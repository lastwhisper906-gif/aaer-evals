# TTMI notes — 0001564590-19-017942


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureAndSignificantAccountingPoliciesTextBlock

[0001564590-19-017942:notes:1]
(1) Nature of Operations and Summary of Significant Accounting Policies

[0001564590-19-017942:notes:2]
TTM Technologies, Inc. (the Company or TTM) is a leading global printed circuit board (PCB) manufacturer, focusing on quick-turn and volume production of technologically complex PCBs, backplane assemblies and electro-mechanical solutions (E-M Solutions) as well as a global designer and manufacturer of radio-frequency (RF) and microwave components and assemblies. The Company provides time-to-market and volume production of advanced technology products and offers a one-stop design, engineering and manufacturing solution to customers from engineering support to prototype development through final mass production. This one-stop design and manufacturing solution enables the Company to align technology developments with the diverse needs of the Company’s customers and to enable them to reduce the time required to develop new products and bring them to market.

[0001564590-19-017942:notes:3]
The Company serves a diversified customer base in various markets throughout the world, including aerospace and defense, automotive components, smartphones and touchscreen tablets, high-end computing, medical, industrial and instrumentation related products, as well as networking/communications infrastructure products. The Company’s customers include both original equipment manufacturers (OEMs) and electronic manufacturing services (EMS) providers.

[0001564590-19-017942:notes:4]
The accompanying consolidated condensed financial statements have been prepared by the Company, without audit, pursuant to the rules and regulations of the Securities and Exchange Commission (SEC). Certain information and disclosures normally included in financial statements prepared in accordance with accounting principles generally accepted in the United States of America (U.S. GAAP) have been condensed or omitted pursuant to such rules and regulations. These consolidated condensed financial statements reflect all adjustments (consisting only of normal recurring adjustments) which, in the opinion of management, are necessary to present fairly the financial position, the results of operations and cash flows of the Company for the periods presented. It is suggested that these consolidated condensed financial statements be read in conjunction with the consolidated financial statements and the notes thereto included in the Company’s most recent Annual Report on Form 10-K. The results of operations for the interim periods are not necessarily indicative of the results to be expected for the full year. The preparation of financial statements in accordance with U.S. GAAP requires management to make estimates and assumptions that affect the amounts reported in the Company’s consolidated condensed financial statements and accompanying notes. Actual results could differ materially from those estimates. The Company uses a 13-week fiscal quarter accounting period with the fourth quarter ending on the Monday nearest December 31.

[0001564590-19-017942:notes:5]
Reclassifications

[0001564590-19-017942:notes:6]
Certain amounts in the prior period consolidated condensed financial statement have been reclassified to conform to the presentation of the current period consolidated condensed financial statement. These reclassifications had no effect on the previously reported net income. An adjustment has been made to combine the statutory surplus reserve with retained earnings on the consolidated condensed balance sheet and the consolidated statement of stockholders’ equity.

[0001564590-19-017942:notes:7]
Summary of Significant Accounting Policies

[0001564590-19-017942:notes:8]
Leases

[0001564590-19-017942:notes:9]
The Company determines if an arrangement is a lease at inception. Operating leases are included in operating lease right-of-use (ROU) assets, other current liabilities, and operating lease liabilities on the consolidated condensed balance sheets.

[0001564590-19-017942:notes:10]
ROU assets represent the Company’s right to use an underlying asset for the lease term and lease liabilities represent the Company’s obligation to make lease payments arising from the lease. Operating lease ROU assets and liabilities are recognized at commencement date based on the present value of lease payments over the lease term. As most of the Company’s leases do not provide an implicit rate, the Company uses incremental borrowing rate based on the information available at commencement date in determining the present value of lease payments. The operating lease ROU asset also includes any lease payments made and excludes lease incentives. Lease terms may include options to extend or terminate the lease when it is reasonably certain that the Company will exercise that option. Lease expense for lease payments is recognized on a straight-line basis over the lease term.

[0001564590-19-017942:notes:11]
The Company has lease agreements with lease and non-lease components and accounts for the lease and non-lease components as a single lease component.

[0001564590-19-017942:notes:12]
Recently Adopted and Issued Accounting Standards

[0001564590-19-017942:notes:13]
Recently Adopted Accounting Standards

[0001564590-19-017942:notes:14]
In February 2016, the Financial Accounting Standards Board (FASB) issued ASU 2016-02, Leases (Topic 842) which supersedes the existing lease recognition requirements in the current accounting standard for leases. The core principal of the new standard is that an entity should recognize ROU assets and lease liabilities arising from a lease for both financing and operating leases, along with additional qualitative and quantitative disclosures.

[0001564590-19-017942:notes:15]
In July 2018, the FASB issued ASU 2018-11, Leases (Topic 842): Targeted Improvements. ASU 2018-11 provides additional guidance to Topic 842 including providing preparers an additional optional retrospective adoption method which allows entities to initially apply the new leases standard at the adoption date and recognize a cumulative effect adjustment to the opening balance of retained earnings. ASU 2018-11 also provides lessors a practical expedient to not separate lease from non-lease components, in certain situations.

[0001564590-19-017942:notes:16]
The Company adopted the new lease standard as of January 1, 2019 and utilized the retrospective cumulative effect adjustment transition method with a cumulative effect adjustment being recorded as of the adoption date. Therefore, comparative information has not been adjusted and continues to be reported under previous U.S. GAAP guidance for the consolidated balance sheet at December 31, 2018 and the consolidated condensed statement of operations for the quarter ended April 2, 2018. The Company implemented internal controls and key system functionality to enable the preparation of financial information on adoption. The Company elected certain available practical expedients including the package of practical expedients permitted under the transition guidance within the new standard, which among other things, allowed the Company to carry forward the historical lease classification. Additionally, the Company elected an accounting policy to not record ROU assets and lease liabilities for leases with an initial term of twelve months or less on its consolidated condensed balance sheet.

[0001564590-19-017942:notes:17]
The cumulative effect of the changes made to the Company’s January 1, 2019 consolidated condensed balance sheet for the adoption of the new lease standard was as follows:

[0001564590-19-017942:notes:18]
|  |  | Balance at December 31, 2018 |  |  | New Lease Standard Adjustment |  |  | Balance at January 1, 2019 |  |
|  |  | (In thousands) |  |
| Balance Sheet |  |  |  |  |  |  |  |  |  |  |  |  |
| Assets |  |  |  |  |  |  |  |  |  |  |  |  |
| Operating lease right-of-use assets |  | $ | — |  |  | $ | 16,894 |  |  | $ | 16,894 |  |
| Deposits and other non-current assets |  |  | 55,597 |  |  |  | (548 | ) |  |  | 55,049 |  |
| Liabilities |  |  |  |  |  |  |  |  |  |  |  |  |
| Other current liabilities |  |  | 113,756 |  |  |  | 2,545 |  |  |  | 116,301 |  |
| Operating lease liabilities |  |  | — |  |  |  | 14,356 |  |  |  | 14,356 |  |
| Other long-term liabilities |  |  | 94,777 |  |  |  | (555 | ) |  |  | 94,222 |  |

[0001564590-19-017942:notes:19]
The adoption of the new accounting guidance did not have a material impact to the consolidated condensed statement of operations or the consolidated condensed statement of cash flows for the quarter ended April 1, 2019. See Note 4 for further details.

[0001564590-19-017942:notes:20]
In June 2018, the FASB issued ASU 2018-07, Compensation-Stock Compensation (Topic 718): Improvements to Nonemployee Share-based Payments. This ASU expands the scope of Topic 718 to include share-based payment transactions for acquiring goods and services from nonemployees. The effective date for the standard is for interim periods in fiscal years beginning after December 15, 2018, with early adoption permitted, but no earlier than the Company's adoption date of Topic 606. The new guidance is required to be applied retrospectively with the cumulative effect recognized at the date of initial application. The Company adopted ASU 2018-07 on January 1, 2019. The adoption did not have a material impact on the consolidated condensed financial statements or related disclosures.

[0001564590-19-017942:notes:21]
In August 2017, the FASB issued ASU 2017-12, Derivatives and Hedging (Topic 815): Targeted Improvements to Accounting for Hedging Activities. This ASU amends and simplifies existing guidance in order to allow companies to more accurately present the economic effects of risk management activities in the financial statements. ASU 2017-12 also amends the guidance surrounding the recognition of the value of hedged instruments to include the entire change in value, rather than just the effective portion, in other comprehensive income and recognized in earnings at the same time that the hedged item affects earnings for cash flow and net investment hedges. This ASU is effective for fiscal years beginning after December 15, 2018, including interim periods within those fiscal years. Early adoption is permitted. The Company adopted ASU 2017-12 on January 1, 2019. The adoption did not have a material impact on the consolidated condensed financial statements or related disclosures.

[0001564590-19-017942:notes:22]
Recently Issued Accounting Standards Not Yet Adopted

[0001564590-19-017942:notes:23]
In August 2018, the FASB issued ASU 2018-14, Compensation—Retirement Benefits—Defined Benefit Plans—General (Subtopic 715-20)—Disclosure Framework—Changes to the Disclosure Requirements for Defined Benefit Plans. The amendments in this update change the disclosure requirements for employers that sponsor defined benefit pension and/or other postretirement benefit plans. It eliminates requirements for certain disclosures that are no longer considered cost beneficial and requires new disclosures that the FASB considers pertinent. The guidance is effective for fiscal years ending after December 15, 2020. Early adoption is permitted. The Company does not anticipate the adoption will have a material impact on the consolidated condensed financial statements and related disclosures.


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0001564590-19-017942:notes:24]
(2) Revenues

[0001564590-19-017942:notes:25]
As of April 1, 2019, the aggregate amount of the transaction price allocated to remaining performance obligations for long-term contracts was $20,601. The Company expects to recognize revenue on approximately 85% of the remaining performance obligations for the Company’s long-term contracts over the next twelve months with the remaining amount recognized thereafter. The remaining performance obligations for the Company’s short-term contracts are expected to be recognized within one year or less.

[0001564590-19-017942:notes:26]
Revenue from products and services transferred to customers over time and at a point in time accounted for 97% and 3%, respectively of the Company’s revenue for the quarter ended April 1, 2019.

[0001564590-19-017942:notes:27]
The following tables represent a disaggregation of revenue by principal end markets with the reportable segments:

[0001564590-19-017942:notes:28]
|  |  | Quarter ended April 1, 2019 |  |
|  |  | PCB |  |  | E-M Solutions |  |  | Total |  |
| End Markets |  | (In thousands) |  |
| Aerospace and Defense |  | $ | 165,068 |  |  | $ | 4 |  |  | $ | 165,072 |  |
| Automotive |  |  | 85,813 |  |  |  | 19,765 |  |  |  | 105,578 |  |
| Cellular Phone |  |  | 43,084 |  |  |  | — |  |  |  | 43,084 |  |
| Computing/Storage/Peripherals |  |  | 80,892 |  |  |  | 189 |  |  |  | 81,081 |  |
| Medical/Industrial/Instrumentation |  |  | 87,670 |  |  |  | 8,167 |  |  |  | 95,837 |  |
| Networking/Communications |  |  | 88,063 |  |  |  | 23,339 |  |  |  | 111,402 |  |
| Other |  |  | 18,232 |  |  |  | (86 | ) |  |  | 18,146 |  |
| Total |  | $ | 568,822 |  |  | $ | 51,378 |  |  | $ | 620,200 |  |

[0001564590-19-017942:notes:29]
|  |  | Quarter ended April 2, 2018 |  |
|  |  | PCB |  |  | E-M Solutions |  |  | Total |  |
| End Markets |  | (In thousands) |  |
| Aerospace and Defense |  | $ | 122,676 |  |  | $ | 89 |  |  | $ | 122,765 |  |
| Automotive |  |  | 116,292 |  |  |  | 19,310 |  |  |  | 135,602 |  |
| Cellular Phone |  |  | 104,860 |  |  |  | — |  |  |  | 104,860 |  |
| Computing/Storage/Peripherals |  |  | 88,542 |  |  |  | 305 |  |  |  | 88,847 |  |
| Medical/Industrial/Instrumentation |  |  | 93,634 |  |  |  | 7,523 |  |  |  | 101,157 |  |
| Networking/Communications |  |  | 81,937 |  |  |  | 19,473 |  |  |  | 101,410 |  |
| Other |  |  | 8,490 |  |  |  | 451 |  |  |  | 8,941 |  |
| Total |  | $ | 616,431 |  |  | $ | 47,151 |  |  | $ | 663,582 |  |


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001564590-19-017942:notes:30]
[same as prior period, unchanged from 0001564590-18-028539:notes:26]

[0001564590-19-017942:notes:31]
On April 18, 2018, the Company acquired all of the equity interests of Anaren for a total consideration of $787,911. Anaren was a leading provider of mission-critical RF solutions, microelectronics, and microwave components and assemblies for the wireless infrastructure and aerospace and defense electronics markets.

[0001564590-19-017942:notes:32]
Bank fees and legal, accounting, and other professional service costs associated with the acquisition of Anaren of $203 and $3,973 for the quarters ended April 1, 2019 and April 2, 2018, respectively, have been expensed and recorded as general and administrative expense in the consolidated condensed statements of operations.

[0001564590-19-017942:notes:33]
[same as prior period, unchanged from 0001564590-18-028539:notes:29]

[0001564590-19-017942:notes:34]
[same as prior period, unchanged from 0001564590-18-028539:notes:30]

[0001564590-19-017942:notes:35]
The purchase price of the Anaren acquisition was allocated to tangible and intangible assets acquired, and liabilities assumed based on the fair value at the date of the acquisition, April 18, 2018. The excess of the purchase price over the fair value of net assets acquired was allocated to goodwill. The fair value assigned to identifiable intangible assets acquired was based on estimates and assumptions made by management at the time of the acquisition. The Company finalized the allocation of the purchase price during the fourth quarter of 2018.

[0001564590-19-017942:notes:36]
The fair values assigned are based on reasonable methods applicable to the nature of the assets acquired and liabilities assumed. The following summarizes the final estimated fair values of net assets acquired:

[0001564590-19-017942:notes:37]
|  |  | (In thousands) |  |
| Cash |  | $ | 12,911 |  |
| Trade and notes receivables |  |  | 32,457 |  |
| Contract assets |  |  | 23,585 |  |
| Inventories |  |  | 56,619 |  |
| Other current assets |  |  | 1,373 |  |
| Property, plant and equipment |  |  | 45,115 |  |
| Identifiable intangible assets |  |  | 336,000 |  |
| Other assets |  |  | 300 |  |
| Goodwill |  |  | 394,474 |  |
| Trade accounts payable |  |  | (14,623 | ) |
| Contract liabilities |  |  | (7,778 | ) |
| Other current liabilities |  |  | (7,616 | ) |
| Long-term debt |  |  | (178,604 | ) |
| Non-current deferred tax liabilities |  |  | (76,470 | ) |
| Other liabilities |  |  | (8,436 | ) |
| Total |  | $ | 609,307 |  |

[0001564590-19-017942:notes:38]
Goodwill represents the excess of the purchase price over the fair value of assets acquired and liabilities assumed. The goodwill acquired in the acquisition is not deductible for income tax purposes.

[0001564590-19-017942:notes:39]
[same as prior period, unchanged from 0001564590-18-028539:notes:55]

[0001564590-19-017942:notes:40]
The unaudited pro forma financial information below gives effect to this acquisition as if it had occurred at the beginning of fiscal 2018, or January 2, 2018. The pro forma financial information presented includes the effects of adjustments related to the amortization of acquired identifiable intangible assets and acquired inventory, depreciation of acquired fixed assets, and other non-recurring transactions costs directly associated with the acquisitions such as legal, accounting and banking fees.

[0001564590-19-017942:notes:41]
[same as prior period, unchanged from 0001564590-18-028539:notes:57]

[0001564590-19-017942:notes:42]
|  |  | Quarter Ended |  |
|  |  | April 1, |  |  | April 2, |  |
|  |  | 2019 |  |  | 2018 |  |
|  |  | (In thousands) |  |
| Net sales |  | $ | 620,200 |  |  | $ | 726,844 |  |
| Net (loss) income |  |  | (3,252 | ) |  |  | 12,526 |  |
| Basic (loss) earnings per share |  | $ | (0.03 | ) |  | $ | 0.12 |  |
| Dilutive (loss) earnings per share |  | $ | (0.03 | ) |  | $ | 0.12 |  |


## us-gaap:LesseeOperatingLeasesTextBlock

[0001564590-19-017942:notes:43]
(4) Leases

[0001564590-19-017942:notes:44]
The Company leases some of its manufacturing and assembly plants, sales offices and equipment under non-cancellable operating leases that expire at various dates through 2049. The majority of the Company’s lease arrangements are comprised of fixed payments and a limited number of leases consist of variable payments based on equipment usage. Certain leases contain renewal provisions at the Company’s option. Most of the leases require the Company to pay for certain other costs such as property taxes and maintenance. Certain leases also contain rent escalation clauses (step rents) that require additional rental amounts in the later years of the term. Rent expense for leases with step rents is recognized on a straight-line basis over the minimum lease term. The lease agreements do not contain any material residual value guarantees or material restrictive covenants.

[0001564590-19-017942:notes:45]
The components of lease expense were as follows:

[0001564590-19-017942:notes:46]
|  | Quarter Ended April 1, 2019 |  |
|  | (In thousands) |  |
| Operating lease cost | $ | 2,231 |  |
| Variable lease cost |  | 191 |  |
| Short-term lease cost |  | 151 |  |

[0001564590-19-017942:notes:47]
Supplemental cash flow information related to leases was as follows:

[0001564590-19-017942:notes:48]
|  | Quarter Ended April 1, 2019 |  |
|  | (In thousands) |  |
| Cash paid for amounts included in the measurement of lease liabilities: |  |  |  |
| Operating cash flows from operating leases | $ | 1,870 |  |
| Right-of-use assets obtained in exchange for new lease obligations: |  |  |  |
| Operating leases |  | 6,789 |  |

[0001564590-19-017942:notes:49]
Supplemental balance sheet information related to leases was as follows:

[0001564590-19-017942:notes:50]
|  | As of April 1, 2019 |  |
|  | (In thousands) |  |
| Operating lease right-of-use assets | $ | 21,631 |  |
| Other current liabilities |  | 7,405 |  |
| Operating lease liabilities |  | 14,598 |  |
| Total operating lease liabilities | $ | 22,003 |  |

[0001564590-19-017942:notes:51]
| Weighted average remaining lease term | 3.8 years |  |
| Weighted average discount rate |  | 4.10 | % |

[0001564590-19-017942:notes:52]
Maturities of operating lease liabilities were as follows1:

[0001564590-19-017942:notes:53]
|  |  | (In thousands) |  |
| Less than one year |  | $ | 8,131 |  |
| 1 - 2 years |  |  | 6,246 |  |
| 2 - 3 years |  |  | 4,869 |  |
| 3 - 4 years |  |  | 1,731 |  |
| 4 - 5 years |  |  | 1,300 |  |
| Thereafter |  |  | 1,539 |  |
| Total lease payments |  |  | 23,816 |  |
| Less imputed interest |  |  | (1,813 | ) |
| Total |  | $ | 22,003 |  |
| 1 Excludes $4,313 of legally binding minimum lease payments for leases signed but not yet commenced. |  |

[0001564590-19-017942:notes:54]
Operating Leases Pre-Topic 842 Adoption

[0001564590-19-017942:notes:55]
The Company leases some of its manufacturing and assembly plants, sales offices and equipment under noncancellable operating leases that expire at various dates through 2049. Certain real property leases contain renewal provisions at the Company’s option. Most of the leases require the Company to pay for certain other costs such as property taxes and maintenance. Certain leases also contain rent escalation clauses (step rents) that require additional rental amounts in the later years of the term. Rent expense for leases with step rents is recognized on a straight-line basis over the minimum lease term.

[0001564590-19-017942:notes:56]
The following is a schedule of future minimum lease payments as of December 31, 2018:

[0001564590-19-017942:notes:57]
|  |  | Operating Leases |  |
|  |  | (In thousands) |  |
| 2019 |  | $ | 7,282 |  |
| 2020 |  |  | 4,701 |  |
| 2021 |  |  | 3,406 |  |
| 2022 |  |  | 2,408 |  |
| 2023 |  |  | 2,172 |  |
| Thereafter |  |  | 4,172 |  |
| Total minimum lease payments |  | $ | 24,141 |  |


## us-gaap:AdditionalFinancialInformationDisclosureTextBlock

[0001564590-19-017942:notes:58]
(5) Composition of Certain Consolidated Condensed Financial Statement Captions

[0001564590-19-017942:notes:59]
|  |  | As of |  |
|  |  | April 1, 2019 |  |  | December 31, 2018 |  |
|  |  | (in thousands) |  |
| Inventories: |  |  |  |  |  |  |  |  |
| Raw materials |  | $ | 101,002 |  |  | $ | 97,600 |  |
| Work-in-process |  |  | 11,623 |  |  |  | 10,299 |  |
| Finished goods |  |  | 2,175 |  |  |  | 1,478 |  |
|  |  | $ | 114,800 |  |  | $ | 109,377 |  |
| Property, plant and equipment, net: |  |  |  |  |  |  |  |  |
| Land and land use rights |  | $ | 74,850 |  |  | $ | 75,431 |  |
| Buildings and improvements |  |  | 536,038 |  |  |  | 534,122 |  |
| Machinery and equipment |  |  | 1,381,549 |  |  |  | 1,357,035 |  |
| Construction-in-progress, furniture and fixtures and other |  |  | 40,446 |  |  |  | 42,713 |  |
|  |  |  | 2,032,883 |  |  |  | 2,009,301 |  |
| Less: Accumulated depreciation |  |  | (995,187 | ) |  |  | (957,277 | ) |
|  |  | $ | 1,037,696 |  |  | $ | 1,052,024 |  |


## us-gaap:GoodwillDisclosureTextBlock

[0001564590-19-017942:notes:60]
[same as prior period, unchanged from 0001564590-18-028539:notes:65]

[0001564590-19-017942:notes:61]
As of April 1, 2019 and December 31, 2018, goodwill was as follows:

[0001564590-19-017942:notes:62]
|  |  | Total |  |
|  |  | (In thousands) |  |
| Balance as of April 1, 2019 and December 31, 2018 |  |  |  |  |
| Goodwill |  | $ | 938,445 |  |
| Accumulated impairment losses |  |  | (171,400 | ) |
|  |  | $ | 767,045 |  |

[0001564590-19-017942:notes:63]
All goodwill relates to the Company’s PCB reportable segment.


## us-gaap:IntangibleAssetsDisclosureTextBlock

[0001564590-19-017942:notes:64]
[same as prior period, unchanged from 0001564590-18-028539:notes:70]

[0001564590-19-017942:notes:65]
As of April 1, 2019 and December 31, 2018, the components of definite-lived intangibles were as follows:

[0001564590-19-017942:notes:66]
|  |  | Gross Amount |  |  | Accumulated Amortization |  |  | Net Carrying Amount |  | Weighted Average Amortization Period |  |
|  |  | (In thousands) |  | (years) |  |
| April 1, 2019 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Customer relationships |  | $ | 415,000 |  |  | $ | (93,149 | ) |  | $ | 321,851 |  |  | 10.7 |  |
| Technology |  |  | 39,500 |  |  |  | (4,525 | ) |  |  | 34,975 |  |  | 9.4 |  |
| Backlog |  |  | 29,000 |  |  |  | (27,908 | ) |  |  | 1,092 |  |  | 0.9 |  |
|  |  | $ | 483,500 |  |  | $ | (125,582 | ) |  | $ | 357,918 |  |  |  |  |
| December 31, 2018 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Customer relationships |  | $ | 203,634 |  |  | $ | (123,522 | ) |  | $ | 80,112 |  |  | 8.1 |  |
| Technology |  |  | 3,000 |  |  |  | (3,000 | ) |  |  | — |  |  | 3.0 |  |
| Acquired intangibles from acquisition |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Customer relationships |  |  | 267,500 |  |  |  | (15,561 | ) |  |  | 251,939 |  |  | 12.2 |  |
| Developed technology |  |  | 39,500 |  |  |  | (3,345 | ) |  |  | 36,155 |  |  | 9.4 |  |
| Backlog |  |  | 29,000 |  |  |  | (21,283 | ) |  |  | 7,717 |  |  | 0.9 |  |
|  |  | $ | 542,634 |  |  | $ | (166,711 | ) |  | $ | 375,923 |  |  |  |  |

[0001564590-19-017942:notes:67]
Definite-lived intangibles are generally amortized using the straight line method of amortization over the useful life, with the exception of certain customer relationship intangibles, which are amortized using an accelerated method of amortization based on estimated cash flows. Amortization expense was $18,005 and $5,861 for the quarters ended April 1, 2019 and April 2, 2018, respectively. For the quarter ended April 1, 2019, $1,179 of amortization expense is included in cost of goods sold.

[0001564590-19-017942:notes:68]
[same as prior period, unchanged from 0001564590-18-028539:notes:75]

[0001564590-19-017942:notes:69]
|  |  | (In thousands) |  |
| Remaining 2019 |  | $ | 35,156 |  |
| 2020 |  |  | 45,419 |  |
| 2021 |  |  | 42,108 |  |
| 2022 |  |  | 39,002 |  |
| 2023 |  |  | 36,290 |  |
| Thereafter |  |  | 159,943 |  |
|  |  | $ | 357,918 |  |


## us-gaap:LongTermDebtTextBlock

[0001564590-19-017942:notes:70]
(8) Long-term Debt and Letters of Credit

[0001564590-19-017942:notes:71]
The following table summarizes the long-term debt of the Company as of April 1, 2019 and December 31, 2018:

[0001564590-19-017942:notes:72]
|  |  | Interest Rate as of April 1, 2019 |  |  | Principal Outstanding as of April 1, 2019 |  |  | Interest Rate as of December 31, 2018 |  |  | Principal Outstanding as of December 31, 2018 |  |
|  |  | (In thousands) |  |
| Term Loan due September 2024 |  | 4.99% |  |  | $ | 805,879 |  |  | 5.00% |  |  | $ | 835,879 |  |
| Senior Notes due October 2025 |  | 5.63% |  |  |  | 375,000 |  |  | 5.63% |  |  |  | 375,000 |  |
| Convertible Senior Notes due December 2020 |  | 1.75% |  |  |  | 249,975 |  |  | 1.75% |  |  |  | 249,985 |  |
| U.S. ABL Revolving Loan due May 2020 |  | 3.99% |  |  |  | 40,000 |  |  | 4.00% |  |  |  | 40,000 |  |
| Asia ABL Revolving Loan due May 2020 |  | 3.89% |  |  |  | 30,000 |  |  | 3.90% |  |  |  | 30,000 |  |
|  |  |  |  |  |  |  | 1,500,854 |  |  |  |  |  |  |  | 1,530,864 |  |
| Less: Long-term debt unamortized discount |  |  |  |  |  |  | (19,603 | ) |  |  |  |  |  |  | (22,167 | ) |
| Long-term debt unamortized debt issuance costs |  |  |  |  |  |  | (15,241 | ) |  |  |  |  |  |  | (16,272 | ) |
|  |  |  |  |  |  |  | 1,466,010 |  |  |  |  |  |  |  | 1,492,425 |  |
| Less: current maturities |  |  |  |  |  |  | — |  |  |  |  |  |  |  | (30,000 | ) |
| Long-term debt, less current maturities |  |  |  |  |  | $ | 1,466,010 |  |  |  |  |  |  | $ | 1,462,425 |  |

[0001564590-19-017942:notes:73]
Term Loan Facility

[0001564590-19-017942:notes:74]
On April 18, 2018, the Company closed its $600,000 commitment of incremental loans concurrent with the completion of its acquisition of Anaren. At issuance, these incremental loans increased the Company’s existing balance of its Term Loan Facility due 2024 from $348,250 to $948,250. The Term Loan Facility had an outstanding balance of $805,879 as of April 1, 2019 and is included in long-term debt. The Term Loan Facility was issued at a weighted average discount of 99.7% and bears interest, at the Company’s option, at a floating rate of LIBOR, plus an applicable interest margin of 2.50%, or an alternate base rate, (defined as the greater of the JP Morgan prime, the New York Fed bank rate plus 0.5% or LIBOR plus 1.0%), subject to a 1.0% floor plus an applicable margin of 1.5%. At April 1, 2019, the interest rate on the outstanding borrowings under the Term Loan Facility was 4.99%. There is no provision, other than an event of default, for the interest margin to increase. The Term Loan Facility will mature on September 28, 2024. The Term Loan Facility is secured by a significant amount of the domestic assets of the Company and a pledge of 65% of voting stock of the Company’s first tier foreign subsidiaries and is structurally senior to the Company’s Senior Notes and Convertible Senior Notes. See Senior Notes and Convertible Senior Notes below.

[0001564590-19-017942:notes:75]
Based on certain parameters defined in the Term Loan Facility, including a First Lien Leverage Ratio, the Company may be required to make an additional principal payment on an annual basis beginning after fiscal year 2018, if the Company’s First Lien Leverage Ratio is greater than 2.0. For 2019, the Company is not required to make an additional principal payment as its First Lien Leverage Ratio is less than 2.0. Any remaining outstanding balance under the Term Loan Facility is due at the maturity date of September 28, 2024.

[0001564590-19-017942:notes:76]
Borrowings under the Term Loan Facility are subject to certain affirmative and negative covenants, including limitations on indebtedness, corporate transactions, investments and dispositions, and share payments.

[0001564590-19-017942:notes:77]
Senior Notes

[0001564590-19-017942:notes:78]
The $375,000 of Senior Notes, which is included in long-term debt, bears interest at a rate of 5.63% per annum. Interest is payable semiannually in arrears on April 1 and October 1 of each year beginning April 1, 2018. The Senior Notes will mature on October 1, 2025.

[0001564590-19-017942:notes:79]
Borrowings under the Senior Notes are subject to certain affirmative and negative covenants, including limitations on indebtedness, corporate transactions, investments, dispositions, and share payments.

[0001564590-19-017942:notes:80]
Convertible Senior Notes due 2020

[0001564590-19-017942:notes:81]
The Company maintains 1.75% Convertible Senior Notes in the amount of $249,975 due December 15, 2020. The Convertible Senior Notes bear interest at a rate of 1.75% per annum. Interest is payable semiannually in arrears on June 15 and December 15 of each year. The Convertible Senior Notes are unsecured obligations and would rank equally to the Company’s future unsecured senior indebtedness and are senior in right of payment to any of the Company’s future subordinated indebtedness.

[0001564590-19-017942:notes:82]
As of April 1, 2019 and December 31, 2018, the following summarizes the equity components of the Convertible Senior Notes included in additional paid-in capital:

[0001564590-19-017942:notes:83]
|  |  | As of April 1, 2019 |  |  | As of December 31, 2018 |  |
|  |  | Embedded conversion option — Convertible Senior Notes |  |  | Embedded conversion option — Convertible Senior Notes Issuance Costs |  |  | Total |  |  | Embedded conversion option — Convertible Senior Notes |  |  | Embedded conversion option — Convertible Senior Notes Issuance Costs |  |  | Total |  |
|  |  | (in thousands) |  |
| Convertible Senior Notes due 2020 |  | $ | 60,213 |  |  | $ | (1,916 | ) |  | $ | 58,297 |  |  | $ | 60,216 |  |  | $ | (1,916 | ) |  | $ | 58,300 |  |

[0001564590-19-017942:notes:84]
The components of interest expense resulting from the Convertible Senior Notes for the quarters ended April 1, 2019 and April 2, 2018 were as follows:

[0001564590-19-017942:notes:85]
|  |  | Quarter Ended |  |
|  |  | April 1, |  |  | April 2, |  |
|  |  | 2019 |  |  | 2018 |  |
|  |  | (In thousands) |  |
| Contractual coupon interest |  | $ | 1,094 |  |  | $ | 1,094 |  |
| Amortization of debt discount |  | $ | 2,379 |  |  | $ | 2,230 |  |
| Amortization of debt issuance costs |  | $ | 238 |  |  | $ | 224 |  |

[0001564590-19-017942:notes:86]
Asset-Based Lending Agreements

[0001564590-19-017942:notes:87]
The Company maintains a $200,000 U.S. Asset-Based Lending Credit Agreement (U.S. ABL), and a $150,000 Asia Asset-Based Lending Credit Agreement (Asia ABL) (collectively the ABL Revolving Loans).

[0001564590-19-017942:notes:88]
The U.S. ABL consists of three tranches comprised of a revolving credit facility for up to $200,000, a letter of credit facility for up to $50,000, and swingline loans for up to $30,000, provided that at no time may amounts outstanding under the tranches exceed in aggregate $200,000 or the applicable borrowing base, which is a percentage of the principal amount of Eligible Accounts, as defined in the U.S. ABL agreement. Borrowings under the U.S. ABL bear interest at either a floating rate of LIBOR plus a margin of 150 basis points or JP Morgan Chase Bank’s prime rate plus a margin of 50 basis points, at the Company’s option. At April 1, 2019, the interest rate on the outstanding borrowings under the U.S. ABL was 3.99%. The applicable margin can vary based on the remaining availability of the facility, from 125 to 175 basis points for LIBOR-based loans and from 25 to 75 basis points for JP Morgan Chase Bank’s prime rate-based loans. Other than availability and an event of default, there are no other provisions for the interest margin to increase. The U.S. ABL will mature on May 31, 2020. Loans made under the U.S. ABL are secured first by all of the Company’s domestic cash, receivables and certain inventories as well as by a second position against a significant amount of the domestic assets of the Company and a pledge of 65% of the voting stock of the Company’s first tier foreign subsidiaries and are structurally senior to the Company’s Senior Notes and Convertible Senior Notes. See Senior Notes and Convertible Senior Notes above. As of April 1, 2019, $40,000 of the U.S. ABL was outstanding and classified as long-term debt, which is consistent with its maturity date.

[0001564590-19-017942:notes:89]
The Asia ABL consists of two tranches comprised of a revolving credit facility for up to $150,000 and a letter of credit facility for up to $100,000, provided that at no time may amounts outstanding under both tranches exceed in aggregate $150,000 or the applicable borrowing base, which is a percentage of the principal amount of Eligible Accounts, as defined in the Asia ABL agreement. Borrowings under the Asia ABL bear interest at a floating rate of LIBOR plus 140 basis points. As of April 1, 2019, the interest rate on the outstanding borrowings under the Asia ABL was 3.89%. There is no provision, other than an event of default, for the interest margin to increase. The Asia ABL will mature on May 22, 2020. Loans made under the Asia ABL are secured by a portion of the Company’s Asia Pacific cash and receivables and are structurally senior to the Company’s domestic obligations, including the Senior Notes and Convertible Senior Notes. See Senior Notes and Convertible Senior Notes above. As of April 1, 2019, $30,000 of the Asia ABL was outstanding and classified as long-term debt, which is consistent with its maturity date.

[0001564590-19-017942:notes:90]
The Company has up to $50,000 and $100,000 Letters of Credit Facilities under the U.S. ABL and the Asia ABL, respectively. As of April 1, 2019, letters of credit in the amount of $13,383 were outstanding under the U.S. ABL and $19,445 were outstanding under the Asia ABL with various expiration dates through September 2019. Available borrowing capacity under the U.S. ABL and the Asia ABL was $146,617 and $100,555, respectively, which considers letters of credit outstanding as of April 1, 2019.

[0001564590-19-017942:notes:91]
The Company is required to pay a commitment fee of 0.25% to 0.375% per annum on any unused portion of the U.S. ABL or Asia ABL. The Company incurred total commitment fees related to unused borrowing availability of $240 and $241 for the quarters ended April 1, 2019 and April 2, 2018, respectively. Under the occurrence of certain events, the ABL Revolving Loans are subject to various financial and operational covenants, including maintaining minimum fixed charge coverage ratios.

[0001564590-19-017942:notes:92]
Other Credit Facility

[0001564590-19-017942:notes:93]
Additionally, the Company is party to a revolving loan credit facility (Chinese Revolver) with a lender in China. Under this arrangement, the lender has made available to the Company approximately $31,286 in unsecured borrowing with all terms of the borrowing to be negotiated at the time the Chinese Revolver is drawn upon. There are no commitment fees on the unused portion of the Chinese Revolver, and this arrangement expires in June 2019. As of April 1, 2019, the Chinese Revolver had not been drawn upon.

[0001564590-19-017942:notes:94]
Debt Issuance and Debt Discount

[0001564590-19-017942:notes:95]
As of April 1, 2019 and December 31, 2018, remaining unamortized debt discount and debt issuance costs for the Term Loan Facility, Senior Notes and Convertible Senior Notes are as follows:

[0001564590-19-017942:notes:96]
|  |  | As of April 1, 2019 |  |  | As of December 31, 2018 |  |
|  |  | Debt Issuance Costs |  |  | Debt Discount |  |  | Effective Interest Rate |  |  | Debt Issuance Costs |  |  | Debt Discount |  |  | Effective Interest Rate |  |
|  |  | (in thousands) |  |
| Term Loan due September 2024 |  | $ | 7,620 |  |  | $ | 2,305 |  |  | 4.66% |  |  | $ | 8,229 |  |  | $ | 2,489 |  |  | 4.66% |  |
| Senior Notes due October 2025 |  |  | 5,887 |  |  | — |  |  | 5.92% |  |  |  | 6,071 |  |  | — |  |  | 5.92% |  |
| Convertible Senior Notes |  |  | 1,734 |  |  |  | 17,298 |  |  | 6.48% |  |  |  | 1,972 |  |  |  | 19,678 |  |  | 6.48% |  |
|  |  | $ | 15,241 |  |  | $ | 19,603 |  |  |  |  |  |  | $ | 16,272 |  |  | $ | 22,167 |  |  |  |  |  |

[0001564590-19-017942:notes:97]
The above debt discount and debt issuance costs are recorded as a reduction of the debt and are amortized into interest expense using an effective interest rate over the duration of the debt.

[0001564590-19-017942:notes:98]
Remaining unamortized debt issuance costs for the ABL Revolving Loans of $1,170 and $1,420 as of April 1, 2019 and December 31, 2018, respectively, are included in other non-current assets and are amortized to interest expense over the duration of the ABL Revolving Loans using the straight line method of amortization.

[0001564590-19-017942:notes:99]
At April 1, 2019, the remaining weighted average amortization period for all unamortized debt discount and debt issuance costs was 3.5 years.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001564590-19-017942:notes:100]
[same as prior period, unchanged from 0001564590-18-028539:notes:109]

[0001564590-19-017942:notes:101]
[same as prior period, unchanged from 0001564590-18-028539:notes:110]

[0001564590-19-017942:notes:102]
During the quarter ended April 1, 2019, the Company’s effective tax rate was impacted by a net discrete benefit of $342. This is related to retroactive approval of the Company’s renewal application for High and New Tax Enterprise status for two of the Company’s manufacturing subsidiaries in China offset by the accrued interest expense on existing uncertain tax positions.

[0001564590-19-017942:notes:103]
The Company has various foreign subsidiaries formed or acquired to conduct or support its business outside the United States. The Company expects its earnings attributable to most foreign subsidiaries may be repatriated back to the U.S. and so a deferred tax liability has been recorded for foreign withholding and the estimated federal/state tax impact. For those other companies with earnings currently being reinvested outside of the U.S., no deferred tax liabilities on undistributed earnings are recorded.


## us-gaap:FinancialInstrumentsDisclosureTextBlock

[0001564590-19-017942:notes:104]
[same as prior period, unchanged from 0001564590-18-028539:notes:121]

[0001564590-19-017942:notes:105]
[same as prior period, unchanged from 0001564590-18-028539:notes:122]

[0001564590-19-017942:notes:106]
[same as prior period, unchanged from 0001564590-18-028539:notes:123]

[0001564590-19-017942:notes:107]
[same as prior period, unchanged from 0001564590-18-028539:notes:124]

[0001564590-19-017942:notes:108]
[same as prior period, unchanged from 0001564590-18-028539:notes:125]

[0001564590-19-017942:notes:109]
At inception, the Company designated the interest rate swap as a cash flow hedge and the fair value of the interest rate swap was zero. As of April 1, 2019, the fair value of the interest rate swap was recorded as a liability in the amount of $6,982 and included as a component of other long-term liabilities. The change in the fair value of the interest rate swap is recorded as a component of accumulated other comprehensive loss, net of tax, in the Company’s consolidated condensed balance sheet. No ineffectiveness was recognized for the quarter ended April 1, 2019. During the quarter ended April 1, 2019, the interest rate swap increased interest expense by $339.

[0001564590-19-017942:notes:110]
[same as prior period, unchanged from 0001564590-18-028539:notes:127]

[0001564590-19-017942:notes:111]
The Company enters into foreign currency forward contracts to mitigate the impact of changes in foreign currency exchange rates and to reduce the volatility of purchases and other obligations generated in currencies other than its functional currencies. The Company’s foreign subsidiaries may at times purchase forward exchange contracts to manage their foreign currency risks in relation to certain purchases of machinery denominated in foreign currencies other than the Company’s functional currencies. There were no foreign exchange contracts at April 1, 2019. The notional amount of the foreign exchange contracts at December 31, 2018 was approximately $4,313. The Company had designated certain of these foreign exchange contracts as cash flow hedges.

[0001564590-19-017942:notes:112]
[same as prior period, unchanged from 0001564590-18-028539:notes:129]

[0001564590-19-017942:notes:113]
|  |  |  |  | Liability Fair Value |  |
|  |  | Balance Sheet Location |  | April 1, 2019 |  |  | December 31, 2018 |  |
|  |  |  |  | (In thousands) |  |
| Cash flow derivative instruments designated as hedges: |  |  |  |  |  |  |  |  |
| Interest rate swap |  | Other long-term liabilities |  | $ | (6,982 | ) |  | $ | (4,735 | ) |
| Cash flow derivative instruments not designated as hedges: |  |  |  |  |  |  |  |  |
| Foreign exchange contracts |  | Other current liabilities |  |  | — |  |  |  | (139 | ) |

[0001564590-19-017942:notes:114]
The following table provides information about the amounts recorded in accumulated other comprehensive loss related to derivatives designated as cash flow hedges, as well as the amounts recorded in each caption in the consolidated condensed statements of operations when derivative amounts are reclassified out of accumulated other comprehensive loss for the quarters ended April 1, 2019 and April 2, 2018:

[0001564590-19-017942:notes:115]
|  |  |  | Quarter ended April 1, 2019 |  |  | Quarter ended April 2, 2018 |  |
|  | Financial Statement Caption |  | Gain/(Loss) Recognized in Other Comprehensive Income |  |  | Gain/(Loss) Reclassified into Income |  |  | Gain/(Loss) Recognized in Other Comprehensive Income |  |  | Gain/(Loss) Reclassified into Income |  |
|  |  |  | (In thousands) |  |
| Cash flow hedge: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Interest rate swap | Interest expense |  | $ | (2,586 | ) |  | $ | (339 | ) |  | $ | — |  |  | $ | — |  |
| Foreign currency forward | Depreciation expense |  |  | — |  |  |  | (39 | ) |  |  | (6 | ) |  |  | 41 |  |

[0001564590-19-017942:notes:116]
The following table provides a summary of the activity associated with the designated cash flow hedges reflected in accumulated other comprehensive loss for the quarters ended April 1, 2019 and April 2, 2018:

[0001564590-19-017942:notes:117]
|  |  | Quarter Ended |  |
|  |  | April 1, |  |  | April 2, |  |
|  |  | 2019 |  |  | 2018 |  |
|  |  | (In thousands) |  |
| Beginning balance, net of tax |  | $ | (4,214 | ) |  | $ | (742 | ) |
| Changes in fair value loss, net of tax |  |  | (1,828 | ) |  |  | (6 | ) |
| Reclassification to earnings |  |  | 278 |  |  |  | 41 |  |
| Ending balance, net of tax |  | $ | (5,764 | ) |  | $ | (707 | ) |

[0001564590-19-017942:notes:118]
Based on the current yield curve, the Company expects that losses of approximately $1,417 of the accumulated other comprehensive loss will be reclassified into the statement of operations, net of tax, in the next twelve months.

[0001564590-19-017942:notes:119]
The net gain recognized in other, net in the consolidated condensed statements of operations on derivative instruments not designated as hedges is as follows:

[0001564590-19-017942:notes:120]
|  |  | Quarter Ended |  |
|  |  | April 1, |  |  | April 2, |  |
|  |  | 2019 |  |  | 2018 |  |
|  |  | (In thousands) |  |
| Derivative instruments not designated as hedges: |  |  |  |  |  |  |  |  |
| Foreign exchange contracts |  | $ | 4 |  |  | $ | 427 |  |


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0001564590-19-017942:notes:121]
(11) Accumulated Other Comprehensive Loss

[0001564590-19-017942:notes:122]
The following provides a summary of the components of accumulated other comprehensive loss, net of tax as of April 1, 2019 and December 31, 2018:

[0001564590-19-017942:notes:123]
|  |  | Foreign Currency Translation |  |  | Pension Obligation |  |  | Gains (Losses) on Cash Flow Hedges |  |  | Total |  |
|  |  | (In thousands) |  |
| Ending balance at December 31, 2018 |  | $ | 1,578 |  |  | $ | (1,284 | ) |  | $ | (4,214 | ) |  | $ | (3,920 | ) |
| Other comprehensive income (loss) before reclassifications |  |  | 630 |  |  |  | 19 |  |  |  | (1,828 | ) |  |  | (1,179 | ) |
| Amounts reclassified from accumulated other comprehensive income |  |  | — |  |  |  | — |  |  |  | 278 |  |  |  | 278 |  |
| Other comprehensive income (loss) |  |  | 630 |  |  |  | 19 |  |  |  | (1,550 | ) |  |  | (901 | ) |
| Ending balance at April 1, 2019 |  | $ | 2,208 |  |  | $ | (1,265 | ) |  | $ | (5,764 | ) |  | $ | (4,821 | ) |


## us-gaap:ConcentrationRiskDisclosureTextBlock

[0001564590-19-017942:notes:124]
[same as prior period, unchanged from 0001564590-18-028539:notes:141]

[0001564590-19-017942:notes:125]
[same as prior period, unchanged from 0001564590-18-028539:notes:142]

[0001564590-19-017942:notes:126]
[same as prior period, unchanged from 0001564590-18-028539:notes:143]

[0001564590-19-017942:notes:127]
There were no customers that accounted for 10% or more of net sales for the quarter ended April 1, 2019. For the quarter ended April 2, 2018, one customer accounted for approximately 16% of the Company’s net sales. There were no other customers that accounted for 10% or more of net sales for the quarter ended April 2, 2018.


## us-gaap:FairValueDisclosuresTextBlock

[0001564590-19-017942:notes:128]
[same as prior period, unchanged from 0001564590-18-028539:notes:145]

[0001564590-19-017942:notes:129]
[same as prior period, unchanged from 0001564590-18-028539:notes:146]

[0001564590-19-017942:notes:130]
The carrying amount and estimated fair value of the Company’s financial instruments at April 1, 2019 and December 31, 2018 were as follows:

[0001564590-19-017942:notes:131]
|  |  | April 1, 2019 |  |  | December 31, 2018 |  |
|  |  | Carrying Amount |  |  | Fair Value |  |  | Carrying Amount |  |  | Fair Value |  |
|  |  | (In thousands) |  |
| Derivative liabilities, current |  | $ | — |  |  | $ | — |  |  | $ | 139 |  |  | $ | 139 |  |
| Derivative liabilities, non-current |  |  | 6,982 |  |  |  | 6,982 |  |  |  | 4,735 |  |  |  | 4,735 |  |
| Term Loan due September 2024 |  |  | 795,954 |  |  |  | 791,776 |  |  |  | 825,161 |  |  |  | 782,592 |  |
| Senior Notes due October 2025 |  |  | 369,113 |  |  |  | 365,205 |  |  |  | 368,929 |  |  |  | 350,880 |  |
| Convertible Senior Notes |  |  | 230,943 |  |  |  | 337,691 |  |  |  | 228,335 |  |  |  | 290,858 |  |
| ABL Revolving Loans |  |  | 70,000 |  |  |  | 70,000 |  |  |  | 70,000 |  |  |  | 70,000 |  |

[0001564590-19-017942:notes:132]
The fair value of the derivative instruments was determined using pricing models developed based on the LIBOR swap rate, foreign currency exchange rates, and other observable market data, including quoted market prices, as appropriate using Level 2 inputs. The values were adjusted to reflect non-performance risk of both the counterparty and the Company, as necessary.

[0001564590-19-017942:notes:133]
The fair value of the long-term debt was estimated based on quoted market prices or discounting the debt over its life using current market rates for similar debt as of April 1, 2019 and December 31, 2018, which are considered Level 2 inputs.

[0001564590-19-017942:notes:134]
The fair value of the Convertible Senior Notes was estimated based on quoted market prices of the securities on an active exchange, which are considered Level 2 inputs.

[0001564590-19-017942:notes:135]
As of April 1, 2019 and December 31, 2018, the Company’s other financial instruments also included cash and cash equivalents, accounts receivable, and accounts payable. Due to short-term maturities, the carrying amount of these instruments approximates fair value. The Company’s cash and cash equivalents at April 1, 2019 consisted of $25,308 held in the U.S., with the remaining $209,911 held by foreign subsidiaries.

[0001564590-19-017942:notes:136]
The majority of the Company’s non-financial assets and liabilities, which include goodwill, intangible assets, inventories, and property, plant and equipment, are not required to be carried at fair value on a recurring basis. However, if certain triggering events occur (or are tested at least annually in the case of goodwill) such that a non-financial instrument is required to be evaluated for impairment, based upon a comparison of the non-financial instrument’s fair value to its carrying value, an impairment is recorded to reduce the carrying value to the fair value, if the carrying value exceeds the fair value.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001564590-19-017942:notes:137]
(14) Commitments and Contingencies

[0001564590-19-017942:notes:138]
Legal Matters

[0001564590-19-017942:notes:139]
The Company is subject to various legal matters, which it considers normal for its business activities. While the Company currently believes that the amount of any reasonably possible loss for known matters would not be material to the Company’s financial condition, the outcome of these actions is inherently difficult to predict. In the event of an adverse outcome, the ultimate potential loss could have a material adverse effect on the Company’s financial condition or results of operations in a particular period. The Company has accrued amounts for its loss contingencies which are probable and estimable as of April 1, 2019 and December 31, 2018. However, these amounts are not material to the consolidated condensed financial statements of the Company.


## us-gaap:EarningsPerShareTextBlock

[0001564590-19-017942:notes:140]
(15) (Loss) Earnings Per Share

[0001564590-19-017942:notes:141]
The following is a reconciliation of the numerator and denominator used to calculate basic (loss) earnings per share and diluted (loss) earnings per share for the quarters ended April 1, 2019 and April 2, 2018:

[0001564590-19-017942:notes:142]
|  |  | Quarter Ended |  |
|  |  | April 1, 2019 |  |  | April 2, 2018 |  |
|  |  | (In thousands, except per share amounts) |  |
| Net (loss) income |  | $ | (3,252 | ) |  | $ | 10,097 |  |
| Basic weighted average shares |  |  | 104,315 |  |  |  | 102,508 |  |
| Dilutive effect of performance-based restricted stock units, restricted stock units and stock options |  |  | — |  |  |  | 1,829 |  |
| Dilutive effect of outstanding warrants |  |  | — |  |  |  | 3,180 |  |
| Diluted shares |  |  | 104,315 |  |  |  | 107,517 |  |
| (Loss) earnings per share: |  |  |  |  |  |  |  |  |
| Basic |  | $ | (0.03 | ) |  |  | 0.10 |  |
| Diluted |  | $ | (0.03 | ) |  |  | 0.09 |  |

[0001564590-19-017942:notes:143]
For the quarter ended April 1, 2019, potential shares of common stock, consisting of stock options to purchase approximately 100 shares of common stock at exercise prices ranging from $9.54 to $16.60 per share, 1,493 restricted stock units (RSUs), and 255 performance-based restricted stock units (PRUs) were not included in the computation of diluted earnings per share because the Company incurred a net loss and, as a result, the impact would be anti-dilutive.

[0001564590-19-017942:notes:144]
For the quarter ended April 2, 2018, PRUs, RSUs, and stock options to purchase 931 shares of common stock were not considered in calculating diluted earnings per share because the options’ exercise prices or the total expected proceeds under the treasury stock method for PRUs, RSUs or stock options was greater than the average market price of common shares during the applicable quarter and, therefore, the effect would be anti-dilutive.

[0001564590-19-017942:notes:145]
Outstanding warrants for the quarter ended April 1, 2019, to purchase common stock were not included in the computation of dilutive earnings per share because the strike price of the warrants to purchase the Company’s common stock were greater than the average market price of common shares during the applicable quarter, and therefore, the effect would be anti-dilutive.

[0001564590-19-017942:notes:146]
For the quarters ended April 1, 2019 and April 2, 2018, the effect of shares of common stock related to the Company’s Convertible Senior Notes, based on the if-converted method, were not included in the computation of dilutive earnings per share as the impact would be anti-dilutive.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001564590-19-017942:notes:147]
[same as prior period, unchanged from 0001564590-18-028539:notes:163]

[0001564590-19-017942:notes:148]
[same as prior period, unchanged from 0001564590-18-028539:notes:164]

[0001564590-19-017942:notes:149]
|  |  | Quarter Ended |  |
|  |  | April 1, |  |  | April 2, |  |
|  |  | 2019 |  |  | 2018 |  |
|  |  | (In thousands) |  |
| Cost of goods sold |  | $ | 705 |  |  | $ | 529 |  |
| Selling and marketing |  |  | 466 |  |  |  | 374 |  |
| General and administrative |  |  | 2,755 |  |  |  | 2,719 |  |
| Stock-based compensation expense recognized |  | $ | 3,926 |  |  | $ | 3,622 |  |

[0001564590-19-017942:notes:150]
[same as prior period, unchanged from 0001564590-18-028539:notes:166]

[0001564590-19-017942:notes:151]
The Company maintains a long-term incentive program for executives that provides for the issuance of PRUs, representing hypothetical shares of the Company’s common stock that may be issued. Under the PRU program, a target number of PRUs is typically awarded at the beginning of each three-year performance period. The number of shares of common stock released at the end of the performance period will range from zero to 2.4 times the target number depending on performance during the period. The performance metrics of the PRU program are based on (a) annual financial targets, which are based on revenue and EBITDA (earnings before interest, tax, depreciation, and amortization expense), each equally weighted, and (b) an overall modifier based on the Company’s total stockholder return (TSR) relative to a group of peer companies selected by the Company’s compensation committee, over the three-year performance period.

[0001564590-19-017942:notes:152]
The Company records stock-based compensation expense for PRU awards granted based on management’s periodic assessment of the annual financial performance goals to be achieved. As of April 1, 2019, management determined that vesting of the PRU awards was probable. PRU activity for the quarter ended April 1, 2019 was as follows:

[0001564590-19-017942:notes:153]
|  |  | Shares |  |  | Weighted Average Fair Value |  |
|  |  | (In thousands) |  |  |  |  |  |
| Outstanding shares at December 31, 2018 |  |  | 255 |  |  | $ | 18.75 |  |
| Granted |  |  | 176 |  |  |  | 11.84 |  |
| Outstanding shares at April 1, 2019 |  |  | 431 |  |  | $ | 15.94 |  |

[0001564590-19-017942:notes:154]
The fair value for PRUs granted is calculated using a Monte Carlo simulation model, as the TSR modifier contains a market condition. For the quarters ended April 1, 2019 and April 2, 2018, the following assumptions were used in determining the fair value:

[0001564590-19-017942:notes:155]
|  |  | Quarter Ended |  |
|  |  | April 1, |  |  | April 2, |  |
|  |  | 2019 (1) |  |  | 2018 (2) |  |
| Weighted-average fair value |  | $ | 11.84 |  |  | $ | 19.60 |  |
| Risk-free interest rate |  |  | 2.50 | % |  |  | 2.13 | % |
| Dividend yield |  |  | — |  |  |  | — |  |
| Expected volatility |  |  | 39 | % |  |  | 40 | % |
| Expected term in years |  |  | 1.3 |  |  |  | 1.5 |  |

[0001564590-19-017942:notes:156]
| (1) | Reflects the weighted-averages for the third year of the three-year performance period applicable to PRUs granted in 2017 and second year of the three-year performance period applicable to PRUs granted in 2018. |

[0001564590-19-017942:notes:157]
| (2) | Reflects the weighted-averages for the third year of the three-year performance period applicable to PRUs granted in 2016, second year of the three-year performance period applicable to PRUs granted in 2017 and first year of the three-year performance period applicable to PRUs granted in 2018. |

[0001564590-19-017942:notes:158]
The risk-free interest rate for the expected term of PRUs is based on the U.S. Treasury yield curve in effect at the time of grant. Expected volatility is calculated using the Company’s historical stock price. The expected term of the PRUs reflects the performance period for the PRUs granted.

[0001564590-19-017942:notes:159]
[same as prior period, unchanged from 0001564590-18-028539:notes:170]

[0001564590-19-017942:notes:160]
The Company granted 2 and 828 RSUs during the quarters ended April 1, 2019 and April 2, 2018, respectively. The RSUs granted have a weighted-average fair value per unit of $11.21 and $15.29 for the quarters ended April 1, 2019 and April 2, 2018, respectively. The fair value for RSUs granted is based on the closing share price of the Company’s common stock on the date of grant.

[0001564590-19-017942:notes:161]
[same as prior period, unchanged from 0001564590-18-028539:notes:172]

[0001564590-19-017942:notes:162]
The Company did not grant any stock option awards during the quarters ended April 1, 2019 and April 2, 2018.

[0001564590-19-017942:notes:163]
[same as prior period, unchanged from 0001564590-18-028539:notes:174]

[0001564590-19-017942:notes:164]
The following is a summary of total unrecognized compensation costs as of April 1, 2019:

[0001564590-19-017942:notes:165]
|  |  | Unrecognized Stock-Based Compensation Cost |  |  | Remaining Weighted Average Recognition Period |  |
|  |  | (In thousands) |  |  | (In years) |  |
| RSU awards |  | $ | 14,358 |  |  |  | 1.3 |  |
| PRU awards |  |  | 3,860 |  |  |  | 1.2 |  |
| Stock options |  |  | 330 |  |  |  | 2.0 |  |
|  |  | $ | 18,548 |  |  |  |  |  |


## us-gaap:SegmentReportingDisclosureTextBlock

[0001564590-19-017942:notes:166]
[same as prior period, unchanged from 0001564590-18-028539:notes:177]

[0001564590-19-017942:notes:167]
The reportable segments shown below are the Company’s segments for which separate financial information is available and upon which operating results are evaluated by the chief operating decision maker to assess performance and to allocate resources. The Company has two reportable segments: PCB and E-M Solutions. The PCB reportable segment is comprised of multiple operating segments. Factors considered to determine whether operating segments can be aggregated into reportable segments included similarity regarding economic characteristics, products, production processes, type or classes of customers, distribution methods, and regulatory environments.

[0001564590-19-017942:notes:168]
[same as prior period, unchanged from 0001564590-18-028539:notes:179]

[0001564590-19-017942:notes:169]
|  |  | Quarter Ended |  |
|  |  | April 1, 2019 |  |  | April 2, 2018 |  |
|  |  | (In thousands) |  |
| Net Sales: |  |  |  |  |  |  |  |  |
| PCB (1) |  | $ | 568,822 |  |  | $ | 616,431 |  |
| E-M Solutions |  |  | 51,378 |  |  |  | 47,151 |  |
| Total net sales |  | $ | 620,200 |  |  | $ | 663,582 |  |
| Operating Segment Income (Loss): |  |  |  |  |  |  |  |  |
| PCB (1) |  | $ | 58,542 |  |  | $ | 63,464 |  |
| E-M Solutions |  |  | 1,179 |  |  |  | 40 |  |
| Corporate |  |  | (24,226 | ) |  |  | (27,642 | ) |
| Total operating segment income |  |  | 35,495 |  |  |  | 35,862 |  |
| Amortization of definite-lived intangibles (2) |  |  | (18,005 | ) |  |  | (5,861 | ) |
| Total operating income |  |  | 17,490 |  |  |  | 30,001 |  |
| Total other expense |  |  | (22,218 | ) |  |  | (14,854 | ) |
| (Loss) income before income taxes |  | $ | (4,728 | ) |  | $ | 15,147 |  |

[0001564590-19-017942:notes:170]
| (1) | Figures for the quarter ended April 2, 2018 do not include Anaren, as the acquisition occurred on April 18, 2018. |

[0001564590-19-017942:notes:171]
| (2) | Amortization of definite-lived intangibles primarily relates to the PCB reportable segment. For the quarter ended April 1, 2019, $1,179 of amortization expense is included in cost of goods sold. |

[0001564590-19-017942:notes:172]
The Corporate category primarily includes operating expenses that are not included in the segment operating performance measures. Corporate consists primarily of corporate governance functions such as finance, accounting, information technology, facilities and human resources personnel, as well as global sales and marketing personnel, research and development costs, acquisition and integration costs associated with acquisitions. Bank fees and legal, accounting, and other professional service costs associated with the acquisition of Anaren of $203 and $3,973 for the quarters ended April 1, 2019 and April 2, 2018, respectively, are included in Corporate (see Note 3).


## us-gaap:RelatedPartyTransactionsDisclosureTextBlock

[0001564590-19-017942:notes:173]
(18) Related Party Transactions

[0001564590-19-017942:notes:174]
In the normal course of business, the Company’s foreign subsidiaries purchase laminate and prepreg from related parties in which a member of the Board of Directors of the Company holds an equity interest. The Company’s foreign subsidiaries purchased laminate and prepreg from these related parties in the amount of $8,312 and $12,708 for the quarters ended April 1, 2019 and April 2, 2018, respectively.

[0001564590-19-017942:notes:175]
As of April 1, 2019 and December 31, 2018, the Company’s consolidated condensed balance sheets included $10,260 and $10,630, respectively, in accounts payable due to related parties for purchases of laminate and prepreg and such balances are included as a component of accounts payable on the consolidated condensed balance sheets.
