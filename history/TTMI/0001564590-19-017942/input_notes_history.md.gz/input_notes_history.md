# TTMI note change history — 0001564590-18-028539 → 0001564590-19-017942


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2019-05-09):
[0001564590-19-017942:note_history:1]
The Company is subject to various legal matters, which it considers normal for its business activities. While the Company currently believes that the amount of any reasonably possible loss for known matters would not be material to the Company’s financial condition, the outcome of these actions is inherently difficult to predict. In the event of an adverse outcome, the ultimate potential loss could have a material adverse effect on the Company’s financial condition or results of operations in a particular period. The Company has accrued amounts for its loss contingencies which are probable and estimable as of April 1, 2019 and December 31, 2018. However, these amounts are not material to the consolidated condensed financial statements of the Company.
  (was, 2018-11-08, similarity 0.982):
[0001564590-18-028539:note_history:1]
The Company is subject to various legal matters, which it considers normal for its business activities. While the Company currently believes that the amount of any reasonably possible loss for known matters would not be material to the Company’s financial condition, the outcome of these actions is inherently difficult to predict. In the event of an adverse outcome, the ultimate potential loss could have a material adverse effect on the Company’s financial condition or results of operations in a particular period. The Company has accrued amounts for its loss contingencies which are probable and estimable as of October 1, 2018 and January 1, 2018. However, these amounts are not material to the consolidated condensed financial statements of the Company.

- removed (2019-05-09):
[0001564590-18-028539:note_history:2]
Environmental Matters

- removed (2019-05-09):
[0001564590-18-028539:note_history:3]
The process to manufacture PCBs requires adherence to city, county, state, federal regulations as well as foreign environmental regulations regarding the storage, use, handling and disposal of chemicals, solid wastes and other hazardous materials, as well as compliance with air quality standards and chemical use reporting. The Company believes that its facilities in the United States and Canada comply in all material respects with applicable environmental laws and regulations. In China, governmental authorities have adopted new rules and regulations governing environmental issues. An update to the Chinese environmental waste water law was issued in late 2012, allowing for an interim period in which plants subject to such law may install equipment that meets the new regulatory regime. Some of the Company’s plants in China are not yet in full compliance with the updated environmental regulations. The Company has established and enacted an investment plan related to the efforts to come into full compliance with the new regulations. The 2018 capital expenditure costs expected for these plans are included in the Company’s capital expenditure projections.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureAndSignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: title_similarity, score: 0.7692

- changed (2019-05-09):
[0001564590-19-017942:note_history:4]
(1) Nature of Operations and Summary of Significant Accounting Policies
  (was, 2018-11-08, similarity 0.7863):
[0001564590-18-028539:note_history:4]
(2) Summary of Significant Accounting Policies

- added (2019-05-09):
[0001564590-19-017942:note_history:5]
TTM Technologies, Inc. (the Company or TTM) is a leading global printed circuit board (PCB) manufacturer, focusing on quick-turn and volume production of technologically complex PCBs, backplane assemblies and electro-mechanical solutions (E-M Solutions) as well as a global designer and manufacturer of radio-frequency (RF) and microwave components and assemblies. The Company provides time-to-market and volume production of advanced technology products and offers a one-stop design, engineering and manufacturing solution to customers from engineering support to prototype development through final mass production. This one-stop design and manufacturing solution enables the Company to align technology developments with the diverse needs of the Company’s customers and to enable them to reduce the time required to develop new products and bring them to market.

- added (2019-05-09):
[0001564590-19-017942:note_history:6]
The Company serves a diversified customer base in various markets throughout the world, including aerospace and defense, automotive components, smartphones and touchscreen tablets, high-end computing, medical, industrial and instrumentation related products, as well as networking/communications infrastructure products. The Company’s customers include both original equipment manufacturers (OEMs) and electronic manufacturing services (EMS) providers.

- added (2019-05-09):
[0001564590-19-017942:note_history:7]
The accompanying consolidated condensed financial statements have been prepared by the Company, without audit, pursuant to the rules and regulations of the Securities and Exchange Commission (SEC). Certain information and disclosures normally included in financial statements prepared in accordance with accounting principles generally accepted in the United States of America (U.S. GAAP) have been condensed or omitted pursuant to such rules and regulations. These consolidated condensed financial statements reflect all adjustments (consisting only of normal recurring adjustments) which, in the opinion of management, are necessary to present fairly the financial position, the results of operations and cash flows of the Company for the periods presented. It is suggested that these consolidated condensed financial statements be read in conjunction with the consolidated financial statements and the notes thereto included in the Company’s most recent Annual Report on Form 10-K. The results of operations for the interim periods are not necessarily indicative of the results to be expected for the full year. The preparation of financial statements in accordance with U.S. GAAP requires management to make estimates and assumptions that affect the amounts reported in the Company’s consolidated condensed financial statements and accompanying notes. Actual results could differ materially from those estimates. The Company uses a 13-week fiscal quarter accounting period with the fourth quarter ending on the Monday nearest December 31.

- added (2019-05-09):
[0001564590-19-017942:note_history:8]
Reclassifications

- added (2019-05-09):
[0001564590-19-017942:note_history:9]
Certain amounts in the prior period consolidated condensed financial statement have been reclassified to conform to the presentation of the current period consolidated condensed financial statement. These reclassifications had no effect on the previously reported net income. An adjustment has been made to combine the statutory surplus reserve with retained earnings on the consolidated condensed balance sheet and the consolidated statement of stockholders’ equity.

- added (2019-05-09):
[0001564590-19-017942:note_history:10]
Summary of Significant Accounting Policies

- added (2019-05-09):
[0001564590-19-017942:note_history:11]
Leases

- added (2019-05-09):
[0001564590-19-017942:note_history:12]
The Company determines if an arrangement is a lease at inception. Operating leases are included in operating lease right-of-use (ROU) assets, other current liabilities, and operating lease liabilities on the consolidated condensed balance sheets.

- added (2019-05-09):
[0001564590-19-017942:note_history:13]
ROU assets represent the Company’s right to use an underlying asset for the lease term and lease liabilities represent the Company’s obligation to make lease payments arising from the lease. Operating lease ROU assets and liabilities are recognized at commencement date based on the present value of lease payments over the lease term. As most of the Company’s leases do not provide an implicit rate, the Company uses incremental borrowing rate based on the information available at commencement date in determining the present value of lease payments. The operating lease ROU asset also includes any lease payments made and excludes lease incentives. Lease terms may include options to extend or terminate the lease when it is reasonably certain that the Company will exercise that option. Lease expense for lease payments is recognized on a straight-line basis over the lease term.

- added (2019-05-09):
[0001564590-19-017942:note_history:14]
The Company has lease agreements with lease and non-lease components and accounts for the lease and non-lease components as a single lease component.

- added (2019-05-09):
[0001564590-19-017942:note_history:15]
Recently Adopted and Issued Accounting Standards

- added (2019-05-09):
[0001564590-19-017942:note_history:16]
Recently Adopted Accounting Standards

- added (2019-05-09):
[0001564590-19-017942:note_history:17]
In February 2016, the Financial Accounting Standards Board (FASB) issued ASU 2016-02, Leases (Topic 842) which supersedes the existing lease recognition requirements in the current accounting standard for leases. The core principal of the new standard is that an entity should recognize ROU assets and lease liabilities arising from a lease for both financing and operating leases, along with additional qualitative and quantitative disclosures.

- added (2019-05-09):
[0001564590-19-017942:note_history:18]
In July 2018, the FASB issued ASU 2018-11, Leases (Topic 842): Targeted Improvements. ASU 2018-11 provides additional guidance to Topic 842 including providing preparers an additional optional retrospective adoption method which allows entities to initially apply the new leases standard at the adoption date and recognize a cumulative effect adjustment to the opening balance of retained earnings. ASU 2018-11 also provides lessors a practical expedient to not separate lease from non-lease components, in certain situations.

- added (2019-05-09):
[0001564590-19-017942:note_history:19]
The Company adopted the new lease standard as of January 1, 2019 and utilized the retrospective cumulative effect adjustment transition method with a cumulative effect adjustment being recorded as of the adoption date. Therefore, comparative information has not been adjusted and continues to be reported under previous U.S. GAAP guidance for the consolidated balance sheet at December 31, 2018 and the consolidated condensed statement of operations for the quarter ended April 2, 2018. The Company implemented internal controls and key system functionality to enable the preparation of financial information on adoption. The Company elected certain available practical expedients including the package of practical expedients permitted under the transition guidance within the new standard, which among other things, allowed the Company to carry forward the historical lease classification. Additionally, the Company elected an accounting policy to not record ROU assets and lease liabilities for leases with an initial term of twelve months or less on its consolidated condensed balance sheet.

- added (2019-05-09):
[0001564590-19-017942:note_history:20]
The cumulative effect of the changes made to the Company’s January 1, 2019 consolidated condensed balance sheet for the adoption of the new lease standard was as follows:

- added (2019-05-09):
[0001564590-19-017942:note_history:21]
|  |  | Balance at December 31, 2018 |  |  | New Lease Standard Adjustment |  |  | Balance at January 1, 2019 |  |
|  |  | (In thousands) |  |
| Balance Sheet |  |  |  |  |  |  |  |  |  |  |  |  |
| Assets |  |  |  |  |  |  |  |  |  |  |  |  |
| Operating lease right-of-use assets |  | $ | — |  |  | $ | 16,894 |  |  | $ | 16,894 |  |
| Deposits and other non-current assets |  |  | 55,597 |  |  |  | (548 | ) |  |  | 55,049 |  |
| Liabilities |  |  |  |  |  |  |  |  |  |  |  |  |
| Other current liabilities |  |  | 113,756 |  |  |  | 2,545 |  |  |  | 116,301 |  |
| Operating lease liabilities |  |  | — |  |  |  | 14,356 |  |  |  | 14,356 |  |
| Other long-term liabilities |  |  | 94,777 |  |  |  | (555 | ) |  |  | 94,222 |  |

- added (2019-05-09):
[0001564590-19-017942:note_history:22]
The adoption of the new accounting guidance did not have a material impact to the consolidated condensed statement of operations or the consolidated condensed statement of cash flows for the quarter ended April 1, 2019. See Note 4 for further details.

- added (2019-05-09):
[0001564590-19-017942:note_history:23]
In June 2018, the FASB issued ASU 2018-07, Compensation-Stock Compensation (Topic 718): Improvements to Nonemployee Share-based Payments. This ASU expands the scope of Topic 718 to include share-based payment transactions for acquiring goods and services from nonemployees. The effective date for the standard is for interim periods in fiscal years beginning after December 15, 2018, with early adoption permitted, but no earlier than the Company's adoption date of Topic 606. The new guidance is required to be applied retrospectively with the cumulative effect recognized at the date of initial application. The Company adopted ASU 2018-07 on January 1, 2019. The adoption did not have a material impact on the consolidated condensed financial statements or related disclosures.

- added (2019-05-09):
[0001564590-19-017942:note_history:24]
In August 2017, the FASB issued ASU 2017-12, Derivatives and Hedging (Topic 815): Targeted Improvements to Accounting for Hedging Activities. This ASU amends and simplifies existing guidance in order to allow companies to more accurately present the economic effects of risk management activities in the financial statements. ASU 2017-12 also amends the guidance surrounding the recognition of the value of hedged instruments to include the entire change in value, rather than just the effective portion, in other comprehensive income and recognized in earnings at the same time that the hedged item affects earnings for cash flow and net investment hedges. This ASU is effective for fiscal years beginning after December 15, 2018, including interim periods within those fiscal years. Early adoption is permitted. The Company adopted ASU 2017-12 on January 1, 2019. The adoption did not have a material impact on the consolidated condensed financial statements or related disclosures.

- added (2019-05-09):
[0001564590-19-017942:note_history:25]
Recently Issued Accounting Standards Not Yet Adopted

- added (2019-05-09):
[0001564590-19-017942:note_history:26]
In August 2018, the FASB issued ASU 2018-14, Compensation—Retirement Benefits—Defined Benefit Plans—General (Subtopic 715-20)—Disclosure Framework—Changes to the Disclosure Requirements for Defined Benefit Plans. The amendments in this update change the disclosure requirements for employers that sponsor defined benefit pension and/or other postretirement benefit plans. It eliminates requirements for certain disclosures that are no longer considered cost beneficial and requires new disclosures that the FASB considers pertinent. The guidance is effective for fiscal years ending after December 15, 2020. Early adoption is permitted. The Company does not anticipate the adoption will have a material impact on the consolidated condensed financial statements and related disclosures.

- removed (2019-05-09):
[0001564590-18-028539:note_history:27]
Revenue Recognition

- removed (2019-05-09):
[0001564590-18-028539:note_history:28]
The Company derives revenues primarily from the sale of PCBs, custom electronic assemblies using customer-supplied engineering and design plans as well as the design and manufacture of RF and microwave components and assemblies.

- removed (2019-05-09):
[0001564590-18-028539:note_history:29]
For the PCBs and custom electronic assemblies, orders for products generally correspond to the production schedules of the Company’s customers and are supported with firm purchase orders. The Company’s customers have continuous control of the work in progress and finished goods throughout the PCB manufacturing process, as PCBs are built to customer specifications and do not have an alternative use. The customer typically controls the work in progress and finished goods as evidenced either by contractual termination clauses or by the Company’s rights to payment for work performed to date, plus a reasonable profit.  As a result, the Company records revenue in accordance with the “over time” revenue standard as discussed in Note 1 Nature of Operations and Basis of Presentation ─ Recently Adopted and Issued Accounting Standards, beginning in the first quarter of 2018, the Company now recognizes revenue progressively over time based on the extent of progress towards completion of the performance obligation.

- removed (2019-05-09):
[0001564590-18-028539:note_history:30]
The selection of the method to measure progress toward completion requires judgment and is based on the type of PCB or customized electronic assemblies being manufactured. The Company uses the cost-to-cost method as it best depicts the transfer of control to the customer which takes place as we incur costs. Under the cost-to-cost measure of progress, the extent of progress toward completion is measured based on the ratio of costs incurred to date to the total estimated costs at completion of the performance obligation. Revenues are recorded proportionally as costs are incurred.

- removed (2019-05-09):
[0001564590-18-028539:note_history:31]
Additionally, the Company has certain long-term contracts related to its manufacture of components, assemblies, and subsystems which service the aerospace and defense electronics market. These long-term contracts, many of which provide for periodic payments, are recognized over time under the percentage-of completion method. Estimated manufacturing cost-at-completion for these contracts are reviewed on a periodic basis, and adjustments are made periodically to the estimated cost-at-completion, based on actual costs incurred, progress made, and estimates of costs required to complete the contractual requirements. When the estimated manufacturing cost-at-completion exceeds the contract value, the contract is written down to its net realizable value and the loss resulting from the cost overruns are immediately recognized.

- removed (2019-05-09):
[0001564590-18-028539:note_history:32]
Finally, the Company manufactures components, assemblies, and subsystems which service its wireless communications customers. The Company recognizes revenue at a point in time as the customer does not simultaneously receive or consume the benefits provided by the Company’s performance and the asset being manufactured has alternative uses to the Company.

- removed (2019-05-09):
[0001564590-18-028539:note_history:33]
The Company provides customers a limited right of return for defective PCBs including components and subsystems, and assemblies. The Company accrues an estimate for sales returns and allowances progressively over time based on the extent of progress towards completion of the performance obligation using the Company’s judgment based on historical results and anticipated returns.  To the extent actual experience varies from its historical experience, revisions to the sales returns and allowances accrual may be required. Sales returns and allowances are recorded as a reduction of revenue and included as a component of accrued liabilities on the condensed consolidated balance sheet.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock (critical_accounting_estimates) — matched_by: no_current_note, score: 0.0

- removed (2019-05-09):
[0001564590-18-028539:note_history:34]
(1) Nature of Operations and Basis of Presentation

- removed (2019-05-09):
[0001564590-18-028539:note_history:35]
TTM Technologies, Inc. (the Company or TTM) is a leading global printed circuit board (PCB) manufacturer, focusing on quick-turn and volume production of technologically complex PCBs, backplane assemblies and electro-mechanical solutions (E-M Solutions) as well as a global designer and manufacturer of RF and microwave components and assemblies. The Company provides time-to-market and volume production of advanced technology products and offers a one-stop manufacturing solution to customers from engineering support to prototype development through final mass production. This one-stop manufacturing solution enables the Company to align technology developments with the diverse needs of the Company’s customers and to enable them to reduce the time required to develop new products and bring them to market.

- removed (2019-05-09):
[0001564590-18-028539:note_history:36]
The Company serves a diversified customer base in various markets throughout the world, including aerospace and defense, automotive components, smartphones and touchscreen tablets, high-end computing, medical, industrial and instrumentation related products, as well as networking/communications infrastructure products. The Company’s customers include both original equipment manufacturers (OEMs) and electronic manufacturing services (EMS) providers.

- removed (2019-05-09):
[0001564590-18-028539:note_history:37]
The accompanying consolidated condensed financial statements have been prepared by the Company, without audit, pursuant to the rules and regulations of the Securities and Exchange Commission (SEC). Certain information and disclosures normally included in financial statements prepared in accordance with accounting principles generally accepted in the United States of America (U.S. GAAP) have been condensed or omitted pursuant to such rules and regulations. These consolidated condensed financial statements reflect all adjustments (consisting only of normal recurring adjustments) which, in the opinion of management, are necessary to present fairly the financial position, the results of operations and cash flows of the Company for the periods presented. It is suggested that these consolidated condensed financial statements be read in conjunction with the consolidated financial statements and the notes thereto included in the Company’s most recent Annual Report on Form 10-K. The results of operations for the interim periods are not necessarily indicative of the results to be expected for the full year. The preparation of financial statements in accordance with U.S. GAAP requires management to make estimates and assumptions that affect the amounts reported in the Company’s consolidated condensed financial statements and accompanying notes. Actual results could differ materially from those estimates. The Company uses a 13-week fiscal quarter accounting period with the fourth quarter ending on the Monday nearest December 31.

- removed (2019-05-09):
[0001564590-18-028539:note_history:38]
Recently Adopted and Issued Accounting Standards

- removed (2019-05-09):
[0001564590-18-028539:note_history:39]
In May 2014, the Financial Accounting Standards Board (FASB) issued Accounting Standards Update (ASU) 2014-09, Revenue from Contracts with Customers (Topic 606), which replaces most existing revenue recognition guidance in U.S. GAAP, including industry specific requirements, and provides companies with a single revenue recognition model for recognizing revenue of contracts with customers. The core principle of the new revenue standard is that a company should recognize revenue to depict the transfer of promised goods or services to customers in an amount that reflects the consideration to which the company expects to be entitled in exchange for those goods or services.

- removed (2019-05-09):
[0001564590-18-028539:note_history:40]
The Company assessed the new guidance and adopted the new revenue standard on January 2, 2018, which resulted in a change to the timing of revenue recognition for certain of the Company’s revenue streams from “point in time” upon physical delivery to an “over time” model. Additionally, the Company elected the cumulative effect transition method with adjustment to the opening balance of retained earnings at January 2, 2018 for all open contracts as of January 1, 2018. Therefore, comparative information has not been adjusted and continues to be reported under previous U.S. GAAP guidance for the consolidated balance sheet at January 1, 2018 and the consolidated condensed statement of operations for the quarter and three quarters ended October 2, 2017.

- removed (2019-05-09):
[0001564590-18-028539:note_history:41]
The cumulative effect of the changes made to the Company’s January 2, 2018 consolidated condensed balance sheet for the adoption of the new revenue standard was as follows:

- removed (2019-05-09):
[0001564590-18-028539:note_history:42]
|  |  | Balance at January 1, 2018 |  |  | New Revenue Standard Adjustment |  |  | Balance at January 2, 2018 |  |
|  |  | (In thousands) |  |
| Balance Sheet |  |  |  |  |  |  |  |  |  |  |  |  |
| Assets |  |  |  |  |  |  |  |  |  |  |  |  |
| Accounts receivable, net |  | $ | 483,903 |  |  | $ | 8,171 |  |  | $ | 492,074 |  |
| Contract assets |  |  | — |  |  |  | 260,654 |  |  |  | 260,654 |  |
| Inventories |  |  | 294,588 |  |  |  | (223,576 | ) |  |  | 71,012 |  |
| Liabilities |  |  |  |  |  |  |  |  |  |  |  |  |
| Other accrued expenses |  |  | 114,685 |  |  |  | 13,384 |  |  |  | 128,069 |  |
| Other long-term liabilities |  |  | 74,667 |  |  |  | 3,291 |  |  |  | 77,958 |  |
| Equity |  |  |  |  |  |  |  |  |  |  |  |  |
| Retained earnings |  |  | 193,342 |  |  |  | 28,574 |  |  |  | 221,916 |  |

- removed (2019-05-09):
[0001564590-18-028539:note_history:43]
As part of adoption of the new revenue standard, the Company recorded an estimated sales returns and allowance as well as a noncurrent deferred tax liability in the amount of $5,213 and $3,291, respectively, as of January 2, 2018.  Additionally, the Company reclassified its sales returns and allowance balance of $8,171 as of January 1, 2018, from trade accounts receivable to other accrued liabilities. Sales returns and allowances are recorded as a reduction of revenue and a component of accrued liabilities on the condensed consolidated balance sheet.

- removed (2019-05-09):
[0001564590-18-028539:note_history:44]
Additionally, the disclosure below summarizes the impact of the adoption of the new revenue standard on the Company’s consolidated condensed balance sheet as of October 1, 2018, statement of operations for the quarter and three quarters ended October 1, 2018 and statement of cash flows for the three quarters ended October 1, 2018 for which the As Reported reflects the new revenue standard and Balances without New Revenue Standard Adjustment reflects the Company’s replaced revenue recognition policy of “point in time” and upon physical delivery, for certain revenue streams, as appropriate.

- removed (2019-05-09):
[0001564590-18-028539:note_history:45]
|  |  | October 1, 2018 |  |
|  |  | As reported |  |  | Effect of Change Increase (Decrease) |  |  | Balances without New Revenue Standard Adjustment |  |
|  |  | (In thousands) |  |
| Balance Sheet |  |  |  |  |  |  |  |  |  |  |  |  |
| Assets |  |  |  |  |  |  |  |  |  |  |  |  |
| Accounts receivable, net |  | $ | 569,215 |  |  | $ | 8,171 |  |  | $ | 561,044 |  |
| Contract assets |  |  | 296,836 |  |  |  | 288,723 |  |  |  | 8,113 |  |
| Inventories |  |  | 122,232 |  |  |  | (241,839 | ) |  |  | 364,071 |  |
| Liabilities |  |  |  |  |  |  |  |  |  |  |  |  |
| Other accrued expenses |  |  | 112,005 |  |  |  | 13,945 |  |  |  | 98,060 |  |
| Other long-term liabilities |  |  | 100,724 |  |  |  | 3,163 |  |  |  | 97,561 |  |
| Equity |  |  |  |  |  |  |  |  |  |  |  |  |
| Retained earnings |  |  | 343,177 |  |  |  | 37,947 |  |  |  | 305,230 |  |

- removed (2019-05-09):
[0001564590-18-028539:note_history:46]
|  |  | Quarter ended October 1, 2018 |  |  | Three quarters ended October 1, 2018 |  |
|  |  | As reported |  |  | Effect of Change Increase (Decrease) |  |  | Balances without New Revenue Standard Adjustment |  |  | As reported |  |  | Effect of Change Increase |  |  | Balances without New Revenue Standard Adjustment |  |
|  |  | (In thousands) |  |  | (In thousands) |  |
| Net sales |  | $ | 755,837 |  |  | $ | (4,303 | ) |  | $ | 760,140 |  |  | $ | 2,136,306 |  |  | $ | 27,508 |  |  | $ | 2,108,798 |  |
| Cost of goods sold |  |  | 626,253 |  |  |  | (4,056 | ) |  |  | 630,309 |  |  |  | 1,801,904 |  |  |  | 18,263 |  |  |  | 1,783,641 |  |
| Gross profit |  |  | 129,584 |  |  |  | (247 | ) |  |  | 129,831 |  |  |  | 334,402 |  |  |  | 9,245 |  |  |  | 325,157 |  |
| Net income |  |  | 27,001 |  |  |  | (247 | ) |  |  | 27,248 |  |  |  | 121,102 |  |  |  | 9,373 |  |  |  | 111,729 |  |

- removed (2019-05-09):
[0001564590-18-028539:note_history:47]
Included in the Effect of Change Increase (Decrease) columns for the three quarters ended October 1, 2018 are $14,408, $11,375 and $3,033 of net sales, cost of goods sold and gross profit, respectively, related to the opening balance sheet of Anaren Inc. which was acquired on April 18, 2018 (See Note 3), and not to the activity during the three quarters of 2018.

- removed (2019-05-09):
[0001564590-18-028539:note_history:48]
|  |  | Three Quarters ended October 1, 2018 |  |
|  |  | As reported |  |  | Effect of Change Increase (Decrease) |  |  | Balances without New Revenue Standard Adjustment |  |
|  |  | (In thousands) |  |
| Cash flows from operating activities: |  |  |  |  |  |  |  |  |  |  |  |  |
| Net income |  | $ | 121,102 |  |  | $ | 9,373 |  |  | $ | 111,729 |  |
| Adjustments to reconcile net income to net cash used in operating activities: |  |  |  |  |  |  |  |  |  |  |  |  |
| Deferred income taxes |  |  | (64,516 | ) |  |  | (128 | ) |  |  | (64,388 | ) |
| Changes in operating assets and liabilities: |  |  |  |  |  |  |  |  |  |  |  |  |
| Accounts receivable, net |  |  | (44,685 | ) |  |  | — |  |  |  | (44,685 | ) |
| Contract assets |  |  | (12,597 | ) |  |  | (28,069 | ) |  |  | 15,472 |  |
| Inventories |  |  | 5,399 |  |  |  | 18,263 |  |  |  | (12,864 | ) |
| Accrued salaries, wages and benefits and other accrued expenses |  |  | (43,758 | ) |  |  | 561 |  |  |  | (44,319 | ) |

- removed (2019-05-09):
[0001564590-18-028539:note_history:49]
In August 2017, the FASB issued ASU 2017-12, Derivatives and Hedging (Topic 815): Targeted Improvements to Accounting for Hedging Activities. This ASU amends and simplifies existing guidance in order to allow companies to more accurately present the economic effects of risk management activities in the financial statements. ASU 2017-12 also amends the guidance surrounding the recognition of the value of hedged instruments to include the entire change in value, rather than just the effective portion, in other comprehensive income and recognized in earnings at the same time that the hedged item affects earnings for cash flow and net investment hedges. This ASU is effective for fiscal years beginning after December 15, 2018, including interim periods within those fiscal years. Early adoption is permitted. The adoption of this standard is not expected to have a material impact on the consolidated financial statements or related disclosures.

- removed (2019-05-09):
[0001564590-18-028539:note_history:50]
In February 2016, the FASB issued ASU 2016-02, Leases (Topic 842). The objective of this update is to increase transparency and comparability among organizations by recognizing lease assets and lease liabilities on the balance sheet and disclosing key information about leasing arrangements. This ASU is effective for fiscal years beginning after December 15, 2018, including interim periods within those annual periods. The FASB also provided a practical expedient transition method to adopt the new lease requirements by allowing entities to initially apply requirements by recognizing a cumulative-effect adjustment to the opening balance of retained earnings in the period of adoption that would enable the Company to not provide comparative period financial statements. Instead, the Company would apply the transition provisions of the lease standard at its effective date. The Company is planning  on electing the practical expedient transition method as well as the package of practical expedients to not reassess prior conclusions related to contracts containing leases, lease classification and initial direct costs, and is evaluating other practical expedients available under the guidance. The Company expects the impact of adopting this new accounting standard to be material to its consolidated balance sheet, but is still evaluating the impact to its consolidated statement of income.


## ttmi:ScheduleOfComponentsOfInterestExpenseFromConvertibleNotesTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2019-05-09):
[0001564590-19-017942:note_history:51]
The components of interest expense resulting from the Convertible Senior Notes for the quarters ended April 1, 2019 and April 2, 2018 were as follows:
  (was, 2018-11-08, similarity 0.8627):
[0001564590-18-028539:note_history:51]
The components of interest expense resulting from the convertible senior notes for the quarters and three quarters ended October 1, 2018 and October 2, 2017 are as follows:

- added (2019-05-09):
[0001564590-19-017942:note_history:52]
|  |  | Quarter Ended |  |
|  |  | April 1, |  |  | April 2, |  |
|  |  | 2019 |  |  | 2018 |  |
|  |  | (In thousands) |  |
| Contractual coupon interest |  | $ | 1,094 |  |  | $ | 1,094 |  |
| Amortization of debt discount |  | $ | 2,379 |  |  | $ | 2,230 |  |
| Amortization of debt issuance costs |  | $ | 238 |  |  | $ | 224 |  |

- removed (2019-05-09):
[0001564590-18-028539:note_history:53]
|  |  | Quarter Ended |  |  | Three Quarters Ended |  |
|  |  | October 1, |  |  | October 2, |  |  | October 1, |  |  | October 2, |  |
|  |  | 2018 |  |  | 2017 |  |  | 2018 |  |  | 2017 |  |
|  |  | (In thousands) |  |  | (In thousands) |  |
| Contractual coupon interest |  | $ | 1,094 |  |  | $ | 1,094 |  |  | $ | 3,281 |  |  | $ | 3,281 |  |
| Amortization of debt discount |  | $ | 2,303 |  |  | $ | 2,159 |  |  | $ | 6,800 |  |  | $ | 6,376 |  |
| Amortization of debt issuance costs |  | $ | 231 |  |  | $ | 216 |  |  | $ | 682 |  |  | $ | 639 |  |


## ttmi:ScheduleOfUnamortizedDiscountAndDebtIssuanceCostsTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2019-05-09):
[0001564590-19-017942:note_history:54]
As of April 1, 2019 and December 31, 2018, remaining unamortized debt discount and debt issuance costs for the Term Loan Facility, Senior Notes and Convertible Senior Notes are as follows:
  (was, 2018-11-08, similarity 0.9356):
[0001564590-18-028539:note_history:54]
As of October 1, 2018 and January 1, 2018, remaining unamortized debt discount and debt issuance costs for the Term Loan Facility, Senior Notes and Convertible Senior Notes are as follows:

- changed (2019-05-09):
[0001564590-19-017942:note_history:55]
|  |  | As of April 1, 2019 |  |  | As of December 31, 2018 |  |
|  |  | Debt Issuance Costs |  |  | Debt Discount |  |  | Effective Interest Rate |  |  | Debt Issuance Costs |  |  | Debt Discount |  |  | Effective Interest Rate |  |
|  |  | (in thousands) |  |
| Term Loan due September 2024 |  | $ | 7,620 |  |  | $ | 2,305 |  |  | 4.66% |  |  | $ | 8,229 |  |  | $ | 2,489 |  |  | 4.66% |  |
| Senior Notes due October 2025 |  |  | 5,887 |  |  | — |  |  | 5.92% |  |  |  | 6,071 |  |  | — |  |  | 5.92% |  |
| Convertible Senior Notes |  |  | 1,734 |  |  |  | 17,298 |  |  | 6.48% |  |  |  | 1,972 |  |  |  | 19,678 |  |  | 6.48% |  |
|  |  | $ | 15,241 |  |  | $ | 19,603 |  |  |  |  |  |  | $ | 16,272 |  |  | $ | 22,167 |  |  |  |  |  |
  (was, 2018-11-08, similarity 0.9762):
[0001564590-18-028539:note_history:55]
|  |  | As of October 1, 2018 |  |  | As of January 1, 2018 |  |
|  |  | Debt Issuance Costs |  |  | Debt Discount |  |  | Effective Interest Rate |  |  | Debt Issuance Costs |  |  | Debt Discount |  |  | Effective Interest Rate |  |
|  |  | (in thousands) |  |
| Term Loan due September 2024 |  | $ | 9,266 |  |  | $ | 2,804 |  |  | 4.66% |  |  | $ | 2,788 |  |  | $ | 1,691 |  |  | 3.96% |  |
| Senior Notes due October 2025 |  |  | 6,253 |  |  | — |  |  | 5.92% |  |  |  | 6,782 |  |  | — |  |  | 5.92% |  |
| Convertible Senior Notes |  |  | 2,207 |  |  |  | 22,019 |  |  | 6.48% |  |  |  | 2,889 |  |  |  | 28,822 |  |  | 6.48% |  |
|  |  | $ | 17,726 |  |  | $ | 24,823 |  |  |  |  |  |  | $ | 12,459 |  |  | $ | 30,513 |  |  |  |  |  |


## us-gaap:ConvertibleDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2019-05-09):
[0001564590-19-017942:note_history:56]
As of April 1, 2019 and December 31, 2018, the following summarizes the equity components of the Convertible Senior Notes included in additional paid-in capital:
  (was, 2018-11-08, similarity 0.9241):
[0001564590-18-028539:note_history:56]
As of October 1, 2018 and January 1, 2018, the following summarizes the equity components of the convertible senior notes included in additional paid-in capital:

- added (2019-05-09):
[0001564590-19-017942:note_history:57]
|  |  | As of April 1, 2019 |  |  | As of December 31, 2018 |  |
|  |  | Embedded conversion option — Convertible Senior Notes |  |  | Embedded conversion option — Convertible Senior Notes Issuance Costs |  |  | Total |  |  | Embedded conversion option — Convertible Senior Notes |  |  | Embedded conversion option — Convertible Senior Notes Issuance Costs |  |  | Total |  |
|  |  | (in thousands) |  |
| Convertible Senior Notes due 2020 |  | $ | 60,213 |  |  | $ | (1,916 | ) |  | $ | 58,297 |  |  | $ | 60,216 |  |  | $ | (1,916 | ) |  | $ | 58,300 |  |

- removed (2019-05-09):
[0001564590-18-028539:note_history:58]
|  |  | As of October 1, 2018 and January 1, 2018 |  |
|  |  | Embedded conversion option — Convertible Senior Notes |  |  | Embedded conversion option — Convertible Senior Notes Issuance Costs |  |  | Total |  |
|  |  | (in thousands) |  |
| Convertible Senior Notes due 2020 |  | $ | 60,216 |  |  | $ | (1,916 | ) |  | $ | 58,300 |  |


## us-gaap:LongTermDebtTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2019-05-09):
[0001564590-19-017942:note_history:59]
The following table summarizes the long-term debt of the Company as of April 1, 2019 and December 31, 2018:
  (was, 2018-11-08, similarity 0.8832):
[0001564590-18-028539:note_history:59]
The following table summarizes the long-term debt of the Company as of October 1, 2018 and January 1, 2018:

- added (2019-05-09):
[0001564590-19-017942:note_history:60]
|  |  | Interest Rate as of April 1, 2019 |  |  | Principal Outstanding as of April 1, 2019 |  |  | Interest Rate as of December 31, 2018 |  |  | Principal Outstanding as of December 31, 2018 |  |
|  |  | (In thousands) |  |
| Term Loan due September 2024 |  | 4.99% |  |  | $ | 805,879 |  |  | 5.00% |  |  | $ | 835,879 |  |
| Senior Notes due October 2025 |  | 5.63% |  |  |  | 375,000 |  |  | 5.63% |  |  |  | 375,000 |  |
| Convertible Senior Notes due December 2020 |  | 1.75% |  |  |  | 249,975 |  |  | 1.75% |  |  |  | 249,985 |  |
| U.S. ABL Revolving Loan due May 2020 |  | 3.99% |  |  |  | 40,000 |  |  | 4.00% |  |  |  | 40,000 |  |
| Asia ABL Revolving Loan due May 2020 |  | 3.89% |  |  |  | 30,000 |  |  | 3.90% |  |  |  | 30,000 |  |
|  |  |  |  |  |  |  | 1,500,854 |  |  |  |  |  |  |  | 1,530,864 |  |
| Less: Long-term debt unamortized discount |  |  |  |  |  |  | (19,603 | ) |  |  |  |  |  |  | (22,167 | ) |
| Long-term debt unamortized debt issuance costs |  |  |  |  |  |  | (15,241 | ) |  |  |  |  |  |  | (16,272 | ) |
|  |  |  |  |  |  |  | 1,466,010 |  |  |  |  |  |  |  | 1,492,425 |  |
| Less: current maturities |  |  |  |  |  |  | — |  |  |  |  |  |  |  | (30,000 | ) |
| Long-term debt, less current maturities |  |  |  |  |  | $ | 1,466,010 |  |  |  |  |  |  | $ | 1,462,425 |  |

- changed (2019-05-09):
[0001564590-19-017942:note_history:61]
On April 18, 2018, the Company closed its $600,000 commitment of incremental loans concurrent with the completion of its acquisition of Anaren. At issuance, these incremental loans increased the Company’s existing balance of its Term Loan Facility due 2024 from $348,250 to $948,250. The Term Loan Facility had an outstanding balance of $805,879 as of April 1, 2019 and is included in long-term debt. The Term Loan Facility was issued at a weighted average discount of 99.7% and bears interest, at the Company’s option, at a floating rate of LIBOR, plus an applicable interest margin of 2.50%, or an alternate base rate, (defined as the greater of the JP Morgan prime, the New York Fed bank rate plus 0.5% or LIBOR plus 1.0%), subject to a 1.0% floor plus an applicable margin of 1.5%. At April 1, 2019, the interest rate on the outstanding borrowings under the Term Loan Facility was 4.99%. There is no provision, other than an event of default, for the interest margin to increase. The Term Loan Facility will mature on September 28, 2024. The Term Loan Facility is secured by a significant amount of the domestic assets of the Company and a pledge of 65% of voting stock of the Company’s first tier foreign subsidiaries and is structurally senior to the Company’s Senior Notes and Convertible Senior Notes. See Senior Notes and Convertible Senior Notes below.
  (was, 2018-11-08, similarity 0.9674):
[0001564590-18-028539:note_history:61]
On April 18, 2018, the Company closed its $600,000 commitment of incremental loans concurrent with the completion of its acquisition of Anaren. At issuance, these incremental loans increased the Company’s existing balance of its Term Loan Facility due 2024 from $348,250 to $948,250. The Term Loan Facility had an outstanding balance of $905,879 as of October 1, 2018, of which $40,000 is included in short-term debt and $865,879 is included in long-term debt. The Term Loan Facility was issued at a weighted average discount of 99.7% and bears interest, at the Company’s option, at a floating rate of LIBOR, plus an applicable interest margin of 2.50%, or an alternate base rate, (defined as the greater of the JP Morgan prime, the New York Fed bank rate plus 0.5% or LIBOR plus 1.0%), subject to a 1.0% floor plus an applicable margin of 1.5%. At October 1, 2018 the interest rate on the outstanding borrowings under the Term Loan Facility was 4.77%. There is no provision, other than an event of default, for the interest margin to increase. The Term Loan Facility will mature on September 28, 2024. The Term Loan Facility is secured by a significant amount of the domestic assets of the Company and a pledge of 65% of voting stock of the Company’s first tier foreign subsidiaries and is structurally senior to the Company’s Senior Notes and Convertible Senior Notes. See Senior Notes and Convertible Senior Notes below.

- added (2019-05-09):
[0001564590-19-017942:note_history:62]
Based on certain parameters defined in the Term Loan Facility, including a First Lien Leverage Ratio, the Company may be required to make an additional principal payment on an annual basis beginning after fiscal year 2018, if the Company’s First Lien Leverage Ratio is greater than 2.0. For 2019, the Company is not required to make an additional principal payment as its First Lien Leverage Ratio is less than 2.0. Any remaining outstanding balance under the Term Loan Facility is due at the maturity date of September 28, 2024.

- changed (2019-05-09):
[0001564590-19-017942:note_history:63]
The $375,000 of Senior Notes, which is included in long-term debt, bears interest at a rate of 5.63% per annum. Interest is payable semiannually in arrears on April 1 and October 1 of each year beginning April 1, 2018. The Senior Notes will mature on October 1, 2025.
  (was, 2018-11-08, similarity 0.998):
[0001564590-18-028539:note_history:63]
The $375,000 of Senior Notes, which is included in long-term debt, bear interest at a rate of 5.63% per annum. Interest is payable semiannually in arrears on April 1 and October 1 of each year beginning April 1, 2018. The Senior Notes will mature on October 1, 2025.

- changed (2019-05-09):
[0001564590-19-017942:note_history:64]
The Company maintains 1.75% Convertible Senior Notes in the amount of $249,975 due December 15, 2020. The Convertible Senior Notes bear interest at a rate of 1.75% per annum. Interest is payable semiannually in arrears on June 15 and December 15 of each year. The Convertible Senior Notes are unsecured obligations and would rank equally to the Company’s future unsecured senior indebtedness and are senior in right of payment to any of the Company’s future subordinated indebtedness.
  (was, 2018-11-08, similarity 0.986):
[0001564590-18-028539:note_history:64]
The Company maintains 1.75% convertible senior notes in the amount of $249,985 due December 15, 2020. The convertible senior notes bear interest at a rate of 1.75% per annum. Interest is payable semiannually in arrears on June 15 and December 15 of each year. The convertible senior notes are senior unsecured obligations and rank equally to the Company’s future unsecured senior indebtedness and are senior in right of payment to any of the Company’s future subordinated indebtedness.

- changed (2019-05-09):
[0001564590-19-017942:note_history:65]
As of April 1, 2019 and December 31, 2018, the following summarizes the equity components of the Convertible Senior Notes included in additional paid-in capital:
  (was, 2018-11-08, similarity 0.9241):
[0001564590-18-028539:note_history:65]
As of October 1, 2018 and January 1, 2018, the following summarizes the equity components of the convertible senior notes included in additional paid-in capital:

- added (2019-05-09):
[0001564590-19-017942:note_history:66]
|  |  | As of April 1, 2019 |  |  | As of December 31, 2018 |  |
|  |  | Embedded conversion option — Convertible Senior Notes |  |  | Embedded conversion option — Convertible Senior Notes Issuance Costs |  |  | Total |  |  | Embedded conversion option — Convertible Senior Notes |  |  | Embedded conversion option — Convertible Senior Notes Issuance Costs |  |  | Total |  |
|  |  | (in thousands) |  |
| Convertible Senior Notes due 2020 |  | $ | 60,213 |  |  | $ | (1,916 | ) |  | $ | 58,297 |  |  | $ | 60,216 |  |  | $ | (1,916 | ) |  | $ | 58,300 |  |

- changed (2019-05-09):
[0001564590-19-017942:note_history:67]
The components of interest expense resulting from the Convertible Senior Notes for the quarters ended April 1, 2019 and April 2, 2018 were as follows:
  (was, 2018-11-08, similarity 0.8627):
[0001564590-18-028539:note_history:67]
The components of interest expense resulting from the convertible senior notes for the quarters and three quarters ended October 1, 2018 and October 2, 2017 are as follows:

- added (2019-05-09):
[0001564590-19-017942:note_history:68]
|  |  | Quarter Ended |  |
|  |  | April 1, |  |  | April 2, |  |
|  |  | 2019 |  |  | 2018 |  |
|  |  | (In thousands) |  |
| Contractual coupon interest |  | $ | 1,094 |  |  | $ | 1,094 |  |
| Amortization of debt discount |  | $ | 2,379 |  |  | $ | 2,230 |  |
| Amortization of debt issuance costs |  | $ | 238 |  |  | $ | 224 |  |

- changed (2019-05-09):
[0001564590-19-017942:note_history:69]
The U.S. ABL consists of three tranches comprised of a revolving credit facility for up to $200,000, a letter of credit facility for up to $50,000, and swingline loans for up to $30,000, provided that at no time may amounts outstanding under the tranches exceed in aggregate $200,000 or the applicable borrowing base, which is a percentage of the principal amount of Eligible Accounts, as defined in the U.S. ABL agreement. Borrowings under the U.S. ABL bear interest at either a floating rate of LIBOR plus a margin of 150 basis points or JP Morgan Chase Bank’s prime rate plus a margin of 50 basis points, at the Company’s option. At April 1, 2019, the interest rate on the outstanding borrowings under the U.S. ABL was 3.99%. The applicable margin can vary based on the remaining availability of the facility, from 125 to 175 basis points for LIBOR-based loans and from 25 to 75 basis points for JP Morgan Chase Bank’s prime rate-based loans. Other than availability and an event of default, there are no other provisions for the interest margin to increase. The U.S. ABL will mature on May 31, 2020. Loans made under the U.S. ABL are secured first by all of the Company’s domestic cash, receivables and certain inventories as well as by a second position against a significant amount of the domestic assets of the Company and a pledge of 65% of the voting stock of the Company’s first tier foreign subsidiaries and are structurally senior to the Company’s Senior Notes and Convertible Senior Notes. See Senior Notes and Convertible Senior Notes above. As of April 1, 2019, $40,000 of the U.S. ABL was outstanding and classified as long-term debt, which is consistent with its maturity date.
  (was, 2018-11-08, similarity 0.9905):
[0001564590-18-028539:note_history:69]
The U.S. ABL consists of three tranches comprised of a revolving credit facility for up to $200,000, a letter of credit facility for up to $50,000, and swingline loans for up to $30,000, provided that at no time may amounts outstanding under the tranches exceed in aggregate $200,000 or the applicable borrowing base, which is a percentage of the principal amount of Eligible Accounts, as defined in the U.S. ABL agreement. Borrowings under the U.S. ABL bear interest at either a floating rate of LIBOR plus a margin of 150 basis points or JP Morgan Chase Bank’s prime rate plus a margin of 50 basis points, at the Company’s option. At October 1, 2018, the interest rate on the outstanding borrowings under the U.S. ABL was 3.77%. The applicable margin can vary based on the remaining availability of the facility, from 125 to 175 basis points for LIBOR-based loans and from 25 to 75 basis points for JP Morgan Chase Bank’s prime rate-based loans. Other than availability and an event of default, there are no other provisions for the interest margin to increase. The U.S. ABL will mature on May 31, 2020. Loans made under the U.S. ABL are secured first by all of the Company’s domestic cash, receivables and certain inventories as well as by a second position against a significant amount of the domestic assets of the Company and a pledge of 65% of the voting stock of the Company’s first tier foreign subsidiaries and are structurally senior to the Company’s Senior Notes and Convertible Senior Notes. See Senior Notes and Convertible Senior Notes above. At October 1, 2018, $40,000 of the U.S. ABL was outstanding and classified as long-term debt, which is consistent with its maturity date.

- changed (2019-05-09):
[0001564590-19-017942:note_history:70]
The Asia ABL consists of two tranches comprised of a revolving credit facility for up to $150,000 and a letter of credit facility for up to $100,000, provided that at no time may amounts outstanding under both tranches exceed in aggregate $150,000 or the applicable borrowing base, which is a percentage of the principal amount of Eligible Accounts, as defined in the Asia ABL agreement. Borrowings under the Asia ABL bear interest at a floating rate of LIBOR plus 140 basis points. As of April 1, 2019, the interest rate on the outstanding borrowings under the Asia ABL was 3.89%. There is no provision, other than an event of default, for the interest margin to increase. The Asia ABL will mature on May 22, 2020. Loans made under the Asia ABL are secured by a portion of the Company’s Asia Pacific cash and receivables and are structurally senior to the Company’s domestic obligations, including the Senior Notes and Convertible Senior Notes. See Senior Notes and Convertible Senior Notes above. As of April 1, 2019, $30,000 of the Asia ABL was outstanding and classified as long-term debt, which is consistent with its maturity date.
  (was, 2018-11-08, similarity 0.9826):
[0001564590-18-028539:note_history:70]
The Asia ABL consists of two tranches comprised of a revolving credit facility for up to $150,000 and a letter of credit facility for up to $100,000, provided that at no time may amounts outstanding under both tranches exceed in aggregate $150,000 or the applicable borrowing base, which is a percentage of the principal amount of Eligible Accounts, as defined in the Asia ABL agreement. Borrowings under the Asia ABL bear interest at a floating rate of LIBOR plus 140 basis points. At October 1, 2018, the interest rate on the outstanding borrowings under the Asia ABL was 3.67%. There is no provision, other than an event of default, for the interest margin to increase. The Asia ABL will mature on May 22, 2020. Loans made under the Asia ABL are secured by a portion of the Company’s Asia Pacific cash and receivables and are structurally senior to the Company’s domestic obligations, including the Senior Notes and Convertible Senior Notes. See Senior Notes and Convertible Senior Notes above. At October 1, 2018, $30,000 of the Asia ABL was outstanding and classified as long-term debt, which is consistent with its maturity date.

- changed (2019-05-09):
[0001564590-19-017942:note_history:71]
The Company has up to $50,000 and $100,000 Letters of Credit Facilities under the U.S. ABL and the Asia ABL, respectively. As of April 1, 2019, letters of credit in the amount of $13,383 were outstanding under the U.S. ABL and $19,445 were outstanding under the Asia ABL with various expiration dates through September 2019. Available borrowing capacity under the U.S. ABL and the Asia ABL was $146,617 and $100,555, respectively, which considers letters of credit outstanding as of April 1, 2019.
  (was, 2018-11-08, similarity 0.9488):
[0001564590-18-028539:note_history:71]
The Company has up to $50,000 and $100,000 Letters of Credit Facilities under the U.S. ABL and the Asia ABL, respectively. As of October 1, 2018, letters of credit in the amount of $6,701 were outstanding under the U.S. ABL and $9,287 were outstanding under the Asia ABL with various expiration dates through December 2019. Available borrowing capacity under the U.S. ABL and the Asia ABL was $153,299 and $110,713, respectively, which considers letters of credit outstanding at October 1, 2018.

- changed (2019-05-09):
[0001564590-19-017942:note_history:72]
The Company is required to pay a commitment fee of 0.25% to 0.375% per annum on any unused portion of the U.S. ABL or Asia ABL. The Company incurred total commitment fees related to unused borrowing availability of $240 and $241 for the quarters ended April 1, 2019 and April 2, 2018, respectively. Under the occurrence of certain events, the ABL Revolving Loans are subject to various financial and operational covenants, including maintaining minimum fixed charge coverage ratios.
  (was, 2018-11-08, similarity 0.8746):
[0001564590-18-028539:note_history:72]
The Company is required to pay a commitment fee of 0.25% to 0.375% per annum on any unused portion of the U.S. ABL or Asia ABL. The Company incurred total commitment fees related to unused borrowing availability of $251 and $179 for the quarters ended October 1, 2018 and October 2, 2017, respectively, and $739 and $546 for the three quarters ended October 1, 2018 and October 2, 2017, respectively. Under the occurrence of certain events, the ABL Revolving Loans are subject to various financial and operational covenants, including maintaining minimum fixed charge coverage ratios.

- changed (2019-05-09):
[0001564590-19-017942:note_history:73]
Additionally, the Company is party to a revolving loan credit facility (Chinese Revolver) with a lender in China. Under this arrangement, the lender has made available to the Company approximately $31,286 in unsecured borrowing with all terms of the borrowing to be negotiated at the time the Chinese Revolver is drawn upon. There are no commitment fees on the unused portion of the Chinese Revolver, and this arrangement expires in June 2019. As of April 1, 2019, the Chinese Revolver had not been drawn upon.
  (was, 2018-11-08, similarity 0.9789):
[0001564590-18-028539:note_history:73]
Additionally, the Company is party to a revolving loan credit facility (Chinese Revolver) with a lender in China. Under this arrangement, the lender has made available to the Company approximately $30,600 in unsecured borrowing with all terms of the borrowing to be negotiated at the time the Chinese Revolver is drawn upon. There are no commitment fees on the unused portion of the Chinese Revolver, and this arrangement expires in January 2019. As of October 1, 2018, the Chinese Revolver had not been drawn upon.

- changed (2019-05-09):
[0001564590-19-017942:note_history:74]
As of April 1, 2019 and December 31, 2018, remaining unamortized debt discount and debt issuance costs for the Term Loan Facility, Senior Notes and Convertible Senior Notes are as follows:
  (was, 2018-11-08, similarity 0.9356):
[0001564590-18-028539:note_history:74]
As of October 1, 2018 and January 1, 2018, remaining unamortized debt discount and debt issuance costs for the Term Loan Facility, Senior Notes and Convertible Senior Notes are as follows:

- changed (2019-05-09):
[0001564590-19-017942:note_history:75]
|  |  | As of April 1, 2019 |  |  | As of December 31, 2018 |  |
|  |  | Debt Issuance Costs |  |  | Debt Discount |  |  | Effective Interest Rate |  |  | Debt Issuance Costs |  |  | Debt Discount |  |  | Effective Interest Rate |  |
|  |  | (in thousands) |  |
| Term Loan due September 2024 |  | $ | 7,620 |  |  | $ | 2,305 |  |  | 4.66% |  |  | $ | 8,229 |  |  | $ | 2,489 |  |  | 4.66% |  |
| Senior Notes due October 2025 |  |  | 5,887 |  |  | — |  |  | 5.92% |  |  |  | 6,071 |  |  | — |  |  | 5.92% |  |
| Convertible Senior Notes |  |  | 1,734 |  |  |  | 17,298 |  |  | 6.48% |  |  |  | 1,972 |  |  |  | 19,678 |  |  | 6.48% |  |
|  |  | $ | 15,241 |  |  | $ | 19,603 |  |  |  |  |  |  | $ | 16,272 |  |  | $ | 22,167 |  |  |  |  |  |
  (was, 2018-11-08, similarity 0.9762):
[0001564590-18-028539:note_history:75]
|  |  | As of October 1, 2018 |  |  | As of January 1, 2018 |  |
|  |  | Debt Issuance Costs |  |  | Debt Discount |  |  | Effective Interest Rate |  |  | Debt Issuance Costs |  |  | Debt Discount |  |  | Effective Interest Rate |  |
|  |  | (in thousands) |  |
| Term Loan due September 2024 |  | $ | 9,266 |  |  | $ | 2,804 |  |  | 4.66% |  |  | $ | 2,788 |  |  | $ | 1,691 |  |  | 3.96% |  |
| Senior Notes due October 2025 |  |  | 6,253 |  |  | — |  |  | 5.92% |  |  |  | 6,782 |  |  | — |  |  | 5.92% |  |
| Convertible Senior Notes |  |  | 2,207 |  |  |  | 22,019 |  |  | 6.48% |  |  |  | 2,889 |  |  |  | 28,822 |  |  | 6.48% |  |
|  |  | $ | 17,726 |  |  | $ | 24,823 |  |  |  |  |  |  | $ | 12,459 |  |  | $ | 30,513 |  |  |  |  |  |

- changed (2019-05-09):
[0001564590-19-017942:note_history:76]
Remaining unamortized debt issuance costs for the ABL Revolving Loans of $1,170 and $1,420 as of April 1, 2019 and December 31, 2018, respectively, are included in other non-current assets and are amortized to interest expense over the duration of the ABL Revolving Loans using the straight line method of amortization.
  (was, 2018-11-08, similarity 0.9353):
[0001564590-18-028539:note_history:76]
Remaining unamortized debt issuance costs for the ABL Revolving Loans of $1,670 and $2,421 as of October 1, 2018 and January 1, 2018, respectively, are included in other non-current assets and are amortized to interest expense over the duration of the ABL Revolving Loans using the straight line method of amortization.

- changed (2019-05-09):
[0001564590-19-017942:note_history:77]
At April 1, 2019, the remaining weighted average amortization period for all unamortized debt discount and debt issuance costs was 3.5 years.
  (was, 2018-11-08, similarity 0.963):
[0001564590-18-028539:note_history:77]
At October 1, 2018, the remaining weighted average amortization period for all unamortized debt discount and debt issuance costs was 3.9 years.

- removed (2019-05-09):
[0001564590-18-028539:note_history:78]
|  |  | Interest Rate as of October 1, 2018 |  |  | Principal Outstanding as of October 1, 2018 |  |  | Interest Rate as of January 1, 2018 |  |  | Principal Outstanding as of January 1, 2018 |  |
|  |  | (In thousands) |  |
| Term Loan due September 2024 |  | 4.77% |  |  | $ | 905,879 |  |  | 4.06% |  |  | $ | 349,125 |  |
| Senior Notes due October 2025 |  | 5.63% |  |  |  | 375,000 |  |  | 5.63% |  |  |  | 375,000 |  |
| Convertible Senior Notes due December 2020 |  | 1.75% |  |  |  | 249,985 |  |  | 1.75% |  |  |  | 249,985 |  |
| U.S. ABL Revolving Loan due May 2020 |  | 3.77% |  |  |  | 40,000 |  |  | 3.06% |  |  |  | 17,000 |  |
| Asia ABL Revolving Loan due May 2020 |  | 3.67% |  |  |  | 30,000 |  |  | 2.96% |  |  |  | 30,000 |  |
| Capital Lease |  |  | — |  |  |  | — |  |  | 6.43% |  |  |  | 1,919 |  |
|  |  |  |  |  |  |  | 1,600,864 |  |  |  |  |  |  |  | 1,023,029 |  |
| Less: Long-term debt unamortized discount |  |  |  |  |  |  | (24,823 | ) |  |  |  |  |  |  | (30,513 | ) |
| Long-term debt unamortized debt issuance costs |  |  |  |  |  |  | (17,726 | ) |  |  |  |  |  |  | (12,459 | ) |
|  |  |  |  |  |  |  | 1,558,315 |  |  |  |  |  |  |  | 980,057 |  |
| Less: current maturities |  |  |  |  |  |  | (40,000 | ) |  |  |  |  |  |  | (4,578 | ) |
| Long-term debt, less current maturities |  |  |  |  |  | $ | 1,518,315 |  |  |  |  |  |  | $ | 975,479 |  |

- removed (2019-05-09):
[0001564590-18-028539:note_history:79]
Subsequent to October 1, 2018, the Company made an optional debt principal prepayment of $40,000. As a result of the principal prepayments, the Company is no longer required to make any quarterly scheduled payments. However, based on certain parameters defined in the Term Loan Facility, including a First Lien Leverage Ratio, the Company may be required to make an additional principal payment on an annual basis beginning after fiscal year 2018. Any remaining outstanding balance under the Term Loan Facility is due at the maturity date of September 28, 2024.

- removed (2019-05-09):
[0001564590-18-028539:note_history:80]
|  |  | As of October 1, 2018 and January 1, 2018 |  |
|  |  | Embedded conversion option — Convertible Senior Notes |  |  | Embedded conversion option — Convertible Senior Notes Issuance Costs |  |  | Total |  |
|  |  | (in thousands) |  |
| Convertible Senior Notes due 2020 |  | $ | 60,216 |  |  | $ | (1,916 | ) |  | $ | 58,300 |  |

- removed (2019-05-09):
[0001564590-18-028539:note_history:81]
|  |  | Quarter Ended |  |  | Three Quarters Ended |  |
|  |  | October 1, |  |  | October 2, |  |  | October 1, |  |  | October 2, |  |
|  |  | 2018 |  |  | 2017 |  |  | 2018 |  |  | 2017 |  |
|  |  | (In thousands) |  |  | (In thousands) |  |
| Contractual coupon interest |  | $ | 1,094 |  |  | $ | 1,094 |  |  | $ | 3,281 |  |  | $ | 3,281 |  |
| Amortization of debt discount |  | $ | 2,303 |  |  | $ | 2,159 |  |  | $ | 6,800 |  |  | $ | 6,376 |  |
| Amortization of debt issuance costs |  | $ | 231 |  |  | $ | 216 |  |  | $ | 682 |  |  | $ | 639 |  |

- removed (2019-05-09):
[0001564590-18-028539:note_history:82]
Loss on Extinguishment of Debt

- removed (2019-05-09):
[0001564590-18-028539:note_history:83]
During the quarter ended October 2, 2017, the Company recognized loss on extinguishment of debt of $768, primarily associated with the write off of the remaining unamortized debt issuance and debt discount for the 2016 Term Loan.


## us-gaap:ScheduleOfDebtInstrumentsTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2019-05-09):
[0001564590-19-017942:note_history:84]
The following table summarizes the long-term debt of the Company as of April 1, 2019 and December 31, 2018:
  (was, 2018-11-08, similarity 0.8832):
[0001564590-18-028539:note_history:84]
The following table summarizes the long-term debt of the Company as of October 1, 2018 and January 1, 2018:

- added (2019-05-09):
[0001564590-19-017942:note_history:85]
|  |  | Interest Rate as of April 1, 2019 |  |  | Principal Outstanding as of April 1, 2019 |  |  | Interest Rate as of December 31, 2018 |  |  | Principal Outstanding as of December 31, 2018 |  |
|  |  | (In thousands) |  |
| Term Loan due September 2024 |  | 4.99% |  |  | $ | 805,879 |  |  | 5.00% |  |  | $ | 835,879 |  |
| Senior Notes due October 2025 |  | 5.63% |  |  |  | 375,000 |  |  | 5.63% |  |  |  | 375,000 |  |
| Convertible Senior Notes due December 2020 |  | 1.75% |  |  |  | 249,975 |  |  | 1.75% |  |  |  | 249,985 |  |
| U.S. ABL Revolving Loan due May 2020 |  | 3.99% |  |  |  | 40,000 |  |  | 4.00% |  |  |  | 40,000 |  |
| Asia ABL Revolving Loan due May 2020 |  | 3.89% |  |  |  | 30,000 |  |  | 3.90% |  |  |  | 30,000 |  |
|  |  |  |  |  |  |  | 1,500,854 |  |  |  |  |  |  |  | 1,530,864 |  |
| Less: Long-term debt unamortized discount |  |  |  |  |  |  | (19,603 | ) |  |  |  |  |  |  | (22,167 | ) |
| Long-term debt unamortized debt issuance costs |  |  |  |  |  |  | (15,241 | ) |  |  |  |  |  |  | (16,272 | ) |
|  |  |  |  |  |  |  | 1,466,010 |  |  |  |  |  |  |  | 1,492,425 |  |
| Less: current maturities |  |  |  |  |  |  | — |  |  |  |  |  |  |  | (30,000 | ) |
| Long-term debt, less current maturities |  |  |  |  |  | $ | 1,466,010 |  |  |  |  |  |  | $ | 1,462,425 |  |

- removed (2019-05-09):
[0001564590-18-028539:note_history:86]
|  |  | Interest Rate as of October 1, 2018 |  |  | Principal Outstanding as of October 1, 2018 |  |  | Interest Rate as of January 1, 2018 |  |  | Principal Outstanding as of January 1, 2018 |  |
|  |  | (In thousands) |  |
| Term Loan due September 2024 |  | 4.77% |  |  | $ | 905,879 |  |  | 4.06% |  |  | $ | 349,125 |  |
| Senior Notes due October 2025 |  | 5.63% |  |  |  | 375,000 |  |  | 5.63% |  |  |  | 375,000 |  |
| Convertible Senior Notes due December 2020 |  | 1.75% |  |  |  | 249,985 |  |  | 1.75% |  |  |  | 249,985 |  |
| U.S. ABL Revolving Loan due May 2020 |  | 3.77% |  |  |  | 40,000 |  |  | 3.06% |  |  |  | 17,000 |  |
| Asia ABL Revolving Loan due May 2020 |  | 3.67% |  |  |  | 30,000 |  |  | 2.96% |  |  |  | 30,000 |  |
| Capital Lease |  |  | — |  |  |  | — |  |  | 6.43% |  |  |  | 1,919 |  |
|  |  |  |  |  |  |  | 1,600,864 |  |  |  |  |  |  |  | 1,023,029 |  |
| Less: Long-term debt unamortized discount |  |  |  |  |  |  | (24,823 | ) |  |  |  |  |  |  | (30,513 | ) |
| Long-term debt unamortized debt issuance costs |  |  |  |  |  |  | (17,726 | ) |  |  |  |  |  |  | (12,459 | ) |
|  |  |  |  |  |  |  | 1,558,315 |  |  |  |  |  |  |  | 980,057 |  |
| Less: current maturities |  |  |  |  |  |  | (40,000 | ) |  |  |  |  |  |  | (4,578 | ) |
| Long-term debt, less current maturities |  |  |  |  |  | $ | 1,518,315 |  |  |  |  |  |  | $ | 975,479 |  |


## us-gaap:RelatedPartyTransactionsDisclosureTextBlock (related_parties) — matched_by: tag_name, score: 1.0

- changed (2019-05-09):
[0001564590-19-017942:note_history:87]
In the normal course of business, the Company’s foreign subsidiaries purchase laminate and prepreg from related parties in which a member of the Board of Directors of the Company holds an equity interest. The Company’s foreign subsidiaries purchased laminate and prepreg from these related parties in the amount of $8,312 and $12,708 for the quarters ended April 1, 2019 and April 2, 2018, respectively.
  (was, 2018-11-08, similarity 0.8522):
[0001564590-18-028539:note_history:87]
In the normal course of business, the Company’s foreign subsidiaries purchase laminate and prepreg from related parties in which a member of the Board of Directors of the Company holds an equity interest. The Company’s foreign subsidiaries purchased laminate and prepreg from these related parties in the amount of $10,437 and $13,225 for the quarters ended October 1, 2018 and October 2, 2017, respectively, and $35,695 and $38,886 for the three quarters ended October 1, 2018 and October 2, 2017, respectively.

- added (2019-05-09):
[0001564590-19-017942:note_history:88]
As of April 1, 2019 and December 31, 2018, the Company’s consolidated condensed balance sheets included $10,260 and $10,630, respectively, in accounts payable due to related parties for purchases of laminate and prepreg and such balances are included as a component of accounts payable on the consolidated condensed balance sheets.

- removed (2019-05-09):
[0001564590-18-028539:note_history:89]
As of October 1, 2018 and January 1, 2018, the Company’s consolidated condensed balance sheets included $10,745 and $14,452, respectively, in accounts payable due to related parties primarily for purchases of laminate and prepreg and such balances are included as a component of accounts payable on the consolidated condensed balance sheets.


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: no_prior_note, score: 0.0

- added (2019-05-09):
[0001564590-19-017942:note_history:90]
The following tables represent a disaggregation of revenue by principal end markets with the reportable segments:

- added (2019-05-09):
[0001564590-19-017942:note_history:91]
|  |  | Quarter ended April 1, 2019 |  |
|  |  | PCB |  |  | E-M Solutions |  |  | Total |  |
| End Markets |  | (In thousands) |  |
| Aerospace and Defense |  | $ | 165,068 |  |  | $ | 4 |  |  | $ | 165,072 |  |
| Automotive |  |  | 85,813 |  |  |  | 19,765 |  |  |  | 105,578 |  |
| Cellular Phone |  |  | 43,084 |  |  |  | — |  |  |  | 43,084 |  |
| Computing/Storage/Peripherals |  |  | 80,892 |  |  |  | 189 |  |  |  | 81,081 |  |
| Medical/Industrial/Instrumentation |  |  | 87,670 |  |  |  | 8,167 |  |  |  | 95,837 |  |
| Networking/Communications |  |  | 88,063 |  |  |  | 23,339 |  |  |  | 111,402 |  |
| Other |  |  | 18,232 |  |  |  | (86 | ) |  |  | 18,146 |  |
| Total |  | $ | 568,822 |  |  | $ | 51,378 |  |  | $ | 620,200 |  |

- added (2019-05-09):
[0001564590-19-017942:note_history:92]
|  |  | Quarter ended April 2, 2018 |  |
|  |  | PCB |  |  | E-M Solutions |  |  | Total |  |
| End Markets |  | (In thousands) |  |
| Aerospace and Defense |  | $ | 122,676 |  |  | $ | 89 |  |  | $ | 122,765 |  |
| Automotive |  |  | 116,292 |  |  |  | 19,310 |  |  |  | 135,602 |  |
| Cellular Phone |  |  | 104,860 |  |  |  | — |  |  |  | 104,860 |  |
| Computing/Storage/Peripherals |  |  | 88,542 |  |  |  | 305 |  |  |  | 88,847 |  |
| Medical/Industrial/Instrumentation |  |  | 93,634 |  |  |  | 7,523 |  |  |  | 101,157 |  |
| Networking/Communications |  |  | 81,937 |  |  |  | 19,473 |  |  |  | 101,410 |  |
| Other |  |  | 8,490 |  |  |  | 451 |  |  |  | 8,941 |  |
| Total |  | $ | 616,431 |  |  | $ | 47,151 |  |  | $ | 663,582 |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: no_prior_note, score: 0.0

- added (2019-05-09):
[0001564590-19-017942:note_history:93]
(2) Revenues

- added (2019-05-09):
[0001564590-19-017942:note_history:94]
As of April 1, 2019, the aggregate amount of the transaction price allocated to remaining performance obligations for long-term contracts was $20,601. The Company expects to recognize revenue on approximately 85% of the remaining performance obligations for the Company’s long-term contracts over the next twelve months with the remaining amount recognized thereafter. The remaining performance obligations for the Company’s short-term contracts are expected to be recognized within one year or less.

- added (2019-05-09):
[0001564590-19-017942:note_history:95]
Revenue from products and services transferred to customers over time and at a point in time accounted for 97% and 3%, respectively of the Company’s revenue for the quarter ended April 1, 2019.

- added (2019-05-09):
[0001564590-19-017942:note_history:96]
The following tables represent a disaggregation of revenue by principal end markets with the reportable segments:

- added (2019-05-09):
[0001564590-19-017942:note_history:97]
|  |  | Quarter ended April 1, 2019 |  |
|  |  | PCB |  |  | E-M Solutions |  |  | Total |  |
| End Markets |  | (In thousands) |  |
| Aerospace and Defense |  | $ | 165,068 |  |  | $ | 4 |  |  | $ | 165,072 |  |
| Automotive |  |  | 85,813 |  |  |  | 19,765 |  |  |  | 105,578 |  |
| Cellular Phone |  |  | 43,084 |  |  |  | — |  |  |  | 43,084 |  |
| Computing/Storage/Peripherals |  |  | 80,892 |  |  |  | 189 |  |  |  | 81,081 |  |
| Medical/Industrial/Instrumentation |  |  | 87,670 |  |  |  | 8,167 |  |  |  | 95,837 |  |
| Networking/Communications |  |  | 88,063 |  |  |  | 23,339 |  |  |  | 111,402 |  |
| Other |  |  | 18,232 |  |  |  | (86 | ) |  |  | 18,146 |  |
| Total |  | $ | 568,822 |  |  | $ | 51,378 |  |  | $ | 620,200 |  |

- added (2019-05-09):
[0001564590-19-017942:note_history:98]
|  |  | Quarter ended April 2, 2018 |  |
|  |  | PCB |  |  | E-M Solutions |  |  | Total |  |
| End Markets |  | (In thousands) |  |
| Aerospace and Defense |  | $ | 122,676 |  |  | $ | 89 |  |  | $ | 122,765 |  |
| Automotive |  |  | 116,292 |  |  |  | 19,310 |  |  |  | 135,602 |  |
| Cellular Phone |  |  | 104,860 |  |  |  | — |  |  |  | 104,860 |  |
| Computing/Storage/Peripherals |  |  | 88,542 |  |  |  | 305 |  |  |  | 88,847 |  |
| Medical/Industrial/Instrumentation |  |  | 93,634 |  |  |  | 7,523 |  |  |  | 101,157 |  |
| Networking/Communications |  |  | 81,937 |  |  |  | 19,473 |  |  |  | 101,410 |  |
| Other |  |  | 8,490 |  |  |  | 451 |  |  |  | 8,941 |  |
| Total |  | $ | 616,431 |  |  | $ | 47,151 |  |  | $ | 663,582 |  |


## us-gaap:RevenueRecognitionPolicyTextBlock (revenue_recognition_policy) — matched_by: no_current_note, score: 0.0

- removed (2019-05-09):
[0001564590-18-028539:note_history:99]
Revenue Recognition

- removed (2019-05-09):
[0001564590-18-028539:note_history:100]
The Company derives revenues primarily from the sale of PCBs, custom electronic assemblies using customer-supplied engineering and design plans as well as the design and manufacture of RF and microwave components and assemblies.

- removed (2019-05-09):
[0001564590-18-028539:note_history:101]
For the PCBs and custom electronic assemblies, orders for products generally correspond to the production schedules of the Company’s customers and are supported with firm purchase orders. The Company’s customers have continuous control of the work in progress and finished goods throughout the PCB manufacturing process, as PCBs are built to customer specifications and do not have an alternative use. The customer typically controls the work in progress and finished goods as evidenced either by contractual termination clauses or by the Company’s rights to payment for work performed to date, plus a reasonable profit.  As a result, the Company records revenue in accordance with the “over time” revenue standard as discussed in Note 1 Nature of Operations and Basis of Presentation ─ Recently Adopted and Issued Accounting Standards, beginning in the first quarter of 2018, the Company now recognizes revenue progressively over time based on the extent of progress towards completion of the performance obligation.

- removed (2019-05-09):
[0001564590-18-028539:note_history:102]
The selection of the method to measure progress toward completion requires judgment and is based on the type of PCB or customized electronic assemblies being manufactured. The Company uses the cost-to-cost method as it best depicts the transfer of control to the customer which takes place as we incur costs. Under the cost-to-cost measure of progress, the extent of progress toward completion is measured based on the ratio of costs incurred to date to the total estimated costs at completion of the performance obligation. Revenues are recorded proportionally as costs are incurred.

- removed (2019-05-09):
[0001564590-18-028539:note_history:103]
Additionally, the Company has certain long-term contracts related to its manufacture of components, assemblies, and subsystems which service the aerospace and defense electronics market. These long-term contracts, many of which provide for periodic payments, are recognized over time under the percentage-of completion method. Estimated manufacturing cost-at-completion for these contracts are reviewed on a periodic basis, and adjustments are made periodically to the estimated cost-at-completion, based on actual costs incurred, progress made, and estimates of costs required to complete the contractual requirements. When the estimated manufacturing cost-at-completion exceeds the contract value, the contract is written down to its net realizable value and the loss resulting from the cost overruns are immediately recognized.

- removed (2019-05-09):
[0001564590-18-028539:note_history:104]
Finally, the Company manufactures components, assemblies, and subsystems which service its wireless communications customers. The Company recognizes revenue at a point in time as the customer does not simultaneously receive or consume the benefits provided by the Company’s performance and the asset being manufactured has alternative uses to the Company.

- removed (2019-05-09):
[0001564590-18-028539:note_history:105]
The Company provides customers a limited right of return for defective PCBs including components and subsystems, and assemblies. The Company accrues an estimate for sales returns and allowances progressively over time based on the extent of progress towards completion of the performance obligation using the Company’s judgment based on historical results and anticipated returns.  To the extent actual experience varies from its historical experience, revisions to the sales returns and allowances accrual may be required. Sales returns and allowances are recorded as a reduction of revenue and included as a component of accrued liabilities on the condensed consolidated balance sheet.
