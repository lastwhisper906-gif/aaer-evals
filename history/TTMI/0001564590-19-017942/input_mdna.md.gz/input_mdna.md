# TTMI MD&A — 0001564590-19-017942


## mdna

[0001564590-19-017942:mdna:1]
[same as prior period, unchanged from 0001564590-18-028539:mdna:1]

[0001564590-19-017942:mdna:2]
[same as prior period, unchanged from 0001564590-18-028539:mdna:2]

[0001564590-19-017942:mdna:3]
We are a leading global printed circuit board (PCB) manufacturer, focusing on quick-turn and volume production of technologically complex PCBs, backplane assemblies and electro-mechanical solutions (E-M Solutions), as well as a global designer and manufacturer of radio-frequency (RF) and microwave components and assemblies. We focus on providing time-to-market and volume production of advanced technology products and offer a one-stop design, engineering and manufacturing solution to our customers from engineering support to prototype development through final mass production. This one-stop design, engineering and manufacturing solution allows us to align technology development with the diverse needs of our customers and to enable them to reduce the time required to develop new products and bring them to market. We serve a diversified customer base consisting of approximately 2,200 customers in various markets throughout the world, including aerospace and defense, automotive components, smartphones and touchscreen tablets, high-end computing, medical, industrial and instrumentation related products, as well as networking/communications infrastructure products. Our customers include both original equipment manufacturers (OEMs) and electronic manufacturing services (EMS) providers.

[0001564590-19-017942:mdna:4]
[same as prior period, unchanged from 0001564590-18-028539:mdna:7]

[0001564590-19-017942:mdna:5]
While our customers include both OEMs and EMS providers, we measure customers based on OEM companies, as they are the ultimate end customers. Sales to our ten largest customers accounted for 47% and 45% of our net sales for the quarters ended April 1, 2019 and April 2, 2018, respectively. We sell to OEMs both directly and indirectly through EMS providers.

[0001564590-19-017942:mdna:6]
[same as prior period, unchanged from 0001564590-18-028539:mdna:9]

[0001564590-19-017942:mdna:7]
|  |  | Quarter Ended |  |  |
| End Markets (1) |  | April 1, 2019 (3) |  |  |  | April 2, 2018 |  |  |
| Aerospace and Defense |  |  | 27 |  | % |  |  | 19 |  | % |
| Automotive |  |  | 17 |  |  |  |  | 21 |  |  |
| Cellular Phone (2) |  |  | 7 |  |  |  |  | 16 |  |  |
| Computing/Storage/Peripherals (2) |  |  | 13 |  |  |  |  | 13 |  |  |
| Medical/Industrial/Instrumentation |  |  | 15 |  |  |  |  | 15 |  |  |
| Networking/Communications |  |  | 18 |  |  |  |  | 15 |  |  |
| Other |  |  | 3 |  |  |  |  | 1 |  |  |
| Total |  |  | 100 |  | % |  |  | 100 |  | % |

[0001564590-19-017942:mdna:8]
[same as prior period, unchanged from 0001564590-18-028539:mdna:11]

[0001564590-19-017942:mdna:9]
[same as prior period, unchanged from 0001564590-18-028539:mdna:12]

[0001564590-19-017942:mdna:10]
| (3) | Amounts include activity of Anaren since acquisition which occurred on April 18, 2018. |

[0001564590-19-017942:mdna:11]
We derive revenues primarily from the sale of PCBs, custom electronic assemblies using customer-supplied engineering and design plans as well as the design and manufacture of RF and microwave components and assemblies. Most orders for products generally correspond to the production schedules of our customers and are supported with firm purchase orders. Most of our customers have continuous control of the work in progress and finished goods throughout the PCB manufacturing process, as PCBs are built to customer specifications with no alternative use, and there is an enforceable right to payment for work performed to date. As a result, we recognize revenue progressively over time based on the extent of progress towards completion of the performance obligation. We recognize revenue under these contracts based on the cost-to-cost method as it best depicts the transfer of control to the customer which takes place as we incur costs. Under the cost-to-cost measure of progress, the extent of progress toward completion is measured based on the ratio of costs incurred to date to the total estimated costs at completion of the performance obligation. Revenues are recorded proportionally as costs are incurred.

[0001564590-19-017942:mdna:12]
Additionally, we have certain long-term contracts related to the manufacture of components, assemblies, and subsystems which service the aerospace and defense electronics market. These long-term contracts, many of which provide for periodic payments, are recognized over time under the percentage-of completion method. Estimated manufacturing cost-at-completion for these contracts are reviewed on a periodic basis, and adjustments are made as needed to the estimated cost-at-completion, based on actual costs incurred, progress made, and estimates of costs required to complete the contractual requirements. When the estimated manufacturing cost-at-completion exceeds the contract value, the contract is written down to its net realizable value and the loss resulting from the cost overruns are immediately recognized.

[0001564590-19-017942:mdna:13]
We also manufacture certain components, assemblies, and subsystems which service our wireless communications customers. We recognize revenue at a point in time upon transfer of control of the products to our customer. Point in time recognition was determined as our customers do not simultaneously receive or consume the benefits provided by our performance and the asset being manufactured has alternative uses to us.

[0001564590-19-017942:mdna:14]
Net sales consist of gross sales less an allowance for returns, which typically have been approximately 2% of gross sales. We provide our customers a limited right of return for defective PCBs including components, subsystems and assemblies. We record an estimate for sales returns and allowances at the time of sale based on historical results and anticipated returns.

[0001564590-19-017942:mdna:15]
[same as prior period, unchanged from 0001564590-18-028539:mdna:19]

[0001564590-19-017942:mdna:16]
[same as prior period, unchanged from 0001564590-18-028539:mdna:20]

[0001564590-19-017942:mdna:17]
[same as prior period, unchanged from 0001564590-18-028539:mdna:21]

[0001564590-19-017942:mdna:18]
[same as prior period, unchanged from 0001564590-18-028539:mdna:22]

[0001564590-19-017942:mdna:19]
Our consolidated condensed financial statements included in this report have been prepared in accordance with accounting principles generally accepted in the United States of America (U.S. GAAP). The preparation of these financial statements requires management to make estimates and assumptions that affect the reported amounts of assets, liabilities, net sales and expenses, and related disclosure of contingent assets and liabilities.

[0001564590-19-017942:mdna:20]
See Item 7, Management’s Discussion and Analysis of Financial Condition and Results of Operations, in our Annual Report on Form 10-K for the fiscal year ended December 31, 2018 for further discussion of critical accounting policies and estimates. There were no material changes to our critical accounting policies and estimates since December 31, 2018.

[0001564590-19-017942:mdna:21]
[same as prior period, unchanged from 0001564590-18-028539:mdna:26]

[0001564590-19-017942:mdna:22]
The results of operations for the quarter ended April 2, 2018 do not include the results of operations from our acquisition of Anaren, as the acquisition occurred on April 18, 2018. The following table sets forth the relationship of various items to net sales in our consolidated condensed statements of operations:

[0001564590-19-017942:mdna:23]
|  |  | Quarter Ended |  |  |
|  |  | April 1, 2019 |  |  |  | April 2, 2018 |  |  |
| Net sales |  |  | 100.0 |  | % |  |  | 100.0 |  | % |
| Cost of goods sold |  |  | 85.7 |  |  |  |  | 86.6 |  |  |
| Gross profit |  |  | 14.3 |  |  |  |  | 13.4 |  |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |
| Selling and marketing |  |  | 3.0 |  |  |  |  | 2.7 |  |  |
| General and administrative |  |  | 5.7 |  |  |  |  | 5.3 |  |  |
| Amortization of definite-lived intangibles |  |  | 2.7 |  |  |  |  | 0.9 |  |  |
| Total operating expenses |  |  | 11.4 |  |  |  |  | 8.9 |  |  |
| Operating income |  |  | 2.9 |  |  |  |  | 4.5 |  |  |
| Other income (expense): |  |  |  |  |  |  |  |  |  |  |
| Interest expense |  |  | (3.5 | ) |  |  |  | (2.1 | ) |  |
| Other, net |  |  | (0.1 | ) |  |  |  | (0.1 | ) |  |
| Total other expense, net |  |  | (3.6 | ) |  |  |  | (2.2 | ) |  |
| (Loss) income before income taxes |  |  | (0.7 | ) |  |  |  | 2.3 |  |  |
| Income tax benefit (provision) |  |  | 0.3 |  |  |  |  | (0.8 | ) |  |
| Net (loss) income |  |  | (0.4 | ) | % |  |  | 1.5 |  | % |

[0001564590-19-017942:mdna:24]
We have two reportable segments: PCB and E-M Solutions. The PCB reportable segment is comprised of multiple operating segments. Factors considered in determining whether operating segments can be aggregated into reportable segments included similarity regarding economic characteristics, products, production process, type or class of customers, distribution methods and regulatory environments.

[0001564590-19-017942:mdna:25]
[same as prior period, unchanged from 0001564590-18-028539:mdna:33]

[0001564590-19-017942:mdna:26]
Total net sales decreased $43.4 million, or 6.5%, to $620.2 million for the first quarter of 2019 from $663.6 million for the first quarter of 2018. This decrease resulted from a reduction in net sales for the PCB reportable segment of $47.6 million, or 7.7%, to $568.8 million for the first quarter of 2019 from $616.4 million for the first quarter of 2018. The reduction in PCB net sales was primarily due to lower demand in the Cellular Phone and Automotive end markets, partially offset by an increase in our Aerospace and Defense and Networking/Communications end markets primarily attributable to the acquisition of Anaren. These changes resulted in an average PCB selling price increase of 11.6%, driven mainly by product mix shift and a 21.2% decrease in the volume of PCB shipments as compared to the first quarter of 2018. The reduction in PCB net sales was partially offset by an increase in net sales for the E-M Solutions reportable segment of $4.2 million, or 8.9%, to $51.4 million for the first quarter of 2019 from $47.2 million for the first quarter of 2018. The increase was primarily due to higher demand in our Networking/Communications end market.

[0001564590-19-017942:mdna:27]
[same as prior period, unchanged from 0001564590-18-028539:mdna:37]

[0001564590-19-017942:mdna:28]
Overall gross margin increased to 14.3% for the first quarter of 2019 from 13.4% for the first quarter of 2018 as a result of increased gross margin in both the PCB and E-M Solutions reportable segments. Gross margin for the PCB reportable segment increased to 15.5% for the first quarter of 2019 from 14.3% for the first quarter of 2018 primarily due to the acquisition of Anaren and higher production levels at our Aerospace and Defense focused facilities partially offset by lower utilization in our Cellular Phone facilities. Gross margin for the E-M Solutions reportable segment increased to 6.3% for the first quarter of 2019 from 5.5% for the first quarter of 2018 primarily due to higher volume.

[0001564590-19-017942:mdna:29]
Capacity utilization is a key driver for us, particularly in our high volume facilities in Asia, as a significant portion of our operating costs are fixed in nature. Capacity utilization for the first quarter of 2019 in our Asia and North America PCB facilities was 55.4% and 60.3%, respectively, compared to 78.2% and 61.2%, respectively, in the first quarter of 2018. The significant decline in the utilization of our facilities in Asia was due to the softness we experienced in the first quarter in the Cellular Phone and Automotive end markets.

[0001564590-19-017942:mdna:30]
27

[0001564590-19-017942:mdna:31]
[same as prior period, unchanged from 0001564590-18-028539:mdna:41]

[0001564590-19-017942:mdna:32]
Selling and marketing expenses increased $1.3 million, to $18.9 million for the first quarter of 2019 from $17.6 million for the first quarter of 2018. As a percentage of net sales, selling and marketing expenses was 3.0% for the first quarter of 2019, as compared to 2.7% for the first quarter of 2018. The increase in selling and marketing expense for the quarter ended April 1, 2019 primarily relates to expenses incurred by Anaren post acquisition.

[0001564590-19-017942:mdna:33]
[same as prior period, unchanged from 0001564590-18-028539:mdna:43]

[0001564590-19-017942:mdna:34]
General and administrative expenses increased $0.3 million to $35.5 million, or 5.7% of net sales, for the first quarter of 2019 from $35.2 million, or 5.3% of net sales, for the first quarter of 2018. The increase in expense was primarily due to the acquisition of Anaren partially offset by a $3.3 million decrease in acquisition-related costs.

[0001564590-19-017942:mdna:35]
[same as prior period, unchanged from 0001564590-18-028539:mdna:45]

[0001564590-19-017942:mdna:36]
Other expense, net increased $7.3 million to $22.2 million for the first quarter of 2019 from $14.9 million for the first quarter of 2018. The increase in other expense, net for the quarter ended April 1, 2019 was primarily due to the increase in interest expense of $7.9 million mainly related to the $600.0 million incremental debt incurred in conjunction with the Anaren acquisition.

[0001564590-19-017942:mdna:37]
[same as prior period, unchanged from 0001564590-18-028539:mdna:48]

[0001564590-19-017942:mdna:38]
The provision for income taxes decreased $6.6 million to $1.5 million tax benefit for the first quarter of 2019 from $5.1 million tax expense for the first quarter of 2018. The decrease in income tax expense for the first quarter of 2019 was primarily due to decreased operating income and the retroactive approval of the Company’s renewal application for High and New Tax Enterprise status for two of the Company’s manufacturing subsidiaries in China.

[0001564590-19-017942:mdna:39]
Our effective tax rate is primarily impacted by tax rates in China and Hong Kong, the U.S. federal income tax rate, apportioned state income tax rates, generation of other credits and deductions available to us, as well as changes in valuation allowances, and certain non-deductible items. We had a net deferred income tax asset of approximately $14.9 million and $13.7 million as of April 1, 2019 and December 31, 2018, respectively.

[0001564590-19-017942:mdna:40]
[same as prior period, unchanged from 0001564590-18-028539:mdna:60]

[0001564590-19-017942:mdna:41]
Our principal sources of liquidity have been cash provided by operations, the issuance of convertible senior notes, term debt, senior notes, and revolving debt. Our principal uses of cash have been to finance capital expenditures, finance acquisitions, meet debt service requirements, fund working capital requirements, and refinance existing debt. We anticipate that servicing debt, financing capital expenditures, financing acquisitions, and funding working capital requirements will continue to be the principal demands on our cash in the future.

[0001564590-19-017942:mdna:42]
Cash flow provided by operating activities during the first quarter of 2019 was $36.9 million as compared to cash flow used in operating activities of $14.3 million in the same period in 2018. The increase in cash flow was primarily due to lower investment in working capital in the first quarter of 2019 as compared to the first quarter of 2018. As of April 1, 2019, we had net working capital of approximately $561.8 million compared to $533.7 million as of December 31, 2018.

[0001564590-19-017942:mdna:43]
Net cash used in investing activities was approximately $28.4 million for the first quarter of 2019 reflecting $33.5 million for purchases of property, plant and equipment less proceeds from sale of property, plant and equipment and other assets of $5.0 million. Net cash used in investing activities was approximately $42.1 million for the first quarter of 2018 reflecting purchases of property, plant and equipment.

[0001564590-19-017942:mdna:44]
Net cash used in financing activities was approximately $30.0 million for the first quarter of 2019, reflecting repayment of long-term debt of $30.0 million. Net cash used in financing activities was approximately $0.9 million for the first quarter of 2018, reflecting repayment of long-term debt.

[0001564590-19-017942:mdna:45]
As of April 1, 2019, we had cash and cash equivalents of approximately $235.2 million, of which approximately $209.9 million was held by our foreign subsidiaries, primarily in China.

[0001564590-19-017942:mdna:46]
Our 2019 net capital expenditures are expected to be in the range of $130.0 million to $150.0 million.

[0001564590-19-017942:mdna:47]
[same as prior period, unchanged from 0001564590-18-028539:mdna:67]

[0001564590-19-017942:mdna:48]
[same as prior period, unchanged from 0001564590-18-028539:mdna:68]

[0001564590-19-017942:mdna:49]
On April 18, 2018, we closed our $600.0 million commitment of incremental loans concurrent with the completion of our acquisition of Anaren. At issuance, these incremental loans increased the existing balance of our Term Loan Facility due 2024 from $348.3 million to $948.3 million. The Term Loan Facility had an outstanding balance of $805.9 million as of April 1, 2019 and is included in long-term debt. The Term Loan Facility was issued at a weighted average discount of 99.7% and bears interest, at our option, at a floating rate of LIBOR, plus an applicable interest margin of 2.50%, or an alternate base rate, (defined as the greater of the JP Morgan prime, the New York Fed bank rate plus 0.5% or LIBOR plus 1%), subject to a 1% floor plus an applicable margin of 1.5%. At April 1, 2019, the interest rate on the outstanding borrowings under the Term Loan Facility was 4.99%. There is no provision, other than an event of default, for the interest margin to increase. The Term Loan Facility will mature on September 28, 2024. The Term Loan Facility is secured by a significant amount of our domestic assets and a pledge of 65% of voting stock of our first tier foreign subsidiaries and is structurally senior to our Senior Notes and Convertible Senior Notes. See Senior Notes and Convertible Senior Notes below.

[0001564590-19-017942:mdna:50]
Based on certain parameters defined in the Term Loan Facility, including a First Lien Leverage Ratio, we may be required to make an additional principal payment on an annual basis beginning after fiscal year 2018, if our First Lien Leverage Ratio is greater than 2.0. For 2019, we are not required to make an additional principal payment as our First Lien Leverage Ratio was less than 2.0. Any remaining outstanding balance under the Term Loan Facility is due at the maturity date of September 28, 2024.

[0001564590-19-017942:mdna:51]
Borrowings under the Term Loan Facility are subject to certain affirmative and negative covenants, including limitations on indebtedness, corporate transactions, investments and dispositions, and share payments. At April 1, 2019, we were in compliance with the covenants under the Term Loan Facility.

[0001564590-19-017942:mdna:52]
[same as prior period, unchanged from 0001564590-18-028539:mdna:72]

[0001564590-19-017942:mdna:53]
The $375.0 million of Senior Notes, which is included in long-term debt, bears interest at a rate of 5.63% per annum. Interest is payable semiannually in arrears on April 1 and October 1 of each year beginning April 1, 2018. The Senior Notes will mature on October 1, 2025.

[0001564590-19-017942:mdna:54]
Borrowings under the Senior Notes are subject to certain affirmative and negative covenants, including limitations on indebtedness, corporate transactions, investments, dispositions, and share payments. At April 1, 2019, we were in compliance with the covenants under the Senior Notes.

[0001564590-19-017942:mdna:55]
Convertible Senior Notes due 2020

[0001564590-19-017942:mdna:56]
We maintain 1.75% Convertible Senior Notes in the amount of $250.0 million due December 15, 2020. The Convertible Senior Notes bear interest at a rate of 1.75% per annum. Interest is payable semiannually in arrears on June 15 and December 15 of each year. The Convertible Senior Notes are senior unsecured obligations and rank equally to our future unsecured senior indebtedness and senior in right of payment to any of our future subordinated indebtedness. Offering expenses are being amortized to interest expense over the term of the Convertible Senior Notes.

[0001564590-19-017942:mdna:57]
[same as prior period, unchanged from 0001564590-18-028539:mdna:77]

[0001564590-19-017942:mdna:58]
[same as prior period, unchanged from 0001564590-18-028539:mdna:78]

[0001564590-19-017942:mdna:59]
The U.S. ABL consists of three tranches comprised of a revolving credit facility of up to $200.0 million, a letter of credit facility for up to $50.0 million, and swingline loans for up to $30.0 million, provided that at no time may amounts outstanding under the tranches exceed in aggregate $200.0 million or the applicable borrowing base, which is a percentage of the principal amount of Eligible Accounts, as defined in the U.S. ABL agreement. Borrowings under the U.S. ABL bear interest at either a floating rate of LIBOR plus a margin of 150 basis points or JP Morgan Chase Bank’s prime rate plus a margin of 50 basis points, at our option. At April 1, 2019, the interest rate on the outstanding borrowings under the U.S. ABL was 3.99%. The applicable margin can vary based on the remaining availability of the facility, from 125 to 175 basis points for LIBOR-based loans and from 25 to 75 basis points for JP Morgan Chase Bank’s prime rate-based loans. Other than availability and an event of default, there are no other provisions for the interest margin to increase. The U.S. ABL will mature on May 31, 2020. Loans made under the U.S. ABL are secured first by all of our domestic cash, receivables and certain inventories as well as by a second position against a significant amount of our domestic assets and a pledge of 65% of the voting stock of our first tier foreign subsidiaries and are structurally senior to our Senior Notes and Convertible Senior Notes. See Senior Notes and Convertible Senior Notes above. As of April 1, 2019, $40.0 million of the U.S. ABL was outstanding and classified as long-term debt, which is consistent with its maturity date.

[0001564590-19-017942:mdna:60]
The Asia ABL consists of two tranches comprised of a revolving credit facility for up to $150.0 million and a letter of credit facility for up to $100.0 million, provided that at no time may amounts outstanding under both tranches exceed in aggregate $150.0 million or the applicable borrowing base, which is a percentage of the principal amount of Eligible Accounts, as defined in the Asia ABL agreement. Borrowings under the Asia ABL bear interest at a floating rate of LIBOR plus 140 basis points. As of April 1, 2019, the interest rate on the outstanding borrowings under the Asia ABL was 3.89%. There is no provision, other than an event of default, for the interest margin to increase. The Asia ABL will mature on May 22, 2020. Loans made under the Asia ABL are secured by a portion of our Asia Pacific cash and receivables and are structurally senior to our domestic obligations, including the Senior Notes and Convertible Senior Notes. See Senior Notes and Convertible Senior above. As of April 1, 2019, $30.0 million of the Asia ABL was outstanding and classified as long-term debt, which is consistent with its maturity date.

[0001564590-19-017942:mdna:61]
We have up to $50.0 million and $100.0 million Letters of Credit Facilities under the U.S. ABL and the Asia ABL, respectively. As of April 1, 2019, letters of credit in the amount of $13.4 million were outstanding under the U.S. ABL and $19.4 million were outstanding under the Asia ABL with various expiration dates through September 2019. Available borrowing capacity under the U.S. ABL and the Asia ABL was $146.6 million and $100.6 million, respectively, which considers letters of credit outstanding as of April 1, 2019.

[0001564590-19-017942:mdna:62]
We are required to pay a commitment fee of 0.25% to 0.375% per annum on any unused portion of the ABL Revolving Loans. We paid commitment fees of $0.2 million for the quarters ended April 1, 2019 and April 2, 2018. Under the occurrence of certain events, the ABL Revolving Loans are subject to various financial and operational covenants, including maintaining minimum fixed charge coverage ratios. At April 1, 2019, we were in compliance with the covenants under the ABL Revolving Loans.

[0001564590-19-017942:mdna:63]
Other Credit Facility

[0001564590-19-017942:mdna:64]
Additionally, we are party to a revolving loan credit facility (Chinese Revolver) with a lender in China. Under this arrangement, the lender has made available to us approximately $31.3 million in unsecured borrowing with all terms of the borrowing to be negotiated at the time the Chinese Revolver is drawn upon. There are no commitment fees on the unused portion of the Chinese Revolver, and this arrangement expires in June 2019. As of April 1, 2019, the Chinese Revolver had not been drawn upon.

[0001564590-19-017942:mdna:65]
Based on our current level of operations, we believe that cash generated from operations, cash on hand and cash from the issuance of term and revolving debt will be adequate to meet our currently anticipated capital expenditure, debt service, and working capital needs for the next twelve months.

[0001564590-19-017942:mdna:66]
[same as prior period, unchanged from 0001564590-18-028539:mdna:87]

[0001564590-19-017942:mdna:67]
As of the date of this report, other than changes related to adoption of the new lease accounting standard as discussed in Note 1 to the consolidated condensed financial statements, there were no material changes to our contractual obligations and commitments outside the ordinary course of business since December 31, 2018 as reported in our 2018 Form 10-K.

[0001564590-19-017942:mdna:68]
[same as prior period, unchanged from 0001564590-18-028539:mdna:91]

[0001564590-19-017942:mdna:69]
We do not have any relationships with unconsolidated entities or financial partnerships, such as entities often referred to as structured finance or special purpose entities, which would have been established for the purpose of facilitating off-balance sheet arrangements or other contractually narrow or limited purposes. In addition, we do not engage in trading activities involving non-exchange traded contracts. As a result, we are not materially exposed to any financing, liquidity, market, or credit risk that could arise if we had engaged in these relationships.

[0001564590-19-017942:mdna:70]
[same as prior period, unchanged from 0001564590-18-028539:mdna:93]

[0001564590-19-017942:mdna:71]
[same as prior period, unchanged from 0001564590-18-028539:mdna:94]
