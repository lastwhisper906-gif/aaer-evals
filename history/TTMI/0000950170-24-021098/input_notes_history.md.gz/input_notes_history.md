# TTMI note change history — 0000950170-23-041297 → 0000950170-23-060227


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2023-11-07):
[0000950170-23-060227:note_history:1]
The Company is subject to various legal matters, which it considers normal for its business activities. While the Company currently believes that the amount of any reasonably possible loss for known matters would not be material to the Company’s financial condition, the outcome of these actions is inherently difficult to predict. In the event of an adverse outcome, the ultimate potential loss could have a material adverse effect on the Company’s financial condition or results of operations in a particular period. The Company has accrued amounts for its loss contingencies which are probable and estimable as of October 2, 2023 and January 2, 2023 and included as a component of other current liabilities. However, these amounts are not material to the consolidated condensed financial statements of the Company.
  (was, 2023-08-10, similarity 0.9932):
[0000950170-23-041297:note_history:1]
The Company is subject to various legal matters, which it considers normal for its business activities. While the Company currently believes that the amount of any reasonably possible loss for known matters would not be material to the Company’s financial condition, the outcome of these actions is inherently difficult to predict. In the event of an adverse outcome, the ultimate potential loss could have a material adverse effect on the Company’s financial condition or results of operations in a particular period. The Company has accrued amounts for its loss contingencies which are probable and estimable as of July 3, 2023 and January 2, 2023 and included as a component of other current liabilities. However, these amounts are not material to the consolidated condensed financial statements of the Company.

- changed (2023-11-07):
[0000950170-23-060227:note_history:2]
The Company has and may continue to enter into industrial cooperation agreements, sometimes referred to as offset agreements, as a condition to obtaining orders for products and services from customers in foreign countries. These agreements are intended to promote investment in the applicable country, and the Company’s obligations under these agreements may be satisfied through activities that do not require the Company to use cash, including transferring technology or providing manufacturing and other consulting support. The obligations under these agreements may also be satisfied through the use of cash for activities such as purchasing supplies from in-country vendors, setting up support centers, research and development investments, acquisitions, and building or leasing facilities for in-country operations. The amount of the offset requirement is determined by contract value awarded
  (was, 2023-08-10, similarity 0.803):
[0000950170-23-041297:note_history:2]
The Company has and may continue to enter into industrial cooperation agreements, sometimes referred to as offset agreements, as a condition to obtaining orders for products and services from customers in foreign countries. These agreements are intended to promote investment in the applicable country, and the Company’s obligations under these agreements may be satisfied through activities that do not require the Company to use cash, including transferring technology or providing manufacturing and other consulting support. The obligations under these agreements may also be satisfied through the use of cash for activities such as purchasing supplies from in-country vendors, setting up support centers, research and development investments, acquisitions, and building or leasing facilities for in-country operations. The amount of the offset requirement is determined by contract value awarded and negotiated percentages with customers. As of July 3, 2023, the Company had outstanding offset agreements of approximately $20,169, some of which extend through 2028. Offset programs usually extend over several years and in some cases provide for penalties in the event the Company fails to perform in accordance with contract requirements. Historically, the Company has not paid any such penalties, and as of July 3, 2023, no such penalties have been paid.

- added (2023-11-07):
[0000950170-23-060227:note_history:3]
and negotiated percentages with customers. As of October 2, 2023, the Company had outstanding offset agreements of approximately $27,963, some of which extend through 2028. Offset programs usually extend over several years and in some cases provide for penalties in the event the Company fails to perform in accordance with contract requirements. Historically, the Company has not paid any such penalties, and as of October 2, 2023, no such penalties have been paid.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureAndSignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2023-11-07):
[0000950170-23-060227:note_history:4]
The accompanying consolidated condensed financial statements have been prepared by the Company, without audit, pursuant to the rules and regulations of the Securities and Exchange Commission (SEC). Certain information and disclosures normally included in financial statements prepared in accordance with accounting principles generally accepted in the United States of America (U.S. GAAP) have been condensed or omitted pursuant to such rules and regulations. These consolidated condensed financial statements should be read in conjunction with the consolidated financial statements and the notes thereto included in the Company’s most recent Annual Report on Form 10-K. The preparation of financial statements in accordance with U.S. GAAP requires management to make estimates and assumptions that affect the amounts reported in the Company’s consolidated condensed financial statements and accompanying notes. Due, in part, to the coronavirus (COVID-19) and its variants, the conflict between Russia and Ukraine, and the current conflict in Israel and the Gaza Strip, the global economy and financial markets have been volatile. In addition, the global economy and financial markets have experienced on-going disruptions in global supply chains, labor shortages, high inflation, and a potential recession. The Company has considered information available to it as of the date of issuance of these financial statements and is not aware of any specific events or circumstances that would require an update to its estimates or judgments, or a revision to the carrying value of its assets or liabilities. The actual results the Company experienced may differ materially and adversely from its estimates. The Company uses a 52/53 week fiscal calendar with the fourth quarter ending on the Monday nearest December 31.
  (was, 2023-08-10, similarity 0.7934):
[0000950170-23-041297:note_history:4]
The accompanying consolidated condensed financial statements have been prepared by the Company, without audit, pursuant to the rules and regulations of the Securities and Exchange Commission (SEC). Certain information and disclosures normally included in financial statements prepared in accordance with accounting principles generally accepted in the United States of America (U.S. GAAP) have been condensed or omitted pursuant to such rules and regulations. These consolidated condensed financial statements should be read in conjunction with the consolidated financial statements and the notes thereto included in the Company’s most recent Annual Report on Form 10-K. The preparation of financial statements in accordance with U.S. GAAP requires management to make estimates and assumptions that affect the amounts reported in the Company’s consolidated condensed financial statements and accompanying notes. Due, in part, to the on-going effects of the coronavirus (COVID-19) and its variants on the Company and the conflict between Russia and Ukraine, the global economy and financial markets have been volatile. In addition, both COVID-19 and the conflict in Ukraine have contributed to on-going disruptions in global supply chains, labor shortages, high inflation, and a potential recession, and there is a significant amount of uncertainty about the length and severity of the direct and indirect effects of COVID-19 variants and the conflict. The Company has considered information available to it as of the date of issuance of these financial statements and is not aware of any specific events or circumstances that would require an update to its estimates or judgments, or a revision to the carrying value of its assets or liabilities. The actual results the Company experienced may differ materially and adversely from its estimates. The Company uses a 52/53 week fiscal calendar with the fourth quarter ending on the Monday nearest December 31.

- added (2023-11-07):
[0000950170-23-060227:note_history:5]
Reclassifications

- added (2023-11-07):
[0000950170-23-060227:note_history:6]
Certain amounts in the prior period financial statements have been reclassified to conform to the presentation of the current period financial statements. These reclassifications had no effect on the previously reported net income.

- changed (2023-11-07):
[0000950170-23-060227:note_history:7]
In September 2022, the Financial Accounting Standards Board (FASB) issued Accounting Standards Update (ASU) 2022-04, Liabilities - Supplier Finance Programs (Topic 450-50): Disclosure of Supplier Finance Program Obligations, that requires entities that use supplier finance programs in connection with the purchase of goods and services to disclose the key terms of the programs and information about obligations outstanding at the end of the reporting period, including a rollforward of those obligations. The guidance does not affect the recognition, measurement or financial statement presentation of supplier finance program obligations. The amendments are effective for all entities for fiscal years beginning after December 15, 2022 on a retrospective basis, including interim periods within those fiscal years, except for the requirement to disclose rollforward information, which is effective prospectively for fiscal years beginning after December 15, 2023. The Company adopted ASU 2022-04 as of April 3, 2023. The Company has agreements with financial institutions to facilitate the payments to certain suppliers. Under the terms of the agreements, the Company confirms the validity of each supplier invoice to the respective financial institution upon receipt. The supplier receives payment from the financial institution, and the Company pays the financial institution based on the terms negotiated, which generally range from 160 days to 360 days. Liabilities associated with these agreements are recorded in accounts payable on the consolidated condensed balance sheets and amounted to $15,945 and $6,653 as of October 2, 2023 and January 2, 2023, respectively.
  (was, 2023-08-10, similarity 0.9805):
[0000950170-23-041297:note_history:7]
In September 2022, the Financial Accounting Standards Board (FASB) issued Accounting Standards Update (ASU) 2022-04, Liabilities - Supplier Finance Programs (Topic 450-50): Disclosure of Supplier Finance Program Obligations, that requires entities that use supplier finance programs in connection with the purchase of goods and services to disclose the key terms of the programs and information about obligations outstanding at the end of the reporting period, including a rollforward of those obligations. The guidance does not affect the recognition, measurement or financial statement presentation of supplier finance program obligations. The amendments are effective for all entities for fiscal years beginning after December 15, 2022 on a retrospective basis, including interim periods within those fiscal years, except for the requirement to disclose rollforward information, which is effective prospectively for fiscal years beginning after December 15, 2023. The Company adopted ASU 2022-04 as of April 3, 2023. The Company has agreements with financial institutions to facilitate the payments to certain suppliers. Under the terms of the agreements, the Company confirms the validity of each supplier invoice to the respective financial institution upon receipt. The supplier receives payment from the financial institution, and the Company pays the financial institution based on the terms negotiated, which generally range from 160 days to 360 days, with a weighted average of 260 days. Liabilities associated with these agreements are recorded in accounts payable on the consolidated condensed balance sheets and amounted to $8,206 and $6,653 as of July 3, 2023 and January 2, 2023, respectively.

- changed (2023-11-07):
[0000950170-23-060227:note_history:8]
In December 2022, the FASB issued ASU 2022-06, Reference Rate Reform (Topic 848): Deferral of the Sunset Date of Topic 848, which deferred the sunset date of Topic 848 to December 31, 2024, after which entities will no longer be permitted to apply the optional expedients and exceptions in Topic 848. On March 23, 2023, the Company entered into a four-year pay-fixed, receive floating (1-month CME Term Secured Overnight Financing Rate (SOFR)), interest rate swap arrangement with a notional amount of $250,000 for the period beginning April 1, 2023 and ending on April 1, 2027. Under the terms of the interest rate swap, the Company pays a fixed rate of 3.49% against a portion of its Term SOFR-based debt and receives a floating 1-month CME Term SOFR during
  (was, 2023-08-10, similarity 0.9027):
[0000950170-23-041297:note_history:8]
In December 2022, the FASB issued ASU 2022-06, Reference Rate Reform (Topic 848): Deferral of the Sunset Date of Topic 848, which deferred the sunset date of Topic 848 to December 31, 2024, after which entities will no longer be permitted to apply the optional expedients and exceptions in Topic 848. On March 23, 2023, the Company entered into a four-year pay-fixed, receive floating (1-month CME Term Secured Overnight Financing Rate (SOFR)), interest rate swap arrangement with a notional amount of $250,000 for the period beginning April 1, 2023 and ending on April 1, 2027. Under the terms of the interest rate swap, the Company pays a fixed rate of 3.49% against a portion of its Term SOFR-based debt and receives a floating 1-month CME Term SOFR during the swap period. The Company elected optional expedients provided in Topic 848 which allow the designation of the interest rate swap as a cash flow hedge.

- added (2023-11-07):
[0000950170-23-060227:note_history:9]
the swap period. The Company elected optional expedients provided in Topic 848 which allow the designation of the interest rate swap as a cash flow hedge.


## ttmi:ScheduleOfUnamortizedDiscountAndDebtIssuanceCostsTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2023-11-07):
[0000950170-23-060227:note_history:10]
As of October 2, 2023 and January 2, 2023, remaining unamortized debt issuance costs and debt discount for the Senior Notes due 2029 and Term Loan Facility are as follows:
  (was, 2023-08-10, similarity 0.8508):
[0000950170-23-041297:note_history:10]
As of July 3, 2023 and January 2, 2023, remaining unamortized debt discount and debt issuance costs for the Senior Notes due 2029 and Term Loan Facility are as follows:

- changed (2023-11-07):
[0000950170-23-060227:note_history:11]
|  |  | As of October 2, 2023 |  |  |  | As of January 2, 2023 |
|  |  | DebtIssuance Costs |  |  | DebtDiscount |  |  | EffectiveInterest Rate |  |  |  | DebtIssuance Costs |  |  | DebtDiscount |  |  | EffectiveInterest Rate |  |  |
|  |  | (In thousands, except interest rates) |
| Senior Notes due March 2029 |  | $ | 4,260 |  |  | $ | — |  |  |  | 4.18 |  | % |  | $ | 4,779 |  |  | $ | — |  |  |  | 4.18 |  | % |
| Term Loan due May 2030 |  |  | 4,052 |  |  |  | 3,364 |  |  |  | 8.26 |  |  |  |  | — |  |  |  | — |  |  |  | — |  |  |
| Term Loan due September 2024 |  |  | — |  |  |  | — |  |  |  | — |  |  |  |  | 1,301 |  |  |  | 392 |  |  |  | 4.66 |  |  |
|  |  | $ | 8,312 |  |  | $ | 3,364 |  |  |  |  |  |  | $ | 6,080 |  |  | $ | 392 |  |  |  |  |  |
  (was, 2023-08-10, similarity 0.9909):
[0000950170-23-041297:note_history:11]
|  |  | As of July 3, 2023 |  |  |  | As of January 2, 2023 |
|  |  | DebtIssuance Costs |  |  | DebtDiscount |  |  | EffectiveInterest Rate |  |  |  | DebtIssuance Costs |  |  | DebtDiscount |  |  | EffectiveInterest Rate |  |  |
|  |  | (In thousands, except interest rates) |
| Senior Notes due March 2029 |  | $ | 4,435 |  |  | $ | — |  |  |  | 4.18 |  | % |  | $ | 4,779 |  |  | $ | — |  |  |  | 4.18 |  | % |
| Term Loan due May 2030 |  |  | 4,181 |  |  |  | 3,471 |  |  |  | 8.25 |  |  |  |  | — |  |  |  | — |  |  |  | — |  |  |
| Term Loan due September 2024 |  |  | — |  |  |  | — |  |  |  | — |  |  |  |  | 1,301 |  |  |  | 392 |  |  |  | 4.66 |  |  |
|  |  | $ | 8,616 |  |  | $ | 3,471 |  |  |  |  |  |  | $ | 6,080 |  |  | $ | 392 |  |  |  |  |  |


## us-gaap:LongTermDebtTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2023-11-07):
[0000950170-23-060227:note_history:12]
The following table summarizes the long-term debt of the Company as of October 2, 2023 and January 2, 2023:
  (was, 2023-08-10, similarity 0.9436):
[0000950170-23-041297:note_history:12]
The following table summarizes the long-term debt of the Company as of July 3, 2023 and January 2, 2023:

- changed (2023-11-07):
[0000950170-23-060227:note_history:13]
|  |  | Interest Rate as ofOctober 2, 2023 |  |  |  | PrincipalOutstandingas ofOctober 2, 2023 |  |  | Interest Rate as ofJanuary 2, 2023 |  |  |  | PrincipalOutstandingas ofJanuary 2, 2023 |  |
|  |  | (In thousands, except interest rates) |  |
| Senior Notes due March 2029 |  |  | 4.00 |  | % |  | $ | 500,000 |  |  |  | 4.00 |  | % |  | $ | 500,000 |  |
| Term Loan due May 2030 |  |  | 8.07 |  |  |  |  | 349,125 |  |  |  | — |  |  |  |  | — |  |
| Asia ABL Revolving Loan due June 2028 |  |  | 6.62 |  |  |  |  | 30,000 |  |  |  | 5.79 |  |  |  |  | 30,000 |  |
| Term Loan due September 2024 |  |  | — |  |  |  |  | — |  |  |  | 6.89 |  |  |  |  | 405,879 |  |
|  |  |  |  |  |  |  | 879,125 |  |  |  |  |  |  |  | 935,879 |  |
| Less: Long-term debt unamortized debt issuance costs |  |  |  |  |  |  | (8,312 | ) |  |  |  |  |  |  | (6,080 | ) |
| Long-term debt unamortized discount |  |  |  |  |  |  | (3,364 | ) |  |  |  |  |  |  | (392 | ) |
|  |  |  |  |  |  |  | 867,449 |  |  |  |  |  |  |  | 929,407 |  |
| Less: current maturities |  |  |  |  |  |  | (2,625 | ) |  |  |  |  |  |  | (50,000 | ) |
| Long-term debt, less current maturities |  |  |  |  |  | $ | 864,824 |  |  |  |  |  |  | $ | 879,407 |  |
  (was, 2023-08-10, similarity 0.9101):
[0000950170-23-041297:note_history:13]
|  |  | Interest Rate as ofJuly 3, 2023 |  |  |  | PrincipalOutstandingas ofJuly 3, 2023 |  |  | Interest Rate as ofJanuary 2, 2023 |  |  |  | PrincipalOutstandingas ofJanuary 2, 2023 |  |
|  |  | (In thousands, except interest rates) |  |
| Senior Notes due March 2029 |  |  | 4.00 |  | % |  | $ | 500,000 |  |  |  | 4.00 |  | % |  | $ | 500,000 |  |
| Term Loan due May 2030 |  |  | 7.89 |  |  |  |  | 350,000 |  |  |  | — |  |  |  |  | — |  |
| Asia ABL Revolving Loan due June 2028 |  |  | 6.44 |  |  |  |  | 30,000 |  |  |  | 5.79 |  |  |  |  | 30,000 |  |
| Term Loan due September 2024 |  |  | — |  |  |  |  | — |  |  |  | 6.89 |  |  |  |  | 405,879 |  |
|  |  |  |  |  |  |  | 880,000 |  |  |  |  |  |  |  | 935,879 |  |
| Less: Long-term debt unamortized debt issuance costs |  |  |  |  |  |  | (8,616 | ) |  |  |  |  |  |  | (6,080 | ) |
| Long-term debt unamortized discount |  |  |  |  |  |  | (3,471 | ) |  |  |  |  |  |  | (392 | ) |
|  |  |  |  |  |  |  | 867,913 |  |  |  |  |  |  |  | 929,407 |  |
| Less: current maturities |  |  |  |  |  |  | (3,500 | ) |  |  |  |  |  |  | (50,000 | ) |
| Long-term debt, less current maturities |  |  |  |  |  | $ | 864,413 |  |  |  |  |  |  | $ | 879,407 |  |

- changed (2023-11-07):
[0000950170-23-060227:note_history:14]
On May 30, 2023, pursuant to an Amended & Restated Term Loan Credit Agreement by and among the Company, JPMorgan Chase Bank, N.A., as Administrative Agent, and the several lenders from time to time parties thereto (Term Loan Credit Agreement), the Company closed its $350,000 senior secured Term Loan due 2030 (Term Loan Facility). This Term Loan Facility had an outstanding balance of $349,125 as of October 2, 2023, of which $2,625 is included in short-term debt and $346,500 is included in long-term debt. The Term Loan Facility was issued with a 1.0% original issue discount and bears interest at a floating rate of 1-month CME Term SOFR plus an applicable margin of 2.75%. There is no provision, other than an event of default, for the interest margin to increase. The Company is required to make quarterly principal repayments in an aggregate annual amount equal to 1% of the initial aggregate principal amount of the Term Loan Facility. Such principal repayment is payable quarterly on January 1, April 1, July 1, and October 1 and ending with the last such day to occur prior to May 30, 2030. The remaining principal under the Term Loan Facility is scheduled to mature on May 30, 2030. In addition, the Term Loan Credit Agreement permits the Company to add one or more senior secured incremental term loan facilities to the Term Loan Facility subject to the satisfaction of certain conditions.
  (was, 2023-08-10, similarity 0.9303):
[0000950170-23-041297:note_history:14]
On May 30, 2023, pursuant to an Amended & Restated Term Loan Credit Agreement by and among the Company, JPMorgan Chase Bank, N.A., as Administrative Agent, and the several lenders from time to time parties thereto (Term Loan Credit Agreement), the Company closed its $350,000 senior secured Term Loan due 2030 (Term Loan Facility), of which $3,500 is included in short-term debt and $346,500 is included in long-term debt. The Term Loan Facility was issued with a 1.0% original issue discount and bears interest at a floating rate of 1-month CME Term SOFR plus an applicable margin of 2.75%. There is no provision, other than an event of default, for the interest margin to increase. The Company is required to make quarterly principal repayments in an aggregate annual amount equal to 1% of the initial aggregate principal amount of the Term Loan Facility beginning October 1, 2023. Such principal repayment is payable quarterly on January 1, April 1, July 1, and October 1 and ending with the last such day to occur prior to May 30, 2030. The remaining principal under the Term Loan Facility is scheduled to mature on May 30, 2030. In addition, the Term Loan Credit Agreement will permit the Company to add one or more senior secured incremental term loan facilities to the Term Loan Facility subject to the satisfaction of certain conditions.

- added (2023-11-07):
[0000950170-23-060227:note_history:15]
Borrowings under the U.S. ABL bear interest at a floating rate of Term SOFR plus a margin ranging from 1.25% to 1.50%. The applicable margin can vary based on the remaining availability of the facility, from 1.25% to 1.50% for Term SOFR-based loans and from 0.25% to 0.50% for JPMorgan Chase Bank’s prime rate-based loans. Other than availability and an event of default, there are no other provisions for the interest margin to increase. The Company is also required to pay certain fees in connection with the U.S. ABL

- added (2023-11-07):
[0000950170-23-060227:note_history:16]
agreement, including unused commitment fees based on the average daily unused portion of the U.S. ABL facility, equal to 0.25% on an annual basis.

- added (2023-11-07):
[0000950170-23-060227:note_history:17]
Borrowings under the Asia ABL bear interest at a floating rate of Term SOFR plus 1.30%. There is no provision, other than an event of default, for the interest margin to increase. The Company is also required to pay certain fees in connection with the Asia ABL agreement, including unused commitment fees based on the average daily unused portion of the Asia ABL facility, equal to 0.25% on an annual basis.

- changed (2023-11-07):
[0000950170-23-060227:note_history:18]
As of October 2, 2023, letters of credit in the amount of $6,191 were outstanding under the U.S. ABL and $21,961 were outstanding under the Asia ABL with various maturities through November 2024. Available borrowing capacity under the U.S. ABL and the Asia ABL was $143,809 and $98,039, respectively, which considers letters of credit outstanding as of October 2, 2023.
  (was, 2023-08-10, similarity 0.9442):
[0000950170-23-041297:note_history:18]
As of July 3, 2023, letters of credit in the amount of $6,191 were outstanding under the U.S. ABL and $14,039 were outstanding under the Asia ABL with various maturities through September 2024. Available borrowing capacity under the U.S. ABL and the Asia ABL was $143,809 and $105,961, respectively, which considers letters of credit outstanding as of July 3, 2023.

- changed (2023-11-07):
[0000950170-23-060227:note_history:19]
As of October 2, 2023 and January 2, 2023, remaining unamortized debt issuance costs and debt discount for the Senior Notes due 2029 and Term Loan Facility are as follows:
  (was, 2023-08-10, similarity 0.8508):
[0000950170-23-041297:note_history:19]
As of July 3, 2023 and January 2, 2023, remaining unamortized debt discount and debt issuance costs for the Senior Notes due 2029 and Term Loan Facility are as follows:

- changed (2023-11-07):
[0000950170-23-060227:note_history:20]
|  |  | As of October 2, 2023 |  |  |  | As of January 2, 2023 |
|  |  | DebtIssuance Costs |  |  | DebtDiscount |  |  | EffectiveInterest Rate |  |  |  | DebtIssuance Costs |  |  | DebtDiscount |  |  | EffectiveInterest Rate |  |  |
|  |  | (In thousands, except interest rates) |
| Senior Notes due March 2029 |  | $ | 4,260 |  |  | $ | — |  |  |  | 4.18 |  | % |  | $ | 4,779 |  |  | $ | — |  |  |  | 4.18 |  | % |
| Term Loan due May 2030 |  |  | 4,052 |  |  |  | 3,364 |  |  |  | 8.26 |  |  |  |  | — |  |  |  | — |  |  |  | — |  |  |
| Term Loan due September 2024 |  |  | — |  |  |  | — |  |  |  | — |  |  |  |  | 1,301 |  |  |  | 392 |  |  |  | 4.66 |  |  |
|  |  | $ | 8,312 |  |  | $ | 3,364 |  |  |  |  |  |  | $ | 6,080 |  |  | $ | 392 |  |  |  |  |  |
  (was, 2023-08-10, similarity 0.9909):
[0000950170-23-041297:note_history:20]
|  |  | As of July 3, 2023 |  |  |  | As of January 2, 2023 |
|  |  | DebtIssuance Costs |  |  | DebtDiscount |  |  | EffectiveInterest Rate |  |  |  | DebtIssuance Costs |  |  | DebtDiscount |  |  | EffectiveInterest Rate |  |  |
|  |  | (In thousands, except interest rates) |
| Senior Notes due March 2029 |  | $ | 4,435 |  |  | $ | — |  |  |  | 4.18 |  | % |  | $ | 4,779 |  |  | $ | — |  |  |  | 4.18 |  | % |
| Term Loan due May 2030 |  |  | 4,181 |  |  |  | 3,471 |  |  |  | 8.25 |  |  |  |  | — |  |  |  | — |  |  |  | — |  |  |
| Term Loan due September 2024 |  |  | — |  |  |  | — |  |  |  | — |  |  |  |  | 1,301 |  |  |  | 392 |  |  |  | 4.66 |  |  |
|  |  | $ | 8,616 |  |  | $ | 3,471 |  |  |  |  |  |  | $ | 6,080 |  |  | $ | 392 |  |  |  |  |  |

- changed (2023-11-07):
[0000950170-23-060227:note_history:21]
The above debt issuance costs and debt discount are recorded as a reduction of the debt and are amortized into interest expense using an effective interest rate over the duration of the debt.
  (was, 2023-08-10, similarity 0.9058):
[0000950170-23-041297:note_history:21]
The above debt discount and debt issuance costs are recorded as a reduction of the debt and are amortized into interest expense using an effective interest rate over the duration of the debt.

- changed (2023-11-07):
[0000950170-23-060227:note_history:22]
The remaining unamortized debt issuance costs for the ABL Revolving Loans of $1,695 and $792 as of October 2, 2023 and January 2, 2023, respectively, are included in other non-current assets and are amortized to interest expense over the duration of the ABL Revolving Loans using the straight-line method of amortization.
  (was, 2023-08-10, similarity 0.9819):
[0000950170-23-041297:note_history:22]
The remaining unamortized debt issuance costs for the ABL Revolving Loans of $1,786 and $792 as of July 3, 2023 and January 2, 2023, respectively, are included in other non-current assets and are amortized to interest expense over the duration of the ABL Revolving Loans using the straight-line method of amortization.

- changed (2023-11-07):
[0000950170-23-060227:note_history:23]
As of October 2, 2023, the remaining weighted average amortization period for all unamortized debt issuance costs and debt discount was 6.0 years.
  (was, 2023-08-10, similarity 0.8291):
[0000950170-23-041297:note_history:23]
As of July 3, 2023, the remaining weighted average amortization period for all unamortized debt discount and debt issuance costs was 6.3 years.

- changed (2023-11-07):
[0000950170-23-060227:note_history:24]
During the three quarters ended October 2, 2023, the Company recognized loss on extinguishment of debt of $1,154, primarily associated with the write-off of the remaining unamortized debt issuance costs and debt discount as a result of the repayment of the remaining outstanding balance of the Term Loan Facility that was due to mature September 2024.
  (was, 2023-08-10, similarity 0.9422):
[0000950170-23-041297:note_history:24]
During the quarter ended July 3, 2023, the Company recognized loss on extinguishment of debt of $1,154, primarily associated with the write-off of the remaining unamortized debt issuance and debt discount as a result of the repayment of the remaining outstanding balance of the Term Loan Facility that was due to mature September 2024.

- removed (2023-11-07):
[0000950170-23-041297:note_history:25]
Borrowings under the U.S. ABL bear interest at a floating rate of Term SOFR plus a margin ranging from 1.25% to 1.50%. The applicable margin can vary based on the remaining availability of the facility, from 125 to 150 basis points for Term SOFR-based loans and from 25 to 50 basis points for JPMorgan Chase Bank’s prime rate-based loans. Other than availability and an event of default, there are no other provisions for the interest margin to increase. The Company is also required to pay certain fees in connection with the U.S. ABL agreement, including unused commitment fees based on the average daily unused portion of the U.S. ABL facility, equal to 0.25% on an annual basis.

- removed (2023-11-07):
[0000950170-23-041297:note_history:26]
Borrowings under the Asia ABL bear interest at a floating rate of Term SOFR plus 130 basis points. There is no provision, other than an event of default, for the interest margin to increase. The Company is also required to pay certain fees in connection with the Asia ABL agreement, including unused commitment fees based on the average daily unused portion of the Asia ABL facility, equal to 0.25% on an annual basis.


## us-gaap:ScheduleOfDebtInstrumentsTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2023-11-07):
[0000950170-23-060227:note_history:27]
The following table summarizes the long-term debt of the Company as of October 2, 2023 and January 2, 2023:
  (was, 2023-08-10, similarity 0.9436):
[0000950170-23-041297:note_history:27]
The following table summarizes the long-term debt of the Company as of July 3, 2023 and January 2, 2023:

- changed (2023-11-07):
[0000950170-23-060227:note_history:28]
|  |  | Interest Rate as ofOctober 2, 2023 |  |  |  | PrincipalOutstandingas ofOctober 2, 2023 |  |  | Interest Rate as ofJanuary 2, 2023 |  |  |  | PrincipalOutstandingas ofJanuary 2, 2023 |  |
|  |  | (In thousands, except interest rates) |  |
| Senior Notes due March 2029 |  |  | 4.00 |  | % |  | $ | 500,000 |  |  |  | 4.00 |  | % |  | $ | 500,000 |  |
| Term Loan due May 2030 |  |  | 8.07 |  |  |  |  | 349,125 |  |  |  | — |  |  |  |  | — |  |
| Asia ABL Revolving Loan due June 2028 |  |  | 6.62 |  |  |  |  | 30,000 |  |  |  | 5.79 |  |  |  |  | 30,000 |  |
| Term Loan due September 2024 |  |  | — |  |  |  |  | — |  |  |  | 6.89 |  |  |  |  | 405,879 |  |
|  |  |  |  |  |  |  | 879,125 |  |  |  |  |  |  |  | 935,879 |  |
| Less: Long-term debt unamortized debt issuance costs |  |  |  |  |  |  | (8,312 | ) |  |  |  |  |  |  | (6,080 | ) |
| Long-term debt unamortized discount |  |  |  |  |  |  | (3,364 | ) |  |  |  |  |  |  | (392 | ) |
|  |  |  |  |  |  |  | 867,449 |  |  |  |  |  |  |  | 929,407 |  |
| Less: current maturities |  |  |  |  |  |  | (2,625 | ) |  |  |  |  |  |  | (50,000 | ) |
| Long-term debt, less current maturities |  |  |  |  |  | $ | 864,824 |  |  |  |  |  |  | $ | 879,407 |  |
  (was, 2023-08-10, similarity 0.9101):
[0000950170-23-041297:note_history:28]
|  |  | Interest Rate as ofJuly 3, 2023 |  |  |  | PrincipalOutstandingas ofJuly 3, 2023 |  |  | Interest Rate as ofJanuary 2, 2023 |  |  |  | PrincipalOutstandingas ofJanuary 2, 2023 |  |
|  |  | (In thousands, except interest rates) |  |
| Senior Notes due March 2029 |  |  | 4.00 |  | % |  | $ | 500,000 |  |  |  | 4.00 |  | % |  | $ | 500,000 |  |
| Term Loan due May 2030 |  |  | 7.89 |  |  |  |  | 350,000 |  |  |  | — |  |  |  |  | — |  |
| Asia ABL Revolving Loan due June 2028 |  |  | 6.44 |  |  |  |  | 30,000 |  |  |  | 5.79 |  |  |  |  | 30,000 |  |
| Term Loan due September 2024 |  |  | — |  |  |  |  | — |  |  |  | 6.89 |  |  |  |  | 405,879 |  |
|  |  |  |  |  |  |  | 880,000 |  |  |  |  |  |  |  | 935,879 |  |
| Less: Long-term debt unamortized debt issuance costs |  |  |  |  |  |  | (8,616 | ) |  |  |  |  |  |  | (6,080 | ) |
| Long-term debt unamortized discount |  |  |  |  |  |  | (3,471 | ) |  |  |  |  |  |  | (392 | ) |
|  |  |  |  |  |  |  | 867,913 |  |  |  |  |  |  |  | 929,407 |  |
| Less: current maturities |  |  |  |  |  |  | (3,500 | ) |  |  |  |  |  |  | (50,000 | ) |
| Long-term debt, less current maturities |  |  |  |  |  | $ | 864,413 |  |  |  |  |  |  | $ | 879,407 |  |


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2023-11-07):
[0000950170-23-060227:note_history:29]
|  |  | Quarter Ended October 2, 2023 |  |  | Quarter Ended October 3, 2022 (1) |  |
|  |  | PCB |  |  | RF&S Components |  |  | Total |  |  | PCB |  |  | RF&S Components |  |  | Total |  |
| End Markets |  | (In thousands) |  |
| Aerospace and Defense |  | $ | 255,618 |  |  | $ | — |  |  | $ | 255,618 |  |  | $ | 254,285 |  |  | $ | — |  |  | $ | 254,285 |  |
| Automotive |  |  | 86,803 |  |  |  | — |  |  |  | 86,803 |  |  |  | 100,811 |  |  |  | — |  |  |  | 100,811 |  |
| Data Center Computing |  |  | 99,584 |  |  |  | — |  |  |  | 99,584 |  |  |  | 95,830 |  |  |  | 13 |  |  |  | 95,843 |  |
| Medical/Industrial/Instrumentation |  |  | 89,818 |  |  |  | 895 |  |  |  | 90,713 |  |  |  | 128,444 |  |  |  | 1,239 |  |  |  | 129,683 |  |
| Networking |  |  | 31,853 |  |  |  | 8,011 |  |  |  | 39,864 |  |  |  | 78,181 |  |  |  | 12,494 |  |  |  | 90,675 |  |
| Other |  |  | — |  |  |  | — |  |  |  | — |  |  |  | (376 | ) |  |  | 159 |  |  |  | (217 | ) |
| Total |  | $ | 563,676 |  |  | $ | 8,906 |  |  | $ | 572,582 |  |  | $ | 657,175 |  |  | $ | 13,905 |  |  | $ | 671,080 |  |
  (was, 2023-08-10, similarity 0.9559):
[0000950170-23-041297:note_history:29]
|  |  | Quarter Ended July 3, 2023 |  |  | Quarter Ended July 4, 2022 |  |
|  |  | PCB |  |  | RF&S Components |  |  | Total |  |  | PCB |  |  | RF&S Components |  |  | Total |  |
| End Markets |  | (In thousands) |  |  |  |  |  |  |  |  |
| Aerospace and Defense |  | $ | 254,284 |  |  | $ | — |  |  | $ | 254,284 |  |  | $ | 189,676 |  |  | $ | — |  |  | $ | 189,676 |  |
| Automotive |  |  | 92,374 |  |  |  | — |  |  |  | 92,374 |  |  |  | 111,778 |  |  |  | — |  |  |  | 111,778 |  |
| Data Center Computing |  |  | 64,305 |  |  |  | 51 |  |  |  | 64,356 |  |  |  | 106,188 |  |  |  | 20 |  |  |  | 106,208 |  |
| Medical/Industrial/Instrumentation |  |  | 88,979 |  |  |  | 745 |  |  |  | 89,724 |  |  |  | 131,061 |  |  |  | 2,246 |  |  |  | 133,307 |  |
| Networking |  |  | 36,589 |  |  |  | 9,182 |  |  |  | 45,771 |  |  |  | 69,766 |  |  |  | 15,109 |  |  |  | 84,875 |  |
| Other |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 960 |  |  |  | (1,254 | ) |  |  | (294 | ) |
| Total |  | $ | 536,531 |  |  | $ | 9,978 |  |  | $ | 546,509 |  |  | $ | 609,429 |  |  | $ | 16,121 |  |  | $ | 625,550 |  |

- changed (2023-11-07):
[0000950170-23-060227:note_history:30]
|  |  | Three Quarters Ended October 2, 2023 |  |  | Three Quarters Ended October 3, 2022 (1) |  |  |
|  |  | PCB |  |  | RF&S Components |  |  | Total |  |  | PCB |  |  | RF&S Components |  |  | Total |  |  |
| End Markets |  | (In thousands) |  |  |
| Aerospace and Defense |  | $ | 742,194 |  |  | $ | — |  |  | $ | 742,194 |  |  | $ | 616,141 |  |  | $ | — |  |  | $ | 616,141 |  |  |
| Automotive |  |  | 272,644 |  |  |  | — |  |  |  | 272,644 |  |  |  | 327,825 |  |  |  | — |  |  |  | 327,825 |  |  |
| Data Center Computing |  |  | 221,759 |  |  |  | 51 |  |  |  | 221,810 |  |  |  | 293,802 |  |  |  | 33 |  |  |  | 293,835 |  |  |
| Medical/Industrial/Instrumentation |  |  | 279,565 |  |  |  | 2,557 |  |  |  | 282,122 |  |  |  | 379,867 |  |  |  | 5,023 |  |  |  | 384,890 |  |  |
| Networking |  |  | 118,156 |  |  |  | 26,602 |  |  |  | 144,758 |  |  |  | 211,590 |  |  |  | 41,360 |  |  |  | 252,950 |  |  |
| Other |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 3,449 |  |  |  | (1,200 | ) |  |  | 2,249 |  |  |
| Total |  | $ | 1,634,318 |  |  | $ | 29,210 |  |  | $ | 1,663,528 |  |  | $ | 1,832,674 |  |  | $ | 45,216 |  |  | $ | 1,877,890 |  |  |
  (was, 2023-08-10, similarity 0.9344):
[0000950170-23-041297:note_history:30]
|  |  | Two Quarters Ended July 3, 2023 |  |  | Two Quarters Ended July 4, 2022 |  |  |
|  |  | PCB |  |  | RF&S Components |  |  | Total |  |  | PCB |  |  | RF&S Components |  |  |  | Total |  |  |
| End Markets |  | (In thousands) |  |  |
| Aerospace and Defense |  | $ | 486,576 |  |  | $ | — |  |  | $ | 486,576 |  |  | $ | 361,856 |  |  | $ | — |  |  |  | $ | 361,856 |  |  |
| Automotive |  |  | 185,841 |  |  |  | — |  |  |  | 185,841 |  |  |  | 227,014 |  |  |  | — |  |  |  |  | 227,014 |  |  |
| Data Center Computing |  |  | 122,175 |  |  |  | 51 |  |  |  | 122,226 |  |  |  | 197,972 |  |  |  | 20 |  |  |  |  | 197,992 |  |  |
| Medical/Industrial/Instrumentation |  |  | 189,747 |  |  |  | 1,662 |  |  |  | 191,409 |  |  |  | 251,423 |  |  |  | 3,784 |  |  |  |  | 255,207 |  |  |
| Networking |  |  | 86,303 |  |  |  | 18,591 |  |  |  | 104,894 |  |  |  | 133,409 |  |  |  | 28,866 |  |  |  |  | 162,275 |  |  |
| Other |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 3,825 |  |  |  | (1,359 | ) |  |  |  | 2,466 |  |  |
| Total |  | $ | 1,070,642 |  |  | $ | 20,304 |  |  | $ | 1,090,946 |  |  | $ | 1,175,499 |  |  | $ | 31,311 |  |  |  | $ | 1,206,810 |  |  |

- added (2023-11-07):
[0000950170-23-060227:note_history:31]
(1)
Amended for Telephonics integration.


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2023-11-07):
[0000950170-23-060227:note_history:32]
As of October 2, 2023, the aggregate amount of the transaction price allocated to remaining performance obligations for long-term contracts was $353,941. The Company expects to recognize revenue on approximately 56% of the remaining performance obligations for the Company’s long-term contracts over the next twelve months with the remaining amount expected to be recognized thereafter.
  (was, 2023-08-10, similarity 0.9852):
[0000950170-23-041297:note_history:32]
As of July 3, 2023, the aggregate amount of the transaction price allocated to remaining performance obligations for long-term contracts was $376,291. The Company expects to recognize revenue on approximately 50% of the remaining performance obligations for the Company’s long-term contracts over the next twelve months with the remaining amount expected to be recognized thereafter.

- changed (2023-11-07):
[0000950170-23-060227:note_history:33]
For contracts in which anticipated total costs exceed the total expected revenue, an estimated loss is recognized in the period when identifiable. A provision for the entire amount of the estimated loss is recorded on a cumulative basis. The estimated remaining costs to complete for loss contracts as of October 2, 2023 and January 2, 2023 were $19,202 and $21,632, respectively.
  (was, 2023-08-10, similarity 0.9847):
[0000950170-23-041297:note_history:33]
For contracts in which anticipated total costs exceed the total expected revenue, an estimated loss is recognized in the period when identifiable. A provision for the entire amount of the estimated loss is recorded on a cumulative basis. The estimated remaining costs to complete for loss contracts as of July 3, 2023 and January 2, 2023 were $19,971 and $21,632, respectively.

- changed (2023-11-07):
[0000950170-23-060227:note_history:34]
Revenue recognized for the three quarters ended October 2, 2023 from amounts recorded as contract liabilities as of January 2, 2023 was $33,939.
  (was, 2023-08-10, similarity 0.9333):
[0000950170-23-041297:note_history:34]
Revenue recognized for the two quarters ended July 3, 2023 from amounts recorded as contract liabilities as of January 2, 2023 was $27,069.

- changed (2023-11-07):
[0000950170-23-060227:note_history:35]
Revenue from products and services transferred to customers over time and at a point in time accounted for 96% and 4%, respectively, of the Company’s revenue for the quarter and three quarters ended October 2, 2023, and 98% and 2%, respectively, of the Company’s revenue for the quarter and three quarters ended October 3, 2022.
  (was, 2023-08-10, similarity 0.9325):
[0000950170-23-041297:note_history:35]
Revenue from products and services transferred to customers over time and at a point in time accounted for 96% and 4%, respectively, of the Company’s revenue for the quarter and two quarters ended July 3, 2023, and 97% and 3%, respectively, of the Company’s revenue for the quarter and two quarters ended July 4, 2022.

- changed (2023-11-07):
[0000950170-23-060227:note_history:36]
|  |  | Quarter Ended October 2, 2023 |  |  | Quarter Ended October 3, 2022 (1) |  |
|  |  | PCB |  |  | RF&S Components |  |  | Total |  |  | PCB |  |  | RF&S Components |  |  | Total |  |
| End Markets |  | (In thousands) |  |
| Aerospace and Defense |  | $ | 255,618 |  |  | $ | — |  |  | $ | 255,618 |  |  | $ | 254,285 |  |  | $ | — |  |  | $ | 254,285 |  |
| Automotive |  |  | 86,803 |  |  |  | — |  |  |  | 86,803 |  |  |  | 100,811 |  |  |  | — |  |  |  | 100,811 |  |
| Data Center Computing |  |  | 99,584 |  |  |  | — |  |  |  | 99,584 |  |  |  | 95,830 |  |  |  | 13 |  |  |  | 95,843 |  |
| Medical/Industrial/Instrumentation |  |  | 89,818 |  |  |  | 895 |  |  |  | 90,713 |  |  |  | 128,444 |  |  |  | 1,239 |  |  |  | 129,683 |  |
| Networking |  |  | 31,853 |  |  |  | 8,011 |  |  |  | 39,864 |  |  |  | 78,181 |  |  |  | 12,494 |  |  |  | 90,675 |  |
| Other |  |  | — |  |  |  | — |  |  |  | — |  |  |  | (376 | ) |  |  | 159 |  |  |  | (217 | ) |
| Total |  | $ | 563,676 |  |  | $ | 8,906 |  |  | $ | 572,582 |  |  | $ | 657,175 |  |  | $ | 13,905 |  |  | $ | 671,080 |  |
  (was, 2023-08-10, similarity 0.9559):
[0000950170-23-041297:note_history:36]
|  |  | Quarter Ended July 3, 2023 |  |  | Quarter Ended July 4, 2022 |  |
|  |  | PCB |  |  | RF&S Components |  |  | Total |  |  | PCB |  |  | RF&S Components |  |  | Total |  |
| End Markets |  | (In thousands) |  |  |  |  |  |  |  |  |
| Aerospace and Defense |  | $ | 254,284 |  |  | $ | — |  |  | $ | 254,284 |  |  | $ | 189,676 |  |  | $ | — |  |  | $ | 189,676 |  |
| Automotive |  |  | 92,374 |  |  |  | — |  |  |  | 92,374 |  |  |  | 111,778 |  |  |  | — |  |  |  | 111,778 |  |
| Data Center Computing |  |  | 64,305 |  |  |  | 51 |  |  |  | 64,356 |  |  |  | 106,188 |  |  |  | 20 |  |  |  | 106,208 |  |
| Medical/Industrial/Instrumentation |  |  | 88,979 |  |  |  | 745 |  |  |  | 89,724 |  |  |  | 131,061 |  |  |  | 2,246 |  |  |  | 133,307 |  |
| Networking |  |  | 36,589 |  |  |  | 9,182 |  |  |  | 45,771 |  |  |  | 69,766 |  |  |  | 15,109 |  |  |  | 84,875 |  |
| Other |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 960 |  |  |  | (1,254 | ) |  |  | (294 | ) |
| Total |  | $ | 536,531 |  |  | $ | 9,978 |  |  | $ | 546,509 |  |  | $ | 609,429 |  |  | $ | 16,121 |  |  | $ | 625,550 |  |

- changed (2023-11-07):
[0000950170-23-060227:note_history:37]
|  |  | Three Quarters Ended October 2, 2023 |  |  | Three Quarters Ended October 3, 2022 (1) |  |  |
|  |  | PCB |  |  | RF&S Components |  |  | Total |  |  | PCB |  |  | RF&S Components |  |  | Total |  |  |
| End Markets |  | (In thousands) |  |  |
| Aerospace and Defense |  | $ | 742,194 |  |  | $ | — |  |  | $ | 742,194 |  |  | $ | 616,141 |  |  | $ | — |  |  | $ | 616,141 |  |  |
| Automotive |  |  | 272,644 |  |  |  | — |  |  |  | 272,644 |  |  |  | 327,825 |  |  |  | — |  |  |  | 327,825 |  |  |
| Data Center Computing |  |  | 221,759 |  |  |  | 51 |  |  |  | 221,810 |  |  |  | 293,802 |  |  |  | 33 |  |  |  | 293,835 |  |  |
| Medical/Industrial/Instrumentation |  |  | 279,565 |  |  |  | 2,557 |  |  |  | 282,122 |  |  |  | 379,867 |  |  |  | 5,023 |  |  |  | 384,890 |  |  |
| Networking |  |  | 118,156 |  |  |  | 26,602 |  |  |  | 144,758 |  |  |  | 211,590 |  |  |  | 41,360 |  |  |  | 252,950 |  |  |
| Other |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 3,449 |  |  |  | (1,200 | ) |  |  | 2,249 |  |  |
| Total |  | $ | 1,634,318 |  |  | $ | 29,210 |  |  | $ | 1,663,528 |  |  | $ | 1,832,674 |  |  | $ | 45,216 |  |  | $ | 1,877,890 |  |  |
  (was, 2023-08-10, similarity 0.9344):
[0000950170-23-041297:note_history:37]
|  |  | Two Quarters Ended July 3, 2023 |  |  | Two Quarters Ended July 4, 2022 |  |  |
|  |  | PCB |  |  | RF&S Components |  |  | Total |  |  | PCB |  |  | RF&S Components |  |  |  | Total |  |  |
| End Markets |  | (In thousands) |  |  |
| Aerospace and Defense |  | $ | 486,576 |  |  | $ | — |  |  | $ | 486,576 |  |  | $ | 361,856 |  |  | $ | — |  |  |  | $ | 361,856 |  |  |
| Automotive |  |  | 185,841 |  |  |  | — |  |  |  | 185,841 |  |  |  | 227,014 |  |  |  | — |  |  |  |  | 227,014 |  |  |
| Data Center Computing |  |  | 122,175 |  |  |  | 51 |  |  |  | 122,226 |  |  |  | 197,972 |  |  |  | 20 |  |  |  |  | 197,992 |  |  |
| Medical/Industrial/Instrumentation |  |  | 189,747 |  |  |  | 1,662 |  |  |  | 191,409 |  |  |  | 251,423 |  |  |  | 3,784 |  |  |  |  | 255,207 |  |  |
| Networking |  |  | 86,303 |  |  |  | 18,591 |  |  |  | 104,894 |  |  |  | 133,409 |  |  |  | 28,866 |  |  |  |  | 162,275 |  |  |
| Other |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 3,825 |  |  |  | (1,359 | ) |  |  |  | 2,466 |  |  |
| Total |  | $ | 1,070,642 |  |  | $ | 20,304 |  |  | $ | 1,090,946 |  |  | $ | 1,175,499 |  |  | $ | 31,311 |  |  |  | $ | 1,206,810 |  |  |

- added (2023-11-07):
[0000950170-23-060227:note_history:38]
(1)
Amended for Telephonics integration.
