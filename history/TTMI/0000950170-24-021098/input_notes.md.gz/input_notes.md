# TTMI notes — 0000950170-24-021098


## dei:DocumentsIncorporatedByReferenceTextBlock

[0000950170-24-021098:notes:1]
Portions of the registrant’s definitive Proxy Statement for its 2024 Annual Meeting of Stockholders will be incorporated by reference into Part III of this Annual Report on Form 10-K. Such Proxy Statement, or an amendment to this Report, will be filed with the Securities and Exchange Commission within 120 days after the end of the fiscal year to which this Report relates.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureAndSignificantAccountingPoliciesTextBlock

[0000950170-24-021098:notes:2]
(1)
Nature of Operations and Summary of Significant Accounting Policies

[0000950170-24-021098:notes:3]
Nature of Operations

[0000950170-24-021098:notes:4]
TTM Technologies, Inc. (the Company or TTM) is a leading global manufacturer of technology solutions, including mission systems, radio frequency (RF) components/RF microwave/microelectronic assemblies, quick-turn and technologically advanced printed circuit boards (PCB). The Company provides time-to-market and volume production of advanced technology products and offers a one-stop design, engineering and manufacturing solution to customers. This solution allows the Company to align technology developments with the diverse needs of the Company’s customers and to enable them to reduce the time required to develop new products and bring them to market.

[0000950170-24-021098:notes:5]
The Company serves a diversified customer base in various markets throughout the world, including aerospace and defense, data center computing, automotive, medical, industrial and instrumentation, and networking. The Company’s customers include original equipment manufacturers (OEMs), electronic manufacturing services (EMS) providers, original design manufacturers (ODMs), distributors and government agencies (both domestic and allied foreign governments).

[0000950170-24-021098:notes:6]
The Company operates on a 52 or 53 week fiscal calendar with the fourth quarter ending on the Monday nearest December 31. Fiscal year 2023 and 2022 consisted of 52 weeks ended on January 1, 2024 and January 2, 2023, respectively. Fiscal year 2021 consisted of 53 weeks ended on January 3, 2022, with the additional week included in the fourth quarter. All references to years relate to fiscal years unless otherwise noted.

[0000950170-24-021098:notes:7]
Use of Estimates

[0000950170-24-021098:notes:8]
The preparation of financial statements in conformity with accounting principles generally accepted in the United States of America (U.S. GAAP) requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities and disclosure of contingent assets and liabilities at the date of the financial statements and the reported amount of revenues and expenses during the reporting period. These estimates and assumptions are based on management’s best estimates and judgment. Due, in part, to the conflict between Russia and Ukraine, and the conflict in Israel and the Gaza Strip, the global economy and financial markets have been volatile. The Company has considered information available to it as of the date of issuance of these financial statements and is not aware of any specific events or circumstances that would require an update to its estimates or judgments, or a revision to the carrying value of its assets or liabilities. Management evaluates its estimates and assumptions on an ongoing basis using historical experience and other factors, including the economic environment, which management believes to be reasonable under the circumstances. Management adjusts such estimates and assumptions when facts and circumstances dictate. The actual results the Company experienced may differ materially and adversely from its estimates. To the extent there are material differences between the estimates and actual results, the Company’s future result of operations will be affected.

[0000950170-24-021098:notes:9]
Principles of Consolidation

[0000950170-24-021098:notes:10]
The consolidated financial statements include the accounts of TTM and its subsidiaries. All intercompany accounts and transactions have been eliminated in consolidation.

[0000950170-24-021098:notes:11]
Foreign Currency Translation and Transactions

[0000950170-24-021098:notes:12]
The functional currency of one of the Company’s subsidiaries is the Chinese Renminbi (RMB). Accordingly, assets and liabilities are translated into U.S. dollars using period-end exchange rates. Sales and expenses are translated at the average exchange rates in effect during the period. The resulting translation gains or losses are recorded as a component of accumulated other comprehensive income/(loss) in the consolidated statement of stockholders’ equity and the consolidated statement of comprehensive income. Net gains and losses resulting from foreign currency remeasurements and transactions are included in income as a component of other, net in the consolidated statements of operations and totaled $4,059 loss, $12,756 gain and $5,033 loss for the years ended January 1, 2024, January 2, 2023 and January 3, 2022, respectively.

[0000950170-24-021098:notes:13]
Cash Equivalents

[0000950170-24-021098:notes:14]
The Company considers highly liquid investments with insignificant interest rate risk and original maturities to the Company of three months or less to be cash equivalents.

[0000950170-24-021098:notes:15]
Accounts Receivable and Allowance for Doubtful Accounts

[0000950170-24-021098:notes:16]
Accounts receivable are reflected at estimated net realizable value, do not bear interest and do not generally require collateral. The Company performs credit evaluations of its customers and adjusts credit limits based upon payment history and the customer’s current creditworthiness. The Company maintains an allowance for doubtful accounts based upon a variety of factors. The Company considers both current and forecasted future economic conditions in determining the adequacy of its allowance for doubtful accounts.

[0000950170-24-021098:notes:17]
The Company’s allowance for doubtful accounts was $3,041, $2,075 and $1,558 as of January 1, 2024, January 2, 2023 and January 3, 2022, respectively.

[0000950170-24-021098:notes:18]
Inventories

[0000950170-24-021098:notes:19]
Inventories are stated at the lower of cost (determined on a first-in, first-out or weighted average basis) or net realizable value. Assessments to value the inventory at the lower of the actual cost to purchase and/or manufacture the inventory, or net realizable value of the inventory, are based upon assumptions about future demand and market conditions. As a result of the Company’s assessments, when the net realizable value of inventory is less than the carrying value, the inventory cost is written down to the net realizable value and the write down is recorded as a charge to cost of goods sold.

[0000950170-24-021098:notes:20]
Property, Plant and Equipment, Net

[0000950170-24-021098:notes:21]
Property, plant and equipment are recorded at cost. Depreciation expense is computed using the straight-line method over the estimated useful lives of the assets. Assets recorded under leasehold improvements are amortized using the straight-line method over the lesser of their useful lives or the related lease term. The Company uses the following estimated useful lives:

[0000950170-24-021098:notes:22]
| Land use rights |  | 50-99 years |
| Buildings and improvements |  | 7-50 years |
| Machinery and equipment |  | 3-10 years |
| Furniture and fixtures |  | 3-7 years |

[0000950170-24-021098:notes:23]
Upon retirement or other disposition of property, plant and equipment, the cost and related accumulated depreciation are removed from the accounts. The resulting gain or loss is included in the determination of operating income in the period incurred. Depreciation and amortization expense on property, plant and equipment was $99,155, $91,276 and $85,942 for the years ended January 1, 2024, January 2, 2023 and January 3, 2022, respectively.

[0000950170-24-021098:notes:24]
The Company capitalizes interest on borrowings during the active construction period of major capital projects. Capitalized interest is amortized over the average useful lives of such assets, which primarily consist of buildings and machinery and equipment. The Company capitalized interest costs of $2,272, $731 and $936 during the years ended January 1, 2024, January 2, 2023 and January 3, 2022, respectively, in connection with various capital projects.

[0000950170-24-021098:notes:25]
Major renewals and betterments are capitalized and depreciated over their estimated useful lives while minor expenditures for maintenance and repairs are included in operating income as incurred.

[0000950170-24-021098:notes:26]
Goodwill

[0000950170-24-021098:notes:27]
Goodwill represents the excess of purchase price of an acquisition over the fair value of net assets acquired. Goodwill is not amortized but instead is assessed for impairment, at a reporting unit level, annually and when events and circumstances warrant an evaluation. Goodwill is allocated to reporting units, which are operating segments or one level below the Company’s operating segments (the component level). Reporting units are determined by the discrete financial information available for the component and whether it is regularly reviewed by segment management. Components are aggregated into a single reporting unit if they share similar economic characteristics. The Company evaluates its goodwill on an annual basis in the fourth quarter or more frequently if it believes indicators of impairment exist. The Company assesses qualitative factors to determine whether it is more likely than not that the fair value of a reporting unit is less than its carrying amount or performs a quantitative impairment test. When tested quantitatively, the Company compares the fair value of the applicable reporting unit with its carrying value. In making this assessment, management relies on a number of factors, including expected future operating results, business plans, economic projections, anticipated future cash flows, business trends and declines in the Company’s market capitalization. The Company estimates the fair values of its reporting units using a combination of the discounted cash flow (DCF) and market approaches. If the carrying amount of a reporting unit exceeds the reporting unit’s fair value, the amount by which the carrying value exceeds the fair value is recognized as an impairment loss. See Note 5 for further details.

[0000950170-24-021098:notes:28]
Intangible Assets

[0000950170-24-021098:notes:29]
Intangible assets include customer relationships, technology, backlog and trade names, which are being amortized over their estimated useful lives on a straight-line basis. The estimated useful lives of such intangibles range from 2 years to 13 years.

[0000950170-24-021098:notes:30]
Impairment of Long-lived Assets

[0000950170-24-021098:notes:31]
Long-lived tangible assets, including property, plant and equipment, assets held for sale, and definite-lived intangible assets, are reviewed for impairment whenever events or changes in circumstances indicate that the carrying value of the asset or asset groups may not be recoverable. The Company regularly evaluates whether events or circumstances have occurred that indicate possible impairment and relies on a number of factors, including expected future operating results, business plans, economic projections, and anticipated future cash flows. The Company uses an estimate of the future undiscounted net cash flows of the related asset or asset group over the remaining life in measuring whether the assets are recoverable. If the sum of the undiscounted cash flows is less than the carrying amount of the net assets, impairment is measured based on the difference between the net asset’s carrying value and estimated fair value. Fair value is determined through various valuation techniques, including cost-based, market and income approaches as considered necessary.

[0000950170-24-021098:notes:32]
The Company classifies assets to be sold as assets held for sale when (i) Company management has approved and commits to a plan to sell the asset; (ii) the asset is available for immediate sale in its present condition and is ready for sale; (iii) an active program to locate a buyer and other actions required to sell the asset have been initiated; (iv) the sale of the asset is probable; (v) the asset is being actively marketed for sale at a price that is reasonable in relation to its current fair value; and (vi) it is unlikely that significant changes to the plan will be made or that the plan will be withdrawn. Assets classified as held for sale are recorded at the lower of the carrying amount or fair value less the cost to sell.

[0000950170-24-021098:notes:33]
The Company classifies assets held for use when a decision to dispose of an asset or a business is made and the held for sale criteria are not met. In evaluating the recoverability of property and intangible assets subject to amortization, in a held for use business, the carrying value is first compared to the sum of the undiscounted cash flows expected to result from the use and eventual disposition. If the carrying value exceeds the undiscounted expected cash flows, then a fair value analysis is performed. An impairment charge is recognized if the carrying value exceeds the fair value.

[0000950170-24-021098:notes:34]
Leases

[0000950170-24-021098:notes:35]
The Company determines if an arrangement is a lease at inception. Operating leases are included in operating lease right-of-use (ROU) assets, and lease liabilities are included in other current liabilities and operating lease liabilities on the consolidated balance sheets. Finance lease ROU assets are included in property, plant and equipment, net and lease liabilities are included in other current liabilities and other long-term liabilities on the consolidated balance sheets.

[0000950170-24-021098:notes:36]
ROU assets represent the Company’s right to use an underlying asset for the lease term and lease liabilities represent the Company’s obligation to make lease payments arising from the lease. Operating and finance lease ROU assets and liabilities are recognized at commencement date based on the present value of lease payments over the lease term. As most of the Company’s leases do not provide an implicit rate, the Company uses its incremental borrowing rate based on the information available at the commencement date in determining the present value of lease payments. The operating and finance lease ROU assets also include any lease payments made and excludes lease incentives. Lease terms may include options to extend or terminate the lease when it is reasonably certain that the Company will exercise that option. Operating lease expense is recognized on a straight-line basis over the lease term. Finance lease expense is recognized based on the effective interest method over the lease term.

[0000950170-24-021098:notes:37]
The Company has lease agreements with lease and non-lease components and accounts for the lease and non-lease components as a single lease component.

[0000950170-24-021098:notes:38]
Revenue Recognition

[0000950170-24-021098:notes:39]
The Company derives revenues primarily from the sale of PCBs, engineered systems using customer-supplied engineering and design plans as well as long-term contracts related to the design and manufacture of highly sophisticated intelligence, surveillance and communications solutions, RF and microwave/microelectronics components, assemblies, and subsystems. In the absence of a sales agreement, the Company’s standard terms and conditions apply. Revenue is recognized when control of the promised goods or services is transferred to the Company’s customers, in an amount that reflects the consideration to which it expects to be entitled in exchange for those goods or services. The Company applies a five-step approach in determining the amount and timing of revenue to be recognized: (1) identifying the contract with a customer; (2) identifying the performance obligations in the contract; (3) determining the transaction price; (4) allocating the transaction price to the performance obligations in the contract; and (5) recognizing revenue when the corresponding performance obligation is satisfied.

[0000950170-24-021098:notes:40]
Revenue Streams

[0000950170-24-021098:notes:41]
For PCBs and engineered systems, including pursuant to the Company’s long-term contracts related to the manufacture of highly sophisticated intelligence, surveillance and communications solutions, components, assemblies and subsystems, orders for products generally correspond to the production schedules of the Company’s customers and are supported with firm purchase orders. The Company’s customers have continuous control of the work in progress and finished goods throughout the PCB and engineered systems manufacturing process, as these are built to customer specifications with no alternative use, and there is an enforceable right to payment for work performed to date. As a result, the Company recognizes revenue progressively over time based on the extent of progress towards completion of the performance obligation. Revenue recognized is based on a cost method as it best depicts the transfer of control to the customer which takes place as we incur costs. Revenues are recorded proportionally as costs are incurred. For contracts in which anticipated total costs exceed the total expected revenue, an estimated loss is recognized in the period when identifiable. A provision for the entire amount of the estimated loss is recorded on a cumulative basis. The estimated remaining costs to complete for loss contracts as of January 1, 2024 and January 2, 2023 were $25,213 and $21,632, respectively, and the provision is recorded as a reduction to gross margin on the consolidated statements of operations.

[0000950170-24-021098:notes:42]
In addition, the Company manufactures components, assemblies, subsystems, and completed systems which service its RF and Specialty Components (RF&S Components) and certain aerospace and defense customers. The Company recognizes revenue at a point in time upon transfer of control of the products to the customer. Point in time recognition was determined as the customer does not simultaneously receive or consume the benefits provided by the Company’s performance and the asset being manufactured has alternative uses to the Company.

[0000950170-24-021098:notes:43]
Performance Obligations

[0000950170-24-021098:notes:44]
Each distinct promise to transfer products is considered to be an identified performance obligation for which revenue is recognized upon transfer of control of the products to the customer. A contract’s transaction price is allocated to each distinct performance obligation and recognized as revenue when, or as, the performance obligation is satisfied. The majority of the Company's contracts have a single performance obligation as the promise to transfer the individual good or service is not separately identifiable from other promises in the contract and is, therefore, not distinct. As of January 1, 2024, the aggregate amount of the transaction price allocated to remaining performance obligations for the Company’s long-term contracts was $382,238. The Company expects to recognize revenue on approximately 51% of the remaining performance obligations for the Company’s long-term contracts over the next twelve months with the remaining amount recognized thereafter. The remaining performance obligations for the Company’s short-term contracts are expected to be recognized within one year.

[0000950170-24-021098:notes:45]
Transaction Price

[0000950170-24-021098:notes:46]
The Company provides customers a limited right of return for defective PCBs including components, subsystems and assemblies. Estimates of returns are treated as variable consideration for purposes of determining the transaction price. The Company accrues an estimate for sales returns and allowances progressively over time based on the extent of progress towards completion of the performance obligation using the Company’s judgment based on historical results and anticipated returns. To the extent actual experience varies from its historical experience, revisions to the sales returns and allowances accrual may be required. Sales returns and allowances are recorded as a reduction of revenue and included as a component of other current liabilities on the consolidated balance sheets. Shipping and handling fees and related freight costs and supplies associated with shipping products to customers are included as a component of cost of goods sold. Warranty-related services are not considered a separate performance obligation. Incremental warranty costs that are not related to sales returns are recorded in other current liabilities on the consolidated balance sheets and cost of goods sold on the consolidated statements of operations. The following summarizes the activity in the Company’s sales returns and allowances for the years ended January 1, 2024, January 2, 2023 and January 3, 2022:

[0000950170-24-021098:notes:47]
|  |  | For the Year Ended |  |
|  |  | January 1, |  |  | January 2, |  |  | January 3, |  |
|  |  | 2024 |  |  | 2023 |  |  | 2022 |  |
|  |  | (In thousands) |  |
| Balance at beginning of year |  | $ | 12,319 |  |  | $ | 12,853 |  |  | $ | 13,015 |  |
| Addition charged as a reduction of sales |  |  | 4,692 |  |  |  | 2,410 |  |  |  | 5,635 |  |
| Deductions |  |  | (4,719 | ) |  |  | (2,914 | ) |  |  | (5,767 | ) |
| Effect of foreign currency exchange rates |  |  | 9 |  |  |  | (30 | ) |  |  | (30 | ) |
| Balance at end of year |  | $ | 12,301 |  |  | $ | 12,319 |  |  | $ | 12,853 |  |

[0000950170-24-021098:notes:48]
Contract Balances

[0000950170-24-021098:notes:49]
Accounts receivable represents the Company’s unconditional right to receive consideration from its customer. Payments are generally due within 90 days or less of invoicing and do not include a significant financing component. To date, there have been no material credit losses on accounts receivable.

[0000950170-24-021098:notes:50]
A contract asset is recognized when the Company has recognized revenue, but not issued an invoice for payment. Amounts will be invoiced when applicable contract terms, such as the achievement of specified milestones or product delivery, are met. Contract assets are transferred to receivables when the entitlement to payment becomes unconditional. Contract assets were $292,050 and $335,788 as of January 1, 2024 and January 2, 2023, respectively, and represent unbilled amounts for work performed to date. Contract assets decreased by $43,738 due to timing of progress on customer work orders at year-end. As of January 1, 2024 and January 2, 2023, $11,257 and $7,096 of contract assets are expected to be collected after one year, respectively, and are included as a component of deposits and other non-current assets on the consolidated balance sheets. In 2023, there were no material impairment losses on contract assets.

[0000950170-24-021098:notes:51]
A contract liability is recognized when the Company has received payment in advance for the future transfer of goods or services. The Company’s contract liabilities are reduced as the contract requirements are fulfilled. Contract liabilities were $126,508 and $103,981 as of January 1, 2024 and January 2, 2023, respectively, and represent customer advances for work yet to be performed. The contract liabilities increased by $22,527 due to timing of customer billings and/or payments. Revenue recognized for year ended January 1, 2024 from amounts recorded as contract liabilities as of January 2, 2023 was $57,937.

[0000950170-24-021098:notes:52]
The Company has elected to account for shipping and handling activities as a fulfillment cost as permitted by the standard. All incremental customer contract acquisition costs are expensed as they are incurred as the amortization period of the asset that the Company otherwise would have recognized is one year or less in duration.

[0000950170-24-021098:notes:53]
Disaggregated Revenue

[0000950170-24-021098:notes:54]
Revenue from products and services transferred to customers over time and at a point in time accounted for 96% and 4%, respectively, of the Company’s revenue in 2023, 97% and 3%, respectively, of the Company’s revenue in 2022 and 2021.

[0000950170-24-021098:notes:55]
The following tables represent a disaggregation of revenue by principal end markets within the reportable segments:

[0000950170-24-021098:notes:56]
|  |  | For the Year Ended January 1, 2024 |  |  |
|  |  | PCB |  |  | RF&S Components |  |  | Total |  |  |
| End Markets |  | (In thousands) |  |  |
| Aerospace and Defense |  | $ | 1,004,864 |  |  | $ | 18 |  |  | $ | 1,004,882 |  |  |
| Automotive |  |  | 359,455 |  |  |  | — |  |  |  | 359,455 |  |  |
| Data Center Computing |  |  | 318,769 |  |  |  | 51 |  |  |  | 318,820 |  |  |
| Medical/Industrial/Instrumentation |  |  | 365,611 |  |  |  | 3,448 |  |  |  | 369,059 |  |  |
| Networking |  |  | 145,347 |  |  |  | 35,004 |  |  |  | 180,351 |  |  |
| Total |  | $ | 2,194,046 |  |  | $ | 38,521 |  |  | $ | 2,232,567 |  |  |

[0000950170-24-021098:notes:57]
|  |  | For the Year Ended January 2, 2023 |  |  |
|  |  | PCB |  |  | RF&S Components |  |  | Total |  |  |
| End Markets |  | (In thousands) |  |  |
| Aerospace and Defense |  | $ | 862,367 |  |  | $ | — |  |  | $ | 862,367 |  |  |
| Automotive |  |  | 428,022 |  |  |  | — |  |  |  | 428,022 |  |  |
| Data Center Computing |  |  | 378,114 |  |  |  | 34 |  |  |  | 378,148 |  |  |
| Medical/Industrial/Instrumentation |  |  | 486,088 |  |  |  | 5,708 |  |  |  | 491,796 |  |  |
| Networking |  |  | 278,911 |  |  |  | 52,414 |  |  |  | 331,325 |  |  |
| Other |  |  | 4,440 |  |  |  | (1,052 | ) |  |  | 3,388 |  |  |
| Total |  | $ | 2,437,942 |  |  | $ | 57,104 |  |  | $ | 2,495,046 |  |  |

[0000950170-24-021098:notes:58]
|  |  | For the Year Ended January 3, 2022 |  |  |
|  |  | PCB |  |  | RF&S Components |  |  | Other (1) |  |  | Total |  |  |
| End Markets |  | (In thousands) |  |  |
| Aerospace and Defense |  | $ | 727,868 |  |  | $ | 137 |  |  | $ | — |  |  | $ | 728,005 |  |  |
| Automotive |  |  | 407,063 |  |  |  | — |  |  |  | 3,642 |  |  |  | 410,705 |  |  |
| Data Center Computing |  |  | 323,528 |  |  |  | 457 |  |  |  | — |  |  |  | 323,985 |  |  |
| Medical/Industrial/Instrumentation |  |  | 416,504 |  |  |  | 4,880 |  |  |  | 25 |  |  |  | 421,409 |  |  |
| Networking |  |  | 297,569 |  |  |  | 49,059 |  |  |  | 1 |  |  |  | 346,629 |  |  |
| Other |  |  | 14,369 |  |  |  | 4,050 |  |  |  | (412 | ) |  |  | 18,007 |  |  |
| Total |  | $ | 2,186,901 |  |  | $ | 58,583 |  |  | $ | 3,256 |  |  | $ | 2,248,740 |  |  |

[0000950170-24-021098:notes:59]
(1)
Other represents results from the now closed SH E-MS and SZ facilities.

[0000950170-24-021098:notes:60]
Value Added and Sales Tax Collected from Customers

[0000950170-24-021098:notes:61]
As a part of the Company’s normal course of business, value added and sales taxes are collected from customers. Such taxes collected are remitted, in a timely manner, to the appropriate governmental tax authority on behalf of the customer. Value added and sales taxes are excluded from reported revenues and costs of goods sold presented in the consolidated statements of operations and comprehensive income.

[0000950170-24-021098:notes:62]
Stock-Based Compensation

[0000950170-24-021098:notes:63]
The Company recognizes stock-based compensation expense in its consolidated financial statements for its incentive compensation plan awards. The incentive compensation plan awards include performance-based restricted stock units, restricted stock units, and stock options. The associated compensation expense for all awards is based on the grant date fair value of the awards. For performance-based restricted stock units, compensation expense also includes management’s periodic assessment of annual financial performance goals to be achieved. Compensation expense for the incentive compensation plan awards is recognized on a straight line basis over the vesting period of the awards. The fair value of performance-based restricted stock units is estimated on the grant date using a Monte Carlo simulation model based on the underlying common stock closing price as of the date of grant, stock price volatility, and risk-free interest rates. The fair value of restricted stock units is measured on the grant date based on the quoted closing market price of the Company’s common stock.

[0000950170-24-021098:notes:64]
Income Taxes

[0000950170-24-021098:notes:65]
Income taxes are accounted for under the asset and liability method. Deferred income tax assets or liabilities are recognized for the future tax consequences attributable to differences between the financial statement carrying amounts of assets and liabilities and their respective tax bases and operating loss and tax credit carryforwards. Deferred income tax assets and liabilities are measured using enacted tax rates expected to apply to taxable income in the years in which those temporary differences are expected to be settled or realized. The effect on deferred income tax assets and liabilities of a change in tax rates is recognized in income in the period that includes the enactment date. Deferred income tax assets are reviewed for recoverability, and the Company records a valuation allowance to reduce its deferred income tax assets when it is more likely than not that all or some portion of the deferred income tax assets will not be realized.

[0000950170-24-021098:notes:66]
The Company has various foreign subsidiaries formed or acquired to conduct or support its business outside the United States. The Company expects its earnings attributable to foreign subsidiaries will not be indefinitely reinvested except for certain subsidiaries, and we have established a deferred tax liability for foreign withholding taxes and the estimated federal/state tax impact. For those other companies with earnings currently being reinvested outside of the U.S., no deferred tax liabilities on undistributed earnings are recorded.

[0000950170-24-021098:notes:67]
The Company recognizes the effect of income tax positions only if those positions are more likely than not to be sustained. Recognized income tax positions are measured at the largest amount that is greater than 50 percent likely to be realized. Changes in recognition or measurement are reflected in the period in which the change in judgment occurs. Estimated interest and penalties related to underpayment of income taxes are recorded as a component of income tax provision in the consolidated statements of operations.

[0000950170-24-021098:notes:68]
Fair Value Measures

[0000950170-24-021098:notes:69]
The Company measures at fair value certain of its financial and non-financial assets and liabilities by using a fair value hierarchy that prioritizes the inputs to valuation techniques used to measure fair value. Fair value is the price that would be received to sell an asset or paid to transfer a liability in an orderly transaction between market participants at the measurement date, essentially an exit price, based on the highest and best use of the asset or liability. The levels of the fair value hierarchy are:

[0000950170-24-021098:notes:70]
Level 1 — Quoted market prices in active markets for identical assets or liabilities;

[0000950170-24-021098:notes:71]
Level 2 — Significant other observable inputs (e.g., quoted prices for similar items in active markets, quoted prices for identical or similar items in markets that are not active, inputs other than quoted prices that are observable, such as interest rate and yield curves, and market-corroborated inputs); and

[0000950170-24-021098:notes:72]
Level 3 — Unobservable inputs in which there is little or no market data, which require the reporting unit to develop its own assumptions.

[0000950170-24-021098:notes:73]
Earnings Per Share

[0000950170-24-021098:notes:74]
Basic earnings per common share excludes dilution and is computed by dividing net income by the weighted average number of common shares outstanding during the period. Diluted earnings per common share reflect the potential dilution that could occur if stock options, or other common stock equivalents were exercised or converted into common stock. The dilutive effect of stock options or other common stock equivalents is calculated using the treasury stock method.

[0000950170-24-021098:notes:75]
Comprehensive Income

[0000950170-24-021098:notes:76]
Comprehensive income includes changes to equity accounts that were not the result of transactions with stockholders. Comprehensive income is comprised of net income, changes in the cumulative foreign currency translation adjustments, pension obligation adjustments, and realized and unrealized gains or losses on hedged derivative instruments.

[0000950170-24-021098:notes:77]
Loss Contingencies

[0000950170-24-021098:notes:78]
The Company establishes an accrual for an estimated loss contingency when it is both probable that an asset has been impaired or that a liability has been incurred and the amount of the loss can be reasonably estimated. Any legal fees expected to be incurred in connection with a contingency are expensed as incurred.

[0000950170-24-021098:notes:79]
Accounting for Retirement Benefit Plans

[0000950170-24-021098:notes:80]
The Company accounts for its retirement benefit plans and postretirement and postemployment benefit obligations in accordance with Accounting Standards Codification (ASC) Topic 715, Compensation—Retirement Benefits. ASC Topic 715 requires the Company to recognize the overfunded or underfunded status of a defined benefit plan, measured as the difference between the fair value of plan assets and the plan's benefit obligation, as an asset or liability in its consolidated balance sheets and to recognize changes to that funded status in the year in which the changes occur through accumulated other comprehensive loss. ASC Topic 715 also requires measurement of the funded status of a plan as of the Company's consolidated balance sheet dates.

[0000950170-24-021098:notes:81]
Recently Adopted and Issued Accounting Standards

[0000950170-24-021098:notes:82]
Recently Adopted Accounting Standards

[0000950170-24-021098:notes:83]
In September 2022, the Financial Accounting Standards Board (FASB) issued Accounting Standards Update (ASU) 2022-04, Liabilities - Supplier Finance Programs (Topic 450-50): Disclosure of Supplier Finance Program Obligations, that requires entities that use supplier finance programs in connection with the purchase of goods and services to disclose the key terms of the programs and information about obligations outstanding at the end of the reporting period, including a rollforward of those obligations. The guidance does not affect the recognition, measurement or financial statement presentation of supplier finance program obligations. The amendments are effective for all entities for fiscal years beginning after December 15, 2022 on a retrospective basis, including interim periods within those fiscal years, except for the requirement to disclose rollforward information, which is effective prospectively for fiscal years beginning after December 15, 2023. The Company adopted ASU 2022-04 as of April 3, 2023. The Company has agreements with financial institutions to facilitate the payments to certain suppliers. Under the terms of the agreements, the Company confirms the validity of each supplier invoice to the respective financial institution upon receipt. The supplier receives payment from the financial institution, and the Company pays the financial institution based on the terms negotiated, which generally range from 160 days to 360 days. Liabilities associated with these agreements are recorded in accounts payable on the consolidated balance sheets and amounted to $18,832 and $6,653 as of January 1, 2024 and January 2, 2023, respectively.

[0000950170-24-021098:notes:84]
In December 2022, the FASB issued ASU 2022-06, Reference Rate Reform (Topic 848): Deferral of the Sunset Date of Topic 848, which deferred the sunset date of Topic 848 to December 31, 2024, after which entities will no longer be permitted to apply the optional expedients and exceptions in Topic 848. On March 23, 2023, the Company entered into a four-year pay-fixed, receive floating (1-month CME Term Secured Overnight Financing Rate (SOFR)), interest rate swap arrangement with a notional amount of $250,000 for the period beginning April 1, 2023 and ending on April 1, 2027. Under the terms of the interest rate swap, the Company pays a fixed rate of 3.49% against a portion of its Term SOFR-based debt and receives a floating 1-month CME Term SOFR during the swap period. The Company elected optional expedients provided in Topic 848 which allowed the designation of the interest rate swap as a cash flow hedge.

[0000950170-24-021098:notes:85]
Recently Issued Accounting Standards Not Yet Adopted

[0000950170-24-021098:notes:86]
In October 2023, the FASB issued ASU 2023-06, Disclosure Improvements: Codification Amendments in Response to the Securities and Exchange Commission’s (SEC) Disclosure Update and Simplification Initiative, which modifies the disclosure or presentation requirements of a variety of topics in the ASC in response to the SEC’s Release No. 33-10532, Disclosure Update and Simplification Initiative, and align the ASC’s requirements with the SEC’s regulations. For entities subject to the SEC's existing disclosure requirements, the effective date for each amendment will be the date on which the SEC's removal of that related disclosure from Regulation S-X or Regulation S-K becomes effective. However, if by June 30, 2027, the SEC has not removed the related disclosure from its regulations, the amendments will be removed from the Codification and not become effective. Early adoption is prohibited. The Company is currently evaluating the new guidance to determine the impact it may have on its consolidated financial statements and related disclosures.

[0000950170-24-021098:notes:87]
In November 2023, the FASB issued ASU 2023-07, Segment Reporting (Topic 280): Improvements to Reportable Segment Disclosures, which updates reportable segment disclosure requirements primarily through enhanced disclosures about significant segment expenses. The amendments are effective for fiscal years beginning after December 15, 2023, and for interim periods within fiscal years beginning after December 15, 2024. Early adoption is permitted. The amendments should be applied retrospectively to all prior periods presented in the financial statements. The Company is currently evaluating the new guidance to determine the impact it may have on its consolidated financial statements and related disclosures, but expects additional disclosures upon adoption.

[0000950170-24-021098:notes:88]
In December 2023, the FASB issued ASU 2023-09, Income Taxes (Topic 740): Improvements to Income Tax Disclosures, which requires disclosure of disaggregated income taxes paid, prescribes standard categories for the components of the effective tax rate reconciliation, and modifies other income tax-related disclosures. The update will be effective for annual periods beginning after December 15, 2024. Early adoption is permitted for annual financial statements not yet issued or made available for issuance. The Company is currently evaluating the new guidance to determine the impact it may have on its consolidated financial statements and related disclosures, but expects additional disclosures upon adoption.


## us-gaap:LesseeOperatingLeasesTextBlock

[0000950170-24-021098:notes:89]
(2)
Leases

[0000950170-24-021098:notes:90]
The Company leases some of its manufacturing and assembly plants, sales offices and equipment under non-cancellable operating leases and finance leases that expire at various dates through 2043. The majority of the Company’s lease arrangements are comprised of fixed payments, and certain leases consist of variable payments based on equipment usage. These variable payments are not included in the measurement of the ROU asset or lease liability due to uncertainty of the payment amount and are recorded as lease expense in the period incurred. Certain leases contain renewal provisions at the Company’s option. Most of the leases require the Company to pay for certain other costs such as property taxes and maintenance. Certain leases also contain rent escalation clauses (step rents) that require additional rental amounts in the later years of the term. Rent expense for leases with step rents is recognized on a straight-line basis over the minimum lease term. The lease agreements do not contain any material residual value guarantees or material restrictive covenants.

[0000950170-24-021098:notes:91]
The components of lease expense were as follows:

[0000950170-24-021098:notes:92]
|  |  | For the Year Ended |  |
|  |  | January 1, 2024 |  |  | January 2, 2023 |  |  | January 3, 2022 |  |
|  |  | (In thousands) |  |
| Operating lease cost |  | $ | 9,527 |  |  | $ | 7,751 |  |  | $ | 7,907 |  |
| Variable lease cost |  |  | 930 |  |  |  | 1,140 |  |  |  | 798 |  |
| Short-term lease cost |  |  | 311 |  |  |  | 708 |  |  |  | 338 |  |
| Finance lease costs: |  |  |  |  |  |  |  |  |  |
| Amortization of right-of-use assets |  |  | 1,374 |  |  |  | 1,374 |  |  |  | 538 |  |
| Interest on lease liabilities |  |  | 373 |  |  |  | 392 |  |  |  | 159 |  |

[0000950170-24-021098:notes:93]
Supplemental cash flow information related to leases was as follows:

[0000950170-24-021098:notes:94]
|  |  | For the Year Ended |  |
|  |  | January 1, 2024 |  |  | January 2, 2023 |  |  | January 3, 2022 |  |
|  |  | (In thousands) |  |
| Cash paid for amounts included in the measurement of lease liabilities: |  |  |  |  |  |  |  |  |  |
| Operating cash flows for operating leases |  | $ | 9,039 |  |  | $ | 7,746 |  |  | $ | 8,308 |  |
| Right-of-use assets obtained in exchange for new lease obligations: |  |  |  |  |  |  |  |  |  |
| Operating leases |  |  | 77,041 |  |  |  | 7,896 |  |  |  | 8,651 |  |
| Finance leases |  |  | — |  |  |  | — |  |  |  | 15,297 |  |

[0000950170-24-021098:notes:95]
Supplemental balance sheet information related to leases was as follows:

[0000950170-24-021098:notes:96]
|  |  |  |  | As of |  |
|  |  | Balance Sheet Location |  | January 1, 2024 |  |  | January 2, 2023 |  |
|  |  |  |  | (In thousands) |  |
| Assets: |  |  |  |  |  |  |  |  |
| Operating leases |  | Operating lease right-of-use assets |  | $ | 86,286 |  |  | $ | 18,862 |  |
| Finance leases |  | Property, plant and equipment, net |  |  | 12,010 |  |  |  | 13,384 |  |
| Total lease assets |  |  |  | $ | 98,296 |  |  | $ | 32,246 |  |
| Liabilities: |  |  |  |  |  |  |  |  |
| Current: |  |  |  |  |  |  |  |  |
| Operating leases |  | Other current liabilities |  | $ | 8,433 |  |  | $ | 7,368 |  |
| Finance leases |  | Other current liabilities |  |  | 780 |  |  |  | 736 |  |
| Long-term: |  |  |  |  |  |  |  |  |
| Operating leases |  | Operating lease liabilities |  |  | 80,786 |  |  |  | 12,249 |  |
| Finance leases |  | Other long-term liabilities |  |  | 12,799 |  |  |  | 13,579 |  |
| Total lease liabilities |  |  |  | $ | 102,798 |  |  | $ | 33,932 |  |

[0000950170-24-021098:notes:97]
|  |  | As of |  |
|  |  | January 1, 2024 |  |  | January 2, 2023 |  |
| Weighted average remaining lease term (years): |  |  |  |  |  |  |
| Operating leases |  | 12.8 |  |  | 3.3 |  |
| Finance leases |  | 12.6 |  |  | 13.6 |  |
| Weighted average discount rate: |  |  |  |  |  |  |
| Operating leases |  |  | 6.13 | % |  |  | 3.09 | % |
| Finance leases |  |  | 2.69 | % |  |  | 2.69 | % |

[0000950170-24-021098:notes:98]
Maturities of lease liabilities were as follows:

[0000950170-24-021098:notes:99]
|  |  | OperatingLeases (1) |  |  | FinanceLeases |  |
|  |  | (In thousands) |  |
| Less than one year |  | $ | 13,533 |  |  | $ | 1,134 |  |
| 1 - 2 years |  |  | 11,418 |  |  |  | 1,146 |  |
| 2 - 3 years |  |  | 9,280 |  |  |  | 1,175 |  |
| 3 - 4 years |  |  | 7,986 |  |  |  | 1,197 |  |
| 4 - 5 years |  |  | 7,630 |  |  |  | 1,228 |  |
| Thereafter |  |  | 85,018 |  |  |  | 10,231 |  |
| Total lease payments |  |  | 134,865 |  |  |  | 16,110 |  |
| Less imputed interest |  |  | (45,646 | ) |  |  | (2,531 | ) |
| Total |  | $ | 89,219 |  |  | $ | 13,579 |  |

[0000950170-24-021098:notes:100]
(1)
Excludes $817 of legally binding minimum lease payments for leases signed but not yet commenced.


## us-gaap:BusinessCombinationDisclosureTextBlock

[0000950170-24-021098:notes:101]
(3)
Acquisition of Gritel and ISC Farmingdale Corp.

[0000950170-24-021098:notes:102]
On June 27, 2022, the Company completed its acquisition of all of the issued and outstanding capital stock of Gritel and ISC Farmingdale Corp. for a total consideration of $298,339 in cash. At the time of acquisition, Telephonics Corporation was wholly-owned by Gritel, and as a result of the acquisition, became an indirect, wholly-owned subsidiary of the Company (collectively with ISC Farmingdale Corp., Telephonics).

[0000950170-24-021098:notes:103]
For the years ended January 1, 2024 and January 2, 2023, bank fees and legal, accounting, and other professional service costs associated with the acquisition of $598 and $11,529, respectively, have been expensed and recorded as general and administrative expense in the consolidated statements of operations. There were no bank fees or legal, accounting, or other professional service costs associated with the acquisition for the year ended January 3, 2022.

[0000950170-24-021098:notes:104]
Purchase Price Allocation

[0000950170-24-021098:notes:105]
The purchase price was allocated to tangible and intangible assets acquired, and liabilities assumed based on the fair value at the date of the acquisition, June 27, 2022. The excess of the purchase price over the fair value of net assets acquired was allocated to

[0000950170-24-021098:notes:106]
goodwill. The fair values were based on management’s analysis, including work performed by third-party valuation specialists. The Company finalized the allocation of the purchase price during the second quarter of 2023.

[0000950170-24-021098:notes:107]
The fair values assigned are based on reasonable methods applicable to the nature of the assets acquired and liabilities assumed. The following summarizes the final assigned fair values of net assets acquired:

[0000950170-24-021098:notes:108]
|  |  | (In thousands) |  |  |
| Accounts receivable |  | $ | 51,140 |  |  |
| Contract assets |  |  | 26,460 |  |  |
| Inventories |  |  | 38,616 |  |  |
| Prepaid expenses and other current assets |  |  | 5,605 |  |  |
| Property, plant and equipment |  |  | 69,253 |  |  |
| Operating lease right-of-use assets |  |  | 497 |  |  |
| Goodwill |  |  | 112,326 |  |  |
| Identifiable intangible assets |  |  | 101,000 |  |  |
| Non-current deferred tax assets |  |  | 913 |  |  |
| Deposits and other non-current assets |  |  | 3,129 |  |  |
| Accounts payable |  |  | (16,026 | ) |  |
| Contract liabilities |  |  | (65,262 | ) |  |
| Accrued salaries, wages and benefits |  |  | (10,616 | ) |  |
| Other current liabilities |  |  | (12,751 | ) |  |
| Operating lease liabilities |  |  | (336 | ) |  |
| Other long-term liabilities |  |  | (5,609 | ) |  |
| Total |  | $ | 298,339 |  |  |

[0000950170-24-021098:notes:109]
Identifiable Intangible Assets

[0000950170-24-021098:notes:110]
Acquired identifiable intangible assets include customer relationships, technology, backlog, and trade names. The fair value of the identifiable intangible assets was determined using various valuation methods including relief from royalty and excess earnings to determine the present value of expected future cash flows for each identifiable intangible asset based on discount rates. The expected cash flows were estimated using available historical data adjusted based on a market participant perspective. The Company used risk adjusted discount rates between 7.0% and 8.0% to discount the expected future cash flows.

[0000950170-24-021098:notes:111]
The Company finalized the acquired identifiable intangible asset valuation during the second quarter of 2023. The Company recorded amortization expense of $24,877 related to the acquired identifiable intangible assets during the year ended January 1, 2024 (of which $5,627 corresponded to the year ended January 2, 2023 due to the change in amortization period). For the year ended January 1, 2024, $8,850 of amortization expense is included in cost of goods sold (of which $2,950 corresponded to the year ended January 2, 2023).

[0000950170-24-021098:notes:112]
Goodwill represents the excess of the purchase price over the fair value of assets acquired and liabilities assumed. The Company believes that the acquisition of Telephonics will strengthen the Company’s differentiated position in the Aerospace and Defense market. The Company believes that these factors support the amount of goodwill recognized as a result of the purchase price paid for Telephonics, in relation to other acquired tangible and intangible assets. The goodwill acquired in the acquisition is not deductible for income tax purposes.

[0000950170-24-021098:notes:113]
Results of Operations

[0000950170-24-021098:notes:114]
Included in the consolidated statements of operations are net sales of $223,287 and $125,933, excluding intercompany sales, for the years ended January 1, 2024 and January 2, 2023, respectively. Included in the consolidated statements of operations are pre-tax income of $24,965 and $10,822, excluding amortization of intangibles, for the years ended January 1, 2024 and January 2, 2023, respectively.

[0000950170-24-021098:notes:115]
Pro forma Financial Information (Unaudited)

[0000950170-24-021098:notes:116]
The unaudited pro forma financial information below gives effect to this acquisition as if it had occurred at the beginning of fiscal 2022, or January 4, 2022. The pro forma financial information presented includes the effects of adjustments related to the amortization of acquired identifiable intangible assets, decrease in inventory markup, depreciation of acquired fixed assets, and other non-recurring transactions costs directly associated with the acquisition such as legal, accounting and banking fees.

[0000950170-24-021098:notes:117]
The pro forma financial information as presented below is for informational purposes only and is not necessarily indicative of the actual results that would have been achieved had the acquisition occurred at the beginning of the earliest period presented, or the results that may be achieved in future periods.

[0000950170-24-021098:notes:118]
|  |  | For the Year Ended |  |
|  |  | January 1, 2024 |  |  | January 2, 2023 |  |
|  |  | (In thousands, except per share amounts) |  |
| Net sales |  | $ | 2,232,567 |  |  | $ | 2,602,114 |  |
| Net (loss) income |  |  | (13,091 | ) |  |  | 94,952 |  |
| Basic (loss) earnings per share |  | $ | (0.13 | ) |  | $ | 0.93 |  |
| Diluted (loss) earnings per share |  | $ | (0.13 | ) |  | $ | 0.91 |  |


## us-gaap:AdditionalFinancialInformationDisclosureTextBlock

[0000950170-24-021098:notes:119]
(4)
Composition of Certain Consolidated Financial Statement Captions

[0000950170-24-021098:notes:120]
|  |  | As of |  |
|  |  | January 1, 2024 |  |  | January 2, 2023 |  |
|  |  | (In thousands) |  |
| Inventories: |  |  |  |  |  |  |
| Raw materials |  | $ | 165,666 |  |  | $ | 145,561 |  |
| Work-in-process |  |  | 45,494 |  |  |  | 20,114 |  |
| Finished goods |  |  | 1,915 |  |  |  | 4,964 |  |
|  |  | $ | 213,075 |  |  | $ | 170,639 |  |
| Property, plant and equipment, net: |  |  |  |  |  |  |
| Land and land use rights |  | $ | 71,131 |  |  | $ | 76,811 |  |
| Buildings and improvements |  |  | 512,148 |  |  |  | 443,353 |  |
| Machinery and equipment |  |  | 986,527 |  |  |  | 989,935 |  |
| Furniture and fixtures and other |  |  | 10,157 |  |  |  | 11,327 |  |
| Construction-in-progress |  |  | 90,940 |  |  |  | 27,774 |  |
|  |  |  | 1,670,903 |  |  |  | 1,549,200 |  |
| Less: Accumulated depreciation |  |  | (863,236 | ) |  |  | (824,996 | ) |
|  |  | $ | 807,667 |  |  | $ | 724,204 |  |
| Other current liabilities: |  |  |  |  |  |  |
| Accrued capital expenditures |  | $ | 35,026 |  |  | $ | — |  |
| Sales return and allowances |  |  | 12,301 |  |  |  | 12,319 |  |
| Warranty |  |  | 10,557 |  |  |  | 8,045 |  |
| Accrued facility operating costs |  |  | 10,172 |  |  |  | 9,081 |  |
| Interest |  |  | 9,399 |  |  |  | 9,336 |  |
| Operating leases |  |  | 8,433 |  |  |  | 7,368 |  |
| Housing fund |  |  | 7,749 |  |  |  | 7,440 |  |
| Income taxes payable |  |  | 5,466 |  |  |  | 28,057 |  |
| Accrued professional fees |  |  | 3,276 |  |  |  | 5,123 |  |
| Restructuring |  |  | 1,179 |  |  |  | 2,513 |  |
| Derivative liabilities |  |  | 297 |  |  |  | 1,622 |  |
| Other |  |  | 36,951 |  |  |  | 39,128 |  |
|  |  | $ | 140,806 |  |  | $ | 130,032 |  |
| Other long-term liabilities: |  |  |  |  |  |  |
| Deferred income taxes |  | $ | 44,238 |  |  | $ | 54,268 |  |
| Customer deposits |  |  | 29,820 |  |  |  | 38,750 |  |
| Finance leases |  |  | 12,799 |  |  |  | 13,579 |  |
| Derivative liabilities |  |  | 1,476 |  |  |  | — |  |
| Defined benefit pension plan liability |  |  | 836 |  |  |  | 2,471 |  |
| Other |  |  | 24,349 |  |  |  | 25,976 |  |
|  |  | $ | 113,518 |  |  | $ | 135,044 |  |

[0000950170-24-021098:notes:121]
On December 22, 2022, land, building, and relevant ancillary assets related to the Company’s former Shanghai E-MS (SH E-MS) manufacturing facility was expropriated by the Chinese government for a compensation fee of RMB 477.6 million ($69,240 as of

[0000950170-24-021098:notes:122]
January 2, 2023) generating a gain on the sale of $51,804 during the year ended January 2, 2023. The Company received 90% of the proceeds from the sale during 2023 and the remaining 10% was collected subsequent to year-end.


## us-gaap:GoodwillDisclosureTextBlock

[0000950170-24-021098:notes:123]
(5)
Goodwill

[0000950170-24-021098:notes:124]
As of January 1, 2024 and January 2, 2023, goodwill by reportable segment was as follows:

[0000950170-24-021098:notes:125]
|  |  | PCB |  | RF&S Components |  | Total |  |
|  |  | (In thousands) |  |
| Balance as of January 2, 2023 |  |  |  |  |  |  |  |
| Goodwill |  | $ | 823,837 |  | $ | 177,200 |  | $ | 1,001,037 |  |
| Accumulated impairment losses |  |  | (171,400 | ) |  | (69,200 | ) |  | (240,600 | ) |
|  |  |  | 652,437 |  |  | 108,000 |  |  | 760,437 |  |
| Impairment loss during the year ended January 1, 2024 |  |  | — |  |  | (44,100 | ) |  | (44,100 | ) |
| Goodwill adjustment during the year ended January 1, 2024 |  |  | (10,787 | ) |  | — |  |  | (10,787 | ) |
| Derecognition of goodwill due to sale of subsidiary |  |  | (2,815 | ) |  | — |  |  | (2,815 | ) |
| Balance as of January 1, 2024 |  |  |  |  |  |  |  |
| Goodwill |  |  | 810,235 |  |  | 177,200 |  |  | 987,435 |  |
| Accumulated impairment losses |  |  | (171,400 | ) |  | (113,300 | ) |  | (284,700 | ) |
|  |  | $ | 638,835 |  | $ | 63,900 |  | $ | 702,735 |  |

[0000950170-24-021098:notes:126]
The Company evaluates its goodwill on an annual basis during its fourth fiscal quarter and at other times when events or changes in circumstances – such as significant adverse changes in the business climate or operating results or changes in management strategy, coupled with a decline in the market price of its stock and market capitalization – indicate that there may be a potential impairment. The Company assesses qualitative factors to determine whether it is more likely than not that the fair value of a reporting unit is less than its carrying amount or performs a quantitative impairment test.

[0000950170-24-021098:notes:127]
During the third quarter of 2023, the Company experienced a continued decline in sales and profitability in the RF&S Components reporting unit and have reduced forecasted sales in future years. The Company considered these factors to be indicators of potential impairment requiring the Company to test the related goodwill for impairment. As of October 2, 2023, the Company completed a quantitative goodwill impairment analysis related to its RF&S Components reporting unit by comparing the fair value of the reporting unit with its carrying amount. In making this assessment, management relies on a number of factors, including expected future operating results, business plans, economic projections, anticipated future cash flows, business trends and declines in the Company’s market capitalization. The Company determined the fair value of the reporting unit by using both a DCF and a market approach. Under the market approach, the Company used revenue and earnings multiples based on comparable industry multiples to estimate the fair value of the reporting unit. If the carrying amount of a reporting unit exceeds the reporting unit’s fair value, the amount by which the carrying value exceeds the fair value is recognized as an impairment loss.

[0000950170-24-021098:notes:128]
Under the DCF approach, the Company estimated the future cash flows, as well as selected a risk-adjusted discount rate to measure the present value of the anticipated cash flows. When determining future cash flow estimates, the Company considered historical results adjusted to reflect current and anticipated future operating conditions. The Company estimated cash flows for the reporting unit over a discrete period and a terminal period (considering expected long-term growth rates and trends).

[0000950170-24-021098:notes:129]
Based on its analysis, the Company determined that the fair value of the RF&S Components reporting unit was less than its carrying value and recorded a non-cash goodwill impairment charge of $44,100 during the year ended January 1, 2024. If the Company's future cash flow projections and other fair value assumptions for its reporting unit change, the Company’s goodwill may be subject to potential additional impairment charges in subsequent quarters. Estimating the fair value of the reporting unit requires the Company to make assumptions and estimates in such areas as future economic conditions, industry-specific conditions, product pricing, and necessary capital expenditures. The use of different assumptions or estimates for future cash flows, discount rates, or terminal growth rates could produce substantially different estimates of the fair value of the reporting unit.

[0000950170-24-021098:notes:130]
In addition, the Company decreased goodwill by $10,787 during the year ended January 1, 2024 due to an adjustment to the estimate of fair value for identifiable intangible assets and deferred taxes. Goodwill recognized as a result of the acquisition of Telephonics was finalized during the second quarter of 2023. See Note 3, Acquisition of Gritel and ISC Farmingdale Corp., for further information.

[0000950170-24-021098:notes:131]
In the fourth quarter of 2023, the Company performed its annual goodwill impairment test qualitatively and concluded that it was more likely than not that there was no impairment to goodwill.


## us-gaap:IntangibleAssetsDisclosureTextBlock

[0000950170-24-021098:notes:132]
(6)
Definite-lived Intangibles

[0000950170-24-021098:notes:133]
As of January 1, 2024 and January 2, 2023, the components of definite-lived intangibles were as follows:

[0000950170-24-021098:notes:134]
|  |  | GrossAmount |  |  | AccumulatedAmortization |  |  | NetCarryingAmount |  |  | WeightedAverageAmortizationPeriod |  |
|  |  | (In thousands) |  |  | (In years) |  |
| January 1, 2024 |  |  |  |  |  |  |  |  |  |  |  |  |
| Customer relationships |  | $ | 416,230 |  |  | $ | (222,766 | ) |  | $ | 193,464 |  |  |  | 11.2 |  |
| Technology |  |  | 66,650 |  |  |  | (27,278 | ) |  |  | 39,372 |  |  |  | 8.2 |  |
| Backlog |  |  | 13,000 |  |  |  | (9,750 | ) |  |  | 3,250 |  |  |  | 2.0 |  |
| Trade names |  |  | 2,500 |  |  |  | (1,875 | ) |  |  | 625 |  |  |  | 2.0 |  |
|  |  | $ | 498,380 |  |  | $ | (261,669 | ) |  | $ | 236,711 |  |  |  |  |
| January 2, 2023 |  |  |  |  |  |  |  |  |  |  |  |  |
| Customer relationships |  | $ | 366,071 |  |  | $ | (187,560 | ) |  | $ | 178,511 |  |  |  | 11.3 |  |
| Technology |  |  | 47,650 |  |  |  | (24,876 | ) |  |  | 22,774 |  |  |  | 9.5 |  |
| Acquired intangibles from acquisition |  |  |  |  |  |  |  |  |  |  |  |  |
| Customer relationships |  |  | 82,500 |  |  |  | (3,173 | ) |  |  | 79,327 |  |  |  | 13.0 |  |
| Trade names |  |  | 8,250 |  |  |  | (825 | ) |  |  | 7,425 |  |  |  | 5.0 |  |
|  |  | $ | 504,471 |  |  | $ | (216,434 | ) |  | $ | 288,037 |  |  |  |  |

[0000950170-24-021098:notes:135]
The Company has acquired customer relationships, technology, backlog and trade names as a result of the Telephonics acquisition. See Note 3, Acquisition of Gritel and ISC Farmingdale Corp., for further information.

[0000950170-24-021098:notes:136]
Definite-lived intangibles are amortized using the straight-line method of amortization over the useful life. Amortization expense was $61,576, $42,631 and $41,389 for the years ended January 1, 2024, January 2, 2023 and January 3, 2022, respectively. For the years ended January 1, 2024, January 2, 2023 and January 3, 2022, $12,901, $5,534 and $5,641, respectively, of amortization expense is included in cost of goods sold.

[0000950170-24-021098:notes:137]
Estimated aggregate amortization for definite-lived intangible assets for the next five years and thereafter is as follows:

[0000950170-24-021098:notes:138]
|  |  | (In thousands) |  |
| 2024 |  | $ | 44,892 |  |
| 2025 |  |  | 36,897 |  |
| 2026 |  |  | 36,897 |  |
| 2027 |  |  | 34,543 |  |
| 2028 |  |  | 30,997 |  |
| Thereafter |  |  | 52,485 |  |
|  |  | $ | 236,711 |  |


## us-gaap:LongTermDebtTextBlock

[0000950170-24-021098:notes:139]
(7)
Long-term Debt and Letters of Credit

[0000950170-24-021098:notes:140]
The following table summarizes the long-term debt of the Company as of January 1, 2024 and January 2, 2023:

[0000950170-24-021098:notes:141]
|  |  | Interest Rate as ofJanuary 1, 2024 |  |  | PrincipalOutstandingas ofJanuary 1, 2024 |  |  | Interest Rate as ofJanuary 2, 2023 |  |  | PrincipalOutstandingas ofJanuary 2, 2023 |  |
|  |  | (In thousands, except interest rates) |  |
| Senior Notes due March 2029 |  |  | 4.00 |  | % | $ | 500,000 |  |  |  | 4.00 |  | % | $ | 500,000 |  |
| Term Loan due May 2030 |  |  | 8.10 |  |  |  | 349,125 |  |  |  | — |  |  |  | — |  |
| Asia ABL Revolving Loan due June 2028 |  |  | 6.65 |  |  |  | 80,000 |  |  |  | 5.79 |  |  |  | 30,000 |  |
| Term Loan due September 2024 |  |  | — |  |  |  | — |  |  |  | 6.89 |  |  |  | 405,879 |  |
|  |  |  |  |  |  | 929,125 |  |  |  |  |  |  | 935,879 |  |
| Less: Unamortized debt issuance costs |  |  |  |  |  | (8,021 | ) |  |  |  |  |  | (6,080 | ) |
| Unamortized debt discount |  |  |  |  |  | (3,268 | ) |  |  |  |  |  | (392 | ) |
|  |  |  |  |  |  | 917,836 |  |  |  |  |  |  | 929,407 |  |
| Less: current maturities |  |  |  |  |  | (3,500 | ) |  |  |  |  |  | (50,000 | ) |
| Long-term debt, less current maturities |  |  |  |  | $ | 914,336 |  |  |  |  |  | $ | 879,407 |  |

[0000950170-24-021098:notes:142]
The fiscal calendar maturities of debt through 2028 and thereafter are as follows:

[0000950170-24-021098:notes:143]
|  |  | (In thousands) |  |
| 2024 |  | $ | 3,500 |  |
| 2025 |  |  | 3,500 |  |
| 2026 |  |  | 3,500 |  |
| 2027 |  |  | 4,375 |  |
| 2028 |  |  | 83,500 |  |
| Thereafter |  |  | 830,750 |  |
|  |  | $ | 929,125 |  |

[0000950170-24-021098:notes:144]
As of January 1, 2024, the Company was in compliance with the financial covenants under the Senior Notes due 2029, Term Loan Facility and ABL Revolving Loans.

[0000950170-24-021098:notes:145]
Senior Notes due 2029

[0000950170-24-021098:notes:146]
On March 10, 2021, the Company issued $500,000 of Senior Notes due 2029, which are included in long-term debt and bear interest at a rate of 4.0% per annum. Interest is payable semiannually in arrears on March 1 and September 1 of each year beginning September 1, 2021. The Senior Notes due 2029 will mature on March 1, 2029.

[0000950170-24-021098:notes:147]
The Senior Notes due 2029 are irrevocably and unconditionally guaranteed, jointly and severally, on a senior unsecured basis by the Company’s existing and future domestic subsidiaries, subject to certain exceptions. The Senior Notes due 2029 and related guarantees are senior unsecured obligations of, respectively, the Company and applicable subsidiary guarantors.

[0000950170-24-021098:notes:148]
Term Loan Facility

[0000950170-24-021098:notes:149]
On May 30, 2023, pursuant to an Amended & Restated Term Loan Credit Agreement by and among the Company, JPMorgan Chase Bank, N.A., as Administrative Agent, and the several lenders from time to time parties thereto (Term Loan Credit Agreement), the Company closed its $350,000 senior secured Term Loan due 2030 (Term Loan Facility). This Term Loan Facility had an outstanding balance of $349,125 as of January 1, 2024, of which $3,500 is included in short-term debt and $345,625 is included in long-term debt. The Term Loan Facility was issued with a 1.0% original issue discount and bears interest at a floating rate of 1-month CME Term SOFR plus an applicable margin of 2.75%. There is no provision, other than an event of default, for the interest margin to increase. The Company is required to make quarterly principal repayments in an aggregate annual amount equal to 1% of the initial aggregate principal amount of the Term Loan Facility. Such principal repayment is payable quarterly on January 1, April 1, July 1, and October 1 and ending with the last such day to occur prior to May 30, 2030. The remaining principal under the Term Loan Facility is scheduled to mature on May 30, 2030. In addition, the Term Loan Credit Agreement permits the Company to add one or more senior secured incremental term loan facilities to the Term Loan Facility subject to the satisfaction of certain conditions.

[0000950170-24-021098:notes:150]
The Company used $234,818 under the Term Loan Facility and $115,182 of cashless rollover from continuing lenders, together with cash on hand, to refinance the full amount of indebtedness outstanding under the Company’s previous Term Loan Facility that was due to mature in 2024, as well as to pay related fees and expenses.

[0000950170-24-021098:notes:151]
The obligations under the Term Loan Facility are unconditionally guaranteed by each Subsidiary Guarantor of the Company, subject to certain exceptions (Guarantors). The Term Loan Facility is secured by (i) a perfected first priority security interest in substantially all of the assets of the Company and the Guarantors (other than the U.S. ABL Priority Collateral (as defined below)), including all of the total outstanding voting capital stock held by the Company and the Guarantors (subject to a limitation of 65% on pledges of such capital stock of certain foreign subsidiaries and domestic holding companies of foreign subsidiaries) and (ii) a perfected second priority interest in all of the U.S. ABL Priority Collateral. The Term Loan Facility is structurally senior to the Company’s Senior Notes due 2029.

[0000950170-24-021098:notes:152]
Based on certain parameters defined in the Term Loan Facility, including a Secured Leverage Ratio, the Company may be required to make an additional principal payment on an annual basis if its Secured Leverage Ratio is greater than 2.0.

[0000950170-24-021098:notes:153]
Borrowings under the Term Loan Credit Agreement are subject to certain affirmative and negative covenants, including limitations on indebtedness, corporate transactions, investments, dispositions, and share payments.

[0000950170-24-021098:notes:154]
Asset-Based Lending Agreements

[0000950170-24-021098:notes:155]
The Company amended and restated its U.S. Asset-Based Lending Credit Agreement (U.S. ABL) on May 30, 2023 and its Asia Asset-Based Lending Credit Agreement (Asia ABL) on June 14, 2023. Both agreements were amended for the benchmark interest rate and margins and maturity was extended to May 2028 and June 2028 for the U.S. ABL and the Asia ABL (collectively the ABL Revolving Loans), respectively.

[0000950170-24-021098:notes:156]
The U.S. ABL is comprised of a revolving credit facility for up to $150,000 and a sublimit for letter of credit for up to $50,000, provided that at no time may amounts outstanding under the agreement exceed in the aggregate $150,000 or the applicable borrowing base, which is the sum of (i) a percentage of the principal amount of “Eligible Accounts”, plus (ii) a percentage of the net orderly liquidation value of (x) “Eligible Inventory”, minus (y) “Inventory Reserves” applicable thereto, minus (iii) “Reserves”, each as defined in the U.S. ABL agreement. Borrowings under the U.S. ABL bear interest at a floating rate of Term SOFR plus a margin ranging from 1.25% to 1.50%. The applicable margin can vary based on the remaining availability of the facility, from 1.25% to 1.50% for Term SOFR-based loans and from 0.25% to 0.50% for JPMorgan Chase Bank’s prime rate-based loans. Other than availability and an event of default, there are no other provisions for the interest margin to increase.

[0000950170-24-021098:notes:157]
The U.S. ABL is scheduled to mature on May 30, 2028. The Guarantors have also fully guaranteed the full and timely payment of all obligations in respect of the U.S. ABL. Loans made under the U.S. ABL are secured by a perfected first priority security interest in certain deposit accounts, cash and cash equivalents, accounts receivable and certain U.S. inventory (U.S. ABL Priority Collateral) as well as by a perfected second priority interest in all of the collateral securing the Term Loan Facility.

[0000950170-24-021098:notes:158]
The Asia ABL is comprised of a revolving credit facility for up to $150,000 and a sublimit for letter of credit for up to $100,000, provided that at no time may amounts outstanding under the agreement exceed in aggregate $150,000 or the applicable borrowing base, which is a percentage of the principal amount of Eligible Accounts, as defined in the Asia ABL agreement. Borrowings under the Asia ABL bear interest at a floating rate of Term SOFR plus 1.30%. There is no provision, other than an event of default, for the interest margin to increase. As of January 1, 2024, the interest rate on the outstanding borrowings under the Asia ABL was 6.65%. As of January 1, 2024, $80,000 under the Asia ABL was outstanding and classified as long-term debt, which is consistent with its maturity date.

[0000950170-24-021098:notes:159]
The Asia ABL is scheduled to mature on June 13, 2028. Loans made under the Asia ABL are secured by a portion of the Company’s Asia Pacific cash and receivables and are structurally senior to the Company’s domestic obligations, including the Senior Notes due 2029.

[0000950170-24-021098:notes:160]
As of January 1, 2024, letters of credit in the amount of $6,928 were outstanding under the U.S. ABL and $23,977 were outstanding under the Asia ABL with various maturities through March 2025. Available borrowing capacity under the U.S. ABL and the Asia ABL was $143,072 and $46,023 respectively, which considers letters of credit outstanding as of January 1, 2024.

[0000950170-24-021098:notes:161]
The Company is required to pay a commitment fee of 0.25% per annum on any unused portion of the ABL Revolving Loans. The Company incurred total commitment fees related to unused borrowing availability of $620, $661 and $663 for the years ended January 1, 2024, January 2, 2023 and January 3, 2022, respectively. Under the occurrence of certain events, the ABL Revolving Loans are subject to various financial covenants, including leverage and fixed charge coverage ratios.

[0000950170-24-021098:notes:162]
Debt Issuance Costs and Debt Discount

[0000950170-24-021098:notes:163]
As of January 1, 2024 and January 2, 2023, remaining unamortized debt issuance costs and debt discount for the Senior Notes due 2029 and Term Loan Facility are as follows:

[0000950170-24-021098:notes:164]
|  |  | As of January 1, 2024 |  |  | As of January 2, 2023 |
|  |  | DebtIssuance Costs |  |  | DebtDiscount |  |  | EffectiveInterest Rate |  |  | DebtIssuance Costs |  |  | DebtDiscount |  |  | EffectiveInterest Rate |  |  |
|  |  | (In thousands, except interest rates) |
| Senior Notes due March 2029 |  | $ | 4,085 |  |  | $ | — |  |  |  | 4.18 |  | % | $ | 4,779 |  |  | $ | — |  |  |  | 4.18 |  | % |
| Term Loan due May 2030 |  |  | 3,936 |  |  |  | 3,268 |  |  |  | 8.26 |  |  |  | — |  |  |  | — |  |  |  | — |  |  |
| Term Loan due September 2024 |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 1,301 |  |  |  | 392 |  |  |  | 4.66 |  |  |
|  |  | $ | 8,021 |  |  | $ | 3,268 |  |  |  |  |  | $ | 6,080 |  |  | $ | 392 |  |  |  |  |  |

[0000950170-24-021098:notes:165]
The above debt issuance costs and debt discount are recorded as a reduction of the debt and are amortized into interest expense using an effective interest rate over the duration of the debt.

[0000950170-24-021098:notes:166]
Remaining unamortized debt issuance costs for the ABL Revolving Loans of $1,603 and $792 as of January 1, 2024 and January 2, 2023, respectively, are included in other non-current assets and are amortized to interest expense over the duration of the ABL Revolving Loans using the straight line method of amortization.

[0000950170-24-021098:notes:167]
As of January 1, 2024, the remaining weighted average amortization period for all unamortized debt issuance costs and debt discount was 5.8 years.

[0000950170-24-021098:notes:168]
Loss on Extinguishment of Debt

[0000950170-24-021098:notes:169]
During the year ended January 1, 2024, the Company recognized loss on extinguishment of debt of $1,154, primarily associated with the write-off of the remaining unamortized debt issuance costs and debt discount as a result of the repayment of the remaining outstanding balance of the Term Loan Facility that was due to mature September 2024. During the year ended January 2, 2023, the Company recognized losses of $15,217 associated with the premium paid on extinguishment of debt and the write-off of the remaining unamortized debt issuance costs as a result of the repayment of the remaining outstanding balance of the Senior Notes due 2025.


## us-gaap:IncomeTaxDisclosureTextBlock

[0000950170-24-021098:notes:170]
(8)
Income Taxes

[0000950170-24-021098:notes:171]
The components of income before income taxes for the years ended January 1, 2024, January 2, 2023 and January 3, 2022 are:

[0000950170-24-021098:notes:172]
|  |  | For the Year Ended |  |
|  |  | January 1,2024 |  |  | January 2,2023 |  |  | January 3,2022 |  |
|  |  | (In thousands) |  |
| United States |  | $ | (105,101 | ) |  | $ | (52,468 | ) |  | $ | (28,057 | ) |
| Foreign |  |  | 105,398 |  |  |  | 235,331 |  |  |  | 98,110 |  |
| Income before income taxes |  | $ | 297 |  |  | $ | 182,863 |  |  | $ | 70,053 |  |

[0000950170-24-021098:notes:173]
The Company expects its earnings attributable to foreign subsidiaries will not be indefinitely reinvested, except for certain subsidiaries, and the Company has established a deferred tax liability of approximately $6,154 and $982 for the foreign and U.S. federal/state impact, respectively. For those other companies with earnings currently being reinvested outside of the U.S., the undistributed earnings amounted to approximately $60,769 as of January 1, 2024. The determination of the unrecognized deferred tax liability related to these undistributed earnings is approximately $2,703.

[0000950170-24-021098:notes:174]
The components of income tax provision for the years ended January 1, 2024, January 2, 2023 and January 3, 2022 are:

[0000950170-24-021098:notes:175]
|  |  | For the Year Ended |  |
|  |  | January 1,2024 |  |  | January 2,2023 |  |  | January 3,2022 |  |
|  |  | (In thousands) |  |
| Current (provision) benefit: |  |  |  |  |  |  |  |  |  |
| Federal |  | $ | 445 |  |  | $ | (2,591 | ) |  | $ | (1,125 | ) |
| State |  |  | (1,592 | ) |  |  | (1,812 | ) |  |  | 547 |  |
| Foreign |  |  | (29,094 | ) |  |  | (23,453 | ) |  |  | (9,211 | ) |
| Total current |  |  | (30,241 | ) |  |  | (27,856 | ) |  |  | (9,789 | ) |
| Deferred (provision) benefit: |  |  |  |  |  |  |  |  |  |
| Federal |  |  | 1,321 |  |  |  | (29,093 | ) |  |  | 2,889 |  |
| State |  |  | 271 |  |  |  | (3,905 | ) |  |  | (1,492 | ) |
| Foreign |  |  | 9,634 |  |  |  | (27,426 | ) |  |  | (7,247 | ) |
| Total deferred |  |  | 11,226 |  |  |  | (60,424 | ) |  |  | (5,850 | ) |
| Income tax provision |  | $ | (19,015 | ) |  | $ | (88,280 | ) |  | $ | (15,639 | ) |

[0000950170-24-021098:notes:176]
The following is a reconciliation of the provision for income taxes at the statutory federal income tax rate compared to the Company’s provision for income taxes for the years ended January 1, 2024, January 2, 2023 and January 3, 2022:

[0000950170-24-021098:notes:177]
|  |  | For the Year Ended |  |
|  |  | January 1,2024 |  |  | January 2,2023 |  |  | January 3,2022 |  |
|  |  | (In thousands) |  |
| Statutory federal income tax provision |  | $ | (62 | ) |  | $ | (38,401 | ) |  | $ | (14,711 | ) |
| State income taxes, net of federal benefit and state tax credits |  |  | (1,875 | ) |  |  | 1,750 |  |  |  | 1,815 |  |
| IRC Section 162(m) limitation |  |  | (2,121 | ) |  |  | (791 | ) |  |  | (725 | ) |
| Stock options |  |  | (651 | ) |  |  | (599 | ) |  |  | 89 |  |
| Global Intangible Low-Taxed Income |  |  | (12,639 | ) |  |  | (19,240 | ) |  |  | (9,824 | ) |
| Foreign tax credits |  |  | 14,916 |  |  |  | 17,343 |  |  |  | 3,028 |  |
| Permanently reinvested earnings assertion |  |  | (3,934 | ) |  |  | (2,721 | ) |  |  | (1,392 | ) |
| Foreign tax differential on foreign earnings & other permanent items |  |  | 3,788 |  |  |  | 1,504 |  |  |  | 3,917 |  |
| Change in valuation allowance |  |  | (13,460 | ) |  |  | (50,805 | ) |  |  | (1,139 | ) |
| Uncertain tax positions |  |  | 957 |  |  |  | (85 | ) |  |  | (642 | ) |
| Federal research and development credits |  |  | 4,665 |  |  |  | 4,319 |  |  |  | 3,400 |  |
| Goodwill impairment |  |  | (9,261 | ) |  |  | — |  |  |  | — |  |
| Other |  |  | 662 |  |  |  | (554 | ) |  |  | 545 |  |
| Income tax provision |  | $ | (19,015 | ) |  | $ | (88,280 | ) |  | $ | (15,639 | ) |

[0000950170-24-021098:notes:178]
Deferred income taxes reflect the net tax effects of temporary differences between the carrying amounts of assets and liabilities for financial reporting purposes and the amounts used for income tax purposes. The significant components of the net deferred income tax (liabilities) assets as of January 1, 2024 and January 2, 2023 are as follows:

[0000950170-24-021098:notes:179]
|  |  | As of |  |
|  |  | January 1,2024 |  |  | January 2,2023 |  |
|  |  | (In thousands) |  |
| Deferred income tax assets: |  |  |  |  |  |  |
| Net operating loss carryforwards |  | $ | 30,098 |  |  | $ | 33,092 |  |
| Reserves and accruals |  |  | 60,023 |  |  |  | 60,360 |  |
| Interest expense limitation |  |  | 959 |  |  |  | 115 |  |
| Unrealized gain on cash flow hedge |  |  | (1,221 | ) |  |  | (276 | ) |
| Tax credit carryforwards |  |  | 35,760 |  |  |  | 36,192 |  |
| Stock-based compensation |  |  | 5,312 |  |  |  | 5,076 |  |
| Property, plant and equipment |  |  | 4,733 |  |  |  | 5,983 |  |
| Other deferred income tax assets |  |  | 883 |  |  |  | 2,848 |  |
|  |  |  | 136,547 |  |  |  | 143,390 |  |
| Less: valuation allowance |  |  | (81,779 | ) |  |  | (67,173 | ) |
|  |  |  | 54,768 |  |  |  | 76,217 |  |
| Deferred income tax liabilities: |  |  |  |  |  |  |
| Repatriation of foreign earnings |  |  | (7,137 | ) |  |  | (7,112 | ) |
| Property, plant and equipment basis differences |  |  | (73,072 | ) |  |  | (84,609 | ) |
| Goodwill and intangible amortization |  |  | (11,551 | ) |  |  | (31,456 | ) |
| Other deferred income tax liabilities |  |  | (5,149 | ) |  |  | (4,882 | ) |
| Net deferred income tax (liabilities) assets (included in Other long-term liabilities and Deposits and other non-current assets, respectively) |  | $ | (42,141 | ) |  | $ | (51,842 | ) |

[0000950170-24-021098:notes:180]
As of January 1, 2024, the Company had the following net operating loss (NOL) carryforwards: $88,318 in the U.S. for federal, $15,243 in various U.S. states, $25,199 in China, and $23,627 in Hong Kong. The U.S. federal NOLs expire in 2028 through 2032, the various U.S. states’ NOLs expire in 2025 through 2043, the China NOLs expire in 2025 through 2033, and the Hong Kong NOLs carryforward indefinitely. Further, the Company’s tax credits were approximately $45,777, of which $6,147 carryforward indefinitely.

[0000950170-24-021098:notes:181]
In connection with the Company’s acquisition of Viasystems during 2015, there was more than a 50% change in ownership under Section 382 of the Internal Revenue Code of 1986, as amended, and regulations issued there under. As a consequence, the utilization of the remaining Viasystems U.S. NOLs is limited to approximately $9,826 per year and total $88,318.

[0000950170-24-021098:notes:182]
A valuation allowance is provided when it is more likely than not that all or some portion of the deferred income tax assets will not be realized. The Company established a valuation allowance on its U.S. net deferred tax assets in the current year mainly due to cumulative book losses in the U.S. In addition, certain subsidiaries in various tax jurisdictions continue to have NOL carryforwards, which the Company has determined are not more likely than not to be utilized. As a result, a full valuation allowance has been recorded for these subsidiaries as of January 1, 2024. For the remaining net deferred income tax assets, management has determined that it is more likely than not that the results of future operations will generate sufficient income to realize the net deferred tax assets.

[0000950170-24-021098:notes:183]
The following summarizes the activity in the Company’s valuation allowance for the years ended January 1, 2024, January 2, 2023 and January 3, 2022:

[0000950170-24-021098:notes:184]
|  |  | For the Year Ended |  |
|  |  | January 1,2024 |  |  | January 2,2023 |  |  | January 3,2022 |  |
|  |  | (In thousands) |  |
| Balance at beginning of year |  | $ | 67,173 |  |  | $ | 16,541 |  |  | $ | 15,322 |  |
| Additions charged to expense |  |  | 13,811 |  |  |  | 51,748 |  |  |  | 2,330 |  |
| Addition related to acquisition |  |  | 1,187 |  |  |  | — |  |  |  | — |  |
| Other reduction charged to expense |  |  | (392 | ) |  |  | (1,116 | ) |  |  | (1,111 | ) |
| Balance at end of year |  | $ | 81,779 |  |  | $ | 67,173 |  |  | $ | 16,541 |  |

[0000950170-24-021098:notes:185]
Certain entities within China qualified for the high and new technology enterprise (HNTE) status enabling those entities to enjoy certain benefits, which were effective for the years ended January 1, 2024, January 2, 2023 and January 3, 2022. The HNTE status as well as enhanced research and development (R&D) deductions decreased Chinese taxes. HNTE and R&D benefit and effect on earnings per share are as follows:

[0000950170-24-021098:notes:186]
|  |  | For the Year Ended |  |
|  |  | January 1,2024 |  |  | January 2,2023 |  |  | January 3,2022 |  |
|  |  | (In thousands, except per share data) |  |
| HNTE and R&D benefits |  | $ | 6,056 |  |  | $ | 13,480 |  |  | $ | 5,611 |  |
| Basic shares |  |  | 102,744 |  |  |  | 102,074 |  |  |  | 106,314 |  |
| Diluted shares |  |  | 102,744 |  |  |  | 103,866 |  |  |  | 108,153 |  |
| Increases earnings per share: |  |  |  |  |  |  |  |  |  |
| Basic |  | $ | 0.06 |  |  | $ | 0.13 |  |  | $ | 0.05 |  |
| Diluted |  | $ | 0.06 |  |  | $ | 0.13 |  |  | $ | 0.05 |  |

[0000950170-24-021098:notes:187]
HNTE status expired for certain subsidiaries in 2024, but the Company expects to continue to file for renewal of such HNTE status for the foreseeable future.

[0000950170-24-021098:notes:188]
A reconciliation of the beginning and ending amount of unrecognized tax benefits, exclusive of accrued interest and penalties, is as follows:

[0000950170-24-021098:notes:189]
|  |  | For the Year Ended |  |
|  |  | January 1,2024 |  |  | January 2,2023 |  |  | January 3,2022 |  |
|  |  | (In thousands) |  |
| Balance at beginning of year |  | $ | 9,778 |  |  | $ | 9,442 |  |  | $ | 7,404 |  |
| Additions based on tax positions related to the current year |  |  | 934 |  |  |  | 820 |  |  |  | 2,749 |  |
| Additions for tax positions of prior years |  |  | 13 |  |  |  | — |  |  |  | 41 |  |
| Reductions for tax positions of prior years |  |  | — |  |  |  | (72 | ) |  |  | (357 | ) |
| Lapse of statute of limitations |  |  | (362 | ) |  |  | (412 | ) |  |  | (395 | ) |
| Balance at end of year |  | $ | 10,363 |  |  | $ | 9,778 |  |  | $ | 9,442 |  |

[0000950170-24-021098:notes:190]
During the year ended January 1, 2024, the Company increased uncertain tax positions by $585 due to (i) U.S. R&D credit generation in 2023, offset by (ii) release of uncertain tax positions due to statute of limitation expiration.

[0000950170-24-021098:notes:191]
As of January 1, 2024, and January 2, 2023, the Company recorded unrecognized tax benefits of $449 and $776, respectively, as well as interest and penalties of $434 and $1,028, respectively, to current and long-term liabilities. The Company has also recorded unrecognized tax benefits of $9,915 and $9,002 against certain deferred tax assets as of January 1, 2024, and January 2, 2023, respectively. The amount of unrecognized tax benefits that would, if recognized, reduce the Company’s effective income tax rate in any future periods is $883 including interest and penalties. The Company does not expect any of its unrecognized tax benefits to be released in the next twelve months.

[0000950170-24-021098:notes:192]
As of January 1, 2024, the Company is open for (i) U.S. federal income tax examination for the period from 2020 to 2023 and NOL and credit carryforwards are subject to adjustment for 3 years post utilization, (ii) state and local income tax examination for tax years 2019 to 2023 and NOL and credit carryforwards are subject to adjustment for 4 years post utilization; and (iii) foreign income tax examinations generally for tax years from 2013 to 2023.


## us-gaap:FinancialInstrumentsDisclosureTextBlock

[0000950170-24-021098:notes:193]
(9)
Financial Instruments

[0000950170-24-021098:notes:194]
Derivatives

[0000950170-24-021098:notes:195]
Interest Rate Swaps

[0000950170-24-021098:notes:196]
The Company’s business is exposed to risk resulting from fluctuations in interest rates on certain SOFR-based variable rate debt. Increases in interest rates increase interest expenses relating to the outstanding variable rate borrowings and increase the cost of debt. Fluctuations in interest rates can also lead to significant fluctuations in the fair value of the debt obligations.

[0000950170-24-021098:notes:197]
On March 23, 2023, the Company entered into a four-year pay-fixed, receive floating (1-month CME Term SOFR), interest rate swap arrangement with a notional amount of $250,000 for the period beginning April 1, 2023 and ending on April 1, 2027. Under the terms of the interest rate swap, the Company pays a fixed rate of 3.49% against a portion of its Term SOFR-based debt and receives a floating 1-month CME Term SOFR during the swap period.

[0000950170-24-021098:notes:198]
At inception, the Company designated the interest rate swap as a cash flow hedge and the fair value of the interest rate swap was zero. As of January 1, 2024, the fair value of the interest rate swap was recorded, of which $3,253 is included as a component of prepaid expenses and other current assets and $1,476 is included as a component of other long-term liabilities. The change in the fair value of the interest rate swap is recorded as a component of accumulated other comprehensive loss, net of tax in the Company's consolidated balance sheets. No ineffectiveness was recognized for the year ended January 1, 2024. The interest rate swap decreased interest expense by $3,243 for the year ended January 1, 2024.

[0000950170-24-021098:notes:199]
Foreign Exchange Contracts

[0000950170-24-021098:notes:200]
The Company’s foreign subsidiaries may at times purchase forward exchange contracts to manage their foreign currency risks in relation to certain purchases of machinery denominated in foreign currencies other than the Company’s functional currencies. The notional amount of the foreign exchange contracts was $1,925 (Euro (EUR) 1.8 million) and $1,625 (EUR 1.4 million) as of January 1, 2024 and January 2, 2023, respectively. The Company has designated certain of these foreign exchange contracts as cash flow hedges.

[0000950170-24-021098:notes:201]
Commodity Price Risk Management

[0000950170-24-021098:notes:202]
The Company uses various raw materials in the manufacturing of PCBs. Copper clad laminates (CCLs), a key raw material for the manufacture of PCBs, are made from epoxy resin, glass cloth and copper foil. The Company only buys a small amount of copper directly. However, copper is a major driver of laminate cost. The Company enters into commodity contracts to hedge copper as a proxy for hedging laminate. As of January 1, 2024, the Company has commodity contracts with a notional quantity of (i) 0.7 metric tonnes for the period beginning January 1, 2024 and ending on March 31, 2024, (ii) 0.6 metric tonnes for the period beginning April 1, 2024 and ending on June 30, 2024, (iii) 0.6 metric tonnes for the period beginning July 1, 2024 and ending on September 30, 2024, and (iv) 0.5 metric tonnes for the period beginning October 1, 2024 and ending on December 31, 2024. As of January 1, 2024 and January 2, 2023, the fair value of the commodity contracts was recorded as a liability in the amount of $297 and $1,489, respectively, and included as a component of other current liabilities. The changes in the fair value of these commodity contracts are recorded in cost of goods sold in the consolidated statements of operations. The commodity contracts increased cost of goods sold by $372 and $2,605 for the years ended January 1, 2024 and January 2, 2023, respectively and decreased cost of goods sold by $297 for the year ended January 3, 2022. These commodity contracts are not designated as accounting hedges.

[0000950170-24-021098:notes:203]
The fair values of derivative instruments in the consolidated balance sheets are as follows:

[0000950170-24-021098:notes:204]
|  |  |  |  | Asset/(Liability) Fair Value |  |
|  |  | Balance Sheet Location |  | January 1, 2024 |  |  | January 2, 2023 |  |
|  |  |  |  | (In thousands) |  |
| Cash flow derivative instruments designated as hedges: |  |  |  |  |  |  |
| Interest rate swap |  | Prepaid expenses and other current assets |  | $ | 3,253 |  |  | $ | — |  |
| Foreign exchange contracts |  | Prepaid expenses and other current assets |  |  | 29 |  |  |  | — |  |
| Foreign exchange contracts |  | Other current liabilities |  |  | — |  |  |  | (133 | ) |
| Interest rate swap |  | Other long-term liabilities |  |  | (1,476 | ) |  |  | — |  |
| Cash flow derivative instruments not designated as hedges: |  |  |  |  |  |  |
| Commodity contracts |  | Other current liabilities |  |  | (297 | ) |  |  | (1,489 | ) |

[0000950170-24-021098:notes:205]
The following table provides information about the amounts recorded in accumulated other comprehensive loss related to derivatives designated as cash flow hedges, as well as the amounts recorded in each caption in the consolidated statements of operations when derivative amounts are reclassified out of accumulated other comprehensive loss for the years ended January 1, 2024, January 2, 2023, and January 3, 2022:

[0000950170-24-021098:notes:206]
|  |  |  | For the Year Ended |  |  |
|  |  |  | January 1, 2024 |  |  | January 2, 2023 |  |  | January 3, 2022 |  |  |
|  |  | FinancialStatement Caption | Gain Recognizedin OtherComprehensiveLoss |  |  | AmountsReclassifiedinto Income |  |  | Gain Recognizedin OtherComprehensiveIncome |  |  | AmountsReclassifiedinto Income |  |  | Loss Recognizedin OtherComprehensiveLoss |  |  | AmountsReclassifiedinto Income |  |  |
|  |  |  | (In thousands) |
| Cash flow hedge: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Interest rate swap |  | Interest expense | $ | 5,020 |  |  | $ | (3,243 | ) |  | $ | 190 |  |  | $ | (4,105 | ) |  | $ | (599 | ) |  | $ | (11,272 | ) |  |

[0000950170-24-021098:notes:207]
The following table provides a summary of the activity associated with the designated cash flow hedges reflected in accumulated other comprehensive loss for the years ended January 1, 2024, January 2, 2023, and January 3, 2022:

[0000950170-24-021098:notes:208]
|  |  | For the Year Ended |  |
|  |  | January 1, |  |  | January 2, |  |  | January 3, |  |
|  |  | 2024 |  |  | 2023 |  |  | 2022 |  |
|  |  | (In thousands) |  |
| Beginning balance, net of tax |  | $ | (85 | ) |  | $ | (3,223 | ) |  | $ | (11,231 | ) |
| Changes in fair value gain (loss), net of tax |  |  | 4,061 |  |  |  | (91 | ) |  |  | (515 | ) |
| Reclassification to earnings |  |  | (2,713 | ) |  |  | 3,229 |  |  |  | 8,523 |  |
| Ending balance, net of tax |  | $ | 1,263 |  |  | $ | (85 | ) |  | $ | (3,223 | ) |

[0000950170-24-021098:notes:209]
Based on the current yield curve, the Company expects that gains of approximately $2,445 of accumulated other comprehensive loss will be reclassified into the consolidated statement of operations, net of tax, in the next twelve months.


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0000950170-24-021098:notes:210]
(10)
Accumulated Other Comprehensive Loss

[0000950170-24-021098:notes:211]
The following provides a summary of the components of accumulated other comprehensive loss, net of tax as of January 1, 2024, January 2, 2023 and January 3, 2022:

[0000950170-24-021098:notes:212]
|  |  | ForeignCurrencyTranslation |  |  | Pension Obligation |  |  | (Losses) Gainson Cash FlowHedges |  |  | Total |  |
|  |  | (In thousands) |  |
| Ending balance as of January 3, 2022 |  | $ | (23,899 | ) |  | $ | (133 | ) |  | $ | (3,223 | ) |  | $ | (27,255 | ) |
| Other comprehensive (loss) income before reclassifications |  |  | (2,085 | ) |  |  | 1,412 |  |  |  | (91 | ) |  |  | (764 | ) |
| Amounts reclassified from accumulated other comprehensive income |  |  | — |  |  |  | — |  |  |  | 3,229 |  |  |  | 3,229 |  |
| Net year to date other comprehensive (loss) income |  |  | (2,085 | ) |  |  | 1,412 |  |  |  | 3,138 |  |  |  | 2,465 |  |
| Ending balance as of January 2, 2023 |  |  | (25,984 | ) |  |  | 1,279 |  |  |  | (85 | ) |  |  | (24,790 | ) |
| Other comprehensive (loss) income before reclassifications |  |  | (6,876 | ) |  |  | 1,251 |  |  |  | 4,061 |  |  |  | (1,564 | ) |
| Amounts reclassified from accumulated other comprehensive income |  |  | — |  |  |  | — |  |  |  | (2,713 | ) |  |  | (2,713 | ) |
| Net year to date other comprehensive (loss) income |  |  | (6,876 | ) |  |  | 1,251 |  |  |  | 1,348 |  |  |  | (4,277 | ) |
| Ending balance as of January 1, 2024 |  | $ | (32,859 | ) |  | $ | 2,530 |  |  | $ | 1,263 |  |  | $ | (29,067 | ) |


## us-gaap:ConcentrationRiskDisclosureTextBlock

[0000950170-24-021098:notes:213]
(11)
Significant Customers and Concentration of Credit Risk

[0000950170-24-021098:notes:214]
Financial instruments that are potentially subject to concentrations of credit risk are primarily cash and cash equivalents and accounts receivable.

[0000950170-24-021098:notes:215]
The Company had cash and cash equivalents held by its foreign subsidiaries of $195,928 and $161,708 as of January 1, 2024 and January 2, 2023, respectively. The Company maintains its cash and cash equivalents with major financial institutions and such balances exceed Federal Deposit Insurance Corporation insurance limits. The Company has not experienced any losses in such accounts and believes it is not exposed to any significant risk on cash and cash equivalents.

[0000950170-24-021098:notes:216]
In the normal course of business, the Company extends credit to its customers. Some customers to whom the Company extends credit are located outside the United States. The Company performs ongoing credit evaluations of customers, does not require collateral, and considers the credit risk profile of the entity from which the receivable is due in further evaluating collection risk. There were no customers that accounted for 10% or more of accounts receivable as of January 1, 2024. As of January 2, 2023, there was one customer that accounted for 11% of the Company’s accounts receivable.

[0000950170-24-021098:notes:217]
The Company’s customers include both OEMs and EMS companies. The Company’s OEM customers often direct a significant portion of their purchases through EMS companies. While the Company’s customers include both OEM and EMS providers, the Company measures customer concentration based on OEM companies, as they are the ultimate end customers.

[0000950170-24-021098:notes:218]
For the year ended January 1, 2024, one customer accounted for approximately 13% of the Company’s net sales. For each of the years ended January 2, 2023 and January 3, 2022, one customer accounted for approximately 10% of the Company’s net sales.


## us-gaap:FairValueDisclosuresTextBlock

[0000950170-24-021098:notes:219]
(12)
Fair Value Measures

[0000950170-24-021098:notes:220]
The Company measures at fair value its financial and non-financial assets by using a fair value hierarchy that prioritizes the inputs to valuation techniques used to measure fair value. Fair value is the price that would be received to sell an asset or paid to transfer a liability in an orderly transaction between market participants at the measurement date, essentially an exit price, based on the highest and best use of the asset or liability.

[0000950170-24-021098:notes:221]
The carrying amount and estimated fair value of the Company’s financial instruments as of January 1, 2024 and January 2, 2023 were as follows:

[0000950170-24-021098:notes:222]
|  |  | As of |  |  | As of |  |
|  |  | January 1, 2024 |  |  | January 2, 2023 |  |
|  |  | CarryingAmount |  |  | Fair Value |  |  | CarryingAmount |  |  | Fair Value |  |
|  |  | (In thousands) |  |
| Derivative assets, current |  | $ | 3,282 |  |  | $ | 3,282 |  |  | $ | — |  |  | $ | — |  |
| Derivative liabilities, current |  |  | 297 |  |  |  | 297 |  |  |  | 1,622 |  |  |  | 1,622 |  |
| Derivative liabilities, non-current |  |  | 1,476 |  |  |  | 1,476 |  |  |  | — |  |  |  | — |  |
| Senior Notes due March 2029 |  |  | 495,915 |  |  |  | 455,035 |  |  |  | 495,221 |  |  |  | 430,165 |  |
| Term Loan due May 2030 |  |  | 341,921 |  |  |  | 351,743 |  |  |  | — |  |  |  | — |  |
| Term Loan due September 2024 |  |  | — |  |  |  | — |  |  |  | 404,186 |  |  |  | 405,628 |  |
| ABL Revolving Loans |  |  | 80,000 |  |  |  | 80,000 |  |  |  | 30,000 |  |  |  | 30,000 |  |

[0000950170-24-021098:notes:223]
The fair value of the derivative instruments was determined using pricing models developed based on the 1-month CME Term SOFR swap rate, foreign currency exchange rates, and other observable market data, including quoted market prices, as appropriate using Level 2 inputs. The values were adjusted to reflect non-performance risk of both the counterparty and the Company, as necessary.

[0000950170-24-021098:notes:224]
The fair value of the long-term debt was estimated based on quoted market prices or discounting the debt over its life using current market rates for similar debt as of January 1, 2024 and January 2, 2023, which are considered Level 2 inputs.

[0000950170-24-021098:notes:225]
The fair value of plan assets in the defined benefit plan of $23,249 and $21,637 as of January 1, 2024 and January 2, 2023, respectively, were not included in the table above and was estimated based on quoted market prices of the securities that are actively traded and price quotes that are readily available, which are considered Level 1 inputs. See Note 15 for further details of the plan assets measured at fair value in the defined benefit plan.

[0000950170-24-021098:notes:226]
As of January 1, 2024 and January 2, 2023, the Company’s other financial instruments included cash and cash equivalents, accounts receivable, contract assets, accounts payable, and contract liabilities. The carrying amount of these instruments approximates fair value.

[0000950170-24-021098:notes:227]
The majority of the Company’s non-financial assets and liabilities, which include goodwill, intangible assets, inventories, and property, plant and equipment, are not required to be carried at fair value on a recurring basis. However, if certain triggering events occur (or are tested at least annually in the case of goodwill) such that a non-financial instrument is required to be evaluated for impairment, based upon a comparison of the non-financial instrument’s fair value to its carrying value, an impairment is recorded to reduce the carrying value to the fair value, if the carrying value exceeds the fair value.

[0000950170-24-021098:notes:228]
As of January 1, 2024, the Company’s goodwill balance related to its RF&S Components reporting unit of $63,900 was measured at fair value on a nonrecurring basis. The Company recorded a non-cash goodwill impairment charge of $44,100 related to its RF&S Components reporting unit during the year ended January 1, 2024. The fair value of goodwill was determined using both a DCF and a market approach, which are considered Level 3 inputs. The Company used risk adjusted discount rate of 12% to discount the expected future cash flows. There was no impairment of long-lived assets recognized for the years ended January 1, 2024, January 2, 2023, and January 3, 2022.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0000950170-24-021098:notes:229]
(13)
Commitments and Contingencies

[0000950170-24-021098:notes:230]
Legal Matters

[0000950170-24-021098:notes:231]
The Company is subject to various legal matters, which it considers normal for its business activities. While the Company currently believes that the amount of any reasonably possible loss for known matters would not be material to the Company’s financial condition, the outcome of these actions is inherently difficult to predict. In the event of an adverse outcome, the ultimate potential loss could have a material adverse effect on the Company’s financial condition or results of operations in a particular period. The Company has accrued amounts for its loss contingencies which are probable and estimable as of January 1, 2024 and January 2, 2023. However, these amounts are not material to the consolidated financial statements of the Company.

[0000950170-24-021098:notes:232]
Offset Agreements

[0000950170-24-021098:notes:233]
The Company has and may continue to enter into industrial cooperation agreements, sometimes referred to as offset agreements, as a condition to obtaining orders for products and services from customers in foreign countries. These agreements are intended to promote investment in the applicable country, and the Company’s obligations under these agreements may be satisfied through activities that do not require the Company to use cash, including transferring technology or providing manufacturing and other consulting support. The obligations under these agreements may also be satisfied through the use of cash for activities such as purchasing supplies from in-country vendors, setting up support centers, research and development investments, acquisitions, and building or leasing facilities for in-country operations, if applicable. The amount of the offset requirement is determined by contract value awarded and negotiated percentages with customers. As of January 1, 2024, the Company had outstanding offset agreements of approximately $27,963, some of which extend through 2028. Offset programs usually extend over several years and in some cases provide for penalties in the event the Company fails to perform in accordance with contract requirements. Historically, the Company has not paid any such penalties, and as of January 1, 2024, no such penalties have been paid.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0000950170-24-021098:notes:234]
(14)
Stock-Based Compensation

[0000950170-24-021098:notes:235]
Incentive Compensation Plan

[0000950170-24-021098:notes:236]
The Company maintains a 2023 Incentive Compensation Plan (the Plan), which allows for issuance of up to 5,100 shares through its latest possible expiration date in May 2033.

[0000950170-24-021098:notes:237]
The Plan provides for the grant of performance-based restricted stock units (PRUs), restricted stock units (RSUs), and stock appreciation rights. The exercise price for awards is determined by the compensation committee of the board of directors. Each award shall vest and expire as determined by the compensation committee of the board of directors, with PRUs and RSUs generally vesting over three years for employees and one year for non-employee directors. PRUs and RSUs do not have voting rights. All grants provide for accelerated vesting if there is a change in control, as defined in the Plan.

[0000950170-24-021098:notes:238]
As of January 1, 2024, 570 PRUs, 4,131 RSUs and 60 stock options were outstanding under the Plan. Included in the 570 PRUs outstanding as of January 1, 2024 are 227 vested but not yet released. Included in the 4,131 RSUs outstanding as of January 1, 2024 are 678 vested but not yet released RSUs associated with non-employee directors. These RSUs vest over one year with release of the underlying shares of common stock deferred until retirement from the board of directors (or until one year after retirement in the case of certain prior grants).

[0000950170-24-021098:notes:239]
Performance-based Restricted Stock Units

[0000950170-24-021098:notes:240]
The Company maintains a long-term incentive program for executives that provides for the issuance of PRUs, representing hypothetical shares of the Company’s common stock that may be issued. Under the PRU program, a target number of PRUs is awarded at the beginning of each three-year performance period. The number of shares of common stock released at the end of the performance period may range from zero to 2.4 times the target number depending on performance during the period. The performance metrics of the PRU program are based on (a) annual financial targets, which are based on revenue and earnings before interest, tax, depreciation, and amortization expense (EBITDA), each equally weighted, and (b) an overall modifier based on the Company’s total stockholder return (TSR) relative to a group of peer companies selected by the Company’s compensation committee, over the three-year performance period.

[0000950170-24-021098:notes:241]
Under the PRU program, financial goals are set at the beginning of each fiscal year and performance is reviewed at the end of that year. The percentage to be applied to each participant’s target award ranges from zero to 160% based upon the extent to which the annual financial performance goals are achieved. If specific performance threshold levels for the annual financial goals are met, the amount earned for that element will be applied to one-third of the participants’ PRU award to determine the number of units earned.

[0000950170-24-021098:notes:242]
At the end of the three-year performance period, the total units earned, if any, are adjusted by applying a modifier, ranging from zero to 150% based on the Company’s TSR based on stock price changes relative to a group of peer companies selected by the Company’s compensation committee for the same three-year period.

[0000950170-24-021098:notes:243]
The TSR modifier is intended to ensure that there are limited or no payouts under the PRU program if the Company’s stock performance is significantly below the median TSR of a group of peer companies selected by the Company’s compensation committee over the three-year performance period. Where the annual financial goals have been met and where there has been strong relative TSR performance over the three-year performance period, the PRU program may provide substantial rewards to participants with a maximum payout of 2.4 times the initial PRU award. However, even if all of the annual financial metric goals are achieved in each of the three years, there will be no payouts if the Company’s stock performance is below that of the 10th percentile of the group of peer companies selected by the Company’s compensation committee.

[0000950170-24-021098:notes:244]
Recipients of PRU awards generally must remain employed by the Company on a continuous basis through the end of the three-year performance period in order to receive any amount of the PRUs covered by that award. In events such as death, disability or retirement, the recipient may be entitled to pro-rata amounts of PRUs as defined in the Plan. Target shares subject to PRU awards do not have voting rights of common stock until earned and issued following the end of the three-year performance period.

[0000950170-24-021098:notes:245]
The Company records stock-based compensation expense for PRU awards granted based on management’s periodic assessment of the annual financial performance goals to be achieved. As of January 1, 2024, management determined that vesting of the PRU awards was probable. PRU activity for the year ended January 1, 2024 was as follows:

[0000950170-24-021098:notes:246]
|  |  | Shares |  |  | WeightedAverage FairValue |  |
|  |  | (In thousands) |  |  |  |  |
| Outstanding shares as of January 2, 2023 |  |  | 391 |  |  | $ | 15.55 |  |
| Granted |  |  | 327 |  |  |  | 16.34 |  |
| Vested |  |  | (227 | ) |  |  | 16.12 |  |
| Change in units due to annual performance achievement |  |  | (149 | ) |  |  | 16.22 |  |
| Outstanding shares as of January 1, 2024 |  |  | 342 |  |  | $ | 15.64 |  |

[0000950170-24-021098:notes:247]
The fair value of PRUs granted is calculated using a Monte Carlo simulation model, as the TSR modifier contains a market condition. For the years ended January 1, 2024, January 2, 2023 and January 3, 2022, the following assumptions were used in determining the fair value:

[0000950170-24-021098:notes:248]
|  |  | For the Year Ended |  |
|  |  | January 1, 2024 (1) |  |  | January 2, 2023 (2) |  |  | January 3, 2022 (3) |  |
| Weighted-average fair value |  | $ | 16.36 |  |  | $ | 15.02 |  |  | $ | 14.23 |  |
| Risk-free interest rate |  |  | 4.46 | % |  |  | 1.44 | % |  |  | 0.18 | % |
| Dividend yield |  |  | — |  |  |  | — |  |  |  | — |  |
| Expected volatility |  |  | 42 | % |  |  | 30 | % |  |  | 47 | % |

[0000950170-24-021098:notes:249]
(1)
Reflects the weighted-averages for the third year of the three-year performance period applicable to PRUs granted in 2021, the second year of the three-year performance period applicable to PRUs granted in 2022 and the first year of the three-year performance period applicable to PRUs granted in 2023.

[0000950170-24-021098:notes:250]
(2)
Reflects the weighted-averages for the third year of the three-year performance period applicable to PRUs granted in 2020, the second year of the three-year performance period applicable to PRUs granted in 2021 and the first year of the three-year performance period applicable to PRUs granted in 2022.

[0000950170-24-021098:notes:251]
(3)
Reflects the weighted-averages for the third year of the three-year performance period applicable to PRUs granted in 2019, the second year of the three-year performance period applicable to PRUs granted in 2020 and the first year of the three-year performance period applicable to PRUs granted in 2021.

[0000950170-24-021098:notes:252]
The risk-free interest rate for the expected term of PRUs is based on the U.S. Treasury yield curve in effect at the time of grant. Expected volatility is calculated using the Company’s historical stock price.

[0000950170-24-021098:notes:253]
Restricted Stock Units

[0000950170-24-021098:notes:254]
RSU activity for the year ended January 1, 2024 was as follows:

[0000950170-24-021098:notes:255]
|  |  | Shares |  |  | WeightedAverageGrant-DateFair Value |  |
|  |  | (In thousands) |  |  |  |  |
| Non-vested RSUs outstanding as of January 2, 2023 |  |  | 3,063 |  |  | $ | 12.96 |  |
| Granted |  |  | 2,076 |  |  |  | 13.85 |  |
| Vested |  |  | (1,430 | ) |  |  | 13.93 |  |
| Cancelled |  |  | (256 | ) |  |  | 13.35 |  |
| Non-vested RSUs outstanding as of January 1, 2024 |  |  | 3,453 |  |  | $ | 13.52 |  |
| Vested and expected to vest through 2026 as of January 1, 2024 |  |  | 4,131 |  |  | $ | 13.25 |  |

[0000950170-24-021098:notes:256]
The fair value of the Company’s RSUs is determined based upon the closing common stock price on the grant date. The weighted average fair value per unit of RSUs granted was $13.85, $12.72 and $14.40 for the years ended January 1, 2024, January 2, 2023 and January 3, 2022, respectively. The total fair value of RSUs vested for the years ended January 1, 2024, January 2, 2023 and January 3, 2022 was $19,928, $15,510 and $17,185, respectively.

[0000950170-24-021098:notes:257]
Stock Options

[0000950170-24-021098:notes:258]
As of January 1, 2024, stock options outstanding was 60. This is not material to the consolidated financial statements of the Company.

[0000950170-24-021098:notes:259]
Stock-based Compensation Expense and Unrecognized Compensation Costs

[0000950170-24-021098:notes:260]
For the years ended January 1, 2024, January 2, 2023 and January 3, 2022, the amounts recognized in the consolidated statements of operations with respect to the stock-based compensation plan are as follows:

[0000950170-24-021098:notes:261]
|  |  | For the Year Ended |  |
|  |  | January 1, |  |  | January 2, |  |  | January 3, |  |
|  |  | 2024 |  |  | 2023 |  |  | 2022 |  |
|  |  | (In thousands) |  |
| Cost of goods sold |  | $ | 7,455 |  |  | $ | 5,846 |  |  | $ | 4,714 |  |
| Selling and marketing |  |  | 3,205 |  |  |  | 2,749 |  |  |  | 2,540 |  |
| General and administrative |  |  | 11,088 |  |  |  | 9,808 |  |  |  | 9,718 |  |
| Research and development |  |  | 1,139 |  |  |  | 1,122 |  |  |  | 739 |  |
| Stock-based compensation expense recognized |  | $ | 22,887 |  |  | $ | 19,525 |  |  | $ | 17,711 |  |

[0000950170-24-021098:notes:262]
The following is a summary of total unrecognized compensation costs as of January 1, 2024:

[0000950170-24-021098:notes:263]
|  |  | Unrecognized Stock-Based Compensation Cost |  |  | Remaining Weighted AverageRecognition Period |  |
|  |  | (In thousands) |  |  | (In years) |  |
| RSU awards |  | $ | 34,845 |  |  |  | 1.4 |  |
| PRU awards |  |  | 1,890 |  |  |  | 1.6 |  |
|  |  | $ | 36,735 |  |  |  |  |


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0000950170-24-021098:notes:264]
(15)
Employee Benefit Plans, Deferred Compensation Plan and Retirement Benefit Plan

[0000950170-24-021098:notes:265]
As of January 1, 2024, the Company has several defined contribution plans. In North America, the Company has savings plans (the Savings Plans) in which eligible full-time employees can participate and contribute a percentage of compensation subject to the maximum allowed by the tax agencies. The Savings Plans provides for a partial match by the Company. In China, the Company contributes to either separate trust-administered funds or various government-sponsored pension plans on a mandatory basis. For all defined contribution plans, the Company has no further payment obligation once the required contributions have been made. The Company recorded contributions to defined contribution plans of $36,843, $36,385 and $29,464 during the years ended January 1, 2024, January 2, 2023 and January 3, 2022, respectively.

[0000950170-24-021098:notes:266]
The Company also maintains a deferred compensation plan (the Compensation Plan). The Compensation Plan is an unfunded, nonqualified deferred compensation plan and is limited to selected employees, including the Company’s named executive officers and directors. The Compensation Plan allows participants to defer up to 100% of their annual bonus and between 5% and 100% of their annual director fees. Amounts deferred under the Compensation Plan will be credited to accounts maintained by the Company for each participant and will be credited or debited with the participant’s proportionate share of any gains or losses attributable to the performance of investment options selected by the participant.

[0000950170-24-021098:notes:267]
Following the acquisition of Anaren on April 18, 2018, the Company has a noncontributory defined benefit pension plan covering eligible employees. Effective August 15, 2000, the plan was closed for new participants. Benefits under this plan generally are based on the employee’s years of service and compensation. Effective December 31, 2019, the plan is frozen as to further participation and to further benefit accruals.

[0000950170-24-021098:notes:268]
As of January 1, 2024 and January 2, 2023, the funded status of the accumulated benefit obligation was 97% and 90%, respectively. The Company does not expect to fund a minimum required contribution during fiscal year 2024.

[0000950170-24-021098:notes:269]
The following tables set forth the changes in benefit obligation and the plan assets in the defined benefit plan described above for the years ended January 1, 2024, January 2, 2023 and January 3, 2022:

[0000950170-24-021098:notes:270]
|  |  | For the Year Ended |  |
| Change in Benefit Obligations |  | January 1, 2024 |  |  | January 2, 2023 |  |  | January 3, 2022 |  |
|  |  | (In thousands) |  |
| Benefit obligation at beginning of year |  | $ | (24,108 | ) |  | $ | (31,554 | ) |  | $ | (33,470 | ) |
| Interest cost |  |  | (1,155 | ) |  |  | (803 | ) |  |  | (722 | ) |
| Actuarial (loss) gain |  |  | (247 | ) |  |  | 7,033 |  |  |  | 1,304 |  |
| Benefits paid |  |  | 1,425 |  |  |  | 1,216 |  |  |  | 1,334 |  |
| Benefit obligation at end of year |  | $ | (24,085 | ) |  | $ | (24,108 | ) |  | $ | (31,554 | ) |
| Accumulated benefit obligation at end of year |  | $ | 24,085 |  |  | $ | 24,108 |  |  | $ | 31,554 |  |

[0000950170-24-021098:notes:271]
|  |  | For the Year Ended |  |
| Change in Plan Assets |  | January 1, 2024 |  |  | January 2, 2023 |  |  | January 3, 2022 |  |
|  |  | (In thousands) |  |
| Fair value of plan assets at beginning of year |  | $ | 21,637 |  |  | $ | 26,278 |  |  | $ | 23,484 |  |
| Actual return on plan assets |  |  | 3,038 |  |  |  | (3,760 | ) |  |  | 3,526 |  |
| Employer contributions |  |  | — |  |  |  | 335 |  |  |  | 602 |  |
| Benefits paid |  |  | (1,426 | ) |  |  | (1,216 | ) |  |  | (1,334 | ) |
| Fair value of plan assets at end of year |  | $ | 23,249 |  |  | $ | 21,637 |  |  | $ | 26,278 |  |
| Unfunded status |  | $ | (836 | ) |  | $ | (2,471 | ) |  | $ | (5,276 | ) |
| Net amount recognized |  | $ | (836 | ) |  | $ | (2,471 | ) |  | $ | (5,276 | ) |

[0000950170-24-021098:notes:272]
Amounts before income tax effect recognized in the consolidated balance sheets consists of the following:

[0000950170-24-021098:notes:273]
|  |  | As of |  |  |
|  |  | January 1, 2024 |  |  | January 2, 2023 |  |  |
|  |  | (In thousands) |  |  |
| Other long-term liabilities |  | $ | (836 | ) |  | $ | (2,471 | ) |  |
| Net amount recognized |  | $ | (836 | ) |  | $ | (2,471 | ) |  |

[0000950170-24-021098:notes:274]
Amounts before income tax effect included in accumulated other comprehensive loss as of January 1, 2024 and January 2, 2023 are as follows:

[0000950170-24-021098:notes:275]
|  |  | January 1, 2024 |  |  | January 2, 2023 |  |  |
|  |  | (In thousands) |  |  |
| Net actuarial gain |  | $ | 3,256 |  |  | $ | 1,616 |  |  |
| Accumulated other comprehensive gain |  | $ | 3,256 |  |  | $ | 1,616 |  |  |

[0000950170-24-021098:notes:276]
The net actuarial gain during the year ended January 1, 2024 was primarily driven by an increase in actual return on plan assets.

[0000950170-24-021098:notes:277]
The components included in the net periodic benefit income (cost) and the increase in minimum liability included in other comprehensive loss for the years ended January 1, 2024, January 2, 2023 and January 3, 2022 are as follows:

[0000950170-24-021098:notes:278]
|  |  | For the Year Ended |  |  |
|  |  | January 1, 2024 |  |  | January 2, 2023 |  |  | January 3, 2022 |  |  |
|  |  | (In thousands) |  |  |
| Interest cost |  | $ | 1,155 |  |  | $ | 803 |  |  | $ | 722 |  |  |
| Expected return on plan assets |  |  | (1,150 | ) |  |  | (1,419 | ) |  |  | (1,279 | ) |  |
| Amortization of net actuarial loss |  |  | — |  |  |  | — |  |  |  | 23 |  |  |
| Net periodic benefit income (cost) |  | $ | 5 |  |  | $ | (616 | ) |  | $ | (534 | ) |  |

[0000950170-24-021098:notes:279]
The weighted-average assumptions used to determine benefit obligations for this plan as of January 1, 2024, January 2, 2023 and January 3, 2022 are as follows:

[0000950170-24-021098:notes:280]
|  |  | January 1, 2024 |  |  | January 2, 2023 |  |  | January 3, 2022 |  |  |
| Discount rate |  |  | 4.74 |  | % |  | 4.94 |  | % |  | 2.60 |  | % |
| Expected return on plan assets |  |  | 5.50 |  |  |  | 5.50 |  |  |  | 5.50 |  |  |

[0000950170-24-021098:notes:281]
The Company determines the discount rate assumption based on an analysis using the discount rates from an industry standard curve that is based on high quality corporate bonds and the expected benefit payments from the plan.

[0000950170-24-021098:notes:282]
The weighted-average assumptions used to determine net periodic benefit income (cost) for the years ended January 1, 2024, January 2, 2023 and January 3, 2022 are as follows:

[0000950170-24-021098:notes:283]
|  |  | For the Year Ended |  |  |
|  |  | January 1, 2024 |  |  | January 2, 2023 |  |  | January 3, 2022 |  |  |
| Discount rate |  |  | 4.94 |  | % |  | 2.60 |  | % |  | 2.20 |  | % |
| Expected return on plan assets |  |  | 5.50 |  |  |  | 5.50 |  |  |  | 5.50 |  |  |

[0000950170-24-021098:notes:284]
The Company determines the expected long-term rate of return on plan assets based upon recommendations from its pension plan's investment advisors and using an allocation approach that considers diversification and rebalancing for a portfolio of assets invested over a long-term time horizon. The approach relies on the historical returns of the plan's portfolio and relationships between equities and fixed income investments, consistent with the widely accepted capital market principle that a diversified portfolio with a larger allocation to equity investments can generate a greater return over the long run. Additionally, the Company monitors the mix of investments in its portfolio to ensure alignment with its expected long-term pension obligations. The Company reviews the expected long-term rate of return annually and revises it as appropriate.

[0000950170-24-021098:notes:285]
Investments shall be made pursuant to the following objectives: 1) preserve the purchasing power of the plan’s assets adjusted for inflation; 2) provide long-term growth; and 3) avoid significant volatility. Asset allocation shall be determined based on a long-term target allocation having 29% of assets invested in large-cap stocks, 11% in mid-cap stocks, 11% in small-cap stocks, 11% in international stocks, 34% in the broad bond market, and 3% in the real estate market, with little or none invested in cash. Both the investment allocation and the plan performance are reviewed periodically.

[0000950170-24-021098:notes:286]
The target allocation for 2024 and the plan asset allocation at the end of 2023 and 2022, in percentages, by asset category are as follows:

[0000950170-24-021098:notes:287]
|  |  | Target Allocation 2024 |  |  |  | January 1, 2024 |  |  |  | January 2, 2023 |  |  |
| Equity securities (1) |  |  | 65 |  | % |  |  | 65 |  | % |  |  | 66 |  | % |
| Debt securities (2) |  |  | 34 |  |  |  |  | 32 |  |  |  |  | 33 |  |  |
| Cash and cash equivalents (3) |  |  | 1 |  |  |  |  | 3 |  |  |  |  | 1 |  |  |
| Total |  |  | 100 |  | % |  |  | 100 |  | % |  |  | 100 |  | % |

[0000950170-24-021098:notes:288]
The following table summarizes plan assets measured at fair value as of January 1, 2024 and January 2, 2023:

[0000950170-24-021098:notes:289]
|  |  | As of |  |
|  |  | January 1, 2024 |  |
|  |  | Total |  |  | Quoted Prices inActive Markets for Identical Assets(Level 1) |  |  | SignificantObservable Inputs(Level 2) |  |  | SignificantUnobservable Inputs(Level 3) |  |
|  |  | (In thousands) |  |
| Equity securities (1) |  | $ | 15,171 |  |  | $ | 15,171 |  |  | $ | — |  |  | $ | — |  |
| Debt securities (2) |  |  | 7,380 |  |  |  | 7,380 |  |  |  | — |  |  |  | — |  |
| Cash and cash equivalents (3) |  |  | 698 |  |  |  | 698 |  |  |  | — |  |  |  | — |  |
| Total |  | $ | 23,249 |  |  | $ | 23,249 |  |  | $ | — |  |  | $ | — |  |
|  |  | As of |  |
|  |  | January 2, 2023 |  |
|  |  | Total |  |  | Quoted Prices inActive Markets for Identical Assets(Level 1) |  |  | SignificantObservable Inputs(Level 2) |  |  | SignificantUnobservable Inputs(Level 3) |  |
|  |  | (In thousands) |  |
| Equity securities (1) |  | $ | 14,221 |  |  | $ | 14,221 |  |  | $ | — |  |  | $ | — |  |
| Debt securities (2) |  |  | 7,208 |  |  |  | 7,208 |  |  |  | — |  |  |  | — |  |
| Cash and cash equivalents (3) |  |  | 208 |  |  |  | 208 |  |  |  | — |  |  |  | — |  |
| Total |  | $ | 21,637 |  |  | $ | 21,637 |  |  | $ | — |  |  | $ | — |  |

[0000950170-24-021098:notes:290]
(1)
Equity securities include U.S. and foreign exchange traded common and preferred stocks and mutual funds. Common and preferred shares issued by U.S. and non-U.S. corporations are traded actively on exchanges and price quotes for these shares are readily available. Holdings of corporate stock are categorized as Level 1 investments.

[0000950170-24-021098:notes:291]
(2)
Debt securities include the debt of the U.S. Treasury and U.S. and foreign corporate issuers. U.S. Treasury notes and bonds are actively traded and price quotes for these securities are readily available. Holdings of U.S. Treasury notes and bonds are categorized as Level 1 investments.

[0000950170-24-021098:notes:292]
(3)
Cash and cash equivalents include short-term U.S. government investment notes, short-term money market mutual funds, accrued income and cash held on account. Cash held on account and short-term U.S. government investment notes (including accrued income thereon) for which there is an active market and daily pricing for the security are categorized as Level 1 investments.

[0000950170-24-021098:notes:293]
The Company seeks to maximize medium to long-term returns of the overall pension plan assets with reasonable levels of investment risk. One element of controlling the overall investment risk is through diversification of asset allocation, among domestic and international equity and debt instruments. The plan's equity investments include foreign and domestic exchange traded equities across a range of industries and countries, but primarily in the domestic markets. The plan's debt securities are primarily invested in government and corporate issuers primarily in the domestic market.

[0000950170-24-021098:notes:294]
The following benefit payments, which reflect expected future service, as appropriate, are expected to be paid:

[0000950170-24-021098:notes:295]
|  |  | (In thousands) |  |
| 2024 |  | $ | 1,544 |  |
| 2025 |  |  | 1,590 |  |
| 2026 |  |  | 1,630 |  |
| 2027 |  |  | 1,652 |  |
| 2028 |  |  | 1,677 |  |
| Years 2029 through 2032 |  |  | 8,628 |  |


## us-gaap:PreferredStockTextBlock

[0000950170-24-021098:notes:296]
(16)
Preferred Stock

[0000950170-24-021098:notes:297]
The board of directors has the authority, without action by stockholders, to designate and issue preferred stock in one or more series. The board of directors may also designate the rights, preferences and privileges of each series of preferred stock, any or all of which may be superior to the rights of the common stock. As of January 1, 2024, no shares of preferred stock were outstanding.


## us-gaap:SegmentReportingDisclosureTextBlock

[0000950170-24-021098:notes:298]
(17)
Segment Information

[0000950170-24-021098:notes:299]
The reportable segments shown below are the Company’s segments for which separate financial information is available and upon which operating results are evaluated by the chief operating decision maker to assess performance and to allocate resources. The PCB reportable segment consists of 16 domestic system, sub-system, and PCB plants; four PCB fabrication plants in China; one in Malaysia; and one in Canada. The RF&S Components reportable segment consists of one domestic RF component plant and one RF component plant in China.

[0000950170-24-021098:notes:300]
The Company, including the chief operating decision maker, evaluates segment performance based on reportable segment income, which is operating income before amortization of intangibles. Interest expense and interest income are not presented by segment since they are not included in the measure of segment profitability reviewed by the chief operating decision maker. All inter-segment transactions have been eliminated.

[0000950170-24-021098:notes:301]
|  |  | For the Year Ended |  |
|  |  | January 1, 2024 |  |  | January 2, 2023 |  |  | January 3, 2022 |  |
|  |  | (In thousands) |  |
| Net Sales: |  |  |  |  |  |  |  |  |  |
| PCB |  | $ | 2,194,046 |  |  | $ | 2,437,942 |  |  | $ | 2,186,901 |  |
| RF&S Components |  |  | 38,521 |  |  |  | 57,104 |  |  |  | 58,583 |  |
| Other (1) |  |  | — |  |  |  | — |  |  |  | 3,256 |  |
| Total net sales |  | $ | 2,232,567 |  |  | $ | 2,495,046 |  |  | $ | 2,248,740 |  |
| Operating Segment Income: |  |  |  |  |  |  |  |  |  |
| PCB |  | $ | 271,098 |  |  | $ | 317,316 |  |  | $ | 262,442 |  |
| RF&S Components |  |  | (33,158 | ) |  |  | 23,534 |  |  |  | 22,035 |  |
| Corporate and Other (1) |  |  | (134,048 | ) |  |  | (87,811 | ) |  |  | (117,097 | ) |
| Total operating segment income |  |  | 103,892 |  |  |  | 253,039 |  |  |  | 167,380 |  |
| Amortization of definite-lived intangibles (2) |  |  | (61,576 | ) |  |  | (42,631 | ) |  |  | (41,389 | ) |
| Total operating income |  |  | 42,316 |  |  |  | 210,408 |  |  |  | 125,991 |  |
| Total other expense, net |  |  | (42,019 | ) |  |  | (27,545 | ) |  |  | (55,938 | ) |
| Income before income taxes |  | $ | 297 |  |  | $ | 182,863 |  |  | $ | 70,053 |  |

[0000950170-24-021098:notes:302]
|  |  | For the Year Ended |  |
|  |  | January 1, 2024 |  |  | January 2, 2023 |  |  | January 3, 2022 |  |
|  |  | (In thousands) |  |
| Depreciation Expense: |  |  |  |  |  |  |  |  |  |
| PCB |  | $ | 90,957 |  |  | $ | 82,760 |  |  | $ | 76,380 |  |
| RF&S Components |  |  | 1,833 |  |  |  | 1,798 |  |  |  | 1,671 |  |
| Corporate and Other (1) |  |  | 6,365 |  |  |  | 6,718 |  |  |  | 7,891 |  |
| Total depreciation expense |  | $ | 99,155 |  |  | $ | 91,276 |  |  | $ | 85,942 |  |
| Capital Expenditures: |  |  |  |  |  |  |  |  |  |
| PCB |  | $ | 193,992 |  |  | $ | 90,784 |  |  | $ | 74,028 |  |
| RF&S Components |  |  | 733 |  |  |  | 2,279 |  |  |  | 1,604 |  |
| Corporate and Other (1) |  |  | 4,001 |  |  |  | 4,345 |  |  |  | 6,735 |  |
| Total capital expenditures |  | $ | 198,726 |  |  | $ | 97,408 |  |  | $ | 82,367 |  |

[0000950170-24-021098:notes:303]
|  |  | As of |  |
|  |  | January 1, 2024 |  |  | January 2, 2023 |  |
|  |  | (In thousands) |  |
| Segment Assets: |  |  |  |  |  |  |
| PCB |  | $ | 2,032,202 |  |  | $ | 1,890,723 |  |
| RF&S Components |  |  | 142,520 |  |  |  | 202,619 |  |
| Corporate and Other (1) |  |  | 1,148,941 |  |  |  | 1,230,262 |  |
| Total assets |  | $ | 3,323,663 |  |  | $ | 3,323,604 |  |

[0000950170-24-021098:notes:304]
(1)
Other represents results from the now closed SH E-MS and SZ facilities. For the year ended January 2, 2023, operating segment income includes the gain on sale of property occupied by the Company’s former SH E-MS entity of $51,804.

[0000950170-24-021098:notes:305]
(2)
Amortization of definite-lived intangibles relates to the PCB and RF&S Components reportable segments. For the years ended January 1, 2024, January 2, 2023 and January 3, 2022, $12,901, $5,534 and $5,641, respectively, of amortization expense is included in cost of goods sold.

[0000950170-24-021098:notes:306]
The Corporate category primarily includes operating expenses that are not included in the segment operating performance measures. Corporate consists primarily of corporate governance functions such as finance, accounting, information technology and human resources personnel, as well as global sales and marketing personnel, research and development costs, and acquisition and integration costs associated with acquisitions and divestitures.

[0000950170-24-021098:notes:307]
The Company markets and sells its products in approximately 60 countries. Other than in the United States, the Company does not conduct business in any country in which its net sales in that country exceed 10% of the Company’s total net sales. Net sales and long-lived assets are as follows:

[0000950170-24-021098:notes:308]
|  |  | 2023 |  |  | 2022 |  |  | 2021 |  |
|  |  | Net Sales |  |  | Long-Lived Assets |  |  | Net Sales |  |  | Long-Lived Assets |  |  | Net Sales |  |  | Long-Lived Assets |  |
|  |  | (In thousands) |  |
| United States |  | $ | 1,263,065 |  |  | $ | 1,235,255 |  |  | $ | 1,224,334 |  |  | $ | 1,363,754 |  |  | $ | 1,049,590 |  |  | $ | 1,131,663 |  |
| China (1) |  |  | 164,280 |  |  |  | 346,602 |  |  |  | 330,558 |  |  |  | 374,474 |  |  |  | 399,364 |  |  |  | 382,580 |  |
| Other |  |  | 805,222 |  |  |  | 165,256 |  |  |  | 940,154 |  |  |  | 34,450 |  |  |  | 799,786 |  |  |  | 28,754 |  |
| Total |  | $ | 2,232,567 |  |  | $ | 1,747,113 |  |  | $ | 2,495,046 |  |  | $ | 1,772,678 |  |  | $ | 2,248,740 |  |  | $ | 1,542,997 |  |

[0000950170-24-021098:notes:309]
(1)
Includes Hong Kong

[0000950170-24-021098:notes:310]
Net sales are attributed to countries by country invoiced.


## us-gaap:EarningsPerShareTextBlock

[0000950170-24-021098:notes:311]
(18)
(Loss) Earnings Per Share

[0000950170-24-021098:notes:312]
The following is a reconciliation of the numerator and denominator used to calculate basic earnings per share and diluted earnings per share for the years ended January 1, 2024, January 2, 2023 and January 3, 2022:

[0000950170-24-021098:notes:313]
|  |  | For the Year Ended |  |
|  |  | January 1, 2024 |  |  | January 2, 2023 |  |  | January 3, 2022 |  |
|  |  | (In thousands, except per share amounts) |  |
| Net (loss) income |  | $ | (18,718 | ) |  | $ | 94,583 |  |  | $ | 54,414 |  |
| Basic weighted average shares |  |  | 102,744 |  |  |  | 102,074 |  |  |  | 106,314 |  |
| Dilutive effect of performance-based restricted stock units, restricted stock units and stock options |  |  | — |  |  |  | 1,791 |  |  |  | 1,639 |  |
| Dilutive effect of outstanding warrants |  |  | — |  |  |  | 1 |  |  |  | 200 |  |
| Diluted shares |  |  | 102,744 |  |  |  | 103,866 |  |  |  | 108,153 |  |
| (Loss) earnings per share: |  |  |  |  |  |  |  |  |  |
| Basic |  | $ | (0.18 | ) |  | $ | 0.93 |  |  | $ | 0.51 |  |
| Diluted |  | $ | (0.18 | ) |  | $ | 0.91 |  |  | $ | 0.50 |  |

[0000950170-24-021098:notes:314]
For the year ended January 1, 2024, potential shares of common stock, consisting of stock options to purchase approximately 60 shares of common stock at exercise prices ranging from $11.83 to $16.60 per share, 3,527 RSUs, and 668 PRUs were not included in the computation of diluted earnings per share because the Company incurred a net loss and as a result, the impact would be anti-dilutive.

[0000950170-24-021098:notes:315]
For the years ended January 2, 2023 and January 3, 2022, PRUs, RSUs and stock options to purchase 535 and 895 shares of common stock, respectively, were not included in the computation of diluted earnings per share. The PRUs were not included in the computation of diluted earnings per share because the performance conditions had not been met, and for RSUs and stock options, the options’ exercise prices or the total expected proceeds under the treasury stock method was greater than the average market price of common stock during the applicable year and, as a result, the impact would be anti-dilutive. 
There were warrants sold to purchase 707 shares of the Company’s common stock for the year ended January 3, 2022.


## us-gaap:TreasuryStockTextBlock

[0000950170-24-021098:notes:316]
(19)
Share Repurchase Program

[0000950170-24-021098:notes:317]
On May 3, 2023, the Company's Board of Directors authorized and approved a share repurchase program (the “2023 Repurchase Program”), under which the Company may repurchase up to $100,000 in value of the Company’s outstanding shares of common stock from time to time through May 3, 2025. The Company may repurchase shares through open market purchases, privately-negotiated transactions, or otherwise in accordance with applicable federal securities laws, including Rule 10b-18 of the Securities Exchange Act of 1934, as amended (Exchange Act), which sets certain restrictions on the method, timing, price and volume of open market stock repurchases. In addition, the Company expects to adopt one or more trading plans in accordance with Rule 10b5-1 of the Exchange Act to facilitate certain purchases that may be effected under the share repurchase program. The timing, manner, price and amount of any repurchases will be determined at the Company’s discretion, and the share repurchase program may be suspended, terminated or modified at any time for any reason. The repurchase program does not obligate the Company to acquire any specific number of shares.

[0000950170-24-021098:notes:318]
During the year ended January 1, 2024, the Company repurchased 1,804 shares of common stock for a total cost of approximately

[0000950170-24-021098:notes:319]
$24,432 (including commissions). As of January 1, 2024, the remaining amount in value available to be repurchased under the 2023 Repurchase Program was approximately $75,568.


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0000950170-24-021098:notes:320]
(20)
Restructuring Charges

[0000950170-24-021098:notes:321]
On February 8, 2023, the Company announced a consolidation plan, pursuant to which the Company ceased operations at three of its manufacturing facilities during the year ended January 1, 2024 and consolidated the operations of those facilities into other Company facilities. The three manufacturing facilities are PCB operations located in Anaheim and Santa Clara, California, and Hong Kong. The Company recorded $20,775 of restructuring charges during 2023 since the February 8, 2023 announcement. In addition, the Company recorded $5,323 of accelerated depreciation expense in the consolidated statements of operations for the year ended January 1, 2024.

[0000950170-24-021098:notes:322]
In addition to this consolidation plan, the Company recognized $3,577 of employee separation, contract termination and other costs during the year ended January 1, 2024 in connection with other global realignment restructuring efforts. Contract termination and other costs primarily represented plant closure costs.

[0000950170-24-021098:notes:323]
The below table summarizes such restructuring costs by reportable segment for the years ended January 1, 2024, January 2, 2023, and January 3, 2022:

[0000950170-24-021098:notes:324]
|  |  | For the Year Ended |  |
|  |  | January 1, 2024 |  |  | January 2, 2023 |  |  | January 3, 2022 |  |
|  |  | EmployeeSeparation/Severance |  |  | ContractTerminationand OtherCosts |  |  | Total |  |  | EmployeeSeparation/Severance |  |  | ContractTerminationand OtherCosts |  |  | Total |  |  | EmployeeSeparation/Severance |  |  | ContractTerminationand OtherCosts |  |  | Total |  |
|  |  | (In thousands) |  |
| Reportable Segment: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| PCB |  | $ | 13,780 |  |  | $ | 9,877 |  |  | $ | 23,657 |  |  | $ | 2,510 |  |  | $ | 1,036 |  |  | $ | 3,546 |  |  | $ | 504 |  |  | $ | 122 |  |  | $ | 626 |  |
| RF&S Components |  |  | 14 |  |  |  | — |  |  |  | 14 |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |
| Corporate and Other (1) |  |  | 305 |  |  |  | 376 |  |  |  | 681 |  |  |  | 31 |  |  |  | 517 |  |  |  | 548 |  |  |  | 415 |  |  |  | 3,204 |  |  |  | 3,619 |  |
|  |  | $ | 14,099 |  |  | $ | 10,253 |  |  | $ | 24,352 |  |  | $ | 2,541 |  |  | $ | 1,553 |  |  | $ | 4,094 |  |  | $ | 919 |  |  | $ | 3,326 |  |  | $ | 4,245 |  |

[0000950170-24-021098:notes:325]
Accrued restructuring costs are included as a component of other current liabilities in the consolidated balance sheet. The below table shows the utilization of the accrued restructuring costs during the year ended January 1, 2024:

[0000950170-24-021098:notes:326]
|  |  | EmployeeSeparation/Severance |  |  | ContractTerminationand OtherCosts |  |  | Total |  |
|  |  | (In thousands) |  |
| Accrued as of January 3, 2022 |  | $ | — |  |  | $ | 34 |  |  | $ | 34 |  |
| Charged to expense |  |  | 2,541 |  |  |  | 1,553 |  |  |  | 4,094 |  |
| Amount paid |  |  | (31 | ) |  |  | (1,584 | ) |  |  | (1,615 | ) |
| Accrued as of January 2, 2023 |  | $ | 2,510 |  |  | $ | 3 |  |  | $ | 2,513 |  |
| Charged to expense |  |  | 14,099 |  |  |  | 10,253 |  |  |  | 24,352 |  |
| Amount paid, net of government contributions eligible for offsetting |  |  | (15,615 | ) |  |  | (10,071 | ) |  |  | (25,686 | ) |
| Accrued as of January 1, 2024 |  | $ | 994 |  |  | $ | 185 |  |  | $ | 1,179 |  |
