# TTMI MD&A — 0000950170-24-021098


## mdna

[0000950170-24-021098:mdna:1]
ITEM 7. MANAGEMENT’S DISCUSSION AND ANALYSIS OF FINANCIAL CONDITION AND RESULTS OF OPERATIONS

[0000950170-24-021098:mdna:2]
This financial review presents our operating results for each of our three most recent fiscal years and our financial condition as of January 1, 2024. Except for historical information contained herein, the following discussion contains forward-looking statements which are subject to known and unknown risks, uncertainties and other factors that may cause our actual results to differ materially from those expressed or implied by such forward-looking statements. We discuss such risks, uncertainties and other factors throughout this Report and specifically under Item 1A of Part I of this Report, Risk Factors. In addition, the following discussion should be read in connection with the information presented in our consolidated financial statements and the related notes to our consolidated financial statements.

[0000950170-24-021098:mdna:3]
COMPANY OVERVIEW

[0000950170-24-021098:mdna:4]
We are a leading global manufacturer of technology solutions, including mission systems, radio frequency (RF) components/RF microwave/microelectronic assemblies, quick-turn and technologically advanced printed circuit boards (PCB). We focus on providing time-to-market and volume production of advanced technology products and offer a one-stop design, engineering, and manufacturing solution to our customers. This solution allows us to align technology development with the diverse needs of our customers and to enable them to reduce the time required to develop new products and bring them to market. We serve a diversified customer base consisting of approximately 1,500 customers in various markets throughout the world, including aerospace and defense, data center computing, automotive, medical, industrial and instrumentation, and networking. Our customers include original equipment manufacturers (OEMs), electronic manufacturing services (EMS) providers, original design manufacturers (ODMs), distributors and government agencies (both domestic and allied foreign governments).

[0000950170-24-021098:mdna:5]
RECENT DEVELOPMENTS

[0000950170-24-021098:mdna:6]
On November 1, 2023, we announced our selection of Syracuse, New York as the location for a new proposed advanced technology PCB manufacturing facility. We believe the planned investment aligns with New York State’s continued emphasis as a premier technology hub for U.S. electronics and the recent selection of Buffalo-Rochester-Syracuse (BRS) for the Federal Tech Hub designation. The project reflects our support for cultivating an even stronger microelectronics ecosystem in New York and across the U.S. Aerospace & Defense industrial base. We expect that the proposed facility will bring advanced technology capability for our domestic high-volume production of ultra-high-density interconnect (HDI) PCBs in support of national security requirements. We are in the advanced stages of project planning, having identified the 24-acre property adjacent to our existing facility in Syracuse for the campus expansion and the site for the new facility. We have completed initial building designs and site layout, and are now applying for the required permitting. Groundbreaking is anticipated in the first half of 2024, with the project's final scale, scope, and timeline subject to finalizing funding with various stakeholders. Phase one of the proposed project, including capital for campus-wide improvements is estimated to be $100.0 million to $130.0 million, and is anticipated to run through 2026. Our planned capital investment commitments will be determined after finalizing terms with various stakeholders.

[0000950170-24-021098:mdna:7]
As announced on February 8, 2023, we substantially closed in fiscal year 2023 our PCB manufacturing operations in Anaheim and Santa Clara, California, and Hong Kong and consolidated the business from these sites into our remaining facilities. The plant closures are expected to improve both facility and talent utilization across our footprint resulting in improved profitability. We recorded $20.8 million of restructuring charges and $5.3 million of accelerated depreciation expense during 2023 related to this.

[0000950170-24-021098:mdna:8]
On March 30, 2023, we completed the sale of our Shanghai Backplane Assembly entity for approximately $11.2 million to DBG Holdings Limited (DBG), which is wholly owned by DBG Technology Co. Ltd., a public company traded on the Shenzhen Stock Exchange. We recorded a gain on the sale of $1.3 million.

[0000950170-24-021098:mdna:9]
FINANCIAL OVERVIEW

[0000950170-24-021098:mdna:10]
We use a 52 or 53 week fiscal calendar with the fourth quarter ending on the Monday nearest December 31. Fiscal year 2023 and 2022 were 52 weeks ended on January 1, 2024 and January 2, 2023, respectively. Fiscal year 2021 consisted of 53 weeks ended on January 3, 2022, with the additional week included in the fourth quarter. We estimate the additional week contributed approximately $42.2 million of additional revenue and approximately $2.5 million of additional operating income for the year ended January 3, 2022.

[0000950170-24-021098:mdna:11]
While our customers include both OEMs and EMS providers, we measure customers based on OEM companies, as they are the ultimate end customers. Sales to our five largest customers accounted for 41%, 33% and 30% of our net sales in fiscal years 2023, 2022 and 2021, respectively. We sell to OEMs both directly and indirectly through EMS providers.

[0000950170-24-021098:mdna:12]
The following table shows the percentage of our net sales attributable to each of the principal end markets we serve for the periods indicated:

[0000950170-24-021098:mdna:13]
|  |  | For the Year Ended |  |  |
| End Markets (1) |  | January 1, 2024 |  |  |  | January 2, 2023 |  |  |  | January 3, 2022 |  |  |
| Aerospace and Defense |  |  | 45 |  | % |  |  | 35 |  | % |  |  | 33 |  | % |
| Automotive |  |  | 16 |  |  |  |  | 17 |  |  |  |  | 18 |  |  |
| Data Center Computing |  |  | 14 |  |  |  |  | 15 |  |  |  |  | 14 |  |  |
| Medical/Industrial/Instrumentation |  |  | 17 |  |  |  |  | 20 |  |  |  |  | 19 |  |  |
| Networking |  |  | 8 |  |  |  |  | 13 |  |  |  |  | 15 |  |  |
| Other (2) |  |  | — |  |  |  |  | — |  |  |  |  | 1 |  |  |
| Total |  |  | 100 |  | % |  |  | 100 |  | % |  |  | 100 |  | % |

[0000950170-24-021098:mdna:14]
(1)
Sales to EMS companies are classified by the end markets of their OEM customers.

[0000950170-24-021098:mdna:15]
(2)
Other end market reflects direct sales to EMS and distributor customers.

[0000950170-24-021098:mdna:16]
We derive revenues primarily from the sale of PCBs, engineered systems using customer-supplied engineering and design plans as well as our long-term contracts related to the design and manufacture of highly sophisticated intelligence, surveillance and communications solutions, and RF and microwave/microelectronics components, assemblies, and subsystems. Orders for products generally correspond to the production schedules of our customers and are supported with firm purchase orders. Our customers have continuous control of the work in progress and finished goods throughout the PCB and engineered systems manufacturing process, as these are built to customer specifications with no alternative use, and there is an enforceable right of payment for work performed to date. As a result, we recognize revenue progressively over time based on the extent of progress towards completion of the performance obligation. We recognize revenue based on a cost method as it best depicts the transfer of control to the customer which takes place as we incur costs. Revenues are recorded proportionally as costs are incurred.

[0000950170-24-021098:mdna:17]
We also manufacture certain components, assemblies, subsystems, and completed systems which service our RF and Specialty Components (RF&S Components) customers and certain aerospace and defense customers. We recognize revenue at a point in time upon transfer of control of the products to our customer. Point in time recognition was determined as our customers do not simultaneously receive or consume the benefits provided by our performance and the asset being manufactured has alternative uses to us.

[0000950170-24-021098:mdna:18]
Net sales consist of gross sales less an allowance for returns, which typically have been approximately 2% of gross sales. We provide our customers a limited right of return for defective PCBs including components, subsystems, and assemblies. We record an estimate for sales returns and allowances at the time of sale based on historical results and anticipated returns.

[0000950170-24-021098:mdna:19]
Cost of goods sold consists of materials, labor, outside services, and overhead expenses incurred in the manufacture and testing of our products. Shipping and handling fees and related freight costs and supplies associated with shipping products are also included as a component of cost of goods sold. Many factors affect our gross margin, including capacity utilization, product mix, production volume, supply chain issues, and yield.

[0000950170-24-021098:mdna:20]
Selling and marketing expenses consist primarily of salaries, labor related benefits, and commissions paid to our internal sales force, independent sales representatives, and our sales support staff, as well as costs associated with marketing materials and trade shows.

[0000950170-24-021098:mdna:21]
General and administrative costs primarily include the salaries for executive, finance, accounting, information technology, and human resources personnel, as well as expenses for accounting and legal assistance, incentive compensation expense, and gains or losses on the sale or disposal of property, plant and equipment.

[0000950170-24-021098:mdna:22]
Research and development expenses consist primarily of salaries and labor related benefits paid to our research and development staff, as well as material costs.

[0000950170-24-021098:mdna:23]
CRITICAL ACCOUNTING POLICIES AND ESTIMATES

[0000950170-24-021098:mdna:24]
Our consolidated financial statements included in this Report have been prepared in accordance with accounting principles generally accepted in the United States of America (U.S. GAAP). The preparation of these financial statements requires management to make estimates and assumptions that affect the reported amounts of assets, liabilities, net sales and expenses, and related disclosure of contingent assets and liabilities.

[0000950170-24-021098:mdna:25]
A critical accounting policy is defined as one that is both material to the presentation of our consolidated financial statements and requires us to make judgments that could have a material effect on our financial condition or results of operations. These policies require us to make assumptions about matters that are highly uncertain at the time of the estimate. Critical accounting estimates refers to those estimates made in accordance with U.S. GAAP that have had or are reasonably likely to have a material impact on the amounts reported

[0000950170-24-021098:mdna:26]
in the consolidated financial statements and the related notes due to the significant level of uncertainty involved in developing the estimate. Different estimates we could reasonably have used, or changes in the estimates that are reasonably likely to occur, could have a material effect on our financial condition or results of operations.

[0000950170-24-021098:mdna:27]
We base our estimates on historical experience and on various other assumptions that we believe to be reasonable under the circumstances, the results of which form the basis for making judgments about the carrying values of assets and liabilities that are not readily apparent from other sources. Management has discussed the development, selection and disclosure of these estimates with the audit committee of our board of directors. Actual results may differ from these estimates under different assumptions or conditions.

[0000950170-24-021098:mdna:28]
We believe the following critical accounting policies and estimates reflect the more significant judgments and estimates used by us in preparing our consolidated financial statements:

[0000950170-24-021098:mdna:29]
Revenue Recognition

[0000950170-24-021098:mdna:30]
Revenue is recognized when control of the promised goods or services is transferred to customers, in an amount that reflects the consideration to which we expect to be entitled in exchange for those goods or services. We apply a five-step approach in determining the amount and timing of revenue to be recognized: (1) identifying the contract with a customer; (2) identifying the performance obligations in the contract; (3) determining the transaction price; (4) allocating the transaction price to the performance obligations in the contract; and (5) recognizing revenue when the corresponding performance obligation is satisfied.

[0000950170-24-021098:mdna:31]
For PCBs and engineered systems, including pursuant to long-term contracts related to the manufacture of highly sophisticated intelligence, surveillance and communications solutions, components, assemblies and subsystems, orders for products generally correspond to the production schedules of customers and are supported with firm purchase orders. Customers have continuous control of the work in progress and finished goods throughout the PCB and engineered systems manufacturing process, as these are built to customer specifications with no alternative use, and there is an enforceable right to payment for work performed to date. As a result, we recognize revenue progressively over time based on the extent of progress towards completion of the performance obligation. Revenue recognized is based on a cost method as it best depicts the transfer of control to the customer which takes place as we incur costs. Revenues are recorded proportionally as costs are incurred.

[0000950170-24-021098:mdna:32]
For revenue recorded on an over time basis, we apply a gross margin estimate to inventory in process of being manufactured for customers to determine how much of a contract asset or contract liability should be recorded at period end. Contract assets totaled $292.1 million and $335.8 million for the years ended January 1, 2024 and January 2, 2023, respectively. The decrease in contract assets is primarily due to timing of progress on customer work orders at year-end. In addition, $11.3 million and $7.1 million of contract assets are expected to be collected after one year and included as a component of deposits and other non-current assets on the consolidated balance sheets as of January 1, 2024 and January 2, 2023, respectively. We use historical information to estimate the gross margin associated with performance obligations that are satisfied over time. We reevaluate our estimate of gross margins on a quarterly basis. Based on the review of gross margins, we update our estimate to the model as necessary. If our estimates of gross margins are inaccurate, we may recognize too much or too little revenue in a period. While experience has shown that trends in gross margins are not volatile, changes in pricing or cost efficiencies could create significant fluctuations. An increase or decrease of 200 basis points in gross margin estimates would have increased or decreased our contract assets by $3.6 million and $3.4 million, respectively, and decreased or increased our contract liabilities by $3.6 million, respectively.

[0000950170-24-021098:mdna:33]
In addition, we manufacture components, assemblies, subsystems, and completed systems which service our RF&S Components and certain aerospace and defense customers. We recognize revenue at a point in time upon transfer of control of the products to the customer. Point in time recognition was determined as our customer does not simultaneously receive or consume the benefits provided by our performance and the asset being manufactured has alternative uses to us.

[0000950170-24-021098:mdna:34]
Goodwill and Intangible Assets

[0000950170-24-021098:mdna:35]
We have significant goodwill and definite-lived intangibles. We review these assets for impairment whenever events or changes in circumstances indicate that the carrying amount of such assets may not be recoverable. In addition, we perform an impairment test related to goodwill at least annually. As necessary, we make judgments regarding future cash flow forecasts in the assessment of impairment.

[0000950170-24-021098:mdna:36]
Goodwill is allocated to our reporting units, which are our operating segments or one level below our operating segments (the component level). Reporting units are determined by the discrete financial information available for the component and whether it is regularly reviewed by segment management. Components are aggregated into a single reporting unit if they share similar economic characteristics. The Company evaluates its goodwill on an annual basis in the fourth quarter or more frequently if it believes indicators of impairment exist. We assess qualitative factors to determine whether it is more likely than not that the fair value of a reporting unit is less than its carrying amount or perform a quantitative impairment test. When tested quantitatively, we compare the fair value of the applicable reporting unit with its carrying value. We estimate the fair values of our reporting units using a combination of the discounted cash flow (DCF) and market approach. If the carrying amount of a reporting unit exceeds the reporting unit’s fair value, the amount by which the carrying value exceeds the fair value is recognized as an impairment loss.

[0000950170-24-021098:mdna:37]
We have two reportable segments: PCB and RF&S Components. Goodwill is attributable to both of our PCB and RF&S Components reportable segments.

[0000950170-24-021098:mdna:38]
During the third quarter of 2023, we experienced a continued decline in sales and profitability in the RF and Specialty Components (RF&S Components) reporting unit and have reduced our forecasted sales in future years. We considered these factors to be indicators of potential impairment requiring us to test the related goodwill for impairment. As of October 2, 2023, we completed a quantitative goodwill impairment analysis related to our RF&S Components reporting unit by comparing the fair value of the reporting unit with its carrying amount. In making this assessment, we rely on a number of factors, including expected future operating results, business plans, economic projections, anticipated future cash flows, business trends and declines in our market capitalization. We determined the fair value of the reporting unit by using both a discounted cash flow (DCF) and a market approach. Under the market approach, we used revenue and earnings multiples based on comparable industry multiples to estimate the fair value of the reporting unit.

[0000950170-24-021098:mdna:39]
Under the DCF approach, we estimated the future cash flows, as well as selected a risk-adjusted discount rate to measure the present value of the anticipated cash flows. When determining future cash flow estimates, we considered historical results adjusted to reflect current and anticipated future operating conditions. We estimated cash flows for the reporting unit over a discrete period and a terminal period (considering expected long-term growth rates and trends).

[0000950170-24-021098:mdna:40]
Based on our analysis, we determined that the fair value of the RF&S Components reporting unit was less than its carrying value and recorded a non-cash goodwill impairment charge of $44.1 million. Estimating the fair value of the reporting unit requires us to make assumptions and estimates in such areas as future economic conditions, industry-specific conditions, product pricing, and necessary capital expenditures. The use of different assumptions or estimates for future cash flows, discount rates, or terminal growth rates could produce substantially different estimates of the fair value of the reporting unit. We may be subject to additional goodwill impairment charges if actual results do not meet the estimates used in determining the fair value of goodwill and the associated goodwill impairment charge.

[0000950170-24-021098:mdna:41]
In the fourth quarter of 2023, we performed our annual impairment test qualitatively and concluded that it was more likely than not that goodwill was not impaired. Management will continue to monitor the reporting units for changes in the business environment that could impact recoverability. The recoverability of goodwill is dependent upon the continued growth of cash flows from our business activities. If the economy or business environment falter and we are unable to achieve our assumed revenue growth rates or profit margin percentages, our projections used would need to be re-measured, which could impact the carrying value of our goodwill in one or more of our reporting units.

[0000950170-24-021098:mdna:42]
We also assess definite-lived intangibles for potential impairment given similar impairment indicators. When indicators of impairment exist related to our definite-lived intangible assets, we use an estimate of the undiscounted cash flows in measuring whether the carrying amount of the assets is recoverable. If the sum of the undiscounted cash flows is less than the carrying amount of the net assets, impairment is measured based on the difference between the net asset’s carrying value and estimated fair value. Fair value is determined through various valuation techniques, including cost-based, market and income approaches as considered necessary, which involve judgments related to future cash flows and the application of the appropriate valuation model.

[0000950170-24-021098:mdna:43]
Business Combinations

[0000950170-24-021098:mdna:44]
The application of acquisition accounting to a business acquisition requires that we identify the individual assets acquired and liabilities assumed and estimate the fair value of each. The fair value of assets acquired and liabilities assumed in a business acquisition are recognized at the acquisition date, with the purchase price exceeding the fair values being recognized as goodwill. Determining fair value of identifiable assets, particularly intangibles, liabilities acquired and contingent obligations assumed requires management to make estimates. In certain circumstances, the allocations of the purchase price are based upon preliminary estimates and assumptions and subject to revision when we receive final information, including appraisals and other analysis. Accordingly, the measurement period for such purchase price allocations will end when the information, or the facts and circumstances, becomes available, but will not exceed twelve months. We will recognize measurement-period adjustments during the period of resolution, including the effect on earnings of any amounts that would have been recorded in previous periods if the accounting had been completed at the acquisition date.

[0000950170-24-021098:mdna:45]
Goodwill and intangible assets often represent a significant portion of the assets acquired in a business combination. We recognize the fair value of an acquired intangible apart from goodwill whenever the intangible arises from contractual or other legal rights, or when it can be separated or divided from the acquired entity and sold, transferred, licensed, rented or exchanged, either individually or in combination with a related contract, asset or liability. Intangible assets consist primarily of customer relationships, technology, backlog, and tradenames acquired in business combinations. The fair value of the identifiable intangible assets was determined using various valuation methods including relief from royalty and excess earnings to determine the present value of expected future cash flows for each identifiable intangible asset based on discount rates. The expected cash flows were estimated using available historical data adjusted based on a market participant perspective. We used risk adjusted discount rates between 7.0% and 8.0% to discount the expected future cash flows.

[0000950170-24-021098:mdna:46]
RESULTS OF OPERATIONS

[0000950170-24-021098:mdna:47]
We operate on a 52 or 53 week year ending on the Monday nearest December 31. Fiscal year 2023 and 2022 were 52 weeks ended on January 1, 2024 and January 2, 2023, respectively. Fiscal year 2021 consisted of 53 weeks ended on January 3, 2022, with the additional week included in the fourth quarter. We estimate the additional week contributed approximately $42.2 million of additional revenue and approximately $2.5 million of additional operating income for the year ended January 3, 2022.

[0000950170-24-021098:mdna:48]
The following table sets forth the relationship of various items to net sales in our consolidated statements of operations:

[0000950170-24-021098:mdna:49]
|  |  | For the Year Ended |  |  |
|  |  | January 1, 2024 |  |  |  | January 2, 2023 |  |  |  | January 3, 2022 |  |  |
| Net sales |  |  | 100.0 |  | % |  |  | 100.0 |  | % |  |  | 100.0 |  | % |
| Cost of goods sold |  |  | 81.5 |  |  |  |  | 81.6 |  |  |  |  | 83.5 |  |  |
| Gross profit |  |  | 18.5 |  |  |  |  | 18.4 |  |  |  |  | 16.5 |  |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |
| Selling and marketing |  |  | 3.4 |  |  |  |  | 3.0 |  |  |  |  | 2.8 |  |  |
| General and administrative |  |  | 6.7 |  |  |  |  | 6.4 |  |  |  |  | 5.5 |  |  |
| Research and development |  |  | 1.2 |  |  |  |  | 1.0 |  |  |  |  | 0.8 |  |  |
| Amortization of definite-lived intangibles |  |  | 2.2 |  |  |  |  | 1.5 |  |  |  |  | 1.6 |  |  |
| Impairment of goodwill |  |  | 2.0 |  |  |  |  | — |  |  |  |  | — |  |  |
| Restructuring charges |  |  | 1.1 |  |  |  |  | 0.2 |  |  |  |  | 0.2 |  |  |
| Gain on sale of Shanghai E-MS (SH E-MS) property |  |  | — |  |  |  |  | (2.1 | ) |  |  |  | — |  |  |
| Total operating expenses |  |  | 16.6 |  |  |  |  | 10.0 |  |  |  |  | 10.9 |  |  |
| Operating income |  |  | 1.9 |  |  |  |  | 8.4 |  |  |  |  | 5.6 |  |  |
| Other (expense) income: |  |  |  |  |  |  |  |  |  |  |  |  |
| Interest expense |  |  | (2.2 | ) |  |  |  | (1.8 | ) |  |  |  | (2.0 | ) |  |
| Loss on extinguishment of debt |  |  | (0.1 | ) |  |  |  | — |  |  |  |  | (0.7 | ) |  |
| Gain on sale of subsidiary |  |  | 0.1 |  |  |  |  | — |  |  |  |  | — |  |  |
| Other, net |  |  | 0.3 |  |  |  |  | 0.7 |  |  |  |  | 0.2 |  |  |
| Total other expense, net |  |  | (1.9 | ) |  |  |  | (1.1 | ) |  |  |  | (2.5 | ) |  |
| Income before income taxes |  |  | — |  |  |  |  | 7.3 |  |  |  |  | 3.1 |  |  |
| Income tax provision |  |  | (0.9 | ) |  |  |  | (3.5 | ) |  |  |  | (0.7 | ) |  |
| Net (loss) income |  |  | (0.9 | ) | % |  |  | 3.8 |  | % |  |  | 2.4 |  | % |

[0000950170-24-021098:mdna:50]
The Telephonics acquisition occurred on June 27, 2022. Accordingly, our fiscal year 2022 only includes Telephonics’ 2022 results of operations since the acquisition date. As of the fourth quarter of 2022, we completed our integration of Telephonics and reassessed our reportable segments, which resulted in the inclusion of Telephonics into our PCB reportable segment.

[0000950170-24-021098:mdna:51]
Net Sales

[0000950170-24-021098:mdna:52]
Total net sales decreased $262.5 million, or 10.5%, to $2,232.5 million for the year ended January 1, 2024 from $2,495.0 million for the year ended January 2, 2023. Net sales for the PCB reportable segment decreased $243.9 million, or 10.0%, to $2,194.0 million for the year ended January 1, 2024 from $2,437.9 million for the year ended January 2, 2023. The primary driver of this decrease was demand weakness in our commercial end markets and decrease in sales of $36.3 million from the Shanghai Backplane Assembly entity we sold in the first quarter of 2023, partially offset by the inclusion of a full year of results of Telephonics during the year ended January 1, 2024 (as compared to the inclusion in the year ended January 2, 2023 of its results commencing with its acquisition in June 2022), as well as organic growth in our Aerospace and Defense end market. Net sales for the RF&S Components reportable segment decreased $18.6 million, or 32.5%, to $38.5 million for the year ended January 1, 2024 from $57.1 million for the year ended January 2, 2023. The decrease in RF&S Components net sales was primarily due to lower demand in our Networking end market.

[0000950170-24-021098:mdna:53]
Total net sales increased $246.3 million, or 11.0%, to $2,495.0 million for the year ended January 2, 2023 from $2,248.7 million for the year ended January 3, 2022. Net sales for the PCB reportable segment increased $251.0 million, or 11.5%, to $2,437.9 million for the year ended January 2, 2023 from $2,186.9 million for the year ended January 3, 2022. This increase in PCB net sales was primarily due to the acquisition of Telephonics in June 2022, which accounted for $125.9 million in net sales for the year ended January 2, 2023 since the date of acquisition, as well as increased demand in our Medical/Industrial/Instrumentation, Data Center Computing, and Automotive end markets. The increase in PCB net sales also benefited from a 15.4% increase in the average price per square foot driven mainly by better product mix, higher pricing and premium revenue, partially offset by a 5.6% decrease in the volume of PCB shipments as compared to the year ended January 3, 2022. Net sales for the RF&S Components reportable segment decreased $1.5 million, or 2.5%, to $57.1 million for the year end January 2, 2023 from $58.6 million for the year ended January 3, 2022. The decrease in RF&S Components net sales was primarily due to lower demand.

[0000950170-24-021098:mdna:54]
For information regarding net sales by country, see Note 17 of the Notes to Consolidated Financial Statements.

[0000950170-24-021098:mdna:55]
45

[0000950170-24-021098:mdna:56]
Gross Margin

[0000950170-24-021098:mdna:57]
Overall gross margin increased slightly to 18.5% for the year ended January 1, 2024 from 18.4% for the year ended January 2, 2023. The increase in overall gross margin was due to the increase in gross margin for the PCB reportable segment to 19.3% for the year ended January 1, 2024, from 18.2% for the year ended January 2, 2023. This increase was primarily due to better product mix and improved execution in our North America region, partially offset by lower revenues and less quick-turn premium in our commercial markets. Gross margin for the RF&S Components reportable segment decreased to 54.7% for the year ended January 1, 2024, from 62.3% for the year ended January 2, 2023, primarily due to lower sales.

[0000950170-24-021098:mdna:58]
Overall gross margin increased to 18.4% for the year ended January 2, 2023 from 16.5% for the year ended January 3, 2022. The increase in overall gross margin was due to the increase in gross margin for the PCB reportable segment to 18.2% for the year ended January 2, 2023, from 16.3% for the year ended January 3, 2022. This increase was primarily due to better product mix, higher pricing and premium revenue, partially offset by higher labor costs, particularly in North America as we raised wages in the first quarter of 2022 to be more competitive. Gross margin for the RF&S Components reportable segment increased to 62.3% for the year ended January 2, 2023, from 52.6% for the year ended January 3, 2022, primarily due to favorable product mix.

[0000950170-24-021098:mdna:59]
An important factor affecting gross margins is capacity utilization, which is measured by the actual production as a percentage of maximum capacity. This measure is particularly important in our high-volume PCB facilities in Asia, as a significant portion of our operating costs are fixed in nature. North America utilization figures are not as meaningful as Asia because bottlenecks in these high mix low volume facilities tend to occur in areas outside of plating, which is the core process that we use for calculating utilization rates. Capacity utilization for the year ended January 1, 2024 in our Asia and North America PCB facilities was 49% and 38%, respectively, compared to 75% and 45%, respectively, for the year ended January 2, 2023. The decrease in capacity utilization in our Asia PCB facilities was caused by a decline in production volumes due to demand weakness in our commercial end markets while the decrease in our North America PCB facilities was due to the additional plating capacity added as well as a greater mix of higher technology product that requires less finish plating.

[0000950170-24-021098:mdna:60]
Selling and Marketing Expenses

[0000950170-24-021098:mdna:61]
Selling and marketing expenses increased $1.7 million to $76.9 million for the year ended January 1, 2024 from $75.2 million for the year ended January 2, 2023. As a percentage of net sales, selling and marketing expenses were 3.4% for the year ended January 1, 2024 as compared to 3.0% for the year ended January 2, 2023. The increase in selling and marketing expense was primarily due to the inclusion of a full year of Telephonics expenses, which resulted in an increase of $3.5 million and an increase in labor and travel costs, partially offset by a $3.7 million decrease in commission expense.

[0000950170-24-021098:mdna:62]
Selling and marketing expenses increased $12.2 million to $75.2 million for the year ended January 2, 2023 from $63.0 million for the year ended January 3, 2022. As a percentage of net sales, selling and marketing expenses were 3.0% for the year ended January 2, 2023 as compared to 2.8% for the year ended January 3, 2022. The increase in selling and marketing expense was primarily due to $4.8 million of selling and marketing expenses incurred by Telephonics post acquisition and increases in labor costs and commission expense company wide.

[0000950170-24-021098:mdna:63]
General and Administrative Expenses

[0000950170-24-021098:mdna:64]
General and administrative expenses decreased $8.5 million to $149.6 million for the year ended January 1, 2024 from $158.2 million for the year ended January 2, 2023, but increased as a percentage of net sales to 6.7% from 6.4% over the same two periods. The decrease in the amount of general and administrative expenses primarily resulted from $13.2 million of reduced acquisition and integration costs mainly related to the acquisition of Telephonics on June 27, 2022. In addition, there were decreases in incentive compensation and bad debt. These decreases were partially offset by the inclusion of a full year of Telephonics expenses, which resulted in an increase of $1.6 million, increase in labor costs and lower gains on the sale of assets. The increase of general and administrative expenses as a percentage of net sales resulted from lower net sales for the year ended January 1, 2024 as compared to January 2, 2023.

[0000950170-24-021098:mdna:65]
General and administrative expenses increased $33.3 million to $158.2 million, or 6.4% of net sales, for the year ended January 2, 2023 from $124.9 million, or 5.5% of net sales, for the year ended January 3, 2022. The increase in expense was primarily due to $11.5 million of one-time costs incurred in connection with the acquisition of Telephonics on June 27, 2022 and $6.6 million of general and administrative expenses incurred by Telephonics post acquisition. In addition, there were increases in incentive compensation, labor costs, and bad debt. These increases were partially offset by gains on the sale of assets.

[0000950170-24-021098:mdna:66]
Research and Development Expenses

[0000950170-24-021098:mdna:67]
Research and development expenses increased $2.5 million to $27.3 million, or 1.2% of net sales, for the year ended January 1, 2024 from $24.8 million, or 1.0% of net sales, for the year ended January 2, 2023. The increase in expense was primarily due to the inclusion of a full year of Telephonics expenses, which resulted in an increase of $4.5 million, partially offset by a decrease in labor and material costs.

[0000950170-24-021098:mdna:68]
Research and development expenses increased $6.7 million to $24.8 million, or 1.0% of net sales, for the year ended January 2, 2023 from $18.1 million, or 0.8% of net sales, for the year ended January 3, 2022. The increase in expense was primarily due to $3.4 million of research and development expense incurred by Telephonics post acquisition and increases in labor costs.

[0000950170-24-021098:mdna:69]
Impairment of Goodwill

[0000950170-24-021098:mdna:70]
For the year ended January 1, 2024, we recorded a goodwill impairment charge of $44.1 million. See Note 5 of the Notes to Consolidated Financial Statements for further information.

[0000950170-24-021098:mdna:71]
Restructuring Charges

[0000950170-24-021098:mdna:72]
For the years ended January 1, 2024, January 2, 2023, and January 3, 2022, we incurred restructuring charges of $24.4 million, $4.1 million and $4.2 million, respectively, related to our global realignment restructuring efforts.

[0000950170-24-021098:mdna:73]
For the year ended January 1, 2024, we recognized restructuring charges of $23.7 million and $0.7 million in our PCB reportable segment and Corporate and Other, respectively. For the year ended January 2, 2023, we recognized restructuring charges of $3.5 million and $0.6 million in our PCB reportable segment and Corporate and Other, respectively. For the year ended January 3, 2022, we recognized restructuring charges of $0.6 million and $3.6 million in our PCB reportable segment and Corporate and Other, respectively. These charges primarily represent employee separation and contract termination and other costs associated with the restructuring plans.

[0000950170-24-021098:mdna:74]
Gain on sale of SH E-MS Property

[0000950170-24-021098:mdna:75]
On December 22, 2022, land, building, and relevant ancillary assets related to our former SH E-MS manufacturing facility was expropriated by the Chinese government for a compensation fee of Renminbi (RMB) 477.6 million ($69.2 million as of January 2, 2023) and we recorded a gain on the sale of $51.8 million during the year ended January 2, 2023. We received 90% of the proceeds from the sale during 2023 and the remaining 10% was collected subsequent to year-end.

[0000950170-24-021098:mdna:76]
Other Expense

[0000950170-24-021098:mdna:77]
Other expense, net increased $14.5 million to $42.0 million for the year ended January 1, 2024 from $27.5 million for the year ended January 2, 2023. The increase in other expense, net was primarily due to:

[0000950170-24-021098:mdna:78]
•	a decrease in other income of $16.8 million related to the strengthening of the Chinese RMB, which we utilize at our China facilities for employee-related expenses, RMB denominated purchases, and other costs of running our operations in China,

[0000950170-24-021098:mdna:79]
•	an increase in interest expense of $2.6 million due to higher interest rates,

[0000950170-24-021098:mdna:80]
•	partially offset by an increase in interest income of $5.9 million.

[0000950170-24-021098:mdna:81]
Other expense, net decreased $28.4 million to $27.5 million for the year ended January 2, 2023 from $55.9 million for the year ended January 3, 2022. The decrease in other expense, net was primarily due to:

[0000950170-24-021098:mdna:82]
•	an increase in other income of $17.8 million related to the weakening of the Chinese RMB, which we utilize at our China facilities for employee-related expenses, RMB denominated purchases, and other costs of running our operations in China,

[0000950170-24-021098:mdna:83]
•	the absence of $15.2 million of loss on extinguishment of debt,

[0000950170-24-021098:mdna:84]
•	partially offset by the decrease in other income of $4.1 million related to the change in fair value of warrant liabilities.

[0000950170-24-021098:mdna:85]
Income Taxes

[0000950170-24-021098:mdna:86]
Income tax expense decreased $69.3 million to $19.0 million for the year ended January 1, 2024 from $88.3 million for the year ended January 2, 2023. The change in income tax from fiscal year 2022 to fiscal year 2023 was primarily due to a decrease in pre-tax book income, the absence of an expense to set up a valuation allowance against U.S. deferred tax assets in 2022, and the release of uncertain tax positions due to lapse of statute of limitations.

[0000950170-24-021098:mdna:87]
Our effective tax rate is primarily impacted by tax rates in China and Hong Kong, the U.S. federal income tax rate, apportioned state income tax rates, the generation of credits and deductions available to us, as well as changes in the valuation allowance, certain non-deductible items, global intangible low taxed income, and the establishment of a deferred tax liability related to unremitted foreign earnings.

[0000950170-24-021098:mdna:88]
Income tax expense increased $72.7 million to $88.3 million for the year ended January 2, 2023 from $15.6 million for the year ended January 3, 2022. The change in income tax from fiscal year 2021 to fiscal year 2022 was primarily due to an increase in the valuation allowance set up against U.S. deferred tax assets, an increase in pre-tax book income, and a gain on the sale of certain assets of our Shanghai E-MS subsidiary.

[0000950170-24-021098:mdna:89]
Liquidity and Capital Resources

[0000950170-24-021098:mdna:90]
Our principal sources of liquidity have been cash provided by operations, the issuance of debt, and borrowings under our revolving credit facilities. Our principal uses of cash have been to finance capital expenditures, finance acquisitions, fund working capital requirements, to repay debt obligations, and to repurchase common stock. We anticipate that financing capital expenditures, financing acquisitions, funding working capital requirements, servicing debt, and repurchasing common stock will be the principal demands on our cash in the future.

[0000950170-24-021098:mdna:91]
Cash flow provided by operating activities during the year ended January 1, 2024 was $187.3 million as compared to $272.9 million in the same period in fiscal year 2022. The decrease in cash flow was primarily due to the $113.3 million decrease in net income.

[0000950170-24-021098:mdna:92]
Net cash used in investing activities was approximately $92.0 million for the year ended January 1, 2024, primarily reflecting the use of $160.2 million for purchases of property, plant and equipment and other assets, partially offset by the receipt of $61.8 million of proceeds from the sale of property associated with our Shanghai E-MS subsidiary and $6.0 million of proceeds from the sale of our Shanghai Backplane Assembly subsidiary, net of cash disposed. Net cash used in investing activities was approximately $395.5 million for the year ended January 2, 2023, primarily reflecting $298.3 million to fund the acquisition of Telephonics, $102.9 million for purchases of property, plant and equipment and other assets, less $6.0 million for proceeds from sale of property, plant and equipment and other assets.

[0000950170-24-021098:mdna:93]
Net cash used in financing activities during the year ended January 1, 2024 was $47.7 million, reflecting repayment of long-term debt borrowings of $291.6 million, repurchases of common stock of $24.4 million, refund of customer deposits of $7.5 million, payment of debt issuance costs of $5.5 million and payment of original issue discount of $3.5 million, partially offset by the receipt of proceeds of $234.8 million from long-term debt borrowing and proceeds of $50.0 million from borrowings under our revolving credit facilities. Net cash used in financing activities during the year ended January 2, 2023 was $11.3 million, primarily reflecting repurchases of common stock of $35.4 million, cash used to settle warrants of $0.9 million, less customer deposits of $25.0 million.

[0000950170-24-021098:mdna:94]
As of January 1, 2024, we had cash and cash equivalents of approximately $450.2 million, of which approximately $195.9 million was held by our foreign subsidiaries, primarily in China, and $189.1 million of available borrowing capacity under our revolving credit facilities. Should we choose to remit cash to the United States from our foreign locations, we may incur tax obligations which would reduce the amount of cash ultimately available to the United States. However, we believe there would be no material tax consequences not previously accrued for the repatriation of this cash.

[0000950170-24-021098:mdna:95]
Our 2024 capital expenditure plan is expected to be in the range of $135.0 million to $155.0 million.

[0000950170-24-021098:mdna:96]
Share Repurchases

[0000950170-24-021098:mdna:97]
On May 3, 2023, our board of directors authorized a share repurchase program (the “2023 Repurchase Program”) allowing us to repurchase up to $100.0 million of our common stock from time to time through May 3, 2025. During 2023, we repurchased a total of 1.8 million shares of our common stock for $24.4 million (including commissions). As of January 1, 2024, the remaining amount in value available to be repurchased under the 2023 Repurchase Program was approximately $75.6 million.

[0000950170-24-021098:mdna:98]
Long-term Debt and Letters of Credit

[0000950170-24-021098:mdna:99]
As of January 1, 2024, we had $917.8 million of outstanding debt, net of discount and debt issuance costs, composed of $495.9 million of Senior Notes due March 2029, $341.9 million of a Term Loan due May 2030, and $80.0 million under the Asia Asset-Based Lending Credit Agreement (Asia ABL).

[0000950170-24-021098:mdna:100]
Pursuant to the terms of the Senior Notes due 2029 and Term Loan Facility, we are subject to certain affirmative and negative covenants, including limitations on indebtedness, corporate transactions, investments, dispositions, and restricted payments. Under the U.S. ABL and Asia ABL (collectively, the ABL Revolving Loans), we are also subject to various financial covenants, including leverage and fixed charge coverage ratios. As of January 1, 2024, we were in compliance with the covenants under the Senior Notes due 2029, Term Loan Facility and ABL Revolving Loans.

[0000950170-24-021098:mdna:101]
Based on our current level of operations, we believe that cash generated from operations, cash on hand and cash from the issuance of term and revolving debt will be adequate to meet our currently anticipated capital expenditure, debt service, and working capital needs for the next twelve months. Additional information regarding our indebtedness, including information about the credit available under our debt facilities, interest rates and other key terms of our outstanding indebtedness, is included in Note 7 of the Notes to Consolidated Financial Statements included in this Report.

[0000950170-24-021098:mdna:102]
Contractual Obligations and Commitments

[0000950170-24-021098:mdna:103]
As part of our ongoing operations, we enter into contractual arrangements that obligate us to make future cash payments. These obligations impact our liquidity and capital resource needs. Our estimated future obligations consist of long-term debt obligations, interest on debt obligations, derivative liabilities, purchase obligations, and leases as of January 1, 2024.

[0000950170-24-021098:mdna:104]
A summary of our long-term debt obligations as of January 1, 2024 is included in Note 7 of the Notes to Consolidated Financial Statements included in this Report.

[0000950170-24-021098:mdna:105]
Our aggregate interest on debt obligations as of January 1, 2024 amounted to $310.1 million, which are expected to be settled as follows: $53.8 million within 1 year, $106.8 million within 1-3 years, $103.3 million within 4-5 years, and $46.2 million after 5 years. For debt obligations based on variable rates, interest rates used are as of January 1, 2024.

[0000950170-24-021098:mdna:106]
As of January 1, 2024, $0.3 million of our derivative liabilities are expected to be settled within one year and $1.5 million of our derivative liabilities are expected to be settled within 1-3 years.

[0000950170-24-021098:mdna:107]
We also have outstanding firm purchase orders with certain suppliers for the purchase of material and inventory. Orders for standard, or catalog, items can typically be canceled with little or no financial penalty. Our policy regarding non-standard or customized items dictates that such items are only ordered specifically for customers who have contractually assumed liability for the inventory, although exceptions are made to this policy in certain situations. In addition, a substantial portion of catalog items covered by our purchase orders are procured for specific customers based on their purchase orders or a forecast under which the customer has contractually assumed liability for such material. Accordingly, our liability from purchase obligations under these purchase orders is not expected to be significant.

[0000950170-24-021098:mdna:108]
A summary of our lease obligations as of January 1, 2024 is included in Note 2 of the Notes to Consolidated Financial Statements included in this Report.

[0000950170-24-021098:mdna:109]
Offset Agreements

[0000950170-24-021098:mdna:110]
Following the acquisition of Telephonics on June 27, 2022, we have and may continue to enter into industrial cooperation agreements, sometimes referred to as offset agreements, as a condition to obtaining orders for our products and services from customers in foreign countries. These agreements are intended to promote investment in the applicable country, and our obligations under these agreements may be satisfied through activities that do not require us to use cash, including transferring technology or providing manufacturing and other consulting support. The obligations under these agreements may also be satisfied through the use of cash for such activities as purchasing supplies from in-country vendors, setting up support centers, research and development investments, acquisitions, and building or leasing facilities for in-country operations. The amount of the offset requirement is determined by contract value awarded and negotiated percentages with customers. As of January 1, 2024, we had outstanding offset agreements of approximately $28.0 million, some of which extend through 2028. Offset programs usually extend over several years and in some cases provide for penalties in the event we fail to perform in accordance with contract requirements. Historically, we have not paid any such penalties, and as of January 1, 2024, no such penalties have been paid.

[0000950170-24-021098:mdna:111]
Seasonality

[0000950170-24-021098:mdna:112]
We tend to experience modest seasonal softness in the first and third quarters due to holidays and vacation periods in China and North America, respectively, which limit production leading to stronger revenue levels in the second and fourth quarters.

[0000950170-24-021098:mdna:113]
Recently Issued Accounting Standards

[0000950170-24-021098:mdna:114]
For a description of recently adopted and issued accounting standards, including the respective dates of adoption and expected effects on our results of operations and financial condition, see Note 1 of the Notes to Consolidated Financial Statements.
