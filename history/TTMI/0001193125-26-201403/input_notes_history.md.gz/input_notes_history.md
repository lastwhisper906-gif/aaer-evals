# TTMI note change history — 0001193125-25-260708 → 0001193125-26-201403


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2026-05-01):
[0001193125-26-201403:note_history:1]
The Company is subject to various legal matters, which it considers normal for its business activities. While the Company currently believes that the amount of any reasonably possible loss for known matters would not be material to the Company’s financial condition, the outcome of these actions is inherently difficult to predict. In the event of an adverse outcome, the ultimate potential loss could have a material adverse effect on the Company’s financial condition or results of operations in a particular period. The Company has accrued amounts for its loss contingencies which are probable and estimable as of March 30, 2026 and December 29, 2025 and included as a component of other current liabilities. However, these amounts are not material to the consolidated condensed financial statements of the Company.
  (was, 2025-10-31, similarity 0.9914):
[0001193125-25-260708:note_history:1]
The Company is subject to various legal matters, which it considers normal for its business activities. While the Company currently believes that the amount of any reasonably possible loss for known matters would not be material to the Company’s financial condition, the outcome of these actions is inherently difficult to predict. In the event of an adverse outcome, the ultimate potential loss could have a material adverse effect on the Company’s financial condition or results of operations in a particular period. The Company has accrued amounts for its loss contingencies which are probable and estimable as of September 29, 2025 and December 30, 2024 and included as a component of other current liabilities. However, these amounts are not material to the consolidated condensed financial statements of the Company.

- changed (2026-05-01):
[0001193125-26-201403:note_history:2]
The Company has agreements with financial institutions to facilitate payments to certain suppliers. Liabilities associated with these agreements are recorded in accounts payable on the consolidated condensed balance sheets and amounted to $16,375 and $12,535 as of March 30, 2026 and December 29, 2025, respectively.
  (was, 2025-10-31, similarity 0.9764):
[0001193125-25-260708:note_history:2]
The Company has agreements with financial institutions to facilitate payments to certain suppliers. Liabilities associated with these agreements are recorded in accounts payable on the consolidated condensed balance sheets and amounted to $12,195 and $17,218 as of September 29, 2025 and December 30, 2024, respectively.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureAndSignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- added (2026-05-01):
[0001193125-26-201403:note_history:3]
TTM Technologies, Inc. is a leading global manufacturer of technology products, including mission systems, RF components, RF microwave/microelectronic assemblies, and technologically advanced interconnect products, including PCBs and substrates. The Company provides time-to-market and volume production of advanced technology products and offers a one-stop design, engineering, and manufacturing solution to customers. This solution allows the Company to align technology developments with the diverse needs of the Company’s customers and to enable them to reduce the time required to develop new products and bring them to market.

- changed (2026-05-01):
[0001193125-26-201403:note_history:4]
The Company serves a diversified customer base in various markets throughout the world, including aerospace and defense; automotive; data center and networking; and medical, industrial, and instrumentation. The Company’s customers include OEMs, EMS providers, ODMs, distributors, and government agencies (both domestic and allied foreign governments).
  (was, 2025-10-31, similarity 0.6305):
[0001193125-25-260708:note_history:4]
The Company serves a diversified customer base in various markets throughout the world, including aerospace and defense, data center computing, automotive, medical, industrial, and instrumentation, and networking. The Company’s customers include original equipment manufacturers (OEMs), electronic manufacturing services (EMS) providers, original design manufacturers (ODMs), distributors, and government agencies (both domestic and allied foreign governments).

- added (2026-05-01):
[0001193125-26-201403:note_history:5]
The accompanying unaudited consolidated condensed financial statements have been prepared by the Company pursuant to the rules and regulations of the SEC. Certain information and disclosures normally included in financial statements prepared in accordance with U.S. GAAP have been condensed or omitted pursuant to such rules and regulations. These consolidated condensed financial statements should be read in conjunction with the consolidated financial statements and the notes thereto included in the Company’s most recent Annual Report on Form 10-K. The preparation of financial statements in accordance with U.S. GAAP requires management to make estimates and assumptions that affect the amounts reported in the Company’s consolidated condensed financial statements and accompanying notes. Due, in part, to the conflicts between Russia and Ukraine and conflicts in the Middle East, as well as other global regions, the imposition of, or changes to, tariffs by the United States as well as retaliatory tariffs or measures by other countries, and the rising prices of global crude oil, the global economy and financial markets have continued to be volatile. As such, the Company has considered information available to it as of the date of issuance of these consolidated condensed financial statements and is not aware of any specific events or circumstances that would require an update to its estimates or judgments, or a revision to the carrying value of its assets or liabilities. The actual results the Company experienced may differ materially and adversely from its estimates.

- added (2026-05-01):
[0001193125-26-201403:note_history:6]
In December 2025, the FASB issued ASU 2025-10, Accounting for Government Grants Received by Business Entities, to provide guidance on how business entities should recognize, measure, and present government grants received. The ASU is effective for annual periods beginning after December 15, 2028, and interim periods within those annual reporting periods. Early adoption is permitted. The guidance may be applied on a modified prospective basis, a modified retrospective basis, or a retrospective basis. The Company is currently evaluating the timing of the adoption and the impact of this ASU on its consolidated financial statements and related disclosures.

- changed (2026-05-01):
[0001193125-26-201403:note_history:7]
In September 2025, the FASB issued ASU 2025-06, Targeted Improvements to the Accounting for Internal-Use Software, which amends the existing standard to remove all references to prescriptive and sequential software development project stages. Under this guidance, eligible software development costs will begin capitalization when management has authorized and committed to funding the software project, and it is probable that the project will be completed and the software will be used to perform the function intended. The ASU is effective for annual periods beginning after December 15, 2027, and interim periods within those annual reporting periods. Early adoption is permitted as of the beginning of an annual reporting period. The guidance may be applied on a prospective basis, a modified basis for in-process projects, or a retrospective basis. The Company is currently evaluating the timing of the adoption and the impact of this ASU on its consolidated financial statements and related disclosures.
  (was, 2025-10-31, similarity 0.9405):
[0001193125-25-260708:note_history:7]
In September 2025, the Financial Accounting Standards Board (FASB) issued Accounting Standards Update (ASU) 2025-06, Targeted Improvements to the Accounting for Internal-Use Software, which amends the existing standard to remove all references to prescriptive and sequential software development project stages. Under this guidance, eligible software development costs will begin capitalization when management has authorized and committed to funding the software project, and it is probable that the project will be completed and the software will be used to perform the function intended. The ASU is effective for annual periods beginning after December 15, 2027, and interim periods within those annual reporting periods. Early adoption is permitted as of the beginning of an annual reporting period. The guidance may be applied on a prospective basis, a modified basis, or a retrospective basis. The Company is currently evaluating the timing of the adoption and the impact of this ASU on its consolidated financial statements and related disclosures.

- removed (2026-05-01):
[0001193125-25-260708:note_history:8]
TTM Technologies, Inc. (the Company or TTM) is a leading global manufacturer of technology products, including mission systems, radio frequency (RF) components, RF microwave/microelectronic assemblies, and technologically advanced printed circuit boards (PCBs). The Company provides time-to-market and volume production of advanced technology products and offers a one-stop design, engineering, and manufacturing solution to customers. This solution allows the Company to align technology developments with the diverse needs of the Company’s customers and to enable them to reduce the time required to develop new products and bring them to market.

- removed (2026-05-01):
[0001193125-25-260708:note_history:9]
The accompanying unaudited consolidated condensed financial statements have been prepared by the Company pursuant to the rules and regulations of the Securities and Exchange Commission (SEC). Certain information and disclosures normally included in financial statements prepared in accordance with accounting principles generally accepted in the United States of America (U.S. GAAP) have been condensed or omitted pursuant to such rules and regulations. These consolidated condensed financial statements should be read in conjunction with the consolidated financial statements and the notes thereto included in the Company’s most recent Annual Report on Form 10-K. The preparation of financial statements in accordance with U.S. GAAP requires management to make estimates and assumptions that affect the amounts reported in the Company’s consolidated condensed financial statements and accompanying notes. Due, in part, to the conflicts between Russia and Ukraine, as well as other global regions and the imposition of, or changes to, tariffs by the United States as well as retaliatory tariffs or measures by other countries, the global economy and financial markets have been volatile in recent periods. As such, the Company has considered information available to it as of the date of issuance of these consolidated condensed financial statements and is not aware of any specific events or circumstances that would require an update to its estimates or judgments, or a revision to the carrying value of its assets or liabilities. The actual results the Company experienced may differ materially and adversely from its estimates. The Company uses a 52/53 week fiscal calendar with the fourth quarter ending on the Monday nearest December 31.

- removed (2026-05-01):
[0001193125-25-260708:note_history:10]
In July 2025, the FASB issued ASU 2025-05, Measurement of Credit Losses for Accounts Receivable and Contract Assets, which provides a practical expedient to measure credit losses on accounts receivable and contract assets. The ASU is effective for annual periods beginning after December 15, 2025, and interim periods within those annual reporting periods. Early adoption is permitted. The Company is currently evaluating the timing of the adoption and the impact of this ASU on its consolidated financial statements and related disclosures.

- removed (2026-05-01):
[0001193125-25-260708:note_history:11]
In December 2023, the FASB issued ASU 2023-09, Income Taxes (Topic 740): Improvements to Income Tax Disclosures, which requires disclosure of disaggregated income taxes paid, prescribes standard categories for the components of the effective tax rate reconciliation, and modifies other income tax-related disclosures. The update will be effective for annual periods beginning after December 15, 2024. Early adoption is permitted for annual financial statements not yet issued or made available for issuance. The Company will adopt ASU 2023-09 in its 2025 fiscal year Form 10-K. This ASU will impact only the Company's disclosures with no impacts to the results of operations, cash flows, and financial condition.


## ttmi:ScheduleOfUnamortizedDiscountAndDebtIssuanceCostsTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2026-05-01):
[0001193125-26-201403:note_history:12]
|  |  | As of |
|  |  | March 30, 2026 |  | December 29, 2025 |
|  |  | DebtIssuance Costs |  |  | DebtDiscount |  |  | EffectiveInterest Rate |  | DebtIssuance Costs |  |  | DebtDiscount |  |  | EffectiveInterest Rate |
|  |  | (In thousands, except interest rates) |
| Senior Notes due March 2029 |  | $ | 2,414 |  |  | $ | — |  |  |  | 4.18 |  | % |  | $ | 2,608 |  |  | $ | — |  |  |  | 4.18 |  | % |
| Term Loan due May 2030 |  |  | 2,860 |  |  |  | 2,261 |  |  |  | 8.01 |  |  |  |  | 3,009 |  |  |  | 2,382 |  |  |  | 8.01 |  |  |
| Total |  | $ | 5,274 |  |  | $ | 2,261 |  |  |  |  |  |  | $ | 5,617 |  |  | $ | 2,382 |  |  |  |  |  |
  (was, 2025-10-31, similarity 0.9627):
[0001193125-25-260708:note_history:12]
|  |  | As of |
|  |  | September 29, 2025 |  | December 30, 2024 |
|  |  | DebtIssuance Costs |  |  | DebtDiscount |  |  | EffectiveInterest Rate |  | DebtIssuance Costs |  |  | DebtDiscount |  |  | EffectiveInterest Rate |
|  |  | (In thousands, except interest rates) |
| Senior Notes due March 2029 |  | $ | 2,799 |  |  | $ | — |  |  |  | 4.18 |  | % |  | $ | 3,362 |  |  | $ | — |  |  |  | 4.18 |  | % |
| Term Loan due May 2030 |  |  | 3,158 |  |  |  | 2,498 |  |  |  | 8.01 |  |  |  |  | 3,589 |  |  |  | 2,840 |  |  |  | 8.01 |  |  |
| Total |  | $ | 5,957 |  |  | $ | 2,498 |  |  |  |  |  |  | $ | 6,951 |  |  | $ | 2,840 |  |  |  |  |  |


## us-gaap:LongTermDebtTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2026-05-01):
[0001193125-26-201403:note_history:13]
|  |  | As of |  |
|  |  | March 30, 2026 |  |  | December 29, 2025 |  |
|  |  | Interest Rate |  | PrincipalOutstanding |  |  | Interest Rate |  | PrincipalOutstanding |  |
|  |  | (In thousands, except interest rates) |  |
| Senior Notes due March 2029 |  |  | 4.00 |  | % |  | $ | 500,000 |  |  |  | 4.00 |  | % |  | $ | 500,000 |  |
| Term Loan due May 2030 |  |  | 5.91 |  |  |  |  | 341,303 |  |  |  | 5.97 |  |  |  |  | 342,169 |  |
| Asia ABL Revolving Loan due June 2028 |  |  | 4.96 |  |  |  |  | 80,000 |  |  |  | 5.02 |  |  |  |  | 80,000 |  |
| Other |  |  | 5.99 |  |  |  |  | 1,925 |  |  |  | 5.99 |  |  |  |  | 1,981 |  |
| Total debt |  |  |  |  |  |  | 923,228 |  |  |  |  |  |  |  | 924,150 |  |
| Less: Unamortized debt issuance costs |  |  |  |  |  |  | (5,274 | ) |  |  |  |  |  |  | (5,617 | ) |
| Less: Unamortized debt discount |  |  |  |  |  |  | (2,261 | ) |  |  |  |  |  |  | (2,382 | ) |
| Subtotal |  |  |  |  |  |  | 915,693 |  |  |  |  |  |  |  | 916,151 |  |
| Less: Current maturities |  |  |  |  |  |  | (3,851 | ) |  |  |  |  |  |  | (3,815 | ) |
| Long-term debt, less current maturities |  |  |  |  |  | $ | 911,842 |  |  |  |  |  |  | $ | 912,336 |  |
  (was, 2025-10-31, similarity 0.7825):
[0001193125-25-260708:note_history:13]
|  |  | As of |  |
|  |  | September 29, 2025 |  |  | December 30, 2024 |  |
|  |  | Interest Rate |  | PrincipalOutstanding |  |  | Interest Rate |  | PrincipalOutstanding |  |
|  |  | (In thousands, except interest rates) |  |
| Senior Notes due March 2029 |  |  | 4.00 |  | % |  | $ | 500,000 |  |  |  | 4.00 |  | % |  | $ | 500,000 |  |
| Term Loan due May 2030 |  |  | 6.38 |  |  |  |  | 343,035 |  |  |  | 6.59 |  |  |  |  | 345,634 |  |
| Asia ABL Revolving Loan due June 2028 |  |  | 5.43 |  |  |  |  | 80,000 |  |  |  | 5.64 |  |  |  |  | 80,000 |  |
| Other |  |  | 5.99 |  |  |  |  | 2,065 |  |  |  | 5.99 |  |  |  |  | 2,311 |  |
| Total debt |  |  |  |  |  |  | 925,100 |  |  |  |  |  |  |  | 927,945 |  |
| Less: Unamortized debt issuance costs |  |  |  |  |  |  | (5,957 | ) |  |  |  |  |  |  | (6,951 | ) |
| Less: Unamortized debt discount |  |  |  |  |  |  | (2,498 | ) |  |  |  |  |  |  | (2,840 | ) |
| Subtotal |  |  |  |  |  |  | 916,645 |  |  |  |  |  |  |  | 918,154 |  |
| Less: Current maturities |  |  |  |  |  |  | (3,810 | ) |  |  |  |  |  |  | (3,795 | ) |
| Long-term debt, less current maturities |  |  |  |  |  | $ | 912,835 |  |  |  |  |  |  | $ | 914,359 |  |

- changed (2026-05-01):
[0001193125-26-201403:note_history:14]
Borrowings under the Senior Notes due 2029 and Term Loan Facility are subject to certain affirmative and negative covenants, including limitations on indebtedness, corporate transactions, investments, dispositions, and restricted payments.
  (was, 2025-10-31, similarity 0.9459):
[0001193125-25-260708:note_history:14]
Borrowings under the Senior Notes due 2029 and Term Loan Facility due 2030 (Term Loan Facility) are subject to certain affirmative and negative covenants, including limitations on indebtedness, corporate transactions, investments, dispositions, and restricted payments.

- changed (2026-05-01):
[0001193125-26-201403:note_history:15]
Under the occurrence of certain events, the ABL Revolving Loans are subject to various financial covenants, including leverage and fixed-charge coverage ratios.
  (was, 2025-10-31, similarity 0.6267):
[0001193125-25-260708:note_history:15]
Under the occurrence of certain events, the U.S. Asset-Based Lending Credit Agreement (U.S. ABL) and Asia Asset-Based Lending Credit Agreement (Asia ABL) (collectively, the ABL Revolving Loans) are subject to various financial covenants, including leverage and fixed-charge coverage ratios.

- changed (2026-05-01):
[0001193125-26-201403:note_history:16]
|  |  | As of |
|  |  | March 30, 2026 |  | December 29, 2025 |
|  |  | DebtIssuance Costs |  |  | DebtDiscount |  |  | EffectiveInterest Rate |  | DebtIssuance Costs |  |  | DebtDiscount |  |  | EffectiveInterest Rate |
|  |  | (In thousands, except interest rates) |
| Senior Notes due March 2029 |  | $ | 2,414 |  |  | $ | — |  |  |  | 4.18 |  | % |  | $ | 2,608 |  |  | $ | — |  |  |  | 4.18 |  | % |
| Term Loan due May 2030 |  |  | 2,860 |  |  |  | 2,261 |  |  |  | 8.01 |  |  |  |  | 3,009 |  |  |  | 2,382 |  |  |  | 8.01 |  |  |
| Total |  | $ | 5,274 |  |  | $ | 2,261 |  |  |  |  |  |  | $ | 5,617 |  |  | $ | 2,382 |  |  |  |  |  |
  (was, 2025-10-31, similarity 0.9627):
[0001193125-25-260708:note_history:16]
|  |  | As of |
|  |  | September 29, 2025 |  | December 30, 2024 |
|  |  | DebtIssuance Costs |  |  | DebtDiscount |  |  | EffectiveInterest Rate |  | DebtIssuance Costs |  |  | DebtDiscount |  |  | EffectiveInterest Rate |
|  |  | (In thousands, except interest rates) |
| Senior Notes due March 2029 |  | $ | 2,799 |  |  | $ | — |  |  |  | 4.18 |  | % |  | $ | 3,362 |  |  | $ | — |  |  |  | 4.18 |  | % |
| Term Loan due May 2030 |  |  | 3,158 |  |  |  | 2,498 |  |  |  | 8.01 |  |  |  |  | 3,589 |  |  |  | 2,840 |  |  |  | 8.01 |  |  |
| Total |  | $ | 5,957 |  |  | $ | 2,498 |  |  |  |  |  |  | $ | 6,951 |  |  | $ | 2,840 |  |  |  |  |  |

- changed (2026-05-01):
[0001193125-26-201403:note_history:17]
Remaining unamortized debt issuance costs for the ABL Revolving Loans of $784 and $874 as of March 30, 2026 and December 29, 2025, respectively, are included in deposits and other non-current assets and are amortized to interest expense over the duration of the ABL Revolving Loans using the straight-line method of amortization.
  (was, 2025-10-31, similarity 0.9778):
[0001193125-25-260708:note_history:17]
Remaining unamortized debt issuance costs for the ABL Revolving Loans of $966 and $1,239 as of September 29, 2025 and December 30, 2024, respectively, are included in deposits and other non-current assets and are amortized to interest expense over the duration of the ABL Revolving Loans using the straight-line method of amortization.

- changed (2026-05-01):
[0001193125-26-201403:note_history:18]
As of March 30, 2026, the remaining weighted average amortization period for all unamortized debt issuance costs and debt discount was 3.6 years.
  (was, 2025-10-31, similarity 0.964):
[0001193125-25-260708:note_history:18]
As of September 29, 2025, the remaining weighted average amortization period for all unamortized debt issuance costs and debt discount was 4.1 years.


## us-gaap:ScheduleOfDebtInstrumentsTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2026-05-01):
[0001193125-26-201403:note_history:19]
|  |  | As of |  |
|  |  | March 30, 2026 |  |  | December 29, 2025 |  |
|  |  | Interest Rate |  | PrincipalOutstanding |  |  | Interest Rate |  | PrincipalOutstanding |  |
|  |  | (In thousands, except interest rates) |  |
| Senior Notes due March 2029 |  |  | 4.00 |  | % |  | $ | 500,000 |  |  |  | 4.00 |  | % |  | $ | 500,000 |  |
| Term Loan due May 2030 |  |  | 5.91 |  |  |  |  | 341,303 |  |  |  | 5.97 |  |  |  |  | 342,169 |  |
| Asia ABL Revolving Loan due June 2028 |  |  | 4.96 |  |  |  |  | 80,000 |  |  |  | 5.02 |  |  |  |  | 80,000 |  |
| Other |  |  | 5.99 |  |  |  |  | 1,925 |  |  |  | 5.99 |  |  |  |  | 1,981 |  |
| Total debt |  |  |  |  |  |  | 923,228 |  |  |  |  |  |  |  | 924,150 |  |
| Less: Unamortized debt issuance costs |  |  |  |  |  |  | (5,274 | ) |  |  |  |  |  |  | (5,617 | ) |
| Less: Unamortized debt discount |  |  |  |  |  |  | (2,261 | ) |  |  |  |  |  |  | (2,382 | ) |
| Subtotal |  |  |  |  |  |  | 915,693 |  |  |  |  |  |  |  | 916,151 |  |
| Less: Current maturities |  |  |  |  |  |  | (3,851 | ) |  |  |  |  |  |  | (3,815 | ) |
| Long-term debt, less current maturities |  |  |  |  |  | $ | 911,842 |  |  |  |  |  |  | $ | 912,336 |  |
  (was, 2025-10-31, similarity 0.7825):
[0001193125-25-260708:note_history:19]
|  |  | As of |  |
|  |  | September 29, 2025 |  |  | December 30, 2024 |  |
|  |  | Interest Rate |  | PrincipalOutstanding |  |  | Interest Rate |  | PrincipalOutstanding |  |
|  |  | (In thousands, except interest rates) |  |
| Senior Notes due March 2029 |  |  | 4.00 |  | % |  | $ | 500,000 |  |  |  | 4.00 |  | % |  | $ | 500,000 |  |
| Term Loan due May 2030 |  |  | 6.38 |  |  |  |  | 343,035 |  |  |  | 6.59 |  |  |  |  | 345,634 |  |
| Asia ABL Revolving Loan due June 2028 |  |  | 5.43 |  |  |  |  | 80,000 |  |  |  | 5.64 |  |  |  |  | 80,000 |  |
| Other |  |  | 5.99 |  |  |  |  | 2,065 |  |  |  | 5.99 |  |  |  |  | 2,311 |  |
| Total debt |  |  |  |  |  |  | 925,100 |  |  |  |  |  |  |  | 927,945 |  |
| Less: Unamortized debt issuance costs |  |  |  |  |  |  | (5,957 | ) |  |  |  |  |  |  | (6,951 | ) |
| Less: Unamortized debt discount |  |  |  |  |  |  | (2,498 | ) |  |  |  |  |  |  | (2,840 | ) |
| Subtotal |  |  |  |  |  |  | 916,645 |  |  |  |  |  |  |  | 918,154 |  |
| Less: Current maturities |  |  |  |  |  |  | (3,810 | ) |  |  |  |  |  |  | (3,795 | ) |
| Long-term debt, less current maturities |  |  |  |  |  | $ | 912,835 |  |  |  |  |  |  | $ | 914,359 |  |


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- added (2026-05-01):
[0001193125-26-201403:note_history:20]
|  |  | For the Quarter Ended |  |
|  |  | March 30, 2026 |  |  | March 31, 2025 |  |
|  |  | A&D |  |  | Commercial |  |  | Total |  |  | A&D |  |  | Commercial |  |  | Total |  |
|  |  | (In thousands) |  |
| End Markets (1): |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Aerospace and Defense |  | $ | 341,557 |  |  | $ | — |  |  | $ | 341,557 |  |  | $ | 307,418 |  |  | $ | — |  |  | $ | 307,418 |  |
| Automotive |  |  | — |  |  |  | 69,770 |  |  |  | 69,770 |  |  |  | — |  |  |  | 71,354 |  |  |  | 71,354 |  |
| Data Center and Networking |  |  | 8,663 |  |  |  | 293,084 |  |  |  | 301,747 |  |  |  | 7,911 |  |  |  | 179,539 |  |  |  | 187,450 |  |
| Medical, Industrial, and Instrumentation |  |  | 966 |  |  |  | 131,936 |  |  |  | 132,902 |  |  |  | 909 |  |  |  | 81,537 |  |  |  | 82,446 |  |
| Total |  | $ | 351,186 |  |  | $ | 494,790 |  |  | $ | 845,976 |  |  | $ | 316,238 |  |  | $ | 332,430 |  |  | $ | 648,668 |  |

- added (2026-05-01):
[0001193125-26-201403:note_history:21]
(1)
The end market revenue for the quarter ended March 31, 2025 has been recast to reflect certain adjustments to allocations resulting from the segment reorganizations that occurred during the quarters ended March 30, 2026 and June 30, 2025 as well as the combination of the data center computing and networking end markets. The end market revenue excludes intersegment sales totaling $731 and $287 for the quarters ended March 30, 2026 and March 31, 2025, respectively. See Note 4, Segment Information, for further information.

- removed (2026-05-01):
[0001193125-25-260708:note_history:22]
|  |  | For the Quarter Ended |  |
|  |  | September 29, 2025 |  |  | September 30, 2024 |  |
|  |  | Aerospace and Defense (A&D) |  |  | Commercial |  |  | RF and Specialty Components (RF&S Components) |  |  | Total |  |  | A&D |  |  | Commercial |  |  | RF&S Components |  |  | Total |  |
|  |  | (In thousands) |  |
| End Markets (1): |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Aerospace and Defense |  | $ | 333,556 |  |  | $ | — |  |  | $ | — |  |  | $ | 333,556 |  |  | $ | 277,604 |  |  | $ | — |  |  | $ | — |  |  | $ | 277,604 |  |
| Automotive |  |  | — |  |  |  | 79,355 |  |  |  | — |  |  |  | 79,355 |  |  |  | — |  |  |  | 86,773 |  |  |  | — |  |  |  | 86,773 |  |
| Data Center Computing |  |  | — |  |  |  | 175,302 |  |  |  | 33 |  |  |  | 175,335 |  |  |  | — |  |  |  | 121,767 |  |  |  | 201 |  |  |  | 121,968 |  |
| Medical/Industrial/Instrumentation |  |  | — |  |  |  | 107,289 |  |  |  | 1,128 |  |  |  | 108,417 |  |  |  | — |  |  |  | 87,968 |  |  |  | 579 |  |  |  | 88,547 |  |
| Networking |  |  | — |  |  |  | 46,790 |  |  |  | 9,283 |  |  |  | 56,073 |  |  |  | — |  |  |  | 32,681 |  |  |  | 8,965 |  |  |  | 41,646 |  |
| Total |  | $ | 333,556 |  |  | $ | 408,736 |  |  | $ | 10,444 |  |  | $ | 752,736 |  |  | $ | 277,604 |  |  | $ | 329,189 |  |  | $ | 9,745 |  |  | $ | 616,538 |  |

- removed (2026-05-01):
[0001193125-25-260708:note_history:23]
|  |  | For the Three Quarters Ended |  |
|  |  | September 29, 2025 |  |  | September 30, 2024 |  |
|  |  | A&D |  |  | Commercial |  |  | RF&S Components |  |  | Total |  |  | A&D |  |  | Commercial |  |  | RF&S Components |  |  | Total |  |
|  |  | (In thousands) |  |
| End Markets (1): |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Aerospace and Defense |  | $ | 966,066 |  |  | $ | — |  |  | $ | — |  |  | $ | 966,066 |  |  | $ | 828,908 |  |  | $ | — |  |  | $ | — |  |  | $ | 828,908 |  |
| Automotive |  |  | — |  |  |  | 232,133 |  |  |  | — |  |  |  | 232,133 |  |  |  | — |  |  |  | 239,681 |  |  |  | — |  |  |  | 239,681 |  |
| Data Center Computing |  |  | — |  |  |  | 460,291 |  |  |  | 979 |  |  |  | 461,270 |  |  |  | — |  |  |  | 359,680 |  |  |  | 323 |  |  |  | 360,003 |  |
| Medical/Industrial/Instrumentation |  |  | — |  |  |  | 299,397 |  |  |  | 3,046 |  |  |  | 302,443 |  |  |  | — |  |  |  | 249,532 |  |  |  | 2,035 |  |  |  | 251,567 |  |
| Networking |  |  | — |  |  |  | 144,826 |  |  |  | 25,287 |  |  |  | 170,113 |  |  |  | — |  |  |  | 86,940 |  |  |  | 24,689 |  |  |  | 111,629 |  |
| Total |  | $ | 966,066 |  |  | $ | 1,136,647 |  |  | $ | 29,312 |  |  | $ | 2,132,025 |  |  | $ | 828,908 |  |  | $ | 935,833 |  |  | $ | 27,047 |  |  | $ | 1,791,788 |  |

- removed (2026-05-01):
[0001193125-25-260708:note_history:24]
(1)
The end market revenue for the A&D and Commercial reportable segments prior to the quarter ended June 30, 2025 has been recast to reflect certain adjustments to allocations resulting from the segment reorganization. The end market revenue excludes intersegment sales totaling $3,469 and $9,119 for the quarter and three quarters ended September 29, 2025, respectively, and $2,157 and $5,646 for the quarter and three quarters ended September 30, 2024, respectively. See Note 4, Segment Information, for further information.


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2026-05-01):
[0001193125-26-201403:note_history:25]
For contracts in which anticipated total costs exceed the total expected revenue, an estimated loss is recognized in the period when identifiable. A provision for the entire amount of the estimated loss is recorded on a cumulative basis. The estimated remaining costs to complete for loss contracts as of March 30, 2026 and December 29, 2025 were $28,523 and $33,163, respectively.
  (was, 2025-10-31, similarity 0.9807):
[0001193125-25-260708:note_history:25]
For contracts in which anticipated total costs exceed the total expected revenue, an estimated loss is recognized in the period when identifiable. A provision for the entire amount of the estimated loss is recorded on a cumulative basis. The estimated remaining costs to complete for loss contracts as of September 29, 2025 and December 30, 2024 were $32,275 and $36,976, respectively.

- changed (2026-05-01):
[0001193125-26-201403:note_history:26]
As of March 30, 2026, the aggregate amount of the transaction price allocated to remaining performance obligations for long‑term contracts was $393,556. The Company expects to recognize revenue on approximately 62% of the remaining performance obligations for the Company’s long-term contracts over the next 12 months with the remaining amount expected to be recognized thereafter. The remaining performance obligations for the Company’s short‑term contracts are expected to be recognized within one year, and the Company is applying the optional permitted exemption to forgo disclosing the amount of transaction price allocated to the remaining performance obligations for contracts with an expected duration of one year or less.
  (was, 2025-10-31, similarity 0.6654):
[0001193125-25-260708:note_history:26]
As of September 29, 2025, the aggregate amount of the transaction price allocated to remaining performance obligations for long‑term contracts was $418,620. The Company expects to recognize revenue on approximately 57% of the remaining performance obligations for the Company’s long-term contracts over the next 12 months with the remaining amount expected to be recognized thereafter.

- changed (2026-05-01):
[0001193125-26-201403:note_history:27]
Revenue recognized for the quarter ended March 30, 2026 from amounts recorded as contract liabilities as of December 29, 2025 was $42,002. Revenue recognized for the quarter ended March 31, 2025 from amounts recorded as contract liabilities as of December 30, 2024 was $22,496.
  (was, 2025-10-31, similarity 0.6106):
[0001193125-25-260708:note_history:27]
Revenue recognized for the three quarters ended September 29, 2025 from amounts recorded as contract liabilities as of December 30, 2024 was $82,722. Revenue recognized for the three quarters ended September 30, 2024 from amounts recorded as contract liabilities as of January 1, 2024 was $33,331.

- changed (2026-05-01):
[0001193125-26-201403:note_history:28]
Revenue from products and services transferred to customers over time and at a point in time accounted for 96% and 4%, respectively, of the Company's revenue for both the quarters ended March 30, 2026 and March 31, 2025.
  (was, 2025-10-31, similarity 0.7964):
[0001193125-25-260708:note_history:28]
Revenue from products and services transferred to customers over time and at a point in time accounted for 96% and 4%, respectively, of the Company’s revenue for both the quarter and three quarters ended September 29, 2025 and September 30, 2024.

- added (2026-05-01):
[0001193125-26-201403:note_history:29]
|  |  | For the Quarter Ended |  |
|  |  | March 30, 2026 |  |  | March 31, 2025 |  |
|  |  | A&D |  |  | Commercial |  |  | Total |  |  | A&D |  |  | Commercial |  |  | Total |  |
|  |  | (In thousands) |  |
| End Markets (1): |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Aerospace and Defense |  | $ | 341,557 |  |  | $ | — |  |  | $ | 341,557 |  |  | $ | 307,418 |  |  | $ | — |  |  | $ | 307,418 |  |
| Automotive |  |  | — |  |  |  | 69,770 |  |  |  | 69,770 |  |  |  | — |  |  |  | 71,354 |  |  |  | 71,354 |  |
| Data Center and Networking |  |  | 8,663 |  |  |  | 293,084 |  |  |  | 301,747 |  |  |  | 7,911 |  |  |  | 179,539 |  |  |  | 187,450 |  |
| Medical, Industrial, and Instrumentation |  |  | 966 |  |  |  | 131,936 |  |  |  | 132,902 |  |  |  | 909 |  |  |  | 81,537 |  |  |  | 82,446 |  |
| Total |  | $ | 351,186 |  |  | $ | 494,790 |  |  | $ | 845,976 |  |  | $ | 316,238 |  |  | $ | 332,430 |  |  | $ | 648,668 |  |

- added (2026-05-01):
[0001193125-26-201403:note_history:30]
(1)
The end market revenue for the quarter ended March 31, 2025 has been recast to reflect certain adjustments to allocations resulting from the segment reorganizations that occurred during the quarters ended March 30, 2026 and June 30, 2025 as well as the combination of the data center computing and networking end markets. The end market revenue excludes intersegment sales totaling $731 and $287 for the quarters ended March 30, 2026 and March 31, 2025, respectively. See Note 4, Segment Information, for further information.

- removed (2026-05-01):
[0001193125-25-260708:note_history:31]
|  |  | For the Quarter Ended |  |
|  |  | September 29, 2025 |  |  | September 30, 2024 |  |
|  |  | Aerospace and Defense (A&D) |  |  | Commercial |  |  | RF and Specialty Components (RF&S Components) |  |  | Total |  |  | A&D |  |  | Commercial |  |  | RF&S Components |  |  | Total |  |
|  |  | (In thousands) |  |
| End Markets (1): |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Aerospace and Defense |  | $ | 333,556 |  |  | $ | — |  |  | $ | — |  |  | $ | 333,556 |  |  | $ | 277,604 |  |  | $ | — |  |  | $ | — |  |  | $ | 277,604 |  |
| Automotive |  |  | — |  |  |  | 79,355 |  |  |  | — |  |  |  | 79,355 |  |  |  | — |  |  |  | 86,773 |  |  |  | — |  |  |  | 86,773 |  |
| Data Center Computing |  |  | — |  |  |  | 175,302 |  |  |  | 33 |  |  |  | 175,335 |  |  |  | — |  |  |  | 121,767 |  |  |  | 201 |  |  |  | 121,968 |  |
| Medical/Industrial/Instrumentation |  |  | — |  |  |  | 107,289 |  |  |  | 1,128 |  |  |  | 108,417 |  |  |  | — |  |  |  | 87,968 |  |  |  | 579 |  |  |  | 88,547 |  |
| Networking |  |  | — |  |  |  | 46,790 |  |  |  | 9,283 |  |  |  | 56,073 |  |  |  | — |  |  |  | 32,681 |  |  |  | 8,965 |  |  |  | 41,646 |  |
| Total |  | $ | 333,556 |  |  | $ | 408,736 |  |  | $ | 10,444 |  |  | $ | 752,736 |  |  | $ | 277,604 |  |  | $ | 329,189 |  |  | $ | 9,745 |  |  | $ | 616,538 |  |

- removed (2026-05-01):
[0001193125-25-260708:note_history:32]
|  |  | For the Three Quarters Ended |  |
|  |  | September 29, 2025 |  |  | September 30, 2024 |  |
|  |  | A&D |  |  | Commercial |  |  | RF&S Components |  |  | Total |  |  | A&D |  |  | Commercial |  |  | RF&S Components |  |  | Total |  |
|  |  | (In thousands) |  |
| End Markets (1): |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Aerospace and Defense |  | $ | 966,066 |  |  | $ | — |  |  | $ | — |  |  | $ | 966,066 |  |  | $ | 828,908 |  |  | $ | — |  |  | $ | — |  |  | $ | 828,908 |  |
| Automotive |  |  | — |  |  |  | 232,133 |  |  |  | — |  |  |  | 232,133 |  |  |  | — |  |  |  | 239,681 |  |  |  | — |  |  |  | 239,681 |  |
| Data Center Computing |  |  | — |  |  |  | 460,291 |  |  |  | 979 |  |  |  | 461,270 |  |  |  | — |  |  |  | 359,680 |  |  |  | 323 |  |  |  | 360,003 |  |
| Medical/Industrial/Instrumentation |  |  | — |  |  |  | 299,397 |  |  |  | 3,046 |  |  |  | 302,443 |  |  |  | — |  |  |  | 249,532 |  |  |  | 2,035 |  |  |  | 251,567 |  |
| Networking |  |  | — |  |  |  | 144,826 |  |  |  | 25,287 |  |  |  | 170,113 |  |  |  | — |  |  |  | 86,940 |  |  |  | 24,689 |  |  |  | 111,629 |  |
| Total |  | $ | 966,066 |  |  | $ | 1,136,647 |  |  | $ | 29,312 |  |  | $ | 2,132,025 |  |  | $ | 828,908 |  |  | $ | 935,833 |  |  | $ | 27,047 |  |  | $ | 1,791,788 |  |

- removed (2026-05-01):
[0001193125-25-260708:note_history:33]
(1)
The end market revenue for the A&D and Commercial reportable segments prior to the quarter ended June 30, 2025 has been recast to reflect certain adjustments to allocations resulting from the segment reorganization. The end market revenue excludes intersegment sales totaling $3,469 and $9,119 for the quarter and three quarters ended September 29, 2025, respectively, and $2,157 and $5,646 for the quarter and three quarters ended September 30, 2024, respectively. See Note 4, Segment Information, for further information.
