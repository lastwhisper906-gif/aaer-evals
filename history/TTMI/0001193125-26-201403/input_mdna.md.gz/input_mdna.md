# TTMI MD&A — 0001193125-26-201403


## mdna

[0001193125-26-201403:mdna:1]
[same as prior period, unchanged from 0001193125-25-260708:mdna:1]

[0001193125-26-201403:mdna:2]
[same as prior period, unchanged from 0001193125-25-260708:mdna:2]

[0001193125-26-201403:mdna:3]
This Report contains forward-looking statements regarding future events or our future financial and operational performance. Forward-looking statements include statements regarding markets for our products; trends in net sales, gross profits, and estimated expense levels; liquidity and anticipated cash needs and availability; and any statement that contains the words “anticipate,” “believe,” “plan,” “forecast,” “foresee,” “estimate,” “project,” “expect,” “seek,” “target,” “intend,” “goal,” and other similar expressions. The forward-looking statements included in this Report reflect our current expectations and beliefs, and we do not undertake publicly to update or revise these statements, even if experience or future changes make it clear that any projected results expressed in this Report or future quarterly reports to stockholders, press releases, or company statements will not be realized. In addition, the inclusion of any statement in this Report does not constitute an admission by us that the events or circumstances described in such statement are material. Furthermore, we wish to caution and advise readers that these statements are based on assumptions that may not materialize and may involve risks and uncertainties, many of which are beyond our control, that could cause actual events or performance to differ materially from those contained or implied in these forward-looking statements. These risks and uncertainties include the risks identified under the heading "Risk Factors" in our Annual Report on Form 10-K for the fiscal year ended December 29, 2025, as updated by our other filings with the SEC, and described elsewhere in this Report. The following discussion and analysis of our financial condition and results of operations should be read in conjunction with our consolidated condensed financial statements and the related notes and the other financial information included in this Report, as well as the “Management’s Discussion and Analysis of Financial Condition and Results of Operations” set forth in our Annual Report on Form 10-K for the fiscal year ended December 29, 2025, filed with the SEC.

[0001193125-26-201403:mdna:4]
[same as prior period, unchanged from 0001193125-25-260708:mdna:4]

[0001193125-26-201403:mdna:5]
We are a leading global manufacturer of technology products, including mission systems, RF components, RF microwave/microelectronic assemblies, and technologically advanced interconnect products, including PCBs and substrates. We focus on providing time-to-market and volume production of advanced technology products and offer a one-stop design, engineering, and manufacturing solution to our customers. This solution allows us to align technology development with the diverse needs of our customers and to enable them to reduce the time required to develop new products and bring them to market. We serve a diversified customer base consisting of approximately 1,300 customers in various markets throughout the world, including aerospace and defense; automotive; data center and networking; and medical, industrial, and instrumentation. Our customers include OEMs, EMS providers, ODMs, distributors, and government agencies (both domestic and allied foreign governments).

[0001193125-26-201403:mdna:6]
[same as prior period, unchanged from 0001193125-25-260708:mdna:6]

[0001193125-26-201403:mdna:7]
We previously announced we are in the process of constructing a new advanced technology PCB manufacturing facility in Syracuse, New York. We expect that our new facility will bring advanced technology capability for our domestic high-volume production of ultra‑high‑density interconnect (HDI) PCBs in support of national security requirements. The building construction is complete, equipment is arriving, and we continue to install and test equipment setups. Volume production in this facility is expected to commence in the second half of 2026.

[0001193125-26-201403:mdna:8]
[same as prior period, unchanged from 0001193125-25-260708:mdna:10]

[0001193125-26-201403:mdna:9]
Our customers include both OEMs and EMS providers. We sell to OEMs both directly and indirectly through EMS providers. For such indirect sales, we measure customers based on OEM companies as they are the ultimate end customers. Sales to our ten largest customers collectively accounted for 56% of our net sales for both the quarters ended March 30, 2026 and March 31, 2025.

[0001193125-26-201403:mdna:10]
[same as prior period, unchanged from 0001193125-25-260708:mdna:12]

[0001193125-26-201403:mdna:11]
|  |  | For the Quarter Ended |
|  |  | March 30, 2026 |  | March 31, 2025 (1) |
| End Markets (2): |  |  |  |  |  |  |  |  |
| Aerospace and Defense |  |  | 40 |  | % |  |  | 48 |  | % |
| Automotive |  |  | 8 |  |  |  |  | 11 |  |  |
| Data Center and Networking |  |  | 36 |  |  |  |  | 28 |  |  |
| Medical, Industrial, and Instrumentation |  |  | 16 |  |  |  |  | 13 |  |  |
| Total |  |  | 100 |  | % |  |  | 100 |  | % |

[0001193125-26-201403:mdna:12]
(1)
The end market revenue for the quarter ended March 31, 2025 has been recast to reflect certain adjustments to allocations resulting from the segment reorganization that occurred during the quarter ended June 30, 2025 as well as the combination of the data center computing and networking end markets.

[0001193125-26-201403:mdna:13]
[same as prior period, unchanged from 0001193125-25-260708:mdna:15]

[0001193125-26-201403:mdna:14]
[same as prior period, unchanged from 0001193125-25-260708:mdna:16]

[0001193125-26-201403:mdna:15]
[same as prior period, unchanged from 0001193125-25-260708:mdna:17]

[0001193125-26-201403:mdna:16]
See Item 7, Management’s Discussion and Analysis of Financial Condition and Results of Operations, in our Annual Report on Form 10-K for the fiscal year ended December 29, 2025 for further discussion of critical accounting policies and estimates. There have been no material changes to our critical accounting policies and estimates since December 29, 2025.

[0001193125-26-201403:mdna:17]
[same as prior period, unchanged from 0001193125-25-260708:mdna:19]

[0001193125-26-201403:mdna:18]
[same as prior period, unchanged from 0001193125-25-260708:mdna:20]

[0001193125-26-201403:mdna:19]
[same as prior period, unchanged from 0001193125-25-260708:mdna:21]

[0001193125-26-201403:mdna:20]
|  |  | For the Quarter Ended |  |
|  |  | March 30, 2026 |  |  | March 31, 2025 |  |
|  |  | (In thousands, except margin rates) |  |
| Net sales |  | $ | 845,976 |  |  | $ | 648,668 |  |
| Cost of goods sold |  |  | 664,795 |  |  |  | 517,696 |  |
| Gross profit |  |  | 181,181 |  |  |  | 130,972 |  |
| Gross margin |  |  | 21.4 | % |  |  | 20.2 | % |
| Operating expenses: |  |  |  |  |  |  |
| Selling and marketing |  |  | 24,994 |  |  |  | 21,271 |  |
| General and administrative |  |  | 68,745 |  |  |  | 43,774 |  |
| Research and development |  |  | 7,808 |  |  |  | 8,064 |  |
| Amortization of definite-lived intangibles |  |  | 6,889 |  |  |  | 6,889 |  |
| Restructuring charges |  |  | 296 |  |  |  | 714 |  |
| Total operating expenses |  |  | 108,732 |  |  |  | 80,712 |  |
| Operating income |  |  | 72,449 |  |  |  | 50,260 |  |
| Operating margin |  |  | 8.6 | % |  |  | 7.7 | % |
| Total other expense, net |  |  | (13,924 | ) |  |  | (9,269 | ) |
| Income tax provision |  |  | (8,537 | ) |  |  | (8,813 | ) |
| Net income |  | $ | 49,988 |  |  | $ | 32,178 |  |

[0001193125-26-201403:mdna:21]
[same as prior period, unchanged from 0001193125-25-260708:mdna:24]

[0001193125-26-201403:mdna:22]
Total net sales increased $197.3 million, or 30.4%, to $846.0 million for the quarter ended March 30, 2026, from $648.7 million for the quarter ended March 31, 2025. The primary driver of this increase was due to continued strong demand in our data center and networking end market driven by the continued build out of AI data centers and related applications, as well as strong growth in our medical, industrial, and instrumentation and aerospace and defense end markets.

[0001193125-26-201403:mdna:23]
[same as prior period, unchanged from 0001193125-25-260708:mdna:27]

[0001193125-26-201403:mdna:24]
Gross profit increased $50.2 million to $181.2 million for the quarter ended March 30, 2026, from $131.0 million for the quarter ended March 31, 2025. Gross margin rate increased to 21.4% for the quarter ended March 30, 2026, from 20.2% for the quarter ended March 31, 2025. These increases were primarily due to higher sales volume, favorable product mix, and improved operational execution, partially offset by continued ramp-up costs in connection with our fabrication plant in Penang, Malaysia.

[0001193125-26-201403:mdna:25]
[same as prior period, unchanged from 0001193125-25-260708:mdna:30]

[0001193125-26-201403:mdna:26]
Operating expenses increased $28.0 million to $108.7 million for the quarter ended March 30, 2026, from $80.7 million for the quarter ended March 31, 2025, primarily due to higher stock-based compensation, labor costs, and incentive compensation. The increase in stock-based compensation was primarily driven by exceeding predetermined targets, stock price appreciation, and vesting of certain performance-based stock grants.

[0001193125-26-201403:mdna:27]
[same as prior period, unchanged from 0001193125-25-260708:mdna:33]

[0001193125-26-201403:mdna:28]
Operating income increased $22.2 million to $72.4 million for the quarter ended March 30, 2026, from $50.3 million for the quarter ended March 31, 2025. Operating margin rate increased to 8.6% for the quarter ended March 30, 2026, from 7.7% for the quarter ended March 31, 2025. The primary drivers of these increases are discussed above in the variance explanations for Gross Profit and Margin Rate and Operating Expenses.

[0001193125-26-201403:mdna:29]
[same as prior period, unchanged from 0001193125-25-260708:mdna:36]

[0001193125-26-201403:mdna:30]
Total other expense, net increased $4.7 million to $13.9 million for the quarter ended March 30, 2026, from $9.3 million for the quarter ended March 31, 2025, primarily due to a higher amount of foreign exchange losses during the quarter ended March 30, 2026 resulting from strengthening RMB and MYR during the quarter ended March 30, 2026 as compared to the quarter ended March 31, 2025. We utilize the RMB and MYR at our China and Malaysia facilities, respectively, for employee‑related and other costs of running our operations in foreign countries.

[0001193125-26-201403:mdna:31]
[same as prior period, unchanged from 0001193125-25-260708:mdna:40]

[0001193125-26-201403:mdna:32]
Income tax expense decreased $0.3 million to $8.5 million for the quarter ended March 30, 2026, from $8.8 million for the quarter ended March 31, 2025, primarily due to tax benefits from the deduction of stock-based compensation, partially offset by tax expense driven by higher income before income taxes.

[0001193125-26-201403:mdna:33]
Our effective tax rate is primarily impacted by the mix of foreign and U.S. income, tax rates in China and Hong Kong, the U.S. federal income tax rate, apportioned state income tax rates, the generation of credits and deductions available to us as well as changes in valuation allowances and certain non-deductible items. We had a net deferred income tax liability of $45.2 million and $40.6 million as of March 30, 2026 and March 31, 2025, respectively.

[0001193125-26-201403:mdna:34]
[same as prior period, unchanged from 0001193125-25-260708:mdna:46]

[0001193125-26-201403:mdna:35]
[same as prior period, unchanged from 0001193125-25-260708:mdna:47]

[0001193125-26-201403:mdna:36]
During the quarter ended March 30, 2026, the Company strategically realigned RF&S Components within the A&D sector and concluded that the Company now has two reportable segments: A&D and Commercial. In prior periods, the Company had three reportable segments: A&D, Commercial, and RF&S Components following a change during the quarter ended June 30, 2025. As a result, certain prior period amounts have been reclassified to conform with this new presentation. See Part I, Item 1, Note 4, Segment Information, of the Notes to Consolidated Condensed Financial Statements in this Report for further information.

[0001193125-26-201403:mdna:37]
[same as prior period, unchanged from 0001193125-25-260708:mdna:49]

[0001193125-26-201403:mdna:38]
|  |  | For the Quarter Ended |  |
|  |  | March 30, 2026 |  |  | March 31, 2025 |  |
|  |  | (In thousands, except margin rates) |  |
| Segment sales: |  |  |  |  |  |  |
| A&D |  | $ | 351,664 |  |  | $ | 316,250 |  |
| Commercial |  |  | 495,043 |  |  |  | 332,705 |  |
| Total |  | $ | 846,707 |  |  | $ | 648,955 |  |
| Segment operating income: |  |  |  |  |  |  |
| A&D |  | $ | 54,779 |  |  | $ | 42,369 |  |
| Commercial |  |  | 81,568 |  |  |  | 43,649 |  |
| Total |  |  | 136,347 |  |  |  | 86,018 |  |
| Segment operating margin rate: |  |  |  |  |  |  |
| A&D |  |  | 15.6 | % |  |  | 13.4 | % |
| Commercial |  |  | 16.5 | % |  |  | 13.1 | % |
| Total |  |  | 16.1 | % |  |  | 13.3 | % |
| Unallocated amounts: |  |  |  |  |  |  |
| Restructuring |  |  | (296 | ) |  |  | (714 | ) |
| Acquisition-related and other charges |  |  | (197 | ) |  | — |  |
| Stock-based compensation |  |  | (24,356 | ) |  |  | (8,787 | ) |
| Other corporate expenses |  |  | (29,825 | ) |  |  | (17,033 | ) |
| Amortization of definite-lived intangibles (1) |  |  | (9,224 | ) |  |  | (9,224 | ) |
| Operating income |  | $ | 72,449 |  |  | $ | 50,260 |  |

[0001193125-26-201403:mdna:39]
(1)
Amortization of definite-lived intangibles relates to the A&D and Commercial reportable segments, but is not reviewed separately by the CODM. For the quarters ended March 30, 2026 and March 31, 2025, amortization expense of $2,335 is included in cost of goods sold for the A&D reportable segment.

[0001193125-26-201403:mdna:40]
[same as prior period, unchanged from 0001193125-25-260708:mdna:52]

[0001193125-26-201403:mdna:41]
[same as prior period, unchanged from 0001193125-25-260708:mdna:53]

[0001193125-26-201403:mdna:42]
[same as prior period, unchanged from 0001193125-25-260708:mdna:54]

[0001193125-26-201403:mdna:43]
Segment sales for the A&D reportable segment increased $35.4 million, or 11.2%, to $351.7 million for the quarter ended March 30, 2026, from $316.3 million for the quarter ended March 31, 2025. The primary drivers of this increase were strong defense budget spending, our strong strategic program alignment, and key bookings for ongoing franchise programs, including restricted programs. These increases were driven by increased sales related to missiles and munitions as well as strong demand in our mission systems and specialty assembly businesses.

[0001193125-26-201403:mdna:44]
[same as prior period, unchanged from 0001193125-25-260708:mdna:58]

[0001193125-26-201403:mdna:45]
Segment operating income for the A&D reportable segment increased $12.4 million to $54.8 million for the quarter ended March 30, 2026, from $42.4 million for the quarter ended March 31, 2025. Segment operating margin rate for the A&D reportable segment increased to 15.6% for the quarter ended March 30, 2026, from 13.4% for the quarter ended March 31, 2025. The primary drivers of these increases were higher sales volume, as discussed above, favorable product mix, and improved operational execution.

[0001193125-26-201403:mdna:46]
[same as prior period, unchanged from 0001193125-25-260708:mdna:61]

[0001193125-26-201403:mdna:47]
[same as prior period, unchanged from 0001193125-25-260708:mdna:62]

[0001193125-26-201403:mdna:48]
Segment sales for the Commercial reportable segment increased $162.3 million, or 48.8%, to $495.0 million for the quarter ended March 30, 2026, from $332.7 million for the quarter ended March 31, 2025. The primary driver of this increase was strong demand in our data center and networking end market driven by the continued buildout of AI data centers and related applications, as well as strong sales performance in our medical, industrial, and instrumentation end market.

[0001193125-26-201403:mdna:49]
[same as prior period, unchanged from 0001193125-25-260708:mdna:65]

[0001193125-26-201403:mdna:50]
Segment operating income for the Commercial reportable segment increased $37.9 million to $81.6 million for the quarter ended March 30, 2026, from $43.6 million for the quarter ended March 31, 2025. Segment operating margin rate for the Commercial reportable segment increased to 16.5% for the quarter ended March 30, 2026, from 13.1% for the quarter ended March 31, 2025. The primary driver of these increases was higher sales volume, as discussed above, and improved operational execution, partially offset by increased ramp-up costs in connection with our fabrication plant in Penang, Malaysia.

[0001193125-26-201403:mdna:51]
[same as prior period, unchanged from 0001193125-25-260708:mdna:76]

[0001193125-26-201403:mdna:52]
[same as prior period, unchanged from 0001193125-25-260708:mdna:77]

[0001193125-26-201403:mdna:53]
Cash flow provided by operating activities during the first quarter of 2026 was $21.7 million as compared to cash flow used in operating activities of $10.7 million in the same period in 2025. The increase in cash flow was primarily due to an increase in net income of $17.8 million.

[0001193125-26-201403:mdna:54]
Net cash used in investing activities during the first quarter of 2026 was $106.8 million, consisting of net purchases of property, plant, and equipment and other assets. Net cash used in investing activities during the first quarter of 2025 was $63.2 million, primarily resulting from the use of $63.3 million for purchases of property, plant, and equipment and other assets.

[0001193125-26-201403:mdna:55]
Net cash used in financing activities during the first quarter of 2026 was $6.2 million, primarily resulting from the repayments of $5.0 million for customer deposits and $0.9 million for long-term debt borrowings. Net cash used in financing activities during the first quarter of 2025 was $18.8 million, reflecting the use of $17.9 million for repurchases of common stock and $0.9 million for the repayment of long-term debt borrowings.

[0001193125-26-201403:mdna:56]
As of March 30, 2026, we had cash and cash equivalents of approximately $410.0 million, of which approximately $156.4 million was held by our foreign subsidiaries, primarily in China, and $189.5 million of available borrowing capacity under our revolving credit facilities. Should we choose to remit cash to the United States from our foreign locations, we may incur tax obligations which would reduce the amount of cash ultimately available to the United States. However, we believe there would be no material tax expenses not previously accrued for the repatriation of this cash.

[0001193125-26-201403:mdna:57]
Our total 2026 capital expenditures are expected to be in the range of $300.0 million to $320.0 million, primarily for capacity expansion to meet market demand.

[0001193125-26-201403:mdna:58]
[same as prior period, unchanged from 0001193125-25-260708:mdna:83]

[0001193125-26-201403:mdna:59]
On May 8, 2025, our Board of Directors authorized the 2025 Repurchase Program, under which we may repurchase up to $100.0 million in value of our common stock from time to time through May 7, 2027. We did not repurchase any shares of our common stock during the quarter ended March 30, 2026. As of March 30, 2026, the remaining amount in value available to be repurchased under the 2025 Repurchase Program was $100.0 million.

[0001193125-26-201403:mdna:60]
[same as prior period, unchanged from 0001193125-25-260708:mdna:85]

[0001193125-26-201403:mdna:61]
As of March 30, 2026, we had $915.7 million of outstanding debt, net of discount and issuance costs, composed of $497.6 million of Senior Notes due 2029, $336.2 million under the Term Loan Facility, $80.0 million under the Asia ABL, and $1.9 million of other loans.

[0001193125-26-201403:mdna:62]
Pursuant to the terms of the Senior Notes due 2029 and Term Loan Facility, we are subject to certain affirmative and negative covenants, including limitations on indebtedness, corporate transactions, investments, dispositions, and restricted payments. Under the ABL Revolving Loans, we are also subject to various financial covenants, including leverage and fixed-charge coverage ratios. As of March 30, 2026, we were in compliance with the covenants under the Senior Notes due 2029, Term Loan Facility, and ABL Revolving Loans.

[0001193125-26-201403:mdna:63]
[same as prior period, unchanged from 0001193125-25-260708:mdna:88]

[0001193125-26-201403:mdna:64]
[same as prior period, unchanged from 0001193125-25-260708:mdna:89]

[0001193125-26-201403:mdna:65]
We have agreements with financial institutions to facilitate payments to certain suppliers. Liabilities associated with these agreements are recorded in accounts payable on the consolidated condensed balance sheets and amounted to $16.4 million and $12.5 million as of March 30, 2026 and December 29, 2025, respectively.

[0001193125-26-201403:mdna:66]
[same as prior period, unchanged from 0001193125-25-260708:mdna:91]

[0001193125-26-201403:mdna:67]
As part of our ongoing operations, we enter into contractual arrangements that obligate us to make future cash payments. These obligations impact our liquidity and capital resource needs. Our estimated future obligations consist of long-term debt obligations, interest on debt obligations, derivative liabilities, purchase obligations, and leases. As of March 30, 2026, there were no material changes outside the ordinary course of business since December 29, 2025 to our contractual obligations and commitments and the related cash requirements.

[0001193125-26-201403:mdna:68]
[same as prior period, unchanged from 0001193125-25-260708:mdna:93]

[0001193125-26-201403:mdna:69]
We do not consider any material portion of our business to be seasonal. Various factors, however, can affect the distribution of our sales between accounting periods, including the timing of customer orders, the availability of customer funding, product deliveries, and customer acceptance.

[0001193125-26-201403:mdna:70]
Recently Issued Accounting Standards

[0001193125-26-201403:mdna:71]
[same as prior period, unchanged from 0001193125-25-260708:mdna:96]
