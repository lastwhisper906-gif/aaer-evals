# TTMI notes — 0001193125-26-201403


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureAndSignificantAccountingPoliciesTextBlock

[0001193125-26-201403:notes:1]
[same as prior period, unchanged from 0001193125-25-260708:notes:1]

[0001193125-26-201403:notes:2]
TTM Technologies, Inc. is a leading global manufacturer of technology products, including mission systems, RF components, RF microwave/microelectronic assemblies, and technologically advanced interconnect products, including PCBs and substrates. The Company provides time-to-market and volume production of advanced technology products and offers a one-stop design, engineering, and manufacturing solution to customers. This solution allows the Company to align technology developments with the diverse needs of the Company’s customers and to enable them to reduce the time required to develop new products and bring them to market.

[0001193125-26-201403:notes:3]
The Company serves a diversified customer base in various markets throughout the world, including aerospace and defense; automotive; data center and networking; and medical, industrial, and instrumentation. The Company’s customers include OEMs, EMS providers, ODMs, distributors, and government agencies (both domestic and allied foreign governments).

[0001193125-26-201403:notes:4]
The accompanying unaudited consolidated condensed financial statements have been prepared by the Company pursuant to the rules and regulations of the SEC. Certain information and disclosures normally included in financial statements prepared in accordance with U.S. GAAP have been condensed or omitted pursuant to such rules and regulations. These consolidated condensed financial statements should be read in conjunction with the consolidated financial statements and the notes thereto included in the Company’s most recent Annual Report on Form 10-K. The preparation of financial statements in accordance with U.S. GAAP requires management to make estimates and assumptions that affect the amounts reported in the Company’s consolidated condensed financial statements and accompanying notes. Due, in part, to the conflicts between Russia and Ukraine and conflicts in the Middle East, as well as other global regions, the imposition of, or changes to, tariffs by the United States as well as retaliatory tariffs or measures by other countries, and the rising prices of global crude oil, the global economy and financial markets have continued to be volatile. As such, the Company has considered information available to it as of the date of issuance of these consolidated condensed financial statements and is not aware of any specific events or circumstances that would require an update to its estimates or judgments, or a revision to the carrying value of its assets or liabilities. The actual results the Company experienced may differ materially and adversely from its estimates.

[0001193125-26-201403:notes:5]
Recently Issued Accounting Standards Not Yet Adopted

[0001193125-26-201403:notes:6]
In December 2025, the FASB issued ASU 2025-10, Accounting for Government Grants Received by Business Entities, to provide guidance on how business entities should recognize, measure, and present government grants received. The ASU is effective for annual periods beginning after December 15, 2028, and interim periods within those annual reporting periods. Early adoption is permitted. The guidance may be applied on a modified prospective basis, a modified retrospective basis, or a retrospective basis. The Company is currently evaluating the timing of the adoption and the impact of this ASU on its consolidated financial statements and related disclosures.

[0001193125-26-201403:notes:7]
In September 2025, the FASB issued ASU 2025-06, Targeted Improvements to the Accounting for Internal-Use Software, which amends the existing standard to remove all references to prescriptive and sequential software development project stages. Under this guidance, eligible software development costs will begin capitalization when management has authorized and committed to funding the software project, and it is probable that the project will be completed and the software will be used to perform the function intended. The ASU is effective for annual periods beginning after December 15, 2027, and interim periods within those annual reporting periods. Early adoption is permitted as of the beginning of an annual reporting period. The guidance may be applied on a prospective basis, a modified basis for in-process projects, or a retrospective basis. The Company is currently evaluating the timing of the adoption and the impact of this ASU on its consolidated financial statements and related disclosures.

[0001193125-26-201403:notes:8]
In November 2024, the FASB issued ASU 2024-03, Income Statement-Reporting Comprehensive Income-Expense Disaggregation Disclosures (Subtopic 220-40): Disaggregation of Income Statement Expenses, which requires disclosure in the notes to the financial statements of specified information about certain costs and expenses. In January 2025, the FASB issued ASU 2025-01, Income Statement-Reporting Comprehensive Income-Expense Disaggregation Disclosures (Subtopic 220-40): Clarifying the Effective Date, which amends the effective date of ASU 2024-03 to clarify that all public business entities are required to adopt the guidance in annual reporting periods beginning after December 15, 2026, and interim periods within annual reporting periods beginning after December 15, 2027. Early adoption of ASU 2024-03 is permitted. ASU 2024-03 should be applied either prospectively to financial statements issued for reporting periods after the effective date or retrospectively to any or all prior periods presented in the financial statements. The Company is currently evaluating the new guidance to determine the impact it may have on its consolidated financial statements and related disclosures, but expects additional disclosures upon adoption.


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0001193125-26-201403:notes:9]
[same as prior period, unchanged from 0001193125-25-260708:notes:10]

[0001193125-26-201403:notes:10]
For contracts in which anticipated total costs exceed the total expected revenue, an estimated loss is recognized in the period when identifiable. A provision for the entire amount of the estimated loss is recorded on a cumulative basis. The estimated remaining costs to complete for loss contracts as of March 30, 2026 and December 29, 2025 were $28,523 and $33,163, respectively.

[0001193125-26-201403:notes:11]
As of March 30, 2026, the aggregate amount of the transaction price allocated to remaining performance obligations for long‑term contracts was $393,556. The Company expects to recognize revenue on approximately 62% of the remaining performance obligations for the Company’s long-term contracts over the next 12 months with the remaining amount expected to be recognized thereafter. The remaining performance obligations for the Company’s short‑term contracts are expected to be recognized within one year, and the Company is applying the optional permitted exemption to forgo disclosing the amount of transaction price allocated to the remaining performance obligations for contracts with an expected duration of one year or less.

[0001193125-26-201403:notes:12]
Revenue recognized for the quarter ended March 30, 2026 from amounts recorded as contract liabilities as of December 29, 2025 was $42,002. Revenue recognized for the quarter ended March 31, 2025 from amounts recorded as contract liabilities as of December 30, 2024 was $22,496.

[0001193125-26-201403:notes:13]
Revenue from products and services transferred to customers over time and at a point in time accounted for 96% and 4%, respectively, of the Company's revenue for both the quarters ended March 30, 2026 and March 31, 2025.

[0001193125-26-201403:notes:14]
[same as prior period, unchanged from 0001193125-25-260708:notes:15]

[0001193125-26-201403:notes:15]
|  |  | For the Quarter Ended |  |
|  |  | March 30, 2026 |  |  | March 31, 2025 |  |
|  |  | A&D |  |  | Commercial |  |  | Total |  |  | A&D |  |  | Commercial |  |  | Total |  |
|  |  | (In thousands) |  |
| End Markets (1): |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Aerospace and Defense |  | $ | 341,557 |  |  | $ | — |  |  | $ | 341,557 |  |  | $ | 307,418 |  |  | $ | — |  |  | $ | 307,418 |  |
| Automotive |  |  | — |  |  |  | 69,770 |  |  |  | 69,770 |  |  |  | — |  |  |  | 71,354 |  |  |  | 71,354 |  |
| Data Center and Networking |  |  | 8,663 |  |  |  | 293,084 |  |  |  | 301,747 |  |  |  | 7,911 |  |  |  | 179,539 |  |  |  | 187,450 |  |
| Medical, Industrial, and Instrumentation |  |  | 966 |  |  |  | 131,936 |  |  |  | 132,902 |  |  |  | 909 |  |  |  | 81,537 |  |  |  | 82,446 |  |
| Total |  | $ | 351,186 |  |  | $ | 494,790 |  |  | $ | 845,976 |  |  | $ | 316,238 |  |  | $ | 332,430 |  |  | $ | 648,668 |  |

[0001193125-26-201403:notes:16]
(1)
The end market revenue for the quarter ended March 31, 2025 has been recast to reflect certain adjustments to allocations resulting from the segment reorganizations that occurred during the quarters ended March 30, 2026 and June 30, 2025 as well as the combination of the data center computing and networking end markets. The end market revenue excludes intersegment sales totaling $731 and $287 for the quarters ended March 30, 2026 and March 31, 2025, respectively. See Note 4, Segment Information, for further information.


## us-gaap:ConcentrationRiskDisclosureTextBlock

[0001193125-26-201403:notes:17]
[same as prior period, unchanged from 0001193125-25-260708:notes:19]

[0001193125-26-201403:notes:18]
[same as prior period, unchanged from 0001193125-25-260708:notes:20]

[0001193125-26-201403:notes:19]
The Company had cash and cash equivalents held by its foreign subsidiaries of $156,445 and $191,925 as of March 30, 2026 and December 29, 2025, respectively. The Company maintains its cash and cash equivalents with major financial institutions and such balances exceed Federal Deposit Insurance Corporation (FDIC) insurance limits. The Company has not experienced any losses in such accounts and believes it is not exposed to any significant risk on cash and cash equivalents.

[0001193125-26-201403:notes:20]
In the normal course of business, the Company extends credit to its customers. Some customers to whom the Company extends credit are located outside the United States. The Company performs ongoing credit evaluations of customers, does not require collateral, and considers the credit risk profile of the entity from which the receivable is due in further evaluating collection risk. As of March 30, 2026 and December 29, 2025, one customer accounted for 13% and 14%, respectively, of the Company's accounts receivable.

[0001193125-26-201403:notes:21]
The Company’s customers include both OEMs and EMS companies. The Company’s OEM customers often direct a significant portion of their purchases through EMS companies. While the Company’s customers include both OEM and EMS providers, the Company measures customer concentration based on OEM companies, as they are the ultimate end customers.
For the quarter ended March 30, 2026, two customers collectively accounted for approximately 26% of the Company's net sales. For the quarter ended March 31, 2025, one customer accounted for approximately 12% of the Company's net sales.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001193125-26-201403:notes:22]
[same as prior period, unchanged from 0001193125-25-260708:notes:24]

[0001193125-26-201403:notes:23]
During the quarter ended March 30, 2026, the Company strategically realigned RF&S Components within the A&D sector and concluded that the Company now has two reportable segments: A&D and Commercial. In prior periods, the Company had three reportable segments: A&D, Commercial, and RF&S Components following a change during the quarter ended June 30, 2025. As a result, certain prior period amounts have been reclassified to conform with this new presentation.

[0001193125-26-201403:notes:24]
The reportable segments shown below are the Company’s segments for which separate financial information is available and upon which operating results are evaluated by the CODM, who is the President and Chief Executive Officer, to assess performance and to allocate resources. The CODM uses segment operating income to allocate resources such as employees and capital resources for each segment during the Company’s annual budgeting and forecasting process. Total sales and operating profit by segment include

[0001193125-26-201403:notes:25]
intersegment sales which are generally recorded at cost-plus a specified fee or at a negotiated fixed price. Separate segment asset measures are not used as a basis for the CODM to evaluate the performance of or to allocate resources to the segments.

[0001193125-26-201403:notes:26]
The A&D reportable segment consists of PCBs, value-added assemblies, microelectronics, RF/microwave components and assemblies, integrated mission systems, and commercial off-the-shelf (COTS) components. These highly engineered electronics products include the manufacture and test of customer‑supplied designs as well as long-term contracts to design, develop, manufacture, and test new products. The products in the A&D reportable segment support surveillance, intelligence, communications, and other critical missions for customers in the aerospace and defense industry as well as commercial customers in the telecommunications, industrial, and instrumentation markets. The Commercial reportable segment consists of PCBs using customer-supplied engineering and design plans supporting customers in the automotive; data center and networking; and medical, industrial, and instrumentation end markets.

[0001193125-26-201403:notes:27]
[same as prior period, unchanged from 0001193125-25-260708:notes:28]

[0001193125-26-201403:notes:28]
|  |  | For the Quarter Ended |  |
|  |  | March 30, 2026 |  |  | March 31, 2025 |  |
|  |  | Net Sales |  |  | Intersegment Sales |  |  | Segment Sales |  |  | Net Sales |  |  | Intersegment Sales |  |  | Segment Sales |  |
|  |  | (In thousands) |  |
| A&D |  | $ | 351,186 |  |  | $ | 478 |  |  | $ | 351,664 |  |  | $ | 316,238 |  |  | $ | 12 |  |  | $ | 316,250 |  |
| Commercial |  |  | 494,790 |  |  |  | 253 |  |  |  | 495,043 |  |  |  | 332,430 |  |  |  | 275 |  |  |  | 332,705 |  |
| Eliminations |  |  | — |  |  |  | (731 | ) |  |  | (731 | ) |  |  | — |  |  |  | (287 | ) |  |  | (287 | ) |
| Total |  | $ | 845,976 |  |  | $ | — |  |  | $ | 845,976 |  |  | $ | 648,668 |  |  | $ | — |  |  | $ | 648,668 |  |

[0001193125-26-201403:notes:29]
|  |  | For the Quarter Ended March 30, 2026 |
|  |  | Net Sales |  |  | Cost of Goods Sold |  |  | Operating Expenses |  |  | Operating Income |  |  | Operating Margin |
|  |  | (In thousands, except margin rates) |
| A&D |  | $ | 351,664 |  |  | $ | (261,164 | ) |  | $ | (35,721 | ) |  | $ | 54,779 |  |  |  | 15.6 |  | % |
| Commercial |  |  | 495,043 |  |  |  | (393,338 | ) |  |  | (20,137 | ) |  |  | 81,568 |  |  |  | 16.5 |  |  |
| Total segment |  |  | 846,707 |  |  |  | (654,502 | ) |  |  | (55,858 | ) |  |  | 136,347 |  |  |  | 16.1 |  |  |
| Eliminations |  |  | (731 | ) |  |  |  |  |  |  |  |  | — |  |  |  |  |  |
| Unallocated amounts: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Restructuring |  |  |  |  |  |  |  |  |  |  |  | (296 | ) |  |  |  |  |
| Acquisition-related and other charges |  |  |  |  |  |  |  |  |  |  |  | (197 | ) |  |  |  |  |
| Stock-based compensation |  |  |  |  |  |  |  |  |  |  |  | (24,356 | ) |  |  |  |  |
| Other corporate expenses |  |  |  |  |  |  |  |  |  |  |  | (29,825 | ) |  |  |  |  |
| Amortization of definite-lived intangibles |  |  |  |  |  |  |  |  |  |  |  | (9,224 | ) |  |  |  |  |
| Consolidated |  | $ | 845,976 |  |  |  |  |  |  |  |  |  | 72,449 |  |  |  | 8.6 |  | % |
| Interest expense |  |  |  |  |  |  |  |  |  |  |  | (10,600 | ) |  |  |  |  |
| Other, net |  |  |  |  |  |  |  |  |  |  |  | (3,324 | ) |  |  |  |  |
| Income before income taxes |  |  |  |  |  |  |  |  |  |  | $ | 58,525 |  |  |  |  |  |

[0001193125-26-201403:notes:30]
|  |  | For the Quarter Ended March 31, 2025 |
|  |  | Net Sales |  |  | Cost of Goods Sold |  |  | Operating Expenses |  |  | Operating Income |  |  | Operating Margin |
|  |  | (In thousands, except margin rates) |
| A&D |  | $ | 316,250 |  |  | $ | (240,995 | ) |  | $ | (32,886 | ) |  | $ | 42,369 |  |  |  | 13.4 |  | % |
| Commercial |  |  | 332,705 |  |  |  | (269,085 | ) |  |  | (19,971 | ) |  |  | 43,649 |  |  |  | 13.1 |  |  |
| Total segment |  |  | 648,955 |  |  |  | (510,080 | ) |  |  | (52,857 | ) |  |  | 86,018 |  |  |  | 13.3 |  |  |
| Eliminations |  |  | (287 | ) |  |  |  |  |  |  |  |  | — |  |  |  |  |  |
| Unallocated amounts: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Restructuring |  |  |  |  |  |  |  |  |  |  |  | (714 | ) |  |  |  |  |
| Stock-based compensation |  |  |  |  |  |  |  |  |  |  |  | (8,787 | ) |  |  |  |  |
| Other corporate expenses |  |  |  |  |  |  |  |  |  |  |  | (17,033 | ) |  |  |  |  |
| Amortization of definite-lived intangibles |  |  |  |  |  |  |  |  |  |  |  | (9,224 | ) |  |  |  |  |
| Consolidated |  | $ | 648,668 |  |  |  |  |  |  |  |  |  | 50,260 |  |  |  | 7.7 |  | % |
| Interest expense |  |  |  |  |  |  |  |  |  |  |  | (11,464 | ) |  |  |  |  |
| Other, net |  |  |  |  |  |  |  |  |  |  |  | 2,195 |  |  |  |  |  |
| Income before income taxes |  |  |  |  |  |  |  |  |  |  | $ | 40,991 |  |  |  |  |  |

[0001193125-26-201403:notes:31]
Amortization of definite-lived intangibles relates to the A&D and Commercial reportable segments, but is not reviewed separately by the CODM. For the quarters ended March 30, 2026 and March 31, 2025, amortization expense of $2,335 is included in cost of goods sold for the A&D reportable segment.

[0001193125-26-201403:notes:32]
[same as prior period, unchanged from 0001193125-25-260708:notes:34]

[0001193125-26-201403:notes:33]
|  |  | For the Quarter Ended |  |
|  |  | March 30, 2026 |  |  | March 31, 2025 |  |
|  |  | (In thousands) |  |
| A&D |  | $ | 9,441 |  |  | $ | 9,214 |  |
| Commercial |  |  | 18,148 |  |  |  | 15,900 |  |
| Segment total |  |  | 27,589 |  |  |  | 25,114 |  |
| Corporate |  |  | 1,703 |  |  |  | 1,749 |  |
| Total |  | $ | 29,292 |  |  | $ | 26,863 |  |

[0001193125-26-201403:notes:34]
The Company markets and sells its products in approximately 60 countries. For the quarter ended March 30, 2026, the Company did not conduct business in any country other than the United States and Taiwan in which its net sales in that country exceeded 10% of the Company’s total net sales. For the quarter ended March 31, 2025, the Company did not conduct business in any country other than the United States in which its net sales in that country exceeded 10% of the Company's total net sales. Net sales are attributed to countries by the invoiced location and were as follows:

[0001193125-26-201403:notes:35]
|  |  | For the Quarter Ended |  |
|  |  | March 30, 2026 |  |  | March 31, 2025 |  |
|  |  | (In thousands) |  |
| United States |  | $ | 413,597 |  |  | $ | 357,808 |  |
| Taiwan |  |  | 91,073 |  |  |  | 54,156 |  |
| Other |  |  | 341,306 |  |  |  | 236,704 |  |
| Total net sales |  | $ | 845,976 |  |  | $ | 648,668 |  |


## us-gaap:AdditionalFinancialInformationDisclosureTextBlock

[0001193125-26-201403:notes:36]
[same as prior period, unchanged from 0001193125-25-260708:notes:38]

[0001193125-26-201403:notes:37]
|  |  | As of |  |
|  |  | March 30, 2026 |  |  | December 29, 2025 |  |
|  |  | (In thousands) |  |
| Inventories: |  |  |  |  |  |  |
| Raw materials |  | $ | 225,415 |  |  | $ | 197,531 |  |
| Work-in-process |  |  | 50,622 |  |  |  | 48,236 |  |
| Finished goods |  |  | 4,173 |  |  |  | 4,290 |  |
| Inventories |  | $ | 280,210 |  |  | $ | 250,057 |  |
| Property, plant, and equipment, net: |  |  |  |  |  |  |
| Land and land use rights |  | $ | 72,342 |  |  | $ | 72,342 |  |
| Buildings and improvements |  |  | 629,342 |  |  |  | 634,785 |  |
| Machinery and equipment |  |  | 1,213,918 |  |  |  | 1,187,187 |  |
| Furniture and fixtures and other |  |  | 12,735 |  |  |  | 11,642 |  |
| Construction-in-progress |  |  | 156,520 |  |  |  | 101,945 |  |
| Property, plant, and equipment, gross |  |  | 2,084,857 |  |  |  | 2,007,901 |  |
| Less: Accumulated depreciation |  |  | (1,017,604 | ) |  |  | (997,191 | ) |
| Property, plant, and equipment, net |  | $ | 1,067,253 |  |  | $ | 1,010,710 |  |
| Other current liabilities: |  |  |  |  |  |  |
| Sales return and allowances |  | $ | 14,191 |  |  | $ | 12,392 |  |
| Accrued facility operating costs |  |  | 13,200 |  |  |  | 10,497 |  |
| Income taxes payable |  |  | 12,266 |  |  |  | 8,080 |  |
| Operating leases |  |  | 10,228 |  |  |  | 8,909 |  |
| Housing fund |  |  | 8,987 |  |  |  | 8,783 |  |
| Warranty |  |  | 7,080 |  |  |  | 7,855 |  |
| Interest |  |  | 3,727 |  |  |  | 8,792 |  |
| Accrued professional fees |  |  | 3,609 |  |  |  | 3,522 |  |
| Other |  |  | 40,074 |  |  |  | 37,420 |  |
| Other current liabilities |  | $ | 113,362 |  |  | $ | 106,250 |  |
| Other long-term liabilities: |  |  |  |  |  |  |
| Deferred income taxes |  | $ | 47,798 |  |  | $ | 46,334 |  |
| Customer deposits |  |  | 17,965 |  |  |  | 23,465 |  |
| Finance leases |  |  | 15,585 |  |  |  | 15,829 |  |
| Other |  |  | 26,882 |  |  |  | 30,393 |  |
| Other long-term liabilities |  | $ | 108,230 |  |  | $ | 116,021 |  |


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0001193125-26-201403:notes:38]
[same as prior period, unchanged from 0001193125-25-260708:notes:40]

[0001193125-26-201403:notes:39]
[same as prior period, unchanged from 0001193125-25-260708:notes:41]

[0001193125-26-201403:notes:40]
In connection with the Company’s strategic segment realignment during the quarter ended March 30, 2026, the RF&S Components reporting unit is now included as part of A&D. Management performed a goodwill impairment assessment over the $31,300 goodwill for the RF&S Components reporting unit and concluded no impairment indicators existed either before or after the realignment.

[0001193125-26-201403:notes:41]
As of March 30, 2026 and December 29, 2025, goodwill by reportable segment was $287,499 and $382,636 for A&D and Commercial, respectively.

[0001193125-26-201403:notes:42]
[same as prior period, unchanged from 0001193125-25-260708:notes:45]

[0001193125-26-201403:notes:43]
[same as prior period, unchanged from 0001193125-25-260708:notes:46]

[0001193125-26-201403:notes:44]
|  |  | GrossAmount |  |  | AccumulatedAmortization |  |  | NetCarryingAmount |  |  | WeightedAverageAmortizationPeriod |  |
|  |  | (In thousands) |  |  | (In years) |  |
| As of March 30, 2026 |  |  |  |  |  |  |  |  |  |  |  |  |
| Customer relationships |  | $ | 323,500 |  |  | $ | (196,153 | ) |  | $ | 127,347 |  |  |  | 11.8 |  |
| Technology |  |  | 66,650 |  |  |  | (48,299 | ) |  |  | 18,351 |  |  |  | 8.2 |  |
| Total |  | $ | 390,150 |  |  | $ | (244,452 | ) |  | $ | 145,698 |  |  |  |  |
| As of December 29, 2025 |  |  |  |  |  |  |  |  |  |  |  |  |
| Customer relationships |  | $ | 323,500 |  |  | $ | (189,264 | ) |  | $ | 134,236 |  |  |  | 11.8 |  |
| Technology |  |  | 66,650 |  |  |  | (45,964 | ) |  |  | 20,686 |  |  |  | 8.2 |  |
| Total |  | $ | 390,150 |  |  | $ | (235,228 | ) |  | $ | 154,922 |  |  |  |  |

[0001193125-26-201403:notes:45]
Definite-lived intangibles are amortized using the straight-line method of amortization over the useful life. For both the quarters ended March 30, 2026 and March 31, 2025, amortization expense was $9,224, of which $2,335 was included in cost of goods sold.

[0001193125-26-201403:notes:46]
[same as prior period, unchanged from 0001193125-25-260708:notes:49]

[0001193125-26-201403:notes:47]
|  |  | (In thousands) |  |
| Remaining 2026 |  | $ | 27,673 |  |
| 2027 |  |  | 34,543 |  |
| 2028 |  |  | 30,997 |  |
| 2029 |  |  | 22,355 |  |
| 2030 |  |  | 18,178 |  |
| Thereafter |  |  | 11,952 |  |
| Total |  | $ | 145,698 |  |


## us-gaap:LongTermDebtTextBlock

[0001193125-26-201403:notes:48]
(7) Long-term Debt and Letters of Credit

[0001193125-26-201403:notes:49]
Long-term debt was as follows:

[0001193125-26-201403:notes:50]
|  |  | As of |  |
|  |  | March 30, 2026 |  |  | December 29, 2025 |  |
|  |  | Interest Rate |  | PrincipalOutstanding |  |  | Interest Rate |  | PrincipalOutstanding |  |
|  |  | (In thousands, except interest rates) |  |
| Senior Notes due March 2029 |  |  | 4.00 |  | % |  | $ | 500,000 |  |  |  | 4.00 |  | % |  | $ | 500,000 |  |
| Term Loan due May 2030 |  |  | 5.91 |  |  |  |  | 341,303 |  |  |  | 5.97 |  |  |  |  | 342,169 |  |
| Asia ABL Revolving Loan due June 2028 |  |  | 4.96 |  |  |  |  | 80,000 |  |  |  | 5.02 |  |  |  |  | 80,000 |  |
| Other |  |  | 5.99 |  |  |  |  | 1,925 |  |  |  | 5.99 |  |  |  |  | 1,981 |  |
| Total debt |  |  |  |  |  |  | 923,228 |  |  |  |  |  |  |  | 924,150 |  |
| Less: Unamortized debt issuance costs |  |  |  |  |  |  | (5,274 | ) |  |  |  |  |  |  | (5,617 | ) |
| Less: Unamortized debt discount |  |  |  |  |  |  | (2,261 | ) |  |  |  |  |  |  | (2,382 | ) |
| Subtotal |  |  |  |  |  |  | 915,693 |  |  |  |  |  |  |  | 916,151 |  |
| Less: Current maturities |  |  |  |  |  |  | (3,851 | ) |  |  |  |  |  |  | (3,815 | ) |
| Long-term debt, less current maturities |  |  |  |  |  | $ | 911,842 |  |  |  |  |  |  | $ | 912,336 |  |

[0001193125-26-201403:notes:51]
Debt Covenants

[0001193125-26-201403:notes:52]
Borrowings under the Senior Notes due 2029 and Term Loan Facility are subject to certain affirmative and negative covenants, including limitations on indebtedness, corporate transactions, investments, dispositions, and restricted payments.

[0001193125-26-201403:notes:53]
Under the occurrence of certain events, the ABL Revolving Loans are subject to various financial covenants, including leverage and fixed-charge coverage ratios.

[0001193125-26-201403:notes:54]
Debt Issuance Costs and Debt Discount

[0001193125-26-201403:notes:55]
Remaining unamortized debt issuance costs and debt discount were as follows:

[0001193125-26-201403:notes:56]
|  |  | As of |
|  |  | March 30, 2026 |  | December 29, 2025 |
|  |  | DebtIssuance Costs |  |  | DebtDiscount |  |  | EffectiveInterest Rate |  | DebtIssuance Costs |  |  | DebtDiscount |  |  | EffectiveInterest Rate |
|  |  | (In thousands, except interest rates) |
| Senior Notes due March 2029 |  | $ | 2,414 |  |  | $ | — |  |  |  | 4.18 |  | % |  | $ | 2,608 |  |  | $ | — |  |  |  | 4.18 |  | % |
| Term Loan due May 2030 |  |  | 2,860 |  |  |  | 2,261 |  |  |  | 8.01 |  |  |  |  | 3,009 |  |  |  | 2,382 |  |  |  | 8.01 |  |  |
| Total |  | $ | 5,274 |  |  | $ | 2,261 |  |  |  |  |  |  | $ | 5,617 |  |  | $ | 2,382 |  |  |  |  |  |

[0001193125-26-201403:notes:57]
The above debt issuance costs and debt discount are recorded as a reduction of the debt and are amortized into interest expense using an effective interest rate over the duration of the debt.

[0001193125-26-201403:notes:58]
Remaining unamortized debt issuance costs for the ABL Revolving Loans of $784 and $874 as of March 30, 2026 and December 29, 2025, respectively, are included in deposits and other non-current assets and are amortized to interest expense over the duration of the ABL Revolving Loans using the straight-line method of amortization.

[0001193125-26-201403:notes:59]
As of March 30, 2026, the remaining weighted average amortization period for all unamortized debt issuance costs and debt discount was 3.6 years.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001193125-26-201403:notes:60]
[same as prior period, unchanged from 0001193125-25-260708:notes:63]

[0001193125-26-201403:notes:61]
[same as prior period, unchanged from 0001193125-25-260708:notes:64]

[0001193125-26-201403:notes:62]
During the quarter ended March 30, 2026, the Company’s effective tax rate was impacted by a net discrete benefit of $2,816. The net discrete benefit was primarily related to the deduction of stock‑based compensation, partially offset by a deferred tax expense related to the approval of the High and New Technology Enterprise (HNTE) status for a manufacturing subsidiary in China.

[0001193125-26-201403:notes:63]
[same as prior period, unchanged from 0001193125-25-260708:notes:66]


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001193125-26-201403:notes:64]
[same as prior period, unchanged from 0001193125-25-260708:notes:69]

[0001193125-26-201403:notes:65]
[same as prior period, unchanged from 0001193125-25-260708:notes:70]

[0001193125-26-201403:notes:66]
[same as prior period, unchanged from 0001193125-25-260708:notes:71]

[0001193125-26-201403:notes:67]
|  |  | For the Quarter Ended |  |
|  |  | March 30, 2026 |  |  | March 31, 2025 |  |
|  |  | (In thousands, except per share amounts) |  |
| Net income |  | $ | 49,988 |  |  | $ | 32,178 |  |
| Basic weighted average shares |  |  | 103,832 |  |  |  | 101,866 |  |
| Dilutive effect of PRUs, RSUs, and stock options |  |  | 3,252 |  |  |  | 2,664 |  |
| Diluted shares |  |  | 107,084 |  |  |  | 104,530 |  |
| Earnings per share: |  |  |  |  |  |  |
| Basic earnings per share |  | $ | 0.48 |  |  | $ | 0.32 |  |
| Diluted earnings per share |  |  | 0.47 |  |  |  | 0.31 |  |

[0001193125-26-201403:notes:68]
For the quarter ended March 30, 2026, there were no PRUs, RSUs, or stock options that would have had an anti-dilutive impact. For the quarter ended March 31, 2025, PRUs and RSUs to purchase 130 shares of common stock were not included in the computation of diluted earnings per share. The PRUs were not included in the computation of diluted earnings per share because the performance conditions had not been met, and for the RSUs, the total expected proceeds under the treasury stock method were greater than the average market price of common stock and, as a result, the impact would be anti-dilutive.

[0001193125-26-201403:notes:69]
[same as prior period, unchanged from 0001193125-25-260708:notes:74]

[0001193125-26-201403:notes:70]
On May 8, 2025, the Company's Board of Directors authorized the 2025 Repurchase Program, under which the Company may repurchase up to $100,000 in value of the Company’s outstanding shares of common stock from time to time through May 7, 2027. The Company may repurchase shares through open market purchases, privately‑negotiated transactions, or otherwise in accordance with applicable federal securities laws, including Rule 10b-18 of the Exchange Act, which sets certain restrictions on the method, timing, price, and volume of open market stock repurchases. In addition, the Company adopted one trading plan in accordance with Rule 10b5-1 of the Exchange Act to facilitate certain purchases that may be effected under the share repurchase program. The timing, manner, price, and amount of any repurchases will be determined at the Company’s discretion, and the share repurchase program may be suspended, terminated, or modified at any time for any reason. The repurchase program does not obligate the Company to acquire any specific number of shares.

[0001193125-26-201403:notes:71]
During the quarter ended March 30, 2026, the Company did not repurchase any shares. As of March 30, 2026, the remaining amount in value available to be repurchased under the 2025 Repurchase Program was $100,000.

[0001193125-26-201403:notes:72]
[same as prior period, unchanged from 0001193125-25-260708:notes:77]

[0001193125-26-201403:notes:73]
[same as prior period, unchanged from 0001193125-25-260708:notes:78]

[0001193125-26-201403:notes:74]
|  |  | As of |  |
|  |  | March 30, 2026 |  |  | December 29, 2025 |  |
|  |  | (In thousands) |  |
| Foreign currency translation |  | $ | (33,239 | ) |  | $ | (33,374 | ) |
| Pension obligation |  |  | 2,891 |  |  |  | 2,891 |  |
| Cash flow hedges |  |  | 482 |  |  |  | (447 | ) |
| Total |  | $ | (29,866 | ) |  | $ | (30,930 | ) |


## us-gaap:FairValueDisclosuresTextBlock

[0001193125-26-201403:notes:75]
[same as prior period, unchanged from 0001193125-25-260708:notes:80]

[0001193125-26-201403:notes:76]
[same as prior period, unchanged from 0001193125-25-260708:notes:82]

[0001193125-26-201403:notes:77]
|  |  | As of |  |
|  |  | March 30, 2026 |  |  | December 29, 2025 |  |
|  |  | Carrying Amount |  |  | Fair Value |  |  | Carrying Amount |  |  | Fair Value |  |
|  |  | (In thousands) |  |
| Derivative assets, current |  | $ | 4,230 |  |  | $ | 4,230 |  |  | $ | 5,212 |  |  | $ | 5,212 |  |
| Derivative liabilities, current |  |  | — |  |  |  | — |  |  |  | 31 |  |  |  | 31 |  |
| Derivative liabilities, non-current |  |  | — |  |  |  | — |  |  |  | 382 |  |  |  | 382 |  |
| Senior Notes due March 2029 |  |  | 497,586 |  |  |  | 477,825 |  |  |  | 497,392 |  |  |  | 488,325 |  |
| Term Loan due May 2030 |  |  | 336,182 |  |  |  | 344,289 |  |  |  | 336,778 |  |  |  | 345,806 |  |
| ABL Revolving Loans |  |  | 80,000 |  |  |  | 80,000 |  |  |  | 80,000 |  |  |  | 80,000 |  |
| Other loan |  |  | 1,925 |  |  |  | 1,925 |  |  |  | 1,981 |  |  |  | 1,981 |  |

[0001193125-26-201403:notes:78]
[same as prior period, unchanged from 0001193125-25-260708:notes:84]

[0001193125-26-201403:notes:79]
The fair value of the long-term debt was estimated based on quoted market prices, where available, as of March 30, 2026 and December 29, 2025, which are considered Level 2 inputs.

[0001193125-26-201403:notes:80]
As of March 30, 2026 and December 29, 2025, the Company’s other financial instruments included cash and cash equivalents, accounts receivable, contract assets, accounts payable, and contract liabilities. The carrying amount of these instruments approximates fair value.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001193125-26-201403:notes:81]
(11) Commitments and Contingencies

[0001193125-26-201403:notes:82]
Legal Matters

[0001193125-26-201403:notes:83]
The Company is subject to various legal matters, which it considers normal for its business activities. While the Company currently believes that the amount of any reasonably possible loss for known matters would not be material to the Company’s financial condition, the outcome of these actions is inherently difficult to predict. In the event of an adverse outcome, the ultimate potential loss could have a material adverse effect on the Company’s financial condition or results of operations in a particular period. The Company has accrued amounts for its loss contingencies which are probable and estimable as of March 30, 2026 and December 29, 2025 and included as a component of other current liabilities. However, these amounts are not material to the consolidated condensed financial statements of the Company.

[0001193125-26-201403:notes:84]
Supplier Finance Program Obligations

[0001193125-26-201403:notes:85]
The Company has agreements with financial institutions to facilitate payments to certain suppliers. Liabilities associated with these agreements are recorded in accounts payable on the consolidated condensed balance sheets and amounted to $16,375 and $12,535 as of March 30, 2026 and December 29, 2025, respectively.


## ecd:MtrlTermsOfTrdArrTextBlock

[0001193125-26-201403:notes:86]
During the quarter ended March 30, 2026, our directors and/or officers (as defined in Rule 16a-1(f) under the Exchange Act) adopted or terminated the contracts, instructions, or written plans for the purchase or sale of our securities set forth in the table below.

[0001193125-26-201403:notes:87]
| Name and Title |  | Action |  | Adoption / Termination Date |  | Rule 10b5-1 (1) |  | Non-Rule 10b5-1 (2) |  | Total Number of Shares of Common Stock to be Sold |  | Expiration Date |
| Daniel L. Boehle(Executive Vice President and CFO) |  | Adoption |  | February 24, 2026 |  | X |  |  |  | Indeterminable (3) |  | (4) |
| Thomas Clapprood(President, Interconnect Solutions Business Unit) |  | Adoption |  | February 27, 2026 |  | X |  |  |  | Indeterminable (3) |  | (4) |
| Robert Farrell(President, Communication and Computing Business Unit) |  | Adoption |  | February 25, 2026 |  | X |  |  |  | Indeterminable (3) |  | (4) |
| Gregory Fortier(Senior Vice President, Integrated Electronics Business Unit) |  | Adoption |  | February 27, 2026 |  | X |  |  |  | Indeterminable (3) |  | (4) |
| Catherine A. Gridley(Executive Vice President and President, Aerospace and Defense Sector) |  | Adoption |  | February 24, 2026 |  | X |  |  |  | Indeterminable (3) |  | (4) |
| Dale Knecht(Senior Vice President of Global Information Technology) |  | Adoption |  | February 24, 2026 |  | X |  |  |  | Indeterminable (3) |  | (4) |
| Shawn Powers(Executive Vice President and Chief Human Resources Officer) |  | Adoption |  | February 25, 2026 |  | X |  |  |  | Indeterminable (3) |  | (4) |

[0001193125-26-201403:notes:88]
| Name and Title |  | Action |  | Adoption / Termination Date |  | Rule 10b5-1 (1) |  | Non-Rule 10b5-1 (2) |  | Total Number of Shares of Common Stock to be Sold |  | Expiration Date |
| Edwin Roks(President, CEO, and Director) |  | Adoption |  | February 25, 2026 |  | X |  |  |  | Indeterminable (3) |  | (4) |
| Liz Romo(Chief Accounting Officer) |  | Adoption |  | February 24, 2026 |  | X |  |  |  | Indeterminable (3) |  | (4) |
| Douglas L. Soder(Executive Vice President and President, Commercial Sector) |  | Adoption |  | February 24, 2026 |  | X |  |  |  | Indeterminable (3) |  | (4) |
| James P. Walsh (Chief Operating Officer) |  | Adoption |  | February 24, 2026 |  | X |  |  |  | Indeterminable (3) |  | (4) |
| Daniel J. Weber(Executive Vice President, Chief Legal Officer and Secretary) |  | Adoption |  | February 26, 2026 |  | X |  |  |  | Indeterminable (3) |  | (4) |

[0001193125-26-201403:notes:89]
[same as prior period, unchanged from 0001193125-25-260708:notes:96]

[0001193125-26-201403:notes:90]
[same as prior period, unchanged from 0001193125-25-260708:notes:97]

[0001193125-26-201403:notes:91]
(3)
Rule 10b5-1 trading arrangement that is intended to provide for “eligible sell-to-cover transactions” (as described in Rule 10b5-1(c)(1)(ii)(D)(3) under the Exchange Act) to satisfy tax withholding obligations arising exclusively from vesting of RSUs or PRUs. The number of shares subject to covered RSUs or PRUs that will be sold to satisfy applicable tax withholding obligations upon vesting is not currently determinable as the number will vary based on the market price of our common stock and the extent to which vesting conditions are satisfied. This sell-to-cover arrangement provides solely for the automatic sale of shares that would otherwise be issuable in respect of a covered RSU or PRU in an amount sufficient to satisfy the applicable withholding obligation, with the proceeds of the sale delivered to the Company in satisfaction of the applicable withholding obligation.

[0001193125-26-201403:notes:92]
(4)
The duration of the trading arrangement is perpetual; provided, that the trading arrangement may expire if the officer terminates the trading arrangement in compliance with Rule 10b5-1 and Company policy, or upon certain other events outside of the officer’s control including, but not limited to, extraordinary corporate transactions or bankruptcy.
