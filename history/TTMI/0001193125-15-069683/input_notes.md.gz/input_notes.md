# TTMI notes — 0001193125-15-069683


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001193125-15-069683:notes:1]
| (13) | Commitments and Contingencies |

[0001193125-15-069683:notes:2]
Operating
 Leases

[0001193125-15-069683:notes:3]
The Company
 leases some of its manufacturing and assembly plants, a sales
 office and equipment under noncancellable operating leases that
 expire at various dates through 2020. Certain real property leases
 contain renewal provisions at the Company’s option. Most of
 the leases require the Company to pay for certain other costs such
 as property taxes and maintenance. Certain leases also contain rent
 escalation clauses (step rents) that require additional rental
 amounts in the later years of the term. Rent expense for leases
 with step rents is recognized on a straight-line basis over the
 minimum lease term.

[0001193125-15-069683:notes:4]
The following
 is a schedule of future minimum lease payments as of
 December 29, 2014:

[0001193125-15-069683:notes:5]
|  |  | Operating Leases |  |
|  |  | (In thousands) |  |
| 2015 |  | $ | 2,104 |  |
| 2016 |  |  | 1,454 |  |
| 2017 |  |  | 964 |  |
| 2018 |  |  | 681 |  |
| 2019 |  |  | 330 |  |
| Thereafter |  |  | 91 |  |
| Total minimum lease payments |  | $ | 5,624 |  |

[0001193125-15-069683:notes:6]
Total rent
 expense for the years ended 2014, 2013, and 2012 was approximately
 $3,731, $3,364 and $3,101, respectively.

[0001193125-15-069683:notes:7]
Legal
 Matters

[0001193125-15-069683:notes:8]
The Company is
 subject to various legal matters, which it considers normal for its
 business activities. While the Company currently believes that the
 amount of any reasonably possible or probable loss for known
 matters would not be material to the Company’s financial
 condition, the outcome of these actions is inherently difficult to
 predict. In the event of an adverse outcome, the ultimate potential
 loss could have a material adverse effect on the Company’s
 financial condition or results of operations in a particular
 period. The Company has accrued amounts for its loss contingencies
 which are probable and estimable as of December 29, 2014 and
 December 30, 2013. However, these amounts are not material to
 the consolidated financial statements of the Company.

[0001193125-15-069683:notes:9]
Class Action
 Complaints related to Viasystems Acquisition

[0001193125-15-069683:notes:10]
Since the
 public announcement on September 22, 2014 of the execution of
 the Merger Agreement, Viasystems, TTM, Merger Sub, and the members
 of the Viasystems Board have been named as defendants in two
 putative class action complaints challenging the Merger. The first
 lawsuit, filed in the Circuit Court of St. Louis County, Missouri
 on September 30, 2014 (the Missouri Lawsuit), and the second
 lawsuit, filed in the Court of Chancery of the State of Delaware on
 October 13, 2014 (the Delaware Lawsuit and, together with the
 Missouri Lawsuit, the Lawsuits), generally allege that the Merger
 fails to properly value Viasystems, that the individual defendants
 breached their fiduciary duties in approving the Merger Agreement,
 and that those breaches were aided and abetted by TTM, Merger Sub,
 and Viasystems.

[0001193125-15-069683:notes:11]
The Delaware
 Lawsuit specifically alleges, among other allegations, that
 (1) the Viasystems Board breached its fiduciary duties by:
 (a) agreeing to the Merger for grossly inadequate
 consideration, (b) agreeing to lock up the Merger with deal
 protection devices that prevent other bidders from making a
 successful competing offer for Viasystems, and
 (c) participating in a transaction where the loyalties of the
 Viasystems Board and management are divided; (2) the voting
 agreements entered into between the Company and certain of
 Viasystems’ significant stockholders prevent Viasystems
 stockholders from providing a meaningful vote on the proposal to
 adopt the Merger; and (3) that those breaches of fiduciary
 duties were aided and abetted by TTM, Merger Sub, and Viasystems.
 Further, the Missouri Lawsuit specifically alleges, among other
 allegations, that (1) the proposed Merger is unfair and the
 consideration to be paid in connection with the Merger is
 inadequate; (2) the Viasystems Board and Viasystems’
 management have a conflict of interest due to the cash pool bonus
 and change in control payments to be made to certain executive
 officers and key employees if the Merger is consummated; and
 (3) the Merger Agreement contains impermissible deal
 protection devices.

[0001193125-15-069683:notes:12]
The Lawsuits
 seek injunctive relief to enjoin the defendants from completing the
 Merger on the agreed-upon terms, rescinding, to the extent already
 implemented, the Merger Agreement or any of the terms therein,
 costs and disbursements and attorneys’ and experts’
 fees and costs, as well as other equitable relief as the respective
 court deems proper. The Delaware Lawsuit also seeks: (1) in
 the event the Merger is consummated prior to the entry of the
 court’s final judgment, rescissory damages as an alternative
 to rescission, and (2) an accounting by all defendants to the
 plaintiff and other members of the class for all damages caused by
 the defendants and for all profits and any special benefits
 obtained as a result of their alleged breaches of their fiduciary
 duties.

[0001193125-15-069683:notes:13]
On
 January 6, 2015, the parties to the Missouri Lawsuit entered
 into a Memorandum of Understanding (MOU) with respect to a proposed
 settlement that will terminate both Lawsuits upon entry of the
 final judgment. The parties are in the process of negotiating
 this settlement agreement. Pursuant to the MOU, the settlement
 agreement will provide for payment of attorneys’ fees and
 reimbursement of expenses, and releases of all claims and relief
 sought in both Lawsuits.

[0001193125-15-069683:notes:14]
Environmental Matters

[0001193125-15-069683:notes:15]
The process to
 manufacture PCBs requires adherence to city, county, state, federal
 and foreign environmental regulations regarding the storage, use,
 handling and disposal of chemicals, solid wastes and other
 hazardous materials, as well as compliance with air quality
 standards and chemical use reporting. The Company believes that its
 facilities in the United States comply in all material respects
 with applicable environmental laws and regulations. In China,
 governmental authorities have adopted new rules and regulations
 governing environmental issues. An update to Chinese
 environmental waste water law was issued in late 2012, but allows
 for an interim period in which plants subject to such law may
 install equipment that meets the new regulatory regime. The
 Company’s plants in China are not yet in full compliance with
 the newly adopted environmental regulations. The Company
 believes it has developed plans acceptable to the Chinese
 government and is in the process of implementing these plans. The
 Company does not anticipate any immediate risk of government fines
 or temporary closure of its Chinese plants. The Company has
 established and enacted an investment plan related to the efforts
 to come into full compliance with the new regulations. The 2015
 capital expenditure costs expected for these plans are included in
 the Company’s capital expenditure projections.


## us-gaap:EarningsPerSharePolicyTextBlock

[0001193125-15-069683:notes:16]
Earnings
 Per Share

[0001193125-15-069683:notes:17]
Basic earnings
 per common share excludes dilution and is computed by dividing net
 income attributable to TTM Technologies, Inc. stockholders by the
 weighted average number of common shares outstanding during the
 period. Diluted earnings per common share reflect the potential
 dilution that could occur if stock options or other common stock
 equivalents were exercised or converted into common stock. The
 dilutive effect of stock options or other common stock equivalents
 is calculated using the treasury stock method.


## us-gaap:EarningsPerShareTextBlock

[0001193125-15-069683:notes:18]
| (19) | Earnings Per Share |

[0001193125-15-069683:notes:19]
The following
 is a reconciliation of the numerator and denominator used to
 calculate basic earnings (loss) per share and diluted earnings
 (loss) per share for the years ended 2014, 2013 and
 2012:

[0001193125-15-069683:notes:20]
|  |  | For the Year Ended |  |
|  |  | December 29, 2014 |  |  | December 30, 2013 |  |  | December 31, 2012 |  |
|  |  | (In thousands, except per share amounts) |  |
| Net income (loss) attributable to TTM Technologies, Inc. stockholders |  | $ | 14,693 |  |  | $ | 21,877 |  |  | $ | (174,595 | ) |
| Weighted average shares outstanding |  |  | 83,238 |  |  |  | 82,506 |  |  |  | 81,800 |  |
| Dilutive effect of performance-based stock units, restricted stock units and stock options |  |  | 703 |  |  |  | 626 |  |  |  | — |  |
| Diluted shares |  |  | 83,941 |  |  |  | 83,132 |  |  |  | 81,800 |  |
| Earnings (loss) per share attributable to TTM Technologies, Inc. stockholders: |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  | $ | 0.18 |  |  | $ | 0.27 |  |  | $ | (2.13 | ) |
| Diluted |  | $ | 0.18 |  |  | $ | 0.26 |  |  | $ | (2.13 | ) |

[0001193125-15-069683:notes:21]
For the years
 ended December 29, 2014 and December 30, 2013, PRUs, RSUs
 and stock options to purchase 1,233 and 1,751 shares of common
 stock, respectively, were not considered in calculating diluted
 earnings per share because the options’ exercise prices or
 the total assumed proceeds under the treasury stock method for
 PRUs, RSUs or stock options was greater than the average market
 price of common shares during the applicable year and, therefore,
 the effect would be anti-dilutive.

[0001193125-15-069683:notes:22]
For the year
 ended December 31, 2012, potential shares of common stock,
 consisting of stock options to purchase approximately 1,151 shares
 of common stock at exercise prices ranging from $4.69 to $16.82 per
 share, 1,362 RSUs, and 267 PRUs were not included in the
 computation of diluted earnings per share because the Company
 incurred a net loss from operations and, as a result, the impact
 would be anti-dilutive.

[0001193125-15-069683:notes:23]
Additionally,
 for the years ended December 29, 2014, December 30,
 2013, and December 31, 2012, the effect of shares of common
 stock related to the Company’s convertible senior notes and
 warrants to purchase common stock were not included in the
 computation of dilutive earnings per share because the conversion
 price of the convertible senior notes and the strike price of the
 warrants to purchase the Company’s common stock were greater
 than the average market price of common shares during the
 applicable year, and therefore, the effect would be anti-dilutive
 and were as follows:

[0001193125-15-069683:notes:24]
|  |  | For the Year Ended |  |
|  |  | December 29, 2014 |  |  | December 30, 2013 |  |  | December 31, 2012 |  |
|  |  | (In thousands) |  |
| Common stock related to convertible senior notes |  |  | 27,970 |  |  |  | 25,265 |  |  |  | 10,963 |  |
| Warrants to purchase common stock |  |  | 28,020 |  |  |  | 23,654 |  |  |  | 10,963 |  |


## us-gaap:FairValueAssetsMeasuredOnNonrecurringBasisTextBlock

[0001193125-15-069683:notes:25]
For the years
 ended 2014, 2013 and 2012, the following assets were measured at
 fair value on a nonrecurring basis using the type of inputs
 shown:

[0001193125-15-069683:notes:26]
|  |  | Fair Value Measurements Using: |  |
|  |  | December 29, 2014 |  |  | Level 1 Inputs |  |  | Level 2 Inputs |  |  | Level 3 Inputs |  |  | Total Losses for the Year Ended December 29, 2014 |  |
|  |  | (In thousands) |  |
| Assets held for sale |  | $ | 21,031 |  |  |  | — |  |  | $ | 21,031 |  |  |  | — |  |  | $ | 1,845 |  |

[0001193125-15-069683:notes:27]
|  |  | Fair Value Measurements Using: |  |
|  |  | December 30, 2013 |  |  | Level 1 Inputs |  |  | Level 2 Inputs |  |  | Level 3 Inputs |  |  | Total Losses for the Year Ended December 30, 2013 |  |
|  |  | (In thousands) |  |
| Assets held for sale |  | $ | 2,519 |  |  |  | — |  |  | $ | 2,519 |  |  |  | — |  |  | $ | 10,782 |  |

[0001193125-15-069683:notes:28]
|  |  | Fair Value Measurements Using: |  |
|  |  | December 31, 2012 |  |  | Level 1 Inputs |  |  | Level 2 Inputs |  |  | Level 3 Inputs |  |  | Total Losses for the Year Ended December 31, 2012 |  |
|  |  | (In thousands) |  |
| Goodwill |  | $ | 12,120 |  |  |  | — |  |  |  | — |  |  | $ | 12,120 |  |  | $ | 171,400 |  |
| Definite-lived intangible assets |  |  | 36,984 |  |  |  | — |  |  |  | — |  |  |  | 36,984 |  |  |  | 28,935 |  |
| Long-lived assets |  |  | 38,100 |  |  |  | — |  |  | $ | 38,100 |  |  |  | — |  |  |  | 18,082 |  |
|  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | $ | 218,417 |  |


## us-gaap:InventoryPolicyTextBlock

[0001193125-15-069683:notes:29]
Inventories

[0001193125-15-069683:notes:30]
Inventories are
 stated at the lower of cost (determined on a first-in, first-out
 and weighted average basis) or market. Assessments to value the
 inventory at the lower of the actual cost to purchase
 and / or manufacture the inventory, or the current
 estimated market value of the inventory, are based upon assumptions
 about future demand and market conditions. As a result of the
 Company’s assessments, when the market value of inventory is
 less than the carrying value, the inventory cost is written down to
 the market value and the write down is recorded as a charge to cost
 of goods sold.


## us-gaap:ReconciliationOfAssetsFromSegmentToConsolidatedTextBlock

[0001193125-15-069683:notes:31]
|  |  | As of |  |
|  |  | December 29, 2014 |  |  | December 30, 2013 |  |  | December 31, 2012 |  |
|  |  | (In thousands) |  |
| Segment Assets: |  |  |  |  |  |  |  |  |  |  |  |  |
| Asia Pacific |  | $ | 1,098,496 |  |  | $ | 1,134,325 |  |  | $ | 1,207,206 |  |
| North America |  |  | 502,793 |  |  |  | 539,102 |  |  |  | 469,366 |  |
| Unallocated corporate assets |  |  | — |  |  |  | 148 |  |  |  | 390 |  |
| Total assets |  | $ | 1,601,289 |  |  | $ | 1,673,575 |  |  | $ | 1,676,962 |  |


## us-gaap:ScheduleOfDerivativeInstrumentsTextBlock

[0001193125-15-069683:notes:32]
The fair values
 of derivative instruments in the consolidated balance sheet are as
 follows:

[0001193125-15-069683:notes:33]
|  |  |  |  | Asset / (Liability) Fair Value as of |  |
|  |  | Balance Sheet Location |  | December 29, 2014 |  |  | December 30, 2013 |  |
|  |  |  |  | (In thousands) |  |
| Cash flow derivative instruments designated as hedges: |  |  |  |  |  |  |  |  |  |  |
| Foreign exchange contracts |  | Other accrued expenses |  | $ | (12 | ) |  | $ | (751 | ) |
| Foreign exchange contracts |  | Deposits and other non-current assets |  |  | — |  |  |  | 10 |  |
| Cash flow derivative instruments not designated as hedges: |  |  |  |  |  |  |  |  |  |  |
| Foreign exchange contracts |  | Prepaid expenses and other current assets |  |  | — |  |  |  | 647 |  |
| Foreign exchange contracts |  | Other accrued expenses |  |  | (5,050 | ) |  |  | (899 | ) |
| Foreign exchange contracts |  | Other long-term liabilities |  |  | — |  |  |  | (1,288 | ) |
|  |  |  |  | $ | (5,062 | ) |  | $ | (2,281 | ) |


## us-gaap:ScheduleOfEffectiveIncomeTaxRateReconciliationTableTextBlock

[0001193125-15-069683:notes:34]
The following
 is a reconciliation between the statutory federal income tax rates
 and the Company’s effective income tax rates for the years
 ended 2014, 2013, and 2012, which are derived by dividing the
 income tax (provision) benefit by the income (loss) before income
 taxes:

[0001193125-15-069683:notes:35]
|  |  | For the Year Ended |  |
|  |  | December 29, 2014 |  |  | December 30, 2013 |  |  | December 31, 2012 |  |
| Statutory federal income tax rate |  |  | (34.0 | )% |  |  | (34.0 | )% |  |  | (34.0 | )% |
| State income taxes, net of federal benefit and state tax credits |  |  | (0.4 | ) |  |  | 2.2 |  |  |  | 0.2 |  |
| Foreign tax differential on foreign earnings |  |  | (28.0 | ) |  |  | (9.5 | ) |  |  | 2.7 |  |
| Change in valuation allowance |  |  | 23.9 |  |  |  | (6.0 | ) |  |  | 4.9 |  |
| Federal research and development credits |  |  | 4.6 |  |  |  | 6.0 |  |  |  | — |  |
| Loss on extinguishment of debt |  |  | — |  |  |  | 2.6 |  |  |  | — |  |
| Nondeductible goodwill impairment |  |  | — |  |  |  | — |  |  |  | 34.6 |  |
| Domestic production activities deduction |  |  | — |  |  |  | — |  |  |  | (0.2 | ) |
| Other |  |  | (0.2 | ) |  |  | (1.2 | ) |  |  | (0.6 | ) |
| Total provision for income taxes |  |  | (34.1 | )% |  |  | (39.9 | )% |  |  | 7.6 | % |


## us-gaap:ScheduleOfFairValueAssetsAndLiabilitiesMeasuredOnRecurringBasisTableTextBlock

[0001193125-15-069683:notes:36]
As of
 December 29, 2014 and December 30, 2013, the following
 financial assets and liabilities were measured at fair value on a
 recurring basis using the type of inputs shown:

[0001193125-15-069683:notes:37]
|  |  |  |  |  | Fair Value Measurements Using: |  |
|  |  | As of December 29, 2014 |  |  | Level 1 Inputs |  |  | Level 2 Inputs |  |  | Level 3 Inputs |  |
|  |  | (In thousands) |  |
| Money market funds |  | $ | 129,012 |  |  | $ | 129,012 |  |  |  | — |  |  |  | — |  |
| Foreign exchange derivative liabilities |  |  | 5,062 |  |  |  | — |  |  | $ | 5,062 |  |  |  | — |  |

[0001193125-15-069683:notes:38]
|  |  |  |  |  | Fair Value Measurements Using: |  |
|  |  | As of December 30, 2013 |  |  | Level 1 Inputs |  |  | Level 2 Inputs |  |  | Level 3 Inputs |  |
|  |  | (In thousands) |  |
| Money market funds |  | $ | 23,838 |  |  | $ | 23,838 |  |  |  | — |  |  |  | — |  |
| Available for sale securities |  |  | 148 |  |  |  | 148 |  |  |  | — |  |  |  | — |  |
| Foreign exchange derivative assets |  |  | 657 |  |  |  | — |  |  | $ | 657 |  |  |  | — |  |
| Foreign exchange derivative liabilities |  |  | 2,938 |  |  |  | — |  |  |  | 2,938 |  |  |  | — |  |


## us-gaap:ScheduleOfRevenuesFromExternalCustomersAndLongLivedAssetsByGeographicalAreasTableTextBlock

[0001193125-15-069683:notes:39]
Net sales and
 long-lived assets are as follows:

[0001193125-15-069683:notes:40]
|  |  | 2014 |  |  | 2013 |  |  | 2012 |  |
|  |  | Net Sales |  |  | Long-Lived Assets |  |  | Net Sales |  |  | Long-Lived Assets |  |  | Net Sales |  |  | Long-Lived Assets |  |
|  |  | (In thousands) |  |
| United States |  | $ | 568,796 |  |  | $ | 103,340 |  |  | $ | 571,046 |  |  | $ | 95,672 |  |  | $ | 489,566 |  |  | $ | 93,080 |  |
| China |  |  | 352,385 |  |  |  | 682,739 |  |  |  | 391,905 |  |  |  | 754,781 |  |  |  | 431,157 |  |  |  | 789,702 |  |
| Other |  |  | 404,536 |  |  |  | — |  |  |  | 405,264 |  |  |  | — |  |  |  | 427,945 |  |  |  | — |  |
| Total |  | $ | 1,325,717 |  |  | $ | 786,079 |  |  | $ | 1,368,215 |  |  | $ | 850,453 |  |  | $ | 1,348,668 |  |  | $ | 882,782 |  |


## us-gaap:ScheduleOfShareBasedCompensationRestrictedStockUnitsAwardActivityTableTextBlock

[0001193125-15-069683:notes:41]
RSU activity
 for the year ended December 29, 2014 was as
 follows:

[0001193125-15-069683:notes:42]
|  |  | Shares |  |  | Weighted Average Grant-Date Fair Value |  |
|  |  | (In thousands) |  |  |  |  |
| Non-vested RSUs outstanding at December 30, 2013 |  |  | 1,327 |  |  | $ | 10.22 |  |
| Granted |  |  | 845 |  |  |  | 7.98 |  |
| Vested |  |  | (638 | ) |  |  | 11.27 |  |
| Forfeited |  |  | (98 | ) |  |  | 8.69 |  |
| Non-vested RSUs outstanding at December 29, 2014 |  |  | 1,436 |  |  | $ | 8.54 |  |
| Vested and expected to vest at December 29, 2014 |  |  | 1,627 |  |  | $ | 8.83 |  |


## us-gaap:ScheduleOfShareBasedPaymentAwardStockOptionsValuationAssumptionsTableTextBlock

[0001193125-15-069683:notes:43]
For the years
 ended 2014, 2013 and 2012, the following assumptions were used in
 determining the fair value:

[0001193125-15-069683:notes:44]
|  |  | For the Year Ended |  |
|  |  | December 29, 2014(1) |  |  | December 30, 2013(2) |  |  | December 31, 2012(3) |  |
| Weighted-average fair value |  | $ | 5.80 |  |  | $ | 6.79 |  |  | $ | 12.51 |  |
| Risk-free interest rate |  |  | 0.4 | % |  |  | 0.3 | % |  |  | 0.3 | % |
| Dividend yield |  |  | — |  |  |  | — |  |  |  | — |  |
| Expected volatility |  |  | 41 | % |  |  | 49 | % |  |  | 55 | % |
| Expected term in months |  |  | 23 |  |  |  | 25 |  |  |  | 23 |  |

[0001193125-15-069683:notes:45]
| (1) | Reflects the weighted-averages for the third year of the three-year performance period applicable to PRUs granted in 2012, the second year of the three-year performance period applicable to PRUs granted in 2013 and the first year of the three-year performance period applicable to PRUs granted in 2014. |

[0001193125-15-069683:notes:46]
| (2) | Reflects the weighted-averages for the third year of the three-year performance period applicable to PRUs granted in 2011, second year of the three-year performance period applicable to PRUs granted in 2012 and for the first year of the three-year performance period applicable to PRUs granted in 2013. |

[0001193125-15-069683:notes:47]
| (3) | Reflects the weighted-averages for the third year of the three-year performance period applicable to PRUs granted in 2010, second year of the three-year performance period applicable to PRUs granted in 2011 and for the first year of the three-year performance period applicable to PRUs granted in 2012. |


## us-gaap:AllowanceForCreditLossesOnFinancingReceivablesTableTextBlock

[0001193125-15-069683:notes:48]
The following
 summarizes the activity in the Company’s allowance for
 doubtful accounts for the years ended 2014, 2013 and
 2012:

[0001193125-15-069683:notes:49]
|  |  | For the Year Ended |  |
|  |  | December 29, 2014 |  |  | December 30, 2013 |  |  | December 31, 2012 |  |
|  |  | (In thousands) |  |
| Balance at beginning of year |  | $ | 518 |  |  | $ | 1,680 |  |  | $ | 1,294 |  |
| Additions charged to (reversals of) expense |  |  | 214 |  |  |  | (157 | ) |  |  | 648 |  |
| Sale of a majority owned subsidiary |  |  | — |  |  |  | (459 | ) |  |  | — |  |
| Deductions |  |  | (34 | ) |  |  | (554 | ) |  |  | (275 | ) |
| Effect of foreign currency exchange rates |  |  | (2 | ) |  |  | 8 |  |  |  | 13 |  |
| Balance at end of year |  | $ | 696 |  |  | $ | 518 |  |  | $ | 1,680 |  |


## us-gaap:CompensationRelatedCostsPolicyTextBlock

[0001193125-15-069683:notes:50]
Stock-Based Compensation

[0001193125-15-069683:notes:51]
The Company
 recognizes stock-based compensation expense in its consolidated
 financial statements for its incentive compensation plan
 awards.

[0001193125-15-069683:notes:52]
The incentive
 compensation plan awards include performance-based restricted stock
 units, restricted stock units, and stock options and the associated
 compensation expense is based on the grant date fair value of the
 awards, net of estimated forfeitures, as well as an assessment of
 probability of the performance-based awards vesting. Compensation
 expense for the incentive compensation plan awards is recognized on
 a straight line basis over the vesting period of the awards. The
 fair value of performance-based restricted stock units is estimated
 on the grant date using a Monte Carlo simulation model based on the
 underlying common stock closing price as of the date of grant, the
 expected term, stock price volatility, and risk-free interest
 rates. The fair value of restricted stock units is measured on the
 grant date based on the quoted closing market price of the
 Company’s common stock. The fair value of the stock options
 is estimated on the grant date using the Black-Scholes option
 pricing model based on the underlying common stock closing price as
 of the date of grant, the expected term, stock price volatility,
 and risk-free interest rates.


## us-gaap:ComprehensiveIncomePolicyPolicyTextBlock

[0001193125-15-069683:notes:53]
Comprehensive Income

[0001193125-15-069683:notes:54]
Comprehensive
 income includes changes to equity accounts that were not the result
 of transactions with stockholders. Comprehensive income is
 comprised of net income (loss), changes in the cumulative foreign
 currency translation adjustments and realized and unrealized gains
 or losses on hedged derivative instruments and available for sale
 securities.


## us-gaap:ConcentrationRiskDisclosureTextBlock

[0001193125-15-069683:notes:55]
| (11) | Significant Customers and Concentration of Credit Risk |

[0001193125-15-069683:notes:56]
In the normal
 course of business, the Company extends credit to its customers,
 which are concentrated primarily in the computer and networking,
 communications and aerospace and defense industries. Most customers
 to which the Company extends credit are located outside the United
 States, with the exception of certain customers in the aerospace
 and defense industries. The Company performs ongoing credit
 evaluations of customers, does not require collateral and considers
 the credit risk profile of the entity from which the receivable is
 due in further evaluating collection risk.

[0001193125-15-069683:notes:57]
The
 Company’s customers include both OEMs and EMS companies. The
 Company’s OEM customers often direct a significant portion of
 their purchases through EMS companies. While the Company’s
 customers include both OEM and EMS providers, the Company measures
 customer concentration based on OEM companies, as they are the
 ultimate end customers.

[0001193125-15-069683:notes:58]
For the years
 ended 2014, 2013 and 2012, one customer accounted for approximately
 21%, 20% and 14%, respectively, of the Company’s net sales.
 There were no other customers that accounted for 10% or more
 of net sales for the years ended 2014, 2013 and 2012.


## us-gaap:CommitmentsAndContingenciesPolicyTextBlock

[0001193125-15-069683:notes:59]
Loss
 Contingencies

[0001193125-15-069683:notes:60]
The Company
 establishes an accrual for an estimated loss contingency when it is
 both probable that an asset has been impaired or that a liability
 has been incurred and the amount of the loss can be reasonably
 estimated. Any legal fees expected to be incurred in connection
 with a contingency are expensed as incurred.


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0001193125-15-069683:notes:61]
| (4) | Goodwill and Definite-lived Intangibles |

[0001193125-15-069683:notes:62]
Goodwill

[0001193125-15-069683:notes:63]
As of
 December 29, 2014 and December 30, 2013 goodwill was as
 follows:

[0001193125-15-069683:notes:64]
|  |  | Total |  |
|  |  | (In thousands) |  |
| Balance as of December 31, 2012 |  |  |  |  |
| Goodwill |  | $ | 183,520 |  |
| Accumulated impairment losses |  |  | (171,400 | ) |
|  |  |  | 12,120 |  |
| Impairment losses during the year |  |  | — |  |
| Foreign currency translation adjustment during the year |  |  | — |  |
| Balance as of December 30, 2013 |  |  |  |  |
| Goodwill |  |  | 183,520 |  |
| Accumulated impairment losses |  |  | (171,400 | ) |
|  |  |  | 12,120 |  |
| Impairment losses during the year |  |  | — |  |
| Foreign currency translation adjustment during the year |  |  | (9 | ) |
| Balance as of December 29, 2014 |  |  |  |  |
| Goodwill |  |  | 183,511 |  |
| Accumulated impairment losses |  |  | (171,400 | ) |
|  |  | $ | 12,111 |  |

[0001193125-15-069683:notes:65]
Goodwill
 balances include foreign currency translation adjustments related
 to foreign subsidiaries which operate in currencies other than the
 U.S. Dollar. All of the Company’s remaining goodwill is
 included as a component of the Asia Pacific operating segment,
 which is also a reporting unit.

[0001193125-15-069683:notes:66]
During the
 fourth quarter of 2014, the Company performed the required annual
 goodwill impairment analysis, which was based on a combination of
 the income approach utilizing discounted cash flow analysis and the
 market approach, and concluded that the Asia Pacific reporting
 unit’s goodwill was not impaired. The excess of fair value
 over carrying value of the Asia Pacific reporting unit’s
 equity as of December 29, 2014, the annual testing date, was
 approximately 28.2% of carrying value.

[0001193125-15-069683:notes:67]
The key
 variables that drive the projected cash flow of the reporting unit
 are estimated revenue growth rates, levels of profitability, the
 terminal value growth rate assumption, and the weighted average
 cost of capital (WACC) rate applied. These assumptions are subject
 to uncertainty, including the ability to increase revenue and
 improve profitability levels. For the remaining $12,111 of Asia
 Pacific reporting unit goodwill as of December 29, 2014, a
 decline in future performance and cash flow or a small change in
 other key assumptions, including increases to its WACC, may result
 in the recognition of a goodwill impairment charge. For example,
 keeping all other variables constant, a 330 basis point increase in
 the WACC applied would require that the Company perform the second
 step of the goodwill impairment test. In addition, keeping all
 other variables constant, a more than 663 basis point decrease in
 terminal value growth rates would require that the Company perform
 the second step of the goodwill impairment test.

[0001193125-15-069683:notes:68]
The Company
 will continue to evaluate its goodwill on an annual basis during
 its fourth fiscal quarter and whenever events or changes in
 circumstances — such as significant adverse changes in
 business climate or operating results, changes in management
 strategy, coupled with a decline in the market price of our stock
 and market capitalization — indicate that there may be a
 potential impairment. If factors indicate that assets are impaired,
 we would be required to reduce the carrying value of our goodwill
 and definite-lived intangible assets, which may result in an
 impairment charge.

[0001193125-15-069683:notes:69]
During an
 interim period of 2012, the Company performed an evaluation of
 goodwill as the Company believed there were impairment triggering
 events and circumstances which warranted an evaluation. Given the
 triggering events and circumstances, the Company performed step one
 of the impairment test for goodwill and determined that the fair
 value of the Asia Pacific operating segment, which was based on a
 combination of discounted cash flow analysis and market approach,
 was lower than the carrying value.

[0001193125-15-069683:notes:70]
The failure of
 step one of the goodwill impairment test triggered a step two
 impairment analysis. As a result of that analysis, an impairment
 charge of $171,400 for goodwill was recognized during the year
 ended 2012.

[0001193125-15-069683:notes:71]
Definite-lived Intangibles

[0001193125-15-069683:notes:72]
As of
 December 29, 2014 and December 30, 2013, the components
 of definite-lived intangibles were as follows:

[0001193125-15-069683:notes:73]
|  |  | Gross Amount |  |  | Accumulated Amortization |  |  | Accumulated Impairment |  |  | Foreign Currency Translation Adjustment |  |  | Net Carrying Amount |  |  | Weighted Average Amortization Period |  |
|  |  | (In thousands) |  |  | (years) |  |
| December 29, 2014: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Strategic customer relationships |  | $ | 120,427 |  |  | $ | (74,486 | ) |  | $ | (28,935 | ) |  | $ | 445 |  |  | $ | 17,451 |  |  |  | 9.2 |  |
| Trade name |  |  | 10,302 |  |  |  | (8,520 | ) |  |  | — |  |  |  | 17 |  |  |  | 1,799 |  |  |  | 6.0 |  |
|  |  | $ | 130,729 |  |  | $ | (83,006 | ) |  | $ | (28,935 | ) |  | $ | 462 |  |  | $ | 19,250 |  |  |  |  |  |
| December 30, 2013: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Strategic customer relationships |  | $ | 120,427 |  |  | $ | (67,895 | ) |  | $ | (28,935 | ) |  | $ | 463 |  |  | $ | 24,060 |  |  |  | 9.2 |  |
| Trade name |  |  | 10,302 |  |  |  | (6,719 | ) |  |  | — |  |  |  | 18 |  |  |  | 3,601 |  |  |  | 6.0 |  |
|  |  | $ | 130,729 |  |  | $ | (74,614 | ) |  | $ | (28,935 | ) |  | $ | 481 |  |  | $ | 27,661 |  |  |  |  |  |

[0001193125-15-069683:notes:74]
The
 December 29, 2014 and December 30, 2013 definite-lived
 intangible balances include foreign currency translation
 adjustments related to foreign subsidiaries which operate in
 currencies other than the U.S. Dollar.

[0001193125-15-069683:notes:75]
In conjunction
 with interim evaluation of goodwill in 2012, the Company also
 performed an evaluation of definite-lived intangibles as the
 Company believed there were impairment triggering events and
 circumstances which warranted an evaluation. Based on the
 undiscounted cash flows for the Asia Pacific operating segment, the
 Company determined that the carrying amounts were not recoverable.
 In performing the impairment test for definite-lived intangibles,
 the Company recorded a charge in the amount of $28,935 for the year
 ended December 31, 2012 to reduce the carrying value of
 strategic customer relationships in the Asia Pacific operating
 segment to fair value, which was determined using the discounted
 cash flow method.

[0001193125-15-069683:notes:76]
Definite-lived
 intangibles are generally amortized using the straight line method
 of amortization over the useful life, with the exception of the
 strategic customer relationship intangibles, which are amortized
 using an accelerated method of amortization based on estimated cash
 flows. Amortization expense was $8,387, $9,332 and, $14,684 for the
 years ended 2014, 2013 and 2012, respectively. Amortization expense
 related to acquired licensing agreements is classified as cost of
 goods sold.

[0001193125-15-069683:notes:77]
Estimated
 aggregate amortization for definite-lived intangible assets for the
 next five years is as follows:

[0001193125-15-069683:notes:78]
|  |  | (In thousands) |  |
| 2015 |  | $ | 7,487 |  |
| 2016 |  |  | 4,124 |  |
| 2017 |  |  | 3,901 |  |
| 2018 |  |  | 3,738 |  |
| 2019 |  |  | — |  |
|  |  | $ | 19,250 |  |


## us-gaap:IncomeTaxPolicyTextBlock

[0001193125-15-069683:notes:79]
Income
 Taxes

[0001193125-15-069683:notes:80]
Income taxes
 are accounted for under the asset and liability method. Deferred
 income tax assets or liabilities are recognized for the future tax
 consequences attributable to differences between the financial
 statement carrying amounts of assets and liabilities and their
 respective tax basis and operating loss and tax credit
 carryforwards. Deferred income tax assets and liabilities are
 measured using enacted tax rates expected to apply to taxable
 income in the years in which those temporary differences are
 expected to be settled or realized. The effect on deferred income
 tax assets and liabilities of a change in tax rates is recognized
 in income in the period that includes the enactment date. Deferred
 income tax assets are reviewed for recoverability, and the Company
 records a valuation allowance to reduce its deferred income tax
 assets when it is more likely than not that all or some portion of
 the deferred income tax assets will not be realized.

[0001193125-15-069683:notes:81]
The Company has
 various foreign subsidiaries formed or acquired to conduct or
 support its business outside the United States. The Company does
 not provide for U.S. income taxes on undistributed earnings
 for its Asia Pacific operating segment as management expects the
 foreign earnings will be indefinitely reinvested in such foreign
 jurisdictions. For certain subsidiaries within the Asia Pacific
 operating segment, indefinite investment of undistributed earnings
 has not been asserted between the respective subsidiaries and their
 foreign parent entity and therefore, a deferred tax liability for
 the foreign tax impacts has been recorded on the undistributed
 earnings of these subsidiaries. For the Company’s backplane
 assembly plant in Shanghai, China, which is managed in conjunction
 with the Company’s U.S. operations, earnings are expected to
 be repatriated and therefore the Company has provided U.S. income
 taxes on these undistributed earnings.

[0001193125-15-069683:notes:82]
The Company
 recognizes the effect of income tax positions only if those
 positions are more likely than not of being sustained. Recognized
 income tax positions are measured at the largest amount that is
 greater than 50 percent likely to be realized. Changes in
 recognition or measurement are reflected in the period in which the
 change in judgment occurs. Estimated interest and penalties related
 to underpayment of income taxes are recorded as a component of
 income tax provision in the consolidated statement of
 operations.


## us-gaap:ScheduleOfIncomeBeforeIncomeTaxDomesticAndForeignTableTextBlock

[0001193125-15-069683:notes:83]
The components
 of income before income taxes for the years ended 2014, 2013 and
 2012 are:

[0001193125-15-069683:notes:84]
|  |  | For the Year Ended |  |
|  |  | December 29, 2014 |  |  | December 30, 2013 |  |  | December 31, 2012 |  |
|  |  | (In thousands) |  |
| United States |  | $ | (3,201 | ) |  | $ | (2,247 | ) |  | $ | 20,827 |  |
| Foreign |  |  | 25,492 |  |  |  | 42,019 |  |  |  | (189,199 | ) |
| Income (loss) before income taxes |  | $ | 22,291 |  |  | $ | 39,772 |  |  | $ | (168,372 | ) |


## us-gaap:ScheduleOfShareBasedCompensationStockOptionsActivityTableTextBlock

[0001193125-15-069683:notes:85]
Option activity
 under the Plan for the year ended December 29, 2014 was as
 follows:

[0001193125-15-069683:notes:86]
|  |  | Options |  |  | Weighted- Average Exercise Price |  |  | Weighted- Average Remaining Contractual Term |  |  | Aggregate Intrinsic Value |  |
|  |  | (In thousands) |  |  |  |  |  | (In years) |  |  | (In thousands) |  |
| Outstanding at December 30, 2013 |  |  | 597 |  |  | $ | 11.34 |  |  |  | 3.2 |  |  |  |  |  |
| Granted |  |  | — |  |  |  | — |  |  |  |  |  |  |  |  |  |
| Exercised |  |  | — |  |  |  | — |  |  |  |  |  |  |  |  |  |
| Forfeited/expired |  |  | (86 | ) |  |  | 10.14 |  |  |  |  |  |  |  |  |  |
| Outstanding at December 29, 2014 |  |  | 511 |  |  | $ | 11.54 |  |  |  | 2.3 |  |  | $ | 38 |  |
| Vested and expected to vest at December 29, 2014 |  |  | 511 |  |  | $ | 11.54 |  |  |  | 2.3 |  |  | $ | 38 |  |
| Exercisable at December 29, 2014 |  |  | 511 |  |  | $ | 11.54 |  |  |  | 2.3 |  |  | $ | 38 |  |


## us-gaap:SegmentReportingDisclosureTextBlock

[0001193125-15-069683:notes:87]
| (18) | Segment Information |

[0001193125-15-069683:notes:88]
The operating
 segments reported below are the Company’s segments for which
 separate financial information is available and upon which
 operating results are evaluated by the chief operating decision
 maker to assess performance and to allocate resources. The Company
 manages its worldwide operations based on two geographic operating
 segments: 1) Asia Pacific, which consists of five PCB fabrication
 plants, and 2) North America, which consists of seven domestic PCB
 fabrication plants, including a facility that provides follow-on
 value-added services primarily for one of the PCB fabrication
 plants, and one backplane assembly plant in Shanghai, China, which
 is managed in conjunction with the Company’s U.S. operations.
 Each segment operates predominantly in the same industry with
 production facilities that produce customized products for its
 customers and use similar means of product distribution.

[0001193125-15-069683:notes:89]
The Company
 evaluates segment performance based on operating segment income,
 which is operating income before amortization of intangibles.
 Interest expense and interest income are not presented by segment
 since they are not included in the measure of segment profitability
 reviewed by the chief operating decision maker. All inter-segment
 transactions have been eliminated. Reportable segment assets
 exclude short-term investments, which are managed
 centrally.

[0001193125-15-069683:notes:90]
|  |  | For the Year Ended |  |
|  |  | December 29, 2014 |  |  | December 30, 2013 |  |  | December 31, 2012 |  |
|  |  | (In thousands) |  |
| Net Sales: |  |  |  |  |  |  |  |  |  |  |  |  |
| Asia Pacific |  | $ | 811,107 |  |  | $ | 850,322 |  |  | $ | 842,443 |  |
| North America |  |  | 516,670 |  |  |  | 520,802 |  |  |  | 509,426 |  |
| Total sales |  |  | 1,327,777 |  |  |  | 1,371,124 |  |  |  | 1,351,869 |  |
| Inter-segment sales |  |  | (2,060 | ) |  |  | (2,909 | ) |  |  | (3,201 | ) |
| Total net sales |  | $ | 1,325,717 |  |  | $ | 1,368,215 |  |  | $ | 1,348,668 |  |
| Operating Segment Income (Loss): |  |  |  |  |  |  |  |  |  |  |  |  |
| Asia Pacific |  | $ | 39,239 |  |  | $ | 53,317 |  |  | $ | (165,183 | ) |
| North America |  |  | 15,687 |  |  |  | 25,143 |  |  |  | 37,803 |  |
| Total operating segment income (loss) |  |  | 54,926 |  |  |  | 78,460 |  |  |  | (127,380 | ) |
| Amortization of definite-lived intangibles |  |  | (8,387 | ) |  |  | (9,332 | ) |  |  | (14,637 | ) |
| Total operating income (loss) |  |  | 46,539 |  |  |  | 69,128 |  |  |  | (142,017 | ) |
| Total other expense, net |  |  | (24,248 | ) |  |  | (29,356 | ) |  |  | (26,355 | ) |
| Income (loss) before income taxes |  | $ | 22,291 |  |  | $ | 39,772 |  |  | $ | (168,372 | ) |
| Depreciation Expense: |  |  |  |  |  |  |  |  |  |  |  |  |
| Asia Pacific |  | $ | 78,925 |  |  | $ | 75,374 |  |  | $ | 67,790 |  |
| North America |  |  | 16,424 |  |  |  | 16,746 |  |  |  | 16,496 |  |
| Total depreciation expense |  | $ | 95,349 |  |  | $ | 92,120 |  |  | $ | 84,286 |  |
| Capital Expenditures: |  |  |  |  |  |  |  |  |  |  |  |  |
| Asia Pacific |  | $ | 51,236 |  |  | $ | 106,300 |  |  | $ | 142,424 |  |
| North America |  |  | 25,546 |  |  |  | 21,971 |  |  |  | 18,130 |  |
| Total capital expenditures |  | $ | 76,782 |  |  | $ | 128,271 |  |  | $ | 160,554 |  |

[0001193125-15-069683:notes:91]
The Company
 accounts for inter-segment sales and transfers as if the sale or
 transfer were to third parties: at arms length and consistent with
 the Company’s revenue recognition policy. The inter-segment
 sales are sales from the Asia Pacific operating segment to the
 North America operating segment.

[0001193125-15-069683:notes:92]
During the
 years ended 2014, 2013 and 2012, the Company recorded impairment
 charges of $1,845, $10,782 and $18,082, respectively, for the
 impairment of long-lived assets related to its Asia Pacific
 operating segment. During the year ended December 31, 2012,
 the Company recorded an impairment charge for goodwill and
 definite-lived intangibles of $200,335 related to its Asia Pacific
 operating segment.

[0001193125-15-069683:notes:93]
See Note 4 for additional information regarding the
 impairment of goodwill and definite-lived intangibles and Note 5
 for additional information regarding the impairment of long-lived
 assets.

[0001193125-15-069683:notes:94]
The Company
 markets and sells its products in approximately 41 countries. Other
 than in the United States and China, the Company does not conduct
 business in any country in which its net sales in that country
 exceed 10% of the Company’s total net sales. Net sales and
 long-lived assets are as follows:

[0001193125-15-069683:notes:95]
Net sales are attributed to countries by country
 invoiced.


## us-gaap:RelatedPartyTransactionsDisclosureTextBlock

[0001193125-15-069683:notes:96]
| (21) | Related Party Transactions |

[0001193125-15-069683:notes:97]
In the normal course of business, the Company’s foreign
 subsidiaries purchase laminate and prepreg from related parties in
 which a significant shareholder of the Company holds an equity
 interest. For the years ended 2014, 2013 and 2012, the
 Company’s foreign subsidiaries purchased $47,446, $62,648 and
 $90,603, respectively, of laminate and prepreg from these related
 parties.

[0001193125-15-069683:notes:98]
As mentioned above in Note 20, the Company completed its sale
 of SYE during 2013. Sales to SYE for years ended December 29,
 2014 and December 30, 2013 were $24,120 and $29,616,
 respectively. Additionally, purchases from SYE for the year ended
 December 29, 2014 were approximately $1,671. There were no
 purchases from SYE for year ended December 30,
 2013.

[0001193125-15-069683:notes:99]
As of December 29, 2014 and December 30, 2013, the
 Company’s consolidated balance sheet included $17,950 and
 $19,547, respectively, in accounts payable due to, and $4,934 and
 $13,312, respectively, in accounts receivable due from a related
 party for the purchase of laminate and prepreg, and sales of PCBs
 to SYE, respectively, as mentioned above.


## us-gaap:ScheduleOfEmployeeServiceShareBasedCompensationAllocationOfRecognizedPeriodCostsTextBlock

[0001193125-15-069683:notes:100]
For the years
 ended 2014, 2013 and 2012, the amounts recognized in the
 consolidated financial statements with respect to the stock-based
 compensation plan are as follows:

[0001193125-15-069683:notes:101]
|  |  | For the Year Ended |  |
|  |  | December 29, 2014 |  |  | December 30, 2013 |  |  | December 31, 2012 |  |
|  |  | (In thousands) |  |
| Cost of goods sold |  | $ | 866 |  |  | $ | 1,059 |  |  | $ | 1,094 |  |
| Selling and marketing |  |  | 1,109 |  |  |  | 1,308 |  |  |  | 471 |  |
| General and administrative |  |  | 5,825 |  |  |  | 6,618 |  |  |  | 8,701 |  |
| Stock-based compensation expense recognized |  |  | 7,800 |  |  |  | 8,985 |  |  |  | 10,266 |  |
| Income tax benefit recognized |  |  | (2,018 | ) |  |  | (2,274 | ) |  |  | (2,482 | ) |
| Total stock-based compensation expense after income taxes |  | $ | 5,782 |  |  | $ | 6,711 |  |  | $ | 7,784 |  |


## us-gaap:RevenueRecognitionPolicyTextBlock

[0001193125-15-069683:notes:102]
Revenue
 Recognition

[0001193125-15-069683:notes:103]
The Company
 derives its revenue primarily from the sale of PCBs using customer
 supplied engineering and design plans and recognizes revenue when:
 (i) persuasive evidence of a sales arrangement exists,
 (ii) the sales terms are fixed or determinable,
 (iii) title and risk of loss have transferred, and
 (iv) collectability is reasonably assured — generally
 when products are shipped to the customer, except in situations in
 which title passes upon receipt of the products by the customer. In
 this case, revenues are recognized upon notification that customer
 receipt has occurred. The Company does not have customer acceptance
 provisions, but it does provide its customers a limited right of
 return for defective PCBs. The Company accrues an estimated amount
 for sales returns and allowances related to defective PCBs at the
 time of sale based on its ability to estimate sales returns and
 allowances using current and historical information. The reserve
 for sales returns and allowances is included as a reduction to
 revenue and accounts receivable, net. Shipping and handling fees
 and related freight costs and supplies associated with shipping
 products to customers are included as a component of cost of goods
 sold. Incremental warranty costs that are not related to sales
 returns are recorded in cost of goods sold.

[0001193125-15-069683:notes:104]
The following
 summarizes the activity in the Company’s allowance for sales
 returns and allowances for the years ended 2014, 2013 and
 2012:

[0001193125-15-069683:notes:105]
|  |  | For the Year Ended |  |
|  |  | December 29, 2014 |  |  | December 30, 2013 |  |  | December 31, 2012 |  |
|  |  | (In thousands) |  |
| Balance at beginning of year |  | $ | 6,028 |  |  | $ | 9,320 |  |  | $ | 6,279 |  |
| Additions charged to expense |  |  | 38,440 |  |  |  | 33,154 |  |  |  | 24,798 |  |
| Sale of a majority owned subsidiary |  |  | — |  |  |  | (347 | ) |  |  | — |  |
| Deductions |  |  | (37,578 | ) |  |  | (36,104 | ) |  |  | (21,764 | ) |
| Effect of foreign currency exchange rates |  |  | — |  |  |  | 5 |  |  |  | 7 |  |
| Balance at end of year |  | $ | 6,890 |  |  | $ | 6,028 |  |  | $ | 9,320 |  |


## us-gaap:ScheduleOfShareBasedCompensationArrangementByShareBasedPaymentAwardPerformanceBasedUnitsVestedAndExpectedToVestTableTextBlock

[0001193125-15-069683:notes:106]
PRU
 activity for the year ended December 29, 2014 was as
 follows:

[0001193125-15-069683:notes:107]
|  |  | Shares |  |  | Weighted Average Fair Value |  |
|  |  | (In thousands) |  |  |  |  |
| Outstanding target shares at December 30, 2013 |  |  | 353 |  |  | $ | 10.23 |  |
| Granted |  |  | 258 |  |  |  | 5.80 |  |
| Vested |  |  | (90 | ) |  |  | 13.17 |  |
| Change in units due to annual financial target performance achievement |  |  | (29 | ) |  |  | 7.32 |  |
| Forfeited |  |  | (217 | ) |  |  | 6.90 |  |
| Outstanding target shares at December 29, 2014 |  |  | 275 |  |  | $ | 8.03 |  |


## us-gaap:DerivativesPolicyTextBlock

[0001193125-15-069683:notes:108]
Derivative Instruments and Hedging
 Activities

[0001193125-15-069683:notes:109]
Derivative
 financial instruments are recognized as either assets or
 liabilities in the consolidated balance sheets at their respective
 fair values. As a matter of policy, the Company uses derivatives
 for risk management purposes. The Company does not use derivatives
 for speculative purposes.

[0001193125-15-069683:notes:110]
Derivatives are
 typically entered into as hedges for changes in interest rates,
 currency exchange rates, and other risks. When the Company
 determines to designate a derivative instrument as a cash flow
 hedge, the Company formally documents the hedging relationship and
 its risk management objective and strategy for undertaking the
 hedge, the hedging instrument, the hedged item, the nature of the
 risk being hedged, how the hedging instrument’s effectiveness
 in offsetting the hedged risk will be assessed, and a description
 of the method of measuring ineffectiveness. The Company also
 formally assesses, both at the hedge’s inception and on an
 ongoing basis, whether the derivative that is used in hedging
 transactions is highly effective in offsetting changes in cash
 flows of hedged items.

[0001193125-15-069683:notes:111]
Fair value of
 the derivative instruments is determined using pricing models
 developed based on the underlying swap interest rate, foreign
 currency exchange rates, and other observable market data as
 appropriate. The values are also adjusted to reflect nonperformance
 risk of the counterparty and the Company, as necessary. For
 derivatives that are designated as a cash flow hedge, changes in
 the fair value of the derivative are recognized in accumulated
 other comprehensive income, to the extent the derivative is
 effective at offsetting the changes in cash flow being hedged until
 the hedged item affects earnings. To the extent there is any hedge
 ineffectiveness, changes in fair value relating to the ineffective
 portion are immediately recognized in earnings. Changes in the fair
 value of derivatives that are not designated as hedges are recorded
 in earnings each period.


## us-gaap:ScheduleOfComponentsOfIncomeTaxExpenseBenefitTableTextBlock

[0001193125-15-069683:notes:112]
The components
 of income tax provision for the years ended 2014, 2013 and 2012
 are:

[0001193125-15-069683:notes:113]
|  |  | For the Year Ended |  |
|  |  | December 29, 2014 |  |  | December 30, 2013 |  |  | December 31, 2012 |  |
|  |  | (In thousands) |  |
| Current (provision) benefit: |  |  |  |  |  |  |  |  |  |  |  |  |
| Federal |  | $ | 1,717 |  |  | $ | 6,684 |  |  | $ | (2,124 | ) |
| State |  |  | (216 | ) |  |  | 643 |  |  |  | (479 | ) |
| Foreign |  |  | (5,385 | ) |  |  | (14,466 | ) |  |  | (10,164 | ) |
| Total current |  |  | (3,884 | ) |  |  | (7,139 | ) |  |  | (12,767 | ) |
| Deferred (provision) benefit: |  |  |  |  |  |  |  |  |  |  |  |  |
| Federal |  |  | (829 | ) |  |  | (5,038 | ) |  |  | (3,105 | ) |
| State |  |  | 133 |  |  |  | (5,337 | ) |  |  | (515 | ) |
| Foreign |  |  | (3,018 | ) |  |  | 1,635 |  |  |  | 3,659 |  |
| Total deferred |  |  | (3,714 | ) |  |  | (8,740 | ) |  |  | 39 |  |
| Total provision |  | $ | (7,598 | ) |  | $ | (15,879 | ) |  | $ | (12,728 | ) |


## us-gaap:ScheduleOfOtherDerivativesNotDesignatedAsHedgingInstrumentsStatementsOfFinancialPerformanceAndFinancialPositionLocationTableTextBlock

[0001193125-15-069683:notes:114]
The net gain
 (loss) recognized in other, net in the consolidated statement of
 operations on derivative instruments not designated as hedges is as
 follows for the years 2014, 2013 and 2012:

[0001193125-15-069683:notes:115]
|  |  | For the Year Ended |  |
|  |  | December 29, 2014 |  |  | December 30, 2013 |  |  | December 31, 2012 |  |
|  |  | (In thousands) |  |
| Derivative instruments not designated as hedges: |  |  |  |  |  |  |  |  |  |  |  |  |
| Foreign exchange contracts |  | $ | (3,579 | ) |  | $ | (2,381 | ) |  | $ | (239 | ) |
| Interest rate swap |  |  | — |  |  |  | 620 |  |  |  | (306 | ) |
|  |  | $ | (3,579 | ) |  | $ | (1,761 | ) |  | $ | (545 | ) |


## us-gaap:ScheduleOfUnrecognizedCompensationCostNonvestedAwardsTableTextBlock

[0001193125-15-069683:notes:116]
The following
 is a summary of total unrecognized compensation costs as of
 December 29, 2014:

[0001193125-15-069683:notes:117]
|  |  | Unrecognized Stock-Based Compensation Cost |  |  | Remaining Weighted Average Recognition Period |  |
|  |  | (In thousands) |  |  | (In years) |  |
| PRU awards |  | $ | 1,011 |  |  |  | 1.36 |  |
| RSU awards |  |  | 6,527 |  |  |  | 1.28 |  |
|  |  | $ | 7,538 |  |  |  |  |  |


## us-gaap:CashAndCashEquivalentsPolicyTextBlock

[0001193125-15-069683:notes:118]
Cash
 Equivalents

[0001193125-15-069683:notes:119]
The Company
 considers highly liquid investments with insignificant interest
 rate risk and original maturities to the Company of three months or
 less to be cash equivalents. Cash equivalents consist primarily of
 interest-bearing bank accounts and money market funds.

[0001193125-15-069683:notes:120]
The Company
 considers highly liquid investments with an effective maturity to
 the Company of more than three months and less than one year to be
 short-term investments.


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001193125-15-069683:notes:121]
| (9) | Financial Instruments |

[0001193125-15-069683:notes:122]
Derivatives

[0001193125-15-069683:notes:123]
Interest
 Rate Swaps

[0001193125-15-069683:notes:124]
The
 Company’s business is exposed to interest rate risk resulting
 from fluctuations in interest rates on certain variable rate LIBOR
 debt. Increases in interest rates would increase interest expenses
 relating to the outstanding variable rate borrowings of certain
 foreign subsidiaries and increase the cost of debt. Fluctuations in
 interest rates can also lead to significant fluctuations in the
 fair value of the debt obligations.

[0001193125-15-069683:notes:125]
The Company
 entered into a two-year pay-fixed, receive floating (1-month
 LIBOR), amortizing interest rate swap arrangement with an initial
 notional amount of $146,500, which expired on April 16, 2013.
 The Company had designated this interest rate swap as a cash flow
 hedge and, during the year ended 2012, the interest rate swap
 increased interest expense by $1,908. For the year ended 2013, the
 Company did not designate this interest rate swap as a cash flow
 hedge as the borrowings attributable to this interest rate swap
 were paid in full during the third quarter of 2012. The change in
 the fair value of this interest rate swap during the year ended
 December 30, 2013 was recorded as other, net in the
 consolidated statement of operations.

[0001193125-15-069683:notes:126]
Foreign
 Exchange Contracts

[0001193125-15-069683:notes:127]
The Company
 enters into foreign currency forward contracts to mitigate the
 impact of changes in foreign currency exchange rates and to reduce
 the volatility of purchases and other obligations generated in
 currencies other than the functional currencies. The
 Company’s foreign subsidiaries may at times purchase forward
 exchange contracts to manage its foreign currency risks in relation
 to certain purchases of machinery denominated in foreign currencies
 other than the Company’s foreign functional currency. The
 notional amount of the foreign exchange contracts as of
 December 29, 2014 and December 30, 2013 was approximately
 $29,142 and $47,000, respectively. The Company has designated
 certain of these foreign exchange contracts as cash flow
 hedges.

[0001193125-15-069683:notes:128]
The fair
 values of derivative instruments in the consolidated balance sheet
 are as follows:

[0001193125-15-069683:notes:129]
The following
 table provides information about the amounts recorded in
 accumulated other comprehensive income related to derivatives
 designated as cash flow hedges, as well as the amounts recorded in
 each caption in the consolidated statement of operations when
 derivative amounts are reclassified out of accumulated other
 comprehensive income for the years ended 2014, 2013 and
 2012:

[0001193125-15-069683:notes:130]
|  |  |  |  | For the Year Ended |  |
|  |  |  |  | December 29, 2014 |  |  | December 30, 2013 |  |  | December 31, 2012 |  |
|  |  |  |  | Effective Portion |  |  | Ineffective Portion |  |  | Effective Portion |  |  | Ineffective Portion |  |  | Effective Portion |  |  | Ineffective Portion |  |
|  |  | Financial Statement Caption |  | Gain/(Loss) Recognized in Other Comprehensive Income |  |  | Gain/(Loss) Reclassified into Income |  |  | Gain/ (Loss) Recognized into Income |  |  | Gain/(Loss) Recognized in Other Comprehensive Income |  |  | Gain/(Loss) Reclassified into Income |  |  | Gain/ (Loss) Recognized into Income |  |  | Gain/(Loss) Recognized in Other Comprehensive Income |  |  | Gain/(Loss) Reclassified into Income |  |  | Gain/ (Loss) Recognized into Income |  |
|  |  | (In thousands) |  |
| Cash flow hedge: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Interest rate swap |  | Interest expense |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  | $ | 1,563 |  |  | $ | (1,908 | ) |  |  | — |  |
| Interest rate swap |  | Other, net |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  | $ | (1,158 | ) |
| Foreign currency forward |  | Depreciation expense |  | $ | 43 |  |  | $ | (146 | ) |  |  | — |  |  | $ | (1,726 | ) |  | $ | (128 | ) |  |  | — |  |  |  | 1,096 |  |  |  | — |  |  |  | — |  |
|  |  |  |  | $ | 43 |  |  | $ | (146 | ) |  |  | — |  |  | $ | (1,726 | ) |  | $ | (128 | ) |  |  | — |  |  | $ | 2,659 |  |  | $ | (1,908 | ) |  | $ | (1,158 | ) |

[0001193125-15-069683:notes:131]
The following
 provides a summary of the activity associated with the designated
 cash flow hedges reflected in accumulated other comprehensive
 income for the years ended 2014, 2013 and 2012:

[0001193125-15-069683:notes:132]
|  |  | For the Year Ended |  |
|  |  | December 29, 2014 |  |  | December 30, 2013 |  |  | December 31, 2012 |  |
|  |  | (In thousands) |  |
| Beginning balance, net of tax |  | $ | (1,613 | ) |  | $ | (15 | ) |  | $ | (3,262 | ) |
| Changes in fair value gain (loss), net of tax |  |  | 43 |  |  |  | (1,726 | ) |  |  | 2,405 |  |
| Reclassification to earnings, net of tax |  |  | 146 |  |  |  | 128 |  |  |  | 842 |  |
| Ending balance, net of tax |  | $ | (1,424 | ) |  | $ | (1,613 | ) |  | $ | (15 | ) |

[0001193125-15-069683:notes:133]
The Company
 expects that approximately $170 of the accumulated other
 comprehensive income will be reclassified into the statement of
 operations, net of tax, in the next 12 months.


## us-gaap:MinorityInterestDisclosureTextBlock

[0001193125-15-069683:notes:134]
| (20) | Non-controlling Interest Holdings |

[0001193125-15-069683:notes:135]
On June 17,
 2013, the Company completed the sale of its 70.2% controlling
 equity interest in Dongguan Shengyi Electronics Ltd. (SYE) to its
 noncontrolling partner, Shengyi Technology Co. Ltd. (Sytech), for
 702,000,000 Chinese RMB or $114,495. The Company recognized a gain
 on the sale of SYE of $17,917 in 2013. Consideration net of cash
 sold was $67,147.

[0001193125-15-069683:notes:136]
Additionally,
 the Company acquired Sytech’s 20.0% noncontrolling equity
 interest in Dongguan Meadville Circuits Ltd. (DMC) for 180,000,000
 Chinese RMB or $29,358 in 2013. The Company recorded a decrease to
 additional paid-in capital for the difference between the purchase
 price and the carrying value of the noncontrolling interest of
 $71.


## us-gaap:PreferredStockTextBlock

[0001193125-15-069683:notes:137]
| (16) | Preferred Stock |

[0001193125-15-069683:notes:138]
The board of
 directors has the authority, without action by stockholders, to
 designate and issue preferred stock in one or more series. The
 board of directors may also designate the rights, preferences and
 privileges of each series of preferred stock, any or all of which
 may be superior to the rights of the common stock. As of
 December 29, 2014, no shares of preferred stock were
 outstanding.


## us-gaap:PropertyPlantAndEquipmentPolicyTextBlock

[0001193125-15-069683:notes:139]
Property,
 Plant and Equipment, Net

[0001193125-15-069683:notes:140]
Property, plant
 and equipment are recorded at cost. Depreciation expense is
 computed using the straight-line method over the estimated useful
 lives of the assets. Assets recorded under leasehold improvements
 are amortized using the straight-line method over the lesser of
 their useful lives or the related lease term. The Company uses the
 following estimated useful lives:

[0001193125-15-069683:notes:141]
| Land use rights |  |  | 50-99 years |  |
| Buildings and improvements |  |  | 7-40 years |  |
| Machinery and equipment |  |  | 3-12 years |  |
| Furniture and fixtures |  |  | 3-7 years |  |

[0001193125-15-069683:notes:142]
Upon retirement
 or other disposition of property, plant and equipment, the cost and
 related accumulated depreciation are removed from the accounts. The
 resulting gain or loss is included in the determination of
 operating income in the period incurred. Depreciation and
 amortization expense on property, plant and equipment was $95,349,
 $92,120 and $84,286, for the years ended 2014, 2013 and 2012,
 respectively.

[0001193125-15-069683:notes:143]
The Company
 capitalizes interest on borrowings during the active construction
 period of major capital projects. Capitalized interest is amortized
 over the average useful lives of such assets, which primarily
 consist of buildings and machinery and equipment. The Company
 capitalized interest costs of $551, $1,125 and $1,774 during the
 years ended 2014, 2013 and 2012, respectively, in connection with
 various capital projects.

[0001193125-15-069683:notes:144]
Major renewals
 and betterments are capitalized and depreciated over their
 estimated useful lives while minor expenditures for maintenance and
 repairs are included in operating income as incurred.


## us-gaap:ScheduleOfAccumulatedOtherComprehensiveIncomeLossTableTextBlock

[0001193125-15-069683:notes:145]
The following
 provides a summary of the components of accumulated other
 comprehensive income, net of tax as of December 29,
 2014, December 30, 2013 and December 31,
 2012:

[0001193125-15-069683:notes:146]
|  |  | Foreign Currency Translation |  |  | Gains (Losses) on Cash Flow Hedges |  |  | Unrealized Gains (Losses) on Available for Sale Securities |  |  | Total |  |
|  |  | (In thousands) |  |
| Ending balance at December 31, 2012 |  | $ | 46,775 |  |  | $ | (15 | ) |  | $ | (11 | ) |  | $ | 46,749 |  |
| Other comprehensive income (loss) before reclassifications |  |  | 14,771 |  |  |  | (1,726 | ) |  |  | (105 | ) |  |  | 12,940 |  |
| Amounts reclassified from accumulated other comprehensive income |  |  | (14,266 | ) |  |  | 128 |  |  |  | 53 |  |  |  | (14,085 | ) |
| Net year to date period other comprehensive income (loss) |  |  | 505 |  |  |  | (1,598 | ) |  |  | (52 | ) |  |  | (1,145 | ) |
| Ending balance at December 30, 2013 |  |  | 47,280 |  |  |  | (1,613 | ) |  |  | (63 | ) |  |  | 45,604 |  |
| Other comprehensive income (loss) before reclassifications |  |  | (14,841 | ) |  |  | 43 |  |  |  | (20 | ) |  |  | (14,818 | ) |
| Amounts reclassified from accumulated other comprehensive income |  |  | — |  |  |  | 146 |  |  |  | 83 |  |  |  | 229 |  |
| Net year to date period other comprehensive income (loss) |  |  | (14,841 | ) |  |  | 189 |  |  |  | 63 |  |  |  | (14,589 | ) |
| Ending balance at December 29, 2014 |  | $ | 32,439 |  |  | $ | (1,424 | ) |  | $ | — |  |  | $ | 31,015 |  |


## us-gaap:ScheduleOfDebtInstrumentsTextBlock

[0001193125-15-069683:notes:147]
The following
 table summarizes the long-term debt of the Company as of
 December 29, 2014 and December 30, 2013:

[0001193125-15-069683:notes:148]
|  |  | Average Effective Interest Rate as of December 29, 2014 |  |  | December 29, 2014 |  |  | Average Effective Interest Rate as of December 30, 2013 |  |  | December 30, 2013 |  |
|  |  | (In thousands) |  |
| Term loan due September 2016 |  |  | 2.55 | % |  | $ | 273,800 |  |  |  | 2.55 | % |  | $ | 370,000 |  |
| Other |  |  | 6.00 | % |  |  | 4 |  |  |  | 6.00 | % |  |  | 8 |  |
|  |  |  |  |  |  |  | 273,804 |  |  |  |  |  |  |  | 370,008 |  |
| Less: current maturities |  |  |  |  |  |  | (96,204 | ) |  |  |  |  |  |  | (96,204 | ) |
| Long-term debt, less current maturities |  |  |  |  |  | $ | 177,600 |  |  |  |  |  |  | $ | 273,804 |  |


## us-gaap:SummaryOfIncomeTaxContingenciesTextBlock

[0001193125-15-069683:notes:149]
A
 reconciliation of the beginning and ending amount of unrecognized
 tax benefits, exclusive of accrued interest and penalties, is as
 follows:

[0001193125-15-069683:notes:150]
|  |  | For the Year Ended |  |
|  |  | December 29, 2014 |  |  | December 30, 2013 |  |  | December 31, 2012 |  |
|  |  | (In thousands) |  |
| Beginning balance |  | $ | 2,298 |  |  | $ | 2,424 |  |  | $ | 887 |  |
| Additions based on tax positions related to the current year |  |  | 220 |  |  |  | 322 |  |  |  | 49 |  |
| Additions for tax positions of prior years |  |  | 286 |  |  |  | — |  |  |  | 1,488 |  |
| Reductions for tax positions of prior years |  |  | — |  |  |  | (448 | ) |  |  | — |  |
| Lapse of statute |  |  | (363 | ) |  |  | — |  |  |  | — |  |
| Ending balance |  | $ | 2,441 |  |  | $ | 2,298 |  |  | $ | 2,424 |  |


## us-gaap:ConsolidationPolicyTextBlock

[0001193125-15-069683:notes:151]
Principles of Consolidation

[0001193125-15-069683:notes:152]
The
 consolidated financial statements include the accounts of TTM
 Technologies, Inc. and its subsidiaries. All intercompany accounts
 and transactions have been eliminated in consolidation.


## us-gaap:ForeignCurrencyTransactionsAndTranslationsPolicyTextBlock

[0001193125-15-069683:notes:153]
Foreign
 Currency Translation and Transactions

[0001193125-15-069683:notes:154]
The functional
 currency of certain of the Company’s subsidiaries is either
 the Chinese Renminbi (RMB) or the Hong Kong Dollar. Accordingly,
 assets and liabilities are translated into U.S. dollars using
 period-end exchange rates. Sales and expenses are translated at the
 average exchange rates in effect during the period. The resulting
 translation gains or losses are recorded as a component of
 accumulated other comprehensive income in the consolidated
 statement of stockholders’ equity and the consolidated
 statement of comprehensive income. Net gains resulting from foreign
 currency remeasurements and transactions are included in income as
 a component of other, net in the consolidated statements of
 operations and totaled $2,378, $6,113, and $3,581 for the years
 ended 2014, 2013 and 2012, respectively.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001193125-15-069683:notes:155]
| (8) | Income Taxes |

[0001193125-15-069683:notes:156]
The Company
 expects its foreign earnings attributable to the Asia Pacific
 operating segment will be indefinitely reinvested in such foreign
 jurisdictions and, therefore, no deferred tax liabilities for
 U.S. income taxes on undistributed earnings are recorded. The
 undistributed earnings of the foreign subsidiaries amounted to
 approximately $263,200. The determination of unrecognized deferred
 tax liability related to these undistributed earnings is not
 practicable. Foreign earnings attributable to certain manufacturing
 subsidiaries within the Asia Pacific operating segment may be
 repatriated to the parent holding company located in Hong Kong, and
 therefore, a deferred tax liability of approximately $3,486 for the
 foreign tax impacts has been recorded on the undistributed earnings
 of these subsidiaries.

[0001193125-15-069683:notes:157]
Foreign
 earnings attributable to the Company’s backplane assembly
 facility in Shanghai, China, which is managed in conjunction with
 the Company’s U.S. operations, will be repatriated to the
 Company and therefore a deferred tax liability of $5,302 for U.S.
 income taxes on undistributed earnings has been
 recorded.

[0001193125-15-069683:notes:158]
Deferred income
 taxes reflect the net tax effects of temporary differences between
 the carrying amounts of assets and liabilities for financial
 reporting purposes and the amounts used for income tax purposes.
 The significant components of the net deferred income tax assets as
 of December 29, 2014 and December 30, 2013 are as
 follows:

[0001193125-15-069683:notes:159]
|  |  | As of |  |
|  |  | December 29, 2014 |  |  | December 30, 2013 |  |
|  |  | (In thousands) |  |
| Deferred income tax assets: |  |  |  |  |  |  |  |  |
| Goodwill and intangible amortization |  | $ | 11,071 |  |  | $ | 13,216 |  |
| Reserves and accruals |  |  | 11,415 |  |  |  | 10,203 |  |
| Net operating loss carryforwards |  |  | 26,644 |  |  |  | 22,004 |  |
| State tax credit carryforwards, net of federal benefit |  |  | 6,101 |  |  |  | 6,317 |  |
| Stock-based compensation |  |  | 3,624 |  |  |  | 4,093 |  |
| Original issue discount on convertible senior notes |  |  | 22,029 |  |  |  | 22,425 |  |
| Other deferred income tax assets |  |  | 3,804 |  |  |  | 2,539 |  |
|  |  |  | 84,688 |  |  |  | 80,797 |  |
| Less: valuation allowance |  |  | (38,839 | ) |  |  | (44,160 | ) |
|  |  |  | 45,849 |  |  |  | 36,637 |  |
| Deferred income tax liabilities: |  |  |  |  |  |  |  |  |
| Discount on convertible senior notes |  |  | (19,315 | ) |  |  | (19,940 | ) |
| Unrealized gain on currency translation |  |  | (2,979 | ) |  |  | (3,132 | ) |
| Repatriation of foreign earnings |  |  | (8,823 | ) |  |  | (7,241 | ) |
| Property, plant and equipment basis differences |  |  | (11,819 | ) |  |  | (903 | ) |
| Net deferred income tax assets |  | $ | 2,913 |  |  | $ | 5,421 |  |
| Deferred income tax assets (liabilities), net: |  |  |  |  |  |  |  |  |
| Current deferred income taxes |  | $ | 10,147 |  |  | $ | 8,767 |  |
| Noncurrent deferred income taxes |  |  | (7,234 | ) |  |  | (3,346 | ) |

[0001193125-15-069683:notes:160]
At
 December 29, 2014 the Company’s foreign and multiple
 state net operating loss carryforwards for income tax purposes were
 approximately $107,151 and $7,884, respectively. If not utilized,
 the foreign and state net operating loss carryforwards will begin
 to expire in 2015 and 2018, respectively. At December 29,
 2014, the Company’s state tax credit carryforwards were
 approximately $10,106 of which $2,221 has no expiration
 date.

[0001193125-15-069683:notes:161]
A valuation
 allowance is provided when it is more likely than not that all or
 some portion of the deferred income tax assets will not be
 realized. Certain subsidiaries within the Asia Pacific operating
 segment continue to have net operating loss carryforwards in
 various tax jurisdictions that the Company has determined are not
 more likely than not to be utilized. Additionally, there are
 certain subsidiaries within the Asia Pacific operating segment that
 continue to generate losses that are not more likely than not to be
 utilized. Based on historical performance and future expectations
 of these subsidiaries, the Company does not anticipate sufficient
 taxable income to utilize these net operating loss carryforwards.
 As a result, a full valuation allowance has been recorded for these
 subsidiaries at December 29, 2014. Additionally, the State of
 California has limited the carryforward period of certain credits
 to 10 years instead of indefinite. The Company has determined that
 it is not more likely than not to fully utilize certain state
 credits, and as such has recorded a valuation allowance. For the
 remaining net deferred income tax asset, management has determined
 that it is more likely than not that the results of future
 operations will generate sufficient taxable income to realize the
 net deferred tax asset.

[0001193125-15-069683:notes:162]
The following
 summarizes the activity in the Company’s valuation allowance
 for the years ended 2014, 2013 and 2012:

[0001193125-15-069683:notes:163]
|  |  | For the Year Ended |  |
|  |  | December 29, 2014 |  |  | December 30, 2013 |  |  | December 31, 2012 |  |
|  |  | (In thousands) |  |
| Balance at beginning of year |  | $ | 44,160 |  |  | $ | 41,790 |  |  | $ | 33,583 |  |
| Additions charged to expense |  |  | 6,458 |  |  |  | 6,763 |  |  |  | 8,207 |  |
| Deductions |  |  | (11,779 | ) |  |  | (4,393 | ) |  |  | — |  |
| Balance at end of year |  | $ | 38,839 |  |  | $ | 44,160 |  |  | $ | 41,790 |  |

[0001193125-15-069683:notes:164]
Certain
 entities within the Asia Pacific operating segment operated under
 the high technology enterprise (HNTE) and tax holidays in China,
 which were effective for the years ended 2014, 2013 and 2012. The
 HNTE and tax holidays decreased Chinese taxes by $1,877, $3,187 and
 $4,694, which increased both basic and dilutive earnings per share
 by $0.02, $0.04 and $0.06, for the years ended 2014, 2013 and 2012,
 respectively. The Company will continue to file for the favorable
 reduced rates related to HNTE for the foreseeable
 future.

[0001193125-15-069683:notes:165]
As of
 December 29, 2014 and December 30, 2013, the Company
 recorded unrecognized tax benefits of $31 and $576, respectively,
 as well as interest and penalties of $22 and $40, respectively, to
 other long-term liabilities. The Company has also recorded
 unrecognized tax benefits of $1,385 and $982 against certain
 deferred tax assets as of December 29, 2014 and
 December 30, 2013, respectively. Additionally, $1,025 of
 unrecognized tax benefit is recorded to current liabilities. The
 amount of unrecognized tax benefits that would, if recognized,
 reduce the Company’s effective income tax rate in any future
 periods is $2,441. The Company expects its unrecognized tax
 benefits to decrease by $1,035 over the next 12 months due to
 expiring statutes.

[0001193125-15-069683:notes:166]
The Company and
 its subsidiaries are subject to U.S. federal, state, local,
 and/or foreign income tax, and in the normal course of business its
 income tax returns are subject to examination by the relevant
 taxing authorities. As of December 29, 2014, the 2009-2014 tax
 years remain subject to examination in the U.S. federal tax,
 various state tax and foreign tax jurisdictions. As of
 December 29, 2014, the Company was not under any income tax
 audit.


## us-gaap:LongTermDebtTextBlock

[0001193125-15-069683:notes:167]
| (6) | Long-term Debt and Letters of Credit |

[0001193125-15-069683:notes:168]
The maturities
 of long-term debt through 2016 are as follows:

[0001193125-15-069683:notes:169]
|  |  | (In thousands) |  |
| 2015 |  | $ | 96,204 |  |
| 2016 |  |  | 177,600 |  |
|  |  | $ | 273,804 |  |

[0001193125-15-069683:notes:170]
Credit
 Agreement

[0001193125-15-069683:notes:171]
On
 September 14, 2012, the Company became a party to a facility
 agreement (Credit Agreement) with a syndicate of eight banks led by
 The Hongkong and Shanghai Banking Corporation Limited as Facility
 Agent. The Credit Agreement consists of a $370,000 senior secured
 term loan (Term Loan), a $90,000 senior secured revolving loan
 (Revolving Loan), and a secured $80,000 letters of credit facility
 (Letters of Credit Facility). The Term Loan and Letters of Credit
 Facility will mature on September 14, 2016. The Revolving Loan
 will mature on March 14, 2016. The Credit Agreement is secured
 by substantially all of the assets of the Company’s Asia
 Pacific operating segment and is senior to all other debt,
 including the convertible senior notes. See Note 7. The Company has
 fully and unconditionally guaranteed the full and timely payment of
 all Credit Agreement related obligations of its Asia Pacific
 operating segment.

[0001193125-15-069683:notes:172]
Borrowings
 under the Credit Agreement bear interest at a floating rate of
 LIBOR plus an applicable interest margin of 2.38%. There is no
 provision, other than an event of default, for these interest
 margins to increase. At December 29, 2014, the weighted
 average interest rate on the outstanding borrowings under the
 Credit Agreement was 2.55%.

[0001193125-15-069683:notes:173]
The Company is
 required to make scheduled payments of the outstanding Term Loan
 balance, while the Revolving Loan is due on March 14, 2016.
 Any other outstanding balances under the Credit Agreement are due
 at the maturity date of September 14, 2016. Borrowings under
 the Credit Agreement are subject to certain financial and operating
 covenants that include maintaining maximum total leverage ratios
 and minimum net worth, current ratio, and interest coverage ratios
 at both the Company and at the Asia Pacific operating segment
 level. In addition, the Company’s Credit Agreement includes a
 covenant that the Principal Shareholders (as defined in the
 Shareholders Agreement dated April 9, 2010 as amended on
 September 14, 2012) will not reduce their shareholding below
 15 percent of TTM’s issued shares. At December 29,
 2014, the Company was in compliance with the covenants under the
 Credit Agreement.

[0001193125-15-069683:notes:174]
As of
 December 29, 2014 and December 30, 2013, the remaining
 unamortized debt issuance costs included in other non-current
 assets was $1,123 and $1,937 and is amortized to interest expense
 over the term of the Credit Agreement using the effective interest
 rate method. At December 29, 2014, the remaining amortization
 period for the unamortized debt issuance costs was 1.5
 years.

[0001193125-15-069683:notes:175]
The Company is
 also required to pay a commitment fee of 0.50% per annum on
 any unused portion of the loan and letters of credit facility
 granted under the Credit Agreement. The Company incurred commitment
 fees related to unused borrowing availability of $600, $442 and
 $305 for the years ended 2014, 2013 and, 2012, respectively. As of
 December 29, 2014, the outstanding amount of the Term Loan
 under the Credit Agreement was $273,800, of which $96,200 is due
 for repayment through September 2015 and is included as short-term
 debt, with the remaining $177,600 included as long-term debt. None
 of the Revolving Loan associated with the Credit Agreement was
 outstanding as of December 29, 2014. Available borrowing
 capacity under the Revolving Loan was $90,000 at December 29,
 2014.

[0001193125-15-069683:notes:176]
Other
 Credit Facility

[0001193125-15-069683:notes:177]
Additionally,
 the Company is party to a revolving loan credit facility (Chinese
 Revolver) with a lender in the People’s Republic of China
 (China). Under this arrangement, the lender has made available to
 the Company approximately $36,900 in unsecured borrowing with all
 terms of the borrowing to be negotiated at the time the Chinese
 Revolver is drawn upon. There are no commitment fees on the unused
 portion of the Chinese Revolver and this arrangement expires in
 December 2015. As of December 29, 2014, the Chinese Revolver
 had not been drawn upon.

[0001193125-15-069683:notes:178]
Letters
 of Credit

[0001193125-15-069683:notes:179]
The Company has
 an $80,000 Letters of Credit Facility under the Credit Agreement,
 as mentioned above. As of December 29, 2014, letters of credit
 in the amount of $35,422 were outstanding under this Credit
 Agreement. The Company has other standby letters of credit
 outstanding in the amount of $4,257, which expire between
 December 31, 2015 and February 28, 2016.

[0001193125-15-069683:notes:180]
Loss on
 Extinguishment of Debt

[0001193125-15-069683:notes:181]
The Company
 became a party to its current Credit Agreement during the year
 ended December 31, 2012 in order to refinance and pay in full
 the outstanding loans borrowed under an existing 2009 credit
 agreement. Given the substantial modification in terms of the
 Credit Agreement, the refinancing was accounted for as an
 extinguishment of debt. As a result, the Company recognized $5,527
 as a loss on the extinguishment of debt for the year ended
 December 31, 2012 resulting from certain remaining unamortized
 debt issuance costs associated with the terminated 2009 credit
 agreement and certain additional lender fees paid in connection
 with the Credit Agreement.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0001193125-15-069683:notes:182]
| (1) | Nature of Operations and Basis of Presentation |

[0001193125-15-069683:notes:183]
TTM
 Technologies, Inc. (the Company or TTM) is a leading global
 provider of time-critical and technologically complex printed
 circuit board (PCB) products and backplane assemblies (i.e., PCBs
 populated with electronic components), which serve as the
 foundation of sophisticated electronic products. The Company
 provides time-to-market and advanced technology products and offers
 a one-stop manufacturing solution to customers from engineering
 support to prototype development through final volume production.
 This one-stop manufacturing solution allows the Company to align
 technology developments with the diverse needs of the
 Company’s customers and to enable them to reduce the time
 required to develop new products and bring them to
 market.

[0001193125-15-069683:notes:184]
Additionally,
 the Company serves a diversified customer base in various markets
 throughout the world, including manufacturers of
 networking/communications infrastructure products, touchscreen
 tablets and smartphones, as well as the aerospace and defense,
 high-end computing, and industrial/medical industries. The
 Company’s customers include both original equipment
 manufacturers (OEMs) and electronic manufacturing services (EMS)
 providers.

[0001193125-15-069683:notes:185]
Beginning 2013,
 the Company operates on a 52 or 53 week year ending on the Monday
 nearest December 31. Fiscal 2014 and fiscal 2013 were 52 weeks
 and ended on December 29, 2014, and December 30, 2013,
 respectively. Prior to 2013, the Company’s fiscal year always
 ended on December 31. All references to years relate to fiscal
 years unless otherwise noted.

[0001193125-15-069683:notes:186]
Acquisition of Viasystems Group, Inc.

[0001193125-15-069683:notes:187]
On
 September 21, 2014, TTM, Viasystems Group, Inc. (Viasystems),
 and Vector Acquisition Corp. (Merger Sub) entered into an Agreement
 and Plan of Merger (the Merger Agreement) under which, subject to
 the satisfaction of certain conditions, TTM expects to acquire all
 outstanding shares of Viasystems (the Merger) for a combined
 consideration of $11.33 in cash and 0.706 shares of TTM common
 stock per outstanding share of Viasystems common stock, which based
 on the closing market price on December 31, 2014 was valued at
 $16.65 per share of Viasystems common stock, or approximately
 $361.7 million. The total purchase price of the transaction,
 including debt assumed, is approximately $992.5 million, which was
 based on the closing market price on December 31, 2014 and is
 subject to change prior to the consummation of the
 Merger.

[0001193125-15-069683:notes:188]
Concurrently
 with the execution of the Merger Agreement, the Company obtained a
 debt financing commitment in an aggregate amount of $1,115 million
 in connection with financing the transactions contemplated by the
 Merger Agreement. Assuming consummation of the Merger, the Company
 intends to use the aggregate proceeds of such financing
 arrangements to finance the Merger, to refinance certain existing
 indebtedness of Viasystems, to refinance certain of the
 Company’s existing indebtedness, and to pay the fees and
 expenses incurred in connection with the Merger. The Company is in
 the process of finalizing the specific financing
 arrangements.

[0001193125-15-069683:notes:189]
Viasystems is a
 worldwide provider of complex multi-layer rigid, flexible, and
 rigid-flex PCBs and electro-mechanical solutions (E-M
 Solutions). Viasystems’ products are found in a wide variety
 of commercial products, including automotive engine controls,
 hybrid converters, automotive electronics for navigation, safety,
 and entertainment, telecommunications switching equipment, data
 networking equipment, computer storage equipment, semiconductor
 test equipment, wind and solar energy applications, off-shore
 drilling equipment, communications applications, flight control
 systems, and complex industrial, medical, and other technical
 instruments. Viasystems’ E-M Solutions services can be
 bundled with its PCBs to provide an integrated solution to
 customers. Viasystems operates 15 manufacturing facilities
 worldwide: eight in the United States, five in China, one each in
 Canada and Mexico. Viasystems serves a diversified customer base of
 over 1,000 customers in various markets throughout the
 world.

[0001193125-15-069683:notes:190]
The Merger
 Agreement provides that Viasystems is entitled to receive a reverse
 breakup fee of $40 million from TTM in the event that the Merger
 Agreement is terminated following specific conditions.

[0001193125-15-069683:notes:191]
Since the public
 announcement on September 22, 2014 of the execution of the
 Merger Agreement, TTM, Viasystems, Merger Sub, and the members of
 the Viasystems board of directors (the Viasystems Board) have been
 named as defendants in two putative class action complaints
 challenging the Merger. See Note 13 to these Consolidated Financial
 Statements for additional information.

[0001193125-15-069683:notes:192]
Bank fees and
 legal accounting and other professional service costs associated
 with the acquisition of Viasystems of $5,981 for the year
 ended December 29, 2014 have been expensed and recorded
 as general and administrative expense in the consolidated statement
 of operations.


## us-gaap:SignificantAccountingPoliciesTextBlock

[0001193125-15-069683:notes:193]
| (2) | Summary of Significant Accounting Policies |

[0001193125-15-069683:notes:194]
Use of
 Estimates

[0001193125-15-069683:notes:195]
The
 preparation of financial statements in conformity with accounting
 principles generally accepted in the United States of America (U.S.
 GAAP) requires management to make estimates and assumptions that
 affect the reported amounts of assets and liabilities and
 disclosure of contingent assets and liabilities at the date of the
 financial statements and the reported amount of revenues and
 expenses during the reporting period. Such estimates include the
 sales return reserve; accounts receivable; inventories; goodwill;
 intangible assets and other long-lived assets; self insurance
 reserves; derivative instruments and hedging activities;
 environmental liabilities; legal contingencies; income taxes; and
 others. These estimates and assumptions are based on
 management’s best estimates and judgment. Management
 evaluates its estimates and assumptions on an ongoing basis using
 historical experience and other factors, including the economic
 environment, which management believes to be reasonable under the
 circumstances. Management adjusts such estimates and assumptions
 when facts and circumstances dictate. Unpredictable spending by OEM
 and EMS companies has also increased the uncertainty inherent in
 such estimates and assumptions. As future events and their effects
 cannot be determined with precision, actual results could differ
 from those estimates.

[0001193125-15-069683:notes:196]
The
 functional currency of certain of the Company’s subsidiaries
 is either the Chinese Renminbi (RMB) or the Hong Kong Dollar.
 Accordingly, assets and liabilities are translated into
 U.S. dollars using period-end exchange rates. Sales and
 expenses are translated at the average exchange rates in effect
 during the period. The resulting translation gains or losses are
 recorded as a component of accumulated other comprehensive income
 in the consolidated statement of stockholders’ equity and the
 consolidated statement of comprehensive income. Net gains resulting
 from foreign currency remeasurements and transactions are included
 in income as a component of other, net in the consolidated
 statements of operations and totaled $2,378, $6,113, and $3,581 for
 the years ended 2014, 2013 and 2012, respectively.

[0001193125-15-069683:notes:197]
Accounts Receivable, Allowance for Doubtful Accounts and
 Factoring Arrangements

[0001193125-15-069683:notes:198]
Accounts
 Receivable

[0001193125-15-069683:notes:199]
Accounts
 receivable are reflected at estimated net realizable value, do not
 bear interest and do not generally require collateral. The Company
 performs credit evaluations of its customers and adjusts credit
 limits based upon payment history and the customer’s current
 creditworthiness. The Company maintains an allowance for doubtful
 accounts based upon a variety of factors. The Company reviews all
 open accounts and provides specific reserves for customer
 collection issues when it believes the loss is probable,
 considering such factors as the length of time receivables are past
 due, the financial condition of the customer, and historical
 experience. The Company also records a reserve for all customers,
 excluding those that have been specifically reserved for, based
 upon evaluation of historical losses.

[0001193125-15-069683:notes:200]
Additionally,
 in the normal course of business, the Company’s foreign
 subsidiaries may utilize accounts receivable factoring
 arrangements. Under these arrangements, the Company’s foreign
 subsidiaries may sell certain of their accounts receivable to
 financial institutions, which are accounted for as a sale, at a
 discount ranging from 1% to 2% of the accounts receivable. In all
 arrangements there is no recourse against the Company for its
 customers’ failure to pay. The Company sold $3,941 of
 accounts receivable for the year ended 2012. The Company did not
 sell any accounts receivable for the years ended 2014 or
 2013.

[0001193125-15-069683:notes:201]
Allowance
 for Doubtful Accounts

[0001193125-15-069683:notes:202]
Inventories
 are stated at the lower of cost (determined on a first-in,
 first-out and weighted average basis) or market. Assessments to
 value the inventory at the lower of the actual cost to purchase
 and / or manufacture the inventory, or the current
 estimated market value of the inventory, are based upon assumptions
 about future demand and market conditions. As a result of the
 Company’s assessments, when the market value of inventory is
 less than the carrying value, the inventory cost is written down to
 the market value and the write down is recorded as a charge to cost
 of goods sold.

[0001193125-15-069683:notes:203]
Property, Plant and Equipment, Net

[0001193125-15-069683:notes:204]
Property,
 plant and equipment are recorded at cost. Depreciation expense is
 computed using the straight-line method over the estimated useful
 lives of the assets. Assets recorded under leasehold improvements
 are amortized using the straight-line method over the lesser of
 their useful lives or the related lease term. The Company uses the
 following estimated useful lives:

[0001193125-15-069683:notes:205]
Upon
 retirement or other disposition of property, plant and equipment,
 the cost and related accumulated depreciation are removed from the
 accounts. The resulting gain or loss is included in the
 determination of operating income in the period incurred.
 Depreciation and amortization expense on property, plant and
 equipment was $95,349, $92,120 and $84,286, for the years ended
 2014, 2013 and 2012, respectively.

[0001193125-15-069683:notes:206]
Major
 renewals and betterments are capitalized and depreciated over their
 estimated useful lives while minor expenditures for maintenance and
 repairs are included in operating income as incurred.

[0001193125-15-069683:notes:207]
Goodwill
 represents the excess of purchase price of an acquisition over the
 fair value of net assets acquired. Goodwill is not amortized but
 instead is assessed for impairment, at a reporting unit level,
 annually and when events and circumstances warrant an evaluation.
 The Company evaluates goodwill on an annual basis, as of the end of
 the fourth quarter, and whenever events and changes in
 circumstances indicate that there may be a potential impairment. In
 making this assessment, management relies on a number of factors,
 including expected future operating results, business plans,
 economic projections, anticipated future cash flows, business
 trends and market conditions.

[0001193125-15-069683:notes:208]
The Company
 has two operating segments consisting of three reporting units. See
 Note 4 for information regarding the impairment of goodwill for the
 year ended 2012.

[0001193125-15-069683:notes:209]
Intangible Assets

[0001193125-15-069683:notes:210]
Intangible
 assets include customer relationships, trade name and licensing
 agreements, which are being amortized over their estimated useful
 lives using straight-line and accelerated methods. The estimated
 useful lives of such intangibles range from 3 years to
 15 years. Amortization expense related to acquired licensing
 agreements is classified as a component of cost of goods sold. Also
 see discussion below of impairment of long-lived assets, which
 includes definite-lived intangible assets.

[0001193125-15-069683:notes:211]
Impairment of Long-lived Assets

[0001193125-15-069683:notes:212]
Long-lived
 tangible assets, including property, plant and equipment, assets
 held for sale, and definite-lived intangible assets, are reviewed
 for impairment whenever events or changes in circumstances indicate
 that the carrying value of the asset or asset groups may not be
 recoverable. The Company regularly evaluates whether events or
 circumstances have occurred that indicate possible impairment and
 relies on a number of factors, including expected future operating
 results, business plans, economic projections, and anticipated
 future cash flows. The Company uses an estimate of the future
 undiscounted net cash flows and comparisons to like-kind assets, as
 appropriate, of the related asset or asset group over the remaining
 life in measuring whether the assets are recoverable. Measurement
 of the amount of impairment, if any, is based upon the difference
 between the asset’s carrying value and estimated fair value.
 Fair value is determined through various valuation techniques,
 including cost-based, market and income approaches as considered
 necessary. See Notes 4 and 5 for information regarding the
 impairment of definite-lived intangibles and long-lived assets
 during the years ended 2014, 2013 and 2012.

[0001193125-15-069683:notes:213]
The Company
 classifies assets to be sold as assets held for sale when
 (i) Company management has approved and commits to a plan to
 sell the asset, (ii) the asset is available for immediate sale
 in its present condition and is ready for sale, (iii) an
 active program to locate a buyer and other actions required to sell
 the asset have been initiated, (iv) the sale of the asset is
 probable, (v) the asset is being actively marketed for sale at
 a price that is reasonable in relation to its current fair value,
 and (vi) it is unlikely that significant changes to the plan
 will be made or that the plan will be withdrawn. Assets classified
 as held for sale are recorded at the lower of the carrying amount
 or fair value less the cost to sell and are a component of prepaid
 expenses and other current assets in the consolidated balance
 sheets.

[0001193125-15-069683:notes:214]
The Company
 classifies assets held for use when a decision to dispose of an
 asset or a business is made and the held for sale criteria are not
 met. Assets of the business are evaluated for recoverability in the
 following order: (i) assets other than goodwill, property and
 intangibles; (ii) property and intangibles subject to
 amortization; and (iii) goodwill. In evaluating the
 recoverability of property and intangible assets subject to
 amortization, in a held for use business, the carrying value is
 first compared to the sum of the undiscounted cash flows expected
 to result from the use and eventual disposition. If the carrying
 value exceeds the undiscounted expected cash flows, then a fair
 value analysis is performed. An impairment charge is recognized if
 the carrying value exceeds the fair value.

[0001193125-15-069683:notes:215]
The Company
 has various foreign subsidiaries formed or acquired to conduct or
 support its business outside the United States. The Company does
 not provide for U.S. income taxes on undistributed earnings
 for its Asia Pacific operating segment as management expects the
 foreign earnings will be indefinitely reinvested in such foreign
 jurisdictions. For certain subsidiaries within the Asia Pacific
 operating segment, indefinite investment of undistributed earnings
 has not been asserted between the respective subsidiaries and their
 foreign parent entity and therefore, a deferred tax liability for
 the foreign tax impacts has been recorded on the undistributed
 earnings of these subsidiaries. For the Company’s backplane
 assembly plant in Shanghai, China, which is managed in conjunction
 with the Company’s U.S. operations, earnings are expected to
 be repatriated and therefore the Company has provided U.S. income
 taxes on these undistributed earnings.

[0001193125-15-069683:notes:216]
Self
 Insurance

[0001193125-15-069683:notes:217]
The Company
 is primarily self insured in North America for group health
 insurance and workers compensation benefits provided to U.S.
 employees. The Company also purchases stop loss insurance to
 protect against annual claims per individual and at an aggregate
 level. The individual insured stop loss on the Company’s self
 insurance is $300 per individual for group health insurance and
 $250 per individual for worker’s compensation benefits. Self
 insurance liabilities are estimated for claims incurred but not
 paid based on judgment, using the Company’s historical claim
 data and information and analysis provided by actuarial and claim
 advisors, the Company’s insurance carrier and brokers. The
 Company has accrued $5,032 and $4,609 for self insurance
 liabilities as of December 29, 2014 and December 30,
 2013, respectively, and these amounts are reflected within accrued
 salaries, wages and benefits in the consolidated balance
 sheets.

[0001193125-15-069683:notes:218]
Group health
 insurance and workers compensation benefits for the Company’s
 Asia Pacific operating segment are fully insured.

[0001193125-15-069683:notes:219]
Convertible Debt

[0001193125-15-069683:notes:220]
The
 accounting standards for convertible debt instruments that may be
 fully or partially settled in cash upon conversion require the debt
 and equity components to be separately accounted for in a manner
 that reflects the Company’s nonconvertible borrowing rate
 when interest expense is recognized in subsequent periods. The
 amount recorded as debt is based on the fair value of the debt
 component as a standalone instrument, determined using an average
 interest rate for similar nonconvertible debt issued by entities
 with credit ratings comparable to the Company’s at the time
 of issuance. The difference between the debt recorded at inception
 and its principal amount is to be accreted to principal through
 interest expense through the estimated life of the note.

[0001193125-15-069683:notes:221]
Derivatives
 are typically entered into as hedges for changes in interest rates,
 currency exchange rates, and other risks. When the Company
 determines to designate a derivative instrument as a cash flow
 hedge, the Company formally documents the hedging relationship and
 its risk management objective and strategy for undertaking the
 hedge, the hedging instrument, the hedged item, the nature of the
 risk being hedged, how the hedging instrument’s effectiveness
 in offsetting the hedged risk will be assessed, and a description
 of the method of measuring ineffectiveness. The Company also
 formally assesses, both at the hedge’s inception and on an
 ongoing basis, whether the derivative that is used in hedging
 transactions is highly effective in offsetting changes in cash
 flows of hedged items.

[0001193125-15-069683:notes:222]
Value
 Added and Sales Tax Collected from Customers

[0001193125-15-069683:notes:223]
As a part of
 the Company’s normal course of business, value added and
 sales taxes are collected from customers. Such taxes collected are
 remitted, in a timely manner, to the appropriate governmental tax
 authority on behalf of the customer. The Company’s policy is
 to present revenue and costs, net of value added and sales
 taxes.

[0001193125-15-069683:notes:224]
Fair
 Value Measures

[0001193125-15-069683:notes:225]
The Company
 measures at fair value certain of its financial and non-financial
 assets and liabilities by using a fair value hierarchy that
 prioritizes the inputs to valuation techniques used to measure fair
 value. Fair value is the price that would be received to sell an
 asset or paid to transfer a liability in an orderly transaction
 between market participants at the measurement date, essentially an
 exit price, based on the highest and best use of the asset or
 liability. The levels of the fair value hierarchy are:

[0001193125-15-069683:notes:226]
Level 1 — Quoted market prices in active
 markets for identical assets or liabilities;

[0001193125-15-069683:notes:227]
Level 2 — Significant other observable inputs
 (e.g., quoted prices for similar items in active markets, quoted
 prices for identical or similar items in markets that are not
 active, inputs other than quoted prices that are observable, such
 as interest rate and yield curves, and market-corroborated
 inputs); and

[0001193125-15-069683:notes:228]
Level 3 — Unobservable inputs in which there is
 little or no market data, which require the reporting unit to
 develop its own assumptions.

[0001193125-15-069683:notes:229]
Environmental Accrual

[0001193125-15-069683:notes:230]
Accruals for
 estimated costs for environmental obligations generally are
 recognized no later than the date when the Company identifies what
 cleanup measures, if any, are likely to be required to address the
 environmental condition. Included in such obligations are the
 estimated direct costs to investigate and address the conditions,
 and the associated engineering, legal and consulting costs. In
 making these estimates, the Company considers information that is
 currently available, existing technology, enacted laws and
 regulations, and its estimates of the timing of the required
 remedial actions. Such accruals are initially measured on a
 discounted basis — and are adjusted as further
 information becomes available or circumstances change —
 and are accreted to the payable amount over time.

[0001193125-15-069683:notes:231]
Earnings Per Share

[0001193125-15-069683:notes:232]
Basic
 earnings per common share excludes dilution and is computed by
 dividing net income attributable to TTM Technologies, Inc.
 stockholders by the weighted average number of common shares
 outstanding during the period. Diluted earnings per common share
 reflect the potential dilution that could occur if stock options or
 other common stock equivalents were exercised or converted into
 common stock. The dilutive effect of stock options or other common
 stock equivalents is calculated using the treasury stock
 method.

[0001193125-15-069683:notes:233]
Recently Adopted and Issued Accounting
 Standards

[0001193125-15-069683:notes:234]
In August
 2014, the Financial Accounting Standards Board (FASB) issued
 Accounting Standards Update No. (ASU) 2014-15 Disclosure of Uncertainties
 About an Entity’s Ability to Continue as a Going Concern,
 which provides guidance on determining when and how to disclose
 going concern uncertainties in the financial statements. The new
 standard requires management to perform interim and annual
 assessments of an entity’s ability to continue as a going
 concern. The update is effective for annual periods ending after
 December 15, 2016, and interim periods thereafter. Early
 adoption is permitted. The impact on the Company’s financial
 statements of adopting ASU 2014-15 is currently being assessed by
 management.

[0001193125-15-069683:notes:235]
In May 2014,
 the FASB issued ASU 2014-09, Revenue from Contracts with
 Customers, which requires an entity to recognize the amount of
 revenue to which it expects to be entitled for the transfer of
 promised goods or services to customers. The ASU will replace most
 existing revenue recognition guidance in U.S. GAAP when it becomes
 effective. The new standard is effective for the Company at the
 beginning of fiscal year 2017. Early application is not permitted.
 The standard permits the use of either the retrospective or
 cumulative effect transition method. The Company is evaluating the
 effect that ASU 2014-09 will have on its consolidated financial
 statements and related disclosures. The Company has not yet
 selected a transition method nor has it determined the effect of
 the standard on its ongoing financial reporting.

[0001193125-15-069683:notes:236]
In July 2013,
 the FASB issued an update that would require an unrecognized tax
 benefit, or a portion of an unrecognized benefit, to be presented
 in the financial statements as a reduction to a deferred tax asset
 for a net operating loss carryforward, a similar tax loss, or a tax
 credit carryforward. This update is effective for interim and
 annual periods beginning after December 15, 2013, with early
 adoption permitted. The Company adopted the amendment at the
 beginning of 2014, and its adoption did not have a material impact
 on its financial statements.


## us-gaap:AdditionalFinancialInformationDisclosureTextBlock

[0001193125-15-069683:notes:237]
| (3) | Composition of Certain Consolidated Financial Statement Captions |

[0001193125-15-069683:notes:238]
|  |  | As of |  |
|  |  | December 29, 2014 |  |  | December 30, 2013 |  |
|  |  | (In thousands) |  |
| Inventories: |  |  |  |  |
| Raw materials |  | $ | 44,477 |  |  | $ | 42,533 |  |
| Work-in-process |  |  | 57,544 |  |  |  | 48,338 |  |
| Finished goods |  |  | 43,166 |  |  |  | 47,274 |  |
|  |  | $ | 145,187 |  |  | $ | 138,145 |  |
| Property, plant and equipment, net: |  |  |  |  |  |  |  |  |
| Land and land use rights |  | $ | 31,093 |  |  | $ | 35,585 |  |
| Buildings and improvements |  |  | 247,404 |  |  |  | 252,998 |  |
| Machinery and equipment |  |  | 854,829 |  |  |  | 822,279 |  |
| Construction-in-progress |  |  | 31,850 |  |  |  | 32,494 |  |
| Furniture and fixtures and other |  |  | 11,677 |  |  |  | 11,538 |  |
|  |  |  | 1,176,853 |  |  |  | 1,154,894 |  |
| Less: Accumulated depreciation |  |  | (422,135 | ) |  |  | (344,222 | ) |
|  |  | $ | 754,718 |  |  | $ | 810,672 |  |
| Other accrued expenses: |  |  |  |  |  |  |  |  |
| Interest |  | $ | 581 |  |  | $ | 1,096 |  |
| Derivative liabilities |  |  | 5,062 |  |  |  | 1,650 |  |
| Income taxes payable |  |  | 4,923 |  |  |  | 7,159 |  |
| Accrued subcontractor charges |  |  | 3,796 |  |  |  | 2,836 |  |
| Accrued repair and maintenance |  |  | 1,970 |  |  |  | 2,475 |  |
| Accrued utilities |  |  | 5,006 |  |  |  | 5,994 |  |
| Other |  |  | 20,644 |  |  |  | 18,709 |  |
|  |  | $ | 41,982 |  |  | $ | 39,919 |  |


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001193125-15-069683:notes:239]
| (14) | Stock-Based Compensation |

[0001193125-15-069683:notes:240]
Incentive Compensation Plan

[0001193125-15-069683:notes:241]
The Company
 maintains the 2014 Incentive Compensation Plan (the Plan), which
 allows for the issuance of up to 5,288 shares through its
 expiration date of February 2024.

[0001193125-15-069683:notes:242]
The Plan
 provides for the grant of incentive stock options and nonqualified
 stock options to the Company’s key employees, non-employee
 directors and consultants. Other types of awards such as
 performance-based restricted stock units (PRUs), restricted stock
 units (RSUs), and stock appreciation rights are also permitted. The
 exercise price for options and awards is determined by the
 compensation committee of the board of directors and, for options
 intended to qualify as incentive stock options, may not be less
 than the fair market value as determined by the closing stock price
 at the date of the grant. Each option and award shall vest and
 expire as determined by the compensation committee of the board of
 directors, with options, PRUs and RSUs generally vesting over three
 years for employees and one year for non-employee directors.
 Options, PRUs and RSUs do not have voting rights. Options expire no
 later than ten years from the grant date. All grants provide for
 accelerated vesting if there is a change in control, as defined in
 the Plan. Upon the exercise of outstanding stock options or vesting
 of RSUs and PRUs, the Company’s practice is to issue new
 registered shares that are reserved for issuance under the
 Plan.

[0001193125-15-069683:notes:243]
As of
 December 29, 2014, 275 PRUs, 1,687 RSUs and 511 stock options
 were outstanding under the Plan. Included in the 1,687 RSUs
 outstanding as of December 29, 2014 are 251 vested but not yet
 released RSUs associated with non-employee directors. These RSUs
 vest over one year with release of the underlying shares of common
 stock deferred until retirement from the board of directors, (or
 until one year after retirement in the case of certain prior
 grants).

[0001193125-15-069683:notes:244]
Performance-based Restricted Stock
 Units

[0001193125-15-069683:notes:245]
The Company
 maintains a long-term incentive program for executives that
 provides for the issuance of PRUs, representing hypothetical shares
 of the Company’s common stock that may be issued. Under the
 PRU program, a target number of PRUs is awarded at the beginning of
 each three-year performance period. The number of shares of common
 stock released at the end of the performance period may range from
 zero to 2.4 times the target number depending on performance during
 the period. The performance metrics of the PRU program are based on
 (a) annual financial targets, which are based on revenue and
 EBITDA (earnings before interest, tax, depreciation, and
 amortization expense), each equally weighted, and (b) an
 overall modifier based on the Company’s total stockholder
 return (TSR) relative to the S&P SmallCap 600 for PRUs granted
 in 2012, and, for PRUs granted in 2013 and 2014, a group of peer
 companies selected by the Company’s compensation committee,
 over the three-year performance period.

[0001193125-15-069683:notes:246]
Under the PRU
 program, financial goals are set at the beginning of each fiscal
 year and performance is reviewed at the end of that year. The
 percentage to be applied to each participant’s target award
 ranges from zero to 160% based upon the extent to which the annual
 financial performance goals are achieved. If specific performance
 threshold levels for the annual financial goals are met, the amount
 earned for that element will be applied to one-third of the
 participants’ PRU award to determine the number of units
 earned.

[0001193125-15-069683:notes:247]
At the end of
 the three-year performance period, the total units earned, if any,
 are adjusted by applying a modifier, ranging from zero to 150%
 based on the Company’s TSR based on stock price changes
 relative to the TSR of S&P SmallCap 600 companies or a
 group of peer companies selected by the Company’s
 compensation committee, as appropriate, for the same three-year
 period.

[0001193125-15-069683:notes:248]
The TSR
 modifier is intended to ensure that there are limited or no payouts
 under the PRU program if the Company’s stock performance is
 significantly below the median TSR of S&P SmallCap
 600 companies or a group of peer companies selected by the
 Company’s compensation committee, as appropriate, over the
 three-year performance period. Where the annual financial goals
 have been met and where there has been strong relative TSR
 performance over the three-year performance period, the PRU program
 may provide substantial rewards to participants with a maximum
 payout of 2.4 times the initial PRU award. However, even if all of
 the annual financial metric goals are achieved in each of the three
 years, there will be no payouts if the Company’s stock
 performance is below that of the 20th percentile of S&P
 SmallCap 600 companies or of the group of peer companies
 selected by the Company’s compensation committee, as
 appropriate.

[0001193125-15-069683:notes:249]
Recipients of
 PRU awards generally must remain employed by the Company on a
 continuous basis through the end of the three-year performance
 period in order to receive any amount of the PRUs covered by that
 award. In events such as death, disability or retirement, the
 recipient may be entitled to pro-rata amounts of PRUs as defined in
 the Plan. Target shares subject to PRU awards do not have voting
 rights of common stock until earned and issued following the end of
 the three-year performance period.

[0001193125-15-069683:notes:250]
The Company
 records stock-based compensation expense for PRU awards granted
 based on management’s periodic assessment of the probability
 of the PRU awards vesting. As of December 29, 2014, management
 determined that vesting of the PRU awards was probable. PRU
 activity for the year ended December 29, 2014 was as
 follows:

[0001193125-15-069683:notes:251]
The fair
 value of PRUs granted is calculated using a Monte Carlo simulation
 model, as the TSR modifier contains a market condition. For the
 years ended 2014, 2013 and 2012, the following assumptions were
 used in determining the fair value:

[0001193125-15-069683:notes:252]
The expected
 term of the PRUs reflects the performance period for the PRUs
 granted. Expected volatility is calculated using the
 Company’s historical stock price. The risk-free interest rate
 for the expected term of PRUs is based on the U.S Treasury yield
 curve in effect at the time of grant.

[0001193125-15-069683:notes:253]
Restricted Stock Units

[0001193125-15-069683:notes:254]
The fair
 value of the Company’s RSUs is determined based upon the
 closing common stock price on the grant date. The fair value per
 unit of RSUs granted was $7.98, $8.17 and $11.89 for the years
 2014, 2013 and 2012, respectively. The total fair value of RSUs
 vested for the years 2014, 2013 and 2012 was $7,195, $7,878 and
 $6,467, respectively.

[0001193125-15-069683:notes:255]
Stock
 Options

[0001193125-15-069683:notes:256]
The Company
 did not grant any stock option awards during the years ended 2014,
 2013 or 2012. Option activity under the Plan for the year ended
 December 29, 2014 was as follows:

[0001193125-15-069683:notes:257]
The aggregate
 intrinsic values in the table above represent the total pretax
 intrinsic value (the difference between Company’s closing
 stock price on the last trading day of the 2014 fiscal year and the
 exercise price, multiplied by the number of in-the-money options)
 that would have been received by the option holders had all option
 holders exercised their options on December 29, 2014. This
 amount changes based on the fair market value of the
 Company’s stock. The total intrinsic value of options
 exercised for the years ended 2013 and 2012 was $117 and $58,
 respectively. There were no options exercised in 2014. The total
 fair value of the options vested for the years ended 2014, 2013 and
 2012 was $110, $143 and $325, respectively.

[0001193125-15-069683:notes:258]
Stock-based Compensation Expense and Unrecognized
 Compensation Costs

[0001193125-15-069683:notes:259]
The Company
 may become entitled to a deduction in its tax returns upon the
 future exercise of incentive stock options under certain
 circumstances; however, the value of this deduction will be
 recorded as an increase to additional paid-in capital and not as an
 income tax benefit. For the years ended 2014 and 2013, a net tax
 shortfall of $1,015 and $744, respectively, related to fully vested
 stock option awards exercised and vested RSUs was recorded as a
 decrease to additional paid-in capital. For the year ended 2012, a
 net tax benefit of $112, related to fully vested stock option
 awards exercised and vested restricted stock units was recorded as
 an increase to additional paid-in capital.


## us-gaap:FairValueDisclosuresTextBlock

[0001193125-15-069683:notes:260]
| (12) | Fair Value Measures |

[0001193125-15-069683:notes:261]
The Company
 measures at fair value its financial and non-financial assets by
 using a fair value hierarchy that prioritizes the inputs to
 valuation techniques used to measure fair value. Fair value is the
 price that would be received to sell an asset or paid to transfer a
 liability in an orderly transaction between market participants at
 the measurement date, essentially an exit price, based on the
 highest and best use of the asset or liability.

[0001193125-15-069683:notes:262]
The carrying
 amount and estimated fair value of the Company’s financial
 instruments as of December 29, 2014 and December 30, 2013
 were as follows:

[0001193125-15-069683:notes:263]
|  |  | As of December 29, 2014 |  |  | As of December 30, 2013 |  |
|  |  | Carrying Amount |  |  | Fair Value |  |  | Carrying Amount |  |  | Fair Value |  |
|  |  | (In thousands) |  |
| Available for sale securities |  |  | — |  |  |  | — |  |  | $ | 148 |  |  | $ | 148 |  |
| Derivative assets, current |  |  | — |  |  |  | — |  |  |  | 647 |  |  |  | 647 |  |
| Derivative assets, non-current |  |  | — |  |  |  | — |  |  |  | 10 |  |  |  | 10 |  |
| Derivative liabilities, current |  | $ | 5,062 |  |  | $ | 5,062 |  |  |  | 1,650 |  |  |  | 1,650 |  |
| Derivative liabilities, non-current |  |  | — |  |  |  | — |  |  |  | 1,288 |  |  |  | 1,288 |  |
| Long-term debt |  |  | 273,804 |  |  |  | 273,820 |  |  |  | 370,008 |  |  |  | 369,402 |  |
| Convertible senior notes due 2015 |  |  | 31,841 |  |  |  | 32,631 |  |  |  | 36,568 |  |  |  | 39,960 |  |
| Convertible senior notes due 2020 |  |  | 197,042 |  |  |  | 241,875 |  |  |  | 167,167 |  |  |  | 237,050 |  |

[0001193125-15-069683:notes:264]
The fair value
 of available for sale securities was determined using quoted market
 prices for the securities on an active exchange.

[0001193125-15-069683:notes:265]
The fair value
 of the derivative instruments was determined using pricing models
 developed based on the LIBOR swap rate, foreign currency exchange
 rates, and other observable market data, including quoted market
 prices, as appropriate. The values were adjusted to reflect
 nonperformance risk of the counterparty and the Company, as
 necessary.

[0001193125-15-069683:notes:266]
The fair value
 of the long-term debt was estimated based on discounting the debt
 over its life using current market rates for similar debt as of
 December 29, 2014 and December 30, 2013, which are
 considered Level 1 inputs.

[0001193125-15-069683:notes:267]
The fair value
 of the convertible senior notes was estimated based on quoted
 market prices of the securities on an active exchange, which are
 considered Level 1 inputs.

[0001193125-15-069683:notes:268]
As of
 December 29, 2014 and December 30, 2013, the
 Company’s other financial instruments also included cash and
 cash equivalents, accounts receivable, accounts payable and
 equipment payables. Due to short-term maturities, the carrying
 amount of these instruments approximates fair value.

[0001193125-15-069683:notes:269]
There were no
 transfers of financial assets or liabilities between Level 1
 and Level 2 inputs for the years ended 2014 and
 2013.

[0001193125-15-069683:notes:270]
The majority of
 the Company’s non-financial assets and liabilities, which
 include goodwill, intangible assets, inventories, and property,
 plant and equipment, are not required to be carried at fair value
 on a recurring basis. However, if certain triggering events occur
 (or are tested at least annually for goodwill) such that a
 non-financial instrument is required to be evaluated for
 impairment, based upon a comparison of the non-financial
 instrument’s fair value to its carrying value, an impairment
 is recorded to reduce the carrying value to the fair value, if the
 carrying value exceeds the fair value.

[0001193125-15-069683:notes:271]
The fair values
 of long-lived assets held and used and the assets held for sale
 were primarily determined using appraisals and comparable prices of
 similar assets, which are considered to be Level 2
 inputs.

[0001193125-15-069683:notes:272]
The fair value
 of goodwill and definite-lived intangible assets were determined
 using a combination of the income approach and the market approach
 as considered necessary, which are considered to be Level 3
 inputs.


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0001193125-15-069683:notes:273]
| (15) | Employee Benefit and Deferred Compensation Plans |

[0001193125-15-069683:notes:274]
The Company has
 three separate retirement benefit plans: one in North America and
 two in Asia Pacific. In North America, the Company has a 401(k)
 savings plan (the Savings Plan) in which eligible full-time
 employees can participate and contribute a percentage of
 compensation subject to the maximum allowed by the Internal Revenue
 Service. The Savings Plan provides for a partial match by the
 employer of the first 5% of employee contributions (100% of the
 first 3% and 50% of the following 2% of employee contributions). In
 Asia Pacific, the Company contributes to either separate
 trust-administered funds or various government-sponsored pension
 plans on a mandatory basis. For all retirement plans, the Company
 has no further payment obligation once the required contributions
 have been made. The Company recorded contributions to retirement
 benefit plans of $18,953, $14,987 and $14,452 during the years
 ended 2014, 2013, 2012, respectively.

[0001193125-15-069683:notes:275]
The Company
 also maintains a deferred compensation plan (the Compensation
 Plan). The Compensation Plan is an unfunded, nonqualified deferred
 compensation plan and is limited to selected employees, including
 our named executive officers and our directors. The Compensation
 Plan allows participants to defer up to 100% of their annual bonus
 and between 5% and 100% of their annual director fees. Amounts
 deferred under the Compensation Plan will be credited to accounts
 maintained by the Company for each participant and will be credited
 or debited with the participant’s proportionate share of any
 gains or losses attributable to the performance of investment
 options selected by the participant.


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0001193125-15-069683:notes:276]
| (10) | Accumulated Other Comprehensive Income |

[0001193125-15-069683:notes:277]
Foreign
 currency translation gains, summarized above, are reported net of
 tax of $2,979, $3,132, and $2,959 as of December 29,
 2014, December 30, 2013 and December 31, 2012,
 respectively.

[0001193125-15-069683:notes:278]
The following
 provides a summary of reclassifications out of accumulated other
 comprehensive income, net of tax for the year ended
 December 29, 2014 and December 30, 2013:

[0001193125-15-069683:notes:279]
|  |  |  |  | Amount Reclassified from Accumulated Other Comprehensive Income For the Year Ended |  |
| Details about Accumulated Other Comprehensive Income Components |  | Statement of Operations Location |  | December 29, 2014 |  |  | December 30, 2013 |  |
| Loss on cash flow hedges |  | Depreciation expense, net of tax |  | $ | 146 |  |  | $ | 128 |  |
| Loss on available for sale securities |  | Other, net, net of tax |  | $ | 83 |  |  | $ | 53 |  |
| Gain on foreign currency translation |  | Gain on sale of assets, net of tax |  | $ | — |  |  | $ | (14,266 | ) |


## ttmi:ScheduleOfLiabilityAndEquityComponentsOfConvertibleNotesTableTextBlock

[0001193125-15-069683:notes:280]
As of
 December 29, 2014 and December 30, 2013, the following
 summarizes the liability and equity components of the convertible
 senior notes:

[0001193125-15-069683:notes:281]
|  |  | As of December 29, 2014 |  |  | As of December 30, 2013 |  |
|  |  | Principal |  |  | Unamortized Discount |  |  | Net Carrying Amount |  |  | Principal |  |  | Unamortized Discount |  |  | Net Carrying Amount |  |
|  |  | (in thousands) |  |
| Liability components: |  |  |  |  |
| Convertible Senior Notes due 2020 |  | $ | 250,000 |  |  | $ | (52,958 | ) |  | $ | 197,042 |  |  | $ | 220,000 |  |  | $ | (52,833 | ) |  | $ | 167,167 |  |
| Convertible Senior Notes due 2015 |  |  | 32,395 |  |  |  | (554 | ) |  |  | 31,841 |  |  |  | 38,909 |  |  |  | (2,341 | ) |  |  | 36,568 |  |
| Total |  | $ | 282,395 |  |  | $ | (53,512 | ) |  | $ | 228,883 |  |  | $ | 258,909 |  |  | $ | (55,174 | ) |  | $ | 203,735 |  |

[0001193125-15-069683:notes:282]
|  |  | As of December 29, 2014 |  |  | As of December 30, 2013 |  |
|  |  | Embedded conversion option — Convertible Senior Notes |  |  | Embedded conversion option — Convertible Senior Notes Issuance Costs |  |  | Total |  |  | Embedded conversion option — Convertible Senior Notes |  |  | Embedded conversion option — Convertible Senior Notes Issuance Costs |  |  | Total |  |
|  |  | (in thousands) |  |
| Equity components: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Additional paid-in capital: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Convertible Senior Notes due 2020 |  | $ | 60,227 |  |  | $ | (1,916 | ) |  | $ | 58,311 |  |  | $ | 53,000 |  |  | $ | (1,644 | ) |  | $ | 51,356 |  |
| Convertible Senior Notes due 2015 |  |  | 39,781 |  |  |  | (1,413 | ) |  |  | 38,368 |  |  |  | 39,928 |  |  |  | (1,413 | ) |  |  | 38,515 |  |
|  |  | $ | 100,008 |  |  | $ | (3,329 | ) |  | $ | 96,679 |  |  | $ | 92,928 |  |  | $ | (3,057 | ) |  | $ | 89,871 |  |


## ttmi:DistributionOfProfitsDisclosureTextBlock

[0001193125-15-069683:notes:283]
| (17) | Distribution of profits |

[0001193125-15-069683:notes:284]
As stipulated by
 the relevant laws and regulations of China applicable to the
 Company’s subsidiaries in China, each of such subsidiaries is
 required to make appropriations from its net income as determined
 in accordance with accounting principles and the relevant financial
 regulations of China (PRC GAAP) to a non-distributable reserve,
 also referred to as statutory surplus reserve. The appropriations
 to the statutory surplus reserve are required to be made at not
 less than 10% of the profit after tax as determined under PRC GAAP
 and are required until the balance reaches 50% of its registered
 capital. The statutory surplus reserve is used to offset future or
 past losses. These Chinese subsidiaries may, upon a resolution
 passed by their respective shareholders, convert the statutory
 surplus reserve into capital.

[0001193125-15-069683:notes:285]
There were
 appropriations of approximately $2,544, $3,526 and $8,145 to the
 statutory surplus reserve of the Company’s Chinese
 subsidiaries for the years ended 2014, 2013 and 2012,
 respectively.


## ttmi:ScheduleOfComponentsOfInterestExpenseFromConvertibleNotesTableTextBlock

[0001193125-15-069683:notes:286]
The components
 of interest expense resulting from the convertible senior notes for
 the years ended 2014, 2013 and 2012 are as follows:

[0001193125-15-069683:notes:287]
|  |  | For the Year Ended |  |
|  |  | December 29, 2014 |  |  | December 30, 2013 |  |  | December 31, 2012 |  |
|  |  | (In thousands) |  |
| Contractual coupon interest |  |  |  |  |  |  |  |  |  |  |  |  |
| Convertible Senior Notes due 2020 |  | $ | 4,367 |  |  | $ | 107 |  |  |  | — |  |
| Convertible Senior Notes due 2015 |  |  | 1,053 |  |  |  | 5,559 |  |  | $ | 5,688 |  |
|  |  | $ | 5,420 |  |  | $ | 5,666 |  |  | $ | 5,688 |  |
| Amortization of debt discount |  |  |  |  |  |  |  |  |  |  |  |  |
| Convertible Senior Notes due 2020 |  | $ | 7,102 |  |  | $ | 167 |  |  |  | — |  |
| Convertible Senior Notes due 2015 |  |  | 1,395 |  |  |  | 6,780 |  |  | $ | 6,380 |  |
|  |  | $ | 8,497 |  |  | $ | 6,947 |  |  | $ | 6,380 |  |
| Amortization of debt issuance costs |  |  |  |  |  |  |  |  |  |  |  |  |
| Convertible Senior Notes due 2020 |  | $ | 712 |  |  | $ | 16 |  |  |  | — |  |
| Convertible Senior Notes due 2015 |  |  | 141 |  |  |  | 684 |  |  | $ | 644 |  |
|  |  | $ | 853 |  |  | $ | 700 |  |  | $ | 644 |  |


## ttmi:DividendsTextBlock

[0001193125-15-069683:notes:288]
| (22) | Dividend |

[0001193125-15-069683:notes:289]
During the year
 ended December 31, 2012, one of the Company’s
 majority-owned foreign subsidiaries declared a dividend in the
 amount of approximately $47,600, which included $9,501 paid to its
 non-controlling interest shareholder during the year ended
 December 31, 2012.


## ttmi:RestructuringCostsAndAssetImpairmentsTableTextBlock

[0001193125-15-069683:notes:290]
| (5) | Impairment and Restructuring Charges |

[0001193125-15-069683:notes:291]
Closure
 of Suzhou, China Facility

[0001193125-15-069683:notes:292]
The Company
 announced its plan to cease manufacturing at its Suzhou, China
 facility in 2013. As a result, the Company determined that certain
 long-lived assets were impaired and as such, recorded charges of
 $1,845 and $10,782 for the years ended December 29, 2014 and
 December 30, 2013, respectively, primarily related to
 machinery and equipment held for sale.

[0001193125-15-069683:notes:293]
Additionally,
 as a result of the shutdown, the Company laid-off 774 employees at
 this site and recorded $3,445 in employee separation costs for the
 year ended December 30, 2013. These costs were classified as
 restructuring charges in the consolidated statement of operations.
 As of December 29, 2014, substantially all employees had been
 separated.

[0001193125-15-069683:notes:294]
During the
 fourth quarter of 2014, the Company commenced the process of
 selling the Suzhou, China facility and therefore, the Company
 reclassified its remaining assets, consisting primarily of property
 plant and equipment, to assets held for sale, for which the current
 carrying value approximates fair value less costs to sell at
 December 29, 2014. Subsequent to December 29, 2014, the
 Company sold this facility for approximately $21,300.

[0001193125-15-069683:notes:295]
The Suzhou,
 China manufacturing facility is included in the Asia Pacific
 reporting unit and operating segment.

[0001193125-15-069683:notes:296]
Other
 Impairment

[0001193125-15-069683:notes:297]
During the year
 ended December 31, 2012, in conjunction with the evaluation of
 goodwill and definite-lived intangibles described in Note 4, the
 Company recorded a charge for the impairment of long-lived assets
 in the amount of $18,082, specifically for two real estate assets
 related to the Asia Pacific reporting unit, which is also the Asia
 Pacific operating segment. The long-lived asset impairment charge
 was incurred to reduce the carrying value of these two real estate
 assets to their fair value due to current and expected
 underutilization and limited market demand.


## ttmi:ConvertibleSeniorNotesTextBlock

[0001193125-15-069683:notes:298]
| (7) | Convertible Senior Notes |

[0001193125-15-069683:notes:299]
The
 components of interest expense resulting from the convertible
 senior notes for the years ended 2014, 2013 and 2012 are as
 follows:

[0001193125-15-069683:notes:300]
As of
 December 29, 2014 and December 30, 2013, remaining
 unamortized debt issuance costs included in other non-current
 assets were $5,363 and $5,399, respectively. The debt issuance
 costs and debt discount are being amortized to interest expense
 over the term of the convertible senior notes using the effective
 interest rate method. At December 29, 2014, the remaining
 weighted average amortization period for the unamortized senior
 convertible note discount and debt issuance costs was
 5.9 years.

[0001193125-15-069683:notes:301]
For the years
 ended 2014, 2013 and 2012, the amortization of the convertible
 senior notes due 2015 debt discount and debt issuance costs is
 based on an effective interest rate of 8.37%. For the years ended
 2014 and 2013, the amortization of the convertible senior notes due
 2020 debt discount and debt issuance costs is based on an effective
 interest rate of 6.48%.

[0001193125-15-069683:notes:302]
Convertible Senior Notes due 2020

[0001193125-15-069683:notes:303]
In December
 2013, the Company issued 1.75% convertible senior notes due
 December 15, 2020, in a public offering for an aggregate
 principal amount of $220,000. The convertible senior notes bear
 interest at a rate of 1.75% per annum. Interest is payable
 semiannually in arrears on June 15 and December 15 of
 each year. The convertible senior notes are senior unsecured
 obligations and rank equally to the Company’s future
 unsecured senior indebtedness and senior in right of payment to any
 of the Company’s future subordinated indebtedness.

[0001193125-15-069683:notes:304]
In January
 2014, the Company closed the sale of an additional $30,000
 aggregate principal amount of its 1.75% convertible senior notes
 due 2020 (Additional Notes). The Additional Notes were sold
 pursuant to the exercise of an over-allotment option granted by the
 Company in the underwriting agreement related to the offer and sale
 of $220,000 aggregate principal amount of its 1.75% convertible
 senior notes due 2020.

[0001193125-15-069683:notes:305]
Conversion:    At any time
 prior to March 15, 2020, holders may convert their convertible
 senior notes into cash and, if applicable, into shares of the
 Company’s common stock based on a conversion rate of
 103.7613 shares of the Company’s common stock per $1
 principal amount of convertible senior notes, subject to
 adjustment, under the following circumstances: (1) during any
 calendar quarter beginning after March 31, 2014 (and only
 during such calendar quarter), if the last reported sale price of
 our common stock for at least 20 trading days during the 30
 consecutive trading days ending on the last trading day of the
 immediately preceding calendar quarter is greater than or equal to
 130% of the applicable conversion price on each applicable trading
 day of such preceding calendar quarter; (2) during the five
 business day period after any 10 consecutive trading day period in
 which the trading price per note for each day of that 10
 consecutive trading day period was less than 98% of the product of
 the last reported sale price of the Company’s common stock
 and the conversion rate on such day; or (3) upon the
 occurrence of specified corporate transactions described in the
 indenture governing the notes. As of December 29, 2014, none
 of the conversion criteria had been met.

[0001193125-15-069683:notes:306]
On or after
 March 15, 2020 until the close of business on the third
 scheduled trading day preceding the maturity date, holders may
 convert their notes at any time, regardless of the foregoing
 circumstances. Upon conversion, for each $1 principal amount of
 notes, the Company will pay shares of our common stock, cash or a
 combination of cash and shares of our common stock at its election,
 if applicable, based on a daily conversion value calculated on a
 proportionate basis for each day of the 80 trading day observation
 period. All conversions occurring on the same date or on or after
 March 15, 2020 shall be settled using the same settlement
 method. Additionally, in the event of a fundamental change as
 defined in the indenture governing the notes, or other conversion
 rate adjustments such as share splits or combinations, other
 distributions of shares, cash or other assets to stockholders,
 including self-tender transactions (Other Conversion Rate
 Adjustments), the conversion rate may be modified to adjust the
 number of shares per $1 principal amount of the notes. As of
 December 29, 2014, none of the criteria for a fundamental
 change or a conversion rate adjustment had been met.

[0001193125-15-069683:notes:307]
The maximum
 number of shares issuable upon conversion, including the effect of
 a fundamental change and subject to Other Conversion Rate
 Adjustments, would be 32,425.

[0001193125-15-069683:notes:308]
Note
 Repurchase:    The Company is not
 permitted to redeem the convertible senior notes at any time prior
 to maturity. In the event of a fundamental change or certain
 default events, as defined in the indenture governing the notes,
 holders may require the Company to repurchase for cash all or a
 portion of their convertible senior notes at a price equal to 100%
 of the principal amount, plus any accrued and unpaid
 interest.

[0001193125-15-069683:notes:309]
Convertible Note Hedge and Warrant
 Transaction:    In connection with the
 issuance of the convertible senior notes due 2020 in both December
 2013 and January 2014, the Company entered into a convertible note
 hedge and warrant transaction (Call Spread Transaction), with
 respect to the Company’s common stock. The convertible note
 hedge, which cost an aggregate $66,275 and was recorded, net of
 tax, as a reduction of additional paid-in capital, consists of the
 Company’s option to purchase up to 25,940 common stock shares
 at a price of $9.64 per share. The hedge expires on
 December 15, 2020 and can only be executed upon the conversion
 of the above mentioned convertible senior notes due 2020.
 Additionally, the Company sold warrants in both December 2013 and
 January 2014 to purchase 25,940 shares of its common stock at
 a price of $14.26 per share. The warrants expire ratably from March
 2021 through January 2022. The aggregate proceeds from the sale of
 warrants of $33,775 were recorded as an addition to additional
 paid-in capital. The 2020 Call Spread Transaction has no effect on
 the terms of the convertible senior notes due 2020 and reduces
 potential dilution by effectively increasing the conversion price
 of the convertible senior notes due 2020 to $14.26 per share of the
 Company’s common stock.

[0001193125-15-069683:notes:310]
Convertible Senior Notes due 2015

[0001193125-15-069683:notes:311]
In May 2008,
 the Company issued 3.25% convertible senior notes due
 May 15, 2015, in a public offering for an aggregate principal
 amount of $175,000. The convertible senior notes bear interest at a
 rate of 3.25% per annum. Interest is payable semiannually in
 arrears on May 15 and November 15 of each year. The
 convertible senior notes are senior unsecured obligations and rank
 equally to the Company’s future unsecured senior indebtedness
 and senior in right of payment to any of the Company’s future
 subordinated indebtedness.

[0001193125-15-069683:notes:312]
Note
 Repurchase:    In December 2013, the
 Company repurchased $136,091 of notes at approximately 103.4% of
 their principal amount. Additionally, in January 2014, the Company
 repurchased $6,541 of notes at approximately 103.4% of their
 principal amount. The repurchases were accounted for as
 extinguishments of debt and, accordingly, the Company recognized
 losses of approximately $506 for the year ended December 29,
 2014 and $10,743 for the year ended December 30, 2013,
 primarily associated with the premium paid to repurchase the
 convertible senior notes and the recognition of related unamortized
 debt discount and issuance costs.

[0001193125-15-069683:notes:313]
The Company
 is not permitted to redeem the convertible senior notes at any time
 prior to maturity. In the event of a fundamental change or certain
 default events, as defined in the indenture governing the notes,
 holders may require the Company to repurchase for cash all or a
 portion of their convertible senior notes at a price equal to 100%
 of the principal amount, plus any accrued and unpaid
 interest.

[0001193125-15-069683:notes:314]
Conversion:    On or after
 November 15, 2014, until the close of business on the third
 scheduled trading day preceding the maturity date, holders may
 convert their notes at any time. Upon conversion, for each $1
 principal amount of notes, the Company will pay cash for the lesser
 of the conversion value or $1 and shares of our common stock, if
 any, based on a daily conversion value calculated on a
 proportionate basis for each day of the 60 trading day observation
 period. Additionally, in the event of a fundamental change as
 defined in the indenture governing the notes, or other conversion
 rate adjustments such as share splits or combinations, other
 distributions of shares, cash or other assets to stockholders,
 including self-tender transactions (Other Conversion Rate
 Adjustments), the conversion rate may be modified to adjust the
 number of shares per $1 principal amount of the notes. As of
 December 29, 2014, holders may convert their notes at any
 time; however none of the criteria for a fundamental change or a
 conversion rate adjustment had been met.

[0001193125-15-069683:notes:315]
The maximum
 number of shares issuable upon conversion, including the effect of
 a fundamental change and subject to Other Conversion Rate
 Adjustments, would be 2,587.
