# TTMI note change history — 0001193125-14-295293 → 0001193125-14-404493


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2014-11-10):
[0001193125-14-404493:note_history:1]
The
 Company is subject to various legal matters, which it considers
 normal for its business activities. While the Company currently
 believes that the amount of any reasonably possible or probable
 loss for known matters would not be material to the Company’s
 financial condition, the outcome of these actions is inherently
 difficult to predict. In the event of an adverse outcome, the
 ultimate potential loss could have a material adverse effect on the
 Company’s financial condition or results of operations in a
 particular period. The Company has accrued amounts for its loss
 contingencies which are probable and estimable at
 September 29, 2014 and December 30, 2013. However, these
 amounts are not material to the consolidated condensed financial
 statements of the Company.
  (was, 2014-08-05, similarity 0.9915):
[0001193125-14-295293:note_history:1]
The Company is subject to various legal matters, which it
 considers normal for its business activities. While the Company
 currently believes that the amount of any reasonably possible or
 probable loss for known matters would not be material to the
 Company’s financial condition, the outcome of these actions
 is inherently difficult to predict. In the event of an adverse
 outcome, the ultimate potential loss could have a material adverse
 effect on the Company’s financial condition or results of
 operations in a particular period. The Company has accrued amounts
 for its loss contingencies which are probable and estimable at
 June 30, 2014 and December 30, 2013. However, these
 amounts are not material to the consolidated condensed financial
 statements of the Company.

- added (2014-11-10):
[0001193125-14-404493:note_history:2]
Class Action Complaints
 related to Viasystems Acquisition

- added (2014-11-10):
[0001193125-14-404493:note_history:3]
Since
 the public announcement on September 22, 2014 of the execution
 of the Merger Agreement, Viasystems, TTM, Merger Sub, and the
 members of the Viasystems Board have been named as defendants in
 two putative class action complaints challenging the Merger. The
 first lawsuit, filed in the Circuit Court of St. Louis County,
 Missouri on September 30, 2014 (the Missouri Lawsuit), and the
 second lawsuit, filed in the Court of Chancery of the State of
 Delaware on October 13, 2014 (the Delaware Lawsuit and,
 together with the Missouri Lawsuit, the Lawsuits), generally allege
 that the Merger fails to properly value Viasystems, that the
 individual defendants breached their fiduciary duties in approving
 the Merger Agreement, and that those breaches were aided and
 abetted by TTM, Merger Sub, and Viasystems.

- added (2014-11-10):
[0001193125-14-404493:note_history:4]
The
 Delaware Lawsuit specifically alleges, among other allegations,
 that (1) the Viasystems Board breached its fiduciary duties
 by: (a) agreeing to the Merger for grossly inadequate
 consideration, (b) agreeing to lock up the Merger with deal
 protection devices that prevent other bidders from making a
 successful competing offer for Viasystems, and
 (c) participating in a transaction where the loyalties of the
 Viasystems Board and management are divided; (2) the voting
 agreements entered into between the Company and certain of
 Viasystems’ significant stockholders prevent Viasystems
 stockholders from providing a meaningful vote on the proposal to
 adopt the Merger; and (3) that those breaches of fiduciary
 duties were aided and abetted by TTM, Merger Sub, and Viasystems.
 Further, the Missouri Lawsuit specifically alleges, among other
 allegations, that (1) the proposed Merger is unfair and the
 consideration to be paid in connection with the Merger is
 inadequate; (2) the Viasystems Board and Viasystems’
 management have a conflict of interest due to the cash pool bonus
 and change in control payments to be made to certain executive
 officers and key employees if the Merger is consummated; and
 (3) the Merger Agreement contains impermissible deal
 protection devices.

- added (2014-11-10):
[0001193125-14-404493:note_history:5]
The
 Lawsuits seek injunctive relief to enjoin the defendants from
 completing the Merger on the agreed-upon terms, rescinding, to the
 extent already implemented, the Merger Agreement or any of the
 terms therein, costs and disbursements and attorneys’ and
 experts’ fees and costs, as well as other equitable relief as
 the respective court deems proper. The Delaware Lawsuit also seeks:
 (1) in the event the Merger is consummated prior to the entry
 of the court’s final judgment, rescissory damages as an
 alternative to rescission, and (2) an accounting by all
 defendants to the plaintiff and other members of the class for all
 damages caused by the defendants and for all profits and any
 special benefits obtained as a result of their alleged breaches of
 their fiduciary duties. TTM believes the Lawsuits are without
 merit.

- changed (2014-11-10):
[0001193125-14-404493:note_history:6]
The
 process to manufacture PCBs requires adherence to city, county,
 state, federal and foreign environmental regulations regarding the
 storage, use, handling and disposal of chemicals, solid wastes and
 other hazardous materials as well as compliance with air quality
 standards and chemical use reporting. The Company believes that its
 facilities in the United States comply in all material respects
 with applicable environmental laws and regulations. In China,
 governmental authorities have adopted new rules and regulations
 governing environmental issues. An update to Chinese
 environmental water waste law was issued in late 2012, but allows
 for an interim period in which plants subject to such law may
 install equipment that meets the new regulatory regime and come
 into full compliance with the new laws in 2014 and 2015, depending
 on the province of China in which such plant is located. The
 Company’s plants in China are not yet in full compliance with
 the newly adopted environmental regulations as updated in late
 2012. The Company expects to come into compliance and does not
 anticipate any immediate risk of government fines or temporary
 closure of its Chinese plants. The Company has established and
 enacted an investment plan, which includes capital expenditures
 estimated to be approximately $15, 000 through 2015, to address the
 regulatory changes in order to come into full compliance during the
 interim period.
  (was, 2014-08-05, similarity 0.8362):
[0001193125-14-295293:note_history:6]
The process to manufacture PCBs requires adherence to city,
 county, state, federal and foreign environmental regulations
 regarding the storage, use, handling and disposal of chemicals,
 solid wastes and other hazardous materials as well as compliance
 with air quality standards. The Company believes that its
 facilities in the United States comply in all material respects
 with applicable environmental laws and regulations. In China,
 governmental authorities are taking various steps to tighten the
 rules and regulations governing environmental issues. An
 update to Chinese environmental law was issued in late 2012, but
 allows for an interim period in which foreign entities may adjust
 to the new regulatory regime and come into full compliance with the
 new laws. The Company’s plants in China are not yet in
 full compliance with the current environmental regulations as
 updated in late 2012. The Company expects to come into
 compliance and does not anticipate any immediate risk of government
 fines or temporary closure of its Chinese plants. The Company
 has established and enacted an investment plan, which includes
 capital expenditures estimated to be approximately $10,000 for
 2014, to address the regulatory changes in order to come into full
 compliance during the interim period.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2014-11-10):
[0001193125-14-404493:note_history:7]
The accompanying consolidated condensed financial statements
 have been prepared by the Company, without audit, pursuant to the
 rules and regulations of the Securities and Exchange Commission
 (SEC). Certain information and disclosures normally included in
 financial statements prepared in accordance with accounting
 principles generally accepted in the United States of America have
 been condensed or omitted pursuant to such rules and regulations.
 These consolidated condensed financial statements reflect all
 adjustments (consisting only of normal recurring adjustments)
 which, in the opinion of management, are necessary to present
 fairly the financial position, the results of operations and cash
 flows of the Company for the periods presented. It is suggested
 that these consolidated condensed financial statements be read in
 conjunction with the consolidated financial statements and the
 notes thereto included in the Company’s most recent Annual
 Report on Form 10-K. The results of operations for the interim
 periods are not necessarily indicative of the results to be
 expected for the full year. The preparation of financial statements
 in accordance with U.S. generally accepted accounting principles
 requires management to make estimates and assumptions that affect
 the amounts reported in the Company’s consolidated condensed
 financial statements and accompanying notes. Actual results could
 differ materially from those estimates. The Company uses a 13-week
 fiscal quarter accounting period with the fourth quarter ending on
 the Monday nearest December 31.
  (was, 2014-08-05, similarity 0.9987):
[0001193125-14-295293:note_history:7]
The accompanying consolidated condensed financial statements
 have been prepared by the Company, without audit, pursuant to the
 rules and regulations of the Securities and Exchange Commission
 (SEC). Certain information and disclosures normally included in
 financial statements prepared in accordance with accounting
 principles generally accepted in the United States of America have
 been condensed or omitted pursuant to such rules and regulations.
 These consolidated condensed financial statements reflect all
 adjustments (consisting only of normal recurring adjustments)
 which, in the opinion of management, are necessary to present
 fairly the financial position, the results of operations and cash
 flows of the Company for the periods presented. It is suggested
 that these consolidated condensed financial statements be read in
 conjunction with the consolidated financial statements and the
 notes thereto included in the Company’s most recent Annual
 Report on Form 10-K. The results of operations for the interim
 periods are not necessarily indicative of the results to be
 expected for the full year. The preparation of financial statements
 in accordance with U.S. generally accepted accounting principles
 requires management to make estimates and assumptions that affect
 the amounts reported in the Company’s consolidated condensed
 financial statements and accompanying notes. Actual results could
 differ materially from those estimates. The Company uses a 13-week
 fiscal quarter accounting period with fourth quarter ending on the
 Monday nearest December 31.

- changed (2014-11-10):
[0001193125-14-404493:note_history:8]
On May 28, 2014, the Financial Accounting Standards Board
 (FASB) issued Accounting Standards Update No. (ASU) 2014-09,
 Revenue from Contracts with Customers, which requires an
 entity to recognize the amount of revenue to which it expects to be
 entitled for the transfer of promised goods or services to
 customers. The ASU will replace most existing revenue recognition
 guidance in U.S. GAAP when it becomes effective. The new standard
 is effective for the Company at the beginning of fiscal year 2017.
 Early application is not permitted. The standard permits the use of
 either the retrospective or cumulative effect transition method.
 The Company is evaluating the effect that ASU 2014-09 will have on
 its consolidated financial statements and related disclosures. The
 Company has not yet selected a transition method nor has it
 determined the effect of the standard on its ongoing financial
 reporting.
  (was, 2014-08-05, similarity 0.9765):
[0001193125-14-295293:note_history:8]
On May 28, 2014, the Financial Accounting Standards Board
 (FASB) issued Accounting Standards Update No. (ASU) 2014-09,
 Revenue from Contracts with Customers, which requires an
 entity to recognize the amount of revenue to which it expects to be
 entitled for the transfer of promised goods or services to
 customers. The ASU will replace most existing revenue recognition
 guidance in U.S. GAAP when it becomes effective. The new standard
 is effective for the Company on January 1, 2017. Early
 application is not permitted. The standard permits the use of
 either the retrospective or cumulative effect transition method.
 The Company is evaluating the effect that ASU 2014-09 will have on
 its consolidated financial statements and related disclosures. The
 Company has not yet selected a transition method nor has it
 determined the effect of the standard on its ongoing financial
 reporting.


## ttmi:ConvertibleSeniorNotesTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2014-11-10):
[0001193125-14-404493:note_history:9]
As of September 29, 2014 and December 30, 2013, the
 following summarizes the liability and equity components of the
 convertible senior notes:
  (was, 2014-08-05, similarity 0.9569):
[0001193125-14-295293:note_history:9]
As of June 30, 2014 and December 30, 2013, the
 following summarizes the liability and equity components of the
 convertible senior notes:

- changed (2014-11-10):
[0001193125-14-404493:note_history:10]
|  |  | As of September 29, 2014 |  |  | As of December 30, 2013 |  |
|  |  | Principal |  |  | Unamortized Discount |  |  | Net Carrying Amount |  |  | Principal |  |  | Unamortized Discount |  |  | Net Carrying Amount |  |
|  |  | (in thousands) |  |
| Liability components: |  |  |  |  |
| Convertible senior notes due 2020 |  | $ | 250,000 |  |  | $ | (54,766 | ) |  | $ | 195,234 |  |  | $ | 220,000 |  |  | $ | (52,833 | ) |  | $ | 167,167 |  |
| Convertible senior notes due 2015 |  |  | 32,395 |  |  |  | (914 | ) |  |  | 31,481 |  |  |  | 38,909 |  |  |  | (2,341 | ) |  |  | 36,568 |  |
| Total |  | $ | 282,395 |  |  | $ | (55,680 | ) |  | $ | 226,715 |  |  | $ | 258,909 |  |  | $ | (55,174 | ) |  | $ | 203,735 |  |
|  |  | As of September 29, 2014 |  |  | As of December 30, 2013 |  |
|  |  | Embedded conversion option — Convertible Senior Notes |  |  | Embedded conversion option — Convertible Senior Notes Issuance Costs |  |  | Total |  |  | Embedded conversion option — Convertible Senior Notes |  |  | Embedded conversion option — Convertible Senior Notes Issuance Costs |  |  | Total |  |
|  |  | (in thousands) |  |
| Equity components: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Additional paid-in capital: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Convertible senior notes due 2020 |  | $ | 60,227 |  |  | $ | (1,916 | ) |  | $ | 58,311 |  |  | $ | 53,000 |  |  | $ | (1,644 | ) |  | $ | 51,356 |  |
| Convertible senior notes due 2015 |  |  | 39,781 |  |  |  | (1,413 | ) |  |  | 38,368 |  |  |  | 39,928 |  |  |  | (1,413 | ) |  |  | 38,515 |  |
|  |  | $ | 100,008 |  |  | $ | (3,329 | ) |  | $ | 96,679 |  |  | $ | 92,928 |  |  | $ | (3,057 | ) |  | $ | 89,871 |  |
  (was, 2014-08-05, similarity 0.9898):
[0001193125-14-295293:note_history:10]
|  |  | As of June 30, 2014 |  |  | As of December 30, 2013 |  |
|  |  | Principal |  |  | Unamortized Discount |  |  | Net Carrying Amount |  |  | Principal |  |  | Unamortized Discount |  |  | Net Carrying Amount |  |
|  |  | (in thousands) |  |
| Liability components: |  |  |  |  |
| Convertible senior notes due 2020 |  | $ | 250,000 |  |  | $ | (56,545 | ) |  | $ | 193,455 |  |  | $ | 220,000 |  |  | $ | (52,833 | ) |  | $ | 167,167 |  |
| Convertible senior notes due 2015 |  |  | 32,395 |  |  |  | (1,266 | ) |  |  | 31,129 |  |  |  | 38,909 |  |  |  | (2,341 | ) |  |  | 36,568 |  |
| Total |  | $ | 282,395 |  |  | $ | (57,811 | ) |  | $ | 224,584 |  |  | $ | 258,909 |  |  | $ | (55,174 | ) |  | $ | 203,735 |  |
|  |  | As of June 30, 2014 |  |  | As of December 30, 2013 |  |
|  |  | Embedded conversion option — Convertible Senior Notes |  |  | Embedded conversion option — Convertible Senior Notes Issuance Costs |  |  | Total |  |  | Embedded conversion option — Convertible Senior Notes |  |  | Embedded conversion option — Convertible Senior Notes Issuance Costs |  |  | Total |  |
|  |  | (in thousands) |  |
| Equity components: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Additional paid-in capital: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Convertible senior notes due 2020 |  | $ | 60,227 |  |  | $ | (1,916 | ) |  | $ | 58,311 |  |  | $ | 53,000 |  |  | $ | (1,644 | ) |  | $ | 51,356 |  |
| Convertible senior notes due 2015 |  |  | 39,781 |  |  | $ | (1,413 | ) |  |  | 38,368 |  |  |  | 39,928 |  |  |  | (1,413 | ) |  |  | 38,515 |  |
|  |  | $ | 100,008 |  |  | $ | (3,329 | ) |  | $ | 96,679 |  |  | $ | 92,928 |  |  | $ | (3,057 | ) |  | $ | 89,871 |  |

- changed (2014-11-10):
[0001193125-14-404493:note_history:11]
The components of interest expense resulting from the
 convertible senior notes for the quarter and three quarters ended
 September 29, 2014 and September 30, 2013 are as
 follows:
  (was, 2014-08-05, similarity 0.9068):
[0001193125-14-295293:note_history:11]
The components of interest expense resulting from the
 convertible senior notes for the quarter and two quarters ended
 June 30, 2014 and July 1, 2013 are as follows:

- changed (2014-11-10):
[0001193125-14-404493:note_history:12]
|  |  | For the Quarter Ended |  |  | For the Three Quarters Ended |  |
|  |  | September 29, 2014 |  |  | September 30, 2013 |  |  | September 29, 2014 |  |  | September 30, 2013 |  |
|  |  | (In thousands) |  |  | (In thousands) |  |
| Contractual coupon interest |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Convertible senior notes due 2020 |  | $ | 1,094 |  |  | $ | — |  |  | $ | 3,273 |  |  | $ | — |  |
| Convertible senior notes due 2015 |  |  | 263 |  |  |  | 1,422 |  |  |  | 790 |  |  |  | 4,266 |  |
|  |  | $ | 1,357 |  |  | $ | 1,422 |  |  | $ | 4,063 |  |  | $ | 4,266 |  |
| Amortization of debt discount |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Convertible senior notes due 2020 |  | $ | 1,779 |  |  | $ | — |  |  | $ | 5,294 |  |  | $ | — |  |
| Convertible senior notes due 2015 |  |  | 352 |  |  |  | 1,751 |  |  |  | 1,036 |  |  |  | 5,147 |  |
|  |  | $ | 2,131 |  |  | $ | 1,751 |  |  | $ | 6,330 |  |  | $ | 5,147 |  |
| Amortization of debt issuance costs |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Convertible senior notes due 2020 |  | $ | 178 |  |  | $ | — |  |  | $ | 531 |  |  | $ | — |  |
| Convertible senior notes due 2015 |  |  | 36 |  |  |  | 177 |  |  |  | 104 |  |  |  | 519 |  |
|  |  | $ | 214 |  |  | $ | 177 |  |  | $ | 635 |  |  | $ | 519 |  |
  (was, 2014-08-05, similarity 0.939):
[0001193125-14-295293:note_history:12]
|  |  | For the Quarter Ended |  |  | For the Two Quarters Ended |  |
|  |  | June 30, 2014 |  |  | July 1, 2013 |  |  | June 30, 2014 |  |  | July 1, 2013 |  |
|  |  | (In thousands) |  |  | (In thousands) |  |
| Contractual coupon interest |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Convertible senior notes due 2020 |  | $ | 1,094 |  |  | $ | — |  |  | $ | 2,179 |  |  | $ | — |  |
| Convertible senior notes due 2015 |  |  | 263 |  |  |  | 1,422 |  |  |  | 526 |  |  |  | 2,844 |  |
|  |  | $ | 1,357 |  |  | $ | 1,422 |  |  | $ | 2,705 |  |  | $ | 2,844 |  |
| Amortization of debt discount |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Convertible senior notes due 2020 |  | $ | 1,751 |  |  | $ | — |  |  | $ | 3,515 |  |  | $ | — |  |
| Convertible senior notes due 2015 |  |  | 345 |  |  |  | 1,715 |  |  |  | 683 |  |  |  | 3,395 |  |
|  |  | $ | 2,096 |  |  | $ | 1,715 |  |  | $ | 4,198 |  |  | $ | 3,395 |  |
| Amortization of debt issuance costs |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Convertible senior notes due 2020 |  | $ | 175 |  |  | $ | — |  |  | $ | 353 |  |  | $ | — |  |
| Convertible senior notes due 2015 |  |  | 35 |  |  |  | 174 |  |  |  | 69 |  |  |  | 343 |  |
|  |  | $ | 210 |  |  | $ | 174 |  |  | $ | 422 |  |  | $ | 343 |  |

- changed (2014-11-10):
[0001193125-14-404493:note_history:13]
As of September 29, 2014 and December 30, 2013,
 remaining unamortized debt issuance costs included in other
 non-current assets were $5,580 and $5,399, respectively. The debt
 issuance costs and debt discount are being amortized to interest
 expense over the term of the convertible senior notes using the
 effective interest rate method. At September 29, 2014, the
 remaining weighted average amortization period for the unamortized
 senior convertible note discount and debt issuance costs was
 6.1 years.
  (was, 2014-08-05, similarity 0.6916):
[0001193125-14-295293:note_history:13]
As of June 30, 2014 and December 30, 2013, remaining
 unamortized debt issuance costs included in other non-current
 assets were $5,795 and $5,399, respectively. The debt issuance
 costs and debt discount are being amortized to interest expense
 over the term of the convertible senior notes using the effective
 interest rate method. At June 30, 2014, the remaining weighted
 average amortization period for the unamortized senior convertible
 note discount and debt issuance costs was
 6.3 years.

- changed (2014-11-10):
[0001193125-14-404493:note_history:14]
For the quarter and three quarters ended September 29,
 2014, the amortization of debt discount and debt issuance costs for
 the 2020 convertible senior notes and the 2015 convertible senior
 notes is based on an effective interest rate of 6.48% and 8.37%,
 respectively. For the quarter and three quarters ended
 September 30, 2013, the amortization of debt discount and debt
 issuance costs for the 2015 convertible senior notes is based on an
 effective interest rate of 8.37%.
  (was, 2014-08-05, similarity 0.9564):
[0001193125-14-295293:note_history:14]
For the quarter and two quarters ended June 30, 2014, the
 amortization of debt discount and debt issuance costs for the 2020
 convertible senior notes and the 2015 convertible senior notes is
 based on an effective interest rate of 6.48% and 8.37%,
 respectively. For the quarter and two quarters ended July 1,
 2013, the amortization of debt discount and debt issuance costs for
 the 2015 convertible senior notes is based on an effective interest
 rate of 8.37%.

- removed (2014-11-10):
[0001193125-14-295293:note_history:15]
The accounting standards for convertible debt instruments that
 may be fully or partially settled in cash upon conversion require
 the debt and equity components to be separately accounted for in a
 manner that reflects our nonconvertible borrowing rate when
 interest expense is recognized in subsequent periods. The amount
 recorded as debt is based on the fair value of the debt component
 as a standalone instrument, determined using an average interest
 rate for similar nonconvertible debt issued by entities with credit
 ratings comparable to the Company’s at the time of issuance.
 The difference between the debt recorded at inception and its
 principal amount is to be accreted to principal through interest
 expense through the estimated life of the note.


## ttmi:ScheduleOfComponentsOfInterestExpenseFromConvertibleNotesTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2014-11-10):
[0001193125-14-404493:note_history:16]
The components of interest expense resulting from the
 convertible senior notes for the quarter and three quarters ended
 September 29, 2014 and September 30, 2013 are as
 follows:
  (was, 2014-08-05, similarity 0.9068):
[0001193125-14-295293:note_history:16]
The components of interest expense resulting from the
 convertible senior notes for the quarter and two quarters ended
 June 30, 2014 and July 1, 2013 are as follows:

- changed (2014-11-10):
[0001193125-14-404493:note_history:17]
|  |  | For the Quarter Ended |  |  | For the Three Quarters Ended |  |
|  |  | September 29, 2014 |  |  | September 30, 2013 |  |  | September 29, 2014 |  |  | September 30, 2013 |  |
|  |  | (In thousands) |  |  | (In thousands) |  |
| Contractual coupon interest |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Convertible senior notes due 2020 |  | $ | 1,094 |  |  | $ | — |  |  | $ | 3,273 |  |  | $ | — |  |
| Convertible senior notes due 2015 |  |  | 263 |  |  |  | 1,422 |  |  |  | 790 |  |  |  | 4,266 |  |
|  |  | $ | 1,357 |  |  | $ | 1,422 |  |  | $ | 4,063 |  |  | $ | 4,266 |  |
| Amortization of debt discount |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Convertible senior notes due 2020 |  | $ | 1,779 |  |  | $ | — |  |  | $ | 5,294 |  |  | $ | — |  |
| Convertible senior notes due 2015 |  |  | 352 |  |  |  | 1,751 |  |  |  | 1,036 |  |  |  | 5,147 |  |
|  |  | $ | 2,131 |  |  | $ | 1,751 |  |  | $ | 6,330 |  |  | $ | 5,147 |  |
| Amortization of debt issuance costs |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Convertible senior notes due 2020 |  | $ | 178 |  |  | $ | — |  |  | $ | 531 |  |  | $ | — |  |
| Convertible senior notes due 2015 |  |  | 36 |  |  |  | 177 |  |  |  | 104 |  |  |  | 519 |  |
|  |  | $ | 214 |  |  | $ | 177 |  |  | $ | 635 |  |  | $ | 519 |  |
  (was, 2014-08-05, similarity 0.939):
[0001193125-14-295293:note_history:17]
|  |  | For the Quarter Ended |  |  | For the Two Quarters Ended |  |
|  |  | June 30, 2014 |  |  | July 1, 2013 |  |  | June 30, 2014 |  |  | July 1, 2013 |  |
|  |  | (In thousands) |  |  | (In thousands) |  |
| Contractual coupon interest |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Convertible senior notes due 2020 |  | $ | 1,094 |  |  | $ | — |  |  | $ | 2,179 |  |  | $ | — |  |
| Convertible senior notes due 2015 |  |  | 263 |  |  |  | 1,422 |  |  |  | 526 |  |  |  | 2,844 |  |
|  |  | $ | 1,357 |  |  | $ | 1,422 |  |  | $ | 2,705 |  |  | $ | 2,844 |  |
| Amortization of debt discount |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Convertible senior notes due 2020 |  | $ | 1,751 |  |  | $ | — |  |  | $ | 3,515 |  |  | $ | — |  |
| Convertible senior notes due 2015 |  |  | 345 |  |  |  | 1,715 |  |  |  | 683 |  |  |  | 3,395 |  |
|  |  | $ | 2,096 |  |  | $ | 1,715 |  |  | $ | 4,198 |  |  | $ | 3,395 |  |
| Amortization of debt issuance costs |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Convertible senior notes due 2020 |  | $ | 175 |  |  | $ | — |  |  | $ | 353 |  |  | $ | — |  |
| Convertible senior notes due 2015 |  |  | 35 |  |  |  | 174 |  |  |  | 69 |  |  |  | 343 |  |
|  |  | $ | 210 |  |  | $ | 174 |  |  | $ | 422 |  |  | $ | 343 |  |


## ttmi:ScheduleOfLiabilityAndEquityComponentsOfConvertibleNotesTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2014-11-10):
[0001193125-14-404493:note_history:18]
As of September 29, 2014 and December 30, 2013, the
 following summarizes the liability and equity components of the
 convertible senior notes:
  (was, 2014-08-05, similarity 0.9569):
[0001193125-14-295293:note_history:18]
As of June 30, 2014 and December 30, 2013, the
 following summarizes the liability and equity components of the
 convertible senior notes:

- changed (2014-11-10):
[0001193125-14-404493:note_history:19]
|  |  | As of September 29, 2014 |  |  | As of December 30, 2013 |  |
|  |  | Principal |  |  | Unamortized Discount |  |  | Net Carrying Amount |  |  | Principal |  |  | Unamortized Discount |  |  | Net Carrying Amount |  |
|  |  | (in thousands) |  |
| Liability components: |  |  |  |  |
| Convertible senior notes due 2020 |  | $ | 250,000 |  |  | $ | (54,766 | ) |  | $ | 195,234 |  |  | $ | 220,000 |  |  | $ | (52,833 | ) |  | $ | 167,167 |  |
| Convertible senior notes due 2015 |  |  | 32,395 |  |  |  | (914 | ) |  |  | 31,481 |  |  |  | 38,909 |  |  |  | (2,341 | ) |  |  | 36,568 |  |
| Total |  | $ | 282,395 |  |  | $ | (55,680 | ) |  | $ | 226,715 |  |  | $ | 258,909 |  |  | $ | (55,174 | ) |  | $ | 203,735 |  |
|  |  | As of September 29, 2014 |  |  | As of December 30, 2013 |  |
|  |  | Embedded conversion option — Convertible Senior Notes |  |  | Embedded conversion option — Convertible Senior Notes Issuance Costs |  |  | Total |  |  | Embedded conversion option — Convertible Senior Notes |  |  | Embedded conversion option — Convertible Senior Notes Issuance Costs |  |  | Total |  |
|  |  | (in thousands) |  |
| Equity components: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Additional paid-in capital: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Convertible senior notes due 2020 |  | $ | 60,227 |  |  | $ | (1,916 | ) |  | $ | 58,311 |  |  | $ | 53,000 |  |  | $ | (1,644 | ) |  | $ | 51,356 |  |
| Convertible senior notes due 2015 |  |  | 39,781 |  |  |  | (1,413 | ) |  |  | 38,368 |  |  |  | 39,928 |  |  |  | (1,413 | ) |  |  | 38,515 |  |
|  |  | $ | 100,008 |  |  | $ | (3,329 | ) |  | $ | 96,679 |  |  | $ | 92,928 |  |  | $ | (3,057 | ) |  | $ | 89,871 |  |
  (was, 2014-08-05, similarity 0.9898):
[0001193125-14-295293:note_history:19]
|  |  | As of June 30, 2014 |  |  | As of December 30, 2013 |  |
|  |  | Principal |  |  | Unamortized Discount |  |  | Net Carrying Amount |  |  | Principal |  |  | Unamortized Discount |  |  | Net Carrying Amount |  |
|  |  | (in thousands) |  |
| Liability components: |  |  |  |  |
| Convertible senior notes due 2020 |  | $ | 250,000 |  |  | $ | (56,545 | ) |  | $ | 193,455 |  |  | $ | 220,000 |  |  | $ | (52,833 | ) |  | $ | 167,167 |  |
| Convertible senior notes due 2015 |  |  | 32,395 |  |  |  | (1,266 | ) |  |  | 31,129 |  |  |  | 38,909 |  |  |  | (2,341 | ) |  |  | 36,568 |  |
| Total |  | $ | 282,395 |  |  | $ | (57,811 | ) |  | $ | 224,584 |  |  | $ | 258,909 |  |  | $ | (55,174 | ) |  | $ | 203,735 |  |
|  |  | As of June 30, 2014 |  |  | As of December 30, 2013 |  |
|  |  | Embedded conversion option — Convertible Senior Notes |  |  | Embedded conversion option — Convertible Senior Notes Issuance Costs |  |  | Total |  |  | Embedded conversion option — Convertible Senior Notes |  |  | Embedded conversion option — Convertible Senior Notes Issuance Costs |  |  | Total |  |
|  |  | (in thousands) |  |
| Equity components: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Additional paid-in capital: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Convertible senior notes due 2020 |  | $ | 60,227 |  |  | $ | (1,916 | ) |  | $ | 58,311 |  |  | $ | 53,000 |  |  | $ | (1,644 | ) |  | $ | 51,356 |  |
| Convertible senior notes due 2015 |  |  | 39,781 |  |  | $ | (1,413 | ) |  |  | 38,368 |  |  |  | 39,928 |  |  |  | (1,413 | ) |  |  | 38,515 |  |
|  |  | $ | 100,008 |  |  | $ | (3,329 | ) |  | $ | 96,679 |  |  | $ | 92,928 |  |  | $ | (3,057 | ) |  | $ | 89,871 |  |


## us-gaap:LongTermDebtTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2014-11-10):
[0001193125-14-404493:note_history:20]
The following table summarizes the long-term debt of the
 Company as of September 29, 2014 and December 30,
 2013:
  (was, 2014-08-05, similarity 0.9447):
[0001193125-14-295293:note_history:20]
The following table summarizes the long-term debt of the
 Company as of June 30, 2014 and December 30,
 2013:

- changed (2014-11-10):
[0001193125-14-404493:note_history:21]
|  |  | Average Effective Interest Rate as of September 29, 2014 |  | September 29, 2014 |  |  | Average Effective Interest Rate as of December 30, 2013 |  | December 30, 2013 |  |
|  |  | (In thousands) |  |
| Term loan due September 2016 |  | 2.53% |  | $ | 273,800 |  |  | 2.55% |  | $ | 370,000 |  |
| Other |  | 6.00% |  |  | 5 |  |  | 6.00% |  |  | 8 |  |
|  |  |  |  |  | 273,805 |  |  |  |  |  | 370,008 |  |
| Less: current maturities |  |  |  |  | (96,205 | ) |  |  |  |  | (96,204 | ) |
| Long-term debt, less current maturities |  |  |  | $ | 177,600 |  |  |  |  | $ | 273,804 |  |
  (was, 2014-08-05, similarity 0.9518):
[0001193125-14-295293:note_history:21]
|  |  | Average Effective Interest Rate as of June 30, 2014 |  | June 30, 2014 |  |  | Average Effective Interest Rate as of December 30, 2013 |  | December 30, 2013 |  |
|  |  | (In thousands) |  |
| Term loan due September 2016 |  | 2.54% |  | $ | 321,900 |  |  | 2.55% |  | $ | 370,000 |  |
| Other |  | 6.00% |  |  | 6 |  |  | 6.00% |  |  | 8 |  |
|  |  |  |  |  | 321,906 |  |  |  |  |  | 370,008 |  |
| Less: current maturities |  |  |  |  | (96,205 | ) |  |  |  |  | (96,204 | ) |
| Long-term debt, less current maturities |  |  |  | $ | 225,701 |  |  |  |  | $ | 273,804 |  |

- changed (2014-11-10):
[0001193125-14-404493:note_history:22]
|  |  | (In thousands) |  |
| 2015 |  | $ | 96,205 |  |
| 2016 |  |  | 177,600 |  |
|  |  | $ | 273,805 |  |
  (was, 2014-08-05, similarity 0.8506):
[0001193125-14-295293:note_history:22]
|  |  | (In thousands) |  |
| Remaining 2014 |  | $ | 48,102 |  |
| 2015 |  |  | 96,204 |  |
| 2016 |  |  | 177,600 |  |
|  |  | $ | 321,906 |  |

- changed (2014-11-10):
[0001193125-14-404493:note_history:23]
In 2012, the Company became a party to a facility agreement
 (Credit Agreement) consisting of a $370,000 senior secured term
 loan (Term Loan), a $90,000 senior secured revolving loan
 (Revolving Loan), and a secured $80,000 letters of credit facility
 (Letters of Credit Facility). The Term Loan and Letters of Credit
 Facility will mature on September 14, 2016. The Revolving Loan
 will mature on March 14, 2016. The Credit Agreement is secured
 by substantially all of the assets of the Company’s Asia
 Pacific operating segment and is senior to all other debt,
 including the convertible senior notes. See Note 6 to these
 Consolidated Condensed Financial Statements for additional
 information. The Company has fully and unconditionally guaranteed
 the full and timely payment of all Credit Agreement related
 obligations of its Asia Pacific operating segment.
  (was, 2014-08-05, similarity 0.7415):
[0001193125-14-295293:note_history:23]
In 2012, the Company became a party to a facility agreement
 (Credit Agreement) consisting of a $370,000 senior secured term
 loan (Term Loan), a $90,000 senior secured revolving loan
 (Revolving Loan), and a secured $80,000 letters of credit facility
 (Letters of Credit Facility). The Term Loan and Letters of Credit
 Facility will mature on September 14, 2016. The Revolving Loan
 will mature on March 14, 2016. The Credit Agreement is secured
 by substantially all of the assets of the Company’s Asia
 Pacific operating segment and is senior to all other debt,
 including the convertible senior notes. See Note 5. The Company has
 fully and unconditionally guaranteed the full and timely payment of
 all Credit Agreement related obligations of its Asia Pacific
 operating segment.

- changed (2014-11-10):
[0001193125-14-404493:note_history:24]
As of September 29, 2014 and December 30, 2013, the
 remaining unamortized debt issuance costs included in other
 non-current assets was $1,323 and $1,937, respectively, and is
 amortized to interest expense over the term of the Company’s
 Credit Agreement using the effective interest rate method. At
 September 29, 2014, the remaining amortization period for the
 unamortized debt issuance costs was 1.7 years.
  (was, 2014-08-05, similarity 0.8043):
[0001193125-14-295293:note_history:24]
As of June 30, 2014 and December 30, 2013, the
 remaining unamortized debt issuance costs included in other
 non-current assets was $1,525 and $1,937, respectively, and is
 amortized to interest expense over the term of the Company’s
 Credit Agreement using the effective interest rate method. At
 June 30, 2014, the remaining amortization period for the
 unamortized debt issuance costs was 2.0 years.

- added (2014-11-10):
[0001193125-14-404493:note_history:25]
The Company is also required to pay a commitment fee of
 0.50% per annum on any unused portion of the loan and letters
 of credit facility granted under the Credit Agreement. The Company
 incurred commitment fees related to unused borrowing availability
 of $155 and $129 for the quarters ended September 29, 2014 and
 September 30, 2013, respectively, and $439 and $320 for the
 three quarters ended September 29, 2014 and September 30,
 2013, respectively. As of September 29, 2014, the outstanding
 amount of the Term Loan under the Credit Agreement was $273,800, of
 which $96,200 is due for repayment through September 2015 and is
 included as short-term debt, with the remaining $177,600 included
 as long-term debt. None of the Revolving Loan was outstanding under
 the Credit Agreement as of September 29, 2014. Available
 borrowing capacity under the Revolving Loan was $90,000 at
 September 29, 2014.

- changed (2014-11-10):
[0001193125-14-404493:note_history:26]
Additionally, the Company is party to a revolving loan credit
 facility with a lender in the People’s Republic of China
 (China). Under this arrangement, the lender has made available to
 the Company approximately $47,300 in unsecured borrowing with all
 terms of the borrowing to be negotiated at the time the revolver is
 drawn upon. There are no commitment fees on the unused portion of
 the revolver and this arrangement expires in December 2014. As of
 September 29, 2014, the revolver had not been drawn
 upon.
  (was, 2014-08-05, similarity 0.9785):
[0001193125-14-295293:note_history:26]
Additionally, the Company is party to a revolving loan credit
 facility with a lender in the People’s Republic of China
 (PRC). Under this arrangement, the lender has made available to the
 Company approximately $46,600 in unsecured borrowing with all terms
 of the borrowing to be negotiated at the time the revolver is drawn
 upon. There are no commitment fees on the unused portion of the
 revolver and this arrangement expires in December 2014. As of
 June 30, 2014, the revolver had not been drawn
 upon.

- added (2014-11-10):
[0001193125-14-404493:note_history:27]
The Company has an $80,000 Letters of Credit Facility under the
 Credit Agreement, as mentioned above. As of September 29,
 2014, letters of credit in the amount of $43,234 were outstanding
 under this Credit Agreement. The Company has other standby letters
 of credit outstanding in the amount of $3,894, which expire between
 December 31, 2014 and February 28, 2015.

- removed (2014-11-10):
[0001193125-14-295293:note_history:28]
The Company is also required to pay a commitment fee of
 0.50% per annum on any unused portion of the loan and letters
 of credit facility granted under the Credit Agreement. The Company
 incurred commitment fees related to unused borrowing availability
 of $151 and $95 for the quarters ended June 30, 2014 and
 July 1, 2013, respectively, and $284 and $191 for the two
 quarters ended June 30, 2014 and July 1, 2013,
 respectively. As of June 30, 2014, the outstanding amount of
 the Term Loan under the Credit Agreement was $321,900, of which
 $96,200 is due for repayment through March 2015 and is included as
 short-term debt, with the remaining $225,700 included as long-term
 debt. None of the Revolver was outstanding under the Credit
 Agreement as of June 30, 2014. Available borrowing capacity
 under the Revolving Loan was $90,000 at June 30,
 2014.

- removed (2014-11-10):
[0001193125-14-295293:note_history:29]
The Company has an $80,000 Letters of Credit Facility under the
 Credit Agreement, as mentioned above. As of June 30, 2014,
 letters of credit in the amount of $46,183 were outstanding under
 this Credit Agreement. The Company has other standby letters of
 credit outstanding in the amount of $3,894, as well other unused
 letter of credit facilities in the amount of $24,100. The
 outstanding standby letters of credit and unused letter of credit
 facilities expire between December 31, 2014 and
 February 28, 2015.


## us-gaap:ScheduleOfDebtInstrumentsTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2014-11-10):
[0001193125-14-404493:note_history:30]
The following table summarizes the long-term debt of the
 Company as of September 29, 2014 and December 30,
 2013:
  (was, 2014-08-05, similarity 0.9447):
[0001193125-14-295293:note_history:30]
The following table summarizes the long-term debt of the
 Company as of June 30, 2014 and December 30,
 2013:

- changed (2014-11-10):
[0001193125-14-404493:note_history:31]
|  |  | Average Effective Interest Rate as of September 29, 2014 |  | September 29, 2014 |  |  | Average Effective Interest Rate as of December 30, 2013 |  | December 30, 2013 |  |
|  |  | (In thousands) |  |
| Term loan due September 2016 |  | 2.53% |  | $ | 273,800 |  |  | 2.55% |  | $ | 370,000 |  |
| Other |  | 6.00% |  |  | 5 |  |  | 6.00% |  |  | 8 |  |
|  |  |  |  |  | 273,805 |  |  |  |  |  | 370,008 |  |
| Less: current maturities |  |  |  |  | (96,205 | ) |  |  |  |  | (96,204 | ) |
| Long-term debt, less current maturities |  |  |  | $ | 177,600 |  |  |  |  | $ | 273,804 |  |
  (was, 2014-08-05, similarity 0.9518):
[0001193125-14-295293:note_history:31]
|  |  | Average Effective Interest Rate as of June 30, 2014 |  | June 30, 2014 |  |  | Average Effective Interest Rate as of December 30, 2013 |  | December 30, 2013 |  |
|  |  | (In thousands) |  |
| Term loan due September 2016 |  | 2.54% |  | $ | 321,900 |  |  | 2.55% |  | $ | 370,000 |  |
| Other |  | 6.00% |  |  | 6 |  |  | 6.00% |  |  | 8 |  |
|  |  |  |  |  | 321,906 |  |  |  |  |  | 370,008 |  |
| Less: current maturities |  |  |  |  | (96,205 | ) |  |  |  |  | (96,204 | ) |
| Long-term debt, less current maturities |  |  |  | $ | 225,701 |  |  |  |  | $ | 273,804 |  |


## us-gaap:ScheduleOfMaturitiesOfLongTermDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2014-11-10):
[0001193125-14-404493:note_history:32]
|  |  | (In thousands) |  |
| 2015 |  | $ | 96,205 |  |
| 2016 |  |  | 177,600 |  |
|  |  | $ | 273,805 |  |
  (was, 2014-08-05, similarity 0.8506):
[0001193125-14-295293:note_history:32]
|  |  | (In thousands) |  |
| Remaining 2014 |  | $ | 48,102 |  |
| 2015 |  |  | 96,204 |  |
| 2016 |  |  | 177,600 |  |
|  |  | $ | 321,906 |  |


## us-gaap:RelatedPartyTransactionsDisclosureTextBlock (related_parties) — matched_by: tag_name, score: 1.0

- changed (2014-11-10):
[0001193125-14-404493:note_history:33]
In the
 normal course of business, the Company’s foreign subsidiaries
 purchase laminate and prepreg from related parties in which a
 significant shareholder of the Company holds an equity interest.
 The Company purchased laminate and prepreg from these related
 parties in the amount of $11,469 and $13,740 for the quarters ended
 September 29, 2014 and September 30, 2013, respectively,
 and $36,647 and $51,349 for the three quarters ended
 September 29, 2014 and September 30, 2013,
 respectively.
  (was, 2014-08-05, similarity 0.8929):
[0001193125-14-295293:note_history:33]
In the normal course of business, the Company’s foreign
 subsidiaries purchase laminate and prepreg from related parties in
 which a significant shareholder of the Company holds an equity
 interest. The Company purchased laminate and prepreg from these
 related parties in the amount of $13,390 and $18,472 for the
 quarters ended June 30, 2014 and July 1, 2013,
 respectively, and $25,180 and $37,609 for the two quarters ended
 June 30, 2014 and July 1, 2013, respectively.

- added (2014-11-10):
[0001193125-14-404493:note_history:34]
Dongguan Shengyi Electronics Ltd., (SYE) is a related party as
 a significant shareholder of the Company holds an equity interest
 in the parent company of SYE. Sales to SYE for the quarters ended
 September 29, 2014 and September 30, 2013 were $2,282 and
 $14,351, respectively, and $21,535 and $18,361 for the three
 quarters ended September 29, 2014 and September 30, 2013,
 respectively. Additionally, purchases from SYE for the quarter and
 three quarters ended September 29, 2014 were approximately $78
 and $550, respectively. There were no purchases from SYE for the
 quarter or three quarters ended September 30, 2013.

- changed (2014-11-10):
[0001193125-14-404493:note_history:35]
As of
 September 29, 2014 and December 30, 2013, the
 Company’s consolidated condensed balance sheet included
 $19,884 and $19,547, respectively, in accounts payable due to, and
 $8,924 and $13,312, respectively, in accounts receivable due from
 related parties for the purchase of laminate and prepreg, and sales
 of PCBs to SYE, as mentioned above.
  (was, 2014-08-05, similarity 0.979):
[0001193125-14-295293:note_history:35]
As of June 30, 2014 and December 30, 2013, the
 Company’s consolidated condensed balance sheet included
 $20,482 and $19,547, respectively, in accounts payable due to, and
 $14,269 and $13,312, respectively, in accounts receivable due from
 related parties for the purchase of laminate and prepreg, and sales
 of PCBs to SYE, as mentioned above.

- removed (2014-11-10):
[0001193125-14-295293:note_history:36]
Dongguan Shengyi Electronics Ltd., (SYE) is a related party as
 a significant shareholder of the Company holds an equity interest
 in the parent company of SYE. Subsequent to the Company’s
 sale of its controlling interest in SYE in June 2013, the Company
 began selling PCBs to, and purchasing PCBs from, SYE. Sales to SYE
 for the quarter and two quarters ended June 30, 2014 were
 approximately $9,100 and $19,253, respectively, and $4,009 for both
 the quarter and two quarters ended July 1, 2013. Additionally,
 purchases from SYE for the quarter and two quarters ended
 June 30, 2014 were approximately $201 and $472, respectively.
 There were no purchases from SYE for the quarter or two quarters
 ended July 1, 2013.
