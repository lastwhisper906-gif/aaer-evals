# TTMI MD&A — 0001193125-15-069683


## mdna

[0001193125-15-069683:mdna:1]
| ITEM 7. | MANAGEMENT’S DISCUSSION AND ANALYSIS OF FINANCIAL CONDITION AND RESULTS OF OPERATIONS |

[0001193125-15-069683:mdna:2]
This financial review presents our operating results for each of our three most recent fiscal years and our financial condition at
December 29, 2014. Except for historical information contained herein, the following discussion contains forward-looking statements which are subject to known and unknown risks, uncertainties and other factors that may cause our actual results
to differ materially from those expressed or implied by such forward-looking statements. We discuss such risks, uncertainties and other factors throughout this report and specifically under Item 1A of Part I of this report, Risk Factors.
In addition, the following discussion should be read in connection with the information presented in our consolidated financial statements and the related notes to our consolidated financial statements.

[0001193125-15-069683:mdna:3]
OVERVIEW AND RECENT DEVELOPMENTS

[0001193125-15-069683:mdna:4]
We are a leading global provider of time-critical and technologically complex printed circuit board products and backplane assemblies (i.e., PCBs populated with electronic components), which serve as the
foundation of sophisticated electronic products. We focus on providing time-to-market and advanced technology products and offer a one-stop manufacturing solution to our customers from engineering support to prototype development through final
volume production. This one-stop manufacturing solution allows us to align technology development with the diverse needs of our customers and to enable them to reduce the time required to develop new products and bring them to market. We serve a
diversified customer base consisting of approximately 1,000 customers in various markets throughout the world, including manufacturers of networking/communications infrastructure products, smartphones and touchscreen tablets, as well as the
aerospace and defense, high-end computing, and industrial/medical industries. Our customers include both original equipment manufacturers and electronic manufacturing services providers.

[0001193125-15-069683:mdna:5]
On September 21, 2014, TTM, Viasystems, and Merger Sub entered into the Merger Agreement under which, subject to the satisfaction of
certain conditions, we expect to acquire all outstanding shares of Viasystems for a combined consideration of $11.33 in cash and 0.706 shares of TTM common stock per outstanding share of Viasystems common stock, which based on the closing market
price on December 31, 2014 was valued at $16.65 per share of Viasystems common stock, or approximately $361.7 million. The total purchase price of the transaction, including debt assumed, is approximately $992.5 million, which was based on the
closing market price on December 31, 2014 and is subject to change prior to the consummation of the Merger.

[0001193125-15-069683:mdna:6]
Concurrently
with the execution of the Merger Agreement, we obtained a debt financing commitment in an aggregate amount of $1,115 million in connection with financing the transactions contemplated by the Merger Agreement. Assuming consummation of the Merger, we
intend to use the aggregate proceeds of such financing arrangements to finance the Merger, to refinance certain existing indebtedness of Viasystems, to refinance certain of our existing indebtedness, and to pay the fees and expenses incurred in
connection with the Merger. We are in the process of finalizing the specific financing arrangements.

[0001193125-15-069683:mdna:7]
Our Asia Pacific
operating segment experiences revenue fluctuations, caused in part by seasonal patterns in the touchscreen tablet and cellular phone industries, which together have become a significant portion of the end markets we serve. This seasonality typically
results in higher net sales in the third and fourth quarters due to end customer demand to meet fourth quarter sales of consumer electronics products and lower sales in the first and second quarters. Lower sales in the first and second quarters can
present utilization challenges for us which negatively impact gross margin. Additionally, our labor costs in China have increased significantly over the past several years as a result of mandated increases in the minimum wage and other competitive
dynamics, and we operate in a priced competitive industry. The impact of these items, if not offset by yield and productivity improvements and other cost efficiencies, may reduce our gross margins in the future.

[0001193125-15-069683:mdna:8]
During the year ended December 29, 2014, we experienced a decline in gross and operating margins in our Asia Pacific operating
segment resulting from the underutilization of certain advanced technology production facilities and an unexpected power outage. We experienced underutilization in the first and second quarters of 2014 caused by an increase in capacity to service an
expected higher level of business which did not materialize. Additionally, in the third quarter of 2014, we experienced a 5 day production shut down due to an unexpected

[0001193125-15-069683:mdna:9]
power outage at one of our advanced technology production facilities which negatively impacted our productivity and yield improvement efforts as we were launching new products and significantly
ramping for increased volumes. Although we believe these to be unique challenges, we may experience similar challenges in the future which could negatively impact gross margins.

[0001193125-15-069683:mdna:10]
While our customers include both OEMs and EMS providers, we measure customers based on OEM companies as they are the ultimate end
customers. Sales to our 5 largest customers accounted for 44%, 41% and 33% of our net sales in 2014, 2013 and 2012, respectively. We sell to OEMs both directly and indirectly through EMS providers.

[0001193125-15-069683:mdna:11]
The following table shows the percentage of our net sales attributable to each of the principal end markets we served for the periods
indicated:

[0001193125-15-069683:mdna:12]
| End Markets(1)(2) |  | 2014 |  |  | 2013 |  |  | 2012 |  |
| Aerospace and Defense |  |  | 16 | % |  |  | 15 | % |  |  | 15 | % |
| Cellular Phone(3) |  |  | 23 |  |  |  | 20 |  |  |  | 16 |  |
| Computing/Storage/Peripherals(3) |  |  | 13 |  |  |  | 20 |  |  |  | 23 |  |
| Medical/Industrial/Instrumentation/Other |  |  | 9 |  |  |  | 8 |  |  |  | 9 |  |
| Networking/Communications |  |  | 33 |  |  |  | 32 |  |  |  | 31 |  |
| Other(3) |  |  | 6 |  |  |  | 5 |  |  |  | 6 |  |
| Total |  |  | 100 | % |  |  | 100 | % |  |  | 100 | % |

[0001193125-15-069683:mdna:13]
| (1) | Sales to EMS companies are classified by the end markets of their OEM customers. |

[0001193125-15-069683:mdna:14]
| (2) | Certain reclassifications of prior year end market percentages have been made to conform to the current year presentation. Beginning in the first quarter of 2013, we reclassified substrate PCBs, which were included in the Other end market, into the end markets that the substrate PCBs are sold into — predominantly Cellular Phone. |

[0001193125-15-069683:mdna:15]
| (3) | Smartphones are included in the Cellular Phone end market, touchscreen tablets are included in the Computing/Storage/Peripherals end market and other mobile devices such as e-readers are included in the Other end market. |

[0001193125-15-069683:mdna:16]
Purchase orders may be cancelled prior to shipment. We
charge customers a fee, based on percentage completed, if an order is cancelled once it has entered production. We derive revenues primarily from the sale of PCBs and backplane assemblies using customer-supplied engineering and design plans. We
recognize revenues when persuasive evidence of a sales arrangement exists, the sales terms are fixed or determinable, title and risk of loss have transferred, and collectability is reasonably assured — generally when products are shipped
to the customer. Net sales consist of gross sales less an allowance for returns, which typically have been less than 3% of gross sales. We provide our customers a limited right of return for defective PCBs and backplane assemblies. We record an
estimate for sales returns and allowances at the time of sale based on historical results.

[0001193125-15-069683:mdna:17]
Cost of goods sold consists of
materials, labor, outside services, and overhead expenses incurred in the manufacture and testing of our products. Many factors affect our gross margin, including capacity utilization, product mix, production volume, and yield. We generally do not
participate in any significant long-term contracts with suppliers, and we believe there are a number of potential suppliers for the raw materials we use.

[0001193125-15-069683:mdna:18]
Selling and marketing expenses consist primarily of salaries, labor related benefits, and commissions paid to our internal sales force, independent sales representatives, and our sales support staff, as
well as costs associated with marketing materials and trade shows.

[0001193125-15-069683:mdna:19]
General and administrative costs primarily include the
salaries for executive, finance, accounting, information technology, facilities and human resources personnel, discretionary meals for employees in Asia, as well as insurance expenses, expenses for accounting and legal assistance, incentive
compensation expense, and gains or losses on the sale or disposal of property, plant and equipment.

[0001193125-15-069683:mdna:20]
CRITICAL ACCOUNTING POLICIES AND ESTIMATES

[0001193125-15-069683:mdna:21]
Our consolidated financial statements included in this report have been prepared in accordance with accounting principles generally
accepted in the United States of America. The preparation of these financial statements requires us to make estimates and assumptions that affect the reported amounts of assets, liabilities, net sales and expenses, and related disclosure of
contingent assets and liabilities.

[0001193125-15-069683:mdna:22]
A critical accounting policy is defined as one that is both material to the presentation of
our consolidated financial statements and requires us to make judgments that could have a material effect on our financial condition or results of operations. These policies require us to make assumptions about matters that are highly uncertain at
the time of the estimate. Different estimates we could reasonably have used, or changes in the estimates that are reasonably likely to occur, or could have a material effect on our financial condition or results of operations.

[0001193125-15-069683:mdna:23]
We base our estimates on historical experience and on various other assumptions that are believed to be reasonable under the
circumstances, the results of which form the basis for making judgments about the carrying values of assets and liabilities that are not readily apparent from other sources. Management has discussed the development, selection and disclosure of these
estimates with the audit committee of our board of directors. Actual results may differ from these estimates under different assumptions or conditions.

[0001193125-15-069683:mdna:24]
Our critical accounting policies include asset valuation related to bad debts and inventory; sales returns and allowances; impairment of long-lived assets, including goodwill and intangible assets;
derivative instruments and hedging activities; realizability of deferred tax assets; and determining self-insurance reserves.

[0001193125-15-069683:mdna:25]
Allowance for Doubtful Accounts

[0001193125-15-069683:mdna:26]
We provide customary credit terms to our customers and generally do not require collateral. We perform ongoing credit evaluations of the financial condition of our customers and maintain an allowance for
doubtful accounts based upon historical collections experience and judgments as to expected collectability of accounts. Our actual bad debts may differ from our estimates.

[0001193125-15-069683:mdna:27]
Inventories

[0001193125-15-069683:mdna:28]
In assessing the realizability of inventories, we are
required to make judgments as to future demand requirements and compare these with current and committed inventory levels. When the market value of inventory is less than the carrying value, the inventory cost is written down to its estimated net
realizable value, thereby establishing a new cost basis. Our inventory requirements may change based on our projected customer demand, market conditions, technological and product life cycle changes, longer or shorter than expected usage periods,
and other factors that could affect the valuation of our inventories. We maintain certain finished goods inventories near certain key customer locations in accordance with agreements with those customers. Although this inventory is typically
supported by valid purchase orders, should these customers ultimately not purchase these inventories, our results of operations and financial condition would be adversely affected.

[0001193125-15-069683:mdna:29]
Sales Returns and Allowances

[0001193125-15-069683:mdna:30]
We derive revenues primarily from the sale of PCBs and backplane assemblies using customer-supplied engineering and design plans. We recognize revenue when persuasive evidence of a sales arrangement
exists, the sales terms are fixed or determinable, title and risk of loss have transferred, and collectability is reasonably assured — generally when products are shipped to the customer. We provide our customers a limited right of return
for defective PCBs and backplane assemblies. We accrue an estimate for sales returns and allowances at the time of sale using our judgment based on historical results and anticipated returns as a result of current period sales. To the extent actual
experience varies from our historical experience, revisions to these allowances may be required.

[0001193125-15-069683:mdna:31]
Long-lived Assets

[0001193125-15-069683:mdna:32]
We have significant long-lived tangible and intangible assets consisting of property, plant and equipment,
definite-lived intangibles, and goodwill. We review these assets for impairment whenever events or changes in

[0001193125-15-069683:mdna:33]
circumstances indicate that the carrying amount of such assets may not be recoverable. In addition, we perform an impairment test related to goodwill at least annually. As necessary, we make
judgments regarding future cash flow forecasts in the assessment of impairment.

[0001193125-15-069683:mdna:34]
During the fourth quarter of each year, and
when events and circumstances warrant an evaluation, we perform an impairment assessment of goodwill, which may require the use of a fair-value based analysis. We determine the fair value of our reporting units based on discounted cash flows and
market approach analyses as considered necessary. We consider factors such as the state of the economy and reduced expectations for future cash flows coupled with a decline in our market capitalization for a sustained period as indicators for
potential goodwill impairment. If the reporting unit’s carrying amount exceeds its estimated fair value, a second step must be performed to measure the amount of the goodwill impairment loss, if any. The second step compares the implied fair
value of the reporting unit’s goodwill, determined in the same manner as the amount of goodwill recognized in a business combination, with the carrying amount of such goodwill. If the carrying amount of the reporting unit’s goodwill
exceeds the implied fair value of that goodwill, an impairment loss is recognized in an amount equal to that excess. For the year ended December 31, 2012 our assessment of goodwill impairment indicated that the carrying value of goodwill for
our Asia Pacific reporting unit, in our Asia Pacific operating segment, was in excess of fair value, and therefore goodwill was impaired. See Note 4 to our consolidated financial statements.

[0001193125-15-069683:mdna:35]
We periodically evaluate whether events and circumstances have occurred, such that the potential for reduced expectations for future cash
flows coupled with a further decline in the market price of our stock and market capitalization may indicate that the remaining balance of goodwill and definite-lived intangible assets may not be recoverable. If factors indicate that assets are
impaired, we would be required to reduce the carrying value of our goodwill and definite-lived intangible assets which may result in an impairment charge.

[0001193125-15-069683:mdna:36]
We also assess other long-lived assets, specifically definite-lived intangibles and property, plant and equipment, for potential impairment given similar impairment indicators. When indicators of
impairment exist related to our long-lived tangible assets and definite-lived intangible assets, we use an estimate of the undiscounted net cash flows and comparison to like-kind assets, as appropriate, in measuring whether the carrying amount of
the assets is recoverable. Measurement of the amount of impairment, if any, is based upon the difference between the asset’s carrying value and estimated fair value. Fair value is determined through various valuation techniques, including
cost-based, market and income approaches as considered necessary, which involve judgments related to future cash flows and the application of the appropriate valuation model. During the years ended 2014, 2013 and 2012, we recorded impairment charges
to reduce the carrying value of certain long-lived assets in the Asia Pacific operating segment. See Notes 4 and 5 to our consolidated financial statements.

[0001193125-15-069683:mdna:37]
Assets Held for Sale — We classify assets to be sold as assets held for sale when (i) we have approved and commit to a plan to sell the asset, (ii) the asset is available for
immediate sale in its present condition, (iii) an active program to locate a buyer and other actions required to sell the asset have been initiated, (iv) the sale of the asset is probable, (v) the asset is being actively marketed for
sale at a price that is reasonable in relation to its current fair value, and (vi) it is unlikely that significant changes to the plan will be made or that the plan will be withdrawn. Assets classified as held for sale are recorded at the lower
of the carrying amount or fair value less the cost to sell.

[0001193125-15-069683:mdna:38]
Assets Held for Use — If a decision to
dispose of an asset or a business is made and the held for sale criteria are not met, it is considered held for use. Assets of the business are evaluated for recoverability in the following order: (i) assets other than goodwill, property and
intangibles; (ii) property and intangibles subject to amortization; and (iii) goodwill. In evaluating the recoverability of property and intangible assets subject to amortization, in a held for use business, the carrying value is first
compared to the sum of the undiscounted cash flows expected to result from the use and eventual disposition. If the carrying value exceeds the undiscounted expected cash flows, then a fair value analysis is performed. An impairment charge is
recognized if the carrying value exceeds the fair value.

[0001193125-15-069683:mdna:39]
Derivative Instruments and Hedging Activities

[0001193125-15-069683:mdna:40]
As a matter of policy, we use derivatives for risk management purposes, and we do not use derivatives for speculative
purposes. Derivatives are typically entered into as hedges of changes in interest rates, currency exchange rates, and other risks.

[0001193125-15-069683:mdna:41]
When we determine to designate a derivative instrument as a cash flow hedge, we formally
document the hedging relationship and its risk management objective and strategy for undertaking the hedge, the hedging instrument, the hedged item, the nature of the risk being hedged, how the hedging instrument’s effectiveness in offsetting
the hedged risk will be assessed, and a description of the method of measuring ineffectiveness. We also formally assess, both at the hedge’s inception and on an ongoing basis, whether the derivative that is used in hedging transactions is
highly effective in offsetting changes in cash flows of hedged items.

[0001193125-15-069683:mdna:42]
Derivative financial instruments are recognized as
either assets or liabilities on the consolidated balance sheet with measurement at fair value. Fair value of the derivative instruments is determined using pricing models developed based on the underlying swap interest rate, foreign currency
exchange rates, and other observable market data as appropriate. The values are also adjusted to reflect nonperformance risk of the counterparty and our company, as necessary. For derivatives that are designated as a cash flow hedge, changes in the
fair value of the derivative are recognized in accumulated other comprehensive income, to the extent the derivative is effective at offsetting the changes in cash flow being hedged until the hedged item affects earnings. To the extent there is any
hedge ineffectiveness, changes in fair value relating to the ineffective portion are immediately recognized in earnings. Changes in the fair value of derivatives that are not designated as hedges are recorded in earnings each period.

[0001193125-15-069683:mdna:43]
Income Taxes

[0001193125-15-069683:mdna:44]
Deferred income tax assets are reviewed for recoverability, and valuation allowances are provided, when necessary, to reduce deferred income tax assets to the amounts that are more likely than not to be
realized based on our estimate of future taxable income. Should our expectations of taxable income change in future periods, it may be necessary to establish a valuation allowance, which could affect our results of operations in the period such a
determination is made. We record income tax provision or benefit during interim periods at a rate that is based on expected results for the full year. If future changes in market conditions cause actual results for the year to be more or less
favorable than those expected, adjustments to the effective income tax rate could be required.

[0001193125-15-069683:mdna:45]
In addition, we are subject to
income taxes in the United States and foreign jurisdictions. Significant judgment is required in determining our worldwide provision for income taxes. In the ordinary course of our business, there are many transactions for which the ultimate tax
determination is uncertain. Additionally, our calculations of income taxes are based on our interpretations of applicable tax laws in the jurisdictions in which we file.

[0001193125-15-069683:mdna:46]
Self Insurance

[0001193125-15-069683:mdna:47]
We are primarily self-insured in North America for
group health insurance and worker’s compensation benefits provided to our U.S. employees, and we purchase insurance to protect against annual claims at the individual and aggregate level. We estimate our exposure for claims incurred but
not reported at the end of each reporting period. We use our judgment using our historical claim data and information and analysis provided by actuarial and claim advisors, our insurance carriers and brokers on an annual basis to estimate our
liability for these claims. This liability is subject to individual insured stop-loss coverage of $300,000 per individual for group health insurance and $250,000 for worker’s compensation benefits. Our actual claims experience may differ from
our estimates.

[0001193125-15-069683:mdna:48]
RESULTS OF OPERATIONS

[0001193125-15-069683:mdna:49]
The following table sets forth the relationship of various items to net sales in our consolidated statement of operations:

[0001193125-15-069683:mdna:50]
|  |  | For the Year Ended |  |
|  |  | December 29,2014 |  |  | December 30,2013 |  |  | December 31,2012 |  |
| Net sales |  |  | 100.0 | % |  |  | 100.0 | % |  |  | 100.0 | % |
| Cost of goods sold |  |  | 85.3 |  |  |  | 84.1 |  |  |  | 83.3 |  |
| Gross profit |  |  | 14.7 |  |  |  | 15.9 |  |  |  | 16.7 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |
| Selling and marketing |  |  | 2.8 |  |  |  | 2.7 |  |  |  | 2.7 |  |
| General and administrative |  |  | 7.6 |  |  |  | 7.7 |  |  |  | 7.3 |  |
| Amortization of definite-lived intangibles |  |  | 0.7 |  |  |  | 0.7 |  |  |  | 1.1 |  |
| Gain on sale of assets |  |  | — |  |  |  | (1.3 | ) |  |  | — |  |
| Restructuring charges |  |  | — |  |  |  | 0.3 |  |  |  | — |  |
| Impairment of long-lived assets |  |  | 0.1 |  |  |  | 0.8 |  |  |  | 1.3 |  |
| Impairment of goodwill and definite-lived intangibles |  |  | — |  |  |  | — |  |  |  | 14.8 |  |
| Total operating expenses |  |  | 11.2 |  |  |  | 10.9 |  |  |  | 27.2 |  |
| Operating income (loss) |  |  | 3.5 |  |  |  | 5.0 |  |  |  | (10.5 | ) |
| Other income (expense): |  |  |  |  |  |  |  |  |  |  |  |  |
| Interest expense |  |  | (1.8 | ) |  |  | (1.7 | ) |  |  | (1.9 | ) |
| Loss on extinguishment of debt |  |  | — |  |  |  | (0.8 | ) |  |  | (0.4 | ) |
| Other, net |  |  | — |  |  |  | 0.4 |  |  |  | 0.3 |  |
| Total other expense, net |  |  | (1.8 | ) |  |  | (2.1 | ) |  |  | (2.0 | ) |
| Income (loss) before income taxes |  |  | 1.7 |  |  |  | 2.9 |  |  |  | (12.5 | ) |
| Income tax provision |  |  | (0.6 | ) |  |  | (1.2 | ) |  |  | (0.9 | ) |
| Net income (loss) |  |  | 1.1 |  |  |  | 1.7 |  |  |  | (13.4 | ) |
| Less: Net (income) loss attributable to non-controlling interest |  |  | — |  |  |  | (0.1 | ) |  |  | 0.5 |  |
| Net income (loss) attributable to TTM Technologies, Inc. stockholders |  |  | 1.1 | % |  |  | 1.6 | % |  |  | (12.9 | )% |

[0001193125-15-069683:mdna:51]
We manage our worldwide operations based on two geographic operating segments: 1) Asia Pacific, which
consists of five PCB fabrication plants and 2) North America, which consists of seven domestic PCB fabrication plants, including a facility that provides follow-on value-added services primarily for one of the PCB fabrication plants, and one
backplane assembly plant in Shanghai, China, which is managed in conjunction with our U.S. operations. Each segment operates predominantly in the same industry with production facilities that produce customized products for their customers and use
similar means of product distribution.

[0001193125-15-069683:mdna:52]
48

[0001193125-15-069683:mdna:53]
The following table compares net sales by reportable segment for the years ended 2014, 2013
and 2012:

[0001193125-15-069683:mdna:54]
|  |  | For the Year Ended |  |
|  |  | December 29,2014 |  |  | December 30,2013 |  |  | December 31,2012 |  |
|  |  | (In thousands) |  |
| Net Sales: |  |  |  |  |  |  |  |  |  |  |  |  |
| Asia Pacific |  | $ | 811,107 |  |  | $ | 850,322 |  |  | $ | 842,443 |  |
| North America |  |  | 516,670 |  |  |  | 520,802 |  |  |  | 509,426 |  |
| Total sales |  |  | 1,327,777 |  |  |  | 1,371,124 |  |  |  | 1,351,869 |  |
| Inter-segment sales |  |  | (2,060 | ) |  |  | (2,909 | ) |  |  | (3,201 | ) |
| Total net sales |  | $ | 1,325,717 |  |  | $ | 1,368,215 |  |  | $ | 1,348,668 |  |

[0001193125-15-069683:mdna:55]
Net Sales

[0001193125-15-069683:mdna:56]
Total net sales decreased $42.5 million, or 3.1%, from $1,368.2 million for the year ended December 30, 2013 to $1,325.7 million for the year ended December 29, 2014. Net sales for the Asia
Pacific segment, excluding inter-segment sales, decreased $38.4 million, or 4.5%, from $847.4 million in the year ended December 30, 2013 to $809.0 million for the year ended December 29, 2014. This decrease was primarily due to the
absence of net sales resulting from the sale of a controlling equity interest in a subsidiary in the second quarter of 2013, combined with lower demand in our Computing/Storage/Peripherals and Cellular Phone end markets in the first and second
quarters of 2014. This decrease was partially offset by higher demand in our Cellular Phone end market in the second half of 2014. The overall decline in demand resulted in a 12% decrease in PCB shipments from the year December 30, 2013, and
was partially offset by a 9% increase in the average PCB selling price, which was driven by product mix shift. Net sales for the North America segment decreased $4.1 million, or 0.8%, from $520.8 million for the year ended December 30, 2013 to
$516.7 million for the year ended December 29, 2014. This decrease was primarily due to lower demand for PCB products in our Networking/Communications and Computing/Storage/Peripherals end markets, partially offset by an increase in demand for
backplane assemblies predominantly in our Networking/Communications end market.

[0001193125-15-069683:mdna:57]
Total net sales increased $19.5 million, or
1.4%, from $1,348.7 million for the year ended December 31, 2012 to $1,368.2 million for the year ended December 30, 2013. Net sales for the Asia Pacific segment, excluding inter-segment sales, increased $8.2 million, or 1.0%, from $839.2
million for the year ended December 31, 2012 to $847.4 million in the year ended December 30, 2013. This increase was primarily due to new customer programs in our Cellular Phone end market and an increase in average PCB selling price of
12%, which was driven by increased layer count and a product mix shift towards products utilizing advanced technology PCBs. The increase in net sales was partially offset by a specific product warranty claim amounting to $8.0 million, lower demand
in our Computing/Storage/Peripherals end market, and a 10% decrease in the volume of PCB shipments from the year ended December 31, 2012. Net sales for the North America segment increased $11.4 million, or 2.2%, from $509.4 million for the year
ended December 31, 2012 to $520.8 million for the year ended December 30, 2013. This increase was primarily due to higher demand in our Networking/Communications and Aerospace and Defense end markets partially offset by a decrease in our
Computing/Storage/Peripherals and Medical/Industrial/Instrumentation end markets. Average PCB selling price increased 11% due to greater advanced technology product mix and higher quick-turn work. This increase was partially offset by a 9% decline
in PCB sales volume.

[0001193125-15-069683:mdna:58]
The inter-segment sales are sales from the Asia Pacific operating segment to the North America operating
segment.

[0001193125-15-069683:mdna:59]
Gross Margin

[0001193125-15-069683:mdna:60]
Overall gross margin decreased from 15.9% for the year ended December 30, 2013 to 14.7% for the year ended December 29, 2014. Gross margin for the Asia Pacific segment decreased from 15.5% for
the year ended December 30, 2013 to 14.4% for the year ended December 29, 2014, primarily due to the underutilization of certain advanced technology production facilities and an unexpected power outage. Our Asia Pacific segment

[0001193125-15-069683:mdna:61]
experienced underutilization in the first and second quarters of 2014 caused by an increase in capacity to service an expected higher level of business which did not materialize. Additionally, in
the third quarter of 2014, our Asia Pacific segment experienced a 5 day production shut down due to an unexpected power outage at one of our advanced technology production facilities which negatively impacted our productivity and yield improvement
efforts as we were launching new products and significantly ramping for increased volumes. Gross margin for the North America segment decreased from 16.6% for the year ended December 30, 2013 to 15.1% for the year ended December 29, 2014,
primarily due to a mix shift toward lower margin assembly products and lower cost absorption due to lower production volumes at certain PCB fabrication plants.

[0001193125-15-069683:mdna:62]
Overall gross margin decreased from 16.7% for the year ended December 31, 2012 to 15.9% for the year ended December 30, 2013. Gross margin for the Asia Pacific segment decreased from 15.8% for
the year ended December 31, 2012 to 15.5% for the year ended December 30, 2013 primarily due to a specific product warranty claim amounting to $8.0 million, increased equipment related expenses, and higher labor costs. Gross margin for the
North America segment decreased from 18.2% for the year ended December 31, 2012 to 16.6% for the year ended December 30, 2013, primarily due to higher direct material content, labor costs and incentive compensation expense.

[0001193125-15-069683:mdna:63]
Selling and Marketing Expenses

[0001193125-15-069683:mdna:64]
Selling and marketing expenses decreased $0.2 million, or 0.5%, from $37.1 million for the year ended December 30, 2013 to $36.9 million for the year ended December 29, 2014. As a percentage of
net sales, selling and marketing expenses were 2.7% and 2.8% for the years ended December 30, 2013 and December 29, 2014, respectively. The decrease in selling and marketing expenses for the year ended December 29, 2014, was primarily
due to reduced commissions and lower travel expenses over the comparable periods of the prior year. Additionally, the increase in selling and marketing expense as a percentage of net sales for the year ended December 29, 2014 was primarily due
to lower net sales.

[0001193125-15-069683:mdna:65]
Selling and marketing expenses increased $1.1 million, or 3.1%, from $36.0 million for the year ended
December 31, 2012 to $37.1 million for the year ended December 30, 2013. The increase in selling and marketing expenses was primarily due to an increase in labor costs and stock-based compensation expense. As a percentage of net sales,
selling and marketing expenses were 2.7% for both of the years ended December 31, 2012 and December 30, 2013.

[0001193125-15-069683:mdna:66]
General and Administrative Expenses

[0001193125-15-069683:mdna:67]
General and administrative expenses decreased $4.9 million from $105.9 million, or 7.7% of net sales, for the year ended December 30, 2013 to $101.0 million, or 7.6% of net sales, for the year ended
December 29, 2014. The decrease in general and administrative expense for the year ended December 29, 2014 is primarily due to costs savings resulting from the sale of our controlling equity interest in a subsidiary in the Asia Pacific
operating segment and lower incentive compensation expense, offset by the $6.0 million of acquisition-related costs recorded in the third and fourth quarters of 2014.

[0001193125-15-069683:mdna:68]
General and administrative expenses increased $7.9 million from $98.0 million, or 7.3% of net sales, for the year ended December 31, 2012 to $105.9 million, or 7.7% of net sales, for the year ended
December 30, 2013. The increase in expense primarily relates to an increase in incentive compensation expense as well as increased labor costs, partially offset by lower stock-based compensation expense.

[0001193125-15-069683:mdna:69]
Impairment of Long-Lived Assets and Restructuring Charges

[0001193125-15-069683:mdna:70]
For the year ended December 29, 2014 and December 30, 2013, in conjunction with the shutdown of the Suzhou, China facility, we
recorded charges of $1.8 million and $10.8 million, respectively, primarily arising from the impairment of certain machinery and equipment. Additionally, in conjunction with the shutdown, we recorded restructuring charges of $3.4 million during the
year ended December 30, 2013, consisting of separation costs associated with the layoff of 774 employees.

[0001193125-15-069683:mdna:71]
During the year
ended December 31, 2012, we recorded an impairment charge in the Asia Pacific operating segment in the amount of $18.1 million. This impairment charge related specifically to two real estate assets for which there was expected underutilization
and limited market demand.

[0001193125-15-069683:mdna:72]
If forecasts and assumptions used to support the realizability of our long-lived assets
change in the future, significant impairment charges could result that would adversely affect our results of operations and financial condition.

[0001193125-15-069683:mdna:73]
Impairment of Goodwill and Definite-lived Intangibles

[0001193125-15-069683:mdna:74]
During the
year ended December 31, 2012, we performed an interim evaluation of goodwill and definite-lived intangibles as we believed there were impairment triggering events and circumstances that warranted an evaluation. These circumstances included
continued decreases in operating profit due to softer revenues and shifts in product mix when compared with projected results. These factors led to weaker than expected performance for the year ended December 31, 2012. As a result, we recorded
a charge for the impairment of goodwill and definite-lived intangibles in the amount of $200.3 million for the year ended December 31, 2012, consisting of charges of $171.4 million for goodwill and $28.9 million for definite-lived intangibles.

[0001193125-15-069683:mdna:75]
Other Income (Expense)

[0001193125-15-069683:mdna:76]
Other expense, net decreased $5.2 million from $29.4 million for the year ended December 30, 2013 to $24.2 million for year ended December 29, 2014. The decrease in other expense, net was
primarily due to the absence of a $10.7 million loss on the extinguishment of debt related to repurchase of a portion of convertible senior notes due 2015 for the year ended December 30, 2013, offset by an increase in foreign currency
transaction and derivative losses of $5.5 million, which includes a $3.6 million foreign currency transaction and derivative loss recognized in the first quarter of 2014 primarily due to the rapid depreciation of the RMB against the
U.S. Dollar.

[0001193125-15-069683:mdna:77]
Other expense, net increased $3.0 million from $26.4 million for year ended December 31, 2012 to $29.4
million for the year ended December 30, 2013. The increase in other expense, net was primarily due to a $5.2 million increase in the loss on extinguishment of debt related to repurchase of a significant portion of convertible senior notes due
2015 during the year ended December 30, 2013, combined with the absence of a $0.8 million realized gain on the sale of securities in 2012, offset by a decrease in interest expense by $1.8 million and a $1.3 million increase in foreign currency
transaction and derivative gains. The decrease in interest expense is primarily the result of the absence of the interest expense recognized from an interest rate swap that expired in April 2013.

[0001193125-15-069683:mdna:78]
Income Taxes

[0001193125-15-069683:mdna:79]
Our effective tax rate for the years ended December 29, 2014 and December 30, 2013 was 34.1% and 39.9%, respectively. The provision for income taxes decreased $8.3 million from an income tax
expense of $15.9 million for the year ended December 30, 2013 to $7.6 million for the year ended December 29, 2014. The decrease in our provision for income taxes was primarily due to losses incurred for the first three quarters of 2014
compared to income in the same period of the prior year, combined with (i) a $1.5 million discrete tax benefit recorded in the first quarter of 2014 resulting from the retroactive approval of the high technology enterprise status for a
subsidiary within the Asia Pacific operating segment, (ii) a $0.7 million discrete tax benefit recorded in the third quarter of 2014 resulting from the research and development deduction at a Chinese subsidiary within the Asia Pacific operating
segment, and (iii) the absence of local withholding taxes of approximately $4.9 million related to the sale of a controlling equity interest in a subsidiary in the second quarter of 2013.

[0001193125-15-069683:mdna:80]
Our effective tax rate is primarily impacted by tax rates in China and Hong Kong, the U.S. federal income tax rate, apportioned state
income tax rates, generation of other credits and deductions available to us, and certain non-deductible items. Certain foreign losses generated are not more likely than not to be realizable, and thus no income tax benefit has been recognized on
these losses. As of December 29, 2014 and December 30, 2013, we had net deferred income tax assets of approximately $2.9 million and $5.4 million, respectively. As of the end of 2014, based on our forecast for future taxable earnings, we
believe it is more likely than not that we will utilize the deferred income tax assets in future periods.

[0001193125-15-069683:mdna:81]
The provision for
income taxes increased $3.2 million from $12.7 million for the year ended December 31, 2012 to $15.9 million for the year ended December 30, 2013. Our effective tax rate was (7.6)% for the year

[0001193125-15-069683:mdna:82]
ended December 31, 2012 and 39.9% for the year ended December 30, 2013. During the year ended December 30, 2013, our tax rate was impacted by several discrete items including the
impairment of property, plant, and equipment related to the Suzhou, China plant shutdown, which resulted in no related tax benefit in 2013; enacted state law that changed the carryforward period of certain state tax credits resulting in the
recording of a valuation allowance in the amount of approximately $2.9 million against net deferred tax assets in 2013; release of the valuation allowance of $1.5 million for a foreign subsidiary; increase in deferred tax liabilities of $3.8 million
as certain events occurred that will cause a limitation on our ability to utilize foreign tax credits upon the future repatriation of foreign undistributed earnings of our backplane assembly facility in Shanghai, China; and local withholding taxes
of $4.9 million from the gain on the sale of our controlling interest in our SYE operation in China.

[0001193125-15-069683:mdna:83]
Liquidity and Capital Resources

[0001193125-15-069683:mdna:84]
Our principal sources of liquidity have been cash provided by operations, the issuance of convertible senior notes, and
term and revolving debt. Our principal uses of cash have been to finance capital expenditures, meet debt service requirements, fund working capital requirements, finance acquisitions, and refinance existing debt. We anticipate that financing
acquisitions, servicing debt, financing capital expenditures, and funding working capital requirements, will continue to be the principal demands on our cash in the future.

[0001193125-15-069683:mdna:85]
As of December 29, 2014, we had net working capital of approximately $302.1 million compared to $347.0 million as of December 30, 2013. This decrease in working capital is primarily attributable
to the payment of debt obligations and the reclassification of our convertible notes due in 2015 from long-term to current.

[0001193125-15-069683:mdna:86]
As
of December 29, 2014, we had cash and cash equivalents of approximately $279.0 million, of which approximately $82.1 million was held by our foreign subsidiaries. Of the cash and cash equivalents held by our foreign subsidiaries as of
December 29, 2014, $79.1 million was located in Asia and $3.0 million was located in Europe. Cash and cash equivalents located in our Asia Pacific operating segment are expected to be used in local operations. Cash and cash equivalents located
in our backplane assembly facility in Shanghai, China, as well as in Europe, which are managed in conjunction with our U.S. operations, totaled approximately $13.2 million and are available for repatriation and a deferred tax liability for U.S.
income taxes on undistributed earnings has been recorded.

[0001193125-15-069683:mdna:87]
Our 2015 capital expenditure plan is expected to total approximately
$100 million (of which approximately $80 million relates to our Asia Pacific operating segment). The expenditures will fund capital equipment purchases to increase production capacity, especially for advanced technology manufacturing, comply with
increased environmental regulations, replace aging equipment, and expand our technological capabilities. While our cash capital expenditures are expected to be approximately $100 million in 2015, we expect new capital expenditure purchases in 2015
to approximate $70 million.

[0001193125-15-069683:mdna:88]
Credit Agreement and Chinese Revolver

[0001193125-15-069683:mdna:89]
We are party to a facility agreement (the Credit Agreement) consisting of a $370.0 million senior secured Term Loan (the Term Loan), a
$90.0 million senior secured Revolving Loan (the Revolving Loan) and a secured $80.0 million Letters of Credit Facility (the Letters of Credit Facility). The Term Loan and Letters of Credit Facility will mature on September 14, 2016, and the
Revolving Loan will mature on March 14, 2016. The Credit Agreement is secured by substantially all of the assets of our Asia Pacific operating segment and is senior to all of our other debt, including the convertible senior notes. We have fully
and unconditionally guaranteed the full and timely payment of all Credit Agreement related obligations of the Asia Pacific operating segment.

[0001193125-15-069683:mdna:90]
Borrowings under the Credit Agreement bear interest at a floating rate of LIBOR plus an interest margin of 2.38%. At December 29, 2014, the weighted average interest rate on the outstanding
borrowings under the Credit Agreement was 2.55%.

[0001193125-15-069683:mdna:91]
Borrowings under the Credit Agreement are subject to certain financial and
operating covenants that include maintaining maximum total leverage ratios and minimum net worth, current ratio, and interest coverage ratios for both us and our Asia Pacific operating segment. In addition, our Credit Agreement includes a covenant
that the Principal Shareholders (as defined in the Shareholders Agreement dated April 9, 2010 as amended on September 14, 2012) will not reduce their shareholding below 15 percent of TTM’s issued shares. At December 29, 2014, we
were in compliance with the covenants.

[0001193125-15-069683:mdna:92]
We are required to pay a commitment fee of 0.50% per annum on any unused portion of the
loans and letters of credit facility granted under the Credit Agreement. We incurred $0.6 million for the year ended December 29, 2014 in commitment fees. As of December 29, 2014, the outstanding amount of the Term Loan was $273.8 million,
of which $96.2 million is due for repayment through September 2015 and is included as short-term debt, with the remaining $177.6 million included as long-term debt. None of the Revolving Loan associated with the Credit Agreement was outstanding at
December 29, 2014. Available borrowing capacity under the Revolving Loan was $90.0 million as of December 29, 2014.

[0001193125-15-069683:mdna:93]
We have an $80.0 million Letters of Credit Facility under the Credit Agreement. As of December 29, 2014, letters of credit in the
amount of $35.4 million were outstanding under our Credit Agreement, and other standby letters of credit were outstanding in the amount of $4.3 million. The other outstanding standby letters of credit expire between December 31, 2015 and
February 28, 2016.

[0001193125-15-069683:mdna:94]
We are party to a revolving loan credit facility with a lender in China, (the Chinese Revolver). Under
this arrangement, the lender has made available to us approximately $36.9 million in unsecured borrowing with all terms of the borrowing to be negotiated at the time the Chinese Revolver is drawn upon. There are no commitment fees on the unused
portion of the Chinese Revolver and this arrangement expires in December 2015. As of December 29, 2014, the Chinese Revolver had not been drawn upon.

[0001193125-15-069683:mdna:95]
Convertible Senior Notes due 2020

[0001193125-15-069683:mdna:96]
On December 20, 2013, we
issued 1.75% convertible senior notes due December 15, 2020, in a public offering for an aggregate principal amount of $220.0 million. The convertible senior notes bear interest at a rate of 1.75% per annum. Interest is payable
semiannually in arrears on June 15 and December 15 of each year. The convertible senior notes are senior unsecured obligations and rank equally to our future unsecured senior indebtedness and senior in right of payment to any of our future
subordinated indebtedness. Offering expenses are being amortized to interest expense over the term of the convertible senior notes.

[0001193125-15-069683:mdna:97]
Additionally, in January 2014, we closed the sale of an additional $30.0 million aggregate principal amount of our 1.75% convertible senior notes due 2020 (the Additional Notes). The Additional Notes were
sold pursuant to the exercise of an over-allotment option granted by us in the underwriting agreement related to the offer and sale of $220.0 million aggregate principal amount of our 1.75% convertible senior notes due 2020.

[0001193125-15-069683:mdna:98]
Conversion:    At any time prior to March 15, 2020, holders may convert their convertible senior
notes into cash and, if applicable, into shares of our common stock based on a conversion rate of 103.7613 shares of our common stock per $1,000 principal amount of convertible senior notes, subject to adjustment, under the following
circumstances: (1) during any calendar quarter beginning after March 31, 2014 (and only during such calendar quarter), if the last reported sale price of our common stock for at least 20 trading days during the 30 consecutive trading days
ending on the last trading day of the immediately preceding calendar quarter is greater than or equal to 130% of the applicable conversion price on each applicable trading day of such preceding calendar quarter; (2) during the five business day
period after any 10 consecutive trading day period in which the trading price per note for each day of that 10 consecutive trading day period was less than 98% of the product of the last reported sale price of our common stock and the conversion
rate on such day; or (3) upon the occurrence of specified corporate transactions described in the indenture governing the notes. As of December 29, 2014, none of the conversion criteria had been met.

[0001193125-15-069683:mdna:99]
On or after March 15, 2020 until the close of business on the third scheduled trading day preceding the maturity date, holders may
convert their notes at any time, regardless of the foregoing circumstances. Upon conversion, for each $1,000 principal amount of notes, we will pay shares of our common stock, cash or a combination of cash and shares of our common stock at our
election, if applicable, based on a daily conversion value calculated on a proportionate basis for each day of the 80 trading day observation period. All conversions occurring on the same date or on or after March 15, 2020 shall be settled
using the same settlement method. Additionally, in the event of a fundamental change as defined in the indenture governing the notes, or other conversion rate adjustments such as share splits or combinations, other distributions of shares, cash or
other assets to stockholders, including self-tender transactions (Other Conversion Rate Adjustments), the conversion rate may be modified to adjust the number of shares per $1,000 principal amount of the notes. As of December 29, 2014, none of
the criteria for a fundamental change or a conversion rate adjustment had been met.

[0001193125-15-069683:mdna:100]
The maximum number of shares issuable upon conversion, including the effect of a fundamental
change and subject to Other Conversion Rate Adjustments, would be 32.4 million.

[0001193125-15-069683:mdna:101]
Note
Repurchase:    We are not permitted to redeem the convertible senior notes at any time prior to maturity. In the event of a fundamental change or certain default events, as defined in the indenture governing the notes,
holders may require us to repurchase for cash all or a portion of their convertible senior notes at a price equal to 100% of the principal amount, plus any accrued and unpaid interest.

[0001193125-15-069683:mdna:102]
Convertible Note Hedge and Warrant Transaction:    In connection with the issuance of the convertible
senior notes due 2020 in both December 2013 and January 2014, we entered into a convertible note hedge and warrant transaction (the Call Spread Transaction), with respect to our common stock. The convertible note hedge, which cost an aggregate $66.3
million and was recorded, net of tax, as a reduction of additional paid-in capital, consists of our option to purchase up to 25.9 million common stock shares at a price of $9.64 per share. The hedge expires on December 15, 2020 and can
only be executed upon the conversion of the above mentioned convertible senior notes due 2020. Additionally, we sold warrants in both December 2013 and January 2014 to purchase 25.9 million shares of our common stock at a price of $14.26 per
share. The warrants expire ratably from March 2021 through January 2022. The aggregate proceeds from the sale of warrants of $33.8 million were recorded as an addition to additional paid-in capital. The 2020 Call Spread Transaction has no effect on
the terms of the convertible senior notes due 2020 and reduces potential dilution by effectively increasing the conversion price of the convertible senior notes due 2020 to $14.26 per share of our common stock.

[0001193125-15-069683:mdna:103]
Convertible Senior Notes due 2015

[0001193125-15-069683:mdna:104]
In May 2008, we issued $175.0 million of convertible senior notes. The convertible senior notes bear interest at a rate of 3.25% per annum. Interest is payable semiannually in arrears on
May 15 and November 15 of each year. The convertible senior notes are senior unsecured obligations and rank equally to our future unsecured senior indebtedness and senior in right of payment to any of our future subordinated indebtedness.
Offering expenses are being amortized to interest expense over the term of the convertible senior notes.

[0001193125-15-069683:mdna:105]
In December 2013, we
repurchased $136.1 million principal amount of notes at approximately 103.4% of their principal amount. Additionally, in January 2014, we repurchased $6.5 million principal amount of notes at approximately 103.4% of their principal amount. The
repurchases were accounted for as extinguishments of debt and, accordingly, we recognized losses of approximately $10.7 million for the year ended December 30, 2013 and $0.5 million for the year ended December 29, 2014, respectively,
primarily associated with the premium paid to repurchase the convertible senior notes and the recognition of certain remaining unamortized debt discount and issuance costs.

[0001193125-15-069683:mdna:106]
Financing Commitment and Current Liquidity Needs

[0001193125-15-069683:mdna:107]
Concurrently with
the execution of the Merger Agreement, we obtained a debt financing commitment in an aggregate amount of $1,115 million in connection with financing the transactions contemplated by the Merger Agreement. Assuming consummation of the Merger, we
intend to use the aggregate proceeds of such financing arrangements to finance the Merger, to refinance certain existing indebtedness of Viasystems, to refinance certain of our existing indebtedness, and to pay the fees and expenses incurred in
connection with the Merger. We are in the process of finalizing the specific financing arrangements.

[0001193125-15-069683:mdna:108]
Based on our current
level of operations, we believe that cash generated from operations, cash on hand and cash available from borrowings under our existing credit arrangements will be adequate to meet our currently anticipated capital expenditure, debt service, and
working capital needs for the next 12 months. However, assuming consummation of the Merger, we will enter into new borrowing arrangements to fund the Merger, fund our business operations, or refinance existing debt.

[0001193125-15-069683:mdna:109]
Prior to the Merger, our principal sources of liquidity have been cash provided by operations, the issuance of convertible senior notes,
and term and revolving debt. Following the Merger, we expect that our principal sources of liquidity will continue to be our existing cash and cash equivalents, cash flow from operations, as well as from funds available from financing arrangements
entered into in connection with the Merger. We expect that servicing debt, funding working capital requirements, financing capital expenditures, and financing acquisitions will continue to be the principal demands on our cash.

[0001193125-15-069683:mdna:110]
Contractual Obligations and Commitments

[0001193125-15-069683:mdna:111]
The following table provides information on our contractual obligations as of December 29, 2014:

[0001193125-15-069683:mdna:112]
| Contractual Obligations(1) |  | Total |  |  | Less Than1 Year |  |  | 1 - 3 Years |  |  | 4 - 5 Years |  |  | After5 Years |  |
|  |  | (In thousands) |  |
| Long-term debt obligations |  | $ | 273,804 |  |  | $ | 96,204 |  |  | $ | 177,600 |  |  | $ | — |  |  | $ | — |  |
| Convertible debt obligations |  |  | 282,395 |  |  |  | 32,395 |  |  |  | — |  |  |  | — |  |  |  | 250,000 |  |
| Interest on debt obligations |  |  | 35,146 |  |  |  | 10,616 |  |  |  | 11,405 |  |  |  | 8,750 |  |  |  | 4,375 |  |
| Foreign currency forward contract liabilities |  |  | 5,062 |  |  |  | 5,062 |  |  |  | — |  |  |  | — |  |  |  | — |  |
| Equipment payables |  |  | 47,212 |  |  |  | 47,212 |  |  |  | — |  |  |  | — |  |  |  | — |  |
| Purchase obligations |  |  | 19,389 |  |  |  | 17,121 |  |  |  | 2,268 |  |  |  | — |  |  |  | — |  |
| Operating lease commitments |  |  | 5,624 |  |  |  | 2,104 |  |  |  | 2,418 |  |  |  | 1,011 |  |  |  | 91 |  |
| Total contractual obligations |  | $ | 668,632 |  |  | $ | 210,714 |  |  | $ | 193,691 |  |  | $ | 9,761 |  |  | $ | 254,466 |  |

[0001193125-15-069683:mdna:113]
| (1) | Unrecognized uncertain tax benefits of $2.4 million are not included in the table above as the settlement timing is uncertain. |

[0001193125-15-069683:mdna:114]
Off Balance Sheet Arrangements

[0001193125-15-069683:mdna:115]
We do not currently have, nor have we ever had, any relationships with unconsolidated entities or financial partnerships, such as entities often referred to as structured finance or special purpose
entities, which would have been established for the purpose of facilitating off-balance sheet arrangements or other contractually narrow or limited purposes. In addition, we do not engage in trading activities involving non-exchange traded
contracts. As a result, we are not materially exposed to any financing, liquidity, market, or credit risk that could arise if we had engaged in these relationships.

[0001193125-15-069683:mdna:116]
Seasonality

[0001193125-15-069683:mdna:117]
As a result of the product and customer mix of our Asia
Pacific operating segment, our revenue is subject to seasonal fluctuations. These fluctuations include seasonal patterns in the computer and cellular phone industries, which together have become a significant portion of the end markets we serve.
This seasonality typically results in higher net sales in the third and fourth quarters due to end customer demand to meet fourth quarter sales of consumer electronics products. Seasonal fluctuations also include the Chinese New Year holidays in the
first quarter, which typically results in lower net sales. We attribute this decline to shutdowns of our customers’ manufacturing facilities surrounding the Chinese New Year public holidays, which normally occur in January or February of each
year.

[0001193125-15-069683:mdna:118]
Recently Issued Accounting Standards

[0001193125-15-069683:mdna:119]
In August 2014, the Financial Accounting Standards Board (FASB) issued Accounting Standards Update No. (ASU) 2014-15 Disclosure of Uncertainties About an Entity’s Ability to Continue as a Going
Concern, which provides guidance on determining when and how to disclose going concern uncertainties in the financial statements. The new standard requires management to perform interim and annual assessments of an entity’s ability to
continue as a going concern. The update is effective for annual periods ending after December 15, 2016, and interim periods thereafter. Early adoption is permitted. The impact on our financial statements of adopting ASU 2014-15 is currently
being assessed by management.

[0001193125-15-069683:mdna:120]
In May 2014, the FASB issued ASU 2014-09, Revenue from Contracts with Customers,
which requires an entity to recognize the amount of revenue to which it expects to be entitled for the transfer of promised goods or services to customers. ASU 2014-09 will replace most existing revenue recognition guidance in U.S. GAAP when it
becomes effective. The new standard is effective for us at the beginning of fiscal year 2017. Early application is not permitted. The standard permits the use of either the retrospective or cumulative effect

[0001193125-15-069683:mdna:121]
transition method. We are evaluating the effect that ASU 2014-09 will have on our consolidated financial statements and related disclosures. We have not yet selected a transition method nor have
we determined the effect of the standard on our ongoing financial reporting.

[0001193125-15-069683:mdna:122]
In July 2013, the FASB issued an update that
would require an unrecognized tax benefit, or a portion of an unrecognized benefit, to be presented in the financial statements as a reduction to a deferred tax asset for a net operating loss carryforward, a similar tax loss, or a tax credit
carryforward. This update is effective for interim and annual periods beginning after December 15, 2013, with early adoption permitted. Our adoption of this updated standard in 2014 did not have a material impact on our financial statements.
