# TTMI MD&A — 0001564590-20-037715


## mdna

[0001564590-20-037715:mdna:1]
[same as prior period, unchanged from 0001564590-20-022818:mdna:1]

[0001564590-20-037715:mdna:2]
[same as prior period, unchanged from 0001564590-20-022818:mdna:2]

[0001564590-20-037715:mdna:3]
We are a leading global printed circuit board (PCB) manufacturer, focusing on quick-turn and volume production of technologically advanced PCBs and backplane assemblies as well as a global designer and manufacturer of high-frequency radio frequency (RF) and microwave components and assemblies. We focus on providing time-to-market and volume production of advanced technology products and offer a one-stop design, engineering and manufacturing solution to our customers. This one-stop design, engineering and manufacturing solution allows us to align technology development with the diverse needs of our customers and to enable them to reduce the time required to develop new products and bring them to market. We serve a diversified customer base consisting of approximately 1,200 customers in various markets throughout the world, including aerospace and defense, computing, automotive components, medical, industrial and instrumentation related products, as well as networking/communications infrastructure products. Our customers include both original equipment manufacturers (OEMs) and electronic manufacturing services (EMS) providers.

[0001564590-20-037715:mdna:4]
[same as prior period, unchanged from 0001564590-20-022818:mdna:4]

[0001564590-20-037715:mdna:5]
[same as prior period, unchanged from 0001564590-20-022818:mdna:5]

[0001564590-20-037715:mdna:6]
[same as prior period, unchanged from 0001564590-20-022818:mdna:8]

[0001564590-20-037715:mdna:7]
[same as prior period, unchanged from 0001564590-20-022818:mdna:9]

[0001564590-20-037715:mdna:8]
While our customers include both OEMs and EMS providers, we measure customers based on OEM companies, as they are the ultimate end customers. Sales to our ten largest customers accounted for 36% and 38% of our net sales for the quarter and two quarters ended June 29, 2020. Sales to our ten largest customers accounted for 40% and 41% of our net sales for the quarter and two quarters ended July 1, 2019, respectively. We sell to OEMs both directly and indirectly through EMS providers.

[0001564590-20-037715:mdna:9]
[same as prior period, unchanged from 0001564590-20-022818:mdna:11]

[0001564590-20-037715:mdna:10]
|  |  | Quarter Ended |  |  |  | Two Quarters Ended |  |  |
| End Markets (1) |  | June 29, 2020 |  |  |  | July 1, 2019 |  |  |  | June 29, 2020 |  |  |  | July 1, 2019 |  |  |
| Aerospace and Defense |  |  | 33 |  | % |  |  | 33 |  | % |  |  | 35 |  | % |  |  | 32 |  | % |
| Automotive |  |  | 12 |  |  |  |  | 18 |  |  |  |  | 13 |  |  |  |  | 19 |  |  |
| Cellular Phone |  |  | — |  |  |  |  | — |  |  |  |  | — |  |  |  |  | — |  |  |
| Computing/Storage/Peripherals |  |  | 13 |  |  |  |  | 11 |  |  |  |  | 12 |  |  |  |  | 11 |  |  |
| Medical/Industrial/Instrumentation |  |  | 20 |  |  |  |  | 18 |  |  |  |  | 20 |  |  |  |  | 17 |  |  |
| Networking/Communications |  |  | 19 |  |  |  |  | 19 |  |  |  |  | 18 |  |  |  |  | 19 |  |  |
| Other (2) |  |  | 3 |  |  |  |  | 1 |  |  |  |  | 2 |  |  |  |  | 2 |  |  |
| Total |  |  | 100 |  | % |  |  | 100 |  | % |  |  | 100 |  | % |  |  | 100 |  | % |

[0001564590-20-037715:mdna:11]
[same as prior period, unchanged from 0001564590-20-022818:mdna:13]

[0001564590-20-037715:mdna:12]
| (2) | Other consumer devices that include wearables, portable video devices and personal headphones are included in the Other end market. |

[0001564590-20-037715:mdna:13]
[same as prior period, unchanged from 0001564590-20-022818:mdna:15]

[0001564590-20-037715:mdna:14]
[same as prior period, unchanged from 0001564590-20-022818:mdna:16]

[0001564590-20-037715:mdna:15]
[same as prior period, unchanged from 0001564590-20-022818:mdna:17]

[0001564590-20-037715:mdna:16]
[same as prior period, unchanged from 0001564590-20-022818:mdna:18]

[0001564590-20-037715:mdna:17]
[same as prior period, unchanged from 0001564590-20-022818:mdna:19]

[0001564590-20-037715:mdna:18]
General and administrative costs primarily include the salaries for executive, finance, accounting, information technology, facilities, and human resources personnel, as well as expenses for restructuring, accounting, legal assistance and incentive compensation expense, and gains or losses on the sale or disposal of property, plant and equipment.

[0001564590-20-037715:mdna:19]
Research and development expenses consist primarily of salaries and labor related benefits paid to our research and development staff, as well as material costs.

[0001564590-20-037715:mdna:20]
[same as prior period, unchanged from 0001564590-20-022818:mdna:22]

[0001564590-20-037715:mdna:21]
[same as prior period, unchanged from 0001564590-20-022818:mdna:23]

[0001564590-20-037715:mdna:22]
[same as prior period, unchanged from 0001564590-20-022818:mdna:24]

[0001564590-20-037715:mdna:23]
[same as prior period, unchanged from 0001564590-20-022818:mdna:25]

[0001564590-20-037715:mdna:24]
[same as prior period, unchanged from 0001564590-20-022818:mdna:26]

[0001564590-20-037715:mdna:25]
|  |  | Quarter Ended |  | Two Quarters Ended |
|  |  | June 29, 2020 |  |  |  | July 1, 2019 |  |  |  | June 29, 2020 |  |  |  | July 1, 2019 |  |  |
| Net sales |  |  | 100.0 |  | % |  |  | 100.0 |  | % |  |  | 100.0 |  | % |  |  | 100.0 |  | % |
| Cost of goods sold |  |  | 82.4 |  |  |  |  | 82.4 |  |  |  |  | 83.0 |  |  |  |  | 82.0 |  |  |
| Gross profit |  |  | 17.6 |  |  |  |  | 17.6 |  |  |  |  | 17.0 |  |  |  |  | 18.0 |  |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Selling and marketing |  |  | 2.8 |  |  |  |  | 3.2 |  |  |  |  | 3.0 |  |  |  |  | 3.2 |  |  |
| General and administrative |  |  | 8.2 |  |  |  |  | 6.0 |  |  |  |  | 7.6 |  |  |  |  | 5.8 |  |  |
| Research and development |  |  | 0.9 |  |  |  |  | 0.9 |  |  |  |  | 0.9 |  |  |  |  | 0.9 |  |  |
| Amortization of definite-lived intangibles |  |  | 1.7 |  |  |  |  | 2.0 |  |  |  |  | 1.8 |  |  |  |  | 2.5 |  |  |
| Total operating expenses |  |  | 13.6 |  |  |  |  | 12.1 |  |  |  |  | 13.3 |  |  |  |  | 12.4 |  |  |
| Operating income |  |  | 4.0 |  |  |  |  | 5.5 |  |  |  |  | 3.7 |  |  |  |  | 5.6 |  |  |
| Other (expense) income: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Interest expense |  |  | (3.3 | ) |  |  |  | (3.9 | ) |  |  |  | (3.6 | ) |  |  |  | (3.9 | ) |  |
| Other, net |  |  | 0.1 |  |  |  |  | 0.6 |  |  |  |  | 0.3 |  |  |  |  | 0.2 |  |  |
| Total other expense, net |  |  | (3.2 | ) |  |  |  | (3.3 | ) |  |  |  | (3.3 | ) |  |  |  | (3.7 | ) |  |
| Income from continuing operations before income taxes |  |  | 0.8 |  |  |  |  | 2.2 |  |  |  |  | 0.4 |  |  |  |  | 1.9 |  |  |
| Income tax benefit (provision) |  |  | 0.8 |  |  |  |  | 0.2 |  |  |  |  | 0.2 |  |  |  |  | (0.1 | ) |  |
| Net income from continuing operations |  |  | 1.6 |  | % |  |  | 2.4 |  | % |  |  | 0.6 |  | % |  |  | 1.8 |  | % |

[0001564590-20-037715:mdna:26]
[same as prior period, unchanged from 0001564590-20-022818:mdna:28]

[0001564590-20-037715:mdna:27]
[same as prior period, unchanged from 0001564590-20-022818:mdna:29]

[0001564590-20-037715:mdna:28]
Total net sales increased $43.4 million, or 8.2%, to $570.3 million for the second quarter of 2020 from $526.9 million for the second quarter of 2019. This increase primarily resulted from an increase in net sales for the PCB reportable segment of $53.1 million, or 11.4%, to $520.1 million for the second quarter of 2020 from $467.0 million for the second quarter of 2019. The increase was primarily due to increased demand in our Medical/Industrial/Instrumentation, Computing/Storage/Peripherals, and Aerospace and Defense end markets, partially offset by lower demand in our Automotive end market. These changes resulted in a higher price per square foot of 22.5%, driven mainly by product mix shift, however the resulting increase in net sales was partially offset by a 13.3% decrease in the volume of PCB shipments as compared to the second quarter of 2019. The increase in net sales was partially offset by a reduction in net sales for the E-M Solutions reportable segment of $9.7 million, or 16.2%, to $50.2 million for the second quarter of 2020 from $59.9 million for the second quarter of 2019. The decrease was primarily due to lower demand in our Automotive and Medical/Industrial/Instrumentation end markets, partially offset by increased demand in our Networking/Communications end market.

[0001564590-20-037715:mdna:29]
Total net sales increased $4.6 million, or 0.4%, to $1,067.9 million for the first two quarters of 2020 from $1,063.3 million for the first two quarters of 2019. This increase primarily resulted from an increase in net sales for the PCB reportable segment of $35.5 million, or 3.7%, to $987.5 million for the first two quarters of 2020 from $952.0 million for the first two quarters of 2019. The increase was primarily due to increased demand in our Medical/Industrial/Instrumentation, Aerospace and Defense, and Computing/Storage/Peripherals end markets, partially offset by lower demand in our Automotive and Networking/Communications end markets. These changes resulted in a higher price per square foot of 24.6%, driven mainly by product mix shift, however the resulting increase in net sales was partially offset by an 18.7% decrease in the volume of PCB shipments as compared to the first two quarters of 2019. The increase in net sales was partially offset by a reduction in net sales for the E-M Solutions reportable segment of $30.8 million, or 27.7%, to $80.5 million for the first two quarters of 2020 from $111.3 million for the first two quarters of 2019. The decrease was primarily due to lower demand in our Automotive and Medical/Industrial/Instrumentation end markets, partially offset by increased demand in our Networking/Communications end market.

[0001564590-20-037715:mdna:30]
[same as prior period, unchanged from 0001564590-20-022818:mdna:31]

[0001564590-20-037715:mdna:31]
Overall gross margin was 17.6% for the both the second quarter of 2020 and the second quarter of 2019. Gross margin for the PCB reportable segment increased to 20.3% for the second quarter of 2020 from 19.6% for the second quarter of 2019, primarily due to higher volumes in our commercially focused facilities. Gross margin for the E-M Solutions reportable segment decreased to

[0001564590-20-037715:mdna:32]
(1.1%) for the second quarter of 2020 from 7.3% for the second quarter of 2019, primarily due to lower sales and additional provision for excess and obsolete inventories.

[0001564590-20-037715:mdna:33]
Overall gross margin decreased to 17.0% for the first two quarters of 2020 from 18.0% for the first two quarters of 2019. Gross margin for the PCB reportable segment decreased to 19.5% for the first two quarters of 2020 from 19.9% for the first two quarters of 2019. Gross margin for the E-M Solutions reportable segment decreased to (2.8%) for the first two quarters of 2020 from 6.8% for the first two quarters of 2019, primarily due to lower sales and additional provision for excess and obsolete inventories.

[0001564590-20-037715:mdna:34]
Capacity utilization is a key driver for us, which is measured by the actual production as a percentage of maximum capacity. This measure is particularly important in our high volume facilities in Asia, as a significant portion of our operating costs are fixed in nature. Capacity utilization for the second quarter of 2020 in our Asia and North America PCB facilities was 70% and 63%, respectively, compared to 60% and 62%, respectively, for the second quarter of 2019. Capacity utilization for the first two quarters of 2020 in our Asia and North America PCB facilities was 61% and 65%, respectively, compared to 62% and 62%, respectively for the first two quarters of 2019. The significant increase in capacity utilization in our Asia PCB facilities for the second quarter of 2020 compared to the second quarter of 2019 was primarily due to an increase in production related to increased sales in our Medical/Industrial/Instrumentation and Computing/Storage/Peripherals end markets.

[0001564590-20-037715:mdna:35]
[same as prior period, unchanged from 0001564590-20-022818:mdna:34]

[0001564590-20-037715:mdna:36]
Selling and marketing expenses decreased $0.9 million, to $16.0 million for the second quarter of 2020 from $16.9 million for the second quarter of 2019. As a percentage of net sales, selling and marketing expenses was 2.8% for the second quarter of 2020, as compared to 3.2% for the second quarter of 2019. The decrease in selling and marketing expense for the quarter ended June 29, 2020 was primarily due to reduced travel expense due to the COVID-19 pandemic, which has decreased travel on a temporary basis.

[0001564590-20-037715:mdna:37]
Selling and marketing expenses decreased $2.4 million, to $32.1 million for the first two quarters of 2020 from $34.5 million for the first two quarters of 2019. As a percentage of net sales, selling and marketing expenses was 3.0% for the first two quarters of 2020, as compared to 3.2% for the first two quarters of 2019. The decrease in selling and marketing expense for the two quarters ended June 29, 2020 was primarily due to reduced travel and commission expense.

[0001564590-20-037715:mdna:38]
[same as prior period, unchanged from 0001564590-20-022818:mdna:36]

[0001564590-20-037715:mdna:39]
General and administrative expenses increased $14.9 million to $46.7 million, or 8.2% of net sales, for the second quarter of 2020 from $31.9 million, or 6.0% of net sales, for the second quarter of 2019. The increase in general and administrative expenses for the quarter ended June 29, 2020 was primarily due to the increase in restructuring charges of $10.7 million associated with the restructuring of its E-M Solutions business unit and higher incentive compensation and supplies expense.

[0001564590-20-037715:mdna:40]
General and administrative expenses increased $19.2 million to $81.4 million, or 7.6% of net sales, for the first two quarters of 2020 from $62.2 million, or 5.8% of net sales, for the first two quarters of 2019. The increase in general and administrative expenses for the two quarters ended June 29, 2020 was primarily due to the increase in restructuring charges of $10.6 million associated with the restructuring of its E-M Solutions business unit and higher incentive compensation and supplies expense.

[0001564590-20-037715:mdna:41]
Other (Expense) Income

[0001564590-20-037715:mdna:42]
Other expense, net increased $0.6 million to $18.1 million for the second quarter of 2020 from $17.5 million for the second quarter of 2019. The increase in other expense, net for the quarter ended June 29, 2020 was primarily the result of lower foreign currency gains due to the depreciation of the Chinese Renminbi (RMB) in the second quarter of 2020 compared to the second quarter of 2019. We utilize the RMB at our China facilities for employee-related expenses, RMB denominated purchases, and other costs of running our operations in China. This was partially offset by a decrease in interest expense of $2.0 million mainly as a result of lower interest rates.

[0001564590-20-037715:mdna:43]
Other expense, net decreased $3.6 million to $35.4 million for the first two quarters of 2020 from $39.0 million for the first two quarters of 2019. The decrease in other expense, net for the two quarters ended June 29, 2020 was primarily due to the decrease in interest expense of $3.3 million mainly as a result of lower interest rates and a $30.0 million debt pay down for the Term Loan Facility during February 2019, and decrease in other income related to the sale of other assets of $2.8 million. This was partially offset by lower foreign currency gains due to the depreciation of the RMB in the first two quarters of 2020 compared to the first two quarters of 2019.

[0001564590-20-037715:mdna:44]
[same as prior period, unchanged from 0001564590-20-022818:mdna:40]

[0001564590-20-037715:mdna:45]
The income tax benefit increased by $3.5 million to $4.5 million of tax benefit for the second quarter of 2020 from $1.0 million of tax benefit for the second quarter of 2019. The increase in income tax benefit for the second quarter of 2020 was primarily due to an increase in the release of uncertain tax positions due to the expiration of the statute of limitation in foreign jurisdictions netted against an increase in the valuation allowance and withholding tax expense related to the announced closure of two of the E-M Solutions plants.

[0001564590-20-037715:mdna:46]
The income tax benefit increased by $3.6 million to $2.3 million of tax benefit for the first two quarters of 2020 from $1.3 million of tax expense for the first two quarters of 2019. The increase in income tax benefit for the first two quarters of 2020 was primarily due to (i) a decrease in continuing operating income, (ii) an increase in the release of uncertain tax positions due to the expiration of the statute of limitation in foreign jurisdictions, (iii) an increase related to the retroactive approval of the Company’s renewal application for High and New Tax Enterprise status for two of the Company’s manufacturing subsidiaries in China, netted against (iv) an increase in the valuation allowance and withholding tax deferred tax liability related to the announced closure of two of the E-M Solutions plants.

[0001564590-20-037715:mdna:47]
Our effective tax rate is primarily impacted by tax rates in China and Hong Kong, the U.S. federal income tax rate, apportioned state income tax rates, the generation of credits and deductions available to us, as well as changes in valuation allowances and certain non-deductible items. We had a net deferred income tax liability of approximately $10.9 million as of June 29, 2020 and a net deferred income tax asset of approximately $12.6 million as of July 1, 2019.

[0001564590-20-037715:mdna:48]
On March 27, 2020, the President of the United States signed the Coronavirus Aid, Relief, and Economic Security Act (CARES Act) providing economic relief to disruptions caused by the Coronavirus pandemic. Accounting Standard Codification (ASC) 740, Accounting for Income Taxes, requires companies to recognize the effect of tax law changes in the period of enactment regardless of the effective date of those tax law changes. We considered the impact to our financial statements of the corporate income tax aspects of the CARES Act and determined the impact is not material to our financial statements. The CARES Act includes a number of provisions, including the increase of IRC Section 163(j) interest expense deduction limitation of Adjusted Tax Income (ATI) from 30% to 50%. This is applicable to 2019 and 2020 tax years. The Company accounted for such change in the Q1 2020 provision calculation. There are also provisions that allow for a 100% refund of Alternative Minimum Tax Credit carryforwards and which postpone tax compliance deadlines and payments ordinarily due April 15, 2020.

[0001564590-20-037715:mdna:49]
[same as prior period, unchanged from 0001564590-20-022818:mdna:44]

[0001564590-20-037715:mdna:50]
Our principal sources of liquidity have been cash provided by operations, the issuance of debt, and borrowings under our Revolving Credit Facility. Our principal uses of cash have been to finance capital expenditures, finance acquisitions, meet debt service requirements, fund working capital requirements, and pay down existing debt. We anticipate that servicing debt, financing capital expenditures, financing acquisitions, and funding working capital requirements will continue to be the principal demands on our cash in the future.

[0001564590-20-037715:mdna:51]
Cash flow provided by operating activities for continuing operations during the first two quarters of 2020 was $107.4 million as compared to cash flow provided by operating activities for continuing operations of $120.3 million in the same period in 2019. The decrease in cash flow was primarily due to the $12.6 million decrease in net income from continuing operations to $6.1 million for the first two quarters of 2020 from $18.7 million in the same period in 2019.

[0001564590-20-037715:mdna:52]
Net cash used in investing activities for continuing operations was approximately $45.3 million for the first two quarters of 2020, reflecting purchases of property, plant and equipment and other assets. Net cash used in investing activities for continuing operations was approximately $50.2 million for the first two quarters of 2019, reflecting $55.9 million for purchases of property, plant and equipment and other assets less proceeds from sale of property, plant and equipment and other assets of $5.7 million.

[0001564590-20-037715:mdna:53]
There was no activity related to cash flows from financing activities for the first two quarters of 2020. Net cash used in financing activities was approximately $31.5 million for the first two quarters of 2019, reflecting repayment of long-term debt of $30.0 million and payment of debt issuance costs of $1.5 million.

[0001564590-20-037715:mdna:54]
As of June 29, 2020, we had cash and cash equivalents of approximately $694.7 million, of which approximately $389.4 million was held by our foreign subsidiaries, primarily in Hong Kong and China.

[0001564590-20-037715:mdna:55]
Our 2020 net capital expenditures and asset acquisitions are expected to be in the range of $100.0 million to $110.0 million.

[0001564590-20-037715:mdna:56]
[same as prior period, unchanged from 0001564590-20-022818:mdna:51]

[0001564590-20-037715:mdna:57]
[same as prior period, unchanged from 0001564590-20-022818:mdna:52]

[0001564590-20-037715:mdna:58]
As of June 29, 2020, we had $1,482.8 million of outstanding debt, net of discount and debt issuance costs, composed of $798.0 million of Term Loan debt due September 2024, $370.1 million of Senior Notes due October 2025, $244.7 million of Convertible Senior Notes due December 2020, $40.0 million under the U.S. ABL, and $30.0 million under the Asia ABL. Subsequent to June 29, 2020, we made a debt principal prepayment for the Term Loan of $400.0 million.

[0001564590-20-037715:mdna:59]
Borrowings under the Term Loan Facility and Senior Notes Facility are subject to certain affirmative and negative covenants, including limitations on indebtedness, corporate transactions, investments, dispositions, and share payments. Under the occurrence of certain events, the ABL Revolving Loans are subject to various financial and operational covenants, including maintaining minimum fixed charge coverage ratios. As of June 29, 2020, we were in compliance with the covenants under the Term Loan Facility, Senior Notes Facility and ABL Revolving Loans.

[0001564590-20-037715:mdna:60]
[same as prior period, unchanged from 0001564590-20-022818:mdna:55]

[0001564590-20-037715:mdna:61]
[same as prior period, unchanged from 0001564590-20-022818:mdna:56]

[0001564590-20-037715:mdna:62]
[same as prior period, unchanged from 0001564590-20-022818:mdna:57]

[0001564590-20-037715:mdna:63]
[same as prior period, unchanged from 0001564590-20-022818:mdna:58]

[0001564590-20-037715:mdna:64]
[same as prior period, unchanged from 0001564590-20-022818:mdna:59]

[0001564590-20-037715:mdna:65]
[same as prior period, unchanged from 0001564590-20-022818:mdna:60]

[0001564590-20-037715:mdna:66]
[same as prior period, unchanged from 0001564590-20-022818:mdna:61]

[0001564590-20-037715:mdna:67]
Recently Issued Accounting Standards

[0001564590-20-037715:mdna:68]
[same as prior period, unchanged from 0001564590-20-022818:mdna:63]
