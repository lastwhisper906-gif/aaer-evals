# TTMI note change history — 0001564590-20-022818 → 0001564590-20-037715


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2020-08-06):
[0001564590-20-037715:note_history:1]
The Company is subject to various legal matters, which it considers normal for its business activities. While the Company currently believes that the amount of any reasonably possible loss for known matters would not be material to the Company’s financial condition, the outcome of these actions is inherently difficult to predict. In the event of an adverse outcome, the ultimate potential loss could have a material adverse effect on the Company’s financial condition or results of operations in a particular period. The Company has accrued amounts for its loss contingencies which are probable and estimable as of June 29, 2020 and December 30, 2019. However, these amounts are not material to the consolidated condensed financial statements of the Company.
  (was, 2020-05-07, similarity 0.994):
[0001564590-20-022818:note_history:1]
The Company is subject to various legal matters, which it considers normal for its business activities. While the Company currently believes that the amount of any reasonably possible loss for known matters would not be material to the Company’s financial condition, the outcome of these actions is inherently difficult to predict. In the event of an adverse outcome, the ultimate potential loss could have a material adverse effect on the Company’s financial condition or results of operations in a particular period. The Company has accrued amounts for its loss contingencies which are probable and estimable as of March 30, 2020 and December 30, 2019. However, these amounts are not material to the consolidated condensed financial statements of the Company.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureAndSignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2020-08-06):
[0001564590-20-037715:note_history:2]
TTM Technologies, Inc. (the Company or TTM) is a leading global printed circuit board (PCB) manufacturer, focusing on quick-turn and volume production of technologically advanced PCBs and backplane assemblies as well as a global designer and manufacturer of high-frequency radio frequency (RF) and microwave components and assemblies. The Company provides time-to-market and volume production of advanced technology products and offers a one-stop design, engineering and manufacturing solution to customers. This one-stop design and manufacturing solution enables the Company to align technology developments with the diverse needs of the Company’s customers and to enable them to reduce the time required to develop new products and bring them to market.
  (was, 2020-05-07, similarity 0.9325):
[0001564590-20-022818:note_history:2]
TTM Technologies, Inc. (the Company or TTM) is a leading global printed circuit board (PCB) manufacturer, focusing on quick-turn and volume production of technologically complex PCBs, backplane assemblies and electro-mechanical solutions (E-M Solutions) as well as a global designer and manufacturer of radio-frequency (RF) and microwave components and assemblies. The Company provides time-to-market and volume production of advanced technology products and offers a one-stop design, engineering and manufacturing solution to customers. This one-stop design and manufacturing solution enables the Company to align technology developments with the diverse needs of the Company’s customers and to enable them to reduce the time required to develop new products and bring them to market.

- changed (2020-08-06):
[0001564590-20-037715:note_history:3]
The Company serves a diversified customer base in various markets throughout the world, including aerospace and defense, computing, automotive components, medical, industrial and instrumentation related products, as well as networking/communications infrastructure products. The Company’s customers include both original equipment manufacturers (OEMs) and electronic manufacturing services (EMS) providers.
  (was, 2020-05-07, similarity 0.9863):
[0001564590-20-022818:note_history:3]
The Company serves a diversified customer base in various markets throughout the world, including aerospace and defense, automotive components, medical, industrial and instrumentation related products, as well as networking/communications infrastructure products. The Company’s customers include both original equipment manufacturers (OEMs) and electronic manufacturing services (EMS) providers.

- added (2020-08-06):
[0001564590-20-037715:note_history:4]
On January 19, 2020, the Company entered into a definitive equity interests purchase agreement with AKMMeadville Electronics (Xiamen) Co., Ltd (the Purchaser) for the sale of the Company’s following subsidiaries, which was completed on April 17, 2020: Shanghai Kaiser Electronics Co., Ltd. (SKE), Shanghai Meadville Electronics Co., Ltd. (SME), Shanghai Meadville Science & Technology Co., Ltd. (SP) and Guangzhou Meadville Electronics Co., Ltd. (GME) (collectively, the Mobility business unit). Prior to the closing of the sale of the Company’s Mobility business unit, all assets and liabilities attributable to the Mobility business unit have been aggregated under the captions “Current assets held for sale”, “Non-current assets held for sale”, “Current liabilities held for sale” and “Non-current liabilities held for sale”. For all periods presented in the consolidated condensed statements of operations, all sales, costs, expenses, income taxes and gain on sale attributable to the Mobility business unit have been aggregated under the caption “Income from discontinued operations, net of income taxes”. Prior year results have been recast to conform with the current presentation. Refer to Note 2, Discontinued Operations, for additional information.

- changed (2020-08-06):
[0001564590-20-037715:note_history:5]
Certain prior year amounts in the consolidated condensed financial statements have been reclassified due to the sale of the Company’s Mobility business unit. Refer to Note 2, Discontinued Operations, for further information regarding this sale and the resulting prior year reclassifications. Further, in 2020, the Company began presenting research and development expenses as a separate line item on the consolidated condensed statements of operations to better align with similar presentation made by peers and to provide additional disclosure that is meaningful for investors. The prior year consolidated condensed statements of operations were adjusted to conform with this new presentation. Research and development expense were previously presented within general and administrative expense on the consolidated condensed statements of operations.
  (was, 2020-05-07, similarity 0.9799):
[0001564590-20-022818:note_history:5]
Certain prior year amounts in the condensed consolidated financial statements have been reclassified due to the sale of the Company’s Mobility business unit. Refer to Note 2, Discontinued Operations, for further information regarding this sale and the resulting prior year reclassifications. Further, in 2020, the Company began presenting research and development expenses as a separate line item on the consolidated condensed statements of operations to better align with similar presentation made by peers and to provide additional disclosure that is meaningful for investors. The prior year consolidated condensed statements of operations were adjusted to conform with this new presentation. Research and development expense were previously presented within general and administrative expense on the consolidated condensed statements of operations.

- changed (2020-08-06):
[0001564590-20-037715:note_history:6]
In August 2018, the FASB issued ASU 2018-14, Compensation—Retirement Benefits—Defined Benefit Plans—General (Subtopic 715-20)—Disclosure Framework—Changes to the Disclosure Requirements for Defined Benefit Plans. The amendments in this update change the disclosure requirements for employers that sponsor defined benefit pension and/or other postretirement benefit plans. It eliminates requirements for certain disclosures that are no longer considered cost beneficial and requires new disclosures that the FASB considers pertinent. The guidance is effective for fiscal years ending after December 15, 2020. Early adoption is permitted. The Company does not anticipate the adoption will have a material impact on its consolidated condensed financial statements and related disclosures.
  (was, 2020-05-07, similarity 0.9961):
[0001564590-20-022818:note_history:6]
In August 2018, the FASB issued ASU 2018-14, Compensation—Retirement Benefits—Defined Benefit Plans—General (Subtopic 715-20)—Disclosure Framework—Changes to the Disclosure Requirements for Defined Benefit Plans. The amendments in this update change the disclosure requirements for employers that sponsor defined benefit pension and/or other postretirement benefit plans. It eliminates requirements for certain disclosures that are no longer considered cost beneficial and requires new disclosures that the FASB considers pertinent. The guidance is effective for fiscal years ending after December 15, 2020. Early adoption is permitted. The Company does not anticipate the adoption will have a material impact on the consolidated condensed financial statements and related disclosures.

- removed (2020-08-06):
[0001564590-20-022818:note_history:7]
On January 19, 2020, the Company entered into a definitive equity interests purchase agreement with AKMMeadville Electronics (Xiamen) Co., Ltd (the Purchaser) for the sale of the Company’s following subsidiaries, which was completed on April 17, 2020: Shanghai Kaiser Electronics Co., Ltd. (SKE), Shanghai Meadville Electronics Co., Ltd. (SME), Shanghai Meadville Science & Technology Co., Ltd. (SP) and Guangzhou Meadville Electronics Co., Ltd. (GME) (collectively, the Mobility business unit). For all periods presented in the consolidated condensed balance sheet, all assets and liabilities attributable to the Mobility business unit have been aggregated under the captions “Current assets held for sale”, “Non-current assets held for sale”, “Current liabilities held for sale” and “Non-current liabilities held for sale”. For all periods presented in the consolidated condensed statements of operations, all sales, costs, expenses and income taxes attributable to the Mobility business unit have been aggregated under the caption “Income from discontinued operations, net of income taxes”. Prior year results have been recast to conform with the current presentation. Refer to Note 2, Discontinued Operations, for additional information.


## ttmi:ScheduleOfUnamortizedDiscountAndDebtIssuanceCostsTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2020-08-06):
[0001564590-20-037715:note_history:8]
As of June 29, 2020 and December 30, 2019, remaining unamortized debt discount and debt issuance costs for the Term Loan Facility, Senior Notes and Convertible Senior Notes are as follows:
  (was, 2020-05-07, similarity 0.9746):
[0001564590-20-022818:note_history:8]
As of March 30, 2020 and December 30, 2019, remaining unamortized debt discount and debt issuance costs for the Term Loan Facility, Senior Notes and Convertible Senior Notes are as follows:

- changed (2020-08-06):
[0001564590-20-037715:note_history:9]
|  |  | As of June 29, 2020 |  |  | As of December 30, 2019 |
|  |  | Debt Issuance Costs |  |  | Debt Discount |  |  | Effective Interest Rate |  |  | Debt Issuance Costs |  |  | Debt Discount |  |  | Effective Interest Rate |  |  |
|  |  | (In thousands, except interest rates) |
| Term Loan due September 2024 |  | $ | 6,013 |  |  | $ | 1,819 |  |  |  | 4.66 |  | % | $ | 6,663 |  |  | $ | 2,016 |  |  |  | 4.66 |  | % |
| Senior Notes due October 2025 |  |  | 4,923 |  |  | — |  |  |  | 5.92 |  |  |  | 5,316 |  |  | — |  |  |  | 5.92 |  |  |
| Convertible Senior Notes |  |  | 482 |  |  |  | 4,808 |  |  |  | 6.48 |  |  |  | 995 |  |  |  | 9,927 |  |  |  | 6.48 |  |  |
|  |  | $ | 11,418 |  |  | $ | 6,627 |  |  |  |  |  |  | $ | 12,974 |  |  | $ | 11,943 |  |  |  |  |  |  |
  (was, 2020-05-07, similarity 0.9926):
[0001564590-20-022818:note_history:9]
|  |  | As of March 30, 2020 |  |  | As of December 30, 2019 |
|  |  | Debt Issuance Costs |  |  | Debt Discount |  |  | Effective Interest Rate |  |  | Debt Issuance Costs |  |  | Debt Discount |  |  | Effective Interest Rate |  |  |
|  |  | (In thousands, except interest rates) |
| Term Loan due September 2024 |  | $ | 6,340 |  |  | $ | 1,918 |  |  |  | 4.66 |  | % | $ | 6,663 |  |  | $ | 2,016 |  |  |  | 4.66 |  | % |
| Senior Notes due October 2025 |  |  | 5,121 |  |  | — |  |  |  | 5.92 |  |  |  | 5,316 |  |  | — |  |  |  | 5.92 |  |  |
| Convertible Senior Notes |  |  | 741 |  |  |  | 7,387 |  |  |  | 6.48 |  |  |  | 995 |  |  |  | 9,927 |  |  |  | 6.48 |  |  |
|  |  | $ | 12,202 |  |  | $ | 9,305 |  |  |  |  |  |  | $ | 12,974 |  |  | $ | 11,943 |  |  |  |  |  |  |


## us-gaap:LongTermDebtTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2020-08-06):
[0001564590-20-037715:note_history:10]
The following table summarizes the long-term debt of the Company as of June 29, 2020 and December 30, 2019:
  (was, 2020-05-07, similarity 0.9538):
[0001564590-20-022818:note_history:10]
The following table summarizes the long-term debt of the Company as of March 30, 2020 and December 30, 2019:

- changed (2020-08-06):
[0001564590-20-037715:note_history:11]
|  |  | Interest Rate as of June 29, 2020 |  |  | Principal Outstanding as of June 29, 2020 |  |  | Interest Rate as of December 30, 2019 |  |  | Principal Outstanding as of December 30, 2019 |  |
|  |  | (In thousands) |  |
| Term Loan due September 2024 |  |  | 2.67 |  | % | $ | 805,879 |  |  |  | 4.28 |  | % | $ | 805,879 |  |
| Senior Notes due October 2025 |  |  | 5.63 |  |  |  | 375,000 |  |  |  | 5.63 |  |  |  | 375,000 |  |
| Convertible Senior Notes due December 2020 |  |  | 1.75 |  |  |  | 249,975 |  |  |  | 1.75 |  |  |  | 249,975 |  |
| U.S. ABL Revolving Loan due June 2024 |  |  | 1.42 |  |  |  | 40,000 |  |  |  | 3.03 |  |  |  | 40,000 |  |
| Asia ABL Revolving Loan due June 2024 |  |  | 1.57 |  |  |  | 30,000 |  |  |  | 3.18 |  |  |  | 30,000 |  |
|  |  |  |  |  |  |  | 1,500,854 |  |  |  |  |  |  |  | 1,500,854 |  |
| Less: Long-term debt unamortized discount |  |  |  |  |  |  | (6,627 | ) |  |  |  |  |  |  | (11,943 | ) |
| Long-term debt unamortized debt issuance costs |  |  |  |  |  |  | (11,418 | ) |  |  |  |  |  |  | (12,974 | ) |
|  |  |  |  |  |  |  | 1,482,809 |  |  |  |  |  |  |  | 1,475,937 |  |
| Less: current maturities |  |  |  |  |  |  | (649,975 | ) |  |  |  |  |  |  | (249,975 | ) |
| Long-term debt, less current maturities |  |  |  |  |  | $ | 832,834 |  |  |  |  |  |  | $ | 1,225,962 |  |
  (was, 2020-05-07, similarity 0.991):
[0001564590-20-022818:note_history:11]
|  |  | Interest Rate as of March 30, 2020 |  |  | Principal Outstanding as of March 30, 2020 |  |  | Interest Rate as of December 30, 2019 |  |  | Principal Outstanding as of December 30, 2019 |  |
|  |  | (In thousands) |  |
| Term Loan due September 2024 |  |  | 3.48 |  | % | $ | 805,879 |  |  |  | 4.28 |  | % | $ | 805,879 |  |
| Senior Notes due October 2025 |  |  | 5.63 |  |  |  | 375,000 |  |  |  | 5.63 |  |  |  | 375,000 |  |
| Convertible Senior Notes due December 2020 |  |  | 1.75 |  |  |  | 249,975 |  |  |  | 1.75 |  |  |  | 249,975 |  |
| U.S. ABL Revolving Loan due June 2024 |  |  | 2.23 |  |  |  | 40,000 |  |  |  | 3.03 |  |  |  | 40,000 |  |
| Asia ABL Revolving Loan due June 2024 |  |  | 2.38 |  |  |  | 30,000 |  |  |  | 3.18 |  |  |  | 30,000 |  |
|  |  |  |  |  |  |  | 1,500,854 |  |  |  |  |  |  |  | 1,500,854 |  |
| Less: Long-term debt unamortized discount |  |  |  |  |  |  | (9,305 | ) |  |  |  |  |  |  | (11,943 | ) |
| Long-term debt unamortized debt issuance costs |  |  |  |  |  |  | (12,202 | ) |  |  |  |  |  |  | (12,974 | ) |
|  |  |  |  |  |  |  | 1,479,347 |  |  |  |  |  |  |  | 1,475,937 |  |
| Less: current maturities |  |  |  |  |  |  | (249,975 | ) |  |  |  |  |  |  | (249,975 | ) |
| Long-term debt, less current maturities |  |  |  |  |  | $ | 1,229,372 |  |  |  |  |  |  | $ | 1,225,962 |  |

- added (2020-08-06):
[0001564590-20-037715:note_history:12]
The Company has twelve months to reinvest the cash proceeds received from the sale of the Mobility business unit. If the proceeds are not reinvested, the Company is required to use the proceeds to prepay the Term Loan. The Company plans to use the cash proceeds for debt repayment and reinvestment. As of June 29, 2020, the Term Loan had an outstanding balance of $805,879, of which $400,000 is included in short-term debt. Subsequent to June 29, 2020, the Company made a debt principal prepayment for the Term Loan of $400,000. Permitted investments, as defined in the Term Loan Credit Agreement, include extensions of trade credit in the ordinary course of business, investments in cash and cash equivalents, permitted acquisitions, investments in assets useful in the business of the Company and its restricted subsidiaries, investments in joint ventures and unrestricted subsidiaries among others.

- changed (2020-08-06):
[0001564590-20-037715:note_history:13]
As of June 29, 2020 and December 30, 2019, remaining unamortized debt discount and debt issuance costs for the Term Loan Facility, Senior Notes and Convertible Senior Notes are as follows:
  (was, 2020-05-07, similarity 0.9746):
[0001564590-20-022818:note_history:13]
As of March 30, 2020 and December 30, 2019, remaining unamortized debt discount and debt issuance costs for the Term Loan Facility, Senior Notes and Convertible Senior Notes are as follows:

- changed (2020-08-06):
[0001564590-20-037715:note_history:14]
|  |  | As of June 29, 2020 |  |  | As of December 30, 2019 |
|  |  | Debt Issuance Costs |  |  | Debt Discount |  |  | Effective Interest Rate |  |  | Debt Issuance Costs |  |  | Debt Discount |  |  | Effective Interest Rate |  |  |
|  |  | (In thousands, except interest rates) |
| Term Loan due September 2024 |  | $ | 6,013 |  |  | $ | 1,819 |  |  |  | 4.66 |  | % | $ | 6,663 |  |  | $ | 2,016 |  |  |  | 4.66 |  | % |
| Senior Notes due October 2025 |  |  | 4,923 |  |  | — |  |  |  | 5.92 |  |  |  | 5,316 |  |  | — |  |  |  | 5.92 |  |  |
| Convertible Senior Notes |  |  | 482 |  |  |  | 4,808 |  |  |  | 6.48 |  |  |  | 995 |  |  |  | 9,927 |  |  |  | 6.48 |  |  |
|  |  | $ | 11,418 |  |  | $ | 6,627 |  |  |  |  |  |  | $ | 12,974 |  |  | $ | 11,943 |  |  |  |  |  |  |
  (was, 2020-05-07, similarity 0.9926):
[0001564590-20-022818:note_history:14]
|  |  | As of March 30, 2020 |  |  | As of December 30, 2019 |
|  |  | Debt Issuance Costs |  |  | Debt Discount |  |  | Effective Interest Rate |  |  | Debt Issuance Costs |  |  | Debt Discount |  |  | Effective Interest Rate |  |  |
|  |  | (In thousands, except interest rates) |
| Term Loan due September 2024 |  | $ | 6,340 |  |  | $ | 1,918 |  |  |  | 4.66 |  | % | $ | 6,663 |  |  | $ | 2,016 |  |  |  | 4.66 |  | % |
| Senior Notes due October 2025 |  |  | 5,121 |  |  | — |  |  |  | 5.92 |  |  |  | 5,316 |  |  | — |  |  |  | 5.92 |  |  |
| Convertible Senior Notes |  |  | 741 |  |  |  | 7,387 |  |  |  | 6.48 |  |  |  | 995 |  |  |  | 9,927 |  |  |  | 6.48 |  |  |
|  |  | $ | 12,202 |  |  | $ | 9,305 |  |  |  |  |  |  | $ | 12,974 |  |  | $ | 11,943 |  |  |  |  |  |  |

- changed (2020-08-06):
[0001564590-20-037715:note_history:15]
Remaining unamortized debt issuance costs for the ABL Revolving Loans of $2,226 and $2,511 as of June 29, 2020 and December 30, 2019, respectively, are included in other non-current assets and are amortized to interest expense over the duration of the ABL Revolving Loans using the straight-line method of amortization.
  (was, 2020-05-07, similarity 0.985):
[0001564590-20-022818:note_history:15]
Remaining unamortized debt issuance costs for the ABL Revolving Loans of $2,369 and $2,511 as of March 30, 2020 and December 30, 2019, respectively, are included in other non-current assets and are amortized to interest expense over the duration of the ABL Revolving Loans using the straight-line method of amortization.

- changed (2020-08-06):
[0001564590-20-037715:note_history:16]
As of June 29, 2020, the remaining weighted average amortization period for all unamortized debt discount and debt issuance costs was 3.5 years.
  (was, 2020-05-07, similarity 0.967):
[0001564590-20-022818:note_history:16]
As of March 30, 2020, the remaining weighted average amortization period for all unamortized debt discount and debt issuance costs was 3.4 years.

- removed (2020-08-06):
[0001564590-20-022818:note_history:17]
The Company has twelve months to reinvest the cash proceeds received from the sale of the Mobility business unit. If the proceeds are not reinvested, the Company is required to use the proceeds to prepay the Term Loan. The Company plans to use the cash proceeds for debt repayment and reinvestment. Permitted investments, as defined in the Term Loan Credit Agreement, include extensions of trade credit in the ordinary course of business, investments in cash and cash equivalents, permitted acquisitions, investments in assets useful in the business of the Company and its restricted subsidiaries, investments in joint ventures and unrestricted subsidiaries among others.


## us-gaap:ScheduleOfDebtInstrumentsTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2020-08-06):
[0001564590-20-037715:note_history:18]
The following table summarizes the long-term debt of the Company as of June 29, 2020 and December 30, 2019:
  (was, 2020-05-07, similarity 0.9538):
[0001564590-20-022818:note_history:18]
The following table summarizes the long-term debt of the Company as of March 30, 2020 and December 30, 2019:

- changed (2020-08-06):
[0001564590-20-037715:note_history:19]
|  |  | Interest Rate as of June 29, 2020 |  |  | Principal Outstanding as of June 29, 2020 |  |  | Interest Rate as of December 30, 2019 |  |  | Principal Outstanding as of December 30, 2019 |  |
|  |  | (In thousands) |  |
| Term Loan due September 2024 |  |  | 2.67 |  | % | $ | 805,879 |  |  |  | 4.28 |  | % | $ | 805,879 |  |
| Senior Notes due October 2025 |  |  | 5.63 |  |  |  | 375,000 |  |  |  | 5.63 |  |  |  | 375,000 |  |
| Convertible Senior Notes due December 2020 |  |  | 1.75 |  |  |  | 249,975 |  |  |  | 1.75 |  |  |  | 249,975 |  |
| U.S. ABL Revolving Loan due June 2024 |  |  | 1.42 |  |  |  | 40,000 |  |  |  | 3.03 |  |  |  | 40,000 |  |
| Asia ABL Revolving Loan due June 2024 |  |  | 1.57 |  |  |  | 30,000 |  |  |  | 3.18 |  |  |  | 30,000 |  |
|  |  |  |  |  |  |  | 1,500,854 |  |  |  |  |  |  |  | 1,500,854 |  |
| Less: Long-term debt unamortized discount |  |  |  |  |  |  | (6,627 | ) |  |  |  |  |  |  | (11,943 | ) |
| Long-term debt unamortized debt issuance costs |  |  |  |  |  |  | (11,418 | ) |  |  |  |  |  |  | (12,974 | ) |
|  |  |  |  |  |  |  | 1,482,809 |  |  |  |  |  |  |  | 1,475,937 |  |
| Less: current maturities |  |  |  |  |  |  | (649,975 | ) |  |  |  |  |  |  | (249,975 | ) |
| Long-term debt, less current maturities |  |  |  |  |  | $ | 832,834 |  |  |  |  |  |  | $ | 1,225,962 |  |
  (was, 2020-05-07, similarity 0.991):
[0001564590-20-022818:note_history:19]
|  |  | Interest Rate as of March 30, 2020 |  |  | Principal Outstanding as of March 30, 2020 |  |  | Interest Rate as of December 30, 2019 |  |  | Principal Outstanding as of December 30, 2019 |  |
|  |  | (In thousands) |  |
| Term Loan due September 2024 |  |  | 3.48 |  | % | $ | 805,879 |  |  |  | 4.28 |  | % | $ | 805,879 |  |
| Senior Notes due October 2025 |  |  | 5.63 |  |  |  | 375,000 |  |  |  | 5.63 |  |  |  | 375,000 |  |
| Convertible Senior Notes due December 2020 |  |  | 1.75 |  |  |  | 249,975 |  |  |  | 1.75 |  |  |  | 249,975 |  |
| U.S. ABL Revolving Loan due June 2024 |  |  | 2.23 |  |  |  | 40,000 |  |  |  | 3.03 |  |  |  | 40,000 |  |
| Asia ABL Revolving Loan due June 2024 |  |  | 2.38 |  |  |  | 30,000 |  |  |  | 3.18 |  |  |  | 30,000 |  |
|  |  |  |  |  |  |  | 1,500,854 |  |  |  |  |  |  |  | 1,500,854 |  |
| Less: Long-term debt unamortized discount |  |  |  |  |  |  | (9,305 | ) |  |  |  |  |  |  | (11,943 | ) |
| Long-term debt unamortized debt issuance costs |  |  |  |  |  |  | (12,202 | ) |  |  |  |  |  |  | (12,974 | ) |
|  |  |  |  |  |  |  | 1,479,347 |  |  |  |  |  |  |  | 1,475,937 |  |
| Less: current maturities |  |  |  |  |  |  | (249,975 | ) |  |  |  |  |  |  | (249,975 | ) |
| Long-term debt, less current maturities |  |  |  |  |  | $ | 1,229,372 |  |  |  |  |  |  | $ | 1,225,962 |  |


## us-gaap:RelatedPartyTransactionsDisclosureTextBlock (related_parties) — matched_by: tag_name, score: 1.0

- changed (2020-08-06):
[0001564590-20-037715:note_history:20]
In the normal course of business, the Company’s foreign subsidiaries purchase laminate and prepreg from related parties in which a former member of the Board of Directors of the Company holds an equity interest. The Company’s foreign subsidiaries purchased laminate and prepreg from these related parties in the amount of $5,986 and $8,193 for the quarters ended June 29, 2020 and July 1, 2019, respectively, and $11,767 and $15,696 for the two quarters ended June 29, 2020 and July 1, 2019, respectively.
  (was, 2020-05-07, similarity 0.8592):
[0001564590-20-022818:note_history:20]
In the normal course of business, the Company’s foreign subsidiaries purchase laminate and prepreg from related parties in which a member of the Board of Directors of the Company holds an equity interest. The Company’s foreign subsidiaries purchased laminate and prepreg from these related parties in the amount of $6,272 and $8,312 for the quarters ended March 30, 2020 and April 1, 2019, respectively.

- changed (2020-08-06):
[0001564590-20-037715:note_history:21]
As of June 29, 2020 and December 30, 2019, the Company’s consolidated condensed balance sheets included $7,601 and $9,220, respectively, in accounts payable due to related parties for purchases of laminate and prepreg and such balances are included as a component of accounts payable on the consolidated condensed balance sheets.
  (was, 2020-05-07, similarity 0.9855):
[0001564590-20-022818:note_history:21]
As of March 30, 2020 and December 30, 2019, the Company’s consolidated condensed balance sheets included $6,895 and $9,220, respectively, in accounts payable due to related parties for purchases of laminate and prepreg and such balances are included as a component of accounts payable on the consolidated condensed balance sheets.


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2020-08-06):
[0001564590-20-037715:note_history:22]
|  |  | Quarter Ended June 29, 2020 |  |  | Quarter Ended July 1, 2019 |  |  |
|  |  | PCB |  |  | E-M Solutions |  |  | Total |  |  | PCB |  |  | E-M Solutions |  |  | Total |  |  |
| End Markets |  | (In thousands) |  |  |
| Aerospace and Defense |  | $ | 188,620 |  |  | $ | 20 |  |  | $ | 188,640 |  |  | $ | 174,810 |  |  | $ | 362 |  |  | $ | 175,172 |  |  |
| Automotive |  |  | 58,100 |  |  |  | 11,462 |  |  |  | 69,562 |  |  |  | 73,049 |  |  |  | 23,993 |  |  |  | 97,042 |  |  |
| Cellular Phone |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |
| Computing/Storage/Peripherals |  |  | 71,864 |  |  |  | 36 |  |  |  | 71,900 |  |  |  | 56,482 |  |  |  | — |  |  |  | 56,482 |  |  |
| Medical/Industrial/Instrumentation |  |  | 114,105 |  |  |  | 3,187 |  |  |  | 117,292 |  |  |  | 82,453 |  |  |  | 9,641 |  |  |  | 92,094 |  |  |
| Networking/Communications |  |  | 73,595 |  |  |  | 36,267 |  |  |  | 109,862 |  |  |  | 74,485 |  |  |  | 25,926 |  |  |  | 100,411 |  |  |
| Other |  |  | 13,783 |  |  |  | (741 | ) |  |  | 13,042 |  |  |  | 5,681 |  |  |  | (5 | ) |  |  | 5,676 |  |  |
| Total |  | $ | 520,067 |  |  | $ | 50,231 |  |  | $ | 570,298 |  |  | $ | 466,960 |  |  | $ | 59,917 |  |  | $ | 526,877 |  |  |
  (was, 2020-05-07, similarity 0.7583):
[0001564590-20-022818:note_history:22]
|  |  | Quarter Ended April 1, 2019 |  |  |
|  |  | PCB |  |  | E-M Solutions |  |  | Total |  |  |
| End Markets |  | (In thousands) |  |  |
| Aerospace and Defense |  | $ | 164,797 |  |  | $ | 4 |  |  | $ | 164,801 |  |  |
| Automotive |  |  | 81,593 |  |  |  | 19,765 |  |  |  | 101,358 |  |  |
| Cellular Phone |  |  | 1,904 |  |  |  | — |  |  |  | 1,904 |  |  |
| Computing/Storage/Peripherals |  |  | 57,846 |  |  |  | 189 |  |  |  | 58,035 |  |  |
| Medical/Industrial/Instrumentation |  |  | 82,182 |  |  |  | 8,167 |  |  |  | 90,349 |  |  |
| Networking/Communications |  |  | 84,023 |  |  |  | 23,339 |  |  |  | 107,362 |  |  |
| Other |  |  | 12,722 |  |  |  | (86 | ) |  |  | 12,636 |  |  |
| Total |  | $ | 485,067 |  |  | $ | 51,378 |  |  | $ | 536,445 |  |  |

- changed (2020-08-06):
[0001564590-20-037715:note_history:23]
|  |  | Two Quarters Ended June 29, 2020 |  |  | Two Quarters Ended July 1, 2019 |  |  |
|  |  | PCB |  |  | E-M Solutions |  |  | Total |  |  | PCB |  |  | E-M Solutions |  |  | Total |  |  |
| End Markets |  | (In thousands) |  |  |
| Aerospace and Defense |  | $ | 373,071 |  |  | $ | 20 |  |  | $ | 373,091 |  |  | $ | 339,607 |  |  | $ | 366 |  |  | $ | 339,973 |  |  |
| Automotive |  |  | 119,521 |  |  |  | 18,925 |  |  |  | 138,446 |  |  |  | 154,642 |  |  |  | 43,758 |  |  |  | 198,400 |  |  |
| Cellular Phone |  |  | 1,164 |  |  |  | — |  |  |  | 1,164 |  |  |  | — |  |  |  | — |  |  |  | — |  |  |
| Computing/Storage/Peripherals |  |  | 130,146 |  |  |  | 140 |  |  |  | 130,286 |  |  |  | 114,328 |  |  |  | 189 |  |  |  | 114,517 |  |  |
| Medical/Industrial/Instrumentation |  |  | 202,329 |  |  |  | 6,945 |  |  |  | 209,274 |  |  |  | 164,635 |  |  |  | 17,808 |  |  |  | 182,443 |  |  |
| Networking/Communications |  |  | 134,493 |  |  |  | 55,244 |  |  |  | 189,737 |  |  |  | 158,508 |  |  |  | 49,265 |  |  |  | 207,773 |  |  |
| Other |  |  | 26,773 |  |  |  | (827 | ) |  |  | 25,946 |  |  |  | 20,307 |  |  |  | (91 | ) |  |  | 20,216 |  |  |
| Total |  | $ | 987,497 |  |  | $ | 80,447 |  |  | $ | 1,067,944 |  |  | $ | 952,027 |  |  | $ | 111,295 |  |  | $ | 1,063,322 |  |  |
  (was, 2020-05-07, similarity 0.6954):
[0001564590-20-022818:note_history:23]
|  |  | Quarter Ended March 30, 2020 |  |  |
|  |  | PCB |  |  | E-M Solutions |  |  | Total |  |  |
| End Markets |  | (In thousands) |  |  |
| Aerospace and Defense |  | $ | 184,451 |  |  | $ | — |  |  | $ | 184,451 |  |  |
| Automotive |  |  | 61,421 |  |  |  | 7,463 |  |  |  | 68,884 |  |  |
| Cellular Phone |  |  | 2,788 |  |  |  | — |  |  |  | 2,788 |  |  |
| Computing/Storage/Peripherals |  |  | 58,282 |  |  |  | 104 |  |  |  | 58,386 |  |  |
| Medical/Industrial/Instrumentation |  |  | 88,224 |  |  |  | 3,758 |  |  |  | 91,982 |  |  |
| Networking/Communications |  |  | 60,898 |  |  |  | 18,977 |  |  |  | 79,875 |  |  |
| Other |  |  | 11,366 |  |  |  | (86 | ) |  |  | 11,280 |  |  |
| Total |  | $ | 467,430 |  |  | $ | 30,216 |  |  | $ | 497,646 |  |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2020-08-06):
[0001564590-20-037715:note_history:24]
As of June 29, 2020, the aggregate amount of the transaction price allocated to remaining performance obligations for long-term contracts was $19,172. The Company expects to recognize revenue on approximately 83% of the remaining performance obligations for the Company’s long-term contracts over the next twelve months with the remaining amount recognized thereafter. The remaining performance obligations for the Company’s short-term contracts are expected to be recognized within one year.
  (was, 2020-05-07, similarity 0.9906):
[0001564590-20-022818:note_history:24]
As of March 30, 2020, the aggregate amount of the transaction price allocated to remaining performance obligations for long-term contracts was $23,014. The Company expects to recognize revenue on approximately 44% of the remaining performance obligations for the Company’s long-term contracts over the next twelve months with the remaining amount recognized thereafter. The remaining performance obligations for the Company’s short-term contracts are expected to be recognized within one year.

- added (2020-08-06):
[0001564590-20-037715:note_history:25]
Revenue from products and services transferred to customers over time and at a point in time accounted for 98% and 2%, respectively, of the Company’s revenue for the quarter and two quarters ended June 29, 2020. Revenue from products and services transferred to customers over time and at a point in time accounted for 97% and 3%, respectively, of the Company’s revenue for the quarter ended July 1, 2019, and 96% and 4%, respectively, of the Company’s revenue for the two quarters ended July 1, 2019.

- changed (2020-08-06):
[0001564590-20-037715:note_history:26]
|  |  | Quarter Ended June 29, 2020 |  |  | Quarter Ended July 1, 2019 |  |  |
|  |  | PCB |  |  | E-M Solutions |  |  | Total |  |  | PCB |  |  | E-M Solutions |  |  | Total |  |  |
| End Markets |  | (In thousands) |  |  |
| Aerospace and Defense |  | $ | 188,620 |  |  | $ | 20 |  |  | $ | 188,640 |  |  | $ | 174,810 |  |  | $ | 362 |  |  | $ | 175,172 |  |  |
| Automotive |  |  | 58,100 |  |  |  | 11,462 |  |  |  | 69,562 |  |  |  | 73,049 |  |  |  | 23,993 |  |  |  | 97,042 |  |  |
| Cellular Phone |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |
| Computing/Storage/Peripherals |  |  | 71,864 |  |  |  | 36 |  |  |  | 71,900 |  |  |  | 56,482 |  |  |  | — |  |  |  | 56,482 |  |  |
| Medical/Industrial/Instrumentation |  |  | 114,105 |  |  |  | 3,187 |  |  |  | 117,292 |  |  |  | 82,453 |  |  |  | 9,641 |  |  |  | 92,094 |  |  |
| Networking/Communications |  |  | 73,595 |  |  |  | 36,267 |  |  |  | 109,862 |  |  |  | 74,485 |  |  |  | 25,926 |  |  |  | 100,411 |  |  |
| Other |  |  | 13,783 |  |  |  | (741 | ) |  |  | 13,042 |  |  |  | 5,681 |  |  |  | (5 | ) |  |  | 5,676 |  |  |
| Total |  | $ | 520,067 |  |  | $ | 50,231 |  |  | $ | 570,298 |  |  | $ | 466,960 |  |  | $ | 59,917 |  |  | $ | 526,877 |  |  |
  (was, 2020-05-07, similarity 0.7583):
[0001564590-20-022818:note_history:26]
|  |  | Quarter Ended April 1, 2019 |  |  |
|  |  | PCB |  |  | E-M Solutions |  |  | Total |  |  |
| End Markets |  | (In thousands) |  |  |
| Aerospace and Defense |  | $ | 164,797 |  |  | $ | 4 |  |  | $ | 164,801 |  |  |
| Automotive |  |  | 81,593 |  |  |  | 19,765 |  |  |  | 101,358 |  |  |
| Cellular Phone |  |  | 1,904 |  |  |  | — |  |  |  | 1,904 |  |  |
| Computing/Storage/Peripherals |  |  | 57,846 |  |  |  | 189 |  |  |  | 58,035 |  |  |
| Medical/Industrial/Instrumentation |  |  | 82,182 |  |  |  | 8,167 |  |  |  | 90,349 |  |  |
| Networking/Communications |  |  | 84,023 |  |  |  | 23,339 |  |  |  | 107,362 |  |  |
| Other |  |  | 12,722 |  |  |  | (86 | ) |  |  | 12,636 |  |  |
| Total |  | $ | 485,067 |  |  | $ | 51,378 |  |  | $ | 536,445 |  |  |

- changed (2020-08-06):
[0001564590-20-037715:note_history:27]
|  |  | Two Quarters Ended June 29, 2020 |  |  | Two Quarters Ended July 1, 2019 |  |  |
|  |  | PCB |  |  | E-M Solutions |  |  | Total |  |  | PCB |  |  | E-M Solutions |  |  | Total |  |  |
| End Markets |  | (In thousands) |  |  |
| Aerospace and Defense |  | $ | 373,071 |  |  | $ | 20 |  |  | $ | 373,091 |  |  | $ | 339,607 |  |  | $ | 366 |  |  | $ | 339,973 |  |  |
| Automotive |  |  | 119,521 |  |  |  | 18,925 |  |  |  | 138,446 |  |  |  | 154,642 |  |  |  | 43,758 |  |  |  | 198,400 |  |  |
| Cellular Phone |  |  | 1,164 |  |  |  | — |  |  |  | 1,164 |  |  |  | — |  |  |  | — |  |  |  | — |  |  |
| Computing/Storage/Peripherals |  |  | 130,146 |  |  |  | 140 |  |  |  | 130,286 |  |  |  | 114,328 |  |  |  | 189 |  |  |  | 114,517 |  |  |
| Medical/Industrial/Instrumentation |  |  | 202,329 |  |  |  | 6,945 |  |  |  | 209,274 |  |  |  | 164,635 |  |  |  | 17,808 |  |  |  | 182,443 |  |  |
| Networking/Communications |  |  | 134,493 |  |  |  | 55,244 |  |  |  | 189,737 |  |  |  | 158,508 |  |  |  | 49,265 |  |  |  | 207,773 |  |  |
| Other |  |  | 26,773 |  |  |  | (827 | ) |  |  | 25,946 |  |  |  | 20,307 |  |  |  | (91 | ) |  |  | 20,216 |  |  |
| Total |  | $ | 987,497 |  |  | $ | 80,447 |  |  | $ | 1,067,944 |  |  | $ | 952,027 |  |  | $ | 111,295 |  |  | $ | 1,063,322 |  |  |
  (was, 2020-05-07, similarity 0.6954):
[0001564590-20-022818:note_history:27]
|  |  | Quarter Ended March 30, 2020 |  |  |
|  |  | PCB |  |  | E-M Solutions |  |  | Total |  |  |
| End Markets |  | (In thousands) |  |  |
| Aerospace and Defense |  | $ | 184,451 |  |  | $ | — |  |  | $ | 184,451 |  |  |
| Automotive |  |  | 61,421 |  |  |  | 7,463 |  |  |  | 68,884 |  |  |
| Cellular Phone |  |  | 2,788 |  |  |  | — |  |  |  | 2,788 |  |  |
| Computing/Storage/Peripherals |  |  | 58,282 |  |  |  | 104 |  |  |  | 58,386 |  |  |
| Medical/Industrial/Instrumentation |  |  | 88,224 |  |  |  | 3,758 |  |  |  | 91,982 |  |  |
| Networking/Communications |  |  | 60,898 |  |  |  | 18,977 |  |  |  | 79,875 |  |  |
| Other |  |  | 11,366 |  |  |  | (86 | ) |  |  | 11,280 |  |  |
| Total |  | $ | 467,430 |  |  | $ | 30,216 |  |  | $ | 497,646 |  |  |

- removed (2020-08-06):
[0001564590-20-022818:note_history:28]
Revenue from products and services transferred to customers over time and at a point in time accounted for 98% and 2%, respectively, of the Company’s revenue for the quarter ended March 30, 2020, and 97% and 3%, respectively, of the Company’s revenue for the quarter ended April 1, 2019.


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: tag_name, score: 1.0

- changed (2020-08-06):
[0001564590-20-037715:note_history:29]
(20) Subsequent Event
  (was, 2020-05-07, similarity 0.9756):
[0001564590-20-022818:note_history:29]
(19) Subsequent Events

- added (2020-08-06):
[0001564590-20-037715:note_history:30]
Subsequent to June 29, 2020, the Company made a $400,000 debt principal prepayment for its Term Loan.

- removed (2020-08-06):
[0001564590-20-022818:note_history:31]
On April 17, 2020, the Company completed the sale of its Mobility business unit for a base purchase price of $550,000 in cash, subject to customary purchase price adjustments. The base purchase price does not include certain accounts receivable of the divested business, which is estimated to total approximately $95,000.

- removed (2020-08-06):
[0001564590-20-022818:note_history:32]
On April 29, 2020, the Company announced the restructuring of its E-M Solutions business unit, which consists of three Chinese manufacturing facilities with two being in Shanghai (SH BPA and SH E-MS) and one in Shenzhen (SZ). The Company will discontinue operations at the SH E-MS and SZ facilities while integrating the SH BPA facility into its PCB operations. No goodwill is allocated to the E-M Solutions reportable segment. The cash outlay for severance and other shutdown costs is estimated to be approximately $17,000 and is expected to be incurred over the next 12 to 15 months. The Company also expects to incur approximately $8,000 related to non-cash asset impairments. At this time, these amounts are estimates and subject to change as the Company carries out the restructuring. This subsequent event has not been recognized in these consolidated condensed financial statements and will be recognized in the Company’s consolidated financial statements in the upcoming quarters.
