# TTMI notes — 0001564590-20-037715


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureAndSignificantAccountingPoliciesTextBlock

[0001564590-20-037715:notes:1]
[same as prior period, unchanged from 0001564590-20-022818:notes:1]

[0001564590-20-037715:notes:2]
TTM Technologies, Inc. (the Company or TTM) is a leading global printed circuit board (PCB) manufacturer, focusing on quick-turn and volume production of technologically advanced PCBs and backplane assemblies as well as a global designer and manufacturer of high-frequency radio frequency (RF) and microwave components and assemblies. The Company provides time-to-market and volume production of advanced technology products and offers a one-stop design, engineering and manufacturing solution to customers. This one-stop design and manufacturing solution enables the Company to align technology developments with the diverse needs of the Company’s customers and to enable them to reduce the time required to develop new products and bring them to market.

[0001564590-20-037715:notes:3]
The Company serves a diversified customer base in various markets throughout the world, including aerospace and defense, computing, automotive components, medical, industrial and instrumentation related products, as well as networking/communications infrastructure products. The Company’s customers include both original equipment manufacturers (OEMs) and electronic manufacturing services (EMS) providers.

[0001564590-20-037715:notes:4]
[same as prior period, unchanged from 0001564590-20-022818:notes:4]

[0001564590-20-037715:notes:5]
On January 19, 2020, the Company entered into a definitive equity interests purchase agreement with AKMMeadville Electronics (Xiamen) Co., Ltd (the Purchaser) for the sale of the Company’s following subsidiaries, which was completed on April 17, 2020: Shanghai Kaiser Electronics Co., Ltd. (SKE), Shanghai Meadville Electronics Co., Ltd. (SME), Shanghai Meadville Science & Technology Co., Ltd. (SP) and Guangzhou Meadville Electronics Co., Ltd. (GME) (collectively, the Mobility business unit). Prior to the closing of the sale of the Company’s Mobility business unit, all assets and liabilities attributable to the Mobility business unit have been aggregated under the captions “Current assets held for sale”, “Non-current assets held for sale”, “Current liabilities held for sale” and “Non-current liabilities held for sale”. For all periods presented in the consolidated condensed statements of operations, all sales, costs, expenses, income taxes and gain on sale attributable to the Mobility business unit have been aggregated under the caption “Income from discontinued operations, net of income taxes”. Prior year results have been recast to conform with the current presentation. Refer to Note 2, Discontinued Operations, for additional information.

[0001564590-20-037715:notes:6]
[same as prior period, unchanged from 0001564590-20-022818:notes:6]

[0001564590-20-037715:notes:7]
[same as prior period, unchanged from 0001564590-20-022818:notes:7]

[0001564590-20-037715:notes:8]
Certain prior year amounts in the consolidated condensed financial statements have been reclassified due to the sale of the Company’s Mobility business unit. Refer to Note 2, Discontinued Operations, for further information regarding this sale and the resulting prior year reclassifications. Further, in 2020, the Company began presenting research and development expenses as a separate line item on the consolidated condensed statements of operations to better align with similar presentation made by peers and to provide additional disclosure that is meaningful for investors. The prior year consolidated condensed statements of operations were adjusted to conform with this new presentation. Research and development expense were previously presented within general and administrative expense on the consolidated condensed statements of operations.

[0001564590-20-037715:notes:9]
[same as prior period, unchanged from 0001564590-20-022818:notes:9]

[0001564590-20-037715:notes:10]
Recently Adopted Accounting Standards

[0001564590-20-037715:notes:11]
In June 2016, the FASB issued ASU 2016-13, Financial Instruments - Credit Losses (Topic 326): Measurement of Credit Losses on Financial Instruments, which amends the current accounting guidance and requires the measurement of all expected losses based on historical experience, current conditions and reasonable and supportable forecasts. For trade receivables, loans, and other financial instruments, the Company will be required to use a forward-looking expected loss model that reflects losses that are probable rather than the incurred loss model for recognizing credit losses. The standard became effective for interim and annual periods beginning after December 15, 2019. Application of the amendments is through a cumulative-effect adjustment to retained earnings as of the effective date. The Company adopted this ASU as of December 31, 2019 and it did not have a material impact on its financial statements.

[0001564590-20-037715:notes:12]
Recently Issued Accounting Standards Not Yet Adopted

[0001564590-20-037715:notes:13]
In March 2020, the FASB issued ASU 2020-04, Reference Rate Reform (Topic 848): Facilitation of the Effects of Reference Rate Reform on Financial Reporting, which provides temporary relief to the GAAP guidance on contract modifications and hedge accounting to ease the financial reporting burdens of the expected market transition from LIBOR and other interbank offered rates to alternative rates. This guidance is effective beginning on March 12, 2020 through December 31, 2022. The guidance on contract modifications can be applied prospectively from any date beginning March 12, 2020 and may also be applied to modifications of existing contracts made earlier in the interim period that includes March 12, 2020. The guidance on hedging can be applied to eligible hedging relationships existing at the beginning of the interim period that includes March 12, 2020 and to new eligible hedging relationships entered into after the beginning of that interim period. The Company is currently evaluating the new guidance to determine the impact it may have on its consolidated condensed financial statements and related disclosures.

[0001564590-20-037715:notes:14]
In December 2019, the FASB issued ASU 2019-12, Income Taxes (Topic 740): Simplifying the Accounting for Income Taxes, which is intended to simplify various aspects related to accounting for income taxes. ASU 2019-12 removes certain exceptions to the general principles in Topic 740 and also clarifies and amends existing guidance to improve consistent application. The guidance is effective for fiscal years beginning after December 15, 2020, including interim periods within those fiscal years. Early adoption is permitted. The Company has evaluated the new guidance to determine the impact it may have on its consolidated condensed financial statements and related disclosures and the impact is not expected to be material.

[0001564590-20-037715:notes:15]
In August 2018, the FASB issued ASU 2018-14, Compensation—Retirement Benefits—Defined Benefit Plans—General (Subtopic 715-20)—Disclosure Framework—Changes to the Disclosure Requirements for Defined Benefit Plans. The amendments in this update change the disclosure requirements for employers that sponsor defined benefit pension and/or other postretirement benefit plans. It eliminates requirements for certain disclosures that are no longer considered cost beneficial and requires new disclosures that the FASB considers pertinent. The guidance is effective for fiscal years ending after December 15, 2020. Early adoption is permitted. The Company does not anticipate the adoption will have a material impact on its consolidated condensed financial statements and related disclosures.


## us-gaap:DisposalGroupsIncludingDiscontinuedOperationsDisclosureTextBlock

[0001564590-20-037715:notes:16]
[same as prior period, unchanged from 0001564590-20-022818:notes:16]

[0001564590-20-037715:notes:17]
On January 19, 2020, the Company entered into a definitive equity interests purchase agreement for the sale of the Company’s Mobility business unit. The sale was completed on April 17, 2020 for a base purchase price of $550,000, subject to customary purchase price adjustments. The base purchase price does not include certain accounts receivable of the divested business, which are estimated to total approximately $95,000.

[0001564590-20-037715:notes:18]
On April 18, 2020, the Company also entered into a Transition Services Agreement (TSA) with the Purchaser pursuant to which the Purchaser is receiving certain services (the Services) to enable it to operate the Mobility business unit after the closing of the sale of the Mobility business unit. The Services include finance and accounting, human resources, legal and compliance, sales, information technology, and other corporate support services. Under the TSA, the Services are being provided at cost for a period of up to 24 months. The Company does not anticipate this will have a material impact on its consolidated condensed financial statements.

[0001564590-20-037715:notes:19]
Further, on June 29, 2020, the Company entered into a Sales Force Agreement with the Purchaser pursuant to which the Company’s sales representatives will assist the Purchaser in selling PCBs manufactured by the Purchaser to certain customers for a commission for a period up to April 17, 2021. The Company does not anticipate this will have a material impact on its consolidated condensed financial statements.

[0001564590-20-037715:notes:20]
As the sale of the Company’s Mobility business unit represents a strategic shift that will have a major effect on the Company’s operations and financial results, in accordance with the provisions of FASB authoritative guidance on the presentation of financial statements, Mobility business unit results are classified as discontinued operations in the consolidated condensed statements of operations for all periods presented. Prior year results have been recast to conform with the current presentation.

[0001564590-20-037715:notes:21]
[same as prior period, unchanged from 0001564590-20-022818:notes:19]

[0001564590-20-037715:notes:22]
|  |  | Quarter Ended |  |  | Two Quarters Ended |  |
|  |  | June 29, |  |  | July 1, |  |  | June 29, |  |  | July 1, |  |
|  |  | 2020 |  |  | 2019 |  |  | 2020 |  |  | 2019 |  |
|  |  | (In thousands, except per share data) |  |
| Net sales |  | $ | 30,777 |  |  | $ | 106,161 |  |  | $ | 143,951 |  |  | $ | 189,916 |  |
| Cost of goods sold |  |  | 28,375 |  |  |  | 114,394 |  |  |  | 136,800 |  |  |  | 208,290 |  |
| Gross profit |  |  | 2,402 |  |  |  | (8,233 | ) |  |  | 7,151 |  |  |  | (18,374 | ) |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Selling and marketing |  |  | 285 |  |  |  | 969 |  |  |  | 1,461 |  |  |  | 2,310 |  |
| General and administrative |  |  | 1,007 |  |  |  | 2,272 |  |  |  | 2,317 |  |  |  | 2,742 |  |
| Research and development |  |  | — |  |  |  | — |  |  |  | 147 |  |  |  | — |  |
| Amortization of definite-lived intangibles |  |  | 134 |  |  |  | 674 |  |  |  | 809 |  |  |  | 1,348 |  |
| Total operating expenses |  |  | 1,426 |  |  |  | 3,915 |  |  |  | 4,734 |  |  |  | 6,400 |  |
| Operating income (loss) |  |  | 976 |  |  |  | (12,148 | ) |  |  | 2,417 |  |  |  | (24,774 | ) |
| Other (expense) income: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Interest expense |  |  | — |  |  |  | (318 | ) |  |  | (223 | ) |  |  | (871 | ) |
| Gain on sale of the Mobility business unit |  |  | 248,863 |  |  |  | — |  |  |  | 248,863 |  |  |  | — |  |
| Other, net |  |  | (411 | ) |  |  | 1,614 |  |  |  | 1,160 |  |  |  | 1,441 |  |
| Total other income, net |  |  | 248,452 |  |  |  | 1,296 |  |  |  | 249,800 |  |  |  | 570 |  |
| Income (loss) from discontinued operations before income taxes |  |  | 249,428 |  |  |  | (10,852 | ) |  |  | 252,217 |  |  |  | (24,204 | ) |
| Income tax (provision) benefit |  |  | (65,964 | ) |  |  | 1,783 |  |  |  | (66,707 | ) |  |  | 5,645 |  |
| Income (loss) from discontinued operations, net of income taxes |  | $ | 183,464 |  |  | $ | (9,069 | ) |  | $ | 185,510 |  |  | $ | (18,559 | ) |
| Earnings (loss) per share from discontinued operations: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic earnings (loss) per share |  | $ | 1.72 |  |  | $ | (0.09 | ) |  | $ | 1.75 |  |  | $ | (0.18 | ) |
| Diluted earnings (loss) per share |  | $ | 1.70 |  |  | $ | (0.09 | ) |  | $ | 1.72 |  |  | $ | (0.18 | ) |

[0001564590-20-037715:notes:23]
Depreciation expense related to the discontinued operations for the quarters ended June 29, 2020 and July 1, 2019 was $3,117 and $17,866, respectively, and $21,382 and $35,941 for the two quarters ended June 29, 2020 and July 1, 2019, respectively.

[0001564590-20-037715:notes:24]
During the quarter and two quarters ended June 29, 2020, the Company’s income tax expense related to the discontinued operations was impacted by a net discrete expense of $65,774. As a result of the sale of the Mobility business unit, the discrete income tax expense is related mainly to (i) China withholding tax related to gain on sale, (ii) U.S. income tax related to Global Intangible Low Taxed Income (GILTI) inclusion net of IRC Section 250 deduction and foreign tax credits, and offset by (iii) release of U.S. FIN 48 uncertain tax positions.

[0001564590-20-037715:notes:25]
Proceeds from the sale of the Company’s Mobility business unit have been presented in the consolidated condensed statements of cash flows within net cash provided by investing activities from discontinued operations. As of June 29, 2020, the Company’s consolidated condensed balance sheet included $314,585 of receivable from Purchaser of the Mobility business unit. Subsequent to June 29, 2020, the Company received the remaining portion of the proceeds. The following is a reconciliation of the gain recorded for the sale of the Company’s Mobility business unit (in thousands):

[0001564590-20-037715:notes:26]
| Net proceeds from the sale of the Mobility business unit (1) |  | $ | 567,585 |  |
| Mobility business unit assets: |  |  |  |  |
| Cash and cash equivalents |  |  | 12,513 |  |
| Restricted cash |  |  | 35,412 |  |
| Accounts receivable, net |  |  | 12 |  |
| Contract assets |  |  | 40,072 |  |
| Inventories |  |  | 5,642 |  |
| Prepaid expenses and other current assets |  |  | 4,593 |  |
| Property, plant and equipment, net |  |  | 328,648 |  |
| Goodwill |  |  | 68,267 |  |
| Definite-lived intangibles, net |  |  | 5,520 |  |
| Deposits and other non-current assets |  |  | 6,291 |  |
| Total Mobility business unit assets |  |  | 506,970 |  |
| Mobility business unit liabilities: |  |  |  |  |
| Accounts payable |  |  | 142,636 |  |
| Accrued salaries, wages and benefits |  |  | 9,392 |  |
| Other current liabilities |  |  | 11,283 |  |
| Other long-term liabilities |  |  | 303 |  |
| Total Mobility business unit liabilities |  |  | 163,614 |  |
| Derecognition of foreign currency translation adjustments and unrealized losses on cash flow hedges recorded in accumulated other comprehensive loss |  |  | 26,957 |  |
| Other transaction costs incurred as part of the sale of the Mobility business unit (2) |  |  | 2,323 |  |
| Gain on sale of the Mobility business unit before income taxes |  | $ | 248,863 |  |

[0001564590-20-037715:notes:27]
| (1) | Net proceeds from the sale of the Mobility business unit are net of customary purchase price adjustments. As of June 29, 2020, the Company received a portion of the proceeds amounting to $253,000. |

[0001564590-20-037715:notes:28]
| (2) | Costs directly incurred as a result of the sale of the Company’s Mobility business unit, including legal fees, professional fees, and other costs. |


## us-gaap:ScheduleOfDisposalGroupsIncludingDiscontinuedOperationsIncomeStatementBalanceSheetAndAdditionalDisclosuresTextBlock

[0001564590-20-037715:notes:29]
The following is a reconciliation of the gain recorded for the sale of the Company’s Mobility business unit (in thousands):


## us-gaap:LesseeOperatingLeasesTextBlock

[0001564590-20-037715:notes:30]
[same as prior period, unchanged from 0001564590-20-022818:notes:25]

[0001564590-20-037715:notes:31]
The Company leases some of its manufacturing and assembly plants, sales offices and equipment under non-cancellable operating leases that expire at various dates through 2049. The majority of the Company’s lease arrangements are comprised of fixed payments and certain leases consist of variable payments based on equipment usage. These variable payments are not included in the measurement of the right-of-use (ROU) asset or lease liability due to uncertainty of the payment amount and are recorded as lease expense in the period incurred. Certain leases contain renewal provisions at the Company’s option. Most of the leases require the Company to pay for certain other costs such as property taxes and maintenance. Certain leases also contain rent escalation clauses (step rents) that require additional rental amounts in the later years of the term. Rent expense for leases with step rents is recognized on a straight-line basis over the minimum lease term. The lease agreements do not contain any material residual value guarantees or material restrictive covenants.

[0001564590-20-037715:notes:32]
[same as prior period, unchanged from 0001564590-20-022818:notes:27]

[0001564590-20-037715:notes:33]
|  |  | Quarter Ended |  |  | Two Quarters Ended |  |
|  |  | June 29, 2020 |  |  | July 1, 2019 |  |  | June 29, 2020 |  |  | July 1, 2019 |  |
|  |  | (In thousands) |  |
| Operating lease cost |  | $ | 2,227 |  |  | $ | 2,132 |  |  | $ | 4,708 |  |  | $ | 4,164 |  |
| Variable lease cost |  |  | 137 |  |  |  | 102 |  |  |  | 243 |  |  |  | 261 |  |
| Short-term lease cost |  |  | 169 |  |  |  | 144 |  |  |  | 398 |  |  |  | 185 |  |

[0001564590-20-037715:notes:34]
[same as prior period, unchanged from 0001564590-20-022818:notes:29]

[0001564590-20-037715:notes:35]
|  |  | Two Quarters Ended |  |
|  |  | June 29, 2020 |  |  | July 1, 2019 |  |
|  |  | (In thousands) |  |
| Cash paid for amounts included in the measurement of lease liabilities: |  |  |  |  |  |  |  |  |
| Operating cash flows from operating leases |  | $ | 4,342 |  |  | $ | 4,164 |  |
| Right-of-use assets obtained in exchange for new lease obligations: |  |  |  |  |  |  |  |  |
| Operating leases |  |  | 3,205 |  |  |  | 12,896 |  |

[0001564590-20-037715:notes:36]
[same as prior period, unchanged from 0001564590-20-022818:notes:31]

[0001564590-20-037715:notes:37]
|  |  | As of |  |
|  |  | June 29, 2020 |  |  | December 30, 2019 |  |
|  |  | (In thousands) |  |
| Operating lease right-of-use assets |  | $ | 21,993 |  |  | $ | 22,173 |  |
| Other current liabilities |  |  | 7,641 |  |  |  | 7,111 |  |
| Operating lease liabilities |  |  | 15,015 |  |  |  | 15,413 |  |
| Total operating lease liabilities |  | $ | 22,656 |  |  | $ | 22,524 |  |

[0001564590-20-037715:notes:38]
|  |  | As of |  |
|  |  | June 29, 2020 |  |  | December 30, 2019 |  |
| Weighted average remaining lease term |  | 4.1 years |  |  | 4.4 years |  |
| Weighted average discount rate |  |  | 3.76 | % |  |  | 3.92 | % |

[0001564590-20-037715:notes:39]
[same as prior period, unchanged from 0001564590-20-022818:notes:34]

[0001564590-20-037715:notes:40]
|  |  | (In thousands) |  |
| Less than one year |  | $ | 8,339 |  |
| 1 - 2 years |  |  | 6,111 |  |
| 2 - 3 years |  |  | 3,413 |  |
| 3 - 4 years |  |  | 2,540 |  |
| 4 - 5 years |  |  | 1,725 |  |
| Thereafter |  |  | 2,415 |  |
| Total lease payments |  |  | 24,543 |  |
| Less imputed interest |  |  | (1,887 | ) |
| Total |  | $ | 22,656 |  |

[0001564590-20-037715:notes:41]
[same as prior period, unchanged from 0001564590-20-022818:notes:36]


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0001564590-20-037715:notes:42]
[same as prior period, unchanged from 0001564590-20-022818:notes:37]

[0001564590-20-037715:notes:43]
As of June 29, 2020, the aggregate amount of the transaction price allocated to remaining performance obligations for long-term contracts was $19,172. The Company expects to recognize revenue on approximately 83% of the remaining performance obligations for the Company’s long-term contracts over the next twelve months with the remaining amount recognized thereafter. The remaining performance obligations for the Company’s short-term contracts are expected to be recognized within one year.

[0001564590-20-037715:notes:44]
Revenue from products and services transferred to customers over time and at a point in time accounted for 98% and 2%, respectively, of the Company’s revenue for the quarter and two quarters ended June 29, 2020. Revenue from products and services transferred to customers over time and at a point in time accounted for 97% and 3%, respectively, of the Company’s revenue for the quarter ended July 1, 2019, and 96% and 4%, respectively, of the Company’s revenue for the two quarters ended July 1, 2019.

[0001564590-20-037715:notes:45]
[same as prior period, unchanged from 0001564590-20-022818:notes:40]

[0001564590-20-037715:notes:46]
|  |  | Quarter Ended June 29, 2020 |  |  | Quarter Ended July 1, 2019 |  |  |
|  |  | PCB |  |  | E-M Solutions |  |  | Total |  |  | PCB |  |  | E-M Solutions |  |  | Total |  |  |
| End Markets |  | (In thousands) |  |  |
| Aerospace and Defense |  | $ | 188,620 |  |  | $ | 20 |  |  | $ | 188,640 |  |  | $ | 174,810 |  |  | $ | 362 |  |  | $ | 175,172 |  |  |
| Automotive |  |  | 58,100 |  |  |  | 11,462 |  |  |  | 69,562 |  |  |  | 73,049 |  |  |  | 23,993 |  |  |  | 97,042 |  |  |
| Cellular Phone |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |
| Computing/Storage/Peripherals |  |  | 71,864 |  |  |  | 36 |  |  |  | 71,900 |  |  |  | 56,482 |  |  |  | — |  |  |  | 56,482 |  |  |
| Medical/Industrial/Instrumentation |  |  | 114,105 |  |  |  | 3,187 |  |  |  | 117,292 |  |  |  | 82,453 |  |  |  | 9,641 |  |  |  | 92,094 |  |  |
| Networking/Communications |  |  | 73,595 |  |  |  | 36,267 |  |  |  | 109,862 |  |  |  | 74,485 |  |  |  | 25,926 |  |  |  | 100,411 |  |  |
| Other |  |  | 13,783 |  |  |  | (741 | ) |  |  | 13,042 |  |  |  | 5,681 |  |  |  | (5 | ) |  |  | 5,676 |  |  |
| Total |  | $ | 520,067 |  |  | $ | 50,231 |  |  | $ | 570,298 |  |  | $ | 466,960 |  |  | $ | 59,917 |  |  | $ | 526,877 |  |  |

[0001564590-20-037715:notes:47]
|  |  | Two Quarters Ended June 29, 2020 |  |  | Two Quarters Ended July 1, 2019 |  |  |
|  |  | PCB |  |  | E-M Solutions |  |  | Total |  |  | PCB |  |  | E-M Solutions |  |  | Total |  |  |
| End Markets |  | (In thousands) |  |  |
| Aerospace and Defense |  | $ | 373,071 |  |  | $ | 20 |  |  | $ | 373,091 |  |  | $ | 339,607 |  |  | $ | 366 |  |  | $ | 339,973 |  |  |
| Automotive |  |  | 119,521 |  |  |  | 18,925 |  |  |  | 138,446 |  |  |  | 154,642 |  |  |  | 43,758 |  |  |  | 198,400 |  |  |
| Cellular Phone |  |  | 1,164 |  |  |  | — |  |  |  | 1,164 |  |  |  | — |  |  |  | — |  |  |  | — |  |  |
| Computing/Storage/Peripherals |  |  | 130,146 |  |  |  | 140 |  |  |  | 130,286 |  |  |  | 114,328 |  |  |  | 189 |  |  |  | 114,517 |  |  |
| Medical/Industrial/Instrumentation |  |  | 202,329 |  |  |  | 6,945 |  |  |  | 209,274 |  |  |  | 164,635 |  |  |  | 17,808 |  |  |  | 182,443 |  |  |
| Networking/Communications |  |  | 134,493 |  |  |  | 55,244 |  |  |  | 189,737 |  |  |  | 158,508 |  |  |  | 49,265 |  |  |  | 207,773 |  |  |
| Other |  |  | 26,773 |  |  |  | (827 | ) |  |  | 25,946 |  |  |  | 20,307 |  |  |  | (91 | ) |  |  | 20,216 |  |  |
| Total |  | $ | 987,497 |  |  | $ | 80,447 |  |  | $ | 1,067,944 |  |  | $ | 952,027 |  |  | $ | 111,295 |  |  | $ | 1,063,322 |  |  |


## us-gaap:AdditionalFinancialInformationDisclosureTextBlock

[0001564590-20-037715:notes:48]
[same as prior period, unchanged from 0001564590-20-022818:notes:43]

[0001564590-20-037715:notes:49]
|  |  | As of |  |
|  |  | June 29, 2020 |  |  | December 30, 2019 |  |
|  |  | (In thousands) |  |
| Inventories: |  |  |  |  |  |  |  |  |
| Raw materials |  | $ | 111,382 |  |  | $ | 97,660 |  |
| Work-in-process |  |  | 8,795 |  |  |  | 10,898 |  |
| Finished goods |  |  | 2,670 |  |  |  | 5,195 |  |
|  |  | $ | 122,847 |  |  | $ | 113,753 |  |
| Property, plant and equipment, net: |  |  |  |  |  |  |  |  |
| Land and land use rights |  | $ | 62,009 |  |  | $ | 62,009 |  |
| Buildings and improvements |  |  | 393,322 |  |  |  | 381,980 |  |
| Machinery and equipment |  |  | 820,570 |  |  |  | 777,916 |  |
| Furniture and fixtures and other |  |  | 10,625 |  |  |  | 10,329 |  |
| Construction-in-progress |  |  | 33,363 |  |  |  | 58,195 |  |
|  |  |  | 1,319,889 |  |  |  | 1,290,429 |  |
| Less: Accumulated depreciation |  |  | (659,023 | ) |  |  | (612,228 | ) |
|  |  | $ | 660,866 |  |  | $ | 678,201 |  |


## us-gaap:GoodwillDisclosureTextBlock

[0001564590-20-037715:notes:50]
[same as prior period, unchanged from 0001564590-20-022818:notes:45]

[0001564590-20-037715:notes:51]
As of June 29, 2020 and December 30, 2019, goodwill was as follows:

[0001564590-20-037715:notes:52]
|  |  | Total |  |
|  |  | (In thousands) |  |
| Balance as of December 30, 2019 and June 29, 2020 |  |  |  |  |
| Goodwill |  | $ | 946,191 |  |
| Accumulated impairment loss |  |  | (171,400 | ) |
| Goodwill related to the Mobility business unit |  |  | (68,267 | ) |
|  |  | $ | 706,524 |  |

[0001564590-20-037715:notes:53]
[same as prior period, unchanged from 0001564590-20-022818:notes:48]


## us-gaap:IntangibleAssetsDisclosureTextBlock

[0001564590-20-037715:notes:54]
[same as prior period, unchanged from 0001564590-20-022818:notes:49]

[0001564590-20-037715:notes:55]
As of June 29, 2020 and December 30, 2019, the components of definite-lived intangibles were as follows:

[0001564590-20-037715:notes:56]
|  |  | Gross Amount |  |  | Accumulated Amortization |  |  | Net Carrying Amount |  |  | Weighted Average Amortization Period |  |
|  |  | (In thousands) |  |  | (In years) |  |
| June 29, 2020 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Customer relationships |  | $ | 397,500 |  |  | $ | (130,426 | ) |  | $ | 267,074 |  |  |  | 11.0 |  |
| Technology |  |  | 47,650 |  |  |  | (10,934 | ) |  |  | 36,716 |  |  |  | 9.5 |  |
|  |  | $ | 445,150 |  |  | $ | (141,360 | ) |  | $ | 303,790 |  |  |  |  |  |
| December 30, 2019 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Customer relationships |  | $ | 396,270 |  |  | $ | (111,272 | ) |  | $ | 284,998 |  |  |  | 11.0 |  |
| Technology |  |  | 39,500 |  |  |  | (8,064 | ) |  |  | 31,436 |  |  |  | 9.4 |  |
| Acquired intangibles from acquisition in 2019 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Customer relationships |  |  | 1,230 |  |  |  | (31 | ) |  |  | 1,199 |  |  |  | 5.0 |  |
| Technology |  |  | 8,150 |  |  |  | (103 | ) |  |  | 8,047 |  |  |  | 10.0 |  |
|  |  | $ | 445,150 |  |  | $ | (119,470 | ) |  | $ | 325,680 |  |  |  |  |  |

[0001564590-20-037715:notes:57]
Definite-lived intangibles are generally amortized using the straight-line method of amortization over the estimated useful life. Amortization expense was $10,945 and $11,773 for the quarters ended June 29, 2020 and July 1, 2019, respectively, and $21,890 and $29,104 for the two quarters ended June 29, 2020 and July 1, 2019, respectively. For the quarter and two quarters ended June 29, 2020, $1,384 and $2,767, respectively, of amortization expense is included in cost of goods sold. For the quarter and two quarters ended July 1, 2019, $1,180 and $2,359, respectively, of amortization expense is included in cost of goods sold.

[0001564590-20-037715:notes:58]
[same as prior period, unchanged from 0001564590-20-022818:notes:53]

[0001564590-20-037715:notes:59]
|  |  | (In thousands) |  |
| Remaining 2020 |  | $ | 21,891 |  |
| 2021 |  |  | 41,344 |  |
| 2022 |  |  | 38,793 |  |
| 2023 |  |  | 36,838 |  |
| 2024 |  |  | 29,812 |  |
| Thereafter |  |  | 135,112 |  |
|  |  | $ | 303,790 |  |


## us-gaap:LongTermDebtTextBlock

[0001564590-20-037715:notes:60]
(8) Long-term Debt and Letters of Credit

[0001564590-20-037715:notes:61]
The following table summarizes the long-term debt of the Company as of June 29, 2020 and December 30, 2019:

[0001564590-20-037715:notes:62]
|  |  | Interest Rate as of June 29, 2020 |  |  | Principal Outstanding as of June 29, 2020 |  |  | Interest Rate as of December 30, 2019 |  |  | Principal Outstanding as of December 30, 2019 |  |
|  |  | (In thousands) |  |
| Term Loan due September 2024 |  |  | 2.67 |  | % | $ | 805,879 |  |  |  | 4.28 |  | % | $ | 805,879 |  |
| Senior Notes due October 2025 |  |  | 5.63 |  |  |  | 375,000 |  |  |  | 5.63 |  |  |  | 375,000 |  |
| Convertible Senior Notes due December 2020 |  |  | 1.75 |  |  |  | 249,975 |  |  |  | 1.75 |  |  |  | 249,975 |  |
| U.S. ABL Revolving Loan due June 2024 |  |  | 1.42 |  |  |  | 40,000 |  |  |  | 3.03 |  |  |  | 40,000 |  |
| Asia ABL Revolving Loan due June 2024 |  |  | 1.57 |  |  |  | 30,000 |  |  |  | 3.18 |  |  |  | 30,000 |  |
|  |  |  |  |  |  |  | 1,500,854 |  |  |  |  |  |  |  | 1,500,854 |  |
| Less: Long-term debt unamortized discount |  |  |  |  |  |  | (6,627 | ) |  |  |  |  |  |  | (11,943 | ) |
| Long-term debt unamortized debt issuance costs |  |  |  |  |  |  | (11,418 | ) |  |  |  |  |  |  | (12,974 | ) |
|  |  |  |  |  |  |  | 1,482,809 |  |  |  |  |  |  |  | 1,475,937 |  |
| Less: current maturities |  |  |  |  |  |  | (649,975 | ) |  |  |  |  |  |  | (249,975 | ) |
| Long-term debt, less current maturities |  |  |  |  |  | $ | 832,834 |  |  |  |  |  |  | $ | 1,225,962 |  |

[0001564590-20-037715:notes:63]
The Company has twelve months to reinvest the cash proceeds received from the sale of the Mobility business unit. If the proceeds are not reinvested, the Company is required to use the proceeds to prepay the Term Loan. The Company plans to use the cash proceeds for debt repayment and reinvestment. As of June 29, 2020, the Term Loan had an outstanding balance of $805,879, of which $400,000 is included in short-term debt. Subsequent to June 29, 2020, the Company made a debt principal prepayment for the Term Loan of $400,000. Permitted investments, as defined in the Term Loan Credit Agreement, include extensions of trade credit in the ordinary course of business, investments in cash and cash equivalents, permitted acquisitions, investments in assets useful in the business of the Company and its restricted subsidiaries, investments in joint ventures and unrestricted subsidiaries among others.

[0001564590-20-037715:notes:64]
Debt Covenants

[0001564590-20-037715:notes:65]
Borrowings under the Term Loan and Senior Notes are subject to certain affirmative and negative covenants, including limitations on indebtedness, corporate transactions, investments and dispositions, and share payments.

[0001564590-20-037715:notes:66]
Under the occurrence of certain events, the U.S. Asset-Based Lending Credit Agreement (U.S. ABL) and Asia Asset-Based Lending Credit Agreement (Asia ABL) (collectively, the ABL Revolving Loans), are subject to various financial and operational covenants, including maintaining minimum fixed charge coverage ratios.

[0001564590-20-037715:notes:67]
Debt Issuance and Debt Discount

[0001564590-20-037715:notes:68]
As of June 29, 2020 and December 30, 2019, remaining unamortized debt discount and debt issuance costs for the Term Loan Facility, Senior Notes and Convertible Senior Notes are as follows:

[0001564590-20-037715:notes:69]
|  |  | As of June 29, 2020 |  |  | As of December 30, 2019 |
|  |  | Debt Issuance Costs |  |  | Debt Discount |  |  | Effective Interest Rate |  |  | Debt Issuance Costs |  |  | Debt Discount |  |  | Effective Interest Rate |  |  |
|  |  | (In thousands, except interest rates) |
| Term Loan due September 2024 |  | $ | 6,013 |  |  | $ | 1,819 |  |  |  | 4.66 |  | % | $ | 6,663 |  |  | $ | 2,016 |  |  |  | 4.66 |  | % |
| Senior Notes due October 2025 |  |  | 4,923 |  |  | — |  |  |  | 5.92 |  |  |  | 5,316 |  |  | — |  |  |  | 5.92 |  |  |
| Convertible Senior Notes |  |  | 482 |  |  |  | 4,808 |  |  |  | 6.48 |  |  |  | 995 |  |  |  | 9,927 |  |  |  | 6.48 |  |  |
|  |  | $ | 11,418 |  |  | $ | 6,627 |  |  |  |  |  |  | $ | 12,974 |  |  | $ | 11,943 |  |  |  |  |  |  |

[0001564590-20-037715:notes:70]
The above debt discount and debt issuance costs are recorded as a reduction of the debt and are amortized into interest expense using an effective interest rate over the duration of the debt.

[0001564590-20-037715:notes:71]
Remaining unamortized debt issuance costs for the ABL Revolving Loans of $2,226 and $2,511 as of June 29, 2020 and December 30, 2019, respectively, are included in other non-current assets and are amortized to interest expense over the duration of the ABL Revolving Loans using the straight-line method of amortization.

[0001564590-20-037715:notes:72]
As of June 29, 2020, the remaining weighted average amortization period for all unamortized debt discount and debt issuance costs was 3.5 years.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001564590-20-037715:notes:73]
[same as prior period, unchanged from 0001564590-20-022818:notes:68]

[0001564590-20-037715:notes:74]
[same as prior period, unchanged from 0001564590-20-022818:notes:69]

[0001564590-20-037715:notes:75]
During the quarter and two quarters ended June 29, 2020, the Company’s effective tax rate was impacted by a net discrete benefit of $6,871 and $4,818, respectively. This is related mainly to release of uncertain tax positions due to the expiration of the statute of limitation in foreign jurisdictions netted against (i) an increase of valuation allowance and withholding tax expense related to the announced closure of two of the E-M Solutions plants, (ii) retroactive approval of the Company’s renewal application for High and New Tax Enterprise status for two of the Company’s manufacturing subsidiaries in China (including the impact on the respective Company’s deferred tax assets) and (iii) by the accrued interest expense on existing uncertain tax positions.

[0001564590-20-037715:notes:76]
[same as prior period, unchanged from 0001564590-20-022818:notes:71]


## us-gaap:FinancialInstrumentsDisclosureTextBlock

[0001564590-20-037715:notes:77]
[same as prior period, unchanged from 0001564590-20-022818:notes:72]

[0001564590-20-037715:notes:78]
[same as prior period, unchanged from 0001564590-20-022818:notes:73]

[0001564590-20-037715:notes:79]
[same as prior period, unchanged from 0001564590-20-022818:notes:74]

[0001564590-20-037715:notes:80]
[same as prior period, unchanged from 0001564590-20-022818:notes:75]

[0001564590-20-037715:notes:81]
[same as prior period, unchanged from 0001564590-20-022818:notes:76]

[0001564590-20-037715:notes:82]
At inception, the Company designated the interest rate swap as a cash flow hedge and the fair value of the interest rate swap was zero. As of June 29, 2020, the fair value of the interest rate swap was recorded as a liability in the amount of $19,582 and included as a component of other long-term liabilities. The change in the fair value of the interest rate swap is recorded as a component of accumulated other comprehensive loss, net of tax. No ineffectiveness was recognized for the quarter and two quarters ended June 29, 2020 and July 1, 2019. The interest rate swap increased interest expense by $2,342 and $367 for the quarters ended June 29, 2020 and July 1, 2019, respectively, and $3,517 and $706 for the two quarters ended June 29, 2020 and July 1, 2019, respectively.

[0001564590-20-037715:notes:83]
[same as prior period, unchanged from 0001564590-20-022818:notes:78]

[0001564590-20-037715:notes:84]
The Company enters into foreign currency forward contracts to mitigate the impact of changes in foreign currency exchange rates and to reduce the volatility of purchases and other obligations generated in currencies other than its functional currencies. The Company’s foreign subsidiaries may at times purchase forward exchange contracts to manage their foreign currency risks in relation to certain purchases of machinery denominated in foreign currencies other than the Company’s functional currencies. The notional amount of the foreign exchange contracts as of June 29, 2020 and December 30, 2019 was approximately $1,361 and $1,994, respectively. The Company has designated certain of these foreign exchange contracts as cash flow hedges.

[0001564590-20-037715:notes:85]
[same as prior period, unchanged from 0001564590-20-022818:notes:80]

[0001564590-20-037715:notes:86]
|  |  |  |  | Asset/(Liability) Fair Value |  |
|  |  | Balance Sheet Location |  | June 29, 2020 |  |  | December 30, 2019 |  |
|  |  |  |  | (In thousands) |  |
| Cash flow derivative instruments designated as hedges: |  |  |  |  |  |  |  |  |
| Interest rate swap |  | Other long-term liabilities |  | $ | (19,582 | ) |  | $ | (12,067 | ) |
| Cash flow derivative instruments not designated as hedges: |  |  |  |  |  |  |  |  |
| Foreign exchange contracts |  | Prepaid expenses and other current assets |  |  | 1 |  |  |  | 1 |  |
| Foreign exchange contracts |  | Other current liabilities |  |  | (4 | ) |  |  | (3 | ) |

[0001564590-20-037715:notes:87]
The following table provides information about the amounts recorded in accumulated other comprehensive loss related to derivatives designated as cash flow hedges, as well as the amounts recorded in each caption in the consolidated condensed statements of operations when derivative amounts are reclassified out of accumulated other comprehensive loss for the quarter and two quarters ended June 29, 2020 and July 1, 2019:

[0001564590-20-037715:notes:88]
|  |  |  | Quarter Ended June 29, 2020 |  |  | Quarter Ended July 1, 2019 |  |  |
|  |  | Financial Statement Caption | Loss Recognized in Other Comprehensive Loss |  |  | Loss Reclassified into Income |  |  | Loss Recognized in Other Comprehensive Loss |  |  | Loss Reclassified into Income |  |  |
|  |  |  | (In thousands) |
| Cash flow hedge: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Interest rate swap |  | Interest expense | $ | (2,583 | ) |  | $ | (2,342 | ) |  | $ | (6,077 | ) |  | $ | (367 | ) |  |

[0001564590-20-037715:notes:89]
|  |  |  | Two Quarters Ended June 29, 2020 |  |  | Two Quarters Ended July 1, 2019 |  |  |
|  |  | Financial Statement Caption | Loss Recognized in Other Comprehensive Loss |  |  | Loss Reclassified into Income |  |  | Loss Recognized in Other Comprehensive Loss |  |  | Loss Reclassified into Income |  |  |
|  |  |  | (In thousands) |
| Cash flow hedge: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Interest rate swap |  | Interest expense | $ | (11,032 | ) |  | $ | (3,517 | ) |  | $ | (8,663 | ) |  | $ | (706 | ) |  |

[0001564590-20-037715:notes:90]
The following table provides a summary of the activity associated with the designated cash flow hedges reflected in accumulated other comprehensive loss for the two quarters ended June 29, 2020 and July 1, 2019:

[0001564590-20-037715:notes:91]
|  |  | Two Quarters Ended |
|  |  | June 29, |  |  | July 1, |  |  |
|  |  | 2020 |  |  | 2019 |  |  |
|  |  | (In thousands) |
| Beginning balance, net of tax |  | $ | (9,617 | ) |  | $ | (4,214 | ) |  |
| Changes in fair value loss, net of tax |  |  | (8,012 | ) |  |  | (6,331 | ) |  |
| Reclassification to earnings, net of tax |  |  | 2,629 |  |  |  | 574 |  |  |
| Derecognition of unrealized losses on cash flow hedge due to sale of Mobility business unit |  |  | 384 |  |  |  | — |  |  |
| Ending balance, net of tax |  | $ | (14,616 | ) |  | $ | (9,971 | ) |  |

[0001564590-20-037715:notes:92]
Based on the current yield curve, the Company expects that losses of approximately $7,588 of the accumulated other comprehensive loss will be reclassified into the statement of operations, net of tax, in the next twelve months.


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0001564590-20-037715:notes:93]
[same as prior period, unchanged from 0001564590-20-022818:notes:87]

[0001564590-20-037715:notes:94]
The following provides a summary of the components of accumulated other comprehensive loss, net of tax, as of June 29, 2020 and December 30, 2019:

[0001564590-20-037715:notes:95]
|  |  | Foreign Currency Translation |  |  | Pension Obligation |  |  | (Losses) Gains on Cash Flow Hedges |  |  | Total |  |
|  |  | (In thousands) |  |
| Ending balance as of December 30, 2019 |  | $ | 1,115 |  |  | $ | (1,584 | ) |  | $ | (9,617 | ) |  | $ | (10,086 | ) |
| Other comprehensive (loss) income before reclassifications |  |  | (271 | ) |  |  | 21 |  |  |  | (8,012 | ) |  |  | (8,262 | ) |
| Amounts reclassified from accumulated other comprehensive loss |  |  | — |  |  |  | — |  |  |  | 2,629 |  |  |  | 2,629 |  |
| Derecognition of foreign currency translation adjustments due to sale of Mobility business unit |  |  | (27,341 | ) |  |  | — |  |  |  | — |  |  |  | (27,341 | ) |
| Derecognition of unrealized losses on cash flow hedge due to sale of Mobility business unit |  |  | — |  |  |  | — |  |  |  | 384 |  |  |  | 384 |  |
| Other comprehensive (loss) income |  |  | (27,612 | ) |  |  | 21 |  |  |  | (4,999 | ) |  |  | (32,590 | ) |
| Ending balance as of June 29, 2020 |  | $ | (26,497 | ) |  | $ | (1,563 | ) |  | $ | (14,616 | ) |  | $ | (42,676 | ) |


## us-gaap:ConcentrationRiskDisclosureTextBlock

[0001564590-20-037715:notes:96]
[same as prior period, unchanged from 0001564590-20-022818:notes:90]

[0001564590-20-037715:notes:97]
[same as prior period, unchanged from 0001564590-20-022818:notes:91]

[0001564590-20-037715:notes:98]
The Company’s customers include both OEMs and EMS companies. The Company’s OEM customers often direct a significant portion of their purchases through EMS companies. While the Company’s customers include both OEM and EMS providers, the Company measures customer concentration based on OEM companies, as they are the ultimate end customers. For the quarter ended June 29, 2020, one customer accounted for approximately 11% of the Company’s net sales. There were no other customers that accounted for 10% or more of net sales for the quarter ended June 29, 2020. There were no customers that accounted for 10% or more of net sales for the quarter ended July 1, 2019 and two quarters ended June 29, 2020 and July 1, 2019.


## us-gaap:FairValueDisclosuresTextBlock

[0001564590-20-037715:notes:99]
[same as prior period, unchanged from 0001564590-20-022818:notes:93]

[0001564590-20-037715:notes:100]
[same as prior period, unchanged from 0001564590-20-022818:notes:94]

[0001564590-20-037715:notes:101]
The carrying amount and estimated fair value of the Company’s financial instruments as of June 29, 2020 and December 30, 2019 were as follows:

[0001564590-20-037715:notes:102]
|  |  | As of |  |  | As of |  |
|  |  | June 29, 2020 |  |  | December 30, 2019 |  |
|  |  | Carrying Amount |  |  | Fair Value |  |  | Carrying Amount |  |  | Fair Value |  |
|  |  | (In thousands) |  |
| Derivative assets, current |  | $ | 1 |  |  | $ | 1 |  |  | $ | 1 |  |  | $ | 1 |  |
| Derivative liabilities, current |  |  | 4 |  |  |  | 4 |  |  |  | 3 |  |  |  | 3 |  |
| Derivative liabilities, non-current |  |  | 19,582 |  |  |  | 19,582 |  |  |  | 12,067 |  |  |  | 12,067 |  |
| Term Loan due September 2024 |  |  | 798,047 |  |  |  | 765,585 |  |  |  | 797,200 |  |  |  | 808,901 |  |
| Senior Notes due October 2025 |  |  | 370,077 |  |  |  | 373,448 |  |  |  | 369,684 |  |  |  | 390,143 |  |
| Convertible Senior Notes due December 2020 |  |  | 244,685 |  |  |  | 306,994 |  |  |  | 239,053 |  |  |  | 391,686 |  |
| ABL Revolving Loans |  |  | 70,000 |  |  |  | 70,000 |  |  |  | 70,000 |  |  |  | 70,000 |  |

[0001564590-20-037715:notes:103]
[same as prior period, unchanged from 0001564590-20-022818:notes:97]

[0001564590-20-037715:notes:104]
The fair value of the long-term debt was estimated based on quoted market prices or discounting the debt over its life using current market rates for similar debt as of June 29, 2020 and December 30, 2019, which are considered Level 2 inputs.

[0001564590-20-037715:notes:105]
[same as prior period, unchanged from 0001564590-20-022818:notes:99]

[0001564590-20-037715:notes:106]
As of June 29, 2020 and December 30, 2019, the Company’s other financial instruments also included cash and cash equivalents, accounts receivable, and accounts payable. Due to short-term maturities, the carrying amount of these instruments approximates fair value. The Company’s cash and cash equivalents as of June 29, 2020 consisted of $305,263 held in the U.S., with the remaining $389,405 held by foreign subsidiaries.

[0001564590-20-037715:notes:107]
[same as prior period, unchanged from 0001564590-20-022818:notes:101]


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001564590-20-037715:notes:108]
(14) Commitments and Contingencies

[0001564590-20-037715:notes:109]
Legal Matters

[0001564590-20-037715:notes:110]
The Company is subject to various legal matters, which it considers normal for its business activities. While the Company currently believes that the amount of any reasonably possible loss for known matters would not be material to the Company’s financial condition, the outcome of these actions is inherently difficult to predict. In the event of an adverse outcome, the ultimate potential loss could have a material adverse effect on the Company’s financial condition or results of operations in a particular period. The Company has accrued amounts for its loss contingencies which are probable and estimable as of June 29, 2020 and December 30, 2019. However, these amounts are not material to the consolidated condensed financial statements of the Company.


## us-gaap:EarningsPerShareTextBlock

[0001564590-20-037715:notes:111]
(15) Earnings Per Share

[0001564590-20-037715:notes:112]
The following is a reconciliation of the numerator and denominator used to calculate basic earnings per share and diluted earnings per share from continuing operations for the quarter and two quarters ended June 29, 2020 and July 1, 2019:

[0001564590-20-037715:notes:113]
|  |  | Quarter Ended |  |  | Two Quarters Ended |  |
|  |  | June 29, 2020 |  |  | July 1, 2019 |  |  | June 29, 2020 |  |  | July 1, 2019 |  |
|  |  | (In thousands, except per share amounts) |  |
| Basic earnings: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic earnings |  | $ | 9,346 |  |  | $ | 12,493 |  |  | $ | 6,126 |  |  | $ | 18,731 |  |
| Diluted earnings: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Net income |  | $ | 9,346 |  |  | $ | 12,493 |  |  | $ | 6,126 |  |  | $ | 18,731 |  |
| Interest expense from Convertible Senior Notes, net of tax |  |  | — |  |  |  | 2,780 |  |  |  | — |  |  |  | — |  |
| Diluted earnings |  | $ | 9,346 |  |  | $ | 15,273 |  |  | $ | 6,126 |  |  | $ | 18,731 |  |
| Basic weighted average shares |  |  | 106,295 |  |  |  | 105,470 |  |  |  | 105,990 |  |  |  | 104,893 |  |
| Dilutive effect of performance-based restricted stock units, restricted stock units and stock options |  |  | 1,190 |  |  |  | 637 |  |  |  | 1,441 |  |  |  | 967 |  |
| Dilutive effect of assumed conversion of Convertible Senior Notes outstanding |  |  | — |  |  |  | 25,938 |  |  |  | — |  |  |  | — |  |
| Diluted shares |  |  | 107,485 |  |  |  | 132,045 |  |  |  | 107,431 |  |  |  | 105,860 |  |
| Earnings per share: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  | $ | 0.09 |  |  | $ | 0.12 |  |  | $ | 0.06 |  |  | $ | 0.18 |  |
| Diluted |  | $ | 0.09 |  |  | $ | 0.12 |  |  | $ | 0.06 |  |  | $ | 0.18 |  |

[0001564590-20-037715:notes:114]
PRUs, RSUs, and stock options to purchase 1,162 and 1,089 shares of common stock for the quarters ended June 29, 2020 and July 1, 2019, respectively, and 750 and 1,089 shares of common stock for the two quarters ended June 29, 2020 and July 1, 2019, respectively, were not included in the computation of diluted earnings per share. The PRUs were not included in the computation of diluted earnings per share because the performance conditions had not been met at June 29, 2020 and July 1, 2019, and for RSUs and stock options, the options’ exercise prices or the total expected proceeds under the treasury stock method was greater than the average market price of common shares during the applicable quarter and two quarters and, as a result, the impact would be anti-dilutive.

[0001564590-20-037715:notes:115]
Outstanding warrants for the quarter and two quarters ended June 29, 2020 and July 1, 2019, to purchase common stock were not included in the computation of dilutive earnings per share because the strike price of the warrants to purchase the Company’s common stock were greater than the average market price of common shares during the applicable quarter, and therefore, the effect would be anti-dilutive.

[0001564590-20-037715:notes:116]
For the quarter and two quarters ended June 29, 2020 and for the two quarters ended July 1, 2019, the effect of shares of common stock related to the Company’s Convertible Senior Notes, based on the if-converted method, were not included in the computation of dilutive earnings per share as the impact would be anti-dilutive.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001564590-20-037715:notes:117]
[same as prior period, unchanged from 0001564590-20-022818:notes:112]

[0001564590-20-037715:notes:118]
[same as prior period, unchanged from 0001564590-20-022818:notes:113]

[0001564590-20-037715:notes:119]
|  |  | Quarter Ended |  | Two Quarters Ended |
|  |  | June 29, |  |  | July 1, |  |  |  | June 29, |  |  | July 1, |  |  |
|  |  | 2020 |  |  | 2019 |  |  |  | 2020 |  |  | 2019 |  |  |
|  |  | (In thousands) |  | (In thousands) |
| Cost of goods sold |  | $ | 620 |  |  | $ | 569 |  |  |  | $ | 1,470 |  |  | $ | 1,273 |  |  |
| Selling and marketing |  |  | 291 |  |  |  | 383 |  |  |  |  | 742 |  |  |  | 834 |  |  |
| General and administrative |  |  | 1,690 |  |  |  | 2,611 |  |  |  |  | 5,167 |  |  |  | 5,332 |  |  |
| Research and development |  |  | 46 |  |  |  | 39 |  |  |  |  | 103 |  |  |  | 89 |  |  |
| Stock-based compensation expense recognized |  | $ | 2,647 |  |  | $ | 3,602 |  |  |  | $ | 7,482 |  |  | $ | 7,528 |  |  |

[0001564590-20-037715:notes:120]
[same as prior period, unchanged from 0001564590-20-022818:notes:115]

[0001564590-20-037715:notes:121]
The following is a summary of total unrecognized compensation costs as of June 29, 2020:

[0001564590-20-037715:notes:122]
|  |  | Unrecognized Stock-Based Compensation Cost |  |  | Remaining Weighted Average Recognition Period |  |
|  |  | (In thousands) |  |  | (In years) |  |
| RSU awards |  | $ | 28,531 |  |  |  | 1.7 |  |
| PRU awards |  |  | 1,760 |  |  |  | 1.1 |  |
| Stock options |  |  | 184 |  |  |  | 1.4 |  |
|  |  | $ | 30,475 |  |  |  |  |  |


## us-gaap:SegmentReportingDisclosureTextBlock

[0001564590-20-037715:notes:123]
[same as prior period, unchanged from 0001564590-20-022818:notes:118]

[0001564590-20-037715:notes:124]
[same as prior period, unchanged from 0001564590-20-022818:notes:119]

[0001564590-20-037715:notes:125]
[same as prior period, unchanged from 0001564590-20-022818:notes:120]

[0001564590-20-037715:notes:126]
|  |  | Quarter Ended |  |  | Two Quarters Ended |  |
|  |  | June 29, 2020 |  |  | July 1, 2019 |  |  | June 29, 2020 |  |  | July 1, 2019 |  |
|  |  | (In thousands) |  |
| Net Sales: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| PCB |  | $ | 520,067 |  |  | $ | 466,960 |  |  | $ | 987,497 |  |  | $ | 952,027 |  |
| E-M Solutions |  |  | 50,231 |  |  |  | 59,917 |  |  |  | 80,447 |  |  |  | 111,295 |  |
| Total net sales |  | $ | 570,298 |  |  | $ | 526,877 |  |  | $ | 1,067,944 |  |  | $ | 1,063,322 |  |
| Operating Segment Income (Loss): |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| PCB |  | $ | 80,056 |  |  | $ | 62,463 |  |  | $ | 141,682 |  |  | $ | 132,957 |  |
| E-M Solutions |  |  | (15,577 | ) |  |  | 863 |  |  |  | (19,906 | ) |  |  | 2,042 |  |
| Corporate |  |  | (30,538 | ) |  |  | (22,561 | ) |  |  | (60,708 | ) |  |  | (46,787 | ) |
| Total operating segment income |  |  | 33,941 |  |  |  | 40,765 |  |  |  | 61,068 |  |  |  | 88,212 |  |
| Amortization of definite-lived intangibles (1) |  |  | (10,945 | ) |  |  | (11,773 | ) |  |  | (21,890 | ) |  |  | (29,104 | ) |
| Total operating income |  |  | 22,996 |  |  |  | 28,992 |  |  |  | 39,178 |  |  |  | 59,108 |  |
| Total other expense |  |  | (18,117 | ) |  |  | (17,546 | ) |  |  | (35,396 | ) |  |  | (39,038 | ) |
| Income before income taxes |  | $ | 4,879 |  |  | $ | 11,446 |  |  | $ | 3,782 |  |  | $ | 20,070 |  |

[0001564590-20-037715:notes:127]
| (1) | Amortization of definite-lived intangibles relates to the PCB reportable segment. For the quarter and two quarters ended June 29, 2020, $1,384 and $2,767, respectively, of amortization expense is included in cost of goods sold. For the quarter and two quarters ended July 1, 2019, $1,180 and $2,359, respectively, of amortization expense is included in cost of goods sold. |

[0001564590-20-037715:notes:128]
[same as prior period, unchanged from 0001564590-20-022818:notes:123]


## us-gaap:RelatedPartyTransactionsDisclosureTextBlock

[0001564590-20-037715:notes:129]
(18) Related Party Transactions

[0001564590-20-037715:notes:130]
In the normal course of business, the Company’s foreign subsidiaries purchase laminate and prepreg from related parties in which a former member of the Board of Directors of the Company holds an equity interest. The Company’s foreign subsidiaries purchased laminate and prepreg from these related parties in the amount of $5,986 and $8,193 for the quarters ended June 29, 2020 and July 1, 2019, respectively, and $11,767 and $15,696 for the two quarters ended June 29, 2020 and July 1, 2019, respectively.

[0001564590-20-037715:notes:131]
As of June 29, 2020 and December 30, 2019, the Company’s consolidated condensed balance sheets included $7,601 and $9,220, respectively, in accounts payable due to related parties for purchases of laminate and prepreg and such balances are included as a component of accounts payable on the consolidated condensed balance sheets.


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0001564590-20-037715:notes:132]
(19) Restructuring Charges

[0001564590-20-037715:notes:133]
On April 29, 2020, the Company announced the restructuring of its E-M Solutions business unit. The E-MS business unit consists of three Chinese manufacturing facilities with two being in Shanghai (SH BPA and SH E-MS) and one in Shenzhen (SZ). The Company will discontinue operations at the SH E-MS and SZ facilities while integrating the SH BPA facility into its PCB operations. The restructuring is another step in advancing the Company’s stated strategy of increasing its focus on differentiated higher margin products that more fully leverage the Company’s early engagement capabilities and industry leading engineering-based technology solutions. The closure of the SH E-MS and SZ facilities will not be immediate as the Company has obligations to fulfill with customers. The Company anticipates phasing out production over the remainder of 2020. As of June 29, 2020, the Company has incurred approximately $13,414 of restructuring charges since the April 29, 2020 announcement. The Company estimates that it will incur total charges related to restructuring of its E-M Solutions business unit of approximately $18,500 and accelerated depreciation expense of approximately $8,000.

[0001564590-20-037715:notes:134]
In connection with the restructuring of its E-M Solutions business unit and other global realignment restructuring efforts, the Company recognized employee separation, contract termination and other costs during the quarter and two quarters ended June 29, 2020 and July 1, 2019. Contract termination and other costs primarily represented plant closure costs.

[0001564590-20-037715:notes:135]
The below table summarizes such restructuring costs by reportable segment, which are included as a component of general and administrative expenses in the consolidated condensed statements of operations, for the quarter and two quarters ended

[0001564590-20-037715:notes:136]
June 29, 2020 and July 1, 2019:

[0001564590-20-037715:notes:137]
|  |  | Quarter Ended June 29, 2020 |  |  | Two Quarters Ended June 29, 2020 |  |  |
|  |  | Employee Separation/ Severance |  |  | Contract Termination and Other Costs |  |  | Total |  |  | Employee Separation/ Severance |  |  | Contract Termination and Other Costs |  |  | Total |  |  |
|  |  | (In thousands) |  |  |
| Reportable Segment: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| PCB |  | $ | (8 | ) |  | $ | 1 |  |  | $ | (7 | ) |  | $ | (8 | ) |  | $ | 14 |  |  | $ | 6 |  |  |
| E-M Solutions |  |  | 13,085 |  |  |  | 292 |  |  |  | 13,377 |  |  |  | 13,394 |  |  |  | 291 |  |  |  | 13,685 |  |  |
| Corporate |  |  | — |  |  |  | 44 |  |  |  | 44 |  |  |  | — |  |  |  | 51 |  |  |  | 51 |  |  |
|  |  | $ | 13,077 |  |  | $ | 337 |  |  | $ | 13,414 |  |  | $ | 13,386 |  |  | $ | 356 |  |  | $ | 13,742 |  |  |

[0001564590-20-037715:notes:138]
|  |  | Quarter Ended July 1, 2019 |  |  | Two Quarters Ended July 1, 2019 |  |  |
|  |  | Employee Separation/ Severance |  |  | Contract Termination and Other Costs |  |  | Total |  |  | Employee Separation/ Severance |  |  | Contract Termination and Other Costs |  |  | Total |  |  |
|  |  | (In thousands) |  |  |
| Reportable Segment: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| PCB |  | $ | 2,564 |  |  | $ | — |  |  | $ | 2,564 |  |  | $ | 2,988 |  |  | $ | — |  |  | $ | 2,988 |  |  |
| E-M Solutions |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |
| Corporate |  |  | 160 |  |  |  | 8 |  |  |  | 168 |  |  |  | 160 |  |  |  | 16 |  |  |  | 176 |  |  |
|  |  | $ | 2,724 |  |  | $ | 8 |  |  | $ | 2,732 |  |  | $ | 3,148 |  |  | $ | 16 |  |  | $ | 3,164 |  |  |

[0001564590-20-037715:notes:139]
Accrued restructuring costs are included as a component of other current liabilities in the consolidated condensed balance sheet. The below table shows the utilization of the accrued restructuring costs during the two quarters ended June 29, 2020:

[0001564590-20-037715:notes:140]
|  |  | Employee Separation/ Severance |  |  | Contract Termination and Other Costs |  |  | Total |  |
|  |  | (In thousands) |  |
| Accrued as of December 30, 2019 |  | $ | 260 |  |  | $ | 242 |  |  | $ | 502 |  |
| Charged to expense |  |  | 13,386 |  |  |  | 356 |  |  |  | 13,742 |  |
| Amount paid |  |  | (2,130 | ) |  |  | (358 | ) |  |  | (2,488 | ) |
| Accrued as of June 29, 2020 |  | $ | 11,516 |  |  | $ | 240 |  |  | $ | 11,756 |  |


## us-gaap:SubsequentEventsTextBlock

[0001564590-20-037715:notes:141]
(20) Subsequent Event

[0001564590-20-037715:notes:142]
Subsequent to June 29, 2020, the Company made a $400,000 debt principal prepayment for its Term Loan.
