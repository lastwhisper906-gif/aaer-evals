# TTMI 8-K — 0001193125-20-203110 filed 2020-07-29

## item codes, every 8-K on or before 2020-08-06

- 2020-07-29 0001193125-20-203110 — 2.02, 9.01
- 2020-05-08 0001193125-20-137566 — 5.07
- 2020-05-04 0001193125-20-131366 — 7.01, 9.01
- 2020-04-29 0001193125-20-126358 — 2.05, 7.01, 9.01
- 2020-04-29 0001193125-20-126117 — 2.02, 9.01
- 2020-04-23 0001193125-20-117365 — 2.01, 7.01, 9.01
- 2020-02-05 0001193125-20-025365 — 2.02, 9.01
- 2020-01-31 0001193125-20-021278 — 5.02
- 2020-01-22 0001193125-20-012011 — 1.01, 7.01, 9.01
- 2019-10-30 0001193125-19-278973 — 2.02, 9.01
- 2019-08-19 0001193125-19-224091 — 5.02, 9.01
- 2019-07-31 0001193125-19-208689 — 2.02, 9.01
- 2019-07-24 0001193125-19-201401 — 1.01, 2.03
- 2019-06-13 0001193125-19-171943 — 7.01, 9.01
- 2019-06-06 0001193125-19-167332 — 1.01, 2.03, 3.03, 7.01, 9.01
- 2019-05-09 0001193125-19-143113 — 5.07
- 2019-05-01 0001193125-19-132977 — 2.02, 9.01
- 2019-02-06 0001193125-19-029540 — 2.02, 9.01
- 2019-01-15 0001193125-19-009142 — 2.02, 9.01
- 2018-10-30 0001193125-18-312212 — 2.02, 9.01
- 2018-10-22 0001193125-18-303926 — 5.02
- 2018-09-06 0001193125-18-268231 — 5.02, 9.01
- 2018-08-01 0001193125-18-234997 — 2.02, 9.01
- 2018-06-29 0001193125-18-209635 — 9.01 — amendment of 0001193125-18-120583
- 2018-05-29 0001193125-18-176976 — 7.01, 9.01
- 2018-05-10 0001193125-18-159394 — 5.07
- 2018-05-09 0001193125-18-157596 — 5.02
- 2018-05-02 0001193125-18-148650 — 2.02, 9.01
- 2018-04-18 0001193125-18-120583 — 1.01, 2.01, 2.03, 7.01, 9.01
- 2018-02-21 0001193125-18-052169 — 8.01, 9.01
- 2018-02-20 0001193125-18-050385 — 5.02, 9.01
- 2018-02-09 0001193125-18-036966 — 7.01, 9.01
- 2018-02-07 0001193125-18-034744 — 2.02, 9.01
- 2017-12-14 0001193125-17-369625 — 1.01, 2.03, 9.01
- 2017-12-04 0001193125-17-359439 — 1.01, 7.01, 9.01
- 2017-11-01 0001193125-17-329425 — 2.02, 9.01
- 2017-09-29 0001193125-17-298999 — 1.01, 2.03, 3.03, 7.01, 9.01
- 2017-09-15 0001193125-17-286491 — 7.01, 9.01
- 2017-09-11 0001193125-17-281193 — 7.01, 9.01
- 2017-09-06 0001193125-17-277536 — 7.01, 9.01
- 2017-08-02 0001193125-17-245823 — 2.02, 9.01
- 2017-05-18 0001193125-17-173896 — 5.02, 5.07
- 2017-05-08 0001193125-17-162548 — 2.02, 9.01
- 2017-03-01 0001193125-17-063931 — 1.01, 1.02, 5.02
- 2017-02-08 0001193125-17-034652 — 2.02, 9.01
- 2016-11-18 0001193125-16-772305 — 8.01, 9.01
- 2016-10-26 0001193125-16-747948 — 2.02, 9.01
- 2016-10-20 0001193125-16-742905 — 5.02
- 2016-10-05 0001193125-16-731552 — 5.02, 9.01
- 2016-09-27 0001193125-16-720828 — 1.01, 2.03, 7.01, 9.01
- 2016-07-27 0001193125-16-659983 — 2.02, 9.01
- 2016-05-23 0001193125-16-599342 — 7.01, 9.01
- 2016-05-18 0001193125-16-594656 — 5.02, 5.03, 5.07, 9.01
- 2016-04-27 0001171843-16-009432 — 2.02, 9.01
- 2016-03-08 0001193125-16-495457 — 5.03, 7.01, 9.01
- 2016-02-09 0001193125-16-454281 — 8.01, 9.01
- 2016-02-04 0001171843-16-007659 — 2.02, 9.01
- 2016-01-04 0001193125-16-418740 — 1.01, 9.01
- 2015-12-11 0001193125-15-400867 — 5.02, 9.01
- 2015-10-30 0001171843-15-005835 — 2.02, 7.01 — amendment of 0001171843-15-005766
- 2015-10-28 0001171843-15-005766 — 2.02, 9.01
- 2015-09-29 0001193125-15-331517 — 2.02, 2.05, 2.06, 9.01
- 2015-08-05 0001171843-15-004361 — 2.02, 9.01
- 2015-07-31 0001193125-15-272962 — 9.01 — amendment of 0001193125-15-210734
- 2015-06-02 0001193125-15-210734 — 1.01, 1.02, 2.01, 2.03, 7.01, 9.01
- 2015-05-29 0001193125-15-206622 — 1.01, 2.03, 9.01
- 2015-05-20 0001171843-15-002975 — 7.01, 9.01
- 2015-05-19 0001193125-15-193434 — 5.07, 9.01
- 2015-05-05 0001171843-15-002499 — 7.01, 9.01
- 2015-04-29 0001171843-15-002307 — 2.02, 9.01
- 2015-04-21 0001193125-15-139239 — 7.01, 9.01
- 2015-04-21 0001171843-15-002065 — 2.02, 9.01
- 2015-02-04 0001171843-15-000599 — 2.02, 9.01
- 2015-01-20 0001193125-15-014019 — 7.01, 9.01
- 2014-12-30 0001193125-14-457111 — 7.01, 9.01
- 2014-12-15 0001193125-14-442645 — 1.01, 9.01
- 2014-12-04 0001193125-14-433658 — 8.01, 9.01
- 2014-11-18 0001193125-14-415889 — 7.01, 9.01
- 2014-10-29 0001171843-14-005051 — 2.02, 9.01
- 2014-10-27 0001193125-14-383428 — 1.01, 9.01
- 2014-09-22 0001193125-14-348697 — 1.01, 7.01, 9.01
- 2014-08-05 0001193125-14-295808 — 1.01, 5.02, 9.01
- 2014-07-30 0001171843-14-003548 — 2.02, 9.01
- 2014-04-30 0001171843-14-002017 — 2.02, 9.01
- 2014-04-25 0001193125-14-160146 — 5.02, 5.07, 9.01
- 2014-04-10 0001171843-14-001656 — 2.02, 9.01
- 2014-03-04 0001193125-14-082534 — 4.01, 9.01
- 2014-02-05 0001171843-14-000553 — 2.02, 9.01
- 2014-01-14 0001193125-14-010922 — 1.01, 2.03, 3.02, 8.01, 9.01
- 2013-12-27 0001193125-13-486144 — 5.02, 9.01
- 2013-12-20 0001193125-13-481141 — 1.01, 1.02, 2.03, 3.02, 8.01, 9.01
- 2013-12-17 0001193125-13-476207 — 5.03
- 2013-10-30 0001193125-13-418572 — 2.02, 5.02, 9.01
- 2013-09-12 0001193125-13-365420 — 2.05
- 2013-08-14 0001193125-13-334349 — 7.01, 9.01
- 2013-08-01 0001171843-13-003138 — 2.02, 9.01
- 2013-06-25 0001193125-13-270725 — 5.02, 9.01
- 2013-05-02 0001171843-13-001746 — 2.02, 9.01
- 2013-04-29 0001193125-13-182083 — 5.02, 5.07, 9.01
- 2013-03-18 0001193125-13-111308 — 1.01, 7.01, 9.01
- 2013-03-06 0001193125-13-093625 — 5.02, 9.01
- 2013-03-01 0001193125-13-087439 — 2.02 — amendment of 0001171843-13-000414
- 2013-02-28 0001193125-13-084764 — 5.02
- 2013-02-05 0001171843-13-000414 — 2.02, 9.01
- 2013-01-31 0001193125-13-032848 — 5.02, 9.01
- 2013-01-17 0001193125-13-015928 — 7.01, 9.01
- 2013-01-16 0001193125-13-014581 — 2.02, 9.01
- 2012-12-11 0001193125-12-498644 — 5.02, 9.01
- 2012-11-15 0001193125-12-472451 — 7.01, 9.01
- 2012-11-01 0001171843-12-003890 — 2.02, 9.01
- 2012-09-19 0001193125-12-396969 — 1.01, 2.03, 7.01, 9.01
- 2012-09-11 0001193125-12-388130 — 7.01, 9.01
- 2012-07-31 0001171843-12-002829 — 2.02, 9.01
- 2012-05-15 0001193125-12-233501 — 7.01, 9.01
- 2012-05-01 0001171843-12-001574 — 2.02, 9.01
- 2012-04-27 0001193125-12-191623 — 5.07
- 2012-03-01 0001193125-12-090623 — 2.02 — amendment of 0001171843-12-000382
- 2012-02-07 0001171843-12-000382 — 2.02, 9.01
- 2012-01-19 0001193125-12-016588 — 5.02, 9.01
- 2011-11-15 0000950123-11-098812 — 7.01, 9.01
- 2011-11-02 0001171843-11-003248 — 2.02, 9.01
- 2011-09-28 0000950123-11-087344 — 7.01, 9.01
- 2011-09-19 0000950123-11-085128 — 5.02, 9.01
- 2011-09-15 0000950123-11-084704 — 5.07 — amendment of 0000950123-11-054296
- 2011-08-04 0001171843-11-002356 — 2.02, 9.01
- 2011-07-27 0000950123-11-068987 — 1.01, 2.03, 9.01
- 2011-06-21 0000950123-11-060477 — 7.01, 9.01
- 2011-06-06 0000950123-11-056971 — 5.03, 9.01
- 2011-05-26 0000950123-11-054296 — 5.07
- 2011-05-10 0000950123-11-048462 — 8.01, 9.01
- 2011-05-05 0001171843-11-001344 — 2.02, 9.01
- 2011-03-22 0000950123-11-027824 — 7.01, 9.01
- 2011-03-18 0000950123-11-026913 — 4.01
- 2011-03-18 0000950123-11-026910 — 4.01, 9.01 — amendment, the index does not say of what
- 2011-03-02 0000950123-11-020941 — 5.03, 9.01
- 2011-02-10 0001171843-11-000391 — 2.02, 9.01
- 2011-01-13 0000950123-11-002528 — 7.01, 9.01
- 2011-01-13 0000950123-11-002446 — 2.02, 9.01
- 2010-11-29 0000950123-10-109448 — 4.01, 9.01 — amendment, the index does not say of what
- 2010-11-17 0000950123-10-106706 — 4.01
- 2010-11-15 0000950123-10-105479 — 5.02, 9.01
- 2010-11-04 0001171843-10-002324 — 2.02, 9.01
- 2010-10-22 0000950123-10-095179 — 1.01, 9.01
- 2010-10-04 0000950123-10-090949 — 1.01, 5.03, 9.01
- 2010-08-05 0001171843-10-001587 — 2.02, 9.01
- 2010-08-05 0000950123-10-073258 — 1.01, 2.03, 9.01
- 2010-08-05 0000950123-10-073256 — 9.01 — amendment of 0000950123-10-034163
- 2010-07-12 0000950123-10-064794 — 5.02, 8.01, 9.01
- 2010-06-10 0000950123-10-057166 — 7.01, 9.01
- 2010-06-02 0000950123-10-055111 — 1.01, 5.07, 9.01
- 2010-05-06 0001171843-10-000819 — 2.02, 9.01
- 2010-04-26 0000950123-10-037806 — 8.01, 9.01 — amendment of 0000950123-10-034163
- 2010-04-13 0000950123-10-034163 — 1.01, 2.01, 2.03, 5.02, 7.01, 9.01
- 2010-03-30 0000950123-10-030123 — 1.01, 5.02, 9.01
- 2010-03-24 0000950123-10-027317 — 1.01, 5.02, 9.01
- 2010-03-16 0000950123-10-024853 — 7.01, 9.01 — amendment of 0001171843-10-000140
- 2010-03-15 0000950123-10-024637 — 5.07
- 2010-02-04 0001171843-10-000140 — 2.02, 9.01
- 2010-02-02 0000950123-10-007780 — 8.01, 9.01
- 2010-01-13 0000950123-10-002245 — 7.01, 9.01
- 2009-12-23 0000950123-09-073069 — 1.01, 9.01
- 2009-12-15 0000950123-09-070868 — 8.01, 9.01
- 2009-11-16 0000950123-09-062630 — 1.01, 7.01, 9.01
- 2009-11-04 0001171843-09-001103 — 2.02, 9.01
- 2009-09-04 0000950123-09-041133 — 2.05, 9.01
- 2009-07-29 0001171843-09-000743 — 2.02, 9.01
- 2009-06-09 0000950123-09-012507 — 7.01, 9.01
- 2009-04-30 0001171843-09-000427 — 2.02, 9.01
- 2009-04-28 0001362310-09-005960 — 8.01
- 2009-02-19 0001362310-09-002454 — 5.03, 9.01
- 2009-02-10 0001171843-09-000123 — 2.02, 9.01
- 2009-01-16 0000950153-09-000040 — 2.05, 9.01
- 2009-01-08 0000950153-09-000023 — 7.01, 9.01
- 2008-10-29 0001157523-08-008533 — 2.02, 9.01
- 2008-07-29 0001157523-08-005998 — 2.02, 9.01
- 2008-05-22 0000950153-08-001035 — 1.01, 2.03, 3.02, 9.01
- 2008-05-22 0000950153-08-001034 — 7.01, 9.01
- 2008-05-15 0000950153-08-000987 — 1.01, 1.02, 2.03, 3.02, 9.01
- 2008-04-30 0001157523-08-003483 — 2.02, 9.01
- 2008-02-07 0001157523-08-001077 — 2.02, 9.01
- 2008-01-08 0000950153-08-000033 — 7.01, 9.01
- 2007-11-15 0000950153-07-002440 — 7.01, 9.01
- 2007-11-14 0000950153-07-002426 — 7.01, 9.01
- 2007-11-14 0000950153-07-002421 — 5.03, 9.01
- 2007-10-31 0001157523-07-010491 — 2.02, 9.01
- 2007-10-02 0000950153-07-002094 — 7.01, 9.01
- 2007-07-31 0000950153-07-001622 — 2.02, 9.01
- 2007-06-13 0000950153-07-001327 — 7.01, 9.01
- 2007-05-02 0000950153-07-000941 — 2.02, 9.01
- 2007-04-12 0000950153-07-000763 — 5.02, 9.01
- 2007-02-15 0000950153-07-000339 — 2.02, 9.01
- 2007-01-11 0000950153-07-000076 — 7.01, 9.01
- 2007-01-10 0000950153-07-000071 — 2.01, 9.01 — amendment, the index does not say of what
- 2006-12-11 0000950153-06-002967 — 2.05, 9.01
- 2006-11-15 0000950153-06-002843 — 7.01, 9.01
- 2006-11-14 0000950153-06-002837 — 7.01, 9.01
- 2006-11-02 0000950153-06-002682 — 1.01, 1.02, 2.03, 9.01
- 2006-11-01 0000950153-06-002668 — 2.02, 9.01
- 2006-10-30 0000950124-06-006210 — 2.01, 9.01
- 2006-08-04 0000950153-06-002025 — 1.01, 9.01
- 2006-07-26 0000950153-06-001937 — 2.02, 9.01
- 2006-06-28 0000950153-06-001716 — 1.01, 9.01
- 2006-06-13 0000950153-06-001597 — 7.01, 9.01
- 2006-04-26 0000950153-06-001079 — 2.02, 9.01
- 2006-02-08 0001104659-06-006985 — 2.02, 9.01
- 2006-01-12 0001104659-06-001893 — 7.01, 9.01
- 2005-12-05 0001104659-05-058918 — 1.01, 5.02, 9.01
- 2005-10-26 0001104659-05-050306 — 2.02, 9.01
- 2005-09-20 0001104659-05-044954 — 8.01
- 2005-08-30 0001104659-05-042053 — 3.03, 8.01, 9.01
- 2005-07-27 0001104659-05-034437 — 2.02, 5.02, 9.01
- 2005-07-21 0001104659-05-033462 — 1.01, 1.02, 2.03, 9.01
- 2005-06-13 0001104659-05-027969 — 8.01
- 2005-06-08 0001104659-05-027364 — 7.01, 9.01
- 2005-05-17 0001104659-05-024118 — 7.01, 9.01
- 2005-05-12 0001104659-05-022993 — 7.01, 9.01
- 2005-05-11 0001104659-05-022606 — 1.01, 9.01
- 2005-05-02 0001104659-05-019649 — 2.02, 5.02, 9.01
- 2005-04-26 0001104659-05-018233 — 7.01, 9.01
- 2005-02-08 0001104659-05-004642 — 2.02, 9.01
- 2005-01-12 0001104659-05-001194 — 7.01, 9.01
- 2004-12-22 0001104659-04-040933 — 5.02
- 2004-12-08 0001104659-04-038850 — 7.01, 9.01
- 2004-10-26 0001104659-04-031931 — 2.02, 9.01
- 2004-10-01 0001104659-04-029361 — 5.02
- 2004-08-02 0001104659-04-021785 — 9
- 2004-07-29 0001104659-04-021529 — 12
- 2004-05-06 0001104659-04-012742 — 9
- 2004-04-26 0001104659-04-011228 — 12
- 2004-02-03 0001104659-04-002424 — 9
- 2004-01-28 0001104659-04-001980 — 12
- 2004-01-09 0001104659-04-000457 — 9
- 2003-10-21 0001104659-03-023304 — 12
- 2003-07-29 0001104659-03-015999 — 12
- 2003-05-08 0001104659-03-008647 — 9
- 2003-05-08 0001104659-03-008462 — 9
- 2003-05-01 0001104659-03-007866 — 9
- 2003-03-07 0001104659-03-003816 — 2, 7 — amendment of 0000950153-02-002190
- 2002-12-27 0000950153-02-002190 — 2, 7
- 2002-05-17 0000912057-02-021145 — 4, 7
- 2001-12-21 0000912057-01-544281 — 7
- 2000-10-27 0000912057-00-046109 — 5

## late-filing notifications on or before 2020-08-06

- none on or before 2020-08-06

## item 2.02 — earnings release, exhibit 99.1

[0001193125-20-203110:8k_2_02:1]
EX-99.1
2
d124119dex991.htm
EX-99.1

[0001193125-20-203110:8k_2_02:2]
EX-99.1

[0001193125-20-203110:8k_2_02:3]
Exhibit 99.1

[0001193125-20-203110:8k_2_02:4]
| TTM Technologies, Inc., Q2’20 |  |  |  |  |  | Contact: Sameer Desai, Senior Director, Corporate Development & Investor Relations Sameer.desai@ttmtech.com 714-327-3050 |

[0001193125-20-203110:8k_2_02:5]
TTM Technologies, Inc. Reports Fiscal Second Quarter 2020 Results

[0001193125-20-203110:8k_2_02:6]
Santa Ana, CA – July 29, 2020 – TTM Technologies, Inc. (NASDAQ:TTMI), a leading global printed circuit board (“PCB”) and radio
frequency (“RF”) components manufacturer, today reported results for the second quarter of fiscal 2020, which ended on June 29, 2020.

[0001193125-20-203110:8k_2_02:7]
On
April 19th, TTM completed the previously announced sale of its Mobility business unit. The operating results and related assets and liabilities of the Mobility business under US GAAP are presented as discontinued operations for all periods. To
facilitate the comparison of TTM’s results to previously issued guidance, non-GAAP financial information is also provided below which includes approximately three weeks of results for the Mobility
business unit as well as results from the previously announced closure of the two E-MS plants. Please refer to the earnings schedule for additional details on exited businesses and continuing operations.

[0001193125-20-203110:8k_2_02:8]
Second Quarter 2020 Highlights

[0001193125-20-203110:8k_2_02:9]
|  | • |  | GAAP net sales were $570.3 million |

[0001193125-20-203110:8k_2_02:10]
|  | • |  | Non-GAAP net sales were $601.1 million |

[0001193125-20-203110:8k_2_02:11]
|  | • |  | GAAP net income of $192.8 million, or $1.79 per diluted share, inclusive of a net gain on the sale of the Mobility business unit of $183.1 million or $1.70 per diluted share |

[0001193125-20-203110:8k_2_02:12]
|  | • |  | Non-GAAP net income was $33.3 million, or $0.31 per diluted share, inclusive of $0.01 of foreign exchange loss |

[0001193125-20-203110:8k_2_02:13]
|  | • |  | Cash flow from operations of $119.0 million |

[0001193125-20-203110:8k_2_02:14]
|  | • |  | Today repaid $400 million of Term Loan B from cash received from Mobility Business Unit divestiture |

[0001193125-20-203110:8k_2_02:15]
Second Quarter 2020 GAAP Financial Results

[0001193125-20-203110:8k_2_02:16]
Net sales from continuing operations for the second quarter of 2020 were $570.3 million, compared to $526.9 million in the second
quarter of 2019 and $497.6 million in the first quarter of 2020.

[0001193125-20-203110:8k_2_02:17]
GAAP operating income from continuing operations for the second quarter of
2020 was $23.0 million, compared to $29.0 million in the second quarter of 2019 and $16.2 million in the first quarter of 2020.

[0001193125-20-203110:8k_2_02:18]
GAAP net income for the second quarter of 2020 was $192.8 million, or $1.79 per diluted share and includes an estimated net gain of
$183.1 million from the sale of the Mobility business. This compares to net income of $3.4 million, or $0.03 per diluted share in the second quarter of 2019, and net loss of $1.2 million, or ($0.01) per diluted
share, in the first quarter of 2020.

[0001193125-20-203110:8k_2_02:19]
Second Quarter 2020 Non-GAAP Financial Results

[0001193125-20-203110:8k_2_02:20]
Net sales for the second quarter of 2020 were $601.1 million, compared to $633.0 million in the second quarter of 2019 and
$610.8 million in the first quarter of 2020.

[0001193125-20-203110:8k_2_02:21]
On a non-GAAP basis, net income for the second quarter
of 2020 was $33.3 million, or $0.31 per diluted share. This compares to non-GAAP net income of $21.3 million, or $0.20 per diluted share, for the second quarter of 2019 and $19.6 million, or $0.18 per diluted share, in
the first quarter of 2020.

[0001193125-20-203110:8k_2_02:22]
Adjusted EBITDA for the second quarter of 2020 was $80.3 million, or 13.4 percent of net sales,
compared to adjusted EBITDA of $82.9 million, or 13.1 percent of net sales, for the second quarter of 2019 and $82.1 million, or 13.4 percent of net sales, for the first quarter of 2020.

[0001193125-20-203110:8k_2_02:23]
| TTM Technologies, Inc., Q2’20 |  |  |  |  |  | Contact: Sameer Desai, Senior Director, Corporate Development & Investor Relations Sameer.desai@ttmtech.com 714-327-3050 |

[0001193125-20-203110:8k_2_02:24]
“In the second quarter, TTM demonstrated excellent operational execution and overcame COVID-19 related challenges to deliver revenue and earnings above the previously guided range. All of our manufacturing facilities continue to remain operational and I want to recognize all of our employees for
their tremendous efforts in support of our customers during these challenging times,” said Tom Edman, CEO of TTM. “The diversified mix of end markets that we serve enabled TTM to grow revenues and outperform earnings expectations despite
weakness in the automotive and commercial aerospace end markets. Finally, TTM has shown financial discipline, bringing our net debt to EBITDA ratio to 2.1, following the receipt of proceeds from the sale of the Mobility Business Unit and subsequent
repayment of our Term loan.”

[0001193125-20-203110:8k_2_02:25]
Business Outlook

[0001193125-20-203110:8k_2_02:26]
Looking ahead, we believe that we will continue to experience COVID-19 related impacts on our end markets as well as
inefficiencies with our own production. Taking this into consideration, TTM estimates that revenue for the third quarter of 2020 will be in the range of $470 million to $510 million, and
non-GAAP net income will be in the range of $0.16 to $0.22 per diluted share. This guidance no longer includes the Mobility Business Unit but continues to include the
E-MS business unit while that business winds down.

[0001193125-20-203110:8k_2_02:27]
Live Webcast/Conference Call

[0001193125-20-203110:8k_2_02:28]
TTM will host a conference call and webcast to discuss second quarter 2020 results and the third quarter 2020 outlook on Wednesday, July 29, 2020, at 4:30
p.m. Eastern Time (1:30 p.m. Pacific Time). The conference call will include forward-looking statements.

[0001193125-20-203110:8k_2_02:29]
Telephone access is available by dialing
domestic 800-367-2403 or international 334-777-6978 (ID 9715005). The conference call also will be webcast on TTM’s website
at www.ttm.com.

[0001193125-20-203110:8k_2_02:30]
To Access a Replay of the Webcast

[0001193125-20-203110:8k_2_02:31]
The replay of the webcast will remain accessible for one week following the live event on TTM’s website at www.ttm.com.

[0001193125-20-203110:8k_2_02:32]
About TTM

[0001193125-20-203110:8k_2_02:33]
TTM Technologies, Inc. is a leading global
printed circuit board manufacturer, focusing on quick-turn and volume production of technologically advanced PCBs and backplane assemblies as well as a global designer and manufacturer of high-frequency radio frequency (RF) and microwave components
and assemblies. TTM stands for time-to-market, representing how TTM’s time-critical, one-stop manufacturing services enable
customers to shorten the time required to develop new products and bring them to market. Additional information can be found at www.ttm.com.

[0001193125-20-203110:8k_2_02:34]
Forward-Looking Statements

[0001193125-20-203110:8k_2_02:35]
This release contains
forward-looking statements that relate to future events or performance. TTM cautions you that such statements are simply predictions and actual events or results may differ materially. These statements reflect TTM’s current expectations, and
TTM does not undertake to update or revise these forward looking statements, even if experience or future changes make it clear that any projected results expressed or implied in this or other TTM statements will not be realized. Further, these
statements involve risks and uncertainties, many of which are beyond TTM’s control, which could cause actual results to differ materially from the forward-looking statements. These risks and uncertainties include, but are not limited to, the
impact of COVID-19, general market and economic conditions, including interest rates, currency exchange rates and consumer spending, demand for TTM’s products, market pressures on prices of TTM’s
products, warranty claims, changes in product mix, contemplated

[0001193125-20-203110:8k_2_02:36]
| TTM Technologies, Inc., Q2’20 |  |  |  |  |  | Contact: Sameer Desai, Senior Director, Corporate Development & Investor Relations Sameer.desai@ttmtech.com 714-327-3050 |

[0001193125-20-203110:8k_2_02:37]
significant capital expenditures and related financing requirements, TTM’s dependence upon a small number of customers and other factors set forth in the “Risk Factors” and
“Management’s Discussion and Analysis of Financial Condition and Results of Operations” sections of the Company’s public reports filed with the SEC.

[0001193125-20-203110:8k_2_02:38]
About Our Non-GAAP Financial Measures

[0001193125-20-203110:8k_2_02:39]
This release includes information about TTM’s adjusted EBITDA, non-GAAP net income and non-GAAP earnings per share, all of which are non-GAAP financial measures. TTM presents non-GAAP financial information to enable
investors to see TTM through the eyes of management and to provide better insight into TTM’s ongoing financial performance.

[0001193125-20-203110:8k_2_02:40]
A material limitation
associated with the use of the above non-GAAP financial measures is that they have no standardized measurement prescribed by GAAP and may not be comparable to similar
non-GAAP financial measures used by other companies. TTM compensates for these limitations by providing full disclosure of each non-GAAP financial measure and
reconciliation to the most directly comparable GAAP financial measure. However, the non-GAAP financial measures should not be considered in isolation from, or as a substitute for, financial information
prepared in accordance with GAAP.

[0001193125-20-203110:8k_2_02:41]
With respect to the Company’s outlook for non-GAAP net income per diluted
share, we are unable to predict with reasonable certainty or without unreasonable effort certain items that may affect a comparable measure calculated and presented in accordance with GAAP. Our expected
non-GAAP net income per diluted share excludes primarily the future impact of restructuring actions, impairment charges, unusual gains and losses, and tax adjustments. These reconciling items are highly
variable and difficult to predict due to various factors outside of management’s control and could have a material impact on our future period net income per diluted share calculated and presented in accordance with GAAP. Accordingly, a
reconciliation of non-GAAP net income per diluted share to a comparable measure calculated and presented in accordance with GAAP is not available without unreasonable effort and has not been provided.

[0001193125-20-203110:8k_2_02:42]
- Tables Follow -

[0001193125-20-203110:8k_2_02:43]
TTM TECHNOLOGIES, INC.

[0001193125-20-203110:8k_2_02:44]
Selected Unaudited Financial Information

[0001193125-20-203110:8k_2_02:45]
(In thousands, except per share data)

[0001193125-20-203110:8k_2_02:46]
|  |  | Second Quarter |  |  | First Quarter |  |  | First Two Quarters |  |
|  |  | 2020 |  |  | 2019* |  |  | 2020 |  |  | 2020 |  |  | 2019* |  |
| CONSOLIDATED CONDENSED STATEMENTS OF OPERATIONS |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Net sales |  | $ | 570,298 |  |  | $ | 526,877 |  |  | $ | 497,646 |  |  | $ | 1,067,944 |  |  | $ | 1,063,322 |  |
| Cost of goods sold |  |  | 469,868 |  |  |  | 434,029 |  |  |  | 416,304 |  |  |  | 886,172 |  |  |  | 871,648 |  |
| Gross profit |  |  | 100,430 |  |  |  | 92,848 |  |  |  | 81,342 |  |  |  | 181,772 |  |  |  | 191,674 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Selling and marketing |  |  | 15,969 |  |  |  | 16,898 |  |  |  | 16,169 |  |  |  | 32,138 |  |  |  | 34,458 |  |
| General and administrative |  |  | 33,309 |  |  |  | 29,137 |  |  |  | 34,339 |  |  |  | 67,648 |  |  |  | 58,987 |  |
| Research and development |  |  | 5,181 |  |  |  | 4,496 |  |  |  | 4,762 |  |  |  | 9,943 |  |  |  | 9,212 |  |
| Amortization of definite-lived intangibles |  |  | 9,561 |  |  |  | 10,593 |  |  |  | 9,562 |  |  |  | 19,123 |  |  |  | 26,745 |  |
| Restructuring charges |  |  | 13,414 |  |  |  | 2,732 |  |  |  | 328 |  |  |  | 13,742 |  |  |  | 3,164 |  |
| Total operating expenses |  |  | 77,434 |  |  |  | 63,856 |  |  |  | 65,160 |  |  |  | 142,594 |  |  |  | 132,566 |  |
| Operating income |  |  | 22,996 |  |  |  | 28,992 |  |  |  | 16,182 |  |  |  | 39,178 |  |  |  | 59,108 |  |
| Interest expense |  |  | (18,572 | ) |  |  | (20,553 | ) |  |  | (19,781 | ) |  |  | (38,353 | ) |  |  | (41,688 | ) |
| Other, net |  |  | 455 |  |  |  | 3,007 |  |  |  | 2,502 |  |  |  | 2,957 |  |  |  | 2,650 |  |
| Income (Loss) from continuing operations before income taxes |  |  | 4,879 |  |  |  | 11,446 |  |  |  | (1,097 | ) |  |  | 3,782 |  |  |  | 20,070 |  |
| Income tax benefit (provision) |  |  | 4,467 |  |  |  | 1,047 |  |  |  | (2,123 | ) |  |  | 2,344 |  |  |  | (1,339 | ) |
| Net income (loss) from continuing operations |  |  | 9,346 |  |  |  | 12,493 |  |  |  | (3,220 | ) |  |  | 6,126 |  |  |  | 18,731 |  |
| Income (loss) from discontinued operations, net of income taxes |  |  | 183,464 |  |  |  | (9,069 | ) |  |  | 2,046 |  |  |  | 185,510 |  |  |  | (18,559 | ) |
| Net income (loss) |  | $ | 192,810 |  |  | $ | 3,424 |  |  | $ | (1,174 | ) |  | $ | 191,636 |  |  | $ | 172 |  |
| * Reclassified Research and development expenses as a separate line item from General and administrative expenses |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Earnings (loss) per share: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic earnings (loss) per share from continuing operations |  | $ | 0.09 |  |  | $ | 0.12 |  |  | $ | (0.03 | ) |  | $ | 0.06 |  |  | $ | 0.18 |  |
| Basic earnings (loss) per share from discontinued operations |  |  | 1.72 |  |  |  | (0.09 | ) |  |  | 0.02 |  |  |  | 1.75 |  |  |  | (0.18 | ) |
| Basic earnings (loss) per share |  | $ | 1.81 |  |  | $ | 0.03 |  |  | $ | (0.01 | ) |  | $ | 1.81 |  |  | $ | 0.00 |  |
| Diluted earnings (loss) per share from continuing operations |  | $ | 0.09 |  |  | $ | 0.12 |  |  | $ | (0.03 | ) |  | $ | 0.06 |  |  | $ | 0.18 |  |
| Diluted earnings (loss) per share from discontinued operations |  |  | 1.70 |  |  |  | (0.09 | ) |  |  | 0.02 |  |  |  | 1.72 |  |  |  | (0.18 | ) |
| Diluted earnings (loss) per share |  | $ | 1.79 |  |  | $ | 0.03 |  |  | $ | (0.01 | ) |  | $ | 1.78 |  |  | $ | 0.00 |  |
| Weighted-average shares used in computing per share amounts: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  |  | 106,295 |  |  |  | 105,470 |  |  |  | 105,686 |  |  |  | 105,990 |  |  |  | 104,893 |  |
| Diluted |  |  | 107,485 |  |  |  | 132,045 |  |  |  | 105,686 |  |  |  | 107,431 |  |  |  | 105,860 |  |
| Reconciliation of the denominator used to calculate basic earnings per share and diluted earnings per share: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Net income |  |  | 9,346 |  |  |  | 12,493 |  |  |  |  |  |  |  | 6,126 |  |  |  | 18,731 |  |
| Add back items: interest expense, net of tax |  |  | — |  |  |  | 2,780 |  |  |  |  |  |  |  | — |  |  |  | — |  |
| Adjusted net income |  |  | 9,346 |  |  |  | 15,273 |  |  |  |  |  |  |  | 6,126 |  |  |  | 18,731 |  |
| Weighted-average shares outstanding |  |  | 106,295 |  |  |  | 105,470 |  |  |  |  |  |  |  | 105,990 |  |  |  | 104,893 |  |
| Dilutive effect of convertible debt |  |  | — |  |  |  | 25,938 |  |  |  |  |  |  |  | — |  |  |  | — |  |
| Dilutive effect of warrants |  |  | — |  |  |  | — |  |  |  |  |  |  |  | — |  |  |  | — |  |
| Dilutive effect of performance-based stock units, restricted stock units & stock options |  |  | 1,190 |  |  |  | 637 |  |  |  |  |  |  |  | 1,441 |  |  |  | 967 |  |
| Diluted shares |  |  | 107,485 |  |  |  | 132,045 |  |  |  |  |  |  |  | 107,431 |  |  |  | 105,860 |  |
| Earnings per share: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic earnings per share from continuing operations |  | $ | 0.09 |  |  | $ | 0.12 |  |  |  |  |  |  | $ | 0.06 |  |  | $ | 0.18 |  |
| Basic earnings (loss) per share from discontinued operations |  |  | 1.72 |  |  |  | (0.09 | ) |  |  |  |  |  |  | 1.75 |  |  |  | (0.18 | ) |
| Basic earnings per share |  | $ | 1.81 |  |  | $ | 0.03 |  |  |  |  |  |  | $ | 1.81 |  |  | $ | 0.00 |  |
| Diluted earnings per share from continuing operations |  | $ | 0.09 |  |  | $ | 0.12 |  |  |  |  |  |  | $ | 0.06 |  |  | $ | 0.18 |  |
| Diluted earnings (loss) per share from discontinued operations |  |  | 1.70 |  |  |  | (0.09 | ) |  |  |  |  |  |  | 1.72 |  |  |  | (0.18 | ) |
| Diluted earnings per share |  | $ | 1.79 |  |  | $ | 0.03 |  |  |  |  |  |  | $ | 1.78 |  |  | $ | 0.00 |  |
| SELECTED BALANCE SHEET DATA |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | June 29,2020 |  |  | December 30,2019 |  |  |  |  |  |  |  |  |  |  |
| Cash and cash equivalents, including restricted cash |  | $ | 694,668 |  |  | $ | 379,818 |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Accounts and notes receivable, net |  |  | 414,329 |  |  |  | 503,598 |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Contract assets |  |  | 287,281 |  |  |  | 254,600 |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Inventories |  |  | 122,847 |  |  |  | 113,753 |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Current assets held for sale |  |  | — |  |  |  | 67,572 |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Total current assets |  |  | 1,871,912 |  |  |  | 1,342,684 |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Property, plant and equipment, net |  |  | 660,866 |  |  |  | 678,201 |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Operating lease right of use asset |  |  | 21,993 |  |  |  | 22,173 |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Non-current assets held for sale |  |  | — |  |  |  | 425,597 |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Other non-current assets |  |  | 1,039,900 |  |  |  | 1,092,278 |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Total assets |  |  | 3,594,671 |  |  |  | 3,560,933 |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Short-term debt, including current portion of long-term debt |  | $ | 649,975 |  |  | $ | 249,975 |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Accounts payable |  |  | 351,819 |  |  |  | 329,866 |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Current liabilities held for sale |  |  | — |  |  |  | 185,391 |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Total current liabilities |  |  | 1,197,457 |  |  |  | 946,666 |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Debt, net of discount |  |  | 832,834 |  |  |  | 1,225,962 |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Non-current liabilities held for sale |  |  | — |  |  |  | 1,530 |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Total long-term liabilities |  |  | 951,649 |  |  |  | 1,335,230 |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Total equity |  |  | 1,445,565 |  |  |  | 1,279,037 |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Total liabilities and equity |  |  | 3,594,671 |  |  |  | 3,560,933 |  |  |  |  |  |  |  |  |  |  |  |  |  |

[0001193125-20-203110:8k_2_02:47]
| SUPPLEMENTAL DATA |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | Second Quarter |  |  | First Quarter |  |  | First Two Quarters |  |
|  |  | 2020 |  |  | 2019 |  |  | 2020 |  |  | 2020 |  |  | 2019* |  |
| Gross margin |  |  | 17.6 | % |  |  | 17.6 | % |  |  | 16.3 | % |  |  | 17.0 | % |  |  | 18.0 | % |
| Operating margin |  |  | 4.0 | % |  |  | 5.5 | % |  |  | 3.3 | % |  |  | 3.7 | % |  |  | 5.6 | % |
| End Market Breakdown, including Mobility: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | Second Quarter |  |  | First Quarter |  |  |  |  |  |  |  |
|  |  | 2020 |  |  | 2019 |  |  | 2020 |  |  |  |  |  |  |  |
| Aerospace/Defense |  |  | 31 | % |  |  | 28 | % |  |  | 30 | % |  |  |  |  |  |  |  |  |
| Automotive |  |  | 12 | % |  |  | 16 | % |  |  | 12 | % |  |  |  |  |  |  |  |  |
| Cellular Phone |  |  | 3 | % |  |  | 6 | % |  |  | 11 | % |  |  |  |  |  |  |  |  |
| Computing/Storage/Peripherals |  |  | 13 | % |  |  | 15 | % |  |  | 14 | % |  |  |  |  |  |  |  |  |
| Medical/Industrial/Instrumentation |  |  | 20 | % |  |  | 15 | % |  |  | 16 | % |  |  |  |  |  |  |  |  |
| Networking/Communications |  |  | 19 | % |  |  | 17 | % |  |  | 14 | % |  |  |  |  |  |  |  |  |
| Other |  |  | 2 | % |  |  | 3 | % |  |  | 3 | % |  |  |  |  |  |  |  |  |

[0001193125-20-203110:8k_2_02:48]
| TTM Consolidated |  |  |  |  |  |  | Mobility Business Unit |  |
| End Markets |  | 1Q 19 |  |  | 2Q 19 |  |  | 3Q 19 |  |  | 4Q 19 |  |  | FY2019 |  |  | 1Q 20 |  |  | 2Q 20 |  |  |  |  |  | End Markets |  | 1Q 19 |  |  | 2Q 19 |  |  | 3Q 19 |  |  | 4Q 19 |  |  | FY2019 |  |  | 1Q 20 |  |  | 2Q 20 |  |
| Aerospace/Defense |  |  | 27 | % |  |  | 28 | % |  |  | 24 | % |  |  | 26 | % |  |  | 26 | % |  |  | 30 | % |  |  | 31 | % |  |  |  |  |  | Aerospace/Defense |  |  | 0 | % |  |  | 0 | % |  |  | 0 | % |  |  | 0 | % |  |  | 0 | % |  |  | 0 | % |  |  | 0 | % |
| Automotive |  |  | 17 | % |  |  | 16 | % |  |  | 17 | % |  |  | 14 | % |  |  | 16 | % |  |  | 12 | % |  |  | 12 | % |  |  |  |  |  | Automotive |  |  | 5 | % |  |  | 6 | % |  |  | 3 | % |  |  | 2 | % |  |  | 4 | % |  |  | 3 | % |  |  | 4 | % |
| Cellular Phones |  |  | 7 | % |  |  | 6 | % |  |  | 19 | % |  |  | 16 | % |  |  | 13 | % |  |  | 11 | % |  |  | 3 | % |  |  |  |  |  | Cellular Phones |  |  | 48 | % |  |  | 41 | % |  |  | 73 | % |  |  | 65 | % |  |  | 60 | % |  |  | 56 | % |  |  | 54 | % |
| Computing/Storage/Periph |  |  | 13 | % |  |  | 15 | % |  |  | 12 | % |  |  | 14 | % |  |  | 13 | % |  |  | 14 | % |  |  | 13 | % |  |  |  |  |  | Computing/Storage/Periph |  |  | 28 | % |  |  | 36 | % |  |  | 14 | % |  |  | 19 | % |  |  | 22 | % |  |  | 22 | % |  |  | 25 | % |
| Medical/Industrial/Inst |  |  | 15 | % |  |  | 15 | % |  |  | 13 | % |  |  | 13 | % |  |  | 14 | % |  |  | 16 | % |  |  | 20 | % |  |  |  |  |  | Medical/Industrial/Inst |  |  | 7 | % |  |  | 5 | % |  |  | 2 | % |  |  | 3 | % |  |  | 4 | % |  |  | 3 | % |  |  | 4 | % |
| Networking/Communications |  |  | 18 | % |  |  | 17 | % |  |  | 13 | % |  |  | 15 | % |  |  | 15 | % |  |  | 14 | % |  |  | 19 | % |  |  |  |  |  | Networking/Communications |  |  | 5 | % |  |  | 5 | % |  |  | 4 | % |  |  | 6 | % |  |  | 5 | % |  |  | 6 | % |  |  | 5 | % |
| Other |  |  | 3 | % |  |  | 3 | % |  |  | 2 | % |  |  | 2 | % |  |  | 3 | % |  |  | 3 | % |  |  | 2 | % |  |  |  |  |  | Other |  |  | 7 | % |  |  | 7 | % |  |  | 4 | % |  |  | 5 | % |  |  | 5 | % |  |  | 10 | % |  |  | 8 | % |
| SZ + SH-EMS |  |  |  |  |  |  | TTM, excluding Mobility, SZ & SH E-MS |  |
| End Markets |  | 1Q 19 |  |  | 2Q 19 |  |  | 3Q 19 |  |  | 4Q 19 |  |  | FY2019 |  |  | 1Q 20 |  |  | 2Q 20 |  |  |  |  |  | End Markets |  | 1Q 19 |  |  | 2Q 19 |  |  | 3Q 19 |  |  | 4Q 19 |  |  | FY2019 |  |  | 1Q 20 |  |  | 2Q 20 |  |
| Aerospace/Defense |  |  | 0 | % |  |  | 1 | % |  |  | 0 | % |  |  | 0 | % |  |  | 0 | % |  |  | 0 | % |  |  | 0 | % |  |  |  |  |  | Aerospace/Defense |  |  | 33 | % |  |  | 36 | % |  |  | 36 | % |  |  | 37 | % |  |  | 35 | % |  |  | 38 | % |  |  | 33 | % |
| Automotive |  |  | 56 | % |  |  | 58 | % |  |  | 74 | % |  |  | 59 | % |  |  | 63 | % |  |  | 49 | % |  |  | 54 | % |  |  |  |  |  | Automotive |  |  | 17 | % |  |  | 15 | % |  |  | 15 | % |  |  | 15 | % |  |  | 15 | % |  |  | 13 | % |  |  | 11 | % |
| Cellular Phones |  |  | 0 | % |  |  | 0 | % |  |  | 0 | % |  |  | 0 | % |  |  | 0 | % |  |  | 0 | % |  |  | 0 | % |  |  |  |  |  | Cellular Phones |  |  | 0 | % |  |  | -1 | % |  |  | 1 | % |  |  | 0 | % |  |  | 0 | % |  |  | 1 | % |  |  | 0 | % |
| Computing/Storage/Periph |  |  | 0 | % |  |  | 0 | % |  |  | 0 | % |  |  | 0 | % |  |  | 0 | % |  |  | 0 | % |  |  | 0 | % |  |  |  |  |  | Computing/Storage/Periph |  |  | 12 | % |  |  | 12 | % |  |  | 12 | % |  |  | 13 | % |  |  | 12 | % |  |  | 12 | % |  |  | 13 | % |
| Medical/Industrial/Inst |  |  | 22 | % |  |  | 23 | % |  |  | 11 | % |  |  | 19 | % |  |  | 18 | % |  |  | 23 | % |  |  | 14 | % |  |  |  |  |  | Medical/Industrial/Inst |  |  | 16 | % |  |  | 17 | % |  |  | 18 | % |  |  | 17 | % |  |  | 17 | % |  |  | 18 | % |  |  | 21 | % |
| Networking/Communications |  |  | 21 | % |  |  | 18 | % |  |  | 16 | % |  |  | 22 | % |  |  | 19 | % |  |  | 29 | % |  |  | 35 | % |  |  |  |  |  | Networking/Communications |  |  | 20 | % |  |  | 19 | % |  |  | 16 | % |  |  | 17 | % |  |  | 18 | % |  |  | 16 | % |  |  | 19 | % |
| Other |  |  | 1 | % |  |  | 0 | % |  |  | -1 | % |  |  | 0 | % |  |  | 0 | % |  |  | -1 | % |  |  | -3 | % |  |  |  |  |  | Other |  |  | 2 | % |  |  | 2 | % |  |  | 2 | % |  |  | 1 | % |  |  | 3 | % |  |  | 2 | % |  |  | 3 | % |

[0001193125-20-203110:8k_2_02:49]
| Stock-based Compensation, including Mobility: |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | Second Quarter |  |  | First Quarter |  |
|  |  | 2020 |  |  | 2019 |  |  | 2020 |  |
| Amount included in: |  |  |  |  |  |  |  |  |  |  |  |  |
| Cost of goods sold |  | $ | 620 |  |  | $ | 569 |  |  | $ | 850 |  |
| Selling and marketing |  |  | 291 |  |  |  | 383 |  |  |  | 451 |  |
| General and administrative |  |  | 1,690 |  |  |  | 2,611 |  |  |  | 3,477 |  |
| Research & Development |  |  | 46 |  |  |  | 39 |  |  |  | 57 |  |
| Total stock-based compensation expense |  | $ | 2,647 |  |  | $ | 3,602 |  |  | $ | 4,835 |  |
| Operating Segment Data: |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | Second Quarter |  |  | First Quarter |  |
| Net sales: |  |  | 2020 |  |  |  | 2019 |  |  |  | 2020 |  |
| PCB |  | $ | 520,067 |  |  | $ | 466,960 |  |  | $ | 467,430 |  |
| E-M Solutions |  |  | 50,231 |  |  |  | 59,917 |  |  |  | 30,216 |  |
| Total net sales |  | $ | 570,298 |  |  |  | 526,877 |  |  |  | 497,646 |  |
| Operating segment income: |  |  |  |  |  |  |  |  |  |  |  |  |
| PCB |  | $ | 80,056 |  |  | $ | 62,463 |  |  | $ | 61,626 |  |
| E-M Solutions |  |  | (15,577 | ) |  |  | 863 |  |  |  | (4,329 | ) |
| Corporate |  |  | (30,538 | ) |  |  | (22,561 | ) |  |  | (30,170 | ) |
| Total operating segment income |  |  | 33,941 |  |  |  | 40,765 |  |  |  | 27,127 |  |
| Amortization of definite-lived intangibles |  |  | (10,945 | ) |  |  | (11,773 | ) |  |  | (10,945 | ) |
| Total operating income |  |  | 22,996 |  |  |  | 28,992 |  |  |  | 16,182 |  |
| Total other expense |  |  | (18,117 | ) |  |  | (17,546 | ) |  |  | (17,279 | ) |
| Income (Loss) from continuing operations before income taxes |  | $ | 4,879 |  |  | $ | 11,446 |  |  | $ | (1,097 | ) |

[0001193125-20-203110:8k_2_02:50]
RECONCILIATIONS1

[0001193125-20-203110:8k_2_02:51]
|  |  | GAAPDecember 30, 2019 |  |  | Mobility balancesDecember 30, 20192 |  |  | CombinedDecember 30, 2019 |  |
| Cash and cash equivalents, including restricted cash |  | $ | 379,818 |  |  | $ | 20,336 |  |  | $ | 400,154 |  |
| Accounts and notes receivable, net |  |  | 503,598 |  |  |  | 66 |  |  |  | 503,664 |  |
| Contract assets |  |  | 254,600 |  |  |  | 33,635 |  |  |  | 288,235 |  |
| Inventories |  |  | 113,753 |  |  |  | 8,266 |  |  |  | 122,019 |  |
| Current assets held for sale |  |  | 67,572 |  |  |  | (67,572 | ) |  |  | — |  |
| Total current assets |  |  | 1,342,684 |  |  |  | — |  |  |  | 1,342,684 |  |
| Property, plant and equipment, net |  |  | 678,201 |  |  |  | 344,728 |  |  |  | 1,022,929 |  |
| Operating lease right of use asset |  |  | 22,173 |  |  |  | 1,983 |  |  |  | 24,156 |  |
| Non-current assets held for sale |  |  | 425,597 |  |  |  | (425,597 | ) |  |  | — |  |
| Other non-current assets |  |  | 1,092,278 |  |  |  | 78,886 |  |  |  | 1,171,164 |  |
| Total assets |  |  | 3,560,933 |  |  |  | — |  |  |  | 3,560,933 |  |
| Short-term debt, including current portion of long-term debt |  | $ | 249,975 |  |  | $ | — |  |  | $ | 249,975 |  |
| Accounts payable |  |  | 329,866 |  |  |  | 153,700 |  |  |  | 483,566 |  |
| Current liabilities held for sale |  |  | 185,391 |  |  |  | (185,391 | ) |  |  | — |  |
| Total current liabilities |  |  | 946,666 |  |  |  | — |  |  |  | 946,666 |  |
| Debt, net of discount |  |  | 1,225,962 |  |  |  | — |  |  |  | 1,225,962 |  |
| Non-current liabilities held for sale |  |  | 1,530 |  |  |  | (1,530 | ) |  |  | — |  |
| Total long-term liabilities |  |  | 1,335,230 |  |  |  | — |  |  |  | 1,335,230 |  |
| Total equity |  |  | 1,279,037 |  |  |  | — |  |  |  | 1,279,037 |  |
| Total liabilities and equity |  |  | 3,560,933 |  |  |  | — |  |  |  | 3,560,933 |  |

[0001193125-20-203110:8k_2_02:52]
|  |  | Second Quarter |  |  | First Quarter |  |  | First Two Quarters |  |
|  |  | 2020 |  |  | 2019 |  |  | 2020 |  |  | 2020 |  |  | 2019* |  |
| Non-GAAP revenue reconciliation3: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| GAAP revenue |  | $ | 570,298 |  |  | $ | 526,877 |  |  | $ | 497,646 |  |  | $ | 1,067,944 |  |  | $ | 1,063,322 |  |
| Revenue from discontinued operations |  |  | 30,777 |  |  |  | 106,161 |  |  |  | 113,174 |  |  |  | 143,951 |  |  |  | 189,916 |  |
| Non-GAAP revenue |  | $ | 601,075 |  |  | $ | 633,038 |  |  | $ | 610,820 |  |  | $ | 1,211,895 |  |  | $ | 1,253,238 |  |
| Non-GAAP gross profit reconciliation4: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| GAAP gross profit |  | $ | 100,430 |  |  | $ | 92,848 |  |  | $ | 81,342 |  |  | $ | 181,772 |  |  | $ | 191,674 |  |
| Gross profit from discontinued operations |  |  | 2,402 |  |  |  | (8,233 | ) |  |  | 4,749 |  |  |  | 7,151 |  |  |  | (18,374 | ) |
| Add back item: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of definite-lived intangibles |  |  | 1,384 |  |  |  | 1,180 |  |  |  | 1,383 |  |  |  | 2,767 |  |  |  | 2,359 |  |
| Accelerated Depreciation |  |  | 2,397 |  |  |  | — |  |  |  | — |  |  |  | 2,397 |  |  |  | — |  |
| Stock-based compensation |  |  | 620 |  |  |  | 569 |  |  |  | 850 |  |  |  | 1,470 |  |  |  | 1,275 |  |
| Non-GAAP gross profit |  | $ | 107,233 |  |  | $ | 86,364 |  |  | $ | 88,324 |  |  | $ | 195,557 |  |  | $ | 176,934 |  |
| Non-GAAP gross margin |  |  | 17.8 | % |  |  | 13.6 | % |  |  | 14.5 | % |  |  | 16.1 | % |  |  | 14.1 | % |
| Non-GAAP operating income reconciliation5: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| GAAP operating income |  | $ | 22,996 |  |  | $ | 28,992 |  |  | $ | 16,182 |  |  | $ | 39,178 |  |  | $ | 59,108 |  |
| Operating income (loss) from discontinued operations |  |  | 976 |  |  |  | (12,148 | ) |  |  | 1,441 |  |  |  | 2,417 |  |  |  | (24,774 | ) |
| Add back items: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of definite-lived intangibles |  |  | 11,079 |  |  |  | 12,447 |  |  |  | 11,620 |  |  |  | 22,699 |  |  |  | 30,452 |  |
| Accelerated Depreciation |  |  | 2,754 |  |  |  | — |  |  |  | — |  |  |  | 2,754 |  |  |  | — |  |
| Stock-based compensation |  |  | 2,647 |  |  |  | 3,602 |  |  |  | 4,835 |  |  |  | 7,482 |  |  |  | 7,528 |  |
| Restructuring, acquisition-related, and other charges |  |  | 14,273 |  |  |  | 4,351 |  |  |  | 1,596 |  |  |  | 15,869 |  |  |  | 5,454 |  |
| Non-GAAP operating income |  | $ | 54,725 |  |  | $ | 37,244 |  |  | $ | 35,674 |  |  | $ | 90,399 |  |  | $ | 77,768 |  |
| Non-GAAP operating margin |  |  | 9.1 | % |  |  | 5.9 | % |  |  | 5.8 | % |  |  | 7.5 | % |  |  | 6.2 | % |
| Non-GAAP net income and EPS reconciliation6: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| GAAP net income (loss) |  | $ | 9,346 |  |  | $ | 12,493 |  |  |  | (3,220 | ) |  | $ | 6,126 |  |  | $ | 18,731 |  |
| Net income (loss) from discontinued operations |  |  | 183,464 |  |  |  | (9,069 | ) |  |  | 2,046 |  |  |  | 185,510 |  |  |  | (18,559 | ) |
| Add back items: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of definite-lived intangibles |  |  | 11,079 |  |  |  | 12,447 |  |  |  | 11,620 |  |  |  | 22,699 |  |  |  | 30,452 |  |
| Accelerated Depreciation |  |  | 2,754 |  |  |  | — |  |  |  | — |  |  |  | 2,754 |  |  |  | — |  |
| Gain on sales of the Mobility business unit |  |  | (248,863 | ) |  |  | — |  |  |  | — |  |  |  | (248,863 | ) |  |  | — |  |
| Stock-based compensation |  |  | 2,647 |  |  |  | 3,602 |  |  |  | 4,835 |  |  |  | 7,482 |  |  |  | 7,528 |  |
| Non-cash interest expense |  |  | 3,604 |  |  |  | 3,467 |  |  |  | 3,553 |  |  |  | 7,157 |  |  |  | 7,335 |  |
| (Gain) on sale of assets |  |  | (274 | ) |  |  | (235 | ) |  |  | (233 | ) |  |  | (507 | ) |  |  | (3,306 | ) |
| Restructuring, acquisition-related, and other charges |  |  | 13,969 |  |  |  | 4,351 |  |  |  | 1,596 |  |  |  | 15,565 |  |  |  | 5,454 |  |
| Income taxes7 |  |  | 55,613 |  |  |  | (5,789 | ) |  |  | (593 | ) |  |  | 55,020 |  |  |  | (9,939 | ) |
| Non-GAAP net income |  | $ | 33,339 |  |  | $ | 21,267 |  |  | $ | 19,604 |  |  | $ | 52,943 |  |  | $ | 37,696 |  |
| Non-GAAP earnings per diluted share |  | $ | 0.31 |  |  | $ | 0.20 |  |  | $ | 0.18 |  |  | $ | 0.49 |  |  | $ | 0.36 |  |
| Non-GAAP diluted number of shares8: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Diluted shares |  |  | 107,485 |  |  |  | 132,045 |  |  |  | 107,378 |  |  |  | 107,431 |  |  |  | 105,860 |  |
| Dilutive effect of convertible debt |  |  | — |  |  |  | (25,938 | ) |  |  | — |  |  |  | — |  |  |  | — |  |
| Non-GAAP diluted number of shares |  |  | 107,485 |  |  |  | 106,107 |  |  |  | 107,378 |  |  |  | 107,431 |  |  |  | 105,860 |  |
| Adjusted EBITDA reconciliation9: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| GAAP net income (loss) |  | $ | 9,346 |  |  | $ | 12,493 |  |  | $ | (3,220 | ) |  | $ | 6,126 |  |  | $ | 18,731 |  |
| Net income (loss) from discontinued operations |  |  | 183,464 |  |  |  | (9,069 | ) |  |  | 2,046 |  |  | $ | 185,510 |  |  | $ | (18,559 | ) |
| Add back items: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Income tax provision (benefit) |  |  | 61,498 |  |  |  | (2,829 | ) |  |  | 2,865 |  |  |  | 64,363 |  |  |  | (4,306 | ) |
| Interest expense |  |  | 18,572 |  |  |  | 20,871 |  |  |  | 20,004 |  |  |  | 38,576 |  |  |  | 42,559 |  |
| Amortization of definite-lived intangibles |  |  | 11,079 |  |  |  | 12,447 |  |  |  | 11,620 |  |  |  | 22,699 |  |  |  | 30,452 |  |
| Gain on sales of the Mobility business unit |  |  | (248,863 | ) |  |  | — |  |  |  | — |  |  |  | (248,863 | ) |  |  | — |  |
| Depreciation expense |  |  | 28,871 |  |  |  | 41,235 |  |  |  | 42,632 |  |  |  | 71,503 |  |  |  | 82,837 |  |
| Stock-based compensation |  |  | 2,647 |  |  |  | 3,602 |  |  |  | 4,835 |  |  |  | 7,482 |  |  |  | 7,528 |  |
| (Gain) on sale of assets |  |  | (274 | ) |  |  | (235 | ) |  |  | (233 | ) |  |  | (507 | ) |  |  | (3,306 | ) |
| Restructuring, acquisition-related, and other charges |  |  | 13,969 |  |  |  | 4,351 |  |  |  | 1,596 |  |  |  | 15,565 |  |  |  | 5,454 |  |
| Adjusted EBITDA |  | $ | 80,309 |  |  | $ | 82,866 |  |  | $ | 82,145 |  |  | $ | 162,454 |  |  | $ | 161,390 |  |
| Adjusted EBITDA margin |  |  | 13.4 | % |  |  | 13.1 | % |  |  | 13.4 | % |  |  | 13.4 | % |  |  | 12.9 | % |
| Free cash flow reconciliation, including Mobility: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Operating cash flow |  |  | 118,996 |  |  |  | 86,123 |  |  |  | 27,913 |  |  |  | 146,909 |  |  |  | 123,047 |  |
| Capital expenditures, net |  |  | (22,370 | ) |  |  | (34,741 | ) |  |  | (32,451 | ) |  |  | (54,821 | ) |  |  | (63,187 | ) |
| Free cash flow |  | $ | 96,626 |  |  | $ | 51,382 |  |  | $ | (4,538 | ) |  | $ | 92,088 |  |  | $ | 59,860 |  |

[0001193125-20-203110:8k_2_02:53]
Select Non-GAAP income statement data

[0001193125-20-203110:8k_2_02:54]
| TTM Consolidated |  | Q1-19A |  |  | Q2-19A |  |  | Q3-19A |  |  | Q4-19A |  |  | FY 2019A |  |  | Q1-20A |  |  | Q2-20A |  |
| Sales |  |  | 620.2 |  |  |  | 633.0 |  |  |  | 716.8 |  |  |  | 719.3 |  |  |  | 2,689.3 |  |  |  | 610.8 |  |  |  | 601.1 |  |
| Gross Profit |  |  | 90.6 |  |  |  | 86.4 |  |  |  | 106.0 |  |  |  | 126.8 |  |  |  | 409.7 |  |  |  | 88.3 |  |  |  | 107.2 |  |
| Gross Margin |  |  | 14.6 | % |  |  | 13.6 | % |  |  | 14.8 | % |  |  | 17.6 | % |  |  | 15.2 | % |  |  | 14.5 | % |  |  | 17.8 | % |
| Op Income |  |  | 40.5 |  |  |  | 37.2 |  |  |  | 54.0 |  |  |  | 72.4 |  |  |  | 204.1 |  |  |  | 35.7 |  |  |  | 54.7 |  |
| Operating Margin |  |  | 6.5 | % |  |  | 5.9 | % |  |  | 7.5 | % |  |  | 10.1 | % |  |  | 7.6 | % |  |  | 5.8 | % |  |  | 9.1 | % |
| EBITDA |  |  | 78.5 |  |  |  | 82.9 |  |  |  | 103.5 |  |  |  | 111.3 |  |  |  | 376.2 |  |  |  | 82.1 |  |  |  | 80.3 |  |
| EBITDA % |  |  | 12.7 | % |  |  | 13.1 | % |  |  | 14.4 | % |  |  | 15.5 | % |  |  | 14.0 | % |  |  | 13.4 | % |  |  | 13.4 | % |
| Mobility |  | Q1-19A |  |  | Q2-19A |  |  | Q3-19A |  |  | Q4-19A |  |  | FY 2019A |  |  | Q1-20A |  |  | Q2-20A |  |
| Sales |  |  | 83.8 |  |  |  | 106.1 |  |  |  | 182.6 |  |  |  | 183.5 |  |  |  | 556.0 |  |  |  | 113.2 |  |  |  | 30.8 |  |
| Gross Profit |  |  | (10.1 | ) |  |  | (8.2 | ) |  |  | 18.6 |  |  |  | 24.3 |  |  |  | 24.5 |  |  |  | 4.7 |  |  |  | 2.4 |  |
| Gross Margin |  |  | -12.1 | % |  |  | -7.8 | % |  |  | 10.2 | % |  |  | 13.2 | % |  |  | 4.4 | % |  |  | 4.2 | % |  |  | 7.8 | % |
| Op Income |  |  | (11.9 | ) |  |  | (10.3 | ) |  |  | 15.9 |  |  |  | 21.0 |  |  |  | 14.7 |  |  |  | 2.1 |  |  |  | 1.1 |  |
| Operating Margin |  |  | -14.2 | % |  |  | -9.7 | % |  |  | 8.7 | % |  |  | 11.4 | % |  |  | 2.6 | % |  |  | 1.9 | % |  |  | 3.6 | % |
| EBITDA |  |  | 6.0 |  |  |  | 9.2 |  |  |  | 36.9 |  |  |  | 38.5 |  |  |  | 90.6 |  |  |  | 21.9 |  |  |  | 3.8 |  |
| EBITDA % |  |  | 7.2 | % |  |  | 8.7 | % |  |  | 20.2 | % |  |  | 21.0 | % |  |  | 16.3 | % |  |  | 19.3 | % |  |  | 12.3 | % |
| SZ + SH-EMS |  | Q1-19A |  |  | Q2-19A |  |  | Q3-19A |  |  | Q4-19A |  |  | FY 2019A |  |  | Q1-20A |  |  | Q2-20A |  |
| Sales |  |  | 36.0 |  |  |  | 40.9 |  |  |  | 54.5 |  |  |  | 29.8 |  |  |  | 161.2 |  |  |  | 14.2 |  |  |  | 21.4 |  |
| Gross Profit |  |  | 3.0 |  |  |  | 3.4 |  |  |  | 5.2 |  |  |  | 2.3 |  |  |  | 13.9 |  |  |  | (2.4 | ) |  |  | (0.3 | ) |
| Gross Margin |  |  | 8.3 | % |  |  | 8.3 | % |  |  | 9.5 | % |  |  | 7.7 | % |  |  | 8.6 | % |  |  | -16.7 | % |  |  | -1.4 | % |
| Op Income |  |  | 2.0 |  |  |  | 1.2 |  |  |  | 4.3 |  |  |  | 2.0 |  |  |  | 9.5 |  |  |  | (3.8 | ) |  |  | (0.8 | ) |
| Operating Margin |  |  | 5.6 | % |  |  | 2.9 | % |  |  | 7.9 | % |  |  | 6.7 | % |  |  | 5.9 | % |  |  | -26.8 | % |  |  | -3.8 | % |
| EBITDA |  |  | 2.5 |  |  |  | 3.1 |  |  |  | 7.1 |  |  |  | 2.0 |  |  |  | 14.7 |  |  |  | (3.6 | ) |  |  | 0.1 |  |
| EBITDA % |  |  | 6.9 | % |  |  | 7.6 | % |  |  | 13.0 | % |  |  | 6.7 | % |  |  | 9.1 | % |  |  | -25.4 | % |  |  | 0.4 | % |
| TTM Proforma Excluding Mobility, SZ & SH-EMS |  | Q1-19A |  |  | Q2-19A |  |  | Q3-19A |  |  | Q4-19A |  |  | FY 2019A |  |  | Q1-20A |  |  | Q2-20A |  |
| Sales |  |  | 500.4 |  |  |  | 486.0 |  |  |  | 479.7 |  |  |  | 506.0 |  |  |  | 1,972.1 |  |  |  | 483.4 |  |  |  | 548.9 |  |
| Gross Profit |  |  | 97.7 |  |  |  | 91.2 |  |  |  | 82.2 |  |  |  | 100.1 |  |  |  | 371.2 |  |  |  | 86.0 |  |  |  | 105.6 |  |
| Gross Margin |  |  | 19.5 | % |  |  | 18.8 | % |  |  | 17.1 | % |  |  | 19.8 | % |  |  | 18.8 | % |  |  | 17.8 | % |  |  | 19.2 | % |
| Op Income |  |  | 52.2 |  |  |  | 46.2 |  |  |  | 33.8 |  |  |  | 49.4 |  |  |  | 179.8 |  |  |  | 37.7 |  |  |  | 54.4 |  |
| OM |  |  | 10.4 | % |  |  | 9.5 | % |  |  | 7.0 | % |  |  | 9.8 | % |  |  | 9.1 | % |  |  | 7.8 | % |  |  | 9.9 | % |
| EBITDA |  |  | 70.0 |  |  |  | 70.6 |  |  |  | 59.5 |  |  |  | 70.5 |  |  |  | 270.5 |  |  |  | 63.5 |  |  |  | 76.4 |  |
| EBITDA % |  |  | 14.0 | % |  |  | 14.5 | % |  |  | 12.4 | % |  |  | 13.9 | % |  |  | 13.7 | % |  |  | 13.1 | % |  |  | 13.9 | % |

[0001193125-20-203110:8k_2_02:55]
| 1 | This information provides a reconciliation of non-GAAP balance sheet data to the financial information in our consolidated condensed balance sheet and non-GAAP revenue, non-GAAP gross profit, non-GAAP operating income, non-GAAP net income, non-GAAP EPS, and adjusted EBITDA to the financial information in our consolidated condensed statements of operations. |

[0001193125-20-203110:8k_2_02:56]
| 2 | Excludes the estimated gain on sale of Mobility. |

[0001193125-20-203110:8k_2_02:57]
| 3 | Non-GAAP revenue includes revenue from discontinued operations. |

[0001193125-20-203110:8k_2_02:58]
| 4 | Non-GAAP gross profit and gross margin measures include discontinued operations and exclude amortization of intangibles, accelerated depreciation due to the closure of two EM-Solutions plants, and stock-based compensation expense. |

[0001193125-20-203110:8k_2_02:59]
| 5 | Non-GAAP operating income and operating margin measures include discontinued operations and exclude amortization of intangibles, accelerated depreciation due to the closure of two EM-Solutions plants, stock-based compensation expense, gain on sale of assets, acquisition-related costs, restructuring and other charges. |

[0001193125-20-203110:8k_2_02:60]
| 6 | This information provides non-GAAP net income and non-GAAP EPS, which are non-GAAP financial measures. Management believes that both measures—which include discontinued operations and add back amortization of intangibles, accelerated depreciation due to the closure of two EM-Solutions plants, stock-based compensation expense, non-cash interest expense on debt (before consideration of capitalized interest), gain on sale of assets, acquisition-related costs, restructuring and other charges as well as the associated tax impact of these charges and discrete tax items—provide additional useful information to investors regarding the Company’s ongoing financial condition and results of operations. |

[0001193125-20-203110:8k_2_02:61]
| 7 | Income tax adjustments reflect the difference between income taxes based on a non-GAAP tax rate and a forecasted annual GAAP tax rate. |

[0001193125-20-203110:8k_2_02:62]
| 8 | Non-GAAP diluted number of shares used in computing non-GAAP earnings per share excludes the dilutive effect of convertible debt. |

[0001193125-20-203110:8k_2_02:63]
| 9 | Adjusted EBITDA is defined as earnings, including discontinued operations, before interest expense, income taxes, depreciation, amortization of intangibles, stock-based compensation expense, gain on sale of assets, acquisition-related costs, restructuring and other charges. We present adjusted EBITDA to enhance the understanding of our operating results, and it is a key measure we use to evaluate our operations. In addition, we provide our adjusted EBITDA because we believe that investors and securities analysts will find adjusted EBITDA to be a useful measure for evaluating our operating performance and comparing our operating performance with that of similar companies that have different capital structures and for evaluating our ability to meet our future debt service, capital expenditures, and working capital requirements. However, adjusted EBITDA should not be considered as an alternative to cash flows from operating activities as a measure of liquidity or as an alternative to net income as a measure of operating results in accordance with accounting principles generally accepted in the United States of America. |
