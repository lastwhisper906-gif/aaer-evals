# TTMI notes — 0000950170-25-024839


## dei:DocumentsIncorporatedByReferenceTextBlock

[0000950170-25-024839:notes:1]
Portions of the registrant’s definitive Proxy Statement for its 2025 Annual Meeting of Stockholders will be incorporated by reference into Part III of this Annual Report on Form 10-K. Such Proxy Statement, or an amendment to this Report, will be filed with the Securities and Exchange Commission within 120 days after the end of the fiscal year to which this Report relates.


## cyd:CybersecurityRiskManagementProcessesForAssessingIdentifyingAndManagingThreatsTextBlock

[0000950170-25-024839:notes:2]
ITEM 1C. CYBERSECURITY

[0000950170-25-024839:notes:3]
We depend on information systems and technology in substantially all aspects of our business, including communications among our employees and with suppliers and customers. Such uses of information systems and technology give rise to cybersecurity risks, including system disruption, security breach, ransomware, theft, espionage, and inadvertent release of information. Our business involves the storage and transmission of numerous classes of sensitive and/or confidential information and intellectual property, including customers’ and suppliers’ information, private information about employees, and financial and strategic information about the company and its business partners. Further, as we pursue new initiatives that improve our operations and cost structure, we are also expanding and improving our information technologies, resulting in a larger technological presence and increased exposure to cybersecurity risk. If we fail to properly assess and identify cybersecurity risks, we may become increasingly vulnerable to such risks.

[0000950170-25-024839:notes:4]
Cybersecurity risk management and strategy

[0000950170-25-024839:notes:5]
We assess and identify security risk to the organization by:

[0000950170-25-024839:notes:6]
•
conducting assessments of risk including likelihood and magnitude from unauthorized access, use, disclosure, disruption, modification, or destruction of information systems and the related information processes, stored, or transmitted;

[0000950170-25-024839:notes:7]
•
performing risk assessments and producing security assessment reports that document the results of the assessment for use and review by IT senior leadership, including the Company’s Senior Vice President of Information Technology (SVP-IT);

[0000950170-25-024839:notes:8]
•
ensuring security controls are assessed for effectiveness, are implemented correctly, operating as intended, and producing the desired outcome; and

[0000950170-25-024839:notes:9]
•
periodically scanning for vulnerabilities and remedying all vulnerabilities in accordance with the associated risk.

[0000950170-25-024839:notes:10]
We have established a continuous monitoring strategy and program, which includes:

[0000950170-25-024839:notes:11]
•
a set of defined security metrics to be monitored;

[0000950170-25-024839:notes:12]
•
performance of security control assessments on an ongoing basis;

[0000950170-25-024839:notes:13]
•
addressing results of analysis and reporting security status to the executive team; and

[0000950170-25-024839:notes:14]
•
monitoring information systems to detect attacks and indicators of potential attacks.

[0000950170-25-024839:notes:15]
Other processes in place to further manage any additional security risk to the organization include:

[0000950170-25-024839:notes:16]
•
identifying, reporting, and correcting information system flaws, security alerts, and advisories;

[0000950170-25-024839:notes:17]
•
monitoring inbound and outbound communications for unusual or unauthorized activity;

[0000950170-25-024839:notes:18]
•
designing and implementing application systems to include sound backup and recoverability principles, such as periodic data backups in the case of a disaster;

[0000950170-25-024839:notes:19]
•
mechanisms designed for the physical protection of IT resources; and

[0000950170-25-024839:notes:20]
•
use of all third-party and cloud computing services are reviewed and evaluated for material risks of cybersecurity threats by the IT security department before being formally authorized for use. Use of services must comply with all laws and regulations governing the handling of personally identifiable information, corporate financial data, controlled unclassified information, or any other data owned or collected by the company.

[0000950170-25-024839:notes:21]
Our cybersecurity incident management plan includes the following, among other things:

[0000950170-25-024839:notes:22]
•
The SVP-IT leads the team in the development, documentation, review and testing of security procedures, and incident response procedures. Beyond initial creation, procedures are continually re-assessed, augmented, updated, and tested on an ongoing basis;

[0000950170-25-024839:notes:23]
•
The SVP-IT works with the Executive Team on the identification, assessment, verification, and classification of incidents to determine affected stakeholders and appropriate parties for contact;

[0000950170-25-024839:notes:24]
•
The SVP-IT is responsible for launching the Cybersecurity Incident Response Team (CIRT) if necessary, and for notification to the Chief Executive Officer, who in turn will contact the Board of Directors and Government Security Committee in order to validate the response is being addressed appropriately.

[0000950170-25-024839:notes:25]
•
The CIRT team, in consultation with outside experts if needed, is responsible for the following:

[0000950170-25-024839:notes:26]
o
Initial containment;

[0000950170-25-024839:notes:27]
o
Analysis to establish root cause of incidents, identification and evidence collection;

[0000950170-25-024839:notes:28]
o
Incident containment by further analyzing additional information and further identifying any additional compromised machines or resources not previously identified;

[0000950170-25-024839:notes:29]
o
Implementing solutions designed to solve underlying problems and prevent re-occurrence;

[0000950170-25-024839:notes:30]
o
Recovery and restoring normal business functionality;

[0000950170-25-024839:notes:31]
o
Review after closure of each incident and conducting a post-mortem analysis to improve prevention and help to make incident response processes more efficient and effective. Also, the CIRT evaluates competency and any additional training requirements needed.

[0000950170-25-024839:notes:32]
While we have experienced cybersecurity incidents in the past, to date none have materially affected us or our business strategy, results of operations, financial condition and/or cash flows. Moreover, we have not identified any risks from cybersecurity threats that have materially affected or are reasonably likely to materially affect our business strategy, results of operations, financial condition and/or cash flows. See Item 1A, Risk Factors above for more information. While we continually work to safeguard the information systems we use, and the proprietary, confidential, and personal information residing therein, and mitigate potential risks, there can be no assurance that such actions will be sufficient to prevent cybersecurity incidents or mitigate all potential risks to such systems, networks, and data or those of our third-party providers.

[0000950170-25-024839:notes:33]
Governance

[0000950170-25-024839:notes:34]
We have invested in robust data security and privacy protections. We follow industry-standard recommendations for data security such as those outlined in the National Institute of Standards and Technology (NIST) Special Publication 800-171 and evolving Cybersecurity Maturity Model Certification (CMMC) frameworks. We have developed cybersecurity policies and procedures, including a data classification system to ensure the protection of critical data. In addition to periodic internal review, we also employ external auditors as needed, and cybersecurity testing firms to review our cybersecurity posture.

[0000950170-25-024839:notes:35]
We maintain a CIRT, whose responsibilities are described above. We conduct periodic tests with this team to maintain readiness and resiliency while regularly reviewing its policies in the interest of protecting data security. External companies or agencies may be called upon to provide consulting, guidance, assistance, or some other form of support in response to a cybersecurity incident. The regular training of employees, at least annually, on the ever-present threat of cybersecurity helps maintain data security.

[0000950170-25-024839:notes:36]
Our Board of Directors receives an update from our SVP-IT twice per year. In addition, our Government Security Committee of the Board of Directors is responsible for reviewing Cybersecurity Posture and overall resilience of the aerospace and defense portion of the network. The Government Security Committee reviews global cybersecurity risk with the SVP-IT at least four times a year. These reviews included standard cybersecurity-related metrics as well as other detailed reviews of sensitive systems. Our SVP-IT has over 25 years of experience in IT, which include various leadership roles at other large corporations and holds an Executive Master in Cybersecurity degree from Brown University.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureAndSignificantAccountingPoliciesTextBlock

[0000950170-25-024839:notes:37]
(1)
Nature of Operations and Summary of Significant Accounting Policies

[0000950170-25-024839:notes:38]
Nature of Operations

[0000950170-25-024839:notes:39]
TTM Technologies, Inc. (the Company or TTM) is a leading global manufacturer of technology solutions including mission systems, radio frequency (RF) components, RF microwave/microelectronic assemblies, and quick-turn and technologically advanced printed circuit boards (PCB). The Company provides time-to-market and volume production of advanced technology products and offers a one-stop design, engineering, and manufacturing solution to customers. This solution allows the Company to align technology developments with the diverse needs of the Company’s customers and to enable them to reduce the time required to develop new products and bring them to market.

[0000950170-25-024839:notes:40]
The Company serves a diversified customer base in various markets throughout the world, including aerospace and defense, data center computing, automotive, medical, industrial, and instrumentation, and networking. The Company’s customers include original equipment manufacturers (OEMs), electronic manufacturing services (EMS) providers, original design manufacturers (ODMs), distributors, and government agencies (both domestic and allied foreign governments).

[0000950170-25-024839:notes:41]
The Company operates on a 52 or 53 week fiscal calendar with the fourth quarter ending on the Monday nearest December 31. Fiscal years 2024, 2023, and 2022 consisted of 52 weeks ended on December 30, 2024, January 1, 2024, and January 2, 2023, respectively. All references to years relate to fiscal years unless otherwise noted.

[0000950170-25-024839:notes:42]
Use of Estimates

[0000950170-25-024839:notes:43]
The preparation of financial statements in conformity with accounting principles generally accepted in the United States of America (U.S. GAAP) requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities and disclosure of contingent assets and liabilities at the date of the financial statements and the reported amount of revenues and expenses during the reporting period. These estimates and assumptions are based on management’s best estimates and judgment. Due, in part, to the conflict between Russia and Ukraine as well as other global regions, the global economy and financial markets have been volatile in recent years. As such, the Company has considered information available to it as of the date of issuance of these financial statements and is not aware of any specific events or circumstances that would require an update to its estimates or judgments, or a revision to the carrying value of its assets or liabilities. Management evaluates its estimates and assumptions on an ongoing basis using historical experience and other factors, including the economic environment, which management believes to be reasonable under the circumstances. Management adjusts such estimates and assumptions when facts and circumstances dictate. The actual results the Company experienced may differ materially and adversely from its estimates. To the extent there are material differences between the estimates and actual results, the Company’s future result of operations will be affected.

[0000950170-25-024839:notes:44]
Principles of Consolidation

[0000950170-25-024839:notes:45]
The consolidated financial statements include the accounts of TTM and its subsidiaries. All intercompany accounts and transactions have been eliminated in consolidation.

[0000950170-25-024839:notes:46]
Foreign Currency Translation and Transactions

[0000950170-25-024839:notes:47]
The functional currency of one of the Company’s subsidiaries is the Chinese Renminbi (RMB). Accordingly, assets and liabilities are translated into U.S. dollars using period-end exchange rates. Sales and expenses are translated at the average exchange rates in effect during the period. The resulting translation gains or losses are recorded as a component of accumulated other comprehensive loss in the consolidated statement of stockholders’ equity and the consolidated statement of comprehensive income. Net gains and losses resulting from foreign currency re-measurements and transactions are included in income as a component of other, net in the consolidated statements of operations and totaled $1,218 gain, $4,059 loss, and $12,756 gain for the years ended December 30, 2024, January 1, 2024, and January 2, 2023, respectively.

[0000950170-25-024839:notes:48]
Cash Equivalents

[0000950170-25-024839:notes:49]
The Company considers highly liquid investments with insignificant interest rate risk and original maturities to the Company of three months or less to be cash equivalents.

[0000950170-25-024839:notes:50]
Accounts Receivable and Allowance for Doubtful Accounts

[0000950170-25-024839:notes:51]
Accounts receivable are reflected at estimated net realizable value, do not bear interest and do not generally require collateral. The Company performs credit evaluations of its customers and adjusts credit limits based upon payment history and the customer’s current creditworthiness. The Company maintains an allowance for doubtful accounts based upon a variety of factors. The Company considers both current and forecasted future economic conditions in determining the adequacy of its allowance for doubtful accounts.

[0000950170-25-024839:notes:52]
The Company’s allowance for doubtful accounts was $3,248 and $3,041 as of December 30, 2024 and January 1, 2024, respectively.

[0000950170-25-024839:notes:53]
Inventories

[0000950170-25-024839:notes:54]
Inventories are stated at the lower of cost (based on standard cost, which approximates first-in, first-out method) or net realizable value. Assessments to value the inventory at the lower of the actual cost to purchase and/or manufacture the inventory, or net realizable value of the inventory, are based upon assumptions about future demand and market conditions. As a result of the Company’s assessments, when the net realizable value of inventory is less than the carrying value, the inventory cost is written down to the net realizable value and the write down is recorded as a charge to cost of goods sold.

[0000950170-25-024839:notes:55]
Property, Plant, and Equipment, Net

[0000950170-25-024839:notes:56]
Property, plant, and equipment are recorded at cost. Depreciation expense is computed using the straight-line method over the estimated useful lives of the assets. Assets recorded under leasehold improvements are amortized using the straight-line method over the lesser of their useful lives or the related lease term. The Company uses the following estimated useful lives:

[0000950170-25-024839:notes:57]
| Land use rights |  | 50-99 years |
| Buildings and improvements |  | 7-50 years |
| Machinery and equipment |  | 3-10 years |
| Furniture and fixtures |  | 3-7 years |

[0000950170-25-024839:notes:58]
Upon retirement or other disposition of property, plant, and equipment, the cost and related accumulated depreciation are removed from the accounts. The resulting gain or loss is included in the determination of operating income in the period incurred. Depreciation expense on property, plant, and equipment was $105,233, $99,155, and $91,276 for the years ended December 30, 2024, January 1, 2024, and January 2, 2023, respectively.

[0000950170-25-024839:notes:59]
The Company capitalizes interest on borrowings during the active construction period of major capital projects. Capitalized interest is amortized over the average useful lives of such assets, which primarily consist of buildings and machinery and equipment. The Company capitalized interest costs of $4,006, $2,272, and $731 during the years ended December 30, 2024, January 1, 2024, and January 2, 2023, respectively, in connection with various capital projects.

[0000950170-25-024839:notes:60]
Major renewals and betterments are capitalized and depreciated over their estimated useful lives while minor expenditures for maintenance and repairs are included in operating income as incurred.

[0000950170-25-024839:notes:61]
Goodwill

[0000950170-25-024839:notes:62]
Goodwill represents the excess of purchase price of an acquisition over the fair value of net assets acquired. Goodwill is not amortized but instead is assessed for impairment, at a reporting unit level, annually and when events and circumstances warrant an evaluation. Goodwill is allocated to reporting units, which are operating segments or one level below the Company’s operating segments (the component level). Reporting units are determined by the discrete financial information available for the component and whether it is regularly reviewed by segment management. Components are aggregated into a single reporting unit if they share similar economic characteristics. The Company evaluates its goodwill on an annual basis in the fourth quarter or more frequently if it believes indicators of impairment exist. The Company assesses qualitative factors to determine whether it is more likely than not that the fair value of a reporting unit is less than its carrying amount or performs a quantitative impairment test. When tested quantitatively, the Company compares the fair value of the applicable reporting unit with its carrying value. In making this assessment, management relies on a number of factors, including expected future operating results, business plans, economic projections, anticipated future cash flows, business trends and declines in the Company’s market capitalization. The Company estimates the fair values of its reporting units using a combination of the discounted cash flow (DCF) and market approaches. If the carrying amount of a reporting unit exceeds the reporting unit’s fair value, the amount by which the carrying value exceeds the fair value is recognized as an impairment loss. See Note 6, Goodwill, for further details.

[0000950170-25-024839:notes:63]
Intangible Assets

[0000950170-25-024839:notes:64]
Intangible assets include customer relationships and technology, which are being amortized over their estimated useful lives on a straight-line basis. The estimated useful lives of such intangibles range from 5 years to 13 years.

[0000950170-25-024839:notes:65]
Impairment of Long-lived Assets

[0000950170-25-024839:notes:66]
Long-lived tangible assets, including property, plant, and equipment, assets held for sale, and definite-lived intangible assets, are reviewed for impairment whenever events or changes in circumstances indicate that the carrying value of the asset or asset groups may not be recoverable. The Company regularly evaluates whether events or circumstances have occurred that indicate possible impairment and relies on a number of factors, including expected future operating results, business plans, economic projections, and anticipated future cash flows. The Company uses an estimate of the future undiscounted net cash flows of the related asset or asset group over the remaining life in measuring whether the assets are recoverable. If the sum of the undiscounted cash flows is less than the carrying amount of the net assets, impairment is measured based on the difference between the net asset’s carrying value and estimated fair value. Fair value is determined through various valuation techniques, including cost-based, market, and income approaches as considered necessary.

[0000950170-25-024839:notes:67]
The Company classifies assets to be sold as assets held for sale when (1) Company management has approved and commits to a plan to sell the asset; (2) the asset is available for immediate sale in its present condition and is ready for sale; (3) an active program to locate a buyer and other actions required to sell the asset have been initiated; (4) the sale of the asset is probable; (5) the asset is being actively marketed for sale at a price that is reasonable in relation to its current fair value; and (6) it is unlikely that significant changes to the plan will be made or that the plan will be withdrawn. Assets classified as held for sale are recorded at the lower of the carrying amount or fair value less the cost to sell.

[0000950170-25-024839:notes:68]
The Company classifies assets held for use when a decision to dispose of an asset or a business is made and the held for sale criteria are not met. In evaluating the recoverability of property and intangible assets subject to amortization, in a held for use business, the carrying value is first compared to the sum of the undiscounted cash flows expected to result from the use and eventual disposition. If the carrying value exceeds the undiscounted expected cash flows, then a fair value analysis is performed. An impairment charge is recognized if the carrying value exceeds the fair value.

[0000950170-25-024839:notes:69]
Leases

[0000950170-25-024839:notes:70]
The Company determines if an arrangement is a lease at inception. Operating leases are included in operating lease right-of-use (ROU) assets, and lease liabilities are included in other current liabilities and operating lease liabilities on the consolidated balance sheets. Finance lease ROU assets are included in property, plant, and equipment, net and lease liabilities are included in other current liabilities and other long-term liabilities on the consolidated balance sheets.

[0000950170-25-024839:notes:71]
ROU assets represent the Company’s right to use an underlying asset for the lease term and lease liabilities represent the Company’s obligation to make lease payments arising from the lease. Operating and finance lease ROU assets and liabilities are recognized at commencement date based on the present value of lease payments over the lease term. As most of the Company’s leases do not provide an implicit rate, the Company uses its incremental borrowing rate based on the information available at the commencement date in determining the present value of lease payments. The operating and finance lease ROU assets also include any lease payments made and excludes lease incentives. Lease terms may include options to extend or terminate the lease when it is reasonably certain that the Company will exercise that option. Operating lease expense is recognized on a straight-line basis over the lease term. Finance lease expense is recognized based on the effective interest method over the lease term.

[0000950170-25-024839:notes:72]
The Company has lease agreements with lease and non-lease components and accounts for the lease and non-lease components as a single lease component.

[0000950170-25-024839:notes:73]
Revenue Recognition

[0000950170-25-024839:notes:74]
The Company derives revenues primarily from the sale of PCBs, engineered systems using customer-supplied engineering and design plans as well as long-term contracts related to the design and manufacture of highly sophisticated intelligence, surveillance, and communications solutions, RF and microwave/microelectronics components, assemblies, and subsystems. In the absence of a sales agreement, the Company’s standard terms and conditions apply. Revenue is recognized when control of the promised goods or services is transferred to the Company’s customers, in an amount that reflects the consideration to which it expects to be entitled in exchange for those goods or services. The Company applies a five-step approach in determining the amount and timing of revenue to be recognized: (1) identifying the contract with a customer; (2) identifying the performance obligations in the contract; (3) determining the transaction price; (4) allocating the transaction price to the performance obligations in the contract; and (5) recognizing revenue when the corresponding performance obligation is satisfied.

[0000950170-25-024839:notes:75]
Revenue Streams

[0000950170-25-024839:notes:76]
For PCBs and engineered systems, including pursuant to the Company’s long-term contracts related to the manufacture of highly sophisticated intelligence, surveillance, and communications solutions, components, assemblies, and subsystems, orders for products generally correspond to the production schedules of the Company’s customers and are supported with firm purchase orders. The Company’s customers have continuous control of the work in progress and finished goods throughout the PCB and engineered systems manufacturing process, as these are built to customer specifications with no alternative use, and there is an enforceable right to payment for work performed to date. As a result, the Company recognizes revenue progressively over time based on the extent of progress towards completion of the performance obligation. Revenue recognized is based on a cost method as it best depicts the transfer of control to the customer which takes place as we incur costs. Revenues are recorded proportionally as costs are incurred. For contracts in which anticipated total costs exceed the total expected revenue, an estimated loss is recognized in the period when identifiable. A provision for the entire amount of the estimated loss is recorded on a cumulative basis. The estimated remaining costs to complete for loss contracts as of December 30, 2024 and January 1, 2024 were $36,976 and $25,213, respectively, and the provision is recorded as a reduction to gross margin on the consolidated statements of operations.

[0000950170-25-024839:notes:77]
In addition, the Company manufactures components, assemblies, subsystems, and completed systems which service its RF and Specialty Components (RF&S Components) and certain aerospace and defense customers. The Company recognizes revenue at a point in time upon transfer of control of the products to the customer. Point in time recognition was determined as the customer does not simultaneously receive or consume the benefits provided by the Company’s performance and the asset being manufactured has alternative uses to the Company.

[0000950170-25-024839:notes:78]
Performance Obligations

[0000950170-25-024839:notes:79]
Each distinct promise to transfer products is considered to be an identified performance obligation for which revenue is recognized upon transfer of control of the products to the customer. A contract’s transaction price is allocated to each distinct performance obligation and recognized as revenue when, or as, the performance obligation is satisfied. The majority of the Company's contracts have a single performance obligation as the promise to transfer the individual good or service is not separately identifiable from other promises in the contract and is, therefore, not distinct. As of December 30, 2024, the aggregate amount of the transaction price allocated to remaining performance obligations for the Company’s long-term contracts was $452,793. The Company expects to recognize revenue on approximately 54% of the remaining performance obligations for the Company’s long‑term contracts over the next twelve months with the remaining amount recognized thereafter. The remaining performance obligations for the Company’s short‑term contracts are expected to be recognized within one year.

[0000950170-25-024839:notes:80]
Transaction Price

[0000950170-25-024839:notes:81]
The Company provides customers a limited right of return for defective PCBs including components, assemblies, and subsystems. Estimates of returns are treated as variable consideration for purposes of determining the transaction price. The Company accrues an estimate for sales returns and allowances progressively over time based on the extent of progress towards completion of the performance obligation using the Company’s judgment based on historical results and anticipated returns. To the extent actual experience varies from its historical experience, revisions to the sales returns and allowances accrual may be required. Sales returns and allowances are recorded as a reduction of revenue and included as a component of other current liabilities on the consolidated balance sheets. Shipping and handling fees and related freight costs and supplies associated with shipping products to customers are included as a component of cost of goods sold. Warranty-related services are not considered a separate performance obligation. Incremental warranty costs that are not related to sales returns are recorded in other current liabilities on the consolidated balance sheets and cost of goods sold on the consolidated statements of operations. The following summarizes the activity in the Company’s sales returns and allowances:

[0000950170-25-024839:notes:82]
|  |  | For the Year Ended |  |
|  |  | December 30, 2024 |  |  | January 1, 2024 |  |  | January 2, 2023 |  |
|  |  | (In thousands) |  |
| Balance at beginning of year |  | $ | 12,301 |  |  | $ | 12,319 |  |  | $ | 12,853 |  |
| Addition charged as a reduction of sales |  |  | 2,787 |  |  |  | 4,692 |  |  |  | 2,410 |  |
| Deductions |  |  | (4,281 | ) |  |  | (4,719 | ) |  |  | (2,914 | ) |
| Effect of foreign currency exchange rates |  |  | (30 | ) |  |  | 9 |  |  |  | (30 | ) |
| Balance at end of year |  | $ | 10,777 |  |  | $ | 12,301 |  |  | $ | 12,319 |  |

[0000950170-25-024839:notes:83]
Contract Balances

[0000950170-25-024839:notes:84]
Accounts receivable represents the Company’s unconditional right to receive consideration from its customer. Payments are generally due within 90 days or less of invoicing and do not include a significant financing component. To date, there have been no material credit losses on accounts receivable.

[0000950170-25-024839:notes:85]
A contract asset is recognized when the Company has recognized revenue, but not issued an invoice for payment. Amounts will be invoiced when applicable contract terms, such as the achievement of specified milestones or product delivery, are met. Contract assets represent unbilled amounts for work performed to date and are transferred to receivables when the entitlement to payment becomes unconditional. As of December 30, 2024, total contract assets were $386,817, of which $381,382 are expected to be collected within one year and recorded as contract assets and $5,435 are expected to be collected after one year and included as a component of deposits and other non-current assets on the consolidated balance sheets. As of January 1, 2024, total contract assets were $303,307, of which $292,050 were expected to be collected within one year and recorded as contract assets and $11,257 were expected to be collected after one year and included as a component of deposits and other non-current assets on the consolidated balance sheets. The increase in total contract assets in 2024 is primarily due to an increase in unbilled receivables. In 2024, there were no material impairment losses on contract assets.

[0000950170-25-024839:notes:86]
A contract liability is recognized when the Company has received payment in advance for the future transfer of goods or services. The Company’s contract liabilities are reduced as the contract requirements are fulfilled. Contract liabilities were $170,915 and $126,508 as of December 30, 2024 and January 1, 2024, respectively, and represent customer advances for work yet to be performed. The contract liabilities increased by $44,407 due to timing of customer billings and/or payments. Revenue recognized for the year ended December 30, 2024 from amounts recorded as contract liabilities as of January 1, 2024 was $37,457.

[0000950170-25-024839:notes:87]
The Company has elected to account for shipping and handling activities as a fulfillment cost as permitted by the standard. All incremental customer contract acquisition costs are expensed as they are incurred as the amortization period of the asset that the Company otherwise would have recognized is one year or less in duration.

[0000950170-25-024839:notes:88]
Disaggregated Revenue

[0000950170-25-024839:notes:89]
Revenue from products and services transferred to customers over time and at a point in time accounted for 96% and 4%, respectively, of the Company’s revenue in both 2024 and 2023. Revenue from products and services transferred to customers over time and at a point in time accounted for 97% and 3%, respectively, of the Company’s revenue in 2022.

[0000950170-25-024839:notes:90]
Disaggregated revenue by principal end markets within reportable segments was as follows for the periods shown:

[0000950170-25-024839:notes:91]
|  |  | For the Year Ended December 30, 2024 |  |
|  |  | PCB |  |  | RF&S Components |  |  | Total |  |
|  |  | (In thousands) |  |
| End Markets: |  |  |  |  |  |  |  |  |  |
| Aerospace and Defense |  | $ | 1,127,529 |  |  | $ | — |  |  | $ | 1,127,529 |  |
| Automotive |  |  | 315,924 |  |  |  | — |  |  |  | 315,924 |  |
| Data Center Computing |  |  | 502,258 |  |  |  | 619 |  |  |  | 502,877 |  |
| Medical/Industrial/Instrumentation |  |  | 333,276 |  |  |  | 2,809 |  |  |  | 336,085 |  |
| Networking |  |  | 126,628 |  |  |  | 33,710 |  |  |  | 160,338 |  |
| Total |  | $ | 2,405,615 |  |  | $ | 37,138 |  |  | $ | 2,442,753 |  |

[0000950170-25-024839:notes:92]
|  |  | For the Year Ended January 1, 2024 |  |
|  |  | PCB |  |  | RF&S Components |  |  | Total |  |
|  |  | (In thousands) |  |
| End Markets: |  |  |  |  |  |  |  |  |  |
| Aerospace and Defense |  | $ | 1,004,864 |  |  | $ | 18 |  |  | $ | 1,004,882 |  |
| Automotive |  |  | 359,455 |  |  |  | — |  |  |  | 359,455 |  |
| Data Center Computing |  |  | 318,769 |  |  |  | 51 |  |  |  | 318,820 |  |
| Medical/Industrial/Instrumentation |  |  | 365,611 |  |  |  | 3,448 |  |  |  | 369,059 |  |
| Networking |  |  | 145,347 |  |  |  | 35,004 |  |  |  | 180,351 |  |
| Total |  | $ | 2,194,046 |  |  | $ | 38,521 |  |  | $ | 2,232,567 |  |

[0000950170-25-024839:notes:93]
|  |  | For the Year Ended January 2, 2023 |  |
|  |  | PCB |  |  | RF&S Components |  |  | Total |  |
|  |  | (In thousands) |  |
| End Markets: |  |  |  |  |  |  |  |  |  |
| Aerospace and Defense |  | $ | 862,367 |  |  | $ | — |  |  | $ | 862,367 |  |
| Automotive |  |  | 428,022 |  |  |  | — |  |  |  | 428,022 |  |
| Data Center Computing |  |  | 378,114 |  |  |  | 34 |  |  |  | 378,148 |  |
| Medical/Industrial/Instrumentation |  |  | 486,088 |  |  |  | 5,708 |  |  |  | 491,796 |  |
| Networking |  |  | 278,911 |  |  |  | 52,414 |  |  |  | 331,325 |  |
| Other |  |  | 4,440 |  |  |  | (1,052 | ) |  |  | 3,388 |  |
| Total |  | $ | 2,437,942 |  |  | $ | 57,104 |  |  | $ | 2,495,046 |  |

[0000950170-25-024839:notes:94]
Value-Added and Sales Tax Collected from Customers

[0000950170-25-024839:notes:95]
As a part of the Company’s normal course of business, value-added and sales taxes are collected from customers. Such taxes collected are remitted, in a timely manner, to the appropriate governmental tax authority on behalf of the customer. Value-added and sales taxes are excluded from reported revenues and costs of goods sold presented in the consolidated statements of operations and comprehensive income (loss).

[0000950170-25-024839:notes:96]
Stock-Based Compensation

[0000950170-25-024839:notes:97]
The Company recognizes stock-based compensation expense in its consolidated financial statements for its incentive compensation plan awards. The incentive compensation plan awards include performance-based restricted stock units (PRUs), restricted stock units (RSUs), and stock options. The associated compensation expense for all awards is based on the grant date fair value of the awards. For PRUs, compensation expense also includes management’s periodic assessment of annual financial performance goals to be achieved. Compensation expense for the incentive compensation plan awards is recognized on a straight-line basis over the vesting period of the awards. The fair value of PRUs is estimated on the grant date using a Monte Carlo simulation model based on the underlying common stock closing price as of the date of grant, stock price volatility, and risk-free interest rates. The fair value of RSUs is measured on the grant date based on the quoted closing market price of the Company’s common stock.

[0000950170-25-024839:notes:98]
Income Taxes

[0000950170-25-024839:notes:99]
Income taxes are accounted for under the asset and liability method. Deferred income tax assets or liabilities are recognized for the future tax consequences attributable to differences between the financial statement carrying amounts of assets and liabilities and their respective tax bases and operating loss and tax credit carryforwards. Deferred income tax assets and liabilities are measured using enacted tax rates expected to apply to taxable income in the years in which those temporary differences are expected to be settled or realized. The effect on deferred income tax assets and liabilities of a change in tax rates is recognized in income in the period that includes the enactment date. Deferred income tax assets are reviewed for recoverability, and the Company records a valuation allowance to reduce its deferred income tax assets when it is more likely than not that all or some portion of the deferred income tax assets will not be realized.

[0000950170-25-024839:notes:100]
The Company has various foreign subsidiaries formed or acquired to conduct or support its business outside the United States. The Company expects its earnings attributable to foreign subsidiaries will not be indefinitely reinvested except for certain subsidiaries, and we have established a deferred tax liability for foreign withholding taxes and the estimated federal/state tax impact. For those other companies with earnings currently being reinvested outside of the U.S., no deferred tax liabilities on undistributed earnings are recorded.

[0000950170-25-024839:notes:101]
The Company recognizes the effect of income tax positions only if those positions are more likely than not to be sustained. Recognized income tax positions are measured at the largest amount that is greater than 50 percent likely to be realized. Changes in recognition or measurement are reflected in the period in which the change in judgment occurs. Estimated interest and penalties related to underpayment of income taxes are recorded as a component of income tax provision in the consolidated statements of operations.

[0000950170-25-024839:notes:102]
Fair Value Measures

[0000950170-25-024839:notes:103]
The Company measures at fair value certain of its financial and non-financial assets and liabilities by using a fair value hierarchy that prioritizes the inputs to valuation techniques used to measure fair value. Fair value is the price that would be received to sell an asset or paid to transfer a liability in an orderly transaction between market participants at the measurement date, essentially an exit price, based on the highest and best use of the asset or liability. The levels of the fair value hierarchy are:

[0000950170-25-024839:notes:104]
Level 1 — Quoted market prices in active markets for identical assets or liabilities;

[0000950170-25-024839:notes:105]
Level 2 — Significant other observable inputs (e.g., quoted prices for similar items in active markets, quoted prices for identical or similar items in markets that are not active, inputs other than quoted prices that are observable, such as interest rate and yield curves, and market-corroborated inputs); and

[0000950170-25-024839:notes:106]
Level 3 — Unobservable inputs in which there is little or no market data, which require the reporting unit to develop its own assumptions.

[0000950170-25-024839:notes:107]
Earnings (Loss) Per Share

[0000950170-25-024839:notes:108]
Basic earnings (loss) per common share excludes dilution and is computed by dividing net income (loss) by the weighted average number of common shares outstanding during the period. Diluted earnings (loss) per common share reflect the potential dilution that could occur if stock options, or other common stock equivalents were exercised or converted into common stock. The dilutive effect of stock options or other common stock equivalents is calculated using the treasury stock method.

[0000950170-25-024839:notes:109]
Comprehensive Income (Loss)

[0000950170-25-024839:notes:110]
Comprehensive income (loss) includes changes to equity accounts that were not the result of transactions with stockholders. Comprehensive income (loss) is comprised of net income (loss), changes in the cumulative foreign currency translation adjustments, pension obligation adjustments, and realized and unrealized gains or losses on hedged derivative instruments.

[0000950170-25-024839:notes:111]
Loss Contingencies

[0000950170-25-024839:notes:112]
The Company establishes an accrual for an estimated loss contingency when it is both probable that an asset has been impaired or that a liability has been incurred and the amount of the loss can be reasonably estimated. Any legal fees expected to be incurred in connection with a contingency are expensed as incurred.

[0000950170-25-024839:notes:113]
Recently Adopted and Issued Accounting Standards

[0000950170-25-024839:notes:114]
Recently Adopted Accounting Standards

[0000950170-25-024839:notes:115]
In November 2023, the Financial Accounting Standards Board (FASB) issued Accounting Standards Update (ASU) 2023-07, Segment Reporting (Topic 280): Improvements to Reportable Segment Disclosures, which updates reportable segment disclosure requirements primarily through enhanced disclosures about significant segment expenses. The amendments are effective for fiscal years beginning after December 15, 2023, and for interim periods within fiscal years beginning after December 15, 2024. Early adoption is permitted. The amendments should be applied retrospectively to all prior periods presented in the financial statements. The Company adopted ASU 2023-07 as of December 30, 2024 using a retrospective transition method. This ASU impacts only the Company's disclosures with no impacts to the results of operations, cash flows, and financial condition. See Note 10, Segment Information, for further details.

[0000950170-25-024839:notes:116]
Recently Issued Accounting Standards Not Yet Adopted

[0000950170-25-024839:notes:117]
In November 2024, the FASB issued ASU 2024-03, Income Statement-Reporting Comprehensive Income-Expense Disaggregation Disclosures (Subtopic 220-40): Disaggregation of Income Statement Expenses, which requires disclosure in the notes to the financial statements of specified information about certain costs and expenses. In January 2025, the FASB issued ASU 2025-01, Income Statement-Reporting Comprehensive Income-Expense Disaggregation Disclosures (Subtopic 220-40): Clarifying the Effective Date, which amends the effective date of ASU 2024-03 to clarify that all public business entities are required to adopt the guidance in annual reporting periods beginning after December 15, 2026, and interim periods within annual reporting periods beginning after December 15, 2027. Early adoption of ASU 2024-03 is permitted. ASU 2024-03 should be applied either prospectively to financial statements issued for reporting periods after the effective date or retrospectively to any or all prior periods presented in the financial statements. The Company is currently evaluating the new guidance to determine the impact it may have on its consolidated financial statements and related disclosures, but expects additional disclosures upon adoption.

[0000950170-25-024839:notes:118]
In December 2023, the FASB issued ASU 2023-09, Income Taxes (Topic 740): Improvements to Income Tax Disclosures, which requires disclosure of disaggregated income taxes paid, prescribes standard categories for the components of the effective tax rate reconciliation, and modifies other income tax-related disclosures. The update will be effective for annual periods beginning after December 15, 2024. Early adoption is permitted for annual financial statements not yet issued or made available for issuance. The Company is currently evaluating the new guidance to determine the impact it may have on its consolidated financial statements and related disclosures, but expects additional disclosures upon adoption.

[0000950170-25-024839:notes:119]
In October 2023, the FASB issued ASU 2023-06, Disclosure Improvements: Codification Amendments in Response to the Securities and Exchange Commission’s Disclosure Update and Simplification Initiative, which modifies the disclosure or presentation requirements of a variety of topics in the Accounting Standards Codification (ASC) in response to the Securities and Exchange Commission’s (SEC) Release No. 33-10532, Disclosure Update and Simplification Initiative, and align the ASC requirements with the

[0000950170-25-024839:notes:120]
SEC’s regulations. For entities subject to the SEC's existing disclosure requirements, the effective date for each amendment will be the date on which the SEC's removal of that related disclosure from Regulation S-X or Regulation S-K becomes effective. However, if by June 30, 2027, the SEC has not removed the related disclosure from its regulations, the amendments will be removed from the Codification and not become effective. Early adoption is prohibited. The Company is currently evaluating the new guidance to determine the impact it may have on the presentation of its consolidated financial statements and related disclosures.


## us-gaap:TreasuryStockTextBlock

[0000950170-25-024839:notes:121]
(2)
Share Repurchase Program

[0000950170-25-024839:notes:122]
On May 3, 2023, the Company's Board of Directors authorized and approved a share repurchase program (2023 Repurchase Program), under which the Company may repurchase up to $100,000 in value of the Company’s outstanding shares of common stock from time to time through May 3, 2025. The Company may repurchase shares through open market purchases, privately-negotiated transactions, or otherwise in accordance with applicable federal securities laws, including Rule 10b-18 of the Securities Exchange Act of 1934, as amended (Exchange Act), which sets certain restrictions on the method, timing, price, and volume of open market stock repurchases. In addition, the Company adopted one trading plan in accordance with Rule 10b5-1 of the Exchange Act to facilitate certain purchases that may be effected under the share repurchase program. The timing, manner, price, and amount of any repurchases will be determined at the Company’s discretion, and the share repurchase program may be suspended, terminated, or modified at any time for any reason. The repurchase program does not obligate the Company to acquire any specific number of shares.

[0000950170-25-024839:notes:123]
During the year ended December 30, 2024, the Company repurchased 1,990 shares of common stock for a total cost of approximately $34,479 (including commissions). As of December 30, 2024, the remaining amount in value available to be repurchased under the 2023 Repurchase Program was approximately $41,088.


## us-gaap:ConcentrationRiskDisclosureTextBlock

[0000950170-25-024839:notes:124]
(3)
Significant Customers and Concentration of Credit Risk

[0000950170-25-024839:notes:125]
Financial instruments that are potentially subject to concentrations of credit risk are primarily cash and cash equivalents and accounts receivable.

[0000950170-25-024839:notes:126]
The Company had cash and cash equivalents held by its foreign subsidiaries of $207,909 and $195,928 as of December 30, 2024 and January 1, 2024, respectively. The Company maintains its cash and cash equivalents with major financial institutions and such balances exceed Federal Deposit Insurance Corporation insurance limits. The Company has not experienced any losses in such accounts and believes it is not exposed to any significant risk on cash and cash equivalents.

[0000950170-25-024839:notes:127]
In the normal course of business, the Company extends credit to its customers. Some customers to whom the Company extends credit are located outside the United States. The Company performs ongoing credit evaluations of customers, does not require collateral, and considers the credit risk profile of the entity from which the receivable is due in further evaluating collection risk. As of December 30, 2024 and January 1, 2024, there were no customers that accounted for 10% or more of the Company’s accounts receivable.

[0000950170-25-024839:notes:128]
The Company’s customers include both OEMs and EMS companies. The Company’s OEM customers often direct a significant portion of their purchases through EMS companies. While the Company’s customers include both OEM and EMS providers, the Company measures customer concentration based on OEM companies, as they are the ultimate end customers.

[0000950170-25-024839:notes:129]
One customer accounted for approximately 11%, 13%, and 10% of the Company’s net sales for the years ended December 30, 2024, January 1, 2024, and January 2, 2023, respectively.


## us-gaap:LesseeOperatingLeasesTextBlock

[0000950170-25-024839:notes:130]
(4)
Leases

[0000950170-25-024839:notes:131]
The Company leases some of its manufacturing and assembly plants, sales offices, and equipment under non-cancellable operating leases and finance leases that expire at various dates through 2043. The majority of the Company’s lease arrangements are comprised of fixed payments, and certain leases consist of variable payments based on equipment usage. These variable payments are not included in the measurement of the ROU asset or lease liability due to uncertainty of the payment amount and are recorded as lease expense in the period incurred. Certain leases contain renewal provisions at the Company’s option. Most of the leases require the Company to pay for certain other costs such as property taxes and maintenance. Certain leases also contain rent escalation clauses (step rents) that require additional rental amounts in the later years of the term. Rent expense for leases with step rents is recognized on a straight-line basis over the minimum lease term. The lease agreements do not contain any material residual value guarantees or material restrictive covenants.

[0000950170-25-024839:notes:132]
The components of lease expense were as follows:

[0000950170-25-024839:notes:133]
|  |  | For the Year Ended |  |
|  |  | December 30, 2024 |  |  | January 1, 2024 |  |  | January 2, 2023 |  |
|  |  | (In thousands) |  |
| Operating lease cost |  | $ | 14,933 |  |  | $ | 9,527 |  |  | $ | 7,751 |  |
| Variable lease cost |  |  | 1,055 |  |  |  | 930 |  |  |  | 1,140 |  |
| Short-term lease cost |  |  | 409 |  |  |  | 311 |  |  |  | 708 |  |
| Finance lease costs: |  |  |  |  |  |  |  |  |  |
| Amortization of right-of-use assets |  |  | 1,372 |  |  |  | 1,374 |  |  |  | 1,374 |  |
| Interest on lease liabilities |  |  | 354 |  |  |  | 373 |  |  |  | 392 |  |

[0000950170-25-024839:notes:134]
Supplemental cash flow information related to leases was as follows:

[0000950170-25-024839:notes:135]
|  |  | For the Year Ended |  |
|  |  | December 30, 2024 |  |  | January 1, 2024 |  |  | January 2, 2023 |  |
|  |  | (In thousands) |  |
| Cash paid for amounts included in the measurement of lease liabilities: |  |  |  |  |  |  |  |  |  |
| Operating cash flows for operating leases |  | $ | 13,926 |  |  | $ | 9,039 |  |  | $ | 7,746 |  |
| Right-of-use assets obtained in exchange for new lease obligations: |  |  |  |  |  |  |  |  |  |
| Operating leases |  | $ | 2,796 |  |  | $ | 77,041 |  |  | $ | 7,896 |  |

[0000950170-25-024839:notes:136]
Supplemental balance sheet information related to leases was as follows:

[0000950170-25-024839:notes:137]
|  |  |  |  | As of |  |
|  |  | Balance Sheet Location |  | December 30, 2024 |  |  | January 1, 2024 |  |
|  |  |  |  | (In thousands) |  |
| Assets: |  |  |  |  |  |  |  |  |
| Operating leases |  | Operating lease right-of-use assets |  | $ | 78,252 |  |  | $ | 86,286 |  |
| Finance leases |  | Property, plant, and equipment, net |  |  | 10,621 |  |  |  | 12,010 |  |
| Total lease assets |  |  |  | $ | 88,873 |  |  | $ | 98,296 |  |
| Liabilities: |  |  |  |  |  |  |  |  |
| Current: |  |  |  |  |  |  |  |  |
| Operating leases |  | Other current liabilities |  | $ | 7,556 |  |  | $ | 8,433 |  |
| Finance leases |  | Other current liabilities |  |  | 814 |  |  |  | 780 |  |
| Long-term: |  |  |  |  |  |  |  |  |
| Operating leases |  | Operating lease liabilities |  |  | 77,509 |  |  |  | 80,786 |  |
| Finance leases |  | Other long-term liabilities |  |  | 11,985 |  |  |  | 12,799 |  |
| Total lease liabilities |  |  |  | $ | 97,864 |  |  | $ | 102,798 |  |

[0000950170-25-024839:notes:138]
|  |  | As of |
|  |  | December 30, 2024 |  | January 1, 2024 |
| Weighted average remaining lease term (years): |  |  |  |  |  |  |  |  |
| Operating leases |  | 12.5 |  |  |  | 12.8 |  |  |
| Finance leases |  | 11.6 |  |  |  | 12.6 |  |  |
| Weighted average discount rate: |  |  |  |  |  |  |  |  |
| Operating leases |  |  | 6.24 |  | % |  |  | 6.13 |  | % |
| Finance leases |  |  | 2.69 |  |  |  |  | 2.69 |  |  |

[0000950170-25-024839:notes:139]
Maturities of lease liabilities for the next five years and thereafter were as follows:

[0000950170-25-024839:notes:140]
|  |  | Operating Leases (1) |  |  | Finance Leases |  |
|  |  | (In thousands) |  |
| 2025 |  | $ | 12,542 |  |  | $ | 1,145 |  |
| 2026 |  |  | 10,136 |  |  |  | 1,175 |  |
| 2027 |  |  | 8,775 |  |  |  | 1,197 |  |
| 2028 |  |  | 7,964 |  |  |  | 1,228 |  |
| 2029 |  |  | 7,730 |  |  |  | 1,251 |  |
| Thereafter |  |  | 79,908 |  |  |  | 8,980 |  |
| Total lease payments |  |  | 127,055 |  |  |  | 14,976 |  |
| Less: Imputed interest |  |  | (41,990 | ) |  |  | (2,177 | ) |
| Total |  | $ | 85,065 |  |  | $ | 12,799 |  |

[0000950170-25-024839:notes:141]
(1)
Excludes $436 of legally binding minimum lease payments for leases signed but not yet commenced.


## us-gaap:AdditionalFinancialInformationDisclosureTextBlock

[0000950170-25-024839:notes:142]
(5)
Composition of Certain Consolidated Financial Statement Captions

[0000950170-25-024839:notes:143]
|  |  | As of |  |
|  |  | December 30, 2024 |  |  | January 1, 2024 |  |
|  |  | (In thousands) |  |
| Inventories: |  |  |  |  |  |  |
| Raw materials |  | $ | 178,066 |  |  | $ | 165,666 |  |
| Work-in-process |  |  | 45,580 |  |  |  | 45,494 |  |
| Finished goods |  |  | 1,339 |  |  |  | 1,915 |  |
| Inventories |  | $ | 224,985 |  |  | $ | 213,075 |  |
| Property, plant, and equipment, net: |  |  |  |  |  |  |
| Land and land use rights |  | $ | 69,788 |  |  | $ | 71,131 |  |
| Buildings and improvements |  |  | 515,773 |  |  |  | 512,148 |  |
| Machinery and equipment |  |  | 1,116,658 |  |  |  | 986,527 |  |
| Furniture and fixtures and other |  |  | 11,115 |  |  |  | 10,157 |  |
| Construction-in-progress |  |  | 75,502 |  |  |  | 90,940 |  |
| Property, plant, and equipment, gross |  |  | 1,788,836 |  |  |  | 1,670,903 |  |
| Less: Accumulated depreciation |  |  | (918,879 | ) |  |  | (863,236 | ) |
| Property, plant, and equipment, net |  | $ | 869,957 |  |  | $ | 807,667 |  |
| Other current liabilities: |  |  |  |  |  |  |
| Income taxes payable |  | $ | 15,919 |  |  | $ | 5,466 |  |
| Accrued capital expenditures |  |  | 13,046 |  |  |  | 35,026 |  |
| Sales return and allowances |  |  | 10,777 |  |  |  | 12,301 |  |
| Interest |  |  | 9,054 |  |  |  | 9,399 |  |
| Accrued facility operating costs |  |  | 8,925 |  |  |  | 10,172 |  |
| Housing fund |  |  | 7,927 |  |  |  | 7,749 |  |
| Warranty |  |  | 7,685 |  |  |  | 10,557 |  |
| Operating leases |  |  | 7,556 |  |  |  | 8,433 |  |
| Accrued professional fees |  |  | 3,606 |  |  |  | 3,276 |  |
| Restructuring |  |  | 3,486 |  |  |  | 1,179 |  |
| Derivative liabilities |  |  | 667 |  |  |  | 297 |  |
| Other |  |  | 31,326 |  |  |  | 36,951 |  |
| Other current liabilities |  | $ | 119,974 |  |  | $ | 140,806 |  |
| Other long-term liabilities: |  |  |  |  |  |  |
| Deferred income taxes |  | $ | 41,362 |  |  | $ | 44,238 |  |
| Customer deposits |  |  | 28,390 |  |  |  | 29,820 |  |
| Finance leases |  |  | 11,985 |  |  |  | 12,799 |  |
| Other |  |  | 26,011 |  |  |  | 26,661 |  |
| Other long-term liabilities |  | $ | 107,748 |  |  | $ | 113,518 |  |


## us-gaap:GoodwillDisclosureTextBlock

[0000950170-25-024839:notes:144]
(6)
Goodwill

[0000950170-25-024839:notes:145]
Goodwill by reportable segment was as follows:

[0000950170-25-024839:notes:146]
|  |  | PCB |  |  | RF&S Components |  |  | Total |  |
|  |  | (In thousands) |  |
| As of January 1, 2024 |  |  |  |  |  |  |  |  |  |
| Goodwill |  | $ | 810,235 |  |  | $ | 177,200 |  |  | $ | 987,435 |  |
| Accumulated impairment losses |  |  | (171,400 | ) |  |  | (113,300 | ) |  |  | (284,700 | ) |
| Carrying amount |  |  | 638,835 |  |  |  | 63,900 |  |  |  | 702,735 |  |
| Impairment loss during the year ended December 30, 2024 |  |  | — |  |  |  | (32,600 | ) |  |  | (32,600 | ) |
| As of December 30, 2024 |  |  |  |  |  |  |  |  |  |
| Goodwill |  |  | 810,235 |  |  |  | 177,200 |  |  |  | 987,435 |  |
| Accumulated impairment losses |  |  | (171,400 | ) |  |  | (145,900 | ) |  |  | (317,300 | ) |
| Carrying amount |  | $ | 638,835 |  |  | $ | 31,300 |  |  | $ | 670,135 |  |

[0000950170-25-024839:notes:147]
The Company evaluates its goodwill on an annual basis during its fourth fiscal quarter and at other times when events or changes in circumstances – such as significant adverse changes in the business climate or operating results or changes in management strategy, coupled with a decline in the market price of its stock and market capitalization – indicate that there may be a potential impairment. The Company assesses qualitative factors to determine whether it is more likely than not that the fair value of a reporting unit is less than its carrying amount or performs a quantitative impairment test.

[0000950170-25-024839:notes:148]
In the fourth quarter of 2024, the Company performed its annual goodwill impairment test qualitatively for the PCB reporting unit and concluded that it was more likely than not that there was no impairment to goodwill.

[0000950170-25-024839:notes:149]
In the fourth quarter of 2024, the Company performed its annual goodwill impairment test quantitatively for the RF&S Components reporting unit. As of November 1, 2024, the Company completed a quantitative goodwill impairment analysis related to its RF&S Components reporting unit by comparing the fair value of the reporting unit with its carrying amount. In making this assessment, management relies on a number of factors, including expected future operating results, business plans, economic projections, anticipated future cash flows, and business trends. The Company determined the fair value of the reporting unit by using both a DCF and a market approach. Under the market approach, the Company used revenue and earnings multiples based on comparable industry multiples to estimate the fair value of the reporting unit. If the carrying amount of a reporting unit exceeds the reporting unit’s fair value, the amount by which the carrying value exceeds the fair value is recognized as an impairment loss.

[0000950170-25-024839:notes:150]
Under the DCF approach, the Company estimated the future cash flows, as well as selected a risk-adjusted discount rate to measure the present value of the anticipated cash flows. When determining future cash flow estimates, the Company considered historical results adjusted to reflect current and anticipated future operating conditions. The Company estimated cash flows for the reporting unit over a discrete period and a terminal period (considering expected long-term growth rates and trends).

[0000950170-25-024839:notes:151]
Based on its analysis, the Company determined that the fair value of the RF&S Components reporting unit was less than its carrying value and recorded a non-cash goodwill impairment charge of $32,600 during the year ended December 30, 2024. If the Company's future cash flow projections and other fair value assumptions for its reporting unit change, the Company’s goodwill may be subject to potential additional impairment charges in subsequent quarters. Estimating the fair value of the reporting unit requires the Company to make assumptions and estimates in such areas as future economic conditions, industry-specific conditions, product pricing, and necessary capital expenditures. The use of different assumptions or estimates for future cash flows, discount rates, or terminal growth rates, which are subject to a high degree of judgment, could produce substantially different estimates of the fair value of the reporting unit.


## us-gaap:IntangibleAssetsDisclosureTextBlock

[0000950170-25-024839:notes:152]
(7)
Definite-lived Intangibles

[0000950170-25-024839:notes:153]
The components of definite-lived intangibles were as follows:

[0000950170-25-024839:notes:154]
|  |  | GrossAmount |  |  | AccumulatedAmortization |  |  | NetCarryingAmount |  |  | WeightedAverageAmortizationPeriod |  |
|  |  | (In thousands) |  |  | (In years) |  |
| As of December 30, 2024 |  |  |  |  |  |  |  |  |  |  |  |  |
| Customer relationships |  | $ | 323,500 |  |  | $ | (161,710 | ) |  | $ | 161,790 |  |  |  | 11.8 |  |
| Technology |  |  | 66,650 |  |  |  | (36,621 | ) |  |  | 30,029 |  |  |  | 8.2 |  |
| Total |  | $ | 390,150 |  |  | $ | (198,331 | ) |  | $ | 191,819 |  |  |  |  |
| As of January 1, 2024 |  |  |  |  |  |  |  |  |  |  |  |  |
| Customer relationships |  | $ | 416,230 |  |  | $ | (222,766 | ) |  | $ | 193,464 |  |  |  | 11.2 |  |
| Technology |  |  | 66,650 |  |  |  | (27,278 | ) |  |  | 39,372 |  |  |  | 8.2 |  |
| Backlog |  |  | 13,000 |  |  |  | (9,750 | ) |  |  | 3,250 |  |  |  | 2.0 |  |
| Trade names |  |  | 2,500 |  |  |  | (1,875 | ) |  |  | 625 |  |  |  | 2.0 |  |
| Total |  | $ | 498,380 |  |  | $ | (261,669 | ) |  | $ | 236,711 |  |  |  |  |

[0000950170-25-024839:notes:155]
Definite-lived intangibles are amortized using the straight-line method of amortization over the useful life. Amortization expense was $44,892, $61,576, and $42,631 for the years ended December 30, 2024, January 1, 2024, and January 2, 2023, respectively. For the years ended December 30, 2024, January 1, 2024, and January 2, 2023, $9,342, $12,901, and $5,534, respectively, of amortization expense is included in cost of goods sold.

[0000950170-25-024839:notes:156]
In connection with the finalization of acquired identifiable intangible asset valuation during the second quarter of 2023 related to the Company's acquisition in 2022 of Telephonics, the Company recorded amortization expense of $24,877 related to the acquired identifiable intangible assets during the year ended January 1, 2024 (of which $5,627 corresponded to the year ended January 2, 2023 due to the change in amortization period). For the year ended January 1, 2024, $8,850 of amortization expense related to the acquired identifiable intangible assets was included in cost of goods sold (of which $2,950 corresponded to the year ended January 2, 2023).

[0000950170-25-024839:notes:157]
Estimated aggregate amortization for definite-lived intangible assets for the next five years and thereafter is as follows:

[0000950170-25-024839:notes:158]
|  |  | (In thousands) |  |
| 2025 |  | $ | 36,897 |  |
| 2026 |  |  | 36,897 |  |
| 2027 |  |  | 34,543 |  |
| 2028 |  |  | 30,997 |  |
| 2029 |  |  | 22,355 |  |
| Thereafter |  |  | 30,130 |  |
| Total |  | $ | 191,819 |  |


## us-gaap:LongTermDebtTextBlock

[0000950170-25-024839:notes:159]
(8)
Long-term Debt and Letters of Credit

[0000950170-25-024839:notes:160]
Long-term debt was as follows:

[0000950170-25-024839:notes:161]
|  |  | As of December 30, 2024 |  |  | As of January 1, 2024 |  |
|  |  | Interest Rate |  | Principal Outstanding |  |  | Interest Rate |  | Principal Outstanding |  |
|  |  | (In thousands, except interest rates) |  |
| Senior Notes due March 2029 |  |  | 4.00 |  | % |  | $ | 500,000 |  |  |  | 4.00 |  | % |  | $ | 500,000 |  |
| Term Loan due May 2030 |  |  | 6.59 |  |  |  |  | 345,634 |  |  |  | 8.10 |  |  |  |  | 349,125 |  |
| Asia ABL Revolving Loan due June 2028 |  |  | 5.64 |  |  |  |  | 80,000 |  |  |  | 6.65 |  |  |  |  | 80,000 |  |
| Other |  |  | 5.99 |  |  |  |  | 2,311 |  |  |  | — |  |  |  |  | — |  |
| Total debt |  |  |  |  |  |  | 927,945 |  |  |  |  |  |  |  | 929,125 |  |
| Less: Unamortized debt issuance costs |  |  |  |  |  |  | (6,951 | ) |  |  |  |  |  |  | (8,021 | ) |
| Less: Unamortized debt discount |  |  |  |  |  |  | (2,840 | ) |  |  |  |  |  |  | (3,268 | ) |
| Subtotal |  |  |  |  |  |  | 918,154 |  |  |  |  |  |  |  | 917,836 |  |
| Less: Current maturities |  |  |  |  |  |  | (3,795 | ) |  |  |  |  |  |  | (3,500 | ) |
| Long-term debt, less current maturities |  |  |  |  |  | $ | 914,359 |  |  |  |  |  |  | $ | 914,336 |  |

[0000950170-25-024839:notes:162]
The fiscal calendar maturities of debt for the next five years and thereafter are as follows:

[0000950170-25-024839:notes:163]
|  |  | (In thousands) |  |
| 2025 |  | $ | 3,795 |  |
| 2026 |  |  | 3,815 |  |
| 2027 |  |  | 4,735 |  |
| 2028 |  |  | 83,828 |  |
| 2029 |  |  | 503,018 |  |
| Thereafter |  |  | 328,754 |  |
| Total |  | $ | 927,945 |  |

[0000950170-25-024839:notes:164]
Senior Notes due 2029

[0000950170-25-024839:notes:165]
On March 10, 2021, the Company issued $500,000 of Senior Notes due 2029, which are included in long-term debt and bear interest at a rate of 4.0% per annum. Interest is payable semiannually in arrears on March 1 and September 1 of each year beginning September 1, 2021. The Senior Notes due 2029 will mature on March 1, 2029.

[0000950170-25-024839:notes:166]
The Senior Notes due 2029 are irrevocably and unconditionally guaranteed, jointly and severally, on a senior unsecured basis by the Company’s existing and future domestic subsidiaries, subject to certain exceptions. The Senior Notes due 2029 and related guarantees are senior unsecured obligations of, respectively, the Company and applicable subsidiary guarantors.

[0000950170-25-024839:notes:167]
Term Loan Facility

[0000950170-25-024839:notes:168]
On August 1, 2024, the Company entered into a First Amendment to its Amended and Restated Term Loan Credit Agreement, dated as of May 30, 2023, by and among the Company, as Borrower, JPMorgan Chase Bank, N.A., as Administrative Agent, and the several lenders from time to time parties thereto, pursuant to which the Company closed its $346,500 new senior secured term loan (Term Loan Facility) that bears interest at a floating rate of 1-month Chicago Mercantile Exchange (CME) Term Secured Overnight Financing Rate (SOFR) plus an applicable margin of 2.25%, 50 basis points lower than the previous term loan facility issued in May 2023. The Term Loan Facility is issued at par, maintains the same maturity of May 30, 2030 as the previous term loan facility, and the majority is a cashless rollover from the previous term loan facility. This Term Loan Facility had an outstanding balance of $345,634 as of December 30, 2024, of which $3,465 is included in short-term debt and $342,169 is included in long-term debt. The Term Loan Facility was issued with a 1.0% original issue discount. There is no provision, other than an event of default, for the interest margin to increase. The Company is required to make quarterly principal repayments in an aggregate annual amount equal to 1% of the $346,500 aggregate principal amount of the Term Loan Facility. Such principal repayment is payable quarterly on January 1, April 1, July 1, and October 1 and ending with the last such day to occur prior to May 30, 2030. The remaining principal under the Term Loan Facility is scheduled to mature on May 30, 2030. In addition, the Term Loan Credit Agreement permits the Company to add one or more senior secured incremental term loan facilities to the Term Loan Facility subject to the satisfaction of certain conditions.

[0000950170-25-024839:notes:169]
The obligations under the Term Loan Facility are unconditionally guaranteed by each Subsidiary Guarantor of the Company, subject to certain exceptions (Guarantors). The Term Loan Facility is secured by (i) a perfected first priority security interest in substantially all of the assets of the Company and the Guarantors (other than the U.S. Asset-Based Lending Credit Agreement (U.S.

[0000950170-25-024839:notes:170]
ABL) Priority Collateral (as defined below)), including all of the total outstanding voting capital stock held by the Company and the Guarantors (subject to a limitation of 65% on pledges of such capital stock of certain foreign subsidiaries and domestic holding companies of foreign subsidiaries) and (ii) a perfected second priority interest in all of the U.S. ABL Priority Collateral (as defined below). The Term Loan Facility is structurally senior to the Company’s Senior Notes due 2029.

[0000950170-25-024839:notes:171]
Based on certain parameters defined in the Term Loan Facility, including a Secured Leverage Ratio, the Company may be required to make an additional principal payment on an annual basis if its Secured Leverage Ratio is greater than 2.0.

[0000950170-25-024839:notes:172]
Borrowings under the Term Loan Credit Agreement are subject to certain affirmative and negative covenants, including limitations on indebtedness, corporate transactions, investments, dispositions, and share payments.

[0000950170-25-024839:notes:173]
Asset-Based Lending Agreements

[0000950170-25-024839:notes:174]
The U.S. ABL is comprised of a revolving credit facility for up to $150,000 and a sublimit for letter of credit for up to $50,000, provided that at no time may amounts outstanding under the agreement exceed in the aggregate $150,000 or the applicable borrowing base, which is the sum of (i) a percentage of the principal amount of “Eligible Accounts”, plus (ii) a percentage of the net orderly liquidation value of (x) “Eligible Inventory”, minus (y) “Inventory Reserves” applicable thereto, minus (iii) “Reserves”, each as defined in the U.S. ABL agreement. Borrowings under the U.S. ABL bear interest at a floating rate of Term SOFR plus a margin ranging from 1.25% to 1.50%. The applicable margin can vary based on the remaining availability of the facility, from 1.25% to 1.50% for Term SOFR-based loans and from 0.25% to 0.50% for JPMorgan Chase Bank’s prime rate-based loans. Other than availability and an event of default, there are no other provisions for the interest margin to increase.

[0000950170-25-024839:notes:175]
The U.S. ABL is scheduled to mature on May 30, 2028. The Guarantors have also fully guaranteed the full and timely payment of all obligations in respect of the U.S. ABL. Loans made under the U.S. ABL are secured by a perfected first priority security interest in certain deposit accounts, cash and cash equivalents, accounts receivable, and certain U.S. inventory (U.S. ABL Priority Collateral) as well as by a perfected second priority interest in all of the collateral securing the Term Loan Facility.

[0000950170-25-024839:notes:176]
The Asia Asset-Based Lending Credit Agreement (Asia ABL) is comprised of a revolving credit facility for up to $150,000 and a sublimit for letter of credit for up to $100,000, provided that at no time may amounts outstanding under the agreement exceed in aggregate $150,000 or the applicable borrowing base, which is a percentage of the principal amount of Eligible Accounts, as defined in the Asia ABL agreement. Borrowings under the Asia ABL bear interest at a floating rate of Term SOFR plus 1.30%. There is no provision, other than an event of default, for the interest margin to increase. As of December 30, 2024, the interest rate on the outstanding borrowings under the Asia ABL was 5.64%. As of December 30, 2024, $80,000 under the Asia ABL was outstanding and classified as long-term debt, which is consistent with its maturity date.

[0000950170-25-024839:notes:177]
The Asia ABL is scheduled to mature on June 13, 2028. Loans made under the Asia ABL are secured by a portion of the Company’s Asia Pacific cash and receivables and are structurally senior to the Company’s domestic obligations, including the Senior Notes due 2029.

[0000950170-25-024839:notes:178]
As of December 30, 2024, letters of credit in the amount of $7,497 were outstanding under the U.S. ABL and $16,931 were outstanding under the Asia ABL with various maturities through December 2025. Available borrowing capacity under the U.S. ABL and the Asia ABL was $142,503 and $53,069 respectively, which considers letters of credit outstanding as of December 30, 2024.

[0000950170-25-024839:notes:179]
The Company is required to pay a commitment fee of 0.25% per annum on any unused portion of the U.S. ABL and the Asia ABL (collectively, the ABL Revolving Loans). The Company incurred total commitment fees related to unused borrowing availability of $476, $620, and $661 for the years ended December 30, 2024, January 1, 2024, and January 2, 2023, respectively. Under the occurrence of certain events, the ABL Revolving Loans are subject to various financial covenants, including leverage and fixed charge coverage ratios.

[0000950170-25-024839:notes:180]
Debt Issuance Costs and Debt Discount

[0000950170-25-024839:notes:181]
Remaining unamortized debt issuance costs and debt discount were as follows:

[0000950170-25-024839:notes:182]
|  |  | As of December 30, 2024 |  | As of January 1, 2024 |
|  |  | DebtIssuance Costs |  |  | DebtDiscount |  |  | EffectiveInterest Rate |  | DebtIssuance Costs |  |  | DebtDiscount |  |  | EffectiveInterest Rate |
|  |  | (In thousands, except interest rates) |
| Senior Notes due March 2029 |  | $ | 3,362 |  |  | $ | — |  |  |  | 4.18 |  | % |  | $ | 4,085 |  |  | $ | — |  |  |  | 4.18 |  | % |
| Term Loan due May 2030 |  |  | 3,589 |  |  |  | 2,840 |  |  |  | 8.01 |  |  |  |  | 3,936 |  |  |  | 3,268 |  |  |  | 8.26 |  |  |
| Total |  | $ | 6,951 |  |  | $ | 2,840 |  |  |  |  |  |  | $ | 8,021 |  |  | $ | 3,268 |  |  |  |  |  |

[0000950170-25-024839:notes:183]
The above debt issuance costs and debt discount are recorded as a reduction of the debt and are amortized into interest expense using an effective interest rate over the duration of the debt.

[0000950170-25-024839:notes:184]
Remaining unamortized debt issuance costs for the ABL Revolving Loans of $1,239 and $1,603 as of December 30, 2024 and January 1, 2024, respectively, are included in deposits and other non-current assets and are amortized to interest expense over the duration of the ABL Revolving Loans using the straight-line method of amortization.

[0000950170-25-024839:notes:185]
As of December 30, 2024, the remaining weighted average amortization period for all unamortized debt issuance costs and debt discount was 4.8 years.

[0000950170-25-024839:notes:186]
Debt Covenants

[0000950170-25-024839:notes:187]
As of December 30, 2024, the Company was in compliance with the financial covenants under the Senior Notes due 2029, Term Loan Facility, and ABL Revolving Loans.

[0000950170-25-024839:notes:188]
Loss on Extinguishment of Debt

[0000950170-25-024839:notes:189]
During the year ended January 1, 2024, the Company recognized loss on extinguishment of debt of $1,154, primarily associated with the write-off of the remaining unamortized debt issuance costs and debt discount as a result of the repayment of the remaining outstanding balance of the Term Loan Facility that was due to mature September 2024.


## us-gaap:IncomeTaxDisclosureTextBlock

[0000950170-25-024839:notes:190]
(9)
Income Taxes

[0000950170-25-024839:notes:191]
The components of income before income taxes were as follows:

[0000950170-25-024839:notes:192]
|  |  | For the Year Ended |  |
|  |  | December 30, 2024 |  |  | January 1, 2024 |  |  | January 2, 2023 |  |
|  |  | (In thousands) |  |
| United States |  | $ | (36,745 | ) |  | $ | (105,101 | ) |  | $ | (52,468 | ) |
| Foreign |  |  | 120,694 |  |  |  | 105,398 |  |  |  | 235,331 |  |
| Income before income taxes |  | $ | 83,949 |  |  | $ | 297 |  |  | $ | 182,863 |  |

[0000950170-25-024839:notes:193]
The Company expects its earnings attributable to foreign subsidiaries will not be indefinitely reinvested, except for certain subsidiaries, and the Company has established a deferred tax liability of approximately $3,693 and $1,267 for the foreign and U.S. federal/state impact, respectively. For those other companies with earnings currently being reinvested outside of the U.S., the undistributed earnings amounted to approximately $60,769 as of December 30, 2024. The determination of the unrecognized deferred tax liability related to these undistributed earnings is approximately $2,687.

[0000950170-25-024839:notes:194]
The components of income tax provision were as follows:

[0000950170-25-024839:notes:195]
|  |  | For the Year Ended |  |
|  |  | December 30, 2024 |  |  | January 1, 2024 |  |  | January 2, 2023 |  |
|  |  | (In thousands) |  |
| Current (provision) benefit: |  |  |  |  |  |  |  |  |  |
| Federal |  | $ | (2,984 | ) |  | $ | 445 |  |  | $ | (2,591 | ) |
| State |  |  | (2,958 | ) |  |  | (1,592 | ) |  |  | (1,812 | ) |
| Foreign |  |  | (22,934 | ) |  |  | (29,094 | ) |  |  | (23,453 | ) |
| Total current |  |  | (28,876 | ) |  |  | (30,241 | ) |  |  | (27,856 | ) |
| Deferred benefit (provision): |  |  |  |  |  |  |  |  |  |
| Federal |  |  | 340 |  |  |  | 1,321 |  |  |  | (29,093 | ) |
| State |  |  | 85 |  |  |  | 271 |  |  |  | (3,905 | ) |
| Foreign |  |  | 801 |  |  |  | 9,634 |  |  |  | (27,426 | ) |
| Total deferred |  |  | 1,226 |  |  |  | 11,226 |  |  |  | (60,424 | ) |
| Income tax provision |  | $ | (27,650 | ) |  | $ | (19,015 | ) |  | $ | (88,280 | ) |

[0000950170-25-024839:notes:196]
The reconciliation of the provision for income taxes at the statutory federal income tax rate compared to the Company’s provision for income taxes were as follows:

[0000950170-25-024839:notes:197]
|  |  | For the Year Ended |  |
|  |  | December 30, 2024 |  |  | January 1, 2024 |  |  | January 2, 2023 |  |
|  |  | (In thousands) |  |
| Statutory federal income tax provision |  | $ | (17,629 | ) |  | $ | (62 | ) |  | $ | (38,401 | ) |
| State income taxes, net of federal benefit and state tax credits |  |  | (672 | ) |  |  | (1,875 | ) |  |  | 1,750 |  |
| IRC Section 162(m) limitation |  |  | (1,467 | ) |  |  | (2,121 | ) |  |  | (791 | ) |
| Stock options |  |  | 453 |  |  |  | (651 | ) |  |  | (599 | ) |
| Global Intangible Low-Taxed Income |  |  | (7,435 | ) |  |  | (12,639 | ) |  |  | (19,240 | ) |
| Foreign tax credits |  |  | 10,131 |  |  |  | 14,916 |  |  |  | 17,343 |  |
| Permanently reinvested earnings assertion |  |  | (2,634 | ) |  |  | (3,934 | ) |  |  | (2,721 | ) |
| Foreign tax differential on foreign earnings & other permanent items |  |  | 6,928 |  |  |  | 3,788 |  |  |  | 1,504 |  |
| Change in valuation allowance |  |  | (13,650 | ) |  |  | (13,460 | ) |  |  | (50,805 | ) |
| Uncertain tax positions |  |  | — |  |  |  | 957 |  |  |  | (85 | ) |
| Federal research and development credits |  |  | 6,052 |  |  |  | 4,665 |  |  |  | 4,319 |  |
| Goodwill impairment |  |  | (6,846 | ) |  |  | (9,261 | ) |  |  | — |  |
| Other |  |  | (881 | ) |  |  | 662 |  |  |  | (554 | ) |
| Income tax provision |  | $ | (27,650 | ) |  | $ | (19,015 | ) |  | $ | (88,280 | ) |

[0000950170-25-024839:notes:198]
Deferred income taxes reflect the net tax effects of temporary differences between the carrying amounts of assets and liabilities for financial reporting purposes and the amounts used for income tax purposes. The significant components of the net deferred income tax assets (liabilities) were as follows:

[0000950170-25-024839:notes:199]
|  |  | As of |  |
|  |  | December 30, 2024 |  |  | January 1, 2024 |  |
|  |  | (In thousands) |  |
| Deferred income tax assets: |  |  |  |  |  |  |
| Net operating loss carryforwards |  | $ | 29,974 |  |  | $ | 30,098 |  |
| Reserves and accruals |  |  | 57,453 |  |  |  | 60,023 |  |
| Interest expense limitation |  |  | 41 |  |  |  | 959 |  |
| Unrealized gain on cash flow hedge |  |  | — |  |  |  | (1,221 | ) |
| Tax credit carryforwards |  |  | 33,559 |  |  |  | 35,760 |  |
| Stock-based compensation |  |  | 6,591 |  |  |  | 5,312 |  |
| Property, plant, and equipment |  |  | 3,748 |  |  |  | 4,733 |  |
| Intangible and capitalized research expenditure amortization |  |  | 7,601 |  |  |  | — |  |
| Other deferred income tax assets |  |  | 880 |  |  |  | 883 |  |
|  |  |  | 139,847 |  |  |  | 136,547 |  |
| Less: Valuation allowance |  |  | (95,373 | ) |  |  | (81,779 | ) |
|  |  |  | 44,474 |  |  |  | 54,768 |  |
| Deferred income tax liabilities: |  |  |  |  |  |  |
| Debt discount and issuance cost |  |  | (1,582 | ) |  |  | — |  |
| Repatriation of foreign earnings |  |  | (4,961 | ) |  |  | (7,137 | ) |
| Property, plant, and equipment basis differences |  |  | (74,632 | ) |  |  | (73,072 | ) |
| Goodwill and intangible amortization |  |  | (1,358 | ) |  |  | (11,551 | ) |
| Unrealized gain on cash flow hedge |  |  | (1,895 | ) |  |  | — |  |
| Other deferred income tax liabilities |  |  | (465 | ) |  |  | (5,149 | ) |
| Net deferred income tax liabilities (included in other long-term liabilities and deposits and other non-current assets) |  | $ | (40,419 | ) |  | $ | (42,141 | ) |

[0000950170-25-024839:notes:200]
As of December 30, 2024, the Company had the following net operating loss (NOLs) carryforwards: $78,492 in the U.S. for federal, $24,132 in various U.S. states, $33,344 in China, $23,582 in Hong Kong, and $26,008 in Malaysia. The U.S. federal NOLs expire in 2029 through 2032, the various U.S. states’ NOLs expire in 2025 through 2044, the China NOLs expire in 2029 through 2034, and the Hong Kong and Malaysia NOLs carryforward indefinitely. Further, the Company’s tax credits were approximately $43,752, of which $5,849 carryforward indefinitely.

[0000950170-25-024839:notes:201]
In connection with the Company’s acquisition of Viasystems during 2015, there was more than a 50% change in ownership under Section 382 of the Internal Revenue Code of 1986, as amended, and regulations issued there under. As a consequence, the utilization of the remaining Viasystems U.S. NOLs is limited to approximately $9,826 per year and total $78,492.

[0000950170-25-024839:notes:202]
A valuation allowance is provided when it is more likely than not that all or some portion of the deferred income tax assets will not be realized. The Company established a valuation allowance on its U.S. net deferred tax assets in the current year mainly due to cumulative book losses in the U.S. In addition, certain subsidiaries in various tax jurisdictions continue to have NOL carryforwards, which the Company has determined are not more likely than not to be utilized. As a result, a full valuation allowance has been recorded for these subsidiaries as of December 30, 2024. For the remaining net deferred income tax assets, management has determined that it is more likely than not that the results of future operations will generate sufficient income to realize the net deferred tax assets.

[0000950170-25-024839:notes:203]
A summary of the activity in the Company’s valuation allowance was as follows:

[0000950170-25-024839:notes:204]
|  |  | For the Year Ended |  |
|  |  | December 30, 2024 |  |  | January 1, 2024 |  |  | January 2, 2023 |  |
|  |  | (In thousands) |  |
| Balance at beginning of year |  | $ | 81,779 |  |  | $ | 67,173 |  |  | $ | 16,541 |  |
| Additions charged to expense |  |  | 13,743 |  |  |  | 13,811 |  |  |  | 51,748 |  |
| Addition related to acquisition |  |  | — |  |  |  | 1,187 |  |  |  | — |  |
| Other reduction charged to expense |  |  | (149 | ) |  |  | (392 | ) |  |  | (1,116 | ) |
| Balance at end of year |  | $ | 95,373 |  |  | $ | 81,779 |  |  | $ | 67,173 |  |

[0000950170-25-024839:notes:205]
Certain entities within China qualified for the high and new technology enterprise (HNTE) status enabling those entities to enjoy certain benefits, which were effective for the years ended December 30, 2024, January 1, 2024, and January 2, 2023. The HNTE status as well as enhanced research and development (R&D) deductions decreased Chinese taxes. HNTE and R&D benefit and effect on earnings per share were as follows:

[0000950170-25-024839:notes:206]
|  |  | For the Year Ended |  |
|  |  | December 30, 2024 |  |  | January 1, 2024 |  |  | January 2, 2023 |  |
|  |  | (In thousands, except per share data) |  |
| HNTE and R&D benefits |  | $ | 5,187 |  |  | $ | 6,056 |  |  | $ | 13,480 |  |
| Basic shares |  |  | 101,781 |  |  |  | 102,744 |  |  |  | 102,074 |  |
| Diluted shares |  |  | 104,098 |  |  |  | 102,744 |  |  |  | 103,866 |  |
| Increases earnings per share: |  |  |  |  |  |  |  |  |  |
| Basic |  | $ | 0.05 |  |  | $ | 0.06 |  |  | $ | 0.13 |  |
| Diluted |  |  | 0.05 |  |  |  | 0.06 |  |  |  | 0.13 |  |

[0000950170-25-024839:notes:207]
HNTE status expired for certain subsidiaries in 2024, but the Company expects to continue to file for renewal of such HNTE status for the foreseeable future.

[0000950170-25-024839:notes:208]
With respect to its Malaysian operations, the Company received official notification from Malaysia Investment Development Authority (MIDA) in December 2023 that the Company's application for an incentive was approved. The incentive provided by MIDA is for a special tax rate of 0% for three, five-year periods (totaling 15 years) as long as the Malaysian operations meet specific requirements outlined in the notice. Starting in 2024, the Company's Malaysian operations will be subject to a 0% tax rate (absent any applicable impact from the global minimum tax of 15% under the Organization for Economic Co-operation and Development’s (OECD) Pillar Two). No tax benefit was recognized for the year ended December 30, 2024.

[0000950170-25-024839:notes:209]
A reconciliation of the beginning and ending amount of unrecognized tax benefits, exclusive of accrued interest and penalties, were as follows:

[0000950170-25-024839:notes:210]
|  |  | For the Year Ended |  |
|  |  | December 30, 2024 |  |  | January 1, 2024 |  |  | January 2, 2023 |  |
|  |  | (In thousands) |  |
| Balance at beginning of year |  | $ | 10,363 |  |  | $ | 9,778 |  |  | $ | 9,442 |  |
| Additions based on tax positions related to the current year |  |  | 1,220 |  |  |  | 934 |  |  |  | 820 |  |
| Additions for tax positions of prior years |  |  | — |  |  |  | 13 |  |  |  | — |  |
| Reductions for tax positions of prior years |  |  | (3 | ) |  |  | — |  |  |  | (72 | ) |
| Lapse of statute of limitations |  |  | (941 | ) |  |  | (362 | ) |  |  | (412 | ) |
| Balance at end of year |  | $ | 10,639 |  |  | $ | 10,363 |  |  | $ | 9,778 |  |

[0000950170-25-024839:notes:211]
During the year ended December 30, 2024, the Company increased uncertain tax positions by $276 due to U.S. R&D credit generation in 2024, offset by the release of uncertain tax positions due to the statute of limitations expiration.

[0000950170-25-024839:notes:212]
As of December 30, 2024 and January 1, 2024, the Company recorded unrecognized tax benefits of $446 and $449, respectively, as well as interest and penalties of $475 and $434, respectively, to other current liabilities and other long-term liabilities. The Company has also recorded unrecognized tax benefits of $10,193 and $9,914 against certain deferred tax assets as of December 30, 2024 and January 1, 2024, respectively. The amount of unrecognized tax benefits that would, if recognized, reduce the Company’s effective income tax rate in any future periods is $921 including interest and penalties. The Company expects its unrecognized tax benefits to decrease by $244 along with related interest of $445 over the next twelve months due to expiring statutes.

[0000950170-25-024839:notes:213]
As of December 30, 2024, the Company is open for (1) U.S. federal income tax examination for the period from 2021 to 2024 and NOL and credit carryforwards are subject to adjustment for three years post utilization; (2) state and local income tax examination for tax years 2020 to 2024 and NOL and credit carryforwards are subject to adjustment for four years post utilization; and (3) foreign income tax examinations generally for tax years from 2014 to 2024.


## us-gaap:SegmentReportingDisclosureTextBlock

[0000950170-25-024839:notes:214]
(10)
Segment Information

[0000950170-25-024839:notes:215]
The reportable segments shown below are the Company’s segments for which separate financial information is available and upon which operating results are evaluated by the chief operating decision maker (CODM), who is the President and Chief Executive Officer, to assess performance and to allocate resources. They are managed separately because each business manufactures at different stages in the electrical equipment manufacturing value chain and has different margins. The CODM uses segment operating income to allocate resources such as employees and capital resources for each segment during the Company’s annual budgeting and forecasting process. On a quarterly basis, the CODM considers variances in forecast to actual, prior quarter actual to current quarter actual, prior year quarter actual to current quarter actual, and the next quarter forecast to current quarter actual for segment operating income when making decisions about deploying personnel and capital resources to the segments. Separate segment asset measures are not used as a basis for the CODM to evaluate the performance of or to allocate resources to the segments.

[0000950170-25-024839:notes:216]
The PCB reportable segment consists of PCBs, engineered systems using customer-supplied engineering and design plans as well as long-term contracts related to the design and manufacture of highly sophisticated intelligence, surveillance, and communications solutions, components, assemblies, and subsystems. The RF&S Components reportable segment consists of components, assemblies, subsystems, and completed systems which service its RF&S Components and certain aerospace and defense customers.

[0000950170-25-024839:notes:217]
Effective January 1, 2025, the Company changed its organization structure to enhance clarity in sector performance, accountability, and operating costs by clearly allocating resources to either Aerospace and Defense, Commercial, or RF&S Components. To align the new operating model and business structure, the Company is making management organizational changes and implementing new reporting and processes to provide discrete information to manage the business. Management is currently evaluating the impact of this change in organization structure on its assessment of operating segments.

[0000950170-25-024839:notes:218]
Reconciliations of net sales and segment operating income were as follows:

[0000950170-25-024839:notes:219]
|  |  | For the Year Ended December 30, 2024 |  |
|  |  | PCB |  |  | RF&S Components |  |  | Total |  |
|  |  | (In thousands) |  |
| Reconciliation of net sales |  |  |  |  |  |  |  |  |  |
| Gross sales |  | $ | 2,414,983 |  |  | $ | 37,317 |  |  | $ | 2,452,300 |  |
| Less: Inter-segment sales |  |  | (9,368 | ) |  |  | (179 | ) |  |  | (9,547 | ) |
| Net sales |  |  | 2,405,615 |  |  |  | 37,138 |  |  |  | 2,442,753 |  |
| Less: |  |  |  |  |  |  |  |  |  |
| Cost of goods sold |  |  | (1,918,001 | ) |  |  | (19,139 | ) |  |  | (1,937,140 | ) |
| Operating expenses |  |  | (139,223 | ) |  |  | (9,511 | ) |  |  | (148,734 | ) |
| Segment operating income |  | $ | 348,391 |  |  | $ | 8,488 |  |  |  | 356,879 |  |
| Reconciliation of segment operating income |  |  |  |  |  |  |  |  |  |
| Other profit or (loss) (1) |  |  |  |  |  |  |  |  | (33,479 | ) |
| Unallocated amounts: |  |  |  |  |  |  |  |  |  |
| Stock-based compensation |  |  |  |  |  |  |  |  | (29,780 | ) |
| Other corporate expenses |  |  |  |  |  |  |  |  | (132,685 | ) |
| Amortization of definite-lived intangibles (2) |  |  |  |  |  |  |  |  | (44,892 | ) |
| Interest expense |  |  |  |  |  |  |  |  | (47,515 | ) |
| Other, net |  |  |  |  |  |  |  |  | 15,421 |  |
| Income before income taxes |  |  |  |  |  |  |  | $ | 83,949 |  |

[0000950170-25-024839:notes:220]
|  |  | For the Year Ended January 1, 2024 |  |
|  |  | PCB |  |  | RF&S Components |  |  | Total |  |
|  |  | (In thousands) |  |
| Reconciliation of net sales |  |  |  |  |  |  |  |  |  |
| Gross sales |  | $ | 2,199,547 |  |  | $ | 38,619 |  |  | $ | 2,238,166 |  |
| Less: Inter-segment sales |  |  | (5,501 | ) |  |  | (98 | ) |  |  | (5,599 | ) |
| Net sales |  |  | 2,194,046 |  |  |  | 38,521 |  |  |  | 2,232,567 |  |
| Less: |  |  |  |  |  |  |  |  |  |
| Cost of goods sold |  |  | (1,771,811 | ) |  |  | (17,540 | ) |  |  | (1,789,351 | ) |
| Operating expenses |  |  | (127,565 | ) |  |  | (10,124 | ) |  |  | (137,689 | ) |
| Segment operating income |  | $ | 294,670 |  |  | $ | 10,857 |  |  |  | 305,527 |  |
| Reconciliation of segment operating income |  |  |  |  |  |  |  |  |  |
| Other profit or (loss) (1) |  |  |  |  |  |  |  |  | (65,994 | ) |
| Unallocated amounts: |  |  |  |  |  |  |  |  |  |
| Stock-based compensation |  |  |  |  |  |  |  |  | (22,887 | ) |
| Other corporate expenses |  |  |  |  |  |  |  |  | (112,754 | ) |
| Amortization of definite-lived intangibles (2) |  |  |  |  |  |  |  |  | (61,576 | ) |
| Interest expense |  |  |  |  |  |  |  |  | (48,124 | ) |
| Loss on extinguishment of debt |  |  |  |  |  |  |  |  | (1,154 | ) |
| Gain on sale of subsidiary |  |  |  |  |  |  |  |  | 1,270 |  |
| Other, net |  |  |  |  |  |  |  |  | 5,989 |  |
| Income before income taxes |  |  |  |  |  |  |  | $ | 297 |  |

[0000950170-25-024839:notes:221]
|  |  | For the Year Ended January 2, 2023 |  |
|  |  | PCB |  |  | RF&S Components |  |  | Total |  |
|  |  | (In thousands) |  |
| Reconciliation of net sales |  |  |  |  |  |  |  |  |  |
| Gross sales |  | $ | 2,446,572 |  |  | $ | 57,104 |  |  | $ | 2,503,676 |  |
| Less: Inter-segment sales |  |  | (8,630 | ) |  |  | — |  |  |  | (8,630 | ) |
| Net sales |  |  | 2,437,942 |  |  |  | 57,104 |  |  |  | 2,495,046 |  |
| Less: |  |  |  |  |  |  |  |  |  |
| Cost of goods sold |  |  | (2,001,348 | ) |  |  | (21,509 | ) |  |  | (2,022,857 | ) |
| Operating expenses |  |  | (123,655 | ) |  |  | (12,060 | ) |  |  | (135,715 | ) |
| Segment operating income |  | $ | 312,939 |  |  | $ | 23,535 |  |  |  | 336,474 |  |
| Reconciliation of segment operating income |  |  |  |  |  |  |  |  |  |
| Other profit or (loss) (1) |  |  |  |  |  |  |  |  | 46,306 |  |
| Unallocated amounts: |  |  |  |  |  |  |  |  |  |
| Stock-based compensation |  |  |  |  |  |  |  |  | (19,525 | ) |
| Other corporate expenses |  |  |  |  |  |  |  |  | (110,216 | ) |
| Amortization of definite-lived intangibles (2) |  |  |  |  |  |  |  |  | (42,631 | ) |
| Interest expense |  |  |  |  |  |  |  |  | (45,517 | ) |
| Other, net |  |  |  |  |  |  |  |  | 17,972 |  |
| Income before income taxes |  |  |  |  |  |  |  | $ | 182,863 |  |

[0000950170-25-024839:notes:222]
(1)
Represents elimination of inter-segment sales, accelerated depreciation associated with plant closures, gain on sale of assets, unrealized gain/loss on commodity hedge, acquisition costs, non-cash goodwill impairment charge, restructuring, and purchase accounting related inventory markup.

[0000950170-25-024839:notes:223]
(2)
Amortization of definite-lived intangibles relates to the PCB and RF&S Components reportable segments, but is not reviewed separately by the CODM. For the years ended December 30, 2024, January 1, 2024, and January 2, 2023, amortization expense of $9,342, $12,292, and $3,442, respectively, is included in cost of goods sold for the PCB reportable segment. For the years ended January 1, 2024 and January 2, 2023, amortization expense of $609 and $2,092, respectively, is included in cost of goods sold for the RF&S Components reportable segment.

[0000950170-25-024839:notes:224]
Depreciation expense by reportable segment was as follows:

[0000950170-25-024839:notes:225]
|  |  | For the Year Ended |  |
|  |  | December 30, 2024 |  |  | January 1, 2024 |  |  | January 2, 2023 |  |
|  |  | (In thousands) |  |
| PCB |  | $ | 95,232 |  |  | $ | 90,957 |  |  | $ | 82,760 |  |
| RF&S Components |  |  | 1,693 |  |  |  | 1,833 |  |  |  | 1,798 |  |
| Segment total |  |  | 96,925 |  |  |  | 92,790 |  |  |  | 84,558 |  |
| Corporate |  |  | 8,308 |  |  |  | 6,365 |  |  |  | 6,718 |  |
| Total |  | $ | 105,233 |  |  | $ | 99,155 |  |  | $ | 91,276 |  |

[0000950170-25-024839:notes:226]
The Company markets and sells its products in approximately 60 countries. Other than in the United States and Taiwan, the Company does not conduct business in any country in which its net sales in that country exceed 10% of the Company’s total net sales. Net sales are attributed to countries by country invoiced and were as follows:

[0000950170-25-024839:notes:227]
|  |  | For the Year Ended |  |
|  |  | December 30, 2024 |  |  | January 1, 2024 |  |  | January 2, 2023 |  |
|  |  | (In thousands) |  |
| United States |  | $ | 1,232,288 |  |  | $ | 1,263,065 |  |  | $ | 1,224,334 |  |
| Taiwan |  |  | 274,345 |  |  |  | 177,042 |  |  |  | 127,657 |  |
| Other |  |  | 936,120 |  |  |  | 792,460 |  |  |  | 1,143,055 |  |
| Total |  | $ | 2,442,753 |  |  | $ | 2,232,567 |  |  | $ | 2,495,046 |  |

[0000950170-25-024839:notes:228]
Long-lived assets include property, plant, and equipment, goodwill, and definite-lived intangibles and were as follows:

[0000950170-25-024839:notes:229]
|  |  | As of |  |
|  |  | December 30, 2024 |  |  | January 1, 2024 |  |
|  |  | (In thousands) |  |
| United States |  | $ | 1,171,611 |  |  | $ | 1,235,255 |  |
| China |  |  | 357,159 |  |  |  | 346,602 |  |
| Other |  |  | 203,141 |  |  |  | 165,256 |  |
| Total |  | $ | 1,731,911 |  |  | $ | 1,747,113 |  |


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0000950170-25-024839:notes:230]
(11)
Accumulated Other Comprehensive Loss

[0000950170-25-024839:notes:231]
A summary of the components of accumulated other comprehensive loss, net of tax is as follows:

[0000950170-25-024839:notes:232]
|  |  | Foreign CurrencyTranslation |  |  | Pension Obligation |  |  | Cash Flow Hedges |  |  | Total |  |
|  |  | (In thousands) |  |
| Balance as of January 2, 2023 |  | $ | (25,984 | ) |  | $ | 1,279 |  |  | $ | (85 | ) |  | $ | (24,790 | ) |
| Other comprehensive (loss) income before reclassifications |  |  | (6,876 | ) |  |  | 1,251 |  |  |  | 4,061 |  |  |  | (1,564 | ) |
| Amounts reclassified from accumulated other comprehensive loss |  |  | — |  |  |  | — |  |  |  | (2,713 | ) |  |  | (2,713 | ) |
| Net year to date other comprehensive (loss) income |  |  | (6,876 | ) |  |  | 1,251 |  |  |  | 1,348 |  |  |  | (4,277 | ) |
| Balance as of January 1, 2024 |  |  | (32,860 | ) |  |  | 2,530 |  |  |  | 1,263 |  |  |  | (29,067 | ) |
| Other comprehensive (loss) income before reclassifications |  |  | (897 | ) |  |  | 1,082 |  |  |  | 4,147 |  |  |  | 4,332 |  |
| Amounts reclassified from accumulated other comprehensive loss |  |  | — |  |  |  | — |  |  |  | (3,147 | ) |  |  | (3,147 | ) |
| Net year to date other comprehensive (loss) income |  |  | (897 | ) |  |  | 1,082 |  |  |  | 1,000 |  |  |  | 1,185 |  |
| Balance as of December 30, 2024 |  | $ | (33,757 | ) |  | $ | 3,612 |  |  | $ | 2,263 |  |  | $ | (27,882 | ) |


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0000950170-25-024839:notes:233]
(12)
Stock-Based Compensation

[0000950170-25-024839:notes:234]
Incentive Compensation Plan

[0000950170-25-024839:notes:235]
The Company maintains a 2023 Incentive Compensation Plan (the Plan), which allows for issuance of up to 5,100 shares through its latest possible expiration date in May 2033.

[0000950170-25-024839:notes:236]
The Plan provides for the grant of PRUs, RSUs, and stock appreciation rights. The exercise price for awards is determined by the Compensation Committee of the Board of Directors. Each award shall vest and expire as determined by the Compensation Committee of the Board of Directors, with PRUs and RSUs generally vesting over three years for employees and one year for non‑employee directors. PRUs and RSUs do not have voting rights. All grants provide for accelerated vesting if there is a change in control, as defined in the Plan.

[0000950170-25-024839:notes:237]
As of December 30, 2024, 740 PRUs, 4,106 RSUs, and 60 stock options were outstanding under the Plan. Included in the 740 PRUs outstanding as of December 30, 2024 are 411 vested but not yet released. Included in the 4,106 RSUs outstanding as of December 30, 2024 are 641 vested but not yet released RSUs associated with non-employee directors. These RSUs vest over one year with release of the underlying shares of common stock deferred until retirement from the Board of Directors (or until one year after retirement in the case of certain prior grants).

[0000950170-25-024839:notes:238]
Performance-based Restricted Stock Units

[0000950170-25-024839:notes:239]
The Company maintains a long-term incentive program for executives that provides for the issuance of PRUs, representing hypothetical shares of the Company’s common stock that may be issued. Under the PRU program, a target number of PRUs is awarded at the beginning of each three-year performance period. The number of shares of common stock released at the end of the performance period depends on performance during the period and may range from zero to 2.4 times the target number for PRUs awarded before 2023 and zero to 2.0 times the target number for PRUs awarded in 2023 and thereafter. For PRUs awarded before 2023, the performance metrics of the PRU program are based on (1) annual financial targets, which are based on revenue and earnings before interest, tax, depreciation, and amortization expense (EBITDA), each equally weighted, and (2) an overall modifier based on the Company’s total stockholder return (TSR) relative to a group of peer companies selected by the Company’s Compensation Committee, over the three year performance period. For PRUs awarded in 2023 and thereafter, the performance metrics of the PRU program are based on (1) annual financial targets, which are based on revenue and EBITDA, each equally weighted, and (2) the three-year TSR performance result, which will be an additive component to the Company’s financial results of the aggregated three-year measurement period.

[0000950170-25-024839:notes:240]
Under the PRU program, financial goals with respect to one or more target milestones are set at the beginning of each year and performance is reviewed at the end of that year. The percentage to be applied to each participant’s target award ranges from zero to 160% for PRUs awarded before 2023 and zero to 200% for PRUs awarded in 2023 and thereafter, based upon the extent to which the target milestones are achieved. If specific performance threshold levels for the target milestones are met, the amount earned for that element over the three-year performance period will be applied equally for PRUs awarded before 2023 and 80% for PRUs awarded in 2023 and thereafter, of the participants’ PRU award to determine the number of units earned.

[0000950170-25-024839:notes:241]
At the end of the three-year performance period, the total units earned, if any, are adjusted by the TSR calculation. The TSR calculation is a percentage ranging from zero to 150% for PRUs awarded before 2023 and zero to 200% for PRUs awarded in 2023 and thereafter, determined on the Company’s TSR based on stock price changes relative to a group of peer companies selected by the Company’s Compensation Committee for the same three-year period. For outstanding PRU awards granted before 2023, the TSR is used as an overall modifier of the three-year performance period such that the base calculations are multiplied by the TSR modifier, ranging from zero to 200%, based on the relative performance of the Company’s stock price as compared to its TSR peer group. For PRUs awarded in 2023 and thereafter, the TSR calculation will be applied to 20% of the participants’ PRU award to determine the number of additional units earned.

[0000950170-25-024839:notes:242]
Recipients of PRU awards generally must remain employed by the Company on a continuous basis through the end of the three‑year performance period in order to receive any amount of the PRUs covered by that award. In events such as death, disability, or retirement, the recipient may be entitled to pro-rata amounts of PRUs as defined in the Plan. Target shares subject to PRU awards do not have voting rights of common stock until earned and issued following the end of the three-year performance period.

[0000950170-25-024839:notes:243]
The Company records stock-based compensation expense for PRU awards granted based on management’s periodic assessment of the annual financial performance goals to be achieved. As of December 30, 2024, management determined that vesting of the PRU awards was probable. PRU activity for the year ended December 30, 2024 was as follows:

[0000950170-25-024839:notes:244]
|  |  | Shares |  |  | Weighted AverageFair Value |  |
|  |  | (In thousands) |  |  |  |  |
| Outstanding shares as of January 1, 2024 |  |  | 342 |  |  | $ | 15.64 |  |
| Granted |  |  | 351 |  |  |  | 19.51 |  |
| Vested |  |  | (411 | ) |  |  | 15.23 |  |
| Forfeited / cancelled |  |  | (15 | ) |  |  | 15.23 |  |
| Change in units due to annual performance achievement |  |  | 62 |  |  |  | 14.81 |  |
| Outstanding shares as of December 30, 2024 |  |  | 329 |  |  | $ | 20.14 |  |

[0000950170-25-024839:notes:245]
The fair value of PRUs granted is calculated using a Monte Carlo simulation model, as the TSR modifier contains a market condition. The following assumptions were used in determining the fair value:

[0000950170-25-024839:notes:246]
|  |  | For the Year Ended |  |
|  |  | December 30, 2024 (1) |  |  | January 1, 2024 (2) |  |  | January 2, 2023 (3) |  |
| Weighted-average fair value |  | $ | 19.51 |  |  | $ | 16.36 |  |  | $ | 15.02 |  |
| Risk-free interest rate |  |  | 4.42 | % |  |  | 4.46 | % |  |  | 1.44 | % |
| Dividend yield |  |  | — |  |  |  | — |  |  |  | — |  |
| Expected volatility |  |  | 41 | % |  |  | 42 | % |  |  | 30 | % |

[0000950170-25-024839:notes:247]
(1)
Reflects the weighted-averages for the third year of the three-year performance period applicable to PRUs granted in 2022, the second year of the three-year performance period applicable to PRUs granted in 2023, and the first year of the three-year performance period applicable to PRUs granted in 2024.

[0000950170-25-024839:notes:248]
(2)
Reflects the weighted-averages for the third year of the three-year performance period applicable to PRUs granted in 2021, the second year of the three-year performance period applicable to PRUs granted in 2022, and the first year of the three-year performance period applicable to PRUs granted in 2023.

[0000950170-25-024839:notes:249]
(3)
Reflects the weighted-averages for the third year of the three-year performance period applicable to PRUs granted in 2020, the second year of the three-year performance period applicable to PRUs granted in 2021, and the first year of the three-year performance period applicable to PRUs granted in 2022.

[0000950170-25-024839:notes:250]
The risk-free interest rate for the expected term of PRUs is based on the U.S. Treasury yield curve in effect at the time of grant. Expected volatility is calculated using the Company’s historical stock price.

[0000950170-25-024839:notes:251]
Restricted Stock Units

[0000950170-25-024839:notes:252]
RSU activity for the year ended December 30, 2024 was as follows:

[0000950170-25-024839:notes:253]
|  |  | Shares |  |  | Weighted AverageGrant-Date Fair Value |  |
|  |  | (In thousands) |  |  |  |  |
| Non-vested RSUs outstanding as of January 1, 2024 |  |  | 3,453 |  |  | $ | 13.52 |  |
| Granted |  |  | 1,794 |  |  |  | 19.32 |  |
| Vested |  |  | (1,615 | ) |  |  | 18.93 |  |
| Cancelled |  |  | (167 | ) |  |  | 14.89 |  |
| Non-vested RSUs outstanding as of December 30, 2024 |  |  | 3,465 |  |  | $ | 16.47 |  |
| Vested and expected to vest through 2027 as of December 30, 2024 |  |  | 4,106 |  |  | $ | 15.78 |  |

[0000950170-25-024839:notes:254]
The fair value of the Company’s RSUs is determined based upon the closing common stock price on the grant date. The weighted average fair value per unit of RSUs granted was $19.32, $13.85, and $12.72 for the years ended December 30, 2024, January 1, 2024, and January 2, 2023, respectively. The total fair value of RSUs vested for the years ended December 30, 2024, January 1, 2024, and January 2, 2023 was $30,575, $19,928, and $15,510, respectively.

[0000950170-25-024839:notes:255]
Stock Options

[0000950170-25-024839:notes:256]
As of December 30, 2024, stock options outstanding was 60. This is not material to the consolidated financial statements of the Company.

[0000950170-25-024839:notes:257]
Stock-based Compensation Expense and Unrecognized Compensation Costs

[0000950170-25-024839:notes:258]
Stock-based compensation expense recognized in the accompanying consolidated statements of operations was as follows:

[0000950170-25-024839:notes:259]
|  |  | For the Year Ended |  |
|  |  | December 30, 2024 |  |  | January 1, 2024 |  |  | January 2, 2023 |  |
|  |  | (In thousands) |  |
| Cost of goods sold |  | $ | 9,342 |  |  | $ | 7,455 |  |  | $ | 5,846 |  |
| Selling and marketing |  |  | 3,845 |  |  |  | 3,205 |  |  |  | 2,749 |  |
| General and administrative |  |  | 15,322 |  |  |  | 11,088 |  |  |  | 9,808 |  |
| Research and development |  |  | 1,271 |  |  |  | 1,139 |  |  |  | 1,122 |  |
| Total |  | $ | 29,780 |  |  | $ | 22,887 |  |  | $ | 19,525 |  |

[0000950170-25-024839:notes:260]
A summary of total unrecognized compensation costs as of December 30, 2024 was as follows:

[0000950170-25-024839:notes:261]
|  |  | Unrecognized Stock-BasedCompensation Cost |  |  | Remaining Weighted AverageRecognition Period |  |
|  |  | (In thousands) |  |  | (In years) |  |
| RSU awards |  | $ | 42,838 |  |  |  | 4.9 |  |
| PRU awards |  |  | 12,418 |  |  |  | 1.6 |  |
| Total |  | $ | 55,256 |  |  |  |  |


## us-gaap:FairValueDisclosuresTextBlock

[0000950170-25-024839:notes:262]
(13)
Fair Value Measures

[0000950170-25-024839:notes:263]
The Company measures at fair value its financial and non-financial assets by using a fair value hierarchy that prioritizes the inputs to valuation techniques used to measure fair value. Fair value is the price that would be received to sell an asset or paid to transfer a liability in an orderly transaction between market participants at the measurement date, essentially an exit price, based on the highest and best use of the asset or liability.

[0000950170-25-024839:notes:264]
The carrying amount and estimated fair value of the Company’s financial instruments were as follows:

[0000950170-25-024839:notes:265]
|  |  | As of December 30, 2024 |  |  | As of January 1, 2024 |  |
|  |  | Carrying Amount |  |  | Fair Value |  |  | Carrying Amount |  |  | Fair Value |  |
|  |  | (In thousands) |  |
| Derivative assets, current |  | $ | 1,765 |  |  | $ | 1,765 |  |  | $ | 3,282 |  |  | $ | 3,282 |  |
| Derivative assets, non-current |  |  | 1,326 |  |  |  | 1,326 |  |  |  | — |  |  |  | — |  |
| Derivative liabilities, current |  |  | 667 |  |  |  | 667 |  |  |  | 297 |  |  |  | 297 |  |
| Derivative liabilities, non-current |  |  | — |  |  |  | — |  |  |  | 1,476 |  |  |  | 1,476 |  |
| Senior Notes due March 2029 |  |  | 496,638 |  |  |  | 464,325 |  |  |  | 495,915 |  |  |  | 455,035 |  |
| Term Loan due May 2030 |  |  | 339,205 |  |  |  | 346,930 |  |  |  | 341,921 |  |  |  | 351,743 |  |
| ABL Revolving Loans |  |  | 80,000 |  |  |  | 80,000 |  |  |  | 80,000 |  |  |  | 80,000 |  |
| Other loan |  |  | 2,311 |  |  |  | 2,311 |  |  |  | — |  |  |  | — |  |

[0000950170-25-024839:notes:266]
The fair value of the derivative instruments was determined using pricing models developed based on the 1-month CME Term SOFR swap rate, foreign currency exchange rates, and other observable market data, including quoted market prices, as appropriate using Level 2 inputs. The values were adjusted to reflect non-performance risk of both the counterparty and the Company, as necessary.

[0000950170-25-024839:notes:267]
The fair value of the long-term debt was estimated based on quoted market prices or discounting the debt over its life using current market rates for similar debt as of December 30, 2024 and January 1, 2024, which are considered Level 2 inputs.

[0000950170-25-024839:notes:268]
The fair value of plan assets in the defined benefit plan of $23,297 and $23,249 as of December 30, 2024 and January 1, 2024, respectively, were not included in the table above and was estimated based on quoted market prices of the securities that are actively traded and price quotes that are readily available, which are considered Level 1 inputs.

[0000950170-25-024839:notes:269]
As of December 30, 2024 and January 1, 2024, the Company’s other financial instruments included cash and cash equivalents, accounts receivable, contract assets, accounts payable, and contract liabilities. The carrying amount of these instruments approximates fair value.

[0000950170-25-024839:notes:270]
The majority of the Company’s non-financial assets and liabilities, which include goodwill, intangible assets, inventories, and property, plant, and equipment, are not required to be carried at fair value on a recurring basis. However, if certain triggering events occur (or are tested at least annually in the case of goodwill) such that a non-financial instrument is required to be evaluated for impairment, based upon a comparison of the non-financial instrument’s fair value to its carrying value, an impairment is recorded to reduce the carrying value to the fair value, if the carrying value exceeds the fair value.

[0000950170-25-024839:notes:271]
As of December 30, 2024 and January 1, 2024, the Company’s goodwill balance related to its RF&S Components reporting unit of $31,300 and $63,900, respectively, was measured at fair value on a nonrecurring basis. The Company recorded a non-cash goodwill impairment charge of $32,600 and $44,100 related to its RF&S Components reporting unit during the years ended December 30, 2024 and January 1, 2024, respectively. The fair value of goodwill was determined using both a DCF and a market approach, which are considered Level 3 inputs. The Company used risk adjusted discount rate of 12% to discount the expected future cash flows in both 2024 and 2023. There was no impairment of long-lived assets recognized for the years ended December 30, 2024, January 1, 2024, and January 2, 2023.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0000950170-25-024839:notes:272]
(14)
Commitments and Contingencies

[0000950170-25-024839:notes:273]
Legal Matters

[0000950170-25-024839:notes:274]
The Company is subject to various legal matters, which it considers normal for its business activities. While the Company currently believes that the amount of any reasonably possible loss for known matters would not be material to the Company’s financial condition, the outcome of these actions is inherently difficult to predict. In the event of an adverse outcome, the ultimate potential loss could have a material adverse effect on the Company’s financial condition or results of operations in a particular period. The Company has accrued amounts for its loss contingencies which are probable and estimable as of December 30, 2024 and January 1, 2024 and included as a component of other current liabilities. However, these amounts are not material to the consolidated financial statements of the Company.

[0000950170-25-024839:notes:275]
Offset Agreements

[0000950170-25-024839:notes:276]
The Company has and may continue to enter into industrial cooperation agreements, sometimes referred to as offset agreements, as a condition to obtaining orders for products and services from customers in foreign countries. These agreements are intended to promote investment in the applicable country, and the Company’s obligations under these agreements may be satisfied through activities that do not require the Company to use cash, including transferring technology or providing manufacturing and other consulting support. The obligations under these agreements may also be satisfied through the use of cash for activities such as purchasing supplies from in-country vendors, setting up support centers, research and development investments, acquisitions, and building or leasing facilities for in-country operations. The amount of the offset requirement is determined by contract value awarded and negotiated percentages with customers. As of December 30, 2024, the Company had outstanding offset agreements of approximately $27,268, some of which extend through 2028. Offset programs usually extend over several years and in some cases provide for penalties in the event the Company fails to perform in accordance with contract requirements. To date, the Company has not been obligated to pay any such penalties.

[0000950170-25-024839:notes:277]
Supplier Finance Program Obligations

[0000950170-25-024839:notes:278]
The Company has agreements with financial institutions to facilitate payments to certain suppliers. Under the terms of the agreements, the Company confirms the validity of each supplier invoice to the respective financial institution upon receipt. The supplier receives payment from the financial institution, and the Company pays the financial institution based on the terms negotiated, which generally range from 160 days to 360 days. Liabilities associated with these agreements are recorded in accounts payable on the consolidated balance sheets and amounted to $17,218 and $18,832 as of December 30, 2024 and January 1, 2024, respectively.

[0000950170-25-024839:notes:279]
The details of the outstanding obligations confirmed as valid under the Company’s supplier finance program are as follows:

[0000950170-25-024839:notes:280]
|  |  | For the Year Ended December 30, 2024 |  |
|  |  | (In thousands) |  |
| Confirmed obligations outstanding at beginning of year |  | $ | 18,832 |  |
| Invoices confirmed during the year |  |  | 22,887 |  |
| Confirmed invoices paid during the year |  |  | (24,983 | ) |
| Effect of foreign currency exchange rates |  |  | 482 |  |
| Confirmed obligations outstanding at end of year |  | $ | 17,218 |  |


## us-gaap:EarningsPerShareTextBlock

[0000950170-25-024839:notes:281]
(15)
Earnings (Loss) Per Share

[0000950170-25-024839:notes:282]
The reconciliation of the numerator and denominator used to calculate basic earnings (loss) per share and diluted earnings (loss) per share is as follows:

[0000950170-25-024839:notes:283]
|  |  | For the Year Ended |  |
|  |  | December 30, 2024 |  |  | January 1, 2024 |  |  | January 2, 2023 |  |
|  |  | (In thousands, except per share amounts) |  |
| Net income (loss) |  | $ | 56,299 |  |  | $ | (18,718 | ) |  | $ | 94,583 |  |
| Basic weighted average shares |  |  | 101,781 |  |  |  | 102,744 |  |  |  | 102,074 |  |
| Dilutive effect of PRUs, RSUs, and stock options |  |  | 2,317 |  |  |  | — |  |  |  | 1,791 |  |
| Dilutive effect of outstanding warrants |  |  | — |  |  |  | — |  |  |  | 1 |  |
| Diluted shares |  |  | 104,098 |  |  |  | 102,744 |  |  |  | 103,866 |  |
| Earnings (loss) per share: |  |  |  |  |  |  |  |  |  |
| Basic earnings (loss) per share |  | $ | 0.55 |  |  | $ | (0.18 | ) |  | $ | 0.93 |  |
| Diluted earnings (loss) per share |  |  | 0.54 |  |  |  | (0.18 | ) |  |  | 0.91 |  |

[0000950170-25-024839:notes:284]
For the years ended December 30, 2024 and January 2, 2023, PRUs, RSUs, and stock options to purchase 158 and 535 shares of common stock, respectively, were not included in the computation of diluted earnings per share. The PRUs were not included in the computation of diluted earnings per share because the performance conditions had not been met, and for the RSUs and stock options, the options’ exercise prices or the total expected proceeds under the treasury stock method was greater than the average market price of common stock during the applicable year and, as a result, the impact would be anti-dilutive.

[0000950170-25-024839:notes:285]
For the year ended January 1, 2024, potential shares of common stock, consisting of stock options to purchase 60 shares of common stock at exercise prices ranging from $11.83 to $16.60 per share, 3,527 RSUs, and 668 PRUs were not included in the computation of diluted earnings per share because the Company incurred a net loss and as a result, the impact would be anti-dilutive.


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0000950170-25-024839:notes:286]
(16)
Restructuring Charges

[0000950170-25-024839:notes:287]
On February 8, 2023, the Company announced a consolidation plan, pursuant to which the Company ceased operations at three of its manufacturing facilities during the year ended January 1, 2024 and consolidated the operations of those facilities into other Company facilities. The three manufacturing facilities are PCB operations located in Anaheim and Santa Clara, California, and Hong Kong. The Company recorded $27,439 of restructuring charges and $6,032 of accelerated depreciation since the February 8, 2023 announcement.

[0000950170-25-024839:notes:288]
In addition to this consolidation plan, the Company recognized employee separation, contract termination, and other costs during the year ended December 30, 2024 in connection with other global realignment restructuring efforts. Contract termination and other costs primarily represented plant closure costs.

[0000950170-25-024839:notes:289]
Restructuring costs by reportable segment were as follows:

[0000950170-25-024839:notes:290]
|  |  | For the Year Ended |  |
|  |  | December 30, 2024 |  |  | January 1, 2024 |  |  | January 2, 2023 |  |
|  |  | Employee Separation/Severance |  |  | Contract Terminationand Other Costs |  |  | Total |  |  | Employee Separation/Severance |  |  | Contract Terminationand Other Costs |  |  | Total |  |  | Employee Separation/Severance |  |  | Contract Terminationand Other Costs |  |  | Total |  |
|  |  | (In thousands) |  |
| PCB |  | $ | 466 |  |  | $ | 7,640 |  |  | $ | 8,106 |  |  | $ | 13,780 |  |  | $ | 9,877 |  |  | $ | 23,657 |  |  | $ | 2,510 |  |  | $ | 1,036 |  |  | $ | 3,546 |  |
| RF&S Components |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 14 |  |  |  | — |  |  |  | 14 |  |  |  | — |  |  |  | — |  |  |  | — |  |
| Corporate and Other |  |  | 2,411 |  |  |  | 683 |  |  |  | 3,094 |  |  |  | 305 |  |  |  | 376 |  |  |  | 681 |  |  |  | 31 |  |  |  | 517 |  |  |  | 548 |  |
| Total |  | $ | 2,877 |  |  | $ | 8,323 |  |  | $ | 11,200 |  |  | $ | 14,099 |  |  | $ | 10,253 |  |  | $ | 24,352 |  |  | $ | 2,541 |  |  | $ | 1,553 |  |  | $ | 4,094 |  |

[0000950170-25-024839:notes:291]
Accrued restructuring costs are included as a component of other current liabilities in the consolidated balance sheet. The utilization of the accrued restructuring costs was as follows:

[0000950170-25-024839:notes:292]
|  |  | Employee Separation/Severance |  |  | Contract Terminationand Other Costs |  |  | Total |  |
|  |  | (In thousands) |  |
| Accrued as of January 2, 2023 |  | $ | 2,510 |  |  | $ | 3 |  |  | $ | 2,513 |  |
| Charged to expense |  |  | 14,099 |  |  |  | 10,253 |  |  |  | 24,352 |  |
| Amount paid, net of government contributions eligible for offsetting |  |  | (15,615 | ) |  |  | (10,071 | ) |  |  | (25,686 | ) |
| Accrued as of January 1, 2024 |  |  | 994 |  |  |  | 185 |  |  |  | 1,179 |  |
| Charged to expense |  |  | 2,877 |  |  |  | 8,323 |  |  |  | 11,200 |  |
| Amount paid |  |  | (794 | ) |  |  | (8,099 | ) |  |  | (8,893 | ) |
| Accrued as of December 30, 2024 |  | $ | 3,077 |  |  | $ | 409 |  |  | $ | 3,486 |  |


## us-gaap:PreferredStockTextBlock

[0000950170-25-024839:notes:293]
(17)
Preferred Stock

[0000950170-25-024839:notes:294]
The Board of Directors has the authority, without action by stockholders, to designate and issue preferred stock in one or more series. The Board of Directors may also designate the rights, preferences, and privileges of each series of preferred stock, any or all of which may be superior to the rights of the common stock. As of December 30, 2024, no shares of preferred stock were outstanding.
