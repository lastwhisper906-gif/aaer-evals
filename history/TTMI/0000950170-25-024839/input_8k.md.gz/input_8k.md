# TTMI 8-K — 0001193125-25-020820 filed 2025-02-05

## item codes, every 8-K on or before 2025-02-21

- 2025-02-18 0001193125-25-028278 — 5.02, 7.01, 9.01
- 2025-02-05 0001193125-25-020820 — 2.02, 9.01
- 2024-10-30 0001193125-24-247537 — 2.02, 9.01
- 2024-08-01 0001193125-24-191480 — 1.01, 2.03
- 2024-07-31 0001193125-24-189522 — 2.02, 9.01
- 2024-06-14 0001193125-24-161581 — 1.01, 2.03
- 2024-06-10 0001193125-24-158390 — 5.03, 9.01 — amendment of 0001193125-24-136138
- 2024-05-10 0001193125-24-136138 — 5.02, 5.03, 5.07, 7.01, 9.01
- 2024-05-01 0001193125-24-126373 — 2.02, 9.01
- 2024-02-07 0001193125-24-026126 — 2.02, 9.01
- 2023-11-01 0001193125-23-267755 — 2.02, 9.01
- 2023-08-02 0001193125-23-201189 — 5.02, 7.01, 9.01
- 2023-08-02 0001193125-23-201186 — 2.02, 9.01
- 2023-06-20 0001193125-23-169669 — 1.01, 2.03, 7.01, 9.01
- 2023-05-30 0001193125-23-156582 — 1.01, 2.03, 3.03, 7.01, 9.01
- 2023-05-12 0001193125-23-142632 — 5.07
- 2023-05-03 0001193125-23-134390 — 2.02, 8.01, 9.01
- 2023-03-09 0001193125-23-066103 — 7.01, 9.01
- 2023-02-08 0001193125-23-028382 — 2.02, 2.05, 7.01, 9.01
- 2022-11-03 0001193125-22-276659 — 2.02, 9.01 — amendment of 0001193125-22-275849
- 2022-11-02 0001193125-22-275849 — 2.02, 9.01
- 2022-09-08 0001193125-22-241001 — 9.01 — amendment of 0001193125-22-182826
- 2022-08-03 0001193125-22-211262 — 2.02, 9.01
- 2022-06-27 0001193125-22-182826 — 2.01, 7.01, 9.01
- 2022-05-16 0001193125-22-151684 — 5.07
- 2022-05-04 0001193125-22-140455 — 2.02, 9.01
- 2022-04-18 0001193125-22-108017 — 1.01, 7.01, 9.01
- 2022-03-01 0001193125-22-059877 — 7.01, 9.01
- 2022-02-09 0001193125-22-032669 — 2.02, 9.01
- 2021-10-27 0001193125-21-309324 — 2.02, 9.01
- 2021-07-28 0001193125-21-227406 — 2.02, 9.01
- 2021-06-14 0001193125-21-189568 — 5.02, 9.01
- 2021-05-13 0001193125-21-159545 — 2.02, 5.02, 5.07, 9.01
- 2021-04-28 0001193125-21-136849 — 2.02, 9.01
- 2021-03-16 0001193125-21-083011 — 1.02, 8.01
- 2021-03-10 0001193125-21-076246 — 1.01, 2.03, 3.03, 7.01, 9.01
- 2021-02-24 0001193125-21-054812 — 7.01, 9.01
- 2021-02-23 0001193125-21-051549 — 7.01, 9.01
- 2021-02-03 0001193125-21-027322 — 2.02, 8.01, 9.01
- 2020-12-15 0001193125-20-318208 — 7.01, 9.01
- 2020-10-28 0001193125-20-279980 — 2.02, 9.01
- 2020-09-04 0001193125-20-239645 — 5.02
- 2020-07-29 0001193125-20-203110 — 2.02, 9.01
- 2020-05-08 0001193125-20-137566 — 5.07
- 2020-05-04 0001193125-20-131366 — 7.01, 9.01
- 2020-04-29 0001193125-20-126358 — 2.05, 7.01, 9.01
- 2020-04-29 0001193125-20-126117 — 2.02, 9.01
- 2020-04-23 0001193125-20-117365 — 2.01, 7.01, 9.01
- 2020-02-05 0001193125-20-025365 — 2.02, 9.01
- 2020-01-31 0001193125-20-021278 — 5.02
- 2020-01-22 0001193125-20-012011 — 1.01, 7.01, 9.01
- 2019-10-30 0001193125-19-278973 — 2.02, 9.01
- 2019-08-19 0001193125-19-224091 — 5.02, 9.01
- 2019-07-31 0001193125-19-208689 — 2.02, 9.01
- 2019-07-24 0001193125-19-201401 — 1.01, 2.03
- 2019-06-13 0001193125-19-171943 — 7.01, 9.01
- 2019-06-06 0001193125-19-167332 — 1.01, 2.03, 3.03, 7.01, 9.01
- 2019-05-09 0001193125-19-143113 — 5.07
- 2019-05-01 0001193125-19-132977 — 2.02, 9.01
- 2019-02-06 0001193125-19-029540 — 2.02, 9.01
- 2019-01-15 0001193125-19-009142 — 2.02, 9.01
- 2018-10-30 0001193125-18-312212 — 2.02, 9.01
- 2018-10-22 0001193125-18-303926 — 5.02
- 2018-09-06 0001193125-18-268231 — 5.02, 9.01
- 2018-08-01 0001193125-18-234997 — 2.02, 9.01
- 2018-06-29 0001193125-18-209635 — 9.01 — amendment of 0001193125-18-120583
- 2018-05-29 0001193125-18-176976 — 7.01, 9.01
- 2018-05-10 0001193125-18-159394 — 5.07
- 2018-05-09 0001193125-18-157596 — 5.02
- 2018-05-02 0001193125-18-148650 — 2.02, 9.01
- 2018-04-18 0001193125-18-120583 — 1.01, 2.01, 2.03, 7.01, 9.01
- 2018-02-21 0001193125-18-052169 — 8.01, 9.01
- 2018-02-20 0001193125-18-050385 — 5.02, 9.01
- 2018-02-09 0001193125-18-036966 — 7.01, 9.01
- 2018-02-07 0001193125-18-034744 — 2.02, 9.01
- 2017-12-14 0001193125-17-369625 — 1.01, 2.03, 9.01
- 2017-12-04 0001193125-17-359439 — 1.01, 7.01, 9.01
- 2017-11-01 0001193125-17-329425 — 2.02, 9.01
- 2017-09-29 0001193125-17-298999 — 1.01, 2.03, 3.03, 7.01, 9.01
- 2017-09-15 0001193125-17-286491 — 7.01, 9.01
- 2017-09-11 0001193125-17-281193 — 7.01, 9.01
- 2017-09-06 0001193125-17-277536 — 7.01, 9.01
- 2017-08-02 0001193125-17-245823 — 2.02, 9.01
- 2017-05-18 0001193125-17-173896 — 5.02, 5.07
- 2017-05-08 0001193125-17-162548 — 2.02, 9.01
- 2017-03-01 0001193125-17-063931 — 1.01, 1.02, 5.02
- 2017-02-08 0001193125-17-034652 — 2.02, 9.01
- 2016-11-18 0001193125-16-772305 — 8.01, 9.01
- 2016-10-26 0001193125-16-747948 — 2.02, 9.01
- 2016-10-20 0001193125-16-742905 — 5.02
- 2016-10-05 0001193125-16-731552 — 5.02, 9.01
- 2016-09-27 0001193125-16-720828 — 1.01, 2.03, 7.01, 9.01
- 2016-07-27 0001193125-16-659983 — 2.02, 9.01
- 2016-05-23 0001193125-16-599342 — 7.01, 9.01
- 2016-05-18 0001193125-16-594656 — 5.02, 5.03, 5.07, 9.01
- 2016-04-27 0001171843-16-009432 — 2.02, 9.01
- 2016-03-08 0001193125-16-495457 — 5.03, 7.01, 9.01
- 2016-02-09 0001193125-16-454281 — 8.01, 9.01
- 2016-02-04 0001171843-16-007659 — 2.02, 9.01
- 2016-01-04 0001193125-16-418740 — 1.01, 9.01
- 2015-12-11 0001193125-15-400867 — 5.02, 9.01
- 2015-10-30 0001171843-15-005835 — 2.02, 7.01 — amendment of 0001171843-15-005766
- 2015-10-28 0001171843-15-005766 — 2.02, 9.01
- 2015-09-29 0001193125-15-331517 — 2.02, 2.05, 2.06, 9.01
- 2015-08-05 0001171843-15-004361 — 2.02, 9.01
- 2015-07-31 0001193125-15-272962 — 9.01 — amendment of 0001193125-15-210734
- 2015-06-02 0001193125-15-210734 — 1.01, 1.02, 2.01, 2.03, 7.01, 9.01
- 2015-05-29 0001193125-15-206622 — 1.01, 2.03, 9.01
- 2015-05-20 0001171843-15-002975 — 7.01, 9.01
- 2015-05-19 0001193125-15-193434 — 5.07, 9.01
- 2015-05-05 0001171843-15-002499 — 7.01, 9.01
- 2015-04-29 0001171843-15-002307 — 2.02, 9.01
- 2015-04-21 0001193125-15-139239 — 7.01, 9.01
- 2015-04-21 0001171843-15-002065 — 2.02, 9.01
- 2015-02-04 0001171843-15-000599 — 2.02, 9.01
- 2015-01-20 0001193125-15-014019 — 7.01, 9.01
- 2014-12-30 0001193125-14-457111 — 7.01, 9.01
- 2014-12-15 0001193125-14-442645 — 1.01, 9.01
- 2014-12-04 0001193125-14-433658 — 8.01, 9.01
- 2014-11-18 0001193125-14-415889 — 7.01, 9.01
- 2014-10-29 0001171843-14-005051 — 2.02, 9.01
- 2014-10-27 0001193125-14-383428 — 1.01, 9.01
- 2014-09-22 0001193125-14-348697 — 1.01, 7.01, 9.01
- 2014-08-05 0001193125-14-295808 — 1.01, 5.02, 9.01
- 2014-07-30 0001171843-14-003548 — 2.02, 9.01
- 2014-04-30 0001171843-14-002017 — 2.02, 9.01
- 2014-04-25 0001193125-14-160146 — 5.02, 5.07, 9.01
- 2014-04-10 0001171843-14-001656 — 2.02, 9.01
- 2014-03-04 0001193125-14-082534 — 4.01, 9.01
- 2014-02-05 0001171843-14-000553 — 2.02, 9.01
- 2014-01-14 0001193125-14-010922 — 1.01, 2.03, 3.02, 8.01, 9.01
- 2013-12-27 0001193125-13-486144 — 5.02, 9.01
- 2013-12-20 0001193125-13-481141 — 1.01, 1.02, 2.03, 3.02, 8.01, 9.01
- 2013-12-17 0001193125-13-476207 — 5.03
- 2013-10-30 0001193125-13-418572 — 2.02, 5.02, 9.01
- 2013-09-12 0001193125-13-365420 — 2.05
- 2013-08-14 0001193125-13-334349 — 7.01, 9.01
- 2013-08-01 0001171843-13-003138 — 2.02, 9.01
- 2013-06-25 0001193125-13-270725 — 5.02, 9.01
- 2013-05-02 0001171843-13-001746 — 2.02, 9.01
- 2013-04-29 0001193125-13-182083 — 5.02, 5.07, 9.01
- 2013-03-18 0001193125-13-111308 — 1.01, 7.01, 9.01
- 2013-03-06 0001193125-13-093625 — 5.02, 9.01
- 2013-03-01 0001193125-13-087439 — 2.02 — amendment of 0001171843-13-000414
- 2013-02-28 0001193125-13-084764 — 5.02
- 2013-02-05 0001171843-13-000414 — 2.02, 9.01
- 2013-01-31 0001193125-13-032848 — 5.02, 9.01
- 2013-01-17 0001193125-13-015928 — 7.01, 9.01
- 2013-01-16 0001193125-13-014581 — 2.02, 9.01
- 2012-12-11 0001193125-12-498644 — 5.02, 9.01
- 2012-11-15 0001193125-12-472451 — 7.01, 9.01
- 2012-11-01 0001171843-12-003890 — 2.02, 9.01
- 2012-09-19 0001193125-12-396969 — 1.01, 2.03, 7.01, 9.01
- 2012-09-11 0001193125-12-388130 — 7.01, 9.01
- 2012-07-31 0001171843-12-002829 — 2.02, 9.01
- 2012-05-15 0001193125-12-233501 — 7.01, 9.01
- 2012-05-01 0001171843-12-001574 — 2.02, 9.01
- 2012-04-27 0001193125-12-191623 — 5.07
- 2012-03-01 0001193125-12-090623 — 2.02 — amendment of 0001171843-12-000382
- 2012-02-07 0001171843-12-000382 — 2.02, 9.01
- 2012-01-19 0001193125-12-016588 — 5.02, 9.01
- 2011-11-15 0000950123-11-098812 — 7.01, 9.01
- 2011-11-02 0001171843-11-003248 — 2.02, 9.01
- 2011-09-28 0000950123-11-087344 — 7.01, 9.01
- 2011-09-19 0000950123-11-085128 — 5.02, 9.01
- 2011-09-15 0000950123-11-084704 — 5.07 — amendment of 0000950123-11-054296
- 2011-08-04 0001171843-11-002356 — 2.02, 9.01
- 2011-07-27 0000950123-11-068987 — 1.01, 2.03, 9.01
- 2011-06-21 0000950123-11-060477 — 7.01, 9.01
- 2011-06-06 0000950123-11-056971 — 5.03, 9.01
- 2011-05-26 0000950123-11-054296 — 5.07
- 2011-05-10 0000950123-11-048462 — 8.01, 9.01
- 2011-05-05 0001171843-11-001344 — 2.02, 9.01
- 2011-03-22 0000950123-11-027824 — 7.01, 9.01
- 2011-03-18 0000950123-11-026913 — 4.01
- 2011-03-18 0000950123-11-026910 — 4.01, 9.01 — amendment, the index does not say of what
- 2011-03-02 0000950123-11-020941 — 5.03, 9.01
- 2011-02-10 0001171843-11-000391 — 2.02, 9.01
- 2011-01-13 0000950123-11-002528 — 7.01, 9.01
- 2011-01-13 0000950123-11-002446 — 2.02, 9.01
- 2010-11-29 0000950123-10-109448 — 4.01, 9.01 — amendment, the index does not say of what
- 2010-11-17 0000950123-10-106706 — 4.01
- 2010-11-15 0000950123-10-105479 — 5.02, 9.01
- 2010-11-04 0001171843-10-002324 — 2.02, 9.01
- 2010-10-22 0000950123-10-095179 — 1.01, 9.01
- 2010-10-04 0000950123-10-090949 — 1.01, 5.03, 9.01
- 2010-08-05 0001171843-10-001587 — 2.02, 9.01
- 2010-08-05 0000950123-10-073258 — 1.01, 2.03, 9.01
- 2010-08-05 0000950123-10-073256 — 9.01 — amendment of 0000950123-10-034163
- 2010-07-12 0000950123-10-064794 — 5.02, 8.01, 9.01
- 2010-06-10 0000950123-10-057166 — 7.01, 9.01
- 2010-06-02 0000950123-10-055111 — 1.01, 5.07, 9.01
- 2010-05-06 0001171843-10-000819 — 2.02, 9.01
- 2010-04-26 0000950123-10-037806 — 8.01, 9.01 — amendment of 0000950123-10-034163
- 2010-04-13 0000950123-10-034163 — 1.01, 2.01, 2.03, 5.02, 7.01, 9.01
- 2010-03-30 0000950123-10-030123 — 1.01, 5.02, 9.01
- 2010-03-24 0000950123-10-027317 — 1.01, 5.02, 9.01
- 2010-03-16 0000950123-10-024853 — 7.01, 9.01 — amendment of 0001171843-10-000140
- 2010-03-15 0000950123-10-024637 — 5.07
- 2010-02-04 0001171843-10-000140 — 2.02, 9.01
- 2010-02-02 0000950123-10-007780 — 8.01, 9.01
- 2010-01-13 0000950123-10-002245 — 7.01, 9.01
- 2009-12-23 0000950123-09-073069 — 1.01, 9.01
- 2009-12-15 0000950123-09-070868 — 8.01, 9.01
- 2009-11-16 0000950123-09-062630 — 1.01, 7.01, 9.01
- 2009-11-04 0001171843-09-001103 — 2.02, 9.01
- 2009-09-04 0000950123-09-041133 — 2.05, 9.01
- 2009-07-29 0001171843-09-000743 — 2.02, 9.01
- 2009-06-09 0000950123-09-012507 — 7.01, 9.01
- 2009-04-30 0001171843-09-000427 — 2.02, 9.01
- 2009-04-28 0001362310-09-005960 — 8.01
- 2009-02-19 0001362310-09-002454 — 5.03, 9.01
- 2009-02-10 0001171843-09-000123 — 2.02, 9.01
- 2009-01-16 0000950153-09-000040 — 2.05, 9.01
- 2009-01-08 0000950153-09-000023 — 7.01, 9.01
- 2008-10-29 0001157523-08-008533 — 2.02, 9.01
- 2008-07-29 0001157523-08-005998 — 2.02, 9.01
- 2008-05-22 0000950153-08-001035 — 1.01, 2.03, 3.02, 9.01
- 2008-05-22 0000950153-08-001034 — 7.01, 9.01
- 2008-05-15 0000950153-08-000987 — 1.01, 1.02, 2.03, 3.02, 9.01
- 2008-04-30 0001157523-08-003483 — 2.02, 9.01
- 2008-02-07 0001157523-08-001077 — 2.02, 9.01
- 2008-01-08 0000950153-08-000033 — 7.01, 9.01
- 2007-11-15 0000950153-07-002440 — 7.01, 9.01
- 2007-11-14 0000950153-07-002426 — 7.01, 9.01
- 2007-11-14 0000950153-07-002421 — 5.03, 9.01
- 2007-10-31 0001157523-07-010491 — 2.02, 9.01
- 2007-10-02 0000950153-07-002094 — 7.01, 9.01
- 2007-07-31 0000950153-07-001622 — 2.02, 9.01
- 2007-06-13 0000950153-07-001327 — 7.01, 9.01
- 2007-05-02 0000950153-07-000941 — 2.02, 9.01
- 2007-04-12 0000950153-07-000763 — 5.02, 9.01
- 2007-02-15 0000950153-07-000339 — 2.02, 9.01
- 2007-01-11 0000950153-07-000076 — 7.01, 9.01
- 2007-01-10 0000950153-07-000071 — 2.01, 9.01 — amendment, the index does not say of what
- 2006-12-11 0000950153-06-002967 — 2.05, 9.01
- 2006-11-15 0000950153-06-002843 — 7.01, 9.01
- 2006-11-14 0000950153-06-002837 — 7.01, 9.01
- 2006-11-02 0000950153-06-002682 — 1.01, 1.02, 2.03, 9.01
- 2006-11-01 0000950153-06-002668 — 2.02, 9.01
- 2006-10-30 0000950124-06-006210 — 2.01, 9.01
- 2006-08-04 0000950153-06-002025 — 1.01, 9.01
- 2006-07-26 0000950153-06-001937 — 2.02, 9.01
- 2006-06-28 0000950153-06-001716 — 1.01, 9.01
- 2006-06-13 0000950153-06-001597 — 7.01, 9.01
- 2006-04-26 0000950153-06-001079 — 2.02, 9.01
- 2006-02-08 0001104659-06-006985 — 2.02, 9.01
- 2006-01-12 0001104659-06-001893 — 7.01, 9.01
- 2005-12-05 0001104659-05-058918 — 1.01, 5.02, 9.01
- 2005-10-26 0001104659-05-050306 — 2.02, 9.01
- 2005-09-20 0001104659-05-044954 — 8.01
- 2005-08-30 0001104659-05-042053 — 3.03, 8.01, 9.01
- 2005-07-27 0001104659-05-034437 — 2.02, 5.02, 9.01
- 2005-07-21 0001104659-05-033462 — 1.01, 1.02, 2.03, 9.01
- 2005-06-13 0001104659-05-027969 — 8.01
- 2005-06-08 0001104659-05-027364 — 7.01, 9.01
- 2005-05-17 0001104659-05-024118 — 7.01, 9.01
- 2005-05-12 0001104659-05-022993 — 7.01, 9.01
- 2005-05-11 0001104659-05-022606 — 1.01, 9.01
- 2005-05-02 0001104659-05-019649 — 2.02, 5.02, 9.01
- 2005-04-26 0001104659-05-018233 — 7.01, 9.01
- 2005-02-08 0001104659-05-004642 — 2.02, 9.01
- 2005-01-12 0001104659-05-001194 — 7.01, 9.01
- 2004-12-22 0001104659-04-040933 — 5.02
- 2004-12-08 0001104659-04-038850 — 7.01, 9.01
- 2004-10-26 0001104659-04-031931 — 2.02, 9.01
- 2004-10-01 0001104659-04-029361 — 5.02
- 2004-08-02 0001104659-04-021785 — 9
- 2004-07-29 0001104659-04-021529 — 12
- 2004-05-06 0001104659-04-012742 — 9
- 2004-04-26 0001104659-04-011228 — 12
- 2004-02-03 0001104659-04-002424 — 9
- 2004-01-28 0001104659-04-001980 — 12
- 2004-01-09 0001104659-04-000457 — 9
- 2003-10-21 0001104659-03-023304 — 12
- 2003-07-29 0001104659-03-015999 — 12
- 2003-05-08 0001104659-03-008647 — 9
- 2003-05-08 0001104659-03-008462 — 9
- 2003-05-01 0001104659-03-007866 — 9
- 2003-03-07 0001104659-03-003816 — 2, 7 — amendment of 0000950153-02-002190
- 2002-12-27 0000950153-02-002190 — 2, 7
- 2002-05-17 0000912057-02-021145 — 4, 7
- 2001-12-21 0000912057-01-544281 — 7
- 2000-10-27 0000912057-00-046109 — 5

## late-filing notifications on or before 2025-02-21

- none on or before 2025-02-21

## item 2.02 — earnings release, exhibit 99.1

[0001193125-25-020820:8k_2_02:1]
EX-99.1
2
d663986dex991.htm
EX-99.1

[0001193125-25-020820:8k_2_02:2]
EX-99.1

[0001193125-25-020820:8k_2_02:3]
EXHIBIT 99.1

[0001193125-25-020820:8k_2_02:4]
|  |  |  |  | Contact: Sameer Desai, Vice President, Corporate Development & Investor Relations Sameer.desai@ttmtech.com 714-327-3050 |

[0001193125-25-020820:8k_2_02:5]
TTM Technologies, Inc. Reports Fourth Quarter and Fiscal Year 2024 Results

[0001193125-25-020820:8k_2_02:6]
Santa Ana, CA – February 5, 2025– TTM Technologies, Inc. (NASDAQ: TTMI) (“TTM”), a leading global manufacturer of technology
solutions including mission systems, radio frequency (“RF”) components and RF microwave/microelectronic assemblies and quick-turn and technologically advanced printed circuit boards (“PCB”s) today reported results for the fourth
quarter and fiscal 2024, which ended on December 30, 2024.

[0001193125-25-020820:8k_2_02:7]
Fourth Quarter 2024 Highlights

[0001193125-25-020820:8k_2_02:8]
|  | • |  | Net sales were $651.0 million |

[0001193125-25-020820:8k_2_02:9]
|  | • |  | GAAP net income of $5.2 million, or $0.05 per diluted share, inclusive of a $14.1 million pre-tax, non-operational, foreign exchange gain |

[0001193125-25-020820:8k_2_02:10]
|  | • |  | Non-GAAP net income was $62.8 million, or $0.60 per diluted share, inclusive of a $14.1 million pre-tax, non-operational, foreign exchange gain |

[0001193125-25-020820:8k_2_02:11]
|  | • |  | Cash flow from operations was $86.1 million, or 13.2% of sales |

[0001193125-25-020820:8k_2_02:12]
|  | • |  | Book to bill of 1.09 for the fourth quarter |

[0001193125-25-020820:8k_2_02:13]
|  | • |  | A&D program backlog a record $1.56 billion |

[0001193125-25-020820:8k_2_02:14]
|  | • |  | Data Center Computing revenues a record 22% of total company revenues |

[0001193125-25-020820:8k_2_02:15]
Fourth Quarter 2024 GAAP Financial Results

[0001193125-25-020820:8k_2_02:16]
Net sales for
the fourth quarter of 2024 were $651.0 million, compared to $569.0 million in the fourth quarter of 2023.

[0001193125-25-020820:8k_2_02:17]
GAAP operating income for the fourth
quarter of 2024 was $9.0 million, inclusive of a $32.6 million goodwill impairment charge related to the RF&S Components segment compared to GAAP operating income for the fourth quarter of 2023 of $34.6 million.

[0001193125-25-020820:8k_2_02:18]
GAAP net income for the fourth quarter of 2024 was $5.2 million, or $0.05 per diluted share, inclusive of a $32.6 million goodwill impairment charge
related to the RF&S Components segment, compared to GAAP net income for the fourth quarter of 2023 of $17.3 million, or $0.17 per diluted share. GAAP net income for the fourth quarter of 2024 included a $14.1 million pre-tax foreign exchange gain, compared to a $7.0 million pre-tax foreign exchange loss in the fourth quarter of 2023.

[0001193125-25-020820:8k_2_02:19]
Fourth Quarter 2024 Non-GAAP Financial Results

[0001193125-25-020820:8k_2_02:20]
On a non-GAAP basis, net income for the fourth quarter of 2024 was $62.8 million, or $0.60 per diluted share. This
compares to non-GAAP net income of $43.0 million, or $0.41 per diluted share, for the fourth quarter of 2023. Non-GAAP net income for the fourth quarter of 2024
included a $14.1 million pre-tax foreign exchange gain, compared to a $7.0 million pre-tax foreign exchange loss in the fourth quarter of 2023.

[0001193125-25-020820:8k_2_02:21]
Adjusted EBITDA in the fourth quarter of 2024 was $108.7 million, or 16.7% of sales compared to adjusted EBITDA of $80.9 million, or 14.2% of sales
for the fourth quarter of 2023. Adjusted EBITDA for the fourth quarter of 2024 included a $14.1 million foreign exchange gain, compared to a $7.0 million foreign exchange loss in the fourth quarter of 2023.

[0001193125-25-020820:8k_2_02:22]
“We delivered a solid quarter with revenues and non-GAAP EPS above the high end of the guided range. Revenues
reflected the fourth consecutive quarter of year on year growth due to demand strength in our Aerospace and Defense, Data Center Computing and Networking end markets, the latter two being driven by generative AI,” said Tom Edman, CEO of TTM.
“Operating margins were double digit for the second consecutive quarter and reflected continued solid execution. In addition, cash flow from operations was a healthy 13.2% of revenues enabling the company to maintain a solid balance sheet with
a net leverage ratio of 1.2x,” concluded Mr. Edman.

[0001193125-25-020820:8k_2_02:23]
|  |  |  |  | Contact: Sameer Desai, Vice President, Corporate Development & Investor Relations Sameer.desai@ttmtech.com 714-327-3050 |

[0001193125-25-020820:8k_2_02:24]
Full Year 2024 Results

[0001193125-25-020820:8k_2_02:25]
Net sales for 2024 increased to $2.4 billion from $2.2 billion in 2023, a 9.4% increase.

[0001193125-25-020820:8k_2_02:26]
GAAP operating income for 2024 was $116.0 million, inclusive of a $32.6 million goodwill impairment charge related to the RF&S Components
segment. This compares to a GAAP operating income for 2023 of $42.3 million, inclusive of a $44.1 million goodwill impairment charge related to the RF&S Components segment.

[0001193125-25-020820:8k_2_02:27]
GAAP net income for 2024 was $56.3 million, or $0.54 per diluted share, inclusive of a $32.6 million goodwill impairment charge related to the
RF&S Components segment. This compares to a GAAP net loss for 2023 of $18.7 million, or ($0.18) per diluted share, inclusive of a $44.1 million goodwill impairment charge related to the RF&S Components segment.

[0001193125-25-020820:8k_2_02:28]
On a non-GAAP basis, net income for 2024 was $178.4 million, or $1.71 per diluted share. This compares to 2023 non-GAAP net income of $139.5 million, or $1.33 per diluted share.

[0001193125-25-020820:8k_2_02:29]
Adjusted EBITDA for 2024 was
$352.5 million, or 14.4% of net sales, compared to $298.2 million, or 13.4% of net sales, for 2023.

[0001193125-25-020820:8k_2_02:30]
“Our employees delivered outstanding
results in 2024 for TTM. Revenue growth of 9.4% was driven by generative AI in the Data Center Computing market and continued strength in the Aerospace and Defense market. Revenue fall through, favorable product mix, and improved execution helped to
grow margins and non-GAAP EPS year on year,” continued Edman. “We continue to execute on our strategic priorities by growing Aerospace and Defense revenues 12% year on year, opening a new
manufacturing facility in Penang, Malaysia supporting customer supply chain resiliency needs and starting construction on a new ultra-HDI manufacturing facility in Syracuse, New York. Finally, in 2024, we
generated $236.9 million in operating cash flow which enabled us to strengthen our balance sheet, refinance our Term Loan, and return $34.5 million of capital to our shareholders through our stock buy back program.”

[0001193125-25-020820:8k_2_02:31]
Business Outlook

[0001193125-25-020820:8k_2_02:32]
For the first quarter of 2025,
TTM estimates that revenues will be in the range of $600 million to $640 million, and non-GAAP net income will be in the range of $0.37 to $0.43 per diluted share.

[0001193125-25-020820:8k_2_02:33]
With respect to the Company’s outlook for non-GAAP net income per diluted share, we are unable to predict with
reasonable certainty or without unreasonable effort certain items that may affect a comparable measure calculated and presented in accordance with GAAP. Our expected non-GAAP net income per diluted share
excludes primarily the future impact of restructuring actions, impairment charges, unusual gains and losses including but not limited to unrealized foreign exchange translation, and tax adjustments. These reconciling items are highly variable and
difficult to predict due to various factors outside of management’s control and could have a material impact on our future period net income per diluted share calculated and presented in accordance with GAAP. Accordingly, a reconciliation of non-GAAP net income per diluted share to a comparable measure calculated and presented in accordance with GAAP has not been provided because the Company is unable to provide such reconciliation without unreasonable
effort. For the same reasons, TTM is unable to address the probable significance of the information.

[0001193125-25-020820:8k_2_02:34]
|  |  |  |  | Contact: Sameer Desai, Vice President, Corporate Development & Investor Relations Sameer.desai@ttmtech.com 714-327-3050 |

[0001193125-25-020820:8k_2_02:35]
Live Webcast/Conference Call

[0001193125-25-020820:8k_2_02:36]
TTM will host a conference call and webcast to discuss fourth quarter and fiscal year 2024 results and the first quarter 2025 outlook on Wednesday,
February 5, 2025, at 4:30 p.m. Eastern Time (1:30 p.m. Pacific Time). The conference call will include forward-looking statements.

[0001193125-25-020820:8k_2_02:37]
Access to the
conference call is available by clicking on the registration link TTM Technologies, Inc. fourth quarter and fiscal year 2024 conference call. Registering participants will receive dial in information and a unique PIN to join the call.
Participants can register at any time up to the start of the conference call. The conference call will also be simulcast on the company’s website, and can be accessed by clicking on the link TTM Technologies Inc. fourth quarter and fiscal
year 2024 webcast. The webcast will remain accessible for one week following the live event.

[0001193125-25-020820:8k_2_02:38]
To Access a Replay of the Webcast

[0001193125-25-020820:8k_2_02:39]
The replay of the webcast will remain accessible for one week following the live event on TTM’s website at TTM Technologies Inc. fourth quarter and
fiscal year 2024 webcast.

[0001193125-25-020820:8k_2_02:40]
About TTM

[0001193125-25-020820:8k_2_02:41]
TTM
Technologies, Inc. is a leading global manufacturer of technology solutions, including mission systems, radio frequency (“RF”) components, RF microwave/microelectronic assemblies, and quick-turn and technologically advanced printed circuit
boards (“PCB”s). TTM stands for time-to-market, representing how TTM’s time-critical, one-stop manufacturing
services enable customers to shorten the time required to develop new products and bring them to market. Additional information can be found at www.ttm.com.

[0001193125-25-020820:8k_2_02:42]
Forward-Looking Statements

[0001193125-25-020820:8k_2_02:43]
The preliminary financial
results included in this press release represent the most current information available to management. The company’s actual results when disclosed in its Form 10-Q may differ from these preliminary
results as a result of the completion of the company’s financial closing procedures, final adjustments, completion of the review by the company’s independent registered accounting firm, and other developments that may arise between now and
the disclosure of the final results. This release contains forward-looking statements that relate to future events or performance. TTM cautions you that such statements are simply predictions and actual events or results may differ materially. These
statements reflect TTM’s current expectations, and TTM does not undertake to update or revise these forward looking statements, even if experience or future changes make it clear that any projected results expressed or implied in this or other
TTM statements will not be realized. Further, these statements involve risks and uncertainties, many of which are beyond TTM’s control, which could cause actual results to differ materially from the forward-looking statements. These risks and
uncertainties include, but are not limited to, general market and economic conditions, including interest rates, currency exchange rates, and consumer spending, demand for TTM’s products, market pressures on prices of TTM’s products,
warranty claims, changes in product mix, contemplated significant capital expenditures and related financing requirements, TTM’s dependence upon a small number of customers, and other factors set forth in the “Risk Factors” and
“Management’s Discussion and Analysis of Financial Condition and Results of Operations” sections of the Company’s public reports filed with the SEC.

[0001193125-25-020820:8k_2_02:44]
About Our Non-GAAP Financial Measures

[0001193125-25-020820:8k_2_02:45]
To supplement our consolidated condensed financial statements presented on a GAAP basis, this release includes information about TTM’s adjusted EBITDA, non-GAAP net income and non-GAAP earnings per share, all of which are non-GAAP financial measures. TTM presents non-GAAP financial information to enable investors to see TTM through the eyes of management and to provide better insight into TTM’s ongoing financial performance.

[0001193125-25-020820:8k_2_02:46]
|  |  |  |  | Contact: Sameer Desai, Vice President, Corporate Development & Investor Relations Sameer.desai@ttmtech.com 714-327-3050 |

[0001193125-25-020820:8k_2_02:47]
A material limitation associated with the use of the above non-GAAP
financial measures is that they have no standardized measurement prescribed by GAAP and may not be comparable to similar non-GAAP financial measures used by other companies. TTM compensates for these
limitations by providing full disclosure of each non-GAAP financial measure and reconciliations below to the most directly comparable GAAP financial measure. However, the
non-GAAP financial measures should not be considered in isolation from, or as a substitute for, financial information prepared in accordance with GAAP.

[0001193125-25-020820:8k_2_02:48]
- Tables Follow -

[0001193125-25-020820:8k_2_02:49]
TTM TECHNOLOGIES, INC.

[0001193125-25-020820:8k_2_02:50]
Selected Unaudited Financial Information

[0001193125-25-020820:8k_2_02:51]
(In thousands, except per share data)

[0001193125-25-020820:8k_2_02:52]
CONSOLIDATED CONDENSED STATEMENTS OF OPERATIONS

[0001193125-25-020820:8k_2_02:53]
|  |  | Fourth Quarter |  |  | Full Year |  |
|  |  | 2024 |  |  | 2023 |  |  | 2024 |  |  | 2023 |  |
| Net sales |  | $ | 650,965 |  |  | $ | 569,039 |  |  | $ | 2,442,753 |  |  | $ | 2,232,567 |  |
| Cost of goods sold |  |  | 524,424 |  |  |  | 453,671 |  |  |  | 1,965,378 |  |  |  | 1,819,299 |  |
| Gross profit |  |  | 126,541 |  |  |  | 115,368 |  |  |  | 477,375 |  |  |  | 413,268 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Selling and marketing |  |  | 19,977 |  |  |  | 18,677 |  |  |  | 80,030 |  |  |  | 76,922 |  |
| General and administrative |  |  | 45,266 |  |  |  | 37,802 |  |  |  | 170,107 |  |  |  | 149,631 |  |
| Research and development |  |  | 7,923 |  |  |  | 7,590 |  |  |  | 31,845 |  |  |  | 27,272 |  |
| Amortization of definite-lived intangibles |  |  | 6,914 |  |  |  | 11,430 |  |  |  | 35,550 |  |  |  | 48,675 |  |
| Impairment of goodwill |  |  | 32,600 |  |  |  | — |  |  |  | 32,600 |  |  |  | 44,100 |  |
| Restructuring charges |  |  | 4,833 |  |  |  | 5,291 |  |  |  | 11,200 |  |  |  | 24,352 |  |
| Total operating expenses |  |  | 117,513 |  |  |  | 80,790 |  |  |  | 361,332 |  |  |  | 370,952 |  |
| Operating income |  |  | 9,028 |  |  |  | 34,578 |  |  |  | 116,043 |  |  |  | 42,316 |  |
| Interest expense |  |  | (11,204 | ) |  |  | (13,373 | ) |  |  | (47,515 | ) |  |  | (48,124 | ) |
| Loss on extinguishment of debt |  |  | — |  |  |  | — |  |  |  | — |  |  |  | (1,154 | ) |
| Gain on sale of subsidiary |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 1,270 |  |
| Other, net |  |  | 16,507 |  |  |  | (3,321 | ) |  |  | 15,421 |  |  |  | 5,989 |  |
| Income before income taxes |  |  | 14,331 |  |  |  | 17,884 |  |  |  | 83,949 |  |  |  | 297 |  |
| Income tax provision |  |  | (9,161 | ) |  |  | (546 | ) |  |  | (27,650 | ) |  |  | (19,015 | ) |
| Net income (loss) |  | $ | 5,170 |  |  | $ | 17,338 |  |  | $ | 56,299 |  |  | $ | (18,718 | ) |
| Earnings (loss) per share: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  | $ | 0.05 |  |  | $ | 0.17 |  |  | $ | 0.55 |  |  | $ | (0.18 | ) |
| Diluted |  |  | 0.05 |  |  |  | 0.17 |  |  |  | 0.54 |  |  |  | (0.18 | ) |
| Weighted-average shares used in computing per share amounts: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  |  | 101,981 |  |  |  | 102,327 |  |  |  | 101,781 |  |  |  | 102,744 |  |
| Diluted |  |  | 104,576 |  |  |  | 104,302 |  |  |  | 104,098 |  |  |  | 102,744 |  |
| Reconciliation of the denominator used to calculate basic earnings per share and diluted earnings per share: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Weighted-average shares outstanding |  |  | 101,981 |  |  |  | 102,327 |  |  |  | 101,781 |  |  |  | 102,744 |  |
| Dilutive effect of performance-based stock units, restricted stock units and stock options |  |  | 2,595 |  |  |  | 1,975 |  |  |  | 2,317 |  |  |  | — |  |
| Diluted shares |  |  | 104,576 |  |  |  | 104,302 |  |  |  | 104,098 |  |  |  | 102,744 |  |

[0001193125-25-020820:8k_2_02:54]
SELECTED BALANCE SHEET DATA

[0001193125-25-020820:8k_2_02:55]
|  |  | December 30, 2024 |  |  | January 1, 2024 |  |
| Cash and cash equivalents, including restricted cash |  | $ | 503,932 |  |  | $ | 450,208 |  |
| Accounts and notes receivable, net |  |  | 448,611 |  |  |  | 413,557 |  |
| Receivable from sale of SH E-MS property |  |  | — |  |  |  | 6,737 |  |
| Contract assets |  |  | 381,382 |  |  |  | 292,050 |  |
| Inventories |  |  | 224,985 |  |  |  | 213,075 |  |
| Total current assets |  |  | 1,606,744 |  |  |  | 1,429,687 |  |
| Property, plant and equipment, net |  |  | 869,957 |  |  |  | 807,667 |  |
| Operating lease right of use asset |  |  | 78,252 |  |  |  | 86,286 |  |
| Other non-current assets |  |  | 917,541 |  |  |  | 1,000,023 |  |
| Total assets |  |  | 3,472,494 |  |  |  | 3,323,663 |  |
| Short-term debt, including current portion of long-term debt |  | $ | 3,795 |  |  | $ | 3,500 |  |
| Accounts payable |  |  | 406,221 |  |  |  | 334,609 |  |
| Total current liabilities |  |  | 809,054 |  |  |  | 703,984 |  |
| Debt, net of discount |  |  | 914,359 |  |  |  | 914,336 |  |
| Total long-term liabilities |  |  | 1,099,616 |  |  |  | 1,108,640 |  |
| Total equity |  |  | 1,563,824 |  |  |  | 1,511,039 |  |
| Total liabilities and equity |  |  | 3,472,494 |  |  |  | 3,323,663 |  |

[0001193125-25-020820:8k_2_02:56]
SUPPLEMENTAL DATA

[0001193125-25-020820:8k_2_02:57]
|  |  | Fourth Quarter |  |  | Full Year |  |
|  |  | 2024 |  |  | 2023 |  |  | 2024 |  |  | 2023 |  |
| Gross margin |  |  | 19.4 | % |  |  | 20.3 | % |  |  | 19.5 | % |  |  | 18.5 | % |
| Operating margin |  |  | 1.4 | % |  |  | 6.1 | % |  |  | 4.8 | % |  |  | 1.9 | % |
| End Market Breakdown: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | Fourth Quarter |  |  |  |  |  |  |  |
|  |  | 2024 |  |  | 2023 |  |  |  |  |  |  |  |
| Aerospace and Defense |  |  | 47 | % |  |  | 46 | % |  |  |  |  |  |  |  |  |
| Automotive |  |  | 11 | % |  |  | 15 | % |  |  |  |  |  |  |  |  |
| Data Center Computing |  |  | 22 | % |  |  | 17 | % |  |  |  |  |  |  |  |  |
| Medical/Industrial/Instrumentation |  |  | 13 | % |  |  | 16 | % |  |  |  |  |  |  |  |  |
| Networking |  |  | 7 | % |  |  | 6 | % |  |  |  |  |  |  |  |  |
| Stock-based Compensation: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | Fourth Quarter |  |  |  |  |  |  |  |
|  |  | 2024 |  |  | 2023 |  |  |  |  |  |  |  |
| Amount included in: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cost of goods sold |  | $ | 2,653 |  |  | $ | 2,084 |  |  |  |  |  |  |  |  |  |
| Selling and marketing |  |  | 1,054 |  |  |  | 878 |  |  |  |  |  |  |  |  |  |
| General and administrative |  |  | 4,067 |  |  |  | 2,891 |  |  |  |  |  |  |  |  |  |
| Research and development |  |  | 309 |  |  |  | 306 |  |  |  |  |  |  |  |  |  |
| Total stock-based compensation expense |  | $ | 8,083 |  |  | $ | 6,159 |  |  |  |  |  |  |  |  |  |

[0001193125-25-020820:8k_2_02:58]
RECONCILIATIONS1

[0001193125-25-020820:8k_2_02:59]
|  |  | Fourth Quarter |  |  | Full Year |  |
|  |  | 2024 |  |  | 2023 |  |  | 2024 |  |  | 2023 |  |
| Non-GAAP gross profit reconciliation2: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| GAAP gross profit |  | $ | 126,541 |  |  | $ | 115,368 |  |  | $ | 477,375 |  |  | $ | 413,268 |  |
| Add back item: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of definite-lived intangibles |  |  | 2,336 |  |  |  | 2,335 |  |  |  | 9,342 |  |  |  | 12,901 |  |
| Stock-based compensation |  |  | 2,653 |  |  |  | 2,084 |  |  |  | 9,342 |  |  |  | 7,455 |  |
| Unrealized loss (gain) on commodity hedge |  |  | 1,635 |  |  |  | (701 | ) |  |  | 370 |  |  |  | (1,192 | ) |
| Purchase accounting related inventory markup |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 327 |  |
| Other charges |  |  | — |  |  |  | 1,950 |  |  |  | 709 |  |  |  | 5,324 |  |
| Non-GAAP gross profit |  | $ | 133,165 |  |  | $ | 121,036 |  |  | $ | 497,138 |  |  | $ | 438,083 |  |
| Non-GAAP gross margin |  |  | 20.5 | % |  |  | 21.3 | % |  |  | 20.4 | % |  |  | 19.6 | % |
| Non-GAAP operating income reconciliation3: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| GAAP operating income |  | $ | 9,028 |  |  | $ | 34,578 |  |  | $ | 116,043 |  |  | $ | 42,316 |  |
| Add back items: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of definite-lived intangibles |  |  | 9,250 |  |  |  | 13,765 |  |  |  | 44,892 |  |  |  | 61,576 |  |
| Stock-based compensation |  |  | 8,083 |  |  |  | 6,159 |  |  |  | 29,780 |  |  |  | 22,887 |  |
| Gain on sale of property, plant and equipment |  |  | (1,249 | ) |  |  | — |  |  |  | (15,669 | ) |  |  | (195 | ) |
| Unrealized loss (gain) on commodity hedge |  |  | 1,635 |  |  |  | (701 | ) |  |  | 370 |  |  |  | (1,192 | ) |
| Purchase accounting related inventory markup |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 327 |  |
| Impairment, restructuring, acquisition-related and other charges |  |  | 39,018 |  |  |  | 7,241 |  |  |  | 58,324 |  |  |  | 72,654 |  |
| Non-GAAP operating income |  | $ | 65,765 |  |  | $ | 61,042 |  |  | $ | 233,740 |  |  | $ | 198,373 |  |
| Non-GAAP operating margin |  |  | 10.1 | % |  |  | 10.7 | % |  |  | 9.6 | % |  |  | 8.9 | % |
| Non-GAAP net income and EPS reconciliation4: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| GAAP net income (loss) |  | $ | 5,170 |  |  | $ | 17,338 |  |  | $ | 56,299 |  |  | $ | (18,718 | ) |
| Add back items: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of definite-lived intangibles |  |  | 9,250 |  |  |  | 13,765 |  |  |  | 44,892 |  |  |  | 61,576 |  |
| Stock-based compensation |  |  | 8,083 |  |  |  | 6,159 |  |  |  | 29,780 |  |  |  | 22,887 |  |
| Non-cash interest expense |  |  | 525 |  |  |  | 478 |  |  |  | 2,042 |  |  |  | 2,204 |  |
| Gain on sale of property, plant and equipment |  |  | (1,249 | ) |  |  | — |  |  |  | (15,669 | ) |  |  | (195 | ) |
| Loss on extinguishment of debt |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 1,154 |  |
| Gain on sale of subsidiary |  |  | — |  |  |  | — |  |  |  | — |  |  |  | (1,270 | ) |
| Unrealized loss (gain) on commodity hedge |  |  | 1,635 |  |  |  | (701 | ) |  |  | 370 |  |  |  | (1,192 | ) |
| Purchase accounting related inventory markup |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 327 |  |
| Impairment, restructuring, acquisition-related and other charges |  |  | 39,018 |  |  |  | 7,241 |  |  |  | 58,324 |  |  |  | 72,654 |  |
| Income taxes5 |  |  | 375 |  |  |  | (1,314 | ) |  |  | 2,352 |  |  |  | 113 |  |
| Non-GAAP net income |  | $ | 62,807 |  |  | $ | 42,966 |  |  | $ | 178,390 |  |  | $ | 139,540 |  |
| Non-GAAP earnings per diluted share |  | $ | 0.60 |  |  | $ | 0.41 |  |  | $ | 1.71 |  |  | $ | 1.33 |  |
| Non-GAAP diluted number of shares: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| GAAP diluted number of shares |  |  | 104,576 |  |  |  | 104,302 |  |  |  | 104,098 |  |  |  | 102,744 |  |
| Dilutive effect of performance-based stock units, restricted stock units and stock options |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 1,851 |  |
| Non-GAAP diluted number of shares |  |  | 104,576 |  |  |  | 104,302 |  |  |  | 104,098 |  |  |  | 104,595 |  |
| Adjusted EBITDA reconciliation6: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| GAAP net income (loss) |  | $ | 5,170 |  |  | $ | 17,338 |  |  | $ | 56,299 |  |  | $ | (18,718 | ) |
| Add back items: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Income tax provision |  |  | 9,161 |  |  |  | 546 |  |  |  | 27,650 |  |  |  | 19,015 |  |
| Interest expense |  |  | 11,204 |  |  |  | 13,373 |  |  |  | 47,515 |  |  |  | 48,124 |  |
| Amortization of definite-lived intangibles |  |  | 9,250 |  |  |  | 13,765 |  |  |  | 44,892 |  |  |  | 61,576 |  |
| Depreciation expense |  |  | 26,524 |  |  |  | 25,095 |  |  |  | 105,233 |  |  |  | 99,155 |  |
| Stock-based compensation |  |  | 8,083 |  |  |  | 6,159 |  |  |  | 29,780 |  |  |  | 22,887 |  |
| Gain on sale of property, plant and equipment |  |  | (1,249 | ) |  |  | — |  |  |  | (15,669 | ) |  |  | (195 | ) |
| Loss on extinguishment of debt |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 1,154 |  |
| Gain on sale of subsidiary |  |  | — |  |  |  | — |  |  |  | — |  |  |  | (1,270 | ) |
| Unrealized loss (gain) on commodity hedge |  |  | 1,635 |  |  |  | (701 | ) |  |  | 370 |  |  |  | (1,192 | ) |
| Purchase accounting related inventory markup |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 327 |  |
| Impairment, restructuring, acquisition-related and other charges |  |  | 38,966 |  |  |  | 5,291 |  |  |  | 56,439 |  |  |  | 67,330 |  |
| Adjusted EBITDA |  | $ | 108,744 |  |  | $ | 80,866 |  |  | $ | 352,509 |  |  | $ | 298,193 |  |
| Adjusted EBITDA margin |  |  | 16.7 | % |  |  | 14.2 | % |  |  | 14.4 | % |  |  | 13.4 | % |
| Free cash flow reconciliation: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Operating cash flow |  | $ | 86,054 |  |  | $ | 47,470 |  |  | $ | 236,894 |  |  | $ | 187,284 |  |
| Capital expenditures, net |  |  | (52,761 | ) |  |  | (45,954 | ) |  |  | (152,871 | ) |  |  | (159,737 | ) |
| Free cash flow |  | $ | 33,293 |  |  | $ | 1,516 |  |  | $ | 84,023 |  |  | $ | 27,547 |  |

[0001193125-25-020820:8k_2_02:60]
| 1 | This information provides a reconciliation of non-GAAP gross profit, non-GAAP operating income, non-GAAP net income, non-GAAP EPS, and adjusted EBITDA to the financial information in our consolidated condensed statements of operations. |

[0001193125-25-020820:8k_2_02:61]
| 2 | Non-GAAP gross profit and gross margin measures exclude amortization of intangibles, stock-based compensation expense, unrealized loss (gain) on commodity hedge, purchase accounting related inventory markup, and other charges. |

[0001193125-25-020820:8k_2_02:62]
| 3 | Non-GAAP operating income and operating margin measures exclude amortization of intangibles, stock-based compensation expense, gain on sale of property, plant, and equipment, unrealized loss (gain) on commodity hedge, purchase accounting related inventory markup, impairment, restructuring, acquisition-related costs, and other charges. |

[0001193125-25-020820:8k_2_02:63]
| 4 | This information provides non-GAAP net income and non-GAAP EPS, which are non-GAAP financial measures. Management believes that both measures — which add back amortization of intangibles, stock-based compensation expense, non-cash interest expense on debt (before consideration of capitalized interest), gain on sale of property, plant, and equipment, loss on extinguishment of debt, gain on sale of subsidiary, unrealized loss (gain) on commodity hedge, purchase accounting related inventory markup, impairment, restructuring, acquisition-related costs, and other charges as well as the associated tax impact of these charges and discrete tax items — provide additional useful information to investors regarding the Company’s ongoing financial condition and results of operations. |

[0001193125-25-020820:8k_2_02:64]
| 5 | Income tax adjustments reflect the difference between income taxes based on a non-GAAP tax rate and a forecasted annual GAAP tax rate. |

[0001193125-25-020820:8k_2_02:65]
| 6 | Adjusted EBITDA is defined as earnings before income taxes, interest expense, amortization of intangibles, depreciation, stock-based compensation expense, gain on sale of property, plant and equipment, loss on extinguishment of debt, gain on sale of subsidiary, unrealized loss (gain) on commodity hedge, purchase accounting related inventory markup, impairment, restructuring, acquisition-related costs, and other charges. We present adjusted EBITDA to enhance the understanding of our operating results, and it is a key measure we use to evaluate our operations. In addition, we provide our adjusted EBITDA because we believe that investors and securities analysts will find adjusted EBITDA to be a useful measure for evaluating our operating performance and comparing our operating performance with that of similar companies that have different capital structures and for evaluating our ability to meet our future debt service, capital expenditures, and working capital requirements. However, adjusted EBITDA should not be considered as an alternative to cash flows from operating activities as a measure of liquidity or as an alternative to net income as a measure of operating results in accordance with accounting principles generally accepted in the United States of America. |

[0001193125-25-020820:8k_2_02:66]
TTM TECHNOLOGIES, INC.

[0001193125-25-020820:8k_2_02:67]
Revised Historical Non-GAAP Financial Information

[0001193125-25-020820:8k_2_02:68]
(In thousands, except per share data)

[0001193125-25-020820:8k_2_02:69]
REVISED HISTORICAL RECONCILIATIONS1

[0001193125-25-020820:8k_2_02:70]
|  |  | Q1 2023 |  |  | Q2 2023 |  |  | Q3 2023 |  |  | Q4 2023 |  |  | Full Year 2023 |  |  | Q1 2024 |  |  | Q2 2024 |  |  | Q3 2024 |  |  | Q4 2024 |  |  | Full Year 2024 |  |
| Non-GAAP net income and EPS reconciliation2: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| GAAP net income (loss) |  | $ | (5,814 | ) |  | $ | 6,824 |  |  | $ | (37,066 | ) |  | $ | 17,338 |  |  | $ | (18,718 | ) |  | $ | 10,466 |  |  | $ | 26,352 |  |  | $ | 14,311 |  |  | $ | 5,170 |  |  | $ | 56,299 |  |
| Add back items: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of definite-lived intangibles |  |  | 27,772 |  |  |  | 6,275 |  |  |  | 13,764 |  |  |  | 13,765 |  |  |  | 61,576 |  |  |  | 13,765 |  |  |  | 12,591 |  |  |  | 9,286 |  |  |  | 9,250 |  |  |  | 44,892 |  |
| Stock-based compensation |  |  | 5,240 |  |  |  | 5,121 |  |  |  | 6,367 |  |  |  | 6,159 |  |  |  | 22,887 |  |  |  | 6,787 |  |  |  | 6,580 |  |  |  | 8,330 |  |  |  | 8,083 |  |  |  | 29,780 |  |
| Non-cash interest expense |  |  | 727 |  |  |  | 497 |  |  |  | 502 |  |  |  | 478 |  |  |  | 2,204 |  |  |  | 518 |  |  |  | 506 |  |  |  | 493 |  |  |  | 525 |  |  |  | 2,042 |  |
| Gain on sale of property, plant and equipment |  |  | (173 | ) |  |  | (22 | ) |  |  | — |  |  |  | — |  |  |  | (195 | ) |  |  | — |  |  |  | (14,420 | ) |  |  | — |  |  |  | (1,249 | ) |  |  | (15,669 | ) |
| Loss on extinguishment of debt |  |  | — |  |  |  | 1,154 |  |  |  | — |  |  |  | — |  |  |  | 1,154 |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |
| (Gain) loss on sale of subsidiary |  |  | (1,339 | ) |  |  | 69 |  |  |  | — |  |  |  | — |  |  |  | (1,270 | ) |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |
| Unrealized (gain) loss on commodity hedge |  |  | (2,128 | ) |  |  | 867 |  |  |  | 770 |  |  |  | (701 | ) |  |  | (1,192 | ) |  |  | (752 | ) |  |  | (434 | ) |  |  | (79 | ) |  |  | 1,635 |  |  |  | 370 |  |
| Purchase accounting related inventory markup |  |  | 163 |  |  |  | 164 |  |  |  | — |  |  |  | — |  |  |  | 327 |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |
| Impairment, restructuring, acquisition-related and other charges |  |  | 5,944 |  |  |  | 12,277 |  |  |  | 47,192 |  |  |  | 7,241 |  |  |  | 72,654 |  |  |  | 3,738 |  |  |  | 11,308 |  |  |  | 4,260 |  |  |  | 39,018 |  |  |  | 58,324 |  |
| Income taxes3 |  |  | (11,744 | ) |  |  | (182 | ) |  |  | 13,353 |  |  |  | (1,314 | ) |  |  | 113 |  |  |  | (1,735 | ) |  |  | (2,352 | ) |  |  | 6,064 |  |  |  | 375 |  |  |  | 2,352 |  |
| Non-GAAP net income - AS REPORTED |  | $ | 18,648 |  |  | $ | 33,044 |  |  | $ | 44,882 |  |  | $ | 42,966 |  |  | $ | 139,540 |  |  | $ | 32,787 |  |  | $ | 40,131 |  |  | $ | 42,665 |  |  | $ | 62,807 |  |  | $ | 178,390 |  |
| Adjust for unrealized foreign exchange: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Unrealized (gain) loss on foreign exchange |  |  | (2,419 | ) |  |  | (2,216 | ) |  |  | 570 |  |  |  | 5,026 |  |  |  | 961 |  |  |  | (4,277 | ) |  |  | 79 |  |  |  | 16,207 |  |  |  | (13,048 | ) |  |  | (1,039 | ) |
| Income taxes3 |  |  | 411 |  |  |  | 377 |  |  |  | (178 | ) |  |  | (724 | ) |  |  | (114 | ) |  |  | 599 |  |  |  | (11 | ) |  |  | (2,089 | ) |  |  | 1,630 |  |  |  | 129 |  |
| Non-GAAP net income - AS ADJUSTED |  | $ | 16,640 |  |  | $ | 31,205 |  |  | $ | 45,274 |  |  | $ | 47,268 |  |  | $ | 140,387 |  |  | $ | 29,109 |  |  | $ | 40,199 |  |  | $ | 56,783 |  |  | $ | 51,389 |  |  | $ | 177,480 |  |
| Non-GAAP earnings per diluted share - AS REPORTED |  | $ | 0.18 |  |  | $ | 0.32 |  |  | $ | 0.43 |  |  | $ | 0.41 |  |  | $ | 1.33 |  |  | $ | 0.31 |  |  | $ | 0.39 |  |  | $ | 0.41 |  |  | $ | 0.60 |  |  | $ | 1.71 |  |
| Impact from unrealized (gain) loss on foreign exchange (after tax) |  |  | (0.02 | ) |  |  | (0.02 | ) |  |  | 0.00 |  |  |  | 0.04 |  |  |  | 0.01 |  |  |  | (0.04 | ) |  |  | 0.00 |  |  |  | 0.14 |  |  |  | (0.11 | ) |  |  | (0.01 | ) |
| Non-GAAP earnings per diluted share - AS ADJUSTED |  | $ | 0.16 |  |  | $ | 0.30 |  |  | $ | 0.43 |  |  | $ | 0.45 |  |  | $ | 1.34 |  |  | $ | 0.28 |  |  | $ | 0.39 |  |  | $ | 0.55 |  |  | $ | 0.49 |  |  | $ | 1.70 |  |
| Non-GAAP diluted number of shares: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| GAAP diluted number of shares |  |  | 102,381 |  |  |  | 104,820 |  |  |  | 103,510 |  |  |  | 104,302 |  |  |  | 102,744 |  |  |  | 104,098 |  |  |  | 103,889 |  |  |  | 103,828 |  |  |  | 104,576 |  |  |  | 104,098 |  |
| Dilutive effect of performance-based stock units, restricted stock units and stock options |  |  | 1,949 |  |  |  | — |  |  |  | 1,419 |  |  |  | — |  |  |  | 1,851 |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |
| Non-GAAP diluted number of shares |  |  | 104,330 |  |  |  | 104,820 |  |  |  | 104,929 |  |  |  | 104,302 |  |  |  | 104,595 |  |  |  | 104,098 |  |  |  | 103,889 |  |  |  | 103,828 |  |  |  | 104,576 |  |  |  | 104,098 |  |
| Adjusted EBITDA reconciliation4: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| GAAP net income (loss) |  | $ | (5,814 | ) |  | $ | 6,824 |  |  | $ | (37,066 | ) |  | $ | 17,338 |  |  | $ | (18,718 | ) |  | $ | 10,466 |  |  | $ | 26,352 |  |  | $ | 14,311 |  |  | $ | 5,170 |  |  | $ | 56,299 |  |
| Add back items: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Income tax provision (benefit) |  |  | (7,924 | ) |  |  | 6,586 |  |  |  | 19,807 |  |  |  | 546 |  |  |  | 19,015 |  |  |  | 3,603 |  |  |  | 4,180 |  |  |  | 10,706 |  |  |  | 9,161 |  |  |  | 27,650 |  |
| Interest expense |  |  | 12,807 |  |  |  | 11,843 |  |  |  | 10,101 |  |  |  | 13,373 |  |  |  | 48,124 |  |  |  | 12,324 |  |  |  | 12,219 |  |  |  | 11,768 |  |  |  | 11,204 |  |  |  | 47,515 |  |
| Amortization of definite-lived intangibles |  |  | 27,772 |  |  |  | 6,275 |  |  |  | 13,764 |  |  |  | 13,765 |  |  |  | 61,576 |  |  |  | 13,765 |  |  |  | 12,591 |  |  |  | 9,286 |  |  |  | 9,250 |  |  |  | 44,892 |  |
| Depreciation expense |  |  | 25,253 |  |  |  | 24,937 |  |  |  | 23,870 |  |  |  | 25,095 |  |  |  | 99,155 |  |  |  | 24,696 |  |  |  | 26,184 |  |  |  | 27,829 |  |  |  | 26,524 |  |  |  | 105,233 |  |
| Stock-based compensation |  |  | 5,240 |  |  |  | 5,121 |  |  |  | 6,367 |  |  |  | 6,159 |  |  |  | 22,887 |  |  |  | 6,787 |  |  |  | 6,580 |  |  |  | 8,330 |  |  |  | 8,083 |  |  |  | 29,780 |  |
| Gain on sale of property, plant and equipment |  |  | (173 | ) |  |  | (22 | ) |  |  | — |  |  |  | — |  |  |  | (195 | ) |  |  | — |  |  |  | (14,420 | ) |  |  | — |  |  |  | (1,249 | ) |  |  | (15,669 | ) |
| Loss on extinguishment of debt |  |  | — |  |  |  | 1,154 |  |  |  | — |  |  |  | — |  |  |  | 1,154 |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |
| (Gain) loss on sale of subsidiary |  |  | (1,339 | ) |  |  | 69 |  |  |  | — |  |  |  | — |  |  |  | (1,270 | ) |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |
| Unrealized (gain) loss on commodity hedge |  |  | (2,128 | ) |  |  | 867 |  |  |  | 770 |  |  |  | (701 | ) |  |  | (1,192 | ) |  |  | (752 | ) |  |  | (434 | ) |  |  | (79 | ) |  |  | 1,635 |  |  |  | 370 |  |
| Purchase accounting related inventory markup |  |  | 163 |  |  |  | 164 |  |  |  | — |  |  |  | — |  |  |  | 327 |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |
| Impairment, restructuring, acquisition-related and other charges |  |  | 4,668 |  |  |  | 10,904 |  |  |  | 46,467 |  |  |  | 5,291 |  |  |  | 67,330 |  |  |  | 3,900 |  |  |  | 11,308 |  |  |  | 2,265 |  |  |  | 38,966 |  |  |  | 56,439 |  |
| Adjusted EBITDA - AS REPORTED |  | $ | 58,525 |  |  | $ | 74,722 |  |  | $ | 84,080 |  |  | $ | 80,866 |  |  | $ | 298,193 |  |  | $ | 74,789 |  |  | $ | 84,560 |  |  | $ | 84,416 |  |  | $ | 108,744 |  |  | $ | 352,509 |  |
| Adjusted EBITDA margin - AS REPORTED |  |  | 10.7 | % |  |  | 13.7 | % |  |  | 14.7 | % |  |  | 14.2 | % |  |  | 13.4 | % |  |  | 13.1 | % |  |  | 14.0 | % |  |  | 13.7 | % |  |  | 16.7 | % |  |  | 14.4 | % |
| Adjust for unrealized foreign exchange: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Unrealized (gain) loss on foreign exchange |  |  | (2,419 | ) |  |  | (2,216 | ) |  |  | 570 |  |  |  | 5,026 |  |  |  | 961 |  |  |  | (4,277 | ) |  |  | 79 |  |  |  | 16,207 |  |  |  | (13,048 | ) |  |  | (1,039 | ) |
| Adjusted EBITDA - AS ADJUSTED |  | $ | 56,106 |  |  | $ | 72,506 |  |  | $ | 84,650 |  |  | $ | 85,892 |  |  | $ | 299,154 |  |  | $ | 70,512 |  |  | $ | 84,639 |  |  | $ | 100,623 |  |  | $ | 95,696 |  |  | $ | 351,470 |  |
| Adjusted EBITDA margin - AS ADJUSTED |  |  | 10.3 | % |  |  | 13.3 | % |  |  | 14.8 | % |  |  | 15.1 | % |  |  | 13.4 | % |  |  | 12.4 | % |  |  | 14.0 | % |  |  | 16.3 | % |  |  | 14.7 | % |  |  | 14.4 | % |

[0001193125-25-020820:8k_2_02:71]
| 1 | This information provides revised reconciliations of non-GAAP net income, non-GAAP EPS, and adjusted EBITDA to the financial information in our consolidated condensed statements of operations. TTM has determined that it is appropriate to exclude the impact of unrealized foreign exchange gains/losses from its non-GAAP measures of adjusted EBITDA, non-GAAP net income, and non-GAAP EPS. We believe the exclusion of these non-cash, non-operational, impacts from our non-GAAP financial measures will provide a more transparent and consistent measure of our core operating performance across reporting periods. Therefore, this schedule provides revised reconciliations to these non-GAAP measures which exclude the respective unrealized foreign exchange gains/losses for fiscal years 2023 and 2024 and each quarterly reporting period therein. Going forward, we intend to begin making this adjustment in our earnings releases to exclude the impact of unrealized foreign exchange gains/losses from our non-GAAP financial measures, commencing with the first quarter of 2025. The “AS REPORTED” lines reflect the respective non-GAAP measure as it was originally reported. The “AS ADJUSTED” lines reflect the results of the adjustments to exclude unrealized foreign exchange (gain) loss from all periods presented. The first and second quarters and full year of fiscal year 2023 have also been recast to reclassify certain amounts between “Gain on sale of property, plant and equipment” and “Impairment, restructuring, acquisition-related and other charges” in order to align with the current classifications of these respective amounts for comparative purposes. |

[0001193125-25-020820:8k_2_02:72]
| 2 | This information provides non-GAAP net income and non-GAAP EPS, which are non-GAAP financial measures. Management believes that both measures — which add back amortization of intangibles, stock-based compensation expense, non-cash interest expense on debt (before consideration of capitalized interest), gain on sale of property, plant and equipment, loss on extinguishment of debt, gain (loss) on sale of subsidiary, unrealized (gain) loss on commodity hedge, purchase accounting related inventory markup, impairment, restructuring, acquisition-related costs, and other charges as well as the associated tax impact of these charges and discrete tax items — provide additional useful information to investors regarding the Company’s ongoing financial condition and results of operations. The “AS REPORTED” lines reflect the respective non-GAAP measure as it was originally reported. The “AS ADJUSTED” lines reflect the results of the adjustments to exclude unrealized foreign exchange (gain) loss from all periods presented. |

[0001193125-25-020820:8k_2_02:73]
| 3 | Income tax adjustments reflect the difference between income taxes based on a non-GAAP tax rate and a forecasted annual GAAP tax rate. |

[0001193125-25-020820:8k_2_02:74]
| 4 | Adjusted EBITDA is defined as earnings before income taxes, interest expense, amortization of intangibles, depreciation, stock-based compensation expense, gain on sale of property, plant and equipment, loss on extinguishment of debt, (gain) loss on sale of subsidiary, unrealized (gain) loss on commodity hedge, purchase accounting related inventory markup, impairment, restructuring, acquisition-related costs, and other charges. We present adjusted EBITDA to enhance the understanding of our operating results, and it is a key measure we use to evaluate our operations. In addition, we provide our adjusted EBITDA because we believe that investors and securities analysts will find adjusted EBITDA to be a useful measure for evaluating our operating performance and comparing our operating performance with that of similar companies that have different capital structures and for evaluating our ability to meet our future debt service, capital expenditures, and working capital requirements. However, adjusted EBITDA should not be considered as an alternative to cash flows from operating activities as a measure of liquidity or as an alternative to net income as a measure of operating results in accordance with accounting principles generally accepted in the United States of America. The “AS REPORTED” lines reflect the respective non-GAAP measure as it was originally reported. The “AS ADJUSTED” lines reflect the results of the adjustments to exclude unrealized foreign exchange (gain) loss from all periods presented. |
