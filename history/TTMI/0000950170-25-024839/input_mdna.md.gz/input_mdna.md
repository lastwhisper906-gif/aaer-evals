# TTMI MD&A — 0000950170-25-024839


## mdna

[0000950170-25-024839:mdna:1]
ITEM 7. MANAGEMENT’S DISCUSSION AND ANALYSIS OF FINANCIAL CONDITION AND RESULTS OF OPERATIONS

[0000950170-25-024839:mdna:2]
This financial review presents our operating results for each of our three most recent fiscal years and our financial condition as of December 30, 2024. Except for historical information contained herein, the following discussion contains forward-looking statements which are subject to known and unknown risks, uncertainties, and other factors that may cause our actual results to differ materially from those expressed or implied by such forward-looking statements. We discuss such risks, uncertainties, and other factors throughout this Annual Report on Form 10-K (Report) and specifically under Item 1A, Risk Factors of Part I of this Report. In addition, the following discussion should be read in connection with the information presented in our consolidated financial statements and the related notes to our consolidated financial statements.

[0000950170-25-024839:mdna:3]
COMPANY OVERVIEW

[0000950170-25-024839:mdna:4]
We are a leading global manufacturer of technology solutions, including mission systems, radio frequency (RF) components, RF microwave/microelectronic assemblies, and quick-turn and technologically advanced printed circuit boards (PCB). We focus on providing time-to-market and volume production of advanced technology products and offer a one-stop design, engineering, and manufacturing solution to our customers. This solution allows us to align technology development with the diverse needs of our customers and to enable them to reduce the time required to develop new products and bring them to market. We serve a diversified customer base consisting of approximately 1,400 customers in various markets throughout the world, including aerospace and defense, data center computing, automotive, medical, industrial and instrumentation, and networking. Our customers include original equipment manufacturers (OEMs), electronic manufacturing services (EMS) providers, original design manufacturers (ODMs), distributors, and government agencies (both domestic and allied foreign governments).

[0000950170-25-024839:mdna:5]
RECENT DEVELOPMENTS

[0000950170-25-024839:mdna:6]
In the third quarter of 2024, we commenced construction of our new advanced technology PCB manufacturing facility in Syracuse, New York. We expect that our new facility will bring advanced technology capability for our domestic high-volume production of ultra-high-density interconnect (HDI) PCBs in support of national security requirements. We believe the planned investment aligns with New York State’s continuing focus on the region as a premier technology hub for U.S. electronics and the recent selection of Buffalo-Rochester-Syracuse (BRS) for the Federal Tech Hub designation. The project reflects our support for cultivating a stronger microelectronics ecosystem in New York and across the U.S. Aerospace and Defense industrial base. The new building will be located on the 24-acre property adjacent to our existing facility in Syracuse, and we expect to commence initial low rate production in 2026. Phase one of the proposed project, including capital for campus-wide improvements is estimated to be $100.0 million to $130.0 million. We expect to receive support in the form of grants, awards, and tax credits from both federal and New York state sources of approximately $52.0 million in the aggregate (subject to certain requirements and contingencies), which would offset the initial capital investment and lower operating expenses.

[0000950170-25-024839:mdna:7]
In addition, we previously announced plans to consolidate our integrated electronics facilities in Elizabeth City, North Carolina and Huntington, New York into existing facilities in order to improve efficiencies. As of the end of fiscal year 2024, the closure of Elizabeth City has been completed and the closure of Huntington is expected by the middle of 2025.

[0000950170-25-024839:mdna:8]
FINANCIAL OVERVIEW

[0000950170-25-024839:mdna:9]
While our customers include both OEMs and EMS providers, we measure customers based on OEM companies, as they are the ultimate end customers. Sales to our five largest customers accounted for 42%, 41%, and 33% of our net sales in fiscal years 2024, 2023, and 2022, respectively, which is in line with the increase in sales in our aerospace and defense end market. We sell to OEMs both directly and indirectly through EMS providers.

[0000950170-25-024839:mdna:10]
The percentage of our net sales attributable to each of the principal end markets we served was as follows:

[0000950170-25-024839:mdna:11]
|  |  | For the Year Ended |
|  |  | December 30, 2024 |  | January 1, 2024 |  | January 2, 2023 |
| End Markets (1): |  |  |  |  |  |  |  |  |  |
| Aerospace and Defense |  | 46 | % |  | 45 | % |  | 35 | % |
| Automotive |  | 13 |  |  | 16 |  |  | 17 |  |
| Data Center Computing |  | 21 |  |  | 14 |  |  | 15 |  |
| Medical/Industrial/Instrumentation |  | 14 |  |  | 17 |  |  | 20 |  |
| Networking |  | 6 |  |  | 8 |  |  | 13 |  |
| Total |  | 100 | % |  | 100 | % |  | 100 | % |

[0000950170-25-024839:mdna:12]
(1)
Sales to EMS companies are classified by the end markets of their OEM customers.

[0000950170-25-024839:mdna:13]
We derive revenues primarily from the sale of PCBs, engineered systems using customer-supplied engineering and design plans as well as our long-term contracts related to the design and manufacture of highly sophisticated intelligence, surveillance, and communications solutions, and RF and microwave/microelectronics components, assemblies, and subsystems. Orders for products generally correspond to the production schedules of our customers and are supported with firm purchase orders. Our customers have continuous control of the work in progress and finished goods throughout the PCB and engineered systems manufacturing process, as these are built to customer specifications with no alternative use, and there is an enforceable right of payment for work performed to date. As a result, we recognize revenue progressively over time based on the extent of progress towards completion of the performance obligation. We recognize revenue based on a cost method as it best depicts the transfer of control to the customer which takes place as we incur costs. Revenues are recorded proportionally as costs are incurred.

[0000950170-25-024839:mdna:14]
We also manufacture certain components, assemblies, subsystems, and completed systems which service our RF and Specialty Components (RF&S Components) customers and certain aerospace and defense customers. We recognize revenue at a point in time upon transfer of control of the products to our customer. Point in time recognition was determined as our customers do not simultaneously receive or consume the benefits provided by our performance and the asset being manufactured has alternative uses to us.

[0000950170-25-024839:mdna:15]
Net sales consist of gross sales less an allowance for returns, which typically have been approximately 2% of gross sales. We provide our customers a limited right of return for defective PCBs including components, assemblies, and subsystems. We record an estimate for sales returns and allowances at the time of sale based on historical results and anticipated returns.

[0000950170-25-024839:mdna:16]
Cost of goods sold consists of materials, labor, outside services, and overhead expenses incurred in the manufacture and testing of our products. Shipping and handling fees and related freight costs and supplies associated with shipping products are also included as a component of cost of goods sold. Many factors affect our gross margin, including capacity utilization, product mix, production volume, supply chain costs, and yield.

[0000950170-25-024839:mdna:17]
Selling and marketing expenses consist primarily of salaries, labor-related benefits, and commissions paid to our internal sales force, independent sales representatives, and our sales support staff, as well as costs associated with marketing materials and trade shows.

[0000950170-25-024839:mdna:18]
General and administrative costs primarily include the salaries for executive, finance, accounting, information technology, and human resources personnel, as well as expenses for accounting and legal assistance, incentive compensation expense, and gains or losses on the sale or disposal of property, plant, and equipment.

[0000950170-25-024839:mdna:19]
Research and development expenses consist primarily of salaries and labor-related benefits paid to our research and development staff, as well as material costs.

[0000950170-25-024839:mdna:20]
CRITICAL ACCOUNTING POLICIES AND ESTIMATES

[0000950170-25-024839:mdna:21]
Our consolidated financial statements included in this Report have been prepared in accordance with accounting principles generally accepted in the United States of America (U.S. GAAP). The preparation of these financial statements requires management to make estimates and assumptions that affect the reported amounts of assets, liabilities, net sales and expenses, and related disclosure of contingent assets and liabilities.

[0000950170-25-024839:mdna:22]
A critical accounting policy is defined as one that is both material to the presentation of our consolidated financial statements and requires us to make judgments that could have a material effect on our financial condition or results of operations. These policies

[0000950170-25-024839:mdna:23]
require us to make assumptions about matters that are highly uncertain at the time of the estimate. Critical accounting estimates refers to those estimates made in accordance with U.S. GAAP that have had or are reasonably likely to have a material impact on the amounts reported in the consolidated financial statements and the related notes due to the significant level of uncertainty involved in developing the estimate. Different estimates we could reasonably have used, or changes in the estimates that are reasonably likely to occur, could have a material effect on our financial condition or results of operations.

[0000950170-25-024839:mdna:24]
We base our estimates on historical experience and on various other assumptions that we believe to be reasonable under the circumstances, the results of which form the basis for making judgments about the carrying values of assets and liabilities that are not readily apparent from other sources. Management has discussed the development, selection, and disclosure of these estimates with the Audit Committee of our Board of Directors. Actual results may differ from these estimates under different assumptions or conditions.

[0000950170-25-024839:mdna:25]
We believe the following critical accounting policies and estimates reflect the more significant judgments and estimates used by us in preparing our consolidated financial statements:

[0000950170-25-024839:mdna:26]
Revenue Recognition

[0000950170-25-024839:mdna:27]
Revenue is recognized when control of the promised goods or services is transferred to customers, in an amount that reflects the consideration to which we expect to be entitled in exchange for those goods or services. We apply a five-step approach in determining the amount and timing of revenue to be recognized: (1) identifying the contract with a customer; (2) identifying the performance obligations in the contract; (3) determining the transaction price; (4) allocating the transaction price to the performance obligations in the contract; and (5) recognizing revenue when the corresponding performance obligation is satisfied.

[0000950170-25-024839:mdna:28]
For PCBs and engineered systems, including pursuant to long-term contracts related to the manufacture of highly sophisticated intelligence, surveillance and communications solutions, components, assemblies, and subsystems, orders for products generally correspond to the production schedules of customers and are supported with firm purchase orders. Customers have continuous control of the work in progress and finished goods throughout the PCB and engineered systems manufacturing process, as these are built to customer specifications with no alternative use, and there is an enforceable right to payment for work performed to date. As a result, we recognize revenue progressively over time based on the extent of progress towards completion of the performance obligation. Revenue recognized is based on a cost method as it best depicts the transfer of control to the customer which takes place as we incur costs. Revenues are recorded proportionally as costs are incurred.

[0000950170-25-024839:mdna:29]
For revenue recorded on an over time basis, we apply a gross margin estimate to inventory in process of being manufactured for customers to determine how much of a contract asset or contract liability should be recorded at period end. As of December 30, 2024, total contract assets were $386.8 million, of which $381.4 million are expected to be collected within one year and recorded as contract assets and $5.4 million are expected to be collected after one year and included as a component of deposits and other non-current assets on the consolidated balance sheets. As of January 1, 2024, total contract assets were $303.3 million, of which $292.1 million were expected to be collected within one year and recorded as contract assets and $11.3 million were expected to be collected after one year and included as a component of deposits and other non-current assets on the consolidated balance sheets. The increase in total contract assets in 2024 is primarily due to an increase in unbilled receivables. We use historical information to estimate the gross margin associated with performance obligations that are satisfied over time. We reevaluate our estimate of gross margins on a quarterly basis. Based on the review of gross margins, we update our estimate to the model as necessary. If our estimates of gross margins are inaccurate, we may recognize too much or too little revenue in a period. While experience has shown that trends in gross margins are not volatile, changes in pricing or cost efficiencies could create significant fluctuations. An increase or decrease of 200 basis points in gross margin estimates would have increased or decreased our contract assets by $3.7 million and $2.3 million, respectively, and decreased or increased our contract liabilities by $7.2 million and $5.6 million, respectively.

[0000950170-25-024839:mdna:30]
In addition, we manufacture components, assemblies, subsystems, and completed systems which service our RF&S Components and certain aerospace and defense customers. We recognize revenue at a point in time upon transfer of control of the products to the customer. Point in time recognition was determined as our customer does not simultaneously receive or consume the benefits provided by our performance and the asset being manufactured has alternative uses to us.

[0000950170-25-024839:mdna:31]
Goodwill and Intangible Assets

[0000950170-25-024839:mdna:32]
We have significant goodwill and definite-lived intangibles. We review these assets for impairment whenever events or changes in circumstances indicate that the carrying amount of such assets may not be recoverable. In addition, we perform an impairment test related to goodwill at least annually. As necessary, we make judgments regarding future cash flow forecasts in the assessment of impairment.

[0000950170-25-024839:mdna:33]
Goodwill is allocated to our reporting units, which are our operating segments or one level below our operating segments (the component level). Reporting units are determined by the discrete financial information available for the component and whether it is regularly reviewed by segment management. Components are aggregated into a single reporting unit if they share similar economic characteristics. We evaluate goodwill on an annual basis in the fourth quarter or more frequently if we believe indicators of impairment exist. We assess qualitative factors to determine whether it is more likely than not that the fair value of a reporting unit is less than its carrying amount or perform a quantitative impairment test. When tested quantitatively, we compare the fair value of the applicable

[0000950170-25-024839:mdna:34]
reporting unit with its carrying value. We estimate the fair values of our reporting units using a combination of the discounted cash flow (DCF) and market approach. If the carrying amount of a reporting unit exceeds the reporting unit’s fair value, the amount by which the carrying value exceeds the fair value is recognized as an impairment loss.

[0000950170-25-024839:mdna:35]
We have two reportable segments: PCB and RF&S Components. Goodwill is attributable to both of our PCB and RF&S Components reportable segments.

[0000950170-25-024839:mdna:36]
In the fourth quarter of 2024, we performed our annual goodwill impairment test qualitatively for the PCB reporting unit and concluded that it was more likely than not that there was no impairment to goodwill.

[0000950170-25-024839:mdna:37]
In the fourth quarter of 2024, we performed our annual goodwill impairment test quantitatively for the RF&S Components reporting unit. As of November 1, 2024, we completed a quantitative goodwill impairment analysis related to our RF&S Components reporting unit by comparing the fair value of the reporting unit with its carrying amount. In making this assessment, we rely on a number of factors, including expected future operating results, business plans, economic projections, anticipated future cash flows, and business trends. We determined the fair value of the reporting unit by using both a DCF and a market approach. Under the market approach, we used revenue and earnings multiples based on comparable industry multiples to estimate the fair value of the reporting unit.

[0000950170-25-024839:mdna:38]
Under the DCF approach, we estimated the future cash flows, as well as selected a risk-adjusted discount rate to measure the present value of the anticipated cash flows. When determining future cash flow estimates, we considered historical results adjusted to reflect current and anticipated future operating conditions. We estimated cash flows for the reporting unit over a discrete period and a terminal period (considering expected long-term growth rates and trends).

[0000950170-25-024839:mdna:39]
Based on our analysis, we determined that the fair value of the RF&S Components reporting unit was less than its carrying value and recorded a non-cash goodwill impairment charge of $32.6 million during the year ended December 30, 2024. Estimating the fair value of the reporting unit requires us to make assumptions and estimates in such areas as future economic conditions, industry-specific conditions, product pricing, and necessary capital expenditures. The use of different assumptions or estimates for future cash flows, discount rates, or terminal growth rates, which are subject to a high degree of judgment, could produce substantially different estimates of the fair value of the reporting unit. We may be subject to additional goodwill impairment charges if actual results do not meet the estimates used in determining the fair value of goodwill and the associated goodwill impairment charge.

[0000950170-25-024839:mdna:40]
Management will continue to monitor the reporting units for changes in the business environment that could impact recoverability. The recoverability of goodwill is dependent upon the continued growth of cash flows from our business activities. If the economy or business environment falter and we are unable to achieve our assumed revenue growth rates or profit margin percentages, our projections used would need to be re-measured, which could impact the carrying value of our goodwill in one or more of our reporting units.

[0000950170-25-024839:mdna:41]
We also assess definite-lived intangibles for potential impairment given similar impairment indicators. When indicators of impairment exist related to our definite-lived intangible assets, we use an estimate of the undiscounted cash flows in measuring whether the carrying amount of the assets is recoverable. If the sum of the undiscounted cash flows is less than the carrying amount of the net assets, impairment is measured based on the difference between the net asset’s carrying value and estimated fair value. Fair value is determined through various valuation techniques, including cost-based, market, and income approaches as considered necessary, which involve judgments related to future cash flows and the application of the appropriate valuation model.

[0000950170-25-024839:mdna:42]
RESULTS OF OPERATIONS

[0000950170-25-024839:mdna:43]
We operate on a 52 or 53 week fiscal calendar with the fourth quarter ending on the Monday nearest December 31. Fiscal years 2024, 2023, and 2022 consisted of 52 weeks ended on December 30, 2024, January 1, 2024, and January 2, 2023, respectively.

[0000950170-25-024839:mdna:44]
The relationship of various items to net sales in our consolidated statements of operations was as follows:

[0000950170-25-024839:mdna:45]
|  |  | For the Year Ended |
|  |  | December 30, 2024 |  | January 1, 2024 |  | January 2, 2023 |
| Net sales |  |  | 100.0 |  | % |  |  | 100.0 |  | % |  |  | 100.0 |  | % |
| Cost of goods sold |  |  | 80.5 |  |  |  |  | 81.5 |  |  |  |  | 81.6 |  |  |
| Gross profit |  |  | 19.5 |  |  |  |  | 18.5 |  |  |  |  | 18.4 |  |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |
| Selling and marketing |  |  | 3.3 |  |  |  |  | 3.4 |  |  |  |  | 3.0 |  |  |
| General and administrative |  |  | 7.0 |  |  |  |  | 6.7 |  |  |  |  | 6.4 |  |  |
| Research and development |  |  | 1.3 |  |  |  |  | 1.2 |  |  |  |  | 1.0 |  |  |
| Amortization of definite-lived intangibles |  |  | 1.4 |  |  |  |  | 2.2 |  |  |  |  | 1.5 |  |  |
| Impairment of goodwill |  |  | 1.3 |  |  |  |  | 2.0 |  |  |  |  | — |  |  |
| Restructuring charges |  |  | 0.4 |  |  |  |  | 1.1 |  |  |  |  | 0.2 |  |  |
| Gain on sale of Shanghai E-MS (SH E-MS) property |  |  | — |  |  |  |  | — |  |  |  |  | (2.1 | ) |  |
| Total operating expenses |  |  | 14.7 |  |  |  |  | 16.6 |  |  |  |  | 10.0 |  |  |
| Operating income |  |  | 4.8 |  |  |  |  | 1.9 |  |  |  |  | 8.4 |  |  |
| Other (expense) income: |  |  |  |  |  |  |  |  |  |  |  |  |
| Interest expense |  |  | (2.0 | ) |  |  |  | (2.2 | ) |  |  |  | (1.8 | ) |  |
| Loss on extinguishment of debt |  |  | — |  |  |  |  | (0.1 | ) |  |  |  | — |  |  |
| Gain on sale of subsidiary |  |  | — |  |  |  |  | 0.1 |  |  |  |  | — |  |  |
| Other, net |  |  | 0.6 |  |  |  |  | 0.3 |  |  |  |  | 0.7 |  |  |
| Total other expense, net |  |  | (1.4 | ) |  |  |  | (1.9 | ) |  |  |  | (1.1 | ) |  |
| Income before income taxes |  |  | 3.4 |  |  |  |  | — |  |  |  |  | 7.3 |  |  |
| Income tax provision |  |  | (1.1 | ) |  |  |  | (0.9 | ) |  |  |  | (3.5 | ) |  |
| Net income (loss) |  |  | 2.3 |  | % |  |  | (0.9 | ) | % |  |  | 3.8 |  | % |

[0000950170-25-024839:mdna:46]
The Telephonics acquisition occurred on June 27, 2022. Accordingly, our fiscal year 2022 only includes Telephonics’ 2022 results of operations since the acquisition date. As of the fourth quarter of 2022, we completed our integration of Telephonics and reassessed our reportable segments, which resulted in the inclusion of Telephonics into our PCB reportable segment.

[0000950170-25-024839:mdna:47]
Net Sales

[0000950170-25-024839:mdna:48]
Total net sales increased $210.2 million, or 9.4%, to $2,442.8 million for the year ended December 30, 2024 from $2,232.5 million for the year ended January 1, 2024. Net sales for the PCB reportable segment increased $211.6 million, or 9.6%, to $2,405.6 million for the year ended December 30, 2024 from $2,194.0 million for the year ended January 1, 2024. The primary driver of this increase was demand growth for generative artificial intelligence (AI) applications in our data center computing end market and strong demand and improved operational execution in our aerospace and defense end market, partially offset by demand weakness due to customers' inventory correction in our automotive, medical, industrial, and instrumentation, and networking end markets. We also sold our Shanghai Backplane Assembly entity in the first quarter of 2023, which had the effect of reducing net sales in 2024 by $8.4 million. Net sales for the RF&S Components reportable segment decreased $1.4 million, or 3.6%, to $37.1 million for the year ended December 30, 2024 from $38.5 million for the year ended January 1, 2024. The decrease in RF&S Components net sales was primarily due to lower demand in our networking end market.

[0000950170-25-024839:mdna:49]
Total net sales decreased $262.5 million, or 10.5%, to $2,232.5 million for the year ended January 1, 2024 from $2,495.0 million for the year ended January 2, 2023. Net sales for the PCB reportable segment decreased $243.9 million, or 10.0%, to $2,194.0 million for the year ended January 1, 2024 from $2,437.9 million for the year ended January 2, 2023. The primary driver of this decrease was demand weakness in our commercial end markets and decrease in sales of $36.3 million from the Shanghai Backplane Assembly entity we sold in the first quarter of 2023, partially offset by the inclusion of a full year of results of Telephonics during the year ended January 1, 2024 (as compared to the inclusion in the year ended January 2, 2023 of its results commencing with its acquisition in 2022), as well as organic growth in our aerospace and defense end market. Net sales for the RF&S Components reportable segment decreased $18.6 million, or 32.5%, to $38.5 million for the year ended January 1, 2024 from $57.1 million for the year ended January 2, 2023. The decrease in RF&S Components net sales was primarily due to lower demand in our networking end market.

[0000950170-25-024839:mdna:50]
For information regarding net sales by country, see Part II, Item 8, Note 10, Segment Information, of the Notes to Consolidated Financial Statements in this Report.

[0000950170-25-024839:mdna:51]
45

[0000950170-25-024839:mdna:52]
Gross Margin

[0000950170-25-024839:mdna:53]
Overall gross margin increased to 19.5% for the year ended December 30, 2024 from 18.5% for the year ended January 1, 2024. The increase in overall gross margin was due to the increase in gross margin for the PCB reportable segment to 20.6% for the year ended December 30, 2024, from 19.3% for the year ended January 1, 2024. This increase was primarily due to higher sales volume, particularly in the data center computing and aerospace and defense end markets, and improved operational execution, partially offset by declines in the automotive, medical, industrial, and instrumentation, and networking end markets, higher employee costs, and continued ramp up costs included in cost of goods sold in connection with our fabrication plant in Penang, Malaysia. Gross margin for the RF&S Components reportable segment decreased to 48.9% for the year ended December 30, 2024, from 54.7% for the year ended January 1, 2024, primarily due to lower sales.

[0000950170-25-024839:mdna:54]
Overall gross margin increased slightly to 18.5% for the year ended January 1, 2024 from 18.4% for the year ended January 2, 2023. The increase in overall gross margin was due to the increase in gross margin for the PCB reportable segment to 19.3% for the year ended January 1, 2024, from 18.2% for the year ended January 2, 2023. This increase was primarily due to better product mix and improved execution in our North America region, partially offset by lower revenues and less quick-turn premium in our commercial markets. Gross margin for the RF&S Components reportable segment decreased to 54.7% for the year ended January 1, 2024, from 62.3% for the year ended January 2, 2023, primarily due to lower sales.

[0000950170-25-024839:mdna:55]
An important factor affecting gross margins is capacity utilization, which is measured by the actual production as a percentage of maximum capacity. This measure is particularly important in our high-volume PCB facilities in Asia, as a significant portion of our operating costs are fixed in nature. We believe that our North America utilization figures are not as meaningful as Asia because bottlenecks in these high mix low volume facilities tend to occur in areas outside of plating, which is the core process that we use for calculating utilization rates. Capacity utilization for the year ended December 30, 2024 in our Asia and North America PCB facilities was 59% and 36%, respectively, compared to 49% and 38%, respectively, for the year ended January 1, 2024. The increase in capacity utilization in our Asia PCB facilities was caused by strong demand in the data center computing end market.

[0000950170-25-024839:mdna:56]
Selling and Marketing Expenses

[0000950170-25-024839:mdna:57]
Selling and marketing expenses increased $3.1 million to $80.0 million for the year ended December 30, 2024 from $76.9 million for the year ended January 1, 2024. However, selling and marketing expenses as a percentage of net sales decreased to 3.3% for the year ended December 30, 2024 as compared to 3.4% for the year ended January 1, 2024. The increase in the amount of selling and marketing expenses was primarily due to an increase of $2.0 million in labor costs, $0.6 million in stock-based compensation, and $0.5 million in travel costs. The decrease in selling and marketing expenses as a percentage of net sales resulted from higher net sales for the year ended December 30, 2024 as compared to January 1, 2024.

[0000950170-25-024839:mdna:58]
Selling and marketing expenses increased $1.7 million to $76.9 million, or 3.4% of net sales, for the year ended January 1, 2024 from $75.2 million, or 3.0% of net sales, for the year ended January 2, 2023. The increase in selling and marketing expense was primarily due to the inclusion of a full year of Telephonics expenses, which resulted in an increase of $3.5 million and an increase in labor and travels costs, partially offset by a $3.7 million decrease in commission expense.

[0000950170-25-024839:mdna:59]
General and Administrative Expenses

[0000950170-25-024839:mdna:60]
General and administrative expenses increased $20.5 million to $170.1 million, or 7.0% of net sales, for the year ended December 30, 2024 from $149.6 million, or 6.7% of net sales, for the year ended January 1, 2024. The increase in general and administrative expenses was primarily due to increases in consulting and other professional services expenses, labor costs, stock-based compensation, bad debt, incentive compensation, and the write down of our Hong Kong building of $6.1 million, partially offset by gains on the sale of assets primarily related to the sale of two buildings vacated with the closure of our Anaheim and Santa Clara plants of $14.4 million.

[0000950170-25-024839:mdna:61]
General and administrative expenses decreased $8.5 million to $149.6 million for the year ended January 1, 2024 from $158.2 million for the year ended January 2, 2023, but increased as a percentage of net sales to 6.7% from 6.4% over the same two periods. The decrease in the amount of general and administrative expenses primarily resulted from $13.2 million of reduced acquisition and integration costs mainly related to the acquisition of Telephonics on June 27, 2022. In addition, there were decreases in incentive compensation and bad debt. These decreases were partially offset by the inclusion of a full year of Telephonics expenses, which resulted in an increase of $1.6 million, increase in labor costs and lower gains on the sale of assets. The increase of general and administrative expenses as a percentage of net sales resulted from lower net sales for the year ended January 1, 2024 as compared to January 2, 2023.

[0000950170-25-024839:mdna:62]
Research and Development Expenses

[0000950170-25-024839:mdna:63]
Research and development expenses increased $4.6 million to $31.8 million, or 1.3% of net sales, for the year ended December 30, 2024 from $27.3 million, or 1.2% of net sales, for the year ended January 1, 2024. The increase in research and development expenses was primarily due to increases in labor costs and research and development projects.

[0000950170-25-024839:mdna:64]
46

[0000950170-25-024839:mdna:65]
Research and development expenses increased $2.5 million to $27.3 million, or 1.2% of net sales, for the year ended January 1, 2024 from $24.8 million, or 1.0% of net sales, for the year ended January 2, 2023. The increase in expense was primarily due to the inclusion of a full year of Telephonics expenses, which resulted in an increase of $4.5 million, partially offset by a decrease in labor and material costs.

[0000950170-25-024839:mdna:66]
Impairment of Goodwill

[0000950170-25-024839:mdna:67]
For the years ended December 30, 2024 and January 1, 2024, we recorded goodwill impairment charges of $32.6 million and $44.1 million, respectively. See Part II, Item 8, Note 6, Goodwill, of the Notes to Consolidated Financial Statements included in this Report for further information.

[0000950170-25-024839:mdna:68]
Restructuring Charges

[0000950170-25-024839:mdna:69]
For the years ended December 30, 2024, January 1, 2024, and January 2, 2023, we incurred restructuring charges of $11.2 million, $24.4 million, and $4.1 million, respectively, related to our global realignment restructuring efforts.

[0000950170-25-024839:mdna:70]
For the year ended December 30, 2024, we recognized restructuring charges of $8.1 million and $3.1 million in our PCB reportable segment and Corporate and Other, respectively. For the year ended January 1, 2024, we recognized restructuring charges of $23.7 million and $0.7 million in our PCB reportable segment and Corporate and Other, respectively. For the year ended January 2, 2023, we recognized restructuring charges of $3.5 million and $0.6 million in our PCB reportable segment and Corporate and Other, respectively. These charges primarily represent employee separation and contract termination and other costs associated with the restructuring plans.

[0000950170-25-024839:mdna:71]
Gain on sale of SH E-MS Property

[0000950170-25-024839:mdna:72]
On December 22, 2022, land, building, and relevant ancillary assets related to our former SH E-MS manufacturing facility was expropriated by the Chinese government for a compensation fee of Renminbi (RMB) 477.6 million ($69.2 million as of January 2, 2023) and we recorded a gain on the sale of $51.8 million during the year ended January 2, 2023.

[0000950170-25-024839:mdna:73]
Total Other Expense, Net

[0000950170-25-024839:mdna:74]
Total other expense, net decreased $9.9 million to $32.1 million for the year ended December 30, 2024 from $42.0 million for the year ended January 1, 2024. This decrease was primarily due to the weakening RMB resulting in a $1.2 million foreign exchange gain during the year ended December 30, 2024, as compared to a $3.9 million foreign exchange loss during the year ended January 1, 2024. We utilize the RMB at our China facilities for employee-related and other costs of running our operations in China. In addition, there was a $3.8 million increase in interest income and $0.6 million decrease in interest expense.

[0000950170-25-024839:mdna:75]
Total other expense, net increased $14.5 million to $42.0 million for the year ended January 1, 2024 from $27.5 million for the year ended January 2, 2023. This increase was primarily due to a decrease in other income of $16.8 million related to the strengthening of the Chinese RMB and an increase in interest expense of $2.6 million due to higher interest rates, partially offset by an increase in interest income of $5.9 million.

[0000950170-25-024839:mdna:76]
Income Taxes

[0000950170-25-024839:mdna:77]
Income tax expense increased $8.6 million to $27.7 million for the year ended December 30, 2024 from $19.0 million for the year ended January 1, 2024, primarily due to an increase in pre-tax book income.

[0000950170-25-024839:mdna:78]
Income tax expense decreased $69.3 million to $19.0 million for the year ended January 1, 2024 from $88.3 million for the year ended January 2, 2023, primarily due to a decrease in pre-tax book income, the absence of an expense to set up a valuation allowance against U.S. deferred tax assets in 2022, and the release of uncertain tax positions due to lapse of statute of limitations.

[0000950170-25-024839:mdna:79]
Our effective tax rate is primarily impacted by tax rates in China and Hong Kong, the U.S. federal income tax rate, apportioned state income tax rates, the generation of credits and deductions available to us, as well as changes in the valuation allowance, certain non-deductible items, global intangible low taxed income, and the establishment of a deferred tax liability related to unremitted foreign earnings.

[0000950170-25-024839:mdna:80]
Liquidity and Capital Resources

[0000950170-25-024839:mdna:81]
Our principal sources of liquidity have been cash provided by operations, the issuance of debt, and borrowings under our revolving credit facilities. Our principal uses of cash have been to finance capital expenditures, finance acquisitions, fund working capital requirements, repay debt obligations, and repurchase common stock. We anticipate that financing capital expenditures, financing acquisitions, funding working capital requirements, servicing debt, and repurchasing common stock will be the principal demands on our cash in the future.

[0000950170-25-024839:mdna:82]
Cash flow provided by operating activities during the year ended December 30, 2024 was $236.9 million as compared to $187.3 million in the same period in 2023. The increase in cash flow was primarily due to the $75.0 million increase in net income.

[0000950170-25-024839:mdna:83]
Net cash used in investing activities was $146.2 million for the year ended December 30, 2024, primarily reflecting the use of $185.7 million for purchases of property, plant, and equipment and other assets. This was partially offset by the receipt of $32.9 million of proceeds from the sale of property, plant, and equipment and other assets primarily related to the sale of two buildings vacated with the closure of our Anaheim and Santa Clara plants and $6.7 million of proceeds from the sale of property associated with our Shanghai E‑MS subsidiary. Net cash used in investing activities was $92.0 million for the year ended January 1, 2024, primarily reflecting the use of $160.2 million for purchases of property, plant, and equipment and other assets, partially offset by the receipt of $61.8 million of proceeds from the sale of property associated with our Shanghai E-MS subsidiary and $6.0 million of proceeds from the sale of our Shanghai Backplane Assembly subsidiary, net of cash disposed.

[0000950170-25-024839:mdna:84]
Net cash used in financing activities was $36.8 million for the year ended December 30, 2024, reflecting the use of $34.5 million for repurchases of our common stock, $9.6 million for the repayment of long-term debt borrowings, and $1.2 million for payment of debt issuance costs, partially offset by $8.4 million of proceeds from long-term debt borrowings primarily related to the refinancing of our Term Loan Facility due 2030 (Term Loan Facility). Net cash used in financing activities during the year ended January 1, 2024 was $47.7 million, reflecting repayment of long-term debt borrowings of $291.6 million, repurchases of common stock of $24.4 million, refund of customer deposits of $7.5 million, payment of debt issuance costs of $5.5 million and payment of original issue discount of $3.5 million, partially offset by the receipt of proceeds of $234.8 million from long-term debt borrowing and proceeds of $50.0 million from borrowings under our revolving credit facilities.

[0000950170-25-024839:mdna:85]
As of December 30, 2024, we had cash and cash equivalents of approximately $503.9 million, of which approximately $207.9 million was held by our foreign subsidiaries, primarily in China, and $195.6 million of available borrowing capacity under our revolving credit facilities. Should we choose to remit cash to the United States from our foreign locations, we may incur tax obligations which would reduce the amount of cash ultimately available to the United States. However, we believe there would be no material tax expenses not previously accrued for the repatriation of this cash.

[0000950170-25-024839:mdna:86]
Our total 2025 capital expenditures are expected to be in the range of $230.0 million to $250.0 million, of which approximately $66.0 million relate to our construction of our new plant in Syracuse, New York.

[0000950170-25-024839:mdna:87]
Share Repurchases

[0000950170-25-024839:mdna:88]
On May 3, 2023, our Board of Directors authorized a share repurchase program (2023 Repurchase Program) allowing us to repurchase up to $100.0 million of our common stock from time to time through May 3, 2025. During 2024, we repurchased approximately 2.0 million shares of our common stock for a total cost of $34.5 million (including commissions). As of December 30, 2024, the remaining amount in value available to be repurchased under the 2023 Repurchase Program was approximately $41.1 million.

[0000950170-25-024839:mdna:89]
Long-term Debt and Letters of Credit

[0000950170-25-024839:mdna:90]
As of December 30, 2024, we had $918.2 million of outstanding debt, net of discount and debt issuance costs, composed of $496.6 million of Senior Notes due 2029, $339.2 million under the Term Loan Facility, $80.0 million under the Asia Asset‑Based Lending Credit Agreement (Asia ABL), and $2.3 million of other loans.

[0000950170-25-024839:mdna:91]
Pursuant to the terms of the Senior Notes due 2029 and Term Loan Facility, we are subject to certain affirmative and negative covenants, including limitations on indebtedness, corporate transactions, investments, dispositions, and restricted payments. Under the U.S. Asset-Based Lending Credit Agreement (U.S. ABL) and Asia ABL (collectively, the ABL Revolving Loans), we are also subject to various financial covenants, including leverage and fixed charge coverage ratios. As of December 30, 2024, we were in compliance with the covenants under the Senior Notes due 2029, Term Loan Facility, and ABL Revolving Loans.

[0000950170-25-024839:mdna:92]
Based on our current level of operations, we believe that cash generated from operations, cash on hand, and cash from the issuance of term and revolving debt will be adequate to meet our currently anticipated capital expenditure, debt service, and working capital needs for the next twelve months. Additional information regarding our indebtedness, including information about the credit available under our debt facilities, interest rates, and other key terms of our outstanding indebtedness, is included in Part II, Item 8, Note 8, Long‑term Debt and Letters of Credit, of the Notes to Consolidated Financial Statements included in this Report.

[0000950170-25-024839:mdna:93]
Supplier Finance Program Obligations

[0000950170-25-024839:mdna:94]
We have agreements with financial institutions to facilitate payments to certain suppliers. Under the terms of the agreements, we confirm the validity of each supplier invoice to the respective financial institution upon receipt. The supplier receives payment from the financial institution, and we pay the financial institution based on the terms negotiated, which generally range from 160 days to 360 days. Liabilities associated with these agreements are recorded in accounts payable on the consolidated balance sheets and amounted to $17.2 million and $18.8 million as of December 30, 2024 and January 1, 2024, respectively.

[0000950170-25-024839:mdna:95]
Contractual Obligations and Commitments

[0000950170-25-024839:mdna:96]
As part of our ongoing operations, we enter into contractual arrangements that obligate us to make future cash payments. These obligations impact our liquidity and capital resource needs. Our estimated future obligations consist of long-term debt obligations, interest on debt obligations, derivative liabilities, purchase obligations, and leases.

[0000950170-25-024839:mdna:97]
A summary of our long-term debt obligations as of December 30, 2024 is included in Part II, Item 8, Note 8, Long‑term Debt and Letters of Credit, of the Notes to Consolidated Financial Statements included in this Report.

[0000950170-25-024839:mdna:98]
Our aggregate interest on debt obligations as of December 30, 2024 amounted to $226.0 million, which are expected to be settled as follows: $47.6 million within 1 year, $94.9 million within 1-3 years, $74.7 million within 4-5 years, and $8.8 million after 5 years. For debt obligations based on variable rates, interest rates used are as of December 30, 2024.

[0000950170-25-024839:mdna:99]
As of December 30, 2024, $0.7 million of our derivative liabilities are expected to be settled within one year.

[0000950170-25-024839:mdna:100]
We also have outstanding firm purchase orders with certain suppliers for the purchase of material and inventory. Orders for standard, or catalog, items can typically be canceled with little or no financial penalty. Our policy regarding non-standard or customized items dictates that such items are only ordered specifically for customers who have contractually assumed liability for the inventory, although exceptions are made to this policy in certain situations. In addition, a substantial portion of catalog items covered by our purchase orders are procured for specific customers based on their purchase orders or a forecast under which the customer has contractually assumed liability for such material. Accordingly, our liability from purchase obligations under these purchase orders is not expected to be significant.

[0000950170-25-024839:mdna:101]
A summary of our lease obligations as of December 30, 2024 is included in Part II, Item 8, Note 4, Leases, of the Notes to Consolidated Financial Statements included in this Report.

[0000950170-25-024839:mdna:102]
Offset Agreements

[0000950170-25-024839:mdna:103]
We have previously entered into, and may continue to enter into industrial cooperation agreements, sometimes referred to as offset agreements, as a condition to obtaining orders for our products and services from customers in foreign countries. As of December 30, 2024, we had outstanding offset agreements of approximately $27.3 million, some of which extend through 2028. Offset programs usually extend over several years and in some cases provide for penalties in the event we fail to perform in accordance with contract requirements. To date, we have not been obligated to pay any such penalties. For details about our offset agreements, see Part II, Item 8, Note 14, Commitments and Contingencies, of the Notes to Consolidated Financial Statements included in this Report.

[0000950170-25-024839:mdna:104]
Seasonality

[0000950170-25-024839:mdna:105]
We tend to experience modest seasonal softness in the first and third quarters due to holidays and vacation periods in China and North America, respectively, which limit production leading to stronger revenue levels in the second and fourth quarters.

[0000950170-25-024839:mdna:106]
Recently Issued Accounting Standards

[0000950170-25-024839:mdna:107]
For a description of recently adopted and issued accounting standards, including the respective dates of adoption and expected effects on our results of operations and financial condition, see Part II, Item 8, Note 1, Nature of Operations and Summary of Significant Accounting Policies, of the Notes to Consolidated Financial Statements.
