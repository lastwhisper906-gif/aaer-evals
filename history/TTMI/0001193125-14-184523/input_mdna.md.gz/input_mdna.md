# TTMI MD&A — 0001193125-14-184523


## mdna

[0001193125-14-184523:mdna:1]
[same as prior period, unchanged from 0001193125-13-424647:mdna:1]

[0001193125-14-184523:mdna:2]
This
discussion and analysis should be read in conjunction with “Management’s Discussion and Analysis of Financial Condition and Results of Operations” set forth in our Annual Report on Form 10-K for the fiscal year ended December 30,
2013, filed with the SEC.

[0001193125-14-184523:mdna:3]
OVERVIEW AND RECENT DEVELOPMENTS

[0001193125-14-184523:mdna:4]
We are a leading global provider of time-critical and technologically complex printed circuit board (PCB) products and
backplane assemblies (PCBs populated with electronic components), which serve as the foundation of sophisticated electronic products. We provide our customers time-to-market and advanced technology products and offer a one-stop manufacturing
solution to customers from engineering support to prototype development through final volume production. We serve a diversified customer base in various markets throughout the world, including manufacturers of networking/communications
infrastructure products, touch screen tablets, mobile media devices and smartphones. We also serve the aerospace and defense, high-end computing, and industrial/medical industries. Our customers include both original equipment manufacturers (OEMs)
and electronic manufacturing services (EMS) providers.

[0001193125-14-184523:mdna:5]
Our Asia Pacific operating segment revenue experiences
fluctuations, caused in part by seasonal patterns in the computer and cellular phone industries, which together have become a significant portion of the end markets we serve. This seasonality typically results in higher net sales in the third and
fourth quarters due to end customer demand to meet fourth quarter sales of consumer electronics products.

[0001193125-14-184523:mdna:6]
In
the normal course of operations, we are exposed to risks associated with fluctuations in foreign currency exchange rates. Specifically, we are subject to risks associated with transactions that are denominated in currencies other than our functional
currencies. Our primary foreign exchange exposure is to the Chinese Renminbi (RMB). In the first quarter ended March 31, 2014, our consolidated condensed statement of operations includes an unrealized foreign exchange loss of approximately $3.6
million, due to the rapid depreciation of the RMB against the U.S. Dollar. We do not engage in hedging to manage foreign currency risk related to revenue and expenses denominated in RMB nor do we currently use derivative instruments to reduce
exposure to foreign currency risk for loans due from our foreign subsidiaries.

[0001193125-14-184523:mdna:7]
Labor costs represent a
significant portion of our total manufacturing costs. Our labor costs in the People’s Republic of China (PRC) have increased rapidly over the past number of years and as a result of mandated increases in the minimum wage and increased
compensation offered to our labor force and due to the reduction of overtime hours that we implemented to meet standards required by some of our global customers. These increases in labor costs have reduced the gross and operating margins of our
Asia Pacific operating segment. We believe annual labor rate increases together with increased pricing pressures from our principal customers and the reduction in our first quarter and second quarter operating leverage due to the seasonal nature of
our business will occur each year for the foreseeable future and may further reduce gross and operating margins in our Asia Pacific operating segment.

[0001193125-14-184523:mdna:8]
While our customers include both OEMs and EMS providers, we measure customers based on OEM companies as they are the ultimate end customers. Sales to our 10 largest customers accounted for 53% and 51% of
our net sales for the quarters ended March 31, 2014 and April 1, 2013, respectively. We sell to OEMs both directly and indirectly through EMS providers.

[0001193125-14-184523:mdna:9]
The following table shows the percentage of our net sales attributable to each of the principal end markets we serve for
the periods indicated.

[0001193125-14-184523:mdna:10]
|  |  | Quarter Ended |  |
| End Markets(1) |  | March 31,2014 |  |  | April 1,2013 |  |
| Aerospace/Defense |  |  | 17 | % |  |  | 16 | % |
| Cellular Phone(2) |  |  | 15 |  |  |  | 17 |  |
| Computing/Storage/Peripherals(2) |  |  | 18 |  |  |  | 19 |  |
| Medical/Industrial/Instrumentation |  |  | 10 |  |  |  | 8 |  |
| Networking/Communications |  |  | 34 |  |  |  | 34 |  |
| Other(2) |  |  | 6 |  |  |  | 6 |  |
| Total |  |  | 100 | % |  |  | 100 | % |

[0001193125-14-184523:mdna:11]
[same as prior period, unchanged from 0001193125-13-424647:mdna:13]

[0001193125-14-184523:mdna:12]
[same as prior period, unchanged from 0001193125-13-424647:mdna:14]

[0001193125-14-184523:mdna:13]
19

[0001193125-14-184523:mdna:14]
For PCBs, we measure the time sensitivity of our products by tracking the
quick-turn percentage of our work. We define quick-turn orders as those with delivery times of 10 days or less, which typically captures research and development, prototype, and new product introduction work, in addition to unexpected
short-term production demand from our customers. Generally, we quote prices after we receive the design specifications and the time and volume requirements from our customers. Our quick-turn services command a premium price as compared to our
standard lead-time products.

[0001193125-14-184523:mdna:15]
We also deliver product within compressed lead times of 11 to 20 days. We
typically receive a premium price for this work as well. Purchase orders may be cancelled prior to shipment. We charge customers a fee, based on percentage completed, if an order is cancelled once it has entered production. We derive revenues
primarily from the sale of PCBs and backplane assemblies using customer-supplied engineering and design plans. We recognize revenues when persuasive evidence of a sales arrangement exists, the sales terms are fixed or determinable, title and risk of
loss have transferred, and collectability is reasonably assured — generally when products are shipped to the customer. Net sales consist of gross sales less an allowance for returns, which typically have been less than 3% of gross sales.
We provide our customers a limited right of return for defective PCBs and backplane assemblies. We record an estimate for sales returns and allowances at the time of sale based on historical results.

[0001193125-14-184523:mdna:16]
Cost of goods sold consists of materials, labor, outside services, and overhead expenses incurred in the manufacture and
testing of our products as well as stock-based compensation expense. Many factors affect our gross margin, including capacity utilization, product mix, product quality issues, production volume, and yield. We generally do not participate in any
significant long-term contracts with suppliers, and we believe there are a number of potential suppliers for the raw materials we use.

[0001193125-14-184523:mdna:17]
Selling and marketing expenses consist primarily of salaries and commissions paid to our internal sales force and independent sales representatives, salaries paid to our sales support staff, stock-based
compensation expense as well as costs associated with marketing materials and trade shows.

[0001193125-14-184523:mdna:18]
General and
administrative costs primarily include the salaries for executive, finance, accounting, information technology, facilities and human resources personnel, as well as insurance expenses, expenses for accounting and legal assistance, incentive
compensation expense, stock-based compensation expense, bad debt expense, gains or losses on the sale or disposal of property, plant and equipment, and acquisition-related expenses.

[0001193125-14-184523:mdna:19]
[same as prior period, unchanged from 0001193125-13-424647:mdna:23]

[0001193125-14-184523:mdna:20]
Our
consolidated condensed financial statements included in this report have been prepared in accordance with accounting principles generally accepted in the United States of America. The preparation of these financial statements requires management to
make estimates and assumptions that affect the reported amounts of assets, liabilities, net sales and expenses, and related disclosure of contingent assets and liabilities.

[0001193125-14-184523:mdna:21]
See Item 7, Management’s Discussion and Analysis of Financial Condition and Results of Operation, in the
Company’s Annual Report on Form 10-K for the fiscal year ended December 30, 2013 for further discussion of critical accounting policies and estimates. There were no material changes to our critical accounting policies and estimates since
December 30, 2013.

[0001193125-14-184523:mdna:22]
[same as prior period, unchanged from 0001193125-13-424647:mdna:26]

[0001193125-14-184523:mdna:23]
The following table sets forth the relationship of various items to net sales in our consolidated condensed statement of
operations:

[0001193125-14-184523:mdna:24]
|  |  | Quarter Ended |  |
|  |  | March 31, 2014 |  |  | April 1, 2013 |  |
| Net sales |  |  | 100.0 | % |  |  | 100.0 | % |
| Cost of goods sold |  |  | 86.8 |  |  |  | 84.4 |  |
| Gross profit |  |  | 13.2 |  |  |  | 15.6 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |
| Selling and marketing |  |  | 3.2 |  |  |  | 2.8 |  |
| General and administrative |  |  | 7.7 |  |  |  | 8.2 |  |
| Amortization of definite-lived intangibles |  |  | 0.8 |  |  |  | 0.7 |  |
| Total operating expenses |  |  | 11.7 |  |  |  | 11.7 |  |
| Operating income |  |  | 1.5 |  |  |  | 3.9 |  |
| Other income (expense): |  |  |  |  |  |  |  |  |
| Interest expense |  |  | (2.1 | ) |  |  | (1.9 | ) |
| Loss on extinguishment of debt |  |  | (0.2 | ) |  |  | — |  |
| Other, net |  |  | (1.1 | ) |  |  | 0.3 |  |
| Total other expense, net |  |  | (3.4 | ) |  |  | (1.6 | ) |
| (Loss) Income before income taxes |  |  | (1.9 | ) |  |  | 2.3 |  |
| Income tax benefit (provision) |  |  | 0.6 |  |  |  | (0.3 | ) |
| Net (loss) income |  |  | (1.3 | ) |  |  | 2.0 |  |
| Less: Net (income) loss attributable to noncontrolling interest |  |  | — |  |  |  | (0.4 | ) |
| Net (loss) income attributable to TTM Technologies, Inc. stockholders |  |  | (1.3 | )% |  |  | 1.6 | % |

[0001193125-14-184523:mdna:25]
We manage our worldwide operations based on two geographic operating segments: 1) Asia
Pacific, which consists of five PCB fabrication plants and one drilling facility and 2) North America, which consists of seven domestic PCB fabrication plants, including a facility that provides follow-on value-added services primarily for one of
the PCB fabrication plants, and one backplane assembly plant in Shanghai, China, which is managed in conjunction with our U.S. operations. Each segment operates predominantly in the same industry with production facilities that produce similar
customized products for their customers and use similar means of product distribution.

[0001193125-14-184523:mdna:26]
The following table
compares net sales by reportable segment for the quarters ended March 31, 2014 and April 1, 2013:

[0001193125-14-184523:mdna:27]
|  |  | Quarter Ended |  |
|  |  | March 31, 2014 |  |  | April 1, 2013 |  |
|  |  | (In thousands) |  |
| Net Sales: |  |  |  |  |  |  |  |  |
| Asia Pacific |  | $ | 165,666 |  |  | $ | 202,583 |  |
| North America |  |  | 126,589 |  |  |  | 123,589 |  |
| Total sales |  |  | 292,255 |  |  |  | 326,172 |  |
| Inter-segment sales |  |  | (360 | ) |  |  | (780 | ) |
| Total net sales |  | $ | 291,895 |  |  | $ | 325,392 |  |

[0001193125-14-184523:mdna:28]
[same as prior period, unchanged from 0001193125-13-424647:mdna:10]

[0001193125-14-184523:mdna:29]
[same as prior period, unchanged from 0001193125-13-424647:mdna:32]

[0001193125-14-184523:mdna:30]
Net sales decreased $33.5 million, or 10.3%, from $325.4 million for the first quarter of 2013 to $291.9 million for the
first quarter of 2014.

[0001193125-14-184523:mdna:31]
Net sales for the Asia Pacific operating segment, excluding inter-segment sales,
decreased $36.5 million, or 18.1%, from $201.8 million in the first quarter of 2013 to $165.3 million in the first quarter of 2014. This decrease is primarily due to the absence of net sales resulting from the sale of a controlling equity interest
in a subsidiary in the second quarter of 2013 combined with lower demand in our Cellular Phone end market, which resulted in a 28% decrease in PCB shipments from the first quarter of 2013. This decrease in net sales was partially offset by a 13%
increase in the average PCB selling price, which was driven by product mix shift.

[0001193125-14-184523:mdna:32]
Net sales for the North
America operating segment increased $3.0 million, or 2.4%, from $123.6 million in the first quarter of 2013 to $126.6 million in the first quarter of 2014. This increase was primarily due to a 26% increase in demand for backplane assemblies for the
Networking / Communications end market. This increase in net sales was partially offset by a 4% decrease in demand for PCB products, primarily in the Aerospace/Defense end market.

[0001193125-14-184523:mdna:33]
[same as prior period, unchanged from 0001193125-13-424647:mdna:35]

[0001193125-14-184523:mdna:34]
Gross margin decreased from 15.6% for
the first quarter of 2013 to 13.2% for the first quarter of 2014.

[0001193125-14-184523:mdna:35]
Gross margin for the Asia Pacific segment
decreased from 15.6% for the first quarter of 2013 to 13.0% for the first quarter of 2014, primarily due to lower utilization and increased equipment related expenses at our advanced technology plants.

[0001193125-14-184523:mdna:36]
Gross margin for the North America segment decreased from 15.5% for the first quarter of 2013 to 13.5% for the first
quarter of 2014, primarily due to a mix shift toward lower margin assembly products and lower cost absorption due to lower production volumes at certain PCB fabrication plants.

[0001193125-14-184523:mdna:37]
[same as prior period, unchanged from 0001193125-13-424647:mdna:38]

[0001193125-14-184523:mdna:38]
Selling and
marketing expenses increased $0.1 million, from $9.2 million for the first quarter of 2013 to $9.3 million for the first quarter of 2014. As a percentage of net sales, selling and marketing expenses were 2.8% for the first quarter of 2013 as
compared to 3.2% for the first quarter of 2014. The increase in selling and marketing expense as a percentage of net sales is primarily due to lower net sales.

[0001193125-14-184523:mdna:39]
[same as prior period, unchanged from 0001193125-13-424647:mdna:40]

[0001193125-14-184523:mdna:40]
General and
administrative expenses decreased $4.1 million from $26.6 million, or 8.2% of net sales, for the first quarter of 2013 to $22.5 million, or 7.7% of net sales, for the first quarter of 2014. The decrease in expense primarily relates to costs savings
from the sale of a controlling equity interest in a subsidiary in the Asia Pacific operating segment, and lower incentive compensation expense.

[0001193125-14-184523:mdna:41]
[same as prior period, unchanged from 0001193125-13-424647:mdna:50]

[0001193125-14-184523:mdna:42]
Other expense, net increased $4.8 million from $5.3 million for the first quarter of 2013 to $10.1 million for the first quarter of 2014. The increase in other expense, net was primarily due to unrealized
foreign currency transaction losses of $3.6 million due to the rapid depreciation of the Chinese RMB against the U.S. Dollar, and $0.5 million loss on the extinguishment of debt related to repurchase of a portion of convertible senior notes due
2015. For the quarter ended April 1, 2013, we had an unrealized foreign currency transaction gain of $0.8 million.

[0001193125-14-184523:mdna:43]
[same as prior period, unchanged from 0001193125-13-424647:mdna:53]

[0001193125-14-184523:mdna:44]
The provision for income taxes decreased $2.7 million from a $0.8 million tax provision for the first
quarter of 2013 to $1.9 million tax benefit for the first quarter of 2014. Our effective tax rate was 10.6% for the first quarter of 2013 and 32.8% for the first quarter of 2014. The decrease in our provision for income taxes is primarily due to a
$1.5 million discrete tax benefit resulting from the retroactive approval of the high technology enterprise status for a subsidiary within the Asia Pacific operating segment. Our effective tax rate is primarily impacted by the U.S. federal income
tax rate, apportioned state income tax rates, tax rates in China and Hong Kong, generation of other credits and deductions available to us, and certain non-deductible items. Certain foreign losses generated are not more than likely to be realizable,
and thus no income tax benefit has been recognized on these losses. Additionally, as of March 31, 2014 and December 30, 2013, we had net deferred income tax assets of approximately $4.0 million and $5.4 million, respectively. Based on our
forecast for future taxable earnings, we believe it is more likely than not that we will utilize the deferred income tax assets in future periods.

[0001193125-14-184523:mdna:45]
[same as prior period, unchanged from 0001193125-13-424647:mdna:56]

[0001193125-14-184523:mdna:46]
Our principal sources of liquidity have been cash provided by operations, the issuance of convertible senior notes, and
term and revolving debt. Our principal uses of cash have been to refinance existing debt, finance capital expenditures, meet debt service requirements, fund working capital requirements and finance acquisitions. We anticipate that servicing debt,
financing capital expenditures, funding working capital requirements, and financing acquisitions will continue to be the principal demands on our cash in the future.

[0001193125-14-184523:mdna:47]
As of March 31, 2014, we had net working capital of approximately $326.9 million compared to $347.0 million as of
December 30, 2013.

[0001193125-14-184523:mdna:48]
As of March 31, 2014, we had cash and cash equivalents of approximately $318.0
million, of which approximately $96.7 million was held by our foreign subsidiaries. Of the cash and cash equivalents held by our foreign subsidiaries as of March 31, 2014, $93.0 million was located in Asia and $3.7 million was located in
Europe. Cash and cash equivalents located in our Asia Pacific operating segment are expected to be used in local operations. Cash and cash equivalents located in our backplane assembly facility in Shanghai, China, as well as in Europe, totaled
approximately $12.1 million which are managed in conjunction with our U.S. operations, are expected to be repatriated and will be subject to U.S. income tax.

[0001193125-14-184523:mdna:49]
Our 2014 capital expenditure plan is expected to total approximately $100.0 million (of which approximately $80.0 million relates to our Asia Pacific operating segment). The expenditures will fund capital
equipment purchases to increase production capacity, especially for advanced technology manufacturing, comply with increased environmental regulations, replace aging equipment, and expand our technological capabilities.

[0001193125-14-184523:mdna:50]
Based on our current level of operations, we believe that cash generated from operations, cash on hand and cash available
from borrowings under our existing credit arrangements will be adequate to meet our currently anticipated capital expenditure, debt service, working capital, and acquisition needs for the next 12 months. However, we may enter into new borrowing
arrangements, if needed, to fund our business operations or to refinance existing debt.

[0001193125-14-184523:mdna:51]
[same as prior period, unchanged from 0001193125-13-424647:mdna:62]

[0001193125-14-184523:mdna:52]
We are party to a facility agreement (Credit Agreement) consisting of a $370.0 million senior secured Term
Loan, a $90.0 million senior secured Revolving Loan and a secured $80.0 million Letters of Credit Facility. The Term Loan and Letters of Credit Facility will mature on September 14, 2016, and the Revolving Loan will mature on March 14,
2016. The Credit Agreement is secured by substantially all of the assets of our Asia Pacific operating segment and is senior to all of our other debt, including the convertible senior notes. We have fully and unconditionally guaranteed the full and
punctual payment of all Credit Agreement related obligations of the Asia Pacific operating segment.

[0001193125-14-184523:mdna:53]
Borrowings under the Credit Agreement bear interest at a floating rate of LIBOR plus an interest margin of 2.38%. At
March 31, 2014, the weighted average interest rate on the outstanding borrowings under the Credit Agreement was 2.53%.

[0001193125-14-184523:mdna:54]
Borrowings under the Credit Agreement are subject to certain financial and operating covenants that include maintaining maximum total leverage ratios and minimum net worth, current ratio, and interest
coverage ratios for both us and our Asia Pacific operating segment. In addition, our Credit Agreement includes a covenant that the Principal Shareholders (as defined in the Shareholders Agreement dated April 9, 2010 as amended on
September 14, 2012) will not reduce their shareholding below 15 percent of TTM’s issued shares. At March 31, 2014, we were in compliance with the covenants.

[0001193125-14-184523:mdna:55]
We are required to pay a commitment fee of 0.50% per annum on any unused portion of the loans and letters of credit
facility granted under the Credit Agreement. We incurred $0.1 million for the quarter ended March 31, 2014 in commitment fees. As of March 31, 2014, the outstanding amount of the Term Loan was $321.9 million, of which $96.2 million is due
for repayment in September 2014 and March 2015 and is included as short-term debt, with the remaining $225.7 million included as long-term debt. None of the Revolving Loan associated with the Credit Agreement was outstanding at March 31, 2014.
Available borrowing capacity under the Revolving Loan was $90.0 million as of March 31, 2014.

[0001193125-14-184523:mdna:56]
We have an
$80.0 million Letters of Credit Facility under the Credit Agreement. As of March 31, 2014, letters of credit in the amount of $57.0 million were outstanding under our Credit Agreement. We have other standby letters of credit outstanding in the
amount of $3.4 million, as well as other unused letter of credit facilities in the amount of $31.1 million. The outstanding standby letters of credit and unused letter of credit facilities expire between December 31, 2014 and February 28,
2015.

[0001193125-14-184523:mdna:57]
We are party to a revolving loan credit facility with a lender in the PRC. Under this arrangement, the
lender has made available to us approximately $46.7 million in unsecured borrowing with all terms of the borrowing to be negotiated at the time the revolver is drawn upon. There are no commitment fees on the unused portion of the revolver and this
arrangement expires in December 2014. As of March 31, 2014, the revolver had not been drawn upon.

[0001193125-14-184523:mdna:58]
Convertible Senior Notes due 2020

[0001193125-14-184523:mdna:59]
On December 20, 2013, we issued 1.75% convertible senior notes due December 15, 2020, in a public offering
for an aggregate principal amount of $220.0 million. The convertible senior notes bear interest at a rate of 1.75% per annum. Interest is payable semiannually in arrears on June 15 and December 15 of each year. The convertible senior
notes are senior unsecured obligations and rank equally to our future unsecured senior indebtedness and senior in right of payment to any of our future subordinated indebtedness. Offering expenses are being amortized to interest expense over the
term of the convertible senior notes.

[0001193125-14-184523:mdna:60]
During the quarter ended March 31, 2014, we closed the sale of an
additional $30.0 million aggregate principal amount of our 1.75% convertible senior notes due 2020 (Additional Notes). The Additional Notes were sold pursuant to the exercise of an over-allotment option granted by us in the underwriting agreement
related to the offer and sale of $220.0 million aggregate principal amount of our 1.75% convertible senior notes due 2020. In connection with the offering of the Additional Notes, we entered into additional convertible note hedge transactions with
respect to shares of our common stock. The additional purchased call options cover up to approximately 3.1 million shares of common stock, at a strike price of $9.64 and will expire upon the maturity of the notes. Additionally, we also entered
into additional warrant transactions, whereby we sold warrants to acquire up to approximately 3.1 million shares of common stock at a strike price of $14.26.

[0001193125-14-184523:mdna:61]
Convertible Senior Notes due 2015

[0001193125-14-184523:mdna:62]
In May 2008, we issued $175.0 million of convertible senior notes. The convertible senior notes bear interest at a
rate of 3.25% per annum. Interest is payable semiannually in arrears on May 15 and November 15 of each year. The convertible senior notes are senior unsecured obligations and rank equally to our future unsecured senior indebtedness
and senior in right of payment to any of our future subordinated indebtedness. Offering expenses are being amortized to interest expense over the term of the convertible senior notes.

[0001193125-14-184523:mdna:63]
During the quarter ended March 31, 2014, we repurchased $6.5 million principal amount of notes at approximately
103.4% of their principal amount. This repurchase was also accounted for as an extinguishment of debt and, accordingly, we recognized a loss of approximately $0.5 million, primarily associated with the premium paid to repurchase the convertible
senior notes and the recognition of certain remaining unamortized debt discount and issuance costs.

[0001193125-14-184523:mdna:64]
[same as prior period, unchanged from 0001193125-13-424647:mdna:73]

[0001193125-14-184523:mdna:65]
The following table provides information on our contractual obligations as of March 31, 2014:

[0001193125-14-184523:mdna:66]
|  |  | Total |  |  | Less Than1 Year |  |  | 1 - 3 Years |  |  | 4 - 5 Years |  |  | After5 Years |  |
|  |  | (In thousands) |  |
| Contractual Obligations(1) |  |  |  |
| Long-term debt obligations |  | $ | 321,907 |  |  | $ | 96,205 |  |  | $ | 225,702 |  |  | $ | — |  |  | $ | — |  |
| Convertible debt obligations |  |  | 282,395 |  |  |  | — |  |  |  | 32,395 |  |  |  | — |  |  |  | 250,000 |  |
| Interest on debt obligations |  |  | 46,281 |  |  |  | 12,888 |  |  |  | 15,893 |  |  |  | 8,750 |  |  |  | 8,750 |  |
| Foreign currency forward contract liabilities |  |  | 2,028 |  |  |  | 1,216 |  |  |  | 812 |  |  |  | — |  |  |  | — |  |
| Equipment payables |  |  | 65,642 |  |  |  | 53,628 |  |  |  | 12,014 |  |  |  | — |  |  |  | — |  |
| Purchase obligations |  |  | 25,249 |  |  |  | 22,416 |  |  |  | 2,833 |  |  |  | — |  |  |  | — |  |
| Operating lease commitments |  |  | 6,757 |  |  |  | 2,663 |  |  |  | 2,703 |  |  |  | 1,094 |  |  |  | 297 |  |
| Total contractual obligations |  | $ | 750,259 |  |  | $ | 189,016 |  |  | $ | 292,352 |  |  | $ | 9,844 |  |  | $ | 259,047 |  |

[0001193125-14-184523:mdna:67]
| (1) | Unrecognized uncertain tax benefits of $2.7 million are not included in the table above as we have not determined when the amount will be paid. |

[0001193125-14-184523:mdna:68]
[same as prior period, unchanged from 0001193125-13-424647:mdna:77]

[0001193125-14-184523:mdna:69]
We do not currently have, nor have we ever had, any relationships with unconsolidated entities or financial partnerships,
such as entities often referred to as structured finance or special purpose entities, which would have been established for the purpose of facilitating off-balance sheet arrangements or other contractually narrow or limited purposes. In addition, we
do not engage in trading activities involving non-exchange traded contracts. As a result, we are not materially exposed to any financing, liquidity, market, or credit risk that could arise if we had engaged in these relationships.

[0001193125-14-184523:mdna:70]
[same as prior period, unchanged from 0001193125-13-424647:mdna:79]

[0001193125-14-184523:mdna:71]
As a result of the product and customer mix of our Asia Pacific operating segment, our revenue is subject to seasonal fluctuations. These fluctuations include seasonal patterns in the computer and
cellular phone industries, which together have become a significant portion of the end markets we serve. This seasonality typically results in higher net sales in the third and fourth quarters due to end customer demand to meet fourth quarter sales
of consumer electronics products. Seasonal fluctuations also include the Chinese New Year holidays in the first quarter, which typically results in lower net sales.

[0001193125-14-184523:mdna:72]
Recently Issued Accounting Standards

[0001193125-14-184523:mdna:73]
In July 2013, the
Financial Accounting Standards Board (FASB) issued an update that would require an unrecognized tax benefit, or a portion of an unrecognized benefit, to be presented in the financial statements as a reduction to a deferred tax asset for a net
operating loss carryforward, a similar tax loss, or a tax credit carryforward. This update is effective for interim and annual periods beginning after December 15, 2013, with early adoption permitted. We adopted the amendment on January 1,
2014, and our adoption did not have a material impact on our financial statements.
