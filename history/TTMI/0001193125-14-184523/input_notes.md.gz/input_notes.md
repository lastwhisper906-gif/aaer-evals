# TTMI notes — 0001193125-14-184523


## us-gaap:ScheduleOfOtherDerivativesNotDesignatedAsHedgingInstrumentsStatementsOfFinancialPerformanceAndFinancialPositionLocationTableTextBlock

[0001193125-14-184523:notes:1]
The net gain (loss) recognized in other, net in the
 consolidated condensed statement of operations on derivative
 instruments not designated as hedges is as follows:

[0001193125-14-184523:notes:2]
|  |  | For the Quarter Ended |  |
|  |  | March 31, 2014 |  |  | April 1, 2013 |  |
|  |  | (In thousands) |  |
| Derivative instruments not designated as hedges: |  |  |  |  |  |  |  |  |
| Foreign exchange contracts |  | $ | 522 |  |  | $ | (531 | ) |
| Interest rate swap |  |  | — |  |  |  | 477 |  |
|  |  | $ | 522 |  |  | $ | (54 | ) |


## us-gaap:ReconciliationOfOperatingProfitLossFromSegmentsToConsolidatedTextBlock

[0001193125-14-184523:notes:3]
|  |  | For the Quarter Ended |  |
|  |  | March 31, 2014 |  |  | April 1, 2013 |  |
|  |  | (In thousands) |  |
| Net Sales: |  |  |  |  |  |  |  |  |
| Asia Pacific |  | $ | 165,666 |  |  | $ | 202,583 |  |
| North America |  |  | 126,589 |  |  |  | 123,589 |  |
| Total sales |  |  | 292,255 |  |  |  | 326,172 |  |
| Inter-segment sales |  |  | (360 | ) |  |  | (780 | ) |
| Total net sales |  | $ | 291,895 |  |  | $ | 325,392 |  |
| Operating Segment Income: |  |  |  |  |  |  |  |  |
| Asia Pacific |  | $ | 3,867 |  |  | $ | 11,125 |  |
| North America |  |  | 2,822 |  |  |  | 3,857 |  |
| Total operating segment income |  |  | 6,689 |  |  |  | 14,982 |  |
| Amortization of definite-lived intangibles |  |  | (2,236 | ) |  |  | (2,328 | ) |
| Total operating income |  |  | 4,453 |  |  |  | 12,654 |  |
| Total other expense |  |  | (10,107 | ) |  |  | (5,277 | ) |
| (Loss) income before income taxes |  | $ | (5,654 | ) |  | $ | 7,377 |  |


## us-gaap:ScheduleOfAccumulatedOtherComprehensiveIncomeLossTableTextBlock

[0001193125-14-184523:notes:4]
The following provides a summary of the components of
 accumulated other comprehensive income as of March 31, 2014
 and December 30, 2013:

[0001193125-14-184523:notes:5]
|  |  | Foreign Currency Translation |  |  | Gains (Losses) on Cash Flow Hedges |  |  | Unrealized Gains (Losses) on Available for Sale Securities |  |  | Total |  |
|  |  | (In thousands) |  |
| Ending balance at December 30, 2013 |  | $ | 47,280 |  |  | $ | (1,613 | ) |  | $ | (63 | ) |  | $ | 45,604 |  |
| Other comprehensive income (loss) before reclassifications |  |  | (12,093 | ) |  |  | 120 |  |  |  | (20 | ) |  |  | (11,993 | ) |
| Amounts reclassified from accumulated other comprehensive income |  |  | — |  |  |  | 25 |  |  |  | 37 |  |  |  | 62 |  |
| Other comprehensive (loss) income |  |  | (12,093 | ) |  |  | 145 |  |  |  | 17 |  |  |  | (11,931 | ) |
| Ending balance at March 31, 2014 |  | $ | 35,187 |  |  | $ | (1,468 | ) |  | $ | (46 | ) |  | $ | 33,673 |  |


## us-gaap:ScheduleOfRestructuringAndRelatedCostsTextBlock

[0001193125-14-184523:notes:6]
The
 below table shows the utilization of the accrued restructuring
 costs during the quarter ended March 31, 2014:

[0001193125-14-184523:notes:7]
|  |  | (In thousands) |  |
| Accrued at December 30, 2013 |  | $ | 637 |  |
| Adjustment to estimated employee separation charges |  |  | (24 | ) |
| Amount paid |  |  | (237 | ) |
| Accrued at March 31, 2014 |  | $ | 376 |  |


## us-gaap:ScheduleOfFairValueAssetsAndLiabilitiesMeasuredOnRecurringBasisTableTextBlock

[0001193125-14-184523:notes:8]
At March 31, 2014 and December 30, 2013, the
 following financial assets and liabilities were measured at fair
 value on a recurring basis using the type of inputs
 shown:

[0001193125-14-184523:notes:9]
|  |  | March 31, 2014 |  |  | Fair Value Measurements Using: |  |
|  |  |  | Level 1 Inputs |  |  | Level 2 Inputs |  |  | Level 3 Inputs |  |
|  |  | (In thousands) |  |
| Money market funds |  | $ | 147,339 |  |  | $ | 147,339 |  |  | $ | — |  |  |  | — |  |
| Available for sale securities |  |  | 69 |  |  |  | 69 |  |  |  | — |  |  |  | — |  |
| Foreign exchange derivative assets |  |  | 310 |  |  |  | — |  |  |  | 310 |  |  |  | — |  |
| Foreign exchange derivative liabilities |  |  | 2,028 |  |  |  | — |  |  |  | 2,028 |  |  |  | — |  |
|  |  | December 30, 2013 |  |  | Fair Value Measurements Using: |  |
|  |  |  | Level 1 Inputs |  |  | Level 2 Inputs |  |  | Level 3 Inputs |  |
|  |  | (In thousands) |  |
| Money market funds |  | $ | 23,838 |  |  | $ | 23,838 |  |  | $ | — |  |  |  | — |  |
| Available for sale securities |  |  | 148 |  |  |  | 148 |  |  |  | — |  |  |  | — |  |
| Foreign exchange derivative assets |  |  | 657 |  |  |  | — |  |  |  | 657 |  |  |  | — |  |
| Foreign exchange derivative liabilities |  |  | 2,938 |  |  |  | — |  |  |  | 2,938 |  |  |  | — |  |


## us-gaap:ScheduleOfUnrecognizedCompensationCostNonvestedAwardsTableTextBlock

[0001193125-14-184523:notes:10]
The following is a summary of total unrecognized compensation
 costs as of March 31, 2014:

[0001193125-14-184523:notes:11]
|  |  | Unrecognized Stock-Based Compensation Cost |  |  | Remaining Weighted Average Recognition Period |
|  |  | (In thousands) |  |  | (years) |
| PRU awards |  | $ | 2,102 |  |  | 1.9 |
| RSU awards |  |  | 10,866 |  |  | 1.6 |
| Stock option awards |  |  | 52 |  |  | 0.4 |
|  |  | $ | 13,020 |  |  |  |


## us-gaap:ScheduleOfInventoryCurrentTableTextBlock

[0001193125-14-184523:notes:12]
Inventories as of March 31, 2014 and December 30,
 2013 consist of the following:

[0001193125-14-184523:notes:13]
|  |  | As of |  |
|  |  | March 31, 2014 |  |  | December 30, 2013 |  |
|  |  | (In thousands) |  |
| Inventories: |  |  |  |  |  |  |  |  |
| Raw materials |  | $ | 43,950 |  |  | $ | 42,533 |  |
| Work-in-process |  |  | 52,346 |  |  |  | 48,338 |  |
| Finished goods |  |  | 43,019 |  |  |  | 47,274 |  |
|  |  | $ | 139,315 |  |  | $ | 138,145 |  |


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001193125-14-184523:notes:14]
(7)
 Financial Instruments

[0001193125-14-184523:notes:15]
[same as prior period, unchanged from 0001193125-13-424647:notes:23]

[0001193125-14-184523:notes:16]
The Company enters into foreign currency forward contracts to
 mitigate the impact of changes in foreign currency exchange rates
 and to reduce the volatility of purchases and other obligations
 generated in currencies other than the functional currencies. The
 Company’s foreign subsidiaries may at times purchase forward
 exchange contracts to manage their foreign currency risks in
 relation to certain purchases of machinery denominated in foreign
 currencies other than the Company’s foreign functional
 currency. The notional amount of the foreign exchange contracts as
 of March 31, 2014 and December 30, 2013 was approximately
 $40,038 and $47,000, respectively. The Company has designated
 certain of these foreign exchange contracts as cash flow
 hedges.

[0001193125-14-184523:notes:17]
[same as prior period, unchanged from 0001193125-13-424647:notes:29]

[0001193125-14-184523:notes:18]
|  |  |  |  | Asset / (Liability) Fair Value |  |
|  |  | Balance Sheet Location |  | March 31, 2014 |  |  | December 30, 2013 |  |
|  |  |  |  | (In thousands) |  |
| Cash flow derivative instruments designated as hedges: |  |  |  |  |  |  |  |  |
| Foreign exchange contracts |  | Other accrued expenses |  | $ | (70 | ) |  | $ | (751 | ) |
| Foreign exchange contracts |  | Deposits and other non-current assets |  |  | — |  |  |  | 10 |  |
| Cash flow derivative instruments not designated as hedges: |  |  |  |  |  |  |  |  |
| Foreign exchange contracts |  | Prepaid expenses and other current assets |  |  | 310 |  |  |  | 647 |  |
| Foreign exchange contracts |  | Other accrued expenses |  |  | (1,146 | ) |  |  | (899 | ) |
| Foreign exchange contracts |  | Other long-term liabilities |  |  | (812 | ) |  |  | (1,288 | ) |
|  |  |  |  | $ | (1,718 | ) |  | $ | (2,281 | ) |

[0001193125-14-184523:notes:19]
[same as prior period, unchanged from 0001193125-13-424647:notes:31]

[0001193125-14-184523:notes:20]
|  |  |  |  | For the Quarter Ended |  |
|  |  |  |  | March 31, 2014 |  |  | April 1, 2013 |  |
|  |  |  |  | Effective Portion |  |  | Ineffective Portion |  |  | Effective Portion |  |  | Ineffective Portion |  |
|  |  | Financial Statement Caption |  | Gain/(Loss) Recognized in Other Comprehensive Income |  |  | Gain/(Loss) Reclassified into Income |  |  | Gain/(Loss) Reclassified into Income |  |  | Gain/(Loss) Recognized in Other Comprehensive Income |  |  | Gain/(Loss) Reclassified into Income |  |  | Gain/(Loss) Recognized into Income |  |
|  |  | (In thousands) |  |
| Cash flow hedge: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Foreign currency forward |  | Depreciation expense |  | $ | 120 |  |  | $ | 25 |  |  | $ | — |  |  | $ | (381 | ) |  | $ | — |  |  | $ | — |  |
|  |  |  |  | $ | 120 |  |  | $ | 25 |  |  | $ | — |  |  | $ | (381 | ) |  | $ | — |  |  | $ | — |  |

[0001193125-14-184523:notes:21]
The following table provides a summary of the activity
 associated with the designated cash flow hedges reflected in
 accumulated other comprehensive income for the quarters ended
 March 31, 2014 and April 1, 2013:

[0001193125-14-184523:notes:22]
|  |  | For the Quarter Ended |  |
|  |  | March 31, 2014 |  |  | April 1, 2013 |  |
|  |  | (In thousands) |  |
| Beginning balance unrealized loss, net of tax |  | $ | (1,613 | ) |  | $ | (15 | ) |
| Changes in fair value, net of tax |  |  | 120 |  |  |  | (381 | ) |
| Reclassification to earnings |  |  | 25 |  |  |  | — |  |
| Ending balance unrealized loss, net of tax |  | $ | (1,468 | ) |  | $ | (396 | ) |

[0001193125-14-184523:notes:23]
The Company expects that approximately $162 of expense will be
 reclassified into the statement of operations, net of tax, in the
 next 12 months.

[0001193125-14-184523:notes:24]
Other
 Financial Instruments

[0001193125-14-184523:notes:25]
The carrying amount and estimated fair value of the
 Company’s financial instruments at March 31, 2014 and
 December 30, 2013 were as follows:

[0001193125-14-184523:notes:26]
|  |  | March 31, 2014 |  |  | December 30, 2013 |  |
|  |  | Carrying Amount |  |  | Fair Value |  |  | Carrying Amount |  |  | Fair Value |  |
|  |  | (In thousands) |  |
| Available for sale securities |  | $ | 69 |  |  | $ | 69 |  |  | $ | 148 |  |  | $ | 148 |  |
| Derivative assets, current |  |  | 310 |  |  |  | 310 |  |  |  | 647 |  |  |  | 647 |  |
| Derivative liabilities, current |  |  | 1,216 |  |  |  | 1,216 |  |  |  | 1,650 |  |  |  | 1,650 |  |
| Derivative assets, non-current |  |  | — |  |  |  | — |  |  |  | 10 |  |  |  | 10 |  |
| Derivative liabilities, non-current |  |  | 812 |  |  |  | 812 |  |  |  | 1,288 |  |  |  | 1,288 |  |
| Long-term debt |  |  | 321,907 |  |  |  | 321,248 |  |  |  | 370,008 |  |  |  | 369,402 |  |
| Convertible senior notes due 2015 |  |  | 30,783 |  |  |  | 33,360 |  |  |  | 36,568 |  |  |  | 39,960 |  |
| Convertible senior notes due 2020 |  |  | 191,705 |  |  |  | 277,425 |  |  |  | 167,167 |  |  |  | 237,050 |  |

[0001193125-14-184523:notes:27]
[same as prior period, unchanged from 0001193125-13-424647:notes:40]

[0001193125-14-184523:notes:28]
The fair value of the derivative instruments was determined
 using pricing models developed based on the LIBOR swap rate,
 foreign currency exchange rates, and other observable market data,
 including quoted market prices, as appropriate. The values were
 adjusted to reflect nonperformance risk of the counterparty and the
 Company, as necessary.

[0001193125-14-184523:notes:29]
The fair value of the long-term debt was estimated based on
 discounting the debt over its life using current market rates for
 similar debt as of March 31, 2014 and December 30,
 2013.

[0001193125-14-184523:notes:30]
[same as prior period, unchanged from 0001193125-13-424647:notes:43]

[0001193125-14-184523:notes:31]
As of March 31, 2014 and December 30, 2013, the
 Company’s other financial instruments also included cash and
 cash equivalents, accounts receivable, accounts payable and
 equipment payables. Due to short-term maturities, the carrying
 amount of these instruments approximates fair value.


## us-gaap:ScheduleOfShareBasedCompensationArrangementByShareBasedPaymentAwardPerformanceBasedUnitsVestedAndExpectedToVestTableTextBlock

[0001193125-14-184523:notes:32]
PRUs activity for the quarter ended March 31, 2014 was as
 follows:

[0001193125-14-184523:notes:33]
|  |  | Shares |  |
|  |  | (In thousands) |  |
| Outstanding target shares at December 30, 2013 |  |  | 353 |  |
| Granted: |  |  |  |  |
| Third tranche of 2012 grant |  |  | 59 |  |
| Second tranche of 2013 grant |  |  | 113 |  |
| First tranche of 2014 grant |  |  | 86 |  |
| Change in units due to annual performance achievement |  |  | (10 | ) |
| Vested |  |  | (90 | ) |
| Forfeitures / cancellations |  |  | (34 | ) |
| Outstanding target shares at March 31, 2014 |  |  | 477 |  |


## us-gaap:FairValueDisclosuresTextBlock

[0001193125-14-184523:notes:34]
(10) Fair Value
 Measures

[0001193125-14-184523:notes:35]
[same as prior period, unchanged from 0001193125-13-424647:notes:48]

[0001193125-14-184523:notes:36]
There were no transfers of financial assets or liabilities
 between Level 1 and Level 2 inputs for the quarters ended
 March 31, 2014 and April 1, 2013. See Note 7 for the fair
 value disclosures over long-term debt and convertible senior
 notes.


## us-gaap:ConcentrationRiskDisclosureTextBlock

[0001193125-14-184523:notes:37]
(9) Significant Customers
 and Concentration of Credit Risk

[0001193125-14-184523:notes:38]
In the
 normal course of business, the Company extends credit to its
 customers, which are concentrated primarily in the computer,
 networking and communications, and aerospace and defense
 industries. Most are located outside the United States, with the
 exception of aerospace and defense industries. The Company performs
 ongoing credit evaluations of customers, does not require
 collateral and considers the credit risk profile of the entity from
 which the receivable is due in further evaluating collection
 risk.

[0001193125-14-184523:notes:39]
[same as prior period, unchanged from 0001193125-13-424647:notes:57]

[0001193125-14-184523:notes:40]
For
 the quarters ended March 31, 2014 and April 1, 2013 one
 customer accounted for approximately 16% and 14%, respectively, of
 the Company’s net sales.


## us-gaap:ScheduleOfMaturitiesOfLongTermDebtTableTextBlock

[0001193125-14-184523:notes:41]
The calendar maturities of long-term debt through 2016 are as
 follows:

[0001193125-14-184523:notes:42]
|  |  | (In thousands) |  |
| Remaining 2014 |  | $ | 48,103 |  |
| 2015 |  |  | 96,204 |  |
| 2016 |  |  | 177,600 |  |
|  |  | $ | 321,907 |  |


## us-gaap:InventoryDisclosureTextBlock

[0001193125-14-184523:notes:43]
(3)
 Inventories


## us-gaap:ScheduleOfEarningsPerShareBasicAndDilutedTableTextBlock

[0001193125-14-184523:notes:44]
The following is a reconciliation of the numerator and
 denominator used to calculate basic earnings per share and diluted
 earnings per share for the quarters ended March 31, 2014 and
 April 1, 2013:

[0001193125-14-184523:notes:45]
|  |  | Quarter Ended |  |
|  |  | March 31, 2014 |  |  | April 1, 2013 |  |
|  |  | (In thousands, except per share amounts) |  |
| Net (loss) income attributable to TTM Technologies, Inc. stockholders |  | $ | (3,799 | ) |  | $ | 5,152 |  |
| Weighted average shares outstanding |  |  | 82,925 |  |  |  | 82,150 |  |
| Dilutive effect of performance-based stock units, restricted stock units and stock options |  |  | — |  |  |  | 692 |  |
| Diluted shares |  |  | 82,925 |  |  |  | 82,842 |  |
| (Loss) earnings per share attributable to TTM Technologies, Inc stockholders: |  |  |  |  |  |  |  |  |
| Basic |  | $ | (0.05 | ) |  | $ | 0.06 |  |
| Diluted |  | $ | (0.05 | ) |  | $ | 0.06 |  |


## us-gaap:LongTermDebtTextBlock

[0001193125-14-184523:notes:46]
(4)
 Long-term Debt and Letters of Credit

[0001193125-14-184523:notes:47]
The following table summarizes the long-term debt of the
 Company as of March 31, 2014 and December 30,
 2013:

[0001193125-14-184523:notes:48]
|  |  | Average Effective Interest Rate as of March 31, 2014 |  | March 31, 2014 |  |  | Average Effective Interest Rate as of December 30, 2013 |  | December 30, 2013 |  |
|  |  | (In thousands) |  |
| Term loan due September 2016 |  | 2.53% |  | $ | 321,900 |  |  | 2.55% |  | $ | 370,000 |  |
| Other |  | 6.00% |  |  | 7 |  |  | 6.00% |  |  | 8 |  |
|  |  |  |  |  | 321,907 |  |  |  |  |  | 370,008 |  |
| Less: current maturities |  |  |  |  | (96,205 | ) |  |  |  |  | (96,204 | ) |
| Long-term debt, less current maturities |  |  |  | $ | 225,702 |  |  |  |  | $ | 273,804 |  |

[0001193125-14-184523:notes:49]
Credit
 Agreement

[0001193125-14-184523:notes:50]
In 2012, the Company became a party to a facility agreement
 (Credit Agreement) consisting of a $370,000 senior secured term
 loan (Term Loan), a $90,000 senior secured revolving loan
 (Revolving Loan), and a secured $80,000 letters of credit facility
 (Letters of Credit Facility). The Term Loan and Letters of Credit
 Facility will mature on September 14, 2016. The Revolving Loan
 will mature on March 14, 2016. The Credit Agreement is secured
 by substantially all of the assets of the Company’s Asia
 Pacific operating segment and is senior to all other debt,
 including the convertible senior notes. See Note 5. The Company has
 fully and unconditionally guaranteed the full and punctual payment
 of all Credit Agreement related obligations of its Asia Pacific
 operating segment.

[0001193125-14-184523:notes:51]
As of March 31, 2014 and December 30, 2013, the
 remaining unamortized debt issuance costs included in other
 non-current assets was $1,728 and $1,937 and is amortized to
 interest expense over the term of the Company’s Credit
 Agreement using the effective interest rate method. At
 March 31, 2014, the remaining amortization period for the
 unamortized debt issuance costs was 2.2 years.

[0001193125-14-184523:notes:52]
The Company is also required to pay a commitment fee of
 0.50% per annum on any unused portion of the loan and letters
 of credit facility granted under the Credit Agreement. The Company
 incurred commitment fees related to unused borrowing availability
 of $133 and $96 for the quarters ended March 31, 2014 and
 April 1, 2013, respectively. As of March 31, 2014, the
 outstanding amount of the Term Loan under the Credit Agreement is
 $321,900, of which $96,200 is due for repayment in September 2014
 and March 2015 and is included as short-term debt, with the
 remaining $225,700 included as long-term debt. None of the Revolver
 was outstanding under the Credit Agreement as of March 31,
 2014. Available borrowing capacity under the Revolving Loan was
 $90,000 at March 31, 2014.

[0001193125-14-184523:notes:53]
Other
 Credit Facility

[0001193125-14-184523:notes:54]
Additionally, the Company is party to a revolving loan credit
 facility with a lender in the People’s Republic of China
 (PRC). Under this arrangement, the lender has made available to the
 Company approximately $46,700 in unsecured borrowing with all terms
 of the borrowing to be negotiated at the time the revolver is drawn
 upon. There are no commitment fees on the unused portion of the
 revolver and this arrangement expires in December 2014. As of
 March 31, 2014, the revolver had not been drawn
 upon.

[0001193125-14-184523:notes:55]
Letters
 of Credit

[0001193125-14-184523:notes:56]
The Company has an $80,000 Letters of Credit Facility under the
 Credit Agreement, as mentioned above. As of March 31, 2014,
 letters of credit in the amount of $56,986 were outstanding under
 this Credit Agreement. The Company has other standby letters of
 credit outstanding in the amount of $3,394 million, as well other
 unused letter of credit facilities in the amount of $31,100. The
 outstanding standby letters of credit and unused letter of credit
 facilities expire between December 31, 2014 and
 February 28, 2015.


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0001193125-14-184523:notes:57]
[same as prior period, unchanged from 0001193125-13-424647:notes:76]

[0001193125-14-184523:notes:58]
On
 September 6, 2013, the Company announced its plan to cease
 manufacturing at its Suzhou, China facility and lay off 774
 employees at this site. The Company has ceased production, but
 complete shutdown of the facility is not expected until the second
 quarter of 2014. The Suzhou, China manufacturing facility is
 included in the Asia Pacific reporting unit and operating
 segment.

[0001193125-14-184523:notes:59]
As of
 March 31, 2014, 27 employees had not yet been separated. The
 Company expects most of the remaining employees to be separated and
 the remaining accrued restructuring costs to be paid by the end of
 the second quarter of 2014. Accrued restructuring costs are
 included as a component of accrued salaries, wages and benefits in
 the consolidated condensed balance sheet.


## us-gaap:ReclassificationOutOfAccumulatedOtherComprehensiveIncomeTableTextBlock

[0001193125-14-184523:notes:60]
The following provides a summary of reclassifications out of
 accumulated other comprehensive income for the quarters ended
 March 31, 2014 and April 1, 2013:

[0001193125-14-184523:notes:61]
|  |  |  |  | Amount Reclassified from Accumulated Other Comprehensive Income For the Quarter Ended |  |
| Details about Accumulated Other Comprehensive Income Components |  | Statement of Operations Location |  | March 31, 2014 |  |  | April 1, 2013 |  |
| Loss on cash flow hedges |  | Depreciation expense, net of tax |  | $ | 25 |  |  | $ | — |  |
| Loss on available for sale securities |  | Other, net, net of tax |  | $ | 37 |  |  | $ | — |  |


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0001193125-14-184523:notes:62]
(8)
 Accumulated Other Comprehensive Income

[0001193125-14-184523:notes:63]
Foreign currency translation amounts as of March 31, 2014
 and December 30, 2013 are net of tax of $3,013 and $3,132,
 respectively.


## us-gaap:EarningsPerShareTextBlock

[0001193125-14-184523:notes:64]
(12)
 Earnings Per Share

[0001193125-14-184523:notes:65]
For the quarter ended March 31, 2014, potential shares of
 common stock, consisting of stock options to purchase approximately
 597 shares of common stock at exercise prices ranging from $5.78 to
 $16.82 per share, 1,769 restricted stock units, and 229
 performance-based restricted stock units were not included in the
 computation of diluted earnings per share because the Company
 incurred a net loss and, as a result, the impact would be
 anti-dilutive.

[0001193125-14-184523:notes:66]
For the quarter ended April 1, 2013, performance-based
 stock units, restricted stock units and stock options to purchase
 2,508 shares of common stock, were not considered in calculating
 diluted earnings per share because the options’ exercise
 prices or the total expected proceeds under the treasury stock
 method for performance-based stock units, restricted stock units or
 stock options was greater than the average market price of common
 shares during the period and, therefore, the effect would be
 anti-dilutive.

[0001193125-14-184523:notes:67]
Additionally, for the quarters ended March 31, 2014 and
 April 1, 2013, the effect of 27,970 and 10,963 shares of
 common stock, related to the Company’s convertible senior
 notes, respectively, and warrants to purchase 28,020 and 10,963
 shares of common stock, respectively, were not included in the
 computation of dilutive earnings per share because the effect would
 be anti-dilutive.


## us-gaap:RelatedPartyTransactionsDisclosureTextBlock

[0001193125-14-184523:notes:68]
(15) Related Party
 Transactions

[0001193125-14-184523:notes:69]
In the normal course of business, the Company’s foreign
 subsidiaries purchase laminate and prepreg from related parties in
 which a significant shareholder of the Company holds an equity
 interest. For the quarters ended March 31, 2014 and
 April 1, 2013, the Company’s foreign subsidiaries
 purchased $11,790 and $19,137 respectively, of laminate and prepreg
 from these related parties.

[0001193125-14-184523:notes:70]
Dongguan Shengyi Electronics Ltd., (SYE) is a related party as
 a significant shareholder of the Company holds an equity interest
 in the parent company of SYE. Subsequent to the Company’s
 sale of its controlling interest in SYE in June 2013, the Company
 began selling PCBs to, and purchasing PCBs from, SYE. Sales to and
 purchases from SYE, for the quarter ended March 31, 2014 were
 approximately $10,147 and $271, respectively. There were no sales
 to or purchases from SYE for the quarter ended April 1,
 2013.

[0001193125-14-184523:notes:71]
As of March 31, 2014 and December 30, 2013, the
 Company’s consolidated condensed balance sheet included
 $19,882 and $19,547, respectively, in accounts payable due to, and
 $16,975 and $13,312, respectively, in accounts receivable due from
 a related party for the purchase of laminate and prepreg, and sales
 of PCBs to SYE, as mentioned above.


## us-gaap:ScheduleOfEmployeeServiceShareBasedCompensationAllocationOfRecognizedPeriodCostsTextBlock

[0001193125-14-184523:notes:72]
[same as prior period, unchanged from 0001193125-13-424647:notes:95]

[0001193125-14-184523:notes:73]
|  |  | Quarter Ended |  |
|  |  | March 31, 2014 |  |  | April 1, 2013 |  |
|  |  | (In thousands) |  |
| Cost of goods sold |  | $ | 263 |  |  | $ | 303 |  |
| Selling and marketing |  |  | 335 |  |  |  | 362 |  |
| General and administrative |  |  | 1,570 |  |  |  | 1,665 |  |
| Stock-based compensation expense recognized |  |  | 2,168 |  |  |  | 2,330 |  |
| Income tax benefit recognized |  |  | (570 | ) |  |  | (497 | ) |
| Total stock-based compensation expense after income taxes |  | $ | 1,598 |  |  | $ | 1,833 |  |


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0001193125-14-184523:notes:74]
[same as prior period, unchanged from 0001193125-13-424647:notes:97]

[0001193125-14-184523:notes:75]
TTM
 Technologies, Inc. (the Company or TTM) is a leading global
 provider of time-critical and technologically complex printed
 circuit board (PCB) products and backplane assemblies (PCBs
 populated with electronic components), which serve as the
 foundation of sophisticated electronic products. The Company
 provides advanced technology products and offers a one-stop
 manufacturing solution to customers from engineering support to
 prototype development through final volume production. The Company
 serves a diversified customer base in various markets throughout
 the world, including manufacturers of networking/communications
 infrastructure products, touch screen tablets and smartphones. The
 Company also serves aerospace and defense, high-end computing, and
 industrial/medical industries. The Company’s customers
 include both original equipment manufacturers (OEMs) and electronic
 manufacturing services (EMS) providers.

[0001193125-14-184523:notes:76]
The
 accompanying consolidated condensed financial statements have been
 prepared by the Company, without audit, pursuant to the rules and
 regulations of the Securities and Exchange Commission (SEC).
 Certain information and disclosures normally included in financial
 statements prepared in accordance with accounting principles
 generally accepted in the United States of America have been
 condensed or omitted pursuant to such rules and regulations. These
 consolidated condensed financial statements reflect all adjustments
 (consisting only of normal recurring adjustments) which, in the
 opinion of management, are necessary to present fairly the
 financial position, the results of operations and cash flows of the
 Company for the periods presented. It is suggested that these
 consolidated condensed financial statements be read in conjunction
 with the consolidated financial statements and the notes thereto
 included in the Company’s most recent Annual Report on Form
 10-K. The results of operations for the interim periods are not
 necessarily indicative of the results to be expected for the full
 year. The preparation of financial statements in accordance with
 U.S. generally accepted accounting principles requires management
 to make estimates and assumptions that affect the amounts reported
 in the Company’s consolidated condensed financial statements
 and accompanying notes. Actual results could differ materially from
 those estimates. The Company uses a 13-week fiscal quarter
 accounting period with fourth quarter ending on the Monday nearest
 December 31.


## us-gaap:ScheduleOfShareBasedPaymentAwardStockOptionsValuationAssumptionsTableTextBlock

[0001193125-14-184523:notes:77]
For the quarters ended March 31, 2014 and April 1,
 2013, the following assumptions were used in determining the fair
 value:

[0001193125-14-184523:notes:78]
|  |  | March 31, 20141 |  |  | April 1, 20132 |  |
| Weighted-average fair value |  | $ | 5.80 |  |  | $ | 6.79 |  |
| Risk-free interest rate |  |  | 0.4 | % |  |  | 0.3 | % |
| Dividend yield |  |  | — |  |  |  | — |  |
| Expected volatility |  |  | 41 | % |  |  | 49 | % |
| Expected term in months |  |  | 23 |  |  |  | 25 |  |

[0001193125-14-184523:notes:79]
| (1) | Reflects the weighted-averages for the third year of the three-year performance period applicable to PRUs granted in 2012, second year of the three-year performance period applicable to PRUs granted in 2013 and first year of the three-year performance period applicable to PRUs granted in 2014. |

[0001193125-14-184523:notes:80]
| (2) | Reflects the weighted-averages for the third year of the three-year performance period applicable to PRUs granted in 2011, second year of the three-year performance period applicable to PRUs granted in 2012 and first year of the three-year performance period applicable to PRUs granted in 2013. |


## us-gaap:IncomeTaxDisclosureTextBlock

[0001193125-14-184523:notes:81]
(6) Income
 Taxes

[0001193125-14-184523:notes:82]
The
 Company’s effective tax rate was 32.8% and 10.6% for the
 quarters ended March 31, 2014 and April 1, 2013,
 respectively. The Company’s effective tax rate will generally
 differ from the U.S. federal statutory rate of 35% due to favorable
 tax rates associated with earnings from the Company’s
 operations in lower-tax jurisdictions in China, the apportioned
 state income tax rates, generation of other credits and deductions
 available to us, and certain non-deductible items.

[0001193125-14-184523:notes:83]
During
 the quarter ended March 31, 2014, the Company’s
 effective tax rate was further impacted by a discrete tax benefit
 resulting from the retroactive approval of the high technology
 enterprise status for certain Chinese subsidiaries within the
 Company’s Asia Pacific operating segment. The Company’s
 effective tax rate for the quarter ended April 1, 2013 was
 impacted by the recognition of discrete tax benefits from the
 extension of federal research and development credit laws, and from
 the approval of research and development deduction in
 China.

[0001193125-14-184523:notes:84]
Certain foreign losses generated are not more than likely to be
 realizable, and thus, no income tax benefit has been recognized on
 these losses. The Company’s foreign earnings attributable to
 the Asia Pacific operating segment will be permanently reinvested
 in such foreign jurisdictions and, therefore, no deferred tax
 liabilities for U.S. income taxes on undistributed earnings are
 recorded.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001193125-14-184523:notes:85]
(13) Stock-Based
 Compensation

[0001193125-14-184523:notes:86]
[same as prior period, unchanged from 0001193125-13-424647:notes:113]

[0001193125-14-184523:notes:87]
The Company maintains a long-term incentive program for
 executives that provides for the issuance of performance-based
 restricted stock units (PRUs), representing hypothetical shares of
 the Company’s common stock that may be issued. Under the PRU
 program, a target number of PRUs is awarded at the beginning of
 each three-year performance period. The number of shares of common
 stock released at the end of the performance period will range from
 zero to 2.4 times the target number depending on performance during
 the period. The performance metrics of the PRU program are based on
 (a) annual financial targets, which are based on revenue and
 EBITDA (earnings before interest, tax, depreciation, and
 amortization expense), each equally weighted, and (b) an
 overall modifier based on the Company’s total stockholder
 return (TSR) relative to the S&P SmallCap 600 for PRUs granted
 in 2012, and, for PRUs granted in 2013 and 2014, a group of peer
 companies selected by the Company’s compensation committee,
 over the three-year performance period.

[0001193125-14-184523:notes:88]
The Company records stock-based compensation expense for PRU
 awards granted based on management’s periodic assessment of
 the probability of the PRU awards vesting. For the quarter ended
 March 31, 2014, management determined that vesting of the PRU
 awards was probable. PRUs activity for the quarter ended
 March 31, 2014 was as follows:

[0001193125-14-184523:notes:89]
The fair value for PRUs granted is calculated using a Monte
 Carlo simulation model, as the TSR modifier contains a market
 condition. For the quarters ended March 31, 2014 and
 April 1, 2013, the following assumptions were used in
 determining the fair value:

[0001193125-14-184523:notes:90]
[same as prior period, unchanged from 0001193125-13-424647:notes:117]

[0001193125-14-184523:notes:91]
The Company granted 760 and 828 restricted stock units during
 the quarters ended March 31, 2014 and April 1, 2013,
 respectively. The units granted have a weighted-average fair value
 per unit of $8.00 and $8.27 for the quarters ended March 31,
 2014 and April 1, 2013, respectively. The fair value for
 restricted stock units granted is based on the closing share price
 of the Company’s common stock on the date of
 grant.

[0001193125-14-184523:notes:92]
[same as prior period, unchanged from 0001193125-13-424647:notes:119]

[0001193125-14-184523:notes:93]
The Company did not grant any stock option awards during the
 quarters ended March 31, 2014 and April 1,
 2013.

[0001193125-14-184523:notes:94]
[same as prior period, unchanged from 0001193125-13-424647:notes:123]


## us-gaap:SegmentReportingDisclosureTextBlock

[0001193125-14-184523:notes:95]
(14) Segment
 Information

[0001193125-14-184523:notes:96]
The
 operating segments reported below are the Company’s segments
 for which separate financial information is available and upon
 which operating results are evaluated by the chief operating
 decision maker to assess performance and to allocate resources. The
 Company manages its worldwide operations based on two geographic
 operating segments: 1) Asia Pacific, which consists of five PCB
 fabrication plants and one drilling facility, and 2) North America,
 which consists of seven domestic PCB fabrication plants, including
 a facility that provides follow-on value-added services primarily
 for one of the PCB fabrication plants, and one backplane assembly
 plant in Shanghai, China, which is managed in conjunction with the
 Company’s U.S. operations. Each segment operates
 predominantly in the same industry with production facilities that
 produce similar customized products for its customers and use
 similar means of product distribution.

[0001193125-14-184523:notes:97]
The
 Company evaluates segment performance based on operating segment
 income, which is operating income before amortization of
 intangibles. Interest expense and interest income are not presented
 by segment since they are not included in the measure of segment
 profitability reviewed by the chief operating decision maker. All
 inter-segment transactions have been eliminated. Reportable segment
 assets exclude short-term investments, which are managed
 centrally.

[0001193125-14-184523:notes:98]
The
 Company accounts for inter-segment sales and transfers as if the
 sale or transfer were to third parties: at arms length and
 consistent with the Company’s revenue recognition policy. The
 inter-segment sales for the quarter ended March 31, 2014 and
 April 1, 2013 are sales from the Asia Pacific operating
 segment to the North America operating segment.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001193125-14-184523:notes:99]
(11) Commitments and
 Contingencies

[0001193125-14-184523:notes:100]
Legal
 Matters

[0001193125-14-184523:notes:101]
The Company is subject to various legal matters, which it
 considers normal for its business activities. While the Company
 currently believes that the amount of any reasonably possible or
 probable loss for known matters would not be material to the
 Company’s financial condition, the outcome of these actions
 is inherently difficult to predict. In the event of an adverse
 outcome, the ultimate potential loss could have a material adverse
 effect on the Company’s financial condition or results of
 operations in a particular period. The Company has accrued amounts
 for its loss contingencies which are probable and estimable at
 March 31, 2014 and December 30, 2013. However, these
 amounts are not material to the consolidated condensed financial
 statements of the Company.

[0001193125-14-184523:notes:102]
Environmental
 Matters

[0001193125-14-184523:notes:103]
The process to manufacture PCBs requires adherence to city,
 county, state, federal and foreign environmental regulations
 regarding the storage, use, handling and disposal of chemicals,
 solid wastes and other hazardous materials as well as compliance
 with air quality standards. The Company believes that its
 facilities in the United States comply in all material respects
 with applicable environmental laws and regulations. In China,
 governmental authorities are taking various steps to tighten the
 rules and regulations governing environmental issues. An
 update to Chinese environmental law was issued in late 2012, but
 allows for an interim period in which foreign entities may adjust
 to the new regulatory regime and come into full compliance with the
 new laws. The Company’s plants in China are not yet in
 full compliance with the current environmental regulations as
 updated in late 2012. The Company does not anticipate any
 immediate risk of government fines or temporary closure of Chinese
 plants. The Company has established and enacted an investment
 plan, which includes capital expenditures estimated to be
 approximately $4,700 for 2014, to address the regulatory changes in
 order to come into full compliance during the interim
 period.


## ttmi:ScheduleOfComponentsOfInterestExpenseFromConvertibleNotesTableTextBlock

[0001193125-14-184523:notes:104]
The components of interest expense resulting from the
 convertible senior notes for the quarters ended March 31, 2014
 and April 1, 2013 are as follows:

[0001193125-14-184523:notes:105]
|  |  | For the Quarter Ended |  |
|  |  | March 31, 2014 |  |  | April 1, 2013 |  |
|  |  | (In thousands) |  |
| Contractual coupon interest |  |  |  |  |  |  |  |  |
| Convertible senior notes due 2020 |  | $ | 1,085 |  |  | $ | — |  |
| Convertible senior notes due 2015 |  |  | 263 |  |  |  | 1,422 |  |
|  |  | $ | 1,348 |  |  | $ | 1,422 |  |
| Amortization of debt discount |  |  |  |  |  |  |  |  |
| Convertible senior notes due 2020 |  | $ | 1,764 |  |  | $ | — |  |
| Convertible senior notes due 2015 |  |  | 338 |  |  |  | 1,680 |  |
|  |  | $ | 2,102 |  |  | $ | 1,680 |  |
| Amortization of debt issuance costs |  |  |  |  |  |  |  |  |
| Convertible senior notes due 2020 |  | $ | 177 |  |  | $ | — |  |
| Convertible senior notes due 2015 |  |  | 34 |  |  |  | 169 |  |
|  |  | $ | 211 |  |  | $ | 169 |  |


## ttmi:ScheduleOfLiabilityAndEquityComponentsOfConvertibleNotesTableTextBlock

[0001193125-14-184523:notes:106]
As of March 31, 2014 and December 30, 2013, the
 following summarizes the liability and equity components of the
 convertible senior notes:

[0001193125-14-184523:notes:107]
|  |  | As of March 31, 2014 |  |  | As of December 30, 2013 |  |
|  |  | Principal |  |  | Unamortized Discount |  |  | Net Carrying Amount |  |  | Principal |  |  | Unamortized Discount |  |  | Net Carrying Amount |  |
|  |  | (in thousands) |  |
| Liability components: |  |  |  |  |
| Convertible senior notes due 2020 |  | $ | 250,000 |  |  | $ | (58,295 | ) |  | $ | 191,705 |  |  | $ | 220,000 |  |  | $ | (52,833 | ) |  | $ | 167,167 |  |
| Convertible senior notes due 2015 |  |  | 32,395 |  |  |  | (1,612 | ) |  |  | 30,783 |  |  |  | 38,909 |  |  |  | (2,341 | ) |  |  | 36,568 |  |
| Total |  | $ | 282,395 |  |  | $ | (59,907 | ) |  | $ | 222,488 |  |  | $ | 258,909 |  |  | $ | (55,174 | ) |  | $ | 203,735 |  |

[0001193125-14-184523:notes:108]
|  |  | As of March 31, 2014 |  |  | As of December 30, 2013 |  |
|  |  | Embedded conversion option — Convertible Senior Notes |  |  | Embedded conversion option — Convertible Senior Notes Issuance Costs |  |  | Total |  |  | Embedded conversion option — Convertible Senior Notes |  |  | Embedded conversion option — Convertible Senior Notes Issuance Costs |  |  | Total |  |
|  |  | (in thousands) |  |
| Equity components: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Additional paid-in capital: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Convertible senior notes due 2020 |  | $ | 60,227 |  |  | $ | (1,916 | ) |  | $ | 58,311 |  |  | $ | 53,000 |  |  | $ | (1,644 | ) |  | $ | 51,356 |  |
| Convertible senior notes due 2015 |  |  | 39,781 |  |  | $ | (1,413 | ) |  |  | 38,368 |  |  |  | 39,928 |  |  | $ | (1,413 | ) |  |  | 38,515 |  |
|  |  | $ | 100,008 |  |  | $ | (3,329 | ) |  | $ | 96,679 |  |  | $ | 92,928 |  |  | $ | (3,057 | ) |  | $ | 89,871 |  |


## ttmi:ConvertibleSeniorNotesTextBlock

[0001193125-14-184523:notes:109]
(5)
 Convertible Senior Notes

[0001193125-14-184523:notes:110]
Convertible Senior Notes due 2020

[0001193125-14-184523:notes:111]
In December 2013, the Company issued 1.75% convertible
 senior notes due December 15, 2020, in a public offering for
 an aggregate principal amount of $220,000. The convertible senior
 notes bear interest at a rate of 1.75% per annum. Interest is
 payable semiannually in arrears on June 15 and
 December 15 of each year. The convertible senior notes are
 senior unsecured obligations and rank equally to the
 Company’s future unsecured senior indebtedness and senior in
 right of payment to any of the Company’s future subordinated
 indebtedness.

[0001193125-14-184523:notes:112]
During the quarter ended March 31, 2014, the Company
 closed the sale of an additional $30,000 aggregate principal amount
 of its 1.75% convertible senior notes due 2020 (Additional Notes).
 The Additional Notes were sold pursuant to the exercise of an
 over-allotment option granted by the Company in the underwriting
 agreement related to the offer and sale of $220,000 aggregate
 principal amount of its 1.75% convertible senior notes due
 2020.

[0001193125-14-184523:notes:113]
In connection with the offering of the Additional Notes, the
 Company entered into additional convertible note hedge and warrant
 transactions (Additional Call Spread Transaction) with respect to
 shares of its common stock. The additional convertible note hedge,
 which cost an aggregate $7,953 and was recorded, net of tax, as a
 reduction of additional paid-in capital, consists of the
 Company’s option to purchase up to 3,100 common stock shares
 at a price of $9.64 per share and will expire upon the maturity of
 the notes. Additionally, the Company sold warrants to purchase
 3,100 shares of its common stock at a price of $14.26 per
 share. The warrants expire ratably from March 2021 through January
 2022. The proceeds from the sale of warrants of $4,053 was recorded
 as an increase to additional paid-in capital. The 2020 Additional
 Call Spread Transaction has no effect on the terms of the
 convertible senior notes due 2020 and reduces potential dilution by
 effectively increasing the conversion price of the convertible
 senior notes due 2020 to $14.26 per share of the Company’s
 common stock.

[0001193125-14-184523:notes:114]
The maximum number of shares issuable upon conversion,
 including the effect of a fundamental change and subject to Other
 Conversion Rate Adjustments, would be 32,425.

[0001193125-14-184523:notes:115]
Convertible Senior Notes due 2015

[0001193125-14-184523:notes:116]
In May 2008, the Company issued 3.25% convertible senior
 notes due May 15, 2015, in a public offering for an aggregate
 principal amount of $175,000. The convertible senior notes bear
 interest at a rate of 3.25% per annum. Interest is payable
 semiannually in arrears on May 15 and November 15 of each
 year. The convertible senior notes are senior unsecured obligations
 and rank equally to the Company’s future unsecured senior
 indebtedness and senior in right of payment to any of the
 Company’s future subordinated indebtedness.

[0001193125-14-184523:notes:117]
During the quarter ended March 31, 2014, the Company
 repurchased $6,514 of notes at approximately 103.4% of their
 principal amount. The repurchase of the convertible senior notes
 was accounted for as an extinguishment of debt, and accordingly,
 the Company recognized a $506 loss primarily associated with the
 premium paid to repurchase the convertible senior notes and the
 recognition of certain remaining unamortized debt discount and
 issuance costs.

[0001193125-14-184523:notes:118]
The maximum number of shares issuable upon conversion,
 including the effect of a fundamental change and subject to Other
 Conversion Rate Adjustments, would be 2,587.

[0001193125-14-184523:notes:119]
The accounting standards for convertible debt instruments that
 may be fully or partially settled in cash upon conversion require
 the debt and equity components to be separately accounted for in a
 manner that reflects our nonconvertible borrowing rate when
 interest expense is recognized in subsequent periods. The amount
 recorded as debt is based on the fair value of the debt component
 as a standalone instrument, determined using an average interest
 rate for similar nonconvertible debt issued by entities with credit
 ratings comparable to the Company’s at the time of issuance.
 The difference between the debt recorded at inception and its
 principal amount is to be accreted to principal through interest
 expense through the estimated life of the note.

[0001193125-14-184523:notes:120]
As of March 31, 2014 and December 30, 2013, remaining
 unamortized debt issuance costs included in other non-current
 assets were $6,005 and $5,399, respectively. The debt issuance
 costs and debt discount are being amortized to interest expense
 over the term of the convertible senior notes using the effective
 interest rate method. At March 31, 2014, the remaining
 weighted average amortization period for the unamortized senior
 convertible note discount and debt issuance costs was
 6.6 years.

[0001193125-14-184523:notes:121]
For the quarter ended March 31, 2014, the amortization of
 debt discount and debt issuance costs for the 2020 convertible
 senior notes and the 2015 convertible senior notes is based on an
 effective interest rate of 6.48% and 8.37%, respectively. For the
 quarter ended April 1, 2013, the amortization of debt discount
 and debt issuance costs for the 2015 convertible senior notes is
 based on an effective interest rate of 8.37%.
