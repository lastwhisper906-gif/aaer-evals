# TTMI note change history — 0001193125-13-424647 → 0001193125-14-184523


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2014-05-06):
[0001193125-14-184523:note_history:1]
The Company is subject to various legal matters, which it
 considers normal for its business activities. While the Company
 currently believes that the amount of any reasonably possible or
 probable loss for known matters would not be material to the
 Company’s financial condition, the outcome of these actions
 is inherently difficult to predict. In the event of an adverse
 outcome, the ultimate potential loss could have a material adverse
 effect on the Company’s financial condition or results of
 operations in a particular period. The Company has accrued amounts
 for its loss contingencies which are probable and estimable at
 March 31, 2014 and December 30, 2013. However, these
 amounts are not material to the consolidated condensed financial
 statements of the Company.
  (was, 2013-11-04, similarity 0.9908):
[0001193125-13-424647:note_history:1]
The
 Company is subject to various legal matters, which it considers
 normal for its business activities. While the Company currently
 believes that the amount of any reasonably possible or probable
 loss for known matters would not be material to the Company’s
 financial condition, the outcome of these actions is inherently
 difficult to predict. In the event of an adverse outcome, the
 ultimate potential loss could have a material adverse effect on the
 Company’s financial condition or results of operations in a
 particular period. The Company has accrued amounts for its loss
 contingencies which are probable and estimable at
 September 30, 2013 and December 31, 2012. However, these
 amounts are not material to the consolidated condensed financial
 statements of the Company.

- added (2014-05-06):
[0001193125-14-184523:note_history:2]
The process to manufacture PCBs requires adherence to city,
 county, state, federal and foreign environmental regulations
 regarding the storage, use, handling and disposal of chemicals,
 solid wastes and other hazardous materials as well as compliance
 with air quality standards. The Company believes that its
 facilities in the United States comply in all material respects
 with applicable environmental laws and regulations. In China,
 governmental authorities are taking various steps to tighten the
 rules and regulations governing environmental issues. An
 update to Chinese environmental law was issued in late 2012, but
 allows for an interim period in which foreign entities may adjust
 to the new regulatory regime and come into full compliance with the
 new laws. The Company’s plants in China are not yet in
 full compliance with the current environmental regulations as
 updated in late 2012. The Company does not anticipate any
 immediate risk of government fines or temporary closure of Chinese
 plants. The Company has established and enacted an investment
 plan, which includes capital expenditures estimated to be
 approximately $4,700 for 2014, to address the regulatory changes in
 order to come into full compliance during the interim
 period.

- removed (2014-05-06):
[0001193125-13-424647:note_history:3]
The
 process to manufacture PCBs requires adherence to city, county,
 state, federal and foreign environmental regulations regarding the
 storage, use, handling and disposal of chemicals, solid wastes and
 other hazardous materials as well as air quality standards.
 Management believes that its facilities comply in all material
 respects with environmental laws and regulations. The Company has
 in the past received certain notices of minor violations and has
 implemented certain required minor corrective activities. There can
 be no assurance that violations will not occur in the future. The
 Company does not expect the outcome of the environmental
 remediation matters, either individually or in the aggregate, to
 have a material adverse effect on its financial position, results
 of operations, or cash flows.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2014-05-06):
[0001193125-14-184523:note_history:4]
TTM
 Technologies, Inc. (the Company or TTM) is a leading global
 provider of time-critical and technologically complex printed
 circuit board (PCB) products and backplane assemblies (PCBs
 populated with electronic components), which serve as the
 foundation of sophisticated electronic products. The Company
 provides advanced technology products and offers a one-stop
 manufacturing solution to customers from engineering support to
 prototype development through final volume production. The Company
 serves a diversified customer base in various markets throughout
 the world, including manufacturers of networking/communications
 infrastructure products, touch screen tablets and smartphones. The
 Company also serves aerospace and defense, high-end computing, and
 industrial/medical industries. The Company’s customers
 include both original equipment manufacturers (OEMs) and electronic
 manufacturing services (EMS) providers.
  (was, 2013-11-04, similarity 0.9811):
[0001193125-13-424647:note_history:4]
TTM
 Technologies, Inc. (the Company or TTM) is a leading global
 provider of time-critical and technologically complex printed
 circuit board (PCB) products and backplane assemblies (PCBs
 populated with electronic components), which serve as the
 foundation of sophisticated electronic products. The Company
 provides advanced technology products and offers a one-stop
 manufacturing solution to customers from engineering support to
 prototype development through final volume production. The Company
 serves a diversified customer base in various markets throughout
 the world, including manufacturers of networking/communications
 infrastructure products, touch screen tablets and smartphones. The
 Company also serves commercial aerospace/defense, high-end
 computing, and industrial/medical industries. The Company’s
 customers include both original equipment manufacturers (OEMs) and
 electronic manufacturing services (EMS) providers.

- changed (2014-05-06):
[0001193125-14-184523:note_history:5]
The
 accompanying consolidated condensed financial statements have been
 prepared by the Company, without audit, pursuant to the rules and
 regulations of the Securities and Exchange Commission (SEC).
 Certain information and disclosures normally included in financial
 statements prepared in accordance with accounting principles
 generally accepted in the United States of America have been
 condensed or omitted pursuant to such rules and regulations. These
 consolidated condensed financial statements reflect all adjustments
 (consisting only of normal recurring adjustments) which, in the
 opinion of management, are necessary to present fairly the
 financial position, the results of operations and cash flows of the
 Company for the periods presented. It is suggested that these
 consolidated condensed financial statements be read in conjunction
 with the consolidated financial statements and the notes thereto
 included in the Company’s most recent Annual Report on Form
 10-K. The results of operations for the interim periods are not
 necessarily indicative of the results to be expected for the full
 year. The preparation of financial statements in accordance with
 U.S. generally accepted accounting principles requires management
 to make estimates and assumptions that affect the amounts reported
 in the Company’s consolidated condensed financial statements
 and accompanying notes. Actual results could differ materially from
 those estimates. The Company uses a 13-week fiscal quarter
 accounting period with fourth quarter ending on the Monday nearest
 December 31.
  (was, 2013-11-04, similarity 0.9122):
[0001193125-13-424647:note_history:5]
The
 accompanying consolidated condensed financial statements have been
 prepared by the Company, without audit, pursuant to the rules and
 regulations of the Securities and Exchange Commission (SEC).
 Certain information and disclosures normally included in financial
 statements prepared in accordance with accounting principles
 generally accepted in the United States of America have been
 condensed or omitted pursuant to such rules and regulations. These
 consolidated condensed financial statements reflect all adjustments
 (consisting only of normal recurring adjustments) which, in the
 opinion of management, are necessary to present fairly the
 financial position, the results of operations and cash flows of the
 Company for the periods presented. It is suggested that these
 consolidated condensed financial statements be read in conjunction
 with the consolidated financial statements and the notes thereto
 included in the Company’s most recent Annual Report on Form
 10-K. The results of operations for the interim periods are not
 necessarily indicative of the results to be expected for the full
 year. The preparation of financial statements in accordance with
 U.S. generally accepted accounting principles requires management
 to make estimates and assumptions that affect the amounts reported
 in the Company’s consolidated condensed financial statements
 and accompanying notes. Actual results could differ materially from
 those estimates. Beginning January 1, 2013, the Company uses a
 13-week fiscal quarter accounting period with the first quarter
 ending on the last Monday closest to April 1 and the fourth
 quarter always ending on December 31. The third quarters ended
 September 30, 2013 and September 24, 2012 each contained
 91 days. The three quarters ended September 30, 2013 and
 September 24, 2012 contained 273 and 268 days,
 respectively.


## ttmi:ConvertibleSeniorNotesTextBlock (debt) — matched_by: tag_name, score: 1.0

- added (2014-05-06):
[0001193125-14-184523:note_history:6]
Convertible Senior Notes due 2020

- changed (2014-05-06):
[0001193125-14-184523:note_history:7]
In December 2013, the Company issued 1.75% convertible
 senior notes due December 15, 2020, in a public offering for
 an aggregate principal amount of $220,000. The convertible senior
 notes bear interest at a rate of 1.75% per annum. Interest is
 payable semiannually in arrears on June 15 and
 December 15 of each year. The convertible senior notes are
 senior unsecured obligations and rank equally to the
 Company’s future unsecured senior indebtedness and senior in
 right of payment to any of the Company’s future subordinated
 indebtedness.
  (was, 2013-11-04, similarity 0.7728):
[0001193125-13-424647:note_history:7]
In 2008, the Company issued 3.25% Convertible Senior Notes
 (Convertible Notes) due May 15, 2015, in a public offering for
 an aggregate principal amount of $175,000. The Convertible Notes
 bear interest at a rate of 3.25% per annum. Interest is
 payable semiannually in arrears on May 15 and November 15
 of each year. The Convertible Notes are senior unsecured
 obligations and rank equally to the Company’s future
 unsecured senior indebtedness and senior in right of payment to any
 of the Company’s future subordinated indebtedness. The
 liability and equity components of the Convertible Notes are
 separately accounted for in a manner that reflects the
 Company’s non-convertible debt borrowing rate when interest
 costs are recognized.

- added (2014-05-06):
[0001193125-14-184523:note_history:8]
During the quarter ended March 31, 2014, the Company
 closed the sale of an additional $30,000 aggregate principal amount
 of its 1.75% convertible senior notes due 2020 (Additional Notes).
 The Additional Notes were sold pursuant to the exercise of an
 over-allotment option granted by the Company in the underwriting
 agreement related to the offer and sale of $220,000 aggregate
 principal amount of its 1.75% convertible senior notes due
 2020.

- added (2014-05-06):
[0001193125-14-184523:note_history:9]
In connection with the offering of the Additional Notes, the
 Company entered into additional convertible note hedge and warrant
 transactions (Additional Call Spread Transaction) with respect to
 shares of its common stock. The additional convertible note hedge,
 which cost an aggregate $7,953 and was recorded, net of tax, as a
 reduction of additional paid-in capital, consists of the
 Company’s option to purchase up to 3,100 common stock shares
 at a price of $9.64 per share and will expire upon the maturity of
 the notes. Additionally, the Company sold warrants to purchase
 3,100 shares of its common stock at a price of $14.26 per
 share. The warrants expire ratably from March 2021 through January
 2022. The proceeds from the sale of warrants of $4,053 was recorded
 as an increase to additional paid-in capital. The 2020 Additional
 Call Spread Transaction has no effect on the terms of the
 convertible senior notes due 2020 and reduces potential dilution by
 effectively increasing the conversion price of the convertible
 senior notes due 2020 to $14.26 per share of the Company’s
 common stock.

- added (2014-05-06):
[0001193125-14-184523:note_history:10]
The maximum number of shares issuable upon conversion,
 including the effect of a fundamental change and subject to Other
 Conversion Rate Adjustments, would be 32,425.

- added (2014-05-06):
[0001193125-14-184523:note_history:11]
Convertible Senior Notes due 2015

- added (2014-05-06):
[0001193125-14-184523:note_history:12]
In May 2008, the Company issued 3.25% convertible senior
 notes due May 15, 2015, in a public offering for an aggregate
 principal amount of $175,000. The convertible senior notes bear
 interest at a rate of 3.25% per annum. Interest is payable
 semiannually in arrears on May 15 and November 15 of each
 year. The convertible senior notes are senior unsecured obligations
 and rank equally to the Company’s future unsecured senior
 indebtedness and senior in right of payment to any of the
 Company’s future subordinated indebtedness.

- added (2014-05-06):
[0001193125-14-184523:note_history:13]
During the quarter ended March 31, 2014, the Company
 repurchased $6,514 of notes at approximately 103.4% of their
 principal amount. The repurchase of the convertible senior notes
 was accounted for as an extinguishment of debt, and accordingly,
 the Company recognized a $506 loss primarily associated with the
 premium paid to repurchase the convertible senior notes and the
 recognition of certain remaining unamortized debt discount and
 issuance costs.

- added (2014-05-06):
[0001193125-14-184523:note_history:14]
The maximum number of shares issuable upon conversion,
 including the effect of a fundamental change and subject to Other
 Conversion Rate Adjustments, would be 2,587.

- added (2014-05-06):
[0001193125-14-184523:note_history:15]
The accounting standards for convertible debt instruments that
 may be fully or partially settled in cash upon conversion require
 the debt and equity components to be separately accounted for in a
 manner that reflects our nonconvertible borrowing rate when
 interest expense is recognized in subsequent periods. The amount
 recorded as debt is based on the fair value of the debt component
 as a standalone instrument, determined using an average interest
 rate for similar nonconvertible debt issued by entities with credit
 ratings comparable to the Company’s at the time of issuance.
 The difference between the debt recorded at inception and its
 principal amount is to be accreted to principal through interest
 expense through the estimated life of the note.

- added (2014-05-06):
[0001193125-14-184523:note_history:16]
As of March 31, 2014 and December 30, 2013, the
 following summarizes the liability and equity components of the
 convertible senior notes:

- added (2014-05-06):
[0001193125-14-184523:note_history:17]
|  |  | As of March 31, 2014 |  |  | As of December 30, 2013 |  |
|  |  | Principal |  |  | Unamortized Discount |  |  | Net Carrying Amount |  |  | Principal |  |  | Unamortized Discount |  |  | Net Carrying Amount |  |
|  |  | (in thousands) |  |
| Liability components: |  |  |  |  |
| Convertible senior notes due 2020 |  | $ | 250,000 |  |  | $ | (58,295 | ) |  | $ | 191,705 |  |  | $ | 220,000 |  |  | $ | (52,833 | ) |  | $ | 167,167 |  |
| Convertible senior notes due 2015 |  |  | 32,395 |  |  |  | (1,612 | ) |  |  | 30,783 |  |  |  | 38,909 |  |  |  | (2,341 | ) |  |  | 36,568 |  |
| Total |  | $ | 282,395 |  |  | $ | (59,907 | ) |  | $ | 222,488 |  |  | $ | 258,909 |  |  | $ | (55,174 | ) |  | $ | 203,735 |  |

- added (2014-05-06):
[0001193125-14-184523:note_history:18]
|  |  | As of March 31, 2014 |  |  | As of December 30, 2013 |  |
|  |  | Embedded conversion option — Convertible Senior Notes |  |  | Embedded conversion option — Convertible Senior Notes Issuance Costs |  |  | Total |  |  | Embedded conversion option — Convertible Senior Notes |  |  | Embedded conversion option — Convertible Senior Notes Issuance Costs |  |  | Total |  |
|  |  | (in thousands) |  |
| Equity components: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Additional paid-in capital: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Convertible senior notes due 2020 |  | $ | 60,227 |  |  | $ | (1,916 | ) |  | $ | 58,311 |  |  | $ | 53,000 |  |  | $ | (1,644 | ) |  | $ | 51,356 |  |
| Convertible senior notes due 2015 |  |  | 39,781 |  |  | $ | (1,413 | ) |  |  | 38,368 |  |  |  | 39,928 |  |  | $ | (1,413 | ) |  |  | 38,515 |  |
|  |  | $ | 100,008 |  |  | $ | (3,329 | ) |  | $ | 96,679 |  |  | $ | 92,928 |  |  | $ | (3,057 | ) |  | $ | 89,871 |  |

- changed (2014-05-06):
[0001193125-14-184523:note_history:19]
The components of interest expense resulting from the
 convertible senior notes for the quarters ended March 31, 2014
 and April 1, 2013 are as follows:
  (was, 2013-11-04, similarity 0.8505):
[0001193125-13-424647:note_history:19]
The components of interest expense resulting from the
 Convertible Notes for the quarter and three quarters ended
 September 30, 2013 and September 24, 2012 are as
 follows:

- added (2014-05-06):
[0001193125-14-184523:note_history:20]
|  |  | For the Quarter Ended |  |
|  |  | March 31, 2014 |  |  | April 1, 2013 |  |
|  |  | (In thousands) |  |
| Contractual coupon interest |  |  |  |  |  |  |  |  |
| Convertible senior notes due 2020 |  | $ | 1,085 |  |  | $ | — |  |
| Convertible senior notes due 2015 |  |  | 263 |  |  |  | 1,422 |  |
|  |  | $ | 1,348 |  |  | $ | 1,422 |  |
| Amortization of debt discount |  |  |  |  |  |  |  |  |
| Convertible senior notes due 2020 |  | $ | 1,764 |  |  | $ | — |  |
| Convertible senior notes due 2015 |  |  | 338 |  |  |  | 1,680 |  |
|  |  | $ | 2,102 |  |  | $ | 1,680 |  |
| Amortization of debt issuance costs |  |  |  |  |  |  |  |  |
| Convertible senior notes due 2020 |  | $ | 177 |  |  | $ | — |  |
| Convertible senior notes due 2015 |  |  | 34 |  |  |  | 169 |  |
|  |  | $ | 211 |  |  | $ | 169 |  |

- changed (2014-05-06):
[0001193125-14-184523:note_history:21]
As of March 31, 2014 and December 30, 2013, remaining
 unamortized debt issuance costs included in other non-current
 assets were $6,005 and $5,399, respectively. The debt issuance
 costs and debt discount are being amortized to interest expense
 over the term of the convertible senior notes using the effective
 interest rate method. At March 31, 2014, the remaining
 weighted average amortization period for the unamortized senior
 convertible note discount and debt issuance costs was
 6.6 years.
  (was, 2013-11-04, similarity 0.7273):
[0001193125-13-424647:note_history:21]
At September 30, 2013 and December 31, 2012,
 remaining unamortized debt issuance costs included in other
 non-current assets were $1,243 and $1,762, respectively. The debt
 issuance costs and debt discount are being amortized to interest
 expense over the term of the Convertible Notes using the effective
 interest rate method. At September 30, 2013, the remaining
 amortization period for the unamortized Convertible Note discount
 and debt issuance costs was 1.6 years.

- added (2014-05-06):
[0001193125-14-184523:note_history:22]
For the quarter ended March 31, 2014, the amortization of
 debt discount and debt issuance costs for the 2020 convertible
 senior notes and the 2015 convertible senior notes is based on an
 effective interest rate of 6.48% and 8.37%, respectively. For the
 quarter ended April 1, 2013, the amortization of debt discount
 and debt issuance costs for the 2015 convertible senior notes is
 based on an effective interest rate of 8.37%.

- removed (2014-05-06):
[0001193125-13-424647:note_history:23]
The Company has allocated the Convertible Notes offering costs
 to the liability and equity components in proportion to the
 allocation of proceeds and accounted for them as debt issuance
 costs and equity issuance costs, respectively. At
 September 30, 2013 and December 31, 2012, the following
 summarizes the liability and equity components of the Convertible
 Notes:

- removed (2014-05-06):
[0001193125-13-424647:note_history:24]
|  |  | September 30, 2013 |  |  | December 31, 2012 |  |
|  |  | (In thousands) |  |
| Liability components: |  |  |  |  |  |  |  |  |
| Convertible Notes |  | $ | 175,000 |  |  | $ | 175,000 |  |
| Less: Convertible Notes unamortized discount |  |  | (12,320 | ) |  |  | (17,467 | ) |
| Convertible Notes, net of discount |  | $ | 162,680 |  |  | $ | 157,533 |  |
| Equity components: |  |  |  |  |  |  |  |  |
| Additional paid-in capital: |  |  |  |  |  |  |  |  |
| Embedded conversion option — Convertible Notes |  | $ | 43,000 |  |  | $ | 43,000 |  |
| Embedded conversion option — Convertible Notes issuance costs |  |  | (1,413 | ) |  |  | (1,413 | ) |
|  |  | $ | 41,587 |  |  | $ | 41,587 |  |

- removed (2014-05-06):
[0001193125-13-424647:note_history:25]
|  |  | Quarter Ended |  |  | Three Quarters Ended |  |
|  |  | September 30, 2013 |  |  | September 24, 2012 |  |  | September 30, 2013 |  |  | September 24, 2012 |  |
|  |  | (In thousands) |  |
| Contractual coupon interest |  | $ | 1,422 |  |  | $ | 1,422 |  |  | $ | 4,266 |  |  | $ | 4,266 |  |
| Amortization of Convertible Notes debt discount |  |  | 1,751 |  |  |  | 1,611 |  |  |  | 5,147 |  |  |  | 4,735 |  |
| Amortization of debt issuance costs |  |  | 177 |  |  |  | 163 |  |  |  | 519 |  |  |  | 477 |  |
|  |  | $ | 3,350 |  |  | $ | 3,196 |  |  | $ | 9,932 |  |  | $ | 9,478 |  |

- removed (2014-05-06):
[0001193125-13-424647:note_history:26]
For the quarter and three quarters ended September 30,
 2013 and September 24, 2012, the amortization of the
 Convertible Notes debt discount and debt issuance costs is based on
 an effective interest rate of 8.37%.


## ttmi:ScheduleOfComponentsOfInterestExpenseFromConvertibleNotesTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2014-05-06):
[0001193125-14-184523:note_history:27]
The components of interest expense resulting from the
 convertible senior notes for the quarters ended March 31, 2014
 and April 1, 2013 are as follows:
  (was, 2013-11-04, similarity 0.8505):
[0001193125-13-424647:note_history:27]
The components of interest expense resulting from the
 Convertible Notes for the quarter and three quarters ended
 September 30, 2013 and September 24, 2012 are as
 follows:

- added (2014-05-06):
[0001193125-14-184523:note_history:28]
|  |  | For the Quarter Ended |  |
|  |  | March 31, 2014 |  |  | April 1, 2013 |  |
|  |  | (In thousands) |  |
| Contractual coupon interest |  |  |  |  |  |  |  |  |
| Convertible senior notes due 2020 |  | $ | 1,085 |  |  | $ | — |  |
| Convertible senior notes due 2015 |  |  | 263 |  |  |  | 1,422 |  |
|  |  | $ | 1,348 |  |  | $ | 1,422 |  |
| Amortization of debt discount |  |  |  |  |  |  |  |  |
| Convertible senior notes due 2020 |  | $ | 1,764 |  |  | $ | — |  |
| Convertible senior notes due 2015 |  |  | 338 |  |  |  | 1,680 |  |
|  |  | $ | 2,102 |  |  | $ | 1,680 |  |
| Amortization of debt issuance costs |  |  |  |  |  |  |  |  |
| Convertible senior notes due 2020 |  | $ | 177 |  |  | $ | — |  |
| Convertible senior notes due 2015 |  |  | 34 |  |  |  | 169 |  |
|  |  | $ | 211 |  |  | $ | 169 |  |

- removed (2014-05-06):
[0001193125-13-424647:note_history:29]
|  |  | Quarter Ended |  |  | Three Quarters Ended |  |
|  |  | September 30, 2013 |  |  | September 24, 2012 |  |  | September 30, 2013 |  |  | September 24, 2012 |  |
|  |  | (In thousands) |  |
| Contractual coupon interest |  | $ | 1,422 |  |  | $ | 1,422 |  |  | $ | 4,266 |  |  | $ | 4,266 |  |
| Amortization of Convertible Notes debt discount |  |  | 1,751 |  |  |  | 1,611 |  |  |  | 5,147 |  |  |  | 4,735 |  |
| Amortization of debt issuance costs |  |  | 177 |  |  |  | 163 |  |  |  | 519 |  |  |  | 477 |  |
|  |  | $ | 3,350 |  |  | $ | 3,196 |  |  | $ | 9,932 |  |  | $ | 9,478 |  |


## ttmi:ScheduleOfLiabilityAndEquityComponentsOfConvertibleNotesTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2014-05-06):
[0001193125-14-184523:note_history:30]
As of March 31, 2014 and December 30, 2013, the
 following summarizes the liability and equity components of the
 convertible senior notes:
  (was, 2013-11-04, similarity 0.9106):
[0001193125-13-424647:note_history:30]
At September 30, 2013 and December 31, 2012, the
 following summarizes the liability and equity components of the
 Convertible Notes:

- added (2014-05-06):
[0001193125-14-184523:note_history:31]
|  |  | As of March 31, 2014 |  |  | As of December 30, 2013 |  |
|  |  | Principal |  |  | Unamortized Discount |  |  | Net Carrying Amount |  |  | Principal |  |  | Unamortized Discount |  |  | Net Carrying Amount |  |
|  |  | (in thousands) |  |
| Liability components: |  |  |  |  |
| Convertible senior notes due 2020 |  | $ | 250,000 |  |  | $ | (58,295 | ) |  | $ | 191,705 |  |  | $ | 220,000 |  |  | $ | (52,833 | ) |  | $ | 167,167 |  |
| Convertible senior notes due 2015 |  |  | 32,395 |  |  |  | (1,612 | ) |  |  | 30,783 |  |  |  | 38,909 |  |  |  | (2,341 | ) |  |  | 36,568 |  |
| Total |  | $ | 282,395 |  |  | $ | (59,907 | ) |  | $ | 222,488 |  |  | $ | 258,909 |  |  | $ | (55,174 | ) |  | $ | 203,735 |  |

- added (2014-05-06):
[0001193125-14-184523:note_history:32]
|  |  | As of March 31, 2014 |  |  | As of December 30, 2013 |  |
|  |  | Embedded conversion option — Convertible Senior Notes |  |  | Embedded conversion option — Convertible Senior Notes Issuance Costs |  |  | Total |  |  | Embedded conversion option — Convertible Senior Notes |  |  | Embedded conversion option — Convertible Senior Notes Issuance Costs |  |  | Total |  |
|  |  | (in thousands) |  |
| Equity components: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Additional paid-in capital: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Convertible senior notes due 2020 |  | $ | 60,227 |  |  | $ | (1,916 | ) |  | $ | 58,311 |  |  | $ | 53,000 |  |  | $ | (1,644 | ) |  | $ | 51,356 |  |
| Convertible senior notes due 2015 |  |  | 39,781 |  |  | $ | (1,413 | ) |  |  | 38,368 |  |  |  | 39,928 |  |  | $ | (1,413 | ) |  |  | 38,515 |  |
|  |  | $ | 100,008 |  |  | $ | (3,329 | ) |  | $ | 96,679 |  |  | $ | 92,928 |  |  | $ | (3,057 | ) |  | $ | 89,871 |  |

- removed (2014-05-06):
[0001193125-13-424647:note_history:33]
|  |  | September 30, 2013 |  |  | December 31, 2012 |  |
|  |  | (In thousands) |  |
| Liability components: |  |  |  |  |  |  |  |  |
| Convertible Notes |  | $ | 175,000 |  |  | $ | 175,000 |  |
| Less: Convertible Notes unamortized discount |  |  | (12,320 | ) |  |  | (17,467 | ) |
| Convertible Notes, net of discount |  | $ | 162,680 |  |  | $ | 157,533 |  |
| Equity components: |  |  |  |  |  |  |  |  |
| Additional paid-in capital: |  |  |  |  |  |  |  |  |
| Embedded conversion option — Convertible Notes |  | $ | 43,000 |  |  | $ | 43,000 |  |
| Embedded conversion option — Convertible Notes issuance costs |  |  | (1,413 | ) |  |  | (1,413 | ) |
|  |  | $ | 41,587 |  |  | $ | 41,587 |  |


## us-gaap:LongTermDebtTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2014-05-06):
[0001193125-14-184523:note_history:34]
The following table summarizes the long-term debt of the
 Company as of March 31, 2014 and December 30,
 2013:
  (was, 2013-11-04, similarity 0.9447):
[0001193125-13-424647:note_history:34]
The following table summarizes the long-term debt of the
 Company as of September 30, 2013 and December 31, 2012.

- changed (2014-05-06):
[0001193125-14-184523:note_history:35]
|  |  | Average Effective Interest Rate as of March 31, 2014 |  | March 31, 2014 |  |  | Average Effective Interest Rate as of December 30, 2013 |  | December 30, 2013 |  |
|  |  | (In thousands) |  |
| Term loan due September 2016 |  | 2.53% |  | $ | 321,900 |  |  | 2.55% |  | $ | 370,000 |  |
| Other |  | 6.00% |  |  | 7 |  |  | 6.00% |  |  | 8 |  |
|  |  |  |  |  | 321,907 |  |  |  |  |  | 370,008 |  |
| Less: current maturities |  |  |  |  | (96,205 | ) |  |  |  |  | (96,204 | ) |
| Long-term debt, less current maturities |  |  |  | $ | 225,702 |  |  |  |  | $ | 273,804 |  |
  (was, 2013-11-04, similarity 0.862):
[0001193125-13-424647:note_history:35]
|  |  | Average Effective Interest Rate as of September 30, 2013 |  | September 30, 2013 |  |  | Average Effective Interest Rate as of December 31, 2012 |  | December 31, 2012 |  |
|  |  |  |  | (In thousands) |  |  |  |  | (In thousands) |  |
| Term loan due September 2016 |  | 2.56% |  | $ | 370,000 |  |  | 2.59% |  | $ | 370,000 |  |
| Revolving loan due March 2016 |  | — |  |  | — |  |  | 2.59% |  |  | 30,000 |  |
| Other |  | 6.00% |  |  | 9 |  |  | 6.00% |  |  | 12 |  |
|  |  |  |  |  | 370,009 |  |  |  |  |  | 400,012 |  |
| Less: Current maturities |  |  |  |  | (96,204 | ) |  |  |  |  | (30,004 | ) |
| Long-term debt, less current maturities |  |  |  | $ | 273,805 |  |  |  |  | $ | 370,008 |  |

- changed (2014-05-06):
[0001193125-14-184523:note_history:36]
The calendar maturities of long-term debt through 2016 are as
 follows:
  (was, 2013-11-04, similarity 0.8993):
[0001193125-13-424647:note_history:36]
The calendar maturities of long-term debt through 2016 and
 thereafter are as follows:

- changed (2014-05-06):
[0001193125-14-184523:note_history:37]
|  |  | (In thousands) |  |
| Remaining 2014 |  | $ | 48,103 |  |
| 2015 |  |  | 96,204 |  |
| 2016 |  |  | 177,600 |  |
|  |  | $ | 321,907 |  |
  (was, 2013-11-04, similarity 0.9474):
[0001193125-13-424647:note_history:37]
|  |  | (In thousands) |  |
| 2014 |  | $ | 96,204 |  |
| 2015 |  |  | 96,205 |  |
| 2016 |  |  | 177,600 |  |
|  |  | $ | 370,009 |  |

- added (2014-05-06):
[0001193125-14-184523:note_history:38]
In 2012, the Company became a party to a facility agreement
 (Credit Agreement) consisting of a $370,000 senior secured term
 loan (Term Loan), a $90,000 senior secured revolving loan
 (Revolving Loan), and a secured $80,000 letters of credit facility
 (Letters of Credit Facility). The Term Loan and Letters of Credit
 Facility will mature on September 14, 2016. The Revolving Loan
 will mature on March 14, 2016. The Credit Agreement is secured
 by substantially all of the assets of the Company’s Asia
 Pacific operating segment and is senior to all other debt,
 including the convertible senior notes. See Note 5. The Company has
 fully and unconditionally guaranteed the full and punctual payment
 of all Credit Agreement related obligations of its Asia Pacific
 operating segment.

- changed (2014-05-06):
[0001193125-14-184523:note_history:39]
As of March 31, 2014 and December 30, 2013, the
 remaining unamortized debt issuance costs included in other
 non-current assets was $1,728 and $1,937 and is amortized to
 interest expense over the term of the Company’s Credit
 Agreement using the effective interest rate method. At
 March 31, 2014, the remaining amortization period for the
 unamortized debt issuance costs was 2.2 years.
  (was, 2013-11-04, similarity 0.8766):
[0001193125-13-424647:note_history:39]
At September 30, 2013 and December 31, 2012, the remaining
 unamortized debt issuance costs included in other non-current
 assets was $2,139 and $2,755, respectively, and is amortized to
 interest expense over the term of the Company’s credit
 agreement entered into in September 2012 (Credit Agreement) using
 the effective interest rate method. At September 30, 2013, the
 remaining amortization period for the unamortized debt issuance
 costs was 2.7 years.

- changed (2014-05-06):
[0001193125-14-184523:note_history:40]
The Company is also required to pay a commitment fee of
 0.50% per annum on any unused portion of the loan and letters
 of credit facility granted under the Credit Agreement. The Company
 incurred commitment fees related to unused borrowing availability
 of $133 and $96 for the quarters ended March 31, 2014 and
 April 1, 2013, respectively. As of March 31, 2014, the
 outstanding amount of the Term Loan under the Credit Agreement is
 $321,900, of which $96,200 is due for repayment in September 2014
 and March 2015 and is included as short-term debt, with the
 remaining $225,700 included as long-term debt. None of the Revolver
 was outstanding under the Credit Agreement as of March 31,
 2014. Available borrowing capacity under the Revolving Loan was
 $90,000 at March 31, 2014.
  (was, 2013-11-04, similarity 0.8275):
[0001193125-13-424647:note_history:40]
The Company is also required to pay a commitment fee of 0.50%
 per annum on any unused portion of the loan and letters of credit
 facility granted under the Credit Agreement. The Company incurred
 commitment fees related to unused borrowing availability under the
 Revolver facility of $129 and $96 for the quarter ended September
 30, 2013 and September 24, 2012, respectively, and $320 and $194
 for the three quarters ended September 30, 2013 and September 24,
 2012, respectively. As of September 30, 2013, the outstanding
 amount of the Term Loan under the Credit Agreement is $370,000, of
 which $96,200 is due for repayment in March and September 2014 and
 is included as short-term debt, with the remaining $273,800
 included as long-term debt. None of the Revolver was outstanding
 under the Credit Agreement as of September 30, 2013. Available
 borrowing capacity under the Revolving Loan was $90,000 at
 September 30, 2013.

- changed (2014-05-06):
[0001193125-14-184523:note_history:41]
Additionally, the Company is party to a revolving loan credit
 facility with a lender in the People’s Republic of China
 (PRC). Under this arrangement, the lender has made available to the
 Company approximately $46,700 in unsecured borrowing with all terms
 of the borrowing to be negotiated at the time the revolver is drawn
 upon. There are no commitment fees on the unused portion of the
 revolver and this arrangement expires in December 2014. As of
 March 31, 2014, the revolver had not been drawn
 upon.
  (was, 2013-11-04, similarity 0.9857):
[0001193125-13-424647:note_history:41]
Additionally, the Company is party to a revolving loan credit
 facility with a lender in the People’s Republic of China
 (PRC). Under this arrangement, the lender has made available to the
 Company approximately $47,400 in unsecured borrowing with all terms
 of the borrowing to be negotiated at the time the revolver is drawn
 upon. There are no commitment fees on the unused portion of the
 revolver and this arrangement expires in December 2013. As of
 September 30, 2013, the revolver had not been drawn
 upon.

- added (2014-05-06):
[0001193125-14-184523:note_history:42]
The Company has an $80,000 Letters of Credit Facility under the
 Credit Agreement, as mentioned above. As of March 31, 2014,
 letters of credit in the amount of $56,986 were outstanding under
 this Credit Agreement. The Company has other standby letters of
 credit outstanding in the amount of $3,394 million, as well other
 unused letter of credit facilities in the amount of $31,100. The
 outstanding standby letters of credit and unused letter of credit
 facilities expire between December 31, 2014 and
 February 28, 2015.

- removed (2014-05-06):
[0001193125-13-424647:note_history:43]
As of September 30, 2013, $69,824 of the Letters of Credit
 Facility was outstanding under the Credit Agreement. Additionally,
 the Company maintains other unused letters of credit for an
 aggregate amount of $3,454, which expire between December 31, 2013
 and February 28, 2014.

- removed (2014-05-06):
[0001193125-13-424647:note_history:44]
Loss on
 Extinguishment of Debt

- removed (2014-05-06):
[0001193125-13-424647:note_history:45]
As of September 24, 2012, the November 16, 2009 credit
 agreement had been terminated and all outstanding loans borrowed
 under this agreement were paid in full. Additionally during the
 third quarter ended September 24, 2012, the Company recognized
 $5,527 as a loss on the extinguishment of debt resulting from
 certain remaining unamortized debt issuance costs associated with
 the terminated November 16, 2009 credit agreement and certain
 additional lender fees paid in connection with the New Credit
 Agreement.


## us-gaap:ScheduleOfDebtInstrumentsTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2014-05-06):
[0001193125-14-184523:note_history:46]
The following table summarizes the long-term debt of the
 Company as of March 31, 2014 and December 30,
 2013:
  (was, 2013-11-04, similarity 0.9447):
[0001193125-13-424647:note_history:46]
The following table summarizes the long-term debt of the
 Company as of September 30, 2013 and December 31,
 2012.

- changed (2014-05-06):
[0001193125-14-184523:note_history:47]
|  |  | Average Effective Interest Rate as of March 31, 2014 |  | March 31, 2014 |  |  | Average Effective Interest Rate as of December 30, 2013 |  | December 30, 2013 |  |
|  |  | (In thousands) |  |
| Term loan due September 2016 |  | 2.53% |  | $ | 321,900 |  |  | 2.55% |  | $ | 370,000 |  |
| Other |  | 6.00% |  |  | 7 |  |  | 6.00% |  |  | 8 |  |
|  |  |  |  |  | 321,907 |  |  |  |  |  | 370,008 |  |
| Less: current maturities |  |  |  |  | (96,205 | ) |  |  |  |  | (96,204 | ) |
| Long-term debt, less current maturities |  |  |  | $ | 225,702 |  |  |  |  | $ | 273,804 |  |
  (was, 2013-11-04, similarity 0.862):
[0001193125-13-424647:note_history:47]
|  |  | Average Effective Interest Rate as of September 30, 2013 |  | September 30, 2013 |  |  | Average Effective Interest Rate as of December 31, 2012 |  | December 31, 2012 |  |
|  |  |  |  | (In thousands) |  |  |  |  | (In thousands) |  |
| Term loan due September 2016 |  | 2.56% |  | $ | 370,000 |  |  | 2.59% |  | $ | 370,000 |  |
| Revolving loan due March 2016 |  | — |  |  | — |  |  | 2.59% |  |  | 30,000 |  |
| Other |  | 6.00% |  |  | 9 |  |  | 6.00% |  |  | 12 |  |
|  |  |  |  |  | 370,009 |  |  |  |  |  | 400,012 |  |
| Less: Current maturities |  |  |  |  | (96,204 | ) |  |  |  |  | (30,004 | ) |
| Long-term debt, less current maturities |  |  |  | $ | 273,805 |  |  |  |  | $ | 370,008 |  |


## us-gaap:ScheduleOfMaturitiesOfLongTermDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2014-05-06):
[0001193125-14-184523:note_history:48]
The calendar maturities of long-term debt through 2016 are as
 follows:
  (was, 2013-11-04, similarity 0.8993):
[0001193125-13-424647:note_history:48]
The calendar maturities of long-term debt through 2016 and
 thereafter are as follows:

- changed (2014-05-06):
[0001193125-14-184523:note_history:49]
|  |  | (In thousands) |  |
| Remaining 2014 |  | $ | 48,103 |  |
| 2015 |  |  | 96,204 |  |
| 2016 |  |  | 177,600 |  |
|  |  | $ | 321,907 |  |
  (was, 2013-11-04, similarity 0.9474):
[0001193125-13-424647:note_history:49]
|  |  | (In thousands) |  |
| 2014 |  | $ | 96,204 |  |
| 2015 |  |  | 96,205 |  |
| 2016 |  |  | 177,600 |  |
|  |  | $ | 370,009 |  |


## us-gaap:RelatedPartyTransactionsDisclosureTextBlock (related_parties) — matched_by: tag_name, score: 1.0

- changed (2014-05-06):
[0001193125-14-184523:note_history:50]
In the normal course of business, the Company’s foreign
 subsidiaries purchase laminate and prepreg from related parties in
 which a significant shareholder of the Company holds an equity
 interest. For the quarters ended March 31, 2014 and
 April 1, 2013, the Company’s foreign subsidiaries
 purchased $11,790 and $19,137 respectively, of laminate and prepreg
 from these related parties.
  (was, 2013-11-04, similarity 0.601):
[0001193125-13-424647:note_history:50]
In the
 normal course of business, the Company’s foreign subsidiaries
 purchase laminate and prepreg from related parties in which a
 significant shareholder of the Company holds an equity interest.
 The Company purchased laminate and prepeg from these related
 parties in the amount of $13,740 and $24,385 for the quarters ended
 September 30, 2013 and September 24, 2012, respectively,
 and $51,349 and $67,906 for the three quarters ended
 September 30, 2013 and September 24, 2012,
 respectively.

- added (2014-05-06):
[0001193125-14-184523:note_history:51]
Dongguan Shengyi Electronics Ltd., (SYE) is a related party as
 a significant shareholder of the Company holds an equity interest
 in the parent company of SYE. Subsequent to the Company’s
 sale of its controlling interest in SYE in June 2013, the Company
 began selling PCBs to, and purchasing PCBs from, SYE. Sales to and
 purchases from SYE, for the quarter ended March 31, 2014 were
 approximately $10,147 and $271, respectively. There were no sales
 to or purchases from SYE for the quarter ended April 1,
 2013.

- added (2014-05-06):
[0001193125-14-184523:note_history:52]
As of March 31, 2014 and December 30, 2013, the
 Company’s consolidated condensed balance sheet included
 $19,882 and $19,547, respectively, in accounts payable due to, and
 $16,975 and $13,312, respectively, in accounts receivable due from
 a related party for the purchase of laminate and prepreg, and sales
 of PCBs to SYE, as mentioned above.

- removed (2014-05-06):
[0001193125-13-424647:note_history:53]
As
 mentioned in Note 4, the Company completed its sale of SYE during
 the second quarter of 2013. The Company continues to sell PCBs to
 SYE. Sales to SYE for the quarter and three quarters ended
 September 30, 2013 were approximately $14,351 and $18,361,
 respectively. SYE will continue to be a related party as a
 significant shareholder of the Company holds an equity interest in
 the parent company of SYE.

- removed (2014-05-06):
[0001193125-13-424647:note_history:54]
At
 September 30, 2013 and December 31, 2012, the
 Company’s consolidated condensed balance sheet included
 $28,125 and $34,520, respectively, in accounts payable due to, and
 $17,601 and $48, respectively, in accounts receivable due from,
 related parties for the purchase of laminate and prepreg, sales of
 PCBs to SYE, and lease arrangements, as mentioned above.
