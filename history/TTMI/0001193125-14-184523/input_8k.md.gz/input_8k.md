# TTMI 8-K — 0001171843-14-002017 filed 2014-04-30

## item codes, every 8-K on or before 2014-05-06

- 2014-04-30 0001171843-14-002017 — 2.02, 9.01
- 2014-04-25 0001193125-14-160146 — 5.02, 5.07, 9.01
- 2014-04-10 0001171843-14-001656 — 2.02, 9.01
- 2014-03-04 0001193125-14-082534 — 4.01, 9.01
- 2014-02-05 0001171843-14-000553 — 2.02, 9.01
- 2014-01-14 0001193125-14-010922 — 1.01, 2.03, 3.02, 8.01, 9.01
- 2013-12-27 0001193125-13-486144 — 5.02, 9.01
- 2013-12-20 0001193125-13-481141 — 1.01, 1.02, 2.03, 3.02, 8.01, 9.01
- 2013-12-17 0001193125-13-476207 — 5.03
- 2013-10-30 0001193125-13-418572 — 2.02, 5.02, 9.01
- 2013-09-12 0001193125-13-365420 — 2.05
- 2013-08-14 0001193125-13-334349 — 7.01, 9.01
- 2013-08-01 0001171843-13-003138 — 2.02, 9.01
- 2013-06-25 0001193125-13-270725 — 5.02, 9.01
- 2013-05-02 0001171843-13-001746 — 2.02, 9.01
- 2013-04-29 0001193125-13-182083 — 5.02, 5.07, 9.01
- 2013-03-18 0001193125-13-111308 — 1.01, 7.01, 9.01
- 2013-03-06 0001193125-13-093625 — 5.02, 9.01
- 2013-03-01 0001193125-13-087439 — 2.02 — amendment of 0001171843-13-000414
- 2013-02-28 0001193125-13-084764 — 5.02
- 2013-02-05 0001171843-13-000414 — 2.02, 9.01
- 2013-01-31 0001193125-13-032848 — 5.02, 9.01
- 2013-01-17 0001193125-13-015928 — 7.01, 9.01
- 2013-01-16 0001193125-13-014581 — 2.02, 9.01
- 2012-12-11 0001193125-12-498644 — 5.02, 9.01
- 2012-11-15 0001193125-12-472451 — 7.01, 9.01
- 2012-11-01 0001171843-12-003890 — 2.02, 9.01
- 2012-09-19 0001193125-12-396969 — 1.01, 2.03, 7.01, 9.01
- 2012-09-11 0001193125-12-388130 — 7.01, 9.01
- 2012-07-31 0001171843-12-002829 — 2.02, 9.01
- 2012-05-15 0001193125-12-233501 — 7.01, 9.01
- 2012-05-01 0001171843-12-001574 — 2.02, 9.01
- 2012-04-27 0001193125-12-191623 — 5.07
- 2012-03-01 0001193125-12-090623 — 2.02 — amendment of 0001171843-12-000382
- 2012-02-07 0001171843-12-000382 — 2.02, 9.01
- 2012-01-19 0001193125-12-016588 — 5.02, 9.01
- 2011-11-15 0000950123-11-098812 — 7.01, 9.01
- 2011-11-02 0001171843-11-003248 — 2.02, 9.01
- 2011-09-28 0000950123-11-087344 — 7.01, 9.01
- 2011-09-19 0000950123-11-085128 — 5.02, 9.01
- 2011-09-15 0000950123-11-084704 — 5.07 — amendment of 0000950123-11-054296
- 2011-08-04 0001171843-11-002356 — 2.02, 9.01
- 2011-07-27 0000950123-11-068987 — 1.01, 2.03, 9.01
- 2011-06-21 0000950123-11-060477 — 7.01, 9.01
- 2011-06-06 0000950123-11-056971 — 5.03, 9.01
- 2011-05-26 0000950123-11-054296 — 5.07
- 2011-05-10 0000950123-11-048462 — 8.01, 9.01
- 2011-05-05 0001171843-11-001344 — 2.02, 9.01
- 2011-03-22 0000950123-11-027824 — 7.01, 9.01
- 2011-03-18 0000950123-11-026913 — 4.01
- 2011-03-18 0000950123-11-026910 — 4.01, 9.01 — amendment, the index does not say of what
- 2011-03-02 0000950123-11-020941 — 5.03, 9.01
- 2011-02-10 0001171843-11-000391 — 2.02, 9.01
- 2011-01-13 0000950123-11-002528 — 7.01, 9.01
- 2011-01-13 0000950123-11-002446 — 2.02, 9.01
- 2010-11-29 0000950123-10-109448 — 4.01, 9.01 — amendment, the index does not say of what
- 2010-11-17 0000950123-10-106706 — 4.01
- 2010-11-15 0000950123-10-105479 — 5.02, 9.01
- 2010-11-04 0001171843-10-002324 — 2.02, 9.01
- 2010-10-22 0000950123-10-095179 — 1.01, 9.01
- 2010-10-04 0000950123-10-090949 — 1.01, 5.03, 9.01
- 2010-08-05 0001171843-10-001587 — 2.02, 9.01
- 2010-08-05 0000950123-10-073258 — 1.01, 2.03, 9.01
- 2010-08-05 0000950123-10-073256 — 9.01 — amendment of 0000950123-10-034163
- 2010-07-12 0000950123-10-064794 — 5.02, 8.01, 9.01
- 2010-06-10 0000950123-10-057166 — 7.01, 9.01
- 2010-06-02 0000950123-10-055111 — 1.01, 5.07, 9.01
- 2010-05-06 0001171843-10-000819 — 2.02, 9.01
- 2010-04-26 0000950123-10-037806 — 8.01, 9.01 — amendment of 0000950123-10-034163
- 2010-04-13 0000950123-10-034163 — 1.01, 2.01, 2.03, 5.02, 7.01, 9.01
- 2010-03-30 0000950123-10-030123 — 1.01, 5.02, 9.01
- 2010-03-24 0000950123-10-027317 — 1.01, 5.02, 9.01
- 2010-03-16 0000950123-10-024853 — 7.01, 9.01 — amendment of 0001171843-10-000140
- 2010-03-15 0000950123-10-024637 — 5.07
- 2010-02-04 0001171843-10-000140 — 2.02, 9.01
- 2010-02-02 0000950123-10-007780 — 8.01, 9.01
- 2010-01-13 0000950123-10-002245 — 7.01, 9.01
- 2009-12-23 0000950123-09-073069 — 1.01, 9.01
- 2009-12-15 0000950123-09-070868 — 8.01, 9.01
- 2009-11-16 0000950123-09-062630 — 1.01, 7.01, 9.01
- 2009-11-04 0001171843-09-001103 — 2.02, 9.01
- 2009-09-04 0000950123-09-041133 — 2.05, 9.01
- 2009-07-29 0001171843-09-000743 — 2.02, 9.01
- 2009-06-09 0000950123-09-012507 — 7.01, 9.01
- 2009-04-30 0001171843-09-000427 — 2.02, 9.01
- 2009-04-28 0001362310-09-005960 — 8.01
- 2009-02-19 0001362310-09-002454 — 5.03, 9.01
- 2009-02-10 0001171843-09-000123 — 2.02, 9.01
- 2009-01-16 0000950153-09-000040 — 2.05, 9.01
- 2009-01-08 0000950153-09-000023 — 7.01, 9.01
- 2008-10-29 0001157523-08-008533 — 2.02, 9.01
- 2008-07-29 0001157523-08-005998 — 2.02, 9.01
- 2008-05-22 0000950153-08-001035 — 1.01, 2.03, 3.02, 9.01
- 2008-05-22 0000950153-08-001034 — 7.01, 9.01
- 2008-05-15 0000950153-08-000987 — 1.01, 1.02, 2.03, 3.02, 9.01
- 2008-04-30 0001157523-08-003483 — 2.02, 9.01
- 2008-02-07 0001157523-08-001077 — 2.02, 9.01
- 2008-01-08 0000950153-08-000033 — 7.01, 9.01
- 2007-11-15 0000950153-07-002440 — 7.01, 9.01
- 2007-11-14 0000950153-07-002426 — 7.01, 9.01
- 2007-11-14 0000950153-07-002421 — 5.03, 9.01
- 2007-10-31 0001157523-07-010491 — 2.02, 9.01
- 2007-10-02 0000950153-07-002094 — 7.01, 9.01
- 2007-07-31 0000950153-07-001622 — 2.02, 9.01
- 2007-06-13 0000950153-07-001327 — 7.01, 9.01
- 2007-05-02 0000950153-07-000941 — 2.02, 9.01
- 2007-04-12 0000950153-07-000763 — 5.02, 9.01
- 2007-02-15 0000950153-07-000339 — 2.02, 9.01
- 2007-01-11 0000950153-07-000076 — 7.01, 9.01
- 2007-01-10 0000950153-07-000071 — 2.01, 9.01 — amendment, the index does not say of what
- 2006-12-11 0000950153-06-002967 — 2.05, 9.01
- 2006-11-15 0000950153-06-002843 — 7.01, 9.01
- 2006-11-14 0000950153-06-002837 — 7.01, 9.01
- 2006-11-02 0000950153-06-002682 — 1.01, 1.02, 2.03, 9.01
- 2006-11-01 0000950153-06-002668 — 2.02, 9.01
- 2006-10-30 0000950124-06-006210 — 2.01, 9.01
- 2006-08-04 0000950153-06-002025 — 1.01, 9.01
- 2006-07-26 0000950153-06-001937 — 2.02, 9.01
- 2006-06-28 0000950153-06-001716 — 1.01, 9.01
- 2006-06-13 0000950153-06-001597 — 7.01, 9.01
- 2006-04-26 0000950153-06-001079 — 2.02, 9.01
- 2006-02-08 0001104659-06-006985 — 2.02, 9.01
- 2006-01-12 0001104659-06-001893 — 7.01, 9.01
- 2005-12-05 0001104659-05-058918 — 1.01, 5.02, 9.01
- 2005-10-26 0001104659-05-050306 — 2.02, 9.01
- 2005-09-20 0001104659-05-044954 — 8.01
- 2005-08-30 0001104659-05-042053 — 3.03, 8.01, 9.01
- 2005-07-27 0001104659-05-034437 — 2.02, 5.02, 9.01
- 2005-07-21 0001104659-05-033462 — 1.01, 1.02, 2.03, 9.01
- 2005-06-13 0001104659-05-027969 — 8.01
- 2005-06-08 0001104659-05-027364 — 7.01, 9.01
- 2005-05-17 0001104659-05-024118 — 7.01, 9.01
- 2005-05-12 0001104659-05-022993 — 7.01, 9.01
- 2005-05-11 0001104659-05-022606 — 1.01, 9.01
- 2005-05-02 0001104659-05-019649 — 2.02, 5.02, 9.01
- 2005-04-26 0001104659-05-018233 — 7.01, 9.01
- 2005-02-08 0001104659-05-004642 — 2.02, 9.01
- 2005-01-12 0001104659-05-001194 — 7.01, 9.01
- 2004-12-22 0001104659-04-040933 — 5.02
- 2004-12-08 0001104659-04-038850 — 7.01, 9.01
- 2004-10-26 0001104659-04-031931 — 2.02, 9.01
- 2004-10-01 0001104659-04-029361 — 5.02
- 2004-08-02 0001104659-04-021785 — 9
- 2004-07-29 0001104659-04-021529 — 12
- 2004-05-06 0001104659-04-012742 — 9
- 2004-04-26 0001104659-04-011228 — 12
- 2004-02-03 0001104659-04-002424 — 9
- 2004-01-28 0001104659-04-001980 — 12
- 2004-01-09 0001104659-04-000457 — 9
- 2003-10-21 0001104659-03-023304 — 12
- 2003-07-29 0001104659-03-015999 — 12
- 2003-05-08 0001104659-03-008647 — 9
- 2003-05-08 0001104659-03-008462 — 9
- 2003-05-01 0001104659-03-007866 — 9
- 2003-03-07 0001104659-03-003816 — 2, 7 — amendment of 0000950153-02-002190
- 2002-12-27 0000950153-02-002190 — 2, 7
- 2002-05-17 0000912057-02-021145 — 4, 7
- 2001-12-21 0000912057-01-544281 — 7
- 2000-10-27 0000912057-00-046109 — 5

## late-filing notifications on or before 2014-05-06

- none on or before 2014-05-06

## item 2.02 — earnings release, exhibit 99.1

[0001171843-14-002017:8k_2_02:1]
EX-99
2
newsrelease.htm
PRESS RELEASE

[0001171843-14-002017:8k_2_02:2]
TTM Technologies, Inc. Reports First Quarter 2014 Results
EXHIBIT 99.1

[0001171843-14-002017:8k_2_02:3]
TTM Technologies, Inc. Reports First Quarter 2014 Results

[0001171843-14-002017:8k_2_02:4]
COSTA MESA, Calif., April 30, 2014 (GLOBE NEWSWIRE) -- TTM Technologies, Inc. (Nasdaq:TTMI), a major global printed circuit board (PCB) manufacturer, today reported results for the first quarter 2014, which ended March 31, 2014.

[0001171843-14-002017:8k_2_02:5]
First Quarter 2014 Highlights

[0001171843-14-002017:8k_2_02:6]
Net sales were $291.9 million

[0001171843-14-002017:8k_2_02:7]
GAAP net loss was $3.8 million, or $0.05 per share

[0001171843-14-002017:8k_2_02:8]
Non-GAAP net income was $1.2 million, or $0.01 per diluted share

[0001171843-14-002017:8k_2_02:9]
First Quarter 2014 Financial Results

[0001171843-14-002017:8k_2_02:10]
Net sales for the first quarter of 2014 were $291.9 million compared to $366.1 million in the fourth quarter of 2013 and $325.4 million in the first quarter of 2013. First quarter 2013 included $23 million of revenue from TTM's SYE plant, in which TTM sold its controlling equity interest during the second quarter of 2013.

[0001171843-14-002017:8k_2_02:11]
GAAP operating income for the first quarter of 2014 was $4.5 million compared to operating income of $29.3 million in the fourth quarter of 2013 and operating income of $12.7 million in the first quarter of 2013.

[0001171843-14-002017:8k_2_02:12]
GAAP net loss for the first quarter of 2014 was $3.8 million, or $0.05 per share. This compares to GAAP net income of $11.3 million, or $0.14 per diluted share, in the fourth quarter of 2013 and $5.2 million, or $0.06 per diluted share, in the first quarter of 2013.

[0001171843-14-002017:8k_2_02:13]
On a non-GAAP basis, net income for the first quarter of 2014 was $1.2 million, or $0.01 per diluted share. This compares to non-GAAP net income of $22.1 million, or $0.27 per diluted share, for the fourth quarter of 2013 and $9.8 million, or $0.12 per diluted share, for the first quarter of 2013.

[0001171843-14-002017:8k_2_02:14]
First quarter 2014 results included an unrealized, non-cash foreign exchange loss of approximately $3.6 million, or $(0.03) per diluted share, due to the rapid depreciation of the Chinese RMB against the U.S. dollar.

[0001171843-14-002017:8k_2_02:15]
Adjusted EBITDA for the first quarter of 2014 was $29.1 million, or 10.0 percent of net sales, compared to adjusted EBITDA of $58.4 million, or 16.0 percent of net sales, for the fourth quarter of 2013 and $41.5 million, or 12.7 percent of net sales, for the first quarter of 2013.

[0001171843-14-002017:8k_2_02:16]
"Our first quarter operating performance, excluding an unrealized, non-cash foreign exchange loss, was within our guidance range," said Tom Edman, CEO of TTM. "We largely experienced normal seasonality during the quarter with somewhat more pronounced softness in the cellular phone end market. However, we were pleased to see solid demand in our networking/communications end market."

[0001171843-14-002017:8k_2_02:17]
"We remain confident in our strategy to address a diverse group of served markets and customers. Looking towards the second half of the year, our scale and advanced technology capabilities position TTM well for customer product ramps," concluded Mr. Edman.

[0001171843-14-002017:8k_2_02:18]
Business Outlook

[0001171843-14-002017:8k_2_02:19]
For the second quarter of 2014, TTM estimates that revenue will be in the range of $290 million to $310 million, and non-GAAP earnings in the range of $0.02 to $0.08 per diluted share.

[0001171843-14-002017:8k_2_02:20]
To Access the Live Webcast/Conference Call

[0001171843-14-002017:8k_2_02:21]
The Company will host a conference call and webcast to discuss first quarter 2014 results and second quarter 2014 outlook on Wednesday, April 30, 2014, at 4:30 p.m. Eastern Time (1:30 p.m. Pacific Time).

[0001171843-14-002017:8k_2_02:22]
Telephone access is available by dialing domestic 1-877-941-9205 or international 1-480-629-9771. The conference call also will be webcast on TTM Technologies' website at www.ttmtech.com.

[0001171843-14-002017:8k_2_02:23]
To Access a Replay of the Webcast

[0001171843-14-002017:8k_2_02:24]
The replay of the webcast will remain accessible for one week following the live event on TTM Technologies' website at www.ttmtech.com.

[0001171843-14-002017:8k_2_02:25]
About Our Non-GAAP Financial Measures

[0001171843-14-002017:8k_2_02:26]
This release includes information about the Company's adjusted EBITDA, non-GAAP net income attributable to stockholders and non-GAAP earnings per share attributable to stockholders, all of which are non-GAAP financial measures. The Company presents non-GAAP financial information to enable investors to see the company through the eyes of management and to provide better insight into the Company's ongoing financial performance.

[0001171843-14-002017:8k_2_02:27]
Management believes that the non-GAAP financial information – which add back amortization of intangibles, stock-based compensation expense, non-cash interest expense on debt, asset impairments, restructuring and other unusual or infrequent items (such as the gain realized on the SYE transaction) as well as the associated tax impact of these charges and discrete tax items – provides additional useful information to investors regarding the Company's ongoing financial condition and results of operations.

[0001171843-14-002017:8k_2_02:28]
A material limitation associated with the use of the above non-GAAP financial measures is that they have no standardized measurement prescribed by GAAP and may not be comparable to similar non-GAAP financial measures used by other companies. The Company compensates for these limitations by providing full disclosure of each non-GAAP financial measure and reconciliation to the most directly comparable GAAP financial measure. However, the non-GAAP financial measures should not be considered in isolation from, or as a substitute for, financial information prepared in accordance with GAAP.

[0001171843-14-002017:8k_2_02:29]
Safe Harbor Statement

[0001171843-14-002017:8k_2_02:30]
This release contains forward-looking statements that relate to future events or performance. We caution you that such statements are simply predictions and actual events or results may differ materially. These statements reflect the company's current expectations and the company does not undertake to update or revise these forward looking statements, even if experience or future changes make it clear that any projected results expressed or implied in this or other company statements will not be realized. Further, these statements involve risks and uncertainties, many of which are beyond the company's control, which could cause actual results to differ materially from the forward-looking statements. These risks and uncertainties include, but are not limited to, general market and economic conditions, including interest rates, currency exchange rates and consumer spending, demand for the company's products, market pressures on prices of the company's products, warranty claims, changes in product mix, contemplated significant capital expenditures and related financing requirements, the company's dependence upon a small number of customers and other "Risk Factors" set forth in the company's most recent SEC filings.

[0001171843-14-002017:8k_2_02:31]
About TTM

[0001171843-14-002017:8k_2_02:32]
TTM Technologies, Inc. is a major global printed circuit board manufacturer, focusing on quick-turn and technologically advanced PCBs and the backplane and sub-system assembly business. TTM stands for time-to-market, representing how the Company's time-critical, one-stop manufacturing services enable customers to shorten the time required to develop new products and bring them to market. Additional information can be found at www.ttmtech.com.

[0001171843-14-002017:8k_2_02:33]
- Tables Follow -

[0001171843-14-002017:8k_2_02:34]
| TTM TECHNOLOGIES, INC. |
| Selected Unaudited Financial Information |
| (In thousands, except per share data) |
|  | First Quarter | Fourth Quarter |
|  | 2014 | 2013 | 2013 |
| CONSOLIDATED CONDENSED STATEMENTS OF OPERATIONS |  |  |  |
| Net sales | $ 291,895 | $ 325,392 | $ 366,111 |
| Cost of goods sold | 253,389 | 274,662 | 295,894 |
| Gross profit | 38,506 | 50,730 | 70,217 |
| Operating expenses: |  |  |  |
| Selling and marketing | 9,323 | 9,190 | 9,535 |
| General and administrative | 22,518 | 26,558 | 28,932 |
| Amortization of definite-lived intangibles | 2,236 | 2,328 | 2,348 |
| Restructuring charges | (24) | -- | 88 |
| Total operating expenses | 34,053 | 38,076 | 40,903 |
| Operating income | 4,453 | 12,654 | 29,314 |
| Interest expense | (6,206) | (6,278) | (5,982) |
| Loss on extinguishment of debt | (506) | -- | (10,743) |
| Other, net | (3,395) | 1,001 | 1,092 |
| (Loss) income before income taxes | (5,654) | 7,377 | 13,681 |
| Income tax benefit (provision) | 1,855 | (784) | (2,385) |
| Net (loss) income | (3,799) | 6,593 | 11,296 |
| Net (income) loss attributable to noncontrolling interest | -- | (1,441) | -- |
| Net (loss) income attributable to stockholders | $ (3,799) | $ 5,152 | $ 11,296 |
| (Loss) earnings per share attributable to stockholders: |  |  |  |
| Basic | $ (0.05) | $ 0.06 | $ 0.14 |
| Diluted | $ (0.05) | $ 0.06 | $ 0.14 |
| Weighted-average shares used in computing per share amounts: |  |  |  |
| Basic | 82,925 | 82,150 | 82,649 |
| Diluted | 82,925 | 82,842 | 83,451 |
| SELECTED BALANCE SHEET DATA |  |  |  |
|  | March 31, 2014 | December 30, 2013 |  |
| Cash and cash equivalents | $ 317,993 | $ 330,554 |  |
| Accounts and notes receivable, net | 202,092 | 277,070 |  |
| Inventories | 139,315 | 138,145 |  |
| Total current assets | 719,366 | 804,991 |  |
| Property, plant and equipment, net | 788,296 | 810,672 |  |
| Other non-current assets | 54,472 | 57,912 |  |
| Total assets | 1,562,134 | 1,673,575 |  |
| Short-term debt, including current portion long-term debt | $ 96,205 | $ 96,204 |  |
| Accounts payable | 154,888 | 192,357 |  |
| Total current liabilities | 392,485 | 458,003 |  |
| Debt, net of discount | 448,190 | 477,539 |  |
| Total long-term liabilities | 475,311 | 510,277 |  |
| Total stockholders' equity | 694,338 | 705,295 |  |
| Total liabilities and stockholders' equity | 1,562,134 | 1,673,575 |  |
| SUPPLEMENTAL DATA |  |  |  |
|  | First Quarter | Fourth Quarter |
|  | 2014 | 2013 | 2013 |
| Gross margin | 13.2% | 15.6% | 19.2% |
| Operating margin | 1.5 | 3.9 | 8.0 |
| End Market Breakdown: |  |  |  |
|  | First Quarter | Fourth Quarter |
|  | 2014 | 2013 | 2013 |
| Aerospace/Defense | 17% | 16% | 14% |
| Cellular Phone | 15 | 17 | 24 |
| Computing/Storage/Peripherals | 18 | 19 | 23 |
| Medical/Industrial/Instrumentation | 10 | 8 | 8 |
| Networking/Communications | 34 | 34 | 27 |
| Other | 6 | 6 | 4 |
| Stock-based Compensation: |  |  |  |
|  | First Quarter | Fourth Quarter |
|  | 2014 | 2013 | 2013 |
| Amount included in: |  |  |  |
| Cost of goods sold | $ 263 | $ 303 | $ 250 |
| Selling and marketing | 335 | 362 | 308 |
| General and administrative | 1,570 | 1,665 | 1,684 |
| Total stock-based compensation expense | $ 2,168 | $ 2,330 | $ 2,241 |
| Operating Segment Data: |  |  |  |
|  | First Quarter | Fourth Quarter |
| Net sales: | 2014 | 2013 | 2013 |
| Asia Pacific | $ 165,666 | $ 202,583 | $ 231,648 |
| North America | 126,589 | 123,589 | 134,936 |
| Total sales | 292,255 | 326,172 | 366,584 |
| Inter-segment sales | (360) | (780) | (473) |
| Total net sales | $ 291,895 | $ 325,392 | $ 366,111 |
| Operating segment income: |  |  |  |
| Asia Pacific | $ 3,867 | $ 11,125 | $ 25,863 |
| North America | 2,822 | 3,857 | 5,799 |
| Total operating segment income | 6,689 | 14,982 | 31,662 |
| Amortization of definite-lived intangibles | (2,236) | (2,328) | (2,348) |
| Total operating income | 4,453 | 12,654 | 29,314 |
| Total other expense | (10,107) | (5,277) | (15,633) |
| (Loss) income before income taxes | $ (5,654) | $ 7,377 | $ 13,681 |
| RECONCILIATIONS1 |  |  |  |
|  | First Quarter | Fourth Quarter |
|  | 2014 | 2013 | 2013 |
| Non-GAAP gross profit reconciliation2: |  |  |  |
| GAAP gross profit | $ 38,506 | $ 50,730 | $ 70,217 |
| Add back item: |  |  |  |
| Stock-based compensation | 263 | 303 | 250 |
| Non-GAAP gross profit | $ 38,769 | $ 51,033 | $ 70,467 |
| Non-GAAP gross margin | 13.3% | 15.7% | 19.2% |
| Non-GAAP operating income reconciliation3: |  |  |  |
| GAAP operating income | $ 4,453 | $ 12,654 | $ 29,314 |
| Add back items: |  |  |  |
| Amortization of definite-lived intangibles | 2,236 | 2,328 | 2,348 |
| Stock-based compensation | 2,168 | 2,330 | 2,241 |
| Impairments and restructuring charges | (24) | -- | 88 |
| Non-GAAP operating income | $ 8,833 | $ 17,312 | $ 33,991 |
| Non-GAAP operating margin | 3.0% | 5.3% | 9.3% |
| Non-GAAP net income and EPS attributable to stockholders reconciliation4: |  |  |  |
| GAAP net (loss) income attributable to stockholders | $ (3,799) | $ 5,152 | $ 11,296 |
| Add back items: |  |  |  |
| Amortization of definite-lived intangibles | 2,236 | 2,328 | 2,348 |
| Stock-based compensation | 2,168 | 2,330 | 2,241 |
| Non-cash interest expense | 2,523 | 2,055 | 2,183 |
| Impairments, restructuring and other charges | 482 | -- | 10,831 |
| Income taxes | (2,393) | (2,080) | (6,765) |
| Non-GAAP net income attributable to stockholders | $ 1,217 | $ 9,785 | $ 22,134 |
| Non-GAAP earnings per diluted share attributable to stockholders | $ 0.01 | $ 0.12 | $ 0.27 |
| Adjusted EBITDA reconciliation5: |  |  |  |
| GAAP net (loss) income | $ (3,799) | $ 6,593 | $ 11,296 |
| Add back items: |  |  |  |
| Income tax (benefit) provision | (1,855) | 784 | 2,385 |
| Interest expense | 6,206 | 6,278 | 5,982 |
| Amortization of definite-lived intangibles | 2,236 | 2,328 | 2,348 |
| Depreciation expense | 23,707 | 23,137 | 23,338 |
| Stock-based compensation | 2,168 | 2,330 | 2,241 |
| Impairments, restructuring and other charges | 482 | -- | 10,831 |
| Adjusted EBITDA | $ 29,145 | $ 41,450 | $ 58,421 |
| Adjusted EBITDA margin | 10.0% | 12.7% | 16.0% |
| 1 This information provides a reconciliation of non-GAAP gross profit, non-GAAP operating income, non-GAAP net income attributable to stockholders, non-GAAP EPS attributable to stockholders, and adjusted EBITDA to the financial information in our consolidated condensed statements of operations. |
| 2 Non-GAAP gross profit and gross margin measures exclude stock-based compensation expense. |
| 3 Non-GAAP operating income and operating margin measures exclude amortization of intangibles, stock-based compensation expense, gain on sale of assets, and restructuring and impairment charges. |
| 4 This information provides non-GAAP net income attributable to stockholders and non-GAAP EPS attributable to stockholders, which are non-GAAP financial measures. Management believes that both measures --- which add back amortization of intangibles, stock-based compensation expense, non-cash interest expense on debt (before consideration of capitalized interest), gain on sale of assets, asset impairments, restructuring and other charges as well as the associated tax impact of these charges and discrete tax items --- provide additional useful information to investors regarding the Company's ongoing financial condition and results of operations. |
| 5 Adjusted EBITDA is defined as earnings before interest expense, income taxes, depreciation, amortization of intangibles, stock-based compensation expense, gain on sale of assets, assets impairment, restructuring and other charges. We present adjusted EBITDA to enhance the understanding of our operating results, and it is a key measure we use to evaluate our operations. In addition, we provide our adjusted EBITDA because we believe that investors and securities analysts will find adjusted EBITDA to be a useful measure for evaluating our operating performance and comparing our operating performance with that of similar companies that have different capital structures and for evaluating our ability to meet our future debt service, capital expenditures, and working capital requirements. However, adjusted EBITDA should not be considered as an alternative to cash flows from operating activities as a measure of liquidity or as an alternative to net income as a measure of operating results in accordance with accounting principles generally accepted in the United States of America. |

[0001171843-14-002017:8k_2_02:35]
CONTACT: Todd Schull, CFO
         714-327-3000
