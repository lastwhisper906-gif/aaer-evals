# TTMI notes — 0001193125-18-055988


## us-gaap:CashAndCashEquivalentsPolicyTextBlock

[0001193125-18-055988:notes:1]
Cash
 Equivalents

[0001193125-18-055988:notes:2]
The Company
 considers highly liquid investments with insignificant interest
 rate risk and original maturities to the Company of three months or
 less to be cash equivalents. Cash equivalents consist primarily of
 interest-bearing bank accounts.

[0001193125-18-055988:notes:3]
The Company
 considers highly liquid investments with an effective maturity to
 the Company of more than three months and less than one year to be
 short-term investments.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001193125-18-055988:notes:4]
| (13) | Commitments and Contingencies |

[0001193125-18-055988:notes:5]
Operating
 Leases

[0001193125-18-055988:notes:6]
The Company
 leases some of its manufacturing and assembly plants, a sales
 office and equipment under noncancellable operating leases that
 expire at various dates through 2050. Certain real property leases
 contain renewal provisions at the Company’s option. Most of
 the leases require the Company to pay for certain other costs such
 as property taxes and maintenance. Certain leases also contain rent
 escalation clauses (step rents) that require additional rental
 amounts in the later years of the term. Rent expense for leases
 with step rents is recognized on a straight-line basis over the
 minimum lease term.

[0001193125-18-055988:notes:7]
The following is
 a schedule of future minimum lease payments as of January 1,
 2018:

[0001193125-18-055988:notes:8]
|  |  | Operating Leases |  |
|  |  | (In thousands) |  |
| 2018 |  | $ | 18,604 |  |
| 2019 |  |  | 5,565 |  |
| 2020 |  |  | 3,581 |  |
| 2021 |  |  | 2,700 |  |
| 2022 |  |  | 1,473 |  |
| Thereafter |  |  | 6,187 |  |
| Total minimum lease payments |  | $ | 38,110 |  |

[0001193125-18-055988:notes:9]
Total rent
 expense for the years ended January 1,
 2018, January 2, 2017 and December 28, 2015, was
 approximately $16,665, $10,329 and $7,362, respectively.

[0001193125-18-055988:notes:10]
Legal
 Matters

[0001193125-18-055988:notes:11]
The Company is
 subject to various legal matters, which it considers normal for its
 business activities. While the Company currently believes that the
 amount of any reasonably possible loss for known matters would not
 be material to the Company’s financial condition, the outcome
 of these actions is inherently difficult to predict. In the event
 of an adverse outcome, the ultimate potential loss could have a
 material adverse effect on the Company’s financial condition
 or results of operations in a particular period. The Company has
 accrued amounts for its loss contingencies which are probable and
 estimable as of January 1, 2018 and January 2, 2017.
 However, these amounts are not material to the consolidated
 financial statements of the Company.

[0001193125-18-055988:notes:12]
Environmental Matters

[0001193125-18-055988:notes:13]
The process to
 manufacture PCBs requires adherence to city, county, state,
 federal, and foreign environmental regulations regarding the
 storage, use, handling and disposal of chemicals, solid wastes and
 other hazardous materials, as well as compliance with air quality
 standards and chemical use reporting. The Company believes that its
 facilities in the United States and Canada comply in all material
 respects with applicable environmental laws and regulations. In
 China, governmental authorities have adopted new rules and
 regulations governing environmental issues. An update to the
 Chinese environmental waste water law was issued in late 2012,
 allowing for an interim period in which plants subject to such law
 may install equipment that meets the new regulatory regime. Some of
 the Company’s plants in China are not yet in full compliance
 with the newly adopted environmental regulations. The Company has
 developed plans in response to these new regulations and is in the
 process of implementing these plans. The Company has established
 and enacted an investment plan related to the efforts to come into
 full compliance with the new regulations. The 2018 capital
 expenditure costs expected for these plans are included in the
 Company’s capital expenditure projections.


## us-gaap:ConvertibleDebtTableTextBlock

[0001193125-18-055988:notes:14]
As of
 January 1, 2018 and January 2, 2017, the following
 summarizes the equity components of the convertible senior notes
 included in additional paid-in capital:

[0001193125-18-055988:notes:15]
|  |  | As of January 1, 2018 |  |  | As of January 2, 2017 |  |
|  |  | Embedded conversion option — Convertible Senior Notes |  |  | Embedded conversion option — Convertible Senior Notes Issuance Costs |  |  | Total |  |  | Embedded conversion option — Convertible Senior Notes |  |  | Embedded conversion option — Convertible Senior Notes Issuance Costs |  |  | Total |  |
|  |  | (in thousands) |  |
| Convertible senior notes due 2020 |  | $ | 60,216 |  |  | $ | (1,916 | ) |  | $ | 58,300 |  |  | $ | 60,227 |  |  | $ | (1,916 | ) |  | $ | 58,311 |  |


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001193125-18-055988:notes:16]
(14) Stock-Based
 Compensation

[0001193125-18-055988:notes:17]
Incentive
 Compensation Plan

[0001193125-18-055988:notes:18]
The Company
 maintains a 2014 Incentive Compensation Plan (the Plan), which
 allowed for the issuance of up to 5,288 shares. In May 2016, the
 Plan was amended to increase the amount allowed for issuance by
 5,000 shares, revising the maximum allowed for issuance to 10,288
 through its expiration date of February 2024.

[0001193125-18-055988:notes:19]
The Plan
 provides for the grant of incentive stock options and nonqualified
 stock options to the Company’s key employees, non-employee directors and
 consultants. Other types of awards such as performance-based
 restricted stock units (PRUs), restricted stock units (RSUs), and
 stock appreciation rights are also permitted. The exercise price
 for options and awards is determined by the compensation committee
 of the board of directors and, for options intended to qualify as
 incentive stock options, may not be less than the fair market value
 as determined by the closing stock price at the date of the grant.
 Each option and award shall vest and expire as determined by the
 compensation committee of the board of directors, with options,
 PRUs and RSUs generally vesting over three years for employees and
 one year for non-employee
 directors. Options, PRUs and RSUs do not have voting rights.
 Options expire no later than ten years from the grant date. All
 grants provide for accelerated vesting if there is a change in
 control, as defined in the Plan. Upon the exercise of outstanding
 stock options or vesting of RSUs and PRUs, the Company’s
 practice is to issue new registered shares that are reserved for
 issuance under the Plan.

[0001193125-18-055988:notes:20]
As of
 January 1, 2018, 930 PRUs, 2,918 RSUs and 80 stock options
 were outstanding under the Plan. Included in the 930 PRUs
 outstanding as of January 1, 2018 are 521 vested but not yet
 released. Included in the 2,918 RSUs outstanding as of
 January 1, 2018 are 505 vested but not yet released RSUs
 associated with non-employee directors. These RSUs
 vest over one year with release of the underlying shares of common
 stock deferred until retirement from the board of directors, (or
 until one year after retirement in the case of certain prior
 grants).

[0001193125-18-055988:notes:21]
Performance-based Restricted Stock
 Units

[0001193125-18-055988:notes:22]
The Company
 maintains a long-term incentive program for executives that
 provides for the issuance of PRUs, representing hypothetical shares
 of the Company’s common stock that may be issued. Under the
 PRU program, a target number of PRUs is awarded at the beginning of
 each three-year performance period. The number of shares of common
 stock released at the end of the performance period may range from
 zero to 2.4 times the target number depending on performance during
 the period. The performance metrics of the PRU program are based on
 (a) annual financial targets, which are based on revenue and
 EBITDA (earnings before interest, tax, depreciation, and
 amortization expense), each equally weighted, and (b) an
 overall modifier based on the Company’s total stockholder
 return (TSR) relative to a group of peer companies selected by the
 Company’s compensation committee, over the three-year
 performance period.

[0001193125-18-055988:notes:23]
Under the PRU
 program, financial goals are set at the beginning of each fiscal
 year and performance is reviewed at the end of that year. The
 percentage to be applied to each participant’s target award
 ranges from zero to 160% based upon the extent to which the annual
 financial performance goals are achieved. If specific performance
 threshold levels for the annual financial goals are met, the amount
 earned for that element will be applied to one-third of the participants’
 PRU award to determine the number of units earned.

[0001193125-18-055988:notes:24]
At the end of
 the three-year performance period, the total units earned, if any,
 are adjusted by applying a modifier, ranging from zero to 150%
 based on the Company’s TSR based on stock price changes
 relative to a group of peer companies selected by the
 Company’s compensation committee for the same three-year
 period.

[0001193125-18-055988:notes:25]
The TSR
 modifier is intended to ensure that there are limited or no payouts
 under the PRU program if the Company’s stock performance is
 significantly below the median TSR of a group of peer companies
 selected by the Company’s compensation committee over the
 three-year performance period. Where the annual financial goals
 have been met and where there has been strong relative TSR
 performance over the three-year performance period, the PRU program
 may provide substantial rewards to participants with a maximum
 payout of 2.4 times the initial PRU award. However, even if all of
 the annual financial metric goals are achieved in each of the three
 years, there will be no payouts if the Company’s stock
 performance is below that of the 10th percentile for PRUs granted
 in 2017 and 2016, and 20th percentile for PRUs granted prior to
 2016, of the group of peer companies selected by the
 Company’s compensation committee, as appropriate.

[0001193125-18-055988:notes:26]
Recipients of
 PRU awards generally must remain employed by the Company on a
 continuous basis through the end of the three-year performance
 period in order to receive any amount of the PRUs covered by that
 award. In events such as death, disability or retirement, the
 recipient may be entitled to pro-rata amounts of PRUs as defined in
 the Plan. Target shares subject to PRU awards do not have voting
 rights of common stock until earned and issued following the end of
 the three-year performance period.

[0001193125-18-055988:notes:27]
The Company
 records stock-based compensation expense for PRU awards granted
 based on management’s periodic assessment of the annual
 financial performance goals to be achieved. As of January 1,
 2018, management determined that vesting of the PRU awards was
 probable. PRU activity for the year ended January 1, 2018 was
 as follows:

[0001193125-18-055988:notes:28]
|  |  | Shares |  |  | Weighted Average Fair Value |  |
|  |  | (In thousands) |  |  |  |  |
| Outstanding shares at January 2, 2017 |  |  | 406 |  |  | $ | 8.31 |  |
| Granted |  |  | 363 |  |  |  | 22.90 |  |
| Vested |  |  | (521 | ) |  |  | 13.52 |  |
| Change in units due to annual performance achievement |  |  | 161 |  |  |  | 12.79 |  |
| Outstanding shares at January 1, 2018 |  |  | 409 |  |  | $ | 16.39 |  |

[0001193125-18-055988:notes:29]
The fair value
 of PRUs granted is calculated using a Monte Carlo simulation model,
 as the TSR modifier contains a market condition. For the years
 ended January 1, 2018, January 2, 2017 and
 December 28, 2015, the following assumptions were used in
 determining the fair value:

[0001193125-18-055988:notes:30]
|  |  | For the Year Ended |  |
|  |  | January 1, 2018(1) |  |  | January 2, 2017(2) |  |  | December 28, 2015(3) |  |
| Weighted-average fair value |  | $ | 22.90 |  |  | $ | 6.46 |  |  | $ | 7.22 |  |
| Risk-free interest rate |  |  | 1.20 | % |  |  | 0.8 | % |  |  | 0.5 | % |
| Dividend yield |  |  | — |  |  |  | — |  |  |  | — |  |
| Expected volatility |  |  | 43 | % |  |  | 40 | % |  |  | 37 | % |
| Expected term in months |  |  | 21 |  |  |  | 24 |  |  |  | 22 |  |

[0001193125-18-055988:notes:31]
| (1) | Reflects the weighted-averages for the third year of the three-year performance period applicable to PRUs granted in 2015, the second year of the three-year performance period applicable to PRUs granted in 2016 and the first year of the three-year performance period applicable to PRUs granted in 2017. |

[0001193125-18-055988:notes:32]
| (2) | Reflects the weighted-averages for the third year of the three-year performance period applicable to PRUs granted in 2014, the second year of the three-year performance period applicable to PRUs granted in 2015 and the first year of the three-year performance period applicable to PRUs granted in 2016. |

[0001193125-18-055988:notes:33]
| (3) | Reflects the weighted-averages for the third year of the three-year performance period applicable to PRUs granted in 2013, the second year of the three-year performance period applicable to PRUs granted in 2014 and the first year of the three-year performance period applicable to PRUs granted in 2015. |

[0001193125-18-055988:notes:34]
The expected
 term of the PRUs reflects the performance period for the PRUs
 granted. Expected volatility is calculated using the
 Company’s historical stock price. The risk-free interest rate
 for the expected term of PRUs is based on the U.S Treasury yield
 curve in effect at the time of grant.

[0001193125-18-055988:notes:35]
Restricted Stock Units

[0001193125-18-055988:notes:36]
RSU activity
 for the year ended January 1, 2018 was as follows:

[0001193125-18-055988:notes:37]
|  |  | Shares |  |  | Weighted Average Grant-Date Fair Value |  |
|  |  | (In thousands) |  |  |  |  |
| Non-vested RSUs outstanding at January 2, 2017 |  |  | 2,708 |  |  | $ | 7.48 |  |
| Granted |  |  | 1,029 |  |  |  | 15.85 |  |
| Vested |  |  | (1,235 | ) |  |  | 7.65 |  |
| Forfeited |  |  | (89 | ) |  |  | 9.92 |  |
| Non-vested RSUs outstanding at January 1, 2018 |  |  | 2,413 |  |  | $ | 10.88 |  |
| Vested and expected to vest at January 1, 2018 |  |  | 2,918 |  |  | $ | 10.57 |  |

[0001193125-18-055988:notes:38]
The fair value
 of the Company’s RSUs is determined based upon the closing
 common stock price on the grant date. The weighted average fair
 value per unit of RSUs granted was $15.85, $6.78 and $9.15 for the
 years ended January 1, 2018, January 2, 2017 and
 December 28, 2015, respectively. The total fair value of RSUs
 vested for the years ended January 1,
 2018, January 2, 2017 and December 28, 2015 was
 $9,446, $7,834 and $6,396, respectively.

[0001193125-18-055988:notes:39]
Stock
 Options

[0001193125-18-055988:notes:40]
During the year
 ended January 2, 2017, the Company granted 20 stock options to
 a newly appointed member of the board which were estimated to have
 a fair value per share of $6.78. The fair value calculation is
 based on stock options granted during the period using the
 Black-Scholes option-pricing model on the date of grant. For the
 year ended January 2, 2017 the fair value was determined using
 1.7% as the risk-free interest rate, 51% as the expected
 volatility, 8.5 years as the expected term and no dividend yield.
 No stock options were granted by the Company for the years ended
 January 1, 2018 or December 28, 2015.

[0001193125-18-055988:notes:41]
The Company
 determines the expected term of its stock option awards by periodic
 review of its historical stock option exercise experience. This
 calculation considers pre-vesting forfeitures and uses
 assumed future exercise patterns to account for option
 holders’ expected exercise and post-vesting termination
 behavior for outstanding stock options over their remaining
 contractual terms. Expected volatility is calculated by weighting
 the Company’s historical stock price to calculate expected
 volatility over the expected term of each grant. The risk-free
 interest rate for the expected term of each option granted is based
 on the U.S. Treasury yield curve in effect at the time of
 grant with a period that approximates the expected term of the
 options.

[0001193125-18-055988:notes:42]
Option activity
 under the Plan for the year ended January 1, 2018 was as
 follows:

[0001193125-18-055988:notes:43]
|  |  | Options |  |  | Weighted- Average Exercise Price |  |  | Weighted- Average Remaining Contractual Term |  |  | Aggregate Intrinsic Value |  |
|  |  | (In thousands) |  |  |  |  |  | (In years) |  |  | (In thousands) |  |
| Outstanding at January 2, 2017 |  |  | 87 |  |  | $ | 10.99 |  |  |  | 5.0 |  |  | $ | 228 |  |
| Exercised |  |  | (7 | ) |  |  | 11.16 |  |  |  |  |  |  |  |  |  |
| Outstanding at January 1, 2018 |  |  | 80 |  |  | $ | 10.98 |  |  |  | 4.2 |  |  | $ | 375 |  |
| Vested and expected to vest at January 1, 2018 |  |  | 80 |  |  | $ | 10.98 |  |  |  | 4.2 |  |  | $ | 375 |  |
| Exercisable at January 1, 2018 |  |  | 65 |  |  | $ | 10.78 |  |  |  | 3.1 |  |  | $ | 318 |  |

[0001193125-18-055988:notes:44]
The aggregate
 intrinsic values in the table above represent the total pretax
 intrinsic value (the difference between Company’s closing
 stock price on the last trading day of the 2017 fiscal year and the
 exercise price, multiplied by the number of in-the-money options) that
 would have been received by the option holders had all option
 holders exercised their options on January 1, 2018. This
 amount changes based on the fair market value of the
 Company’s stock. The total intrinsic value of options
 exercised for the years ended January 1, 2018, January 2,
 2017 and December 28, 2015 was $27, $127 and $131,
 respectively. The total fair value of the options vested for the
 year ended January 1, 2018 was $34. There were no options
 vested for the years ended January 2, 2017 and
 December 28, 2015.

[0001193125-18-055988:notes:45]
Stock-based Compensation Expense and Unrecognized
 Compensation Costs

[0001193125-18-055988:notes:46]
For the years
 ended January 1, 2018, January 2, 2017 and
 December 28, 2015, the amounts recognized in the consolidated
 financial statements with respect to the stock-based compensation
 plan are as follows:

[0001193125-18-055988:notes:47]
|  |  | For the Year Ended |  |
|  |  | January 1, 2018 |  |  | January 2, 2017 |  |  | December 28, 2015 |  |
|  |  | (In thousands) |  |
| Cost of goods sold |  | $ | 2,252 |  |  | $ | 1,630 |  |  | $ | 1,117 |  |
| Selling and marketing |  |  | 1,458 |  |  |  | 1,054 |  |  |  | 1,135 |  |
| General and administrative |  |  | 14,580 |  |  |  | 8,406 |  |  |  | 7,409 |  |
| Stock-based compensation expense recognized |  | $ | 18,290 |  |  | $ | 11,090 |  |  | $ | 9,661 |  |

[0001193125-18-055988:notes:48]
The Company may
 become entitled to a deduction in its tax returns upon the future
 exercise of incentive stock options under certain circumstances.
 For the years ended January 1, 2018, January 2, 2017 and
 December 28, 2015, the Company did not record an income tax
 benefit as a result of a full valuation allowance on its deferred
 tax assets.

[0001193125-18-055988:notes:49]
The following
 is a summary of total unrecognized compensation costs as of
 January 1, 2018:

[0001193125-18-055988:notes:50]
|  |  | Unrecognized Stock-Based Compensation Cost |  |  | Remaining Weighted Average Recognition Period |  |
|  |  | (In thousands) |  |  | (In years) |  |
| RSU awards |  | $ | 16,112 |  |  |  | 1.3 |  |
| PRU awards |  |  | 3,726 |  |  |  | 1.4 |  |
| Stock options |  |  | 95 |  |  |  | 1.9 |  |
|  |  | $ | 19,933 |  |  |  |  |  |


## us-gaap:EarningsPerSharePolicyTextBlock

[0001193125-18-055988:notes:51]
Earnings
 Per Share

[0001193125-18-055988:notes:52]
Basic earnings
 per common share excludes dilution and is computed by dividing net
 income attributable to TTM Technologies, Inc. stockholders by the
 weighted average number of common shares outstanding during the
 period. Diluted earnings per common share reflect the potential
 dilution that could occur if stock options, convertible senior
 notes or other common stock equivalents were exercised or converted
 into common stock. The dilutive effect of stock options or other
 common stock equivalents is calculated using the treasury stock
 method, while the dilutive effect of convertible senior notes is
 calculated using the if-converted method.


## us-gaap:InventoryPolicyTextBlock

[0001193125-18-055988:notes:53]
Inventories

[0001193125-18-055988:notes:54]
Inventories are
 stated at the lower of cost (determined on a first-in, first-out and weighted average basis)
 or net realizable value. Assessments to value the inventory at the
 lower of the actual cost to purchase and / or manufacture the
 inventory, or net realizable value of the inventory, are based upon
 assumptions about future demand and market conditions. As a result
 of the Company’s assessments, when the net realizable value
 of inventory is less than the carrying value, the inventory cost is
 written down to the net realizable value and the write down is
 recorded as a charge to cost of goods sold.


## us-gaap:NewAccountingPronouncementsPolicyPolicyTextBlock

[0001193125-18-055988:notes:55]
Recently
 Adopted and Issued Accounting Standards

[0001193125-18-055988:notes:56]
In August 2017,
 the Financial Accounting Standards Board (FASB) issued ASU
 2017-12, Derivatives
 and Hedging (Topic 815): Targeted Improvements to Accounting for
 Hedging Activities. This ASU amends and simplifies existing
 guidance in order to allow companies to more accurately present the
 economic effects of risk management activities in the financial
 statements. ASU 2017-12
 also amends the guidance surrounding the recognition of the value
 of hedged instruments to include the entire change in value, rather
 than just the effective portion, in other comprehensive income and
 recognized in earnings at the same time that the hedged item
 affects earnings for cash flow and net investment hedges. This ASU
 is effective for fiscal years beginning after December 15,
 2018, including interim periods within those fiscal years. Early
 adoption is permitted. The Company is currently evaluating the new
 guidance to determine the impact it may have on its consolidated
 financial statements and related disclosures.

[0001193125-18-055988:notes:57]
In January
 2017, the FASB issued ASU 2017-04, Intangibles (Topic 350):
 Goodwill and Other. This ASU simplifies the accounting for
 goodwill impairment and removes Step 2 of the goodwill impairment
 test. Goodwill impairment will now be the amount by which a
 reporting unit’s carrying value exceeds its fair value
 limited to the total amount of goodwill allocated to that reporting
 unit. Entities will continue to have the option to perform a
 qualitative assessment to determine if a quantitative impairment
 test is necessary. The Company elected to early adopt ASU
 2017-04 on a prospective
 basis during the second quarter of 2017 and the adoption did
 not have a material impact on its consolidated financial statements
 and related disclosures.

[0001193125-18-055988:notes:58]
In January
 2017, the FASB issued ASU 2017-01, Business Combinations
 (Topic 805): Clarifying the Definition of a
 Business. The purpose of this ASU is to clarify the definition
 of a business to assist entities with evaluating whether
 transactions should be accounted for as acquisitions (or disposals)
 of assets or businesses. The Company elected to early adopt ASU
 2017-01 on a prospective
 basis during the fourth quarter of 2017 and the adoption did
 not have a material impact on the consolidated financial statements
 and related disclosures.

[0001193125-18-055988:notes:59]
In October
 2016, the FASB issued ASU 2016-16, Income Taxes (Topic 740):
 Intra-Entity Transfers of Assets Other Than Inventory. The
 objective of this update is to improve the accounting for the
 income tax consequences of intra-entity transfers of assets other
 than inventory by recognizing the income tax consequences when the
 transfer occurs. This ASU is effective for fiscal years beginning
 after December 15, 2017, including interim periods within
 those fiscal years. Early adoption is permitted. The adoption of
 this standard is not expected to have a material impact on the
 consolidated financial statements or related
 disclosures.

[0001193125-18-055988:notes:60]
In August 2016,
 the FASB issued ASU 2016-15, Statement of Cash Flows
 (Topic 230). The objective of this update is to add or clarify
 guidance on the classification of certain cash receipts and
 payments in the statement of cash flows. The Company adopted this
 ASU 2016-15 in the first
 quarter of 2017 and the adoption did not have a material impact on
 the consolidated financial statements and related
 disclosures.

[0001193125-18-055988:notes:61]
In March 2016,
 the FASB issued ASU 2016-09, Stock Compensation (Topic
 718): Improvements to Employee Share-Based Payment Accounting.
 The objective of this update is to simplify several aspects of the
 accounting for employee share-based payment transactions, including
 the income tax consequences, classification of awards as either
 equity or liabilities, and classification on the statement of cash
 flows. The Company adopted ASU 2016-09 on January 3, 2017. The
 adoption did not have a material impact on the consolidated
 financial statements and related disclosures.

[0001193125-18-055988:notes:62]
In February
 2016, the FASB issued ASU 2016-02, Leases (Topic 842).
 The objective of this update is to increase transparency and
 comparability among organizations by recognizing lease assets and
 lease liabilities on the balance sheet and disclosing key
 information about leasing arrangements. This ASU is effective for
 fiscal years beginning after December 15, 2018, including
 interim periods within those annual periods and is to be applied
 utilizing a modified retrospective approach. While the Company
 continues to evaluate the new guidance to determine the impact it
 may have on its consolidated financial statements and related
 disclosures, the primary effect of adopting this update will be to
 record assets and obligations for current operating
 leases.

[0001193125-18-055988:notes:63]
In January
 2016, the FASB issued ASU 2016-01, Financial Instruments
 — Overall (Topic 825): Recognition and Measurement of
 Financial Assets and Financial Liabilities. This ASU amends
 certain aspects of recognition, measurement, presentation and
 disclosure of financial instruments, and supersedes the guidance to
 classify equity securities with readily determinable fair values
 into different categories (that is, trading or available-for-sale) and
 requires equity securities to be measured at fair value with
 changes in the fair value recognized through net income. This ASU
 is effective for annual and interim periods beginning after
 December 15, 2017. The Company does not anticipate the
 adoption will have a material impact on the consolidated financial
 statements and related disclosures.

[0001193125-18-055988:notes:64]
In May 2014,
 the FASB issued ASU 2014-09, Revenue from Contracts
 with Customers, as amended, which requires an entity to
 recognize the amount of revenue to which it expects to be entitled
 for the transfer of promised goods or services to customers. The
 ASU will replace most existing revenue recognition guidance in U.S.
 GAAP when it becomes effective. The new standard is effective for
 the Company at the beginning of fiscal year 2018. The standard
 permits the use of either the retrospective or cumulative effect
 transition method. The Company has assessed that the new guidance
 will result in a change to the timing of revenue recognition for
 the Company’s revenue stream from “point in time”
 upon physical delivery to an “over time” model and this
 transition will have a material impact on the Company’s
 consolidated financial statements upon adoption. As of
 January 2, 2018, management will apply the cumulative effect
 transition method and currently estimates that the adoption will
 increase retained earnings by a range of $30,000 to $40,000 and
 contract assets by a range of $250,000 to $270,000 for 2017. The
 Company has identified and implemented changes to its revenue
 processes and internal controls to meet the ASU’s reporting
 and disclosure requirements.


## us-gaap:ReclassificationOutOfAccumulatedOtherComprehensiveIncomeTableTextBlock

[0001193125-18-055988:notes:65]
The following
 provides a summary of reclassifications out of accumulated other
 comprehensive income, net of tax for the years ended
 January 1, 2018, January 2, 2017 and
 December 28, 2015:

[0001193125-18-055988:notes:66]
|  |  |  |  | Amount Reclassified from Accumulated Other Comprehensive Income For the Year Ended |  |
| Details about Accumulated Other Comprehensive Income Components |  | Statement of Operations Location |  | January 1, 2018 |  |  | January 2, 2017 |  |  | December 28, 2015 |  |
|  |  |  |  | (In thousands) |  |
| Loss on foreign currency forwards cash flow hedges |  | Depreciation expense, net of tax |  | $ | 162 |  |  | $ | 175 |  |  | $ | 172 |  |
| Gain on foreign currency translation |  | Gain on sale of assets, net of tax |  | $ | — |  |  | $ | — |  |  | $ | (1,786 | ) |


## us-gaap:ReconciliationOfOperatingProfitLossFromSegmentsToConsolidatedTextBlock

[0001193125-18-055988:notes:67]
The Company
 accounts for inter-segment sales and transfers consistent with the
 Company’s revenue recognition policy. The inter-segment sales
 for the year ended January 1, 2018 are sales primarily from
 the PCB to the E-M
 Solutions reportable segment.

[0001193125-18-055988:notes:68]
|  |  | For the Year Ended |  |
|  |  | January 1, 2018 |  |  | January 2, 2017 |  |  | December 28, 2015 |  |
|  |  | (In thousands) |  |
| Net Sales: |  |  |  |  |  |  |  |  |  |  |  |  |
| PCB |  | $ | 2,461,575 |  |  | $ | 2,346,554 |  |  | $ | 1,944,041 |  |
| E-M Solutions |  |  | 210,086 |  |  |  | 198,483 |  |  |  | 158,655 |  |
| Total sales |  |  | 2,671,661 |  |  |  | 2,545,037 |  |  |  | 2,102,696 |  |
| Inter-segment sales |  |  | (13,069 | ) |  |  | (11,678 | ) |  |  | (7,208 | ) |
| Total net sales |  | $ | 2,658,592 |  |  | $ | 2,533,359 |  |  | $ | 2,095,488 |  |
| Reportable Segment Income (Loss): |  |  |  |  |  |  |  |  |  |  |  |  |
| PCB |  | $ | 322,486 |  |  | $ | 285,046 |  |  | $ | 172,227 |  |
| E-M Solutions |  |  | 6,716 |  |  |  | 4,684 |  |  |  | 1,424 |  |
| Corporate |  |  | (92,808 | ) |  |  | (92,025 | ) |  |  | (93,421 | ) |
| Total reportable segment income |  |  | 236,394 |  |  |  | 197,705 |  |  |  | 80,230 |  |
| Amortization of definite-lived intangibles |  |  | (23,634 | ) |  |  | (24,252 | ) |  |  | (18,888 | ) |
| Total operating income |  |  | 212,760 |  |  |  | 173,453 |  |  |  | 61,342 |  |
| Total other expense |  |  | (72,802 | ) |  |  | (106,451 | ) |  |  | (52,366 | ) |
| Income before income taxes |  | $ | 139,958 |  |  | $ | 67,002 |  |  | $ | 8,976 |  |

[0001193125-18-055988:notes:69]
|  |  | For the Year Ended |  |
|  |  | January 1, 2018 |  |  | January 2, 2017 |  |  | December 28, 2015 |  |
|  |  | (In thousands) |  |
| Depreciation Expense: |  |  |  |  |  |  |  |  |  |  |  |  |
| PCB |  | $ | 144,256 |  |  | $ | 149,466 |  |  | $ | 130,339 |  |
| E-M Solutions |  |  | 2,471 |  |  |  | 2,540 |  |  |  | 2,079 |  |
| Corporate |  |  | 4,082 |  |  |  | 4,223 |  |  |  | 1,090 |  |
| Total depreciation expense |  | $ | 150,809 |  |  | $ | 156,229 |  |  | $ | 133,508 |  |
| Capital Expenditures: |  |  |  |  |  |  |  |  |  |  |  |  |
| PCB |  | $ | 161,152 |  |  | $ | 74,318 |  |  | $ | 72,036 |  |
| E-M Solutions |  |  | 5,438 |  |  |  | 3,206 |  |  |  | 4,006 |  |
| Corporate |  |  | 44,001 |  |  |  | 5,873 |  |  |  | 1,523 |  |
| Total capital expenditures |  | $ | 210,591 |  |  | $ | 83,397 |  |  | $ | 77,565 |  |


## us-gaap:RestructuringImpairmentAndOtherActivitiesDisclosureTextBlock

[0001193125-18-055988:notes:70]
| (4) | Restructuring and Impairment Charges |

[0001193125-18-055988:notes:71]
Consolidation Plan and Restructuring
 Activities

[0001193125-18-055988:notes:72]
During the year
 ended December 28, 2015 and following the acquisition of
 Viasystems on May 31, 2015, the Company announced a
 consolidation plan that resulted in the closure of certain of the
 Company’s facilities (the Consolidation Plan) and the layoff
 of related employees at these facilities. The Consolidation Plan
 was part of the Company’s integration strategy to improve
 total plant utilization, operational performance and customer
 focus. In connection with the Consolidation Plan and other global
 realignment restructuring efforts, the Company recognized employee
 separation costs and contract termination and other costs during
 the years ended January 1, 2018, January 2, 2017 and
 December 28, 2015. Contract termination and other costs
 primarily represented plant closure costs as well as costs related
 to building operating leases.

[0001193125-18-055988:notes:73]
The below table
 summarizes such restructuring costs by reportable segment for the
 years ended January 1, 2018, January 2, 2017 and
 December 28, 2015:

[0001193125-18-055988:notes:74]
|  |  | For the Year ended |  |
|  |  | January 1, 2018 |  |  | January 2, 2017 |  |  | December 28, 2015 |  |
|  |  | Employee separation/ severance |  |  | Contract termination and other costs |  |  | Total |  |  | Employee separation/ severance |  |  | Contract termination and other costs |  |  | Total |  |  | Employee separation/ severance |  |  | Contract termination and other costs |  |  | Total |  |
|  |  | (In thousands) |  |
| Reportable Segment: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| PCB |  | $ | 178 |  |  | $ | 99 |  |  | $ | 277 |  |  | $ | 1,548 |  |  | $ | 2,141 |  |  | $ | 3,689 |  |  | $ | 2,050 |  |  | $ | — |  |  | $ | 2,050 |  |
| E-M Solutions |  |  | — |  |  |  | 520 |  |  |  | 520 |  |  |  | 903 |  |  |  | 3,644 |  |  |  | 4,547 |  |  |  | 2,039 |  |  |  | — |  |  |  | 2,039 |  |
| Corporate |  |  | 33 |  |  |  | 360 |  |  |  | 393 |  |  |  | (231 | ) |  |  | 946 |  |  |  | 715 |  |  |  | 2,743 |  |  |  | 549 |  |  |  | 3,292 |  |
|  |  | $ | 211 |  |  | $ | 979 |  |  | $ | 1,190 |  |  | $ | 2,220 |  |  | $ | 6,731 |  |  | $ | 8,951 |  |  | $ | 6,832 |  |  | $ | 549 |  |  | $ | 7,381 |  |

[0001193125-18-055988:notes:75]
The below table
 shows the utilization of the accrued restructuring costs during the
 years ended January 1, 2018 and January 2,
 2017:

[0001193125-18-055988:notes:76]
|  |  | Severance |  |  | Contract Termination |  |  | Total |  |
|  |  | (In thousands) |  |
| Accrued at December 28, 2015 |  | $ | 6,044 |  |  | $ | 535 |  |  | $ | 6,579 |  |
| Charged to expense |  |  | 2,495 |  |  |  | 6,698 |  |  |  | 9,193 |  |
| Adjustments to estimate |  |  | (275 | ) |  |  | 33 |  |  |  | (242 | ) |
| Amount paid |  |  | (8,140 | ) |  |  | (6,224 | ) |  |  | (14,364 | ) |
| Accrued at January 2, 2017 |  | $ | 124 |  |  | $ | 1,042 |  |  | $ | 1,166 |  |
| Charged to expense |  |  | 211 |  |  |  | 979 |  |  |  | 1,190 |  |
| Amount paid |  |  | (335 | ) |  |  | (1,522 | ) |  |  | (1,857 | ) |
| Accrued at January 1, 2018 |  | $ | — |  |  | $ | 499 |  |  | $ | 499 |  |

[0001193125-18-055988:notes:77]
As of
 January 1, 2018, the Company has incurred approximately
 $17,522 of restructuring charges since the inception of the
 Consolidation Plan and has substantially completed such
 Consolidation Plan.

[0001193125-18-055988:notes:78]
Additionally,
 the Company recognized $3,346 in impairment charges during the year
 ended January 2, 2017. As a result of the above mentioned
 plant closures and other plant realignment efforts, $1,393 of
 impairment charges were recognized in the consolidated statement of
 operations related to machinery and equipment in the PCB reportable
 segment. In addition, $1,953 of impairment charges were recognized
 in the consolidated statement of operations related to capitalized
 software costs in Corporate.

[0001193125-18-055988:notes:79]
Sale of
 Suzhou, China Manufacturing Facility

[0001193125-18-055988:notes:80]
During the year
 ended December 28, 2015, the Company sold its Meadville
 Aspocomp (Suzhou) Electronic Co., Ltd. subsidiary for $21,275 and
 recognized a gain of $2,504. The Suzhou, China manufacturing
 facility is included in the PCB reportable segment.


## us-gaap:ScheduleOfAccumulatedOtherComprehensiveIncomeLossTableTextBlock

[0001193125-18-055988:notes:81]
The following
 provides a summary of the components of accumulated other
 comprehensive income (loss), net of tax as of January 1,
 2018, January 2, 2017 and December 28,
 2015:

[0001193125-18-055988:notes:82]
|  |  | Foreign Currency Translation |  |  | Gains (Losses) on Cash Flow Hedges |  |  | Total |  |
|  |  | (In thousands) |  |
| Ending balance at December 28, 2015 |  | $ | 2,895 |  |  | $ | (1,272 | ) |  | $ | 1,623 |  |
| Other comprehensive loss before reclassifications |  |  | (46,044 | ) |  |  | (83 | ) |  |  | (46,127 | ) |
| Amounts reclassified from accumulated other comprehensive income |  |  | — |  |  |  | 175 |  |  |  | 175 |  |
| Net year to date period other comprehensive income (loss) |  |  | (46,044 | ) |  |  | 92 |  |  |  | (45,952 | ) |
| Ending balance at January 2, 2017 |  |  | (43,149 | ) |  |  | (1,180 | ) |  |  | (44,329 | ) |
| Other comprehensive gain before reclassifications |  |  | 47,294 |  |  |  | 276 |  |  |  | 47,570 |  |
| Amounts reclassified from accumulated other comprehensive income |  |  | — |  |  |  | 162 |  |  |  | 162 |  |
| Net year to date period other comprehensive income |  |  | 47,294 |  |  |  | 438 |  |  |  | 47,732 |  |
| Ending balance at January 1, 2018 |  | $ | 4,145 |  |  | $ | (742 | ) |  | $ | 3,403 |  |


## us-gaap:ScheduleOfAntidilutiveSecuritiesExcludedFromComputationOfEarningsPerShareTextBlock

[0001193125-18-055988:notes:83]
The below is a
 summary of amounts convertible to common stock related to
 convertible senior notes and related warrants:

[0001193125-18-055988:notes:84]
|  |  | For the Year Ended |  |
|  |  | January 1, 2018 |  |  | January 2, 2017 |  |  | December 28, 2015 |  |
|  |  | (In thousands) |  |
| Common stock related to convertible senior notes |  |  | 25,939 |  |  |  | 25,940 |  |  |  | 25,940 |  |
| Warrants to purchase common stock |  |  | 25,940 |  |  |  | 25,940 |  |  |  | 26,408 |  |


## us-gaap:ScheduleOfComponentsOfIncomeTaxExpenseBenefitTableTextBlock

[0001193125-18-055988:notes:85]
The components
 of income tax provision for the years ended January 1,
 2018, January 2, 2017 and December 28, 2015
 are:

[0001193125-18-055988:notes:86]
|  |  | For the Year Ended |  |
|  |  | January 1, 2018 |  |  | January 2, 2017 |  |  | December 28, 2015 |  |
|  |  | (In thousands) |  |
| Current (provision) benefit: |  |  |  |  |  |  |  |  |  |  |  |  |
| Federal |  | $ | 82 |  |  | $ | (342 | ) |  | $ | 477 |  |
| State |  |  | (462 | ) |  |  | (512 | ) |  |  | (345 | ) |
| Foreign |  |  | (24,006 | ) |  |  | (29,672 | ) |  |  | (19,379 | ) |
| Total current |  |  | (24,386 | ) |  |  | (30,526 | ) |  |  | (19,247 | ) |
| Deferred (provision) benefit: |  |  |  |  |  |  |  |  |  |  |  |  |
| Federal |  |  | 11 |  |  |  | — |  |  |  | (10,084 | ) |
| State |  |  | (31 | ) |  |  | — |  |  |  | (2,184 | ) |
| Foreign |  |  | 9,175 |  |  |  | (901 | ) |  |  | (3,079 | ) |
| Total deferred |  |  | 9,155 |  |  |  | (901 | ) |  |  | (15,347 | ) |
| Total provision |  | $ | (15,231 | ) |  | $ | (31,427 | ) |  | $ | (34,594 | ) |


## us-gaap:ScheduleOfDebtInstrumentsTextBlock

[0001193125-18-055988:notes:87]
The following
 table summarizes the long-term debt of the Company as of
 January 1, 2018 and January 2, 2017:

[0001193125-18-055988:notes:88]
|  |  | Interest Rate as of January 1, 2018 |  |  | Principal Outstanding as of January 1, 2018 |  |  | Interest Rate as of January 2, 2017 |  |  | Principal Outstanding as of January 2, 2017 |  |
|  |  | (In thousands) |  |
| Term Loan due September 2024 |  |  | 4.06 | % |  | $ | 349,125 |  |  |  | — |  |  |  | — |  |
| Senior Notes due October 2025 |  |  | 5.63 | % |  |  | 375,000 |  |  |  | — |  |  |  | — |  |
| Term Loan due May 2021 |  |  | — |  |  |  | — |  |  |  | 5.25 | % |  | $ | 700,000 |  |
| Convertible Senior Notes due December 2020 |  |  | 1.75 | % |  |  | 249,985 |  |  |  | 1.75 | % |  |  | 250,000 |  |
| U.S. ABL Revolving Loan due May 2020 |  |  | 3.06 | % |  |  | 17,000 |  |  |  | 2.27 | % |  |  | 80,000 |  |
| Asia ABL Revolving Loan due May 2020 |  |  | 2.96 | % |  |  | 30,000 |  |  |  | 2.17 | % |  |  | 30,000 |  |
| Capital Lease |  |  | 6.43 | % |  |  | 1,919 |  |  |  | 6.43 | % |  |  | 1,798 |  |
|  |  |  |  |  |  |  | 1,023,029 |  |  |  |  |  |  |  | 1,061,798 |  |
| Less: Long-term debt unamortized discount |  |  |  |  |  |  | (30,513 | ) |  |  |  |  |  |  | (37,392 | ) |
| Long-term debt unamortized debt issuance costs |  |  |  |  |  |  | (12,459 | ) |  |  |  |  |  |  | (4,724 | ) |
|  |  |  |  |  |  |  | 980,057 |  |  |  |  |  |  |  | 1,019,682 |  |
| Less: current maturities |  |  |  |  |  |  | (4,578 | ) |  |  |  |  |  |  | (110,652 | ) |
| Long-term debt, less current maturities |  |  |  |  |  | $ | 975,479 |  |  |  |  |  |  | $ | 909,030 |  |


## us-gaap:ScheduleOfRevenuesFromExternalCustomersAndLongLivedAssetsByGeographicalAreasTableTextBlock

[0001193125-18-055988:notes:89]
Net sales and
 long-lived assets are as follows:

[0001193125-18-055988:notes:90]
|  |  | 2017 |  |  | 2016 |  |  | 2015 |  |
|  |  | Net Sales |  |  | Long-Lived Assets |  |  | Net Sales |  |  | Long-Lived Assets |  |  | Net Sales |  |  | Long-Lived Assets |  |
|  |  | (In thousands) |  |
| United States |  | $ | 850,511 |  |  | $ | 642,256 |  |  | $ | 1,119,086 |  |  | $ | 661,058 |  |  | $ | 960,146 |  |  | $ | 654,579 |  |
| China |  |  | 957,296 |  |  |  | 866,126 |  |  |  | 646,844 |  |  |  | 781,678 |  |  |  | 547,999 |  |  |  | 923,219 |  |
| Other |  |  | 850,785 |  |  |  | 23,984 |  |  |  | 767,429 |  |  |  | 23,124 |  |  |  | 587,343 |  |  |  | 23,133 |  |
| Total |  | $ | 2,658,592 |  |  | $ | 1,532,366 |  |  | $ | 2,533,359 |  |  | $ | 1,465,860 |  |  | $ | 2,095,488 |  |  | $ | 1,600,931 |  |


## us-gaap:SignificantAccountingPoliciesTextBlock

[0001193125-18-055988:notes:91]
| (2) | Summary of Significant Accounting Policies |

[0001193125-18-055988:notes:92]
Use of
 Estimates

[0001193125-18-055988:notes:93]
The preparation
 of financial statements in conformity with accounting principles
 generally accepted in the United States of America (U.S. GAAP)
 requires management to make estimates and assumptions that affect
 the reported amounts of assets and liabilities and disclosure of
 contingent assets and liabilities at the date of the financial
 statements and the reported amount of revenues and expenses during
 the reporting period. Such estimates include the sales return
 reserve; accounts receivable; inventories; goodwill; intangible
 assets and other long-lived assets; self insurance reserves;
 product warranty liabilities; environmental liabilities; legal
 contingencies; income taxes; and others. These estimates and
 assumptions are based on management’s best estimates and
 judgment. Management evaluates its estimates and assumptions on an
 ongoing basis using historical experience and other factors,
 including the economic environment, which management believes to be
 reasonable under the circumstances. Management adjusts such
 estimates and assumptions when facts and circumstances dictate. The
 actual results we experienced may differ materially and adversely
 from our estimates. To the extent there are material differences
 between the estimates and actual results, our future result of
 operations will be affected.

[0001193125-18-055988:notes:94]
Principles of Consolidation

[0001193125-18-055988:notes:95]
The
 consolidated financial statements include the accounts of TTM and
 its subsidiaries. All intercompany accounts and transactions have
 been eliminated in consolidation.

[0001193125-18-055988:notes:96]
Foreign
 Currency Translation and Transactions

[0001193125-18-055988:notes:97]
The functional
 currency of certain of the Company’s subsidiaries is either
 the Chinese Renminbi (RMB) or the Hong Kong Dollar. Accordingly,
 assets and liabilities are translated into U.S. dollars using
 period-end exchange rates.
 Sales and expenses are translated at the average exchange rates in
 effect during the period. The resulting translation gains or losses
 are recorded as a component of accumulated other comprehensive
 income in the consolidated statement of stockholders’ equity
 and the consolidated statement of comprehensive income (loss). Net
 gains and losses resulting from foreign currency remeasurements and
 transactions are included in income as a component of other, net in
 the consolidated statements of operations and totaled $22,802 loss,
 $13,538 gain and $6,766 gain for the years ended January 1,
 2018, January 2, 2017 and December 28, 2015,
 respectively.

[0001193125-18-055988:notes:98]
Accounts
 Receivable and Allowance for Doubtful Accounts

[0001193125-18-055988:notes:99]
Accounts
 receivable are reflected at estimated net realizable value, do not
 bear interest and do not generally require collateral. The Company
 performs credit evaluations of its customers and adjusts credit
 limits based upon payment history and the customer’s current
 creditworthiness. The Company maintains an allowance for doubtful
 accounts based upon a variety of factors. The Company reviews all
 open accounts and provides specific reserves for customer
 collection issues when it believes the loss is probable,
 considering such factors as the length of time receivables are past
 due, the financial condition of the customer, and historical
 experience. The Company also records a reserve for all customers,
 excluding those that have been specifically reserved for, based
 upon evaluation of historical losses.

[0001193125-18-055988:notes:100]
The following
 summarizes the activity in the Company’s allowance for
 doubtful accounts for the years ended January 1,
 2018, January 2, 2017 and December 28,
 2015:

[0001193125-18-055988:notes:101]
|  |  | For the Year Ended |  |
|  |  | January 1, 2018 |  |  | January 2, 2017 |  |  | December 28, 2015 |  |
|  |  | (In thousands) |  |
| Balance at beginning of year |  | $ | 2,851 |  |  | $ | 1,525 |  |  | $ | 696 |  |
| Additions charged to expense |  |  | 346 |  |  |  | 1,560 |  |  |  | 854 |  |
| Deductions |  |  | (719 | ) |  |  | (223 | ) |  |  | (26 | ) |
| Effect of foreign currency exchange rates |  |  | (10 | ) |  |  | (11 | ) |  |  | 1 |  |
| Balance at end of year |  | $ | 2,468 |  |  | $ | 2,851 |  |  | $ | 1,525 |  |

[0001193125-18-055988:notes:102]
Property,
 Plant and Equipment, Net

[0001193125-18-055988:notes:103]
Property, plant
 and equipment are recorded at cost. Depreciation expense is
 computed using the straight-line method over the estimated useful
 lives of the assets. Assets recorded under leasehold improvements
 are amortized using the straight-line method over the lesser of
 their useful lives or the related lease term. The Company uses the
 following estimated useful lives:

[0001193125-18-055988:notes:104]
| Land use rights |  |  | 50-99 years |  |
| Buildings and improvements |  |  | 7-50 years |  |
| Machinery and equipment |  |  | 3-12 years |  |
| Furniture and fixtures |  |  | 3-7 years |  |

[0001193125-18-055988:notes:105]
Upon retirement
 or other disposition of property, plant and equipment, the cost and
 related accumulated depreciation are removed from the accounts. The
 resulting gain or loss is included in the determination of
 operating income in the period incurred. Depreciation and
 amortization expense on property, plant and equipment was $150,809,
 $156,229, and $133,508 for the years ended January 1,
 2018, January 2, 2017 and December 28, 2015,
 respectively.

[0001193125-18-055988:notes:106]
The Company
 capitalizes interest on borrowings during the active construction
 period of major capital projects. Capitalized interest is amortized
 over the average useful lives of such assets, which primarily
 consist of buildings and machinery and equipment. The Company
 capitalized interest costs of $1,494, $1,876 and $888 during the
 years ended January 1, 2018, January 2, 2017 and
 December 28, 2015, respectively, in connection with various
 capital projects.

[0001193125-18-055988:notes:107]
Major renewals
 and betterments are capitalized and depreciated over their
 estimated useful lives while minor expenditures for maintenance and
 repairs are included in operating income as incurred.

[0001193125-18-055988:notes:108]
Goodwill

[0001193125-18-055988:notes:109]
Goodwill
 represents the excess of purchase price of an acquisition over the
 fair value of net assets acquired. Goodwill is not amortized but
 instead is assessed for impairment, at a reporting unit level,
 annually and when events and circumstances warrant an evaluation.
 In making this assessment, management relies on a number of
 factors, including expected future operating results, business
 plans, economic projections, anticipated future cash flows,
 business trends and market conditions.

[0001193125-18-055988:notes:110]
The Company has
 two reportable segments consisting of four reporting units. The
 Company evaluates its goodwill on an annual basis in the fourth
 quarter or more frequently if it believes indicators of impairment
 exist. The Company assesses qualitative factors to determine
 whether it is more likely than not that the fair value of a
 reporting unit is less than its carrying amount. If the Company
 concludes that it is more likely than not that the fair value of a
 reporting units is less than its carrying amount, it compares the
 fair values of the applicable reporting units with their carrying
 values. The Company estimates the fair values of its reporting
 units using a combination of the income and market approach. If the
 carrying amount of a reporting unit exceeds the reporting
 unit’s fair value, the amount by which the carrying value
 exceeds the fair value is recognized as an impairment loss. In the
 fourth quarter of 2017, the Company performed its annual impairment
 test qualitatively and concluded that goodwill was not
 impaired.

[0001193125-18-055988:notes:111]
Intangible Assets

[0001193125-18-055988:notes:112]
Intangible
 assets include customer relationships and technology, which are
 being amortized over their estimated useful lives using
 straight-line and accelerated methods. The estimated useful lives
 of such intangibles range from 3 years to 10 years.

[0001193125-18-055988:notes:113]
Impairment of Long-lived Assets

[0001193125-18-055988:notes:114]
Long-lived
 tangible assets, including property, plant and equipment, assets
 held for sale, and definite-lived intangible assets, are reviewed
 for impairment whenever events or changes in circumstances indicate
 that the carrying value of the asset or asset groups may not be
 recoverable. The Company regularly evaluates whether events or
 circumstances have occurred that indicate possible impairment and
 relies on a number of factors, including expected future operating
 results, business plans, economic projections, and anticipated
 future cash flows. The Company uses an estimate of the future
 undiscounted net cash flows of the related asset or asset group
 over the remaining life in measuring whether the assets are
 recoverable. Measurement of the amount of impairment, if any, is
 based upon the difference between the asset’s carrying value
 and estimated fair value. Fair value is determined through various
 valuation techniques, including cost-based, market and income
 approaches as considered necessary. See Note 4 for information
 regarding the impairment of long-lived assets during
 2016.

[0001193125-18-055988:notes:115]
The Company
 classifies assets to be sold as assets held for sale when
 (i) Company management has approved and commits to a plan to
 sell the asset; (ii) the asset is available for immediate sale
 in its present condition and is ready for sale; (iii) an
 active program to locate a buyer and other actions required to sell
 the asset have been initiated; (iv) the sale of the asset is
 probable; (v) the asset is being actively marketed for sale at
 a price that is reasonable in relation to its current fair value;
 and (vi) it is unlikely that significant changes to the plan
 will be made or that the plan will be withdrawn. Assets classified
 as held for sale are recorded at the lower of the carrying amount
 or fair value less the cost to sell and are a component of prepaid
 expenses and other current assets in the consolidated balance
 sheet.

[0001193125-18-055988:notes:116]
The Company
 classifies assets held for use when a decision to dispose of an
 asset or a business is made and the held for sale criteria are not
 met. Assets of the business are evaluated for recoverability in the
 following order: (i) assets other than goodwill, property and
 intangibles; (ii) property and intangibles subject to
 amortization; and (iii) goodwill. In evaluating the
 recoverability of property and intangible assets subject to
 amortization, in a held for use business, the carrying value is
 first compared to the sum of the undiscounted cash flows expected
 to result from the use and eventual disposition. If the carrying
 value exceeds the undiscounted expected cash flows, then a fair
 value analysis is performed. An impairment charge is recognized if
 the carrying value exceeds the fair value.

[0001193125-18-055988:notes:117]
Revenue
 Recognition

[0001193125-18-055988:notes:118]
The Company
 derives its revenue primarily from the sale of PCBs using customer
 supplied engineering and design plans and recognizes revenue when:
 (i) persuasive evidence of a sales arrangement exists;
 (ii) the sales terms are fixed or determinable;
 (iii) title and risk of loss have transferred; and
 (iv) collectability is reasonably assured — generally
 when products are shipped to the customer, except in situations in
 which title passes upon receipt of the products by the customer. In
 this case, revenues are recognized upon notification that customer
 receipt has occurred. The Company does not have customer acceptance
 provisions, but it does provide its customers a limited right of
 return for defective PCBs. The Company accrues an estimated amount
 for sales returns and allowances related to defective PCBs at the
 time of sale based on its ability to estimate sales returns and
 allowances using current and historical information. The reserve
 for sales returns and allowances is included as a reduction to
 revenue and accounts receivable, net. Shipping and handling fees
 and related freight costs and supplies associated with shipping
 products to customers are included as a component of cost of goods
 sold. Incremental warranty costs that are not related to sales
 returns are recorded in accrued expenses and cost of goods
 sold.

[0001193125-18-055988:notes:119]
The following
 summarizes the activity in the Company’s allowance for sales
 returns and allowances for the years ended January 1,
 2018, January 2, 2017 and December 28,
 2015:

[0001193125-18-055988:notes:120]
|  |  | For the Year Ended |  |
|  |  | January 1, 2018 |  |  | January 2, 2017 |  |  | December 28, 2015 |  |
|  |  | (In thousands) |  |
| Balance at beginning of year |  | $ | 8,119 |  |  | $ | 7,789 |  |  | $ | 6,890 |  |
| Additions charged as a reduction of sales |  |  | 14,574 |  |  |  | 22,060 |  |  |  | 21,728 |  |
| Deductions |  |  | (14,524 | ) |  |  | (21,728 | ) |  |  | (20,832 | ) |
| Effect of foreign currency exchange rates |  |  | 2 |  |  |  | (2 | ) |  |  | 3 |  |
| Balance at end of year |  | $ | 8,171 |  |  | $ | 8,119 |  |  | $ | 7,789 |  |

[0001193125-18-055988:notes:121]
Stock-Based Compensation

[0001193125-18-055988:notes:122]
The Company
 recognizes stock-based compensation expense in its consolidated
 financial statements for its incentive compensation plan
 awards.

[0001193125-18-055988:notes:123]
The incentive
 compensation plan awards include performance-based restricted stock
 units, restricted stock units, and stock options. The associated
 compensation expense for all awards is based on the grant date fair
 value of the awards, and for years 2016 and 2015 include estimated
 forfeitures. For performance-based restricted stock units,
 compensation expense also includes management’s periodic
 assessment of annual financial performance goals to be achieved.
 Compensation expense for the incentive compensation plan awards is
 recognized on a straight line basis over the vesting period of the
 awards. The fair value of performance-based restricted stock units
 is estimated on the grant date using a Monte Carlo simulation model
 based on the underlying common stock closing price as of the date
 of grant, the expected term, stock price volatility, and risk-free
 interest rates. The fair value of restricted stock units is
 measured on the grant date based on the quoted closing market price
 of the Company’s common stock. The fair value of the stock
 options is estimated on the grant date using the Black-Scholes
 option pricing model based on the underlying common stock closing
 price as of the date of grant, the expected term, stock price
 volatility, and risk-free interest rates.

[0001193125-18-055988:notes:124]
Income
 Taxes

[0001193125-18-055988:notes:125]
Income taxes
 are accounted for under the asset and liability method. Deferred
 income tax assets or liabilities are recognized for the future tax
 consequences attributable to differences between the financial
 statement carrying amounts of assets and liabilities and their
 respective tax bases and operating loss and tax credit
 carryforwards. Deferred income tax assets and liabilities are
 measured using enacted tax rates expected to apply to taxable
 income in the years in which those temporary differences are
 expected to be settled or realized. The effect on deferred income
 tax assets and liabilities of a change in tax rates is recognized
 in income in the period that includes the enactment date. Deferred
 income tax assets are reviewed for recoverability, and the Company
 records a valuation allowance to reduce its deferred income tax
 assets when it is more likely than not that all or some portion of
 the deferred income tax assets will not be realized.

[0001193125-18-055988:notes:126]
The Company has
 various foreign subsidiaries formed or acquired to conduct or
 support its business outside the United States. The Company expects
 its earnings attributable to foreign subsidiaries will be
 indefinitely reinvested outside of the U.S., except as noted below
 and, therefore, no deferred tax liabilities for U.S. income taxes
 on undistributed earnings are recorded. Foreign earnings from
 certain subsidiaries may be repatriated to the parent holding
 company located in the Cayman Islands, and therefore, a deferred
 tax liability has been recorded on the undistributed earnings of
 these subsidiaries.

[0001193125-18-055988:notes:127]
The Company
 recognizes the effect of income tax positions only if those
 positions are more likely than not to be sustained. Recognized
 income tax positions are measured at the largest amount that is
 greater than 50 percent likely to be realized. Changes in
 recognition or measurement are reflected in the period in which the
 change in judgment occurs. Estimated interest and penalties related
 to underpayment of income taxes are recorded as a component of
 income tax provision in the consolidated statement of
 operations.

[0001193125-18-055988:notes:128]
Effects of the Tax
 Cuts and Jobs Act

[0001193125-18-055988:notes:129]
On
 December 22, 2017, the Tax Cuts and Jobs Act (Tax Act) was
 enacted. Accounting Standard Codification (ASC) 740, Accounting
 for Income Taxes, requires companies to recognize the effect of
 tax law changes in the period of enactment regardless of the
 effective date of those tax law changes. Certain provisions of the
 Tax Act are effective September 27, 2017, others are effective
 or identified as of December 31, 2017 and others are effective
 after January 1, 2018.

[0001193125-18-055988:notes:130]
Given the
 timing of enactment of the Tax Act and the significance of the
 legislation, the SEC staff issued Staff Accounting Bulletin
 No. 118 (SAB 118), which allows registrants to record
 provisional amounts during a one year “measurement
 period” similar to that used when accounting for business
 combinations. However, the measurement period should not extend
 beyond one year from the Tax Act enactment date and is deemed to
 have ended when the registrant has obtained, prepared and analyzed
 the information necessary to finalize its accounting.

[0001193125-18-055988:notes:131]
To the extent
 that a company’s accounting for certain income tax effects of
 the Tax Act is incomplete but the registrant is able to determine a
 reasonable estimate, it must record a provisional estimate in the
 financial statements. If a company cannot determine a provisional
 estimate to be included in the financial statements, it should
 continue to apply ASC 740, Accounting for Income
 Taxes, on the basis of the provisions of the tax laws that were
 in effect immediately before the enactment of the Tax Act. More
 specifically, SAB 118 summarizes a three-step process to be applied
 at each reporting period to account for and disclose the tax
 effects of the Tax Act. The steps are (1) to record the
 effects of the change in tax law for which accounting is complete;
 (2) to record provisional amounts (or adjustments to
 provisional amounts) for the effects of the tax law where
 accounting is not complete, but for which a reasonable estimate has
 been determined; and (3) where a reasonable estimate cannot
 yet be made, to continue to apply ASC 740, Accounting for
 Income Taxes, based on the tax law in effect prior to
 enactment of the Tax Act.

[0001193125-18-055988:notes:132]
Amounts
 recorded where accounting is complete for the year ended
 January 1, 2018 primarily relate to the reduction in the U.S.
 corporate income tax rate to 21 percent. The Company revalued
 its ending gross deferred tax items, previously recorded at
 35 percent, using the enacted 21 percent corporate tax
 rate. This change resulted in no net tax expense/benefit but did
 cause an approximate $66,000 reduction to our U.S. federal deferred
 tax asset fully offset by a reduction of our valuation
 allowance.

[0001193125-18-055988:notes:133]
Effects of tax
 law changes where a reasonable estimate of the accounting effects
 cannot yet been made include the one-time mandatory repatriation
 transition tax on the net accumulated earnings and profits of a
 U.S. taxpayer’s foreign subsidiaries earned post 1986. The
 Company has performed a preliminary earnings and profits analysis
 with consideration given to foreign loss carryforwards acquired as
 a result of the Company’s acquisitions and determined on a
 provisional basis that there should be no income tax effect in the
 current or any future period. The Company will continue to identify
 and evaluate data to more thoroughly identify the tax impact and
 record adjustments, if any, within the measurement
 period.

[0001193125-18-055988:notes:134]
Other
 significant provisions that are not yet effective for which the
 Company has not completed its analysis, but may impact income taxes
 in future years include: limitations on certain entertainment
 expenses, the inclusion of commissions and performance based
 compensation in determining the excessive compensation limitation,
 limitation on the current deductibility of net interest expense in
 excess of 30 percent of adjusted taxable income, an
 incremental tax (base erosion anti-abuse tax or BEAT) on excessive
 amounts paid to foreign related parties, a minimum tax on certain
 foreign earnings in excess of 10 percent of the foreign
 subsidiaries tangible assets (i.e., global intangible low-taxed income or GILTI), the
 benefit related to foreign derived intangible income (FDII), the
 required capitalization of research and development expenditures
 and the impact of requiring tax conformity with Accounting Standard
 Update (ASU) 2014-09,
 Revenue from Contracts with Customers. The Company is still
 evaluating whether to make a policy election to treat the GILTI tax
 as a period expense or to provide U.S. deferred taxes on foreign
 earnings that are expected to generate GILTI income when they
 reverse in future years.

[0001193125-18-055988:notes:135]
Self
 Insurance

[0001193125-18-055988:notes:136]
The Company is
 primarily self insured in the United States for group health
 insurance and workers compensation benefits provided to U.S.
 employees. The Company also purchases stop loss insurance to
 protect against annual claims per individual and at an aggregate
 level. The individual insured stop loss on the Company’s self
 insurance is $350 per individual for group health insurance and
 $250 per individual for worker’s compensation benefits. Self
 insurance liabilities are estimated for claims incurred but not
 paid based on judgment, using the Company’s historical claim
 data and information and analysis provided by actuarial and claim
 advisors, the Company’s insurance carrier and brokers. The
 Company has accrued $6,386 and $5,375 for self insurance
 liabilities as of January 1, 2018 and January 2, 2017,
 respectively, and these amounts are reflected within accrued
 salaries, wages and benefits in the consolidated balance
 sheets.

[0001193125-18-055988:notes:137]
Group health
 insurance and workers compensation benefits for the Company’s
 plants in China and Canada are fully insured with third
 parties.

[0001193125-18-055988:notes:138]
Convertible Debt

[0001193125-18-055988:notes:139]
The accounting
 standards for convertible debt instruments that may be fully or
 partially settled in cash upon conversion require the debt and
 equity components to be separately accounted for in a manner that
 reflects the Company’s nonconvertible borrowing rate when
 interest expense is recognized in subsequent periods. The amount
 recorded as debt is based on the fair value of the debt component
 as a standalone instrument, determined using an average interest
 rate for similar nonconvertible debt issued by entities with credit
 ratings comparable to the Company’s at the time of issuance.
 The difference between the debt recorded at inception and its
 principal amount is to be accreted to principal through interest
 expense through the estimated life of the note.

[0001193125-18-055988:notes:140]
Value
 Added and Sales Tax Collected from Customers

[0001193125-18-055988:notes:141]
As a part of
 the Company’s normal course of business, value added and
 sales taxes are collected from customers. Such taxes collected are
 remitted, in a timely manner, to the appropriate governmental tax
 authority on behalf of the customer. The Company’s policy is
 to present revenue and costs, net of value added and sales
 taxes.

[0001193125-18-055988:notes:142]
Fair
 Value Measures

[0001193125-18-055988:notes:143]
The Company
 measures at fair value certain of its financial and non-financial assets and liabilities
 by using a fair value hierarchy that prioritizes the inputs to
 valuation techniques used to measure fair value. Fair value is the
 price that would be received to sell an asset or paid to transfer a
 liability in an orderly transaction between market participants at
 the measurement date, essentially an exit price, based on the
 highest and best use of the asset or liability. The levels of the
 fair value hierarchy are:

[0001193125-18-055988:notes:144]
Level 1
 — Quoted market prices in active markets for identical assets
 or liabilities;

[0001193125-18-055988:notes:145]
Level 2
 — Significant other observable inputs (e.g., quoted prices
 for similar items in active markets, quoted prices for identical or
 similar items in markets that are not active, inputs other than
 quoted prices that are observable, such as interest rate and yield
 curves, and market-corroborated inputs); and

[0001193125-18-055988:notes:146]
Level 3
 — Unobservable inputs in which there is little or no market
 data, which require the reporting unit to develop its own
 assumptions.

[0001193125-18-055988:notes:147]
Environmental Accrual

[0001193125-18-055988:notes:148]
Accruals for
 estimated costs for environmental obligations generally are
 recognized no later than the date when the Company identifies what
 cleanup measures, if any, are likely to be required to address the
 environmental condition. Included in such obligations are the
 estimated direct costs to investigate and address the conditions,
 and the associated engineering, legal and consulting costs. In
 making these estimates, the Company considers information that is
 currently available, existing technology, enacted laws and
 regulations, and its estimates of the timing of the required
 remedial actions. Such accruals are initially measured on a
 discounted basis — and are adjusted as further information
 becomes available or circumstances change — and are accreted
 to the payable amount over time.

[0001193125-18-055988:notes:149]
Comprehensive Income

[0001193125-18-055988:notes:150]
Comprehensive
 income includes changes to equity accounts that were not the result
 of transactions with stockholders. Comprehensive income is
 comprised of net income (loss), changes in the cumulative foreign
 currency translation adjustments and realized and unrealized gains
 or losses on hedged derivative instruments.

[0001193125-18-055988:notes:151]
Noncontrolling Interest Holdings

[0001193125-18-055988:notes:152]
Noncontrolling
 interest consisted of a 5% equity interest in a manufacturing
 facility in Huiyang, China which was acquired along with other
 assets and liabilities of Viasystems Group Inc. (Viasystems).
 During the fourth quarter of 2017, the Company purchased the 5%
 equity interest from the noncontrolling interest holder. See Note
 21.

[0001193125-18-055988:notes:153]
Loss
 Contingencies

[0001193125-18-055988:notes:154]
The Company
 establishes an accrual for an estimated loss contingency when it is
 both probable that an asset has been impaired or that a liability
 has been incurred and the amount of the loss can be reasonably
 estimated. Any legal fees expected to be incurred in connection
 with a contingency are expensed as incurred.


## us-gaap:SummaryOfIncomeTaxHolidayTextBlock

[0001193125-18-055988:notes:155]
The HNTE status
 as well as enhanced research and development (R&D) deductions
 decreased Chinese taxes. HNTE and R&D benefit and effect on
 earnings per share are as follows:

[0001193125-18-055988:notes:156]
|  |  | For the Year Ended |  |
|  |  | January 1, 2018 |  |  | January 2, 2017 |  |  | December 28, 2015 |  |
|  |  | (In thousands, except per share amounts) |  |
| HNTE and R&D benefits |  | $ | 11,935 |  |  | $ | 7,666 |  |  | $ | 7,600 |  |
| Basic shares |  |  | 101,580 |  |  |  | 100,099 |  |  |  | 92,675 |  |
| Diluted shares |  |  | 132,476 |  |  |  | 101,482 |  |  |  | 92,675 |  |
| Increases earnings (decreases losses) per share: |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  | $ | 0.12 |  |  | $ | 0.08 |  |  | $ | (0.08 | ) |
| Diluted |  | $ | 0.09 |  |  | $ | 0.08 |  |  | $ | (0.08 | ) |


## us-gaap:AdditionalFinancialInformationDisclosureTextBlock

[0001193125-18-055988:notes:157]
| (5) | Composition of Certain Consolidated Financial Statement Captions |

[0001193125-18-055988:notes:158]
|  |  | As of |  |
|  |  | January 1, 2018 |  |  | January 2, 2017 |  |
|  |  | (In thousands) |  |
| Inventories: |  |  |  |  |
| Raw materials |  | $ | 75,835 |  |  | $ | 73,497 |  |
| Work-in-process |  |  | 120,031 |  |  |  | 105,094 |  |
| Finished goods |  |  | 98,722 |  |  |  | 90,621 |  |
|  |  | $ | 294,588 |  |  | $ | 269,212 |  |
| Property, plant and equipment, net: |  |  |  |  |  |  |  |  |
| Land and land use rights |  | $ | 70,681 |  |  | $ | 69,487 |  |
| Buildings and improvements |  |  | 506,394 |  |  |  | 436,822 |  |
| Machinery and equipment |  |  | 1,243,456 |  |  |  | 1,053,267 |  |
| Construction-in-progress, furniture and fixtures and other |  |  | 51,865 |  |  |  | 54,521 |  |
|  |  |  | 1,872,396 |  |  |  | 1,614,097 |  |
| Less: Accumulated depreciation |  |  | (815,551 | ) |  |  | (647,459 | ) |
|  |  | $ | 1,056,845 |  |  | $ | 966,638 |  |
| Other accrued liabilities: |  |  |  |  |  |  |  |  |
| Interest |  | $ | 6,297 |  |  | $ | 927 |  |
| Other |  |  | 108,388 |  |  |  | 96,275 |  |
|  |  | $ | 114,685 |  |  | $ | 97,202 |  |

[0001193125-18-055988:notes:159]
In 2017, the
 Company sold buildings and related land and land use rights
 associated with the Cleveland, Ohio and Hong Kong facilities with
 an aggregate carrying value of $23,397. The buildings and related
 land and land use rights were classified as assets held for sale at
 January 2, 2017 and included in prepaids and other current
 assets in the consolidated balance sheets.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001193125-18-055988:notes:160]
| (9) | Income Taxes |

[0001193125-18-055988:notes:161]
The components
 of income (loss) before income taxes for the years ended
 January 1, 2018, January 2, 2017 and
 December 28, 2015 are:

[0001193125-18-055988:notes:162]
|  |  | For the Year Ended |  |
|  |  | January 1, 2018 |  |  | January 2, 2017 |  |  | December 28, 2015 |  |
|  |  | (In thousands) |  |
| United States |  | $ | (4,178 | ) |  | $ | (85,323 | ) |  | $ | (104,068 | ) |
| Foreign |  |  | 144,136 |  |  |  | 152,325 |  |  |  | 113,044 |  |
| Income before income taxes |  | $ | 139,958 |  |  | $ | 67,002 |  |  | $ | 8,976 |  |

[0001193125-18-055988:notes:163]
The Company
 expects its earnings attributable to foreign subsidiaries will be
 indefinitely reinvested outside of the U.S., except as noted below
 and, therefore, no deferred tax liabilities for U.S. income taxes
 on undistributed earnings are recorded. The undistributed earnings
 of the foreign subsidiaries amounted to approximately $836,309 as
 of January 1, 2018. The determination of the unrecognized
 deferred tax liability related to these undistributed earnings is
 not practicable. Foreign earnings from certain subsidiaries may be
 repatriated to the ultimate parent holding company located in the
 Cayman Islands, and therefore, a deferred tax liability of
 approximately $8,977 for the foreign tax impact has been recorded
 on the undistributed earnings of these subsidiaries.

[0001193125-18-055988:notes:164]
The following
 is a reconciliation of the provision for income taxes at the
 statutory federal income tax rate compared to the Company’s
 provision for income taxes for the years ended January 1,
 2018, January 2, 2017 and December 28,
 2015:

[0001193125-18-055988:notes:165]
|  |  | For the Year Ended |  |
|  |  | January 1, 2018 |  |  | January 2, 2017 |  |  | December 28, 2015 |  |
|  |  | (In thousands) |  |
| Statutory federal income tax |  | $ | (48,985 | ) |  | $ | (22,780 | ) |  | $ | (3,052 | ) |
| State income taxes, net of federal benefit and state tax credits |  |  | (462 | ) |  |  | 906 |  |  |  | (345 | ) |
| Foreign deemed dividends |  |  | (457 | ) |  |  | (4,585 | ) |  |  | (5,691 | ) |
| Acquisition related expenses |  |  | — |  |  |  | (591 | ) |  |  | (7,692 | ) |
| Intercompany profit in inventory elimination |  |  | (743 | ) |  |  | (335 | ) |  |  | 596 |  |
| Permanently reinvested earnings assertion |  |  | — |  |  |  | — |  |  |  | 8,281 |  |
| Tax Act deferred tax revaluation |  |  | (59,228 | ) |  |  | — |  |  |  | — |  |
| Foreign tax differential on foreign earnings |  |  | 30,412 |  |  |  | 17,530 |  |  |  | 15,543 |  |
| Change in valuation allowance |  |  | 66,716 |  |  |  | (19,119 | ) |  |  | (39,148 | ) |
| Uncertain tax positions |  |  | (3,992 | ) |  |  | (3,464 | ) |  |  | (3,911 | ) |
| Federal research and development credits |  |  | 1,270 |  |  |  | 1,270 |  |  |  | 1,270 |  |
| Other |  |  | 238 |  |  |  | (259 | ) |  |  | (445 | ) |
| Total provision for income taxes |  | $ | (15,231 | ) |  | $ | (31,427 | ) |  | $ | (34,594 | ) |

[0001193125-18-055988:notes:166]
Deferred income
 taxes reflect the net tax effects of temporary differences between
 the carrying amounts of assets and liabilities for financial
 reporting purposes and the amounts used for income tax purposes.
 The significant components of the net deferred income tax assets as
 of January 1, 2018 and January 2, 2017 are as
 follows:

[0001193125-18-055988:notes:167]
|  |  | As of |  |
|  |  | January 1, 2018 |  |  | January 2, 2017 |  |
|  |  | (In thousands) |  |
| Deferred income tax assets: |  |  |  |  |  |  |  |  |
| Net operating loss carryforwards |  | $ | 143,095 |  |  | $ | 212,553 |  |
| Reserves and accruals |  |  | 23,655 |  |  |  | 32,420 |  |
| Tax credit carryforwards |  |  | 27,012 |  |  |  | 18,148 |  |
| Stock-based compensation |  |  | 5,099 |  |  |  | 4,965 |  |
| Original issue discount on convertible senior notes |  |  | 7,345 |  |  |  | 15,329 |  |
| Property, plant and equipment |  |  | 24,170 |  |  |  | 13,398 |  |
| Other deferred income tax assets |  |  | 1,282 |  |  |  | 2,036 |  |
|  |  |  | 231,658 |  |  |  | 298,849 |  |
| Less: valuation allowance |  |  | (167,238 | ) |  |  | (221,951 | ) |
|  |  |  | 64,420 |  |  |  | 76,898 |  |
| Deferred income tax liabilities: |  |  |  |  |  |  |  |  |
| Discount on convertible senior notes |  |  | (6,413 | ) |  |  | (13,410 | ) |
| Repatriation of foreign earnings |  |  | (8,977 | ) |  |  | (6,903 | ) |
| Property, plant and equipment basis differences |  |  | (33,661 | ) |  |  | (32,582 | ) |
| Goodwill and intangible amortization |  |  | (19,400 | ) |  |  | (36,097 | ) |
| Other deferred income tax liabilities |  |  | (828 | ) |  |  | (1,955 | ) |
| Net deferred income tax liabilities |  | $ | (4,859 | ) |  | $ | (14,049 | ) |
| Deferred income tax liabilities, net: |  |  |  |  |  |  |  |  |
| Current deferred income taxes |  | $ | — |  |  | $ | — |  |
| Noncurrent deferred income taxes |  |  | (4,859 | ) |  |  | (14,049 | ) |

[0001193125-18-055988:notes:168]
As of
 January 1, 2018, the Company had the following net operating
 loss (NOL) carryforwards: $500,542 in the U.S. for federal,
 $496,369 in various U.S. states, $52,348 in China, and $34,212 in
 Hong Kong. The U.S. federal NOLs expire in 2018 through 2036, the
 various U.S. states’ NOLs expire in 2018 through 2036, the
 China NOLs expire in 2018 through 2022, and the Hong Kong NOLs
 carryforward indefinitely. Further, the Company’s tax credits
 were approximately $32,480 of which $8,021 carryforward
 indefinitely.

[0001193125-18-055988:notes:169]
In connection
 with the Company’s acquisition of Viasystems, there was more
 than a 50% change in ownership under Section 382 of the
 Internal Revenue Code of 1986, as amended, and regulations issued
 there under. As a consequence, the utilization of the acquired
 Viasystems U.S. NOLs is limited to approximately $9,826 per year.
 In addition, the Company recognized certain gains built in at the
 time of the ownership change, which increase the limitation by
 approximately $47,463 for each of the first 5 years after the
 acquisition. Any unused limitation in a year can be carried over to
 succeeding years.

[0001193125-18-055988:notes:170]
A valuation
 allowance is provided when it is more likely than not that all or
 some portion of the deferred income tax assets will not be
 realized. Based on historical performance and future expectations,
 the Company has a full valuation allowance on its net U.S. deferred
 tax assets. Certain subsidiaries within China continue to have NOL
 carryforwards in various tax jurisdictions that the Company has
 determined are not more likely than not to be utilized. As a
 result, a full valuation allowance has been recorded for these
 subsidiaries at January 1, 2018. For the remaining net
 deferred income tax asset, management has determined that it is
 more likely than not that the results of future operations will
 generate sufficient taxable income to realize the net deferred tax
 asset.

[0001193125-18-055988:notes:171]
The following
 summarizes the activity in the Company’s valuation allowance
 for the years ended January 1, 2018, January 2, 2017
 and December 28, 2015:

[0001193125-18-055988:notes:172]
|  |  | For the Year Ended |  |
|  |  | January 1, 2018 |  |  | January 2, 2017 |  |  | December 28, 2015 |  |
|  |  | (In thousands) |  |
| Balance at beginning of year |  | $ | 221,951 |  |  | $ | 234,192 |  |  | $ | 38,839 |  |
| (Reduction) additions related to acquisition |  |  | — |  |  |  | (18,234 | ) |  |  | 177,699 |  |
| Additions charged to expense |  |  | 4,515 |  |  |  | 5,993 |  |  |  | 39,149 |  |
| Reduction charged to expense — Tax Act |  |  | (59,228 | ) |  |  | — |  |  |  | — |  |
| Reduction related to sale of foreign subsidiary |  |  | — |  |  |  | — |  |  |  | (21,495 | ) |
| Balance at end of year |  | $ | 167,238 |  |  | $ | 221,951 |  |  | $ | 234,192 |  |

[0001193125-18-055988:notes:173]
Certain
 entities within China qualified for the high and new technology
 enterprise (HNTE) status enabling those entities to enjoy certain
 benefits, which were effective for the years ended January 1,
 2018, January 2, 2017 and December 28, 2015. The
 HNTE status as well as enhanced research and development (R&D)
 deductions decreased Chinese taxes. HNTE and R&D benefit and
 effect on earnings per share are as follows:

[0001193125-18-055988:notes:174]
HNTE status
 expires at various dates through 2018, but the Company expects to
 continue to file for renewal of such HNTE status for the
 foreseeable future.

[0001193125-18-055988:notes:175]
A
 reconciliation of the beginning and ending amount of unrecognized
 tax benefits, exclusive of accrued interest and penalties, is as
 follows:

[0001193125-18-055988:notes:176]
|  |  | For the Year Ended |  |
|  |  | January 1, 2018 |  |  | January 2, 2017 |  |  | December 28, 2015 |  |
|  |  | (In thousands) |  |
| Beginning balance |  | $ | 39,727 |  |  | $ | 15,404 |  |  | $ | 2,441 |  |
| Additions related to acquisition |  |  | — |  |  |  | 22,182 |  |  |  | 11,293 |  |
| Additions based on tax positions related to the current year |  |  | 1,965 |  |  |  | 5,389 |  |  |  | 3,349 |  |
| Additions for tax positions of prior years |  |  | 1,661 |  |  |  | 1,545 |  |  |  | 14 |  |
| Reductions for tax positions of prior years |  |  | (3,846 | ) |  |  | (2,286 | ) |  |  | (1,371 | ) |
| Lapse of statute of limitations |  |  | (666 | ) |  |  | (2,507 | ) |  |  | (322 | ) |
| Ending balance |  | $ | 38,841 |  |  | $ | 39,727 |  |  | $ | 15,404 |  |

[0001193125-18-055988:notes:177]
As of
 January 1, 2018 and January 2, 2017, the Company recorded
 unrecognized tax benefits of $29,033 and $28,037, respectively, as
 well as interest and penalties of $12,679 and $10,754,
 respectively, to other long-term liabilities. The Company has also
 recorded unrecognized tax benefits of $9,808 and $11,689 against
 certain deferred tax assets as of January 1, 2018 and
 January 2, 2017, respectively. The amount of unrecognized tax
 benefits that would, if recognized, reduce the Company’s
 effective income tax rate in any future periods is $41,712
 including interest and penalties. The Company expects its
 unrecognized tax benefits to decrease by $774 along with related
 interest of $1,288 over the next 12 months due to expiring
 statutes.

[0001193125-18-055988:notes:178]
As of
 January 1, 2018, the Company is subject to (i) U.S.
 federal income tax examination and / or NOL adjustment for tax
 years from 1999 to 2017, (ii) state and local income tax
 examination for tax years 1999 to 2017, and (iii) foreign
 income tax examinations generally for tax years from 2007 to
 2017.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0001193125-18-055988:notes:179]
| (1) | Nature of Operations and Basis of Presentation |

[0001193125-18-055988:notes:180]
TTM
 Technologies, Inc. (the Company or TTM) is a leading global printed
 circuit board (PCB) manufacturer, focusing on quick-turn and volume
 production of technologically complex PCBs and electro-mechanical
 solutions (E-M Solutions).
 The Company provides time-to-market and volume
 production of advanced technology products and offers a
 one-stop manufacturing
 solution to customers from engineering support to prototype
 development through final mass production. This one-stop manufacturing solution enables
 the Company to align technology developments with the diverse needs
 of the Company’s customers and to enable them to reduce the
 time required to develop new products and bring them to
 market.

[0001193125-18-055988:notes:181]
The Company
 serves a diversified customer base in various markets throughout
 the world, including aerospace and defense, automotive components,
 smartphones and touchscreen tablets, high-end computing, medical, industrial
 and instrumentation related products, as well as
 networking/communications infrastructure products. The
 Company’s customers include both original equipment
 manufacturers (OEMs) and electronic manufacturing services (EMS)
 providers.

[0001193125-18-055988:notes:182]
The Company
 operates on a 52 or 53 week year ending on the Monday nearest
 December 31. Fiscal 2017 and 2015 were 52 weeks ended on
 January 1, 2018 and December 28, 2015, respectively.
 Fiscal 2016 consisted of 53 weeks ended on January 2, 2017
 with the additional week included in the fourth quarter. All
 references to years relate to fiscal years unless otherwise
 noted.


## us-gaap:ScheduleOfEarningsPerShareBasicAndDilutedTableTextBlock

[0001193125-18-055988:notes:183]
The following
 is a reconciliation of the numerator and denominator used to
 calculate basic earnings (loss) per share and diluted earnings
 (loss) per share for the years ended January 1,
 2018, January 2, 2017 and December 28,
 2015:

[0001193125-18-055988:notes:184]
|  |  | For the Year Ended |  |
|  |  | January 1, 2018 |  |  | January 2, 2017 |  |  | December 28, 2015 |  |
|  |  | (In thousands, except per share amounts) |  |
| Basic earnings (loss): |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic earnings (loss) |  | $ | 124,214 |  |  | $ | 34,861 |  |  | $ | (25,882 | ) |
| Diluted earnings (loss): |  |  |  |  |  |  |  |  |  |  |  |  |
| Net income (loss) attributable to TTM Technologies, Inc. stockholders |  | $ | 124,214 |  |  | $ | 34,861 |  |  | $ | (25,882 | ) |
| Interest expense from convertible senior notes, net of tax |  |  | 13,803 |  |  |  | — |  |  |  | — |  |
| Diluted earnings (loss) |  | $ | 138,017 |  |  | $ | 34,861 |  |  | $ | (25,882 | ) |
| Basic shares |  |  | 101,580 |  |  |  | 100,099 |  |  |  | 92,675 |  |
| Dilutive effect of performance-based restricted stock units, restricted stock units and stock options |  |  | 2,157 |  |  |  | 1,383 |  |  |  | — |  |
| Dilutive effect of outstanding warrants |  |  | 2,799 |  |  |  | — |  |  |  | — |  |
| Dilutive effect of assumed conversion of convertible senior notes outstanding |  |  | 25,940 |  |  |  | — |  |  |  | — |  |
| Diluted shares |  |  | 132,476 |  |  |  | 101,482 |  |  |  | 92,675 |  |
| Earnings (loss) per share attributable to TTM Technologies, Inc. stockholders: |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  | $ | 1.22 |  |  | $ | 0.35 |  |  | $ | (0.28 | ) |
| Diluted |  | $ | 1.04 |  |  | $ | 0.34 |  |  | $ | (0.28 | ) |


## us-gaap:ScheduleofFiniteLivedIntangibleAssetsFutureAmortizationExpenseTableTextBlock

[0001193125-18-055988:notes:185]
Estimated
 aggregate amortization for definite-lived intangible assets for the
 next five years and thereafter is as follows:

[0001193125-18-055988:notes:186]
|  |  | (In thousands) |  |
| 2018 |  | $ | 22,863 |  |
| 2019 |  |  | 18,746 |  |
| 2020 |  |  | 18,746 |  |
| 2021 |  |  | 14,921 |  |
| 2022 |  |  | 12,329 |  |
| Thereafter |  |  | 15,345 |  |
|  |  | $ | 102,950 |  |


## us-gaap:ScheduleOfGoodwillTextBlock

[0001193125-18-055988:notes:187]
As of
 January 1, 2018 and January 2, 2017, goodwill was as
 follows:

[0001193125-18-055988:notes:188]
|  |  | Total |  |
|  |  | (In thousands) |  |
| Balance as of December 28, 2015 |  |  |  |  |
| Goodwill |  | $ | 518,390 |  |
| Accumulated impairment losses |  |  | (171,400 | ) |
|  |  |  | 346,990 |  |
| Goodwill recognized during the year |  |  | 25,624 |  |
| Foreign currency translation adjustment |  |  | (5 | ) |
| Balance as of January 2, 2017 |  |  |  |  |
| Goodwill |  | $ | 544,009 |  |
| Accumulated impairment losses |  |  | (171,400 | ) |
|  |  |  | 372,609 |  |
| Foreign currency translation adjustment |  |  | (38 | ) |
| Balance as of January 1, 2018 |  |  |  |  |
| Goodwill |  | $ | 543,971 |  |
| Accumulated impairment losses |  |  | (171,400 | ) |
|  |  | $ | 372,571 |  |


## us-gaap:ScheduleOfMaturitiesOfLongTermDebtTableTextBlock

[0001193125-18-055988:notes:189]
The fiscal
 calendar maturities of long-term debt through 2022 and thereafter
 are as follows:

[0001193125-18-055988:notes:190]
|  |  | (In thousands) |  |
| 2018 |  | $ | 4,578 |  |
| 2019 |  |  | 3,032 |  |
| 2020 |  |  | 300,919 |  |
| 2021 |  |  | 4,375 |  |
| 2022 |  |  | 3,500 |  |
| Thereafter |  |  | 706,625 |  |
|  |  | $ | 1,023,029 |  |


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001193125-18-055988:notes:191]
| (3) | Acquisitions |

[0001193125-18-055988:notes:192]
Definitive
 Stock Purchase Agreement for the Acquisition of Anaren,
 Inc.

[0001193125-18-055988:notes:193]
On
 December 1, 2017, the Company entered into a definitive stock
 purchase agreement with Anaren Holdings, LLC pursuant to which the
 Company agreed to purchase all of the issued and outstanding common
 stock of Anaren Holding Corp., for total consideration of $775,000
 in cash subject to customary working capital and certain other
 adjustments. Other than the equity interests of Anaren, Inc.
 (Anaren), Anaren Holding Corp. has no material assets or
 liabilities and has no material independent operations. Anaren is a
 leading provider of mission-critical radio frequency (RF)
 solutions, microelectronics, and microwave components and
 assemblies for the wireless infrastructure and space and defense
 electronics markets. Anaren’s microwave products are used in
 wireless communication systems including wireless infrastructure,
 wireless consumer and medical applications, as well as advanced
 radar, beam-forming, jamming, motion control and receiver
 applications for the space and defense markets, covering a broad
 range of frequencies and power levels. Its Integrated Radio module
 product lines provide proprietary low power RF monitoring solutions
 deployable in a wide variety of end market applications. The
 acquisition of Anaren will significantly increase the
 Company’s aerospace and defense design capability with
 particular focus on RF products, deepen our customer engagements in
 aerospace and defenses and networking/communications and complement
 the Company’s focus on high technology PCB products
 manufacturing. The Company expects to complete the acquisition in
 the first half of 2018.

[0001193125-18-055988:notes:194]
In
 conjunction with the pending acquisition of Anaren, the Company has
 received commitments to fund a $700,000 senior secured incremental
 term loan (the Incremental Facility). Upon the consummation of the
 acquisition of Anaren, the Company will use the borrowings from the
 Incremental Facility and cash on hand to finance the acquisition.
 Also see Note 22 regarding a subsequent event.

[0001193125-18-055988:notes:195]
Bank fees and
 legal, accounting, and other professional service costs associated
 with the ongoing acquisition of Anaren of $2,266 has been expensed
 and recorded as general and administrative expense in the
 consolidated statements of operations for the year ended
 January 1, 2018.

[0001193125-18-055988:notes:196]
Acquisitions of Viasystems

[0001193125-18-055988:notes:197]
On
 May 31, 2015, the Company completed the acquisition of
 Viasystems, for total consideration of $248,824 in cash and 15,082
 shares of TTM common stock with a fair value of $149,006, and
 thereby acquired all of the outstanding shares of capital stock and
 other equity rights of Viasystems. Additionally, in connection with
 the completion of the acquisition, the Company assumed and
 refinanced Viasystems’ debt, which was approximately $669,024
 as of May 31, 2015. Viasystems was a worldwide provider of
 complex multi-layer rigid, flexible, and rigid-flex PCBs and custom
 electronic assemblies.

[0001193125-18-055988:notes:198]
Bank fees and
 legal, accounting, and other professional service costs associated
 with the acquisition of Viasystems of $1,688 and $34,448 for the
 years ended January 2, 2017 and December 28, 2015,
 respectively, have been expensed and recorded as general and
 administrative expense in the consolidated statements of
 operations. There were no bank fees or legal, accounting, and other
 professional service costs associated with the acquisition of
 Viasystems for the year ended January 1, 2018.


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0001193125-18-055988:notes:199]
| (10) | Accumulated Other Comprehensive Income |


## us-gaap:FairValueAssetsMeasuredOnNonrecurringBasisTextBlock

[0001193125-18-055988:notes:200]
For the year
 ended January 2, 2017, the following assets were measured at
 fair value on a nonrecurring basis using the type of inputs
 shown:

[0001193125-18-055988:notes:201]
|  |  |  |  |  | Fair Value Measurements Using: |  |
|  |  | January 2, 2017 |  |  | Level 1 Inputs |  |  | Level 2 Inputs |  |  | Level 3 Inputs |  |  | Total Losses for the year Ended January 2, 2017 |  |
|  |  | (In thousands) |  |
| Long-lived assets held and use |  | $ | 2,254 |  |  | $ | — |  |  | $ | — |  |  | $ | 2,254 |  |  | $ | 1,953 |  |
| Assets held for sale |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 1,393 |  |
|  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | $ | 3,346 |  |


## us-gaap:FairValueLiabilitiesMeasuredOnRecurringBasisTextBlock

[0001193125-18-055988:notes:202]
The carrying
 amount and estimated fair value of the Company’s financial
 instruments as of January 1, 2018 and January 2, 2017
 were as follows:

[0001193125-18-055988:notes:203]
|  |  | January 1, 2018 |  |  | January 2, 2017 |  |
|  |  | Carrying Amount |  |  | Fair Value |  |  | Carrying Amount |  |  | Fair Value |  |
|  |  | (In thousands) |  |
| Term Loan due September 2024 |  | $ | 344,646 |  |  | $ | 346,943 |  |  |  | — |  |  |  | — |  |
| Term Loan due May 2021 |  |  | — |  |  |  | — |  |  | $ | 699,023 |  |  | $ | 708,750 |  |
| Senior Notes due October 2025 |  |  | 368,218 |  |  |  | 384,769 |  |  |  | — |  |  |  | — |  |
| Convertible Senior Notes |  |  | 218,274 |  |  |  | 429,199 |  |  |  | 208,861 |  |  |  | 380,875 |  |
| ABL Revolving Loans |  |  | 47,000 |  |  |  | 47,000 |  |  |  | 110,000 |  |  |  | 110,000 |  |
| Capital Lease |  |  | 1,919 |  |  |  | 1,919 |  |  |  | 1,798 |  |  |  | 1,798 |  |


## us-gaap:IntangibleAssetsDisclosureTextBlock

[0001193125-18-055988:notes:204]
| (7) | Definite-lived Intangibles |

[0001193125-18-055988:notes:205]
As of
 January 1, 2018 and January 2, 2017, the components of
 definite-lived intangibles were as follows:

[0001193125-18-055988:notes:206]
|  |  | Gross Amount |  |  | Accumulated Amortization |  |  | Foreign Currency Translation Adjustment |  |  | Net Carrying Amount |  |  | Weighted Average Amortization Period |  |
|  |  | (In thousands) |  |  | (years) |  |
| January 1, 2018: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Customer relationships |  | $ | 203,563 |  |  | $ | (101,089 | ) |  | $ | 72 |  |  | $ | 102,546 |  |  |  | 8.1 |  |
| Technology |  |  | 3,000 |  |  |  | (2,596 | ) |  |  | — |  |  |  | 404 |  |  |  | 3.0 |  |
|  |  | $ | 206,563 |  |  | $ | (103,685 | ) |  | $ | 72 |  |  | $ | 102,950 |  |  |  |  |  |
| January 2, 2017: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Customer relationships |  | $ | 203,563 |  |  | $ | (78,473 | ) |  | $ | 119 |  |  | $ | 125,209 |  |  |  | 8.1 |  |
| Technology |  |  | 3,000 |  |  |  | (1,596 | ) |  |  | — |  |  |  | 1,404 |  |  |  | 3.0 |  |
|  |  | $ | 206,563 |  |  | $ | (80,069 | ) |  | $ | 119 |  |  | $ | 126,613 |  |  |  |  |  |

[0001193125-18-055988:notes:207]
The
 January 1, 2018 and January 2, 2017 definite-lived
 intangible balances include foreign currency translation
 adjustments related to foreign subsidiaries with functional
 currencies other than the U.S. Dollar.

[0001193125-18-055988:notes:208]
Definite-lived
 intangibles are generally amortized using the straight line method
 of amortization over the useful life, with the exception of certain
 customer relationship intangibles, which are amortized using an
 accelerated method of amortization based on estimated cash flows.
 Amortization expense was $23,634, $24,252, and $18,888 for the
 years ended January 1, 2018, January 2, 2017 and
 December 28, 2015, respectively.


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0001193125-18-055988:notes:209]
| (15) | Employee Benefit and Deferred Compensation Plans |

[0001193125-18-055988:notes:210]
As of
 January 1, 2018, the Company has four separate retirement
 benefit plans: two in North America and two in China. In North
 America, the Company has savings plans (the Savings Plans) in which
 eligible full-time employees can participate and contribute a
 percentage of compensation subject to the maximum allowed by the
 tax agencies. The Savings Plans provides for a partial match by the
 employer. In China, the Company contributes to either separate
 trust-administered funds or various government-sponsored pension
 plans on a mandatory basis. For all retirement plans, the Company
 has no further payment obligation once the required contributions
 have been made. The Company recorded contributions to retirement
 benefit plans of $42,461, $36,172 and $35,427 during the years
 ended January 1, 2018, January 2, 2017 and
 December 28, 2015, respectively.

[0001193125-18-055988:notes:211]
The Company also
 maintains a deferred compensation plan (the Compensation Plan). The
 Compensation Plan is an unfunded, nonqualified deferred
 compensation plan and is limited to selected employees, including
 our named executive officers and our directors. The Compensation
 Plan allows participants to defer up to 100% of their annual bonus
 and between 5% and 100% of their annual director fees. Amounts
 deferred under the Compensation Plan will be credited to accounts
 maintained by the Company for each participant and will be credited
 or debited with the participant’s proportionate share of any
 gains or losses attributable to the performance of investment
 options selected by the participant.


## us-gaap:ConcentrationRiskDisclosureTextBlock

[0001193125-18-055988:notes:212]
(11) Significant
 Customers and Concentration of Credit Risk

[0001193125-18-055988:notes:213]
In the normal
 course of business, the Company extends credit to its customers.
 Most customers to which the Company extends credit are located
 outside the United States. The Company performs ongoing credit
 evaluations of customers, does not require collateral, and
 considers the credit risk profile of the entity from which the
 receivable is due in further evaluating collection risk.

[0001193125-18-055988:notes:214]
The
 Company’s customers include both OEMs and EMS companies. The
 Company’s OEM customers often direct a significant portion of
 their purchases through EMS companies. While the Company’s
 customers include both OEM and EMS providers, the Company measures
 customer concentration based on OEM companies, as they are the
 ultimate end customers.

[0001193125-18-055988:notes:215]
For the years
 ended January 1, 2018, January 2, 2017 and
 December 28, 2015, one customer accounted for approximately
 20%, 15% and 20%, respectively, of the Company’s net sales.
 There were no other customers that accounted for 10% or more of net
 sales for the years ended January 1,
 2018, January 2, 2017 and December 28,
 2015.


## us-gaap:EarningsPerShareTextBlock

[0001193125-18-055988:notes:216]
| (19) | Earnings Per Share |

[0001193125-18-055988:notes:217]
For the years
 ended January 1, 2018 and January 2, 2017, PRUs, RSUs and
 stock options to purchase 255 and 892 shares of common stock,
 respectively, were not considered in calculating diluted earnings
 per share because the options’ exercise prices or the total
 expected proceeds under the treasury stock method for
 performance-based stock units, restricted stock units or stock
 options was greater than the average market price of common shares
 during the applicable year and, therefore, the effect would be
 anti-dilutive.

[0001193125-18-055988:notes:218]
For the year
 ended December 28, 2015, potential shares of common stock,
 consisting of stock options to purchase approximately 420 shares of
 common stock at exercise prices ranging from $5.78 to $16.82 per
 share, 2,294 RSUs, and 572 PRUs were not included in the
 computation of diluted earnings per share because the Company
 incurred a net loss from operations and, as a result, the impact
 would be anti-dilutive.

[0001193125-18-055988:notes:219]
For the years
 ended January 2, 2017 and December 28, 2015, the effect
 of shares of common stock related to the Company’s
 convertible senior notes were not included in the computation of
 dilutive earnings per share as the impact would be
 anti-dilutive.

[0001193125-18-055988:notes:220]
Outstanding
 warrants for the years ended January 2, 2017 and
 December 28, 2015, to purchase common stock were not included
 in the computation of dilutive earnings per share because the
 strike price of the warrants to purchase the Company’s common
 stock were greater than the average market price of common shares
 during the applicable year, and therefore, the effect would be
 anti-dilutive.


## us-gaap:FairValueDisclosuresTextBlock

[0001193125-18-055988:notes:221]
(12) Fair Value
 Measures

[0001193125-18-055988:notes:222]
The Company
 measures at fair value its financial and non-financial assets by using a fair
 value hierarchy that prioritizes the inputs to valuation techniques
 used to measure fair value. Fair value is the price that would be
 received to sell an asset or paid to transfer a liability in an
 orderly transaction between market participants at the measurement
 date, essentially an exit price, based on the highest and best use
 of the asset or liability.

[0001193125-18-055988:notes:223]
The fair value
 of the long-term debt was estimated based on quoted market prices
 or discounting the debt over its life using current market rates
 for similar debt as of January 1, 2018 and January 2,
 2017, which are considered Level 2 inputs.

[0001193125-18-055988:notes:224]
The fair value
 of the convertible senior notes was estimated based on quoted
 market prices of the securities on an active exchange, which are
 considered Level 2 inputs.

[0001193125-18-055988:notes:225]
As of
 January 1, 2018 and January 2, 2017, the Company’s
 other financial instruments also included cash and cash
 equivalents, accounts receivable, accounts payable and equipment
 payables. Due to short-term maturities, the carrying amount of
 these instruments approximates fair value. Our cash and cash
 equivalents at January 1, 2018 consisted of $115,128 held in
 the U.S., with the remaining $294,198 held by foreign
 subsidiaries.

[0001193125-18-055988:notes:226]
The majority of
 the Company’s non-financial assets and liabilities,
 which include goodwill, intangible assets, inventories, and
 property, plant and equipment, are not required to be carried at
 fair value on a recurring basis. However, if certain triggering
 events occur (or are tested at least annually in the case of
 goodwill) such that a non-financial instrument is required
 to be evaluated for impairment, based upon a comparison of the
 non-financial
 instrument’s fair value to its carrying value, an impairment
 is recorded to reduce the carrying value to the fair value, if the
 carrying value exceeds the fair value.

[0001193125-18-055988:notes:227]
There was no
 impairment of long-lived assets recognized in the year ended
 January 1, 2018 or December 28, 2015.

[0001193125-18-055988:notes:228]
The Company has
 capitalized software costs in accordance with U.S. GAAP. During the
 year ended January 2, 2017, the Company determined that
 certain capitalized costs no longer had benefit primarily as a
 result of the Viasystems acquisition. Because the primary
 determination of fair value was based on management’s
 assumptions and estimates of capitalized costs to dispose, the
 resulting fair value is considered a Level 3 input.


## us-gaap:GoodwillDisclosureTextBlock

[0001193125-18-055988:notes:229]
| (6) | Goodwill |

[0001193125-18-055988:notes:230]
Goodwill
 balances include foreign currency translation adjustments related
 to foreign subsidiaries with functional currencies other than the
 U.S. Dollar. All of the Company’s goodwill is included
 as a component of the PCB reportable segment.

[0001193125-18-055988:notes:231]
In the fourth
 quarter of 2017, the Company performed its annual impairment test
 qualitatively and concluded that it was more likely than not that
 there was no impairment to goodwill. The Company will continue to
 evaluate its goodwill on an annual basis during its fourth fiscal
 quarter and whenever events or changes in circumstances —
 such as significant adverse changes in business climate or
 operating results, changes in management strategy, coupled with a
 decline in the market price of our stock and market capitalization
 — indicate that there may be a potential impairment. If
 factors indicate that assets are impaired, we would be required to
 reduce the carrying value of our goodwill and definite-lived
 intangible assets, which may result in an impairment
 charge.

[0001193125-18-055988:notes:232]
During the year
 ended January 2, 2017, the Company finalized the allocation of
 the purchase price associated with the acquisition of Viasystems
 which resulted in an increase in goodwill due to the reassessment
 of product claims and other contingent liabilities, and certain tax
 positions at certain foreign jurisdictions.


## us-gaap:LongTermDebtTextBlock

[0001193125-18-055988:notes:233]
| (8) | Long-term Debt and Letters of Credit |

[0001193125-18-055988:notes:234]
On
 September 28, 2017, the Company entered into a $350,000 Term
 Loan Facility due 2024 (Term Loan Facility), and issued $375,000 of
 Senior Notes due 2025 (Senior Notes). In conjunction with the
 issuance of the Term Loan Facility and Senior Notes, the Company
 repaid in full the remaining outstanding balance of the
 September 27, 2016 Term Loan Credit Agreement (2016 Term Loan)
 and repaid $63,000 on its existing U.S. Asset-Based Lending Credit
 Agreement (U.S. ABL).

[0001193125-18-055988:notes:235]
Term Loan
 Facility

[0001193125-18-055988:notes:236]
The Term Loan
 Facility, of which $3,500 is included in short-term debt and
 $345,625 is included in long-term debt, was issued at a discount at
 99.5% and bears interest, at the Company’s option, at a
 floating rate of LIBOR, plus an applicable interest margin of 2.5%,
 or an alternate base rate, (defined as the greater of the JP Morgan
 prime, the New York Fed bank rate plus 0.9% or LIBOR plus 1.0%),
 subject to a 1.0% floor plus an applicable margin of 1.5%. At
 January 1, 2018 the interest rate on the outstanding
 borrowings under the Term Loan Facility was 4.06%. There is no
 provision, other than an event of default, for the interest margin
 to increase. The Term Loan Facility will mature on
 September 28, 2024. The Term Loan Facility is secured by a
 significant amount of the domestic assets of the Company and a
 pledge of 65% of voting stock of the Company’s first tier
 foreign subsidiaries and is structurally senior to the
 Company’s Senior Notes and Convertible Senior Notes. See
 Senior Notes and Convertible Senior Notes below.

[0001193125-18-055988:notes:237]
The Company is
 required to make scheduled payments of the outstanding Term Loan
 Facility balance on a quarterly basis beginning January 1,
 2018. Based on certain parameters defined in the Term Loan
 Facility, including a First Lien Leverage Ratio, the Company may be
 required to make an additional principal payment on an annual basis
 beginning after fiscal year 2018, if the Company’s First Lien
 Leverage Ratio is greater than 2.0. Any additional annual payments
 or prepayments would reduce future required scheduled payments. Any
 remaining outstanding balances under the Term Loan Facility are due
 at the maturity date of September 28, 2024.

[0001193125-18-055988:notes:238]
Borrowings
 under the Term Loan Facility are subject to certain affirmative and
 negative covenants, including limitations on indebtedness,
 corporate transactions, investments and dispositions, and share
 payments.

[0001193125-18-055988:notes:239]
Senior
 Notes

[0001193125-18-055988:notes:240]
The $375,000 of
 Senior Notes issued, which is included in long-term debt, bear
 interest at a rate of 5.63% per annum. Interest is payable
 semiannually in arrears on April 1 and October 1 of each
 year beginning April 1, 2018. The Senior Notes will mature on
 October 1, 2025.

[0001193125-18-055988:notes:241]
Borrowings
 under the Senior Notes are subject to certain affirmative and
 negative covenants, including limitations on indebtedness,
 corporate transactions, investments and dispositions, and share
 payments.

[0001193125-18-055988:notes:242]
Convertible Senior Notes due 2020

[0001193125-18-055988:notes:243]
The Company
 maintains 1.75% convertible senior notes in the amount of $249,985
 due December 15, 2020. The convertible senior notes bear
 interest at a rate of 1.75% per annum. Interest is payable
 semiannually in arrears on June 15 and December 15 of
 each year. The convertible senior notes are unsecured obligations,
 are subordinated to the Senior Notes above, and would rank equally
 to the Company’s future unsecured senior indebtedness and are
 senior in right of payment to any of the Company’s future
 subordinated indebtedness.

[0001193125-18-055988:notes:244]
Conversion:    At
 any time prior to March 15, 2020, holders may convert their
 convertible senior notes into cash and, if applicable, into shares
 of the Company’s common stock based on a conversion rate of
 103.7613 shares of the Company’s common stock per $1
 principal amount of convertible senior notes, subject to
 adjustment, under the following circumstances: (1) during any
 calendar quarter beginning after March 31, 2015 (and only
 during such calendar quarter), if the last reported sale price of
 our common stock for at least 20 trading days during the 30
 consecutive trading days ending on the last trading day of the
 immediately preceding calendar quarter is greater than or equal to
 130% of the applicable conversion price on each applicable trading
 day of such preceding calendar quarter; (2) during the five
 business day period after any 10 consecutive trading day period in
 which the trading price per note for each day of that 10
 consecutive trading day period was less than 98% of the product of
 the last reported sale price of the Company’s common stock
 and the conversion rate on such day; or (3) upon the
 occurrence of specified corporate transactions described in the
 indenture governing the notes. As of January 1, 2018, the
 conversion criteria had been met allowing holders to give notice of
 conversion in 2017 and the first quarter of 2018.

[0001193125-18-055988:notes:245]
On or after
 March 15, 2020 until the close of business on the third
 scheduled trading day preceding the maturity date, holders may
 convert their notes at any time, regardless of the foregoing
 circumstances. Upon conversion, for each $1 principal amount of
 notes, the Company will pay shares of our common stock, cash or a
 combination of cash and shares of our common stock at its election,
 if applicable, based on a daily conversion value calculated on a
 proportionate basis for each day of the 80 trading day observation
 period. All conversions occurring on the same date or on or after
 March 15, 2020 shall be settled using the same settlement
 method. Additionally, in the event of a fundamental change as
 defined in the indenture governing the notes, or other conversion
 rate adjustments such as share splits or combinations, other
 distributions of shares, cash or other assets to stockholders,
 including self-tender transactions (Other Conversion Rate
 Adjustments), the conversion rate may be modified to adjust the
 number of shares per $1 principal amount of the notes. As of
 January 1, 2018, none of the criteria for a fundamental change
 or a conversion rate adjustment had been met.

[0001193125-18-055988:notes:246]
The maximum
 number of shares issuable upon conversion, including the effect of
 a fundamental change and subject to Other Conversion Rate
 Adjustments, would be 32,423.

[0001193125-18-055988:notes:247]
Note
 Repurchase:    The
 Company is not permitted to redeem the convertible senior notes at
 any time prior to maturity. In the event of a fundamental change or
 certain default events, as defined in the indenture governing the
 notes, holders may require the Company to repurchase for cash all
 or a portion of their convertible senior notes at a price equal to
 100% of the principal amount, plus any accrued and unpaid
 interest.

[0001193125-18-055988:notes:248]
Convertible Note Hedge and Warrant
 Transaction:    In
 connection with the issuance of the convertible senior notes due
 2020, the Company entered into a convertible note hedge and warrant
 transaction (Call Spread Transaction), with respect to the
 Company’s common stock. The convertible note hedge consists
 of the Company’s option to purchase up to 25,939 common stock
 shares at a price of $9.64 per share. The hedge expires on
 December 15, 2020 and can only be executed upon the conversion
 of the above mentioned convertible senior notes due 2020.
 Additionally, the Company sold warrants to purchase 25,940 shares
 of its common stock at a price of $14.26 per share. The warrants
 expire ratably from March 2021 through January 2022. The 2020 Call
 Spread Transaction has no effect on the terms of the convertible
 senior notes due 2020 and reduces potential dilution by effectively
 increasing the conversion price of the convertible senior notes due
 2020 to $14.26 per share of the Company’s common
 stock.

[0001193125-18-055988:notes:249]
The components
 of interest expense resulting from the convertible senior notes for
 the years ended January 1, 2018, January 2, 2017 and
 December 28, 2015 were as follows:

[0001193125-18-055988:notes:250]
|  |  | For the Year Ended |  |
|  |  | January 1, 2018 |  |  | January 2, 2017 |  |  | December 28, 2015 |  |
|  |  | (In thousands) |  |
| Contractual coupon interest |  |  |  |  |  |  |  |  |  |  |  |  |
| Convertible Senior Notes due 2020 |  | $ | 4,375 |  |  | $ | 4,375 |  |  | $ | 4,375 |  |
| Convertible Senior Notes due 2015 |  |  | — |  |  |  | — |  |  |  | 395 |  |
|  |  | $ | 4,375 |  |  | $ | 4,375 |  |  | $ | 4,770 |  |
| Amortization of debt discount |  |  |  |  |  |  |  |  |  |  |  |  |
| Convertible Senior Notes due 2020 |  | $ | 8,570 |  |  | $ | 8,034 |  |  | $ | 7,532 |  |
| Convertible Senior Notes due 2015 |  |  | — |  |  |  | — |  |  |  | 554 |  |
|  |  | $ | 8,570 |  |  | $ | 8,034 |  |  | $ | 8,086 |  |
| Amortization of debt issuance costs |  |  |  |  |  |  |  |  |  |  |  |  |
| Convertible Senior Notes due 2020 |  | $ | 858 |  |  | $ | 805 |  |  | $ | 755 |  |
| Convertible Senior Notes due 2015 |  |  | — |  |  |  | — |  |  |  | 56 |  |
|  |  | $ | 858 |  |  | $ | 805 |  |  | $ | 811 |  |

[0001193125-18-055988:notes:251]
Asset-Based Lending Agreements

[0001193125-18-055988:notes:252]
The Company
 maintains a $200,000 U.S. ABL, and a $150,000 Asia Asset-Based
 Lending Credit Agreement (Asia ABL) (collectively the ABL Revolving
 Loans).

[0001193125-18-055988:notes:253]
The U.S. ABL
 consists of three tranches comprised of a revolving credit facility
 for up to $200,000, a letter of credit facility for up to $50,000,
 and swingline loans for up to $30,000, provided that at no time may
 amounts outstanding under the tranches exceed in aggregate $200,000
 or the applicable borrowing base, which is a percentage of the
 principal amount of Eligible Accounts, as defined in the U.S. ABL
 agreement. Borrowings under the U.S. ABL bear interest at either a
 floating rate of LIBOR plus a margin of 150 basis points or JP
 Morgan Chase Bank’s prime rate plus a margin of 50 basis
 points, at the Company’s option. At January 1, 2018, the
 interest rate on the outstanding borrowings under the U.S. ABL was
 3.06%. The applicable margin can vary based on the remaining
 availability of the facility, from 125 to 175 basis points for
 LIBOR-based loans and from 25 to 75 basis points for JP Morgan
 Chase Bank’s prime rate-based loans. Other than availability
 and an event of default, there are no other provisions for the
 interest margin to increase. The U.S. ABL will mature on
 May 31, 2020. Loans made under the U.S. ABL are secured first
 by all of the Company’s domestic cash, receivables and
 certain inventories as well as by a second position against a
 significant amount of the domestic assets of the Company and a
 pledge of 65% of voting stock of the Company’s first tier
 foreign subsidiaries and are structurally senior to the
 Company’s Senior Notes and Convertible Senior Notes. See
 Senior Notes and Convertible Senior Notes above. Concurrent with
 the issuance of the Term Loan Facility and Senior Notes, the
 Company paid down $63,000 of the outstanding balance of its U.S.
 ABL. At January 1, 2018, $17,000 of the U.S. ABL was
 outstanding and classified as long-term debt, which is consistent
 with its maturity date.

[0001193125-18-055988:notes:254]
The Asia ABL
 consists of two tranches comprised of a revolving credit facility
 for up to $150,000 and a letter of credit facility for up to
 $100,000, provided that at no time may amounts outstanding under
 both tranches exceed in aggregate $150,000 or the applicable
 borrowing base, which is a percentage of the principal amount of
 Eligible Accounts, as defined in the Asia ABL agreement. Borrowings
 under the Asia ABL bear interest at a floating rate of LIBOR plus
 140 basis points. At January 1, 2018, the interest rate on the
 outstanding borrowings under the Asia ABL was 2.96%. There is no
 provision, other than an event of default, for the interest margin
 to increase. The Asia ABL will mature on May 22, 2020. Loans
 made under the Asia ABL are secured by a portion of the
 Company’s Asia Pacific cash and receivables and are
 structurally senior to the Company’s domestic obligations,
 including the Senior Notes and Convertible Senior Notes. See Senior
 Notes and Convertible Senior Notes above. At January 1, 2018,
 $30,000 of the Asia ABL was outstanding and classified as long-term
 debt, which is consistent with its maturity date.

[0001193125-18-055988:notes:255]
The Company has
 up to $50,000 and $100,000 Letters of Credit Facilities under the
 U.S. ABL and the Asia ABL, respectively. As of January 1,
 2018, letters of credit in the amount of $7,612 were outstanding
 under the U.S. ABL and $43,085 were outstanding under the Asia ABL
 with various expiration dates through March 2019. Available
 borrowing capacity under the U.S. ABL and the Asia ABL was $175,388
 and $76,915, respectively, which considers letters of credit
 outstanding at January 1, 2018.

[0001193125-18-055988:notes:256]
The Company is
 required to pay a commitment fee of 0.25% to 0.375% per annum
 on any unused portion of the U.S ABL and the Asia ABL. The Company
 incurred total commitment fees related to unused borrowing
 availability of $783, $709, and $763 for the years ended
 January 1, 2018, January 2, 2017, and
 December 28, 2015, respectively. Under the occurrence of
 certain events, the ABL Revolving Loans are subject to various
 financial and operational covenants, including maintaining minimum
 fixed charge coverage ratios.

[0001193125-18-055988:notes:257]
Other
 Credit Facility

[0001193125-18-055988:notes:258]
Additionally, the Company
 is party to a revolving loan credit facility (Chinese Revolver)
 with a lender in China. Under this arrangement, the lender has made
 available to the Company approximately $32,200 in unsecured
 borrowing with all terms of the borrowing to be negotiated at the
 time the Chinese Revolver is drawn upon. There are no commitment
 fees on the unused portion of the Chinese Revolver, and this
 arrangement expires in January 2019. As of January 1, 2018,
 the Chinese Revolver had not been drawn upon.

[0001193125-18-055988:notes:259]
Debt
 Issuance and Debt Discount

[0001193125-18-055988:notes:260]
As of
 January 1, 2018 and January 2, 2017, remaining
 unamortized debt discount and debt issuance costs for the Term Loan
 Facility, Senior Notes, Convertible Senior Notes and 2016 Term Loan
 are as follows:

[0001193125-18-055988:notes:261]
|  |  | As of January 1, 2018 |  |  | As of January 2, 2017 |  |
|  |  | Debt Issuance Costs |  |  | Debt Discount |  |  | Effective Interest Rate |  |  | Debt Issuance Costs |  |  | Debt Discount |  |  | Effective Interest Rate |  |
|  |  | (in thousands) |  |
| Term Loan due September 2024 |  | $ | 2,788 |  |  | $ | 1,691 |  |  |  | 3.96 | % |  |  | — |  |  |  | — |  |  |  | — |  |
| Senior Notes due October 2025 |  |  | 6,782 |  |  |  | — |  |  |  | 5.92 | % |  |  | — |  |  |  | — |  |  |  | — |  |
| Convertible Senior Notes |  |  | 2,889 |  |  |  | 28,822 |  |  |  | 6.48 | % |  | $ | 3,747 |  |  | $ | 37,392 |  |  |  | 6.48 | % |
| Term Loan due May 2021 |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 977 |  |  |  | — |  |  |  | 5.29 | % |
|  |  | $ | 12,459 |  |  | $ | 30,513 |  |  |  |  |  |  | $ | 4,724 |  |  | $ | 37,392 |  |  |  |  |  |

[0001193125-18-055988:notes:262]
The above debt
 discount and debt issuance costs are recorded as a reduction of the
 debt and are amortized into interest expense using an effective
 interest rate over the duration of the debt.

[0001193125-18-055988:notes:263]
Debt issuance
 costs for the ABL Revolving Loans of $2,421 and $3,423 as of
 January 1, 2018 and January 2, 2017, respectively, are
 included in other non-current assets and are amortized
 to interest expense over the duration of the ABL Revolving Loans
 using the straight line method of amortization.

[0001193125-18-055988:notes:264]
At
 January 1, 2018, the remaining weighted average amortization
 period for all unamortized debt discount and debt issuance costs
 was 4 years.

[0001193125-18-055988:notes:265]
Loss on
 Extinguishment of Debt

[0001193125-18-055988:notes:266]
During the
 years ended January 1, 2018, January 2, 2017 and
 December 28, 2015, the Company recognized loss on
 extinguishment of debt of $768, $47,767 and $802, respectively,
 primarily associated with the write off of the remaining
 unamortized debt issuance and debt discount for the 2016 Term Loan,
 the 2015 Term Loan Credit Agreement, and the terminated 2012 credit
 agreement, respectively.


## us-gaap:MinorityInterestDisclosureTextBlock

[0001193125-18-055988:notes:267]
| (21) | Noncontrolling Interest Holdings |

[0001193125-18-055988:notes:268]
During the
 fourth quarter of 2017, the Company acquired Desay
 Industrial’s 5% noncontrolling equity interest in the
 manufacturing facility in Huiyang, China otherwise owned by the
 Company for 56,400 Chinese RMB or $8,568. The Company recorded an
 increase to additional paid in capital for the difference between
 the purchase price and the carrying value of the noncontrolling
 interest of $223.


## us-gaap:PreferredStockTextBlock

[0001193125-18-055988:notes:269]
| (16) | Preferred Stock |

[0001193125-18-055988:notes:270]
The board of
 directors has the authority, without action by stockholders, to
 designate and issue preferred stock in one or more series. The
 board of directors may also designate the rights, preferences and
 privileges of each series of preferred stock, any or all of which
 may be superior to the rights of the common stock. As of
 January 1, 2018, no shares of preferred stock were
 outstanding.


## us-gaap:ReconciliationOfAssetsFromSegmentToConsolidatedTextBlock

[0001193125-18-055988:notes:271]
|  |  | As of |  |
|  |  | January 1, 2018 |  |  | January 2, 2017 |  |  | December 28, 2015 |  |
|  |  | (In thousands) |  |
| Segment Assets: |  |  |  |  |  |  |  |  |  |  |  |  |
| PCB |  | $ | 1,991,049 |  |  | $ | 1,791,829 |  |  | $ | 1,943,577 |  |
| E-M Solutions |  |  | 143,344 |  |  |  | 127,826 |  |  |  | 143,779 |  |
| Corporate |  |  | 647,489 |  |  |  | 580,421 |  |  |  | 552,777 |  |
| Total assets |  | $ | 2,781,882 |  |  | $ | 2,500,076 |  |  | $ | 2,640,133 |  |


## us-gaap:RelatedPartyTransactionsDisclosureTextBlock

[0001193125-18-055988:notes:272]
| (20) | Related Party Transactions |

[0001193125-18-055988:notes:273]
In the normal
 course of business, the Company’s foreign subsidiaries
 purchase laminate and prepreg from related parties in which a
 significant shareholder of the Company holds an equity interest.
 The Company purchased laminate and prepreg from these related
 parties in the amount of $51,985, $55,649 and $63,605 for the years
 ended January 1, 2018, January 2, 2017 and
 December 28, 2015, respectively.

[0001193125-18-055988:notes:274]
The Company
 also sells and purchases PCBs to a related party which is a wholly
 owned subsidiary of an entity in which a significant shareholder of
 the Company holds an equity interest. Sales to this related party
 for the years ended January 1, 2018, January 2, 2017
 and December 28, 2015 were $78, $991 and $4,709, respectively.
 Purchases of PCBs, including various services relating to PCB
 manufacturing, from this related party for the year ended
 December 28, 2015 were $1,948. There were no purchases from
 this related party for the years ended January 1, 2018 and
 January 2, 2017.

[0001193125-18-055988:notes:275]
As of
 January 1, 2018 and January 2, 2017, the Company’s
 consolidated balance sheets included $14,452 and $15,836,
 respectively, in accounts payable due to related parties for
 purchases of laminate and prepreg and such balances are included as
 a component of accounts payable on the consolidated balance sheets.
 Additionally, the Company’s consolidated balance sheets
 included $33 and $192, respectively, in accounts receivable due
 from a related party for sales of PCBs, as mentioned above, and
 such balances are included as a component of accounts receivable,
 net on the consolidated balance sheets.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001193125-18-055988:notes:276]
| (18) | Segment Information |

[0001193125-18-055988:notes:277]
The reportable
 segments reported below are the Company’s segments for which
 separate financial information is available and upon which
 operating results are evaluated by the chief operating decision
 maker to assess performance and to allocate resources. The Company
 has two reportable segments: PCB and E-M Solutions. The PCB reportable
 segment is comprised of multiple operating segments. Factors
 considered to determine whether operating segments can be
 aggregated into reportable segments included similarity regarding
 economic characteristics, products, production processes, type or
 classes of customers, distribution methods, and regulatory
 environments.

[0001193125-18-055988:notes:278]
The Company,
 including the chief operating decision maker, evaluates segment
 performance based on reportable segment income, which is operating
 income before amortization of intangibles. Interest expense and
 interest income are not presented by segment since they are not
 included in the measure of segment profitability reviewed by the
 chief operating decision maker. All inter-segment transactions have
 been eliminated.

[0001193125-18-055988:notes:279]
The Corporate
 category includes operating expenses that are not included in the
 segment operating performance measures. Corporate consists
 primarily of corporate governance functions such as finance,
 accounting, information technology, facilities and human resources
 personnel, as well as global sales and marketing personnel and
 acquisition and integration costs associated with the acquisitions.
 Bank fees and legal, accounting, and other professional service
 costs associated with acquisitions of $2,266, $1,688 and $34,448
 for the years ended January 1, 2018, January 2, 2017 and
 December 28, 2015, respectively, are included in
 Corporate.

[0001193125-18-055988:notes:280]
During the year
 ended January 2, 2017, the Company recorded impairment charges
 of $1,393 and $1,953 for the impairment of long-lived assets
 related to its PCB reportable segment and Corporate, respectively.
 There were no impairment charges for the years ended
 January 1, 2018 and December 28, 2015.

[0001193125-18-055988:notes:281]
The Company
 markets and sells its products in approximately 65 countries. Other
 than in the United States and China, the Company does not conduct
 business in any country in which its net sales in that country
 exceed 10% of the Company’s total net sales. Net sales and
 long-lived assets are as follows:

[0001193125-18-055988:notes:282]
Net sales are
 attributed to countries by country invoiced.


## us-gaap:SubsequentEventsTextBlock

[0001193125-18-055988:notes:283]
| (22) | Subsequent Event |

[0001193125-18-055988:notes:284]
On February 21, 2018, the
 Company completed the allocation of $600,000 in commitments from
 lenders in the syndication for the Incremental Facility. This
 allocated Incremental Facility supersedes the original $700,000
 commitment received at the time the Company entered into the
 definitive purchase agreement with Anaren Holdings, LLC. The
 Incremental Facility is expected to be issued at a discount at
 99.75% and have a floating rate of LIBOR plus a margin of 2.5%. The
 closing of the Incremental Facility is expected to occur
 concurrently with the completion of the pending acquisition of
 Anaren.


## ttmi:DistributionOfProfitsDisclosureTextBlock

[0001193125-18-055988:notes:285]
| (17) | Distribution of profits |

[0001193125-18-055988:notes:286]
As stipulated
 by the relevant laws and regulations of China applicable to the
 Company’s subsidiaries in China, each of such subsidiaries is
 required to make appropriations from its net income as determined
 in accordance with accounting principles and the relevant financial
 regulations of China (PRC GAAP) to a non-distributable reserve, also
 referred to as statutory surplus reserve. The appropriations to the
 statutory surplus reserve are required to be made at not less than
 10% of the profit after tax as determined under PRC GAAP and are
 required until the balance reaches 50% of its registered capital.
 The statutory surplus reserve is used to offset future or past
 losses. These Chinese subsidiaries may, upon a resolution passed by
 their respective shareholders, convert the statutory surplus
 reserve into capital.

[0001193125-18-055988:notes:287]
There were
 appropriations of approximately $5,659, $6,037 and $4,576 to the
 statutory surplus reserve of the Company’s Chinese
 subsidiaries for the years ended January 1,
 2018, January 2, 2017 and December 28, 2015,
 respectively.
