# TTMI MD&A — 0001193125-18-055988


## mdna

[0001193125-18-055988:mdna:1]
| ITEM 7. | MANAGEMENT’S DISCUSSION AND ANALYSIS OF FINANCIAL CONDITION AND RESULTS OF OPERATIONS |

[0001193125-18-055988:mdna:2]
This financial review presents our operating results for each of our three most recent fiscal years and our financial condition at
January 1, 2018. Except for historical information contained herein, the following discussion contains forward-looking statements which are subject to known and unknown risks, uncertainties and other factors that may cause our actual results to
differ materially from those expressed or implied by such forward-looking statements. We discuss such risks, uncertainties and other factors throughout this report and specifically under Item 1A of Part I of this report, Risk Factors. In
addition, the following discussion should be read in connection with the information presented in our consolidated financial statements and the related notes to our consolidated financial statements.

[0001193125-18-055988:mdna:3]
COMPANY OVERVIEW

[0001193125-18-055988:mdna:4]
We are
a leading global printed circuit board (PCB) manufacturer, focusing on quick-turn and volume production of technologically complex PCBs and electro-mechanical solutions (E-M Solutions). We focus on providing time-to-market and volume production of advanced technology products and offer a one-stop manufacturing solution to our customers from
engineering support to prototype development through final mass production. This one-stop manufacturing solution allows us to align technology development with the diverse needs of our customers and to enable
them to reduce the time required to develop new products and bring them to market. We serve a diversified customer base consisting of approximately 2,000 customers in various markets throughout the world, including aerospace and defense, automotive
components, smartphones and touchscreen tablets, high-end computing, and medical, industrial and instrumentation related products as well as networking/communications infrastructure products. Our customers
include both original equipment manufacturers (OEMs) and electronic manufacturing services (EMS) providers.

[0001193125-18-055988:mdna:5]
RECENT DEVELOPMENTS

[0001193125-18-055988:mdna:6]
On September 28, 2017, we entered into a $350.0 million Term Loan Facility due 2024 (Term Loan Facility), and
issued $375.0 million of Senior Notes due 2025 (Senior Notes). In conjunction with the issuance of the Term Loan Facility and Senior Notes, we repaid in full the remaining outstanding balance of the September 27, 2016 Term Loan Credit
Agreement (2016 Term Loan) and repaid $63.0 million on our existing U.S. Asset-Based Lending Credit Agreement (U.S. ABL).

[0001193125-18-055988:mdna:7]
On December 1, 2017, we entered into a definitive stock purchase agreement with Anaren Holdings, LLC pursuant to which we agreed to
purchase all of the issued and outstanding common stock of Anaren Holding Corp., for total consideration of $775.0 million in cash subject to customary working capital and certain other adjustments. Other than the equity interest of Anaren,
Inc. (Anaren), Anaren Holding Corp. has no material assets or liabilities and has no material independent operations. Anaren is a leading provider of mission-critical radio frequency (RF) solutions, microelectronics, and microwave components and
assemblies for the wireless infrastructure and space and defense electronics markets. Anaren’s microwave products are used in wireless communication systems including wireless infrastructure, wireless consumer and medical applications, as well
as advanced radar, beam-forming, jamming, motion control and receiver applications for the space and defense markets, covering a broad range of frequencies and power levels. Its Integrated Radio module product lines provide proprietary low power RF
monitoring solutions deployable in a wide variety of end market applications. The acquisition of Anaren will significantly increase our aerospace and defense design capability with particular focus on RF products, deepen our customer engagement in
aerospace and defense and networking/communications and complement our focus on high technology PCB products manufacturing. We expect to complete the acquisition in the first half of 2018.

[0001193125-18-055988:mdna:8]
In conjunction with the pending acquisition of Anaren, we have received commitments to fund a $700.0 million senior secured
incremental term loan (Incremental Facility). Subsequent to January 1, 2018, we completed the allocation of $600.0 million in commitments from lenders in syndication for the Incremental Facility, which supercedes the original
$700.0 million commitment. Upon the consummation of the acquisition of Anaren, we will use the borrowings from the Incremental Facility and cash on hand to finance the acquisition.

[0001193125-18-055988:mdna:9]
FINANCIAL OVERVIEW

[0001193125-18-055988:mdna:10]
For the fiscal year 2017, we experienced higher demand in our Cellular Phone, Computing, and Aerospace and Defense end markets, partially offset by lower demand in our Networking/Communications end
market.

[0001193125-18-055988:mdna:11]
While our customers include both OEMs and EMS providers, we measure customers based on OEM companies as they are the
ultimate end customers. Sales to our five largest customers accounted for 37%, 33% and 37% of our net sales in fiscal years 2017, 2016 and 2015, respectively. We sell to OEMs both directly and indirectly through EMS providers.

[0001193125-18-055988:mdna:12]
The following table shows the percentage of our net sales attributable to each of the principal end markets we served for the periods
indicated:

[0001193125-18-055988:mdna:13]
| End Markets(1) |  | 2017 |  |  | 2016 |  |  | 2015(2) |  |
| Aerospace and Defense |  |  | 16 | % |  |  | 15 | % |  |  | 14 | % |
| Automotive |  |  | 19 |  |  |  | 20 |  |  |  | 13 |  |
| Cellular Phone(3) |  |  | 18 |  |  |  | 14 |  |  |  | 21 |  |
| Computing/Storage/Peripherals(3) |  |  | 13 |  |  |  | 12 |  |  |  | 12 |  |
| Medical/Industrial/Instrumentation |  |  | 14 |  |  |  | 14 |  |  |  | 13 |  |
| Networking/Communications |  |  | 18 |  |  |  | 23 |  |  |  | 25 |  |
| Other(3) |  |  | 2 |  |  |  | 2 |  |  |  | 2 |  |
| Total |  |  | 100 | % |  |  | 100 | % |  |  | 100 | % |

[0001193125-18-055988:mdna:14]
| (1) | Sales to EMS companies are classified by the end markets of their OEM customers. |

[0001193125-18-055988:mdna:15]
| (2) | Amounts include activity of Viasystems, which we acquired on May 31, 2015. |

[0001193125-18-055988:mdna:16]
| (3) | Smartphones are included in the Cellular Phone end market, tablets are included in the Computing/Storage/Peripherals end market and other consumer devices include wearables, portable video devices and personal headphones are included in the Other end market. |

[0001193125-18-055988:mdna:17]
We derive
revenues primarily from the sale of PCBs and custom electronic assemblies using customer-supplied engineering and design plans. We recognize revenues when persuasive evidence of a sales arrangement exists, the sales terms are fixed or determinable,
title and risk of loss have transferred, and collectability is reasonably assured — generally when products are shipped to the customer. Net sales consist of gross sales less an allowance for returns, which typically have been less than 2% of
gross sales. We provide our customers a limited right of return for defective PCBs and backplane assemblies. We record an estimate for sales returns and allowances at the time of sale based on historical results. Purchase orders may be cancelled
prior to shipment. We generally charge customers a fee, based on the percentage completed, if an order is cancelled once it has entered production.

[0001193125-18-055988:mdna:18]
Cost of goods sold consists of materials, labor, outside services, and overhead expenses incurred in the manufacture and testing of our products. Shipping and handling fees and related freight costs and
supplies associated with shipping products are also included as a component of cost of goods sold. Many factors affect our gross margin, including capacity utilization, product mix, production volume, and yield. We generally do not participate in
any significant long-term contracts with suppliers, and we believe there are a number of potential suppliers for the raw materials we use.

[0001193125-18-055988:mdna:19]
Selling and marketing expenses consist primarily of salaries, labor related benefits, and commissions paid to our internal sales force, independent sales representatives, and our sales support staff, as
well as costs associated with marketing materials and trade shows.

[0001193125-18-055988:mdna:20]
General and administrative costs primarily include the
salaries for executive, finance, accounting, information technology, facilities and human resources personnel, as well as expenses for accounting and legal assistance, incentive compensation expense, and gains or losses on the sale or disposal of
property, plant and equipment.

[0001193125-18-055988:mdna:21]
CRITICAL ACCOUNTING POLICIES AND ESTIMATES

[0001193125-18-055988:mdna:22]
Our consolidated financial statements included in this report have been prepared in accordance with accounting principles generally
accepted in the United States of America. The preparation of these financial statements requires us to make estimates and assumptions that affect the reported amounts of assets, liabilities, net sales and expenses, and related disclosure of
contingent assets and liabilities.

[0001193125-18-055988:mdna:23]
A critical accounting policy is defined as one that is both material to the presentation of
our consolidated financial statements and requires us to make judgments that could have a material effect on our financial condition or results of operations. These policies require us to make assumptions about matters that are highly uncertain at
the time of the estimate. Different estimates we could reasonably have used, or changes in the estimates that are reasonably likely to occur, could have a material effect on our financial condition or results of operations.

[0001193125-18-055988:mdna:24]
We base our estimates on historical experience and on various other assumptions that are believed to be reasonable under the
circumstances, the results of which form the basis for making judgments about the carrying values of assets and liabilities that are not readily apparent from other sources. Management has discussed the development, selection and disclosure of these
estimates with the audit committee of our board of directors. Actual results may differ from these estimates under different assumptions or conditions.

[0001193125-18-055988:mdna:25]
Our critical accounting policies include asset valuation related to bad debts and inventory; sales returns and allowances; impairment of long-lived assets, including goodwill and intangible assets;
realizability of deferred tax assets; and determining self-insurance reserves.

[0001193125-18-055988:mdna:26]
Allowance for Doubtful Accounts

[0001193125-18-055988:mdna:27]
We provide customary credit terms to our customers and generally do not require collateral. We perform ongoing credit
evaluations of the financial condition of our customers and maintain an allowance for doubtful accounts based upon historical collections experience and judgments as to expected collectability of accounts. Our actual bad debts may differ from our
estimates.

[0001193125-18-055988:mdna:28]
Inventories

[0001193125-18-055988:mdna:29]
In assessing the realizability of inventories, we are required to make judgments as to future demand requirements and compare these with current and committed inventory levels. When the estimated sales
value of inventory is less than the carrying value, the inventory cost is written down to its estimated net realizable value, thereby establishing a new cost basis. Our inventory requirements may change based on projected customer demand, market
conditions, technological and product life cycle changes, longer or shorter than expected usage periods, and other factors that could affect the valuation of our inventories. We maintain certain finished goods inventories near certain key customer
locations in accordance with agreements with those customers. Although this inventory is typically supported by valid purchase orders, should these customers ultimately not purchase these inventories, our results of operations and financial
condition would be adversely affected.

[0001193125-18-055988:mdna:30]
Sales Returns and Allowances

[0001193125-18-055988:mdna:31]
We derive revenues primarily from the sale of PCBs and custom electronic assemblies using customer-supplied engineering and design plans.
We recognize revenue when persuasive evidence of a sales arrangement exists, the sales terms are fixed or determinable, title and risk of loss have transferred, and collectability is reasonably assured — generally when products are shipped to
the customer. We provide our customers a limited right of return for defective PCBs and backplane assemblies. We accrue an estimate for sales returns and allowances at the time of sale using our judgment based on historical results and anticipated
returns as a result of current period sales. To the extent actual experience varies from our historical experience, revisions to these allowances may be required.

[0001193125-18-055988:mdna:32]
Long-lived Assets

[0001193125-18-055988:mdna:33]
We have significant long-lived tangible and
intangible assets consisting of property, plant and equipment, definite-lived intangibles, and goodwill. We review these assets for impairment whenever events or changes in

[0001193125-18-055988:mdna:34]
circumstances indicate that the carrying amount of such assets may not be recoverable. In addition, we perform an impairment test related to goodwill at least annually. As necessary, we make
judgments regarding future cash flow forecasts in the assessment of impairment.

[0001193125-18-055988:mdna:35]
During the fourth quarter of each year, and
when events and circumstances warrant an evaluation, we perform an impairment assessment of goodwill, which may require the use of a fair-value based analysis. We assess qualitative factors to determine whether it is more likely than not that the
fair value of a reporting unit is less than its carrying amount. If we conclude that it is more likely than not that the fair value of a reporting unit is less than its carrying amount, we compare the fair values of the applicable reporting units
with their carrying values. If the carrying amount of a reporting unit exceeds the reporting unit’s fair value, the amount by which the carrying value exceeds the fair value is recognized as an impairment loss. We determine the fair value of
our reporting units based on discounted cash flows and market approach analyses as considered necessary. We consider factors such as the state of the economy and reduced expectations for future cash flows coupled with a decline in our market
capitalization for a sustained period as indicators for potential goodwill impairment. In the fourth quarter of 2017, we performed our annual impairment test qualitatively and concluded that it was more likely than not that goodwill was not
impaired.

[0001193125-18-055988:mdna:36]
We also assess other long-lived assets, specifically definite-lived intangibles and property, plant and equipment,
for potential impairment given similar impairment indicators. When indicators of impairment exist related to our long-lived tangible assets and definite-lived intangible assets, we use an estimate of the undiscounted cash flows in measuring whether
the carrying amount of the assets is recoverable. Measurement of the amount of impairment, if any, is based upon the difference between the asset’s carrying value and estimated fair value. Fair value is determined through various valuation
techniques, including cost-based, market and income approaches as considered necessary, which involve judgments related to future cash flows and the application of the appropriate valuation model. During the fiscal year 2016 we recorded impairment
charges to reduce the carrying value of certain long-lived assets in the PCB reportable segment. See Note 4 to our consolidated financial statements.

[0001193125-18-055988:mdna:37]
Assets Held for Sale — We classify assets to be sold as assets held for sale when (i) we have approved and commit to a plan to sell the asset, (ii) the asset is available for
immediate sale in its present condition, (iii) an active program to locate a buyer and other actions required to sell the asset have been initiated, (iv) the sale of the asset is probable, (v) the asset is being actively marketed for
sale at a price that is reasonable in relation to its current fair value, and (vi) it is unlikely that significant changes to the plan will be made or that the plan will be withdrawn. Assets classified as held for sale are recorded at the lower
of the carrying amount or fair value less the cost to sell.

[0001193125-18-055988:mdna:38]
Assets Held for Use — If a decision to dispose of an
asset or a business is made and the held for sale criteria are not met, it is considered held for use. Assets of the business are evaluated for recoverability in the following order: (i) assets other than goodwill, property and intangibles;
(ii) property and intangibles subject to amortization; and (iii) goodwill. In evaluating the recoverability of property and intangible assets subject to amortization, in a held for use business, the carrying value is first compared to the
sum of the undiscounted cash flows expected to result from the use and eventual disposition. If the carrying value exceeds the undiscounted expected cash flows, then a fair value analysis is performed. An impairment charge is recognized if the
carrying value exceeds the fair value.

[0001193125-18-055988:mdna:39]
Income Taxes

[0001193125-18-055988:mdna:40]
Deferred income tax assets are reviewed for recoverability, and valuation allowances are provided, when necessary, to reduce deferred
income tax assets to the amounts that are more likely than not to be realized based on our estimate of future taxable income. At January 1, 2018, we had a net noncurrent deferred income tax liability of $4.9 million, which is net of the
$64.4 million deferred tax asset. At January 1, 2018, our deferred income tax asset of $64.4 million was net of a valuation allowance of approximately $167.2 million. Should our expectations of taxable income change in future
periods, it may be necessary to adjust our valuation allowance, which could affect our results of operations in the period such a determination is made. We record income tax provision or benefit during interim periods at a rate that is based on
expected results for the full year. If future changes in market conditions cause actual results for the year to be more or less favorable than those expected, adjustments to the effective income tax rate could be required.

[0001193125-18-055988:mdna:41]
Effects of the Tax Cuts and Jobs Act

[0001193125-18-055988:mdna:42]
On December 22, 2017, the Tax Cuts and Jobs Act (Tax Act) was enacted. Accounting Standards Codification (ASC) 740, Accounting for
Income Taxes, requires companies to recognize the effect of tax law changes in the period of enactment regardless of the effective date of those tax law changes. Certain provisions of the Tax Act are effective September 27, 2017, others are
effective or identified as of December 31, 2017 and others are effective after January 1, 2018.

[0001193125-18-055988:mdna:43]
Given the timing of
enactment of the Tax Act and the significance of the legislation, the SEC staff issued Staff Accounting Bulletin No. 118 (SAB 118), which allows registrants to record provisional amounts during a one year “measurement period” similar
to that used when accounting for business combinations. However, the measurement period should not extend beyond one year from the Tax Act enactment date and is deemed to have ended when the registrant has obtained, prepared and analyzed the
information necessary to finalize its accounting.

[0001193125-18-055988:mdna:44]
To the extent that a company’s accounting for certain income tax
effects of the Tax Act is incomplete but the registrant is able to determine a reasonable estimate, it must record a provisional estimate in the financial statements. If a company cannot determine a provisional estimate to be included in the
financial statements, it should continue to apply ASC 740, Accounting for Income Taxes, on the basis of the provisions of the tax laws that were in effect immediately before the enactment of the Tax Act. More specifically, SAB 118 summarizes
a three-step process to be applied at each reporting period to account for and disclose the tax effects of the Tax Act. The steps are (1) to record the effects of the change in tax law for which accounting is complete; (2) to record
provisional amounts (or adjustments to provisional amounts) for the effects of the tax law where accounting is not complete, but for which a reasonable estimate has been determined; and (3) where a reasonable estimate cannot yet be made, to
continue to apply ASC 740, Accounting for Income Taxes, based on the tax law in effect prior to enactment of the Tax Act.

[0001193125-18-055988:mdna:45]
We do not believe that accounting is complete for the year ended January 1, 2018. With respect to the reduction in the U.S. corporate
income tax rate to 21 percent, we revalued our ending gross deferred tax items, previously recorded at 35 percent, using the enacted 21 percent corporate tax rate. This change resulted in no net tax expense/benefit but did cause an
approximate $66.0 million reduction to our U.S. federal deferred tax asset fully offset by a reduction of our valuation allowance. While we are able to make a reasonable estimate of the impact of the reduction in corporate rate, it may be
affected by other analyses related to the Tax Act, including, but not limited to, our calculation of deemed repatriation of deferred foreign income and the state tax effect of adjustments made to federal temporary differences, as well as changes to
our valuation allowance.

[0001193125-18-055988:mdna:46]
Further effects of tax law changes where we have made a provisional estimate include the one-time mandatory repatriation transition tax on the net accumulated earnings and profits of a U.S. taxpayer’s foreign subsidiaries earned post 1986. We have performed a preliminary earnings and profits
analysis with consideration given to foreign loss carryforwards acquired as a result of our acquisitions and determined that there should be no income tax effect in the current or any future period. We will continue to identify and evaluate data to
more thoroughly identify the tax impact and record adjustments, if any, within the measurement period.

[0001193125-18-055988:mdna:47]
Other significant
provisions that are not yet effective and for which we have not completed our analysis, but which may impact income taxes in future years include: limitations on certain entertainment expenses, the inclusion of commissions and performance based
compensation in determining the excessive compensation limitation, limitation on the current deductibility of net interest expense in excess of 30 percent of adjusted taxable income, an incremental tax (base erosion anti-abuse tax or BEAT) on
excessive amounts paid to foreign related parties, a minimum tax on certain foreign earnings in excess of 10 percent of the foreign subsidiaries tangible assets (i.e., global intangible low-taxed income
or GILTI), the benefit related to foreign derived intangible income (FDII), the required capitalization of research and development expenditures and the impact of requiring tax conformity with Accounting Standard Update (ASU) 2014-09, Revenue from Contracts with Customers. We are still evaluating whether to make a policy election to treat the GILTI tax as a period expense or to provide U.S. deferred taxes on foreign earnings that
are expected to generate GILTI income when they reverse in future years.

[0001193125-18-055988:mdna:48]
In addition, we are subject to income taxes in the
United States and foreign jurisdictions. Significant judgment is required in determining our worldwide provision for income taxes. In the ordinary course of our business, there are many transactions for which the ultimate tax determination is
uncertain. Additionally, our calculations of income taxes are based on our interpretations of applicable tax laws in the jurisdictions in which we file.

[0001193125-18-055988:mdna:49]
Self Insurance

[0001193125-18-055988:mdna:50]
We are primarily self-insured in the United States for group health insurance and worker’s compensation benefits provided to our U.S.
employees, and we purchase insurance to protect against annual claims at the individual and aggregate level. We estimate our exposure for claims incurred but not reported at the end of each reporting period. We use our judgment using our historical
claim data and information and analysis provided by actuarial and claim advisors, our insurance carriers and brokers on an annual basis to estimate our liability for these claims. This liability is subject to individual insured stop-loss coverage of
$350,000 per individual for group health insurance and $250,000 per individual for worker’s compensation benefits. Our actual claims experience may differ from our estimates.

[0001193125-18-055988:mdna:51]
RESULTS OF OPERATIONS

[0001193125-18-055988:mdna:52]
We operate on a 52 or 53 week year ending on the
Monday nearest December 31. Fiscal year 2017 and 2015 were 52 weeks ended January 1, 2018 and December 28, 2015, respectively. Fiscal year 2016 consisted of 53 weeks ended on January 2, 2017 with the additional week included
in the fourth quarter. We estimate the additional week contributed approximately $29.2 million of additional revenue and approximately $1.1 million of additional operating income for the year ended January 2, 2017.

[0001193125-18-055988:mdna:53]
The following table sets forth the relationship of various items to net sales in our consolidated statements of operations:

[0001193125-18-055988:mdna:54]
|  |  | For the Year Ended |  |
|  |  | January 1,2018 |  |  | January 2,2017 |  |  | December 28,2015 |  |
| Net sales |  |  | 100.0 | % |  |  | 100.0 | % |  |  | 100.0 | % |
| Cost of goods sold |  |  | 83.8 |  |  |  | 83.3 |  |  |  | 85.2 |  |
| Gross profit |  |  | 16.2 |  |  |  | 16.7 |  |  |  | 14.8 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |
| Selling and marketing |  |  | 2.5 |  |  |  | 2.6 |  |  |  | 2.7 |  |
| General and administrative |  |  | 4.7 |  |  |  | 5.8 |  |  |  | 8.0 |  |
| Amortization of definite-lived intangibles |  |  | 1.0 |  |  |  | 1.0 |  |  |  | 0.9 |  |
| Restructuring charges |  |  | — |  |  |  | 0.4 |  |  |  | 0.4 |  |
| Impairment of long-lived assets |  |  | — |  |  |  | 0.1 |  |  |  | — |  |
| Gain on sale of assets |  |  | — |  |  |  | — |  |  |  | (0.1 | ) |
| Total operating expenses |  |  | 8.2 |  |  |  | 9.9 |  |  |  | 11.9 |  |
| Operating income |  |  | 8.0 |  |  |  | 6.8 |  |  |  | 2.9 |  |
| Other income (expense): |  |  |  |  |  |  |  |  |  |  |  |  |
| Interest expense |  |  | (2.0 | ) |  |  | (3.0 | ) |  |  | (2.9 | ) |
| Loss on extinguishment of debt |  |  | — |  |  |  | (1.9 | ) |  |  | — |  |
| Other, net |  |  | (0.7 | ) |  |  | 0.7 |  |  |  | 0.4 |  |
| Total other expense, net |  |  | (2.7 | ) |  |  | (4.2 | ) |  |  | (2.5 | ) |
| Income before income taxes |  |  | 5.3 |  |  |  | 2.6 |  |  |  | 0.4 |  |
| Income tax provision |  |  | (0.6 | ) |  |  | (1.2 | ) |  |  | (1.6 | ) |
| Net income (loss) |  |  | 4.7 |  |  |  | 1.4 |  |  |  | (1.2 | ) |
| Less: Net income attributable to the noncontrolling interest |  |  | — |  |  |  | — |  |  |  | — |  |
| Net income (loss) attributable to TTM Technologies, Inc. stockholders |  |  | 4.7 | % |  |  | 1.4 | % |  |  | (1.2 | )% |

[0001193125-18-055988:mdna:55]
50

[0001193125-18-055988:mdna:56]
The Viasystems Group, Inc. (Viasystems) acquisition occurred on May 31, 2015.
Accordingly, our fiscal year 2015 only includes Viasystems’ 2015 results of operations for the last seven fiscal months.

[0001193125-18-055988:mdna:57]
We have two reportable segments: PCB and E-M Solutions. The PCB reportable segment is comprised of
multiple operating segments. Factors considered in determining whether operating segments can be aggregated into reportable segments included similarity regarding economic characteristics, products, production process, type or class of customers,
distribution methods and regulatory environments.

[0001193125-18-055988:mdna:58]
The following table compares net sales by reportable segment for fiscal
years 2017, 2016 and 2015:

[0001193125-18-055988:mdna:59]
|  |  | For the Year Ended |  |
|  |  | January 1,2018 |  |  | January 2,2017 |  |  | December 28,2015 |  |
|  |  | (In thousands) |  |
| Net Sales: |  |  |  |  |  |  |  |  |  |  |  |  |
| PCB |  | $ | 2,461,575 |  |  | $ | 2,346,554 |  |  | $ | 1,944,041 |  |
| E-M Solutions |  |  | 210,086 |  |  |  | 198,483 |  |  |  | 158,655 |  |
| Total sales |  |  | 2,671,661 |  |  |  | 2,545,037 |  |  |  | 2,102,696 |  |
| Inter-segment sales |  |  | (13,069 | ) |  |  | (11,678 | ) |  |  | (7,208 | ) |
| Total net sales |  | $ | 2,658,592 |  |  | $ | 2,533,359 |  |  | $ | 2,095,488 |  |

[0001193125-18-055988:mdna:60]
Net Sales

[0001193125-18-055988:mdna:61]
Total net sales increased $125.2 million, or 4.9%, from $2,533.4 million for the year ended January 2, 2017 to $2,658.6 million for the year ended January 1, 2018. Net sales for
the PCB reportable segment, excluding inter-segment sales, increased $113.6 million, or 4.9%, from $2,334.9 million for the year ended January 2, 2017 to $2,448.5 million for the year ended January 1, 2018. This increase was
primarily due to higher demand in our Cellular Phone, Computing/Storage/Peripherals and Aerospace and Defense end markets compared to the year ended January 2, 2017, partially offset by lower demand in our Networking/Communications end market.
While these changes resulted in essentially no change in PCB shipments as compared to the year ended January 2, 2017, average PCB selling price increased by 4.9% as a result of higher average PCB selling price in our Cellular Phone end market,
which is primarily due to a more complex technology at a higher cost. Net sales for the E-M Solutions reportable segment, excluding inter-segment sales, increased $11.6 million, or 5.8%, from
$198.5 million for the year ended January 2, 2017 to $210.1 million for the year ended January 1, 2018. This increase was primarily due to higher demand in our Automotive end market.

[0001193125-18-055988:mdna:62]
Total net sales increased $437.9 million, or 20.9%, from $2,095.5 million for the year ended December 28, 2015 to
$2,533.4 million for the year ended January 2, 2017. Net sales for the PCB reportable segment, excluding inter-segment sales, increased $397.7 million, or 20.5%, from $1,937.2 million for the year ended December 28, 2015 to
$2,334.9 million for the year ended January 2, 2017. This increase was primarily due to the additional sales resulting from a full year contribution from the acquisition of Viasystems, combined with higher demand in our Automotive and
Aerospace and Defense end markets, partially offset with lower demand in our Cellular Phone end market. These changes, including the sales from Viasystems, resulted in a 40% increase in PCB shipments from the year ended December 28, 2015. Our
increased net sales were partially offset by a decrease in the average PCB selling price of 13%, which was driven by a product mix shift resulting from the acquisition. Net sales for the E-M Solutions
reportable segment, excluding inter-segment sales, increased $40.2 million, or 25.4%, from $158.3 million for the year ended December 28, 2015 to $198.5 million for the year ended January 2, 2017. This increase was due to
the additional sales resulting from the acquisition of Viasystems.

[0001193125-18-055988:mdna:63]
The inter-segment sales are primarily sales from the PCB
reportable segment to the E-M Solutions reportable segment.

[0001193125-18-055988:mdna:64]
Gross Margin

[0001193125-18-055988:mdna:65]
Overall gross margin decreased from 16.7% for the year ended January 2, 2017 to 16.2% for the year ended
January 1, 2018. Gross margin for the PCB reportable segment decreased from 17.7% for the year ended

[0001193125-18-055988:mdna:66]
January 2, 2017 to 17.2% for the year ended January 1, 2018, primarily due to the change in classification of certain facilities and labor support related costs from general and
administrative expenses to cost of goods sold as a result of changes in our business structure, partially offset by higher margins in our Cellular Phone focused facilities. Gross margin for the E-M Solutions
reportable segment decreased from 9.1% for the year ended January 2, 2017 to 8.1% for the year ended January 1, 2018 primarily due to mix shift toward higher direct material content work.

[0001193125-18-055988:mdna:67]
Capacity utilization is a key driver for us, particularly in our high volume Asia facilities, as a significant portion of our operating
costs are fixed in nature. Capacity utilization for the year ended January 2, 2017 in our Asia and North America PCB facilities was 81% and 57%, respectively, compared to 86% and 54%, respectively, for the year ended January 1, 2018.

[0001193125-18-055988:mdna:68]
Overall gross margin increased from 14.8% for the year ended December 28, 2015 to 16.7% for the year ended
January 2, 2017. Gross margin for the PCB reportable segment increased from 15.5% for the year ended December 28, 2015 to 17.7% for the year ended January 2, 2017 primarily due to higher utilization and full year contribution from the
Automotive focused facilities and the absence of $13.3 million of increased costs incurred during fiscal year 2015 due to the fair value mark up of acquired inventory associated with the acquisition of Viasystems. Gross margin for the E-M Solutions reportable segment increased from 6.6% for the year ended December 28, 2015 to 9.1% for the year ended January 2, 2017 primarily due to increased production volumes at certain acquired
facilities.

[0001193125-18-055988:mdna:69]
Selling and Marketing Expenses

[0001193125-18-055988:mdna:70]
Selling and marketing expenses decreased $0.5 million from $66.4 million for the year ended January 2, 2017 to
$65.9 million for the year ended January 1, 2018. As a percentage of net sales, selling and marketing expenses were 2.6% for the year ended January 2, 2017 as compared to 2.5% for the year ended January 1, 2018. The decrease in
selling and marketing expense as a percentage of net sales for the periods noted was primarily due to higher net sales and lower travel expenses.

[0001193125-18-055988:mdna:71]
Selling and marketing expenses increased $9.0 million from $57.4 million for the year ended December 28, 2015 to $66.4 million for the year ended January 2, 2017. As a percentage
of net sales, selling and marketing expenses were 2.7% for the year ended December 28, 2015 as compared to 2.6% for the year ended January 2, 2017. The increase in selling and marketing expense for the year ended January 2, 2017
primarily related to additional selling and marketing activities resulting from the acquisition of Viasystems.

[0001193125-18-055988:mdna:72]
General
and Administrative Expenses

[0001193125-18-055988:mdna:73]
General and administrative expenses decreased $21.1 million from $147.2 million,
or 5.8% of net sales, for the year ended January 2, 2017 to $126.1 million, or 4.7% of net sales, for the year ended January 1, 2018. The decrease in expense is primarily related to the change in classification of certain facilities
and labor support related costs to cost of goods sold due to changes in our business structure.

[0001193125-18-055988:mdna:74]
General and administrative
expenses decreased $20.5 million from $167.7 million, or 8.0% of net sales, for the year ended December 28, 2015 to $147.2 million, or 5.8% of net sales, for the year ended January 2, 2017. The decrease in expense primarily
related to a decrease of $32.8 million in acquisition-related costs as compared to the year ended December 28, 2015, partially offset by increased expenses resulting from the acquisition of Viasystems. The decrease in general and
administrative expense as percentage of net sales was primarily due to the decrease in acquisition-related costs and higher net sales.

[0001193125-18-055988:mdna:75]
Impairment of Long-Lived Assets and Restructuring Charges

[0001193125-18-055988:mdna:76]
For the
years ended January 1, 2018, January 2, 2017 and December 28, 2015, we incurred restructuring charges of $1.2 million, $8.9 million, and $7.4 million, respectively, related to a consolidation plan (the Consolidation
Plan) announced on September 29, 2015, that resulted in the closure of our facilities in Cleveland, Ohio, Milpitas, California, and Juarez, Mexico and other global realignment efforts.

[0001193125-18-055988:mdna:77]
During the year ended January 1, 2018, in connection with the Consolidation Plan,
we recognized restructuring charges of $0.3 million and $0.5 million in our PCB and E-M Solutions reportable segments, respectively, and $0.4 million in Corporate. For the year ended
January 2, 2017, we recognized restructuring charges of $3.7 million and $4.5 million in our PCB and E-M Solutions reportable segments, respectively, and $0.7 million in Corporate. For the
year ended December 28, 2015, we recognized restructuring charges of $2.0 million, for both our PCB and E-M Solutions reportable segments and $3.4 million in Corporate. These charges primarily
represent employee separation and contract termination and other costs associated with the Consolidation Plan and other global realignment restructuring efforts. As of January 1, 2018, we had incurred approximately $17.5 million of
restructuring charges since the inception of the Consolidation Plan and we have substantially completed such Consolidation Plan.

[0001193125-18-055988:mdna:78]
Additionally, as a result of the above mentioned plant closures and other plant realignment efforts, we also recognized impairment charges
of $3.3 million for the year ended January 2, 2017, of which $1.4 million were recognized in our PCB reportable segment and $1.9 million were recognized in the Corporate. The impairment charge for the PCB reportable segment
related to machinery and equipment while the impairment charge for Corporate related to the write-off of capitalized software costs.

[0001193125-18-055988:mdna:79]
If forecasts and assumptions used to support the realizability of our long-lived assets change in the future, significant impairment or restructuring charges could result that would adversely affect our
results of operations and financial condition.

[0001193125-18-055988:mdna:80]
Other Income (Expense)

[0001193125-18-055988:mdna:81]
Other expense, net decreased $33.7 million from $106.5 million for the year ended January 2, 2017 to $72.8 million for
the year ended January 1, 2018. The decrease in other expense, net was primarily due to:

[0001193125-18-055988:mdna:82]
|  | • |  | the absence of the 2016 loss on extinguishment of debt of $47.8 million related to the full repayment of the 2015 Term Loan Credit Agreement, |

[0001193125-18-055988:mdna:83]
|  | • |  | a decrease in interest expense of $22.1 million, due to overall lower amount of principal outstanding, a lower Term Loan Facility interest rate margin by 175 basis points, and three quarters of comparatively lower amortization of debt issuance costs and debt discount after the full repayment of our 2016 Term Loan in the fourth quarter of 2016, and |

[0001193125-18-055988:mdna:84]
|  | • |  | partially offset by an increase from a change in foreign exchange expense of $36.3 million resulting from a $22.8 million foreign exchange losses for the year ended January 1, 2018 compared to a $13.5 million of foreign exchange gains for the year ended January 2, 2017 primarily resulting from a weakening U.S. dollar relative to the Chinese Renminbi. |

[0001193125-18-055988:mdna:85]
Other expense, net increased $54.1 million from $52.4 million for the year ended December 28,
2015 to $106.5 million for the year ended January 2, 2017. The increase in other expense, net was primarily due to:

[0001193125-18-055988:mdna:86]
|  | • |  | the loss on extinguishment of debt of $47.8 million related to the full repayment of the 2015 Term Loan Credit Agreement, |

[0001193125-18-055988:mdna:87]
|  | • |  | an increase in interest expense of $16.2 million primarily related to twelve months of outstanding borrowings consisting of the 2016 Term Loan and ABL Revolving Loans, for the year ended January 2, 2017, compared with only seven months of outstanding borrowings for the year ended December 28, 2015, and |

[0001193125-18-055988:mdna:88]
|  | • |  | partially offset by an increase in foreign exchange gains of $7.1 million resulting from $13.5 million of foreign exchange gains for the year ended January 2, 2017 compared to $6.4 million of foreign exchange gains for the year ended December 28, 2015. |

[0001193125-18-055988:mdna:89]
Income Taxes

[0001193125-18-055988:mdna:90]
The provision for income taxes decreased
$16.2 million from an income tax expense of $31.4 million for the year ended January 2, 2017 to $15.2 million for the year ended January 1, 2018. The decrease in income tax expense in 2017 was primarily due to a release of
the valuation allowance in certain foreign entities and an increase in tax incentives in China.

[0001193125-18-055988:mdna:91]
Our tax expense is primarily impacted by tax rates in China and Hong Kong, the U.S.
federal income tax rate, apportioned state income tax rates, generation of other credits and deductions available to us, changes in our valuation allowance, and certain non-deductible items. Certain losses generated are not more likely than not to
be realizable, and thus no income tax benefit has been recognized on these losses. We had a net deferred income tax liability of approximately $4.9 million and $14.0 million as of January 1, 2018 and January 2, 2017,
respectively. As of January 1, 2018, we have a full valuation allowance recorded in U.S. Based on our forecast for future taxable earnings in certain foreign jurisdictions, we believe it is more likely than not that we will utilize the deferred
income tax assets in future periods.

[0001193125-18-055988:mdna:92]
The provision for income taxes decreased $3.2 million from an income tax expense of
$34.6 million for the year ended December 28, 2015 to $31.4 million for the year ended January 2, 2017. The decrease in income tax expense in 2016 is primarily due to the release of uncertain tax positions due to lapse of statute
in foreign jurisdiction

[0001193125-18-055988:mdna:93]
Liquidity and Capital Resources

[0001193125-18-055988:mdna:94]
Our principal sources of liquidity have been cash provided by operations, the issuance of convertible senior notes, term debt, senior notes and revolving debt. Our principal uses of cash have been to
finance capital expenditures, finance acquisitions (including the contemplated acquisition of Anaren in fiscal 2018), meet debt service requirements, fund working capital requirements, and refinance existing debt. We anticipate that servicing debt,
financing capital expenditures, financing acquisitions, and funding working capital requirements will continue to be the principal demands on our cash in the future.

[0001193125-18-055988:mdna:95]
Cash flow provided by operating activities during the year ended January 1, 2018 was $332.8 million as compared to $298.3 million in the same period in 2016. The improved cash flow was the
result of stronger operational performance. As of January 1, 2018, we had net working capital of approximately $501.0 million compared to $323.8 million as of January 2, 2017. At January 1, 2018 cash cycle days improved to
38 days as compared to 43 days at January 2, 2017.

[0001193125-18-055988:mdna:96]
Net cash used in investing activities was approximately
$124.1 million for the year ended January 1, 2018 primarily reflecting the purchases of property, plant and equipment of $151.3 million, offset by net of proceeds from sales of property, plant and equipment and assets held for sale of
$27.2 million.

[0001193125-18-055988:mdna:97]
Net cash used in financing activities was approximately $59.0 million for the year ended
January 1, 2018 primarily reflecting proceeds from long-term debt totaling $725.0 million, offset by the repayment of $700.9 million of long-term debt, repayment of $63.0 million of a revolving loan, payment of $8.6 million
for purchase of the non-controlling interest in one of our subsidiaries, and payment of debt issuance costs and original issue discount of $11.6 million associated with the Term Loan Facility and Senior
Notes.

[0001193125-18-055988:mdna:98]
As of January 1, 2018, we had cash and cash equivalents of approximately $409.3 million, of which
approximately $294.2 million was held by our foreign subsidiaries, primarily in Asia.

[0001193125-18-055988:mdna:99]
Our 2018 capital expenditure plan
is expected to be in the range of $150.0 million to $170.0 million.

[0001193125-18-055988:mdna:100]
Long-term Debt and Letters of Credit

[0001193125-18-055988:mdna:101]
On September 28, 2017, we entered into a $350.0 million Term Loan Facility, and issued $375.0 million of Senior Notes. In
conjunction with the issuance of the Term Loan Facility and Senior Notes, we repaid in full the remaining outstanding balance of the 2016 Term Loan and repaid $63.0 million of our existing U.S. ABL.

[0001193125-18-055988:mdna:102]
In conjunction with the pending acquisition of Anaren, we have received commitments to fund a $700.0 million Incremental Facility.
Subsequent to January 1, 2018, we completed the allocation of $600.0 million of commitments from lenders in the syndication for the Incremental Facility, which supercedes the original $700.0 million commitment. The Incremental
Facility would be issued at a discount at 99.75% and have a floating rate of LIBOR plus a margin of 2.5%. Upon the consummation of the acquisition of Anaren, we will use the borrowings from the Incremental Facility and cash on hand to finance such
acquisition.

[0001193125-18-055988:mdna:103]
Term Loan Facility

[0001193125-18-055988:mdna:104]
The Term Loan Facility, of which $3.5 million is included in short-term debt and $345.6 million is included in long-term debt, was issued at a discount at 99.5% and bears interest, at our
option, at a floating rate of LIBOR,

[0001193125-18-055988:mdna:105]
plus an applicable interest margin of 2.5%, or an alternate base rate, (defined as the greater of the JP Morgan prime, the New York Fed bank rate plus 0.9% or LIBOR plus 1%), subject to a 1%
floor plus an applicable margin of 1.5%. At January 1, 2018, the interest rate on the outstanding borrowings under the Term Loan Facility was 4.06%. There is no provision, other than an event of default, for the interest margin to increase. The
Term Loan Facility will mature on September 28, 2024. The Term Loan Facility is secured by a significant amount of our domestic assets and a pledge of 65% of voting stock of our first tier foreign subsidiaries and is structurally senior to our
Senior Notes and Convertible Senior Notes. See Senior Notes and Convertible Senior Notes below.

[0001193125-18-055988:mdna:106]
We are required to make
scheduled payments of the outstanding Term Loan Facility balance on a quarterly basis beginning January 1, 2018. Based on certain parameters defined in the Term Loan Facility, including a First Lien Leverage Ratio, we may be required to make an
additional principal payment on an annual basis beginning after fiscal year 2018, if our First Lien Leverage Ratio is greater than 2.0. Any additional annual payments or prepayments would reduce future required scheduled payments. Any remaining
outstanding balances under the Term Loan Facility are due at the maturity date of September 28, 2024.

[0001193125-18-055988:mdna:107]
Borrowings under
the Term Loan Facility are subject to certain affirmative and negative covenants, including limitations on indebtedness, corporate transactions, investments and dispositions, and share payments. At January 1, 2018, we were in compliance with
the covenants under the Term Loan Facility.

[0001193125-18-055988:mdna:108]
Senior Notes

[0001193125-18-055988:mdna:109]
The $375.0 million of Senior Notes issued, which is included in long-term debt, bear interest at a rate of 5.63% per annum. Interest is payable semiannually in arrears on April 1 and
October 1 of each year beginning April 1, 2018. The Senior Notes will mature on October 1, 2025.

[0001193125-18-055988:mdna:110]
Borrowings
under the Senior Notes are subject to certain affirmative and negative covenants, including limitations on indebtedness, corporate transactions, investments and dispositions, and share payments. At January 1, 2018, we were in compliance with
the covenants under the Senior Notes.

[0001193125-18-055988:mdna:111]
Asset-Based Lending Agreements

[0001193125-18-055988:mdna:112]
We maintain a $200.0 million U.S. ABL, and a $150.0 million Asia Asset-Based Lending Credit Agreement (Asia ABL) (collectively
the ABL Revolving Loans).

[0001193125-18-055988:mdna:113]
The U.S. ABL consists of three tranches comprised of a revolving credit facility of up to
$200.0 million, a letter of credit facility for up to $50.0 million, and swingline loans for up to $30.0 million, provided that at no time may amounts outstanding under the tranches exceed in aggregate $200.0 million or the
applicable borrowing base, which is a percentage of the principal amount of Eligible Accounts, as defined in the U.S. ABL agreement. Borrowings under the U.S. ABL bear interest at either a floating rate of LIBOR plus a margin of 150 basis points or
JP Morgan Chase Bank’s prime rate plus a margin of 50 basis points, at our option. At January 1, 2018, the interest rate on the outstanding borrowings under the U.S. ABL was 3.06%. The applicable margin can vary based on the remaining
availability of the facility, from 125 to 175 basis points for LIBOR-based loans and from 25 to 75 basis points for JP Morgan Chase Bank’s prime rate-based loans. Other than availability and an event of default, there are no other provisions
for the interest margin to increase. The U.S. ABL will mature on May 31, 2020. Loans made under the U.S. ABL are secured first by all of our domestic cash, receivables and certain inventories as well as by a second position against a
significant amount of our domestic assets and a pledge of 65% of voting stock of our first tier foreign subsidiaries and are structurally senior to our Senior Notes and Convertible Senior Notes. See Senior Notes and Convertible Senior Notes
elsewhere in this section. As noted earlier, concurrent with the issuance of the Term Loan Facility and Senior Notes, we paid down $63.0 million of the outstanding balance of our U.S. ABL. At January 1, 2018, $17.0 million of the U.S.
ABL was outstanding and classified as long-term debt, which is consistent with its maturity date.

[0001193125-18-055988:mdna:114]
The Asia ABL consists of two
tranches comprised of a revolving credit facility for up to $150.0 million and a letter of credit facility for up to $100.0 million, provided that at no time may amounts outstanding under both tranches exceed in aggregate
$150.0 million or the applicable borrowing base, which is a percentage of the principal amount of Eligible Accounts, as defined in the Asia ABL agreement. Borrowings under the Asia ABL

[0001193125-18-055988:mdna:115]
bear interest at a floating rate of LIBOR plus 140 basis points. At January 1, 2018, the interest rate on the outstanding borrowings under the Asia ABL was 2.96%. There is no provision,
other than an event of default, for the interest margin to increase. The Asia ABL will mature on May 22, 2020. Loans made under the Asia ABL are secured by a portion of our Asia cash and receivables and are structurally senior to our domestic
obligations, including the Senior Notes and Convertible Senior Notes. See Senior Notes and Convertible Senior Notes elsewhere in this section. At January 1, 2018, $30.0 million of the Asia ABL was outstanding and classified as long-term
debt, which is consistent with its maturity date.

[0001193125-18-055988:mdna:116]
We have up to $50.0 million and $100.0 million Letters of Credit
Facilities under the U.S. ABL and the Asia ABL, respectively. As of January 1, 2018, letters of credit in the amount of $7.6 million were outstanding under the U.S. ABL and $43.1 million were outstanding under the Asia ABL with
various expiration dates through March 2019. Available borrowing capacity under the U.S. ABL and the Asia ABL was $175.4 million and $76.9 million, respectively, which considers letters of credit outstanding at January 1, 2018.

[0001193125-18-055988:mdna:117]
We are required to pay a commitment fee of 0.25% to 0.375% per annum on any unused portion of the ABL Revolving Loans. We
paid commitment fees of $0.8 million, $0.7 million and $0.8 million for the years ended January 1, 2018, January 2, 2017, and December 28, 2015, respectively. Under the occurrence of certain events, the ABL Revolving
Loans are subject to various financial and operational covenants, including maintaining minimum fixed charge coverage ratios. At January 1, 2018, we were in compliance with the covenants under the ABL Revolving Loans.

[0001193125-18-055988:mdna:118]
Chinese Revolver

[0001193125-18-055988:mdna:119]
Additionally, we are party to a revolving loan credit facility (Chinese Revolver) with a lender in China. Under this arrangement, the lender has made available to us approximately $32.2 million in
unsecured borrowing with all terms of the borrowing to be negotiated at the time the Chinese Revolver is drawn upon. There are no commitment fees on the unused portion of the Chinese Revolver, and this arrangement expires in January 2019. As of
January 1, 2018, the Chinese Revolver had not been drawn upon.

[0001193125-18-055988:mdna:120]
Convertible Senior Notes due 2020

[0001193125-18-055988:mdna:121]
We issued 1.75% convertible senior notes due December 15, 2020, in a public offering for an aggregate principal amount of
$250.0 million. The convertible senior notes bear interest at a rate of 1.75% per annum. Interest is payable semiannually in arrears on June 15 and December 15 of each year. The convertible senior notes are senior unsecured
obligations and rank equally to our future unsecured senior indebtedness and senior in right of payment to any of our future subordinated indebtedness. Offering expenses are being amortized to interest expense over the term of the convertible senior
notes.

[0001193125-18-055988:mdna:122]
Conversion:     At any time prior to March 15, 2020, holders may convert their
convertible senior notes into cash and, if applicable, into shares of our common stock based on a conversion rate of 103.7613 shares of our common stock per $1,000 principal amount of convertible senior notes, subject to adjustment, under the
following circumstances: (1) during any calendar quarter beginning after March 31, 2015 (and only during such calendar quarter), if the last reported sale price of our common stock for at least 20 trading days during the 30 consecutive
trading days ending on the last trading day of the immediately preceding calendar quarter is greater than or equal to 130% of the applicable conversion price on each applicable trading day of such preceding calendar quarter; (2) during the five
business day period after any 10 consecutive trading day period in which the trading price per note for each day of that 10 consecutive trading day period was less than 98% of the product of the last reported sale price of our common stock and the
conversion rate on such day; or (3) upon the occurrence of specified corporate transactions described in the indenture governing the notes. As of January 1, 2018, the conversion criteria had been met allowing holders to give notice of
conversion in 2017 and the first quarter of 2018.

[0001193125-18-055988:mdna:123]
On or after March 15, 2020 until the close of business on the third
scheduled trading day preceding the maturity date, holders may convert their notes at any time, regardless of the foregoing circumstances. Upon conversion, for each $1,000 principal amount of notes, we will pay shares of our common stock, cash or a
combination of cash and shares of our common stock at our election, if applicable, based on a daily conversion value calculated on a proportionate basis for each day of the 80 trading day observation period. All conversions

[0001193125-18-055988:mdna:124]
occurring on the same date or on or after March 15, 2020 shall be settled using the same settlement method. Additionally, in the event of a fundamental change as defined in the indenture
governing the notes, or other conversion rate adjustments such as share splits or combinations, other distributions of shares, cash or other assets to stockholders, including self-tender transactions (Other Conversion Rate Adjustments), the
conversion rate may be modified to adjust the number of shares per $1,000 principal amount of the notes. As of January 1, 2018, none of the criteria for a fundamental change or a conversion rate adjustment had been met.

[0001193125-18-055988:mdna:125]
The maximum number of shares issuable upon conversion, including the effect of a fundamental change and subject to Other Conversion Rate
Adjustments, would be 32.4 million.

[0001193125-18-055988:mdna:126]
Note Repurchase:    We are not permitted to redeem
the convertible senior notes at any time prior to maturity. In the event of a fundamental change or certain default events, as defined in the indenture governing the notes, holders may require us to repurchase for cash all or a portion of their
convertible senior notes at a price equal to 100% of the principal amount, plus any accrued and unpaid interest.

[0001193125-18-055988:mdna:127]
In connection
with the issuance of the convertible senior notes due 2020, we entered into a convertible note hedge and warrant transaction (the Call Spread Transaction), with respect to our common stock. The convertible note hedge consists of our option to
purchase up to 25.9 million common stock shares at a price of $9.64 per share. The hedge expires on December 15, 2020 and can only be executed upon the conversion of the above mentioned convertible senior notes due 2020. Additionally, we
sold warrants to purchase 25.9 million shares of our common stock at a price of $14.26 per share. The warrants expire ratably from March 2021 through January 2022. The Call Spread Transaction has no effect on the terms of the convertible senior
notes due 2020 and reduces potential dilution by effectively increasing the conversion price of the convertible senior notes due 2020 to $14.26 per share of our common stock.

[0001193125-18-055988:mdna:128]
Based on our current level of operations, we believe that cash generated from operations, cash on hand and cash from the issuance of term and revolving debt will be adequate to meet our currently
anticipated capital expenditure, debt service, and working capital needs for the next 12 months.

[0001193125-18-055988:mdna:129]
Contractual Obligations and Commitments

[0001193125-18-055988:mdna:130]
The following table provides information on our contractual obligations as of January 1, 2018:

[0001193125-18-055988:mdna:131]
| Contractual Obligations(1) |  | Total |  |  | Less Than1 Year |  |  | 1 - 3Years |  |  | 4 - 5Years |  |  | After5 Years |  |
|  |  | (In thousands) |  |
| Long-term debt obligations |  | $ | 773,044 |  |  | $ | 4,578 |  |  | $ | 53,966 |  |  | $ | 7,875 |  |  | $ | 706,625 |  |
| Convertible debt obligations |  |  | 249,985 |  |  |  | — |  |  |  | 249,985 |  |  |  | — |  |  |  | — |  |
| Interest on debt obligations |  |  | 279,701 |  |  |  | 41,667 |  |  |  | 81,171 |  |  |  | 70,032 |  |  |  | 86,831 |  |
| Equipment payables |  |  | 59,049 |  |  |  | 58,465 |  |  |  | 584 |  |  |  | — |  |  |  | — |  |
| Purchase obligations |  |  | 104,779 |  |  |  | 94,433 |  |  |  | 1,764 |  |  |  | 610 |  |  |  | 7,972 |  |
| Operating lease commitments |  |  | 38,110 |  |  |  | 18,604 |  |  |  | 9,146 |  |  |  | 4,173 |  |  |  | 6,187 |  |
| Total contractual obligations |  | $ | 1,504,668 |  |  | $ | 217,747 |  |  | $ | 396,616 |  |  | $ | 82,690 |  |  | $ | 807,615 |  |

[0001193125-18-055988:mdna:132]
| (1) | Unrecognized uncertain tax benefits of $38.8 million are not included in the table above as the settlement timing is uncertain. |

[0001193125-18-055988:mdna:133]
Off Balance Sheet Arrangements

[0001193125-18-055988:mdna:134]
We do not currently have, nor have we ever had, any relationships with unconsolidated entities or financial partnerships, such as entities often referred to as structured finance or special purpose
entities, which would have been established for the purpose of facilitating off-balance sheet arrangements or other contractually narrow or limited purposes. In addition, we do not engage in trading activities
involving non-exchange traded contracts. As a result, we are not materially exposed to any financing, liquidity, market, or credit risk that could arise if we had engaged in these relationships.

[0001193125-18-055988:mdna:135]
Seasonality

[0001193125-18-055988:mdna:136]
Orders for our products generally correspond to the production schedules of our customers. We historically experience higher net sales in the third and fourth quarters due to end customer demand in the
fourth quarter for consumer electronics products. Seasonal fluctuations also include the Chinese New Year holidays in the first quarter, which typically results in lower net sales. We attribute this decline to shutdowns of our customers’ and
our own China based manufacturing facilities surrounding the Chinese New Year public holidays, which normally occur in January or February of each year.

[0001193125-18-055988:mdna:137]
Recently Issued Accounting Standards

[0001193125-18-055988:mdna:138]
In August 2017, the Financial
Accounting Standards Board (FASB) issued ASU 2017-12, Derivatives and Hedging (Topic 815): Targeted Improvements to Accounting for Hedging Activities. This ASU amends and simplifies existing guidance in
order to allow companies to more accurately present the economic effects of risk management activities in the financial statements. ASU 2017-12 also amends the guidance surrounding the recognition of the value
of hedged instruments to include the entire change in value, rather than just the effective portion, in other comprehensive income and recognized in earnings at the same time that the hedged item affects earnings for cash flow and net investment
hedges. This ASU is effective for fiscal years beginning after December 15, 2018, including interim periods within those fiscal years. Early adoption is permitted. We are currently evaluating the new guidance to determine the impact it may have
on our consolidated financial statements and related disclosures.

[0001193125-18-055988:mdna:139]
In January 2017, the FASB issued ASU 2017-04, Intangibles (Topic 350): Goodwill and Other. This ASU simplifies the accounting for goodwill impairment and removes Step 2 of the goodwill impairment test. Goodwill impairment will now be
the amount by which a reporting unit’s carrying value exceeds its fair value limited to the total amount of goodwill allocated to that reporting unit. Entities will continue to have the option to perform a qualitative assessment to determine if
a quantitative impairment test is necessary. We elected to early adopt ASU 2017-04 on a prospective basis during the second quarter of 2017, and the adoption did not have a material impact on our
consolidated financial statements and related disclosures.

[0001193125-18-055988:mdna:140]
In January 2017, the FASB issued ASU
2017-01, Business Combinations (Topic 805): Clarifying the Definition of a Business. The purpose of this ASU is to clarify the definition of a business to
assist entities with evaluating whether transactions should be accounted for as acquisitions (or disposals) of assets or businesses. We elected to early adopt ASU 2017-01 on a prospective basis during the
fourth quarter of 2017, and the adoption did not have a material impact on our consolidated financial statements and related disclosures.

[0001193125-18-055988:mdna:141]
In October 2016, the FASB issued ASU 2016-16, Income Taxes (Topic 740): Intra-Entity Transfers of Assets Other Than Inventory. The objective of this update
is to improve the accounting for the income tax consequences of intra-entity transfers of assets other than inventory by recognizing the income tax consequences when the transfer occurs. This ASU is effective for fiscal years beginning after
December 15, 2017, including interim periods within those fiscal years. Early adoption is permitted. The adoption of this standard is not expected to have a material impact on our consolidated financial statements or related disclosures.

[0001193125-18-055988:mdna:142]
In August 2016, the FASB issued ASU 2016-15, Statement of Cash Flows (Topic
230). The objective of this update is to add or clarify guidance on the classification of certain cash receipts and payments in the statement of cash flows. We adopted this ASU 2016-15 in the first quarter
of 2017 and the adoption did not have a material impact on our consolidated financial statements and related disclosures.

[0001193125-18-055988:mdna:143]
In
March 2016, the FASB issued ASU 2016-09, Stock Compensation (Topic 718): Improvements to Employee Share-Based Payment Accounting. The objective of this update is to simplify several aspects of the
accounting for employee share-based payment transactions, including the income tax consequences, classification of awards as either equity or liabilities, and classification on the statement of cash flows. We adopted ASU 2016-09 during the first quarter of 2017. The adoption did not have a material impact on our consolidated financial statements and related disclosures.

[0001193125-18-055988:mdna:144]
In February 2016, the FASB issued ASU 2016-02, Leases (Topic 842). The objective of this
update is to increase transparency and comparability among organizations by recognizing lease assets and lease liabilities on

[0001193125-18-055988:mdna:145]
the balance sheet and disclosing key information about leasing arrangements. This ASU is effective for fiscal years beginning after December 15, 2018, including interim periods within those
annual periods and is to be applied utilizing a modified retrospective approach. While we continue to evaluate the new guidance to determine the impact it may have on our consolidated financial statements and related disclosures, the primary effect
of adopting this update will be to record assets and obligations for current operating leases.

[0001193125-18-055988:mdna:146]
In January 2016, the FASB
issued ASU 2016-01, Financial Instruments—Overall (Topic 825): Recognition and Measurement of Financial Assets and Financial Liabilities. This ASU amends certain aspects of recognition,
measurement, presentation and disclosure of financial instruments, and supersedes the guidance to classify equity securities with readily determinable fair values into different categories (that is, trading or available-for-sale) and requires equity securities to be measured at fair value with changes in the fair value recognized through net income. This ASU is effective for annual and interim periods beginning
after December 15, 2017. We do not anticipate the adoption will have a material impact on our consolidated financial statements and related disclosures.

[0001193125-18-055988:mdna:147]
In May 2014, the FASB issued ASU 2014-09, Revenue from Contracts with Customers, as amended, which requires an entity to recognize the amount of revenue to
which it expects to be entitled for the transfer of promised goods or services to customers. The ASU will replace most existing revenue recognition guidance in U.S. GAAP when it becomes effective. The new standard is effective for us at the
beginning of fiscal year 2018. The standard permits the use of either the retrospective or cumulative effect transition method. We have assessed that the impact of the new guidance will result in a change to the timing of revenue recognition for our
revenue stream from “point in time” upon physical delivery to an “over time” model and this transition will have a material impact on our consolidated financial statements upon adoption. As of January 2, 2018, we will apply
the cumulative effect transition method and currently estimate that the adoption will increase retained earnings by a range of $30.0 million to $40.0 million and contract assets by a range of $250.0 million to $270.0 million for
2017. We have identified and implemented changes to our revenue processes and internal controls to meet the ASU’s reporting and disclosure requirements.
