# TTMI notes — 0001193125-16-671832


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001193125-16-671832:notes:1]
(12) Commitments and
 Contingencies

[0001193125-16-671832:notes:2]
Legal
 Matters

[0001193125-16-671832:notes:3]
The
 Company is subject to various legal matters, which it considers
 normal for its business activities. While the Company currently
 believes that the amount of any reasonably possible loss for known
 matters would not be material to the Company’s financial
 condition, the outcome of these actions is inherently difficult to
 predict. In the event of an adverse outcome, the ultimate potential
 loss could have a material adverse effect on the Company’s
 financial condition or results of operations in a particular
 period. The Company has accrued amounts for its loss contingencies
 which are probable and estimable as of June 27, 2016 and
 December 28, 2015. However, these amounts are not material to
 the consolidated condensed financial statements of the
 Company.

[0001193125-16-671832:notes:4]
Environmental
 Matters

[0001193125-16-671832:notes:5]
The
 process to manufacture PCBs requires adherence to city, county,
 state, federal, and foreign environmental regulations regarding the
 storage, use, handling, and disposal of chemicals, solid wastes,
 and other hazardous materials, as well as compliance with air
 quality standards and chemical use reporting. The Company believes
 that its facilities in the United States, Canada and Mexico comply
 in all material respects with applicable environmental laws and
 regulations. In China, governmental authorities have adopted new
 rules and regulations governing environmental issues. An update to
 the Chinese environmental waste water law was issued in late 2012,
 allowing for an interim period in which plants subject to such law
 may install equipment that meets the new regulatory regime. Some of
 the Company’s plants in China are not yet in full compliance
 with the updated environmental regulations. The Company believes it
 has developed plans acceptable to the Chinese government and is in
 the process of implementing these plans. The Company does not
 anticipate any immediate risk of government fines or temporary
 closure of its Chinese plants. The Company has established and
 enacted an investment plan related to the efforts to come into full
 compliance with the new regulations. The 2016 capital expenditure
 costs expected for these plans are included in the Company’s
 capital expenditure projections.


## us-gaap:ConvertibleDebtTableTextBlock

[0001193125-16-671832:notes:6]
As of
 June 27, 2016 and December 28, 2015, the following summarizes
 the equity components of the convertible senior notes included in
 additional paid-in capital:

[0001193125-16-671832:notes:7]
|  |  | As of June 27, 2016 and December 28, 2015 |  |
|  |  | Embedded conversion option — Convertible Senior Notes |  |  | Embedded conversion option — Convertible Senior Notes Issuance Costs |  |  | Total |  |
|  |  | (in thousands) |  |
| Convertible senior notes due 2020 |  | $ | 60,227 |  |  | $ | (1,916 | ) |  | $ | 58,311 |  |


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001193125-16-671832:notes:8]
[same as prior period, unchanged from 0001193125-16-582073:notes:21]

[0001193125-16-671832:notes:9]
[same as prior period, unchanged from 0001193125-16-582073:notes:22]

[0001193125-16-671832:notes:10]
|  |  | Quarter Ended |  |  | Two Quarters Ended |  |
|  |  | June 27, 2016 |  |  | June 29, 2015 |  |  | June 27, 2016 |  |  | June 29, 2015 |  |
|  |  | (In thousands) |  |
| Cost of goods sold |  | $ | 429 |  |  | $ | 243 |  |  | $ | 749 |  |  | $ | 468 |  |
| Selling and marketing |  |  | 271 |  |  |  | 269 |  |  |  | 481 |  |  |  | 540 |  |
| General and administrative |  |  | 2,145 |  |  |  | 1,802 |  |  |  | 3,861 |  |  |  | 3,346 |  |
| Stock-based compensation expense recognized |  | $ | 2,845 |  |  | $ | 2,314 |  |  | $ | 5,091 |  |  | $ | 4,354 |  |

[0001193125-16-671832:notes:11]
[same as prior period, unchanged from 0001193125-16-582073:notes:24]

[0001193125-16-671832:notes:12]
[same as prior period, unchanged from 0001193125-16-582073:notes:25]

[0001193125-16-671832:notes:13]
The Company records stock-based compensation expense for PRU
 awards granted based on management’s periodic assessment of
 the probability of the PRU awards vesting. For the quarters and two
 quarters ended June 27, 2016, management determined that vesting of
 the PRU awards was probable. PRUs activity for the two quarters
 ended June 27, 2016 was as follows:

[0001193125-16-671832:notes:14]
|  |  | Shares |  |  | Weighted Average Fair Value |  |
|  |  | (In thousands) |  |  |  |  |
| Outstanding target shares at December 28, 2015 |  |  | 301 |  |  | $ | 8.58 |  |
| Granted |  |  | 347 |  |  |  | 6.46 |  |
| Change in units due to annual financial target performance achievement |  |  | — |  |  |  | — |  |
| Outstanding target shares at June 27, 2016 |  |  | 648 |  |  | $ | 7.45 |  |

[0001193125-16-671832:notes:15]
[same as prior period, unchanged from 0001193125-16-582073:notes:31]

[0001193125-16-671832:notes:16]
The Company granted 131 and 331 RSUs during the quarters ended
 June 27, 2016 and June 29, 2015, respectively, and 1,814 and 1,301
 RSUs during the two quarters ended June 27, 2016 and June 29, 2015,
 respectively. The RSUs granted have a weighted-average fair value
 per unit of $6.53 and $10.19 for the quarters ended June 27, 2016
 and June 29, 2015, respectively, and $6.74 and $9.15 for the
 two quarters ended June 27, 2016 and June 29, 2015, respectively.
 The fair value for RSUs granted is based on the closing share price
 of the Company’s common stock on the date of
 grant.

[0001193125-16-671832:notes:17]
[same as prior period, unchanged from 0001193125-16-582073:notes:33]

[0001193125-16-671832:notes:18]
The Company did not grant any stock option awards during the
 quarters and two quarters ended June 27, 2016 and June 29,
 2015.

[0001193125-16-671832:notes:19]
[same as prior period, unchanged from 0001193125-16-582073:notes:35]

[0001193125-16-671832:notes:20]
The following is a summary of total unrecognized compensation
 costs as of June 27, 2016:

[0001193125-16-671832:notes:21]
|  |  | Unrecognized Stock-Based Compensation Cost |  |  | Remaining Weighted Average Recognition Period |  |
|  |  | (In thousands) |  |  | (years) |  |
| RSU awards |  | $ | 16,427 |  |  |  | 1.5 |  |
| PRU awards |  |  | 2,636 |  |  |  | 1.7 |  |
|  |  | $ | 19,063 |  |  |  |  |  |


## us-gaap:DisposalGroupsIncludingDiscontinuedOperationsDisclosureTextBlock

[0001193125-16-671832:notes:22]
[same as prior period, unchanged from 0001193125-16-582073:notes:47]

[0001193125-16-671832:notes:23]
During
 the quarter ended June 29, 2015, the Company sold its Meadville
 Aspocomp (Suzhou) Electronic Co., Ltd. subsidiary, which held its
 Suzhou, China manufacturing facility, for $21,275 and recognized a
 gain of $2,504. This subsidiary was included in the Company’s
 PCB operating segment.


## us-gaap:InventoryDisclosureTextBlock

[0001193125-16-671832:notes:24]
[same as prior period, unchanged from 0001193125-16-582073:notes:16]

[0001193125-16-671832:notes:25]
Inventories as of June 27, 2016 and December 28, 2015
 consisted of the following:

[0001193125-16-671832:notes:26]
|  |  | As of |  |
|  |  | June 27, 2016 |  |  | December 28, 2015 |  |
|  |  | (In thousands) |  |
| Inventories: |  |  |  |  |  |  |  |  |
| Raw materials |  | $ | 66,631 |  |  | $ | 70,577 |  |
| Work-in-process |  |  | 109,414 |  |  |  | 97,193 |  |
| Finished goods |  |  | 94,745 |  |  |  | 101,153 |  |
|  |  | $ | 270,790 |  |  | $ | 268,923 |  |


## us-gaap:NewAccountingPronouncementsPolicyPolicyTextBlock

[0001193125-16-671832:notes:27]
Recently Adopted and
 Issued Accounting Standards

[0001193125-16-671832:notes:28]
In
 March 2016, the Financial Accounting Standards Board (FASB) issued
 Accounting Standards Update (ASU) 2016-09, Stock Compensation
 (Topic 718): Improvements to Employee Share-Based Payment
 Accounting. The objective of this update is to simplify several
 aspects of the accounting for employee share-based payment
 transactions, including the income tax consequences, classification
 of awards as either equity or liabilities, and classification on
 the statement of cash flows. This ASU is effective for fiscal years
 beginning after December 15, 2016, including interim periods within
 those fiscal years. Early adoption is permitted. The Company is
 currently evaluating the new guidance to determine the impact it
 may have on its consolidated financial statements and related
 disclosures.

[0001193125-16-671832:notes:29]
In
 February 2016, the FASB issued ASU 2016-02, Leases (Topic
 842). The objective of this update is to increase transparency
 and comparability among organizations by recognizing lease assets
 and lease liabilities on the balance sheet and disclosing key
 information about leasing arrangements. This ASU is effective for
 fiscal years beginning after December 15, 2018, including interim
 periods within those annual periods and is to be applied utilizing
 a modified retrospective approach. The Company is currently
 evaluating the new guidance to determine the impact it may have on
 its consolidated financial statements and related
 disclosures.

[0001193125-16-671832:notes:30]
In
 April 2015, the FASB issued ASU 2015-03, Imputation of
 Interest, as amended, which requires an entity to record debt
 issuance costs related to debt reported in the balance sheet as a
 direct deduction from the face amount of that debt. The update is
 effective for annual periods ending after December 15, 2015.
 The standard requires the use of the retrospective transition
 method. The Company adopted the new standard in the first quarter
 of 2016. Accordingly, as of June 27, 2016, approximately $27,558 of
 unamortized debt issuance costs were presented as a reduction of
 long-term debt on the Company’s consolidated condensed
 balance sheets. Furthermore, the Company reclassified approximately
 $31,171 of unamortized debt issuance costs that had been presented
 as other non-current assets as of December 28, 2015.

[0001193125-16-671832:notes:31]
In May
 2014, the FASB issued ASU 2014-09, Revenue from Contracts with
 Customers, as amended, which requires an entity to recognize
 the amount of revenue to which it expects to be entitled for the
 transfer of promised goods or services to customers. The ASU will
 replace most existing revenue recognition guidance in U.S. GAAP
 when it becomes effective. The new standard is effective for the
 Company at the beginning of fiscal year 2018, however application
 of the standard is allowed as early as the beginning of fiscal
 2017. The standard permits the use of either the retrospective or
 cumulative effect transition method. The Company is evaluating the
 effect that ASU 2014-09 will have on its consolidated financial
 statements and related disclosures. The Company has not yet
 selected a transition method nor has it determined the effect of
 the standard on its ongoing financial reporting.


## us-gaap:ReclassificationOutOfAccumulatedOtherComprehensiveIncomeTableTextBlock

[0001193125-16-671832:notes:32]
The following provides a summary of reclassifications out of
 accumulated other comprehensive income (loss) for the quarters and
 two quarters ended June 27, 2016 and June 29, 2015:

[0001193125-16-671832:notes:33]
|  |  |  |  | Amount Reclassified from Accumulated Other Comprehensive Income |  |
|  |  |  |  | For the Quarter Ended |  |  | For the Two Quarters Ended |  |
| Details about Accumulated Other Comprehensive Income Components |  | Statement of Operations Location |  | June 27, 2016 |  |  | June 29, 2015 |  |  | June 27, 2016 |  |  | June 29, 2015 |  |
| Gain on foreign currency translation |  | Gain on sale of assets, net of tax |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | (1,786 | ) |
| Loss on cash flow hedges |  | Depreciation expense, net of tax |  | $ | 39 |  |  | $ | 43 |  |  | $ | 81 |  |  | $ | 85 |  |


## us-gaap:ReconciliationOfOperatingProfitLossFromSegmentsToConsolidatedTextBlock

[0001193125-16-671832:notes:34]
The
 Company accounts for inter-segment sales and transfers consistent
 with the Company’s revenue recognition policy. The
 inter-segment sales for the quarters and two quarters ended June
 27, 2016 and June 29, 2015, are sales primarily from the PCB to the
 E-M Solutions operating segment.

[0001193125-16-671832:notes:35]
|  |  | Quarter Ended |  |  | Two Quarters Ended |  |
|  |  | June 27, 2016 |  |  | June 29, 2015 |  |  | June 27, 2016 |  |  | June 29, 2015 |  |
|  |  | (In thousands) |  |
| Net Sales: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| PCB |  | $ | 563,574 |  |  | $ | 417,901 |  |  | $ | 1,093,519 |  |  | $ | 728,225 |  |
| E-M Solutions |  |  | 40,427 |  |  |  | 28,514 |  |  |  | 96,905 |  |  |  | 47,796 |  |
| Total sales |  |  | 604,001 |  |  |  | 446,415 |  |  |  | 1,190,424 |  |  |  | 776,201 |  |
| Inter-segment sales |  |  | (2,154 | ) |  |  | (970 | ) |  |  | (5,319 | ) |  |  | (1,592 | ) |
| Total net sales |  | $ | 601,847 |  |  | $ | 445,445 |  |  | $ | 1,185,105 |  |  | $ | 774,609 |  |
| Operating Segment Income (Loss): |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| PCB |  | $ | 64,970 |  |  | $ | 30,456 |  |  | $ | 114,337 |  |  | $ | 53,716 |  |
| E-M Solutions |  |  | (153 | ) |  |  | (110 | ) |  |  | 234 |  |  |  | 541 |  |
| Corporate |  |  | (24,189 | ) |  |  | (33,496 | ) |  |  | (49,094 | ) |  |  | (47,268 | ) |
| Total operating segment income (loss) |  |  | 40,628 |  |  |  | (3,150 | ) |  |  | 65,477 |  |  |  | 6,989 |  |
| Amortization of definite-lived intangibles |  |  | (5,949 | ) |  |  | (3,910 | ) |  |  | (11,896 | ) |  |  | (5,784 | ) |
| Total operating income (loss) |  |  | 34,679 |  |  |  | (7,060 | ) |  |  | 53,581 |  |  |  | 1,205 |  |
| Total other expense |  |  | (16,893 | ) |  |  | (12,899 | ) |  |  | (37,468 | ) |  |  | (19,079 | ) |
| Income (loss) before income taxes |  | $ | 17,786 |  |  | $ | (19,959 | ) |  | $ | 16,113 |  |  | $ | (17,874 | ) |


## us-gaap:RestructuringImpairmentAndOtherActivitiesDisclosureTextBlock

[0001193125-16-671832:notes:36]
[same as prior period, unchanged from 0001193125-16-582073:notes:84]

[0001193125-16-671832:notes:37]
On September 29, 2015, the Company announced a
 consolidation plan that will result in the closure of the
 Company’s facilities in Cleveland, Ohio, Milpitas, California
 and Juarez, Mexico (the Consolidation Plan) and the layoff of
 approximately 480 employees at these sites. The Consolidation Plan
 is part of the Company’s integration strategy to improve
 total plant utilization, operational performance and customer focus
 following its acquisition of Viasystems. In accordance with the
 Consolidation Plan, the Company will combine its Cleveland and
 Milpitas facilities into its North Jackson, Ohio and Silicon
 Valley, California facilities, respectively, and close its Juarez
 facility.

[0001193125-16-671832:notes:38]
In connection with the Consolidation Plan and other global
 realignment restructuring efforts, the Company recognized employee
 separation costs and contract termination and other costs during
 the quarter and two quarters ended June 27, 2016. Contract
 termination and other costs primarily represented plant closure
 costs for Cleveland, Ohio, Milpitas, California and Juarez, Mexico,
 as well as costs related to building operating leases associated
 with the downsizing of the St. Louis, Missouri office.

[0001193125-16-671832:notes:39]
The below table summarizes such restructuring costs by
 operating segment:

[0001193125-16-671832:notes:40]
|  |  | Quarter Ended June 27, 2016 |  |  | Two Quarters Ended June 27, 2016 |  |
|  |  | Employee separation/ severance |  |  | Contract termination and other costs |  |  | Total |  |  | Employee separation/ severance |  |  | Contract termination and other costs |  |  | Total |  |
|  |  | (In thousands) |  |
| Operating Segment: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| PCB |  | $ | 668 |  |  | $ | 488 |  |  | $ | 1,156 |  |  | $ | 1,267 |  |  | $ | 1,100 |  |  | $ | 2,367 |  |
| E-M Solutions |  |  | 578 |  |  |  | 1,425 |  |  |  | 2,003 |  |  |  | 734 |  |  |  | 1,944 |  |  |  | 2,678 |  |
| Corporate |  |  | 40 |  |  |  | 790 |  |  |  | 830 |  |  |  | 9 |  |  |  | 848 |  |  |  | 857 |  |
|  |  | $ | 1,286 |  |  | $ | 2,703 |  |  | $ | 3,989 |  |  | $ | 2,010 |  |  | $ | 3,892 |  |  | $ | 5,902 |  |

[0001193125-16-671832:notes:41]
The below table shows the utilization of the accrued
 restructuring costs during the two quarters ended June 27,
 2016:

[0001193125-16-671832:notes:42]
|  |  | Employee separation/ severance |  |  | Contract termination and other costs |  |  | Total |  |
|  |  | (In thousands) |  |
| Accrued at December 28, 2015 |  | $ | 6,044 |  |  | $ | 535 |  |  | $ | 6,579 |  |
| Charged to expense |  |  | 2,010 |  |  |  | 3,892 |  |  |  | 5,902 |  |
| Amount paid |  |  | (6,802 | ) |  |  | (3,085 | ) |  |  | (9,887 | ) |
| Accrued at June 27, 2016 |  | $ | 1,252 |  |  | $ | 1,342 |  |  | $ | 2,594 |  |

[0001193125-16-671832:notes:43]
As of June 27, 2016, the remaining accrual for employee
 separation/severance, which relates to employees yet to be
 separated, was included as a component of accrued salaries, wages
 and benefits and the remaining unpaid estimated contract
 termination and other costs are included as a component of other
 accrued expenses in the consolidated condensed balance sheet. The
 Company expects the remaining employees to be separated and the
 remaining accrued restructuring costs to be substantially paid out
 by December 2016.

[0001193125-16-671832:notes:44]
As of June 27, 2016, the Company has incurred approximately
 $13,283 of restructuring charges since the September 29, 2015
 announcement and estimates that it will incur total charges of
 approximately $15,000 to $20,000 related to these closures and
 global realignment efforts.

[0001193125-16-671832:notes:45]
The Company also recognized $3,346 in impairment charges during
 the two quarters ended June 27, 2016. As a result of the above
 mentioned plant closures and other plant realignment efforts,
 $1,393 of impairment charges were recognized in the consolidated
 condensed statement of operations related to machinery and
 equipment in the PCB operating segment for the two quarters ended
 June 27, 2016. Additionally, the Company expensed $1,953 of
 capitalized software costs in the Corporate operating segment
 during the two quarters ended June 27, 2016.


## us-gaap:ScheduleOfAccumulatedOtherComprehensiveIncomeLossTableTextBlock

[0001193125-16-671832:notes:46]
The following provides a summary of the components of
 accumulated other comprehensive income (loss) as of June 27, 2016
 and December 28, 2015:

[0001193125-16-671832:notes:47]
|  |  | Foreign Currency Translation |  |  | Gains (Losses) on Cash Flow Hedges |  |  | Total |  |
|  |  | (In thousands) |  |
| Ending balance at December 28, 2015 |  | $ | 2,895 |  |  | $ | (1,272 | ) |  | $ | 1,623 |  |
| Other comprehensive loss before reclassifications |  |  | (13,711 | ) |  |  | (21 | ) |  |  | (13,732 | ) |
| Amounts reclassified from accumulated other comprehensive income |  |  | — |  |  |  | 81 |  |  |  | 81 |  |
| Other comprehensive (loss) income |  |  | (13,711 | ) |  |  | 60 |  |  |  | (13,651 | ) |
| Ending balance at June 27, 2016 |  | $ | (10,816 | ) |  | $ | (1,212 | ) |  | $ | (12,028 | ) |


## us-gaap:ScheduleOfBusinessAcquisitionsByAcquisitionTextBlock

[0001193125-16-671832:notes:48]
The
 following summarizes the components of the purchase
 price:

[0001193125-16-671832:notes:49]
|  |  | (In thousands) |  |
| Value of TTM common stock issued |  | $ | 149,006 |  |
| Cash consideration |  |  | 248,824 |  |
|  |  |  | 397,830 |  |
| Debt assumed |  |  | 669,024 |  |
| Enterprise value |  | $ | 1,066,854 |  |


## us-gaap:ScheduleOfDebtInstrumentsTextBlock

[0001193125-16-671832:notes:50]
The following table summarizes the long-term debt of the
 Company as of June 27, 2016 and December 28, 2015:

[0001193125-16-671832:notes:51]
|  |  | Average Effective Interest Rate as of June 27, 2016 |  |  | June 27, 2016 |  |  | Average Effective Interest Rate as of December 28, 2015 |  |  | December 28, 2015 |  |
|  |  | (In thousands) |  |
| Term loan due May 2021 |  |  | 6.00% |  |  | $ | 841,143 |  |  |  | 6.00% |  |  | $ | 947,625 |  |
| U.S. ABL revolving loan due May 2020 |  |  | 2.21% |  |  |  | 80,000 |  |  |  | 2.17% |  |  |  | 80,000 |  |
| Convertible senior notes due December 2020 |  |  | 1.75% |  |  |  | 250,000 |  |  |  | 1.75% |  |  |  | 250,000 |  |
| Capital lease |  |  | 6.43% |  |  |  | 2,042 |  |  |  |  |  |  |  | — |  |
|  |  |  |  |  |  |  | 1,173,185 |  |  |  |  |  |  |  | 1,277,625 |  |
| Less: Long-term debt unamortized discount |  |  |  |  |  |  | (68,062 | ) |  |  |  |  |  |  | (75,668 | ) |
| Long-term debt unamortized debt issuance costs |  |  |  |  |  |  | (27,558 | ) |  |  |  |  |  |  | (31,171 | ) |
|  |  |  |  |  |  |  | 1,077,565 |  |  |  |  |  |  |  | 1,170,786 |  |
| Less: current maturities |  |  |  |  |  |  | (80,358 | ) |  |  |  |  |  |  | (157,375 | ) |
| Long-term debt, less current maturities |  |  |  |  |  | $ | 997,207 |  |  |  |  |  |  | $ | 1,013,411 |  |


## us-gaap:IncomeTaxDisclosureTextBlock

[0001193125-16-671832:notes:52]
[same as prior period, unchanged from 0001193125-16-582073:notes:107]

[0001193125-16-671832:notes:53]
[same as prior period, unchanged from 0001193125-16-582073:notes:108]

[0001193125-16-671832:notes:54]
During
 the quarter and two quarters ended June 27, 2016, the
 Company’s effective tax rate was impacted by a net discrete
 benefit of $5,942 and $6,494, respectively, related to (i) tax
 holiday benefits, (ii) release of uncertain tax positions due to
 expiration of statute of limitations in foreign jurisdiction, and
 (iii) accrued interest on existing uncertain tax positions.
 Additionally, no tax benefit was recorded on the losses incurred in
 the U.S. and certain foreign jurisdictions as a result of
 corresponding increases in the valuation allowances in these
 jurisdictions. The Company’s foreign earnings attributable to
 certain foreign subsidiaries will be indefinitely reinvested in
 such foreign jurisdictions and, therefore, no deferred tax
 liabilities for U.S. income taxes on undistributed earnings are
 recorded.

[0001193125-16-671832:notes:55]
Certain entities in China operated under tax incentives
 effective through 2016. For the quarter and two quarters ended June
 27, 2016, the tax incentives decreased Chinese taxes by
 approximately $2,861 and $4,525, respectively, which increased
 basic earnings per share by $0.03 and $0.05, and increased diluted
 earnings per share by $0.02 and $0.04, respectively.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0001193125-16-671832:notes:56]
[same as prior period, unchanged from 0001193125-16-582073:notes:103]

[0001193125-16-671832:notes:57]
TTM
 Technologies, Inc. (the Company or TTM) is a leading global printed
 circuit board (PCB) manufacturer, focusing on quick-turn and
 technologically advanced PCBs and electro-mechanical solutions (E-M
 Solutions). The Company provides time-to-market and advanced
 technology products and offers a one-stop manufacturing solution to
 customers from engineering support to prototype development through
 final volume production. This one-stop manufacturing solution
 allows the Company to align technology developments with the
 diverse needs of the Company’s customers and to enable them
 to reduce the time required to develop new products and bring them
 to market.

[0001193125-16-671832:notes:58]
The
 Company serves a diversified customer base in various markets
 throughout the world, including manufacturers of
 networking/communications infrastructure products, tablets and
 smartphones, as well as the aerospace and defense, automotive
 components, high-end computing, and medical, industrial and
 instrumentation related products. The Company’s customers
 include both original equipment manufacturers (OEMs) and electronic
 manufacturing services (EMS) providers.

[0001193125-16-671832:notes:59]
The
 accompanying consolidated condensed financial statements have been
 prepared by the Company, without audit, pursuant to the rules and
 regulations of the Securities and Exchange Commission (SEC).
 Certain information and disclosures normally included in financial
 statements prepared in accordance with accounting principles
 generally accepted in the United States of America (U.S. GAAP) have
 been condensed or omitted pursuant to such rules and regulations.
 These consolidated condensed financial statements reflect all
 adjustments (consisting only of normal recurring adjustments)
 which, in the opinion of management, are necessary to present
 fairly the financial position, the results of operations and cash
 flows of the Company for the periods presented. It is suggested
 that these consolidated condensed financial statements be read in
 conjunction with the consolidated financial statements and the
 notes thereto included in the Company’s most recent Annual
 Report on Form 10-K. The results of operations for the interim
 periods are not necessarily indicative of the results to be
 expected for the full year. The preparation of financial statements
 in accordance with U.S. GAAP requires management to make estimates
 and assumptions that affect the amounts reported in the
 Company’s consolidated condensed financial statements and
 accompanying notes. Actual results could differ materially from
 those estimates. The Company uses a 52/53 week fiscal calendar with
 the fourth quarter ending on the Monday nearest December 31.
 Fiscal 2015 was a 52 week year. Fiscal 2016 will be a 53 week year
 with the additional week included in the fourth quarter.


## us-gaap:ScheduleOfEarningsPerShareBasicAndDilutedTableTextBlock

[0001193125-16-671832:notes:60]
The
 following is a reconciliation of the numerator and denominator used
 to calculate basic earnings (loss) per share and diluted earnings
 (loss) per share for the quarters and two quarters ended June 27,
 2016 and June 29, 2015:

[0001193125-16-671832:notes:61]
|  |  | Quarter Ended |  |  | Two Quarters Ended |  |
|  |  | June 27, 2016 |  |  | June 29, 2015 |  |  | June 27, 2016 |  |  | June 29, 2015 |  |
|  |  | (In thousands, except per share amounts) |  |
| Basic earning (loss): |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic earning (loss) |  | $ | 18,548 |  |  | $ | (36,612 | ) |  | $ | 11,284 |  |  | $ | (33,166 | ) |
| Diluted earning (loss): |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Net income (loss) attributable to TTM Technologies, Inc. stockholders |  | $ | 18,548 |  |  | $ | (36,612 | ) |  | $ | 11,284 |  |  | $ | (33,166 | ) |
| Interest expense from convertible senior notes, net of tax |  |  | 3,285 |  |  |  | — |  |  |  | — |  |  |  | — |  |
| Diluted earnings (loss) |  | $ | 21,833 |  |  | $ | (36,612 | ) |  | $ | 11,284 |  |  | $ | (33,166 | ) |
| Basic shares |  |  | 100,170 |  |  |  | 88,834 |  |  |  | 99,883 |  |  |  | 86,218 |  |
| Dilutive effect of performance-based stock units, restricted stock units and stock options |  |  | 840 |  |  |  | — |  |  |  | 907 |  |  |  | — |  |
| Dilutive effect of assumed conversion of convertible senior notes outstanding |  |  | 25,940 |  |  |  | — |  |  |  | — |  |  |  | — |  |
| Diluted shares |  |  | 126,950 |  |  |  | 88,834 |  |  |  | 100,790 |  |  |  | 86,218 |  |
| Income (loss) per share attributable to TTM Technologies, Inc. stockholders: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  | $ | 0.19 |  |  | $ | (0.41 | ) |  | $ | 0.11 |  |  | $ | (0.38 | ) |
| Diluted |  | $ | 0.17 |  |  | $ | (0.41 | ) |  | $ | 0.11 |  |  | $ | (0.38 | ) |


## us-gaap:ScheduleOfMaturitiesOfLongTermDebtTableTextBlock

[0001193125-16-671832:notes:62]
The
 fiscal calendar maturities of long-term debt through 2020 and
 thereafter are as follows:

[0001193125-16-671832:notes:63]
|  |  | (In thousands) |  |
| Remaining 2016 |  | $ | 80,358 |  |
| 2017 |  |  | 377 |  |
| 2018 |  |  | 401 |  |
| 2019 |  |  | 45,945 |  |
| 2020 |  |  | 297,979 |  |
| Thereafter |  |  | 748,125 |  |
|  |  | $ | 1,173,185 |  |


## us-gaap:ScheduleofFiniteLivedIntangibleAssetsFutureAmortizationExpenseTableTextBlock

[0001193125-16-671832:notes:64]
Estimated aggregate amortization for definite-lived intangible
 assets for the next five years and thereafter is as
 follows:

[0001193125-16-671832:notes:65]
|  |  | (In thousands) |  |
| Remaining 2016 |  | $ | 11,975 |  |
| 2017 |  |  | 23,647 |  |
| 2018 |  |  | 22,889 |  |
| 2019 |  |  | 18,746 |  |
| 2020 |  |  | 18,746 |  |
| Thereafter |  |  | 42,956 |  |
|  |  | $ | 138,959 |  |


## us-gaap:ScheduleOfGoodwillTextBlock

[0001193125-16-671832:notes:66]
As of
 June 27, 2016 and December 28, 2015, goodwill was as
 follows:

[0001193125-16-671832:notes:67]
|  |  | Total |  |
|  |  | (In thousands) |  |
| Balance as of December 28, 2015 |  | $ | 346,990 |  |
| Goodwill recognized during the two quarters ended June 27, 2016 |  |  | 25,624 |  |
| Foreign currency translation adjustment |  |  | (18 | ) |
| Balance as of June 27, 2016 |  | $ | 372,596 |  |


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001193125-16-671832:notes:68]
[same as prior period, unchanged from 0001193125-16-582073:notes:71]

[0001193125-16-671832:notes:69]
[same as prior period, unchanged from 0001193125-16-582073:notes:72]

[0001193125-16-671832:notes:70]
Bank
 fees and legal, accounting, and other professional service costs
 associated with the acquisition of Viasystems of $605
 and $22,627 for the quarters ended June 27, 2016 and June
 29, 2015, respectively, and $1,296 and $30,862 for the two quarters
 ended June 27, 2016 and June 29, 2015, respectively, have been
 expensed and recorded as general and administrative expense in
 the consolidated condensed statements of operations.

[0001193125-16-671832:notes:71]
The
 value of the shares of the Company’s common stock used in
 determining the purchase price was $9.88 per share, the closing
 price of the Company’s common stock on May 29, 2015, the
 last business day prior to the effective date of the
 acquisition.

[0001193125-16-671832:notes:72]
The
 purchase price of the Viasystems acquisition was allocated to
 tangible and intangible assets acquired, liabilities assumed and
 noncontrolling interest based on the fair value at the date of the
 acquisition (May 31, 2015). The excess of the purchase price over
 the fair value of net assets acquired and noncontrolling interest
 was allocated to goodwill. The fair value assigned to intangible
 assets acquired was based on estimates and assumptions made by
 management at the time of acquisition. As of June 27, 2016, the
 Company has finalized the allocation of the purchase
 price.

[0001193125-16-671832:notes:73]
The
 fair values assigned are based on reasonable methods applicable to
 the nature of the assets acquired, liabilities assumed and
 noncontrolling interest. The following summarizes the final
 estimated fair values of net assets acquired and noncontrolling
 interest:

[0001193125-16-671832:notes:74]
|  |  | (In thousands) |  |
| Cash |  | $ | 79,662 |  |
| Restricted cash |  |  | 3,510 |  |
| Accounts and notes receivables ($216,259 contractual gross receivables) |  |  | 209,196 |  |
| Inventories |  |  | 132,216 |  |
| Prepaid expenses and other current assets |  |  | 30,633 |  |
| Property, plant and equipment |  |  | 427,457 |  |
| Identifiable intangible assets |  |  | 150,500 |  |
| Goodwill |  |  | 360,494 |  |
| Deposits and other noncurrent assets |  |  | 1,157 |  |
| Current liabilities |  |  | (256,705 | ) |
| Long-term debt |  |  | (669,024 | ) |
| Other liabilities |  |  | (63,966 | ) |
| Noncontrolling interest |  |  | (7,300 | ) |
| Total |  | $ | 397,830 |  |

[0001193125-16-671832:notes:75]
Goodwill represents the excess of the Viasystems purchase price
 over the fair value of tangibles and identifiable intangible assets
 acquired, liabilities assumed and noncontrolling interest. During
 the two quarters ended June 27, 2016, goodwill was adjusted to
 reflect:

[0001193125-16-671832:notes:76]
|  | • |  | an increase in current liabilities by $3,442 due to a reassessment of product claims and other contingent liabilities, and |

[0001193125-16-671832:notes:77]
|  | • |  | an increase in other noncurrent liabilities by $22,182 primarily related to certain foreign tax liabilities. |

[0001193125-16-671832:notes:78]
[same as prior period, unchanged from 0001193125-16-582073:notes:77]

[0001193125-16-671832:notes:79]
[same as prior period, unchanged from 0001193125-16-582073:notes:78]

[0001193125-16-671832:notes:80]
[same as prior period, unchanged from 0001193125-16-582073:notes:79]

[0001193125-16-671832:notes:81]
|  |  | Quarter Ended June 29, 2015 |  |  | Two Quarters Ended June 29, 2015 |  |
|  |  | (In thousands, except per share data) |  |
| Net sales |  | $ | 647,632 |  |  | $ | 1,281,425 |  |
| Net loss attributable to TTM Technologies, Inc. stockholders |  | $ | (24,348 | ) |  | $ | (22,796 | ) |
| Basic loss per share |  | $ | (0.23 | ) |  | $ | (0.23 | ) |
| Dilutive loss per share |  | $ | (0.23 | ) |  | $ | (0.23 | ) |

[0001193125-16-671832:notes:82]
[same as prior period, unchanged from 0001193125-16-582073:notes:81]


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0001193125-16-671832:notes:83]
(9)
 Accumulated Other Comprehensive Income (Loss)


## us-gaap:FairValueAssetsMeasuredOnNonrecurringBasisTextBlock

[0001193125-16-671832:notes:84]
For the two quarters ended June 27, 2016, the following assets
 were measured at fair value on a nonrecurring basis using the type
 of inputs shown:

[0001193125-16-671832:notes:85]
|  |  |  |  |  | Fair Value Measurements Using: |  |
|  |  | June 27, 2016 |  |  | Level 1 Inputs |  |  | Level 2 Inputs |  |  | Level 3 Inputs |  |  | Total Losses for the Two Quarters Ended June 27, 2016 |  |
|  |  | (In thousands) |  |
| Assets held for sale |  | $ | 155 |  |  | $ | — |  |  | $ | 155 |  |  | $ | — |  |  | $ | 1,393 |  |
| Long-lived assets held and use |  |  | 2,254 |  |  |  | — |  |  |  | — |  |  |  | 2,254 |  |  |  | 1,953 |  |
|  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | $ | 3,346 |  |


## us-gaap:IntangibleAssetsDisclosureTextBlock

[0001193125-16-671832:notes:86]
[same as prior period, unchanged from 0001193125-16-582073:notes:1]

[0001193125-16-671832:notes:87]
As of June 27, 2016 and December 28, 2015, the components
 of definite-lived intangibles were as follows:

[0001193125-16-671832:notes:88]
|  |  | Gross Amount |  |  | Accumulated Amortization |  |  | Foreign Currency Translation Adjustment |  |  | Net Carrying Amount |  |  | Weighted Average Amortization Period |  |
|  |  | (In thousands) |  |  | (years) |  |
| June 27, 2016: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Customer relationships |  | $ | 203,563 |  |  | $ | (66,636 | ) |  | $ | 109 |  |  | $ | 137,036 |  |  |  | 8.1 |  |
| Technology |  |  | 3,000 |  |  |  | (1,077 | ) |  |  | — |  |  |  | 1,923 |  |  |  | 3.0 |  |
|  |  | $ | 206,563 |  |  | $ | (67,713 | ) |  | $ | 109 |  |  | $ | 138,959 |  |  |  |  |  |
| December 28, 2015: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Customer relationships |  | $ | 91,492 |  |  | $ | (80,152 | ) |  | $ | 426 |  |  | $ | 11,766 |  |  |  | 9.2 |  |
| Trade name |  |  | 10,302 |  |  |  | (10,313 | ) |  |  | 11 |  |  |  | — |  |  |  | 6.0 |  |
| Acquired intangibles from Viasystems acquisition |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Customer relationships |  |  | 147,500 |  |  |  | (10,815 | ) |  |  | — |  |  |  | 136,685 |  |  |  | 8.1 |  |
| Technology |  |  | 3,000 |  |  |  | (577 | ) |  |  | — |  |  |  | 2,423 |  |  |  | 3.0 |  |
|  |  | $ | 252,294 |  |  | $ | (101,857 | ) |  | $ | 437 |  |  | $ | 150,874 |  |  |  |  |  |

[0001193125-16-671832:notes:89]
The June 27, 2016 and December 28, 2015 definite-lived
 intangible balances include foreign currency translation
 adjustments related to foreign subsidiaries with functional
 currencies other than the U.S. Dollar.

[0001193125-16-671832:notes:90]
Definite-lived intangibles are generally amortized using the
 straight line method of amortization over the useful life, with the
 exception of certain customer relationship intangibles, which are
 amortized using an accelerated method of amortization based on
 estimated cash flows. Amortization expense was $5,949 and $3,910
 for the quarters ended June 27, 2016 and June 29, 2015,
 respectively, and $11,896 and $5,784 for the two quarters ended
 June 27, 2016 and June 29, 2015, respectively.


## us-gaap:ConcentrationRiskDisclosureTextBlock

[0001193125-16-671832:notes:91]
[same as prior period, unchanged from 0001193125-16-582073:notes:10]

[0001193125-16-671832:notes:92]
In the
 normal course of business, the Company extends credit to its
 customers, which are concentrated primarily in the automotive,
 cellular phone, computer, networking and communications and
 aerospace and defense industries. Most customers to which the
 Company extends credit are located outside the United States, with
 the exception of certain customers in the aerospace and defense
 industries. The Company performs ongoing credit evaluations of
 customers, does not require collateral, and considers the credit
 risk profile of the entity from which the receivable is due in
 further evaluating collection risk.

[0001193125-16-671832:notes:93]
The
 Company’s customers include both OEM and EMS companies. The
 Company’s OEM customers often direct a significant portion of
 their purchases through EMS companies. While the Company’s
 customers include both OEM and EMS providers, the Company measures
 customer concentration based on OEM companies, as they are the
 ultimate end customers.

[0001193125-16-671832:notes:94]
For
 the quarters ended June 27, 2016 and June 29, 2015, one customer
 accounted for approximately 10% and 22%, respectively, of the
 Company’s net sales. For the two quarters ended June 27, 2016
 and June 29, 2015, one customer accounted for approximately 10% and
 24%, respectively, of the Company’s net sales. There were no
 other customers that accounted for 10% or more of net sales for the
 quarters or two quarters ended June 27, 2016 and June 29,
 2015.


## us-gaap:EarningsPerShareTextBlock

[0001193125-16-671832:notes:95]
[same as prior period, unchanged from 0001193125-16-582073:notes:90]

[0001193125-16-671832:notes:96]
For
 the quarter and two quarters ended June 27, 2016, performance-based
 stock units (PRUs), restricted stock units (RSUs) and stock options
 to purchase 347 and 1,644 shares of common stock, respectively,
 were not considered in calculating diluted earnings per share
 because the options’ exercise prices or the total expected
 proceeds under the treasury stock method for performance-based
 stock units, restricted stock units or stock options was greater
 than the average market price of common shares during the
 applicable quarter and two quarters and, therefore, the effect
 would be anti-dilutive.

[0001193125-16-671832:notes:97]
For
 the two quarters ended June 27, 2016, the effect of shares of
 common stock related to the Company’s convertible senior
 notes, based on the if-converted method, were not included in the
 computation of dilutive earnings per share as the impact would be
 anti-dilutive.

[0001193125-16-671832:notes:98]
For
 the quarter and two quarters ended June 29, 2015, potential
 shares of common stock, consisting of stock options to purchase
 approximately 433 shares of common stock at exercise prices ranging
 from $5.78 to $16.82 per share, 2,335 RSUs, and 275 PRUs were not
 included in the computation of diluted earnings per share because
 the Company incurred a net loss and, as a result, the impact would
 be anti-dilutive.

[0001193125-16-671832:notes:99]
For
 both the quarters and two quarters ended June 27, 2016 and
 June 29, 2015, outstanding warrants to purchase 25,940 and
 28,020 shares, respectively, were not included in the computation
 of dilutive earnings per share because the strike price of the
 warrants to purchase the Company’s common stock were greater
 than the average market price of common shares during the
 applicable quarters and two quarters, and therefore, the effect
 would be anti-dilutive.


## us-gaap:FairValueDisclosuresTextBlock

[0001193125-16-671832:notes:100]
[same as prior period, unchanged from 0001193125-16-582073:notes:51]

[0001193125-16-671832:notes:101]
The Company measures at fair value its financial and
 non-financial assets by using a fair value hierarchy that
 prioritizes the inputs to valuation techniques used to measure fair
 value. Fair value is the price that would be received to sell an
 asset or paid to transfer a liability in an orderly transaction
 between market participants at the measurement date, essentially an
 exit price, based on the highest and best use of the asset or
 liability.

[0001193125-16-671832:notes:102]
The carrying amount and estimated fair value of the
 Company’s financial instruments at June 27, 2016 and
 December 28, 2015 were as follows:

[0001193125-16-671832:notes:103]
|  |  | June 27, 2016 |  |  | December 28, 2015 |  |
|  |  | Carrying Amount |  |  | Fair Value |  |  | Carrying Amount |  |  | Fair Value |  |
|  |  | (In thousands) |  |
| Term and revolving loans |  | $ | 871,153 |  |  | $ | 910,629 |  |  | $ | 970,764 |  |  | $ | 935,000 |  |
| Convertible senior notes due 2020 |  |  | 204,370 |  |  |  | 235,775 |  |  |  | 200,022 |  |  |  | 230,950 |  |
| Capital lease |  |  | 2,042 |  |  |  | 2,042 |  |  |  | — |  |  |  | — |  |

[0001193125-16-671832:notes:104]
The fair value of the long-term debt was estimated based on
 quoted market prices or discounting the debt over its life using
 current market rates for similar debt as of June 27, 2016 and
 December 28, 2015, which are considered Level 1 and Level 2
 inputs.

[0001193125-16-671832:notes:105]
The fair value of the convertible senior notes was estimated
 based on quoted market prices of the securities on an active
 exchange, which are considered Level 1 and Level 2
 inputs.

[0001193125-16-671832:notes:106]
As of June 27, 2016 and December 28, 2015, the
 Company’s other financial instruments also included cash and
 cash equivalents, accounts receivable and accounts payable. Due to
 short-term maturities, the carrying amount of these instruments
 approximates fair value. Our cash and cash equivalents at June 27,
 2016 consisted of $64,143 held in the U.S., with the remaining
 $152,008 held by foreign subsidiaries.

[0001193125-16-671832:notes:107]
The majority of the Company’s non-financial assets and
 liabilities, which include goodwill, intangible assets,
 inventories, and property, plant and equipment, are not required to
 be carried at fair value on a recurring basis. However, if certain
 triggering events occur such that a non-financial instrument is
 required to be evaluated for impairment (at least annually for
 goodwill), based upon a comparison of the non-financial
 instrument’s fair value to its carrying value, an impairment
 is recorded to reduce the carrying value to the fair value, if the
 carrying value exceeds the fair value.

[0001193125-16-671832:notes:108]
There was no impairment of long-lived assets recognized in the
 quarter ended June 27, 2016 or for the quarter and two quarters
 ended June 29, 2015.

[0001193125-16-671832:notes:109]
The fair values of assets held for sale were primarily
 determined using appraisals and comparable prices of similar
 assets, which are considered to be Level 2 inputs.

[0001193125-16-671832:notes:110]
Additionally, the Company has capitalized software costs in
 accordance with U.S. GAAP. During the two quarters ended June 27,
 2016, the Company determined that certain capitalized costs no
 longer had benefit primarily as a result of the Viasystems
 acquisition. Because the primary determination of fair value was
 based on management’s assumptions and estimates of
 capitalized costs to dispose, the resulting fair value is
 considered a Level 3 input.


## us-gaap:GoodwillDisclosureTextBlock

[0001193125-16-671832:notes:111]
[same as prior period, unchanged from 0001193125-16-582073:notes:42]

[0001193125-16-671832:notes:112]
As of June 27, 2016 and December 28, 2015, goodwill was as
 follows:

[0001193125-16-671832:notes:113]
All goodwill relates to the Company’s PCB reportable
 operating segment.

[0001193125-16-671832:notes:114]
[same as prior period, unchanged from 0001193125-16-582073:notes:46]


## us-gaap:LongTermDebtTextBlock

[0001193125-16-671832:notes:115]
(7) Long-term Debt and
 Letters of Credit

[0001193125-16-671832:notes:116]
The fiscal calendar maturities of long-term debt through 2020
 and thereafter are as follows:

[0001193125-16-671832:notes:117]
Term and Revolving
 Loans

[0001193125-16-671832:notes:118]
On May 31, 2015, in conjunction with the acquisition of
 Viasystems, the Company entered into a $950,000 Term Loan Credit
 Agreement (Term Loan). Additionally, the Company entered into a
 $150,000 U.S. Asset-Based Lending Credit Agreement (U.S. ABL) and a
 $150,000 Asia Asset-Based Lending Credit agreement (Asia ABL)
 (collectively the ABL Revolving Loans). The Company drew $80,000 of
 the U.S. ABL at the closing of the acquisition of
 Viasystems.

[0001193125-16-671832:notes:119]
The Term Loan was issued at a discount at 96.5% and bears
 interest at a floating rate of LIBOR, with a 1.0% LIBOR floor, plus
 an applicable interest margin of 5.0%, or JP Morgan Chase
 Bank’s prime rate, with a 2% floor, plus a margin of 4%, at
 the Company’s option. At June 27, 2016, the weighted average
 interest rate on the outstanding borrowings under the Term Loan was
 6.0%. There is no provision, other than an event of default, for
 the interest margin to increase. The Term Loan will mature on
 May 31, 2021. The Term Loan is secured by a significant amount
 of the assets of the Company and its domestic subsidiaries and a
 pledge of 65% of voting stock of the Company’s first tier
 foreign subsidiaries and is structurally senior to the
 Company’s convertible senior notes. See Convertible Senior
 Notes below.

[0001193125-16-671832:notes:120]
The U.S. ABL consists of three tranches comprised of a
 revolving credit facility of up to $150,000, a letter of credit
 facility of up to $75,000, and swingline loans of up to $30,000,
 provided that at no time may amounts outstanding under the tranches
 exceed in aggregate $150,000 or the applicable borrowing base,
 which is a percentage of the principal amount of Eligible Accounts,
 as defined in the U.S. ABL agreement. Borrowings under the U.S. ABL
 bear interest at either a floating rate of LIBOR plus a margin of
 175 basis points or JP Morgan Chase Bank’s prime rate plus a
 margin of 75 basis points, at the Company’s option. At June
 27, 2016, the weighted average interest rate on the outstanding
 borrowings under the U.S. ABL was 2.21%. The applicable margin can
 vary based on the remaining availability of the facility, from 150
 to 200 basis points for LIBOR-based loans or from 50 to 100 basis
 points for JP Morgan Chase Bank’s prime rate-based loans.
 Other than availability and an event of default, there are no other
 provisions for the interest margin to increase. The U.S. ABL will
 mature on May 31, 2020. Loans made under the U.S. ABL are
 secured first by all of the Company’s domestic cash,
 receivables and inventories as well as by a second position against
 a significant amount of the assets of the Company and its domestic
 subsidiaries and a pledge of 65% of voting stock of the
 Company’s first tier foreign subsidiaries and are
 structurally senior to the Company’s convertible senior
 notes. See Convertible Senior Notes below. At June 27, 2016,
 $80,000 of the U.S. ABL was outstanding and classified as
 short-term debt.

[0001193125-16-671832:notes:121]
The Company and its domestic subsidiaries have fully and
 unconditionally guaranteed the full and timely payment of all Term
 Loan and U.S. ABL related obligations.

[0001193125-16-671832:notes:122]
The Asia ABL consists of two tranches comprised of a revolving
 credit facility of up to $150,000 and a letter of credit facility
 of up to $100,000, provided that at no time may amounts outstanding
 under both tranches exceed in aggregate $150,000 or the applicable
 borrowing base, which is a percentage of the principal amount of
 Eligible Accounts, as defined in the Asia ABL agreement. Borrowings
 under the Asia ABL bear interest at a floating rate of LIBOR plus
 175 basis points. There is no provision, other than an event of
 default, for the interest margin to increase. The Asia ABL will
 mature on May 22, 2020. Loans made under the Asia ABL are
 secured by a portion of cash and receivables of certain of the
 Companies subsidiaries in Asia and are structurally senior to the
 Company’s domestic obligations, including the convertible
 senior notes. See Convertible Senior Notes below. Additionally,
 certain of the Company’s subsidiaries in Asia have fully and
 unconditionally guaranteed the full and timely payment of all Asia
 ABL related obligations. At June 27, 2016, none of the Asia ABL was
 outstanding.

[0001193125-16-671832:notes:123]
The Company is required to make scheduled payments of the
 outstanding Term Loan balance on a quarterly basis. Based on
 certain parameters defined in the Term Loan agreement, the Company
 may be required to make an additional principal payment on an
 annual basis. Any additional annual payments reduce future required
 quarterly scheduled payments. During the quarter and two quarters
 ended June 27, 2016, the Company made debt principal payments
 totaling $30,000 and $106,482, respectively, representing normally
 scheduled principal payments as well as additional prepayments of
 principal. Any other outstanding balances under the Term Loan are
 due at the maturity date of May 31, 2021. Borrowings under the
 Term Loan are subject to various financial and operating covenants
 including maintaining a maximum total leverage ratio. Under the
 occurrence of certain events, the U.S. ABL and the Asia ABL are
 subject to various financial and operational covenants, including
 maintaining minimum fixed charge coverage ratios. At June 27, 2016,
 the Company was in compliance with the covenants under the Term
 Loan, the U.S. ABL and the Asia ABL.

[0001193125-16-671832:notes:124]
As of June 27, 2016 and December 28, 2015, remaining
 unamortized debt discount of $26,588 and $30,242, respectively, and
 debt issuance costs of $23,402 and $26,619, respectively, related
 to the Term Loan. These debt discount and debt issuance costs are
 recorded as a reduction of the Term Loan and are amortized over the
 duration of the Term Loan into interest expense using an effective
 interest rate of 7.50%.

[0001193125-16-671832:notes:125]
Additionally, remaining unamortized debt issuance costs related
 to the ABL Revolving Loans were $3,816 and $4,303 as of June 27,
 2016 and December 28, 2015, respectively. These debt issuance costs
 are included in other non-current assets and are amortized to
 interest expense over the duration of the ABL Revolving Loans using
 the straight line method of amortization.

[0001193125-16-671832:notes:126]
At June 27, 2016, the remaining amortization period for the
 unamortized debt discount and debt issuance costs for both the Term
 Loan and the ABL Revolving Loans was 4.9 years.

[0001193125-16-671832:notes:127]
The Company is required to pay a commitment fee of 0.25% to
 0.375% per annum on any unused portion of the U.S. ABL or Asia
 ABL based on utilization levels. Additionally, the Company also
 paid commitment fees of 0.5% per annum on the unused portion
 of the $90,000 senior secured revolving loan associated with the
 terminated 2012 credit agreement for the quarter and two quarters
 ended June 29, 2015. The Company incurred total commitment fees
 related to unused borrowing availability of $150 and $193 for the
 quarters ended June 27, 2016 and June 29, 2015, respectively, and
 $344 and $366 for the two quarters ended June 27, 2016 and June 29,
 2015, respectively. As of June 27, 2016, the outstanding amount of
 the Term Loan was $841,143, all of which is included as long-term
 debt. Additionally, $80,000 of the U.S. ABL and none of the Asia
 ABL was outstanding as of June 27, 2016. Available borrowing
 capacity under the U.S. ABL and Asia ABL was $63,003 and $137,778,
 which includes letters of credit outstanding of $6,997 and $12,222
 mentioned below, respectively, at June 27, 2016.

[0001193125-16-671832:notes:128]
Letters of
 Credit

[0001193125-16-671832:notes:129]
The Company has up to $75,000 and $100,000 Letters of Credit
 Facilities under the U.S. ABL and the Asia ABL, respectively, as
 mentioned above. As of June 27, 2016, letters of credit in the
 amount of $6,997 were outstanding under the U.S. ABL and $12,222
 were outstanding under the Asia ABL with various expiration dates
 through July 2017.

[0001193125-16-671832:notes:130]
At December 28, 2015, certain letters of credit were
 securitized by cash collateral. As such the Company had recorded
 such cash as restricted cash on the consolidated condensed balance
 sheet as of December 28, 2015. As of June 27, 2016, none of the
 letters of credit were securitized by cash collateral.

[0001193125-16-671832:notes:131]
Convertible Senior
 Notes

[0001193125-16-671832:notes:132]
Convertible Senior
 Notes due 2020

[0001193125-16-671832:notes:133]
The Company issued 1.75% convertible senior notes due
 December 15, 2020 in a public offering for an aggregate
 principal amount of $250,000 in 2013. The convertible senior notes
 bear interest at a rate of 1.75% per annum. Interest is
 payable semiannually in arrears on June 15 and
 December 15 of each year. The convertible senior notes are
 senior unsecured obligations and rank equally to the
 Company’s future unsecured senior indebtedness and are senior
 in right of payment to any of the Company’s future
 subordinated indebtedness.

[0001193125-16-671832:notes:134]
Convertible Senior
 Notes due 2015

[0001193125-16-671832:notes:135]
The Company issued 3.25% convertible senior notes due on
 May 15, 2015 in a public offering for an aggregate principal
 amount of $175,000. In May 2015 the outstanding principal of
 $32,395 plus accrued interest was paid in full.

[0001193125-16-671832:notes:136]
As of June 27, 2016 and December 28, 2015, the following
 summarizes the equity components of the convertible senior notes
 included in additional paid-in capital:

[0001193125-16-671832:notes:137]
The components of interest expense resulting from the
 convertible senior notes for the quarters and two quarters ended
 June 27, 2016 and June 29, 2015 are as follows:

[0001193125-16-671832:notes:138]
|  |  | For the Quarter Ended |  |  | For the Two Quarters Ended |  |
|  |  | June 27, 2016 |  |  | June 29, 2015 |  |  | June 27, 2016 |  |  | June 29, 2015 |  |
|  |  | (In thousands) |  |
| Contractual coupon interest |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Convertible senior notes due 2020 |  | $ | 1,093 |  |  | $ | 1,094 |  |  | $ | 2,187 |  |  | $ | 2,187 |  |
| Convertible senior notes due 2015 |  |  | — |  |  |  | 131 |  |  |  | — |  |  |  | 395 |  |
|  |  | $ | 1,093 |  |  | $ | 1,225 |  |  | $ | 2,187 |  |  | $ | 2,582 |  |
| Amortization of debt discount |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Convertible senior notes due 2020 |  | $ | 1,992 |  |  | $ | 1,867 |  |  | $ | 3,952 |  |  | $ | 3,705 |  |
| Convertible senior notes due 2015 |  |  | — |  |  |  | 187 |  |  |  | — |  |  |  | 554 |  |
|  |  | $ | 1,992 |  |  | $ | 2,054 |  |  | $ | 3,952 |  |  | $ | 4,259 |  |
| Amortization of debt issuance costs |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Convertible senior notes due 2020 |  | $ | 200 |  |  | $ | 187 |  |  | $ | 396 |  |  | $ | 371 |  |
| Convertible senior notes due 2015 |  |  | — |  |  |  | 19 |  |  |  | — |  |  |  | 56 |  |
|  |  | $ | 200 |  |  | $ | 206 |  |  | $ | 396 |  |  | $ | 427 |  |

[0001193125-16-671832:notes:139]
As of June 27, 2016 and December 28, 2015, remaining
 unamortized debt discount of $41,474 and $45,426, respectively, and
 debt issuance costs of $4,156 and $4,552, respectively, related to
 the convertible senior notes. These debt discount and debt issuance
 costs are recorded as a reduction of the convertible senior notes
 and are being amortized to interest expense over the term of the
 convertible senior notes using the effective interest rate method.
 At June 27, 2016, the remaining weighted average amortization
 period for the unamortized senior convertible note discount and
 debt issuance costs was 4.5 years.

[0001193125-16-671832:notes:140]
For the quarters and two quarters ended June 27, 2016 and June
 29, 2015, the amortization of the convertible senior notes due 2020
 debt discount and debt issuance costs was based on an effective
 interest rate of 6.48%. For the quarter and two quarters ended June
 29, 2015, the amortization of the convertible senior notes due 2015
 debt discount and debt issuance costs was based on an effective
 interest rate of 8.37%.

[0001193125-16-671832:notes:141]
Other Credit
 Facility

[0001193125-16-671832:notes:142]
Additionally, the Company is party to a revolving loan credit
 facility (Chinese Revolver) with a lender in China. Under this
 arrangement, the lender has made available to the Company
 approximately $34,800 in unsecured borrowing with all terms of the
 borrowing to be negotiated at the time the Chinese Revolver is
 drawn upon. There are no commitment fees on the unused portion of
 the Chinese Revolver, and this arrangement expires in December
 2016. As of June 27, 2016, the Chinese Revolver had not been drawn
 upon.

[0001193125-16-671832:notes:143]
Loss on
 Extinguishment of Debt

[0001193125-16-671832:notes:144]
The Company became a party to its current Term Loan and ABL
 Revolving Loans during the second quarter ended June 29, 2015
 in order to refinance and pay in full the remaining outstanding
 amount of $225,700 under an existing 2012 credit agreement, as well
 as to finance the acquisition of Viasystems and refinance
 Viasystems’ outstanding debt. As a result, the Company
 recognized losses of approximately $802 for the quarter and two
 quarters ended June 29, 2015 resulting from the write off of
 the remaining unamortized debt issuance costs associated with the
 terminated 2012 credit agreement.


## us-gaap:RelatedPartyTransactionsDisclosureTextBlock

[0001193125-16-671832:notes:145]
(16) Related Party
 Transactions

[0001193125-16-671832:notes:146]
In the
 normal course of business, the Company’s foreign subsidiaries
 purchase laminate and prepreg from related parties in which a
 significant shareholder of the Company holds an equity interest.
 The Company purchased laminate and prepreg from these related
 parties in the amount of $14,259 and $12,914 for the quarters ended
 June 27, 2016 and June 29, 2015, respectively, and $30,257 and
 $22,859 for the two quarters ended June 27, 2016 and June 29, 2015,
 respectively.

[0001193125-16-671832:notes:147]
Dongguan Shengyi Electronics Ltd. (SYE) is also a related party
 as it is a wholly owned subsidiary of an entity in which a
 significant shareholder of the Company holds an equity interest.
 The Company sells PCBs to SYE and purchases PCBs including various
 services relating to PCB manufacturing from SYE. Sales to SYE for
 the quarters ended June 27, 2016 and June 29, 2015 were $298 and
 $1,343, respectively, and $610 and $2,825 for the two quarters
 ended June 27, 2016 and June 29, 2015, respectively. Purchases of
 PCBs, including various services relating to PCB manufacturing, for
 the quarter ended June 29, 2015 were $366, and $805 for the two
 quarters ended June 29, 2015. There were no purchases of PCBs
 including various services relating to PCB manufacturing for the
 quarter or two quarters ended June 27, 2016.

[0001193125-16-671832:notes:148]
As of
 June 27, 2016 and December 28, 2015, the Company’s
 consolidated condensed balance sheets included $18,167 and $29,306,
 respectively, in accounts payable due to related parties for
 purchases of laminate and prepreg and various PCB manufacturing
 services and such balances are included as a component of accounts
 payable on the consolidated condensed balance sheets. Additionally,
 the Company’s consolidated condensed balance sheets included
 $476 and $1,999, in accounts receivable due from a related party
 for sales of PCBs to SYE, as of June 27, 2016 and December 28,
 2015, respectively, as mentioned above, and such balances are
 included as a component of accounts receivable, net on the
 consolidated condensed balance sheets.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001193125-16-671832:notes:149]
[same as prior period, unchanged from 0001193125-16-582073:notes:38]

[0001193125-16-671832:notes:150]
The
 operating segments reported below are the Company’s segments
 for which separate financial information is available and upon
 which operating results are evaluated by the chief operating
 decision maker to assess performance and to allocate resources. The
 Company has reviewed its reportable operating segments and
 determined that it continues to have two reportable operating
 segments: PCB and E-M Solutions. This determination was made based
 on the criteria of earning revenues and incurring expenses, the
 Company’s organizational structure which has segment managers
 who report to the chief operating decision maker and discrete
 financial information, and the aggregation of similar operating
 segments into reportable operating segments. Factors considered to
 determine whether operating segments can be aggregated into
 reportable segments included similarity regarding economic
 characteristics, products, production processes, type or classes of
 customers, distribution methods, and regulatory environments. All
 prior-period amounts have been adjusted retrospectively to reflect
 our reportable segment changes that were made in the third quarter
 of 2015.

[0001193125-16-671832:notes:151]
[same as prior period, unchanged from 0001193125-16-582073:notes:40]

[0001193125-16-671832:notes:152]
The
 Corporate category includes operating expenses that are not
 included in the segment operating performance measures. Corporate
 consists primarily of corporate governance functions such as
 finance, accounting, information technology, facilities and human
 resources personnel, as well as global sales and marketing
 personnel and acquisition and integration costs associated with the
 acquisition of Viasystems. Corporate includes bank fees and legal,
 accounting, and other professional service costs associated with
 the acquisition of Viasystems of $605 and $22,627 for the quarters
 ended June 27, 2016 and June 29, 2015, respectively, and
 $1,296 and $30,862 for the two quarters ended June 27, 2016 and
 June 29, 2015, respectively.
