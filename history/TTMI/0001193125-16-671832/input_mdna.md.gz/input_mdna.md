# TTMI MD&A — 0001193125-16-671832


## mdna

[0001193125-16-671832:mdna:1]
[same as prior period, unchanged from 0001193125-16-582073:mdna:1]

[0001193125-16-671832:mdna:2]
[same as prior period, unchanged from 0001193125-16-582073:mdna:2]

[0001193125-16-671832:mdna:3]
[same as prior period, unchanged from 0001193125-16-582073:mdna:3]

[0001193125-16-671832:mdna:4]
We are a leading global printed circuit board (PCB) manufacturer, focusing on quick-turn and technologically advanced PCBs and electro-mechanical solutions (E-M Solutions). We focus on providing
time-to-market and advanced technology products and offer a one-stop manufacturing solution to our customers from engineering support to prototype development through final volume production. This one-stop manufacturing solution allows us to align
technology development with the diverse needs of our customers and to enable them to reduce the time required to develop new products and bring them to market. We serve a diversified customer base consisting of approximately 1,500 customers in
various markets throughout the world, including manufacturers of networking/communications infrastructure products, smartphones, tablets and ultra notebooks, as well as the aerospace and defense, automotive components, high-end computing, and
medical, industrial and instrumentation related products. Our customers include both original equipment manufacturers (OEMs) and electronic manufacturing services (EMS) providers.

[0001193125-16-671832:mdna:5]
[same as prior period, unchanged from 0001193125-16-582073:mdna:5]

[0001193125-16-671832:mdna:6]
The acquisition of Viasystems has had and will continue to have a significant effect
on our operations and financial results. We have greatly increased and diversified our revenue base and added the fast growing automotive end market to our portfolio of markets we serve. Our financial results for the second quarter and two
quarters ended 2016 demonstrate the benefits of this diversification along with our strong operational execution and focus on realizing synergies from the integration. These results are reflected in improved gross and operating margins the second
quarter and two quarters ended 2016 as compared to the same periods in 2015.

[0001193125-16-671832:mdna:7]
On May 31, 2015, in
conjunction with the acquisition of Viasystems, we entered into a $950.0 million Term Loan Credit Agreement (Term Loan). During the quarter and two quarters ended June 27, 2016, the Company made debt principal payments totaling $30.0 million and
$106.5 million, respectively, representing normally scheduled principal payments as well as additional prepayments of principal. From time to time, we may make additional principal payments in the normal course of business as cash flow allows.

[0001193125-16-671832:mdna:8]
While our customers include both OEMs and EMS providers, we measure customers based on OEM companies, as they
are the ultimate end customers. Sales to our 10 largest customers accounted for 40% and 53% of our net sales for the quarters ended June 27, 2016 and June 29, 2015, respectively, and 40% and 55% for the two quarters ended June 27, 2016 and June 29,
2015, respectively. We sell to OEMs both directly and indirectly through EMS providers.

[0001193125-16-671832:mdna:9]
The following table
shows the percentage of our net sales attributable to each of the principal end markets we served for the periods indicated:

[0001193125-16-671832:mdna:10]
|  |  | Quarter Ended |  |  | Two Quarters Ended |  |
| End Markets(1)(2) |  | June 27,2016 |  |  | June 29,2015 (4) |  |  | June 27,2016 |  |  | June 29,2015 (4) |  |
| Aerospace/Defense |  |  | 16 | % |  |  | 15 | % |  |  | 16 | % |  |  | 15 | % |
| Automotive(2) |  |  | 19 |  |  |  | 7 |  |  |  | 20 |  |  |  | 5 |  |
| Cellular Phone(3) |  |  | 10 |  |  |  | 24 |  |  |  | 10 |  |  |  | 27 |  |
| Computing/Storage/Peripherals(3) |  |  | 13 |  |  |  | 11 |  |  |  | 13 |  |  |  | 11 |  |
| Medical/Industrial/Instrumentation |  |  | 16 |  |  |  | 12 |  |  |  | 16 |  |  |  | 11 |  |
| Networking/Communications |  |  | 25 |  |  |  | 26 |  |  |  | 24 |  |  |  | 27 |  |
| Other(2)(3) |  |  | 1 |  |  |  | 5 |  |  |  | 1 |  |  |  | 4 |  |
| Total |  |  | 100 | % |  |  | 100 | % |  |  | 100 | % |  |  | 100 | % |

[0001193125-16-671832:mdna:11]
[same as prior period, unchanged from 0001193125-16-582073:mdna:9]

[0001193125-16-671832:mdna:12]
[same as prior period, unchanged from 0001193125-16-582073:mdna:10]

[0001193125-16-671832:mdna:13]
[same as prior period, unchanged from 0001193125-16-582073:mdna:11]

[0001193125-16-671832:mdna:14]
| (4) | Amounts include activity of Viasystems, which we acquired on May 31, 2015. |

[0001193125-16-671832:mdna:15]
We derive revenues primarily from the sale of PCBs and custom electronic assemblies using customer-supplied engineering
and design plans. We recognize revenues when persuasive evidence of a sales arrangement exists, the sales terms are fixed or determinable, title and risk of loss have transferred, and collectability is reasonably assured — generally when
products are shipped to the customer. Net sales consist of gross sales less an allowance for returns, which typically have been less than 3% of gross sales. We provide our customers a limited right of return for defective PCBs and backplane
assemblies. We record an estimate for sales returns and allowances at the time of sale based on historical results. Purchase orders may be cancelled prior to shipment. We generally charge customers a fee, based on the percentage completed, if an
order is cancelled once it has entered production.

[0001193125-16-671832:mdna:16]
Cost of goods sold consists of materials, labor, outside
services, and overhead expenses incurred in the manufacture and testing of our products. Shipping and handling fees and related freight costs and supplies associated with shipping products are also included as a component of cost of goods sold. Many
factors affect our gross margin, including capacity utilization, product mix, production volume, and yield. We generally do not participate in any significant long-term contracts with suppliers, and we believe there are a number of potential
suppliers for most of the raw materials we use.

[0001193125-16-671832:mdna:17]
Selling and marketing expenses consist primarily of salaries,
labor related benefits, and commissions paid to our internal sales force, independent sales representatives, and our sales support staff, as well as costs associated with marketing materials and trade shows.

[0001193125-16-671832:mdna:18]
General and administrative costs primarily include the salaries for executive, finance, accounting, information
technology, facilities, and human resources personnel, as well as insurance expenses, expenses for accounting and legal assistance, incentive compensation expense, and gains or losses on the sale or disposal of property, plant and equipment.

[0001193125-16-671832:mdna:19]
[same as prior period, unchanged from 0001193125-16-582073:mdna:18]

[0001193125-16-671832:mdna:20]
Our consolidated condensed financial statements included in this report have been prepared in accordance with U.S. GAAP. The preparation of these financial statements requires management to make estimates
and assumptions that affect the reported amounts of assets, liabilities, net sales and expenses, and related disclosure of contingent assets and liabilities.

[0001193125-16-671832:mdna:21]
See Item 7, Management’s Discussion and Analysis of Financial Condition and Results of Operation, in our Annual Report on Form 10-K for the fiscal year ended December 28, 2015 for
further discussion of critical accounting policies and estimates. There were no material changes to our critical accounting policies and estimates since December 28, 2015.

[0001193125-16-671832:mdna:22]
[same as prior period, unchanged from 0001193125-16-582073:mdna:21]

[0001193125-16-671832:mdna:23]
The Viasystems acquisition occurred on May 31, 2015. The acquisition has had and will continue to have a significant
effect on our operations as discussed below.

[0001193125-16-671832:mdna:24]
The following table sets forth the relationship of various items
to net sales in our consolidated condensed statements of operations:

[0001193125-16-671832:mdna:25]
|  |  | Quarter Ended |  |  | Two Quarters Ended |  |
|  |  | June 27, 2016 |  |  | June 29, 2015 |  |  | June 27, 2016 |  |  | June 29, 2015 |  |
| Net sales |  |  | 100.0 | % |  |  | 100.0 | % |  |  | 100.0 | % |  |  | 100.0 | % |
| Cost of goods sold |  |  | 83.8 |  |  |  | 86.3 |  |  |  | 84.7 |  |  |  | 85.4 |  |
| Gross profit |  |  | 16.2 |  |  |  | 13.7 |  |  |  | 15.3 |  |  |  | 14.6 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Selling and marketing |  |  | 2.8 |  |  |  | 2.8 |  |  |  | 2.9 |  |  |  | 2.8 |  |
| General and administrative |  |  | 6.0 |  |  |  | 11.7 |  |  |  | 6.1 |  |  |  | 11.2 |  |
| Amortization of definite-lived intangibles |  |  | 1.0 |  |  |  | 0.8 |  |  |  | 1.0 |  |  |  | 0.7 |  |
| Impairment of long-lived assets |  |  | — |  |  |  | — |  |  |  | 0.3 |  |  |  | — |  |
| Restructuring charges |  |  | 0.7 |  |  |  | — |  |  |  | 0.5 |  |  |  |  |  |
| Gain on sale of asset |  |  | — |  |  |  | — |  |  |  | — |  |  |  | (0.3 | ) |
| Total operating expenses |  |  | 10.5 |  |  |  | 15.3 |  |  |  | 10.8 |  |  |  | 14.4 |  |
| Operating income (loss) |  |  | 5.7 |  |  |  | (1.6 | ) |  |  | 4.5 |  |  |  | 0.2 |  |
| Other income (expense): |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Interest expense |  |  | (3.3 | ) |  |  | (2.9 | ) |  |  | (3.5 | ) |  |  | (2.4 | ) |
| Loss on extinguishment of debt |  |  | — |  |  |  | (0.2 | ) |  |  | — |  |  |  | (0.1 | ) |
| Other, net |  |  | 0.6 |  |  |  | 0.2 |  |  |  | 0.3 |  |  |  | — |  |
| Total other expense, net |  |  | (2.7 | ) |  |  | (2.9 | ) |  |  | (3.2 | ) |  |  | (2.5 | ) |
| Income (loss) before income taxes |  |  | 3.0 |  |  |  | (4.5 | ) |  |  | 1.3 |  |  |  | (2.3 | ) |
| Income tax (provision) benefit |  |  | 0.1 |  |  |  | (3.7 | ) |  |  | (0.3 | ) |  |  | (2.0 | ) |
| Net income (loss) |  |  | 3.1 |  |  |  | (8.2 | ) |  |  | 1.0 |  |  |  | (4.3 | ) |
| Less: Net income attributable to noncontrolling interest |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |
| Net income (loss) attributable to TTM Technologies, Inc. stockholders |  |  | 3.1 | % |  |  | (8.2 | )% |  |  | 1.0 | % |  |  | (4.3 | )% |

[0001193125-16-671832:mdna:26]
We have reviewed our reportable operating segments and determined that we continue to
have two reportable operating segments: PCB and E-M Solutions. This determination was made based on the criteria of earning revenues and incurring expenses, our organizational structure which has segment managers who report to the chief operating
decision maker and discrete financial information, and the aggregation of similar operating segments into reportable operating segments.

[0001193125-16-671832:mdna:27]
The following table compares net sales by reportable segment for the quarters and two quarters ended June 27, 2016 and June 29, 2015:

[0001193125-16-671832:mdna:28]
|  |  | Quarter Ended |  |  | Two Quarters Ended |  |
|  |  | June 27, 2016 |  |  | June 29, 2015 |  |  | June 27, 2016 |  |  | June 29, 2015 |  |
|  |  | (In thousands) |  |
| Net Sales: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| PCB |  | $ | 563,574 |  |  | $ | 417,901 |  |  | $ | 1,093,519 |  |  | $ | 728,225 |  |
| E-M Solutions |  |  | 40,427 |  |  |  | 28,514 |  |  |  | 96,905 |  |  |  | 47,976 |  |
| Total sales |  |  | 604,001 |  |  |  | 446,415 |  |  |  | 1,190,424 |  |  |  | 776,201 |  |
| Inter-segment sales |  |  | (2,154 | ) |  |  | (970 | ) |  |  | (5,319 | ) |  |  | (1,592 | ) |
| Total net sales |  | $ | 601,847 |  |  | $ | 445,445 |  |  | $ | 1,185,105 |  |  | $ | 774,609 |  |

[0001193125-16-671832:mdna:29]
[same as prior period, unchanged from 0001193125-16-582073:mdna:45]

[0001193125-16-671832:mdna:30]
[same as prior period, unchanged from 0001193125-16-582073:mdna:29]

[0001193125-16-671832:mdna:31]
Total net sales increased $156.4 million, or 35.1%, from $445.4 million for the second quarter of 2015 to $601.8 million
for the second quarter of 2016. Net sales for the PCB operating segment, excluding inter-segment sales, increased $144.4 million, or 34.6%, from $417.0 million for the second quarter of 2015 to $561.4 million for the second quarter of 2016.
This increase is primarily due to the additional sales resulting from the acquisition of Viasystems, which accounted for approximately $169.6 million of the net increase in PCB sales for the second quarter of 2016, partially offset by lower demand
in our Cellular Phone end market. These changes, including the sales from Viasystems, resulted in a 76% increase in PCB shipments as compared to the second quarter of 2015, partially offset by an average PCB selling price decrease of 23%, which was
driven by a product mix shift resulting from the acquisition. Net sales for the E-M Solutions operating segment increased $12.0 million from $28.4 million for the second quarter of 2015 to $40.4 million for the second quarter of 2016. This increase
is due to the additional sales resulting from the acquisition of Viasystems.

[0001193125-16-671832:mdna:32]
Total net sales increased $410.5
million, or 53.0%, from $774.6 million for the first two quarters of 2015 to $1,185.1 million for the first two quarters of 2016. Net sales for the PCB operating segment, excluding inter-segment sales, increased $361.4 million, or 49.7%, from
$726.8 million for the first two quarters of 2015 to $1,088.2 million for the first two quarters of 2016. This increase is primarily due to the additional sales resulting from the acquisition of Viasystems, which accounted for $410.7 million of
the net increase in PCB sales for the first two quarters of 2016, partially offset by lower demand in our Cellular Phone end market. These changes, including the sales from Viasystems, resulted in a 116% increase in PCB shipments as compared to the
first two quarters of 2015, partially offset by an average PCB selling price decrease of 30%, which was driven by a product mix shift resulting from the acquisition. Net sales for the E-M Solutions operating segment increased $49.1 million from
$47.8 million for the first two quarters of 2015 to $96.9 million for the first two quarters of 2016. This increase is due to the additional sales resulting from the acquisition of Viasystems.

[0001193125-16-671832:mdna:33]
[same as prior period, unchanged from 0001193125-16-582073:mdna:33]

[0001193125-16-671832:mdna:34]
Overall gross margin increased from 13.7% for the second quarter of 2015 to 16.2% for the second quarter of 2016, and from 14.6% for the first two quarters of 2015 to 15.3% for the first two quarters of
2016.

[0001193125-16-671832:mdna:35]
Gross margin for the PCB operating segment increased from 14.6% for the second quarter of 2015 to 17.1%
for the second quarter of 2016, and from 15.3% for the first two quarters of 2015 to 16.4% for the first two quarters of 2016, primarily due to the improved operating performance at certain acquired manufacturing facilities and the benefits
resulting from our synergy initiatives, partially offset by reduced volumes at our facilities supporting the cellular phone end market.

[0001193125-16-671832:mdna:36]
Gross margin for the E-M Solutions operating segment increased from 4.1% for the second quarter of 2015 to 8.5% for the second quarter of 2016, and from 5.6% for the first two quarters of 2015 to 7.4% for
the first two quarters of 2016, primarily due to savings from the closure of Juarez, Mexico facility.

[0001193125-16-671832:mdna:37]
[same as prior period, unchanged from 0001193125-16-582073:mdna:37]

[0001193125-16-671832:mdna:38]
Selling and marketing expenses increased $4.3 million, from $12.3 million for the second quarter of
2015 to $16.6 million for the second quarter of 2016. Selling and marketing expenses increased $12.1 million, from $21.8 million for the first two quarters of 2015 to $33.9 million for the first two quarters of 2016. As a percentage of net sales,
selling and marketing expenses were 2.8% for both of the second quarters of 2015 and 2016 and 2.8% for the first two quarters of 2015, as compared to 2.9% for the first two quarters of 2016. The increase in selling and marketing expense
primarily relates to increased selling and marketing expense incurred with the acquisition of Viasystems, partially offset by workforce reductions associated with global realignment efforts.

[0001193125-16-671832:mdna:39]
[same as prior period, unchanged from 0001193125-16-582073:mdna:39]

[0001193125-16-671832:mdna:40]
General and
administrative expenses decreased $15.5 million from $52.0 million, or 11.7% of net sales, for the second quarter of 2015 to $36.5 million, or 6.0% of net sales, for the second quarter of 2016. General and administrative expenses decreased
$13.9 million from $86.5 million, or 11.2% of net sales, for the first two quarters of 2015 to $72.6 million, or 6.1% of net sales, for the first two quarters of 2016. The decrease in expense primarily related to a decrease of $22.0 million and
$29.6 million for the quarter and two quarters ended June 27, 2016, respectively, in acquisition related costs, partially offset by increased expenses incurred related to Viasystems. The decrease in general and administrative expense as percentage
of net sales was primarily due to the decrease in acquisition related costs and higher net sales.

[0001193125-16-671832:mdna:41]
Impairment of Long-Lived Assets and
Restructuring Charges

[0001193125-16-671832:mdna:42]
For the second quarter and the first two quarters of 2016, we incurred
restructuring charges of $4.0 million and $5.9 million, respectively, which primarily related to the September 29, 2015 announced consolidation plan that will result in the closure of our facilities in Cleveland, Ohio, Milpitas, California, and
Juarez, Mexico (the Consolidation Plan) and other global realignment efforts. These charges primarily represent severance and contract termination and other costs. Approximately $1.2 million and $2.4 million of

[0001193125-16-671832:mdna:43]
25

[0001193125-16-671832:mdna:44]
these restructuring charges were recognized in our PCB operating segment for the second quarter and the first two quarters of 2016, respectively, $2.0 million and $2.7 million were recognized in
our E-M Solutions operating segment for the second quarter and the first two quarters of 2016, respectively, and $0.8 million were recognized in our Corporate operating segment for both the second quarter and the first two quarters of 2016,
respectively. As of June 27, 2016, we have incurred approximately $13.3 million of such charges since the September 29, 2015 announcement and estimate that we will incur total charges of approximately $15.0 million to $20.0 million related to these
closures and other global realignment efforts.

[0001193125-16-671832:mdna:45]
Additionally, as a result of the above mentioned plant
closures and other plant realignment efforts, we also recognized impairment charges of $3.3 million for the first two quarters of 2016, of which $1.4 million were recognized in our PCB operating segment and $1.9 million were recognized related
in the Corporate operating segment. The impairment charge for the PCB operating segment related to machinery and equipment while the impairment charge for the Corporate operating segment related to the write-off of capitalized software costs.

[0001193125-16-671832:mdna:46]
If forecasts and assumptions used to support the realizability of our long-lived assets change in the future,
significant impairment or restructuring charges could result that would adversely affect our results of operations and financial condition.

[0001193125-16-671832:mdna:47]
[same as prior period, unchanged from 0001193125-16-582073:mdna:46]

[0001193125-16-671832:mdna:48]
Other expense, net increased $4.0 million from $12.9 million for the second quarter of 2015 to $16.9 million for the second quarter of 2016. Other expense, net increased $18.4 million from $19.1 million
for the first two quarters of 2015 to $37.5 million for the first two quarters of 2016. The increase in other expense, net was primarily due to an increase in interest expense related to the Term Loan and U.S. ABL, totaling $921.1 million as of June
27, 2016 at a weighted average interest rate of 5.7%, which was entered into on May 31, 2015 in connection with the acquisition of Viasystems. This increase was partially offset by $2.6 million and $3.7 million of higher foreign currency transaction
gains for the quarter and two quarters ended June 27, 2016, respectively, due primarily to the devaluation of the RMB, which is utilized at certain of our Asia operations.

[0001193125-16-671832:mdna:49]
[same as prior period, unchanged from 0001193125-16-582073:mdna:48]

[0001193125-16-671832:mdna:50]
The provision for income taxes
decreased by $17.6 million from $16.6 million of tax expense for the second quarter of 2015 to $1.0 million of tax benefit for the second quarter of 2016. The provision for income taxes decreased $10.8 million from $15.3 million of tax expense for
the first two quarters of 2015 to $4.5 million of tax expense for the first two quarters of 2016. The decrease in income tax expense in 2016 as compared to 2015 is primarily due to tax benefits recorded in the second quarter of 2016 related to the
release of existing uncertain tax positions due to the expiration of the statute of limitations and a research and development tax benefit in certain foreign jurisdictions. Further, a discrete tax expense was recorded in the second quarter of 2015
related to a valuation allowance that was provided against our existing U.S. net deferred tax assets.

[0001193125-16-671832:mdna:51]
Our
effective tax rate is primarily impacted by tax rates in China and Hong Kong, the U.S. federal income tax rate, apportioned state income tax rates, generation of other credits and deductions available to us, changes in the valuation allowance, and
certain non-deductible items. U.S. and certain foreign losses generated are not more likely than not to be realizable, and thus no income tax benefit has been recognized on these losses. As of June 27, 2016, we had net deferred income tax
liabilities of approximately $9.7 million and as of December 28, 2015, we had net deferred income tax liabilities of approximately $13.1 million.

[0001193125-16-671832:mdna:52]
[same as prior period, unchanged from 0001193125-16-582073:mdna:51]

[0001193125-16-671832:mdna:53]
Our principal
sources of liquidity have been cash provided by operations, the issuance of convertible senior notes, and term and revolving debt. Our principal uses of cash have been to finance acquisitions and capital expenditures, meet debt service requirements,
fund working capital requirements, and refinance existing debt. We anticipate that servicing debt, financing capital expenditures, financing acquisitions, and funding working capital requirements will continue to be the principal demands on our cash
in the future.

[0001193125-16-671832:mdna:54]
Cash flow provided by operating activities during the first two quarters of 2016 was $97.9
million as compared to $82.9 million in the same period in 2015. The increase in cash flow was primarily due to higher net income. As of June 27, 2016, we had net working capital of approximately $319.5 million compared to $277.5 million
as of December 28, 2015. Cash cycle days were 52 days for the second quarter of 2016 as compared to 53 days for the same quarter of 2015.

[0001193125-16-671832:mdna:55]
Net cash used in investing activities was approximately $31.9 million for the first two quarters of 2016 primarily reflecting purchases of property, plant and equipment, net of proceeds from sales of
property, plant and equipment and assets held for sale of $35.4 million, less release of restricted cash to cash and cash equivalents of $3.5 million. For the first two quarters of 2015, net cash used in investing activities was approximately
$210.2 million, which reflects the acquisition of Viasystems, net of cash acquired, in the amount of $166.6 million, purchases of property, plant and equipment, net of proceeds from sales of property, plant and equipment and assets held for sale of
$25.2 million, and designation of cash and cash equivalents to restricted cash of $18.4 million.

[0001193125-16-671832:mdna:56]
26

[0001193125-16-671832:mdna:57]
Net cash used in financing activities was approximately $106.5 million for
the first two quarters of 2016 reflecting the repayment of normally scheduled principal payments as well as additional prepayments of principal of long-term debt. For the first two quarters of 2015, net cash used in financing activities was
approximately $3.1 million primarily reflecting proceeds from long-term debt and a revolving loan totaling $1,030.0 million, offset by the repayment of $1,033.5 million of debt, including the assumed long-term debt in the acquisition of $669.0
million, the payoff of the 2012 credit agreement term loan, the payoff of the remaining 2015 convertible senior notes, and payment of debt issuance costs and original issue discount of $67.0 million associated with the new long-term debt and
revolver loans.

[0001193125-16-671832:mdna:58]
As of June 27, 2016, we had cash and cash equivalents of approximately $216.2 million, of
which approximately $152.0 million was held by our foreign subsidiaries, primarily in Asia. Cash and cash equivalents held by our foreign locations are expected to be used in local operations.

[0001193125-16-671832:mdna:59]
Our 2016 capital expenditures are expected to be in the range of $110 million to $120 million. The expenditures will fund
capital equipment purchases to increase production capacity, especially for advanced technology manufacturing, comply with changing environmental regulations, replace aging equipment, and expand our technological capabilities.

[0001193125-16-671832:mdna:60]
[same as prior period, unchanged from 0001193125-16-582073:mdna:58]

[0001193125-16-671832:mdna:61]
On May 31, 2015, in conjunction with the acquisition of Viasystems, we entered into a $950.0 million Term Loan Credit Agreement (Term Loan). Additionally, we entered into a $150.0 million U.S.
Asset-Based Lending Credit Agreement (U.S. ABL) and a $150.0 million Asia Asset-Based Lending Credit agreement (Asia ABL). We drew $80.0 million of the U.S. ABL at the closing of the acquisition of Viasystems.

[0001193125-16-671832:mdna:62]
The Term Loan Credit agreement was issued at a discount at 96.5% and bears interest at a floating rate of LIBOR, with a
1.0% LIBOR floor, plus an applicable interest margin of 5.0%. At June 27, 2016, the weighted average interest rate on the outstanding borrowings under the Term Loan was 6.0%. There is no provision, other than an event of default, for the interest
margin to increase. The Term Loan will mature on May 31, 2021. The Term Loan is secured by a significant amount of our assets and our domestic subsidiaries and a pledge of 65% of the voting stock of our first tier foreign subsidiaries and is
structurally senior to our convertible senior notes. See Convertible Senior Notes due 2020 below.

[0001193125-16-671832:mdna:63]
The U.S.
ABL consists of three tranches comprised of a revolving credit facility of up to $150.0 million, a letter of credit facility of up to $75.0 million, and swingline loans of up to $30.0 million, provided that at no time may amounts outstanding under
the tranches exceed in aggregate $150.0 million or the applicable borrowing base, which is a percentage of the principal amount of Eligible Accounts, as defined in the U.S. ABL agreement. Borrowings under the U.S. ABL bear interest at a floating
rate of LIBOR plus a margin of 175 basis points. At June 27, 2016, the weighted average interest rate on the outstanding borrowings under the U.S. ABL was 2.21%. The applicable margin can vary based on the remaining availability of the facility,
from 150 to 200 basis points for LIBOR-based loans. The U.S. ABL will mature on May 31, 2020. Loans made under the U.S. ABL are secured first by all of our domestic cash, receivables and inventories as well as by a second position against a
significant amount of our assets and our domestic subsidiaries and a pledge of 65% of the voting stock of our first tier foreign subsidiaries and are structurally senior to our convertible senior notes. See Convertible Senior Notes due 2020 below.
At June 27, 2016, $80.0 million of the U.S. ABL was outstanding and classified as short term debt.

[0001193125-16-671832:mdna:64]
We and our
domestic subsidiaries have fully and unconditionally guaranteed the full and timely payment of all Term Loan and U.S. ABL related obligations.

[0001193125-16-671832:mdna:65]
The Asia ABL consists of two tranches comprised of a revolving credit facility of up to $150.0 million and a letter of credit facility of up to $100.0 million provided that at no time may amounts
outstanding under both tranches exceed in aggregate $150.0 million or the applicable borrowing base, which is a percentage of the principal amount of Eligible Accounts, as defined in the Asia ABL agreement. Borrowings under the Asia ABL bear
interest at a floating rate of LIBOR plus 175 basis points. There is no provision, other than an event of default, for the interest margin to increase. The Asia ABL will mature on May 22, 2020. Loans made under the Asia ABL are secured by a
portion of cash and receivables of certain of our subsidiaries in Asia and are structurally senior to our domestic obligations, including our convertible senior notes. See Convertible Senior Notes due 2020 below. Additionally, certain of our
subsidiaries in Asia have fully and unconditionally guaranteed the full and timely payment of all Asia ABL related obligations. At June 27, 2016, none of the Asia ABL was outstanding.

[0001193125-16-671832:mdna:66]
We are required to make scheduled payments of the outstanding Term Loan balance on a quarterly basis. Based on certain
parameters defined in the Term Loan agreement, we may be required to make an additional principal payment on an annual basis. Any additional annual payments reduce future required quarterly scheduled payments. During the quarter and two quarters
ended June 27, 2016, we made debt principal payments totaling $30.0 million and $106.5 million, respectively, representing normally scheduled principal payments as well as additional prepayments of principal. From time to time, we may make
additional principal payments in the normal course of business as cash flow allows. Any other outstanding balances under the Term Loan are due at the maturity date of May 31, 2021. Borrowings under the Term Loan are subject to various
financial and operating covenants including maintaining a

[0001193125-16-671832:mdna:67]
27

[0001193125-16-671832:mdna:68]
maximum total leverage ratio. Under the occurrence of certain events, the U.S. ABL and the Asia ABL are subject to various financial and operational covenants, including maintaining minimum fixed
charge coverage ratios. At June 27, 2016, we were in compliance with the covenants under the Term Loan, the U.S. ABL and the Asia ABL.

[0001193125-16-671832:mdna:69]
We are also required to pay a commitment fee of 0.25% to 0.375% per annum on any unused portion of the U.S. ABL or Asia ABL based on utilization levels. Additionally, we also paid commitment fees of
0.5% per annum on the unused portion of the $90.0 million senior secured revolving loan associated with the terminated 2012 credit agreement for the quarter and two quarters ended June 29, 2015. We incurred total commitment fees related to
unused borrowing availability of $0.1 million and $0.3 million for the quarter and two quarters ended June 27, 2016, respectively. As of June 27, 2016, the outstanding amount of the Term Loan was $841.1 million, all of which is included as long-term
debt. Additionally, $80.0 million of the U.S. ABL and none of the Asia ABL was outstanding as of June 27, 2016. Available borrowing capacity under the U.S. ABL and Asia ABL was $63.0 million and $137.8 million, respectively, which includes $7.0
million and $12.2 million of outstanding letters of credit mentioned below, respectively, at June 27, 2016.

[0001193125-16-671832:mdna:70]
[same as prior period, unchanged from 0001193125-16-582073:mdna:66]

[0001193125-16-671832:mdna:71]
We have up to $75.0 million and $100.0 million Letters of Credit Facilities available under the U.S. ABL
and the Asia ABL, respectively. As of June 27, 2016, letters of credit in the amount of $7.0 million were outstanding under the U.S. ABL and $12.2 million were outstanding under the Asia ABL with various expiration dates through July 2017.

[0001193125-16-671832:mdna:72]
[same as prior period, unchanged from 0001193125-16-582073:mdna:68]

[0001193125-16-671832:mdna:73]
We are party to a revolving loan credit facility with a lender in China. Under this arrangement, the lender has made available to us approximately $34.8 million in unsecured borrowing with all terms of
the borrowing to be negotiated at the time the Chinese Revolver is drawn upon. There are no commitment fees on the unused portion of the Chinese Revolver, and this arrangement expires in December 2016. As of June 27, 2016, the Chinese Revolver had
not been drawn upon.

[0001193125-16-671832:mdna:74]
Convertible Senior Notes due 2020

[0001193125-16-671832:mdna:75]
On December 2013, we issued 1.75% convertible senior notes due December 15, 2020, in a public offering for an
aggregate principal amount of $250.0 million. The convertible senior notes bear interest at a rate of 1.75% per annum. Interest is payable semiannually in arrears on June 15 and December 15 of each year. The convertible senior notes
are senior unsecured obligations and rank equally to our future unsecured senior indebtedness and senior in right of payment to any of our future subordinated indebtedness. Offering expenses are being amortized to interest expense over the term of
the convertible senior notes.

[0001193125-16-671832:mdna:76]
In connection with the issuance of the convertible senior notes due 2020, we
entered into a convertible note hedge and warrant transaction (the Call Spread Transaction), with respect to our common stock. The convertible note hedge consists of our option to purchase up to 25.9 million common stock shares at a price of
$9.64 per share. The hedge expires on December 15, 2020 and can only be executed upon the conversion of the above mentioned convertible senior notes due 2020. Additionally, we sold warrants to purchase 25.9 million shares of our common
stock at a price of $14.26 per share. The warrants expire ratably from March 2021 through January 2022. The Call Spread Transaction has no effect on the terms of the convertible senior notes due 2020 and reduces potential dilution by effectively
increasing the conversion price of the convertible senior notes due 2020 to $14.26 per share of our common stock.

[0001193125-16-671832:mdna:77]
[same as prior period, unchanged from 0001193125-16-582073:mdna:73]

[0001193125-16-671832:mdna:78]
[same as prior period, unchanged from 0001193125-16-582073:mdna:74]

[0001193125-16-671832:mdna:79]
The following table provides information on our contractual obligations as of June 27, 2016:

[0001193125-16-671832:mdna:80]
|  |  | Total |  |  | Less Than1 Year |  |  | 1 - 3 Years |  |  | 4 - 5 Years |  |  | After5 Years |  |
| Contractual Obligations (1) |  | (In thousands) |  |
| Long-term debt obligations |  | $ | 923,185 |  |  | $ | 80,358 |  |  | $ | 22,546 |  |  | $ | 820,281 |  |  | $ | — |  |
| Convertible debt obligations |  |  | 250,000 |  |  |  | — |  |  |  | — |  |  |  | 250,000 |  |  |  | — |  |
| Interest on debt obligations |  |  | 277,378 |  |  |  | 57,466 |  |  |  | 111,130 |  |  |  | 108,782 |  |  |  | — |  |
| Equipment payables |  |  | 17,258 |  |  |  | 17,258 |  |  |  | — |  |  |  | — |  |  |  | — |  |
| Purchase obligations |  |  | 67,798 |  |  |  | 63,891 |  |  |  | 3,907 |  |  |  | — |  |  |  | — |  |
| Operating lease commitments |  |  | 28,442 |  |  |  | 9,472 |  |  |  | 9,083 |  |  |  | 4,252 |  |  |  | 5,635 |  |
| Total contractual obligations |  | $ | 1,564,061 |  |  | $ | 228,445 |  |  | $ | 146,666 |  |  | $ | 1,183,315 |  |  | $ | 5,635 |  |

[0001193125-16-671832:mdna:81]
| (1) | Unrecognized uncertain tax benefits of $35.0 million are not included in the table above as the settlement timing is uncertain. |

[0001193125-16-671832:mdna:82]
[same as prior period, unchanged from 0001193125-16-582073:mdna:78]

[0001193125-16-671832:mdna:83]
[same as prior period, unchanged from 0001193125-16-582073:mdna:79]

[0001193125-16-671832:mdna:84]
[same as prior period, unchanged from 0001193125-16-582073:mdna:80]

[0001193125-16-671832:mdna:85]
[same as prior period, unchanged from 0001193125-16-582073:mdna:81]
