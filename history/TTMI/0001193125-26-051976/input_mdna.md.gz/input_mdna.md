# TTMI MD&A — 0001193125-26-051976


## mdna

[0001193125-26-051976:mdna:1]
ITEM 7. MANAGEMENT’S DISCUSSION AND ANALYSIS OF FINANCIAL CONDITION AND RESULTS OF OPERATIONS

[0001193125-26-051976:mdna:2]
This financial review presents our operating results for each of our three most recent fiscal years and our financial condition as of December 29, 2025. Except for historical information contained herein, the following discussion contains forward-looking statements which are subject to known and unknown risks, uncertainties, and other factors that may cause our actual results to differ materially from those expressed or implied by such forward-looking statements. We discuss such risks, uncertainties, and other factors throughout this Report and specifically under Item 1A, Risk Factors of Part I of this Report. In addition, the following discussion should be read in connection with the information presented in our consolidated financial statements and the related notes to our consolidated financial statements.

[0001193125-26-051976:mdna:3]
COMPANY OVERVIEW

[0001193125-26-051976:mdna:4]
We are a leading global manufacturer of technology products, including mission systems, RF components, RF microwave/microelectronic assemblies, and technologically advanced interconnect products, including PCBs and substrates. We focus on providing time-to-market and volume production of advanced technology products and offer a one-stop design, engineering, and manufacturing solution to our customers. This solution allows us to align technology development with the diverse needs of our customers and to enable them to reduce the time required to develop new products and bring them to market. We serve a diversified customer base consisting of approximately 1,300 customers in various markets throughout the world, including aerospace and defense, data center computing, automotive, medical, industrial, and instrumentation, and networking. Our customers include OEMs, EMS providers, ODMs, distributors, and government agencies (both domestic and allied foreign governments).

[0001193125-26-051976:mdna:5]
RECENT DEVELOPMENTS

[0001193125-26-051976:mdna:6]
On July 9, 2025, we announced the acquisition of a facility in Eau Claire, Wisconsin, as well as land rights for an additional future manufacturing site in Penang, Malaysia. We believe the Eau Claire, Wisconsin facility comes equipped with the necessary infrastructure to support advanced technology PCB manufacturing and enhances our ability to support future high-volume U.S. production of advanced technology PCBs across key markets, particularly data center computing and networking for generative AI applications. In addition, we acquired land rights for ten acres in Penang to establish a new production site that we anticipate will align with customers’ increasing interests in supply chain diversification beyond China. The future Penang facility will be in close proximity to our existing facility and will enable us to deliver cost-competitive, high-quality advanced technology PCB manufacturing to commercial markets such as data center computing, networking, and medical, industrial, and instrumentation. Together, these new investments support our strategy to offer regionally optimized, globally connected manufacturing solutions for our customers.

[0001193125-26-051976:mdna:7]
We previously announced we are in the process of constructing a new advanced technology PCB manufacturing facility in Syracuse, New York. We expect that our new facility will bring advanced technology capability for our domestic high-volume production of ultra-HDI PCBs in support of national security requirements. The building construction is complete, equipment is arriving, and we are beginning to install and test equipment setups. Volume production in this facility is expected to commence in the second half of 2026.

[0001193125-26-051976:mdna:8]
FINANCIAL OVERVIEW

[0001193125-26-051976:mdna:9]
Our customers include both OEMs and EMS providers. We sell to OEMs both directly and indirectly through EMS providers. For such indirect sales, we measure customers based on OEM companies as they are the ultimate end customers. Sales to our ten largest customers collectively accounted for 55%, 42%, and 41% of our net sales in 2025, 2024, and 2023, respectively.

[0001193125-26-051976:mdna:10]
The percentage of our net sales attributable to each of the principal end markets we served was as follows:

[0001193125-26-051976:mdna:11]
|  |  | For the Year Ended |
|  |  | December 29, 2025 (1) |  | December 30, 2024 (1) |  | January 1, 2024 (1) |
| End Markets (2): |  |  |  |  |  |  |  |  |  |
| Aerospace and Defense |  | 44 | % |  | 46 | % |  | 46 | % |
| Automotive |  | 10 |  |  | 13 |  |  | 16 |  |
| Data Center Computing |  | 24 |  |  | 20 |  |  | 14 |  |
| Medical/Industrial/Instrumentation |  | 14 |  |  | 14 |  |  | 16 |  |
| Networking |  | 8 |  |  | 7 |  |  | 8 |  |
| Total |  | 100 | % |  | 100 | % |  | 100 | % |

[0001193125-26-051976:mdna:12]
(1)
The end market revenue for the years ended December 30, 2024 and January 1, 2024 has been recast to reflect certain adjustments to allocations resulting from the segment reorganization that occurred during the quarter ended June 30, 2025.

[0001193125-26-051976:mdna:13]
(2)
Sales to EMS companies are classified by the end markets of their OEM customers.

[0001193125-26-051976:mdna:14]
We derive revenues primarily from the sale of PCBs, engineered systems using customer-supplied engineering and design plans as well as our long-term contracts related to the design and manufacture of highly sophisticated intelligence, surveillance, and communications solutions, and RF and microwave/microelectronics components, assemblies, and subsystems. Orders for products generally correspond to the production schedules of our customers and are supported with firm purchase orders. Our customers have continuous control of the work in progress and finished goods throughout the PCB and engineered systems manufacturing process, as these are built to customer specifications with no alternative use, and there is an enforceable right of payment for work performed to date. As a result, we recognize revenue progressively over time based on the extent of progress towards completion of the performance obligation. We recognize revenue based on a cost method as it best depicts the transfer of control to the customer which takes place as we incur costs. Revenues are recorded proportionally as costs are incurred.

[0001193125-26-051976:mdna:15]
We also manufacture certain components, assemblies, subsystems, and completed systems which service our RF&S Components customers and certain aerospace and defense customers. We recognize revenue at a point in time upon transfer of control of the products to our customer. Point in time recognition was determined as our customers do not simultaneously receive or consume the benefits provided by our performance and the asset being manufactured has alternative uses to us.

[0001193125-26-051976:mdna:16]
Net sales consist of gross sales less an allowance for returns, which typically have been approximately 2% of gross sales. We provide our customers a limited right of return for defective PCBs including components, assemblies, and subsystems. We record an estimate for sales returns and allowances at the time of sale based on historical results and anticipated returns.

[0001193125-26-051976:mdna:17]
Cost of goods sold consists of materials, labor, outside services, and overhead expenses incurred in the manufacture and testing of our products. Shipping and handling fees and related freight costs and supplies associated with shipping products are also included as a component of cost of goods sold. Many factors affect our gross margin, including product mix, production volume, supply chain costs, and yield.

[0001193125-26-051976:mdna:18]
Selling and marketing expenses consist primarily of salaries, labor-related benefits, and commissions paid to our internal sales force, independent sales representatives, and our sales support staff, as well as costs associated with marketing materials and trade shows.

[0001193125-26-051976:mdna:19]
General and administrative costs primarily include the salaries for executive, finance, accounting, information technology, and human resources personnel, as well as expenses for accounting and legal assistance, incentive compensation expense, and gains or losses on the sale or disposal of property, plant, and equipment.

[0001193125-26-051976:mdna:20]
Research and development expenses consist primarily of salaries and labor-related benefits paid to our research and development staff, as well as material costs.

[0001193125-26-051976:mdna:21]
CRITICAL ACCOUNTING POLICIES AND ESTIMATES

[0001193125-26-051976:mdna:22]
Our consolidated financial statements included in this Report have been prepared in accordance with U.S. GAAP. The preparation of these financial statements requires management to make estimates and assumptions that affect the reported amounts of assets, liabilities, net sales and expenses, and related disclosure of contingent assets and liabilities.

[0001193125-26-051976:mdna:23]
A critical accounting policy is defined as one that is both material to the presentation of our consolidated financial statements and requires us to make judgments that could have a material effect on our financial condition or results of operations. These policies require us to make assumptions about matters that are highly uncertain at the time of the estimate. Critical accounting estimates refers

[0001193125-26-051976:mdna:24]
to those estimates made in accordance with U.S. GAAP that have had or are reasonably likely to have a material impact on the amounts reported in the consolidated financial statements and the related notes due to the significant level of uncertainty involved in developing the estimate. Different estimates we could reasonably have used, or changes in the estimates that are reasonably likely to occur, could have a material effect on our financial condition or results of operations.

[0001193125-26-051976:mdna:25]
We base our estimates on historical experience and on various other assumptions that we believe to be reasonable under the circumstances, the results of which form the basis for making judgments about the carrying values of assets and liabilities that are not readily apparent from other sources. Actual results may differ from these estimates under different assumptions or conditions.

[0001193125-26-051976:mdna:26]
We believe the following critical accounting policies and estimates reflect the more significant judgments and estimates used by us in preparing our consolidated financial statements. For additional discussion of the application of our significant accounting policies, see Part II, Item 8, Note 1, Nature of Operations and Summary of Significant Accounting Policies, of the Notes to Consolidated Financial Statements in this Report.

[0001193125-26-051976:mdna:27]
Revenue Recognition

[0001193125-26-051976:mdna:28]
For PCBs and engineered systems, customers have continuous control of the work in progress and finished goods throughout the PCB and engineered systems manufacturing process, as these are built to customer specifications with no alternative use, and there is an enforceable right to payment for work performed to date. As a result, we recognize revenue progressively over time based on the extent of progress towards completion of the performance obligation. See Part II, Item 8, Note 2, Revenues, of the Notes to Consolidated Financial Statements in this Report for further information.

[0001193125-26-051976:mdna:29]
For revenue recorded on an over time basis, we apply a gross margin estimate to inventory in process of being manufactured for customers to determine how much of a contract asset or contract liability should be recorded at period end. We use historical information to estimate the gross margin associated with performance obligations that are satisfied over time. We reevaluate our estimate of gross margins on a quarterly basis. Based on the review of gross margins, we update our estimate to the model as necessary. If our estimates of gross margins are inaccurate, we may recognize too much or too little revenue in a period. While experience has shown that trends in gross margins are not volatile, changes in pricing or cost efficiencies could create significant fluctuations. An increase or decrease of 200 basis points in gross margin estimates would have increased or decreased our contract assets by $3.7 million and $2.9 million, respectively, and decreased or increased our contract liabilities by $6.4 million and $5.8 million, respectively.

[0001193125-26-051976:mdna:30]
Goodwill and Intangible Assets

[0001193125-26-051976:mdna:31]
During the quarter ended June 30, 2025, in connection with our change in organizational structure to enhance clarity in sector performance, accountability, and operating costs, we concluded that we have three reportable segments: A&D, Commercial, and RF&S Components. In prior periods, we had two reportable segments: PCB and RF&S Components. In connection with our assessment of operating segments, we determined that our operating segments were also our reporting units and reallocated our PCB goodwill between A&D and Commercial based on the estimated relative fair values of the reporting units. In connection with the reallocation of goodwill, we performed a quantitative goodwill impairment assessment for these segments and concluded no impairment indicators existed as of June 30, 2025. See Part II, Item 8, Note 4, Segment Information, and Note 6, Goodwill and Definite-lived Intangibles, of the Notes to Consolidated Financial Statements in this Report for further information.

[0001193125-26-051976:mdna:32]
We completed our quantitative goodwill impairment analysis related to our PCB, A&D, and Commercial reporting units by comparing the fair value of each reporting unit with its carrying amount. Based on our analysis, we determined that the fair values of the PCB, A&D, and Commercial reporting units were greater than their respective carrying values. In making this assessment, we rely on a number of factors, including expected future operating results, business plans, economic projections, anticipated future cash flows, and business trends. We determined the fair value of the reporting units by using both a DCF and a market approach. Under the market approach, we used revenue and earnings multiples based on comparable industry multiples to estimate the fair value of the reporting unit.

[0001193125-26-051976:mdna:33]
Under the DCF approach, we estimated the future cash flows, as well as selected a risk-adjusted discount rate to measure the present value of the anticipated cash flows. When determining future cash flow estimates, we considered historical results adjusted to reflect current and anticipated future operating conditions. We estimated cash flows for the reporting unit over a discrete period and a terminal period (considering expected long-term growth rates and trends).

[0001193125-26-051976:mdna:34]
We reallocated PCB goodwill to the A&D and Commercial reporting units based on their estimated relative fair values. Estimating the fair value of the reporting unit requires us to make assumptions and estimates in such areas as future economic conditions, industry-specific conditions, product pricing, and necessary capital expenditures. The use of different assumptions or estimates for future cash flows, discount rates, or terminal growth rates, which are subject to a high degree of judgment, could produce substantially different estimates of the fair value of the reporting unit.

[0001193125-26-051976:mdna:35]
In the fourth quarter of 2025, we performed our annual goodwill impairment test qualitatively for the A&D, Commercial, and RF&S Components reporting units and concluded that it was more likely than not that there was no impairment to goodwill.

[0001193125-26-051976:mdna:36]
Management will continue to monitor the reporting units for changes in the business environment that could impact recoverability. The recoverability of goodwill is dependent upon the continued growth of cash flows from our business activities. If the economy or business environment falters and we are unable to achieve our assumed revenue growth rates or profit margin percentages, our projections used would need to be remeasured, which could impact the carrying value of our goodwill in one or more of our reporting units.

[0001193125-26-051976:mdna:37]
We also assess definite-lived intangibles for potential impairment given similar impairment indicators. When indicators of impairment exist related to our definite-lived intangible assets, we use an estimate of the undiscounted cash flows in measuring whether the carrying amount of the assets is recoverable. If the sum of the undiscounted cash flows is less than the carrying amount of the net assets, impairment is measured based on the difference between the net asset’s carrying value and estimated fair value. Fair value is determined through various valuation techniques, including cost-based, market, and income approaches as considered necessary, which involve judgments related to future cash flows and the application of the appropriate valuation model.

[0001193125-26-051976:mdna:38]
CONSOLIDATED OPERATING RESULTS

[0001193125-26-051976:mdna:39]
We operate on a 52 or 53 week fiscal calendar with the fourth quarter ending on the Monday nearest December 31. Fiscal years 2025, 2024, and 2023 consisted of 52 weeks ended on December 29, 2025, December 30, 2024, and January 1, 2024, respectively. All references to years relate to fiscal years unless otherwise noted.

[0001193125-26-051976:mdna:40]
Selected financial highlights are presented in the table below:

[0001193125-26-051976:mdna:41]
|  |  | For the Year Ended |  |
|  |  | December 29, 2025 |  |  | December 30, 2024 |  |  | January 1, 2024 |  |
|  |  | (In thousands, except margin rates) |  |
| Net sales |  | $ | 2,906,345 |  |  | $ | 2,442,753 |  |  | $ | 2,232,567 |  |
| Cost of goods sold |  |  | 2,304,659 |  |  |  | 1,965,378 |  |  |  | 1,819,299 |  |
| Gross profit |  |  | 601,686 |  |  |  | 477,375 |  |  |  | 413,268 |  |
| Gross margin |  |  | 20.7 | % |  |  | 19.5 | % |  |  | 18.5 | % |
| Operating expenses: |  |  |  |  |  |  |  |  |  |
| Selling and marketing |  |  | 85,460 |  |  |  | 80,030 |  |  |  | 76,922 |  |
| General and administrative |  |  | 192,149 |  |  |  | 170,107 |  |  |  | 149,631 |  |
| Research and development |  |  | 28,992 |  |  |  | 31,845 |  |  |  | 27,272 |  |
| Amortization of definite-lived intangibles |  |  | 27,554 |  |  |  | 35,550 |  |  |  | 48,675 |  |
| Impairment of goodwill |  | — |  |  |  | 32,600 |  |  |  | 44,100 |  |
| Restructuring charges |  |  | 2,847 |  |  |  | 11,200 |  |  |  | 24,352 |  |
| Total operating expenses |  |  | 337,002 |  |  |  | 361,332 |  |  |  | 370,952 |  |
| Operating income |  |  | 264,684 |  |  |  | 116,043 |  |  |  | 42,316 |  |
| Operating margin |  |  | 9.1 | % |  |  | 4.8 | % |  |  | 1.9 | % |
| Total other expense, net |  |  | (54,347 | ) |  |  | (32,094 | ) |  |  | (42,019 | ) |
| Income tax provision |  |  | (32,889 | ) |  |  | (27,650 | ) |  |  | (19,015 | ) |
| Net income (loss) |  | $ | 177,448 |  |  | $ | 56,299 |  |  | $ | (18,718 | ) |

[0001193125-26-051976:mdna:42]
Net Sales

[0001193125-26-051976:mdna:43]
Total net sales increased $463.6 million, or 19.0%, to $2,906.3 million for the year ended December 29, 2025 from $2,442.8 million for the year ended December 30, 2024. The primary driver of this increase was strong demand in our aerospace and defense, data center computing, and networking end markets, the latter two being driven by generative AI. In addition, our medical, industrial, and instrumentation end market was stronger as inventories and demand normalized in this end market.

[0001193125-26-051976:mdna:44]
Total net sales increased $210.2 million, or 9.4%, to $2,442.8 million for the year ended December 30, 2024 from $2,232.5 million for the year ended January 1, 2024. The primary driver of this increase was demand growth for generative AI applications in our data center computing end market and strong demand and improved operational execution in our aerospace and defense end market, partially offset by demand weakness due to customers' inventory correction in our automotive, medical, industrial, and instrumentation, and networking end markets. We also sold our Shanghai Backplane Assembly entity in the first quarter of 2023, which had the effect of reducing net sales in 2024 by $8.4 million.

[0001193125-26-051976:mdna:45]
Gross Profit and Margin Rate

[0001193125-26-051976:mdna:46]
Gross profit increased $124.3 million to $601.7 million for the year ended December 29, 2025, from $477.4 million for the year ended December 30, 2024. Gross margin rate increased to 20.7% for the year ended December 29, 2025, from 19.5% for the year ended December 30, 2024. These increases were primarily due to higher sales volume, improved operational execution, favorable product

[0001193125-26-051976:mdna:47]
mix, and increased volume of PCB shipments, partially offset by continued ramp-up costs in connection with our fabrication plant in Penang, Malaysia.

[0001193125-26-051976:mdna:48]
Gross profit increased $64.1 million to $477.4 million for the year ended December 30, 2024, from $413.3 million for the year ended January 1, 2024. Gross margin rate increased to 19.5% for the year ended December 30, 2024, from 18.5% for the year ended January 1, 2024. These increases were primarily due to higher sales volume and improved operational execution, partially offset by higher employee costs and continued ramp-up costs in connection with our fabrication plant in Penang, Malaysia.

[0001193125-26-051976:mdna:49]
Operating Expenses

[0001193125-26-051976:mdna:50]
Operating expenses decreased $24.3 million to $337.0 million for the year ended December 29, 2025, from $361.3 million for the year ended December 30, 2024, primarily due to the absence of a $32.6 million impairment of goodwill, decreases in restructuring charges and amortization of definite-lived intangibles, and the absence of a $6.1 million write down of our Hong Kong building that occurred during the year ended December 30, 2024, partially offset by higher stock-based compensation and incentive compensation expense as well as the absence of $14.4 million of gains on the sale of assets primarily related to the sale of two buildings vacated with the closure of our Anaheim and Santa Clara plants that occurred during the year ended December 30, 2024.

[0001193125-26-051976:mdna:51]
Operating expenses decreased $9.6 million to $361.3 million for the year ended December 30, 2024, from $371.0 million for the year ended January 1, 2024, primarily due to decreases in restructuring charges, amortization of definite-lived intangibles, and impairment of goodwill, partially offset by higher labor costs, consulting and other professional services expenses, stock-based compensation, bad debt, and incentive compensation. In addition, $14.4 million of gains on the sale of assets primarily related to the sale of two buildings vacated with the closure of our Anaheim and Santa Clara plants were partially offset by the write down of our Hong Kong building of $6.1 million that occurred during the year ended December 30, 2024.

[0001193125-26-051976:mdna:52]
Total Other Expense, Net

[0001193125-26-051976:mdna:53]
Total other expense, net increased $22.3 million to $54.3 million for the year ended December 29, 2025 from $32.1 million for the year ended December 30, 2024, primarily due to a foreign exchange loss of $20.4 million during the year ended December 29, 2025 compared to a foreign exchange gain of $1.2 million during the year ended December 30, 2024. We utilize the RMB and MYR at our China and Malaysia facilities, respectively, for employee‑related and other costs of running our operations in foreign countries. There was an unrealized loss from foreign exchange of $14.6 million during the year ended December 29, 2025, compared to an unrealized gain from foreign exchange of $1.0 million during the year ended December 30, 2024. The unrealized loss was related to the translation of our China and Malaysia balance sheets from their local currencies into the U.S. dollar functional currency, resulting from strengthening RMB and MYR during the year ended December 29, 2025 as compared to the year ended December 30, 2024.

[0001193125-26-051976:mdna:54]
Total other expense, net decreased $9.9 million to $32.1 million for the year ended December 30, 2024 from $42.0 million for the year ended January 1, 2024. This decrease was primarily due to the weakening RMB resulting in a $1.2 million foreign exchange gain during the year ended December 30, 2024, as compared to a $3.9 million foreign exchange loss during the year ended January 1, 2024. In addition, there was a $3.8 million increase in interest income and $0.6 million decrease in interest expense.

[0001193125-26-051976:mdna:55]
Income Taxes

[0001193125-26-051976:mdna:56]
Income tax expense increased $5.2 million to $32.9 million for the year ended December 29, 2025 from $27.7 million for the year ended December 30, 2024, primarily due to an increase in income before income taxes for the year ended December 29, 2025 and income tax accruals for assessments and uncertain tax positions in various jurisdictions, partially offset by the OBBBA tax impact, as discussed below, and an income tax benefit from the deduction of stock‑based compensation.

[0001193125-26-051976:mdna:57]
Income tax expense increased $8.6 million to $27.7 million for the year ended December 30, 2024 from $19.0 million for the year ended January 1, 2024, primarily due to an increase in income before income taxes.

[0001193125-26-051976:mdna:58]
On July 4, 2025, the OBBBA was enacted, introducing amendments to U.S. tax laws with various effective dates from 2025 to 2027. The OBBBA includes provisions such as the permanent extension of certain provisions of the Tax Cuts and Jobs Act that were set to expire at the end of 2025 and modifications to the international tax framework. Topic 740 requires the effects of changes in tax rates and laws on deferred tax balances to be recognized in the period in which the legislation is enacted. Accordingly, our tax provisions for the year ended December 29, 2025 incorporated the estimated effects of the tax law changes including the accelerated depreciation of qualified property and the immediate expensing of U.S. research and development expenditure paid or incurred for tax years beginning after December 31, 2024. We recorded a $6.0 million benefit from the decrease in the U.S. valuation allowance resulting from the OBBBA impact to our deferred tax assets.

[0001193125-26-051976:mdna:59]
Our effective tax rate is primarily impacted by the mix of foreign and U.S. income, tax rates in China and Hong Kong, the U.S. federal income tax rate, apportioned state income tax rates, the generation of credits and deductions available to us as well as changes in valuation allowances and certain non-deductible items.

[0001193125-26-051976:mdna:60]
SEGMENT OPERATING RESULTS

[0001193125-26-051976:mdna:61]
Basis of Presentation

[0001193125-26-051976:mdna:62]
During the quarter ended June 30, 2025, in connection with our change in organizational structure to enhance clarity in sector performance, accountability, and operating costs, our management finalized its assessment of our operating segments and concluded that we have three reportable segments: A&D, Commercial, and RF&S Components. As a result, certain prior period amounts have been reclassified to conform with this new presentation. See Part II, Item 8, Note 4, Segment Information, of the Notes to Consolidated Financial Statements in this Report for further information.

[0001193125-26-051976:mdna:63]
Selected segment financial highlights, with reconciliations to operating income, are presented in the table below:

[0001193125-26-051976:mdna:64]
|  |  | For the Year Ended |  |
|  |  | December 29, 2025 |  |  | December 30, 2024 |  |  | January 1, 2024 |  |
|  |  | (In thousands, except margin rates) |  |
| Segment sales: |  |  |  |  |  |  |  |  |  |
| A&D |  | $ | 1,292,523 |  |  | $ | 1,139,955 |  |  | $ | 1,045,983 |  |
| Commercial |  |  | 1,585,701 |  |  |  | 1,275,701 |  |  |  | 1,164,672 |  |
| RF&S Components |  |  | 40,014 |  |  |  | 37,317 |  |  |  | 38,619 |  |
| Total |  | $ | 2,918,238 |  |  | $ | 2,452,973 |  |  | $ | 2,249,274 |  |
| Segment operating income: |  |  |  |  |  |  |  |  |  |
| A&D |  | $ | 183,813 |  |  | $ | 141,800 |  |  | $ | 95,021 |  |
| Commercial |  |  | 238,781 |  |  |  | 179,782 |  |  |  | 171,379 |  |
| RF&S Components |  |  | 11,253 |  |  |  | 8,666 |  |  |  | 10,955 |  |
| Total |  |  | 433,847 |  |  |  | 330,248 |  |  |  | 277,355 |  |
| Segment operating margin rate: |  |  |  |  |  |  |  |  |  |
| A&D |  |  | 14.2 | % |  |  | 12.4 | % |  |  | 9.1 | % |
| Commercial |  |  | 15.1 | % |  |  | 14.1 | % |  |  | 14.7 | % |
| RF&S Components |  |  | 28.1 | % |  |  | 23.2 | % |  |  | 28.4 | % |
| Total |  |  | 14.9 | % |  |  | 13.5 | % |  |  | 12.3 | % |
| Unallocated amounts: |  |  |  |  |  |  |  |  |  |
| Restructuring |  |  | (2,847 | ) |  |  | (11,200 | ) |  |  | (24,352 | ) |
| Impairment of goodwill |  | — |  |  |  | (32,600 | ) |  |  | (44,100 | ) |
| Gain on sale of property, plant, and equipment |  | — |  |  |  | 15,669 |  |  |  | 195 |  |
| Acquisition-related and other charges |  |  | (15 | ) |  |  | (14,524 | ) |  |  | (4,529 | ) |
| Stock-based compensation |  |  | (41,668 | ) |  |  | (29,780 | ) |  |  | (22,887 | ) |
| Other corporate expenses |  |  | (87,736 | ) |  |  | (96,878 | ) |  |  | (77,790 | ) |
| Amortization of definite-lived intangibles (1) |  |  | (36,897 | ) |  |  | (44,892 | ) |  |  | (61,576 | ) |
| Operating income |  | $ | 264,684 |  |  | $ | 116,043 |  |  | $ | 42,316 |  |

[0001193125-26-051976:mdna:65]
(1)
Amortization of definite-lived intangibles relates to the A&D, Commercial, and RF&S Components reportable segments, but is not reviewed separately by the CODM. For the years ended December 29, 2025, December 30, 2024, and January 1, 2024, amortization expense of $9,343, $9,342, and $12,292, respectively, is included in cost of goods sold for the A&D reportable segment. For the year ended January 1, 2024, amortization expense of $609 is included in cost of goods sold for the RF&S Components reportable segment.

[0001193125-26-051976:mdna:66]
Segment operating income, as reconciled in Part II, Item 8, Note 4, Segment Information, of the Notes to Consolidated Financial Statements in this Report, and segment operating margin rate (segment operating income divided by segment sales) are presented in conformity with Accounting Standards Codification (ASC) Topic 280, Segment Reporting. These measures are reported to the CODM, who is the President and Chief Executive Officer, for purposes of making decisions about allocating resources to the segments and assessing their performance. For these reasons, these measures are excluded from the definition of non‑GAAP financial measures under the SEC's Regulation G and Item 10(e) of Regulation S-K.

[0001193125-26-051976:mdna:67]
35

[0001193125-26-051976:mdna:68]
A&D

[0001193125-26-051976:mdna:69]
Segment Sales

[0001193125-26-051976:mdna:70]
Segment sales for the A&D reportable segment increased $152.6 million, or 13.4%, to $1,292.5 million for the year ended December 29, 2025, from $1,140.0 million for the year ended December 30, 2024. The primary drivers of this increase were improved spending in previous defense budgets, our strong strategic program alignment, and key bookings for ongoing franchise programs, including restricted programs. These increases were driven by increased sales related to missiles and munitions as well as strong demand in our mission systems and specialty assembly businesses.

[0001193125-26-051976:mdna:71]
Segment sales for the A&D reportable segment increased $94.0 million, or 9.0%, to $1,140.0 million for the year ended December 30, 2024, from $1,046.0 million for the year ended January 1, 2024. The primary driver of this increase was strong demand in our radar and missile systems.

[0001193125-26-051976:mdna:72]
Segment Operating Income and Margin Rate

[0001193125-26-051976:mdna:73]
Segment operating income for the A&D reportable segment increased $42.0 million to $183.8 million for the year ended December 29, 2025, from $141.8 million for the year ended December 30, 2024. Segment operating margin rate for the A&D reportable segment increased to 14.2% for the year ended December 29, 2025, from 12.4% for the year ended December 30, 2024. The primary drivers of these increases were higher sales volume, as discussed above, favorable product mix, and improved operational execution.

[0001193125-26-051976:mdna:74]
Segment operating income for the A&D reportable segment increased $46.8 million to $141.8 million for the year ended December 30, 2024, from $95.0 million for the year ended January 1, 2024. Segment operating margin rate for the A&D reportable segment increased to 12.4% for the year ended December 30, 2024, from 9.1% for the year ended January 1, 2024. The primary drivers of these increases were higher sales volume, as discussed above, and improved operational execution.

[0001193125-26-051976:mdna:75]
Commercial

[0001193125-26-051976:mdna:76]
Segment Sales

[0001193125-26-051976:mdna:77]
Segment sales for the Commercial reportable segment increased $310.0 million, or 24.3%, to $1,585.7 million for the year ended December 29, 2025, from $1,275.7 million for the year ended December 30, 2024. The primary driver of this increase was strong demand in our data center computing and networking end markets driven by generative AI, and the recovery in medical, industrial, and instrumentation market.

[0001193125-26-051976:mdna:78]
Segment sales for the Commercial reportable segment increased $111.0 million, or 9.5%, to $1,275.7 million for the year ended December 30, 2024, from $1,164.7 million for the year ended January 1, 2024. The primary driver of this increase was demand growth for generative AI applications in our data center computing end market, partially offset by demand weakness due to customers' inventory correction in our automotive, medical, industrial, and instrumentation, and networking end markets. We also sold our Shanghai Backplane Assembly entity in the first quarter of 2023, which had the effect of reducing Commercial reportable segment net sales in 2024 by $8.4 million.

[0001193125-26-051976:mdna:79]
Segment Operating Income and Margin Rate

[0001193125-26-051976:mdna:80]
Segment operating income for the Commercial reportable segment increased $59.0 million to $238.8 million for the year ended December 29, 2025, from $179.8 million for the year ended December 30, 2024. Segment operating margin rate for the Commercial reportable segment increased to 15.1% for the year ended December 29, 2025, from 14.1% for the year ended December 30, 2024. The primary driver of these increases in segment operating income was higher sales volume, as discussed above, partially offset by increased ramp-up costs in connection with our fabrication plant in Penang, Malaysia.

[0001193125-26-051976:mdna:81]
Segment operating income for the Commercial reportable segment increased $8.4 million to $179.8 million for the year ended December 30, 2024, from $171.4 million for the year ended January 1, 2024. Segment operating margin rate for the Commercial reportable segment decreased to 14.1% for the year ended December 30, 2024, from 14.7% for the year ended January 1, 2024. The primary driver of the increase in segment operating income was higher sales volume, as discussed above, while the segment operating margin rate decreased due to continued ramp-up costs in connection with our fabrication plant in Penang, Malaysia.

[0001193125-26-051976:mdna:82]
RF&S Components

[0001193125-26-051976:mdna:83]
Segment Sales

[0001193125-26-051976:mdna:84]
Segment sales for the RF&S Components reportable segment increased $2.7 million, or 7.2%, to $40.0 million for the year ended December 29, 2025, from $37.3 million for the year ended December 30, 2024. The primary driver of this increase was stronger new business development across the networking and medical, industrial, and instrumentation end markets.

[0001193125-26-051976:mdna:85]
Segment sales for the RF&S Components reportable segment decreased $1.3 million, or 3.4%, to $37.3 million for the year ended December 30, 2024, from $38.6 million for the year ended January 1, 2024. The primary driver of this decrease was lower demand in our networking end market.

[0001193125-26-051976:mdna:86]
Segment Operating Income and Margin Rate

[0001193125-26-051976:mdna:87]
Segment operating income for the RF&S Components reportable segment increased $2.6 million to $11.3 million for the year ended December 29, 2025, from $8.7 million for the year ended December 30, 2024. Segment operating margin rate for the RF&S Components reportable segment increased to 28.1% for the year ended December 29, 2025, from 23.2% for the year ended December 30, 2024. The primary drivers of these increases were higher sales volume as discussed above, and improved operational execution.

[0001193125-26-051976:mdna:88]
Segment operating income for the RF&S Components reportable segment decreased $2.3 million to $8.7 million for the year ended December 30, 2024, from $11.0 million for the year ended January 1, 2024. Segment operating margin rate for the RF&S Components reportable segment decreased to 23.2% for the December 30, 2024, from 28.4% for the year ended January 1, 2024. The primary driver of these decreases was lower sales volume, as discussed above.

[0001193125-26-051976:mdna:89]
Liquidity and Capital Resources

[0001193125-26-051976:mdna:90]
Our principal sources of liquidity have been cash provided by operations, the issuance of debt, and borrowings under our revolving credit facilities. Our principal uses of cash have been to finance capital expenditures, finance acquisitions, fund working capital requirements, repay debt obligations, and repurchase common stock. We anticipate that financing capital expenditures, financing acquisitions, funding working capital requirements, servicing debt, and repurchasing common stock will be the principal demands on our cash in the future.

[0001193125-26-051976:mdna:91]
Cash flow provided by operating activities during the year ended December 29, 2025 was $291.9 million as compared to $236.9 million in the same period in 2024. The increase in cash flow was primarily due to the $121.1 million increase in net income, partially offset by an increase in working capital.

[0001193125-26-051976:mdna:92]
Net cash used in investing activities was $273.9 million for the year ended December 29, 2025, primarily reflecting the use of $292.6 million for purchases of property, plant, and equipment and other assets, partially offset by the receipt of $17.8 million of proceeds from capital-related government incentives. Net cash used in investing activities was $146.2 million for the year ended December 30, 2024, primarily reflecting the use of $185.7 million for purchases of property, plant, and equipment and other assets. This was partially offset by the receipt of $32.9 million of proceeds from the sale of property, plant, and equipment and other assets primarily related to the sale of two buildings vacated with the closure of our Anaheim and Santa Clara plants and $6.7 million of proceeds from the sale of property associated with our Shanghai E‑MS subsidiary.

[0001193125-26-051976:mdna:93]
Net cash used in financing activities was $20.9 million for the year ended December 29, 2025, reflecting the use of $17.9 million for repurchases of our common stock and $3.8 million for the repayment of long-term debt borrowings, partially offset by the receipt of $1.5 million of customer deposits. Net cash used in financing activities was $36.8 million for the year ended December 30, 2024, reflecting the use of $34.5 million for repurchases of our common stock, $9.6 million for the repayment of long-term debt borrowings, and $1.2 million for payment of debt issuance costs, partially offset by $8.4 million of proceeds from long-term debt borrowings primarily related to the refinancing of our Term Loan Facility.

[0001193125-26-051976:mdna:94]
As of December 29, 2025, we had cash and cash equivalents of approximately $501.2 million, of which approximately $191.9 million was held by our foreign subsidiaries, primarily in China, and $195.8 million of available borrowing capacity under our revolving credit facilities. Should we choose to remit cash to the United States from our foreign locations, we may incur tax obligations which would reduce the amount of cash ultimately available to the United States. However, we believe there would be no material tax expenses not previously accrued for the repatriation of this cash.

[0001193125-26-051976:mdna:95]
Our total 2026 capital expenditures are expected to be in the range of $240.0 million to $260.0 million.

[0001193125-26-051976:mdna:96]
Share Repurchases

[0001193125-26-051976:mdna:97]
On May 8, 2025, our Board of Directors authorized the 2025 Repurchase Program, under which we may repurchase up to $100.0 million in value of our common stock from time to time through May 7, 2027. During the year ended December 29, 2025, under our previous two-year repurchase program that expired on May 3, 2025, we repurchased approximately 0.7 million shares of our common stock for a total cost of $17.9 million (including commissions). As of December 29, 2025, we have not repurchased any shares of our common stock under the 2025 Repurchase Program, and the remaining amount in value available to be repurchased thereunder was $100.0 million.

[0001193125-26-051976:mdna:98]
Long-term Debt and Letters of Credit

[0001193125-26-051976:mdna:99]
As of December 29, 2025, we had $916.2 million of outstanding debt, net of discount and debt issuance costs, composed of $497.4 million of Senior Notes due 2029, $336.8 million under the Term Loan Facility, $80.0 million under the Asia ABL, and $2.0 million of other loans.

[0001193125-26-051976:mdna:100]
Pursuant to the terms of the Senior Notes due 2029 and Term Loan Facility, we are subject to certain affirmative and negative covenants, including limitations on indebtedness, corporate transactions, investments, dispositions, and restricted payments. Under the ABL Revolving Loans, we are also subject to various financial covenants, including leverage and fixed charge coverage ratios. As of December 29, 2025, we were in compliance with the covenants under the Senior Notes due 2029, Term Loan Facility, and ABL Revolving Loans.

[0001193125-26-051976:mdna:101]
Based on our current level of operations, we believe that cash generated from operations, cash on hand, and cash from the issuance of term and revolving debt will be adequate to meet our currently anticipated capital expenditure, debt service, and working capital needs for the next 12 months. Additional information regarding our indebtedness, including information about the credit available under our debt facilities, interest rates, and other key terms of our outstanding indebtedness, is included in Part II, Item 8, Note 7, Long‑term Debt and Letters of Credit, of the Notes to Consolidated Financial Statements included in this Report.

[0001193125-26-051976:mdna:102]
Supplier Finance Program Obligations

[0001193125-26-051976:mdna:103]
We have agreements with financial institutions to facilitate payments to certain suppliers. Liabilities associated with these agreements are recorded in accounts payable on the consolidated balance sheets and amounted to $12.5 million and $17.2 million as of December 29, 2025 and December 30, 2024, respectively.

[0001193125-26-051976:mdna:104]
Contractual Obligations and Commitments

[0001193125-26-051976:mdna:105]
As part of our ongoing operations, we enter into contractual arrangements that obligate us to make future cash payments. These obligations impact our liquidity and capital resource needs. Our estimated future obligations consist of long-term debt obligations, interest on debt obligations, derivative liabilities, purchase obligations, and leases.

[0001193125-26-051976:mdna:106]
A summary of our long-term debt obligations as of December 29, 2025 is included in Part II, Item 8, Note 7, Long‑term Debt and Letters of Credit, of the Notes to Consolidated Financial Statements included in this Report.

[0001193125-26-051976:mdna:107]
Our aggregate interest on debt obligations as of December 29, 2025 amounted to $167.9 million, which are expected to be settled as follows: $44.7 million within 1 year, $85.0 million within 1-3 years, and $38.2 million within 4-5 years. For debt obligations based on variable rates, interest rates used are as of December 29, 2025.

[0001193125-26-051976:mdna:108]
As of December 29, 2025, an immaterial amount of our derivative liabilities is expected to be settled within one year and $0.4 million of our derivative liabilities are expected to be settled within 1-3 years.

[0001193125-26-051976:mdna:109]
We also have outstanding firm purchase orders with certain suppliers for the purchase of material and inventory. Orders for standard, or catalog, items can typically be canceled with little or no financial penalty. Our policy regarding non-standard or customized items dictates that such items are only ordered specifically for customers who have contractually assumed liability for the inventory, although exceptions are made to this policy in certain situations. In addition, a substantial portion of catalog items covered by our purchase orders are procured for specific customers based on their purchase orders or a forecast under which the customer has contractually assumed liability for such material. Accordingly, our liability from purchase obligations under these purchase orders is not expected to be significant.

[0001193125-26-051976:mdna:110]
A summary of our lease obligations as of December 29, 2025 is included in Part II, Item 8, Note 13, Leases, of the Notes to Consolidated Financial Statements included in this Report.

[0001193125-26-051976:mdna:111]
Seasonality

[0001193125-26-051976:mdna:112]
We do not consider any material portion of our business to be seasonal. Various factors, however, can affect the distribution of our sales between accounting periods, including the timing of customer orders, the availability of customer funding, product deliveries, and customer acceptance.

[0001193125-26-051976:mdna:113]
Recently Issued Accounting Standards

[0001193125-26-051976:mdna:114]
For a description of recently adopted and issued accounting standards, including the respective dates of adoption and expected effects on our results of operations and financial condition, see Part II, Item 8, Note 1, Nature of Operations and Summary of Significant Accounting Policies, of the Notes to Consolidated Financial Statements included in this Report.
