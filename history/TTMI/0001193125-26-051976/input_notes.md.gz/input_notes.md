# TTMI notes — 0001193125-26-051976


## dei:DocumentsIncorporatedByReferenceTextBlock

[0001193125-26-051976:notes:1]
Portions of the registrant’s definitive Proxy Statement for its 2026 Annual Meeting of Stockholders will be incorporated by reference into Part III of this Annual Report on Form 10-K. Such Proxy Statement, or an amendment to this Report, will be filed with the Securities and Exchange Commission within 120 days after the end of the fiscal year to which this Report relates.


## cyd:CybersecurityRiskManagementProcessesForAssessingIdentifyingAndManagingThreatsTextBlock

[0001193125-26-051976:notes:2]
ITEM 1C. CYBERSECURITY

[0001193125-26-051976:notes:3]
We depend on information systems and technology in substantially all aspects of our business, including communications among our employees and with suppliers and customers. Such uses of information systems and technology give rise to cybersecurity risks, including system disruption, security breach, ransomware, theft, espionage, and inadvertent release of information. Our business involves the storage and transmission of numerous classes of sensitive and/or confidential information and intellectual property, including customers’ and suppliers’ information, private information about employees, and financial and strategic information about the company and its business partners. Further, as we pursue new initiatives that improve our operations and cost structure, we are also expanding and improving our information technologies, resulting in a larger technological presence and increased exposure to cybersecurity risk. If we fail to properly assess and identify cybersecurity risks, we may become increasingly vulnerable to such risks.

[0001193125-26-051976:notes:4]
Cybersecurity risk management and strategy

[0001193125-26-051976:notes:5]
We assess and identify security risk to the organization by:

[0001193125-26-051976:notes:6]
•
conducting assessments of risk including likelihood and magnitude from unauthorized access, use, disclosure, disruption, modification, or destruction of information systems and the related information processes, stored, or transmitted;

[0001193125-26-051976:notes:7]
•
performing risk assessments and producing security assessment reports that document the results of the assessment for use and review by IT senior leadership, including the Company’s SVP-IT;

[0001193125-26-051976:notes:8]
•
ensuring security controls are assessed for effectiveness, are implemented correctly, operating as intended, and producing the desired outcome; and

[0001193125-26-051976:notes:9]
•
periodically scanning for vulnerabilities and remedying all vulnerabilities in accordance with the associated risk.

[0001193125-26-051976:notes:10]
We have established a continuous monitoring strategy and program, which includes:

[0001193125-26-051976:notes:11]
•
a set of defined security metrics to be monitored;

[0001193125-26-051976:notes:12]
•
performance of security control assessments on an ongoing basis;

[0001193125-26-051976:notes:13]
•
addressing results of analysis and reporting security status to the executive team; and

[0001193125-26-051976:notes:14]
•
monitoring information systems to detect attacks and indicators of potential attacks.

[0001193125-26-051976:notes:15]
Other processes in place to further manage any additional security risk to the organization include:

[0001193125-26-051976:notes:16]
•
identifying, reporting, and correcting information system flaws, security alerts, and advisories;

[0001193125-26-051976:notes:17]
•
monitoring inbound and outbound communications for unusual or unauthorized activity;

[0001193125-26-051976:notes:18]
•
designing and implementing application systems to include sound backup and recoverability principles, such as periodic data backups in the case of a disaster;

[0001193125-26-051976:notes:19]
•
mechanisms designed for the physical protection of IT resources; and

[0001193125-26-051976:notes:20]
•
use of all third-party and cloud computing services are reviewed and evaluated for material risks of cybersecurity threats by the IT security department before being formally authorized for use. Use of services must comply with all laws and regulations governing the handling of personally identifiable information, corporate financial data, controlled unclassified information, or any other data owned or collected by the company.

[0001193125-26-051976:notes:21]
Our cybersecurity incident management plan includes the following, among other things:

[0001193125-26-051976:notes:22]
•
The SVP-IT leads the team in the development, documentation, review and testing of security procedures, and incident response procedures. Beyond initial creation, procedures are continually reassessed, augmented, updated, and tested on an ongoing basis;

[0001193125-26-051976:notes:23]
•
The SVP-IT works with the Executive Team on the identification, assessment, verification, and classification of incidents to determine affected stakeholders and appropriate parties for contact;

[0001193125-26-051976:notes:24]
•
The SVP-IT is responsible for launching the CIRT if necessary, and for notification to the Chief Executive Officer, who in turn will contact the Board of Directors and Government Security Committee in order to validate the response is being addressed appropriately.

[0001193125-26-051976:notes:25]
•
The CIRT team, in consultation with outside experts if needed, is responsible for the following:

[0001193125-26-051976:notes:26]
o
Initial containment;

[0001193125-26-051976:notes:27]
o
Analysis to establish root cause of incidents, identification, and evidence collection;

[0001193125-26-051976:notes:28]
o
Incident containment by further analyzing additional information and further identifying any additional compromised machines or resources not previously identified;

[0001193125-26-051976:notes:29]
o
Implementing solutions designed to solve underlying problems and prevent recurrence;

[0001193125-26-051976:notes:30]
o
Recovery and restoring normal business functionality;

[0001193125-26-051976:notes:31]
o
Review after closure of each incident and conducting a post-mortem analysis to improve prevention and help to make incident response processes more efficient and effective. Also, the CIRT evaluates competency and any additional training requirements needed.

[0001193125-26-051976:notes:32]
While we have experienced cybersecurity incidents in the past, to date none have materially affected us or our business strategy, results of operations, financial condition, and/or cash flows. Moreover, we have not identified any risks from cybersecurity threats that have materially affected or are reasonably likely to materially affect our business strategy, results of operations, financial condition, and/or cash flows. See Item 1A, Risk Factors above for more information. While we continually work to safeguard the information

[0001193125-26-051976:notes:33]
systems we use, and the proprietary, confidential, and personal information residing therein, and mitigate potential risks, there can be no assurance that such actions will be sufficient to prevent cybersecurity incidents or mitigate all potential risks to such systems, networks, and data or those of our third-party providers.

[0001193125-26-051976:notes:34]
Governance

[0001193125-26-051976:notes:35]
We have invested in robust data security and privacy protections. We follow industry-standard recommendations for data security such as those outlined in the National Institute of Standards and Technology (NIST) Special Publication 800-171 and evolving Cybersecurity Maturity Model Certification (CMMC) frameworks. We have developed cybersecurity policies and procedures, including a data classification system to ensure the protection of critical data. In addition to periodic internal review, we also employ external auditors as needed, and cybersecurity testing firms to review our cybersecurity posture.

[0001193125-26-051976:notes:36]
We maintain a CIRT, whose responsibilities are described above. We conduct periodic tests with this team to maintain readiness and resiliency while regularly reviewing its policies in the interest of protecting data security. External companies or agencies may be called upon to provide consulting, guidance, assistance, or some other form of support in response to a cybersecurity incident. The regular training of employees, at least annually, on the ever-present threat of cybersecurity helps maintain data security.

[0001193125-26-051976:notes:37]
Our Board of Directors receives an update from our SVP-IT twice per year. In addition, our Government Security Committee of the Board of Directors is responsible for reviewing Cybersecurity Posture and overall resilience of the aerospace and defense portion of the network. The Government Security Committee reviews global cybersecurity risk with the SVP-IT at least four times a year. These reviews included standard cybersecurity-related metrics as well as other detailed reviews of sensitive systems. Our SVP-IT has over 25 years of experience in IT, which include various leadership roles at other large corporations and holds an Executive Master in Cybersecurity degree from Brown University.


## ecd:MtrlTermsOfTrdArrTextBlock

[0001193125-26-051976:notes:38]
During the quarter ended December 29, 2025, our directors and/or officers (as defined in Rule 16a-1(f) under the Exchange Act) adopted or terminated the contracts, instructions, or written plans for the purchase or sale of our securities set forth in the table below.

[0001193125-26-051976:notes:39]
| Name and Title |  | Action |  | Adoption / Termination Date |  | Rule 10b5-1 (1) |  | Non-Rule 10b5-1 (2) |  | Total Number of Shares of Common Stock to be Sold (3) |  | Expiration Date |
| Daniel L. Boehle(Executive Vice President and CFO) |  | Termination |  | November 17, 2025 |  | X |  |  |  | Indeterminable (4) |  | August 31, 2026 |

[0001193125-26-051976:notes:40]
| Name and Title |  | Action |  | Adoption / Termination Date |  | Rule 10b5-1 (1) |  | Non-Rule 10b5-1 (2) |  | Total Number of Shares of Common Stock to be Sold (3) |  | Expiration Date |
| Thomas Clapprood(President, Radar Systems and Sensors Business Unit) |  | Termination |  | November 17, 2025 |  | X |  |  |  | Indeterminable (4) |  | June 30, 2026 |
| Thomas T. Edman(Director) |  | Termination |  | November 20, 2025 |  | X |  |  |  | Indeterminable (4) |  | June 30, 2026 |
| Robert Farrell(President, Communication and Computing Business Unit) |  | Termination |  | November 18, 2025 |  | X |  |  |  | Indeterminable (4) |  | June 30, 2026 |
| Catherine A. Gridley(Executive Vice President and President, Aerospace & Defense Sector) |  | Termination |  | November 17, 2025 |  | X |  |  |  | Indeterminable (4) |  | June 30, 2026 |
| Dale Knecht(Senior Vice President of Global Information Technology) |  | Termination |  | November 24, 2025 |  | X |  |  |  | Indeterminable (4) |  | June 30, 2026 |
| Shawn Powers(Executive Vice President and Chief Human Resources Officer) |  | Termination |  | November 24, 2025 |  | X |  |  |  | Indeterminable (4) |  | June 30, 2026 |
| Shawn Powers(Executive Vice President and Chief Human Resources Officer) |  | Termination |  | November 13, 2025 |  | X |  |  |  | Up to 15,000 |  | November 30, 2026 |
| Douglas L. Soder(Executive Vice President and President, Commercial Sector) |  | Termination |  | November 13, 2025 |  | X |  |  |  | Up to 25,000 |  | November 30, 2026 |
| Douglas L. Soder(Executive Vice President and President, Commercial Sector) |  | Termination |  | November 17, 2025 |  | X |  |  |  | Indeterminable (4) |  | June 30, 2026 |
| Steven Spoto (President, Integrated Electronics Business Unit) |  | Termination |  | November 19, 2025 |  | X |  |  |  | Indeterminable (4) |  | August 12, 2026 |
| James P. Walsh (Chief Operating Officer) |  | Termination |  | November 17, 2025 |  | X |  |  |  | Indeterminable (4) |  | June 30, 2026 |
| Daniel J. Weber(Executive Vice President, Chief Legal Officer and Secretary) |  | Termination |  | November 17, 2025 |  | X |  |  |  | Indeterminable (4) |  | June 30, 2026 |

[0001193125-26-051976:notes:41]
(1)
Contract, instruction, or written plan intended to satisfy the affirmative defense conditions of Rule 10b5-1(c) under the Exchange Act.

[0001193125-26-051976:notes:42]
(2)
“Non-Rule 10b5-1 trading arrangement” as defined in Item 408(c) of Regulation S-K under the Exchange Act.

[0001193125-26-051976:notes:43]
(3)
Represents the maximum number of shares that may be sold pursuant to the 10b5-1 arrangement. The number of shares sold will be dependent on the satisfaction of certain conditions as set forth in the trading plan.

[0001193125-26-051976:notes:44]
(4)
Rule 10b5-1 trading arrangement that was intended to provide for “eligible sell-to-cover transactions” (as described in Rule 10b5-1(c)(1)(ii)(D)(3) under the Exchange Act) to satisfy tax withholding obligations arising exclusively from vesting of RSUs or PRUs. The number of shares subject to covered RSUs or PRUs that were to be sold to satisfy applicable tax withholding obligations upon vesting were not currently determinable as the number would vary based on the market price of our common stock and the extent to which vesting conditions are satisfied. This sell-to-cover arrangement provided solely for the automatic sale of shares that would otherwise be issuable in respect of a covered RSU or PRU in an amount sufficient to satisfy the applicable withholding obligation, with the proceeds of the sale delivered to the Company in satisfaction of the applicable withholding obligation.


## dei:AuditorOpinionTextBlock

[0001193125-26-051976:notes:45]
Opinions on the Consolidated Financial Statements and Internal Control Over Financial Reporting

[0001193125-26-051976:notes:46]
We have audited the accompanying consolidated balance sheets of TTM Technologies, Inc. and subsidiaries (the Company) as of December 29, 2025 and December 30, 2024, the related consolidated statements of operations, comprehensive income (loss), stockholders’ equity, and cash flows for each of the years in the three-year period ended December 29, 2025, and the related notes (collectively, the consolidated financial statements). We also have audited the Company’s internal control over financial reporting as of December 29, 2025, based on criteria established in Internal Control – Integrated Framework (2013) issued by the Committee of Sponsoring Organizations of the Treadway Commission.

[0001193125-26-051976:notes:47]
In our opinion, the consolidated financial statements referred to above present fairly, in all material respects, the financial position of the Company as of December 29, 2025 and December 30, 2024, and the results of its operations and its cash flows for each of the years in the three-year period ended December 29, 2025, in conformity with U.S. generally accepted accounting principles. Also in our opinion, the Company maintained, in all material respects, effective internal control over financial reporting as of December 29, 2025 based on criteria established in Internal Control – Integrated Framework (2013) issued by the Committee of Sponsoring Organizations of the Treadway Commission.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureAndSignificantAccountingPoliciesTextBlock

[0001193125-26-051976:notes:48]
(1)
Nature of Operations and Summary of Significant Accounting Policies

[0001193125-26-051976:notes:49]
Nature of Operations

[0001193125-26-051976:notes:50]
TTM is a leading global manufacturer of technology products, including mission systems, RF components, RF microwave/microelectronic assemblies, and technologically advanced interconnect products, including PCBs and substrates. The Company provides time-to-market and volume production of advanced technology products and offers a one-stop design, engineering, and manufacturing solution to customers. This solution allows the Company to align technology development with the diverse needs of the Company’s customers and to enable them to reduce the time required to develop new products and bring them to market.

[0001193125-26-051976:notes:51]
The Company serves a diversified customer base in various markets throughout the world, including aerospace and defense, data center computing, automotive, medical, industrial, and instrumentation, and networking. The Company’s customers include OEMs, EMS providers, ODMs, distributors, and government agencies (both domestic and allied foreign governments).

[0001193125-26-051976:notes:52]
The Company operates on a 52 or 53 week fiscal calendar with the fourth quarter ending on the Monday nearest December 31. Fiscal years 2025, 2024, and 2023 consisted of 52 weeks ended on December 29, 2025, December 30, 2024, and January 1, 2024, respectively. All references to years relate to fiscal years unless otherwise noted.

[0001193125-26-051976:notes:53]
Use of Estimates

[0001193125-26-051976:notes:54]
The preparation of financial statements in conformity with U.S. GAAP requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities and disclosure of contingent assets and liabilities at the date of the financial statements and the reported amount of revenues and expenses during the reporting period. These estimates and assumptions are based on management’s best estimates and judgment. Due, in part, to the conflict between Russia and Ukraine as well as other global regions and the imposition of, or changes to, tariffs by the United States as well as retaliatory tariffs or measures by other countries, the global economy and financial markets have been volatile in recent years. As such, the Company has considered information available to it as of the date of issuance of these financial statements and is not aware of any specific events or circumstances that would require an update to its estimates or judgments, or a revision to the carrying value of its assets or liabilities. The actual results the Company experienced may differ materially and adversely from its estimates. To the extent there are material differences between the estimates and actual results, the Company’s future result of operations will be affected.

[0001193125-26-051976:notes:55]
Principles of Consolidation

[0001193125-26-051976:notes:56]
The consolidated financial statements include the accounts of TTM and its subsidiaries. All intercompany accounts and transactions have been eliminated in consolidation.

[0001193125-26-051976:notes:57]
Foreign Currency Translation and Transactions

[0001193125-26-051976:notes:58]
The functional currency of one of the Company’s subsidiaries is the RMB. Accordingly, assets and liabilities are translated into U.S. dollars using period-end exchange rates. Sales and expenses are translated at the average exchange rates in effect during the period. The resulting translation gains or losses are recorded as a component of accumulated other comprehensive loss in the consolidated statement of stockholders’ equity and the consolidated statement of comprehensive income (loss). Net gains and losses resulting from foreign currency remeasurements and transactions are included in income as a component of other, net in the consolidated statements of operations and totaled $20,426 loss, $1,218 gain, and $4,059 loss for the years ended December 29, 2025, December 30, 2024, and January 1, 2024, respectively.

[0001193125-26-051976:notes:59]
Cash Equivalents

[0001193125-26-051976:notes:60]
The Company considers highly liquid investments with insignificant interest rate risk and original maturities to the Company of three months or less to be cash equivalents.

[0001193125-26-051976:notes:61]
Accounts Receivable and Allowance for Doubtful Accounts

[0001193125-26-051976:notes:62]
Accounts receivable are reflected at estimated net realizable value, do not bear interest and do not generally require collateral. The Company performs credit evaluations of its customers and adjusts credit limits based upon payment history and the customer’s current creditworthiness. The Company maintains an allowance for doubtful accounts based upon a variety of factors. The Company considers both current and forecasted future economic conditions in determining the adequacy of its allowance for doubtful accounts. The Company’s allowance for doubtful accounts was $1,573 and $3,248 as of December 29, 2025 and December 30, 2024, respectively.

[0001193125-26-051976:notes:63]
Inventories

[0001193125-26-051976:notes:64]
Inventories are stated at the lower of cost (based on standard cost, which approximates first-in, first-out method) or net realizable value. Assessments to value the inventory at the lower of the actual cost to purchase and/or manufacture the inventory, or net realizable value of the inventory, are based upon assumptions about future demand and market conditions. As a result of the Company’s assessments, when the net realizable value of inventory is less than the carrying value, the inventory cost is written down to the net realizable value and the write down is recorded as a charge to cost of goods sold.

[0001193125-26-051976:notes:65]
Property, Plant, and Equipment, Net

[0001193125-26-051976:notes:66]
Property, plant, and equipment are recorded at cost. Depreciation expense is computed using the straight-line method over the estimated useful lives of the assets. Assets recorded under leasehold improvements are amortized using the straight-line method over the lesser of their useful lives or the related lease term. The Company uses the following estimated useful lives:

[0001193125-26-051976:notes:67]
| Land use rights |  | 50-99 years |
| Buildings and improvements |  | 7-50 years |
| Machinery and equipment |  | 3-10 years |
| Furniture and fixtures |  | 3-7 years |

[0001193125-26-051976:notes:68]
Upon retirement or other disposition of property, plant, and equipment, the cost and related accumulated depreciation are removed from the accounts. The resulting gain or loss is included in the determination of operating income in the period incurred. Depreciation expense on property, plant, and equipment was $110,274, $105,233, and $99,155 for the years ended December 29, 2025, December 30, 2024, and January 1, 2024, respectively.

[0001193125-26-051976:notes:69]
The Company capitalizes interest on borrowings during the active construction period of major capital projects. Capitalized interest is amortized over the average useful lives of such assets, which primarily consist of buildings and machinery and equipment. The Company capitalized interest costs of $3,828, $4,006, and $2,272 during the years ended December 29, 2025, December 30, 2024, and January 1, 2024, respectively, in connection with various capital projects.

[0001193125-26-051976:notes:70]
Major renewals and betterments are capitalized and depreciated over their estimated useful lives while minor expenditures for maintenance and repairs are included in operating income as incurred.

[0001193125-26-051976:notes:71]
Goodwill

[0001193125-26-051976:notes:72]
Goodwill represents the excess of purchase price of an acquisition over the fair value of net assets acquired. Goodwill is not amortized but instead is assessed for impairment, at a reporting unit level, annually and when events and circumstances warrant an evaluation. Goodwill is allocated to reporting units, which are operating segments or one level below the Company’s operating segments (the component level). Reporting units are determined by the discrete financial information available for the component and whether it is regularly reviewed by segment management. Components are aggregated into a single reporting unit if they share similar economic characteristics. The Company evaluates its goodwill on an annual basis in the fourth quarter or more frequently if it believes indicators of impairment exist. The Company assesses qualitative factors to determine whether it is more likely than not that the fair value of a reporting unit is less than its carrying amount or performs a quantitative impairment test. When tested quantitatively, the Company compares the fair value of the applicable reporting unit with its carrying value. In making this assessment, management relies on a number of factors, including expected future operating results, business plans, economic projections, anticipated future cash flows, business trends and declines in the Company’s market capitalization. The Company estimates the fair values of its reporting units using a combination of the DCF and market approaches. If the carrying amount of a reporting unit exceeds the reporting unit’s fair value, the amount by which the carrying value exceeds the fair value is recognized as an impairment loss. See Note 6, Goodwill and Definite-lived Intangibles, for further details.

[0001193125-26-051976:notes:73]
Intangible Assets

[0001193125-26-051976:notes:74]
Intangible assets include customer relationships and technology, which are being amortized over their estimated useful lives on a straight-line basis. The estimated useful lives of such intangibles range from 5 years to 13 years.

[0001193125-26-051976:notes:75]
Impairment of Long-lived Assets

[0001193125-26-051976:notes:76]
Long-lived tangible assets, including property, plant, and equipment, assets held for sale, and definite-lived intangible assets, are reviewed for impairment whenever events or changes in circumstances indicate that the carrying value of the asset or asset groups may not be recoverable. The Company regularly evaluates whether events or circumstances have occurred that indicate possible impairment and relies on a number of factors, including expected future operating results, business plans, economic projections, and anticipated future cash flows. The Company uses an estimate of the future undiscounted net cash flows of the related asset or asset group over the remaining life in measuring whether the assets are recoverable. If the sum of the undiscounted cash flows is less than the carrying amount of the net assets, impairment is measured based on the difference between the net asset’s carrying value and estimated fair value. Fair value is determined through various valuation techniques, including cost-based, market, and income approaches as considered necessary.

[0001193125-26-051976:notes:77]
Leases

[0001193125-26-051976:notes:78]
The Company determines if an arrangement is a lease at inception. Operating leases are included in operating lease ROU assets and lease liabilities are included in other current liabilities and operating lease liabilities on the consolidated balance sheets. Finance lease ROU assets are included in property, plant, and equipment, net and lease liabilities are included in other current liabilities and other long-term liabilities on the consolidated balance sheets.

[0001193125-26-051976:notes:79]
ROU assets represent the Company’s right to use an underlying asset for the lease term and lease liabilities represent the Company’s obligation to make lease payments arising from the lease. Operating and finance lease ROU assets and liabilities are recognized at commencement date based on the present value of lease payments over the lease term. As most of the Company’s leases do not provide an implicit rate, the Company uses its incremental borrowing rate based on the information available at the commencement date in determining the present value of lease payments. The operating and finance lease ROU assets also include any lease payments made and excludes lease incentives. Lease terms may include options to extend or terminate the lease when it is reasonably certain that the Company will exercise that option. Operating lease expense is recognized on a straight-line basis over the lease term. Finance lease expense is recognized based on the effective interest method over the lease term.

[0001193125-26-051976:notes:80]
The Company has lease agreements with lease and non-lease components and accounts for the lease and non-lease components as a single lease component.

[0001193125-26-051976:notes:81]
Revenue Recognition

[0001193125-26-051976:notes:82]
The Company derives revenues primarily from the sale of PCBs, engineered systems using customer-supplied engineering and design plans as well as long-term contracts related to the design and manufacture of highly sophisticated intelligence, surveillance, and communications solutions, RF and microwave/microelectronics components, assemblies, and subsystems. In the absence of a sales agreement, the Company’s standard terms and conditions apply. Revenue is recognized when control of the promised goods or services is transferred to the Company’s customers, in an amount that reflects the consideration to which it expects to be entitled in exchange for those goods or services. The Company applies a five-step approach in determining the amount and timing of revenue to be recognized: (1) identifying the contract with a customer; (2) identifying the performance obligations in the contract; (3) determining the transaction price; (4) allocating the transaction price to the performance obligations in the contract; and (5) recognizing revenue when the corresponding performance obligation is satisfied.

[0001193125-26-051976:notes:83]
Revenue Streams

[0001193125-26-051976:notes:84]
For PCBs and engineered systems, including pursuant to the Company’s long-term contracts related to the manufacture of highly sophisticated intelligence, surveillance, and communications solutions, components, assemblies, and subsystems, orders for products generally correspond to the production schedules of the Company’s customers and are supported with firm purchase orders. The Company’s customers have continuous control of the work in progress and finished goods throughout the PCB and engineered systems manufacturing process, as these are built to customer specifications with no alternative use, and there is an enforceable right to payment for work performed to date. As a result, the Company recognizes revenue progressively over time based on the extent of progress towards completion of the performance obligation. Revenue recognized is based on a cost method as it best depicts the transfer of control to the customer which takes place as we incur costs. Revenues are recorded proportionally as costs are incurred. For contracts in which anticipated total costs exceed the total expected revenue, an estimated loss is recognized in the period when identifiable. A provision for the entire amount of the estimated loss is recorded on a cumulative basis.

[0001193125-26-051976:notes:85]
In addition, the Company manufactures components, assemblies, subsystems, and completed systems which service its RF&S Components and certain aerospace and defense customers. The Company recognizes revenue at a point in time upon transfer of control of the products to the customer. Point in time recognition was determined as the customer does not simultaneously receive or consume the benefits provided by the Company’s performance and the asset being manufactured has alternative uses to the Company.

[0001193125-26-051976:notes:86]
Performance Obligations

[0001193125-26-051976:notes:87]
Each distinct promise to transfer products is considered to be an identified performance obligation for which revenue is recognized upon transfer of control of the products to the customer. A contract’s transaction price is allocated to each distinct performance obligation and recognized as revenue when, or as, the performance obligation is satisfied. The majority of the Company's contracts have a single performance obligation as the promise to transfer the individual good or service is not separately identifiable from other promises in the contract and is, therefore, not distinct.

[0001193125-26-051976:notes:88]
Transaction Price

[0001193125-26-051976:notes:89]
The Company provides customers a limited right of return for defective PCBs including components, assemblies, and subsystems. Estimates of returns are treated as variable consideration for purposes of determining the transaction price. The Company accrues an estimate for sales returns and allowances progressively over time based on the extent of progress towards completion of the performance obligation using the Company’s judgment based on historical results and anticipated returns. To the extent actual experience varies from its historical experience, revisions to the sales returns and allowances accrual may be required. Sales returns and allowances are recorded as a reduction of revenue and included as a component of other current liabilities on the consolidated balance sheets. Shipping and handling fees and related freight costs and supplies associated with shipping products to customers are included as a component of cost of goods sold. Warranty-related services are not considered a separate performance obligation. Incremental warranty costs that are not related to sales returns are recorded in other current liabilities on the consolidated balance sheets and cost of goods sold on the consolidated statements of operations. The following summarizes the activity in the Company’s sales returns and allowances:

[0001193125-26-051976:notes:90]
|  |  | For the Year Ended |  |
|  |  | December 29, 2025 |  |  | December 30, 2024 |  |  | January 1, 2024 |  |
|  |  | (In thousands) |  |
| Balance at beginning of year |  | $ | 10,777 |  |  | $ | 12,301 |  |  | $ | 12,319 |  |
| Addition charged as a reduction of sales |  |  | 4,831 |  |  |  | 2,787 |  |  |  | 4,692 |  |
| Deductions |  |  | (3,238 | ) |  |  | (4,281 | ) |  |  | (4,719 | ) |
| Effect of foreign currency exchange rates |  |  | 22 |  |  |  | (30 | ) |  |  | 9 |  |
| Balance at end of year |  | $ | 12,392 |  |  | $ | 10,777 |  |  | $ | 12,301 |  |

[0001193125-26-051976:notes:91]
Contract Balances

[0001193125-26-051976:notes:92]
Accounts receivable represents the Company’s unconditional right to receive consideration from its customer. Payments are generally due within 90 days or less of invoicing and do not include a significant financing component. To date, there have been no material credit losses on accounts receivable.

[0001193125-26-051976:notes:93]
A contract asset is recognized when the Company has recognized revenue, but has not issued an invoice for payment. Amounts will be invoiced when applicable contract terms, such as the achievement of specified milestones or product delivery, are met. Contract assets represent unbilled amounts for work performed to date and are transferred to receivables when the entitlement to payment becomes unconditional.

[0001193125-26-051976:notes:94]
A contract liability is recognized when the Company has received payment in advance for the future transfer of goods or services. The Company’s contract liabilities are reduced as the contract requirements are fulfilled.

[0001193125-26-051976:notes:95]
The Company has elected to account for shipping and handling activities as a fulfillment cost as permitted by the standard. All incremental customer contract acquisition costs are expensed as they are incurred as the amortization period of the asset that the Company otherwise would have recognized is one year or less in duration.

[0001193125-26-051976:notes:96]
Value-added and sales taxes are collected from customers and remitted, in a timely manner, to the appropriate governmental tax authority on behalf of the customer. Such taxes are excluded from reported revenues and costs of goods sold presented in the consolidated statements of operations and comprehensive income (loss).

[0001193125-26-051976:notes:97]
Stock-Based Compensation

[0001193125-26-051976:notes:98]
The Company recognizes stock-based compensation expense in its consolidated financial statements for its incentive compensation plan awards. The incentive compensation plan awards include PRUs, RSUs, and stock options. The associated compensation expense for all awards is based on the grant date fair value of the awards. For PRUs, compensation expense also includes management’s periodic assessment of annual financial performance goals to be achieved. Compensation expense for the incentive compensation plan awards is recognized on a straight-line basis over the vesting period of the awards. The fair value of PRUs is estimated on the grant date using a Monte Carlo simulation model based on the underlying common stock closing price as of the date

[0001193125-26-051976:notes:99]
of grant, stock price volatility, and risk-free interest rates. The fair value of RSUs is measured on the grant date based on the quoted closing market price of the Company’s common stock.

[0001193125-26-051976:notes:100]
Income Taxes

[0001193125-26-051976:notes:101]
Income taxes are accounted for under the asset and liability method. Deferred income tax assets or liabilities are recognized for the future tax consequences attributable to differences between the financial statement carrying amounts of assets and liabilities and their respective tax bases and operating loss and tax credit carryforwards. Deferred income tax assets and liabilities are measured using enacted tax rates expected to apply to taxable income in the years in which those temporary differences are expected to be settled or realized. The effect on deferred income tax assets and liabilities of a change in tax rates is recognized in income in the period that includes the enactment date. Deferred income tax assets are reviewed for recoverability, and the Company records a valuation allowance to reduce its deferred income tax assets when it is more likely than not that all or some portion of the deferred income tax assets will not be realized.

[0001193125-26-051976:notes:102]
The Company has various foreign subsidiaries formed or acquired to conduct or support its business outside the United States. The Company expects its earnings attributable to foreign subsidiaries will not be indefinitely reinvested except for certain subsidiaries, and we have established a deferred tax liability for foreign withholding taxes and the estimated federal/state tax impact. For those other companies with earnings currently being reinvested outside of the U.S., no deferred tax liabilities on undistributed earnings are recorded.

[0001193125-26-051976:notes:103]
The Company recognizes the effect of income tax positions only if those positions are more likely than not to be sustained. Recognized income tax positions are measured at the largest amount that is greater than 50 percent likely to be realized. Changes in recognition or measurement are reflected in the period in which the change in judgment occurs. Estimated interest and penalties related to underpayment of income taxes are recorded as a component of income tax provision in the consolidated statements of operations.

[0001193125-26-051976:notes:104]
Fair Value Measures

[0001193125-26-051976:notes:105]
The Company measures at fair value certain of its financial and non-financial assets and liabilities by using a fair value hierarchy that prioritizes the inputs to valuation techniques used to measure fair value. Fair value is the price that would be received to sell an asset or paid to transfer a liability in an orderly transaction between market participants at the measurement date, essentially an exit price, based on the highest and best use of the asset or liability. The levels of the fair value hierarchy are:

[0001193125-26-051976:notes:106]
Level 1 — Quoted market prices in active markets for identical assets or liabilities;

[0001193125-26-051976:notes:107]
Level 2 — Significant other observable inputs (e.g., quoted prices for similar items in active markets, quoted prices for identical or similar items in markets that are not active, inputs other than quoted prices that are observable, such as interest rate and yield curves, and market-corroborated inputs); and

[0001193125-26-051976:notes:108]
Level 3 — Unobservable inputs in which there is little or no market data, which require the reporting unit to develop its own assumptions.

[0001193125-26-051976:notes:109]
Earnings (Loss) Per Share

[0001193125-26-051976:notes:110]
Basic earnings (loss) per common share excludes dilution and is computed by dividing net income (loss) by the weighted average number of common shares outstanding during the period. Diluted earnings (loss) per common share reflect the potential dilution that could occur if stock options, or other common stock equivalents were exercised or converted into common stock. The dilutive effect of stock options or other common stock equivalents is calculated using the treasury stock method.

[0001193125-26-051976:notes:111]
Comprehensive Income (Loss)

[0001193125-26-051976:notes:112]
Comprehensive income (loss) includes changes to equity accounts that were not the result of transactions with stockholders. Comprehensive income (loss) is comprised of net income (loss), changes in the cumulative foreign currency translation adjustments, pension obligation adjustments, and realized and unrealized gains or losses on hedged derivative instruments.

[0001193125-26-051976:notes:113]
Loss Contingencies

[0001193125-26-051976:notes:114]
The Company establishes an accrual for an estimated loss contingency when it is both probable that an asset has been impaired or that a liability has been incurred and the amount of the loss can be reasonably estimated. Any legal fees expected to be incurred in connection with a contingency are expensed as incurred.

[0001193125-26-051976:notes:115]
Government Incentives

[0001193125-26-051976:notes:116]
Government incentives are recorded in the Company’s consolidated financial statements in accordance with their purpose as a reduction of expense or an offset to the related capital asset. The benefit is generally recognized when all conditions attached to the incentive have been met or are expected to be met and there is reasonable assurance of their receipt. The Company records operating grants as a reduction to expense in the same line item on the consolidated statements of operations as the expenditure for which the grant is intended to compensate. The Company records capital-related incentives as a reduction to property, plant, and equipment, net on the consolidated balance sheets and recognizes a reduction to depreciation expense over the useful life of the related acquired asset.

[0001193125-26-051976:notes:117]
The Company expects to receive cash and credits in connection with capital expenditure expansion projects and process and product qualifications under the Defense Industrial Base Consortium (DIBC) base agreement. The duration of the grant agreement is three years. During the year ended December 29, 2025, the Company received government assistance of $20,396 in cash, of which $17,844 resulted from investment of manufacturing equipment and was recorded as a reduction to property, plant, and equipment, net on the consolidated balance sheets.

[0001193125-26-051976:notes:118]
Recently Adopted and Issued Accounting Standards

[0001193125-26-051976:notes:119]
Recently Adopted Accounting Standards

[0001193125-26-051976:notes:120]
In December 2023, the FASB issued ASU 2023-09, Income Taxes (Topic 740): Improvements to Income Tax Disclosures, which requires disclosure of disaggregated income taxes paid, prescribes standard categories for the components of the effective tax rate reconciliation, and modifies other income tax-related disclosures. The Company adopted ASU 2023-09 on a prospective basis for the year ended December 29, 2025. See Note 8, Income Taxes, for further information.

[0001193125-26-051976:notes:121]
Recently Issued Accounting Standards Not Yet Adopted

[0001193125-26-051976:notes:122]
In December 2025, the FASB issued ASU 2025-10, Accounting for Government Grants Received by Business Entities, to provide guidance on how business entities should recognize, measure, and present government grants received. The ASU is effective for annual periods beginning after December 15, 2028, and interim periods within those annual reporting periods. Early adoption is permitted. The guidance may be applied on a modified prospective basis, a modified retrospective basis, or a retrospective basis. The Company is currently evaluating the timing of the adoption and the impact of this ASU on its consolidated financial statements and related disclosures.

[0001193125-26-051976:notes:123]
In September 2025, the FASB issued ASU 2025-06, Targeted Improvements to the Accounting for Internal-Use Software, which amends the existing standard to remove all references to prescriptive and sequential software development project stages. Under this guidance, eligible software development costs will begin capitalization when management has authorized and committed to funding the software project, and it is probable that the project will be completed and the software will be used to perform the function intended. The ASU is effective for annual periods beginning after December 15, 2027, and interim periods within those annual reporting periods. Early adoption is permitted as of the beginning of an annual reporting period. The guidance may be applied on a prospective basis, a modified basis, or a retrospective basis. The Company is currently evaluating the timing of the adoption and the impact of this ASU on its consolidated financial statements and related disclosures.

[0001193125-26-051976:notes:124]
In November 2024, the FASB issued ASU 2024-03, Income Statement-Reporting Comprehensive Income-Expense Disaggregation Disclosures (Subtopic 220-40): Disaggregation of Income Statement Expenses, which requires disclosure in the notes to the financial statements of specified information about certain costs and expenses. In January 2025, the FASB issued ASU 2025-01, Income Statement-Reporting Comprehensive Income-Expense Disaggregation Disclosures (Subtopic 220-40): Clarifying the Effective Date, which amends the effective date of ASU 2024-03 to clarify that all public business entities are required to adopt the guidance in annual reporting periods beginning after December 15, 2026, and interim periods within annual reporting periods beginning after December 15, 2027. Early adoption of ASU 2024-03 is permitted. ASU 2024-03 should be applied either prospectively to financial statements issued for reporting periods after the effective date or retrospectively to any or all prior periods presented in the financial statements. The Company is currently evaluating the new guidance to determine the impact it may have on its consolidated financial statements and related disclosures, but expects additional disclosures upon adoption.


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0001193125-26-051976:notes:125]
(2)
Revenues

[0001193125-26-051976:notes:126]
For contracts in which anticipated total costs exceed the total expected revenue, an estimated loss is recognized in the period when identifiable. A provision for the entire amount of the estimated loss is recorded on a cumulative basis. The estimated remaining costs to complete for loss contracts as of December 29, 2025 and December 30, 2024 were $33,163 and $36,976, respectively.

[0001193125-26-051976:notes:127]
As of December 29, 2025, the aggregate amount of the transaction price allocated to remaining performance obligations for long‑term contracts was $415,062. The Company expects to recognize revenue on approximately 62% of the remaining performance obligations for the Company’s long-term contracts over the next 12 months with the remaining amount expected to be recognized thereafter. The remaining performance obligations for the Company’s short‑term contracts are expected to be recognized within one year, and the Company is applying the optional exemption to not disclose the amount of transaction price allocated to the remaining performance obligations for contracts with an expected duration of one year or less.

[0001193125-26-051976:notes:128]
As of December 29, 2025, total contract assets were $472,255, of which $468,006 are expected to be collected within one year and recorded as contract assets and $4,249 are expected to be collected after one year and included as a component of deposits and other non-current assets on the consolidated balance sheets. As of December 30, 2024, total contract assets were $386,817, of which $381,382 were expected to be collected within one year and recorded as contract assets and $5,435 were expected to be collected after one year and included as a component of deposits and other non-current assets on the consolidated balance sheets. The increase in total contract assets in 2025 is primarily due to recognition of revenues for which invoicing had not yet occurred. In 2025, there were no material impairment losses on contract assets.

[0001193125-26-051976:notes:129]
Contract liabilities were $175,627 and $170,915 as of December 29, 2025 and December 30, 2024, respectively, and represent customer advances for work yet to be performed. The contract liabilities increased by $4,712 due to timing of customer billings and/or payments. Revenue recognized for the year ended December 29, 2025 from amounts recorded as contract liabilities as of December 30, 2024 was $106,638.

[0001193125-26-051976:notes:130]
Disaggregated Revenue

[0001193125-26-051976:notes:131]
Revenue from products and services transferred to customers over time and at a point in time accounted for 96% and 4%, respectively, of the Company’s revenue in 2025, 2024, and 2023.

[0001193125-26-051976:notes:132]
Disaggregated revenue by principal end markets within reportable segments was as follows:

[0001193125-26-051976:notes:133]
|  |  | For the Year Ended December 29, 2025 |  |
|  |  | A&D |  |  | Commercial |  |  | RF&S Components |  |  | Total |  |
|  |  | (In thousands) |  |
| End Markets (1): |  |  |  |  |  |  |  |  |  |  |  |  |
| Aerospace and Defense |  | $ | 1,281,536 |  |  | $ | — |  |  | $ | — |  |  | $ | 1,281,536 |  |
| Automotive |  |  | — |  |  |  | 302,194 |  |  |  | — |  |  |  | 302,194 |  |
| Data Center Computing |  |  | — |  |  |  | 682,374 |  |  |  | 1,019 |  |  |  | 683,393 |  |
| Medical/Industrial/Instrumentation |  |  | — |  |  |  | 405,132 |  |  |  | 4,329 |  |  |  | 409,461 |  |
| Networking |  |  | — |  |  |  | 195,151 |  |  |  | 34,610 |  |  |  | 229,761 |  |
| Total |  | $ | 1,281,536 |  |  | $ | 1,584,851 |  |  | $ | 39,958 |  |  | $ | 2,906,345 |  |

[0001193125-26-051976:notes:134]
|  |  | For the Year Ended December 30, 2024 |  |
|  |  | A&D |  |  | Commercial |  |  | RF&S Components |  |  | Total |  |
|  |  | (In thousands) |  |
| End Markets (1): |  |  |  |  |  |  |  |  |  |  |  |  |
| Aerospace and Defense |  | $ | 1,130,781 |  |  | $ | — |  |  | $ | — |  |  | $ | 1,130,781 |  |
| Automotive |  |  | — |  |  |  | 315,125 |  |  |  | — |  |  |  | 315,125 |  |
| Data Center Computing |  |  | — |  |  |  | 500,798 |  |  |  | 619 |  |  |  | 501,417 |  |
| Medical/Industrial/Instrumentation |  |  | — |  |  |  | 332,346 |  |  |  | 2,809 |  |  |  | 335,155 |  |
| Networking |  |  | — |  |  |  | 126,565 |  |  |  | 33,710 |  |  |  | 160,275 |  |
| Total |  | $ | 1,130,781 |  |  | $ | 1,274,834 |  |  | $ | 37,138 |  |  | $ | 2,442,753 |  |

[0001193125-26-051976:notes:135]
|  |  | For the Year Ended January 1, 2024 |  |
|  |  | A&D |  |  | Commercial |  |  | RF&S Components |  |  | Total |  |
|  |  | (In thousands) |  |
| End Markets (1): |  |  |  |  |  |  |  |  |  |  |  |  |
| Aerospace and Defense |  | $ | 1,030,491 |  |  | $ | — |  |  | $ | 18 |  |  | $ | 1,030,509 |  |
| Automotive |  |  | — |  |  |  | 351,477 |  |  |  | — |  |  |  | 351,477 |  |
| Data Center Computing |  |  | — |  |  |  | 313,378 |  |  |  | 51 |  |  |  | 313,429 |  |
| Medical/Industrial/Instrumentation |  |  | — |  |  |  | 357,264 |  |  |  | 3,448 |  |  |  | 360,712 |  |
| Networking |  |  | — |  |  |  | 141,436 |  |  |  | 35,004 |  |  |  | 176,440 |  |
| Total |  | $ | 1,030,491 |  |  | $ | 1,163,555 |  |  | $ | 38,521 |  |  | $ | 2,232,567 |  |

[0001193125-26-051976:notes:136]
(1)
The end market revenue for the years ended December 30, 2024 and January 1, 2024 has been recast to reflect certain adjustments to allocations resulting from the segment reorganization that occurred during the quarter ended June 30, 2025. The end market revenue excludes intersegment sales totaling $11,893, $10,220, and $16,707 for the years ended December 29, 2025, December 30, 2024, and January 1, 2024, respectively. See Note 4, Segment Information, for further information.


## us-gaap:ConcentrationRiskDisclosureTextBlock

[0001193125-26-051976:notes:137]
(3)
Significant Customers and Concentration of Credit Risk

[0001193125-26-051976:notes:138]
Financial instruments that are potentially subject to concentrations of credit risk are primarily cash and cash equivalents and accounts receivable.

[0001193125-26-051976:notes:139]
The Company had cash and cash equivalents held by its foreign subsidiaries of $191,925 and $207,909 as of December 29, 2025 and December 30, 2024, respectively. The Company maintains its cash and cash equivalents with major financial institutions and such balances exceed Federal Deposit Insurance Corporation (FDIC) insurance limits. The Company has not experienced any losses in such accounts and believes it is not exposed to any significant risk on cash and cash equivalents.

[0001193125-26-051976:notes:140]
In the normal course of business, the Company extends credit to its customers. Some customers to whom the Company extends credit are located outside the United States. The Company performs ongoing credit evaluations of customers, does not require collateral, and considers the credit risk profile of the entity from which the receivable is due in further evaluating collection risk. As of December 29, 2025, one customer accounted for 14% of the Company's accounts receivable. There were no customers that accounted for 10% or more of the Company's accounts receivable as of December 30, 2024.

[0001193125-26-051976:notes:141]
The Company’s customers include both OEMs and EMS companies. The Company’s OEM customers often direct a significant portion of their purchases through EMS companies. While the Company’s customers include both OEM and EMS providers, the Company measures customer concentration based on OEM companies, as they are the ultimate end customers.

[0001193125-26-051976:notes:142]
For the year ended December 29, 2025, two customers collectively accounted for approximately 23% of the Company's net sales. For the years ended December 30, 2024 and January 1, 2024, one customer accounted for approximately 11% and 13%, respectively, of the Company's net sales.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001193125-26-051976:notes:143]
(4)
Segment Information

[0001193125-26-051976:notes:144]
During the quarter ended June 30, 2025, in connection with the Company's change in organizational structure to enhance clarity in sector performance, accountability, and operating costs, the Company’s management finalized its assessment of the Company's operating segments and concluded that the Company now has three reportable segments: A&D, Commercial, and RF&S Components. In prior periods, the Company had two reportable segments: PCB and RF&S Components. As a result, certain prior period amounts have been reclassified to conform with this new presentation.

[0001193125-26-051976:notes:145]
The reportable segments shown below are the Company’s segments for which separate financial information is available and upon which operating results are evaluated by the CODM, who is the President and Chief Executive Officer, to assess performance and to allocate resources. The CODM uses segment operating income to allocate resources such as employees and capital resources for each segment during the Company’s annual budgeting and forecasting process. Total sales and operating profit by segment include intersegment sales which are generally recorded at cost-plus a specified fee or at a negotiated fixed price. Separate segment asset measures are not used as a basis for the CODM to evaluate the performance of or to allocate resources to the segments.

[0001193125-26-051976:notes:146]
The A&D reportable segment consists of PCBs, value-added assemblies, microelectronics, RF/microwave components and assemblies, and integrated mission systems. These highly engineered electronics products include the manufacture and test of customer‑supplied designs as well as long-term contracts to design, develop, manufacture, and test new products. The products in the A&D reportable segment support surveillance, intelligence, communications, and other critical missions for customers in the aerospace and defense industry. The Commercial reportable segment consists of PCBs using customer-supplied engineering and design plans supporting customers in the automotive, medical, industrial, and instrumentation, networking, and data center computing end markets. The RF&S Components reportable segment consists of TTM designed RF components for commercial customers in the telecommunications, industrial, and instrumentation markets, as well as commercial off-the-shelf (COTS) components for certain aerospace and defense customers.

[0001193125-26-051976:notes:147]
Reconciliations of net sales and segment operating income were as follows:

[0001193125-26-051976:notes:148]
|  |  | For the Year Ended December 29, 2025 |
|  |  | A&D |  |  | Commercial |  |  | RF&S Components |  |  | Eliminations |  |  | Total |
|  |  | (In thousands, except margin rates) |
| Net sales |  | $ | 1,281,536 |  |  | $ | 1,584,851 |  |  | $ | 39,958 |  |  | $ | — |  |  | $ | 2,906,345 |  |  |
| Intersegment sales |  |  | 10,987 |  |  |  | 850 |  |  |  | 56 |  |  |  | (11,893 | ) |  |  | — |  |  |
| Segment sales |  | $ | 1,292,523 |  |  | $ | 1,585,701 |  |  | $ | 40,014 |  |  | $ | (11,893 | ) |  | $ | 2,906,345 |  |  |
|  |  | Net Sales |  |  | Cost of Goods Sold |  |  | Operating Expenses |  |  | Operating Income |  |  | Operating Margin |
| A&D |  | $ | 1,292,523 |  |  | $ | (988,792 | ) |  | $ | (119,918 | ) |  | $ | 183,813 |  |  |  | 14.2 |  | % |
| Commercial |  |  | 1,585,701 |  |  |  | (1,271,779 | ) |  |  | (75,141 | ) |  |  | 238,781 |  |  |  | 15.1 |  |  |
| RF&S Components |  |  | 40,014 |  |  |  | (19,640 | ) |  |  | (9,121 | ) |  |  | 11,253 |  |  |  | 28.1 |  |  |
| Total segment |  |  | 2,918,238 |  |  |  | (2,280,211 | ) |  |  | (204,180 | ) |  |  | 433,847 |  |  |  | 14.9 |  |  |
| Eliminations |  |  | (11,893 | ) |  |  |  |  |  |  |  |  | — |  |  |  |  |  |
| Unallocated amounts: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Restructuring |  |  |  |  |  |  |  |  |  |  |  | (2,847 | ) |  |  |  |  |
| Acquisition-related and other charges |  |  |  |  |  |  |  |  |  |  |  | (15 | ) |  |  |  |  |
| Stock-based compensation |  |  |  |  |  |  |  |  |  |  |  | (41,668 | ) |  |  |  |  |
| Other corporate expenses |  |  |  |  |  |  |  |  |  |  |  | (87,736 | ) |  |  |  |  |
| Amortization of definite-lived intangibles |  |  |  |  |  |  |  |  |  |  |  | (36,897 | ) |  |  |  |  |
| Consolidated |  | $ | 2,906,345 |  |  |  |  |  |  |  |  |  | 264,684 |  |  |  | 9.1 |  | % |
| Interest expense |  |  |  |  |  |  |  |  |  |  |  | (45,334 | ) |  |  |  |  |
| Other, net |  |  |  |  |  |  |  |  |  |  |  | (9,013 | ) |  |  |  |  |
| Income before income taxes |  |  |  |  |  |  |  |  |  |  | $ | 210,337 |  |  |  |  |  |

[0001193125-26-051976:notes:149]
|  |  | For the Year Ended December 30, 2024 |
|  |  | A&D |  |  | Commercial |  |  | RF&S Components |  |  | Eliminations |  |  | Total |
|  |  | (In thousands, except margin rates) |
| Net sales |  | $ | 1,130,781 |  |  | $ | 1,274,834 |  |  | $ | 37,138 |  |  | $ | — |  |  | $ | 2,442,753 |  |  |
| Intersegment sales |  |  | 9,174 |  |  |  | 867 |  |  |  | 179 |  |  |  | (10,220 | ) |  |  | — |  |  |
| Segment sales |  | $ | 1,139,955 |  |  | $ | 1,275,701 |  |  | $ | 37,317 |  |  | $ | (10,220 | ) |  | $ | 2,442,753 |  |  |
|  |  | Net Sales |  |  | Cost of Goods Sold |  |  | Operating Expenses |  |  | Operating Income |  |  | Operating Margin |
| A&D |  | $ | 1,139,955 |  |  | $ | (883,450 | ) |  | $ | (114,705 | ) |  | $ | 141,800 |  |  |  | 12.4 |  | % |
| Commercial |  |  | 1,275,701 |  |  |  | (1,029,647 | ) |  |  | (66,272 | ) |  |  | 179,782 |  |  |  | 14.1 |  |  |
| RF&S Components |  |  | 37,317 |  |  |  | (19,139 | ) |  |  | (9,512 | ) |  |  | 8,666 |  |  |  | 23.2 |  |  |
| Total segment |  |  | 2,452,973 |  |  |  | (1,932,236 | ) |  |  | (190,489 | ) |  |  | 330,248 |  |  |  | 13.5 |  |  |
| Eliminations |  |  | (10,220 | ) |  |  |  |  |  |  |  |  | — |  |  |  |  |  |
| Unallocated amounts: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Restructuring |  |  |  |  |  |  |  |  |  |  |  | (11,200 | ) |  |  |  |  |
| Impairment of goodwill |  |  |  |  |  |  |  |  |  |  |  | (32,600 | ) |  |  |  |  |
| Gain on sale of property, plant, and equipment |  |  |  |  |  |  |  |  |  |  |  | 15,669 |  |  |  |  |  |
| Acquisition-related and other charges |  |  |  |  |  |  |  |  |  |  |  | (14,524 | ) |  |  |  |  |
| Stock-based compensation |  |  |  |  |  |  |  |  |  |  |  | (29,780 | ) |  |  |  |  |
| Other corporate expenses |  |  |  |  |  |  |  |  |  |  |  | (96,878 | ) |  |  |  |  |
| Amortization of definite-lived intangibles |  |  |  |  |  |  |  |  |  |  |  | (44,892 | ) |  |  |  |  |
| Consolidated |  | $ | 2,442,753 |  |  |  |  |  |  |  |  |  | 116,043 |  |  |  | 4.8 |  | % |
| Interest expense |  |  |  |  |  |  |  |  |  |  |  | (47,515 | ) |  |  |  |  |
| Other, net |  |  |  |  |  |  |  |  |  |  |  | 15,421 |  |  |  |  |  |
| Income before income taxes |  |  |  |  |  |  |  |  |  |  | $ | 83,949 |  |  |  |  |  |

[0001193125-26-051976:notes:150]
|  |  | For the Year Ended January 1, 2024 |
|  |  | A&D |  |  | Commercial |  |  | RF&S Components |  |  | Eliminations |  |  | Total |
|  |  | (In thousands, except margin rates) |
| Net sales |  | $ | 1,030,491 |  |  | $ | 1,163,555 |  |  | $ | 38,521 |  |  | $ | — |  |  | $ | 2,232,567 |  |  |
| Intersegment sales |  |  | 15,492 |  |  |  | 1,117 |  |  |  | 98 |  |  |  | (16,707 | ) |  |  | — |  |  |
| Segment sales |  | $ | 1,045,983 |  |  | $ | 1,164,672 |  |  | $ | 38,619 |  |  | $ | (16,707 | ) |  | $ | 2,232,567 |  |  |
|  |  | Net Sales |  |  | Cost of Goods Sold |  |  | Operating Expenses |  |  | Operating Income |  |  | Operating Margin |
| A&D |  | $ | 1,045,983 |  |  | $ | (847,452 | ) |  | $ | (103,510 | ) |  | $ | 95,021 |  |  |  | 9.1 |  | % |
| Commercial |  |  | 1,164,672 |  |  |  | (930,144 | ) |  |  | (63,149 | ) |  |  | 171,379 |  |  |  | 14.7 |  |  |
| RF&S Components |  |  | 38,619 |  |  |  | (17,540 | ) |  |  | (10,124 | ) |  |  | 10,955 |  |  |  | 28.4 |  |  |
| Total segment |  |  | 2,249,274 |  |  |  | (1,795,136 | ) |  |  | (176,783 | ) |  |  | 277,355 |  |  |  | 12.3 |  |  |
| Eliminations |  |  | (16,707 | ) |  |  |  |  |  |  |  |  | — |  |  |  |  |  |
| Unallocated amounts: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Restructuring |  |  |  |  |  |  |  |  |  |  |  | (24,352 | ) |  |  |  |  |
| Impairment of goodwill |  |  |  |  |  |  |  |  |  |  |  | (44,100 | ) |  |  |  |  |
| Gain on sale of property, plant, and equipment |  |  |  |  |  |  |  |  |  |  |  | 195 |  |  |  |  |  |
| Acquisition-related and other charges |  |  |  |  |  |  |  |  |  |  |  | (4,529 | ) |  |  |  |  |
| Stock-based compensation |  |  |  |  |  |  |  |  |  |  |  | (22,887 | ) |  |  |  |  |
| Other corporate expenses |  |  |  |  |  |  |  |  |  |  |  | (77,790 | ) |  |  |  |  |
| Amortization of definite-lived intangibles |  |  |  |  |  |  |  |  |  |  |  | (61,576 | ) |  |  |  |  |
| Consolidated |  | $ | 2,232,567 |  |  |  |  |  |  |  |  |  | 42,316 |  |  |  | 1.9 |  | % |
| Interest expense |  |  |  |  |  |  |  |  |  |  |  | (48,124 | ) |  |  |  |  |
| Loss on extinguishment of debt |  |  |  |  |  |  |  |  |  |  |  | (1,154 | ) |  |  |  |  |
| Gain on sale of subsidiary |  |  |  |  |  |  |  |  |  |  |  | 1,270 |  |  |  |  |  |
| Other, net |  |  |  |  |  |  |  |  |  |  |  | 5,989 |  |  |  |  |  |
| Income before income taxes |  |  |  |  |  |  |  |  |  |  | $ | 297 |  |  |  |  |  |

[0001193125-26-051976:notes:151]
Amortization of definite-lived intangibles relates to the A&D, Commercial, and RF&S Components reportable segments, but is not reviewed separately by the CODM. For the years ended December 29, 2025, December 30, 2024, and January 1, 2024, amortization expense of $9,343, $9,342, and $12,292, respectively, is included in cost of goods sold for the A&D reportable segment. For the year ended January 1, 2024, amortization expense of $609 is included in cost of goods sold for the RF&S Components reportable segment.

[0001193125-26-051976:notes:152]
Depreciation expense by reportable segment was as follows:

[0001193125-26-051976:notes:153]
|  |  | For the Year Ended |  |
|  |  | December 29, 2025 |  |  | December 30, 2024 |  |  | January 1, 2024 |  |
|  |  | (In thousands) |  |
| A&D |  | $ | 33,770 |  |  | $ | 36,998 |  |  | $ | 42,587 |  |
| Commercial |  |  | 68,904 |  |  |  | 58,234 |  |  |  | 48,370 |  |
| RF&S Components |  |  | 1,765 |  |  |  | 1,693 |  |  |  | 1,833 |  |
| Segment total |  |  | 104,439 |  |  |  | 96,925 |  |  |  | 92,790 |  |
| Corporate |  |  | 5,835 |  |  |  | 8,308 |  |  |  | 6,365 |  |
| Total |  | $ | 110,274 |  |  | $ | 105,233 |  |  | $ | 99,155 |  |

[0001193125-26-051976:notes:154]
The Company markets and sells its products in approximately 60 countries. For the years ended December 29, 2025 and January 1, 2024, the Company did not conduct business in any country other than the United States in which its net sales in that country exceeded 10% of the Company’s total net sales. For the year ended December 30, 2024, in addition to the United States, net sales in Taiwan exceeded 10% of the Company’s total net sales. Net sales are attributed to countries by the invoiced location and were as follows:

[0001193125-26-051976:notes:155]
|  |  | For the Year Ended |  |
|  |  | December 29, 2025 |  |  | December 30, 2024 |  |  | January 1, 2024 |  |
|  |  | (In thousands) |  |
| United States |  | $ | 1,554,258 |  |  | $ | 1,232,288 |  |  | $ | 1,263,065 |  |
| Taiwan |  |  | 256,995 |  |  |  | 274,345 |  |  |  | 177,042 |  |
| Other |  |  | 1,095,092 |  |  |  | 936,120 |  |  |  | 792,460 |  |
| Total net sales |  | $ | 2,906,345 |  |  | $ | 2,442,753 |  |  | $ | 2,232,567 |  |

[0001193125-26-051976:notes:156]
Long-lived assets include property, plant, and equipment, goodwill, and definite-lived intangibles and were as follows:

[0001193125-26-051976:notes:157]
|  |  | As of |  |
|  |  | December 29, 2025 |  |  | December 30, 2024 |  |
|  |  | (In thousands) |  |
| United States |  | $ | 876,099 |  |  | $ | 1,171,611 |  |
| China |  |  | 732,843 |  |  |  | 357,159 |  |
| Other |  |  | 226,825 |  |  |  | 203,141 |  |
| Total |  | $ | 1,835,767 |  |  | $ | 1,731,911 |  |


## us-gaap:AdditionalFinancialInformationDisclosureTextBlock

[0001193125-26-051976:notes:158]
(5)
Composition of Certain Consolidated Financial Statement Captions

[0001193125-26-051976:notes:159]
|  |  | As of |  |
|  |  | December 29, 2025 |  |  | December 30, 2024 |  |
|  |  | (In thousands) |  |
| Inventories: |  |  |  |  |  |  |
| Raw materials |  | $ | 197,531 |  |  | $ | 178,066 |  |
| Work-in-process |  |  | 48,236 |  |  |  | 45,580 |  |
| Finished goods |  |  | 4,290 |  |  |  | 1,339 |  |
| Inventories |  | $ | 250,057 |  |  | $ | 224,985 |  |
| Property, plant, and equipment, net: |  |  |  |  |  |  |
| Land and land use rights |  | $ | 72,342 |  |  | $ | 69,788 |  |
| Buildings and improvements |  |  | 634,785 |  |  |  | 515,773 |  |
| Machinery and equipment |  |  | 1,187,187 |  |  |  | 1,116,658 |  |
| Furniture and fixtures and other |  |  | 11,642 |  |  |  | 11,115 |  |
| Construction-in-progress |  |  | 101,945 |  |  |  | 75,502 |  |
| Property, plant, and equipment, gross |  |  | 2,007,901 |  |  |  | 1,788,836 |  |
| Less: Accumulated depreciation |  |  | (997,191 | ) |  |  | (918,879 | ) |
| Property, plant, and equipment, net |  | $ | 1,010,710 |  |  | $ | 869,957 |  |
| Other current liabilities: |  |  |  |  |  |  |
| Sales return and allowances |  | $ | 12,392 |  |  | $ | 10,777 |  |
| Accrued facility operating costs |  |  | 10,497 |  |  |  | 8,925 |  |
| Operating leases |  |  | 8,909 |  |  |  | 7,556 |  |
| Interest |  |  | 8,792 |  |  |  | 9,054 |  |
| Housing fund |  |  | 8,783 |  |  |  | 7,927 |  |
| Income taxes payable |  |  | 8,080 |  |  |  | 15,919 |  |
| Warranty |  |  | 7,855 |  |  |  | 7,685 |  |
| Accrued professional fees |  |  | 3,522 |  |  |  | 3,606 |  |
| Other |  |  | 37,420 |  |  |  | 48,525 |  |
| Other current liabilities |  | $ | 106,250 |  |  | $ | 119,974 |  |
| Other long-term liabilities: |  |  |  |  |  |  |
| Deferred income taxes |  | $ | 46,334 |  |  | $ | 41,362 |  |
| Customer deposits |  |  | 23,465 |  |  |  | 28,390 |  |
| Finance leases |  |  | 15,829 |  |  |  | 11,985 |  |
| Other |  |  | 30,393 |  |  |  | 26,011 |  |
| Other long-term liabilities |  | $ | 116,021 |  |  | $ | 107,748 |  |


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0001193125-26-051976:notes:160]
(6)
Goodwill and Definite-lived Intangibles

[0001193125-26-051976:notes:161]
In connection with the Company’s assessment of its operating segments, effective during the quarter ended June 30, 2025, the Company determined that its operating segments were also its reporting units and reallocated its PCB goodwill between A&D and Commercial based on the estimated relative fair values of the reporting units. In connection with the reallocation of goodwill, management performed a goodwill impairment assessment for each segment and concluded no impairment indicators existed as of June 30, 2025.

[0001193125-26-051976:notes:162]
Goodwill by reportable segment was as follows:

[0001193125-26-051976:notes:163]
|  |  | A&D |  |  | Commercial |  |  | RF&S Components |  |  | Total |  |
|  |  | (In thousands) |  |
| As of December 29, 2025 and December 30, 2024 |  |  |  |  |  |  |  |  |  |  |  |  |
| Goodwill |  | $ | 256,199 |  |  | $ | 382,636 |  |  | $ | 177,200 |  |  | $ | 816,035 |  |
| Accumulated impairment losses |  |  | — |  |  |  | — |  |  |  | (145,900 | ) |  |  | (145,900 | ) |
| Carrying amount |  | $ | 256,199 |  |  | $ | 382,636 |  |  | $ | 31,300 |  |  | $ | 670,135 |  |

[0001193125-26-051976:notes:164]
In the fourth quarter of 2025, the Company performed its annual goodwill impairment test qualitatively and concluded that it was more likely than not that there was no impairment to goodwill.

[0001193125-26-051976:notes:165]
Definite-lived Intangibles

[0001193125-26-051976:notes:166]
The components of definite-lived intangibles were as follows:

[0001193125-26-051976:notes:167]
|  |  | GrossAmount |  |  | AccumulatedAmortization |  |  | NetCarryingAmount |  |  | WeightedAverageAmortizationPeriod |  |
|  |  | (In thousands) |  |  | (In years) |  |
| As of December 29, 2025 |  |  |  |  |  |  |  |  |  |  |  |  |
| Customer relationships |  | $ | 323,500 |  |  | $ | (189,264 | ) |  | $ | 134,236 |  |  |  | 11.8 |  |
| Technology |  |  | 66,650 |  |  |  | (45,964 | ) |  |  | 20,686 |  |  |  | 8.2 |  |
| Total |  | $ | 390,150 |  |  | $ | (235,228 | ) |  | $ | 154,922 |  |  |  |  |
| As of December 30, 2024 |  |  |  |  |  |  |  |  |  |  |  |  |
| Customer relationships |  | $ | 323,500 |  |  | $ | (161,710 | ) |  | $ | 161,790 |  |  |  | 11.8 |  |
| Technology |  |  | 66,650 |  |  |  | (36,621 | ) |  |  | 30,029 |  |  |  | 8.2 |  |
| Total |  | $ | 390,150 |  |  | $ | (198,331 | ) |  | $ | 191,819 |  |  |  |  |

[0001193125-26-051976:notes:168]
Amortization expense was $36,897, $44,892, and $61,576 for the years ended December 29, 2025, December 30, 2024, and January 1, 2024, respectively. For the years ended December 29, 2025, December 30, 2024, and January 1, 2024, $9,343, $9,342, and $12,901, respectively, of amortization expense was included in cost of goods sold.

[0001193125-26-051976:notes:169]
In connection with the finalization of acquired identifiable intangible asset valuation during the second quarter of 2023 related to the Company's acquisition in 2022 of Telephonics, the Company recorded amortization expense of $24,877 related to the acquired identifiable intangible assets during the year ended January 1, 2024. For the year ended January 1, 2024, $8,850 of amortization expense related to the acquired identifiable intangible assets was included in cost of goods sold.

[0001193125-26-051976:notes:170]
Estimated aggregate amortization for definite-lived intangible assets for the next five years and thereafter is as follows:

[0001193125-26-051976:notes:171]
|  |  | (In thousands) |  |
| 2026 |  | $ | 36,897 |  |
| 2027 |  |  | 34,543 |  |
| 2028 |  |  | 30,997 |  |
| 2029 |  |  | 22,355 |  |
| 2030 |  |  | 18,178 |  |
| Thereafter |  |  | 11,952 |  |
| Total |  | $ | 154,922 |  |


## us-gaap:LongTermDebtTextBlock

[0001193125-26-051976:notes:172]
(7)
Long-term Debt and Letters of Credit

[0001193125-26-051976:notes:173]
Long-term debt was as follows:

[0001193125-26-051976:notes:174]
|  |  | As of December 29, 2025 |  |  | As of December 30, 2024 |  |
|  |  | Interest Rate |  | Principal Outstanding |  |  | Interest Rate |  | Principal Outstanding |  |
|  |  | (In thousands, except interest rates) |  |
| Senior Notes due March 2029 |  |  | 4.00 |  | % |  | $ | 500,000 |  |  |  | 4.00 |  | % |  | $ | 500,000 |  |
| Term Loan due May 2030 |  |  | 5.97 |  |  |  |  | 342,169 |  |  |  | 6.59 |  |  |  |  | 345,634 |  |
| Asia ABL Revolving Loan due June 2028 |  |  | 5.02 |  |  |  |  | 80,000 |  |  |  | 5.64 |  |  |  |  | 80,000 |  |
| Other |  |  | 5.99 |  |  |  |  | 1,981 |  |  |  | 5.99 |  |  |  |  | 2,311 |  |
| Total debt |  |  |  |  |  |  | 924,150 |  |  |  |  |  |  |  | 927,945 |  |
| Less: Unamortized debt issuance costs |  |  |  |  |  |  | (5,617 | ) |  |  |  |  |  |  | (6,951 | ) |
| Less: Unamortized debt discount |  |  |  |  |  |  | (2,382 | ) |  |  |  |  |  |  | (2,840 | ) |
| Subtotal |  |  |  |  |  |  | 916,151 |  |  |  |  |  |  |  | 918,154 |  |
| Less: Current maturities |  |  |  |  |  |  | (3,815 | ) |  |  |  |  |  |  | (3,795 | ) |
| Long-term debt, less current maturities |  |  |  |  |  | $ | 912,336 |  |  |  |  |  |  | $ | 914,359 |  |

[0001193125-26-051976:notes:175]
The fiscal calendar maturities of debt for the next five years are as follows:

[0001193125-26-051976:notes:176]
|  |  | (In thousands) |  |
| 2026 |  | $ | 3,815 |  |
| 2027 |  |  | 4,735 |  |
| 2028 |  |  | 83,828 |  |
| 2029 |  |  | 503,018 |  |
| 2030 |  |  | 328,754 |  |
| Total |  | $ | 924,150 |  |

[0001193125-26-051976:notes:177]
Senior Notes due 2029

[0001193125-26-051976:notes:178]
On March 10, 2021, the Company issued $500,000 of Senior Notes due 2029, which are included in long-term debt and bear interest at a rate of 4.0% per annum. Interest is payable semiannually in arrears on March 1 and September 1 of each year beginning September 1, 2021. The Senior Notes due 2029 will mature on March 1, 2029.

[0001193125-26-051976:notes:179]
The Senior Notes due 2029 are irrevocably and unconditionally guaranteed, jointly and severally, on a senior unsecured basis by the Company’s existing and future domestic subsidiaries, subject to certain exceptions. The Senior Notes due 2029 and related guarantees are senior unsecured obligations of, respectively, the Company and applicable subsidiary guarantors.

[0001193125-26-051976:notes:180]
Term Loan Facility

[0001193125-26-051976:notes:181]
On August 1, 2024, the Company entered into the Term Loan Facility, by and among the Company, as Borrower, JPMorgan Chase Bank, N.A., as Administrative Agent, and the several lenders from time to time parties thereto, pursuant to which the Company closed its $346,500 senior secured term loan that bears interest at a floating rate of 1-month CME SOFR plus an applicable margin of 2.25%. The Term Loan Facility is issued at par and matures on May 30, 2030, and the majority is a cashless rollover from the previous term loan facility. This Term Loan Facility had an outstanding balance of $342,169 as of December 29, 2025, of which $3,465 is included in short-term debt and $338,704 is included in long-term debt. The Term Loan Facility was issued with a 1.0% original issue discount. There is no provision, other than an event of default, for the interest margin to increase. The Company is required to make quarterly principal repayments in an aggregate annual amount equal to 1% of the $346,500 aggregate principal amount of the Term Loan Facility. Such principal repayment is payable quarterly on January 1, April 1, July 1, and October 1 and ending with the last such day to occur prior to May 30, 2030. The remaining principal under the Term Loan Facility is scheduled to mature on May 30, 2030. In addition, the Term Loan Facility permits the Company to add one or more senior secured incremental term loan facilities to the Term Loan Facility subject to the satisfaction of certain conditions.

[0001193125-26-051976:notes:182]
The obligations under the Term Loan Facility are unconditionally guaranteed by the Guarantors. The Term Loan Facility is secured by (i) a perfected first priority security interest in substantially all of the assets of the Company and the Guarantors (other than the U.S. ABL Priority Collateral), including all of the total outstanding voting capital stock held by the Company and the Guarantors (subject to a limitation of 65% on pledges of such capital stock of certain foreign subsidiaries and domestic holding companies of

[0001193125-26-051976:notes:183]
foreign subsidiaries) and (ii) a perfected second priority interest in all of the U.S. ABL Priority Collateral. The Term Loan Facility is structurally senior to the Company’s Senior Notes due 2029.

[0001193125-26-051976:notes:184]
Based on certain parameters defined in the Term Loan Facility, including a Secured Leverage Ratio, the Company may be required to make an additional principal payment on an annual basis if its Secured Leverage Ratio is greater than 2.0.

[0001193125-26-051976:notes:185]
Borrowings under the Term Loan Facility are subject to certain affirmative and negative covenants, including limitations on indebtedness, corporate transactions, investments, dispositions, and share payments.

[0001193125-26-051976:notes:186]
Asset-Based Lending Agreements

[0001193125-26-051976:notes:187]
The U.S. ABL is comprised of a revolving credit facility for up to $150,000 and a sublimit for letter of credit for up to $50,000, provided that at no time may amounts outstanding under the agreement exceed in the aggregate $150,000 or the applicable borrowing base, which is the sum of (i) a percentage of the principal amount of “Eligible Accounts”, plus (ii) a percentage of the net orderly liquidation value of (x) “Eligible Inventory”, minus (y) “Inventory Reserves” applicable thereto, minus (iii) “Reserves”, each as defined in the U.S. ABL agreement. Borrowings under the U.S. ABL bear interest at a floating rate of Term SOFR plus a margin ranging from 1.25% to 1.50%. The applicable margin can vary based on the remaining availability of the facility, from 1.25% to 1.50% for Term SOFR-based loans and from 0.25% to 0.50% for JPMorgan Chase Bank’s prime rate-based loans. Other than availability and an event of default, there are no other provisions for the interest margin to increase.

[0001193125-26-051976:notes:188]
The U.S. ABL is scheduled to mature on May 30, 2028. The Guarantors have also fully guaranteed the full and timely payment of all obligations in respect of the U.S. ABL. Loans made under the U.S. ABL are secured by U.S. ABL Priority Collateral as well as by a perfected second priority interest in all of the collateral securing the Term Loan Facility.

[0001193125-26-051976:notes:189]
The Asia ABL is comprised of a revolving credit facility for up to $150,000 and a sublimit for letter of credit for up to $100,000, provided that at no time may amounts outstanding under the agreement exceed in aggregate $150,000 or the applicable borrowing base, which is a percentage of the principal amount of Eligible Accounts, as defined in the Asia ABL agreement. Borrowings under the Asia ABL bear interest at a floating rate of Term SOFR plus 1.30%. There is no provision, other than an event of default, for the interest margin to increase. As of December 29, 2025, the interest rate on the outstanding borrowings under the Asia ABL was 5.02%. As of December 29, 2025, $80,000 under the Asia ABL was outstanding and classified as long-term debt, which is consistent with its maturity date.

[0001193125-26-051976:notes:190]
The Asia ABL is scheduled to mature on June 13, 2028. Loans made under the Asia ABL are secured by a portion of the Company’s Asia Pacific cash and receivables and are structurally senior to the Company’s domestic obligations, including the Senior Notes due 2029.

[0001193125-26-051976:notes:191]
As of December 29, 2025, letters of credit in the amount of $6,628 were outstanding under the U.S. ABL and $17,540 were outstanding under the Asia ABL with various maturities through February 2027. Available borrowing capacity under the U.S. ABL and the Asia ABL was $143,372 and $52,460 respectively, which considers letters of credit outstanding as of December 29, 2025.

[0001193125-26-051976:notes:192]
The Company is required to pay a commitment fee of 0.25% per annum on any unused portion of the ABL Revolving Loans. The Company incurred total commitment fees related to unused borrowing availability of $504, $476, and $620 for the years ended December 29, 2025, December 30, 2024, and January 1, 2024, respectively. Under the occurrence of certain events, the ABL Revolving Loans are subject to various financial covenants, including leverage and fixed charge coverage ratios.

[0001193125-26-051976:notes:193]
Debt Issuance Costs and Debt Discount

[0001193125-26-051976:notes:194]
Remaining unamortized debt issuance costs and debt discount were as follows:

[0001193125-26-051976:notes:195]
|  |  | As of December 29, 2025 |  | As of December 30, 2024 |
|  |  | DebtIssuance Costs |  |  | DebtDiscount |  |  | EffectiveInterest Rate |  | DebtIssuance Costs |  |  | DebtDiscount |  |  | EffectiveInterest Rate |
|  |  | (In thousands, except interest rates) |
| Senior Notes due March 2029 |  | $ | 2,608 |  |  | $ | — |  |  |  | 4.18 |  | % |  | $ | 3,362 |  |  | $ | — |  |  |  | 4.18 |  | % |
| Term Loan due May 2030 |  |  | 3,009 |  |  |  | 2,382 |  |  |  | 8.01 |  |  |  |  | 3,589 |  |  |  | 2,840 |  |  |  | 8.01 |  |  |
| Total |  | $ | 5,617 |  |  | $ | 2,382 |  |  |  |  |  |  | $ | 6,951 |  |  | $ | 2,840 |  |  |  |  |  |

[0001193125-26-051976:notes:196]
The above debt issuance costs and debt discount are recorded as a reduction of the debt and are amortized into interest expense using an effective interest rate over the duration of the debt.

[0001193125-26-051976:notes:197]
Remaining unamortized debt issuance costs for the ABL Revolving Loans of $874 and $1,239 as of December 29, 2025 and December 30, 2024, respectively, are included in deposits and other non-current assets and are amortized to interest expense over the duration of the ABL Revolving Loans using the straight-line method of amortization.

[0001193125-26-051976:notes:198]
As of December 29, 2025, the remaining weighted average amortization period for all unamortized debt issuance costs and debt discount was 3.9 years.

[0001193125-26-051976:notes:199]
Debt Covenants

[0001193125-26-051976:notes:200]
As of December 29, 2025, the Company was in compliance with the financial covenants under the Senior Notes due 2029, Term Loan Facility, and ABL Revolving Loans.

[0001193125-26-051976:notes:201]
Loss on Extinguishment of Debt

[0001193125-26-051976:notes:202]
During the year ended January 1, 2024, the Company recognized loss on extinguishment of debt of $1,154, primarily associated with the write-off of the remaining unamortized debt issuance costs and debt discount as a result of the repayment of the remaining outstanding balance of the previous Term Loan Facility that was due to mature September 2024.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001193125-26-051976:notes:203]
(8)
Income Taxes

[0001193125-26-051976:notes:204]
The components of income before income taxes from continuing operations were as follows:

[0001193125-26-051976:notes:205]
|  |  | For the Year Ended |  |
|  |  | December 29, 2025 |  |  | December 30, 2024 |  |  | January 1, 2024 |  |
|  |  | (In thousands) |  |
| United States |  | $ | 62,677 |  |  | $ | (36,745 | ) |  | $ | (105,101 | ) |
| Foreign |  |  | 147,660 |  |  |  | 120,694 |  |  |  | 105,398 |  |
| Income before income taxes |  | $ | 210,337 |  |  | $ | 83,949 |  |  | $ | 297 |  |

[0001193125-26-051976:notes:206]
The components of income tax provision from continuing operations were as follows:

[0001193125-26-051976:notes:207]
|  |  | For the Year Ended |  |
|  |  | December 29, 2025 |  |  | December 30, 2024 |  |  | January 1, 2024 |  |
|  |  | (In thousands) |  |
| Current (provision) benefit: |  |  |  |  |  |  |  |  |  |
| Federal |  | $ | (3,235 | ) |  | $ | (2,984 | ) |  | $ | 445 |  |
| State |  |  | (2,900 | ) |  |  | (2,958 | ) |  |  | (1,592 | ) |
| Foreign |  |  | (22,964 | ) |  |  | (22,934 | ) |  |  | (29,094 | ) |
| Total current |  |  | (29,099 | ) |  |  | (28,876 | ) |  |  | (30,241 | ) |
| Deferred (provision) benefit: |  |  |  |  |  |  |  |  |  |
| Federal |  |  | (1,664 | ) |  |  | 340 |  |  |  | 1,321 |  |
| State |  |  | (216 | ) |  |  | 85 |  |  |  | 271 |  |
| Foreign |  |  | (1,910 | ) |  |  | 801 |  |  |  | 9,634 |  |
| Total deferred |  |  | (3,790 | ) |  |  | 1,226 |  |  |  | 11,226 |  |
| Total income tax (provision) benefit: |  |  |  |  |  |  |  |  |  |
| Federal |  |  | (4,899 | ) |  |  | (2,644 | ) |  |  | 1,766 |  |
| State |  |  | (3,116 | ) |  |  | (2,873 | ) |  |  | (1,321 | ) |
| Foreign |  |  | (24,874 | ) |  |  | (22,133 | ) |  |  | (19,460 | ) |
| Income tax provision |  | $ | (32,889 | ) |  | $ | (27,650 | ) |  | $ | (19,015 | ) |

[0001193125-26-051976:notes:208]
The reconciliation of the provision for income taxes at the statutory federal income tax rate compared to the Company’s provision for income taxes was as follows:

[0001193125-26-051976:notes:209]
|  |  | For the Year Ended December 29, 2025 |  |
|  |  | Amount |  |  | Rate |  |
|  |  | (In thousands, except rates) |  |
| U.S. federal statutory income tax |  | $ | (44,171 | ) |  |  | 21.0 | % |
| Domestic federal tax effects: |  |  |  |  |  |  |
| Tax credits |  |  |  |  |  |  |
| Research credits |  |  | 4,696 |  |  |  | (2.2 | ) |
| Foreign tax credits |  |  | 11,681 |  |  |  | (5.6 | ) |
| Nontaxable and nondeductible items |  |  |  |  |  |  |
| IRC section 162(m) limitation |  |  | (4,355 | ) |  |  | 2.1 |  |
| Other |  |  | 421 |  |  |  | (0.2 | ) |
| Cross-border tax laws |  |  |  |  |  |  |
| Global intangible low-taxed income |  |  | (30,760 | ) |  |  | 14.6 |  |
| Foreign derived intangible income |  |  | 16,916 |  |  |  | (8.0 | ) |
| Excess tax benefits on share-based payments |  |  | 5,355 |  |  |  | (2.5 | ) |
| Change in valuation allowance |  |  | 5,983 |  |  |  | (2.8 | ) |
| Domestic state and local income taxes, net of federal effect |  |  | (3,116 | ) |  |  | 1.5 |  |
| Foreign tax effects: |  |  |  |  |  |  |
| China |  |  |  |  |  |  |
| Super research and development expenditure |  |  | 3,482 |  |  |  | (1.7 | ) |
| Tax settlement |  |  | (3,221 | ) |  |  | 1.5 |  |
| Other |  |  | 681 |  |  |  | (0.3 | ) |
| Hong Kong |  |  |  |  |  |  |
| Statutory income tax rate differential |  |  | 4,123 |  |  |  | (2.0 | ) |
| Other |  |  | (450 | ) |  |  | 0.2 |  |
| Other foreign jurisdictions |  |  | 1,177 |  |  |  | (0.6 | ) |
| Worldwide changes in unrecognized tax benefits |  |  | (1,331 | ) |  |  | 0.6 |  |
| Total income tax provision |  | $ | (32,889 | ) |  |  | 15.6 | % |

[0001193125-26-051976:notes:210]
|  |  | For the Year Ended |  |
|  |  | December 30, 2024 |  |  | January 1, 2024 |  |
|  | (In thousands) |  |
| Statutory federal income tax provision |  | $ | (17,629 | ) |  | $ | (62 | ) |
| State income taxes, net of federal benefit and state tax credits |  |  | (672 | ) |  |  | (1,875 | ) |
| IRC section 162(m) limitation |  |  | (1,467 | ) |  |  | (2,121 | ) |
| Stock options |  |  | 453 |  |  |  | (651 | ) |
| Global intangible low-taxed income |  |  | (7,435 | ) |  |  | (12,639 | ) |
| Foreign tax credits |  |  | 10,131 |  |  |  | 14,916 |  |
| Permanently reinvested earnings assertion |  |  | (2,634 | ) |  |  | (3,934 | ) |
| Foreign tax differential on foreign earnings and other permanent items |  |  | 6,928 |  |  |  | 3,788 |  |
| Change in valuation allowance |  |  | (13,650 | ) |  |  | (13,460 | ) |
| Uncertain tax positions |  |  | — |  |  |  | 957 |  |
| Federal research and development credits |  |  | 6,052 |  |  |  | 4,665 |  |
| Goodwill impairment |  |  | (6,846 | ) |  |  | (9,261 | ) |
| Other |  |  | (881 | ) |  |  | 662 |  |
| Income tax provision |  | $ | (27,650 | ) |  | $ | (19,015 | ) |

[0001193125-26-051976:notes:211]
As of December 29, 2025, the majority of the Company's domestic state income taxes were attributed to the following states: $1,332 in Maryland and $497 in Massachusetts.

[0001193125-26-051976:notes:212]
Deferred income taxes reflect the net tax effects of temporary differences between the carrying amounts of assets and liabilities for financial reporting purposes and the amounts used for income tax purposes. The significant components of the net deferred income tax assets (liabilities) were as follows:

[0001193125-26-051976:notes:213]
|  |  | As of |  |
|  |  | December 29, 2025 |  |  | December 30, 2024 |  |
|  |  | (In thousands) |  |
| Deferred income tax assets: |  |  |  |  |  |  |
| Net operating loss carryforwards |  | $ | 28,843 |  |  | $ | 29,974 |  |
| Reserves and accruals |  |  | 59,071 |  |  |  | 57,453 |  |
| Interest expense limitation |  |  | — |  |  |  | 41 |  |
| Tax credit carryforwards |  |  | 30,334 |  |  |  | 33,559 |  |
| Stock-based compensation |  |  | 8,038 |  |  |  | 6,591 |  |
| Property, plant, and equipment |  |  | 3,515 |  |  |  | 3,748 |  |
| Intangible and capitalized research expenditure amortization |  |  | 1,909 |  |  |  | 7,601 |  |
| Operating lease liabilities |  |  | 22,913 |  |  |  | — |  |
| Other deferred income tax assets |  |  | 1,822 |  |  |  | 880 |  |
|  |  |  | 156,445 |  |  |  | 139,847 |  |
| Less: Valuation allowance |  |  | (85,963 | ) |  |  | (95,373 | ) |
|  |  |  | 70,482 |  |  |  | 44,474 |  |
| Deferred income tax liabilities: |  |  |  |  |  |  |
| Debt discount and issuance cost |  |  | (1,123 | ) |  |  | (1,582 | ) |
| Repatriation of foreign earnings |  |  | (6,196 | ) |  |  | (4,961 | ) |
| Property, plant, and equipment basis differences |  |  | (85,275 | ) |  |  | (74,632 | ) |
| Goodwill and intangible amortization |  |  | (1,458 | ) |  |  | (1,358 | ) |
| Unrealized gain on cash flow hedge |  |  | (527 | ) |  |  | (1,895 | ) |
| Operating lease right-of-use assets |  |  | (19,342 | ) |  |  | — |  |
| Other deferred income tax liabilities |  |  | (329 | ) |  |  | (465 | ) |
| Net deferred income tax liabilities (included in other long-term liabilities and deposits and other non-current assets) |  | $ | (43,768 | ) |  | $ | (40,419 | ) |

[0001193125-26-051976:notes:214]
As of December 29, 2025, the Company had the following NOLs carryforwards: $68,667 in the U.S. for federal, $19,054 in various U.S. states, $8,805 in China, $22,796 in Hong Kong, and $33,156 in Malaysia. The U.S. federal NOLs expire in 2029 through 2032, the various U.S. states’ NOLs expire in 2026 through 2045, the China NOLs expire in 2031 through 2035, and the Hong Kong and Malaysia NOLs carryforward indefinitely. Further, the Company’s tax credits were approximately $41,153, of which $4,883 carryforward indefinitely.

[0001193125-26-051976:notes:215]
In connection with the Company’s acquisition of Viasystems Group, Inc. during 2015, there was more than a 50% change in ownership under Section 382 of the Internal Revenue Code of 1986, as amended, and regulations issued thereunder. As a consequence, the utilization of the remaining Viasystems Group, Inc. U.S. NOLs is limited to approximately $9,826 per year and total $68,667.

[0001193125-26-051976:notes:216]
As of December 29, 2025, the Company expects its earnings attributable to foreign subsidiaries will not be indefinitely reinvested, except for certain subsidiaries, and the Company established a deferred tax liability of $4,682 and $1,514 for the foreign and U.S. federal/state impact, respectively. For those other companies with earnings currently being reinvested outside of the U.S., the undistributed earnings amounted to $60,769, and the unrecognized deferred tax liability related to these undistributed earnings was $2,687.

[0001193125-26-051976:notes:217]
A valuation allowance is provided when it is more likely than not that all or some portion of the deferred income tax assets will not be realized. The Company established a valuation allowance on its U.S. net deferred tax assets in the current year mainly due to cumulative book losses in the U.S. In addition, certain subsidiaries in various tax jurisdictions continue to have NOL carryforwards, which the Company has determined are not more likely than not to be utilized. As a result, a full valuation allowance has been recorded for these subsidiaries as of December 29, 2025. For the remaining net deferred income tax assets, management has determined that it is more likely than not that the results of future operations will generate sufficient income to realize the net deferred tax assets.

[0001193125-26-051976:notes:218]
A summary of the activity in the Company’s valuation allowance was as follows:

[0001193125-26-051976:notes:219]
|  |  | For the Year Ended |  |
|  |  | December 29, 2025 |  |  | December 30, 2024 |  |  | January 1, 2024 |  |
|  |  | (In thousands) |  |
| Balance at beginning of year |  | $ | 95,373 |  |  | $ | 81,779 |  |  | $ | 67,173 |  |
| (Reduction) addition charged to expense |  |  | (2,937 | ) |  |  | 13,743 |  |  |  | 13,811 |  |
| Addition related to acquisition |  |  | — |  |  |  | — |  |  |  | 1,187 |  |
| Reduction related to tax law changes |  |  | (5,983 | ) |  |  | — |  |  |  | — |  |
| Reduction related to other comprehensive income |  |  | (530 | ) |  |  | — |  |  |  | — |  |
| Other addition (reduction) charged to expense |  |  | 40 |  |  |  | (149 | ) |  |  | (392 | ) |
| Balance at end of year |  | $ | 85,963 |  |  | $ | 95,373 |  |  | $ | 81,779 |  |

[0001193125-26-051976:notes:220]
Certain entities within China qualified for the HNTE status enabling those entities to utilize certain benefits, which were effective for the years ended December 29, 2025, December 30, 2024, and January 1, 2024. The HNTE status as well as enhanced R&D deductions decreased Chinese taxes. The HNTE and R&D benefit and effect on earnings per share were as follows:

[0001193125-26-051976:notes:221]
|  |  | For the Year Ended |  |
|  |  | December 29, 2025 |  |  | December 30, 2024 |  |  | January 1, 2024 |  |
|  |  | (In thousands, except per share data) |  |
| HNTE and R&D benefit |  | $ | 5,792 |  |  | $ | 5,187 |  |  | $ | 6,056 |  |
| Basic shares |  |  | 102,598 |  |  |  | 101,781 |  |  |  | 102,744 |  |
| Diluted shares |  |  | 105,453 |  |  |  | 104,098 |  |  |  | 102,744 |  |
| Increase on earnings per share: |  |  |  |  |  |  |  |  |  |
| Basic |  | $ | 0.06 |  |  | $ | 0.05 |  |  | $ | 0.06 |  |
| Diluted |  |  | 0.05 |  |  |  | 0.05 |  |  |  | 0.06 |  |

[0001193125-26-051976:notes:222]
The HNTE status expired for certain subsidiaries in 2025, but the Company expects to continue to file for renewal of such HNTE status for the foreseeable future.

[0001193125-26-051976:notes:223]
The Company operates under a tax incentive approved by MIDA, which provides for a 0% tax rate for three consecutive five-year periods (totaling 15 years), subject to the satisfaction of specific operational requirements. For the year ended December 29, 2025, the Company concluded that it did not meet certain conditions required to maintain the incentive and recorded tax at the statutory tax rate of 24%. The Company is currently in the process of applying to MIDA for a revision of incentive criteria; however, there is no assurance that such revision will be approved.

[0001193125-26-051976:notes:224]
A reconciliation of unrecognized tax benefits, exclusive of accrued interest and penalties, was as follows:

[0001193125-26-051976:notes:225]
|  |  | For the Year Ended |  |
|  |  | December 29, 2025 |  |  | December 30, 2024 |  |  | January 1, 2024 |  |
|  |  | (In thousands) |  |
| Balance at beginning of year |  | $ | 10,639 |  |  | $ | 10,363 |  |  | $ | 9,778 |  |
| Additions based on tax positions related to the current year |  |  | 1,125 |  |  |  | 1,220 |  |  |  | 934 |  |
| Additions for tax positions of prior years |  |  | 977 |  |  |  | — |  |  |  | 13 |  |
| Reductions for tax positions of prior years |  |  | — |  |  |  | (3 | ) |  |  | — |  |
| Lapse of statute of limitations |  |  | (337 | ) |  |  | (941 | ) |  |  | (362 | ) |
| Balance at end of year |  | $ | 12,404 |  |  | $ | 10,639 |  |  | $ | 10,363 |  |

[0001193125-26-051976:notes:226]
During the year ended December 29, 2025, the Company increased uncertain tax positions by $1,765 due to U.S. R&D credit generation, prior year international tax matters, and U.S. foreign sourced income deductions, offset by the release of uncertain tax positions due to the statute of limitations expiration.

[0001193125-26-051976:notes:227]
As of December 29, 2025 and December 30, 2024, the Company recorded unrecognized tax expense of $1,261 and $446, respectively, as well as interest and penalties of $63 and $475, respectively, to other current liabilities and other long-term liabilities. Additionally, the Company recorded unrecognized tax expenses of $11,143 and $10,193 against certain deferred tax assets as of December 29, 2025 and December 30, 2024, respectively.

[0001193125-26-051976:notes:228]
As of December 29, 2025, the Company is open for (1) U.S. federal income tax examination for the tax periods from 2022 to 2025 and NOL and credit carryforwards are subject to adjustment for three years post utilization; (2) state and local income tax examination for tax years from 2020 to 2025 and NOL and credit carryforwards are subject to adjustment for four years post utilization; and (3) foreign income tax examinations generally for tax years from 2015 to 2025.

[0001193125-26-051976:notes:229]
A summary of the Company's income taxes paid, net of refunds was as follows:

[0001193125-26-051976:notes:230]
|  |  | For the Year Ended December 29, 2025 |  |
|  |  | (In thousands) |  |
| U.S. federal |  | $ | 3,460 |  |
| U.S. state and local |  |  | 4,258 |  |
| Foreign: |  |  |  |
| China |  |  | 4,209 |  |
| Hong Kong |  |  | 23,668 |  |
| Other |  |  | 1,842 |  |
| Total foreign |  |  | 29,719 |  |
| Total income taxes paid, net of refunds |  | $ | 37,437 |  |


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001193125-26-051976:notes:231]
(9)
Earnings Per Share, Share Repurchase Program, Preferred Stock, and Accumulated Other Comprehensive Loss

[0001193125-26-051976:notes:232]
The reconciliation of the numerator and denominator used to calculate basic earnings (loss) per share and diluted earnings (loss) per share is as follows:

[0001193125-26-051976:notes:233]
|  |  | For the Year Ended |  |
|  |  | December 29, 2025 |  |  | December 30, 2024 |  |  | January 1, 2024 |  |
|  |  | (In thousands, except per share amounts) |  |
| Net income (loss) |  | $ | 177,448 |  |  | $ | 56,299 |  |  | $ | (18,718 | ) |
| Basic weighted average shares |  |  | 102,598 |  |  |  | 101,781 |  |  |  | 102,744 |  |
| Dilutive effect of PRUs, RSUs, and stock options |  |  | 2,855 |  |  |  | 2,317 |  |  |  | — |  |
| Diluted shares |  |  | 105,453 |  |  |  | 104,098 |  |  |  | 102,744 |  |
| Earnings (loss) per share: |  |  |  |  |  |  |  |  |  |
| Basic earnings (loss) per share |  | $ | 1.73 |  |  | $ | 0.55 |  |  | $ | (0.18 | ) |
| Diluted earnings (loss) per share |  |  | 1.68 |  |  |  | 0.54 |  |  |  | (0.18 | ) |

[0001193125-26-051976:notes:234]
For the years ended December 29, 2025 and December 30, 2024, PRUs and RSUs to purchase 167 shares of common stock and PRUs, RSUs, and stock options to purchase 158 shares of common stock, respectively, were not included in the computation of diluted earnings per share. The PRUs were not included in the computation of diluted earnings per share because the performance conditions had not been met, and for the RSUs and stock options, the options’ exercise prices or the total expected proceeds under the treasury stock method were greater than the average market price of common stock during the applicable year and, as a result, the impact would be anti-dilutive.

[0001193125-26-051976:notes:235]
For the year ended January 1, 2024, potential shares of common stock, consisting of stock options to purchase 60 shares of common stock at exercise prices ranging from $11.83 to $16.60 per share, 3,527 RSUs, and 668 PRUs were not included in the computation of diluted earnings per share because the Company incurred a net loss and as a result, the impact would be anti-dilutive.

[0001193125-26-051976:notes:236]
Share Repurchase Program

[0001193125-26-051976:notes:237]
On May 8, 2025, the Company's Board of Directors authorized the 2025 Repurchase Program, under which the Company may repurchase up to $100,000 in value of the Company’s outstanding shares of common stock from time to time through May 7, 2027. The Company’s previous two-year repurchase program expired on May 3, 2025. The Company may repurchase shares through open market purchases, privately‑negotiated transactions, or otherwise in accordance with applicable federal securities laws, including Rule 10b-18 of the Exchange Act, which sets certain restrictions on the method, timing, price, and volume of open market stock repurchases. In addition, the Company adopted one trading plan in accordance with Rule 10b5-1 of the Exchange Act to facilitate certain purchases that may be effected under the share repurchase program. The timing, manner, price, and amount of any repurchases will be determined

[0001193125-26-051976:notes:238]
at the Company’s discretion, and the share repurchase program may be suspended, terminated, or modified at any time for any reason. The repurchase program does not obligate the Company to acquire any specific number of shares.

[0001193125-26-051976:notes:239]
During the year ended December 29, 2025, the Company repurchased 700 shares of common stock for a total cost of $17,875 (including commissions) under the Company’s previous repurchase program. As of December 29, 2025, the remaining amount in value available to be repurchased under the 2025 Repurchase Program was $100,000.

[0001193125-26-051976:notes:240]
Preferred Stock

[0001193125-26-051976:notes:241]
Authorized preferred stock may be issued with designations, rights, privileges, powers, and preferences designated by the Board of Directors. There were no shares of preferred stock issued or outstanding in 2025, 2024, or 2023.

[0001193125-26-051976:notes:242]
Accumulated Other Comprehensive Loss

[0001193125-26-051976:notes:243]
The components of accumulated other comprehensive loss, net of tax were as follows:

[0001193125-26-051976:notes:244]
|  |  | As of |  |
|  |  | December 29, 2025 |  |  | December 30, 2024 |  |  | January 1, 2024 |  |
|  |  | (In thousands) |  |
| Foreign currency translation |  | $ | (33,374 | ) |  | $ | (33,757 | ) |  | $ | (32,860 | ) |
| Pension obligation |  |  | 2,891 |  |  |  | 3,612 |  |  |  | 2,530 |  |
| Cash flow hedges |  |  | (447 | ) |  |  | 2,263 |  |  |  | 1,263 |  |
| Total |  | $ | (30,930 | ) |  | $ | (27,882 | ) |  | $ | (29,067 | ) |


## us-gaap:FairValueDisclosuresTextBlock

[0001193125-26-051976:notes:245]
(10)
Fair Value Measures

[0001193125-26-051976:notes:246]
The carrying amount and estimated fair value of the Company’s financial instruments were as follows:

[0001193125-26-051976:notes:247]
|  |  | As of December 29, 2025 |  |  | As of December 30, 2024 |  |
|  |  | Carrying Amount |  |  | Fair Value |  |  | Carrying Amount |  |  | Fair Value |  |
|  |  | (In thousands) |  |
| Derivative assets, current |  | $ | 5,212 |  |  | $ | 5,212 |  |  | $ | 1,765 |  |  | $ | 1,765 |  |
| Derivative assets, non-current |  |  | — |  |  |  | — |  |  |  | 1,326 |  |  |  | 1,326 |  |
| Derivative liabilities, current |  |  | 31 |  |  |  | 31 |  |  |  | 667 |  |  |  | 667 |  |
| Derivative liabilities, non-current |  |  | 382 |  |  |  | 382 |  |  |  | — |  |  |  | — |  |
| Senior Notes due March 2029 |  |  | 497,392 |  |  |  | 488,325 |  |  |  | 496,638 |  |  |  | 464,325 |  |
| Term Loan due May 2030 |  |  | 336,778 |  |  |  | 345,806 |  |  |  | 339,205 |  |  |  | 346,930 |  |
| ABL Revolving Loans |  |  | 80,000 |  |  |  | 80,000 |  |  |  | 80,000 |  |  |  | 80,000 |  |
| Other loan |  |  | 1,981 |  |  |  | 1,981 |  |  |  | 2,311 |  |  |  | 2,311 |  |

[0001193125-26-051976:notes:248]
The fair value of the derivative instruments was determined using pricing models developed based on the 1-month CME Term SOFR swap rate, foreign currency exchange rates, and other observable market data, including quoted market prices, as appropriate using Level 2 inputs. The values were adjusted to reflect non-performance risk of both the counterparty and the Company, as necessary.

[0001193125-26-051976:notes:249]
The fair value of the long-term debt was estimated based on quoted market prices, where available, as of December 29, 2025 and December 30, 2024, which are considered Level 2 inputs.

[0001193125-26-051976:notes:250]
The fair value of plan assets in the defined benefit plan of $23,229 and $23,297 as of December 29, 2025 and December 30, 2024, respectively, was not included in the table above and was estimated based on quoted market prices of the securities that are actively traded and price quotes that are readily available, which are considered Level 1 inputs.

[0001193125-26-051976:notes:251]
As of December 29, 2025 and December 30, 2024, the Company’s other financial instruments included cash and cash equivalents, accounts receivable, contract assets, accounts payable, and contract liabilities. The carrying amount of these instruments approximates fair value.

[0001193125-26-051976:notes:252]
As of December 30, 2024, the Company’s goodwill balance related to its RF&S Components reporting unit of $31,300 was measured at fair value on a nonrecurring basis. The Company recorded a non-cash goodwill impairment charge of $32,600 related to its RF&S Components reporting unit during the year ended December 30, 2024. The fair value of goodwill was determined using both a DCF and a market approach, which are considered Level 3 inputs. The Company used a risk adjusted discount rate of 12% to discount the expected future cash flows in 2024.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001193125-26-051976:notes:253]
(11)
Commitments and Contingencies

[0001193125-26-051976:notes:254]
Legal Matters

[0001193125-26-051976:notes:255]
The Company is subject to various legal matters, which it considers normal for its business activities. While the Company currently believes that the amount of any reasonably possible loss for known matters would not be material to the Company’s financial condition, the outcome of these actions is inherently difficult to predict. In the event of an adverse outcome, the ultimate potential loss could have a material adverse effect on the Company’s financial condition or results of operations in a particular period. The Company has accrued amounts for its loss contingencies which are probable and estimable as of December 29, 2025 and December 30, 2024 and included as a component of other current liabilities. However, these amounts are not material to the consolidated financial statements of the Company.

[0001193125-26-051976:notes:256]
Supplier Finance Program Obligations

[0001193125-26-051976:notes:257]
The Company has agreements with financial institutions to facilitate payments to certain suppliers. Under the terms of the agreements, the Company confirms the validity of each supplier invoice to the respective financial institution upon receipt. The supplier receives payment from the financial institution, and the Company pays the financial institution based on the terms negotiated, which generally range from 160 days to 360 days. Liabilities associated with these agreements are recorded in accounts payable on the consolidated balance sheets and amounted to $12,535 and $17,218 as of December 29, 2025 and December 30, 2024, respectively.

[0001193125-26-051976:notes:258]
The details of the outstanding obligations confirmed as valid under the Company’s supplier finance program were as follows:

[0001193125-26-051976:notes:259]
|  |  | For the Year Ended |  |
|  |  | December 29, 2025 |  |  | December 30, 2024 |  |
|  |  | (In thousands) |  |
| Confirmed obligations outstanding at beginning of year |  | $ | 17,218 |  |  | $ | 18,832 |  |
| Invoices confirmed during the year |  |  | 12,579 |  |  |  | 22,887 |  |
| Confirmed invoices paid during the year |  |  | (17,480 | ) |  |  | (24,983 | ) |
| Effect of foreign currency exchange rates |  |  | 218 |  |  |  | 482 |  |
| Confirmed obligations outstanding at end of year |  | $ | 12,535 |  |  | $ | 17,218 |  |


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001193125-26-051976:notes:260]
(12)
Stock-Based Compensation

[0001193125-26-051976:notes:261]
Incentive Compensation Plan

[0001193125-26-051976:notes:262]
The Company maintains the Plan, which allows for issuance of up to 5,100 shares through its latest possible expiration date in May 2033.

[0001193125-26-051976:notes:263]
The Plan provides for the grant of PRUs, RSUs, stock appreciation rights, and stock options. The exercise price for awards is determined by the Compensation Committee of the Board of Directors. Each award shall vest and expire as determined by the Compensation Committee of the Board of Directors, with PRUs and RSUs generally vesting over three years for employees and one year for non‑employee directors. PRUs and RSUs do not have voting rights. All grants provide for accelerated vesting if there is a change in control, as defined in the Plan.

[0001193125-26-051976:notes:264]
As of December 29, 2025, 843 PRUs, 3,381 RSUs, and 40 stock options were outstanding under the Plan. Included in the 843 PRUs outstanding as of December 29, 2025 are 372 vested but not yet released. Included in the 3,381 RSUs outstanding as of December 29, 2025 are 612 vested but not yet released RSUs associated with non-employee directors. These RSUs vest over one year with release of the underlying shares of common stock deferred until retirement from the Board of Directors (or until one year after retirement in the case of certain prior grants).

[0001193125-26-051976:notes:265]
Performance-based Restricted Stock Units

[0001193125-26-051976:notes:266]
The Company maintains a long-term incentive program for executives that provides for the issuance of PRUs, representing hypothetical shares of the Company’s common stock that may be issued. Under the PRU program, a target number of PRUs is awarded at the beginning of each three-year performance period. The number of shares of common stock released at the end of the performance period depends on performance during the period and may range from zero to 2.4 times the target number for PRUs awarded before 2023 and zero to 2.0 times the target number for PRUs awarded in 2023 and thereafter. For PRUs awarded before 2023, the performance metrics of the PRU program are based on (1) annual financial targets, which are based on revenue and EBITDA, each equally weighted, and (2) an overall modifier based on the Company’s TSR relative to a group of peer companies selected by the Company’s Compensation Committee, over the three year performance period. For PRUs awarded in 2023 and thereafter, the performance metrics of the PRU program are based on (1) annual financial targets, which are based on revenue and EBITDA, each equally weighted, and (2) the three-year TSR performance result, which will be an additive component to the Company’s financial results of the aggregated three-year measurement period.

[0001193125-26-051976:notes:267]
Under the PRU program, financial goals with respect to one or more target milestones are set at the beginning of each year and performance is reviewed at the end of that year. The percentage to be applied to each participant’s target award ranges from zero to 160% for PRUs awarded before 2023 and zero to 200% for PRUs awarded in 2023 and thereafter, based upon the extent to which the target milestones are achieved. If specific performance threshold levels for the target milestones are met, the amount earned for that element over the three-year performance period will be applied equally for PRUs awarded before 2023 and 80% for PRUs awarded in 2023 and thereafter, of the participants’ PRU award to determine the number of units earned.

[0001193125-26-051976:notes:268]
At the end of the three-year performance period, the total units earned, if any, are adjusted by the TSR calculation. The TSR calculation is a percentage ranging from zero to 150% for PRUs awarded before 2023 and zero to 200% for PRUs awarded in 2023 and thereafter, determined on the Company’s TSR based on stock price changes relative to a group of peer companies selected by the Company’s Compensation Committee for the same three-year period. For outstanding PRU awards granted before 2023, the TSR is used as an overall modifier of the three-year performance period such that the base calculations are multiplied by the TSR modifier, ranging from zero to 150%, based on the relative performance of the Company’s stock price as compared to its TSR peer group. For PRUs awarded in 2023 and thereafter, the TSR calculation will be applied to 20% of the participants’ PRU award to determine the number of additional units earned.

[0001193125-26-051976:notes:269]
Recipients of PRU awards generally must remain employed by the Company on a continuous basis through the end of the three‑year performance period in order to receive any amount of the PRUs covered by that award. In events such as death, disability, or retirement, the recipient may be entitled to pro-rata amounts of PRUs as defined in the Plan. Target shares subject to PRU awards do not have voting rights of common stock until earned and issued following the end of the three-year performance period.

[0001193125-26-051976:notes:270]
The Company records stock-based compensation expense for PRU awards granted based on management’s periodic assessment of the annual financial performance goals to be achieved. As of December 29, 2025, management determined that vesting of the PRU awards was probable. PRU activity for the year ended December 29, 2025 was as follows:

[0001193125-26-051976:notes:271]
|  |  | Shares |  |  | Weighted AverageFair Value |  |
|  |  | (In thousands) |  |  |  |  |
| Outstanding shares as of December 30, 2024 |  |  | 329 |  |  | $ | 20.14 |  |
| Granted |  |  | 371 |  |  |  | 46.12 |  |
| Vested |  |  | (372 | ) |  |  | 19.82 |  |
| Forfeited / cancelled |  |  | 102 |  |  |  | 31.34 |  |
| Change in units due to annual performance achievement |  |  | 52 |  |  |  | 61.73 |  |
| Outstanding shares as of December 29, 2025 |  |  | 482 |  |  | $ | 47.26 |  |

[0001193125-26-051976:notes:272]
The fair value of PRUs granted is calculated using a Monte Carlo simulation model, as the TSR modifier contains a market condition. The following assumptions were used in determining the fair value:

[0001193125-26-051976:notes:273]
|  |  | For the Year Ended |  |
|  |  | December 29, 2025 (1) |  |  | December 30, 2024 (2) |  |  | January 1, 2024 (3) |  |
| Weighted-average fair value |  | $ | 46.11 |  |  | $ | 19.51 |  |  | $ | 16.36 |  |
| Risk-free interest rate |  |  | 3.99 | % |  |  | 4.42 | % |  |  | 4.46 | % |
| Expected volatility |  |  | 39 | % |  |  | 41 | % |  |  | 42 | % |

[0001193125-26-051976:notes:274]
(1)
Reflects the weighted-averages for the third year of the three-year performance period applicable to PRUs granted in 2023, the second year of the three-year performance period applicable to PRUs granted in 2024, and the first year of the three-year performance period applicable to PRUs granted in 2025.

[0001193125-26-051976:notes:275]
(2)
Reflects the weighted-averages for the third year of the three-year performance period applicable to PRUs granted in 2022, the second year of the three-year performance period applicable to PRUs granted in 2023, and the first year of the three-year performance period applicable to PRUs granted in 2024.

[0001193125-26-051976:notes:276]
(3)
Reflects the weighted-averages for the third year of the three-year performance period applicable to PRUs granted in 2021, the second year of the three-year performance period applicable to PRUs granted in 2022, and the first year of the three-year performance period applicable to PRUs granted in 2023.

[0001193125-26-051976:notes:277]
The risk-free interest rate for the expected term of PRUs is based on the U.S. Treasury yield curve in effect at the time of grant. Expected volatility is calculated using the Company’s historical stock price.

[0001193125-26-051976:notes:278]
Restricted Stock Units

[0001193125-26-051976:notes:279]
RSU activity for the year ended December 29, 2025 was as follows:

[0001193125-26-051976:notes:280]
|  |  | Shares |  |  | Weighted AverageGrant-Date Fair Value |  |
|  |  | (In thousands) |  |  |  |  |
| Non-vested RSUs outstanding as of December 30, 2024 |  |  | 3,465 |  |  | $ | 16.47 |  |
| Granted |  |  | 1,197 |  |  |  | 38.03 |  |
| Vested |  |  | (1,730 | ) |  |  | 15.27 |  |
| Cancelled |  |  | (163 | ) |  |  | 19.62 |  |
| Non-vested RSUs outstanding as of December 29, 2025 |  |  | 2,769 |  |  | $ | 26.23 |  |
| Vested and expected to vest through 2028 as of December 29, 2025 |  |  | 3,381 |  |  | $ | 23.80 |  |

[0001193125-26-051976:notes:281]
The weighted average fair value per unit of RSUs granted was $38.03, $19.32, and $13.85 for the years ended December 29, 2025, December 30, 2024, and January 1, 2024, respectively. The total fair value of RSUs vested for the years ended December 29, 2025, December 30, 2024, and January 1, 2024 was $63,429, $30,575, and $19,928, respectively.

[0001193125-26-051976:notes:282]
Stock Options

[0001193125-26-051976:notes:283]
As of December 29, 2025, stock options outstanding was 40 and no options were granted during the year. This is not material to the consolidated financial statements of the Company.

[0001193125-26-051976:notes:284]
Stock-based Compensation Expense and Unrecognized Compensation Costs

[0001193125-26-051976:notes:285]
Stock-based compensation expense recognized in the accompanying consolidated statements of operations was as follows:

[0001193125-26-051976:notes:286]
|  |  | For the Year Ended |  |
|  |  | December 29, 2025 |  |  | December 30, 2024 |  |  | January 1, 2024 |  |
|  |  | (In thousands) |  |
| Cost of goods sold |  | $ | 12,866 |  |  | $ | 9,342 |  |  | $ | 7,455 |  |
| Selling and marketing |  |  | 4,648 |  |  |  | 3,845 |  |  |  | 3,205 |  |
| General and administrative |  |  | 23,616 |  |  |  | 15,322 |  |  |  | 11,088 |  |
| Research and development |  |  | 538 |  |  |  | 1,271 |  |  |  | 1,139 |  |
| Total |  | $ | 41,668 |  |  | $ | 29,780 |  |  | $ | 22,887 |  |

[0001193125-26-051976:notes:287]
A summary of total unrecognized compensation costs as of December 29, 2025 is as follows:

[0001193125-26-051976:notes:288]
|  |  | Unrecognized Stock-BasedCompensation Cost |  |  | Remaining Weighted AverageRecognition Period |  |
|  |  | (In thousands) |  |  | (In years) |  |
| RSU awards |  | $ | 55,306 |  |  |  | 1.5 |  |
| PRU awards |  |  | 14,746 |  |  |  | 1.7 |  |
| Total |  | $ | 70,052 |  |  |  |  |


## us-gaap:LesseeOperatingLeasesTextBlock

[0001193125-26-051976:notes:289]
(13)
Leases

[0001193125-26-051976:notes:290]
The Company leases some of its manufacturing and assembly plants, sales offices, and equipment under non-cancellable operating leases and finance leases that expire at various dates through 2043. The majority of the Company’s lease arrangements are comprised of fixed payments, and certain leases consist of variable payments based on equipment usage. These variable payments are not included in the measurement of the ROU asset or lease liability due to uncertainty of the payment amount and are recorded as lease expense in the period incurred. Certain leases contain renewal provisions at the Company’s option. Most of the leases require the Company to pay for certain other costs such as property taxes and maintenance. Certain leases also contain rent escalation clauses (step rents) that require additional rental amounts in the later years of the term. Rent expense for leases with step rents is recognized on a straight-line basis over the minimum lease term. The lease agreements do not contain any material residual value guarantees or material restrictive covenants.

[0001193125-26-051976:notes:291]
The components of lease expense were as follows:

[0001193125-26-051976:notes:292]
|  |  | For the Year Ended |  |
|  |  | December 29, 2025 |  |  | December 30, 2024 |  |  | January 1, 2024 |  |
|  |  | (In thousands) |  |
| Operating lease cost |  | $ | 15,218 |  |  | $ | 14,933 |  |  | $ | 9,527 |  |
| Variable lease cost |  |  | 1,290 |  |  |  | 1,055 |  |  |  | 930 |  |
| Short-term lease cost |  |  | 677 |  |  |  | 409 |  |  |  | 311 |  |
| Finance lease costs: |  |  |  |  |  |  |  |  |  |
| Amortization of right-of-use assets |  |  | 1,652 |  |  |  | 1,372 |  |  |  | 1,374 |  |
| Interest on lease liabilities |  |  | 554 |  |  |  | 354 |  |  |  | 373 |  |

[0001193125-26-051976:notes:293]
Supplemental cash flow information related to leases was as follows:

[0001193125-26-051976:notes:294]
|  |  | For the Year Ended |  |
|  |  | December 29, 2025 |  |  | December 30, 2024 |  |  | January 1, 2024 |  |
|  |  | (In thousands) |  |
| Cash paid for amounts included in the measurement of lease liabilities: |  |  |  |  |  |  |  |  |  |
| Operating cash flows for operating leases |  | $ | 14,469 |  |  | $ | 13,926 |  |  | $ | 9,039 |  |
| Right-of-use assets obtained in exchange for new lease obligations: |  |  |  |  |  |  |  |  |  |
| Operating leases |  | $ | 12,700 |  |  | $ | 2,796 |  |  | $ | 77,041 |  |
| Finance leases |  |  | 4,682 |  |  |  | — |  |  |  | — |  |

[0001193125-26-051976:notes:295]
Supplemental balance sheet information related to leases was as follows:

[0001193125-26-051976:notes:296]
|  |  |  |  | As of |  |
|  |  | Balance Sheet Location |  | December 29, 2025 |  |  | December 30, 2024 |  |
|  |  |  |  | (In thousands) |  |
| Assets: |  |  |  |  |  |  |  |  |
| Operating leases |  | Operating lease right-of-use assets |  | $ | 80,914 |  |  | $ | 78,252 |  |
| Finance leases |  | Property, plant, and equipment, net |  |  | 13,652 |  |  |  | 10,621 |  |
| Total lease assets |  |  |  | $ | 94,566 |  |  | $ | 88,873 |  |
| Liabilities: |  |  |  |  |  |  |  |  |
| Current: |  |  |  |  |  |  |  |  |
| Operating leases |  | Other current liabilities |  | $ | 8,909 |  |  | $ | 7,556 |  |
| Finance leases |  | Other current liabilities |  |  | 1,117 |  |  |  | 814 |  |
| Long-term: |  |  |  |  |  |  |  |  |
| Operating leases |  | Operating lease liabilities |  |  | 87,524 |  |  |  | 77,509 |  |
| Finance leases |  | Other long-term liabilities |  |  | 15,829 |  |  |  | 11,985 |  |
| Total lease liabilities |  |  |  | $ | 113,379 |  |  | $ | 97,864 |  |

[0001193125-26-051976:notes:297]
|  |  | As of |
|  |  | December 29, 2025 |  | December 30, 2024 |
| Weighted average remaining lease term (years): |  |  |  |  |  |  |  |  |
| Operating leases |  | 11.3 |  |  |  | 12.5 |  |  |
| Finance leases |  | 11.6 |  |  |  | 11.6 |  |  |
| Weighted average discount rate: |  |  |  |  |  |  |  |  |
| Operating leases |  |  | 6.22 |  | % |  |  | 6.24 |  | % |
| Finance leases |  |  | 3.70 |  |  |  |  | 2.69 |  |  |

[0001193125-26-051976:notes:298]
Maturities of lease liabilities for the next five years and thereafter are as follows:

[0001193125-26-051976:notes:299]
|  |  | Operating Leases |  |  | Finance Leases |  |
|  |  | (In thousands) |  |
| 2026 |  | $ | 14,537 |  |  | $ | 1,698 |  |
| 2027 |  |  | 12,432 |  |  |  | 1,717 |  |
| 2028 |  |  | 11,338 |  |  |  | 1,733 |  |
| 2029 |  |  | 10,389 |  |  |  | 1,750 |  |
| 2030 |  |  | 10,413 |  |  |  | 1,780 |  |
| Thereafter |  |  | 79,270 |  |  |  | 12,395 |  |
| Total lease payments |  |  | 138,379 |  |  |  | 21,073 |  |
| Less: Imputed interest |  |  | (41,946 | ) |  |  | (4,127 | ) |
| Total |  | $ | 96,433 |  |  | $ | 16,946 |  |
