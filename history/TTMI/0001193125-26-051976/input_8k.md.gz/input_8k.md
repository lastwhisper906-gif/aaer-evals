# TTMI 8-K — 0001193125-26-037560 filed 2026-02-04

## item codes, every 8-K on or before 2026-02-17

- 2026-02-04 0001193125-26-037560 — 2.02, 9.01
- 2026-02-02 0001193125-26-032638 — 5.02, 7.01, 9.01
- 2026-01-13 0001193125-26-011807 — 7.01
- 2025-10-29 0001193125-25-256425 — 2.02, 9.01
- 2025-08-14 0001193125-25-180363 — 5.02, 7.01, 9.01
- 2025-07-30 0001193125-25-169326 — 2.02, 5.02, 7.01, 9.01
- 2025-05-09 0001193125-25-116469 — 5.02, 5.07, 7.01, 8.01, 9.01
- 2025-04-30 0001193125-25-107148 — 2.02, 9.01
- 2025-02-18 0001193125-25-028278 — 5.02, 7.01, 9.01
- 2025-02-05 0001193125-25-020820 — 2.02, 9.01
- 2024-10-30 0001193125-24-247537 — 2.02, 9.01
- 2024-08-01 0001193125-24-191480 — 1.01, 2.03
- 2024-07-31 0001193125-24-189522 — 2.02, 9.01
- 2024-06-14 0001193125-24-161581 — 1.01, 2.03
- 2024-06-10 0001193125-24-158390 — 5.03, 9.01 — amendment of 0001193125-24-136138
- 2024-05-10 0001193125-24-136138 — 5.02, 5.03, 5.07, 7.01, 9.01
- 2024-05-01 0001193125-24-126373 — 2.02, 9.01
- 2024-02-07 0001193125-24-026126 — 2.02, 9.01
- 2023-11-01 0001193125-23-267755 — 2.02, 9.01
- 2023-08-02 0001193125-23-201189 — 5.02, 7.01, 9.01
- 2023-08-02 0001193125-23-201186 — 2.02, 9.01
- 2023-06-20 0001193125-23-169669 — 1.01, 2.03, 7.01, 9.01
- 2023-05-30 0001193125-23-156582 — 1.01, 2.03, 3.03, 7.01, 9.01
- 2023-05-12 0001193125-23-142632 — 5.07
- 2023-05-03 0001193125-23-134390 — 2.02, 8.01, 9.01
- 2023-03-09 0001193125-23-066103 — 7.01, 9.01
- 2023-02-08 0001193125-23-028382 — 2.02, 2.05, 7.01, 9.01
- 2022-11-03 0001193125-22-276659 — 2.02, 9.01 — amendment of 0001193125-22-275849
- 2022-11-02 0001193125-22-275849 — 2.02, 9.01
- 2022-09-08 0001193125-22-241001 — 9.01 — amendment of 0001193125-22-182826
- 2022-08-03 0001193125-22-211262 — 2.02, 9.01
- 2022-06-27 0001193125-22-182826 — 2.01, 7.01, 9.01
- 2022-05-16 0001193125-22-151684 — 5.07
- 2022-05-04 0001193125-22-140455 — 2.02, 9.01
- 2022-04-18 0001193125-22-108017 — 1.01, 7.01, 9.01
- 2022-03-01 0001193125-22-059877 — 7.01, 9.01
- 2022-02-09 0001193125-22-032669 — 2.02, 9.01
- 2021-10-27 0001193125-21-309324 — 2.02, 9.01
- 2021-07-28 0001193125-21-227406 — 2.02, 9.01
- 2021-06-14 0001193125-21-189568 — 5.02, 9.01
- 2021-05-13 0001193125-21-159545 — 2.02, 5.02, 5.07, 9.01
- 2021-04-28 0001193125-21-136849 — 2.02, 9.01
- 2021-03-16 0001193125-21-083011 — 1.02, 8.01
- 2021-03-10 0001193125-21-076246 — 1.01, 2.03, 3.03, 7.01, 9.01
- 2021-02-24 0001193125-21-054812 — 7.01, 9.01
- 2021-02-23 0001193125-21-051549 — 7.01, 9.01
- 2021-02-03 0001193125-21-027322 — 2.02, 8.01, 9.01
- 2020-12-15 0001193125-20-318208 — 7.01, 9.01
- 2020-10-28 0001193125-20-279980 — 2.02, 9.01
- 2020-09-04 0001193125-20-239645 — 5.02
- 2020-07-29 0001193125-20-203110 — 2.02, 9.01
- 2020-05-08 0001193125-20-137566 — 5.07
- 2020-05-04 0001193125-20-131366 — 7.01, 9.01
- 2020-04-29 0001193125-20-126358 — 2.05, 7.01, 9.01
- 2020-04-29 0001193125-20-126117 — 2.02, 9.01
- 2020-04-23 0001193125-20-117365 — 2.01, 7.01, 9.01
- 2020-02-05 0001193125-20-025365 — 2.02, 9.01
- 2020-01-31 0001193125-20-021278 — 5.02
- 2020-01-22 0001193125-20-012011 — 1.01, 7.01, 9.01
- 2019-10-30 0001193125-19-278973 — 2.02, 9.01
- 2019-08-19 0001193125-19-224091 — 5.02, 9.01
- 2019-07-31 0001193125-19-208689 — 2.02, 9.01
- 2019-07-24 0001193125-19-201401 — 1.01, 2.03
- 2019-06-13 0001193125-19-171943 — 7.01, 9.01
- 2019-06-06 0001193125-19-167332 — 1.01, 2.03, 3.03, 7.01, 9.01
- 2019-05-09 0001193125-19-143113 — 5.07
- 2019-05-01 0001193125-19-132977 — 2.02, 9.01
- 2019-02-06 0001193125-19-029540 — 2.02, 9.01
- 2019-01-15 0001193125-19-009142 — 2.02, 9.01
- 2018-10-30 0001193125-18-312212 — 2.02, 9.01
- 2018-10-22 0001193125-18-303926 — 5.02
- 2018-09-06 0001193125-18-268231 — 5.02, 9.01
- 2018-08-01 0001193125-18-234997 — 2.02, 9.01
- 2018-06-29 0001193125-18-209635 — 9.01 — amendment of 0001193125-18-120583
- 2018-05-29 0001193125-18-176976 — 7.01, 9.01
- 2018-05-10 0001193125-18-159394 — 5.07
- 2018-05-09 0001193125-18-157596 — 5.02
- 2018-05-02 0001193125-18-148650 — 2.02, 9.01
- 2018-04-18 0001193125-18-120583 — 1.01, 2.01, 2.03, 7.01, 9.01
- 2018-02-21 0001193125-18-052169 — 8.01, 9.01
- 2018-02-20 0001193125-18-050385 — 5.02, 9.01
- 2018-02-09 0001193125-18-036966 — 7.01, 9.01
- 2018-02-07 0001193125-18-034744 — 2.02, 9.01
- 2017-12-14 0001193125-17-369625 — 1.01, 2.03, 9.01
- 2017-12-04 0001193125-17-359439 — 1.01, 7.01, 9.01
- 2017-11-01 0001193125-17-329425 — 2.02, 9.01
- 2017-09-29 0001193125-17-298999 — 1.01, 2.03, 3.03, 7.01, 9.01
- 2017-09-15 0001193125-17-286491 — 7.01, 9.01
- 2017-09-11 0001193125-17-281193 — 7.01, 9.01
- 2017-09-06 0001193125-17-277536 — 7.01, 9.01
- 2017-08-02 0001193125-17-245823 — 2.02, 9.01
- 2017-05-18 0001193125-17-173896 — 5.02, 5.07
- 2017-05-08 0001193125-17-162548 — 2.02, 9.01
- 2017-03-01 0001193125-17-063931 — 1.01, 1.02, 5.02
- 2017-02-08 0001193125-17-034652 — 2.02, 9.01
- 2016-11-18 0001193125-16-772305 — 8.01, 9.01
- 2016-10-26 0001193125-16-747948 — 2.02, 9.01
- 2016-10-20 0001193125-16-742905 — 5.02
- 2016-10-05 0001193125-16-731552 — 5.02, 9.01
- 2016-09-27 0001193125-16-720828 — 1.01, 2.03, 7.01, 9.01
- 2016-07-27 0001193125-16-659983 — 2.02, 9.01
- 2016-05-23 0001193125-16-599342 — 7.01, 9.01
- 2016-05-18 0001193125-16-594656 — 5.02, 5.03, 5.07, 9.01
- 2016-04-27 0001171843-16-009432 — 2.02, 9.01
- 2016-03-08 0001193125-16-495457 — 5.03, 7.01, 9.01
- 2016-02-09 0001193125-16-454281 — 8.01, 9.01
- 2016-02-04 0001171843-16-007659 — 2.02, 9.01
- 2016-01-04 0001193125-16-418740 — 1.01, 9.01
- 2015-12-11 0001193125-15-400867 — 5.02, 9.01
- 2015-10-30 0001171843-15-005835 — 2.02, 7.01 — amendment of 0001171843-15-005766
- 2015-10-28 0001171843-15-005766 — 2.02, 9.01
- 2015-09-29 0001193125-15-331517 — 2.02, 2.05, 2.06, 9.01
- 2015-08-05 0001171843-15-004361 — 2.02, 9.01
- 2015-07-31 0001193125-15-272962 — 9.01 — amendment of 0001193125-15-210734
- 2015-06-02 0001193125-15-210734 — 1.01, 1.02, 2.01, 2.03, 7.01, 9.01
- 2015-05-29 0001193125-15-206622 — 1.01, 2.03, 9.01
- 2015-05-20 0001171843-15-002975 — 7.01, 9.01
- 2015-05-19 0001193125-15-193434 — 5.07, 9.01
- 2015-05-05 0001171843-15-002499 — 7.01, 9.01
- 2015-04-29 0001171843-15-002307 — 2.02, 9.01
- 2015-04-21 0001193125-15-139239 — 7.01, 9.01
- 2015-04-21 0001171843-15-002065 — 2.02, 9.01
- 2015-02-04 0001171843-15-000599 — 2.02, 9.01
- 2015-01-20 0001193125-15-014019 — 7.01, 9.01
- 2014-12-30 0001193125-14-457111 — 7.01, 9.01
- 2014-12-15 0001193125-14-442645 — 1.01, 9.01
- 2014-12-04 0001193125-14-433658 — 8.01, 9.01
- 2014-11-18 0001193125-14-415889 — 7.01, 9.01
- 2014-10-29 0001171843-14-005051 — 2.02, 9.01
- 2014-10-27 0001193125-14-383428 — 1.01, 9.01
- 2014-09-22 0001193125-14-348697 — 1.01, 7.01, 9.01
- 2014-08-05 0001193125-14-295808 — 1.01, 5.02, 9.01
- 2014-07-30 0001171843-14-003548 — 2.02, 9.01
- 2014-04-30 0001171843-14-002017 — 2.02, 9.01
- 2014-04-25 0001193125-14-160146 — 5.02, 5.07, 9.01
- 2014-04-10 0001171843-14-001656 — 2.02, 9.01
- 2014-03-04 0001193125-14-082534 — 4.01, 9.01
- 2014-02-05 0001171843-14-000553 — 2.02, 9.01
- 2014-01-14 0001193125-14-010922 — 1.01, 2.03, 3.02, 8.01, 9.01
- 2013-12-27 0001193125-13-486144 — 5.02, 9.01
- 2013-12-20 0001193125-13-481141 — 1.01, 1.02, 2.03, 3.02, 8.01, 9.01
- 2013-12-17 0001193125-13-476207 — 5.03
- 2013-10-30 0001193125-13-418572 — 2.02, 5.02, 9.01
- 2013-09-12 0001193125-13-365420 — 2.05
- 2013-08-14 0001193125-13-334349 — 7.01, 9.01
- 2013-08-01 0001171843-13-003138 — 2.02, 9.01
- 2013-06-25 0001193125-13-270725 — 5.02, 9.01
- 2013-05-02 0001171843-13-001746 — 2.02, 9.01
- 2013-04-29 0001193125-13-182083 — 5.02, 5.07, 9.01
- 2013-03-18 0001193125-13-111308 — 1.01, 7.01, 9.01
- 2013-03-06 0001193125-13-093625 — 5.02, 9.01
- 2013-03-01 0001193125-13-087439 — 2.02 — amendment of 0001171843-13-000414
- 2013-02-28 0001193125-13-084764 — 5.02
- 2013-02-05 0001171843-13-000414 — 2.02, 9.01
- 2013-01-31 0001193125-13-032848 — 5.02, 9.01
- 2013-01-17 0001193125-13-015928 — 7.01, 9.01
- 2013-01-16 0001193125-13-014581 — 2.02, 9.01
- 2012-12-11 0001193125-12-498644 — 5.02, 9.01
- 2012-11-15 0001193125-12-472451 — 7.01, 9.01
- 2012-11-01 0001171843-12-003890 — 2.02, 9.01
- 2012-09-19 0001193125-12-396969 — 1.01, 2.03, 7.01, 9.01
- 2012-09-11 0001193125-12-388130 — 7.01, 9.01
- 2012-07-31 0001171843-12-002829 — 2.02, 9.01
- 2012-05-15 0001193125-12-233501 — 7.01, 9.01
- 2012-05-01 0001171843-12-001574 — 2.02, 9.01
- 2012-04-27 0001193125-12-191623 — 5.07
- 2012-03-01 0001193125-12-090623 — 2.02 — amendment of 0001171843-12-000382
- 2012-02-07 0001171843-12-000382 — 2.02, 9.01
- 2012-01-19 0001193125-12-016588 — 5.02, 9.01
- 2011-11-15 0000950123-11-098812 — 7.01, 9.01
- 2011-11-02 0001171843-11-003248 — 2.02, 9.01
- 2011-09-28 0000950123-11-087344 — 7.01, 9.01
- 2011-09-19 0000950123-11-085128 — 5.02, 9.01
- 2011-09-15 0000950123-11-084704 — 5.07 — amendment of 0000950123-11-054296
- 2011-08-04 0001171843-11-002356 — 2.02, 9.01
- 2011-07-27 0000950123-11-068987 — 1.01, 2.03, 9.01
- 2011-06-21 0000950123-11-060477 — 7.01, 9.01
- 2011-06-06 0000950123-11-056971 — 5.03, 9.01
- 2011-05-26 0000950123-11-054296 — 5.07
- 2011-05-10 0000950123-11-048462 — 8.01, 9.01
- 2011-05-05 0001171843-11-001344 — 2.02, 9.01
- 2011-03-22 0000950123-11-027824 — 7.01, 9.01
- 2011-03-18 0000950123-11-026913 — 4.01
- 2011-03-18 0000950123-11-026910 — 4.01, 9.01 — amendment, the index does not say of what
- 2011-03-02 0000950123-11-020941 — 5.03, 9.01
- 2011-02-10 0001171843-11-000391 — 2.02, 9.01
- 2011-01-13 0000950123-11-002528 — 7.01, 9.01
- 2011-01-13 0000950123-11-002446 — 2.02, 9.01
- 2010-11-29 0000950123-10-109448 — 4.01, 9.01 — amendment, the index does not say of what
- 2010-11-17 0000950123-10-106706 — 4.01
- 2010-11-15 0000950123-10-105479 — 5.02, 9.01
- 2010-11-04 0001171843-10-002324 — 2.02, 9.01
- 2010-10-22 0000950123-10-095179 — 1.01, 9.01
- 2010-10-04 0000950123-10-090949 — 1.01, 5.03, 9.01
- 2010-08-05 0001171843-10-001587 — 2.02, 9.01
- 2010-08-05 0000950123-10-073258 — 1.01, 2.03, 9.01
- 2010-08-05 0000950123-10-073256 — 9.01 — amendment of 0000950123-10-034163
- 2010-07-12 0000950123-10-064794 — 5.02, 8.01, 9.01
- 2010-06-10 0000950123-10-057166 — 7.01, 9.01
- 2010-06-02 0000950123-10-055111 — 1.01, 5.07, 9.01
- 2010-05-06 0001171843-10-000819 — 2.02, 9.01
- 2010-04-26 0000950123-10-037806 — 8.01, 9.01 — amendment of 0000950123-10-034163
- 2010-04-13 0000950123-10-034163 — 1.01, 2.01, 2.03, 5.02, 7.01, 9.01
- 2010-03-30 0000950123-10-030123 — 1.01, 5.02, 9.01
- 2010-03-24 0000950123-10-027317 — 1.01, 5.02, 9.01
- 2010-03-16 0000950123-10-024853 — 7.01, 9.01 — amendment of 0001171843-10-000140
- 2010-03-15 0000950123-10-024637 — 5.07
- 2010-02-04 0001171843-10-000140 — 2.02, 9.01
- 2010-02-02 0000950123-10-007780 — 8.01, 9.01
- 2010-01-13 0000950123-10-002245 — 7.01, 9.01
- 2009-12-23 0000950123-09-073069 — 1.01, 9.01
- 2009-12-15 0000950123-09-070868 — 8.01, 9.01
- 2009-11-16 0000950123-09-062630 — 1.01, 7.01, 9.01
- 2009-11-04 0001171843-09-001103 — 2.02, 9.01
- 2009-09-04 0000950123-09-041133 — 2.05, 9.01
- 2009-07-29 0001171843-09-000743 — 2.02, 9.01
- 2009-06-09 0000950123-09-012507 — 7.01, 9.01
- 2009-04-30 0001171843-09-000427 — 2.02, 9.01
- 2009-04-28 0001362310-09-005960 — 8.01
- 2009-02-19 0001362310-09-002454 — 5.03, 9.01
- 2009-02-10 0001171843-09-000123 — 2.02, 9.01
- 2009-01-16 0000950153-09-000040 — 2.05, 9.01
- 2009-01-08 0000950153-09-000023 — 7.01, 9.01
- 2008-10-29 0001157523-08-008533 — 2.02, 9.01
- 2008-07-29 0001157523-08-005998 — 2.02, 9.01
- 2008-05-22 0000950153-08-001035 — 1.01, 2.03, 3.02, 9.01
- 2008-05-22 0000950153-08-001034 — 7.01, 9.01
- 2008-05-15 0000950153-08-000987 — 1.01, 1.02, 2.03, 3.02, 9.01
- 2008-04-30 0001157523-08-003483 — 2.02, 9.01
- 2008-02-07 0001157523-08-001077 — 2.02, 9.01
- 2008-01-08 0000950153-08-000033 — 7.01, 9.01
- 2007-11-15 0000950153-07-002440 — 7.01, 9.01
- 2007-11-14 0000950153-07-002426 — 7.01, 9.01
- 2007-11-14 0000950153-07-002421 — 5.03, 9.01
- 2007-10-31 0001157523-07-010491 — 2.02, 9.01
- 2007-10-02 0000950153-07-002094 — 7.01, 9.01
- 2007-07-31 0000950153-07-001622 — 2.02, 9.01
- 2007-06-13 0000950153-07-001327 — 7.01, 9.01
- 2007-05-02 0000950153-07-000941 — 2.02, 9.01
- 2007-04-12 0000950153-07-000763 — 5.02, 9.01
- 2007-02-15 0000950153-07-000339 — 2.02, 9.01
- 2007-01-11 0000950153-07-000076 — 7.01, 9.01
- 2007-01-10 0000950153-07-000071 — 2.01, 9.01 — amendment, the index does not say of what
- 2006-12-11 0000950153-06-002967 — 2.05, 9.01
- 2006-11-15 0000950153-06-002843 — 7.01, 9.01
- 2006-11-14 0000950153-06-002837 — 7.01, 9.01
- 2006-11-02 0000950153-06-002682 — 1.01, 1.02, 2.03, 9.01
- 2006-11-01 0000950153-06-002668 — 2.02, 9.01
- 2006-10-30 0000950124-06-006210 — 2.01, 9.01
- 2006-08-04 0000950153-06-002025 — 1.01, 9.01
- 2006-07-26 0000950153-06-001937 — 2.02, 9.01
- 2006-06-28 0000950153-06-001716 — 1.01, 9.01
- 2006-06-13 0000950153-06-001597 — 7.01, 9.01
- 2006-04-26 0000950153-06-001079 — 2.02, 9.01
- 2006-02-08 0001104659-06-006985 — 2.02, 9.01
- 2006-01-12 0001104659-06-001893 — 7.01, 9.01
- 2005-12-05 0001104659-05-058918 — 1.01, 5.02, 9.01
- 2005-10-26 0001104659-05-050306 — 2.02, 9.01
- 2005-09-20 0001104659-05-044954 — 8.01
- 2005-08-30 0001104659-05-042053 — 3.03, 8.01, 9.01
- 2005-07-27 0001104659-05-034437 — 2.02, 5.02, 9.01
- 2005-07-21 0001104659-05-033462 — 1.01, 1.02, 2.03, 9.01
- 2005-06-13 0001104659-05-027969 — 8.01
- 2005-06-08 0001104659-05-027364 — 7.01, 9.01
- 2005-05-17 0001104659-05-024118 — 7.01, 9.01
- 2005-05-12 0001104659-05-022993 — 7.01, 9.01
- 2005-05-11 0001104659-05-022606 — 1.01, 9.01
- 2005-05-02 0001104659-05-019649 — 2.02, 5.02, 9.01
- 2005-04-26 0001104659-05-018233 — 7.01, 9.01
- 2005-02-08 0001104659-05-004642 — 2.02, 9.01
- 2005-01-12 0001104659-05-001194 — 7.01, 9.01
- 2004-12-22 0001104659-04-040933 — 5.02
- 2004-12-08 0001104659-04-038850 — 7.01, 9.01
- 2004-10-26 0001104659-04-031931 — 2.02, 9.01
- 2004-10-01 0001104659-04-029361 — 5.02
- 2004-08-02 0001104659-04-021785 — 9
- 2004-07-29 0001104659-04-021529 — 12
- 2004-05-06 0001104659-04-012742 — 9
- 2004-04-26 0001104659-04-011228 — 12
- 2004-02-03 0001104659-04-002424 — 9
- 2004-01-28 0001104659-04-001980 — 12
- 2004-01-09 0001104659-04-000457 — 9
- 2003-10-21 0001104659-03-023304 — 12
- 2003-07-29 0001104659-03-015999 — 12
- 2003-05-08 0001104659-03-008647 — 9
- 2003-05-08 0001104659-03-008462 — 9
- 2003-05-01 0001104659-03-007866 — 9
- 2003-03-07 0001104659-03-003816 — 2, 7 — amendment of 0000950153-02-002190
- 2002-12-27 0000950153-02-002190 — 2, 7
- 2002-05-17 0000912057-02-021145 — 4, 7
- 2001-12-21 0000912057-01-544281 — 7
- 2000-10-27 0000912057-00-046109 — 5

## late-filing notifications on or before 2026-02-17

- none on or before 2026-02-17

## item 2.02 — earnings release, exhibit 99.1

[0001193125-26-037560:8k_2_02:1]
EX-99.1
2
d19660dex991.htm
EX-99.1

[0001193125-26-037560:8k_2_02:2]
EX-99.1

[0001193125-26-037560:8k_2_02:3]
Exhibit 99.1

[0001193125-26-037560:8k_2_02:4]
|  |  |  |  | Contact: Sean K.F. Hannan, Vice President, Investor Relations Sean.Hannan@ttmtech.com +1 339 466 7737 |

[0001193125-26-037560:8k_2_02:5]
TTM Technologies, Inc. Reports Fourth Quarter & Fiscal Year 2025 Results

[0001193125-26-037560:8k_2_02:6]
Santa Ana, CA – February 4, 2026 – TTM Technologies, Inc. (NASDAQ: TTMI) (“TTM”), a leading global manufacturer of technology
products, including mission systems, radio frequency (“RF”) components, RF microwave/microelectronic assemblies, and technologically advanced interconnect products, including printed circuit boards (“PCB”s) and substrates,
today reported results for the fourth quarter and fiscal 2025, which ended on December 29, 2025.

[0001193125-26-037560:8k_2_02:7]
Fourth Quarter 2025 Highlights

[0001193125-26-037560:8k_2_02:8]
|  | • |  | Net sales were $774.3 million, up 19% year on year |

[0001193125-26-037560:8k_2_02:9]
|  | • |  | GAAP net income of $50.7 million, or $0.48 per diluted share |

[0001193125-26-037560:8k_2_02:10]
|  | • |  | Adjusted EBITDA of $126.2 million, or 16.3% of net sales |

[0001193125-26-037560:8k_2_02:11]
|  | • |  | Non-GAAP net income of $74.8 million, or $0.70 per diluted share, an all-time quarterly record high |

[0001193125-26-037560:8k_2_02:12]
|  | • |  | Cash flow from operations of $62.9 million, or 8.1% of net sales |

[0001193125-26-037560:8k_2_02:13]
|  | • |  | Total book to bill of 1.35 for the fourth quarter |

[0001193125-26-037560:8k_2_02:14]
|  | • |  | A&D program backlog $1.6 billion |

[0001193125-26-037560:8k_2_02:15]
|  | • |  | Data Center Computing and Networking combined end market revenues increased to 36% of total company revenues driven by generative AI demand |

[0001193125-26-037560:8k_2_02:16]
Fourth Quarter 2025 GAAP Financial Results

[0001193125-26-037560:8k_2_02:17]
Net sales in the fourth quarter of 2025 were $774.3 million, compared to $651.0 million in the fourth quarter of 2024.

[0001193125-26-037560:8k_2_02:18]
GAAP operating income in the fourth quarter of 2025 was $80.7 million. This compared to GAAP operating income in the fourth quarter of 2024 of
$9.0 million, inclusive of a $32.6 million goodwill impairment charge related to the RF&S Components segment.

[0001193125-26-037560:8k_2_02:19]
GAAP net income in the fourth
quarter of 2025 was $50.7 million, or $0.48 per diluted share. This compared to GAAP net income in the fourth quarter of 2024 of $5.2 million, or $0.05 per diluted share, inclusive of a $32.6 million goodwill impairment charge related
to the RF&S Components segment.

[0001193125-26-037560:8k_2_02:20]
Fourth Quarter 2025 Non-GAAP Financial Results

[0001193125-26-037560:8k_2_02:21]
Adjusted EBITDA in the fourth quarter of 2025 was $126.2 million, or 16.3% of net sales, compared to adjusted EBITDA of $95.7 million, or 14.7% of
net sales, in the fourth quarter of 2024.

[0001193125-26-037560:8k_2_02:22]
Non-GAAP net income in the fourth quarter of 2025 was
$74.8 million, or $0.70 per diluted share. This compares to non-GAAP net income of $51.4 million, or $0.49 per diluted share, in the fourth quarter of 2024.

[0001193125-26-037560:8k_2_02:23]
“We delivered another strong quarter with both revenues and non-GAAP EPS at or above the high end of the guided
range. Revenues grew 19% reflecting continued demand strength in the Data Center Computing and Networking end markets supporting AI and data center buildouts. Our Medical, Industrial and Instrumentation end market experienced healthy double-digit
revenue growth while Aerospace and Defense experienced higher than market growth,” said Edwin Roks, President & CEO of TTM Technologies Inc. “Adjusted EBITDA margins were 16.3%, reflecting continued solid execution.” concluded
Dr. Roks.

[0001193125-26-037560:8k_2_02:24]
Full Year 2025 Results

[0001193125-26-037560:8k_2_02:25]
Net sales for 2025
increased to $2.9 billion from $2.4 billion in 2024, a 19.0% increase.

[0001193125-26-037560:8k_2_02:26]
GAAP operating income for 2025 was $264.7 million. This compares to
a GAAP operating income for 2024 of $116.0 million, inclusive of a $32.6 million goodwill impairment charge related to the RF&S Components segment.

[0001193125-26-037560:8k_2_02:27]
|  |  |  |  | Contact: Sean K.F. Hannan, Vice President, Investor Relations Sean.Hannan@ttmtech.com +1 339 466 7737 |

[0001193125-26-037560:8k_2_02:28]
GAAP net income for 2025 was $177.4 million, or $1.68 per diluted share. This compares to GAAP net
income for 2024 of $56.3 million, or $0.54 per diluted share, inclusive of a $32.6 million goodwill impairment charge related to the RF&S Components segment.

[0001193125-26-037560:8k_2_02:29]
On a non-GAAP basis, net income for 2025 was $259.0 million, or $2.46 per diluted share. This compares to 2024 non-GAAP net income of $177.5 million, or $1.70 per diluted share.

[0001193125-26-037560:8k_2_02:30]
Adjusted EBITDA for 2025 was
$456.3 million, or 15.7% of net sales, compared to $351.5 million, or 14.4% of net sales, for 2024.

[0001193125-26-037560:8k_2_02:31]
“Our employees delivered powerful
growth and profitability results in 2025 for TTM. Revenue growth of 19% was largely driven by generative AI in the Data Center Computing and Networking end markets and continued strength in the Aerospace and Defense, and Medical, Industrial, and
Instrumentation end markets. Revenue fall through, favorable product mix, and improved execution helped to grow margins and non-GAAP EPS,” continued Roks. “We continue to push forward and execute
upon strategic priorities by capitalizing on our growth opportunities through leading product innovation and optimized technological and geographic capacity.”

[0001193125-26-037560:8k_2_02:32]
Business Outlook

[0001193125-26-037560:8k_2_02:33]
For the first quarter of 2026, TTM
estimates that net sales will be in the range of $770 million to $810 million, and non-GAAP net income will be in the range of $0.64 to $0.70 per diluted share. For fiscal year 2026, TTM estimates
that net sales will grow in the 15% to 20% range.

[0001193125-26-037560:8k_2_02:34]
With respect to TTM’s outlook for non-GAAP net income per
diluted share, we are unable to predict with reasonable certainty or without unreasonable effort certain items that may affect a comparable measure calculated and presented in accordance with GAAP. Our expected
non-GAAP net income per diluted share excludes primarily the future impact of restructuring actions, impairment charges, unusual gains and losses including but not limited to unrealized foreign exchange
translation, and tax adjustments. These reconciling items are highly variable and difficult to predict due to various factors outside of management’s control and could have a material impact on our future period net income per diluted share
calculated and presented in accordance with GAAP. Accordingly, a reconciliation of non-GAAP net income per diluted share to a comparable measure calculated and presented in accordance with GAAP has not been
provided because TTM is unable to provide such reconciliation without unreasonable effort. For the same reasons, TTM is unable to address the probable significance of the information.

[0001193125-26-037560:8k_2_02:35]
Live Webcast/Conference Call

[0001193125-26-037560:8k_2_02:36]
TTM will host a conference
call and webcast to discuss fourth quarter and fiscal year 2025 results and the first quarter 2026 outlook on Wednesday, February 4, 2026, at 4:30 p.m. Eastern Time (1:30 p.m. Pacific Time). The conference call will include forward-looking
statements.

[0001193125-26-037560:8k_2_02:37]
Access to the conference call will be available by clicking on the registration link TTM Technologies, Inc. Fourth Quarter and
Fiscal 2025 Conference Call. Registering participants will receive dial in information and a unique PIN to join the call. Participants can register at any time up to the start of the conference call. The conference call will also be simulcast on
the company’s website for those who would like to view the live webcast, and this can be accessed by clicking on the link TTM Technologies Fourth Quarter and Fiscal 2025 Webcast.

[0001193125-26-037560:8k_2_02:38]
|  |  |  |  | Contact: Sean K.F. Hannan, Vice President, Investor Relations Sean.Hannan@ttmtech.com +1 339 466 7737 |

[0001193125-26-037560:8k_2_02:39]
To Access a Replay of the Webcast

[0001193125-26-037560:8k_2_02:40]
The replay of the webcast will remain accessible for one week following the live event on TTM’s website at TTM Technologies Inc. Fourth Quarter and
Fiscal 2025 Webcast.

[0001193125-26-037560:8k_2_02:41]
About TTM

[0001193125-26-037560:8k_2_02:42]
TTM
Technologies, Inc. is a leading global manufacturer of technology products, including mission systems, radio frequency (“RF”) components, RF microwave/microelectronic assemblies, and technologically advanced interconnect products,
including PCBs and substrates. TTM stands for time-to-market, representing how TTM’s time-critical, one-stop design,
engineering and manufacturing services enable customers to reduce the time required to develop new products and bring them to market. Additional information can be found at www.ttm.com.

[0001193125-26-037560:8k_2_02:43]
Forward-Looking Statements

[0001193125-26-037560:8k_2_02:44]
The preliminary financial
results included in this press release represent the most current information available to management. TTM’s actual results when disclosed in its Form 10-Q may differ from these preliminary results as a
result of the completion of TTM’s financial closing procedures, final adjustments, completion of the review by TTM’s independent registered accounting firm, and other developments that may arise between now and the disclosure of the
final results. This release contains forward-looking statements that relate to future events or performance. TTM cautions you that such statements are simply predictions and actual events or results may differ materially. These statements reflect
TTM’s current expectations, and TTM does not undertake to update or revise these forward-looking statements, even if experience or future changes make it clear that any projected results expressed or implied in this or other TTM statements
will not be realized. Further, these statements involve risks and uncertainties, many of which are beyond TTM’s control, which could cause actual results to differ materially from the forward-looking statements. These risks and uncertainties
include, but are not limited to, general market and economic conditions, including interest rates, currency exchange rates, and consumer spending, demand for TTM’s products, market pressures on prices of TTM’s products, warranty claims,
changes in product mix, contemplated significant capital expenditures and related financing requirements, TTM’s dependence upon a small number of customers, and other factors set forth in the “Risk Factors” and
“Management’s Discussion and Analysis of Financial Condition and Results of Operations” sections of TTM’s public reports filed with the SEC.

[0001193125-26-037560:8k_2_02:45]
About Our Non-GAAP Financial Measures

[0001193125-26-037560:8k_2_02:46]
To supplement our consolidated condensed financial statements presented on a GAAP basis, this release includes information about TTM’s adjusted EBITDA, non-GAAP net income, and non-GAAP earnings per diluted share (“EPS”), all of which are non-GAAP financial measures. TTM
presents non-GAAP financial information to enable investors to see TTM through the eyes of management and to provide better insight into TTM’s ongoing financial performance.

[0001193125-26-037560:8k_2_02:47]
A material limitation associated with the use of the above non-GAAP financial measures is that they have no
standardized measurement prescribed by GAAP and may not be comparable to similar non-GAAP financial measures used by other companies. TTM compensates for these limitations by providing full disclosure of each non-GAAP financial measure and reconciliations below to the most directly comparable GAAP financial measure. However, the non-GAAP financial measures should not be considered
in isolation from, or as a substitute for, financial information prepared in accordance with GAAP.

[0001193125-26-037560:8k_2_02:48]
- Tables Follow -

[0001193125-26-037560:8k_2_02:49]
TTM TECHNOLOGIES, INC.

[0001193125-26-037560:8k_2_02:50]
Selected Unaudited Financial Information

[0001193125-26-037560:8k_2_02:51]
(In thousands, except per share data)

[0001193125-26-037560:8k_2_02:52]
|  |  | Fourth Quarter |  |  | Full Year |  |
|  |  | 2025 |  |  | 2024 |  |  | 2025 |  |  | 2024 |  |
| CONSOLIDATED CONDENSED STATEMENTS OF OPERATIONS |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Net sales |  | $ | 774,320 |  |  | $ | 650,965 |  |  | $ | 2,906,345 |  |  | $ | 2,442,753 |  |
| Cost of goods sold |  |  | 608,451 |  |  |  | 524,424 |  |  |  | 2,304,659 |  |  |  | 1,965,378 |  |
| Gross profit |  |  | 165,869 |  |  |  | 126,541 |  |  |  | 601,686 |  |  |  | 477,375 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Selling and marketing |  |  | 21,077 |  |  |  | 19,977 |  |  |  | 85,460 |  |  |  | 80,030 |  |
| General and administrative |  |  | 50,058 |  |  |  | 45,266 |  |  |  | 192,149 |  |  |  | 170,107 |  |
| Research and development |  |  | 6,881 |  |  |  | 7,923 |  |  |  | 28,992 |  |  |  | 31,845 |  |
| Amortization of definite-lived intangibles |  |  | 6,888 |  |  |  | 6,914 |  |  |  | 27,554 |  |  |  | 35,550 |  |
| Impairment of goodwill |  |  | — |  |  |  | 32,600 |  |  |  | — |  |  |  | 32,600 |  |
| Restructuring charges |  |  | 216 |  |  |  | 4,833 |  |  |  | 2,847 |  |  |  | 11,200 |  |
| Total operating expenses |  |  | 85,120 |  |  |  | 117,513 |  |  |  | 337,002 |  |  |  | 361,332 |  |
| Operating income |  |  | 80,749 |  |  |  | 9,028 |  |  |  | 264,684 |  |  |  | 116,043 |  |
| Interest expense |  |  | (12,376 | ) |  |  | (11,204 | ) |  |  | (45,334 | ) |  |  | (47,515 | ) |
| Other, net |  |  | (6,365 | ) |  |  | 16,507 |  |  |  | (9,013 | ) |  |  | 15,421 |  |
| Income before income taxes |  |  | 62,008 |  |  |  | 14,331 |  |  |  | 210,337 |  |  |  | 83,949 |  |
| Income tax provision |  |  | (11,323 | ) |  |  | (9,161 | ) |  |  | (32,889 | ) |  |  | (27,650 | ) |
| Net income |  | $ | 50,685 |  |  | $ | 5,170 |  |  | $ | 177,448 |  |  | $ | 56,299 |  |
| Earnings per share: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  | $ | 0.49 |  |  | $ | 0.05 |  |  | $ | 1.73 |  |  | $ | 0.55 |  |
| Diluted |  |  | 0.48 |  |  |  | 0.05 |  |  |  | 1.68 |  |  |  | 0.54 |  |
| Weighted-average shares used in computing per share amounts: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  |  | 103,351 |  |  |  | 101,981 |  |  |  | 102,598 |  |  |  | 101,781 |  |
| Diluted |  |  | 106,596 |  |  |  | 104,576 |  |  |  | 105,453 |  |  |  | 104,098 |  |
| Reconciliation of the denominator used to calculate basic earnings per share and diluted earnings per share: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Weighted-average shares outstanding |  |  | 103,351 |  |  |  | 101,981 |  |  |  | 102,598 |  |  |  | 101,781 |  |
| Dilutive effect of performance-based stock units, restricted stock units and stock options |  |  | 3,245 |  |  |  | 2,595 |  |  |  | 2,855 |  |  |  | 2,317 |  |
| Diluted shares |  |  | 106,596 |  |  |  | 104,576 |  |  |  | 105,453 |  |  |  | 104,098 |  |

[0001193125-26-037560:8k_2_02:53]
| SELECTED BALANCE SHEET DATA |  |  |  |  |  |  |  |  |
|  |  | December 29, 2025 |  |  | December 30, 2024 |  |
| Cash and cash equivalents |  | $ | 501,234 |  |  | $ | 503,932 |  |
| Accounts receivable, net |  |  | 563,741 |  |  |  | 448,611 |  |
| Contract assets |  |  | 468,006 |  |  |  | 381,382 |  |
| Inventories |  |  | 250,057 |  |  |  | 224,985 |  |
| Total current assets |  |  | 1,855,406 |  |  |  | 1,606,744 |  |
| Property, plant and equipment, net |  |  | 1,010,710 |  |  |  | 869,957 |  |
| Total assets |  |  | 3,840,331 |  |  |  | 3,472,494 |  |
| Short-term debt, including current portion of long-term debt |  | $ | 3,815 |  |  | $ | 3,795 |  |
| Accounts payable |  |  | 543,538 |  |  |  | 406,221 |  |
| Contract liabilities |  |  | 175,627 |  |  |  | 170,915 |  |
| Total current liabilities |  |  | 962,197 |  |  |  | 809,054 |  |
| Long-term debt, net of discount and issuance costs |  |  | 912,336 |  |  |  | 914,359 |  |
| Total long-term liabilities |  |  | 1,115,881 |  |  |  | 1,099,616 |  |
| Total stockholders’ equity |  |  | 1,762,253 |  |  |  | 1,563,824 |  |
| Total liabilities and stockholders’ equity |  |  | 3,840,331 |  |  |  | 3,472,494 |  |

[0001193125-26-037560:8k_2_02:54]
| SUPPLEMENTAL DATA |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | Fourth Quarter |  |  | Full Year |  |
|  |  | 2025 |  |  | 2024 |  |  | 2025 |  |  | 2024 |  |
| Gross margin |  |  | 21.4 | % |  |  | 19.4 | % |  |  | 20.7 | % |  |  | 19.5 | % |
| Operating margin |  |  | 10.4 | % |  |  | 1.4 | % |  |  | 9.1 | % |  |  | 4.8 | % |
|  |  | Fourth Quarter |  |  | Full Year |  |
|  |  | 2025 |  |  | 2024 |  |  | 2025 |  |  | 2024 |  |
| End market breakdown1 : |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Aerospace and Defense |  |  | 41 | % |  |  | 46 | % |  |  | 44 | % |  |  | 46 | % |
| Automotive |  |  | 9 | % |  |  | 12 | % |  |  | 10 | % |  |  | 13 | % |
| Data Center Computing |  |  | 28 | % |  |  | 22 | % |  |  | 24 | % |  |  | 20 | % |
| Medical/Industrial/Instrumentation |  |  | 14 | % |  |  | 13 | % |  |  | 14 | % |  |  | 14 | % |
| Networking |  |  | 8 | % |  |  | 7 | % |  |  | 8 | % |  |  | 7 | % |
|  |  | Fourth Quarter |  |  | Full Year |  |
|  |  | 2025 |  |  | 2024 |  |  | 2025 |  |  | 2024 |  |
| Operating segment data1 : |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Net sales: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Aerospace & Defense |  | $ | 317,970 |  |  | $ | 306,157 |  |  | $ | 1,292,523 |  |  | $ | 1,139,955 |  |
| Commercial |  |  | 448,452 |  |  |  | 339,261 |  |  |  | 1,585,701 |  |  |  | 1,275,701 |  |
| RF&S Components |  |  | 10,672 |  |  |  | 10,121 |  |  |  | 40,014 |  |  |  | 37,317 |  |
| Intersegment eliminations |  |  | (2,774 | ) |  |  | (4,574 | ) |  |  | (11,893 | ) |  |  | (10,220 | ) |
| Total net sales |  | $ | 774,320 |  |  | $ | 650,965 |  |  | $ | 2,906,345 |  |  | $ | 2,442,753 |  |
| Segment operating income: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Aerospace & Defense |  |  | 44,870 |  |  |  | 41,548 |  |  |  | 183,813 |  |  |  | 141,800 |  |
| Commercial |  |  | 75,032 |  |  |  | 48,924 |  |  |  | 238,781 |  |  |  | 179,782 |  |
| RF&S Components |  |  | 3,672 |  |  |  | 2,527 |  |  |  | 11,253 |  |  |  | 8,666 |  |
| Total segment operating income |  | $ | 123,574 |  |  | $ | 92,999 |  |  | $ | 433,847 |  |  | $ | 330,248 |  |
| Unallocated amounts: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Restructuring |  |  | (216 | ) |  |  | (4,833 | ) |  |  | (2,847 | ) |  |  | (11,200 | ) |
| Impairment of goodwill |  |  | — |  |  |  | (32,600 | ) |  |  | — |  |  |  | (32,600 | ) |
| Gain on sale of property, plant, and equipment |  |  | — |  |  |  | 1,249 |  |  |  | — |  |  |  | 15,669 |  |
| Acquisition-related and other charges |  |  | — |  |  |  | (1,585 | ) |  |  | (15 | ) |  |  | (14,524 | ) |
| Stock-based compensation |  |  | (12,082 | ) |  |  | (8,083 | ) |  |  | (41,668 | ) |  |  | (29,780 | ) |
| Other corporate expenses |  |  | (21,303 | ) |  |  | (28,869 | ) |  |  | (87,736 | ) |  |  | (96,878 | ) |
| Amortization of definite-lived intangibles |  |  | (9,224 | ) |  |  | (9,250 | ) |  |  | (36,897 | ) |  |  | (44,892 | ) |
| Total operating income |  | $ | 80,749 |  |  | $ | 9,028 |  |  | $ | 264,684 |  |  | $ | 116,043 |  |
| RECONCILIATIONS2 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | Fourth Quarter |  |  | Full Year |  |
|  |  | 2025 |  |  | 2024 |  |  | 2025 |  |  | 2024 |  |
| Non-GAAP gross profit reconciliation3 : |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| GAAP gross profit |  | $ | 165,869 |  |  | $ | 126,541 |  |  | $ | 601,686 |  |  | $ | 477,375 |  |
| Add back item: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of definite-lived intangibles |  |  | 2,336 |  |  |  | 2,336 |  |  |  | 9,343 |  |  |  | 9,342 |  |
| Stock-based compensation |  |  | 3,646 |  |  |  | 2,653 |  |  |  | 12,866 |  |  |  | 9,342 |  |
| Unrealized (gain) loss on commodity hedge |  |  | (4,044 | ) |  |  | 1,635 |  |  |  | (5,879 | ) |  |  | 370 |  |
| Other charges |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 709 |  |
| Non-GAAP gross profit |  | $ | 167,807 |  |  | $ | 133,165 |  |  | $ | 618,016 |  |  | $ | 497,138 |  |
| Non-GAAP gross margin |  |  | 21.7 | % |  |  | 20.5 | % |  |  | 21.3 | % |  |  | 20.4 | % |
| Non-GAAP operating income reconciliation4 : |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| GAAP operating income |  | $ | 80,749 |  |  | $ | 9,028 |  |  | $ | 264,684 |  |  | $ | 116,043 |  |
| Add back items: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of definite-lived intangibles |  |  | 9,224 |  |  |  | 9,250 |  |  |  | 36,897 |  |  |  | 44,892 |  |
| Stock-based compensation |  |  | 12,082 |  |  |  | 8,083 |  |  |  | 41,668 |  |  |  | 29,780 |  |
| (Gain) loss on sale of property, plant and equipment |  |  | — |  |  |  | (1,249 | ) |  |  | — |  |  |  | (15,669 | ) |
| Unrealized (gain) loss on commodity hedge |  |  | (4,044 | ) |  |  | 1,635 |  |  |  | (5,879 | ) |  |  | 370 |  |
| Impairment, restructuring, acquisition-related and other charges |  |  | 226 |  |  |  | 39,018 |  |  |  | 3,044 |  |  |  | 58,324 |  |
| Non-GAAP operating income |  | $ | 98,237 |  |  | $ | 65,765 |  |  | $ | 340,414 |  |  | $ | 233,740 |  |
| Non-GAAP operating margin |  |  | 12.7 | % |  |  | 10.1 | % |  |  | 11.7 | % |  |  | 9.6 | % |
| Non-GAAP net income and EPS reconciliation5 : |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| GAAP net income |  | $ | 50,685 |  |  | $ | 5,170 |  |  | $ | 177,448 |  |  | $ | 56,299 |  |
| Add back items: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of definite-lived intangibles |  |  | 9,224 |  |  |  | 9,250 |  |  |  | 36,897 |  |  |  | 44,892 |  |
| Stock-based compensation |  |  | 12,082 |  |  |  | 8,083 |  |  |  | 41,668 |  |  |  | 29,780 |  |
| Non-cash interest expense |  |  | 548 |  |  |  | 525 |  |  |  | 2,157 |  |  |  | 2,042 |  |
| (Gain) loss on sale of property, plant and equipment |  |  | — |  |  |  | (1,249 | ) |  |  | — |  |  |  | (15,669 | ) |
| Unrealized (gain) loss on commodity hedge |  |  | (4,044 | ) |  |  | 1,635 |  |  |  | (5,879 | ) |  |  | 370 |  |
| Unrealized (gain) loss on foreign exchange |  |  | 6,163 |  |  |  | (13,048 | ) |  |  | 14,629 |  |  |  | (1,039 | ) |
| Impairment, restructuring, acquisition-related and other charges |  |  | 226 |  |  |  | 39,018 |  |  |  | 3,044 |  |  |  | 58,324 |  |
| Income taxes6 |  |  | (63 | ) |  |  | 2,005 |  |  |  | (10,994 | ) |  |  | 2,481 |  |
| Non-GAAP net income |  | $ | 74,821 |  |  | $ | 51,389 |  |  | $ | 258,970 |  |  | $ | 177,480 |  |
| Non-GAAP earnings per diluted share |  | $ | 0.70 |  |  | $ | 0.49 |  |  | $ | 2.46 |  |  | $ | 1.70 |  |

[0001193125-26-037560:8k_2_02:55]
|  |  | Fourth Quarter |  |  | Full Year |  |
|  |  | 2025 |  |  | 2024 |  |  | 2025 |  |  | 2024 |  |
| Adjusted EBITDA reconciliation7 : |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| GAAP net income |  | $ | 50,685 |  |  | $ | 5,170 |  |  | $ | 177,448 |  |  | $ | 56,299 |  |
| Add back items: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Income tax provision |  |  | 11,323 |  |  |  | 9,161 |  |  |  | 32,889 |  |  |  | 27,650 |  |
| Interest expense |  |  | 12,376 |  |  |  | 11,204 |  |  |  | 45,334 |  |  |  | 47,515 |  |
| Amortization of definite-lived intangibles |  |  | 9,224 |  |  |  | 9,250 |  |  |  | 36,897 |  |  |  | 44,892 |  |
| Depreciation expense |  |  | 28,139 |  |  |  | 26,524 |  |  |  | 110,274 |  |  |  | 105,233 |  |
| Stock-based compensation |  |  | 12,082 |  |  |  | 8,083 |  |  |  | 41,668 |  |  |  | 29,780 |  |
| (Gain) loss on sale of property, plant and equipment |  |  | — |  |  |  | (1,249 | ) |  |  | — |  |  |  | (15,669 | ) |
| Unrealized (gain) loss on commodity hedge |  |  | (4,044 | ) |  |  | 1,635 |  |  |  | (5,879 | ) |  |  | 370 |  |
| Unrealized (gain) loss on foreign exchange |  |  | 6,163 |  |  |  | (13,048 | ) |  |  | 14,629 |  |  |  | (1,039 | ) |
| Impairment, restructuring, acquisition-related and other charges |  |  | 226 |  |  |  | 38,966 |  |  |  | 3,044 |  |  |  | 56,439 |  |
| Adjusted EBITDA |  | $ | 126,174 |  |  | $ | 95,696 |  |  | $ | 456,304 |  |  | $ | 351,470 |  |
| Adjusted EBITDA margin |  |  | 16.3 | % |  |  | 14.7 | % |  |  | 15.7 | % |  |  | 14.4 | % |
| Free cash flow reconciliation: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Operating cash flow |  | $ | 62,930 |  |  | $ | 86,054 |  |  | $ | 291,882 |  |  | $ | 236,894 |  |
| Capital expenditures, net |  |  | (51,253 | ) |  |  | (52,761 | ) |  |  | (273,940 | ) |  |  | (152,871 | ) |
| Free cash flow |  | $ | 11,677 |  |  | $ | 33,293 |  |  | $ | 17,942 |  |  | $ | 84,023 |  |

[0001193125-26-037560:8k_2_02:56]
| 1 | Prior year end market revenue and operating segment data has been recasted in connection with the Company’s previously disclosed change in organization structure - refer to the recasted historical selected unaudited financial information in the Form 8-K filed on July 30, 2025 for further information. |

[0001193125-26-037560:8k_2_02:57]
| 2 | This information provides a reconciliation of non-GAAP gross profit, non-GAAP operating income, non-GAAP net income, non-GAAP EPS, and adjusted EBITDA to the financial information in our consolidated condensed statements of operations. Prior year results have been revised to exclude the impact of unrealized (gain) loss on foreign exchange from non-GAAP net income, non-GAAP EPS, and adjusted EBITDA - refer to the revised historical non-GAAP financial information in the Form 8-K filed on February 5, 2025 for further information. |

[0001193125-26-037560:8k_2_02:58]
| 3 | Non-GAAP gross profit and gross margin measures exclude amortization of definite-lived intangibles, stock-based compensation, unrealized (gain) loss on commodity hedge, and other charges. |

[0001193125-26-037560:8k_2_02:59]
| 4 | Non-GAAP operating income and operating margin measures exclude amortization of definite-lived intangibles, stock-based compensation, (gain) loss on sale of property, plant and equipment, unrealized (gain) loss on commodity hedge, impairment, restructuring, acquisition-related, and other charges. |

[0001193125-26-037560:8k_2_02:60]
| 5 | This information provides non-GAAP net income and non-GAAP EPS, which are non-GAAP financial measures. Management believes that both measures - which add back amortization of definite-lived intangibles, stock-based compensation, non-cash interest expense, (gain) loss on sale of property, plant and equipment, unrealized (gain) loss on commodity hedge, unrealized (gain) loss on foreign exchange, impairment, restructuring, acquisition-related, and other charges as well as the associated tax impact of these charges and discrete tax items - provide additional useful information to investors regarding the Company’s ongoing financial condition and results of operations. |

[0001193125-26-037560:8k_2_02:61]
| 6 | Income tax adjustments reflect the difference between income taxes based on a non-GAAP tax rate and a forecasted annual GAAP tax rate. |

[0001193125-26-037560:8k_2_02:62]
| 7 | Adjusted EBITDA is defined as earnings before income taxes provision, interest expense, amortization of definite-lived intangibles, depreciation expense, stock-based compensation, (gain) loss on sale of property, plant and equipment, unrealized (gain) loss on commodity hedge, unrealized (gain) loss on foreign exchange, impairment, restructuring, acquisition-related, and other charges. We present adjusted EBITDA to enhance the understanding of our operating results, and it is a key measure we use to evaluate our operations. In addition, we provide our adjusted EBITDA because we believe that investors and securities analysts will find adjusted EBITDA to be a useful measure for evaluating our operating performance and comparing our operating performance with that of similar companies that have different capital structures and for evaluating our ability to meet our future debt service, capital expenditures, and working capital requirements. However, adjusted EBITDA should not be considered as an alternative to cash flows from operating activities as a measure of liquidity or as an alternative to net income as a measure of operating results in accordance with accounting principles generally accepted in the United States of America. |
