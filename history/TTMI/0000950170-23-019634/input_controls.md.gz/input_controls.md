# TTMI 10-Q controls and the auditor's report


## item_4_controls

[0000950170-23-019634:item_4_controls:1]
Item 4. Controls and Procedures

[0000950170-23-019634:item_4_controls:2]
Evaluation of Disclosure Controls and Procedures

[0000950170-23-019634:item_4_controls:3]
Our management, under the supervision and with the participation of our Chief Executive Officer (CEO) and Chief Financial Officer (CFO), has evaluated the effectiveness of the design and operation of our disclosure controls and procedures (as defined in Exchange Act Rules 13a-15(e) and 15d-15(e)) as of the end of the period covered by this Quarterly Report. Based on this evaluation, our CEO and CFO have concluded that, as of April 3, 2023 such disclosure controls and procedures were effective to provide reasonable assurance that information we are required to disclose in reports that we file or submit under the Exchange Act is (i) recorded, processed, summarized and reported within the time periods specified in the SEC’s rules and forms and (ii) accumulated and communicated to our management, including our CEO and CFO, as appropriate to allow timely decisions regarding required disclosures.

[0000950170-23-019634:item_4_controls:4]
In designing and evaluating our disclosure controls and procedures, our management recognized that any controls and procedures, no matter how well designed and operated, can provide only reasonable assurance of achieving their desired control objectives, and our management is required to apply its judgment in evaluating the cost-benefit relationship of possible controls and procedures.

[0000950170-23-019634:item_4_controls:5]
Changes in Internal Control over Financial Reporting

[0000950170-23-019634:item_4_controls:6]
We continue to expand our implementation of an enterprise resource planning (ERP) system on a worldwide basis, which is expected to improve the efficiency of the financial reporting and related transaction processes. We continue to roll out the ERP system to our remaining locations.

[0000950170-23-019634:item_4_controls:7]
There have been no other changes in our internal control over financial reporting (as defined in Rules 13a-15(f) and 15d-15(f) under the Exchange Act) during the quarter ended April 3, 2023 that have materially affected, or are reasonably likely to materially affect, our internal control over financial reporting.

[0000950170-23-019634:item_4_controls:8]
28
