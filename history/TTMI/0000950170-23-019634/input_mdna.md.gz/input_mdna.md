# TTMI MD&A — 0000950170-23-019634


## mdna

[0000950170-23-019634:mdna:1]
[same as prior period, unchanged from 0000950170-22-023197:mdna:1]

[0000950170-23-019634:mdna:2]
[same as prior period, unchanged from 0000950170-22-023197:mdna:2]

[0000950170-23-019634:mdna:3]
We are a leading global manufacturer of technology solutions, including engineered systems, radio frequency (RF) components and RF microwave/microelectronic assemblies, and printed circuit boards (PCB). We focus on providing time-to-market and volume production of advanced technology products and offer a one-stop design, engineering, and manufacturing solution to our customers. This one-stop design, engineering, and manufacturing solution allows us to align technology development with the diverse needs of our customers and to enable them to reduce the time required to develop new products and bring them to market. We serve a diversified customer base consisting of approximately 1,500 customers in various markets throughout the world, including aerospace and defense, data center computing, automotive, medical, industrial and instrumentation, as well as networking. Our customers include original equipment manufacturers (OEMs), electronic manufacturing services (EMS) providers, original design manufacturers (ODMs), distributors and government agencies.

[0000950170-23-019634:mdna:4]
[same as prior period, unchanged from 0000950170-22-023197:mdna:4]

[0000950170-23-019634:mdna:5]
While demand in the Aerospace and Defense end market remains strong, bookings in our commercial end markets have stabilized at a low level given continued customer inventory reductions and weaker end market demand. This resulted in a decline to revenues during the quarter ended April 3, 2023.

[0000950170-23-019634:mdna:6]
On March 30, 2023, we completed the sale of our Shanghai Backplane Assembly entity for approximately $11.3 million, subject to customary post-closing adjustments, to DBG Holdings Limited (DBG), which is wholly owned by DBG Technology Co. Ltd., a public company traded on the Shenzhen Stock Exchange. We recorded a gain on the sale of $1.3 million.

[0000950170-23-019634:mdna:7]
On February 8, 2023, we announced that we intend to close PCB manufacturing operations in Anaheim and Santa Clara, California, and Hong Kong and to consolidate the business from these impacted sites into our remaining facilities. The plant closures are expected to improve both facility and talent utilization across our footprint resulting in improved profitability. We expect to record between $22.0 million and $28.0 million in separation, accelerated depreciation and disposal costs related to this restructuring, primarily between now and the end of 2023. Approximately 80% of these costs are expected to be in the form of cash expenditures and the rest in the form of non-cash charges.

[0000950170-23-019634:mdna:8]
On December 22, 2022, our land, building, and relevant ancillary assets related to our former Shanghai E-MS (SH E-MS) manufacturing facility was expropriated by the Chinese government for a compensation fee of Renminbi (RMB) 477.6 million resulting in a gain on the sale of $51.8 million. We received 50% of the proceeds as of April 3, 2023 and expect to receive the remaining proceeds as follows: 40% before June 30, 2023 and 10% before December 30, 2023. As of April 3, 2023 and January 2, 2023, the receivable from sale of SH E-MS property was $34.7 million and $69.2 million, respectively.

[0000950170-23-019634:mdna:9]
[same as prior period, unchanged from 0000950170-22-023197:mdna:10]

[0000950170-23-019634:mdna:10]
While our customers include both OEMs and EMS providers, we measure customers based on OEM companies, as they are the ultimate end customers. Sales to our ten largest customers collectively accounted for 48% and 45% of our net sales for the quarters ended April 3, 2023 and April 4, 2022, respectively. We sell to OEMs both directly and indirectly through EMS providers.

[0000950170-23-019634:mdna:11]
[same as prior period, unchanged from 0000950170-22-023197:mdna:12]

[0000950170-23-019634:mdna:12]
|  |  | Quarter Ended |  |  |
| End Markets (1) |  | April 3, 2023 |  |  |  | April 4, 2022 |  |  |
| Aerospace and Defense |  |  | 43 |  | % |  |  | 30 |  | % |
| Automotive |  |  | 17 |  |  |  |  | 20 |  |  |
| Data Center Computing |  |  | 10 |  |  |  |  | 16 |  |  |
| Medical/Industrial/Instrumentation |  |  | 19 |  |  |  |  | 21 |  |  |
| Networking |  |  | 11 |  |  |  |  | 13 |  |  |
| Total |  |  | 100 |  | % |  |  | 100 |  | % |

[0000950170-23-019634:mdna:13]
[same as prior period, unchanged from 0000950170-22-023197:mdna:14]

[0000950170-23-019634:mdna:14]
21

[0000950170-23-019634:mdna:15]
We derive revenues primarily from the sale of PCBs, engineered systems using customer-supplied engineering and design plans as well as our long-term contracts related to the design and manufacture of highly sophisticated intelligence, surveillance and communications solutions, RF and microwave/microelectronics components, assemblies, and subsystems. Orders for products generally correspond to the production schedules of our customers and are supported with firm purchase orders. Our customers have continuous control of the work in progress and finished goods throughout the PCB and engineered systems manufacturing process, as these are built to customer specifications with no alternative use, and there is an enforceable right of payment for work performed to date. As a result, we recognize revenue progressively over time based on the extent of progress towards completion of the performance obligation. We recognize revenue based on a cost method as it best depicts the transfer of control to the customer which takes place as we incur costs. Revenues are recorded proportionally as costs are incurred.

[0000950170-23-019634:mdna:16]
We also manufacture certain components, assemblies, subsystems, and completed systems which service our RF and Specialty Components (RF&S Components) customers and certain aerospace and defense customers. We recognize revenue at a point in time upon transfer of control of the products to our customer. Point in time recognition was determined as our customers do not simultaneously receive or consume the benefits provided by our performance and the asset being manufactured has alternative uses to us.

[0000950170-23-019634:mdna:17]
[same as prior period, unchanged from 0000950170-22-023197:mdna:18]

[0000950170-23-019634:mdna:18]
Cost of goods sold consists of materials, labor, outside services, and overhead expenses incurred in the manufacture and testing of our products. Shipping and handling fees and related freight costs and supplies associated with shipping products are also included as a component of cost of goods sold. Many factors affect our gross margin, including capacity utilization, product mix, production volume, supply chain issues, and yield.

[0000950170-23-019634:mdna:19]
[same as prior period, unchanged from 0000950170-22-023197:mdna:20]

[0000950170-23-019634:mdna:20]
[same as prior period, unchanged from 0000950170-22-023197:mdna:21]

[0000950170-23-019634:mdna:21]
[same as prior period, unchanged from 0000950170-22-023197:mdna:22]

[0000950170-23-019634:mdna:22]
[same as prior period, unchanged from 0000950170-22-023197:mdna:23]

[0000950170-23-019634:mdna:23]
[same as prior period, unchanged from 0000950170-22-023197:mdna:24]

[0000950170-23-019634:mdna:24]
See Item 7, Management’s Discussion and Analysis of Financial Condition and Results of Operations, in our Annual Report on Form 10-K for the fiscal year ended January 2, 2023 for further discussion of critical accounting policies and estimates.

[0000950170-23-019634:mdna:25]
[same as prior period, unchanged from 0000950170-22-023197:mdna:26]

[0000950170-23-019634:mdna:26]
[same as prior period, unchanged from 0000950170-22-023197:mdna:27]

[0000950170-23-019634:mdna:27]
|  |  | Quarter Ended |
|  |  | April 3, 2023 |  |  |  | April 4, 2022 |  |  |
| Net sales |  |  | 100.0 |  | % |  |  | 100.0 |  | % |
| Cost of goods sold |  |  | 84.2 |  |  |  |  | 84.4 |  |  |
| Gross profit |  |  | 15.8 |  |  |  |  | 15.6 |  |  |
| Operating expenses: |  |  |  |  |  |  |  |  |
| Selling and marketing |  |  | 3.9 |  |  |  |  | 3.1 |  |  |
| General and administrative |  |  | 6.4 |  |  |  |  | 5.6 |  |  |
| Research and development |  |  | 1.3 |  |  |  |  | 1.0 |  |  |
| Amortization of definite-lived intangibles |  |  | 4.0 |  |  |  |  | 1.4 |  |  |
| Restructuring charges |  |  | 0.8 |  |  |  |  | — |  |  |
| Total operating expenses |  |  | 16.4 |  |  |  |  | 11.1 |  |  |
| Operating (loss) income |  |  | (0.6 | ) |  |  |  | 4.5 |  |  |
| Other (expense) income: |  |  |  |  |  |  |  |  |
| Interest expense |  |  | (2.4 | ) |  |  |  | (2.0 | ) |  |
| Gain on sale of subsidiary |  |  | 0.2 |  |  |  |  | — |  |  |
| Other, net |  |  | 0.2 |  |  |  |  | 0.3 |  |  |
| Total other expense, net |  |  | (2.0 | ) |  |  |  | (1.7 | ) |  |
| (Loss) income before income taxes |  |  | (2.6 | ) |  |  |  | 2.8 |  |  |
| Income tax benefit |  |  | 1.5 |  |  |  |  | 0.2 |  |  |
| Net (loss) income |  |  | (1.1 | ) | % |  |  | 3.0 |  | % |

[0000950170-23-019634:mdna:28]
[same as prior period, unchanged from 0000950170-22-023197:mdna:30]

[0000950170-23-019634:mdna:29]
Total net sales decreased $36.9 million, or 6.3%, to $544.4 million for the first quarter of 2023 from $581.3 million for the first quarter of 2022. The primary driver for the decrease in total net sales was a decrease in net sales for the PCB reportable segment of $32.0 million, or 5.6%, to $534.1 million for the first quarter of 2023 from $566.1 million for the first quarter of 2022, which was primarily due to demand weakness in our commercial end markets partially offset by the inclusion of Telephonics as well as organic growth in our Aerospace and Defense end market. Net sales for the RF&S Components reportable segment decreased $4.9 million, or 32.0%, to $10.3 million for the first quarter of 2023 from $15.2 million for the first quarter of 2022, which was primarily due to lower demand in our Networking end market.

[0000950170-23-019634:mdna:30]
[same as prior period, unchanged from 0000950170-22-023197:mdna:33]

[0000950170-23-019634:mdna:31]
Overall gross margin increased to 15.8% for the first quarter of 2023 from 15.6% for the first quarter of 2022. Gross margin for the PCB reportable segment increased to 16.5% for the first quarter of 2023 from 14.7% for the first quarter of 2022. This increase was primarily due to the inclusion of Telephonics, favorable foreign exchange and better product mix partially offset by less premium revenue and production inefficiencies. Gross margin for the RF&S Components reportable segment decreased to 49.6% for the first quarter of 2023 from 57.0% for the first quarter of 2022, primarily due to lower sales.

[0000950170-23-019634:mdna:32]
Capacity utilization is a key driver for us, which is measured by the actual production as a percentage of capacity. This measure is particularly important in our high-volume facilities in Asia, as a significant portion of our operating costs are fixed in nature. Capacity utilization for the first quarter of 2023 in our Asia and North America PCB facilities was 52% and 39%, respectively, compared to 78% and 49%, respectively, for the first quarter of 2022. The decrease in capacity utilization for the first quarter of 2023 in our Asia PCB facilities was caused by a decline in production volumes while the decrease in our North America PCB facilities during the same periods was due to the additional plating capacity added.

[0000950170-23-019634:mdna:33]
[same as prior period, unchanged from 0000950170-22-023197:mdna:37]

[0000950170-23-019634:mdna:34]
Selling and marketing expense increased $3.0 million, to $21.3 million for the first quarter of 2023 from $18.3 million for the first quarter of 2022. As a percentage of net sales, selling and marketing expense was 3.9% for the first quarter of 2023, as compared to 3.1% for the first quarter of 2022. The increase in selling and marketing expense was primarily due to $2.2 million of selling and marketing expenses incurred by Telephonics post acquisition.

[0000950170-23-019634:mdna:35]
[same as prior period, unchanged from 0000950170-22-023197:mdna:40]

[0000950170-23-019634:mdna:36]
General and administrative expense increased $2.3 million to $35.1 million, or 6.4% of net sales, for the first quarter of 2023 from $32.8 million, or 5.6% of net sales, for the first quarter of 2022. The increase in expense was primarily due to $1.2 million of general and administrative expense incurred by Telephonics post acquisition as well as an increase in labor costs.

[0000950170-23-019634:mdna:37]
Research and Development Expenses

[0000950170-23-019634:mdna:38]
Research and development expense increased $1.5 million to $7.1 million, or 1.3% of net sales, for the first quarter of 2023 from $5.6 million, or 1.0% of net sales, for the first quarter of 2022. The increase in expense was primarily due to $1.3 million of research and development expense incurred by Telephonics post acquisition.

[0000950170-23-019634:mdna:39]
[same as prior period, unchanged from 0000950170-22-023197:mdna:43]

[0000950170-23-019634:mdna:40]
Other expense, net increased $0.9 million to $10.3 million for the first quarter of 2023 from $9.4 million for the first quarter of 2022. This increase was primarily the result of an increase in interest expense of $1.4 million due to higher interest rates and a decrease in other income of $0.8 million mainly due to foreign currency losses resulting from the strengthening RMB in the first quarter of 2023 compared to the first quarter of 2022. The resulting increase in other expense, net, however, was partially offset by the gain on sale of a subsidiary of $1.3 million. We utilize the RMB at our China facilities for employee-related expenses, RMB denominated purchases, and other costs of running our operations in China.

[0000950170-23-019634:mdna:41]
[same as prior period, unchanged from 0000950170-22-023197:mdna:46]

[0000950170-23-019634:mdna:42]
Income tax benefit increased by $7.1 million to $7.9 million for the first quarter of 2023 from $0.8 million for the first quarter of 2022. The increase in income tax benefit was primarily due to an increase in pre-tax loss offset by the absence in the first quarter of 2023 of certain benefits related to the renewal of the High and New Tax Enterprise status for certain of our Chinese subsidiaries.

[0000950170-23-019634:mdna:43]
Our effective tax rate is primarily impacted by the mix of foreign and U.S. income, tax rates in China and Hong Kong, the U.S. federal income tax rate, apportioned state income tax rates, the generation of credits and deductions available to the Company as well as changes in valuation allowances and certain non-deductible items. We had a net deferred income tax liability of approximately $51.1 million and a net deferred income tax asset of approximately $10.2 million as of April 3, 2023 and April 4, 2022, respectively. The decrease in the deferred income tax asset was primarily due to the recording of a full valuation allowance for the U.S. in the last quarter of 2022.

[0000950170-23-019634:mdna:44]
[same as prior period, unchanged from 0000950170-22-023197:mdna:51]

[0000950170-23-019634:mdna:45]
Our principal sources of liquidity have been cash provided by operations, the issuance of debt, and borrowings under our revolving credit facility. Our principal uses of cash have been to finance capital expenditures, finance acquisitions, fund working capital requirements, to repay debt obligations, and to repurchase common stock. We anticipate that financing capital expenditures, financing acquisitions, funding working capital requirements, servicing debt, and repurchasing common stock will be the principal demands on our cash in the future.

[0000950170-23-019634:mdna:46]
Cash flow provided by operating activities during the first quarter of 2023 was $55.1 million as compared to cash flow provided by operating activities of $36.0 million in the same period in 2022. The increase in cash flow was primarily due to an overall decreased investment in working capital.

[0000950170-23-019634:mdna:47]
Net cash provided by investing activities was approximately $9.6 million for the first quarter of 2023, primarily reflecting $34.7 million of proceeds from the sale of property associated with our Shanghai E-MS subsidiary, $5.6 million of proceeds from the sale of a subsidiary, net of cash disposed, less $31.0 million for purchases of property, plant and equipment and other assets. Net cash used in investing activities was approximately $23.4 million for the first quarter of 2022, comprised of purchases of property, plant and equipment and other assets.

[0000950170-23-019634:mdna:48]
Net cash used in financing activities during the first quarter of 2023 was $50.0 million for the repayment of long-term debt. Net cash used in financing activities during the first quarter of 2022 was $31.1 million, primarily reflecting repurchases of common stock of $30.2 million and cash used to settle warrants of $0.9 million.

[0000950170-23-019634:mdna:49]
As of April 3, 2023, we had cash and cash equivalents of approximately $417.5 million, of which approximately $243.8 million was held by our foreign subsidiaries, primarily in China. Should we choose to remit cash to the United States from our foreign locations, we may incur tax obligations which would reduce the amount of cash ultimately available to the United States. However, we believe there would be no material tax consequences not previously accrued for the repatriation of this cash.

[0000950170-23-019634:mdna:50]
Our 2023 capital expenditures are expected to be in the range of $125.0 million to $145.0 million.

[0000950170-23-019634:mdna:51]
[same as prior period, unchanged from 0000950170-22-023197:mdna:60]

[0000950170-23-019634:mdna:52]
As of April 3, 2023, we had $880.0 million of outstanding debt, net of discount and debt issuance costs, composed of $495.4 million of Senior Notes due March 2029, $354.6 million of a Term Loan due September 2024, and $30.0 million under the Asia Asset-Based Lending Credit Agreement (Asia ABL).

[0000950170-23-019634:mdna:53]
Pursuant to the terms of the Term Loan Facility and Senior Notes due 2029, we are subject to certain affirmative and negative covenants, including limitations on indebtedness, corporate transactions, investments, dispositions, and restricted payments. Under the U.S. Asset-Based Lending Credit Agreement (U.S. ABL) and Asia ABL (collectively, the ABL Revolving Loans), we are also subject to various financial covenants, including leverage and fixed charge coverage ratios. As of April 3, 2023, we were in compliance with the covenants under the Term Loan Facility, Senior Notes due 2029 and ABL Revolving Loans.

[0000950170-23-019634:mdna:54]
[same as prior period, unchanged from 0000950170-22-023197:mdna:63]

[0000950170-23-019634:mdna:55]
[same as prior period, unchanged from 0000950170-22-023197:mdna:64]

[0000950170-23-019634:mdna:56]
As part of our on-going operations, we enter into contractual arrangements that obligate us to make future cash payments. These obligations impact our liquidity and capital resource needs. Our estimated future obligations consist of long-term debt obligations, interest on debt obligations, purchase obligations, and leases as of April 3, 2023. As of the date of this report, there were no material changes outside the ordinary course of business since January 2, 2023 to our contractual obligations and commitments and the related cash requirements.

[0000950170-23-019634:mdna:57]
[same as prior period, unchanged from 0000950170-22-023197:mdna:66]

[0000950170-23-019634:mdna:58]
Following the acquisition of Telephonics on June 27, 2022, we have and may continue to enter into industrial cooperation agreements, sometimes referred to as offset agreements, as a condition to obtaining orders for our products and services from customers in foreign countries. These agreements are intended to promote investment in the applicable country, and our obligations under these agreements may be satisfied through activities that do not require us to use cash, including transferring technology or providing manufacturing and other consulting support. The obligations under these agreements may also be satisfied through the use of cash for such activities as purchasing supplies from in-country vendors, setting up support centers, research and development investments, acquisitions, and building or leasing facilities for in-country operations, if applicable. The amount of the offset requirement is determined by contract value awarded and negotiated percentages with customers. As of April 3, 2023, we had outstanding offset agreements of approximately $20.2 million, some of which extend through 2028. Offset programs usually extend over several years and in some cases provide for penalties in the event we fail to perform in accordance with contract requirements. Historically, we have not paid any such penalties, and as of April 3, 2023, no such penalties have been paid.

[0000950170-23-019634:mdna:59]
[same as prior period, unchanged from 0000950170-22-023197:mdna:68]

[0000950170-23-019634:mdna:60]
[same as prior period, unchanged from 0000950170-22-023197:mdna:69]

[0000950170-23-019634:mdna:61]
Recently Issued Accounting Standards

[0000950170-23-019634:mdna:62]
[same as prior period, unchanged from 0000950170-22-023197:mdna:71]
