# TTMI note change history — 0000950170-22-023197 → 0000950170-23-019634


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2023-05-09):
[0000950170-23-019634:note_history:1]
The Company is subject to various legal matters, which it considers normal for its business activities. While the Company currently believes that the amount of any reasonably possible loss for known matters would not be material to the Company’s financial condition, the outcome of these actions is inherently difficult to predict. In the event of an adverse outcome, the ultimate potential loss could have a material adverse effect on the Company’s financial condition or results of operations in a particular period. The Company has accrued amounts for its loss contingencies which are probable and estimable as of April 3, 2023 and January 2, 2023. However, these amounts are not material to the consolidated condensed financial statements of the Company.
  (was, 2022-11-08, similarity 0.992):
[0000950170-22-023197:note_history:1]
The Company is subject to various legal matters, which it considers normal for its business activities. While the Company currently believes that the amount of any reasonably possible loss for known matters would not be material to the Company’s financial condition, the outcome of these actions is inherently difficult to predict. In the event of an adverse outcome, the ultimate potential loss could have a material adverse effect on the Company’s financial condition or results of operations in a particular period. The Company has accrued amounts for its loss contingencies which are probable and estimable as of October 3, 2022 and January 3, 2022. However, these amounts are not material to the consolidated condensed financial statements of the Company.

- changed (2023-05-09):
[0000950170-23-019634:note_history:2]
The Company has and may continue to enter into industrial cooperation agreements, sometimes referred to as offset agreements, as a condition to obtaining orders for products and services from customers in foreign countries. These agreements are intended to promote investment in the applicable country, and the Company’s obligations under these agreements may be satisfied through activities that do not require the Company to use cash, including transferring technology or providing manufacturing and other consulting support. The obligations under these agreements may also be satisfied through the use of cash for activities such as purchasing supplies from in-country vendors, setting up support centers, research and development investments, acquisitions, and building or leasing facilities for in-country operations, if applicable. The amount of the offset requirement is determined by contract value awarded and negotiated percentages with customers. As of April 3, 2023, the Company had outstanding offset agreements of approximately $20,169, some of which extend through 2028. Offset programs usually extend over several years and in some cases provide for penalties in the event the Company fails to perform in accordance with contract requirements. Historically, the Company has not paid any such penalties, and as of April 3, 2023, no such penalties have been paid.
  (was, 2022-11-08, similarity 0.959):
[0000950170-22-023197:note_history:2]
Following the acquisition of Telephonics on June 27, 2022, the Company has and may continue to enter into industrial cooperation agreements, sometimes referred to as offset agreements, as a condition to obtaining orders for products and services from customers in foreign countries. These agreements are intended to promote investment in the applicable country, and the Company’s obligations under these agreements may be satisfied through activities that do not require the Company to use cash, including transferring technology or providing manufacturing and other consulting support. The obligations under these agreements may also be satisfied through the use of cash for activities such as purchasing supplies from in-country vendors, setting up support centers, research and development investments, acquisitions, and building or leasing facilities for in-country operations, if applicable. The amount of the offset requirement is determined by contract value awarded and negotiated percentages with customers. As of October 3, 2022, the Company had outstanding offset agreements of approximately $32,000, some of which extend through 2028. Offset programs usually extend over several years and in some cases provide for penalties in the event the Company fails to perform in accordance with contract requirements. Historically, the Company has not paid any such penalties, and as of October 3, 2022, no such penalties are estimable or probable.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureAndSignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2023-05-09):
[0000950170-23-019634:note_history:3]
TTM Technologies, Inc. (the Company or TTM) is a leading global manufacturer of technology solutions, including engineered systems, radio frequency (RF) components and RF microwave/microelectronic assemblies, and printed circuit boards (PCB). The Company provides time-to-market and volume production of advanced technology products and offers a one-stop design, engineering, and manufacturing solution to customers. This one-stop design, engineering, and manufacturing solution allows the Company to align technology developments with the diverse needs of the Company’s customers and to enable them to reduce the time required to develop new products and bring them to market.
  (was, 2022-11-08, similarity 0.9993):
[0000950170-22-023197:note_history:3]
TTM Technologies, Inc. (the Company or TTM) is a leading global manufacturer of technology solutions including engineered systems, radio frequency (RF) components and RF microwave/microelectronic assemblies, and printed circuit boards (PCB). The Company provides time-to-market and volume production of advanced technology products and offers a one-stop design, engineering, and manufacturing solution to customers. This one-stop design, engineering, and manufacturing solution allows the Company to align technology developments with the diverse needs of the Company’s customers and to enable them to reduce the time required to develop new products and bring them to market.

- changed (2023-05-09):
[0000950170-23-019634:note_history:4]
The Company serves a diversified customer base in various markets throughout the world, including aerospace and defense, data center computing, automotive, medical, industrial and instrumentation related products, as well as networking. The Company’s customers include original equipment manufacturers (OEMs), electronic manufacturing services (EMS) providers, original design manufacturers (ODMs), distributors and government agencies.
  (was, 2022-11-08, similarity 0.8407):
[0000950170-22-023197:note_history:4]
The Company serves a diversified customer base in various markets throughout the world, including aerospace and defense, data center computing, automotive components, medical, industrial and instrumentation related products, as well as networking/communications infrastructure products. The Company’s customers include both original equipment manufacturers (OEMs) and electronic manufacturing services (EMS) providers.

- added (2023-05-09):
[0000950170-23-019634:note_history:5]
The accompanying consolidated condensed financial statements have been prepared by the Company, without audit, pursuant to the rules and regulations of the Securities and Exchange Commission (SEC). Certain information and disclosures normally included in financial statements prepared in accordance with accounting principles generally accepted in the United States of America (U.S. GAAP) have been condensed or omitted pursuant to such rules and regulations. It is suggested that these consolidated condensed financial statements be read in conjunction with the consolidated financial statements and the notes thereto included in the Company’s most recent Annual Report on Form 10-K. The preparation of financial statements in accordance with U.S. GAAP requires management to make estimates and assumptions that affect the amounts reported in the Company’s consolidated condensed financial statements and accompanying notes. Due, in part, to the on-going effects of the coronavirus (COVID-19) global pandemic on the Company and the conflict between Russia and Ukraine, the global economy and financial markets have been volatile, and both the pandemic and conflict has contributed to on-going disruptions in global supply chains, labor shortages, high inflation, and a potential recession, and there is a significant amount of uncertainty about the length and severity of the direct and indirect effects of the pandemic and the conflict. The Company has considered information available to it as of the date of issuance of these financial statements and is not aware of any specific events or circumstances that would require an update to its estimates or judgments, or a revision to the carrying value of its assets or liabilities. The actual results the Company experienced may differ materially and adversely from its estimates. The Company uses a 52/53 week fiscal calendar with the fourth quarter ending on the Monday nearest December 31.

- changed (2023-05-09):
[0000950170-23-019634:note_history:6]
In September 2022, the Financial Accounting Standards Board (FASB) issued Accounting Standards Update (ASU) 2022-04, Liabilities - Supplier Finance Programs (Topic 450-50): Disclosure of Supplier Finance Program Obligations, that requires entities that use supplier finance programs in connection with the purchase of goods and services to disclose the key terms of the programs and information about obligations outstanding at the end of the reporting period, including a rollforward of those obligations. The guidance does not affect the recognition, measurement or financial statement presentation of supplier finance program obligations. The amendments are effective for all entities for fiscal years beginning after December 15, 2022 on a retrospective basis, including interim periods within those fiscal years, except for the requirement to disclose rollforward information, which is effective prospectively for fiscal years beginning after December 15, 2023. The Company adopted ASU 2022-04 as of April 3, 2023. The Company has agreements with financial institutions to facilitate the payments to certain suppliers. Under the terms of the agreements, the Company confirms the validity of each supplier invoice to the respective financial institution upon receipt. The supplier receives payment from the financial institution, and the Company pays the financial institution based on the terms negotiated, which generally range from 220 days to 360 days, with a weighted average of 290 days. Liabilities associated with these agreements are recorded in accounts payable on the consolidated condensed balance sheets and amounted to $3,565 and $6,653 as of April 3, 2023 and January 2, 2023, respectively.
  (was, 2022-11-08, similarity 0.6467):
[0000950170-22-023197:note_history:6]
In September 2022, the FASB issued ASU 2022-04, Liabilities - Supplier Finance Programs (Topic 450-50): Disclosure of Supplier Finance Program Obligations, that requires entities that use supplier finance programs in connection with the purchase of goods and services to disclose the key terms of the programs and information about obligations outstanding at the end of the reporting period, including a rollforward of those obligations. The guidance does not affect the recognition, measurement or financial statement presentation of supplier finance program obligations. The amendments are effective for all entities for fiscal years beginning after December 15, 2022 on a retrospective basis, including interim periods within those fiscal years, except for the requirement to disclose rollforward information, which is effective prospectively for fiscal years beginning after December 15, 2023. Early adoption is permitted upon issuance of the update. The Company is currently evaluating the new guidance to determine the impact it may have on its consolidated financial statements and related disclosures.

- added (2023-05-09):
[0000950170-23-019634:note_history:7]
In December 2022, the FASB issued ASU 2022-06, Reference Rate Reform (Topic 848): Deferral of the Sunset Date of Topic 848, which deferred the sunset date of Topic 848 to December 31, 2024, after which entities will no longer be permitted to apply the optional expedients and exceptions in Topic 848. On March 23, 2023, the Company entered into a four-year pay-fixed, receive floating (1-month CME Term Secured Overnight Financing Rate (SOFR)), interest rate swap arrangement with a notional amount of $250.0 million for the period beginning April 1, 2023 and ending on April 1, 2027. Under the terms of the interest rate swap, the Company pays a fixed rate of 3.49% against a portion of its LIBOR-based debt and receives a floating 1-month CME Term SOFR during the swap period. The Company elected optional expedients provided in Topic 848 which allow the designation of the interest rate swap as a cash flow hedge.

- removed (2023-05-09):
[0000950170-22-023197:note_history:8]
The accompanying consolidated condensed financial statements have been prepared by the Company, without audit, pursuant to the rules and regulations of the Securities and Exchange Commission (SEC). Certain information and disclosures normally included in financial statements prepared in accordance with accounting principles generally accepted in the United States of America (U.S. GAAP) have been condensed or omitted pursuant to such rules and regulations. It is suggested that these consolidated condensed financial statements be read in conjunction with the consolidated financial statements and the notes thereto included in the Company’s most recent Annual Report on Form 10-K. The preparation of financial statements in accordance with U.S. GAAP requires management to make estimates and assumptions that affect the amounts reported in the Company’s consolidated condensed financial statements and accompanying notes. Due, in part, to the coronavirus (COVID-19) global pandemic and the conflict between Russia and Ukraine, the global economy and financial markets have been volatile, and both the pandemic and conflict has contributed to on-going disruptions in global supply chains, labor shortages, high inflation, and a potential recession, and there is a significant amount of uncertainty about the length and severity of the direct and indirect effects of the pandemic and the conflict. The Company has considered information available to it as of the date of issuance of these financial statements and is not aware of any specific events or circumstances that would require an update to its estimates or judgments, or a revision to the carrying value of its assets or liabilities. Actual results could differ materially from those estimates. The Company uses a 52/53 week fiscal calendar with the fourth quarter ending on the Monday nearest December 31.

- removed (2023-05-09):
[0000950170-22-023197:note_history:9]
In October 2021, the Financial Accounting Standards Board (FASB) issued Accounting Standards Update (ASU) 2021-08, Business Combinations (Topic 805): Accounting for Contract Assets and Contract Liabilities from Contracts with Customers, which requires that an acquirer recognize and measure contract assets and contract liabilities acquired in a business combination in accordance with Accounting Standards Codification (ASC) 606, Revenue from Contracts with Customers, as if it had originated the contracts. Prior to this ASU, an acquirer generally recognizes contract assets acquired and contract liabilities assumed that arose from contracts with customers at fair value on the acquisition date. The ASU is effective for fiscal years beginning after December 15, 2022, with early adoption permitted. The ASU is to be applied prospectively to business combinations occurring on or after the effective date of the amendment (or if adopted early as of an interim period, as of the beginning of the fiscal year that includes the interim period of early application). The Company early adopted ASU 2021-08 on April 4, 2022 and did not have an impact on its consolidated condensed financial statements and related disclosures. The new guidance was applied to the acquisition of Gritel Holding Co., Inc. (Gritel), ISC Farmingdale Corp., and Gritel's wholly owned subsidiary, Telephonics Corporation.

- removed (2023-05-09):
[0000950170-22-023197:note_history:10]
Recently Issued Accounting Standards Not Yet Adopted

- removed (2023-05-09):
[0000950170-22-023197:note_history:11]
In November 2021, the FASB issued ASU 2021-10, Government Assistance (Topic 832): Disclosures by Business Entities about Government Assistance, which provides guidance on disclosures for transactions with a government that are accounted for by applying a grant or contribution accounting model by analogy. The guidance is effective for annual periods beginning after December 15, 2021. Early adoption is permitted. The Company does not anticipate the adoption will have a material impact on the consolidated financial statements and related disclosures.


## ttmi:ScheduleOfUnamortizedDiscountAndDebtIssuanceCostsTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2023-05-09):
[0000950170-23-019634:note_history:12]
As of April 3, 2023 and January 2, 2023, remaining unamortized debt discount and debt issuance costs for the Senior Notes due 2029 and Term Loan Facility are as follows:
  (was, 2022-11-08, similarity 0.9684):
[0000950170-22-023197:note_history:12]
As of October 3, 2022 and January 3, 2022, remaining unamortized debt discount and debt issuance costs for the Senior Notes due 2029 and Term Loan Facility are as follows:

- changed (2023-05-09):
[0000950170-23-019634:note_history:13]
|  |  | As of April 3, 2023 |  |  | As of January 2, 2023 |
|  |  | DebtIssuance Costs |  |  | DebtDiscount |  |  | EffectiveInterest Rate |  |  | DebtIssuance Costs |  |  | DebtDiscount |  |  | EffectiveInterest Rate |  |  |
|  |  | (In thousands, except interest rates) |
| Senior Notes due March 2029 |  | $ | 4,608 |  |  | $ | — |  |  |  | 4.18 |  | % | $ | 4,779 |  |  | $ | — |  |  |  | 4.18 |  | % |
| Term Loan due September 2024 |  |  | 981 |  |  |  | 297 |  |  |  | 4.66 |  |  |  | 1,301 |  |  |  | 392 |  |  |  | 4.66 |  |  |
|  |  | $ | 5,589 |  |  | $ | 297 |  |  |  |  |  | $ | 6,080 |  |  | $ | 392 |  |  |  |  |  |
  (was, 2022-11-08, similarity 0.9882):
[0000950170-22-023197:note_history:13]
|  |  | As of October 3, 2022 |  |  | As of January 3, 2022 |
|  |  | DebtIssuance Costs |  |  | DebtDiscount |  |  | EffectiveInterest Rate |  |  | DebtIssuance Costs |  |  | DebtDiscount |  |  | EffectiveInterest Rate |  |  |
|  |  | (In thousands, except interest rates) |
| Senior Notes due March 2029 |  | $ | 4,947 |  |  | $ | — |  |  |  | 4.18 |  | % | $ | 5,444 |  |  | $ | — |  |  |  | 4.18 |  | % |
| Term Loan due September 2024 |  |  | 1,480 |  |  |  | 448 |  |  |  | 4.66 |  |  |  | 2,010 |  |  |  | 607 |  |  |  | 4.66 |  |  |
|  |  | $ | 6,427 |  |  | $ | 448 |  |  |  |  |  | $ | 7,454 |  |  | $ | 607 |  |  |  |  |  |


## us-gaap:LongTermDebtTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2023-05-09):
[0000950170-23-019634:note_history:14]
The following table summarizes the long-term debt of the Company as of April 3, 2023 and January 2, 2023:
  (was, 2022-11-08, similarity 0.949):
[0000950170-22-023197:note_history:14]
The following table summarizes the long-term debt of the Company as of October 3, 2022 and January 3, 2022:

- changed (2023-05-09):
[0000950170-23-019634:note_history:15]
|  |  | Interest Rate as ofApril 3, 2023 |  |  |  | PrincipalOutstandingas ofApril 3, 2023 |  |  | Interest Rate as ofJanuary 2, 2023 |  |  |  | PrincipalOutstandingas ofJanuary 2, 2023 |  |
|  |  | (In thousands, except interest rates) |  |
| Senior Notes due March 2029 |  |  | 4.00 |  | % |  | $ | 500,000 |  |  |  | 4.00 |  | % |  | $ | 500,000 |  |
| Term Loan due September 2024 |  |  | 7.36 |  |  |  |  | 355,879 |  |  |  | 6.89 |  |  |  |  | 405,879 |  |
| Asia ABL Revolving Loan due June 2024 |  |  | 6.26 |  |  |  |  | 30,000 |  |  |  | 5.79 |  |  |  |  | 30,000 |  |
|  |  |  |  |  |  |  | 885,879 |  |  |  |  |  |  |  | 935,879 |  |
| Less: Long-term debt unamortized debt issuance costs |  |  |  |  |  |  | (5,589 | ) |  |  |  |  |  |  | (6,080 | ) |
| Long-term debt unamortized discount |  |  |  |  |  |  | (297 | ) |  |  |  |  |  |  | (392 | ) |
|  |  |  |  |  |  |  | 879,993 |  |  |  |  |  |  |  | 929,407 |  |
| Less: current maturities |  |  |  |  |  |  | — |  |  |  |  |  |  |  | (50,000 | ) |
| Long-term debt, less current maturities |  |  |  |  |  | $ | 879,993 |  |  |  |  |  |  | $ | 879,407 |  |
  (was, 2022-11-08, similarity 0.9333):
[0000950170-22-023197:note_history:15]
|  |  | Interest Rate as ofOctober 3, 2022 |  |  |  | PrincipalOutstandingas ofOctober 3, 2022 |  |  | Interest Rate as ofJanuary 3, 2022 |  |  |  | PrincipalOutstandingas ofJanuary 3, 2022 |  |
|  |  | (In thousands, except interest rates) |  |
| Senior Notes due March 2029 |  |  | 4.00 |  | % |  | $ | 500,000 |  |  |  | 4.00 |  | % |  | $ | 500,000 |  |
| Term Loan due September 2024 |  |  | 5.67 |  |  |  |  | 405,879 |  |  |  | 2.60 |  |  |  |  | 405,879 |  |
| Asia ABL Revolving Loan due June 2024 |  |  | 4.57 |  |  |  |  | 30,000 |  |  |  | 1.50 |  |  |  |  | 30,000 |  |
|  |  |  |  |  |  |  | 935,879 |  |  |  |  |  |  |  | 935,879 |  |
| Less: Long-term debt unamortized discount |  |  |  |  |  |  | (448 | ) |  |  |  |  |  |  | (607 | ) |
| Long-term debt unamortized debt issuance costs |  |  |  |  |  |  | (6,427 | ) |  |  |  |  |  |  | (7,454 | ) |
|  |  |  |  |  |  |  | 929,004 |  |  |  |  |  |  |  | 927,818 |  |
| Less: current maturities |  |  |  |  |  |  | — |  |  |  |  |  |  |  | — |  |
| Long-term debt, less current maturities |  |  |  |  |  | $ | 929,004 |  |  |  |  |  |  | $ | 927,818 |  |

- changed (2023-05-09):
[0000950170-23-019634:note_history:16]
Borrowings under the Senior Notes due 2029 and Term Loan Facility are subject to certain affirmative and negative covenants, including limitations on indebtedness, corporate transactions, investments, dispositions, and restricted payments.
  (was, 2022-11-08, similarity 0.9679):
[0000950170-22-023197:note_history:16]
Borrowings under the Senior Notes due 2029 and Term Loan Facility are subject to certain affirmative and negative covenants, including limitations on indebtedness, corporate transactions, investments, dispositions, and share payments.

- changed (2023-05-09):
[0000950170-23-019634:note_history:17]
As of April 3, 2023 and January 2, 2023, remaining unamortized debt discount and debt issuance costs for the Senior Notes due 2029 and Term Loan Facility are as follows:
  (was, 2022-11-08, similarity 0.9684):
[0000950170-22-023197:note_history:17]
As of October 3, 2022 and January 3, 2022, remaining unamortized debt discount and debt issuance costs for the Senior Notes due 2029 and Term Loan Facility are as follows:

- changed (2023-05-09):
[0000950170-23-019634:note_history:18]
|  |  | As of April 3, 2023 |  |  | As of January 2, 2023 |
|  |  | DebtIssuance Costs |  |  | DebtDiscount |  |  | EffectiveInterest Rate |  |  | DebtIssuance Costs |  |  | DebtDiscount |  |  | EffectiveInterest Rate |  |  |
|  |  | (In thousands, except interest rates) |
| Senior Notes due March 2029 |  | $ | 4,608 |  |  | $ | — |  |  |  | 4.18 |  | % | $ | 4,779 |  |  | $ | — |  |  |  | 4.18 |  | % |
| Term Loan due September 2024 |  |  | 981 |  |  |  | 297 |  |  |  | 4.66 |  |  |  | 1,301 |  |  |  | 392 |  |  |  | 4.66 |  |  |
|  |  | $ | 5,589 |  |  | $ | 297 |  |  |  |  |  | $ | 6,080 |  |  | $ | 392 |  |  |  |  |  |
  (was, 2022-11-08, similarity 0.9882):
[0000950170-22-023197:note_history:18]
|  |  | As of October 3, 2022 |  |  | As of January 3, 2022 |
|  |  | DebtIssuance Costs |  |  | DebtDiscount |  |  | EffectiveInterest Rate |  |  | DebtIssuance Costs |  |  | DebtDiscount |  |  | EffectiveInterest Rate |  |  |
|  |  | (In thousands, except interest rates) |
| Senior Notes due March 2029 |  | $ | 4,947 |  |  | $ | — |  |  |  | 4.18 |  | % | $ | 5,444 |  |  | $ | — |  |  |  | 4.18 |  | % |
| Term Loan due September 2024 |  |  | 1,480 |  |  |  | 448 |  |  |  | 4.66 |  |  |  | 2,010 |  |  |  | 607 |  |  |  | 4.66 |  |  |
|  |  | $ | 6,427 |  |  | $ | 448 |  |  |  |  |  | $ | 7,454 |  |  | $ | 607 |  |  |  |  |  |

- changed (2023-05-09):
[0000950170-23-019634:note_history:19]
The remaining unamortized debt issuance costs for the ABL Revolving Loans of $652 and $792 as of April 3, 2023 and January 2, 2023, respectively, are included in other non-current assets and are amortized to interest expense over the duration of the ABL Revolving Loans using the straight-line method of amortization.
  (was, 2022-11-08, similarity 0.9736):
[0000950170-22-023197:note_history:19]
Remaining unamortized debt issuance costs for the ABL Revolving Loans of $933 and $1,355 as of October 3, 2022 and January 3, 2022, respectively, are included in other non-current assets and are amortized to interest expense over the duration of the ABL Revolving Loans using the straight-line method of amortization.

- changed (2023-05-09):
[0000950170-23-019634:note_history:20]
As of April 3, 2023, the remaining weighted average amortization period for all unamortized debt discount and debt issuance costs was 4.6 years.
  (was, 2022-11-08, similarity 0.9638):
[0000950170-22-023197:note_history:20]
As of October 3, 2022, the remaining weighted average amortization period for all unamortized debt discount and debt issuance costs was 4.8 years.

- removed (2023-05-09):
[0000950170-22-023197:note_history:21]
Loss on Extinguishment of Debt

- removed (2023-05-09):
[0000950170-22-023197:note_history:22]
During the three quarters ended September 27, 2021, the Company recognized losses of $15,217 associated with the premium paid on extinguishment of debt and the write-off of the remaining unamortized debt issuance costs as a result of the repayment of the remaining outstanding balance of the Senior Notes due 2025.


## us-gaap:ScheduleOfDebtInstrumentsTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2023-05-09):
[0000950170-23-019634:note_history:23]
The following table summarizes the long-term debt of the Company as of April 3, 2023 and January 2, 2023:
  (was, 2022-11-08, similarity 0.949):
[0000950170-22-023197:note_history:23]
The following table summarizes the long-term debt of the Company as of October 3, 2022 and January 3, 2022:

- changed (2023-05-09):
[0000950170-23-019634:note_history:24]
|  |  | Interest Rate as ofApril 3, 2023 |  |  |  | PrincipalOutstandingas ofApril 3, 2023 |  |  | Interest Rate as ofJanuary 2, 2023 |  |  |  | PrincipalOutstandingas ofJanuary 2, 2023 |  |
|  |  | (In thousands, except interest rates) |  |
| Senior Notes due March 2029 |  |  | 4.00 |  | % |  | $ | 500,000 |  |  |  | 4.00 |  | % |  | $ | 500,000 |  |
| Term Loan due September 2024 |  |  | 7.36 |  |  |  |  | 355,879 |  |  |  | 6.89 |  |  |  |  | 405,879 |  |
| Asia ABL Revolving Loan due June 2024 |  |  | 6.26 |  |  |  |  | 30,000 |  |  |  | 5.79 |  |  |  |  | 30,000 |  |
|  |  |  |  |  |  |  | 885,879 |  |  |  |  |  |  |  | 935,879 |  |
| Less: Long-term debt unamortized debt issuance costs |  |  |  |  |  |  | (5,589 | ) |  |  |  |  |  |  | (6,080 | ) |
| Long-term debt unamortized discount |  |  |  |  |  |  | (297 | ) |  |  |  |  |  |  | (392 | ) |
|  |  |  |  |  |  |  | 879,993 |  |  |  |  |  |  |  | 929,407 |  |
| Less: current maturities |  |  |  |  |  |  | — |  |  |  |  |  |  |  | (50,000 | ) |
| Long-term debt, less current maturities |  |  |  |  |  | $ | 879,993 |  |  |  |  |  |  | $ | 879,407 |  |
  (was, 2022-11-08, similarity 0.9333):
[0000950170-22-023197:note_history:24]
|  |  | Interest Rate as ofOctober 3, 2022 |  |  |  | PrincipalOutstandingas ofOctober 3, 2022 |  |  | Interest Rate as ofJanuary 3, 2022 |  |  |  | PrincipalOutstandingas ofJanuary 3, 2022 |  |
|  |  | (In thousands, except interest rates) |  |
| Senior Notes due March 2029 |  |  | 4.00 |  | % |  | $ | 500,000 |  |  |  | 4.00 |  | % |  | $ | 500,000 |  |
| Term Loan due September 2024 |  |  | 5.67 |  |  |  |  | 405,879 |  |  |  | 2.60 |  |  |  |  | 405,879 |  |
| Asia ABL Revolving Loan due June 2024 |  |  | 4.57 |  |  |  |  | 30,000 |  |  |  | 1.50 |  |  |  |  | 30,000 |  |
|  |  |  |  |  |  |  | 935,879 |  |  |  |  |  |  |  | 935,879 |  |
| Less: Long-term debt unamortized discount |  |  |  |  |  |  | (448 | ) |  |  |  |  |  |  | (607 | ) |
| Long-term debt unamortized debt issuance costs |  |  |  |  |  |  | (6,427 | ) |  |  |  |  |  |  | (7,454 | ) |
|  |  |  |  |  |  |  | 929,004 |  |  |  |  |  |  |  | 927,818 |  |
| Less: current maturities |  |  |  |  |  |  | — |  |  |  |  |  |  |  | — |  |
| Long-term debt, less current maturities |  |  |  |  |  | $ | 929,004 |  |  |  |  |  |  | $ | 927,818 |  |


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2023-05-09):
[0000950170-23-019634:note_history:25]
|  |  | Quarter Ended April 3, 2023 |  |  |
|  |  | PCB |  |  | RF&S Components |  |  | Total |  |  |
| End Markets |  | (In thousands) |
| Aerospace and Defense |  | $ | 232,292 |  |  | $ | — |  |  | $ | 232,292 |  |  |
| Automotive |  |  | 93,467 |  |  |  | — |  |  |  | 93,467 |  |  |
| Data Center Computing |  |  | 57,870 |  |  |  | — |  |  |  | 57,870 |  |  |
| Medical/Industrial/Instrumentation |  |  | 100,768 |  |  |  | 917 |  |  |  | 101,685 |  |  |
| Networking |  |  | 49,714 |  |  |  | 9,409 |  |  |  | 59,123 |  |  |
| Total |  | $ | 534,111 |  |  | $ | 10,326 |  |  | $ | 544,437 |  |  |
  (was, 2022-11-08, similarity 0.6501):
[0000950170-22-023197:note_history:25]
|  |  | Quarter Ended October 3, 2022 |  |  | Quarter Ended September 27, 2021 |  |  |
|  |  | PCB |  |  | RF&S Components |  |  | Other (1) |  |  | Total |  |  | PCB |  |  | RF&S Components |  |  | Total |  |  |
| End Markets |  | (In thousands) |  |  |
| Aerospace and Defense |  | $ | 186,030 |  |  | $ | — |  |  | $ | 68,255 |  |  | $ | 254,285 |  |  | $ | 173,894 |  |  | $ | 12 |  |  | $ | 173,906 |  |  |
| Automotive |  |  | 100,811 |  |  |  | — |  |  |  | — |  |  |  | 100,811 |  |  |  | 99,205 |  |  |  | — |  |  |  | 99,205 |  |  |
| Data Center Computing |  |  | 95,830 |  |  |  | 13 |  |  |  | — |  |  |  | 95,843 |  |  |  | 81,202 |  |  |  | — |  |  |  | 81,202 |  |  |
| Medical/Industrial/Instrumentation |  |  | 128,444 |  |  |  | 1,239 |  |  |  | — |  |  |  | 129,683 |  |  |  | 108,879 |  |  |  | 1,467 |  |  |  | 110,346 |  |  |
| Networking/Communications |  |  | 78,181 |  |  |  | 12,494 |  |  |  | — |  |  |  | 90,675 |  |  |  | 74,316 |  |  |  | 12,848 |  |  |  | 87,164 |  |  |
| Other |  |  | (376 | ) |  |  | 159 |  |  |  | — |  |  |  | (217 | ) |  |  | 3,622 |  |  |  | 1,339 |  |  |  | 4,961 |  |  |
| Total |  | $ | 588,920 |  |  | $ | 13,905 |  |  | $ | 68,255 |  |  | $ | 671,080 |  |  | $ | 541,118 |  |  | $ | 15,666 |  |  | $ | 556,784 |  |  |

- changed (2023-05-09):
[0000950170-23-019634:note_history:26]
|  |  | Quarter Ended April 4, 2022 |  |  |
|  |  | PCB |  |  | RF&S Components |  |  | Total |  |  |
| End Markets |  | (In thousands) |
| Aerospace and Defense |  | $ | 172,180 |  |  | $ | — |  |  | $ | 172,180 |  |  |
| Automotive |  |  | 115,236 |  |  |  | — |  |  |  | 115,236 |  |  |
| Data Center Computing |  |  | 91,784 |  |  |  | — |  |  |  | 91,784 |  |  |
| Medical/Industrial/Instrumentation |  |  | 120,362 |  |  |  | 1,538 |  |  |  | 121,900 |  |  |
| Networking |  |  | 63,643 |  |  |  | 13,757 |  |  |  | 77,400 |  |  |
| Other |  |  | 2,865 |  |  |  | (105 | ) |  |  | 2,760 |  |  |
| Total |  | $ | 566,070 |  |  | $ | 15,190 |  |  | $ | 581,260 |  |  |
  (was, 2022-11-08, similarity 0.6323):
[0000950170-22-023197:note_history:26]
|  |  | Three Quarters Ended October 3, 2022 |  |  | Three Quarters Ended September 27, 2021 |  |  |
|  |  | PCB |  |  | RF&S Components |  |  |  | Other (1) |  |  | Total |  |  | PCB |  |  | RF&S Components |  |  | Other (1) |  |  | Total |  |  |
| End Markets |  | (In thousands) |  |  |
| Aerospace and Defense |  | $ | 547,886 |  |  | $ | — |  |  |  | $ | 68,255 |  |  | $ | 616,141 |  |  | $ | 545,585 |  |  | $ | 24 |  |  | $ | — |  |  | $ | 545,609 |  |  |
| Automotive |  |  | 327,825 |  |  |  | — |  |  |  |  | — |  |  |  | 327,825 |  |  |  | 293,890 |  |  |  | — |  |  |  | 3,642 |  |  |  | 297,532 |  |  |
| Data Center Computing |  |  | 293,802 |  |  |  | 33 |  |  |  |  | — |  |  |  | 293,835 |  |  |  | 235,191 |  |  |  | 456 |  |  |  | — |  |  |  | 235,647 |  |  |
| Medical/Industrial/Instrumentation |  |  | 379,867 |  |  |  | 5,023 |  |  |  |  | — |  |  |  | 384,890 |  |  |  | 303,661 |  |  |  | 3,615 |  |  |  | 25 |  |  |  | 307,301 |  |  |
| Networking/Communications |  |  | 211,590 |  |  |  | 41,360 |  |  |  |  | — |  |  |  | 252,950 |  |  |  | 216,982 |  |  |  | 35,451 |  |  |  | 1 |  |  |  | 252,434 |  |  |
| Other |  |  | 3,449 |  |  |  | (1,200 | ) |  |  |  | — |  |  |  | 2,249 |  |  |  | 9,775 |  |  |  | 2,713 |  |  |  | (412 | ) |  |  | 12,076 |  |  |
| Total |  | $ | 1,764,419 |  |  | $ | 45,216 |  |  |  | $ | 68,255 |  |  | $ | 1,877,890 |  |  | $ | 1,605,084 |  |  | $ | 42,259 |  |  | $ | 3,256 |  |  | $ | 1,650,599 |  |  |

- removed (2023-05-09):
[0000950170-22-023197:note_history:27]
(1)
Other represents results from Telephonics for the quarter and three quarters ended October 3, 2022 and from the now closed Shanghai (SH E-MS) and Shenzhen (SZ) facilities previously utilized by the Company's former E-M Solutions business unit for the three quarters ended September 27, 2021.


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2023-05-09):
[0000950170-23-019634:note_history:28]
As of April 3, 2023, the aggregate amount of the transaction price allocated to remaining performance obligations for long-term contracts was $378,829. The Company expects to recognize revenue on approximately 52% of the remaining performance obligations for the Company’s long-term contracts over the next twelve months with the remaining amount expected to be recognized thereafter.
  (was, 2022-11-08, similarity 0.8899):
[0000950170-22-023197:note_history:28]
As of October 3, 2022, the aggregate amount of the transaction price allocated to remaining performance obligations for long-term contracts was $303,046. The Company expects to recognize revenue on approximately 64% of the remaining performance obligations for the Company’s long-term contracts over the next twelve months.

- added (2023-05-09):
[0000950170-23-019634:note_history:29]
For contracts in which anticipated total costs exceed the total expected revenue, an estimated loss is recognized in the period when identifiable. A provision for the entire amount of the estimated loss is recorded on a cumulative basis. The estimated remaining costs to complete for loss contracts as of April 3, 2023 and January 2, 2023 were $20,641 and $21,632, respectively.

- added (2023-05-09):
[0000950170-23-019634:note_history:30]
Revenue recognized for the quarter ended April 3, 2023 from amounts recorded as contract liabilities as of January 2, 2023 was $18,508.

- changed (2023-05-09):
[0000950170-23-019634:note_history:31]
Revenue from products and services transferred to customers over time and at a point in time accounted for 96% and 4%, respectively, of the Company’s revenue for the quarter ended April 3, 2023, and 97% and 3%, respectively, of the Company’s revenue for the quarter ended April 4, 2022.
  (was, 2022-11-08, similarity 0.8378):
[0000950170-22-023197:note_history:31]
Revenue from products and services transferred to customers over time and at a point in time accounted for 98% and 2%, respectively, of the Company’s revenue for the quarter and three quarters ended October 3, 2022, and 97% and 3%, respectively, of the Company’s revenue for the quarter and three quarters ended September 27, 2021.

- changed (2023-05-09):
[0000950170-23-019634:note_history:32]
|  |  | Quarter Ended April 3, 2023 |  |  |
|  |  | PCB |  |  | RF&S Components |  |  | Total |  |  |
| End Markets |  | (In thousands) |
| Aerospace and Defense |  | $ | 232,292 |  |  | $ | — |  |  | $ | 232,292 |  |  |
| Automotive |  |  | 93,467 |  |  |  | — |  |  |  | 93,467 |  |  |
| Data Center Computing |  |  | 57,870 |  |  |  | — |  |  |  | 57,870 |  |  |
| Medical/Industrial/Instrumentation |  |  | 100,768 |  |  |  | 917 |  |  |  | 101,685 |  |  |
| Networking |  |  | 49,714 |  |  |  | 9,409 |  |  |  | 59,123 |  |  |
| Total |  | $ | 534,111 |  |  | $ | 10,326 |  |  | $ | 544,437 |  |  |
  (was, 2022-11-08, similarity 0.6501):
[0000950170-22-023197:note_history:32]
|  |  | Quarter Ended October 3, 2022 |  |  | Quarter Ended September 27, 2021 |  |  |
|  |  | PCB |  |  | RF&S Components |  |  | Other (1) |  |  | Total |  |  | PCB |  |  | RF&S Components |  |  | Total |  |  |
| End Markets |  | (In thousands) |  |  |
| Aerospace and Defense |  | $ | 186,030 |  |  | $ | — |  |  | $ | 68,255 |  |  | $ | 254,285 |  |  | $ | 173,894 |  |  | $ | 12 |  |  | $ | 173,906 |  |  |
| Automotive |  |  | 100,811 |  |  |  | — |  |  |  | — |  |  |  | 100,811 |  |  |  | 99,205 |  |  |  | — |  |  |  | 99,205 |  |  |
| Data Center Computing |  |  | 95,830 |  |  |  | 13 |  |  |  | — |  |  |  | 95,843 |  |  |  | 81,202 |  |  |  | — |  |  |  | 81,202 |  |  |
| Medical/Industrial/Instrumentation |  |  | 128,444 |  |  |  | 1,239 |  |  |  | — |  |  |  | 129,683 |  |  |  | 108,879 |  |  |  | 1,467 |  |  |  | 110,346 |  |  |
| Networking/Communications |  |  | 78,181 |  |  |  | 12,494 |  |  |  | — |  |  |  | 90,675 |  |  |  | 74,316 |  |  |  | 12,848 |  |  |  | 87,164 |  |  |
| Other |  |  | (376 | ) |  |  | 159 |  |  |  | — |  |  |  | (217 | ) |  |  | 3,622 |  |  |  | 1,339 |  |  |  | 4,961 |  |  |
| Total |  | $ | 588,920 |  |  | $ | 13,905 |  |  | $ | 68,255 |  |  | $ | 671,080 |  |  | $ | 541,118 |  |  | $ | 15,666 |  |  | $ | 556,784 |  |  |

- changed (2023-05-09):
[0000950170-23-019634:note_history:33]
|  |  | Quarter Ended April 4, 2022 |  |  |
|  |  | PCB |  |  | RF&S Components |  |  | Total |  |  |
| End Markets |  | (In thousands) |
| Aerospace and Defense |  | $ | 172,180 |  |  | $ | — |  |  | $ | 172,180 |  |  |
| Automotive |  |  | 115,236 |  |  |  | — |  |  |  | 115,236 |  |  |
| Data Center Computing |  |  | 91,784 |  |  |  | — |  |  |  | 91,784 |  |  |
| Medical/Industrial/Instrumentation |  |  | 120,362 |  |  |  | 1,538 |  |  |  | 121,900 |  |  |
| Networking |  |  | 63,643 |  |  |  | 13,757 |  |  |  | 77,400 |  |  |
| Other |  |  | 2,865 |  |  |  | (105 | ) |  |  | 2,760 |  |  |
| Total |  | $ | 566,070 |  |  | $ | 15,190 |  |  | $ | 581,260 |  |  |
  (was, 2022-11-08, similarity 0.6323):
[0000950170-22-023197:note_history:33]
|  |  | Three Quarters Ended October 3, 2022 |  |  | Three Quarters Ended September 27, 2021 |  |  |
|  |  | PCB |  |  | RF&S Components |  |  |  | Other (1) |  |  | Total |  |  | PCB |  |  | RF&S Components |  |  | Other (1) |  |  | Total |  |  |
| End Markets |  | (In thousands) |  |  |
| Aerospace and Defense |  | $ | 547,886 |  |  | $ | — |  |  |  | $ | 68,255 |  |  | $ | 616,141 |  |  | $ | 545,585 |  |  | $ | 24 |  |  | $ | — |  |  | $ | 545,609 |  |  |
| Automotive |  |  | 327,825 |  |  |  | — |  |  |  |  | — |  |  |  | 327,825 |  |  |  | 293,890 |  |  |  | — |  |  |  | 3,642 |  |  |  | 297,532 |  |  |
| Data Center Computing |  |  | 293,802 |  |  |  | 33 |  |  |  |  | — |  |  |  | 293,835 |  |  |  | 235,191 |  |  |  | 456 |  |  |  | — |  |  |  | 235,647 |  |  |
| Medical/Industrial/Instrumentation |  |  | 379,867 |  |  |  | 5,023 |  |  |  |  | — |  |  |  | 384,890 |  |  |  | 303,661 |  |  |  | 3,615 |  |  |  | 25 |  |  |  | 307,301 |  |  |
| Networking/Communications |  |  | 211,590 |  |  |  | 41,360 |  |  |  |  | — |  |  |  | 252,950 |  |  |  | 216,982 |  |  |  | 35,451 |  |  |  | 1 |  |  |  | 252,434 |  |  |
| Other |  |  | 3,449 |  |  |  | (1,200 | ) |  |  |  | — |  |  |  | 2,249 |  |  |  | 9,775 |  |  |  | 2,713 |  |  |  | (412 | ) |  |  | 12,076 |  |  |
| Total |  | $ | 1,764,419 |  |  | $ | 45,216 |  |  |  | $ | 68,255 |  |  | $ | 1,877,890 |  |  | $ | 1,605,084 |  |  | $ | 42,259 |  |  | $ | 3,256 |  |  | $ | 1,650,599 |  |  |

- removed (2023-05-09):
[0000950170-22-023197:note_history:34]
(1)
Other represents results from Telephonics for the quarter and three quarters ended October 3, 2022 and from the now closed Shanghai (SH E-MS) and Shenzhen (SZ) facilities previously utilized by the Company's former E-M Solutions business unit for the three quarters ended September 27, 2021.


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: no_prior_note, score: 0.0

- added (2023-05-09):
[0000950170-23-019634:note_history:35]
(18) Subsequent Events

- added (2023-05-09):
[0000950170-23-019634:note_history:36]
On May 3, 2023, the Company announced that its Board of Directors authorized and approved a share repurchase program. Under the program, the Company may repurchase up to $100,000 in value of the Company’s outstanding shares of common stock from time to time through May 3, 2025. The Company may repurchase shares through open market purchases, privately-negotiated transactions, or otherwise in accordance with applicable federal securities laws, including Rule 10b-18 of the Securities Exchange Act of 1934, as amended (Exchange Act) which sets certain restrictions on the method, timing, price and volume of open market stock repurchases. In addition, the Company expects to adopt one or more trading plans in accordance with Rule 10b5-1 of the Exchange Act to facilitate certain purchases that may be effected under the share repurchase program. The timing, manner, price and amount of any repurchases will be determined at the Company’s discretion, and the share repurchase program may be suspended, terminated or modified at any time for any reason. The repurchase program does not obligate the Company to acquire any specific number of shares.
