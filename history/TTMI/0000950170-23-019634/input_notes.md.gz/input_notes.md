# TTMI notes — 0000950170-23-019634


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureAndSignificantAccountingPoliciesTextBlock

[0000950170-23-019634:notes:1]
[same as prior period, unchanged from 0000950170-22-023197:notes:1]

[0000950170-23-019634:notes:2]
TTM Technologies, Inc. (the Company or TTM) is a leading global manufacturer of technology solutions, including engineered systems, radio frequency (RF) components and RF microwave/microelectronic assemblies, and printed circuit boards (PCB). The Company provides time-to-market and volume production of advanced technology products and offers a one-stop design, engineering, and manufacturing solution to customers. This one-stop design, engineering, and manufacturing solution allows the Company to align technology developments with the diverse needs of the Company’s customers and to enable them to reduce the time required to develop new products and bring them to market.

[0000950170-23-019634:notes:3]
The Company serves a diversified customer base in various markets throughout the world, including aerospace and defense, data center computing, automotive, medical, industrial and instrumentation related products, as well as networking. The Company’s customers include original equipment manufacturers (OEMs), electronic manufacturing services (EMS) providers, original design manufacturers (ODMs), distributors and government agencies.

[0000950170-23-019634:notes:4]
The accompanying consolidated condensed financial statements have been prepared by the Company, without audit, pursuant to the rules and regulations of the Securities and Exchange Commission (SEC). Certain information and disclosures normally included in financial statements prepared in accordance with accounting principles generally accepted in the United States of America (U.S. GAAP) have been condensed or omitted pursuant to such rules and regulations. It is suggested that these consolidated condensed financial statements be read in conjunction with the consolidated financial statements and the notes thereto included in the Company’s most recent Annual Report on Form 10-K. The preparation of financial statements in accordance with U.S. GAAP requires management to make estimates and assumptions that affect the amounts reported in the Company’s consolidated condensed financial statements and accompanying notes. Due, in part, to the on-going effects of the coronavirus (COVID-19) global pandemic on the Company and the conflict between Russia and Ukraine, the global economy and financial markets have been volatile, and both the pandemic and conflict has contributed to on-going disruptions in global supply chains, labor shortages, high inflation, and a potential recession, and there is a significant amount of uncertainty about the length and severity of the direct and indirect effects of the pandemic and the conflict. The Company has considered information available to it as of the date of issuance of these financial statements and is not aware of any specific events or circumstances that would require an update to its estimates or judgments, or a revision to the carrying value of its assets or liabilities. The actual results the Company experienced may differ materially and adversely from its estimates. The Company uses a 52/53 week fiscal calendar with the fourth quarter ending on the Monday nearest December 31.

[0000950170-23-019634:notes:5]
[same as prior period, unchanged from 0000950170-22-023197:notes:5]

[0000950170-23-019634:notes:6]
Recently Adopted Accounting Standards

[0000950170-23-019634:notes:7]
In September 2022, the Financial Accounting Standards Board (FASB) issued Accounting Standards Update (ASU) 2022-04, Liabilities - Supplier Finance Programs (Topic 450-50): Disclosure of Supplier Finance Program Obligations, that requires entities that use supplier finance programs in connection with the purchase of goods and services to disclose the key terms of the programs and information about obligations outstanding at the end of the reporting period, including a rollforward of those obligations. The guidance does not affect the recognition, measurement or financial statement presentation of supplier finance program obligations. The amendments are effective for all entities for fiscal years beginning after December 15, 2022 on a retrospective basis, including interim periods within those fiscal years, except for the requirement to disclose rollforward information, which is effective prospectively for fiscal years beginning after December 15, 2023. The Company adopted ASU 2022-04 as of April 3, 2023. The Company has agreements with financial institutions to facilitate the payments to certain suppliers. Under the terms of the agreements, the Company confirms the validity of each supplier invoice to the respective financial institution upon receipt. The supplier receives payment from the financial institution, and the Company pays the financial institution based on the terms negotiated, which generally range from 220 days to 360 days, with a weighted average of 290 days. Liabilities associated with these agreements are recorded in accounts payable on the consolidated condensed balance sheets and amounted to $3,565 and $6,653 as of April 3, 2023 and January 2, 2023, respectively.

[0000950170-23-019634:notes:8]
In December 2022, the FASB issued ASU 2022-06, Reference Rate Reform (Topic 848): Deferral of the Sunset Date of Topic 848, which deferred the sunset date of Topic 848 to December 31, 2024, after which entities will no longer be permitted to apply the optional expedients and exceptions in Topic 848. On March 23, 2023, the Company entered into a four-year pay-fixed, receive floating (1-month CME Term Secured Overnight Financing Rate (SOFR)), interest rate swap arrangement with a notional amount of $250.0 million for the period beginning April 1, 2023 and ending on April 1, 2027. Under the terms of the interest rate swap, the Company pays a fixed rate of 3.49% against a portion of its LIBOR-based debt and receives a floating 1-month CME Term SOFR during the swap period. The Company elected optional expedients provided in Topic 848 which allow the designation of the interest rate swap as a cash flow hedge.


## us-gaap:BusinessCombinationDisclosureTextBlock

[0000950170-23-019634:notes:9]
[same as prior period, unchanged from 0000950170-22-023197:notes:11]

[0000950170-23-019634:notes:10]
On June 27, 2022, the Company completed its acquisition of all of the issued and outstanding capital stock of Gritel and ISC Farmingdale Corp. for a total consideration of $298,339 in cash. At the time of acquisition, Telephonics Corporation was wholly-owned by Gritel, and as a result of the acquisition, became an indirect, wholly-owned subsidiary of the Company (collectively with ISC Farmingdale Corp., Telephonics).

[0000950170-23-019634:notes:11]
For the quarters ended April 3, 2023 and April 4, 2022, bank fees and legal, accounting, and other professional service costs associated with the acquisition of $411 and $854, respectively, have been expensed and recorded as general and administrative expense in the consolidated condensed statements of operations.

[0000950170-23-019634:notes:12]
[same as prior period, unchanged from 0000950170-22-023197:notes:14]

[0000950170-23-019634:notes:13]
The purchase price was allocated to tangible and intangible assets acquired, and liabilities assumed based on the fair value at the date of the acquisition, June 27, 2022. The excess of the purchase price over the fair value of net assets acquired was allocated to goodwill. The fair values were based on management’s analysis, including work performed by third-party valuation specialists.

[0000950170-23-019634:notes:14]
The fair values assigned are based on reasonable methods applicable to the nature of the assets acquired and liabilities assumed. The following summarizes the estimated fair values of net assets acquired:

[0000950170-23-019634:notes:15]
|  |  | (In thousands) |  |  |
| Accounts receivable |  | $ | 51,140 |  |  |
| Contract assets |  |  | 26,460 |  |  |
| Inventories |  |  | 38,616 |  |  |
| Prepaid expenses and other current assets |  |  | 5,605 |  |  |
| Property, plant and equipment |  |  | 69,253 |  |  |
| Operating lease right-of-use assets |  |  | 497 |  |  |
| Goodwill |  |  | 111,763 |  |  |
| Identifiable intangible assets |  |  | 101,000 |  |  |
| Non-current deferred tax assets |  |  | 1,476 |  |  |
| Deposits and other non-current assets |  |  | 3,129 |  |  |
| Accounts payable |  |  | (16,026 | ) |  |
| Contract liabilities |  |  | (65,262 | ) |  |
| Accrued salaries, wages and benefits |  |  | (10,616 | ) |  |
| Other current liabilities |  |  | (12,751 | ) |  |
| Operating lease liabilities |  |  | (336 | ) |  |
| Other long-term liabilities |  |  | (5,609 | ) |  |
| Total |  | $ | 298,339 |  |  |

[0000950170-23-019634:notes:16]
The components of the preliminary purchase price allocations that are not yet finalized relate to the fair values of identifiable intangible assets, deferred taxes, tax uncertainties, income taxes payable, and goodwill. As such, fair values may change during the allowable measurement period, which is up to the point the Company obtains and analyzes information that existed as of the date of the acquisition necessary to determine the fair values of the assets acquired and liabilities assumed, but in no case to exceed more than one year from the date of acquisition. Any subsequent changes to the purchase price allocation during the measurement period will be recorded in the reporting period in which the adjustment amounts are determined. Any changes in the fair values of the assets acquired and liabilities assumed during the measurement period may result in material adjustments to goodwill.

[0000950170-23-019634:notes:17]
Goodwill

[0000950170-23-019634:notes:18]
Goodwill represents the excess of the purchase price over the fair value of assets acquired and liabilities assumed. During the quarter ended April 3, 2023, the Company decreased goodwill by $11,350 due to an adjustment to the estimate of fair value for identifiable intangible assets and deferred taxes. Additionally, the Company recorded amortization expense of $18,114 related to the acquired identifiable intangible assets during the quarter ended April 3, 2023 (of which $10,744 corresponded to the year ended January 2, 2023). For the quarter ended April 3, 2023, $4,425 of amortization expense is included in cost of goods sold (of which $2,950 corresponded to the year ended January 2, 2023). The Company believes that the acquisition of Telephonics will strengthen the Company’s differentiated position in the Aerospace and Defense market. The Company believes that these factors support the amount of goodwill recognized as a result of the purchase price paid for Telephonics, in relation to other acquired tangible and intangible assets. The goodwill acquired in the acquisition is not deductible for income tax purposes.

[0000950170-23-019634:notes:19]
[same as prior period, unchanged from 0000950170-22-023197:notes:20]

[0000950170-23-019634:notes:20]
Included in the consolidated condensed statements of operations are $48,639 and $6,785, excluding intercompany sales and amortization of intangibles, of net sales and pre-tax income for the quarter ended April 3, 2023, respectively.

[0000950170-23-019634:notes:21]
[same as prior period, unchanged from 0000950170-22-023197:notes:22]

[0000950170-23-019634:notes:22]
The unaudited preliminary pro forma financial information below gives effect to this acquisition as if it had occurred at the beginning of fiscal 2022, or January 4, 2022. The preliminary pro forma financial information presented includes the effects of adjustments related to the amortization of acquired identifiable intangible assets and decrease in inventory markup, depreciation of acquired fixed assets, and other non-recurring transactions costs directly associated with the acquisition such as legal, accounting and banking fees.

[0000950170-23-019634:notes:23]
[same as prior period, unchanged from 0000950170-22-023197:notes:24]

[0000950170-23-019634:notes:24]
|  |  | Quarter Ended |  |
|  |  | April 3, 2023 |  |  | April 4, 2022 |  |
|  |  | (In thousands, except per share amounts) |  |
| Net sales |  | $ | 544,437 |  |  | $ | 637,533 |  |
| Net (loss) income |  |  | (1,557 | ) |  |  | 11,611 |  |
| Basic (loss) earnings per share |  | $ | (0.02 | ) |  | $ | 0.11 |  |
| Diluted (loss) earnings per share |  | $ | (0.02 | ) |  | $ | 0.11 |  |


## us-gaap:LesseeOperatingLeasesTextBlock

[0000950170-23-019634:notes:25]
[same as prior period, unchanged from 0000950170-22-023197:notes:26]

[0000950170-23-019634:notes:26]
The Company leases some of its manufacturing and assembly plants, sales offices and equipment under non-cancellable operating leases and finance leases that expire at various dates through 2049. The majority of the Company’s lease arrangements are comprised of fixed payments, and certain leases consist of variable payments based on equipment usage. These variable payments are not included in the measurement of the right-of-use (ROU) asset or lease liability due to uncertainty of the payment amount and are recorded as lease expense in the period incurred. Certain leases contain renewal provisions at the Company’s option. Most of the leases require the Company to pay for certain other costs such as property taxes and maintenance. Certain leases also contain rent escalation clauses (step rents) that require additional rental amounts in the later years of the term. Rent expense for leases with step rents is recognized on a straight-line basis over the minimum lease term. The lease agreements do not contain any material residual value guarantees or material restrictive covenants.

[0000950170-23-019634:notes:27]
[same as prior period, unchanged from 0000950170-22-023197:notes:28]

[0000950170-23-019634:notes:28]
|  |  | Quarter Ended |  |
|  |  | April 3, 2023 |  |  | April 4, 2022 |  |
|  |  | (In thousands) |  |
| Operating lease cost |  | $ | 2,046 |  |  | $ | 1,884 |  |
| Variable lease cost |  |  | 278 |  |  |  | 246 |  |
| Short-term lease cost |  |  | 117 |  |  |  | 140 |  |
| Finance lease costs: |  |  |  |  |  |  |
| Amortization of right-of-use assets |  |  | 344 |  |  |  | 344 |  |
| Interest on lease liabilities |  |  | 94 |  |  |  | 98 |  |

[0000950170-23-019634:notes:29]
[same as prior period, unchanged from 0000950170-22-023197:notes:30]

[0000950170-23-019634:notes:30]
|  |  | Quarter Ended |  |
|  |  | April 3, 2023 |  |  | April 4, 2022 |  |
|  |  | (In thousands) |  |
| Cash paid for amounts included in the measurement of lease liabilities: |  |  |  |  |  |  |
| Operating cash flows for operating leases |  | $ | 2,070 |  |  | $ | 1,861 |  |
| Right-of-use assets obtained in exchange for new lease obligations: |  |  |  |  |  |  |
| Operating leases |  |  | 529 |  |  |  | 421 |  |

[0000950170-23-019634:notes:31]
[same as prior period, unchanged from 0000950170-22-023197:notes:32]

[0000950170-23-019634:notes:32]
|  |  |  |  | As of |  |
|  |  | Balance Sheet Location |  | April 3, 2023 |  |  | January 2, 2023 |  |
|  |  |  |  | (In thousands) |  |
| Assets: |  |  |  |  |  |  |  |  |
| Operating leases |  | Operating lease right-of-use assets |  | $ | 15,622 |  |  | $ | 18,862 |  |
| Finance leases |  | Property, plant and equipment, net |  |  | 13,041 |  |  |  | 13,384 |  |
| Total lease assets |  |  |  | $ | 28,663 |  |  | $ | 32,246 |  |
| Liabilities: |  |  |  |  |  |  |  |  |
| Current: |  |  |  |  |  |  |  |  |
| Operating leases |  | Other current liabilities |  | $ | 6,257 |  |  | $ | 7,368 |  |
| Finance leases |  | Other current liabilities |  |  | 752 |  |  |  | 736 |  |
| Long-term: |  |  |  |  |  |  |  |  |
| Operating leases |  | Operating lease liabilities |  |  | 10,099 |  |  |  | 12,249 |  |
| Finance leases |  | Other long-term liabilities |  |  | 13,385 |  |  |  | 13,579 |  |
| Total lease liabilities |  |  |  | $ | 30,493 |  |  | $ | 33,932 |  |

[0000950170-23-019634:notes:33]
|  |  | As of |  |
|  |  | April 3, 2023 |  |  | January 2, 2023 |  |
| Weighted average remaining lease term (years): |  |  |  |  |  |  |
| Operating leases |  | 3.2 |  |  | 3.3 |  |
| Finance leases |  | 13.4 |  |  | 13.6 |  |
| Weighted average discount rate: |  |  |  |  |  |  |
| Operating leases |  |  | 3.31 | % |  |  | 3.09 | % |
| Finance leases |  |  | 2.69 | % |  |  | 2.69 | % |

[0000950170-23-019634:notes:34]
[same as prior period, unchanged from 0000950170-22-023197:notes:35]

[0000950170-23-019634:notes:35]
|  |  | OperatingLeases (1) |  |  | FinanceLeases |  |
|  |  | (In thousands) |  |
| Less than one year |  | $ | 6,662 |  |  | $ | 1,121 |  |
| 1 - 2 years |  |  | 5,485 |  |  |  | 1,131 |  |
| 2 - 3 years |  |  | 2,867 |  |  |  | 1,158 |  |
| 3 - 4 years |  |  | 1,213 |  |  |  | 1,175 |  |
| 4 - 5 years |  |  | 438 |  |  |  | 1,210 |  |
| Thereafter |  |  | 657 |  |  |  | 11,152 |  |
| Total lease payments |  |  | 17,322 |  |  |  | 16,947 |  |
| Less imputed interest |  |  | (966 | ) |  |  | (2,810 | ) |
| Total |  | $ | 16,356 |  |  | $ | 14,137 |  |

[0000950170-23-019634:notes:36]
[same as prior period, unchanged from 0000950170-22-023197:notes:37]


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0000950170-23-019634:notes:37]
[same as prior period, unchanged from 0000950170-22-023197:notes:38]

[0000950170-23-019634:notes:38]
As of April 3, 2023, the aggregate amount of the transaction price allocated to remaining performance obligations for long-term contracts was $378,829. The Company expects to recognize revenue on approximately 52% of the remaining performance obligations for the Company’s long-term contracts over the next twelve months with the remaining amount expected to be recognized thereafter.

[0000950170-23-019634:notes:39]
For contracts in which anticipated total costs exceed the total expected revenue, an estimated loss is recognized in the period when identifiable. A provision for the entire amount of the estimated loss is recorded on a cumulative basis. The estimated remaining costs to complete for loss contracts as of April 3, 2023 and January 2, 2023 were $20,641 and $21,632, respectively.

[0000950170-23-019634:notes:40]
Revenue recognized for the quarter ended April 3, 2023 from amounts recorded as contract liabilities as of January 2, 2023 was $18,508.

[0000950170-23-019634:notes:41]
Revenue from products and services transferred to customers over time and at a point in time accounted for 96% and 4%, respectively, of the Company’s revenue for the quarter ended April 3, 2023, and 97% and 3%, respectively, of the Company’s revenue for the quarter ended April 4, 2022.

[0000950170-23-019634:notes:42]
[same as prior period, unchanged from 0000950170-22-023197:notes:41]

[0000950170-23-019634:notes:43]
|  |  | Quarter Ended April 3, 2023 |  |  |
|  |  | PCB |  |  | RF&S Components |  |  | Total |  |  |
| End Markets |  | (In thousands) |
| Aerospace and Defense |  | $ | 232,292 |  |  | $ | — |  |  | $ | 232,292 |  |  |
| Automotive |  |  | 93,467 |  |  |  | — |  |  |  | 93,467 |  |  |
| Data Center Computing |  |  | 57,870 |  |  |  | — |  |  |  | 57,870 |  |  |
| Medical/Industrial/Instrumentation |  |  | 100,768 |  |  |  | 917 |  |  |  | 101,685 |  |  |
| Networking |  |  | 49,714 |  |  |  | 9,409 |  |  |  | 59,123 |  |  |
| Total |  | $ | 534,111 |  |  | $ | 10,326 |  |  | $ | 544,437 |  |  |

[0000950170-23-019634:notes:44]
|  |  | Quarter Ended April 4, 2022 |  |  |
|  |  | PCB |  |  | RF&S Components |  |  | Total |  |  |
| End Markets |  | (In thousands) |
| Aerospace and Defense |  | $ | 172,180 |  |  | $ | — |  |  | $ | 172,180 |  |  |
| Automotive |  |  | 115,236 |  |  |  | — |  |  |  | 115,236 |  |  |
| Data Center Computing |  |  | 91,784 |  |  |  | — |  |  |  | 91,784 |  |  |
| Medical/Industrial/Instrumentation |  |  | 120,362 |  |  |  | 1,538 |  |  |  | 121,900 |  |  |
| Networking |  |  | 63,643 |  |  |  | 13,757 |  |  |  | 77,400 |  |  |
| Other |  |  | 2,865 |  |  |  | (105 | ) |  |  | 2,760 |  |  |
| Total |  | $ | 566,070 |  |  | $ | 15,190 |  |  | $ | 581,260 |  |  |


## us-gaap:AdditionalFinancialInformationDisclosureTextBlock

[0000950170-23-019634:notes:45]
[same as prior period, unchanged from 0000950170-22-023197:notes:45]

[0000950170-23-019634:notes:46]
|  |  | As of |  |
|  |  | April 3, 2023 |  |  | January 2, 2023 |  |
|  |  | (In thousands) |  |
| Inventories: |  |  |  |  |  |  |
| Raw materials |  | $ | 142,205 |  |  | $ | 145,561 |  |
| Work-in-process |  |  | 29,201 |  |  |  | 20,114 |  |
| Finished goods |  |  | 5,322 |  |  |  | 4,964 |  |
|  |  | $ | 176,728 |  |  | $ | 170,639 |  |
| Property, plant and equipment, net: |  |  |  |  |  |  |
| Land and land use rights |  | $ | 76,811 |  |  | $ | 76,811 |  |
| Buildings and improvements |  |  | 444,990 |  |  |  | 443,353 |  |
| Machinery and equipment |  |  | 994,365 |  |  |  | 989,935 |  |
| Furniture and fixtures and other |  |  | 11,206 |  |  |  | 11,327 |  |
| Construction-in-progress |  |  | 26,899 |  |  |  | 27,774 |  |
|  |  |  | 1,554,271 |  |  |  | 1,549,200 |  |
| Less: Accumulated depreciation |  |  | (840,124 | ) |  |  | (824,996 | ) |
|  |  | $ | 714,147 |  |  | $ | 724,204 |  |
| Other current liabilities: |  |  |  |  |  |  |
| Sales return and allowances |  | $ | 10,774 |  |  | $ | 12,319 |  |
| Income taxes payable |  |  | 9,142 |  |  |  | 28,057 |  |
| Accrued facility operating costs |  |  | 9,102 |  |  |  | 9,081 |  |
| Housing fund |  |  | 7,572 |  |  |  | 7,440 |  |
| Customer deposits |  |  | 7,500 |  |  |  | — |  |
| Warranty |  |  | 6,450 |  |  |  | 8,045 |  |
| Operating leases |  |  | 6,257 |  |  |  | 7,368 |  |
| Accrued professional fees |  |  | 5,463 |  |  |  | 5,123 |  |
| Restructuring |  |  | 3,973 |  |  |  | 2,513 |  |
| Interest |  |  | 1,847 |  |  |  | 9,336 |  |
| Derivative liabilities |  |  | 310 |  |  |  | 1,622 |  |
| Other |  |  | 34,104 |  |  |  | 39,128 |  |
|  |  | $ | 102,494 |  |  | $ | 130,032 |  |
| Other long-term liabilities: |  |  |  |  |  |  |
| Deferred income taxes |  | $ | 53,648 |  |  | $ | 54,268 |  |
| Customer deposits |  |  | 31,250 |  |  |  | 38,750 |  |
| Finance leases |  |  | 13,385 |  |  |  | 13,579 |  |
| Defined benefit pension plan liability |  |  | 2,473 |  |  |  | 2,471 |  |
| Derivative liabilities |  |  | 901 |  |  |  | — |  |
| Other |  |  | 28,801 |  |  |  | 25,976 |  |
|  |  | $ | 130,458 |  |  | $ | 135,044 |  |

[0000950170-23-019634:notes:47]
On December 22, 2022, land, building, and relevant ancillary assets related to the Company’s former Shanghai E-MS (SH E-MS) manufacturing facility were expropriated by the Chinese government for a compensation fee of Renminbi (RMB) 477.6 million generating a gain on the sale of $51,804. The Company received 50% of the proceeds as of April 3, 2023 and will receive the remaining proceeds as follows: 40% before June 30, 2023 and 10% before December 30, 2023. As of April 3, 2023 and January 2, 2023, the receivable from sale of SH E-MS property was $34,746 and $69,240, respectively.


## us-gaap:GoodwillDisclosureTextBlock

[0000950170-23-019634:notes:48]
[same as prior period, unchanged from 0000950170-22-023197:notes:47]

[0000950170-23-019634:notes:49]
As of April 3, 2023 and January 2, 2023, goodwill by reportable segment was as follows:

[0000950170-23-019634:notes:50]
|  |  | PCB |  |  | RF&S Components |  |  | Total |  |
|  |  | (In thousands) |  |
| Balance as of January 2, 2023 |  |  |  |  |  |  |  |  |  |
| Goodwill |  | $ | 823,837 |  |  | $ | 177,200 |  |  | $ | 1,001,037 |  |
| Accumulated impairment losses |  |  | (171,400 | ) |  |  | (69,200 | ) |  |  | (240,600 | ) |
|  |  |  | 652,437 |  |  |  | 108,000 |  |  |  | 760,437 |  |
| Goodwill adjustment during the quarter ended April 3, 2023 |  |  | (11,350 | ) |  |  | — |  |  |  | (11,350 | ) |
| Derecognition of goodwill due to sale of subsidiary |  |  | (2,815 | ) |  |  | — |  |  |  | (2,815 | ) |
| Balance as of April 3, 2023 |  |  |  |  |  |  |  |  |  |
| Goodwill |  |  | 809,672 |  |  |  | 177,200 |  |  |  | 986,872 |  |
| Accumulated impairment losses |  |  | (171,400 | ) |  |  | (69,200 | ) |  |  | (240,600 | ) |
|  |  | $ | 638,272 |  |  | $ | 108,000 |  |  | $ | 746,272 |  |

[0000950170-23-019634:notes:51]
During the quarter ended April 3, 2023, the Company decreased goodwill by $11,350 due to an adjustment to the estimate of fair value for identifiable intangible assets and deferred taxes. Goodwill recognized as a result of the acquisition of Telephonics is not yet finalized as of April 3, 2023. See Note 2 for additional information.


## us-gaap:IntangibleAssetsDisclosureTextBlock

[0000950170-23-019634:notes:52]
[same as prior period, unchanged from 0000950170-22-023197:notes:51]

[0000950170-23-019634:notes:53]
As of April 3, 2023 and January 2, 2023, the components of definite-lived intangibles were as follows:

[0000950170-23-019634:notes:54]
|  |  | GrossAmount |  |  | AccumulatedAmortization |  |  | NetCarryingAmount |  |  | WeightedAverageAmortizationPeriod |  |
|  |  | (In thousands) |  |  | (In years) |  |
| April 3, 2023 |  |  |  |  |  |  |  |  |  |  |  |  |
| Customer relationships |  | $ | 422,071 |  |  | $ | (202,833 | ) |  | $ | 219,238 |  |  |  | 10.6 |  |
| Technology |  |  | 77,150 |  |  |  | (30,685 | ) |  |  | 46,465 |  |  |  | 7.8 |  |
| Backlog |  |  | 13,000 |  |  |  | (9,750 | ) |  |  | 3,250 |  |  |  | 1.0 |  |
| Trade names |  |  | 2,500 |  |  |  | (938 | ) |  |  | 1,562 |  |  |  | 2.0 |  |
|  |  | $ | 514,721 |  |  | $ | (244,206 | ) |  | $ | 270,515 |  |  |  |  |
| January 2, 2023 |  |  |  |  |  |  |  |  |  |  |  |  |
| Customer relationships |  | $ | 366,071 |  |  | $ | (187,560 | ) |  | $ | 178,511 |  |  |  | 11.3 |  |
| Technology |  |  | 47,650 |  |  |  | (24,876 | ) |  |  | 22,774 |  |  |  | 9.5 |  |
| Acquired intangibles from acquisition |  |  |  |  |  |  |  |  |  |  |  |  |
| Customer relationships |  |  | 82,500 |  |  |  | (3,173 | ) |  |  | 79,327 |  |  |  | 13.0 |  |
| Trade names |  |  | 8,250 |  |  |  | (825 | ) |  |  | 7,425 |  |  |  | 5.0 |  |
|  |  | $ | 504,471 |  |  | $ | (216,434 | ) |  | $ | 288,037 |  |  |  |  |

[0000950170-23-019634:notes:55]
The Company has acquired customer relationships, technology, backlog and trade names as a result of the Telephonics acquisition. See Note 2, Acquisition of Gritel and ISC Farmingdale Corp., for further information.

[0000950170-23-019634:notes:56]
Definite-lived intangibles are amortized using the straight-line method of amortization over the useful life. Amortization expense was $27,772 and $9,658 for the quarters ended April 3, 2023 and April 4, 2022, respectively. For the quarters ended April 3, 2023 and April 4, 2022, $5,808 and $1,384, respectively, of amortization expense is included in cost of goods sold.

[0000950170-23-019634:notes:57]
[same as prior period, unchanged from 0000950170-22-023197:notes:56]

[0000950170-23-019634:notes:58]
|  |  | (In thousands) |  |
| Remaining 2023 |  | $ | 42,654 |  |
| 2024 |  |  | 45,375 |  |
| 2025 |  |  | 40,630 |  |
| 2026 |  |  | 40,630 |  |
| 2027 |  |  | 38,348 |  |
| Thereafter |  |  | 62,878 |  |
|  |  | $ | 270,515 |  |


## us-gaap:LongTermDebtTextBlock

[0000950170-23-019634:notes:59]
(8) Long-term Debt and Letters of Credit

[0000950170-23-019634:notes:60]
The following table summarizes the long-term debt of the Company as of April 3, 2023 and January 2, 2023:

[0000950170-23-019634:notes:61]
|  |  | Interest Rate as ofApril 3, 2023 |  |  |  | PrincipalOutstandingas ofApril 3, 2023 |  |  | Interest Rate as ofJanuary 2, 2023 |  |  |  | PrincipalOutstandingas ofJanuary 2, 2023 |  |
|  |  | (In thousands, except interest rates) |  |
| Senior Notes due March 2029 |  |  | 4.00 |  | % |  | $ | 500,000 |  |  |  | 4.00 |  | % |  | $ | 500,000 |  |
| Term Loan due September 2024 |  |  | 7.36 |  |  |  |  | 355,879 |  |  |  | 6.89 |  |  |  |  | 405,879 |  |
| Asia ABL Revolving Loan due June 2024 |  |  | 6.26 |  |  |  |  | 30,000 |  |  |  | 5.79 |  |  |  |  | 30,000 |  |
|  |  |  |  |  |  |  | 885,879 |  |  |  |  |  |  |  | 935,879 |  |
| Less: Long-term debt unamortized debt issuance costs |  |  |  |  |  |  | (5,589 | ) |  |  |  |  |  |  | (6,080 | ) |
| Long-term debt unamortized discount |  |  |  |  |  |  | (297 | ) |  |  |  |  |  |  | (392 | ) |
|  |  |  |  |  |  |  | 879,993 |  |  |  |  |  |  |  | 929,407 |  |
| Less: current maturities |  |  |  |  |  |  | — |  |  |  |  |  |  |  | (50,000 | ) |
| Long-term debt, less current maturities |  |  |  |  |  | $ | 879,993 |  |  |  |  |  |  | $ | 879,407 |  |

[0000950170-23-019634:notes:62]
Debt Covenants

[0000950170-23-019634:notes:63]
Borrowings under the Senior Notes due 2029 and Term Loan Facility are subject to certain affirmative and negative covenants, including limitations on indebtedness, corporate transactions, investments, dispositions, and restricted payments.

[0000950170-23-019634:notes:64]
Under the occurrence of certain events, the U.S. Asset-Based Lending Credit Agreement (U.S. ABL) and Asia Asset-Based Lending Credit Agreement (Asia ABL) (collectively, the ABL Revolving Loans), are subject to various financial covenants, including leverage and fixed charge coverage ratios.

[0000950170-23-019634:notes:65]
Debt Issuance and Debt Discount

[0000950170-23-019634:notes:66]
As of April 3, 2023 and January 2, 2023, remaining unamortized debt discount and debt issuance costs for the Senior Notes due 2029 and Term Loan Facility are as follows:

[0000950170-23-019634:notes:67]
|  |  | As of April 3, 2023 |  |  | As of January 2, 2023 |
|  |  | DebtIssuance Costs |  |  | DebtDiscount |  |  | EffectiveInterest Rate |  |  | DebtIssuance Costs |  |  | DebtDiscount |  |  | EffectiveInterest Rate |  |  |
|  |  | (In thousands, except interest rates) |
| Senior Notes due March 2029 |  | $ | 4,608 |  |  | $ | — |  |  |  | 4.18 |  | % | $ | 4,779 |  |  | $ | — |  |  |  | 4.18 |  | % |
| Term Loan due September 2024 |  |  | 981 |  |  |  | 297 |  |  |  | 4.66 |  |  |  | 1,301 |  |  |  | 392 |  |  |  | 4.66 |  |  |
|  |  | $ | 5,589 |  |  | $ | 297 |  |  |  |  |  | $ | 6,080 |  |  | $ | 392 |  |  |  |  |  |

[0000950170-23-019634:notes:68]
The above debt discount and debt issuance costs are recorded as a reduction of the debt and are amortized into interest expense using an effective interest rate over the duration of the debt.

[0000950170-23-019634:notes:69]
The remaining unamortized debt issuance costs for the ABL Revolving Loans of $652 and $792 as of April 3, 2023 and January 2, 2023, respectively, are included in other non-current assets and are amortized to interest expense over the duration of the ABL Revolving Loans using the straight-line method of amortization.

[0000950170-23-019634:notes:70]
As of April 3, 2023, the remaining weighted average amortization period for all unamortized debt discount and debt issuance costs was 4.6 years.


## us-gaap:IncomeTaxDisclosureTextBlock

[0000950170-23-019634:notes:71]
[same as prior period, unchanged from 0000950170-22-023197:notes:72]

[0000950170-23-019634:notes:72]
The Company’s effective tax rate is impacted by the mix of foreign and U.S. income, tax rates in China and Hong Kong, the U.S. federal income tax rate, apportioned state income tax rates, the generation of credits and deductions available to the Company as well as changes in valuation allowances and certain non-deductible items. No tax benefit was recorded on the losses incurred in certain foreign jurisdictions as a result of corresponding increases in the valuation allowances in these jurisdictions.

[0000950170-23-019634:notes:73]
During the quarter ended April 3, 2023, the Company’s effective tax rate was impacted by a net discrete expense of $356. This is primarily related to tax on sale of one of the Company’s subsidiaries in China and accrued interest expense on existing uncertain tax position.

[0000950170-23-019634:notes:74]
The Company has various foreign subsidiaries formed or acquired to conduct or support its business outside the U.S. The Company expects its earnings attributable to most foreign subsidiaries may be repatriated back to the U.S. and so a deferred tax liability has been recorded for foreign withholding taxes and the estimated federal/state tax impact on any repatriation. For those other

[0000950170-23-019634:notes:75]
companies with earnings currently being reinvested outside of the U.S., no deferred tax liability on undistributed earnings has been recorded.


## us-gaap:SegmentReportingDisclosureTextBlock

[0000950170-23-019634:notes:76]
(10) Segment Information

[0000950170-23-019634:notes:77]
The reportable segments shown below are the Company’s segments for which separate financial information is available and upon which operating results are evaluated by the chief operating decision maker to assess performance and to allocate resources.

[0000950170-23-019634:notes:78]
[same as prior period, unchanged from 0000950170-22-023197:notes:126]

[0000950170-23-019634:notes:79]
|  |  | Quarter Ended |  |
|  |  | April 3, 2023 |  |  | April 4, 2022 |  |
|  |  | (In thousands) |  |
| Net Sales: |  |  |  |  |  |  |
| PCB |  | $ | 534,111 |  |  | $ | 566,070 |  |
| RF&S Components |  |  | 10,326 |  |  |  | 15,190 |  |
| Total net sales |  | $ | 544,437 |  |  | $ | 581,260 |  |
| Operating Segment Income (Loss): |  |  |  |  |  |  |
| PCB |  | $ | 51,634 |  |  | $ | 56,540 |  |
| RF&S Components |  |  | 2,168 |  |  |  | 5,750 |  |
| Corporate and Other |  |  | (29,498 | ) |  |  | (26,764 | ) |
| Total operating segment income |  |  | 24,304 |  |  |  | 35,526 |  |
| Amortization of definite-lived intangibles (1) |  |  | (27,772 | ) |  |  | (9,658 | ) |
| Total operating (loss) income |  |  | (3,468 | ) |  |  | 25,868 |  |
| Total other expense |  |  | (10,270 | ) |  |  | (9,391 | ) |
| (Loss) income before income taxes |  | $ | (13,738 | ) |  | $ | 16,477 |  |

[0000950170-23-019634:notes:80]
|  |  | As of |  |
|  |  | April 3, 2023 |  |  | January 2, 2023 |  |
|  |  | (In thousands) |  |
| Segment Assets: |  |  |  |  |  |  |
| PCB |  | $ | 1,831,973 |  |  | $ | 1,890,723 |  |
| RF&S Components |  |  | 195,741 |  |  |  | 202,619 |  |
| Corporate and Other |  |  | 1,148,321 |  |  |  | 1,230,262 |  |
| Total assets |  | $ | 3,176,035 |  |  | $ | 3,323,604 |  |

[0000950170-23-019634:notes:81]
(1)
Amortization of definite-lived intangibles relates to the PCB and RF&S Components reportable segments. For the quarters ended April 3, 2023 and April 4, 2022, $5,808 and $1,384, respectively, of amortization expense is included in cost of goods sold.

[0000950170-23-019634:notes:82]
The Corporate and Other category primarily includes operating expenses that are not included in the segment operating performance measures. Corporate and Other consists primarily of corporate governance functions such as finance, accounting, information technology and human resources personnel, as well as global sales and marketing personnel, research and development costs, and acquisition and integration costs associated with acquisitions and divestitures.

[0000950170-23-019634:notes:83]
The Company markets and sells its products in approximately 50 countries. Other than in the United States, the Company does not conduct business in any country in which its net sales in that country exceed 10% of the Company’s total net sales. Net sales are as follows:

[0000950170-23-019634:notes:84]
|  |  | Quarter Ended |  |
|  |  | April 3, 2023 |  |  | April 4, 2022 |  |
|  |  | (In thousands) |  |
| Net Sales: |  |  |  |  |  |  |
| United States |  | $ | 311,441 |  |  | $ | 264,401 |  |
| China |  |  | 44,037 |  |  |  | 77,205 |  |
| Other |  |  | 188,959 |  |  |  | 239,654 |  |
| Total net sales |  | $ | 544,437 |  |  | $ | 581,260 |  |

[0000950170-23-019634:notes:85]
[same as prior period, unchanged from 0000950170-22-023197:notes:134]


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0000950170-23-019634:notes:86]
[same as prior period, unchanged from 0000950170-22-023197:notes:93]

[0000950170-23-019634:notes:87]
The following provides a summary of the components of accumulated other comprehensive loss, net of tax, as of April 3, 2023 and January 2, 2023:

[0000950170-23-019634:notes:88]
|  |  | ForeignCurrencyTranslation |  |  | PensionObligation |  |  | (Losses) Gainson Cash FlowHedges |  |  | Total |  |
|  |  | (In thousands) |  |
| Ending balance as of January 2, 2023 |  | $ | (25,984 | ) |  | $ | 1,279 |  |  | $ | (85 | ) |  | $ | (24,790 | ) |
| Other comprehensive (loss) income before reclassifications |  |  | (6,597 | ) |  |  | 1 |  |  |  | (680 | ) |  |  | (7,276 | ) |
| Amounts reclassified from accumulated other comprehensive loss |  |  | — |  |  |  | — |  |  |  | 5 |  |  |  | 5 |  |
| Other comprehensive (loss) income |  |  | (6,597 | ) |  |  | 1 |  |  |  | (675 | ) |  |  | (7,271 | ) |
| Ending balance as of April 3, 2023 |  | $ | (32,581 | ) |  | $ | 1,280 |  |  | $ | (760 | ) |  | $ | (32,061 | ) |


## us-gaap:ConcentrationRiskDisclosureTextBlock

[0000950170-23-019634:notes:89]
[same as prior period, unchanged from 0000950170-22-023197:notes:96]

[0000950170-23-019634:notes:90]
In the normal course of business, the Company extends credit to its customers. Some customers to whom the Company extends credit are located outside the United States. The Company performs on-going credit evaluations of customers, does not require collateral, and considers the credit risk profile of the entity from which the receivable is due in further evaluating collection risk. There were no customers that accounted for 10% or more of accounts receivable as of April 3, 2023. As of January 2, 2023, there was one customer that accounted for 11% of the Company’s accounts receivable.

[0000950170-23-019634:notes:91]
[same as prior period, unchanged from 0000950170-22-023197:notes:98]

[0000950170-23-019634:notes:92]
For the quarters ended April 3, 2023 and April 4, 2022, one customer accounted for approximately 12% and 10% of the Company’s net sales, respectively.


## us-gaap:FairValueDisclosuresTextBlock

[0000950170-23-019634:notes:93]
[same as prior period, unchanged from 0000950170-22-023197:notes:100]

[0000950170-23-019634:notes:94]
[same as prior period, unchanged from 0000950170-22-023197:notes:101]

[0000950170-23-019634:notes:95]
The carrying amount and estimated fair value of the Company’s financial instruments as of April 3, 2023 and January 2, 2023 were as follows:

[0000950170-23-019634:notes:96]
|  |  | As of |  |  | As of |  |
|  |  | April 3, 2023 |  |  | January 2, 2023 |  |
|  |  | CarryingAmount |  |  | Fair Value |  |  | CarryingAmount |  |  | Fair Value |  |
|  |  | (In thousands) |  |
| Derivative assets, current |  | $ | 640 |  |  | $ | 640 |  |  | $ | — |  |  | $ | — |  |
| Derivative liabilities, current |  |  | 310 |  |  |  | 310 |  |  |  | 1,622 |  |  |  | 1,622 |  |
| Derivative liabilities, non-current |  |  | 901 |  |  |  | 901 |  |  |  | — |  |  |  | — |  |
| Senior Notes due March 2029 |  |  | 495,392 |  |  |  | 436,870 |  |  |  | 495,221 |  |  |  | 430,165 |  |
| Term Loan due September 2024 |  |  | 354,601 |  |  |  | 355,879 |  |  |  | 404,186 |  |  |  | 405,628 |  |
| ABL Revolving Loans |  |  | 30,000 |  |  |  | 30,000 |  |  |  | 30,000 |  |  |  | 30,000 |  |

[0000950170-23-019634:notes:97]
The fair value of the derivative instruments was determined using pricing models developed based on the 1-month CME Term SOFR swap rate, foreign currency exchange rates, and other observable market data, including quoted market prices, as appropriate using Level 2 inputs. The values were adjusted to reflect non-performance risk of both the counterparty and the Company, as necessary.

[0000950170-23-019634:notes:98]
The fair value of the long-term debt was estimated based on quoted market prices or discounting the debt over its life using current market rates for similar debt as of April 3, 2023 and January 2, 2023, which are considered Level 2 inputs.

[0000950170-23-019634:notes:99]
As of April 3, 2023 and January 2, 2023, the Company’s other financial instruments included cash and cash equivalents, accounts receivable, contract assets, accounts payable, and contract liabilities. The carrying amount of these instruments approximates fair value. The Company’s cash and cash equivalents as of April 3, 2023 consisted of $173,696 held in the U.S., with the remaining $243,756 held by foreign subsidiaries.

[0000950170-23-019634:notes:100]
[same as prior period, unchanged from 0000950170-22-023197:notes:107]


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0000950170-23-019634:notes:101]
(14) Commitments and Contingencies

[0000950170-23-019634:notes:102]
Legal Matters

[0000950170-23-019634:notes:103]
The Company is subject to various legal matters, which it considers normal for its business activities. While the Company currently believes that the amount of any reasonably possible loss for known matters would not be material to the Company’s financial condition, the outcome of these actions is inherently difficult to predict. In the event of an adverse outcome, the ultimate potential loss could have a material adverse effect on the Company’s financial condition or results of operations in a particular period. The Company has accrued amounts for its loss contingencies which are probable and estimable as of April 3, 2023 and January 2, 2023. However, these amounts are not material to the consolidated condensed financial statements of the Company.

[0000950170-23-019634:notes:104]
Offset Agreements

[0000950170-23-019634:notes:105]
The Company has and may continue to enter into industrial cooperation agreements, sometimes referred to as offset agreements, as a condition to obtaining orders for products and services from customers in foreign countries. These agreements are intended to promote investment in the applicable country, and the Company’s obligations under these agreements may be satisfied through activities that do not require the Company to use cash, including transferring technology or providing manufacturing and other consulting support. The obligations under these agreements may also be satisfied through the use of cash for activities such as purchasing supplies from in-country vendors, setting up support centers, research and development investments, acquisitions, and building or leasing facilities for in-country operations, if applicable. The amount of the offset requirement is determined by contract value awarded and negotiated percentages with customers. As of April 3, 2023, the Company had outstanding offset agreements of approximately $20,169, some of which extend through 2028. Offset programs usually extend over several years and in some cases provide for penalties in the event the Company fails to perform in accordance with contract requirements. Historically, the Company has not paid any such penalties, and as of April 3, 2023, no such penalties have been paid.


## us-gaap:EarningsPerShareTextBlock

[0000950170-23-019634:notes:106]
[same as prior period, unchanged from 0000950170-22-023197:notes:113]

[0000950170-23-019634:notes:107]
The following is a reconciliation of the numerator and denominator used to calculate basic earnings per share and diluted earnings per share for the quarters ended April 3, 2023 and April 4, 2022:

[0000950170-23-019634:notes:108]
|  |  | Quarter Ended |  |
|  |  | April 3, |  |  | April 4, |  |
|  |  | 2023 |  |  | 2022 |  |
|  |  | (In thousands, except per share amounts) |  |
| Net (loss) income |  | $ | (5,814 | ) |  | $ | 17,246 |  |
| Basic weighted average shares |  |  | 102,381 |  |  |  | 102,613 |  |
| Dilutive effect of performance-based restricted stock units, restricted stock units and stock options |  |  | — |  |  |  | 1,685 |  |
| Dilutive effect of outstanding warrants |  |  | — |  |  |  | 6 |  |
| Diluted shares |  |  | 102,381 |  |  |  | 104,304 |  |
| (Loss) earnings per share: |  |  |  |  |  |  |
| Basic |  | $ | (0.06 | ) |  | $ | 0.17 |  |
| Diluted |  | $ | (0.06 | ) |  | $ | 0.17 |  |

[0000950170-23-019634:notes:109]
For the quarter ended April 3, 2023, potential shares of common stock, consisting of stock options to purchase approximately 60 shares of common stock at exercise prices ranging from $11.83 to $16.60 per share, 3,027 restricted stock units (RSUs), and 606 performance-based restricted stock units (PRUs) were not included in the computation of diluted earnings per share because the Company incurred a net loss and as a result, the impact would be anti-dilutive.

[0000950170-23-019634:notes:110]
PRUs, RSUs, and stock options to purchase 975 shares of common stock for the quarter ended April 4, 2022 were not included in the computation of diluted earnings per share. The PRUs were not included in the computation of diluted earnings per share because the performance conditions had not been met at April 4, 2022, and for RSUs and stock options, the options’ exercise prices or the total expected proceeds under the treasury stock method was greater than the average market price of common stock during the applicable quarter and, as a result, the impact would be anti-dilutive.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0000950170-23-019634:notes:111]
[same as prior period, unchanged from 0000950170-22-023197:notes:118]

[0000950170-23-019634:notes:112]
[same as prior period, unchanged from 0000950170-22-023197:notes:119]

[0000950170-23-019634:notes:113]
|  |  | Quarter Ended |  |
|  |  | April 3, |  |  | April 4, |  |
|  |  | 2023 |  |  | 2022 |  |
|  |  | (In thousands) |  |
| Cost of goods sold |  | $ | 1,662 |  |  | $ | 1,276 |  |
| Selling and marketing |  |  | 741 |  |  |  | 650 |  |
| General and administrative |  |  | 2,562 |  |  |  | 2,053 |  |
| Research and development |  |  | 275 |  |  |  | 255 |  |
| Stock-based compensation expense recognized |  | $ | 5,240 |  |  | $ | 4,234 |  |

[0000950170-23-019634:notes:114]
[same as prior period, unchanged from 0000950170-22-023197:notes:121]

[0000950170-23-019634:notes:115]
The following is a summary of total unrecognized compensation costs as of April 3, 2023:

[0000950170-23-019634:notes:116]
|  |  | Unrecognized Stock-Based Compensation Cost |  |  | Remaining Weighted AverageRecognition Period |  |
|  |  | (In thousands) |  |  | (In years) |  |
| RSU awards |  | $ | 24,846 |  |  |  | 1.4 |  |
| PRU awards |  |  | 2,998 |  |  |  | 1.3 |  |
|  |  | $ | 27,844 |  |  |  |  |


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0000950170-23-019634:notes:117]
(17) Restructuring Charges

[0000950170-23-019634:notes:118]
On February 8, 2023, the Company announced a consolidation plan, which would include closing three of its manufacturing facilities and consolidating the operations of those facilities into other Company facilities. The three manufacturing facilities are PCB operations located in Anaheim and Santa Clara, California, and Hong Kong. As of the end of April 2023, the Company ceased operations at the Hong Kong manufacturing facility and expects to be substantially closed by the end of the second quarter of 2023. The Company expects the Anaheim and Santa Clara facilities to be substantially closed by the end of 2023. As of April 3, 2023, the Company has incurred approximately $3,473 of restructuring charges and $1,276 of accelerated depreciation expense since the February 8, 2023 announcement.

[0000950170-23-019634:notes:119]
In addition to this consolidation plan, the Company recognized employee separation, contract termination and other costs during the quarters ended April 3, 2023 and April 4, 2022 in connection with other global realignment restructuring efforts. Contract termination and other costs primarily represented plant closure costs.

[0000950170-23-019634:notes:120]
The below table summarizes such restructuring costs by reportable segment for the quarters ended April 3, 2023 and April 4, 2022:

[0000950170-23-019634:notes:121]
|  |  | Quarter Ended April 3, 2023 |  |
|  |  | EmployeeSeparation/Severance |  |  | ContractTerminationand OtherCosts |  |  | Total |  |
|  |  | (In thousands) |  |
| Reportable Segment: |  |  |  |  |  |  |  |  |  |
| PCB |  | $ | 3,757 |  |  | $ | 186 |  |  | $ | 3,943 |  |
| Corporate and Other |  |  | 126 |  |  |  | 98 |  |  |  | 224 |  |
|  |  | $ | 3,883 |  |  | $ | 284 |  |  | $ | 4,167 |  |

[0000950170-23-019634:notes:122]
|  |  | Quarter Ended April 4, 2022 |  |
|  |  | EmployeeSeparation/Severance |  |  | ContractTerminationand OtherCosts |  |  | Total |  |
|  |  | (In thousands) |  |
| Reportable Segment: |  |  |  |  |  |  |  |  |  |
| Corporate and Other |  | $ | 31 |  |  | $ | 153 |  |  | $ | 184 |  |
|  |  | $ | 31 |  |  | $ | 153 |  |  | $ | 184 |  |

[0000950170-23-019634:notes:123]
Accrued restructuring costs are included as a component of other current liabilities in the consolidated condensed balance sheet. The below table shows the utilization of the accrued restructuring costs during the quarter ended April 3, 2023:

[0000950170-23-019634:notes:124]
|  |  | EmployeeSeparation/Severance |  |  | ContractTerminationand OtherCosts |  |  | Total |  |
|  |  | (In thousands) |  |
| Accrued as of January 2, 2023 |  | $ | 2,510 |  |  | $ | 3 |  |  | $ | 2,513 |  |
| Charged to expense |  |  | 3,883 |  |  |  | 284 |  |  |  | 4,167 |  |
| Amount paid |  |  | (2,521 | ) |  |  | (186 | ) |  |  | (2,707 | ) |
| Accrued as of April 3, 2023 |  | $ | 3,872 |  |  | $ | 101 |  |  | $ | 3,973 |  |


## us-gaap:SubsequentEventsTextBlock

[0000950170-23-019634:notes:125]
(18) Subsequent Events

[0000950170-23-019634:notes:126]
On May 3, 2023, the Company announced that its Board of Directors authorized and approved a share repurchase program. Under the program, the Company may repurchase up to $100,000 in value of the Company’s outstanding shares of common stock from time to time through May 3, 2025. The Company may repurchase shares through open market purchases, privately-negotiated transactions, or otherwise in accordance with applicable federal securities laws, including Rule 10b-18 of the Securities Exchange Act of 1934, as amended (Exchange Act) which sets certain restrictions on the method, timing, price and volume of open market stock repurchases. In addition, the Company expects to adopt one or more trading plans in accordance with Rule 10b5-1 of the Exchange Act to facilitate certain purchases that may be effected under the share repurchase program. The timing, manner, price and amount of any repurchases will be determined at the Company’s discretion, and the share repurchase program may be suspended, terminated or modified at any time for any reason. The repurchase program does not obligate the Company to acquire any specific number of shares.
