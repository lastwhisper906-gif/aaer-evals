# TTMI MD&A — 0000950170-23-005994


## mdna

[0000950170-23-005994:mdna:1]
ITEM 7. MANAGEMENT’S DISCUSSION AND ANALYSIS OF FINANCIAL CONDITION AND RESULTS OF OPERATIONS

[0000950170-23-005994:mdna:2]
This financial review presents our operating results for each of our three most recent fiscal years and our financial condition as of January 2, 2023. Except for historical information contained herein, the following discussion contains forward-looking statements which are subject to known and unknown risks, uncertainties and other factors that may cause our actual results to differ materially from those expressed or implied by such forward-looking statements. We discuss such risks, uncertainties and other factors throughout this report and specifically under Item 1A of Part I of this report, Risk Factors. In addition, the following discussion should be read in connection with the information presented in our consolidated financial statements and the related notes to our consolidated financial statements.

[0000950170-23-005994:mdna:3]
COMPANY OVERVIEW

[0000950170-23-005994:mdna:4]
We are a leading global manufacturer of technology solutions, including engineered systems, radio frequency (RF) components and RF microwave/microelectronic assemblies, and printed circuit boards (PCB). We focus on providing time-to-market and volume production of advanced technology products and offer a one-stop design, engineering and manufacturing solution to our customers. This one-stop design, engineering and manufacturing solution allows us to align technology development with the diverse needs of our customers and to enable them to reduce the time required to develop new products and bring them to market. We serve a diversified customer base consisting of approximately 1,500 customers in various markets throughout the world, including aerospace and defense, data center computing, automotive, medical, industrial and instrumentation, as well as networking and telecommunications. Our customers include original equipment manufacturers (OEMs), electronic manufacturing services (EMS) providers, original design manufacturers (ODMs), distributors and government agencies.

[0000950170-23-005994:mdna:5]
RECENT DEVELOPMENTS

[0000950170-23-005994:mdna:6]
On February 8, 2023, we announced that we intend to close PCB manufacturing operations in Anaheim and Santa Clara, California, and Hong Kong and to consolidate the business from these impacted sites into our remaining facilities. The plant closures are expected to improve both facility and talent utilization across our footprint resulting in improved profitability. We expect to record between $22.0 million and $28.0 million in separation, asset impairment and disposal costs related to this restructuring, primarily between now and the end of 2023. Approximately 80% of these costs are expected to be in the form of cash expenditures and the rest in the form of non-cash charges.

[0000950170-23-005994:mdna:7]
On December 22, 2022, our land, building, and relevant ancillary assets related to our former Shanghai E-MS (SH E-MS) manufacturing facility was expropriated by the Chinese government for a compensation fee of Renminbi (RMB) 477.6 million ($69.2 million as of January 2, 2023) generating a gain on the sale of $51.8 million. We will receive the proceeds as follows: 50% before March 30, 2023, 40% before June 30, 2023, and 10% before December 30, 2023.

[0000950170-23-005994:mdna:8]
On June 27, 2022, we completed our acquisition of all of the issued and outstanding common stock of Gritel Holding Co., Inc. (Gritel) and ISC Farmingdale Corp. for a total consideration of $298.3 million in cash. At the time of the acquisition, Telephonics Corporation was wholly-owned by Gritel, and as a result of the acquisition, became an indirect, wholly-owned subsidiary of the Company (collectively with ISC Farmingdale Corp., Telephonics). Telephonics is recognized globally as a leading provider of highly sophisticated military intelligence, surveillance and communications solutions that are deployed across a wide range of land, sea, and air applications.

[0000950170-23-005994:mdna:9]
On March 1, 2022, we announced that we are planning to open a new highly automated PCB manufacturing facility in Penang, Malaysia, with operations to commence in late fiscal 2023. During fiscal year 2022, we completed the pilings required for the building and laid the majority of the foundation. We have also received multiple deposits from customers with whom we have signed long-term agreements which we expect can eventually provide a business base for over 70% of the planned capacity in the new building. We expect our total capital expenditures for the facility to be approximately $130.0 million through 2025.

[0000950170-23-005994:mdna:10]
The coronavirus (COVID-19) pandemic initially caused disruption to our operations in China in January 2020. By March 2020, the situation escalated as the scope of the COVID-19 pandemic worsened outside of the Asia-Pacific region, with Europe and North America being affected by the pandemic. We expect continued impacts on our production, as well as on-going significant uncertainty relating to the actual and potential impacts of the COVID-19 pandemic, and we cannot reasonably estimate its duration or severity. For example, during the first quarter of the 2022 fiscal year, an outbreak in Mainland China forced temporary lockdown orders in several cities in which we operate, and, at other times throughout 2022 the Chinese government imposed lockdowns and other restrictions as part of its “zero-COVID” policy. Further, in North America, there was a surge in cases resulting from the Omicron variant from December 2021 through January 2022 which resulted in production inefficiencies caused by a combination of quarantine impacts and direct labor shortages on our overall production. The COVID-19 pandemic along with the conflict between Russia and Ukraine has created and continues to contribute to various global macroeconomic, customer demand, operational and supply chain risks and has contributed to high inflation, labor shortages in North America, and a potential recession, each of which could have a material and adverse impact on our business going forward. See Item 1A, Risk Factors, of Part I above for further information related to the COVID-19 pandemic, conflict between Russia and Ukraine, and macro-economic risks resulting, in part, from the pandemic.

[0000950170-23-005994:mdna:11]
We are monitoring the impacts the COVID-19 pandemic has had, and continues to have, on our supply chain, and our operations in China, and are collaborating with our third-party partners with the goal of mitigating, to the extent reasonably practicable, significant delays in delivery of our products. We continue to experience supply chain constraints and inflationary pressures. We have been actively taking measures intended to manage both supply chain constraints and higher raw materials costs, including, without limitation, through such measures as supplier diversification, on-going operational efficiency efforts and quotation adjustments to mitigate the impact on our business.

[0000950170-23-005994:mdna:12]
We also continue to see challenges in attracting and retaining labor in North America. We actively seek to demonstrate employees’ value to our business through a combination of financial and non-financial methods. However, a number of factors may continue to adversely affect the labor force available to us, including high employment levels, government regulations, and wage inflation. An overall labor shortage, lack of skilled labor, increased turnover or labor inflation could have a material adverse impact on our business.

[0000950170-23-005994:mdna:13]
FINANCIAL OVERVIEW

[0000950170-23-005994:mdna:14]
Results related to our Mobility business unit are reported as discontinued operations for 2020. See Note 9 of the Notes to Consolidated Financial Statements for further information. Unless otherwise noted, amounts and disclosures throughout our Management’s Discussion and Analysis of Financial Condition and Results of Operations relate to our continuing operations.

[0000950170-23-005994:mdna:15]
We use a 52/53 week fiscal calendar with the fourth quarter ending on the Monday nearest December 31. Fiscal year 2022 and 2020 were 52 weeks ended on January 2, 2023 and December 28, 2020, respectively. Fiscal year 2021 consisted of 53 weeks ended on January 3, 2022, with the additional week included in the fourth quarter. We estimate the additional week contributed approximately $42.2 million of additional revenue and approximately $2.5 million of additional operating income for the year ended January 3, 2022.

[0000950170-23-005994:mdna:16]
While our customers include both OEMs and EMS providers, we measure customers based on OEM companies, as they are the ultimate end customers. Sales to our five largest customers accounted for 33%, 30% and 29% of our net sales in fiscal years 2022, 2021 and 2020, respectively. We sell to OEMs both directly and indirectly through EMS providers.

[0000950170-23-005994:mdna:17]
The following table shows the percentage of our net sales attributable to each of the principal end markets we serve for the periods indicated:

[0000950170-23-005994:mdna:18]
|  |  | For the Year Ended |  |  |
| End Markets (1) |  | January 2, 2023 |  |  |  | January 3, 2022 |  |  |  | December 28, 2020 |  |  |
| Aerospace and Defense |  |  | 35 |  | % |  |  | 33 |  | % |  |  | 36 |  | % |
| Automotive |  |  | 17 |  |  |  |  | 18 |  |  |  |  | 15 |  |  |
| Data Center Computing (2) |  |  | 15 |  |  |  |  | 14 |  |  |  |  | 12 |  |  |
| Medical/Industrial/Instrumentation |  |  | 20 |  |  |  |  | 19 |  |  |  |  | 18 |  |  |
| Networking |  |  | 13 |  |  |  |  | 15 |  |  |  |  | 18 |  |  |
| Other (3) |  |  | — |  |  |  |  | 1 |  |  |  |  | 1 |  |  |
| Total |  |  | 100 |  | % |  |  | 100 |  | % |  |  | 100 |  | % |

[0000950170-23-005994:mdna:19]
(1)
Sales to EMS companies are classified by the end markets of their OEM customers.

[0000950170-23-005994:mdna:20]
(2)
Beginning in the first quarter of 2021, the Computing/Storage/Peripherals end market was renamed to Data Center Computing to better reflect the customer mix and growth prospects. There was no change to the customers included in this end market.

[0000950170-23-005994:mdna:21]
(3)
Other end market reflects direct sales to EMS and distributor customers.

[0000950170-23-005994:mdna:22]
We derive revenues primarily from the sale of PCBs, engineered systems using customer-supplied engineering and design plans as well as our long-term contracts related to the design and manufacture of highly sophisticated intelligence, surveillance and communications solutions, RF and microwave/microelectronics components, assemblies, and subsystems. Orders for products generally correspond to the production schedules of our customers and are supported with firm purchase orders. Our customers have continuous control of the work in progress and finished goods throughout the PCB and engineered systems manufacturing process, as these are built to customer specifications with no alternative use, and there is an enforceable right of payment for work performed to date. As a result, we recognize revenue progressively over time based on the extent of progress towards completion of the performance obligation. We recognize revenue based on a cost method as it best depicts the transfer of control to the customer which takes place as we incur costs. Revenues are recorded proportionally as costs are incurred.

[0000950170-23-005994:mdna:23]
We also manufacture certain components, assemblies, subsystems, and completed systems which service our RF and Specialty Components (RF&S Components) customers and certain aerospace and defense customers. We recognize revenue at a point in time upon transfer of control of the products to our customer. Point in time recognition was determined as our customers do not simultaneously receive or consume the benefits provided by our performance and the asset being manufactured has alternative uses to us.

[0000950170-23-005994:mdna:24]
Net sales consist of gross sales less an allowance for returns, which typically have been approximately 2% of gross sales. We provide our customers a limited right of return for defective PCBs including components, subsystems, and assemblies. We record an estimate for sales returns and allowances at the time of sale based on historical results and anticipated returns.

[0000950170-23-005994:mdna:25]
Cost of goods sold consists of materials, labor, outside services, and overhead expenses incurred in the manufacture and testing of our products. Shipping and handling fees and related freight costs and supplies associated with shipping products are also included as a component of cost of goods sold. Many factors affect our gross margin, including capacity utilization, product mix, production volume, supply chain issues, and yield.

[0000950170-23-005994:mdna:26]
Selling and marketing expenses consist primarily of salaries, labor related benefits, and commissions paid to our internal sales force, independent sales representatives, and our sales support staff, as well as costs associated with marketing materials and trade shows.

[0000950170-23-005994:mdna:27]
General and administrative costs primarily include the salaries for executive, finance, accounting, information technology, and human resources personnel, as well as expenses for accounting and legal assistance, incentive compensation expense, and gains or losses on the sale or disposal of property, plant and equipment.

[0000950170-23-005994:mdna:28]
Research and development expenses consist primarily of salaries and labor related benefits paid to our research and development staff, as well as material costs.

[0000950170-23-005994:mdna:29]
CRITICAL ACCOUNTING POLICIES AND ESTIMATES

[0000950170-23-005994:mdna:30]
Our consolidated financial statements included in this report have been prepared in accordance with accounting principles generally accepted in the United States of America (U.S. GAAP). The preparation of these financial statements requires management to make estimates and assumptions that affect the reported amounts of assets, liabilities, net sales and expenses, and related disclosure of contingent assets and liabilities.

[0000950170-23-005994:mdna:31]
A critical accounting policy is defined as one that is both material to the presentation of our consolidated financial statements and requires us to make judgments that could have a material effect on our financial condition or results of operations. These policies require us to make assumptions about matters that are highly uncertain at the time of the estimate. Critical accounting estimates refers to those estimates made in accordance with U.S. GAAP that have had or are reasonably likely to have a material impact on the amounts reported in the consolidated financial statements and the related notes due to the significant level of uncertainty involved in developing the estimate. Different estimates we could reasonably have used, or changes in the estimates that are reasonably likely to occur, could have a material effect on our financial condition or results of operations.

[0000950170-23-005994:mdna:32]
We base our estimates on historical experience and on various other assumptions that we believe to be reasonable under the circumstances, the results of which form the basis for making judgments about the carrying values of assets and liabilities that are not readily apparent from other sources. Management has discussed the development, selection and disclosure of these estimates with the audit committee of our board of directors. Actual results may differ from these estimates under different assumptions or conditions.

[0000950170-23-005994:mdna:33]
We believe the following critical accounting policies and estimates reflect the more significant judgments and estimates used by us in preparing our consolidated financial statements:

[0000950170-23-005994:mdna:34]
Revenue Recognition

[0000950170-23-005994:mdna:35]
Revenue is recognized when control of the promised goods or services is transferred to customers, in an amount that reflects the consideration to which we expect to be entitled in exchange for those goods or services. We apply a five-step approach in determining the amount and timing of revenue to be recognized: (1) identifying the contract with a customer; (2) identifying the performance obligations in the contract; (3) determining the transaction price; (4) allocating the transaction price to the performance obligations in the contract; and (5) recognizing revenue when the corresponding performance obligation is satisfied.

[0000950170-23-005994:mdna:36]
For PCBs and engineered systems, including pursuant to long-term contracts related to the manufacture of highly sophisticated intelligence, surveillance and communications solutions, components, assemblies and subsystems, orders for products generally correspond to the production schedules of customers and are supported with firm purchase orders. Customers have continuous control of the work in progress and finished goods throughout the PCB and engineered systems manufacturing process, as these are built to customer specifications with no alternative use, and there is an enforceable right to payment for work performed to date. As a result, we recognize revenue progressively over time based on the extent of progress towards completion of the performance obligation. Revenue recognized is based on a cost method as it best depicts the transfer of control to the customer which takes place as we incur costs. Revenues are recorded proportionally as costs are incurred.

[0000950170-23-005994:mdna:37]
For revenue recorded on an over time basis, we apply a gross margin estimate to inventory in process of being manufactured for customers to determine how much of a contract asset or contract liability should be recorded at period end. Contract assets totaled $335.8 million and $324.9 million for the years ended January 2, 2023 and January 3, 2022, respectively. $25.0 million of that increase in contract assets is due to the inclusion of Telephonics’ operations commencing on June 27, 2022 and the rest of the increase is primarily due to timing of progress on customer work orders at year-end. In addition, as a result of Telephonics’ operations in the period commencing on June 27, 2022, $7.1 million of contract assets are expected to be collected after one year and included as a component of deposits and other non-current assets on the consolidated balance sheets as of January 2, 2023. We use historical information to estimate the gross margin associated with performance obligations that are satisfied over time. We reevaluate our estimate of gross margins on a quarterly basis. Based on the review of gross margins, we update our estimate to the model as necessary. If our estimates of gross margins are inaccurate, we may recognize too much or too little revenue in a period. While experience has shown that trends in gross margins are not volatile, changes in pricing or cost efficiencies could create significant fluctuations. An increase or decrease of 200 basis points in gross margin estimates would have increased or decreased our contract assets by $3.7 million and $2.7 million, respectively, and decreased or increased our contract liabilities by $4.1 million and $4.8 million, respectively.

[0000950170-23-005994:mdna:38]
In addition, we manufacture components, assemblies, subsystems, and completed systems which service our RF&S Components and certain aerospace and defense customers. We recognize revenue at a point in time upon transfer of control of the products to the customer. Point in time recognition was determined as our customer does not simultaneously receive or consume the benefits provided by our performance and the asset being manufactured has alternative uses to us.

[0000950170-23-005994:mdna:39]
Goodwill and Intangible Assets

[0000950170-23-005994:mdna:40]
We have significant goodwill and definite-lived intangibles. We review these assets for impairment whenever events or changes in circumstances indicate that the carrying amount of such assets may not be recoverable. In addition, we perform an impairment test related to goodwill at least annually. As necessary, we make judgments regarding future cash flow forecasts in the assessment of impairment.

[0000950170-23-005994:mdna:41]
Goodwill is allocated to our reporting units, which are our operating segments or one level below our operating segments (the component level). Reporting units are determined by the discrete financial information available for the component and whether it is regularly reviewed by segment management. Components are aggregated into a single reporting unit if they share similar economic characteristics. The Company evaluates its goodwill on an annual basis in the fourth quarter or more frequently if it believes indicators of impairment exist. We assess qualitative factors to determine whether it is more likely than not that the fair value of a reporting unit is less than its carrying amount or perform a quantitative impairment test. When tested quantitatively, we compare the fair value of the applicable reporting unit with its carrying value. We estimate the fair values of our reporting units using a combination of the discounted cash flow (DCF) and market approach. If the carrying amount of a reporting unit exceeds the reporting unit’s fair value, the amount by which the carrying value exceeds the fair value is recognized as an impairment loss.

[0000950170-23-005994:mdna:42]
We have two reportable segments: PCB and RF&S Components. Goodwill is attributable to both of our PCB and RF&S Components reportable segments.

[0000950170-23-005994:mdna:43]
In the fourth quarter of 2022, we performed our annual impairment test quantitatively and concluded that goodwill was not impaired. In performing the impairment test, we determined the fair value of our reporting units by using discounted cash flow (DCF) and market analyses. Determining fair value requires us to make judgments about appropriate discount rates, terminal value growth rates and the amount and timing of expected future cash flows. The cash flows employed in the DCF analysis for each reporting unit are based on the reporting unit's budget, long-term business plan, and recent operating performance. Discount rate assumptions are based on an assessment of the risk inherent in the future cash flows of the respective reporting unit and market conditions. Under the market approach, we use revenue and earnings multiples based on comparable industry multiples to estimate the fair value of the reporting units. For the annual impairment test, the fair value of our PCB and RF&S Components reportable segments exceeded their respective carrying values by 21% and 29%, respectively. Significant assumptions used in the DCF included terminal value growth rates and discount rates that ranged from 3% to 12%. An increase in the discount rate and decrease in the long-term growth rates of 0.5% would result in the fair value of the reporting units exceeding their respective carrying values by 17% to 24%. Given the inherent uncertainty in determining the assumptions underlying a DCF and market analysis, actual results may differ from those used in our valuations. In assessing the reasonableness of the determined fair values, we also reconciled the aggregate determined fair value of the Company to the Company's market capitalization, which, at the date of our annual impairment test, implied a 31% control premium on a normalized basis.

[0000950170-23-005994:mdna:44]
Management will continue to monitor the reporting units for changes in the business environment that could impact recoverability. The recoverability of goodwill is dependent upon the continued growth of cash flows from our business activities. If the economy or business environment falter and we are unable to achieve our assumed revenue growth rates or profit margin percentages, our projections used would need to be re-measured, which could impact the carrying value of our goodwill in one or more of our reporting units.

[0000950170-23-005994:mdna:45]
We also assess definite-lived intangibles for potential impairment given similar impairment indicators. When indicators of impairment exist related to our definite-lived intangible assets, we use an estimate of the undiscounted cash flows in measuring whether the carrying amount of the assets is recoverable. If the sum of the undiscounted cash flows is less than the carrying amount of the net assets, impairment is measured based on the difference between the net asset’s carrying value and estimated fair value. Fair value is determined through various valuation techniques, including cost-based, market and income approaches as considered necessary, which involve judgments related to future cash flows and the application of the appropriate valuation model.

[0000950170-23-005994:mdna:46]
Business Combinations

[0000950170-23-005994:mdna:47]
The application of acquisition accounting to a business acquisition requires that we identify the individual assets acquired and liabilities assumed and estimate the fair value of each. The fair value of assets acquired and liabilities assumed in a business acquisition are recognized at the acquisition date, with the purchase price exceeding the fair values being recognized as goodwill. Determining fair value of identifiable assets, particularly intangibles, liabilities acquired and contingent obligations assumed requires management to make estimates. In certain circumstances, the allocations of the purchase price are based upon preliminary estimates and assumptions and subject to revision when we receive final information, including appraisals and other analysis. Accordingly, the measurement period for such purchase price allocations will end when the information, or the facts and circumstances, becomes available, but will not exceed twelve months. We will recognize measurement-period adjustments during the period of resolution, including the effect on earnings of any amounts that would have been recorded in previous periods if the accounting had been completed at the acquisition date.

[0000950170-23-005994:mdna:48]
Goodwill and intangible assets often represent a significant portion of the assets acquired in a business combination. We recognize the fair value of an acquired intangible apart from goodwill whenever the intangible arises from contractual or other legal rights, or when it can be separated or divided from the acquired entity and sold, transferred, licensed, rented or exchanged, either individually or in combination with a related contract, asset or liability. Intangible assets consist primarily of customer relationships and trade names acquired in business combinations. As of January 2, 2023, we have not finalized the determination of fair values allocated to identifiable

[0000950170-23-005994:mdna:49]
intangible assets. We used publicly available benchmarking information, as well as a variety of other assumptions, including market participant assumptions to determine the preliminary values assigned to intangible assets.

[0000950170-23-005994:mdna:50]
RESULTS OF OPERATIONS

[0000950170-23-005994:mdna:51]
We operate on a 52 or 53 week year ending on the Monday nearest December 31. Fiscal year 2022 and 2020 were 52 weeks ended on January 2, 2023 and December 28, 2020, respectively. Fiscal year 2021 consisted of 53 weeks ended on January 3, 2022, with the additional week included in the fourth quarter. We estimate the additional week contributed approximately $42.2 million of additional revenue and approximately $2.5 million of additional operating income for the year ended January 3, 2022.

[0000950170-23-005994:mdna:52]
The following table sets forth the relationship of various items to net sales in our consolidated statements of operations:

[0000950170-23-005994:mdna:53]
|  |  | For the Year Ended |  |  |
|  |  | January 2, 2023 |  |  |  | January 3, 2022 |  |  |  | December 28, 2020 |  |  |
| Net sales |  |  | 100.0 |  | % |  |  | 100.0 |  | % |  |  | 100.0 |  | % |
| Cost of goods sold |  |  | 81.6 |  |  |  |  | 83.5 |  |  |  |  | 83.0 |  |  |
| Gross profit |  |  | 18.4 |  |  |  |  | 16.5 |  |  |  |  | 17.0 |  |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |
| Selling and marketing |  |  | 3.0 |  |  |  |  | 2.8 |  |  |  |  | 3.0 |  |  |
| General and administrative |  |  | 6.4 |  |  |  |  | 5.5 |  |  |  |  | 5.8 |  |  |
| Research and development |  |  | 1.0 |  |  |  |  | 0.8 |  |  |  |  | 1.0 |  |  |
| Amortization of definite-lived intangibles |  |  | 1.5 |  |  |  |  | 1.6 |  |  |  |  | 1.8 |  |  |
| Gain on sale of SH E-MS property |  |  | (2.1 | ) |  |  |  | — |  |  |  |  | — |  |  |
| Restructuring charges |  |  | 0.2 |  |  |  |  | 0.2 |  |  |  |  | 0.8 |  |  |
| Impairment of goodwill |  |  | — |  |  |  |  | — |  |  |  |  | 3.3 |  |  |
| Total operating expenses |  |  | 10.0 |  |  |  |  | 10.9 |  |  |  |  | 15.7 |  |  |
| Operating income |  |  | 8.4 |  |  |  |  | 5.6 |  |  |  |  | 1.3 |  |  |
| Other (expense) income: |  |  |  |  |  |  |  |  |  |  |  |  |
| Interest expense |  |  | (1.8 | ) |  |  |  | (2.0 | ) |  |  |  | (3.5 | ) |  |
| Loss on extinguishment of debt |  |  | — |  |  |  |  | (0.7 | ) |  |  |  | — |  |  |
| Other, net |  |  | 0.7 |  |  |  |  | 0.2 |  |  |  |  | — |  |  |
| Total other expense, net |  |  | (1.1 | ) |  |  |  | (2.5 | ) |  |  |  | (3.5 | ) |  |
| Income (loss) from continuing operations before income taxes |  |  | 7.3 |  |  |  |  | 3.1 |  |  |  |  | (2.2 | ) |  |
| Income tax (provision) benefit |  |  | (3.5 | ) |  |  |  | (0.7 | ) |  |  |  | 1.4 |  |  |
| Net income (loss) from continuing operations |  |  | 3.8 |  | % |  |  | 2.4 |  | % |  |  | (0.8 | ) | % |

[0000950170-23-005994:mdna:54]
The Telephonics acquisition occurred on June 27, 2022. Accordingly, our fiscal year 2022 only includes Telephonics’ 2022 results of operations since the acquisition date. As of the fourth quarter of 2022, we completed our integration of Telephonics and reassessed our reportable segments, which resulted in the inclusion of Telephonics into our PCB reportable segment.

[0000950170-23-005994:mdna:55]
Net Sales

[0000950170-23-005994:mdna:56]
Total net sales increased $246.3 million, or 11.0%, to $2,495.0 million for the year ended January 2, 2023 from $2,248.7 million for the year ended January 3, 2022. Net sales for the PCB reportable segment increased $251.0 million, or 11.5%, to $2,437.9 million for the year ended January 2, 2023 from $2,186.9 million for the year ended January 3, 2022. This increase in PCB net sales was primarily due to the acquisition of Telephonics in June 2022, which accounted for $125.9 million in net sales for the year ended January 2, 2023 since the date of acquisition, as well as increased demand in our Medical/Industrial/Instrumentation, Data Center Computing, and Automotive end markets. The increase in PCB net sales also benefited from a 15.4% increase in the average price per square foot driven mainly by better product mix, higher pricing and premium revenue, partially offset by a 5.6% decrease in the volume of PCB shipments as compared to the year ended January 3, 2022. Net sales for the RF&S Components reportable segment decreased $1.5 million, or 2.5%, to $57.1 million for the year end January 2, 2023 from $58.6 million for the year ended January 3, 2022. The decrease in RF&S Components net sales was primarily due to lower demand.

[0000950170-23-005994:mdna:57]
Total net sales increased $143.4 million, or 6.8%, to $2,248.7 million for the year ended January 3, 2022 from $2,105.3 million for the year ended December 28, 2020. This increase primarily resulted from an increase in net sales for the PCB reportable segment of $206.0 million, or 10.4%, to $2,186.9 million for the year ended January 3, 2022 from $1,980.9 million for the year ended December 28, 2020. The increase in PCB net sales was primarily due to increased demand in our Automotive, Data Center Computing, and Medical/Industrial/Instrumentation end markets, partially offset by lower demand in our Aerospace and Defense and Networking end markets. Also driving the increase in PCB net sales was an increase in the volume of PCB shipments of 24.3% as compared to the year ended December 28, 2020. The benefit of this volume increase, however, was partially offset by an 11.9% decrease in the average price per square foot. Also contributing to the increase in total net sales was an increase in net sales for the RF&S Components reportable

[0000950170-23-005994:mdna:58]
segment of $13.9 million, or 31.2%, to $58.6 million for the year ended January 3, 2022 from $44.7 million for the year ended December 28, 2020. The increase in RF&S Components net sales was primarily due to increased demand in our Networking end market. Partially offsetting the PCB and RF&S Components increases was a $76.5 million reduction in net sales due to the closure of the two plants from our E-M Solutions segment.

[0000950170-23-005994:mdna:59]
For information regarding net sales by country, see Note 17 of the Notes to Consolidated Financial Statements.

[0000950170-23-005994:mdna:60]
Gross Margin

[0000950170-23-005994:mdna:61]
Overall gross margin increased to 18.4% for the year ended January 2, 2023 from 16.5% for the year ended January 3, 2022. The increase in overall gross margin was due to the increase in gross margin for the PCB reportable segment to 18.2% for the year ended January 2, 2023, from 16.3% for the year ended January 3, 2022. This increase was primarily due to better product mix, higher pricing and premium revenue, partially offset by higher labor costs, particularly in North America as we raised wages in the first quarter of 2022 to be more competitive. Gross margin for the RF&S Components reportable segment increased to 62.3% for the year ended January 2, 2023, from 52.6% for the year ended January 3, 2022, primarily due to favorable product mix.

[0000950170-23-005994:mdna:62]
Overall gross margin decreased to 16.5% for the year ended January 3, 2022 from 17.0% for the year ended December 28, 2020. The decrease in overall gross margin was due to the decrease in gross margin for the PCB reportable segment to 16.3% for the year ended January 3, 2022, from 18.1% for the year ended December 28, 2020, primarily due to higher raw material costs resulting primarily from increased commodity prices, principally copper, unfavorable foreign exchange rates which increased our cost of operations, and production and labor inefficiencies. We were able to mitigate most of these cost increases through higher revenue and production and spending efficiencies including savings realized from the closure of two of our E-M Solutions factories at the end of 2020. Gross margin for the RF&S Components reportable segment increased to 52.6% for the year ended January 3, 2022, from 45.9% for the year ended December 28, 2020, primarily due to higher sales.

[0000950170-23-005994:mdna:63]
Capacity utilization is a key driver for us, which is measured by the actual production as a percentage of maximum capacity. This measure is particularly important in our high-volume PCB facilities in Asia, as a significant portion of our operating costs are fixed in nature. Capacity utilization for the year ended January 2, 2023 in our Asia and North America PCB facilities was 81% and 43%, respectively, compared to 86% and 51%, respectively, for the year ended January 3, 2022. The decrease in capacity utilization in our Asia PCB facilities was caused by a decline in production volumes while the decrease in our North America PCB facilities was due to the additional plating capacity added in the fiscal year ended January 2, 2023, and direct labor shortages throughout the year in certain regions.

[0000950170-23-005994:mdna:64]
Selling and Marketing Expenses

[0000950170-23-005994:mdna:65]
Selling and marketing expenses increased $12.2 million to $75.2 million for the year ended January 2, 2023 from $63.0 million for the year ended January 3, 2022. As a percentage of net sales, selling and marketing expenses were 3.0% for the year ended January 2, 2023 as compared to 2.8% for the year ended January 3, 2022. The increase in selling and marketing expense was primarily due to $4.8 million of selling and marketing expenses incurred by Telephonics post acquisition and increases in labor costs and commission expense company wide.

[0000950170-23-005994:mdna:66]
Selling and marketing expenses decreased $0.9 million to $63.0 million for the year ended January 3, 2022 from $63.9 million for the year ended December 28, 2020. As a percentage of net sales, selling and marketing expenses were 2.8% for the year ended January 3, 2022 as compared to 3.0% for the year ended December 28, 2020. The decrease in selling and marketing expenses in 2021 was primarily due to a decrease in commission expense.

[0000950170-23-005994:mdna:67]
General and Administrative Expenses

[0000950170-23-005994:mdna:68]
General and administrative expenses increased $33.3 million to $158.2 million, or 6.4% of net sales, for the year ended January 2, 2023 from $124.9 million, or 5.5% of net sales, for the year ended January 3, 2022. The increase in expense was primarily due to $11.5 million of one-time costs incurred in connection with the acquisition of Telephonics on June 27, 2022 and $6.6 million of general and administrative expenses incurred by Telephonics post acquisition. In addition, there were increases in incentive compensation, labor costs, and bad debt. These increases were partially offset by gains on the sale of assets.

[0000950170-23-005994:mdna:69]
General and administrative expenses increased $2.4 million to $124.9 million, or 5.5% of net sales, for the year ended January 3, 2022 from $122.5 million, or 5.8% of net sales, for the year ended December 28, 2020. This increase was primarily due to an increase in labor costs and other general and administrative spending, including increased consulting and legal costs.

[0000950170-23-005994:mdna:70]
Gain on sale of SH E-MS Property

[0000950170-23-005994:mdna:71]
On December 22, 2022, land, building, and relevant ancillary assets related to our former SH E-MS manufacturing facility was expropriated by the Chinese government for a compensation fee of RMB 477.6 million ($69.2 million as of January 2, 2023) and we recorded a gain on the sale of $51.8 million. We will receive the proceeds as follows: 50% before March 30, 2023, 40% before June 30, 2023, and 10% before December 30, 2023.

[0000950170-23-005994:mdna:72]
Impairment of Goodwill

[0000950170-23-005994:mdna:73]
For the year ended December 28, 2020, we recorded a goodwill impairment charge of $69.2 million. See Note 5 of the Notes to Consolidated Financial Statements for further information.

[0000950170-23-005994:mdna:74]
Other Expense

[0000950170-23-005994:mdna:75]
Other expense, net decreased $28.4 million to $27.5 million for the year ended January 2, 2023 from $55.9 million for the year ended January 3, 2022. The decrease in other expense, net was primarily due to:

[0000950170-23-005994:mdna:76]
•	an increase in other income of $17.8 million related to the weakening of the Chinese RMB, which we utilize at our China facilities for employee-related expenses, RMB denominated purchases, and other costs of running our operations in China,

[0000950170-23-005994:mdna:77]
•	the absence of $15.2 million of loss on extinguishment of debt,

[0000950170-23-005994:mdna:78]
•	partially offset by the decrease in other income of $4.1 million related to the change in fair value of warrant liabilities.

[0000950170-23-005994:mdna:79]
Other expense, net decreased $18.4 million to $55.9 million for the year ended January 3, 2022 from $74.4 million for the year ended December 28, 2020. The decrease in other expense, net was primarily due to:

[0000950170-23-005994:mdna:80]
•	a decrease in interest expense of $27.7 million due to overall lower levels of debt outstanding,

[0000950170-23-005994:mdna:81]
•	an increase in other income of $4.2 million for the year ended January 3, 2022 related to the change in fair value of warrant liabilities,

[0000950170-23-005994:mdna:82]
•	partially offset by $15.2 million of loss on extinguishment of debt.

[0000950170-23-005994:mdna:83]
Income Taxes

[0000950170-23-005994:mdna:84]
Income tax expense increased $72.7 million to $88.3 million for the year ended January 2, 2023 from $15.6 million for the year ended January 3, 2022. The change in income tax from fiscal year 2021 to fiscal year 2022 was primarily due to an increase in the valuation allowance set up against U.S. deferred tax assets, an increase in pre-tax book income, and a gain on the sale of certain assets of our Shanghai E-MS subsidiary.

[0000950170-23-005994:mdna:85]
Our effective tax rate is primarily impacted by tax rates in China and Hong Kong, the US federal income tax rate, apportioned state income tax rates, the generation of credits and deductions available to us, as well as changes in valuation allowances, certain non-deductible items, global intangible low taxed income, and the establishment of a deferred tax liability related to unremitted foreign earnings.

[0000950170-23-005994:mdna:86]
The provision for income taxes increased $45.5 million to an income tax expense of $15.6 million for the year ended January 3, 2022 from an income tax benefit of $29.9 million for the year ended December 28, 2020. The change in income tax from a benefit to an expense in 2021 was primarily due to an increase in pre-tax book income, the absence of beneficial tax examination settlement in 2020, and an increase in the valuation allowance set up against certain state tax credits. The increase in tax expense was partially offset by a tax benefit related to the retroactive approval of the Company’s renewal application for High and New Tax Enterprise status for two of the Company’s manufacturing subsidiaries in China (including the impact on the respective subsidiaries’ deferred tax amounts).

[0000950170-23-005994:mdna:87]
Liquidity and Capital Resources

[0000950170-23-005994:mdna:88]
Our principal sources of liquidity have been cash provided by operations, the issuance of debt, and borrowings under our revolving credit facility. Our principal uses of cash have been to finance capital expenditures, finance acquisitions, fund working capital requirements, to repay debt obligations, and to repurchase common stock. We anticipate that financing capital expenditures, financing acquisitions, funding working capital requirements, servicing debt, and repurchasing common stock will be the principal demands on our cash in the future.

[0000950170-23-005994:mdna:89]
Cash flow provided by operating activities from continuing operations during the year ended January 2, 2023 was $272.9 million as compared to $176.6 million in the same period in fiscal year 2021. The increase in cash flow was primarily due to an increase in net income of $40.2 million from continuing operations and an overall decreased investment in working capital.

[0000950170-23-005994:mdna:90]
Net cash used in investing activities for continuing operations was approximately $395.5 million for the year ended January 2, 2023, primarily reflecting $298.3 million to fund the acquisition of Telephonics, $102.9 million for purchases of property, plant and equipment and other assets, less $6.0 million for proceeds from sale of property, plant and equipment and other assets. Net cash used in investing activities for continuing operations was approximately $84.1 million for the year ended January 3, 2022, primarily reflecting $82.0 million for purchases of property, plant and equipment and other assets, $3.2 million investment in an unconsolidated joint venture, less $1.4 million for proceeds from sale of property, plant and equipment and other assets.

[0000950170-23-005994:mdna:91]
Net cash used in financing activities for continuing operations during the year ended January 2, 2023 was $11.3 million, primarily reflecting repurchases of common stock of $35.4 million, cash used to settle warrants of $0.9 million, less customer deposits of $25.0 million. Net cash used in financing activities for continuing operations during the year ended January 3, 2022 was $7.2 million, primarily reflecting repayment of long-term debt of $425.8 million, repurchases of common stock of $64.7 million, capital equipment financing

[0000950170-23-005994:mdna:92]
of $7.5 million, payment of debt issuance costs of $6.0 million, and cash used to settle warrants of $3.2 million, less the proceeds from long-term debt borrowing of $500.0 million.

[0000950170-23-005994:mdna:93]
We received pre-tax proceeds from the sale of the Mobility business unit, net of cash disposed, of $507.5 million during the year ended December 28, 2020, which have been presented in the consolidated statements of cash flows within net cash provided by investing activities from discontinued operations.

[0000950170-23-005994:mdna:94]
As of January 2, 2023, we had cash and cash equivalents of approximately $402.7 million, of which approximately $161.7 million was held by our foreign subsidiaries, primarily in China. Should we choose to remit cash to the United States from our foreign locations, we may incur tax obligations which would reduce the amount of cash ultimately available to the United States. However, we believe there would be no material tax consequences not previously accrued for the repatriation of this cash.

[0000950170-23-005994:mdna:95]
Our 2023 capital expenditure plan is expected to be in the range of $140.0 million to $160.0 million.

[0000950170-23-005994:mdna:96]
Share Repurchases

[0000950170-23-005994:mdna:97]
On February 3, 2021, our board of directors authorized a share repurchase program allowing us to repurchase up to $100.0 million of our common stock. During 2022, we repurchased a total of 2.7 million shares of our common stock for $35.4 million (including commissions). As of January 2, 2023, there are no remaining amounts authorized for repurchase. From its commencement, we repurchased a total of 7.5 million shares of our common stock for $100.0 million under the share repurchase program.

[0000950170-23-005994:mdna:98]
Long-term Debt and Letters of Credit

[0000950170-23-005994:mdna:99]
As of January 2, 2023, we had $929.4 million of outstanding debt, net of discount and debt issuance costs, composed of $495.2 million of Senior Notes due March 2029, $404.2 million of a Term Loan due September 2024, and $30.0 million under the Asia Asset-Based Lending Credit Agreement (Asia ABL). Subsequent to January 2, 2023, we made an optional debt principal prepayment of $50.0 million on our Term Loan Facility.

[0000950170-23-005994:mdna:100]
Pursuant to the terms of the Term Loan Facility and Senior Notes due 2029, we are subject to certain affirmative and negative covenants, including limitations on indebtedness, corporate transactions, investments, dispositions, and share payments. Under the occurrence of certain events, under the U.S. Asset-Based Lending Credit Agreement (U.S. ABL) and Asia ABL (collectively, the ABL Revolving Loans), we are also subject to various financial covenants, including leverage and fixed charge coverage ratios. As of January 2, 2023, we were in compliance with the covenants under the Term Loan Facility, Senior Notes due 2029 and ABL Revolving Loans.

[0000950170-23-005994:mdna:101]
Based on our current level of operations, we believe that cash generated from operations, cash on hand and cash from the issuance of term and revolving debt will be adequate to meet our currently anticipated capital expenditure, debt service, and working capital needs for the next twelve months. Additional information regarding our indebtedness, including information about the credit available under our debt facilities, interest rates and other key terms of our outstanding indebtedness, is included in Note 7 of the Notes to Consolidated Financial Statements included in this Annual Report on Form 10-K.

[0000950170-23-005994:mdna:102]
Contractual Obligations and Commitments

[0000950170-23-005994:mdna:103]
As part of our ongoing operations, we enter into contractual arrangements that obligate us to make future cash payments. These obligations impact our liquidity and capital resource needs. Our estimated future obligations consist of long-term debt obligations, interest on debt obligations, derivative liabilities, purchase obligations, and leases as of January 2, 2023.

[0000950170-23-005994:mdna:104]
A summary of our long-term debt obligations as of January 2, 2023 is included in Note 7 of the Notes to Consolidated Financial Statements included in this Annual Report on Form 10-K.

[0000950170-23-005994:mdna:105]
Our aggregate interest on debt obligations as of January 2, 2023 amounted to $174.1 million, which are expected to be settled as follows: $46.6 million within 1 year, $59.1 million within 1-3 years, $40.0 million within 4-5 years, and $28.4 million after 5 years. For debt obligations based on variable rates, interest rates used are as of January 2, 2023.

[0000950170-23-005994:mdna:106]
Our derivative liabilities of $1.6 million as of January 2, 2023 are expected to be settled within one year.

[0000950170-23-005994:mdna:107]
We also have outstanding firm purchase orders with certain suppliers for the purchase of material and inventory. Orders for standard, or catalog, items can typically be canceled with little or no financial penalty. Our policy regarding non-standard or customized items dictates that such items are only ordered specifically for customers who have contractually assumed liability for the inventory, although exceptions are made to this policy in certain situations. In addition, a substantial portion of catalog items covered by our purchase orders are procured for specific customers based on their purchase orders or a forecast under which the customer has contractually assumed liability for such material. Accordingly, our liability from purchase obligations under these purchase orders is not expected to be significant.

[0000950170-23-005994:mdna:108]
A summary of our lease obligations as of January 2, 2023 is included in Note 2 of the Notes to Consolidated Financial Statements included in this Annual Report on Form 10-K.

[0000950170-23-005994:mdna:109]
Offset Agreements

[0000950170-23-005994:mdna:110]
Following the acquisition of Telephonics on June 27, 2022, we have and may continue to enter into industrial cooperation agreements, sometimes referred to as offset agreements, as a condition to obtaining orders for our products and services from customers in foreign countries. These agreements are intended to promote investment in the applicable country, and our obligations under these agreements may be satisfied through activities that do not require us to use cash, including transferring technology or providing manufacturing and other consulting support. The obligations under these agreements may also be satisfied through the use of cash for such activities as purchasing supplies from in-country vendors, setting up support centers, research and development investments, acquisitions, and building or leasing facilities for in-country operations, if applicable. The amount of the offset requirement is determined by contract value awarded and negotiated percentages with customers. As of January 2, 2023, we had outstanding offset agreements of approximately $20.2 million, some of which extend through 2028. Offset programs usually extend over several years and in some cases provide for penalties in the event we fail to perform in accordance with contract requirements. Historically, we have not paid any such penalties, and as of January 2, 2023, no such penalties have been paid.

[0000950170-23-005994:mdna:111]
Seasonality

[0000950170-23-005994:mdna:112]
We tend to experience modest seasonal softness in the first and third quarters due to holidays and vacation periods in China and North America, respectively, which limit production leading to stronger revenue levels in the second and fourth quarters.

[0000950170-23-005994:mdna:113]
Recently Issued Accounting Standards

[0000950170-23-005994:mdna:114]
For a description of recently adopted and issued accounting standards, including the respective dates of adoption and expected effects on our results of operations and financial condition, see Note 1 of the Notes to Consolidated Financial Statements.
