# TTMI 8-K — 0001193125-23-028382 filed 2023-02-08

## item codes, every 8-K on or before 2023-03-03

- 2023-02-08 0001193125-23-028382 — 2.02, 2.05, 7.01, 9.01
- 2022-11-03 0001193125-22-276659 — 2.02, 9.01 — amendment of 0001193125-22-275849
- 2022-11-02 0001193125-22-275849 — 2.02, 9.01
- 2022-09-08 0001193125-22-241001 — 9.01 — amendment of 0001193125-22-182826
- 2022-08-03 0001193125-22-211262 — 2.02, 9.01
- 2022-06-27 0001193125-22-182826 — 2.01, 7.01, 9.01
- 2022-05-16 0001193125-22-151684 — 5.07
- 2022-05-04 0001193125-22-140455 — 2.02, 9.01
- 2022-04-18 0001193125-22-108017 — 1.01, 7.01, 9.01
- 2022-03-01 0001193125-22-059877 — 7.01, 9.01
- 2022-02-09 0001193125-22-032669 — 2.02, 9.01
- 2021-10-27 0001193125-21-309324 — 2.02, 9.01
- 2021-07-28 0001193125-21-227406 — 2.02, 9.01
- 2021-06-14 0001193125-21-189568 — 5.02, 9.01
- 2021-05-13 0001193125-21-159545 — 2.02, 5.02, 5.07, 9.01
- 2021-04-28 0001193125-21-136849 — 2.02, 9.01
- 2021-03-16 0001193125-21-083011 — 1.02, 8.01
- 2021-03-10 0001193125-21-076246 — 1.01, 2.03, 3.03, 7.01, 9.01
- 2021-02-24 0001193125-21-054812 — 7.01, 9.01
- 2021-02-23 0001193125-21-051549 — 7.01, 9.01
- 2021-02-03 0001193125-21-027322 — 2.02, 8.01, 9.01
- 2020-12-15 0001193125-20-318208 — 7.01, 9.01
- 2020-10-28 0001193125-20-279980 — 2.02, 9.01
- 2020-09-04 0001193125-20-239645 — 5.02
- 2020-07-29 0001193125-20-203110 — 2.02, 9.01
- 2020-05-08 0001193125-20-137566 — 5.07
- 2020-05-04 0001193125-20-131366 — 7.01, 9.01
- 2020-04-29 0001193125-20-126358 — 2.05, 7.01, 9.01
- 2020-04-29 0001193125-20-126117 — 2.02, 9.01
- 2020-04-23 0001193125-20-117365 — 2.01, 7.01, 9.01
- 2020-02-05 0001193125-20-025365 — 2.02, 9.01
- 2020-01-31 0001193125-20-021278 — 5.02
- 2020-01-22 0001193125-20-012011 — 1.01, 7.01, 9.01
- 2019-10-30 0001193125-19-278973 — 2.02, 9.01
- 2019-08-19 0001193125-19-224091 — 5.02, 9.01
- 2019-07-31 0001193125-19-208689 — 2.02, 9.01
- 2019-07-24 0001193125-19-201401 — 1.01, 2.03
- 2019-06-13 0001193125-19-171943 — 7.01, 9.01
- 2019-06-06 0001193125-19-167332 — 1.01, 2.03, 3.03, 7.01, 9.01
- 2019-05-09 0001193125-19-143113 — 5.07
- 2019-05-01 0001193125-19-132977 — 2.02, 9.01
- 2019-02-06 0001193125-19-029540 — 2.02, 9.01
- 2019-01-15 0001193125-19-009142 — 2.02, 9.01
- 2018-10-30 0001193125-18-312212 — 2.02, 9.01
- 2018-10-22 0001193125-18-303926 — 5.02
- 2018-09-06 0001193125-18-268231 — 5.02, 9.01
- 2018-08-01 0001193125-18-234997 — 2.02, 9.01
- 2018-06-29 0001193125-18-209635 — 9.01 — amendment of 0001193125-18-120583
- 2018-05-29 0001193125-18-176976 — 7.01, 9.01
- 2018-05-10 0001193125-18-159394 — 5.07
- 2018-05-09 0001193125-18-157596 — 5.02
- 2018-05-02 0001193125-18-148650 — 2.02, 9.01
- 2018-04-18 0001193125-18-120583 — 1.01, 2.01, 2.03, 7.01, 9.01
- 2018-02-21 0001193125-18-052169 — 8.01, 9.01
- 2018-02-20 0001193125-18-050385 — 5.02, 9.01
- 2018-02-09 0001193125-18-036966 — 7.01, 9.01
- 2018-02-07 0001193125-18-034744 — 2.02, 9.01
- 2017-12-14 0001193125-17-369625 — 1.01, 2.03, 9.01
- 2017-12-04 0001193125-17-359439 — 1.01, 7.01, 9.01
- 2017-11-01 0001193125-17-329425 — 2.02, 9.01
- 2017-09-29 0001193125-17-298999 — 1.01, 2.03, 3.03, 7.01, 9.01
- 2017-09-15 0001193125-17-286491 — 7.01, 9.01
- 2017-09-11 0001193125-17-281193 — 7.01, 9.01
- 2017-09-06 0001193125-17-277536 — 7.01, 9.01
- 2017-08-02 0001193125-17-245823 — 2.02, 9.01
- 2017-05-18 0001193125-17-173896 — 5.02, 5.07
- 2017-05-08 0001193125-17-162548 — 2.02, 9.01
- 2017-03-01 0001193125-17-063931 — 1.01, 1.02, 5.02
- 2017-02-08 0001193125-17-034652 — 2.02, 9.01
- 2016-11-18 0001193125-16-772305 — 8.01, 9.01
- 2016-10-26 0001193125-16-747948 — 2.02, 9.01
- 2016-10-20 0001193125-16-742905 — 5.02
- 2016-10-05 0001193125-16-731552 — 5.02, 9.01
- 2016-09-27 0001193125-16-720828 — 1.01, 2.03, 7.01, 9.01
- 2016-07-27 0001193125-16-659983 — 2.02, 9.01
- 2016-05-23 0001193125-16-599342 — 7.01, 9.01
- 2016-05-18 0001193125-16-594656 — 5.02, 5.03, 5.07, 9.01
- 2016-04-27 0001171843-16-009432 — 2.02, 9.01
- 2016-03-08 0001193125-16-495457 — 5.03, 7.01, 9.01
- 2016-02-09 0001193125-16-454281 — 8.01, 9.01
- 2016-02-04 0001171843-16-007659 — 2.02, 9.01
- 2016-01-04 0001193125-16-418740 — 1.01, 9.01
- 2015-12-11 0001193125-15-400867 — 5.02, 9.01
- 2015-10-30 0001171843-15-005835 — 2.02, 7.01 — amendment of 0001171843-15-005766
- 2015-10-28 0001171843-15-005766 — 2.02, 9.01
- 2015-09-29 0001193125-15-331517 — 2.02, 2.05, 2.06, 9.01
- 2015-08-05 0001171843-15-004361 — 2.02, 9.01
- 2015-07-31 0001193125-15-272962 — 9.01 — amendment of 0001193125-15-210734
- 2015-06-02 0001193125-15-210734 — 1.01, 1.02, 2.01, 2.03, 7.01, 9.01
- 2015-05-29 0001193125-15-206622 — 1.01, 2.03, 9.01
- 2015-05-20 0001171843-15-002975 — 7.01, 9.01
- 2015-05-19 0001193125-15-193434 — 5.07, 9.01
- 2015-05-05 0001171843-15-002499 — 7.01, 9.01
- 2015-04-29 0001171843-15-002307 — 2.02, 9.01
- 2015-04-21 0001193125-15-139239 — 7.01, 9.01
- 2015-04-21 0001171843-15-002065 — 2.02, 9.01
- 2015-02-04 0001171843-15-000599 — 2.02, 9.01
- 2015-01-20 0001193125-15-014019 — 7.01, 9.01
- 2014-12-30 0001193125-14-457111 — 7.01, 9.01
- 2014-12-15 0001193125-14-442645 — 1.01, 9.01
- 2014-12-04 0001193125-14-433658 — 8.01, 9.01
- 2014-11-18 0001193125-14-415889 — 7.01, 9.01
- 2014-10-29 0001171843-14-005051 — 2.02, 9.01
- 2014-10-27 0001193125-14-383428 — 1.01, 9.01
- 2014-09-22 0001193125-14-348697 — 1.01, 7.01, 9.01
- 2014-08-05 0001193125-14-295808 — 1.01, 5.02, 9.01
- 2014-07-30 0001171843-14-003548 — 2.02, 9.01
- 2014-04-30 0001171843-14-002017 — 2.02, 9.01
- 2014-04-25 0001193125-14-160146 — 5.02, 5.07, 9.01
- 2014-04-10 0001171843-14-001656 — 2.02, 9.01
- 2014-03-04 0001193125-14-082534 — 4.01, 9.01
- 2014-02-05 0001171843-14-000553 — 2.02, 9.01
- 2014-01-14 0001193125-14-010922 — 1.01, 2.03, 3.02, 8.01, 9.01
- 2013-12-27 0001193125-13-486144 — 5.02, 9.01
- 2013-12-20 0001193125-13-481141 — 1.01, 1.02, 2.03, 3.02, 8.01, 9.01
- 2013-12-17 0001193125-13-476207 — 5.03
- 2013-10-30 0001193125-13-418572 — 2.02, 5.02, 9.01
- 2013-09-12 0001193125-13-365420 — 2.05
- 2013-08-14 0001193125-13-334349 — 7.01, 9.01
- 2013-08-01 0001171843-13-003138 — 2.02, 9.01
- 2013-06-25 0001193125-13-270725 — 5.02, 9.01
- 2013-05-02 0001171843-13-001746 — 2.02, 9.01
- 2013-04-29 0001193125-13-182083 — 5.02, 5.07, 9.01
- 2013-03-18 0001193125-13-111308 — 1.01, 7.01, 9.01
- 2013-03-06 0001193125-13-093625 — 5.02, 9.01
- 2013-03-01 0001193125-13-087439 — 2.02 — amendment of 0001171843-13-000414
- 2013-02-28 0001193125-13-084764 — 5.02
- 2013-02-05 0001171843-13-000414 — 2.02, 9.01
- 2013-01-31 0001193125-13-032848 — 5.02, 9.01
- 2013-01-17 0001193125-13-015928 — 7.01, 9.01
- 2013-01-16 0001193125-13-014581 — 2.02, 9.01
- 2012-12-11 0001193125-12-498644 — 5.02, 9.01
- 2012-11-15 0001193125-12-472451 — 7.01, 9.01
- 2012-11-01 0001171843-12-003890 — 2.02, 9.01
- 2012-09-19 0001193125-12-396969 — 1.01, 2.03, 7.01, 9.01
- 2012-09-11 0001193125-12-388130 — 7.01, 9.01
- 2012-07-31 0001171843-12-002829 — 2.02, 9.01
- 2012-05-15 0001193125-12-233501 — 7.01, 9.01
- 2012-05-01 0001171843-12-001574 — 2.02, 9.01
- 2012-04-27 0001193125-12-191623 — 5.07
- 2012-03-01 0001193125-12-090623 — 2.02 — amendment of 0001171843-12-000382
- 2012-02-07 0001171843-12-000382 — 2.02, 9.01
- 2012-01-19 0001193125-12-016588 — 5.02, 9.01
- 2011-11-15 0000950123-11-098812 — 7.01, 9.01
- 2011-11-02 0001171843-11-003248 — 2.02, 9.01
- 2011-09-28 0000950123-11-087344 — 7.01, 9.01
- 2011-09-19 0000950123-11-085128 — 5.02, 9.01
- 2011-09-15 0000950123-11-084704 — 5.07 — amendment of 0000950123-11-054296
- 2011-08-04 0001171843-11-002356 — 2.02, 9.01
- 2011-07-27 0000950123-11-068987 — 1.01, 2.03, 9.01
- 2011-06-21 0000950123-11-060477 — 7.01, 9.01
- 2011-06-06 0000950123-11-056971 — 5.03, 9.01
- 2011-05-26 0000950123-11-054296 — 5.07
- 2011-05-10 0000950123-11-048462 — 8.01, 9.01
- 2011-05-05 0001171843-11-001344 — 2.02, 9.01
- 2011-03-22 0000950123-11-027824 — 7.01, 9.01
- 2011-03-18 0000950123-11-026913 — 4.01
- 2011-03-18 0000950123-11-026910 — 4.01, 9.01 — amendment, the index does not say of what
- 2011-03-02 0000950123-11-020941 — 5.03, 9.01
- 2011-02-10 0001171843-11-000391 — 2.02, 9.01
- 2011-01-13 0000950123-11-002528 — 7.01, 9.01
- 2011-01-13 0000950123-11-002446 — 2.02, 9.01
- 2010-11-29 0000950123-10-109448 — 4.01, 9.01 — amendment, the index does not say of what
- 2010-11-17 0000950123-10-106706 — 4.01
- 2010-11-15 0000950123-10-105479 — 5.02, 9.01
- 2010-11-04 0001171843-10-002324 — 2.02, 9.01
- 2010-10-22 0000950123-10-095179 — 1.01, 9.01
- 2010-10-04 0000950123-10-090949 — 1.01, 5.03, 9.01
- 2010-08-05 0001171843-10-001587 — 2.02, 9.01
- 2010-08-05 0000950123-10-073258 — 1.01, 2.03, 9.01
- 2010-08-05 0000950123-10-073256 — 9.01 — amendment of 0000950123-10-034163
- 2010-07-12 0000950123-10-064794 — 5.02, 8.01, 9.01
- 2010-06-10 0000950123-10-057166 — 7.01, 9.01
- 2010-06-02 0000950123-10-055111 — 1.01, 5.07, 9.01
- 2010-05-06 0001171843-10-000819 — 2.02, 9.01
- 2010-04-26 0000950123-10-037806 — 8.01, 9.01 — amendment of 0000950123-10-034163
- 2010-04-13 0000950123-10-034163 — 1.01, 2.01, 2.03, 5.02, 7.01, 9.01
- 2010-03-30 0000950123-10-030123 — 1.01, 5.02, 9.01
- 2010-03-24 0000950123-10-027317 — 1.01, 5.02, 9.01
- 2010-03-16 0000950123-10-024853 — 7.01, 9.01 — amendment of 0001171843-10-000140
- 2010-03-15 0000950123-10-024637 — 5.07
- 2010-02-04 0001171843-10-000140 — 2.02, 9.01
- 2010-02-02 0000950123-10-007780 — 8.01, 9.01
- 2010-01-13 0000950123-10-002245 — 7.01, 9.01
- 2009-12-23 0000950123-09-073069 — 1.01, 9.01
- 2009-12-15 0000950123-09-070868 — 8.01, 9.01
- 2009-11-16 0000950123-09-062630 — 1.01, 7.01, 9.01
- 2009-11-04 0001171843-09-001103 — 2.02, 9.01
- 2009-09-04 0000950123-09-041133 — 2.05, 9.01
- 2009-07-29 0001171843-09-000743 — 2.02, 9.01
- 2009-06-09 0000950123-09-012507 — 7.01, 9.01
- 2009-04-30 0001171843-09-000427 — 2.02, 9.01
- 2009-04-28 0001362310-09-005960 — 8.01
- 2009-02-19 0001362310-09-002454 — 5.03, 9.01
- 2009-02-10 0001171843-09-000123 — 2.02, 9.01
- 2009-01-16 0000950153-09-000040 — 2.05, 9.01
- 2009-01-08 0000950153-09-000023 — 7.01, 9.01
- 2008-10-29 0001157523-08-008533 — 2.02, 9.01
- 2008-07-29 0001157523-08-005998 — 2.02, 9.01
- 2008-05-22 0000950153-08-001035 — 1.01, 2.03, 3.02, 9.01
- 2008-05-22 0000950153-08-001034 — 7.01, 9.01
- 2008-05-15 0000950153-08-000987 — 1.01, 1.02, 2.03, 3.02, 9.01
- 2008-04-30 0001157523-08-003483 — 2.02, 9.01
- 2008-02-07 0001157523-08-001077 — 2.02, 9.01
- 2008-01-08 0000950153-08-000033 — 7.01, 9.01
- 2007-11-15 0000950153-07-002440 — 7.01, 9.01
- 2007-11-14 0000950153-07-002426 — 7.01, 9.01
- 2007-11-14 0000950153-07-002421 — 5.03, 9.01
- 2007-10-31 0001157523-07-010491 — 2.02, 9.01
- 2007-10-02 0000950153-07-002094 — 7.01, 9.01
- 2007-07-31 0000950153-07-001622 — 2.02, 9.01
- 2007-06-13 0000950153-07-001327 — 7.01, 9.01
- 2007-05-02 0000950153-07-000941 — 2.02, 9.01
- 2007-04-12 0000950153-07-000763 — 5.02, 9.01
- 2007-02-15 0000950153-07-000339 — 2.02, 9.01
- 2007-01-11 0000950153-07-000076 — 7.01, 9.01
- 2007-01-10 0000950153-07-000071 — 2.01, 9.01 — amendment, the index does not say of what
- 2006-12-11 0000950153-06-002967 — 2.05, 9.01
- 2006-11-15 0000950153-06-002843 — 7.01, 9.01
- 2006-11-14 0000950153-06-002837 — 7.01, 9.01
- 2006-11-02 0000950153-06-002682 — 1.01, 1.02, 2.03, 9.01
- 2006-11-01 0000950153-06-002668 — 2.02, 9.01
- 2006-10-30 0000950124-06-006210 — 2.01, 9.01
- 2006-08-04 0000950153-06-002025 — 1.01, 9.01
- 2006-07-26 0000950153-06-001937 — 2.02, 9.01
- 2006-06-28 0000950153-06-001716 — 1.01, 9.01
- 2006-06-13 0000950153-06-001597 — 7.01, 9.01
- 2006-04-26 0000950153-06-001079 — 2.02, 9.01
- 2006-02-08 0001104659-06-006985 — 2.02, 9.01
- 2006-01-12 0001104659-06-001893 — 7.01, 9.01
- 2005-12-05 0001104659-05-058918 — 1.01, 5.02, 9.01
- 2005-10-26 0001104659-05-050306 — 2.02, 9.01
- 2005-09-20 0001104659-05-044954 — 8.01
- 2005-08-30 0001104659-05-042053 — 3.03, 8.01, 9.01
- 2005-07-27 0001104659-05-034437 — 2.02, 5.02, 9.01
- 2005-07-21 0001104659-05-033462 — 1.01, 1.02, 2.03, 9.01
- 2005-06-13 0001104659-05-027969 — 8.01
- 2005-06-08 0001104659-05-027364 — 7.01, 9.01
- 2005-05-17 0001104659-05-024118 — 7.01, 9.01
- 2005-05-12 0001104659-05-022993 — 7.01, 9.01
- 2005-05-11 0001104659-05-022606 — 1.01, 9.01
- 2005-05-02 0001104659-05-019649 — 2.02, 5.02, 9.01
- 2005-04-26 0001104659-05-018233 — 7.01, 9.01
- 2005-02-08 0001104659-05-004642 — 2.02, 9.01
- 2005-01-12 0001104659-05-001194 — 7.01, 9.01
- 2004-12-22 0001104659-04-040933 — 5.02
- 2004-12-08 0001104659-04-038850 — 7.01, 9.01
- 2004-10-26 0001104659-04-031931 — 2.02, 9.01
- 2004-10-01 0001104659-04-029361 — 5.02
- 2004-08-02 0001104659-04-021785 — 9
- 2004-07-29 0001104659-04-021529 — 12
- 2004-05-06 0001104659-04-012742 — 9
- 2004-04-26 0001104659-04-011228 — 12
- 2004-02-03 0001104659-04-002424 — 9
- 2004-01-28 0001104659-04-001980 — 12
- 2004-01-09 0001104659-04-000457 — 9
- 2003-10-21 0001104659-03-023304 — 12
- 2003-07-29 0001104659-03-015999 — 12
- 2003-05-08 0001104659-03-008647 — 9
- 2003-05-08 0001104659-03-008462 — 9
- 2003-05-01 0001104659-03-007866 — 9
- 2003-03-07 0001104659-03-003816 — 2, 7 — amendment of 0000950153-02-002190
- 2002-12-27 0000950153-02-002190 — 2, 7
- 2002-05-17 0000912057-02-021145 — 4, 7
- 2001-12-21 0000912057-01-544281 — 7
- 2000-10-27 0000912057-00-046109 — 5

## late-filing notifications on or before 2023-03-03

- none on or before 2023-03-03

## item 2.02 — earnings release, exhibit 99.1

[0001193125-23-028382:8k_2_02:1]
EX-99.1
2
d426497dex991.htm
EX-99.1

[0001193125-23-028382:8k_2_02:2]
EX-99.1

[0001193125-23-028382:8k_2_02:3]
| TTM Technologies, Inc., Q4’22 |  |  |  | Contact: Sameer Desai, Vice President, Corporate Development & Investor Relations Sameer.desai@ttmtech.com 714-327-3050 |

[0001193125-23-028382:8k_2_02:4]
Exhibit 99.1

[0001193125-23-028382:8k_2_02:5]
TTM Technologies, Inc. Reports Fiscal Fourth Quarter and 2022 Results

[0001193125-23-028382:8k_2_02:6]
Santa Ana, CA – February 8, 2023– TTM Technologies, Inc. (NASDAQ: TTMI), a leading global manufacturer of technology solutions including engineered
systems, radio frequency (“RF”) components and RF microwave/microelectronic assemblies, and printed circuit boards (“PCB”), today reported results for the fourth quarter and fiscal 2022, which ended on January 2, 2023.

[0001193125-23-028382:8k_2_02:7]
Fourth Quarter 2022 Highlights

[0001193125-23-028382:8k_2_02:8]
|  | - |  | Net sales were $617.2 million |

[0001193125-23-028382:8k_2_02:9]
|  | - |  | GAAP net income of $6.0 million, or $0.06 per diluted share |

[0001193125-23-028382:8k_2_02:10]
|  | - |  | Non-GAAP net income was $42.7 million, or $0.41 per diluted share |

[0001193125-23-028382:8k_2_02:11]
|  | - |  | Operating cash flow of $77.6 million; free cash flow of $56.8 million |

[0001193125-23-028382:8k_2_02:12]
|  | - |  | Announced consolidation of manufacturing footprint |

[0001193125-23-028382:8k_2_02:13]
Fourth Quarter 2022 GAAP Financial Results

[0001193125-23-028382:8k_2_02:14]
Net sales for the fourth quarter
of 2022 were $617.2 million, compared to $598.1 million in the fourth quarter of 2021.

[0001193125-23-028382:8k_2_02:15]
GAAP operating income for the fourth quarter of 2022
was $97.6 million and includes a gain of $51.8 million in December 2022 from the sale of the property occupied by our former Shanghai E-MS entity. This compares to GAAP operating income
of $33.1 million in the fourth quarter of 2021.

[0001193125-23-028382:8k_2_02:16]
GAAP net income for the fourth quarter of 2022 was $6.0 million, or $0.06 per diluted
share, compared to GAAP net income of $8.4 million, or $0.08 per diluted share in the fourth quarter of 2021. Our fourth quarter 2022 results include a tax reserve of $51.7 million to establish a valuation allowance for
certain U.S. deferred tax items.

[0001193125-23-028382:8k_2_02:17]
Fourth Quarter 2022 Non-GAAP Financial Results

[0001193125-23-028382:8k_2_02:18]
On a non-GAAP basis, net income for the fourth quarter of 2022 was $42.7 million, or $0.41 per diluted share. This
compares to non-GAAP net income of $36.2 million, or $0.34 per diluted share, for the fourth quarter of 2021.

[0001193125-23-028382:8k_2_02:19]
Adjusted
EBITDA in the fourth quarter of 2022 was $81.6 million, or 13.2% of sales compared to adjusted EBITDA of $70.4 million, or 11.8% of sales for the fourth quarter of 2021.

[0001193125-23-028382:8k_2_02:20]
“TTM delivered non-GAAP earnings above the midpoint of guidance. Of particular note, we saw strong cash flow in the fourth quarter of $77.6 million, which allowed
us to repay a portion of our Term Loan B on January 3rd, 2023, and reduce our net leverage to 1.5x, below our 2x target,” said Tom Edman, CEO of TTM. “We also saw the second quarter in a
row of record bookings of $464.3 million in the Aerospace and Defense end market,” concluded Mr. Edman.

[0001193125-23-028382:8k_2_02:21]
Full Year Fiscal 2022 Results

[0001193125-23-028382:8k_2_02:22]
Net sales for fiscal year 2022 increased to $2.50 billion from $2.25 billion in fiscal year 2021, an 11.0% increase. Excluding approximately six months from
the contribution of Telephonics, revenues grew organically 5.4% in 2022 over 2021.

[0001193125-23-028382:8k_2_02:23]
GAAP operating income for fiscal year 2022 was $210.4 million, an increase
from GAAP operating income of $126.0 million in fiscal year 2021.

[0001193125-23-028382:8k_2_02:24]
| TTM Technologies, Inc., Q4’22 |  |  |  | Contact: Sameer Desai, Vice President, Corporate Development & Investor Relations Sameer.desai@ttmtech.com 714-327-3050 |

[0001193125-23-028382:8k_2_02:25]
GAAP net income for fiscal year 2022 was $94.6 million, or $0.91 per diluted share, compared to GAAP net income of
$54.4 million, or $0.50 per diluted share, in fiscal year 2021.

[0001193125-23-028382:8k_2_02:26]
On a non-GAAP basis, net income for fiscal year 2022 was $181.2 million, or $1.74
per diluted share. This compares to fiscal year 2021 non-GAAP net income of $138.0 million, or $1.28 per diluted share.

[0001193125-23-028382:8k_2_02:27]
Adjusted EBITDA for fiscal year
2022 was $343.1 million, or 13.8 percent of net sales, compared to $275.6 million, or 12.3 percent of net sales, for fiscal year 2021. Cash flow from operations for fiscal year 2022 was $272.9 million.

[0001193125-23-028382:8k_2_02:28]
“We delivered solid results in 2022 with revenues growing organically 5.4% year on year, despite supply chain, labor inflation and availability, and COVID-19 challenges,” continued Edman. “In addition, we closed the acquisition of Telephonics, increasing our revenues from the Aerospace and Defense end market to approximately one billion dollar annual
run rate and approximately 40% of total company revenues. Finally, in 2022, we generated $272.9 million in operating cash flow which enabled us to purchase Telephonics and strengthen our balance sheet, while returning capital to our
shareholders.”

[0001193125-23-028382:8k_2_02:29]
Business Outlook

[0001193125-23-028382:8k_2_02:30]
While demand in the Aerospace and
Defense market remains strong, we have seen a reduction in bookings in our commercial end markets due to inventory reductions, weaker end market demand and production inefficiencies in our Asia Pacific manufacturing facilities due to Chinese New
Year. As a result, TTM estimates that revenue for the first quarter of 2023 will be in the range of $550 million to $590 million, and non-GAAP net income will be in the range of $0.16 to $0.22
per diluted share. We also announced a plan for the consolidation of our manufacturing footprint in a press release issued today, February 8th, after the market close.

[0001193125-23-028382:8k_2_02:31]
Live Webcast/Conference Call

[0001193125-23-028382:8k_2_02:32]
TTM will host a conference call and webcast to
discuss fourth quarter and 2022 results and the first quarter 2023 outlook as well as the consolidation of its manufacturing footprint on Wednesday, February 8th, 2023 at 4:30 p.m. Eastern Time (1:30 p.m. Pacific Time). The conference call will
include forward-looking statements.

[0001193125-23-028382:8k_2_02:33]
Access to the conference call is available by clicking on the registration link TTM Technologies, Inc. fourth quarter fiscal year 2022 conference call. Registering participants will receive dial in information and a unique
PIN to join the call. Participants can register at any time up to the start of the conference call. The conference call also will be webcast on TTM’s website at www.ttm.com.

[0001193125-23-028382:8k_2_02:34]
To Access a Replay of the Webcast

[0001193125-23-028382:8k_2_02:35]
The replay of the webcast will remain
accessible for one week following the live event on TTM’s website at www.ttm.com.

[0001193125-23-028382:8k_2_02:36]
About TTM

[0001193125-23-028382:8k_2_02:37]
TTM Technologies, Inc. is a leading global manufacturer of technology solutions including engineered systems, RF components and RF microwave/microelectronic assemblies,
and quick-turn and technologically advanced PCBs. TTM stands for time-to-market, representing how TTM’s time-critical,
one-stop manufacturing services enable customers to shorten the time required to develop new products and bring them to market. Additional information can be found at www.ttm.com.

[0001193125-23-028382:8k_2_02:38]
Forward-Looking Statements

[0001193125-23-028382:8k_2_02:39]
The preliminary financial results included in
this press release represent the most current information available to management. The company’s actual results when disclosed in its Form 10-K may differ from

[0001193125-23-028382:8k_2_02:40]
| TTM Technologies, Inc., Q4’22 |  |  |  | Contact: Sameer Desai, Vice President, Corporate Development & Investor Relations Sameer.desai@ttmtech.com 714-327-3050 |

[0001193125-23-028382:8k_2_02:41]
these preliminary results as a result of the completion of the company’s financial closing procedures; final adjustments; completion of the review by the company’s independent
registered accounting firm; and other developments that may arise between now and the disclosure of the final results. This release contains forward-looking statements that relate to future events or performance. TTM cautions you that such
statements are simply predictions and actual events or results may differ materially. These statements reflect TTM’s current expectations, and TTM does not undertake to update or revise these forward looking statements, even if experience or
future changes make it clear that any projected results expressed or implied in this or other TTM statements will not be realized. Further, these statements involve risks and uncertainties, many of which are beyond TTM’s control, which could
cause actual results to differ materially from the forward-looking statements. These risks and uncertainties include, but are not limited to, the impact of COVID-19, general market and economic conditions,
including interest rates, currency exchange rates and consumer spending, demand for TTM’s products, market pressures on prices of TTM’s products, warranty claims, changes in product mix, contemplated significant capital expenditures and
related financing requirements, TTM’s dependence upon a small number of customers and other factors set forth in the “Risk Factors” and “Management’s Discussion and Analysis of Financial Condition and Results of
Operations” sections of the Company’s public reports filed with the SEC.

[0001193125-23-028382:8k_2_02:42]
About Our Non-GAAP Financial Measures

[0001193125-23-028382:8k_2_02:43]
This release includes information about TTM’s adjusted EBITDA, non-GAAP net income and non-GAAP earnings per share, all of which are non-GAAP financial measures. TTM presents non-GAAP financial information to enable
investors to see TTM through the eyes of management and to provide better insight into TTM’s ongoing financial performance.

[0001193125-23-028382:8k_2_02:44]
A material limitation associated
with the use of the above non-GAAP financial measures is that they have no standardized measurement prescribed by GAAP and may not be comparable to similar non-GAAP
financial measures used by other companies. TTM compensates for these limitations by providing full disclosure of each non-GAAP financial measure and reconciliation to the most directly comparable GAAP
financial measure. However, the non-GAAP financial measures should not be considered in isolation from, or as a substitute for, financial information prepared in accordance with GAAP.

[0001193125-23-028382:8k_2_02:45]
With respect to the Company’s outlook for non-GAAP net income per diluted share, we are unable to predict with reasonable
certainty or without unreasonable effort certain items that may affect a comparable measure calculated and presented in accordance with GAAP. Our expected non-GAAP net income per diluted share excludes
primarily the future impact of restructuring actions, impairment charges, unusual gains and losses, and tax adjustments. These reconciling items are highly variable and difficult to predict due to various factors outside of management’s control
and could have a material impact on our future period net income per diluted share calculated and presented in accordance with GAAP. Accordingly, a reconciliation of non-GAAP net income per diluted share to a
comparable measure calculated and presented in accordance with GAAP is not available without unreasonable effort and has not been provided.

[0001193125-23-028382:8k_2_02:46]
- Tables
Follow -

[0001193125-23-028382:8k_2_02:47]
TTM TECHNOLOGIES, INC.

[0001193125-23-028382:8k_2_02:48]
Selected Unaudited Financial Information

[0001193125-23-028382:8k_2_02:49]
(In thousands, except per share data)

[0001193125-23-028382:8k_2_02:50]
|  |  | Fourth Quarter |  |  | Full Year |  |
|  |  | 2022 |  |  | 2021 |  |  | 2022 |  |  | 2021 |  |
| CONSOLIDATED CONDENSED STATEMENTS OF OPERATIONS |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Net sales |  | $ | 617,156 |  |  | $ | 598,141 |  |  | $ | 2,495,046 |  |  | $ | 2,248,740 |  |
| Cost of goods sold |  |  | 495,754 |  |  |  | 500,819 |  |  |  | 2,037,081 |  |  |  | 1,876,729 |  |
| Gross profit |  |  | 121,402 |  |  |  | 97,322 |  |  |  | 457,965 |  |  |  | 372,011 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Selling and marketing |  |  | 19,529 |  |  |  | 16,271 |  |  |  | 75,182 |  |  |  | 63,016 |  |
| General and administrative |  |  | 36,317 |  |  |  | 33,790 |  |  |  | 158,180 |  |  |  | 124,865 |  |
| Research and development |  |  | 6,698 |  |  |  | 5,071 |  |  |  | 24,808 |  |  |  | 18,146 |  |
| Gain on sale of SH E-MS Property |  |  | (51,804 | ) |  |  | — |  |  |  | (51,804 | ) |  |  | — |  |
| Amortization of definite-lived intangibles |  |  | 10,275 |  |  |  | 8,911 |  |  |  | 37,097 |  |  |  | 35,748 |  |
| Restructuring charges |  |  | 2,827 |  |  |  | 211 |  |  |  | 4,094 |  |  |  | 4,245 |  |
| Total operating expenses |  |  | 23,842 |  |  |  | 64,254 |  |  |  | 247,557 |  |  |  | 246,020 |  |
| Operating income |  |  | 97,560 |  |  |  | 33,068 |  |  |  | 210,408 |  |  |  | 125,991 |  |
| Interest expense |  |  | (12,506 | ) |  |  | (11,860 | ) |  |  | (45,517 | ) |  |  | (45,475 | ) |
| Loss on extinguishment of debt |  |  | — |  |  |  | — |  |  |  | — |  |  |  | (15,217 | ) |
| Other, net |  |  | (1,960 | ) |  |  | (584 | ) |  |  | 17,972 |  |  |  | 4,754 |  |
| Income before income taxes |  |  | 83,094 |  |  |  | 20,624 |  |  |  | 182,863 |  |  |  | 70,053 |  |
| Income tax provision |  |  | (77,077 | ) |  |  | (12,237 | ) |  |  | (88,280 | ) |  |  | (15,639 | ) |
| Net income |  | $ | 6,017 |  |  | $ | 8,387 |  |  | $ | 94,583 |  |  | $ | 54,414 |  |
| Earnings per share: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  | $ | 0.06 |  |  | $ | 0.08 |  |  | $ | 0.93 |  |  | $ | 0.51 |  |
| Diluted |  |  | 0.06 |  |  |  | 0.08 |  |  |  | 0.91 |  |  |  | 0.50 |  |
| Weighted-average shares used in computing per share amounts: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  |  | 102,217 |  |  |  | 104,186 |  |  |  | 102,074 |  |  |  | 106,314 |  |
| Diluted |  |  | 104,220 |  |  |  | 105,769 |  |  |  | 103,866 |  |  |  | 108,153 |  |
| Reconciliation of the denominator used to calculate basic earnings per share and diluted earnings per share: |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Weighted-average shares outstanding |  |  | 102,217 |  |  |  | 104,186 |  |  |  | 102,074 |  |  |  | 106,314 |  |
| Dilutive effect of warrants |  |  | — |  |  |  | — |  |  |  | 1 |  |  |  | 200 |  |
| Dilutive effect of performance-based stock units, restricted stock units & stock options |  |  | 2,003 |  |  |  | 1,583 |  |  |  | 1,791 |  |  |  | 1,639 |  |
| Diluted shares |  |  | 104,220 |  |  |  | 105,769 |  |  |  | 103,866 |  |  |  | 108,153 |  |

[0001193125-23-028382:8k_2_02:51]
TTM TECHNOLOGIES, INC.

[0001193125-23-028382:8k_2_02:52]
Selected Unaudited Financial Information

[0001193125-23-028382:8k_2_02:53]
(In thousands, except per share data)

[0001193125-23-028382:8k_2_02:54]
| SELECTED BALANCE SHEET DATA |  |  |  |  |  |  |  |  |
|  |  | January 2, 2023 |  |  | January 3, 2022 |  |
| Cash and cash equivalents, including restricted cash |  | $ | 402,749 |  |  | $ | 537,678 |  |
| Accounts and notes receivable, net |  |  | 473,225 |  |  |  | 386,347 |  |
| Receivable from sale of SH E-MS Property |  |  | 69,240 |  |  |  | — |  |
| Contract assets |  |  | 335,788 |  |  |  | 324,862 |  |
| Inventories |  |  | 170,639 |  |  |  | 127,612 |  |
| Total current assets |  |  | 1,493,056 |  |  |  | 1,407,413 |  |
| Property, plant and equipment, net |  |  | 724,204 |  |  |  | 665,755 |  |
| Operating lease right of use asset |  |  | 18,862 |  |  |  | 20,802 |  |
| Other non-current assets |  |  | 1,087,482 |  |  |  | 931,577 |  |
| Total assets |  |  | 3,323,604 |  |  |  | 3,025,547 |  |
| Short-term debt, including current portion of long-term debt |  | $ | 50,000 |  |  | $ | — |  |
| Accounts payable |  |  | 361,788 |  |  |  | 361,484 |  |
| Total current liabilities |  |  | 761,325 |  |  |  | 558,148 |  |
| Debt, net of discount |  |  | 879,407 |  |  |  | 927,818 |  |
| Total long-term liabilities |  |  | 1,026,700 |  |  |  | 1,011,982 |  |
| Total equity |  |  | 1,535,579 |  |  |  | 1,455,417 |  |
| Total liabilities and equity |  |  | 3,323,604 |  |  |  | 3,025,547 |  |

[0001193125-23-028382:8k_2_02:55]
TTM TECHNOLOGIES, INC.

[0001193125-23-028382:8k_2_02:56]
Selected Unaudited Financial Information

[0001193125-23-028382:8k_2_02:57]
(In thousands, except per share data)

[0001193125-23-028382:8k_2_02:58]
| SUPPLEMENTAL DATA |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | Fourth Quarter |  |  | Full Year |  |
|  |  | 2022 |  |  | 2021 |  |  | 2022 |  |  | 2021 |  |
| Gross margin |  |  | 19.7 | % |  |  | 16.3 | % |  |  | 18.4 | % |  |  | 16.5 | % |
| Operating margin |  |  | 15.8 | % |  |  | 5.5 | % |  |  | 8.4 | % |  |  | 5.6 | % |

[0001193125-23-028382:8k_2_02:59]
End Market Breakdown:

[0001193125-23-028382:8k_2_02:60]
|  |  | Fourth Quarter |  |
|  |  | 2022 |  |  | 2021 |  |
| Aerospace and Defense |  |  | 40 | % |  |  | 30 | % |
| Automotive |  |  | 16 | % |  |  | 19 | % |
| Data Center Computing |  |  | 14 | % |  |  | 15 | % |
| Medical/Industrial/Instrumentation |  |  | 17 | % |  |  | 19 | % |
| Networking |  |  | 13 | % |  |  | 16 | % |
| Other |  |  | 0 | % |  |  | 1 | % |

[0001193125-23-028382:8k_2_02:61]
Stock-based Compensation:

[0001193125-23-028382:8k_2_02:62]
|  |  | Fourth Quarter |  |
|  |  | 2022 |  |  | 2021 |  |
| Amount included in: |  |  |  |  |  |  |  |  |
| Cost of goods sold |  | $ | 1,699 |  |  | $ | 1,404 |  |
| Selling and marketing |  |  | 717 |  |  |  | 721 |  |
| General and administrative |  |  | 2,674 |  |  |  | 2,806 |  |
| Research and development |  |  | 304 |  |  |  | 277 |  |
| Total stock-based compensation expense |  | $ | 5,394 |  |  | $ | 5,208 |  |

[0001193125-23-028382:8k_2_02:63]
Operating Segment Data:

[0001193125-23-028382:8k_2_02:64]
|  |  | Fourth Quarter |  |
|  |  | 2022 |  |  | 2021 |  |
| Net sales: |  |  |  |  |  |  |  |  |
| PCB |  | $ | 605,268 |  |  | $ | 581,817 |  |
| RF&S Components |  |  | 11,888 |  |  |  | 16,324 |  |
| Total net sales |  | $ | 617,156 |  |  | $ | 598,141 |  |
| Operating segment income: |  |  |  |  |  |  |  |  |
| PCB |  | $ | 79,573 |  |  | $ | 70,731 |  |
| RF&S Components |  |  | 5,122 |  |  |  | 6,906 |  |
| Corporate & Other1 |  |  | 24,523 |  |  |  | (34,168 | ) |
| Total operating segment income |  |  | 109,218 |  |  |  | 43,469 |  |
| Amortization of definite-lived intangibles |  |  | (11,658 | ) |  |  | (10,401 | ) |
| Total operating income |  |  | 97,560 |  |  |  | 33,068 |  |
| Total other expense |  |  | (14,466 | ) |  |  | (12,444 | ) |
| Income before income taxes |  | $ | 83,094 |  |  | $ | 20,624 |  |

[0001193125-23-028382:8k_2_02:65]
TTM TECHNOLOGIES, INC.

[0001193125-23-028382:8k_2_02:66]
Selected Unaudited Financial Information

[0001193125-23-028382:8k_2_02:67]
(In thousands, except per share data)

[0001193125-23-028382:8k_2_02:68]
| RECONCILIATIONS2 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | Fourth Quarter |  |  | Full Year |  |
|  |  | 2022 |  |  | 2021 |  |  | 2022 |  |  | 2021 |  |
| Non-GAAP gross profit reconciliation3: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| GAAP gross profit |  | $ | 121,402 |  |  | $ | 97,322 |  |  | $ | 457,965 |  |  | $ | 372,011 |  |
| Add back item: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of definite-lived intangibles |  |  | 1,383 |  |  |  | 1,490 |  |  |  | 5,534 |  |  |  | 5,641 |  |
| Accelerated depreciation |  |  | — |  |  |  | — |  |  |  | 124 |  |  |  | — |  |
| Stock-based compensation |  |  | 1,699 |  |  |  | 1,404 |  |  |  | 5,846 |  |  |  | 4,714 |  |
| Unrealized (gain) loss on commodity hedge |  |  | (2,407 | ) |  |  | (362 | ) |  |  | 1,785 |  |  |  | (297 | ) |
| Purchase accounting related inventory markup |  |  | 79 |  |  |  | — |  |  |  | 327 |  |  |  | — |  |
| Restructuring and other charges |  |  | — |  |  |  | 7 |  |  |  | — |  |  |  | 261 |  |
| Non-GAAP gross profit |  | $ | 122,156 |  |  | $ | 99,861 |  |  | $ | 471,581 |  |  | $ | 382,330 |  |
| Non-GAAP gross margin |  |  | 19.8 | % |  |  | 16.7 | % |  |  | 18.9 | % |  |  | 17.0 | % |
| Non-GAAP operating income reconciliation4: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| GAAP operating income |  | $ | 97,560 |  |  | $ | 33,068 |  |  | $ | 210,408 |  |  | $ | 125,991 |  |
| Add back items: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of definite-lived intangibles |  |  | 11,658 |  |  |  | 10,401 |  |  |  | 42,631 |  |  |  | 41,389 |  |
| Accelerated depreciation |  |  | — |  |  |  | — |  |  |  | 124 |  |  |  | — |  |
| Stock-based compensation |  |  | 5,394 |  |  |  | 5,208 |  |  |  | 19,525 |  |  |  | 17,711 |  |
| Gain on sale of assets |  |  | (55,979 | ) |  |  | — |  |  |  | (55,979 | ) |  |  | (421 | ) |
| Unrealized (gain) loss on commodity hedge |  |  | (2,407 | ) |  |  | (362 | ) |  |  | 1,785 |  |  |  | (297 | ) |
| Purchase accounting related inventory markup |  |  | 79 |  |  |  | — |  |  |  | 327 |  |  |  | — |  |
| Restructuring, acquisition-related and other charges |  |  | 3,261 |  |  |  | 800 |  |  |  | 16,066 |  |  |  | 5,350 |  |
| Non-GAAP operating income |  | $ | 59,566 |  |  | $ | 49,115 |  |  | $ | 234,887 |  |  | $ | 189,723 |  |
| Non-GAAP operating margin |  |  | 9.7 | % |  |  | 8.2 | % |  |  | 9.4 | % |  |  | 8.4 | % |
| Non-GAAP net income and EPS reconciliation5: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| GAAP net income |  | $ | 6,017 |  |  | $ | 8,387 |  |  | $ | 94,583 |  |  | $ | 54,414 |  |
| Add back items: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of definite-lived intangibles |  |  | 11,658 |  |  |  | 10,401 |  |  |  | 42,631 |  |  |  | 41,389 |  |
| Accelerated depreciation |  |  | — |  |  |  | — |  |  |  | 124 |  |  |  | — |  |
| Stock-based compensation |  |  | 5,394 |  |  |  | 5,208 |  |  |  | 19,525 |  |  |  | 17,711 |  |
| Non-cash interest expense |  |  | 543 |  |  |  | 496 |  |  |  | 2,152 |  |  |  | 2,109 |  |
| Gain on sale of assets |  |  | (55,979 | ) |  |  | — |  |  |  | (56,806 | ) |  |  | (991 | ) |
| Change in fair value of warrant liabilities |  |  | — |  |  |  | (373 | ) |  |  | (99 | ) |  |  | (4,241 | ) |
| Loss on extinguishment of debt |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 15,217 |  |
| Unrealized (gain) loss on commodity hedge |  |  | (2,407 | ) |  |  | (362 | ) |  |  | 1,785 |  |  |  | (297 | ) |
| Purchase accounting related inventory markup |  |  | 79 |  |  |  | — |  |  |  | 327 |  |  |  | — |  |
| Restructuring, acquisition-related and other charges |  |  | 3,261 |  |  |  | 800 |  |  |  | 16,066 |  |  |  | 5,350 |  |
| Income taxes6 |  |  | 74,131 |  |  |  | 11,636 |  |  |  | 60,895 |  |  |  | 7,373 |  |
| Non-GAAP net income |  | $ | 42,697 |  |  | $ | 36,193 |  |  | $ | 181,183 |  |  | $ | 138,034 |  |
| Non-GAAP earnings per diluted share |  | $ | 0.41 |  |  | $ | 0.34 |  |  | $ | 1.74 |  |  | $ | 1.28 |  |
| Non-GAAP diluted number of shares: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| GAAP diluted number of shares |  |  | 104,220 |  |  |  | 105,769 |  |  |  | 103,866 |  |  |  | 108,153 |  |
| Dilutive effect of performance-based stock units, restricted stock units & stock options |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |
| Non-GAAP diluted number of shares |  |  | 104,220 |  |  |  | 105,769 |  |  |  | 103,866 |  |  |  | 108,153 |  |
| Adjusted EBITDA reconciliation7: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| GAAP net income |  | $ | 6,017 |  |  | $ | 8,387 |  |  | $ | 94,583 |  |  | $ | 54,414 |  |
| Add back items: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Income tax provision |  |  | 77,077 |  |  |  | 12,237 |  |  |  | 88,280 |  |  |  | 15,639 |  |
| Interest expense |  |  | 12,506 |  |  |  | 11,860 |  |  |  | 45,517 |  |  |  | 45,475 |  |
| Amortization of definite-lived intangibles |  |  | 11,658 |  |  |  | 10,401 |  |  |  | 42,631 |  |  |  | 41,389 |  |
| Depreciation expense |  |  | 23,970 |  |  |  | 22,231 |  |  |  | 91,276 |  |  |  | 85,942 |  |
| Stock-based compensation |  |  | 5,394 |  |  |  | 5,208 |  |  |  | 19,525 |  |  |  | 17,711 |  |
| Gain on sale of assets |  |  | (55,979 | ) |  |  | — |  |  |  | (56,806 | ) |  |  | (991 | ) |
| Change in fair value of warrant liabilities |  |  | — |  |  |  | (373 | ) |  |  | (99 | ) |  |  | (4,241 | ) |
| Loss on extinguishment of debt |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 15,217 |  |
| Unrealized (gain) loss on commodity hedge |  |  | (2,407 | ) |  |  | (362 | ) |  |  | 1,785 |  |  |  | (297 | ) |
| Purchase accounting related inventory markup |  |  | 79 |  |  |  | — |  |  |  | 327 |  |  |  | — |  |
| Restructuring, acquisition-related and other charges |  |  | 3,261 |  |  |  | 800 |  |  |  | 16,066 |  |  |  | 5,350 |  |
| Adjusted EBITDA |  | $ | 81,576 |  |  | $ | 70,389 |  |  | $ | 343,085 |  |  | $ | 275,608 |  |
| Adjusted EBITDA margin |  |  | 13.2 | % |  |  | 11.8 | % |  |  | 13.8 | % |  |  | 12.3 | % |
| Free cash flow reconciliation: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Operating cash flow |  | $ | 77,559 |  |  | $ | 62,369 |  |  | $ | 272,873 |  |  | $ | 176,632 |  |
| Capital expenditures, net |  |  | (20,779 | ) |  |  | (19,455 | ) |  |  | (96,874 | ) |  |  | (80,524 | ) |
| Free cash flow |  | $ | 56,780 |  |  | $ | 42,914 |  |  | $ | 175,999 |  |  | $ | 96,108 |  |

[0001193125-23-028382:8k_2_02:69]
TTM TECHNOLOGIES, INC.

[0001193125-23-028382:8k_2_02:70]
Selected Unaudited Financial Information

[0001193125-23-028382:8k_2_02:71]
(In thousands, except per share data)

[0001193125-23-028382:8k_2_02:72]
| 1 | Other represents results from the now closed Shenzhen and Shanghai E-MS facilities, which also includes the gain on sale of property occupied by our former Shanghai E-MS entity of $51,804. |

[0001193125-23-028382:8k_2_02:73]
| 2 | This information provides a reconciliation of non-GAAP gross profit, non-GAAP operating income, non-GAAP net income, non-GAAP EPS, and adjusted EBITDA to the financial information in our consolidated condensed statements of operations. |

[0001193125-23-028382:8k_2_02:74]
| 3 | Non-GAAP gross profit and gross margin measures exclude amortization of intangibles, accelerated depreciation, stock-based compensation expense, unrealized (gain) loss on commodity hedge, purchase accounting related inventory markup, restructuring and other charges. |

[0001193125-23-028382:8k_2_02:75]
| 4 | Non-GAAP operating income and operating margin measures exclude amortization of intangibles, accelerated depreciation, stock-based compensation expense, gain on sale of assets, unrealized (gain) loss on commodity hedge, purchase accounting related inventory markup, restructuring, acquisition-related costs, and other charges. |

[0001193125-23-028382:8k_2_02:76]
| 5 | This information provides non-GAAP net income and non-GAAP EPS, which are non-GAAP financial measures. Management believes that both measures — which add back amortization of intangibles, accelerated depreciation, stock-based compensation expense, non-cash interest expense on debt (before consideration of capitalized interest), gain on sale of assets, change in fair value of warrant liabilities, loss on extinguishment of debt, unrealized (gain) loss on commodity hedge, purchase accounting related inventory markup, restructuring, acquisition-related costs, and other charges as well as the associated tax impact of these charges and discrete tax items — provide additional useful information to investors regarding the Company’s ongoing financial condition and results of operations. |

[0001193125-23-028382:8k_2_02:77]
| 6 | Income tax adjustments reflect the difference between income taxes based on a non-GAAP tax rate and a forecasted annual GAAP tax rate. In addition, the non-GAAP rate in the fourth quarter of 2022 excludes the tax impact of $51,748 related to an increase in the U.S. valuation allowance. |

[0001193125-23-028382:8k_2_02:78]
| 7 | Adjusted EBITDA is defined as earnings before interest expense, income taxes, depreciation, amortization of intangibles, stock-based compensation expense, gain on sale of assets, change in fair value of warrant liabilities, loss on extinguishment of debt, unrealized (gain) loss on commodity hedge, purchase accounting related inventory markup, restructuring, acquisition-related costs, and other charges. We present adjusted EBITDA to enhance the understanding of our operating results, and it is a key measure we use to evaluate our operations. In addition, we provide our adjusted EBITDA because we believe that investors and securities analysts will find adjusted EBITDA to be a useful measure for evaluating our operating performance and comparing our operating performance with that of similar companies that have different capital structures and for evaluating our ability to meet our future debt service, capital expenditures, and working capital requirements. However, adjusted EBITDA should not be considered as an alternative to cash flows from operating activities as a measure of liquidity or as an alternative to net income as a measure of operating results in accordance with accounting principles generally accepted in the United States of America. |
