# TTMI note change history — 0001564590-22-028936 → 0000950170-22-023197


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2022-11-08):
[0000950170-22-023197:note_history:1]
The Company is subject to various legal matters, which it considers normal for its business activities. While the Company currently believes that the amount of any reasonably possible loss for known matters would not be material to the Company’s financial condition, the outcome of these actions is inherently difficult to predict. In the event of an adverse outcome, the ultimate potential loss could have a material adverse effect on the Company’s financial condition or results of operations in a particular period. The Company has accrued amounts for its loss contingencies which are probable and estimable as of October 3, 2022 and January 3, 2022. However, these amounts are not material to the consolidated condensed financial statements of the Company.
  (was, 2022-08-10, similarity 0.9927):
[0001564590-22-028936:note_history:1]
The Company is subject to various legal matters, which it considers normal for its business activities. While the Company currently believes that the amount of any reasonably possible loss for known matters would not be material to the Company’s financial condition, the outcome of these actions is inherently difficult to predict. In the event of an adverse outcome, the ultimate potential loss could have a material adverse effect on the Company’s financial condition or results of operations in a particular period. The Company has accrued amounts for its loss contingencies which are probable and estimable as of July 4, 2022 and January 3, 2022. However, these amounts are not material to the consolidated condensed financial statements of the Company.

- added (2022-11-08):
[0000950170-22-023197:note_history:2]
Offset Agreements

- added (2022-11-08):
[0000950170-22-023197:note_history:3]
Following the acquisition of Telephonics on June 27, 2022, the Company has and may continue to enter into industrial cooperation agreements, sometimes referred to as offset agreements, as a condition to obtaining orders for products and services from customers in foreign countries. These agreements are intended to promote investment in the applicable country, and the Company’s obligations under these agreements may be satisfied through activities that do not require the Company to use cash, including transferring technology or providing manufacturing and other consulting support. The obligations under these agreements may also be satisfied through the use of cash for activities such as purchasing supplies from in-country vendors, setting up support centers, research and development investments, acquisitions, and building or leasing facilities for in-country operations, if applicable. The amount of the offset requirement is determined by contract value awarded and negotiated percentages with customers. As of October 3, 2022, the Company had outstanding offset agreements of approximately $32,000, some of which extend through 2028. Offset programs usually extend over several years and in some cases provide for penalties in the event the Company fails to perform in accordance with contract requirements. Historically, the Company has not paid any such penalties, and as of October 3, 2022, no such penalties are estimable or probable.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureAndSignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2022-11-08):
[0000950170-22-023197:note_history:4]
The accompanying consolidated condensed financial statements have been prepared by the Company, without audit, pursuant to the rules and regulations of the Securities and Exchange Commission (SEC). Certain information and disclosures normally included in financial statements prepared in accordance with accounting principles generally accepted in the United States of America (U.S. GAAP) have been condensed or omitted pursuant to such rules and regulations. It is suggested that these consolidated condensed financial statements be read in conjunction with the consolidated financial statements and the notes thereto included in the Company’s most recent Annual Report on Form 10-K. The preparation of financial statements in accordance with U.S. GAAP requires management to make estimates and assumptions that affect the amounts reported in the Company’s consolidated condensed financial statements and accompanying notes. Due, in part, to the coronavirus (COVID-19) global pandemic and the conflict between Russia and Ukraine, the global economy and financial markets have been volatile, and both the pandemic and conflict has contributed to on-going disruptions in global supply chains, labor shortages, high inflation, and a potential recession, and there is a significant amount of uncertainty about the length and severity of the direct and indirect effects of the pandemic and the conflict. The Company has considered information available to it as of the date of issuance of these financial statements and is not aware of any specific events or circumstances that would require an update to its estimates or judgments, or a revision to the carrying value of its assets or liabilities. Actual results could differ materially from those estimates. The Company uses a 52/53 week fiscal calendar with the fourth quarter ending on the Monday nearest December 31.
  (was, 2022-08-10, similarity 0.8057):
[0001564590-22-028936:note_history:4]
The accompanying consolidated condensed financial statements have been prepared by the Company, without audit, pursuant to the rules and regulations of the Securities and Exchange Commission (SEC). Certain information and disclosures normally included in financial statements prepared in accordance with accounting principles generally accepted in the United States of America (U.S. GAAP) have been condensed or omitted pursuant to such rules and regulations. It is suggested that these consolidated condensed financial statements be read in conjunction with the consolidated financial statements and the notes thereto included in the Company’s most recent Annual Report on Form 10-K. The preparation of financial statements in accordance with U.S. GAAP requires management to make estimates and assumptions that affect the amounts reported in the Company’s consolidated condensed financial statements and accompanying notes. Due, in part, to the on-going coronavirus (COVID-19) global pandemic, the global economy and financial markets have been volatile, and the pandemic has contributed to disruptions in global supply chains, labor shortages and high inflation, and there is a significant amount of uncertainty about the length and severity of the consequences caused by the ongoing pandemic. The Company has considered information available to it as of the date of issuance of these financial statements and is not aware of any specific events or circumstances that would require an update to its estimates or judgments, or a revision to the carrying value of its assets or liabilities. Actual results could differ materially from those estimates. The Company uses a 52/53 week fiscal calendar with the fourth quarter ending on the Monday nearest December 31.

- changed (2022-11-08):
[0000950170-22-023197:note_history:5]
In October 2021, the Financial Accounting Standards Board (FASB) issued Accounting Standards Update (ASU) 2021-08, Business Combinations (Topic 805): Accounting for Contract Assets and Contract Liabilities from Contracts with Customers, which requires that an acquirer recognize and measure contract assets and contract liabilities acquired in a business combination in accordance with Accounting Standards Codification (ASC) 606, Revenue from Contracts with Customers, as if it had originated the contracts. Prior to this ASU, an acquirer generally recognizes contract assets acquired and contract liabilities assumed that arose from contracts with customers at fair value on the acquisition date. The ASU is effective for fiscal years beginning after December 15, 2022, with early adoption permitted. The ASU is to be applied prospectively to business combinations occurring on or after the effective date of the amendment (or if adopted early as of an interim period, as of the beginning of the fiscal year that includes the interim period of early application). The Company early adopted ASU 2021-08 on April 4, 2022 and did not have an impact on its consolidated condensed financial statements and related disclosures. The new guidance was applied to the acquisition of Gritel Holding Co., Inc. (Gritel), ISC Farmingdale Corp., and Gritel's wholly owned subsidiary, Telephonics Corporation.
  (was, 2022-08-10, similarity 0.9712):
[0001564590-22-028936:note_history:5]
In October 2021, the Financial Accounting Standards Board (FASB) issued Accounting Standards Update (ASU) 2021-08, Business Combinations (Topic 805): Accounting for Contract Assets and Contract Liabilities from Contracts with Customers, which requires that an acquirer recognize and measure contract assets and contract liabilities acquired in a business combination in accordance with Accounting Standards Codification (ASC) 606, Revenue from Contracts with Customers, as if it had originated the contracts. Prior to this ASU, an acquirer generally recognizes contract assets acquired and contract liabilities assumed that arose from contracts with customers at fair value on the acquisition date. The ASU is effective for fiscal years beginning after December 15, 2022, with early adoption permitted. The ASU is to be applied prospectively to business combinations occurring on or after the effective date of the amendment (or if adopted early as of an interim period, as of the beginning of the fiscal year that includes the interim period of early application). The Company early adopted ASU 2021-08 on April 4, 2022 and did not have an impact on its consolidated condensed financial statements and related disclosures. The new guidance will be applied to the acquisition of Gritel Holding Co., Inc. (Gritel) and ISC Farmingdale Corp.

- added (2022-11-08):
[0000950170-22-023197:note_history:6]
In September 2022, the FASB issued ASU 2022-04, Liabilities - Supplier Finance Programs (Topic 450-50): Disclosure of Supplier Finance Program Obligations, that requires entities that use supplier finance programs in connection with the purchase of goods and services to disclose the key terms of the programs and information about obligations outstanding at the end of the reporting period, including a rollforward of those obligations. The guidance does not affect the recognition, measurement or financial statement presentation of supplier finance program obligations. The amendments are effective for all entities for fiscal years beginning after December 15, 2022 on a retrospective basis, including interim periods within those fiscal years, except for the requirement to disclose rollforward information, which is effective prospectively for fiscal years beginning after December 15, 2023. Early adoption is permitted upon issuance of the update. The Company is currently evaluating the new guidance to determine the impact it may have on its consolidated financial statements and related disclosures.


## ttmi:ScheduleOfUnamortizedDiscountAndDebtIssuanceCostsTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2022-11-08):
[0000950170-22-023197:note_history:7]
As of October 3, 2022 and January 3, 2022, remaining unamortized debt discount and debt issuance costs for the Senior Notes due 2029 and Term Loan Facility are as follows:
  (was, 2022-08-10, similarity 0.9651):
[0001564590-22-028936:note_history:7]
As of July 4, 2022 and January 3, 2022, remaining unamortized debt discount and debt issuance costs for the Senior Notes due 2029 and Term Loan Facility are as follows:

- changed (2022-11-08):
[0000950170-22-023197:note_history:8]
|  |  | As of October 3, 2022 |  |  | As of January 3, 2022 |
|  |  | DebtIssuance Costs |  |  | DebtDiscount |  |  | EffectiveInterest Rate |  |  | DebtIssuance Costs |  |  | DebtDiscount |  |  | EffectiveInterest Rate |  |  |
|  |  | (In thousands, except interest rates) |
| Senior Notes due March 2029 |  | $ | 4,947 |  |  | $ | — |  |  |  | 4.18 |  | % | $ | 5,444 |  |  | $ | — |  |  |  | 4.18 |  | % |
| Term Loan due September 2024 |  |  | 1,480 |  |  |  | 448 |  |  |  | 4.66 |  |  |  | 2,010 |  |  |  | 607 |  |  |  | 4.66 |  |  |
|  |  | $ | 6,427 |  |  | $ | 448 |  |  |  |  |  | $ | 7,454 |  |  | $ | 607 |  |  |  |  |  |
  (was, 2022-08-10, similarity 0.8172):
[0001564590-22-028936:note_history:8]
|  |  | As of July 4, 2022 |  |  | As of January 3, 2022 |
|  |  | Debt Issuance Costs |  |  | Debt Discount |  |  | Effective Interest Rate |  |  | Debt Issuance Costs |  |  | Debt Discount |  |  | Effective Interest Rate |  |  |
|  |  | (In thousands, except interest rates) |
| Senior Notes due March 2029 |  | $ | 5,114 |  |  | $ | — |  |  |  | 4.18 |  | % | $ | 5,444 |  |  | $ | — |  |  |  | 4.18 |  | % |
| Term Loan due September 2024 |  |  | 1,658 |  |  |  | 502 |  |  |  | 4.66 |  |  |  | 2,010 |  |  |  | 607 |  |  |  | 4.66 |  |  |
|  |  | $ | 6,772 |  |  | $ | 502 |  |  |  |  |  |  | $ | 7,454 |  |  | $ | 607 |  |  |  |  |  |  |


## us-gaap:LongTermDebtTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2022-11-08):
[0000950170-22-023197:note_history:9]
The following table summarizes the long-term debt of the Company as of October 3, 2022 and January 3, 2022:
  (was, 2022-08-10, similarity 0.9436):
[0001564590-22-028936:note_history:9]
The following table summarizes the long-term debt of the Company as of July 4, 2022 and January 3, 2022:

- changed (2022-11-08):
[0000950170-22-023197:note_history:10]
|  |  | Interest Rate as ofOctober 3, 2022 |  |  |  | PrincipalOutstandingas ofOctober 3, 2022 |  |  | Interest Rate as ofJanuary 3, 2022 |  |  |  | PrincipalOutstandingas ofJanuary 3, 2022 |  |
|  |  | (In thousands, except interest rates) |  |
| Senior Notes due March 2029 |  |  | 4.00 |  | % |  | $ | 500,000 |  |  |  | 4.00 |  | % |  | $ | 500,000 |  |
| Term Loan due September 2024 |  |  | 5.67 |  |  |  |  | 405,879 |  |  |  | 2.60 |  |  |  |  | 405,879 |  |
| Asia ABL Revolving Loan due June 2024 |  |  | 4.57 |  |  |  |  | 30,000 |  |  |  | 1.50 |  |  |  |  | 30,000 |  |
|  |  |  |  |  |  |  | 935,879 |  |  |  |  |  |  |  | 935,879 |  |
| Less: Long-term debt unamortized discount |  |  |  |  |  |  | (448 | ) |  |  |  |  |  |  | (607 | ) |
| Long-term debt unamortized debt issuance costs |  |  |  |  |  |  | (6,427 | ) |  |  |  |  |  |  | (7,454 | ) |
|  |  |  |  |  |  |  | 929,004 |  |  |  |  |  |  |  | 927,818 |  |
| Less: current maturities |  |  |  |  |  |  | — |  |  |  |  |  |  |  | — |  |
| Long-term debt, less current maturities |  |  |  |  |  | $ | 929,004 |  |  |  |  |  |  | $ | 927,818 |  |
  (was, 2022-08-10, similarity 0.8505):
[0001564590-22-028936:note_history:10]
|  |  | Interest Rate as of July 4, 2022 |  |  | Principal Outstanding as of July 4, 2022 |  |  | Interest Rate as of January 3, 2022 |  |  | Principal Outstanding as of January 3, 2022 |  |
|  |  | (In thousands, except interest rates) |  |
| Senior Notes due March 2029 |  |  | 4.00 |  | % | $ | 500,000 |  |  |  | 4.00 |  | % | $ | 500,000 |  |
| Term Loan due September 2024 |  |  | 4.28 |  |  |  | 405,879 |  |  |  | 2.60 |  |  |  | 405,879 |  |
| Asia ABL Revolving Loan due June 2024 |  |  | 3.18 |  |  |  | 30,000 |  |  |  | 1.50 |  |  |  | 30,000 |  |
|  |  |  |  |  |  |  | 935,879 |  |  |  |  |  |  |  | 935,879 |  |
| Less: Long-term debt unamortized discount |  |  |  |  |  |  | (502 | ) |  |  |  |  |  |  | (607 | ) |
| Long-term debt unamortized debt issuance costs |  |  |  |  |  |  | (6,772 | ) |  |  |  |  |  |  | (7,454 | ) |
|  |  |  |  |  |  |  | 928,605 |  |  |  |  |  |  |  | 927,818 |  |
| Less: current maturities |  |  |  |  |  |  | — |  |  |  |  |  |  |  | — |  |
| Long-term debt, less current maturities |  |  |  |  |  | $ | 928,605 |  |  |  |  |  |  | $ | 927,818 |  |

- changed (2022-11-08):
[0000950170-22-023197:note_history:11]
As of October 3, 2022 and January 3, 2022, remaining unamortized debt discount and debt issuance costs for the Senior Notes due 2029 and Term Loan Facility are as follows:
  (was, 2022-08-10, similarity 0.9651):
[0001564590-22-028936:note_history:11]
As of July 4, 2022 and January 3, 2022, remaining unamortized debt discount and debt issuance costs for the Senior Notes due 2029 and Term Loan Facility are as follows:

- changed (2022-11-08):
[0000950170-22-023197:note_history:12]
|  |  | As of October 3, 2022 |  |  | As of January 3, 2022 |
|  |  | DebtIssuance Costs |  |  | DebtDiscount |  |  | EffectiveInterest Rate |  |  | DebtIssuance Costs |  |  | DebtDiscount |  |  | EffectiveInterest Rate |  |  |
|  |  | (In thousands, except interest rates) |
| Senior Notes due March 2029 |  | $ | 4,947 |  |  | $ | — |  |  |  | 4.18 |  | % | $ | 5,444 |  |  | $ | — |  |  |  | 4.18 |  | % |
| Term Loan due September 2024 |  |  | 1,480 |  |  |  | 448 |  |  |  | 4.66 |  |  |  | 2,010 |  |  |  | 607 |  |  |  | 4.66 |  |  |
|  |  | $ | 6,427 |  |  | $ | 448 |  |  |  |  |  | $ | 7,454 |  |  | $ | 607 |  |  |  |  |  |
  (was, 2022-08-10, similarity 0.8172):
[0001564590-22-028936:note_history:12]
|  |  | As of July 4, 2022 |  |  | As of January 3, 2022 |
|  |  | Debt Issuance Costs |  |  | Debt Discount |  |  | Effective Interest Rate |  |  | Debt Issuance Costs |  |  | Debt Discount |  |  | Effective Interest Rate |  |  |
|  |  | (In thousands, except interest rates) |
| Senior Notes due March 2029 |  | $ | 5,114 |  |  | $ | — |  |  |  | 4.18 |  | % | $ | 5,444 |  |  | $ | — |  |  |  | 4.18 |  | % |
| Term Loan due September 2024 |  |  | 1,658 |  |  |  | 502 |  |  |  | 4.66 |  |  |  | 2,010 |  |  |  | 607 |  |  |  | 4.66 |  |  |
|  |  | $ | 6,772 |  |  | $ | 502 |  |  |  |  |  |  | $ | 7,454 |  |  | $ | 607 |  |  |  |  |  |  |

- changed (2022-11-08):
[0000950170-22-023197:note_history:13]
Remaining unamortized debt issuance costs for the ABL Revolving Loans of $933 and $1,355 as of October 3, 2022 and January 3, 2022, respectively, are included in other non-current assets and are amortized to interest expense over the duration of the ABL Revolving Loans using the straight-line method of amortization.
  (was, 2022-08-10, similarity 0.9817):
[0001564590-22-028936:note_history:13]
Remaining unamortized debt issuance costs for the ABL Revolving Loans of $1,073 and $1,355 as of July 4, 2022 and January 3, 2022, respectively, are included in other non-current assets and are amortized to interest expense over the duration of the ABL Revolving Loans using the straight-line method of amortization.

- changed (2022-11-08):
[0000950170-22-023197:note_history:14]
As of October 3, 2022, the remaining weighted average amortization period for all unamortized debt discount and debt issuance costs was 4.8 years.
  (was, 2022-08-10, similarity 0.96):
[0001564590-22-028936:note_history:14]
As of July 4, 2022, the remaining weighted average amortization period for all unamortized debt discount and debt issuance costs was 4.9 years.

- added (2022-11-08):
[0000950170-22-023197:note_history:15]
During the three quarters ended September 27, 2021, the Company recognized losses of $15,217 associated with the premium paid on extinguishment of debt and the write-off of the remaining unamortized debt issuance costs as a result of the repayment of the remaining outstanding balance of the Senior Notes due 2025.

- removed (2022-11-08):
[0001564590-22-028936:note_history:16]
During the two quarters ended June 28, 2021, the Company recognized losses of $15,217 associated with the premium paid on extinguishment of debt and the write-off of the remaining unamortized debt issuance costs as a result of the repayment of the remaining outstanding balance of the Senior Notes due 2025.


## us-gaap:ScheduleOfDebtInstrumentsTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2022-11-08):
[0000950170-22-023197:note_history:17]
The following table summarizes the long-term debt of the Company as of October 3, 2022 and January 3, 2022:
  (was, 2022-08-10, similarity 0.9436):
[0001564590-22-028936:note_history:17]
The following table summarizes the long-term debt of the Company as of July 4, 2022 and January 3, 2022:

- changed (2022-11-08):
[0000950170-22-023197:note_history:18]
|  |  | Interest Rate as ofOctober 3, 2022 |  |  |  | PrincipalOutstandingas ofOctober 3, 2022 |  |  | Interest Rate as ofJanuary 3, 2022 |  |  |  | PrincipalOutstandingas ofJanuary 3, 2022 |  |
|  |  | (In thousands, except interest rates) |  |
| Senior Notes due March 2029 |  |  | 4.00 |  | % |  | $ | 500,000 |  |  |  | 4.00 |  | % |  | $ | 500,000 |  |
| Term Loan due September 2024 |  |  | 5.67 |  |  |  |  | 405,879 |  |  |  | 2.60 |  |  |  |  | 405,879 |  |
| Asia ABL Revolving Loan due June 2024 |  |  | 4.57 |  |  |  |  | 30,000 |  |  |  | 1.50 |  |  |  |  | 30,000 |  |
|  |  |  |  |  |  |  | 935,879 |  |  |  |  |  |  |  | 935,879 |  |
| Less: Long-term debt unamortized discount |  |  |  |  |  |  | (448 | ) |  |  |  |  |  |  | (607 | ) |
| Long-term debt unamortized debt issuance costs |  |  |  |  |  |  | (6,427 | ) |  |  |  |  |  |  | (7,454 | ) |
|  |  |  |  |  |  |  | 929,004 |  |  |  |  |  |  |  | 927,818 |  |
| Less: current maturities |  |  |  |  |  |  | — |  |  |  |  |  |  |  | — |  |
| Long-term debt, less current maturities |  |  |  |  |  | $ | 929,004 |  |  |  |  |  |  | $ | 927,818 |  |
  (was, 2022-08-10, similarity 0.8505):
[0001564590-22-028936:note_history:18]
|  |  | Interest Rate as of July 4, 2022 |  |  | Principal Outstanding as of July 4, 2022 |  |  | Interest Rate as of January 3, 2022 |  |  | Principal Outstanding as of January 3, 2022 |  |
|  |  | (In thousands, except interest rates) |  |
| Senior Notes due March 2029 |  |  | 4.00 |  | % | $ | 500,000 |  |  |  | 4.00 |  | % | $ | 500,000 |  |
| Term Loan due September 2024 |  |  | 4.28 |  |  |  | 405,879 |  |  |  | 2.60 |  |  |  | 405,879 |  |
| Asia ABL Revolving Loan due June 2024 |  |  | 3.18 |  |  |  | 30,000 |  |  |  | 1.50 |  |  |  | 30,000 |  |
|  |  |  |  |  |  |  | 935,879 |  |  |  |  |  |  |  | 935,879 |  |
| Less: Long-term debt unamortized discount |  |  |  |  |  |  | (502 | ) |  |  |  |  |  |  | (607 | ) |
| Long-term debt unamortized debt issuance costs |  |  |  |  |  |  | (6,772 | ) |  |  |  |  |  |  | (7,454 | ) |
|  |  |  |  |  |  |  | 928,605 |  |  |  |  |  |  |  | 927,818 |  |
| Less: current maturities |  |  |  |  |  |  | — |  |  |  |  |  |  |  | — |  |
| Long-term debt, less current maturities |  |  |  |  |  | $ | 928,605 |  |  |  |  |  |  | $ | 927,818 |  |


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2022-11-08):
[0000950170-22-023197:note_history:19]
|  |  | Quarter Ended October 3, 2022 |  |  | Quarter Ended September 27, 2021 |  |  |
|  |  | PCB |  |  | RF&S Components |  |  | Other (1) |  |  | Total |  |  | PCB |  |  | RF&S Components |  |  | Total |  |  |
| End Markets |  | (In thousands) |  |  |
| Aerospace and Defense |  | $ | 186,030 |  |  | $ | — |  |  | $ | 68,255 |  |  | $ | 254,285 |  |  | $ | 173,894 |  |  | $ | 12 |  |  | $ | 173,906 |  |  |
| Automotive |  |  | 100,811 |  |  |  | — |  |  |  | — |  |  |  | 100,811 |  |  |  | 99,205 |  |  |  | — |  |  |  | 99,205 |  |  |
| Data Center Computing |  |  | 95,830 |  |  |  | 13 |  |  |  | — |  |  |  | 95,843 |  |  |  | 81,202 |  |  |  | — |  |  |  | 81,202 |  |  |
| Medical/Industrial/Instrumentation |  |  | 128,444 |  |  |  | 1,239 |  |  |  | — |  |  |  | 129,683 |  |  |  | 108,879 |  |  |  | 1,467 |  |  |  | 110,346 |  |  |
| Networking/Communications |  |  | 78,181 |  |  |  | 12,494 |  |  |  | — |  |  |  | 90,675 |  |  |  | 74,316 |  |  |  | 12,848 |  |  |  | 87,164 |  |  |
| Other |  |  | (376 | ) |  |  | 159 |  |  |  | — |  |  |  | (217 | ) |  |  | 3,622 |  |  |  | 1,339 |  |  |  | 4,961 |  |  |
| Total |  | $ | 588,920 |  |  | $ | 13,905 |  |  | $ | 68,255 |  |  | $ | 671,080 |  |  | $ | 541,118 |  |  | $ | 15,666 |  |  | $ | 556,784 |  |  |
  (was, 2022-08-10, similarity 0.8983):
[0001564590-22-028936:note_history:19]
|  |  | Quarter Ended July 4, 2022 |  |  | Quarter Ended June 28, 2021 |  |  |
|  |  | PCB |  |  | RF&S Components |  |  | Total |  |  | PCB |  |  | RF&S Components |  |  | Total |  |  |
| End Markets |  | (In thousands) |  |  |
| Aerospace and Defense |  | $ | 189,676 |  |  | $ | — |  |  | $ | 189,676 |  |  | $ | 185,152 |  |  | $ | 6 |  |  | $ | 185,158 |  |  |
| Automotive |  |  | 111,778 |  |  |  | — |  |  |  | 111,778 |  |  |  | 102,893 |  |  |  | — |  |  |  | 102,893 |  |  |
| Data Center Computing |  |  | 106,188 |  |  |  | 20 |  |  |  | 106,208 |  |  |  | 82,230 |  |  |  | 24 |  |  |  | 82,254 |  |  |
| Medical/Industrial/Instrumentation |  |  | 131,061 |  |  |  | 2,246 |  |  |  | 133,307 |  |  |  | 104,012 |  |  |  | 1,067 |  |  |  | 105,079 |  |  |
| Networking/Communications |  |  | 69,766 |  |  |  | 15,109 |  |  |  | 84,875 |  |  |  | 75,728 |  |  |  | 11,950 |  |  |  | 87,678 |  |  |
| Other |  |  | 960 |  |  |  | (1,254 | ) |  |  | (294 | ) |  |  | 3,465 |  |  |  | 856 |  |  |  | 4,321 |  |  |
| Total |  | $ | 609,429 |  |  | $ | 16,121 |  |  | $ | 625,550 |  |  | $ | 553,480 |  |  | $ | 13,903 |  |  | $ | 567,383 |  |  |

- changed (2022-11-08):
[0000950170-22-023197:note_history:20]
|  |  | Three Quarters Ended October 3, 2022 |  |  | Three Quarters Ended September 27, 2021 |  |  |
|  |  | PCB |  |  | RF&S Components |  |  |  | Other (1) |  |  | Total |  |  | PCB |  |  | RF&S Components |  |  | Other (1) |  |  | Total |  |  |
| End Markets |  | (In thousands) |  |  |
| Aerospace and Defense |  | $ | 547,886 |  |  | $ | — |  |  |  | $ | 68,255 |  |  | $ | 616,141 |  |  | $ | 545,585 |  |  | $ | 24 |  |  | $ | — |  |  | $ | 545,609 |  |  |
| Automotive |  |  | 327,825 |  |  |  | — |  |  |  |  | — |  |  |  | 327,825 |  |  |  | 293,890 |  |  |  | — |  |  |  | 3,642 |  |  |  | 297,532 |  |  |
| Data Center Computing |  |  | 293,802 |  |  |  | 33 |  |  |  |  | — |  |  |  | 293,835 |  |  |  | 235,191 |  |  |  | 456 |  |  |  | — |  |  |  | 235,647 |  |  |
| Medical/Industrial/Instrumentation |  |  | 379,867 |  |  |  | 5,023 |  |  |  |  | — |  |  |  | 384,890 |  |  |  | 303,661 |  |  |  | 3,615 |  |  |  | 25 |  |  |  | 307,301 |  |  |
| Networking/Communications |  |  | 211,590 |  |  |  | 41,360 |  |  |  |  | — |  |  |  | 252,950 |  |  |  | 216,982 |  |  |  | 35,451 |  |  |  | 1 |  |  |  | 252,434 |  |  |
| Other |  |  | 3,449 |  |  |  | (1,200 | ) |  |  |  | — |  |  |  | 2,249 |  |  |  | 9,775 |  |  |  | 2,713 |  |  |  | (412 | ) |  |  | 12,076 |  |  |
| Total |  | $ | 1,764,419 |  |  | $ | 45,216 |  |  |  | $ | 68,255 |  |  | $ | 1,877,890 |  |  | $ | 1,605,084 |  |  | $ | 42,259 |  |  | $ | 3,256 |  |  | $ | 1,650,599 |  |  |
  (was, 2022-08-10, similarity 0.8544):
[0001564590-22-028936:note_history:20]
|  |  | Two Quarters Ended July 4, 2022 |  |  | Two Quarters Ended June 28, 2021 |  |  |
|  |  | PCB |  |  | RF&S Components |  |  | Total |  |  | PCB |  |  | RF&S Components |  |  | Other (1) |  |  | Total |  |  |
| End Markets |  | (In thousands) |  |  |
| Aerospace and Defense |  | $ | 361,856 |  |  | $ | — |  |  | $ | 361,856 |  |  | $ | 371,691 |  |  | $ | 12 |  |  | $ | — |  |  | $ | 371,703 |  |  |
| Automotive |  |  | 227,014 |  |  |  | — |  |  |  | 227,014 |  |  |  | 194,685 |  |  |  | — |  |  |  | 3,642 |  |  |  | 198,327 |  |  |
| Data Center Computing |  |  | 197,972 |  |  |  | 20 |  |  |  | 197,992 |  |  |  | 153,989 |  |  |  | 456 |  |  |  | — |  |  |  | 154,445 |  |  |
| Medical/Industrial/Instrumentation |  |  | 251,423 |  |  |  | 3,784 |  |  |  | 255,207 |  |  |  | 194,782 |  |  |  | 2,148 |  |  |  | 25 |  |  |  | 196,955 |  |  |
| Networking/Communications |  |  | 133,409 |  |  |  | 28,866 |  |  |  | 162,275 |  |  |  | 142,666 |  |  |  | 22,603 |  |  |  | 1 |  |  |  | 165,270 |  |  |
| Other |  |  | 3,825 |  |  |  | (1,359 | ) |  |  | 2,466 |  |  |  | 6,153 |  |  |  | 1,374 |  |  |  | (412 | ) |  |  | 7,115 |  |  |
| Total |  | $ | 1,175,499 |  |  | $ | 31,311 |  |  | $ | 1,206,810 |  |  | $ | 1,063,966 |  |  | $ | 26,593 |  |  | $ | 3,256 |  |  | $ | 1,093,815 |  |  |

- changed (2022-11-08):
[0000950170-22-023197:note_history:21]
(1)
Other represents results from Telephonics for the quarter and three quarters ended October 3, 2022 and from the now closed Shanghai (SH E-MS) and Shenzhen (SZ) facilities previously utilized by the Company's former E-M Solutions business unit for the three quarters ended September 27, 2021.
  (was, 2022-08-10, similarity 0.7304):
[0001564590-22-028936:note_history:21]
| (1) | Other represents results from the now closed Shanghai (SH E-MS) and Shenzhen (SZ) facilities previously utilized by the Company’s former E-M Solutions business unit. |


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2022-11-08):
[0000950170-22-023197:note_history:22]
As of October 3, 2022, the aggregate amount of the transaction price allocated to remaining performance obligations for long-term contracts was $303,046. The Company expects to recognize revenue on approximately 64% of the remaining performance obligations for the Company’s long-term contracts over the next twelve months.
  (was, 2022-08-10, similarity 0.9822):
[0001564590-22-028936:note_history:22]
As of July 4, 2022, the aggregate amount of the transaction price allocated to remaining performance obligations for long-term contracts was $308,915. The Company expects to recognize revenue on approximately 64% of the remaining performance obligations for the Company’s long-term contracts over the next twelve months.

- changed (2022-11-08):
[0000950170-22-023197:note_history:23]
Revenue from products and services transferred to customers over time and at a point in time accounted for 98% and 2%, respectively, of the Company’s revenue for the quarter and three quarters ended October 3, 2022, and 97% and 3%, respectively, of the Company’s revenue for the quarter and three quarters ended September 27, 2021.
  (was, 2022-08-10, similarity 0.9295):
[0001564590-22-028936:note_history:23]
Revenue from products and services transferred to customers over time and at a point in time accounted for 97% and 3%, respectively, of the Company’s revenue for the quarter and two quarters ended July 4, 2022, and 98% and 2%, respectively, of the Company’s revenue for the quarter and two quarters ended June 28, 2021.

- changed (2022-11-08):
[0000950170-22-023197:note_history:24]
|  |  | Quarter Ended October 3, 2022 |  |  | Quarter Ended September 27, 2021 |  |  |
|  |  | PCB |  |  | RF&S Components |  |  | Other (1) |  |  | Total |  |  | PCB |  |  | RF&S Components |  |  | Total |  |  |
| End Markets |  | (In thousands) |  |  |
| Aerospace and Defense |  | $ | 186,030 |  |  | $ | — |  |  | $ | 68,255 |  |  | $ | 254,285 |  |  | $ | 173,894 |  |  | $ | 12 |  |  | $ | 173,906 |  |  |
| Automotive |  |  | 100,811 |  |  |  | — |  |  |  | — |  |  |  | 100,811 |  |  |  | 99,205 |  |  |  | — |  |  |  | 99,205 |  |  |
| Data Center Computing |  |  | 95,830 |  |  |  | 13 |  |  |  | — |  |  |  | 95,843 |  |  |  | 81,202 |  |  |  | — |  |  |  | 81,202 |  |  |
| Medical/Industrial/Instrumentation |  |  | 128,444 |  |  |  | 1,239 |  |  |  | — |  |  |  | 129,683 |  |  |  | 108,879 |  |  |  | 1,467 |  |  |  | 110,346 |  |  |
| Networking/Communications |  |  | 78,181 |  |  |  | 12,494 |  |  |  | — |  |  |  | 90,675 |  |  |  | 74,316 |  |  |  | 12,848 |  |  |  | 87,164 |  |  |
| Other |  |  | (376 | ) |  |  | 159 |  |  |  | — |  |  |  | (217 | ) |  |  | 3,622 |  |  |  | 1,339 |  |  |  | 4,961 |  |  |
| Total |  | $ | 588,920 |  |  | $ | 13,905 |  |  | $ | 68,255 |  |  | $ | 671,080 |  |  | $ | 541,118 |  |  | $ | 15,666 |  |  | $ | 556,784 |  |  |
  (was, 2022-08-10, similarity 0.8983):
[0001564590-22-028936:note_history:24]
|  |  | Quarter Ended July 4, 2022 |  |  | Quarter Ended June 28, 2021 |  |  |
|  |  | PCB |  |  | RF&S Components |  |  | Total |  |  | PCB |  |  | RF&S Components |  |  | Total |  |  |
| End Markets |  | (In thousands) |  |  |
| Aerospace and Defense |  | $ | 189,676 |  |  | $ | — |  |  | $ | 189,676 |  |  | $ | 185,152 |  |  | $ | 6 |  |  | $ | 185,158 |  |  |
| Automotive |  |  | 111,778 |  |  |  | — |  |  |  | 111,778 |  |  |  | 102,893 |  |  |  | — |  |  |  | 102,893 |  |  |
| Data Center Computing |  |  | 106,188 |  |  |  | 20 |  |  |  | 106,208 |  |  |  | 82,230 |  |  |  | 24 |  |  |  | 82,254 |  |  |
| Medical/Industrial/Instrumentation |  |  | 131,061 |  |  |  | 2,246 |  |  |  | 133,307 |  |  |  | 104,012 |  |  |  | 1,067 |  |  |  | 105,079 |  |  |
| Networking/Communications |  |  | 69,766 |  |  |  | 15,109 |  |  |  | 84,875 |  |  |  | 75,728 |  |  |  | 11,950 |  |  |  | 87,678 |  |  |
| Other |  |  | 960 |  |  |  | (1,254 | ) |  |  | (294 | ) |  |  | 3,465 |  |  |  | 856 |  |  |  | 4,321 |  |  |
| Total |  | $ | 609,429 |  |  | $ | 16,121 |  |  | $ | 625,550 |  |  | $ | 553,480 |  |  | $ | 13,903 |  |  | $ | 567,383 |  |  |

- changed (2022-11-08):
[0000950170-22-023197:note_history:25]
|  |  | Three Quarters Ended October 3, 2022 |  |  | Three Quarters Ended September 27, 2021 |  |  |
|  |  | PCB |  |  | RF&S Components |  |  |  | Other (1) |  |  | Total |  |  | PCB |  |  | RF&S Components |  |  | Other (1) |  |  | Total |  |  |
| End Markets |  | (In thousands) |  |  |
| Aerospace and Defense |  | $ | 547,886 |  |  | $ | — |  |  |  | $ | 68,255 |  |  | $ | 616,141 |  |  | $ | 545,585 |  |  | $ | 24 |  |  | $ | — |  |  | $ | 545,609 |  |  |
| Automotive |  |  | 327,825 |  |  |  | — |  |  |  |  | — |  |  |  | 327,825 |  |  |  | 293,890 |  |  |  | — |  |  |  | 3,642 |  |  |  | 297,532 |  |  |
| Data Center Computing |  |  | 293,802 |  |  |  | 33 |  |  |  |  | — |  |  |  | 293,835 |  |  |  | 235,191 |  |  |  | 456 |  |  |  | — |  |  |  | 235,647 |  |  |
| Medical/Industrial/Instrumentation |  |  | 379,867 |  |  |  | 5,023 |  |  |  |  | — |  |  |  | 384,890 |  |  |  | 303,661 |  |  |  | 3,615 |  |  |  | 25 |  |  |  | 307,301 |  |  |
| Networking/Communications |  |  | 211,590 |  |  |  | 41,360 |  |  |  |  | — |  |  |  | 252,950 |  |  |  | 216,982 |  |  |  | 35,451 |  |  |  | 1 |  |  |  | 252,434 |  |  |
| Other |  |  | 3,449 |  |  |  | (1,200 | ) |  |  |  | — |  |  |  | 2,249 |  |  |  | 9,775 |  |  |  | 2,713 |  |  |  | (412 | ) |  |  | 12,076 |  |  |
| Total |  | $ | 1,764,419 |  |  | $ | 45,216 |  |  |  | $ | 68,255 |  |  | $ | 1,877,890 |  |  | $ | 1,605,084 |  |  | $ | 42,259 |  |  | $ | 3,256 |  |  | $ | 1,650,599 |  |  |
  (was, 2022-08-10, similarity 0.8544):
[0001564590-22-028936:note_history:25]
|  |  | Two Quarters Ended July 4, 2022 |  |  | Two Quarters Ended June 28, 2021 |  |  |
|  |  | PCB |  |  | RF&S Components |  |  | Total |  |  | PCB |  |  | RF&S Components |  |  | Other (1) |  |  | Total |  |  |
| End Markets |  | (In thousands) |  |  |
| Aerospace and Defense |  | $ | 361,856 |  |  | $ | — |  |  | $ | 361,856 |  |  | $ | 371,691 |  |  | $ | 12 |  |  | $ | — |  |  | $ | 371,703 |  |  |
| Automotive |  |  | 227,014 |  |  |  | — |  |  |  | 227,014 |  |  |  | 194,685 |  |  |  | — |  |  |  | 3,642 |  |  |  | 198,327 |  |  |
| Data Center Computing |  |  | 197,972 |  |  |  | 20 |  |  |  | 197,992 |  |  |  | 153,989 |  |  |  | 456 |  |  |  | — |  |  |  | 154,445 |  |  |
| Medical/Industrial/Instrumentation |  |  | 251,423 |  |  |  | 3,784 |  |  |  | 255,207 |  |  |  | 194,782 |  |  |  | 2,148 |  |  |  | 25 |  |  |  | 196,955 |  |  |
| Networking/Communications |  |  | 133,409 |  |  |  | 28,866 |  |  |  | 162,275 |  |  |  | 142,666 |  |  |  | 22,603 |  |  |  | 1 |  |  |  | 165,270 |  |  |
| Other |  |  | 3,825 |  |  |  | (1,359 | ) |  |  | 2,466 |  |  |  | 6,153 |  |  |  | 1,374 |  |  |  | (412 | ) |  |  | 7,115 |  |  |
| Total |  | $ | 1,175,499 |  |  | $ | 31,311 |  |  | $ | 1,206,810 |  |  | $ | 1,063,966 |  |  | $ | 26,593 |  |  | $ | 3,256 |  |  | $ | 1,093,815 |  |  |

- changed (2022-11-08):
[0000950170-22-023197:note_history:26]
(1)
Other represents results from Telephonics for the quarter and three quarters ended October 3, 2022 and from the now closed Shanghai (SH E-MS) and Shenzhen (SZ) facilities previously utilized by the Company's former E-M Solutions business unit for the three quarters ended September 27, 2021.
  (was, 2022-08-10, similarity 0.7304):
[0001564590-22-028936:note_history:26]
| (1) | Other represents results from the now closed Shanghai (SH E-MS) and Shenzhen (SZ) facilities previously utilized by the Company’s former E-M Solutions business unit. |
