# TTMI notes — 0000950170-23-005994


## dei:DocumentsIncorporatedByReferenceTextBlock

[0000950170-23-005994:notes:1]
Portions of the registrant’s definitive Proxy Statement for its 2023 Annual Meeting of Stockholders are incorporated by reference into Part III of this report. Such Proxy Statement will be filed with the Securities and Exchange Commission within 120 days after the end of the fiscal year to which this report relates.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureAndSignificantAccountingPoliciesTextBlock

[0000950170-23-005994:notes:2]
(1)
Nature of Operations and Summary of Significant Accounting Policies

[0000950170-23-005994:notes:3]
Nature of Operations

[0000950170-23-005994:notes:4]
TTM Technologies, Inc. (the Company or TTM) is a leading global manufacturer of technology solutions, including engineered systems, radio frequency (RF) components and RF microwave/microelectronic assemblies, and printed circuit boards (PCB). The Company provides time-to-market and volume production of advanced technology products and offers a one-stop design, engineering and manufacturing solution to customers. This one-stop design, engineering and manufacturing solution allows the Company to align technology developments with the diverse needs of the Company’s customers and to enable them to reduce the time required to develop new products and bring them to market.

[0000950170-23-005994:notes:5]
The Company serves a diversified customer base in various markets throughout the world, including aerospace and defense, data center computing, automotive, medical, industrial and instrumentation, as well as networking and telecommunications. The Company’s customers include original equipment manufacturers (OEMs), electronic manufacturing services (EMS) providers, original design manufacturers (ODMs), distributors and government agencies.

[0000950170-23-005994:notes:6]
On January 19, 2020, the Company entered into a definitive equity interests purchase agreement with AKMMeadville Electronics (Xiamen) Co., Ltd (the Purchaser) for the sale that was completed on April 17, 2020 of the following now former Company subsidiaries: Shanghai Kaiser Electronics Co., Ltd. (SKE), Shanghai Meadville Electronics Co., Ltd. (SME), Shanghai Meadville Science & Technology Co., Ltd. (SP) and Guangzhou Meadville Electronics Co., Ltd. (GME) (collectively, the Mobility business unit). In the consolidated statements of operations for 2020, all sales, costs, expenses, income taxes and gain on sale attributable to the Mobility business unit have been aggregated under the caption “Income from discontinued operations, net of income taxes”. See Note 9 for additional information.

[0000950170-23-005994:notes:7]
The Company operates on a 52 or 53 week fiscal calendar with the fourth quarter ending on the Monday nearest December 31. Fiscal year 2022 and 2020 consisted of 52 weeks ended on January 2, 2023 and December 28, 2020, respectively. Fiscal year 2021 consisted of 53 weeks ended on January 3, 2022, with the additional week included in the fourth quarter. All references to years relate to fiscal years unless otherwise noted.

[0000950170-23-005994:notes:8]
Reclassifications

[0000950170-23-005994:notes:9]
The Company currently has two reportable segments: PCB and RF and Specialty Components (RF&S Components). On April 29, 2020, the Company announced the restructuring of its E-M Solutions business unit. In prior periods, the Company’s E-M Solutions business unit consisted of three Chinese manufacturing facilities with two being in Shanghai (SH BPA and SH E-MS) and one in Shenzhen (SZ). The Company closed the SH E-MS and SZ facilities at the end of 2020 and integrated the SH BPA facility into its PCB operations. As of March 29, 2021, E-M Solutions no longer met the criteria for segment reporting. As a result of the restructuring of the E-M Solutions business unit, certain prior year amounts have been reclassified to conform to this new presentation.

[0000950170-23-005994:notes:10]
Use of Estimates

[0000950170-23-005994:notes:11]
The preparation of financial statements in conformity with accounting principles generally accepted in the United States of America (U.S. GAAP) requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities and disclosure of contingent assets and liabilities at the date of the financial statements and the reported amount of revenues and expenses during the reporting period. These estimates and assumptions are based on management’s best estimates and judgment. Due, in part, to the on-going effects of the coronavirus (COVID-19) global pandemic on the Company and the conflict between Russia and Ukraine, the global economy and financial markets have been volatile, and both the pandemic and conflict has contributed to on-going disruptions in global supply chains, labor shortages, high inflation, and a potential recession, and there is a significant amount of uncertainty about the length and severity of the direct and indirect effects of the pandemic and the conflict. The Company has considered information available to it as of the date of issuance of these financial statements and is not aware of any specific events or circumstances that would require an update to its estimates or judgments, or a revision to the carrying value of its assets or liabilities. Management evaluates its estimates and assumptions on an ongoing basis using historical experience and other factors, including the economic environment, which management believes to be reasonable under the circumstances. Management adjusts such estimates and assumptions when facts and circumstances dictate. The actual results the Company experienced may differ materially and adversely from its estimates. To the extent there are material differences between the estimates and actual results, the Company’s future result of operations will be affected.

[0000950170-23-005994:notes:12]
Principles of Consolidation

[0000950170-23-005994:notes:13]
The consolidated financial statements include the accounts of TTM and its subsidiaries. All intercompany accounts and transactions have been eliminated in consolidation.

[0000950170-23-005994:notes:14]
Foreign Currency Translation and Transactions

[0000950170-23-005994:notes:15]
The functional currency of one of the Company’s subsidiaries is the Chinese Renminbi (RMB). Accordingly, assets and liabilities are translated into U.S. dollars using period-end exchange rates. Sales and expenses are translated at the average exchange rates in effect during the period. The resulting translation gains or losses are recorded as a component of accumulated other comprehensive income/(loss) in the consolidated statement of stockholders’ equity and the consolidated statement of comprehensive income. Net gains and losses resulting from foreign currency remeasurements and transactions are included in income as a component of other, net in the consolidated statements of operations and totaled $12,756 gain, $5,033 loss and $10,475 loss for the years ended January 2, 2023, January 3, 2022 and December 28, 2020, respectively.

[0000950170-23-005994:notes:16]
Cash Equivalents

[0000950170-23-005994:notes:17]
The Company considers highly liquid investments with insignificant interest rate risk and original maturities to the Company of three months or less to be cash equivalents.

[0000950170-23-005994:notes:18]
Accounts Receivable and Allowance for Doubtful Accounts

[0000950170-23-005994:notes:19]
Accounts receivable are reflected at estimated net realizable value, do not bear interest and do not generally require collateral. The Company performs credit evaluations of its customers and adjusts credit limits based upon payment history and the customer’s current creditworthiness. The Company maintains an allowance for doubtful accounts based upon a variety of factors. The Company considers both current and forecasted future economic conditions in determining the adequacy of its allowance for doubtful accounts.

[0000950170-23-005994:notes:20]
The Company’s allowance for doubtful accounts was $2,075, $1,558 and $2,886 as of January 2, 2023, January 3, 2022 and December 28, 2020, respectively.

[0000950170-23-005994:notes:21]
Inventories

[0000950170-23-005994:notes:22]
Inventories are stated at the lower of cost (determined on a first-in, first-out or weighted average basis) or net realizable value. Assessments to value the inventory at the lower of the actual cost to purchase and/or manufacture the inventory, or net realizable value of the inventory, are based upon assumptions about future demand and market conditions. As a result of the Company’s assessments, when the net realizable value of inventory is less than the carrying value, the inventory cost is written down to the net realizable value and the write down is recorded as a charge to cost of goods sold.

[0000950170-23-005994:notes:23]
Property, Plant and Equipment, Net

[0000950170-23-005994:notes:24]
Property, plant and equipment are recorded at cost. Depreciation expense is computed using the straight-line method over the estimated useful lives of the assets. Assets recorded under leasehold improvements are amortized using the straight-line method over the lesser of their useful lives or the related lease term. The Company uses the following estimated useful lives:

[0000950170-23-005994:notes:25]
| Land use rights |  | 50-99 years |
| Buildings and improvements |  | 7-50 years |
| Machinery and equipment |  | 3-10 years |
| Furniture and fixtures |  | 3-7 years |

[0000950170-23-005994:notes:26]
Upon retirement or other disposition of property, plant and equipment, the cost and related accumulated depreciation are removed from the accounts. The resulting gain or loss is included in the determination of operating income in the period incurred. Depreciation and amortization expense on property, plant and equipment was $91,276, $85,942 and $99,572 for the years ended January 2, 2023, January 3, 2022 and December 28, 2020, respectively.

[0000950170-23-005994:notes:27]
The Company capitalizes interest on borrowings during the active construction period of major capital projects. Capitalized interest is amortized over the average useful lives of such assets, which primarily consist of buildings and machinery and equipment. The Company capitalized interest costs of $731, $936 and $1,783 during the years ended January 2, 2023, January 3, 2022 and December 28, 2020, respectively, in connection with various capital projects.

[0000950170-23-005994:notes:28]
Major renewals and betterments are capitalized and depreciated over their estimated useful lives while minor expenditures for maintenance and repairs are included in operating income as incurred.

[0000950170-23-005994:notes:29]
Goodwill

[0000950170-23-005994:notes:30]
Goodwill represents the excess of purchase price of an acquisition over the fair value of net assets acquired. Goodwill is not amortized but instead is assessed for impairment, at a reporting unit level, annually and when events and circumstances warrant an evaluation. Goodwill is allocated to reporting units, which are operating segments or one level below the Company’s operating segments (the component level). Reporting units are determined by the discrete financial information available for the component and whether it is regularly reviewed by segment management. Components are aggregated into a single reporting unit if they share similar economic

[0000950170-23-005994:notes:31]
characteristics. The Company evaluates its goodwill on an annual basis in the fourth quarter or more frequently if it believes indicators of impairment exist. The Company assesses qualitative factors to determine whether it is more likely than not that the fair value of a reporting unit is less than its carrying amount or performs a quantitative impairment test. When tested quantitatively, the Company compares the fair value of the applicable reporting unit with its carrying value. In making this assessment, management relies on a number of factors, including expected future operating results, business plans, economic projections, anticipated future cash flows, business trends and declines in the Company’s market capitalization. The Company estimates the fair values of its reporting units using a combination of the discounted cash flow (DCF) and market approaches. If the carrying amount of a reporting unit exceeds the reporting unit’s fair value, the amount by which the carrying value exceeds the fair value is recognized as an impairment loss. See Note 5 for further details.

[0000950170-23-005994:notes:32]
Intangible Assets

[0000950170-23-005994:notes:33]
Intangible assets include customer relationships, technology, and trade names which are being amortized over their estimated useful lives on a straight-line basis. The estimated useful lives of such intangibles range from 5 years to 13 years.

[0000950170-23-005994:notes:34]
Impairment of Long-lived Assets

[0000950170-23-005994:notes:35]
Long-lived tangible assets, including property, plant and equipment, assets held for sale, and definite-lived intangible assets, are reviewed for impairment whenever events or changes in circumstances indicate that the carrying value of the asset or asset groups may not be recoverable. The Company regularly evaluates whether events or circumstances have occurred that indicate possible impairment and relies on a number of factors, including expected future operating results, business plans, economic projections, and anticipated future cash flows. The Company uses an estimate of the future undiscounted net cash flows of the related asset or asset group over the remaining life in measuring whether the assets are recoverable. If the sum of the undiscounted cash flows is less than the carrying amount of the net assets, impairment is measured based on the difference between the net asset’s carrying value and estimated fair value. Fair value is determined through various valuation techniques, including cost-based, market and income approaches as considered necessary.

[0000950170-23-005994:notes:36]
The Company classifies assets to be sold as assets held for sale when (i) Company management has approved and commits to a plan to sell the asset; (ii) the asset is available for immediate sale in its present condition and is ready for sale; (iii) an active program to locate a buyer and other actions required to sell the asset have been initiated; (iv) the sale of the asset is probable; (v) the asset is being actively marketed for sale at a price that is reasonable in relation to its current fair value; and (vi) it is unlikely that significant changes to the plan will be made or that the plan will be withdrawn. Assets classified as held for sale are recorded at the lower of the carrying amount or fair value less the cost to sell.

[0000950170-23-005994:notes:37]
The Company classifies assets held for use when a decision to dispose of an asset or a business is made and the held for sale criteria are not met. In evaluating the recoverability of property and intangible assets subject to amortization, in a held for use business, the carrying value is first compared to the sum of the undiscounted cash flows expected to result from the use and eventual disposition. If the carrying value exceeds the undiscounted expected cash flows, then a fair value analysis is performed. An impairment charge is recognized if the carrying value exceeds the fair value.

[0000950170-23-005994:notes:38]
Leases

[0000950170-23-005994:notes:39]
The Company determines if an arrangement is a lease at inception. Operating leases are included in operating lease right-of-use (ROU) assets, and lease liabilities are included in other current liabilities and operating lease liabilities on the consolidated balance sheets. Finance lease ROU assets are included in property, plant and equipment, net and lease liabilities are included in other current liabilities and other long-term liabilities on the consolidated balance sheets.

[0000950170-23-005994:notes:40]
ROU assets represent the Company’s right to use an underlying asset for the lease term and lease liabilities represent the Company’s obligation to make lease payments arising from the lease. Operating and finance lease ROU assets and liabilities are recognized at commencement date based on the present value of lease payments over the lease term. As most of the Company’s leases do not provide an implicit rate, the Company uses its incremental borrowing rate based on the information available at the commencement date in determining the present value of lease payments. The operating and finance lease ROU assets also include any lease payments made and excludes lease incentives. Lease terms may include options to extend or terminate the lease when it is reasonably certain that the Company will exercise that option. Operating lease expense is recognized on a straight-line basis over the lease term. Finance lease expense is recognized based on the effective interest method over the lease term.

[0000950170-23-005994:notes:41]
The Company has lease agreements with lease and non-lease components and accounts for the lease and non-lease components as a single lease component.

[0000950170-23-005994:notes:42]
Revenue Recognition

[0000950170-23-005994:notes:43]
The Company derives revenues primarily from the sale of PCBs, engineered systems using customer-supplied engineering and design plans as well as long-term contracts related to the design and manufacture of highly sophisticated intelligence, surveillance and

[0000950170-23-005994:notes:44]
communications solutions, RF and microwave/microelectronics components, assemblies, and subsystems. In the absence of a sales agreement, the Company’s standard terms and conditions apply. Revenue is recognized when control of the promised goods or services is transferred to the Company’s customers, in an amount that reflects the consideration to which it expects to be entitled in exchange for those goods or services. The Company applies a five-step approach in determining the amount and timing of revenue to be recognized: (1) identifying the contract with a customer; (2) identifying the performance obligations in the contract; (3) determining the transaction price; (4) allocating the transaction price to the performance obligations in the contract; and (5) recognizing revenue when the corresponding performance obligation is satisfied.

[0000950170-23-005994:notes:45]
Revenue Streams

[0000950170-23-005994:notes:46]
For PCBs and engineered systems, including pursuant to the Company’s long-term contracts related to the manufacture of highly sophisticated intelligence, surveillance and communications solutions, components, assemblies and subsystems, orders for products generally correspond to the production schedules of the Company’s customers and are supported with firm purchase orders. The Company’s customers have continuous control of the work in progress and finished goods throughout the PCB and engineered systems manufacturing process, as these are built to customer specifications with no alternative use, and there is an enforceable right to payment for work performed to date. As a result, the Company recognizes revenue progressively over time based on the extent of progress towards completion of the performance obligation. Revenue recognized is based on a cost method as it best depicts the transfer of control to the customer which takes place as we incur costs. Revenues are recorded proportionally as costs are incurred. For contracts in which anticipated total costs exceed the total expected revenue, an estimated loss is recognized in the period when identifiable. A provision for the entire amount of the estimated loss is recorded on a cumulative basis. The estimated remaining costs to complete for loss contracts as of January 2, 2023 was $21,632 and the provision is recorded as a reduction to gross margin on the consolidated statements of operations.

[0000950170-23-005994:notes:47]
In addition, the Company manufactures components, assemblies, subsystems, and completed systems which service its RF&S Components and certain aerospace and defense customers. The Company recognizes revenue at a point in time upon transfer of control of the products to the customer. Point in time recognition was determined as the customer does not simultaneously receive or consume the benefits provided by the Company’s performance and the asset being manufactured has alternative uses to the Company.

[0000950170-23-005994:notes:48]
Performance Obligations

[0000950170-23-005994:notes:49]
Each distinct promise to transfer products is considered to be an identified performance obligation for which revenue is recognized upon transfer of control of the products to the customer. A contract’s transaction price is allocated to each distinct performance obligation and recognized as revenue when, or as, the performance obligation is satisfied. The majority of the Company's contracts have a single performance obligation as the promise to transfer the individual good or service is not separately identifiable from other promises in the contract and is, therefore, not distinct. As of January 2, 2023, the aggregate amount of the transaction price allocated to remaining performance obligations for the Company’s long-term contracts was $375,941. The Company expects to recognize revenue on approximately 49% of the remaining performance obligations for the Company’s long-term contracts over the next twelve months with the remaining amount recognized thereafter. The remaining performance obligations for the Company’s short-term contracts are expected to be recognized within one year.

[0000950170-23-005994:notes:50]
Transaction Price

[0000950170-23-005994:notes:51]
The Company provides customers a limited right of return for defective PCBs including components, subsystems and assemblies. Estimates of returns are treated as variable consideration for purposes of determining the transaction price. The Company accrues an estimate for sales returns and allowances progressively over time based on the extent of progress towards completion of the performance obligation using the Company’s judgment based on historical results and anticipated returns. To the extent actual experience varies from its historical experience, revisions to the sales returns and allowances accrual may be required. Sales returns and allowances are recorded as a reduction of revenue and included as a component of other current liabilities on the consolidated balance sheets. Shipping and handling fees and related freight costs and supplies associated with shipping products to customers are included as a component of cost of goods sold. Warranty-related services are not considered a separate performance obligation. Incremental warranty costs that are not related to sales returns are recorded in other current liabilities on the consolidated balance sheets and cost of goods sold on the consolidated statements of operations. The following summarizes the activity in the Company’s sales returns and allowances for the years ended January 2, 2023, January 3, 2022 and December 28, 2020:

[0000950170-23-005994:notes:52]
|  |  | For the Year Ended |  |
|  |  | January 2, |  |  | January 3, |  |  | December 28, |  |
|  |  | 2023 |  |  | 2022 |  |  | 2020 |  |
|  |  | (In thousands) |  |
| Balance at beginning of year |  | $ | 12,853 |  |  | $ | 13,015 |  |  | $ | 12,717 |  |
| Addition charged as a reduction of sales |  |  | 2,410 |  |  |  | 5,635 |  |  |  | 7,658 |  |
| Deductions |  |  | (2,914 | ) |  |  | (5,767 | ) |  |  | (7,389 | ) |
| Effect of foreign currency exchange rates |  |  | (30 | ) |  |  | (30 | ) |  |  | 29 |  |
| Balance at end of year |  | $ | 12,319 |  |  | $ | 12,853 |  |  | $ | 13,015 |  |

[0000950170-23-005994:notes:53]
Contract Balances

[0000950170-23-005994:notes:54]
Accounts receivable represents the Company’s unconditional right to receive consideration from its customer. Payments are generally due within 90 days or less of invoicing and do not include a significant financing component. To date, there have been no material credit losses on accounts receivable.

[0000950170-23-005994:notes:55]
A contract asset is recognized when the Company has recognized revenue, but not issued an invoice for payment. Amounts will be invoiced when applicable contract terms, such as the achievement of specified milestones or product delivery, are met. Contract assets are transferred to receivables when the entitlement to payment becomes unconditional. Contract assets were $335,788 and $324,862 as of January 2, 2023 and January 3, 2022, respectively, and represent unbilled amounts for work performed to date. Contract assets increased by $24,972 due to the acquisition of Telephonics Corporation on June 27, 2022. In addition, as a result of the acquisition of Telephonics Corporation, $7,096 of contract assets are expected to be collected after one year and included as a component of deposits and other non-current assets on the consolidated balance sheets as of January 2, 2023. There were no contract assets expected to be collected after one year as of January 3, 2022. In 2022, there were no material impairment losses on contract assets.

[0000950170-23-005994:notes:56]
A contract liability is recognized when the Company has received payment in advance for the future transfer of goods or services. The Company’s contract liabilities are reduced as the contract requirements are fulfilled. Contract liabilities were $103,981 and $14,189 as of January 2, 2023 and January 3, 2022 respectively, and represent customer advances for work yet to be performed. The contract liabilities increased by $52,360 due to the acquisition of Telephonics Corporation on June 27, 2022.

[0000950170-23-005994:notes:57]
The remaining change in the balances of the Company’s contract assets and liabilities primarily results from timing differences between revenue recognition and customer billings and/or payments.

[0000950170-23-005994:notes:58]
The Company has elected to account for shipping and handling activities as a fulfillment cost as permitted by the standard. All incremental customer contract acquisition costs are expensed as they are incurred as the amortization period of the asset that the Company otherwise would have recognized is one year or less in duration.

[0000950170-23-005994:notes:59]
Disaggregated Revenue

[0000950170-23-005994:notes:60]
Revenue from products and services transferred to customers over time and at a point in time accounted for 97% and 3%, respectively, of the Company’s revenue in 2022 and 2021 and 98% and 2%, respectively, of the Company’s revenue in 2020.

[0000950170-23-005994:notes:61]
The following tables represent a disaggregation of revenue by principal end markets with the reportable segments:

[0000950170-23-005994:notes:62]
|  |  | For the Year Ended January 2, 2023 |  |  |
|  |  | PCB |  |  | RF&S Components |  |  | Total |  |  |
| End Markets |  | (In thousands) |  |  |
| Aerospace and Defense |  | $ | 862,367 |  |  | $ | — |  |  | $ | 862,367 |  |  |
| Automotive |  |  | 428,022 |  |  |  | — |  |  |  | 428,022 |  |  |
| Data Center Computing (2) |  |  | 378,114 |  |  |  | 34 |  |  |  | 378,148 |  |  |
| Medical/Industrial/Instrumentation |  |  | 486,088 |  |  |  | 5,708 |  |  |  | 491,796 |  |  |
| Networking |  |  | 278,911 |  |  |  | 52,414 |  |  |  | 331,325 |  |  |
| Other |  |  | 4,440 |  |  |  | (1,052 | ) |  |  | 3,388 |  |  |
| Total |  | $ | 2,437,942 |  |  | $ | 57,104 |  |  | $ | 2,495,046 |  |  |

[0000950170-23-005994:notes:63]
|  |  | For the Year Ended January 3, 2022 |  |  |
|  |  | PCB |  |  | RF&S Components |  |  | Other (1) |  |  | Total |  |  |
| End Markets |  | (In thousands) |  |  |
| Aerospace and Defense |  | $ | 727,868 |  |  | $ | 137 |  |  | $ | — |  |  | $ | 728,005 |  |  |
| Automotive |  |  | 407,063 |  |  |  | — |  |  |  | 3,642 |  |  |  | 410,705 |  |  |
| Data Center Computing (2) |  |  | 323,528 |  |  |  | 457 |  |  |  | — |  |  |  | 323,985 |  |  |
| Medical/Industrial/Instrumentation |  |  | 416,504 |  |  |  | 4,880 |  |  |  | 25 |  |  |  | 421,409 |  |  |
| Networking |  |  | 297,569 |  |  |  | 49,059 |  |  |  | 1 |  |  |  | 346,629 |  |  |
| Other |  |  | 14,369 |  |  |  | 4,050 |  |  |  | (412 | ) |  |  | 18,007 |  |  |
| Total |  | $ | 2,186,901 |  |  | $ | 58,583 |  |  | $ | 3,256 |  |  | $ | 2,248,740 |  |  |

[0000950170-23-005994:notes:64]
|  |  | For the Year Ended December 28, 2020 |  |  |
|  |  | PCB |  |  | RF&S Components |  |  | Other (1) |  |  | Total |  |  |
| End Markets |  | (In thousands) |  |  |
| Aerospace and Defense |  | $ | 745,050 |  |  | $ | 189 |  |  | $ | 646 |  |  | $ | 745,885 |  |  |
| Automotive |  |  | 269,755 |  |  |  | — |  |  |  | 49,100 |  |  |  | 318,855 |  |  |
| Cellular Phone |  |  | 1,341 |  |  |  | — |  |  |  | — |  |  |  | 1,341 |  |  |
| Data Center Computing (2) |  |  | 258,078 |  |  |  | 834 |  |  |  | 124 |  |  |  | 259,036 |  |  |
| Medical/Industrial/Instrumentation |  |  | 375,106 |  |  |  | 2,967 |  |  |  | 9,622 |  |  |  | 387,695 |  |  |
| Networking |  |  | 308,421 |  |  |  | 39,160 |  |  |  | 23,003 |  |  |  | 370,584 |  |  |
| Other |  |  | 23,167 |  |  |  | 1,506 |  |  |  | (2,747 | ) |  |  | 21,926 |  |  |
| Total |  | $ | 1,980,918 |  |  | $ | 44,656 |  |  | $ | 79,748 |  |  | $ | 2,105,322 |  |  |

[0000950170-23-005994:notes:65]
(1)
Other represents results from the now closed SH E-MS and SZ facilities.

[0000950170-23-005994:notes:66]
(2)
Beginning in the first quarter of 2021, the Computing/Storage/Peripherals end market was renamed to Data Center Computing to better reflect the customer mix and growth prospects. There was no change to the customers included in this end market.

[0000950170-23-005994:notes:67]
Value Added and Sales Tax Collected from Customers

[0000950170-23-005994:notes:68]
As a part of the Company’s normal course of business, value added and sales taxes are collected from customers. Such taxes collected are remitted, in a timely manner, to the appropriate governmental tax authority on behalf of the customer. Value added and sales taxes are excluded from reported revenues and costs of goods sold presented in the consolidated statements of operations and comprehensive income.

[0000950170-23-005994:notes:69]
Stock-Based Compensation

[0000950170-23-005994:notes:70]
The Company recognizes stock-based compensation expense in its consolidated financial statements for its incentive compensation plan awards. The incentive compensation plan awards include performance-based restricted stock units, restricted stock units, and stock options. The associated compensation expense for all awards is based on the grant date fair value of the awards. For performance-based restricted stock units, compensation expense also includes management’s periodic assessment of annual financial performance goals to be achieved. Compensation expense for the incentive compensation plan awards is recognized on a straight line basis over the vesting period of the awards. The fair value of performance-based restricted stock units is estimated on the grant date using a Monte Carlo simulation model based on the underlying common stock closing price as of the date of grant, stock price volatility, and risk-free interest rates. The fair value of restricted stock units is measured on the grant date based on the quoted closing market price of the Company’s common stock. The fair value of the stock options is estimated on the grant date using the Black-Scholes option

[0000950170-23-005994:notes:71]
pricing model based on the underlying common stock closing price as of the date of grant, the expected term, stock price volatility, and risk-free interest rates.

[0000950170-23-005994:notes:72]
Income Taxes

[0000950170-23-005994:notes:73]
Income taxes are accounted for under the asset and liability method. Deferred income tax assets or liabilities are recognized for the future tax consequences attributable to differences between the financial statement carrying amounts of assets and liabilities and their respective tax bases and operating loss and tax credit carryforwards. Deferred income tax assets and liabilities are measured using enacted tax rates expected to apply to taxable income in the years in which those temporary differences are expected to be settled or realized. The effect on deferred income tax assets and liabilities of a change in tax rates is recognized in income in the period that includes the enactment date. Deferred income tax assets are reviewed for recoverability, and the Company records a valuation allowance to reduce its deferred income tax assets when it is more likely than not that all or some portion of the deferred income tax assets will not be realized.

[0000950170-23-005994:notes:74]
The Company has various foreign subsidiaries formed or acquired to conduct or support its business outside the United States. The Company expects its earnings attributable to foreign subsidiaries will not be indefinitely reinvested except for certain subsidiaries, and we have established a deferred tax liability for foreign withholding taxes and the estimated federal/state tax impact. For those other companies with earnings currently being reinvested outside of the U.S., no deferred tax liabilities on undistributed earnings are recorded.

[0000950170-23-005994:notes:75]
The Company recognizes the effect of income tax positions only if those positions are more likely than not to be sustained. Recognized income tax positions are measured at the largest amount that is greater than 50 percent likely to be realized. Changes in recognition or measurement are reflected in the period in which the change in judgment occurs. Estimated interest and penalties related to underpayment of income taxes are recorded as a component of income tax provision in the consolidated statements of operations.

[0000950170-23-005994:notes:76]
Fair Value Measures

[0000950170-23-005994:notes:77]
The Company measures at fair value certain of its financial and non-financial assets and liabilities by using a fair value hierarchy that prioritizes the inputs to valuation techniques used to measure fair value. Fair value is the price that would be received to sell an asset or paid to transfer a liability in an orderly transaction between market participants at the measurement date, essentially an exit price, based on the highest and best use of the asset or liability. The levels of the fair value hierarchy are:

[0000950170-23-005994:notes:78]
Level 1 — Quoted market prices in active markets for identical assets or liabilities;

[0000950170-23-005994:notes:79]
Level 2 — Significant other observable inputs (e.g., quoted prices for similar items in active markets, quoted prices for identical or similar items in markets that are not active, inputs other than quoted prices that are observable, such as interest rate and yield curves, and market-corroborated inputs); and

[0000950170-23-005994:notes:80]
Level 3 — Unobservable inputs in which there is little or no market data, which require the reporting unit to develop its own assumptions.

[0000950170-23-005994:notes:81]
Earnings Per Share

[0000950170-23-005994:notes:82]
Basic earnings per common share excludes dilution and is computed by dividing net income by the weighted average number of common shares outstanding during the period. Diluted earnings per common share reflect the potential dilution that could occur if stock options, Convertible Senior Notes or other common stock equivalents were exercised or converted into common stock. The dilutive effect of stock options or other common stock equivalents is calculated using the treasury stock method. During the year ended December 28, 2020, the Company calculated the dilutive effect of Convertible Senior Notes using the treasury stock method because the Company repaid and settled the Convertible Senior Notes in cash.

[0000950170-23-005994:notes:83]
Comprehensive Income

[0000950170-23-005994:notes:84]
Comprehensive income includes changes to equity accounts that were not the result of transactions with stockholders. Comprehensive income is comprised of net income, changes in the cumulative foreign currency translation adjustments, pension obligation adjustments, and realized and unrealized gains or losses on hedged derivative instruments.

[0000950170-23-005994:notes:85]
Loss Contingencies

[0000950170-23-005994:notes:86]
The Company establishes an accrual for an estimated loss contingency when it is both probable that an asset has been impaired or that a liability has been incurred and the amount of the loss can be reasonably estimated. Any legal fees expected to be incurred in connection with a contingency are expensed as incurred.

[0000950170-23-005994:notes:87]
Accounting for Retirement Benefit Plans

[0000950170-23-005994:notes:88]
The Company accounts for its retirement benefit plans and postretirement and postemployment benefit obligations in accordance with ASC Topic 715, Compensation—Retirement Benefits. ASC Topic 715 requires the Company to recognize the overfunded or underfunded status of a defined benefit plan, measured as the difference between the fair value of plan assets and the plan's benefit obligation, as an asset or liability in its consolidated balance sheets and to recognize changes to that funded status in the year in which the changes occur through accumulated other comprehensive loss. ASC Topic 715 also requires measurement of the funded status of a plan as of the Company's consolidated balance sheet dates.

[0000950170-23-005994:notes:89]
Recently Adopted and Issued Accounting Standards

[0000950170-23-005994:notes:90]
Recently Adopted Accounting Standards

[0000950170-23-005994:notes:91]
In November 2021, the Financial Accounting Standards Board (FASB) issued Accounting Standards Update (ASU) 2021-10, Government Assistance (Topic 832): Disclosures by Business Entities about Government Assistance, which provides guidance on disclosures for transactions with a government that are accounted for by applying a grant or contribution accounting model by analogy. The guidance is effective for fiscal years, and for interim periods within those fiscal years, beginning after December 15, 2021. Early adoption is permitted. The Company adopted this ASU and it did not have a material impact on the consolidated financial statements.

[0000950170-23-005994:notes:92]
In October 2021, the FASB issued ASU 2021-08, Business Combinations (Topic 805): Accounting for Contract Assets and Contract Liabilities from Contracts with Customers, which requires that an acquirer recognize and measure contract assets and contract liabilities acquired in a business combination in accordance with Accounting Standards Codification (ASC) 606, Revenue from Contracts with Customers, as if it had originated the contracts. Prior to this ASU, an acquirer generally recognizes contract assets acquired and contract liabilities assumed that arose from contracts with customers at fair value on the acquisition date. The ASU is effective for fiscal years beginning after December 15, 2022, with early adoption permitted. The ASU is to be applied prospectively to business combinations occurring on or after the effective date of the amendment (or if adopted early as of an interim period, as of the beginning of the fiscal year that includes the interim period of early application). The Company early adopted ASU 2021-08 on April 4, 2022 and did not have an impact on its consolidated financial statements and related disclosures. The new guidance was applied to the acquisition of Gritel Holding Co., Inc. (Gritel), ISC Farmingdale Corp., and Gritel's wholly owned subsidiary, Telephonics Corporation.

[0000950170-23-005994:notes:93]
Recently Issued Accounting Standards Not Yet Adopted

[0000950170-23-005994:notes:94]
In September 2022, the FASB issued ASU 2022-04, Liabilities - Supplier Finance Programs (Topic 450-50): Disclosure of Supplier Finance Program Obligations, that requires entities that use supplier finance programs in connection with the purchase of goods and services to disclose the key terms of the programs and information about obligations outstanding at the end of the reporting period, including a rollforward of those obligations. The guidance does not affect the recognition, measurement or financial statement presentation of supplier finance program obligations. The amendments are effective for all entities for fiscal years beginning after December 15, 2022 on a retrospective basis, including interim periods within those fiscal years, except for the requirement to disclose rollforward information, which is effective prospectively for fiscal years beginning after December 15, 2023. Early adoption is permitted upon issuance of the update. The Company is currently evaluating the new guidance to determine the impact it may have on its consolidated financial statements and related disclosures.


## us-gaap:LesseeOperatingLeasesTextBlock

[0000950170-23-005994:notes:95]
(2)
Leases

[0000950170-23-005994:notes:96]
The Company leases some of its manufacturing and assembly plants, sales offices and equipment under non-cancellable operating leases and finance leases that expire at various dates through 2049. The majority of the Company’s lease arrangements are comprised of fixed payments, and certain leases consist of variable payments based on equipment usage. These variable payments are not included in the measurement of the ROU asset or lease liability due to uncertainty of the payment amount and are recorded as lease expense in the period incurred. Certain leases contain renewal provisions at the Company’s option. Most of the leases require the Company to pay for certain other costs such as property taxes and maintenance. Certain leases also contain rent escalation clauses (step rents) that require additional rental amounts in the later years of the term. Rent expense for leases with step rents is recognized on a straight-line basis over the minimum lease term. The lease agreements do not contain any material residual value guarantees or material restrictive covenants.

[0000950170-23-005994:notes:97]
The components of lease expense were as follows:

[0000950170-23-005994:notes:98]
|  |  | For the Year Ended |  |
|  |  | January 2, 2023 |  |  | January 3, 2022 |  |  | December 28, 2020 |  |
|  |  | (In thousands) |  |
| Operating lease cost |  | $ | 7,751 |  |  | $ | 7,907 |  |  | $ | 9,304 |  |
| Variable lease cost |  |  | 1,140 |  |  |  | 798 |  |  |  | 529 |  |
| Short-term lease cost |  |  | 708 |  |  |  | 338 |  |  |  | 525 |  |
| Finance lease costs: |  |  |  |  |  |  |  |  |  |
| Amortization of right-of-use assets |  |  | 1,374 |  |  |  | 538 |  |  |  | — |  |
| Interest on lease liabilities |  |  | 392 |  |  |  | 159 |  |  |  | — |  |

[0000950170-23-005994:notes:99]
Supplemental cash flow information related to leases was as follows:

[0000950170-23-005994:notes:100]
|  |  | For the Year Ended |  |
|  |  | January 2, 2023 |  |  | January 3, 2022 |  |  | December 28, 2020 |  |
|  |  | (In thousands) |  |
| Cash paid for amounts included in the measurement of lease liabilities: |  |  |  |  |  |  |  |  |  |
| Operating cash flows for operating leases |  | $ | 7,746 |  |  | $ | 8,308 |  |  | $ | 8,865 |  |
| Right-of-use assets obtained in exchange for new lease obligations: |  |  |  |  |  |  |  |  |  |
| Operating leases |  |  | 7,896 |  |  |  | 8,651 |  |  |  | 10,036 |  |
| Finance leases |  |  | — |  |  |  | 15,297 |  |  |  | — |  |

[0000950170-23-005994:notes:101]
Supplemental balance sheet information related to leases was as follows:

[0000950170-23-005994:notes:102]
|  |  |  |  | As of |  |
|  |  | Balance Sheet Location |  | January 2, 2023 |  |  | January 3, 2022 |  |
|  |  |  |  | (In thousands) |  |
| Assets: |  |  |  |  |  |  |  |  |
| Operating leases |  | Operating lease right-of-use assets |  | $ | 18,862 |  |  | $ | 20,802 |  |
| Finance leases |  | Property, plant and equipment, net |  |  | 13,384 |  |  |  | 14,759 |  |
| Total lease assets |  |  |  | $ | 32,246 |  |  | $ | 35,561 |  |
| Liabilities: |  |  |  |  |  |  |  |  |
| Current: |  |  |  |  |  |  |  |  |
| Operating leases |  | Other current liabilities |  | $ | 7,368 |  |  | $ | 6,362 |  |
| Finance leases |  | Other current liabilities |  |  | 736 |  |  |  | 698 |  |
| Long-term: |  |  |  |  |  |  |  |  |
| Operating leases |  | Operating lease liabilities |  |  | 12,249 |  |  |  | 15,252 |  |
| Finance leases |  | Other long-term liabilities |  |  | 13,579 |  |  |  | 14,317 |  |
| Total lease liabilities |  |  |  | $ | 33,932 |  |  | $ | 36,629 |  |

[0000950170-23-005994:notes:103]
|  |  | As of |  |
|  |  | January 2, 2023 |  |  | January 3, 2022 |  |
| Weighted average remaining lease term (years): |  |  |  |  |  |  |
| Operating leases |  | 3.3 |  |  | 3.9 |  |
| Finance leases |  | 13.6 |  |  | 14.6 |  |
| Weighted average discount rate: |  |  |  |  |  |  |
| Operating leases |  |  | 3.09 | % |  |  | 2.56 | % |
| Finance leases |  |  | 2.69 | % |  |  | 2.68 | % |

[0000950170-23-005994:notes:104]
Maturities of lease liabilities were as follows:

[0000950170-23-005994:notes:105]
|  |  | OperatingLeases (1) |  |  | FinanceLeases |  |
|  |  | (In thousands) |  |
| Less than one year |  | $ | 7,832 |  |  | $ | 1,109 |  |
| 1 - 2 years |  |  | 6,493 |  |  |  | 1,134 |  |
| 2 - 3 years |  |  | 3,572 |  |  |  | 1,145 |  |
| 3 - 4 years |  |  | 1,608 |  |  |  | 1,175 |  |
| 4 - 5 years |  |  | 494 |  |  |  | 1,197 |  |
| Thereafter |  |  | 724 |  |  |  | 11,459 |  |
| Total lease payments |  |  | 20,723 |  |  |  | 17,219 |  |
| Less imputed interest |  |  | (1,106 | ) |  |  | (2,904 | ) |
| Total |  | $ | 19,617 |  |  | $ | 14,315 |  |

[0000950170-23-005994:notes:106]
(1)
Excludes $1,205 of legally binding minimum lease payments for leases signed but not yet commenced.


## us-gaap:BusinessCombinationDisclosureTextBlock

[0000950170-23-005994:notes:107]
(3)
Acquisition of Gritel and ISC Farmingdale Corp.

[0000950170-23-005994:notes:108]
On June 27, 2022, the Company completed its acquisition of all of the issued and outstanding capital stock of Gritel and ISC Farmingdale Corp. for a total consideration of $298,339 in cash. At the time of acquisition, Telephonics Corporation was wholly-owned by Gritel, and as a result of the acquisition, became an indirect, wholly-owned subsidiary of the Company (collectively with ISC Farmingdale Corp., Telephonics).

[0000950170-23-005994:notes:109]
For the year ended January 2, 2023, bank fees and legal, accounting, and other professional service costs associated with the acquisition of $11,529 have been expensed and recorded as general and administrative expense in the consolidated statements of operations. There were no bank fees or legal, accounting, or other professional service costs associated with the acquisition for the years ended January 3, 2022 and December 28, 2020.

[0000950170-23-005994:notes:110]
Preliminary Purchase Price Allocation

[0000950170-23-005994:notes:111]
The purchase price was allocated to tangible and intangible assets acquired, and liabilities assumed based on estimates of fair value at the date of the acquisition, June 27, 2022. The excess of the purchase price over the fair value of net assets acquired was allocated to goodwill. The fair values were based on management’s analysis, including work performed by third-party valuation specialists.

[0000950170-23-005994:notes:112]
The fair values assigned are based on reasonable methods applicable to the nature of the assets acquired and liabilities assumed. The following summarizes the estimated fair values of net assets acquired:

[0000950170-23-005994:notes:113]
|  |  | (In thousands) |  |  |
| Accounts receivable |  | $ | 51,140 |  |  |
| Contract assets |  |  | 26,460 |  |  |
| Inventories |  |  | 38,616 |  |  |
| Prepaid expenses and other current assets |  |  | 5,605 |  |  |
| Property, plant and equipment |  |  | 69,253 |  |  |
| Operating lease right-of-use assets |  |  | 497 |  |  |
| Goodwill |  |  | 123,113 |  |  |
| Identifiable intangible assets |  |  | 90,750 |  |  |
| Non-current deferred tax assets |  |  | 2,559 |  |  |
| Deposits and other non-current assets |  |  | 3,129 |  |  |
| Accounts payable |  |  | (16,026 | ) |  |
| Contract liabilities |  |  | (65,262 | ) |  |
| Accrued salaries, wages and benefits |  |  | (10,616 | ) |  |
| Other current liabilities |  |  | (13,134 | ) |  |
| Operating lease liabilities |  |  | (336 | ) |  |
| Other long-term liabilities |  |  | (7,409 | ) |  |
| Total |  | $ | 298,339 |  |  |

[0000950170-23-005994:notes:114]
The areas of the preliminary purchase price allocations that are not yet finalized relate to the fair values of identifiable intangible assets, deferred taxes, tax uncertainties, income taxes payable, and goodwill. As such, fair values may change during the allowable

[0000950170-23-005994:notes:115]
measurement period, which is up to the point the Company obtains and analyzes information that existed as of the date of the acquisition necessary to determine the fair values of the assets acquired and liabilities assumed, but in no case to exceed more than one year from the date of acquisition. Any subsequent changes to the purchase price allocation during the measurement period will be recorded in the reporting period in which the adjustment amounts are determined. Any changes in the fair values of the assets acquired and liabilities assumed during the measurement period may result in material adjustments to goodwill.

[0000950170-23-005994:notes:116]
The Company acquired $38,616 of inventories as a result of the acquisition. Work-in-process inventory was valued at estimated selling prices less costs to complete, costs of disposal and a reasonable profit allowance for the completion and selling effort. Raw materials were valued at estimated replacement cost.

[0000950170-23-005994:notes:117]
Property, Plant and Equipment

[0000950170-23-005994:notes:118]
The fair value of property, plant and equipment was determined by utilizing two approaches: the cost and sales comparison approaches, each including management assumptions. Each approach assumes valuation of the property at the property’s highest and best use.

[0000950170-23-005994:notes:119]
Identifiable Intangible Assets

[0000950170-23-005994:notes:120]
Acquired identifiable intangible assets include customer relationships and trade names. As of January 2, 2023, the Company had not finalized the determination of fair values allocated to identifiable intangible assets. The Company used publicly available benchmarking information, as well as a variety of other assumptions, including market participant assumptions to determine the preliminary values.

[0000950170-23-005994:notes:121]
Goodwill represents the excess of the purchase price over the fair value of assets acquired and liabilities assumed. The Company has integrated Telephonics into the PCB reportable segment. The excess purchase price over the fair value of assets acquired and liabilities assumed has been completely allocated to the PCB reportable segment. The Company believes that the acquisition of Telephonics will strengthen the Company’s differentiated position in the Aerospace and Defense market. The Company believes that these factors support the amount of goodwill recognized as a result of the purchase price paid for Telephonics, in relation to other acquired tangible and intangible assets. The goodwill acquired in the acquisition is not deductible for income tax purposes.

[0000950170-23-005994:notes:122]
Results of Operations

[0000950170-23-005994:notes:123]
Included in the consolidated statements of operations are $125,933 and $10,822, excluding intercompany sales, of net sales and pre-tax income for the year ended January 2, 2023, respectively.

[0000950170-23-005994:notes:124]
Preliminary Pro forma Financial Information (Unaudited)

[0000950170-23-005994:notes:125]
The unaudited preliminary pro forma financial information below gives effect to this acquisition as if it had occurred at the beginning of fiscal 2021, or December 29, 2020. The preliminary pro forma financial information presented includes the effects of adjustments related to the amortization of acquired identifiable intangible assets and decrease in inventory markup, depreciation of acquired fixed assets, and other non-recurring transactions costs directly associated with the acquisition such as legal, accounting and banking fees.

[0000950170-23-005994:notes:126]
The preliminary pro forma financial information as presented below is for informational purposes only and is not necessarily indicative of the actual results that would have been achieved had the acquisition occurred at the beginning of the earliest period presented, or the results that may be achieved in future periods.

[0000950170-23-005994:notes:127]
|  |  | For the Year Ended |  |
|  |  | January 2, 2023 |  |  | January 3, 2022 |  |
|  |  | (In thousands, except per share amounts) |  |
| Net sales |  | $ | 2,602,114 |  |  | $ | 2,506,025 |  |
| Net income |  |  | 103,498 |  |  |  | 57,827 |  |
| Basic earnings per share |  | $ | 1.01 |  |  | $ | 0.54 |  |
| Diluted earnings per share |  | $ | 1.00 |  |  | $ | 0.53 |  |


## us-gaap:AdditionalFinancialInformationDisclosureTextBlock

[0000950170-23-005994:notes:128]
(4)
Composition of Certain Consolidated Financial Statement Captions

[0000950170-23-005994:notes:129]
|  |  | As of |  |
|  |  | January 2, 2023 |  |  | January 3, 2022 |  |
|  |  | (In thousands) |  |
| Inventories: |  |  |  |  |  |  |
| Raw materials |  | $ | 145,561 |  |  | $ | 114,653 |  |
| Work-in-process |  |  | 20,114 |  |  |  | 9,620 |  |
| Finished goods |  |  | 4,964 |  |  |  | 3,339 |  |
|  |  | $ | 170,639 |  |  | $ | 127,612 |  |
| Property, plant and equipment, net: |  |  |  |  |  |  |
| Land and land use rights |  | $ | 76,811 |  |  | $ | 62,015 |  |
| Buildings and improvements |  |  | 443,353 |  |  |  | 429,344 |  |
| Machinery and equipment |  |  | 989,935 |  |  |  | 891,925 |  |
| Furniture and fixtures and other |  |  | 11,327 |  |  |  | 10,360 |  |
| Construction-in-progress |  |  | 27,774 |  |  |  | 25,554 |  |
|  |  |  | 1,549,200 |  |  |  | 1,419,198 |  |
| Less: Accumulated depreciation |  |  | (824,996 | ) |  |  | (753,443 | ) |
|  |  | $ | 724,204 |  |  | $ | 665,755 |  |
| Other current liabilities: |  |  |  |  |  |  |
| Income taxes payable |  | $ | 28,057 |  |  | $ | 7,162 |  |
| Sales return and allowances |  |  | 12,319 |  |  |  | 12,853 |  |
| Interest |  |  | 9,336 |  |  |  | 8,741 |  |
| Accrued facility operating costs |  |  | 9,081 |  |  |  | 9,717 |  |
| Warranty |  |  | 8,045 |  |  |  | 1,450 |  |
| Housing fund |  |  | 7,440 |  |  |  | 7,321 |  |
| Operating leases |  |  | 7,368 |  |  |  | 6,362 |  |
| Accrued professional fees |  |  | 5,123 |  |  |  | 3,390 |  |
| Restructuring |  |  | 2,513 |  |  |  | 34 |  |
| Derivative liabilities |  |  | 1,622 |  |  |  | 4,295 |  |
| Other |  |  | 39,128 |  |  |  | 31,704 |  |
|  |  | $ | 130,032 |  |  | $ | 93,029 |  |
| Other long-term liabilities: |  |  |  |  |  |  |
| Deferred income taxes |  | $ | 54,268 |  |  | $ | 28,361 |  |
| Customer deposits |  |  | 38,750 |  |  |  | — |  |
| Finance leases |  |  | 13,579 |  |  |  | 14,317 |  |
| Defined benefit pension plan liability |  |  | 2,471 |  |  |  | 5,276 |  |
| Other |  |  | 25,976 |  |  |  | 20,958 |  |
|  |  | $ | 135,044 |  |  | $ | 68,912 |  |

[0000950170-23-005994:notes:130]
On December 22, 2022, land, building, and relevant ancillary assets related to the Company’s former Shanghai E-MS (SH E-MS) manufacturing facility was expropriated by the Chinese government for a compensation fee of RMB 477.6 million ($69,240 as of January 2, 2023) generating a gain on the sale of $51,804. The Company will receive the proceeds as follows: 50% before March 30, 2023, 40% before June 30, 2023, and 10% before December 30, 2023.


## us-gaap:GoodwillDisclosureTextBlock

[0000950170-23-005994:notes:131]
(5)
Goodwill

[0000950170-23-005994:notes:132]
As of January 2, 2023 and January 3, 2022, goodwill by reportable segment was as follows:

[0000950170-23-005994:notes:133]
|  |  | PCB |  | RF&S Components |  | Total |  |
|  |  | (In thousands) |  |
| Balance as of January 3, 2022 |  |  |  |  |  |  |  |
| Goodwill |  | $ | 700,724 |  | $ | 177,200 |  | $ | 877,924 |  |
| Accumulated impairment losses |  |  | (171,400 | ) |  | (69,200 | ) |  | (240,600 | ) |
|  |  |  | 529,324 |  |  | 108,000 |  |  | 637,324 |  |
| Goodwill recognized during the year ended January 2, 2023 |  |  | 123,113 |  |  | — |  |  | 123,113 |  |
| Balance as of January 2, 2023 |  |  |  |  |  |  |  |
| Goodwill |  |  | 823,837 |  |  | 177,200 |  |  | 1,001,037 |  |
| Accumulated impairment losses |  |  | (171,400 | ) |  | (69,200 | ) |  | (240,600 | ) |
|  |  | $ | 652,437 |  | $ | 108,000 |  | $ | 760,437 |  |

[0000950170-23-005994:notes:134]
Goodwill recognized as a result of the acquisition of Telephonics is not yet finalized as of January 2, 2023. See Note 3 for additional information.

[0000950170-23-005994:notes:135]
The Company evaluates its goodwill on an annual basis during its fourth fiscal quarter and at other times when events or changes in circumstances — such as significant adverse changes in the business climate or operating results or changes in management strategy, coupled with a decline in the market price of its stock and market capitalization — indicate that there may be a potential impairment.

[0000950170-23-005994:notes:136]
During the fourth quarter of 2022, the Company performed its annual goodwill impairment test quantitatively, which was based on a combination of the income approach utilizing discounted cash flow analysis and the market approach, and concluded that the goodwill was not impaired for the Company’s reporting units. The Company will continue to evaluate its goodwill on an annual basis during its fourth fiscal quarter and whenever events or changes in circumstances indicate that there may be a potential impairment.


## us-gaap:IntangibleAssetsDisclosureTextBlock

[0000950170-23-005994:notes:137]
(6)
Definite-lived Intangibles

[0000950170-23-005994:notes:138]
As of January 2, 2023 and January 3, 2022, the components of definite-lived intangibles were as follows:

[0000950170-23-005994:notes:139]
|  |  | GrossAmount |  |  | AccumulatedAmortization |  |  | NetCarryingAmount |  |  | WeightedAverageAmortizationPeriod |  |
|  |  | (In thousands) |  |  | (In years) |  |
| January 2, 2023 |  |  |  |  |  |  |  |  |  |  |  |  |
| Customer relationships |  | $ | 366,071 |  |  | $ | (187,560 | ) |  | $ | 178,511 |  |  |  | 11.3 |  |
| Technology |  |  | 47,650 |  |  |  | (24,876 | ) |  |  | 22,774 |  |  |  | 9.5 |  |
| Acquired intangibles from acquisition |  |  |  |  |  |  |  |  |  |  |  |  |
| Customer relationships |  |  | 82,500 |  |  |  | (3,173 | ) |  |  | 79,327 |  |  |  | 13.0 |  |
| Trade names |  |  | 8,250 |  |  |  | (825 | ) |  |  | 7,425 |  |  |  | 5.0 |  |
|  |  | $ | 504,471 |  |  | $ | (216,434 | ) |  | $ | 288,037 |  |  |  |  |
| January 3, 2022 |  |  |  |  |  |  |  |  |  |  |  |  |
| Customer relationships |  | $ | 366,071 |  |  | $ | (154,461 | ) |  | $ | 211,610 |  |  |  | 11.3 |  |
| Technology |  |  | 47,650 |  |  |  | (19,342 | ) |  |  | 28,308 |  |  |  | 9.5 |  |
|  |  | $ | 413,721 |  |  | $ | (173,803 | ) |  | $ | 239,918 |  |  |  |  |

[0000950170-23-005994:notes:140]
Definite-lived intangibles are amortized using the straight-line method of amortization over the useful life. Amortization expense was $42,631, $41,389 and $44,373 for the years ended January 2, 2023, January 3, 2022 and December 28, 2020, respectively. For the years ended January 2, 2023, January 3, 2022 and December 28, 2020, $5,534, $5,641 and $5,535, respectively, of amortization expense is included in cost of goods sold.

[0000950170-23-005994:notes:141]
Estimated aggregate amortization for definite-lived intangible assets for the next five years and thereafter is as follows:

[0000950170-23-005994:notes:142]
|  |  | (In thousands) |  |
| 2023 |  | $ | 44,695 |  |
| 2024 |  |  | 37,513 |  |
| 2025 |  |  | 33,393 |  |
| 2026 |  |  | 33,393 |  |
| 2027 |  |  | 33,178 |  |
| Thereafter |  |  | 105,865 |  |
|  |  | $ | 288,037 |  |


## us-gaap:LongTermDebtTextBlock

[0000950170-23-005994:notes:143]
(7)
Long-term Debt and Letters of Credit

[0000950170-23-005994:notes:144]
The following table summarizes the long-term debt of the Company as of January 2, 2023 and January 3, 2022:

[0000950170-23-005994:notes:145]
|  |  | Interest Rate as ofJanuary 2, 2023 |  |  | PrincipalOutstandingas ofJanuary 2, 2023 |  |  | Interest Rate as ofJanuary 3, 2022 |  |  | PrincipalOutstandingas ofJanuary 3, 2022 |  |
|  |  | (In thousands, except interest rates) |  |
| Senior Notes due March 2029 |  |  | 4.00 |  | % | $ | 500,000 |  |  |  | 4.00 |  | % | $ | 500,000 |  |
| Term Loan due September 2024 |  |  | 6.89 |  |  |  | 405,879 |  |  |  | 2.60 |  |  |  | 405,879 |  |
| Asia ABL Revolving Loan due June 2024 |  |  | 5.79 |  |  |  | 30,000 |  |  |  | 1.50 |  |  |  | 30,000 |  |
|  |  |  |  |  |  | 935,879 |  |  |  |  |  |  | 935,879 |  |
| Less: Long-term debt unamortized discount |  |  |  |  |  | (392 | ) |  |  |  |  |  | (607 | ) |
| Long-term debt unamortized debt issuance costs |  |  |  |  |  | (6,080 | ) |  |  |  |  |  | (7,454 | ) |
|  |  |  |  |  |  | 929,407 |  |  |  |  |  |  | 927,818 |  |
| Less: current maturities |  |  |  |  |  | (50,000 | ) |  |  |  |  |  | — |  |
| Long-term debt, less current maturities |  |  |  |  | $ | 879,407 |  |  |  |  |  | $ | 927,818 |  |

[0000950170-23-005994:notes:146]
The fiscal calendar maturities of debt through 2027 and thereafter are as follows:

[0000950170-23-005994:notes:147]
|  |  | (In thousands) |  |
| 2023 |  | $ | 50,000 |  |
| 2024 |  |  | 385,879 |  |
| 2025 |  |  | — |  |
| 2026 |  |  | — |  |
| 2027 |  |  | — |  |
| Thereafter |  |  | 500,000 |  |
|  |  | $ | 935,879 |  |

[0000950170-23-005994:notes:148]
As of January 2, 2023, the Company was in compliance with the financial covenants under the Term Loan Facility, Senior Notes due 2029 and ABL Revolving Loans.

[0000950170-23-005994:notes:149]
Senior Notes due 2029

[0000950170-23-005994:notes:150]
On March 10, 2021, the Company issued $500,000 of Senior Notes due 2029, which are included in long-term debt and bear interest at a rate of 4.0% per annum. Interest is payable semiannually in arrears on March 1 and September 1 of each year beginning September 1, 2021. The Senior Notes due 2029 will mature on March 1, 2029.

[0000950170-23-005994:notes:151]
The Company used a portion of the net proceeds from the issuance of the Senior Notes due 2029 during the quarter ended March 29, 2021 to: (i) fund the early retirement of $375,000 Senior Notes due 2025, (ii) fund the repayment of $40,000 then outstanding under the U.S. Asset-Based Lending Credit Agreement (U.S. ABL) revolving credit facility (but not terminate the commitments thereunder), and (iii) pay related premiums, fees and expenses. The Company used the remaining net proceeds for general corporate purposes.

[0000950170-23-005994:notes:152]
Convertible Senior Notes due 2020

[0000950170-23-005994:notes:153]
The Convertible Senior Notes bore interest at a rate of 1.75% per annum. Interest was payable semiannually in arrears on June 15 and December 15 of each year. The Convertible Senior Notes were unsecured obligations that ranked equally to the Company’s future unsecured senior indebtedness and were senior in right of payment to any of the Company’s future subordinated indebtedness. Offering

[0000950170-23-005994:notes:154]
expenses were amortized to interest expense over the term of the Convertible Senior Notes. The Convertible Senior Notes matured and were repaid in cash in the amount of $249,975 on December 15, 2020.

[0000950170-23-005994:notes:155]
Convertible Note Hedge and Warrant Transaction:    In connection with the issuance of the Convertible Senior Notes due 2020, the Company entered into a convertible note hedge and warrant transaction (Call Spread Transaction), with respect to the Company’s common stock. The convertible note hedge consisted of the Company’s option to purchase up to 25,939 common stock shares at a price of $9.64 per share. The hedge could only be executed upon the conversion of the above mentioned Convertible Senior Notes due 2020 and it expired unexercised on December 15, 2020. Additionally, the Company sold equity-classified warrants to purchase 25,940 shares of its common stock at a price of $14.26 per share, which remained outstanding and expired ratably from March 2021 through January 2022. The Call Spread Transaction had no effect on the terms of the Convertible Senior Notes due 2020.

[0000950170-23-005994:notes:156]
The components of interest expense resulting from the Convertible Senior Notes for the year ended December 28, 2020 were as follows: $4,180 contractual coupon interest, $9,926 amortization of debt discount, and $995 amortization of debt issuance costs.

[0000950170-23-005994:notes:157]
Term Loan Facility

[0000950170-23-005994:notes:158]
On April 18, 2018, the Company closed its $600,000 commitment of incremental loans concurrent with the completion of its acquisition of Anaren. At issuance, these incremental loans increased the Company’s existing balance of its Term Loan Facility due 2024 from $348,250 to $948,250. The Term Loan Facility had an outstanding balance of $405,879 as of January 2, 2023, of which $50,000 is included in short-term debt as the Company made an optional debt principal prepayment of $50,000 subsequent to January 2, 2023. The remaining balance of $355,879 is included in long-term debt. The Term Loan Facility was issued at a weighted average discount of 99.7% and bears interest, at the Company’s option, at a floating rate of LIBOR plus an applicable interest margin of 2.5%, or an alternate base rate (as defined in the Term Loan Credit Agreement) plus an applicable margin of 1.5%. As of January 2, 2023, the interest rate on the outstanding borrowings under the Term Loan Facility was 6.89%. There is no provision, other than an event of default, for the interest margin to increase. The Term Loan Facility will mature on September 28, 2024. The Term Loan Facility is secured by a significant amount of the domestic assets of the Company and a pledge of 65% of voting stock of the Company’s first tier foreign subsidiaries and is structurally senior to the Company’s Senior Notes due 2029. See Senior Notes due 2029 above.

[0000950170-23-005994:notes:159]
Pursuant to the Term Loan Credit Agreement, the Company could reinvest the cash proceeds received from the sale of the Mobility business unit for a period of twelve months commencing September 3, 2020. If the proceeds were not reinvested during that time, the Company was required to use the proceeds to prepay the Term Loan. The Company used a portion of the cash proceeds to repay $400,000 of the Term Loan during the year ended December 28, 2020 and used the remaining cash proceeds for reinvestment pursuant to the Term Loan Credit Agreement. Permitted investments, as defined in the Term Loan Credit Agreement, include extensions of trade credit in the ordinary course of business, investments in cash and cash equivalents, permitted acquisitions, investments in assets useful in the business of the Company and its restricted subsidiaries, investments in joint ventures and unrestricted subsidiaries among others.

[0000950170-23-005994:notes:160]
Based on certain parameters defined in the Term Loan Facility, including a First Lien Leverage Ratio, the Company may be required to make an additional principal payment on an annual basis beginning after fiscal year 2018, if the Company’s First Lien Leverage Ratio is greater than 2.0. For 2022, the Company is not required to make an additional principal payment as its First Lien Leverage Ratio was less than 2.0. Any remaining outstanding balance under the Term Loan Facility is due at the maturity date of September 28, 2024.

[0000950170-23-005994:notes:161]
Borrowings under the Term Loan Facility are subject to certain affirmative and negative covenants, including limitations on indebtedness, corporate transactions, investments, dispositions, and share payments.

[0000950170-23-005994:notes:162]
Asset-Based Lending Agreements

[0000950170-23-005994:notes:163]
In June 2019, the Company amended its U.S. Asset-Based Lending Credit Agreement (U.S. ABL) and its Asia Asset-Based Lending Credit Agreement (Asia ABL) (collectively the ABL Revolving Loans). The U.S. ABL credit facility was amended to extend its maturity to June 2024 and decrease the size of the revolving credit facility to $150,000. The Asia ABL credit facility was amended to extend the maturity to June 2024.

[0000950170-23-005994:notes:164]
The U.S. ABL consists of two tranches comprised of a revolving credit facility for up to $150,000 and a letter of credit facility for up to $50,000, provided that at no time may amounts outstanding under the tranches exceed in aggregate $150,000 or the applicable borrowing base, which is a percentage of the principal amount of Eligible Accounts, as defined in the U.S. ABL agreement. Borrowings under the U.S. ABL bear interest at either a floating rate of LIBOR plus a margin of 125 basis points or an alternate base rate (defined as the greater of the prime rate, the New York Fed bank rate plus 0.5% or LIBOR plus 1.0%) subject to a 1.0% floor, plus an applicable margin of 25 basis points, at the Company’s option. The applicable margin can vary based on the remaining availability of the facility, from 125 to 150 basis points for LIBOR-based loans and from 25 to 50 basis points for JP Morgan Chase Bank’s prime rate-based loans. Other than availability and an event of default, there are no other provisions for the interest margin to increase. The U.S. ABL will mature on June 3, 2024. Loans made under the U.S. ABL are secured first by all of the Company’s domestic cash, receivables and certain inventories as well as by a second position against a significant amount of the domestic assets of the Company and a pledge of

[0000950170-23-005994:notes:165]
65% of the voting stock of the Company’s first tier foreign subsidiaries and are structurally senior to the Company’s Senior Notes due 2029. See Senior Notes due 2029 and Convertible Senior Notes above.

[0000950170-23-005994:notes:166]
The Asia ABL consists of two tranches comprised of a revolving credit facility for up to $150,000 and a letter of credit facility for up to $100,000, provided that at no time may amounts outstanding under both tranches exceed in aggregate $150,000 or the applicable borrowing base, which is a percentage of the principal amount of Eligible Accounts, as defined in the Asia ABL agreement. Borrowings under the Asia ABL bear interest at a floating rate of LIBOR plus 140 basis points. As of January 2, 2023, the interest rate on the outstanding borrowings under the Asia ABL was 5.79%. There is no provision, other than an event of default, for the interest margin to increase. The Asia ABL will mature on June 4, 2024. Loans made under the Asia ABL are secured by a portion of the Company’s Asia Pacific cash and receivables and are structurally senior to the Company’s domestic obligations, including the Senior Notes due 2029. See Senior Notes due 2029 above. As of January 2, 2023, $30,000 under the Asia ABL was outstanding and classified as long-term debt, which is consistent with its maturity date.

[0000950170-23-005994:notes:167]
As of January 2, 2023, letters of credit in the amount of $15,929 were outstanding under the U.S. ABL and $5,023 were outstanding under the Asia ABL with various maturities through October 2023. Available borrowing capacity under the U.S. ABL and the Asia ABL was $134,071 and $114,977 respectively, which considers letters of credit outstanding as of January 2, 2023.

[0000950170-23-005994:notes:168]
The Company is required to pay a commitment fee of 0.25% per annum on any unused portion of the U.S. ABL and 0.28% per annum on any unused portion of the Asia ABL. The Company incurred total commitment fees related to unused borrowing availability of $661, $663 and $541 for the years ended January 2, 2023, January 3, 2022 and December 28, 2020, respectively. Under the occurrence of certain events, the ABL Revolving Loans are subject to various financial and operational covenants, including maintaining minimum fixed charge coverage ratios.

[0000950170-23-005994:notes:169]
Debt Issuance and Debt Discount

[0000950170-23-005994:notes:170]
As of January 2, 2023 and January 3, 2022, remaining unamortized debt discount and debt issuance costs for the Senior Notes due 2029 and Term Loan Facility are as follows:

[0000950170-23-005994:notes:171]
|  |  | As of January 2, 2023 |  |  | As of January 3, 2022 |
|  |  | DebtIssuance Costs |  |  | DebtDiscount |  |  | EffectiveInterest Rate |  |  | DebtIssuance Costs |  |  | DebtDiscount |  |  | EffectiveInterest Rate |  |  |
|  |  | (In thousands, except interest rates) |
| Senior Notes due March 2029 |  | $ | 4,779 |  |  | $ | — |  |  |  | 4.18 |  | % | $ | 5,444 |  |  | $ | — |  |  |  | 4.18 |  | % |
| Term Loan due September 2024 |  |  | 1,301 |  |  |  | 392 |  |  |  | 4.66 |  |  |  | 2,010 |  |  |  | 607 |  |  |  | 4.66 |  |  |
|  |  | $ | 6,080 |  |  | $ | 392 |  |  |  |  |  | $ | 7,454 |  |  | $ | 607 |  |  |  |  |  |

[0000950170-23-005994:notes:172]
The above debt discount and debt issuance costs are recorded as a reduction of the debt and are amortized into interest expense using an effective interest rate over the duration of the debt.

[0000950170-23-005994:notes:173]
Remaining unamortized debt issuance costs for the ABL Revolving Loans of $792 and $1,355 as of January 2, 2023 and January 3, 2022, respectively, are included in other non-current assets and are amortized to interest expense over the duration of the ABL Revolving Loans using the straight line method of amortization.

[0000950170-23-005994:notes:174]
As of January 2, 2023, the remaining weighted average amortization period for all unamortized debt discount and debt issuance costs was 4.6 years.

[0000950170-23-005994:notes:175]
Loss on Extinguishment of Debt

[0000950170-23-005994:notes:176]
During the year ended January 3, 2022, the Company recognized losses of $15,217 associated with the premium paid on extinguishment of debt and the write-off of the remaining unamortized debt issuance costs as a result of the repayment of the remaining outstanding balance of the Senior Notes due 2025.


## us-gaap:IncomeTaxDisclosureTextBlock

[0000950170-23-005994:notes:177]
(8)
Income Taxes

[0000950170-23-005994:notes:178]
The components of income (loss) from continuing operations before income taxes for the years ended January 2, 2023, January 3, 2022 and December 28, 2020 are:

[0000950170-23-005994:notes:179]
|  |  | For the Year Ended |  |
|  |  | January 2,2023 |  |  | January 3,2022 |  |  | December 28,2020 |  |
|  |  | (In thousands) |  |
| United States |  | $ | (52,468 | ) |  | $ | (28,057 | ) |  | $ | (84,582 | ) |
| Foreign |  |  | 235,331 |  |  |  | 98,110 |  |  |  | 38,305 |  |
| Income (loss) from continuing operations before income taxes |  | $ | 182,863 |  |  | $ | 70,053 |  |  | $ | (46,277 | ) |

[0000950170-23-005994:notes:180]
The Company expects its earnings attributable to foreign subsidiaries will not be indefinitely reinvested, except for certain subsidiaries, and the Company has established a deferred tax liability of approximately $5,586 and $1,526 for the foreign and U.S. federal/state impact, respectively. For those other companies with earnings currently being reinvested outside of the U.S., the undistributed earnings amounted to approximately $60,769 as of January 2, 2023. The determination of the unrecognized deferred tax liability related to these undistributed earnings is approximately $2,654.

[0000950170-23-005994:notes:181]
The components of income tax (provision) benefit for the years ended January 2, 2023, January 3, 2022 and December 28, 2020 are:

[0000950170-23-005994:notes:182]
|  |  | For the Year Ended |  |
|  |  | January 2,2023 |  |  | January 3,2022 |  |  | December 28,2020 |  |
|  |  | (In thousands) |  |
| Current (provision) benefit: |  |  |  |  |  |  |  |  |  |
| Federal |  | $ | (2,591 | ) |  | $ | (1,125 | ) |  | $ | (44 | ) |
| State |  |  | (1,812 | ) |  |  | 547 |  |  |  | (4,624 | ) |
| Foreign |  |  | (23,453 | ) |  |  | (9,211 | ) |  |  | 27,902 |  |
| Total current |  |  | (27,856 | ) |  |  | (9,789 | ) |  |  | 23,234 |  |
| Deferred (provision) benefit: |  |  |  |  |  |  |  |  |  |
| Federal |  |  | (29,093 | ) |  |  | 2,889 |  |  |  | 2,446 |  |
| State |  |  | (3,905 | ) |  |  | (1,492 | ) |  |  | 4,498 |  |
| Foreign |  |  | (27,426 | ) |  |  | (7,247 | ) |  |  | (287 | ) |
| Total deferred |  |  | (60,424 | ) |  |  | (5,850 | ) |  |  | 6,657 |  |
| Income tax (provision) benefit |  | $ | (88,280 | ) |  | $ | (15,639 | ) |  | $ | 29,891 |  |

[0000950170-23-005994:notes:183]
The following is a reconciliation of the provision for income taxes at the statutory federal income tax rate compared to the Company’s provision for income taxes for the years ended January 2, 2023, January 3, 2022 and December 28, 2020:

[0000950170-23-005994:notes:184]
|  |  | For the Year Ended |  |
|  |  | January 2,2023 |  |  | January 3,2022 |  |  | December 28,2020 |  |
|  |  | (In thousands) |  |
| Statutory federal income tax (provision) benefit |  | $ | (38,401 | ) |  | $ | (14,711 | ) |  | $ | 9,718 |  |
| State income taxes, net of federal benefit and state tax credits |  |  | 1,750 |  |  |  | 1,815 |  |  |  | (2,674 | ) |
| IRC Section 162(m) limitation |  |  | (791 | ) |  |  | (725 | ) |  |  | (712 | ) |
| Stock options |  |  | (599 | ) |  |  | 89 |  |  |  | (1,298 | ) |
| Global Intangible Low-Taxed Income |  |  | (19,240 | ) |  |  | (9,824 | ) |  |  | (1,300 | ) |
| Foreign tax credits |  |  | 17,343 |  |  |  | 3,028 |  |  |  | — |  |
| Permanently reinvested earnings assertion |  |  | (2,721 | ) |  |  | (1,392 | ) |  |  | (1,442 | ) |
| Foreign tax differential on foreign earnings & other permanent items |  |  | 1,504 |  |  |  | 3,917 |  |  |  | 3,933 |  |
| Change in valuation allowance |  |  | (50,805 | ) |  |  | (1,139 | ) |  |  | (2,668 | ) |
| Uncertain tax positions |  |  | (85 | ) |  |  | (642 | ) |  |  | 36,936 |  |
| Federal research and development credits |  |  | 4,319 |  |  |  | 3,400 |  |  |  | 4,250 |  |
| Goodwill impairment |  |  | — |  |  |  | — |  |  |  | (14,532 | ) |
| Other |  |  | (554 | ) |  |  | 545 |  |  |  | (320 | ) |
| Income tax (provision) benefit |  | $ | (88,280 | ) |  | $ | (15,639 | ) |  | $ | 29,891 |  |

[0000950170-23-005994:notes:185]
Deferred income taxes reflect the net tax effects of temporary differences between the carrying amounts of assets and liabilities for financial reporting purposes and the amounts used for income tax purposes. The significant components of the net deferred income tax (liabilities) assets as of January 2, 2023 and January 3, 2022 are as follows:

[0000950170-23-005994:notes:186]
|  |  | As of |  |
|  |  | January 2,2023 |  |  | January 3,2022 |  |
|  |  | (In thousands) |  |
| Deferred income tax assets: |  |  |  |  |  |  |
| Net operating loss carryforwards |  | $ | 33,092 |  |  | $ | 41,354 |  |
| Reserves and accruals |  |  | 60,360 |  |  |  | 30,944 |  |
| Interest expense limitation |  |  | 115 |  |  |  | 2,826 |  |
| Unrealized (gain) loss on cash flow hedge |  |  | (276 | ) |  |  | 1,128 |  |
| Tax credit carryforwards |  |  | 36,192 |  |  |  | 38,890 |  |
| Stock-based compensation |  |  | 5,076 |  |  |  | 4,724 |  |
| Property, plant and equipment |  |  | 5,983 |  |  |  | 7,665 |  |
| Other deferred income tax assets |  |  | 2,848 |  |  |  | 707 |  |
|  |  |  | 143,390 |  |  |  | 128,238 |  |
| Less: valuation allowance |  |  | (67,173 | ) |  |  | (16,541 | ) |
|  |  |  | 76,217 |  |  |  | 111,697 |  |
| Deferred income tax liabilities: |  |  |  |  |  |  |
| Repatriation of foreign earnings |  |  | (7,112 | ) |  |  | (4,482 | ) |
| Property, plant and equipment basis differences |  |  | (84,609 | ) |  |  | (62,791 | ) |
| Goodwill and intangible amortization |  |  | (31,456 | ) |  |  | (33,318 | ) |
| Other deferred income tax liabilities |  |  | (4,882 | ) |  |  | (4,203 | ) |
| Net deferred income tax (liabilities) assets (included in Other long-term liabilities and Deposits and other non-current assets, respectively) |  | $ | (51,842 | ) |  | $ | 6,903 |  |

[0000950170-23-005994:notes:187]
As of January 2, 2023, the Company had the following net operating loss (NOL) carryforwards: $98,257 in the U.S. for federal, $21,831 in various U.S. states, $37,195 in China, and $15,019 in Hong Kong. The U.S. federal NOLs expire in 2028 through 2032, the various U.S. states’ NOLs expire in 2023 through 2042, the China NOLs expire in 2025 through 2032, and the Hong Kong NOLs carryforward indefinitely. Further, the Company’s tax credits were approximately $46,276, of which $5,928 carryforward indefinitely.

[0000950170-23-005994:notes:188]
In connection with the Company’s acquisition of Viasystems during 2015, there was more than a 50% change in ownership under Section 382 of the Internal Revenue Code of 1986, as amended, and regulations issued there under. As a consequence, the utilization of the remaining Viasystems U.S. NOLs is limited to approximately $9,826 per year and total $98,257.

[0000950170-23-005994:notes:189]
A valuation allowance is provided when it is more likely than not that all or some portion of the deferred income tax assets will not be realized. The Company established a valuation allowance on its U.S. net deferred tax assets in the current year mainly due to cumulative book losses in the U.S. In addition, certain subsidiaries in various tax jurisdictions continue to have NOL carryforwards, which the Company has determined are not more likely than not to be utilized. As a result, a full valuation allowance has been recorded for these subsidiaries as of January 2, 2023. For the remaining net deferred income tax assets, management has determined that it is more likely than not that the results of future operations will generate sufficient income to realize the net deferred tax assets.

[0000950170-23-005994:notes:190]
The following summarizes the activity in the Company’s valuation allowance for the years ended January 2, 2023, January 3, 2022 and December 28, 2020:

[0000950170-23-005994:notes:191]
|  |  | For the Year Ended |  |
|  |  | January 2,2023 |  |  | January 3,2022 |  |  | December 28,2020 |  |
|  |  | (In thousands) |  |
| Balance at beginning of year |  | $ | 16,541 |  |  | $ | 15,322 |  |  | $ | 14,292 |  |
| Additions charged to expense |  |  | 51,748 |  |  |  | 2,330 |  |  |  | 3,904 |  |
| Other reduction charged to expense |  |  | (1,116 | ) |  |  | (1,111 | ) |  |  | (2,874 | ) |
| Balance at end of year |  | $ | 67,173 |  |  | $ | 16,541 |  |  | $ | 15,322 |  |

[0000950170-23-005994:notes:192]
Certain entities within China qualified for the high and new technology enterprise (HNTE) status enabling those entities to enjoy certain benefits, which were effective for the years ended January 2, 2023, January 3, 2022 and December 28, 2020. The HNTE status as well as enhanced research and development (R&D) deductions decreased Chinese taxes. HNTE and R&D benefit and effect on earnings per share are as follows:

[0000950170-23-005994:notes:193]
|  |  | For the Year Ended |  |
|  |  | January 2,2023 |  |  | January 3,2022 |  |  | December 28,2020 |  |
|  |  | (In thousands, except per share data) |  |
| HNTE and R&D benefits |  | $ | 13,480 |  |  | $ | 5,611 |  |  | $ | 4,235 |  |
| Basic shares |  |  | 102,074 |  |  |  | 106,314 |  |  |  | 106,366 |  |
| Diluted shares |  |  | 103,866 |  |  |  | 108,153 |  |  |  | 106,366 |  |
| Increases earnings per share: |  |  |  |  |  |  |  |  |  |
| Basic |  | $ | 0.13 |  |  | $ | 0.05 |  |  | $ | 0.04 |  |
| Diluted |  | $ | 0.13 |  |  | $ | 0.05 |  |  | $ | 0.04 |  |

[0000950170-23-005994:notes:194]
HNTE status expires for certain subsidiaries in 2023, but the Company expects to continue to file for renewal of such HNTE status for the foreseeable future.

[0000950170-23-005994:notes:195]
A reconciliation of the beginning and ending amount of unrecognized tax benefits, exclusive of accrued interest and penalties, is as follows:

[0000950170-23-005994:notes:196]
|  |  | For the Year Ended |  |
|  |  | January 2,2023 |  |  | January 3,2022 |  |  | December 28,2020 |  |
|  |  | (In thousands) |  |
| Balance at beginning of year |  | $ | 9,442 |  |  | $ | 7,404 |  |  | $ | 37,465 |  |
| Additions based on tax positions related to the current year |  |  | 820 |  |  |  | 2,749 |  |  |  | 839 |  |
| Additions for tax positions of prior years |  |  | — |  |  |  | 41 |  |  |  | 202 |  |
| Reductions for tax positions of prior years |  |  | (72 | ) |  |  | (357 | ) |  |  | (27,283 | ) |
| Lapse of statute of limitations |  |  | (412 | ) |  |  | (395 | ) |  |  | (3,819 | ) |
| Balance at end of year |  | $ | 9,778 |  |  | $ | 9,442 |  |  | $ | 7,404 |  |

[0000950170-23-005994:notes:197]
During the year ended January 2, 2023, the Company increased uncertain tax positions by $336 due to (i) U.S. R&D credit generation in 2022, offset by (ii) release of uncertain tax positions due to states’ statute of limitation expiration.

[0000950170-23-005994:notes:198]
As of January 2, 2023, and January 3, 2022, the Company recorded unrecognized tax benefits of $776 and $804, respectively, as well as interest and penalties of $1,028 and $1,026, respectively, to current and long-term liabilities. The Company has also recorded unrecognized tax benefits of $9,002 and $8,638 against certain deferred tax assets as of January 2, 2023 and January 3, 2022, respectively. The amount of unrecognized tax benefits that would, if recognized, reduce the Company’s effective income tax rate in any future periods is $1,804 including interest and penalties. The Company expects its unrecognized tax benefits to decrease by $363 along with related interest of $662 over the next twelve months due to expiring statutes.

[0000950170-23-005994:notes:199]
As of January 2, 2023, the Company is open for (i) U.S. federal income tax examination for the period from 2020 to 2022 and NOL and credit carryforwards are subject to adjustment for 3 years post utilization, (ii) state and local income tax examination for tax years 2019 to 2022 and NOL and credit carryforwards are subject to adjustment for 4 years post utilization; and (iii) foreign income tax examinations generally for tax years from 2012 to 2022.


## us-gaap:DisposalGroupsIncludingDiscontinuedOperationsDisclosureTextBlock

[0000950170-23-005994:notes:200]
(9)
Discontinued Operations

[0000950170-23-005994:notes:201]
On January 19, 2020, the Company entered into a definitive equity interests purchase agreement for the sale of the Company’s Mobility business unit. The sale was completed on April 17, 2020 for a base purchase price of $550,000, subject to customary purchase price adjustments. The base purchase price did not include certain accounts receivable of the divested business, which were estimated to total approximately $95,000. After the price adjustments, the final purchase price was $569,246, which did not include approximately $83,000 accounts receivable of the divested business.

[0000950170-23-005994:notes:202]
On April 18, 2020, the Company entered into a Transition Services Agreement (TSA) with the Purchaser pursuant to which the Purchaser is receiving certain services (the Services) to enable it to operate the Mobility business unit after the closing of the sale of the Mobility business unit. The Services include finance and accounting, human resources, legal and compliance, sales, information technology, and other corporate support services. Under the TSA, the Services were being provided at cost for a period of up to 24 months. In addition, the Company entered into a Manufacturing Supply Agreement with the Purchaser pursuant to which the Purchaser

[0000950170-23-005994:notes:203]
will supply products to a few customers of the Company. There was no material impact of these agreements on the Company’s consolidated financial statements.

[0000950170-23-005994:notes:204]
Further, on June 29, 2020, the Company entered into a Sales Force Agreement with the Purchaser pursuant to which the Company’s sales representatives assisted the Purchaser in selling PCBs manufactured by the Purchaser to certain customers for a commission for a period up to April 17, 2021. There was no material impact on the Company’s consolidated financial statements.

[0000950170-23-005994:notes:205]
As the sale of the Company’s Mobility business unit represented a strategic shift that had a major effect on the Company’s operations and financial results, in accordance with the provisions of FASB authoritative guidance on the presentation of financial statements, Mobility business unit results are classified as discontinued operations in the consolidated statements of operations for 2020.

[0000950170-23-005994:notes:206]
The following table summarizes the results of Mobility operations for fiscal year 2020 prior to sale:

[0000950170-23-005994:notes:207]
|  |  | For the Year Ended |  |
|  |  | December 28, |  |
|  |  | 2020 |  |
|  |  | (In thousands, except per share data) |  |
| Net sales |  | $ | 143,951 |  |
| Cost of goods sold |  |  | 136,800 |  |
| Gross profit |  |  | 7,151 |  |
| Operating expenses: |  |  |  |
| Selling and marketing |  |  | 1,461 |  |
| General and administrative |  |  | 2,317 |  |
| Research and development |  |  | 147 |  |
| Amortization of definite-lived intangibles |  |  | 809 |  |
| Restructuring charges |  |  | — |  |
| Total operating expenses |  |  | 4,734 |  |
| Operating income |  |  | 2,417 |  |
| Other (expense) income: |  |  |  |
| Interest expense |  |  | (223 | ) |
| Gain on sale of the Mobility business unit |  |  | 237,253 |  |
| Other, net |  |  | 1,160 |  |
| Total other income, net |  |  | 238,190 |  |
| Income from discontinued operations before income taxes |  |  | 240,607 |  |
| Income tax provision |  |  | (46,686 | ) |
| Income from discontinued operations, net of income taxes |  | $ | 193,921 |  |
| Earnings per share from discontinued operations: |  |  |  |
| Basic earnings per share |  | $ | 1.82 |  |
| Diluted earnings per share |  | $ | 1.82 |  |

[0000950170-23-005994:notes:208]
Depreciation expense related to the discontinued operations for the year ended December 28, 2020 was $21,375.

[0000950170-23-005994:notes:209]
During the year ended December 28, 2020, the Company’s income tax expense related to the discontinued operations was impacted by a net discrete tax expense of $46,686. The net income tax expense for the year ended December 28, 2020 is related mainly to (i) China withholding tax related to gain on sale, (ii) U.S. income tax related to Global Intangible Low Taxed Income (GILTI) inclusion net of IRC Section 250 deduction and foreign tax credits, offset by (iii) release of U.S. uncertain tax positions as a result of available excess foreign tax credits.

[0000950170-23-005994:notes:210]
Proceeds from the sale of the Company’s Mobility business unit have been presented in the consolidated statements of cash flows within net cash provided by investing activities from discontinued operations. The following is a reconciliation of the final gain recorded for the sale of the Company’s Mobility business unit (in thousands):

[0000950170-23-005994:notes:211]
| Net proceeds from the sale of the Mobility business unit (1) |  | $ | 569,246 |  |
| Mobility business unit assets: |  |  |  |
| Cash and cash equivalents |  |  | 12,513 |  |
| Restricted cash |  |  | 35,412 |  |
| Accounts receivable, net |  |  | 12 |  |
| Contract assets |  |  | 40,072 |  |
| Inventories |  |  | 4,988 |  |
| Prepaid expenses and other current assets |  |  | 4,593 |  |
| Property, plant and equipment, net |  |  | 328,648 |  |
| Goodwill |  |  | 68,267 |  |
| Definite-lived intangibles, net |  |  | 5,520 |  |
| Deposits and other non-current assets |  |  | 6,291 |  |
| Total Mobility business unit assets |  |  | 506,316 |  |
| Mobility business unit liabilities: |  |  |  |
| Accounts payable |  |  | 142,636 |  |
| Accrued salaries, wages and benefits |  |  | 9,392 |  |
| Other current liabilities |  |  | 8,890 |  |
| Other long-term liabilities |  |  | 303 |  |
| Total Mobility business unit liabilities |  |  | 161,221 |  |
| Derecognition of foreign currency translation adjustments and unrealized losses on cash flow hedges recorded in accumulated other comprehensive loss |  |  | 26,957 |  |
| Other transaction costs incurred as part of the sale of the Mobility business unit (2) |  |  | 13,855 |  |
| Gain on sale of the Mobility business unit before income taxes |  | $ | 237,253 |  |

[0000950170-23-005994:notes:212]
(1)
Net proceeds from the sale of the Mobility business unit are net of the finalized customary purchase price adjustments.

[0000950170-23-005994:notes:213]
(2)
Costs directly incurred as a result of the sale of the Company’s Mobility business unit, including bank fees, legal fees, professional fees, and other costs.


## us-gaap:ScheduleOfDisposalGroupsIncludingDiscontinuedOperationsIncomeStatementBalanceSheetAndAdditionalDisclosuresTextBlock

[0000950170-23-005994:notes:214]
The following is a reconciliation of the final gain recorded for the sale of the Company’s Mobility business unit (in thousands):


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0000950170-23-005994:notes:215]
(10)
Accumulated Other Comprehensive Loss

[0000950170-23-005994:notes:216]
The following provides a summary of the components of accumulated other comprehensive loss, net of tax as of January 2, 2023, January 3, 2022 and December 28, 2020:

[0000950170-23-005994:notes:217]
|  |  | ForeignCurrencyTranslation |  |  | Pension Obligation |  |  | (Losses) Gainson Cash FlowHedges |  |  | Total |  |
|  |  | (In thousands) |  |
| Ending balance as of December 28, 2020 |  | $ | (24,827 | ) |  | $ | (2,855 | ) |  | $ | (11,231 | ) |  | $ | (38,913 | ) |
| Other comprehensive income (loss) before reclassifications |  |  | 928 |  |  |  | 2,722 |  |  |  | (515 | ) |  |  | 3,135 |  |
| Amounts reclassified from accumulated other comprehensive income |  |  | — |  |  |  | — |  |  |  | 8,523 |  |  |  | 8,523 |  |
| Net year to date other comprehensive loss |  |  | 928 |  |  |  | 2,722 |  |  |  | 8,008 |  |  |  | 11,658 |  |
| Ending balance as of January 3, 2022 |  |  | (23,899 | ) |  |  | (133 | ) |  |  | (3,223 | ) |  |  | (27,255 | ) |
| Other comprehensive (loss) income before reclassifications |  |  | (2,085 | ) |  |  | 1,412 |  |  |  | (91 | ) |  |  | (764 | ) |
| Amounts reclassified from accumulated other comprehensive income |  |  | — |  |  |  | — |  |  |  | 3,229 |  |  |  | 3,229 |  |
| Net year to date other comprehensive (loss) income |  |  | (2,085 | ) |  |  | 1,412 |  |  |  | 3,138 |  |  |  | 2,465 |  |
| Ending balance as of January 2, 2023 |  | $ | (25,984 | ) |  | $ | 1,279 |  |  | $ | (85 | ) |  | $ | (24,790 | ) |


## us-gaap:ConcentrationRiskDisclosureTextBlock

[0000950170-23-005994:notes:218]
(11)
Significant Customers and Concentration of Credit Risk

[0000950170-23-005994:notes:219]
In the normal course of business, the Company extends credit to its customers. Some customers to whom the Company extends credit are located outside the United States. The Company performs ongoing credit evaluations of customers, does not require collateral, and considers the credit risk profile of the entity from which the receivable is due in further evaluating collection risk. As of January 2, 2023, there was one customer that accounted for 11% of the Company’s accounts receivable. There were no customers that accounted for 10% or more of accounts receivable as of January 3, 2022.

[0000950170-23-005994:notes:220]
The Company’s customers include both OEMs and EMS companies. The Company’s OEM customers often direct a significant portion of their purchases through EMS companies. While the Company’s customers include both OEM and EMS providers, the Company measures customer concentration based on OEM companies, as they are the ultimate end customers.

[0000950170-23-005994:notes:221]
For each of the years ended January 2, 2023 and January 3, 2022, one customer accounted for approximately 10% of the Company’s net sales. For the year ended December 28, 2020, one customer accounted for approximately 11% of the Company’s net sales.


## us-gaap:FairValueDisclosuresTextBlock

[0000950170-23-005994:notes:222]
(12)
Fair Value Measures

[0000950170-23-005994:notes:223]
The Company measures at fair value its financial and non-financial assets by using a fair value hierarchy that prioritizes the inputs to valuation techniques used to measure fair value. Fair value is the price that would be received to sell an asset or paid to transfer a liability in an orderly transaction between market participants at the measurement date, essentially an exit price, based on the highest and best use of the asset or liability.

[0000950170-23-005994:notes:224]
The carrying amount and estimated fair value of the Company’s financial instruments as of January 2, 2023 and January 3, 2022 were as follows:

[0000950170-23-005994:notes:225]
|  |  | As of |  |  | As of |  |
|  |  | January 2, 2023 |  |  | January 3, 2022 |  |
|  |  | CarryingAmount |  |  | Fair Value |  |  | CarryingAmount |  |  | Fair Value |  |
|  |  | (In thousands) |  |
| Derivative assets, current |  | $ | — |  |  | $ | — |  |  | $ | 297 |  |  | $ | 297 |  |
| Derivative liabilities, current |  |  | 1,622 |  |  |  | 1,622 |  |  |  | 4,295 |  |  |  | 4,295 |  |
| Senior Notes due March 2029 |  |  | 495,221 |  |  |  | 430,165 |  |  |  | 494,556 |  |  |  | 498,200 |  |
| Term Loan due September 2024 |  |  | 404,186 |  |  |  | 405,628 |  |  |  | 403,262 |  |  |  | 406,135 |  |
| ABL Revolving Loans |  |  | 30,000 |  |  |  | 30,000 |  |  |  | 30,000 |  |  |  | 30,000 |  |

[0000950170-23-005994:notes:226]
The fair value of the derivative instruments was determined using pricing models developed based on the LIBOR swap rate, foreign currency exchange rates, and other observable market data, including quoted market prices, as appropriate using Level 2 inputs. The values were adjusted to reflect non-performance risk of both the counterparty and the Company, as necessary.

[0000950170-23-005994:notes:227]
The fair value of the long-term debt was estimated based on quoted market prices or discounting the debt over its life using current market rates for similar debt as of January 2, 2023 and January 3, 2022, which are considered Level 2 inputs.

[0000950170-23-005994:notes:228]
The fair value of plan assets in the defined benefit plan of $21,637 and $26,278 as of January 2, 2023 and January 3, 2022, respectively, were not included in the table above and was estimated based on quoted market prices of the securities that are actively traded and price quotes that are readily available, which are considered Level 1 inputs. See Note 15 for further details of the plan assets measured at fair value in the defined benefit plan.

[0000950170-23-005994:notes:229]
As of January 2, 2023 and January 3, 2022, the Company’s other financial instruments included cash and cash equivalents, accounts receivable, contract assets, accounts payable, and contract liabilities. The carrying amount of these instruments approximates fair value. The Company’s cash and cash equivalents as of January 2, 2023 consisted of $241,041 held in the U.S., with the remaining $161,708 held by foreign subsidiaries.

[0000950170-23-005994:notes:230]
The majority of the Company’s non-financial assets and liabilities, which include goodwill, intangible assets, inventories, and property, plant and equipment, are not required to be carried at fair value on a recurring basis. However, if certain triggering events occur (or are tested at least annually in the case of goodwill) such that a non-financial instrument is required to be evaluated for impairment, based upon a comparison of the non-financial instrument’s fair value to its carrying value, an impairment is recorded to reduce the carrying value to the fair value, if the carrying value exceeds the fair value.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0000950170-23-005994:notes:231]
(13)
Commitments and Contingencies

[0000950170-23-005994:notes:232]
Legal Matters

[0000950170-23-005994:notes:233]
The Company is subject to various legal matters, which it considers normal for its business activities. While the Company currently believes that the amount of any reasonably possible loss for known matters would not be material to the Company’s financial condition, the outcome of these actions is inherently difficult to predict. In the event of an adverse outcome, the ultimate potential loss could have a material adverse effect on the Company’s financial condition or results of operations in a particular period. The Company has accrued amounts for its loss contingencies which are probable and estimable as of January 2, 2023 and January 3, 2022. However, these amounts are not material to the consolidated financial statements of the Company.

[0000950170-23-005994:notes:234]
Offset Agreements

[0000950170-23-005994:notes:235]
Following the acquisition of Telephonics on June 27, 2022, the Company has and may continue to enter into industrial cooperation agreements, sometimes referred to as offset agreements, as a condition to obtaining orders for products and services from customers in foreign countries. These agreements are intended to promote investment in the applicable country, and the Company’s obligations under these agreements may be satisfied through activities that do not require the Company to use cash, including transferring technology or providing manufacturing and other consulting support. The obligations under these agreements may also be satisfied through the use of cash for activities such as purchasing supplies from in-country vendors, setting up support centers, research and development investments, acquisitions, and building or leasing facilities for in-country operations, if applicable. The amount of the offset requirement is determined by contract value awarded and negotiated percentages with customers. As of January 2, 2023, the Company had outstanding offset agreements of approximately $20,169, some of which extend through 2028. Offset programs usually extend over

[0000950170-23-005994:notes:236]
several years and in some cases provide for penalties in the event the Company fails to perform in accordance with contract requirements. Historically, the Company has not paid any such penalties, and as of January 2, 2023, no such penalties have been paid.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0000950170-23-005994:notes:237]
(14)
Stock-Based Compensation

[0000950170-23-005994:notes:238]
Incentive Compensation Plan

[0000950170-23-005994:notes:239]
The Company maintains a 2014 Incentive Compensation Plan (the Plan), which, with subsequent amendments, allows for issuance of up to 15,788 shares through its expiration date in February 2024.

[0000950170-23-005994:notes:240]
The Plan provides for the grant of performance-based restricted stock units (PRUs), restricted stock units (RSUs), and stock appreciation rights. The exercise price for awards is determined by the compensation committee of the board of directors. Each award shall vest and expire as determined by the compensation committee of the board of directors, with PRUs and RSUs generally vesting over three years for employees and one year for non-employee directors. PRUs and RSUs do not have voting rights. All grants provide for accelerated vesting if there is a change in control, as defined in the Plan.

[0000950170-23-005994:notes:241]
As of January 2, 2023, 727 PRUs, 3,658 RSUs and 60 stock options were outstanding under the Plan. Included in the 727 PRUs outstanding as of January 2, 2023 are 336 vested but not yet released. Included in the 3,658 RSUs outstanding as of January 2, 2023 are 594 vested but not yet released RSUs associated with non-employee directors. These RSUs vest over one year with release of the underlying shares of common stock deferred until retirement from the board of directors, (or until one year after retirement in the case of certain prior grants).

[0000950170-23-005994:notes:242]
Performance-based Restricted Stock Units

[0000950170-23-005994:notes:243]
The Company maintains a long-term incentive program for executives that provides for the issuance of PRUs, representing hypothetical shares of the Company’s common stock that may be issued. Under the PRU program, a target number of PRUs is awarded at the beginning of each three-year performance period. The number of shares of common stock released at the end of the performance period may range from zero to 2.4 times the target number depending on performance during the period. The performance metrics of the PRU program are based on (a) annual financial targets, which are based on revenue and EBITDA (earnings before interest, tax, depreciation, and amortization expense), each equally weighted, and (b) an overall modifier based on the Company’s total stockholder return (TSR) relative to a group of peer companies selected by the Company’s compensation committee, over the three-year performance period.

[0000950170-23-005994:notes:244]
Under the PRU program, financial goals are set at the beginning of each fiscal year and performance is reviewed at the end of that year. The percentage to be applied to each participant’s target award ranges from zero to 160% based upon the extent to which the annual financial performance goals are achieved. If specific performance threshold levels for the annual financial goals are met, the amount earned for that element will be applied to one-third of the participants’ PRU award to determine the number of units earned.

[0000950170-23-005994:notes:245]
At the end of the three-year performance period, the total units earned, if any, are adjusted by applying a modifier, ranging from zero to 150% based on the Company’s TSR based on stock price changes relative to a group of peer companies selected by the Company’s compensation committee for the same three-year period.

[0000950170-23-005994:notes:246]
The TSR modifier is intended to ensure that there are limited or no payouts under the PRU program if the Company’s stock performance is significantly below the median TSR of a group of peer companies selected by the Company’s compensation committee over the three-year performance period. Where the annual financial goals have been met and where there has been strong relative TSR performance over the three-year performance period, the PRU program may provide substantial rewards to participants with a maximum payout of 2.4 times the initial PRU award. However, even if all of the annual financial metric goals are achieved in each of the three years, there will be no payouts if the Company’s stock performance is below that of the 10th percentile of the group of peer companies selected by the Company’s compensation committee.

[0000950170-23-005994:notes:247]
Recipients of PRU awards generally must remain employed by the Company on a continuous basis through the end of the three-year performance period in order to receive any amount of the PRUs covered by that award. In events such as death, disability or retirement, the recipient may be entitled to pro-rata amounts of PRUs as defined in the Plan. Target shares subject to PRU awards do not have voting rights of common stock until earned and issued following the end of the three-year performance period.

[0000950170-23-005994:notes:248]
The Company records stock-based compensation expense for PRU awards granted based on management’s periodic assessment of the annual financial performance goals to be achieved. As of January 2, 2023, management determined that vesting of the PRU awards was probable. PRU activity for the year ended January 2, 2023 was as follows:

[0000950170-23-005994:notes:249]
|  |  | Shares |  |  | WeightedAverage FairValue |  |
|  |  | (In thousands) |  |  |  |  |
| Outstanding shares as of January 3, 2022 |  |  | 326 |  |  | $ | 15.41 |  |
| Granted |  |  | 327 |  |  |  | 15.02 |  |
| Vested |  |  | (336 | ) |  |  | 14.79 |  |
| Forfeited / cancelled |  |  | (4 | ) |  |  | 15.79 |  |
| Change in units due to annual performance achievement |  |  | 78 |  |  |  | 15.08 |  |
| Outstanding shares as of January 2, 2023 |  |  | 391 |  |  | $ | 15.55 |  |

[0000950170-23-005994:notes:250]
The fair value of PRUs granted is calculated using a Monte Carlo simulation model, as the TSR modifier contains a market condition. For the years ended January 2, 2023, January 3, 2022 and December 28, 2020, the following assumptions were used in determining the fair value:

[0000950170-23-005994:notes:251]
|  |  | For the Year Ended |  |
|  |  | January 2, 2023 (1) |  |  | January 3, 2022 (2) |  |  | December 28, 2020 (3) |  |
| Weighted-average fair value |  | $ | 15.02 |  |  | $ | 14.23 |  |  | $ | 10.57 |  |
| Risk-free interest rate |  |  | 1.44 | % |  |  | 0.18 | % |  |  | 0.18 | % |
| Dividend yield |  |  | — |  |  |  | — |  |  |  | — |  |
| Expected volatility |  |  | 30 | % |  |  | 47 | % |  |  | 49 | % |

[0000950170-23-005994:notes:252]
(1)
Reflects the weighted-averages for the third year of the three-year performance period applicable to PRUs granted in 2020, the second year of the three-year performance period applicable to PRUs granted in 2021 and the first year of the three-year performance period applicable to PRUs granted in 2022.

[0000950170-23-005994:notes:253]
(2)
Reflects the weighted-averages for the third year of the three-year performance period applicable to PRUs granted in 2019, the second year of the three-year performance period applicable to PRUs granted in 2020 and the first year of the three-year performance period applicable to PRUs granted in 2021.

[0000950170-23-005994:notes:254]
(3)
Reflects the weighted-averages for the third year of the three-year performance period applicable to PRUs granted in 2018, the second year of the three-year performance period applicable to PRUs granted in 2019 and the first year of the three-year performance period applicable to PRUs granted in 2020.

[0000950170-23-005994:notes:255]
The risk-free interest rate for the expected term of PRUs is based on the U.S. Treasury yield curve in effect at the time of grant. Expected volatility is calculated using the Company’s historical stock price.

[0000950170-23-005994:notes:256]
Restricted Stock Units

[0000950170-23-005994:notes:257]
RSU activity for the year ended January 2, 2023 was as follows:

[0000950170-23-005994:notes:258]
|  |  | Shares |  |  | WeightedAverageGrant-DateFair Value |  |
|  |  | (In thousands) |  |  |  |  |
| Non-vested RSUs outstanding as of January 3, 2022 |  |  | 2,597 |  |  | $ | 12.70 |  |
| Granted |  |  | 1,931 |  |  |  | 12.72 |  |
| Vested |  |  | (1,287 | ) |  |  | 12.05 |  |
| Forfeited |  |  | (178 | ) |  |  | 12.75 |  |
| Non-vested RSUs outstanding as of January 2, 2023 |  |  | 3,063 |  |  | $ | 12.96 |  |
| Vested and expected to vest through 2025 as of January 2, 2023 |  |  | 3,658 |  |  | $ | 12.72 |  |

[0000950170-23-005994:notes:259]
The fair value of the Company’s RSUs is determined based upon the closing common stock price on the grant date. The weighted average fair value per unit of RSUs granted was $12.72, $14.40 and $11.20 for the years ended January 2, 2023, January 3, 2022 and December 28, 2020, respectively. The total fair value of RSUs vested for the years ended January 2, 2023, January 3, 2022 and December 28, 2020 was $15,510, $17,185 and $13,093, respectively.

[0000950170-23-005994:notes:260]
Stock Options

[0000950170-23-005994:notes:261]
As of January 2, 2023, stock options outstanding was 60. This is not material to the consolidated financial statements of the Company.

[0000950170-23-005994:notes:262]
Stock-based Compensation Expense and Unrecognized Compensation Costs

[0000950170-23-005994:notes:263]
For the years ended January 2, 2023, January 3, 2022 and December 28, 2020, the amounts recognized in the consolidated statements of operations with respect to the stock-based compensation plan are as follows:

[0000950170-23-005994:notes:264]
|  |  | For the Year Ended |  |
|  |  | January 2, |  |  | January 3, |  |  | December 28, |  |
|  |  | 2023 |  |  | 2022 |  |  | 2020 |  |
|  |  | (In thousands) |  |
| Cost of goods sold |  | $ | 5,846 |  |  | $ | 4,714 |  |  | $ | 3,889 |  |
| Selling and marketing |  |  | 2,749 |  |  |  | 2,540 |  |  |  | 1,919 |  |
| General and administrative |  |  | 9,808 |  |  |  | 9,718 |  |  |  | 10,083 |  |
| Research and development |  |  | 1,122 |  |  |  | 739 |  |  |  | 182 |  |
| Stock-based compensation expense recognized |  | $ | 19,525 |  |  | $ | 17,711 |  |  | $ | 16,073 |  |

[0000950170-23-005994:notes:265]
The following is a summary of total unrecognized compensation costs as of January 2, 2023:

[0000950170-23-005994:notes:266]
|  |  | Unrecognized Stock-Based Compensation Cost |  |  | Remaining Weighted AverageRecognition Period |  |
|  |  | (In thousands) |  |  | (In years) |  |
| RSU awards |  | $ | 29,657 |  |  |  | 1.4 |  |
| PRU awards |  |  | 2,435 |  |  |  | 1.7 |  |
| Stock options |  |  | — |  |  |  | — |  |
|  |  | $ | 32,092 |  |  |  |  |


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0000950170-23-005994:notes:267]
(15)
Employee Benefit Plans, Deferred Compensation Plan and Retirement Benefit Plan

[0000950170-23-005994:notes:268]
As of January 2, 2023, the Company has several defined contribution plans. In North America, the Company has savings plans (the Savings Plans) in which eligible full-time employees can participate and contribute a percentage of compensation subject to the maximum allowed by the tax agencies. The Savings Plans provides for a partial match by the Company. In China, the Company contributes to either separate trust-administered funds or various government-sponsored pension plans on a mandatory basis. For all defined contribution plans, the Company has no further payment obligation once the required contributions have been made. The Company recorded contributions to defined contribution plans of $36,385, $29,464 and $23,146 during the years ended January 2, 2023, January 3, 2022 and December 28, 2020, respectively.

[0000950170-23-005994:notes:269]
The Company also maintains a deferred compensation plan (the Compensation Plan). The Compensation Plan is an unfunded, nonqualified deferred compensation plan and is limited to selected employees, including the Company’s named executive officers and directors. The Compensation Plan allows participants to defer up to 100% of their annual bonus and between 5% and 100% of their annual director fees. Amounts deferred under the Compensation Plan will be credited to accounts maintained by the Company for each participant and will be credited or debited with the participant’s proportionate share of any gains or losses attributable to the performance of investment options selected by the participant.

[0000950170-23-005994:notes:270]
Following the acquisition of Anaren on April 18, 2018, the Company has a noncontributory defined benefit pension plan covering eligible employees. Effective August 15, 2000, the plan was closed for new participants. Benefits under this plan generally are based on the employee’s years of service and compensation. Effective December 31, 2019, the plan is frozen as to further participation and to further benefit accruals.

[0000950170-23-005994:notes:271]
As of January 2, 2023 and January 3, 2022, the funded status of the accumulated benefit obligation was 90% and 83%, respectively. The Company does not expect to fund a minimum required contribution during fiscal year 2023.

[0000950170-23-005994:notes:272]
The following tables set forth the changes in benefit obligation and the plan assets in the defined benefit plan described above for the years ended January 2, 2023, January 3, 2022 and December 28, 2020:

[0000950170-23-005994:notes:273]
|  |  | For the Year Ended |  |
| Change in Benefit Obligations |  | January 2, 2023 |  |  | January 3, 2022 |  |  | December 28,2020 |  |
|  |  | (In thousands) |  |
| Benefit obligation at beginning of year |  | $ | (31,554 | ) |  | $ | (33,470 | ) |  | $ | (30,600 | ) |
| Interest cost |  |  | (803 | ) |  |  | (722 | ) |  |  | (907 | ) |
| Actuarial gain (loss) |  |  | 7,033 |  |  |  | 1,304 |  |  |  | (3,146 | ) |
| Benefits paid |  |  | 1,216 |  |  |  | 1,334 |  |  |  | 1,183 |  |
| Benefit obligation at end of year |  | $ | (24,108 | ) |  | $ | (31,554 | ) |  | $ | (33,470 | ) |
| Accumulated benefit obligation at end of year |  | $ | 24,108 |  |  | $ | 31,554 |  |  | $ | 33,470 |  |

[0000950170-23-005994:notes:274]
|  |  | For the Year Ended |  |
| Change in Plan Assets |  | January 2, 2023 |  |  | January 3, 2022 |  |  | December 28,2020 |  |
|  |  | (In thousands) |  |
| Fair value of plan assets at beginning of year |  | $ | 26,278 |  |  | $ | 23,484 |  |  | $ | 21,287 |  |
| Actual return on plan assets |  |  | (3,760 | ) |  |  | 3,526 |  |  |  | 2,704 |  |
| Employer contributions |  |  | 335 |  |  |  | 602 |  |  |  | 676 |  |
| Benefits paid |  |  | (1,216 | ) |  |  | (1,334 | ) |  |  | (1,183 | ) |
| Fair value of plan assets at end of year |  | $ | 21,637 |  |  | $ | 26,278 |  |  | $ | 23,484 |  |
| Unfunded status |  | $ | (2,471 | ) |  | $ | (5,276 | ) |  | $ | (9,986 | ) |
| Net amount recognized |  | $ | (2,471 | ) |  | $ | (5,276 | ) |  | $ | (9,986 | ) |

[0000950170-23-005994:notes:275]
Amounts before income tax effect recognized in the consolidated balance sheets consists of the following:

[0000950170-23-005994:notes:276]
|  |  | As of |  |  |
|  |  | January 2, 2023 |  |  | January 3, 2022 |  |  |
|  |  | (In thousands) |  |  |
| Other long-term liabilities |  | $ | (2,471 | ) |  | $ | (5,276 | ) |  |
| Net amount recognized |  | $ | (2,471 | ) |  | $ | (5,276 | ) |  |

[0000950170-23-005994:notes:277]
Amounts before income tax effect included in accumulated other comprehensive loss as of January 2, 2023 and
January 3, 2022 are as follows:

[0000950170-23-005994:notes:278]
|  |  | January 2, 2023 |  |  | January 3, 2022 |  |  |
|  |  | (In thousands) |  |  |
| Net actuarial gain (loss) |  | $ | 1,616 |  |  | $ | (238 | ) |  |
| Accumulated other comprehensive gain (loss) |  | $ | 1,616 |  |  | $ | (238 | ) |  |

[0000950170-23-005994:notes:279]
The net actuarial gain during the year ended January 2, 2023 was primarily driven by a decrease in liabilities due to a higher assumed discount rate.

[0000950170-23-005994:notes:280]
The components included in the net periodic benefit cost and the increase in minimum liability included in other comprehensive loss for the years ended January 2, 2023, January 3, 2022 and December 28, 2020 are as follows:

[0000950170-23-005994:notes:281]
|  |  | January 2, 2023 |  |  | January 3, 2022 |  |  | December 28, 2020 |  |  |
|  |  | (In thousands) |  |  |
| Interest cost |  | $ | 803 |  |  | $ | 722 |  |  | $ | 907 |  |  |
| Expected return on plan assets |  |  | (1,419 | ) |  |  | (1,279 | ) |  |  | (1,272 | ) |  |
| Amortization of net actuarial loss |  |  | — |  |  |  | 23 |  |  |  | — |  |  |
| Net periodic benefit cost |  | $ | (616 | ) |  | $ | (534 | ) |  | $ | (365 | ) |  |

[0000950170-23-005994:notes:282]
The weighted-average assumptions used to determine benefit obligations for this plan as of January 2, 2023, January 3, 2022 and December 28, 2020 are as follows:

[0000950170-23-005994:notes:283]
|  |  | January 2, 2023 |  |  | January 3, 2022 |  |  | December 28, 2020 |  |  |
| Discount rate |  |  | 4.94 |  | % |  | 2.60 |  | % |  | 2.20 |  | % |
| Expected return on plan assets |  |  | 5.50 |  |  |  | 5.50 |  |  |  | 5.50 |  |  |

[0000950170-23-005994:notes:284]
The Company determines the discount rate assumption based on the internal rate of return for a portfolio of high quality bonds, with a minimum rating of Moody's AA Corporate and with maturities that are consistent with the projected future cash flow obligations.

[0000950170-23-005994:notes:285]
The weighted-average assumptions used to determine net periodic benefit cost for the years ended January 2, 2023, January 3, 2022 and December 28, 2020 are as follows:

[0000950170-23-005994:notes:286]
|  |  | For the Year Ended |  |  |
|  |  | January 2, 2023 |  |  | January 3, 2022 |  |  | December 28, 2020 |  |  |
| Discount rate |  |  | 2.60 |  | % |  | 2.20 |  | % |  | 3.02 |  | % |
| Expected return on plan assets |  |  | 5.50 |  |  |  | 5.50 |  |  |  | 6.00 |  |  |

[0000950170-23-005994:notes:287]
The Company determines the expected long-term rate of return on plan assets based upon recommendations from its pension plan's investment advisors and using an allocation approach that considers diversification and rebalancing for a portfolio of assets invested over a long-term time horizon. The approach relies on the historical returns of the plan's portfolio and relationships between equities and fixed income investments, consistent with the widely accepted capital market principle that a diversified portfolio with a larger allocation to equity investments can generate a greater return over the long run. Additionally, the Company monitors the mix of investments in its portfolio to ensure alignment with its expected long-term pension obligations. The Company reviews the expected long-term rate of return annually and revises it as appropriate.

[0000950170-23-005994:notes:288]
Investments shall be made pursuant to the following objectives: 1) preserve the purchasing power of the plan’s assets adjusted for inflation; 2) provide long-term growth; and 3) avoid significant volatility. Asset allocation shall be determined based on a long-term

[0000950170-23-005994:notes:289]
target allocation having 29% of assets invested in large-cap stocks, 11% in mid-cap stocks, 11% in small-cap stocks, 11% in international stocks, 34% in the broad bond market, and 3% in the real estate market, with little or none invested in cash. Both the investment allocation and the plan performance are reviewed periodically.

[0000950170-23-005994:notes:290]
The target allocation for 2023 and the plan asset allocation at the end of 2022 and 2021, in percentages, by asset category are as follows:

[0000950170-23-005994:notes:291]
|  |  | Target Allocation 2023 |  |  |  | January 2, 2023 |  |  |  | January 3, 2022 |  |  |
| Equity securities (1) |  |  | 65 |  | % |  |  | 66 |  | % |  |  | 67 |  | % |
| Debt securities (2) |  |  | 34 |  |  |  |  | 33 |  |  |  |  | 32 |  |  |
| Cash and cash equivalents (3) |  |  | 1 |  |  |  |  | 1 |  |  |  |  | 1 |  |  |
| Total |  |  | 100 |  | % |  |  | 100 |  | % |  |  | 100 |  | % |

[0000950170-23-005994:notes:292]
The following table summarizes plan assets measured at fair value as of January 2, 2023 and January 3, 2022:

[0000950170-23-005994:notes:293]
|  |  | As of |  |
|  |  | January 2, 2023 |  |
|  |  | Total |  |  | Quoted Prices inActive Markets for Identical Assets(Level 1) |  |  | SignificantObservable Inputs(Level 2) |  |  | SignificantUnobservable Inputs(Level 3) |  |
|  |  | (In thousands) |  |
| Equity securities (1) |  | $ | 14,221 |  |  | $ | 14,221 |  |  | $ | — |  |  | $ | — |  |
| Debt securities (2) |  |  | 7,208 |  |  |  | 7,208 |  |  |  | — |  |  |  | — |  |
| Cash and cash equivalents (3) |  |  | 208 |  |  |  | 208 |  |  |  | — |  |  |  | — |  |
| Total |  | $ | 21,637 |  |  | $ | 21,637 |  |  | $ | — |  |  | $ | — |  |
|  |  | As of |  |
|  |  | January 3, 2022 |  |
|  |  | Total |  |  | Quoted Prices inActive Markets for Identical Assets(Level 1) |  |  | SignificantObservable Inputs(Level 2) |  |  | SignificantUnobservable Inputs(Level 3) |  |
|  |  | (In thousands) |  |
| Equity securities (1) |  | $ | 17,661 |  |  | $ | 17,661 |  |  | $ | — |  |  | $ | — |  |
| Debt securities (2) |  |  | 8,290 |  |  |  | 8,290 |  |  |  | — |  |  |  | — |  |
| Cash and cash equivalents (3) |  |  | 327 |  |  |  | 327 |  |  |  | — |  |  |  | — |  |
| Total |  | $ | 26,278 |  |  | $ | 26,278 |  |  | $ | — |  |  | $ | — |  |

[0000950170-23-005994:notes:294]
(1)
Equity securities include U.S. and foreign exchange traded common and preferred stocks and mutual funds. Common and preferred shares issued by U.S. and non-U.S. corporations are traded actively on exchanges and price quotes for these shares are readily available. Holdings of corporate stock are categorized as Level 1 investments.

[0000950170-23-005994:notes:295]
(2)
Debt securities include the debt of the U.S. Treasury and U.S. and foreign corporate issuers. U.S. Treasury notes and bonds are actively traded and price quotes for these securities are readily available. Holdings of U.S. Treasury notes and bonds are categorized as Level 1 investments.

[0000950170-23-005994:notes:296]
(3)
Cash and cash equivalents include short-term U.S. government investment notes, short-term money market mutual funds, accrued income and cash held on account. Cash held on account and short-term U.S. government investment notes (including accrued income thereon) for which there is an active market and daily pricing for the security are categorized as Level 1 investments.

[0000950170-23-005994:notes:297]
The Company seeks to maximize medium to long-term returns of the overall pension plan assets with reasonable levels of investment risk. One element of controlling the overall investment risk is through diversification of asset allocation, among domestic and international equity and debt instruments. The plan's equity investments include foreign and domestic exchange traded equities across a range of industries and countries, but primarily in the domestic markets. The plan's debt securities are primarily invested in government and corporate issuers primarily in the domestic market.

[0000950170-23-005994:notes:298]
The following benefit payments, which reflect expected future service, as appropriate, are expected to be paid:

[0000950170-23-005994:notes:299]
|  |  | (In thousands) |  |
| 2023 |  | $ | 1,462 |  |
| 2024 |  |  | 1,554 |  |
| 2025 |  |  | 1,613 |  |
| 2026 |  |  | 1,662 |  |
| 2027 |  |  | 1,689 |  |
| Years 2028 through 2032 |  |  | 8,796 |  |


## us-gaap:PreferredStockTextBlock

[0000950170-23-005994:notes:300]
(16)
Preferred Stock

[0000950170-23-005994:notes:301]
The board of directors has the authority, without action by stockholders, to designate and issue preferred stock in one or more series. The board of directors may also designate the rights, preferences and privileges of each series of preferred stock, any or all of which may be superior to the rights of the common stock. As of January 2, 2023, no shares of preferred stock were outstanding.


## us-gaap:SegmentReportingDisclosureTextBlock

[0000950170-23-005994:notes:302]
(17)
Segment Information

[0000950170-23-005994:notes:303]
The reportable segments shown below are the Company’s segments for which separate financial information is available and upon which operating results are evaluated by the chief operating decision maker to assess performance and to allocate resources. As of the fourth quarter of 2022, the Company reassessed its reportable segments, which resulted in the inclusion of Telephonics into the PCB reportable segment. On April 29, 2020, the Company announced the restructuring of its E-M Solutions business unit. In prior periods, the Company’s E-M Solutions business unit consisted of three Chinese manufacturing facilities with two being in Shanghai (SH BPA and SH E-MS) and one in Shenzhen (SZ). The Company closed the SH E-MS and SZ facilities at the end of 2020 and integrated the SH BPA facility into its PCB operations. As of March 29, 2021, E-M Solutions no longer met the criteria for segment reporting. As a result of the restructuring of the E-M Solutions business unit, certain prior year amounts have been reclassified to conform to this new presentation. The PCB reportable segment consists of eighteen domestic system, sub-system, and PCB plants; six PCB fabrication plants in China; and one in Canada. The RF&S Components reportable segment consists of one domestic RF component plant and one RF component plant in China.

[0000950170-23-005994:notes:304]
The Company, including the chief operating decision maker, evaluates segment performance based on reportable segment income, which is operating income before amortization of intangibles. Interest expense and interest income are not presented by segment since they are not included in the measure of segment profitability reviewed by the chief operating decision maker. All inter-segment transactions have been eliminated.

[0000950170-23-005994:notes:305]
|  |  | For the Year Ended |  |
|  |  | January 2, 2023 |  |  | January 3, 2022 |  |  | December 28, 2020 |  |
|  |  | (In thousands) |  |
| Net Sales: |  |  |  |  |  |  |  |  |  |
| PCB |  | $ | 2,437,942 |  |  | $ | 2,186,901 |  |  | $ | 1,980,918 |  |
| RF&S Components |  |  | 57,104 |  |  |  | 58,583 |  |  |  | 44,656 |  |
| Other (1) |  |  | — |  |  |  | 3,256 |  |  |  | 79,748 |  |
| Total net sales |  | $ | 2,495,046 |  |  | $ | 2,248,740 |  |  | $ | 2,105,322 |  |
| Operating Segment Income: |  |  |  |  |  |  |  |  |  |
| PCB |  | $ | 317,316 |  |  | $ | 262,442 |  |  | $ | 266,319 |  |
| RF&S Components |  |  | 23,534 |  |  |  | 22,035 |  |  |  | (56,671 | ) |
| Corporate and Other (1) |  |  | (87,811 | ) |  |  | (117,097 | ) |  |  | (137,183 | ) |
| Total operating segment income |  |  | 253,039 |  |  |  | 167,380 |  |  |  | 72,465 |  |
| Amortization of definite-lived intangibles (2) |  |  | (42,631 | ) |  |  | (41,389 | ) |  |  | (44,373 | ) |
| Total operating income |  |  | 210,408 |  |  |  | 125,991 |  |  |  | 28,092 |  |
| Total other expense, net |  |  | (27,545 | ) |  |  | (55,938 | ) |  |  | (74,369 | ) |
| Income (loss) before income taxes |  | $ | 182,863 |  |  | $ | 70,053 |  |  | $ | (46,277 | ) |

[0000950170-23-005994:notes:306]
|  |  | For the Year Ended |  |
|  |  | January 2, 2023 |  |  | January 3, 2022 |  |  | December 28, 2020 |  |
|  |  | (In thousands) |  |
| Depreciation Expense: |  |  |  |  |  |  |  |  |  |
| PCB |  | $ | 82,760 |  |  | $ | 76,380 |  |  | $ | 79,737 |  |
| RF&S Components |  |  | 1,798 |  |  |  | 1,671 |  |  |  | 1,742 |  |
| Corporate and Other (1) |  |  | 6,718 |  |  |  | 7,891 |  |  |  | 18,093 |  |
| Total depreciation expense |  | $ | 91,276 |  |  | $ | 85,942 |  |  | $ | 99,572 |  |
| Capital Expenditures: |  |  |  |  |  |  |  |  |  |
| PCB |  | $ | 90,784 |  |  | $ | 74,028 |  |  | $ | 64,895 |  |
| RF&S Components |  |  | 2,279 |  |  |  | 1,604 |  |  |  | 1,514 |  |
| Corporate and Other (1) |  |  | 4,345 |  |  |  | 6,735 |  |  |  | 5,916 |  |
| Total capital expenditures |  | $ | 97,408 |  |  | $ | 82,367 |  |  | $ | 72,325 |  |

[0000950170-23-005994:notes:307]
|  |  | As of |  |
|  |  | January 2, 2023 |  |  | January 3, 2022 |  |
|  |  | (In thousands) |  |
| Segment Assets: |  |  |  |  |  |  |
| PCB |  | $ | 1,890,723 |  |  | $ | 1,655,401 |  |
| RF&S Components |  |  | 202,619 |  |  |  | 216,737 |  |
| Corporate and Other (1) |  |  | 1,230,262 |  |  |  | 1,153,409 |  |
| Total assets |  | $ | 3,323,604 |  |  | $ | 3,025,547 |  |

[0000950170-23-005994:notes:308]
(1)
Other represents results from the now closed SH E-MS and SZ facilities. For the year ended January 2, 2023, operating segment income includes the gain on sale of property occupied by the Company’s former SH E-MS entity of $51,804.

[0000950170-23-005994:notes:309]
(2)
Amortization of definite-lived intangibles primarily relates to the PCB and RF&S Components reportable segments. For the years ended January 2, 2023, January 3, 2022 and December 28, 2020, $5,534, $5,641 and $5,535, respectively, of amortization expense is included in cost of goods sold.

[0000950170-23-005994:notes:310]
The Corporate category primarily includes operating expenses that are not included in the segment operating performance measures. Corporate consists primarily of corporate governance functions such as finance, accounting, information technology and human resources personnel, as well as global sales and marketing personnel, research and development costs, and acquisition and integration costs associated with acquisitions and divestitures.

[0000950170-23-005994:notes:311]
The Company markets and sells its products in approximately 60 countries. Other than in the United States and China, the Company does not conduct business in any country in which its net sales in that country exceed 10% of the Company’s total net sales. Net sales and long-lived assets are as follows:

[0000950170-23-005994:notes:312]
|  |  | 2022 |  |  | 2021 |  |  | 2020 |  |
|  |  | Net Sales |  |  | Long-Lived Assets |  |  | Net Sales |  |  | Long-Lived Assets |  |  | Net Sales |  |  | Long-Lived Assets |  |
|  |  | (In thousands) |  |
| United States |  | $ | 1,224,334 |  |  | $ | 1,363,754 |  |  | $ | 1,049,590 |  |  | $ | 1,131,663 |  |  | $ | 1,086,440 |  |  | $ | 1,154,218 |  |
| China |  |  | 274,309 |  |  |  | 374,474 |  |  |  | 327,435 |  |  |  | 382,580 |  |  |  | 334,462 |  |  |  | 387,627 |  |
| Other |  |  | 996,403 |  |  |  | 34,450 |  |  |  | 871,715 |  |  |  | 28,754 |  |  |  | 684,420 |  |  |  | 27,221 |  |
| Total |  | $ | 2,495,046 |  |  | $ | 1,772,678 |  |  | $ | 2,248,740 |  |  | $ | 1,542,997 |  |  | $ | 2,105,322 |  |  | $ | 1,569,066 |  |

[0000950170-23-005994:notes:313]
Net sales are attributed to countries by country invoiced.


## us-gaap:EarningsPerShareTextBlock

[0000950170-23-005994:notes:314]
(18)
Earnings Per Share

[0000950170-23-005994:notes:315]
The following is a reconciliation of the numerator and denominator used to calculate basic earnings per share and diluted earnings per share from continuing operations for the years ended January 2, 2023, January 3, 2022 and December 28, 2020:

[0000950170-23-005994:notes:316]
|  |  | For the Year Ended |  |
|  |  | January 2, 2023 |  |  | January 3, 2022 |  |  | December 28, 2020 |  |
|  |  | (In thousands, except per share amounts) |  |
| Net income (loss) from continuing operations |  | $ | 94,583 |  |  | $ | 54,414 |  |  | $ | (16,386 | ) |
| Basic weighted average shares |  |  | 102,074 |  |  |  | 106,314 |  |  |  | 106,366 |  |
| Dilutive effect of performance-based restricted stock units, restricted stock units and stock options |  |  | 1,791 |  |  |  | 1,639 |  |  |  | — |  |
| Dilutive effect of outstanding warrants |  |  | 1 |  |  |  | 200 |  |  |  | — |  |
| Diluted shares |  |  | 103,866 |  |  |  | 108,153 |  |  |  | 106,366 |  |
| Earnings (loss) per share: |  |  |  |  |  |  |  |  |  |
| Basic |  | $ | 0.93 |  |  | $ | 0.51 |  |  | $ | (0.15 | ) |
| Diluted |  | $ | 0.91 |  |  | $ | 0.50 |  |  | $ | (0.15 | ) |

[0000950170-23-005994:notes:317]
For the years ended January 2, 2023, January 3, 2022 and December 28, 2020, PRUs, RSUs and stock options to purchase 535, 895 and 433 shares of common stock, respectively, were not included in the computation of diluted earnings per share. The PRUs were not included in the computation of diluted earnings per share because the performance conditions had not been met, and for RSUs and stock options, the options’ exercise prices or the total expected proceeds under the treasury stock method was greater than the average market price of common stock during the applicable year and, as a result, the impact would be anti-dilutive.

[0000950170-23-005994:notes:318]
There were warrants sold to purchase 707 and 25,940 shares of the Company’s common stock for the year ended January 3, 2022 and December 28, 2020, respectively.

[0000950170-23-005994:notes:319]
During the year ended December 28, 2020, the Company calculated the dilutive effect of Convertible Senior Notes using the treasury stock method because the Company repaid and settled the Convertible Senior Notes in cash. For the year ended December 28, 2020, the effect of shares of common stock related to the Company’s Convertible Senior Notes were not included in the computation of dilutive earnings per share as the impact would be anti-dilutive due to the net loss from continuing operations.


## us-gaap:TreasuryStockTextBlock

[0000950170-23-005994:notes:320]
(19)
Share Repurchase Program

[0000950170-23-005994:notes:321]
On February 3, 2021, the Company announced that its Board of Directors authorized and approved a share repurchase program. Under the program, the Company was authorized to repurchase up to $100,000 in value of the Company’s outstanding shares of common stock from time to time through February 3, 2023. The program permitted the Company to repurchase shares through open market purchases, privately-negotiated transactions, or otherwise in accordance with applicable federal securities laws, including Rule 10b-18 of the Securities Exchange Act of 1934, as amended (the Exchange Act) which sets certain restrictions on the method, timing, price, and volume of open market stock repurchases. In addition, the Company adopted a trading plan in accordance with Rule 10b5-1 of the Exchange Act to facilitate certain purchases effected under the share repurchase program. The timing, manner, price and amount of any repurchases were determined at the Company’s discretion. The repurchase program did not obligate the Company to acquire any specific number of shares.

[0000950170-23-005994:notes:322]
During the year ended January 2, 2023, the Company repurchased a total of 2,747 shares of common stock for a total cost of $35,424 (including commissions). As of January 2, 2023, there are no amounts authorized for repurchase.


## us-gaap:SubsequentEventsTextBlock

[0000950170-23-005994:notes:323]
(20)
Subsequent Events

[0000950170-23-005994:notes:324]
On February 8, 2023, the Company announced that it intends to close PCB manufacturing operations in Anaheim and Santa Clara, California, and Hong Kong and to consolidate the business from these impacted sites into the Company’s remaining facilities. The plant closures are expected to improve both facility and talent utilization across the Company’s footprint resulting in improved profitability. The Company expects to record between $22,000 and $28,000 in separation, asset impairment and disposal costs related to this restructuring, primarily between now and the end of 2023. Approximately 80% of these costs are expected to be in the form of cash expenditures and the rest in the form of non-cash charges.
