# TTMI note change history — 0001564590-20-037715 → 0001564590-20-051296


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2020-11-05):
[0001564590-20-051296:note_history:1]
The Company is subject to various legal matters, which it considers normal for its business activities. While the Company currently believes that the amount of any reasonably possible loss for known matters would not be material to the Company’s financial condition, the outcome of these actions is inherently difficult to predict. In the event of an adverse outcome, the ultimate potential loss could have a material adverse effect on the Company’s financial condition or results of operations in a particular period. The Company has accrued amounts for its loss contingencies which are probable and estimable as of September 28, 2020 and December 30, 2019. However, these amounts are not material to the consolidated condensed financial statements of the Company.
  (was, 2020-08-06, similarity 0.9914):
[0001564590-20-037715:note_history:1]
The Company is subject to various legal matters, which it considers normal for its business activities. While the Company currently believes that the amount of any reasonably possible loss for known matters would not be material to the Company’s financial condition, the outcome of these actions is inherently difficult to predict. In the event of an adverse outcome, the ultimate potential loss could have a material adverse effect on the Company’s financial condition or results of operations in a particular period. The Company has accrued amounts for its loss contingencies which are probable and estimable as of June 29, 2020 and December 30, 2019. However, these amounts are not material to the consolidated condensed financial statements of the Company.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureAndSignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2020-11-05):
[0001564590-20-051296:note_history:2]
On January 19, 2020, the Company entered into a definitive equity interests purchase agreement with AKMMeadville Electronics (Xiamen) Co., Ltd (the Purchaser) for the sale of the Company’s following subsidiaries, which was completed on April 17, 2020: Shanghai Kaiser Electronics Co., Ltd. (SKE), Shanghai Meadville Electronics Co., Ltd. (SME), Shanghai Meadville Science & Technology Co., Ltd. (SP) and Guangzhou Meadville Electronics Co., Ltd. (GME) (collectively, the Mobility business unit). Prior to the closing of the sale of the Company’s Mobility business unit, all assets and liabilities attributable to the Mobility business unit have been aggregated under the captions “Current assets held for sale”, “Non-current assets held for sale”, “Current liabilities held for sale” and “Non-current liabilities held for sale”. For all periods presented in the consolidated condensed statements of operations, all sales, costs, expenses, income taxes and gain on sale attributable to the Mobility business unit have been aggregated under the caption “Income (loss) from discontinued operations, net of income taxes”. Prior year results have been recast to conform with the current presentation. Refer to Note 2, Discontinued Operations, for additional information.
  (was, 2020-08-06, similarity 0.9972):
[0001564590-20-037715:note_history:2]
On January 19, 2020, the Company entered into a definitive equity interests purchase agreement with AKMMeadville Electronics (Xiamen) Co., Ltd (the Purchaser) for the sale of the Company’s following subsidiaries, which was completed on April 17, 2020: Shanghai Kaiser Electronics Co., Ltd. (SKE), Shanghai Meadville Electronics Co., Ltd. (SME), Shanghai Meadville Science & Technology Co., Ltd. (SP) and Guangzhou Meadville Electronics Co., Ltd. (GME) (collectively, the Mobility business unit). Prior to the closing of the sale of the Company’s Mobility business unit, all assets and liabilities attributable to the Mobility business unit have been aggregated under the captions “Current assets held for sale”, “Non-current assets held for sale”, “Current liabilities held for sale” and “Non-current liabilities held for sale”. For all periods presented in the consolidated condensed statements of operations, all sales, costs, expenses, income taxes and gain on sale attributable to the Mobility business unit have been aggregated under the caption “Income from discontinued operations, net of income taxes”. Prior year results have been recast to conform with the current presentation. Refer to Note 2, Discontinued Operations, for additional information.

- added (2020-11-05):
[0001564590-20-051296:note_history:3]
Certain prior year amounts in the consolidated condensed financial statements have been reclassified due to the sale of the Company’s Mobility business unit. Refer to Note 2, Discontinued Operations, for further information regarding this sale and the resulting prior year reclassifications.

- added (2020-11-05):
[0001564590-20-051296:note_history:4]
During the quarter ended September 28, 2020, the Company’s RF and Specialty Components (RF&S Components) operating segment met the quantitative threshold for separate presentation of a reportable segment. In prior periods, the Company had two reportable segments: PCB and E-M Solutions. The RF&S Components reportable segment was previously aggregated with the PCB reportable segment. As a result, certain prior year amounts and prior quarters within the current year have been reclassified to conform with this new presentation.

- changed (2020-11-05):
[0001564590-20-051296:note_history:5]
Further, in 2020, the Company began presenting research and development expenses as a separate line item on the consolidated condensed statements of operations to better align with similar presentation made by peers and to provide additional disclosure that is meaningful for investors. The prior year consolidated condensed statements of operations were adjusted to conform with this new presentation. Research and development expense were previously presented within general and administrative expense on the consolidated condensed statements of operations.
  (was, 2020-08-06, similarity 0.7923):
[0001564590-20-037715:note_history:5]
Certain prior year amounts in the consolidated condensed financial statements have been reclassified due to the sale of the Company’s Mobility business unit. Refer to Note 2, Discontinued Operations, for further information regarding this sale and the resulting prior year reclassifications. Further, in 2020, the Company began presenting research and development expenses as a separate line item on the consolidated condensed statements of operations to better align with similar presentation made by peers and to provide additional disclosure that is meaningful for investors. The prior year consolidated condensed statements of operations were adjusted to conform with this new presentation. Research and development expense were previously presented within general and administrative expense on the consolidated condensed statements of operations.

- added (2020-11-05):
[0001564590-20-051296:note_history:6]
Immaterial Correction of Error

- added (2020-11-05):
[0001564590-20-051296:note_history:7]
During the quarter ended September 28, 2020, the Company paid for certain transaction costs related to the sale of the Mobility business unit totaling $11,043. This should have been recorded as an expense, which would have reduced the gain on sale of Mobility business unit, during the quarter ended June 29, 2020. The Company overstated both the income from discontinued operations, net of income taxes and net income by $11,043, both basic earnings per share from discontinued operations and basic earnings per share of $0.10 and $0.11 in the quarter and two quarters ended June 29, 2020, respectively, and both diluted earnings per share from discontinued operations and diluted earnings per share of $0.10 in the quarter and two quarters ended June 29, 2020. Further, total current liabilities were understated by $11,043 and retained earnings were overstated by $11,043 as of June 29, 2020. Management concluded that this error was not material to the consolidated condensed financial statements for the quarter and two quarters ended June 29, 2020. Prior period amounts have been revised to correct the error.

- added (2020-11-05):
[0001564590-20-051296:note_history:8]
In March 2020, the FASB issued ASU 2020-04, Reference Rate Reform (Topic 848): Facilitation of the Effects of Reference Rate Reform on Financial Reporting, which provides temporary relief to the GAAP guidance on contract modifications and hedge accounting to ease the financial reporting burdens of the expected market transition from LIBOR and other interbank offered rates to alternative rates. This guidance became effective beginning on March 12, 2020 and will remain in effect through December 31, 2022. The guidance on contract modifications can be applied prospectively from any date beginning March 12, 2020 and may also be applied to modifications of existing contracts made earlier in the interim period that included March 12, 2020. The guidance on hedging can be applied to eligible hedging relationships existing at the beginning of the interim period that included March 12, 2020 and to new eligible hedging relationships entered into after the beginning of that interim period. The Company adopted this ASU and it did not have a material impact on its financial statements.

- removed (2020-11-05):
[0001564590-20-037715:note_history:9]
In March 2020, the FASB issued ASU 2020-04, Reference Rate Reform (Topic 848): Facilitation of the Effects of Reference Rate Reform on Financial Reporting, which provides temporary relief to the GAAP guidance on contract modifications and hedge accounting to ease the financial reporting burdens of the expected market transition from LIBOR and other interbank offered rates to alternative rates. This guidance is effective beginning on March 12, 2020 through December 31, 2022. The guidance on contract modifications can be applied prospectively from any date beginning March 12, 2020 and may also be applied to modifications of existing contracts made earlier in the interim period that includes March 12, 2020. The guidance on hedging can be applied to eligible hedging relationships existing at the beginning of the interim period that includes March 12, 2020 and to new eligible hedging relationships entered into after the beginning of that interim period. The Company is currently evaluating the new guidance to determine the impact it may have on its consolidated condensed financial statements and related disclosures.


## ttmi:ScheduleOfUnamortizedDiscountAndDebtIssuanceCostsTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2020-11-05):
[0001564590-20-051296:note_history:10]
As of September 28, 2020 and December 30, 2019, remaining unamortized debt discount and debt issuance costs for the Term Loan Facility, Senior Notes and Convertible Senior Notes are as follows:
  (was, 2020-08-06, similarity 0.9694):
[0001564590-20-037715:note_history:10]
As of June 29, 2020 and December 30, 2019, remaining unamortized debt discount and debt issuance costs for the Term Loan Facility, Senior Notes and Convertible Senior Notes are as follows:

- changed (2020-11-05):
[0001564590-20-051296:note_history:11]
|  |  | As of September 28, 2020 |  |  | As of December 30, 2019 |
|  |  | Debt Issuance Costs |  |  | Debt Discount |  |  | Effective Interest Rate |  |  | Debt Issuance Costs |  |  | Debt Discount |  |  | Effective Interest Rate |  |  |
|  |  | (In thousands, except interest rates) |
| Term Loan due September 2024 |  | $ | 2,862 |  |  | $ | 866 |  |  |  | 4.66 |  | % | $ | 6,663 |  |  | $ | 2,016 |  |  |  | 4.66 |  | % |
| Senior Notes due October 2025 |  |  | 4,721 |  |  | — |  |  |  | 5.92 |  |  |  | 5,316 |  |  | — |  |  |  | 5.92 |  |  |
| Convertible Senior Notes |  |  | 219 |  |  |  | 2,188 |  |  |  | 6.48 |  |  |  | 995 |  |  |  | 9,927 |  |  |  | 6.48 |  |  |
|  |  | $ | 7,802 |  |  | $ | 3,054 |  |  |  |  |  |  | $ | 12,974 |  |  | $ | 11,943 |  |  |  |  |  |  |
  (was, 2020-08-06, similarity 0.9893):
[0001564590-20-037715:note_history:11]
|  |  | As of June 29, 2020 |  |  | As of December 30, 2019 |
|  |  | Debt Issuance Costs |  |  | Debt Discount |  |  | Effective Interest Rate |  |  | Debt Issuance Costs |  |  | Debt Discount |  |  | Effective Interest Rate |  |  |
|  |  | (In thousands, except interest rates) |
| Term Loan due September 2024 |  | $ | 6,013 |  |  | $ | 1,819 |  |  |  | 4.66 |  | % | $ | 6,663 |  |  | $ | 2,016 |  |  |  | 4.66 |  | % |
| Senior Notes due October 2025 |  |  | 4,923 |  |  | — |  |  |  | 5.92 |  |  |  | 5,316 |  |  | — |  |  |  | 5.92 |  |  |
| Convertible Senior Notes |  |  | 482 |  |  |  | 4,808 |  |  |  | 6.48 |  |  |  | 995 |  |  |  | 9,927 |  |  |  | 6.48 |  |  |
|  |  | $ | 11,418 |  |  | $ | 6,627 |  |  |  |  |  |  | $ | 12,974 |  |  | $ | 11,943 |  |  |  |  |  |  |


## us-gaap:LongTermDebtTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2020-11-05):
[0001564590-20-051296:note_history:12]
The following table summarizes the long-term debt of the Company as of September 28, 2020 and December 30, 2019:
  (was, 2020-08-06, similarity 0.9447):
[0001564590-20-037715:note_history:12]
The following table summarizes the long-term debt of the Company as of June 29, 2020 and December 30, 2019:

- changed (2020-11-05):
[0001564590-20-051296:note_history:13]
|  |  | Interest Rate as of September 28, 2020 |  |  | Principal Outstanding as of September 28, 2020 |  |  | Interest Rate as of December 30, 2019 |  |  | Principal Outstanding as of December 30, 2019 |  |
|  |  | (In thousands) |  |
| Term Loan due September 2024 |  |  | 2.65 |  | % | $ | 405,879 |  |  |  | 4.28 |  | % | $ | 805,879 |  |
| Senior Notes due October 2025 |  |  | 5.63 |  |  |  | 375,000 |  |  |  | 5.63 |  |  |  | 375,000 |  |
| Convertible Senior Notes due December 2020 |  |  | 1.75 |  |  |  | 249,975 |  |  |  | 1.75 |  |  |  | 249,975 |  |
| U.S. ABL Revolving Loan due June 2024 |  |  | 1.40 |  |  |  | 40,000 |  |  |  | 3.03 |  |  |  | 40,000 |  |
| Asia ABL Revolving Loan due June 2024 |  |  | 1.55 |  |  |  | 30,000 |  |  |  | 3.18 |  |  |  | 30,000 |  |
|  |  |  |  |  |  |  | 1,100,854 |  |  |  |  |  |  |  | 1,500,854 |  |
| Less: Long-term debt unamortized discount |  |  |  |  |  |  | (3,054 | ) |  |  |  |  |  |  | (11,943 | ) |
| Long-term debt unamortized debt issuance costs |  |  |  |  |  |  | (7,802 | ) |  |  |  |  |  |  | (12,974 | ) |
|  |  |  |  |  |  |  | 1,089,998 |  |  |  |  |  |  |  | 1,475,937 |  |
| Less: current maturities |  |  |  |  |  |  | (249,975 | ) |  |  |  |  |  |  | (249,975 | ) |
| Long-term debt, less current maturities |  |  |  |  |  | $ | 840,023 |  |  |  |  |  |  | $ | 1,225,962 |  |
  (was, 2020-08-06, similarity 0.9711):
[0001564590-20-037715:note_history:13]
|  |  | Interest Rate as of June 29, 2020 |  |  | Principal Outstanding as of June 29, 2020 |  |  | Interest Rate as of December 30, 2019 |  |  | Principal Outstanding as of December 30, 2019 |  |
|  |  | (In thousands) |  |
| Term Loan due September 2024 |  |  | 2.67 |  | % | $ | 805,879 |  |  |  | 4.28 |  | % | $ | 805,879 |  |
| Senior Notes due October 2025 |  |  | 5.63 |  |  |  | 375,000 |  |  |  | 5.63 |  |  |  | 375,000 |  |
| Convertible Senior Notes due December 2020 |  |  | 1.75 |  |  |  | 249,975 |  |  |  | 1.75 |  |  |  | 249,975 |  |
| U.S. ABL Revolving Loan due June 2024 |  |  | 1.42 |  |  |  | 40,000 |  |  |  | 3.03 |  |  |  | 40,000 |  |
| Asia ABL Revolving Loan due June 2024 |  |  | 1.57 |  |  |  | 30,000 |  |  |  | 3.18 |  |  |  | 30,000 |  |
|  |  |  |  |  |  |  | 1,500,854 |  |  |  |  |  |  |  | 1,500,854 |  |
| Less: Long-term debt unamortized discount |  |  |  |  |  |  | (6,627 | ) |  |  |  |  |  |  | (11,943 | ) |
| Long-term debt unamortized debt issuance costs |  |  |  |  |  |  | (11,418 | ) |  |  |  |  |  |  | (12,974 | ) |
|  |  |  |  |  |  |  | 1,482,809 |  |  |  |  |  |  |  | 1,475,937 |  |
| Less: current maturities |  |  |  |  |  |  | (649,975 | ) |  |  |  |  |  |  | (249,975 | ) |
| Long-term debt, less current maturities |  |  |  |  |  | $ | 832,834 |  |  |  |  |  |  | $ | 1,225,962 |  |

- added (2020-11-05):
[0001564590-20-051296:note_history:14]
As of September 28, 2020, the Company’s restricted cash balance of $249,975 consisted of a specific deposit account to be used for principal payment on the Convertible Senior Notes due December 2020.

- added (2020-11-05):
[0001564590-20-051296:note_history:15]
The Company has twelve months to reinvest the cash proceeds received from the sale of the Mobility business unit. If the proceeds are not reinvested, the Company is required to use the proceeds to prepay the Term Loan. The Company used a portion of the cash proceeds to repay $400,000 of the Term Loan during the quarter ended September 28, 2020 and plans to use the remaining cash proceeds for reinvestment. Permitted investments, as defined in the Term Loan Credit Agreement, include extensions of trade credit in the ordinary course of business, investments in cash and cash equivalents, permitted acquisitions, investments in assets useful in the business of the Company and its restricted subsidiaries, investments in joint ventures and unrestricted subsidiaries among others.

- changed (2020-11-05):
[0001564590-20-051296:note_history:16]
As of September 28, 2020 and December 30, 2019, remaining unamortized debt discount and debt issuance costs for the Term Loan Facility, Senior Notes and Convertible Senior Notes are as follows:
  (was, 2020-08-06, similarity 0.9694):
[0001564590-20-037715:note_history:16]
As of June 29, 2020 and December 30, 2019, remaining unamortized debt discount and debt issuance costs for the Term Loan Facility, Senior Notes and Convertible Senior Notes are as follows:

- changed (2020-11-05):
[0001564590-20-051296:note_history:17]
|  |  | As of September 28, 2020 |  |  | As of December 30, 2019 |
|  |  | Debt Issuance Costs |  |  | Debt Discount |  |  | Effective Interest Rate |  |  | Debt Issuance Costs |  |  | Debt Discount |  |  | Effective Interest Rate |  |  |
|  |  | (In thousands, except interest rates) |
| Term Loan due September 2024 |  | $ | 2,862 |  |  | $ | 866 |  |  |  | 4.66 |  | % | $ | 6,663 |  |  | $ | 2,016 |  |  |  | 4.66 |  | % |
| Senior Notes due October 2025 |  |  | 4,721 |  |  | — |  |  |  | 5.92 |  |  |  | 5,316 |  |  | — |  |  |  | 5.92 |  |  |
| Convertible Senior Notes |  |  | 219 |  |  |  | 2,188 |  |  |  | 6.48 |  |  |  | 995 |  |  |  | 9,927 |  |  |  | 6.48 |  |  |
|  |  | $ | 7,802 |  |  | $ | 3,054 |  |  |  |  |  |  | $ | 12,974 |  |  | $ | 11,943 |  |  |  |  |  |  |
  (was, 2020-08-06, similarity 0.9893):
[0001564590-20-037715:note_history:17]
|  |  | As of June 29, 2020 |  |  | As of December 30, 2019 |
|  |  | Debt Issuance Costs |  |  | Debt Discount |  |  | Effective Interest Rate |  |  | Debt Issuance Costs |  |  | Debt Discount |  |  | Effective Interest Rate |  |  |
|  |  | (In thousands, except interest rates) |
| Term Loan due September 2024 |  | $ | 6,013 |  |  | $ | 1,819 |  |  |  | 4.66 |  | % | $ | 6,663 |  |  | $ | 2,016 |  |  |  | 4.66 |  | % |
| Senior Notes due October 2025 |  |  | 4,923 |  |  | — |  |  |  | 5.92 |  |  |  | 5,316 |  |  | — |  |  |  | 5.92 |  |  |
| Convertible Senior Notes |  |  | 482 |  |  |  | 4,808 |  |  |  | 6.48 |  |  |  | 995 |  |  |  | 9,927 |  |  |  | 6.48 |  |  |
|  |  | $ | 11,418 |  |  | $ | 6,627 |  |  |  |  |  |  | $ | 12,974 |  |  | $ | 11,943 |  |  |  |  |  |  |

- changed (2020-11-05):
[0001564590-20-051296:note_history:18]
Remaining unamortized debt issuance costs for the ABL Revolving Loans of $2,084 and $2,511 as of September 28, 2020 and December 30, 2019, respectively, are included in other non-current assets and are amortized to interest expense over the duration of the ABL Revolving Loans using the straight-line method of amortization.
  (was, 2020-08-06, similarity 0.9785):
[0001564590-20-037715:note_history:18]
Remaining unamortized debt issuance costs for the ABL Revolving Loans of $2,226 and $2,511 as of June 29, 2020 and December 30, 2019, respectively, are included in other non-current assets and are amortized to interest expense over the duration of the ABL Revolving Loans using the straight-line method of amortization.

- changed (2020-11-05):
[0001564590-20-051296:note_history:19]
As of September 28, 2020, the remaining weighted average amortization period for all unamortized debt discount and debt issuance costs was 3.6 years.
  (was, 2020-08-06, similarity 0.9603):
[0001564590-20-037715:note_history:19]
As of June 29, 2020, the remaining weighted average amortization period for all unamortized debt discount and debt issuance costs was 3.5 years.

- removed (2020-11-05):
[0001564590-20-037715:note_history:20]
The Company has twelve months to reinvest the cash proceeds received from the sale of the Mobility business unit. If the proceeds are not reinvested, the Company is required to use the proceeds to prepay the Term Loan. The Company plans to use the cash proceeds for debt repayment and reinvestment. As of June 29, 2020, the Term Loan had an outstanding balance of $805,879, of which $400,000 is included in short-term debt. Subsequent to June 29, 2020, the Company made a debt principal prepayment for the Term Loan of $400,000. Permitted investments, as defined in the Term Loan Credit Agreement, include extensions of trade credit in the ordinary course of business, investments in cash and cash equivalents, permitted acquisitions, investments in assets useful in the business of the Company and its restricted subsidiaries, investments in joint ventures and unrestricted subsidiaries among others.


## us-gaap:ScheduleOfDebtInstrumentsTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2020-11-05):
[0001564590-20-051296:note_history:21]
The following table summarizes the long-term debt of the Company as of September 28, 2020 and December 30, 2019:
  (was, 2020-08-06, similarity 0.9447):
[0001564590-20-037715:note_history:21]
The following table summarizes the long-term debt of the Company as of June 29, 2020 and December 30, 2019:

- changed (2020-11-05):
[0001564590-20-051296:note_history:22]
|  |  | Interest Rate as of September 28, 2020 |  |  | Principal Outstanding as of September 28, 2020 |  |  | Interest Rate as of December 30, 2019 |  |  | Principal Outstanding as of December 30, 2019 |  |
|  |  | (In thousands) |  |
| Term Loan due September 2024 |  |  | 2.65 |  | % | $ | 405,879 |  |  |  | 4.28 |  | % | $ | 805,879 |  |
| Senior Notes due October 2025 |  |  | 5.63 |  |  |  | 375,000 |  |  |  | 5.63 |  |  |  | 375,000 |  |
| Convertible Senior Notes due December 2020 |  |  | 1.75 |  |  |  | 249,975 |  |  |  | 1.75 |  |  |  | 249,975 |  |
| U.S. ABL Revolving Loan due June 2024 |  |  | 1.40 |  |  |  | 40,000 |  |  |  | 3.03 |  |  |  | 40,000 |  |
| Asia ABL Revolving Loan due June 2024 |  |  | 1.55 |  |  |  | 30,000 |  |  |  | 3.18 |  |  |  | 30,000 |  |
|  |  |  |  |  |  |  | 1,100,854 |  |  |  |  |  |  |  | 1,500,854 |  |
| Less: Long-term debt unamortized discount |  |  |  |  |  |  | (3,054 | ) |  |  |  |  |  |  | (11,943 | ) |
| Long-term debt unamortized debt issuance costs |  |  |  |  |  |  | (7,802 | ) |  |  |  |  |  |  | (12,974 | ) |
|  |  |  |  |  |  |  | 1,089,998 |  |  |  |  |  |  |  | 1,475,937 |  |
| Less: current maturities |  |  |  |  |  |  | (249,975 | ) |  |  |  |  |  |  | (249,975 | ) |
| Long-term debt, less current maturities |  |  |  |  |  | $ | 840,023 |  |  |  |  |  |  | $ | 1,225,962 |  |
  (was, 2020-08-06, similarity 0.9711):
[0001564590-20-037715:note_history:22]
|  |  | Interest Rate as of June 29, 2020 |  |  | Principal Outstanding as of June 29, 2020 |  |  | Interest Rate as of December 30, 2019 |  |  | Principal Outstanding as of December 30, 2019 |  |
|  |  | (In thousands) |  |
| Term Loan due September 2024 |  |  | 2.67 |  | % | $ | 805,879 |  |  |  | 4.28 |  | % | $ | 805,879 |  |
| Senior Notes due October 2025 |  |  | 5.63 |  |  |  | 375,000 |  |  |  | 5.63 |  |  |  | 375,000 |  |
| Convertible Senior Notes due December 2020 |  |  | 1.75 |  |  |  | 249,975 |  |  |  | 1.75 |  |  |  | 249,975 |  |
| U.S. ABL Revolving Loan due June 2024 |  |  | 1.42 |  |  |  | 40,000 |  |  |  | 3.03 |  |  |  | 40,000 |  |
| Asia ABL Revolving Loan due June 2024 |  |  | 1.57 |  |  |  | 30,000 |  |  |  | 3.18 |  |  |  | 30,000 |  |
|  |  |  |  |  |  |  | 1,500,854 |  |  |  |  |  |  |  | 1,500,854 |  |
| Less: Long-term debt unamortized discount |  |  |  |  |  |  | (6,627 | ) |  |  |  |  |  |  | (11,943 | ) |
| Long-term debt unamortized debt issuance costs |  |  |  |  |  |  | (11,418 | ) |  |  |  |  |  |  | (12,974 | ) |
|  |  |  |  |  |  |  | 1,482,809 |  |  |  |  |  |  |  | 1,475,937 |  |
| Less: current maturities |  |  |  |  |  |  | (649,975 | ) |  |  |  |  |  |  | (249,975 | ) |
| Long-term debt, less current maturities |  |  |  |  |  | $ | 832,834 |  |  |  |  |  |  | $ | 1,225,962 |  |


## us-gaap:RelatedPartyTransactionsDisclosureTextBlock (related_parties) — matched_by: tag_name, score: 1.0

- added (2020-11-05):
[0001564590-20-051296:note_history:23]
In the normal course of business, the Company’s foreign subsidiaries purchase laminate and prepreg from related parties in which a significant shareholder of the Company holds an equity interest. The Company’s foreign subsidiaries purchased laminate and prepreg from these related parties in the amount of $5,760 and $7,151 for the quarters ended September 28, 2020 and September 30, 2019, respectively, and $17,527 and $22,847 for the three quarters ended September 28, 2020 and September 30, 2019, respectively.

- changed (2020-11-05):
[0001564590-20-051296:note_history:24]
As of September 28, 2020 and December 30, 2019, the Company’s consolidated condensed balance sheets included $6,786 and $9,220, respectively, in accounts payable due to related parties for purchases of laminate and prepreg and such balances are included as a component of accounts payable on the consolidated condensed balance sheets.
  (was, 2020-08-06, similarity 0.9791):
[0001564590-20-037715:note_history:24]
As of June 29, 2020 and December 30, 2019, the Company’s consolidated condensed balance sheets included $7,601 and $9,220, respectively, in accounts payable due to related parties for purchases of laminate and prepreg and such balances are included as a component of accounts payable on the consolidated condensed balance sheets.

- removed (2020-11-05):
[0001564590-20-037715:note_history:25]
In the normal course of business, the Company’s foreign subsidiaries purchase laminate and prepreg from related parties in which a former member of the Board of Directors of the Company holds an equity interest. The Company’s foreign subsidiaries purchased laminate and prepreg from these related parties in the amount of $5,986 and $8,193 for the quarters ended June 29, 2020 and July 1, 2019, respectively, and $11,767 and $15,696 for the two quarters ended June 29, 2020 and July 1, 2019, respectively.


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- added (2020-11-05):
[0001564590-20-051296:note_history:26]
|  | Quarter Ended September 28, 2020 |  |  | Quarter Ended September 30, 2019 |  |  |
|  | PCB |  |  | RF&S Components |  |  | E-M Solutions |  | Total |  |  | PCB |  |  | RF&S Components |  |  | E-M Solutions |  | Total |  |  |
| End Markets | (In thousands) |  |  |
| Aerospace and Defense | $ | 182,709 |  |  | $ | 180 |  |  | $ | 16 |  | $ | 182,905 |  |  | $ | 170,651 |  |  | $ | 729 |  |  | $ | 1 |  | $ | 171,381 |  |  |
| Automotive |  | 64,375 |  |  |  | — |  |  |  | 8,891 |  |  | 73,266 |  |  |  | 72,597 |  |  |  | — |  |  |  | 39,559 |  |  | 112,156 |  |  |
| Cellular Phone |  | 39 |  |  |  | — |  |  |  | — |  |  | 39 |  |  |  | 3,512 |  |  |  | — |  |  |  | — |  |  | 3,512 |  |  |
| Computing/Storage/ Peripherals |  | 62,606 |  |  |  | 186 |  |  |  | 30 |  |  | 62,822 |  |  |  | 57,367 |  |  |  | 592 |  |  |  | 72 |  |  | 58,031 |  |  |
| Medical/Industrial/ Instrumentation |  | 92,059 |  |  |  | 742 |  |  |  | 2,769 |  |  | 95,570 |  |  |  | 84,178 |  |  |  | 705 |  |  |  | 5,775 |  |  | 90,658 |  |  |
| Networking/Communications |  | 55,905 |  |  |  | 7,203 |  |  |  | 27,185 |  |  | 90,293 |  |  |  | 58,782 |  |  |  | 7,971 |  |  |  | 22,746 |  |  | 89,499 |  |  |
| Other |  | 5,971 |  |  |  | 3,431 |  |  |  | (721 | ) |  | 8,681 |  |  |  | 5,729 |  |  |  | 3,647 |  |  |  | (440 | ) |  | 8,936 |  |  |
| Total | $ | 463,664 |  |  | $ | 11,742 |  |  | $ | 38,170 |  | $ | 513,576 |  |  | $ | 452,816 |  |  | $ | 13,644 |  |  | $ | 67,713 |  | $ | 534,173 |  |  |

- added (2020-11-05):
[0001564590-20-051296:note_history:27]
|  | Three Quarters Ended September 28, 2020 |  |  | Three Quarters Ended September 30, 2019 |  |  |
|  | PCB |  |  | RF&S Components |  |  | E-M Solutions |  | Total |  |  | PCB |  |  | RF&S Components |  |  | E-M Solutions |  | Total |  |  |
| End Markets | (In thousands) |  |  |
| Aerospace and Defense | $ | 555,771 |  |  | $ | 189 |  |  | $ | 36 |  | $ | 555,996 |  |  | $ | 510,210 |  |  | $ | 777 |  |  | $ | 367 |  | $ | 511,354 |  |  |
| Automotive |  | 183,896 |  |  |  | — |  |  |  | 27,816 |  |  | 211,712 |  |  |  | 227,239 |  |  |  | — |  |  |  | 83,317 |  |  | 310,556 |  |  |
| Cellular Phone |  | 1,203 |  |  |  | — |  |  |  | — |  |  | 1,203 |  |  |  | 5,416 |  |  |  | — |  |  |  | — |  |  | 5,416 |  |  |
| Computing/Storage/ Peripherals |  | 192,275 |  |  |  | 663 |  |  |  | 170 |  |  | 193,108 |  |  |  | 170,914 |  |  |  | 1,373 |  |  |  | 261 |  |  | 172,548 |  |  |
| Medical/Industrial/ Instrumentation |  | 292,794 |  |  |  | 2,336 |  |  |  | 9,714 |  |  | 304,844 |  |  |  | 246,889 |  |  |  | 2,629 |  |  |  | 23,583 |  |  | 273,101 |  |  |
| Networking/ Communications |  | 178,428 |  |  |  | 19,173 |  |  |  | 82,429 |  |  | 280,030 |  |  |  | 188,069 |  |  |  | 37,192 |  |  |  | 72,011 |  |  | 297,272 |  |  |
| Other |  | 25,262 |  |  |  | 10,913 |  |  |  | (1,548 | ) |  | 34,627 |  |  |  | 18,025 |  |  |  | 9,754 |  |  |  | (531 | ) |  | 27,248 |  |  |
| Total | $ | 1,429,629 |  |  | $ | 33,274 |  |  | $ | 118,617 |  | $ | 1,581,520 |  |  | $ | 1,366,762 |  |  | $ | 51,725 |  |  | $ | 179,008 |  | $ | 1,597,495 |  |  |

- removed (2020-11-05):
[0001564590-20-037715:note_history:28]
|  |  | Quarter Ended June 29, 2020 |  |  | Quarter Ended July 1, 2019 |  |  |
|  |  | PCB |  |  | E-M Solutions |  |  | Total |  |  | PCB |  |  | E-M Solutions |  |  | Total |  |  |
| End Markets |  | (In thousands) |  |  |
| Aerospace and Defense |  | $ | 188,620 |  |  | $ | 20 |  |  | $ | 188,640 |  |  | $ | 174,810 |  |  | $ | 362 |  |  | $ | 175,172 |  |  |
| Automotive |  |  | 58,100 |  |  |  | 11,462 |  |  |  | 69,562 |  |  |  | 73,049 |  |  |  | 23,993 |  |  |  | 97,042 |  |  |
| Cellular Phone |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |
| Computing/Storage/Peripherals |  |  | 71,864 |  |  |  | 36 |  |  |  | 71,900 |  |  |  | 56,482 |  |  |  | — |  |  |  | 56,482 |  |  |
| Medical/Industrial/Instrumentation |  |  | 114,105 |  |  |  | 3,187 |  |  |  | 117,292 |  |  |  | 82,453 |  |  |  | 9,641 |  |  |  | 92,094 |  |  |
| Networking/Communications |  |  | 73,595 |  |  |  | 36,267 |  |  |  | 109,862 |  |  |  | 74,485 |  |  |  | 25,926 |  |  |  | 100,411 |  |  |
| Other |  |  | 13,783 |  |  |  | (741 | ) |  |  | 13,042 |  |  |  | 5,681 |  |  |  | (5 | ) |  |  | 5,676 |  |  |
| Total |  | $ | 520,067 |  |  | $ | 50,231 |  |  | $ | 570,298 |  |  | $ | 466,960 |  |  | $ | 59,917 |  |  | $ | 526,877 |  |  |

- removed (2020-11-05):
[0001564590-20-037715:note_history:29]
|  |  | Two Quarters Ended June 29, 2020 |  |  | Two Quarters Ended July 1, 2019 |  |  |
|  |  | PCB |  |  | E-M Solutions |  |  | Total |  |  | PCB |  |  | E-M Solutions |  |  | Total |  |  |
| End Markets |  | (In thousands) |  |  |
| Aerospace and Defense |  | $ | 373,071 |  |  | $ | 20 |  |  | $ | 373,091 |  |  | $ | 339,607 |  |  | $ | 366 |  |  | $ | 339,973 |  |  |
| Automotive |  |  | 119,521 |  |  |  | 18,925 |  |  |  | 138,446 |  |  |  | 154,642 |  |  |  | 43,758 |  |  |  | 198,400 |  |  |
| Cellular Phone |  |  | 1,164 |  |  |  | — |  |  |  | 1,164 |  |  |  | — |  |  |  | — |  |  |  | — |  |  |
| Computing/Storage/Peripherals |  |  | 130,146 |  |  |  | 140 |  |  |  | 130,286 |  |  |  | 114,328 |  |  |  | 189 |  |  |  | 114,517 |  |  |
| Medical/Industrial/Instrumentation |  |  | 202,329 |  |  |  | 6,945 |  |  |  | 209,274 |  |  |  | 164,635 |  |  |  | 17,808 |  |  |  | 182,443 |  |  |
| Networking/Communications |  |  | 134,493 |  |  |  | 55,244 |  |  |  | 189,737 |  |  |  | 158,508 |  |  |  | 49,265 |  |  |  | 207,773 |  |  |
| Other |  |  | 26,773 |  |  |  | (827 | ) |  |  | 25,946 |  |  |  | 20,307 |  |  |  | (91 | ) |  |  | 20,216 |  |  |
| Total |  | $ | 987,497 |  |  | $ | 80,447 |  |  | $ | 1,067,944 |  |  | $ | 952,027 |  |  | $ | 111,295 |  |  | $ | 1,063,322 |  |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2020-11-05):
[0001564590-20-051296:note_history:30]
As of September 28, 2020, the aggregate amount of the transaction price allocated to remaining performance obligations for long-term contracts was $19,606. The Company expects to recognize revenue on approximately 86% of the remaining performance obligations for the Company’s long-term contracts over the next twelve months with the remaining amount recognized thereafter. The remaining performance obligations for the Company’s short-term contracts are expected to be recognized within one year.
  (was, 2020-08-06, similarity 0.9865):
[0001564590-20-037715:note_history:30]
As of June 29, 2020, the aggregate amount of the transaction price allocated to remaining performance obligations for long-term contracts was $19,172. The Company expects to recognize revenue on approximately 83% of the remaining performance obligations for the Company’s long-term contracts over the next twelve months with the remaining amount recognized thereafter. The remaining performance obligations for the Company’s short-term contracts are expected to be recognized within one year.

- changed (2020-11-05):
[0001564590-20-051296:note_history:31]
Revenue from products and services transferred to customers over time and at a point in time accounted for 98% and 2%, respectively, of the Company’s revenue for the quarter and three quarters ended September 28, 2020. Revenue from products and services transferred to customers over time and at a point in time accounted for 97% and 3%, respectively, of the Company’s revenue for the quarter and three quarters ended September 30, 2019.
  (was, 2020-08-06, similarity 0.8575):
[0001564590-20-037715:note_history:31]
Revenue from products and services transferred to customers over time and at a point in time accounted for 98% and 2%, respectively, of the Company’s revenue for the quarter and two quarters ended June 29, 2020. Revenue from products and services transferred to customers over time and at a point in time accounted for 97% and 3%, respectively, of the Company’s revenue for the quarter ended July 1, 2019, and 96% and 4%, respectively, of the Company’s revenue for the two quarters ended July 1, 2019.

- added (2020-11-05):
[0001564590-20-051296:note_history:32]
|  | Quarter Ended September 28, 2020 |  |  | Quarter Ended September 30, 2019 |  |  |
|  | PCB |  |  | RF&S Components |  |  | E-M Solutions |  | Total |  |  | PCB |  |  | RF&S Components |  |  | E-M Solutions |  | Total |  |  |
| End Markets | (In thousands) |  |  |
| Aerospace and Defense | $ | 182,709 |  |  | $ | 180 |  |  | $ | 16 |  | $ | 182,905 |  |  | $ | 170,651 |  |  | $ | 729 |  |  | $ | 1 |  | $ | 171,381 |  |  |
| Automotive |  | 64,375 |  |  |  | — |  |  |  | 8,891 |  |  | 73,266 |  |  |  | 72,597 |  |  |  | — |  |  |  | 39,559 |  |  | 112,156 |  |  |
| Cellular Phone |  | 39 |  |  |  | — |  |  |  | — |  |  | 39 |  |  |  | 3,512 |  |  |  | — |  |  |  | — |  |  | 3,512 |  |  |
| Computing/Storage/ Peripherals |  | 62,606 |  |  |  | 186 |  |  |  | 30 |  |  | 62,822 |  |  |  | 57,367 |  |  |  | 592 |  |  |  | 72 |  |  | 58,031 |  |  |
| Medical/Industrial/ Instrumentation |  | 92,059 |  |  |  | 742 |  |  |  | 2,769 |  |  | 95,570 |  |  |  | 84,178 |  |  |  | 705 |  |  |  | 5,775 |  |  | 90,658 |  |  |
| Networking/Communications |  | 55,905 |  |  |  | 7,203 |  |  |  | 27,185 |  |  | 90,293 |  |  |  | 58,782 |  |  |  | 7,971 |  |  |  | 22,746 |  |  | 89,499 |  |  |
| Other |  | 5,971 |  |  |  | 3,431 |  |  |  | (721 | ) |  | 8,681 |  |  |  | 5,729 |  |  |  | 3,647 |  |  |  | (440 | ) |  | 8,936 |  |  |
| Total | $ | 463,664 |  |  | $ | 11,742 |  |  | $ | 38,170 |  | $ | 513,576 |  |  | $ | 452,816 |  |  | $ | 13,644 |  |  | $ | 67,713 |  | $ | 534,173 |  |  |

- added (2020-11-05):
[0001564590-20-051296:note_history:33]
|  | Three Quarters Ended September 28, 2020 |  |  | Three Quarters Ended September 30, 2019 |  |  |
|  | PCB |  |  | RF&S Components |  |  | E-M Solutions |  | Total |  |  | PCB |  |  | RF&S Components |  |  | E-M Solutions |  | Total |  |  |
| End Markets | (In thousands) |  |  |
| Aerospace and Defense | $ | 555,771 |  |  | $ | 189 |  |  | $ | 36 |  | $ | 555,996 |  |  | $ | 510,210 |  |  | $ | 777 |  |  | $ | 367 |  | $ | 511,354 |  |  |
| Automotive |  | 183,896 |  |  |  | — |  |  |  | 27,816 |  |  | 211,712 |  |  |  | 227,239 |  |  |  | — |  |  |  | 83,317 |  |  | 310,556 |  |  |
| Cellular Phone |  | 1,203 |  |  |  | — |  |  |  | — |  |  | 1,203 |  |  |  | 5,416 |  |  |  | — |  |  |  | — |  |  | 5,416 |  |  |
| Computing/Storage/ Peripherals |  | 192,275 |  |  |  | 663 |  |  |  | 170 |  |  | 193,108 |  |  |  | 170,914 |  |  |  | 1,373 |  |  |  | 261 |  |  | 172,548 |  |  |
| Medical/Industrial/ Instrumentation |  | 292,794 |  |  |  | 2,336 |  |  |  | 9,714 |  |  | 304,844 |  |  |  | 246,889 |  |  |  | 2,629 |  |  |  | 23,583 |  |  | 273,101 |  |  |
| Networking/ Communications |  | 178,428 |  |  |  | 19,173 |  |  |  | 82,429 |  |  | 280,030 |  |  |  | 188,069 |  |  |  | 37,192 |  |  |  | 72,011 |  |  | 297,272 |  |  |
| Other |  | 25,262 |  |  |  | 10,913 |  |  |  | (1,548 | ) |  | 34,627 |  |  |  | 18,025 |  |  |  | 9,754 |  |  |  | (531 | ) |  | 27,248 |  |  |
| Total | $ | 1,429,629 |  |  | $ | 33,274 |  |  | $ | 118,617 |  | $ | 1,581,520 |  |  | $ | 1,366,762 |  |  | $ | 51,725 |  |  | $ | 179,008 |  | $ | 1,597,495 |  |  |

- removed (2020-11-05):
[0001564590-20-037715:note_history:34]
|  |  | Quarter Ended June 29, 2020 |  |  | Quarter Ended July 1, 2019 |  |  |
|  |  | PCB |  |  | E-M Solutions |  |  | Total |  |  | PCB |  |  | E-M Solutions |  |  | Total |  |  |
| End Markets |  | (In thousands) |  |  |
| Aerospace and Defense |  | $ | 188,620 |  |  | $ | 20 |  |  | $ | 188,640 |  |  | $ | 174,810 |  |  | $ | 362 |  |  | $ | 175,172 |  |  |
| Automotive |  |  | 58,100 |  |  |  | 11,462 |  |  |  | 69,562 |  |  |  | 73,049 |  |  |  | 23,993 |  |  |  | 97,042 |  |  |
| Cellular Phone |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |
| Computing/Storage/Peripherals |  |  | 71,864 |  |  |  | 36 |  |  |  | 71,900 |  |  |  | 56,482 |  |  |  | — |  |  |  | 56,482 |  |  |
| Medical/Industrial/Instrumentation |  |  | 114,105 |  |  |  | 3,187 |  |  |  | 117,292 |  |  |  | 82,453 |  |  |  | 9,641 |  |  |  | 92,094 |  |  |
| Networking/Communications |  |  | 73,595 |  |  |  | 36,267 |  |  |  | 109,862 |  |  |  | 74,485 |  |  |  | 25,926 |  |  |  | 100,411 |  |  |
| Other |  |  | 13,783 |  |  |  | (741 | ) |  |  | 13,042 |  |  |  | 5,681 |  |  |  | (5 | ) |  |  | 5,676 |  |  |
| Total |  | $ | 520,067 |  |  | $ | 50,231 |  |  | $ | 570,298 |  |  | $ | 466,960 |  |  | $ | 59,917 |  |  | $ | 526,877 |  |  |

- removed (2020-11-05):
[0001564590-20-037715:note_history:35]
|  |  | Two Quarters Ended June 29, 2020 |  |  | Two Quarters Ended July 1, 2019 |  |  |
|  |  | PCB |  |  | E-M Solutions |  |  | Total |  |  | PCB |  |  | E-M Solutions |  |  | Total |  |  |
| End Markets |  | (In thousands) |  |  |
| Aerospace and Defense |  | $ | 373,071 |  |  | $ | 20 |  |  | $ | 373,091 |  |  | $ | 339,607 |  |  | $ | 366 |  |  | $ | 339,973 |  |  |
| Automotive |  |  | 119,521 |  |  |  | 18,925 |  |  |  | 138,446 |  |  |  | 154,642 |  |  |  | 43,758 |  |  |  | 198,400 |  |  |
| Cellular Phone |  |  | 1,164 |  |  |  | — |  |  |  | 1,164 |  |  |  | — |  |  |  | — |  |  |  | — |  |  |
| Computing/Storage/Peripherals |  |  | 130,146 |  |  |  | 140 |  |  |  | 130,286 |  |  |  | 114,328 |  |  |  | 189 |  |  |  | 114,517 |  |  |
| Medical/Industrial/Instrumentation |  |  | 202,329 |  |  |  | 6,945 |  |  |  | 209,274 |  |  |  | 164,635 |  |  |  | 17,808 |  |  |  | 182,443 |  |  |
| Networking/Communications |  |  | 134,493 |  |  |  | 55,244 |  |  |  | 189,737 |  |  |  | 158,508 |  |  |  | 49,265 |  |  |  | 207,773 |  |  |
| Other |  |  | 26,773 |  |  |  | (827 | ) |  |  | 25,946 |  |  |  | 20,307 |  |  |  | (91 | ) |  |  | 20,216 |  |  |
| Total |  | $ | 987,497 |  |  | $ | 80,447 |  |  | $ | 1,067,944 |  |  | $ | 952,027 |  |  | $ | 111,295 |  |  | $ | 1,063,322 |  |  |


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: no_current_note, score: 0.0

- removed (2020-11-05):
[0001564590-20-037715:note_history:36]
(20) Subsequent Event

- removed (2020-11-05):
[0001564590-20-037715:note_history:37]
Subsequent to June 29, 2020, the Company made a $400,000 debt principal prepayment for its Term Loan.
