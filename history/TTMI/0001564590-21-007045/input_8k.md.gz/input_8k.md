# TTMI 8-K — 0001193125-21-027322 filed 2021-02-03

## item codes, every 8-K on or before 2021-02-22

- 2021-02-03 0001193125-21-027322 — 2.02, 8.01, 9.01
- 2020-12-15 0001193125-20-318208 — 7.01, 9.01
- 2020-10-28 0001193125-20-279980 — 2.02, 9.01
- 2020-09-04 0001193125-20-239645 — 5.02
- 2020-07-29 0001193125-20-203110 — 2.02, 9.01
- 2020-05-08 0001193125-20-137566 — 5.07
- 2020-05-04 0001193125-20-131366 — 7.01, 9.01
- 2020-04-29 0001193125-20-126358 — 2.05, 7.01, 9.01
- 2020-04-29 0001193125-20-126117 — 2.02, 9.01
- 2020-04-23 0001193125-20-117365 — 2.01, 7.01, 9.01
- 2020-02-05 0001193125-20-025365 — 2.02, 9.01
- 2020-01-31 0001193125-20-021278 — 5.02
- 2020-01-22 0001193125-20-012011 — 1.01, 7.01, 9.01
- 2019-10-30 0001193125-19-278973 — 2.02, 9.01
- 2019-08-19 0001193125-19-224091 — 5.02, 9.01
- 2019-07-31 0001193125-19-208689 — 2.02, 9.01
- 2019-07-24 0001193125-19-201401 — 1.01, 2.03
- 2019-06-13 0001193125-19-171943 — 7.01, 9.01
- 2019-06-06 0001193125-19-167332 — 1.01, 2.03, 3.03, 7.01, 9.01
- 2019-05-09 0001193125-19-143113 — 5.07
- 2019-05-01 0001193125-19-132977 — 2.02, 9.01
- 2019-02-06 0001193125-19-029540 — 2.02, 9.01
- 2019-01-15 0001193125-19-009142 — 2.02, 9.01
- 2018-10-30 0001193125-18-312212 — 2.02, 9.01
- 2018-10-22 0001193125-18-303926 — 5.02
- 2018-09-06 0001193125-18-268231 — 5.02, 9.01
- 2018-08-01 0001193125-18-234997 — 2.02, 9.01
- 2018-06-29 0001193125-18-209635 — 9.01 — amendment of 0001193125-18-120583
- 2018-05-29 0001193125-18-176976 — 7.01, 9.01
- 2018-05-10 0001193125-18-159394 — 5.07
- 2018-05-09 0001193125-18-157596 — 5.02
- 2018-05-02 0001193125-18-148650 — 2.02, 9.01
- 2018-04-18 0001193125-18-120583 — 1.01, 2.01, 2.03, 7.01, 9.01
- 2018-02-21 0001193125-18-052169 — 8.01, 9.01
- 2018-02-20 0001193125-18-050385 — 5.02, 9.01
- 2018-02-09 0001193125-18-036966 — 7.01, 9.01
- 2018-02-07 0001193125-18-034744 — 2.02, 9.01
- 2017-12-14 0001193125-17-369625 — 1.01, 2.03, 9.01
- 2017-12-04 0001193125-17-359439 — 1.01, 7.01, 9.01
- 2017-11-01 0001193125-17-329425 — 2.02, 9.01
- 2017-09-29 0001193125-17-298999 — 1.01, 2.03, 3.03, 7.01, 9.01
- 2017-09-15 0001193125-17-286491 — 7.01, 9.01
- 2017-09-11 0001193125-17-281193 — 7.01, 9.01
- 2017-09-06 0001193125-17-277536 — 7.01, 9.01
- 2017-08-02 0001193125-17-245823 — 2.02, 9.01
- 2017-05-18 0001193125-17-173896 — 5.02, 5.07
- 2017-05-08 0001193125-17-162548 — 2.02, 9.01
- 2017-03-01 0001193125-17-063931 — 1.01, 1.02, 5.02
- 2017-02-08 0001193125-17-034652 — 2.02, 9.01
- 2016-11-18 0001193125-16-772305 — 8.01, 9.01
- 2016-10-26 0001193125-16-747948 — 2.02, 9.01
- 2016-10-20 0001193125-16-742905 — 5.02
- 2016-10-05 0001193125-16-731552 — 5.02, 9.01
- 2016-09-27 0001193125-16-720828 — 1.01, 2.03, 7.01, 9.01
- 2016-07-27 0001193125-16-659983 — 2.02, 9.01
- 2016-05-23 0001193125-16-599342 — 7.01, 9.01
- 2016-05-18 0001193125-16-594656 — 5.02, 5.03, 5.07, 9.01
- 2016-04-27 0001171843-16-009432 — 2.02, 9.01
- 2016-03-08 0001193125-16-495457 — 5.03, 7.01, 9.01
- 2016-02-09 0001193125-16-454281 — 8.01, 9.01
- 2016-02-04 0001171843-16-007659 — 2.02, 9.01
- 2016-01-04 0001193125-16-418740 — 1.01, 9.01
- 2015-12-11 0001193125-15-400867 — 5.02, 9.01
- 2015-10-30 0001171843-15-005835 — 2.02, 7.01 — amendment of 0001171843-15-005766
- 2015-10-28 0001171843-15-005766 — 2.02, 9.01
- 2015-09-29 0001193125-15-331517 — 2.02, 2.05, 2.06, 9.01
- 2015-08-05 0001171843-15-004361 — 2.02, 9.01
- 2015-07-31 0001193125-15-272962 — 9.01 — amendment of 0001193125-15-210734
- 2015-06-02 0001193125-15-210734 — 1.01, 1.02, 2.01, 2.03, 7.01, 9.01
- 2015-05-29 0001193125-15-206622 — 1.01, 2.03, 9.01
- 2015-05-20 0001171843-15-002975 — 7.01, 9.01
- 2015-05-19 0001193125-15-193434 — 5.07, 9.01
- 2015-05-05 0001171843-15-002499 — 7.01, 9.01
- 2015-04-29 0001171843-15-002307 — 2.02, 9.01
- 2015-04-21 0001193125-15-139239 — 7.01, 9.01
- 2015-04-21 0001171843-15-002065 — 2.02, 9.01
- 2015-02-04 0001171843-15-000599 — 2.02, 9.01
- 2015-01-20 0001193125-15-014019 — 7.01, 9.01
- 2014-12-30 0001193125-14-457111 — 7.01, 9.01
- 2014-12-15 0001193125-14-442645 — 1.01, 9.01
- 2014-12-04 0001193125-14-433658 — 8.01, 9.01
- 2014-11-18 0001193125-14-415889 — 7.01, 9.01
- 2014-10-29 0001171843-14-005051 — 2.02, 9.01
- 2014-10-27 0001193125-14-383428 — 1.01, 9.01
- 2014-09-22 0001193125-14-348697 — 1.01, 7.01, 9.01
- 2014-08-05 0001193125-14-295808 — 1.01, 5.02, 9.01
- 2014-07-30 0001171843-14-003548 — 2.02, 9.01
- 2014-04-30 0001171843-14-002017 — 2.02, 9.01
- 2014-04-25 0001193125-14-160146 — 5.02, 5.07, 9.01
- 2014-04-10 0001171843-14-001656 — 2.02, 9.01
- 2014-03-04 0001193125-14-082534 — 4.01, 9.01
- 2014-02-05 0001171843-14-000553 — 2.02, 9.01
- 2014-01-14 0001193125-14-010922 — 1.01, 2.03, 3.02, 8.01, 9.01
- 2013-12-27 0001193125-13-486144 — 5.02, 9.01
- 2013-12-20 0001193125-13-481141 — 1.01, 1.02, 2.03, 3.02, 8.01, 9.01
- 2013-12-17 0001193125-13-476207 — 5.03
- 2013-10-30 0001193125-13-418572 — 2.02, 5.02, 9.01
- 2013-09-12 0001193125-13-365420 — 2.05
- 2013-08-14 0001193125-13-334349 — 7.01, 9.01
- 2013-08-01 0001171843-13-003138 — 2.02, 9.01
- 2013-06-25 0001193125-13-270725 — 5.02, 9.01
- 2013-05-02 0001171843-13-001746 — 2.02, 9.01
- 2013-04-29 0001193125-13-182083 — 5.02, 5.07, 9.01
- 2013-03-18 0001193125-13-111308 — 1.01, 7.01, 9.01
- 2013-03-06 0001193125-13-093625 — 5.02, 9.01
- 2013-03-01 0001193125-13-087439 — 2.02 — amendment of 0001171843-13-000414
- 2013-02-28 0001193125-13-084764 — 5.02
- 2013-02-05 0001171843-13-000414 — 2.02, 9.01
- 2013-01-31 0001193125-13-032848 — 5.02, 9.01
- 2013-01-17 0001193125-13-015928 — 7.01, 9.01
- 2013-01-16 0001193125-13-014581 — 2.02, 9.01
- 2012-12-11 0001193125-12-498644 — 5.02, 9.01
- 2012-11-15 0001193125-12-472451 — 7.01, 9.01
- 2012-11-01 0001171843-12-003890 — 2.02, 9.01
- 2012-09-19 0001193125-12-396969 — 1.01, 2.03, 7.01, 9.01
- 2012-09-11 0001193125-12-388130 — 7.01, 9.01
- 2012-07-31 0001171843-12-002829 — 2.02, 9.01
- 2012-05-15 0001193125-12-233501 — 7.01, 9.01
- 2012-05-01 0001171843-12-001574 — 2.02, 9.01
- 2012-04-27 0001193125-12-191623 — 5.07
- 2012-03-01 0001193125-12-090623 — 2.02 — amendment of 0001171843-12-000382
- 2012-02-07 0001171843-12-000382 — 2.02, 9.01
- 2012-01-19 0001193125-12-016588 — 5.02, 9.01
- 2011-11-15 0000950123-11-098812 — 7.01, 9.01
- 2011-11-02 0001171843-11-003248 — 2.02, 9.01
- 2011-09-28 0000950123-11-087344 — 7.01, 9.01
- 2011-09-19 0000950123-11-085128 — 5.02, 9.01
- 2011-09-15 0000950123-11-084704 — 5.07 — amendment of 0000950123-11-054296
- 2011-08-04 0001171843-11-002356 — 2.02, 9.01
- 2011-07-27 0000950123-11-068987 — 1.01, 2.03, 9.01
- 2011-06-21 0000950123-11-060477 — 7.01, 9.01
- 2011-06-06 0000950123-11-056971 — 5.03, 9.01
- 2011-05-26 0000950123-11-054296 — 5.07
- 2011-05-10 0000950123-11-048462 — 8.01, 9.01
- 2011-05-05 0001171843-11-001344 — 2.02, 9.01
- 2011-03-22 0000950123-11-027824 — 7.01, 9.01
- 2011-03-18 0000950123-11-026913 — 4.01
- 2011-03-18 0000950123-11-026910 — 4.01, 9.01 — amendment, the index does not say of what
- 2011-03-02 0000950123-11-020941 — 5.03, 9.01
- 2011-02-10 0001171843-11-000391 — 2.02, 9.01
- 2011-01-13 0000950123-11-002528 — 7.01, 9.01
- 2011-01-13 0000950123-11-002446 — 2.02, 9.01
- 2010-11-29 0000950123-10-109448 — 4.01, 9.01 — amendment, the index does not say of what
- 2010-11-17 0000950123-10-106706 — 4.01
- 2010-11-15 0000950123-10-105479 — 5.02, 9.01
- 2010-11-04 0001171843-10-002324 — 2.02, 9.01
- 2010-10-22 0000950123-10-095179 — 1.01, 9.01
- 2010-10-04 0000950123-10-090949 — 1.01, 5.03, 9.01
- 2010-08-05 0001171843-10-001587 — 2.02, 9.01
- 2010-08-05 0000950123-10-073258 — 1.01, 2.03, 9.01
- 2010-08-05 0000950123-10-073256 — 9.01 — amendment of 0000950123-10-034163
- 2010-07-12 0000950123-10-064794 — 5.02, 8.01, 9.01
- 2010-06-10 0000950123-10-057166 — 7.01, 9.01
- 2010-06-02 0000950123-10-055111 — 1.01, 5.07, 9.01
- 2010-05-06 0001171843-10-000819 — 2.02, 9.01
- 2010-04-26 0000950123-10-037806 — 8.01, 9.01 — amendment of 0000950123-10-034163
- 2010-04-13 0000950123-10-034163 — 1.01, 2.01, 2.03, 5.02, 7.01, 9.01
- 2010-03-30 0000950123-10-030123 — 1.01, 5.02, 9.01
- 2010-03-24 0000950123-10-027317 — 1.01, 5.02, 9.01
- 2010-03-16 0000950123-10-024853 — 7.01, 9.01 — amendment of 0001171843-10-000140
- 2010-03-15 0000950123-10-024637 — 5.07
- 2010-02-04 0001171843-10-000140 — 2.02, 9.01
- 2010-02-02 0000950123-10-007780 — 8.01, 9.01
- 2010-01-13 0000950123-10-002245 — 7.01, 9.01
- 2009-12-23 0000950123-09-073069 — 1.01, 9.01
- 2009-12-15 0000950123-09-070868 — 8.01, 9.01
- 2009-11-16 0000950123-09-062630 — 1.01, 7.01, 9.01
- 2009-11-04 0001171843-09-001103 — 2.02, 9.01
- 2009-09-04 0000950123-09-041133 — 2.05, 9.01
- 2009-07-29 0001171843-09-000743 — 2.02, 9.01
- 2009-06-09 0000950123-09-012507 — 7.01, 9.01
- 2009-04-30 0001171843-09-000427 — 2.02, 9.01
- 2009-04-28 0001362310-09-005960 — 8.01
- 2009-02-19 0001362310-09-002454 — 5.03, 9.01
- 2009-02-10 0001171843-09-000123 — 2.02, 9.01
- 2009-01-16 0000950153-09-000040 — 2.05, 9.01
- 2009-01-08 0000950153-09-000023 — 7.01, 9.01
- 2008-10-29 0001157523-08-008533 — 2.02, 9.01
- 2008-07-29 0001157523-08-005998 — 2.02, 9.01
- 2008-05-22 0000950153-08-001035 — 1.01, 2.03, 3.02, 9.01
- 2008-05-22 0000950153-08-001034 — 7.01, 9.01
- 2008-05-15 0000950153-08-000987 — 1.01, 1.02, 2.03, 3.02, 9.01
- 2008-04-30 0001157523-08-003483 — 2.02, 9.01
- 2008-02-07 0001157523-08-001077 — 2.02, 9.01
- 2008-01-08 0000950153-08-000033 — 7.01, 9.01
- 2007-11-15 0000950153-07-002440 — 7.01, 9.01
- 2007-11-14 0000950153-07-002426 — 7.01, 9.01
- 2007-11-14 0000950153-07-002421 — 5.03, 9.01
- 2007-10-31 0001157523-07-010491 — 2.02, 9.01
- 2007-10-02 0000950153-07-002094 — 7.01, 9.01
- 2007-07-31 0000950153-07-001622 — 2.02, 9.01
- 2007-06-13 0000950153-07-001327 — 7.01, 9.01
- 2007-05-02 0000950153-07-000941 — 2.02, 9.01
- 2007-04-12 0000950153-07-000763 — 5.02, 9.01
- 2007-02-15 0000950153-07-000339 — 2.02, 9.01
- 2007-01-11 0000950153-07-000076 — 7.01, 9.01
- 2007-01-10 0000950153-07-000071 — 2.01, 9.01 — amendment, the index does not say of what
- 2006-12-11 0000950153-06-002967 — 2.05, 9.01
- 2006-11-15 0000950153-06-002843 — 7.01, 9.01
- 2006-11-14 0000950153-06-002837 — 7.01, 9.01
- 2006-11-02 0000950153-06-002682 — 1.01, 1.02, 2.03, 9.01
- 2006-11-01 0000950153-06-002668 — 2.02, 9.01
- 2006-10-30 0000950124-06-006210 — 2.01, 9.01
- 2006-08-04 0000950153-06-002025 — 1.01, 9.01
- 2006-07-26 0000950153-06-001937 — 2.02, 9.01
- 2006-06-28 0000950153-06-001716 — 1.01, 9.01
- 2006-06-13 0000950153-06-001597 — 7.01, 9.01
- 2006-04-26 0000950153-06-001079 — 2.02, 9.01
- 2006-02-08 0001104659-06-006985 — 2.02, 9.01
- 2006-01-12 0001104659-06-001893 — 7.01, 9.01
- 2005-12-05 0001104659-05-058918 — 1.01, 5.02, 9.01
- 2005-10-26 0001104659-05-050306 — 2.02, 9.01
- 2005-09-20 0001104659-05-044954 — 8.01
- 2005-08-30 0001104659-05-042053 — 3.03, 8.01, 9.01
- 2005-07-27 0001104659-05-034437 — 2.02, 5.02, 9.01
- 2005-07-21 0001104659-05-033462 — 1.01, 1.02, 2.03, 9.01
- 2005-06-13 0001104659-05-027969 — 8.01
- 2005-06-08 0001104659-05-027364 — 7.01, 9.01
- 2005-05-17 0001104659-05-024118 — 7.01, 9.01
- 2005-05-12 0001104659-05-022993 — 7.01, 9.01
- 2005-05-11 0001104659-05-022606 — 1.01, 9.01
- 2005-05-02 0001104659-05-019649 — 2.02, 5.02, 9.01
- 2005-04-26 0001104659-05-018233 — 7.01, 9.01
- 2005-02-08 0001104659-05-004642 — 2.02, 9.01
- 2005-01-12 0001104659-05-001194 — 7.01, 9.01
- 2004-12-22 0001104659-04-040933 — 5.02
- 2004-12-08 0001104659-04-038850 — 7.01, 9.01
- 2004-10-26 0001104659-04-031931 — 2.02, 9.01
- 2004-10-01 0001104659-04-029361 — 5.02
- 2004-08-02 0001104659-04-021785 — 9
- 2004-07-29 0001104659-04-021529 — 12
- 2004-05-06 0001104659-04-012742 — 9
- 2004-04-26 0001104659-04-011228 — 12
- 2004-02-03 0001104659-04-002424 — 9
- 2004-01-28 0001104659-04-001980 — 12
- 2004-01-09 0001104659-04-000457 — 9
- 2003-10-21 0001104659-03-023304 — 12
- 2003-07-29 0001104659-03-015999 — 12
- 2003-05-08 0001104659-03-008647 — 9
- 2003-05-08 0001104659-03-008462 — 9
- 2003-05-01 0001104659-03-007866 — 9
- 2003-03-07 0001104659-03-003816 — 2, 7 — amendment of 0000950153-02-002190
- 2002-12-27 0000950153-02-002190 — 2, 7
- 2002-05-17 0000912057-02-021145 — 4, 7
- 2001-12-21 0000912057-01-544281 — 7
- 2000-10-27 0000912057-00-046109 — 5

## late-filing notifications on or before 2021-02-22

- none on or before 2021-02-22

## item 2.02 — earnings release, exhibit 99.1

[0001193125-21-027322:8k_2_02:1]
EX-99.1
2
d79559dex991.htm
EX-99.1

[0001193125-21-027322:8k_2_02:2]
EX-99.1

[0001193125-21-027322:8k_2_02:3]
Exhibit 99.1

[0001193125-21-027322:8k_2_02:4]
| TTM Technologies, Inc., Q4’20 |  | Contact: |
|  |  | Sameer Desai, |
|  |  | Senior Director, Corporate Development & Investor Relations |
|  |  | Sameer.desai@ttmtech.com 714-327-3050 |

[0001193125-21-027322:8k_2_02:5]
TTM Technologies, Inc. Reports Fiscal Fourth Quarter and 2020 Results

[0001193125-21-027322:8k_2_02:6]
Santa Ana, CA – February 3, 2021– TTM Technologies, Inc. (NASDAQ:TTMI), a leading global printed circuit board (“PCB”) and
radio frequency (“RF”) components manufacturer, today reported results for the fourth quarter of fiscal 2020, which ended on December 28, 2020.

[0001193125-21-027322:8k_2_02:7]
Fourth Quarter 2020 Highlights

[0001193125-21-027322:8k_2_02:8]
|  | • |  | Net sales were $523.8 million |

[0001193125-21-027322:8k_2_02:9]
|  | • |  | GAAP net income of $39.0 million, or $0.34 per diluted share |

[0001193125-21-027322:8k_2_02:10]
|  | • |  | Non-GAAP net income was $40.2 million, or $0.37 per diluted share |

[0001193125-21-027322:8k_2_02:11]
|  | • |  | Cash flow from operations of $55.5 million |

[0001193125-21-027322:8k_2_02:12]
|  | • |  | Repaid and settled $250 million convertible bonds |

[0001193125-21-027322:8k_2_02:13]
|  | • |  | Leverage ratio at end of Q4 2020 was 1.4x defined as net debt divided by the last twelve months EBITDA (excluding Mobility), the lowest level in five years |

[0001193125-21-027322:8k_2_02:14]
|  | • |  | In Q1 2021, announced $100 million stock repurchase program in separate press release |

[0001193125-21-027322:8k_2_02:15]
On April 19th, 2020, TTM completed the previously announced sale of its Mobility business unit. The operating results and related assets and liabilities of
the Mobility business under US GAAP are presented as discontinued operations for all periods. Non-GAAP results do not include Mobility results but still include the two E-MS plants being shut down. Please refer to the earnings schedule for
additional details on exited businesses and continuing operations.

[0001193125-21-027322:8k_2_02:16]
Fourth Quarter 2020 GAAP Financial Results

[0001193125-21-027322:8k_2_02:17]
Net sales from continuing operations for the fourth quarter of 2020 were $523.8 million, compared to $535.7 million in the fourth quarter of 2019.

[0001193125-21-027322:8k_2_02:18]
GAAP operating income from continuing operations for the fourth quarter of 2020 was $29.2 million. This compares to GAAP operating income of $29.4
million in the fourth quarter of 2019.

[0001193125-21-027322:8k_2_02:19]
GAAP net income from continuing operations for the fourth quarter of 2020 was $39.0 million, or $0.34 per diluted
share, compared to net income of $10.8 million, or $0.10 per diluted share in the fourth quarter of 2019.

[0001193125-21-027322:8k_2_02:20]
Fourth Quarter 2020 Non-GAAP Financial Results

[0001193125-21-027322:8k_2_02:21]
On a non-GAAP basis, net income from continuing operations for the fourth quarter of 2020
was $40.2 million, or $0.37 per diluted share. This compares to non-GAAP net income of $27.5 million, or $0.26 per diluted share, for the fourth quarter of 2019.

[0001193125-21-027322:8k_2_02:22]
Adjusted EBITDA for continuing operations in the fourth quarter of 2020 was $68.2 million, or 13.0 percent of net sales, compared to adjusted EBITDA of $72.8
million, or 13.6 percent of net sales, for the fourth quarter of 2019.

[0001193125-21-027322:8k_2_02:23]
“In the fourth quarter, TTM demonstrated excellent operational execution in
the face of COVID-19 related challenges to deliver revenue above the midpoint and earnings above the previously guided range. TTM outperformed revenue expectations due to better sales across all end markets,” said Tom Edman, CEO of TTM.
“Additionally, strict financial discipline led to solid operating cash flow in the quarter, driving our net debt leverage ratio down to 1.4x and enabling repayment of our convertible bond.”

[0001193125-21-027322:8k_2_02:24]
| TTM Technologies, Inc., Q4’20 |  | Contact: Sameer Desai, Senior Director, Corporate Development & Investor Relations Sameer.desai@ttmtech.com 714-327-3050 |

[0001193125-21-027322:8k_2_02:25]
Full Year 2020 Financial Results

[0001193125-21-027322:8k_2_02:26]
Net sales from continuing operations for fiscal year 2020 decreased to $2.11 billion from $2.13 billion in fiscal year 2019, a 1.3% decrease.

[0001193125-21-027322:8k_2_02:27]
GAAP operating income from continuing operations for fiscal year 2020 was $28.1 million, a decrease from GAAP operating income of $109.6 million in fiscal
year 2019.

[0001193125-21-027322:8k_2_02:28]
GAAP net loss from continuing operations for fiscal year 2020 was $16.4 million, or $0.15 per diluted share, compared to GAAP net income of
$31.9 million, or $0.30 per diluted share, for fiscal year 2019.

[0001193125-21-027322:8k_2_02:29]
On a non-GAAP basis, net income from continuing operations for fiscal year 2020 was
$116.7 million, or $1.10 per diluted share. This compares to fiscal year 2019 non-GAAP net income of $107.1 million, or $1.01 per diluted share.

[0001193125-21-027322:8k_2_02:30]
Adjusted
EBITDA for fiscal year 2020 was $272.3 million, or 12.9 percent of net sales, compared to $285.7 million, or 13.4 percent of net sales, for fiscal year 2019. Cash flow from operations for fiscal year 2020 was $287.2 million.

[0001193125-21-027322:8k_2_02:31]
“Despite the challenges from COVID-19 and the strengthening Chinese currency, we delivered solid results in 2020 and made progress on our strategy of
diversification, differentiation and discipline. Specifically, we exited the volatile consumer and lower margin businesses through the sale of the Mobility business unit and the restructuring of the E-MS business unit,” continued Edman.
“In addition, we generated significant cash flows due to our operational and financial discipline. This cash, along with the proceeds from the Mobility sale, allowed us to repay $400 million of our Term Loan and our convertible bonds reducing
our leverage and putting TTM in a strong position for the future.”

[0001193125-21-027322:8k_2_02:32]
Business Outlook

[0001193125-21-027322:8k_2_02:33]
TTM estimates that revenue for the first quarter of 2021 will be in the range of $490 million to $530 million, and non-GAAP net income will be in the range of
$0.19 to $0.25 per diluted share.

[0001193125-21-027322:8k_2_02:34]
Live Webcast/Conference Call

[0001193125-21-027322:8k_2_02:35]
TTM will host a conference call and webcast to discuss fourth quarter 2020 results and the first quarter 2021 outlook on Wednesday, February 3rd, 2021 at 4:30
p.m. Eastern Time (1:30 p.m. Pacific Time). The conference call will include forward-looking statements.

[0001193125-21-027322:8k_2_02:36]
Telephone access is available by dialing
domestic 800-458-4121 or international 323-794-2093 (ID 2336839). The conference call also will be webcast on TTM’s website at www.ttm.com.

[0001193125-21-027322:8k_2_02:37]
To
Access a Replay of the Webcast

[0001193125-21-027322:8k_2_02:38]
The replay of the webcast will remain accessible for one week following the live event on TTM’s website at
www.ttm.com.

[0001193125-21-027322:8k_2_02:39]
About TTM

[0001193125-21-027322:8k_2_02:40]
TTM Technologies, Inc. is a
leading global printed circuit board manufacturer, focusing on quick-turn and volume production of technologically advanced PCBs and backplane assemblies as well as a global designer and manufacturer of high-frequency radio frequency (RF) and
microwave components and assemblies. TTM stands for time-to-market, representing how TTM’s time-critical, one-stop manufacturing services enable customers to shorten the time required to develop new products and bring them to market. Additional
information can be found at www.ttm.com.

[0001193125-21-027322:8k_2_02:41]
| TTM Technologies, Inc., Q4’20 |  | Contact: Sameer Desai, Senior Director, Corporate Development & Investor Relations Sameer.desai@ttmtech.com 714-327-3050 |

[0001193125-21-027322:8k_2_02:42]
Forward-Looking Statements

[0001193125-21-027322:8k_2_02:43]
The preliminary financial results included in this press release represent the most current information available to management. The company’s actual
results when disclosed in its Form 10-K may differ from these preliminary results as a result of the completion of the company’s financial closing procedures; final adjustments; completion of the review
by the company’s independent registered accounting firm; and other developments that may arise between now and the disclosure of the final results. This release contains forward-looking statements that relate to future events or performance.
TTM cautions you that such statements are simply predictions and actual events or results may differ materially. These statements reflect TTM’s current expectations, and TTM does not undertake to update or revise these forward looking
statements, even if experience or future changes make it clear that any projected results expressed or implied in this or other TTM statements will not be realized. Further, these statements involve risks and uncertainties, many of which are beyond
TTM’s control, which could cause actual results to differ materially from the forward-looking statements. These risks and uncertainties include, but are not limited to, the impact of COVID-19, general
market and economic conditions, including interest rates, currency exchange rates and consumer spending, demand for TTM’s products, market pressures on prices of TTM’s products, warranty claims, changes in product mix, contemplated
significant capital expenditures and related financing requirements, TTM’s dependence upon a small number of customers and other factors set forth in the “Risk Factors” and “Management’s Discussion and Analysis of Financial
Condition and Results of Operations” sections of the Company’s public reports filed with the SEC.

[0001193125-21-027322:8k_2_02:44]
About Our
Non-GAAP Financial Measures

[0001193125-21-027322:8k_2_02:45]
This release includes information about TTM’s adjusted EBITDA, non-GAAP net income and non-GAAP earnings per share, all of which are non-GAAP financial measures. TTM presents non-GAAP financial information to enable investors to see TTM through the eyes of management and to provide better insight into TTM’s ongoing financial performance.

[0001193125-21-027322:8k_2_02:46]
A material limitation associated with the use of the above non-GAAP financial measures is that they have no standardized measurement prescribed by GAAP and
may not be comparable to similar non-GAAP financial measures used by other companies. TTM compensates for these limitations by providing full disclosure of each non-GAAP financial measure and reconciliation to the most directly comparable GAAP
financial measure. However, the non-GAAP financial measures should not be considered in isolation from, or as a substitute for, financial information prepared in accordance with GAAP.

[0001193125-21-027322:8k_2_02:47]
With respect to the Company’s outlook for non-GAAP net income per diluted share, we are unable to predict with reasonable certainty or without
unreasonable effort certain items that may affect a comparable measure calculated and presented in accordance with GAAP. Our expected non-GAAP net income per diluted share excludes primarily the future impact
of restructuring actions, impairment charges, unusual gains and losses, and tax adjustments. These reconciling items are highly variable and difficult to predict due to various factors outside of management’s control and could have a material
impact on our future period net income per diluted share calculated and presented in accordance with GAAP. Accordingly, a reconciliation of non-GAAP net income per diluted share to a comparable measure
calculated and presented in accordance with GAAP is not available without unreasonable effort and has not been provided.

[0001193125-21-027322:8k_2_02:48]
- Tables Follow -

[0001193125-21-027322:8k_2_02:49]
TTM TECHNOLOGIES, INC.

[0001193125-21-027322:8k_2_02:50]
Selected Unaudited Financial Information

[0001193125-21-027322:8k_2_02:51]
(In thousands, except per share data)

[0001193125-21-027322:8k_2_02:52]
|  |  | Fourth Quarter |  |  | Full Year |  |
|  |  | 2020 |  |  | 2019* |  |  | 2020 |  |  | 2019* |  |
| CONSOLIDATED CONDENSED STATEMENTS OF OPERATIONS |  |  |  |  |  |  |  |  |  |
| Net sales |  | $ | 523,802 |  |  | $ | 535,715 |  |  | $ | 2,105,322 |  |  | $ | 2,133,210 |  |
| Cost of goods sold |  |  | 435,829 |  |  |  | 435,470 |  |  |  | 1,746,299 |  |  |  | 1,756,033 |  |
| Gross profit |  |  | 87,973 |  |  |  | 100,245 |  |  |  | 359,023 |  |  |  | 377,177 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Selling and marketing |  |  | 15,849 |  |  |  | 17,560 |  |  |  | 63,882 |  |  |  | 69,171 |  |
| General and administrative |  |  | 26,831 |  |  |  | 37,193 |  |  |  | 122,477 |  |  |  | 129,284 |  |
| Research and development |  |  | 4,604 |  |  |  | 4,367 |  |  |  | 19,770 |  |  |  | 17,937 |  |
| Amortization of definite-lived intangibles |  |  | 9,589 |  |  |  | 9,531 |  |  |  | 38,838 |  |  |  | 45,776 |  |
| Restructuring charges |  |  | 1,934 |  |  |  | 2,204 |  |  |  | 16,764 |  |  |  | 5,380 |  |
| Impairment of goodwill |  |  | — |  |  |  | — |  |  |  | 69,200 |  |  |  | — |  |
| Total operating expenses |  |  | 58,807 |  |  |  | 70,855 |  |  |  | 330,931 |  |  |  | 267,548 |  |
| Operating income |  |  | 29,166 |  |  |  | 29,390 |  |  |  | 28,092 |  |  |  | 109,629 |  |
| Interest expense |  |  | (14,599 | ) |  |  | (19,976 | ) |  |  | (73,156 | ) |  |  | (82,087 | ) |
| Other, net |  |  | (1,854 | ) |  |  | (1,741 | ) |  |  | (1,213 | ) |  |  | 6,784 |  |
| Income (loss) from continuing operations before income taxes |  |  | 12,713 |  |  |  | 7,673 |  |  |  | (46,277 | ) |  |  | 34,326 |  |
| Income tax benefit (provision) |  |  | 26,247 |  |  |  | 3,124 |  |  |  | 29,891 |  |  |  | (2,405 | ) |
| Net income (loss) from continuing operations |  |  | 38,960 |  |  |  | 10,797 |  |  |  | (16,386 | ) |  |  | 31,921 |  |
| Income from discontinued operations, net of income taxes |  |  | — |  |  |  | 14,462 |  |  |  | 193,921 |  |  |  | 9,380 |  |
| Net income |  | $ | 38,960 |  |  | $ | 25,259 |  |  | $ | 177,535 |  |  | $ | 41,301 |  |
| * Reclassified Research and development expenses as a separate line item from General and administrative expenses |  |
| Earnings per share: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic earnings (loss) per share from continuing operations |  | $ | 0.36 |  |  | $ | 0.10 |  |  | $ | (0.15 | ) |  | $ | 0.30 |  |
| Basic earnings per share from discontinued operations |  |  | — |  |  |  | 0.14 |  |  |  | 1.82 |  |  |  | 0.09 |  |
| Basic earnings per share |  | $ | 0.36 |  |  | $ | 0.24 |  |  | $ | 1.67 |  |  | $ | 0.39 |  |
| Diluted earnings (loss) per share from continuing operations |  | $ | 0.34 |  |  | $ | 0.10 |  |  | $ | (0.15 | ) |  | $ | 0.30 |  |
| Diluted earnings per share from discontinued operations |  |  | — |  |  |  | 0.14 |  |  |  | 1.82 |  |  |  | 0.09 |  |
| Diluted earnings per share |  | $ | 0.34 |  |  | $ | 0.24 |  |  | $ | 1.67 |  |  | $ | 0.39 |  |
| Weighted-average shares used in computing per share amounts: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  |  | 106,755 |  |  |  | 105,502 |  |  |  | 106,366 |  |  |  | 105,195 |  |
| Diluted |  |  | 113,513 |  |  |  | 107,135 |  |  |  | 106,366 |  |  |  | 106,332 |  |
| Reconciliation of the denominator used to calculate basic earnings per share and diluted earnings per share: |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Weighted-average shares outstanding |  |  | 106,755 |  |  |  | 105,502 |  |  |  |  |  |  |  | 105,195 |  |
| Dilutive effect of convertible debt |  |  | 5,193 |  |  |  | — |  |  |  |  |  |  |  | — |  |
| Dilutive effect of performance-based stock units, restricted stock units & stock options |  |  | 1,565 |  |  |  | 1,633 |  |  |  |  |  |  |  | 1,137 |  |
| Diluted shares |  |  | 113,513 |  |  |  | 107,135 |  |  |  |  |  |  |  | 106,332 |  |
| SELECTED BALANCE SHEET DATA |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | December 28, 2020 |  |  | December 30, 2019 |  |  |  |  |  |  |  |
| Cash and cash equivalents, including restricted cash |  | $ | 451,565 |  |  | $ | 379,818 |  |  |  |  |  |  |  |  |  |
| Accounts and notes receivable, net |  |  | 381,105 |  |  |  | 503,598 |  |  |  |  |  |  |  |  |  |
| Contract assets |  |  | 273,256 |  |  |  | 254,600 |  |  |  |  |  |  |  |  |  |
| Inventories |  |  | 115,651 |  |  |  | 113,753 |  |  |  |  |  |  |  |  |  |
| Current assets held for sale |  |  | — |  |  |  | 67,572 |  |  |  |  |  |  |  |  |  |
| Total current assets |  |  | 1,248,758 |  |  |  | 1,342,684 |  |  |  |  |  |  |  |  |  |
| Property, plant and equipment, net |  |  | 650,435 |  |  |  | 678,201 |  |  |  |  |  |  |  |  |  |
| Operating lease right of use asset |  |  | 24,340 |  |  |  | 22,173 |  |  |  |  |  |  |  |  |  |
| Non-current assets held for sale |  |  | — |  |  |  | 425,597 |  |  |  |  |  |  |  |  |  |
| Other non-current assets |  |  | 972,411 |  |  |  | 1,092,278 |  |  |  |  |  |  |  |  |  |
| Total assets |  |  | 2,895,944 |  |  |  | 3,560,933 |  |  |  |  |  |  |  |  |  |
| Short-term debt, including current portion of long-term debt |  | $ | — |  |  | $ | 249,975 |  |  |  |  |  |  |  |  |  |
| Accounts payable |  |  | 327,102 |  |  |  | 329,866 |  |  |  |  |  |  |  |  |  |
| Current liabilities held for sale |  |  | — |  |  |  | 185,391 |  |  |  |  |  |  |  |  |  |
| Total current liabilities |  |  | 518,046 |  |  |  | 946,666 |  |  |  |  |  |  |  |  |  |
| Debt, net of discount |  |  | 842,853 |  |  |  | 1,225,962 |  |  |  |  |  |  |  |  |  |
| Non-current liabilities held for sale |  |  | — |  |  |  | 1,530 |  |  |  |  |  |  |  |  |  |
| Total long-term liabilities |  |  | 933,889 |  |  |  | 1,335,230 |  |  |  |  |  |  |  |  |  |
| Total equity |  |  | 1,444,009 |  |  |  | 1,279,037 |  |  |  |  |  |  |  |  |  |
| Total liabilities and equity |  |  | 2,895,944 |  |  |  | 3,560,933 |  |  |  |  |  |  |  |  |  |

[0001193125-21-027322:8k_2_02:53]
| SUPPLEMENTAL DATA |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | Fourth Quarter |  |  | Full Year |  |
|  |  | 2020 |  |  | 2019 |  |  | 2020 |  |  | 2019 |  |
| Gross margin |  |  | 16.8 | % |  |  | 18.7 | % |  |  | 17.1 | % |  |  | 17.7 | % |
| Operating margin |  |  | 5.6 | % |  |  | 5.5 | % |  |  | 1.3 | % |  |  | 5.1 | % |
| Stock-based Compensation: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | Fourth Quarter |  |  |  |  |  |  |  |
|  |  | 2020 |  |  | 2019 |  |  |  |  |  |  |  |
| Amount included in: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cost of goods sold |  | $ | 1,246 |  |  | $ | 938 |  |  |  |  |  |  |  |  |  |
| Selling and marketing |  |  | 620 |  |  |  | 479 |  |  |  |  |  |  |  |  |  |
| General and administrative |  |  | 2,211 |  |  |  | 3,147 |  |  |  |  |  |  |  |  |  |
| Research and development |  |  | 35 |  |  |  | 62 |  |  |  |  |  |  |  |  |  |
| Total stock-based compensation expense |  | $ | 4,112 |  |  | $ | 4,626 |  |  |  |  |  |  |  |  |  |
| Operating Segment Data: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | Fourth Quarter |  |  |  |  |  |  |  |
|  |  | 2020 |  |  | 2019 |  |  |  |  |  |  |  |
| Net sales: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| PCB |  | $ | 475,614 |  |  | $ | 477,799 |  |  |  |  |  |  |  |  |  |
| RF&S |  |  | 11,382 |  |  |  | 10,591 |  |  |  |  |  |  |  |  |  |
| E-M Solutions |  |  | 36,806 |  |  |  | 47,325 |  |  |  |  |  |  |  |  |  |
| Total net sales |  | $ | 523,802 |  |  | $ | 535,715 |  |  |  |  |  |  |  |  |  |
| Operating segment income: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| PCB |  | $ | 62,621 |  |  | $ | 69,184 |  |  |  |  |  |  |  |  |  |
| RF&S |  |  | 3,209 |  |  |  | 3,552 |  |  |  |  |  |  |  |  |  |
| E-M Solutions |  |  | 41 |  |  |  | 1,841 |  |  |  |  |  |  |  |  |  |
| Corporate |  |  | (25,732 | ) |  |  | (34,373 | ) |  |  |  |  |  |  |  |  |
| Total operating segment income |  |  | 40,139 |  |  |  | 40,204 |  |  |  |  |  |  |  |  |  |
| Amortization of definite-lived intangibles |  |  | (10,973 | ) |  |  | (10,814 | ) |  |  |  |  |  |  |  |  |
| Total operating income |  |  | 29,166 |  |  |  | 29,390 |  |  |  |  |  |  |  |  |  |
| Total other expense |  |  | (16,453 | ) |  |  | (21,717 | ) |  |  |  |  |  |  |  |  |
| Income from continuing operations before income taxes |  | $ | 12,713 |  |  | $ | 7,673 |  |  |  |  |  |  |  |  |  |
| RECONCILIATIONS1 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | Fourth Quarter |  |  | Full Year |  |
|  |  | 2020 |  |  | 2019 |  |  | 2020 |  |  | 2019 |  |
| Non-GAAP gross profit reconciliation2: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| GAAP gross profit from continuing operations |  | $ | 87,973 |  |  | $ | 100,245 |  |  | $ | 359,023 |  |  | $ | 377,177 |  |
| Add back item: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of definite-lived intangibles |  |  | 1,384 |  |  |  | 1,283 |  |  |  | 5,535 |  |  |  | 4,822 |  |
| Accelerated depreciation |  |  | 899 |  |  |  | — |  |  |  | 5,835 |  |  |  | — |  |
| Stock-based compensation |  |  | 1,246 |  |  |  | 938 |  |  |  | 3,889 |  |  |  | 3,148 |  |
| Non-GAAP gross profit |  | $ | 91,502 |  |  | $ | 102,466 |  |  | $ | 374,282 |  |  | $ | 385,147 |  |
| Non-GAAP gross margin |  |  | 17.5 | % |  |  | 19.1 | % |  |  | 17.8 | % |  |  | 18.1 | % |
| Non-GAAP operating income reconciliation3: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| GAAP operating income from continuing operations |  | $ | 29,166 |  |  | $ | 29,390 |  |  | $ | 28,092 |  |  | $ | 109,629 |  |
| Add back items: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of definite-lived intangibles |  |  | 10,973 |  |  |  | 10,814 |  |  |  | 44,373 |  |  |  | 50,598 |  |
| Accelerated depreciation |  |  | 1,057 |  |  |  | — |  |  |  | 6,751 |  |  |  | — |  |
| Stock-based compensation |  |  | 4,112 |  |  |  | 4,626 |  |  |  | 16,073 |  |  |  | 16,816 |  |
| (Gain) on sale of assets |  |  | (97 | ) |  |  | (66 | ) |  |  | (97 | ) |  |  | (66 | ) |
| Impairments, restructuring, acquisition-related, and other charges |  |  | 2,098 |  |  |  | 6,521 |  |  |  | 86,237 |  |  |  | 12,282 |  |
| Non-GAAP operating income |  | $ | 47,309 |  |  | $ | 51,285 |  |  | $ | 181,429 |  |  | $ | 189,259 |  |
| Non-GAAP operating margin |  |  | 9.0 | % |  |  | 9.6 | % |  |  | 8.6 | % |  |  | 8.9 | % |
| Non-GAAP net income and EPS reconciliation4: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| GAAP net income (loss) from continuing operations |  | $ | 38,960 |  |  | $ | 10,797 |  |  | $ | (16,386 | ) |  | $ | 31,921 |  |
| Add back items: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of definite-lived intangibles |  |  | 10,973 |  |  |  | 10,814 |  |  |  | 44,373 |  |  |  | 50,598 |  |
| Accelerated depreciation |  |  | 1,057 |  |  |  | — |  |  |  | 6,751 |  |  |  | — |  |
| Stock-based compensation |  |  | 4,112 |  |  |  | 4,626 |  |  |  | 16,073 |  |  |  | 16,816 |  |
| Non-cash interest expense |  |  | 2,962 |  |  |  | 3,501 |  |  |  | 17,451 |  |  |  | 14,288 |  |
| (Gain) on sale of assets |  |  | (119 | ) |  |  | (186 | ) |  |  | (825 | ) |  |  | (3,743 | ) |
| Impairments, restructuring, acquisition-related, and other charges |  |  | 2,098 |  |  |  | 6,521 |  |  |  | 86,237 |  |  |  | 12,282 |  |
| Income taxes5 |  |  | (19,800 | ) |  |  | (8,610 | ) |  |  | (36,988 | ) |  |  | (15,046 | ) |
| Non-GAAP net income |  | $ | 40,243 |  |  | $ | 27,463 |  |  | $ | 116,686 |  |  | $ | 107,116 |  |
| Non-GAAP earnings per diluted share |  | $ | 0.37 |  |  | $ | 0.26 |  |  | $ | 1.10 |  |  | $ | 1.01 |  |
| Non-GAAP diluted number of shares: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Diluted shares |  |  | 113,513 |  |  |  | 107,135 |  |  |  | 106,366 |  |  |  | 106,332 |  |
| Dilutive effect of convertible debt |  |  | (5,193 | ) |  |  | — |  |  |  | — |  |  |  | — |  |
| Non-GAAP diluted number of shares |  |  | 108,320 |  |  |  | 107,135 |  |  |  | 106,366 |  |  |  | 106,332 |  |
| Adjusted EBITDA reconciliation6: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| GAAP net income (loss) from continuing operations |  | $ | 38,960 |  |  | $ | 10,797 |  |  | $ | (16,386 | ) |  | $ | 31,921 |  |
| Add back items: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Income tax (benefit) provision |  |  | (26,247 | ) |  |  | (3,124 | ) |  |  | (29,891 | ) |  |  | 2,405 |  |
| Interest expense |  |  | 14,599 |  |  |  | 19,976 |  |  |  | 73,156 |  |  |  | 82,087 |  |
| Amortization of definite-lived intangibles |  |  | 10,973 |  |  |  | 10,814 |  |  |  | 44,373 |  |  |  | 50,598 |  |
| Depreciation expense |  |  | 23,775 |  |  |  | 23,413 |  |  |  | 99,572 |  |  |  | 93,370 |  |
| Stock-based compensation |  |  | 4,112 |  |  |  | 4,626 |  |  |  | 16,073 |  |  |  | 16,816 |  |
| (Gain) on sale of assets |  |  | (119 | ) |  |  | (186 | ) |  |  | (825 | ) |  |  | (3,743 | ) |
| Impairments, restructuring, acquisition-related, and other charges |  |  | 2,098 |  |  |  | 6,521 |  |  |  | 86,237 |  |  |  | 12,282 |  |
| Adjusted EBITDA |  | $ | 68,151 |  |  | $ | 72,837 |  |  | $ | 272,309 |  |  | $ | 285,736 |  |
| Adjusted EBITDA margin |  |  | 13.0 | % |  |  | 13.6 | % |  |  | 12.9 | % |  |  | 13.4 | % |
| Free cash flow reconciliation, including Mobility: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Operating cash flow |  | $ | 55,490 |  |  | $ | 130,148 |  |  | $ | 287,176 |  |  | $ | 311,937 |  |
| Capital expenditures, net |  |  | (18,663 | ) |  |  | (46,982 | ) |  |  | (102,551 | ) |  |  | (135,972 | ) |
| Free cash flow |  | $ | 36,827 |  |  | $ | 83,166 |  |  | $ | 184,625 |  |  | $ | 175,965 |  |

[0001193125-21-027322:8k_2_02:54]
| 1 | This information provides a reconciliation of non-GAAP gross profit, non-GAAP operating income, non-GAAP net income, non-GAAP EPS, and adjusted EBITDA to the financial information in our consolidated condensed statements of operations. |

[0001193125-21-027322:8k_2_02:55]
| 2 | Non-GAAP gross profit and gross margin measures exclude amortization of intangibles, accelerated depreciation due to restructuring of two E-M Solutions plants, and stock-based compensation expense. |

[0001193125-21-027322:8k_2_02:56]
| 3 | Non-GAAP operating income and operating margin measures exclude amortization of intangibles, accelerated depreciation due to restructuring of two E-M Solutions plants, stock-based compensation expense, gain on sale of assets, impairment of goodwill, acquisition-related costs, restructuring and other charges. |

[0001193125-21-027322:8k_2_02:57]
| 4 | This information provides non-GAAP net income and non-GAAP EPS, which are non-GAAP financial measures. Management believes that both measures — which add back amortization of intangibles, accelerated depreciation due to restructuring of two E-M Solutions plants, stock-based compensation expense, non-cash interest expense on debt (before consideration of capitalized interest), gain on sale of assets, impairment of goodwill, acquisition-related costs, restructuring and other charges as well as the associated tax impact of these charges and discrete tax items — provide additional useful information to investors regarding the Company’s ongoing financial condition and results of operations. |

[0001193125-21-027322:8k_2_02:58]
| 5 | Income tax adjustments reflect the difference between income taxes based on a non-GAAP tax rate and a forecasted annual GAAP tax rate. |

[0001193125-21-027322:8k_2_02:59]
| 6 | Adjusted EBITDA is defined as earnings before interest expense, income taxes, depreciation, amortization of intangibles, stock-based compensation expense, gain on sale of assets, impairment of goodwill, acquisition-related costs, restructuring and other charges. We present adjusted EBITDA to enhance the understanding of our operating results, and it is a key measure we use to evaluate our operations. In addition, we provide our adjusted EBITDA because we believe that investors and securities analysts will find adjusted EBITDA to be a useful measure for evaluating our operating performance and comparing our operating performance with that of similar companies that have different capital structures and for evaluating our ability to meet our future debt service, capital expenditures, and working capital requirements. However, adjusted EBITDA should not be considered as an alternative to cash flows from operating activities as a measure of liquidity or as an alternative to net income as a measure of operating results in accordance with accounting principles generally accepted in the United States of America. |

[0001193125-21-027322:8k_2_02:60]
MERP Tables

[0001193125-21-027322:8k_2_02:61]
TTM Consolidated

[0001193125-21-027322:8k_2_02:62]
| End Markets |  | 1Q-19 |  |  | 2Q-19 |  |  | 3Q-19 |  |  | 4Q-19 |  |  | FY 2019 |  |  | 1Q-20 |  |  | 2Q-20 |  |  | 3Q-20 |  |  | 4Q-20 |  |  | FY 2020 |  |
| Aerospace/Defense |  |  | 27 | % |  |  | 28 | % |  |  | 24 | % |  |  | 26 | % |  |  | 26 | % |  |  | 30 | % |  |  | 31 | % |  |  | 36 | % |  |  | 36 | % |  |  | 33 | % |
| Automotive |  |  | 17 | % |  |  | 16 | % |  |  | 17 | % |  |  | 14 | % |  |  | 16 | % |  |  | 12 | % |  |  | 12 | % |  |  | 14 | % |  |  | 21 | % |  |  | 14 | % |
| Cellular Phones |  |  | 7 | % |  |  | 6 | % |  |  | 19 | % |  |  | 16 | % |  |  | 13 | % |  |  | 11 | % |  |  | 3 | % |  |  | 0 | % |  |  | 0 | % |  |  | 4 | % |
| Computing/Storage/Periph |  |  | 13 | % |  |  | 15 | % |  |  | 12 | % |  |  | 14 | % |  |  | 13 | % |  |  | 14 | % |  |  | 13 | % |  |  | 12 | % |  |  | 13 | % |  |  | 13 | % |
| Medical/Industrial/Inst |  |  | 15 | % |  |  | 15 | % |  |  | 13 | % |  |  | 13 | % |  |  | 14 | % |  |  | 16 | % |  |  | 20 | % |  |  | 19 | % |  |  | 15 | % |  |  | 17 | % |
| Networking/Communications |  |  | 18 | % |  |  | 17 | % |  |  | 13 | % |  |  | 15 | % |  |  | 15 | % |  |  | 14 | % |  |  | 19 | % |  |  | 18 | % |  |  | 15 | % |  |  | 17 | % |
| Other |  |  | 3 | % |  |  | 3 | % |  |  | 2 | % |  |  | 2 | % |  |  | 3 | % |  |  | 3 | % |  |  | 2 | % |  |  | 1 | % |  |  | 0 | % |  |  | 2 | % |
| Mobility Business Unit |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| End Markets |  | 1Q-19 |  |  | 2Q-19 |  |  | 3Q-19 |  |  | 4Q-19 |  |  | FY 2019 |  |  | 1Q-20 |  |  | 2Q-20 |  |  | 3Q-20 |  |  | 4Q-20 |  |  | FY 2020 |  |
| Aerospace/Defense |  |  | 0 | % |  |  | 0 | % |  |  | 0 | % |  |  | 0 | % |  |  | 0 | % |  |  | 0 | % |  |  | 0 | % |  |  | 0 | % |  |  | 0 | % |  |  | 0 | % |
| Automotive |  |  | 5 | % |  |  | 6 | % |  |  | 3 | % |  |  | 2 | % |  |  | 4 | % |  |  | 3 | % |  |  | 5 | % |  |  | 0 | % |  |  | 0 | % |  |  | 3 | % |
| Cellular Phones |  |  | 48 | % |  |  | 41 | % |  |  | 73 | % |  |  | 65 | % |  |  | 60 | % |  |  | 57 | % |  |  | 54 | % |  |  | 0 | % |  |  | 0 | % |  |  | 56 | % |
| Computing/Storage/Periph |  |  | 28 | % |  |  | 36 | % |  |  | 14 | % |  |  | 19 | % |  |  | 22 | % |  |  | 22 | % |  |  | 25 | % |  |  | 0 | % |  |  | 0 | % |  |  | 23 | % |
| Medical/Industrial/Inst |  |  | 7 | % |  |  | 5 | % |  |  | 2 | % |  |  | 3 | % |  |  | 4 | % |  |  | 4 | % |  |  | 4 | % |  |  | 0 | % |  |  | 0 | % |  |  | 4 | % |
| Networking/Communications |  |  | 5 | % |  |  | 5 | % |  |  | 4 | % |  |  | 6 | % |  |  | 5 | % |  |  | 5 | % |  |  | 5 | % |  |  | 0 | % |  |  | 0 | % |  |  | 5 | % |
| Other |  |  | 7 | % |  |  | 7 | % |  |  | 4 | % |  |  | 5 | % |  |  | 5 | % |  |  | 9 | % |  |  | 7 | % |  |  | 0 | % |  |  | 0 | % |  |  | 9 | % |
| TTM excluding Mobility |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| End Markets |  | 1Q-19 |  |  | 2Q-19 |  |  | 3Q-19 |  |  | 4Q-19 |  |  | FY 2019 |  |  | 1Q-20 |  |  | 2Q-20 |  |  | 3Q-20 |  |  | 4Q-20 |  |  | FY 2020 |  |
| Aerospace/Defense |  |  | 31 | % |  |  | 33 | % |  |  | 31 | % |  |  | 35 | % |  |  | 33 | % |  |  | 37 | % |  |  | 33 | % |  |  | 36 | % |  |  | 36 | % |  |  | 36 | % |
| Automotive |  |  | 19 | % |  |  | 18 | % |  |  | 21 | % |  |  | 17 | % |  |  | 19 | % |  |  | 14 | % |  |  | 12 | % |  |  | 14 | % |  |  | 21 | % |  |  | 15 | % |
| Cellular Phones |  |  | 0 | % |  |  | 0 | % |  |  | 1 | % |  |  | 0 | % |  |  | 0 | % |  |  | 0 | % |  |  | 0 | % |  |  | 0 | % |  |  | 0 | % |  |  | 0 | % |
| Computing/Storage/Periph |  |  | 11 | % |  |  | 11 | % |  |  | 11 | % |  |  | 12 | % |  |  | 11 | % |  |  | 12 | % |  |  | 13 | % |  |  | 12 | % |  |  | 13 | % |  |  | 12 | % |
| Medical/Industrial/Inst |  |  | 17 | % |  |  | 17 | % |  |  | 17 | % |  |  | 17 | % |  |  | 17 | % |  |  | 19 | % |  |  | 21 | % |  |  | 19 | % |  |  | 15 | % |  |  | 18 | % |
| Networking/Communications |  |  | 20 | % |  |  | 19 | % |  |  | 17 | % |  |  | 18 | % |  |  | 18 | % |  |  | 17 | % |  |  | 20 | % |  |  | 18 | % |  |  | 15 | % |  |  | 18 | % |
| Other |  |  | 2 | % |  |  | 2 | % |  |  | 2 | % |  |  | 1 | % |  |  | 2 | % |  |  | 1 | % |  |  | 1 | % |  |  | 1 | % |  |  | 0 | % |  |  | 1 | % |
| SZ + SH-EMS |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| End Markets |  | 1Q-19 |  |  | 2Q-19 |  |  | 3Q-19 |  |  | 4Q-19 |  |  | FY 2019 |  |  | 1Q-20 |  |  | 2Q-20 |  |  | 3Q-20 |  |  | 4Q-20 |  |  | FY 2020 |  |
| Aerospace/Defense |  |  | 0 | % |  |  | 1 | % |  |  | 0 | % |  |  | 0 | % |  |  | 0 | % |  |  | 0 | % |  |  | 0 | % |  |  | 0 | % |  |  | 3 | % |  |  | 1 | % |
| Automotive |  |  | 56 | % |  |  | 58 | % |  |  | 74 | % |  |  | 59 | % |  |  | 63 | % |  |  | 49 | % |  |  | 54 | % |  |  | 49 | % |  |  | 86 | % |  |  | 61 | % |
| Cellular Phones |  |  | 0 | % |  |  | 0 | % |  |  | 0 | % |  |  | 0 | % |  |  | 0 | % |  |  | 0 | % |  |  | 0 | % |  |  | 0 | % |  |  | 0 | % |  |  | 0 | % |
| Computing/Storage/Periph |  |  | 0 | % |  |  | 0 | % |  |  | 0 | % |  |  | 0 | % |  |  | 0 | % |  |  | 0 | % |  |  | 0 | % |  |  | 0 | % |  |  | 0 | % |  |  | 0 | % |
| Medical/Industrial/Inst |  |  | 22 | % |  |  | 23 | % |  |  | 11 | % |  |  | 19 | % |  |  | 18 | % |  |  | 23 | % |  |  | 14 | % |  |  | 14 | % |  |  | 2 | % |  |  | 12 | % |
| Networking/Communications |  |  | 21 | % |  |  | 18 | % |  |  | 16 | % |  |  | 22 | % |  |  | 19 | % |  |  | 30 | % |  |  | 35 | % |  |  | 44 | % |  |  | 10 | % |  |  | 29 | % |
| Other |  |  | 1 | % |  |  | 0 | % |  |  | -1 | % |  |  | 0 | % |  |  | 0 | % |  |  | -2 | % |  |  | -3 | % |  |  | -7 | % |  |  | -1 | % |  |  | -3 | % |
| TTM, excluding Mobility, SZ & SH E-MS |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| End Markets |  | 1Q-19 |  |  | 2Q-19 |  |  | 3Q-19 |  |  | 4Q-19 |  |  | FY 2019 |  |  | 1Q-20 |  |  | 2Q-20 |  |  | 3Q-20 |  |  | 4Q-20 |  |  | FY 2020 |  |
| Aerospace/Defense |  |  | 33 | % |  |  | 36 | % |  |  | 36 | % |  |  | 37 | % |  |  | 35 | % |  |  | 38 | % |  |  | 34 | % |  |  | 37 | % |  |  | 38 | % |  |  | 37 | % |
| Automotive |  |  | 17 | % |  |  | 15 | % |  |  | 15 | % |  |  | 15 | % |  |  | 15 | % |  |  | 13 | % |  |  | 11 | % |  |  | 13 | % |  |  | 17 | % |  |  | 13 | % |
| Cellular Phones |  |  | 0 | % |  |  | -1 | % |  |  | 1 | % |  |  | 0 | % |  |  | 0 | % |  |  | 1 | % |  |  | 0 | % |  |  | 0 | % |  |  | 0 | % |  |  | 0 | % |
| Computing/Storage/Periph |  |  | 12 | % |  |  | 12 | % |  |  | 12 | % |  |  | 13 | % |  |  | 12 | % |  |  | 12 | % |  |  | 13 | % |  |  | 13 | % |  |  | 13 | % |  |  | 13 | % |
| Medical/Industrial/Inst |  |  | 16 | % |  |  | 17 | % |  |  | 18 | % |  |  | 17 | % |  |  | 17 | % |  |  | 19 | % |  |  | 21 | % |  |  | 19 | % |  |  | 16 | % |  |  | 19 | % |
| Networking/Communications |  |  | 20 | % |  |  | 19 | % |  |  | 16 | % |  |  | 17 | % |  |  | 18 | % |  |  | 16 | % |  |  | 19 | % |  |  | 17 | % |  |  | 16 | % |  |  | 17 | % |
| Other |  |  | 2 | % |  |  | 2 | % |  |  | 2 | % |  |  | 1 | % |  |  | 3 | % |  |  | 1 | % |  |  | 2 | % |  |  | 1 | % |  |  | 0 | % |  |  | 1 | % |

[0001193125-21-027322:8k_2_02:63]
Proforma Tables

[0001193125-21-027322:8k_2_02:64]
Select Non-GAAP income statement data:

[0001193125-21-027322:8k_2_02:65]
| TTM Consolidated |  | Q1-19 |  |  | Q2-19 |  |  | Q3-19 |  |  | Q4-19 |  |  | FY 2019 |  |  | Q1-20 |  |  | Q2-20 |  |  | Q3-20 |  |  | Q4-20 |  |  | FY 2020 |  |
| Sales |  |  | 620.2 |  |  |  | 633.0 |  |  |  | 716.8 |  |  |  | 719.3 |  |  |  | 2,689.3 |  |  |  | 610.8 |  |  |  | 601.1 |  |  |  | 513.6 |  |  |  | 523.8 |  |  |  | 2,249.3 |  |
| Gross Profit |  |  | 90.6 |  |  |  | 86.4 |  |  |  | 106.0 |  |  |  | 126.8 |  |  |  | 409.7 |  |  |  | 88.3 |  |  |  | 107.2 |  |  |  | 94.4 |  |  |  | 91.5 |  |  |  | 381.4 |  |
| Gross Margin |  |  | 14.6 | % |  |  | 13.6 | % |  |  | 14.8 | % |  |  | 17.6 | % |  |  | 15.2 | % |  |  | 14.5 | % |  |  | 17.8 | % |  |  | 18.4 | % |  |  | 17.5 | % |  |  | 17.0 | % |
| Op Income |  |  | 40.5 |  |  |  | 37.2 |  |  |  | 54.0 |  |  |  | 72.3 |  |  |  | 204.0 |  |  |  | 35.7 |  |  |  | 54.7 |  |  |  | 46.9 |  |  |  | 47.3 |  |  |  | 184.6 |  |
| Operating Margin |  |  | 6.5 | % |  |  | 5.9 | % |  |  | 7.5 | % |  |  | 10.1 | % |  |  | 7.6 | % |  |  | 5.8 | % |  |  | 9.1 | % |  |  | 9.1 | % |  |  | 9.0 | % |  |  | 8.2 | % |
| EBITDA |  |  | 78.5 |  |  |  | 82.9 |  |  |  | 103.5 |  |  |  | 111.3 |  |  |  | 376.2 |  |  |  | 82.1 |  |  |  | 80.3 |  |  |  | 67.2 |  |  |  | 68.2 |  |  |  | 297.8 |  |
| EBITDA% |  |  | 12.7 | % |  |  | 13.1 | % |  |  | 14.4 | % |  |  | 15.5 | % |  |  | 14.0 | % |  |  | 13.4 | % |  |  | 13.4 | % |  |  | 13.1 | % |  |  | 13.0 | % |  |  | 13.2 | % |
| Mobility Proforma |  | Q1-19 |  |  | Q2-19 |  |  | Q3-19 |  |  | Q4-19 |  |  | FY 2019 |  |  | Q1-20 |  |  | Q2-20 |  |  | Q3-20 |  |  | Q4-20 |  |  | FY 2020 |  |
| Sales |  |  | 83.8 |  |  |  | 106.1 |  |  |  | 182.6 |  |  |  | 183.5 |  |  |  | 556.0 |  |  |  | 113.2 |  |  |  | 30.8 |  |  |  | — |  |  |  | — |  |  |  | 144.0 |  |
| Gross Profit |  |  | (10.1 | ) |  |  | (8.2 | ) |  |  | 18.6 |  |  |  | 24.3 |  |  |  | 24.5 |  |  |  | 4.7 |  |  |  | 2.4 |  |  |  | — |  |  |  | — |  |  |  | 7.1 |  |
| Gross Margin |  |  | -12.1 | % |  |  | -7.8 | % |  |  | 10.2 | % |  |  | 13.2 | % |  |  | 4.4 | % |  |  | 4.2 | % |  |  | 7.8 | % |  |  | — |  |  |  | — |  |  |  | 5.0 | % |
| Op Income |  |  | (11.9 | ) |  |  | (10.3 | ) |  |  | 16.0 |  |  |  | 21.0 |  |  |  | 14.8 |  |  |  | 2.1 |  |  |  | 1.1 |  |  |  | — |  |  |  | — |  |  |  | 3.2 |  |
| Operating Margin |  |  | -14.2 | % |  |  | -9.7 | % |  |  | 8.8 | % |  |  | 11.4 | % |  |  | 2.7 | % |  |  | 1.9 | % |  |  | 3.6 | % |  |  | — |  |  |  | — |  |  |  | 2.2 | % |
| EBITDA |  |  | 5.9 |  |  |  | 9.2 |  |  |  | 36.9 |  |  |  | 38.5 |  |  |  | 90.5 |  |  |  | 21.9 |  |  |  | 3.5 |  |  |  | — |  |  |  | — |  |  |  | 25.4 |  |
| EBITDA% |  |  | 7.0 | % |  |  | 8.7 | % |  |  | 20.2 | % |  |  | 21.0 | % |  |  | 16.3 | % |  |  | 19.3 | % |  |  | 11.4 | % |  |  | — |  |  |  | — |  |  |  | 17.6 | % |
| TTM Proforma Excluding Mobility |  | Q1-19 |  |  | Q2-19 |  |  | Q3-19 |  |  | Q4-19 |  |  | FY 2019 |  |  | Q1-20 |  |  | Q2-20 |  |  | Q3-20 |  |  | Q4-20 |  |  | FY 2020 |  |
| Sales |  |  | 536.4 |  |  |  | 526.9 |  |  |  | 534.2 |  |  |  | 535.8 |  |  |  | 2,133.3 |  |  |  | 497.6 |  |  |  | 570.3 |  |  |  | 513.6 |  |  |  | 523.8 |  |  |  | 2,105.3 |  |
| Gross Profit |  |  | 100.7 |  |  |  | 94.6 |  |  |  | 87.4 |  |  |  | 102.5 |  |  |  | 385.2 |  |  |  | 83.6 |  |  |  | 104.8 |  |  |  | 94.4 |  |  |  | 91.5 |  |  |  | 374.3 |  |
| Gross Margin |  |  | 18.8 | % |  |  | 18.0 | % |  |  | 16.4 | % |  |  | 19.1 | % |  |  | 18.1 | % |  |  | 16.8 | % |  |  | 18.4 | % |  |  | 18.4 | % |  |  | 17.5 | % |  |  | 17.8 | % |
| Op Income |  |  | 52.4 |  |  |  | 47.5 |  |  |  | 38.0 |  |  |  | 51.3 |  |  |  | 189.2 |  |  |  | 33.6 |  |  |  | 53.6 |  |  |  | 46.9 |  |  |  | 47.3 |  |  |  | 181.4 |  |
| Operating Margin |  |  | 9.8 | % |  |  | 9.0 | % |  |  | 7.1 | % |  |  | 9.6 | % |  |  | 8.9 | % |  |  | 6.8 | % |  |  | 9.4 | % |  |  | 9.1 | % |  |  | 9.0 | % |  |  | 8.6 | % |
| EBITDA |  |  | 72.6 |  |  |  | 73.7 |  |  |  | 66.6 |  |  |  | 72.8 |  |  |  | 285.7 |  |  |  | 60.2 |  |  |  | 76.8 |  |  |  | 67.2 |  |  |  | 68.2 |  |  |  | 272.4 |  |
| EBITDA% |  |  | 13.5 | % |  |  | 14.0 | % |  |  | 12.5 | % |  |  | 13.6 | % |  |  | 13.4 | % |  |  | 12.1 | % |  |  | 13.5 | % |  |  | 13.1 | % |  |  | 13.0 | % |  |  | 12.9 | % |
| SZ + SH-EMS Proforma |  | Q1-19 |  |  | Q2-19 |  |  | Q3-19 |  |  | Q4-19 |  |  | FY 2019 |  |  | Q1-20 |  |  | Q2-20 |  |  | Q3-20 |  |  | Q4-20 |  |  | FY 2020 |  |
| Sales |  |  | 36.0 |  |  |  | 40.9 |  |  |  | 54.5 |  |  |  | 29.8 |  |  |  | 161.2 |  |  |  | 14.2 |  |  |  | 21.4 |  |  |  | 20.5 |  |  |  | 23.7 |  |  |  | 79.8 |  |
| Gross Profit |  |  | 3.0 |  |  |  | 3.4 |  |  |  | 5.2 |  |  |  | 2.3 |  |  |  | 13.9 |  |  |  | (2.4 | ) |  |  | (0.3 | ) |  |  | 3.4 |  |  |  | 3.2 |  |  |  | 3.9 |  |
| Gross Margin |  |  | 8.3 | % |  |  | 8.3 | % |  |  | 9.5 | % |  |  | 7.7 | % |  |  | 8.6 | % |  |  | -16.7 | % |  |  | -1.4 | % |  |  | 16.6 | % |  |  | 13.5 | % |  |  | 4.9 | % |
| Op Income |  |  | 2.0 |  |  |  | 1.2 |  |  |  | 4.3 |  |  |  | 2.0 |  |  |  | 9.5 |  |  |  | (3.8 | ) |  |  | (0.8 | ) |  |  | 2.3 |  |  |  | 2.7 |  |  |  | 0.4 |  |
| Operating Margin |  |  | 5.6 | % |  |  | 2.9 | % |  |  | 7.9 | % |  |  | 6.7 | % |  |  | 5.9 | % |  |  | -26.8 | % |  |  | -3.8 | % |  |  | 11.3 | % |  |  | 11.4 | % |  |  | 0.5 | % |
| EBITDA |  |  | 2.5 |  |  |  | 3.1 |  |  |  | 7.1 |  |  |  | 2.0 |  |  |  | 14.7 |  |  |  | (3.6 | ) |  |  | 0.1 |  |  |  | 2.6 |  |  |  | 3.1 |  |  |  | 2.2 |  |
| EBITDA% |  |  | 6.9 | % |  |  | 7.6 | % |  |  | 13.0 | % |  |  | 6.7 | % |  |  | 9.1 | % |  |  | -25.4 | % |  |  | 0.4 | % |  |  | 12.9 | % |  |  | 13.1 | % |  |  | 2.8 | % |
| TTM Proforma Excluding Mobility, SZ & SH-EMS |  | Q1-19 |  |  | Q2-19 |  |  | Q3-19 |  |  | Q4-19 |  |  | FY 2019 |  |  | Q1-20 |  |  | Q2-20 |  |  | Q3-20 |  |  | Q4-20 |  |  | FY 2020 |  |
| Sales |  |  | 500.4 |  |  |  | 486.0 |  |  |  | 479.7 |  |  |  | 506.0 |  |  |  | 1,972.1 |  |  |  | 483.4 |  |  |  | 548.9 |  |  |  | 493.1 |  |  |  | 500.1 |  |  |  | 2,025.5 |  |
| Gross Profit |  |  | 97.7 |  |  |  | 91.2 |  |  |  | 82.2 |  |  |  | 100.2 |  |  |  | 371.3 |  |  |  | 86.0 |  |  |  | 105.1 |  |  |  | 91.0 |  |  |  | 88.3 |  |  |  | 370.4 |  |
| Gross Margin |  |  | 19.5 | % |  |  | 18.8 | % |  |  | 17.1 | % |  |  | 19.8 | % |  |  | 18.8 | % |  |  | 17.8 | % |  |  | 19.1 | % |  |  | 18.5 | % |  |  | 17.7 | % |  |  | 18.3 | % |
| Op Income |  |  | 50.4 |  |  |  | 46.2 |  |  |  | 33.7 |  |  |  | 49.3 |  |  |  | 179.6 |  |  |  | 37.7 |  |  |  | 54.4 |  |  |  | 44.6 |  |  |  | 44.6 |  |  |  | 181.3 |  |
| OM |  |  | 10.1 | % |  |  | 9.5 | % |  |  | 7.0 | % |  |  | 9.7 | % |  |  | 9.1 | % |  |  | 7.8 | % |  |  | 9.9 | % |  |  | 9.0 | % |  |  | 8.9 | % |  |  | 8.9 | % |
| EBITDA |  |  | 70.1 |  |  |  | 70.6 |  |  |  | 59.5 |  |  |  | 70.8 |  |  |  | 271.0 |  |  |  | 63.8 |  |  |  | 76.7 |  |  |  | 64.6 |  |  |  | 65.1 |  |  |  | 270.2 |  |
| EBITDA% |  |  | 14.0 | % |  |  | 14.5 | % |  |  | 12.4 | % |  |  | 14.0 | % |  |  | 13.7 | % |  |  | 13.2 | % |  |  | 14.0 | % |  |  | 13.1 | % |  |  | 13.0 | % |  |  | 13.3 | % |
