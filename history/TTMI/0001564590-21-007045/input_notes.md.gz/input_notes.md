# TTMI notes — 0001564590-21-007045


## dei:DocumentsIncorporatedByReferenceTextBlock

[0001564590-21-007045:notes:1]
Portions of the registrant’s definitive Proxy Statement for its 2021 Annual Meeting of Stockholders are incorporated by reference into Part III of this report. Such Proxy Statement will be filed with the Securities and Exchange Commission within 120 days after the end of the fiscal year to which this report relates.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureAndSignificantAccountingPoliciesTextBlock

[0001564590-21-007045:notes:2]
| (1) | Nature of Operations and Summary of Significant Accounting Policies |

[0001564590-21-007045:notes:3]
Nature of Operations

[0001564590-21-007045:notes:4]
TTM Technologies, Inc. (the Company or TTM) is a leading global printed circuit board (PCB) manufacturer, focusing on quick-turn and volume production of technologically advanced PCBs and backplane assemblies as well as a global designer and manufacturer of high-frequency radio frequency (RF) and microwave components and assemblies. The Company provides time-to-market and volume production of advanced technology products and offers a one-stop design, engineering and manufacturing solution to customers. This one-stop design, engineering and manufacturing solution allows the Company to align technology developments with the diverse needs of the Company’s customers and to enable them to reduce the time required to develop new products and bring them to market.

[0001564590-21-007045:notes:5]
The Company serves a diversified customer base in various markets throughout the world, including aerospace and defense, computing, automotive components, medical, industrial and instrumentation related products, as well as networking/communications infrastructure products. The Company’s customers include both original equipment manufacturers (OEMs) and electronic manufacturing services (EMS) providers.

[0001564590-21-007045:notes:6]
On January 19, 2020, the Company entered into a definitive equity interests purchase agreement with AKMMeadville Electronics (Xiamen) Co., Ltd (the Purchaser) for the sale of the Company’s following subsidiaries, which was completed on April 17, 2020: Shanghai Kaiser Electronics Co., Ltd. (SKE), Shanghai Meadville Electronics Co., Ltd. (SME), Shanghai Meadville Science & Technology Co., Ltd. (SP) and Guangzhou Meadville Electronics Co., Ltd. (GME) (collectively, the Mobility business unit). Prior to the closing of the sale of the Company’s Mobility business unit, all assets and liabilities attributable to the Mobility business unit have been aggregated under the captions “Current assets held for sale”, “Non-current assets held for sale”, “Current liabilities held for sale” and “Non-current liabilities held for sale”. For all periods presented in the consolidated statements of operations, all sales, costs, expenses, income taxes and gain on sale attributable to the Mobility business unit have been aggregated under the caption “Income (loss) from discontinued operations, net of income taxes”. Prior year results have been recast to conform with the current presentation. See Note 3, Discontinued Operations, for additional information.

[0001564590-21-007045:notes:7]
The Company operates on a 52 or 53 week year ending on the Monday nearest December 31. Fiscal 2020, 2019 and 2018 were 52 weeks ended on December 28, 2020, December 30, 2019 and December 31, 2018, respectively. All references to years relate to fiscal years unless otherwise noted.

[0001564590-21-007045:notes:8]
Reclassifications

[0001564590-21-007045:notes:9]
During the year ended December 28, 2020, the Company’s RF and Specialty Components (RF&S Components) operating segment met the quantitative threshold for separate presentation of a reportable segment. In prior periods, the Company had two reportable segments: PCB and E-M Solutions. The RF&S Components reportable segment was previously aggregated with the PCB reportable segment. As a result, certain prior period amounts have been reclassified to conform with this new presentation.

[0001564590-21-007045:notes:10]
Further, in 2020, the Company began presenting research and development expenses as a separate line item on the consolidated statements of operations to better align with similar presentation made by peers and to provide additional disclosure that is meaningful for investors. The prior year consolidated statements of operations were adjusted to conform with this new presentation. Research and development expense were previously presented within general and administrative expense on the consolidated statements of operations.

[0001564590-21-007045:notes:11]
Use of Estimates

[0001564590-21-007045:notes:12]
The preparation of financial statements in conformity with accounting principles generally accepted in the United States of America (U.S. GAAP) requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities and disclosure of contingent assets and liabilities at the date of the financial statements and the reported amount of revenues and expenses during the reporting period. Such estimates include the sales return reserve; allowance for doubtful accounts; inventory reserve; product warranty liabilities; legal contingencies; income taxes; pension obligations; and fair values of financial instruments. These estimates and assumptions are based on management’s best estimates and judgment. Due to the coronavirus (COVID-19) global pandemic, the global economy and financial markets have been disrupted and there is a significant amount of uncertainty about the length and severity of the consequences caused by the pandemic. The Company has considered information available to it as of the date of issuance of these financial statements and is not aware of any specific events or circumstances that would require an update to its estimates or judgments, or a revision to the carrying value of its assets or liabilities. Management evaluates its estimates and assumptions on an ongoing basis using historical experience and other factors, including the economic environment, which management believes to be reasonable under the circumstances. Management adjusts such estimates and assumptions when facts and circumstances dictate. The actual results we experienced may differ materially and adversely from our estimates. To the extent there are material differences between the estimates and actual results, our future result of operations will be affected.

[0001564590-21-007045:notes:13]
Principles of Consolidation

[0001564590-21-007045:notes:14]
The consolidated financial statements include the accounts of TTM and its subsidiaries. All intercompany accounts and transactions have been eliminated in consolidation.

[0001564590-21-007045:notes:15]
Foreign Currency Translation and Transactions

[0001564590-21-007045:notes:16]
The functional currency of certain of the Company’s subsidiaries is the Chinese Renminbi (RMB). Accordingly, assets and liabilities are translated into U.S. dollars using period-end exchange rates. Sales and expenses are translated at the average exchange rates in effect during the period. The resulting translation gains or losses are recorded as a component of accumulated other comprehensive (loss) income in the consolidated statement of stockholders’ equity and the consolidated statement of comprehensive income. Net losses resulting from foreign currency remeasurements and transactions are included in expenses as a component of other, net in the consolidated statements of operations and totaled $10,475, $467 and $786 for the years ended December 28, 2020, December 30, 2019 and December 31, 2018, respectively.

[0001564590-21-007045:notes:17]
Cash Equivalents

[0001564590-21-007045:notes:18]
The Company considers highly liquid investments with insignificant interest rate risk and original maturities to the Company of three months or less to be cash equivalents.

[0001564590-21-007045:notes:19]
Accounts Receivable and Allowance for Doubtful Accounts

[0001564590-21-007045:notes:20]
Accounts receivable are reflected at estimated net realizable value, do not bear interest and do not generally require collateral. The Company performs credit evaluations of its customers and adjusts credit limits based upon payment history and the customer’s current creditworthiness. The Company maintains an allowance for doubtful accounts based upon a variety of factors. The Company considers both current and forecasted future economic conditions in determining the adequacy of its allowance for doubtful accounts.

[0001564590-21-007045:notes:21]
The Company’s allowance for doubtful accounts was $2,886, $1,929, and $2,750 as of December 28, 2020, December 30, 2019 and December 31, 2018, respectively.

[0001564590-21-007045:notes:22]
Inventories

[0001564590-21-007045:notes:23]
Inventories are stated at the lower of cost (determined on a first-in, first-out and weighted average basis) or net realizable value. Assessments to value the inventory at the lower of the actual cost to purchase and/or manufacture the inventory, or net realizable value of the inventory, are based upon assumptions about future demand and market conditions. As a result of the Company’s assessments, when the net realizable value of inventory is less than the carrying value, the inventory cost is written down to the net realizable value and the write down is recorded as a charge to cost of goods sold.

[0001564590-21-007045:notes:24]
Property, Plant and Equipment, Net

[0001564590-21-007045:notes:25]
Property, plant and equipment are recorded at cost. Depreciation expense is computed using the straight-line method over the estimated useful lives of the assets. Assets recorded under leasehold improvements are amortized using the straight-line method over the lesser of their useful lives or the related lease term. The Company uses the following estimated useful lives:

[0001564590-21-007045:notes:26]
| Land use rights |  | 50-99 years |
| Buildings and improvements |  | 7-50 years |
| Machinery and equipment |  | 3-10 years |
| Furniture and fixtures |  | 3-7 years |

[0001564590-21-007045:notes:27]
Upon retirement or other disposition of property, plant and equipment, the cost and related accumulated depreciation are removed from the accounts. The resulting gain or loss is included in the determination of operating income in the period incurred. Depreciation and amortization expense on property, plant and equipment was $99,572, $93,370, and $91,329 for the years ended December 28, 2020, December 30, 2019 and December 31, 2018, respectively.

[0001564590-21-007045:notes:28]
The Company capitalizes interest on borrowings during the active construction period of major capital projects. Capitalized interest is amortized over the average useful lives of such assets, which primarily consist of buildings and machinery and equipment. The Company capitalized interest costs of $1,783, $1,810 and $1,438 during the years ended December 28, 2020, December 30, 2019 and December 31, 2018, respectively, in connection with various capital projects.

[0001564590-21-007045:notes:29]
Major renewals and betterments are capitalized and depreciated over their estimated useful lives while minor expenditures for maintenance and repairs are included in operating income as incurred.

[0001564590-21-007045:notes:30]
Goodwill

[0001564590-21-007045:notes:31]
Goodwill represents the excess of purchase price of an acquisition over the fair value of net assets acquired. Goodwill is not amortized but instead is assessed for impairment, at a reporting unit level, annually and when events and circumstances warrant an evaluation. Goodwill is allocated to reporting units, which are operating segments or one level below the Company’s operating segments (the component level). Reporting units are determined by the discrete financial information available for the component and whether it is regularly reviewed by segment management. Components are aggregated into a single reporting unit if they share similar economic characteristics. The Company evaluates its goodwill on an annual basis in the fourth quarter or more frequently if it believes indicators of impairment exist. The Company assesses qualitative factors to determine whether it is more likely than not that the fair value of a reporting unit is less than its carrying amount or performs an annual impairment test. When tested quantitatively, the Company compares the fair value of the applicable reporting unit with its carrying value. In making this assessment, management relies on a number of factors, including expected future operating results, business plans, economic projections, anticipated future cash flows, business trends and declines in the Company’s market capitalization. The Company estimates the fair values of its reporting units using a combination of the discounted cash flow (DCF) and market approaches. If the carrying amount of a reporting unit exceeds the reporting unit’s fair value, the amount by which the carrying value exceeds the fair value is recognized as an impairment loss. See Note 5 for further details.

[0001564590-21-007045:notes:32]
During the fourth quarter of 2020, the Company changed the date of its annual impairment test of goodwill from year-end to the first day of fiscal November to provide for additional time to complete the required impairment testing. This change does not represent a material change to the Company’s method of applying an accounting principle. The change in annual impairment test date has been prospectively applied beginning the first day of fiscal November 2020.

[0001564590-21-007045:notes:33]
Intangible Assets

[0001564590-21-007045:notes:34]
Intangible assets include customer relationships and technology, which are being amortized over their estimated useful lives on a straight-line basis. The estimated useful lives of such intangibles range from 5 years to 13 years.

[0001564590-21-007045:notes:35]
Impairment of Long-lived Assets

[0001564590-21-007045:notes:36]
Long-lived tangible assets, including property, plant and equipment, assets held for sale, and definite-lived intangible assets, are reviewed for impairment whenever events or changes in circumstances indicate that the carrying value of the asset or asset groups may not be recoverable. The Company regularly evaluates whether events or circumstances have occurred that indicate possible impairment and relies on a number of factors, including expected future operating results, business plans, economic projections, and anticipated future cash flows. The Company uses an estimate of the future undiscounted net cash flows of the related asset or asset group over the remaining life in measuring whether the assets are recoverable. If the sum of the undiscounted cash flows is less than the carrying amount of the net assets, impairment is measured based on the difference between the net asset’s carrying value and estimated fair value. Fair value is determined through various valuation techniques, including cost-based, market and income approaches as considered necessary.

[0001564590-21-007045:notes:37]
The Company classifies assets to be sold as assets held for sale when (i) Company management has approved and commits to a plan to sell the asset; (ii) the asset is available for immediate sale in its present condition and is ready for sale; (iii) an active program to locate a buyer and other actions required to sell the asset have been initiated; (iv) the sale of the asset is probable; (v) the asset is being actively marketed for sale at a price that is reasonable in relation to its current fair value; and (vi) it is unlikely that significant changes to the plan will be made or that the plan will be withdrawn. Assets classified as held for sale are recorded at the lower of the carrying amount or fair value less the cost to sell.

[0001564590-21-007045:notes:38]
The Company classifies assets held for use when a decision to dispose of an asset or a business is made and the held for sale criteria are not met. In evaluating the recoverability of property and intangible assets subject to amortization, in a held for use business, the carrying value is first compared to the sum of the undiscounted cash flows expected to result from the use and eventual disposition. If the carrying value exceeds the undiscounted expected cash flows, then a fair value analysis is performed. An impairment charge is recognized if the carrying value exceeds the fair value.

[0001564590-21-007045:notes:39]
Leases

[0001564590-21-007045:notes:40]
The Company adopted the new lease standard as of January 1, 2019 under the retrospective cumulative effect adjustment transition method. Therefore, the consolidated financial statements for the year ended December 31, 2018 have not been adjusted and continued to be reported under previous U.S. GAAP guidance. As a result, beginning in the first quarter of 2019, the Company determines if an arrangement is a lease at inception. Operating leases are included in operating lease right-of-use (ROU) assets, and lease liabilities are included in other current liabilities and operating lease liabilities on the consolidated balance sheets.

[0001564590-21-007045:notes:41]
ROU assets represent the Company’s right to use an underlying asset for the lease term and lease liabilities represent the Company’s obligation to make lease payments arising from the lease. Operating lease ROU assets and liabilities are recognized at commencement date based on the present value of lease payments over the lease term. As most of the Company’s leases do not provide an implicit rate, the Company uses its incremental borrowing rate based on the information available at the commencement date in determining the present value of lease payments. The operating lease ROU asset also includes any lease payments made and excludes lease incentives. Lease terms may include options to extend or terminate the lease when it is reasonably certain that the Company will exercise that option. Lease expense for lease payments is recognized on a straight-line basis over the lease term.

[0001564590-21-007045:notes:42]
The Company has lease agreements with lease and non-lease components and accounts for the lease and non-lease components as a single lease component.

[0001564590-21-007045:notes:43]
Revenue Recognition

[0001564590-21-007045:notes:44]
The Company derives revenues primarily from the sale of PCBs, custom electronic assemblies using customer-supplied engineering and design plans as well as the design and manufacture of RF and microwave components and assemblies. In the absence of a sales agreement, the Company’s standard terms and conditions apply. Revenue is recognized when control of the promised goods or services is transferred to the Company’s customers, in an amount that reflects the consideration to which it expects to be entitled in exchange for those goods or services. The Company applies a five-step approach as defined in the new standard in determining the amount and timing of revenue to be recognized: (1) identifying the contract with a customer; (2) identifying the performance obligations in the contract; (3) determining the transaction price; (4) allocating the transaction price to the performance obligations in the contract; and (5) recognizing revenue when the corresponding performance obligation is satisfied.

[0001564590-21-007045:notes:45]
Revenue Streams

[0001564590-21-007045:notes:46]
For PCBs and custom electronic assemblies, including pursuant to the Company’s long-term contracts related to the manufacture of components, assemblies and subsystems, orders for products generally correspond to the production schedules of the Company’s customers and are supported with firm purchase orders. The Company’s customers have continuous control of the work in progress and finished goods throughout the PCB and custom electronic assemblies manufacturing process, as these are built to customer specifications with no alternative use, and there is an enforceable right to payment for work performed to date. As a result, the Company recognizes revenue progressively over time based on the extent of progress towards completion of the performance obligation. Revenue recognized is based on a cost method as it best depicts the transfer of control to the customer which takes place as we incur costs. Revenues are recorded proportionally as costs are incurred.

[0001564590-21-007045:notes:47]
In addition, the Company manufactures components, assemblies, and subsystems which service its RF&S Components customers. The Company recognizes revenue at a point in time upon transfer of control of the products to the customer. Point in time recognition was determined as the customer does not simultaneously receive or consume the benefits provided by the Company’s performance and the asset being manufactured has alternative uses to the Company.

[0001564590-21-007045:notes:48]
Performance Obligations

[0001564590-21-007045:notes:49]
Each distinct promise to transfer products is considered to be an identified performance obligation for which revenue is recognized upon transfer of control of the products to the customer. A contract’s transaction price is allocated to each distinct performance obligation and recognized as revenue when, or as, the performance obligation is satisfied. The majority of the Company's contracts have a single performance obligation as the promise to transfer the individual good or service is not separately identifiable from other promises in the contract and is, therefore, not distinct. As of December 28, 2020, the aggregate amount of the transaction price allocated to remaining performance obligations for the Company’s long-term contracts was $21,275. The Company expects to recognize revenue on approximately 99% of the remaining performance obligations for the Company’s long-term contracts over the next twelve months with the remaining amount recognized thereafter. The remaining performance obligations for the Company’s short-term contracts are expected to be recognized within one year.

[0001564590-21-007045:notes:50]
Transaction Price

[0001564590-21-007045:notes:51]
The Company provides customers a limited right of return for defective PCBs including components, subsystems and assemblies. Estimates of returns are treated as variable consideration for purposes of determining the transaction price. The Company accrues an estimate for sales returns and allowances progressively over time based on the extent of progress towards completion of the performance obligation using the Company’s judgment based on historical results and anticipated returns. To the extent actual experience varies from its historical experience, revisions to the sales returns and allowances accrual may be required. Sales returns and allowances are recorded as a reduction of revenue and included as a component of accrued expenses on the consolidated balance sheets. Shipping and handling fees and related freight costs and supplies associated with shipping products to customers are included as a component of cost of goods sold. Warranty-related services are not considered a separate performance obligation. Incremental warranty costs that are not related to sales returns are recorded in accrued expenses on the consolidated balance sheets and cost of goods sold on the consolidated statements of operations. The following summarizes the activity in the Company’s sales returns and allowances for the years ended December 28, 2020, December 30, 2019 and December 31, 2018:

[0001564590-21-007045:notes:52]
|  |  | For the Year Ended |  |
|  |  | December 28, |  |  | December 30, |  |  | December 31, |  |
|  |  | 2020 |  |  | 2019 |  |  | 2018 |  |
|  |  | (In thousands) |  |
| Balance at beginning of year |  | $ | 12,717 |  |  | $ | 15,296 |  |  | $ | 8,171 |  |
| Addition charged as a reduction of sales |  |  | 7,658 |  |  |  | 15,632 |  |  |  | 22,750 |  |
| Deductions |  |  | (7,389 | ) |  |  | (18,228 | ) |  |  | (15,602 | ) |
| Effect of foreign currency exchange rates |  |  | 29 |  |  |  | 17 |  |  |  | (23 | ) |
| Balance at end of year |  | $ | 13,015 |  |  | $ | 12,717 |  |  | $ | 15,296 |  |

[0001564590-21-007045:notes:53]
Contract Balances

[0001564590-21-007045:notes:54]
Accounts receivable represents the Company’s unconditional right to receive consideration from its customer. Payments are generally due within 90 days or less of invoicing and do not include a significant financing component. To date, there have been no material impairment losses on accounts receivable.

[0001564590-21-007045:notes:55]
A contract asset is recognized when the Company has recognized revenue, but not issued an invoice for payment. Contract assets are classified as current assets and are transferred to receivables when the entitlement to payment becomes unconditional. The Company’s contract assets are generally converted to trade account receivables within 90 days, at which time the Company is entitled to payment of the fixed price upon delivery of the finished product subject to customer payment terms. Contract assets were $273,256 and $254,600 as of December 28, 2020 and December 30, 2019, respectively, and represent unbilled amounts for work performed to date. In 2020, there were no material impairment losses on contract assets.

[0001564590-21-007045:notes:56]
A contract liability is recognized when the Company has received payment in advance for the future transfer of goods or services. The Company’s contract liabilities are generally converted to revenue within 90 days. Contract liabilities were $4,254 and $3,838 as of December 28, 2020 and December 30, 2019, respectively, and represent customer advances for work yet to be performed.

[0001564590-21-007045:notes:57]
The Company has elected to account for shipping and handling activities as a fulfillment cost as permitted by the standard. All incremental customer contract acquisition costs are expensed as they are incurred as the amortization period of the asset that the Company otherwise would have recognized is one year or less in duration.

[0001564590-21-007045:notes:58]
Disaggregated Revenue

[0001564590-21-007045:notes:59]
Revenue from products and services transferred to customers over time and at a point in time accounted for 98% and 2%, respectively, of the Company’s revenue in 2020, 2019 and 2018.

[0001564590-21-007045:notes:60]
The following tables represent a disaggregation of revenue by principal end markets with the reportable segments:

[0001564590-21-007045:notes:61]
|  |  | For the Year Ended December 28, 2020 |  |  |
|  |  | PCB |  |  | RF&S Components |  |  | E-M Solutions |  |  | Total |  |  |
| End Markets |  | (In thousands) |  |  |
| Aerospace and Defense |  | $ | 745,041 |  |  | $ | 189 |  |  | $ | 655 |  |  | $ | 745,885 |  |  |
| Automotive |  |  | 270,240 |  |  |  | — |  |  |  | 48,615 |  |  |  | 318,855 |  |  |
| Cellular Phone |  |  | 1,341 |  |  |  | — |  |  |  | — |  |  |  | 1,341 |  |  |
| Computing/Storage/Peripherals |  |  | 258,032 |  |  |  | 834 |  |  |  | 170 |  |  |  | 259,036 |  |  |
| Medical/Industrial/Instrumentation |  |  | 374,237 |  |  |  | 2,967 |  |  |  | 10,491 |  |  |  | 387,695 |  |  |
| Networking/Communications |  |  | 234,211 |  |  |  | 39,160 |  |  |  | 97,213 |  |  |  | 370,584 |  |  |
| Other |  |  | 22,141 |  |  |  | 1,506 |  |  |  | (1,721 | ) |  |  | 21,926 |  |  |
| Total |  | $ | 1,905,243 |  |  | $ | 44,656 |  |  | $ | 155,423 |  |  | $ | 2,105,322 |  |  |

[0001564590-21-007045:notes:62]
|  |  | For the Year Ended December 30, 2019 |  |  |
|  |  | PCB |  |  | RF&S Components |  |  | E-M Solutions |  |  | Total |  |  |
| End Markets |  | (In thousands) |  |  |
| Aerospace and Defense |  | $ | 696,279 |  |  | $ | 777 |  |  | $ | 543 |  |  | $ | 697,599 |  |  |
| Automotive |  |  | 302,101 |  |  |  | — |  |  |  | 102,004 |  |  |  | 404,105 |  |  |
| Cellular Phone |  |  | 1,224 |  |  |  | — |  |  |  | — |  |  |  | 1,224 |  |  |
| Computing/Storage/Peripherals |  |  | 235,615 |  |  |  | 1,588 |  |  |  | 288 |  |  |  | 237,491 |  |  |
| Medical/Industrial/Instrumentation |  |  | 331,551 |  |  |  | 3,752 |  |  |  | 29,682 |  |  |  | 364,985 |  |  |
| Networking/Communications |  |  | 253,306 |  |  |  | 43,333 |  |  |  | 94,435 |  |  |  | 391,074 |  |  |
| Other |  |  | 24,486 |  |  |  | 12,865 |  |  |  | (619 | ) |  |  | 36,732 |  |  |
| Total |  | $ | 1,844,562 |  |  | $ | 62,315 |  |  | $ | 226,333 |  |  | $ | 2,133,210 |  |  |

[0001564590-21-007045:notes:63]
|  |  | For the Year Ended December 31, 2018 |  |  |
|  |  | PCB |  |  | RF&S Components |  |  | E-M Solutions |  |  | Total |  |  |
| End Markets |  | (In thousands) |  |  |
| Aerospace and Defense |  | $ | 606,573 |  |  | $ | 153 |  |  | $ | 858 |  |  | $ | 607,584 |  |  |
| Automotive |  |  | 388,643 |  |  |  | — |  |  |  | 86,828 |  |  |  | 475,471 |  |  |
| Computing/Storage/Peripherals |  |  | 280,497 |  |  |  | 939 |  |  |  | 1,694 |  |  |  | 283,130 |  |  |
| Medical/Industrial/Instrumentation |  |  | 345,078 |  |  |  | 2,271 |  |  |  | 39,852 |  |  |  | 387,201 |  |  |
| Networking/Communications |  |  | 322,128 |  |  |  | 40,982 |  |  |  | 96,894 |  |  |  | 460,004 |  |  |
| Other |  |  | 16,171 |  |  |  | 8,360 |  |  |  | (179 | ) |  |  | 24,352 |  |  |
| Total |  | $ | 1,959,090 |  |  | $ | 52,705 |  |  | $ | 225,947 |  |  | $ | 2,237,742 |  |  |

[0001564590-21-007045:notes:64]
Value Added and Sales Tax Collected from Customers

[0001564590-21-007045:notes:65]
As a part of the Company’s normal course of business, value added and sales taxes are collected from customers. Such taxes collected are remitted, in a timely manner, to the appropriate governmental tax authority on behalf of the customer. Value added and sales taxes are excluded from reported revenues and costs of goods sold presented in the consolidated statements of operations and comprehensive income.

[0001564590-21-007045:notes:66]
Stock-Based Compensation

[0001564590-21-007045:notes:67]
The Company recognizes stock-based compensation expense in its consolidated financial statements for its incentive compensation plan awards. The incentive compensation plan awards include performance-based restricted stock units, restricted stock units, and stock options. The associated compensation expense for all awards is based on the grant date fair value of the awards. For performance-based restricted stock units, compensation expense also includes management’s periodic assessment of annual financial performance goals to be achieved. Compensation expense for the incentive compensation plan awards is recognized on a straight line

[0001564590-21-007045:notes:68]
basis over the vesting period of the awards. The fair value of performance-based restricted stock units is estimated on the grant date using a Monte Carlo simulation model based on the underlying common stock closing price as of the date of grant, stock price volatility, and risk-free interest rates. The fair value of restricted stock units is measured on the grant date based on the quoted closing market price of the Company’s common stock. The fair value of the stock options is estimated on the grant date using the Black-Scholes option pricing model based on the underlying common stock closing price as of the date of grant, the expected term, stock price volatility, and risk-free interest rates.

[0001564590-21-007045:notes:69]
Income Taxes

[0001564590-21-007045:notes:70]
Income taxes are accounted for under the asset and liability method. Deferred income tax assets or liabilities are recognized for the future tax consequences attributable to differences between the financial statement carrying amounts of assets and liabilities and their respective tax bases and operating loss and tax credit carryforwards. Deferred income tax assets and liabilities are measured using enacted tax rates expected to apply to taxable income in the years in which those temporary differences are expected to be settled or realized. The effect on deferred income tax assets and liabilities of a change in tax rates is recognized in income in the period that includes the enactment date. Deferred income tax assets are reviewed for recoverability, and the Company records a valuation allowance to reduce its deferred income tax assets when it is more likely than not that all or some portion of the deferred income tax assets will not be realized.

[0001564590-21-007045:notes:71]
The Company has various foreign subsidiaries formed or acquired to conduct or support its business outside the United States. The Company expects its earnings attributable to foreign subsidiaries will be indefinitely reinvested except for our material Chinese and Canadian plants and the respective holding companies where a deferred tax liability has been recorded for foreign withholding and estimated federal/state tax impact. For those other companies with earnings currently being reinvested outside of the U.S., no deferred tax liabilities on undistributed earnings are recorded.

[0001564590-21-007045:notes:72]
The Company recognizes the effect of income tax positions only if those positions are more likely than not to be sustained. Recognized income tax positions are measured at the largest amount that is greater than 50 percent likely to be realized. Changes in recognition or measurement are reflected in the period in which the change in judgment occurs. Estimated interest and penalties related to underpayment of income taxes are recorded as a component of income tax provision in the consolidated statements of operations.

[0001564590-21-007045:notes:73]
Fair Value Measures

[0001564590-21-007045:notes:74]
The Company measures at fair value certain of its financial and non-financial assets and liabilities by using a fair value hierarchy that prioritizes the inputs to valuation techniques used to measure fair value. Fair value is the price that would be received to sell an asset or paid to transfer a liability in an orderly transaction between market participants at the measurement date, essentially an exit price, based on the highest and best use of the asset or liability. The levels of the fair value hierarchy are:

[0001564590-21-007045:notes:75]
Level 1 — Quoted market prices in active markets for identical assets or liabilities;

[0001564590-21-007045:notes:76]
Level 2 — Significant other observable inputs (e.g., quoted prices for similar items in active markets, quoted prices for identical or similar items in markets that are not active, inputs other than quoted prices that are observable, such as interest rate and yield curves, and market-corroborated inputs); and

[0001564590-21-007045:notes:77]
Level 3 — Unobservable inputs in which there is little or no market data, which require the reporting unit to develop its own assumptions.

[0001564590-21-007045:notes:78]
Earnings Per Share

[0001564590-21-007045:notes:79]
Basic earnings per common share excludes dilution and is computed by dividing net income by the weighted average number of common shares outstanding during the period. Diluted earnings per common share reflect the potential dilution that could occur if stock options, Convertible Senior Notes or other common stock equivalents were exercised or converted into common stock. The dilutive effect of stock options or other common stock equivalents is calculated using the treasury stock method. During the year ended December 28, 2020, the Company calculated the dilutive effect of Convertible Senior Notes using the treasury stock method because the Company repaid and settled the Convertible Senior Notes in cash. This change in policy from the if-converted method to treasury stock method was applied on a prospective basis.

[0001564590-21-007045:notes:80]
Comprehensive Income

[0001564590-21-007045:notes:81]
Comprehensive income includes changes to equity accounts that were not the result of transactions with stockholders. Comprehensive income is comprised of net income, changes in the cumulative foreign currency translation adjustments, pension obligation adjustments, and realized and unrealized gains or losses on hedged derivative instruments.

[0001564590-21-007045:notes:82]
Loss Contingencies

[0001564590-21-007045:notes:83]
The Company establishes an accrual for an estimated loss contingency when it is both probable that an asset has been impaired or that a liability has been incurred and the amount of the loss can be reasonably estimated. Any legal fees expected to be incurred in connection with a contingency are expensed as incurred.

[0001564590-21-007045:notes:84]
Accounting for Retirement Benefit Plans

[0001564590-21-007045:notes:85]
The Company accounts for its retirement benefit plans and postretirement and postemployment benefit obligations in accordance with ASC Topic 715, Compensation—Retirement Benefits. ASC Topic 715 requires the Company to recognize the overfunded or underfunded status of a defined benefit plan, measured as the difference between the fair value of plan assets and the plan's benefit obligation, as an asset or liability in its consolidated balance sheets and to recognize changes to that funded status in the year in which the changes occur through accumulated other comprehensive loss. ASC Topic 715 also requires measurement of the funded status of a plan as of the Company's consolidated balance sheet dates.

[0001564590-21-007045:notes:86]
Recently Adopted and Issued Accounting Standards

[0001564590-21-007045:notes:87]
Recently Adopted Accounting Standards

[0001564590-21-007045:notes:88]
In March 2020, the Financial Accounting Standards Board (FASB) issued ASU 2020-04, Reference Rate Reform (Topic 848): Facilitation of the Effects of Reference Rate Reform on Financial Reporting, which provides temporary relief to the GAAP guidance on contract modifications and hedge accounting to ease the financial reporting burdens of the expected market transition from LIBOR and other interbank offered rates to alternative rates. This guidance became effective beginning on March 12, 2020 and will remain in effect through December 31, 2022. The guidance on contract modifications can be applied prospectively from any date beginning March 12, 2020 and may also be applied to modifications of existing contracts made earlier in the interim period that included March 12, 2020. The guidance on hedging can be applied to eligible hedging relationships existing at the beginning of the interim period that included March 12, 2020 and to new eligible hedging relationships entered into after the beginning of that interim period. The Company adopted this ASU and it did not have a material impact on its consolidated financial statements.

[0001564590-21-007045:notes:89]
In August 2018, the FASB issued ASU 2018-14, Compensation—Retirement Benefits—Defined Benefit Plans—General (Subtopic 715-20)—Disclosure Framework—Changes to the Disclosure Requirements for Defined Benefit Plans. The amendments in this update change the disclosure requirements for employers that sponsor defined benefit pension and/or other postretirement benefit plans. It eliminates requirements for certain disclosures that are no longer considered cost beneficial and requires new disclosures that the FASB considers pertinent. The Company adopted this ASU as of December 28, 2020 and it did not have a material impact on its consolidated financial statements. See Note 15 for disclosure changes made.

[0001564590-21-007045:notes:90]
In June 2016, the FASB issued ASU 2016-13, Financial Instruments - Credit Losses (Topic 326): Measurement of Credit Losses on Financial Instruments, which amends the current accounting guidance and requires the measurement of all expected losses based on historical experience, current conditions and reasonable and supportable forecasts. For trade receivables, loans, and other financial instruments, the Company will be required to use a forward-looking expected loss model that reflects losses that are probable rather than the incurred loss model for recognizing credit losses. The standard became effective for interim and annual periods beginning after December 15, 2019. Application of the amendments is through a cumulative-effect adjustment to retained earnings as of the effective date. The Company adopted this ASU as of December 31, 2019 and it did not have a material impact on its consolidated financial statements.

[0001564590-21-007045:notes:91]
Recently Issued Accounting Standards Not Yet Adopted

[0001564590-21-007045:notes:92]
In December 2019, the FASB issued ASU 2019-12, Income Taxes (Topic 740): Simplifying the Accounting for Income Taxes, which is intended to simplify various aspects related to accounting for income taxes. ASU 2019-12 removes certain exceptions to the general principles in Topic 740 and also clarifies and amends existing guidance to improve consistent application. The guidance is effective for fiscal years beginning after December 15, 2020, including interim periods within those fiscal years. Early adoption is permitted. The Company has evaluated the new guidance to determine the impact it may have on its consolidated financial statements and related disclosures and the impact is not expected to be material.


## us-gaap:LesseeOperatingLeasesTextBlock

[0001564590-21-007045:notes:93]
| (2) | Leases |

[0001564590-21-007045:notes:94]
The Company leases some of its manufacturing and assembly plants, sales offices and equipment under non-cancellable operating leases that expire at various dates through 2049. The majority of the Company’s lease arrangements are comprised of fixed payments and certain leases consist of variable payments based on equipment usage. These variable payments are not included in the measurement of the ROU asset or lease liability due to uncertainty of the payment amount and are recorded as lease expense in the period incurred. Certain leases contain renewal provisions at the Company’s option. Most of the leases require the Company to pay for certain other costs such as property taxes and maintenance. Certain leases also contain rent escalation clauses (step rents) that require additional rental amounts in the later years of the term. Rent expense for leases with step rents is recognized on a straight-line basis

[0001564590-21-007045:notes:95]
over the minimum lease term. The lease agreements do not contain any material residual value guarantees or material restrictive covenants.

[0001564590-21-007045:notes:96]
The components of lease expense were as follows:

[0001564590-21-007045:notes:97]
|  |  | For the Year Ended |  |
|  |  | December 28, 2020 |  |  | December 30, 2019 |  |
|  |  | (In thousands) |  |
| Operating lease cost |  | $ | 9,304 |  |  | $ | 8,560 |  |
| Variable lease cost |  |  | 529 |  |  |  | 591 |  |
| Short-term lease cost |  |  | 525 |  |  |  | 520 |  |

[0001564590-21-007045:notes:98]
Supplemental cash flow information related to leases was as follows:

[0001564590-21-007045:notes:99]
|  |  | For the Year Ended |  |
|  |  | December 28, 2020 |  |  | December 30, 2019 |  |
|  |  | (In thousands) |  |
| Cash paid for amounts included in the measurement of lease liabilities: |  |  |  |  |  |  |  |  |
| Operating cash flows from operating leases |  | $ | 8,865 |  |  | $ | 8,265 |  |
| Right-of-use assets obtained in exchange for new lease obligations: |  |  |  |  |  |  |  |  |
| Operating leases |  |  | 10,036 |  |  |  | 13,596 |  |

[0001564590-21-007045:notes:100]
Supplemental balance sheet information related to leases was as follows:

[0001564590-21-007045:notes:101]
|  |  | As of |  |
|  |  | December 28, 2020 |  |  | December 30, 2019 |  |
|  |  | (In thousands) |  |
| Operating lease right-of-use assets |  | $ | 24,340 |  |  | $ | 22,173 |  |
| Other current liabilities |  |  | 8,144 |  |  |  | 7,111 |  |
| Operating lease liabilities |  |  | 17,211 |  |  |  | 15,413 |  |
| Total operating lease liabilities |  | $ | 25,355 |  |  | $ | 22,524 |  |

[0001564590-21-007045:notes:102]
|  |  | As of |  |
|  |  | December 28, 2020 |  |  | December 30, 2019 |  |
| Weighted average remaining lease term |  | 4.2 years |  |  | 4.4 years |  |
| Weighted average discount rate |  |  | 3.31 | % |  |  | 3.92 | % |

[0001564590-21-007045:notes:103]
Maturities of operating lease liabilities were as follows (1):

[0001564590-21-007045:notes:104]
|  |  | (In thousands) |  |
| Less than one year |  | $ | 9,170 |  |
| 1 - 2 years |  |  | 5,240 |  |
| 2 - 3 years |  |  | 4,562 |  |
| 3 - 4 years |  |  | 3,586 |  |
| 4 - 5 years |  |  | 2,313 |  |
| Thereafter |  |  | 2,336 |  |
| Total lease payments |  |  | 27,207 |  |
| Less imputed interest |  |  | (1,852 | ) |
| Total |  | $ | 25,355 |  |

[0001564590-21-007045:notes:105]
|  | (1) | Excludes $955 of legally binding minimum lease payments for leases signed but not yet commenced. |

[0001564590-21-007045:notes:106]
Operating Leases Pre-Topic 842 Adoption

[0001564590-21-007045:notes:107]
The following is a schedule of future minimum lease payments as of December 31, 2018:

[0001564590-21-007045:notes:108]
|  |  | Operating Leases |  |
|  |  | (In thousands) |  |
| 2019 |  | $ | 6,204 |  |
| 2020 |  |  | 4,677 |  |
| 2021 |  |  | 3,406 |  |
| 2022 |  |  | 2,408 |  |
| 2023 |  |  | 2,172 |  |
| Thereafter |  |  | 4,172 |  |
| Total minimum lease payments |  | $ | 23,039 |  |

[0001564590-21-007045:notes:109]
Total rent expense for the year ended December 31, 2018 was approximately $9,297.


## us-gaap:DisposalGroupsIncludingDiscontinuedOperationsDisclosureTextBlock

[0001564590-21-007045:notes:110]
| (3) | Discontinued Operations |

[0001564590-21-007045:notes:111]
On January 19, 2020, the Company entered into a definitive equity interests purchase agreement for the sale of the Company’s Mobility business unit. The sale was completed on April 17, 2020 for a base purchase price of $550,000, subject to customary purchase price adjustments. The base purchase price does not include certain accounts receivable of the divested business, which were estimated to total approximately $95,000. Subsequently, the final purchase price was $569,246 after customary purchase price adjustments, which did not include approximately $83,000 accounts receivable of the divested business.

[0001564590-21-007045:notes:112]
On April 18, 2020, the Company also entered into a Transition Services Agreement (TSA) with the Purchaser pursuant to which the Purchaser is receiving certain services (the Services) to enable it to operate the Mobility business unit after the closing of the sale of the Mobility business unit. The Services include finance and accounting, human resources, legal and compliance, sales, information technology, and other corporate support services. Under the TSA, the Services are being provided at cost for a period of up to 24 months. In addition, the Company entered into a Manufacturing Supply Agreement with the Purchaser pursuant to which the Purchaser will supply products to a few customers of the Company. There was no material impact on the Company’s consolidated financial statements.

[0001564590-21-007045:notes:113]
Further, on June 29, 2020, the Company entered into a Sales Force Agreement with the Purchaser pursuant to which the Company’s sales representatives will assist the Purchaser in selling PCBs manufactured by the Purchaser to certain customers for a commission for a period up to April 17, 2021. There was no material impact on the Company’s consolidated financial statements.

[0001564590-21-007045:notes:114]
As the sale of the Company’s Mobility business unit represents a strategic shift that will have a major effect on the Company’s operations and financial results, in accordance with the provisions of FASB authoritative guidance on the presentation of financial statements, Mobility business unit results are classified as discontinued operations in the consolidated statements of operations for all periods presented. Prior year results have been recast to conform with the current presentation.

[0001564590-21-007045:notes:115]
The following table summarizes the results of Mobility operations for each period prior to sale:

[0001564590-21-007045:notes:116]
|  |  | For the Year Ended |  |
|  |  | December 28, |  |  | December 30, |  |  | December 31, |  |
|  |  | 2020 |  |  | 2019 |  |  | 2018 |  |
|  |  | (In thousands, except per share data) |  |
| Net sales |  | $ | 143,951 |  |  | $ | 556,098 |  |  | $ | 609,519 |  |
| Cost of goods sold |  |  | 136,800 |  |  |  | 531,592 |  |  |  | 555,154 |  |
| Gross profit |  |  | 7,151 |  |  |  | 24,506 |  |  |  | 54,365 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |
| Selling and marketing |  |  | 1,461 |  |  |  | 4,840 |  |  |  | 3,231 |  |
| General and administrative |  |  | 2,317 |  |  |  | 4,875 |  |  |  | 7,464 |  |
| Research and development |  |  | 147 |  |  |  | — |  |  |  | — |  |
| Amortization of definite-lived intangibles |  |  | 809 |  |  |  | 2,698 |  |  |  | 2,698 |  |
| Restructuring charges |  |  | — |  |  |  | 1,601 |  |  |  | 858 |  |
| Total operating expenses |  |  | 4,734 |  |  |  | 14,014 |  |  |  | 14,251 |  |
| Operating income |  |  | 2,417 |  |  |  | 10,492 |  |  |  | 40,114 |  |
| Other (expense) income: |  |  |  |  |  |  |  |  |  |  |  |  |
| Interest expense |  |  | (223 | ) |  |  | (1,147 | ) |  |  | (3,194 | ) |
| Gain on sale of the Mobility business unit |  |  | 237,253 |  |  |  | — |  |  |  | — |  |
| Other, net |  |  | 1,160 |  |  |  | 2,513 |  |  |  | 5,663 |  |
| Total other income, net |  |  | 238,190 |  |  |  | 1,366 |  |  |  | 2,469 |  |
| Income from discontinued operations before income taxes |  |  | 240,607 |  |  |  | 11,858 |  |  |  | 42,583 |  |
| Income tax provision |  |  | (46,686 | ) |  |  | (2,478 | ) |  |  | (4,391 | ) |
| Income from discontinued operations, net of income taxes |  | $ | 193,921 |  |  | $ | 9,380 |  |  | $ | 38,192 |  |
| Earnings per share from discontinued operations: |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic earnings per share |  | $ | 1.82 |  |  | $ | 0.09 |  |  | $ | 0.37 |  |
| Diluted earnings per share |  | $ | 1.82 |  |  | $ | 0.09 |  |  | $ | 0.28 |  |

[0001564590-21-007045:notes:117]
Depreciation expense related to the discontinued operations for the years ended December 28, 2020, December 30, 2019, and December 31, 2018 was $21,375, $73,204, and $71,379, respectively.

[0001564590-21-007045:notes:118]
During the year ended December 28, 2020, the Company’s income tax expense related to the discontinued operations was impacted by a net discrete tax expense of $46,686. The net income tax expense for the year ended December 28, 2020 is related mainly to (i) China withholding tax related to gain on sale, (ii) U.S. income tax related to Global Intangible Low Taxed Income (GILTI) inclusion net of IRC Section 250 deduction and foreign tax credits, and offset by (iii) release of U.S. uncertain tax positions as a result of available excess foreign tax credits.

[0001564590-21-007045:notes:119]
Assets sold and liabilities being assumed by the Purchaser in the sale of the Company’s Mobility business unit include substantially all assets and liabilities, with the exception of certain accounts receivable. The following table summarizes the major categories of assets and liabilities classified as held for sale in the consolidated balance sheet as of December 30, 2019:

[0001564590-21-007045:notes:120]
|  |  | As of |  |
|  |  | December 30, 2019 |  |
|  |  | (In thousands) |  |
| Cash and cash equivalents |  | $ | 20,336 |  |
| Accounts receivable, net |  |  | 66 |  |
| Contract assets |  |  | 33,635 |  |
| Inventories |  |  | 8,266 |  |
| Prepaid expenses and other current assets |  |  | 5,269 |  |
| Property, plant and equipment, net |  |  | 344,728 |  |
| Operating lease right-of-use assets |  |  | 1,983 |  |
| Goodwill |  |  | 68,267 |  |
| Definite-lived intangibles, net |  |  | 6,328 |  |
| Deposits and other non-current assets |  |  | 4,291 |  |
| Total assets classified as held for sale |  | $ | 493,169 |  |
| Accounts payable |  | $ | 153,700 |  |
| Accrued salaries, wages and benefits |  |  | 13,606 |  |
| Other current liabilities |  |  | 18,085 |  |
| Operating lease liabilities |  |  | 1,104 |  |
| Other long-term liabilities |  |  | 426 |  |
| Total liabilities classified as held for sale |  | $ | 186,921 |  |

[0001564590-21-007045:notes:121]
Proceeds from the sale of the Company’s Mobility business unit have been presented in the consolidated statements of cash flows within net cash provided by investing activities from discontinued operations. The following is a reconciliation of the gain recorded for the sale of the Company’s Mobility business unit (in thousands):

[0001564590-21-007045:notes:122]
| Net proceeds from the sale of the Mobility business unit (1) |  | $ | 569,246 |  |
| Mobility business unit assets: |  |  |  |  |
| Cash and cash equivalents |  |  | 12,513 |  |
| Restricted cash |  |  | 35,412 |  |
| Accounts receivable, net |  |  | 12 |  |
| Contract assets |  |  | 40,072 |  |
| Inventories |  |  | 4,988 |  |
| Prepaid expenses and other current assets |  |  | 4,593 |  |
| Property, plant and equipment, net |  |  | 328,648 |  |
| Goodwill |  |  | 68,267 |  |
| Definite-lived intangibles, net |  |  | 5,520 |  |
| Deposits and other non-current assets |  |  | 6,291 |  |
| Total Mobility business unit assets |  |  | 506,316 |  |
| Mobility business unit liabilities: |  |  |  |  |
| Accounts payable |  |  | 142,636 |  |
| Accrued salaries, wages and benefits |  |  | 9,392 |  |
| Other current liabilities |  |  | 8,890 |  |
| Other long-term liabilities |  |  | 303 |  |
| Total Mobility business unit liabilities |  |  | 161,221 |  |
| Derecognition of foreign currency translation adjustments and unrealized losses on cash flow hedges recorded in accumulated other comprehensive loss |  |  | 26,957 |  |
| Other transaction costs incurred as part of the sale of the Mobility business unit (2) |  |  | 13,855 |  |
| Gain on sale of the Mobility business unit before income taxes |  | $ | 237,253 |  |

[0001564590-21-007045:notes:123]
| (1) | Net proceeds from the sale of the Mobility business unit are net of the finalized customary purchase price adjustments. |

[0001564590-21-007045:notes:124]
| (2) | Costs directly incurred as a result of the sale of the Company’s Mobility business unit, including bank fees, legal fees, professional fees, and other costs. |


## us-gaap:ScheduleOfDisposalGroupsIncludingDiscontinuedOperationsIncomeStatementBalanceSheetAndAdditionalDisclosuresTextBlock

[0001564590-21-007045:notes:125]
The following table summarizes the major categories of assets and liabilities classified as held for sale in the consolidated balance sheet as of December 30, 2019:

[0001564590-21-007045:notes:126]
The following is a reconciliation of the gain recorded for the sale of the Company’s Mobility business unit (in thousands):


## us-gaap:AdditionalFinancialInformationDisclosureTextBlock

[0001564590-21-007045:notes:127]
| (4) | Composition of Certain Consolidated Financial Statement Captions |

[0001564590-21-007045:notes:128]
|  |  | As of |  |
|  |  | December 28, 2020 |  |  | December 30, 2019 |  |
|  |  | (In thousands) |  |
| Inventories: |  |  |  |  |  |  |  |  |
| Raw materials |  | $ | 103,890 |  |  | $ | 97,660 |  |
| Work-in-process |  |  | 7,841 |  |  |  | 10,898 |  |
| Finished goods |  |  | 3,920 |  |  |  | 5,195 |  |
|  |  | $ | 115,651 |  |  | $ | 113,753 |  |
| Property, plant and equipment, net: |  |  |  |  |  |  |  |  |
| Land and land use rights |  | $ | 61,781 |  |  | $ | 62,009 |  |
| Buildings and improvements |  |  | 398,540 |  |  |  | 381,980 |  |
| Machinery and equipment |  |  | 832,723 |  |  |  | 777,916 |  |
| Furniture and fixtures and other |  |  | 10,304 |  |  |  | 10,329 |  |
| Construction-in-progress |  |  | 33,191 |  |  |  | 58,195 |  |
|  |  |  | 1,336,539 |  |  |  | 1,290,429 |  |
| Less: Accumulated depreciation |  |  | (686,104 | ) |  |  | (612,228 | ) |
|  |  | $ | 650,435 |  |  | $ | 678,201 |  |
| Other current liabilities: |  |  |  |  |  |  |  |  |
| Sales return and allowances |  | $ | 13,015 |  |  | $ | 12,717 |  |
| Restructuring |  |  | 7,382 |  |  |  | 502 |  |
| Interest |  |  | 7,157 |  |  |  | 8,893 |  |
| Income taxes payable |  |  | 2,428 |  |  |  | 13,035 |  |
| Other |  |  | 59,440 |  |  |  | 57,335 |  |
|  |  | $ | 89,422 |  |  | $ | 92,482 |  |
| Other long-term liabilities: |  |  |  |  |  |  |  |  |
| Deferred income taxes |  | $ | 23,704 |  |  | $ | 25,435 |  |
| Derivative liabilities |  |  | 14,968 |  |  |  | 12,067 |  |
| Defined benefit pension plan liability |  |  | 9,986 |  |  |  | 9,313 |  |
| Other |  |  | 25,167 |  |  |  | 45,510 |  |
|  |  | $ | 73,825 |  |  | $ | 92,325 |  |


## us-gaap:GoodwillDisclosureTextBlock

[0001564590-21-007045:notes:129]
| (5) | Goodwill |

[0001564590-21-007045:notes:130]
As of December 28, 2020, December 30, 2019 and December 31, 2018, goodwill by reportable segment was as follows:

[0001564590-21-007045:notes:131]
|  |  | PCB |  | RF&S Components |  | Total |  |
|  |  | (In thousands) |  |
| Balance as of December 31, 2018 |  |  |  |  |  |  |  |  |  |  |
| Goodwill |  | $ | 692,978 |  | $ | 177,200 |  | $ | 870,178 |  |
| Accumulated impairment losses |  |  | (171,400 | ) |  | — |  |  | (171,400 | ) |
|  |  |  | 521,578 |  |  | 177,200 |  |  | 698,778 |  |
| Goodwill recognized during the year |  |  | 7,746 |  |  | — |  |  | 7,746 |  |
| Balance as of December 30, 2019 |  |  |  |  |  |  |  |  |  |  |
| Goodwill |  |  | 700,724 |  |  | 177,200 |  |  | 877,924 |  |
| Accumulated impairment losses |  |  | (171,400 | ) |  | — |  |  | (171,400 | ) |
|  |  |  | 529,324 |  |  | 177,200 |  |  | 706,524 |  |
| Impairment loss during the year |  |  | — |  |  | (69,200 | ) |  | (69,200 | ) |
| Balance as of December 28, 2020 |  |  |  |  |  |  |  |  |  |  |
| Goodwill |  |  | 700,724 |  |  | 177,200 |  |  | 877,924 |  |
| Accumulated impairment losses |  |  | (171,400 | ) |  | (69,200 | ) |  | (240,600 | ) |
|  |  | $ | 529,324 |  | $ | 108,000 |  | $ | 637,324 |  |

[0001564590-21-007045:notes:132]
The Company evaluates its goodwill on an annual basis during its fourth fiscal quarter and at other times when events or changes in circumstances — such as significant adverse changes in the business climate or operating results or changes in management strategy, coupled with a decline in the market price of its stock and market capitalization — indicate that there may be a potential impairment. During the third quarter of 2020, the Company determined that there was a permanent loss of sales due to certain government restrictions on the sale of U.S.-designed products to certain customers in China in the RF&S Components reporting unit that coupled with the impact of COVID-19, resulted in lower than anticipated results and continued decline in sales. The Company considered these factors to be indicators of potential impairment requiring the Company to test the related goodwill for impairment. As of September 28, 2020, the Company completed a quantitative goodwill impairment analysis related to its RF&S Components reporting unit by comparing the fair value of the reporting unit with its carrying amount. The Company determined the fair value of the reporting unit by using both a DCF and a market approach. Under the market approach, the Company used revenue and earnings multiples based on comparable industry multiples to estimate the fair value of the reporting unit.

[0001564590-21-007045:notes:133]
Under the DCF approach, the Company estimated the future cash flows, as well as selected a risk-adjusted discount rate to measure the present value of the anticipated cash flows. When determining future cash flow estimates, the Company considered historical results adjusted to reflect current and anticipated future operating conditions. The Company estimated cash flows for the reporting unit over a discrete period and a terminal period (considering expected long-term growth rates and trends).

[0001564590-21-007045:notes:134]
Based on its analysis, the Company determined that the fair value of the RF&S Components reporting unit was less than its carrying value and recorded a goodwill impairment charge of $69,200. Estimating the fair value of the reporting unit requires the Company to make assumptions and estimates in such areas as future economic conditions, industry-specific conditions, product pricing, and necessary capital expenditures. The use of different assumptions or estimates for future cash flows, discount rates, or terminal growth rates could produce substantially different estimates of the fair value of the reporting unit. The Company may be subject to additional goodwill impairment charges if actual results do not meet the estimates used in determining the fair value of goodwill and the associated goodwill impairment charge.

[0001564590-21-007045:notes:135]
In the fourth quarter of 2020, the Company performed its annual goodwill impairment test qualitatively and concluded that it was more likely than not that there was no impairment to goodwill.


## us-gaap:IntangibleAssetsDisclosureTextBlock

[0001564590-21-007045:notes:136]
| (6) | Definite-lived Intangibles |

[0001564590-21-007045:notes:137]
As of December 28, 2020 and December 30, 2019, the components of definite-lived intangibles were as follows:

[0001564590-21-007045:notes:138]
|  |  | Gross Amount |  |  | Accumulated Amortization |  |  | Net Carrying Amount |  |  | Weighted Average Amortization Period |  |
|  |  | (In thousands) |  |  | (In years) |  |
| December 28, 2020 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Customer relationships |  | $ | 397,500 |  |  | $ | (150,142 | ) |  | $ | 247,358 |  |  |  | 10.9 |  |
| Technology |  |  | 47,650 |  |  |  | (13,701 | ) |  |  | 33,949 |  |  |  | 9.5 |  |
|  |  | $ | 445,150 |  |  | $ | (163,843 | ) |  | $ | 281,307 |  |  |  |  |  |
| December 30, 2019 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Customer relationships |  | $ | 396,270 |  |  | $ | (111,272 | ) |  | $ | 284,998 |  |  |  | 11.0 |  |
| Technology |  |  | 39,500 |  |  |  | (8,064 | ) |  |  | 31,436 |  |  |  | 9.4 |  |
| Acquired intangibles from acquisition in 2019 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Customer relationships |  |  | 1,230 |  |  |  | (31 | ) |  |  | 1,199 |  |  |  | 5.0 |  |
| Technology |  |  | 8,150 |  |  |  | (103 | ) |  |  | 8,047 |  |  |  | 10.0 |  |
|  |  | $ | 445,150 |  |  | $ | (119,470 | ) |  | $ | 325,680 |  |  |  |  |  |

[0001564590-21-007045:notes:139]
Definite-lived intangibles are amortized using the straight-line method of amortization over the useful life. Amortization expense was $44,373, $50,598, and $60,328 for the years ended December 28, 2020, December 30, 2019 and December 31, 2018, respectively. For the years ended December 28, 2020, December 30, 2019 and December 31, 2018, $5,535, $4,822 and $3,345, respectively, of amortization expense is included in cost of goods sold.

[0001564590-21-007045:notes:140]
Estimated aggregate amortization for definite-lived intangible assets for the next five years and thereafter is as follows:

[0001564590-21-007045:notes:141]
|  |  | (In thousands) |  |
| 2021 |  | $ | 41,179 |  |
| 2022 |  |  | 38,631 |  |
| 2023 |  |  | 36,713 |  |
| 2024 |  |  | 29,713 |  |
| 2025 |  |  | 25,397 |  |
| Thereafter |  |  | 109,674 |  |
|  |  | $ | 281,307 |  |


## us-gaap:LongTermDebtTextBlock

[0001564590-21-007045:notes:142]
| (7) | Long-term Debt and Letters of Credit |

[0001564590-21-007045:notes:143]
The following table summarizes the long-term debt of the Company as of December 28, 2020 and December 30, 2019:

[0001564590-21-007045:notes:144]
|  |  | Interest Rate as of December 28, 2020 |  |  | Principal Outstanding as of December 28, 2020 |  |  | Interest Rate as of December 30, 2019 |  |  | Principal Outstanding as of December 30, 2019 |  |
|  |  | (In thousands) |  |
| Term Loan due September 2024 |  |  | 2.65 |  | % | $ | 405,879 |  |  |  | 4.28 |  | % | $ | 805,879 |  |
| Senior Notes due October 2025 |  |  | 5.63 |  |  |  | 375,000 |  |  |  | 5.63 |  |  |  | 375,000 |  |
| U.S. ABL Revolving Loan due June 2024 |  |  | 1.40 |  |  |  | 40,000 |  |  |  | 3.03 |  |  |  | 40,000 |  |
| Asia ABL Revolving Loan due June 2024 |  |  | 1.55 |  |  |  | 30,000 |  |  |  | 3.18 |  |  |  | 30,000 |  |
| Convertible Senior Notes due December 2020 |  |  | — |  |  |  | — |  |  |  | 1.75 |  |  |  | 249,975 |  |
|  |  |  |  |  |  |  | 850,879 |  |  |  |  |  |  |  | 1,500,854 |  |
| Less: Long-term debt unamortized discount |  |  |  |  |  |  | (814 | ) |  |  |  |  |  |  | (11,943 | ) |
| Long-term debt unamortized debt issuance costs |  |  |  |  |  |  | (7,212 | ) |  |  |  |  |  |  | (12,974 | ) |
|  |  |  |  |  |  |  | 842,853 |  |  |  |  |  |  |  | 1,475,937 |  |
| Less: current maturities |  |  |  |  |  |  | — |  |  |  |  |  |  |  | (249,975 | ) |
| Long-term debt, less current maturities |  |  |  |  |  | $ | 842,853 |  |  |  |  |  |  | $ | 1,225,962 |  |

[0001564590-21-007045:notes:145]
The fiscal calendar maturities of long-term debt through 2025 and thereafter are as follows:

[0001564590-21-007045:notes:146]
|  |  | (In thousands) |  |
| 2021 |  | $ | — |  |
| 2022 |  |  | — |  |
| 2023 |  |  | — |  |
| 2024 |  |  | 475,879 |  |
| 2025 |  |  | 375,000 |  |
| Thereafter |  |  | — |  |
|  |  | $ | 850,879 |  |

[0001564590-21-007045:notes:147]
As of December 28, 2020, the Company was in compliance with the financial covenants under the Term Loan Facility, Senior Notes and ABL Revolving Loans.

[0001564590-21-007045:notes:148]
Term Loan Facility

[0001564590-21-007045:notes:149]
On April 18, 2018, the Company closed its $600,000 commitment of incremental loans concurrent with the completion of its acquisition of Anaren. At issuance, these incremental loans increased the Company’s existing balance of its Term Loan Facility due 2024 from $348,250 to $948,250. The Term Loan Facility had an outstanding balance of $405,879 as of December 28, 2020 and is included in long-term debt. The Term Loan Facility was issued at a weighted average discount of 99.7% and bears interest, at the

[0001564590-21-007045:notes:150]
Company’s option, at a floating rate of LIBOR plus an applicable interest margin of 2.5%, or an alternate base rate (as defined in the Term Loan Credit Agreement) plus an applicable margin of 1.5%. As of December 28, 2020, the interest rate on the outstanding borrowings under the Term Loan Facility was 2.65%. There is no provision, other than an event of default, for the interest margin to increase. The Term Loan Facility will mature on September 28, 2024. The Term Loan Facility is secured by a significant amount of the domestic assets of the Company and a pledge of 65% of voting stock of the Company’s first tier foreign subsidiaries and is structurally senior to the Company’s Senior Notes and Convertible Senior Notes. See Senior Notes and Convertible Senior Notes below.

[0001564590-21-007045:notes:151]
The Company has twelve months to reinvest the cash proceeds received from the sale of the Mobility business unit. If the proceeds are not reinvested, the Company is required to use the proceeds to prepay the Term Loan. The Company used a portion of the cash proceeds to repay $400,000 of the Term Loan during the year ended December 28, 2020 and plans to use the remaining cash proceeds for reinvestment. Permitted investments, as defined in the Term Loan Credit Agreement, include extensions of trade credit in the ordinary course of business, investments in cash and cash equivalents, permitted acquisitions, investments in assets useful in the business of the Company and its restricted subsidiaries, investments in joint ventures and unrestricted subsidiaries among others.

[0001564590-21-007045:notes:152]
Based on certain parameters defined in the Term Loan Facility, including a First Lien Leverage Ratio, the Company may be required to make an additional principal payment on an annual basis beginning after fiscal year 2018, if the Company’s First Lien Leverage Ratio is greater than 2.0. For 2020, the Company is not required to make an additional principal payment as its First Lien Leverage Ratio was less than 2.0. Any remaining outstanding balance under the Term Loan Facility is due at the maturity date of September 28, 2024.

[0001564590-21-007045:notes:153]
Borrowings under the Term Loan Facility are subject to certain affirmative and negative covenants, including limitations on indebtedness, corporate transactions, investments, dispositions, and share payments.

[0001564590-21-007045:notes:154]
Senior Notes

[0001564590-21-007045:notes:155]
The $375,000 of Senior Notes issued, which is included in long-term debt, bear interest at a rate of 5.63% per annum. Interest is payable semiannually in arrears on April 1 and October 1 of each year beginning April 1, 2018. The Senior Notes will mature on October 1, 2025.

[0001564590-21-007045:notes:156]
Borrowings under the Senior Notes are subject to certain affirmative and negative covenants, including limitations on indebtedness, corporate transactions, investments, dispositions, and share payments.

[0001564590-21-007045:notes:157]
Convertible Senior Notes due 2020

[0001564590-21-007045:notes:158]
The Convertible Senior Notes bore interest at a rate of 1.75% per annum. Interest was payable semiannually in arrears on June 15 and December 15 of each year. The Convertible Senior Notes were unsecured obligations that ranked equally to the Company’s future unsecured senior indebtedness and were senior in right of payment to any of the Company’s future subordinated indebtedness. Offering expenses were amortized to interest expense over the term of the Convertible Senior Notes. The Convertible Senior Notes matured and were repaid in cash in the amount of $249,975 on December 15, 2020.

[0001564590-21-007045:notes:159]
Convertible Note Hedge and Warrant Transaction:    In connection with the issuance of the Convertible Senior Notes due 2020, the Company entered into a convertible note hedge and warrant transaction (Call Spread Transaction), with respect to the Company’s common stock. The convertible note hedge consisted of the Company’s option to purchase up to 25,939 common stock shares at a price of $9.64 per share. The hedge could only be executed upon the conversion of the above mentioned Convertible Senior Notes due 2020 and it expired unexercised on December 15, 2020. Additionally, the Company sold equity-classified warrants to purchase 25,940 shares of its common stock at a price of $14.26 per share. Although the Convertible Senior Notes are no longer outstanding, these warrants remain outstanding and expire ratably from March 2021 through January 2022. The Call Spread Transaction had no effect on the terms of the Convertible Senior Notes due 2020.

[0001564590-21-007045:notes:160]
The components of interest expense resulting from the Convertible Senior Notes for the years ended December 28, 2020, December 30, 2019 and December 31, 2018 were as follows:

[0001564590-21-007045:notes:161]
|  |  | For the Year Ended |  |
|  |  | December 28, |  |  | December 30, |  |  | December 31, |  |
|  |  | 2020 |  |  | 2019 |  |  | 2018 |  |
|  |  | (In thousands) |  |
| Contractual coupon interest |  | $ | 4,180 |  |  | $ | 4,374 |  |  | $ | 4,375 |  |
| Amortization of debt discount |  | $ | 9,926 |  |  | $ | 9,751 |  |  | $ | 9,142 |  |
| Amortization of debt issuance costs |  | $ | 995 |  |  | $ | 977 |  |  | $ | 916 |  |

[0001564590-21-007045:notes:162]
Asset-Based Lending Agreements

[0001564590-21-007045:notes:163]
During June 2019, the Company amended its U.S. Asset-Based Lending Credit Agreement (U.S. ABL) and its Asia Asset-Based Lending Credit Agreement (Asia ABL) (collectively the ABL Revolving Loans). The U.S. ABL credit facility was amended to extend its maturity to June 2024 and decrease the size of the revolving credit facility to $150,000. The Asia ABL credit facility was amended to extend the maturity to June 2024.

[0001564590-21-007045:notes:164]
The U.S. ABL consists of two tranches comprised of a revolving credit facility for up to $150,000 and a letter of credit facility for up to $50,000, provided that at no time may amounts outstanding under the tranches exceed in aggregate $150,000 or the applicable borrowing base, which is a percentage of the principal amount of Eligible Accounts, as defined in the U.S. ABL agreement. Borrowings under the U.S. ABL bear interest at either a floating rate of LIBOR plus a margin of 125 basis points or an alternate base rate (defined as the greater of the prime rate, the New York Fed bank rate plus 0.5% or LIBOR plus 1.0%) subject to a 1.0% floor, plus an applicable margin of 25 basis points, at the Company’s option. As of December 28, 2020, the interest rate on the outstanding borrowings under the U.S. ABL was 1.40%. The applicable margin can vary based on the remaining availability of the facility, from 125 to 150 basis points for LIBOR-based loans and from 25 to 50 basis points for JP Morgan Chase Bank’s prime rate-based loans. Other than availability and an event of default, there are no other provisions for the interest margin to increase. The U.S. ABL will mature on June 3, 2024. Loans made under the U.S. ABL are secured first by all of the Company’s domestic cash, receivables and certain inventories as well as by a second position against a significant amount of the domestic assets of the Company and a pledge of 65% of the voting stock of the Company’s first tier foreign subsidiaries and are structurally senior to the Company’s Senior Notes and Convertible Senior Notes. See Senior Notes and Convertible Senior Notes above. As of December 28, 2020, $40,000 under the U.S. ABL was outstanding and classified as long-term debt, which is consistent with its maturity date.

[0001564590-21-007045:notes:165]
The Asia ABL consists of two tranches comprised of a revolving credit facility for up to $150,000 and a letter of credit facility for up to $100,000, provided that at no time may amounts outstanding under both tranches exceed in aggregate $150,000 or the applicable borrowing base, which is a percentage of the principal amount of Eligible Accounts, as defined in the Asia ABL agreement. Borrowings under the Asia ABL bear interest at a floating rate of LIBOR plus 140 basis points. As of December 28, 2020, the interest rate on the outstanding borrowings under the Asia ABL was 1.55%. There is no provision, other than an event of default, for the interest margin to increase. The Asia ABL will mature on June 4, 2024. Loans made under the Asia ABL are secured by a portion of the Company’s Asia Pacific cash and receivables and are structurally senior to the Company’s domestic obligations, including the Senior Notes and Convertible Senior Notes. See Senior Notes and Convertible Senior Notes above. As of December 28, 2020, $30,000 under the Asia ABL was outstanding and classified as long-term debt, which is consistent with its maturity date.

[0001564590-21-007045:notes:166]
As of December 28, 2020, letters of credit in the amount of $11,329 were outstanding under the U.S. ABL and $13,042 were outstanding under the Asia ABL with various expiration dates through May 2021. Available borrowing capacity under the U.S. ABL and the Asia ABL was $98,671 and $106,958, respectively, which considers letters of credit outstanding as of December 28, 2020.

[0001564590-21-007045:notes:167]
The Company is required to pay a commitment fee of 0.25% per annum on any unused portion of the U.S. ABL and 0.28% per annum on any unused portion of the Asia ABL. The Company incurred total commitment fees related to unused borrowing availability of $541, $703 and $992 for the years ended December 28, 2020, December 30, 2019 and December 31, 2018, respectively. Under the occurrence of certain events, the ABL Revolving Loans are subject to various financial and operational covenants, including maintaining minimum fixed charge coverage ratios.

[0001564590-21-007045:notes:168]
Debt Issuance and Debt Discount

[0001564590-21-007045:notes:169]
As of December 28, 2020 and December 30, 2019, remaining unamortized debt discount and debt issuance costs for the Term Loan Facility, Senior Notes, and Convertible Senior Notes are as follows:

[0001564590-21-007045:notes:170]
|  |  | As of December 28, 2020 |  |  | As of December 30, 2019 |
|  |  | Debt Issuance Costs |  |  | Debt Discount |  |  | Effective Interest Rate |  |  | Debt Issuance Costs |  |  | Debt Discount |  |  | Effective Interest Rate |  |  |
|  |  | (In thousands, except interest rates) |
| Term Loan due September 2024 |  | $ | 2,695 |  |  | $ | 814 |  |  |  | 4.66 |  | % | $ | 6,663 |  |  | $ | 2,016 |  |  |  | 4.66 |  | % |
| Senior Notes due October 2025 |  |  | 4,517 |  |  | — |  |  |  | 5.92 |  |  |  | 5,316 |  |  | — |  |  |  | 5.92 |  |  |
| Convertible Senior Notes due December 2020 |  | — |  |  | — |  |  | — |  |  |  | 995 |  |  |  | 9,927 |  |  |  | 6.48 |  |  |
|  |  | $ | 7,212 |  |  | $ | 814 |  |  |  |  |  |  | $ | 12,974 |  |  | $ | 11,943 |  |  |  |  |  |  |

[0001564590-21-007045:notes:171]
The above debt discount and debt issuance costs are recorded as a reduction of the debt and are amortized into interest expense using an effective interest rate over the duration of the debt.

[0001564590-21-007045:notes:172]
Remaining unamortized debt issuance costs for the ABL Revolving Loans of $1,919 and $2,511 as of December 28, 2020 and December 30, 2019, respectively, are included in other non-current assets and are amortized to interest expense over the duration of the ABL Revolving Loans using the straight line method of amortization.

[0001564590-21-007045:notes:173]
As of December 28, 2020, the remaining weighted average amortization period for all unamortized debt discount and debt issuance costs was 4.1 years.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001564590-21-007045:notes:174]
| (8) | Income Taxes |

[0001564590-21-007045:notes:175]
The components of (loss) income from continuing operations before income taxes for the years ended December 28, 2020, December 30, 2019 and December 31, 2018 are:

[0001564590-21-007045:notes:176]
|  |  | For the Year Ended |  |
|  |  | December 28, 2020 |  |  | December 30, 2019 |  |  | December 31, 2018 |  |
|  |  | (In thousands) |  |
| United States |  | $ | (84,582 | ) |  | $ | 16,066 |  |  | $ | 18,991 |  |
| Foreign |  |  | 38,305 |  |  |  | 18,260 |  |  |  | 28,194 |  |
| (Loss) income from continuing operations before income taxes |  | $ | (46,277 | ) |  | $ | 34,326 |  |  | $ | 47,185 |  |

[0001564590-21-007045:notes:177]
The Company expects its earnings attributable to foreign subsidiaries will be indefinitely reinvested, except for its material Chinese and Canadian plants and the respective holding companies where a deferred tax liability of approximately $2,458 and $1,548 has been recorded for the foreign and U.S. federal/state impact, respectively. For those other companies with earnings currently being reinvested outside of the U.S., the undistributed earnings amounted to approximately $60,769 as of December 28, 2020. The determination of the unrecognized deferred tax liability related to these undistributed earnings is approximately $2,797.

[0001564590-21-007045:notes:178]
The components of income tax benefit (provision) for the years ended December 28, 2020, December 30, 2019 and
December 31, 2018 are:

[0001564590-21-007045:notes:179]
|  |  | For the Year Ended |  |
|  |  | December 28, 2020 |  |  | December 30, 2019 |  |  | December 31, 2018 |  |
|  |  | (In thousands) |  |
| Current benefit (provision): |  |  |  |  |  |  |  |  |  |  |  |  |
| Federal |  | $ | (44 | ) |  | $ | 294 |  |  | $ | 381 |  |
| State |  |  | (4,624 | ) |  |  | (2,922 | ) |  |  | (1,294 | ) |
| Foreign |  |  | 27,902 |  |  |  | (12,748 | ) |  |  | (9,587 | ) |
| Total current |  |  | 23,234 |  |  |  | (15,376 | ) |  |  | (10,500 | ) |
| Deferred benefit (provision): |  |  |  |  |  |  |  |  |  |  |  |  |
| Federal |  |  | 2,446 |  |  |  | 1,004 |  |  |  | 97,723 |  |
| State |  |  | 4,498 |  |  |  | (1,076 | ) |  |  | 14,351 |  |
| Foreign |  |  | (287 | ) |  |  | 13,043 |  |  |  | (13,367 | ) |
| Total deferred |  |  | 6,657 |  |  |  | 12,971 |  |  |  | 98,707 |  |
| Income tax benefit (provision) |  | $ | 29,891 |  |  | $ | (2,405 | ) |  | $ | 88,207 |  |

[0001564590-21-007045:notes:180]
The following is a reconciliation of the provision for income taxes at the statutory federal income tax rate compared to the Company’s provision for income taxes for the years ended December 28, 2020, December 30, 2019 and December 31, 2018:

[0001564590-21-007045:notes:181]
|  |  | For the Year Ended |  |
|  |  | December 28, 2020 |  |  | December 30, 2019 |  |  | December 31, 2018 |  |
|  |  | (In thousands) |  |
| Statutory federal income tax benefit (provision) |  | $ | 9,718 |  |  | $ | (7,209 | ) |  | $ | (9,909 | ) |
| State income taxes, net of federal benefit and state tax credits |  |  | (2,674 | ) |  |  | (3,163 | ) |  |  | (1,953 | ) |
| Transfer pricing |  |  | — |  |  |  | — |  |  |  | 1,483 |  |
| Acquisition related expenses |  |  | — |  |  |  | — |  |  |  | (1,737 | ) |
| IRC Section 162(m) limitation |  |  | (712 | ) |  |  | (868 | ) |  |  | (3,702 | ) |
| Stock options |  |  | (1,298 | ) |  |  | (252 | ) |  |  | 1,072 |  |
| Global Intangible Low-Taxed Income |  |  | (1,300 | ) |  |  | — |  |  |  | — |  |
| Permanently reinvested earnings assertion |  |  | (1,442 | ) |  |  | (1,765 | ) |  |  | (14,313 | ) |
| Foreign tax differential on foreign earnings & other permanent items |  |  | 3,933 |  |  |  | 687 |  |  |  | (3,685 | ) |
| Change in valuation allowance |  |  | (2,668 | ) |  |  | 2,127 |  |  |  | 118,451 |  |
| Uncertain tax positions |  |  | 36,936 |  |  |  | 999 |  |  |  | (954 | ) |
| Federal research and development credits |  |  | 4,250 |  |  |  | 4,582 |  |  |  | 2,996 |  |
| Goodwill impairment |  |  | (14,532 | ) |  |  | — |  |  |  | — |  |
| Other |  |  | (320 | ) |  |  | 2,457 |  |  |  | 458 |  |
| Income tax benefit (provision) |  | $ | 29,891 |  |  | $ | (2,405 | ) |  | $ | 88,207 |  |

[0001564590-21-007045:notes:182]
Deferred income taxes reflect the net tax effects of temporary differences between the carrying amounts of assets and liabilities for financial reporting purposes and the amounts used for income tax purposes. The significant components of the net deferred income tax assets (liabilities) as of December 28, 2020 and December 30, 2019 are as follows:

[0001564590-21-007045:notes:183]
|  |  | As of |  |
|  |  | December 28, 2020 |  |  | December 30, 2019 |  |
|  |  | (In thousands) |  |
| Deferred income tax assets: |  |  |  |  |  |  |  |  |
| Net operating loss carryforwards |  | $ | 43,209 |  |  | $ | 78,774 |  |
| Reserves and accruals |  |  | 29,429 |  |  |  | 24,765 |  |
| Interest expense limitation |  |  | — |  |  |  | 13,102 |  |
| Unrealized loss on cash flow hedge |  |  | 4,713 |  |  |  | 2,960 |  |
| Tax credit carryforwards |  |  | 39,757 |  |  |  | 37,889 |  |
| Stock-based compensation |  |  | 4,216 |  |  |  | 4,440 |  |
| Original issue discount on Convertible Senior Notes |  |  | 90 |  |  |  | 870 |  |
| Property, plant and equipment |  |  | 9,989 |  |  |  | 14,404 |  |
| Other deferred income tax assets |  |  | 403 |  |  |  | 756 |  |
|  |  |  | 131,806 |  |  |  | 177,960 |  |
| Less: valuation allowance |  |  | (15,322 | ) |  |  | (14,292 | ) |
|  |  |  | 116,484 |  |  |  | 163,668 |  |
| Deferred income tax liabilities: |  |  |  |  |  |  |  |  |
| Repatriation of foreign earnings |  |  | (4,006 | ) |  |  | (9,691 | ) |
| Property, plant and equipment basis differences |  |  | (50,463 | ) |  |  | (56,476 | ) |
| Goodwill and intangible amortization |  |  | (39,668 | ) |  |  | (73,263 | ) |
| Other deferred income tax liabilities |  |  | (5,700 | ) |  |  | (102 | ) |
| Net deferred income tax assets (included in Deposits and other non-current assets) |  | $ | 16,647 |  |  | $ | 24,136 |  |

[0001564590-21-007045:notes:184]
As of December 28, 2020, the Company had the following net operating loss (NOL) carryforwards: $117,908 in the U.S. for federal, $25,723 in various U.S. states, $47,957 in China, and $26,940 in Hong Kong. The U.S. federal NOLs expire in 2027 through 2036, the various U.S. states’ NOLs expire in 2021 through 2036, the China NOLs expire in 2021 through 2027, and the Hong Kong NOLs carryforward indefinitely. Further, the Company’s tax credits were approximately $48,580, of which $6,233 carryforward indefinitely.

[0001564590-21-007045:notes:185]
In connection with the Company’s acquisition of Viasystems during 2015, there was more than a 50% change in ownership under Section 382 of the Internal Revenue Code of 1986, as amended, and regulations issued there under. As a consequence, the utilization of the acquired Viasystems U.S. NOLs is limited to approximately $9,826 per year. In addition, the Company recognized certain gains built in at the time of the ownership change, which increase the limitation by approximately $47,463 for each of the first 5 years after the acquisition. Any unused limitation in a year can be carried over to succeeding years.

[0001564590-21-007045:notes:186]
A valuation allowance is provided when it is more likely than not that all or some portion of the deferred income tax assets will not be realized. During the year ended December 31, 2018, the Company released a majority of its valuation allowance recorded on its U.S. net deferred tax assets due to a combination of the Company’s expectations for future U.S. taxable income improvement and to offset the net deferred tax liability acquired as a result of the Anaren acquisition. It continues to maintain a valuation allowance on certain of its U.S. net deferred tax assets represented by income tax attributes carried forward that are expected to expire unused. Certain subsidiaries within China continue to have NOL carryforwards in various tax jurisdictions that the Company has determined are not more likely than not to be utilized. As a result, a full valuation allowance has been recorded for these subsidiaries as of December 28, 2020. For the remaining net deferred income tax asset, management has determined that it is more likely than not that the results of future operations will generate sufficient taxable income to realize the net deferred tax asset.

[0001564590-21-007045:notes:187]
The following summarizes the activity in the Company’s valuation allowance for the years ended December 28, 2020, December 30, 2019 and December 31, 2018:

[0001564590-21-007045:notes:188]
|  |  | For the Year Ended |  |
|  |  | December 28, 2020 |  |  | December 30, 2019 |  |  | December 31, 2018 |  |
|  |  | (In thousands) |  |
| Balance at beginning of year |  | $ | 14,292 |  |  | $ | 16,635 |  |  | $ | 152,728 |  |
| Reduction related to acquisition |  |  | — |  |  |  | — |  |  |  | (76,040 | ) |
| Additions charged to expense |  |  | 3,904 |  |  |  | 1,526 |  |  |  | — |  |
| Other reduction charged to expense |  |  | (2,874 | ) |  |  | (3,869 | ) |  |  | (60,053 | ) |
| Balance at end of year |  | $ | 15,322 |  |  | $ | 14,292 |  |  | $ | 16,635 |  |

[0001564590-21-007045:notes:189]
Certain entities within China qualified for the high and new technology enterprise (HNTE) status enabling those entities to enjoy certain benefits, which were effective for the years ended December 28, 2020, December 30, 2019 and December 31, 2018. The HNTE status as well as enhanced research and development (R&D) deductions decreased Chinese taxes. HNTE and R&D benefit and effect on earnings per share are as follows:

[0001564590-21-007045:notes:190]
|  |  | For the Year Ended |  |
|  |  | December 28, 2020 |  |  | December 30, 2019 |  |  | December 31, 2018 |  |
|  |  | (In thousands, except per share data) |  |
| HNTE and R&D benefits |  | $ | 4,235 |  |  | $ | 6,060 |  |  | $ | 7,277 |  |
| Basic shares |  |  | 106,366 |  |  |  | 105,195 |  |  |  | 103,355 |  |
| Diluted shares |  |  | 106,366 |  |  |  | 106,332 |  |  |  | 134,036 |  |
| Increases earnings per share: |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  | $ | 0.04 |  |  | $ | 0.06 |  |  | $ | 0.07 |  |
| Diluted |  | $ | 0.04 |  |  | $ | 0.06 |  |  | $ | 0.05 |  |

[0001564590-21-007045:notes:191]
HNTE status expires at various dates in 2020 through 2021, but the Company expects to continue to file for renewal of such HNTE status for the foreseeable future.

[0001564590-21-007045:notes:192]
A reconciliation of the beginning and ending amount of unrecognized tax benefits, exclusive of accrued interest and penalties, is as follows:

[0001564590-21-007045:notes:193]
|  |  | For the Year Ended |  |
|  |  | December 28, 2020 |  |  | December 30, 2019 |  |  | December 31, 2018 |  |
|  |  | (In thousands) |  |
| Balance at beginning of year |  | $ | 37,465 |  |  | $ | 30,284 |  |  | $ | 31,276 |  |
| Additions related to acquisition |  |  | — |  |  |  | — |  |  |  | 903 |  |
| Additions based on tax positions related to the current year |  |  | 839 |  |  |  | 3,553 |  |  |  | 856 |  |
| Additions for tax positions of prior years |  |  | 202 |  |  |  | 4,952 |  |  |  | 117 |  |
| Reductions for tax positions of prior years |  |  | (27,283 | ) |  |  | (103 | ) |  |  | (2,140 | ) |
| Lapse of statute of limitations |  |  | (3,819 | ) |  |  | (1,221 | ) |  |  | (728 | ) |
| Balance at end of year |  | $ | 7,404 |  |  | $ | 37,465 |  |  | $ | 30,284 |  |

[0001564590-21-007045:notes:194]
In the quarter ended December 28, 2020, the Company reduced prior years’ uncertain tax positions by $27,283 due to (i) conclusion of an examination resulting in no adjustment with the Canadian tax authority related to the pre-acquisition tax years of a Canadian subsidiary; and (ii) change in U.S. tax law related to IRC Section 163(j) with respect to the adjusted taxable income calculation.

[0001564590-21-007045:notes:195]
As of December 28, 2020 and December 30, 2019, the Company recorded unrecognized tax benefits of $1,046 and $25,805, respectively, as well as interest and penalties of $1,566 and $13,531, respectively, to current and long-term liabilities. The Company has also recorded unrecognized tax benefits of $6,358 and $19,225 against certain deferred tax assets as of December 28, 2020 and December 30, 2019, respectively. The amount of unrecognized tax benefits that would, if recognized, reduce the Company’s effective income tax rate in any future periods is $2,612 including interest and penalties. The Company expects its unrecognized tax benefits to decrease by $384 along with related interest of $701 over the next twelve months due to expiring statutes.

[0001564590-21-007045:notes:196]
As of December 28, 2020, the Company is open for (i) U.S. federal income tax examination for the period from 2017 to 2020 and NOL and credit carryforwards are subject to adjustment for 3 years post utilization, (ii) state and local income tax examination for tax years 2016 to 2020 and NOL and credit carryforwards are subject to adjustment for 4 years post utilization; and (iii) foreign income tax examinations generally for tax years from 2010 to 2020.


## us-gaap:FinancialInstrumentsDisclosureTextBlock

[0001564590-21-007045:notes:197]
| (9) | Financial Instruments |

[0001564590-21-007045:notes:198]
Derivatives

[0001564590-21-007045:notes:199]
Interest Rate Swaps

[0001564590-21-007045:notes:200]
The Company’s business is exposed to interest rate risk resulting from fluctuations in interest rates on certain LIBOR-based variable rate debt. Increases in interest rates would increase interest expenses relating to the outstanding variable rate borrowings and increase the cost of debt. Fluctuations in interest rates can also lead to significant fluctuations in the fair value of the debt obligations.

[0001564590-21-007045:notes:201]
On May 15, 2018, the Company entered into a four-year pay-fixed, receive floating (1-month LIBOR), interest rate swap arrangement with a notional amount of $400,000 for the period beginning June 1, 2018 and ending on June 1, 2022. Under the terms of the interest rate swap, the Company pays a fixed rate of 2.84% against a portion of its LIBOR-based debt and receives floating 1-month LIBOR during the swap period.

[0001564590-21-007045:notes:202]
At inception, the Company designated the interest rate swap as a cash flow hedge and the fair value of the interest rate swap was zero. As of December 28, 2020, the fair value of the interest rate swap was recorded as a liability in the amount of $14,968 and included as a component of other long-term liabilities. The change in the fair value of the interest rate swap is recorded as a component of accumulated other comprehensive loss, net of tax, in the Company’s consolidated balance sheets. No ineffectiveness was recognized for the years ended December 28, 2020 and December 30, 2019. During the year ended December 28, 2020, the interest rate swap increased interest expense by $8,942.

[0001564590-21-007045:notes:203]
Foreign Exchange Contracts

[0001564590-21-007045:notes:204]
The Company enters into foreign currency forward contracts to mitigate the impact of changes in foreign currency exchange rates and to reduce the volatility of purchases and other obligations generated in currencies other than its functional currencies. The Company’s foreign subsidiaries may at times purchase forward exchange contracts to manage their foreign currency risks in relation to certain purchases of machinery denominated in foreign currencies other than the Company’s functional currencies. The notional amount of the foreign exchange contracts as of December 28, 2020 and December 30, 2019 was approximately $1,181 (Japanese Yen (JPY) 125.0 million) and $1,994 (JPY 215.8 million), respectively. The Company has designated certain of these foreign exchange contracts as cash flow hedges.

[0001564590-21-007045:notes:205]
The fair values of derivative instruments in the consolidated balance sheets are as follows:

[0001564590-21-007045:notes:206]
|  |  |  |  | Asset/(Liability) Fair Value |  |
|  |  | Balance Sheet Location |  | December 28, 2020 |  |  | December 30, 2019 |  |
|  |  |  |  | (In thousands) |  |
| Cash flow derivative instruments designated as hedges: |  |  |  |  |  |  |  |  |
| Interest rate swap |  | Other long-term liabilities |  | $ | (14,968 | ) |  | $ | (12,067 | ) |
| Cash flow derivative instruments not designated as hedges: |  |  |  |  |  |  |  |  |
| Foreign exchange contracts |  | Prepaid expenses and other current assets |  |  | 28 |  |  |  | 1 |  |
| Foreign exchange contracts |  | Other current liabilities |  |  | — |  |  |  | (3 | ) |

[0001564590-21-007045:notes:207]
The following table provides information about the amounts recorded in accumulated other comprehensive loss related to derivatives designated as cash flow hedges, as well as the amounts recorded in each caption in the consolidated statements of operations when derivative amounts are reclassified out of accumulated other comprehensive loss for the years ended December 28, 2020, December 30, 2019 and December 31, 2018:

[0001564590-21-007045:notes:208]
|  |  |  | For the Year Ended |  |  |
|  |  |  | December 28, 2020 |  |  | December 30, 2019 |  |  | December 31, 2018 |  |  |
|  |  | Financial Statement Caption | Loss Recognized in Other Comprehensive Loss |  |  | Loss Reclassified into Income |  |  | Loss Recognized in Other Comprehensive Loss |  |  | Loss Reclassified into Income |  |  | Loss Recognized in Other Comprehensive Loss |  |  | Loss Reclassified into Income |  |  |
|  |  |  | (In thousands) |
| Cash flow hedge: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Interest rate swap |  | Interest expense | $ | (11,843 | ) |  | $ | (8,942 | ) |  | $ | (9,647 | ) |  | $ | (2,315 | ) |  | $ | (6,333 | ) |  | $ | (1,598 | ) |  |

[0001564590-21-007045:notes:209]
The following table provides a summary of the activity associated with the designated cash flow hedges reflected in accumulated other comprehensive loss for the years ended December 28, 2020, December 30, 2019 and December 31, 2018:

[0001564590-21-007045:notes:210]
|  |  | For the Year Ended |  |
|  |  | December 28, |  |  | December 30, |  |  | December 31, |  |
|  |  | 2020 |  |  | 2019 |  |  | 2018 |  |
|  |  | (In thousands) |  |
| Beginning balance, net of tax |  | $ | (9,617 | ) |  | $ | (4,214 | ) |  | $ | (742 | ) |
| Changes in fair value loss, net of tax |  |  | (8,718 | ) |  |  | (7,296 | ) |  |  | (4,846 | ) |
| Reclassification to earnings |  |  | 6,720 |  |  |  | 1,893 |  |  |  | 1,374 |  |
| Derecognition of unrealized losses on cash flow hedge due to sale of Mobility business unit |  |  | 384 |  |  | — |  |  | — |  |
| Ending balance, net of tax |  | $ | (11,231 | ) |  | $ | (9,617 | ) |  | $ | (4,214 | ) |

[0001564590-21-007045:notes:211]
Based on the current yield curve, the Company expects that losses of approximately $8,001 of accumulated other comprehensive loss will be reclassified into the statement of operations, net of tax, in the next twelve months.


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0001564590-21-007045:notes:212]
| (10) | Accumulated Other Comprehensive Loss |

[0001564590-21-007045:notes:213]
The following provides a summary of the components of accumulated other comprehensive loss, net of tax as of December 28, 2020, December 30, 2019 and December 31, 2018:

[0001564590-21-007045:notes:214]
|  |  | Foreign Currency Translation |  |  | Pension Obligation |  |  | (Losses) Gains on Cash Flow Hedges |  |  | Total |  |
|  |  | (In thousands) |  |
| Ending balance as of December 31, 2018 |  | $ | 1,578 |  |  | $ | (1,284 | ) |  | $ | (4,214 | ) |  | $ | (3,920 | ) |
| Other comprehensive loss before reclassifications |  |  | (463 | ) |  |  | (300 | ) |  |  | (7,296 | ) |  |  | (8,059 | ) |
| Amounts reclassified from accumulated other comprehensive income |  |  | — |  |  |  | — |  |  |  | 1,893 |  |  |  | 1,893 |  |
| Net year to date other comprehensive loss |  |  | (463 | ) |  |  | (300 | ) |  |  | (5,403 | ) |  |  | (6,166 | ) |
| Ending balance as of December 30, 2019 |  |  | 1,115 |  |  |  | (1,584 | ) |  |  | (9,617 | ) |  |  | (10,086 | ) |
| Other comprehensive gain (loss) before reclassifications |  |  | 1,745 |  |  |  | (1,271 | ) |  |  | (8,718 | ) |  |  | (8,244 | ) |
| Amounts reclassified from accumulated other comprehensive income |  |  | — |  |  |  | — |  |  |  | 6,720 |  |  |  | 6,720 |  |
| Reclassification adjustment for foreign currency translation |  |  | (346 | ) |  |  | — |  |  |  | — |  |  |  | (346 | ) |
| Derecognition of foreign currency translation adjustments due to sale of Mobility business unit |  |  | (27,341 | ) |  |  | — |  |  |  | — |  |  |  | (27,341 | ) |
| Derecognition of unrealized losses on cash flow hedge due to sale of Mobility business unit |  |  | — |  |  |  | — |  |  |  | 384 |  |  |  | 384 |  |
| Net year to date other comprehensive loss |  |  | (25,942 | ) |  |  | (1,271 | ) |  |  | (1,614 | ) |  |  | (28,827 | ) |
| Ending balance as of December 28, 2020 |  | $ | (24,827 | ) |  | $ | (2,855 | ) |  | $ | (11,231 | ) |  | $ | (38,913 | ) |


## us-gaap:ConcentrationRiskDisclosureTextBlock

[0001564590-21-007045:notes:215]
| (11) | Significant Customers and Concentration of Credit Risk |

[0001564590-21-007045:notes:216]
In the normal course of business, the Company extends credit to its customers. Some customers to which the Company extends credit are located outside the United States. The Company performs ongoing credit evaluations of customers, does not require collateral, and considers the credit risk profile of the entity from which the receivable is due in further evaluating collection risk.

[0001564590-21-007045:notes:217]
The Company’s customers include both OEMs and EMS companies. The Company’s OEM customers often direct a significant portion of their purchases through EMS companies. While the Company’s customers include both OEM and EMS providers, the Company measures customer concentration based on OEM companies, as they are the ultimate end customers.

[0001564590-21-007045:notes:218]
For the year ended December 28, 2020, one customer accounted for approximately 11% of the Company’s net sales. These sales are included in the Company’s PCB segment. There were no other customers that accounted for 10% or more of net sales for the year ended December 28, 2020. There were no customers that accounted for 10% or more of net sales for the years ended December 30, 2019 or December 31, 2018.


## us-gaap:FairValueDisclosuresTextBlock

[0001564590-21-007045:notes:219]
| (12) | Fair Value Measures |

[0001564590-21-007045:notes:220]
The Company measures at fair value its financial and non-financial assets by using a fair value hierarchy that prioritizes the inputs to valuation techniques used to measure fair value. Fair value is the price that would be received to sell an asset or paid to transfer a liability in an orderly transaction between market participants at the measurement date, essentially an exit price, based on the highest and best use of the asset or liability.

[0001564590-21-007045:notes:221]
The carrying amount and estimated fair value of the Company’s financial instruments as of December 28, 2020 and December 30, 2019 were as follows:

[0001564590-21-007045:notes:222]
|  |  | As of |  |  | As of |  |
|  |  | December 28, 2020 |  |  | December 30, 2019 |  |
|  |  | Carrying Amount |  |  | Fair Value |  |  | Carrying Amount |  |  | Fair Value |  |
|  |  | (In thousands) |  |
| Derivative assets, current |  | $ | 28 |  |  | $ | 28 |  |  | $ | 1 |  |  | $ | 1 |  |
| Derivative liabilities, current |  |  | — |  |  |  | — |  |  |  | 3 |  |  |  | 3 |  |
| Derivative liabilities, non-current |  |  | 14,968 |  |  |  | 14,968 |  |  |  | 12,067 |  |  |  | 12,067 |  |
| Term Loan due September 2024 |  |  | 402,370 |  |  |  | 407,909 |  |  |  | 797,200 |  |  |  | 808,901 |  |
| Senior Notes due October 2025 |  |  | 370,483 |  |  |  | 383,974 |  |  |  | 369,684 |  |  |  | 390,143 |  |
| ABL Revolving Loans |  |  | 70,000 |  |  |  | 70,000 |  |  |  | 70,000 |  |  |  | 70,000 |  |
| Convertible Senior Notes due December 2020 |  |  | — |  |  |  | — |  |  |  | 239,053 |  |  |  | 391,686 |  |

[0001564590-21-007045:notes:223]
The fair value of the derivative instruments was determined using pricing models developed based on the LIBOR swap rate, foreign currency exchange rates, and other observable market data, including quoted market prices, as appropriate using Level 2 inputs. The values were adjusted to reflect non-performance risk of both the counterparty and the Company, as necessary.

[0001564590-21-007045:notes:224]
The fair value of the long-term debt was estimated based on quoted market prices or discounting the debt over its life using current market rates for similar debt as of December 28, 2020 and December 30, 2019, which are considered Level 2 inputs.

[0001564590-21-007045:notes:225]
The fair value of the Convertible Senior Notes was estimated based on quoted market prices of the securities on an active exchange, which are considered Level 2 inputs.

[0001564590-21-007045:notes:226]
The fair value of plan assets in the defined benefit plan of $23,484 and $21,287 as of December 28, 2020 and December 30, 2019, respectively, were not included in the table above and was estimated based on quoted market prices of the securities that are actively traded and price quotes that are readily available, which are considered Level 1 inputs. See Note 15 for further details of the plan assets measured at fair value in the defined benefit plan.

[0001564590-21-007045:notes:227]
As of December 28, 2020 and December 30, 2019, the Company’s other financial instruments also included cash and cash equivalents, accounts receivable, and accounts payable. Due to short-term maturities, the carrying amount of these instruments approximates fair value. The Company’s cash and cash equivalents as of December 28, 2020 consisted of $230,166 held in the U.S., with the remaining $221,399 held by foreign subsidiaries.

[0001564590-21-007045:notes:228]
The majority of the Company’s non-financial assets and liabilities, which include goodwill, intangible assets, inventories, and property, plant and equipment, are not required to be carried at fair value on a recurring basis. However, if certain triggering events occur (or are tested at least annually in the case of goodwill) such that a non-financial instrument is required to be evaluated for impairment, based upon a comparison of the non-financial instrument’s fair value to its carrying value, an impairment is recorded to reduce the carrying value to the fair value, if the carrying value exceeds the fair value.

[0001564590-21-007045:notes:229]
As of December 28, 2020, the Company’s goodwill balance related to its RF&S Components reporting unit of $108,000 was measured at fair value on a nonrecurring basis. The Company recorded a goodwill impairment charge of $69,200 during the year ended December 28, 2020. The fair value of goodwill was determined using both a DCF and a market approach, which are considered Level 3 inputs. The Company used risk adjusted discount rate of 19% to discount the expected future cash flows. There was no impairment of long-lived assets recognized for the years ended December 28, 2020, December 30, 2019 or December 31, 2018.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001564590-21-007045:notes:230]
| (13) | Commitments and Contingencies |

[0001564590-21-007045:notes:231]
Legal Matters

[0001564590-21-007045:notes:232]
The Company is subject to various legal matters, which it considers normal for its business activities. While the Company currently believes that the amount of any reasonably possible loss for known matters would not be material to the Company’s financial condition, the outcome of these actions is inherently difficult to predict. In the event of an adverse outcome, the ultimate potential loss could have a material adverse effect on the Company’s financial condition or results of operations in a particular period. The Company has accrued amounts for its loss contingencies which are probable and estimable as of December 28, 2020 and December 30, 2019. However, these amounts are not material to the consolidated financial statements of the Company.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001564590-21-007045:notes:233]
| (14) | Stock-Based Compensation |

[0001564590-21-007045:notes:234]
Incentive Compensation Plan

[0001564590-21-007045:notes:235]
The Company maintains a 2014 Incentive Compensation Plan (the Plan), which, with subsequent amendments, allows for issuance to 15,788 through its expiration date of February 2024.

[0001564590-21-007045:notes:236]
The Plan provides for the grant of incentive stock options and nonqualified stock options to the Company’s key employees, non-employee directors and consultants. Other types of awards such as performance-based restricted stock units (PRUs), restricted stock units (RSUs), and stock appreciation rights are also permitted. The exercise price for options and awards is determined by the compensation committee of the board of directors and, for options intended to qualify as incentive stock options, may not be less than the fair market value as determined by the closing stock price at the date of the grant. Each option and award shall vest and expire as determined by the compensation committee of the board of directors, with options, PRUs and RSUs generally vesting over three years for employees and one year for non-employee directors. Options, PRUs and RSUs do not have voting rights. Options expire no later than ten years from the grant date. All grants provide for accelerated vesting if there is a change in control, as defined in the Plan. Upon the exercise of outstanding stock options or vesting of RSUs and PRUs, the Company’s practice is to issue new registered shares that are reserved for issuance under the Plan.

[0001564590-21-007045:notes:237]
As of December 28, 2020, 426 PRUs, 3,121 RSUs and 60 stock options were outstanding under the Plan. Included in the 3,121 RSUs outstanding as of December 28, 2020 are 556 vested but not yet released RSUs associated with non-employee directors. These RSUs vest over one year with release of the underlying shares of common stock deferred until retirement from the board of directors, (or until one year after retirement in the case of certain prior grants).

[0001564590-21-007045:notes:238]
Performance-based Restricted Stock Units

[0001564590-21-007045:notes:239]
The Company maintains a long-term incentive program for executives that provides for the issuance of PRUs, representing hypothetical shares of the Company’s common stock that may be issued. Under the PRU program, a target number of PRUs is awarded at the beginning of each three-year performance period. The number of shares of common stock released at the end of the performance period may range from zero to 2.4 times the target number depending on performance during the period. The performance metrics of the PRU program are based on (a) annual financial targets, which are based on revenue and EBITDA (earnings before interest, tax, depreciation, and amortization expense), each equally weighted, and (b) an overall modifier based on the Company’s total stockholder return (TSR) relative to a group of peer companies selected by the Company’s compensation committee, over the three-year performance period.

[0001564590-21-007045:notes:240]
Under the PRU program, financial goals are set at the beginning of each fiscal year and performance is reviewed at the end of that year. The percentage to be applied to each participant’s target award ranges from zero to 160% based upon the extent to which the annual financial performance goals are achieved. If specific performance threshold levels for the annual financial goals are met, the amount earned for that element will be applied to one-third of the participants’ PRU award to determine the number of units earned.

[0001564590-21-007045:notes:241]
At the end of the three-year performance period, the total units earned, if any, are adjusted by applying a modifier, ranging from zero to 150% based on the Company’s TSR based on stock price changes relative to a group of peer companies selected by the Company’s compensation committee for the same three-year period.

[0001564590-21-007045:notes:242]
The TSR modifier is intended to ensure that there are limited or no payouts under the PRU program if the Company’s stock performance is significantly below the median TSR of a group of peer companies selected by the Company’s compensation committee over the three-year performance period. Where the annual financial goals have been met and where there has been strong relative TSR performance over the three-year performance period, the PRU program may provide substantial rewards to participants with a maximum payout of 2.4 times the initial PRU award. However, even if all of the annual financial metric goals are achieved in each of the three years, there will be no payouts if the Company’s stock performance is below that of the 10th percentile for PRUs granted in 2020, 2019 and 2018 of the group of peer companies selected by the Company’s compensation committee, as appropriate.

[0001564590-21-007045:notes:243]
Recipients of PRU awards generally must remain employed by the Company on a continuous basis through the end of the three-year performance period in order to receive any amount of the PRUs covered by that award. In events such as death, disability or retirement, the recipient may be entitled to pro-rata amounts of PRUs as defined in the Plan. Target shares subject to PRU awards do not have voting rights of common stock until earned and issued following the end of the three-year performance period.

[0001564590-21-007045:notes:244]
The Company records stock-based compensation expense for PRU awards granted based on management’s periodic assessment of the annual financial performance goals to be achieved. As of December 28, 2020, management determined that vesting of the PRU awards was probable. PRU activity for the year ended December 28, 2020 was as follows:

[0001564590-21-007045:notes:245]
|  |  | Shares |  |  | Weighted Average Fair Value |  |
|  |  | (In thousands) |  |  |  |  |  |
| Outstanding shares as of December 30, 2019 |  |  | 216 |  |  | $ | 12.14 |  |
| Granted |  |  | 303 |  |  |  | 10.57 |  |
| Vested |  |  | (137 | ) |  |  | 12.82 |  |
| Forfeited / cancelled |  |  | (22 | ) |  |  | 10.89 |  |
| Change in units due to annual performance achievement |  |  | (71 | ) |  |  | 12.12 |  |
| Outstanding shares as of December 28, 2020 |  |  | 289 |  |  | $ | 10.27 |  |

[0001564590-21-007045:notes:246]
The fair value of PRUs granted is calculated using a Monte Carlo simulation model, as the TSR modifier contains a market condition. For the years ended December 28, 2020, December 30, 2019 and December 31, 2018, the following assumptions were used in determining the fair value:

[0001564590-21-007045:notes:247]
|  |  | For the Year Ended |  |
|  |  | December 28, 2020 (1) |  |  | December 30, 2019 (2) |  |  | December 31, 2018 (3) |  |
| Weighted-average fair value |  | $ | 10.57 |  |  | $ | 10.17 |  |  | $ | 19.59 |  |
| Risk-free interest rate |  |  | 0.18 | % |  |  | 2.18 | % |  |  | 2.14 | % |
| Dividend yield |  |  | — |  |  |  | — |  |  |  | — |  |
| Expected volatility |  |  | 49 | % |  |  | 38 | % |  |  | 40 | % |

[0001564590-21-007045:notes:248]
| (1) | Reflects the weighted-averages for the third year of the three-year performance period applicable to PRUs granted in 2018, the second year of the three-year performance period applicable to PRUs granted in 2019 and the first year of the three-year performance period applicable to PRUs granted in 2020. |

[0001564590-21-007045:notes:249]
| (2) | Reflects the weighted-averages for the third year of the three-year performance period applicable to PRUs granted in 2017, the second year of the three-year performance period applicable to PRUs granted in 2018 and the first year of the three-year performance period applicable to PRUs granted in 2019. |

[0001564590-21-007045:notes:250]
| (3) | Reflects the weighted-averages for the third year of the three-year performance period applicable to PRUs granted in 2016, the second year of the three-year performance period applicable to PRUs granted in 2017 and the first year of the three-year performance period applicable to PRUs granted in 2018. |

[0001564590-21-007045:notes:251]
The risk-free interest rate for the expected term of PRUs is based on the U.S. Treasury yield curve in effect at the time of grant. Expected volatility is calculated using the Company’s historical stock price.

[0001564590-21-007045:notes:252]
Restricted Stock Units

[0001564590-21-007045:notes:253]
RSU activity for the year ended December 28, 2020 was as follows:

[0001564590-21-007045:notes:254]
|  |  | Shares |  |  | Weighted Average Grant-Date Fair Value |  |
|  |  | (In thousands) |  |  |  |  |  |
| Non-vested RSUs outstanding as of December 30, 2019 |  |  | 2,527 |  |  | $ | 11.91 |  |
| Granted |  |  | 1,474 |  |  |  | 11.20 |  |
| Vested |  |  | (1,141 | ) |  |  | 11.48 |  |
| Forfeited |  |  | (294 | ) |  |  | 11.42 |  |
| Non-vested RSUs outstanding as of December 28, 2020 |  |  | 2,566 |  |  | $ | 11.20 |  |
| Vested and expected to vest through 2023 as of December 28, 2020 |  |  | 3,121 |  |  | $ | 11.15 |  |

[0001564590-21-007045:notes:255]
The fair value of the Company’s RSUs is determined based upon the closing common stock price on the grant date. The weighted average fair value per unit of RSUs granted was $11.20, $10.09 and $15.35 for the years ended December 28, 2020, December 30, 2019 and December 31, 2018, respectively. The total fair value of RSUs vested for the years ended December 28, 2020, December 30, 2019 and December 31, 2018 was $13,093, $13,954 and $12,599, respectively.

[0001564590-21-007045:notes:256]
Stock Options

[0001564590-21-007045:notes:257]
As of December 28, 2020, stock options outstanding was 60. This is not material to the consolidated financial statements of the Company.

[0001564590-21-007045:notes:258]
Stock-based Compensation Expense and Unrecognized Compensation Costs

[0001564590-21-007045:notes:259]
For the years ended December 28, 2020, December 30, 2019 and December 31, 2018, the amounts recognized in the consolidated statements of operations with respect to the stock-based compensation plan are as follows:

[0001564590-21-007045:notes:260]
|  |  | For the Year Ended |  |
|  |  | December 28, |  |  | December 30, |  |  | December 31, |  |
|  |  | 2020 |  |  | 2019 |  |  | 2018 |  |
|  |  | (In thousands) |  |
| Cost of goods sold |  | $ | 3,889 |  |  | $ | 3,148 |  |  | $ | 2,893 |  |
| Selling and marketing |  |  | 1,919 |  |  |  | 1,887 |  |  |  | 1,902 |  |
| General and administrative |  |  | 10,083 |  |  |  | 11,568 |  |  |  | 15,676 |  |
| Research and development |  |  | 182 |  |  |  | 213 |  |  |  | 210 |  |
| Stock-based compensation expense recognized |  | $ | 16,073 |  |  | $ | 16,816 |  |  | $ | 20,681 |  |

[0001564590-21-007045:notes:261]
The following is a summary of total unrecognized compensation costs as of December 28, 2020:

[0001564590-21-007045:notes:262]
|  |  | Unrecognized Stock-Based Compensation Cost |  |  | Remaining Weighted Average Recognition Period |  |
|  |  | (In thousands) |  |  | (In years) |  |
| RSU awards |  | $ | 20,663 |  |  |  | 1.4 |  |
| PRU awards |  |  | 1,898 |  |  |  | 1.6 |  |
| Stock options |  |  | 131 |  |  |  | 1.2 |  |
|  |  | $ | 22,692 |  |  |  |  |  |


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0001564590-21-007045:notes:263]
| (15) | Employee Benefit Plans, Deferred Compensation Plan and Retirement Benefit Plan |

[0001564590-21-007045:notes:264]
As of December 28, 2020, the Company has several defined contribution plans. In North America, the Company has savings plans (the Savings Plans) in which eligible full-time employees can participate and contribute a percentage of compensation subject to the maximum allowed by the tax agencies. The Savings Plans provides for a partial match by the Company. In China, the Company contributes to either separate trust-administered funds or various government-sponsored pension plans on a mandatory basis. For all defined contribution plans, the Company has no further payment obligation once the required contributions have been made. The Company recorded contributions to defined contribution plans of $23,146, $31,253 and $33,106 during the years ended December 28, 2020, December 30, 2019 and December 31, 2018, respectively.

[0001564590-21-007045:notes:265]
The Company also maintains a deferred compensation plan (the Compensation Plan). The Compensation Plan is an unfunded, nonqualified deferred compensation plan and is limited to selected employees, including the Company’s named executive officers and directors. The Compensation Plan allows participants to defer up to 100% of their annual bonus and between 5% and 100% of their annual director fees. Amounts deferred under the Compensation Plan will be credited to accounts maintained by the Company for each participant and will be credited or debited with the participant’s proportionate share of any gains or losses attributable to the performance of investment options selected by the participant.

[0001564590-21-007045:notes:266]
Following the acquisition of Anaren on April 18, 2018, the Company has a noncontributory defined benefit pension plan covering eligible employees. Effective August 15, 2000, the plan was closed for new participants. Benefits under this plan generally are based on the employee’s years of service and compensation. Effective December 31, 2019, the plan is frozen as to further participation and to further benefit accruals.

[0001564590-21-007045:notes:267]
As of December 28, 2020 and December 30, 2019, the funded status of the accumulated benefit obligation was 70%. The Company expects to fund a minimum required contribution of approximately $567 during fiscal year 2021.

[0001564590-21-007045:notes:268]
The following tables set forth the changes in benefit obligation and the plan assets in the defined benefit plan described above for the years ended December 28, 2020, December 30, 2019 and December 31, 2018:

[0001564590-21-007045:notes:269]
|  |  | For the Year Ended |  |
| Change in Benefit Obligations |  | December 28, 2020 |  |  | December 30, 2019 |  |  | December 31, 2018 |  |
|  |  | (In thousands) |  |
| Benefit obligation at beginning of year |  | $ | (30,600 | ) |  | $ | (27,661 | ) |  | $ | (27,525 | ) |
| Service cost |  |  | — |  |  |  | (397 | ) |  |  | (292 | ) |
| Interest cost |  |  | (907 | ) |  |  | (1,109 | ) |  |  | (758 | ) |
| Amendments/curtailments/special termination |  |  | — |  |  |  | 1,636 |  |  |  | — |  |
| Actuarial (loss) gain |  |  | (3,146 | ) |  |  | (4,174 | ) |  |  | 264 |  |
| Benefits paid |  |  | 1,183 |  |  |  | 1,105 |  |  |  | 650 |  |
| Benefit obligation at end of year |  | $ | (33,470 | ) |  | $ | (30,600 | ) |  | $ | (27,661 | ) |
| Accumulated benefit obligation at end of year |  | $ | 33,470 |  |  | $ | 30,600 |  |  | $ | 26,191 |  |

[0001564590-21-007045:notes:270]
|  |  | For the Year Ended |  |
| Change in Plan Assets |  | December 28, 2020 |  |  | December 30, 2019 |  |  | December 31, 2018 |  |
|  |  | (In thousands) |  |
| Fair value of plan assets at beginning of year |  | $ | 21,287 |  |  | $ | 18,251 |  |  | $ | 19,643 |  |
| Actual return on plan assets |  |  | 2,704 |  |  |  | 3,346 |  |  |  | (1,021 | ) |
| Employer contributions |  |  | 676 |  |  |  | 795 |  |  |  | 279 |  |
| Benefits paid |  |  | (1,183 | ) |  |  | (1,105 | ) |  |  | (650 | ) |
| Fair value of plan assets at end of year |  | $ | 23,484 |  |  | $ | 21,287 |  |  | $ | 18,251 |  |
| Unfunded status |  | $ | (9,986 | ) |  | $ | (9,313 | ) |  | $ | (9,410 | ) |
| Net amount recognized |  | $ | (9,986 | ) |  | $ | (9,313 | ) |  | $ | (9,410 | ) |

[0001564590-21-007045:notes:271]
Amounts before income tax effect recognized in the consolidated balance sheets consists of the following:

[0001564590-21-007045:notes:272]
|  |  | As of |  |  | As of |  |  |
|  |  | December 28, 2020 |  |  | December 30, 2019 |  |  |
|  |  | (In thousands) |  |  |
| Other long-term liabilities |  | $ | (9,986 | ) |  | $ | (9,313 | ) |  |
| Net amount recognized |  | $ | (9,986 | ) |  | $ | (9,313 | ) |  |

[0001564590-21-007045:notes:273]
Amounts before income tax effect included in accumulated other comprehensive loss as of December 28, 2020 and
December 30, 2019 are as follows:

[0001564590-21-007045:notes:274]
|  |  | December 28, 2020 |  |  | December 30, 2019 |  |  |
|  |  | (In thousands) |  |  |
| Net actuarial loss |  | $ | (3,811 | ) |  | $ | (2,097 | ) |  |
| Accumulated other comprehensive loss |  | $ | (3,811 | ) |  | $ | (2,097 | ) |  |

[0001564590-21-007045:notes:275]
The net actuarial loss during the year ended December 28, 2020 was primarily driven by an increase in liabilities due to a lower assumed discount rate.

[0001564590-21-007045:notes:276]
The components included in the net periodic benefit cost and the increase in minimum liability included in other comprehensive loss for the years ended December 28, 2020, December 30, 2019 and December 31, 2018 are as follows:

[0001564590-21-007045:notes:277]
|  |  | December 28, 2020 |  |  | December 30, 2019 |  |  | December 31, 2018 |  |  |
|  |  | (In thousands) |  |  |
| Service cost |  | $ | — |  |  | $ | 397 |  |  | $ | 292 |  |  |
| Interest cost |  |  | 907 |  |  |  | 1,109 |  |  |  | 758 |  |  |
| Expected return on plan assets |  |  | (1,272 | ) |  |  | (1,228 | ) |  |  | (920 | ) |  |
| Net periodic benefit cost |  | $ | (365 | ) |  | $ | 278 |  |  | $ | 130 |  |  |

[0001564590-21-007045:notes:278]
The weighted-average assumptions used to determine benefit obligations for this plan as of December 28, 2020,
December 30, 2019 and December 31, 2018 are as follows:

[0001564590-21-007045:notes:279]
|  |  | December 28, 2020 |  |  | December 30, 2019 |  |  | December 31, 2018 |  |  |
| Discount rate |  |  | 2.20 |  | % |  | 3.02 |  | % |  | 4.09 |  | % |
| Rate of compensation increase |  |  | — |  |  |  | 3.20 |  |  |  | 3.20 |  |  |
| Expected return on plan assets |  |  | 5.50 |  |  |  | 6.00 |  |  |  | 6.75 |  |  |

[0001564590-21-007045:notes:280]
The Company determines the discount rate assumption based on the internal rate of return for a portfolio of high quality bonds, with a minimum rating of Moody's AA Corporate and with maturities that are consistent with the projected future cash flow obligations.

[0001564590-21-007045:notes:281]
The weighted-average assumptions used to determine net periodic benefit cost for the years ended December 28, 2020, December 30, 2019 and December 31, 2018 are as follows:

[0001564590-21-007045:notes:282]
|  |  | For the Year Ended |  |  |
|  |  | December 28, 2020 |  |  | December 30, 2019 |  |  | December 31, 2018 |  |  |
| Discount rate |  |  | 3.02 |  | % |  | 4.09 |  | % |  | 3.96 |  | % |
| Rate of compensation increase |  |  | — |  |  |  | 3.20 |  |  |  | 3.20 |  |  |
| Expected return on plan assets |  |  | 6.00 |  |  |  | 6.75 |  |  |  | 6.75 |  |  |

[0001564590-21-007045:notes:283]
The Company determines the expected long-term rate of return on plan assets based upon recommendations from its pension plan's investment advisors and using an allocation approach that considers diversification and rebalancing for a portfolio of assets invested over a long-term time horizon. The approach relies on the historical returns of the plan's portfolio and relationships between equities and fixed income investments, consistent with the widely accepted capital market principle that a diversified portfolio with a larger allocation to equity investments can generate a greater return over the long run. Additionally, the Company monitors the mix of investments in its portfolio to ensure alignment with its expected long-term pension obligations. The Company reviews the expected long-term rate of return annually and revises it as appropriate.

[0001564590-21-007045:notes:284]
Investments shall be made pursuant to the following objectives: 1) preserve the purchasing power of the plan’s assets adjusted for inflation; 2) provide long-term growth; 3) avoid significant volatility. Asset allocation shall be determined based on a long-term target allocation having 29% of assets invested in large-cap stocks, 11% in mid-cap stocks, 11% in small-cap stocks, 11% in international stocks, 34% in the broad bond market, and 3% in the real estate market, with little or none invested in cash. Both the investment allocation and the plan performance are reviewed periodically.

[0001564590-21-007045:notes:285]
The target allocation for 2021 and the plan asset allocation at the end of 2020 and 2019, in percentages, by asset category are as follows:

[0001564590-21-007045:notes:286]
|  |  | Target Allocation 2021 |  |  |  | December 28, 2020 |  |  |  | December 30, 2019 |  |  |
| Equity securities (1) |  |  | 67 |  | % |  |  | 68 |  | % |  |  | 66 |  | % |
| Debt securities (2) |  |  | 30 |  |  |  |  | 30 |  |  |  |  | 31 |  |  |
| Cash and cash equivalents (3) |  |  | 3 |  |  |  |  | 2 |  |  |  |  | 3 |  |  |
| Total |  |  | 100 |  | % |  |  | 100 |  | % |  |  | 100 |  | % |

[0001564590-21-007045:notes:287]
The following table summarizes plan assets measured at fair value as of December 28, 2020 and December 30, 2019:

[0001564590-21-007045:notes:288]
|  |  | As of |  |
|  |  | December 28, 2020 |  |
|  |  | Total |  |  | Quoted Prices in Active Markets for Identical Assets (Level 1) |  |  | Significant Observable Inputs (Level 2) |  |  | Significant Unobservable Inputs (Level 3) |  |
|  |  | (In thousands) |  |
| Equity securities (1) |  | $ | 15,922 |  |  | $ | 15,922 |  |  | $ | — |  |  | $ | — |  |
| Debt securities (2) |  |  | 7,015 |  |  |  | 7,015 |  |  |  | — |  |  |  | — |  |
| Cash and cash equivalents (3) |  |  | 547 |  |  |  | 547 |  |  |  | — |  |  |  | — |  |
| Total |  | $ | 23,484 |  |  | $ | 23,484 |  |  | $ | — |  |  | $ | — |  |
|  |  | As of |  |
|  |  | December 30, 2019 |  |
|  |  | Total |  |  | Quoted Prices in Active Markets for Identical Assets (Level 1) |  |  | Significant Observable Inputs (Level 2) |  |  | Significant Unobservable Inputs (Level 3) |  |
|  |  | (In thousands) |  |
| Equity securities (1) |  | $ | 14,131 |  |  | $ | 14,131 |  |  | $ | — |  |  | $ | — |  |
| Debt securities (2) |  |  | 6,488 |  |  |  | 6,488 |  |  |  | — |  |  |  | — |  |
| Cash and cash equivalents (3) |  |  | 668 |  |  |  | 668 |  |  |  | — |  |  |  | — |  |
| Total |  | $ | 21,287 |  |  | $ | 21,287 |  |  | $ | — |  |  | $ | — |  |

[0001564590-21-007045:notes:289]
| (1) | Equity securities include U.S. and foreign exchange traded common and preferred stocks and mutual funds. Common and preferred shares issued by U.S. and non-U.S. corporations are traded actively on exchanges and price quotes for these shares are readily available. Holdings of corporate stock are categorized as Level 1 investments. |

[0001564590-21-007045:notes:290]
| (2) | Debt securities include the debt of the U.S. Treasury and U.S. and foreign corporate issuers. U.S. Treasury notes and bonds are actively traded and price quotes for these securities are readily available. Holdings of U.S. Treasury notes and bonds are categorized as Level 1 investments. |

[0001564590-21-007045:notes:291]
| (3) | Cash and cash equivalents include short-term U.S. government investment notes, short-term money market mutual funds, accrued income and cash held on account. Cash held on account and short- term U.S. government investment notes (including accrued income thereon) for which there is an active market and daily pricing for the security are categorized as Level 1 investments. |

[0001564590-21-007045:notes:292]
The Company seeks to maximize medium to long-term returns of the overall pension plan assets with reasonable levels of investment risk. One element of controlling the overall investment risk is through diversification of asset allocation, among domestic and international equity and debt instruments. The plan's equity investments include foreign and domestic exchange traded equities across a range of industries and countries, but primarily in the domestic markets. The plan's debt securities are primarily invested in government and corporate issuers primarily in the domestic market.

[0001564590-21-007045:notes:293]
The following benefit payments, which reflect expected future service, as appropriate, are expected to be paid:

[0001564590-21-007045:notes:294]
|  |  | (In thousands) |  |
| 2021 |  | $ | 1,294 |  |
| 2022 |  |  | 1,335 |  |
| 2023 |  |  | 1,421 |  |
| 2024 |  |  | 1,514 |  |
| 2025 |  |  | 1,572 |  |
| Years 2026 through 2030 |  |  | 8,513 |  |


## us-gaap:PreferredStockTextBlock

[0001564590-21-007045:notes:295]
| (16) | Preferred Stock |

[0001564590-21-007045:notes:296]
The board of directors has the authority, without action by stockholders, to designate and issue preferred stock in one or more series. The board of directors may also designate the rights, preferences and privileges of each series of preferred stock, any or all of which may be superior to the rights of the common stock. As of December 28, 2020, no shares of preferred stock were outstanding.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001564590-21-007045:notes:297]
| (17) | Segment Information |

[0001564590-21-007045:notes:298]
The reportable segments shown below are the Company’s segments for which separate financial information is available and upon which operating results are evaluated by the chief operating decision maker to assess performance and to allocate resources. During the year ended December 28, 2020, the Company’s RF&S Components operating segment met the quantitative threshold for separate presentation of a reportable segment. In prior periods, the Company had two reportable segments: PCB and E-M Solutions. The RF&S Components reportable segment was previously aggregated with the PCB reportable segment. As a result, certain prior year amounts have been reclassified to conform with this new presentation. The PCB reportable segment consists of fifteen domestic PCB and sub-system plants; five PCB fabrication plants in China; and one in Canada. The RF&S reportable segment consists of one domestic RF component plant and one RF component plant in China. The E-M Solutions reportable segment consists of three custom electronic assembly plants in China, two of which were closed in the fourth quarter of 2020. As a result, the Company will no longer be reporting E-M Solutions operating segment in 2021. See Note 20 for further details.

[0001564590-21-007045:notes:299]
The Company, including the chief operating decision maker, evaluates segment performance based on reportable segment income, which is operating income before amortization of intangibles. Interest expense and interest income are not presented by segment since they are not included in the measure of segment profitability reviewed by the chief operating decision maker. All inter-segment transactions have been eliminated.

[0001564590-21-007045:notes:300]
|  |  | For the Year Ended |  |
|  |  | December 28, 2020 |  |  | December 30, 2019 |  |  | December 31, 2018 |  |
|  |  | (In thousands) |  |
| Net Sales: |  |  |  |  |  |  |  |  |  |  |  |  |
| PCB |  | $ | 1,905,243 |  |  | $ | 1,844,562 |  |  | $ | 1,959,090 |  |
| RF&S Components |  |  | 44,656 |  |  |  | 62,315 |  |  |  | 52,705 |  |
| E-M Solutions |  |  | 155,423 |  |  |  | 226,333 |  |  |  | 225,947 |  |
| Total net sales |  | $ | 2,105,322 |  |  | $ | 2,133,210 |  |  | $ | 2,237,742 |  |
| Operating Segment Income (Loss): |  |  |  |  |  |  |  |  |  |  |  |  |
| PCB |  | $ | 262,304 |  |  | $ | 233,642 |  |  | $ | 262,143 |  |
| RF&S Components |  |  | (56,671 | ) |  |  | 29,376 |  |  |  | 24,713 |  |
| E-M Solutions |  |  | (20,738 | ) |  |  | 7,119 |  |  |  | 8,105 |  |
| Corporate |  |  | (112,430 | ) |  |  | (109,910 | ) |  |  | (115,662 | ) |
| Total operating segment income |  |  | 72,465 |  |  |  | 160,227 |  |  |  | 179,299 |  |
| Amortization of definite-lived intangibles (1) |  |  | (44,373 | ) |  |  | (50,598 | ) |  |  | (60,328 | ) |
| Total operating income |  |  | 28,092 |  |  |  | 109,629 |  |  |  | 118,971 |  |
| Total other expense |  |  | (74,369 | ) |  |  | (75,303 | ) |  |  | (71,786 | ) |
| (Loss) income before income taxes |  | $ | (46,277 | ) |  | $ | 34,326 |  |  | $ | 47,185 |  |

[0001564590-21-007045:notes:301]
|  |  | For the Year Ended |  |
|  |  | December 28, 2020 |  |  | December 30, 2019 |  |  | December 31, 2018 |  |
|  |  | (In thousands) |  |
| Depreciation Expense: |  |  |  |  |  |  |  |  |  |  |  |  |
| PCB |  | $ | 79,300 |  |  | $ | 80,239 |  |  | $ | 81,138 |  |
| RF&S Components |  |  | 1,742 |  |  |  | 1,720 |  |  |  | 1,120 |  |
| E-M Solutions |  |  | 9,843 |  |  |  | 3,476 |  |  |  | 2,850 |  |
| Corporate |  |  | 8,687 |  |  |  | 7,935 |  |  |  | 6,221 |  |
| Total depreciation expense |  | $ | 99,572 |  |  | $ | 93,370 |  |  | $ | 91,329 |  |
| Capital Expenditures: |  |  |  |  |  |  |  |  |  |  |  |  |
| PCB |  | $ | 64,285 |  |  | $ | 102,984 |  |  | $ | 76,109 |  |
| RF&S Components |  |  | 1,514 |  |  |  | 3,683 |  |  |  | 2,104 |  |
| E-M Solutions |  |  | 722 |  |  |  | 2,302 |  |  |  | 3,918 |  |
| Corporate |  |  | 5,804 |  |  |  | 8,437 |  |  |  | 7,758 |  |
| Total capital expenditures |  | $ | 72,325 |  |  | $ | 117,406 |  |  | $ | 89,889 |  |

[0001564590-21-007045:notes:302]
|  |  | As of |  |
|  |  | December 28, 2020 |  |  | December 30, 2019 |  |
|  |  | (In thousands) |  |
| Segment Assets: |  |  |  |  |  |  |  |  |
| PCB (2) |  | $ | 1,489,121 |  |  | $ | 2,088,229 |  |
| RF&S Components |  |  | 227,990 |  |  |  | 38,536 |  |
| E-M Solutions |  |  | 128,109 |  |  |  | 156,580 |  |
| Corporate |  |  | 1,050,724 |  |  |  | 1,277,588 |  |
| Total assets |  | $ | 2,895,944 |  |  | $ | 3,560,933 |  |

[0001564590-21-007045:notes:303]
| (1) | Amortization of definite-lived intangibles primarily relates to the PCB and RF&S Components reportable segments. For the years ended December 28, 2020, December 30, 2019 and December 31, 2018, $5,535, $4,822 and $3,345, respectively, of amortization expense is included in cost of goods sold. |

[0001564590-21-007045:notes:304]
| (2) | Segment assets for the PCB reportable segment as of December 30, 2019 include the Company’s Mobility business unit’s assets amounting to $493,169. |

[0001564590-21-007045:notes:305]
The Corporate category primarily includes operating expenses that are not included in the segment operating performance measures. Corporate consists primarily of corporate governance functions such as finance, accounting, information technology, facilities and human resources personnel, as well as global sales and marketing personnel, research and development costs, and acquisition and integration costs associated with acquisitions and divestitures. Bank fees and legal, accounting, and other professional service costs associated with acquisitions and divestitures of $273, $6,902 and $13,279 for the years ended December 28, 2020, December 30, 2019 and December 31, 2018, respectively, are included in Corporate.

[0001564590-21-007045:notes:306]
The Company markets and sells its products in approximately 53 countries. Other than in the United States and China, the Company does not conduct business in any country in which its net sales in that country exceed 10% of the Company’s total net sales. Net sales and long-lived assets are as follows:

[0001564590-21-007045:notes:307]
|  |  | 2020 |  |  | 2019 |  |  | 2018 |  |
|  |  | Net Sales |  |  | Long-Lived Assets |  |  | Net Sales |  |  | Long-Lived Assets |  |  | Net Sales |  |  | Long-Lived Assets |  |
|  |  | (In thousands) |  |
| United States |  | $ | 1,086,440 |  |  | $ | 1,154,218 |  |  | $ | 1,118,725 |  |  | $ | 1,348,741 |  |  | $ | 977,265 |  |  | $ | 1,315,174 |  |
| China |  |  | 334,462 |  |  |  | 387,627 |  |  |  | 341,779 |  |  |  | 335,191 |  |  |  | 354,931 |  |  |  | 378,978 |  |
| Other |  |  | 684,420 |  |  |  | 27,221 |  |  |  | 672,706 |  |  |  | 26,473 |  |  |  | 905,546 |  |  |  | 28,029 |  |
| Total |  | $ | 2,105,322 |  |  | $ | 1,569,066 |  |  | $ | 2,133,210 |  |  | $ | 1,710,405 |  |  | $ | 2,237,742 |  |  | $ | 1,722,181 |  |

[0001564590-21-007045:notes:308]
Net sales are attributed to countries by country invoiced.


## us-gaap:EarningsPerShareTextBlock

[0001564590-21-007045:notes:309]
| (18) | Earnings Per Share |

[0001564590-21-007045:notes:310]
The following is a reconciliation of the numerator and denominator used to calculate basic earnings per share and diluted earnings per share from continuing operations for the years ended December 28, 2020, December 30, 2019 and December 31, 2018:

[0001564590-21-007045:notes:311]
|  |  | For the Year Ended |  |
|  |  | December 28, 2020 |  |  | December 30, 2019 |  |  | December 31, 2018 |  |
|  |  | (In thousands, except per share amounts) |  |
| Net (loss) income from continuing operations |  | $ | (16,386 | ) |  | $ | 31,921 |  |  | $ | 135,392 |  |
| Diluted (loss) earnings: |  |  |  |  |  |  |  |  |  |  |  |  |
| Net (loss) income from continuing operations |  | $ | (16,386 | ) |  | $ | 31,921 |  |  | $ | 135,392 |  |
| Interest expense from Convertible Senior Notes, net of tax |  |  | — |  |  |  | — |  |  |  | 11,906 |  |
| Diluted (loss) earnings |  | $ | (16,386 | ) |  | $ | 31,921 |  |  | $ | 147,298 |  |
| Basic weighted average shares |  |  | 106,366 |  |  |  | 105,195 |  |  |  | 103,355 |  |
| Dilutive effect of performance-based restricted stock units, restricted stock units and stock options |  |  | — |  |  |  | 1,137 |  |  |  | 1,677 |  |
| Dilutive effect of outstanding warrants |  |  | — |  |  |  | — |  |  |  | 3,065 |  |
| Dilutive effect of assumed conversion of Convertible Senior Notes outstanding |  |  | — |  |  |  | — |  |  |  | 25,939 |  |
| Diluted shares |  |  | 106,366 |  |  |  | 106,332 |  |  |  | 134,036 |  |
| (Loss) earnings per share: |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  | $ | (0.15 | ) |  | $ | 0.30 |  |  | $ | 1.31 |  |
| Diluted |  | $ | (0.15 | ) |  | $ | 0.30 |  |  | $ | 1.10 |  |

[0001564590-21-007045:notes:312]
For the years ended December 28, 2020, December 30, 2019 and December 31, 2018, PRUs, RSUs and stock options to purchase 433, 730 and 528 shares of common stock, respectively, were not included in the computation of diluted earnings per share. The PRUs were not included in the computation of diluted earnings per share because the performance conditions had not been met at December 28, 2020, and for RSUs and stock options, the options’ exercise prices or the total expected proceeds under the treasury stock method was greater than the average market price of common shares during the applicable year and, as a result, the impact would be anti-dilutive.

[0001564590-21-007045:notes:313]
The below is a summary of amounts convertible to common stock related to Convertible Senior Notes and related warrants:

[0001564590-21-007045:notes:314]
|  |  | For the Year Ended |  |
|  |  | December 28, 2020 |  |  | December 30, 2019 |  |  | December 31, 2018 |  |
|  |  | (In thousands) |  |
| Common stock related to Convertible Senior Notes |  |  | — |  |  |  | 25,938 |  |  |  | 25,939 |  |
| Warrants to purchase common stock |  |  | 25,940 |  |  |  | 25,940 |  |  |  | 25,940 |  |

[0001564590-21-007045:notes:315]
During the year ended December 28, 2020, the Company calculated the dilutive effect of Convertible Senior Notes using the treasury stock method because the Company repaid and settled the Convertible Senior Notes in cash. This change in policy from the if-converted method to treasury stock method was applied on a prospective basis. For the year ended December 28, 2020, the effect of shares of common stock related to the Company’s Convertible Senior Notes were not included in the computation of dilutive earnings per share as the impact would be anti-dilutive due to the net loss from continuing operations. For the year ended December 30, 2019, the effect of shares of common stock related to the Company’s Convertible Senior Notes, based on the if-converted method, were not included in the computation of dilutive earnings per share as the impact would be anti-dilutive.

[0001564590-21-007045:notes:316]
Outstanding warrants for the years ended December 28, 2020 and December 30, 2019, to purchase common stock were not included in the computation of dilutive earnings per share because the strike price of the warrants to purchase the Company’s common stock were greater than the average market price of common shares during the applicable year, and therefore, the effect would be anti-dilutive.


## us-gaap:RelatedPartyTransactionsDisclosureTextBlock

[0001564590-21-007045:notes:317]
| (19) | Related Party Transactions |

[0001564590-21-007045:notes:318]
In the normal course of business, the Company’s foreign subsidiaries purchase laminate and prepreg from related parties in which a former member of the Board of Directors of the Company holds an equity interest. The Company no longer has a related party relationship under ASC Topic 850, Related Party Disclosures, with this former member of the Board of Directors as of December 28, 2020 (resigned on May 9, 2020). The Company’s foreign subsidiaries purchased laminate and prepreg from these related parties in the amount of $25,175, $30,612 and $39,462 for the years ended December 28, 2020, December 30, 2019 and December 31, 2018, respectively.

[0001564590-21-007045:notes:319]
The Company also sells PCBs to a related party which is a wholly owned subsidiary of an entity in which a former member of the Board of Directors of the Company holds an equity interest. The Company no longer has a related party relationship under ASC Topic 850, Related Party Disclosures, with this former member of the Board of Directors as of December 28, 2020 (resigned on May 9, 2020). Sales to this related party for the years ended December 28, 2020 and December 30, 2019 were $32 and $244, respectively. There were no sales to this related party for the year ended December 31, 2018.

[0001564590-21-007045:notes:320]
As of December 30, 2019, the Company’s consolidated balance sheet included $9,220 in accounts payable due to related parties for purchases of laminate and prepreg and such balance is included as a component of accounts payable on the consolidated balance sheet.


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0001564590-21-007045:notes:321]
| (20) | Restructuring Charges |

[0001564590-21-007045:notes:322]
On April 29, 2020, the Company announced the restructuring of its E-M Solutions business unit. The E-M Solutions business unit consists of three Chinese manufacturing facilities with two being in Shanghai (SH BPA and SH E-MS) and one in Shenzhen (SZ). The Company ceased operations at the SH E-MS and SZ facilities while integrating the SH BPA facility into its PCB operations. The restructuring is another step in advancing the Company’s stated strategy of increasing its focus on differentiated higher margin products that more fully leverage the Company’s early engagement capabilities and industry leading engineering-based technology solutions. The Company closed the SH E-MS and SZ facilities in the fourth quarter of 2020. As of December 28, 2020, the Company has incurred approximately $16,573 of restructuring charges and $6,705 of accelerated depreciation expense since the April 29, 2020 announcement.

[0001564590-21-007045:notes:323]
In connection with the restructuring of its E-M Solutions business unit and other global realignment restructuring efforts, the Company recognized employee separation, contract termination and other costs during the years ended December 28, 2020, December 30, 2019, and December 31, 2018. Contract termination and other costs primarily represented plant closure costs.

[0001564590-21-007045:notes:324]
The below table summarizes such restructuring costs by reportable segment for the years ended December 28, 2020, December 30, 2019 and December 31, 2018:

[0001564590-21-007045:notes:325]
|  |  | For the Year Ended |  |
|  |  | December 28, 2020 |  |  | December 30, 2019 |  |  | December 31, 2018 |  |
|  |  | Employee Separation/ Severance |  |  | Contract Termination and Other Costs |  |  | Total |  |  | Employee Separation/ Severance |  |  | Contract Termination and Other Costs |  |  | Total |  |  | Employee Separation/ Severance |  |  | Contract Termination and Other Costs |  |  | Total |  |
|  |  | (In thousands) |  |
| Reportable Segment: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| PCB |  | $ | — |  |  | $ | 14 |  |  | $ | 14 |  |  | $ | 5,218 |  |  | $ | — |  |  | $ | 5,218 |  |  | $ | 1,150 |  |  | $ | — |  |  | $ | 1,150 |  |
| RF&S Components |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 52 |  |  |  | — |  |  |  | 52 |  |  |  | — |  |  |  | — |  |  |  | — |  |
| E-M Solutions |  |  | 15,251 |  |  |  | 1,322 |  |  |  | 16,573 |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |
| Corporate |  |  | 19 |  |  |  | 158 |  |  |  | 177 |  |  |  | 80 |  |  |  | 30 |  |  |  | 110 |  |  |  | 3,389 |  |  |  | 121 |  |  |  | 3,510 |  |
|  |  | $ | 15,270 |  |  | $ | 1,494 |  |  | $ | 16,764 |  |  | $ | 5,350 |  |  | $ | 30 |  |  | $ | 5,380 |  |  | $ | 4,539 |  |  | $ | 121 |  |  | $ | 4,660 |  |

[0001564590-21-007045:notes:326]
Accrued restructuring costs are included as a component of other current liabilities in the consolidated balance sheets. The below table shows the utilization of the accrued restructuring costs during the years ended December 28, 2020 and December 30, 2019:

[0001564590-21-007045:notes:327]
|  |  | Employee Separation/ Severance |  |  | Contract Termination and Other Costs |  |  | Total |  |
|  |  | (In thousands) |  |
| Accrued as of December 31, 2018 |  | $ | 3,158 |  |  | $ | 393 |  |  | $ | 3,551 |  |
| Charged to expense |  |  | 5,350 |  |  |  | 30 |  |  |  | 5,380 |  |
| Amount paid |  |  | (8,248 | ) |  |  | (181 | ) |  |  | (8,429 | ) |
| Accrued as of December 30, 2019 |  | $ | 260 |  |  | $ | 242 |  |  | $ | 502 |  |
| Charged to expense |  |  | 15,270 |  |  |  | 1,494 |  |  |  | 16,764 |  |
| Amount paid |  |  | (8,467 | ) |  |  | (1,417 | ) |  |  | (9,884 | ) |
| Accrued as of December 28, 2020 |  | $ | 7,063 |  |  | $ | 319 |  |  | $ | 7,382 |  |


## us-gaap:SubsequentEventsTextBlock

[0001564590-21-007045:notes:328]
| (21) | Subsequent Events |

[0001564590-21-007045:notes:329]
On February 3, 2021, the Company announced that its Board of Directors authorized and approved a share repurchase program. Under the program, the Company may repurchase up to $100,000 in value of the Company’s outstanding shares of common stock from time to time through February 3, 2023. The Company may repurchase shares through open market purchases, privately-negotiated transactions, or otherwise in accordance with applicable federal securities laws, including Rule 10b-18 of the Exchange Act which sets certain restrictions on the method, timing, price and volume of open market stock repurchases. In addition, the Company expects to adopt one or more trading plans in accordance with Rule 10b5-1 of the Exchange Act to facilitate certain purchases that may be effected under the share repurchase program. The timing, manner, price and amount of any repurchases will be determined at the Company’s discretion, and the share repurchase program may be suspended, terminated or modified at any time for any reason. The repurchase program does not obligate the Company to acquire any specific number of shares.
