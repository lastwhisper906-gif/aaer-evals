# TTMI MD&A — 0001564590-21-007045


## mdna

[0001564590-21-007045:mdna:1]
| ITEM 7. | MANAGEMENT’S DISCUSSION AND ANALYSIS OF FINANCIAL CONDITION AND RESULTS OF OPERATIONS |

[0001564590-21-007045:mdna:2]
This financial review presents our operating results for each of our three most recent fiscal years and our financial condition as of December 28, 2020. Except for historical information contained herein, the following discussion contains forward-looking statements which are subject to known and unknown risks, uncertainties and other factors that may cause our actual results to differ materially from those expressed or implied by such forward-looking statements. We discuss such risks, uncertainties and other factors throughout this report and specifically under Item 1A of Part I of this report, Risk Factors. In addition, the following discussion should be read in connection with the information presented in our consolidated financial statements and the related notes to our consolidated financial statements.

[0001564590-21-007045:mdna:3]
COMPANY OVERVIEW

[0001564590-21-007045:mdna:4]
We are a leading global printed circuit board (PCB) manufacturer, focusing on quick-turn and volume production of technologically advanced PCBs and backplane assemblies as well as a global designer and manufacturer of high-frequency radio frequency (RF) and microwave components and assemblies. We focus on providing time-to-market and volume production of advanced technology products and offer a one-stop design, engineering and manufacturing solution to our customers. This one-stop design, engineering and manufacturing solution allows us to align technology development with the diverse needs of our customers and to enable them to reduce the time required to develop new products and bring them to market. We serve a diversified customer base consisting of approximately 1,600 customers in various markets throughout the world, including aerospace and defense, computing, automotive components, medical, industrial and instrumentation related products, as well as networking/communications infrastructure products. Our customers include both original equipment manufacturers (OEMs) and electronic manufacturing services (EMS) providers.

[0001564590-21-007045:mdna:5]
RECENT DEVELOPMENTS

[0001564590-21-007045:mdna:6]
The recent coronavirus (COVID-19) pandemic first caused business disruption in our operations in China beginning in January 2020. By March 2020, the situation escalated as the scope of the COVID-19 pandemic worsened outside of the Asia-Pacific region, with Europe and North America being affected by the pandemic. Also, we experienced an increase in COVID-19 cases in our facilities in North America during the fourth quarter of 2020. As a result, we expect continued impacts on our production, as well as ongoing significant uncertainty relating to the actual and potential impacts of the COVID-19 pandemic, and we cannot reasonably estimate its duration or severity. The COVID-19 pandemic has created and continues to create various global macroeconomic, customer demand, operational and supply chain risks any one of which could have a material and adverse impact on our business going forward. See Item 1A, Risk Factors, of Part I above for further information related to the COVID-19 pandemic. We have taken measures to protect our employees, suppliers and customers by implementing our pandemic recovery protocols, establishing situational leadership teams in Asia-Pacific and North America along with regularly scheduled executive review and planning calls, implementing global travel restrictions, and conforming to the guidance and direction of local governments and global health organizations. We are monitoring the impacts the COVID-19 pandemic has had, and continues to have, on our supply chain and are collaborating with our third-party partners with the goal of mitigating, to the extent reasonably practicable, significant delays in delivery of our products.

[0001564590-21-007045:mdna:7]
FINANCIAL OVERVIEW

[0001564590-21-007045:mdna:8]
On April 17, 2020, we completed the sale of our Mobility business unit for a final purchase price of $569.2 million, received pre-tax proceeds from the sale, net of cash disposed of $507.5 million, and recorded a gain on the sale before income taxes of $237.3 million. The final purchase price of $569.2 million did not include approximately $83.0 million of accounts receivable of the divested business. Results related to our Mobility business unit are reported as discontinued operations for all periods presented. See Note 3 of the Notes to Consolidated Financial Statements for further information. Unless otherwise noted, amounts and disclosures throughout our Management’s Discussion and Analysis of Financial Condition and Results of Operations relate to our continuing operations.

[0001564590-21-007045:mdna:9]
While our customers include both OEMs and EMS providers, we measure customers based on OEM companies, as they are the ultimate end customers. Sales to our five largest customers accounted for 29%, 27% and 25% of our net sales in fiscal years 2020, 2019 and 2018, respectively. We sell to OEMs both directly and indirectly through EMS providers.

[0001564590-21-007045:mdna:10]
The following table shows the percentage of our net sales attributable to each of the principal end markets we served for the periods indicated:

[0001564590-21-007045:mdna:11]
|  |  | For the Year Ended |  |  |
| End Markets (1) |  | December 28, 2020 |  |  |  | December 30, 2019 |  |  |  | December 31, 2018 (3) |  |  |
| Aerospace and Defense |  |  | 36 |  | % |  |  | 33 |  | % |  |  | 27 |  | % |
| Automotive |  |  | 15 |  |  |  |  | 19 |  |  |  |  | 21 |  |  |
| Computing/Storage/Peripherals |  |  | 12 |  |  |  |  | 11 |  |  |  |  | 13 |  |  |
| Medical/Industrial/Instrumentation |  |  | 18 |  |  |  |  | 17 |  |  |  |  | 17 |  |  |
| Networking/Communications |  |  | 18 |  |  |  |  | 18 |  |  |  |  | 21 |  |  |
| Other (2) |  |  | 1 |  |  |  |  | 2 |  |  |  |  | 1 |  |  |
| Total |  |  | 100 |  | % |  |  | 100 |  | % |  |  | 100 |  | % |

[0001564590-21-007045:mdna:12]
| (1) | Sales to EMS companies are classified by the end markets of their OEM customers. |

[0001564590-21-007045:mdna:13]
| (2) | Other consumer devices that include wearables, portable video devices and personal headphones are included in the Other end market. |

[0001564590-21-007045:mdna:14]
| (3) | Amounts include activity of Anaren since the acquisition which occurred on April 18, 2018. |

[0001564590-21-007045:mdna:15]
We derive revenues primarily from the sale of PCBs, custom electronic assemblies using customer-supplied engineering and design plans as well as our long-term contracts related to the design and manufacture of RF and microwave components, assemblies and subsystems. Orders for products generally correspond to the production schedules of our customers and are supported with firm purchase orders. Our customers have continuous control of the work in progress and finished goods throughout the PCB and custom electronic assemblies manufacturing process, as these are built to customer specifications with no alternative use, and there is an enforceable right of payment for work performed to date. As a result, we recognize revenue progressively over time based on the extent of progress towards completion of the performance obligation. We recognize revenue based on the cost-to-cost method as it best depicts the transfer of control to the customer which takes place as we incur costs. Under the cost-to-cost measure of progress, the extent of progress toward completion is measured based on the ratio of costs incurred to date to the total estimated costs at completion of the performance obligation. Revenues are recorded proportionally as costs are incurred.

[0001564590-21-007045:mdna:16]
We also manufacture certain components, assemblies, and subsystems which service our RF and Specialty Components (RF&S Components) customers. We recognize revenue at a point in time upon transfer of control of the products to our customer. Point in time recognition was determined as our customers do not simultaneously receive or consume the benefits provided by our performance and the asset being manufactured has alternative uses to us.

[0001564590-21-007045:mdna:17]
Net sales consist of gross sales less an allowance for returns, which typically have been approximately 2% of gross sales. We provide our customers a limited right of return for defective PCBs including components, subsystems and assemblies. We record an estimate for sales returns and allowances at the time of sale based on historical results and anticipated returns.

[0001564590-21-007045:mdna:18]
Cost of goods sold consists of materials, labor, outside services, and overhead expenses incurred in the manufacture and testing of our products. Shipping and handling fees and related freight costs and supplies associated with shipping products are also included as a component of cost of goods sold. Many factors affect our gross margin, including capacity utilization, product mix, production volume, and yield. While we have entered into supply assurance agreements with some of our key suppliers to maintain the continuity of supply of some of the key materials we use, we generally do not participate in any significant long-term contracts with suppliers, and we believe there are a number of potential suppliers for most of the raw materials we use.

[0001564590-21-007045:mdna:19]
Selling and marketing expenses consist primarily of salaries, labor related benefits, and commissions paid to our internal sales force, independent sales representatives, and our sales support staff, as well as costs associated with marketing materials and trade shows.

[0001564590-21-007045:mdna:20]
General and administrative costs primarily include the salaries for executive, finance, accounting, information technology, facilities, and human resources personnel, as well as expenses for accounting and legal assistance, incentive compensation expense, and gains or losses on the sale or disposal of property, plant and equipment.

[0001564590-21-007045:mdna:21]
Research and development expenses consist primarily of salaries and labor related benefits paid to our research and development staff, as well as material costs.

[0001564590-21-007045:mdna:22]
CRITICAL ACCOUNTING POLICIES AND ESTIMATES

[0001564590-21-007045:mdna:23]
Our consolidated financial statements included in this report have been prepared in accordance with accounting principles generally accepted in the United States of America (U.S. GAAP). The preparation of these financial statements requires management to make estimates and assumptions that affect the reported amounts of assets, liabilities, net sales and expenses, and related disclosure of contingent assets and liabilities.

[0001564590-21-007045:mdna:24]
A critical accounting policy is defined as one that is both material to the presentation of our consolidated financial statements and requires us to make judgments that could have a material effect on our financial condition or results of operations. These policies require us to make assumptions about matters that are highly uncertain at the time of the estimate. Different estimates we could

[0001564590-21-007045:mdna:25]
reasonably have used, or changes in the estimates that are reasonably likely to occur, could have a material effect on our financial condition or results of operations.

[0001564590-21-007045:mdna:26]
We base our estimates on historical experience and on various other assumptions that are believed to be reasonable under the circumstances, the results of which form the basis for making judgments about the carrying values of assets and liabilities that are not readily apparent from other sources. Management has discussed the development, selection and disclosure of these estimates with the audit committee of our board of directors. Actual results may differ from these estimates under different assumptions or conditions.

[0001564590-21-007045:mdna:27]
Our critical accounting policies include impairment of goodwill and intangible assets and realizability of deferred tax assets.

[0001564590-21-007045:mdna:28]
Goodwill and Intangible Assets

[0001564590-21-007045:mdna:29]
We have significant goodwill and definite-lived intangibles. We review these assets for impairment whenever events or changes in circumstances indicate that the carrying amount of such assets may not be recoverable. In addition, we perform an impairment test related to goodwill at least annually. As necessary, we make judgments regarding future cash flow forecasts in the assessment of impairment.

[0001564590-21-007045:mdna:30]
Goodwill is allocated to our reporting units, which are our operating segments or one level below our operating segments (the component level). Reporting units are determined by the discrete financial information available for the component and whether it is regularly reviewed by segment management. Components are aggregated into a single reporting unit if they share similar economic characteristics. The Company evaluates its goodwill on an annual basis in the fourth quarter or more frequently if it believes indicators of impairment exist. We assess qualitative factors to determine whether it is more likely than not that the fair value of a reporting unit is less than its carrying amount or perform an annual impairment test. When tested quantitatively, we compare the fair value of the applicable reporting unit with its carrying value. We estimate the fair values of our reporting units using a combination of the discounted cash flow (DCF) and market approach. If the carrying amount of a reporting unit exceeds the reporting unit’s fair value, the amount by which the carrying value exceeds the fair value is recognized as an impairment loss.

[0001564590-21-007045:mdna:31]
During the year ended December 28, 2020, our RF&S Components operating segment met the quantitative threshold for separate presentation of a reportable segment. In prior periods, we had two reportable segments consisting of PCB and E-M Solutions. The RF&S Components reportable segment was previously aggregated with the PCB reportable segment. Goodwill is only attributable to our PCB and RF&S Components reportable segments. During the third quarter of 2020, we determined that there was a permanent loss of sales due to certain government restrictions on the sale of U.S.-designed products to certain customers in China in the RF&S Components reporting unit that coupled with the impact of COVID-19, resulted in lower than anticipated results and continued decline in sales. We considered these factors to be indicators of potential impairment requiring us to test the related goodwill of $177.2 million for impairment. As of September 28, 2020, we completed a quantitative goodwill impairment analysis related to our RF&S Components reporting unit by comparing the fair value of the reporting unit with its carrying amount. We determined the fair value of the reporting unit by using both a discounted cash flow (DCF) and a market approach. Under the market approach, we used revenue and earnings multiples based on comparable industry multiples to estimate the fair value of the reporting unit.

[0001564590-21-007045:mdna:32]
Under the DCF approach, we estimated the future cash flows, as well as selected a risk-adjusted discount rate to measure the present value of the anticipated cash flows. When determining future cash flow estimates, we considered historical results adjusted to reflect current and anticipated future operating conditions. We estimated cash flows for the reporting unit over a discrete period and a terminal period (considering expected long-term growth rates and trends).

[0001564590-21-007045:mdna:33]
Based on our analysis, we determined that the fair value of the RF&S Components reporting unit was less than its carrying value and recorded a goodwill impairment charge of $69.2 million. Estimating the fair value of the reporting unit requires us to make assumptions and estimates in such areas as future economic conditions, industry-specific conditions, product pricing, and necessary capital expenditures. The use of different assumptions or estimates for future cash flows, discount rates, or terminal growth rates could produce substantially different estimates of the fair value of the reporting unit. We may be subject to additional goodwill impairment charges if actual results do not meet the estimates used in determining the fair value of goodwill and the associated goodwill impairment charge.

[0001564590-21-007045:mdna:34]
During the fourth quarter of 2020, we changed the date of our annual impairment test of goodwill from year-end to the first day of fiscal November to provide for additional time to complete the required impairment testing. This change does not represent a material change to our method of applying an accounting principle. The change in annual impairment test date has been prospectively applied beginning the first day of fiscal November 2020. In the fourth quarter of 2020, we performed our annual impairment test qualitatively and concluded that it was more likely than not that goodwill was not impaired. Management will continue to monitor the reporting units for changes in the business environment that could impact recoverability. The recoverability of goodwill is dependent upon the continued growth of cash flows from our business activities. If the economy or business environment falter and we are unable to achieve our assumed revenue growth rates or profit margin percentages, our projections used would need to be re-measured, which could impact the carrying value of our goodwill in one or more of our reporting units.

[0001564590-21-007045:mdna:35]
We also assess definite-lived intangibles for potential impairment given similar impairment indicators. When indicators of impairment exist related to our definite-lived intangible assets, we use an estimate of the undiscounted cash flows in measuring whether the carrying amount of the assets is recoverable. If the sum of the undiscounted cash flows is less than the carrying amount of the net assets, impairment is measured based on the difference between the net asset’s carrying value and estimated fair value. Fair

[0001564590-21-007045:mdna:36]
36

[0001564590-21-007045:mdna:37]
value is determined through various valuation techniques, including cost-based, market and income approaches as considered necessary, which involve judgments related to future cash flows and the application of the appropriate valuation model.

[0001564590-21-007045:mdna:38]
Income Taxes

[0001564590-21-007045:mdna:39]
Deferred income tax assets are reviewed for recoverability, and valuation allowances are provided, when necessary, to reduce deferred income tax assets to the amounts that are more likely than not to be realized based on our estimate of future taxable income. As of December 28, 2020, we had a net non-current deferred income tax asset of $16.6 million, which is comprised of a net deferred tax asset of $111.1 million and a net deferred tax liability of $94.5 million. As of December 28, 2020, our deferred income tax asset of $111.1 million was net of a valuation allowance of approximately $15.3 million. Should our expectations of taxable income change in future periods, it may be necessary to adjust our valuation allowance, which could affect our results of operations in the period such a determination is made.

[0001564590-21-007045:mdna:40]
We are subject to income taxes in the United States and foreign jurisdictions. Significant judgment is required in determining our worldwide provision for income taxes. In the ordinary course of our business, there are many transactions for which the ultimate tax determination is uncertain. Additionally, our calculations of income taxes are based on our interpretations of applicable tax laws in the jurisdictions in which we file.

[0001564590-21-007045:mdna:41]
RESULTS OF OPERATIONS

[0001564590-21-007045:mdna:42]
We operate on a 52 or 53 week year ending on the Monday nearest December 31. Fiscal year 2020, 2019 and 2018 were 52 weeks ended December 28, 2020, December 30, 2019 and December 31, 2018, respectively.

[0001564590-21-007045:mdna:43]
The following table sets forth the relationship of various items to net sales in our consolidated statements of operations:

[0001564590-21-007045:mdna:44]
|  |  | For the Year Ended |  |  |
|  |  | December 28, 2020 |  |  |  | December 30, 2019 |  |  |  | December 31, 2018 |  |  |
| Net sales |  |  | 100.0 |  | % |  |  | 100.0 |  | % |  |  | 100.0 |  | % |
| Cost of goods sold |  |  | 83.0 |  |  |  |  | 82.3 |  |  |  |  | 82.0 |  |  |
| Gross profit |  |  | 17.0 |  |  |  |  | 17.7 |  |  |  |  | 18.0 |  |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Selling and marketing |  |  | 3.0 |  |  |  |  | 3.2 |  |  |  |  | 3.1 |  |  |
| General and administrative |  |  | 5.8 |  |  |  |  | 6.1 |  |  |  |  | 6.2 |  |  |
| Research and development |  |  | 1.0 |  |  |  |  | 0.8 |  |  |  |  | 0.6 |  |  |
| Amortization of definite-lived intangibles |  |  | 1.8 |  |  |  |  | 2.2 |  |  |  |  | 2.6 |  |  |
| Restructuring charges |  |  | 0.8 |  |  |  |  | 0.3 |  |  |  |  | 0.2 |  |  |
| Impairment of goodwill |  |  | 3.3 |  |  |  |  | — |  |  |  |  | — |  |  |
| Total operating expenses |  |  | 15.7 |  |  |  |  | 12.6 |  |  |  |  | 12.7 |  |  |
| Operating income |  |  | 1.3 |  |  |  |  | 5.1 |  |  |  |  | 5.3 |  |  |
| Other (expense) income: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Interest expense |  |  | (3.5 | ) |  |  |  | (3.8 | ) |  |  |  | (3.4 | ) |  |
| Other, net |  |  | — |  |  |  |  | 0.3 |  |  |  |  | 0.2 |  |  |
| Total other expense, net |  |  | (3.5 | ) |  |  |  | (3.5 | ) |  |  |  | (3.2 | ) |  |
| (Loss) income from continuing operations before income taxes |  |  | (2.2 | ) |  |  |  | 1.6 |  |  |  |  | 2.1 |  |  |
| Income tax (provision) benefit |  |  | 1.4 |  |  |  |  | (0.1 | ) |  |  |  | 3.9 |  |  |
| Net (loss) income from continuing operations |  |  | (0.8 | ) | % |  |  | 1.5 |  | % |  |  | 6.0 |  | % |

[0001564590-21-007045:mdna:45]
The Anaren acquisition occurred on April 18, 2018. Accordingly, our fiscal year 2018 only includes Anaren’s 2018 results of operations since the acquisition date.

[0001564590-21-007045:mdna:46]
During the year ended December 28, 2020, our RF&S Components operating segment met the quantitative threshold for separate presentation of a reportable segment. In prior periods, we had two reportable segments: PCB and E-M Solutions. The RF&S Components reportable segment was previously aggregated with the PCB reportable segment. As a result, we now report on all three segments, and certain prior year amounts have been reclassified to conform with this new presentation.

[0001564590-21-007045:mdna:47]
Net Sales

[0001564590-21-007045:mdna:48]
Total net sales decreased $27.9 million, or 1.3%, to $2,105.3 million for the year ended December 28, 2020 from $2,133.2 million for the year ended December 30, 2019. This decrease primarily resulted from a decrease in net sales for the E-M Solutions reportable segment of $70.9 million, or 31.3%, to $155.4 million for the year ended December 28, 2020 from $226.3 million for the year ended December 30, 2019, primarily due to the winding down of this reportable segment and lower demand in our Automotive end market. Also contributing to the decrease in total net sales was a decrease in net sales for the RF&S Components reportable segment of $17.7 million, or 28.3%, to $44.7 million for the year ended December 28, 2020 from $62.3 million for the year ended

[0001564590-21-007045:mdna:49]
December 30, 2019. The decrease in RF&S Components net sales was primarily due to restrictions on the sale of U.S.-designed products to certain customers in China which, coupled with the impact of COVID-19, resulted in lower demand in our Networking/Communications and Other end markets. The decrease in total net sales was partially offset by an increase in net sales for the PCB reportable segment of $60.7 million, or 3.3%, to $1,905.2 million for the year ended December 28, 2020 from $1,844.6 million for the year ended December 30, 2019. The increase in PCB net sales was primarily due to increased demand in our Aerospace and Defense, Medical/Industrial/Instrumentation, and Computing/Storage/Peripherals end markets, partially offset by lower demand in our Automotive end market. Also driving the increase in PCB net sales were changes in product mix, which resulted in an increase in the average price per square foot of 15.2%. The benefit of this price increase, however, was partially offset by a 10.1% decrease in the volume of PCB shipments as compared to the year ended December 30, 2019.

[0001564590-21-007045:mdna:50]
Total net sales decreased $104.5 million, or 4.7%, to $2,133.2 million for the year ended December 30, 2019 from $2,237.7 million for the year ended December 31, 2018. Net sales for the PCB reportable segment decreased $114.5 million, or 5.9%, to $1,844.6 million for the year ended December 30, 2019 from $1,959.1 million for the year ended December 31, 2018. The reduction in PCB net sales was primarily due to lower demand in our commercial (non-Aerospace and Defense related) end markets, partially offset by increased demand in our Aerospace and defense end market, which was primarily the result of the impact in the fiscal year 2019 of our acquisition of Anaren (which occurred on April 18, 2018) and higher demand at our other Aerospace and Defense focused facilities. These changes resulted in a 19.6% decrease in the volume of PCB shipments partially offset by an average PCB selling price increase of 13.0%, driven mainly by product mix shift, as compared to the year ended December 31, 2018. Net sales for the RF&S Components reportable segment increased $9.6 million, or 18.2% to $62.3 million for the year ended December 30, 2019 from $52.7 million for the year ended December 31, 2018. The increase was primarily the result of the impact in the fiscal year 2019 of our acquisition of Anaren (which occurred on April 18, 2018). Net sales for the E-M Solutions reportable segment increased $0.4 million, or 0.2%, to $226.3 million for the year ended December 30, 2019 from $225.9 million for the year ended December 31, 2018.

[0001564590-21-007045:mdna:51]
For information regarding net sales by country, see Note 17 of the Notes to Consolidated Financial Statements.

[0001564590-21-007045:mdna:52]
Gross Margin

[0001564590-21-007045:mdna:53]
Overall gross margin decreased to 17.0% for the year ended December 28, 2020 from 17.7% for the year ended December 30, 2019. The decrease in overall gross margin was due to the decrease in gross margin for the RF&S Components and E-M Solutions reportable segment to 45.9% and 1.8%, respectively, for the year ended December 28, 2020 from 63.2% and 7.2%, respectively, for the year ended December 30, 2019, primarily due to lower sales. The lower sales of RF&S Components products was mainly due to restrictions on the sale of U.S.-designed products to certain customers in China. This decrease was partially offset by the gross margin for the PCB reportable segment, which increased to 18.5% for the year ended December 28, 2020 from 18.3% for the year ended December 30, 2019, primarily due to higher volumes at our Aerospace and Defense facilities.

[0001564590-21-007045:mdna:54]
Overall gross margin decreased to 17.7% for the year ended December 30, 2019 from 18.0% for the year ended December 31, 2018. Gross margin for the PCB reportable segment decreased to 18.3% for the year ended December 30, 2019 from 18.5% for the year ended December 31, 2018, primarily due to lower volumes in our commercially focused facilities. Furthermore, gross margin for the RF&S Components and E-M Solutions reportable segments decreased to 63.2% and 7.2%, respectively, for the year ended December 30, 2019 from 64.4% and 8.0%, respectively, for the year ended December 31, 2018, in each case primarily due to mix shift toward higher direct material content work.

[0001564590-21-007045:mdna:55]
Capacity utilization is a key driver for us, which is measured by the actual production as a percentage of maximum capacity. This measure is particularly important in our high volume facilities in Asia, as a significant portion of our operating costs are fixed in nature. Capacity utilization for the year ended December 28, 2020 in our Asia and North America PCB facilities was 62% and 62%, respectively, compared to 61% and 60%, respectively, for the year ended December 30, 2019. The increase in capacity utilization in our Asia and North America PCB facilities was due to an increase in production related to increased sales in our Aerospace and Defense, Medical/Industrial/Instrumentation, and Computing/Storage/Peripherals end markets.

[0001564590-21-007045:mdna:56]
Selling and Marketing Expenses

[0001564590-21-007045:mdna:57]
Selling and marketing expenses decreased $5.3 million to $63.9 million for the year ended December 28, 2020 from $69.2 million for the year ended December 30, 2019. As a percentage of net sales, selling and marketing expenses were 3.0% for the year ended December 28, 2020 as compared to 3.2% for the year ended December 30, 2019. The decrease in selling and marketing expenses in 2020 was primarily due to reduced travel expense and other costs as a result of the COVID-19 pandemic, which has decreased travel on a temporary basis and commission expense.

[0001564590-21-007045:mdna:58]
Selling and marketing expenses decreased $0.9 million to $69.2 million for the year ended December 30, 2019 from $70.1 million for the year ended December 31, 2018. As a percentage of net sales, selling and marketing expenses were 3.2% for the year ended December 30, 2019 as compared to 3.1% for the year ended December 31, 2018. The decrease in selling and marketing expenses in 2019 was primarily due to reduced travel expenses.

[0001564590-21-007045:mdna:59]
General and Administrative Expenses

[0001564590-21-007045:mdna:60]
General and administrative expenses decreased $6.8 million to $122.5 million, or 5.8% of net sales, for the year ended December 28, 2020 from $129.3 million, or 6.1% of net sales, for the year ended December 30, 2019. This decrease was primarily due to a decrease in acquisition costs and cost reduction efforts as a result of the COVID-19 pandemic.

[0001564590-21-007045:mdna:61]
General and administrative expenses decreased $9.0 million to $129.3 million, or 6.1% of net sales, for the year ended December 30, 2019 from $138.3 million, or 6.2% of net sales, for the year ended December 31, 2018. This decrease in expense was primarily due to the decrease in acquisition-related costs of $6.4 million primarily associated with the acquisition of Anaren on April 18, 2018 and a decrease of $8.9 million primarily due to stock-based compensation and incentive compensation expense, partially offset by $6.4 million for the additional three and a half months of general and administrative expense associated with operations acquired in the Anaren acquisition in 2019 (which occurred on April 18, 2018).

[0001564590-21-007045:mdna:62]
Restructuring Charges

[0001564590-21-007045:mdna:63]
For the years ended December 28, 2020, December 30, 2019 and December 31, 2018, we incurred restructuring charges of $16.8 million, $5.4 million and $4.7 million, respectively, related to the restructuring of our E-M Solutions business unit and other global realignment restructuring efforts.

[0001564590-21-007045:mdna:64]
For the year ended December 28, 2020, we recognized restructuring charges of $16.6 million and $0.2 million in our E-M Solutions reportable segment and Corporate, respectively. For the year ended December 30, 2019, we recognized restructuring charges of $5.2 million and $0.1 million in our PCB and RF&S Components reportable segments, respectively, and $0.1 million in Corporate. For the year ended December 31, 2018, we recognized restructuring charges of $1.2 million and $3.5 million in our PCB reportable segment and Corporate, respectively. These charges primarily represent employee separation and contract termination and other costs associated with the restructuring plans.

[0001564590-21-007045:mdna:65]
Impairment of Goodwill

[0001564590-21-007045:mdna:66]
For the year ended December 28, 2020, we recorded a goodwill impairment charge of $69.2 million. See Note 5 of the Notes to Consolidated Financial Statements for further information.

[0001564590-21-007045:mdna:67]
Other Expense

[0001564590-21-007045:mdna:68]
Other expense, net decreased $0.9 million to $74.4 million for the year ended December 28, 2020 from $75.3 million for the year ended December 30, 2019. The decrease in other expense, net was primarily due to:

[0001564590-21-007045:mdna:69]
|  | • | a decrease in interest expense of $8.9 million mainly as a result of a $400.0 million debt principal prepayment for the Term Loan made during the year ended December 28, 2020 and lower interest rates, |

[0001564590-21-007045:mdna:70]
|  | • | partially offset by an increase in foreign currency losses due to the strengthening of the Chinese Renminbi (RMB) during the year ended December 28, 2020 compared to the year ended December 30, 2019. We utilize the RMB at our China facilities for employee-related expenses, RMB denominated purchases, and other costs of running our operations in China. |

[0001564590-21-007045:mdna:71]
Other expense, net increased $3.5 million to $75.3 million for the year ended December 30, 2019 from $71.8 million for the year ended December 31, 2018. The increase in other expense, net was primarily due to:

[0001564590-21-007045:mdna:72]
|  | • | an increase in interest expense of $6.3 million, primarily related to the $600.0 million incremental debt incurred in conjunction with the Anaren acquisition, |

[0001564590-21-007045:mdna:73]
|  | • | partially offset by an increase in other income related to the sale of other assets of $4.0 million. |

[0001564590-21-007045:mdna:74]
Income Taxes

[0001564590-21-007045:mdna:75]
The provision for income taxes decreased $32.3 million to an income tax benefit of $29.9 million for the year ended December 28, 2020 from an income tax expense of $2.4 million for the year ended December 30, 2019. The change in income tax from an expense to a benefit in 2020 was primarily due to the release of uncertain tax positions in 2020 totaling $34.7 million as a result of statute of limitation expirations and the conclusion of a tax exam. This was partially offset by tax expense related to the retroactive approval of the Company’s renewal application for High and New Tax Enterprise status for one of the Company’s manufacturing subsidiaries in China (including the impact on the respective Company’s deferred tax assets) and by an increase in the deferred tax liability related to unremitted foreign earnings.

[0001564590-21-007045:mdna:76]
Our effective tax rate is primarily impacted by tax rates in China and Hong Kong, the US federal income tax rate, apportioned state income tax rates, generation of credits and deductions available to us, as well as changes in valuation allowances, certain non-deductible items, global intangible low taxed income, and the establishment of a deferred tax liability related to unremitted foreign earnings.

[0001564590-21-007045:mdna:77]
The provision for income taxes increased $90.6 million to an income tax expense of $2.4 million for the year ended December 30, 2019 from an income tax benefit of $88.2 million for the year ended December 31, 2018. The increase in income tax expense in 2019 was primarily due to the absence of a $121.4 million release of the Company’s valuation allowance against its net deferred tax assets in 2018, partially offset by a reduction in the deferred tax liability related to unremitted foreign earnings and tax benefits resulted from decreased income before income taxes.

[0001564590-21-007045:mdna:78]
Liquidity and Capital Resources

[0001564590-21-007045:mdna:79]
Our principal sources of liquidity have been cash provided by operations, the issuance of debt, and borrowings under our Revolving Credit Facility. Our principal uses of cash have been to finance capital expenditures, finance acquisitions, fund working capital requirements, and to repay existing debt. We anticipate that financing capital expenditures, financing acquisitions, funding working capital requirements, servicing debt, and potential share repurchases will be the principal demands on our cash in the future.

[0001564590-21-007045:mdna:80]
Cash flow provided by operating activities for continuing operations during the year ended December 28, 2020 was $247.7 million as compared to $295.8 million in the same period in 2019. The decrease in cash flow was primarily due to decrease in net income of $48.3 million.

[0001564590-21-007045:mdna:81]
Net cash used in investing activities for continuing operations was approximately $93.6 million for the year ended December 28, 2020 comprised primarily of purchases of property, plant and equipment and other assets. Net cash used in investing activities was approximately $111.8 million for the year ended December 30, 2019 primarily reflecting $118.0 million for purchases of property, plant and equipment and other assets less proceeds from sale of property, plant and equipment and other assets of $6.2 million.

[0001564590-21-007045:mdna:82]
Net cash used in financing activities for continuing operations during the year ended December 28, 2020 was $642.3 million, primarily reflecting repayment of long-term debt of $650.0 million. Net cash used in financing activities was approximately $31.8 million for the year ended December 30, 2019, primarily reflecting repayment of long-term debt of $30.0 million and payment of debt issuance costs of $1.8 million.

[0001564590-21-007045:mdna:83]
We received pre-tax proceeds from the sale of the Mobility business unit, net of cash disposed, of $507.5 million during the year ended December 28, 2020, which have been presented in the consolidated statements of cash flows within net cash provided by investing activities from discontinued operations.

[0001564590-21-007045:mdna:84]
As of December 28, 2020, we had cash and cash equivalents of approximately $451.6 million, of which approximately $221.4 million was held by our foreign subsidiaries, primarily in China. Should we choose to remit cash to the United States from our foreign locations, we may incur tax obligations which would reduce the amount of cash ultimately available to the United States. However, we believe there would be no material tax consequences not previously accrued for on the repatriation of this cash.

[0001564590-21-007045:mdna:85]
Our 2021 capital expenditure plan is expected to be in the range of $90.0 million to $110.0 million.

[0001564590-21-007045:mdna:86]
Long-term Debt and Letters of Credit

[0001564590-21-007045:mdna:87]
As of December 28, 2020, we had $842.9 million of outstanding debt, net of discount and debt issuance costs, composed of $402.4 million of Term Loan due September 2024, $370.5 million of Senior Notes due October 2025, $40.0 million under the U.S. Asset-Based Lending Credit Agreement (U.S. ABL), and $30.0 million under the Asia Asset-Based Lending Credit Agreement (Asia ABL).

[0001564590-21-007045:mdna:88]
Pursuant to the terms of the Term Loan Facility and Senior Notes, we are subject to certain affirmative and negative covenants, including limitations on indebtedness, corporate transactions, investments, dispositions, and share payments. Under the occurrence of certain events, as a result of the ABL Revolving Loans, we are also subject to various financial and operational covenants, including maintaining minimum fixed charge coverage ratios. As of December 28, 2020, we were in compliance with the covenants under the Term Loan Facility, Senior Notes and ABL Revolving Loans.

[0001564590-21-007045:mdna:89]
Based on our current level of operations, we believe that cash generated from operations, cash on hand and cash from the issuance of term and revolving debt will be adequate to meet our currently anticipated capital expenditure, debt service, and working capital needs for the next twelve months. Additional information regarding our indebtedness, including information about the credit available under our debt facilities, interest rates and other key terms of our outstanding indebtedness, is included in Note 7 of the Notes to Consolidated Financial Statements included in this Annual Report on Form 10-K.

[0001564590-21-007045:mdna:90]
Contractual Obligations and Commitments

[0001564590-21-007045:mdna:91]
The following table provides information on our contractual obligations as of December 28, 2020:

[0001564590-21-007045:mdna:92]
|  |  | Total |  |  | Less Than 1 Year |  |  | 1 - 3 Years |  |  | 4 - 5 Years |  |  | After 5 Years |  |
| Contractual Obligations (1) |  | (In thousands) |  |
| Long-term debt obligations |  | $ | 850,879 |  |  | $ | — |  |  | $ | — |  |  | $ | 850,879 |  |  | $ | — |  |
| Interest on debt obligations |  |  | 149,856 |  |  |  | 33,211 |  |  |  | 65,964 |  |  |  | 50,681 |  |  |  | — |  |
| Derivative liabilities |  |  | 16,384 |  |  |  | 10,977 |  |  |  | 5,407 |  |  |  | — |  |  |  | — |  |
| Purchase obligations |  |  | 104,943 |  |  |  | 75,924 |  |  |  | 20,098 |  |  |  | 724 |  |  |  | 8,197 |  |
| Total contractual obligations |  | $ | 1,122,062 |  |  | $ | 120,112 |  |  | $ | 91,469 |  |  | $ | 902,284 |  |  | $ | 8,197 |  |

[0001564590-21-007045:mdna:93]
| (1) | Unrecognized uncertain tax benefits of $2.6 million are not included in the table above as the settlement timing is uncertain. Operating leases are not included in the table above – see Note 2 of the Notes to Consolidated Financial Statements for further details. |

[0001564590-21-007045:mdna:94]
Off-Balance Sheet Arrangements

[0001564590-21-007045:mdna:95]
We do not have any relationships with unconsolidated entities or financial partnerships, such as entities often referred to as structured finance or special purpose entities, which would have been established for the purpose of facilitating off-balance sheet arrangements or other contractually narrow or limited purposes. In addition, we do not engage in trading activities involving non-exchange traded contracts. As a result, we are not materially exposed to any financing, liquidity, market, or credit risk that could arise if we had engaged in these relationships.

[0001564590-21-007045:mdna:96]
Seasonality

[0001564590-21-007045:mdna:97]
Orders for our products generally correspond to the production schedules of our customers. We historically experience seasonal fluctuations in the first quarter due to the Chinese New Year holidays, which typically results in lower net sales for that quarter. We attribute this decline to shutdowns of our customers’ and our own China based manufacturing facilities surrounding the Chinese New Year public holidays, which normally occur in January or February of each year.

[0001564590-21-007045:mdna:98]
Recently Issued Accounting Standards

[0001564590-21-007045:mdna:99]
For a description of recently adopted and issued accounting standards, including the respective dates of adoption and expected effects on our results of operations and financial condition, see Note 1 of the Notes to Consolidated Financial Statements.
