# TTMI notes — 0001564590-18-020718


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0001564590-18-020718:notes:1]
[same as prior period, unchanged from 0001564590-18-011836:notes:1]

[0001564590-18-020718:notes:2]
TTM Technologies, Inc. (the Company or TTM) is a leading global printed circuit board (PCB) manufacturer, focusing on quick-turn and volume production of technologically complex PCBs and electro-mechanical solutions (E-M Solutions) as well as a global designer and manufacturer of high-frequency radio frequency (RF) and microwave components and assemblies. The Company provides time-to-market and volume production of advanced technology products and offers a one-stop manufacturing solution to customers from engineering support to prototype development through final mass production. This one-stop manufacturing solution enables the Company to align technology developments with the diverse needs of the Company’s customers and to enable them to reduce the time required to develop new products and bring them to market.

[0001564590-18-020718:notes:3]
[same as prior period, unchanged from 0001564590-18-011836:notes:3]

[0001564590-18-020718:notes:4]
[same as prior period, unchanged from 0001564590-18-011836:notes:4]

[0001564590-18-020718:notes:5]
[same as prior period, unchanged from 0001564590-18-011836:notes:5]

[0001564590-18-020718:notes:6]
In May 2014, the Financial Accounting Standards Board (FASB) issued Accounting Standards Update (ASU) 2014-09, Revenue from Contracts with Customers (Topic 606), which replaces most existing revenue recognition guidance in U.S. GAAP, including industry specific requirements, and provides companies with a single revenue recognition model for recognizing revenue of contracts with customers. The core principle of the new revenue standard is that a company should recognize revenue to depict the transfer of promised goods or services to customers in an amount that reflects the consideration to which the company expects to be entitled in exchange for those goods or services.

[0001564590-18-020718:notes:7]
The Company assessed the new guidance and adopted the new revenue standard on January 2, 2018, which resulted in a change to the timing of revenue recognition for certain of the Company’s revenue streams from “point in time” upon physical delivery to an “over time” model. Additionally, the Company elected the cumulative effect transition method with adjustment to the opening balance of retained earnings at January 2, 2018 for all open contracts as of January 1, 2018. Therefore, comparative information has not been adjusted and continues to be reported under previous U.S. GAAP guidance for the consolidated balance sheet at January 1, 2018 and the consolidated condensed statement of operations for the quarter and two quarters ended July 3, 2017.

[0001564590-18-020718:notes:8]
The cumulative effect of the changes made to the Company’s January 2, 2018 consolidated condensed balance sheet for the adoption of the new revenue standard was as follows:

[0001564590-18-020718:notes:9]
[same as prior period, unchanged from 0001564590-18-011836:notes:9]

[0001564590-18-020718:notes:10]
[same as prior period, unchanged from 0001564590-18-011836:notes:10]

[0001564590-18-020718:notes:11]
Additionally, the disclosure below summarizes the impact of the adoption of the new revenue standard on the Company’s consolidated condensed balance sheet as of July 2, 2018, statement of operations for the quarter and two quarters ended July 2, 2018 and statement of cash flows for the two quarters ended July 2, 2018 for which the As Reported reflects the new revenue standard and Balances without New Revenue Standard Adjustment reflects the Company’s replaced revenue recognition policy of “point in time” and upon physical delivery, for certain revenue streams, as appropriate.

[0001564590-18-020718:notes:12]
|  |  | July 2, 2018 |  |
|  |  | As reported |  |  | Effect of Change Increase (Decrease) |  |  | Balances without New Revenue Standard Adjustment |  |
|  |  | (In thousands) |  |
| Balance Sheet |  |  |  |  |  |  |  |  |  |  |  |  |
| Assets |  |  |  |  |  |  |  |  |  |  |  |  |
| Accounts receivable, net |  | $ | 541,587 |  |  | $ | 8,171 |  |  | $ | 533,416 |  |
| Contract assets |  |  | 300,717 |  |  |  | 293,114 |  |  |  | 7,603 |  |
| Inventories |  |  | 121,285 |  |  |  | (245,895 | ) |  |  | 367,180 |  |
| Liabilities |  |  |  |  |  |  |  |  |  |  |  |  |
| Other accrued expenses |  |  | 104,139 |  |  |  | 14,033 |  |  |  | 90,106 |  |
| Other long-term liabilities |  |  | 92,938 |  |  |  | 3,163 |  |  |  | 89,775 |  |
| Equity |  |  |  |  |  |  |  |  |  |  |  |  |
| Retained earnings |  |  | 315,975 |  |  |  | 38,194 |  |  |  | 277,781 |  |

[0001564590-18-020718:notes:13]
|  |  | Quarter ended July 2, 2018 |  |  | Two Quarters ended July 2, 2018 |  |
|  |  | As reported |  |  | Effect of Change Increase (Decrease) |  |  | Balances without New Revenue Standard Adjustment |  |  | As reported |  |  | Effect of Change Increase |  |  | Balances without New Revenue Standard Adjustment |  |
|  |  | (In thousands) |  |  | (In thousands) |  |
| Net sales |  | $ | 716,887 |  |  | $ | 17,730 |  |  | $ | 699,157 |  |  | $ | 1,380,469 |  |  | $ | 31,811 |  |  | $ | 1,348,658 |  |
| Cost of goods sold |  |  | 600,747 |  |  |  | (10,338 | ) |  |  | 611,085 |  |  |  | 1,175,651 |  |  |  | 22,319 |  |  |  | 1,153,332 |  |
| Gross profit |  |  | 116,140 |  |  |  | 7,392 |  |  |  | 108,748 |  |  |  | 204,818 |  |  |  | 9,492 |  |  |  | 195,326 |  |
| Net income |  |  | 84,004 |  |  |  | 7,392 |  |  |  | 76,612 |  |  |  | 94,101 |  |  |  | 9,620 |  |  |  | 84,481 |  |

[0001564590-18-020718:notes:14]
Included in the Effect of Change Increase (Decrease) columns for the quarter and two quarters ended July 2, 2018 are $14,408, $11,375 and $3,033 of net sales, cost of goods sold and gross profit, respectively, related to the opening balance sheet of Anaren Inc. which was acquired on April 18, 2018 (See Note 3), and not to the activity during the quarter.

[0001564590-18-020718:notes:15]
|  |  | Two Quarters ended July 2, 2018 |  |
|  |  | As reported |  |  | Effect of Change Increase (Decrease) |  |  | Balances without New Revenue Standard Adjustment |  |
|  |  | (In thousands) |  |
| Cash flows from operating activities: |  |  |  |  |  |  |  |  |  |  |  |  |
| Net income |  | $ | 94,101 |  |  | $ | 9,620 |  |  | $ | 84,481 |  |
| Adjustments to reconcile net income to net cash used in operating activities: |  |  |  |  |  |  |  |  |  |  |  |  |
| Deferred income taxes |  |  | (64,769 | ) |  |  | (128 | ) |  |  | (64,641 | ) |
| Changes in operating assets and liabilities: |  |  |  |  |  |  |  |  |  |  |  |  |
| Accounts receivable, net |  |  | (17,056 | ) |  |  | — |  |  |  | (17,056 | ) |
| Contract assets |  |  | (16,478 | ) |  |  | (32,460 | ) |  |  | 15,982 |  |
| Inventories |  |  | 5,685 |  |  |  | 22,319 |  |  |  | (16,634 | ) |
| Accrued salaries, wages and benefits and other accrued expenses |  |  | (47,911 | ) |  |  | 649 |  |  |  | (48,560 | ) |

[0001564590-18-020718:notes:16]
In August 2017, the FASB issued ASU 2017-12, Derivatives and Hedging (Topic 815): Targeted Improvements to Accounting for Hedging Activities. This ASU amends and simplifies existing guidance in order to allow companies to more accurately present the economic effects of risk management activities in the financial statements. ASU 2017-12 also amends the guidance surrounding the recognition of the value of hedged instruments to include the entire change in value, rather than just the effective portion, in other comprehensive income and recognized in earnings at the same time that the hedged item affects earnings for cash flow and net investment hedges. This ASU is effective for fiscal years beginning after December 15, 2018, including interim periods within those fiscal years. Early adoption is permitted. The adoption of this standard is not expected to have a material impact on the consolidated financial statements or related disclosures.

[0001564590-18-020718:notes:17]
In February 2016, the FASB issued ASU 2016-02, Leases (Topic 842). The objective of this update is to increase transparency and comparability among organizations by recognizing lease assets and lease liabilities on the balance sheet and disclosing key information about leasing arrangements. This ASU is effective for fiscal years beginning after December 15, 2018, including interim periods within those annual periods and is to be applied utilizing a modified retrospective approach. The Company is currently planning on electing the package of practical expedients to not reassess prior conclusions related to contracts containing leases, lease classification and initial direct costs, and is evaluating other practical expedients available under the guidance. Additionally, the Company continues to evaluate the new guidance to determine the impact it may have on its consolidated financial statements and related disclosures, the primary effect of adopting this update will be to record assets and liabilities for existing operating leases.


## us-gaap:SignificantAccountingPoliciesTextBlock

[0001564590-18-020718:notes:18]
[same as prior period, unchanged from 0001564590-18-011836:notes:17]

[0001564590-18-020718:notes:19]
[same as prior period, unchanged from 0001564590-18-011836:notes:18]

[0001564590-18-020718:notes:20]
The Company derives revenues primarily from the sale of PCBs, custom electronic assemblies using customer-supplied engineering and design plans.  With the acquisition of Anaren Inc. (See Note 3), the Company now also derives revenue from the design, development, and manufacture of components, assemblies, and subsystems which receive, process, and transmit microwave and RF signals which service the aerospace and defense electronics, and wireless communications markets.

[0001564590-18-020718:notes:21]
The Company has three revenue streams which generally coincide with the Company’s reportable segments. These reportable segments are: PCB, E-M Solutions and Anaren.  See Note 17 Segment Information.

[0001564590-18-020718:notes:22]
For the PCBs and custom electronic assemblies, orders for products generally correspond to the production schedules of the Company’s customers and are supported with firm purchase orders. The Company’s customers have continuous transfer of control of the work in progress and finished goods throughout the PCB manufacturing process, as PCBs are built to customer specifications and do not have an alternative use. The customer typically controls the work in progress and finished goods as evidenced either by contractual termination clauses or by the Company’s rights to payment for work performed to date, plus a reasonable profit.  As a result, the Company records revenue in accordance with the “over time” revenue standard as discussed in Note 1 Nature of Operations and Basis of Presentation ─ Recently Adopted and Issued Accounting Standards, beginning in the first quarter of 2018, the Company now recognizes revenue progressively over time based on the extent of progress towards completion of the performance obligation.

[0001564590-18-020718:notes:23]
[same as prior period, unchanged from 0001564590-18-011836:notes:20]

[0001564590-18-020718:notes:24]
Additionally, the Company has certain long-term contracts related to its manufacture of components, assemblies, and subsystems which service the aerospace and defense electronics market. These long-term contracts, many of which provide for periodic payments, are recognized over time under the percentage-of completion method. Estimated manufacturing cost-at-completion for these contracts are reviewed on a periodic basis, and adjustments are made periodically to the estimated cost-at-completion, based on actual costs incurred, progress made, and estimates of costs required to complete the contractual requirements. When the estimated manufacturing cost-at-completion exceeds the contract value, the contract is written down to its net realizable value and the loss resulting from the cost overruns are immediately recognized.

[0001564590-18-020718:notes:25]
Finally, the Company manufactures components, assemblies, and subsystems which service its wireless communications customers. The Company recognizes revenue at a point in time as the customer does not simultaneously receive or consume the benefits provided by the Company’s performance and the asset being manufactured has alternative uses to the Company.

[0001564590-18-020718:notes:26]
The Company provides customers a limited right of return for defective PCBs, assemblies, components and subsystems. The Company accrues an estimate for sales returns and allowances progressively over time based on the extent of progress towards completion of the performance obligation using the Company’s judgment based on historical results and anticipated returns.  To the extent actual experience varies from its historical experience, revisions to the sales returns and allowances accrual may be required. Sales returns and allowances are recorded as a reduction of revenue and included as a component of accrued liabilities on the condensed consolidated balance sheet.


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001564590-18-020718:notes:27]
(3) Acquisition of Anaren Inc.

[0001564590-18-020718:notes:28]
On April 18, 2018, the Company completed its acquisition of all issued and outstanding common stock of Anaren Holding Corp. for a total consideration of $787,911 subject to customary working capital and certain other adjustments. Other than the equity interests of Anaren, Inc. (Anaren), Anaren Holding Corp. had no material assets or liabilities and has no material independent operations. Anaren is a leading provider of mission-critical RF solutions, microelectronics, and microwave components and assemblies for the wireless infrastructure and aerospace and defense electronics markets.

[0001564590-18-020718:notes:29]
For the quarter and two quarters ended July 2, 2018, bank fees and legal, accounting, and other professional service costs associated with the acquisition of $6,852 and $10,825, respectively, have been expensed and recorded as general and administrative expense in the consolidated condensed financial statements. There were no bank fees or legal, accounting, or other professional service costs associated with the acquisition for the quarter and two quarters ended July 3, 2017.

[0001564590-18-020718:notes:30]
The following summarizes the components of the purchase price:

[0001564590-18-020718:notes:31]
|  |  | (In thousands) |  |
| Cash consideration |  | $ | 596,396 |  |
| Cash purchased |  |  | 12,911 |  |
|  |  |  | 609,307 |  |
| Debt assumed |  |  | 178,604 |  |
| Total consideration |  | $ | 787,911 |  |

[0001564590-18-020718:notes:32]
Preliminary Purchase Price Allocation

[0001564590-18-020718:notes:33]
The purchase price was allocated to tangible and intangible assets acquired, and liabilities assumed based on preliminary estimates of fair value at the date of the acquisition, April 18, 2018. The excess of the purchase price over the fair value of net assets acquired was allocated to goodwill. The fair value assigned to identifiable intangible assets acquired was based on estimates and assumptions made by management at the time of the acquisition.

[0001564590-18-020718:notes:34]
The fair values assigned are based on reasonable methods applicable to the nature of the assets acquired and liabilities assumed. The following summarizes the preliminary estimated fair values of net assets acquired:

[0001564590-18-020718:notes:35]
|  |  | (In thousands) |  |
| Cash |  | $ | 12,911 |  |
| Trade and notes receivables |  |  | 32,457 |  |
| Contract assets |  |  | 23,585 |  |
| Inventories |  |  | 55,958 |  |
| Other current assets |  |  | 1,673 |  |
| Property, plant and equipment |  |  | 47,329 |  |
| Identifiable intangible assets |  |  | 337,000 |  |
| Goodwill |  |  | 386,278 |  |
| Trade accounts payable |  |  | (14,629 | ) |
| Contract liabilities |  |  | (7,778 | ) |
| Other current liabilities |  |  | (3,757 | ) |
| Long-term debt |  |  | (178,604 | ) |
| Non-current deferred tax liabilities |  |  | (75,123 | ) |
| Other liabilities |  |  | (7,993 | ) |
| Total |  | $ | 609,307 |  |

[0001564590-18-020718:notes:36]
Due to the fact that the acquisition occurred in the current interim period, the Company’s fair value estimates for the purchase price allocation are preliminary and may change during the allowable measurement period, which is up to the point the Company obtains and analyzes the information that existed as of the date of the acquisition necessary to determine the fair values of the assets acquired and liabilities assumed, but in no case to exceed more than one year from the date of acquisition. As of July 2, 2018, the Company had not finalized the determination of fair values allocated to various assets and liabilities, including, but not limited to, property, plant and equipment, identifiable intangible assets, other assets, deferred taxes, goodwill, tax uncertainties, income taxes payable and liabilities assumed. Any changes in the fair values of the assets acquired and liabilities assumed during the measurement period may result in material adjustments to goodwill.

[0001564590-18-020718:notes:37]
Inventories

[0001564590-18-020718:notes:38]
The Company acquired $55,958 of inventories as a result of the acquisition. Finished goods were preliminarily valued at estimated selling prices less costs of disposal and a reasonable profit allowance for the selling effort. Work-in-process inventory was valued at estimated selling prices less costs to complete, costs of disposal and a reasonable profit allowance for the completion and selling effort. Raw materials were preliminarily valued at estimated replacement cost.

[0001564590-18-020718:notes:39]
Property, Plant and Equipment

[0001564590-18-020718:notes:40]
The fair value of property, plant and equipment was preliminarily determined by utilizing three approaches: the cost, sales comparison, and income capitalization approaches, each including management assumptions. Each approach assumes valuation of the property at the property’s highest and best use.

[0001564590-18-020718:notes:41]
Identifiable Intangible Assets

[0001564590-18-020718:notes:42]
Acquired identifiable intangible assets include customer relationships, developed technology and backlog. The fair value of the identifiable intangible assets was preliminarily determined using various income approach methods including excess earnings to determine the present value of expected future cash flows for each identifiable intangible asset based on discount rates which incorporate a risk premium to take into account the risks inherent in those expected cash flows. The expected cash flows were estimated using available historical data adjusted based on the Company’s historical experience and the expectations of market participants. The preliminary estimated fair value assigned to each class of intangible assets and the related weighted average amortization periods are as follows:

[0001564590-18-020718:notes:43]
|  |  | Estimated fair value |  |  | Weighted- average amortization period |
|  |  | (In thousands) |  |  |  |
| Customer relationships |  | $ | 268,000 |  |  | 12.2 years |
| Developed technology |  |  | 39,500 |  |  | 9.4 years |
| Backlog |  |  | 29,500 |  |  | 0.9 years |
|  |  | $ | 337,000 |  |  |  |

[0001564590-18-020718:notes:44]
Goodwill

[0001564590-18-020718:notes:45]
Goodwill represents the excess of the purchase price over the fair value of assets acquired and liabilities assumed. Prior to the Company’s acquisition of Anaren, the Company had two reportable segments: PCB and E-M Solutions. Due to the acquisition, the Company has reassessed its reportable segments and determined that it has three reportable segments: PCB, E-M Solutions and Anaren. However, beginning in the third quarter of 2018, the Company will no longer report Anaren as a reportable segment as the Company will integrate it into the PCB reportable segment. The excess purchase price over the fair value of assets acquired and liabilities assumed has been completely allocated to the Anaren reportable segment.

[0001564590-18-020718:notes:46]
The Company believes that the acquisition of Anaren will produce the following significant benefits:

[0001564590-18-020718:notes:47]
|  | • | Provide the Company with differentiated RF expertise in aerospace and defense and embedded technology that the Company believes is critical to wireless infrastructure markets. |

[0001564590-18-020718:notes:48]
|  | • | Augment the Company’s strong aerospace and defense position and provide new opportunities for growth in the automotive and optical networking market. |

[0001564590-18-020718:notes:49]
|  | • | Deepen the Company’s engagement and interaction with leading customers in the aerospace and defense and wireless communication infrastructure markets. |

[0001564590-18-020718:notes:50]
|  | • | Strengthen the Company’s management and engineering teams with the addition of talented members having extensive experience in RF design; |

[0001564590-18-020718:notes:51]
The Company believes that these primary factors support the amount of goodwill recognized as a result of the purchase price paid for Anaren, in relation to other acquired tangible and intangible assets. The goodwill acquired in the acquisition is not deductible for income tax purposes.

[0001564590-18-020718:notes:52]
Results of Operations

[0001564590-18-020718:notes:53]
Included in the consolidated condensed statements of operations for the quarter and two quarters ended July 2, 2018 are net sales of $62,011, excluding intercompany sales, and pre-tax net income of $13,307 from the Anaren operations.

[0001564590-18-020718:notes:54]
Pro forma Financial Information

[0001564590-18-020718:notes:55]
The unaudited pro forma financial information below gives effect to this acquisition as if it had occurred at the beginning of fiscal 2017, or January 3, 2017. The pro forma financial information presented includes the effects of adjustments related to the amortization of acquired identifiable intangible assets and acquired inventory, depreciation of acquired fixed assets, and other non-recurring transactions costs directly associated with the acquisitions such as legal, accounting and banking fees.

[0001564590-18-020718:notes:56]
The pro forma financial information as presented below is for informational purposes only and is not necessarily indicative of the actual results that would have been achieved had the acquisition occurred at the beginning of the earliest period presented, or the results that may be achieved in future periods.

[0001564590-18-020718:notes:57]
|  |  | Quarter Ended |  |  | Two Quarters Ended |  |
|  |  | July 2, |  |  | July 3, |  |  | July 2, |  |  | July 3, |  |
|  |  | 2018 |  |  | 2017 |  |  | 2018 |  |  | 2017 |  |
|  |  | (In thousands) |  |  | (In thousands) |  |
| Net sales |  | $ | 722,294 |  |  | $ | 693,508 |  |  | $ | 1,449,143 |  |  | $ | 1,369,519 |  |
| Net income attributable to TTM Technologies, Inc. stockholders |  |  | 91,347 |  |  |  | 22,390 |  |  |  | 107,692 |  |  |  | 49,139 |  |
| Basic earnings per share |  | $ | 0.88 |  |  | $ | 0.22 |  |  | $ | 1.05 |  |  | $ | 0.48 |  |
| Dilutive earnings per share |  | $ | 0.70 |  |  | $ | 0.19 |  |  | $ | 0.86 |  |  | $ | 0.42 |  |


## ttmi:ContractWithCustomerAssetLiabilitiesTextBlock

[0001564590-18-020718:notes:58]
(4) Contract Asset and Liabilities

[0001564590-18-020718:notes:59]
A contract asset is recognized when the Company has recognized revenue, but not issued an invoice for payment.  Contract assets are classified as current assets and transferred to receivables when the entitlement to payment becomes unconditional. The Company’s contract assets are generally converted to trade account receivables within 90 days, at which time the Company is entitled to payment of the fixed price upon delivery of the finished product subject to customer payment terms. Contract assets were $300,717 as of July 2, 2018 and represent unbilled amounts for work performed to date, plus a reasonable profit. There were no contract assets as of January 1, 2018.

[0001564590-18-020718:notes:60]
A contract liability is recognized when the Company has received payment in advance for the future transfer of goods or services. The Company’s contract liabilities are generally converted to revenue within 90 days. Contract liabilities were $7,680 as of July 2, 2018 and represent customer advances for work yet to be performed, plus a reasonable profit. There were no contract liabilities as of January 1, 2018.


## us-gaap:InventoryDisclosureTextBlock

[0001564590-18-020718:notes:61]
(5) Inventories

[0001564590-18-020718:notes:62]
Inventories as of July 2, 2018 and January 1, 2018 consisted of the following:

[0001564590-18-020718:notes:63]
|  |  | As of |  |
|  |  | July 2, 2018 |  |  | January 1, 2018 |  |
|  |  | (in thousands) |  |
| Inventories: |  |  |  |  |  |  |  |  |
| Raw materials |  | $ | 105,603 |  |  | $ | 75,835 |  |
| Work-in-process |  |  | 12,407 |  |  |  | 120,031 |  |
| Finished goods |  |  | 3,275 |  |  |  | 98,722 |  |
|  |  | $ | 121,285 |  |  | $ | 294,588 |  |


## us-gaap:GoodwillDisclosureTextBlock

[0001564590-18-020718:notes:64]
(6) Goodwill

[0001564590-18-020718:notes:65]
As of July 2, 2018 and January 1, 2018, goodwill was as follows:

[0001564590-18-020718:notes:66]
|  |  | PCB |  |  | Anaren |  |  | Total |  |
|  |  | (In thousands) |  |
| Balance as of January 1, 2018 |  |  |  |  |  |  |  |  |  |  |  |  |
| Goodwill |  | $ | 543,971 |  |  | $ | — |  |  | $ | 543,971 |  |
| Accumulated impairment losses |  |  | (171,400 | ) |  |  | — |  |  |  | (171,400 | ) |
|  |  |  | 372,571 |  |  |  | — |  |  |  | 372,571 |  |
| Goodwill recognized during the two quarters ended July 2, 2018 |  |  | — |  |  |  | 386,278 |  |  |  | 386,278 |  |
| Balance as of July 2, 2018 |  |  |  |  |  |  |  |  |  |  |  |  |
| Goodwill |  |  | 543,971 |  |  |  | 386,278 |  |  |  | 930,249 |  |
| Accumulated impairment losses |  |  | (171,400 | ) |  |  | — |  |  |  | (171,400 | ) |
|  |  | $ | 372,571 |  |  | $ | 386,278 |  |  | $ | 758,849 |  |

[0001564590-18-020718:notes:67]
The assignment of goodwill related to the acquisition is preliminary and will be completed in conjunction with the final purchase price allocation.


## us-gaap:IntangibleAssetsDisclosureTextBlock

[0001564590-18-020718:notes:68]
(7) Definite-lived Intangibles

[0001564590-18-020718:notes:69]
As of July 2, 2018 and January 1, 2018, the components of definite-lived intangibles were as follows:

[0001564590-18-020718:notes:70]
|  |  | Gross Amount |  |  | Accumulated Amortization |  |  | Foreign Currency Translation Adjustment |  |  | Net Carrying Amount |  | Weighted Average Amortization Period |  |
|  |  | (In thousands) |  | (years) |  |
| July 2, 2018 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Customer relationships |  | $ | 203,634 |  |  | $ | (112,306 | ) |  | $ | — |  |  | $ | 91,328 |  |  | 8.1 |  |
| Technology |  |  | 3,000 |  |  |  | (3,000 | ) |  |  | — |  |  |  | — |  |  | 3 |  |
| Acquired intangibles from acquisition |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Customer relationships |  |  | 268,000 |  |  |  | (4,605 | ) |  |  | — |  |  |  | 263,395 |  |  | 12.2 |  |
| Developed technology |  |  | 39,500 |  |  |  | (986 | ) |  |  | — |  |  |  | 38,514 |  |  | 9.4 |  |
| Backlog |  |  | 29,500 |  |  |  | (8,137 | ) |  |  | — |  |  |  | 21,363 |  |  | 0.9 |  |
|  |  | $ | 543,634 |  |  | $ | (129,034 | ) |  | $ | — |  |  | $ | 414,600 |  |  |  |  |
| January 1, 2018: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Customer relationships |  | $ | 203,563 |  |  | $ | (101,089 | ) |  | $ | 72 |  |  | $ | 102,546 |  |  | 8.1 |  |
| Technology |  |  | 3,000 |  |  |  | (2,596 | ) |  |  | — |  |  |  | 404 |  |  | 3 |  |
|  |  | $ | 206,563 |  |  | $ | (103,685 | ) |  | $ | 72 |  |  | $ | 102,950 |  |  |  |  |

[0001564590-18-020718:notes:71]
[same as prior period, unchanged from 0001564590-18-011836:notes:32]

[0001564590-18-020718:notes:72]
Definite-lived intangibles are generally amortized using the straight line method of amortization over the estimated useful life, with the exception of certain customer relationship intangibles, which are amortized using an accelerated method of amortization based on estimated cash flows. Amortization expense was $19,489 and $5,910 for the quarters ended July 2, 2018 and July 3, 2017, respectively, and $25,350 and $11,822 for the two quarters ended July 2, 2018 and July 3, 2017, respectively.

[0001564590-18-020718:notes:73]
[same as prior period, unchanged from 0001564590-18-011836:notes:34]

[0001564590-18-020718:notes:74]
|  |  | (In thousands) |  |
| Remaining 2018 |  | $ | 38,084 |  |
| 2019 |  |  | 53,293 |  |
| 2020 |  |  | 45,430 |  |
| 2021 |  |  | 42,118 |  |
| 2022 |  |  | 39,013 |  |
| Thereafter |  |  | 196,662 |  |
|  |  | $ | 414,600 |  |


## us-gaap:LongTermDebtTextBlock

[0001564590-18-020718:notes:75]
(8) Long-term Debt and Letters of Credit

[0001564590-18-020718:notes:76]
The following table summarizes the long-term debt of the Company as of July 2, 2018 and January 1, 2018:

[0001564590-18-020718:notes:77]
|  |  | Interest Rate as of July 2, 2018 |  |  | Principal Outstanding as of July 2, 2018 |  |  | Interest Rate as of January 1, 2018 |  |  | Principal Outstanding as of January 1, 2018 |  |
|  |  | (In thousands) |  |
| Term Loan due September 2024 |  | 4.60% |  |  | $ | 945,879 |  |  | 4.06% |  |  | $ | 349,125 |  |
| Senior Notes due October 2025 |  | 5.63% |  |  |  | 375,000 |  |  | 5.63% |  |  |  | 375,000 |  |
| Convertible Senior Notes due December 2020 |  | 1.75% |  |  |  | 249,985 |  |  | 1.75% |  |  |  | 249,985 |  |
| U.S. ABL Revolving Loan due May 2020 |  | 3.60% |  |  |  | 40,000 |  |  | 3.06% |  |  |  | 17,000 |  |
| Asia ABL Revolving Loan due May 2020 |  | 3.50% |  |  |  | 30,000 |  |  | 2.96% |  |  |  | 30,000 |  |
| Capital Lease |  | 6.43% |  |  |  | 1,556 |  |  | 6.43% |  |  |  | 1,919 |  |
|  |  |  |  |  |  |  | 1,642,420 |  |  |  |  |  |  |  | 1,023,029 |  |
| Less: Long-term debt unamortized discount |  |  |  |  |  |  | (27,359 | ) |  |  |  |  |  |  | (30,513 | ) |
| Long-term debt unamortized debt issuance costs |  |  |  |  |  |  | (18,907 | ) |  |  |  |  |  |  | (12,459 | ) |
|  |  |  |  |  |  |  | 1,596,154 |  |  |  |  |  |  |  | 980,057 |  |
| Less: current maturities |  |  |  |  |  |  | (40,729 | ) |  |  |  |  |  |  | (4,578 | ) |
| Long-term debt, less current maturities |  |  |  |  |  | $ | 1,555,425 |  |  |  |  |  |  | $ | 975,479 |  |

[0001564590-18-020718:notes:78]
Term Loan Facility

[0001564590-18-020718:notes:79]
On April 18, 2018, the Company closed its $600,000 commitment of incremental loans concurrent with the completion of its acquisition of Anaren. These incremental loans increased the Company’s existing balance of its Term Loan Facility due 2024 from $348,250 to $948,250. This Term Loan Facility had an outstanding balance of $945,879 as of July 2, 2018, of which $40,000 is included in short-term debt and $905,879 is included in long-term debt. The Term Loan Facility was issued at a weighted average discount of 99.7% and bears interest, at the Company’s option, at a floating rate of LIBOR, plus an applicable interest margin of 2.50%, or an alternate base rate, (defined as the greater of the JP Morgan prime, the New York Fed bank rate plus 0.5% or LIBOR plus 1.0%), subject to a 1.0% floor plus an applicable margin of 1.5%. At July 2, 2018 the interest rate on the outstanding borrowings under the Term Loan Facility was 4.60%. There is no provision, other than an event of default, for the interest margin to increase. The Term Loan Facility will mature on September 28, 2024. The Term Loan Facility is secured by a significant amount of the domestic assets of the Company and a pledge of 65% of voting stock of the Company’s first tier foreign subsidiaries and is structurally senior to the Company’s Senior Notes and Convertible Senior Notes. See Senior Notes and Convertible Senior Notes below.

[0001564590-18-020718:notes:80]
The Company is required to make scheduled payments of the outstanding Term Loan Facility on a quarterly basis beginning January 1, 2018. Subsequent to July 2, 2018, the Company made an optional debt principal prepayment of $40,000. As a result of the prepayment, the Company is no longer required to make any quarterly scheduled payments until October 2022. However, based on certain parameters defined in the Term Loan Facility, including a First Lien Leverage Ratio, the Company may be required to make an additional principal payment on an annual basis beginning after fiscal year 2018. Any remaining outstanding balance under the Term Loan Facility is due at the maturity date of September 28, 2024.

[0001564590-18-020718:notes:81]
Borrowings under the Term Loan Facility are subject to certain affirmative and negative covenants, including limitations on indebtedness, corporate transactions, investments and dispositions, and share payments.

[0001564590-18-020718:notes:82]
Senior Notes

[0001564590-18-020718:notes:83]
The $375,000 of Senior Notes, which is included in long-term debt, bear interest at a rate of 5.63% per annum. Interest is payable semiannually in arrears on April 1 and October 1 of each year beginning April 1, 2018. The Senior Notes will mature on October 1, 2025.

[0001564590-18-020718:notes:84]
Borrowings under the Senior Notes are subject to certain affirmative and negative covenants, including limitations on indebtedness, corporate transactions, investments, dispositions, and share payments.

[0001564590-18-020718:notes:85]
Convertible Senior Notes due 2020

[0001564590-18-020718:notes:86]
The Company maintains 1.75% convertible senior notes in the amount of $249,985 due December 15, 2020. The convertible senior notes bear interest at a rate of 1.75% per annum. Interest is payable semiannually in arrears on June 15 and December 15 of each year. The convertible senior notes are senior unsecured obligations and rank equally to the Company’s future unsecured senior indebtedness and are senior in right of payment to any of the Company’s future subordinated indebtedness.

[0001564590-18-020718:notes:87]
As of July 2, 2018 and January 1, 2018, the following summarizes the equity components of the convertible senior notes included in additional paid-in capital:

[0001564590-18-020718:notes:88]
|  |  | As of July 2, 2018 and January 1, 2018 |  |
|  |  | Embedded conversion option — Convertible Senior Notes |  |  | Embedded conversion option — Convertible Senior Notes Issuance Costs |  |  | Total |  |
|  |  | (in thousands) |  |
| Convertible Senior Notes due 2020 |  | $ | 60,216 |  |  | $ | (1,916 | ) |  | $ | 58,300 |  |

[0001564590-18-020718:notes:89]
The components of interest expense resulting from the convertible senior notes for the quarter and two quarters ended July 2, 2018 and July 3, 2017 are as follows:

[0001564590-18-020718:notes:90]
|  |  | Quarter Ended |  |  | Two Quarters Ended |  |
|  |  | July 2, |  |  | July 3, |  |  | July 2, |  |  | July 3, |  |
|  |  | 2018 |  |  | 2017 |  |  | 2018 |  |  | 2017 |  |
|  |  | (In thousands) |  |  | (In thousands) |  |
| Contractual coupon interest |  | $ | 1,093 |  |  | $ | 1,093 |  |  | $ | 2,187 |  |  | $ | 2,187 |  |
| Amortization of debt discount |  | $ | 2,267 |  |  | $ | 2,125 |  |  | $ | 4,497 |  |  | $ | 4,216 |  |
| Amortization of debt issuance costs |  | $ | 227 |  |  | $ | 214 |  |  | $ | 451 |  |  | $ | 423 |  |

[0001564590-18-020718:notes:91]
Asset-Based Lending Agreements

[0001564590-18-020718:notes:92]
The Company maintains a $200,000 U.S. Asset-Based Lending Credit Agreement (U.S. ABL), and a $150,000 Asia Asset-Based Lending Credit Agreement (Asia ABL) (collectively the ABL Revolving Loans).

[0001564590-18-020718:notes:93]
The U.S. ABL consists of three tranches comprised of a revolving credit facility for up to $200,000, a letter of credit facility for up to $50,000, and swingline loans for up to $30,000, provided that at no time may amounts outstanding under the tranches exceed in aggregate $200,000 or the applicable borrowing base, which is a percentage of the principal amount of Eligible Accounts, as defined in the U.S. ABL agreement. Borrowings under the U.S. ABL bear interest at either a floating rate of LIBOR plus a margin of 150 basis points or JP Morgan Chase Bank’s prime rate plus a margin of 50 basis points, at the Company’s option. At July 2, 2018, the interest rate on the outstanding borrowings under the U.S. ABL was 3.60%. The applicable margin can vary based on the remaining availability of the facility, from 125 to 175 basis points for LIBOR-based loans and from 25 to 75 basis points for JP Morgan Chase Bank’s prime rate-based loans. Other than availability and an event of default, there are no other provisions for the interest margin to increase. The U.S. ABL will mature on May 31, 2020. Loans made under the U.S. ABL are secured first by all of the Company’s domestic cash, receivables and certain inventories as well as by a second position against a significant amount of the domestic assets of the Company and a pledge of 65% of the voting stock of the Company’s first tier foreign subsidiaries and are structurally senior to the Company’s Senior Notes and Convertible Senior Notes. See Senior Notes and Convertible Senior Notes above. At July 2, 2018, $40,000 of the U.S. ABL was outstanding and classified as long-term debt, which is consistent with its maturity date.

[0001564590-18-020718:notes:94]
The Asia ABL consists of two tranches comprised of a revolving credit facility for up to $150,000 and a letter of credit facility for up to $100,000, provided that at no time may amounts outstanding under both tranches exceed in aggregate $150,000 or the applicable borrowing base, which is a percentage of the principal amount of Eligible Accounts, as defined in the Asia ABL agreement. Borrowings under the Asia ABL bear interest at a floating rate of LIBOR plus 140 basis points. At July 2, 2018, the interest rate on the outstanding borrowings under the Asia ABL was 3.50%. There is no provision, other than an event of default, for the interest margin to increase. The Asia ABL will mature on May 22, 2020. Loans made under the Asia ABL are secured by a portion of the Company’s Asia Pacific cash and receivables and are structurally senior to the Company’s domestic obligations, including the Senior Notes and Convertible Senior Notes. See Senior Notes and Convertible Senior Notes above. At July 2, 2018, $30,000 of the Asia ABL was outstanding and classified as long-term debt, which is consistent with its maturity date.

[0001564590-18-020718:notes:95]
The Company has up to $50,000 and $100,000 Letters of Credit Facilities under the U.S. ABL and the Asia ABL, respectively. As of July 2, 2018, letters of credit in the amount of $6,137 were outstanding under the U.S. ABL and $13,469 were outstanding under the Asia ABL with various expiration dates through June 2019. Available borrowing capacity under the U.S. ABL and the Asia ABL was $153,863 and $106,531, respectively, which considers letters of credit outstanding at July 2, 2018.

[0001564590-18-020718:notes:96]
The Company is required to pay a commitment fee of 0.25% to 0.375% per annum on any unused portion of the U.S. ABL or Asia ABL. The Company incurred total commitment fees related to unused borrowing availability of $247 and $180 for the quarters ended July 2, 2018 and July 3, 2017, respectively, and $488 and $367 for the two quarters ended July 2, 2018 and July 3, 2017, respectively. Under the occurrence of certain events, the ABL Revolving Loans are subject to various financial and operational covenants, including maintaining minimum fixed charge coverage ratios.

[0001564590-18-020718:notes:97]
Other Credit Facility

[0001564590-18-020718:notes:98]
Additionally, the Company is party to a revolving loan credit facility (Chinese Revolver) with a lender in China. Under this arrangement, the lender has made available to the Company approximately $31,700 in unsecured borrowing with all terms of the borrowing to be negotiated at the time the Chinese Revolver is drawn upon. There are no commitment fees on the unused portion of the Chinese Revolver, and this arrangement expires in January 2019. As of July 2, 2018, the Chinese Revolver had not been drawn upon.

[0001564590-18-020718:notes:99]
Debt Issuance and Debt Discount

[0001564590-18-020718:notes:100]
As of July 2, 2018 and January 1, 2018, remaining unamortized debt discount and debt issuance costs for the Term Loan Facility, Senior Notes and Convertible Senior Notes are as follows:

[0001564590-18-020718:notes:101]
|  |  | As of July 2, 2018 |  |  | As of January 1, 2018 |  |
|  |  | Debt Issuance Costs |  |  | Debt Discount |  |  | Effective Interest Rate |  |  | Debt Issuance Costs |  |  | Debt Discount |  |  | Effective Interest Rate |  |
|  |  | (in thousands) |  |
| Term Loan due September 2024 |  | $ | 10,037 |  |  | $ | 3,037 |  |  | 4.66% |  |  | $ | 2,788 |  |  | $ | 1,691 |  |  | 3.96% |  |
| Senior Notes due October 2025 |  |  | 6,432 |  |  | — |  |  | 5.92% |  |  |  | 6,782 |  |  | — |  |  | 5.92% |  |
| Convertible Senior Notes |  |  | 2,438 |  |  |  | 24,322 |  |  | 6.48% |  |  |  | 2,889 |  |  |  | 28,822 |  |  | 6.48% |  |
|  |  | $ | 18,907 |  |  | $ | 27,359 |  |  |  |  |  |  | $ | 12,459 |  |  | $ | 30,513 |  |  |  |  |  |

[0001564590-18-020718:notes:102]
The above debt discount and debt issuance costs are recorded as a reduction of the debt and are amortized into interest expense using an effective interest rate over the duration of the debt.

[0001564590-18-020718:notes:103]
Remaining unamortized debt issuance costs for the ABL Revolving Loans of $1,921 and $2,421 as of July 2, 2018 and January 1, 2018, respectively, are included in other non-current assets and are amortized to interest expense over the duration of the ABL Revolving Loans using the straight line method of amortization.

[0001564590-18-020718:notes:104]
At July 2, 2018, the remaining weighted average amortization period for all unamortized debt discount and debt issuance costs was 4.1 years.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001564590-18-020718:notes:105]
(9) Income Taxes

[0001564590-18-020718:notes:106]
[same as prior period, unchanged from 0001564590-18-011836:notes:67]

[0001564590-18-020718:notes:107]
During the quarter and two quarters ended July 2, 2018, the Company’s effective tax rate was impacted by a net discrete benefit of $67,309 and $66,429, respectively. This is related to accrued interest expense on existing uncertain tax positions, tax incentives, release of uncertain tax positions due to the expiration of the statute of limitations in foreign jurisdictions, release of a portion of the Company’s valuation allowance against its U.S. federal and state net deferred tax assets, and an additional expense related to the non U.S. income tax effect of a change in assertion with respect to the Company’s indefinite reinvestment policy outside of the U.S. Additionally, no tax benefit was recorded on the losses incurred in certain foreign jurisdictions as a result of corresponding increases in the valuation allowances in these jurisdictions.

[0001564590-18-020718:notes:108]
During the quarter ended July 2, 2018, the Company recorded a discrete tax benefit of $74,599 (included in the net amount reported in the previous paragraph) related to the release of a portion of the Company’s valuation allowance against its U.S. federal and state net deferred tax assets as a result of the net deferred tax liability established with the acquisition of Anaren. The Company expects its earnings attributable to foreign subsidiaries will be indefinitely reinvested outside of the U.S. but to facilitate more efficient cash management outside of the U.S., the Company has revised its assertion such that a majority of foreign earnings can be repatriated up to the top tier foreign holding company and as such, has provided for an additional accrual of deferred tax liabilities as a discrete tax expense of $9,963 (also included in the net amount reported in the previous paragraph) for the quarter ended July 2, 2018.  The Company continues to maintain its indefinite reinvestment of earnings attributable to foreign subsidiaries with respect to the U.S. and, therefore, no deferred tax liabilities for U.S. income taxes on undistributed earnings are recorded.

[0001564590-18-020718:notes:109]
[same as prior period, unchanged from 0001564590-18-011836:notes:69]

[0001564590-18-020718:notes:110]
On December 22, 2017, the Tax Cuts and Jobs Act (Tax Act) was enacted. Accounting Standard Codification (ASC) 740, Accounting for Income Taxes, requires companies to recognize the effect of tax law changes in the period of enactment regardless of the effective date of those tax law changes. Certain provisions of the Tax Act were effective September 27, 2017, and others were effective or identified as of December 31, 2017 or January 1, 2018.

[0001564590-18-020718:notes:111]
[same as prior period, unchanged from 0001564590-18-011836:notes:71]

[0001564590-18-020718:notes:112]
[same as prior period, unchanged from 0001564590-18-011836:notes:72]

[0001564590-18-020718:notes:113]
[same as prior period, unchanged from 0001564590-18-011836:notes:73]

[0001564590-18-020718:notes:114]
Effects of tax law changes where a reasonable estimate of the accounting effects cannot yet been made include the one-time mandatory repatriation transition tax on the net accumulated earnings and profits of the Company’s foreign subsidiaries earned post 1986. For the year ended January 1, 2018, the Company had performed a preliminary earnings and profits analysis with consideration given to foreign loss carryforwards acquired as a result of the Company’s acquisitions and determined on a provisional basis that there should be no income tax effect in the current or any future period. For the quarter and two quarters ended July 2, 2018, the Company has continued to gather documentation to support its position and maintains that there should be no income tax effect.

[0001564590-18-020718:notes:115]
The Company has determined that the following provisions that are effective January 1, 2018 and relevant to the Company will not impact the quarter and two quarters ended July 2, 2018 tax expense, primarily as a result of the full valuation allowance in the U.S.: limitations on certain entertainment expenses, the inclusion of commissions and performance based compensation in determining the excessive compensation limitation, limitation on the current deductibility of net interest expense in excess of 30 percent of adjusted taxable income, and a minimum tax on certain foreign earnings in excess of 10 percent of the foreign subsidiaries tangible assets (i.e., global intangible low-taxed income or GILTI). The Company has decided to make a policy election to treat the GILTI tax as a period expense and as such, no U.S. deferred taxes will be calculated on foreign earnings that are expected to generate GILTI income when they reverse in future years.

[0001564590-18-020718:notes:116]
For the quarter and two quarters ended July 2, 2018, other than as noted above, the Company has not made any changes to its previously provisional estimate of the impact U.S. Tax Reform and the Company continues to analyze and model the impact and will record said impact as it becomes more certain. This includes the mandatory repatriation tax and the indefinite criterion assertion on foreign earnings (with respect to repatriation to the U.S.).


## us-gaap:FinancialInstrumentsDisclosureTextBlock

[0001564590-18-020718:notes:117]
(10) Financial Instruments

[0001564590-18-020718:notes:118]
Derivatives

[0001564590-18-020718:notes:119]
Interest Rate Swaps

[0001564590-18-020718:notes:120]
The Company’s business is exposed to interest rate risk resulting from fluctuations in interest rates on certain LIBOR-based variable rate debt. Increases in interest rates would increase interest expenses relating to the outstanding variable rate borrowings and increase the cost of debt. Fluctuations in interest rates can also lead to significant fluctuations in the fair value of the debt obligations.

[0001564590-18-020718:notes:121]
On May 15, 2018, the Company entered into a four-year pay-fixed, receive floating (1-month LIBOR), interest rate swap arrangement with a notional amount of $400,000 for the period beginning June 1, 2018 and ending on June 1, 2022. Under the terms of the interest rate swap, the Company would pay a fixed rate of 2.84% against the first interest payments of a portion of its LIBOR-based debt and would receive floating 1-month LIBOR during the swap period. During the quarter ended July 2, 2018, the Company designated this interest rate swap as a cash flow hedge.

[0001564590-18-020718:notes:122]
At inception, the fair value of the interest rate swap was zero. As of July 2, 2018, the fair value of the interest rate swap was recorded as a liability in the amount of $1,416 and included as a component of other accrued liabilities. The change in the fair value of the interest rate swap is recorded as a component of accumulated other comprehensive income, net of tax, in the Company’s consolidated condensed balance sheet. No ineffectiveness was recognized for the quarter ended July 2, 2018. During the quarter ended July 2, 2018, the interest rate swap increased interest expense by $303.

[0001564590-18-020718:notes:123]
Foreign Exchange Contracts

[0001564590-18-020718:notes:124]
The Company enters into foreign currency forward contracts to mitigate the impact of changes in foreign currency exchange rates and to reduce the volatility of purchases and other obligations generated in currencies other than the functional currencies. The Company’s foreign subsidiaries may at times purchase forward exchange contracts to manage their foreign currency risks in relation to certain purchases of machinery denominated in foreign currencies other than the Company’s functional currency. The notional amount of the foreign exchange contracts at July 2, 2018 and January 1, 2018 was approximately $6,482 and $10,927, respectively. The Company has designated certain of these foreign exchange contracts as cash flow hedges.

[0001564590-18-020718:notes:125]
The fair values of derivative instruments in the consolidated condensed balance sheets are as follows:

[0001564590-18-020718:notes:126]
|  |  |  |  | Asset/(Liability) Fair Value |  |
|  |  | Balance Sheet Location |  | July 2, 2018 |  |  | January 1, 2018 |  |
|  |  |  |  | (In thousands) |  |
| Cash flow derivative instruments designated as hedges: |  |  |  |  |  |  |  |  |
| Interest rate swap |  | Other accrued expenses |  | $ | 1,416 |  |  |  |  |  |
| Foreign exchange contracts |  | Other accrued expenses |  |  | 18 |  |  | $ | 6 |  |
| Cash flow derivative instruments not designated as hedges: |  |  |  |  |  |  |  |  |
| Foreign exchange contracts |  | Prepaid expenses and other current assets |  |  |  |  |  |  | 107 |  |
| Foreign exchange contracts |  | Other accrued expenses |  |  | 131 |  |  |  | 132 |  |
| Foreign exchange contracts |  | Other long-term liabilities |  |  |  |  |  |  | 13 |  |

[0001564590-18-020718:notes:127]
The following table provides information about the amounts recorded in accumulated other comprehensive income related to derivatives designated as cash flow hedges, as well as the amounts recorded in each caption in the consolidated condensed statements of operations when derivative amounts are reclassified out of accumulated other comprehensive income:

[0001564590-18-020718:notes:128]
|  |  |  | Quarter ended July 2, 2018 |  |  | Quarter ended July 3, 2017 |  |
|  |  |  | Effective Portion |  |  | Ineffective Portion |  |  | Effective Portion |  |  | Ineffective Portion |  |
|  |  | Financial Statement Caption | Gain/(Loss) Recognized in Other Comprehensive Income |  |  | Gain/(Loss) Reclassified into Income |  |  | Gain/(Loss) Reclassified into Income |  |  | Gain/(Loss) Recognized in Other Comprehensive Income |  |  | Gain/(Loss) Reclassified into Income |  |  | Gain/(Loss) Reclassified into Income |  |
|  |  |  | (In thousands) |  |
| Cash flow hedge: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Interest rate swap |  | Interest expense | $ | (1,719 | ) |  | $ | (303 | ) |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |
| Foreign currency forward |  | Depreciation expense |  | (20 | ) |  |  | (39 | ) |  |  | — |  |  |  | 96 |  |  |  | (43 | ) |  |  | — |  |
|  |  |  | Two Quarters ended July 2, 2018 |  |  | Two Quarters ended July 3, 2017 |  |
|  |  |  | Effective Portion |  |  | Ineffective Portion |  |  | Effective Portion |  |  | Ineffective Portion |  |
|  |  | Financial Statement Caption | Gain/(Loss) Recognized in Other Comprehensive Income |  |  | Gain/(Loss) Reclassified into Income |  |  | Gain/(Loss) Reclassified into Income |  |  | Gain/(Loss) Recognized in Other Comprehensive Income |  |  | Gain/(Loss) Reclassified into Income |  |  | Gain/(Loss) Reclassified into Income |  |
|  |  |  | (In thousands) |  |
| Cash flow hedge: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Interest rate swap |  | Interest expense | $ | (1,719 | ) |  | $ | (303 | ) |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |
| Foreign currency forward |  | Depreciation expense |  | (26 | ) |  |  | (80 | ) |  |  | — |  |  |  | 164 |  |  |  | (87 | ) |  |  | — |  |

[0001564590-18-020718:notes:129]
The following table provides a summary of the activity associated with the designated cash flow hedges reflected in accumulated other comprehensive income for the two quarters ended July 2, 2018 and July 3, 2017:

[0001564590-18-020718:notes:130]
|  |  | Two Quarters Ended |  |
|  |  | July 2, |  |  | July 3, |  |
|  |  | 2018 |  |  | 2017 |  |
|  |  | (In thousands) |  |
| Beginning balance, net of tax |  | $ | (742 | ) |  | $ | (1,180 | ) |
| Changes in fair value gain (loss), net of tax |  |  | (1,745 | ) |  |  | 164 |  |
| Reclassification to earnings |  |  | 383 |  |  |  | 87 |  |
| Ending balance, net of tax |  | $ | (2,104 | ) |  | $ | (929 | ) |

[0001564590-18-020718:notes:131]
The Company expects that approximately $1,571 of the accumulated other comprehensive income (loss) will be reclassified into the statement of operations, net of tax, in the next 12 months.

[0001564590-18-020718:notes:132]
The net gain (loss) recognized in other, net in the consolidated condensed statements of operations on derivative instruments not designated as hedges is as follows:

[0001564590-18-020718:notes:133]
|  |  | Quarter Ended |  |  | Two Quarters Ended |  |
|  |  | July 2, |  |  | July 3, |  |  | July 2, |  |  | July 3, |  |
|  |  | 2018 |  |  | 2017 |  |  | 2018 |  |  | 2017 |  |
|  |  | (In thousands) |  |
| Derivative instruments not designated as hedges: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Foreign exchange contracts |  | $ | (324 | ) |  | $ | (176 | ) |  | $ | 103 |  |  | $ | (29 | ) |


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0001564590-18-020718:notes:134]
(11) Accumulated Other Comprehensive Income

[0001564590-18-020718:notes:135]
The following provides a summary of the components of accumulated other comprehensive income as of July 2, 2018 and January 1, 2018:

[0001564590-18-020718:notes:136]
|  |  | Foreign Currency Translation |  |  | Gains (Losses) on Cash Flow Hedges |  |  | Total |  |
|  |  | (In thousands) |  |
| Ending balance at January 1, 2018 |  | $ | 4,145 |  |  | $ | (742 | ) |  | $ | 3,403 |  |
| Other comprehensive income (loss) before reclassifications |  |  | (1,079 | ) |  |  | (1,745 | ) |  |  | (2,824 | ) |
| Amounts reclassified from accumulated other comprehensive income |  |  | — |  |  |  | 383 |  |  |  | 383 |  |
| Other comprehensive income (loss) |  |  | (1,079 | ) |  |  | (1,362 | ) |  |  | (2,441 | ) |
| Ending balance at July 2, 2018 |  | $ | 3,066 |  |  | $ | (2,104 | ) |  | $ | 962 |  |


## us-gaap:ConcentrationRiskDisclosureTextBlock

[0001564590-18-020718:notes:137]
(12) Significant Customers and Concentration of Credit Risk

[0001564590-18-020718:notes:138]
[same as prior period, unchanged from 0001564590-18-011836:notes:82]

[0001564590-18-020718:notes:139]
[same as prior period, unchanged from 0001564590-18-011836:notes:83]

[0001564590-18-020718:notes:140]
For the two quarters ended July 2, 2018, one customer accounted for approximately 12% of the Company’s net sales. There were no customers that accounted for 10% or more of net sales for the quarter ended July 2, 2018.  For both the quarter and two quarters ended July 3, 2017, one customer accounted for approximately 16% of the Company’s net sales. There were no other customers that accounted for 10% or more of net sales for the quarter and two quarters ended July 2, 2018 and July 3, 2017.


## us-gaap:FairValueDisclosuresTextBlock

[0001564590-18-020718:notes:141]
(13) Fair Value Measures

[0001564590-18-020718:notes:142]
[same as prior period, unchanged from 0001564590-18-011836:notes:86]

[0001564590-18-020718:notes:143]
The carrying amount and estimated fair value of the Company’s financial instruments at July 2, 2018 and January 1, 2018 were as follows:

[0001564590-18-020718:notes:144]
|  |  | July 2, 2018 |  |  | January 1, 2018 |  |
|  |  | Carrying Amount |  |  | Fair Value |  |  | Carrying Amount |  |  | Fair Value |  |
|  |  | (In thousands) |  |
| Derivative assets, current |  | $ | — |  |  | $ | — |  |  | $ | 107 |  |  | $ | 107 |  |
| Derivative liabilities, current |  |  | 1,565 |  |  |  | 1,565 |  |  |  | 258 |  |  |  | 258 |  |
| Term Loan due September 2024 |  |  | 932,805 |  |  |  | 943,515 |  |  |  | 344,646 |  |  |  | 346,943 |  |
| Senior Notes due October 2025 |  |  | 368,568 |  |  |  | 366,829 |  |  |  | 368,218 |  |  |  | 384,769 |  |
| Convertible Senior Notes |  |  | 223,225 |  |  |  | 474,547 |  |  |  | 218,274 |  |  |  | 429,199 |  |
| ABL Revolving Loans |  |  | 70,000 |  |  |  | 70,000 |  |  |  | 47,000 |  |  |  | 47,000 |  |
| Capital lease |  |  | 1,556 |  |  |  | 1,556 |  |  |  | 1,919 |  |  |  | 1,919 |  |

[0001564590-18-020718:notes:145]
The fair value of the derivative instruments was determined using pricing models developed based on the LIBOR swap rate, foreign currency exchange rates, and other observable market data, including quoted market prices, as appropriate using Level 2 inputs. The values were adjusted to reflect nonperformance risk of both the counterparty and the Company, as necessary.

[0001564590-18-020718:notes:146]
The fair value of the long-term debt was estimated based on quoted market prices or discounting the debt over its life using current market rates for similar debt as of July 2, 2018 and January 1, 2018, which are considered Level 1 and Level 2 inputs.

[0001564590-18-020718:notes:147]
[same as prior period, unchanged from 0001564590-18-011836:notes:90]

[0001564590-18-020718:notes:148]
As of July 2, 2018 and January 1, 2018, the Company’s other financial instruments also included cash and cash equivalents, accounts receivable, and accounts payable. Due to short-term maturities, the carrying amount of these instruments approximates fair value. The Company’s cash and cash equivalents at July 2, 2018 consisted of $64,628 held in the U.S., with the remaining $139,472 held by foreign subsidiaries.

[0001564590-18-020718:notes:149]
The majority of the Company’s non-financial assets and liabilities, which include goodwill, intangible assets, inventories, and property, plant and equipment, are not required to be carried at fair value on a recurring basis. However, if certain triggering events occur (or are tested at least annually in the case of goodwill) such that a non-financial instrument is required to be evaluated for impairment, based upon a comparison of the non-financial instrument’s fair value to its carrying value, an impairment is recorded to reduce the carrying value to the fair value, if the carrying value exceeds the fair value. See Note 3 for discussion of the fair value measurement of assets acquired and liabilities assumed in the Anaren acquisition.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001564590-18-020718:notes:150]
(14) Commitments and Contingencies

[0001564590-18-020718:notes:151]
Legal Matters

[0001564590-18-020718:notes:152]
The Company is subject to various legal matters, which it considers normal for its business activities. While the Company currently believes that the amount of any reasonably possible loss for known matters would not be material to the Company’s financial condition, the outcome of these actions is inherently difficult to predict. In the event of an adverse outcome, the ultimate potential loss could have a material adverse effect on the Company’s financial condition or results of operations in a particular period. The Company has accrued amounts for its loss contingencies which are probable and estimable as of July 2, 2018 and January 1, 2018. However, these amounts are not material to the consolidated condensed financial statements of the Company.

[0001564590-18-020718:notes:153]
Environmental Matters

[0001564590-18-020718:notes:154]
The process to manufacture PCBs requires adherence to city, county, state, federal regulations as well as foreign environmental regulations regarding the storage, use, handling and disposal of chemicals, solid wastes and other hazardous materials, as well as compliance with air quality standards and chemical use reporting. The Company believes that its facilities in the United States and Canada comply in all material respects with applicable environmental laws and regulations. In China, governmental authorities have adopted new rules and regulations governing environmental issues. An update to the Chinese environmental waste water law was issued in late 2012, allowing for an interim period in which plants subject to such law may install equipment that meets the new regulatory regime. Some of the Company’s plants in China are not yet in full compliance with the updated environmental regulations. The Company has established and enacted an investment plan related to the efforts to come into full compliance with the new regulations. The 2018 capital expenditure costs expected for these plans are included in the Company’s capital expenditure projections.


## us-gaap:EarningsPerShareTextBlock

[0001564590-18-020718:notes:155]
(15) Earnings Per Share

[0001564590-18-020718:notes:156]
The following is a reconciliation of the numerator and denominator used to calculate basic earnings per share and diluted earnings per share for the quarter and two quarters ended July 2, 2018 and July 3, 2017:

[0001564590-18-020718:notes:157]
|  |  | Quarter Ended |  |  | Two Quarters Ended |  |
|  |  | July 2, 2018 |  |  | July 3, 2017 |  |  | July 2, 2018 |  |  | July 3, 2017 |  |
|  |  | (In thousands, except per share amounts) |  |
| Basic earnings: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic earnings |  | $ | 84,004 |  |  | $ | 20,591 |  |  | $ | 94,101 |  |  | $ | 53,550 |  |
| Diluted earnings: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Net income attributable to TTM Technologies, Inc. stockholders |  | $ | 84,004 |  |  | $ | 20,591 |  |  | $ | 94,101 |  |  | $ | 53,550 |  |
| Interest expense from convertible senior notes, net of tax |  |  | 3,587 |  |  |  | 3,432 |  |  |  | 7,135 |  |  |  | 6,826 |  |
| Diluted earnings |  | $ | 87,591 |  |  | $ | 24,023 |  |  | $ | 101,236 |  |  | $ | 60,376 |  |
| Basic weighted average shares |  |  | 103,553 |  |  |  | 101,756 |  |  |  | 103,030 |  |  |  | 101,344 |  |
| Dilutive effect of performance-based restricted stock units, restricted stock units and stock options |  |  | 1,376 |  |  |  | 1,604 |  |  |  | 1,603 |  |  |  | 1,735 |  |
| Dilutive effect of outstanding warrants |  |  | 3,854 |  |  |  | 3,924 |  |  |  | 3,517 |  |  |  | 3,054 |  |
| Dilutive effect of assumed conversion of convertible senior notes outstanding |  |  | 25,938 |  |  |  | 25,940 |  |  |  | 25,938 |  |  |  | 25,940 |  |
| Diluted shares |  |  | 134,721 |  |  |  | 133,224 |  |  |  | 134,088 |  |  |  | 132,073 |  |
| Earnings per share attributable to TTM Technologies, Inc. stockholders: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  | $ | 0.81 |  |  |  | 0.20 |  |  | $ | 0.91 |  |  | $ | 0.53 |  |
| Diluted |  | $ | 0.65 |  |  |  | 0.18 |  |  | $ | 0.75 |  |  | $ | 0.46 |  |

[0001564590-18-020718:notes:158]
Performance-based restricted stock units (PRUs), restricted stock units (RSUs) and stock options to purchase 45 and 15 shares of common stock for the quarter ended July 2, 2018 and July 3, 2017, respectively, and 488 and 97 for the two quarters ended July 2, 2018 and July 3, 2017, respectively, were not considered in calculating diluted earnings per share because the options’ exercise prices or the total expected proceeds under the treasury stock method for PRUs, RSUs or stock options was greater than the average market price of common shares during the applicable quarter and two quarters and, therefore, the effect would be anti-dilutive.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001564590-18-020718:notes:159]
(16) Stock-Based Compensation

[0001564590-18-020718:notes:160]
[same as prior period, unchanged from 0001564590-18-011836:notes:104]

[0001564590-18-020718:notes:161]
|  |  | Quarter Ended |  |  | Two Quarters Ended |  |
|  |  | July 2, |  |  | July 3, |  |  | July 2, |  |  | July 3, |  |
|  |  | 2018 |  |  | 2017 |  |  | 2018 |  |  | 2017 |  |
|  |  | (In thousands) |  |  | (In thousands) |  |
| Cost of goods sold |  | $ | 829 |  |  | $ | 639 |  |  | $ | 1,358 |  |  | $ | 1,033 |  |
| Selling and marketing |  |  | 545 |  |  |  | 386 |  |  |  | 919 |  |  |  | 639 |  |
| General and administrative |  |  | 4,493 |  |  |  | 3,975 |  |  |  | 7,212 |  |  |  | 6,956 |  |
| Stock-based compensation expense recognized |  | $ | 5,867 |  |  | $ | 5,000 |  |  | $ | 9,489 |  |  | $ | 8,628 |  |

[0001564590-18-020718:notes:162]
[same as prior period, unchanged from 0001564590-18-011836:notes:106]

[0001564590-18-020718:notes:163]
[same as prior period, unchanged from 0001564590-18-011836:notes:107]

[0001564590-18-020718:notes:164]
The Company records stock-based compensation expense for PRU awards granted based on management’s periodic assessment of the annual financial performance goals to be achieved. For the two quarters ended July 2, 2018, management determined that vesting of the PRU awards was probable. PRUs activity for the two quarters ended July 2, 2018 was as follows:

[0001564590-18-020718:notes:165]
|  |  | Shares |  |  | Weighted Average Fair Value |  |
|  |  | (In thousands) |  |  |  |  |  |
| Outstanding target shares at January 1, 2018 |  |  | 409 |  |  | $ | 16.39 |  |
| Granted |  |  | 334 |  |  |  | 19.59 |  |
| Change in units due to annual performance achievement |  |  | (22 | ) |  |  | 19.59 |  |
| Outstanding target shares at July 2, 2018 |  |  | 721 |  |  | $ | 17.77 |  |

[0001564590-18-020718:notes:166]
[same as prior period, unchanged from 0001564590-18-011836:notes:114]

[0001564590-18-020718:notes:167]
The Company granted 195 and 61 RSUs during the quarters ended July 2, 2018 and July 3, 2017, respectively, and 1,023 and 1,007 RSUs during the two quarters ended July 2, 2018 and July 3, 2017, respectively. The RSUs granted have a weighted-average fair value per unit of $16.06 and $16.52 for the quarters ended July 2, 2018 and July 3, 2017, respectively, and $15.44 and $15.82 for the two quarters ended July 2, 2018 and July 3, 2017, respectively. The fair value for RSUs granted is based on the closing share price of the Company’s common stock on the date of grant.

[0001564590-18-020718:notes:168]
[same as prior period, unchanged from 0001564590-18-011836:notes:116]

[0001564590-18-020718:notes:169]
During the quarter and two quarters ended July 2, 2018, The Company granted 20 stock option awards to a newly appointed member of the board which were estimated to have a fair value per share of $8.92. The fair value calculation is based on stock options granted during the period using the Black-Scholes option-pricing model on the date of grant. For the quarter and two quarters ended July 2, 2018, the fair value was determined using 3.0% as the risk-free interest rate, 43.0% as the expected volatility, 8.5 years as the expected term and no dividend yield. The Company did not grant stock option awards during the quarter and two quarters ended July 3, 2017.

[0001564590-18-020718:notes:170]
[same as prior period, unchanged from 0001564590-18-011836:notes:118]

[0001564590-18-020718:notes:171]
The following is a summary of total unrecognized compensation costs as of July 2, 2018:

[0001564590-18-020718:notes:172]
|  |  | Unrecognized Stock- Based Compensation Cost |  |  | Remaining Weighted Average Recognition Period |  |
|  |  | (In thousands) |  |  | (In years) |  |
| RSU awards |  | $ | 24,888 |  |  |  | 1.5 |  |
| PRU awards |  |  | 6,859 |  |  |  | 1.2 |  |
| Stock options |  |  | 250 |  |  |  | 2.2 |  |
|  |  | $ | 31,997 |  |  |  |  |  |


## us-gaap:SegmentReportingDisclosureTextBlock

[0001564590-18-020718:notes:173]
(17) Segment Information

[0001564590-18-020718:notes:174]
The reportable segments reported below are the Company’s segments for which separate financial information is available and upon which operating results are evaluated by the chief operating decision maker to assess performance and to allocate resources. The Company has three reportable segments: PCB, E-M Solutions and Anaren. However, beginning in the third quarter of 2018, the Company will no longer report Anaren as a reportable segment as the Company will integrate it into the PCB reportable segment. The PCB reportable segment is comprised of multiple operating segments. Factors considered to determine whether operating segments can be aggregated into reportable segments included similarity regarding economic characteristics, products, production processes, type or classes of customers, distribution methods, and regulatory environments.

[0001564590-18-020718:notes:175]
[same as prior period, unchanged from 0001564590-18-011836:notes:123]

[0001564590-18-020718:notes:176]
The inter-segment sales for the quarter and two quarters ended July 2, 2018 and July 3, 2017, are sales primarily from the PCB to the E-M Solutions reportable segment.

[0001564590-18-020718:notes:177]
|  |  | Quarter Ended |  |  | Two Quarters Ended |  |
|  |  | July 2, 2018 |  |  | July 3, 2017 |  |  | July 2, 2018 |  |  | July 3, 2017 |  |
|  |  | (In thousands) |  |  | (In thousands) |  |
| Net Sales: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| PCB |  | $ | 596,461 |  |  | $ | 576,566 |  |  | $ | 1,215,790 |  |  | $ | 1,163,261 |  |
| Anaren (1) |  |  | 62,011 |  |  |  | — |  |  |  | 62,011 |  |  |  | — |  |
| E-M Solutions |  |  | 61,842 |  |  |  | 52,898 |  |  |  | 108,993 |  |  |  | 94,567 |  |
| Total sales |  |  | 720,314 |  |  |  | 629,464 |  |  |  | 1,386,794 |  |  |  | 1,257,828 |  |
| Inter-segment sales |  |  | (3,427 | ) |  |  | (2,282 | ) |  |  | (6,325 | ) |  |  | (5,399 | ) |
| Total net sales |  | $ | 716,887 |  |  | $ | 627,182 |  |  | $ | 1,380,469 |  |  | $ | 1,252,429 |  |
| Operating Segment Income (Loss): |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| PCB |  | $ | 68,028 |  |  | $ | 69,435 |  |  | $ | 131,492 |  |  | $ | 151,691 |  |
| Anaren (1) |  |  | 12,936 |  |  |  | — |  |  |  | 12,936 |  |  |  | — |  |
| E-M Solutions |  |  | 2,496 |  |  |  | 2,689 |  |  |  | 2,536 |  |  |  | 1,047 |  |
| Corporate |  |  | (32,237 | ) |  |  | (21,158 | ) |  |  | (59,879 | ) |  |  | (43,290 | ) |
| Total operating segment income |  |  | 51,223 |  |  |  | 50,966 |  |  |  | 87,085 |  |  |  | 109,448 |  |
| Amortization of definite-lived intangibles |  |  | (19,489 | ) |  |  | (5,910 | ) |  |  | (25,350 | ) |  |  | (11,822 | ) |
| Total operating income |  |  | 31,734 |  |  |  | 45,056 |  |  |  | 61,735 |  |  |  | 97,626 |  |
| Total other expense |  |  | (14,275 | ) |  |  | (18,747 | ) |  |  | (29,129 | ) |  |  | (34,053 | ) |
| Income before income taxes |  | $ | 17,459 |  |  | $ | 26,309 |  |  | $ | 32,606 |  |  | $ | 63,573 |  |

[0001564590-18-020718:notes:178]
| (1) | The quarter and two quarters ended July 3, 2017 does not include Anaren, as the acquisition occurred on April 18, 2018. |

[0001564590-18-020718:notes:179]
The Corporate category includes operating expenses that are not included in the segment operating performance measures. Corporate consists primarily of corporate governance functions such as finance, accounting, corporate sales, information technology, facilities, corporate operations and human resources personnel. Bank fees and legal, accounting, and other professional service costs associated with the acquisition of Anaren in the amount of $6,852 and $10,825 for the quarter and two quarters ended July 2, 2018, respectively, are included in Corporate. See Note 3 Acquisition of Anaren Inc.


## us-gaap:RelatedPartyTransactionsDisclosureTextBlock

[0001564590-18-020718:notes:180]
(18) Related Party Transactions

[0001564590-18-020718:notes:181]
In the normal course of business, the Company’s foreign subsidiaries purchase laminate and prepreg from related parties in which a member of the Board of Directors of the Company holds an equity interest. The Company’s foreign subsidiaries purchased laminate and prepreg from these related parties in the amount of $12,550 and $12,121 for the quarters ended July 2, 2018 and July 3, 2017, respectively, and $38,257 and $25,611 for the two quarters ended July 2, 2018 and July 3, 2017, respectively.

[0001564590-18-020718:notes:182]
As of July 2, 2018 and January 1, 2018, the Company’s consolidated condensed balance sheets included $15,256 and $14,452, respectively, in accounts payable due to related parties primarily for purchases of laminate and prepreg and such balances are included as a component of accounts payable on the consolidated condensed balance sheets.
