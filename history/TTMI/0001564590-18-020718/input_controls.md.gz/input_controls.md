# TTMI 10-Q controls and the auditor's report


## item_4_controls

[0001564590-18-020718:item_4_controls:1]
Item 4. Controls and Procedures

[0001564590-18-020718:item_4_controls:2]
Evaluation of Disclosure Controls and Procedures

[0001564590-18-020718:item_4_controls:3]
Our management, under the supervision and with the participation of our Chief Executive Officer (CEO) and Chief Financial Officer (CFO), has evaluated the effectiveness of the design and operation of our disclosure controls and procedures (as defined in Rules 13a-15(e) and 15d-15(e) under the Exchange Act of 1934, as amended (the Exchange Act)) as of the end of the period covered by this report. Based on this evaluation, our CEO and CFO have concluded that, as of July 2, 2018, such disclosure controls and procedures were effective to provide reasonable assurance that information we are required to disclose in reports that we file or submit under the Exchange Act is (i) recorded, processed, summarized and reported within the time periods specified in the SEC’s rules and forms and (ii) accumulated and communicated to our management, including our CEO and CFO, as appropriate to allow timely decisions regarding required disclosures.

[0001564590-18-020718:item_4_controls:4]
In designing and evaluating our disclosure controls and procedures, our management recognized that any controls and procedures, no matter how well designed and operated, can provide only reasonable assurance of achieving their desired control objectives, and our management is required to apply its judgment in evaluating the cost-benefit relationship of possible controls and procedures.

[0001564590-18-020718:item_4_controls:5]
Changes in Internal Control Over Financial Reporting

[0001564590-18-020718:item_4_controls:6]
As a result of the acquisition of Anaren on April 18, 2018, our management is in the process of reviewing and evaluating the design and operating effectiveness of its internal control over financial reporting relating to Anaren. Certain changes have been made and will continue to be made to our internal controls until management has completed its evaluation and integrated Anaren’s information and accounting systems and processes. In reliance on interpretive guidance issued by the SEC staff permitting a company to exclude an acquired business from management’s assessment of the effectiveness of internal control over financial reporting for one year following the date that the acquisition is completed, we have elected to exclude disclosure of changes in internal control over financial reporting related to Anaren from this Quarterly Report on Form 10-Q.

[0001564590-18-020718:item_4_controls:7]
35

[0001564590-18-020718:item_4_controls:8]
There have been no other changes in our internal control over financial reporting (as defined in Rules 13a-15(f) and 15d-15(f) under the Exchange Act) during the quarter and two quarters ended July 2, 2018 that have materially affected, or are reasonably likely to materially affect, our internal control over financial reporting.
