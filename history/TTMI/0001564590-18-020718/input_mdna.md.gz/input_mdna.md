# TTMI MD&A — 0001564590-18-020718


## mdna

[0001564590-18-020718:mdna:1]
[same as prior period, unchanged from 0001564590-18-011836:mdna:1]

[0001564590-18-020718:mdna:2]
[same as prior period, unchanged from 0001564590-18-011836:mdna:2]

[0001564590-18-020718:mdna:3]
We are a leading global printed circuit board (PCB) manufacturer, focusing on quick-turn and volume production of technologically complex PCBs and electro-mechanical solutions (E-M Solutions), as well as a global designer and manufacturer of high-frequency radio frequency (RF) and microwave components and assemblies. We focus on providing time-to-market and volume production of advanced technology products and offer a one-stop manufacturing solution to our customers from engineering support to prototype development through final mass production. This one-stop manufacturing solution allows us to align technology development with the diverse needs of our customers and to enable them to reduce the time required to develop new products and bring them to market. We serve a diversified customer base consisting of approximately 2,200 customers in various markets throughout the world, including aerospace and defense, automotive components, smartphones and touchscreen tablets, high-end computing, and medical, industrial and instrumentation related products as well as networking/communications infrastructure products. Our customers include both original equipment manufacturers (OEMs) and electronic manufacturing services (EMS) providers.

[0001564590-18-020718:mdna:4]
[same as prior period, unchanged from 0001564590-18-011836:mdna:4]

[0001564590-18-020718:mdna:5]
On April 18, 2018, we completed our acquisition to purchase all of the issued and outstanding common stock of Anaren Holding Corp. for total consideration of $787.9 million subject to customary working capital and certain other adjustments. Other than the equity interests of Anaren, Inc. (Anaren), Anaren Holding Corp. has no material assets or liabilities and has no material independent operations. Anaren is a leading provider of mission-critical RF solutions, microelectronics, and microwave components and assemblies for the wireless infrastructure and aerospace and defense electronics markets.

[0001564590-18-020718:mdna:6]
Additionally, we closed our $600.0 million commitment for incremental loans concurrent with the completion of our acquisition of Anaren. We used the proceeds of the incremental loans, along with cash on hand to fund the purchase price of the acquisition and to pay related fees and expenses.

[0001564590-18-020718:mdna:7]
[same as prior period, unchanged from 0001564590-18-011836:mdna:7]

[0001564590-18-020718:mdna:8]
While our customers include both OEMs and EMS providers, we measure customers based on OEM companies, as they are the ultimate end customers. Sales to our 10 largest customers accounted for 43% of our net sales for both the quarter and two quarters ended July 2, 2018. Sales to our 10 largest customers accounted for 45% of our net sales for both the quarter and two quarters ended July 3, 2017. We sell to OEMs both directly and indirectly through EMS providers.

[0001564590-18-020718:mdna:9]
[same as prior period, unchanged from 0001564590-18-011836:mdna:9]

[0001564590-18-020718:mdna:10]
|  |  | Quarter Ended |  |  |  | Two Quarters Ended |  |  |
| End Markets(1)(2) |  | July 2, 2018 |  |  |  | July 3, 2017 |  |  |  | July 2, 2018 |  |  |  | July 3, 2017 |  |  |
| Aerospace and Defense |  |  | 24 |  | % |  |  | 17 |  | % |  |  | 21 |  | % |  |  | 16 |  | % |
| Automotive |  |  | 19 |  |  |  |  | 20 |  |  |  |  | 20 |  |  |  |  | 20 |  |  |
| Cellular Phone(2) |  |  | 8 |  |  |  |  | 13 |  |  |  |  | 12 |  |  |  |  | 13 |  |  |
| Computing/Storage/Peripherals(2) |  |  | 15 |  |  |  |  | 14 |  |  |  |  | 14 |  |  |  |  | 15 |  |  |
| Medical/Industrial/Instrumentation |  |  | 14 |  |  |  |  | 15 |  |  |  |  | 14 |  |  |  |  | 15 |  |  |
| Networking/Communications |  |  | 17 |  |  |  |  | 20 |  |  |  |  | 17 |  |  |  |  | 20 |  |  |
| Other(3) |  |  | 3 |  |  |  |  | 1 |  |  |  |  | 2 |  |  |  |  | 1 |  |  |
| Total |  |  | 100 |  | % |  |  | 100 |  | % |  |  | 100 |  | % |  |  | 100 |  | % |

[0001564590-18-020718:mdna:11]
[same as prior period, unchanged from 0001564590-18-011836:mdna:11]

[0001564590-18-020718:mdna:12]
[same as prior period, unchanged from 0001564590-18-011836:mdna:12]

[0001564590-18-020718:mdna:13]
| (3) | Revenue recognized progressively over time based on the extent of progress towards completion of the performance obligation, which has not yet been shipped, is included in the Other end market along with consumer devices such as wearables, portable video devices and personal headphones. |

[0001564590-18-020718:mdna:14]
We derive revenues primarily from the sale of PCBs, custom electronic assemblies using customer-supplied engineering and design plans, and from design, development, and manufacture of components, assemblies, and subsystems which receive, process, and transmit microwave and RF signals. Most orders for products generally correspond to the production schedules of our customers and are supported with firm purchase orders. Most of our customers have continuous transfer of control of the work in progress and finished goods throughout the PCB manufacturing process, as PCBs are built to customer specifications and do not have an alternative use. The customer typically controls the work in progress and finished goods as evidenced either by contractual termination clauses or by our right to payment for work performed to date, plus a reasonable profit. As a result, and in light of our adoption of the new “over time” revenue standard as further discussed below in the “CRITICAL ACCOUNTING POLICIES AND ESTIMATES,” beginning in the first quarter of 2018, we recognized revenue progressively over time based on the extent of progress towards completion of the performance obligation rather than upon shipment as we had in the past.

[0001564590-18-020718:mdna:15]
[same as prior period, unchanged from 0001564590-18-011836:mdna:16]

[0001564590-18-020718:mdna:16]
Additionally, we have certain long-term contracts related to its manufacture of components, assemblies, and subsystems. These long-term contracts, many of which provide for periodic payments, are recognized over time under the percentage-of completion method. Estimated manufacturing cost-at-completion for these contracts are reviewed on a periodic basis, and adjustments are made periodically to the estimated cost-at-completion, based on actual costs incurred, progress made, and estimates of costs required to complete the contractual requirements. When the estimated manufacturing cost-at-completion exceeds the contract value, the contract is written down to its net realizable value and the loss resulting from the cost overruns are immediately recognized.

[0001564590-18-020718:mdna:17]
Finally, we manufacture components, assemblies, and subsystems for which we recognize revenue at a point in time as the customer does not simultaneously receive or consume the benefits provided by our performance and the asset being manufactured has alternative uses to us.

[0001564590-18-020718:mdna:18]
Net sales consist of gross sales less an allowance for returns, which typically have been less than 2% of gross sales. We provide our customers a limited right of return for defective PCBs, assemblies, components and subsystems. We record an estimate for sales returns and allowances at the time of sale based on historical results.

[0001564590-18-020718:mdna:19]
Cost of goods sold consists of materials, labor, outside services, and overhead expenses incurred in the manufacture and testing of our products. Shipping and handling fees and related freight costs and supplies associated with shipping products are also included as a component of cost of goods sold. Many factors affect our gross margin, including capacity utilization, product mix, production volume, and yield. While we have entered into supply assurance agreements with some of our key suppliers to maintain the continuity of supply of some of the key materials we use, we generally do not participate in any significant long-term contracts with suppliers, and we believe there are a number of potential suppliers for the raw materials we use.

[0001564590-18-020718:mdna:20]
[same as prior period, unchanged from 0001564590-18-011836:mdna:19]

[0001564590-18-020718:mdna:21]
General and administrative costs primarily include the salaries for executive, finance, accounting, information technology, facilities, research and development, and human resources personnel, as well as expenses for accounting and legal assistance, incentive compensation expense, and gains or losses on the sale or disposal of property, plant and equipment.

[0001564590-18-020718:mdna:22]
[same as prior period, unchanged from 0001564590-18-011836:mdna:21]

[0001564590-18-020718:mdna:23]
[same as prior period, unchanged from 0001564590-18-011836:mdna:22]

[0001564590-18-020718:mdna:24]
See Item 7, Management’s Discussion and Analysis of Financial Condition and Results of Operations, in our Annual Report on Form 10-K for the fiscal year ended January 1, 2018 for further discussion of critical accounting policies and estimates. There were no material changes to our critical accounting policies and estimates since January 1, 2018, except for the adoption of Accounting Standards Update (ASU) 2014-09, Revenue from Contracts with Customers (new revenue standard) on January 2, 2018.

[0001564590-18-020718:mdna:25]
The new revenue standard replaces most existing revenue recognition guidance in U.S. GAAP, including industry specific requirements, and provides companies with a single revenue recognition model for recognizing revenue of contracts with customers. The core principle of the new revenue standard is that a company should recognize revenue to depict the transfer of promised goods or services to customers in an amount that reflects the consideration to which the company expects to be entitled in exchange for those goods or services.  We assessed the new guidance and adopted the new revenue standard on January 2, 2018, which resulted in a change to the timing of revenue recognition for certain of our revenue streams from “point in time” upon physical delivery to an “over time” model.

[0001564590-18-020718:mdna:26]
[same as prior period, unchanged from 0001564590-18-011836:mdna:25]

[0001564590-18-020718:mdna:27]
The quarter and two quarters ended July 3, 2017 do not include the results of operations from our acquisition of Anaren, as the acquisition occurred on April 18, 2018. The following table sets forth the relationship of various items to net sales in our consolidated condensed statements of operations:

[0001564590-18-020718:mdna:28]
|  |  | Quarter Ended |  |  |  | Two Quarters Ended |  |  |
|  |  | July 2, 2018 |  |  |  | July 3, 2017 |  |  |  | July 2, 2018 |  |  |  | July 3, 2017 |  |  |
| Net sales |  |  | 100.0 |  | % |  |  | 100.0 |  | % |  |  | 100.0 |  | % |  |  | 100.0 |  | % |
| Cost of goods sold |  |  | 83.8 |  |  |  |  | 84.7 |  |  |  |  | 85.2 |  |  |  |  | 84.0 |  |  |
| Gross profit |  |  | 16.2 |  |  |  |  | 15.3 |  |  |  |  | 14.8 |  |  |  |  | 16.0 |  |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Selling and marketing |  |  | 2.6 |  |  |  |  | 2.5 |  |  |  |  | 2.6 |  |  |  |  | 2.6 |  |  |
| General and administrative |  |  | 6.5 |  |  |  |  | 4.7 |  |  |  |  | 5.9 |  |  |  |  | 4.7 |  |  |
| Amortization of definite-lived intangibles |  |  | 2.7 |  |  |  |  | 0.9 |  |  |  |  | 1.8 |  |  |  |  | 0.9 |  |  |
| Total operating expenses |  |  | 11.8 |  |  |  |  | 8.1 |  |  |  |  | 10.3 |  |  |  |  | 8.2 |  |  |
| Operating income |  |  | 4.4 |  |  |  |  | 7.2 |  |  |  |  | 4.5 |  |  |  |  | 7.8 |  |  |
| Other income (expense): |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Interest expense |  |  | (2.9 | ) |  |  |  | (2.1 | ) |  |  |  | (2.5 | ) |  |  |  | (2.1 | ) |  |
| Other, net |  |  | 0.9 |  |  |  |  | (0.9 | ) |  |  |  | 0.4 |  |  |  |  | (0.6 | ) |  |
| Total other expense, net |  |  | (2.0 | ) |  |  |  | (3.0 | ) |  |  |  | (2.1 | ) |  |  |  | (2.7 | ) |  |
| Income before income taxes |  |  | 2.4 |  |  |  |  | 4.2 |  |  |  |  | 2.4 |  |  |  |  | 5.1 |  |  |
| Income tax provision |  |  | 9.3 |  |  |  |  | (0.9 | ) |  |  |  | 4.4 |  |  |  |  | (0.8 | ) |  |
| Net income |  |  | 11.7 |  |  |  |  | 3.3 |  |  |  |  | 6.8 |  |  |  |  | 4.3 |  |  |
| Less: Net income attributable to the non- controlling interest |  |  | — |  |  |  |  | — |  |  |  |  | — |  |  |  |  | — |  |  |
| Net income attributable to TTM Technologies, Inc. stockholders |  |  | 11.7 |  | % |  |  | 3.3 |  | % |  |  | 6.8 |  | % |  |  | 4.3 |  | % |

[0001564590-18-020718:mdna:29]
We have three reportable segments: PCB, E-M Solutions and Anaren. We added the Anaren reportable segment following the acquisition of Anaren on April 18, 2018. See Notes to Consolidated Condensed Financial Statements ─ Note 3 Acquisition of Anaren, Inc. However, beginning in the third quarter of 2018, we will no longer report Anaren as a reportable segment as we will integrate them into the PCB reportable segment. The PCB reportable segment is comprised of multiple operating segments. Factors considered in determining whether operating segments can be aggregated into reportable segments included similarity regarding economic characteristics, products, production process, type or class of customers, distribution methods and regulatory environments.

[0001564590-18-020718:mdna:30]
The following table compares net sales by reportable segment for the quarters and two quarters ended July 2, 2018 and July 3, 2017:

[0001564590-18-020718:mdna:31]
|  |  | Quarter Ended |  |  | Two Quarters Ended |  |
|  |  | July 2, 2018 |  |  | July 3, 2017 |  |  | July 2, 2018 |  |  | July 3, 2017 |  |
|  |  | (In thousands) |  |  | (In thousands) |  |
| Net Sales |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| PCB |  | $ | 596,461 |  |  | $ | 576,566 |  |  | $ | 1,215,790 |  |  | $ | 1,163,261 |  |
| Anaren (1) |  |  | 62,011 |  |  |  | — |  |  |  | 62,011 |  |  |  | — |  |
| E-M Solution |  |  | 61,842 |  |  |  | 52,898 |  |  |  | 108,993 |  |  |  | 94,567 |  |
| Total sales |  |  | 720,314 |  |  |  | 629,464 |  |  |  | 1,386,794 |  |  |  | 1,257,828 |  |
| Inter-segment sales |  |  | (3,427 | ) |  |  | (2,282 | ) |  |  | (6,325 | ) |  |  | (5,399 | ) |
| Total net sales |  | $ | 716,887 |  |  | $ | 627,182 |  |  | $ | 1,380,469 |  |  | $ | 1,252,429 |  |

[0001564590-18-020718:mdna:32]
| (1) | The quarter and two quarters ended July 3, 2017 does not include Anaren, as the acquisition occurred on April 18, 2018. |

[0001564590-18-020718:mdna:33]
[same as prior period, unchanged from 0001564590-18-011836:mdna:31]

[0001564590-18-020718:mdna:34]
Total net sales increased $89.7 million, or 14.3%, from $627.2 million for the second quarter of 2017 to $716.9 million for the second quarter of 2018. Net sales for the PCB reportable segment, excluding inter-segment sales, increased $18.7 million, or 3.3%, from $574.3 million for the second quarter of 2017 to $593.0 million for the second quarter of 2018. This increase was primarily due to higher sales in our Computing and Aerospace and Defense end markets, partially offset by a decline in our Cellular Phone and Networking/Communications end markets. Higher sales were the result of an average PCB selling price increase of 7.9%, which was

[0001564590-18-020718:mdna:35]
28

[0001564590-18-020718:mdna:36]
driven mainly by product mix shift, and a 4.6% decrease in PCB shipments as compared to the second quarter of 2017. Net sales for the E-M Solutions reportable segment increased $8.9 million from $52.9 million for the second quarter of 2017 to $61.8 million for the second quarter of 2018. The increase was primarily due to higher demand in our Automotive end market. Anaren contributed $62.0 million of net sales for the second quarter of 2018.

[0001564590-18-020718:mdna:37]
Total net sales increased $128.1 million, or 10.2%, from $1,252.4 million for the first two quarters of 2017 to $1,380.5 million for the first two quarters of 2018. Net sales for the PCB reportable segment, excluding inter-segment sales, increased $51.6 million, or 4.5%, from $1,157.9 million for the first two quarters of 2017 to $1,209.5 million for the first two quarters of 2018. The increase was primarily from higher demand in our Aerospace and Defense and Medical/Industrial/Instrumentation end markets, partially offset by a decline in our Networking/Communications and Cellular Phone end markets. These changes resulted in a 2.8% decrease in PCB shipments as compared to the first two quarters of 2017, and an average PCB selling price increase of 6.2%, which was driven by a product mix shift. Net sales for the E-M Solutions reportable segment increased $14.4 million, or 15.2%, from $94.6 million for the first two quarters of 2017 to $109.0 million for the first two quarters of 2018. The increase was primarily due to higher demand in our Automotive end market. The Anaren acquisition, which was closed in the second quarter, contributed $62.0 million of net sales for the first two quarters of 2018.

[0001564590-18-020718:mdna:38]
[same as prior period, unchanged from 0001564590-18-011836:mdna:35]

[0001564590-18-020718:mdna:39]
Overall gross margin increased from 15.3% for the second quarter of 2017 to 16.2% for the second quarter of 2018. Gross margin for the PCB reportable segment decreased from 16.1% for the second quarter of 2017 to 15.4% for the second quarter of 2018 primarily due to lower capacity utilization at our Cellular Phone focused facilities. Gross margin for the E-M Solutions reportable segment decreased from 10.0% for the second quarter of 2017 to 8.0% for the second quarter of 2018 primarily due to unfavorable product mix. Gross margin for the Anaren reportable segment was 35.4% for the second quarter of 2018 which included a charge of $4.9 million to cost of goods sold associated with inventory resulting from purchase accounting.

[0001564590-18-020718:mdna:40]
Overall gross margin decreased from 16.0% for the first two quarters of 2017 to 14.8% for the first two quarters of 2018. Gross margin for the PCB reportable segment decreased from 17.1% for the first two quarters of 2017 to 14.8% for the first two quarters of 2018, primarily due to decreased volumes at our Cellular Phone and Networking/Communications focused facilities. Gross margin for the E-M Solutions reportable segment increased from 6.8% for the first two quarters of 2017 to 6.9% for the first two quarters of 2018, primarily due to increased volumes. Gross margin for the Anaren reportable segment was 35.4% for the two quarters of 2018 which included a charge of $4.9 million to cost of goods sold associated with inventory resulting from purchase accounting.

[0001564590-18-020718:mdna:41]
Capacity utilization is a key driver for us, particularly in our high volume Asia facilities, as a significant portion of our operating costs are fixed in nature. Capacity utilization for the second quarter of 2017 in our Asia and North America PCB facilities was 83% and 54%, respectively, compared to 71% and 61%, respectively, in the second quarter of 2018. Capacity utilization for the first two quarters of 2017 in our Asia and North America PCB facilities was 82% and 55%, respectively, compared to 74% and 61%, respectively, in the first two quarters of 2018.

[0001564590-18-020718:mdna:42]
[same as prior period, unchanged from 0001564590-18-011836:mdna:38]

[0001564590-18-020718:mdna:43]
Selling and marketing expenses increased $2.7 million, from $15.9 million for the second quarter of 2017 to $18.6 million for the second quarter of 2018. Selling and marketing expenses increased $3.7 million, from $32.5 million for the first two quarters of 2017 to $36.2 million for the first two quarters of 2018. As a percentage of net sales, selling and marketing expenses was 2.5% for the second quarter of 2017, as compared to 2.6% for the second quarter of 2018, and 2.6% for both of the first two quarters of 2017 and 2018. The increase in selling and marketing expense for the second quarter and the first two quarters primarily relates to the acquisition of Anaren on April 18, 2018.

[0001564590-18-020718:mdna:44]
[same as prior period, unchanged from 0001564590-18-011836:mdna:40]

[0001564590-18-020718:mdna:45]
General and administrative expenses increased $17.2 million from $29.1 million, or 4.7% of net sales, for the second quarter of 2017 to $46.3 million, or 6.5% of net sales, for the second quarter of 2018. General and administrative expenses increased $22.6 million from $58.9 million, or 4.7% of net sales, for the first two quarters of 2017 to $81.5 million, or 5.9% of net sales, for the first two quarters of 2018. The increase in expense primarily relates to $6.8 million and $10.8 million of acquisition-related costs for the quarter and the first two quarters of 2018, respectively, associated with the acquisition of Anaren on April 18, 2018 and two and a half months of general and administrative expense incurred by Anaren post acquisition.

[0001564590-18-020718:mdna:46]
[same as prior period, unchanged from 0001564590-18-011836:mdna:42]

[0001564590-18-020718:mdna:47]
Other expense, net decreased $4.4 million from $18.7 million for the second quarter of 2017 to $14.3 million for the second quarter of 2018. Other expense, net decreased $5.0 million from $34.1 million for the first two quarters of 2017 to $29.1 million for the first two quarters of 2018. The decrease in other expense, net for both the quarter and two quarters was primarily the result of foreign currency gains due to the depreciation of the Chinese Renminbi (RMB) as well as certain government incentives, offset by an increase in interest expense primarily related to the $600.0 million incremental borrowing in conjunction with the Anaren acquisition. We utilize the RMB at our China facilities for employee-related expenses, foreign currency denominated purchases, and other costs of running our operations in China. Further, our translation of balance sheet accounts denominated in foreign currencies could be impacted if foreign exchange rates between those currencies (principally the RMB) and the U.S. Dollar change.

[0001564590-18-020718:mdna:48]
[same as prior period, unchanged from 0001564590-18-011836:mdna:44]

[0001564590-18-020718:mdna:49]
The provision for income taxes decreased by $72.1 million from a tax expense of $5.6 million for the second quarter of 2017 to a tax benefit of $66.5 million for the second quarter of 2018. The provision for income taxes decreased by $71.2 million from $9.7 million of tax expense for the first two quarters of 2017 to $61.5 million of tax benefit for the first two quarters of 2018. The decreases in income tax expense in 2018 were primarily due to a release of a portion of our valuation allowance against our U.S. federal and state net deferred tax assets, decreased operating income, additional benefits from the release of uncertain tax positions, additional tax incentives, and an offset by an additional accrual of tax expense related to a change in our policy of indefinite reinvestment outside of the U.S. for our undistributed earnings attributable to our foreign subsidiaries.

[0001564590-18-020718:mdna:50]
[same as prior period, unchanged from 0001564590-18-011836:mdna:46]

[0001564590-18-020718:mdna:51]
[same as prior period, unchanged from 0001564590-18-011836:mdna:47]

[0001564590-18-020718:mdna:52]
[same as prior period, unchanged from 0001564590-18-011836:mdna:48]

[0001564590-18-020718:mdna:53]
[same as prior period, unchanged from 0001564590-18-011836:mdna:49]

[0001564590-18-020718:mdna:54]
[same as prior period, unchanged from 0001564590-18-011836:mdna:50]

[0001564590-18-020718:mdna:55]
[same as prior period, unchanged from 0001564590-18-011836:mdna:51]

[0001564590-18-020718:mdna:56]
[same as prior period, unchanged from 0001564590-18-011836:mdna:52]

[0001564590-18-020718:mdna:57]
[same as prior period, unchanged from 0001564590-18-011836:mdna:53]

[0001564590-18-020718:mdna:58]
Our effective tax rate was primarily impacted by tax rates in China and Hong Kong, the U.S. federal income tax rate, apportioned state income tax rates, generation of other credits and deductions available to us, as well as changes in valuation allowances, and certain non-deductible items. Certain foreign losses generated are not more likely than not to be realizable, and thus no income tax benefit has been recognized on these losses. We had a net deferred income tax liability of approximately $18.5 million and $4.9 million as of July 2, 2018 and January 1, 2018, respectively.

[0001564590-18-020718:mdna:59]
[same as prior period, unchanged from 0001564590-18-011836:mdna:55]

[0001564590-18-020718:mdna:60]
[same as prior period, unchanged from 0001564590-18-011836:mdna:56]

[0001564590-18-020718:mdna:61]
Cash flow provided by operating activities during first two quarters of 2018 was $41.4 million as compared to $108.7 million in the same period in 2017. The decrease in cash flow was primarily due to increased investment in working capital. Cash cycle days increased to 49 days for the second quarter of 2018 as compared to 40 days for the same quarter of 2017 primarily due to increased accounts receivable resulting from a change in customer mix and timing of receivable collections. As of July 2, 2018, we had net working capital of approximately $513.4 million compared to $501.0 million as of January 1, 2018.

[0001564590-18-020718:mdna:62]
Net cash used in investing activities was approximately $677.5 million for the first two quarters of 2018, reflecting $596.4 million for acquisition of Anaren, net of debt assumed, and $81.1 million net purchases of property, plant and equipment. Net cash used in investing activities was approximately $69.0 million for the first two quarters of 2017 reflecting purchases of property, plant and equipment of $87.1 million less proceeds from sale of property, plant and equipment and assets held for sale of $18.1 million.

[0001564590-18-020718:mdna:63]
Net cash provided by financing activities was approximately $431.7 million for the first two quarters of 2018, primarily reflecting proceeds of $623.0 million from incremental term and revolving loan borrowings, offset by the repayment of assumed long-term debt in acquisition of $178.6 million, repayment of long-term debt $3.7 million, and payment of debt issuance costs and original issue discount of $9.2 million associated with the incremental term loans. Net cash used by financing activities was approximately $49.9 million the first two quarters of 2017 primarily reflecting additional prepayments of principal of long-term debt.

[0001564590-18-020718:mdna:64]
As of July 2, 2018, we had cash and cash equivalents of approximately $204.1 million, of which approximately $139.5 million was held by our foreign subsidiaries, primarily in China. Cash and cash equivalents held by our foreign locations are expected to be used in local operations.

[0001564590-18-020718:mdna:65]
[same as prior period, unchanged from 0001564590-18-011836:mdna:61]

[0001564590-18-020718:mdna:66]
[same as prior period, unchanged from 0001564590-18-011836:mdna:62]

[0001564590-18-020718:mdna:67]
[same as prior period, unchanged from 0001564590-18-011836:mdna:63]

[0001564590-18-020718:mdna:68]
On April 18, 2018, we closed our $600.0 million commitment of incremental loans concurrent with the completion of our acquisition of Anaren. We used the proceeds of the incremental loans along with cash on hand to fund the purchase of the acquisition and to pay related fees and expenses. These incremental loans increased the existing balance of our Term Loan Facility due 2024 from $348.3 million to $948.3 million. This Term Loan Facility had an outstanding balance of $945.9 million as of July 2, 2018, of which $40.0 million is included in short-term debt and $905.9 million is included in long-term debt, was issued at a weighted average discount of 99.7% and bears interest, at our option, at a floating rate of LIBOR, plus an applicable interest margin of 2.5%, or an alternate base rate, (defined as the greater of the JP Morgan prime, the New York Fed bank rate plus 0.5% or LIBOR plus 1%), subject to a 1% floor plus an applicable margin of 1.5%. At July 2, 2018, the interest rate on the outstanding borrowings under the Term Loan Facility was 4.60%. There is no provision, other than an event of default, for the interest margin to increase. The Term Loan Facility will mature on September 28, 2024. The Term Loan Facility is secured by a significant amount of our domestic assets and a pledge of 65% of voting stock of our first tier foreign subsidiaries and is structurally senior to our Senior Notes and Convertible Senior Notes. See Senior Notes and Convertible Senior Notes below.

[0001564590-18-020718:mdna:69]
We are required to make scheduled payments of the outstanding Term Loan Facility on a quarterly basis beginning January 1, 2018. Subsequent to July 2, 2018, we made an optional debt principal prepayment of $40.0 million. As a result of the prepayment, we are no longer required to make any quarterly scheduled payments until October 2022. However, based on certain parameters defined in the Term Loan Facility, including a First Lien Leverage Ratio, we may be required to make an additional principal payment on an annual basis beginning after fiscal year 2018. Any additional annual payments or prepayments would reduce future required scheduled payments. Any remaining outstanding balance under the Term Loan Facility is due at the maturity date of September 28, 2024.

[0001564590-18-020718:mdna:70]
Borrowings under the Term Loan Facility are subject to certain affirmative and negative covenants, including limitations on indebtedness, corporate transactions, investments and dispositions, and share payments. At July 2, 2018, we were in compliance with the covenants under the Term Loan Facility.

[0001564590-18-020718:mdna:71]
[same as prior period, unchanged from 0001564590-18-011836:mdna:68]

[0001564590-18-020718:mdna:72]
[same as prior period, unchanged from 0001564590-18-011836:mdna:69]

[0001564590-18-020718:mdna:73]
Borrowings under the Senior Notes are subject to certain affirmative and negative covenants, including limitations on indebtedness, corporate transactions, investments, dispositions, and share payments. At July 2, 2018, we were in compliance with the covenants under the Senior Notes.

[0001564590-18-020718:mdna:74]
Convertible Senior Notes due 2020

[0001564590-18-020718:mdna:75]
[same as prior period, unchanged from 0001564590-18-011836:mdna:72]

[0001564590-18-020718:mdna:76]
[same as prior period, unchanged from 0001564590-18-011836:mdna:73]

[0001564590-18-020718:mdna:77]
[same as prior period, unchanged from 0001564590-18-011836:mdna:74]

[0001564590-18-020718:mdna:78]
The U.S. ABL consists of three tranches comprised of a revolving credit facility of up to $200.0 million, a letter of credit facility for up to $50.0 million, and swingline loans for up to $30.0 million, provided that at no time may amounts outstanding under the tranches exceed in aggregate $200.0 million or the applicable borrowing base, which is a percentage of the principal amount of Eligible Accounts, as defined in the U.S. ABL agreement. Borrowings under the U.S. ABL bear interest at either a floating rate of LIBOR plus a margin of 150 basis points or JP Morgan Chase Bank’s prime rate plus a margin of 50 basis points, at our option. At July 2, 2018, the interest rate on the outstanding borrowings under the U.S. ABL was 3.60%. The applicable margin can vary based on the remaining availability of the facility, from 125 to 175 basis points for LIBOR-based loans and from 25 to 75 basis points for JP Morgan Chase Bank’s prime rate-based loans. Other than availability and an event of default, there are no other provisions for the interest margin to increase. The U.S. ABL will mature on May 31, 2020. Loans made under the U.S. ABL are secured first by all of our domestic cash, receivables and certain inventories as well as by a second position against a significant amount of our domestic assets and a pledge of 65% of the voting stock of our first tier foreign subsidiaries and are structurally senior to our Senior Notes and Convertible Senior Notes. See Senior Notes and Convertible Senior Notes elsewhere in this section. At July 2, 2018, $40.0 million of the U.S. ABL was outstanding and classified as long-term debt, which is consistent with its maturity date.

[0001564590-18-020718:mdna:79]
The Asia ABL consists of two tranches comprised of a revolving credit facility for up to $150.0 million and a letter of credit facility for up to $100.0 million, provided that at no time may amounts outstanding under both tranches exceed in aggregate $150.0 million or the applicable borrowing base, which is a percentage of the principal amount of Eligible Accounts, as defined in the Asia ABL agreement. Borrowings under the Asia ABL bear interest at a floating rate of LIBOR plus 140 basis points. At July 2, 2018, the interest rate on the outstanding borrowings under the Asia ABL was 3.50%. There is no provision, other than an event of default, for the interest margin to increase. The Asia ABL will mature on May 22, 2020. Loans made under the Asia ABL are secured by a portion of our Asia cash and receivables and are structurally senior to our domestic obligations, including the Senior Notes and Convertible Senior Notes. See Senior Notes and Convertible Senior Notes elsewhere in this section. At July 2, 2018, $30.0 million of the Asia ABL was outstanding and classified as long-term debt, which is consistent with its maturity date.

[0001564590-18-020718:mdna:80]
We have up to $50.0 million and $100.0 million Letters of Credit Facilities under the U.S. ABL and the Asia ABL, respectively. As of July 2, 2018, letters of credit in the amount of $6.1 million were outstanding under the U.S. ABL and $13.5 million were outstanding under the Asia ABL with various expiration dates through June 2019. Available borrowing capacity under the U.S. ABL and the Asia ABL was $153.9 million and $106.5 million, respectively, which considers letters of credit outstanding at July 2, 2018.

[0001564590-18-020718:mdna:81]
We are required to pay a commitment fee of 0.25% to 0.375% per annum on any unused portion of the ABL Revolving Loans. We paid commitment fees of $0.2 million and $0.5 million for the quarter and two quarters ended July 2, 2018, respectively. Under the occurrence of certain events, the ABL Revolving Loans are subject to various financial and operational covenants, including maintaining minimum fixed charge coverage ratios. At July 2, 2018, we were in compliance with the covenants under the ABL Revolving Loans.

[0001564590-18-020718:mdna:82]
Other Credit Facility

[0001564590-18-020718:mdna:83]
Additionally, we are party to a revolving loan credit facility (Chinese Revolver) with a lender in China. Under this arrangement, the lender has made available to us approximately $31.7 million in unsecured borrowing with all terms of the borrowing to be negotiated at the time the Chinese Revolver is drawn upon. There are no commitment fees on the unused portion of the Chinese Revolver, and this arrangement expires in January 2019. As of July 2, 2018, the Chinese Revolver had not been drawn upon.

[0001564590-18-020718:mdna:84]
[same as prior period, unchanged from 0001564590-18-011836:mdna:81]

[0001564590-18-020718:mdna:85]
[same as prior period, unchanged from 0001564590-18-011836:mdna:82]

[0001564590-18-020718:mdna:86]
The following table provides information on our contractual obligations as of July 2, 2018:

[0001564590-18-020718:mdna:87]
|  |  | Total |  |  | Less Than 1 year |  |  | 1 - 3 Years |  |  | 4 - 5 Years |  |  | After 5 Years |  |
| Contractual Obligations (1) |  | (In thousands) |  |
| Long-term debt obligations |  | $ | 1,392,435 |  |  | $ | 40,729 |  |  | $ | 70,827 |  |  | $ | 7,413 |  |  | $ | 1,273,466 |  |
| Convertible debt obligations |  |  | 249,985 |  |  |  | — |  |  |  | 249,985 |  |  |  | — |  |  |  | — |  |
| Interest on debt obligations |  |  | 437,289 |  |  |  | 70,388 |  |  |  | 135,378 |  |  |  | 127,170 |  |  |  | 104,353 |  |
| Derivative liabilities |  |  | 1,565 |  |  |  | 1,565 |  |  |  | — |  |  |  | — |  |  |  | — |  |
| Purchase obligations |  |  | 112,704 |  |  |  | 101,603 |  |  |  | 2,808 |  |  |  | 607 |  |  |  | 7,686 |  |
| Operating lease commitments |  |  | 29,526 |  |  |  | 11,176 |  |  |  | 9,052 |  |  |  | 3,522 |  |  |  | 5,776 |  |
| Total contractual obligations |  | $ | 2,223,504 |  |  | $ | 225,461 |  |  | $ | 468,050 |  |  | $ | 138,712 |  |  | $ | 1,391,281 |  |

[0001564590-18-020718:mdna:88]
| (1) | Unrecognized uncertain tax benefits of $39.7 million are not included in the table above as the settlement timing is uncertain. |

[0001564590-18-020718:mdna:89]
[same as prior period, unchanged from 0001564590-18-011836:mdna:86]

[0001564590-18-020718:mdna:90]
[same as prior period, unchanged from 0001564590-18-011836:mdna:87]

[0001564590-18-020718:mdna:91]
[same as prior period, unchanged from 0001564590-18-011836:mdna:88]

[0001564590-18-020718:mdna:92]
[same as prior period, unchanged from 0001564590-18-011836:mdna:89]
