# TTMI note change history — 0001564590-18-011836 → 0001564590-18-020718


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2018-08-09):
[0001564590-18-020718:note_history:1]
The Company is subject to various legal matters, which it considers normal for its business activities. While the Company currently believes that the amount of any reasonably possible loss for known matters would not be material to the Company’s financial condition, the outcome of these actions is inherently difficult to predict. In the event of an adverse outcome, the ultimate potential loss could have a material adverse effect on the Company’s financial condition or results of operations in a particular period. The Company has accrued amounts for its loss contingencies which are probable and estimable as of July 2, 2018 and January 1, 2018. However, these amounts are not material to the consolidated condensed financial statements of the Company.
  (was, 2018-05-08, similarity 0.9753):
[0001564590-18-011836:note_history:1]
The Company is subject to various legal matters, which it considers normal for its business activities. While the Company currently believes that the amount of any reasonably possible loss for known matters would not be material to the Company’s financial condition, the outcome of these actions is inherently difficult to predict. In the event of an adverse outcome, the ultimate potential loss could have a material adverse effect on the Company’s financial condition or results of operations in a particular period. The Company has accrued amounts for its loss contingencies which are probable and estimable as of April 2, 2018 and January 1, 2018. However, these amounts are not material to the consolidated condensed financial statements of the Company.

- changed (2018-08-09):
[0001564590-18-020718:note_history:2]
The process to manufacture PCBs requires adherence to city, county, state, federal regulations as well as foreign environmental regulations regarding the storage, use, handling and disposal of chemicals, solid wastes and other hazardous materials, as well as compliance with air quality standards and chemical use reporting. The Company believes that its facilities in the United States and Canada comply in all material respects with applicable environmental laws and regulations. In China, governmental authorities have adopted new rules and regulations governing environmental issues. An update to the Chinese environmental waste water law was issued in late 2012, allowing for an interim period in which plants subject to such law may install equipment that meets the new regulatory regime. Some of the Company’s plants in China are not yet in full compliance with the updated environmental regulations. The Company has established and enacted an investment plan related to the efforts to come into full compliance with the new regulations. The 2018 capital expenditure costs expected for these plans are included in the Company’s capital expenditure projections.
  (was, 2018-05-08, similarity 0.9878):
[0001564590-18-011836:note_history:2]
The process to manufacture PCBs requires adherence to city, county, state, federal, and foreign environmental regulations regarding the storage, use, handling and disposal of chemicals, solid wastes and other hazardous materials, as well as compliance with air quality standards and chemical use reporting. The Company believes that its facilities in the United States and Canada comply in all material respects with applicable environmental laws and regulations. In China, governmental authorities have adopted new rules and regulations governing environmental issues. An update to the Chinese environmental waste water law was issued in late 2012, allowing for an interim period in which plants subject to such law may install equipment that meets the new regulatory regime. Some of the Company’s plants in China are not yet in full compliance with the updated environmental regulations. The Company has established and enacted an investment plan related to the efforts to come into full compliance with the new regulations. The 2018 capital expenditure costs expected for these plans are included in the Company’s capital expenditure projections.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- added (2018-08-09):
[0001564590-18-020718:note_history:3]
TTM Technologies, Inc. (the Company or TTM) is a leading global printed circuit board (PCB) manufacturer, focusing on quick-turn and volume production of technologically complex PCBs and electro-mechanical solutions (E-M Solutions) as well as a global designer and manufacturer of high-frequency radio frequency (RF) and microwave components and assemblies. The Company provides time-to-market and volume production of advanced technology products and offers a one-stop manufacturing solution to customers from engineering support to prototype development through final mass production. This one-stop manufacturing solution enables the Company to align technology developments with the diverse needs of the Company’s customers and to enable them to reduce the time required to develop new products and bring them to market.

- changed (2018-08-09):
[0001564590-18-020718:note_history:4]
The Company assessed the new guidance and adopted the new revenue standard on January 2, 2018, which resulted in a change to the timing of revenue recognition for certain of the Company’s revenue streams from “point in time” upon physical delivery to an “over time” model. Additionally, the Company elected the cumulative effect transition method with adjustment to the opening balance of retained earnings at January 2, 2018 for all open contracts as of January 1, 2018. Therefore, comparative information has not been adjusted and continues to be reported under previous U.S. GAAP guidance for the consolidated balance sheet at January 1, 2018 and the consolidated condensed statement of operations for the quarter and two quarters ended July 3, 2017.
  (was, 2018-05-08, similarity 0.9568):
[0001564590-18-011836:note_history:4]
The Company assessed the new guidance and adopted the new revenue standard on January 2, 2018, which resulted in a change to the timing of revenue recognition for the Company’s revenue stream from “point in time” upon physical delivery to an “over time” model. Additionally, the Company has elected the cumulative effect transition method with adjustment to the opening balance of retained earnings at January 2, 2018 for all open contracts as of January 1, 2018. Therefore, comparative information has not been adjusted and continues to be reported under previous U.S. GAAP guidance for the consolidated balance sheet at January 1, 2018 and the consolidated condensed statement of operations for the quarter ended April 3, 2017.

- changed (2018-08-09):
[0001564590-18-020718:note_history:5]
The cumulative effect of the changes made to the Company’s January 2, 2018 consolidated condensed balance sheet for the adoption of the new revenue standard was as follows:
  (was, 2018-05-08, similarity 0.9852):
[0001564590-18-011836:note_history:5]
The cumulative effect of the changes made to the Company’s January 2, 2018 consolidated condensed balance sheet for the adoption of the new revenue standard were as follows:

- added (2018-08-09):
[0001564590-18-020718:note_history:6]
Additionally, the disclosure below summarizes the impact of the adoption of the new revenue standard on the Company’s consolidated condensed balance sheet as of July 2, 2018, statement of operations for the quarter and two quarters ended July 2, 2018 and statement of cash flows for the two quarters ended July 2, 2018 for which the As Reported reflects the new revenue standard and Balances without New Revenue Standard Adjustment reflects the Company’s replaced revenue recognition policy of “point in time” and upon physical delivery, for certain revenue streams, as appropriate.

- changed (2018-08-09):
[0001564590-18-020718:note_history:7]
|  |  | July 2, 2018 |  |
|  |  | As reported |  |  | Effect of Change Increase (Decrease) |  |  | Balances without New Revenue Standard Adjustment |  |
|  |  | (In thousands) |  |
| Balance Sheet |  |  |  |  |  |  |  |  |  |  |  |  |
| Assets |  |  |  |  |  |  |  |  |  |  |  |  |
| Accounts receivable, net |  | $ | 541,587 |  |  | $ | 8,171 |  |  | $ | 533,416 |  |
| Contract assets |  |  | 300,717 |  |  |  | 293,114 |  |  |  | 7,603 |  |
| Inventories |  |  | 121,285 |  |  |  | (245,895 | ) |  |  | 367,180 |  |
| Liabilities |  |  |  |  |  |  |  |  |  |  |  |  |
| Other accrued expenses |  |  | 104,139 |  |  |  | 14,033 |  |  |  | 90,106 |  |
| Other long-term liabilities |  |  | 92,938 |  |  |  | 3,163 |  |  |  | 89,775 |  |
| Equity |  |  |  |  |  |  |  |  |  |  |  |  |
| Retained earnings |  |  | 315,975 |  |  |  | 38,194 |  |  |  | 277,781 |  |
  (was, 2018-05-08, similarity 0.6426):
[0001564590-18-011836:note_history:7]
|  |  | April 2, 2018 |  |
|  |  | As reported |  |  | Effect of Change Increase (Decrease) |  |  | Balances without New Revenue Standard Adjustment |  |
|  |  | (In thousands) |  |
| Balance Sheet |  |  |  |  |  |  |  |  |  |  |  |  |
| Assets |  |  |  |  |  |  |  |  |  |  |  |  |
| Accounts receivable, net |  | $ | 504,914 |  |  | $ | 8,171 |  |  | $ | 496,743 |  |
| Contract assets |  |  | 275,022 |  |  |  | 275,022 |  |  |  | — |  |
| Inventories |  |  | 82,116 |  |  |  | (235,557 | ) |  |  | 317,673 |  |
| Liabilities |  |  |  |  |  |  |  |  |  |  |  |  |
| Other accrued expenses |  |  | 102,162 |  |  |  | 13,671 |  |  |  | 88,491 |  |
| Other long-term liabilities |  |  | 77,078 |  |  |  | 3,163 |  |  |  | 73,915 |  |
| Equity |  |  |  |  |  |  |  |  |  |  |  |  |
| Retained earnings |  |  | 232,013 |  |  |  | 30,801 |  |  |  | 201,212 |  |

- added (2018-08-09):
[0001564590-18-020718:note_history:8]
|  |  | Quarter ended July 2, 2018 |  |  | Two Quarters ended July 2, 2018 |  |
|  |  | As reported |  |  | Effect of Change Increase (Decrease) |  |  | Balances without New Revenue Standard Adjustment |  |  | As reported |  |  | Effect of Change Increase |  |  | Balances without New Revenue Standard Adjustment |  |
|  |  | (In thousands) |  |  | (In thousands) |  |
| Net sales |  | $ | 716,887 |  |  | $ | 17,730 |  |  | $ | 699,157 |  |  | $ | 1,380,469 |  |  | $ | 31,811 |  |  | $ | 1,348,658 |  |
| Cost of goods sold |  |  | 600,747 |  |  |  | (10,338 | ) |  |  | 611,085 |  |  |  | 1,175,651 |  |  |  | 22,319 |  |  |  | 1,153,332 |  |
| Gross profit |  |  | 116,140 |  |  |  | 7,392 |  |  |  | 108,748 |  |  |  | 204,818 |  |  |  | 9,492 |  |  |  | 195,326 |  |
| Net income |  |  | 84,004 |  |  |  | 7,392 |  |  |  | 76,612 |  |  |  | 94,101 |  |  |  | 9,620 |  |  |  | 84,481 |  |

- added (2018-08-09):
[0001564590-18-020718:note_history:9]
Included in the Effect of Change Increase (Decrease) columns for the quarter and two quarters ended July 2, 2018 are $14,408, $11,375 and $3,033 of net sales, cost of goods sold and gross profit, respectively, related to the opening balance sheet of Anaren Inc. which was acquired on April 18, 2018 (See Note 3), and not to the activity during the quarter.

- changed (2018-08-09):
[0001564590-18-020718:note_history:10]
|  |  | Two Quarters ended July 2, 2018 |  |
|  |  | As reported |  |  | Effect of Change Increase (Decrease) |  |  | Balances without New Revenue Standard Adjustment |  |
|  |  | (In thousands) |  |
| Cash flows from operating activities: |  |  |  |  |  |  |  |  |  |  |  |  |
| Net income |  | $ | 94,101 |  |  | $ | 9,620 |  |  | $ | 84,481 |  |
| Adjustments to reconcile net income to net cash used in operating activities: |  |  |  |  |  |  |  |  |  |  |  |  |
| Deferred income taxes |  |  | (64,769 | ) |  |  | (128 | ) |  |  | (64,641 | ) |
| Changes in operating assets and liabilities: |  |  |  |  |  |  |  |  |  |  |  |  |
| Accounts receivable, net |  |  | (17,056 | ) |  |  | — |  |  |  | (17,056 | ) |
| Contract assets |  |  | (16,478 | ) |  |  | (32,460 | ) |  |  | 15,982 |  |
| Inventories |  |  | 5,685 |  |  |  | 22,319 |  |  |  | (16,634 | ) |
| Accrued salaries, wages and benefits and other accrued expenses |  |  | (47,911 | ) |  |  | 649 |  |  |  | (48,560 | ) |
  (was, 2018-05-08, similarity 0.9607):
[0001564590-18-011836:note_history:10]
|  |  | April 2, 2018 |  |
|  |  | As reported |  |  | Effect of Change Increase (Decrease) |  |  | Balances without New Revenue Standard Adjustment |  |
|  |  | (In thousands) |  |
| Cash flows from operating activities: |  |  |  |  |  |  |  |  |  |  |  |  |
| Net income |  | $ | 10,097 |  |  | $ | 2,227 |  |  | $ | 7,870 |  |
| Adjustments to reconcile net income to net cash used in operating activities: |  |  |  |  |  |  |  |  |  |  |  |  |
| Other |  |  | (439 | ) |  |  | (127 | ) |  |  | (312 | ) |
| Changes in operating assets and liabilities: |  |  |  |  |  |  |  |  |  |  |  |  |
| Accounts receivable, net |  |  | (12,840 | ) |  |  | — |  |  |  | (12,840 | ) |
| Contract assets |  |  | (14,368 | ) |  |  | (14,368 | ) |  |  | — |  |
| Inventories |  |  | (11,104 | ) |  |  | 11,981 |  |  |  | (23,085 | ) |
| Accrued salaries, wages and benefits and other accrued expenses |  |  | (47,566 | ) |  |  | 287 |  |  |  | (47,853 | ) |

- changed (2018-08-09):
[0001564590-18-020718:note_history:11]
In August 2017, the FASB issued ASU 2017-12, Derivatives and Hedging (Topic 815): Targeted Improvements to Accounting for Hedging Activities. This ASU amends and simplifies existing guidance in order to allow companies to more accurately present the economic effects of risk management activities in the financial statements. ASU 2017-12 also amends the guidance surrounding the recognition of the value of hedged instruments to include the entire change in value, rather than just the effective portion, in other comprehensive income and recognized in earnings at the same time that the hedged item affects earnings for cash flow and net investment hedges. This ASU is effective for fiscal years beginning after December 15, 2018, including interim periods within those fiscal years. Early adoption is permitted. The adoption of this standard is not expected to have a material impact on the consolidated financial statements or related disclosures.
  (was, 2018-05-08, similarity 0.8721):
[0001564590-18-011836:note_history:11]
In August 2017, the FASB issued ASU 2017-12, Derivatives and Hedging (Topic 815): Targeted Improvements to Accounting for Hedging Activities. This ASU amends and simplifies existing guidance in order to allow companies to more accurately present the economic effects of risk management activities in the financial statements. ASU 2017-12 also amends the guidance surrounding the recognition of the value of hedged instruments to include the entire change in value, rather than just the effective portion, in other comprehensive income and recognized in earnings at the same time that the hedged item affects earnings for cash flow and net investment hedges. This ASU is effective for fiscal years beginning after December 15, 2018, including interim periods within those fiscal years. Early adoption is permitted. The Company is currently evaluating the new guidance to determine the impact it may have on its consolidated financial statements and related disclosures.

- added (2018-08-09):
[0001564590-18-020718:note_history:12]
In February 2016, the FASB issued ASU 2016-02, Leases (Topic 842). The objective of this update is to increase transparency and comparability among organizations by recognizing lease assets and lease liabilities on the balance sheet and disclosing key information about leasing arrangements. This ASU is effective for fiscal years beginning after December 15, 2018, including interim periods within those annual periods and is to be applied utilizing a modified retrospective approach. The Company is currently planning on electing the package of practical expedients to not reassess prior conclusions related to contracts containing leases, lease classification and initial direct costs, and is evaluating other practical expedients available under the guidance. Additionally, the Company continues to evaluate the new guidance to determine the impact it may have on its consolidated financial statements and related disclosures, the primary effect of adopting this update will be to record assets and liabilities for existing operating leases.

- removed (2018-08-09):
[0001564590-18-011836:note_history:13]
TTM Technologies, Inc. (the Company or TTM) is a leading global printed circuit board (PCB) manufacturer, focusing on quick-turn and volume production of technologically complex PCBs and electro-mechanical solutions (E-M Solutions). The Company provides time-to-market and volume production of advanced technology products and offers a one-stop manufacturing solution to customers from engineering support to prototype development through final mass production. This one-stop manufacturing solution enables the Company to align technology developments with the diverse needs of the Company’s customers and to enable them to reduce the time required to develop new products and bring them to market.

- removed (2018-08-09):
[0001564590-18-011836:note_history:14]
Additionally, the below disclosure summarizes the impact of the adoption of new revenue standard on the Company’s consolidated condensed balance sheet, statement of operations and statement of cash flows for the quarter ended April 2, 2018 for which the As Reported reflects the new revenue standard and Balances without New Revenue Standard Adjustment reflects the Company’s replaced revenue recognition policy of “point in time” and upon physical delivery.

- removed (2018-08-09):
[0001564590-18-011836:note_history:15]
|  |  | April 2, 2018 |  |
|  |  | As reported |  |  | Effect of Change Increase |  |  | Balances without New Revenue Standard Adjustment |  |
|  |  | (In thousands) |  |
| Net sales |  | $ | 663,582 |  |  | $ | 14,081 |  |  | $ | 649,501 |  |
| Cost of goods sold |  |  | 574,904 |  |  |  | 11,981 |  |  |  | 562,923 |  |
| Gross profit |  |  | 88,678 |  |  |  | 2,100 |  |  |  | 86,578 |  |
| Net income |  |  | 10,097 |  |  |  | 2,227 |  |  |  | 7,870 |  |

- removed (2018-08-09):
[0001564590-18-011836:note_history:16]
In February 2016, the FASB issued ASU 2016-02, Leases (Topic 842). The objective of this update is to increase transparency and comparability among organizations by recognizing lease assets and lease liabilities on the balance sheet and disclosing key information about leasing arrangements. This ASU is effective for fiscal years beginning after December 15, 2018, including interim periods within those annual periods and is to be applied utilizing a modified retrospective approach. While the Company continues to evaluate the new guidance to determine the impact it may have on its consolidated financial statements and related disclosures, the primary effect of adopting this update will be to record assets and liabilities for existing operating leases.


## us-gaap:SignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- added (2018-08-09):
[0001564590-18-020718:note_history:17]
The Company derives revenues primarily from the sale of PCBs, custom electronic assemblies using customer-supplied engineering and design plans.  With the acquisition of Anaren Inc. (See Note 3), the Company now also derives revenue from the design, development, and manufacture of components, assemblies, and subsystems which receive, process, and transmit microwave and RF signals which service the aerospace and defense electronics, and wireless communications markets.

- changed (2018-08-09):
[0001564590-18-020718:note_history:18]
The Company has three revenue streams which generally coincide with the Company’s reportable segments. These reportable segments are: PCB, E-M Solutions and Anaren.  See Note 17 Segment Information.
  (was, 2018-05-08, similarity 0.8163):
[0001564590-18-011836:note_history:18]
The Company has two revenue streams which coincide with the Company’s reportable segments of PCB and E-M Solutions. See Note 14 Segment Information.

- added (2018-08-09):
[0001564590-18-020718:note_history:19]
For the PCBs and custom electronic assemblies, orders for products generally correspond to the production schedules of the Company’s customers and are supported with firm purchase orders. The Company’s customers have continuous transfer of control of the work in progress and finished goods throughout the PCB manufacturing process, as PCBs are built to customer specifications and do not have an alternative use. The customer typically controls the work in progress and finished goods as evidenced either by contractual termination clauses or by the Company’s rights to payment for work performed to date, plus a reasonable profit.  As a result, the Company records revenue in accordance with the “over time” revenue standard as discussed in Note 1 Nature of Operations and Basis of Presentation ─ Recently Adopted and Issued Accounting Standards, beginning in the first quarter of 2018, the Company now recognizes revenue progressively over time based on the extent of progress towards completion of the performance obligation.

- added (2018-08-09):
[0001564590-18-020718:note_history:20]
Additionally, the Company has certain long-term contracts related to its manufacture of components, assemblies, and subsystems which service the aerospace and defense electronics market. These long-term contracts, many of which provide for periodic payments, are recognized over time under the percentage-of completion method. Estimated manufacturing cost-at-completion for these contracts are reviewed on a periodic basis, and adjustments are made periodically to the estimated cost-at-completion, based on actual costs incurred, progress made, and estimates of costs required to complete the contractual requirements. When the estimated manufacturing cost-at-completion exceeds the contract value, the contract is written down to its net realizable value and the loss resulting from the cost overruns are immediately recognized.

- added (2018-08-09):
[0001564590-18-020718:note_history:21]
Finally, the Company manufactures components, assemblies, and subsystems which service its wireless communications customers. The Company recognizes revenue at a point in time as the customer does not simultaneously receive or consume the benefits provided by the Company’s performance and the asset being manufactured has alternative uses to the Company.

- changed (2018-08-09):
[0001564590-18-020718:note_history:22]
The Company provides customers a limited right of return for defective PCBs, assemblies, components and subsystems. The Company accrues an estimate for sales returns and allowances progressively over time based on the extent of progress towards completion of the performance obligation using the Company’s judgment based on historical results and anticipated returns.  To the extent actual experience varies from its historical experience, revisions to the sales returns and allowances accrual may be required. Sales returns and allowances are recorded as a reduction of revenue and included as a component of accrued liabilities on the condensed consolidated balance sheet.
  (was, 2018-05-08, similarity 0.9489):
[0001564590-18-011836:note_history:22]
The Company provides customers a limited right of return for defective PCBs and backplane assemblies. The Company accrues an estimate for sales returns and allowances progressively over time based on the extent of progress towards completion of the performance obligation using the Company’s judgment based on historical results and anticipated returns.  To the extent actual experience varies from our historical experience, revisions to the sales returns and allowances accrual may be required. Sales returns and allowances are recorded as a reduction of revenue and included as a component of accrued liabilities on the condensed consolidated balance sheet.

- removed (2018-08-09):
[0001564590-18-011836:note_history:23]
The Company derives revenues primarily from the sale of PCBs and custom electronic assemblies using customer-supplied engineering and design plans. Orders for products generally correspond to the production schedules of the Company’s customers and are supported with firm purchase orders. The Company’s customers have continuous transfer of control of the work in progress and finished goods as PCBs are being manufactured, as PCBs are built to customer specifications and do not have an alternative use. The customer typically controls the work in progress and finished goods as evidenced either by contractual termination clauses or by the Company’s rights to payment for work performed to date, plus a reasonable profit.  As a result, in light of the Company’s adoption of the “over time” revenue standard as discussed in Note 1 Nature of Operations and Basis of Presentation─Recently Adopted and Issued Accounting Standards, beginning in the first quarter of 2018, the Company now recognizes revenue progressively over time based on the extent of progress towards completion of the performance obligation.


## ttmi:ScheduleOfComponentsOfInterestExpenseFromConvertibleNotesTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2018-08-09):
[0001564590-18-020718:note_history:24]
The components of interest expense resulting from the convertible senior notes for the quarter and two quarters ended July 2, 2018 and July 3, 2017 are as follows:
  (was, 2018-05-08, similarity 0.8986):
[0001564590-18-011836:note_history:24]
The components of interest expense resulting from the convertible senior notes for the quarters ended April 2, 2018 and April 3, 2017 are as follows:

- added (2018-08-09):
[0001564590-18-020718:note_history:25]
|  |  | Quarter Ended |  |  | Two Quarters Ended |  |
|  |  | July 2, |  |  | July 3, |  |  | July 2, |  |  | July 3, |  |
|  |  | 2018 |  |  | 2017 |  |  | 2018 |  |  | 2017 |  |
|  |  | (In thousands) |  |  | (In thousands) |  |
| Contractual coupon interest |  | $ | 1,093 |  |  | $ | 1,093 |  |  | $ | 2,187 |  |  | $ | 2,187 |  |
| Amortization of debt discount |  | $ | 2,267 |  |  | $ | 2,125 |  |  | $ | 4,497 |  |  | $ | 4,216 |  |
| Amortization of debt issuance costs |  | $ | 227 |  |  | $ | 214 |  |  | $ | 451 |  |  | $ | 423 |  |

- removed (2018-08-09):
[0001564590-18-011836:note_history:26]
|  |  | Quarter Ended |  |
|  |  | April 2, |  |  | April 3, |  |
|  |  | 2018 |  |  | 2017 |  |
|  |  | (In thousands) |  |
| Contractual coupon interest |  | $ | 1,094 |  |  | $ | 1,094 |  |
| Amortization of debt discount |  | $ | 2,230 |  |  | $ | 2,091 |  |
| Amortization of debt issuance costs |  | $ | 224 |  |  | $ | 209 |  |


## ttmi:ScheduleOfUnamortizedDiscountAndDebtIssuanceCostsTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2018-08-09):
[0001564590-18-020718:note_history:27]
As of July 2, 2018 and January 1, 2018, remaining unamortized debt discount and debt issuance costs for the Term Loan Facility, Senior Notes and Convertible Senior Notes are as follows:
  (was, 2018-05-08, similarity 0.9802):
[0001564590-18-011836:note_history:27]
As of April 2, 2018 and January 1, 2018, remaining unamortized debt discount and debt issuance costs for the Term Loan Facility, Senior Notes and Convertible Senior Notes are as follows:

- changed (2018-08-09):
[0001564590-18-020718:note_history:28]
|  |  | As of July 2, 2018 |  |  | As of January 1, 2018 |  |
|  |  | Debt Issuance Costs |  |  | Debt Discount |  |  | Effective Interest Rate |  |  | Debt Issuance Costs |  |  | Debt Discount |  |  | Effective Interest Rate |  |
|  |  | (in thousands) |  |
| Term Loan due September 2024 |  | $ | 10,037 |  |  | $ | 3,037 |  |  | 4.66% |  |  | $ | 2,788 |  |  | $ | 1,691 |  |  | 3.96% |  |
| Senior Notes due October 2025 |  |  | 6,432 |  |  | — |  |  | 5.92% |  |  |  | 6,782 |  |  | — |  |  | 5.92% |  |
| Convertible Senior Notes |  |  | 2,438 |  |  |  | 24,322 |  |  | 6.48% |  |  |  | 2,889 |  |  |  | 28,822 |  |  | 6.48% |  |
|  |  | $ | 18,907 |  |  | $ | 27,359 |  |  |  |  |  |  | $ | 12,459 |  |  | $ | 30,513 |  |  |  |  |  |
  (was, 2018-05-08, similarity 0.7676):
[0001564590-18-011836:note_history:28]
|  |  | As of April 2, 2018 |  |  | As of January 1, 2018 |  |
|  |  | Debt Issuance Costs |  |  | Debt Discount |  |  | Effective Interest Rate |  |  | Debt Issuance Costs |  |  | Debt Discount |  |  | Effective Interest Rate |  |
|  |  | (in thousands) |  |
| Term Loan due September 2024 |  | $ | 2,695 |  |  | $ | 1,636 |  |  |  | 3.96 | % |  | $ | 2,788 |  |  | $ | 1,691 |  |  |  | 3.96 | % |
| Senior Notes due October 2025 |  |  | 6,608 |  |  | — |  |  |  | 5.92 | % |  |  | 6,782 |  |  | — |  |  |  | 5.92 | % |
| Convertible Senior Notes |  |  | 2,665 |  |  |  | 26,589 |  |  |  | 6.48 | % |  |  | 2,889 |  |  |  | 28,822 |  |  |  | 6.48 | % |
|  |  | $ | 11,968 |  |  | $ | 28,225 |  |  |  |  |  |  | $ | 12,459 |  |  | $ | 30,513 |  |  |  |  |  |


## us-gaap:ConvertibleDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2018-08-09):
[0001564590-18-020718:note_history:29]
As of July 2, 2018 and January 1, 2018, the following summarizes the equity components of the convertible senior notes included in additional paid-in capital:
  (was, 2018-05-08, similarity 0.9766):
[0001564590-18-011836:note_history:29]
As of April 2, 2018 and January 1, 2018, the following summarizes the equity components of the convertible senior notes included in additional paid-in capital:

- changed (2018-08-09):
[0001564590-18-020718:note_history:30]
|  |  | As of July 2, 2018 and January 1, 2018 |  |
|  |  | Embedded conversion option — Convertible Senior Notes |  |  | Embedded conversion option — Convertible Senior Notes Issuance Costs |  |  | Total |  |
|  |  | (in thousands) |  |
| Convertible Senior Notes due 2020 |  | $ | 60,216 |  |  | $ | (1,916 | ) |  | $ | 58,300 |  |
  (was, 2018-05-08, similarity 0.9363):
[0001564590-18-011836:note_history:30]
|  |  | As of April 2, 2018 and January 1, 2018 |  |
|  |  | Embedded conversion option — Convertible Senior Notes |  |  | Embedded conversion option — Convertible Senior Notes Issuance Costs |  |  | Total |  |
|  |  | (in thousands) |  |
| Convertible senior notes due 2020 |  | $ | 60,216 |  |  | $ | (1,916 | ) |  | $ | 58,300 |  |


## us-gaap:LongTermDebtTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2018-08-09):
[0001564590-18-020718:note_history:31]
The following table summarizes the long-term debt of the Company as of July 2, 2018 and January 1, 2018:
  (was, 2018-05-08, similarity 0.9637):
[0001564590-18-011836:note_history:31]
The following table summarizes the long-term debt of the Company as of April 2, 2018 and January 1, 2018:

- changed (2018-08-09):
[0001564590-18-020718:note_history:32]
|  |  | Interest Rate as of July 2, 2018 |  |  | Principal Outstanding as of July 2, 2018 |  |  | Interest Rate as of January 1, 2018 |  |  | Principal Outstanding as of January 1, 2018 |  |
|  |  | (In thousands) |  |
| Term Loan due September 2024 |  | 4.60% |  |  | $ | 945,879 |  |  | 4.06% |  |  | $ | 349,125 |  |
| Senior Notes due October 2025 |  | 5.63% |  |  |  | 375,000 |  |  | 5.63% |  |  |  | 375,000 |  |
| Convertible Senior Notes due December 2020 |  | 1.75% |  |  |  | 249,985 |  |  | 1.75% |  |  |  | 249,985 |  |
| U.S. ABL Revolving Loan due May 2020 |  | 3.60% |  |  |  | 40,000 |  |  | 3.06% |  |  |  | 17,000 |  |
| Asia ABL Revolving Loan due May 2020 |  | 3.50% |  |  |  | 30,000 |  |  | 2.96% |  |  |  | 30,000 |  |
| Capital Lease |  | 6.43% |  |  |  | 1,556 |  |  | 6.43% |  |  |  | 1,919 |  |
|  |  |  |  |  |  |  | 1,642,420 |  |  |  |  |  |  |  | 1,023,029 |  |
| Less: Long-term debt unamortized discount |  |  |  |  |  |  | (27,359 | ) |  |  |  |  |  |  | (30,513 | ) |
| Long-term debt unamortized debt issuance costs |  |  |  |  |  |  | (18,907 | ) |  |  |  |  |  |  | (12,459 | ) |
|  |  |  |  |  |  |  | 1,596,154 |  |  |  |  |  |  |  | 980,057 |  |
| Less: current maturities |  |  |  |  |  |  | (40,729 | ) |  |  |  |  |  |  | (4,578 | ) |
| Long-term debt, less current maturities |  |  |  |  |  | $ | 1,555,425 |  |  |  |  |  |  | $ | 975,479 |  |
  (was, 2018-05-08, similarity 0.9807):
[0001564590-18-011836:note_history:32]
|  |  | Interest Rate as of April 2, 2018 |  |  | Principal Outstanding as of April 2, 2018 |  |  | Interest Rate as of January 1, 2018 |  |  | Principal Outstanding as of January 1, 2018 |  |
|  |  | (In thousands) |  |
| Term Loan due September 2024 |  | 4.38% |  |  | $ | 348,250 |  |  | 4.06% |  |  | $ | 349,125 |  |
| Senior Notes due October 2025 |  | 5.63% |  |  |  | 375,000 |  |  | 5.63% |  |  |  | 375,000 |  |
| Convertible Senior Notes due December 2020 |  | 1.75% |  |  |  | 249,985 |  |  | 1.75% |  |  |  | 249,985 |  |
| U.S. ABL Revolving Loan due May 2020 |  | 3.13% |  |  |  | 17,000 |  |  | 3.06% |  |  |  | 17,000 |  |
| Asia ABL Revolving Loan due May 2020 |  | 3.28% |  |  |  | 30,000 |  |  | 2.96% |  |  |  | 30,000 |  |
| Capital Lease |  | 6.43% |  |  |  | 1,987 |  |  | 6.43% |  |  |  | 1,919 |  |
|  |  |  |  |  |  |  | 1,022,222 |  |  |  |  |  |  |  | 1,023,029 |  |
| Less: Long-term debt unamortized discount |  |  |  |  |  |  | (28,225 | ) |  |  |  |  |  |  | (30,513 | ) |
| Long-term debt unamortized debt issuance costs |  |  |  |  |  |  | (11,968 | ) |  |  |  |  |  |  | (12,459 | ) |
|  |  |  |  |  |  |  | 982,029 |  |  |  |  |  |  |  | 980,057 |  |
| Less: current maturities |  |  |  |  |  |  | (4,616 | ) |  |  |  |  |  |  | (4,578 | ) |
| Long-term debt, less current maturities |  |  |  |  |  | $ | 977,413 |  |  |  |  |  |  | $ | 975,479 |  |

- changed (2018-08-09):
[0001564590-18-020718:note_history:33]
On April 18, 2018, the Company closed its $600,000 commitment of incremental loans concurrent with the completion of its acquisition of Anaren. These incremental loans increased the Company’s existing balance of its Term Loan Facility due 2024 from $348,250 to $948,250. This Term Loan Facility had an outstanding balance of $945,879 as of July 2, 2018, of which $40,000 is included in short-term debt and $905,879 is included in long-term debt. The Term Loan Facility was issued at a weighted average discount of 99.7% and bears interest, at the Company’s option, at a floating rate of LIBOR, plus an applicable interest margin of 2.50%, or an alternate base rate, (defined as the greater of the JP Morgan prime, the New York Fed bank rate plus 0.5% or LIBOR plus 1.0%), subject to a 1.0% floor plus an applicable margin of 1.5%. At July 2, 2018 the interest rate on the outstanding borrowings under the Term Loan Facility was 4.60%. There is no provision, other than an event of default, for the interest margin to increase. The Term Loan Facility will mature on September 28, 2024. The Term Loan Facility is secured by a significant amount of the domestic assets of the Company and a pledge of 65% of voting stock of the Company’s first tier foreign subsidiaries and is structurally senior to the Company’s Senior Notes and Convertible Senior Notes. See Senior Notes and Convertible Senior Notes below.
  (was, 2018-05-08, similarity 0.7288):
[0001564590-18-011836:note_history:33]
During the fiscal year 2017, the Company entered into a $350,000 Term Loan Facility due 2024. The Term Loan Facility, of which $3,500 is included in short-term debt and $344,750 is included in long-term debt, was issued at a discount at 99.5% and bears interest, at the Company’s option, at a floating rate of LIBOR, plus an applicable interest margin of 2.5%, or an alternate base rate, (defined as the greater of the JP Morgan prime, the New York Fed bank rate plus 0.9% or LIBOR plus 1.0%), subject to a 1.0% floor plus an applicable margin of 1.5%. At April 2, 2018 the interest rate on the outstanding borrowings under the Term Loan Facility was 4.38%. There is no provision, other than an event of default, for the interest margin to increase. The Term Loan Facility will mature on September 28, 2024. The Term Loan Facility is secured by a significant amount of the domestic assets of the Company and a pledge of 65% of voting stock of the Company’s first tier foreign subsidiaries and is structurally senior to the Company’s Senior Notes and Convertible Senior Notes. See Senior Notes and Convertible Senior Notes below.

- added (2018-08-09):
[0001564590-18-020718:note_history:34]
The Company is required to make scheduled payments of the outstanding Term Loan Facility on a quarterly basis beginning January 1, 2018. Subsequent to July 2, 2018, the Company made an optional debt principal prepayment of $40,000. As a result of the prepayment, the Company is no longer required to make any quarterly scheduled payments until October 2022. However, based on certain parameters defined in the Term Loan Facility, including a First Lien Leverage Ratio, the Company may be required to make an additional principal payment on an annual basis beginning after fiscal year 2018. Any remaining outstanding balance under the Term Loan Facility is due at the maturity date of September 28, 2024.

- changed (2018-08-09):
[0001564590-18-020718:note_history:35]
As of July 2, 2018 and January 1, 2018, the following summarizes the equity components of the convertible senior notes included in additional paid-in capital:
  (was, 2018-05-08, similarity 0.9766):
[0001564590-18-011836:note_history:35]
As of April 2, 2018 and January 1, 2018, the following summarizes the equity components of the convertible senior notes included in additional paid-in capital:

- changed (2018-08-09):
[0001564590-18-020718:note_history:36]
|  |  | As of July 2, 2018 and January 1, 2018 |  |
|  |  | Embedded conversion option — Convertible Senior Notes |  |  | Embedded conversion option — Convertible Senior Notes Issuance Costs |  |  | Total |  |
|  |  | (in thousands) |  |
| Convertible Senior Notes due 2020 |  | $ | 60,216 |  |  | $ | (1,916 | ) |  | $ | 58,300 |  |
  (was, 2018-05-08, similarity 0.9363):
[0001564590-18-011836:note_history:36]
|  |  | As of April 2, 2018 and January 1, 2018 |  |
|  |  | Embedded conversion option — Convertible Senior Notes |  |  | Embedded conversion option — Convertible Senior Notes Issuance Costs |  |  | Total |  |
|  |  | (in thousands) |  |
| Convertible senior notes due 2020 |  | $ | 60,216 |  |  | $ | (1,916 | ) |  | $ | 58,300 |  |

- changed (2018-08-09):
[0001564590-18-020718:note_history:37]
The components of interest expense resulting from the convertible senior notes for the quarter and two quarters ended July 2, 2018 and July 3, 2017 are as follows:
  (was, 2018-05-08, similarity 0.8986):
[0001564590-18-011836:note_history:37]
The components of interest expense resulting from the convertible senior notes for the quarters ended April 2, 2018 and April 3, 2017 are as follows:

- added (2018-08-09):
[0001564590-18-020718:note_history:38]
|  |  | Quarter Ended |  |  | Two Quarters Ended |  |
|  |  | July 2, |  |  | July 3, |  |  | July 2, |  |  | July 3, |  |
|  |  | 2018 |  |  | 2017 |  |  | 2018 |  |  | 2017 |  |
|  |  | (In thousands) |  |  | (In thousands) |  |
| Contractual coupon interest |  | $ | 1,093 |  |  | $ | 1,093 |  |  | $ | 2,187 |  |  | $ | 2,187 |  |
| Amortization of debt discount |  | $ | 2,267 |  |  | $ | 2,125 |  |  | $ | 4,497 |  |  | $ | 4,216 |  |
| Amortization of debt issuance costs |  | $ | 227 |  |  | $ | 214 |  |  | $ | 451 |  |  | $ | 423 |  |

- changed (2018-08-09):
[0001564590-18-020718:note_history:39]
The U.S. ABL consists of three tranches comprised of a revolving credit facility for up to $200,000, a letter of credit facility for up to $50,000, and swingline loans for up to $30,000, provided that at no time may amounts outstanding under the tranches exceed in aggregate $200,000 or the applicable borrowing base, which is a percentage of the principal amount of Eligible Accounts, as defined in the U.S. ABL agreement. Borrowings under the U.S. ABL bear interest at either a floating rate of LIBOR plus a margin of 150 basis points or JP Morgan Chase Bank’s prime rate plus a margin of 50 basis points, at the Company’s option. At July 2, 2018, the interest rate on the outstanding borrowings under the U.S. ABL was 3.60%. The applicable margin can vary based on the remaining availability of the facility, from 125 to 175 basis points for LIBOR-based loans and from 25 to 75 basis points for JP Morgan Chase Bank’s prime rate-based loans. Other than availability and an event of default, there are no other provisions for the interest margin to increase. The U.S. ABL will mature on May 31, 2020. Loans made under the U.S. ABL are secured first by all of the Company’s domestic cash, receivables and certain inventories as well as by a second position against a significant amount of the domestic assets of the Company and a pledge of 65% of the voting stock of the Company’s first tier foreign subsidiaries and are structurally senior to the Company’s Senior Notes and Convertible Senior Notes. See Senior Notes and Convertible Senior Notes above. At July 2, 2018, $40,000 of the U.S. ABL was outstanding and classified as long-term debt, which is consistent with its maturity date.
  (was, 2018-05-08, similarity 0.924):
[0001564590-18-011836:note_history:39]
The U.S. ABL consists of three tranches comprised of a revolving credit facility for up to $200,000, a letter of credit facility for up to $50,000, and swingline loans for up to $30,000, provided that at no time may amounts outstanding under the tranches exceed in aggregate $200,000 or the applicable borrowing base, which is a percentage of the principal amount of Eligible Accounts, as defined in the U.S. ABL agreement. Borrowings under the U.S. ABL bear interest at either a floating rate of LIBOR plus a margin of 125 basis points or JP Morgan Chase Bank’s prime rate plus a margin of 25 basis points, at the Company’s option. At April 2, 2018, the interest rate on the outstanding borrowings under the U.S. ABL was 3.13%. The applicable margin can vary based on the remaining availability of the facility, from 125 to 175 basis points for LIBOR-based loans and from 25 to 75 basis points for JP Morgan Chase Bank’s prime rate-based loans. Other than availability and an event of default, there are no other provisions for the interest margin to increase. The U.S. ABL will mature on May 31, 2020. Loans made under the U.S. ABL are secured first by all of the Company’s domestic cash, receivables and certain inventories as well as by a second position against a significant amount of the domestic assets of the Company and a pledge of 65% of the voting stock of the Company’s first tier foreign subsidiaries and are structurally senior to the Company’s Senior Notes and Convertible Senior Notes. See Senior Notes and Convertible Senior Notes above. At April 2, 2018, $17,000 of the U.S. ABL was outstanding and classified as long-term debt, which is consistent with its maturity date.

- changed (2018-08-09):
[0001564590-18-020718:note_history:40]
The Asia ABL consists of two tranches comprised of a revolving credit facility for up to $150,000 and a letter of credit facility for up to $100,000, provided that at no time may amounts outstanding under both tranches exceed in aggregate $150,000 or the applicable borrowing base, which is a percentage of the principal amount of Eligible Accounts, as defined in the Asia ABL agreement. Borrowings under the Asia ABL bear interest at a floating rate of LIBOR plus 140 basis points. At July 2, 2018, the interest rate on the outstanding borrowings under the Asia ABL was 3.50%. There is no provision, other than an event of default, for the interest margin to increase. The Asia ABL will mature on May 22, 2020. Loans made under the Asia ABL are secured by a portion of the Company’s Asia Pacific cash and receivables and are structurally senior to the Company’s domestic obligations, including the Senior Notes and Convertible Senior Notes. See Senior Notes and Convertible Senior Notes above. At July 2, 2018, $30,000 of the Asia ABL was outstanding and classified as long-term debt, which is consistent with its maturity date.
  (was, 2018-05-08, similarity 0.8903):
[0001564590-18-011836:note_history:40]
The Asia ABL consists of two tranches comprised of a revolving credit facility for up to $150,000 and a letter of credit facility for up to $100,000, provided that at no time may amounts outstanding under both tranches exceed in aggregate $150,000 or the applicable borrowing base, which is a percentage of the principal amount of Eligible Accounts, as defined in the Asia ABL agreement. Borrowings under the Asia ABL bear interest at a floating rate of LIBOR plus 140 basis points. At April 2, 2018, the interest rate on the outstanding borrowings under the Asia ABL was 3.28%. There is no provision, other than an event of default, for the interest margin to increase. The Asia ABL will mature on May 22, 2020. Loans made under the Asia ABL are secured by a portion of the Company’s Asia Pacific cash and receivables and are structurally senior to the Company’s domestic obligations, including the Senior Notes and Convertible Senior Notes. See Senior Notes and Convertible Senior Notes above. At April 2, 2018, $30,000 of the Asia ABL was outstanding and classified as long-term debt, which is consistent with its maturity date.

- changed (2018-08-09):
[0001564590-18-020718:note_history:41]
The Company has up to $50,000 and $100,000 Letters of Credit Facilities under the U.S. ABL and the Asia ABL, respectively. As of July 2, 2018, letters of credit in the amount of $6,137 were outstanding under the U.S. ABL and $13,469 were outstanding under the Asia ABL with various expiration dates through June 2019. Available borrowing capacity under the U.S. ABL and the Asia ABL was $153,863 and $106,531, respectively, which considers letters of credit outstanding at July 2, 2018.
  (was, 2018-05-08, similarity 0.9705):
[0001564590-18-011836:note_history:41]
The Company has up to $50,000 and $100,000 Letters of Credit Facilities under the U.S. ABL and the Asia ABL, respectively. As of April 2, 2018, letters of credit in the amount of $7,252 were outstanding under the U.S. ABL and $26,976 were outstanding under the Asia ABL with various expiration dates through June 2019. Available borrowing capacity under the U.S. ABL and the Asia ABL was $175,748 and $93,024, respectively, which considers letters of credit outstanding at April 2, 2018.

- added (2018-08-09):
[0001564590-18-020718:note_history:42]
The Company is required to pay a commitment fee of 0.25% to 0.375% per annum on any unused portion of the U.S. ABL or Asia ABL. The Company incurred total commitment fees related to unused borrowing availability of $247 and $180 for the quarters ended July 2, 2018 and July 3, 2017, respectively, and $488 and $367 for the two quarters ended July 2, 2018 and July 3, 2017, respectively. Under the occurrence of certain events, the ABL Revolving Loans are subject to various financial and operational covenants, including maintaining minimum fixed charge coverage ratios.

- changed (2018-08-09):
[0001564590-18-020718:note_history:43]
Additionally, the Company is party to a revolving loan credit facility (Chinese Revolver) with a lender in China. Under this arrangement, the lender has made available to the Company approximately $31,700 in unsecured borrowing with all terms of the borrowing to be negotiated at the time the Chinese Revolver is drawn upon. There are no commitment fees on the unused portion of the Chinese Revolver, and this arrangement expires in January 2019. As of July 2, 2018, the Chinese Revolver had not been drawn upon.
  (was, 2018-05-08, similarity 0.991):
[0001564590-18-011836:note_history:43]
Additionally, the Company is party to a revolving loan credit facility (Chinese Revolver) with a lender in China. Under this arrangement, the lender has made available to the Company approximately $33,400 in unsecured borrowing with all terms of the borrowing to be negotiated at the time the Chinese Revolver is drawn upon. There are no commitment fees on the unused portion of the Chinese Revolver, and this arrangement expires in January 2019. As of April 2, 2018, the Chinese Revolver had not been drawn upon.

- changed (2018-08-09):
[0001564590-18-020718:note_history:44]
As of July 2, 2018 and January 1, 2018, remaining unamortized debt discount and debt issuance costs for the Term Loan Facility, Senior Notes and Convertible Senior Notes are as follows:
  (was, 2018-05-08, similarity 0.9802):
[0001564590-18-011836:note_history:44]
As of April 2, 2018 and January 1, 2018, remaining unamortized debt discount and debt issuance costs for the Term Loan Facility, Senior Notes and Convertible Senior Notes are as follows:

- changed (2018-08-09):
[0001564590-18-020718:note_history:45]
|  |  | As of July 2, 2018 |  |  | As of January 1, 2018 |  |
|  |  | Debt Issuance Costs |  |  | Debt Discount |  |  | Effective Interest Rate |  |  | Debt Issuance Costs |  |  | Debt Discount |  |  | Effective Interest Rate |  |
|  |  | (in thousands) |  |
| Term Loan due September 2024 |  | $ | 10,037 |  |  | $ | 3,037 |  |  | 4.66% |  |  | $ | 2,788 |  |  | $ | 1,691 |  |  | 3.96% |  |
| Senior Notes due October 2025 |  |  | 6,432 |  |  | — |  |  | 5.92% |  |  |  | 6,782 |  |  | — |  |  | 5.92% |  |
| Convertible Senior Notes |  |  | 2,438 |  |  |  | 24,322 |  |  | 6.48% |  |  |  | 2,889 |  |  |  | 28,822 |  |  | 6.48% |  |
|  |  | $ | 18,907 |  |  | $ | 27,359 |  |  |  |  |  |  | $ | 12,459 |  |  | $ | 30,513 |  |  |  |  |  |
  (was, 2018-05-08, similarity 0.7676):
[0001564590-18-011836:note_history:45]
|  |  | As of April 2, 2018 |  |  | As of January 1, 2018 |  |
|  |  | Debt Issuance Costs |  |  | Debt Discount |  |  | Effective Interest Rate |  |  | Debt Issuance Costs |  |  | Debt Discount |  |  | Effective Interest Rate |  |
|  |  | (in thousands) |  |
| Term Loan due September 2024 |  | $ | 2,695 |  |  | $ | 1,636 |  |  |  | 3.96 | % |  | $ | 2,788 |  |  | $ | 1,691 |  |  |  | 3.96 | % |
| Senior Notes due October 2025 |  |  | 6,608 |  |  | — |  |  |  | 5.92 | % |  |  | 6,782 |  |  | — |  |  |  | 5.92 | % |
| Convertible Senior Notes |  |  | 2,665 |  |  |  | 26,589 |  |  |  | 6.48 | % |  |  | 2,889 |  |  |  | 28,822 |  |  |  | 6.48 | % |
|  |  | $ | 11,968 |  |  | $ | 28,225 |  |  |  |  |  |  | $ | 12,459 |  |  | $ | 30,513 |  |  |  |  |  |

- changed (2018-08-09):
[0001564590-18-020718:note_history:46]
Remaining unamortized debt issuance costs for the ABL Revolving Loans of $1,921 and $2,421 as of July 2, 2018 and January 1, 2018, respectively, are included in other non-current assets and are amortized to interest expense over the duration of the ABL Revolving Loans using the straight line method of amortization.
  (was, 2018-05-08, similarity 0.985):
[0001564590-18-011836:note_history:46]
Remaining unamortized debt issuance costs for the ABL Revolving Loans of $2,171 and $2,421 as of April 2, 2018 and January 1, 2018, respectively, are included in other non-current assets and are amortized to interest expense over the duration of the ABL Revolving Loans using the straight line method of amortization.

- changed (2018-08-09):
[0001564590-18-020718:note_history:47]
At July 2, 2018, the remaining weighted average amortization period for all unamortized debt discount and debt issuance costs was 4.1 years.
  (was, 2018-05-08, similarity 0.9738):
[0001564590-18-011836:note_history:47]
At April 2, 2018, the remaining weighted average amortization period for all unamortized debt discount and debt issuance costs was 3.8 years.

- removed (2018-08-09):
[0001564590-18-011836:note_history:48]
The Company is required to make scheduled payments of the outstanding Term Loan Facility on a quarterly basis beginning January 1, 2018. Based on certain parameters defined in the Term Loan Facility, including a First Lien Leverage Ratio, the Company may be required to make an additional principal payment on an annual basis beginning after fiscal year 2018, if the Company’s First Lien Leverage Ratio is greater than 2.0. Any additional annual payments or prepayments would reduce future required scheduled payments. Any remaining outstanding balance under the Term Loan Facility are due at the maturity date of September 28, 2024.

- removed (2018-08-09):
[0001564590-18-011836:note_history:49]
|  |  | Quarter Ended |  |
|  |  | April 2, |  |  | April 3, |  |
|  |  | 2018 |  |  | 2017 |  |
|  |  | (In thousands) |  |
| Contractual coupon interest |  | $ | 1,094 |  |  | $ | 1,094 |  |
| Amortization of debt discount |  | $ | 2,230 |  |  | $ | 2,091 |  |
| Amortization of debt issuance costs |  | $ | 224 |  |  | $ | 209 |  |

- removed (2018-08-09):
[0001564590-18-011836:note_history:50]
The Company is required to pay a commitment fee of 0.25% to 0.375% per annum on any unused portion of the U.S. ABL or Asia ABL. The Company incurred total commitment fees related to unused borrowing availability of $241 and $187 for the quarters ended April 2, 2018 and April 3, 2017, respectively. Under the occurrence of certain events, the ABL Revolving Loans are subject to various financial and operational covenants, including maintaining minimum fixed charge coverage ratios.


## us-gaap:ScheduleOfDebtInstrumentsTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2018-08-09):
[0001564590-18-020718:note_history:51]
The following table summarizes the long-term debt of the Company as of July 2, 2018 and January 1, 2018:
  (was, 2018-05-08, similarity 0.9637):
[0001564590-18-011836:note_history:51]
The following table summarizes the long-term debt of the Company as of April 2, 2018 and January 1, 2018:

- changed (2018-08-09):
[0001564590-18-020718:note_history:52]
|  |  | Interest Rate as of July 2, 2018 |  |  | Principal Outstanding as of July 2, 2018 |  |  | Interest Rate as of January 1, 2018 |  |  | Principal Outstanding as of January 1, 2018 |  |
|  |  | (In thousands) |  |
| Term Loan due September 2024 |  | 4.60% |  |  | $ | 945,879 |  |  | 4.06% |  |  | $ | 349,125 |  |
| Senior Notes due October 2025 |  | 5.63% |  |  |  | 375,000 |  |  | 5.63% |  |  |  | 375,000 |  |
| Convertible Senior Notes due December 2020 |  | 1.75% |  |  |  | 249,985 |  |  | 1.75% |  |  |  | 249,985 |  |
| U.S. ABL Revolving Loan due May 2020 |  | 3.60% |  |  |  | 40,000 |  |  | 3.06% |  |  |  | 17,000 |  |
| Asia ABL Revolving Loan due May 2020 |  | 3.50% |  |  |  | 30,000 |  |  | 2.96% |  |  |  | 30,000 |  |
| Capital Lease |  | 6.43% |  |  |  | 1,556 |  |  | 6.43% |  |  |  | 1,919 |  |
|  |  |  |  |  |  |  | 1,642,420 |  |  |  |  |  |  |  | 1,023,029 |  |
| Less: Long-term debt unamortized discount |  |  |  |  |  |  | (27,359 | ) |  |  |  |  |  |  | (30,513 | ) |
| Long-term debt unamortized debt issuance costs |  |  |  |  |  |  | (18,907 | ) |  |  |  |  |  |  | (12,459 | ) |
|  |  |  |  |  |  |  | 1,596,154 |  |  |  |  |  |  |  | 980,057 |  |
| Less: current maturities |  |  |  |  |  |  | (40,729 | ) |  |  |  |  |  |  | (4,578 | ) |
| Long-term debt, less current maturities |  |  |  |  |  | $ | 1,555,425 |  |  |  |  |  |  | $ | 975,479 |  |
  (was, 2018-05-08, similarity 0.9807):
[0001564590-18-011836:note_history:52]
|  |  | Interest Rate as of April 2, 2018 |  |  | Principal Outstanding as of April 2, 2018 |  |  | Interest Rate as of January 1, 2018 |  |  | Principal Outstanding as of January 1, 2018 |  |
|  |  | (In thousands) |  |
| Term Loan due September 2024 |  | 4.38% |  |  | $ | 348,250 |  |  | 4.06% |  |  | $ | 349,125 |  |
| Senior Notes due October 2025 |  | 5.63% |  |  |  | 375,000 |  |  | 5.63% |  |  |  | 375,000 |  |
| Convertible Senior Notes due December 2020 |  | 1.75% |  |  |  | 249,985 |  |  | 1.75% |  |  |  | 249,985 |  |
| U.S. ABL Revolving Loan due May 2020 |  | 3.13% |  |  |  | 17,000 |  |  | 3.06% |  |  |  | 17,000 |  |
| Asia ABL Revolving Loan due May 2020 |  | 3.28% |  |  |  | 30,000 |  |  | 2.96% |  |  |  | 30,000 |  |
| Capital Lease |  | 6.43% |  |  |  | 1,987 |  |  | 6.43% |  |  |  | 1,919 |  |
|  |  |  |  |  |  |  | 1,022,222 |  |  |  |  |  |  |  | 1,023,029 |  |
| Less: Long-term debt unamortized discount |  |  |  |  |  |  | (28,225 | ) |  |  |  |  |  |  | (30,513 | ) |
| Long-term debt unamortized debt issuance costs |  |  |  |  |  |  | (11,968 | ) |  |  |  |  |  |  | (12,459 | ) |
|  |  |  |  |  |  |  | 982,029 |  |  |  |  |  |  |  | 980,057 |  |
| Less: current maturities |  |  |  |  |  |  | (4,616 | ) |  |  |  |  |  |  | (4,578 | ) |
| Long-term debt, less current maturities |  |  |  |  |  | $ | 977,413 |  |  |  |  |  |  | $ | 975,479 |  |


## us-gaap:RelatedPartyTransactionsDisclosureTextBlock (related_parties) — matched_by: tag_name, score: 1.0

- added (2018-08-09):
[0001564590-18-020718:note_history:53]
In the normal course of business, the Company’s foreign subsidiaries purchase laminate and prepreg from related parties in which a member of the Board of Directors of the Company holds an equity interest. The Company’s foreign subsidiaries purchased laminate and prepreg from these related parties in the amount of $12,550 and $12,121 for the quarters ended July 2, 2018 and July 3, 2017, respectively, and $38,257 and $25,611 for the two quarters ended July 2, 2018 and July 3, 2017, respectively.

- changed (2018-08-09):
[0001564590-18-020718:note_history:54]
As of July 2, 2018 and January 1, 2018, the Company’s consolidated condensed balance sheets included $15,256 and $14,452, respectively, in accounts payable due to related parties primarily for purchases of laminate and prepreg and such balances are included as a component of accounts payable on the consolidated condensed balance sheets.
  (was, 2018-05-08, similarity 0.9576):
[0001564590-18-011836:note_history:54]
As of April 2, 2018 and January 1, 2018, the Company’s consolidated condensed balance sheets included $16,095 and $14,452, respectively, in accounts payable due to related parties primarily for purchases of laminate and prepreg and such balances are included as a component of accounts payable on the consolidated condensed balance sheets.

- removed (2018-08-09):
[0001564590-18-011836:note_history:55]
In the normal course of business, the Company’s foreign subsidiaries purchase laminate and prepreg from related parties in which a significant shareholder of the Company holds an equity interest. For the quarters ended April 2, 2018 and April 3, 2017, the Company’s foreign subsidiaries purchased $12,708 and $13,540, respectively, of laminate and prepreg from these related parties.


## us-gaap:RevenueRecognitionPolicyTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- added (2018-08-09):
[0001564590-18-020718:note_history:56]
The Company derives revenues primarily from the sale of PCBs, custom electronic assemblies using customer-supplied engineering and design plans.  With the acquisition of Anaren Inc. (See Note 3), the Company now also derives revenue from the design, development, and manufacture of components, assemblies, and subsystems which receive, process, and transmit microwave and RF signals which service the aerospace and defense electronics, and wireless communications markets.

- changed (2018-08-09):
[0001564590-18-020718:note_history:57]
The Company has three revenue streams which generally coincide with the Company’s reportable segments. These reportable segments are: PCB, E-M Solutions and Anaren.  See Note 17 Segment Information.
  (was, 2018-05-08, similarity 0.8163):
[0001564590-18-011836:note_history:57]
The Company has two revenue streams which coincide with the Company’s reportable segments of PCB and E-M Solutions. See Note 14 Segment Information.

- added (2018-08-09):
[0001564590-18-020718:note_history:58]
For the PCBs and custom electronic assemblies, orders for products generally correspond to the production schedules of the Company’s customers and are supported with firm purchase orders. The Company’s customers have continuous transfer of control of the work in progress and finished goods throughout the PCB manufacturing process, as PCBs are built to customer specifications and do not have an alternative use. The customer typically controls the work in progress and finished goods as evidenced either by contractual termination clauses or by the Company’s rights to payment for work performed to date, plus a reasonable profit.  As a result, the Company records revenue in accordance with the “over time” revenue standard as discussed in Note 1 Nature of Operations and Basis of Presentation ─ Recently Adopted and Issued Accounting Standards, beginning in the first quarter of 2018, the Company now recognizes revenue progressively over time based on the extent of progress towards completion of the performance obligation.

- added (2018-08-09):
[0001564590-18-020718:note_history:59]
Additionally, the Company has certain long-term contracts related to its manufacture of components, assemblies, and subsystems which service the aerospace and defense electronics market. These long-term contracts, many of which provide for periodic payments, are recognized over time under the percentage-of completion method. Estimated manufacturing cost-at-completion for these contracts are reviewed on a periodic basis, and adjustments are made periodically to the estimated cost-at-completion, based on actual costs incurred, progress made, and estimates of costs required to complete the contractual requirements. When the estimated manufacturing cost-at-completion exceeds the contract value, the contract is written down to its net realizable value and the loss resulting from the cost overruns are immediately recognized.

- added (2018-08-09):
[0001564590-18-020718:note_history:60]
Finally, the Company manufactures components, assemblies, and subsystems which service its wireless communications customers. The Company recognizes revenue at a point in time as the customer does not simultaneously receive or consume the benefits provided by the Company’s performance and the asset being manufactured has alternative uses to the Company.

- changed (2018-08-09):
[0001564590-18-020718:note_history:61]
The Company provides customers a limited right of return for defective PCBs, assemblies, components and subsystems. The Company accrues an estimate for sales returns and allowances progressively over time based on the extent of progress towards completion of the performance obligation using the Company’s judgment based on historical results and anticipated returns.  To the extent actual experience varies from its historical experience, revisions to the sales returns and allowances accrual may be required. Sales returns and allowances are recorded as a reduction of revenue and included as a component of accrued liabilities on the condensed consolidated balance sheet.
  (was, 2018-05-08, similarity 0.9489):
[0001564590-18-011836:note_history:61]
The Company provides customers a limited right of return for defective PCBs and backplane assemblies. The Company accrues an estimate for sales returns and allowances progressively over time based on the extent of progress towards completion of the performance obligation using the Company’s judgment based on historical results and anticipated returns.  To the extent actual experience varies from our historical experience, revisions to the sales returns and allowances accrual may be required. Sales returns and allowances are recorded as a reduction of revenue and included as a component of accrued liabilities on the condensed consolidated balance sheet.

- removed (2018-08-09):
[0001564590-18-011836:note_history:62]
The Company derives revenues primarily from the sale of PCBs and custom electronic assemblies using customer-supplied engineering and design plans. Orders for products generally correspond to the production schedules of the Company’s customers and are supported with firm purchase orders. The Company’s customers have continuous transfer of control of the work in progress and finished goods as PCBs are being manufactured, as PCBs are built to customer specifications and do not have an alternative use. The customer typically controls the work in progress and finished goods as evidenced either by contractual termination clauses or by the Company’s rights to payment for work performed to date, plus a reasonable profit.  As a result, in light of the Company’s adoption of the “over time” revenue standard as discussed in Note 1 Nature of Operations and Basis of Presentation─Recently Adopted and Issued Accounting Standards, beginning in the first quarter of 2018, the Company now recognizes revenue progressively over time based on the extent of progress towards completion of the performance obligation.


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: no_current_note, score: 0.0

- removed (2018-08-09):
[0001564590-18-011836:note_history:63]
(16) Subsequent Event

- removed (2018-08-09):
[0001564590-18-011836:note_history:64]
On April 18, 2018, the Company completed its acquisition of all of the issued and outstanding common stock of Anaren Holding Corp. for total consideration of $775,000 in cash subject to customary working capital and certain other adjustments. Other than the equity interests of Anaren, Inc. (Anaren), Anaren Holding Corp. has no material assets or liabilities and has no material independent operations. Anaren is a leading provider of mission-critical radio frequency (RF) solutions, microelectronics, and microwave components and assemblies for the wireless infrastructure and space and defense electronics markets.

- removed (2018-08-09):
[0001564590-18-011836:note_history:65]
Additionally, the Company closed its $600,000 commitment of incremental loans concurrent with the completion of its acquisition of Anaren. The Company used the proceeds of the incremental loan, along with cash on hand to fund the purchase price of the Anaren acquisition and to pay related fees and expenses.

- removed (2018-08-09):
[0001564590-18-011836:note_history:66]
The acquisition will be accounted for using the acquisition method; however the accounting was incomplete at the time these financial statements were issued. As a result, the purchase price allocation and pro-forma income statement disclosures have not been provided. The first periodic report that will include results of operations for Anaren will be the Company’s Form 10-Q for the quarter ended July 2, 2018.
