# TTMI 8-K — 0001193125-17-162548 filed 2017-05-08

## item codes, every 8-K on or before 2017-05-11

- 2017-05-08 0001193125-17-162548 — 2.02, 9.01
- 2017-03-01 0001193125-17-063931 — 1.01, 1.02, 5.02
- 2017-02-08 0001193125-17-034652 — 2.02, 9.01
- 2016-11-18 0001193125-16-772305 — 8.01, 9.01
- 2016-10-26 0001193125-16-747948 — 2.02, 9.01
- 2016-10-20 0001193125-16-742905 — 5.02
- 2016-10-05 0001193125-16-731552 — 5.02, 9.01
- 2016-09-27 0001193125-16-720828 — 1.01, 2.03, 7.01, 9.01
- 2016-07-27 0001193125-16-659983 — 2.02, 9.01
- 2016-05-23 0001193125-16-599342 — 7.01, 9.01
- 2016-05-18 0001193125-16-594656 — 5.02, 5.03, 5.07, 9.01
- 2016-04-27 0001171843-16-009432 — 2.02, 9.01
- 2016-03-08 0001193125-16-495457 — 5.03, 7.01, 9.01
- 2016-02-09 0001193125-16-454281 — 8.01, 9.01
- 2016-02-04 0001171843-16-007659 — 2.02, 9.01
- 2016-01-04 0001193125-16-418740 — 1.01, 9.01
- 2015-12-11 0001193125-15-400867 — 5.02, 9.01
- 2015-10-30 0001171843-15-005835 — 2.02, 7.01 — amendment of 0001171843-15-005766
- 2015-10-28 0001171843-15-005766 — 2.02, 9.01
- 2015-09-29 0001193125-15-331517 — 2.02, 2.05, 2.06, 9.01
- 2015-08-05 0001171843-15-004361 — 2.02, 9.01
- 2015-07-31 0001193125-15-272962 — 9.01 — amendment of 0001193125-15-210734
- 2015-06-02 0001193125-15-210734 — 1.01, 1.02, 2.01, 2.03, 7.01, 9.01
- 2015-05-29 0001193125-15-206622 — 1.01, 2.03, 9.01
- 2015-05-20 0001171843-15-002975 — 7.01, 9.01
- 2015-05-19 0001193125-15-193434 — 5.07, 9.01
- 2015-05-05 0001171843-15-002499 — 7.01, 9.01
- 2015-04-29 0001171843-15-002307 — 2.02, 9.01
- 2015-04-21 0001193125-15-139239 — 7.01, 9.01
- 2015-04-21 0001171843-15-002065 — 2.02, 9.01
- 2015-02-04 0001171843-15-000599 — 2.02, 9.01
- 2015-01-20 0001193125-15-014019 — 7.01, 9.01
- 2014-12-30 0001193125-14-457111 — 7.01, 9.01
- 2014-12-15 0001193125-14-442645 — 1.01, 9.01
- 2014-12-04 0001193125-14-433658 — 8.01, 9.01
- 2014-11-18 0001193125-14-415889 — 7.01, 9.01
- 2014-10-29 0001171843-14-005051 — 2.02, 9.01
- 2014-10-27 0001193125-14-383428 — 1.01, 9.01
- 2014-09-22 0001193125-14-348697 — 1.01, 7.01, 9.01
- 2014-08-05 0001193125-14-295808 — 1.01, 5.02, 9.01
- 2014-07-30 0001171843-14-003548 — 2.02, 9.01
- 2014-04-30 0001171843-14-002017 — 2.02, 9.01
- 2014-04-25 0001193125-14-160146 — 5.02, 5.07, 9.01
- 2014-04-10 0001171843-14-001656 — 2.02, 9.01
- 2014-03-04 0001193125-14-082534 — 4.01, 9.01
- 2014-02-05 0001171843-14-000553 — 2.02, 9.01
- 2014-01-14 0001193125-14-010922 — 1.01, 2.03, 3.02, 8.01, 9.01
- 2013-12-27 0001193125-13-486144 — 5.02, 9.01
- 2013-12-20 0001193125-13-481141 — 1.01, 1.02, 2.03, 3.02, 8.01, 9.01
- 2013-12-17 0001193125-13-476207 — 5.03
- 2013-10-30 0001193125-13-418572 — 2.02, 5.02, 9.01
- 2013-09-12 0001193125-13-365420 — 2.05
- 2013-08-14 0001193125-13-334349 — 7.01, 9.01
- 2013-08-01 0001171843-13-003138 — 2.02, 9.01
- 2013-06-25 0001193125-13-270725 — 5.02, 9.01
- 2013-05-02 0001171843-13-001746 — 2.02, 9.01
- 2013-04-29 0001193125-13-182083 — 5.02, 5.07, 9.01
- 2013-03-18 0001193125-13-111308 — 1.01, 7.01, 9.01
- 2013-03-06 0001193125-13-093625 — 5.02, 9.01
- 2013-03-01 0001193125-13-087439 — 2.02 — amendment of 0001171843-13-000414
- 2013-02-28 0001193125-13-084764 — 5.02
- 2013-02-05 0001171843-13-000414 — 2.02, 9.01
- 2013-01-31 0001193125-13-032848 — 5.02, 9.01
- 2013-01-17 0001193125-13-015928 — 7.01, 9.01
- 2013-01-16 0001193125-13-014581 — 2.02, 9.01
- 2012-12-11 0001193125-12-498644 — 5.02, 9.01
- 2012-11-15 0001193125-12-472451 — 7.01, 9.01
- 2012-11-01 0001171843-12-003890 — 2.02, 9.01
- 2012-09-19 0001193125-12-396969 — 1.01, 2.03, 7.01, 9.01
- 2012-09-11 0001193125-12-388130 — 7.01, 9.01
- 2012-07-31 0001171843-12-002829 — 2.02, 9.01
- 2012-05-15 0001193125-12-233501 — 7.01, 9.01
- 2012-05-01 0001171843-12-001574 — 2.02, 9.01
- 2012-04-27 0001193125-12-191623 — 5.07
- 2012-03-01 0001193125-12-090623 — 2.02 — amendment of 0001171843-12-000382
- 2012-02-07 0001171843-12-000382 — 2.02, 9.01
- 2012-01-19 0001193125-12-016588 — 5.02, 9.01
- 2011-11-15 0000950123-11-098812 — 7.01, 9.01
- 2011-11-02 0001171843-11-003248 — 2.02, 9.01
- 2011-09-28 0000950123-11-087344 — 7.01, 9.01
- 2011-09-19 0000950123-11-085128 — 5.02, 9.01
- 2011-09-15 0000950123-11-084704 — 5.07 — amendment of 0000950123-11-054296
- 2011-08-04 0001171843-11-002356 — 2.02, 9.01
- 2011-07-27 0000950123-11-068987 — 1.01, 2.03, 9.01
- 2011-06-21 0000950123-11-060477 — 7.01, 9.01
- 2011-06-06 0000950123-11-056971 — 5.03, 9.01
- 2011-05-26 0000950123-11-054296 — 5.07
- 2011-05-10 0000950123-11-048462 — 8.01, 9.01
- 2011-05-05 0001171843-11-001344 — 2.02, 9.01
- 2011-03-22 0000950123-11-027824 — 7.01, 9.01
- 2011-03-18 0000950123-11-026913 — 4.01
- 2011-03-18 0000950123-11-026910 — 4.01, 9.01 — amendment, the index does not say of what
- 2011-03-02 0000950123-11-020941 — 5.03, 9.01
- 2011-02-10 0001171843-11-000391 — 2.02, 9.01
- 2011-01-13 0000950123-11-002528 — 7.01, 9.01
- 2011-01-13 0000950123-11-002446 — 2.02, 9.01
- 2010-11-29 0000950123-10-109448 — 4.01, 9.01 — amendment, the index does not say of what
- 2010-11-17 0000950123-10-106706 — 4.01
- 2010-11-15 0000950123-10-105479 — 5.02, 9.01
- 2010-11-04 0001171843-10-002324 — 2.02, 9.01
- 2010-10-22 0000950123-10-095179 — 1.01, 9.01
- 2010-10-04 0000950123-10-090949 — 1.01, 5.03, 9.01
- 2010-08-05 0001171843-10-001587 — 2.02, 9.01
- 2010-08-05 0000950123-10-073258 — 1.01, 2.03, 9.01
- 2010-08-05 0000950123-10-073256 — 9.01 — amendment of 0000950123-10-034163
- 2010-07-12 0000950123-10-064794 — 5.02, 8.01, 9.01
- 2010-06-10 0000950123-10-057166 — 7.01, 9.01
- 2010-06-02 0000950123-10-055111 — 1.01, 5.07, 9.01
- 2010-05-06 0001171843-10-000819 — 2.02, 9.01
- 2010-04-26 0000950123-10-037806 — 8.01, 9.01 — amendment of 0000950123-10-034163
- 2010-04-13 0000950123-10-034163 — 1.01, 2.01, 2.03, 5.02, 7.01, 9.01
- 2010-03-30 0000950123-10-030123 — 1.01, 5.02, 9.01
- 2010-03-24 0000950123-10-027317 — 1.01, 5.02, 9.01
- 2010-03-16 0000950123-10-024853 — 7.01, 9.01 — amendment of 0001171843-10-000140
- 2010-03-15 0000950123-10-024637 — 5.07
- 2010-02-04 0001171843-10-000140 — 2.02, 9.01
- 2010-02-02 0000950123-10-007780 — 8.01, 9.01
- 2010-01-13 0000950123-10-002245 — 7.01, 9.01
- 2009-12-23 0000950123-09-073069 — 1.01, 9.01
- 2009-12-15 0000950123-09-070868 — 8.01, 9.01
- 2009-11-16 0000950123-09-062630 — 1.01, 7.01, 9.01
- 2009-11-04 0001171843-09-001103 — 2.02, 9.01
- 2009-09-04 0000950123-09-041133 — 2.05, 9.01
- 2009-07-29 0001171843-09-000743 — 2.02, 9.01
- 2009-06-09 0000950123-09-012507 — 7.01, 9.01
- 2009-04-30 0001171843-09-000427 — 2.02, 9.01
- 2009-04-28 0001362310-09-005960 — 8.01
- 2009-02-19 0001362310-09-002454 — 5.03, 9.01
- 2009-02-10 0001171843-09-000123 — 2.02, 9.01
- 2009-01-16 0000950153-09-000040 — 2.05, 9.01
- 2009-01-08 0000950153-09-000023 — 7.01, 9.01
- 2008-10-29 0001157523-08-008533 — 2.02, 9.01
- 2008-07-29 0001157523-08-005998 — 2.02, 9.01
- 2008-05-22 0000950153-08-001035 — 1.01, 2.03, 3.02, 9.01
- 2008-05-22 0000950153-08-001034 — 7.01, 9.01
- 2008-05-15 0000950153-08-000987 — 1.01, 1.02, 2.03, 3.02, 9.01
- 2008-04-30 0001157523-08-003483 — 2.02, 9.01
- 2008-02-07 0001157523-08-001077 — 2.02, 9.01
- 2008-01-08 0000950153-08-000033 — 7.01, 9.01
- 2007-11-15 0000950153-07-002440 — 7.01, 9.01
- 2007-11-14 0000950153-07-002426 — 7.01, 9.01
- 2007-11-14 0000950153-07-002421 — 5.03, 9.01
- 2007-10-31 0001157523-07-010491 — 2.02, 9.01
- 2007-10-02 0000950153-07-002094 — 7.01, 9.01
- 2007-07-31 0000950153-07-001622 — 2.02, 9.01
- 2007-06-13 0000950153-07-001327 — 7.01, 9.01
- 2007-05-02 0000950153-07-000941 — 2.02, 9.01
- 2007-04-12 0000950153-07-000763 — 5.02, 9.01
- 2007-02-15 0000950153-07-000339 — 2.02, 9.01
- 2007-01-11 0000950153-07-000076 — 7.01, 9.01
- 2007-01-10 0000950153-07-000071 — 2.01, 9.01 — amendment, the index does not say of what
- 2006-12-11 0000950153-06-002967 — 2.05, 9.01
- 2006-11-15 0000950153-06-002843 — 7.01, 9.01
- 2006-11-14 0000950153-06-002837 — 7.01, 9.01
- 2006-11-02 0000950153-06-002682 — 1.01, 1.02, 2.03, 9.01
- 2006-11-01 0000950153-06-002668 — 2.02, 9.01
- 2006-10-30 0000950124-06-006210 — 2.01, 9.01
- 2006-08-04 0000950153-06-002025 — 1.01, 9.01
- 2006-07-26 0000950153-06-001937 — 2.02, 9.01
- 2006-06-28 0000950153-06-001716 — 1.01, 9.01
- 2006-06-13 0000950153-06-001597 — 7.01, 9.01
- 2006-04-26 0000950153-06-001079 — 2.02, 9.01
- 2006-02-08 0001104659-06-006985 — 2.02, 9.01
- 2006-01-12 0001104659-06-001893 — 7.01, 9.01
- 2005-12-05 0001104659-05-058918 — 1.01, 5.02, 9.01
- 2005-10-26 0001104659-05-050306 — 2.02, 9.01
- 2005-09-20 0001104659-05-044954 — 8.01
- 2005-08-30 0001104659-05-042053 — 3.03, 8.01, 9.01
- 2005-07-27 0001104659-05-034437 — 2.02, 5.02, 9.01
- 2005-07-21 0001104659-05-033462 — 1.01, 1.02, 2.03, 9.01
- 2005-06-13 0001104659-05-027969 — 8.01
- 2005-06-08 0001104659-05-027364 — 7.01, 9.01
- 2005-05-17 0001104659-05-024118 — 7.01, 9.01
- 2005-05-12 0001104659-05-022993 — 7.01, 9.01
- 2005-05-11 0001104659-05-022606 — 1.01, 9.01
- 2005-05-02 0001104659-05-019649 — 2.02, 5.02, 9.01
- 2005-04-26 0001104659-05-018233 — 7.01, 9.01
- 2005-02-08 0001104659-05-004642 — 2.02, 9.01
- 2005-01-12 0001104659-05-001194 — 7.01, 9.01
- 2004-12-22 0001104659-04-040933 — 5.02
- 2004-12-08 0001104659-04-038850 — 7.01, 9.01
- 2004-10-26 0001104659-04-031931 — 2.02, 9.01
- 2004-10-01 0001104659-04-029361 — 5.02
- 2004-08-02 0001104659-04-021785 — 9
- 2004-07-29 0001104659-04-021529 — 12
- 2004-05-06 0001104659-04-012742 — 9
- 2004-04-26 0001104659-04-011228 — 12
- 2004-02-03 0001104659-04-002424 — 9
- 2004-01-28 0001104659-04-001980 — 12
- 2004-01-09 0001104659-04-000457 — 9
- 2003-10-21 0001104659-03-023304 — 12
- 2003-07-29 0001104659-03-015999 — 12
- 2003-05-08 0001104659-03-008647 — 9
- 2003-05-08 0001104659-03-008462 — 9
- 2003-05-01 0001104659-03-007866 — 9
- 2003-03-07 0001104659-03-003816 — 2, 7 — amendment of 0000950153-02-002190
- 2002-12-27 0000950153-02-002190 — 2, 7
- 2002-05-17 0000912057-02-021145 — 4, 7
- 2001-12-21 0000912057-01-544281 — 7
- 2000-10-27 0000912057-00-046109 — 5

## late-filing notifications on or before 2017-05-11

- none on or before 2017-05-11

## item 2.02 — earnings release, exhibit 99.1

[0001193125-17-162548:8k_2_02:1]
EX-99.1
2
d388396dex991.htm
EX-99.1

[0001193125-17-162548:8k_2_02:2]
EX-99.1

[0001193125-17-162548:8k_2_02:3]
Exhibit 99.1

[0001193125-17-162548:8k_2_02:4]
| TTM Technologies, Inc., Q1’17 |  | Contact: Sameer Desai, Senior Director, Corporate Development & Investor Relations sameer.desai@ttmtech.com 714-327-3050 |

[0001193125-17-162548:8k_2_02:5]
TTM Technologies, Inc. Reports Fiscal First Quarter 2017 Results

[0001193125-17-162548:8k_2_02:6]
Broad Based Growth Drives Results to the High End of Guidance

[0001193125-17-162548:8k_2_02:7]
COSTA MESA, CA – May 3rd, 2017 – TTM Technologies, Inc. (NASDAQ:TTMI), a leading global printed circuit board (“PCB”) manufacturer, today
reported results for the first quarter of fiscal 2017, which ended April 3rd, 2017.

[0001193125-17-162548:8k_2_02:8]
First Quarter 2017 Highlights

[0001193125-17-162548:8k_2_02:9]
|  | • |  | Net sales were $625.2 million |

[0001193125-17-162548:8k_2_02:10]
|  | • |  | GAAP net income attributable to stockholders was $33 million, or $0.28 per diluted share |

[0001193125-17-162548:8k_2_02:11]
|  | • |  | Non-GAAP net income attributable to stockholders was $39.2 million, or $0.37 per diluted share |

[0001193125-17-162548:8k_2_02:12]
|  | • |  | Adjusted EBITDA was $95.6 million |

[0001193125-17-162548:8k_2_02:13]
First Quarter 2017 Financial Results

[0001193125-17-162548:8k_2_02:14]
Net sales for the first quarter of 2017 were $625.2 million, compared to $583.3 million in the first quarter of 2016 and $706.5 million in the
fourth quarter of 2016.

[0001193125-17-162548:8k_2_02:15]
GAAP operating income for the first quarter of 2017 was $52.6 million, compared to $18.9 million in the first quarter
of 2016 and $69.6 million in the fourth quarter of 2016.

[0001193125-17-162548:8k_2_02:16]
GAAP net income attributable to stockholders for the first quarter of 2017 was
$33 million, or $0.28 per diluted share. This compares to a GAAP net loss attributable to stockholders of $7.3 million, or $0.07 per share, in the first quarter of 2016 and a GAAP net loss of $2 million, or $0.02 per share, in the
fourth quarter of 2016.

[0001193125-17-162548:8k_2_02:17]
On a non-GAAP basis, net income attributable to stockholders for the first quarter of
2017 was $39.2 million, or $0.37 per diluted share. This compares to non-GAAP net income attributable to stockholders of $13.9 million, or $0.14 per diluted share, for the first quarter of 2016 and
$59.8 million, or $0.58 per diluted share, in the fourth quarter of 2016.

[0001193125-17-162548:8k_2_02:18]
Adjusted EBITDA for the first quarter of 2017 was $95.6 million, or
15.3 percent of net sales, compared to adjusted EBITDA of $74.5 million, or 12.8 percent of net sales, for the first quarter of 2016 and $128.5 million, or 18.2 percent of net sales, for the fourth quarter of 2016.

[0001193125-17-162548:8k_2_02:19]
“TTM delivered strong organic year on year growth in the first quarter of 7 percent, near the high end of our guidance, and profitability which
exceeded our forecast” said Tom Edman, CEO of TTM. “On a year over year basis, most end markets grew, with the fastest growth coming from the cellular, computing and aerospace and defense end markets. This growth, along with strong
operational execution, resulted in non-GAAP EPS above the high end of our guidance. These results represent the highest revenue and EBITDA for a first quarter in the history of the company.”

[0001193125-17-162548:8k_2_02:20]
Business Outlook

[0001193125-17-162548:8k_2_02:21]
For the second quarter of 2017, TTM
estimates that revenue will be in the range of $605 million to $645 million, and non-GAAP net income attributable to stockholders will be in the range of $0.31 to $0.37 per diluted share.

[0001193125-17-162548:8k_2_02:22]
To Access the Live Webcast/Conference Call

[0001193125-17-162548:8k_2_02:23]
TTM will host
a conference call and webcast to discuss first quarter 2017 results and second quarter 2017 outlook on Wednesday, May 3rd, 2017, at 4:30 p.m. Eastern Time (1:30 p.m. Pacific Time). The conference call will include forward-looking statements.

[0001193125-17-162548:8k_2_02:24]
| TTM Technologies, Inc., Q1’17 |  | Contact: Sameer Desai, Senior Director, Corporate Development & Investor Relations sameer.desai@ttmtech.com 714-327-3050 |

[0001193125-17-162548:8k_2_02:25]
Telephone access is available by dialing domestic 888-206-4824 or international 913-312-1522 (ID 1867334). The conference call also will be webcast on TTM’s website at
www.ttm.com.

[0001193125-17-162548:8k_2_02:26]
To Access a Replay of the Webcast

[0001193125-17-162548:8k_2_02:27]
The replay of the webcast will remain accessible for one week following the live event on TTM’s website at www.ttm.com.

[0001193125-17-162548:8k_2_02:28]
About TTM

[0001193125-17-162548:8k_2_02:29]
TTM Technologies, Inc. is a leading global
printed circuit board manufacturer, focusing on quick-turn and volume production of technologically advanced PCBs, backplane assemblies and electro-mechanical solutions. TTM stands for
time-to-market, representing how TTM’s time-critical, one-stop manufacturing services enable customers to shorten the time
required to develop new products and bring them to market. Additional information can be found at www.ttm.com.

[0001193125-17-162548:8k_2_02:30]
Forward-Looking Statements

[0001193125-17-162548:8k_2_02:31]
This release contains forward-looking statements that relate to future events or performance. TTM cautions you that such statements are simply
predictions and actual events or results may differ materially. These statements reflect TTM’s current expectations, and TTM does not undertake to update or revise these forward looking statements, even if experience or future changes make it
clear that any projected results expressed or implied in this or other TTM statements will not be realized. Further, these statements involve risks and uncertainties, many of which are beyond TTM’s control, which could cause actual results to
differ materially from the forward-looking statements. These risks and uncertainties include, but are not limited to, general market and economic conditions, including interest rates, currency exchange rates and consumer spending, demand for
TTM’s products, market pressures on prices of TTM’s products, warranty claims, changes in product mix, contemplated significant capital expenditures and related financing requirements, TTM’s dependence upon a small number of customers
and other factors set forth in the “Risk Factors” and “Management’s Discussion and Analysis of Financial Condition and Results of Operations” sections of the Company’s public reports filed with the SEC.

[0001193125-17-162548:8k_2_02:32]
About Our Non-GAAP Financial Measures

[0001193125-17-162548:8k_2_02:33]
This release includes information about TTM’s adjusted EBITDA, non-GAAP net income and non-GAAP earnings per share, all of which are non-GAAP financial measures. TTM presents non-GAAP financial information to enable
investors to see TTM through the eyes of management and to provide better insight into TTM’s ongoing financial performance.

[0001193125-17-162548:8k_2_02:34]
A material limitation
associated with the use of the above non-GAAP financial measures is that they have no standardized measurement prescribed by GAAP and may not be comparable to similar
non-GAAP financial measures used by other companies. TTM compensates for these limitations by providing full disclosure of each non-GAAP financial measure and
reconciliation to the most directly comparable GAAP financial measure. However, the non-GAAP financial measures should not be considered in isolation from, or as a substitute for, financial information
prepared in accordance with GAAP.

[0001193125-17-162548:8k_2_02:35]
- Tables Follow -

[0001193125-17-162548:8k_2_02:36]
TTM TECHNOLOGIES, INC.

[0001193125-17-162548:8k_2_02:37]
Selected Unaudited Financial Information

[0001193125-17-162548:8k_2_02:38]
(In thousands, except per share data)

[0001193125-17-162548:8k_2_02:39]
|  |  | First Quarter |  |  | Fourth Quarter |  |
|  |  | 2017 |  |  | 2016 |  |  | 2016 |  |
| CONSOLIDATED CONDENSED STATEMENTS OF OPERATIONS |  |  |  |  |  |  |  |  |  |  |  |  |
| Net sales |  | $ | 625,247 |  |  | $ | 583,258 |  |  | $ | 706,534 |  |
| Cost of goods sold |  |  | 520,228 |  |  |  | 499,695 |  |  |  | 573,689 |  |
| Gross profit |  |  | 105,019 |  |  |  | 83,563 |  |  |  | 132,845 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |
| Selling and marketing |  |  | 16,655 |  |  |  | 17,306 |  |  |  | 16,848 |  |
| General and administrative |  |  | 30,822 |  |  |  | 36,149 |  |  |  | 38,998 |  |
| Amortization of definite-lived intangibles |  |  | 5,912 |  |  |  | 5,947 |  |  |  | 6,407 |  |
| Restructuring charges |  |  | 609 |  |  |  | 1,913 |  |  |  | 946 |  |
| Impairment of long-lived assets |  |  | — |  |  |  | 3,346 |  |  |  | — |  |
| Gain on sale of assets |  |  | (1,549 | ) |  |  | — |  |  |  | — |  |
| Total operating expenses |  |  | 52,449 |  |  |  | 64,661 |  |  |  | 63,199 |  |
| Operating income |  |  | 52,570 |  |  |  | 18,902 |  |  |  | 69,646 |  |
| Interest expense |  |  | (13,596 | ) |  |  | (21,784 | ) |  |  | (15,267 | ) |
| Loss on extinguishment of debt |  |  | — |  |  |  | — |  |  |  | (47,767 | ) |
| Other, net |  |  | (1,710 | ) |  |  | 1,209 |  |  |  | 8,994 |  |
| Income before income taxes |  |  | 37,264 |  |  |  | (1,673 | ) |  |  | 15,606 |  |
| Income tax provision |  |  | (4,139 | ) |  |  | (5,477 | ) |  |  | (17,416 | ) |
| Net income (loss) |  | $ | 33,125 |  |  | $ | (7,150 | ) |  | $ | (1,810 | ) |
| Net income attributable to noncontrolling interest |  |  | (166 | ) |  |  | (114 | ) |  |  | (195 | ) |
| Net income (loss) attributable to stockholders |  | $ | 32,959 |  |  | $ | (7,264 | ) |  | $ | (2,005 | ) |
| Earnings (loss) per share attributable to stockholders: |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  | $ | 0.33 |  |  | $ | (0.07 | ) |  | $ | (0.02 | ) |
| Diluted |  | $ | 0.28 |  |  | $ | (0.07 | ) |  | $ | (0.02 | ) |
| Weighted-average shares used in computing per share amounts: |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  |  | 100,932 |  |  |  | 99,596 |  |  |  | 100,365 |  |
| Diluted |  |  | 130,922 |  |  |  | 99,596 |  |  |  | 100,365 |  |
| Reconciliation of the numerator and denominator used to calculate basic earnings per share and diluted earnings per share: |  |
| Net income attributable to stockholders |  | $ | 32,959 |  |  |  |  |  |  |  |  |  |
| Add back items: interest expense, net of tax |  |  | 3,394 |  |  |  |  |  |  |  |  |  |
| Adjusted net income attributable to stockholders |  | $ | 36,353 |  |  |  |  |  |  |  |  |  |
| Weighted-average shares outstanding |  |  | 100,932 |  |  |  |  |  |  |  |  |  |
| Dilutive effect of convertible debt |  |  | 25,940 |  |  |  |  |  |  |  |  |  |
| Dilutive effect of warrants |  |  | 2,183 |  |  |  |  |  |  |  |  |  |
| Dilutive effect of performance-based stock units, restricted stock units and stock options |  |  | 1,867 |  |  |  |  |  |  |  |  |  |
| Diluted shares |  |  | 130,922 |  |  |  |  |  |  |  |  |  |
| Earnings per share attributable to stockholders: |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  | $ | 0.33 |  |  |  |  |  |  |  |  |  |
| Diluted |  | $ | 0.28 |  |  |  |  |  |  |  |  |  |
| SELECTED BALANCE SHEET DATA |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | April 3, 2017 |  |  | January 2, 2017 |  |  |  |  |
| Cash and cash equivalents, including restricted cash |  | $ | 282,871 |  |  | $ | 256,277 |  |  |  |  |  |
| Accounts and notes receivable, net |  |  | 419,216 |  |  |  | 432,596 |  |  |  |  |  |
| Inventories |  |  | 275,092 |  |  |  | 269,212 |  |  |  |  |  |
| Total current assets |  |  | 1,027,291 |  |  |  | 1,012,841 |  |  |  |  |  |
| Property, plant and equipment, net |  |  | 976,446 |  |  |  | 966,638 |  |  |  |  |  |
| Other non-current assets |  |  | 526,508 |  |  |  | 520,597 |  |  |  |  |  |
| Total assets |  |  | 2,530,245 |  |  |  | 2,500,076 |  |  |  |  |  |
| Short-term debt, including current portion of long-term debt |  | $ | 160,658 |  |  | $ | 110,652 |  |  |  |  |  |
| Accounts payable |  |  | 344,257 |  |  |  | 355,774 |  |  |  |  |  |
| Total current liabilities |  |  | 721,580 |  |  |  | 689,065 |  |  |  |  |  |
| Debt, net of discount |  |  | 861,391 |  |  |  | 909,030 |  |  |  |  |  |
| Total long-term liabilities |  |  | 935,983 |  |  |  | 981,886 |  |  |  |  |  |
| Total equity |  |  | 872,682 |  |  |  | 829,125 |  |  |  |  |  |
| Total liabilities and equity |  |  | 2,530,245 |  |  |  | 2,500,076 |  |  |  |  |  |

[0001193125-17-162548:8k_2_02:40]
SUPPLEMENTAL DATA

[0001193125-17-162548:8k_2_02:41]
|  |  | First Quarter |  |  | Fourth Quarter |  |
|  |  | 2017 |  |  | 2016 |  |  | 2016 |  |
| Gross margin |  |  | 16.8 | % |  |  | 14.3 | % |  |  | 18.8 | % |
| Operating margin |  |  | 8.4 | % |  |  | 3.2 | % |  |  | 9.9 | % |
| End Market Breakdown: |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | First Quarter |  |  | Fourth Quarter |  |
|  |  | 2017 |  |  | 2016 |  |  | 2016 |  |
| Aerospace/Defense |  |  | 15 | % |  |  | 15 | % |  |  | 14 | % |
| Automotive |  |  | 20 | % |  |  | 21 | % |  |  | 19 | % |
| Cellular Phone |  |  | 14 | % |  |  | 9 | % |  |  | 19 | % |
| Computing/Storage/Peripherals |  |  | 15 | % |  |  | 13 | % |  |  | 12 | % |
| Medical/Industrial/Instrumentation |  |  | 15 | % |  |  | 16 | % |  |  | 13 | % |
| Networking/Communications |  |  | 20 | % |  |  | 24 | % |  |  | 21 | % |
| Other |  |  | 1 | % |  |  | 2 | % |  |  | 2 | % |
| Stock-based Compensation: |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | First Quarter |  |  | Fourth Quarter |  |
|  |  | 2017 |  |  | 2016 |  |  | 2016 |  |
| Amount included in: |  |  |  |  |  |  |  |  |  |  |  |  |
| Cost of goods sold |  | $ | 394 |  |  | $ | 320 |  |  | $ | 469 |  |
| Selling and marketing |  | $ | 253 |  |  |  | 210 |  |  |  | 305 |  |
| General and administrative |  |  | 2,981 |  |  |  | 1,716 |  |  |  | 2,426 |  |
| Total stock-based compensation expense |  | $ | 3,628 |  |  | $ | 2,246 |  |  | $ | 3,200 |  |
| Operating Segment Data: |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | First Quarter |  |  | Fourth Quarter |  |
|  |  | 2017 |  |  | 2016 |  |  | 2016 |  |
| Net sales: |  |  |  |  |  |  |  |  |  |  |  |  |
| PCB |  | $ | 586,695 |  |  | $ | 529,945 |  |  | $ | 654,379 |  |
| E-M Solutions |  |  | 41,669 |  |  |  | 56,478 |  |  |  | 55,332 |  |
| Corporate |  |  | — |  |  |  | — |  |  |  | — |  |
| Total sales |  |  | 628,364 |  |  |  | 586,423 |  |  |  | 709,711 |  |
| Inter-segment sales |  |  | (3,117 | ) |  |  | (3,165 | ) |  |  | (3,177 | ) |
| Total net sales |  | $ | 625,247 |  |  | $ | 583,258 |  |  | $ | 706,534 |  |
| Operating segment income: |  |  |  |  |  |  |  |  |  |  |  |  |
| PCB |  | $ | 82,256 |  |  | $ | 49,367 |  |  | $ | 95,208 |  |
| E-M Solutions |  |  | (1,642 | ) |  |  | 387 |  |  |  | 3,029 |  |
| Corporate |  |  | (22,132 | ) |  |  | (24,905 | ) |  |  | (22,184 | ) |
| Total operating segment income |  |  | 58,482 |  |  |  | 24,849 |  |  |  | 76,053 |  |
| Amortization of definite-lived intangibles |  |  | (5,912 | ) |  |  | (5,947 | ) |  |  | (6,407 | ) |
| Total operating income |  |  | 52,570 |  |  |  | 18,902 |  |  |  | 69,646 |  |
| Total other expense |  |  | (15,306 | ) |  |  | (20,575 | ) |  |  | (54,040 | ) |
| Income before income taxes |  | $ | 37,264 |  |  | $ | (1,673 | ) |  | $ | 15,606 |  |

[0001193125-17-162548:8k_2_02:42]
RECONCILIATIONS1

[0001193125-17-162548:8k_2_02:43]
|  |  | First Quarter |  |  | Fourth Quarter |  |
|  |  | 2017 |  |  | 2016 |  |  | 2016 |  |
| Non-GAAP gross profit reconciliation2: |  |  |  |  |  |  |  |  |  |  |  |  |
| GAAP gross profit |  | $ | 105,019 |  |  | $ | 83,563 |  |  | $ | 132,845 |  |
| Add back item: |  |  |  |  |  |  |  |  |  |  |  |  |
| Stock-based compensation |  |  | 394 |  |  |  | 320 |  |  |  | 469 |  |
| Non-GAAP gross profit |  | $ | 105,413 |  |  | $ | 83,883 |  |  | $ | 133,314 |  |
| Non-GAAP gross margin |  |  | 16.9 | % |  |  | 14.4 | % |  |  | 18.9 | % |
| Non-GAAP operating income reconciliation3: |  |  |  |  |  |  |  |  |  |  |  |  |
| GAAP operating income |  | $ | 52,570 |  |  | $ | 18,902 |  |  | $ | 69,646 |  |
| Add back items: |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of definite-lived intangibles |  |  | 5,912 |  |  |  | 5,947 |  |  |  | 6,407 |  |
| Stock-based compensation |  |  | 3,628 |  |  |  | 2,246 |  |  |  | 3,200 |  |
| Gain on sale of assets |  |  | (1,549 | ) |  |  | — |  |  |  | — |  |
| Impairments, restructuring, acquisition-related, and other charges |  |  | 709 |  |  |  | 5,950 |  |  |  | 1,725 |  |
| Non-GAAP operating income |  | $ | 61,270 |  |  | $ | 33,045 |  |  | $ | 80,978 |  |
| Non-GAAP operating margin |  |  | 9.8 | % |  |  | 5.7 | % |  |  | 11.5 | % |
| Non-GAAP net income and EPS attributable to stockholders reconciliation4: |  |  |  |  |  |  |  |  |  |  |  |  |
| GAAP net income (loss) attributable to stockholders |  | $ | 32,959 |  |  | $ | (7,264 | ) |  | $ | (2,005 | ) |
| Add back items: |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of definite-lived intangibles |  |  | 5,912 |  |  |  | 5,947 |  |  |  | 6,407 |  |
| Stock-based compensation |  |  | 3,628 |  |  |  | 2,246 |  |  |  | 3,200 |  |
| Non-cash interest expense |  |  | 2,627 |  |  |  | 6,154 |  |  |  | 2,697 |  |
| Gain on sale of assets |  |  | (1,549 | ) |  |  | — |  |  |  | — |  |
| Loss on extinguishment of debt |  |  | — |  |  |  | — |  |  |  | 47,767 |  |
| Impairments, restructuring, acquisition-related, and other charges |  |  | 709 |  |  |  | 5,950 |  |  |  | 1,725 |  |
| Income taxes |  |  | (5,093 | ) |  |  | 821 |  |  |  | 49 |  |
| Non-GAAP net income attributable to stockholders |  | $ | 39,193 |  |  | $ | 13,854 |  |  | $ | 59,840 |  |
| Non-GAAP earnings per diluted share attributable to stockholders |  | $ | 0.37 |  |  | $ | 0.14 |  |  | $ | 0.58 |  |
| Non-GAAP diluted number of shares5: |  |  |  |  |  |  |  |  |  |  |  |  |
| Diluted shares |  |  | 130,922 |  |  |  | 99,596 |  |  |  | 102,563 |  |
| Dilutive effect of convertible debt |  |  | (25,940 | ) |  |  | — |  |  |  | — |  |
| Non-GAAP diluted number of shares |  |  | 104,982 |  |  |  | 99,596 |  |  |  | 102,563 |  |
| Adjusted EBITDA reconciliation6: |  |  |  |  |  |  |  |  |  |  |  |  |
| GAAP net income (loss) |  | $ | 33,125 |  |  | $ | (7,150 | ) |  | $ | (1,810 | ) |
| Add back items: |  |  |  |  |  |  |  |  |  |  |  |  |
| Income tax provision (benefit) |  |  | 4,139 |  |  |  | 5,477 |  |  |  | 17,416 |  |
| Interest expense |  |  | 13,596 |  |  |  | 21,784 |  |  |  | 15,267 |  |
| Amortization of definite-lived intangibles |  |  | 5,912 |  |  |  | 5,947 |  |  |  | 6,407 |  |
| Depreciation expense |  |  | 36,077 |  |  |  | 40,227 |  |  |  | 38,539 |  |
| Stock-based compensation |  |  | 3,628 |  |  |  | 2,246 |  |  |  | 3,200 |  |
| Gain on sale of assets |  |  | (1,549 | ) |  |  | — |  |  |  | — |  |
| Loss on extinguishment of debt |  |  | — |  |  |  | — |  |  |  | 47,767 |  |
| Impairments, restructuring, acquisition-related, and other charges |  |  | 709 |  |  |  | 5,950 |  |  |  | 1,725 |  |
| Adjusted EBITDA |  | $ | 95,637 |  |  | $ | 74,481 |  |  | $ | 128,511 |  |
| Adjusted EBITDA margin |  |  | 15.3 | % |  |  | 12.8 | % |  |  | 18.2 | % |
| Free cash flow reconciliation: |  |  |  |  |  |  |  |  |  |  |  |  |
| Operating cash flow |  |  | 49,584 |  |  |  | 17,892 |  |  |  | 97,650 |  |
| Add back items: |  |  |  |  |  |  |  |  |  |  |  |  |
| Payment of acquisition-related costs |  |  | 153 |  |  |  | 2,324 |  |  |  | 869 |  |
| Adjusted operating cash flow |  |  | 49,737 |  |  |  | 20,216 |  |  |  | 98,519 |  |
| Capital expenditures, net |  |  | (23,378 | ) |  |  | (20,116 | ) |  |  | (20,501 | ) |
| Free cash flow |  | $ | 26,359 |  |  | $ | 100 |  |  | $ | 78,018 |  |

[0001193125-17-162548:8k_2_02:44]
| 1 | This information provides a reconciliation of non-GAAP gross profit, non-GAAP operating income, non-GAAP net income attributable to stockholders, non-GAAP EPS attributable to stockholders, and adjusted EBITDA to the financial information in our consolidated condensed statements of operations. |

[0001193125-17-162548:8k_2_02:45]
| 2 | Non-GAAP gross profit and gross margin measures exclude stock-based compensation expense. |

[0001193125-17-162548:8k_2_02:46]
| 3 | Non-GAAP operating income and operating margin measures exclude amortization of intangibles, stock-based compensation expense, gain on sale of assets, acquisition-related costs, asset impairments, restructuring and other charges. |

[0001193125-17-162548:8k_2_02:47]
| 4 | This information provides non-GAAP net income attributable to stockholders and non-GAAP EPS attributable to stockholders, which are non-GAAP financial measures. Management believes that both measures — which add back amortization of intangibles, stock-based compensation expense, non-cash interest expense on debt (before consideration of capitalized interest), gain on sale of assets, acquisition-related costs, asset impairments, restructuring and other charges as well as the associated tax impact of these charges and discrete tax items — provide additional useful information to investors regarding the Company’s ongoing financial condition and results of operations. |

[0001193125-17-162548:8k_2_02:48]
| 5 | Non-GAAP diluted number of shares used in computing non-GAAP earnings per share attributable to stockholders excludes the dilutive effect of convertible debt. |

[0001193125-17-162548:8k_2_02:49]
| 6 | Adjusted EBITDA is defined as earnings before interest expense, income taxes, depreciation, amortization of intangibles, stock-based compensation expense, gain on sale of assets, acquisition-related costs, asset impairments, restructuring and other charges. We present adjusted EBITDA to enhance the understanding of our operating results, and it is a key measure we use to evaluate our operations. In addition, we provide our adjusted EBITDA because we believe that investors and securities analysts will find adjusted EBITDA to be a useful measure for evaluating our operating performance and comparing our operating performance with that of similar companies that have different capital structures and for evaluating our ability to meet our future debt service, capital expenditures, and working capital requirements. However, adjusted EBITDA should not be considered as an alternative to cash flows from operating activities as a measure of liquidity or as an alternative to net income as a measure of operating results in accordance with accounting principles generally accepted in the United States of America. |
