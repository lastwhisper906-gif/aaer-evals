# TTMI MD&A — 0001193125-17-166200


## mdna

[0001193125-17-166200:mdna:1]
[same as prior period, unchanged from 0001193125-16-758846:mdna:1]

[0001193125-17-166200:mdna:2]
[same as prior period, unchanged from 0001193125-16-758846:mdna:21]

[0001193125-17-166200:mdna:3]
We are a leading global printed circuit board (PCB) manufacturer, focusing on quick-turn and volume production of
technologically complex PCBs and electro-mechanical solutions (E-M Solutions). We focus on providing time-to-market and volume
production of advanced technology products and offer a one-stop manufacturing solution to our customers from engineering support to prototype development through final mass production. This one-stop manufacturing solution allows us to align technology development with the diverse needs of our customers and to enable them to reduce the time required to develop new products and bring them to market. We
serve a diversified customer base consisting of approximately 1,500 customers in various markets throughout the world, including manufacturers of networking/communications infrastructure products, smartphones and touchscreen tablets, as well as
aerospace and defense, automotive, high-end computing, and medical, industrial and instrumentation related products. Our customers include both original equipment manufacturers (OEMs) and electronic
manufacturing services (EMS) providers.

[0001193125-17-166200:mdna:4]
For the first quarter of 2017, we experienced higher demand in our
Cellular Phone, Computing/Storage/Peripherals and Aerospace/ Defense end markets compared to the first quarter of 2016. This increase in sales resulted in higher capacity utilization especially at our Cellular Phone and Computing/Storage/Peripherals
focused facilities resulting in higher gross margins.

[0001193125-17-166200:mdna:5]
While our customers include both OEMs and EMS
providers, we measure customers based on OEM companies, as they are the ultimate end customers. Sales to our 10 largest customers accounted for 45% and 41% of our net sales for the quarters ended April 3, 2017 and March 28, 2016,
respectively. We sell to OEMs both directly and indirectly through EMS providers.

[0001193125-17-166200:mdna:6]
The following table shows
the percentage of our net sales attributable to each of the principal end markets we served for the periods indicated:

[0001193125-17-166200:mdna:7]
|  |  | Quarter Ended |  |
| End Markets(1)(2) |  | April 3,2017 |  |  | March 28,2016 |  |
| Aerospace and Defense |  |  | 15 | % |  |  | 15 | % |
| Automotive |  |  | 20 |  |  |  | 21 |  |
| Cellular Phone(2) |  |  | 14 |  |  |  | 9 |  |
| Computing/Storage/Peripherals(2) |  |  | 15 |  |  |  | 13 |  |
| Medical/Industrial/Instrumentation |  |  | 15 |  |  |  | 16 |  |
| Networking/Communications |  |  | 20 |  |  |  | 24 |  |
| Other(2) |  |  | 1 |  |  |  | 2 |  |
| Total |  |  | 100 | % |  |  | 100 | % |

[0001193125-17-166200:mdna:8]
[same as prior period, unchanged from 0001193125-16-758846:mdna:31]

[0001193125-17-166200:mdna:9]
| (2) | Smartphones are included in the Cellular Phone end market, tablets are included in the Computing/Storage/Peripherals end market and other mobile devices such as e-readers are included in the Other end market. |

[0001193125-17-166200:mdna:10]
20

[0001193125-17-166200:mdna:11]
We derive revenues primarily from the sale of PCBs and custom electronic
assemblies using customer-supplied engineering and design plans. We recognize revenues when persuasive evidence of a sales arrangement exists, the sales terms are fixed or determinable, title and risk of loss have transferred, and collectability is
reasonably assured — generally when products are shipped to the customer. Net sales consist of gross sales less an allowance for returns, which typically have been less than 3% of gross sales. We provide our customers a limited right of return
for defective PCBs and backplane assemblies. We record an estimate for sales returns and allowances at the time of sale based on historical results. Purchase orders may be cancelled prior to shipment. We generally charge customers a fee, based on
the percentage completed, if an order is cancelled once it has entered production.

[0001193125-17-166200:mdna:12]
Cost of goods sold
consists of materials, labor, outside services, and overhead expenses incurred in the manufacture and testing of our products. Shipping and handling fees and related freight costs and supplies associated with shipping products are also included as a
component of cost of goods sold. Many factors affect our gross margin, including capacity utilization, product mix, production volume, and yield. We generally do not participate in any significant long-term contracts with suppliers, and we believe
there are a number of potential suppliers for the raw materials we use.

[0001193125-17-166200:mdna:13]
Selling and marketing expenses
consist primarily of salaries, labor related benefits, and commissions paid to our internal sales force, independent sales representatives, and our sales support staff, as well as costs associated with marketing materials and trade shows.

[0001193125-17-166200:mdna:14]
General and administrative costs primarily include the salaries for executive, finance, accounting,
information technology, and human resources personnel, as well as expenses for accounting and legal assistance, incentive compensation expense, and gains or losses on the sale or disposal of property, plant and equipment.

[0001193125-17-166200:mdna:15]
[same as prior period, unchanged from 0001193125-16-758846:mdna:39]

[0001193125-17-166200:mdna:16]
[same as prior period, unchanged from 0001193125-16-758846:mdna:40]

[0001193125-17-166200:mdna:17]
See Item 7, Management’s Discussion and Analysis of Financial Condition and Results of Operations, in our Annual Report on Form 10-K for the fiscal
year ended January 2, 2017 for further discussion of critical accounting policies and estimates. There were no material changes to our critical accounting policies and estimates since January 2, 2017.

[0001193125-17-166200:mdna:18]
21

[0001193125-17-166200:mdna:19]
[same as prior period, unchanged from 0001193125-16-758846:mdna:43]

[0001193125-17-166200:mdna:20]
The following table sets forth the relationship of various items to net sales in our consolidated condensed statements of
operations:

[0001193125-17-166200:mdna:21]
|  |  | Quarter Ended |  |
|  |  | April 3, 2017 |  |  | March 28, 2016 |  |
| Net sales |  |  | 100.0 | % |  |  | 100.0 | % |
| Cost of goods sold |  |  | 83.2 |  |  |  | 85.7 |  |
| Gross profit |  |  | 16.8 |  |  |  | 14.3 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |
| Selling and marketing |  |  | 2.7 |  |  |  | 3.0 |  |
| General and administrative |  |  | 4.7 |  |  |  | 6.2 |  |
| Amortization of definite-lived intangibles |  |  | 0.9 |  |  |  | 1.0 |  |
| Restructuring charges |  |  | 0.1 |  |  |  | 0.3 |  |
| Impairment of long-lived assets |  |  | — |  |  |  | 0.6 |  |
| Total operating expenses |  |  | 8.4 |  |  |  | 11.1 |  |
| Operating income |  |  | 8.4 |  |  |  | 3.2 |  |
| Other income (expense): |  |  |  |  |  |  |  |  |
| Interest expense |  |  | (2.2 | ) |  |  | (3.7 | ) |
| Other, net |  |  | (0.2 | ) |  |  | 0.2 |  |
| Total other expense, net |  |  | (2.4 | ) |  |  | (3.5 | ) |
| Income (loss) before income taxes |  |  | 6.0 |  |  |  | (0.3 | ) |
| Income tax provision |  |  | (0.7 | ) |  |  | (0.9 | ) |
| Net income (loss) |  |  | 5.3 |  |  |  | (1.2 | ) |
| Less: Net income attributable to the non-controlling interest |  |  | — |  |  |  | — |  |
| Net income (loss) attributable to TTM Technologies, Inc. stockholders |  |  | 5.3 | % |  |  | (1.2 | )% |

[0001193125-17-166200:mdna:22]
We have reviewed our reportable operating segments and determined that we continue to
have two reportable operating segments: PCB and E-M Solutions. This determination was made based on the criteria of earning revenues and incurring expenses, our organizational structure which has segment
managers who report to the chief operating decision maker, discrete financial information, and the aggregation of similar operating segments into reportable operating segments for the PCB reportable operating segment.

[0001193125-17-166200:mdna:23]
The following table compares net sales by reportable segment for the quarters ended April 3, 2017 and March 28,
2016:

[0001193125-17-166200:mdna:24]
|  |  | For the Quarters Ended |  |
|  |  | April 3, 2017 |  |  | March 28, 2016 |  |
|  |  | (In thousands) |  |
| Net Sales: |  |  |  |  |  |  |  |  |
| PCB |  | $ | 586,695 |  |  | $ | 529,945 |  |
| E-M Solutions |  |  | 41,669 |  |  |  | 56,478 |  |
| Total sales |  |  | 628,364 |  |  |  | 586,423 |  |
| Inter-segment sales |  |  | (3,117 | ) |  |  | (3,165 | ) |
| Total net sales |  | $ | 625,247 |  |  | $ | 583,258 |  |

[0001193125-17-166200:mdna:25]
[same as prior period, unchanged from 0001193125-16-758846:mdna:50]

[0001193125-17-166200:mdna:26]
Total net sales increased $41.9 million, or 7.2%, from $583.3 million for the quarter ended March 28, 2016 to $625.2 million for the quarter ended April 3, 2017.

[0001193125-17-166200:mdna:27]
Net sales for the PCB operating segment, excluding inter-segment sales, increased $56.8 million, or 10.8%, from
$526.8 million for the quarter ended March 28, 2016 to $583.6 million for the quarter ended April 3, 2017. This increase is primarily due to higher demand in our Cellular Phone, Computing/Storage/Peripherals and Aerospace/Defense
end markets, partially offset by a decline in our

[0001193125-17-166200:mdna:28]
Networking/Communications end market. These changes resulted in a 9% increase in PCB shipments as compared to the quarter ended March 28, 2016, and an average PCB selling price increase of
1%, which was driven by a product mix shift.

[0001193125-17-166200:mdna:29]
Net sales for the E-M
Solutions operating segment decreased $14.8 million from $56.5 million for the quarter ended March 28, 2016 to $41.7 million for the quarter ended April 3, 2017. This decrease is primarily due to the closure of our Juarez,
Mexico facility and lower demand in our Networking/Communications end market.

[0001193125-17-166200:mdna:30]
[same as prior period, unchanged from 0001193125-16-758846:mdna:54]

[0001193125-17-166200:mdna:31]
Overall gross margin increased from 14.3% for the quarter ended March 28, 2016 to 16.8% for the quarter ended
April 3, 2017. Gross margin for the PCB operating segment increased from 15.6% for the quarter ended March 28, 2016 to 18.2% for the quarter ended April 3, 2017 primarily due to increased volumes at our Cellular Phone and
Computing/Storage/Peripherals focused facilities, savings from our synergy initiatives, a $3.0 million insurance settlement from a fire in our Anaheim, California facility a year ago, partially offset by the reclassification of certain
facilities and labor support related costs from general and administrative expenses to cost of goods sold due to changes in our business structure. Gross margin for the E-M Solutions operating segment
decreased from 6.6% for the quarter ended March 28, 2016 to 2.7% for the quarter ended April 3, 2017 primarily due to decreased volumes and higher inventory reserves.

[0001193125-17-166200:mdna:32]
[same as prior period, unchanged from 0001193125-16-758846:mdna:58]

[0001193125-17-166200:mdna:33]
Selling and
marketing expenses decreased $0.6 million, from $17.3 million for the quarter ended March 28, 2016 to $16.7 million for the quarter ended April 3, 2017. As a percentage of net sales, selling and marketing expenses were 3.0%
for the quarter ended March 28, 2016, as compared to 2.7% for the quarter ended April 3, 2017. The decrease in selling and marketing expense primarily relates to reduced headcount and lower travel expenses.

[0001193125-17-166200:mdna:34]
General and Administrative Expenses

[0001193125-17-166200:mdna:35]
General and administrative expenses decreased $6.9 million from $36.2 million, or 6.2% of net sales, for the quarter ended March 28, 2016 to $29.3 million, or 4.7% of net sales, for
the quarter ended April 3, 2017. The decrease in expense primarily relates to reclassification of certain facilities and labor support related costs to cost of goods sold due to changes in our business structure.

[0001193125-17-166200:mdna:36]
[same as prior period, unchanged from 0001193125-16-758846:mdna:63]

[0001193125-17-166200:mdna:37]
For the quarter ended April 3, 2017 and March 28, 2016, we incurred restructuring charges of $0.6 million
and $1.9 million, respectively, related to a consolidation plan announced on September 29, 2015, that resulted in the closure of our facilities in Cleveland, Ohio, Milpitas, California, and Juarez, Mexico (the Consolidation Plan). These
charges primarily represent severance and contract termination and other costs. For the quarter ended April 3, 2017, in connection with the Consolidation Plan, we recognized restructuring charges of $0.2 million, $0.3 million and
$0.1 million in our PCB, E-M Solutions and Corporate segments, respectively. For the quarter ended March 28, 2016, we recognized restructuring charges of $1.2 million and $0.7 million in
our PCB and E-M Solutions segments, respectively. As of April 3, 2017, the Company has incurred approximately $16.9 million of restructuring charges since the September 29, 2015 announcement.

[0001193125-17-166200:mdna:38]
Additionally, as a result of the above mentioned plant closures and other plant realignment efforts, we also
recognized impairment charges of $3.3 million for the quarter ended March 28, 2016, of which $1.4 million were recognized in our PCB operating segment and $1.9 million were recognized related in the Corporate operating segment.
The impairment charge for the PCB operating segment related to machinery and equipment while the impairment charge for the Corporate operating segment related to the write-off of capitalized software costs.

[0001193125-17-166200:mdna:39]
If forecasts and assumptions used to support the realizability of our long-lived assets change in the future,
significant impairment or restructuring charges could result that would adversely affect our results of operations.

[0001193125-17-166200:mdna:40]
Other Income
(Expense)

[0001193125-17-166200:mdna:41]
Other expense, net decreased $5.3 million from $20.6 million for the quarter ended
March 28, 2016 to $15.3 million for the quarter ended April 3, 2017. The decrease in other expense, net was primarily due to a decrease in interest expense due to lower principal outstanding resulting from net debt principal payments
totaling $217.6 million in 2016, a lower Term Loan interest rate by 75 basis points, and lower amortization of debt issuance costs and debt discount after the full repayment of our prior term loan in the fourth quarter of 2016. The decrease in
other expense, net was partially offset by $3.7 million of foreign currency transaction losses for the quarter ended April 3, 2017 due to the appreciation of the Renminbi, which is utilized at certain of our Asia operations.

[0001193125-17-166200:mdna:42]
[same as prior period, unchanged from 0001193125-16-758846:mdna:72]

[0001193125-17-166200:mdna:43]
The provision for income taxes decreased by $1.4 million from $5.5 million for the quarter ended March 28,
2016 to $4.1 million for the quarter ended April 3, 2017. The decrease in income tax expense in 2017 was primarily due to the receipt of China’s high and new technology enterprise status in one of our subsidiaries in the quarter ended
April 3, 2017, which resulted in a tax incentive benefit effective retroactively to 2016.

[0001193125-17-166200:mdna:44]
Our effective
tax rate was primarily impacted by tax rates in China and Hong Kong, the U.S. federal income tax rate, apportioned state income tax rates, generation of other credits and deductions available to us, valuation allowance establishment, and certain non-deductible items. Certain foreign losses generated are not more likely than not to be realizable, and thus no income tax benefit has been recognized on these losses. We had net deferred income tax
liabilities of approximately $14.0 million at both April 3, 2017 and January 2, 2017.

[0001193125-17-166200:mdna:45]
[same as prior period, unchanged from 0001193125-16-758846:mdna:75]

[0001193125-17-166200:mdna:46]
Our principal sources of liquidity have been cash provided by operations, the issuance of convertible
senior notes, and term and revolving debt. Our principal uses of cash have been to finance acquisitions and capital expenditures, meet debt service requirements, fund working capital requirements, and repay existing debt. We anticipate that
servicing debt, financing capital expenditures, financing acquisitions, and funding working capital requirements will continue to be the principal demands on our cash in the future.

[0001193125-17-166200:mdna:47]
Cash flow provided by operating activities during the quarter ended April 3, 2017 was $49.6 million as compared
to $17.9 million in the same period in 2016. The increase in cash flow was due to stronger operational performance and improved use of working capital. Cash cycle days improved to 46 days for the quarter ended April 3, 2017 as
compared to 54 days for the quarter ended March 28, 2016. As of April 3, 2017, we had net working capital of approximately $305.7 million compared to $323.8 million as of January 2, 2017.

[0001193125-17-166200:mdna:48]
Net cash used in investing activities was approximately $23.4 million for the quarter ended April 3, 2017
primarily reflecting purchases of property, plant and equipment of $33.3 million less proceeds from sale of property, plant and equipment and assets held for sale of $9.9 million. For the quarter ended March 28, 2016, net cash used in
investing activities was approximately $16.6 million primarily reflecting purchases of property, plant and equipment of $20.1 million less release of restricted cash to cash and cash equivalents of $3.5 million.

[0001193125-17-166200:mdna:49]
Net cash provided by financing activities was approximately $0.1 million for the quarter ended April 3, 2017
reflecting proceeds from exercise of common stock options. Net cash used in financing activities was approximately $76.5 million for the quarter ended March 28, 2016 reflecting the repayment of normally scheduled principal payments as well
as an additional prepayment of principal of long-term debt.

[0001193125-17-166200:mdna:50]
As of April 3, 2017, we had cash and cash
equivalents of approximately $282.9 million, of which approximately $225.5 million was held by our foreign subsidiaries, primarily Asia. Cash and cash equivalents held by our foreign locations are expected to be used in local operations.

[0001193125-17-166200:mdna:51]
Our 2017 net capital expenditure are expected to be in the range of $155 million to $170 million,
of which 40 percent are planned for technology enhancements, 30 percent for capacity expansions and 30 percent for compliance and maintenance related expenditures.

[0001193125-17-166200:mdna:52]
[same as prior period, unchanged from 0001193125-16-758846:mdna:83]

[0001193125-17-166200:mdna:53]
We maintain a Term Loan, a
$200.0 million U.S. ABL, and a $150.0 million Asia ABL (collectively the ABL Revolving Loans).

[0001193125-17-166200:mdna:54]
The
Term Loan bears interest at a floating rate of LIBOR, with a 1.0% LIBOR floor, plus an applicable interest margin of 4.25%, or JP Morgan Chase Bank’s prime rate, with a 2% floor, plus a margin of 3.25%, at the our option. At April 3, 2017,
the weighted average interest rate on the outstanding borrowings under the Term Loan was 5.25%. There is no provision, other than an event of default, for the interest margin to increase. The Term Loan will mature on May 31, 2021. The Term Loan
is secured by a significant amount of our assets and a pledge of 65% of voting stock of our first tier foreign subsidiaries and is structurally senior to our convertible senior notes. See Convertible Senior Notes below.

[0001193125-17-166200:mdna:55]
The U.S. ABL consists of three tranches
comprised of a revolving credit facility of up to $200.0 million, a letter of credit facility of up to $50.0 million, and swingline loans of up to $30.0 million, provided that at no time may amounts outstanding under the tranches
exceed in aggregate $200.0 million or the applicable borrowing base, which is a percentage of the principal amount of Eligible Accounts, as defined in the U.S. ABL agreement. Borrowings under the U.S. ABL bear interest at either a floating rate
of LIBOR plus a margin of 150 basis points or JP Morgan Chase Bank’s prime rate plus a margin of 50 basis points, at our option. At April 3, 2017, the weighted average interest rate on the outstanding borrowings under the U.S. ABL was
2.48%. The applicable margin can vary based on the remaining availability of the facility, from 125 to 175 basis points for LIBOR-based loans and from 25

[0001193125-17-166200:mdna:56]
24

[0001193125-17-166200:mdna:57]
to 75 basis points for JP Morgan Chase Bank’s prime rate-based loans. Other than availability and an event of default, there are no other provisions for the interest margin to increase. The
U.S. ABL will mature on May 31, 2020. Loans made under the U.S. ABL are secured first by all of our domestic cash, receivables and inventories as well as by a second position against a significant amount of our assets and a pledge of 65% of
voting stock of our first tier foreign subsidiaries and are structurally senior to our convertible senior notes. See Convertible Senior Notes below. At April 3, 2017, $80.0 million of the U.S. ABL was outstanding. We and our domestic
subsidiaries have fully and unconditionally guaranteed the full and timely payment of all Term Loan and U.S. ABL related obligations.

[0001193125-17-166200:mdna:58]
The Asia ABL consists of two tranches comprised of a revolving credit facility of up to $150.0 million and a letter of credit facility of up to $100.0 million, provided that at no time may
amounts outstanding under both tranches exceed in aggregate $150.0 million or the applicable borrowing base, which is a percentage of the principal amount of Eligible Accounts, as defined in the Asia ABL agreement. Borrowings under the Asia ABL
bear interest at a floating rate of LIBOR plus 140 basis points. At April 3, 2017, the weighted average interest rate on the outstanding borrowings under the Asia ABL was 2.38%. There is no provision, other than an event of default, for the
interest margin to increase. The Asia ABL will mature on May 22, 2020. Loans made under the Asia ABL are secured by a portion of our Asia Pacific cash and receivables and are structurally senior to our domestic obligations, including the
convertible senior notes. See Convertible Senior Notes below. Our Asia Pacific subsidiary and certain of our subsidiaries have fully and unconditionally guaranteed the full and timely payment of all Asia ABL related obligations. At April 3,
2017, $30.0 million of the Asia ABL was outstanding.

[0001193125-17-166200:mdna:59]
We are no longer required to make quarterly
scheduled payments for the remaining term of the outstanding Term Loan balance due to mandatory payments and optional loan prepayments applied to date. Additionally, based on certain parameters defined in the Term Loan agreement, including a secured
leverage ratio, we are also not required to make an additional principal payment for fiscal year 2017 as our secured leverage ratio is less than or equal to 1.5. We may be required to make additional principal payments in future years, if our
secured leverage ratio is greater than 1.5. Any remaining outstanding balances under the Term Loan are due at the maturity date of May 31, 2021. Subsequent to the quarter ended April 3, 2017, the Company made an optional debt principal
prepayment totaling $50.0 million. Borrowings under the Term Loan are subject to financial and operating covenants including maintaining a maximum total leverage ratio. Under the occurrence of certain events, the U.S. ABL and the Asia ABL are
subject to financial and operational covenants, including maintaining minimum fixed charge coverage ratios. At April 3, 2017, we were in compliance with the covenants under the Term Loan, the U.S. ABL and the Asia ABL.

[0001193125-17-166200:mdna:60]
We are required to pay a commitment fee of 0.25% to 0.375% per annum on any unused portion of the U.S. ABL or Asia
ABL based on utilization levels. We incurred total commitment fees related to unused borrowing availability of $0.2 million for both quarters ended April 3, 2017 and March 28, 2016. As of April 3, 2017, the outstanding amount of
the Term Loan was $700.0 million, of which $50.0 million is included in short-term debt and the remaining $650.0 million is included as long-term debt. Additionally, $80.0 million of the U.S. ABL and $30.0 million of the
Asia ABL were outstanding as of April 3, 2017, which were classified as short-term debt. Available borrowing capacity under the U.S. ABL and Asia ABL was $113.5 million and $99.6 million, which includes letters of credit outstanding
of $6.5 million and $20.4 million mentioned below, respectively, at April 3, 2017.

[0001193125-17-166200:mdna:61]
[same as prior period, unchanged from 0001193125-16-758846:mdna:93]

[0001193125-17-166200:mdna:62]
We have up to $50.0 million and $100.0 million Letters of Credit Facilities available under the U.S. ABL and the
Asia ABL, respectively. As of April 3, 2017, letters of credit in the amount of $6.5 million were outstanding under the U.S. ABL and $20.4 million were outstanding under the Asia ABL with various expiration dates through March 2018.

[0001193125-17-166200:mdna:63]
[same as prior period, unchanged from 0001193125-16-758846:mdna:95]

[0001193125-17-166200:mdna:64]
We are party to a revolving loan credit facility with a lender in China. Under this arrangement, the lender has made available to us approximately $30.5 million in unsecured borrowing with all terms
of the borrowing to be negotiated at the time the Chinese Revolver is drawn upon. There are no commitment fees on the unused portion of the Chinese Revolver, and this arrangement expires in January 2018. As of April 3, 2017, the Chinese
Revolver had not been drawn upon.

[0001193125-17-166200:mdna:65]
Convertible Senior Notes due 2020

[0001193125-17-166200:mdna:66]
We issued 1.75% convertible senior notes due December 15, 2020, in a public offering for an aggregate principal
amount of $250.0 million. The convertible senior notes bear interest at a rate of 1.75% per annum. Interest is payable semiannually in arrears on June 15 and December 15 of each year. The convertible senior notes are senior
unsecured obligations and rank equally to our future unsecured senior indebtedness and senior in right of payment to any of our future subordinated indebtedness. Offering expenses are being amortized to interest expense over the term of the
convertible senior notes.

[0001193125-17-166200:mdna:67]
Conversion: At any time prior to March 15, 2020, holders may convert their convertible
senior notes into cash and, if applicable, into shares of our common stock based on a conversion rate of 103.7613 shares of our common stock per $1,000 principal amount of convertible senior notes, subject to adjustment, under the following
circumstances: (1) during any calendar quarter beginning after March 31, 2015 (and only during such calendar quarter), if the last reported sale price of our common stock for at least

[0001193125-17-166200:mdna:68]
20 trading days during the 30 consecutive trading days ending on the last trading day of the immediately preceding calendar quarter is greater than or equal to 130% of the applicable conversion
price on each applicable trading day of such preceding calendar quarter; (2) during the five business day period after any 10 consecutive trading day period in which the trading price per note for each day of that 10 consecutive trading day
period was less than 98% of the product of the last reported sale price of our common stock and the conversion rate on such day; or (3) upon the occurrence of specified corporate transactions described in the indenture governing the notes. As
of April 3, 2017, the conversion criteria had been met under the condition (1) as described above, allowing holders to give notice of conversion in both the first and second quarter of 2017.

[0001193125-17-166200:mdna:69]
On or after March 15, 2020 until the close of business on the third scheduled trading day preceding the maturity
date, holders may convert their notes at any time, regardless of the foregoing circumstances. Upon conversion, for each $1,000 principal amount of notes, we will pay shares of our common stock, cash or a combination of cash and shares of our common
stock at our election, if applicable, based on a daily conversion value calculated on a proportionate basis for each day of the 80 trading day observation period. All conversions occurring on the same date or on or after March 15, 2020 shall be
settled using the same settlement method. Additionally, in the event of a fundamental change as defined in the indenture governing the notes, or other conversion rate adjustments such as share splits or combinations, other distributions of shares,
cash or other assets to stockholders, including self-tender transactions (Other Conversion Rate Adjustments), the conversion rate may be modified to adjust the number of shares per $1,000 principal amount of the notes. As of April 3 2017, none
of the criteria for a fundamental change or a conversion rate adjustment had been met.

[0001193125-17-166200:mdna:70]
The maximum number of
shares issuable upon conversion, including the effect of a fundamental change and subject to Other Conversion Rate Adjustments, would be 32.4 million.

[0001193125-17-166200:mdna:71]
Note Repurchase: We are not permitted to redeem the convertible senior notes at any time prior to maturity. In the event of a fundamental change or certain default events, as
defined in the indenture governing the notes, holders may require us to repurchase for cash all or a portion of their convertible senior notes at a price equal to 100% of the principal amount, plus any accrued and unpaid interest.

[0001193125-17-166200:mdna:72]
In connection with the issuance of the convertible senior notes due 2020, we entered into a convertible note hedge and
warrant transaction (the Call Spread Transaction), with respect to our common stock. The convertible note hedge consists of our option to purchase up to 25.9 million common stock shares at a price of $9.64 per share. The hedge expires on
December 15, 2020 and can only be executed upon the conversion of the above mentioned convertible senior notes due 2020. Additionally, we sold warrants to purchase 25.9 million shares of our common stock at a price of $14.26 per share. The
warrants expire ratably from March 2021 through January 2022. The Call Spread Transaction has no effect on the terms of the convertible senior notes due 2020 and reduces potential dilution by effectively increasing the conversion price of the
convertible senior notes due 2020 to $14.26 per share of our common stock.

[0001193125-17-166200:mdna:73]
Based on our current level of
operations, we believe that cash generated from operations, cash on hand and cash from the issuance of term and revolving debt will be adequate to meet our currently anticipated capital expenditure, debt service, and working capital needs for the
next 12 months.

[0001193125-17-166200:mdna:74]
[same as prior period, unchanged from 0001193125-16-758846:mdna:101]

[0001193125-17-166200:mdna:75]
The following table provides information on our contractual obligations as of April 3, 2017:

[0001193125-17-166200:mdna:76]
|  |  | Total |  |  | Less Than1 Year |  |  | 1 - 3 Years |  |  | 4 - 5 Years |  |  | After5 Years |  |
| Contractual Obligations (1) |  | (In thousands) |  |
| Long-term debt obligations |  | $ | 811,815 |  |  | $ | 160,658 |  |  | $ | 746 |  |  | $ | 650,411 |  |  | $ | — |  |
| Convertible debt obligations |  |  | 250,000 |  |  |  | — |  |  |  | — |  |  |  | 250,000 |  |  |  | — |  |
| Interest on debt obligations |  |  | 165,021 |  |  |  | 42,072 |  |  |  | 78,168 |  |  |  | 44,781 |  |  |  | — |  |
| Equipment payables |  |  | 31,876 |  |  |  | 31,876 |  |  |  | — |  |  |  | — |  |  |  | — |  |
| Purchase obligations |  |  | 118,208 |  |  |  | 102,057 |  |  |  | 16,151 |  |  |  | — |  |  |  | — |  |
| Operating lease commitments |  |  | 27,465 |  |  |  | 8,292 |  |  |  | 9,451 |  |  |  | 5,094 |  |  |  | 4,628 |  |
| Total contractual obligations |  | $ | 1,404,385 |  |  | $ | 344,955 |  |  | $ | 104,516 |  |  | $ | 950,286 |  |  | $ | 4,628 |  |

[0001193125-17-166200:mdna:77]
| (1) | Unrecognized uncertain tax benefits of $39.9 million are not included in the table above as the settlement timing is uncertain. |

[0001193125-17-166200:mdna:78]
[same as prior period, unchanged from 0001193125-16-758846:mdna:105]

[0001193125-17-166200:mdna:79]
We do not currently have, nor have we ever had, any relationships with unconsolidated entities or financial partnerships,
such as entities often referred to as structured finance or special purpose entities, which would have been established for the purpose of facilitating off-balance sheet arrangements or other contractually
narrow or limited purposes. In addition, we do not engage in trading activities involving non-exchange traded contracts. As a result, we are not materially exposed to any financing, liquidity, market, or
credit risk that could arise if we had engaged in these relationships.

[0001193125-17-166200:mdna:80]
[same as prior period, unchanged from 0001193125-16-758846:mdna:107]

[0001193125-17-166200:mdna:81]
Orders for our products generally correspond to the production schedules of our customers. We historically experience
higher net sales in the third and fourth quarters due to end customer demand in the fourth quarter for consumer electronics products. Seasonal fluctuations also include the Chinese New Year holidays in the first quarter, which typically results in
lower net sales. We attribute this decline to shutdowns of our customers’ and our own China based manufacturing facilities surrounding the Chinese New Year public holidays, which normally occur in January or February of each year.
