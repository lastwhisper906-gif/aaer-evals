# TTMI notes — 0001193125-17-166200


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001193125-17-166200:notes:1]
(11) Commitments and
 Contingencies

[0001193125-17-166200:notes:2]
Legal
 Matters

[0001193125-17-166200:notes:3]
The
 Company is subject to various legal matters, which it considers
 normal for its business activities. While the Company currently
 believes that the amount of any reasonably possible loss for known
 matters would not be material to the Company’s financial
 condition, the outcome of these actions is inherently difficult to
 predict. In the event of an adverse outcome, the ultimate potential
 loss could have a material adverse effect on the Company’s
 financial condition or results of operations in a particular
 period. The Company has accrued amounts for its loss contingencies
 which are probable and estimable as of April 3, 2017 and
 January 2, 2017. However, these amounts are not material to
 the consolidated condensed financial statements of the
 Company.

[0001193125-17-166200:notes:4]
Environmental
 Matters

[0001193125-17-166200:notes:5]
The
 process to manufacture PCBs requires adherence to city, county,
 state, federal, and foreign environmental regulations regarding the
 storage, use, handling and disposal of chemicals, solid wastes and
 other hazardous materials, as well as compliance with air quality
 standards and chemical use reporting. The Company believes that its
 facilities in the United States, Canada and Mexico comply in all
 material respects with applicable environmental laws and
 regulations. In China, governmental authorities have adopted new
 rules and regulations governing environmental issues. An update to
 the Chinese environmental waste water law was issued in late 2012,
 allowing for an interim period in which plants subject to such law
 may install equipment that meets the new regulatory regime. Some of
 the Company’s plants in China are not yet in full compliance
 with the updated environmental regulations. The Company believes it
 has developed plans acceptable to the Chinese government and is in
 the process of implementing these plans. The Company does not
 anticipate any immediate risk of government fines or temporary
 closure of its Chinese plants. The Company has established and
 enacted an investment plan related to the efforts to come into full
 compliance with the new regulations. The 2017 capital expenditure
 costs expected for these plans are included in the Company’s
 capital expenditure projections.


## us-gaap:ConvertibleDebtTableTextBlock

[0001193125-17-166200:notes:6]
As of April 3, 2017 and January 2, 2017, the
 following summarizes the equity components of the convertible
 senior notes included in additional paid-in capital:

[0001193125-17-166200:notes:7]
|  |  | As of April 3, 2017 and January 2, 2017 |  |
|  |  | Embedded conversion option — Convertible Senior Notes |  |  | Embedded conversion option — Convertible Senior Notes Issuance Costs |  |  | Total |  |
|  |  | (in thousands) |  |
| Convertible senior notes due 2020 |  | $ | 60,227 |  |  | $ | (1,916 | ) |  | $ | 58,311 |  |


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001193125-17-166200:notes:8]
(13)
 Stock-Based Compensation

[0001193125-17-166200:notes:9]
[same as prior period, unchanged from 0001193125-16-758846:notes:9]

[0001193125-17-166200:notes:10]
|  |  | Quarter Ended |  |
|  |  | April 3, 2017 |  |  | March 28, 2016 |  |
|  |  | (In thousands) |  |
| Cost of goods sold |  | $ | 394 |  |  | $ | 320 |  |
| Selling and marketing |  |  | 253 |  |  |  | 210 |  |
| General and administrative |  |  | 2,981 |  |  |  | 1,716 |  |
| Stock-based compensation expense recognized |  | $ | 3,628 |  |  | $ | 2,246 |  |

[0001193125-17-166200:notes:11]
Performance-based Restricted Stock Units

[0001193125-17-166200:notes:12]
[same as prior period, unchanged from 0001193125-16-758846:notes:12]

[0001193125-17-166200:notes:13]
The Company records stock-based compensation expense for PRU
 awards granted based on management’s periodic assessment of
 the probability of the PRU awards vesting. For the quarter ended
 April 3, 2017, management determined that vesting of the PRU
 awards was probable. PRUs activity for the quarter ended
 April 3, 2017 was as follows:

[0001193125-17-166200:notes:14]
|  |  | Shares |  |  | Weighted Average Fair Value |  |
|  |  | (In thousands) |  |  |  |  |
| Outstanding target shares at January 2, 2017 |  |  | 406 |  |  | $ | 8.31 |  |
| Granted |  |  | 363 |  |  |  | 22.90 |  |
| Outstanding target shares at April 3, 2017 |  |  | 769 |  |  | $ | 15.20 |  |

[0001193125-17-166200:notes:15]
The fair value for PRUs granted is calculated using a Monte
 Carlo simulation model, as the TSR modifier contains a market
 condition. For the quarters ended April 3, 2017 and
 March 28, 2016 the following assumptions were used in
 determining the fair value:

[0001193125-17-166200:notes:16]
|  |  | April 3, 2017(1) |  |  | March 28, 2016(2) |  |
| Weighted-average fair value |  | $ | 22.90 |  |  | $ | 6.46 |  |
| Risk-free interest rate |  |  | 1.20 | % |  |  | 0.84 | % |
| Dividend yield |  |  | — |  |  |  | — |  |
| Expected volatility |  |  | 43 | % |  |  | 40 | % |
| Expected term in months |  |  | 21 |  |  |  | 24 |  |

[0001193125-17-166200:notes:17]
| (1) | Reflects the weighted-averages for the third year of the three-year performance period applicable to PRUs granted in 2015, second year of the three-year performance period applicable to PRUs granted in 2016 and first year of the three-year performance period applicable to PRUs granted in 2017. |

[0001193125-17-166200:notes:18]
| (2) | Reflects the weighted-averages for the third year of the three-year performance period applicable to PRUs granted in 2014, second year of the three-year performance period applicable to PRUs granted in 2015 and first year of the three-year performance period applicable to PRUs granted in 2016. |

[0001193125-17-166200:notes:19]
Restricted
 Stock Units

[0001193125-17-166200:notes:20]
The Company granted 946 and 1,683 RSUs during the quarters
 ended April 3, 2017 and March 28, 2016, respectively. The
 RSUs granted have a weighted-average fair value per unit of $15.78
 and $6.75 for the quarters ended April 3, 2017 and
 March 28, 2016, respectively. The fair value for RSUs granted
 is based on the closing share price of the Company’s common
 stock on the date of grant.

[0001193125-17-166200:notes:21]
[same as prior period, unchanged from 0001193125-16-758846:notes:17]

[0001193125-17-166200:notes:22]
The Company did not grant any stock option awards during the
 quarters ended April 3, 2017 and March 28,
 2016.

[0001193125-17-166200:notes:23]
Summary of
 Unrecognized Compensation Costs

[0001193125-17-166200:notes:24]
The following is a summary of total unrecognized compensation
 costs as of April 3, 2017:

[0001193125-17-166200:notes:25]
|  |  | Unrecognized Stock-Based Compensation Cost |  |  | Remaining Weighted Average Recognition Period |
|  |  | (In thousands) |  |  | (In years) |
| RSU awards |  | $ | 24,888 |  |  | 1.7 |
| PRU awards |  |  | 9,208 |  |  | 1.6 |
| Stock options |  |  | 120 |  |  | 2.2 |
|  |  | $ | 34,216 |  |  |  |


## us-gaap:InventoryDisclosureTextBlock

[0001193125-17-166200:notes:26]
(3)
 Inventories

[0001193125-17-166200:notes:27]
Inventories as of April 3, 2017 and January 2, 2017
 consist of the following:

[0001193125-17-166200:notes:28]
|  |  | As of |  |
|  |  | April 3, 2017 |  |  | January 2, 2017 |  |
|  |  | (In thousands) |  |
| Inventories: |  |  |  |  |  |  |  |  |
| Raw materials |  | $ | 78,392 |  |  | $ | 73,497 |  |
| Work-in-process |  |  | 105,318 |  |  |  | 105,094 |  |
| Finished goods |  |  | 91,382 |  |  |  | 90,621 |  |
|  |  | $ | 275,092 |  |  | $ | 269,212 |  |


## us-gaap:NewAccountingPronouncementsPolicyPolicyTextBlock

[0001193125-17-166200:notes:29]
Recently Adopted and
 Issued Accounting Standards

[0001193125-17-166200:notes:30]
In October 2016, the Financial Accounting Standards Board
 (FASB) issued Accounting Standards Update (ASU) 2016-16, Income Taxes (Topic 740):
 Intra-Entity Transfers of Assets Other Than Inventory. The
 objective of this update is to improve the accounting for the
 income tax consequences of intra-entity transfers of assets other
 than inventory by recognizing the income tax consequences when the
 transfer occurs. This ASU is effective for fiscal years beginning
 after December 15, 2017, including interim periods within
 those fiscal years. Early adoption is permitted. The Company is
 currently evaluating the new guidance to determine the impact it
 may have on its consolidated condensed financial
 statements.

[0001193125-17-166200:notes:31]
In August 2016, the FASB issued ASU 2016-15, Statement of Cash Flows
 (Topic 230). The objective of this update is to add or clarify
 guidance on the classification of certain cash receipts and
 payments in the statement of cash flows. This ASU is effective for
 fiscal years beginning after December 15, 2017, including
 interim periods within those annual periods and is to be applied
 utilizing a retrospective approach. Early adoption is permitted.
 The Company adopted this ASU 2016-15 in the first quarter of 2017
 and the adoption did not have a material impact on its consolidated
 condensed financial statements and related disclosures.

[0001193125-17-166200:notes:32]
In March 2016, the FASB issued ASU 2016-09, Stock Compensation (Topic
 718): Improvements to Employee Share-Based Payment Accounting.
 The objective of this update is to simplify several aspects of the
 accounting for employee share-based payment transactions, including
 the income tax consequences, classification of awards as either
 equity or liabilities, and classification on the statement of cash
 flows. This ASU is effective for fiscal years beginning after
 December 15, 2016, including interim periods within those
 fiscal years. The Company adopted ASU 2016-09 on January 3, 2017. The
 impact of the adoption did not have a material impact on the
 consolidated condensed financial statements and related
 disclosures.

[0001193125-17-166200:notes:33]
In February 2016, the FASB issued ASU 2016-02, Leases (Topic 842).
 The objective of this update is to increase transparency and
 comparability among organizations by recognizing lease assets and
 lease liabilities on the balance sheet and disclosing key
 information about leasing arrangements. This ASU is effective for
 fiscal years beginning after December 15, 2018, including
 interim periods within those annual periods and is to be applied
 utilizing a modified retrospective approach. The Company is
 currently evaluating the new guidance to determine the impact it
 may have on its consolidated financial statements and related
 disclosures.

[0001193125-17-166200:notes:34]
In May 2014, the FASB issued ASU 2014-09, Revenue from Contracts
 with Customers, as amended, which requires an entity to
 recognize the amount of revenue to which it expects to be entitled
 for the transfer of promised goods or services to customers. The
 ASU will replace most existing revenue recognition guidance in U.S.
 GAAP when it becomes effective. The new standard is effective for
 the Company at the beginning of fiscal year 2018, however
 application of the standard is allowed as early as the beginning of
 fiscal 2017. The standard permits the use of either the
 retrospective or cumulative effect transition method. The Company
 has assessed that the impact of the new guidance will result in a
 change to the timing of revenue recognition for the Company’s
 revenue stream from “point in time” upon physical
 delivery to an “over time” model and believes this
 transition could have a material impact on the Company’s
 consolidated financial statements upon adoption. As of
 April 3, 2017, management intends to apply the cumulative
 effect transition method. The Company has identified and is in the
 process of implementing changes to its systems, processes and
 internal controls to meet the standard update’s reporting and
 disclosure requirements.


## us-gaap:ReconciliationOfOperatingProfitLossFromSegmentsToConsolidatedTextBlock

[0001193125-17-166200:notes:35]
The
 Company accounts for inter-segment sales and transfers consistent
 with the Company’s revenue recognition policy. The
 inter-segment sales for the quarters ended April 3, 2017 and
 March 28, 2016, are sales primarily from the PCB to the
 E-M Solutions operating
 segment.

[0001193125-17-166200:notes:36]
|  |  | For the Quarters Ended |  |
|  |  | April 3, 2017 |  |  | March 28, 2016 |  |
|  |  | (In thousands) |  |
| Net Sales: |  |  |  |  |  |  |  |  |
| PCB |  | $ | 586,695 |  |  | $ | 529,945 |  |
| E-M Solutions |  |  | 41,669 |  |  |  | 56,478 |  |
| Total sales |  |  | 628,364 |  |  |  | 586,423 |  |
| Inter-segment sales |  |  | (3,117 | ) |  |  | (3,165 | ) |
| Total net sales |  | $ | 625,247 |  |  | $ | 583,258 |  |
| Operating Segment Income (Loss): |  |  |  |  |  |  |  |  |
| PCB |  | $ | 82,256 |  |  | $ | 49,367 |  |
| E-M Solutions |  |  | (1,642 | ) |  |  | 387 |  |
| Corporate |  |  | (22,132 | ) |  |  | (24,905 | ) |
| Total operating segment income |  |  | 58,482 |  |  |  | 24,849 |  |
| Amortization of definite-lived intangibles |  |  | (5,912 | ) |  |  | (5,947 | ) |
| Total operating income |  |  | 52,570 |  |  |  | 18,902 |  |
| Total other expense |  |  | (15,306 | ) |  |  | (20,575 | ) |
| Income (loss) before income taxes |  | $ | 37,264 |  |  | $ | (1,673 | ) |


## us-gaap:RestructuringImpairmentAndOtherActivitiesDisclosureTextBlock

[0001193125-17-166200:notes:37]
(2)
 Consolidation Plan, Restructuring and Impairment
 Charges

[0001193125-17-166200:notes:38]
On September 29, 2015, the Company announced a
 consolidation plan that resulted in the closure of the
 Company’s facilities in Cleveland, Ohio, Milpitas, California
 and Juarez, Mexico (the Consolidation Plan) and laid off
 approximately 480 employees at these sites. The Consolidation Plan
 was part of the Company’s integration strategy to improve
 total plant utilization, operational performance and customer focus
 following its acquisition of Viasystems. In accordance with the
 Consolidation Plan, the Company has combined its Cleveland and
 Milpitas facilities into its North Jackson, Ohio and Silicon
 Valley, California facilities, respectively, and closed its Juarez,
 Mexico facility.

[0001193125-17-166200:notes:39]
In connection with the Consolidation Plan and other global
 realignment restructuring efforts, the Company recognized employee
 separation, contract termination and other costs during the
 quarters ended April 3, 2017 and March 28,
 2016. Contract termination and other costs primarily
 represented plant closure costs for Cleveland, Ohio, Milpitas,
 California and Juarez, Mexico, as well as costs related to building
 operating leases associated with the downsizing of the St. Louis,
 Missouri office.

[0001193125-17-166200:notes:40]
The below table summarizes such restructuring costs by
 operating segment for the quarters ended April 3, 2017 and
 March 28, 2016:

[0001193125-17-166200:notes:41]
|  |  | For the Quarter Ended April 3, 2017 |  |  | For the Quarter Ended March 28, 2016 |  |
|  |  | Employee separation/ severance |  |  | Contract termination and other costs |  |  | Total |  |  | Employee separation/ severance |  |  | Contract termination and other costs |  |  | Total |  |
|  |  | (In thousands) |  |
| Operating Segment: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| PCB |  | $ | 127 |  |  | $ | 99 |  |  | $ | 226 |  |  | $ | 570 |  |  | $ | 611 |  |  | $ | 1,181 |  |
| E-M Solutions |  |  | — |  |  |  | 271 |  |  |  | 271 |  |  |  | 156 |  |  |  | 519 |  |  |  | 675 |  |
| Corporate |  |  | 33 |  |  |  | 79 |  |  |  | 112 |  |  |  | — |  |  |  | — |  |  |  | — |  |
|  |  | $ | 160 |  |  | $ | 449 |  |  | $ | 609 |  |  | $ | 726 |  |  | $ | 1,130 |  |  | $ | 1,856 |  |

[0001193125-17-166200:notes:42]
The below table shows the utilization of the accrued
 restructuring costs during the quarter ended April 3,
 2017:

[0001193125-17-166200:notes:43]
|  |  | Employee Separation/ Severance |  |  | Contract Termination and Other Costs |  |  | Total |  |
|  |  | (In thousands) |  |
| Accrued at January 2, 2017 |  | $ | 124 |  |  | $ | 1,042 |  |  | $ | 1,166 |  |
| Charged to expense |  |  | 160 |  |  |  | 449 |  |  |  | 609 |  |
| Amount paid |  |  | (284 | ) |  |  | (614 | ) |  |  | (898 | ) |
| Accrued at April 3, 2017 |  | $ | — |  |  | $ | 877 |  |  | $ | 877 |  |

[0001193125-17-166200:notes:44]
As of April 3, 2017, the Company has incurred
 approximately $16,941 of restructuring charges since the
 September 29, 2015 announcement. The Company estimates that it
 will incur total charges related to the Consolidation Plan of
 approximately $20,000.

[0001193125-17-166200:notes:45]
The Company also recognized $3,346 in impairment charges during
 the quarter ended March 28, 2016. As a result of the above
 mentioned plant closures and other plant realignment efforts,
 $1,393 of impairment charges were recognized in the consolidated
 condensed statement of operations related to machinery and
 equipment in the PCB operating segment. In addition, $1,953 of
 impairment charges were recognized in the consolidated condensed
 statement of operations related to capitalized software costs in
 the Corporate operating segment.


## us-gaap:ScheduleOfAccumulatedOtherComprehensiveIncomeLossTableTextBlock

[0001193125-17-166200:notes:46]
The following provides a summary of the components of
 accumulated other comprehensive income (loss) as of April 3,
 2017 and January 2, 2017:

[0001193125-17-166200:notes:47]
|  |  | Foreign Currency Translation |  |  | Gains (Losses) on Cash Flow Hedges |  |  | Total |  |
|  |  | (In thousands) |  |
| Ending balance at January 2, 2017 |  | $ | (43,149 | ) |  | $ | (1,180 | ) |  | $ | (44,329 | ) |
| Other comprehensive income before reclassifications |  |  | 6,619 |  |  |  | 68 |  |  |  | 6,687 |  |
| Amounts reclassified from accumulated other comprehensive income |  |  | — |  |  |  | 44 |  |  |  | 44 |  |
| Other comprehensive income |  |  | 6,619 |  |  |  | 112 |  |  |  | 6,731 |  |
| Ending balance at April 3, 2017 |  | $ | (36,530 | ) |  | $ | (1,068 | ) |  | $ | (37,598 | ) |


## us-gaap:ScheduleOfDebtInstrumentsTextBlock

[0001193125-17-166200:notes:48]
The following table summarizes the long-term debt of the
 Company as of April 3, 2017 and January 2,
 2017:

[0001193125-17-166200:notes:49]
|  |  | Average Effective Interest Rate as of April 3, 2017 |  |  | April 3, 2017 |  |  | Average Effective Interest Rate as of January 2, 2017 |  |  | January 2, 2017 |  |
|  |  | (In thousands) |  |
| Term loan due May 2021 |  |  | 5.25% |  |  | $ | 700,000 |  |  |  | 5.25% |  |  | $ | 700,000 |  |
| U.S. ABL revolving loan due May 2020 |  |  | 2.48% |  |  |  | 80,000 |  |  |  | 2.27% |  |  |  | 80,000 |  |
| Asia ABL revolving loan due May 2020 |  |  | 2.38% |  |  |  | 30,000 |  |  |  | 2.17% |  |  |  | 30,000 |  |
| Convertible Senior Notes due December 2020 |  |  | 1.75% |  |  |  | 250,000 |  |  |  | 1.75% |  |  |  | 250,000 |  |
| Capital lease |  |  | 6.43% |  |  |  | 1,815 |  |  |  | 6.43% |  |  |  | 1,798 |  |
|  |  |  |  |  |  |  | 1,061,815 |  |  |  |  |  |  |  | 1,061,798 |  |
| Less: Long-term debt unamortized discount |  |  |  |  |  |  | (35,301 | ) |  |  |  |  |  |  | (37,392 | ) |
| Long-term debt unamortized debt issuance costs |  |  |  |  |  |  | (4,465 | ) |  |  |  |  |  |  | (4,724 | ) |
|  |  |  |  |  |  |  | 1,022,049 |  |  |  |  |  |  |  | 1,019,682 |  |
| Less: current maturities |  |  |  |  |  |  | (160,658 | ) |  |  |  |  |  |  | (110,652 | ) |
| Long-term debt, less current maturities |  |  |  |  |  | $ | 861,391 |  |  |  |  |  |  | $ | 909,030 |  |


## us-gaap:IncomeTaxDisclosureTextBlock

[0001193125-17-166200:notes:50]
(7) Income
 Taxes

[0001193125-17-166200:notes:51]
The
 Company’s effective tax rate will generally differ from the
 U.S. federal statutory rate of 35% due to favorable tax rates
 associated with earnings from the Company’s operations in
 lower-tax jurisdictions
 such as China, the apportioned state income tax rates, generation
 of other credits and deductions available to the Company, changes
 in valuation allowances, and certain non-deductible items.

[0001193125-17-166200:notes:52]
During
 the quarter ended April 3, 2017, the Company’s effective
 tax rate was impacted by a net discrete benefit of $2,539 related
 to a tax incentive offset by accrued interest expense on existing
 uncertain tax positions. Additionally, no tax benefit was recorded
 on the losses incurred in the U.S. and certain foreign
 jurisdictions as a result of corresponding increases in the
 valuation allowances in these jurisdictions. The Company’s
 foreign earnings attributable to certain subsidiaries in China will
 be indefinitely reinvested in foreign jurisdictions and, therefore,
 no deferred tax liabilities for U.S. income taxes on undistributed
 earnings are recorded.

[0001193125-17-166200:notes:53]
Certain entities in China operated under tax incentives
 effective through 2017. The tax incentives decreased Chinese taxes
 by $5,481, which increased both basic and diluted earnings per
 share by $0.05 and $0.04, respectively, for the quarter ended
 April 3, 2017.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0001193125-17-166200:notes:54]
[same as prior period, unchanged from 0001193125-16-758846:notes:57]

[0001193125-17-166200:notes:55]
TTM Technologies, Inc. (the Company or TTM) is a leading global
 printed circuit board (PCB) manufacturer, focusing on quick-turn
 and volume production of technologically complex PCBs and
 electro-mechanical solutions (E-M Solutions). The Company provides
 time-to-market and advanced
 technology products and offers a one-stop manufacturing solution to
 customers from engineering support to prototype development through
 final mass production. This one-stop manufacturing solution allows
 the Company to align technology developments with the diverse needs
 of the Company’s customers and to enable them to reduce the
 time required to develop new products and bring them to
 market.

[0001193125-17-166200:notes:56]
The Company serves a diversified customer base in various
 markets throughout the world, including networking/communications
 infrastructure products, smartphones and touchscreen tablets, as
 well as aerospace and defense, automotive, high-end computing, and medical,
 industrial and instrumentation related products. The
 Company’s customers include both original equipment
 manufacturers (OEMs) and electronic manufacturing services (EMS)
 providers.

[0001193125-17-166200:notes:57]
The accompanying consolidated condensed financial statements
 have been prepared by the Company, without audit, pursuant to the
 rules and regulations of the Securities and Exchange Commission
 (SEC). Certain information and disclosures normally included in
 financial statements prepared in accordance with accounting
 principles generally accepted in the United States of America (U.S.
 GAAP) have been condensed or omitted pursuant to such rules and
 regulations. These consolidated condensed financial statements
 reflect all adjustments (consisting only of normal recurring
 adjustments) which, in the opinion of management, are necessary to
 present fairly the financial position, the results of operations
 and cash flows of the Company for the periods presented. It is
 suggested that these consolidated condensed financial statements be
 read in conjunction with the consolidated financial statements and
 the notes thereto included in the Company’s most recent
 Annual Report on Form 10-K. The results of operations for
 the interim periods are not necessarily indicative of the results
 to be expected for the full year. The preparation of financial
 statements in accordance with U.S. GAAP requires management to make
 estimates and assumptions that affect the amounts reported in the
 Company’s consolidated condensed financial statements and
 accompanying notes. Actual results could differ materially from
 those estimates. The Company uses a 13-week fiscal quarter accounting
 period with the fourth quarter ending on the Monday nearest
 December 31.


## us-gaap:ScheduleOfEarningsPerShareBasicAndDilutedTableTextBlock

[0001193125-17-166200:notes:58]
The following is a reconciliation of the numerator and
 denominator used to calculate basic earnings (loss) per share and
 diluted earnings (loss) per share for the quarters ended
 April 3, 2017 and March 28, 2016:

[0001193125-17-166200:notes:59]
|  |  | Quarter Ended |  |
|  |  | April 3, 2017 |  |  | March 28, 2016 |  |
|  |  | (In thousands, except per share amounts) |  |
| Basic earnings (loss): |  |  |  |  |  |  |  |  |
| Basic earnings (loss) |  | $ | 32,959 |  |  | $ | (7,264 | ) |
| Diluted earnings (loss): |  |  |  |  |  |  |  |  |
| Net income (loss) attributable to TTM Technologies, Inc. stockholders |  | $ | 32,959 |  |  | $ | (7,264 | ) |
| Interest expense from convertible senior notes, net of tax |  |  | 3,394 |  |  |  | — |  |
| Diluted earnings (loss) |  | $ | 36,353 |  |  | $ | (7,264 | ) |
| Basic weighted average shares |  |  | 100,932 |  |  |  | 99,596 |  |
| Dilutive effect of performance-based restricted stock units, restricted stock units and stock options |  |  | 1,867 |  |  |  | — |  |
| Dilutive effect of outstanding warrants |  |  | 2,183 |  |  |  | — |  |
| Dilutive effect of assumed conversion of convertible senior notes outstanding |  |  | 25,940 |  |  |  | — |  |
| Diluted shares |  |  | 130,922 |  |  |  | 99,596 |  |
| Income (loss) per share attributable to TTM Technologies, Inc. stockholders: |  |  |  |  |  |  |  |  |
| Basic |  | $ | 0.33 |  |  | $ | (0.07 | ) |
| Diluted |  | $ | 0.28 |  |  | $ | (0.07 | ) |


## us-gaap:ScheduleofFiniteLivedIntangibleAssetsFutureAmortizationExpenseTableTextBlock

[0001193125-17-166200:notes:60]
[same as prior period, unchanged from 0001193125-16-758846:notes:63]

[0001193125-17-166200:notes:61]
|  |  | (In thousands) |  |
| Remaining 2017 |  | $ | 17,732 |  |
| 2018 |  |  | 22,870 |  |
| 2019 |  |  | 18,746 |  |
| 2020 |  |  | 18,746 |  |
| 2021 |  |  | 18,746 |  |
| Thereafter |  |  | 23,848 |  |
|  |  | $ | 120,688 |  |


## us-gaap:ScheduleOfGoodwillTextBlock

[0001193125-17-166200:notes:62]
As of
 April 3, 2017 and January 2, 2017, goodwill was as
 follows:

[0001193125-17-166200:notes:63]
|  |  | Total |  |
|  |  | (In thousands) |  |
| Balance as of January 2, 2017 |  | $ | 372,609 |  |
| Foreign currency translation adjustment and other |  |  | (23 | ) |
| Balance as of April 3, 2017 |  | $ | 372,586 |  |


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0001193125-17-166200:notes:64]
(8) Accumulated Other
 Comprehensive Income (Loss)

[0001193125-17-166200:notes:65]
For the quarters ended April 3, 2017 and March 28,
 2016, $44 and $42 net of tax, respectively, were reclassified out
 of accumulated other comprehensive income (loss) to depreciation
 expense related to cash flow hedges.


## us-gaap:FairValueAssetsMeasuredOnNonrecurringBasisTextBlock

[0001193125-17-166200:notes:66]
For the quarter ended March 28, 2016, the following assets
 were measured at fair value on a nonrecurring basis using the type
 of inputs shown:

[0001193125-17-166200:notes:67]
|  |  |  |  |  | Fair Value Measurements Using: |  |
|  |  | March 28, 2016 |  |  | Level 1 Inputs |  |  | Level 2 Inputs |  |  | Level 3 Inputs |  |  | Total Losses for the Quarter Ended March 28, 2016 |  |
|  |  | (In thousands) |  |
| Assets held for sale |  | $ | 155 |  |  | $ | — |  |  | $ | 155 |  |  | $ | — |  |  | $ | 1,393 |  |
| Long-lived assets held and use |  |  | 2,254 |  |  |  | — |  |  |  | — |  |  |  | 2,254 |  |  |  | 1,953 |  |
|  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | $ | 3,346 |  |


## us-gaap:IntangibleAssetsDisclosureTextBlock

[0001193125-17-166200:notes:68]
(5) Definite-lived
 Intangibles

[0001193125-17-166200:notes:69]
As of April 3, 2017 and January 2, 2017, the
 components of definite-lived intangibles were as
 follows:

[0001193125-17-166200:notes:70]
|  |  | Gross Amount |  |  | Accumulated Amortization |  |  | Foreign Currency Translation Adjustment |  |  | Net Carrying Amount |  |  | Weighted Average Amortization Period |  |
|  |  | (In thousands) |  |  | (years) |  |
| April 3, 2017: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Customer relationships |  | $ | 203,563 |  |  | $ | (84,118 | ) |  | $ | 89 |  |  | $ | 119,534 |  |  |  | 8.1 |  |
| Technology |  |  | 3,000 |  |  |  | (1,846 | ) |  |  | — |  |  |  | 1,154 |  |  |  | 3.0 |  |
|  |  | $ | 206,563 |  |  | $ | (85,964 | ) |  | $ | 89 |  |  | $ | 120,688 |  |  |  |  |  |
| January 2, 2017: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Customer relationships |  | $ | 203,563 |  |  | $ | (78,473 | ) |  | $ | 119 |  |  | $ | 125,209 |  |  |  | 8.1 |  |
| Technology |  |  | 3,000 |  |  |  | (1,596 | ) |  |  | — |  |  |  | 1,404 |  |  |  | 3.0 |  |
|  |  | $ | 206,563 |  |  | $ | (80,069 | ) |  | $ | 119 |  |  | $ | 126,613 |  |  |  |  |  |

[0001193125-17-166200:notes:71]
The April 3, 2017 and January 2, 2017 definite-lived
 intangible balances include foreign currency translation
 adjustments related to foreign subsidiaries with functional
 currencies other than the U.S. Dollar.

[0001193125-17-166200:notes:72]
Definite-lived intangibles are generally amortized using the
 straight line method of amortization over the useful life, with the
 exception of certain customer relationship intangibles, which are
 amortized using an accelerated method of amortization based on
 estimated cash flows. Amortization expense was $5,912 and $5,947,
 for the quarters ended April 3, 2017 and March 28, 2016,
 respectively.


## us-gaap:ConcentrationRiskDisclosureTextBlock

[0001193125-17-166200:notes:73]
(9) Significant Customers
 and Concentration of Credit Risk

[0001193125-17-166200:notes:74]
In the
 normal course of business, the Company extends credit to its
 customers. Most customers to which the Company extends credit are
 located outside the United States. The Company performs ongoing
 credit evaluations of customers, does not require collateral, and
 considers the credit risk profile of the entity from which the
 receivable is due in further evaluating collection risk.

[0001193125-17-166200:notes:75]
The
 Company’s customers include both OEMs and EMS companies. The
 Company’s OEM customers often direct a significant portion of
 their purchases through EMS companies. While the Company’s
 customers include both OEM and EMS providers, the Company measures
 customer concentration based on OEM companies, as they are the
 ultimate end customers.

[0001193125-17-166200:notes:76]
For
 the quarters ended April 3, 2017 and March 28, 2016, one
 customer accounted for approximately 16% and 10%, respectively, of
 the Company’s net sales. There were no other customers that
 accounted for 10% or more of net sales for the quarters ended
 April 3, 2017 and March 28, 2016.


## us-gaap:EarningsPerShareTextBlock

[0001193125-17-166200:notes:77]
(12)
 Earnings Per Share

[0001193125-17-166200:notes:78]
For the quarter ended April 3, 2017, performance-based
 restricted stock units (PRUs), restricted stock units (RSUs) and
 stock options to purchase 179 shares of common stock were not
 considered in calculating diluted earnings per share because the
 options’ exercise prices or the total expected proceeds under
 the treasury stock method for PRUs, RSUs or stock options was
 greater than the average market price of common shares during the
 applicable quarter and, therefore, the effect would be
 anti-dilutive.

[0001193125-17-166200:notes:79]
For the quarter ended March 28, 2016, potential shares of
 common stock, consisting of stock options to purchase approximately
 387 shares of common stock at exercise prices ranging from $5.78 to
 $16.82 per share, 3,118 RSUs, and 301 PRUs were not included in the
 computation of diluted earnings per share because the Company
 incurred a net loss and, as a result, the impact would be
 anti-dilutive.

[0001193125-17-166200:notes:80]
For the quarter ended March 28, 2016, the effect of shares
 of common stock related to the Company’s convertible senior
 notes, based on the if-converted method, were not included in
 the computation of dilutive earnings per share because the Company
 incurred a net loss from operations and, as a result, the impact
 would be anti-dilutive.

[0001193125-17-166200:notes:81]
Outstanding warrants for the quarter ended March 28, 2016,
 to purchase common stock of 25,940 were not included in the
 computation of dilutive earnings per share because the strike price
 of the warrants to purchase the Company’s common stock were
 greater than the average market price of common shares during the
 applicable quarter, and therefore, the effect would be
 anti-dilutive.


## us-gaap:FairValueDisclosuresTextBlock

[0001193125-17-166200:notes:82]
(10) Fair Value
 Measures

[0001193125-17-166200:notes:83]
The Company measures at fair value its financial and
 non-financial assets by
 using a fair value hierarchy that prioritizes the inputs to
 valuation techniques used to measure fair value. Fair value is the
 price that would be received to sell an asset or paid to transfer a
 liability in an orderly transaction between market participants at
 the measurement date, essentially an exit price, based on the
 highest and best use of the asset or liability.

[0001193125-17-166200:notes:84]
The carrying amount and estimated fair value of the
 Company’s financial instruments at April 3, 2017 and
 January 2, 2017 were as follows:

[0001193125-17-166200:notes:85]
|  |  | April 3, 2017 |  |  | January 2, 2017 |  |
|  |  | Carrying Amount |  |  | Fair Value |  |  | Carrying Amount |  |  | Fair Value |  |
|  |  | (In thousands) |  |
| Term and Revolving Loans |  | $ | 809,073 |  |  | $ | 820,500 |  |  | $ | 809,023 |  |  | $ | 818,750 |  |
| Convertible senior notes due 2020 |  |  | 211,161 |  |  |  | 431,500 |  |  |  | 208,861 |  |  |  | 380,875 |  |
| Capital lease |  |  | 1,815 |  |  |  | 1,815 |  |  |  | 1,798 |  |  |  | 1,798 |  |

[0001193125-17-166200:notes:86]
The fair value of the long-term debt was estimated based on
 quoted market prices or discounting the debt over its life using
 current market rates for similar debt as of April 3, 2017 and
 January 2, 2017, which are considered Level 1 and
 Level 2 inputs.

[0001193125-17-166200:notes:87]
The fair value of the convertible senior notes was estimated
 based on quoted market prices of the securities on an active
 exchange, which are considered Level 1 and Level 2
 inputs.

[0001193125-17-166200:notes:88]
As of April 3, 2017 and January 2, 2017, the
 Company’s other financial instruments also included cash and
 cash equivalents, accounts receivable, accounts payable and
 equipment payables. Due to short-term maturities, the carrying
 amount of these instruments approximates fair value. Our cash and
 cash equivalents at April 3, 2017 consisted of $57,322 held in
 the U.S., with the remaining $225,549 held by foreign
 subsidiaries.

[0001193125-17-166200:notes:89]
The majority of the Company’s non-financial assets and liabilities,
 which include goodwill, intangible assets, inventories, and
 property, plant and equipment, are not required to be carried at
 fair value on a recurring basis. However, if certain triggering
 events occur (or are tested at least annually in the case of
 goodwill) such that a non-financial instrument is required
 to be evaluated for impairment, based upon a comparison of the
 non-financial
 instrument’s fair value to its carrying value, an impairment
 is recorded to reduce the carrying value to the fair value, if the
 carrying value exceeds the fair value.

[0001193125-17-166200:notes:90]
There was no impairment of long-lived assets recognized for the
 quarter ended April 3, 2017.

[0001193125-17-166200:notes:91]
The fair values of assets held for sale were primarily
 determined using appraisals and comparable prices of similar
 assets, which are considered to be Level 2 inputs.

[0001193125-17-166200:notes:92]
Additionally, the Company had capitalized software costs in
 accordance with U.S. GAAP. During the first quarter ended
 March 28, 2016, the Company determined that certain
 capitalized costs no longer had benefit. Because the primary
 determination of fair value was based on management’s
 assumptions and estimates of capitalized costs to dispose, the
 resulting fair value is considered a Level 3 input.


## us-gaap:GoodwillDisclosureTextBlock

[0001193125-17-166200:notes:93]
(4)
 Goodwill

[0001193125-17-166200:notes:94]
All
 goodwill relates to the Company’s PCB reportable
 segment.

[0001193125-17-166200:notes:95]
Goodwill balances include foreign currency translation
 adjustments related to foreign subsidiaries with functional
 currencies other than the U.S. Dollar.


## us-gaap:LongTermDebtTextBlock

[0001193125-17-166200:notes:96]
(6)
 Long-term Debt and Letters of Credit

[0001193125-17-166200:notes:97]
Term
 and Revolving Loans

[0001193125-17-166200:notes:98]
The Company maintains a Term Loan Credit Agreement (Term Loan),
 a $200,000 U.S. Asset-Based Lending Credit Agreement (U.S. ABL),
 and a $150,000 Asia Asset-Based Lending Credit Agreement (Asia ABL)
 (collectively the ABL Revolving Loans).

[0001193125-17-166200:notes:99]
The Term Loan bears interest at a floating rate of LIBOR, with
 a 1.0% LIBOR floor, plus an applicable interest margin of 4.25%, or
 JP Morgan Chase Bank’s prime rate, with a 2% floor, plus a
 margin of 3.25%, at the Company’s option. At April 3,
 2017 the weighted average interest rate on the outstanding
 borrowings under the Term Loan was 5.25%. There is no provision,
 other than an event of default, for the interest margin to
 increase. The Term Loan will mature on May 31, 2021. The Term
 Loan is secured by a significant amount of the assets of the
 Company and a pledge of 65% of voting stock of the Company’s
 first tier foreign subsidiaries and is structurally senior to the
 Company’s convertible senior notes. See Convertible Senior
 Notes below.

[0001193125-17-166200:notes:100]
The U.S. ABL consists of three tranches comprised of a
 revolving credit facility of up to $200,000, a letter of credit
 facility of up to $50,000, and swingline loans of up to $30,000,
 provided that at no time may amounts outstanding under the tranches
 exceed in aggregate $200,000 or the applicable borrowing base,
 which is a percentage of the principal amount of Eligible Accounts,
 as defined in the U.S. ABL agreement. Borrowings under the U.S. ABL
 bear interest at either a floating rate of LIBOR plus a margin of
 150 basis points or JP Morgan Chase Bank’s prime rate plus a
 margin of 50 basis points, at the Company’s option. At
 April 3, 2017, the weighted average interest rate on the
 outstanding borrowings under the U.S. ABL was 2.48%. The applicable
 margin can vary based on the remaining availability of the
 facility, from 125 to 175 basis points for LIBOR-based loans and
 from 25 to 75 basis points for JP Morgan Chase Bank’s prime
 rate-based loans. Other than availability and an event of default,
 there are no other provisions for the interest margin to increase.
 The U.S. ABL will mature on May 31, 2020. Loans made under the
 U.S. ABL are secured first by all of the Company’s domestic
 cash, receivables and inventories as well as by a second position
 against a significant amount of the assets of the Company and a
 pledge of 65% of voting stock of the Company’s first tier
 foreign subsidiaries and are structurally senior to the
 Company’s convertible senior notes. See Convertible Senior
 Notes below. At April 3, 2017, $80,000 of the U.S. ABL was
 outstanding and classified as short-term debt. The Company and its
 domestic subsidiaries have fully and unconditionally guaranteed the
 full and timely payment of all Term Loan and U.S. ABL related
 obligations.

[0001193125-17-166200:notes:101]
The Asia ABL consists of two tranches comprised of a revolving
 credit facility of up to $150,000 and a letter of credit facility
 of up to $100,000, provided that at no time may amounts outstanding
 under both tranches exceed in aggregate $150,000 or the applicable
 borrowing base, which is a percentage of the principal amount of
 Eligible Accounts, as defined in the Asia ABL agreement. Borrowings
 under the Asia ABL bear interest at a floating rate of LIBOR plus
 140 basis points. At April 3, 2017, the weighted average
 interest rate on the outstanding borrowings under the Asia ABL was
 2.38%. There is no provision, other than an event of default, for
 the interest margin to increase. The Asia ABL will mature on
 May 22, 2020. Loans made under the Asia ABL are secured by a
 portion of the Company’s Asia Pacific cash and receivables
 and are structurally senior to the Company’s domestic
 obligations, including the convertible senior notes. See
 Convertible Senior Notes below. The Company’s Asia Pacific
 subsidiary and certain of its subsidiaries have fully and
 unconditionally guaranteed the full and timely payment of all Asia
 ABL related obligations. At April 3, 2017, $30,000 of the Asia
 ABL was outstanding.

[0001193125-17-166200:notes:102]
The Company is no longer required to make any quarterly
 scheduled payments for the remaining term of the outstanding Term
 Loan balance due to mandatory payments and optional loan
 prepayments applied to date. Additionally, based on certain
 parameters defined in the Term Loan agreement, including a secured
 leverage ratio, the Company is also not required to make any
 additional principal payments for fiscal year 2017 as our secured
 leverage ratio is less than or equal to 1.5. The Company may be
 required to make additional principal payments in future years, if
 the Company’s secured leverage ratio is greater than 1.5. Any
 remaining outstanding balances under the Term Loan are due at the
 maturity date of May 31, 2021. Subsequent to the quarter ended
 April 3, 2017, the Company made an optional debt principal
 prepayment totaling $50,000. Borrowings under the Term Loan are
 subject to financial and operating covenants including maintaining
 a maximum total leverage ratio. Under the occurrence of certain
 events, the U.S. ABL and the Asia ABL are subject to financial and
 operational covenants, including maintaining minimum fixed charge
 coverage ratios. At April 3, 2017, the Company was in
 compliance with the covenants under the Term Loan, the U.S. ABL and
 the Asia ABL.

[0001193125-17-166200:notes:103]
As of April 3, 2017 and January 2, 2017, remaining
 unamortized debt issuance costs of $927 and $977, respectively,
 related to the Term Loan. These debt issuance costs are recorded as
 a reduction of the Term Loan at April 3, 2017 and
 January 2, 2017, respectively, and are amortized over the
 duration of the Term Loan into interest expense using an effective
 interest rate of 5.29%.

[0001193125-17-166200:notes:104]
Additionally, remaining unamortized debt issuance costs related
 to the ABL Revolving Loans were $3,173 and $3,423 as of
 April 3, 2017 and January 2, 2017, respectively. These
 debt issuance costs are included in other non-current assets and are amortized to
 interest expense over the duration of the ABL Revolving Loans using
 the straight line method of amortization.

[0001193125-17-166200:notes:105]
At April 3, 2017, the remaining weighted average
 amortization period for the unamortized debt issuance costs for
 both the Term Loan and the ABL Revolving Loans was 3.4
 years.

[0001193125-17-166200:notes:106]
The Company is required to pay a commitment fee of 0.25% to
 0.375% per annum on any unused portion of the U.S. ABL or Asia
 ABL. The Company incurred total commitment fees related to unused
 borrowing availability of $187 and $194 for the quarters ended
 April 3, 2017 and March 28, 2016, respectively. As of
 April 3, 2017, the outstanding amount of the Term Loan was
 $700,000, of which $50,000 is included in short-term debt and the
 remaining $650,000 is included as long-term debt. Additionally,
 $80,000 of the U.S. ABL and $30,000 of the Asia ABL was outstanding
 as of April 3, 2017. Available borrowing capacity under the
 U.S. ABL and Asia ABL was $113,503 and $99,628, which considers
 letters of credit outstanding of $6,497 and $20,372 mentioned
 below, respectively, at April 3, 2017.

[0001193125-17-166200:notes:107]
Letters
 of Credit

[0001193125-17-166200:notes:108]
The Company has up to $50,000 and $100,000 Letters of Credit
 Facilities under the U.S. ABL and the Asia ABL, respectively, as
 mentioned above. As of April 3, 2017, letters of credit in the
 amount of $6,497 were outstanding under the U.S. ABL and $20,372
 were outstanding under the Asia ABL with various expiration dates
 through March 2018.

[0001193125-17-166200:notes:109]
Convertible Senior Notes due 2020

[0001193125-17-166200:notes:110]
The Company issued 1.75% convertible senior notes due
 December 15, 2020, in a public offering for an aggregate
 principal amount of $250,000 in 2013. The convertible senior notes
 bear interest at a rate of 1.75% per annum. Interest is
 payable semiannually in arrears on June 15 and
 December 15 of each year. The convertible senior notes are
 senior unsecured obligations and rank equally to the
 Company’s future unsecured senior indebtedness and are senior
 in right of payment to any of the Company’s future
 subordinated indebtedness.

[0001193125-17-166200:notes:111]
Conversion: At any time prior to
 March 15, 2020, holders may convert their convertible senior
 notes into cash and, if applicable, into shares of the
 Company’s common stock based on a conversion rate of 103.7613
 shares of the Company’s common stock per $1 principal amount
 of convertible senior notes, subject to adjustment, under the
 following circumstances: (1) during any calendar quarter
 beginning after March 31, 2015 (and only during such calendar
 quarter), if the last reported sale price of our common stock for
 at least 20 trading days during the 30 consecutive trading days
 ending on the last trading day of the immediately preceding
 calendar quarter is greater than or equal to 130% of the applicable
 conversion price on each applicable trading day of such preceding
 calendar quarter; (2) during the five business day period
 after any 10 consecutive trading day period in which the trading
 price per note for each day of that 10 consecutive trading day
 period was less than 98% of the product of the last reported sale
 price of the Company’s common stock and the conversion rate
 on such day; or (3) upon the occurrence of specified corporate
 transactions described in the indenture governing the notes. As of
 April 3, 2017, the conversion criteria had been met under
 condition (1) as described above, allowing holders to give
 notice of conversion in both the first and second quarter of
 2017.

[0001193125-17-166200:notes:112]
On or after March 15, 2020 until the close of business on
 the third scheduled trading day preceding the maturity date,
 holders may convert their notes at any time, regardless of the
 foregoing circumstances. Upon conversion, for each $1 principal
 amount of notes, the Company will pay shares of our common stock,
 cash or a combination of cash and shares of our common stock at its
 election, if applicable, based on a daily conversion value
 calculated on a proportionate basis for each day of the 80 trading
 day observation period. All conversions occurring on the same date
 or on or after March 15, 2020 shall be settled using the same
 settlement method. Additionally, in the event of a fundamental
 change as defined in the indenture governing the notes, or other
 conversion rate adjustments such as share splits or combinations,
 other distributions of shares, cash or other assets to
 stockholders, including self-tender transactions (Other Conversion
 Rate Adjustments), the conversion rate may be modified to adjust
 the number of shares per $1 principal amount of the notes. As of
 April 3, 2017, none of the criteria for a fundamental change
 or a conversion rate adjustment had been met.

[0001193125-17-166200:notes:113]
The maximum number of shares issuable upon conversion,
 including the effect of a fundamental change and subject to Other
 Conversion Rate Adjustments, would be 32,425.

[0001193125-17-166200:notes:114]
Note Repurchase: The Company is not
 permitted to redeem the convertible senior notes at any time prior
 to maturity. In the event of a fundamental change or certain
 default events, as defined in the indenture governing the notes,
 holders may require the Company to repurchase for cash all or a
 portion of their convertible senior notes at a price equal to 100%
 of the principal amount, plus any accrued and unpaid
 interest.

[0001193125-17-166200:notes:115]
Convertible Note Hedge and Warrant
 Transaction: In connection with the
 issuance of the convertible senior notes due 2020, the Company
 entered into a convertible note hedge and warrant transaction (Call
 Spread Transaction), with respect to the Company’s common
 stock. The convertible note hedge consists of the Company’s
 option to purchase up to 25,940 common stock shares at a price of
 $9.64 per share. The hedge expires on December 15, 2020 and
 can only be executed upon the conversion of the above mentioned
 convertible senior notes due 2020. Additionally, the Company sold
 warrants to purchase 25,940 shares of its common stock at a price
 of $14.26 per share. The warrants expire ratably from March 2021
 through January 2022. The 2020 Call Spread Transaction has no
 effect on the terms of the convertible senior notes due 2020 and
 reduces potential dilution by effectively increasing the conversion
 price of the convertible senior notes due 2020 to $14.26 per share
 of the Company’s common stock.

[0001193125-17-166200:notes:116]
The components of interest expense resulting from the
 convertible senior notes for the quarters ended April 3, 2017
 and March 28, 2016 are as follows:

[0001193125-17-166200:notes:117]
|  |  | For the Quarter Ended |  |
|  |  | April 3, 2017 |  |  | March 28, 2016 |  |
|  |  | (In thousands) |  |
| Contractual coupon interest |  | $ | 1,094 |  |  | $ | 1,094 |  |
| Amortization of debt discount |  | $ | 2,091 |  |  | $ | 1,960 |  |
| Amortization of debt issuance costs |  | $ | 209 |  |  | $ | 196 |  |

[0001193125-17-166200:notes:118]
As of April 3, 2017 and January 2, 2017, there
 remains unamortized debt discount of $35,301 and $37,392,
 respectively, and debt issuance costs of $3,538 and $3,747,
 respectively, related to the convertible senior notes. These debt
 discount and debt discount issuance costs are recorded as a
 reduction of the convertible senior notes and are being amortized
 to interest expense over the term of the convertible senior notes
 using the effective interest rate method. At April 3, 2017,
 the remaining weighted average amortization period for the
 unamortized senior convertible note discount and debt issuance
 costs was 3.7 years.

[0001193125-17-166200:notes:119]
For the quarters ended April 3, 2017 and March 28,
 2016, the amortization of the convertible senior notes due 2020
 debt discount and debt issuance costs is based on an effective
 interest rate of 6.48%.

[0001193125-17-166200:notes:120]
Other
 Credit Facility

[0001193125-17-166200:notes:121]
Additionally, the Company is party to a revolving loan credit
 facility (Chinese Revolver) with a lender in China. Under this
 arrangement, the lender has made available to the Company
 approximately $30,500 in unsecured borrowing with all terms of the
 borrowing to be negotiated at the time the Chinese Revolver is
 drawn upon. There are no commitment fees on the unused portion of
 the Chinese Revolver, and this arrangement expires in January 2018.
 As of April 3, 2017, the Chinese Revolver had not been drawn
 upon.


## us-gaap:RelatedPartyTransactionsDisclosureTextBlock

[0001193125-17-166200:notes:122]
(15) Related Party
 Transactions

[0001193125-17-166200:notes:123]
In the normal course of business, the Company’s foreign
 subsidiaries purchase laminate and prepreg from related parties in
 which a significant shareholder of the Company holds an equity
 interest. For the quarters ended April 3, 2017 and
 March 28, 2016, the Company’s foreign subsidiaries
 purchased $13,540 and $15,998, respectively, of laminate and
 prepreg from these related parties.

[0001193125-17-166200:notes:124]
Dongguan Shengyi Electronics Ltd. (SYE) is also a related party
 as it is a wholly owned subsidiary of an entity in which a
 significant shareholder of the Company holds an equity interest.
 The Company sells PCBs to SYE and purchases PCBs including various
 services relating to PCB manufacturing from SYE. Sales to SYE for
 the quarters ended April 3, 2017 and March 28, 2016 were
 $31 and $311, respectively. Purchases of PCBs including various
 services relating to PCB manufacturing for the quarter ended
 March 28, 2016 was $28. There were no purchases of PCBs or any
 services relating to PCB manufacturing for the quarter ended
 April 3, 2017.

[0001193125-17-166200:notes:125]
As of April 3, 2017 and January 2, 2017, the
 Company’s consolidated condensed balance sheets included
 $17,884 and $15,836, respectively, in accounts payable due to
 related parties primarily for purchases of laminate and prepreg and
 such balances are included as a component of accounts payable on
 the consolidated condensed balance sheets. Additionally, the
 Company’s consolidated condensed balance sheets included $124
 and $192, respectively, in accounts receivable due from a related
 party for sales of PCBs to SYE, as mentioned above, and such
 balances are included as a component of accounts receivable, net on
 the consolidated condensed balance sheets.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001193125-17-166200:notes:126]
(14) Segment
 Information

[0001193125-17-166200:notes:127]
The
 operating segments reported below are the Company’s segments
 for which separate financial information is available and upon
 which operating results are evaluated by the chief operating
 decision maker to assess performance and to allocate resources. The
 Company has reviewed its reportable operating segments and
 determined it continues to have two reportable operating segments:
 PCB and E-M Solutions. The
 PCB reportable segment is comprised of multiple operating segments.
 This determination was made based on the criteria of earning
 revenues and incurring expenses, the Company’s organizational
 structure which has segment managers who report to the chief
 operating decision maker, discrete financial information, and the
 aggregation of similar operating segments into reportable operating
 segments. Factors considered to determine whether operating
 segments can be aggregated into reportable segments included
 similarity regarding economic characteristics, products, production
 processes, type or classes of customers, distribution methods, and
 regulatory environments.

[0001193125-17-166200:notes:128]
The
 Company, including the chief operating decision maker, evaluates
 segment performance based on operating segment income, which is
 operating income before amortization of intangibles. Interest
 expense and interest income are not presented by segment since they
 are not included in the measure of segment profitability reviewed
 by the chief operating decision maker. All inter-segment
 transactions have been eliminated..

[0001193125-17-166200:notes:129]
The
 Corporate category includes operating expenses that are not
 included in the segment operating performance measures. Corporate
 consists primarily of corporate governance functions such as
 finance, accounting, corporate sales, information technology,
 facilities, corporate operations and human resources
 personnel.
