# TTMI note change history — 0001193125-16-758846 → 0001193125-17-166200


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2017-05-11):
[0001193125-17-166200:note_history:1]
The
 Company is subject to various legal matters, which it considers
 normal for its business activities. While the Company currently
 believes that the amount of any reasonably possible loss for known
 matters would not be material to the Company’s financial
 condition, the outcome of these actions is inherently difficult to
 predict. In the event of an adverse outcome, the ultimate potential
 loss could have a material adverse effect on the Company’s
 financial condition or results of operations in a particular
 period. The Company has accrued amounts for its loss contingencies
 which are probable and estimable as of April 3, 2017 and
 January 2, 2017. However, these amounts are not material to
 the consolidated condensed financial statements of the
 Company.
  (was, 2016-11-03, similarity 0.9807):
[0001193125-16-758846:note_history:1]
The
 Company is subject to various legal matters, which it considers
 normal for its business activities. While the Company currently
 believes that the amount of any reasonably possible loss for known
 matters would not be material to the Company’s financial
 condition, the outcome of these actions is inherently difficult to
 predict. In the event of an adverse outcome, the ultimate potential
 loss could have a material adverse effect on the Company’s
 financial condition or results of operations in a particular
 period. The Company has accrued amounts for its loss contingencies
 which are probable and estimable as of September 26, 2016 and
 December 28, 2015. However, these amounts are not material to
 the consolidated condensed financial statements of the
 Company.

- changed (2017-05-11):
[0001193125-17-166200:note_history:2]
The
 process to manufacture PCBs requires adherence to city, county,
 state, federal, and foreign environmental regulations regarding the
 storage, use, handling and disposal of chemicals, solid wastes and
 other hazardous materials, as well as compliance with air quality
 standards and chemical use reporting. The Company believes that its
 facilities in the United States, Canada and Mexico comply in all
 material respects with applicable environmental laws and
 regulations. In China, governmental authorities have adopted new
 rules and regulations governing environmental issues. An update to
 the Chinese environmental waste water law was issued in late 2012,
 allowing for an interim period in which plants subject to such law
 may install equipment that meets the new regulatory regime. Some of
 the Company’s plants in China are not yet in full compliance
 with the updated environmental regulations. The Company believes it
 has developed plans acceptable to the Chinese government and is in
 the process of implementing these plans. The Company does not
 anticipate any immediate risk of government fines or temporary
 closure of its Chinese plants. The Company has established and
 enacted an investment plan related to the efforts to come into full
 compliance with the new regulations. The 2017 capital expenditure
 costs expected for these plans are included in the Company’s
 capital expenditure projections.
  (was, 2016-11-03, similarity 0.9721):
[0001193125-16-758846:note_history:2]
The
 process to manufacture PCBs requires adherence to city, county,
 state, federal, and foreign environmental regulations regarding the
 storage, use, handling, and disposal of chemicals, solid wastes,
 and other hazardous materials, as well as compliance with air
 quality standards and chemical use reporting. The Company believes
 that its facilities in the United States, Canada and Mexico comply
 in all material respects with applicable environmental laws and
 regulations. In China, governmental authorities have adopted new
 rules and regulations governing environmental issues. An update to
 the Chinese environmental waste water law was issued in late 2012,
 allowing for an interim period in which plants subject to such law
 may install equipment that meets the new regulatory regime. Some of
 the Company’s plants in China are not yet in full compliance
 with the updated environmental regulations. The Company believes it
 has developed plans acceptable to the Chinese government and is in
 the process of implementing these plans. The Company does not
 anticipate any immediate risk of government fines or temporary
 closure of its Chinese plants. The Company has established and
 enacted an investment plan related to the efforts to come into full
 compliance with the new regulations. The 2016 capital expenditure
 costs expected for these plans are included in the Company’s
 capital expenditure projections.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2017-05-11):
[0001193125-17-166200:note_history:3]
TTM Technologies, Inc. (the Company or TTM) is a leading global
 printed circuit board (PCB) manufacturer, focusing on quick-turn
 and volume production of technologically complex PCBs and
 electro-mechanical solutions (E-M Solutions). The Company provides
 time-to-market and advanced
 technology products and offers a one-stop manufacturing solution to
 customers from engineering support to prototype development through
 final mass production. This one-stop manufacturing solution allows
 the Company to align technology developments with the diverse needs
 of the Company’s customers and to enable them to reduce the
 time required to develop new products and bring them to
 market.
  (was, 2016-11-03, similarity 0.9415):
[0001193125-16-758846:note_history:3]
TTM Technologies, Inc. (the Company or TTM) is a leading global
 printed circuit board (PCB) manufacturer, focusing on quick-turn
 and technologically advanced PCBs and electro-mechanical solutions
 (E-M Solutions). The Company provides time-to-market and advanced
 technology products and offers a one-stop manufacturing solution to
 customers from engineering support to prototype development through
 final volume production. This one-stop manufacturing solution
 allows the Company to align technology developments with the
 diverse needs of the Company’s customers and to enable them
 to reduce the time required to develop new products and bring them
 to market.

- changed (2017-05-11):
[0001193125-17-166200:note_history:4]
The Company serves a diversified customer base in various
 markets throughout the world, including networking/communications
 infrastructure products, smartphones and touchscreen tablets, as
 well as aerospace and defense, automotive, high-end computing, and medical,
 industrial and instrumentation related products. The
 Company’s customers include both original equipment
 manufacturers (OEMs) and electronic manufacturing services (EMS)
 providers.
  (was, 2016-11-03, similarity 0.844):
[0001193125-16-758846:note_history:4]
The Company serves a diversified customer base in various
 markets throughout the world, including manufacturers of
 networking/communications infrastructure products, tablets and
 smartphones, as well as the aerospace and defense, automotive
 components, high-end computing, and medical, industrial and
 instrumentation related products. The Company’s customers
 include both original equipment manufacturers (OEMs) and electronic
 manufacturing services (EMS) providers.

- changed (2017-05-11):
[0001193125-17-166200:note_history:5]
The accompanying consolidated condensed financial statements
 have been prepared by the Company, without audit, pursuant to the
 rules and regulations of the Securities and Exchange Commission
 (SEC). Certain information and disclosures normally included in
 financial statements prepared in accordance with accounting
 principles generally accepted in the United States of America (U.S.
 GAAP) have been condensed or omitted pursuant to such rules and
 regulations. These consolidated condensed financial statements
 reflect all adjustments (consisting only of normal recurring
 adjustments) which, in the opinion of management, are necessary to
 present fairly the financial position, the results of operations
 and cash flows of the Company for the periods presented. It is
 suggested that these consolidated condensed financial statements be
 read in conjunction with the consolidated financial statements and
 the notes thereto included in the Company’s most recent
 Annual Report on Form 10-K. The results of operations for
 the interim periods are not necessarily indicative of the results
 to be expected for the full year. The preparation of financial
 statements in accordance with U.S. GAAP requires management to make
 estimates and assumptions that affect the amounts reported in the
 Company’s consolidated condensed financial statements and
 accompanying notes. Actual results could differ materially from
 those estimates. The Company uses a 13-week fiscal quarter accounting
 period with the fourth quarter ending on the Monday nearest
 December 31.
  (was, 2016-11-03, similarity 0.9323):
[0001193125-16-758846:note_history:5]
The accompanying consolidated condensed financial statements
 have been prepared by the Company, without audit, pursuant to the
 rules and regulations of the Securities and Exchange Commission
 (SEC). Certain information and disclosures normally included in
 financial statements prepared in accordance with accounting
 principles generally accepted in the United States of America (U.S.
 GAAP) have been condensed or omitted pursuant to such rules and
 regulations. These consolidated condensed financial statements
 reflect all adjustments (consisting only of normal recurring
 adjustments) which, in the opinion of management, are necessary to
 present fairly the financial position, the results of operations
 and cash flows of the Company for the periods presented. It is
 suggested that these consolidated condensed financial statements be
 read in conjunction with the consolidated financial statements and
 the notes thereto included in the Company’s most recent
 Annual Report on Form 10-K. The results of operations for the
 interim periods are not necessarily indicative of the results to be
 expected for the full year. The preparation of financial statements
 in accordance with U.S. GAAP requires management to make estimates
 and assumptions that affect the amounts reported in the
 Company’s consolidated condensed financial statements and
 accompanying notes. Actual results could differ materially from
 those estimates. The Company uses a 52/53 week fiscal calendar with
 the fourth quarter ending on the Monday nearest December 31.
 Fiscal 2015 was a 52 week year. Fiscal 2016 will be a 53 week year
 with the additional week included in the fourth quarter.

- added (2017-05-11):
[0001193125-17-166200:note_history:6]
In October 2016, the Financial Accounting Standards Board
 (FASB) issued Accounting Standards Update (ASU) 2016-16, Income Taxes (Topic 740):
 Intra-Entity Transfers of Assets Other Than Inventory. The
 objective of this update is to improve the accounting for the
 income tax consequences of intra-entity transfers of assets other
 than inventory by recognizing the income tax consequences when the
 transfer occurs. This ASU is effective for fiscal years beginning
 after December 15, 2017, including interim periods within
 those fiscal years. Early adoption is permitted. The Company is
 currently evaluating the new guidance to determine the impact it
 may have on its consolidated condensed financial
 statements.

- added (2017-05-11):
[0001193125-17-166200:note_history:7]
In August 2016, the FASB issued ASU 2016-15, Statement of Cash Flows
 (Topic 230). The objective of this update is to add or clarify
 guidance on the classification of certain cash receipts and
 payments in the statement of cash flows. This ASU is effective for
 fiscal years beginning after December 15, 2017, including
 interim periods within those annual periods and is to be applied
 utilizing a retrospective approach. Early adoption is permitted.
 The Company adopted this ASU 2016-15 in the first quarter of 2017
 and the adoption did not have a material impact on its consolidated
 condensed financial statements and related disclosures.

- changed (2017-05-11):
[0001193125-17-166200:note_history:8]
In March 2016, the FASB issued ASU 2016-09, Stock Compensation (Topic
 718): Improvements to Employee Share-Based Payment Accounting.
 The objective of this update is to simplify several aspects of the
 accounting for employee share-based payment transactions, including
 the income tax consequences, classification of awards as either
 equity or liabilities, and classification on the statement of cash
 flows. This ASU is effective for fiscal years beginning after
 December 15, 2016, including interim periods within those
 fiscal years. The Company adopted ASU 2016-09 on January 3, 2017. The
 impact of the adoption did not have a material impact on the
 consolidated condensed financial statements and related
 disclosures.
  (was, 2016-11-03, similarity 0.7562):
[0001193125-16-758846:note_history:8]
In March 2016, the Financial Accounting Standards Board (FASB)
 issued Accounting Standards Update (ASU) 2016-09, Stock
 Compensation (Topic 718): Improvements to Employee Share-Based
 Payment Accounting. The objective of this update is to simplify
 several aspects of the accounting for employee share-based payment
 transactions, including the income tax consequences, classification
 of awards as either equity or liabilities, and classification on
 the statement of cash flows. This ASU is effective for fiscal years
 beginning after December 15, 2016, including interim periods within
 those fiscal years. Early adoption is permitted. The Company is
 currently evaluating the new guidance to determine the impact it
 may have on its consolidated financial statements and related
 disclosures.

- changed (2017-05-11):
[0001193125-17-166200:note_history:9]
In May 2014, the FASB issued ASU 2014-09, Revenue from Contracts
 with Customers, as amended, which requires an entity to
 recognize the amount of revenue to which it expects to be entitled
 for the transfer of promised goods or services to customers. The
 ASU will replace most existing revenue recognition guidance in U.S.
 GAAP when it becomes effective. The new standard is effective for
 the Company at the beginning of fiscal year 2018, however
 application of the standard is allowed as early as the beginning of
 fiscal 2017. The standard permits the use of either the
 retrospective or cumulative effect transition method. The Company
 has assessed that the impact of the new guidance will result in a
 change to the timing of revenue recognition for the Company’s
 revenue stream from “point in time” upon physical
 delivery to an “over time” model and believes this
 transition could have a material impact on the Company’s
 consolidated financial statements upon adoption. As of
 April 3, 2017, management intends to apply the cumulative
 effect transition method. The Company has identified and is in the
 process of implementing changes to its systems, processes and
 internal controls to meet the standard update’s reporting and
 disclosure requirements.
  (was, 2016-11-03, similarity 0.841):
[0001193125-16-758846:note_history:9]
In May 2014, the FASB issued ASU 2014-09, Revenue from
 Contracts with Customers, as amended, which requires an entity
 to recognize the amount of revenue to which it expects to be
 entitled for the transfer of promised goods or services to
 customers. The ASU will replace most existing revenue recognition
 guidance in U.S. GAAP when it becomes effective. The new standard
 is effective for the Company at the beginning of fiscal year 2018,
 however application of the standard is allowed as early as the
 beginning of fiscal 2017. The standard permits the use of either
 the retrospective or cumulative effect transition method and
 management is currently evaluating which transition approach to
 use. The Company has assessed that the impact of the new guidance
 will result in a change to the timing of revenue recognition for a
 portion of the Company’s revenue stream from
 “point in time” upon physical delivery to an
 “over time” model and believes this transition could
 have a material impact on the Company’s consolidated
 financial statements upon adoption.

- removed (2017-05-11):
[0001193125-16-758846:note_history:10]
In April 2015, the FASB issued ASU 2015-03, Imputation of
 Interest, as amended, which requires an entity to record debt
 issuance costs related to debt reported in the balance sheet as a
 direct deduction from the face amount of that debt. The update is
 effective for annual periods ending after December 15, 2015.
 The standard requires the use of the retrospective transition
 method. The Company adopted the new standard in the first quarter
 of 2016. Accordingly, as of September 26, 2016, approximately
 $26,314 of unamortized debt issuance costs were presented as a
 reduction of long-term debt on the Company’s consolidated
 condensed balance sheets. Furthermore, the Company reclassified
 approximately $31,171 of unamortized debt issuance costs that had
 been presented as other non-current assets as of December 28,
 2015.


## ttmi:ScheduleOfComponentsOfInterestExpenseFromConvertibleNotesTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2017-05-11):
[0001193125-17-166200:note_history:11]
The components of interest expense resulting from the
 convertible senior notes for the quarters ended April 3, 2017
 and March 28, 2016 are as follows:
  (was, 2016-11-03, similarity 0.8738):
[0001193125-16-758846:note_history:11]
The
 components of interest expense resulting from the convertible
 senior notes for the quarters and three quarters ended September
 26, 2016 and September 28, 2015 are as follows:

- added (2017-05-11):
[0001193125-17-166200:note_history:12]
|  |  | For the Quarter Ended |  |
|  |  | April 3, 2017 |  |  | March 28, 2016 |  |
|  |  | (In thousands) |  |
| Contractual coupon interest |  | $ | 1,094 |  |  | $ | 1,094 |  |
| Amortization of debt discount |  | $ | 2,091 |  |  | $ | 1,960 |  |
| Amortization of debt issuance costs |  | $ | 209 |  |  | $ | 196 |  |

- removed (2017-05-11):
[0001193125-16-758846:note_history:13]
|  |  | For the Quarter Ended |  |  | For the Three quarters Ended |  |
|  |  | September 26, 2016 |  |  | September 28, 2015 |  |  | September 26, 2016 |  |  | September 28, 2015 |  |
|  |  | (In thousands) |  |
| Contractual coupon interest |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Convertible senior notes due 2020 |  | $ | 1,094 |  |  | $ | 1,094 |  |  | $ | 3,281 |  |  | $ | 3,281 |  |
| Convertible senior notes due 2015 |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 395 |  |
|  |  | $ | 1,094 |  |  | $ | 1,094 |  |  | $ | 3,281 |  |  | $ | 3,676 |  |
| Amortization of debt discount |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Convertible senior notes due 2020 |  | $ | 2,025 |  |  | $ | 1,898 |  |  | $ | 5,977 |  |  | $ | 5,603 |  |
| Convertible senior notes due 2015 |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 554 |  |
|  |  | $ | 2,025 |  |  | $ | 1,898 |  |  | $ | 5,977 |  |  | $ | 6,157 |  |
| Amortization of debt issuance costs |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Convertible senior notes due 2020 |  | $ | 203 |  |  | $ | 190 |  |  | $ | 599 |  |  | $ | 561 |  |
| Convertible senior notes due 2015 |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 56 |  |
|  |  | $ | 203 |  |  | $ | 190 |  |  | $ | 599 |  |  | $ | 617 |  |


## us-gaap:ConvertibleDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2017-05-11):
[0001193125-17-166200:note_history:14]
As of April 3, 2017 and January 2, 2017, the
 following summarizes the equity components of the convertible
 senior notes included in additional paid-in capital:
  (was, 2016-11-03, similarity 0.9246):
[0001193125-16-758846:note_history:14]
As of September 26, 2016 and December 28, 2015, the
 following summarizes the equity components of the convertible
 senior notes included in additional paid-in capital:

- added (2017-05-11):
[0001193125-17-166200:note_history:15]
|  |  | As of April 3, 2017 and January 2, 2017 |  |
|  |  | Embedded conversion option — Convertible Senior Notes |  |  | Embedded conversion option — Convertible Senior Notes Issuance Costs |  |  | Total |  |
|  |  | (in thousands) |  |
| Convertible senior notes due 2020 |  | $ | 60,227 |  |  | $ | (1,916 | ) |  | $ | 58,311 |  |

- removed (2017-05-11):
[0001193125-16-758846:note_history:16]
|  |  | As of September 26, 2016 and December 28, 2015 |  |
|  |  | Embedded conversion option — Convertible Senior Notes |  |  | Embedded conversion option — Convertible Senior Notes Issuance Costs |  |  | Total |  |
|  |  | (in thousands) |  |
| Convertible senior notes due 2020 |  | $ | 60,227 |  |  | $ | (1,916 | ) |  | $ | 58,311 |  |


## us-gaap:LongTermDebtTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2017-05-11):
[0001193125-17-166200:note_history:17]
The following table summarizes the long-term debt of the
 Company as of April 3, 2017 and January 2,
 2017:
  (was, 2016-11-03, similarity 0.8844):
[0001193125-16-758846:note_history:17]
The following table summarizes the long-term debt of the
 Company as of September 26, 2016 and December 28,
 2015:

- changed (2017-05-11):
[0001193125-17-166200:note_history:18]
|  |  | Average Effective Interest Rate as of April 3, 2017 |  |  | April 3, 2017 |  |  | Average Effective Interest Rate as of January 2, 2017 |  |  | January 2, 2017 |  |
|  |  | (In thousands) |  |
| Term loan due May 2021 |  |  | 5.25% |  |  | $ | 700,000 |  |  |  | 5.25% |  |  | $ | 700,000 |  |
| U.S. ABL revolving loan due May 2020 |  |  | 2.48% |  |  |  | 80,000 |  |  |  | 2.27% |  |  |  | 80,000 |  |
| Asia ABL revolving loan due May 2020 |  |  | 2.38% |  |  |  | 30,000 |  |  |  | 2.17% |  |  |  | 30,000 |  |
| Convertible Senior Notes due December 2020 |  |  | 1.75% |  |  |  | 250,000 |  |  |  | 1.75% |  |  |  | 250,000 |  |
| Capital lease |  |  | 6.43% |  |  |  | 1,815 |  |  |  | 6.43% |  |  |  | 1,798 |  |
|  |  |  |  |  |  |  | 1,061,815 |  |  |  |  |  |  |  | 1,061,798 |  |
| Less: Long-term debt unamortized discount |  |  |  |  |  |  | (35,301 | ) |  |  |  |  |  |  | (37,392 | ) |
| Long-term debt unamortized debt issuance costs |  |  |  |  |  |  | (4,465 | ) |  |  |  |  |  |  | (4,724 | ) |
|  |  |  |  |  |  |  | 1,022,049 |  |  |  |  |  |  |  | 1,019,682 |  |
| Less: current maturities |  |  |  |  |  |  | (160,658 | ) |  |  |  |  |  |  | (110,652 | ) |
| Long-term debt, less current maturities |  |  |  |  |  | $ | 861,391 |  |  |  |  |  |  | $ | 909,030 |  |
  (was, 2016-11-03, similarity 0.6868):
[0001193125-16-758846:note_history:18]
|  |  | Average Effective Interest Rate as of September 26, 2016 |  |  | September 26, 2016 |  |  | Average Effective Interest Rate as of December 28, 2015 |  |  | December 28, 2015 |  |
|  |  | (In thousands) |  |
| Term loan due May 2021 |  |  | 6.00% |  |  | $ | 841,143 |  |  |  | 6.00% |  |  | $ | 947,625 |  |
| U.S. ABL revolving loan due May 2020 |  |  | 2.27% |  |  |  | 80,000 |  |  |  | 2.17% |  |  |  | 80,000 |  |
| Convertible senior notes due December 2020 |  |  | 1.75% |  |  |  | 250,000 |  |  |  | 1.75% |  |  |  | 250,000 |  |
| Capital lease |  |  | 6.43% |  |  |  | 1,875 |  |  |  |  |  |  |  | — |  |
|  |  |  |  |  |  |  | 1,173,018 |  |  |  |  |  |  |  | 1,277,625 |  |
| Less: Long-term debt unamortized discount |  |  |  |  |  |  | (64,854 | ) |  |  |  |  |  |  | (75,668 | ) |
| Long-term debt unamortized debt issuance costs |  |  |  |  |  |  | (26,314 | ) |  |  |  |  |  |  | (31,171 | ) |
|  |  |  |  |  |  |  | 1,081,850 |  |  |  |  |  |  |  | 1,170,786 |  |
| Less: current maturities |  |  |  |  |  |  | (146,473 | ) |  |  |  |  |  |  | (157,375 | ) |
| Long-term debt, less current maturities |  |  |  |  |  | $ | 935,377 |  |  |  |  |  |  | $ | 1,013,411 |  |

- changed (2017-05-11):
[0001193125-17-166200:note_history:19]
The Company maintains a Term Loan Credit Agreement (Term Loan),
 a $200,000 U.S. Asset-Based Lending Credit Agreement (U.S. ABL),
 and a $150,000 Asia Asset-Based Lending Credit Agreement (Asia ABL)
 (collectively the ABL Revolving Loans).
  (was, 2016-11-03, similarity 0.6635):
[0001193125-16-758846:note_history:19]
On May 31, 2015, in conjunction with the acquisition of
 Viasystems, the Company entered into a $950,000 Term Loan Credit
 Agreement (Term Loan). Additionally, the Company entered into a
 $150,000 U.S. Asset-Based Lending Credit Agreement (U.S. ABL) and a
 $150,000 Asia Asset-Based Lending Credit agreement (Asia ABL)
 (collectively the ABL Revolving Loans). The Company drew $80,000 of
 the U.S. ABL at the closing of the acquisition of
 Viasystems.

- changed (2017-05-11):
[0001193125-17-166200:note_history:20]
The Term Loan bears interest at a floating rate of LIBOR, with
 a 1.0% LIBOR floor, plus an applicable interest margin of 4.25%, or
 JP Morgan Chase Bank’s prime rate, with a 2% floor, plus a
 margin of 3.25%, at the Company’s option. At April 3,
 2017 the weighted average interest rate on the outstanding
 borrowings under the Term Loan was 5.25%. There is no provision,
 other than an event of default, for the interest margin to
 increase. The Term Loan will mature on May 31, 2021. The Term
 Loan is secured by a significant amount of the assets of the
 Company and a pledge of 65% of voting stock of the Company’s
 first tier foreign subsidiaries and is structurally senior to the
 Company’s convertible senior notes. See Convertible Senior
 Notes below.
  (was, 2016-11-03, similarity 0.9481):
[0001193125-16-758846:note_history:20]
The Term Loan was issued at a discount at 96.5% and bears
 interest at a floating rate of LIBOR, with a 1.0% LIBOR floor, plus
 an applicable interest margin of 5.0%, or JP Morgan Chase
 Bank’s prime rate, with a 2% floor, plus a margin of 4%, at
 the Company’s option. At September 26, 2016, the weighted
 average interest rate on the outstanding borrowings under the Term
 Loan was 6.0%. There is no provision, other than an event of
 default, for the interest margin to increase. The Term Loan will
 mature on May 31, 2021. The Term Loan is secured by a
 significant amount of the assets of the Company and its domestic
 subsidiaries and a pledge of 65% of voting stock of the
 Company’s first tier foreign subsidiaries and is structurally
 senior to the Company’s convertible senior notes. See
 Convertible Senior Notes below.

- changed (2017-05-11):
[0001193125-17-166200:note_history:21]
The U.S. ABL consists of three tranches comprised of a
 revolving credit facility of up to $200,000, a letter of credit
 facility of up to $50,000, and swingline loans of up to $30,000,
 provided that at no time may amounts outstanding under the tranches
 exceed in aggregate $200,000 or the applicable borrowing base,
 which is a percentage of the principal amount of Eligible Accounts,
 as defined in the U.S. ABL agreement. Borrowings under the U.S. ABL
 bear interest at either a floating rate of LIBOR plus a margin of
 150 basis points or JP Morgan Chase Bank’s prime rate plus a
 margin of 50 basis points, at the Company’s option. At
 April 3, 2017, the weighted average interest rate on the
 outstanding borrowings under the U.S. ABL was 2.48%. The applicable
 margin can vary based on the remaining availability of the
 facility, from 125 to 175 basis points for LIBOR-based loans and
 from 25 to 75 basis points for JP Morgan Chase Bank’s prime
 rate-based loans. Other than availability and an event of default,
 there are no other provisions for the interest margin to increase.
 The U.S. ABL will mature on May 31, 2020. Loans made under the
 U.S. ABL are secured first by all of the Company’s domestic
 cash, receivables and inventories as well as by a second position
 against a significant amount of the assets of the Company and a
 pledge of 65% of voting stock of the Company’s first tier
 foreign subsidiaries and are structurally senior to the
 Company’s convertible senior notes. See Convertible Senior
 Notes below. At April 3, 2017, $80,000 of the U.S. ABL was
 outstanding and classified as short-term debt. The Company and its
 domestic subsidiaries have fully and unconditionally guaranteed the
 full and timely payment of all Term Loan and U.S. ABL related
 obligations.
  (was, 2016-11-03, similarity 0.9314):
[0001193125-16-758846:note_history:21]
The U.S. ABL consists of three tranches comprised of a
 revolving credit facility of up to $150,000, a letter of credit
 facility of up to $75,000, and swingline loans of up to $30,000,
 provided that at no time may amounts outstanding under the tranches
 exceed in aggregate $150,000 or the applicable borrowing base,
 which is a percentage of the principal amount of Eligible Accounts,
 as defined in the U.S. ABL agreement. Borrowings under the U.S. ABL
 bear interest at either a floating rate of LIBOR plus a margin of
 175 basis points or JP Morgan Chase Bank’s prime rate plus a
 margin of 75 basis points, at the Company’s option. At
 September 26, 2016, the weighted average interest rate on the
 outstanding borrowings under the U.S. ABL was 2.27%. The applicable
 margin can vary based on the remaining availability of the
 facility, from 150 to 200 basis points for LIBOR-based loans or
 from 50 to 100 basis points for JP Morgan Chase Bank’s prime
 rate-based loans. Other than availability and an event of default,
 there are no other provisions for the interest margin to increase.
 The U.S. ABL will mature on May 31, 2020. Loans made under the
 U.S. ABL are secured first by all of the Company’s domestic
 cash, receivables and inventories as well as by a second position
 against a significant amount of the assets of the Company and its
 domestic subsidiaries and a pledge of 65% of voting stock of the
 Company’s first tier foreign subsidiaries and are
 structurally senior to the Company’s convertible senior
 notes. See Convertible Senior Notes below. At September 26, 2016,
 $80,000 of the U.S. ABL was outstanding and classified as
 short-term debt.

- changed (2017-05-11):
[0001193125-17-166200:note_history:22]
The Asia ABL consists of two tranches comprised of a revolving
 credit facility of up to $150,000 and a letter of credit facility
 of up to $100,000, provided that at no time may amounts outstanding
 under both tranches exceed in aggregate $150,000 or the applicable
 borrowing base, which is a percentage of the principal amount of
 Eligible Accounts, as defined in the Asia ABL agreement. Borrowings
 under the Asia ABL bear interest at a floating rate of LIBOR plus
 140 basis points. At April 3, 2017, the weighted average
 interest rate on the outstanding borrowings under the Asia ABL was
 2.38%. There is no provision, other than an event of default, for
 the interest margin to increase. The Asia ABL will mature on
 May 22, 2020. Loans made under the Asia ABL are secured by a
 portion of the Company’s Asia Pacific cash and receivables
 and are structurally senior to the Company’s domestic
 obligations, including the convertible senior notes. See
 Convertible Senior Notes below. The Company’s Asia Pacific
 subsidiary and certain of its subsidiaries have fully and
 unconditionally guaranteed the full and timely payment of all Asia
 ABL related obligations. At April 3, 2017, $30,000 of the Asia
 ABL was outstanding.
  (was, 2016-11-03, similarity 0.688):
[0001193125-16-758846:note_history:22]
The Asia ABL consists of two tranches comprised of a revolving
 credit facility of up to $150,000 and a letter of credit facility
 of up to $100,000, provided that at no time may amounts outstanding
 under both tranches exceed in aggregate $150,000 or the applicable
 borrowing base, which is a percentage of the principal amount of
 Eligible Accounts, as defined in the Asia ABL agreement. Borrowings
 under the Asia ABL bear interest at a floating rate of LIBOR plus
 175 basis points. There is no provision, other than an event of
 default, for the interest margin to increase. The Asia ABL will
 mature on May 22, 2020. Loans made under the Asia ABL are
 secured by a portion of cash and receivables of certain of the
 Companies subsidiaries in Asia and are structurally senior to the
 Company’s domestic obligations, including the convertible
 senior notes. See Convertible Senior Notes below. Additionally,
 certain of the Company’s subsidiaries in Asia have fully and
 unconditionally guaranteed the full and timely payment of all Asia
 ABL related obligations. At September 26, 2016, none of the Asia
 ABL was outstanding.

- added (2017-05-11):
[0001193125-17-166200:note_history:23]
The Company is no longer required to make any quarterly
 scheduled payments for the remaining term of the outstanding Term
 Loan balance due to mandatory payments and optional loan
 prepayments applied to date. Additionally, based on certain
 parameters defined in the Term Loan agreement, including a secured
 leverage ratio, the Company is also not required to make any
 additional principal payments for fiscal year 2017 as our secured
 leverage ratio is less than or equal to 1.5. The Company may be
 required to make additional principal payments in future years, if
 the Company’s secured leverage ratio is greater than 1.5. Any
 remaining outstanding balances under the Term Loan are due at the
 maturity date of May 31, 2021. Subsequent to the quarter ended
 April 3, 2017, the Company made an optional debt principal
 prepayment totaling $50,000. Borrowings under the Term Loan are
 subject to financial and operating covenants including maintaining
 a maximum total leverage ratio. Under the occurrence of certain
 events, the U.S. ABL and the Asia ABL are subject to financial and
 operational covenants, including maintaining minimum fixed charge
 coverage ratios. At April 3, 2017, the Company was in
 compliance with the covenants under the Term Loan, the U.S. ABL and
 the Asia ABL.

- added (2017-05-11):
[0001193125-17-166200:note_history:24]
As of April 3, 2017 and January 2, 2017, remaining
 unamortized debt issuance costs of $927 and $977, respectively,
 related to the Term Loan. These debt issuance costs are recorded as
 a reduction of the Term Loan at April 3, 2017 and
 January 2, 2017, respectively, and are amortized over the
 duration of the Term Loan into interest expense using an effective
 interest rate of 5.29%.

- changed (2017-05-11):
[0001193125-17-166200:note_history:25]
Additionally, remaining unamortized debt issuance costs related
 to the ABL Revolving Loans were $3,173 and $3,423 as of
 April 3, 2017 and January 2, 2017, respectively. These
 debt issuance costs are included in other non-current assets and are amortized to
 interest expense over the duration of the ABL Revolving Loans using
 the straight line method of amortization.
  (was, 2016-11-03, similarity 0.936):
[0001193125-16-758846:note_history:25]
Additionally, remaining unamortized debt issuance costs related
 to the ABL Revolving Loans were $3,573 and $4,303 as of September
 26, 2016 and December 28, 2015, respectively. These debt issuance
 costs are included in other non-current assets and are amortized to
 interest expense over the duration of the ABL Revolving Loans using
 the straight line method of amortization.

- changed (2017-05-11):
[0001193125-17-166200:note_history:26]
At April 3, 2017, the remaining weighted average
 amortization period for the unamortized debt issuance costs for
 both the Term Loan and the ABL Revolving Loans was 3.4
 years.
  (was, 2016-11-03, similarity 0.8673):
[0001193125-16-758846:note_history:26]
At September 26, 2016, the remaining amortization period for
 the unamortized debt discount and debt issuance costs for both the
 Term Loan and the ABL Revolving Loans was 4.6 years.

- changed (2017-05-11):
[0001193125-17-166200:note_history:27]
The Company is required to pay a commitment fee of 0.25% to
 0.375% per annum on any unused portion of the U.S. ABL or Asia
 ABL. The Company incurred total commitment fees related to unused
 borrowing availability of $187 and $194 for the quarters ended
 April 3, 2017 and March 28, 2016, respectively. As of
 April 3, 2017, the outstanding amount of the Term Loan was
 $700,000, of which $50,000 is included in short-term debt and the
 remaining $650,000 is included as long-term debt. Additionally,
 $80,000 of the U.S. ABL and $30,000 of the Asia ABL was outstanding
 as of April 3, 2017. Available borrowing capacity under the
 U.S. ABL and Asia ABL was $113,503 and $99,628, which considers
 letters of credit outstanding of $6,497 and $20,372 mentioned
 below, respectively, at April 3, 2017.
  (was, 2016-11-03, similarity 0.6629):
[0001193125-16-758846:note_history:27]
The Company is required to pay a commitment fee of 0.25% to
 0.375% per annum on any unused portion of the U.S. ABL or Asia
 ABL based on utilization levels. Additionally, the Company also
 paid commitment fees of 0.5% per annum on the unused portion
 of the $90,000 senior secured revolving loan associated with the
 terminated 2012 credit agreement for the three quarters ended
 September 28, 2015. The Company incurred total commitment fees
 related to unused borrowing availability of $171 and $200 for the
 quarters ended September 26, 2016 and September 28, 2015,
 respectively, and $516 and $565 for the three quarters ended
 September 26, 2016 and September 28, 2015, respectively. As of
 September 26, 2016, the outstanding amount of the Term Loan was
 $841,143, of which $66,143 is included as short-term debt and the
 remaining $775,000 is included as long-term debt. Additionally,
 $80,000 of the U.S. ABL and none of the Asia ABL was outstanding as
 of September 26, 2016. Available borrowing capacity under the U.S.
 ABL and Asia ABL was $63,003 and $142,904, which includes letters
 of credit outstanding of $6,997 and $7,096 mentioned below,
 respectively, at September 26, 2016.

- changed (2017-05-11):
[0001193125-17-166200:note_history:28]
The Company has up to $50,000 and $100,000 Letters of Credit
 Facilities under the U.S. ABL and the Asia ABL, respectively, as
 mentioned above. As of April 3, 2017, letters of credit in the
 amount of $6,497 were outstanding under the U.S. ABL and $20,372
 were outstanding under the Asia ABL with various expiration dates
 through March 2018.
  (was, 2016-11-03, similarity 0.949):
[0001193125-16-758846:note_history:28]
The Company has up to $75,000 and $100,000 Letters of Credit
 Facilities under the U.S. ABL and the Asia ABL, respectively, as
 mentioned above. As of September 26, 2016, letters of credit in the
 amount of $6,997 were outstanding under the U.S. ABL and $7,096
 were outstanding under the Asia ABL with various expiration dates
 through September 2017.

- added (2017-05-11):
[0001193125-17-166200:note_history:29]
Conversion: At any time prior to
 March 15, 2020, holders may convert their convertible senior
 notes into cash and, if applicable, into shares of the
 Company’s common stock based on a conversion rate of 103.7613
 shares of the Company’s common stock per $1 principal amount
 of convertible senior notes, subject to adjustment, under the
 following circumstances: (1) during any calendar quarter
 beginning after March 31, 2015 (and only during such calendar
 quarter), if the last reported sale price of our common stock for
 at least 20 trading days during the 30 consecutive trading days
 ending on the last trading day of the immediately preceding
 calendar quarter is greater than or equal to 130% of the applicable
 conversion price on each applicable trading day of such preceding
 calendar quarter; (2) during the five business day period
 after any 10 consecutive trading day period in which the trading
 price per note for each day of that 10 consecutive trading day
 period was less than 98% of the product of the last reported sale
 price of the Company’s common stock and the conversion rate
 on such day; or (3) upon the occurrence of specified corporate
 transactions described in the indenture governing the notes. As of
 April 3, 2017, the conversion criteria had been met under
 condition (1) as described above, allowing holders to give
 notice of conversion in both the first and second quarter of
 2017.

- added (2017-05-11):
[0001193125-17-166200:note_history:30]
On or after March 15, 2020 until the close of business on
 the third scheduled trading day preceding the maturity date,
 holders may convert their notes at any time, regardless of the
 foregoing circumstances. Upon conversion, for each $1 principal
 amount of notes, the Company will pay shares of our common stock,
 cash or a combination of cash and shares of our common stock at its
 election, if applicable, based on a daily conversion value
 calculated on a proportionate basis for each day of the 80 trading
 day observation period. All conversions occurring on the same date
 or on or after March 15, 2020 shall be settled using the same
 settlement method. Additionally, in the event of a fundamental
 change as defined in the indenture governing the notes, or other
 conversion rate adjustments such as share splits or combinations,
 other distributions of shares, cash or other assets to
 stockholders, including self-tender transactions (Other Conversion
 Rate Adjustments), the conversion rate may be modified to adjust
 the number of shares per $1 principal amount of the notes. As of
 April 3, 2017, none of the criteria for a fundamental change
 or a conversion rate adjustment had been met.

- added (2017-05-11):
[0001193125-17-166200:note_history:31]
The maximum number of shares issuable upon conversion,
 including the effect of a fundamental change and subject to Other
 Conversion Rate Adjustments, would be 32,425.

- added (2017-05-11):
[0001193125-17-166200:note_history:32]
Note Repurchase: The Company is not
 permitted to redeem the convertible senior notes at any time prior
 to maturity. In the event of a fundamental change or certain
 default events, as defined in the indenture governing the notes,
 holders may require the Company to repurchase for cash all or a
 portion of their convertible senior notes at a price equal to 100%
 of the principal amount, plus any accrued and unpaid
 interest.

- added (2017-05-11):
[0001193125-17-166200:note_history:33]
Convertible Note Hedge and Warrant
 Transaction: In connection with the
 issuance of the convertible senior notes due 2020, the Company
 entered into a convertible note hedge and warrant transaction (Call
 Spread Transaction), with respect to the Company’s common
 stock. The convertible note hedge consists of the Company’s
 option to purchase up to 25,940 common stock shares at a price of
 $9.64 per share. The hedge expires on December 15, 2020 and
 can only be executed upon the conversion of the above mentioned
 convertible senior notes due 2020. Additionally, the Company sold
 warrants to purchase 25,940 shares of its common stock at a price
 of $14.26 per share. The warrants expire ratably from March 2021
 through January 2022. The 2020 Call Spread Transaction has no
 effect on the terms of the convertible senior notes due 2020 and
 reduces potential dilution by effectively increasing the conversion
 price of the convertible senior notes due 2020 to $14.26 per share
 of the Company’s common stock.

- changed (2017-05-11):
[0001193125-17-166200:note_history:34]
As of April 3, 2017 and January 2, 2017, the
 following summarizes the equity components of the convertible
 senior notes included in additional paid-in capital:
  (was, 2016-11-03, similarity 0.9246):
[0001193125-16-758846:note_history:34]
As of September 26, 2016 and December 28, 2015, the
 following summarizes the equity components of the convertible
 senior notes included in additional paid-in capital:

- added (2017-05-11):
[0001193125-17-166200:note_history:35]
|  |  | As of April 3, 2017 and January 2, 2017 |  |
|  |  | Embedded conversion option — Convertible Senior Notes |  |  | Embedded conversion option — Convertible Senior Notes Issuance Costs |  |  | Total |  |
|  |  | (in thousands) |  |
| Convertible senior notes due 2020 |  | $ | 60,227 |  |  | $ | (1,916 | ) |  | $ | 58,311 |  |

- changed (2017-05-11):
[0001193125-17-166200:note_history:36]
The components of interest expense resulting from the
 convertible senior notes for the quarters ended April 3, 2017
 and March 28, 2016 are as follows:
  (was, 2016-11-03, similarity 0.8738):
[0001193125-16-758846:note_history:36]
The components of interest expense resulting from the
 convertible senior notes for the quarters and three quarters ended
 September 26, 2016 and September 28, 2015 are as
 follows:

- added (2017-05-11):
[0001193125-17-166200:note_history:37]
|  |  | For the Quarter Ended |  |
|  |  | April 3, 2017 |  |  | March 28, 2016 |  |
|  |  | (In thousands) |  |
| Contractual coupon interest |  | $ | 1,094 |  |  | $ | 1,094 |  |
| Amortization of debt discount |  | $ | 2,091 |  |  | $ | 1,960 |  |
| Amortization of debt issuance costs |  | $ | 209 |  |  | $ | 196 |  |

- changed (2017-05-11):
[0001193125-17-166200:note_history:38]
As of April 3, 2017 and January 2, 2017, there
 remains unamortized debt discount of $35,301 and $37,392,
 respectively, and debt issuance costs of $3,538 and $3,747,
 respectively, related to the convertible senior notes. These debt
 discount and debt discount issuance costs are recorded as a
 reduction of the convertible senior notes and are being amortized
 to interest expense over the term of the convertible senior notes
 using the effective interest rate method. At April 3, 2017,
 the remaining weighted average amortization period for the
 unamortized senior convertible note discount and debt issuance
 costs was 3.7 years.
  (was, 2016-11-03, similarity 0.9165):
[0001193125-16-758846:note_history:38]
As of September 26, 2016 and December 28, 2015, remaining
 unamortized debt discount of $39,449 and $45,426, respectively, and
 debt issuance costs of $3,953 and $4,552, respectively, related to
 the convertible senior notes. These debt discount and debt issuance
 costs are recorded as a reduction of the convertible senior notes
 and are being amortized to interest expense over the term of the
 convertible senior notes using the effective interest rate method.
 At September 26, 2016, the remaining weighted average amortization
 period for the unamortized senior convertible note discount and
 debt issuance costs was 4.2 years.

- added (2017-05-11):
[0001193125-17-166200:note_history:39]
For the quarters ended April 3, 2017 and March 28,
 2016, the amortization of the convertible senior notes due 2020
 debt discount and debt issuance costs is based on an effective
 interest rate of 6.48%.

- changed (2017-05-11):
[0001193125-17-166200:note_history:40]
Additionally, the Company is party to a revolving loan credit
 facility (Chinese Revolver) with a lender in China. Under this
 arrangement, the lender has made available to the Company
 approximately $30,500 in unsecured borrowing with all terms of the
 borrowing to be negotiated at the time the Chinese Revolver is
 drawn upon. There are no commitment fees on the unused portion of
 the Chinese Revolver, and this arrangement expires in January 2018.
 As of April 3, 2017, the Chinese Revolver had not been drawn
 upon.
  (was, 2016-11-03, similarity 0.9711):
[0001193125-16-758846:note_history:40]
Additionally, the Company is party to a revolving loan credit
 facility (Chinese Revolver) with a lender in China. Under this
 arrangement, the lender has made available to the Company
 approximately $34,500 in unsecured borrowing with all terms of the
 borrowing to be negotiated at the time the Chinese Revolver is
 drawn upon. There are no commitment fees on the unused portion of
 the Chinese Revolver, and this arrangement expires in December
 2016. As of September 26, 2016, the Chinese Revolver had not been
 drawn upon.

- removed (2017-05-11):
[0001193125-16-758846:note_history:41]
The Company and its domestic subsidiaries have fully and
 unconditionally guaranteed the full and timely payment of all Term
 Loan and U.S. ABL related obligations.

- removed (2017-05-11):
[0001193125-16-758846:note_history:42]
The Company is required to make scheduled payments of the
 outstanding Term Loan balance on a quarterly basis. Based on
 certain parameters defined in the Term Loan agreement, the Company
 may be required to make an additional principal payment on an
 annual basis. Any additional annual payments or prepayments reduce
 future required quarterly scheduled payments. During the three
 quarters ended September 26, 2016, the Company made debt principal
 payments totaling $106,482, representing normally scheduled
 principal payments as well as additional prepayments of principal.
 Any other outstanding balances under the Term Loan are due at the
 maturity date of May 31, 2021. Borrowings under the Term Loan
 are subject to various financial and operating covenants including
 maintaining a maximum total leverage ratio. Under the occurrence of
 certain events, the U.S. ABL and the Asia ABL are subject to
 various financial and operational covenants, including maintaining
 minimum fixed charge coverage ratios. At September 26, 2016, the
 Company was in compliance with the covenants under the Term Loan,
 the U.S. ABL and the Asia ABL.

- removed (2017-05-11):
[0001193125-16-758846:note_history:43]
As of September 26, 2016 and December 28, 2015, remaining
 unamortized debt discount of $25,405 and $30,242, respectively, and
 debt issuance costs of $22,361 and $26,619, respectively, related
 to the Term Loan. These debt discount and debt issuance costs are
 recorded as a reduction of the Term Loan and are amortized over the
 duration of the Term Loan into interest expense using an effective
 interest rate of 7.50%.

- removed (2017-05-11):
[0001193125-16-758846:note_history:44]
Subsequent to September 26, 2016, the Company issued a new
 $775,000 Term Loan (New Term Loan) at an interest rate of LIBOR
 plus 4.25%, a reduction of 75 basis points from its previous Term
 Loan, and repaid in full the $841,143 of the previously issued Term
 Loan outstanding, which resulted in an overall net reduction of
 $66,143 in the Term Loan outstanding. Principal payments under
 the New Term Loan are due quarterly beginning in April 2020 with
 the balance due on May 31, 2021, the same maturity as the previous
 Term Loan. In addition, the Company amended its U.S. ABL
 credit facility to increase the amount available under the U.S. ABL
 to $200,000, reduce the applicable margin by 0.25% for both
 Eurodollar loans and ABR loans, and reduce the Letters of Credit
 Facilities to $50,000.

- removed (2017-05-11):
[0001193125-16-758846:note_history:45]
At December 28, 2015, certain letters of credit were
 securitized by cash collateral. As such the Company had recorded
 such cash as restricted cash on the consolidated condensed balance
 sheet as of December 28, 2015. As of September 26, 2016, none of
 the letters of credit were securitized by cash
 collateral.

- removed (2017-05-11):
[0001193125-16-758846:note_history:46]
Convertible Senior
 Notes due 2015

- removed (2017-05-11):
[0001193125-16-758846:note_history:47]
The Company issued 3.25% convertible senior notes due on
 May 15, 2015 in a public offering for an aggregate principal
 amount of $175,000. In May 2015 the outstanding principal of
 $32,395 plus accrued interest was paid in full.

- removed (2017-05-11):
[0001193125-16-758846:note_history:48]
|  |  | As of September 26, 2016 and December 28, 2015 |  |
|  |  | Embedded conversion option — Convertible Senior Notes |  |  | Embedded conversion option — Convertible Senior Notes Issuance Costs |  |  | Total |  |
|  |  | (in thousands) |  |
| Convertible senior notes due 2020 |  | $ | 60,227 |  |  | $ | (1,916 | ) |  | $ | 58,311 |  |

- removed (2017-05-11):
[0001193125-16-758846:note_history:49]
|  |  | For the Quarter Ended |  |  | For the Three quarters Ended |  |
|  |  | September 26, 2016 |  |  | September 28, 2015 |  |  | September 26, 2016 |  |  | September 28, 2015 |  |
|  |  | (In thousands) |  |
| Contractual coupon interest |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Convertible senior notes due 2020 |  | $ | 1,094 |  |  | $ | 1,094 |  |  | $ | 3,281 |  |  | $ | 3,281 |  |
| Convertible senior notes due 2015 |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 395 |  |
|  |  | $ | 1,094 |  |  | $ | 1,094 |  |  | $ | 3,281 |  |  | $ | 3,676 |  |
| Amortization of debt discount |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Convertible senior notes due 2020 |  | $ | 2,025 |  |  | $ | 1,898 |  |  | $ | 5,977 |  |  | $ | 5,603 |  |
| Convertible senior notes due 2015 |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 554 |  |
|  |  | $ | 2,025 |  |  | $ | 1,898 |  |  | $ | 5,977 |  |  | $ | 6,157 |  |
| Amortization of debt issuance costs |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Convertible senior notes due 2020 |  | $ | 203 |  |  | $ | 190 |  |  | $ | 599 |  |  | $ | 561 |  |
| Convertible senior notes due 2015 |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 56 |  |
|  |  | $ | 203 |  |  | $ | 190 |  |  | $ | 599 |  |  | $ | 617 |  |

- removed (2017-05-11):
[0001193125-16-758846:note_history:50]
For the quarter and three quarters ended September 26, 2016 and
 September 28, 2015, the amortization of the convertible senior
 notes due 2020 debt discount and debt issuance costs was based on
 an effective interest rate of 6.48%. For the three quarters ended
 September 28, 2015, the amortization of the convertible senior
 notes due 2015 debt discount and debt issuance costs was based on
 an effective interest rate of 8.37%.

- removed (2017-05-11):
[0001193125-16-758846:note_history:51]
Loss on
 Extinguishment of Debt

- removed (2017-05-11):
[0001193125-16-758846:note_history:52]
The Company became a party to its current Term Loan and ABL
 Revolving Loans during the second quarter of 2015 in order to
 refinance and pay in full the remaining outstanding amount of
 $225,700 under an existing 2012 credit agreement, as well as to
 finance the acquisition of Viasystems and refinance
 Viasystems’ outstanding debt. As a result, the Company
 recognized losses of approximately $802 for the three quarters
 ended September 28, 2015 resulting from the write off of the
 remaining unamortized debt issuance costs associated with the
 terminated 2012 credit agreement.


## us-gaap:ScheduleOfDebtInstrumentsTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2017-05-11):
[0001193125-17-166200:note_history:53]
The following table summarizes the long-term debt of the
 Company as of April 3, 2017 and January 2,
 2017:
  (was, 2016-11-03, similarity 0.8844):
[0001193125-16-758846:note_history:53]
The following table summarizes the long-term debt of the
 Company as of September 26, 2016 and December 28,
 2015:

- changed (2017-05-11):
[0001193125-17-166200:note_history:54]
|  |  | Average Effective Interest Rate as of April 3, 2017 |  |  | April 3, 2017 |  |  | Average Effective Interest Rate as of January 2, 2017 |  |  | January 2, 2017 |  |
|  |  | (In thousands) |  |
| Term loan due May 2021 |  |  | 5.25% |  |  | $ | 700,000 |  |  |  | 5.25% |  |  | $ | 700,000 |  |
| U.S. ABL revolving loan due May 2020 |  |  | 2.48% |  |  |  | 80,000 |  |  |  | 2.27% |  |  |  | 80,000 |  |
| Asia ABL revolving loan due May 2020 |  |  | 2.38% |  |  |  | 30,000 |  |  |  | 2.17% |  |  |  | 30,000 |  |
| Convertible Senior Notes due December 2020 |  |  | 1.75% |  |  |  | 250,000 |  |  |  | 1.75% |  |  |  | 250,000 |  |
| Capital lease |  |  | 6.43% |  |  |  | 1,815 |  |  |  | 6.43% |  |  |  | 1,798 |  |
|  |  |  |  |  |  |  | 1,061,815 |  |  |  |  |  |  |  | 1,061,798 |  |
| Less: Long-term debt unamortized discount |  |  |  |  |  |  | (35,301 | ) |  |  |  |  |  |  | (37,392 | ) |
| Long-term debt unamortized debt issuance costs |  |  |  |  |  |  | (4,465 | ) |  |  |  |  |  |  | (4,724 | ) |
|  |  |  |  |  |  |  | 1,022,049 |  |  |  |  |  |  |  | 1,019,682 |  |
| Less: current maturities |  |  |  |  |  |  | (160,658 | ) |  |  |  |  |  |  | (110,652 | ) |
| Long-term debt, less current maturities |  |  |  |  |  | $ | 861,391 |  |  |  |  |  |  | $ | 909,030 |  |
  (was, 2016-11-03, similarity 0.6868):
[0001193125-16-758846:note_history:54]
|  |  | Average Effective Interest Rate as of September 26, 2016 |  |  | September 26, 2016 |  |  | Average Effective Interest Rate as of December 28, 2015 |  |  | December 28, 2015 |  |
|  |  | (In thousands) |  |
| Term loan due May 2021 |  |  | 6.00% |  |  | $ | 841,143 |  |  |  | 6.00% |  |  | $ | 947,625 |  |
| U.S. ABL revolving loan due May 2020 |  |  | 2.27% |  |  |  | 80,000 |  |  |  | 2.17% |  |  |  | 80,000 |  |
| Convertible senior notes due December 2020 |  |  | 1.75% |  |  |  | 250,000 |  |  |  | 1.75% |  |  |  | 250,000 |  |
| Capital lease |  |  | 6.43% |  |  |  | 1,875 |  |  |  |  |  |  |  | — |  |
|  |  |  |  |  |  |  | 1,173,018 |  |  |  |  |  |  |  | 1,277,625 |  |
| Less: Long-term debt unamortized discount |  |  |  |  |  |  | (64,854 | ) |  |  |  |  |  |  | (75,668 | ) |
| Long-term debt unamortized debt issuance costs |  |  |  |  |  |  | (26,314 | ) |  |  |  |  |  |  | (31,171 | ) |
|  |  |  |  |  |  |  | 1,081,850 |  |  |  |  |  |  |  | 1,170,786 |  |
| Less: current maturities |  |  |  |  |  |  | (146,473 | ) |  |  |  |  |  |  | (157,375 | ) |
| Long-term debt, less current maturities |  |  |  |  |  | $ | 935,377 |  |  |  |  |  |  | $ | 1,013,411 |  |


## us-gaap:RelatedPartyTransactionsDisclosureTextBlock (related_parties) — matched_by: tag_name, score: 1.0

- changed (2017-05-11):
[0001193125-17-166200:note_history:55]
In the normal course of business, the Company’s foreign
 subsidiaries purchase laminate and prepreg from related parties in
 which a significant shareholder of the Company holds an equity
 interest. For the quarters ended April 3, 2017 and
 March 28, 2016, the Company’s foreign subsidiaries
 purchased $13,540 and $15,998, respectively, of laminate and
 prepreg from these related parties.
  (was, 2016-11-03, similarity 0.6002):
[0001193125-16-758846:note_history:55]
In the
 normal course of business, the Company’s foreign subsidiaries
 purchase laminate and prepreg from related parties in which a
 significant shareholder of the Company holds an equity interest.
 The Company purchased laminate and prepreg from these related
 parties in the amount of $12,292 and $21,167 for the quarters ended
 September 26, 2016 and September 28, 2015, respectively, and
 $42,549 and $43,335 for the three quarters ended September 26, 2016
 and September 28, 2015, respectively.

- changed (2017-05-11):
[0001193125-17-166200:note_history:56]
Dongguan Shengyi Electronics Ltd. (SYE) is also a related party
 as it is a wholly owned subsidiary of an entity in which a
 significant shareholder of the Company holds an equity interest.
 The Company sells PCBs to SYE and purchases PCBs including various
 services relating to PCB manufacturing from SYE. Sales to SYE for
 the quarters ended April 3, 2017 and March 28, 2016 were
 $31 and $311, respectively. Purchases of PCBs including various
 services relating to PCB manufacturing for the quarter ended
 March 28, 2016 was $28. There were no purchases of PCBs or any
 services relating to PCB manufacturing for the quarter ended
 April 3, 2017.
  (was, 2016-11-03, similarity 0.7963):
[0001193125-16-758846:note_history:56]
Dongguan Shengyi Electronics Ltd. (SYE) is also a related party
 as it is a wholly owned subsidiary of an entity in which a
 significant shareholder of the Company holds an equity interest.
 The Company sells PCBs to SYE and purchases PCBs including various
 services relating to PCB manufacturing from SYE. Sales to SYE for
 the quarters ended September 26, 2016 and September 28, 2015
 were $254 and $1,042, respectively, and $863 and $3,867 for the
 three quarters ended September 26, 2016 and September 28, 2015,
 respectively. Purchases of PCBs, including various services
 relating to PCB manufacturing, for the quarter ended September 28,
 2015 were $344, and $1,840 for the three quarters ended September
 28, 2015. There were no purchases of PCBs including various
 services relating to PCB manufacturing for the quarter or three
 quarters ended September 26, 2016.

- changed (2017-05-11):
[0001193125-17-166200:note_history:57]
As of April 3, 2017 and January 2, 2017, the
 Company’s consolidated condensed balance sheets included
 $17,884 and $15,836, respectively, in accounts payable due to
 related parties primarily for purchases of laminate and prepreg and
 such balances are included as a component of accounts payable on
 the consolidated condensed balance sheets. Additionally, the
 Company’s consolidated condensed balance sheets included $124
 and $192, respectively, in accounts receivable due from a related
 party for sales of PCBs to SYE, as mentioned above, and such
 balances are included as a component of accounts receivable, net on
 the consolidated condensed balance sheets.
  (was, 2016-11-03, similarity 0.7805):
[0001193125-16-758846:note_history:57]
As of
 September 26, 2016 and December 28, 2015, the Company’s
 consolidated condensed balance sheets included $16,952 and
 $29,306, respectively, in accounts payable due to related parties
 for purchases of laminate and prepreg and various PCB manufacturing
 services and such balances are included as a component of accounts
 payable on the consolidated condensed balance sheets. Additionally,
 the Company’s consolidated condensed balance sheets included
 $598 and $1,999, in accounts receivable due from a related party
 for sales of PCBs to SYE, as of September 26, 2016 and December 28,
 2015, respectively, as mentioned above, and such balances are
 included as a component of accounts receivable, net on the
 consolidated condensed balance sheets.
