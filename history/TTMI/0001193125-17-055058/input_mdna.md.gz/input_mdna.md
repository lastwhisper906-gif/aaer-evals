# TTMI MD&A — 0001193125-17-055058


## mdna

[0001193125-17-055058:mdna:1]
| ITEM 7. | MANAGEMENT’S DISCUSSION AND ANALYSIS OF FINANCIAL CONDITION AND RESULTS OF OPERATIONS |

[0001193125-17-055058:mdna:2]
This financial review presents our operating results for each of our three most recent fiscal years and our financial condition at
January 2, 2017. Except for historical information contained herein, the following discussion contains forward-looking statements which are subject to known and unknown risks, uncertainties and other factors that may cause our actual results to
differ materially from those expressed or implied by such forward-looking statements. We discuss such risks, uncertainties and other factors throughout this report and specifically under Item 1A of Part I of this report, Risk Factors. In
addition, the following discussion should be read in connection with the information presented in our consolidated financial statements and the related notes to our consolidated financial statements.

[0001193125-17-055058:mdna:3]
COMPANY OVERVIEW

[0001193125-17-055058:mdna:4]
We are
a leading global printed circuit board (PCB) manufacturer, focusing on quick-turn and volume production of technologically complex PCBs and electro-mechanical solutions (E-M Solutions). We focus on providing time-to-market and volume production of advanced technology products and offer a one-stop manufacturing solution to our customers from
engineering support to prototype development through final mass production. This one-stop manufacturing solution allows us to align technology development with the diverse needs of our customers and to enable
them to reduce the time required to develop new products and bring them to market. We serve a diversified customer base consisting of approximately 1,500 customers in various markets throughout the world, including manufacturers of
networking/communications infrastructure products, smartphones and touchscreen tablets, as well as the aerospace and defense, automotive components, high-end computing, and medical, industrial and
instrumentation related products. Our customers include both original equipment manufacturers (OEMs) and electronic manufacturing services (EMS) providers.

[0001193125-17-055058:mdna:5]
RECENT DEVELOPMENTS

[0001193125-17-055058:mdna:6]
On May 31, 2015, we completed the acquisition of
Viasystems for total consideration of $248.8 million in cash and 15.1 million shares of TTM common stock with a fair value of $149.0 million, and thereby acquired all of the outstanding shares of capital stock and other equity rights
of Viasystems. Additionally, in connection with the completion of the acquisition, we assumed and refinanced Viasystems’ debt, which was approximately $669.0 million as of May 31, 2015. Viasystems was a worldwide provider of complex
multi-layer rigid, flexible, and rigid-flex PCBs and custom electronic assemblies.

[0001193125-17-055058:mdna:7]
The acquisition of Viasystems has had and
will continue to have a significant effect on our operations and financial results. We have greatly increased and diversified our revenue base and added the fast growing Automotive end market to our portfolio of markets we serve. Our financial
results for the year ended January 2, 2017 demonstrate the benefits of this diversification along with our strong operational execution and focus on realizing synergies from the integration. These results are reflected in improved gross and
operating margins for the year ended January 2, 2017 as compared to the year ended December 28, 2015.

[0001193125-17-055058:mdna:8]
On
September 29, 2015 we announced a consolidation plan that resulted in the closure of our facilities in Cleveland, Ohio, Milpitas, California and Juarez, Mexico (the Consolidation Plan). The Consolidation Plan was part of our integration
strategy to improve total plant utilization, operational performance and customer focus following our acquisition of Viasystems. In accordance with the Consolidation Plan, we combined our Cleveland and Milpitas facilities into our North Jackson,
Ohio and Silicon Valley, California facilities, respectively, and closed our Juarez facility. As a result, during the year ended January 2, 2017, we recognized total restructuring charges of $8.9 million. These charges primarily represent
severance expense associated with the Consolidation Plan and other global realignment restructuring efforts. As of January 2, 2017, we have incurred approximately $16.3 million of restructuring charges since the September 29, 2015
announcement.

[0001193125-17-055058:mdna:9]
On September 27, 2016, we issued new $775.0 million Term B Loans (Term Loan B) at an interest rate of
LIBOR, with a 1.0% LIBOR floor, plus 4.25%, a reduction of 75 basis points from the previous Term Loan Credit Agreement (Term Loan), and repaid in full the remaining outstanding balance of the Term Loan. This transaction was accounted for as an
extinguishment of debt and accordingly, we recognized a loss of $47.8 million primarily associated with the write off of the remaining unamortized debt discount and issuance costs.

[0001193125-17-055058:mdna:10]
Additionally, on September 27, 2016, we amended our U.S. Asset-Based Lending Credit
Agreement (U.S. ABL) to increase the amount available to $200.0 million, reduce the applicable margin by 25 basis points for both Eurodollar loans and ABR loans, and reduce the Letters of Credit Facilities to $50 million. On
December 22, 2016, we amended our Asia Asset-Based Lending Credit Agreement (Asia ABL) to reduce the interest margin by 35 basis points.

[0001193125-17-055058:mdna:11]
During the year ended January 2, 2017, we made net debt principal payments totaling $217.6 million, representing normally scheduled principal payments as well as additional prepayments of
principal.

[0001193125-17-055058:mdna:12]
FINANCIAL OVERVIEW

[0001193125-17-055058:mdna:13]
For the fiscal year 2016, we experienced higher demand in our Automotive and Aerospace and Defense end markets and additional sales from the full year contribution of Viasystems compared to that of fiscal
year 2015. This increase in sales resulted in higher capacity utilization at our Automotive focused facilities resulting in higher gross margins. Additionally, we have improved operating efficiencies at certain of our North American plants.

[0001193125-17-055058:mdna:14]
We operate on a 52 or 53 week year ending on the Monday nearest December 31. Fiscal 2016 consisted of 53 weeks ended on
January 2, 2017 with the additional week included in the fourth quarter. We estimate the additional week contributed approximately $29.2 million of additional revenue and approximately $1.1 million of additional operating income for
the year ended January 2, 2017. Fiscal year 2015 and 2014 were 52 weeks ended December 28, 2015 and December 29, 2014, respectively.

[0001193125-17-055058:mdna:15]
While our customers include both OEMs and EMS providers, we measure customers based on OEM companies as they are the ultimate end customers. Sales to our five largest customers accounted for 33%, 37% and
44% of our net sales in fiscal years 2016, 2015 and 2014, respectively. We sell to OEMs both directly and indirectly through EMS providers.

[0001193125-17-055058:mdna:16]
The following table shows the percentage of our net sales attributable to each of the principal end markets we served for the periods indicated:

[0001193125-17-055058:mdna:17]
| End Markets(1)(2) |  | 2016 |  |  | 2015(4) |  |  | 2014 |  |
| Aerospace and Defense |  |  | 15 | % |  |  | 14 | % |  |  | 16 | % |
| Automotive(2) |  |  | 20 |  |  |  | 13 |  |  |  | 2 |  |
| Cellular Phone(3) |  |  | 14 |  |  |  | 21 |  |  |  | 23 |  |
| Computing/Storage/Peripherals(3) |  |  | 12 |  |  |  | 12 |  |  |  | 13 |  |
| Medical/Industrial/Instrumentation |  |  | 14 |  |  |  | 13 |  |  |  | 10 |  |
| Networking/Communications |  |  | 23 |  |  |  | 25 |  |  |  | 33 |  |
| Other(2)(3) |  |  | 2 |  |  |  | 2 |  |  |  | 3 |  |
| Total |  |  | 100 | % |  |  | 100 | % |  |  | 100 | % |

[0001193125-17-055058:mdna:18]
| (1) | Sales to EMS companies are classified by the end markets of their OEM customers. |

[0001193125-17-055058:mdna:19]
| (2) | Certain reclassifications of prior year end market percentages have been made to conform to the current year presentation. Beginning 2015, Automotive has been reclassified from the Other end market. |

[0001193125-17-055058:mdna:20]
| (3) | Smartphones are included in the Cellular Phone end market, tablets are included in the Computing/Storage/Peripherals end market and other mobile devices such as e-readers are included in the Other end market. |

[0001193125-17-055058:mdna:21]
| (4) | Amounts includes 211 days of activity of Viasystems, which we acquired on May 31, 2015. |

[0001193125-17-055058:mdna:22]
We derive revenues primarily from the sale of PCBs and custom electronic assemblies using customer-supplied engineering and design plans.
We recognize revenues when persuasive evidence of a sales arrangement exists, the sales terms are fixed or determinable, title and risk of loss have transferred, and collectability is reasonably assured — generally when products are shipped to
the customer. Net sales consist of gross sales less an allowance for returns, which typically have been less than 3% of gross sales. We provide our customers a limited right of return for defective PCBs and backplane assemblies. We record an
estimate for sales returns and

[0001193125-17-055058:mdna:23]
allowances at the time of sale based on historical results. Purchase orders may be cancelled prior to shipment. We generally charge customers a fee, based on the percentage completed, if an order
is cancelled once it has entered production.

[0001193125-17-055058:mdna:24]
Cost of goods sold consists of materials, labor, outside services, and overhead
expenses incurred in the manufacture and testing of our products. Shipping and handling fees and related freight costs and supplies associated with shipping products are also included as a component of cost of goods sold. Many factors affect our
gross margin, including capacity utilization, product mix, production volume, and yield. We generally do not participate in any significant long-term contracts with suppliers, and we believe there are a number of potential suppliers for the raw
materials we use.

[0001193125-17-055058:mdna:25]
Selling and marketing expenses consist primarily of salaries, labor related benefits, and commissions paid
to our internal sales force, independent sales representatives, and our sales support staff, as well as costs associated with marketing materials and trade shows.

[0001193125-17-055058:mdna:26]
General and administrative costs primarily include the salaries for executive, finance, accounting, information technology, facilities and human resources personnel, as well as expenses for accounting and
legal assistance, incentive compensation expense, and gains or losses on the sale or disposal of property, plant and equipment.

[0001193125-17-055058:mdna:27]
CRITICAL
ACCOUNTING POLICIES AND ESTIMATES

[0001193125-17-055058:mdna:28]
Our consolidated financial statements included in this report have been prepared in
accordance with accounting principles generally accepted in the United States of America. The preparation of these financial statements requires us to make estimates and assumptions that affect the reported amounts of assets, liabilities, net sales
and expenses, and related disclosure of contingent assets and liabilities.

[0001193125-17-055058:mdna:29]
A critical accounting policy is defined as one that
is both material to the presentation of our consolidated financial statements and requires us to make judgments that could have a material effect on our financial condition or results of operations. These policies require us to make assumptions
about matters that are highly uncertain at the time of the estimate. Different estimates we could reasonably have used, or changes in the estimates that are reasonably likely to occur, or could have a material effect on our financial condition or
results of operations.

[0001193125-17-055058:mdna:30]
We base our estimates on historical experience and on various other assumptions that are believed to be
reasonable under the circumstances, the results of which form the basis for making judgments about the carrying values of assets and liabilities that are not readily apparent from other sources. Management has discussed the development, selection
and disclosure of these estimates with the audit committee of our board of directors. Actual results may differ from these estimates under different assumptions or conditions.

[0001193125-17-055058:mdna:31]
Our critical accounting policies include asset valuation related to bad debts and inventory; sales returns and allowances; impairment of long-lived assets, including goodwill and intangible assets;
realizability of deferred tax assets; and determining self-insurance reserves.

[0001193125-17-055058:mdna:32]
Allowance for Doubtful Accounts

[0001193125-17-055058:mdna:33]
We provide customary credit terms to our customers and generally do not require collateral. We perform ongoing credit
evaluations of the financial condition of our customers and maintain an allowance for doubtful accounts based upon historical collections experience and judgments as to expected collectability of accounts. Our actual bad debts may differ from our
estimates.

[0001193125-17-055058:mdna:34]
Inventories

[0001193125-17-055058:mdna:35]
In assessing the realizability of inventories, we are required to make judgments as to future demand requirements and compare these with current and committed inventory levels. When the market value of
inventory is less than the carrying value, the inventory cost is written down to its estimated net realizable value, thereby establishing a new cost basis. Our inventory requirements may change based on our projected customer

[0001193125-17-055058:mdna:36]
demand, market conditions, technological and product life cycle changes, longer or shorter than expected usage periods, and other factors that could affect the valuation of our inventories. We
maintain certain finished goods inventories near certain key customer locations in accordance with agreements with those customers. Although this inventory is typically supported by valid purchase orders, should these customers ultimately not
purchase these inventories, our results of operations and financial condition would be adversely affected.

[0001193125-17-055058:mdna:37]
Sales
Returns and Allowances

[0001193125-17-055058:mdna:38]
We derive revenues primarily from the sale of PCBs and custom electronic assemblies using
customer-supplied engineering and design plans. We recognize revenue when persuasive evidence of a sales arrangement exists, the sales terms are fixed or determinable, title and risk of loss have transferred, and collectability is reasonably assured
— generally when products are shipped to the customer. We provide our customers a limited right of return for defective PCBs and backplane assemblies. We accrue an estimate for sales returns and allowances at the time of sale using our judgment
based on historical results and anticipated returns as a result of current period sales. To the extent actual experience varies from our historical experience, revisions to these allowances may be required.

[0001193125-17-055058:mdna:39]
Long-lived Assets

[0001193125-17-055058:mdna:40]
We have significant long-lived tangible and intangible assets consisting of property, plant and equipment, definite-lived intangibles, and goodwill. We review these assets for impairment whenever events
or changes in circumstances indicate that the carrying amount of such assets may not be recoverable. In addition, we perform an impairment test related to goodwill at least annually. As necessary, we make judgments regarding future cash flow
forecasts in the assessment of impairment.

[0001193125-17-055058:mdna:41]
During the fourth quarter of each year, and when events and circumstances warrant
an evaluation, we perform an impairment assessment of goodwill, which may require the use of a fair-value based analysis. We first assesses qualitative factors to determine whether it is more likely than not that the fair value of a reporting unit
is less than its carrying amount. If we conclude that it is more likely than not that the fair value of a reporting unit is less than its carrying amount, we conduct a two-step quantitative goodwill impairment
test. We determine the fair value of our reporting units based on discounted cash flows and market approach analyses as considered necessary. We consider factors such as the state of the economy and reduced expectations for future cash flows coupled
with a decline in our market capitalization for a sustained period as indicators for potential goodwill impairment. If the reporting unit’s carrying amount exceeds its estimated fair value, a second step must be performed to measure the amount
of the goodwill impairment loss, if any. The second step compares the implied fair value of the reporting unit’s goodwill, determined in the same manner as the amount of goodwill recognized in a business combination, with the carrying amount of
such goodwill. If the carrying amount of the reporting unit’s goodwill exceeds the implied fair value of that goodwill, an impairment loss is recognized in an amount equal to that excess. We periodically evaluate whether events and
circumstances have occurred, such that the potential for reduced expectations for future cash flows coupled with a further decline in the market price of our stock and market capitalization may indicate that the remaining balance of goodwill and
definite-lived intangible assets may not be recoverable. If factors indicate that assets are impaired, we would be required to reduce the carrying value of our goodwill and definite-lived intangible assets which may result in an impairment charge.

[0001193125-17-055058:mdna:42]
We also assess other long-lived assets, specifically definite-lived intangibles and property, plant and equipment, for
potential impairment given similar impairment indicators. When indicators of impairment exist related to our long-lived tangible assets and definite-lived intangible assets, we use an estimate of the undiscounted net cash flows and comparison to
like-kind assets, as appropriate, in measuring whether the carrying amount of the assets is recoverable. Measurement of the amount of impairment, if any, is based upon the difference between the asset’s carrying value and estimated fair value.
Fair value is determined through various valuation techniques, including cost-based, market and income approaches as considered necessary, which involve judgments related to future cash flows and the application of the appropriate valuation model.
During the years ended 2016 and 2014 we recorded impairment charges to reduce the carrying value of certain long-lived assets in the PCB operating segment. See Note 4 to our consolidated financial statements.

[0001193125-17-055058:mdna:43]
Assets Held for Sale — We classify assets to be sold as assets held for sale
when (i) we have approved and commit to a plan to sell the asset, (ii) the asset is available for immediate sale in its present condition, (iii) an active program to locate a buyer and other actions required to sell the asset have
been initiated, (iv) the sale of the asset is probable, (v) the asset is being actively marketed for sale at a price that is reasonable in relation to its current fair value, and (vi) it is unlikely that significant changes to the
plan will be made or that the plan will be withdrawn. Assets classified as held for sale are recorded at the lower of the carrying amount or fair value less the cost to sell.

[0001193125-17-055058:mdna:44]
Assets Held for Use — If a decision to dispose of an asset or a business is made and the held for sale criteria are not met, it is considered held for use. Assets of the business are evaluated
for recoverability in the following order: (i) assets other than goodwill, property and intangibles; (ii) property and intangibles subject to amortization; and (iii) goodwill. In evaluating the recoverability of property and
intangible assets subject to amortization, in a held for use business, the carrying value is first compared to the sum of the undiscounted cash flows expected to result from the use and eventual disposition. If the carrying value exceeds the
undiscounted expected cash flows, then a fair value analysis is performed. An impairment charge is recognized if the carrying value exceeds the fair value.

[0001193125-17-055058:mdna:45]
Income Taxes

[0001193125-17-055058:mdna:46]
Deferred income tax assets are reviewed for
recoverability, and valuation allowances are provided, when necessary, to reduce deferred income tax assets to the amounts that are more likely than not to be realized based on our estimate of future taxable income. At January 2, 2017, we had a
net noncurrent deferred income tax liability of $14.0 million, which is net of the $76.9 million deferred tax assets. At January 2, 2017, our deferred income tax assets of $76.9 million were net of a valuation allowance of
approximately $222.0 million. Should our expectations of taxable income change in future periods, it may be necessary to adjust our valuation allowance, which could affect our results of operations in the period such a determination is made. We
record income tax provision or benefit during interim periods at a rate that is based on expected results for the full year. If future changes in market conditions cause actual results for the year to be more or less favorable than those expected,
adjustments to the effective income tax rate could be required.

[0001193125-17-055058:mdna:47]
In addition, we are subject to income taxes in the United
States and foreign jurisdictions. Significant judgment is required in determining our worldwide provision for income taxes. In the ordinary course of our business, there are many transactions for which the ultimate tax determination is uncertain.
Additionally, our calculations of income taxes are based on our interpretations of applicable tax laws in the jurisdictions in which we file.

[0001193125-17-055058:mdna:48]
Self Insurance

[0001193125-17-055058:mdna:49]
We are primarily self-insured in North America for
group health insurance and worker’s compensation benefits provided to our U.S. employees, and we purchase insurance to protect against annual claims at the individual and aggregate level. We estimate our exposure for claims incurred but not
reported at the end of each reporting period. We use our judgment using our historical claim data and information and analysis provided by actuarial and claim advisors, our insurance carriers and brokers on an annual basis to estimate our liability
for these claims. This liability is subject to individual insured stop-loss coverage of $350,000 per individual for group health insurance and $250,000 per individual for worker’s compensation benefits. Our actual claims experience may differ
from our estimates.

[0001193125-17-055058:mdna:50]
RESULTS OF OPERATIONS

[0001193125-17-055058:mdna:51]
We operate on a 52 or 53 week year ending on the Monday nearest December 31. Fiscal 2016 consisted of 53 weeks ended on January 2, 2017 with the additional week included in the fourth quarter.
We estimate the additional week contributed approximately $29.2 million of additional revenue and approximately $1.1 million of additional operating income for the year ended January 2, 2017. Fiscal year 2015 and 2014 were 52 weeks
ended December 28, 2015 and December 29, 2014, respectively.

[0001193125-17-055058:mdna:52]
The Viasystems acquisition occurred on May 31,
2015. Accordingly, the results of operations of Viasystems are not included in our fiscal year 2014, and our fiscal year 2015 only includes the last seven fiscal months

[0001193125-17-055058:mdna:53]
Viasystems’ 2015 results of operations. The acquisition has had and will continue to have a significant effect on our operations as discussed in the various comparisons noted below.

[0001193125-17-055058:mdna:54]
The following table sets forth the relationship of various items to net sales in our consolidated statements of operations:

[0001193125-17-055058:mdna:55]
|  |  | For the Year Ended |  |
|  |  | January 2,2017 |  |  | December 28,2015 |  |  | December 29,2014 |  |
| Net sales |  |  | 100.0 | % |  |  | 100.0 | % |  |  | 100.0 | % |
| Cost of goods sold |  |  | 83.3 |  |  |  | 85.2 |  |  |  | 85.3 |  |
| Gross profit |  |  | 16.7 |  |  |  | 14.8 |  |  |  | 14.7 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |
| Selling and marketing |  |  | 2.6 |  |  |  | 2.7 |  |  |  | 2.8 |  |
| General and administrative |  |  | 5.8 |  |  |  | 8.0 |  |  |  | 7.6 |  |
| Amortization of definite-lived intangibles |  |  | 1.0 |  |  |  | 0.9 |  |  |  | 0.7 |  |
| Impairment of long-lived assets |  |  | 0.1 |  |  |  | — |  |  |  | 0.1 |  |
| Restructuring charges |  |  | 0.4 |  |  |  | 0.4 |  |  |  | — |  |
| Gain on sale of assets |  |  | — |  |  |  | (0.1 | ) |  |  | — |  |
| Total operating expenses |  |  | 9.9 |  |  |  | 11.9 |  |  |  | 11.2 |  |
| Operating income |  |  | 6.8 |  |  |  | 2.9 |  |  |  | 3.5 |  |
| Other income (expense): |  |  |  |  |  |  |  |  |  |  |  |  |
| Interest expense |  |  | (3.0 | ) |  |  | (2.9 | ) |  |  | (1.8 | ) |
| Loss on extinguishment of debt |  |  | (1.9 | ) |  |  | — |  |  |  | — |  |
| Other, net |  |  | 0.7 |  |  |  | 0.4 |  |  |  | — |  |
| Total other expense, net |  |  | (4.2 | ) |  |  | (2.5 | ) |  |  | (1.8 | ) |
| Income before income taxes |  |  | 2.6 |  |  |  | 0.4 |  |  |  | 1.7 |  |
| Income tax provision |  |  | (1.2 | ) |  |  | (1.6 | ) |  |  | (0.6 | ) |
| Net income (loss) |  |  | 1.4 |  |  |  | (1.2 | ) |  |  | 1.1 |  |
| Less: Net income attributable to the noncontrolling interest |  |  | — |  |  |  | — |  |  |  | — |  |
| Net income (loss) attributable to TTM Technologies, Inc. stockholders |  |  | 1.4 | % |  |  | (1.2 | )% |  |  | 1.1 | % |

[0001193125-17-055058:mdna:56]
We have reviewed our reportable operating segments and determined that we continue to have two reportable
operating segments: PCB and E-M Solutions. The PCB reportable segment is comprised of multiple operating segments. This determination was made based on the criteria of earning revenues and incurring expenses,
our organizational structure which has segment managers who report to the chief operating decision maker, discrete financial information, and the aggregation of similar operating segments into reportable operating segments.

[0001193125-17-055058:mdna:57]
47

[0001193125-17-055058:mdna:58]
The following table compares net sales by reportable segment for fiscal years 2016, 2015 and
2014:

[0001193125-17-055058:mdna:59]
|  |  | For the Year Ended |  |
|  |  | January 2,2017 |  |  | December 28,2015 |  |  | December 29,2014 |  |
|  |  | (In thousands) |  |
| Net Sales: |  |  |  |  |  |  |  |  |  |  |  |  |
| PCB |  | $ | 2,346,554 |  |  | $ | 1,944,041 |  |  | $ | 1,251,665 |  |
| E-M Solutions |  |  | 198,483 |  |  |  | 158,655 |  |  |  | 76,545 |  |
| Total sales |  |  | 2,545,037 |  |  |  | 2,102,696 |  |  |  | 1,328,210 |  |
| Inter-segment sales |  |  | (11,678 | ) |  |  | (7,208 | ) |  |  | (2,493 | ) |
| Total net sales |  | $ | 2,533,359 |  |  | $ | 2,095,488 |  |  | $ | 1,325,717 |  |

[0001193125-17-055058:mdna:60]
Net Sales

[0001193125-17-055058:mdna:61]
Total net sales increased $437.9 million, or 20.9%, from $2,095.5 million for the year ended December 28, 2015 to $2,533.4 million for the year ended January 2, 2017. Net sales
for the PCB operating segment, excluding inter-segment sales, increased $397.7 million, or 20.5%, from $1,937.2 million for the year ended December 28, 2015 to $2,334.9 million for the year ended January 2, 2017. This
increase is primarily due to the additional sales resulting from a full year contribution from the acquisition of Viasystems, combined with higher demand in our Automotive and Aerospace and Defense end markets, partially offset with lower demand in
our Cellular Phone end market. These changes, including the sales from Viasystems, resulted in a 40% increase in PCB shipments from the year ended December 28, 2015. In addition, the average PCB selling price decreased 13%, which was driven by
a product mix shift resulting from the acquisition. Net sales for the E-M Solutions operating segment, excluding inter-segment sales, increased $40.2 million, or 25.4%, from $158.3 million for the
year ended December 28, 2015 to $198.5 million for the year ended January 2, 2017. This increase is due to the additional sales resulting from the acquisition of Viasystems.

[0001193125-17-055058:mdna:62]
Total net sales increased $769.8 million, or 58.1%, from $1,325.7 million for the year ended December 29, 2014 to
$2,095.5 million for the year ended December 28, 2015. Net sales for the PCB operating segment, excluding inter-segment sales, increased $687.7 million, or 55.0%, from $1,249.5 million for the year ended December 29, 2014 to
$1,937.2 million for the year ended December 28, 2015. This increase is primarily due to the additional sales resulting from the acquisition of Viasystems, which accounted for $582.3 million in PCB sales for the year ended
December 28, 2015. Additionally, the increase in PCB sales is due to higher demand in our Cellular Phone end market, partially offset with lower demand in our Networking/Communications end market. These changes, including the sales from
Viasystems, resulted in a 110% increase in PCB shipments from the year ended December 29, 2014. In addition, the average PCB selling price decreased 25%, which was driven by a product mix shift resulting from the acquisition. Net sales for the E-M Solutions operating segment, excluding inter-segment sales, increased $82.1 million, from $76.2 million for the year ended December 29, 2014 to $158.3 million for the year ended
December 28, 2015. This increase is due to the acquisition of Viasystems, which accounted for $82.0 million in E-M Solutions sales for the year ended December 28, 2015.

[0001193125-17-055058:mdna:63]
The inter-segment sales are primarily sales from the PCB operating segment to the E-M Solutions
operating segment.

[0001193125-17-055058:mdna:64]
Gross Margin

[0001193125-17-055058:mdna:65]
Overall gross margin increased from 14.8% for the year ended December 28, 2015 to 16.7% for the year ended January 2, 2017. Gross margin for the PCB operating segment increased from 15.5% for
the year ended December 28, 2015 to 17.7% for the year ended January 2, 2017 primarily due to higher utilization and full year contribution from the Automotive focused facilities and the absence of $13.3 million of increased costs
incurred during fiscal year 2015 due to the fair value mark up of acquired inventory associated with the acquisition of Viasystems. Gross margin for the E-M Solutions operating segment increased from 6.6% for
the year ended December 28, 2015 to 9.1% for the year ended January 2, 2017 primarily due to increased production volumes at certain acquired facilities.

[0001193125-17-055058:mdna:66]
Overall gross margin increased from 14.7% for the year ended December 29, 2014 to 14.8%
for the year ended December 28, 2015. Gross margin for the PCB operating segment increased from 15.0% for the year ended December 29, 2014 to 15.5% for the year ended December 28, 2015 primarily due to higher utilization at our
advanced technology plants, partially offset by the acquisition of Viasystems with lower margins than our existing business and $13.3 million of increased costs due to the fair value mark up of acquired inventory associated with the acquisition
of Viasystems. Gross margin for the E-M Solutions operating segment decreased from 9.4% for the year ended December 29, 2014 to 6.6% for the year ended December 28, 2015 primarily due to the
acquisition of Viasystems.

[0001193125-17-055058:mdna:67]
Selling and Marketing Expenses

[0001193125-17-055058:mdna:68]
Selling and marketing expenses increased $9.0 million from $57.4 million for the year ended December 28, 2015 to
$66.4 million for the year ended January 2, 2017. Additionally, selling and marketing expenses increased $20.5 million, from $36.9 million for the year ended December 29, 2014 to $57.4 million for the year ended
December 28, 2015. The increase in selling and marketing expense for the years ended January 2, 2017 and December 28, 2015 primarily related to additional selling and marketing activities resulting from the acquisition of Viasystems.
As a percentage of net sales, selling and marketing expenses were 2.6% for the year ended January 2, 2017, as compared to 2.7% for the year ended December 28, 2015, and 2.8% for the year ended December 29, 2014. The decrease in
selling and marketing expense as a percentage of net sales for the periods noted was primarily due to higher net sales.

[0001193125-17-055058:mdna:69]
General and Administrative Expenses

[0001193125-17-055058:mdna:70]
General and administrative expenses decreased $20.5 million from $167.7 million, or 8.0% of net sales, for the year ended December 28, 2015 to $147.2 million, or 5.8% of net sales, for
the year ended January 2, 2017. The decrease in expense primarily related to a decrease of $32.8 million in acquisition-related costs as compared to the year ended December 28, 2015, partially offset by increased expenses resulting
from the acquisition of Viasystems. The decrease in general and administrative expense as percentage of net sales was primarily due to the decrease in acquisition-related costs and higher net sales.

[0001193125-17-055058:mdna:71]
General and administrative expenses increased $66.7 million from $101.0 million, or 7.6% of net sales, for the year ended
December 29, 2014 to $167.7 million, or 8.0% of net sales, for the year ended December 28, 2015. The increase in expense was primarily due to $34.4 million of acquisition-related costs for the year ended December 28, 2015
associated with the acquisition of Viasystems and seven months of general and administrative expense resulting from Viasystems post acquisition through December 28, 2015.

[0001193125-17-055058:mdna:72]
Impairment of Long-Lived Assets and Restructuring Charges

[0001193125-17-055058:mdna:73]
For the
years ended January 2, 2017 and December 28, 2015, we incurred restructuring charges of $8.9 million and $7.4 million, respectively, related to the Consolidation Plan announced on September 29, 2015, that resulted in the
closure of our facilities in Cleveland, Ohio, Milpitas, California, and Juarez, Mexico and other global realignment efforts.

[0001193125-17-055058:mdna:74]
During the year ended January 2, 2017, in connection with the Consolidation Plan, we recognized restructuring charges of
$3.7 million, $4.5 million and $0.7 million in our PCB, E-M Solutions and Corporate segments, respectively. For the year ended December 28, 2015, we recognized restructuring charges of
$2.0 million in both our PCB and E-M Solutions segments and $3.4 million in our Corporate segment. These charges primarily represent employee separation and contract termination and other costs
associated with the Consolidation Plan and other global realignment restructuring efforts. As of January 2, 2017, the Company has incurred approximately $16.3 million of restructuring charges since the September 29, 2015 announcement.

[0001193125-17-055058:mdna:75]
Additionally, as a result of the above mentioned plant closures and other plant realignment efforts, we also recognized
impairment charges of $3.3 million for the year ended January 2, 2017, of which $1.4 million were recognized in our PCB operating segment and $1.9 million were recognized in the Corporate operating segment. The impairment charge
for the PCB operating segment related to machinery and equipment while the impairment charge for the Corporate operating segment related to the write-off of capitalized software costs.

[0001193125-17-055058:mdna:76]
If forecasts and assumptions used to support the realizability of our long-lived assets
change in the future, significant impairment or restructuring charges could result that would adversely affect our results of operations and financial condition.

[0001193125-17-055058:mdna:77]
Other Income (Expense)

[0001193125-17-055058:mdna:78]
Other expense, net increased
$54.1 million from $52.4 million for the year ended December 28, 2015 to $106.5 million for the year ended January 2, 2017. The increase in other expense, net was primarily due to the loss on extinguishment of debt of
$47.8 million related to the full repayment of the May 31, 2015 Term Loan and newly issued $775.0 million Term B Loan on September 27, 2016. Another factor contributing to the increase in other expense, net was the increase in
interest expense of $16.2 million related to our Term Loan, which was paid off, and currently outstanding Term Loan B and ABL Revolving Loans, compared with only seven months of the Term Loan and ABL Revolving Loans facilities outstanding
during 2015 which was secured in connection with the acquisition of Viasystems. The increase in other expense, net was partially offset by $13.5 million foreign currency and derivative transaction gains for the year ended January 2, 2017
compared to $6.4 million for the year ended December 28, 2015.

[0001193125-17-055058:mdna:79]
Other expense, net increased $28.2 million from
$24.2 million for the year ended December 29, 2014 to $52.4 million for the year ended December 28, 2015. The increase in other expense, net was primarily due to an increase in interest expense related to a new long-term
borrowing and a revolver loan totaling $1,030.0 million at a weighted average interest rate of 5.7% that we secured in connection with the acquisition of Viasystems. The increase in other expense, net was partially offset by $6.4 million
foreign currency and derivative transaction gains for the year ended December 28, 2015 compared to $1.2 million for the year ended December 29, 2014.

[0001193125-17-055058:mdna:80]
Income Taxes

[0001193125-17-055058:mdna:81]
The provision for income taxes decreased
$3.2 million from an income tax expense of $34.6 million for the year ended December 28, 2015 to $31.4 million for the year ended January 2, 2017. The decrease in income tax expense in 2016 is primarily due to the release of
uncertain tax positions due to lapse of statute in foreign jurisdiction.

[0001193125-17-055058:mdna:82]
Our tax expense is primarily impacted by tax rates in
China and Hong Kong, the U.S. federal income tax rate, apportioned state income tax rates, generation of other credits and deductions available to us, change in valuation allowance, and certain non-deductible
items. Certain losses generated are not more likely than not to be realizable, and thus no income tax benefit has been recognized on these losses. As of January 2, 2017, we had a net deferred income tax liability of approximately
$14.0 million; and as of December 28, 2015, we had a net deferred income tax liability of approximately $13.1 million. As of January 2, 2017, we have a full valuation allowance recorded in U.S. Based on our forecast for future
taxable earnings in certain foreign jurisdictions, we believe it is more likely than not that we will utilize the deferred income tax assets in future periods.

[0001193125-17-055058:mdna:83]
The provision for income taxes increased $27.0 million from an income tax expense of $7.6 million for the year ended December 29, 2014 to $34.6 million for the year ended
December 28, 2015. The increase in income tax expense in 2015 was primarily due to the provision of a full valuation allowance on existing U.S. deferred tax assets, partially offset by the reversal of deferred tax liabilities related to our
decision to indefinitely reinvest the foreign earnings attributable to our backplane assembly facility in Shanghai, China. Further, the income tax expense in 2015 was higher due to inclusion of Viasystems earnings from foreign subsidiaries post
acquisition.

[0001193125-17-055058:mdna:84]
Liquidity and Capital Resources

[0001193125-17-055058:mdna:85]
Our principal sources of liquidity have been cash provided by operations, the issuance of convertible senior notes, and term and revolving debt. Our principal uses of cash have been to acquire Viasystems,
finance capital expenditures, meet debt service requirements, fund working capital requirements, and refinance existing debt. We anticipate that servicing debt, financing capital expenditures, financing acquisitions, and funding working capital
requirements will continue to be the principal demands on our cash in the future.

[0001193125-17-055058:mdna:86]
Cash flow provided by operating activities
during the year ended January 2, 2017 was $298.3 million as compared to $237.5 million in the same period in 2015. The improved cash flow was the result of stronger

[0001193125-17-055058:mdna:87]
operational performance and the full year contribution of Viasystems. As of January 2, 2017, we had net working capital of approximately $323.8 million compared to $277.5 million
as of December 28, 2015. At January 2, 2017 cash cycle days improved to 43 days as compared to 49 days at December 28, 2015.

[0001193125-17-055058:mdna:88]
Net cash used in investing activities was approximately $78.0 million for the year ended January 2, 2017 primarily reflecting the purchases of property, plant and equipment of
$85.1 million, offset by net of proceeds from sales of property, plant and equipment and assets held for sale of $3.6 million and the release of restricted cash to cash and cash equivalents of $3.5 million.

[0001193125-17-055058:mdna:89]
Net cash used in financing activities was approximately $217.1 million for the year ended January 2, 2017 primarily reflecting
the full repayment of the May 31, 2015 Term Loan, and the repayments of normally scheduled principal payments and additional prepayments of principal of our long-term debt, which amounts totaled $1,022.6 million, offset by
$775.0 million newly issued Term B Loan and proceeds from our Asia ABL revolving loan of $30.0 million.

[0001193125-17-055058:mdna:90]
As of
January 2, 2017, we had cash and cash equivalents of approximately $256.3 million, of which approximately $206.1 million was held by our foreign subsidiaries, primarily in Asia. Cash and cash equivalents held by our foreign locations
are expected to be used in local operations.

[0001193125-17-055058:mdna:91]
Our 2017 capital expenditure plan is expected to be in the range of
$130.0 million to $140.0 million of which 50 percent are planned for technology enhancements, 25 percent for capacity expansion and 25 percent for compliance and maintenance related expenditures.

[0001193125-17-055058:mdna:92]
Term and Revolving Loans

[0001193125-17-055058:mdna:93]
On May 31, 2015, in conjunction with the acquisition of Viasystems, we entered into a $950.0 million Term Loan Credit Agreement (Term Loan). Additionally, we entered into a $150.0 million
U.S. ABL and a $150.0 million Asia ABL. We drew $80.0 million of the U.S. ABL at the closing of the acquisition of Viasystems.

[0001193125-17-055058:mdna:94]
On September 27, 2016, we issued new $775.0 million Term Loan B at an interest rate of LIBOR, with a 1.0% LIBOR floor, plus 4.25%, a reduction of 75 basis points from our previous Term Loan, and
repaid in full the remaining outstanding balance of the May 31, 2015 Term Loan. This transaction was accounted for as an extinguishment of debt and accordingly, we recognized a loss of $47.8 million primarily associated with the write off
of the remaining unamortized debt discount and issuance costs.

[0001193125-17-055058:mdna:95]
Additionally, on September 27, 2016, we amended our U.S.
ABL credit facility to increase the amount available to $200.0 million, reduce the applicable margin by 25 basis points for both Eurodollar loans and ABR loans, and reduce the Letters of Credit Facilities to $50 million. On
December 22, 2016, we amended our Asia ABL credit facility to reduce the interest margin by 35 basis points.

[0001193125-17-055058:mdna:96]
The Term
Loan B bears interest at a floating rate of LIBOR, with a 1.0% LIBOR floor, plus an applicable interest margin of 4.25%, or JP Morgan Chase Bank’s prime rate, with a 2% floor, plus a margin of 3.25%, at the our option. At January 2, 2017,
the weighted average interest rate on the outstanding borrowings under the Term Loan was 5.25%. There is no provision, other than an event of default, for the interest margin to increase. The Term Loan B will mature on May 31, 2021. The Term
Loan B is secured by a significant amount of our assets and a pledge of 65% of voting stock of our first tier foreign subsidiaries and is structurally senior to our convertible senior notes. See Convertible Senior Notes below.

[0001193125-17-055058:mdna:97]
The amended U.S. ABL consists of three tranches comprised of a revolving credit facility of up to $200.0 million, a letter of credit
facility of up to $50.0 million, and swingline loans of up to $30.0 million, provided that at no time may amounts outstanding under the tranches exceed in aggregate $200.0 million or the applicable borrowing base, which is a
percentage of the principal amount of Eligible Accounts, as defined in the U.S. ABL agreement. Borrowings under the U.S. ABL bear interest at either a floating rate of LIBOR plus a margin of 150 basis points or JP Morgan Chase Bank’s prime rate
plus a margin of 50 basis points, at our option. At January 2, 2017, the weighted average interest rate on the outstanding borrowings under the U.S. ABL was 2.27%. The applicable margin can vary based on the remaining availability of the
facility, from 125 to 175 basis

[0001193125-17-055058:mdna:98]
points for LIBOR-based loans and from 25 to 75 basis points for JP Morgan Chase Bank’s prime rate-based loans. Other than availability and an event of default, there are no other provisions
for the interest margin to increase. The U.S. ABL will mature on May 31, 2020. Loans made under the U.S. ABL are secured first by all of our domestic cash, receivables and inventories as well as by a second position against a significant amount
of our assets and a pledge of 65% of voting stock of our first tier foreign subsidiaries and are structurally senior to our convertible senior notes. See Convertible Senior Notes below. At January 2, 2017, $80.0 million of the U.S. ABL was
outstanding. We and our domestic subsidiaries have fully and unconditionally guaranteed the full and timely payment of all Term Loan B and U.S. ABL related obligations.

[0001193125-17-055058:mdna:99]
The Asia ABL consists of two tranches comprised of a revolving credit facility of up to $150.0 million and a letter of credit facility of up to $100.0 million, provided that at no time may
amounts outstanding under both tranches exceed in aggregate $150.0 million or the applicable borrowing base, which is a percentage of the principal amount of Eligible Accounts, as defined in the Asia ABL agreement. Borrowings under the Asia ABL
bear interest at a floating rate of LIBOR plus 140 basis points. At January 2, 2017, the weighted average interest rate on the outstanding borrowings under the Asia ABL was 2.17%. There is no provision, other than an event of default, for the
interest margin to increase. The Asia ABL will mature on May 22, 2020. Loans made under the Asia ABL are secured by a portion of our Asia Pacific cash and receivables and are structurally senior to our domestic obligations, including the
convertible senior notes. See Convertible Senior Notes below. Our Asia Pacific subsidiary and certain of our subsidiaries have fully and unconditionally guaranteed the full and timely payment of all Asia ABL related obligations. At January 2,
2017, $30.0 million of the Asia ABL was outstanding.

[0001193125-17-055058:mdna:100]
During the year ended January 2, 2017, we made net debt
principal payments totaling $217.6 million representing normal principal payments as well as additional prepayments of principal. We are not required to make quarterly scheduled payments of the outstanding Term Loan B balance due to mandatory
payments and optional loan prepayments applied to date. Based on certain parameters defined in the Term Loan B agreement, including secured leverage ratio, we may be required to make an additional principal payment on an annual basis. Any remaining
outstanding balances under the Term Loan B are due at the maturity date of May 31, 2021. Borrowings under the Term Loan B are subject to financial and operating covenants including maintaining a maximum total leverage ratio. Under the
occurrence of certain events, the U.S. ABL and the Asia ABL are subject to financial and operational covenants, including maintaining minimum fixed charge coverage ratios. At January 2, 2017, we were in compliance with the covenants under the
Term Loan B, the U.S. ABL and the Asia ABL.

[0001193125-17-055058:mdna:101]
We are required to pay a commitment fee of 0.25% to 0.375% per annum on any
unused portion of the U.S. ABL or Asia ABL based on utilization levels. We incurred total commitment fees related to unused borrowing availability of $0.7 million, $0.8 million, and $0.6 million for the years ended January 2,
2017, December 28, 2015, and December 29, 2014, respectively. As of January 2, 2017, the outstanding amount of the Term Loan B was $700.0 million, which is included as long-term debt. Additionally, $80.0 million of the
U.S. ABL and $30.0 million of the Asia ABL were outstanding as of January 2, 2017, which were classified as short-term debt. Available borrowing capacity under the U.S. ABL and Asia ABL was $113.0 million and $111.7 million,
which includes letters of credit outstanding of $7.0 million and $8.3 million mentioned below, respectively, at January 2, 2017.

[0001193125-17-055058:mdna:102]
Letters of Credit

[0001193125-17-055058:mdna:103]
We have up to $50.0 million and $100.0 million
Letters of Credit Facilities available under the U.S. ABL and the Asia ABL, respectively. As of January 2, 2017, letters of credit in the amount of $7.0 million were outstanding under the U.S. ABL and $8.3 million were outstanding
under the Asia ABL with various expiration dates through December 2017.

[0001193125-17-055058:mdna:104]
Chinese Revolver

[0001193125-17-055058:mdna:105]
We are party to a revolving loan credit facility with a lender in China. Under this arrangement, the lender has made available to us
approximately $30.2 million in unsecured borrowing with all terms of the borrowing to

[0001193125-17-055058:mdna:106]
be negotiated at the time the Chinese Revolver is drawn upon. There are no commitment fees on the unused portion of the Chinese Revolver, and this arrangement expires in January 2018. As of
January 2, 2017, the Chinese Revolver had not been drawn upon.

[0001193125-17-055058:mdna:107]
Convertible Senior Notes due 2020

[0001193125-17-055058:mdna:108]
We issued 1.75% convertible senior notes due December 15, 2020, in a public offering for an aggregate principal amount of
$250.0 million. The convertible senior notes bear interest at a rate of 1.75% per annum. Interest is payable semiannually in arrears on June 15 and December 15 of each year. The convertible senior notes are senior unsecured
obligations and rank equally to our future unsecured senior indebtedness and senior in right of payment to any of our future subordinated indebtedness. Offering expenses are being amortized to interest expense over the term of the convertible senior
notes.

[0001193125-17-055058:mdna:109]
Conversion:    At any time prior to March 15, 2020, holders may
convert their convertible senior notes into cash and, if applicable, into shares of our common stock based on a conversion rate of 103.7613 shares of our common stock per $1,000 principal amount of convertible senior notes, subject to adjustment,
under the following circumstances: (1) during any calendar quarter beginning after March 31, 2015 (and only during such calendar quarter), if the last reported sale price of our common stock for at least 20 trading days during the 30
consecutive trading days ending on the last trading day of the immediately preceding calendar quarter is greater than or equal to 130% of the applicable conversion price on each applicable trading day of such preceding calendar quarter;
(2) during the five business day period after any 10 consecutive trading day period in which the trading price per note for each day of that 10 consecutive trading day period was less than 98% of the product of the last reported sale price of
our common stock and the conversion rate on such day; or (3) upon the occurrence of specified corporate transactions described in the indenture governing the notes. As of January 2, 2017, the conversion criteria had been met allowing
holders to give notice of conversion in the first quarter of 2017.

[0001193125-17-055058:mdna:110]
On or after March 15, 2020 until the close of business
on the third scheduled trading day preceding the maturity date, holders may convert their notes at any time, regardless of the foregoing circumstances. Upon conversion, for each $1,000 principal amount of notes, we will pay shares of our common
stock, cash or a combination of cash and shares of our common stock at our election, if applicable, based on a daily conversion value calculated on a proportionate basis for each day of the 80 trading day observation period. All conversions
occurring on the same date or on or after March 15, 2020 shall be settled using the same settlement method. Additionally, in the event of a fundamental change as defined in the indenture governing the notes, or other conversion rate adjustments
such as share splits or combinations, other distributions of shares, cash or other assets to stockholders, including self-tender transactions (Other Conversion Rate Adjustments), the conversion rate may be modified to adjust the number of shares per
$1,000 principal amount of the notes. As of January 2, 2017, none of the criteria for a fundamental change or a conversion rate adjustment had been met.

[0001193125-17-055058:mdna:111]
The maximum number of shares issuable upon conversion, including the effect of a fundamental change and subject to Other Conversion Rate Adjustments, would be 32.4 million.

[0001193125-17-055058:mdna:112]
Note Repurchase:    We are not permitted to redeem the convertible senior notes at any
time prior to maturity. In the event of a fundamental change or certain default events, as defined in the indenture governing the notes, holders may require us to repurchase for cash all or a portion of their convertible senior notes at a price
equal to 100% of the principal amount, plus any accrued and unpaid interest.

[0001193125-17-055058:mdna:113]
In connection with the issuance of the
convertible senior notes due 2020, we entered into a convertible note hedge and warrant transaction (the Call Spread Transaction), with respect to our common stock. The convertible note hedge consists of our option to purchase up to
25.9 million common stock shares at a price of $9.64 per share. The hedge expires on December 15, 2020 and can only be executed upon the conversion of the above mentioned convertible senior notes due 2020. Additionally, we sold warrants to
purchase 25.9 million shares of our common stock at a price of $14.26 per share. The warrants expire ratably from March 2021 through January 2022. The Call Spread Transaction has no effect on the terms of the convertible senior notes due 2020
and reduces potential dilution by effectively increasing the conversion price of the convertible senior notes due 2020 to $14.26 per share of our common stock.

[0001193125-17-055058:mdna:114]
Based on our current level of operations, we believe that cash generated from operations,
cash on hand and cash from the issuance of term and revolving debt will be adequate to meet our currently anticipated capital expenditure, debt service, and working capital needs for the next 12 months.

[0001193125-17-055058:mdna:115]
Contractual Obligations and Commitments

[0001193125-17-055058:mdna:116]
The following table provides information on our contractual obligations as of January 2, 2017:

[0001193125-17-055058:mdna:117]
| Contractual Obligations(1) |  | Total |  |  | Less Than1 Year |  |  | 1 - 3Years |  |  | 4 - 5Years |  |  | After5 Years |  |
|  |  | (In thousands) |  |
| Long-term debt obligations |  | $ | 811,798 |  |  | $ | 110,652 |  |  | $ | 739 |  |  | $ | 700,407 |  |  | $ | — |  |
| Convertible debt obligations |  |  | 250,000 |  |  |  | — |  |  |  | — |  |  |  | 250,000 |  |  |  | — |  |
| Interest on debt obligations |  |  | 185,228 |  |  |  | 44,656 |  |  |  | 83,395 |  |  |  | 57,177 |  |  |  | — |  |
| Equipment payables |  |  | 12,430 |  |  |  | 12,430 |  |  |  | — |  |  |  | — |  |  |  | — |  |
| Purchase obligations |  |  | 82,690 |  |  |  | 78,520 |  |  |  | 4,165 |  |  |  | 5 |  |  |  | — |  |
| Operating lease commitments |  |  | 24,490 |  |  |  | 7,893 |  |  |  | 7,531 |  |  |  | 4,050 |  |  |  | 5,016 |  |
| Total contractual obligations |  | $ | 1,366,636 |  |  | $ | 254,151 |  |  | $ | 95,830 |  |  | $ | 1,011,639 |  |  | $ | 5,016 |  |

[0001193125-17-055058:mdna:118]
| (1) | Unrecognized uncertain tax benefits of $39.7 million are not included in the table above as the settlement timing is uncertain. |

[0001193125-17-055058:mdna:119]
Off Balance Sheet Arrangements

[0001193125-17-055058:mdna:120]
We do not currently have, nor have we ever had, any relationships with unconsolidated entities or financial partnerships, such as entities often referred to as structured finance or special purpose
entities, which would have been established for the purpose of facilitating off-balance sheet arrangements or other contractually narrow or limited purposes. In addition, we do not engage in trading activities
involving non-exchange traded contracts. As a result, we are not materially exposed to any financing, liquidity, market, or credit risk that could arise if we had engaged in these relationships.

[0001193125-17-055058:mdna:121]
Seasonality

[0001193125-17-055058:mdna:122]
Orders for
our products generally correspond to the production schedules of our customers. We historically experience higher net sales in the third and fourth quarters due to end customer demand in the fourth quarter for consumer electronics products. Seasonal
fluctuations also include the Chinese New Year holidays in the first quarter, which typically results in lower net sales. We attribute this decline to shutdowns of our customers’ and our own China based manufacturing facilities surrounding the
Chinese New Year public holidays, which normally occur in January or February of each year.

[0001193125-17-055058:mdna:123]
Recently Issued Accounting Standards

[0001193125-17-055058:mdna:124]
In October 2016, the Financial Accounting Standards Board (FASB) issued Accounting Standards Update (ASU) 2016-16, Income Taxes (Topic 740): Intra-Entity Transfers of Assets Other Than Inventory. The objective of this update is to improve the accounting for the income tax consequences of intra-entity transfers of
assets other than inventory by recognizing the income tax consequences when the transfer occurs. This ASU is effective for fiscal years beginning after December 15, 2017, including interim periods within those fiscal years. Early adoption is
permitted. We are currently evaluating the new guidance to determine the impact it may have on our consolidated financial statements.

[0001193125-17-055058:mdna:125]
In August 2016, the FASB issued ASU 2016-15, Statement of Cash Flows (Topic 230). The objective of this update is to add or clarify guidance on the
classification of certain cash receipts and payments in the statement of cash flows. This ASU is effective for fiscal years beginning after December 15, 2017, including interim periods within those annual periods and is to be applied utilizing
a retrospective approach. Early adoption is permitted. We are currently evaluating the new guidance to determine the impact it may have on our consolidated financial statements and related disclosures.

[0001193125-17-055058:mdna:126]
In March 2016, the FASB issued Accounting Standards Update (ASU) 2016-09, Stock Compensation (Topic 718): Improvements to Employee Share-Based Payment Accounting. The objective of this update is to simplify several aspects of the accounting for employee share-based payment
transactions, including the income tax consequences, classification of awards as either equity or liabilities, and classification on the statement of cash flows. This ASU is effective for fiscal years beginning after December 15, 2016,
including interim periods within those fiscal years. Early adoption is permitted. The impact on our consolidated financial statements is not expected to be material.

[0001193125-17-055058:mdna:127]
In February 2016, the FASB issued ASU 2016-02, Leases (Topic 842). The objective of this update is to increase transparency and comparability among
organizations by recognizing lease assets and lease liabilities on the balance sheet and disclosing key information about leasing arrangements. This ASU is effective for fiscal years beginning after December 15, 2018, including interim periods
within those annual periods and is to be applied utilizing a modified retrospective approach. We are currently evaluating the new guidance to determine the impact it may have on our consolidated financial statements and related disclosures.

[0001193125-17-055058:mdna:128]
In April 2015, the FASB issued ASU 2015-03, Imputation of Interest, as amended,
which requires an entity to record debt issuance costs related to debt reported in the balance sheet as a direct deduction from the face amount of that debt. The update is effective for annual periods ending after December 15, 2015. The
standard requires the use of the retrospective transition method. We adopted the new standard in the first quarter of 2016. Accordingly, as of January 2, 2017, approximately $4.7 million of unamortized debt issuance costs were presented as
a reduction of long-term debt on our consolidated balance sheets. Furthermore, we reclassified approximately $31.2 million of unamortized debt issuance costs that had been presented as other non-current
assets as of December 28, 2015 as a reduction of long-term debt.

[0001193125-17-055058:mdna:129]
In May 2014, the FASB issued ASU 2014-09, Revenue from Contracts with Customers, as amended, which requires an entity to recognize the amount of revenue to which it expects to be entitled for the transfer of promised goods or services to
customers. The ASU will replace most existing revenue recognition guidance in U.S. GAAP when it becomes effective. The new standard is effective at the beginning of fiscal year 2018, however application of the standard is allowed as early as the
beginning of fiscal 2017. The standard permits the use of either the retrospective or cumulative effect transition method. We have assessed that the impact of the new guidance will result in a change to the timing of revenue recognition for our
revenue stream from “point in time” upon physical delivery to an “over time” model and believe this transition could have a material impact on our consolidated financial statements upon adoption. As of January 2, 2017,
management intends to apply the cumulative effect transition method. We have identified and are in the process of implementing changes to our systems, processes and internal controls to meet the standard update’s reporting and disclosure
requirements.
