# TTMI note change history — 0001193125-16-671832 → 0001193125-16-758846


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2016-11-03):
[0001193125-16-758846:note_history:1]
The
 Company is subject to various legal matters, which it considers
 normal for its business activities. While the Company currently
 believes that the amount of any reasonably possible loss for known
 matters would not be material to the Company’s financial
 condition, the outcome of these actions is inherently difficult to
 predict. In the event of an adverse outcome, the ultimate potential
 loss could have a material adverse effect on the Company’s
 financial condition or results of operations in a particular
 period. The Company has accrued amounts for its loss contingencies
 which are probable and estimable as of September 26, 2016 and
 December 28, 2015. However, these amounts are not material to
 the consolidated condensed financial statements of the
 Company.
  (was, 2016-08-04, similarity 0.9914):
[0001193125-16-671832:note_history:1]
The
 Company is subject to various legal matters, which it considers
 normal for its business activities. While the Company currently
 believes that the amount of any reasonably possible loss for known
 matters would not be material to the Company’s financial
 condition, the outcome of these actions is inherently difficult to
 predict. In the event of an adverse outcome, the ultimate potential
 loss could have a material adverse effect on the Company’s
 financial condition or results of operations in a particular
 period. The Company has accrued amounts for its loss contingencies
 which are probable and estimable as of June 27, 2016 and
 December 28, 2015. However, these amounts are not material to
 the consolidated condensed financial statements of the
 Company.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2016-11-03):
[0001193125-16-758846:note_history:2]
In April 2015, the FASB issued ASU 2015-03, Imputation of
 Interest, as amended, which requires an entity to record debt
 issuance costs related to debt reported in the balance sheet as a
 direct deduction from the face amount of that debt. The update is
 effective for annual periods ending after December 15, 2015.
 The standard requires the use of the retrospective transition
 method. The Company adopted the new standard in the first quarter
 of 2016. Accordingly, as of September 26, 2016, approximately
 $26,314 of unamortized debt issuance costs were presented as a
 reduction of long-term debt on the Company’s consolidated
 condensed balance sheets. Furthermore, the Company reclassified
 approximately $31,171 of unamortized debt issuance costs that had
 been presented as other non-current assets as of December 28,
 2015.
  (was, 2016-08-04, similarity 0.9916):
[0001193125-16-671832:note_history:2]
In
 April 2015, the FASB issued ASU 2015-03, Imputation of
 Interest, as amended, which requires an entity to record debt
 issuance costs related to debt reported in the balance sheet as a
 direct deduction from the face amount of that debt. The update is
 effective for annual periods ending after December 15, 2015.
 The standard requires the use of the retrospective transition
 method. The Company adopted the new standard in the first quarter
 of 2016. Accordingly, as of June 27, 2016, approximately $27,558 of
 unamortized debt issuance costs were presented as a reduction of
 long-term debt on the Company’s consolidated condensed
 balance sheets. Furthermore, the Company reclassified approximately
 $31,171 of unamortized debt issuance costs that had been presented
 as other non-current assets as of December 28, 2015.

- changed (2016-11-03):
[0001193125-16-758846:note_history:3]
In May 2014, the FASB issued ASU 2014-09, Revenue from
 Contracts with Customers, as amended, which requires an entity
 to recognize the amount of revenue to which it expects to be
 entitled for the transfer of promised goods or services to
 customers. The ASU will replace most existing revenue recognition
 guidance in U.S. GAAP when it becomes effective. The new standard
 is effective for the Company at the beginning of fiscal year 2018,
 however application of the standard is allowed as early as the
 beginning of fiscal 2017. The standard permits the use of either
 the retrospective or cumulative effect transition method and
 management is currently evaluating which transition approach to
 use. The Company has assessed that the impact of the new guidance
 will result in a change to the timing of revenue recognition for a
 portion of the Company’s revenue stream from
 “point in time” upon physical delivery to an
 “over time” model and believes this transition could
 have a material impact on the Company’s consolidated
 financial statements upon adoption.
  (was, 2016-08-04, similarity 0.659):
[0001193125-16-671832:note_history:3]
In May
 2014, the FASB issued ASU 2014-09, Revenue from Contracts with
 Customers, as amended, which requires an entity to recognize
 the amount of revenue to which it expects to be entitled for the
 transfer of promised goods or services to customers. The ASU will
 replace most existing revenue recognition guidance in U.S. GAAP
 when it becomes effective. The new standard is effective for the
 Company at the beginning of fiscal year 2018, however application
 of the standard is allowed as early as the beginning of fiscal
 2017. The standard permits the use of either the retrospective or
 cumulative effect transition method. The Company is evaluating the
 effect that ASU 2014-09 will have on its consolidated financial
 statements and related disclosures. The Company has not yet
 selected a transition method nor has it determined the effect of
 the standard on its ongoing financial reporting.


## ttmi:ScheduleOfComponentsOfInterestExpenseFromConvertibleNotesTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2016-11-03):
[0001193125-16-758846:note_history:4]
The
 components of interest expense resulting from the convertible
 senior notes for the quarters and three quarters ended September
 26, 2016 and September 28, 2015 are as follows:
  (was, 2016-08-04, similarity 0.9136):
[0001193125-16-671832:note_history:4]
The
 components of interest expense resulting from the convertible
 senior notes for the quarters and two quarters ended June 27, 2016
 and June 29, 2015 are as follows:

- changed (2016-11-03):
[0001193125-16-758846:note_history:5]
|  |  | For the Quarter Ended |  |  | For the Three quarters Ended |  |
|  |  | September 26, 2016 |  |  | September 28, 2015 |  |  | September 26, 2016 |  |  | September 28, 2015 |  |
|  |  | (In thousands) |  |
| Contractual coupon interest |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Convertible senior notes due 2020 |  | $ | 1,094 |  |  | $ | 1,094 |  |  | $ | 3,281 |  |  | $ | 3,281 |  |
| Convertible senior notes due 2015 |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 395 |  |
|  |  | $ | 1,094 |  |  | $ | 1,094 |  |  | $ | 3,281 |  |  | $ | 3,676 |  |
| Amortization of debt discount |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Convertible senior notes due 2020 |  | $ | 2,025 |  |  | $ | 1,898 |  |  | $ | 5,977 |  |  | $ | 5,603 |  |
| Convertible senior notes due 2015 |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 554 |  |
|  |  | $ | 2,025 |  |  | $ | 1,898 |  |  | $ | 5,977 |  |  | $ | 6,157 |  |
| Amortization of debt issuance costs |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Convertible senior notes due 2020 |  | $ | 203 |  |  | $ | 190 |  |  | $ | 599 |  |  | $ | 561 |  |
| Convertible senior notes due 2015 |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 56 |  |
|  |  | $ | 203 |  |  | $ | 190 |  |  | $ | 599 |  |  | $ | 617 |  |
  (was, 2016-08-04, similarity 0.8685):
[0001193125-16-671832:note_history:5]
|  |  | For the Quarter Ended |  |  | For the Two Quarters Ended |  |
|  |  | June 27, 2016 |  |  | June 29, 2015 |  |  | June 27, 2016 |  |  | June 29, 2015 |  |
|  |  | (In thousands) |  |
| Contractual coupon interest |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Convertible senior notes due 2020 |  | $ | 1,093 |  |  | $ | 1,094 |  |  | $ | 2,187 |  |  | $ | 2,187 |  |
| Convertible senior notes due 2015 |  |  | — |  |  |  | 131 |  |  |  | — |  |  |  | 395 |  |
|  |  | $ | 1,093 |  |  | $ | 1,225 |  |  | $ | 2,187 |  |  | $ | 2,582 |  |
| Amortization of debt discount |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Convertible senior notes due 2020 |  | $ | 1,992 |  |  | $ | 1,867 |  |  | $ | 3,952 |  |  | $ | 3,705 |  |
| Convertible senior notes due 2015 |  |  | — |  |  |  | 187 |  |  |  | — |  |  |  | 554 |  |
|  |  | $ | 1,992 |  |  | $ | 2,054 |  |  | $ | 3,952 |  |  | $ | 4,259 |  |
| Amortization of debt issuance costs |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Convertible senior notes due 2020 |  | $ | 200 |  |  | $ | 187 |  |  | $ | 396 |  |  | $ | 371 |  |
| Convertible senior notes due 2015 |  |  | — |  |  |  | 19 |  |  |  | — |  |  |  | 56 |  |
|  |  | $ | 200 |  |  | $ | 206 |  |  | $ | 396 |  |  | $ | 427 |  |


## us-gaap:ConvertibleDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2016-11-03):
[0001193125-16-758846:note_history:6]
As of September 26, 2016 and December 28, 2015, the
 following summarizes the equity components of the convertible
 senior notes included in additional paid-in capital:
  (was, 2016-08-04, similarity 0.9639):
[0001193125-16-671832:note_history:6]
As of
 June 27, 2016 and December 28, 2015, the following summarizes
 the equity components of the convertible senior notes included in
 additional paid-in capital:

- changed (2016-11-03):
[0001193125-16-758846:note_history:7]
|  |  | As of September 26, 2016 and December 28, 2015 |  |
|  |  | Embedded conversion option — Convertible Senior Notes |  |  | Embedded conversion option — Convertible Senior Notes Issuance Costs |  |  | Total |  |
|  |  | (in thousands) |  |
| Convertible senior notes due 2020 |  | $ | 60,227 |  |  | $ | (1,916 | ) |  | $ | 58,311 |  |
  (was, 2016-08-04, similarity 0.6712):
[0001193125-16-671832:note_history:7]
|  |  | As of June 27, 2016 and December 28, 2015 |  |
|  |  | Embedded conversion option — Convertible Senior Notes |  |  | Embedded conversion option — Convertible Senior Notes Issuance Costs |  |  | Total |  |
|  |  | (in thousands) |  |
| Convertible senior notes due 2020 |  | $ | 60,227 |  |  | $ | (1,916 | ) |  | $ | 58,311 |  |


## us-gaap:LongTermDebtTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2016-11-03):
[0001193125-16-758846:note_history:8]
The following table summarizes the long-term debt of the
 Company as of September 26, 2016 and December 28,
 2015:
  (was, 2016-08-04, similarity 0.9447):
[0001193125-16-671832:note_history:8]
The following table summarizes the long-term debt of the
 Company as of June 27, 2016 and December 28, 2015:

- changed (2016-11-03):
[0001193125-16-758846:note_history:9]
|  |  | Average Effective Interest Rate as of September 26, 2016 |  |  | September 26, 2016 |  |  | Average Effective Interest Rate as of December 28, 2015 |  |  | December 28, 2015 |  |
|  |  | (In thousands) |  |
| Term loan due May 2021 |  |  | 6.00% |  |  | $ | 841,143 |  |  |  | 6.00% |  |  | $ | 947,625 |  |
| U.S. ABL revolving loan due May 2020 |  |  | 2.27% |  |  |  | 80,000 |  |  |  | 2.17% |  |  |  | 80,000 |  |
| Convertible senior notes due December 2020 |  |  | 1.75% |  |  |  | 250,000 |  |  |  | 1.75% |  |  |  | 250,000 |  |
| Capital lease |  |  | 6.43% |  |  |  | 1,875 |  |  |  |  |  |  |  | — |  |
|  |  |  |  |  |  |  | 1,173,018 |  |  |  |  |  |  |  | 1,277,625 |  |
| Less: Long-term debt unamortized discount |  |  |  |  |  |  | (64,854 | ) |  |  |  |  |  |  | (75,668 | ) |
| Long-term debt unamortized debt issuance costs |  |  |  |  |  |  | (26,314 | ) |  |  |  |  |  |  | (31,171 | ) |
|  |  |  |  |  |  |  | 1,081,850 |  |  |  |  |  |  |  | 1,170,786 |  |
| Less: current maturities |  |  |  |  |  |  | (146,473 | ) |  |  |  |  |  |  | (157,375 | ) |
| Long-term debt, less current maturities |  |  |  |  |  | $ | 935,377 |  |  |  |  |  |  | $ | 1,013,411 |  |
  (was, 2016-08-04, similarity 0.9729):
[0001193125-16-671832:note_history:9]
|  |  | Average Effective Interest Rate as of June 27, 2016 |  |  | June 27, 2016 |  |  | Average Effective Interest Rate as of December 28, 2015 |  |  | December 28, 2015 |  |
|  |  | (In thousands) |  |
| Term loan due May 2021 |  |  | 6.00% |  |  | $ | 841,143 |  |  |  | 6.00% |  |  | $ | 947,625 |  |
| U.S. ABL revolving loan due May 2020 |  |  | 2.21% |  |  |  | 80,000 |  |  |  | 2.17% |  |  |  | 80,000 |  |
| Convertible senior notes due December 2020 |  |  | 1.75% |  |  |  | 250,000 |  |  |  | 1.75% |  |  |  | 250,000 |  |
| Capital lease |  |  | 6.43% |  |  |  | 2,042 |  |  |  |  |  |  |  | — |  |
|  |  |  |  |  |  |  | 1,173,185 |  |  |  |  |  |  |  | 1,277,625 |  |
| Less: Long-term debt unamortized discount |  |  |  |  |  |  | (68,062 | ) |  |  |  |  |  |  | (75,668 | ) |
| Long-term debt unamortized debt issuance costs |  |  |  |  |  |  | (27,558 | ) |  |  |  |  |  |  | (31,171 | ) |
|  |  |  |  |  |  |  | 1,077,565 |  |  |  |  |  |  |  | 1,170,786 |  |
| Less: current maturities |  |  |  |  |  |  | (80,358 | ) |  |  |  |  |  |  | (157,375 | ) |
| Long-term debt, less current maturities |  |  |  |  |  | $ | 997,207 |  |  |  |  |  |  | $ | 1,013,411 |  |

- changed (2016-11-03):
[0001193125-16-758846:note_history:10]
The Term Loan was issued at a discount at 96.5% and bears
 interest at a floating rate of LIBOR, with a 1.0% LIBOR floor, plus
 an applicable interest margin of 5.0%, or JP Morgan Chase
 Bank’s prime rate, with a 2% floor, plus a margin of 4%, at
 the Company’s option. At September 26, 2016, the weighted
 average interest rate on the outstanding borrowings under the Term
 Loan was 6.0%. There is no provision, other than an event of
 default, for the interest margin to increase. The Term Loan will
 mature on May 31, 2021. The Term Loan is secured by a
 significant amount of the assets of the Company and its domestic
 subsidiaries and a pledge of 65% of voting stock of the
 Company’s first tier foreign subsidiaries and is structurally
 senior to the Company’s convertible senior notes. See
 Convertible Senior Notes below.
  (was, 2016-08-04, similarity 0.9918):
[0001193125-16-671832:note_history:10]
The Term Loan was issued at a discount at 96.5% and bears
 interest at a floating rate of LIBOR, with a 1.0% LIBOR floor, plus
 an applicable interest margin of 5.0%, or JP Morgan Chase
 Bank’s prime rate, with a 2% floor, plus a margin of 4%, at
 the Company’s option. At June 27, 2016, the weighted average
 interest rate on the outstanding borrowings under the Term Loan was
 6.0%. There is no provision, other than an event of default, for
 the interest margin to increase. The Term Loan will mature on
 May 31, 2021. The Term Loan is secured by a significant amount
 of the assets of the Company and its domestic subsidiaries and a
 pledge of 65% of voting stock of the Company’s first tier
 foreign subsidiaries and is structurally senior to the
 Company’s convertible senior notes. See Convertible Senior
 Notes below.

- changed (2016-11-03):
[0001193125-16-758846:note_history:11]
The U.S. ABL consists of three tranches comprised of a
 revolving credit facility of up to $150,000, a letter of credit
 facility of up to $75,000, and swingline loans of up to $30,000,
 provided that at no time may amounts outstanding under the tranches
 exceed in aggregate $150,000 or the applicable borrowing base,
 which is a percentage of the principal amount of Eligible Accounts,
 as defined in the U.S. ABL agreement. Borrowings under the U.S. ABL
 bear interest at either a floating rate of LIBOR plus a margin of
 175 basis points or JP Morgan Chase Bank’s prime rate plus a
 margin of 75 basis points, at the Company’s option. At
 September 26, 2016, the weighted average interest rate on the
 outstanding borrowings under the U.S. ABL was 2.27%. The applicable
 margin can vary based on the remaining availability of the
 facility, from 150 to 200 basis points for LIBOR-based loans or
 from 50 to 100 basis points for JP Morgan Chase Bank’s prime
 rate-based loans. Other than availability and an event of default,
 there are no other provisions for the interest margin to increase.
 The U.S. ABL will mature on May 31, 2020. Loans made under the
 U.S. ABL are secured first by all of the Company’s domestic
 cash, receivables and inventories as well as by a second position
 against a significant amount of the assets of the Company and its
 domestic subsidiaries and a pledge of 65% of voting stock of the
 Company’s first tier foreign subsidiaries and are
 structurally senior to the Company’s convertible senior
 notes. See Convertible Senior Notes below. At September 26, 2016,
 $80,000 of the U.S. ABL was outstanding and classified as
 short-term debt.
  (was, 2016-08-04, similarity 0.9918):
[0001193125-16-671832:note_history:11]
The U.S. ABL consists of three tranches comprised of a
 revolving credit facility of up to $150,000, a letter of credit
 facility of up to $75,000, and swingline loans of up to $30,000,
 provided that at no time may amounts outstanding under the tranches
 exceed in aggregate $150,000 or the applicable borrowing base,
 which is a percentage of the principal amount of Eligible Accounts,
 as defined in the U.S. ABL agreement. Borrowings under the U.S. ABL
 bear interest at either a floating rate of LIBOR plus a margin of
 175 basis points or JP Morgan Chase Bank’s prime rate plus a
 margin of 75 basis points, at the Company’s option. At June
 27, 2016, the weighted average interest rate on the outstanding
 borrowings under the U.S. ABL was 2.21%. The applicable margin can
 vary based on the remaining availability of the facility, from 150
 to 200 basis points for LIBOR-based loans or from 50 to 100 basis
 points for JP Morgan Chase Bank’s prime rate-based loans.
 Other than availability and an event of default, there are no other
 provisions for the interest margin to increase. The U.S. ABL will
 mature on May 31, 2020. Loans made under the U.S. ABL are
 secured first by all of the Company’s domestic cash,
 receivables and inventories as well as by a second position against
 a significant amount of the assets of the Company and its domestic
 subsidiaries and a pledge of 65% of voting stock of the
 Company’s first tier foreign subsidiaries and are
 structurally senior to the Company’s convertible senior
 notes. See Convertible Senior Notes below. At June 27, 2016,
 $80,000 of the U.S. ABL was outstanding and classified as
 short-term debt.

- changed (2016-11-03):
[0001193125-16-758846:note_history:12]
The Asia ABL consists of two tranches comprised of a revolving
 credit facility of up to $150,000 and a letter of credit facility
 of up to $100,000, provided that at no time may amounts outstanding
 under both tranches exceed in aggregate $150,000 or the applicable
 borrowing base, which is a percentage of the principal amount of
 Eligible Accounts, as defined in the Asia ABL agreement. Borrowings
 under the Asia ABL bear interest at a floating rate of LIBOR plus
 175 basis points. There is no provision, other than an event of
 default, for the interest margin to increase. The Asia ABL will
 mature on May 22, 2020. Loans made under the Asia ABL are
 secured by a portion of cash and receivables of certain of the
 Companies subsidiaries in Asia and are structurally senior to the
 Company’s domestic obligations, including the convertible
 senior notes. See Convertible Senior Notes below. Additionally,
 certain of the Company’s subsidiaries in Asia have fully and
 unconditionally guaranteed the full and timely payment of all Asia
 ABL related obligations. At September 26, 2016, none of the Asia
 ABL was outstanding.
  (was, 2016-08-04, similarity 0.994):
[0001193125-16-671832:note_history:12]
The Asia ABL consists of two tranches comprised of a revolving
 credit facility of up to $150,000 and a letter of credit facility
 of up to $100,000, provided that at no time may amounts outstanding
 under both tranches exceed in aggregate $150,000 or the applicable
 borrowing base, which is a percentage of the principal amount of
 Eligible Accounts, as defined in the Asia ABL agreement. Borrowings
 under the Asia ABL bear interest at a floating rate of LIBOR plus
 175 basis points. There is no provision, other than an event of
 default, for the interest margin to increase. The Asia ABL will
 mature on May 22, 2020. Loans made under the Asia ABL are
 secured by a portion of cash and receivables of certain of the
 Companies subsidiaries in Asia and are structurally senior to the
 Company’s domestic obligations, including the convertible
 senior notes. See Convertible Senior Notes below. Additionally,
 certain of the Company’s subsidiaries in Asia have fully and
 unconditionally guaranteed the full and timely payment of all Asia
 ABL related obligations. At June 27, 2016, none of the Asia ABL was
 outstanding.

- changed (2016-11-03):
[0001193125-16-758846:note_history:13]
The Company is required to make scheduled payments of the
 outstanding Term Loan balance on a quarterly basis. Based on
 certain parameters defined in the Term Loan agreement, the Company
 may be required to make an additional principal payment on an
 annual basis. Any additional annual payments or prepayments reduce
 future required quarterly scheduled payments. During the three
 quarters ended September 26, 2016, the Company made debt principal
 payments totaling $106,482, representing normally scheduled
 principal payments as well as additional prepayments of principal.
 Any other outstanding balances under the Term Loan are due at the
 maturity date of May 31, 2021. Borrowings under the Term Loan
 are subject to various financial and operating covenants including
 maintaining a maximum total leverage ratio. Under the occurrence of
 certain events, the U.S. ABL and the Asia ABL are subject to
 various financial and operational covenants, including maintaining
 minimum fixed charge coverage ratios. At September 26, 2016, the
 Company was in compliance with the covenants under the Term Loan,
 the U.S. ABL and the Asia ABL.
  (was, 2016-08-04, similarity 0.9546):
[0001193125-16-671832:note_history:13]
The Company is required to make scheduled payments of the
 outstanding Term Loan balance on a quarterly basis. Based on
 certain parameters defined in the Term Loan agreement, the Company
 may be required to make an additional principal payment on an
 annual basis. Any additional annual payments reduce future required
 quarterly scheduled payments. During the quarter and two quarters
 ended June 27, 2016, the Company made debt principal payments
 totaling $30,000 and $106,482, respectively, representing normally
 scheduled principal payments as well as additional prepayments of
 principal. Any other outstanding balances under the Term Loan are
 due at the maturity date of May 31, 2021. Borrowings under the
 Term Loan are subject to various financial and operating covenants
 including maintaining a maximum total leverage ratio. Under the
 occurrence of certain events, the U.S. ABL and the Asia ABL are
 subject to various financial and operational covenants, including
 maintaining minimum fixed charge coverage ratios. At June 27, 2016,
 the Company was in compliance with the covenants under the Term
 Loan, the U.S. ABL and the Asia ABL.

- changed (2016-11-03):
[0001193125-16-758846:note_history:14]
As of September 26, 2016 and December 28, 2015, remaining
 unamortized debt discount of $25,405 and $30,242, respectively, and
 debt issuance costs of $22,361 and $26,619, respectively, related
 to the Term Loan. These debt discount and debt issuance costs are
 recorded as a reduction of the Term Loan and are amortized over the
 duration of the Term Loan into interest expense using an effective
 interest rate of 7.50%.
  (was, 2016-08-04, similarity 0.9828):
[0001193125-16-671832:note_history:14]
As of June 27, 2016 and December 28, 2015, remaining
 unamortized debt discount of $26,588 and $30,242, respectively, and
 debt issuance costs of $23,402 and $26,619, respectively, related
 to the Term Loan. These debt discount and debt issuance costs are
 recorded as a reduction of the Term Loan and are amortized over the
 duration of the Term Loan into interest expense using an effective
 interest rate of 7.50%.

- changed (2016-11-03):
[0001193125-16-758846:note_history:15]
Additionally, remaining unamortized debt issuance costs related
 to the ABL Revolving Loans were $3,573 and $4,303 as of September
 26, 2016 and December 28, 2015, respectively. These debt issuance
 costs are included in other non-current assets and are amortized to
 interest expense over the duration of the ABL Revolving Loans using
 the straight line method of amortization.
  (was, 2016-08-04, similarity 0.9815):
[0001193125-16-671832:note_history:15]
Additionally, remaining unamortized debt issuance costs related
 to the ABL Revolving Loans were $3,816 and $4,303 as of June 27,
 2016 and December 28, 2015, respectively. These debt issuance costs
 are included in other non-current assets and are amortized to
 interest expense over the duration of the ABL Revolving Loans using
 the straight line method of amortization.

- changed (2016-11-03):
[0001193125-16-758846:note_history:16]
At September 26, 2016, the remaining amortization period for
 the unamortized debt discount and debt issuance costs for both the
 Term Loan and the ABL Revolving Loans was 4.6 years.
  (was, 2016-08-04, similarity 0.9676):
[0001193125-16-671832:note_history:16]
At June 27, 2016, the remaining amortization period for the
 unamortized debt discount and debt issuance costs for both the Term
 Loan and the ABL Revolving Loans was 4.9 years.

- changed (2016-11-03):
[0001193125-16-758846:note_history:17]
The Company is required to pay a commitment fee of 0.25% to
 0.375% per annum on any unused portion of the U.S. ABL or Asia
 ABL based on utilization levels. Additionally, the Company also
 paid commitment fees of 0.5% per annum on the unused portion
 of the $90,000 senior secured revolving loan associated with the
 terminated 2012 credit agreement for the three quarters ended
 September 28, 2015. The Company incurred total commitment fees
 related to unused borrowing availability of $171 and $200 for the
 quarters ended September 26, 2016 and September 28, 2015,
 respectively, and $516 and $565 for the three quarters ended
 September 26, 2016 and September 28, 2015, respectively. As of
 September 26, 2016, the outstanding amount of the Term Loan was
 $841,143, of which $66,143 is included as short-term debt and the
 remaining $775,000 is included as long-term debt. Additionally,
 $80,000 of the U.S. ABL and none of the Asia ABL was outstanding as
 of September 26, 2016. Available borrowing capacity under the U.S.
 ABL and Asia ABL was $63,003 and $142,904, which includes letters
 of credit outstanding of $6,997 and $7,096 mentioned below,
 respectively, at September 26, 2016.
  (was, 2016-08-04, similarity 0.8693):
[0001193125-16-671832:note_history:17]
The Company is required to pay a commitment fee of 0.25% to
 0.375% per annum on any unused portion of the U.S. ABL or Asia
 ABL based on utilization levels. Additionally, the Company also
 paid commitment fees of 0.5% per annum on the unused portion
 of the $90,000 senior secured revolving loan associated with the
 terminated 2012 credit agreement for the quarter and two quarters
 ended June 29, 2015. The Company incurred total commitment fees
 related to unused borrowing availability of $150 and $193 for the
 quarters ended June 27, 2016 and June 29, 2015, respectively, and
 $344 and $366 for the two quarters ended June 27, 2016 and June 29,
 2015, respectively. As of June 27, 2016, the outstanding amount of
 the Term Loan was $841,143, all of which is included as long-term
 debt. Additionally, $80,000 of the U.S. ABL and none of the Asia
 ABL was outstanding as of June 27, 2016. Available borrowing
 capacity under the U.S. ABL and Asia ABL was $63,003 and $137,778,
 which includes letters of credit outstanding of $6,997 and $12,222
 mentioned below, respectively, at June 27, 2016.

- added (2016-11-03):
[0001193125-16-758846:note_history:18]
Subsequent to September 26, 2016, the Company issued a new
 $775,000 Term Loan (New Term Loan) at an interest rate of LIBOR
 plus 4.25%, a reduction of 75 basis points from its previous Term
 Loan, and repaid in full the $841,143 of the previously issued Term
 Loan outstanding, which resulted in an overall net reduction of
 $66,143 in the Term Loan outstanding. Principal payments under
 the New Term Loan are due quarterly beginning in April 2020 with
 the balance due on May 31, 2021, the same maturity as the previous
 Term Loan. In addition, the Company amended its U.S. ABL
 credit facility to increase the amount available under the U.S. ABL
 to $200,000, reduce the applicable margin by 0.25% for both
 Eurodollar loans and ABR loans, and reduce the Letters of Credit
 Facilities to $50,000.

- changed (2016-11-03):
[0001193125-16-758846:note_history:19]
The Company has up to $75,000 and $100,000 Letters of Credit
 Facilities under the U.S. ABL and the Asia ABL, respectively, as
 mentioned above. As of September 26, 2016, letters of credit in the
 amount of $6,997 were outstanding under the U.S. ABL and $7,096
 were outstanding under the Asia ABL with various expiration dates
 through September 2017.
  (was, 2016-08-04, similarity 0.9521):
[0001193125-16-671832:note_history:19]
The Company has up to $75,000 and $100,000 Letters of Credit
 Facilities under the U.S. ABL and the Asia ABL, respectively, as
 mentioned above. As of June 27, 2016, letters of credit in the
 amount of $6,997 were outstanding under the U.S. ABL and $12,222
 were outstanding under the Asia ABL with various expiration dates
 through July 2017.

- changed (2016-11-03):
[0001193125-16-758846:note_history:20]
At December 28, 2015, certain letters of credit were
 securitized by cash collateral. As such the Company had recorded
 such cash as restricted cash on the consolidated condensed balance
 sheet as of December 28, 2015. As of September 26, 2016, none of
 the letters of credit were securitized by cash
 collateral.
  (was, 2016-08-04, similarity 0.9774):
[0001193125-16-671832:note_history:20]
At December 28, 2015, certain letters of credit were
 securitized by cash collateral. As such the Company had recorded
 such cash as restricted cash on the consolidated condensed balance
 sheet as of December 28, 2015. As of June 27, 2016, none of the
 letters of credit were securitized by cash collateral.

- changed (2016-11-03):
[0001193125-16-758846:note_history:21]
As of September 26, 2016 and December 28, 2015, the
 following summarizes the equity components of the convertible
 senior notes included in additional paid-in capital:
  (was, 2016-08-04, similarity 0.9639):
[0001193125-16-671832:note_history:21]
As of June 27, 2016 and December 28, 2015, the following
 summarizes the equity components of the convertible senior notes
 included in additional paid-in capital:

- changed (2016-11-03):
[0001193125-16-758846:note_history:22]
|  |  | As of September 26, 2016 and December 28, 2015 |  |
|  |  | Embedded conversion option — Convertible Senior Notes |  |  | Embedded conversion option — Convertible Senior Notes Issuance Costs |  |  | Total |  |
|  |  | (in thousands) |  |
| Convertible senior notes due 2020 |  | $ | 60,227 |  |  | $ | (1,916 | ) |  | $ | 58,311 |  |
  (was, 2016-08-04, similarity 0.6712):
[0001193125-16-671832:note_history:22]
|  |  | As of June 27, 2016 and December 28, 2015 |  |
|  |  | Embedded conversion option — Convertible Senior Notes |  |  | Embedded conversion option — Convertible Senior Notes Issuance Costs |  |  | Total |  |
|  |  | (in thousands) |  |
| Convertible senior notes due 2020 |  | $ | 60,227 |  |  | $ | (1,916 | ) |  | $ | 58,311 |  |

- changed (2016-11-03):
[0001193125-16-758846:note_history:23]
The components of interest expense resulting from the
 convertible senior notes for the quarters and three quarters ended
 September 26, 2016 and September 28, 2015 are as
 follows:
  (was, 2016-08-04, similarity 0.9136):
[0001193125-16-671832:note_history:23]
The components of interest expense resulting from the
 convertible senior notes for the quarters and two quarters ended
 June 27, 2016 and June 29, 2015 are as follows:

- changed (2016-11-03):
[0001193125-16-758846:note_history:24]
|  |  | For the Quarter Ended |  |  | For the Three quarters Ended |  |
|  |  | September 26, 2016 |  |  | September 28, 2015 |  |  | September 26, 2016 |  |  | September 28, 2015 |  |
|  |  | (In thousands) |  |
| Contractual coupon interest |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Convertible senior notes due 2020 |  | $ | 1,094 |  |  | $ | 1,094 |  |  | $ | 3,281 |  |  | $ | 3,281 |  |
| Convertible senior notes due 2015 |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 395 |  |
|  |  | $ | 1,094 |  |  | $ | 1,094 |  |  | $ | 3,281 |  |  | $ | 3,676 |  |
| Amortization of debt discount |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Convertible senior notes due 2020 |  | $ | 2,025 |  |  | $ | 1,898 |  |  | $ | 5,977 |  |  | $ | 5,603 |  |
| Convertible senior notes due 2015 |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 554 |  |
|  |  | $ | 2,025 |  |  | $ | 1,898 |  |  | $ | 5,977 |  |  | $ | 6,157 |  |
| Amortization of debt issuance costs |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Convertible senior notes due 2020 |  | $ | 203 |  |  | $ | 190 |  |  | $ | 599 |  |  | $ | 561 |  |
| Convertible senior notes due 2015 |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 56 |  |
|  |  | $ | 203 |  |  | $ | 190 |  |  | $ | 599 |  |  | $ | 617 |  |
  (was, 2016-08-04, similarity 0.8685):
[0001193125-16-671832:note_history:24]
|  |  | For the Quarter Ended |  |  | For the Two Quarters Ended |  |
|  |  | June 27, 2016 |  |  | June 29, 2015 |  |  | June 27, 2016 |  |  | June 29, 2015 |  |
|  |  | (In thousands) |  |
| Contractual coupon interest |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Convertible senior notes due 2020 |  | $ | 1,093 |  |  | $ | 1,094 |  |  | $ | 2,187 |  |  | $ | 2,187 |  |
| Convertible senior notes due 2015 |  |  | — |  |  |  | 131 |  |  |  | — |  |  |  | 395 |  |
|  |  | $ | 1,093 |  |  | $ | 1,225 |  |  | $ | 2,187 |  |  | $ | 2,582 |  |
| Amortization of debt discount |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Convertible senior notes due 2020 |  | $ | 1,992 |  |  | $ | 1,867 |  |  | $ | 3,952 |  |  | $ | 3,705 |  |
| Convertible senior notes due 2015 |  |  | — |  |  |  | 187 |  |  |  | — |  |  |  | 554 |  |
|  |  | $ | 1,992 |  |  | $ | 2,054 |  |  | $ | 3,952 |  |  | $ | 4,259 |  |
| Amortization of debt issuance costs |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Convertible senior notes due 2020 |  | $ | 200 |  |  | $ | 187 |  |  | $ | 396 |  |  | $ | 371 |  |
| Convertible senior notes due 2015 |  |  | — |  |  |  | 19 |  |  |  | — |  |  |  | 56 |  |
|  |  | $ | 200 |  |  | $ | 206 |  |  | $ | 396 |  |  | $ | 427 |  |

- changed (2016-11-03):
[0001193125-16-758846:note_history:25]
As of September 26, 2016 and December 28, 2015, remaining
 unamortized debt discount of $39,449 and $45,426, respectively, and
 debt issuance costs of $3,953 and $4,552, respectively, related to
 the convertible senior notes. These debt discount and debt issuance
 costs are recorded as a reduction of the convertible senior notes
 and are being amortized to interest expense over the term of the
 convertible senior notes using the effective interest rate method.
 At September 26, 2016, the remaining weighted average amortization
 period for the unamortized senior convertible note discount and
 debt issuance costs was 4.2 years.
  (was, 2016-08-04, similarity 0.7517):
[0001193125-16-671832:note_history:25]
As of June 27, 2016 and December 28, 2015, remaining
 unamortized debt discount of $41,474 and $45,426, respectively, and
 debt issuance costs of $4,156 and $4,552, respectively, related to
 the convertible senior notes. These debt discount and debt issuance
 costs are recorded as a reduction of the convertible senior notes
 and are being amortized to interest expense over the term of the
 convertible senior notes using the effective interest rate method.
 At June 27, 2016, the remaining weighted average amortization
 period for the unamortized senior convertible note discount and
 debt issuance costs was 4.5 years.

- changed (2016-11-03):
[0001193125-16-758846:note_history:26]
For the quarter and three quarters ended September 26, 2016 and
 September 28, 2015, the amortization of the convertible senior
 notes due 2020 debt discount and debt issuance costs was based on
 an effective interest rate of 6.48%. For the three quarters ended
 September 28, 2015, the amortization of the convertible senior
 notes due 2015 debt discount and debt issuance costs was based on
 an effective interest rate of 8.37%.
  (was, 2016-08-04, similarity 0.8546):
[0001193125-16-671832:note_history:26]
For the quarters and two quarters ended June 27, 2016 and June
 29, 2015, the amortization of the convertible senior notes due 2020
 debt discount and debt issuance costs was based on an effective
 interest rate of 6.48%. For the quarter and two quarters ended June
 29, 2015, the amortization of the convertible senior notes due 2015
 debt discount and debt issuance costs was based on an effective
 interest rate of 8.37%.

- changed (2016-11-03):
[0001193125-16-758846:note_history:27]
Additionally, the Company is party to a revolving loan credit
 facility (Chinese Revolver) with a lender in China. Under this
 arrangement, the lender has made available to the Company
 approximately $34,500 in unsecured borrowing with all terms of the
 borrowing to be negotiated at the time the Chinese Revolver is
 drawn upon. There are no commitment fees on the unused portion of
 the Chinese Revolver, and this arrangement expires in December
 2016. As of September 26, 2016, the Chinese Revolver had not been
 drawn upon.
  (was, 2016-08-04, similarity 0.987):
[0001193125-16-671832:note_history:27]
Additionally, the Company is party to a revolving loan credit
 facility (Chinese Revolver) with a lender in China. Under this
 arrangement, the lender has made available to the Company
 approximately $34,800 in unsecured borrowing with all terms of the
 borrowing to be negotiated at the time the Chinese Revolver is
 drawn upon. There are no commitment fees on the unused portion of
 the Chinese Revolver, and this arrangement expires in December
 2016. As of June 27, 2016, the Chinese Revolver had not been drawn
 upon.

- changed (2016-11-03):
[0001193125-16-758846:note_history:28]
The Company became a party to its current Term Loan and ABL
 Revolving Loans during the second quarter of 2015 in order to
 refinance and pay in full the remaining outstanding amount of
 $225,700 under an existing 2012 credit agreement, as well as to
 finance the acquisition of Viasystems and refinance
 Viasystems’ outstanding debt. As a result, the Company
 recognized losses of approximately $802 for the three quarters
 ended September 28, 2015 resulting from the write off of the
 remaining unamortized debt issuance costs associated with the
 terminated 2012 credit agreement.
  (was, 2016-08-04, similarity 0.7775):
[0001193125-16-671832:note_history:28]
The Company became a party to its current Term Loan and ABL
 Revolving Loans during the second quarter ended June 29, 2015
 in order to refinance and pay in full the remaining outstanding
 amount of $225,700 under an existing 2012 credit agreement, as well
 as to finance the acquisition of Viasystems and refinance
 Viasystems’ outstanding debt. As a result, the Company
 recognized losses of approximately $802 for the quarter and two
 quarters ended June 29, 2015 resulting from the write off of
 the remaining unamortized debt issuance costs associated with the
 terminated 2012 credit agreement.

- removed (2016-11-03):
[0001193125-16-671832:note_history:29]
The fiscal calendar maturities of long-term debt through 2020
 and thereafter are as follows:

- removed (2016-11-03):
[0001193125-16-671832:note_history:30]
|  |  | (In thousands) |  |
| Remaining 2016 |  | $ | 80,358 |  |
| 2017 |  |  | 377 |  |
| 2018 |  |  | 401 |  |
| 2019 |  |  | 45,945 |  |
| 2020 |  |  | 297,979 |  |
| Thereafter |  |  | 748,125 |  |
|  |  | $ | 1,173,185 |  |

- removed (2016-11-03):
[0001193125-16-671832:note_history:31]
Convertible Senior
 Notes


## us-gaap:ScheduleOfDebtInstrumentsTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2016-11-03):
[0001193125-16-758846:note_history:32]
The following table summarizes the long-term debt of the
 Company as of September 26, 2016 and December 28,
 2015:
  (was, 2016-08-04, similarity 0.9447):
[0001193125-16-671832:note_history:32]
The following table summarizes the long-term debt of the
 Company as of June 27, 2016 and December 28, 2015:

- changed (2016-11-03):
[0001193125-16-758846:note_history:33]
|  |  | Average Effective Interest Rate as of September 26, 2016 |  |  | September 26, 2016 |  |  | Average Effective Interest Rate as of December 28, 2015 |  |  | December 28, 2015 |  |
|  |  | (In thousands) |  |
| Term loan due May 2021 |  |  | 6.00% |  |  | $ | 841,143 |  |  |  | 6.00% |  |  | $ | 947,625 |  |
| U.S. ABL revolving loan due May 2020 |  |  | 2.27% |  |  |  | 80,000 |  |  |  | 2.17% |  |  |  | 80,000 |  |
| Convertible senior notes due December 2020 |  |  | 1.75% |  |  |  | 250,000 |  |  |  | 1.75% |  |  |  | 250,000 |  |
| Capital lease |  |  | 6.43% |  |  |  | 1,875 |  |  |  |  |  |  |  | — |  |
|  |  |  |  |  |  |  | 1,173,018 |  |  |  |  |  |  |  | 1,277,625 |  |
| Less: Long-term debt unamortized discount |  |  |  |  |  |  | (64,854 | ) |  |  |  |  |  |  | (75,668 | ) |
| Long-term debt unamortized debt issuance costs |  |  |  |  |  |  | (26,314 | ) |  |  |  |  |  |  | (31,171 | ) |
|  |  |  |  |  |  |  | 1,081,850 |  |  |  |  |  |  |  | 1,170,786 |  |
| Less: current maturities |  |  |  |  |  |  | (146,473 | ) |  |  |  |  |  |  | (157,375 | ) |
| Long-term debt, less current maturities |  |  |  |  |  | $ | 935,377 |  |  |  |  |  |  | $ | 1,013,411 |  |
  (was, 2016-08-04, similarity 0.9729):
[0001193125-16-671832:note_history:33]
|  |  | Average Effective Interest Rate as of June 27, 2016 |  |  | June 27, 2016 |  |  | Average Effective Interest Rate as of December 28, 2015 |  |  | December 28, 2015 |  |
|  |  | (In thousands) |  |
| Term loan due May 2021 |  |  | 6.00% |  |  | $ | 841,143 |  |  |  | 6.00% |  |  | $ | 947,625 |  |
| U.S. ABL revolving loan due May 2020 |  |  | 2.21% |  |  |  | 80,000 |  |  |  | 2.17% |  |  |  | 80,000 |  |
| Convertible senior notes due December 2020 |  |  | 1.75% |  |  |  | 250,000 |  |  |  | 1.75% |  |  |  | 250,000 |  |
| Capital lease |  |  | 6.43% |  |  |  | 2,042 |  |  |  |  |  |  |  | — |  |
|  |  |  |  |  |  |  | 1,173,185 |  |  |  |  |  |  |  | 1,277,625 |  |
| Less: Long-term debt unamortized discount |  |  |  |  |  |  | (68,062 | ) |  |  |  |  |  |  | (75,668 | ) |
| Long-term debt unamortized debt issuance costs |  |  |  |  |  |  | (27,558 | ) |  |  |  |  |  |  | (31,171 | ) |
|  |  |  |  |  |  |  | 1,077,565 |  |  |  |  |  |  |  | 1,170,786 |  |
| Less: current maturities |  |  |  |  |  |  | (80,358 | ) |  |  |  |  |  |  | (157,375 | ) |
| Long-term debt, less current maturities |  |  |  |  |  | $ | 997,207 |  |  |  |  |  |  | $ | 1,013,411 |  |


## us-gaap:ScheduleOfMaturitiesOfLongTermDebtTableTextBlock (debt) — matched_by: no_current_note, score: 0.0

- removed (2016-11-03):
[0001193125-16-671832:note_history:34]
The
 fiscal calendar maturities of long-term debt through 2020 and
 thereafter are as follows:

- removed (2016-11-03):
[0001193125-16-671832:note_history:35]
|  |  | (In thousands) |  |
| Remaining 2016 |  | $ | 80,358 |  |
| 2017 |  |  | 377 |  |
| 2018 |  |  | 401 |  |
| 2019 |  |  | 45,945 |  |
| 2020 |  |  | 297,979 |  |
| Thereafter |  |  | 748,125 |  |
|  |  | $ | 1,173,185 |  |


## us-gaap:RelatedPartyTransactionsDisclosureTextBlock (related_parties) — matched_by: tag_name, score: 1.0

- changed (2016-11-03):
[0001193125-16-758846:note_history:36]
In the
 normal course of business, the Company’s foreign subsidiaries
 purchase laminate and prepreg from related parties in which a
 significant shareholder of the Company holds an equity interest.
 The Company purchased laminate and prepreg from these related
 parties in the amount of $12,292 and $21,167 for the quarters ended
 September 26, 2016 and September 28, 2015, respectively, and
 $42,549 and $43,335 for the three quarters ended September 26, 2016
 and September 28, 2015, respectively.
  (was, 2016-08-04, similarity 0.8929):
[0001193125-16-671832:note_history:36]
In the
 normal course of business, the Company’s foreign subsidiaries
 purchase laminate and prepreg from related parties in which a
 significant shareholder of the Company holds an equity interest.
 The Company purchased laminate and prepreg from these related
 parties in the amount of $14,259 and $12,914 for the quarters ended
 June 27, 2016 and June 29, 2015, respectively, and $30,257 and
 $22,859 for the two quarters ended June 27, 2016 and June 29, 2015,
 respectively.

- added (2016-11-03):
[0001193125-16-758846:note_history:37]
Dongguan Shengyi Electronics Ltd. (SYE) is also a related party
 as it is a wholly owned subsidiary of an entity in which a
 significant shareholder of the Company holds an equity interest.
 The Company sells PCBs to SYE and purchases PCBs including various
 services relating to PCB manufacturing from SYE. Sales to SYE for
 the quarters ended September 26, 2016 and September 28, 2015
 were $254 and $1,042, respectively, and $863 and $3,867 for the
 three quarters ended September 26, 2016 and September 28, 2015,
 respectively. Purchases of PCBs, including various services
 relating to PCB manufacturing, for the quarter ended September 28,
 2015 were $344, and $1,840 for the three quarters ended September
 28, 2015. There were no purchases of PCBs including various
 services relating to PCB manufacturing for the quarter or three
 quarters ended September 26, 2016.

- changed (2016-11-03):
[0001193125-16-758846:note_history:38]
As of
 September 26, 2016 and December 28, 2015, the Company’s
 consolidated condensed balance sheets included $16,952 and
 $29,306, respectively, in accounts payable due to related parties
 for purchases of laminate and prepreg and various PCB manufacturing
 services and such balances are included as a component of accounts
 payable on the consolidated condensed balance sheets. Additionally,
 the Company’s consolidated condensed balance sheets included
 $598 and $1,999, in accounts receivable due from a related party
 for sales of PCBs to SYE, as of September 26, 2016 and December 28,
 2015, respectively, as mentioned above, and such balances are
 included as a component of accounts receivable, net on the
 consolidated condensed balance sheets.
  (was, 2016-08-04, similarity 0.9814):
[0001193125-16-671832:note_history:38]
As of
 June 27, 2016 and December 28, 2015, the Company’s
 consolidated condensed balance sheets included $18,167 and $29,306,
 respectively, in accounts payable due to related parties for
 purchases of laminate and prepreg and various PCB manufacturing
 services and such balances are included as a component of accounts
 payable on the consolidated condensed balance sheets. Additionally,
 the Company’s consolidated condensed balance sheets included
 $476 and $1,999, in accounts receivable due from a related party
 for sales of PCBs to SYE, as of June 27, 2016 and December 28,
 2015, respectively, as mentioned above, and such balances are
 included as a component of accounts receivable, net on the
 consolidated condensed balance sheets.

- removed (2016-11-03):
[0001193125-16-671832:note_history:39]
Dongguan Shengyi Electronics Ltd. (SYE) is also a related party
 as it is a wholly owned subsidiary of an entity in which a
 significant shareholder of the Company holds an equity interest.
 The Company sells PCBs to SYE and purchases PCBs including various
 services relating to PCB manufacturing from SYE. Sales to SYE for
 the quarters ended June 27, 2016 and June 29, 2015 were $298 and
 $1,343, respectively, and $610 and $2,825 for the two quarters
 ended June 27, 2016 and June 29, 2015, respectively. Purchases of
 PCBs, including various services relating to PCB manufacturing, for
 the quarter ended June 29, 2015 were $366, and $805 for the two
 quarters ended June 29, 2015. There were no purchases of PCBs
 including various services relating to PCB manufacturing for the
 quarter or two quarters ended June 27, 2016.
