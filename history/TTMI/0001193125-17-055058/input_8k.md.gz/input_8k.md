# TTMI 8-K — 0001193125-17-034652 filed 2017-02-08

## item codes, every 8-K on or before 2017-02-24

- 2017-02-08 0001193125-17-034652 — 2.02, 9.01
- 2016-11-18 0001193125-16-772305 — 8.01, 9.01
- 2016-10-26 0001193125-16-747948 — 2.02, 9.01
- 2016-10-20 0001193125-16-742905 — 5.02
- 2016-10-05 0001193125-16-731552 — 5.02, 9.01
- 2016-09-27 0001193125-16-720828 — 1.01, 2.03, 7.01, 9.01
- 2016-07-27 0001193125-16-659983 — 2.02, 9.01
- 2016-05-23 0001193125-16-599342 — 7.01, 9.01
- 2016-05-18 0001193125-16-594656 — 5.02, 5.03, 5.07, 9.01
- 2016-04-27 0001171843-16-009432 — 2.02, 9.01
- 2016-03-08 0001193125-16-495457 — 5.03, 7.01, 9.01
- 2016-02-09 0001193125-16-454281 — 8.01, 9.01
- 2016-02-04 0001171843-16-007659 — 2.02, 9.01
- 2016-01-04 0001193125-16-418740 — 1.01, 9.01
- 2015-12-11 0001193125-15-400867 — 5.02, 9.01
- 2015-10-30 0001171843-15-005835 — 2.02, 7.01 — amendment of 0001171843-15-005766
- 2015-10-28 0001171843-15-005766 — 2.02, 9.01
- 2015-09-29 0001193125-15-331517 — 2.02, 2.05, 2.06, 9.01
- 2015-08-05 0001171843-15-004361 — 2.02, 9.01
- 2015-07-31 0001193125-15-272962 — 9.01 — amendment of 0001193125-15-210734
- 2015-06-02 0001193125-15-210734 — 1.01, 1.02, 2.01, 2.03, 7.01, 9.01
- 2015-05-29 0001193125-15-206622 — 1.01, 2.03, 9.01
- 2015-05-20 0001171843-15-002975 — 7.01, 9.01
- 2015-05-19 0001193125-15-193434 — 5.07, 9.01
- 2015-05-05 0001171843-15-002499 — 7.01, 9.01
- 2015-04-29 0001171843-15-002307 — 2.02, 9.01
- 2015-04-21 0001193125-15-139239 — 7.01, 9.01
- 2015-04-21 0001171843-15-002065 — 2.02, 9.01
- 2015-02-04 0001171843-15-000599 — 2.02, 9.01
- 2015-01-20 0001193125-15-014019 — 7.01, 9.01
- 2014-12-30 0001193125-14-457111 — 7.01, 9.01
- 2014-12-15 0001193125-14-442645 — 1.01, 9.01
- 2014-12-04 0001193125-14-433658 — 8.01, 9.01
- 2014-11-18 0001193125-14-415889 — 7.01, 9.01
- 2014-10-29 0001171843-14-005051 — 2.02, 9.01
- 2014-10-27 0001193125-14-383428 — 1.01, 9.01
- 2014-09-22 0001193125-14-348697 — 1.01, 7.01, 9.01
- 2014-08-05 0001193125-14-295808 — 1.01, 5.02, 9.01
- 2014-07-30 0001171843-14-003548 — 2.02, 9.01
- 2014-04-30 0001171843-14-002017 — 2.02, 9.01
- 2014-04-25 0001193125-14-160146 — 5.02, 5.07, 9.01
- 2014-04-10 0001171843-14-001656 — 2.02, 9.01
- 2014-03-04 0001193125-14-082534 — 4.01, 9.01
- 2014-02-05 0001171843-14-000553 — 2.02, 9.01
- 2014-01-14 0001193125-14-010922 — 1.01, 2.03, 3.02, 8.01, 9.01
- 2013-12-27 0001193125-13-486144 — 5.02, 9.01
- 2013-12-20 0001193125-13-481141 — 1.01, 1.02, 2.03, 3.02, 8.01, 9.01
- 2013-12-17 0001193125-13-476207 — 5.03
- 2013-10-30 0001193125-13-418572 — 2.02, 5.02, 9.01
- 2013-09-12 0001193125-13-365420 — 2.05
- 2013-08-14 0001193125-13-334349 — 7.01, 9.01
- 2013-08-01 0001171843-13-003138 — 2.02, 9.01
- 2013-06-25 0001193125-13-270725 — 5.02, 9.01
- 2013-05-02 0001171843-13-001746 — 2.02, 9.01
- 2013-04-29 0001193125-13-182083 — 5.02, 5.07, 9.01
- 2013-03-18 0001193125-13-111308 — 1.01, 7.01, 9.01
- 2013-03-06 0001193125-13-093625 — 5.02, 9.01
- 2013-03-01 0001193125-13-087439 — 2.02 — amendment of 0001171843-13-000414
- 2013-02-28 0001193125-13-084764 — 5.02
- 2013-02-05 0001171843-13-000414 — 2.02, 9.01
- 2013-01-31 0001193125-13-032848 — 5.02, 9.01
- 2013-01-17 0001193125-13-015928 — 7.01, 9.01
- 2013-01-16 0001193125-13-014581 — 2.02, 9.01
- 2012-12-11 0001193125-12-498644 — 5.02, 9.01
- 2012-11-15 0001193125-12-472451 — 7.01, 9.01
- 2012-11-01 0001171843-12-003890 — 2.02, 9.01
- 2012-09-19 0001193125-12-396969 — 1.01, 2.03, 7.01, 9.01
- 2012-09-11 0001193125-12-388130 — 7.01, 9.01
- 2012-07-31 0001171843-12-002829 — 2.02, 9.01
- 2012-05-15 0001193125-12-233501 — 7.01, 9.01
- 2012-05-01 0001171843-12-001574 — 2.02, 9.01
- 2012-04-27 0001193125-12-191623 — 5.07
- 2012-03-01 0001193125-12-090623 — 2.02 — amendment of 0001171843-12-000382
- 2012-02-07 0001171843-12-000382 — 2.02, 9.01
- 2012-01-19 0001193125-12-016588 — 5.02, 9.01
- 2011-11-15 0000950123-11-098812 — 7.01, 9.01
- 2011-11-02 0001171843-11-003248 — 2.02, 9.01
- 2011-09-28 0000950123-11-087344 — 7.01, 9.01
- 2011-09-19 0000950123-11-085128 — 5.02, 9.01
- 2011-09-15 0000950123-11-084704 — 5.07 — amendment of 0000950123-11-054296
- 2011-08-04 0001171843-11-002356 — 2.02, 9.01
- 2011-07-27 0000950123-11-068987 — 1.01, 2.03, 9.01
- 2011-06-21 0000950123-11-060477 — 7.01, 9.01
- 2011-06-06 0000950123-11-056971 — 5.03, 9.01
- 2011-05-26 0000950123-11-054296 — 5.07
- 2011-05-10 0000950123-11-048462 — 8.01, 9.01
- 2011-05-05 0001171843-11-001344 — 2.02, 9.01
- 2011-03-22 0000950123-11-027824 — 7.01, 9.01
- 2011-03-18 0000950123-11-026913 — 4.01
- 2011-03-18 0000950123-11-026910 — 4.01, 9.01 — amendment, the index does not say of what
- 2011-03-02 0000950123-11-020941 — 5.03, 9.01
- 2011-02-10 0001171843-11-000391 — 2.02, 9.01
- 2011-01-13 0000950123-11-002528 — 7.01, 9.01
- 2011-01-13 0000950123-11-002446 — 2.02, 9.01
- 2010-11-29 0000950123-10-109448 — 4.01, 9.01 — amendment, the index does not say of what
- 2010-11-17 0000950123-10-106706 — 4.01
- 2010-11-15 0000950123-10-105479 — 5.02, 9.01
- 2010-11-04 0001171843-10-002324 — 2.02, 9.01
- 2010-10-22 0000950123-10-095179 — 1.01, 9.01
- 2010-10-04 0000950123-10-090949 — 1.01, 5.03, 9.01
- 2010-08-05 0001171843-10-001587 — 2.02, 9.01
- 2010-08-05 0000950123-10-073258 — 1.01, 2.03, 9.01
- 2010-08-05 0000950123-10-073256 — 9.01 — amendment of 0000950123-10-034163
- 2010-07-12 0000950123-10-064794 — 5.02, 8.01, 9.01
- 2010-06-10 0000950123-10-057166 — 7.01, 9.01
- 2010-06-02 0000950123-10-055111 — 1.01, 5.07, 9.01
- 2010-05-06 0001171843-10-000819 — 2.02, 9.01
- 2010-04-26 0000950123-10-037806 — 8.01, 9.01 — amendment of 0000950123-10-034163
- 2010-04-13 0000950123-10-034163 — 1.01, 2.01, 2.03, 5.02, 7.01, 9.01
- 2010-03-30 0000950123-10-030123 — 1.01, 5.02, 9.01
- 2010-03-24 0000950123-10-027317 — 1.01, 5.02, 9.01
- 2010-03-16 0000950123-10-024853 — 7.01, 9.01 — amendment of 0001171843-10-000140
- 2010-03-15 0000950123-10-024637 — 5.07
- 2010-02-04 0001171843-10-000140 — 2.02, 9.01
- 2010-02-02 0000950123-10-007780 — 8.01, 9.01
- 2010-01-13 0000950123-10-002245 — 7.01, 9.01
- 2009-12-23 0000950123-09-073069 — 1.01, 9.01
- 2009-12-15 0000950123-09-070868 — 8.01, 9.01
- 2009-11-16 0000950123-09-062630 — 1.01, 7.01, 9.01
- 2009-11-04 0001171843-09-001103 — 2.02, 9.01
- 2009-09-04 0000950123-09-041133 — 2.05, 9.01
- 2009-07-29 0001171843-09-000743 — 2.02, 9.01
- 2009-06-09 0000950123-09-012507 — 7.01, 9.01
- 2009-04-30 0001171843-09-000427 — 2.02, 9.01
- 2009-04-28 0001362310-09-005960 — 8.01
- 2009-02-19 0001362310-09-002454 — 5.03, 9.01
- 2009-02-10 0001171843-09-000123 — 2.02, 9.01
- 2009-01-16 0000950153-09-000040 — 2.05, 9.01
- 2009-01-08 0000950153-09-000023 — 7.01, 9.01
- 2008-10-29 0001157523-08-008533 — 2.02, 9.01
- 2008-07-29 0001157523-08-005998 — 2.02, 9.01
- 2008-05-22 0000950153-08-001035 — 1.01, 2.03, 3.02, 9.01
- 2008-05-22 0000950153-08-001034 — 7.01, 9.01
- 2008-05-15 0000950153-08-000987 — 1.01, 1.02, 2.03, 3.02, 9.01
- 2008-04-30 0001157523-08-003483 — 2.02, 9.01
- 2008-02-07 0001157523-08-001077 — 2.02, 9.01
- 2008-01-08 0000950153-08-000033 — 7.01, 9.01
- 2007-11-15 0000950153-07-002440 — 7.01, 9.01
- 2007-11-14 0000950153-07-002426 — 7.01, 9.01
- 2007-11-14 0000950153-07-002421 — 5.03, 9.01
- 2007-10-31 0001157523-07-010491 — 2.02, 9.01
- 2007-10-02 0000950153-07-002094 — 7.01, 9.01
- 2007-07-31 0000950153-07-001622 — 2.02, 9.01
- 2007-06-13 0000950153-07-001327 — 7.01, 9.01
- 2007-05-02 0000950153-07-000941 — 2.02, 9.01
- 2007-04-12 0000950153-07-000763 — 5.02, 9.01
- 2007-02-15 0000950153-07-000339 — 2.02, 9.01
- 2007-01-11 0000950153-07-000076 — 7.01, 9.01
- 2007-01-10 0000950153-07-000071 — 2.01, 9.01 — amendment, the index does not say of what
- 2006-12-11 0000950153-06-002967 — 2.05, 9.01
- 2006-11-15 0000950153-06-002843 — 7.01, 9.01
- 2006-11-14 0000950153-06-002837 — 7.01, 9.01
- 2006-11-02 0000950153-06-002682 — 1.01, 1.02, 2.03, 9.01
- 2006-11-01 0000950153-06-002668 — 2.02, 9.01
- 2006-10-30 0000950124-06-006210 — 2.01, 9.01
- 2006-08-04 0000950153-06-002025 — 1.01, 9.01
- 2006-07-26 0000950153-06-001937 — 2.02, 9.01
- 2006-06-28 0000950153-06-001716 — 1.01, 9.01
- 2006-06-13 0000950153-06-001597 — 7.01, 9.01
- 2006-04-26 0000950153-06-001079 — 2.02, 9.01
- 2006-02-08 0001104659-06-006985 — 2.02, 9.01
- 2006-01-12 0001104659-06-001893 — 7.01, 9.01
- 2005-12-05 0001104659-05-058918 — 1.01, 5.02, 9.01
- 2005-10-26 0001104659-05-050306 — 2.02, 9.01
- 2005-09-20 0001104659-05-044954 — 8.01
- 2005-08-30 0001104659-05-042053 — 3.03, 8.01, 9.01
- 2005-07-27 0001104659-05-034437 — 2.02, 5.02, 9.01
- 2005-07-21 0001104659-05-033462 — 1.01, 1.02, 2.03, 9.01
- 2005-06-13 0001104659-05-027969 — 8.01
- 2005-06-08 0001104659-05-027364 — 7.01, 9.01
- 2005-05-17 0001104659-05-024118 — 7.01, 9.01
- 2005-05-12 0001104659-05-022993 — 7.01, 9.01
- 2005-05-11 0001104659-05-022606 — 1.01, 9.01
- 2005-05-02 0001104659-05-019649 — 2.02, 5.02, 9.01
- 2005-04-26 0001104659-05-018233 — 7.01, 9.01
- 2005-02-08 0001104659-05-004642 — 2.02, 9.01
- 2005-01-12 0001104659-05-001194 — 7.01, 9.01
- 2004-12-22 0001104659-04-040933 — 5.02
- 2004-12-08 0001104659-04-038850 — 7.01, 9.01
- 2004-10-26 0001104659-04-031931 — 2.02, 9.01
- 2004-10-01 0001104659-04-029361 — 5.02
- 2004-08-02 0001104659-04-021785 — 9
- 2004-07-29 0001104659-04-021529 — 12
- 2004-05-06 0001104659-04-012742 — 9
- 2004-04-26 0001104659-04-011228 — 12
- 2004-02-03 0001104659-04-002424 — 9
- 2004-01-28 0001104659-04-001980 — 12
- 2004-01-09 0001104659-04-000457 — 9
- 2003-10-21 0001104659-03-023304 — 12
- 2003-07-29 0001104659-03-015999 — 12
- 2003-05-08 0001104659-03-008647 — 9
- 2003-05-08 0001104659-03-008462 — 9
- 2003-05-01 0001104659-03-007866 — 9
- 2003-03-07 0001104659-03-003816 — 2, 7 — amendment of 0000950153-02-002190
- 2002-12-27 0000950153-02-002190 — 2, 7
- 2002-05-17 0000912057-02-021145 — 4, 7
- 2001-12-21 0000912057-01-544281 — 7
- 2000-10-27 0000912057-00-046109 — 5

## late-filing notifications on or before 2017-02-24

- none on or before 2017-02-24

## item 2.02 — earnings release, exhibit 99.1

[0001193125-17-034652:8k_2_02:1]
EX-99.1
2
d330320dex991.htm
EX-99.1

[0001193125-17-034652:8k_2_02:2]
EX-99.1

[0001193125-17-034652:8k_2_02:3]
Exhibit 99.1

[0001193125-17-034652:8k_2_02:4]
| TTM Technologies, Inc., Q4’16 |  |  |  | Contact: |
|  |  |  |  | Sameer Desai, |
|  |  |  |  | Senior Director, Corporate Development & Investor Relations |
|  |  |  |  | sameer.desai@ttmtech.com |
|  |  |  |  | 714-327-3050 |

[0001193125-17-034652:8k_2_02:5]
TTM Technologies, Inc. Reports Fourth Quarter and Fiscal Year 2016 Results

[0001193125-17-034652:8k_2_02:6]
Broad Based Growth Drives Results Ahead of Guidance Delivering Record Revenues

[0001193125-17-034652:8k_2_02:7]
COSTA MESA, CA – February 8th, 2017 – TTM Technologies, Inc. (NASDAQ:TTMI), a leading global printed circuit board (“PCB”)
manufacturer, today reported results for the fourth quarter of fiscal 2016, which ended January 2nd, 2017.

[0001193125-17-034652:8k_2_02:8]
Fourth Quarter 2016 Highlights

[0001193125-17-034652:8k_2_02:9]
|  | • |  | Net sales were $706.5 million |

[0001193125-17-034652:8k_2_02:10]
|  | • |  | GAAP net loss attributable to stockholders was $2.0 million, or $0.02 per share, which included a pre-tax charge of $47.8 million for debt extinguishment |

[0001193125-17-034652:8k_2_02:11]
|  | • |  | Non-GAAP net income attributable to stockholders was $59.8 million, or $0.58 per diluted share |

[0001193125-17-034652:8k_2_02:12]
|  | • |  | Adjusted EBITDA was $128.5 million |

[0001193125-17-034652:8k_2_02:13]
Fourth Quarter 2016 Financial Results

[0001193125-17-034652:8k_2_02:14]
Net sales for the fourth quarter of 2016 were $706.5 million, compared to $668.9 million in the fourth quarter of 2015 and $641.7 million in the third quarter
of 2016.

[0001193125-17-034652:8k_2_02:15]
GAAP operating income for the fourth quarter of 2016 was $69.6 million, compared to $36.5 million in the fourth quarter of 2015 and $50.2
million in the third quarter of 2016.

[0001193125-17-034652:8k_2_02:16]
GAAP net loss attributable to stockholders for the fourth quarter of 2016 was $2.0 million, or $0.02 per share.
This compares to a GAAP net income attributable to stockholders of $9.5 million, or $0.09 per diluted share, in the fourth quarter of 2015 and $25.6 million, or $0.23 per diluted share, in the third quarter of 2016. The fourth quarter GAAP net loss
includes a pre-tax charge of $47.8 million due to the early extinguishment of debt.

[0001193125-17-034652:8k_2_02:17]
On a non-GAAP basis, net income attributable to stockholders for the
fourth quarter of 2016 was $59.8 million, or $0.58 per diluted share. This compares to non-GAAP net income attributable to stockholders of $31.5 million, or $0.31 per diluted share, for the fourth quarter of 2015 and $40.1 million, or $0.39 per
diluted share, in the third quarter of 2016.

[0001193125-17-034652:8k_2_02:18]
Adjusted EBITDA for the fourth quarter of 2016 was $128.5 million, or 18.2 percent of net sales, compared to
adjusted EBITDA of $95.8 million, or 14.3 percent of net sales, for the fourth quarter of 2015 and $102.2 million, or 15.9 percent of net sales, for the third quarter of 2016.

[0001193125-17-034652:8k_2_02:19]
“Our fourth quarter revenues exceeded the high end of our guidance and our profitability was better than our forecast,” said Tom Edman, CEO of TTM.
“On a year over year basis, most end markets grew, with the fastest growth coming from the cellular and automotive end markets. This drove substantial operating income leverage in the business resulting in the highest non-GAAP EPS in the
history of the company.”

[0001193125-17-034652:8k_2_02:20]
Full Year 2016 Financial Results

[0001193125-17-034652:8k_2_02:21]
Net sales for fiscal year 2016 increased to $2.5 billion from $2.1 billion in fiscal year 2015.

[0001193125-17-034652:8k_2_02:22]
GAAP operating income for fiscal year 2016 was $173.5 million, an increase from GAAP operating income of $61.3 million in fiscal year 2015.

[0001193125-17-034652:8k_2_02:23]
GAAP net income attributable to stockholders for fiscal year 2016 was $34.9 million, or $0.34 per diluted share, compared to GAAP net loss attributable to
stockholders of $25.9 million, or $0.28 per share, for fiscal year 2015.

[0001193125-17-034652:8k_2_02:24]
| TTM Technologies, Inc., Q4’16 |  |  |  | Contact: |
|  |  |  |  | Sameer Desai, |
|  |  |  |  | Senior Director, Corporate Development & Investor Relations |
|  |  |  |  | sameer.desai@ttmtech.com |
|  |  |  |  | 714-327-3050 |

[0001193125-17-034652:8k_2_02:25]
On a non-GAAP basis, net income attributable to stockholders for fiscal year 2016 was $142.3 million, or
$1.40 per diluted share. This compares to fiscal year 2015 non-GAAP net income attributable to stockholders of $81.1 million, or $0.87 per diluted share.

[0001193125-17-034652:8k_2_02:26]
Adjusted EBITDA for fiscal year 2016 was $395.4 million, or 15.6 percent of net sales, compared to $285.7 million, or 13.6 percent of net sales, for fiscal
year 2015.

[0001193125-17-034652:8k_2_02:27]
“2016 was the year that validated TTM’s strategy of diversification, differentiation and discipline. We saw solid growth in the
automotive and aerospace and defense end markets that partially offset the declines in the cellular and networking and communications end markets. Due to disciplined execution of synergies and cost controls, we generated $217 million in free cash
flow and repaid approximately $218 million of our debt, allowing us to achieve a net debt to EBITDA ratio of less than 2.0 well ahead of our original timeline,” continued Edman. “I would like to thank our employees for their tremendous
efforts to achieve these results for the year 2016 as we created a new “One TTM” resulting from the combination of Viasystems and TTM Technologies.”

[0001193125-17-034652:8k_2_02:28]
“In 2017, we are looking forward to year on year growth in many of our end markets driven by megatrends such as growing automotive electronic content,
increased aerospace and defense procurement, and upgrades in cellular phones.”

[0001193125-17-034652:8k_2_02:29]
Business Outlook

[0001193125-17-034652:8k_2_02:30]
For the first quarter of 2017, TTM estimates that revenue will be in the range of $595 million to $635 million, and non-GAAP net income attributable to
stockholders will be in the range of $0.25 to $0.31 per diluted share.

[0001193125-17-034652:8k_2_02:31]
To Access the Live Webcast/Conference Call

[0001193125-17-034652:8k_2_02:32]
TTM will host a conference call and webcast to discuss fourth quarter 2016 results and first quarter 2017 outlook on Wednesday, February 8th, 2017, at
4:30 p.m. Eastern Time (1:30 p.m. Pacific Time). The conference call will include forward-looking statements.

[0001193125-17-034652:8k_2_02:33]
Telephone access is available by dialing
domestic 888-278-8459 or international 913-312-1495 (ID 6391150). The conference call also will be webcast on TTM’s website at www.ttm.com.

[0001193125-17-034652:8k_2_02:34]
To Access a Replay of the Webcast

[0001193125-17-034652:8k_2_02:35]
The replay of the
webcast will remain accessible for one week following the live event on TTM’s website at www.ttm.com.

[0001193125-17-034652:8k_2_02:36]
About TTM

[0001193125-17-034652:8k_2_02:37]
TTM Technologies, Inc. is a leading global printed circuit board manufacturer, focusing on quick-turn and volume production of technologically advanced PCBs,
backplane assemblies and electro-mechanical solutions. TTM stands for time-to-market, representing how TTM’s time-critical, one-stop manufacturing services enable customers to shorten the time required to develop new products and bring them to
market. Additional information can be found at www.ttm.com.

[0001193125-17-034652:8k_2_02:38]
Forward-Looking Statements

[0001193125-17-034652:8k_2_02:39]
This release contains forward-looking statements that relate to future events or performance. TTM cautions you that such statements are simply predictions and
actual events or results may differ materially. These statements reflect TTM’s current expectations, and TTM does not undertake to update or revise these forward looking statements, even if experience or future changes make it clear that any

[0001193125-17-034652:8k_2_02:40]
| TTM Technologies, Inc., Q4’16 |  |  |  | Contact: |
|  |  |  |  | Sameer Desai, |
|  |  |  |  | Senior Director, Corporate Development & Investor Relations |
|  |  |  |  | sameer.desai@ttmtech.com |
|  |  |  |  | 714-327-3050 |

[0001193125-17-034652:8k_2_02:41]
projected results expressed or implied in this or other TTM statements will not be realized. Further, these statements involve risks and uncertainties, many of which are beyond TTM’s
control, which could cause actual results to differ materially from the forward-looking statements. These risks and uncertainties include, but are not limited to, general market and economic conditions, including interest rates, currency exchange
rates and consumer spending, demand for TTM’s products, market pressures on prices of TTM’s products, warranty claims, changes in product mix, contemplated significant capital expenditures and related financing requirements, TTM’s
dependence upon a small number of customers and other factors set forth in the “Risk Factors” and “Management’s Discussion and Analysis of Financial Condition and Results of Operations” sections of the Company’s public
reports filed with the SEC.

[0001193125-17-034652:8k_2_02:42]
About Our Non-GAAP Financial Measures

[0001193125-17-034652:8k_2_02:43]
This release includes information about TTM’s adjusted EBITDA, non-GAAP net income and non-GAAP earnings per share, all of which are non-GAAP financial
measures. TTM presents non-GAAP financial information to enable investors to see TTM through the eyes of management and to provide better insight into TTM’s ongoing financial performance.

[0001193125-17-034652:8k_2_02:44]
A material limitation associated with the use of the above non-GAAP financial measures is that they have no standardized measurement prescribed by GAAP and
may not be comparable to similar non-GAAP financial measures used by other companies. TTM compensates for these limitations by providing full disclosure of each non-GAAP financial measure and reconciliation to the most directly comparable GAAP
financial measure. However, the non-GAAP financial measures should not be considered in isolation from, or as a substitute for, financial information prepared in accordance with GAAP.

[0001193125-17-034652:8k_2_02:45]
- Tables Follow -

[0001193125-17-034652:8k_2_02:46]
TTM TECHNOLOGIES, INC.

[0001193125-17-034652:8k_2_02:47]
Selected Unaudited Financial Information

[0001193125-17-034652:8k_2_02:48]
(In thousands, except per share data)

[0001193125-17-034652:8k_2_02:49]
|  |  | Fourth Quarter |  |  | Third Quarter |  |  | Full Year |  |
|  |  | 2016 |  |  | 2015 |  |  | 2016 |  |  | 2016 |  |  | 2015 |  |
| CONSOLIDATED CONDENSED STATEMENTS OF OPERATIONS |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Net sales |  | $ | 706,534 |  |  | $ | 668,874 |  |  | $ | 641,720 |  |  | $ | 2,533,359 |  |  | $ | 2,095,488 |  |
| Cost of goods sold |  |  | 573,689 |  |  |  | 560,604 |  |  |  | 532,158 |  |  |  | 2,109,744 |  |  |  | 1,785,351 |  |
| Gross profit |  |  | 132,845 |  |  |  | 108,270 |  |  |  | 109,562 |  |  |  | 423,615 |  |  |  | 310,137 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Selling and marketing |  |  | 16,848 |  |  |  | 17,963 |  |  |  | 15,643 |  |  |  | 66,366 |  |  |  | 57,361 |  |
| General and administrative |  |  | 38,998 |  |  |  | 41,654 |  |  |  | 35,641 |  |  |  | 148,719 |  |  |  | 167,109 |  |
| Amortization of definite-lived intangibles |  |  | 6,407 |  |  |  | 6,683 |  |  |  | 5,949 |  |  |  | 24,252 |  |  |  | 18,888 |  |
| Restructuring charges |  |  | 946 |  |  |  | 5,429 |  |  |  | 2,103 |  |  |  | 8,951 |  |  |  | 7,941 |  |
| Impairment of long-lived assets |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 3,346 |  |  |  | — |  |
| Gain on sale of assets |  |  | — |  |  |  | — |  |  |  | — |  |  |  | (1,472 | ) |  |  | (2,504 | ) |
| Total operating expenses |  |  | 63,199 |  |  |  | 71,729 |  |  |  | 59,336 |  |  |  | 250,162 |  |  |  | 248,795 |  |
| Operating income |  |  | 69,646 |  |  |  | 36,541 |  |  |  | 50,226 |  |  |  | 173,453 |  |  |  | 61,342 |  |
| Interest expense |  |  | (15,267 | ) |  |  | (20,208 | ) |  |  | (18,873 | ) |  |  | (76,008 | ) |  |  | (59,753 | ) |
| Loss on extinguishment of debt |  |  | (47,767 | ) |  |  | — |  |  |  | — |  |  |  | (47,767 | ) |  |  | (802 | ) |
| Other, net |  |  | 8,994 |  |  |  | 3,925 |  |  |  | 3,930 |  |  |  | 17,324 |  |  |  | 8,189 |  |
| Income before income taxes |  |  | 15,606 |  |  |  | 20,258 |  |  |  | 35,283 |  |  |  | 67,002 |  |  |  | 8,976 |  |
| Income tax provision |  |  | (17,416 | ) |  |  | (10,601 | ) |  |  | (9,513 | ) |  |  | (31,427 | ) |  |  | (34,594 | ) |
| Net income (loss) |  | $ | (1,810 | ) |  | $ | 9,657 |  |  | $ | 25,770 |  |  | $ | 35,575 |  |  | $ | (25,618 | ) |
| Net income attributable to noncontrolling interest |  |  | (195 | ) |  |  | (136 | ) |  |  | (188 | ) |  |  | (714 | ) |  |  | (264 | ) |
| Net income (loss) attributable to stockholders |  | $ | (2,005 | ) |  | $ | 9,521 |  |  | $ | 25,582 |  |  | $ | 34,861 |  |  | $ | (25,882 | ) |
| Earnings (loss) per share attributable to stockholders: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  | $ | (0.02 | ) |  | $ | 0.10 |  |  | $ | 0.26 |  |  | $ | 0.35 |  |  | $ | (0.28 | ) |
| Diluted |  | $ | (0.02 | ) |  | $ | 0.09 |  |  | $ | 0.23 |  |  | $ | 0.34 |  |  | $ | (0.28 | ) |
| Weighted-average shares used in computing per share amounts: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  |  | 100,365 |  |  |  | 99,134 |  |  |  | 100,245 |  |  |  | 100,099 |  |  |  | 92,675 |  |
| Diluted |  |  | 100,365 |  |  |  | 126,329 |  |  |  | 127,645 |  |  |  | 101,482 |  |  |  | 92,675 |  |

[0001193125-17-034652:8k_2_02:50]
| Reconciliation of the numerator and denominator used to calculate basic earnings per share and diluted earnings per share: |  |
| Net income attributable to stockholders |  | $ | 9,521 |  |  | $ | 25,582 |  |
| Add back items: interest expense, net of tax |  |  | 2,009 |  |  |  | 3,321 |  |
| Adjusted net income attributable to stockholders |  | $ | 11,530 |  |  | $ | 28,903 |  |
| Weighted-average shares outstanding |  |  | 99,134 |  |  |  | 100,245 |  |
| Dilutive effect of convertible debt |  |  | 25,940 |  |  |  | 25,940 |  |
| Dilutive effect of performance-based stock units, restricted stock units and stock options |  |  | 1,255 |  |  |  | 1,460 |  |
| Diluted shares |  |  | 126,329 |  |  |  | 127,645 |  |
| Earnings per share attributable to stockholders: |  |  |  |  |  |  |  |  |
| Basic |  | $ | 0.10 |  |  | $ | 0.26 |  |
| Diluted |  | $ | 0.09 |  |  | $ | 0.23 |  |

[0001193125-17-034652:8k_2_02:51]
SELECTED BALANCE SHEET DATA

[0001193125-17-034652:8k_2_02:52]
|  |  | January 2, 2017 |  |  | December 28, 2015 |  |
| Cash and cash equivalents, including restricted cash |  | $ | 256,277 |  |  | $ | 262,630 |  |
| Accounts and notes receivable, net |  |  | 432,596 |  |  |  | 454,001 |  |
| Inventories |  |  | 269,212 |  |  |  | 268,923 |  |
| Total current assets |  |  | 1,012,841 |  |  |  | 1,022,520 |  |
| Property, plant and equipment, net |  |  | 966,638 |  |  |  | 1,103,067 |  |
| Other non-current assets |  |  | 520,597 |  |  |  | 514,546 |  |
| Total assets |  |  | 2,500,076 |  |  |  | 2,640,133 |  |
| Short-term debt, including current portion of long-term debt |  | $ | 110,652 |  |  | $ | 157,375 |  |
| Accounts payable |  |  | 355,774 |  |  |  | 347,916 |  |
| Total current liabilities |  |  | 689,065 |  |  |  | 744,994 |  |
| Debt, net of discount |  |  | 909,030 |  |  |  | 1,013,411 |  |
| Total long-term liabilities |  |  | 981,886 |  |  |  | 1,068,470 |  |
| Total equity |  |  | 829,125 |  |  |  | 826,669 |  |
| Total liabilities and equity |  |  | 2,500,076 |  |  |  | 2,640,133 |  |

[0001193125-17-034652:8k_2_02:53]
SUPPLEMENTAL DATA

[0001193125-17-034652:8k_2_02:54]
|  |  | Fourth Quarter |  |  | Third Quarter |  |  | Full Year |  |
|  |  | 2016 |  |  | 2015 |  |  | 2016 |  |  | 2016 |  |  | 2015 |  |
| Gross margin |  |  | 18.8 | % |  |  | 16.2 | % |  |  | 17.1 | % |  |  | 16.7 | % |  |  | 14.8 | % |
| Operating margin |  |  | 9.9 | % |  |  | 5.5 | % |  |  | 7.8 | % |  |  | 6.8 | % |  |  | 2.9 | % |
| End Market Breakdown: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | Fourth Quarter |  |  | Third Quarter |  |  |  |  |
|  |  | 2016 |  |  | 2015 |  |  | 2016 |  |  |
| Aerospace/Defense |  |  | 14 | % |  |  | 13 | % |  |  | 15 | % |  |
| Automotive |  |  | 19 | % |  |  | 18 | % |  |  | 19 | % |  |
| Cellular Phone |  |  | 19 | % |  |  | 18 | % |  |  | 17 | % |  |
| Computing/Storage/Peripherals |  |  | 12 | % |  |  | 12 | % |  |  | 12 | % |  |
| Medical/Industrial/Instrumentation |  |  | 13 | % |  |  | 13 | % |  |  | 14 | % |  |
| Networking/Communications |  |  | 21 | % |  |  | 23 | % |  |  | 21 | % |  |
| Other |  |  | 2 | % |  |  | 3 | % |  |  | 2 | % |  |
| Stock-based Compensation: |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | Fourth Quarter |  |  | Third Quarter |  |  |
|  |  | 2016 |  |  | 2015 |  |  | 2016 |  |  |
| Amount included in: |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cost of goods sold |  | $ | 469 |  |  | $ | 327 |  |  | $ | 412 |  |  |
| Selling and marketing |  | $ | 305 |  |  |  | 301 |  |  |  | 268 |  |  |
| General and administrative |  |  | 2,426 |  |  |  | 2,007 |  |  |  | 2,119 |  |  |
| Total stock-based compensation expense |  | $ | 3,200 |  |  | $ | 2,635 |  |  | $ | 2,799 |  |  |
| Operating Segment Data: |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | Fourth Quarter |  |  | Third Quarter |  |  |
|  |  | 2016 |  |  | 2015 |  |  | 2016 |  |  |
| Net sales: |  |  |  |  |  |  |  |  |  |  |  |  |  |
| PCB |  | $ | 654,379 |  |  | $ | 611,045 |  |  | $ | 598,656 |  |  |
| E-M Solutions |  |  | 55,332 |  |  |  | 61,021 |  |  |  | 46,246 |  |  |
| Corporate |  |  | — |  |  |  | — |  |  |  | — |  |  |
| Total sales |  |  | 709,711 |  |  |  | 672,066 |  |  |  | 644,902 |  |  |
| Inter-segment sales |  |  | (3,177 | ) |  |  | (3,192 | ) |  |  | (3,182 | ) |  |
| Total net sales |  | $ | 706,534 |  |  | $ | 668,874 |  |  | $ | 641,720 |  |  |
| Operating segment income: |  |  |  |  |  |  |  |  |  |  |  |  |  |
| PCB |  | $ | 95,208 |  |  | $ | 66,320 |  |  | $ | 75,501 |  |  |
| E-M Solutions |  |  | 3,029 |  |  |  | 2,612 |  |  |  | 1,421 |  |  |
| Corporate |  |  | (22,184 | ) |  |  | (25,708 | ) |  |  | (20,747 | ) |  |
| Total operating segment income |  |  | 76,053 |  |  |  | 43,224 |  |  |  | 56,175 |  |  |
| Amortization of definite-lived intangibles |  |  | (6,407 | ) |  |  | (6,683 | ) |  |  | (5,949 | ) |  |
| Total operating income |  |  | 69,646 |  |  |  | 36,541 |  |  |  | 50,226 |  |  |
| Total other expense |  |  | (54,040 | ) |  |  | (16,283 | ) |  |  | (14,943 | ) |  |
| Income before income taxes |  | $ | 15,606 |  |  | $ | 20,258 |  |  | $ | 35,283 |  |  |

[0001193125-17-034652:8k_2_02:55]
RECONCILIATIONS1

[0001193125-17-034652:8k_2_02:56]
|  |  | Fourth Quarter |  |  | Third Quarter |  |  | Full Year |  |
|  |  | 2016 |  |  | 2015 |  |  | 2016 |  |  | 2016 |  |  | 2015 |  |
| Non-GAAP gross profit reconciliation2: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| GAAP gross profit |  | $ | 132,845 |  |  | $ | 108,270 |  |  | $ | 109,562 |  |  | $ | 423,615 |  |  | $ | 310,137 |  |
| Add back item: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Inventory markup |  |  | — |  |  |  | 598 |  |  |  | — |  |  |  | — |  |  |  | 16,220 |  |
| Stock-based compensation |  |  | 469 |  |  |  | 327 |  |  |  | 412 |  |  |  | 1,630 |  |  |  | 1,117 |  |
| Non-GAAP gross profit |  | $ | 133,314 |  |  | $ | 109,195 |  |  | $ | 109,974 |  |  | $ | 425,245 |  |  | $ | 327,474 |  |
| Non-GAAP gross margin |  |  | 18.9 | % |  |  | 16.3 | % |  |  | 17.1 | % |  |  | 16.8 | % |  |  | 15.6 | % |
| Non-GAAP operating income reconciliation3: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| GAAP operating income |  | $ | 69,646 |  |  | $ | 36,541 |  |  | $ | 50,226 |  |  | $ | 173,453 |  |  | $ | 61,342 |  |
| Add back items: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of definite-lived intangibles |  |  | 6,407 |  |  |  | 6,683 |  |  |  | 5,949 |  |  |  | 24,252 |  |  |  | 18,888 |  |
| Stock-based compensation |  |  | 3,200 |  |  |  | 2,635 |  |  |  | 2,799 |  |  |  | 11,090 |  |  |  | 9,661 |  |
| Gain on sale of assets |  |  | — |  |  |  | — |  |  |  | — |  |  |  | (1,472 | ) |  |  | (2,504 | ) |
| Acquisition-related costs |  |  | 195 |  |  |  | 1,521 |  |  |  | 197 |  |  |  | 1,688 |  |  |  | 34,448 |  |
| Inventory markup |  |  | — |  |  |  | 598 |  |  |  | — |  |  |  | — |  |  |  | 16,220 |  |
| Impairments, restructuring, and other charges |  |  | 1,530 |  |  |  | 5,429 |  |  |  | 2,103 |  |  |  | 12,881 |  |  |  | 7,941 |  |
| Non-GAAP operating income |  | $ | 80,978 |  |  | $ | 53,407 |  |  | $ | 61,274 |  |  | $ | 221,892 |  |  | $ | 145,996 |  |
| Non-GAAP operating margin |  |  | 11.5 | % |  |  | 8.0 | % |  |  | 9.5 | % |  |  | 8.8 | % |  |  | 7.0 | % |
| Non-GAAP net income and EPS attributable to stockholders reconciliation4: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| GAAP net income (loss) attributable to stockholders |  | $ | (2,005 | ) |  | $ | 9,521 |  |  | $ | 25,582 |  |  | $ | 34,861 |  |  | $ | (25,882 | ) |
| Add back items: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of definite-lived intangibles |  |  | 6,407 |  |  |  | 6,683 |  |  |  | 5,949 |  |  |  | 24,252 |  |  |  | 18,888 |  |
| Stock-based compensation |  |  | 3,200 |  |  |  | 2,635 |  |  |  | 2,799 |  |  |  | 11,090 |  |  |  | 9,661 |  |
| Non-cash interest expense |  |  | 2,697 |  |  |  | 4,893 |  |  |  | 4,721 |  |  |  | 19,180 |  |  |  | 15,626 |  |
| Gain on sale of assets |  |  | — |  |  |  | — |  |  |  | — |  |  |  | (1,472 | ) |  |  | (2,504 | ) |
| Acquisition-related costs |  |  | 195 |  |  |  | 1,521 |  |  |  | 197 |  |  |  | 1,688 |  |  |  | 34,448 |  |
| Inventory markup |  |  | — |  |  |  | 598 |  |  |  | — |  |  |  | — |  |  |  | 16,220 |  |
| Loss on extinguishment of debt |  |  | 47,767 |  |  |  | — |  |  |  | — |  |  |  | 47,767 |  |  |  | 802 |  |
| Impairments, restructuring and other charges |  |  | 1,530 |  |  |  | 5,429 |  |  |  | 2,103 |  |  |  | 12,881 |  |  |  | 7,941 |  |
| Income taxes |  |  | 49 |  |  |  | 247 |  |  |  | (1,208 | ) |  |  | (7,987 | ) |  |  | 5,869 |  |
| Non-GAAP net income attributable to stockholders |  | $ | 59,840 |  |  | $ | 31,527 |  |  | $ | 40,143 |  |  | $ | 142,260 |  |  | $ | 81,069 |  |
| Non-GAAP earnings per diluted share attributable to stockholders |  | $ | 0.58 |  |  | $ | 0.31 |  |  | $ | 0.39 |  |  | $ | 1.40 |  |  | $ | 0.87 |  |
| Non-GAAP diluted number of shares5: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Diluted shares |  |  | 102,563 |  |  |  | 126,329 |  |  |  | 127,645 |  |  |  | 101,482 |  |  |  | 93,640 |  |
| Dilutive effect of convertible debt |  |  | — |  |  |  | (25,940 | ) |  |  | (25,940 | ) |  |  | — |  |  |  | — |  |
| Non-GAAP diluted number of shares |  |  | 102,563 |  |  |  | 100,389 |  |  |  | 101,705 |  |  |  | 101,482 |  |  |  | 93,640 |  |
| Adjusted EBITDA reconciliation6: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| GAAP net income (loss) |  | $ | (1,810 | ) |  | $ | 9,657 |  |  | $ | 25,770 |  |  | $ | 35,575 |  |  | $ | (25,618 | ) |
| Add back items: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Income tax provision (benefit) |  |  | 17,416 |  |  |  | 10,601 |  |  |  | 9,513 |  |  |  | 31,427 |  |  |  | 34,594 |  |
| Interest expense |  |  | 15,267 |  |  |  | 20,208 |  |  |  | 18,873 |  |  |  | 76,008 |  |  |  | 59,753 |  |
| Amortization of definite-lived intangibles |  |  | 6,407 |  |  |  | 6,683 |  |  |  | 5,949 |  |  |  | 24,252 |  |  |  | 18,888 |  |
| Depreciation expense |  |  | 38,539 |  |  |  | 39,105 |  |  |  | 37,006 |  |  |  | 156,229 |  |  |  | 133,508 |  |
| Stock-based compensation |  |  | 3,200 |  |  |  | 2,635 |  |  |  | 2,799 |  |  |  | 11,090 |  |  |  | 9,661 |  |
| Gain on sale of assets |  |  | — |  |  |  | — |  |  |  | — |  |  |  | (1,472 | ) |  |  | (2,504 | ) |
| Acquisition-related costs |  |  | 195 |  |  |  | 1,521 |  |  |  | 197 |  |  |  | 1,688 |  |  |  | 34,448 |  |
| Inventory markup |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 14,200 |  |
| Loss on extinguishment of debt |  |  | 47,767 |  |  |  | — |  |  |  | — |  |  |  | 47,767 |  |  |  | 802 |  |
| Impairments, restructuring and other charges |  |  | 1,530 |  |  |  | 5,429 |  |  |  | 2,103 |  |  |  | 12,881 |  |  |  | 7,941 |  |
| Adjusted EBITDA |  | $ | 128,511 |  |  | $ | 95,839 |  |  | $ | 102,210 |  |  | $ | 395,445 |  |  | $ | 285,673 |  |
| Adjusted EBITDA margin |  |  | 18.2 | % |  |  | 14.3 | % |  |  | 15.9 | % |  |  | 15.6 | % |  |  | 13.6 | % |
| Free cash flow reconciliation: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Operating cash flow |  |  | 97,650 |  |  |  | 139,829 |  |  |  | 102,737 |  |  |  | 298,336 |  |  |  | 237,462 |  |
| Add back items: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Payment of accreted interest on convertible sr. notes |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 8,730 |  |
| Payment of acquisition-related costs |  |  | 869 |  |  |  | 1,522 |  |  |  | 11 |  |  |  | 3,895 |  |  |  | 36,210 |  |
| Adjusted operating cash flow |  |  | 98,519 |  |  |  | 141,351 |  |  |  | 102,748 |  |  |  | 302,231 |  |  |  | 282,402 |  |
| Capital expenditures, net |  |  | (22,619 | ) |  |  | (22,967 | ) |  |  | (24,221 | ) |  |  | (85,139 | ) |  |  | (99,718 | ) |
| Free cash flow |  | $ | 75,900 |  |  | $ | 118,384 |  |  | $ | 78,527 |  |  | $ | 217,092 |  |  | $ | 182,684 |  |

[0001193125-17-034652:8k_2_02:57]
| 1 | This information provides a reconciliation of non-GAAP gross profit, non-GAAP operating income, non-GAAP net income attributable to stockholders, non-GAAP EPS attributable to stockholders, and adjusted EBITDA to the financial information in our consolidated condensed statements of operations. |

[0001193125-17-034652:8k_2_02:58]
| 2 | Non-GAAP gross profit and gross margin measures exclude stock-based compensation expense, and inventory markup. |

[0001193125-17-034652:8k_2_02:59]
| 3 | Non-GAAP operating income and operating margin measures exclude amortization of intangibles, stock-based compensation expense, gain on sale of assets, inventory markup, acquisition-related costs, asset impairments, restructuring and other charges. |

[0001193125-17-034652:8k_2_02:60]
| 4 | This information provides non-GAAP net income attributable to stockholders and non-GAAP EPS attributable to stockholders, which are non-GAAP financial measures. Management believes that both measures - which add back amortization of intangibles, stock-based compensation expense, non-cash interest expense on debt (before consideration of capitalized interest), gain on sale of assets, inventory markup, acquisition-related costs, asset impairments, restructuring and other charges as well as the associated tax impact of these charges and discrete tax items - provide additional useful information to investors regarding the Company’s ongoing financial condition and results of operations. |

[0001193125-17-034652:8k_2_02:61]
| 5 | Non-GAAP diluted number of shares used in computing non-GAAP earnings per share attributable to stockholders excludes the dilutive effect of convertible debt. |

[0001193125-17-034652:8k_2_02:62]
| 6 | Adjusted EBITDA is defined as earnings before interest expense, income taxes, depreciation, amortization of intangibles, stock-based compensation expense, gain on sale of assets, inventory markup, acquisition-related costs, asset impairments, restructuring and other charges. We present adjusted EBITDA to enhance the understanding of our operating results, and it is a key measure we use to evaluate our operations. In addition, we provide our adjusted EBITDA because we believe that investors and securities analysts will find adjusted EBITDA to be a useful measure for evaluating our operating performance and comparing our operating performance with that of similar companies that have different capital structures and for evaluating our ability to meet our future debt service, capital expenditures, and working capital requirements. However, adjusted EBITDA should not be considered as an alternative to cash flows from operating activities as a measure of liquidity or as an alternative to net income as a measure of operating results in accordance with accounting principles generally accepted in the United States of America. |
