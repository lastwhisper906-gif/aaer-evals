# TTMI notes — 0001193125-17-055058


## us-gaap:CashAndCashEquivalentsPolicyTextBlock

[0001193125-17-055058:notes:1]
Cash
 Equivalents

[0001193125-17-055058:notes:2]
The Company
 considers highly liquid investments with insignificant interest
 rate risk and original maturities to the Company of three months or
 less to be cash equivalents. Cash equivalents consist primarily of
 interest-bearing bank accounts and money market funds.

[0001193125-17-055058:notes:3]
The Company
 considers highly liquid investments with an effective maturity to
 the Company of more than three months and less than one year to be
 short-term investments.

[0001193125-17-055058:notes:4]
As of
 December 28, 2015, the Company had $3,530 of restricted cash
 related to the collaterization of certain letter of credit
 arrangements. As of January 2, 2017, all such letter of credit
 arrangements requiring collaterization had expired.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001193125-17-055058:notes:5]
| (13) | Commitments and Contingencies |

[0001193125-17-055058:notes:6]
Operating Leases

[0001193125-17-055058:notes:7]
The Company
 leases some of its manufacturing and assembly plants, a sales
 office and equipment under noncancellable operating leases that
 expire at various dates through 2050. Certain real property leases
 contain renewal provisions at the Company’s option. Most of
 the leases require the Company to pay for certain other costs such
 as property taxes and maintenance. Certain leases also contain rent
 escalation clauses (step rents) that require additional rental
 amounts in the later years of the term. Rent expense for leases
 with step rents is recognized on a straight-line basis over the
 minimum lease term.

[0001193125-17-055058:notes:8]
The following
 is a schedule of future minimum lease payments as of
 January 2, 2017:

[0001193125-17-055058:notes:9]
|  |  | Operating Leases |  |
|  |  | (In thousands) |  |
| 2017 |  | $ | 7,893 |  |
| 2018 |  |  | 4,375 |  |
| 2019 |  |  | 3,156 |  |
| 2020 |  |  | 2,351 |  |
| 2021 |  |  | 1,699 |  |
| Thereafter |  |  | 5,016 |  |
| Total minimum lease payments |  | $ | 24,490 |  |

[0001193125-17-055058:notes:10]
Total rent
 expense for the years ended January 2, 2017, December 28,
 2015, and December 29, 2014, was approximately $10,329, $7,362
 and $3,731, respectively.

[0001193125-17-055058:notes:11]
Legal
 Matters

[0001193125-17-055058:notes:12]
The Company
 is subject to various legal matters, which it considers normal for
 its business activities. While the Company currently believes that
 the amount of any reasonably possible loss for known matters would
 not be material to the Company’s financial condition, the
 outcome of these actions is inherently difficult to predict. In the
 event of an adverse outcome, the ultimate potential loss could have
 a material adverse effect on the Company’s financial
 condition or results of operations in a particular period. The
 Company has accrued amounts for its loss contingencies which are
 probable and estimable as of January 2, 2017 and
 December 28, 2015. However, these amounts are not material to
 the consolidated financial statements of the Company.

[0001193125-17-055058:notes:13]
Environmental Matters

[0001193125-17-055058:notes:14]
The process
 to manufacture PCBs requires adherence to city, county, state,
 federal, and foreign environmental regulations regarding the
 storage, use, handling and disposal of chemicals, solid wastes and
 other hazardous materials, as well as compliance with air quality
 standards and chemical use reporting. The Company believes that its
 facilities in the United States and Canada comply in all material
 respects with applicable environmental laws and regulations. In
 China, governmental authorities have adopted new rules and
 regulations governing environmental issues. An update to the
 Chinese environmental waste water law was issued in late 2012,
 allowing for an interim period in which plants subject to such law
 may install equipment that meets the new regulatory regime. Some of
 the Company’s plants in China are not yet in full compliance
 with the updated environmental regulations. The Company believes it
 has developed plans acceptable to the Chinese government and is in
 the process of implementing these plans. The Company does not
 anticipate any immediate risk of government fines or temporary
 closure of its Chinese plants. The Company has established and
 enacted an investment plan related to the efforts to come into full
 compliance with the new regulations. The 2017 capital expenditure
 costs expected for these plans are included in the Company’s
 capital expenditure projections.


## us-gaap:ConvertibleDebtTableTextBlock

[0001193125-17-055058:notes:15]
As of
 January 2, 2017 and December 28, 2015, the following
 summarizes the equity components of the convertible senior notes
 included in additional paid-in capital:

[0001193125-17-055058:notes:16]
|  |  | As of January 2, 2017 and December 28, 2015 |  |
|  |  | Embedded conversion option — Convertible Senior Notes |  |  | Embedded conversion option — Convertible Senior Notes Issuance Costs |  |  | Total |  |
|  |  | (in thousands) |  |
| Convertible senior notes due 2020 |  | $ | 60,227 |  |  | $ | (1,916 | ) |  | $ | 58,311 |  |


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001193125-17-055058:notes:17]
| (14) | Stock-Based Compensation |

[0001193125-17-055058:notes:18]
Incentive Compensation Plan

[0001193125-17-055058:notes:19]
The Company
 maintains a 2014 Incentive Compensation Plan (the Plan), which
 allowed for the issuance of up to 5,288 shares. In May 2016, the
 Plan was amended to increase the amount allowed for issuance by
 5,000 shares, revising the maximum allowed for issuance to 10,288
 through its expiration date of February 2024.

[0001193125-17-055058:notes:20]
The Plan
 provides for the grant of incentive stock options and nonqualified
 stock options to the Company’s key employees, non-employee directors and consultants.
 Other types of awards such as performance-based restricted stock
 units (PRUs), restricted stock units (RSUs), and stock appreciation
 rights are also permitted. The exercise price for options and
 awards is determined by the compensation committee of the board of
 directors and, for options intended to qualify as incentive stock
 options, may not be less than the fair market value as determined
 by the closing stock price at the date of the grant. Each option
 and award shall vest and expire as determined by the compensation
 committee of the board of directors, with options, PRUs and RSUs
 generally vesting over three years for employees and one year
 for non-employee directors. Options, PRUs and
 RSUs do not have voting rights. Options expire no later than ten
 years from the grant date. All grants provide for accelerated
 vesting if there is a change in control, as defined in the Plan.
 Upon the exercise of outstanding stock options or vesting of RSUs
 and PRUs, the Company’s practice is to issue new registered
 shares that are reserved for issuance under the Plan.

[0001193125-17-055058:notes:21]
As of
 January 2, 2017, 697 PRUs, 3,104 RSUs and 87 stock options
 were outstanding under the Plan. Included in the 697 PRUs
 outstanding as of January 2, 2017 are 291 vested but not yet
 released. Included in the 3,104 RSUs outstanding as of
 January 2, 2017 are 396 vested but not yet released RSUs
 associated with non-employee directors. These RSUs vest
 over one year with release of the underlying shares of common stock
 deferred until retirement from the board of directors, (or until
 one year after retirement in the case of certain prior
 grants).

[0001193125-17-055058:notes:22]
Performance-based Restricted Stock
 Units

[0001193125-17-055058:notes:23]
The Company
 maintains a long-term incentive program for executives that
 provides for the issuance of PRUs, representing hypothetical shares
 of the Company’s common stock that may be issued. Under the
 PRU program, a target number of PRUs is awarded at the beginning of
 each three-year performance period. The number of shares of common
 stock released at the end of the performance period may range from
 zero to 2.4 times the target number depending on performance during
 the period. The performance metrics of the PRU program are based on
 (a) annual financial targets, which are based on revenue and
 EBITDA (earnings before interest, tax, depreciation, and
 amortization expense), each equally weighted, and (b) an
 overall modifier based on the Company’s total stockholder
 return (TSR) relative to a group of peer companies selected by the
 Company’s compensation committee, over the three-year
 performance period.

[0001193125-17-055058:notes:24]
Under the PRU
 program, financial goals are set at the beginning of each fiscal
 year and performance is reviewed at the end of that year. The
 percentage to be applied to each participant’s target award
 ranges from zero to 160% based upon the extent to which the annual
 financial performance goals are achieved. If specific performance
 threshold levels for the annual financial goals are met, the amount
 earned for that element will be applied to one-third of the participants’ PRU
 award to determine the number of units earned.

[0001193125-17-055058:notes:25]
At the end of
 the three-year performance period, the total units earned, if any,
 are adjusted by applying a modifier, ranging from zero to 150%
 based on the Company’s TSR based on stock price changes
 relative to a group of peer companies selected by the
 Company’s compensation committee for the same three-year
 period.

[0001193125-17-055058:notes:26]
The TSR
 modifier is intended to ensure that there are limited or no payouts
 under the PRU program if the Company’s stock performance is
 significantly below the median TSR of a group of peer companies
 selected by the Company’s compensation committee over the
 three-year performance period. Where the annual financial goals
 have been met and where there has been strong relative TSR
 performance over the three-year performance period, the PRU program
 may provide substantial rewards to participants with a maximum
 payout of 2.4 times the initial PRU award. However, even if all of
 the annual financial metric goals are achieved in each of the three
 years, there will be no payouts if the Company’s stock
 performance is below that of the 10th percentile for PRUs granted
 in 2016, and 20th percentile for PRUs granted prior to 2016, of the
 group of peer companies selected by the Company’s
 compensation committee, as appropriate.

[0001193125-17-055058:notes:27]
Recipients of
 PRU awards generally must remain employed by the Company on a
 continuous basis through the end of the three-year performance
 period in order to receive any amount of the PRUs covered by that
 award. In events such as death, disability or retirement, the
 recipient may be entitled to pro-rata amounts of PRUs as defined in
 the Plan. Target shares subject to PRU awards do not have voting
 rights of common stock until earned and issued following the end of
 the three-year performance period.

[0001193125-17-055058:notes:28]
The Company
 records stock-based compensation expense for PRU awards granted
 based on management’s periodic assessment of the probability
 of the PRU awards vesting. As of January 2, 2017, management
 determined that vesting of the PRU awards was probable. PRU
 activity for the year ended January 2, 2017 was as
 follows:

[0001193125-17-055058:notes:29]
|  |  | Shares |  |  | Weighted Average Fair Value |  |
|  |  | (In thousands) |  |  |  |  |
| Outstanding target shares at December 28, 2015 |  |  | 301 |  |  | $ | 8.58 |  |
| Granted |  |  | 346 |  |  |  | 6.46 |  |
| Vested |  |  | (291 | ) |  |  | 6.01 |  |
| Change in units due to annual performance achievement |  |  | 50 |  |  |  | 6.08 |  |
| Outstanding target shares at January 2, 2017 |  |  | 406 |  |  | $ | 8.31 |  |

[0001193125-17-055058:notes:30]
The fair
 value of PRUs granted is calculated using a Monte Carlo simulation
 model, as the TSR modifier contains a market condition. For the
 years ended January 2, 2017, December 28, 2015 and
 December 29, 2014, the following assumptions were used in
 determining the fair value:

[0001193125-17-055058:notes:31]
|  |  | For the Year Ended |  |
|  |  | January 2, 2017(1) |  |  | December 28, 2015(2) |  |  | December 29, 2014(3) |  |
| Weighted-average fair value |  | $ | 6.46 |  |  | $ | 7.22 |  |  | $ | 5.80 |  |
| Risk-free interest rate |  |  | 0.8 | % |  |  | 0.5 | % |  |  | 0.4 | % |
| Dividend yield |  |  | — |  |  |  | — |  |  |  | — |  |
| Expected volatility |  |  | 40 | % |  |  | 37 | % |  |  | 41 | % |
| Expected term in months |  |  | 24 |  |  |  | 22 |  |  |  | 23 |  |

[0001193125-17-055058:notes:32]
| (1) | Reflects the weighted-averages for the third year of the three-year performance period applicable to PRUs granted in 2014, the second year of the three-year performance period applicable to PRUs granted in 2015 and the first year of the three-year performance period applicable to PRUs granted in 2016. |

[0001193125-17-055058:notes:33]
| (2) | Reflects the weighted-averages for the third year of the three-year performance period applicable to PRUs granted in 2013, the second year of the three-year performance period applicable to PRUs granted in 2014 and the first year of the three-year performance period applicable to PRUs granted in 2015. |

[0001193125-17-055058:notes:34]
| (3) | Reflects the weighted-averages for the third year of the three-year performance period applicable to PRUs granted in 2012, second year of the three-year performance period applicable to PRUs granted in 2013 and for the first year of the three-year performance period applicable to PRUs granted in 2014. |

[0001193125-17-055058:notes:35]
The expected
 term of the PRUs reflects the performance period for the PRUs
 granted. Expected volatility is calculated using the
 Company’s historical stock price. The risk-free interest rate
 for the expected term of PRUs is based on the U.S Treasury yield
 curve in effect at the time of grant.

[0001193125-17-055058:notes:36]
Restricted Stock Units

[0001193125-17-055058:notes:37]
RSU activity
 for the year ended January 2, 2017 was as follows:

[0001193125-17-055058:notes:38]
|  |  | Shares |  |  | Weighted Average Grant-Date Fair Value |  |
|  |  | (In thousands) |  |  |  |  |
| Non-vested RSUs outstanding at December 28, 2015 |  |  | 1,975 |  |  | $ | 8.77 |  |
| Granted |  |  | 1,827 |  |  |  | 6.78 |  |
| Vested |  |  | (906 | ) |  |  | 8.65 |  |
| Forfeited |  |  | (188 | ) |  |  | 8.59 |  |
| Non-vested RSUs outstanding at January 2, 2017 |  |  | 2,708 |  |  | $ | 7.48 |  |
| Vested and expected to vest at January 2, 2017 |  |  | 2,980 |  |  | $ | 7.79 |  |

[0001193125-17-055058:notes:39]
The fair
 value of the Company’s RSUs is determined based upon the
 closing common stock price on the grant date. The weighted average
 fair value per unit of RSUs granted was $6.78, $9.15 and $7.98 for
 the years ended January 2, 2017, December 28, 2015 and
 December 29, 2014, respectively. The total fair value of RSUs
 vested for the years ended January 2, 2017, December 28,
 2015 and December 29, 2014 was $7,834, $6,396 and $7,195,
 respectively.

[0001193125-17-055058:notes:40]
Stock
 Options

[0001193125-17-055058:notes:41]
During the
 year ended January 2, 2017, the Company granted 20 stock
 options to a newly appointed member of the board which were
 estimated to have a fair value per share of $6.78. No stock options
 were granted by the Company for the years ended December 28,
 2015 or December 29, 2014. The fair value calculation is based
 on stock options granted during the period using the Black-Scholes
 option-pricing model on the date of grant. For the year ended
 January 2, 2017 the fair value was determined using 1.7% as
 the risk-free interest rate, 51% as the expected volatility, 8.5
 years as the expected term and no dividend yield.

[0001193125-17-055058:notes:42]
The Company
 determines the expected term of its stock option awards by periodic
 review of its historical stock option exercise experience. This
 calculation considers pre-vesting forfeitures and uses assumed
 future exercise patterns to account for option holders’
 expected exercise and post-vesting termination behavior for
 outstanding stock options over their remaining contractual terms.
 Expected volatility is calculated by weighting the Company’s
 historical stock price to calculate expected volatility over the
 expected term of each grant. The risk-free interest rate for the
 expected term of each option granted is based on the
 U.S. Treasury yield curve in effect at the time of grant with
 a period that approximates the expected term of the
 options.

[0001193125-17-055058:notes:43]
Option
 activity under the Plan for the year ended January 2, 2017 was
 as follows:

[0001193125-17-055058:notes:44]
|  |  | Options |  |  | Weighted- Average Exercise Price |  |  | Weighted- Average Remaining Contractual Term |  |  | Aggregate Intrinsic Value |  |
|  |  | (In thousands) |  |  |  |  |  | (In years) |  |  | (In thousands) |  |
| Outstanding at December 28, 2015 |  |  | 420 |  |  | $ | 12.37 |  |  |  | 1.7 |  |  | $ | 4 |  |
| Granted |  |  | 20 |  |  |  | 11.83 |  |  |  |  |  |  |  |  |  |
| Exercised |  |  | (159 | ) |  |  | 10.97 |  |  |  |  |  |  |  |  |  |
| Forfeited/expired |  |  | (194 | ) |  |  | 14.08 |  |  |  |  |  |  |  |  |  |
| Outstanding at January 2, 2017 |  |  | 87 |  |  | $ | 10.99 |  |  |  | 5.0 |  |  | $ | 228 |  |
| Vested and expected to vest at January 2, 2017 |  |  | 87 |  |  | $ | 10.99 |  |  |  | 5.0 |  |  | $ | 228 |  |
| Exercisable at January 2, 2017 |  |  | 67 |  |  | $ | 10.74 |  |  |  | 3.5 |  |  | $ | 192 |  |

[0001193125-17-055058:notes:45]
The aggregate
 intrinsic values in the table above represent the total pretax
 intrinsic value (the difference between Company’s closing
 stock price on the last trading day of the 2016 fiscal year and the
 exercise price, multiplied by the number of in-the-money options) that would have been
 received by the option holders had all option holders exercised
 their options on January 2, 2017. This amount changes based on
 the fair market value of the Company’s stock. The total
 intrinsic value of options exercised for the years ended
 January 2, 2017 and December 28, 2015 was $127 and $131,
 respectively. There were no options exercised for the year ended
 December 29, 2014. There were no options vested for the years
 ended January 2, 2017 and December 28, 2015. The total
 fair value of the options vested for the year ended
 December 29, 2014 was $110.

[0001193125-17-055058:notes:46]
Stock-based Compensation Expense and Unrecognized
 Compensation Costs

[0001193125-17-055058:notes:47]
For the years
 ended January 2, 2017, December 28, 2015 and
 December 29, 2014, the amounts recognized in the consolidated
 financial statements with respect to the stock-based compensation
 plan are as follows:

[0001193125-17-055058:notes:48]
|  |  | For the Year Ended |  |
|  |  | January 2, 2017 |  |  | December 28, 2015 |  |  | December 29, 2014 |  |
|  |  | (In thousands) |  |
| Cost of goods sold |  | $ | 1,630 |  |  | $ | 1,117 |  |  | $ | 866 |  |
| Selling and marketing |  |  | 1,054 |  |  |  | 1,135 |  |  |  | 1,109 |  |
| General and administrative |  |  | 8,406 |  |  |  | 7,409 |  |  |  | 5,825 |  |
| Stock-based compensation expense recognized |  |  | 11,090 |  |  |  | 9,661 |  |  |  | 7,800 |  |
| Income tax benefit recognized |  |  | — |  |  |  | — |  |  |  | (2,018 | ) |
| Stock-based compensation expense recognized |  | $ | 11,090 |  |  | $ | 9,661 |  |  | $ | 5,782 |  |

[0001193125-17-055058:notes:49]
The Company
 may become entitled to a deduction in its tax returns upon the
 future exercise of incentive stock options under certain
 circumstances; however, the value of this deduction will be
 recorded as an increase to additional paid-in capital and not as an income
 tax benefit. For the years ended December 28, 2015 and
 December 29, 2014, a net tax shortfall of $247 and $1,015,
 respectively, related to fully vested stock option awards exercised
 and vested RSUs was recorded as a decrease to
 additionalpaid-in capital.
 For the year ended January 2, 2017, the Company did not
 record a net tax shortfall. Additionally, for the year ended
 January 2, 2017 and December 28, 2015, the Company did
 not record an income tax benefit as a result of a full valuation
 allowance on its deferred tax assets.

[0001193125-17-055058:notes:50]
The following
 is a summary of total unrecognized compensation costs as of
 January 2, 2017:

[0001193125-17-055058:notes:51]
|  |  | Unrecognized Stock-Based Compensation Cost |  |  | Remaining Weighted Average Recognition Period |  |
|  |  | (In thousands) |  |  | (In years) |  |
| RSU awards |  | $ | 11,822 |  |  |  | 1.3 |  |
| PRU awards |  |  | 1,631 |  |  |  | 1.5 |  |
| Stock options |  |  | 114 |  |  |  | 2.4 |  |
|  |  | $ | 13,567 |  |  |  |  |  |


## us-gaap:EarningsPerSharePolicyTextBlock

[0001193125-17-055058:notes:52]
Earnings
 Per Share

[0001193125-17-055058:notes:53]
Basic earnings
 per common share excludes dilution and is computed by dividing net
 income attributable to TTM Technologies, Inc. stockholders by the
 weighted average number of common shares outstanding during the
 period. Diluted earnings per common share reflect the potential
 dilution that could occur if stock options, convertible senior
 notes or other common stock equivalents were exercised or converted
 into common stock. The dilutive effect of stock options or other
 common stock equivalents is calculated using the treasury stock
 method, while the dilutive effect of convertible senior notes is
 calculated using the if-converted method.


## us-gaap:InventoryPolicyTextBlock

[0001193125-17-055058:notes:54]
Inventories

[0001193125-17-055058:notes:55]
Inventories are
 stated at the lower of cost (determined on a first-in, first-out and weighted average basis)
 or market. Assessments to value the inventory at the lower of the
 actual cost to purchase and / or manufacture the inventory, or the
 current estimated market value of the inventory, are based upon
 assumptions about future demand and market conditions. As a result
 of the Company’s assessments, when the market value of
 inventory is less than the carrying value, the inventory cost is
 written down to the market value and the write down is recorded as
 a charge to cost of goods sold.


## us-gaap:NewAccountingPronouncementsPolicyPolicyTextBlock

[0001193125-17-055058:notes:56]
Recently Adopted and Issued Accounting
 Standards

[0001193125-17-055058:notes:57]
In October
 2016, the Financial Accounting Standards Board (FASB) issued
 Accounting Standards Update (ASU) 2016-16, Income Taxes (Topic 740):
 Intra-Entity Transfers of Assets Other Than Inventory. The objective of this
 update is to improve the accounting for the income tax consequences
 of intra-entity transfers of assets other than inventory by
 recognizing the income tax consequences when the transfer occurs.
 This ASU is effective for fiscal years beginning after
 December 15, 2017, including interim periods within those
 fiscal years. Early adoption is permitted. The Company is currently
 evaluating the new guidance to determine the impact it may have on
 its consolidated financial statements.

[0001193125-17-055058:notes:58]
In August
 2016, the FASB issued ASU 2016-15, Statement of Cash Flows
 (Topic 230). The objective of this update is to add or clarify
 guidance on the classification of certain cash receipts and
 payments in the statement of cash flows. This ASU is effective for
 fiscal years beginning after December 15, 2017, including
 interim periods within those annual periods and is to be applied
 utilizing a retrospective approach. Early adoption is permitted.
 The Company is currently evaluating the new guidance to determine
 the impact it may have on its consolidated financial statements and
 related disclosures.

[0001193125-17-055058:notes:59]
In March
 2016, the FASB issued Accounting Standards Update (ASU) 2016-09, Stock Compensation (Topic
 718): Improvements to Employee Share-Based Payment Accounting.
 The objective of this update is to simplify several aspects of the
 accounting for employee share-based payment transactions, including
 the income tax consequences, classification of awards as either
 equity or liabilities, and classification on the statement of cash
 flows. This ASU is effective for fiscal years beginning after
 December 15, 2016, including interim periods within those
 fiscal years. Early adoption is permitted. The impact on the
 Company’s consolidated financial statements is not expected
 to be material.

[0001193125-17-055058:notes:60]
In February
 2016, the FASB issued ASU 2016-02, Leases (Topic 842). The
 objective of this update is to increase transparency and
 comparability among organizations by recognizing lease assets and
 lease liabilities on the balance sheet and disclosing key
 information about leasing arrangements. This ASU is effective for
 fiscal years beginning after December 15, 2018, including
 interim periods within those annual periods and is to be applied
 utilizing a modified retrospective approach. The Company is
 currently evaluating the new guidance to determine the impact it
 may have on its consolidated financial statements and related
 disclosures.

[0001193125-17-055058:notes:61]
In April
 2015, the FASB issued ASU 2015-03, Imputation of Interest,
 as amended, which requires an entity to record debt issuance costs
 related to debt reported in the balance sheet as a direct deduction
 from the face amount of that debt. The update is effective for
 annual periods ending after December 15, 2015. The standard
 requires the use of the retrospective transition method. The
 Company adopted the new standard in the first quarter of 2016.
 Accordingly, as of January 2, 2017, approximately $4,724 of
 unamortized debt issuance costs were presented as a reduction of
 long-term debt on the Company’s consolidated balance sheets.
 Furthermore, the Company reclassified approximately $31,171 of
 unamortized debt issuance costs that had been presented as
 other non-current assets as of December 28,
 2015 as a reduction of long-term debt.

[0001193125-17-055058:notes:62]
In May 2014,
 the FASB issued ASU 2014-09, Revenue from Contracts with
 Customers, as amended, which requires an entity to recognize
 the amount of revenue to which it expects to be entitled for the
 transfer of promised goods or services to customers. The ASU will
 replace most existing revenue recognition guidance in U.S. GAAP
 when it becomes effective. The new standard is effective for the
 Company at the beginning of fiscal year 2018, however application
 of the standard is allowed as early as the beginning of fiscal
 2017. The standard permits the use of either the retrospective or
 cumulative effect transition method. The Company has assessed that
 the impact of the new guidance will result in a change to the
 timing of revenue recognition for the Company’s revenue
 stream from “point in time” upon physical delivery to
 an “over time” model and believes this transition could
 have a material impact on the Company’s consolidated
 financial statements upon adoption. As of January 2, 2017,
 management intends to apply the cumulative effect transition
 method. The Company has identified and is in the process of
 implementing changes to its systems, processes and internal
 controls to meet the standard update’s reporting and
 disclosure requirements.


## us-gaap:ReclassificationOutOfAccumulatedOtherComprehensiveIncomeTableTextBlock

[0001193125-17-055058:notes:63]
The following
 provides a summary of reclassifications out of accumulated other
 comprehensive income, net of tax for the years ended
 January 2, 2017, December 28, 2015 and December 29,
 2014:

[0001193125-17-055058:notes:64]
|  |  |  |  | Amount Reclassified from Accumulated Other Comprehensive Income For the Year Ended |  |
| Details about Accumulated Other Comprehensive Income Components |  | Statement of Operations Location |  | January 2, 2017 |  |  | December 28, 2015 |  |  | December 29, 2014 |  |
| Loss on foreign currency forwards cash flow hedges |  | Depreciation expense, net of tax |  | $ | 175 |  |  | $ | 172 |  |  | $ | 146 |  |
| Gain on foreign currency translation |  | Gain on sale of assets, net of tax |  | $ | — |  |  | $ | (1,786 | ) |  | $ | — |  |
| Loss on available for sale securities |  | Other, net, net of tax |  | $ | — |  |  | $ | — |  |  | $ | 83 |  |


## us-gaap:ReconciliationOfOperatingProfitLossFromSegmentsToConsolidatedTextBlock

[0001193125-17-055058:notes:65]
The Company
 accounts for inter-segment sales and transfers consistent with the
 Company’s revenue recognition policy. The inter-segment sales
 for the year ended January 2, 2017 are sales primarily from
 the PCB to the E-M Solutions operating
 segment.

[0001193125-17-055058:notes:66]
|  |  | For the Year Ended |  |
|  |  | January 2, 2017 |  |  | December 28, 2015 |  |  | December 29, 2014 |  |
|  |  | (In thousands) |  |
| Net Sales: |  |  |  |  |  |  |  |  |  |  |  |  |
| PCB |  | $ | 2,346,554 |  |  | $ | 1,944,041 |  |  | $ | 1,251,665 |  |
| E-M Solutions |  |  | 198,483 |  |  |  | 158,655 |  |  |  | 76,545 |  |
| Total sales |  |  | 2,545,037 |  |  |  | 2,102,696 |  |  |  | 1,328,210 |  |
| Inter-segment sales |  |  | (11,678 | ) |  |  | (7,208 | ) |  |  | (2,493 | ) |
| Total net sales |  | $ | 2,533,359 |  |  | $ | 2,095,488 |  |  | $ | 1,325,717 |  |
| Operating Segment Income (Loss): |  |  |  |  |  |  |  |  |  |  |  |  |
| PCB |  | $ | 285,046 |  |  | $ | 172,227 |  |  | $ | 77,092 |  |
| E-M Solutions |  |  | 4,684 |  |  |  | 1,424 |  |  |  | 3,855 |  |
| Corporate |  |  | (92,025 | ) |  |  | (93,421 | ) |  |  | (26,021 | ) |
| Total operating segment income |  |  | 197,705 |  |  |  | 80,230 |  |  |  | 54,926 |  |
| Amortization of definite-lived intangibles |  |  | (24,252 | ) |  |  | (18,888 | ) |  |  | (8,387 | ) |
| Total operating income |  |  | 173,453 |  |  |  | 61,342 |  |  |  | 46,539 |  |
| Total other expense |  |  | (106,451 | ) |  |  | (52,366 | ) |  |  | (24,248 | ) |
| Income before income taxes |  | $ | 67,002 |  |  | $ | 8,976 |  |  | $ | 22,291 |  |

[0001193125-17-055058:notes:67]
|  |  | For the Year Ended |  |
|  |  | January 2, 2017 |  |  | December 28, 2015 |  |  | December 29, 2014 |  |
|  |  | (In thousands) |  |
| Depreciation Expense: |  |  |  |  |  |  |  |  |  |  |  |  |
| PCB |  | $ | 149,466 |  |  | $ | 130,339 |  |  | $ | 95,027 |  |
| E-M Solutions |  |  | 2,540 |  |  |  | 2,079 |  |  |  | 183 |  |
| Corporate |  |  | 4,223 |  |  |  | 1,090 |  |  |  | 139 |  |
| Total depreciation expense |  | $ | 156,229 |  |  | $ | 133,508 |  |  | $ | 95,349 |  |
| Capital Expenditures: |  |  |  |  |  |  |  |  |  |  |  |  |
| PCB |  | $ | 74,318 |  |  | $ | 72,036 |  |  | $ | 73,779 |  |
| E-M Solutions |  |  | 3,206 |  |  |  | 4,006 |  |  |  | 400 |  |
| Corporate |  |  | 5,873 |  |  |  | 1,523 |  |  |  | 2,603 |  |
| Total capital expenditures |  | $ | 83,397 |  |  | $ | 77,565 |  |  | $ | 76,782 |  |


## us-gaap:RestructuringImpairmentAndOtherActivitiesDisclosureTextBlock

[0001193125-17-055058:notes:68]
| (4) | Restructuring and Impairment Charges |

[0001193125-17-055058:notes:69]
Consolidation Plan and Restructuring
 Activities

[0001193125-17-055058:notes:70]
On
 September 29, 2015, the Company announced a consolidation plan
 that resulted in the closure of the Company’s facilities in
 Cleveland, Ohio, Milpitas, California and Juarez, Mexico (the
 Consolidation Plan) and laid off approximately 480 employees at
 these sites. The Consolidation Plan was part of the Company’s
 integration strategy to improve total plant utilization,
 operational performance and customer focus following its
 acquisition of Viasystems. In accordance with the Consolidation
 Plan, the Company has combined its Cleveland and Milpitas
 facilities into its North Jackson, Ohio and Silicon Valley,
 California facilities, respectively, and closed its Juarez, Mexico
 facility.

[0001193125-17-055058:notes:71]
In connection
 with the Consolidation Plan and other global realignment
 restructuring efforts, the Company recognized employee separation
 costs and contract termination and other costs during the years
 ended January 2, 2017 and December 28,
 2015. Contract termination and other costs primarily
 represented plant closure costs for Cleveland, Ohio, Milpitas,
 California and Juarez, Mexico, as well as costs related to building
 operating leases associated with the downsizing of the St. Louis,
 Missouri office.

[0001193125-17-055058:notes:72]
The below
 table summarizes such restructuring costs by operating segment for
 the years ended January 2, 2017 and December 28,
 2015:

[0001193125-17-055058:notes:73]
|  |  | For the Year Ended January 2, 2017 |  |  | For the Year Ended December 28, 2015 |  |
|  |  | Employee separation/ severance |  |  | Contract termination and other costs |  |  | Total |  |  | Employee separation/ severance |  |  | Contract termination and other costs |  |  | Total |  |
|  |  | (In thousands) |  |
| Operating Segment: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| PCB |  | $ | 1,548 |  |  | $ | 2,141 |  |  | $ | 3,689 |  |  | $ | 2,050 |  |  | $ | — |  |  | $ | 2,050 |  |
| E-M Solutions |  |  | 903 |  |  |  | 3,644 |  |  |  | 4,547 |  |  |  | 2,039 |  |  |  | — |  |  |  | 2,039 |  |
| Corporate |  |  | (231 | ) |  |  | 946 |  |  |  | 715 |  |  |  | 2,743 |  |  |  | 549 |  |  |  | 3,292 |  |
|  |  | $ | 2,220 |  |  | $ | 6,731 |  |  | $ | 8,951 |  |  | $ | 6,832 |  |  | $ | 549 |  |  | $ | 7,381 |  |

[0001193125-17-055058:notes:74]
The below
 table shows the utilization of the accrued restructuring costs
 during the years ended January 2, 2017 and December 28,
 2015:

[0001193125-17-055058:notes:75]
|  |  | Severance |  |  | Contract Termination |  |  | Total |  |
|  |  | (In thousands) |  |
| Accrued at December 29, 2014 |  | $ | — |  |  | $ | — |  |  | $ | — |  |
| Charged to expense |  |  | 6,832 |  |  |  | 549 |  |  |  | 7,381 |  |
| Amount paid |  |  | (788 | ) |  |  | (14 | ) |  |  | (802 | ) |
| Accrued at December 28, 2015 |  | $ | 6,044 |  |  | $ | 535 |  |  | $ | 6,579 |  |
| Charged to expense |  |  | 2,495 |  |  |  | 6,698 |  |  |  | 9,193 |  |
| Adjustments to estimate |  |  | (275 | ) |  |  | 33 |  |  |  | (242 | ) |
| Amount paid |  |  | (8,140 | ) |  |  | (6,224 | ) |  |  | (14,364 | ) |
| Accrued at January 2, 2017 |  | $ | 124 |  |  | $ | 1,042 |  |  | $ | 1,166 |  |

[0001193125-17-055058:notes:76]
As of
 January 2, 2017, the Company has incurred approximately
 $16,332 of restructuring charges since the September 29, 2015
 announcement. The company estimates that it will incur total
 charges related to the Consolidation Plan of approximately
 $20,000.

[0001193125-17-055058:notes:77]
Additionally,
 the Company recognized $3,346 in impairment charges during the year
 ended January 2, 2017. As a result of the above mentioned
 plant closures and other plant realignment efforts, $1,393 of
 impairment charges were recognized in the consolidated statement of
 operations related to machinery and equipment in the PCB operating
 segment. In addition, $1,953 of impairment charges were recognized
 in the consolidated statement of operations related to capitalized
 software costs in the Corporate operating segment.

[0001193125-17-055058:notes:78]
For the year
 ended December 28, 2015, the Company recorded other exit costs
 of $878 related to inventory write-downs associated with the
 consolidation of the Milpitas facility to other Silicon Valley,
 California facilities. These costs have been recorded as a
 component of cost of goods sold in the consolidated statement of
 operations.

[0001193125-17-055058:notes:79]
Impairment
 and Sale of Suzhou, China Manufacturing Facility

[0001193125-17-055058:notes:80]
The Company
 ceased manufacturing at its Meadville Aspocomp (Suzhou) Electronic
 Co., Ltd. subsidiary, which held its Suzhou, China manufacturing
 facility, and shut down its operations in 2013. As a result, the
 Company determined that certain long-lived assets were impaired and
 as such, recorded charges of $1,845 for the year ended
 December 29, 2014 primarily related to machinery and equipment
 held for sale.

[0001193125-17-055058:notes:81]
During the
 year ended December 28, 2015, the Company sold its Meadville
 Aspocomp (Suzhou) Electronic Co., Ltd. subsidiary for $21,275 and
 recognized a gain of $2,504. The Suzhou, China manufacturing
 facility is included in the PCB operating segment.


## us-gaap:ScheduleOfAccumulatedOtherComprehensiveIncomeLossTableTextBlock

[0001193125-17-055058:notes:82]
The following
 provides a summary of the components of accumulated other
 comprehensive income (loss), net of tax as of January 2,
 2017, December 28, 2015 and December 29, 2014:

[0001193125-17-055058:notes:83]
|  |  | Foreign Currency Translation |  |  | Gains (Losses) on Cash Flow Hedges |  |  | Total |  |
|  |  | (In thousands) |  |
| Ending balance at December 29, 2014 |  | $ | 32,439 |  |  | $ | (1,424 | ) |  | $ | 31,015 |  |
| Other comprehensive loss before reclassifications |  |  | (27,758 | ) |  |  | (20 | ) |  |  | (27,778 | ) |
| Amounts reclassified from accumulated other comprehensive income |  |  | (1,786 | ) |  |  | 172 |  |  |  | (1,614 | ) |
| Net year to date period other comprehensive income (loss) |  |  | (29,544 | ) |  |  | 152 |  |  |  | (29,392 | ) |
| Ending balance at December 28, 2015 |  |  | 2,895 |  |  |  | (1,272 | ) |  |  | 1,623 |  |
| Other comprehensive loss before reclassifications |  |  | (46,044 | ) |  |  | (83 | ) |  |  | (46,127 | ) |
| Amounts reclassified from accumulated other comprehensive income |  |  | — |  |  |  | 175 |  |  |  | 175 |  |
| Net year to date period other comprehensive income (loss) |  |  | (46,044 | ) |  |  | 92 |  |  |  | (45,952 | ) |
| Ending balance at January 2, 2017 |  | $ | (43,149 | ) |  | $ | (1,180 | ) |  | $ | (44,329 | ) |


## us-gaap:ScheduleOfAntidilutiveSecuritiesExcludedFromComputationOfEarningsPerShareTextBlock

[0001193125-17-055058:notes:84]
The below is a
 summary of amounts convertible to common stock related to
 convertible senior notes and related warrants:

[0001193125-17-055058:notes:85]
|  |  | For the Year Ended |  |
|  |  | January 2, 2017 |  |  | December 28, 2015 |  |  | December 29, 2014 |  |
|  |  | (In thousands) |  |
| Common stock related to convertible senior notes |  |  | 25,940 |  |  |  | 25,940 |  |  |  | 27,970 |  |
| Warrants to purchase common stock |  |  | 25,940 |  |  |  | 26,408 |  |  |  | 28,020 |  |


## us-gaap:ScheduleOfBusinessAcquisitionsByAcquisitionTextBlock

[0001193125-17-055058:notes:86]
The following
 summarizes the components of the purchase price:

[0001193125-17-055058:notes:87]
|  |  | (In thousands) |  |
| Value of TTM common stock issued |  | $ | 149,006 |  |
| Cash consideration |  |  | 248,824 |  |
|  |  |  | 397,830 |  |
| Debt assumed |  |  | 669,024 |  |
| Enterprise value |  | $ | 1,066,854 |  |


## us-gaap:ScheduleOfComponentsOfIncomeTaxExpenseBenefitTableTextBlock

[0001193125-17-055058:notes:88]
The components
 of income tax provision for the years ended January 2,
 2017, December 28, 2015 and December 29, 2014
 are:

[0001193125-17-055058:notes:89]
|  |  | For the Year Ended |  |
|  |  | January 2, 2017 |  |  | December 28, 2015 |  |  | December 29, 2014 |  |
|  |  | (In thousands) |  |
| Current (provision) benefit: |  |  |  |  |  |  |  |  |  |  |  |  |
| Federal |  | $ | (342 | ) |  | $ | 477 |  |  | $ | 1,717 |  |
| State |  |  | (512 | ) |  |  | (345 | ) |  |  | (216 | ) |
| Foreign |  |  | (29,672 | ) |  |  | (19,379 | ) |  |  | (5,385 | ) |
| Total current |  |  | (30,526 | ) |  |  | (19,247 | ) |  |  | (3,884 | ) |
| Deferred (provision) benefit: |  |  |  |  |  |  |  |  |  |  |  |  |
| Federal |  |  | 715 |  |  |  | (10,084 | ) |  |  | (829 | ) |
| State |  |  | — |  |  |  | (2,184 | ) |  |  | 133 |  |
| Foreign |  |  | (1,616 | ) |  |  | (3,079 | ) |  |  | (3,018 | ) |
| Total deferred |  |  | (901 | ) |  |  | (15,347 | ) |  |  | (3,714 | ) |
| Total provision |  | $ | (31,427 | ) |  | $ | (34,594 | ) |  | $ | (7,598 | ) |


## us-gaap:ScheduleOfDebtInstrumentsTextBlock

[0001193125-17-055058:notes:90]
The following
 table summarizes the long-term debt of the Company as of
 January 2, 2017 and December 28, 2015:

[0001193125-17-055058:notes:91]
|  |  | Average Effective Interest Rate as of January 2, 2017 |  |  | January 2, 2017 |  |  | Average Effective Interest Rate as of December 28, 2015 |  |  | December 28, 2015 |  |
|  |  | (In thousands) |  |
| Term loan due May 2021 |  |  | 5.25 | % |  | $ | 700,000 |  |  |  | — |  |  |  | — |  |
| Term loan due May 2021 |  |  | — |  |  |  | — |  |  |  | 6.00 | % |  | $ | 947,625 |  |
| U.S. ABL revolving loan due May 2020 |  |  | 2.27 | % |  |  | 80,000 |  |  |  | 2.17 | % |  |  | 80,000 |  |
| Asia ABL revolving loan due May 2020 |  |  | 2.17 | % |  |  | 30,000 |  |  |  | — |  |  |  | — |  |
| Convertible Senior Notes due December 2020 |  |  | 1.75 | % |  |  | 250,000 |  |  |  | 1.75 | % |  |  | 250,000 |  |
| Capital lease |  |  | 6.43 | % |  |  | 1,798 |  |  |  | — |  |  |  | — |  |
|  |  |  |  |  |  |  | 1,061,798 |  |  |  |  |  |  |  | 1,277,625 |  |
| Less: Long-term debt unamortized discount |  |  |  |  |  |  | (37,392 | ) |  |  |  |  |  |  | (75,668 | ) |
| Long-term debt unamortized debt issuance costs |  |  |  |  |  |  | (4,724 | ) |  |  |  |  |  |  | (31,171 | ) |
|  |  |  |  |  |  |  | 1,019,682 |  |  |  |  |  |  |  | 1,170,786 |  |
| Less: current maturities |  |  |  |  |  |  | (110,652 | ) |  |  |  |  |  |  | (157,375 | ) |
| Long-term debt, less current maturities |  |  |  |  |  | $ | 909,030 |  |  |  |  |  |  | $ | 1,013,411 |  |


## us-gaap:ScheduleOfRevenuesFromExternalCustomersAndLongLivedAssetsByGeographicalAreasTableTextBlock

[0001193125-17-055058:notes:92]
Net sales and
 long-lived assets are as follows:

[0001193125-17-055058:notes:93]
|  |  | 2016 |  |  | 2015 |  |  | 2014 |  |
|  |  | Net Sales |  |  | Long-Lived Assets |  |  | Net Sales |  |  | Long-Lived Assets |  |  | Net Sales |  |  | Long-Lived Assets |  |
|  |  | (In thousands) |  |
| United States |  | $ | 1,119,086 |  |  | $ | 661,058 |  |  | $ | 960,146 |  |  | $ | 654,579 |  |  | $ | 568,796 |  |  | $ | 103,340 |  |
| China |  |  | 646,844 |  |  |  | 781,678 |  |  |  | 547,999 |  |  |  | 923,219 |  |  |  | 352,385 |  |  |  | 682,739 |  |
| Other |  |  | 767,429 |  |  |  | 23,124 |  |  |  | 587,343 |  |  |  | 23,133 |  |  |  | 404,536 |  |  |  | — |  |
| Total |  | $ | 2,533,359 |  |  | $ | 1,465,860 |  |  | $ | 2,095,488 |  |  | $ | 1,600,931 |  |  | $ | 1,325,717 |  |  | $ | 786,079 |  |


## us-gaap:SignificantAccountingPoliciesTextBlock

[0001193125-17-055058:notes:94]
| (2) | Summary of Significant Accounting Policies |

[0001193125-17-055058:notes:95]
Use of
 Estimates

[0001193125-17-055058:notes:96]
The
 preparation of financial statements in conformity with accounting
 principles generally accepted in the United States of America (U.S.
 GAAP) requires management to make estimates and assumptions that
 affect the reported amounts of assets and liabilities and
 disclosure of contingent assets and liabilities at the date of the
 financial statements and the reported amount of revenues and
 expenses during the reporting period. Such estimates include the
 sales return reserve; accounts receivable; inventories; goodwill;
 intangible assets and other long-lived assets; self insurance
 reserves; product warranty liabilities; environmental liabilities;
 legal contingencies; income taxes; and others. These estimates and
 assumptions are based on management’s best estimates and
 judgment. Management evaluates its estimates and assumptions on an
 ongoing basis using historical experience and other factors,
 including the economic environment, which management believes to be
 reasonable under the circumstances. Management adjusts such
 estimates and assumptions when facts and circumstances dictate. The
 actual results we experienced may differ materially and adversely
 from our estimates. To the extent there are material differences
 between the estimates and actual results, our future result of
 operations will be affected.

[0001193125-17-055058:notes:97]
Principles of Consolidation

[0001193125-17-055058:notes:98]
The
 consolidated financial statements include the accounts of TTM
 Technologies, Inc. and its subsidiaries. All intercompany accounts
 and transactions have been eliminated in consolidation.

[0001193125-17-055058:notes:99]
Foreign
 Currency Translation and Transactions

[0001193125-17-055058:notes:100]
The
 functional currency of certain of the Company’s subsidiaries
 is either the Chinese Renminbi (RMB) or the Hong Kong Dollar.
 Accordingly, assets and liabilities are translated into U.S.
 dollars using period-end exchange rates. Sales and
 expenses are translated at the average exchange rates in effect
 during the period. The resulting translation gains or losses are
 recorded as a component of accumulated other comprehensive income
 in the consolidated statement of stockholders’ equity and the
 consolidated statement of comprehensive income (loss). Net gains
 resulting from foreign currency remeasurements and transactions are
 included in income as a component of other, net in the consolidated
 statements of operations and totaled $13,538, $6,766, and $2,378
 for the years ended January 2, 2017, December 28, 2015
 and December 29, 2014, respectively.

[0001193125-17-055058:notes:101]
Accounts Receivable and Allowance for Doubtful
 Accounts

[0001193125-17-055058:notes:102]
Accounts
 receivable are reflected at estimated net realizable value, do not
 bear interest and do not generally require collateral. The Company
 performs credit evaluations of its customers and adjusts credit
 limits based upon payment history and the customer’s current
 creditworthiness. The Company maintains an allowance for doubtful
 accounts based upon a variety of factors. The Company reviews all
 open accounts and provides specific reserves for customer
 collection issues when it believes the loss is probable,
 considering such factors as the length of time receivables are past
 due, the financial condition of the customer, and historical
 experience. The Company also records a reserve for all customers,
 excluding those that have been specifically reserved for, based
 upon evaluation of historical losses.

[0001193125-17-055058:notes:103]
The following
 summarizes the activity in the Company’s allowance for
 doubtful accounts for the years ended January 2,
 2017, December 28, 2015 and December 29, 2014:

[0001193125-17-055058:notes:104]
|  |  | For the Year Ended |  |
|  |  | January 2, 2017 |  |  | December 28, 2015 |  |  | December 29, 2014 |  |
|  |  | (In thousands) |  |
| Balance at beginning of year |  | $ | 1,525 |  |  | $ | 696 |  |  | $ | 518 |  |
| Additions charged to expense |  |  | 1,560 |  |  |  | 854 |  |  |  | 214 |  |
| Deductions |  |  | (223 | ) |  |  | (26 | ) |  |  | (34 | ) |
| Effect of foreign currency exchange rates |  |  | (11 | ) |  |  | 1 |  |  |  | (2 | ) |
| Balance at end of year |  | $ | 2,851 |  |  | $ | 1,525 |  |  | $ | 696 |  |

[0001193125-17-055058:notes:105]
Inventories
 are stated at the lower of cost (determined on a first-in, first-out and weighted average basis) or
 market. Assessments to value the inventory at the lower of the
 actual cost to purchase and / or manufacture the inventory, or the
 current estimated market value of the inventory, are based upon
 assumptions about future demand and market conditions. As a result
 of the Company’s assessments, when the market value of
 inventory is less than the carrying value, the inventory cost is
 written down to the market value and the write down is recorded as
 a charge to cost of goods sold.

[0001193125-17-055058:notes:106]
Property, Plant and Equipment, Net

[0001193125-17-055058:notes:107]
Property,
 plant and equipment are recorded at cost. Depreciation expense is
 computed using the straight-line method over the estimated useful
 lives of the assets. Assets recorded under leasehold improvements
 are amortized using the straight-line method over the lesser of
 their useful lives or the related lease term. The Company uses the
 following estimated useful lives:

[0001193125-17-055058:notes:108]
| Land use rights |  | 50-99 years |
| Buildings and improvements |  | 7-50 years |
| Machinery and equipment |  | 3-12 years |
| Furniture and fixtures |  | 3-7 years |

[0001193125-17-055058:notes:109]
Upon
 retirement or other disposition of property, plant and equipment,
 the cost and related accumulated depreciation are removed from the
 accounts. The resulting gain or loss is included in the
 determination of operating income in the period incurred.
 Depreciation and amortization expense on property, plant and
 equipment was $156,229, $133,508, and $95,349 for the years ended
 January 2, 2017, December 28, 2015 and December 29,
 2014, respectively.

[0001193125-17-055058:notes:110]
The Company
 capitalizes interest on borrowings during the active construction
 period of major capital projects. Capitalized interest is amortized
 over the average useful lives of such assets, which primarily
 consist of buildings and machinery and equipment. The Company
 capitalized interest costs of $1,876, $888, and $551 during the
 years ended January 2, 2017, December 28, 2015 and
 December 29, 2014, respectively, in connection with various
 capital projects.

[0001193125-17-055058:notes:111]
Major
 renewals and betterments are capitalized and depreciated over their
 estimated useful lives while minor expenditures for maintenance and
 repairs are included in operating income as incurred.

[0001193125-17-055058:notes:112]
Goodwill

[0001193125-17-055058:notes:113]
Goodwill
 represents the excess of purchase price of an acquisition over the
 fair value of net assets acquired. Goodwill is not amortized but
 instead is assessed for impairment, at a reporting unit level,
 annually and when events and circumstances warrant an evaluation.
 In making this assessment, management relies on a number of
 factors, including expected future operating results, business
 plans, economic projections, anticipated future cash flows,
 business trends and market conditions.

[0001193125-17-055058:notes:114]
The Company
 has two reportable operating segments consisting of four reporting
 units. The Company evaluates its goodwill on an annual basis in the
 fourth quarter or more frequently if it believes indicators of
 impairment exist. The Company first assesses qualitative factors to
 determine whether it is more likely than not that the fair value of
 a reporting unit is less than its carrying amount. If the Company
 concludes that it is more likely than not that the fair value of a
 reporting units is less than its carrying amount, it conducts
 a two-step quantitative goodwill
 impairment test. The first step of the impairment test involves
 comparing the fair values of the applicable reporting units with
 their carrying values. The Company estimates the fair values of its
 reporting units using a combination of the income and market
 approach. If the carrying amount of a reporting unit exceeds the
 reporting unit’s fair value, the Company performs the second
 step of the goodwill impairment test. The second step of the
 goodwill impairment test involves comparing the implied fair value
 of the affected reporting unit’s goodwill with the carrying
 value of that goodwill. The amount, by which the carrying value of
 the goodwill exceeds its implied fair value, if any, is recognized
 as an impairment loss. In the fourth quarter of 2016, the Company
 performed its annual impairment test qualitatively and concluded
 that goodwill was not impaired.

[0001193125-17-055058:notes:115]
Intangible Assets

[0001193125-17-055058:notes:116]
Intangible
 assets include customer relationships, technology and trade names,
 which are being amortized over their estimated useful lives using
 straight-line and accelerated methods. The estimated useful lives
 of such intangibles range from 3 years to 10 years.

[0001193125-17-055058:notes:117]
Impairment of Long-lived Assets

[0001193125-17-055058:notes:118]
Long-lived
 tangible assets, including property, plant and equipment, assets
 held for sale, and definite-lived intangible assets, are reviewed
 for impairment whenever events or changes in circumstances indicate
 that the carrying value of the asset or asset groups may not be
 recoverable. The Company regularly evaluates whether events or
 circumstances have occurred that indicate possible impairment and
 relies on a number of factors, including expected future operating
 results, business plans, economic projections, and anticipated
 future cash flows. The Company uses an estimate of the future
 undiscounted net cash flows of the related asset or asset group
 over the remaining life in measuring whether the assets are
 recoverable. Measurement of the amount of impairment, if any, is
 based upon the difference between the asset’s carrying value
 and estimated fair value. Fair value is determined through various
 valuation techniques, including cost-based, market and income
 approaches as considered necessary. See Note 4 for information
 regarding the impairment of long-lived assets during the years 2016
 and 2014.

[0001193125-17-055058:notes:119]
The Company
 classifies assets to be sold as assets held for sale when
 (i) Company management has approved and commits to a plan to
 sell the asset; (ii) the asset is available for immediate sale
 in its present condition and is ready for sale; (iii) an
 active program to locate a buyer and other actions required to sell
 the asset have been initiated; (iv) the sale of the asset is
 probable; (v) the asset is being actively marketed for sale at
 a price that is reasonable in relation to its current fair value;
 and (vi) it is unlikely that significant changes to the plan
 will be made or that the plan will be withdrawn. Assets classified
 as held for sale are recorded at the lower of the carrying amount
 or fair value less the cost to sell and are a component of prepaid
 expenses and other current assets in the consolidated balance
 sheet.

[0001193125-17-055058:notes:120]
The Company
 classifies assets held for use when a decision to dispose of an
 asset or a business is made and the held for sale criteria are not
 met. Assets of the business are evaluated for recoverability in the
 following order: (i) assets other than goodwill, property and
 intangibles; (ii) property and intangibles subject to
 amortization; and (iii) goodwill. In evaluating the
 recoverability of property and intangible assets subject to
 amortization, in a held for use business, the carrying value is
 first compared to the sum of the undiscounted cash flows expected
 to result from the use and eventual disposition. If the carrying
 value exceeds the undiscounted expected cash flows, then a fair
 value analysis is performed. An impairment charge is recognized if
 the carrying value exceeds the fair value.

[0001193125-17-055058:notes:121]
Revenue
 Recognition

[0001193125-17-055058:notes:122]
The Company
 derives its revenue primarily from the sale of PCBs using customer
 supplied engineering and design plans and recognizes revenue when:
 (i) persuasive evidence of a sales arrangement exists;
 (ii) the sales terms are fixed or determinable;
 (iii) title and risk of loss have transferred; and
 (iv) collectability is reasonably assured — generally
 when products are shipped to the customer, except in situations in
 which title passes upon receipt of the products by the customer. In
 this case, revenues are recognized upon notification that customer
 receipt has occurred. The Company does not have customer acceptance
 provisions, but it does provide its customers a limited right of
 return for defective PCBs. The Company accrues an estimated amount
 for sales returns and allowances related to defective PCBs at the
 time of sale based on its ability to estimate sales returns and
 allowances using current and historical information. The reserve
 for sales returns and allowances is included as a reduction to
 revenue and accounts receivable, net. Shipping and handling fees
 and related freight costs and supplies associated with shipping
 products to customers are included as a component of cost of goods
 sold. Incremental warranty costs that are not related to sales
 returns are recorded in accrued expenses and cost of goods
 sold.

[0001193125-17-055058:notes:123]
The following
 summarizes the activity in the Company’s allowance for sales
 returns and allowances for the years ended January 2,
 2017, December 28, 2015 and December 29, 2014:

[0001193125-17-055058:notes:124]
|  |  | For the Year Ended |  |
|  |  | January 2, 2017 |  |  | December 28, 2015 |  |  | December 29, 2014 |  |
|  |  | (In thousands) |  |
| Balance at beginning of year |  | $ | 7,789 |  |  | $ | 6,890 |  |  | $ | 6,028 |  |
| Additions charged to expense |  |  | 22,060 |  |  |  | 21,728 |  |  |  | 38,440 |  |
| Deductions |  |  | (21,728 | ) |  |  | (20,832 | ) |  |  | (37,578 | ) |
| Effect of foreign currency exchange rates |  |  | (2 | ) |  |  | 3 |  |  |  | — |  |
| Balance at end of year |  | $ | 8,119 |  |  | $ | 7,789 |  |  | $ | 6,890 |  |

[0001193125-17-055058:notes:125]
Stock-Based Compensation

[0001193125-17-055058:notes:126]
The Company
 recognizes stock-based compensation expense in its consolidated
 financial statements for its incentive compensation plan
 awards.

[0001193125-17-055058:notes:127]
The incentive
 compensation plan awards include performance-based restricted stock
 units, restricted stock units, and stock options and the associated
 compensation expense is based on the grant date fair value of the
 awards, net of estimated forfeitures, as well as an assessment of
 probability of the performance-based awards vesting. Compensation
 expense for the incentive compensation plan awards is recognized on
 a straight line basis over the vesting period of the awards. The
 fair value of performance-based restricted stock units is estimated
 on the grant date using a Monte Carlo simulation model based on the
 underlying common stock closing price as of the date of grant, the
 expected term, stock price volatility, and risk-free interest
 rates. The fair value of restricted stock units is measured on the
 grant date based on the quoted closing market price of the
 Company’s common stock. The fair value of the stock options
 is estimated on the grant date using the Black-Scholes option
 pricing model based on the underlying common stock closing price as
 of the date of grant, the expected term, stock price volatility,
 and risk-free interest rates.

[0001193125-17-055058:notes:128]
Income
 Taxes

[0001193125-17-055058:notes:129]
Income taxes
 are accounted for under the asset and liability method. Deferred
 income tax assets or liabilities are recognized for the future tax
 consequences attributable to differences between the financial
 statement carrying amounts of assets and liabilities and their
 respective tax bases and operating loss and tax credit
 carryforwards. Deferred income tax assets and liabilities are
 measured using enacted tax rates expected to apply to taxable
 income in the years in which those temporary differences are
 expected to be settled or realized. The effect on deferred income
 tax assets and liabilities of a change in tax rates is recognized
 in income in the period that includes the enactment date. Deferred
 income tax assets are reviewed for recoverability, and the Company
 records a valuation allowance to reduce its deferred income tax
 assets when it is more likely than not that all or some portion of
 the deferred income tax assets will not be realized.

[0001193125-17-055058:notes:130]
The Company
 has various foreign subsidiaries formed or acquired to conduct or
 support its business outside the United States. The Company does
 not provide for U.S. income taxes on undistributed earnings for
 certain foreign subsidiaries as management expects the foreign
 earnings will be indefinitely reinvested in such foreign
 jurisdictions. For certain subsidiaries within China, indefinite
 investment of undistributed earnings has not been asserted between
 the respective subsidiaries and their foreign parent entity and
 therefore, a deferred tax liability for the foreign tax impacts has
 been recorded on the undistributed earnings of these
 subsidiaries.

[0001193125-17-055058:notes:131]
The Company
 recognizes the effect of income tax positions only if those
 positions are more likely than not to be sustained. Recognized
 income tax positions are measured at the largest amount that is
 greater than 50 percent likely to be realized. Changes in
 recognition or measurement are reflected in the period in which the
 change in judgment occurs. Estimated interest and penalties related
 to underpayment of income taxes are recorded as a component of
 income tax provision in the consolidated statement of
 operations.

[0001193125-17-055058:notes:132]
Self
 Insurance

[0001193125-17-055058:notes:133]
The Company
 is primarily self insured in North America for group health
 insurance and workers compensation benefits provided to U.S.
 employees. The Company also purchases stop loss insurance to
 protect against annual claims per individual and at an aggregate
 level. The individual insured stop loss on the Company’s self
 insurance is $350 per individual for group health insurance and
 $250 per individual for worker’s compensation benefits. Self
 insurance liabilities are estimated for claims incurred but not
 paid based on judgment, using the Company’s historical claim
 data and information and analysis provided by actuarial and claim
 advisors, the Company’s insurance carrier and brokers. The
 Company has accrued $5,375 and $5,182 for self insurance
 liabilities as of January 2, 2017 and December 28, 2015,
 respectively, and these amounts are reflected within accrued
 salaries, wages and benefits in the consolidated balance
 sheets.

[0001193125-17-055058:notes:134]
Group health
 insurance and workers compensation benefits for the Company’s
 plants in China are fully insured with third parties.

[0001193125-17-055058:notes:135]
Convertible Debt

[0001193125-17-055058:notes:136]
The
 accounting standards for convertible debt instruments that may be
 fully or partially settled in cash upon conversion require the debt
 and equity components to be separately accounted for in a manner
 that reflects the Company’s nonconvertible borrowing rate
 when interest expense is recognized in subsequent periods. The
 amount recorded as debt is based on the fair value of the debt
 component as a standalone instrument, determined using an average
 interest rate for similar nonconvertible debt issued by entities
 with credit ratings comparable to the Company’s at the time
 of issuance. The difference between the debt recorded at inception
 and its principal amount is to be accreted to principal through
 interest expense through the estimated life of the note.

[0001193125-17-055058:notes:137]
Value
 Added and Sales Tax Collected from Customers

[0001193125-17-055058:notes:138]
As a part of
 the Company’s normal course of business, value added and
 sales taxes are collected from customers. Such taxes collected are
 remitted, in a timely manner, to the appropriate governmental tax
 authority on behalf of the customer. The Company’s policy is
 to present revenue and costs, net of value added and sales
 taxes.

[0001193125-17-055058:notes:139]
Fair
 Value Measures

[0001193125-17-055058:notes:140]
The Company
 measures at fair value certain of its financial and non-financial assets and liabilities by
 using a fair value hierarchy that prioritizes the inputs to
 valuation techniques used to measure fair value. Fair value is the
 price that would be received to sell an asset or paid to transfer a
 liability in an orderly transaction between market participants at
 the measurement date, essentially an exit price, based on the
 highest and best use of the asset or liability. The levels of the
 fair value hierarchy are:

[0001193125-17-055058:notes:141]
Level 1
 — Quoted market prices in active markets for identical assets
 or liabilities;

[0001193125-17-055058:notes:142]
Level 2
 — Significant other observable inputs (e.g., quoted prices
 for similar items in active markets, quoted prices for identical or
 similar items in markets that are not active, inputs other than
 quoted prices that are observable, such as interest rate and yield
 curves, and market-corroborated inputs); and

[0001193125-17-055058:notes:143]
Level 3
 — Unobservable inputs in which there is little or no market
 data, which require the reporting unit to develop its own
 assumptions.

[0001193125-17-055058:notes:144]
Environmental Accrual

[0001193125-17-055058:notes:145]
Accruals for
 estimated costs for environmental obligations generally are
 recognized no later than the date when the Company identifies what
 cleanup measures, if any, are likely to be required to address the
 environmental condition. Included in such obligations are the
 estimated direct costs to investigate and address the conditions,
 and the associated engineering, legal and consulting costs. In
 making these estimates, the Company considers information that is
 currently available, existing technology, enacted laws and
 regulations, and its estimates of the timing of the required
 remedial actions. Such accruals are initially measured on a
 discounted basis — and are adjusted as further information
 becomes available or circumstances change — and are accreted
 to the payable amount over time.

[0001193125-17-055058:notes:146]
Earnings Per Share

[0001193125-17-055058:notes:147]
Basic
 earnings per common share excludes dilution and is computed by
 dividing net income attributable to TTM Technologies, Inc.
 stockholders by the weighted average number of common shares
 outstanding during the period. Diluted earnings per common share
 reflect the potential dilution that could occur if stock options,
 convertible senior notes or other common stock equivalents were
 exercised or converted into common stock. The dilutive effect of
 stock options or other common stock equivalents is calculated using
 the treasury stock method, while the dilutive effect of convertible
 senior notes is calculated using the if-converted method.

[0001193125-17-055058:notes:148]
Comprehensive Income

[0001193125-17-055058:notes:149]
Comprehensive
 income includes changes to equity accounts that were not the result
 of transactions with stockholders. Comprehensive income is
 comprised of net income (loss), changes in the cumulative foreign
 currency translation adjustments and realized and unrealized gains
 or losses on hedged derivative instruments and available for sale
 securities.

[0001193125-17-055058:notes:150]
Noncontrolling Interest Holdings

[0001193125-17-055058:notes:151]
As of
 January 2, 2017, noncontrolling interest consists of a 5%
 equity interest in a manufacturing facility in Huiyang, China which
 was acquired along with other assets and liabilities of
 Viasystems.

[0001193125-17-055058:notes:152]
Loss
 Contingencies

[0001193125-17-055058:notes:153]
The Company
 establishes an accrual for an estimated loss contingency when it is
 both probable that an asset has been impaired or that a liability
 has been incurred and the amount of the loss can be reasonably
 estimated. Any legal fees expected to be incurred in connection
 with a contingency are expensed as incurred.


## us-gaap:AdditionalFinancialInformationDisclosureTextBlock

[0001193125-17-055058:notes:154]
| (5) | Composition of Certain Consolidated Financial Statement Captions |

[0001193125-17-055058:notes:155]
|  |  | As of |  |
|  |  | January 2, 2017 |  |  | December 28, 2015 |  |
|  |  | (In thousands) |  |
| Inventories: |  |  |  |  |
| Raw materials |  | $ | 73,497 |  |  | $ | 70,577 |  |
| Work-in-process |  |  | 105,094 |  |  |  | 97,193 |  |
| Finished goods |  |  | 90,621 |  |  |  | 101,153 |  |
|  |  | $ | 269,212 |  |  | $ | 268,923 |  |
| Property, plant and equipment, net: |  |  |  |  |  |  |  |  |
| Land and land use rights |  | $ | 69,487 |  |  | $ | 91,571 |  |
| Buildings and improvements |  |  | 436,822 |  |  |  | 446,763 |  |
| Machinery and equipment |  |  | 1,053,267 |  |  |  | 1,058,565 |  |
| Construction-in-progress, furniture and fixtures and other |  |  | 54,521 |  |  |  | 39,550 |  |
|  |  |  | 1,614,097 |  |  |  | 1,636,449 |  |
| Less: Accumulated depreciation |  |  | (647,459 | ) |  |  | (533,382 | ) |
|  |  | $ | 966,638 |  |  | $ | 1,103,067 |  |
| Other accrued liabilities: |  |  |  |  |  |  |  |  |
| Interest |  | $ | 927 |  |  | $ | 14,473 |  |
| Equipment payable |  |  | 12,430 |  |  |  | 14,251 |  |
| Other |  |  | 96,275 |  |  |  | 73,024 |  |
|  |  | $ | 109,632 |  |  | $ | 101,748 |  |

[0001193125-17-055058:notes:156]
In the fourth
 quarter of 2016, the Company commenced the process of selling
 buildings and related land and land use rights associated with the
 Cleveland, Ohio and Hong Kong, China facilities and has classified
 and aggregate total of $23,397 as assets held for sale at
 January 2, 2017. Assets held for sale are included in prepaids
 and other current assets in the January 2, 2107 consolidated
 balance sheets.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001193125-17-055058:notes:157]
| (9) | Income Taxes |

[0001193125-17-055058:notes:158]
The
 components of income (loss) before income taxes for the years ended
 January 2, 2017, December 28, 2015 and December 29,
 2014 are:

[0001193125-17-055058:notes:159]
|  |  | For the Year Ended |  |
|  |  | January 2, 2017 |  |  | December 28, 2015 |  |  | December 29, 2014 |  |
|  |  | (In thousands) |  |
| United States |  | $ | (85,323 | ) |  | $ | (104,068 | ) |  | $ | (3,201 | ) |
| Foreign |  |  | 152,325 |  |  |  | 113,044 |  |  |  | 25,492 |  |
| Income before income taxes |  | $ | 67,002 |  |  | $ | 8,976 |  |  | $ | 22,291 |  |

[0001193125-17-055058:notes:160]
The Company
 expects its foreign earnings attributable to all foreign
 subsidiaries will be indefinitely reinvested in such foreign
 jurisdictions and, therefore, no deferred tax liabilities for U.S.
 income taxes on undistributed earnings are recorded. The
 undistributed earnings of the foreign subsidiaries amounted to
 approximately $717,854 as of January 2, 2017. The
 determination of unrecognized deferred tax liability related to
 these undistributed earnings is not practicable. Foreign earnings
 attributable to certain manufacturing subsidiaries within China may
 be repatriated to the parent holding company located in Hong Kong,
 and therefore, a deferred tax liability of approximately $6,903 for
 the foreign tax impact has been recorded on the undistributed
 earnings of these subsidiaries.

[0001193125-17-055058:notes:161]
The
 components of income tax provision for the years ended
 January 2, 2017, December 28, 2015 and December 29,
 2014 are:

[0001193125-17-055058:notes:162]
The following
 is a reconciliation of the provision for income taxes at the
 statutory federal income tax rate compared to the Company’s
 provision for income taxes for the years ended January 2,
 2017, December 28, 2015 and December 29, 2014:

[0001193125-17-055058:notes:163]
|  |  | For the Year Ended |  |
|  |  | January 2, 2017 |  |  | December 28, 2015 |  |  | December 29, 2014 |  |
|  |  | (In thousands) |  |
| Statutory federal income tax |  | $ | (22,780 | ) |  | $ | (3,052 | ) |  | $ | (7,579 | ) |
| State income taxes, net of federal benefit and state tax credits |  |  | 906 |  |  |  | (345 | ) |  |  | (84 | ) |
| Foreign deemed dividends |  |  | (4,585 | ) |  |  | (5,691 | ) |  |  | — |  |
| Acquisition related expenses |  |  | (591 | ) |  |  | (7,692 | ) |  |  | — |  |
| Intercompany profit in inventory elimination |  |  | (335 | ) |  |  | 596 |  |  |  | — |  |
| Permanently reinvested earnings assertion |  |  | — |  |  |  | 8,281 |  |  |  | — |  |
| Foreign tax differential on foreign earnings |  |  | 17,530 |  |  |  | 15,543 |  |  |  | (6,243 | ) |
| Change in valuation allowance |  |  | (19,119 | ) |  |  | (39,148 | ) |  |  | 5,321 |  |
| Uncertain tax positions |  |  | (3,464 | ) |  |  | (3,911 | ) |  |  | — |  |
| Federal research and development credits |  |  | 1,270 |  |  |  | 1,270 |  |  |  | 1,020 |  |
| Loss on extinguishment of debt |  |  | — |  |  |  | — |  |  |  | — |  |
| Other |  |  | (259 | ) |  |  | (445 | ) |  |  | (33 | ) |
| Total provision for income taxes |  | $ | (31,427 | ) |  | $ | (34,594 | ) |  | $ | (7,598 | ) |

[0001193125-17-055058:notes:164]
Deferred
 income taxes reflect the net tax effects of temporary differences
 between the carrying amounts of assets and liabilities for
 financial reporting purposes and the amounts used for income tax
 purposes. The significant components of the net deferred income tax
 assets as of January 2, 2017 and December 28, 2015 are as
 follows:

[0001193125-17-055058:notes:165]
|  |  | As of |  |
|  |  | January 2, 2017 |  |  | December 28, 2015 |  |
|  |  | (In thousands) |  |
| Deferred income tax assets: |  |  |  |  |  |  |  |  |
| Net operating loss carryforwards |  | $ | 212,553 |  |  | $ | 223,456 |  |
| Reserves and accruals |  |  | 32,420 |  |  |  | 36,137 |  |
| Tax credit carryforwards |  |  | 18,148 |  |  |  | 19,719 |  |
| Stock-based compensation |  |  | 4,965 |  |  |  | 4,609 |  |
| Original issue discount on convertible senior notes |  |  | 15,329 |  |  |  | 18,876 |  |
| Property, plant and equipment |  |  | 13,398 |  |  |  | 12,945 |  |
| Other deferred income tax assets |  |  | 2,036 |  |  |  | 3,172 |  |
|  |  |  | 298,849 |  |  |  | 318,914 |  |
| Less: valuation allowance |  |  | (221,951 | ) |  |  | (234,192 | ) |
|  |  |  | 76,898 |  |  |  | 84,722 |  |
| Deferred income tax liabilities: |  |  |  |  |  |  |  |  |
| Discount on convertible senior notes |  |  | (13,410 | ) |  |  | (16,495 | ) |
| Repatriation of foreign earnings |  |  | (6,903 | ) |  |  | (4,776 | ) |
| Property, plant and equipment basis differences |  |  | (32,582 | ) |  |  | (34,716 | ) |
| Goodwill and intangible amortization |  |  | (36,097 | ) |  |  | (41,790 | ) |
| Other deferred income tax assets |  |  | (1,955 | ) |  |  | (93 | ) |
| Net deferred income tax liabilities |  | $ | (14,049 | ) |  | $ | (13,148 | ) |
| Deferred income tax liabilities, net: |  |  |  |  |  |  |  |  |
| Current deferred income taxes |  | $ | — |  |  | $ | — |  |
| Noncurrent deferred income taxes |  |  | (14,049 | ) |  |  | (13,148 | ) |

[0001193125-17-055058:notes:166]
As of
 January 2, 2017, the Company had the following net operating
 loss (“NOL”) carryforwards: $510,093 in the U.S. for
 federal, $561,708 in various U.S. states, $51,694 in China, $36,205
 in Hong Kong and $164 in the Netherlands. The U.S. federal NOLs
 expire in 2019 through 2036, the various U.S. states’ NOLs
 expire in 2017 through 2036, the China NOLs expire in 2017 through
 2021, the Hong Kong NOLs carryforward indefinitely, and the
 Netherlands NOLs expire in 2017. Further, the Company’s tax
 credits were approximately $26,451 of which $8,481 carryforward
 indefinitely.

[0001193125-17-055058:notes:167]
In connection
 with the Company’s acquisition of Viasystems, there was more
 than a 50% change in ownership under Section 382 of the
 Internal Revenue Code of 1986, as amended, and regulations issued
 there under. As a consequence, the utilization of the acquired
 Viasystems U.S. NOLs is limited to approximately $9,826 per year.
 In addition, the Company recognized certain gains built in at the
 time of the ownership change, which increase the limitation by
 approximately $47,463 for each of the first 5 years after the
 acquisition. Any unused limitation in a year can be carried over to
 succeeding years.

[0001193125-17-055058:notes:168]
A valuation
 allowance is provided when it is more likely than not that all or
 some portion of the deferred income tax assets will not be
 realized. Based on historical performance and future expectations,
 the Company has a full valuation allowance on its net U.S. deferred
 tax assets. Certain subsidiaries within China continue to have NOL
 carryforwards in various tax jurisdictions that the Company has
 determined are not more likely than not to be utilized. As a
 result, a full valuation allowance has been recorded for these
 subsidiaries at January 2, 2017. For the remaining net
 deferred income tax asset, management has determined that it is
 more likely than not that the results of future operations will
 generate sufficient taxable income to realize the net deferred tax
 asset.

[0001193125-17-055058:notes:169]
The following
 summarizes the activity in the Company’s valuation allowance
 for the years ended January 2, 2017, December 28, 2015
 and December 29, 2014:

[0001193125-17-055058:notes:170]
|  |  | For the Year Ended |  |
|  |  | January 2, 2017 |  |  | December 28, 2015 |  |  | December 29, 2014 |  |
|  |  | (In thousands) |  |
| Balance at beginning of year |  | $ | 234,192 |  |  | $ | 38,839 |  |  | $ | 44,160 |  |
| (Reduction) additions related to acquisition |  |  | (18,234 | ) |  |  | 177,699 |  |  |  | — |  |
| Additions charged to expense |  |  | 5,993 |  |  |  | 39,149 |  |  |  | 6,458 |  |
| Reduction related to sale of foreign subsidiary |  |  | — |  |  |  | (21,495 | ) |  |  | — |  |
| Deductions |  |  | — |  |  |  | — |  |  |  | (11,779 | ) |
| Balance at end of year |  | $ | 221,951 |  |  | $ | 234,192 |  |  | $ | 38,839 |  |

[0001193125-17-055058:notes:171]
Certain
 entities within China operated under the high and new technology
 enterprise (HNTE) status enabling those entities to enjoy certain
 tax holidays, which were effective for the years ended
 January 2, 2017, December 28, 2015 and December 29,
 2014. The tax holidays as well as enhanced research and development
 (R&D) deductions decreased Chinese taxes by $7,666, $7,600 and
 $1,877, which (decreased) increased both basic and dilutive (loss)
 earnings per share by $(0.08), $(0.08) and $0.02, for the years
 ended January 2, 2017, December 28, 2015 and
 December 29, 2014, respectively. HTNE status and the related
 tax holidays expire at various dates through 2017, but the Company
 expects to continue to file for renewal of such HNTE status for the
 foreseeable future.

[0001193125-17-055058:notes:172]
A
 reconciliation of the beginning and ending amount of unrecognized
 tax benefits, exclusive of accrued interest and penalties, is as
 follows:

[0001193125-17-055058:notes:173]
|  |  | For the Year Ended |  |
|  |  | January 2, 2017 |  |  | December 28, 2015 |  |  | December 29, 2014 |  |
|  |  | (In thousands) |  |
| Beginning balance |  | $ | 15,404 |  |  | $ | 2,441 |  |  | $ | 2,298 |  |
| Additions related to acquisition |  |  | 22,182 |  |  |  | 11,293 |  |  |  | — |  |
| Additions based on tax positions related to the current year |  |  | 5,389 |  |  |  | 3,349 |  |  |  | 220 |  |
| Additions for tax positions of prior years |  |  | 1,545 |  |  |  | 14 |  |  |  | 286 |  |
| Reductions for tax positions of prior years |  |  | (2,286 | ) |  |  | (1,371 | ) |  |  | — |  |
| Lapse of statute |  |  | (2,507 | ) |  |  | (322 | ) |  |  | (363 | ) |
| Ending balance |  | $ | 39,727 |  |  | $ | 15,404 |  |  | $ | 2,441 |  |

[0001193125-17-055058:notes:174]
As of
 January 2, 2017 and December 28, 2015, the Company
 recorded unrecognized tax benefits of $28,037 and $10,649,
 respectively, as well as interest and penalties of $10,754 and
 $12,202, respectively, to other long-term liabilities. The Company
 has also recorded unrecognized tax benefits of $11,689 and $4,755
 against certain deferred tax assets as of January 2, 2017 and
 December 28, 2015, respectively. The amount of unrecognized
 tax benefits that would, if recognized, reduce the Company’s
 effective income tax rate in any future periods is $38,791
 including interest and penalties. The Company expects its
 unrecognized tax benefits to decrease by $641 along with related
 interest of $987 over the next 12 months due to expiring
 statutes.

[0001193125-17-055058:notes:175]
As of
 January 2, 2017, the Company is subject to (i) U.S.
 federal income tax examination and / or NOL adjustment for tax
 years from 1999 to 2016, (ii) state and local income tax
 examination for tax years 1999 to 2016, and (iii) foreign
 income tax examinations generally for tax years from 2006 to
 2016.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0001193125-17-055058:notes:176]
| (1) | Nature of Operations and Basis of Presentation |

[0001193125-17-055058:notes:177]
TTM
 Technologies, Inc. (the Company or TTM) is a leading global printed
 circuit board (PCB) manufacturer, focusing on quick-turn and volume
 production of technologically complex PCBs and electro-mechanical
 solutions (E-M Solutions).
 The Company provides time-to-market and advanced
 technology products and offers a one-stop manufacturing solution to
 customers from engineering support to prototype development through
 final mass production. This one-stop manufacturing solution allows
 the Company to align technology developments with the diverse needs
 of the Company’s customers and to enable them to reduce the
 time required to develop new products and bring them to
 market.

[0001193125-17-055058:notes:178]
The Company
 serves a diversified customer base in various markets throughout
 the world, including networking/communications infrastructure
 products, smartphones and touchscreen tablets, as well as the
 aerospace and defense, automotive components, high-end computing, and medical,
 industrial and instrumentation related products. The
 Company’s customers include both original equipment
 manufacturers (OEMs) and electronic manufacturing services (EMS)
 providers.

[0001193125-17-055058:notes:179]
The Company
 operates on a 52 or 53 week year ending on the Monday nearest
 December 31. Fiscal 2016 consisted of 53 weeks ended on
 January 2, 2017 with the additional week included in the
 fourth quarter. Fiscal 2015 and 2014 were 52 weeks and ended on
 December 28, 2015, and December 29, 2014, respectively.
 All references to years relate to fiscal years unless otherwise
 noted.


## us-gaap:ScheduleOfEarningsPerShareBasicAndDilutedTableTextBlock

[0001193125-17-055058:notes:180]
The following
 is a reconciliation of the numerator and denominator used to
 calculate basic earnings (loss) per share and diluted earnings
 (loss) per share for the years ended January 2,
 2017, December 28, 2015 and December 29, 2014:

[0001193125-17-055058:notes:181]
|  |  | For the Year Ended |  |
|  |  | January 2, 2017 |  |  | December 28, 2015 |  |  | December 29, 2014 |  |
|  |  | (In thousands, except per share amounts) |  |
| Net income (loss) attributable to TTM Technologies, Inc. stockholders |  | $ | 34,861 |  |  | $ | (25,882 | ) |  | $ | 14,693 |  |
| Weighted average shares outstanding |  |  | 100,099 |  |  |  | 92,675 |  |  |  | 83,238 |  |
| Dilutive effect of performance-based stock units, restricted stock units and stock options |  |  | 1,383 |  |  |  | — |  |  |  | 703 |  |
| Diluted shares |  |  | 101,482 |  |  |  | 92,675 |  |  |  | 83,941 |  |
| Earnings (loss) per share attributable to TTM Technologies, Inc. stockholders: |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  | $ | 0.35 |  |  | $ | (0.28 | ) |  | $ | 0.18 |  |
| Diluted |  | $ | 0.34 |  |  | $ | (0.28 | ) |  | $ | 0.18 |  |


## us-gaap:ScheduleOfMaturitiesOfLongTermDebtTableTextBlock

[0001193125-17-055058:notes:182]
The fiscal
 calendar maturities of long-term debt through 2021 and thereafter
 are as follows:

[0001193125-17-055058:notes:183]
|  |  | (In thousands) |  |
| 2017 |  | $ | 110,652 |  |
| 2018 |  |  | 358 |  |
| 2019 |  |  | 381 |  |
| 2020 |  |  | 250,407 |  |
| 2021 |  |  | 700,000 |  |
|  |  | $ | 1,061,798 |  |


## us-gaap:ScheduleofFiniteLivedIntangibleAssetsFutureAmortizationExpenseTableTextBlock

[0001193125-17-055058:notes:184]
Estimated
 aggregate amortization for definite-lived intangible assets for the
 next five years and thereafter is as follows:

[0001193125-17-055058:notes:185]
|  |  | (In thousands) |  |
| 2017 |  | $ | 23,647 |  |
| 2018 |  |  | 22,880 |  |
| 2019 |  |  | 18,746 |  |
| 2020 |  |  | 18,746 |  |
| 2021 |  |  | 18,746 |  |
| Thereafter |  |  | 23,848 |  |
|  |  | $ | 126,613 |  |


## us-gaap:ScheduleOfGoodwillTextBlock

[0001193125-17-055058:notes:186]
As of
 January 2, 2017 and December 28, 2015, goodwill was as
 follows:

[0001193125-17-055058:notes:187]
|  |  | Total |  |
|  |  | (In thousands) |  |
| Balance as of December 29, 2014 |  | $ | 12,111 |  |
| Goodwill recognized during the year |  |  | 334,870 |  |
| Foreign currency translation adjustment |  |  | 9 |  |
| Balance as of December 28, 2015 |  |  | 346,990 |  |
| Goodwill recognized during the year |  |  | 25,624 |  |
| Foreign currency translation adjustment |  |  | (5 | ) |
| Balance as of January 2, 2017 |  | $ | 372,609 |  |


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001193125-17-055058:notes:188]
| (3) | Acquisition of Viasystems Group, Inc. |

[0001193125-17-055058:notes:189]
On
 May 31, 2015, the Company completed the acquisition of
 Viasystems Group, Inc. (Viasystems), for total consideration of
 $248,824 in cash and 15,082 shares of TTM common stock with a fair
 value of $149,006, and thereby acquired all of the outstanding
 shares of capital stock and other equity rights of Viasystems.
 Additionally, in connection with the completion of the acquisition,
 the Company assumed and refinanced Viasystems’ debt, which
 was approximately $669,024 as of May 31, 2015. Viasystems was
 a worldwide provider of complex multi-layer rigid, flexible, and
 rigid-flex PCBs and custom electronic assemblies.

[0001193125-17-055058:notes:190]
Bank fees and
 legal, accounting, and other professional service costs associated
 with the acquisition of Viasystems of $1,688, $34,448 and $5,981
 for the years ended January 2, 2017, December 28, 2015
 and December 29, 2014, respectively, have been expensed and
 recorded as general and administrative expense in the consolidated
 statements of operations.

[0001193125-17-055058:notes:191]
The value of
 the shares of the Company’s common stock used in determining
 the purchase price was $9.88 per share, the closing price of the
 Company’s common stock on May 29, 2015, the last
 business day prior to the effective date of the
 acquisition.

[0001193125-17-055058:notes:192]
The purchase
 price of the Viasystems acquisition was allocated to tangible and
 intangible assets acquired, liabilities assumed and noncontrolling
 interest based on the fair value at the date of the acquisition
 (May 31, 2015). The excess of the purchase price over the fair
 value of net assets acquired and noncontrolling interest was
 allocated to goodwill. The fair value assigned to intangible assets
 acquired was based on estimates and assumptions made by management
 at the time of acquisition. The Company finalized the allocation of
 the purchase price during the second quarter of 2016.

[0001193125-17-055058:notes:193]
The fair
 values assigned are based on reasonable methods applicable to the
 nature of the assets acquired, liabilities assumed and
 noncontrolling interest. The following summarizes the final
 estimated fair values of net assets acquired and noncontrolling
 interest:

[0001193125-17-055058:notes:194]
|  |  | (In thousands) |  |
| Cash |  | $ | 79,662 |  |
| Restricted cash |  |  | 3,510 |  |
| Accounts and notes receivables ($216,259 contractual gross receivables) |  |  | 209,196 |  |
| Inventories |  |  | 132,216 |  |
| Prepaid expenses and other current assets |  |  | 30,633 |  |
| Property, plant and equipment |  |  | 427,457 |  |
| Identifiable intangible assets |  |  | 150,500 |  |
| Goodwill |  |  | 360,494 |  |
| Deposits and other noncurrent assets |  |  | 1,157 |  |
| Current liabilities |  |  | (256,705 | ) |
| Long-term debt |  |  | (669,024 | ) |
| Other liabilities |  |  | (63,966 | ) |
| Noncontrolling interest |  |  | (7,300 | ) |
| Total |  | $ | 397,830 |  |

[0001193125-17-055058:notes:195]
Goodwill
 represents the excess of the Viasystems purchase price over the
 fair value of tangibles and identifiable intangible assets
 acquired, liabilities assumed and noncontrolling interest. During
 the first two quarters of 2016, goodwill was adjusted to
 reflect:

[0001193125-17-055058:notes:196]
|  | • |  | an increase in current liabilities by $3,442 due to a reassessment of product claims and other contingent liabilities, and |

[0001193125-17-055058:notes:197]
|  | • |  | an increase in other noncurrent liabilities by $22,182 primarily related to liabilities associated with certain tax positions at certain foreign jurisdictions. |

[0001193125-17-055058:notes:198]
The goodwill
 acquired in the acquisition is not deductible for income tax
 purposes.


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0001193125-17-055058:notes:199]
| (10) | Accumulated Other Comprehensive Income |


## us-gaap:FairValueAssetsMeasuredOnNonrecurringBasisTextBlock

[0001193125-17-055058:notes:200]
For the years
 ended January 2, 2017 and December 29, 2014, the
 following assets were measured at fair value on a nonrecurring
 basis using the type of inputs shown:

[0001193125-17-055058:notes:201]
|  |  |  |  |  | Fair Value Measurements Using: |  |
|  |  | January 2, 2017 |  |  | Level 1 Inputs |  |  | Level 2 Inputs |  |  | Level 3 Inputs |  |  | Total Losses for the year Ended January 2, 2017 |  |
|  |  | (In thousands) |  |
| Long-lived assets held and use |  | $ | 2,254 |  |  | $ | — |  |  | $ | — |  |  | $ | 2,254 |  |  | $ | 1,953 |  |
| Assets held for sale |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 1,393 |  |
|  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | $ | 3,346 |  |

[0001193125-17-055058:notes:202]
|  |  |  |  |  | Fair Value Measurements Using: |  |
|  |  | December 29, 2014 |  |  | Level 1 Inputs |  |  | Level 2 Inputs |  |  | Level 3 Inputs |  |  | Total Losses for the Year Ended December 29, 2014 |  |
|  |  | (In thousands) |  |
| Assets held for sale |  | $ | 21,031 |  |  | $ | — |  |  | $ | 21,031 |  |  | $ | — |  |  | $ | 1,845 |  |


## us-gaap:IntangibleAssetsDisclosureTextBlock

[0001193125-17-055058:notes:203]
| (7) | Definite-lived Intangibles |

[0001193125-17-055058:notes:204]
As of
 January 2, 2017 and December 28, 2015, the components of
 definite-lived intangibles were as follows:

[0001193125-17-055058:notes:205]
|  |  | Gross Amount |  |  | Accumulated Amortization |  |  | Foreign Currency Translation Adjustment |  |  | Net Carrying Amount |  |  | Weighted Average Amortization Period |  |
|  |  | (In thousands) |  |  | (years) |  |
| January 2, 2017: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Customer relationships |  | $ | 203,563 |  |  | $ | (78,473 | ) |  | $ | 119 |  |  | $ | 125,209 |  |  |  | 8.1 |  |
| Technology |  |  | 3,000 |  |  |  | (1,596 | ) |  |  | — |  |  |  | 1,404 |  |  |  | 3.0 |  |
|  |  | $ | 206,563 |  |  | $ | (80,069 | ) |  | $ | 119 |  |  | $ | 126,613 |  |  |  |  |  |
| December 28, 2015: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Customer relationships |  | $ | 91,492 |  |  | $ | (80,152 | ) |  | $ | 426 |  |  | $ | 11,766 |  |  |  | 9.2 |  |
| Trade name |  |  | 10,302 |  |  |  | (10,313 | ) |  |  | 11 |  |  |  | — |  |  |  | 6.0 |  |
| Acquired intangibles from Viasystems acquisition |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Customer relationships |  |  | 147,500 |  |  |  | (10,815 | ) |  |  | — |  |  |  | 136,685 |  |  |  | 8.1 |  |
| Technology |  |  | 3,000 |  |  |  | (577 | ) |  |  | — |  |  |  | 2,423 |  |  |  | 3.0 |  |
|  |  | $ | 252,294 |  |  | $ | (101,857 | ) |  | $ | 437 |  |  | $ | 150,874 |  |  |  |  |  |

[0001193125-17-055058:notes:206]
The
 January 2, 2017 and December 28, 2015 definite-lived
 intangible balances include foreign currency translation
 adjustments related to foreign subsidiaries with functional
 currencies other than the U.S. Dollar and the removal of fully
 amortized intangibles reducing the gross amounts
 reported.

[0001193125-17-055058:notes:207]
Definite-lived
 intangibles are generally amortized using the straight line method
 of amortization over the useful life, with the exception of certain
 customer relationship intangibles, which are amortized using an
 accelerated method of amortization based on estimated cash flows.
 Amortization expense was $24,252, $18,888, and $8,387 for the years
 ended January 2, 2017, December 28, 2015 and
 December 29, 2014, respectively.


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0001193125-17-055058:notes:208]
| (15) | Employee Benefit and Deferred Compensation Plans |

[0001193125-17-055058:notes:209]
As of
 January 2, 2017, the Company has three separate retirement
 benefit plans: one in North America and two in China. In North
 America, the Company has a 401(k) savings plan (the Savings Plan)
 in which eligible full-time domestic employees can participate and
 contribute a percentage of compensation subject to the maximum
 allowed by the Internal Revenue Service. The Savings Plan provides
 for a partial match by the employer of the first 5% of employee
 contributions (100% of the first 3% and 50% of the following 2% of
 employee contributions). In China, the Company contributes to
 either separate trust-administered funds or various
 government-sponsored pension plans on a mandatory basis. For all
 retirement plans, the Company has no further payment obligation
 once the required contributions have been made. The Company
 recorded contributions to retirement benefit plans of $36,172,
 $35,427 and $18,953 during the years ended January 2,
 2017, December 28, 2015 and December 29, 2014,
 respectively.

[0001193125-17-055058:notes:210]
The Company
 also maintains a deferred compensation plan (the Compensation
 Plan). The Compensation Plan is an unfunded, nonqualified deferred
 compensation plan and is limited to selected employees, including
 our named executive officers and our directors. The Compensation
 Plan allows participants to defer up to 100% of their annual bonus
 and between 5% and 100% of their annual director fees. Amounts
 deferred under the Compensation Plan will be credited to accounts
 maintained by the Company for each participant and will be credited
 or debited with the participant’s proportionate share of any
 gains or losses attributable to the performance of investment
 options selected by the participant.


## us-gaap:ConcentrationRiskDisclosureTextBlock

[0001193125-17-055058:notes:211]
| (11) | Significant Customers and Concentration of Credit Risk |

[0001193125-17-055058:notes:212]
In the normal
 course of business, the Company extends credit to its customers,
 which are concentrated primarily in the automotive, cellular phone,
 computer, networking and communications and aerospace and defense
 industries. Most customers to which the Company extends credit are
 located outside the United States, with the exception of certain
 customers in the aerospace and defense industries. The Company
 performs ongoing credit evaluations of customers, does not require
 collateral, and considers the credit risk profile of the entity
 from which the receivable is due in further evaluating collection
 risk.

[0001193125-17-055058:notes:213]
The
 Company’s customers include both OEMs and EMS companies. The
 Company’s OEM customers often direct a significant portion of
 their purchases through EMS companies. While the Company’s
 customers include both OEM and EMS providers, the Company measures
 customer concentration based on OEM companies, as they are the
 ultimate end customers.

[0001193125-17-055058:notes:214]
For the years
 ended January 2, 2017, December 28, 2015 and
 December 29, 2014, one customer accounted for approximately
 15%, 20% and 21%, respectively, of the Company’s net sales.
 There were no other customers that accounted for 10% or more of net
 sales for the years ended January 2, 2017, December 28,
 2015 and December 29, 2014.


## us-gaap:EarningsPerShareTextBlock

[0001193125-17-055058:notes:215]
| (19) | Earnings Per Share |

[0001193125-17-055058:notes:216]
For the years
 ended January 2, 2017 and December 29, 2014,
 performance-based stock units (PRUs), restricted stock units (RSUs)
 and stock options to purchase 892 and 1,233 shares of common stock,
 respectively, were not considered in calculating diluted earnings
 per share because the options’ exercise prices or the total
 expected proceeds under the treasury stock method for
 performance-based stock units, restricted stock units or stock
 options was greater than the average market price of common shares
 during the applicable year and, therefore, the effect would be
 anti-dilutive.

[0001193125-17-055058:notes:217]
For the year
 ended December 28, 2015, potential shares of common stock,
 consisting of stock options to purchase approximately 420 shares of
 common stock at exercise prices ranging from $5.78 to $16.82 per
 share, 2,294 RSUs, and 572 PRUs were not included in the
 computation of diluted earnings per share because the Company
 incurred a net loss from operations and, as a result, the impact
 would be anti-dilutive.

[0001193125-17-055058:notes:218]
Additionally,
 for the years ended January 2, 2017, December 28, 2015
 and December 29, 2014, the effect of shares of common stock
 related to the Company’s convertible senior notes were not
 included in the computation of dilutive earnings per share as the
 impact would be anti-dilutive.

[0001193125-17-055058:notes:219]
Outstanding
 warrants for the years ended January 2, 2017, December
 28, 2015 and December 29, 2014, to purchase common stock were
 not included in the computation of dilutive earnings per share
 because the strike price of the warrants to purchase the
 Company’s common stock were greater than the average market
 price of common shares during the applicable year, and therefore,
 the effect would be anti-dilutive.


## us-gaap:FairValueDisclosuresTextBlock

[0001193125-17-055058:notes:220]
| (12) | Fair Value Measures |

[0001193125-17-055058:notes:221]
The Company
 measures at fair value its financial and non-financial assets by using a fair value
 hierarchy that prioritizes the inputs to valuation techniques used
 to measure fair value. Fair value is the price that would be
 received to sell an asset or paid to transfer a liability in an
 orderly transaction between market participants at the measurement
 date, essentially an exit price, based on the highest and best use
 of the asset or liability.

[0001193125-17-055058:notes:222]
The carrying
 amount and estimated fair value of the Company’s financial
 instruments as of January 2, 2017 and December 28, 2015
 were as follows:

[0001193125-17-055058:notes:223]
|  |  | As of |  |
|  |  | January 2, 2017 |  |  | December 28, 2015 |  |
|  |  | Carrying Amount |  |  | Fair Value |  |  | Carrying Amount |  |  | Fair Value |  |
|  |  | (In thousands) |  |
| Term and Revolving Loans |  | $ | 809,023 |  |  | $ | 818,750 |  |  | $ | 970,764 |  |  | $ | 935,000 |  |
| Convertible Senior Notes due 2020 |  |  | 208,861 |  |  |  | 380,875 |  |  |  | 200,022 |  |  |  | 230,950 |  |
| Capital lease |  |  | 1,798 |  |  |  | 1,798 |  |  |  | — |  |  |  | — |  |

[0001193125-17-055058:notes:224]
The fair
 value of the long-term debt was estimated based on quoted market
 prices or discounting the debt over its life using current market
 rates for similar debt as of January 2, 2017 and
 December 28, 2015, which are considered Level 1 and
 Level 2 inputs.

[0001193125-17-055058:notes:225]
The fair
 value of the convertible senior notes was estimated based on quoted
 market prices of the securities on an active exchange, which are
 considered Level 1 and Level 2 inputs.

[0001193125-17-055058:notes:226]
As of
 January 2, 2017 and December 28, 2015, the
 Company’s other financial instruments also included cash and
 cash equivalents, accounts receivable, accounts payable and
 equipment payables. Due to short-term maturities, the carrying
 amount of these instruments approximates fair value. Our cash and
 cash equivalents at January 2, 2017 consisted of $50,227 held
 in the U.S., with the remaining $206,050 held by foreign
 subsidiaries.

[0001193125-17-055058:notes:227]
The majority
 of the Company’s non-financial assets and liabilities, which
 include goodwill, intangible assets, inventories, and property,
 plant and equipment, are not required to be carried at fair value
 on a recurring basis. However, if certain triggering events occur
 (or are tested at least annually in the case of goodwill) such that
 a non-financial instrument is required to be
 evaluated for impairment, based upon a comparison of
 the non-financial instrument’s fair value
 to its carrying value, an impairment is recorded to reduce the
 carrying value to the fair value, if the carrying value exceeds the
 fair value.

[0001193125-17-055058:notes:228]
There was no
 impairment of long-lived assets recognized in the year ended
 December 28, 2015.

[0001193125-17-055058:notes:229]
The fair
 values of assets held for sale were primarily determined using
 appraisals and comparable prices of similar assets, which are
 considered to be Level 2 inputs.

[0001193125-17-055058:notes:230]
Additionally,
 the Company has capitalized software costs in accordance with U.S.
 GAAP. During the year ended January 2, 2017, the Company
 determined that certain capitalized costs no longer had benefit
 primarily as a result of the Viasystems acquisition. Because the
 primary determination of fair value was based on management’s
 assumptions and estimates of capitalized costs to dispose, the
 resulting fair value is considered a Level 3 input.


## us-gaap:GoodwillDisclosureTextBlock

[0001193125-17-055058:notes:231]
| (6) | Goodwill |

[0001193125-17-055058:notes:232]
Goodwill
 balances include foreign currency translation adjustments related
 to foreign subsidiaries with functional currencies other than the
 U.S. Dollar. All of the Company’s goodwill is included
 as a component of the PCB reportable operating segment.

[0001193125-17-055058:notes:233]
In the fourth
 quarter of 2016, the Company performed its annual impairment test
 qualitatively and concluded that it was more likely than not that
 there was no impairment to goodwill. The Company will continue to
 evaluate its goodwill on an annual basis during its fourth fiscal
 quarter and whenever events or changes in circumstances —
 such as significant adverse changes in business climate or
 operating results, changes in management strategy, coupled with a
 decline in the market price of our stock and market capitalization
 — indicate that there may be a potential impairment. If
 factors indicate that assets are impaired, we would be required to
 reduce the carrying value of our goodwill and definite-lived
 intangible assets, which may result in an impairment
 charge.


## us-gaap:LongTermDebtTextBlock

[0001193125-17-055058:notes:234]
| (8) | Long-term Debt and Letters of Credit |

[0001193125-17-055058:notes:235]
Term
 and Revolving Loans

[0001193125-17-055058:notes:236]
On
 May 31, 2015, in conjunction with the acquisition of
 Viasystems, the Company entered into a $950,000 Term Loan Credit
 Agreement (Term Loan). Additionally, the Company entered into a
 $150,000 U.S. Asset-Based Lending Credit Agreement(U.S. ABL) and a
 $150,000 Asia Asset-Based Lending Credit Agreement (Asia ABL)
 (collectively the ABL Revolving Loans). The Company drew $80,000 of
 the U.S. ABL at the closing of the acquisition of
 Viasystems.

[0001193125-17-055058:notes:237]
On
 September 27, 2016, the Company issued new $775,000 Term B
 Loans (Term Loan B) at an interest rate of LIBOR, with a 1.0% LIBOR
 floor, plus 4.25%, a reduction of 75 basis points from its previous
 Term Loans, and repaid in full the remaining outstanding balance of
 the May 31, 2015 Term Loan. This transaction was accounted for
 as an extinguishment of debt and accordingly, the Company
 recognized a loss of $47,767 primarily associated with the write
 off of the remaining unamortized debt discount and issuance
 costs.

[0001193125-17-055058:notes:238]
Additionally,
 on September 27, 2016, the Company amended its U.S. ABL credit
 facility to increase the amount available to $200,000, reduce the
 applicable margin by 25 basis points for both Eurodollar loans and
 ABR loans, and reduce the Letters of Credit Facilities to $50,000.
 On December 22, 2016, the Company amended its Asia ABL credit
 facility to reduce the interest margin by 35 basis
 points.

[0001193125-17-055058:notes:239]
The Term Loan
 B bears interest at a floating rate of LIBOR, with a 1.0% LIBOR
 floor, plus an applicable interest margin of 4.25%, or JP Morgan
 Chase Bank’s prime rate, with a 2% floor, plus a margin of
 3.25%, at the Company’s option. At January 2, 2017, the
 weighted average interest rate on the outstanding borrowings under
 the Term Loan was 5.25%. There is no provision, other than an event
 of default, for the interest margin to increase. The Term Loan B
 will mature on May 31, 2021. The Term Loan B is secured by a
 significant amount of the assets of the Company and a pledge of 65%
 of voting stock of the Company’s first tier foreign
 subsidiaries and is structurally senior to the Company’s
 convertible senior notes. See Convertible Senior Notes
 below.

[0001193125-17-055058:notes:240]
The amended
 U.S. ABL consists of three tranches comprised of a revolving credit
 facility of up to $200,000, a letter of credit facility of up to
 $50,000, and swingline loans of up to $30,000, provided that at no
 time may amounts outstanding under the tranches exceed in aggregate
 $200,000 or the applicable borrowing base, which is a percentage of
 the principal amount of Eligible Accounts, as defined in the U.S.
 ABL agreement. Borrowings under the U.S. ABL bear interest at
 either a floating rate of LIBOR plus a margin of 150 basis points
 or JP Morgan Chase Bank’s prime rate plus a margin of 50
 basis points, at the Company’s option. At January 2,
 2017, the weighted average interest rate on the outstanding
 borrowings under the U.S. ABL was 2.27%. The applicable margin can
 vary based on the remaining availability of the facility, from 125
 to 175 basis points for LIBOR-based loans and from 25 to 75 basis
 points for JP Morgan Chase Bank’s prime rate-based loans.
 Other than availability and an event of default, there are no other
 provisions for the interest margin to increase. The U.S. ABL will
 mature on May 31, 2020. Loans made under the U.S. ABL are
 secured first by all of the Company’s domestic cash,
 receivables and inventories as well as by a second position against
 a significant amount of the assets of the Company and a pledge of
 65% of voting stock of the Company’s first tier foreign
 subsidiaries and are structurally senior to the Company’s
 convertible senior notes. See Convertible Senior Notes below. At
 January 2, 2017, $80,000 of the U.S. ABL was outstanding. The
 Company and its domestic subsidiaries have fully and
 unconditionally guaranteed the full and timely payment of all Term
 Loan B and U.S. ABL related obligations.

[0001193125-17-055058:notes:241]
The Asia ABL
 consists of two tranches comprised of a revolving credit facility
 of up to $150,000 and a letter of credit facility of up to
 $100,000, provided that at no time may amounts outstanding under
 both tranches exceed in aggregate $150,000 or the applicable
 borrowing base, which is a percentage of the principal amount of
 Eligible Accounts, as defined in the Asia ABL agreement. Borrowings
 under the Asia ABL bear interest at a floating rate of LIBOR plus
 140 basis points. At January 2, 2017, the weighted average
 interest rate on the outstanding borrowings under the Asia ABL was
 2.17%. There is no provision, other than an event of default, for
 the interest margin to increase. The Asia ABL will mature on
 May 22, 2020. Loans made under the Asia ABL are secured by a
 portion of the Company’s Asia Pacific cash and receivables
 and are structurally senior to the Company’s domestic
 obligations, including the convertible senior notes. See
 Convertible Senior Notes below. The Company’s Asia Pacific
 subsidiary and certain of its subsidiaries have fully and
 unconditionally guaranteed the full and timely payment of all Asia
 ABL related obligations. At January 2, 2017, $30,000 of the
 Asia ABL was outstanding.

[0001193125-17-055058:notes:242]
During the
 year ended January 2, 2017, the Company made net debt
 principal payments totaling $217,625 representing normal principal
 payments as well as additional prepayments of principal. The
 Company is not required to make quarterly scheduled payments of the
 outstanding Term Loan B balance due to mandatory payments and
 optional loan prepayments applied to date. Based on certain
 parameters defined in the Term Loan B agreement, including a
 secured leverage ratio, the Company may be required to make an
 additional principal payment on an annual basis. Any remaining
 outstanding balances under the Term Loan B are due at the maturity
 date of May 31, 2021. Borrowings under the Term Loan B are
 subject to financial and operating covenants including maintaining
 a maximum total leverage ratio. Under the occurrence of certain
 events, the U.S. ABL and the Asia ABL are subject to financial and
 operational covenants, including maintaining minimum fixed charge
 coverage ratios. At January 2, 2017, the Company was in
 compliance with the covenants under the Term Loan B, the U.S. ABL
 and the Asia ABL.

[0001193125-17-055058:notes:243]
As of
 January 2, 2017, remaining unamortized debt issuance costs of
 $977 related to the Term Loan B. As of December 28, 2015,
 remaining unamortized debt discount of $30,242 and debt issuance
 costs of $26,619 related to the Term Loan. There was no unamortized
 debt discount for the Term Loan B at January 2, 2017. These
 debt discount and debt issuance costs are recorded as a reduction
 of the Term Loan B and the Term Loan at January 2, 2017 and
 December 28, 2015, respectively, and are amortized over the
 duration of the Term Loan B and Term Loan into interest expense
 using an effective interest rate of 5.29% and 7.50%,
 respectively.

[0001193125-17-055058:notes:244]
Additionally,
 remaining unamortized debt issuance costs related to the ABL
 Revolving Loans were $3,423 and $4,303 as of January 2, 2017
 and December 28, 2015, respectively. These debt issuance costs
 are included in other non-current assets and are amortized to
 interest expense over the duration of the ABL Revolving Loans using
 the straight line method of amortization.

[0001193125-17-055058:notes:245]
At
 January 2, 2017, the remaining amortization period for the
 unamortized debt issuance costs for both the Term Loan B and the
 ABL Revolving Loans was 3.6 years.

[0001193125-17-055058:notes:246]
The Company
 is required to pay a commitment fee of 0.25% to 0.375% per
 annum on any unused portion of the U.S. ABL or Asia ABL based on
 utilization levels. Additionally, the Company also paid commitment
 fees of 0.5% per annum on the unused portion of the $90,000
 senior secured revolving loan associated with the terminated 2012
 credit agreement for the years ended December 28, 2015
 and December 29, 2014. The Company incurred total
 commitment fees related to unused borrowing availability of $709,
 $763, and $600 for the years ended January 2, 2017,
 December 28, 2015, and December 29, 2014,
 respectively. As of January 2, 2017, the outstanding amount of
 the Term Loan B was $700,000, which is included as long-term debt.
 Additionally, $80,000 of the U.S. ABL and $30,000 of the Asia ABL
 were outstanding as of January 2, 2017, which were classified
 as short-term debt. Available borrowing capacity under the U.S. ABL
 and Asia ABL was $113,003 and $111,663, which includes letters of
 credit outstanding of $6,997 and $8,337 mentioned below,
 respectively, at January 2, 2017.

[0001193125-17-055058:notes:247]
Letters
 of Credit

[0001193125-17-055058:notes:248]
The Company
 has up to $50,000 and $100,000 Letters of Credit Facilities under
 the U.S. ABL and the Asia ABL, respectively, as mentioned above. As
 of January 2, 2017, letters of credit in the amount of $6,997
 were outstanding under the U.S. ABL and $8,337 were outstanding
 under the Asia ABL with various expiration dates through December
 2017.

[0001193125-17-055058:notes:249]
At
 December 28, 2015, certain letters of credit were securitized
 by cash collateral. As such the Company had recorded such cash as
 restricted cash on the consolidated balance sheet as of
 December 28, 2015. As of January 2, 2017, none of the
 letters of credit were securitized by cash collateral.

[0001193125-17-055058:notes:250]
Convertible Senior Notes

[0001193125-17-055058:notes:251]
Convertible Senior Notes due 2020

[0001193125-17-055058:notes:252]
The Company
 issued 1.75% convertible senior notes due December 15, 2020,
 in a public offering for an aggregate principal amount of $250,000
 in 2014. The convertible senior notes bear interest at a rate of
 1.75% per annum. Interest is payable semiannually in arrears
 on June 15 and December 15 of each year. The convertible
 senior notes are senior unsecured obligations and rank equally to
 the Company’s future unsecured senior indebtedness and are
 senior in right of payment to any of the Company’s future
 subordinated indebtedness.

[0001193125-17-055058:notes:253]
Conversion:    At
 any time prior to March 15, 2020, holders may convert their
 convertible senior notes into cash and, if applicable, into shares
 of the Company’s common stock based on a conversion rate of
 103.7613 shares of the Company’s common stock per $1
 principal amount of convertible senior notes, subject to
 adjustment, under the following circumstances: (1) during any
 calendar quarter beginning after March 31, 2015 (and only
 during such calendar quarter), if the last reported sale price of
 our common stock for at least 20 trading days during the 30
 consecutive trading days ending on the last trading day of the
 immediately preceding calendar quarter is greater than or equal to
 130% of the applicable conversion price on each applicable trading
 day of such preceding calendar quarter; (2) during the five
 business day period after any 10 consecutive trading day period in
 which the trading price per note for each day of that 10
 consecutive trading day period was less than 98% of the product of
 the last reported sale price of the Company’s common stock
 and the conversion rate on such day; or (3) upon the
 occurrence of specified corporate transactions described in the
 indenture governing the notes. As of January 2, 2017, the
 conversion criteria had been met allowing holders to give notice of
 conversion in the first quarter of 2017.

[0001193125-17-055058:notes:254]
On or after
 March 15, 2020 until the close of business on the third
 scheduled trading day preceding the maturity date, holders may
 convert their notes at any time, regardless of the foregoing
 circumstances. Upon conversion, for each $1 principal amount of
 notes, the Company will pay shares of our common stock, cash or a
 combination of cash and shares of our common stock at its election,
 if applicable, based on a daily conversion value calculated on a
 proportionate basis for each day of the 80 trading day observation
 period. All conversions occurring on the same date or on or after
 March 15, 2020 shall be settled using the same settlement
 method. Additionally, in the event of a fundamental change as
 defined in the indenture governing the notes, or other conversion
 rate adjustments such as share splits or combinations, other
 distributions of shares, cash or other assets to stockholders,
 including self-tender transactions (Other Conversion Rate
 Adjustments), the conversion rate may be modified to adjust the
 number of shares per $1 principal amount of the notes. As of
 January 2, 2017, none of the criteria for a fundamental change
 or a conversion rate adjustment had been met.

[0001193125-17-055058:notes:255]
The maximum
 number of shares issuable upon conversion, including the effect of
 a fundamental change and subject to Other Conversion Rate
 Adjustments, would be 32,425.

[0001193125-17-055058:notes:256]
Note
 Repurchase:    The
 Company is not permitted to redeem the convertible senior notes at
 any time prior to maturity. In the event of a fundamental change or
 certain default events, as defined in the indenture governing the
 notes, holders may require the Company to repurchase for cash all
 or a portion of their convertible senior notes at a price equal to
 100% of the principal amount, plus any accrued and unpaid
 interest.

[0001193125-17-055058:notes:257]
Convertible Note Hedge and Warrant
 Transaction:    In
 connection with the issuance of the convertible senior notes due
 2020, the Company entered into a convertible note hedge and warrant
 transaction (Call Spread Transaction), with respect to the
 Company’s common stock. The convertible note hedge consists
 of the Company’s option to purchase up to 25,940 common stock
 shares at a price of $9.64 per share. The hedge expires on
 December 15, 2020 and can only be executed upon the conversion
 of the above mentioned convertible senior notes due 2020.
 Additionally, the Company sold warrants to purchase 25,940 shares
 of its common stock at a price of $14.26 per share. The warrants
 expire ratably from March 2021 through January 2022. The 2020 Call
 Spread Transaction has no effect on the terms of the convertible
 senior notes due 2020 and reduces potential dilution by effectively
 increasing the conversion price of the convertible senior notes due
 2020 to $14.26 per share of the Company’s common
 stock.

[0001193125-17-055058:notes:258]
Convertible Senior Notes due 2015

[0001193125-17-055058:notes:259]
The Company
 issued 3.25% convertible senior notes due on May 15, 2015, in
 a public offering for an aggregate principal amount of $175,000. In
 May 2015, the outstanding principal of $32,395 plus accrued
 interest was paid in full.

[0001193125-17-055058:notes:260]
The
 components of interest expense resulting from the convertible
 senior notes for the years ended January 2,
 2017, December 28, 2015 and December 29, 2014 were as
 follows:

[0001193125-17-055058:notes:261]
|  |  | For the Year Ended |  |
|  |  | January 2, 2017 |  |  | December 28, 2015 |  |  | December 29, 2014 |  |
|  |  | (In thousands) |  |
| Contractual coupon interest |  |  |  |  |  |  |  |  |  |  |  |  |
| Convertible Senior Notes due 2020 |  | $ | 4,375 |  |  | $ | 4,375 |  |  | $ | 4,367 |  |
| Convertible Senior Notes due 2015 |  |  | — |  |  |  | 395 |  |  |  | 1,053 |  |
|  |  | $ | 4,375 |  |  | $ | 4,770 |  |  | $ | 5,420 |  |
| Amortization of debt discount |  |  |  |  |  |  |  |  |  |  |  |  |
| Convertible Senior Notes due 2020 |  | $ | 8,034 |  |  | $ | 7,532 |  |  | $ | 7,102 |  |
| Convertible Senior Notes due 2015 |  |  | — |  |  |  | 554 |  |  |  | 1,395 |  |
|  |  | $ | 8,034 |  |  | $ | 8,086 |  |  | $ | 8,497 |  |
| Amortization of debt issuance costs |  |  |  |  |  |  |  |  |  |  |  |  |
| Convertible Senior Notes due 2020 |  | $ | 805 |  |  | $ | 755 |  |  | $ | 712 |  |
| Convertible Senior Notes due 2015 |  |  | — |  |  |  | 56 |  |  |  | 141 |  |
|  |  | $ | 805 |  |  | $ | 811 |  |  | $ | 853 |  |

[0001193125-17-055058:notes:262]
As of
 January 2, 2017 and December 28, 2015, remaining
 unamortized debt discount of $37,392 and $45,426, respectively, and
 debt issuance costs of $3,747 and $4,552, respectively, related to
 the convertible senior notes. These debt discount and debt issuance
 costs are recorded as a reduction of the convertible senior notes
 and are being amortized to interest expense over the term of the
 convertible senior notes using the effective interest rate method.
 At January 2, 2017, the remaining weighted average
 amortization period for the unamortized senior convertible note
 discount and debt issuance costs was 4 years.

[0001193125-17-055058:notes:263]
For the years
 ended January 2, 2017, December 28, 2015 and
 December 29, 2014, the amortization of the convertible senior
 notes due 2020 debt discount and debt issuance costs was based on
 an effective interest rate of 6.48%. For the years
 ended December 28, 2015 and December 29, 2014, the
 amortization of the convertible senior notes due 2015 debt discount
 and debt issuance costs was based on an effective interest rate of
 8.37%.

[0001193125-17-055058:notes:264]
Loss on
 Extinguishment of Debt

[0001193125-17-055058:notes:265]
During the
 year ended January 2, 2017 and as mentioned previously, the
 Company repaid the remaining outstanding balances of its Term Loan.
 As a result, the Company recognized losses of $47,767 primarily
 associated with the write off of the remaining unamortized debt
 discount and debt issuance costs.

[0001193125-17-055058:notes:266]
During the
 year ended December 28, 2015, the Company paid in full the
 remaining outstanding amount of $225,700 under an existing 2012
 credit agreement. As a result, the Company recognized losses of
 approximately $802 resulting from the write off of the remaining
 unamortized debt issuance costs associated with the terminated 2012
 credit agreement.

[0001193125-17-055058:notes:267]
During the
 year ended December 29, 2014, the Company repurchased $6,541
 of its convertible senior notes due 2015 at approximately 103.4% of
 their principal amounts. The repurchases were accounted for as
 extinguishments of debt and, accordingly, the Company recognized
 losses of approximately $506 primarily associated with the premium
 paid to repurchase the convertible senior notes and the recognition
 of related unamortized debt discount and issuance costs.

[0001193125-17-055058:notes:268]
Other
 Credit Facility

[0001193125-17-055058:notes:269]
Additionally,
 the Company is party to a revolving loan credit facility (Chinese
 Revolver) with a lender in China. Under this arrangement, the
 lender has made available to the Company approximately $30,200 in
 unsecured borrowing with all terms of the borrowing to be
 negotiated at the time the Chinese Revolver is drawn upon. There
 are no commitment fees on the unused portion of the Chinese
 Revolver, and this arrangement expires in January 2018. As of
 January 2, 2017, the Chinese Revolver had not been drawn
 upon.


## us-gaap:PreferredStockTextBlock

[0001193125-17-055058:notes:270]
| (16) | Preferred Stock |

[0001193125-17-055058:notes:271]
The board of
 directors has the authority, without action by stockholders, to
 designate and issue preferred stock in one or more series. The
 board of directors may also designate the rights, preferences and
 privileges of each series of preferred stock, any or all of which
 may be superior to the rights of the common stock. As of
 January 2, 2017, no shares of preferred stock were
 outstanding.


## us-gaap:ReconciliationOfAssetsFromSegmentToConsolidatedTextBlock

[0001193125-17-055058:notes:272]
|  |  | As of |  |
|  |  | January 2, 2017 |  |  | December 28, 2015 |  |  | December 29, 2014 |  |
|  |  | (In thousands) |  |
| Segment Assets: |  |  |  |  |  |  |  |  |  |  |  |  |
| PCB |  | $ | 1,791,829 |  |  | $ | 1,943,577 |  |  | $ | 1,334,648 |  |
| E-M Solutions |  |  | 127,826 |  |  |  | 143,779 |  |  |  | 43,255 |  |
| Corporate |  |  | 580,421 |  |  |  | 552,777 |  |  |  | 223,386 |  |
| Total assets |  | $ | 2,500,076 |  |  | $ | 2,640,133 |  |  | $ | 1,601,289 |  |


## us-gaap:RelatedPartyTransactionsDisclosureTextBlock

[0001193125-17-055058:notes:273]
| (20) | Related Party Transactions |

[0001193125-17-055058:notes:274]
In the normal
 course of business, the Company’s foreign subsidiaries
 purchase laminate and prepreg from related parties in which a
 significant shareholder of the Company holds an equity interest.
 The Company purchased laminate and prepreg from these related
 parties in the amount of $55,649, $63,605 and $47,446 for the years
 ended January 2, 2017, December 28, 2015 and
 December 29, 2014, respectively.

[0001193125-17-055058:notes:275]
Dongguan Shengyi
 Electronics Ltd. (SYE) is also a related party as it is a wholly
 owned subsidiary of an entity in which a significant shareholder of
 the Company holds an equity interest. The Company sells PCBs to SYE
 and purchases PCBs including various services relating to PCB
 manufacturing from SYE. Sales to SYE for the years ended
 January 2, 2017, December 28, 2015 and December 29,
 2014 were $991, $4,709 and $24,120, respectively. Purchases of PCBs
 including various services relating to PCB manufacturing for the
 years ended December 28, 2015 and December 29, 2014 were
 $1,948 and $1,671, respectively. There were no purchases from SYE
 for the year ended January 2, 2017.

[0001193125-17-055058:notes:276]
As of
 January 2, 2017 and December 28, 2015, the
 Company’s consolidated balance sheets included $15,836 and
 $29,306, respectively, in accounts payable due to related parties
 for purchases of laminate and prepreg and various PCB manufacturing
 services and such balances are included as a component of accounts
 payable on the consolidated balance sheets. Additionally, the
 Company’s consolidated balance sheets included $192 and
 $1,999, respectively, in accounts receivable due from a related
 party for sales of PCBs to SYE, as mentioned above, and such
 balances are included as a component of accounts receivable, net on
 the consolidated balance sheets.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001193125-17-055058:notes:277]
| (18) | Segment Information |

[0001193125-17-055058:notes:278]
The operating
 segments reported below are the Company’s segments for which
 separate financial information is available and upon which
 operating results are evaluated by the chief operating decision
 maker to assess performance and to allocate resources. The Company
 has reviewed its reportable operating segments and determined it
 continues to have two reportable operating segments: PCB
 and E-M Solutions. The PCB reportable
 segment is comprised of multiple operating segments. This
 determination was made based on the criteria of earning revenues
 and incurring expenses, the Company’s organizational
 structure which has segment managers who report to the chief
 operating decision maker, discrete financial information, and the
 aggregation of similar operating segments into reportable operating
 segments. Factors considered to determine whether operating
 segments can be aggregated into reportable segments included
 similarity regarding economic characteristics, products, production
 processes, type or classes of customers, distribution methods, and
 regulatory environments.

[0001193125-17-055058:notes:279]
The Company,
 including the chief operating decision maker, evaluates segment
 performance based on operating segment income, which is operating
 income before amortization of intangibles. Interest expense and
 interest income are not presented by segment since they are not
 included in the measure of segment profitability reviewed by the
 chief operating decision maker. All inter-segment transactions have
 been eliminated.

[0001193125-17-055058:notes:280]
The Corporate
 category includes operating expenses that are not included in the
 segment operating performance measures. Corporate consists
 primarily of corporate governance functions such as finance,
 accounting, information technology, facilities and human resources
 personnel, as well as global sales and marketing personnel and
 acquisition and integration costs associated with the acquisition
 of Viasystems. Bank fees and legal, accounting, and other
 professional service costs associated with the acquisition of
 Viasystems of $1,688, $34,448 and $5,981 for the years ended
 January 2, 2017, December 28, 2015, and December 29,
 2014, respectively, are included in Corporate.

[0001193125-17-055058:notes:281]
During the
 year ended January 2, 2017, the Company recorded impairment
 charges of $1,393 and $1,953 for the impairment of long-lived
 assets related to its PCB operating segment and Corporate operating
 segment, respectively. During the year ended December 29,
 2014, the Company recorded impairment charges of $1,845 for the
 impairment of long-lived assets related to its PCB operating
 segment. There were no impairment charges for the year ended
 December 28, 2015.

[0001193125-17-055058:notes:282]
The Company
 markets and sells its products in approximately 65 countries. Other
 than in the United States and China, the Company does not conduct
 business in any country in which its net sales in that country
 exceed 10% of the Company’s total net sales. Net sales and
 long-lived assets are as follows:

[0001193125-17-055058:notes:283]
Net sales are
 attributed to countries by country invoiced.


## ttmi:DistributionOfProfitsDisclosureTextBlock

[0001193125-17-055058:notes:284]
| (17) | Distribution of profits |

[0001193125-17-055058:notes:285]
As stipulated
 by the relevant laws and regulations of China applicable to the
 Company’s subsidiaries in China, each of such subsidiaries is
 required to make appropriations from its net income as determined
 in accordance with accounting principles and the relevant financial
 regulations of China (PRC GAAP) to a non-distributable reserve, also referred to as
 statutory surplus reserve. The appropriations to the statutory
 surplus reserve are required to be made at not less than 10% of the
 profit after tax as determined under PRC GAAP and are required
 until the balance reaches 50% of its registered capital. The
 statutory surplus reserve is used to offset future or past losses.
 These Chinese subsidiaries may, upon a resolution passed by their
 respective shareholders, convert the statutory surplus reserve into
 capital.

[0001193125-17-055058:notes:286]
There were
 appropriations of approximately $6,037, $4,576 and $2,544 to the
 statutory surplus reserve of the Company’s Chinese
 subsidiaries for the years ended January 2,
 2017, December 28, 2015 and December 29, 2014,
 respectively.
