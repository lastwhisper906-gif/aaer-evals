# TTMI notes — 0000950170-24-054464


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureAndSignificantAccountingPoliciesTextBlock

[0000950170-24-054464:notes:1]
[same as prior period, unchanged from 0000950170-23-060227:notes:1]

[0000950170-24-054464:notes:2]
TTM Technologies, Inc. (the Company or TTM) is a leading global manufacturer of technology solutions including mission systems, radio frequency (RF) components/RF microwave/microelectronic assemblies, and quick-turn and technologically advanced printed circuit boards (PCB). The Company provides time-to-market and volume production of advanced technology products and offers a one-stop design, engineering, and manufacturing solution to customers. This solution allows the Company to align technology developments with the diverse needs of the Company’s customers and to enable them to reduce the time required to develop new products and bring them to market.

[0000950170-24-054464:notes:3]
The Company serves a diversified customer base in various markets throughout the world, including aerospace and defense, data center computing, automotive, medical, industrial and instrumentation related products, and networking. The Company’s customers include original equipment manufacturers (OEMs), electronic manufacturing services (EMS) providers, original design manufacturers (ODMs), distributors, and government agencies (both domestic and allied foreign governments).

[0000950170-24-054464:notes:4]
The accompanying consolidated condensed financial statements have been prepared by the Company, without audit, pursuant to the rules and regulations of the Securities and Exchange Commission (SEC). Certain information and disclosures normally included in financial statements prepared in accordance with accounting principles generally accepted in the United States of America (U.S. GAAP) have been condensed or omitted pursuant to such rules and regulations. These consolidated condensed financial statements should be read in conjunction with the consolidated financial statements and the notes thereto included in the Company’s most recent Annual Report on Form 10-K. The preparation of financial statements in accordance with U.S. GAAP requires management to make estimates and assumptions that affect the amounts reported in the Company’s consolidated condensed financial statements and accompanying notes. Due, in part, to the conflict between Russia and Ukraine, and the conflict in Israel and the Gaza Strip, the global economy and financial markets have been volatile. The Company has considered information available to it as of the date of issuance of these financial statements and is not aware of any specific events or circumstances that would require an update to its estimates or judgments, or a revision to the carrying value of its assets or liabilities. The actual results the Company experienced may differ materially and adversely from its estimates. The Company uses a 52/53 week fiscal calendar with the fourth quarter ending on the Monday nearest December 31.

[0000950170-24-054464:notes:5]
Recently Issued Accounting Standards Not Yet Adopted

[0000950170-24-054464:notes:6]
In March 2024, the Financial Accounting Standards Board (FASB) issued Accounting Standards Update (ASU) 2024-02, Codification Improvements - Amendments to Remove References to the Concepts Statements, to remove various references to concepts statements from the Accounting Standards Codification (ASC). These amendments clarify guidance, simplify wording or structure of guidance, and other minor improvements. The amendments are effective for fiscal years beginning after December 15, 2024, applied prospectively, with early adoption and retrospective application permitted. The impact of the adoption of the amendments in this update is not expected to be material to the Company's consolidated financial statements and related disclosures.

[0000950170-24-054464:notes:7]
In December 2023, the FASB issued ASU 2023-09, Income Taxes (Topic 740): Improvements to Income Tax Disclosures, which requires disclosure of disaggregated income taxes paid, prescribes standard categories for the components of the effective tax rate reconciliation, and modifies other income tax-related disclosures. The update will be effective for annual periods beginning after December 15, 2024. Early adoption is permitted for annual financial statements not yet issued or made available for issuance. The Company is currently evaluating the new guidance to determine the impact it may have on its consolidated financial statements and related disclosures, but expects additional disclosures upon adoption.

[0000950170-24-054464:notes:8]
In November 2023, the FASB issued ASU 2023-07, Segment Reporting (Topic 280): Improvements to Reportable Segment Disclosures, which updates reportable segment disclosure requirements primarily through enhanced disclosures about significant segment expenses. The amendments are effective for fiscal years beginning after December 15, 2023, and for interim periods within fiscal years beginning after December 15, 2024. Early adoption is permitted. The amendments should be applied retrospectively to all prior periods presented in the financial statements. The Company is currently evaluating the new guidance to determine the impact it may have on its consolidated financial statements and related disclosures, but expects additional disclosures upon adoption.

[0000950170-24-054464:notes:9]
In October 2023, the FASB issued ASU 2023-06, Disclosure Improvements: Codification Amendments in Response to the Securities and Exchange Commission’s Disclosure Update and Simplification Initiative, which modifies the disclosure or presentation requirements of a variety of topics in the ASC in response to the SEC’s Release No. 33-10532, Disclosure Update and Simplification Initiative, and align the ASC requirements with the SEC’s regulations. For entities subject to the SEC's existing disclosure requirements, the effective date for each amendment will be the date on which the SEC's removal of that related disclosure from Regulation S-X or Regulation S-K becomes effective. However, if by June 30, 2027, the SEC has not removed the related disclosure from its regulations, the amendments will be removed from the Codification and not become effective. Early adoption is prohibited. The Company is currently evaluating the new guidance to determine the impact it may have on its consolidated financial statements and related disclosures.


## us-gaap:TreasuryStockTextBlock

[0000950170-24-054464:notes:10]
(2) Share Repurchase Program

[0000950170-24-054464:notes:11]
On May 3, 2023, the Company's Board of Directors authorized and approved a share repurchase program (2023 Repurchase Program), under which the Company may repurchase up to $100,000 in value of the Company’s outstanding shares of common stock from time to time through May 3, 2025. The Company may repurchase shares through open market purchases, privately-negotiated transactions, or otherwise in accordance with applicable federal securities laws, including Rule 10b-18 of the Securities Exchange Act of 1934, as amended (Exchange Act), which sets certain restrictions on the method, timing, price, and volume of open market stock repurchases. In addition, the Company adopted one trading plan in accordance with Rule 10b5-1 of the Exchange Act to facilitate certain purchases that may be effected under the share repurchase program. The timing, manner, price, and amount of any repurchases will be determined at the Company’s discretion, and the share repurchase program may be suspended, terminated, or modified at any time for any reason. The repurchase program does not obligate the Company to acquire any specific number of shares.

[0000950170-24-054464:notes:12]
During the quarter ended April 1, 2024, the Company repurchased 600 shares of common stock for a total cost of approximately $9,334 (including commissions). As of April 1, 2024, the remaining amount in value available to be repurchased under the 2023 Repurchase Program was approximately $66,234.


## us-gaap:ConcentrationRiskDisclosureTextBlock

[0000950170-24-054464:notes:13]
(3) Significant Customers and Concentration of Credit Risk

[0000950170-24-054464:notes:14]
[same as prior period, unchanged from 0000950170-23-060227:notes:117]

[0000950170-24-054464:notes:15]
The Company had cash and cash equivalents held by its foreign subsidiaries of $203,019 and $195,928 as of April 1, 2024 and January 1, 2024, respectively. The Company maintains its cash and cash equivalents with major financial institutions and such balances exceed Federal Deposit Insurance Corporation insurance limits. The Company has not experienced any losses in such accounts and believes it is not exposed to any significant risk on cash and cash equivalents.

[0000950170-24-054464:notes:16]
In the normal course of business, the Company extends credit to its customers. Some customers to whom the Company extends credit are located outside the United States. The Company performs on-going credit evaluations of customers, does not require collateral, and considers the credit risk profile of the entity from which the receivable is due in further evaluating collection risk. As of April 1, 2024, there was one customer that accounted for 11% of the Company's accounts receivable. There were no customers that accounted for 10% or more of the Company’s accounts receivable as of January 1, 2024.

[0000950170-24-054464:notes:17]
[same as prior period, unchanged from 0000950170-23-060227:notes:120]

[0000950170-24-054464:notes:18]
For the quarter ended April 1, 2024, two customers collectively accounted for approximately 22% of the Company's net sales. For the quarter ended April 3, 2023, one customer accounted for approximately 12% of the Company's net sales.


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0000950170-24-054464:notes:19]
[same as prior period, unchanged from 0000950170-23-060227:notes:42]

[0000950170-24-054464:notes:20]
As of April 1, 2024, the aggregate amount of the transaction price allocated to remaining performance obligations for long-term contracts was $385,265. The Company expects to recognize revenue on approximately 49% of the remaining performance obligations for the Company’s long-term contracts over the next 12 months with the remaining amount expected to be recognized thereafter.

[0000950170-24-054464:notes:21]
For contracts in which anticipated total costs exceed the total expected revenue, an estimated loss is recognized in the period when identifiable. A provision for the entire amount of the estimated loss is recorded on a cumulative basis. The estimated remaining costs to complete for loss contracts as of April 1, 2024 and January 1, 2024 were $34,044 and $25,213, respectively.

[0000950170-24-054464:notes:22]
Revenue recognized for the quarter ended April 1, 2024 from amounts recorded as contract liabilities as of January 1, 2024 was $18,214. Revenue recognized for the quarter ended April 3, 2023 from amounts recorded as contract liabilities as of January 2, 2023 was $18,508.

[0000950170-24-054464:notes:23]
Revenue from products and services transferred to customers over time and at a point in time accounted for 96% and 4%, respectively, of the Company’s revenue for the quarters ended April 1, 2024 and April 3, 2023.

[0000950170-24-054464:notes:24]
Disaggregated revenue by principal end markets with reportable segments was as follows:

[0000950170-24-054464:notes:25]
|  |  | Quarter Ended April 1, 2024 |  |
|  |  | PCB |  |  | RF and Specialty Components(RF&S Components) |  |  | Total |  |
|  |  | (In thousands) |  |
| End Markets: |  |  |  |  |  |  |  |  |  |
| Aerospace and Defense |  | $ | 264,776 |  |  | $ | — |  |  | $ | 264,776 |  |
| Automotive |  |  | 73,617 |  |  |  | — |  |  |  | 73,617 |  |
| Data Center Computing |  |  | 119,377 |  |  |  | 59 |  |  |  | 119,436 |  |
| Medical/Industrial/Instrumentation |  |  | 78,793 |  |  |  | 734 |  |  |  | 79,527 |  |
| Networking |  |  | 25,278 |  |  |  | 7,479 |  |  |  | 32,757 |  |
| Total |  | $ | 561,841 |  |  | $ | 8,272 |  |  | $ | 570,113 |  |

[0000950170-24-054464:notes:26]
|  |  | Quarter Ended April 3, 2023 |  |
|  |  | PCB |  |  | RF&S Components |  |  | Total |  |
|  |  | (In thousands) |  |
| End Markets: |  |  |  |  |  |  |  |  |  |
| Aerospace and Defense |  | $ | 232,292 |  |  | $ | — |  |  | $ | 232,292 |  |
| Automotive |  |  | 93,467 |  |  |  | — |  |  |  | 93,467 |  |
| Data Center Computing |  |  | 57,870 |  |  |  | — |  |  |  | 57,870 |  |
| Medical/Industrial/Instrumentation |  |  | 100,768 |  |  |  | 917 |  |  |  | 101,685 |  |
| Networking |  |  | 49,714 |  |  |  | 9,409 |  |  |  | 59,123 |  |
| Total |  | $ | 534,111 |  |  | $ | 10,326 |  |  | $ | 544,437 |  |


## us-gaap:AdditionalFinancialInformationDisclosureTextBlock

[0000950170-24-054464:notes:27]
[same as prior period, unchanged from 0000950170-23-060227:notes:51]

[0000950170-24-054464:notes:28]
|  |  | As of |  |
|  |  | April 1, 2024 |  |  | January 1, 2024 |  |
|  |  | (In thousands) |  |
| Inventories: |  |  |  |  |  |  |
| Raw materials |  | $ | 167,375 |  |  | $ | 165,666 |  |
| Work-in-process |  |  | 51,408 |  |  |  | 45,494 |  |
| Finished goods |  |  | 1,732 |  |  |  | 1,915 |  |
| Inventories |  | $ | 220,515 |  |  | $ | 213,075 |  |
| Property, plant, and equipment, net: |  |  |  |  |  |  |
| Land and land use rights |  | $ | 71,131 |  |  | $ | 71,131 |  |
| Buildings and improvements |  |  | 520,117 |  |  |  | 512,148 |  |
| Machinery and equipment |  |  | 1,050,565 |  |  |  | 986,527 |  |
| Furniture and fixtures and other |  |  | 10,301 |  |  |  | 10,157 |  |
| Construction-in-progress |  |  | 49,740 |  |  |  | 90,940 |  |
| Property, plant, and equipment, gross |  |  | 1,701,854 |  |  |  | 1,670,903 |  |
| Less: Accumulated depreciation |  |  | (876,020 | ) |  |  | (863,236 | ) |
| Property, plant, and equipment, net |  | $ | 825,834 |  |  | $ | 807,667 |  |
| Other current liabilities: |  |  |  |  |  |  |
| Accrued capital expenditures |  | $ | 14,714 |  |  | $ | 35,026 |  |
| Sales return and allowances |  |  | 12,656 |  |  |  | 12,301 |  |
| Accrued facility operating costs |  |  | 8,617 |  |  |  | 10,172 |  |
| Operating leases |  |  | 8,373 |  |  |  | 8,433 |  |
| Warranty |  |  | 8,191 |  |  |  | 10,557 |  |
| Housing fund |  |  | 7,742 |  |  |  | 7,749 |  |
| Income taxes payable |  |  | 5,625 |  |  |  | 5,466 |  |
| Accrued professional fees |  |  | 3,241 |  |  |  | 3,276 |  |
| Interest |  |  | 1,856 |  |  |  | 9,399 |  |
| Restructuring |  |  | 879 |  |  |  | 1,179 |  |
| Derivative liabilities |  |  | 24 |  |  |  | 297 |  |
| Other |  |  | 41,821 |  |  |  | 36,951 |  |
| Other current liabilities |  | $ | 113,739 |  |  | $ | 140,806 |  |
| Other long-term liabilities: |  |  |  |  |  |  |
| Deferred income taxes |  | $ | 46,021 |  |  | $ | 44,238 |  |
| Customer deposits |  |  | 29,105 |  |  |  | 29,820 |  |
| Finance leases |  |  | 12,602 |  |  |  | 12,799 |  |
| Defined benefit pension plan liability |  |  | 792 |  |  |  | 836 |  |
| Derivative liabilities |  |  | — |  |  |  | 1,476 |  |
| Other |  |  | 26,602 |  |  |  | 24,349 |  |
| Other long-term liabilities |  | $ | 115,122 |  |  | $ | 113,518 |  |


## us-gaap:GoodwillDisclosureTextBlock

[0000950170-24-054464:notes:29]
[same as prior period, unchanged from 0000950170-23-060227:notes:54]

[0000950170-24-054464:notes:30]
Goodwill by reportable segment was as follows:

[0000950170-24-054464:notes:31]
|  |  | PCB |  |  | RF&S Components |  |  | Total |  |
|  |  | (In thousands) |  |
| As of April 1, 2024 and January 1, 2024 |  |  |  |  |  |  |  |  |  |
| Goodwill |  | $ | 810,235 |  |  | $ | 177,200 |  |  | $ | 987,435 |  |
| Accumulated impairment losses |  |  | (171,400 | ) |  |  | (113,300 | ) |  |  | (284,700 | ) |
| Carrying amount |  | $ | 638,835 |  |  | $ | 63,900 |  |  | $ | 702,735 |  |


## us-gaap:IntangibleAssetsDisclosureTextBlock

[0000950170-24-054464:notes:32]
[same as prior period, unchanged from 0000950170-23-060227:notes:62]

[0000950170-24-054464:notes:33]
The components of definite-lived intangibles were as follows:

[0000950170-24-054464:notes:34]
|  |  | GrossAmount |  |  | AccumulatedAmortization |  |  | NetCarryingAmount |  |  | WeightedAverageAmortizationPeriod |  |
|  |  | (In thousands) |  |  | (In years) |  |
| As of April 1, 2024 |  |  |  |  |  |  |  |  |  |  |  |  |
| Customer relationships |  | $ | 416,230 |  |  | $ | (232,258 | ) |  | $ | 183,972 |  |  |  | 11.2 |  |
| Technology |  |  | 66,650 |  |  |  | (29,613 | ) |  |  | 37,037 |  |  |  | 8.2 |  |
| Backlog |  |  | 13,000 |  |  |  | (11,375 | ) |  |  | 1,625 |  |  |  | 2.0 |  |
| Trade names |  |  | 2,500 |  |  |  | (2,188 | ) |  |  | 312 |  |  |  | 2.0 |  |
| Total |  | $ | 498,380 |  |  | $ | (275,434 | ) |  | $ | 222,946 |  |  |  |  |
| As of January 1, 2024 |  |  |  |  |  |  |  |  |  |  |  |  |
| Customer relationships |  | $ | 416,230 |  |  | $ | (222,766 | ) |  | $ | 193,464 |  |  |  | 11.2 |  |
| Technology |  |  | 66,650 |  |  |  | (27,278 | ) |  |  | 39,372 |  |  |  | 8.2 |  |
| Backlog |  |  | 13,000 |  |  |  | (9,750 | ) |  |  | 3,250 |  |  |  | 2.0 |  |
| Trade names |  |  | 2,500 |  |  |  | (1,875 | ) |  |  | 625 |  |  |  | 2.0 |  |
| Total |  | $ | 498,380 |  |  | $ | (261,669 | ) |  | $ | 236,711 |  |  |  |  |

[0000950170-24-054464:notes:35]
Definite-lived intangibles are amortized using the straight-line method of amortization over the useful life. Amortization expense was $13,765 and $27,772 for the quarters ended April 1, 2024 and April 3, 2023, respectively. For the quarters ended April 1, 2024 and April 3, 2023, $2,336 and $5,808, respectively, of amortization expense was included in cost of goods sold. The Company recorded amortization expense of $18,114 related to the acquired identifiable intangible assets of Telephonics during the quarter ended April 3, 2023 (of which $10,744 corresponded to the fiscal year ended January 2, 2023). For the quarter ended April 3, 2023, $4,425 of amortization expense related to the acquired identifiable intangible assets of Telephonics was included in cost of goods sold (of which $2,950 corresponded to the fiscal year ended January 2, 2023).

[0000950170-24-054464:notes:36]
[same as prior period, unchanged from 0000950170-23-060227:notes:67]

[0000950170-24-054464:notes:37]
|  |  | (In thousands) |  |
| Remaining 2024 |  | $ | 31,127 |  |
| 2025 |  |  | 36,897 |  |
| 2026 |  |  | 36,897 |  |
| 2027 |  |  | 34,543 |  |
| 2028 |  |  | 30,997 |  |
| Thereafter |  |  | 52,485 |  |
| Total |  | $ | 222,946 |  |


## us-gaap:LongTermDebtTextBlock

[0000950170-24-054464:notes:38]
(8) Long-term Debt and Letters of Credit

[0000950170-24-054464:notes:39]
Long-term debt was as follows:

[0000950170-24-054464:notes:40]
|  |  | As of April 1, 2024 |  |  | As of January 1, 2024 |  |
|  |  | Interest Rate |  | PrincipalOutstanding |  |  | Interest Rate |  | PrincipalOutstanding |  |
|  |  | (In thousands, except interest rates) |  |
| Senior Notes due March 2029 |  |  | 4.00 |  | % |  | $ | 500,000 |  |  |  | 4.00 |  | % |  | $ | 500,000 |  |
| Term Loan due May 2030 |  |  | 8.07 |  |  |  |  | 347,375 |  |  |  | 8.10 |  |  |  |  | 349,125 |  |
| Asia ABL Revolving Loan due June 2028 |  |  | 6.62 |  |  |  |  | 80,000 |  |  |  | 6.65 |  |  |  |  | 80,000 |  |
| Total debt |  |  |  |  |  |  | 927,375 |  |  |  |  |  |  |  | 929,125 |  |
| Less: Unamortized debt issuance costs |  |  |  |  |  |  | (7,706 | ) |  |  |  |  |  |  | (8,021 | ) |
| Less: Unamortized debt discount |  |  |  |  |  |  | (3,156 | ) |  |  |  |  |  |  | (3,268 | ) |
| Subtotal |  |  |  |  |  |  | 916,513 |  |  |  |  |  |  |  | 917,836 |  |
| Less: current maturities |  |  |  |  |  |  | (2,625 | ) |  |  |  |  |  |  | (3,500 | ) |
| Long-term debt, less current maturities |  |  |  |  |  | $ | 913,888 |  |  |  |  |  |  | $ | 914,336 |  |

[0000950170-24-054464:notes:41]
Debt Covenants

[0000950170-24-054464:notes:42]
Borrowings under the Senior Notes due March 2029 and Term Loan due May 2030 (Term Loan Facility) are subject to certain affirmative and negative covenants, including limitations on indebtedness, corporate transactions, investments, dispositions, and restricted payments.

[0000950170-24-054464:notes:43]
Under the occurrence of certain events, the U.S. Asset-Based Lending Credit Agreement (U.S. ABL) and Asia Asset-Based Lending Credit Agreement (Asia ABL) (collectively, the ABL Revolving Loans), are subject to various financial covenants, including leverage and fixed charge coverage ratios.

[0000950170-24-054464:notes:44]
Debt Issuance Costs and Debt Discount

[0000950170-24-054464:notes:45]
Remaining unamortized debt issuance costs and debt discount were as follows:

[0000950170-24-054464:notes:46]
|  |  | As of April 1, 2024 |  | As of January 1, 2024 |
|  |  | DebtIssuance Costs |  |  | DebtDiscount |  |  | EffectiveInterest Rate |  | DebtIssuance Costs |  |  | DebtDiscount |  |  | EffectiveInterest Rate |
|  |  | (In thousands, except interest rates) |
| Senior Notes due March 2029 |  | $ | 3,907 |  |  | $ | — |  |  |  | 4.18 |  | % |  | $ | 4,085 |  |  | $ | — |  |  |  | 4.18 |  | % |
| Term Loan due May 2030 |  |  | 3,799 |  |  |  | 3,156 |  |  |  | 8.26 |  |  |  |  | 3,936 |  |  |  | 3,268 |  |  |  | 8.26 |  |  |
| Total |  | $ | 7,706 |  |  | $ | 3,156 |  |  |  |  |  |  | $ | 8,021 |  |  | $ | 3,268 |  |  |  |  |  |

[0000950170-24-054464:notes:47]
The above debt issuance costs and debt discount are recorded as a reduction of the debt and are amortized into interest expense using an effective interest rate over the duration of the debt.

[0000950170-24-054464:notes:48]
The remaining unamortized debt issuance costs for the ABL Revolving Loans of $1,512 and $1,603 as of April 1, 2024 and January 1, 2024, respectively, are included in deposits and other non-current assets and are amortized to interest expense over the duration of the ABL Revolving Loans using the straight-line method of amortization.

[0000950170-24-054464:notes:49]
As of April 1, 2024, the remaining weighted average amortization period for all unamortized debt issuance costs and debt discount was 5.5 years.


## us-gaap:IncomeTaxDisclosureTextBlock

[0000950170-24-054464:notes:50]
[same as prior period, unchanged from 0000950170-23-060227:notes:97]

[0000950170-24-054464:notes:51]
The Company’s effective tax rate is impacted by the mix of foreign and U.S. income, tax rates in China and Hong Kong, the U.S. federal income tax rate, apportioned state income tax rates, the generation of credits, and deductions available to the Company as well as changes in valuation allowances and certain non-deductible items. No tax benefit was recorded on the losses incurred in certain foreign jurisdictions as a result of corresponding increases in the valuation allowances in these jurisdictions.

[0000950170-24-054464:notes:52]
During the quarter ended April 1, 2024, the Company’s effective tax rate was impacted by a net discrete expense of $487. This is primarily related to the approval of the Company’s renewal application for High and New Technology Enterprise status for two of the Company’s manufacturing subsidiaries in China, including the impact on the respective subsidiaries’ deferred tax amounts.

[0000950170-24-054464:notes:53]
[same as prior period, unchanged from 0000950170-23-060227:notes:100]


## us-gaap:SegmentReportingDisclosureTextBlock

[0000950170-24-054464:notes:54]
[same as prior period, unchanged from 0000950170-23-060227:notes:101]

[0000950170-24-054464:notes:55]
The Company’s reportable segments are the segments for which separate financial information is available and upon which operating results are evaluated by the chief operating decision maker to assess performance and to allocate resources.

[0000950170-24-054464:notes:56]
The Company, including the chief operating decision maker, evaluates segment performance based on reportable segment income, which is operating income before amortization of intangibles. Interest expense and interest income are not presented by segment since they are not included in the measure of segment profitability reviewed by the chief operating decision maker. All inter-segment transactions have been eliminated. Net sales by segment, operating segment income, and segment assets were as follows:

[0000950170-24-054464:notes:57]
|  |  | Quarter Ended |  |
|  |  | April 1, 2024 |  |  | April 3, 2023 |  |
|  |  | (In thousands) |  |
| Net Sales: |  |  |  |  |  |  |
| PCB |  | $ | 561,841 |  |  | $ | 534,111 |  |
| RF&S Components |  |  | 8,272 |  |  |  | 10,326 |  |
| Total net sales |  | $ | 570,113 |  |  | $ | 544,437 |  |
| Operating Segment Income: |  |  |  |  |  |  |
| PCB |  | $ | 69,652 |  |  | $ | 51,634 |  |
| RF&S Components |  |  | 1,662 |  |  |  | 2,168 |  |
| Corporate and Other |  |  | (40,482 | ) |  |  | (29,498 | ) |
| Total operating segment income |  |  | 30,832 |  |  |  | 24,304 |  |
| Amortization of definite-lived intangibles (1) |  |  | (13,765 | ) |  |  | (27,772 | ) |
| Total operating income (loss) |  |  | 17,067 |  |  |  | (3,468 | ) |
| Total other expense |  |  | (2,998 | ) |  |  | (10,270 | ) |
| Income (loss) before income taxes |  | $ | 14,069 |  |  | $ | (13,738 | ) |

[0000950170-24-054464:notes:58]
|  |  | As of |  |
|  |  | April 1, 2024 |  |  | January 1, 2024 |  |
|  |  | (In thousands) |  |
| Segment Assets: |  |  |  |  |  |  |
| PCB |  | $ | 2,067,170 |  |  | $ | 2,032,202 |  |
| RF&S Components |  |  | 140,121 |  |  |  | 142,520 |  |
| Corporate and Other |  |  | 1,091,519 |  |  |  | 1,148,941 |  |
| Total assets |  | $ | 3,298,810 |  |  | $ | 3,323,663 |  |

[0000950170-24-054464:notes:59]
(1)
Amortization of definite-lived intangibles relates to the PCB and RF&S Components reportable segments. For the quarters ended April 1, 2024 and April 3, 2023, $2,336 and $5,808, respectively, of amortization expense is included in cost of goods sold.

[0000950170-24-054464:notes:60]
The Corporate and Other category primarily includes operating expenses that are not included in the segment operating performance measures. Corporate and Other consists primarily of corporate governance functions such as finance, accounting, information technology, and human resources personnel, as well as global sales and marketing personnel, research and development costs, and acquisition and integration costs associated with acquisitions and divestitures.

[0000950170-24-054464:notes:61]
The Company markets and sells its products in approximately 50 countries. Other than in the United States and Taiwan, the Company does not conduct business in any country in which its net sales in that country exceed 10% of the Company’s total net sales. Net sales are attributed to countries by country invoiced and were as follows:

[0000950170-24-054464:notes:62]
|  |  | Quarter Ended |  |
|  |  | April 1, 2024 |  |  | April 3, 2023 |  |
|  |  | (In thousands) |  |
| Net Sales: |  |  |  |  |  |  |
| United States |  | $ | 300,959 |  |  | $ | 311,441 |  |
| Taiwan |  |  | 68,924 |  |  |  | 27,943 |  |
| Other |  |  | 200,230 |  |  |  | 205,053 |  |
| Total net sales |  | $ | 570,113 |  |  | $ | 544,437 |  |


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0000950170-24-054464:notes:63]
[same as prior period, unchanged from 0000950170-23-060227:notes:113]

[0000950170-24-054464:notes:64]
The components of accumulated other comprehensive loss, net of tax, were as follows:

[0000950170-24-054464:notes:65]
|  |  | ForeignCurrencyTranslation |  |  | PensionObligation |  |  | Gains (Losses) on Cash FlowHedges |  |  | Total |  |
|  |  | (In thousands) |  |
| Ending balance as of January 1, 2024 |  | $ | (32,860 | ) |  | $ | 2,530 |  |  | $ | 1,263 |  |  | $ | (29,067 | ) |
| Other comprehensive (loss) income before reclassifications |  |  | (802 | ) |  |  | — |  |  |  | 3,819 |  |  |  | 3,017 |  |
| Amounts reclassified from accumulated other comprehensive loss |  |  | — |  |  |  | — |  |  |  | (867 | ) |  |  | (867 | ) |
| Net year to date other comprehensive (loss) income |  |  | (802 | ) |  |  | — |  |  |  | 2,952 |  |  |  | 2,150 |  |
| Ending balance as of April 1, 2024 |  | $ | (33,662 | ) |  | $ | 2,530 |  |  | $ | 4,215 |  |  | $ | (26,917 | ) |


## us-gaap:FinancialInstrumentsDisclosureTextBlock

[0000950170-24-054464:notes:66]
(12) Financial Instruments

[0000950170-24-054464:notes:67]
[same as prior period, unchanged from 0000950170-23-060227:notes:161]

[0000950170-24-054464:notes:68]
[same as prior period, unchanged from 0000950170-23-060227:notes:162]

[0000950170-24-054464:notes:69]
The Company’s business is exposed to risk resulting from fluctuations in interest rates on certain Secured Overnight Financing Rate (SOFR) based variable rate debt. Increases in interest rates increase interest expenses relating to the outstanding variable rate borrowings and increase the cost of debt. Fluctuations in interest rates can also lead to significant fluctuations in the fair value of the debt obligations.

[0000950170-24-054464:notes:70]
On March 23, 2023, the Company entered into a four-year pay-fixed, receive-floating (1-month Chicago Mercantile Exchange (CME) Term SOFR), interest rate swap arrangement with a notional amount of $250,000 for the period beginning April 1, 2023 and ending on April 1, 2027. Under the terms of the interest rate swap, the Company pays a fixed rate of 3.49% against a portion of its Term SOFR-based debt and receives a floating 1-month CME Term SOFR during the swap period.

[0000950170-24-054464:notes:71]
At inception, the Company designated the interest rate swap as a cash flow hedge and the fair value of the interest rate swap was zero. As of April 1, 2024, the fair value of the interest rate swap was recorded as an asset in the amount of $5,719, of which $4,580 is included as a component of prepaid expenses and other current assets and $1,139 is included as a component of deposits and other non-current assets. As of January 1, 2024, the fair value of the interest rate swap was recorded as a net asset in the amount of $1,777, of which $3,253 is included as a component of prepaid expenses and other current assets and $1,476 is included as a component of other long-term liabilities. The change in the fair value of the interest rate swap is recorded as a component of accumulated other comprehensive loss, net of tax in the Company's consolidated condensed balance sheets. No ineffectiveness was recognized for the quarter ended April 1, 2024. During the quarter ended April 1, 2024, the interest rate swap decreased interest expense by $1,166.

[0000950170-24-054464:notes:72]
[same as prior period, unchanged from 0000950170-23-060227:notes:166]

[0000950170-24-054464:notes:73]
The Company’s foreign subsidiaries may at times enter into forward exchange contracts to manage their foreign currency risks in relation to certain purchases of equipment denominated in foreign currencies other than the Company’s functional currencies. The notional amount of the foreign exchange contracts was $1,925 (Euro (EUR) 1.8 million) as of April 1, 2024 and January 1, 2024. The Company has designated certain of these foreign exchange contracts as cash flow hedges.

[0000950170-24-054464:notes:74]
[same as prior period, unchanged from 0000950170-23-060227:notes:168]

[0000950170-24-054464:notes:75]
The Company uses various raw materials in the manufacturing of PCBs. Copper clad laminates (CCLs), a key raw material for the manufacture of PCBs, are made from epoxy resin, glass cloth, and copper foil. The Company only buys a small amount of copper directly. However, copper is a major driver of laminate cost. The Company enters into commodity contracts to hedge copper as a proxy for hedging laminate. As of April 1, 2024, the Company has commodity contracts with a notional quantity of (i) 0.6 metric tonnes for the period beginning April 1, 2024 and ending on June 30, 2024, (ii) 0.6 metric tonnes for the period beginning July 1, 2024 and ending on September 30, 2024, (iii) 0.5 metric tonnes for the period beginning October 1, 2024 and ending on December 31, 2024, and (iv) 0.5 metric tonnes for the period beginning January 1, 2025 and ending on March 31, 2025. As of April 1, 2024, the fair value of the commodity contracts was recorded as an asset in the amount of $455 and included as a component of prepaid expenses and other current assets. As of January 1, 2024, the fair value of the commodity contracts was recorded as a liability in the amount of $297 and included as a component of other current liabilities. The changes in the fair value of these commodity contracts are recorded in cost of goods sold in the consolidated condensed statements of operations. The commodity contracts decreased cost of goods sold by $431 and $1,041 for the quarters ended April 1, 2024 and April 3, 2023, respectively. These commodity contracts are not designated as accounting hedges.

[0000950170-24-054464:notes:76]
The fair values of derivative instruments in the consolidated condensed balance sheets were as follows:

[0000950170-24-054464:notes:77]
|  |  |  |  | Asset/(Liability) Fair Value |  |
|  |  | Balance Sheet Location |  | April 1, 2024 |  |  | January 1, 2024 |  |
|  |  |  |  | (In thousands) |  |
| Cash flow derivative instruments designated as hedges: |  |  |  |  |  |  |
| Interest rate swap |  | Prepaid expenses and other current assets |  | $ | 4,580 |  |  | $ | 3,253 |  |
| Foreign exchange contracts |  | Prepaid expenses and other current assets |  |  | — |  |  |  | 29 |  |
| Interest rate swap |  | Deposits and other non-current assets |  |  | 1,139 |  |  |  | — |  |
| Foreign exchange contracts |  | Other current liabilities |  |  | (24 | ) |  |  | — |  |
| Interest rate swap |  | Other long-term liabilities |  |  | — |  |  |  | (1,476 | ) |
| Cash flow derivative instruments not designated as hedges: |  |  |  |  |  |  |
| Commodity contracts |  | Prepaid expenses and other current assets |  | $ | 455 |  |  | $ | — |  |
| Commodity contracts |  | Other current liabilities |  |  | — |  |  |  | (297 | ) |

[0000950170-24-054464:notes:78]
Amounts recorded in accumulated other comprehensive loss related to derivatives designated as cash flow hedges, as well as the amounts recorded in each caption in the consolidated condensed statements of operations when derivative amounts are reclassified out of accumulated other comprehensive loss were as follows:

[0000950170-24-054464:notes:79]
|  |  |  |  | Quarter Ended April 1, 2024 |  |  | Quarter Ended April 3, 2023 |  |
|  |  | FinancialStatement Caption |  | Gain Recognized in Other Comprehensive Loss |  |  | AmountsReclassifiedinto Net Income |  |  | Loss Recognizedin OtherComprehensive Loss |  |  | AmountsReclassifiedinto Net Loss |  |
|  |  |  |  | (In thousands) |  |
| Cash flow hedge: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Interest rate swap |  | Interest expense |  | $ | 5,108 |  |  | $ | (1,166 | ) |  | $ | (901 | ) |  | $ | — |  |

[0000950170-24-054464:notes:80]
The activity associated with the designated cash flow hedges reflected in accumulated other comprehensive loss was as follows:

[0000950170-24-054464:notes:81]
|  |  | Quarter Ended |  |
|  |  | April 1, 2024 |  |  | April 3, 2023 |  |
|  |  | (In thousands) |  |
| Beginning balance, net of tax |  | $ | 1,263 |  |  | $ | (85 | ) |
| Changes in fair value gain (loss), net of tax |  |  | 3,819 |  |  |  | (680 | ) |
| Reclassification to earnings |  |  | (867 | ) |  |  | 5 |  |
| Ending balance, net of tax |  | $ | 4,215 |  |  | $ | (760 | ) |


## us-gaap:FairValueDisclosuresTextBlock

[0000950170-24-054464:notes:82]
[same as prior period, unchanged from 0000950170-23-060227:notes:122]

[0000950170-24-054464:notes:83]
[same as prior period, unchanged from 0000950170-23-060227:notes:123]

[0000950170-24-054464:notes:84]
The carrying amount and estimated fair value of the Company’s financial instruments were as follows:

[0000950170-24-054464:notes:85]
|  |  | As of April 1, 2024 |  |  | As of January 1, 2024 |  |
|  |  | CarryingAmount |  |  | Fair Value |  |  | CarryingAmount |  |  | Fair Value |  |
|  |  | (In thousands) |  |
| Derivative assets, current |  | $ | 5,035 |  |  | $ | 5,035 |  |  | $ | 3,282 |  |  | $ | 3,282 |  |
| Derivative assets, non-current |  |  | 1,139 |  |  |  | 1,139 |  |  |  | — |  |  |  | — |  |
| Derivative liabilities, current |  |  | 24 |  |  |  | 24 |  |  |  | 297 |  |  |  | 297 |  |
| Derivative liabilities, non-current |  |  | — |  |  |  | — |  |  |  | 1,476 |  |  |  | 1,476 |  |
| Senior Notes due March 2029 |  |  | 496,093 |  |  |  | 450,285 |  |  |  | 495,915 |  |  |  | 455,035 |  |
| Term Loan due May 2030 |  |  | 340,420 |  |  |  | 348,028 |  |  |  | 341,921 |  |  |  | 351,743 |  |
| ABL Revolving Loans |  |  | 80,000 |  |  |  | 80,000 |  |  |  | 80,000 |  |  |  | 80,000 |  |

[0000950170-24-054464:notes:86]
[same as prior period, unchanged from 0000950170-23-060227:notes:126]

[0000950170-24-054464:notes:87]
The fair value of the long-term debt was estimated based on quoted market prices or discounting the debt over its life using current market rates for similar debt as of April 1, 2024 and January 1, 2024, which are considered Level 2 inputs.

[0000950170-24-054464:notes:88]
As of April 1, 2024 and January 1, 2024, the Company’s other financial instruments included cash and cash equivalents, accounts receivable, contract assets, accounts payable, and contract liabilities. The carrying amount of these instruments approximates fair value.

[0000950170-24-054464:notes:89]
The majority of the Company’s non-financial assets and liabilities, which include goodwill, intangible assets, inventories, and property, plant, and equipment, are not required to be carried at fair value on a recurring basis. However, if certain triggering events occur (or are tested at least annually in the case of goodwill) such that a non-financial instrument is required to be evaluated for impairment, based upon a comparison of the non-financial instrument’s fair value to its carrying value, an impairment is recorded to reduce the carrying value to the fair value, if the carrying value exceeds the fair value.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0000950170-24-054464:notes:90]
(14) Commitments and Contingencies

[0000950170-24-054464:notes:91]
Legal Matters

[0000950170-24-054464:notes:92]
The Company is subject to various legal matters, which it considers normal for its business activities. While the Company currently believes that the amount of any reasonably possible loss for known matters would not be material to the Company’s financial condition, the outcome of these actions is inherently difficult to predict. In the event of an adverse outcome, the ultimate potential loss could have a material adverse effect on the Company’s financial condition or results of operations in a particular period. The Company has accrued amounts for its loss contingencies which are probable and estimable as of April 1, 2024 and January 1, 2024 and included as a component of other current liabilities. However, these amounts are not material to the consolidated condensed financial statements of the Company.

[0000950170-24-054464:notes:93]
Offset Agreements

[0000950170-24-054464:notes:94]
The Company has and may continue to enter into industrial cooperation agreements, sometimes referred to as offset agreements, as a condition to obtaining orders for products and services from customers in foreign countries. These agreements are intended to promote investment in the applicable country, and the Company’s obligations under these agreements may be satisfied through activities that do not require the Company to use cash, including transferring technology or providing manufacturing and other consulting support. The obligations under these agreements may also be satisfied through the use of cash for activities such as purchasing supplies from in-country vendors, setting up support centers, research and development investments, acquisitions, and building or leasing facilities for in-country operations. The amount of the offset requirement is determined by contract value awarded and negotiated percentages with customers. As of April 1, 2024, the Company had outstanding offset agreements of approximately $27,963, some of which extend through 2028. Offset programs usually extend over several years and in some cases provide for penalties in the event the Company fails to perform in accordance with contract requirements. To date, the Company has not been obligated to pay any such penalties.

[0000950170-24-054464:notes:95]
Supplier Finance Program Obligations

[0000950170-24-054464:notes:96]
The Company has agreements with financial institutions to facilitate payments to certain suppliers. Under the terms of the agreements, the Company confirms the validity of each supplier invoice to the respective financial institution upon receipt. The supplier receives payment from the financial institution, and the Company pays the financial institution based on the terms negotiated, which generally range from 160 days to 360 days. Liabilities associated with these agreements are recorded in accounts payable on the consolidated condensed balance sheets and amounted to $17,689 and $18,832 as of April 1, 2024 and January 1, 2024, respectively.


## us-gaap:EarningsPerShareTextBlock

[0000950170-24-054464:notes:97]
(15) Earnings (Loss) Per Share

[0000950170-24-054464:notes:98]
The reconciliation of the numerator and denominator used to calculate basic earnings (loss) per share and diluted earnings (loss) per share is as follows:

[0000950170-24-054464:notes:99]
|  |  | Quarter Ended |  |
|  |  | April 1, 2024 |  |  | April 3, 2023 |  |
|  |  | (In thousands, except per share amounts) |  |
| Net income (loss) |  | $ | 10,466 |  |  | $ | (5,814 | ) |
| Basic weighted average shares |  |  | 101,952 |  |  |  | 102,381 |  |
| Dilutive effect of performance-based restricted stock units, restricted stock units and stock options |  |  | 2,146 |  |  |  | — |  |
| Diluted shares |  |  | 104,098 |  |  |  | 102,381 |  |
| Earnings (loss) per share: |  |  |  |  |  |  |
| Basic |  | $ | 0.10 |  |  | $ | (0.06 | ) |
| Diluted |  | $ | 0.10 |  |  | $ | (0.06 | ) |

[0000950170-24-054464:notes:100]
Restricted stock units (RSUs) and stock options to purchase 4 shares and 20 shares of common stock, respectively, for the quarter ended April 1, 2024 were not included in the computation of diluted earnings per share because the options’ exercise prices or the total expected proceeds under the treasury stock method were greater than the average market price of common stock during the applicable quarter and, as a result, the impact would be anti-dilutive.

[0000950170-24-054464:notes:101]
For the quarter ended April 3, 2023, potential shares of common stock, consisting of stock options to purchase approximately 60 shares of common stock at exercise prices ranging from $11.83 to $16.60 per share, 3,027 RSUs, and 606 performance-based restricted stock units (PRUs) were not included in the computation of diluted earnings per share because the Company incurred a net loss and as a result, the impact would be anti-dilutive.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0000950170-24-054464:notes:102]
[same as prior period, unchanged from 0000950170-23-060227:notes:142]

[0000950170-24-054464:notes:103]
Performance-based Restricted Stock Units

[0000950170-24-054464:notes:104]
The Company maintains a long-term incentive program for executives that provides for the issuance of PRUs, representing hypothetical shares of the Company’s common stock that may be issued. Under the PRU program, a target number of PRUs is awarded at the beginning of each three-year performance period. The number of shares of common stock released at the end of the performance period depends on performance during the period and may range from zero to 2.4 times the target number for PRUs awarded before 2023 and zero to 2.0 times the target number for PRUs awarded in 2023 and thereafter. For PRUs awarded before 2023, the performance metrics of the PRU program are based on (a) annual financial targets, which are based on revenue and earnings before interest, tax, depreciation, and amortization expense (EBITDA), each equally weighted, and (b) an overall modifier based on the Company’s total stockholder return (TSR) relative to a group of peer companies selected by the Company’s compensation committee, over the three-year performance period. For PRUs awarded in 2023 and thereafter, the performance metrics of the PRU program are based on (a) annual financial targets, which are based on revenue and EBITDA, each equally weighted, and (b) the three-year TSR performance result, which will be an additive component to the Company’s financial results of the aggregated three-year measurement period.

[0000950170-24-054464:notes:105]
Under the PRU program, financial goals with respect to one or more target milestones are set at the beginning of each fiscal year and performance is reviewed at the end of that year. The percentage to be applied to each participant’s target award ranges from zero to 160% for PRUs awarded before 2023 and zero to 200% for PRUs awarded in 2023 and thereafter, based upon the extent to which the target milestones are achieved. If specific performance threshold levels for the target milestones are met, the amount earned for that element over the three-year performance period will be applied to one-third for PRUs awarded before 2023 and 80% for PRUs awarded in 2023 and thereafter, of the participants’ PRU award to determine the number of units earned.

[0000950170-24-054464:notes:106]
At the end of the three-year performance period, the total units earned, if any, are adjusted by adding the TSR calculation. The TSR calculation is a percentage ranging from zero to 150% for PRUs awarded before 2023 and zero to 200% for PRUs awarded in 2023 and thereafter, determined on the Company’s TSR based on stock price changes relative to a group of peer companies selected by the Company’s compensation committee for the same three-year period. For outstanding PRU awards granted before 2023, the TSR is used as an overall modifier of the three-year performance period such that the base calculations are multiplied by the TSR modifier, ranging from zero to 200%, based on the relative performance of the Company’s stock price as compared to its TSR peer group. For PRUs awarded in 2023 and thereafter, the TSR calculation will be applied to 20% of the participants’ PRU award to determine the number of additional units earned.

[0000950170-24-054464:notes:107]
Stock-based Compensation Expense and Unrecognized Compensation Costs

[0000950170-24-054464:notes:108]
Stock-based compensation expense recognized in the accompanying consolidated condensed statements of operations was as follows:

[0000950170-24-054464:notes:109]
|  |  | Quarter Ended |  |
|  |  | April 1, 2024 |  |  | April 3, 2023 |  |
|  |  | (In thousands) |  |
| Cost of goods sold |  | $ | 2,029 |  |  | $ | 1,662 |  |
| Selling and marketing |  |  | 868 |  |  |  | 741 |  |
| General and administrative |  |  | 3,595 |  |  |  | 2,562 |  |
| Research and development |  |  | 295 |  |  |  | 275 |  |
| Stock-based compensation expense recognized |  | $ | 6,787 |  |  | $ | 5,240 |  |

[0000950170-24-054464:notes:110]
A summary of total unrecognized compensation costs as of April 1, 2024 was as follows:

[0000950170-24-054464:notes:111]
|  |  | Unrecognized Compensation Costs |  |  | Remaining Weighted AverageRecognition Period |  |
|  |  | (In thousands) |  |  | (In years) |  |
| RSU awards |  | $ | 29,451 |  |  |  | 1.4 |  |
| PRU awards |  |  | 4,631 |  |  |  | 1.3 |  |
| Total |  | $ | 34,082 |  |  |  |  |


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0000950170-24-054464:notes:112]
[same as prior period, unchanged from 0000950170-23-060227:notes:148]

[0000950170-24-054464:notes:113]
On February 8, 2023, the Company announced a consolidation plan, pursuant to which the Company ceased operations at three of its manufacturing facilities during the fiscal year ended January 1, 2024 and consolidated the operations of those facilities into other Company facilities. The three manufacturing facilities were PCB operations located in Anaheim and Santa Clara, California, and Hong Kong. The Company recorded $24,706 of restructuring charges and $5,161 of accelerated depreciation since the February 8, 2023 announcement.

[0000950170-24-054464:notes:114]
In addition to this consolidation plan, the Company recognized employee separation, contract termination, and other costs during the quarters ended April 1, 2024 and April 3, 2023 in connection with other global realignment restructuring efforts. Contract termination and other costs primarily represented plant closure costs.

[0000950170-24-054464:notes:115]
Restructuring costs by reportable segment were as follows:

[0000950170-24-054464:notes:116]
|  |  | Quarter Ended April 1, 2024 |  |
|  |  | EmployeeSeparation/Severance |  |  | ContractTerminationand OtherCosts |  |  | Total |  |
|  |  | (In thousands) |  |
| Reportable Segment: |  |  |  |  |  |  |  |  |  |
| PCB |  | $ | — |  |  | $ | 3,890 |  |  | $ | 3,890 |  |
| Corporate and Other |  |  | — |  |  |  | 48 |  |  |  | 48 |  |
| Total |  | $ | — |  |  | $ | 3,938 |  |  | $ | 3,938 |  |

[0000950170-24-054464:notes:117]
|  |  | Quarter Ended April 3, 2023 |  |
|  |  | EmployeeSeparation/Severance |  |  | ContractTerminationand OtherCosts |  |  | Total |  |
|  |  | (In thousands) |  |
| Reportable Segment: |  |  |  |  |  |  |  |  |  |
| PCB |  | $ | 3,757 |  |  | $ | 186 |  |  | $ | 3,943 |  |
| Corporate and Other |  |  | 126 |  |  |  | 98 |  |  |  | 224 |  |
| Total |  | $ | 3,883 |  |  | $ | 284 |  |  | $ | 4,167 |  |

[0000950170-24-054464:notes:118]
Accrued restructuring costs are included as a component of other current liabilities in the consolidated condensed balance sheet. The utilization of the accrued restructuring costs was as follows:

[0000950170-24-054464:notes:119]
|  |  | EmployeeSeparation/Severance |  |  | ContractTerminationand OtherCosts |  |  | Total |  |
|  |  | (In thousands) |  |
| Accrued as of January 1, 2024 |  | $ | 994 |  |  | $ | 185 |  |  | $ | 1,179 |  |
| Charged to expense |  |  | — |  |  |  | 3,938 |  |  |  | 3,938 |  |
| Amount paid |  |  | (206 | ) |  |  | (4,032 | ) |  |  | (4,238 | ) |
| Accrued as of April 1, 2024 |  | $ | 788 |  |  | $ | 91 |  |  | $ | 879 |  |
