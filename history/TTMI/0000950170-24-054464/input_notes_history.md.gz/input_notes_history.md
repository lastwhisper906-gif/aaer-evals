# TTMI note change history — 0000950170-23-060227 → 0000950170-24-054464


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2024-05-07):
[0000950170-24-054464:note_history:1]
The Company is subject to various legal matters, which it considers normal for its business activities. While the Company currently believes that the amount of any reasonably possible loss for known matters would not be material to the Company’s financial condition, the outcome of these actions is inherently difficult to predict. In the event of an adverse outcome, the ultimate potential loss could have a material adverse effect on the Company’s financial condition or results of operations in a particular period. The Company has accrued amounts for its loss contingencies which are probable and estimable as of April 1, 2024 and January 1, 2024 and included as a component of other current liabilities. However, these amounts are not material to the consolidated condensed financial statements of the Company.
  (was, 2023-11-07, similarity 0.9926):
[0000950170-23-060227:note_history:1]
The Company is subject to various legal matters, which it considers normal for its business activities. While the Company currently believes that the amount of any reasonably possible loss for known matters would not be material to the Company’s financial condition, the outcome of these actions is inherently difficult to predict. In the event of an adverse outcome, the ultimate potential loss could have a material adverse effect on the Company’s financial condition or results of operations in a particular period. The Company has accrued amounts for its loss contingencies which are probable and estimable as of October 2, 2023 and January 2, 2023 and included as a component of other current liabilities. However, these amounts are not material to the consolidated condensed financial statements of the Company.

- changed (2024-05-07):
[0000950170-24-054464:note_history:2]
The Company has and may continue to enter into industrial cooperation agreements, sometimes referred to as offset agreements, as a condition to obtaining orders for products and services from customers in foreign countries. These agreements are intended to promote investment in the applicable country, and the Company’s obligations under these agreements may be satisfied through activities that do not require the Company to use cash, including transferring technology or providing manufacturing and other consulting support. The obligations under these agreements may also be satisfied through the use of cash for activities such as purchasing supplies from in-country vendors, setting up support centers, research and development investments, acquisitions, and building or leasing facilities for in-country operations. The amount of the offset requirement is determined by contract value awarded and negotiated percentages with customers. As of April 1, 2024, the Company had outstanding offset agreements of approximately $27,963, some of which extend through 2028. Offset programs usually extend over several years and in some cases provide for penalties in the event the Company fails to perform in accordance with contract requirements. To date, the Company has not been obligated to pay any such penalties.
  (was, 2023-11-07, similarity 0.8176):
[0000950170-23-060227:note_history:2]
The Company has and may continue to enter into industrial cooperation agreements, sometimes referred to as offset agreements, as a condition to obtaining orders for products and services from customers in foreign countries. These agreements are intended to promote investment in the applicable country, and the Company’s obligations under these agreements may be satisfied through activities that do not require the Company to use cash, including transferring technology or providing manufacturing and other consulting support. The obligations under these agreements may also be satisfied through the use of cash for activities such as purchasing supplies from in-country vendors, setting up support centers, research and development investments, acquisitions, and building or leasing facilities for in-country operations. The amount of the offset requirement is determined by contract value awarded

- added (2024-05-07):
[0000950170-24-054464:note_history:3]
Supplier Finance Program Obligations

- added (2024-05-07):
[0000950170-24-054464:note_history:4]
The Company has agreements with financial institutions to facilitate payments to certain suppliers. Under the terms of the agreements, the Company confirms the validity of each supplier invoice to the respective financial institution upon receipt. The supplier receives payment from the financial institution, and the Company pays the financial institution based on the terms negotiated, which generally range from 160 days to 360 days. Liabilities associated with these agreements are recorded in accounts payable on the consolidated condensed balance sheets and amounted to $17,689 and $18,832 as of April 1, 2024 and January 1, 2024, respectively.

- removed (2024-05-07):
[0000950170-23-060227:note_history:5]
and negotiated percentages with customers. As of October 2, 2023, the Company had outstanding offset agreements of approximately $27,963, some of which extend through 2028. Offset programs usually extend over several years and in some cases provide for penalties in the event the Company fails to perform in accordance with contract requirements. Historically, the Company has not paid any such penalties, and as of October 2, 2023, no such penalties have been paid.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureAndSignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2024-05-07):
[0000950170-24-054464:note_history:6]
TTM Technologies, Inc. (the Company or TTM) is a leading global manufacturer of technology solutions including mission systems, radio frequency (RF) components/RF microwave/microelectronic assemblies, and quick-turn and technologically advanced printed circuit boards (PCB). The Company provides time-to-market and volume production of advanced technology products and offers a one-stop design, engineering, and manufacturing solution to customers. This solution allows the Company to align technology developments with the diverse needs of the Company’s customers and to enable them to reduce the time required to develop new products and bring them to market.
  (was, 2023-11-07, similarity 0.9619):
[0000950170-23-060227:note_history:6]
TTM Technologies, Inc. (the Company or TTM) is a leading global manufacturer of technology solutions including mission systems, radio frequency (RF) components/RF microwave/microelectronic assemblies, quick-turn and technologically advanced printed circuit boards (PCB). The Company provides time-to-market and volume production of advanced technology products and offers a one-stop design, engineering, and manufacturing solution to customers. This one-stop design, engineering, and manufacturing solution allows the Company to align technology developments with the diverse needs of the Company’s customers and to enable them to reduce the time required to develop new products and bring them to market.

- changed (2024-05-07):
[0000950170-24-054464:note_history:7]
The Company serves a diversified customer base in various markets throughout the world, including aerospace and defense, data center computing, automotive, medical, industrial and instrumentation related products, and networking. The Company’s customers include original equipment manufacturers (OEMs), electronic manufacturing services (EMS) providers, original design manufacturers (ODMs), distributors, and government agencies (both domestic and allied foreign governments).
  (was, 2023-11-07, similarity 0.894):
[0000950170-23-060227:note_history:7]
The Company serves a diversified customer base in various markets throughout the world, including aerospace and defense, data center computing, automotive, medical, industrial and instrumentation related products, and networking. The Company’s customers include original equipment manufacturers (OEMs), electronic manufacturing services (EMS) providers, original design manufacturers (ODMs), distributors and government agencies.

- changed (2024-05-07):
[0000950170-24-054464:note_history:8]
The accompanying consolidated condensed financial statements have been prepared by the Company, without audit, pursuant to the rules and regulations of the Securities and Exchange Commission (SEC). Certain information and disclosures normally included in financial statements prepared in accordance with accounting principles generally accepted in the United States of America (U.S. GAAP) have been condensed or omitted pursuant to such rules and regulations. These consolidated condensed financial statements should be read in conjunction with the consolidated financial statements and the notes thereto included in the Company’s most recent Annual Report on Form 10-K. The preparation of financial statements in accordance with U.S. GAAP requires management to make estimates and assumptions that affect the amounts reported in the Company’s consolidated condensed financial statements and accompanying notes. Due, in part, to the conflict between Russia and Ukraine, and the conflict in Israel and the Gaza Strip, the global economy and financial markets have been volatile. The Company has considered information available to it as of the date of issuance of these financial statements and is not aware of any specific events or circumstances that would require an update to its estimates or judgments, or a revision to the carrying value of its assets or liabilities. The actual results the Company experienced may differ materially and adversely from its estimates. The Company uses a 52/53 week fiscal calendar with the fourth quarter ending on the Monday nearest December 31.
  (was, 2023-11-07, similarity 0.9323):
[0000950170-23-060227:note_history:8]
The accompanying consolidated condensed financial statements have been prepared by the Company, without audit, pursuant to the rules and regulations of the Securities and Exchange Commission (SEC). Certain information and disclosures normally included in financial statements prepared in accordance with accounting principles generally accepted in the United States of America (U.S. GAAP) have been condensed or omitted pursuant to such rules and regulations. These consolidated condensed financial statements should be read in conjunction with the consolidated financial statements and the notes thereto included in the Company’s most recent Annual Report on Form 10-K. The preparation of financial statements in accordance with U.S. GAAP requires management to make estimates and assumptions that affect the amounts reported in the Company’s consolidated condensed financial statements and accompanying notes. Due, in part, to the coronavirus (COVID-19) and its variants, the conflict between Russia and Ukraine, and the current conflict in Israel and the Gaza Strip, the global economy and financial markets have been volatile. In addition, the global economy and financial markets have experienced on-going disruptions in global supply chains, labor shortages, high inflation, and a potential recession. The Company has considered information available to it as of the date of issuance of these financial statements and is not aware of any specific events or circumstances that would require an update to its estimates or judgments, or a revision to the carrying value of its assets or liabilities. The actual results the Company experienced may differ materially and adversely from its estimates. The Company uses a 52/53 week fiscal calendar with the fourth quarter ending on the Monday nearest December 31.

- changed (2024-05-07):
[0000950170-24-054464:note_history:9]
Recently Issued Accounting Standards Not Yet Adopted
  (was, 2023-11-07, similarity 0.72):
[0000950170-23-060227:note_history:9]
Recently Adopted and Issued Accounting Standards

- added (2024-05-07):
[0000950170-24-054464:note_history:10]
In March 2024, the Financial Accounting Standards Board (FASB) issued Accounting Standards Update (ASU) 2024-02, Codification Improvements - Amendments to Remove References to the Concepts Statements, to remove various references to concepts statements from the Accounting Standards Codification (ASC). These amendments clarify guidance, simplify wording or structure of guidance, and other minor improvements. The amendments are effective for fiscal years beginning after December 15, 2024, applied prospectively, with early adoption and retrospective application permitted. The impact of the adoption of the amendments in this update is not expected to be material to the Company's consolidated financial statements and related disclosures.

- added (2024-05-07):
[0000950170-24-054464:note_history:11]
In December 2023, the FASB issued ASU 2023-09, Income Taxes (Topic 740): Improvements to Income Tax Disclosures, which requires disclosure of disaggregated income taxes paid, prescribes standard categories for the components of the effective tax rate reconciliation, and modifies other income tax-related disclosures. The update will be effective for annual periods beginning after December 15, 2024. Early adoption is permitted for annual financial statements not yet issued or made available for issuance. The Company is currently evaluating the new guidance to determine the impact it may have on its consolidated financial statements and related disclosures, but expects additional disclosures upon adoption.

- added (2024-05-07):
[0000950170-24-054464:note_history:12]
In November 2023, the FASB issued ASU 2023-07, Segment Reporting (Topic 280): Improvements to Reportable Segment Disclosures, which updates reportable segment disclosure requirements primarily through enhanced disclosures about significant segment expenses. The amendments are effective for fiscal years beginning after December 15, 2023, and for interim periods within fiscal years beginning after December 15, 2024. Early adoption is permitted. The amendments should be applied retrospectively to all prior periods presented in the financial statements. The Company is currently evaluating the new guidance to determine the impact it may have on its consolidated financial statements and related disclosures, but expects additional disclosures upon adoption.

- added (2024-05-07):
[0000950170-24-054464:note_history:13]
In October 2023, the FASB issued ASU 2023-06, Disclosure Improvements: Codification Amendments in Response to the Securities and Exchange Commission’s Disclosure Update and Simplification Initiative, which modifies the disclosure or presentation requirements of a variety of topics in the ASC in response to the SEC’s Release No. 33-10532, Disclosure Update and Simplification Initiative, and align the ASC requirements with the SEC’s regulations. For entities subject to the SEC's existing disclosure requirements, the effective date for each amendment will be the date on which the SEC's removal of that related disclosure from Regulation S-X or Regulation S-K becomes effective. However, if by June 30, 2027, the SEC has not removed the related disclosure from its regulations, the amendments will be removed from the Codification and not become effective. Early adoption is prohibited. The Company is currently evaluating the new guidance to determine the impact it may have on its consolidated financial statements and related disclosures.

- removed (2024-05-07):
[0000950170-23-060227:note_history:14]
Reclassifications

- removed (2024-05-07):
[0000950170-23-060227:note_history:15]
Certain amounts in the prior period financial statements have been reclassified to conform to the presentation of the current period financial statements. These reclassifications had no effect on the previously reported net income.

- removed (2024-05-07):
[0000950170-23-060227:note_history:16]
Recently Adopted Accounting Standards

- removed (2024-05-07):
[0000950170-23-060227:note_history:17]
In September 2022, the Financial Accounting Standards Board (FASB) issued Accounting Standards Update (ASU) 2022-04, Liabilities - Supplier Finance Programs (Topic 450-50): Disclosure of Supplier Finance Program Obligations, that requires entities that use supplier finance programs in connection with the purchase of goods and services to disclose the key terms of the programs and information about obligations outstanding at the end of the reporting period, including a rollforward of those obligations. The guidance does not affect the recognition, measurement or financial statement presentation of supplier finance program obligations. The amendments are effective for all entities for fiscal years beginning after December 15, 2022 on a retrospective basis, including interim periods within those fiscal years, except for the requirement to disclose rollforward information, which is effective prospectively for fiscal years beginning after December 15, 2023. The Company adopted ASU 2022-04 as of April 3, 2023. The Company has agreements with financial institutions to facilitate the payments to certain suppliers. Under the terms of the agreements, the Company confirms the validity of each supplier invoice to the respective financial institution upon receipt. The supplier receives payment from the financial institution, and the Company pays the financial institution based on the terms negotiated, which generally range from 160 days to 360 days. Liabilities associated with these agreements are recorded in accounts payable on the consolidated condensed balance sheets and amounted to $15,945 and $6,653 as of October 2, 2023 and January 2, 2023, respectively.

- removed (2024-05-07):
[0000950170-23-060227:note_history:18]
In December 2022, the FASB issued ASU 2022-06, Reference Rate Reform (Topic 848): Deferral of the Sunset Date of Topic 848, which deferred the sunset date of Topic 848 to December 31, 2024, after which entities will no longer be permitted to apply the optional expedients and exceptions in Topic 848. On March 23, 2023, the Company entered into a four-year pay-fixed, receive floating (1-month CME Term Secured Overnight Financing Rate (SOFR)), interest rate swap arrangement with a notional amount of $250,000 for the period beginning April 1, 2023 and ending on April 1, 2027. Under the terms of the interest rate swap, the Company pays a fixed rate of 3.49% against a portion of its Term SOFR-based debt and receives a floating 1-month CME Term SOFR during

- removed (2024-05-07):
[0000950170-23-060227:note_history:19]
the swap period. The Company elected optional expedients provided in Topic 848 which allow the designation of the interest rate swap as a cash flow hedge.


## ttmi:ScheduleOfUnamortizedDiscountAndDebtIssuanceCostsTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2024-05-07):
[0000950170-24-054464:note_history:20]
Remaining unamortized debt issuance costs and debt discount were as follows:
  (was, 2023-11-07, similarity 0.6383):
[0000950170-23-060227:note_history:20]
As of October 2, 2023 and January 2, 2023, remaining unamortized debt issuance costs and debt discount for the Senior Notes due 2029 and Term Loan Facility are as follows:

- changed (2024-05-07):
[0000950170-24-054464:note_history:21]
|  |  | As of April 1, 2024 |  | As of January 1, 2024 |
|  |  | DebtIssuance Costs |  |  | DebtDiscount |  |  | EffectiveInterest Rate |  | DebtIssuance Costs |  |  | DebtDiscount |  |  | EffectiveInterest Rate |
|  |  | (In thousands, except interest rates) |
| Senior Notes due March 2029 |  | $ | 3,907 |  |  | $ | — |  |  |  | 4.18 |  | % |  | $ | 4,085 |  |  | $ | — |  |  |  | 4.18 |  | % |
| Term Loan due May 2030 |  |  | 3,799 |  |  |  | 3,156 |  |  |  | 8.26 |  |  |  |  | 3,936 |  |  |  | 3,268 |  |  |  | 8.26 |  |  |
| Total |  | $ | 7,706 |  |  | $ | 3,156 |  |  |  |  |  |  | $ | 8,021 |  |  | $ | 3,268 |  |  |  |  |  |
  (was, 2023-11-07, similarity 0.7117):
[0000950170-23-060227:note_history:21]
|  |  | As of October 2, 2023 |  |  |  | As of January 2, 2023 |
|  |  | DebtIssuance Costs |  |  | DebtDiscount |  |  | EffectiveInterest Rate |  |  |  | DebtIssuance Costs |  |  | DebtDiscount |  |  | EffectiveInterest Rate |  |  |
|  |  | (In thousands, except interest rates) |
| Senior Notes due March 2029 |  | $ | 4,260 |  |  | $ | — |  |  |  | 4.18 |  | % |  | $ | 4,779 |  |  | $ | — |  |  |  | 4.18 |  | % |
| Term Loan due May 2030 |  |  | 4,052 |  |  |  | 3,364 |  |  |  | 8.26 |  |  |  |  | — |  |  |  | — |  |  |  | — |  |  |
| Term Loan due September 2024 |  |  | — |  |  |  | — |  |  |  | — |  |  |  |  | 1,301 |  |  |  | 392 |  |  |  | 4.66 |  |  |
|  |  | $ | 8,312 |  |  | $ | 3,364 |  |  |  |  |  |  | $ | 6,080 |  |  | $ | 392 |  |  |  |  |  |


## us-gaap:LongTermDebtTextBlock (debt) — matched_by: tag_name, score: 1.0

- added (2024-05-07):
[0000950170-24-054464:note_history:22]
Long-term debt was as follows:

- added (2024-05-07):
[0000950170-24-054464:note_history:23]
|  |  | As of April 1, 2024 |  |  | As of January 1, 2024 |  |
|  |  | Interest Rate |  | PrincipalOutstanding |  |  | Interest Rate |  | PrincipalOutstanding |  |
|  |  | (In thousands, except interest rates) |  |
| Senior Notes due March 2029 |  |  | 4.00 |  | % |  | $ | 500,000 |  |  |  | 4.00 |  | % |  | $ | 500,000 |  |
| Term Loan due May 2030 |  |  | 8.07 |  |  |  |  | 347,375 |  |  |  | 8.10 |  |  |  |  | 349,125 |  |
| Asia ABL Revolving Loan due June 2028 |  |  | 6.62 |  |  |  |  | 80,000 |  |  |  | 6.65 |  |  |  |  | 80,000 |  |
| Total debt |  |  |  |  |  |  | 927,375 |  |  |  |  |  |  |  | 929,125 |  |
| Less: Unamortized debt issuance costs |  |  |  |  |  |  | (7,706 | ) |  |  |  |  |  |  | (8,021 | ) |
| Less: Unamortized debt discount |  |  |  |  |  |  | (3,156 | ) |  |  |  |  |  |  | (3,268 | ) |
| Subtotal |  |  |  |  |  |  | 916,513 |  |  |  |  |  |  |  | 917,836 |  |
| Less: current maturities |  |  |  |  |  |  | (2,625 | ) |  |  |  |  |  |  | (3,500 | ) |
| Long-term debt, less current maturities |  |  |  |  |  | $ | 913,888 |  |  |  |  |  |  | $ | 914,336 |  |

- changed (2024-05-07):
[0000950170-24-054464:note_history:24]
Borrowings under the Senior Notes due March 2029 and Term Loan due May 2030 (Term Loan Facility) are subject to certain affirmative and negative covenants, including limitations on indebtedness, corporate transactions, investments, dispositions, and restricted payments.
  (was, 2023-11-07, similarity 0.916):
[0000950170-23-060227:note_history:24]
Borrowings under the Senior Notes due 2029 and Term Loan Facility are subject to certain affirmative and negative covenants, including limitations on indebtedness, corporate transactions, investments, dispositions, and restricted payments.

- changed (2024-05-07):
[0000950170-24-054464:note_history:25]
Debt Issuance Costs and Debt Discount
  (was, 2023-11-07, similarity 0.9118):
[0000950170-23-060227:note_history:25]
Debt Issuance and Debt Discount

- changed (2024-05-07):
[0000950170-24-054464:note_history:26]
Remaining unamortized debt issuance costs and debt discount were as follows:
  (was, 2023-11-07, similarity 0.6383):
[0000950170-23-060227:note_history:26]
As of October 2, 2023 and January 2, 2023, remaining unamortized debt issuance costs and debt discount for the Senior Notes due 2029 and Term Loan Facility are as follows:

- changed (2024-05-07):
[0000950170-24-054464:note_history:27]
|  |  | As of April 1, 2024 |  | As of January 1, 2024 |
|  |  | DebtIssuance Costs |  |  | DebtDiscount |  |  | EffectiveInterest Rate |  | DebtIssuance Costs |  |  | DebtDiscount |  |  | EffectiveInterest Rate |
|  |  | (In thousands, except interest rates) |
| Senior Notes due March 2029 |  | $ | 3,907 |  |  | $ | — |  |  |  | 4.18 |  | % |  | $ | 4,085 |  |  | $ | — |  |  |  | 4.18 |  | % |
| Term Loan due May 2030 |  |  | 3,799 |  |  |  | 3,156 |  |  |  | 8.26 |  |  |  |  | 3,936 |  |  |  | 3,268 |  |  |  | 8.26 |  |  |
| Total |  | $ | 7,706 |  |  | $ | 3,156 |  |  |  |  |  |  | $ | 8,021 |  |  | $ | 3,268 |  |  |  |  |  |
  (was, 2023-11-07, similarity 0.7117):
[0000950170-23-060227:note_history:27]
|  |  | As of October 2, 2023 |  |  |  | As of January 2, 2023 |
|  |  | DebtIssuance Costs |  |  | DebtDiscount |  |  | EffectiveInterest Rate |  |  |  | DebtIssuance Costs |  |  | DebtDiscount |  |  | EffectiveInterest Rate |  |  |
|  |  | (In thousands, except interest rates) |
| Senior Notes due March 2029 |  | $ | 4,260 |  |  | $ | — |  |  |  | 4.18 |  | % |  | $ | 4,779 |  |  | $ | — |  |  |  | 4.18 |  | % |
| Term Loan due May 2030 |  |  | 4,052 |  |  |  | 3,364 |  |  |  | 8.26 |  |  |  |  | — |  |  |  | — |  |  |  | — |  |  |
| Term Loan due September 2024 |  |  | — |  |  |  | — |  |  |  | — |  |  |  |  | 1,301 |  |  |  | 392 |  |  |  | 4.66 |  |  |
|  |  | $ | 8,312 |  |  | $ | 3,364 |  |  |  |  |  |  | $ | 6,080 |  |  | $ | 392 |  |  |  |  |  |

- changed (2024-05-07):
[0000950170-24-054464:note_history:28]
The remaining unamortized debt issuance costs for the ABL Revolving Loans of $1,512 and $1,603 as of April 1, 2024 and January 1, 2024, respectively, are included in deposits and other non-current assets and are amortized to interest expense over the duration of the ABL Revolving Loans using the straight-line method of amortization.
  (was, 2023-11-07, similarity 0.9599):
[0000950170-23-060227:note_history:28]
The remaining unamortized debt issuance costs for the ABL Revolving Loans of $1,695 and $792 as of October 2, 2023 and January 2, 2023, respectively, are included in other non-current assets and are amortized to interest expense over the duration of the ABL Revolving Loans using the straight-line method of amortization.

- changed (2024-05-07):
[0000950170-24-054464:note_history:29]
As of April 1, 2024, the remaining weighted average amortization period for all unamortized debt issuance costs and debt discount was 5.5 years.
  (was, 2023-11-07, similarity 0.9638):
[0000950170-23-060227:note_history:29]
As of October 2, 2023, the remaining weighted average amortization period for all unamortized debt issuance costs and debt discount was 6.0 years.

- removed (2024-05-07):
[0000950170-23-060227:note_history:30]
The following table summarizes the long-term debt of the Company as of October 2, 2023 and January 2, 2023:

- removed (2024-05-07):
[0000950170-23-060227:note_history:31]
|  |  | Interest Rate as ofOctober 2, 2023 |  |  |  | PrincipalOutstandingas ofOctober 2, 2023 |  |  | Interest Rate as ofJanuary 2, 2023 |  |  |  | PrincipalOutstandingas ofJanuary 2, 2023 |  |
|  |  | (In thousands, except interest rates) |  |
| Senior Notes due March 2029 |  |  | 4.00 |  | % |  | $ | 500,000 |  |  |  | 4.00 |  | % |  | $ | 500,000 |  |
| Term Loan due May 2030 |  |  | 8.07 |  |  |  |  | 349,125 |  |  |  | — |  |  |  |  | — |  |
| Asia ABL Revolving Loan due June 2028 |  |  | 6.62 |  |  |  |  | 30,000 |  |  |  | 5.79 |  |  |  |  | 30,000 |  |
| Term Loan due September 2024 |  |  | — |  |  |  |  | — |  |  |  | 6.89 |  |  |  |  | 405,879 |  |
|  |  |  |  |  |  |  | 879,125 |  |  |  |  |  |  |  | 935,879 |  |
| Less: Long-term debt unamortized debt issuance costs |  |  |  |  |  |  | (8,312 | ) |  |  |  |  |  |  | (6,080 | ) |
| Long-term debt unamortized discount |  |  |  |  |  |  | (3,364 | ) |  |  |  |  |  |  | (392 | ) |
|  |  |  |  |  |  |  | 867,449 |  |  |  |  |  |  |  | 929,407 |  |
| Less: current maturities |  |  |  |  |  |  | (2,625 | ) |  |  |  |  |  |  | (50,000 | ) |
| Long-term debt, less current maturities |  |  |  |  |  | $ | 864,824 |  |  |  |  |  |  | $ | 879,407 |  |

- removed (2024-05-07):
[0000950170-23-060227:note_history:32]
Term Loan Facility

- removed (2024-05-07):
[0000950170-23-060227:note_history:33]
On May 30, 2023, pursuant to an Amended & Restated Term Loan Credit Agreement by and among the Company, JPMorgan Chase Bank, N.A., as Administrative Agent, and the several lenders from time to time parties thereto (Term Loan Credit Agreement), the Company closed its $350,000 senior secured Term Loan due 2030 (Term Loan Facility). This Term Loan Facility had an outstanding balance of $349,125 as of October 2, 2023, of which $2,625 is included in short-term debt and $346,500 is included in long-term debt. The Term Loan Facility was issued with a 1.0% original issue discount and bears interest at a floating rate of 1-month CME Term SOFR plus an applicable margin of 2.75%. There is no provision, other than an event of default, for the interest margin to increase. The Company is required to make quarterly principal repayments in an aggregate annual amount equal to 1% of the initial aggregate principal amount of the Term Loan Facility. Such principal repayment is payable quarterly on January 1, April 1, July 1, and October 1 and ending with the last such day to occur prior to May 30, 2030. The remaining principal under the Term Loan Facility is scheduled to mature on May 30, 2030. In addition, the Term Loan Credit Agreement permits the Company to add one or more senior secured incremental term loan facilities to the Term Loan Facility subject to the satisfaction of certain conditions.

- removed (2024-05-07):
[0000950170-23-060227:note_history:34]
The Company used $234,818 under the Term Loan Facility and $115,182 of cashless rollover from continuing lenders, together with cash on hand, to refinance the full amount of indebtedness outstanding under the Company’s previous Term Loan Facility that was due to mature in 2024, as well as to pay related fees and expenses.

- removed (2024-05-07):
[0000950170-23-060227:note_history:35]
The obligations under the Term Loan Facility are unconditionally guaranteed by each Subsidiary Guarantor of the Company, subject to certain exceptions (Guarantors). The Term Loan Facility is secured by (i) a perfected first priority security interest in substantially all of the assets of the Company and the Guarantors (other than the U.S. ABL Priority Collateral (as defined below)), including all of the total outstanding voting capital stock held by the Company and the Guarantors (subject to a limitation of 65% on pledges of such capital stock of certain foreign subsidiaries and domestic holding companies of foreign subsidiaries) and (ii) a perfected second priority interest in all of the U.S. ABL Priority Collateral. The Term Loan Facility is structurally senior to the Company’s Senior Notes due 2029.

- removed (2024-05-07):
[0000950170-23-060227:note_history:36]
Asset-Based Lending Agreements

- removed (2024-05-07):
[0000950170-23-060227:note_history:37]
The Company amended and restated its U.S. Asset-Based Lending Credit Agreement (U.S. ABL) on May 30, 2023 and its Asia Asset-Based Lending Credit Agreement (Asia ABL) on June 14, 2023. Both agreements were amended for the benchmark interest rate and margins and maturity was extended to May 2028 and June 2028 for the U.S. ABL and the Asia ABL, respectively.

- removed (2024-05-07):
[0000950170-23-060227:note_history:38]
The U.S. ABL is comprised of a revolving credit facility for up to $150,000 and a sublimit for letter of credit for up to $50,000, provided that at no time may amounts outstanding under the agreement exceed in the aggregate $150,000 or the applicable borrowing base, which is the sum of (i) a percentage of the principal amount of “Eligible Accounts”, plus (ii) a percentage of the net orderly liquidation value of (x) “Eligible Inventory”, minus (y) “Inventory Reserves” applicable thereto, minus (iii) “Reserves”, each as defined in the U.S. ABL agreement.

- removed (2024-05-07):
[0000950170-23-060227:note_history:39]
Borrowings under the U.S. ABL bear interest at a floating rate of Term SOFR plus a margin ranging from 1.25% to 1.50%. The applicable margin can vary based on the remaining availability of the facility, from 1.25% to 1.50% for Term SOFR-based loans and from 0.25% to 0.50% for JPMorgan Chase Bank’s prime rate-based loans. Other than availability and an event of default, there are no other provisions for the interest margin to increase. The Company is also required to pay certain fees in connection with the U.S. ABL

- removed (2024-05-07):
[0000950170-23-060227:note_history:40]
agreement, including unused commitment fees based on the average daily unused portion of the U.S. ABL facility, equal to 0.25% on an annual basis.

- removed (2024-05-07):
[0000950170-23-060227:note_history:41]
The U.S. ABL is scheduled to mature on May 30, 2028. The Guarantors have also fully guaranteed the full and timely payment of all obligations in respect of the U.S. ABL. Loans made under the U.S. ABL are secured by a perfected first priority security interest in certain deposit accounts, cash and cash equivalents, accounts receivable and certain U.S. inventory (U.S. ABL Priority Collateral) as well as by a perfected second priority interest in all of the collateral securing the Term Loan Facility.

- removed (2024-05-07):
[0000950170-23-060227:note_history:42]
The Asia ABL is comprised of a revolving credit facility for up to $150,000 and a sublimit for letter of credit for up to $100,000, provided that at no time may amounts outstanding under the agreement exceed in aggregate $150,000 or the applicable borrowing base, which is a percentage of the principal amount of Eligible Accounts, as defined in the Asia ABL agreement.

- removed (2024-05-07):
[0000950170-23-060227:note_history:43]
Borrowings under the Asia ABL bear interest at a floating rate of Term SOFR plus 1.30%. There is no provision, other than an event of default, for the interest margin to increase. The Company is also required to pay certain fees in connection with the Asia ABL agreement, including unused commitment fees based on the average daily unused portion of the Asia ABL facility, equal to 0.25% on an annual basis.

- removed (2024-05-07):
[0000950170-23-060227:note_history:44]
The Asia ABL is scheduled to mature on June 13, 2028. Loans made under the Asia ABL are secured by a portion of the Company’s Asia Pacific cash and receivables and are structurally senior to the Company’s domestic obligations, including the Senior Notes due 2029.

- removed (2024-05-07):
[0000950170-23-060227:note_history:45]
As of October 2, 2023, letters of credit in the amount of $6,191 were outstanding under the U.S. ABL and $21,961 were outstanding under the Asia ABL with various maturities through November 2024. Available borrowing capacity under the U.S. ABL and the Asia ABL was $143,809 and $98,039, respectively, which considers letters of credit outstanding as of October 2, 2023.

- removed (2024-05-07):
[0000950170-23-060227:note_history:46]
Loss on Extinguishment of Debt

- removed (2024-05-07):
[0000950170-23-060227:note_history:47]
During the three quarters ended October 2, 2023, the Company recognized loss on extinguishment of debt of $1,154, primarily associated with the write-off of the remaining unamortized debt issuance costs and debt discount as a result of the repayment of the remaining outstanding balance of the Term Loan Facility that was due to mature September 2024.


## us-gaap:ScheduleOfDebtInstrumentsTextBlock (debt) — matched_by: tag_name, score: 1.0

- added (2024-05-07):
[0000950170-24-054464:note_history:48]
Long-term debt was as follows:

- added (2024-05-07):
[0000950170-24-054464:note_history:49]
|  |  | As of April 1, 2024 |  |  | As of January 1, 2024 |  |
|  |  | Interest Rate |  | PrincipalOutstanding |  |  | Interest Rate |  | PrincipalOutstanding |  |
|  |  | (In thousands, except interest rates) |  |
| Senior Notes due March 2029 |  |  | 4.00 |  | % |  | $ | 500,000 |  |  |  | 4.00 |  | % |  | $ | 500,000 |  |
| Term Loan due May 2030 |  |  | 8.07 |  |  |  |  | 347,375 |  |  |  | 8.10 |  |  |  |  | 349,125 |  |
| Asia ABL Revolving Loan due June 2028 |  |  | 6.62 |  |  |  |  | 80,000 |  |  |  | 6.65 |  |  |  |  | 80,000 |  |
| Total debt |  |  |  |  |  |  | 927,375 |  |  |  |  |  |  |  | 929,125 |  |
| Less: Unamortized debt issuance costs |  |  |  |  |  |  | (7,706 | ) |  |  |  |  |  |  | (8,021 | ) |
| Less: Unamortized debt discount |  |  |  |  |  |  | (3,156 | ) |  |  |  |  |  |  | (3,268 | ) |
| Subtotal |  |  |  |  |  |  | 916,513 |  |  |  |  |  |  |  | 917,836 |  |
| Less: current maturities |  |  |  |  |  |  | (2,625 | ) |  |  |  |  |  |  | (3,500 | ) |
| Long-term debt, less current maturities |  |  |  |  |  | $ | 913,888 |  |  |  |  |  |  | $ | 914,336 |  |

- removed (2024-05-07):
[0000950170-23-060227:note_history:50]
The following table summarizes the long-term debt of the Company as of October 2, 2023 and January 2, 2023:

- removed (2024-05-07):
[0000950170-23-060227:note_history:51]
|  |  | Interest Rate as ofOctober 2, 2023 |  |  |  | PrincipalOutstandingas ofOctober 2, 2023 |  |  | Interest Rate as ofJanuary 2, 2023 |  |  |  | PrincipalOutstandingas ofJanuary 2, 2023 |  |
|  |  | (In thousands, except interest rates) |  |
| Senior Notes due March 2029 |  |  | 4.00 |  | % |  | $ | 500,000 |  |  |  | 4.00 |  | % |  | $ | 500,000 |  |
| Term Loan due May 2030 |  |  | 8.07 |  |  |  |  | 349,125 |  |  |  | — |  |  |  |  | — |  |
| Asia ABL Revolving Loan due June 2028 |  |  | 6.62 |  |  |  |  | 30,000 |  |  |  | 5.79 |  |  |  |  | 30,000 |  |
| Term Loan due September 2024 |  |  | — |  |  |  |  | — |  |  |  | 6.89 |  |  |  |  | 405,879 |  |
|  |  |  |  |  |  |  | 879,125 |  |  |  |  |  |  |  | 935,879 |  |
| Less: Long-term debt unamortized debt issuance costs |  |  |  |  |  |  | (8,312 | ) |  |  |  |  |  |  | (6,080 | ) |
| Long-term debt unamortized discount |  |  |  |  |  |  | (3,364 | ) |  |  |  |  |  |  | (392 | ) |
|  |  |  |  |  |  |  | 867,449 |  |  |  |  |  |  |  | 929,407 |  |
| Less: current maturities |  |  |  |  |  |  | (2,625 | ) |  |  |  |  |  |  | (50,000 | ) |
| Long-term debt, less current maturities |  |  |  |  |  | $ | 864,824 |  |  |  |  |  |  | $ | 879,407 |  |


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2024-05-07):
[0000950170-24-054464:note_history:52]
Disaggregated revenue by principal end markets with reportable segments was as follows:
  (was, 2023-11-07, similarity 0.7):
[0000950170-23-060227:note_history:52]
The following tables represent a disaggregation of revenue by principal end markets with the reportable segments:

- changed (2024-05-07):
[0000950170-24-054464:note_history:53]
|  |  | Quarter Ended April 1, 2024 |  |
|  |  | PCB |  |  | RF and Specialty Components(RF&S Components) |  |  | Total |  |
|  |  | (In thousands) |  |
| End Markets: |  |  |  |  |  |  |  |  |  |
| Aerospace and Defense |  | $ | 264,776 |  |  | $ | — |  |  | $ | 264,776 |  |
| Automotive |  |  | 73,617 |  |  |  | — |  |  |  | 73,617 |  |
| Data Center Computing |  |  | 119,377 |  |  |  | 59 |  |  |  | 119,436 |  |
| Medical/Industrial/Instrumentation |  |  | 78,793 |  |  |  | 734 |  |  |  | 79,527 |  |
| Networking |  |  | 25,278 |  |  |  | 7,479 |  |  |  | 32,757 |  |
| Total |  | $ | 561,841 |  |  | $ | 8,272 |  |  | $ | 570,113 |  |
  (was, 2023-11-07, similarity 0.6342):
[0000950170-23-060227:note_history:53]
|  |  | Three Quarters Ended October 2, 2023 |  |  | Three Quarters Ended October 3, 2022 (1) |  |  |
|  |  | PCB |  |  | RF&S Components |  |  | Total |  |  | PCB |  |  | RF&S Components |  |  | Total |  |  |
| End Markets |  | (In thousands) |  |  |
| Aerospace and Defense |  | $ | 742,194 |  |  | $ | — |  |  | $ | 742,194 |  |  | $ | 616,141 |  |  | $ | — |  |  | $ | 616,141 |  |  |
| Automotive |  |  | 272,644 |  |  |  | — |  |  |  | 272,644 |  |  |  | 327,825 |  |  |  | — |  |  |  | 327,825 |  |  |
| Data Center Computing |  |  | 221,759 |  |  |  | 51 |  |  |  | 221,810 |  |  |  | 293,802 |  |  |  | 33 |  |  |  | 293,835 |  |  |
| Medical/Industrial/Instrumentation |  |  | 279,565 |  |  |  | 2,557 |  |  |  | 282,122 |  |  |  | 379,867 |  |  |  | 5,023 |  |  |  | 384,890 |  |  |
| Networking |  |  | 118,156 |  |  |  | 26,602 |  |  |  | 144,758 |  |  |  | 211,590 |  |  |  | 41,360 |  |  |  | 252,950 |  |  |
| Other |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 3,449 |  |  |  | (1,200 | ) |  |  | 2,249 |  |  |
| Total |  | $ | 1,634,318 |  |  | $ | 29,210 |  |  | $ | 1,663,528 |  |  | $ | 1,832,674 |  |  | $ | 45,216 |  |  | $ | 1,877,890 |  |  |

- added (2024-05-07):
[0000950170-24-054464:note_history:54]
|  |  | Quarter Ended April 3, 2023 |  |
|  |  | PCB |  |  | RF&S Components |  |  | Total |  |
|  |  | (In thousands) |  |
| End Markets: |  |  |  |  |  |  |  |  |  |
| Aerospace and Defense |  | $ | 232,292 |  |  | $ | — |  |  | $ | 232,292 |  |
| Automotive |  |  | 93,467 |  |  |  | — |  |  |  | 93,467 |  |
| Data Center Computing |  |  | 57,870 |  |  |  | — |  |  |  | 57,870 |  |
| Medical/Industrial/Instrumentation |  |  | 100,768 |  |  |  | 917 |  |  |  | 101,685 |  |
| Networking |  |  | 49,714 |  |  |  | 9,409 |  |  |  | 59,123 |  |
| Total |  | $ | 534,111 |  |  | $ | 10,326 |  |  | $ | 544,437 |  |

- removed (2024-05-07):
[0000950170-23-060227:note_history:55]
|  |  | Quarter Ended October 2, 2023 |  |  | Quarter Ended October 3, 2022 (1) |  |
|  |  | PCB |  |  | RF&S Components |  |  | Total |  |  | PCB |  |  | RF&S Components |  |  | Total |  |
| End Markets |  | (In thousands) |  |
| Aerospace and Defense |  | $ | 255,618 |  |  | $ | — |  |  | $ | 255,618 |  |  | $ | 254,285 |  |  | $ | — |  |  | $ | 254,285 |  |
| Automotive |  |  | 86,803 |  |  |  | — |  |  |  | 86,803 |  |  |  | 100,811 |  |  |  | — |  |  |  | 100,811 |  |
| Data Center Computing |  |  | 99,584 |  |  |  | — |  |  |  | 99,584 |  |  |  | 95,830 |  |  |  | 13 |  |  |  | 95,843 |  |
| Medical/Industrial/Instrumentation |  |  | 89,818 |  |  |  | 895 |  |  |  | 90,713 |  |  |  | 128,444 |  |  |  | 1,239 |  |  |  | 129,683 |  |
| Networking |  |  | 31,853 |  |  |  | 8,011 |  |  |  | 39,864 |  |  |  | 78,181 |  |  |  | 12,494 |  |  |  | 90,675 |  |
| Other |  |  | — |  |  |  | — |  |  |  | — |  |  |  | (376 | ) |  |  | 159 |  |  |  | (217 | ) |
| Total |  | $ | 563,676 |  |  | $ | 8,906 |  |  | $ | 572,582 |  |  | $ | 657,175 |  |  | $ | 13,905 |  |  | $ | 671,080 |  |

- removed (2024-05-07):
[0000950170-23-060227:note_history:56]
(1)
Amended for Telephonics integration.


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2024-05-07):
[0000950170-24-054464:note_history:57]
As of April 1, 2024, the aggregate amount of the transaction price allocated to remaining performance obligations for long-term contracts was $385,265. The Company expects to recognize revenue on approximately 49% of the remaining performance obligations for the Company’s long-term contracts over the next 12 months with the remaining amount expected to be recognized thereafter.
  (was, 2023-11-07, similarity 0.9526):
[0000950170-23-060227:note_history:57]
As of October 2, 2023, the aggregate amount of the transaction price allocated to remaining performance obligations for long-term contracts was $353,941. The Company expects to recognize revenue on approximately 56% of the remaining performance obligations for the Company’s long-term contracts over the next twelve months with the remaining amount expected to be recognized thereafter.

- changed (2024-05-07):
[0000950170-24-054464:note_history:58]
For contracts in which anticipated total costs exceed the total expected revenue, an estimated loss is recognized in the period when identifiable. A provision for the entire amount of the estimated loss is recorded on a cumulative basis. The estimated remaining costs to complete for loss contracts as of April 1, 2024 and January 1, 2024 were $34,044 and $25,213, respectively.
  (was, 2023-11-07, similarity 0.9833):
[0000950170-23-060227:note_history:58]
For contracts in which anticipated total costs exceed the total expected revenue, an estimated loss is recognized in the period when identifiable. A provision for the entire amount of the estimated loss is recorded on a cumulative basis. The estimated remaining costs to complete for loss contracts as of October 2, 2023 and January 2, 2023 were $19,202 and $21,632, respectively.

- changed (2024-05-07):
[0000950170-24-054464:note_history:59]
Revenue recognized for the quarter ended April 1, 2024 from amounts recorded as contract liabilities as of January 1, 2024 was $18,214. Revenue recognized for the quarter ended April 3, 2023 from amounts recorded as contract liabilities as of January 2, 2023 was $18,508.
  (was, 2023-11-07, similarity 0.6273):
[0000950170-23-060227:note_history:59]
Revenue recognized for the three quarters ended October 2, 2023 from amounts recorded as contract liabilities as of January 2, 2023 was $33,939.

- changed (2024-05-07):
[0000950170-24-054464:note_history:60]
Revenue from products and services transferred to customers over time and at a point in time accounted for 96% and 4%, respectively, of the Company’s revenue for the quarters ended April 1, 2024 and April 3, 2023.
  (was, 2023-11-07, similarity 0.6667):
[0000950170-23-060227:note_history:60]
Revenue from products and services transferred to customers over time and at a point in time accounted for 96% and 4%, respectively, of the Company’s revenue for the quarter and three quarters ended October 2, 2023, and 98% and 2%, respectively, of the Company’s revenue for the quarter and three quarters ended October 3, 2022.

- changed (2024-05-07):
[0000950170-24-054464:note_history:61]
Disaggregated revenue by principal end markets with reportable segments was as follows:
  (was, 2023-11-07, similarity 0.7):
[0000950170-23-060227:note_history:61]
The following tables represent a disaggregation of revenue by principal end markets with the reportable segments:

- changed (2024-05-07):
[0000950170-24-054464:note_history:62]
|  |  | Quarter Ended April 1, 2024 |  |
|  |  | PCB |  |  | RF and Specialty Components(RF&S Components) |  |  | Total |  |
|  |  | (In thousands) |  |
| End Markets: |  |  |  |  |  |  |  |  |  |
| Aerospace and Defense |  | $ | 264,776 |  |  | $ | — |  |  | $ | 264,776 |  |
| Automotive |  |  | 73,617 |  |  |  | — |  |  |  | 73,617 |  |
| Data Center Computing |  |  | 119,377 |  |  |  | 59 |  |  |  | 119,436 |  |
| Medical/Industrial/Instrumentation |  |  | 78,793 |  |  |  | 734 |  |  |  | 79,527 |  |
| Networking |  |  | 25,278 |  |  |  | 7,479 |  |  |  | 32,757 |  |
| Total |  | $ | 561,841 |  |  | $ | 8,272 |  |  | $ | 570,113 |  |
  (was, 2023-11-07, similarity 0.6342):
[0000950170-23-060227:note_history:62]
|  |  | Three Quarters Ended October 2, 2023 |  |  | Three Quarters Ended October 3, 2022 (1) |  |  |
|  |  | PCB |  |  | RF&S Components |  |  | Total |  |  | PCB |  |  | RF&S Components |  |  | Total |  |  |
| End Markets |  | (In thousands) |  |  |
| Aerospace and Defense |  | $ | 742,194 |  |  | $ | — |  |  | $ | 742,194 |  |  | $ | 616,141 |  |  | $ | — |  |  | $ | 616,141 |  |  |
| Automotive |  |  | 272,644 |  |  |  | — |  |  |  | 272,644 |  |  |  | 327,825 |  |  |  | — |  |  |  | 327,825 |  |  |
| Data Center Computing |  |  | 221,759 |  |  |  | 51 |  |  |  | 221,810 |  |  |  | 293,802 |  |  |  | 33 |  |  |  | 293,835 |  |  |
| Medical/Industrial/Instrumentation |  |  | 279,565 |  |  |  | 2,557 |  |  |  | 282,122 |  |  |  | 379,867 |  |  |  | 5,023 |  |  |  | 384,890 |  |  |
| Networking |  |  | 118,156 |  |  |  | 26,602 |  |  |  | 144,758 |  |  |  | 211,590 |  |  |  | 41,360 |  |  |  | 252,950 |  |  |
| Other |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 3,449 |  |  |  | (1,200 | ) |  |  | 2,249 |  |  |
| Total |  | $ | 1,634,318 |  |  | $ | 29,210 |  |  | $ | 1,663,528 |  |  | $ | 1,832,674 |  |  | $ | 45,216 |  |  | $ | 1,877,890 |  |  |

- added (2024-05-07):
[0000950170-24-054464:note_history:63]
|  |  | Quarter Ended April 3, 2023 |  |
|  |  | PCB |  |  | RF&S Components |  |  | Total |  |
|  |  | (In thousands) |  |
| End Markets: |  |  |  |  |  |  |  |  |  |
| Aerospace and Defense |  | $ | 232,292 |  |  | $ | — |  |  | $ | 232,292 |  |
| Automotive |  |  | 93,467 |  |  |  | — |  |  |  | 93,467 |  |
| Data Center Computing |  |  | 57,870 |  |  |  | — |  |  |  | 57,870 |  |
| Medical/Industrial/Instrumentation |  |  | 100,768 |  |  |  | 917 |  |  |  | 101,685 |  |
| Networking |  |  | 49,714 |  |  |  | 9,409 |  |  |  | 59,123 |  |
| Total |  | $ | 534,111 |  |  | $ | 10,326 |  |  | $ | 544,437 |  |

- removed (2024-05-07):
[0000950170-23-060227:note_history:64]
|  |  | Quarter Ended October 2, 2023 |  |  | Quarter Ended October 3, 2022 (1) |  |
|  |  | PCB |  |  | RF&S Components |  |  | Total |  |  | PCB |  |  | RF&S Components |  |  | Total |  |
| End Markets |  | (In thousands) |  |
| Aerospace and Defense |  | $ | 255,618 |  |  | $ | — |  |  | $ | 255,618 |  |  | $ | 254,285 |  |  | $ | — |  |  | $ | 254,285 |  |
| Automotive |  |  | 86,803 |  |  |  | — |  |  |  | 86,803 |  |  |  | 100,811 |  |  |  | — |  |  |  | 100,811 |  |
| Data Center Computing |  |  | 99,584 |  |  |  | — |  |  |  | 99,584 |  |  |  | 95,830 |  |  |  | 13 |  |  |  | 95,843 |  |
| Medical/Industrial/Instrumentation |  |  | 89,818 |  |  |  | 895 |  |  |  | 90,713 |  |  |  | 128,444 |  |  |  | 1,239 |  |  |  | 129,683 |  |
| Networking |  |  | 31,853 |  |  |  | 8,011 |  |  |  | 39,864 |  |  |  | 78,181 |  |  |  | 12,494 |  |  |  | 90,675 |  |
| Other |  |  | — |  |  |  | — |  |  |  | — |  |  |  | (376 | ) |  |  | 159 |  |  |  | (217 | ) |
| Total |  | $ | 563,676 |  |  | $ | 8,906 |  |  | $ | 572,582 |  |  | $ | 657,175 |  |  | $ | 13,905 |  |  | $ | 671,080 |  |

- removed (2024-05-07):
[0000950170-23-060227:note_history:65]
(1)
Amended for Telephonics integration.
