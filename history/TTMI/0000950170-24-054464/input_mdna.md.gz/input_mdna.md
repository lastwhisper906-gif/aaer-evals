# TTMI MD&A — 0000950170-24-054464


## mdna

[0000950170-24-054464:mdna:1]
[same as prior period, unchanged from 0000950170-23-060227:mdna:1]

[0000950170-24-054464:mdna:2]
[same as prior period, unchanged from 0000950170-23-060227:mdna:2]

[0000950170-24-054464:mdna:3]
This Quarterly Report on Form 10-Q (Report) contains forward-looking statements regarding future events or our future financial and operational performance. Forward-looking statements include statements regarding markets for our products; trends in net sales, gross profits, and estimated expense levels; liquidity and anticipated cash needs and availability; and any statement that contains the words “anticipate,” “believe,” “plan,” “forecast,” “foresee,” “estimate,” “project,” “expect,” “seek,” “target,” “intend,” “goal,” and other similar expressions. The forward-looking statements included in this report reflect our current expectations and beliefs, and we do not undertake publicly to update or revise these statements, even if experience or future changes make it clear that any projected results expressed in this report or future quarterly reports to stockholders, press releases, or company statements will not be realized. In addition, the inclusion of any statement in this report does not constitute an admission by us that the events or circumstances described in such statement are material. Furthermore, we wish to caution and advise readers that these statements are based on assumptions that may not materialize and may involve risks and uncertainties, many of which are beyond our control, that could cause actual events or performance to differ materially from those contained or implied in these forward-looking statements. These risks and uncertainties include the risks identified under the heading "Risk Factors" in our Annual Report on Form 10-K for the fiscal year ended January 1, 2024, as updated by our other filings with the Securities and Exchange Commission (SEC), and described elsewhere in this Report. The following discussion and analysis of our financial condition and results of operations should be read in conjunction with our consolidated condensed financial statements and the related notes and the other financial information included in this Report, as well as the “Management’s Discussion and Analysis of Financial Condition and Results of Operations” set forth in our Annual Report on Form 10-K for the fiscal year ended January 1, 2024, filed with the SEC.

[0000950170-24-054464:mdna:4]
[same as prior period, unchanged from 0000950170-23-060227:mdna:4]

[0000950170-24-054464:mdna:5]
We are a leading global manufacturer of technology solutions including mission systems, radio frequency (RF) components/RF microwave/microelectronic assemblies, and quick-turn and technologically advanced printed circuit boards (PCB). We focus on providing time-to-market and volume production of advanced technology products and offer a one-stop design, engineering, and manufacturing solution to our customers. This solution allows us to align technology development with the diverse needs of our customers and to enable them to reduce the time required to develop new products and bring them to market. We serve a diversified customer base consisting of approximately 1,500 customers in various markets throughout the world, including aerospace and defense, data center computing, automotive, medical, industrial and instrumentation, and networking. Our customers include original equipment manufacturers (OEMs), electronic manufacturing services (EMS) providers, original design manufacturers (ODMs), distributors, and government agencies (both domestic and allied foreign governments).

[0000950170-24-054464:mdna:6]
[same as prior period, unchanged from 0000950170-23-060227:mdna:6]

[0000950170-24-054464:mdna:7]
On November 1, 2023, we announced our selection of Syracuse, New York as the location for a new proposed advanced technology PCB manufacturing facility. We expect that the proposed facility will bring advanced technology capability for our domestic high-volume production of ultra-high-density interconnect (HDI) PCBs in support of national security requirements. We believe the planned investment aligns with New York State’s continuing focus on the region as a premier technology hub for U.S. electronics and the recent selection of Buffalo-Rochester-Syracuse (BRS) for the Federal Tech Hub designation. The project reflects our support for cultivating a stronger microelectronics ecosystem in New York and across the U.S. Aerospace and Defense industrial base. We are in the advanced stages of project planning, having identified the 24-acre property adjacent to our existing facility in Syracuse for the campus expansion and the site for the new facility. We have completed initial building designs and site layout, and are now applying for the required permitting. Groundbreaking is anticipated in the first half of 2024, with the project's final scale, scope, and timeline subject to finalizing funding with various stakeholders. Phase one of the proposed project, including capital for campus-wide improvements is estimated to be $100.0 million to $130.0 million, and is anticipated to run through 2026. Our planned capital investment commitments will be determined after finalizing terms with various stakeholders.

[0000950170-24-054464:mdna:8]
[same as prior period, unchanged from 0000950170-23-060227:mdna:11]

[0000950170-24-054464:mdna:9]
While our customers include both OEMs and EMS providers, we measure customers based on OEM companies, as they are the ultimate end customers. Sales to our ten largest customers collectively accounted for 53% and 48% of our net sales for the quarters ended April 1, 2024 and April 3, 2023, respectively. We sell to OEMs both directly and indirectly through EMS providers.

[0000950170-24-054464:mdna:10]
The percentage of our net sales attributable to each of the principal end markets we served was as follows:

[0000950170-24-054464:mdna:11]
|  |  | Quarter Ended |
|  |  | April 1, 2024 |  | April 3, 2023 |
| End Markets (1): |  |  |  |  |  |  |  |  |
| Aerospace and Defense |  |  | 46 |  | % |  |  | 43 |  | % |
| Automotive |  |  | 13 |  |  |  |  | 17 |  |  |
| Data Center Computing |  |  | 21 |  |  |  |  | 10 |  |  |
| Medical/Industrial/Instrumentation |  |  | 14 |  |  |  |  | 19 |  |  |
| Networking |  |  | 6 |  |  |  |  | 11 |  |  |
| Total |  |  | 100 |  | % |  |  | 100 |  | % |

[0000950170-24-054464:mdna:12]
[same as prior period, unchanged from 0000950170-23-060227:mdna:16]

[0000950170-24-054464:mdna:13]
We derive revenues primarily from the sale of PCBs, engineered systems using customer-supplied engineering and design plans as well as our long-term contracts related to the design and manufacture of highly sophisticated intelligence, surveillance, and communications solutions, and RF and microwave/microelectronics components, assemblies, and subsystems. Orders for products generally correspond to the production schedules of our customers and are supported with firm purchase orders. Our customers have continuous control of the work in progress and finished goods throughout the PCB and engineered systems manufacturing process, as these are built to customer specifications with no alternative use, and there is an enforceable right of payment for work performed to date. As a result, we recognize revenue progressively over time based on the extent of progress towards completion of the performance obligation. We recognize revenue based on a cost method as it best depicts the transfer of control to the customer which takes place as we incur costs. Revenues are recorded proportionally as costs are incurred.

[0000950170-24-054464:mdna:14]
[same as prior period, unchanged from 0000950170-23-060227:mdna:18]

[0000950170-24-054464:mdna:15]
[same as prior period, unchanged from 0000950170-23-060227:mdna:19]

[0000950170-24-054464:mdna:16]
[same as prior period, unchanged from 0000950170-23-060227:mdna:20]

[0000950170-24-054464:mdna:17]
[same as prior period, unchanged from 0000950170-23-060227:mdna:21]

[0000950170-24-054464:mdna:18]
[same as prior period, unchanged from 0000950170-23-060227:mdna:22]

[0000950170-24-054464:mdna:19]
[same as prior period, unchanged from 0000950170-23-060227:mdna:23]

[0000950170-24-054464:mdna:20]
[same as prior period, unchanged from 0000950170-23-060227:mdna:24]

[0000950170-24-054464:mdna:21]
Our consolidated condensed financial statements included in this Report have been prepared in accordance with accounting principles generally accepted in the United States of America (U.S. GAAP). The preparation of these financial statements requires management to make estimates and assumptions that affect the reported amounts of assets, liabilities, net sales and expenses, and related disclosure of contingent assets and liabilities.

[0000950170-24-054464:mdna:22]
See Item 7, Management’s Discussion and Analysis of Financial Condition and Results of Operations, in our Annual Report on Form 10-K for the fiscal year ended January 1, 2024 for further discussion of critical accounting policies and estimates. There were no material changes to our critical accounting policies and estimates since January 1, 2024.

[0000950170-24-054464:mdna:23]
21

[0000950170-24-054464:mdna:24]
[same as prior period, unchanged from 0000950170-23-060227:mdna:27]

[0000950170-24-054464:mdna:25]
The relationship of various items to net sales in our consolidated condensed statements of operations was as follows:

[0000950170-24-054464:mdna:26]
|  |  | Quarter Ended |
|  |  | April 1, 2024 |  | April 3, 2023 |
| Net sales |  |  | 100.0 |  | % |  |  | 100.0 |  | % |
| Cost of goods sold |  |  | 81.8 |  |  |  |  | 84.2 |  |  |
| Gross profit |  |  | 18.2 |  |  |  |  | 15.8 |  |  |
| Operating expenses: |  |  |  |  |  |  |  |  |
| Selling and marketing |  |  | 3.5 |  |  |  |  | 3.9 |  |  |
| General and administrative |  |  | 7.7 |  |  |  |  | 6.4 |  |  |
| Research and development |  |  | 1.3 |  |  |  |  | 1.3 |  |  |
| Amortization of definite-lived intangibles |  |  | 2.0 |  |  |  |  | 4.0 |  |  |
| Restructuring charges |  |  | 0.7 |  |  |  |  | 0.8 |  |  |
| Total operating expenses |  |  | 15.2 |  |  |  |  | 16.4 |  |  |
| Operating income (loss) |  |  | 3.0 |  |  |  |  | (0.6 | ) |  |
| Other (expense) income: |  |  |  |  |  |  |  |  |
| Interest expense |  |  | (2.2 | ) |  |  |  | (2.4 | ) |  |
| Gain on sale of subsidiary |  |  | — |  |  |  |  | 0.2 |  |  |
| Other, net |  |  | 1.6 |  |  |  |  | 0.2 |  |  |
| Total other expense, net |  |  | (0.6 | ) |  |  |  | (2.0 | ) |  |
| Income (loss) before income taxes |  |  | 2.4 |  |  |  |  | (2.6 | ) |  |
| Income tax (provision) benefit |  |  | (0.6 | ) |  |  |  | 1.5 |  |  |
| Net income (loss) |  |  | 1.8 |  | % |  |  | (1.1 | ) | % |

[0000950170-24-054464:mdna:27]
The following discussion and analysis is for the quarter ended April 1, 2024, compared to the same period ended April 3, 2023, unless otherwise stated.

[0000950170-24-054464:mdna:28]
[same as prior period, unchanged from 0000950170-23-060227:mdna:31]

[0000950170-24-054464:mdna:29]
Total net sales increased $25.7 million, or 4.7%, to $570.1 million for the first quarter of 2024 from $544.4 million for the first quarter of 2023. The increase in total net sales primarily resulted from an increase in net sales for the PCB reportable segment of $27.7 million, or 5.2%, to $561.8 million for the first quarter of 2024 from $534.1 million for the first quarter of 2023. The primary driver of this increase was demand growth in our aerospace and defense and data center computing end markets, partially offset by demand weakness in our medical, industrial, and instrumentation, automotive, and networking end markets, as well as the sale of our Shanghai backplane business in the first quarter of 2023, which had the effect of reducing $8.4 million of net sales when comparing the first quarter of 2024 to the first quarter of 2023. Net sales for the RF&S Components reportable segment decreased $2.0 million, or 19.9%, to $8.3 million for the first quarter of 2024 from $10.3 million for the first quarter of 2023, which was primarily due to lower demand in our networking end market.

[0000950170-24-054464:mdna:30]
[same as prior period, unchanged from 0000950170-23-060227:mdna:35]

[0000950170-24-054464:mdna:31]
Overall gross margin increased to 18.2% for the first quarter of 2024 from 15.8% for the first quarter of 2023. Gross margin for the PCB reportable segment increased to 19.4% for the first quarter of 2024 from 16.5% for the first quarter of 2023. This increase was due to a more favorable product mix and improved execution in our North America region, partially offset by lower sales volume and less premium in some commercial markets. Gross margin for the RF&S Components reportable segment decreased to 47.5% for the first quarter of 2024 from 49.6% for the first quarter of 2023, primarily due to lower sales.

[0000950170-24-054464:mdna:32]
An important factor affecting gross margins is capacity utilization, which is measured by the actual production as a percentage of maximum capacity. This measure is particularly important in our high-volume PCB facilities in Asia, as a significant portion of our operating costs are fixed in nature. North America utilization figures are not as meaningful as Asia because bottlenecks in these high mix low volume facilities tend to occur in areas outside of plating, which is the core process that we use for calculating utilization rates. Capacity utilization for the first quarter of 2024 in our Asia and North America PCB facilities was 52% and 38%, respectively, compared to 52% and 39%, respectively, for the first quarter of 2023.

[0000950170-24-054464:mdna:33]
[same as prior period, unchanged from 0000950170-23-060227:mdna:39]

[0000950170-24-054464:mdna:34]
Selling and marketing expenses decreased $1.0 million to $20.3 million, or 3.5% of net sales, for the first quarter of 2024 from $21.3 million, or 3.9% of net sales, for the first quarter of 2023. The decrease in selling and marketing expenses was primarily due to a decrease in commission expense.

[0000950170-24-054464:mdna:35]
[same as prior period, unchanged from 0000950170-23-060227:mdna:42]

[0000950170-24-054464:mdna:36]
General and administrative expenses increased $8.6 million to $43.7 million, or 7.7% of net sales, for the first quarter of 2024 from $35.1 million, or 6.4% of net sales, for the first quarter of 2023. The increase in general and administrative expenses was primarily due to increases in certain personnel costs, stock-based compensation, bad debt, and other general and administrative spending.

[0000950170-24-054464:mdna:37]
[same as prior period, unchanged from 0000950170-23-060227:mdna:45]

[0000950170-24-054464:mdna:38]
Research and development expenses increased $0.2 million to $7.3 million, or 1.3% of net sales, for the first quarter of 2024 from $7.1 million, or 1.3% of net sales, for the first quarter of 2023. The increase in research and development expenses was primarily due to an increase in research and development projects, while the research and development expenses as a percentage of net sales was flat as a result of higher net sales offset by increased expenses.

[0000950170-24-054464:mdna:39]
[same as prior period, unchanged from 0000950170-23-060227:mdna:50]

[0000950170-24-054464:mdna:40]
Total other expense, net decreased $7.3 million to $3.0 million for the first quarter of 2024 from $10.3 million for the first quarter of 2023, primarily due to an increase in foreign currency gains of $5.6 million resulting from the weakening Renminbi (RMB) in the first quarter of 2024 compared to the first quarter of 2023 and an increase in interest income of $1.7 million. We utilize the RMB at our China facilities for employee-related expenses, RMB denominated purchases, and other costs of running our operations in China.

[0000950170-24-054464:mdna:41]
[same as prior period, unchanged from 0000950170-23-060227:mdna:53]

[0000950170-24-054464:mdna:42]
Income tax expense increased $11.5 million to $3.6 million for the first quarter of 2024 from an income tax benefit of $7.9 million for the first quarter of 2023. The increase in income tax expense was primarily due to an increase in pre-tax income.

[0000950170-24-054464:mdna:43]
Our effective tax rate is primarily impacted by the mix of foreign and U.S. income, tax rates in China and Hong Kong, the U.S. federal income tax rate, apportioned state income tax rates, the generation of credits and deductions available to us as well as changes in valuation allowances and certain non-deductible items. We had a net deferred income tax liability of approximately $44.2 million and $51.1 million as of April 1, 2024 and April 3, 2023, respectively.

[0000950170-24-054464:mdna:44]
[same as prior period, unchanged from 0000950170-23-060227:mdna:57]

[0000950170-24-054464:mdna:45]
Our principal sources of liquidity have been cash provided by operations, the issuance of debt, and borrowings under our revolving credit facility. Our principal uses of cash have been to finance capital expenditures, finance acquisitions, fund working capital requirements, repay debt obligations, and repurchase common stock. We anticipate that financing capital expenditures, financing acquisitions, funding working capital requirements, servicing debt, and repurchasing common stock will be the principal demands on our cash in the future.

[0000950170-24-054464:mdna:46]
Cash flow provided by operating activities during the first quarter of 2024 was $43.9 million as compared to cash flow provided by operating activities of $55.1 million in the same period in 2023. The decrease in cash flow was primarily due to increased investment in working capital.

[0000950170-24-054464:mdna:47]
Net cash used in investing activities was approximately $42.6 million for the first quarter of 2024, primarily reflecting the use of $49.3 million for purchases of property, plant and equipment and other assets, partially offset by $6.7 million of proceeds from the sale of property associated with our Shanghai E-MS subsidiary. Net cash provided by investing activities was approximately $9.6 million for the first quarter of 2023, primarily reflecting $34.7 million of proceeds from the sale of property associated with our Shanghai E-MS subsidiary, $5.6 million of proceeds from the sale of a subsidiary, net of cash disposed, less $31.0 million for purchases of property, plant and equipment and other assets.

[0000950170-24-054464:mdna:48]
Net cash used in financing activities during the first quarter of 2024 was $11.1 million reflecting the use of $9.3 million for repurchases of common stock and $1.8 million for the repayment of long-term debt. Net cash used in financing activities during the first quarter of 2023 was $50.0 million for the repayment of long-term debt.

[0000950170-24-054464:mdna:49]
As of April 1, 2024, we had cash and cash equivalents of approximately $440.4 million, of which approximately $203.0 million was held by our foreign subsidiaries, primarily in China. Should we choose to remit cash to the United States from our foreign locations, we may incur tax obligations which would reduce the amount of cash ultimately available to the United States. However, we believe there would be no material tax consequences not previously accrued for the repatriation of this cash.

[0000950170-24-054464:mdna:50]
Our total 2024 capital expenditures are expected to be in the range of $170.0 million to $190.0 million.

[0000950170-24-054464:mdna:51]
Share Repurchases

[0000950170-24-054464:mdna:52]
On May 3, 2023, our Board of Directors authorized a share repurchase program (2023 Repurchase Program) allowing us to repurchase up to $100.0 million of our common stock from time to time through May 3, 2025. During the quarter ended April 1, 2024, we repurchased a total of 0.6 million shares of our common stock for $9.3 million (including commissions). As of April 1, 2024, the remaining amount in value available to be repurchased under the 2023 Repurchase Program was approximately $66.2 million.

[0000950170-24-054464:mdna:53]
[same as prior period, unchanged from 0000950170-23-060227:mdna:64]

[0000950170-24-054464:mdna:54]
As of April 1, 2024, we had $916.5 million of outstanding debt, net of discount and debt issuance costs, composed of $496.1 million of Senior Notes due March 2029, $340.4 million of Term Loan due May 2030 (Term Loan Facility), and $80.0 million under the Asia Asset-Based Lending Credit Agreement (Asia ABL).

[0000950170-24-054464:mdna:55]
Pursuant to the terms of the Senior Notes due March 2029 and Term Loan Facility, we are subject to certain affirmative and negative covenants, including limitations on indebtedness, corporate transactions, investments, dispositions, and restricted payments. Under the U.S. Asset-Based Lending Credit Agreement (U.S. ABL) and Asia ABL (collectively, the ABL Revolving Loans), we are also subject to various financial covenants, including leverage and fixed charge coverage ratios. As of April 1, 2024, we were in compliance with the covenants under the Senior Notes due March 2029, Term Loan Facility, and ABL Revolving Loans.

[0000950170-24-054464:mdna:56]
Based on our current level of operations, we believe that cash generated from operations, cash on hand, and cash from the issuance of term and revolving debt will be adequate to meet our currently anticipated capital expenditure, debt service, and working capital needs for the next 12 months. Additional information regarding our indebtedness, including information about the credit available under our debt facilities, interest rates, and other key terms of our outstanding indebtedness, is included in Part I, Item 1, Note 8, Long-term Debt and Letters of Credit, of the Notes to Consolidated Condensed Financial Statements included in this Quarterly Report on Form 10-Q.

[0000950170-24-054464:mdna:57]
Supplier Finance Program Obligations

[0000950170-24-054464:mdna:58]
We have agreements with financial institutions to facilitate payments to certain suppliers. Under the terms of the agreements, we confirm the validity of each supplier invoice to the respective financial institution upon receipt. The supplier receives payment from the financial institution, and we pay the financial institution based on the terms negotiated, which generally range from 160 days to 360 days. Liabilities associated with these agreements are recorded in accounts payable on the consolidated condensed balance sheets and amounted to $17.7 million and $18.8 million as of April 1, 2024 and January 1, 2024, respectively.

[0000950170-24-054464:mdna:59]
[same as prior period, unchanged from 0000950170-23-060227:mdna:68]

[0000950170-24-054464:mdna:60]
As part of our on-going operations, we enter into contractual arrangements that obligate us to make future cash payments. These obligations impact our liquidity and capital resource needs. Our estimated future obligations consist of long-term debt obligations, interest on debt obligations, derivative liabilities, purchase obligations, and leases. As of April 1, 2024, there were no material changes outside the ordinary course of business since January 1, 2024 to our contractual obligations and commitments and the related cash requirements.

[0000950170-24-054464:mdna:61]
[same as prior period, unchanged from 0000950170-23-060227:mdna:70]

[0000950170-24-054464:mdna:62]
We have and may continue to enter into industrial cooperation agreements, sometimes referred to as offset agreements, as a condition to obtaining orders for our products and services from customers in foreign countries. These agreements are intended to promote investment in the applicable country, and our obligations under these agreements may be satisfied through activities that do not require us to use cash, including transferring technology or providing manufacturing and other consulting support. The obligations under these agreements may also be satisfied through the use of cash for such activities as purchasing supplies from in-country vendors, setting up support centers, research and development investments, acquisitions, and building or leasing facilities for in-country operations. The amount of the offset requirement is determined by contract value awarded and negotiated percentages with customers. As of April 1, 2024, we had outstanding offset agreements of approximately $28.0 million, some of which extend through 2028. Offset programs usually extend over several years and in some cases provide for penalties in the event we fail to perform in accordance with contract requirements. To date, the Company has not been obligated to pay any such penalties.

[0000950170-24-054464:mdna:63]
[same as prior period, unchanged from 0000950170-23-060227:mdna:72]

[0000950170-24-054464:mdna:64]
[same as prior period, unchanged from 0000950170-23-060227:mdna:73]

[0000950170-24-054464:mdna:65]
Recently Issued Accounting Standards

[0000950170-24-054464:mdna:66]
[same as prior period, unchanged from 0000950170-23-060227:mdna:75]
