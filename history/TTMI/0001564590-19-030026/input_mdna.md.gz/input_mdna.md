# TTMI MD&A — 0001564590-19-030026


## mdna

[0001564590-19-030026:mdna:1]
[same as prior period, unchanged from 0001564590-19-017942:mdna:1]

[0001564590-19-030026:mdna:2]
[same as prior period, unchanged from 0001564590-19-017942:mdna:2]

[0001564590-19-030026:mdna:3]
We are a leading global printed circuit board (PCB) manufacturer, focusing on quick-turn and volume production of technologically complex PCBs, backplane assemblies and electro-mechanical solutions (E-M Solutions), as well as a global designer and manufacturer of radio-frequency (RF) and microwave components and assemblies. We focus on providing time-to-market and volume production of advanced technology products and offer a one-stop design, engineering and manufacturing solution to our customers from engineering support to prototype development through final mass production. This one-stop design, engineering and manufacturing solution allows us to align technology development with the diverse needs of our customers and to enable them to reduce the time required to develop new products and bring them to market. We serve a diversified customer base consisting of approximately 1,600 customers in various markets throughout the world, including aerospace and defense, automotive components, smartphones and touchscreen tablets, high-end computing, medical, industrial and instrumentation related products, as well as networking/communications infrastructure products. Our customers include both original equipment manufacturers (OEMs) and electronic manufacturing services (EMS) providers.

[0001564590-19-030026:mdna:4]
RECENT DEVELOPMENTS

[0001564590-19-030026:mdna:5]
During June 2019, we amended our U.S. Asset-Based Lending Credit Agreement (U.S. ABL) and our Asia Asset-Based Lending Credit Agreement (Asia ABL) (collectively the ABL Revolving Loans). The U.S. ABL credit facility was amended to extend its maturity to June 2024, decrease the size of the facility to $150,000 and add a $100,000 incremental facility. The Asia ABL credit facility was amended to extend the maturity to June 2024 and add a $50,000 incremental facility.

[0001564590-19-030026:mdna:6]
During July 2019, we extended the maturity of our revolving loan credit facility (Chinese Revolver) with a lender in China to July 2020.

[0001564590-19-030026:mdna:7]
[same as prior period, unchanged from 0001564590-19-017942:mdna:4]

[0001564590-19-030026:mdna:8]
While our customers include both OEMs and EMS providers, we measure customers based on OEM companies, as they are the ultimate end customers. Sales to our ten largest customers accounted for 46% of our net sales for both the quarter and two quarters ended July 1, 2019. Sales to our ten largest customers accounted for 43% of our net sales for both the quarter and two quarters ended July 2, 2018. We sell to OEMs both directly and indirectly through EMS providers.

[0001564590-19-030026:mdna:9]
[same as prior period, unchanged from 0001564590-19-017942:mdna:6]

[0001564590-19-030026:mdna:10]
|  |  | Quarter Ended |  |  |  | Two Quarters Ended |  |  |
| End Markets (1) |  | July 1, 2019 |  |  |  | July 2, 2018 (3) |  |  |  | July 1, 2019 |  |  |  | July 2, 2018 (3) |  |  |
| Aerospace and Defense |  |  | 28 |  | % |  |  | 23 |  | % |  |  | 27 |  | % |  |  | 21 |  | % |
| Automotive |  |  | 16 |  |  |  |  | 19 |  |  |  |  | 17 |  |  |  |  | 20 |  |  |
| Cellular Phone (2) |  |  | 6 |  |  |  |  | 8 |  |  |  |  | 7 |  |  |  |  | 12 |  |  |
| Computing/Storage/Peripherals (2) |  |  | 15 |  |  |  |  | 15 |  |  |  |  | 14 |  |  |  |  | 14 |  |  |
| Medical/Industrial/Instrumentation |  |  | 15 |  |  |  |  | 15 |  |  |  |  | 15 |  |  |  |  | 15 |  |  |
| Networking/Communications |  |  | 17 |  |  |  |  | 17 |  |  |  |  | 17 |  |  |  |  | 16 |  |  |
| Other (2) |  |  | 3 |  |  |  |  | 3 |  |  |  |  | 3 |  |  |  |  | 2 |  |  |
| Total |  |  | 100 |  | % |  |  | 100 |  | % |  |  | 100 |  | % |  |  | 100 |  | % |

[0001564590-19-030026:mdna:11]
[same as prior period, unchanged from 0001564590-19-017942:mdna:8]

[0001564590-19-030026:mdna:12]
| (2) | Smartphones are included in the Cellular Phone end market, tablets are included in the Computing/Storage/Peripherals end market and other consumer devices that include wearables, portable video devices and personal headphones are included in the Other end market. |

[0001564590-19-030026:mdna:13]
| (3) | The quarter and two quarters ended July 2, 2018 were amended for the Anaren integration, as the acquisition occurred on April 18, 2018. |

[0001564590-19-030026:mdna:14]
We derive revenues primarily from the sale of PCBs, custom electronic assemblies using customer-supplied engineering and design plans as well as the design and manufacture of RF and microwave components and assemblies. Most orders for products generally correspond to the production schedules of our customers and are supported with firm purchase orders. Most of our customers have continuous control of the work in progress and finished goods throughout the PCB manufacturing process, as PCBs are built to customer specifications with no alternative use, and there is an enforceable right of payment for work performed to date. As a result, we recognize revenue progressively over time based on the extent of progress towards completion of the performance obligation. We recognize revenue under these contracts based on the cost-to-cost method as it best depicts the transfer of control to the customer which takes place as we incur costs. Under the cost-to-cost measure of progress, the extent of progress toward completion is measured based on the ratio of costs incurred to date to the total estimated costs at completion of the performance obligation. Revenues are recorded proportionally as costs are incurred.

[0001564590-19-030026:mdna:15]
[same as prior period, unchanged from 0001564590-19-017942:mdna:12]

[0001564590-19-030026:mdna:16]
[same as prior period, unchanged from 0001564590-19-017942:mdna:13]

[0001564590-19-030026:mdna:17]
[same as prior period, unchanged from 0001564590-19-017942:mdna:14]

[0001564590-19-030026:mdna:18]
[same as prior period, unchanged from 0001564590-19-017942:mdna:15]

[0001564590-19-030026:mdna:19]
[same as prior period, unchanged from 0001564590-19-017942:mdna:16]

[0001564590-19-030026:mdna:20]
[same as prior period, unchanged from 0001564590-19-017942:mdna:17]

[0001564590-19-030026:mdna:21]
[same as prior period, unchanged from 0001564590-19-017942:mdna:18]

[0001564590-19-030026:mdna:22]
[same as prior period, unchanged from 0001564590-19-017942:mdna:19]

[0001564590-19-030026:mdna:23]
[same as prior period, unchanged from 0001564590-19-017942:mdna:20]

[0001564590-19-030026:mdna:24]
[same as prior period, unchanged from 0001564590-19-017942:mdna:21]

[0001564590-19-030026:mdna:25]
The following table sets forth the relationship of various items to net sales in our consolidated condensed statements of operations:

[0001564590-19-030026:mdna:26]
|  |  | Quarter Ended |  |  |  | Two Quarters Ended |  |  |
|  |  | July 1, 2019 |  |  |  | July 2, 2018 |  |  |  | July 1, 2019 |  |  |  | July 2, 2018 |  |  |
| Net sales |  |  | 100.0 |  | % |  |  | 100.0 |  | % |  |  | 100.0 |  | % |  |  | 100.0 |  | % |
| Cost of goods sold |  |  | 86.6 |  |  |  |  | 83.8 |  |  |  |  | 86.2 |  |  |  |  | 85.2 |  |  |
| Gross profit |  |  | 13.4 |  |  |  |  | 16.2 |  |  |  |  | 13.8 |  |  |  |  | 14.8 |  |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Selling and marketing |  |  | 2.8 |  |  |  |  | 2.6 |  |  |  |  | 2.9 |  |  |  |  | 2.6 |  |  |
| General and administrative |  |  | 6.1 |  |  |  |  | 6.5 |  |  |  |  | 5.9 |  |  |  |  | 5.9 |  |  |
| Amortization of definite-lived intangibles |  |  | 1.8 |  |  |  |  | 2.7 |  |  |  |  | 2.3 |  |  |  |  | 1.8 |  |  |
| Total operating expenses |  |  | 10.7 |  |  |  |  | 11.8 |  |  |  |  | 11.1 |  |  |  |  | 10.3 |  |  |
| Operating income |  |  | 2.7 |  |  |  |  | 4.4 |  |  |  |  | 2.7 |  |  |  |  | 4.5 |  |  |
| Other income (expense): |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Interest expense |  |  | (3.3 | ) |  |  |  | (2.9 | ) |  |  |  | (3.4 | ) |  |  |  | (2.5 | ) |  |
| Other, net |  |  | 0.7 |  |  |  |  | 0.9 |  |  |  |  | 0.3 |  |  |  |  | 0.4 |  |  |
| Total other expense, net |  |  | (2.6 | ) |  |  |  | (2.0 | ) |  |  |  | (3.1 | ) |  |  |  | (2.1 | ) |  |
| Income (loss) before income taxes |  |  | 0.1 |  |  |  |  | 2.4 |  |  |  |  | (0.4 | ) |  |  |  | 2.4 |  |  |
| Income tax benefit |  |  | 0.4 |  |  |  |  | 9.3 |  |  |  |  | 0.4 |  |  |  |  | 4.4 |  |  |
| Net income |  |  | 0.5 |  | % |  |  | 11.7 |  | % |  |  | 0.0 |  | % |  |  | 6.8 |  | % |

[0001564590-19-030026:mdna:27]
[same as prior period, unchanged from 0001564590-19-017942:mdna:24]

[0001564590-19-030026:mdna:28]
[same as prior period, unchanged from 0001564590-19-017942:mdna:25]

[0001564590-19-030026:mdna:29]
Total net sales decreased $83.9 million, or 11.7%, to $633.0 million for the second quarter of 2019 from $716.9 million for the second quarter of 2018. This decrease primarily resulted from a reduction in net sales for the PCB reportable segment of $81.9 million, or 12.5%, to $573.1 million for the second quarter of 2019 from $655.0 million for the second quarter of 2018. The reduction in PCB net sales was primarily due to lower demand in our commercial (non-Aerospace and Defense related) end markets, partially offset by an increase in demand in our Aerospace and Defense end market. These changes resulted in an average PCB selling price increase of 14.0%, driven mainly by product mix shift and a 22.7% decrease in the volume of PCB shipments as compared to the second quarter of 2018. Net sales for the E-M Solutions reportable segment decreased $1.9 million, or 3.1%, to $59.9 million for the second quarter of 2019 from $61.8 million for the second quarter of 2018. The decrease was primarily due to lower demand in our Automotive end market.

[0001564590-19-030026:mdna:30]
Total net sales decreased $127.3 million, or 9.2%, to $1,253.2 million for the first two quarters of 2019 from $1,380.5 million for the first two quarters of 2018. This decrease resulted from a reduction in net sales for the PCB reportable segment of $129.6 million, or 10.2% to $1,141.9 million for the first two quarters of 2019 from $1,271.5 million for the first two quarters of 2018. The reduction in PCB net sales was primarily due to lower demand in our commercial end markets, partially offset by an increase in demand in our Aerospace and Defense end market, which increase was primarily the result of the impact in the first two quarters of 2019 of our acquisition of Anaren (which occurred on April 18, 2018). These changes resulted in an average PCB selling price increase of 12.8%, driven mainly by product mix shift and a 21.9% decrease in the volume of PCB shipments as compared to the first two quarters of 2018. Net sales for the E-M Solutions reportable segment increased $2.3 million, or 2.1%, to $111.3 million for the first two quarters of 2019 from $109.0 million for the first two quarters of 2018. The increase was primarily due to higher demand in our Networking/Communications end market, partially offset by a decrease in our Automotive end market.

[0001564590-19-030026:mdna:31]
[same as prior period, unchanged from 0001564590-19-017942:mdna:27]

[0001564590-19-030026:mdna:32]
Overall gross margin decreased to 13.4% for the second quarter of 2019 from 16.2% for the second quarter of 2018. Gross margin for the PCB reportable segment decreased to 14.5% for the second quarter of 2019 from 15.4% for the second quarter of 2018, primarily due to lower volumes in our commercial end markets and ramp related inefficiencies associated with a major product launch in our Cellular end market. Gross margin for the E-M Solutions reportable segment decreased to 7.3% for the second quarter of 2019 from 8.0% for the second quarter of 2018, primarily due to lower volume in our Automotive end market.

[0001564590-19-030026:mdna:33]
Overall gross margin decreased to 13.8% for the first two quarters of 2019 from 14.8% for the first two quarters of 2018. Gross margin for the PCB reportable segment increased to 15.0% for the first two quarters of 2019 from 14.8% for the first two quarters of 2018, primarily due to the impact in the first two quarters of 2019 of our acquisition of Anaren and higher production levels at our Aerospace and Defense focused facilities partially offset by lower volumes in our commercially focused facilities. Gross margin for the E-M Solutions reportable segment decreased to 6.8% for the first two quarters of 2019 from 6.9% for the first two quarters of 2018.

[0001564590-19-030026:mdna:34]
Capacity utilization is a key driver for us, particularly in our high volume facilities in Asia, as a significant portion of our operating costs are fixed in nature. Capacity utilization for the second quarter of 2019 in our Asia and North America PCB facilities was 56% and 60%, respectively, compared to 71% and 61%, respectively, in the second quarter of 2018. Capacity utilization for the first two quarters of 2019 in our Asia and North America PCB facilities was 56% and 60%, respectively, compared to 74% and 61%, respectively, in the first two quarters of 2018. The significant decline in the utilization of our facilities in Asia was due to the softness we experienced in our commercial end markets.

[0001564590-19-030026:mdna:35]
[same as prior period, unchanged from 0001564590-19-017942:mdna:31]

[0001564590-19-030026:mdna:36]
Selling and marketing expenses decreased $0.7 million, to $17.9 million for the second quarter of 2019 from $18.6 million for the second quarter of 2018. As a percentage of net sales, selling and marketing expenses was 2.8% for the second quarter of 2019, as compared to 2.6% for the second quarter of 2018. The decrease in selling and marketing expense for the quarter ended July 1, 2019 primarily relates to reduced commission expense.

[0001564590-19-030026:mdna:37]
Selling and marketing expenses increased $0.6 million, to $36.8 million for the first two quarters of 2019 from $36.2 million for the first two quarters of 2018. As a percentage of net sales, selling and marketing expenses was 2.9% for the first two quarters of 2019, as compared to 2.6% for the first two quarters of 2018. The increase in selling and marketing expense for the two quarters ended July 1, 2019 primarily relates to expenses incurred by Anaren post acquisition partially offset by reduced commission expense.

[0001564590-19-030026:mdna:38]
[same as prior period, unchanged from 0001564590-19-017942:mdna:33]

[0001564590-19-030026:mdna:39]
General and administrative expenses decreased $7.7 million to $38.6 million, or 6.1% of net sales, for the second quarter of 2019 from $46.3 million, or 6.5% of net sales, for the second quarter of 2018. The decrease in general and administrative expenses for the quarter ended July 1, 2019 was primarily due to the decrease in acquisition-related costs of $6.1 million associated with the acquisition of Anaren on April 18, 2018 and a decrease in incentive compensation expense of $3.7 million partially offset by higher restructuring charges.

[0001564590-19-030026:mdna:40]
General and administrative expenses decreased $7.4 million to $74.1 million, or 5.9% of net sales, for the first two quarters of 2019 from $81.5 million, or 5.9% of net sales, for the first two quarters of 2018. The decrease in general and administrative expenses for the two quarters ended July 1, 2019 was primarily due to the decrease in acquisition-related costs of $8.6 million associated with the acquisition of Anaren on April 18, 2018 and a decrease in incentive compensation expense of $3.9 million partially offset by $6.4 million additional three and a half months of general and administrative expense incurred by Anaren (which occurred on April 18, 2018).

[0001564590-19-030026:mdna:41]
[same as prior period, unchanged from 0001564590-19-017942:mdna:35]

[0001564590-19-030026:mdna:42]
Other expense, net increased $2.0 million to $16.3 million for the second quarter of 2019 from $14.3 million for the second quarter of 2018. The increase in other expense, net for the quarter ended July 1, 2019 was primarily the result of lower foreign currency gains due to the depreciation of the Chinese Renminbi (RMB) in the second quarter of 2019 compared to the second quarter of 2018. We utilize the RMB at our China facilities for employee-related expenses, foreign currency denominated purchases, and other costs of running our operations in China.

[0001564590-19-030026:mdna:43]
Other expense, net increased $9.4 million to $38.5 million for the first two quarters of 2019 from $29.1 million for the first two quarters of 2018. The increase in other expense, net for the two quarters ended July 1, 2019 was primarily due to the increase in interest expense of $8.4 million mainly related to the $600.0 million incremental debt incurred in conjunction with the Anaren acquisition.

[0001564590-19-030026:mdna:44]
[same as prior period, unchanged from 0001564590-19-017942:mdna:37]

[0001564590-19-030026:mdna:45]
The income tax benefit decreased by $63.7 million to $2.8 million of tax benefit for the second quarter of 2019 from $66.5 million of tax benefit for the second quarter of 2018. The income tax benefit decreased by $57.2 million to $4.3 million of tax benefit for the first two quarters of 2019 from $61.5 million of tax benefit for the first two quarters of 2018. The decrease in income tax benefit for the first two quarters of 2019 was primarily due to the absence of a $74.6 million release of a portion of the Company’s valuation allowance against its U.S. federal and state net deferred tax assets which occurred in the second quarter of 2018, partially offset by tax benefits resulting from the decreased income before income taxes for the two quarters ended July 1, 2019 and a reduction of discrete tax expense recorded for the first two quarters of 2019 compared to the amount recorded in the first two quarters of 2018.

[0001564590-19-030026:mdna:46]
[same as prior period, unchanged from 0001564590-19-017942:mdna:30]

[0001564590-19-030026:mdna:47]
Our effective tax rate is primarily impacted by tax rates in China and Hong Kong, the U.S. federal income tax rate, apportioned state income tax rates, generation of other credits and deductions available to us, as well as changes in valuation allowances and certain non-deductible items. We had a net deferred income tax asset of approximately $15.9 million and $13.7 million as of July 1, 2019 and December 31, 2018, respectively.

[0001564590-19-030026:mdna:48]
[same as prior period, unchanged from 0001564590-19-017942:mdna:40]

[0001564590-19-030026:mdna:49]
Our principal sources of liquidity have been cash provided by operations, the issuance of Convertible Senior Notes, Term Loan, Senior Notes, and Revolving Credit Facility. Our principal uses of cash have been to finance capital expenditures, finance acquisitions, meet debt service requirements, fund working capital requirements, and pay down existing debt. We anticipate that servicing debt, financing capital expenditures, financing acquisitions, and funding working capital requirements will continue to be the principal demands on our cash in the future.

[0001564590-19-030026:mdna:50]
Cash flow provided by operating activities during the first two quarters of 2019 was $123.0 million as compared to $41.4 million in the same period in 2018. The increase in cash flow was primarily due to lower investment in working capital during the first two quarters of 2019. As of July 1, 2019, we had net working capital of approximately $565.7 million compared to $533.7 million as of December 31, 2018.

[0001564590-19-030026:mdna:51]
Net cash used in investing activities was approximately $63.2 million for the first two quarters of 2019, reflecting $69.1 million used for purchases of property, plant and equipment, less proceeds from the sale of property, plant and equipment and other assets of $5.9 million. Net cash used in investing activities was approximately $677.5 million for the first two quarters of 2018, reflecting $596.4 million used for acquisition of Anaren, net of debt assumed, and $81.1 million used for net purchases of property, plant and equipment.

[0001564590-19-030026:mdna:52]
Net cash used in financing activities was approximately $31.5 million for the first two quarters of 2019, reflecting repayment of long-term debt of $30.0 million and payment of debt issuance costs of $1.5 million. Net cash provided by financing activities was approximately $431.7 million for the first two quarters of 2018, primarily reflecting proceeds of $623.0 million from incremental term and revolving loan borrowings, less the repayment of assumed long-term debt in acquisition of $178.6 million, repayment of long-term debt of $3.7 million, and payment of debt issuance costs and original issue discount of $9.2 million associated with the incremental term loans.

[0001564590-19-030026:mdna:53]
As of July 1, 2019, we had cash and cash equivalents of approximately $284.5 million, of which approximately $204.8 million was held by our foreign subsidiaries, primarily in China.

[0001564590-19-030026:mdna:54]
Our 2019 net capital expenditures and asset acquisitions are expected to be in the range of $150.0 million to $170.0 million.

[0001564590-19-030026:mdna:55]
[same as prior period, unchanged from 0001564590-19-017942:mdna:47]

[0001564590-19-030026:mdna:56]
[same as prior period, unchanged from 0001564590-19-017942:mdna:48]

[0001564590-19-030026:mdna:57]
On April 18, 2018, we closed our $600.0 million commitment of incremental loans concurrent with the completion of our acquisition of Anaren. At issuance, these incremental loans increased the existing balance of our Term Loan Facility due 2024 from $348.3 million to $948.3 million. The Term Loan Facility had an outstanding balance of $805.9 million as of July 1, 2019 and is included in long-term debt. The Term Loan Facility was issued at a weighted average discount of 99.7% and bears interest, at our option, at a floating rate of LIBOR plus an applicable interest margin of 2.5%, or an alternate base rate (as defined in the Term Loan Credit Agreement) plus an applicable margin of 1.5%. As of July 1, 2019, the interest rate on the outstanding borrowings under the Term Loan Facility was 4.89%. There is no provision, other than an event of default, for the interest margin to increase. The Term Loan Facility will mature on September 28, 2024. The Term Loan Facility is secured by a significant amount of our domestic assets and a pledge of 65% of voting stock of our first tier foreign subsidiaries and is structurally senior to our Senior Notes and Convertible Senior Notes. See Senior Notes and Convertible Senior Notes below.

[0001564590-19-030026:mdna:58]
[same as prior period, unchanged from 0001564590-19-017942:mdna:50]

[0001564590-19-030026:mdna:59]
Borrowings under the Term Loan Facility are subject to certain affirmative and negative covenants, including limitations on indebtedness, corporate transactions, investments and dispositions, and share payments. As of July 1, 2019, we were in compliance with the covenants under the Term Loan Facility.

[0001564590-19-030026:mdna:60]
[same as prior period, unchanged from 0001564590-19-017942:mdna:52]

[0001564590-19-030026:mdna:61]
[same as prior period, unchanged from 0001564590-19-017942:mdna:53]

[0001564590-19-030026:mdna:62]
28

[0001564590-19-030026:mdna:63]
Borrowings under the Senior Notes are subject to certain affirmative and negative covenants, including limitations on indebtedness, corporate transactions, investments, dispositions, and share payments. As of July 1, 2019, we were in compliance with the covenants under the Senior Notes.

[0001564590-19-030026:mdna:64]
Convertible Senior Notes due 2020

[0001564590-19-030026:mdna:65]
[same as prior period, unchanged from 0001564590-19-017942:mdna:56]

[0001564590-19-030026:mdna:66]
[same as prior period, unchanged from 0001564590-19-017942:mdna:57]

[0001564590-19-030026:mdna:67]
During June 2019, we amended our ABL Revolving Loans. The U.S. ABL credit facility was amended to extend its maturity to June 2024, decrease the size of the facility to $150,000 and add a $100,000 incremental facility. The Asia ABL credit facility was amended to extend the maturity to June 2024 and add a $50,000 incremental facility.

[0001564590-19-030026:mdna:68]
The U.S. ABL consists of two tranches comprised of a revolving credit facility of up to $150.0 million and a letter of credit facility for up to $50.0 million, provided that at no time may amounts outstanding under the tranches exceed in aggregate $150.0 million or the applicable borrowing base, which is a percentage of the principal amount of Eligible Accounts, as defined in the U.S. ABL agreement. Borrowings under the U.S. ABL bear interest at either a floating rate of LIBOR plus a margin of 138 basis points or an alternate base rate (defined as the greater of the prime rate, the New York Fed bank rate plus 0.5% or LIBOR plus 1.0%) subject to a 1.0% floor, plus an applicable margin of 38 basis points, at our option. As of July 1, 2019, the interest rate on the outstanding borrowings under the U.S. ABL was 3.76%. The applicable margin can vary based on the remaining availability of the facility, from 125 to 150 basis points for LIBOR-based loans and from 25 to 50 basis points for JP Morgan Chase Bank’s prime rate-based loans. Other than availability and an event of default, there are no other provisions for the interest margin to increase. The U.S. ABL will mature on June 3, 2024. Loans made under the U.S. ABL are secured first by all of our domestic cash, receivables and certain inventories as well as by a second position against a significant amount of our domestic assets and a pledge of 65% of the voting stock of our first tier foreign subsidiaries and are structurally senior to our Senior Notes and Convertible Senior Notes. See Senior Notes and Convertible Senior Notes above. As of July 1, 2019, $40.0 million of the U.S. ABL was outstanding and classified as long-term debt, which is consistent with its maturity date.

[0001564590-19-030026:mdna:69]
The Asia ABL consists of two tranches comprised of a revolving credit facility for up to $150.0 million and a letter of credit facility for up to $100.0 million, provided that at no time may amounts outstanding under both tranches exceed in aggregate $150.0 million or the applicable borrowing base, which is a percentage of the principal amount of Eligible Accounts, as defined in the Asia ABL agreement. Borrowings under the Asia ABL bear interest at a floating rate of LIBOR plus 140 basis points. As of July 1, 2019, the interest rate on the outstanding borrowings under the Asia ABL was 3.79%. There is no provision, other than an event of default, for the interest margin to increase. The Asia ABL will mature on June 4, 2024. Loans made under the Asia ABL are secured by a portion of our Asia Pacific cash and receivables and are structurally senior to our domestic obligations, including the Senior Notes and Convertible Senior Notes. See Senior Notes and Convertible Senior Notes above. As of July 1, 2019, $30.0 million of the Asia ABL was outstanding and classified as long-term debt, which is consistent with its maturity date.

[0001564590-19-030026:mdna:70]
We have up to $50.0 million and $100.0 million Letters of Credit Facilities under the U.S. ABL and the Asia ABL, respectively. As of July 1, 2019, letters of credit in the amount of $15.3 million were outstanding under the U.S. ABL and $22.7 million were outstanding under the Asia ABL with various expiration dates through May 2020. Available borrowing capacity under the U.S. ABL and the Asia ABL was $94.7 million and $97.3 million, respectively, which considers letters of credit outstanding as of July 1, 2019.

[0001564590-19-030026:mdna:71]
We are required to pay a commitment fee of 0.25% per annum on any unused portion of the U.S. ABL and 0.28% per annum on any unused portion of the Asia ABL. We paid commitment fees of $0.2 million for the quarters ended July 1, 2019 and July 2, 2018. Additionally, we paid commitment fees of $0.5 million for the two quarters ended July 1, 2019 and July 2, 2018. Under the occurrence of certain events, the ABL Revolving Loans are subject to various financial and operational covenants, including maintaining minimum fixed charge coverage ratios. As of July 1, 2019, we were in compliance with the covenants under the ABL Revolving Loans.

[0001564590-19-030026:mdna:72]
Other Credit Facility

[0001564590-19-030026:mdna:73]
Additionally, we are party to a revolving loan credit facility (Chinese Revolver) with a lender in China. Under this arrangement, the lender has made available to us approximately $29.1 million in unsecured borrowing with all terms of the borrowing to be negotiated at the time the Chinese Revolver is drawn upon. There are no commitment fees on the unused portion of the Chinese Revolver. In July 2019, the expiration of the Chinese Revolver was extended to July 2020. As of July 1, 2019, the Chinese Revolver had not been drawn upon.

[0001564590-19-030026:mdna:74]
[same as prior period, unchanged from 0001564590-19-017942:mdna:65]

[0001564590-19-030026:mdna:75]
[same as prior period, unchanged from 0001564590-19-017942:mdna:66]

[0001564590-19-030026:mdna:76]
As of the date of this report, other than changes related to adoption of the new lease accounting standard as discussed in Note 1 to the consolidated condensed financial statements, there were no material changes to our contractual obligations and commitments outside the ordinary course of business since December 31, 2018 as reported in our Annual Report on Form 10-K for the fiscal year ended December 31, 2018.

[0001564590-19-030026:mdna:77]
[same as prior period, unchanged from 0001564590-19-017942:mdna:68]

[0001564590-19-030026:mdna:78]
[same as prior period, unchanged from 0001564590-19-017942:mdna:69]

[0001564590-19-030026:mdna:79]
[same as prior period, unchanged from 0001564590-19-017942:mdna:70]

[0001564590-19-030026:mdna:80]
Orders for our products generally correspond to the production schedules of our customers. We historically experience higher net sales in the third and fourth quarters due to end customer demand in the fourth quarter for consumer electronics products. Seasonal fluctuations also include the Chinese New Year holidays in the first quarter, which typically results in lower net sales for that quarter. We attribute this decline to shutdowns of our customers’ and our own China based manufacturing facilities surrounding the Chinese New Year public holidays, which normally occur in January or February of each year.
