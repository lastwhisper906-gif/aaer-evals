# TTMI note change history — 0001564590-19-017942 → 0001564590-19-030026


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2019-08-07):
[0001564590-19-030026:note_history:1]
The Company is subject to various legal matters, which it considers normal for its business activities. While the Company currently believes that the amount of any reasonably possible loss for known matters would not be material to the Company’s financial condition, the outcome of these actions is inherently difficult to predict. In the event of an adverse outcome, the ultimate potential loss could have a material adverse effect on the Company’s financial condition or results of operations in a particular period. The Company has accrued amounts for its loss contingencies which are probable and estimable as of July 1, 2019 and December 31, 2018. However, these amounts are not material to the consolidated condensed financial statements of the Company.
  (was, 2019-05-09, similarity 0.994):
[0001564590-19-017942:note_history:1]
The Company is subject to various legal matters, which it considers normal for its business activities. While the Company currently believes that the amount of any reasonably possible loss for known matters would not be material to the Company’s financial condition, the outcome of these actions is inherently difficult to predict. In the event of an adverse outcome, the ultimate potential loss could have a material adverse effect on the Company’s financial condition or results of operations in a particular period. The Company has accrued amounts for its loss contingencies which are probable and estimable as of April 1, 2019 and December 31, 2018. However, these amounts are not material to the consolidated condensed financial statements of the Company.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureAndSignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2019-08-07):
[0001564590-19-030026:note_history:2]
(1) Nature of Operations and Basis of Presentation
  (was, 2019-05-09, similarity 0.6116):
[0001564590-19-017942:note_history:2]
(1) Nature of Operations and Summary of Significant Accounting Policies

- changed (2019-08-07):
[0001564590-19-030026:note_history:3]
Certain amounts in the prior period consolidated condensed financial statement have been reclassified to conform to the presentation of the current period consolidated condensed financial statement. These reclassifications had no effect on the previously reported net income. An adjustment has been made to combine the statutory surplus reserve with retained earnings on the consolidated condensed balance sheet and the consolidated condensed statement of stockholders’ equity.
  (was, 2019-05-09, similarity 0.9894):
[0001564590-19-017942:note_history:3]
Certain amounts in the prior period consolidated condensed financial statement have been reclassified to conform to the presentation of the current period consolidated condensed financial statement. These reclassifications had no effect on the previously reported net income. An adjustment has been made to combine the statutory surplus reserve with retained earnings on the consolidated condensed balance sheet and the consolidated statement of stockholders’ equity.

- changed (2019-08-07):
[0001564590-19-030026:note_history:4]
In February 2016, the Financial Accounting Standards Board (FASB) issued ASU 2016-02, Leases (Topic 842) which supersedes the existing lease recognition requirements in the current accounting standard for leases. The core principal of the new standard is that an entity should recognize right-of-use (ROU) assets and lease liabilities arising from a lease for both financing and operating leases, along with additional qualitative and quantitative disclosures.
  (was, 2019-05-09, similarity 0.9785):
[0001564590-19-017942:note_history:4]
In February 2016, the Financial Accounting Standards Board (FASB) issued ASU 2016-02, Leases (Topic 842) which supersedes the existing lease recognition requirements in the current accounting standard for leases. The core principal of the new standard is that an entity should recognize ROU assets and lease liabilities arising from a lease for both financing and operating leases, along with additional qualitative and quantitative disclosures.

- added (2019-08-07):
[0001564590-19-030026:note_history:5]
The Company adopted the new lease standard as of January 1, 2019 and utilized the retrospective cumulative effect adjustment transition method with a cumulative effect adjustment being recorded as of the adoption date. Therefore, comparative information has not been adjusted and continues to be reported under previous U.S. GAAP guidance for the consolidated condensed balance sheet as of December 31, 2018 and the consolidated condensed statement of operations for the quarter and two quarters ended July 2, 2018. The Company implemented internal controls and key system functionality to enable the preparation of financial information on adoption. The Company elected certain available practical expedients including the package of practical expedients permitted under the transition guidance within the new standard, which among other things, allowed the Company to carry forward the historical lease classification. Additionally, the Company elected an accounting policy to not record ROU assets and lease liabilities for leases with an initial term of twelve months or less on its consolidated condensed balance sheet.

- changed (2019-08-07):
[0001564590-19-030026:note_history:6]
|  |  | Balance as of December 31, 2018 |  |  | New Lease Standard Adjustment |  |  | Balance as of January 1, 2019 |  |
|  |  | (In thousands) |  |
| Assets |  |  |  |  |  |  |  |  |  |  |  |  |
| Operating lease right-of-use assets |  | $ | — |  |  | $ | 16,894 |  |  | $ | 16,894 |  |
| Deposits and other non-current assets |  |  | 55,597 |  |  |  | (548 | ) |  |  | 55,049 |  |
| Liabilities |  |  |  |  |  |  |  |  |  |  |  |  |
| Other current liabilities |  |  | 113,756 |  |  |  | 2,545 |  |  |  | 116,301 |  |
| Operating lease liabilities |  |  | — |  |  |  | 14,356 |  |  |  | 14,356 |  |
| Other long-term liabilities |  |  | 94,777 |  |  |  | (555 | ) |  |  | 94,222 |  |
  (was, 2019-05-09, similarity 0.9536):
[0001564590-19-017942:note_history:6]
|  |  | Balance at December 31, 2018 |  |  | New Lease Standard Adjustment |  |  | Balance at January 1, 2019 |  |
|  |  | (In thousands) |  |
| Balance Sheet |  |  |  |  |  |  |  |  |  |  |  |  |
| Assets |  |  |  |  |  |  |  |  |  |  |  |  |
| Operating lease right-of-use assets |  | $ | — |  |  | $ | 16,894 |  |  | $ | 16,894 |  |
| Deposits and other non-current assets |  |  | 55,597 |  |  |  | (548 | ) |  |  | 55,049 |  |
| Liabilities |  |  |  |  |  |  |  |  |  |  |  |  |
| Other current liabilities |  |  | 113,756 |  |  |  | 2,545 |  |  |  | 116,301 |  |
| Operating lease liabilities |  |  | — |  |  |  | 14,356 |  |  |  | 14,356 |  |
| Other long-term liabilities |  |  | 94,777 |  |  |  | (555 | ) |  |  | 94,222 |  |

- changed (2019-08-07):
[0001564590-19-030026:note_history:7]
The adoption of the new accounting guidance did not have a material impact to the consolidated condensed statement of operations for the quarter and two quarters ended July 1, 2019, or the consolidated condensed statement of cash flows for the two quarters ended July 1, 2019. See Note 3 for further details.
  (was, 2019-05-09, similarity 0.636):
[0001564590-19-017942:note_history:7]
The adoption of the new accounting guidance did not have a material impact to the consolidated condensed statement of operations or the consolidated condensed statement of cash flows for the quarter ended April 1, 2019. See Note 4 for further details.

- added (2019-08-07):
[0001564590-19-030026:note_history:8]
In June 2016, the FASB issued ASU 2016-13, Financial Instruments-Credit Losses (Topic 326): Measurement of Credit Losses on Financial Instruments. ASU 2016-13 seeks to provide financial statement users with more decision-useful information about the expected credit losses on financial instruments, including trade receivables, and other commitments to extend credit held by a reporting entity at each reporting date. The amendments require an entity to replace the incurred loss impairment methodology in current U.S. GAAP with a methodology that reflects current expected credit losses and requires consideration of a broader range of reasonable and supportable information to inform credit loss estimates. This ASU is effective for fiscal years beginning after December 15, 2019, including interim periods within those fiscal years. Early adoption is permitted. The Company is currently evaluating the new guidance to determine the impact it may have on its consolidated condensed financial statements and related disclosures.

- removed (2019-08-07):
[0001564590-19-017942:note_history:9]
Summary of Significant Accounting Policies

- removed (2019-08-07):
[0001564590-19-017942:note_history:10]
Leases

- removed (2019-08-07):
[0001564590-19-017942:note_history:11]
The Company determines if an arrangement is a lease at inception. Operating leases are included in operating lease right-of-use (ROU) assets, other current liabilities, and operating lease liabilities on the consolidated condensed balance sheets.

- removed (2019-08-07):
[0001564590-19-017942:note_history:12]
ROU assets represent the Company’s right to use an underlying asset for the lease term and lease liabilities represent the Company’s obligation to make lease payments arising from the lease. Operating lease ROU assets and liabilities are recognized at commencement date based on the present value of lease payments over the lease term. As most of the Company’s leases do not provide an implicit rate, the Company uses incremental borrowing rate based on the information available at commencement date in determining the present value of lease payments. The operating lease ROU asset also includes any lease payments made and excludes lease incentives. Lease terms may include options to extend or terminate the lease when it is reasonably certain that the Company will exercise that option. Lease expense for lease payments is recognized on a straight-line basis over the lease term.

- removed (2019-08-07):
[0001564590-19-017942:note_history:13]
The Company has lease agreements with lease and non-lease components and accounts for the lease and non-lease components as a single lease component.

- removed (2019-08-07):
[0001564590-19-017942:note_history:14]
The Company adopted the new lease standard as of January 1, 2019 and utilized the retrospective cumulative effect adjustment transition method with a cumulative effect adjustment being recorded as of the adoption date. Therefore, comparative information has not been adjusted and continues to be reported under previous U.S. GAAP guidance for the consolidated balance sheet at December 31, 2018 and the consolidated condensed statement of operations for the quarter ended April 2, 2018. The Company implemented internal controls and key system functionality to enable the preparation of financial information on adoption. The Company elected certain available practical expedients including the package of practical expedients permitted under the transition guidance within the new standard, which among other things, allowed the Company to carry forward the historical lease classification. Additionally, the Company elected an accounting policy to not record ROU assets and lease liabilities for leases with an initial term of twelve months or less on its consolidated condensed balance sheet.


## us-gaap:SignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: no_prior_note, score: 0.0

- added (2019-08-07):
[0001564590-19-030026:note_history:15]
(2) Summary of Significant Accounting Policies

- added (2019-08-07):
[0001564590-19-030026:note_history:16]
Leases

- added (2019-08-07):
[0001564590-19-030026:note_history:17]
The Company determines if an arrangement is a lease at inception. Operating leases are included in operating lease ROU assets, other current liabilities, and operating lease liabilities on the consolidated condensed balance sheets.

- added (2019-08-07):
[0001564590-19-030026:note_history:18]
ROU assets represent the Company’s right to use an underlying asset for the lease term and lease liabilities represent the Company’s obligation to make lease payments arising from the lease. Operating lease ROU assets and liabilities are recognized at commencement date based on the present value of lease payments over the lease term. As most of the Company’s leases do not provide an implicit rate, the Company uses incremental borrowing rate based on the information available at commencement date in determining the present value of lease payments. The operating lease ROU asset also includes any lease payments made and excludes lease incentives. Lease terms may include options to extend or terminate the lease when it is reasonably certain that the Company will exercise that option. Lease expense for lease payments is recognized on a straight-line basis over the lease term.

- added (2019-08-07):
[0001564590-19-030026:note_history:19]
The Company has lease agreements with lease and non-lease components and accounts for the lease and non-lease components as a single lease component.


## ttmi:ScheduleOfComponentsOfInterestExpenseFromConvertibleNotesTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2019-08-07):
[0001564590-19-030026:note_history:20]
The components of interest expense resulting from the Convertible Senior Notes for the quarter and two quarters ended July 1, 2019 and July 2, 2018 were as follows:
  (was, 2019-05-09, similarity 0.8993):
[0001564590-19-017942:note_history:20]
The components of interest expense resulting from the Convertible Senior Notes for the quarters ended April 1, 2019 and April 2, 2018 were as follows:

- added (2019-08-07):
[0001564590-19-030026:note_history:21]
|  |  | Quarter Ended |  |  | Two Quarters Ended |  |
|  |  | July 1, |  |  | July 2, |  |  | July 1, |  |  | July 2, |  |
|  |  | 2019 |  |  | 2018 |  |  | 2019 |  |  | 2018 |  |
|  |  | (In thousands) |  |
| Contractual coupon interest |  | $ | 1,093 |  |  | $ | 1,093 |  |  | $ | 2,187 |  |  | $ | 2,187 |  |
| Amortization of debt discount |  | $ | 2,418 |  |  | $ | 2,267 |  |  | $ | 4,797 |  |  | $ | 4,497 |  |
| Amortization of debt issuance costs |  | $ | 243 |  |  | $ | 227 |  |  | $ | 481 |  |  | $ | 451 |  |

- removed (2019-08-07):
[0001564590-19-017942:note_history:22]
|  |  | Quarter Ended |  |
|  |  | April 1, |  |  | April 2, |  |
|  |  | 2019 |  |  | 2018 |  |
|  |  | (In thousands) |  |
| Contractual coupon interest |  | $ | 1,094 |  |  | $ | 1,094 |  |
| Amortization of debt discount |  | $ | 2,379 |  |  | $ | 2,230 |  |
| Amortization of debt issuance costs |  | $ | 238 |  |  | $ | 224 |  |


## ttmi:ScheduleOfUnamortizedDiscountAndDebtIssuanceCostsTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2019-08-07):
[0001564590-19-030026:note_history:23]
As of July 1, 2019 and December 31, 2018, remaining unamortized debt discount and debt issuance costs for the Term Loan Facility, Senior Notes and Convertible Senior Notes were as follows:
  (was, 2019-05-09, similarity 0.9719):
[0001564590-19-017942:note_history:23]
As of April 1, 2019 and December 31, 2018, remaining unamortized debt discount and debt issuance costs for the Term Loan Facility, Senior Notes and Convertible Senior Notes are as follows:

- added (2019-08-07):
[0001564590-19-030026:note_history:24]
|  |  | As of July 1, 2019 |  |  |  | As of December 31, 2018 |
|  |  | Debt Issuance Costs |  |  | Debt Discount |  |  | Effective Interest Rate |  |  |  | Debt Issuance Costs |  |  | Debt Discount |  |  | Effective Interest Rate |  |  |
|  |  | (In thousands, except interest rates) |
| Term Loan due September 2024 |  | $ | 7,303 |  |  | $ | 2,210 |  |  |  | 4.66 |  | % |  | $ | 8,229 |  |  | $ | 2,489 |  |  |  | 4.66 |  | % |
| Senior Notes due October 2025 |  |  | 5,700 |  |  | — |  |  |  | 5.92 |  |  |  |  | 6,071 |  |  | — |  |  |  | 5.92 |  |  |
| Convertible Senior Notes |  |  | 1,491 |  |  |  | 14,880 |  |  |  | 6.48 |  |  |  |  | 1,972 |  |  |  | 19,678 |  |  |  | 6.48 |  |  |
|  |  | $ | 14,494 |  |  | $ | 17,090 |  |  |  |  |  |  |  | $ | 16,272 |  |  | $ | 22,167 |  |  |  |  |  |  |

- removed (2019-08-07):
[0001564590-19-017942:note_history:25]
|  |  | As of April 1, 2019 |  |  | As of December 31, 2018 |  |
|  |  | Debt Issuance Costs |  |  | Debt Discount |  |  | Effective Interest Rate |  |  | Debt Issuance Costs |  |  | Debt Discount |  |  | Effective Interest Rate |  |
|  |  | (in thousands) |  |
| Term Loan due September 2024 |  | $ | 7,620 |  |  | $ | 2,305 |  |  | 4.66% |  |  | $ | 8,229 |  |  | $ | 2,489 |  |  | 4.66% |  |
| Senior Notes due October 2025 |  |  | 5,887 |  |  | — |  |  | 5.92% |  |  |  | 6,071 |  |  | — |  |  | 5.92% |  |
| Convertible Senior Notes |  |  | 1,734 |  |  |  | 17,298 |  |  | 6.48% |  |  |  | 1,972 |  |  |  | 19,678 |  |  | 6.48% |  |
|  |  | $ | 15,241 |  |  | $ | 19,603 |  |  |  |  |  |  | $ | 16,272 |  |  | $ | 22,167 |  |  |  |  |  |


## us-gaap:ConvertibleDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2019-08-07):
[0001564590-19-030026:note_history:26]
As of July 1, 2019 and December 31, 2018, the following summarizes the equity components of the Convertible Senior Notes included in additional paid-in capital:
  (was, 2019-05-09, similarity 0.9767):
[0001564590-19-017942:note_history:26]
As of April 1, 2019 and December 31, 2018, the following summarizes the equity components of the Convertible Senior Notes included in additional paid-in capital:

- added (2019-08-07):
[0001564590-19-030026:note_history:27]
|  |  | As of July 1, 2019 |  |  | As of December 31, 2018 |  |
|  |  | Embedded conversion option — Convertible Senior Notes |  |  | Embedded conversion option — Convertible Senior Notes Issuance Costs |  |  | Total |  |  | Embedded conversion option — Convertible Senior Notes |  |  | Embedded conversion option — Convertible Senior Notes Issuance Costs |  |  | Total |  |
|  |  | (In thousands) |  |
| Convertible Senior Notes due 2020 |  | $ | 60,213 |  |  | $ | (1,916 | ) |  | $ | 58,297 |  |  | $ | 60,216 |  |  | $ | (1,916 | ) |  | $ | 58,300 |  |

- removed (2019-08-07):
[0001564590-19-017942:note_history:28]
|  |  | As of April 1, 2019 |  |  | As of December 31, 2018 |  |
|  |  | Embedded conversion option — Convertible Senior Notes |  |  | Embedded conversion option — Convertible Senior Notes Issuance Costs |  |  | Total |  |  | Embedded conversion option — Convertible Senior Notes |  |  | Embedded conversion option — Convertible Senior Notes Issuance Costs |  |  | Total |  |
|  |  | (in thousands) |  |
| Convertible Senior Notes due 2020 |  | $ | 60,213 |  |  | $ | (1,916 | ) |  | $ | 58,297 |  |  | $ | 60,216 |  |  | $ | (1,916 | ) |  | $ | 58,300 |  |


## us-gaap:LongTermDebtTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2019-08-07):
[0001564590-19-030026:note_history:29]
The following table summarizes the long-term debt of the Company as of July 1, 2019 and December 31, 2018:
  (was, 2019-05-09, similarity 0.9641):
[0001564590-19-017942:note_history:29]
The following table summarizes the long-term debt of the Company as of April 1, 2019 and December 31, 2018:

- added (2019-08-07):
[0001564590-19-030026:note_history:30]
|  | Interest Rate as of July 1, 2019 |  |  | Principal Outstanding as of July 1, 2019 |  |  | Interest Rate as of December 31, 2018 |  |  | Principal Outstanding as of December 31, 2018 |  |
|  | (In thousands, except interest rates) |  |
| Term Loan due September 2024 |  | 4.89 |  | % | $ | 805,879 |  |  |  | 5.00 |  | % | $ | 835,879 |  |
| Senior Notes due October 2025 |  | 5.63 |  |  |  | 375,000 |  |  |  | 5.63 |  |  |  | 375,000 |  |
| Convertible Senior Notes due December 2020 |  | 1.75 |  |  |  | 249,975 |  |  |  | 1.75 |  |  |  | 249,985 |  |
| U.S. ABL Revolving Loan due June 2024 |  | 3.76 |  |  |  | 40,000 |  |  |  | 4.00 |  |  |  | 40,000 |  |
| Asia ABL Revolving Loan due June 2024 |  | 3.79 |  |  |  | 30,000 |  |  |  | 3.90 |  |  |  | 30,000 |  |
|  |  |  |  |  |  | 1,500,854 |  |  |  |  |  |  |  | 1,530,864 |  |
| Less: Long-term debt unamortized discount |  |  |  |  |  | (17,090 | ) |  |  |  |  |  |  | (22,167 | ) |
| Long-term debt unamortized debt issuance costs |  |  |  |  |  | (14,494 | ) |  |  |  |  |  |  | (16,272 | ) |
|  |  |  |  |  |  | 1,469,270 |  |  |  |  |  |  |  | 1,492,425 |  |
| Less: current maturities |  |  |  |  |  | — |  |  |  |  |  |  |  | (30,000 | ) |
| Long-term debt, less current maturities |  |  |  |  | $ | 1,469,270 |  |  |  |  |  |  | $ | 1,462,425 |  |

- changed (2019-08-07):
[0001564590-19-030026:note_history:31]
On April 18, 2018, the Company closed its $600,000 commitment of incremental loans concurrent with the completion of its acquisition of Anaren. At issuance, these incremental loans increased the Company’s existing balance of its Term Loan Facility due 2024 from $348,250 to $948,250. The Term Loan Facility had an outstanding balance of $805,879 as of July 1, 2019 and is included in long-term debt. The Term Loan Facility was issued at a weighted average discount of 99.7% and bears interest, at the Company’s option, at a floating rate of LIBOR plus an applicable interest margin of 2.5%, or an alternate base rate (as defined in the Term Loan Credit Agreement) plus an applicable margin of 1.5%. As of July 1, 2019, the interest rate on the outstanding borrowings under the Term Loan Facility was 4.89%. There is no provision, other than an event of default, for the interest margin to increase. The Term Loan Facility will mature on September 28, 2024. The Term Loan Facility is secured by a significant amount of the domestic assets of the Company and a pledge of 65% of voting stock of the Company’s first tier foreign subsidiaries and is structurally senior to the Company’s Senior Notes and Convertible Senior Notes. See Senior Notes and Convertible Senior Notes below.
  (was, 2019-05-09, similarity 0.9236):
[0001564590-19-017942:note_history:31]
On April 18, 2018, the Company closed its $600,000 commitment of incremental loans concurrent with the completion of its acquisition of Anaren. At issuance, these incremental loans increased the Company’s existing balance of its Term Loan Facility due 2024 from $348,250 to $948,250. The Term Loan Facility had an outstanding balance of $805,879 as of April 1, 2019 and is included in long-term debt. The Term Loan Facility was issued at a weighted average discount of 99.7% and bears interest, at the Company’s option, at a floating rate of LIBOR, plus an applicable interest margin of 2.50%, or an alternate base rate, (defined as the greater of the JP Morgan prime, the New York Fed bank rate plus 0.5% or LIBOR plus 1.0%), subject to a 1.0% floor plus an applicable margin of 1.5%. At April 1, 2019, the interest rate on the outstanding borrowings under the Term Loan Facility was 4.99%. There is no provision, other than an event of default, for the interest margin to increase. The Term Loan Facility will mature on September 28, 2024. The Term Loan Facility is secured by a significant amount of the domestic assets of the Company and a pledge of 65% of voting stock of the Company’s first tier foreign subsidiaries and is structurally senior to the Company’s Senior Notes and Convertible Senior Notes. See Senior Notes and Convertible Senior Notes below.

- changed (2019-08-07):
[0001564590-19-030026:note_history:32]
Based on certain parameters defined in the Term Loan Facility, including a First Lien Leverage Ratio, the Company may be required to make an additional principal payment on an annual basis beginning after fiscal year 2018, if the Company’s First Lien Leverage Ratio is greater than 2.0. For 2019, the Company is not required to make an additional principal payment as its First Lien Leverage Ratio was less than 2.0. Any remaining outstanding balance under the Term Loan Facility is due at the maturity date of September 28, 2024.
  (was, 2019-05-09, similarity 0.9971):
[0001564590-19-017942:note_history:32]
Based on certain parameters defined in the Term Loan Facility, including a First Lien Leverage Ratio, the Company may be required to make an additional principal payment on an annual basis beginning after fiscal year 2018, if the Company’s First Lien Leverage Ratio is greater than 2.0. For 2019, the Company is not required to make an additional principal payment as its First Lien Leverage Ratio is less than 2.0. Any remaining outstanding balance under the Term Loan Facility is due at the maturity date of September 28, 2024.

- changed (2019-08-07):
[0001564590-19-030026:note_history:33]
The $375,000 of Senior Notes, which is included in long-term debt, bear interest at a rate of 5.63% per annum. Interest is payable semiannually in arrears on April 1 and October 1 of each year beginning April 1, 2018. The Senior Notes will mature on October 1, 2025.
  (was, 2019-05-09, similarity 0.998):
[0001564590-19-017942:note_history:33]
The $375,000 of Senior Notes, which is included in long-term debt, bears interest at a rate of 5.63% per annum. Interest is payable semiannually in arrears on April 1 and October 1 of each year beginning April 1, 2018. The Senior Notes will mature on October 1, 2025.

- changed (2019-08-07):
[0001564590-19-030026:note_history:34]
The Company maintains 1.75% Convertible Senior Notes in the amount of $249,975 due December 15, 2020. The Convertible Senior Notes bear interest at a rate of 1.75% per annum. Interest is payable semiannually in arrears on June 15 and December 15 of each year. The Convertible Senior Notes are senior unsecured obligations and would rank equally to the Company’s future unsecured senior indebtedness and are senior in right of payment to any of the Company’s future subordinated indebtedness.
  (was, 2019-05-09, similarity 0.9925):
[0001564590-19-017942:note_history:34]
The Company maintains 1.75% Convertible Senior Notes in the amount of $249,975 due December 15, 2020. The Convertible Senior Notes bear interest at a rate of 1.75% per annum. Interest is payable semiannually in arrears on June 15 and December 15 of each year. The Convertible Senior Notes are unsecured obligations and would rank equally to the Company’s future unsecured senior indebtedness and are senior in right of payment to any of the Company’s future subordinated indebtedness.

- changed (2019-08-07):
[0001564590-19-030026:note_history:35]
As of July 1, 2019 and December 31, 2018, the following summarizes the equity components of the Convertible Senior Notes included in additional paid-in capital:
  (was, 2019-05-09, similarity 0.9767):
[0001564590-19-017942:note_history:35]
As of April 1, 2019 and December 31, 2018, the following summarizes the equity components of the Convertible Senior Notes included in additional paid-in capital:

- added (2019-08-07):
[0001564590-19-030026:note_history:36]
|  |  | As of July 1, 2019 |  |  | As of December 31, 2018 |  |
|  |  | Embedded conversion option — Convertible Senior Notes |  |  | Embedded conversion option — Convertible Senior Notes Issuance Costs |  |  | Total |  |  | Embedded conversion option — Convertible Senior Notes |  |  | Embedded conversion option — Convertible Senior Notes Issuance Costs |  |  | Total |  |
|  |  | (In thousands) |  |
| Convertible Senior Notes due 2020 |  | $ | 60,213 |  |  | $ | (1,916 | ) |  | $ | 58,297 |  |  | $ | 60,216 |  |  | $ | (1,916 | ) |  | $ | 58,300 |  |

- changed (2019-08-07):
[0001564590-19-030026:note_history:37]
The components of interest expense resulting from the Convertible Senior Notes for the quarter and two quarters ended July 1, 2019 and July 2, 2018 were as follows:
  (was, 2019-05-09, similarity 0.8993):
[0001564590-19-017942:note_history:37]
The components of interest expense resulting from the Convertible Senior Notes for the quarters ended April 1, 2019 and April 2, 2018 were as follows:

- added (2019-08-07):
[0001564590-19-030026:note_history:38]
|  |  | Quarter Ended |  |  | Two Quarters Ended |  |
|  |  | July 1, |  |  | July 2, |  |  | July 1, |  |  | July 2, |  |
|  |  | 2019 |  |  | 2018 |  |  | 2019 |  |  | 2018 |  |
|  |  | (In thousands) |  |
| Contractual coupon interest |  | $ | 1,093 |  |  | $ | 1,093 |  |  | $ | 2,187 |  |  | $ | 2,187 |  |
| Amortization of debt discount |  | $ | 2,418 |  |  | $ | 2,267 |  |  | $ | 4,797 |  |  | $ | 4,497 |  |
| Amortization of debt issuance costs |  | $ | 243 |  |  | $ | 227 |  |  | $ | 481 |  |  | $ | 451 |  |

- added (2019-08-07):
[0001564590-19-030026:note_history:39]
During June 2019, the Company amended its U.S. Asset-Based Lending Credit Agreement (U.S. ABL) and its Asia Asset-Based Lending Credit Agreement (Asia ABL) (collectively the ABL Revolving Loans). The U.S. ABL credit facility was amended to extend its maturity to June 2024, decrease the size of the facility to $150,000 and add a $100,000 incremental facility. The Asia ABL credit facility was amended to extend the maturity to June 2024 and add a $50,000 incremental facility.

- changed (2019-08-07):
[0001564590-19-030026:note_history:40]
The U.S. ABL consists of two tranches comprised of a revolving credit facility for up to $150,000 and a letter of credit facility for up to $50,000, provided that at no time may amounts outstanding under the tranches exceed in aggregate $150,000 or the applicable borrowing base, which is a percentage of the principal amount of Eligible Accounts, as defined in the U.S. ABL agreement. Borrowings under the U.S. ABL bear interest at either a floating rate of LIBOR plus a margin of 138 basis points or an alternate base rate (defined as the greater of the prime rate, the New York Fed bank rate plus 0.5% or LIBOR plus 1.0%) subject to a 1.0% floor, plus an applicable margin of 38 basis points, at the Company’s option. As of July 1, 2019, the interest rate on the outstanding borrowings under the U.S. ABL was 3.76%. The applicable margin can vary based on the remaining availability of the facility, from 125 to 150 basis points for LIBOR-based loans and from 25 to 50 basis points for JP Morgan Chase Bank’s prime rate-based loans. Other than availability and an event of default, there are no other provisions for the interest margin to increase. The U.S. ABL will mature on June 3, 2024. Loans made under the U.S. ABL are secured first by all of the Company’s domestic cash, receivables and certain inventories as well as by a second position against a significant amount of the domestic assets of the Company and a pledge of 65% of the voting stock of the Company’s first tier foreign subsidiaries and are structurally senior to the Company’s Senior Notes and Convertible Senior Notes. See Senior Notes and Convertible Senior Notes above. As of July 1, 2019, $40,000 of the U.S. ABL was outstanding and classified as long-term debt, which is consistent with its maturity date.
  (was, 2019-05-09, similarity 0.7385):
[0001564590-19-017942:note_history:40]
The U.S. ABL consists of three tranches comprised of a revolving credit facility for up to $200,000, a letter of credit facility for up to $50,000, and swingline loans for up to $30,000, provided that at no time may amounts outstanding under the tranches exceed in aggregate $200,000 or the applicable borrowing base, which is a percentage of the principal amount of Eligible Accounts, as defined in the U.S. ABL agreement. Borrowings under the U.S. ABL bear interest at either a floating rate of LIBOR plus a margin of 150 basis points or JP Morgan Chase Bank’s prime rate plus a margin of 50 basis points, at the Company’s option. At April 1, 2019, the interest rate on the outstanding borrowings under the U.S. ABL was 3.99%. The applicable margin can vary based on the remaining availability of the facility, from 125 to 175 basis points for LIBOR-based loans and from 25 to 75 basis points for JP Morgan Chase Bank’s prime rate-based loans. Other than availability and an event of default, there are no other provisions for the interest margin to increase. The U.S. ABL will mature on May 31, 2020. Loans made under the U.S. ABL are secured first by all of the Company’s domestic cash, receivables and certain inventories as well as by a second position against a significant amount of the domestic assets of the Company and a pledge of 65% of the voting stock of the Company’s first tier foreign subsidiaries and are structurally senior to the Company’s Senior Notes and Convertible Senior Notes. See Senior Notes and Convertible Senior Notes above. As of April 1, 2019, $40,000 of the U.S. ABL was outstanding and classified as long-term debt, which is consistent with its maturity date.

- changed (2019-08-07):
[0001564590-19-030026:note_history:41]
The Asia ABL consists of two tranches comprised of a revolving credit facility for up to $150,000 and a letter of credit facility for up to $100,000, provided that at no time may amounts outstanding under both tranches exceed in aggregate $150,000 or the applicable borrowing base, which is a percentage of the principal amount of Eligible Accounts, as defined in the Asia ABL agreement. Borrowings under the Asia ABL bear interest at a floating rate of LIBOR plus 140 basis points. As of July 1, 2019, the interest rate on the outstanding borrowings under the Asia ABL was 3.79%. There is no provision, other than an event of default, for the interest margin to increase. The Asia ABL will mature on June 4, 2024. Loans made under the Asia ABL are secured by a portion of the Company’s Asia Pacific cash and receivables and are structurally senior to the Company’s domestic obligations, including the Senior Notes and Convertible Senior Notes. See Senior Notes and Convertible Senior Notes above. As of July 1, 2019, $30,000 of the Asia ABL was outstanding and classified as long-term debt, which is consistent with its maturity date.
  (was, 2019-05-09, similarity 0.8878):
[0001564590-19-017942:note_history:41]
The Asia ABL consists of two tranches comprised of a revolving credit facility for up to $150,000 and a letter of credit facility for up to $100,000, provided that at no time may amounts outstanding under both tranches exceed in aggregate $150,000 or the applicable borrowing base, which is a percentage of the principal amount of Eligible Accounts, as defined in the Asia ABL agreement. Borrowings under the Asia ABL bear interest at a floating rate of LIBOR plus 140 basis points. As of April 1, 2019, the interest rate on the outstanding borrowings under the Asia ABL was 3.89%. There is no provision, other than an event of default, for the interest margin to increase. The Asia ABL will mature on May 22, 2020. Loans made under the Asia ABL are secured by a portion of the Company’s Asia Pacific cash and receivables and are structurally senior to the Company’s domestic obligations, including the Senior Notes and Convertible Senior Notes. See Senior Notes and Convertible Senior Notes above. As of April 1, 2019, $30,000 of the Asia ABL was outstanding and classified as long-term debt, which is consistent with its maturity date.

- changed (2019-08-07):
[0001564590-19-030026:note_history:42]
The Company has up to $50,000 and $100,000 Letters of Credit Facilities under the U.S. ABL and the Asia ABL, respectively. As of July 1, 2019, letters of credit in the amount of $15,287 were outstanding under the U.S. ABL and $22,718 were outstanding under the Asia ABL with various expiration dates through May 2020. Available borrowing capacity under the U.S. ABL and the Asia ABL was $94,713 and $97,282, respectively, which considers letters of credit outstanding as of July 1, 2019.
  (was, 2019-05-09, similarity 0.9596):
[0001564590-19-017942:note_history:42]
The Company has up to $50,000 and $100,000 Letters of Credit Facilities under the U.S. ABL and the Asia ABL, respectively. As of April 1, 2019, letters of credit in the amount of $13,383 were outstanding under the U.S. ABL and $19,445 were outstanding under the Asia ABL with various expiration dates through September 2019. Available borrowing capacity under the U.S. ABL and the Asia ABL was $146,617 and $100,555, respectively, which considers letters of credit outstanding as of April 1, 2019.

- added (2019-08-07):
[0001564590-19-030026:note_history:43]
The Company is required to pay a commitment fee of 0.25% per annum on any unused portion of the U.S. ABL and 0.28% per annum on any unused portion of the Asia ABL. The Company incurred total commitment fees related to unused borrowing availability of $210 and $247 for the quarters ended July 1, 2019 and July 2, 2018, respectively, and $450 and $488 for the two quarters ended July 1, 2019 and July 2, 2018, respectively. Under the occurrence of certain events, the ABL Revolving Loans are subject to various financial and operational covenants, including maintaining minimum fixed charge coverage ratios.

- changed (2019-08-07):
[0001564590-19-030026:note_history:44]
Additionally, the Company is party to a revolving loan credit facility (Chinese Revolver) with a lender in China. Under this arrangement, the lender has made available to the Company approximately $29,070 in unsecured borrowing with all terms of the borrowing to be negotiated at the time the Chinese Revolver is drawn upon. There are no commitment fees on the unused portion of the Chinese Revolver. In July 2019, the expiration of the Chinese Revolver was extended to July 2020. As of July 1, 2019, the Chinese Revolver had not been drawn upon.
  (was, 2019-05-09, similarity 0.7715):
[0001564590-19-017942:note_history:44]
Additionally, the Company is party to a revolving loan credit facility (Chinese Revolver) with a lender in China. Under this arrangement, the lender has made available to the Company approximately $31,286 in unsecured borrowing with all terms of the borrowing to be negotiated at the time the Chinese Revolver is drawn upon. There are no commitment fees on the unused portion of the Chinese Revolver, and this arrangement expires in June 2019. As of April 1, 2019, the Chinese Revolver had not been drawn upon.

- changed (2019-08-07):
[0001564590-19-030026:note_history:45]
As of July 1, 2019 and December 31, 2018, remaining unamortized debt discount and debt issuance costs for the Term Loan Facility, Senior Notes and Convertible Senior Notes were as follows:
  (was, 2019-05-09, similarity 0.9719):
[0001564590-19-017942:note_history:45]
As of April 1, 2019 and December 31, 2018, remaining unamortized debt discount and debt issuance costs for the Term Loan Facility, Senior Notes and Convertible Senior Notes are as follows:

- added (2019-08-07):
[0001564590-19-030026:note_history:46]
|  |  | As of July 1, 2019 |  |  |  | As of December 31, 2018 |
|  |  | Debt Issuance Costs |  |  | Debt Discount |  |  | Effective Interest Rate |  |  |  | Debt Issuance Costs |  |  | Debt Discount |  |  | Effective Interest Rate |  |  |
|  |  | (In thousands, except interest rates) |
| Term Loan due September 2024 |  | $ | 7,303 |  |  | $ | 2,210 |  |  |  | 4.66 |  | % |  | $ | 8,229 |  |  | $ | 2,489 |  |  |  | 4.66 |  | % |
| Senior Notes due October 2025 |  |  | 5,700 |  |  | — |  |  |  | 5.92 |  |  |  |  | 6,071 |  |  | — |  |  |  | 5.92 |  |  |
| Convertible Senior Notes |  |  | 1,491 |  |  |  | 14,880 |  |  |  | 6.48 |  |  |  |  | 1,972 |  |  |  | 19,678 |  |  |  | 6.48 |  |  |
|  |  | $ | 14,494 |  |  | $ | 17,090 |  |  |  |  |  |  |  | $ | 16,272 |  |  | $ | 22,167 |  |  |  |  |  |  |

- changed (2019-08-07):
[0001564590-19-030026:note_history:47]
Remaining unamortized debt issuance costs for the ABL Revolving Loans of $2,741 and $1,420 as of July 1, 2019 and December 31, 2018, respectively, are included in other non-current assets and are amortized to interest expense over the duration of the ABL Revolving Loans using the straight-line method of amortization.
  (was, 2019-05-09, similarity 0.9817):
[0001564590-19-017942:note_history:47]
Remaining unamortized debt issuance costs for the ABL Revolving Loans of $1,170 and $1,420 as of April 1, 2019 and December 31, 2018, respectively, are included in other non-current assets and are amortized to interest expense over the duration of the ABL Revolving Loans using the straight line method of amortization.

- changed (2019-08-07):
[0001564590-19-030026:note_history:48]
As of July 1, 2019, the remaining weighted average amortization period for all unamortized debt discount and debt issuance costs was 3.6 years.
  (was, 2019-05-09, similarity 0.9556):
[0001564590-19-017942:note_history:48]
At April 1, 2019, the remaining weighted average amortization period for all unamortized debt discount and debt issuance costs was 3.5 years.

- removed (2019-08-07):
[0001564590-19-017942:note_history:49]
|  |  | Interest Rate as of April 1, 2019 |  |  | Principal Outstanding as of April 1, 2019 |  |  | Interest Rate as of December 31, 2018 |  |  | Principal Outstanding as of December 31, 2018 |  |
|  |  | (In thousands) |  |
| Term Loan due September 2024 |  | 4.99% |  |  | $ | 805,879 |  |  | 5.00% |  |  | $ | 835,879 |  |
| Senior Notes due October 2025 |  | 5.63% |  |  |  | 375,000 |  |  | 5.63% |  |  |  | 375,000 |  |
| Convertible Senior Notes due December 2020 |  | 1.75% |  |  |  | 249,975 |  |  | 1.75% |  |  |  | 249,985 |  |
| U.S. ABL Revolving Loan due May 2020 |  | 3.99% |  |  |  | 40,000 |  |  | 4.00% |  |  |  | 40,000 |  |
| Asia ABL Revolving Loan due May 2020 |  | 3.89% |  |  |  | 30,000 |  |  | 3.90% |  |  |  | 30,000 |  |
|  |  |  |  |  |  |  | 1,500,854 |  |  |  |  |  |  |  | 1,530,864 |  |
| Less: Long-term debt unamortized discount |  |  |  |  |  |  | (19,603 | ) |  |  |  |  |  |  | (22,167 | ) |
| Long-term debt unamortized debt issuance costs |  |  |  |  |  |  | (15,241 | ) |  |  |  |  |  |  | (16,272 | ) |
|  |  |  |  |  |  |  | 1,466,010 |  |  |  |  |  |  |  | 1,492,425 |  |
| Less: current maturities |  |  |  |  |  |  | — |  |  |  |  |  |  |  | (30,000 | ) |
| Long-term debt, less current maturities |  |  |  |  |  | $ | 1,466,010 |  |  |  |  |  |  | $ | 1,462,425 |  |

- removed (2019-08-07):
[0001564590-19-017942:note_history:50]
|  |  | As of April 1, 2019 |  |  | As of December 31, 2018 |  |
|  |  | Embedded conversion option — Convertible Senior Notes |  |  | Embedded conversion option — Convertible Senior Notes Issuance Costs |  |  | Total |  |  | Embedded conversion option — Convertible Senior Notes |  |  | Embedded conversion option — Convertible Senior Notes Issuance Costs |  |  | Total |  |
|  |  | (in thousands) |  |
| Convertible Senior Notes due 2020 |  | $ | 60,213 |  |  | $ | (1,916 | ) |  | $ | 58,297 |  |  | $ | 60,216 |  |  | $ | (1,916 | ) |  | $ | 58,300 |  |

- removed (2019-08-07):
[0001564590-19-017942:note_history:51]
|  |  | Quarter Ended |  |
|  |  | April 1, |  |  | April 2, |  |
|  |  | 2019 |  |  | 2018 |  |
|  |  | (In thousands) |  |
| Contractual coupon interest |  | $ | 1,094 |  |  | $ | 1,094 |  |
| Amortization of debt discount |  | $ | 2,379 |  |  | $ | 2,230 |  |
| Amortization of debt issuance costs |  | $ | 238 |  |  | $ | 224 |  |

- removed (2019-08-07):
[0001564590-19-017942:note_history:52]
The Company maintains a $200,000 U.S. Asset-Based Lending Credit Agreement (U.S. ABL), and a $150,000 Asia Asset-Based Lending Credit Agreement (Asia ABL) (collectively the ABL Revolving Loans).

- removed (2019-08-07):
[0001564590-19-017942:note_history:53]
The Company is required to pay a commitment fee of 0.25% to 0.375% per annum on any unused portion of the U.S. ABL or Asia ABL. The Company incurred total commitment fees related to unused borrowing availability of $240 and $241 for the quarters ended April 1, 2019 and April 2, 2018, respectively. Under the occurrence of certain events, the ABL Revolving Loans are subject to various financial and operational covenants, including maintaining minimum fixed charge coverage ratios.

- removed (2019-08-07):
[0001564590-19-017942:note_history:54]
|  |  | As of April 1, 2019 |  |  | As of December 31, 2018 |  |
|  |  | Debt Issuance Costs |  |  | Debt Discount |  |  | Effective Interest Rate |  |  | Debt Issuance Costs |  |  | Debt Discount |  |  | Effective Interest Rate |  |
|  |  | (in thousands) |  |
| Term Loan due September 2024 |  | $ | 7,620 |  |  | $ | 2,305 |  |  | 4.66% |  |  | $ | 8,229 |  |  | $ | 2,489 |  |  | 4.66% |  |
| Senior Notes due October 2025 |  |  | 5,887 |  |  | — |  |  | 5.92% |  |  |  | 6,071 |  |  | — |  |  | 5.92% |  |
| Convertible Senior Notes |  |  | 1,734 |  |  |  | 17,298 |  |  | 6.48% |  |  |  | 1,972 |  |  |  | 19,678 |  |  | 6.48% |  |
|  |  | $ | 15,241 |  |  | $ | 19,603 |  |  |  |  |  |  | $ | 16,272 |  |  | $ | 22,167 |  |  |  |  |  |


## us-gaap:ScheduleOfDebtInstrumentsTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2019-08-07):
[0001564590-19-030026:note_history:55]
The following table summarizes the long-term debt of the Company as of July 1, 2019 and December 31, 2018:
  (was, 2019-05-09, similarity 0.9641):
[0001564590-19-017942:note_history:55]
The following table summarizes the long-term debt of the Company as of April 1, 2019 and December 31, 2018:

- added (2019-08-07):
[0001564590-19-030026:note_history:56]
|  | Interest Rate as of July 1, 2019 |  |  | Principal Outstanding as of July 1, 2019 |  |  | Interest Rate as of December 31, 2018 |  |  | Principal Outstanding as of December 31, 2018 |  |
|  | (In thousands, except interest rates) |  |
| Term Loan due September 2024 |  | 4.89 |  | % | $ | 805,879 |  |  |  | 5.00 |  | % | $ | 835,879 |  |
| Senior Notes due October 2025 |  | 5.63 |  |  |  | 375,000 |  |  |  | 5.63 |  |  |  | 375,000 |  |
| Convertible Senior Notes due December 2020 |  | 1.75 |  |  |  | 249,975 |  |  |  | 1.75 |  |  |  | 249,985 |  |
| U.S. ABL Revolving Loan due June 2024 |  | 3.76 |  |  |  | 40,000 |  |  |  | 4.00 |  |  |  | 40,000 |  |
| Asia ABL Revolving Loan due June 2024 |  | 3.79 |  |  |  | 30,000 |  |  |  | 3.90 |  |  |  | 30,000 |  |
|  |  |  |  |  |  | 1,500,854 |  |  |  |  |  |  |  | 1,530,864 |  |
| Less: Long-term debt unamortized discount |  |  |  |  |  | (17,090 | ) |  |  |  |  |  |  | (22,167 | ) |
| Long-term debt unamortized debt issuance costs |  |  |  |  |  | (14,494 | ) |  |  |  |  |  |  | (16,272 | ) |
|  |  |  |  |  |  | 1,469,270 |  |  |  |  |  |  |  | 1,492,425 |  |
| Less: current maturities |  |  |  |  |  | — |  |  |  |  |  |  |  | (30,000 | ) |
| Long-term debt, less current maturities |  |  |  |  | $ | 1,469,270 |  |  |  |  |  |  | $ | 1,462,425 |  |

- removed (2019-08-07):
[0001564590-19-017942:note_history:57]
|  |  | Interest Rate as of April 1, 2019 |  |  | Principal Outstanding as of April 1, 2019 |  |  | Interest Rate as of December 31, 2018 |  |  | Principal Outstanding as of December 31, 2018 |  |
|  |  | (In thousands) |  |
| Term Loan due September 2024 |  | 4.99% |  |  | $ | 805,879 |  |  | 5.00% |  |  | $ | 835,879 |  |
| Senior Notes due October 2025 |  | 5.63% |  |  |  | 375,000 |  |  | 5.63% |  |  |  | 375,000 |  |
| Convertible Senior Notes due December 2020 |  | 1.75% |  |  |  | 249,975 |  |  | 1.75% |  |  |  | 249,985 |  |
| U.S. ABL Revolving Loan due May 2020 |  | 3.99% |  |  |  | 40,000 |  |  | 4.00% |  |  |  | 40,000 |  |
| Asia ABL Revolving Loan due May 2020 |  | 3.89% |  |  |  | 30,000 |  |  | 3.90% |  |  |  | 30,000 |  |
|  |  |  |  |  |  |  | 1,500,854 |  |  |  |  |  |  |  | 1,530,864 |  |
| Less: Long-term debt unamortized discount |  |  |  |  |  |  | (19,603 | ) |  |  |  |  |  |  | (22,167 | ) |
| Long-term debt unamortized debt issuance costs |  |  |  |  |  |  | (15,241 | ) |  |  |  |  |  |  | (16,272 | ) |
|  |  |  |  |  |  |  | 1,466,010 |  |  |  |  |  |  |  | 1,492,425 |  |
| Less: current maturities |  |  |  |  |  |  | — |  |  |  |  |  |  |  | (30,000 | ) |
| Long-term debt, less current maturities |  |  |  |  |  | $ | 1,466,010 |  |  |  |  |  |  | $ | 1,462,425 |  |


## us-gaap:RelatedPartyTransactionsDisclosureTextBlock (related_parties) — matched_by: tag_name, score: 1.0

- changed (2019-08-07):
[0001564590-19-030026:note_history:58]
In the normal course of business, the Company’s foreign subsidiaries purchase laminate and prepreg from related parties in which a member of the Board of Directors of the Company holds an equity interest. The Company’s foreign subsidiaries purchased laminate and prepreg from these related parties in the amount of $8,917 and $12,550 for the quarters ended July 1, 2019 and July 2, 2018, respectively, and $17,229 and $25,258 for the two quarters ended July 1, 2019 and July 2, 2018, respectively.
  (was, 2019-05-09, similarity 0.8663):
[0001564590-19-017942:note_history:58]
In the normal course of business, the Company’s foreign subsidiaries purchase laminate and prepreg from related parties in which a member of the Board of Directors of the Company holds an equity interest. The Company’s foreign subsidiaries purchased laminate and prepreg from these related parties in the amount of $8,312 and $12,708 for the quarters ended April 1, 2019 and April 2, 2018, respectively.

- changed (2019-08-07):
[0001564590-19-030026:note_history:59]
As of July 1, 2019 and December 31, 2018, the Company’s consolidated condensed balance sheets included $10,537 and $10,630, respectively, in accounts payable due to related parties for purchases of laminate and prepreg and such balances are included as a component of accounts payable on the consolidated condensed balance sheets.
  (was, 2019-05-09, similarity 0.9855):
[0001564590-19-017942:note_history:59]
As of April 1, 2019 and December 31, 2018, the Company’s consolidated condensed balance sheets included $10,260 and $10,630, respectively, in accounts payable due to related parties for purchases of laminate and prepreg and such balances are included as a component of accounts payable on the consolidated condensed balance sheets.


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2019-08-07):
[0001564590-19-030026:note_history:60]
|  |  | Quarter Ended July 1, 2019 |  |  | Quarter Ended July 2, 2018 |  |
|  |  | PCB |  |  | E-M Solutions |  |  | Total |  |  | PCB |  |  | E-M Solutions |  |  | Total |  |
| End Markets |  | (In thousands) |  |
| Aerospace and Defense |  | $ | 175,301 |  |  | $ | 362 |  |  | $ | 175,663 |  |  | $ | 162,951 |  |  | $ | 455 |  |  | $ | 163,406 |  |
| Automotive |  |  | 79,048 |  |  |  | 23,993 |  |  |  | 103,041 |  |  |  | 110,607 |  |  |  | 25,854 |  |  |  | 136,461 |  |
| Cellular Phone |  |  | 40,094 |  |  |  | — |  |  |  | 40,094 |  |  |  | 55,393 |  |  |  | — |  |  |  | 55,393 |  |
| Computing/Storage/Peripherals |  |  | 95,127 |  |  |  | — |  |  |  | 95,127 |  |  |  | 109,633 |  |  |  | 568 |  |  |  | 110,201 |  |
| Medical/Industrial/Instrumentation |  |  | 87,471 |  |  |  | 9,641 |  |  |  | 97,112 |  |  |  | 96,704 |  |  |  | 9,856 |  |  |  | 106,560 |  |
| Networking/Communications |  |  | 79,937 |  |  |  | 25,926 |  |  |  | 105,863 |  |  |  | 99,353 |  |  |  | 24,602 |  |  |  | 123,955 |  |
| Other |  |  | 16,143 |  |  |  | (5 | ) |  |  | 16,138 |  |  |  | 20,404 |  |  |  | 507 |  |  |  | 20,911 |  |
| Total |  | $ | 573,121 |  |  | $ | 59,917 |  |  | $ | 633,038 |  |  | $ | 655,045 |  |  | $ | 61,842 |  |  | $ | 716,887 |  |
  (was, 2019-05-09, similarity 0.7678):
[0001564590-19-017942:note_history:60]
|  |  | Quarter ended April 1, 2019 |  |
|  |  | PCB |  |  | E-M Solutions |  |  | Total |  |
| End Markets |  | (In thousands) |  |
| Aerospace and Defense |  | $ | 165,068 |  |  | $ | 4 |  |  | $ | 165,072 |  |
| Automotive |  |  | 85,813 |  |  |  | 19,765 |  |  |  | 105,578 |  |
| Cellular Phone |  |  | 43,084 |  |  |  | — |  |  |  | 43,084 |  |
| Computing/Storage/Peripherals |  |  | 80,892 |  |  |  | 189 |  |  |  | 81,081 |  |
| Medical/Industrial/Instrumentation |  |  | 87,670 |  |  |  | 8,167 |  |  |  | 95,837 |  |
| Networking/Communications |  |  | 88,063 |  |  |  | 23,339 |  |  |  | 111,402 |  |
| Other |  |  | 18,232 |  |  |  | (86 | ) |  |  | 18,146 |  |
| Total |  | $ | 568,822 |  |  | $ | 51,378 |  |  | $ | 620,200 |  |

- changed (2019-08-07):
[0001564590-19-030026:note_history:61]
|  |  | Two Quarters Ended July 1, 2019 |  |  | Two Quarters Ended July 2, 2018 |  |
|  |  | PCB |  |  | E-M Solutions |  |  | Total |  |  | PCB |  |  | E-M Solutions |  |  | Total |  |
| End Markets |  | (In thousands) |  |
| Aerospace and Defense |  | $ | 340,369 |  |  | $ | 366 |  |  | $ | 340,735 |  |  | $ | 285,627 |  |  | $ | 544 |  |  | $ | 286,171 |  |
| Automotive |  |  | 164,861 |  |  |  | 43,758 |  |  |  | 208,619 |  |  |  | 226,899 |  |  |  | 45,164 |  |  |  | 272,063 |  |
| Cellular Phone |  |  | 83,178 |  |  |  | — |  |  |  | 83,178 |  |  |  | 160,253 |  |  |  | — |  |  |  | 160,253 |  |
| Computing/Storage/Peripherals |  |  | 176,019 |  |  |  | 189 |  |  |  | 176,208 |  |  |  | 198,175 |  |  |  | 873 |  |  |  | 199,048 |  |
| Medical/Industrial/Instrumentation |  |  | 175,141 |  |  |  | 17,808 |  |  |  | 192,949 |  |  |  | 190,338 |  |  |  | 17,379 |  |  |  | 207,717 |  |
| Networking/Communications |  |  | 168,000 |  |  |  | 49,265 |  |  |  | 217,265 |  |  |  | 181,290 |  |  |  | 44,075 |  |  |  | 225,365 |  |
| Other |  |  | 34,375 |  |  |  | (91 | ) |  |  | 34,284 |  |  |  | 28,894 |  |  |  | 958 |  |  |  | 29,852 |  |
| Total |  | $ | 1,141,943 |  |  | $ | 111,295 |  |  | $ | 1,253,238 |  |  | $ | 1,271,476 |  |  | $ | 108,993 |  |  | $ | 1,380,469 |  |
  (was, 2019-05-09, similarity 0.7502):
[0001564590-19-017942:note_history:61]
|  |  | Quarter ended April 2, 2018 |  |
|  |  | PCB |  |  | E-M Solutions |  |  | Total |  |
| End Markets |  | (In thousands) |  |
| Aerospace and Defense |  | $ | 122,676 |  |  | $ | 89 |  |  | $ | 122,765 |  |
| Automotive |  |  | 116,292 |  |  |  | 19,310 |  |  |  | 135,602 |  |
| Cellular Phone |  |  | 104,860 |  |  |  | — |  |  |  | 104,860 |  |
| Computing/Storage/Peripherals |  |  | 88,542 |  |  |  | 305 |  |  |  | 88,847 |  |
| Medical/Industrial/Instrumentation |  |  | 93,634 |  |  |  | 7,523 |  |  |  | 101,157 |  |
| Networking/Communications |  |  | 81,937 |  |  |  | 19,473 |  |  |  | 101,410 |  |
| Other |  |  | 8,490 |  |  |  | 451 |  |  |  | 8,941 |  |
| Total |  | $ | 616,431 |  |  | $ | 47,151 |  |  | $ | 663,582 |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2019-08-07):
[0001564590-19-030026:note_history:62]
As of July 1, 2019, the aggregate amount of the transaction price allocated to remaining performance obligations for long-term contracts was $20,097. The Company expects to recognize revenue on approximately 94% of the remaining performance obligations for the Company’s long-term contracts over the next twelve months with the remaining amount recognized thereafter. The remaining performance obligations for the Company’s short-term contracts are expected to be recognized within one year or less.
  (was, 2019-05-09, similarity 0.9908):
[0001564590-19-017942:note_history:62]
As of April 1, 2019, the aggregate amount of the transaction price allocated to remaining performance obligations for long-term contracts was $20,601. The Company expects to recognize revenue on approximately 85% of the remaining performance obligations for the Company’s long-term contracts over the next twelve months with the remaining amount recognized thereafter. The remaining performance obligations for the Company’s short-term contracts are expected to be recognized within one year or less.

- changed (2019-08-07):
[0001564590-19-030026:note_history:63]
Revenue from products and services transferred to customers over time and at a point in time accounted for 97% and 3%, respectively, of the Company’s revenue for the quarter and two quarters ended July 1, 2019.
  (was, 2019-05-09, similarity 0.9361):
[0001564590-19-017942:note_history:63]
Revenue from products and services transferred to customers over time and at a point in time accounted for 97% and 3%, respectively of the Company’s revenue for the quarter ended April 1, 2019.

- changed (2019-08-07):
[0001564590-19-030026:note_history:64]
|  |  | Quarter Ended July 1, 2019 |  |  | Quarter Ended July 2, 2018 |  |
|  |  | PCB |  |  | E-M Solutions |  |  | Total |  |  | PCB |  |  | E-M Solutions |  |  | Total |  |
| End Markets |  | (In thousands) |  |
| Aerospace and Defense |  | $ | 175,301 |  |  | $ | 362 |  |  | $ | 175,663 |  |  | $ | 162,951 |  |  | $ | 455 |  |  | $ | 163,406 |  |
| Automotive |  |  | 79,048 |  |  |  | 23,993 |  |  |  | 103,041 |  |  |  | 110,607 |  |  |  | 25,854 |  |  |  | 136,461 |  |
| Cellular Phone |  |  | 40,094 |  |  |  | — |  |  |  | 40,094 |  |  |  | 55,393 |  |  |  | — |  |  |  | 55,393 |  |
| Computing/Storage/Peripherals |  |  | 95,127 |  |  |  | — |  |  |  | 95,127 |  |  |  | 109,633 |  |  |  | 568 |  |  |  | 110,201 |  |
| Medical/Industrial/Instrumentation |  |  | 87,471 |  |  |  | 9,641 |  |  |  | 97,112 |  |  |  | 96,704 |  |  |  | 9,856 |  |  |  | 106,560 |  |
| Networking/Communications |  |  | 79,937 |  |  |  | 25,926 |  |  |  | 105,863 |  |  |  | 99,353 |  |  |  | 24,602 |  |  |  | 123,955 |  |
| Other |  |  | 16,143 |  |  |  | (5 | ) |  |  | 16,138 |  |  |  | 20,404 |  |  |  | 507 |  |  |  | 20,911 |  |
| Total |  | $ | 573,121 |  |  | $ | 59,917 |  |  | $ | 633,038 |  |  | $ | 655,045 |  |  | $ | 61,842 |  |  | $ | 716,887 |  |
  (was, 2019-05-09, similarity 0.7678):
[0001564590-19-017942:note_history:64]
|  |  | Quarter ended April 1, 2019 |  |
|  |  | PCB |  |  | E-M Solutions |  |  | Total |  |
| End Markets |  | (In thousands) |  |
| Aerospace and Defense |  | $ | 165,068 |  |  | $ | 4 |  |  | $ | 165,072 |  |
| Automotive |  |  | 85,813 |  |  |  | 19,765 |  |  |  | 105,578 |  |
| Cellular Phone |  |  | 43,084 |  |  |  | — |  |  |  | 43,084 |  |
| Computing/Storage/Peripherals |  |  | 80,892 |  |  |  | 189 |  |  |  | 81,081 |  |
| Medical/Industrial/Instrumentation |  |  | 87,670 |  |  |  | 8,167 |  |  |  | 95,837 |  |
| Networking/Communications |  |  | 88,063 |  |  |  | 23,339 |  |  |  | 111,402 |  |
| Other |  |  | 18,232 |  |  |  | (86 | ) |  |  | 18,146 |  |
| Total |  | $ | 568,822 |  |  | $ | 51,378 |  |  | $ | 620,200 |  |

- changed (2019-08-07):
[0001564590-19-030026:note_history:65]
|  |  | Two Quarters Ended July 1, 2019 |  |  | Two Quarters Ended July 2, 2018 |  |
|  |  | PCB |  |  | E-M Solutions |  |  | Total |  |  | PCB |  |  | E-M Solutions |  |  | Total |  |
| End Markets |  | (In thousands) |  |
| Aerospace and Defense |  | $ | 340,369 |  |  | $ | 366 |  |  | $ | 340,735 |  |  | $ | 285,627 |  |  | $ | 544 |  |  | $ | 286,171 |  |
| Automotive |  |  | 164,861 |  |  |  | 43,758 |  |  |  | 208,619 |  |  |  | 226,899 |  |  |  | 45,164 |  |  |  | 272,063 |  |
| Cellular Phone |  |  | 83,178 |  |  |  | — |  |  |  | 83,178 |  |  |  | 160,253 |  |  |  | — |  |  |  | 160,253 |  |
| Computing/Storage/Peripherals |  |  | 176,019 |  |  |  | 189 |  |  |  | 176,208 |  |  |  | 198,175 |  |  |  | 873 |  |  |  | 199,048 |  |
| Medical/Industrial/Instrumentation |  |  | 175,141 |  |  |  | 17,808 |  |  |  | 192,949 |  |  |  | 190,338 |  |  |  | 17,379 |  |  |  | 207,717 |  |
| Networking/Communications |  |  | 168,000 |  |  |  | 49,265 |  |  |  | 217,265 |  |  |  | 181,290 |  |  |  | 44,075 |  |  |  | 225,365 |  |
| Other |  |  | 34,375 |  |  |  | (91 | ) |  |  | 34,284 |  |  |  | 28,894 |  |  |  | 958 |  |  |  | 29,852 |  |
| Total |  | $ | 1,141,943 |  |  | $ | 111,295 |  |  | $ | 1,253,238 |  |  | $ | 1,271,476 |  |  | $ | 108,993 |  |  | $ | 1,380,469 |  |
  (was, 2019-05-09, similarity 0.7502):
[0001564590-19-017942:note_history:65]
|  |  | Quarter ended April 2, 2018 |  |
|  |  | PCB |  |  | E-M Solutions |  |  | Total |  |
| End Markets |  | (In thousands) |  |
| Aerospace and Defense |  | $ | 122,676 |  |  | $ | 89 |  |  | $ | 122,765 |  |
| Automotive |  |  | 116,292 |  |  |  | 19,310 |  |  |  | 135,602 |  |
| Cellular Phone |  |  | 104,860 |  |  |  | — |  |  |  | 104,860 |  |
| Computing/Storage/Peripherals |  |  | 88,542 |  |  |  | 305 |  |  |  | 88,847 |  |
| Medical/Industrial/Instrumentation |  |  | 93,634 |  |  |  | 7,523 |  |  |  | 101,157 |  |
| Networking/Communications |  |  | 81,937 |  |  |  | 19,473 |  |  |  | 101,410 |  |
| Other |  |  | 8,490 |  |  |  | 451 |  |  |  | 8,941 |  |
| Total |  | $ | 616,431 |  |  | $ | 47,151 |  |  | $ | 663,582 |  |
