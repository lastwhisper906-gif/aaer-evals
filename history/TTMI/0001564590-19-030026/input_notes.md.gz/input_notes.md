# TTMI notes — 0001564590-19-030026


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureAndSignificantAccountingPoliciesTextBlock

[0001564590-19-030026:notes:1]
(1) Nature of Operations and Basis of Presentation

[0001564590-19-030026:notes:2]
[same as prior period, unchanged from 0001564590-19-017942:notes:2]

[0001564590-19-030026:notes:3]
[same as prior period, unchanged from 0001564590-19-017942:notes:3]

[0001564590-19-030026:notes:4]
[same as prior period, unchanged from 0001564590-19-017942:notes:4]

[0001564590-19-030026:notes:5]
[same as prior period, unchanged from 0001564590-19-017942:notes:5]

[0001564590-19-030026:notes:6]
Certain amounts in the prior period consolidated condensed financial statement have been reclassified to conform to the presentation of the current period consolidated condensed financial statement. These reclassifications had no effect on the previously reported net income. An adjustment has been made to combine the statutory surplus reserve with retained earnings on the consolidated condensed balance sheet and the consolidated condensed statement of stockholders’ equity.

[0001564590-19-030026:notes:7]
[same as prior period, unchanged from 0001564590-19-017942:notes:12]

[0001564590-19-030026:notes:8]
Recently Adopted Accounting Standards

[0001564590-19-030026:notes:9]
In February 2016, the Financial Accounting Standards Board (FASB) issued ASU 2016-02, Leases (Topic 842) which supersedes the existing lease recognition requirements in the current accounting standard for leases. The core principal of the new standard is that an entity should recognize right-of-use (ROU) assets and lease liabilities arising from a lease for both financing and operating leases, along with additional qualitative and quantitative disclosures.

[0001564590-19-030026:notes:10]
In July 2018, the FASB issued ASU 2018-11, Leases (Topic 842): Targeted Improvements. ASU 2018-11 provides additional guidance to Topic 842 including providing preparers an additional optional retrospective adoption method which allows entities to initially apply the new leases standard at the adoption date and recognize a cumulative effect adjustment to the opening balance of retained earnings. ASU 2018-11 also provides lessors a practical expedient to not separate lease from non-lease components, in certain situations.

[0001564590-19-030026:notes:11]
The Company adopted the new lease standard as of January 1, 2019 and utilized the retrospective cumulative effect adjustment transition method with a cumulative effect adjustment being recorded as of the adoption date. Therefore, comparative information has not been adjusted and continues to be reported under previous U.S. GAAP guidance for the consolidated condensed balance sheet as of December 31, 2018 and the consolidated condensed statement of operations for the quarter and two quarters ended July 2, 2018. The Company implemented internal controls and key system functionality to enable the preparation of financial information on adoption. The Company elected certain available practical expedients including the package of practical expedients permitted under the transition guidance within the new standard, which among other things, allowed the Company to carry forward the historical lease classification. Additionally, the Company elected an accounting policy to not record ROU assets and lease liabilities for leases with an initial term of twelve months or less on its consolidated condensed balance sheet.

[0001564590-19-030026:notes:12]
[same as prior period, unchanged from 0001564590-19-017942:notes:17]

[0001564590-19-030026:notes:13]
|  |  | Balance as of December 31, 2018 |  |  | New Lease Standard Adjustment |  |  | Balance as of January 1, 2019 |  |
|  |  | (In thousands) |  |
| Assets |  |  |  |  |  |  |  |  |  |  |  |  |
| Operating lease right-of-use assets |  | $ | — |  |  | $ | 16,894 |  |  | $ | 16,894 |  |
| Deposits and other non-current assets |  |  | 55,597 |  |  |  | (548 | ) |  |  | 55,049 |  |
| Liabilities |  |  |  |  |  |  |  |  |  |  |  |  |
| Other current liabilities |  |  | 113,756 |  |  |  | 2,545 |  |  |  | 116,301 |  |
| Operating lease liabilities |  |  | — |  |  |  | 14,356 |  |  |  | 14,356 |  |
| Other long-term liabilities |  |  | 94,777 |  |  |  | (555 | ) |  |  | 94,222 |  |

[0001564590-19-030026:notes:14]
The adoption of the new accounting guidance did not have a material impact to the consolidated condensed statement of operations for the quarter and two quarters ended July 1, 2019, or the consolidated condensed statement of cash flows for the two quarters ended July 1, 2019. See Note 3 for further details.

[0001564590-19-030026:notes:15]
In June 2018, the FASB issued ASU 2018-07, Compensation-Stock Compensation (Topic 718): Improvements to Nonemployee Share-based Payments. This ASU expands the scope of Topic 718 to include share-based payment transactions for acquiring goods and services from nonemployees. The effective date for the standard is for interim periods in fiscal years beginning after December 15, 2018, with early adoption permitted, but no earlier than the Company's adoption date of Topic 606. The new guidance is required to be applied retrospectively with the cumulative effect recognized at the date of initial application. The Company adopted ASU 2018-07 on January 1, 2019. The adoption did not have a material impact on the consolidated condensed financial statements or related disclosures.

[0001564590-19-030026:notes:16]
In August 2017, the FASB issued ASU 2017-12, Derivatives and Hedging (Topic 815): Targeted Improvements to Accounting for Hedging Activities. This ASU amends and simplifies existing guidance in order to allow companies to more accurately present the economic effects of risk management activities in the financial statements. ASU 2017-12 also amends the guidance surrounding the recognition of the value of hedged instruments to include the entire change in value, rather than just the effective portion, in other comprehensive income and recognized in earnings at the same time that the hedged item affects earnings for cash flow and net investment hedges. This ASU is effective for fiscal years beginning after December 15, 2018, including interim periods within those fiscal years. Early adoption is permitted. The Company adopted ASU 2017-12 on January 1, 2019. The adoption did not have a material impact on the consolidated condensed financial statements or related disclosures.

[0001564590-19-030026:notes:17]
Recently Issued Accounting Standards Not Yet Adopted

[0001564590-19-030026:notes:18]
In August 2018, the FASB issued ASU 2018-14, Compensation—Retirement Benefits—Defined Benefit Plans—General (Subtopic 715-20)—Disclosure Framework—Changes to the Disclosure Requirements for Defined Benefit Plans. The amendments in this update change the disclosure requirements for employers that sponsor defined benefit pension and/or other postretirement benefit plans. It eliminates requirements for certain disclosures that are no longer considered cost beneficial and requires new disclosures that the FASB considers pertinent. The guidance is effective for fiscal years ending after December 15, 2020. Early adoption is permitted. The Company does not anticipate the adoption will have a material impact on the consolidated condensed financial statements and related disclosures.

[0001564590-19-030026:notes:19]
In June 2016, the FASB issued ASU 2016-13, Financial Instruments-Credit Losses (Topic 326): Measurement of Credit Losses on Financial Instruments. ASU 2016-13 seeks to provide financial statement users with more decision-useful information about the expected credit losses on financial instruments, including trade receivables, and other commitments to extend credit held by a reporting entity at each reporting date. The amendments require an entity to replace the incurred loss impairment methodology in current U.S. GAAP with a methodology that reflects current expected credit losses and requires consideration of a broader range of reasonable and supportable information to inform credit loss estimates. This ASU is effective for fiscal years beginning after December 15, 2019, including interim periods within those fiscal years. Early adoption is permitted. The Company is currently evaluating the new guidance to determine the impact it may have on its consolidated condensed financial statements and related disclosures.


## us-gaap:SignificantAccountingPoliciesTextBlock

[0001564590-19-030026:notes:20]
(2) Summary of Significant Accounting Policies

[0001564590-19-030026:notes:21]
Leases

[0001564590-19-030026:notes:22]
The Company determines if an arrangement is a lease at inception. Operating leases are included in operating lease ROU assets, other current liabilities, and operating lease liabilities on the consolidated condensed balance sheets.

[0001564590-19-030026:notes:23]
ROU assets represent the Company’s right to use an underlying asset for the lease term and lease liabilities represent the Company’s obligation to make lease payments arising from the lease. Operating lease ROU assets and liabilities are recognized at commencement date based on the present value of lease payments over the lease term. As most of the Company’s leases do not provide an implicit rate, the Company uses incremental borrowing rate based on the information available at commencement date in determining the present value of lease payments. The operating lease ROU asset also includes any lease payments made and excludes lease incentives. Lease terms may include options to extend or terminate the lease when it is reasonably certain that the Company will exercise that option. Lease expense for lease payments is recognized on a straight-line basis over the lease term.

[0001564590-19-030026:notes:24]
The Company has lease agreements with lease and non-lease components and accounts for the lease and non-lease components as a single lease component.


## us-gaap:LesseeOperatingLeasesTextBlock

[0001564590-19-030026:notes:25]
(3) Leases

[0001564590-19-030026:notes:26]
The Company leases some of its manufacturing and assembly plants, sales offices and equipment under non-cancellable operating leases that expire at various dates through 2049. The majority of the Company’s lease arrangements are comprised of fixed payments and a limited number of leases consist of variable payments based on equipment usage. Certain leases contain renewal provisions at the Company’s option. Most of the leases require the Company to pay for certain other costs such as property taxes and maintenance. Certain leases also contain rent escalation clauses (step rents) that require additional rental amounts in the later years of the term. Rent expense for leases with step rents is recognized on a straight-line basis over the minimum lease term. The lease agreements do not contain any material residual value guarantees or material restrictive covenants.

[0001564590-19-030026:notes:27]
[same as prior period, unchanged from 0001564590-19-017942:notes:45]

[0001564590-19-030026:notes:28]
|  | Quarter Ended July 1, 2019 |  |  | Two Quarters Ended July 1, 2019 |  |
|  | (In thousands) |  |
| Operating lease cost | $ | 2,293 |  |  | $ | 4,524 |  |
| Variable lease cost |  | 1,811 |  |  |  | 2,002 |  |
| Short-term lease cost |  | 230 |  |  |  | 381 |  |

[0001564590-19-030026:notes:29]
[same as prior period, unchanged from 0001564590-19-017942:notes:47]

[0001564590-19-030026:notes:30]
|  | Two Quarters Ended July 1, 2019 |  |
|  | (In thousands) |  |
| Cash paid for amounts included in the measurement of lease liabilities: |  |  |  |
| Operating cash flows from operating leases | $ | 4,410 |  |
| Right-of-use assets obtained in exchange for new lease obligations: |  |  |  |
| Operating leases |  | 12,860 |  |

[0001564590-19-030026:notes:31]
[same as prior period, unchanged from 0001564590-19-017942:notes:49]

[0001564590-19-030026:notes:32]
|  | As of July 1, 2019 |  |
|  | (In thousands) |  |
| Operating lease right-of-use assets | $ | 25,625 |  |
| Other current liabilities |  | 7,376 |  |
| Operating lease liabilities |  | 18,365 |  |
| Total operating lease liabilities | $ | 25,741 |  |

[0001564590-19-030026:notes:33]
| Weighted average remaining lease term | 4.6 years |  |
| Weighted average discount rate |  | 3.97 | % |

[0001564590-19-030026:notes:34]
Maturities of operating lease liabilities were as follows (1):

[0001564590-19-030026:notes:35]
|  |  | (In thousands) |  |
| Less than one year |  | $ | 8,182 |  |
| 1 - 2 years |  |  | 6,964 |  |
| 2 - 3 years |  |  | 4,864 |  |
| 3 - 4 years |  |  | 2,449 |  |
| 4 - 5 years |  |  | 1,925 |  |
| Thereafter |  |  | 3,886 |  |
| Total lease payments |  |  | 28,270 |  |
| Less imputed interest |  |  | (2,529 | ) |
| Total |  | $ | 25,741 |  |

[0001564590-19-030026:notes:36]
|  | (1) | Excludes $851 of legally binding minimum lease payments for leases signed but not yet commenced. |

[0001564590-19-030026:notes:37]
[same as prior period, unchanged from 0001564590-19-017942:notes:54]

[0001564590-19-030026:notes:38]
[same as prior period, unchanged from 0001564590-19-017942:notes:56]

[0001564590-19-030026:notes:39]
[same as prior period, unchanged from 0001564590-19-017942:notes:57]


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0001564590-19-030026:notes:40]
(4) Revenues

[0001564590-19-030026:notes:41]
As of July 1, 2019, the aggregate amount of the transaction price allocated to remaining performance obligations for long-term contracts was $20,097. The Company expects to recognize revenue on approximately 94% of the remaining performance obligations for the Company’s long-term contracts over the next twelve months with the remaining amount recognized thereafter. The remaining performance obligations for the Company’s short-term contracts are expected to be recognized within one year or less.

[0001564590-19-030026:notes:42]
Revenue from products and services transferred to customers over time and at a point in time accounted for 97% and 3%, respectively, of the Company’s revenue for the quarter and two quarters ended July 1, 2019.

[0001564590-19-030026:notes:43]
[same as prior period, unchanged from 0001564590-19-017942:notes:27]

[0001564590-19-030026:notes:44]
|  |  | Quarter Ended July 1, 2019 |  |  | Quarter Ended July 2, 2018 |  |
|  |  | PCB |  |  | E-M Solutions |  |  | Total |  |  | PCB |  |  | E-M Solutions |  |  | Total |  |
| End Markets |  | (In thousands) |  |
| Aerospace and Defense |  | $ | 175,301 |  |  | $ | 362 |  |  | $ | 175,663 |  |  | $ | 162,951 |  |  | $ | 455 |  |  | $ | 163,406 |  |
| Automotive |  |  | 79,048 |  |  |  | 23,993 |  |  |  | 103,041 |  |  |  | 110,607 |  |  |  | 25,854 |  |  |  | 136,461 |  |
| Cellular Phone |  |  | 40,094 |  |  |  | — |  |  |  | 40,094 |  |  |  | 55,393 |  |  |  | — |  |  |  | 55,393 |  |
| Computing/Storage/Peripherals |  |  | 95,127 |  |  |  | — |  |  |  | 95,127 |  |  |  | 109,633 |  |  |  | 568 |  |  |  | 110,201 |  |
| Medical/Industrial/Instrumentation |  |  | 87,471 |  |  |  | 9,641 |  |  |  | 97,112 |  |  |  | 96,704 |  |  |  | 9,856 |  |  |  | 106,560 |  |
| Networking/Communications |  |  | 79,937 |  |  |  | 25,926 |  |  |  | 105,863 |  |  |  | 99,353 |  |  |  | 24,602 |  |  |  | 123,955 |  |
| Other |  |  | 16,143 |  |  |  | (5 | ) |  |  | 16,138 |  |  |  | 20,404 |  |  |  | 507 |  |  |  | 20,911 |  |
| Total |  | $ | 573,121 |  |  | $ | 59,917 |  |  | $ | 633,038 |  |  | $ | 655,045 |  |  | $ | 61,842 |  |  | $ | 716,887 |  |

[0001564590-19-030026:notes:45]
|  |  | Two Quarters Ended July 1, 2019 |  |  | Two Quarters Ended July 2, 2018 |  |
|  |  | PCB |  |  | E-M Solutions |  |  | Total |  |  | PCB |  |  | E-M Solutions |  |  | Total |  |
| End Markets |  | (In thousands) |  |
| Aerospace and Defense |  | $ | 340,369 |  |  | $ | 366 |  |  | $ | 340,735 |  |  | $ | 285,627 |  |  | $ | 544 |  |  | $ | 286,171 |  |
| Automotive |  |  | 164,861 |  |  |  | 43,758 |  |  |  | 208,619 |  |  |  | 226,899 |  |  |  | 45,164 |  |  |  | 272,063 |  |
| Cellular Phone |  |  | 83,178 |  |  |  | — |  |  |  | 83,178 |  |  |  | 160,253 |  |  |  | — |  |  |  | 160,253 |  |
| Computing/Storage/Peripherals |  |  | 176,019 |  |  |  | 189 |  |  |  | 176,208 |  |  |  | 198,175 |  |  |  | 873 |  |  |  | 199,048 |  |
| Medical/Industrial/Instrumentation |  |  | 175,141 |  |  |  | 17,808 |  |  |  | 192,949 |  |  |  | 190,338 |  |  |  | 17,379 |  |  |  | 207,717 |  |
| Networking/Communications |  |  | 168,000 |  |  |  | 49,265 |  |  |  | 217,265 |  |  |  | 181,290 |  |  |  | 44,075 |  |  |  | 225,365 |  |
| Other |  |  | 34,375 |  |  |  | (91 | ) |  |  | 34,284 |  |  |  | 28,894 |  |  |  | 958 |  |  |  | 29,852 |  |
| Total |  | $ | 1,141,943 |  |  | $ | 111,295 |  |  | $ | 1,253,238 |  |  | $ | 1,271,476 |  |  | $ | 108,993 |  |  | $ | 1,380,469 |  |


## us-gaap:AdditionalFinancialInformationDisclosureTextBlock

[0001564590-19-030026:notes:46]
[same as prior period, unchanged from 0001564590-19-017942:notes:58]

[0001564590-19-030026:notes:47]
|  |  | As of |  |  | As of |  |
|  |  | July 1, 2019 |  |  | December 31, 2018 |  |
|  |  | (In thousands) |  |
| Inventories: |  |  |  |  |  |  |  |  |
| Raw materials |  | $ | 102,974 |  |  | $ | 97,600 |  |
| Work-in-process |  |  | 13,083 |  |  |  | 10,299 |  |
| Finished goods |  |  | 6,092 |  |  |  | 1,478 |  |
|  |  | $ | 122,149 |  |  | $ | 109,377 |  |
| Property, plant and equipment, net: |  |  |  |  |  |  |  |  |
| Land and land use rights |  | $ | 74,850 |  |  | $ | 75,431 |  |
| Buildings and improvements |  |  | 538,003 |  |  |  | 534,122 |  |
| Machinery and equipment |  |  | 1,398,905 |  |  |  | 1,357,035 |  |
| Construction-in-progress, furniture and fixtures and other |  |  | 57,946 |  |  |  | 42,713 |  |
|  |  |  | 2,069,704 |  |  |  | 2,009,301 |  |
| Less: Accumulated depreciation |  |  | (1,032,617 | ) |  |  | (957,277 | ) |
|  |  | $ | 1,037,087 |  |  | $ | 1,052,024 |  |


## us-gaap:GoodwillDisclosureTextBlock

[0001564590-19-030026:notes:48]
[same as prior period, unchanged from 0001564590-19-017942:notes:60]

[0001564590-19-030026:notes:49]
As of July 1, 2019 and December 31, 2018, goodwill was as follows:

[0001564590-19-030026:notes:50]
|  |  | Total |  |
|  |  | (In thousands) |  |
| Balance as of July 1, 2019 and December 31, 2018 |  |  |  |  |
| Goodwill |  | $ | 938,445 |  |
| Accumulated impairment losses |  |  | (171,400 | ) |
|  |  | $ | 767,045 |  |

[0001564590-19-030026:notes:51]
[same as prior period, unchanged from 0001564590-19-017942:notes:63]

[0001564590-19-030026:notes:52]
The Company evaluates its goodwill on an annual basis during its fourth fiscal quarter and whenever events or changes in circumstances — such as significant adverse changes in business climate or operating results, changes in management strategy, coupled with a decline in the market price of its stock and market capitalization — indicate that there may be a potential impairment. During the quarter, the Company evaluated for triggering events and management did not believe that goodwill was impaired as of July 1, 2019.


## us-gaap:IntangibleAssetsDisclosureTextBlock

[0001564590-19-030026:notes:53]
[same as prior period, unchanged from 0001564590-19-017942:notes:64]

[0001564590-19-030026:notes:54]
As of July 1, 2019 and December 31, 2018, the components of definite-lived intangibles were as follows:

[0001564590-19-030026:notes:55]
|  |  | Gross Amount |  |  | Accumulated Amortization |  |  | Net Carrying Amount |  | Weighted Average Amortization Period |  |
|  |  | (In thousands) |  | (In years) |  |
| July 1, 2019 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Customer relationships |  | $ | 415,000 |  |  | $ | (103,324 | ) |  | $ | 311,676 |  |  | 10.7 |  |
| Technology |  |  | 39,500 |  |  |  | (5,705 | ) |  |  | 33,795 |  |  | 9.4 |  |
|  |  | $ | 454,500 |  |  | $ | (109,029 | ) |  | $ | 345,471 |  |  |  |  |
| December 31, 2018 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Customer relationships |  | $ | 203,634 |  |  | $ | (123,522 | ) |  | $ | 80,112 |  |  | 8.1 |  |
| Technology |  |  | 3,000 |  |  |  | (3,000 | ) |  |  | — |  |  | 3.0 |  |
| Acquired intangibles from acquisition |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Customer relationships |  |  | 267,500 |  |  |  | (15,561 | ) |  |  | 251,939 |  |  | 12.2 |  |
| Developed technology |  |  | 39,500 |  |  |  | (3,345 | ) |  |  | 36,155 |  |  | 9.4 |  |
| Backlog |  |  | 29,000 |  |  |  | (21,283 | ) |  |  | 7,717 |  |  | 0.9 |  |
|  |  | $ | 542,634 |  |  | $ | (166,711 | ) |  | $ | 375,923 |  |  |  |  |

[0001564590-19-030026:notes:56]
Definite-lived intangibles are generally amortized using the straight-line method of amortization over the estimated useful life, with the exception of certain customer relationship intangibles, which are amortized using an accelerated method of amortization based on estimated cash flows. Amortization expense was $12,447 and $19,489 for the quarters ended July 1, 2019 and July 2, 2018, respectively, and $30,452 and $25,350 for the two quarters ended July 1, 2019 and July 2, 2018, respectively. For the quarter and two quarters ended July 1, 2019, $1,180 and $2,359, respectively, of amortization expense is included in cost of goods sold.

[0001564590-19-030026:notes:57]
[same as prior period, unchanged from 0001564590-19-017942:notes:68]

[0001564590-19-030026:notes:58]
|  |  | (In thousands) |  |
| Remaining 2019 |  | $ | 22,709 |  |
| 2020 |  |  | 45,419 |  |
| 2021 |  |  | 42,108 |  |
| 2022 |  |  | 39,002 |  |
| 2023 |  |  | 36,290 |  |
| Thereafter |  |  | 159,943 |  |
|  |  | $ | 345,471 |  |


## us-gaap:LongTermDebtTextBlock

[0001564590-19-030026:notes:59]
(8) Long-term Debt and Letters of Credit

[0001564590-19-030026:notes:60]
The following table summarizes the long-term debt of the Company as of July 1, 2019 and December 31, 2018:

[0001564590-19-030026:notes:61]
|  | Interest Rate as of July 1, 2019 |  |  | Principal Outstanding as of July 1, 2019 |  |  | Interest Rate as of December 31, 2018 |  |  | Principal Outstanding as of December 31, 2018 |  |
|  | (In thousands, except interest rates) |  |
| Term Loan due September 2024 |  | 4.89 |  | % | $ | 805,879 |  |  |  | 5.00 |  | % | $ | 835,879 |  |
| Senior Notes due October 2025 |  | 5.63 |  |  |  | 375,000 |  |  |  | 5.63 |  |  |  | 375,000 |  |
| Convertible Senior Notes due December 2020 |  | 1.75 |  |  |  | 249,975 |  |  |  | 1.75 |  |  |  | 249,985 |  |
| U.S. ABL Revolving Loan due June 2024 |  | 3.76 |  |  |  | 40,000 |  |  |  | 4.00 |  |  |  | 40,000 |  |
| Asia ABL Revolving Loan due June 2024 |  | 3.79 |  |  |  | 30,000 |  |  |  | 3.90 |  |  |  | 30,000 |  |
|  |  |  |  |  |  | 1,500,854 |  |  |  |  |  |  |  | 1,530,864 |  |
| Less: Long-term debt unamortized discount |  |  |  |  |  | (17,090 | ) |  |  |  |  |  |  | (22,167 | ) |
| Long-term debt unamortized debt issuance costs |  |  |  |  |  | (14,494 | ) |  |  |  |  |  |  | (16,272 | ) |
|  |  |  |  |  |  | 1,469,270 |  |  |  |  |  |  |  | 1,492,425 |  |
| Less: current maturities |  |  |  |  |  | — |  |  |  |  |  |  |  | (30,000 | ) |
| Long-term debt, less current maturities |  |  |  |  | $ | 1,469,270 |  |  |  |  |  |  | $ | 1,462,425 |  |

[0001564590-19-030026:notes:62]
Term Loan Facility

[0001564590-19-030026:notes:63]
On April 18, 2018, the Company closed its $600,000 commitment of incremental loans concurrent with the completion of its acquisition of Anaren. At issuance, these incremental loans increased the Company’s existing balance of its Term Loan Facility due 2024 from $348,250 to $948,250. The Term Loan Facility had an outstanding balance of $805,879 as of July 1, 2019 and is included in long-term debt. The Term Loan Facility was issued at a weighted average discount of 99.7% and bears interest, at the Company’s option, at a floating rate of LIBOR plus an applicable interest margin of 2.5%, or an alternate base rate (as defined in the Term Loan Credit Agreement) plus an applicable margin of 1.5%. As of July 1, 2019, the interest rate on the outstanding borrowings under the Term Loan Facility was 4.89%. There is no provision, other than an event of default, for the interest margin to increase. The Term Loan Facility will mature on September 28, 2024. The Term Loan Facility is secured by a significant amount of the domestic assets of the Company and a pledge of 65% of voting stock of the Company’s first tier foreign subsidiaries and is structurally senior to the Company’s Senior Notes and Convertible Senior Notes. See Senior Notes and Convertible Senior Notes below.

[0001564590-19-030026:notes:64]
Based on certain parameters defined in the Term Loan Facility, including a First Lien Leverage Ratio, the Company may be required to make an additional principal payment on an annual basis beginning after fiscal year 2018, if the Company’s First Lien Leverage Ratio is greater than 2.0. For 2019, the Company is not required to make an additional principal payment as its First Lien Leverage Ratio was less than 2.0. Any remaining outstanding balance under the Term Loan Facility is due at the maturity date of September 28, 2024.

[0001564590-19-030026:notes:65]
Borrowings under the Term Loan Facility are subject to certain affirmative and negative covenants, including limitations on indebtedness, corporate transactions, investments and dispositions, and share payments.

[0001564590-19-030026:notes:66]
Senior Notes

[0001564590-19-030026:notes:67]
The $375,000 of Senior Notes, which is included in long-term debt, bear interest at a rate of 5.63% per annum. Interest is payable semiannually in arrears on April 1 and October 1 of each year beginning April 1, 2018. The Senior Notes will mature on October 1, 2025.

[0001564590-19-030026:notes:68]
Borrowings under the Senior Notes are subject to certain affirmative and negative covenants, including limitations on indebtedness, corporate transactions, investments, dispositions, and share payments.

[0001564590-19-030026:notes:69]
Convertible Senior Notes due 2020

[0001564590-19-030026:notes:70]
The Company maintains 1.75% Convertible Senior Notes in the amount of $249,975 due December 15, 2020. The Convertible Senior Notes bear interest at a rate of 1.75% per annum. Interest is payable semiannually in arrears on June 15 and December 15 of each year. The Convertible Senior Notes are senior unsecured obligations and would rank equally to the Company’s future unsecured senior indebtedness and are senior in right of payment to any of the Company’s future subordinated indebtedness.

[0001564590-19-030026:notes:71]
As of July 1, 2019 and December 31, 2018, the following summarizes the equity components of the Convertible Senior Notes included in additional paid-in capital:

[0001564590-19-030026:notes:72]
|  |  | As of July 1, 2019 |  |  | As of December 31, 2018 |  |
|  |  | Embedded conversion option — Convertible Senior Notes |  |  | Embedded conversion option — Convertible Senior Notes Issuance Costs |  |  | Total |  |  | Embedded conversion option — Convertible Senior Notes |  |  | Embedded conversion option — Convertible Senior Notes Issuance Costs |  |  | Total |  |
|  |  | (In thousands) |  |
| Convertible Senior Notes due 2020 |  | $ | 60,213 |  |  | $ | (1,916 | ) |  | $ | 58,297 |  |  | $ | 60,216 |  |  | $ | (1,916 | ) |  | $ | 58,300 |  |

[0001564590-19-030026:notes:73]
The components of interest expense resulting from the Convertible Senior Notes for the quarter and two quarters ended July 1, 2019 and July 2, 2018 were as follows:

[0001564590-19-030026:notes:74]
|  |  | Quarter Ended |  |  | Two Quarters Ended |  |
|  |  | July 1, |  |  | July 2, |  |  | July 1, |  |  | July 2, |  |
|  |  | 2019 |  |  | 2018 |  |  | 2019 |  |  | 2018 |  |
|  |  | (In thousands) |  |
| Contractual coupon interest |  | $ | 1,093 |  |  | $ | 1,093 |  |  | $ | 2,187 |  |  | $ | 2,187 |  |
| Amortization of debt discount |  | $ | 2,418 |  |  | $ | 2,267 |  |  | $ | 4,797 |  |  | $ | 4,497 |  |
| Amortization of debt issuance costs |  | $ | 243 |  |  | $ | 227 |  |  | $ | 481 |  |  | $ | 451 |  |

[0001564590-19-030026:notes:75]
Asset-Based Lending Agreements

[0001564590-19-030026:notes:76]
During June 2019, the Company amended its U.S. Asset-Based Lending Credit Agreement (U.S. ABL) and its Asia Asset-Based Lending Credit Agreement (Asia ABL) (collectively the ABL Revolving Loans). The U.S. ABL credit facility was amended to extend its maturity to June 2024, decrease the size of the facility to $150,000 and add a $100,000 incremental facility. The Asia ABL credit facility was amended to extend the maturity to June 2024 and add a $50,000 incremental facility.

[0001564590-19-030026:notes:77]
The U.S. ABL consists of two tranches comprised of a revolving credit facility for up to $150,000 and a letter of credit facility for up to $50,000, provided that at no time may amounts outstanding under the tranches exceed in aggregate $150,000 or the applicable borrowing base, which is a percentage of the principal amount of Eligible Accounts, as defined in the U.S. ABL agreement. Borrowings under the U.S. ABL bear interest at either a floating rate of LIBOR plus a margin of 138 basis points or an alternate base rate (defined as the greater of the prime rate, the New York Fed bank rate plus 0.5% or LIBOR plus 1.0%) subject to a 1.0% floor, plus an applicable margin of 38 basis points, at the Company’s option. As of July 1, 2019, the interest rate on the outstanding borrowings under the U.S. ABL was 3.76%. The applicable margin can vary based on the remaining availability of the facility, from 125 to 150 basis points for LIBOR-based loans and from 25 to 50 basis points for JP Morgan Chase Bank’s prime rate-based loans. Other than availability and an event of default, there are no other provisions for the interest margin to increase. The U.S. ABL will mature on June 3, 2024. Loans made under the U.S. ABL are secured first by all of the Company’s domestic cash, receivables and certain inventories as well as by a second position against a significant amount of the domestic assets of the Company and a pledge of 65% of the voting stock of the Company’s first tier foreign subsidiaries and are structurally senior to the Company’s Senior Notes and Convertible Senior Notes. See Senior Notes and Convertible Senior Notes above. As of July 1, 2019, $40,000 of the U.S. ABL was outstanding and classified as long-term debt, which is consistent with its maturity date.

[0001564590-19-030026:notes:78]
The Asia ABL consists of two tranches comprised of a revolving credit facility for up to $150,000 and a letter of credit facility for up to $100,000, provided that at no time may amounts outstanding under both tranches exceed in aggregate $150,000 or the applicable borrowing base, which is a percentage of the principal amount of Eligible Accounts, as defined in the Asia ABL agreement. Borrowings under the Asia ABL bear interest at a floating rate of LIBOR plus 140 basis points. As of July 1, 2019, the interest rate on the outstanding borrowings under the Asia ABL was 3.79%. There is no provision, other than an event of default, for the interest margin to increase. The Asia ABL will mature on June 4, 2024. Loans made under the Asia ABL are secured by a portion of the Company’s Asia Pacific cash and receivables and are structurally senior to the Company’s domestic obligations, including the Senior Notes and Convertible Senior Notes. See Senior Notes and Convertible Senior Notes above. As of July 1, 2019, $30,000 of the Asia ABL was outstanding and classified as long-term debt, which is consistent with its maturity date.

[0001564590-19-030026:notes:79]
The Company has up to $50,000 and $100,000 Letters of Credit Facilities under the U.S. ABL and the Asia ABL, respectively. As of July 1, 2019, letters of credit in the amount of $15,287 were outstanding under the U.S. ABL and $22,718 were outstanding under the Asia ABL with various expiration dates through May 2020. Available borrowing capacity under the U.S. ABL and the Asia ABL was $94,713 and $97,282, respectively, which considers letters of credit outstanding as of July 1, 2019.

[0001564590-19-030026:notes:80]
The Company is required to pay a commitment fee of 0.25% per annum on any unused portion of the U.S. ABL and 0.28% per annum on any unused portion of the Asia ABL. The Company incurred total commitment fees related to unused borrowing availability of $210 and $247 for the quarters ended July 1, 2019 and July 2, 2018, respectively, and $450 and $488 for the two quarters ended July 1, 2019 and July 2, 2018, respectively. Under the occurrence of certain events, the ABL Revolving Loans are subject to various financial and operational covenants, including maintaining minimum fixed charge coverage ratios.

[0001564590-19-030026:notes:81]
Other Credit Facility

[0001564590-19-030026:notes:82]
Additionally, the Company is party to a revolving loan credit facility (Chinese Revolver) with a lender in China. Under this arrangement, the lender has made available to the Company approximately $29,070 in unsecured borrowing with all terms of the borrowing to be negotiated at the time the Chinese Revolver is drawn upon. There are no commitment fees on the unused portion of the Chinese Revolver. In July 2019, the expiration of the Chinese Revolver was extended to July 2020. As of July 1, 2019, the Chinese Revolver had not been drawn upon.

[0001564590-19-030026:notes:83]
Debt Issuance and Debt Discount

[0001564590-19-030026:notes:84]
As of July 1, 2019 and December 31, 2018, remaining unamortized debt discount and debt issuance costs for the Term Loan Facility, Senior Notes and Convertible Senior Notes were as follows:

[0001564590-19-030026:notes:85]
|  |  | As of July 1, 2019 |  |  |  | As of December 31, 2018 |
|  |  | Debt Issuance Costs |  |  | Debt Discount |  |  | Effective Interest Rate |  |  |  | Debt Issuance Costs |  |  | Debt Discount |  |  | Effective Interest Rate |  |  |
|  |  | (In thousands, except interest rates) |
| Term Loan due September 2024 |  | $ | 7,303 |  |  | $ | 2,210 |  |  |  | 4.66 |  | % |  | $ | 8,229 |  |  | $ | 2,489 |  |  |  | 4.66 |  | % |
| Senior Notes due October 2025 |  |  | 5,700 |  |  | — |  |  |  | 5.92 |  |  |  |  | 6,071 |  |  | — |  |  |  | 5.92 |  |  |
| Convertible Senior Notes |  |  | 1,491 |  |  |  | 14,880 |  |  |  | 6.48 |  |  |  |  | 1,972 |  |  |  | 19,678 |  |  |  | 6.48 |  |  |
|  |  | $ | 14,494 |  |  | $ | 17,090 |  |  |  |  |  |  |  | $ | 16,272 |  |  | $ | 22,167 |  |  |  |  |  |  |

[0001564590-19-030026:notes:86]
The above debt discount and debt issuance costs are recorded as a reduction of the debt and are amortized into interest expense using an effective interest rate over the duration of the debt.

[0001564590-19-030026:notes:87]
Remaining unamortized debt issuance costs for the ABL Revolving Loans of $2,741 and $1,420 as of July 1, 2019 and December 31, 2018, respectively, are included in other non-current assets and are amortized to interest expense over the duration of the ABL Revolving Loans using the straight-line method of amortization.

[0001564590-19-030026:notes:88]
As of July 1, 2019, the remaining weighted average amortization period for all unamortized debt discount and debt issuance costs was 3.6 years.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001564590-19-030026:notes:89]
[same as prior period, unchanged from 0001564590-19-017942:notes:100]

[0001564590-19-030026:notes:90]
[same as prior period, unchanged from 0001564590-19-017942:notes:101]

[0001564590-19-030026:notes:91]
During the quarter and two quarters ended July 1, 2019, the Company’s effective tax rate was impacted by a net discrete benefit of $2,946 and $3,288, respectively. This is related mainly to release of uncertain tax positions due to the expiration of the statute of limitations in foreign jurisdictions netted against accrued interest expense on existing uncertain tax positions. Additionally, no tax benefit was recorded on the losses incurred in certain foreign jurisdictions as a result of corresponding increases in the valuation allowances in these jurisdictions.

[0001564590-19-030026:notes:92]
[same as prior period, unchanged from 0001564590-19-017942:notes:103]


## us-gaap:FinancialInstrumentsDisclosureTextBlock

[0001564590-19-030026:notes:93]
[same as prior period, unchanged from 0001564590-19-017942:notes:104]

[0001564590-19-030026:notes:94]
[same as prior period, unchanged from 0001564590-19-017942:notes:105]

[0001564590-19-030026:notes:95]
[same as prior period, unchanged from 0001564590-19-017942:notes:106]

[0001564590-19-030026:notes:96]
[same as prior period, unchanged from 0001564590-19-017942:notes:107]

[0001564590-19-030026:notes:97]
[same as prior period, unchanged from 0001564590-19-017942:notes:108]

[0001564590-19-030026:notes:98]
At inception, the Company designated the interest rate swap as a cash flow hedge and the fair value of the interest rate swap was zero. As of July 1, 2019, the fair value of the interest rate swap was recorded as a liability in the amount of $12,693 and included as a component of other long-term liabilities. The change in the fair value of the interest rate swap is recorded as a component of accumulated other comprehensive loss, net of tax. No ineffectiveness was recognized for the quarter and two quarters ended July 1, 2019 and July 2, 2018. The interest rate swap increased interest expense by $367 and $303 for the quarters ended July 1, 2019 and July 2, 2018, respectively, and $706 and $303 for the two quarters ended July 1, 2019 and July 2, 2018, respectively.

[0001564590-19-030026:notes:99]
[same as prior period, unchanged from 0001564590-19-017942:notes:110]

[0001564590-19-030026:notes:100]
The Company enters into foreign currency forward contracts to mitigate the impact of changes in foreign currency exchange rates and to reduce the volatility of purchases and other obligations generated in currencies other than its functional currencies. The Company’s foreign subsidiaries may at times purchase forward exchange contracts to manage their foreign currency risks in relation to certain purchases of machinery denominated in foreign currencies other than the Company’s functional currencies. The notional amount of the foreign exchange contracts as of July 1, 2019 and December 31, 2018 was approximately $1,608 and $4,313, respectively. The Company has designated certain of these foreign exchange contracts as cash flow hedges.

[0001564590-19-030026:notes:101]
[same as prior period, unchanged from 0001564590-19-017942:notes:112]

[0001564590-19-030026:notes:102]
|  |  |  |  | Asset / (Liability) Fair Value |  |
|  |  | Balance Sheet Location |  | July 1, 2019 |  |  | December 31, 2018 |  |
|  |  |  |  | (In thousands) |  |
| Cash flow derivative instruments designated as hedges: |  |  |  |  |  |  |  |  |
| Foreign exchange contracts |  | Prepaid expenses and other current assets |  | $ | 40 |  |  | $ | — |  |
| Interest rate swap |  | Other long-term liabilities |  |  | (12,693 | ) |  |  | (4,735 | ) |
| Cash flow derivative instruments not designated as hedges: |  |  |  |  |  |  |  |  |
| Foreign exchange contracts |  | Other current liabilities |  |  | — |  |  |  | (139 | ) |

[0001564590-19-030026:notes:103]
The following table provides information about the amounts recorded in accumulated other comprehensive loss related to derivatives designated as cash flow hedges, as well as the amounts recorded in each caption in the consolidated condensed statements of operations when derivative amounts are reclassified out of accumulated other comprehensive loss for the quarter and two quarters ended July 1, 2019 and July 2, 2018:

[0001564590-19-030026:notes:104]
|  |  |  | Quarter Ended July 1, 2019 |  |  | Quarter Ended July 2, 2018 |  |
|  | Financial Statement Caption |  | Loss Recognized in Other Comprehensive Income |  |  | Loss Reclassified into Income |  |  | Loss Recognized in Other Comprehensive Income |  |  | Loss Reclassified into Income |  |
|  |  |  | (In thousands) |  |
| Cash flow hedge: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Interest rate swap | Interest expense |  | $ | (6,077 | ) |  | $ | (367 | ) |  | $ | (1,719 | ) |  | $ | (303 | ) |
| Foreign currency forward | Depreciation expense |  |  | (5 | ) |  |  | (39 | ) |  |  | (20 | ) |  |  | (39 | ) |
|  |  |  | Two Quarters Ended July 1, 2019 |  |  | Two Quarters Ended July 2, 2018 |  |
|  | Financial Statement Caption |  | Loss Recognized in Other Comprehensive Income |  |  | Loss Reclassified into Income |  |  | Loss Recognized in Other Comprehensive Income |  |  | Loss Reclassified into Income |  |
|  |  |  | (In thousands) |  |
| Cash flow hedge: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Interest rate swap | Interest expense |  | $ | (8,663 | ) |  | $ | (706 | ) |  | $ | (1,719 | ) |  | $ | (303 | ) |
| Foreign currency forward | Depreciation expense |  |  | (5 | ) |  |  | (78 | ) |  |  | (26 | ) |  |  | (80 | ) |

[0001564590-19-030026:notes:105]
The following table provides a summary of the activity associated with the designated cash flow hedges reflected in accumulated other comprehensive loss for the two quarters ended July 1, 2019 and July 2, 2018:

[0001564590-19-030026:notes:106]
|  |  | Two Quarters Ended |  |
|  |  | July 1, |  |  | July 2, |  |
|  |  | 2019 |  |  | 2018 |  |
|  |  | (In thousands) |  |
| Beginning balance, net of tax |  | $ | (4,214 | ) |  | $ | (742 | ) |
| Changes in fair value loss, net of tax |  |  | (6,331 | ) |  |  | (1,745 | ) |
| Reclassification to earnings |  |  | 574 |  |  |  | 383 |  |
| Ending balance, net of tax |  | $ | (9,971 | ) |  | $ | (2,104 | ) |

[0001564590-19-030026:notes:107]
Based on the current yield curve, the Company expects that losses of approximately $2,956 of the accumulated other comprehensive loss will be reclassified into the statement of operations, net of tax, in the next twelve months.

[0001564590-19-030026:notes:108]
The net gain (loss) recognized in other, net in the consolidated condensed statements of operations on derivative instruments not designated as hedges is as follows:

[0001564590-19-030026:notes:109]
|  |  | Quarter Ended |  |  | Two Quarters Ended |  |
|  |  | July 1, |  |  | July 2, |  |  | July 1, |  |  | July 2, |  |
|  |  | 2019 |  |  | 2018 |  |  | 2019 |  |  | 2018 |  |
|  |  | (In thousands) |  |
| Derivative instruments not designated as hedges: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Foreign exchange contracts |  | $ | 45 |  |  | $ | (324 | ) |  | $ | 49 |  |  | $ | 103 |  |


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0001564590-19-030026:notes:110]
[same as prior period, unchanged from 0001564590-19-017942:notes:121]

[0001564590-19-030026:notes:111]
The following provides a summary of the components of accumulated other comprehensive loss, net of tax, as of July 1, 2019 and December 31, 2018:

[0001564590-19-030026:notes:112]
|  |  | Foreign Currency Translation |  |  | Pension Obligation |  |  | Gains (Losses) on Cash Flow Hedges |  |  | Total |  |
|  |  | (In thousands) |  |
| Ending balance as of December 31, 2018 |  | $ | 1,578 |  |  | $ | (1,284 | ) |  | $ | (4,214 | ) |  | $ | (3,920 | ) |
| Other comprehensive loss before reclassifications |  |  | 29 |  |  |  | 19 |  |  |  | (6,331 | ) |  |  | (6,283 | ) |
| Amounts reclassified from accumulated other comprehensive income |  |  | — |  |  |  | — |  |  |  | 574 |  |  |  | 574 |  |
| Other comprehensive loss |  |  | 29 |  |  |  | 19 |  |  |  | (5,757 | ) |  |  | (5,709 | ) |
| Ending balance as of July 1, 2019 |  | $ | 1,607 |  |  | $ | (1,265 | ) |  | $ | (9,971 | ) |  | $ | (9,629 | ) |


## us-gaap:ConcentrationRiskDisclosureTextBlock

[0001564590-19-030026:notes:113]
[same as prior period, unchanged from 0001564590-19-017942:notes:124]

[0001564590-19-030026:notes:114]
In the normal course of business, the Company extends credit to its customers. The Company performs ongoing credit evaluations of customers, does not require collateral, and considers the credit risk profile of the entity from which the receivable is due in further evaluating collection risk.

[0001564590-19-030026:notes:115]
[same as prior period, unchanged from 0001564590-19-017942:notes:126]

[0001564590-19-030026:notes:116]
For the quarter ended July 1, 2019, one customer accounted for approximately 10% of the Company’s net sales. There were no customers that accounted for 10% or more of net sales for the two quarters ended July 1, 2019. There were no customers that accounted for 10% or more of net sales for the quarter ended July 2, 2018. For the two quarters ended July 2, 2018, one customer accounted for approximately 12% of the Company’s net sales. There were no other customers that accounted for 10% or more of net sales for the quarter and two quarters ended July 1, 2019 and July 2, 2018.


## us-gaap:FairValueDisclosuresTextBlock

[0001564590-19-030026:notes:117]
[same as prior period, unchanged from 0001564590-19-017942:notes:128]

[0001564590-19-030026:notes:118]
[same as prior period, unchanged from 0001564590-19-017942:notes:129]

[0001564590-19-030026:notes:119]
The carrying amount and estimated fair value of the Company’s financial instruments as of July 1, 2019 and December 31, 2018 were as follows:

[0001564590-19-030026:notes:120]
|  |  | As of |  |  | As of |  |
|  |  | July 1, 2019 |  |  | December 31, 2018 |  |
|  |  | Carrying Amount |  |  | Fair Value |  |  | Carrying Amount |  |  | Fair Value |  |
|  |  | (In thousands) |  |
| Derivative liabilities, current |  | $ | — |  |  | $ | — |  |  | $ | 139 |  |  | $ | 139 |  |
| Derivative liabilities, non-current |  |  | 12,693 |  |  |  | 12,693 |  |  |  | 4,735 |  |  |  | 4,735 |  |
| Term Loan due September 2024 |  |  | 796,366 |  |  |  | 798,828 |  |  |  | 825,161 |  |  |  | 782,592 |  |
| Senior Notes due October 2025 |  |  | 369,300 |  |  |  | 369,274 |  |  |  | 368,929 |  |  |  | 350,880 |  |
| Convertible Senior Notes |  |  | 233,604 |  |  |  | 293,571 |  |  |  | 228,335 |  |  |  | 290,858 |  |
| ABL Revolving Loans |  |  | 70,000 |  |  |  | 70,000 |  |  |  | 70,000 |  |  |  | 70,000 |  |

[0001564590-19-030026:notes:121]
[same as prior period, unchanged from 0001564590-19-017942:notes:132]

[0001564590-19-030026:notes:122]
The fair value of the long-term debt was estimated based on quoted market prices or discounting the debt over its life using current market rates for similar debt as of July 1, 2019 and December 31, 2018, which are considered Level 2 inputs.

[0001564590-19-030026:notes:123]
[same as prior period, unchanged from 0001564590-19-017942:notes:134]

[0001564590-19-030026:notes:124]
As of July 1, 2019 and December 31, 2018, the Company’s other financial instruments also included cash and cash equivalents, accounts receivable, and accounts payable. Due to short-term maturities, the carrying amount of these instruments approximates fair value. The Company’s cash and cash equivalents as of July 1, 2019 consisted of $79,661 held in the U.S., with the remaining $204,805 held by foreign subsidiaries.

[0001564590-19-030026:notes:125]
[same as prior period, unchanged from 0001564590-19-017942:notes:136]


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001564590-19-030026:notes:126]
(14) Commitments and Contingencies

[0001564590-19-030026:notes:127]
Legal Matters

[0001564590-19-030026:notes:128]
The Company is subject to various legal matters, which it considers normal for its business activities. While the Company currently believes that the amount of any reasonably possible loss for known matters would not be material to the Company’s financial condition, the outcome of these actions is inherently difficult to predict. In the event of an adverse outcome, the ultimate potential loss could have a material adverse effect on the Company’s financial condition or results of operations in a particular period. The Company has accrued amounts for its loss contingencies which are probable and estimable as of July 1, 2019 and December 31, 2018. However, these amounts are not material to the consolidated condensed financial statements of the Company.


## us-gaap:EarningsPerShareTextBlock

[0001564590-19-030026:notes:129]
(15) Earnings Per Share

[0001564590-19-030026:notes:130]
The following is a reconciliation of the numerator and denominator used to calculate basic earnings per share and diluted earnings per share for the quarter and two quarters ended July 1, 2019 and July 2, 2018:

[0001564590-19-030026:notes:131]
|  |  | Quarter Ended |  |  | Two Quarters Ended |  |
|  |  | July 1, 2019 |  |  | July 2, 2018 |  |  | July 1, 2019 |  |  | July 2, 2018 |  |
|  |  | (In thousands, except per share amounts) |  |
| Basic earnings: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic earnings |  | $ | 3,424 |  |  | $ | 84,004 |  |  | $ | 172 |  |  | $ | 94,101 |  |
| Diluted earnings: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Net income |  | $ | 3,424 |  |  | $ | 84,004 |  |  | $ | 172 |  |  | $ | 94,101 |  |
| Interest expense from Convertible Senior Notes, net of tax |  |  | — |  |  |  | 3,587 |  |  |  | — |  |  |  | 7,135 |  |
| Diluted earnings |  | $ | 3,424 |  |  | $ | 87,591 |  |  | $ | 172 |  |  | $ | 101,236 |  |
| Basic weighted average shares |  |  | 105,470 |  |  |  | 103,553 |  |  |  | 104,893 |  |  |  | 103,030 |  |
| Dilutive effect of performance-based restricted stock units, restricted stock units and stock options |  |  | 637 |  |  |  | 1,376 |  |  |  | 967 |  |  |  | 1,603 |  |
| Dilutive effect of outstanding warrants |  |  | — |  |  |  | 3,854 |  |  |  | — |  |  |  | 3,517 |  |
| Dilutive effect of assumed conversion of Convertible Senior Notes outstanding |  |  | — |  |  |  | 25,938 |  |  |  | — |  |  |  | 25,938 |  |
| Diluted shares |  |  | 106,107 |  |  |  | 134,721 |  |  |  | 105,860 |  |  |  | 134,088 |  |
| Earnings per share: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  | $ | 0.03 |  |  | $ | 0.81 |  |  | $ | 0.00 |  |  | $ | 0.91 |  |
| Diluted |  | $ | 0.03 |  |  | $ | 0.65 |  |  | $ | 0.00 |  |  | $ | 0.75 |  |

[0001564590-19-030026:notes:132]
Performance-based restricted stock units (PRUs), restricted stock units (RSUs), and stock options to purchase 1,089 and 45 shares of common stock for the quarters ended July 1, 2019 and July 2, 2018, respectively, and 1,089 and 488 shares of common stock for the two quarters ended July 1, 2019 and July 2, 2018, respectively, were not included in the computation of diluted earnings per share because the options’ exercise prices or the total expected proceeds under the treasury stock method for PRUs, RSUs, or stock options was greater than the average market price of common shares during the applicable quarter and two quarters and, as a result, the impact would be anti-dilutive.

[0001564590-19-030026:notes:133]
Outstanding warrants for the quarter and two quarters ended July 1, 2019, to purchase common stock were not included in the computation of dilutive earnings per share because the strike price of the warrants to purchase the Company’s common stock were greater than the average market price of common shares during the applicable quarter, and therefore, the effect would be anti-dilutive.

[0001564590-19-030026:notes:134]
For the quarter and two quarters ended July 1, 2019, the effect of shares of common stock related to the Company’s Convertible Senior Notes, based on the if-converted method, were not included in the computation of dilutive earnings per share as the impact would be anti-dilutive.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001564590-19-030026:notes:135]
[same as prior period, unchanged from 0001564590-19-017942:notes:147]

[0001564590-19-030026:notes:136]
[same as prior period, unchanged from 0001564590-19-017942:notes:148]

[0001564590-19-030026:notes:137]
|  |  | Quarter Ended |  |  | Two Quarters Ended |  |
|  |  | July 1, |  |  | July 2, |  |  | July 1, |  |  | July 2, |  |
|  |  | 2019 |  |  | 2018 |  |  | 2019 |  |  | 2018 |  |
|  |  | (In thousands) |  |
| Cost of goods sold |  | $ | 570 |  |  | $ | 829 |  |  | $ | 1,275 |  |  | $ | 1,358 |  |
| Selling and marketing |  |  | 396 |  |  |  | 545 |  |  |  | 862 |  |  |  | 919 |  |
| General and administrative |  |  | 2,636 |  |  |  | 4,493 |  |  |  | 5,391 |  |  |  | 7,212 |  |
| Stock-based compensation expense recognized |  | $ | 3,602 |  |  | $ | 5,867 |  |  | $ | 7,528 |  |  | $ | 9,489 |  |

[0001564590-19-030026:notes:138]
[same as prior period, unchanged from 0001564590-19-017942:notes:150]

[0001564590-19-030026:notes:139]
The Company maintains a long-term incentive program for executives that provides for the issuance of PRUs, representing hypothetical shares of the Company’s common stock that may be issued. Under the PRU program, a target number of PRUs is typically awarded at the beginning of each three-year performance period. The number of shares of common stock released at the end of the performance period will range from zero to 2.4 times the target number depending on performance during the period. The performance metrics of the PRU program are based on (a) annual financial targets, which are based on revenue and EBITDA

[0001564590-19-030026:notes:140]
(earnings before interest, tax, depreciation, and amortization expense), each equally weighted, and (b) an overall modifier based on the Company’s total stockholder return (TSR) relative to a group of peer companies selected by the Company’s compensation committee, over the three-year performance period.

[0001564590-19-030026:notes:141]
The Company records stock-based compensation expense for PRU awards granted based on management’s periodic assessment of the annual financial performance goals to be achieved. As of July 1, 2019, management determined that vesting of the PRU awards was probable. PRUs activity for the two quarters ended July 1, 2019 was as follows:

[0001564590-19-030026:notes:142]
|  |  | Shares |  |  | Weighted Average Fair Value |  |
|  |  | (In thousands) |  |  |  |  |  |
| Outstanding shares as of December 31, 2018 |  |  | 255 |  |  | $ | 18.75 |  |
| Granted |  |  | 293 |  |  |  | 10.17 |  |
| Change in units due to annual performance achievement |  |  | (51 | ) |  |  | 10.15 |  |
| Forfeited / cancelled |  |  | (6 | ) |  |  | 15.18 |  |
| Outstanding shares as of July 1, 2019 |  |  | 491 |  |  | $ | 14.57 |  |

[0001564590-19-030026:notes:143]
The fair value of PRUs granted is calculated using a Monte Carlo simulation model, as the TSR modifier contains a market condition. For the two quarters ended July 1, 2019 and July 2, 2018, the following assumptions were used in determining the fair value:

[0001564590-19-030026:notes:144]
|  |  | Two Quarters Ended |  |
|  |  | July 1, |  |  | July 2, |  |
|  |  | 2019 (1) |  |  | 2018 (2) |  |
| Weighted-average fair value |  | $ | 10.17 |  |  | $ | 19.59 |  |
| Risk-free interest rate |  |  | 2.18 | % |  |  | 2.14 | % |
| Dividend yield |  |  | — |  |  |  | — |  |
| Expected volatility |  |  | 38 | % |  |  | 40 | % |
| Expected term in years |  |  | 1.8 |  |  |  | 1.5 |  |

[0001564590-19-030026:notes:145]
| (1) | Reflects the weighted-averages for the third year of the three-year performance period applicable to PRUs granted in 2017 and second year of the three-year performance period applicable to PRUs granted in 2018 and first year of the three-year performance period applicable to PRUs granted in 2019. |

[0001564590-19-030026:notes:146]
[same as prior period, unchanged from 0001564590-19-017942:notes:157]

[0001564590-19-030026:notes:147]
[same as prior period, unchanged from 0001564590-19-017942:notes:158]

[0001564590-19-030026:notes:148]
[same as prior period, unchanged from 0001564590-19-017942:notes:159]

[0001564590-19-030026:notes:149]
The Company granted 1,599 and 195 RSUs during the quarters ended July 1, 2019 and July 2, 2018, respectively, and 1,601 and 1,023 RSUs during the two quarters ended July 1, 2019 and July 2, 2018, respectively. The RSUs granted have a weighted-average fair value per unit of $10.04 and $16.06 for the quarters ended July 1, 2019 and July 2, 2018, respectively, and $10.04 and $15.44 for the two quarters ended July 1, 2019 and July 2, 2018, respectively. The fair value for RSUs granted is based on the closing share price of the Company’s common stock on the date of grant.

[0001564590-19-030026:notes:150]
[same as prior period, unchanged from 0001564590-19-017942:notes:161]

[0001564590-19-030026:notes:151]
The Company did not grant stock option awards during the quarter and two quarters ended July 1, 2019. During the quarter and two quarters ended July 2, 2018, the Company granted 20 stock option awards to a newly appointed member of the board which were estimated to have a fair value per share of $8.92. The fair value calculation is based on stock options granted during the period using the Black-Scholes option-pricing model on the date of grant. For the quarter and two quarters ended July 2, 2018, the fair value was determined using 3.0% as the risk-free interest rate, 43.0% as the expected volatility, 8.5 years as the expected term and no dividend yield.

[0001564590-19-030026:notes:152]
[same as prior period, unchanged from 0001564590-19-017942:notes:163]

[0001564590-19-030026:notes:153]
The following is a summary of total unrecognized compensation costs as of July 1, 2019:

[0001564590-19-030026:notes:154]
|  |  | Unrecognized Stock-Based Compensation Cost |  |  | Remaining Weighted Average Recognition Period |  |
|  |  | (In thousands) |  |  | (In years) |  |
| RSU awards |  | $ | 27,002 |  |  |  | 1.6 |  |
| PRU awards |  |  | 3,326 |  |  |  | 1.3 |  |
| Stock options |  |  | 300 |  |  |  | 1.9 |  |
|  |  | $ | 30,628 |  |  |  |  |  |


## us-gaap:SegmentReportingDisclosureTextBlock

[0001564590-19-030026:notes:155]
[same as prior period, unchanged from 0001564590-19-017942:notes:166]

[0001564590-19-030026:notes:156]
[same as prior period, unchanged from 0001564590-19-017942:notes:167]

[0001564590-19-030026:notes:157]
[same as prior period, unchanged from 0001564590-19-017942:notes:168]

[0001564590-19-030026:notes:158]
|  |  | Quarter Ended |  |  | Two Quarters Ended |  |
|  |  | July 1, 2019 |  |  | July 2, 2018 |  |  | July 1, 2019 |  |  | July 2, 2018 |  |
|  |  | (In thousands) |  |
| Net Sales: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| PCB |  | $ | 573,121 |  |  | $ | 655,045 |  |  | $ | 1,141,943 |  |  | $ | 1,271,476 |  |
| E-M Solutions |  |  | 59,917 |  |  |  | 61,842 |  |  |  | 111,295 |  |  |  | 108,993 |  |
| Total net sales |  | $ | 633,038 |  |  | $ | 716,887 |  |  | $ | 1,253,238 |  |  | $ | 1,380,469 |  |
| Operating Segment Income (Loss): |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| PCB |  | $ | 50,989 |  |  | $ | 80,964 |  |  | $ | 109,531 |  |  | $ | 144,428 |  |
| E-M Solutions |  |  | 863 |  |  |  | 2,496 |  |  |  | 2,042 |  |  |  | 2,536 |  |
| Corporate |  |  | (22,561 | ) |  |  | (32,237 | ) |  |  | (46,787 | ) |  |  | (59,879 | ) |
| Total operating segment income |  |  | 29,291 |  |  |  | 51,223 |  |  |  | 64,786 |  |  |  | 87,085 |  |
| Amortization of definite-lived intangibles (1) |  |  | (12,447 | ) |  |  | (19,489 | ) |  |  | (30,452 | ) |  |  | (25,350 | ) |
| Total operating income |  |  | 16,844 |  |  |  | 31,734 |  |  |  | 34,334 |  |  |  | 61,735 |  |
| Total other expense, net |  |  | (16,250 | ) |  |  | (14,275 | ) |  |  | (38,468 | ) |  |  | (29,129 | ) |
| Income (loss) before income taxes |  | $ | 594 |  |  | $ | 17,459 |  |  | $ | (4,134 | ) |  | $ | 32,606 |  |

[0001564590-19-030026:notes:159]
| (1) | Amortization of definite-lived intangibles primarily relates to the PCB reportable segment. For the quarter and two quarters ended July 1, 2019, $1,180 and $2,359, respectively, of amortization expense is included in cost of goods sold. |

[0001564590-19-030026:notes:160]
The Corporate category primarily includes operating expenses that are not included in the segment operating performance measures. Corporate consists primarily of corporate governance functions such as finance, accounting, information technology, facilities and human resources personnel, as well as global sales and marketing personnel, research and development costs, acquisition and integration costs associated with acquisitions.


## us-gaap:RelatedPartyTransactionsDisclosureTextBlock

[0001564590-19-030026:notes:161]
(18) Related Party Transactions

[0001564590-19-030026:notes:162]
In the normal course of business, the Company’s foreign subsidiaries purchase laminate and prepreg from related parties in which a member of the Board of Directors of the Company holds an equity interest. The Company’s foreign subsidiaries purchased laminate and prepreg from these related parties in the amount of $8,917 and $12,550 for the quarters ended July 1, 2019 and July 2, 2018, respectively, and $17,229 and $25,258 for the two quarters ended July 1, 2019 and July 2, 2018, respectively.

[0001564590-19-030026:notes:163]
As of July 1, 2019 and December 31, 2018, the Company’s consolidated condensed balance sheets included $10,537 and $10,630, respectively, in accounts payable due to related parties for purchases of laminate and prepreg and such balances are included as a component of accounts payable on the consolidated condensed balance sheets.


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0001564590-19-030026:notes:164]
(19) Restructuring Charges

[0001564590-19-030026:notes:165]
The Company periodically incurs restructuring charges as part of the integration process of recent acquisitions and to realign its operations with anticipated market demand. The Company recognized employee separation, contract termination and other costs during the quarter and two quarters ended July 1, 2019. Contract termination and other costs primarily represented plant closure costs.

[0001564590-19-030026:notes:166]
The below table summarizes such restructuring costs by reportable segment for the quarter and two quarters ended July 1, 2019:

[0001564590-19-030026:notes:167]
|  |  | Quarter Ended July 1, 2019 |  |  | Two Quarters Ended July 1, 2019 |  |  |
|  |  | Employee separation/ severance |  |  | Contract termination and other costs |  |  | Total |  |  | Employee separation/ severance |  |  | Contract termination and other costs |  |  | Total |  |  |
|  |  | (In thousands) |
| Reportable Segment: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| PCB |  | $ | 3,776 |  |  | $ | — |  |  | $ | 3,776 |  |  | $ | 4,213 |  |  | $ | — |  |  | $ | 4,213 |  |  |
| E-M Solutions |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |
| Corporate |  |  | 160 |  |  |  | 8 |  |  |  | 168 |  |  |  | 160 |  |  |  | 16 |  |  |  | 176 |  |  |
|  |  | $ | 3,936 |  |  | $ | 8 |  |  | $ | 3,944 |  |  | $ | 4,373 |  |  | $ | 16 |  |  | $ | 4,389 |  |  |

[0001564590-19-030026:notes:168]
Accrued restructuring costs are included as a component of other current liabilities in the consolidated condensed balance sheet. The below table shows the utilization of the accrued restructuring costs during the two quarters ended July 1, 2019:

[0001564590-19-030026:notes:169]
|  |  | Employee separation/ severance |  |  | Contract termination and other costs |  |  | Total |  |
|  |  | (In thousands) |  |
| Accrued at December 31, 2018 |  | $ | 3,158 |  |  | $ | 393 |  |  | $ | 3,551 |  |
| Charged to expense |  |  | 4,373 |  |  |  | 16 |  |  |  | 4,389 |  |
| Amount paid |  |  | (3,851 | ) |  |  | (61 | ) |  |  | (3,912 | ) |
| Accrued at July 1, 2019 |  | $ | 3,680 |  |  | $ | 348 |  |  | $ | 4,028 |  |
