# TTMI note change history — 0001564590-21-053547 → 0001564590-22-019520


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2022-05-11):
[0001564590-22-019520:note_history:1]
The Company is subject to various legal matters, which it considers normal for its business activities. While the Company currently believes that the amount of any reasonably possible loss for known matters would not be material to the Company’s financial condition, the outcome of these actions is inherently difficult to predict. In the event of an adverse outcome, the ultimate potential loss could have a material adverse effect on the Company’s financial condition or results of operations in a particular period. The Company has accrued amounts for its loss contingencies which are probable and estimable as of April 4, 2022 and January 3, 2022. However, these amounts are not material to the consolidated condensed financial statements of the Company.
  (was, 2021-11-02, similarity 0.9807):
[0001564590-21-053547:note_history:1]
The Company is subject to various legal matters, which it considers normal for its business activities. While the Company currently believes that the amount of any reasonably possible loss for known matters would not be material to the Company’s financial condition, the outcome of these actions is inherently difficult to predict. In the event of an adverse outcome, the ultimate potential loss could have a material adverse effect on the Company’s financial condition or results of operations in a particular period. The Company has accrued amounts for its loss contingencies which are probable and estimable as of September 27, 2021 and December 28, 2020. However, these amounts are not material to the consolidated condensed financial statements of the Company.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureAndSignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2022-05-11):
[0001564590-22-019520:note_history:2]
TTM Technologies, Inc. (the Company or TTM) is a leading global printed circuit board (PCB) manufacturer, focusing on quick-turn and volume production of technologically advanced PCBs and backplane assemblies as well as a global designer and manufacturer of high-frequency radio frequency (RF) and microwave/microelectronics components and assemblies. The Company provides time-to-market and volume production of advanced technology products and offers a one-stop design, engineering, and manufacturing solution to customers. This one-stop design, engineering, and manufacturing solution allows the Company to align technology developments with the diverse needs of the Company’s customers and to enable them to reduce the time required to develop new products and bring them to market.
  (was, 2021-11-02, similarity 0.604):
[0001564590-21-053547:note_history:2]
TTM Technologies, Inc. (the Company or TTM) is a leading global printed circuit board (PCB) manufacturer, focusing on quick-turn and volume production of technologically advanced PCBs and backplane assemblies as well as a global designer and manufacturer of high-frequency radio frequency (RF) and microwave components and assemblies. The Company provides time-to-market and volume production of advanced technology products and offers a one-stop design, engineering and manufacturing solution to customers. This one-stop design, engineering and manufacturing solution allows the Company to align technology developments with the diverse needs of the Company’s customers and to enable them to reduce the time required to develop new products and bring them to market.

- changed (2022-05-11):
[0001564590-22-019520:note_history:3]
The accompanying consolidated condensed financial statements have been prepared by the Company, without audit, pursuant to the rules and regulations of the Securities and Exchange Commission (SEC). Certain information and disclosures normally included in financial statements prepared in accordance with accounting principles generally accepted in the United States of America (U.S. GAAP) have been condensed or omitted pursuant to such rules and regulations. It is suggested that these consolidated condensed financial statements be read in conjunction with the consolidated financial statements and the notes thereto included in the Company’s most recent Annual Report on Form 10-K. The preparation of financial statements in accordance with U.S. GAAP requires management to make estimates and assumptions that affect the amounts reported in the Company’s consolidated condensed financial statements and accompanying notes. Due, in part, to the on-going coronavirus (COVID-19) global pandemic, the global economy and financial markets have been volatile, and the pandemic has contributed to disruptions in global supply chains and labor shortages and high inflation, and there is a significant amount of uncertainty about the length and severity of the consequences caused by the ongoing pandemic. The Company has considered information available to it as of the date of issuance of these financial statements and is not aware of any specific events or circumstances that would require an update to its estimates or judgments, or a revision to the carrying value of its assets or liabilities. Actual results could differ materially from those estimates. The Company uses a 52/53 week fiscal calendar with the fourth quarter ending on the Monday nearest December 31.
  (was, 2021-11-02, similarity 0.9404):
[0001564590-21-053547:note_history:3]
The accompanying consolidated condensed financial statements have been prepared by the Company, without audit, pursuant to the rules and regulations of the Securities and Exchange Commission (SEC). Certain information and disclosures normally included in financial statements prepared in accordance with accounting principles generally accepted in the United States of America (U.S. GAAP) have been condensed or omitted pursuant to such rules and regulations. It is suggested that these consolidated condensed financial statements be read in conjunction with the consolidated financial statements and the notes thereto included in the Company’s most recent Annual Report on Form 10-K. The preparation of financial statements in accordance with U.S. GAAP requires management to make estimates and assumptions that affect the amounts reported in the Company’s consolidated condensed financial statements and accompanying notes. Due to the coronavirus (COVID-19) global pandemic, the global economy and financial markets have been volatile, have contributed to disruptions in global supply chains and labor shortages, and there is a significant amount of uncertainty about the length and severity of the consequences caused by the on-going pandemic. The Company has considered information available to it as of the date of issuance of these financial statements and is not aware of any specific events or circumstances that would require an update to its estimates or judgments, or a revision to the carrying value of its assets or liabilities. Actual results could differ materially from those estimates. The Company uses a 52/53 week fiscal calendar with the fourth quarter ending on the Monday nearest December 31. Fiscal 2021 ending on January 3, 2022 will be a 53-week year with the additional week included in the fourth quarter. Fiscal 2020 was a 52-week year.

- added (2022-05-11):
[0001564590-22-019520:note_history:4]
In October 2021, the Financial Accounting Standards Board (FASB) issued Accounting Standards Update (ASU) 2021-08, Business Combinations (Topic 805): Accounting for Contract Assets and Contract Liabilities from Contracts with Customers, which requires that an acquirer recognize and measure contract assets and contract liabilities acquired in a business combination in accordance with Accounting Standards Codification (ASC) 606, Revenue from Contracts with Customers, as if it had originated the contracts. Prior to this ASU, an acquirer generally recognizes contract assets acquired and contract liabilities assumed that arose from contracts with customers at fair value on the acquisition date. The ASU is effective for fiscal years beginning after December 15, 2022, with early adoption permitted. The ASU is to be applied prospectively to business combinations occurring on or after the effective date of the amendment (or if adopted early as of an interim period, as of the beginning of the fiscal year that includes the interim period of early application). The Company early adopted ASU 2021-08 on April 4, 2022 and any impact on the condensed consolidated financial statements will be dependent on the magnitude and nature of future acquired entities.

- added (2022-05-11):
[0001564590-22-019520:note_history:5]
Recently Issued Accounting Standards Not Yet Adopted

- added (2022-05-11):
[0001564590-22-019520:note_history:6]
In November 2021, the FASB issued ASU 2021-10, Government Assistance (Topic 832): Disclosures by Business Entities about Government Assistance, which provides guidance on disclosures for transactions with a government that are accounted for by applying a grant or contribution accounting model by analogy. The guidance is effective for annual periods beginning after December 15, 2021. Early adoption is permitted. The Company does not anticipate the adoption will have a material impact on the consolidated financial statements and related disclosures.

- removed (2022-05-11):
[0001564590-21-053547:note_history:7]
On January 19, 2020, the Company entered into a definitive equity interests purchase agreement with AKMMeadville Electronics (Xiamen) Co., Ltd (the Purchaser) for the sale that was completed on April 17, 2020 of the following now former Company subsidiaries: Shanghai Kaiser Electronics Co., Ltd. (SKE), Shanghai Meadville Electronics Co., Ltd. (SME), Shanghai Meadville Science & Technology Co., Ltd. (SP) and Guangzhou Meadville Electronics Co., Ltd. (GME) (collectively, the Mobility business unit). For all periods presented in the consolidated condensed statements of operations, all sales, costs, expenses, income taxes and gain on sale attributable to the Mobility business unit have been aggregated under the caption “Income from discontinued operations, net of income taxes”. Refer to Note 2, Discontinued Operations, for additional information.

- removed (2022-05-11):
[0001564590-21-053547:note_history:8]
Unless otherwise noted, amounts and disclosures throughout these notes to consolidated condensed financial statements relate to continuing operations. These consolidated condensed financial statements reflect all adjustments (consisting only of normal recurring adjustments) which, in the opinion of management, are necessary to present fairly the financial position, the results of operations and cash flows of the Company for the periods presented. The results of operations for the interim periods are not necessarily indicative of the results to be expected for the full year.

- removed (2022-05-11):
[0001564590-21-053547:note_history:9]
Reclassifications

- removed (2022-05-11):
[0001564590-21-053547:note_history:10]
The Company currently has two reportable segments: PCB and RF and Specialty Components (RF&S Components). On April 29, 2020, the Company announced the restructuring of its E-M Solutions business unit. In prior periods, the Company’s E-M Solutions business unit consisted of three Chinese manufacturing facilities with two being in Shanghai (SH BPA and SH E-MS) and one in Shenzhen (SZ). The Company closed the SH E-MS and SZ facilities at the end of 2020 and integrated the SH BPA facility into its PCB operations. As of March 29, 2021, E-M Solutions no longer met the criteria for segment reporting. As a result of the restructuring of the E-M Solutions business unit, certain prior year amounts have been reclassified to conform to this new presentation.

- removed (2022-05-11):
[0001564590-21-053547:note_history:11]
In December 2019, the Financial Accounting Standards Board (FASB) issued ASU 2019-12, Income Taxes (Topic 740): Simplifying the Accounting for Income Taxes, which is intended to simplify various aspects related to accounting for income taxes. ASU 2019-12 removes certain exceptions to the general principles in Topic 740 and also clarifies and amends existing guidance to improve consistent application. The guidance is effective for fiscal years beginning after December 15, 2020, including interim periods within those fiscal years. Early adoption is permitted. The Company adopted this ASU as of December 29, 2020 and it did not have a material impact on its consolidated condensed financial statements and related disclosures.


## ttmi:ScheduleOfUnamortizedDiscountAndDebtIssuanceCostsTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2022-05-11):
[0001564590-22-019520:note_history:12]
As of April 4, 2022 and January 3, 2022, remaining unamortized debt discount and debt issuance costs for the Senior Notes due 2029 and Term Loan Facility are as follows:
  (was, 2021-11-02, similarity 0.8521):
[0001564590-21-053547:note_history:12]
As of September 27, 2021 and December 28, 2020, remaining unamortized debt discount and debt issuance costs for the Senior Notes due 2029, Term Loan Facility and Senior Notes due 2025 are as follows:

- changed (2022-05-11):
[0001564590-22-019520:note_history:13]
|  |  | As of April 4, 2022 |  |  | As of January 3, 2022 |
|  |  | Debt Issuance Costs |  |  | Debt Discount |  |  | Effective Interest Rate |  |  | Debt Issuance Costs |  |  | Debt Discount |  |  | Effective Interest Rate |  |  |
|  |  | (In thousands, except interest rates) |
| Senior Notes due March 2029 |  | $ | 5,280 |  |  | $ | — |  |  |  | 4.18 |  | % | $ | 5,444 |  |  | $ | — |  |  |  | 4.18 |  | % |
| Term Loan due September 2024 |  |  | 1,834 |  |  |  | 555 |  |  |  | 4.66 |  |  |  | 2,010 |  |  |  | 607 |  |  |  | 4.66 |  |  |
|  |  | $ | 7,114 |  |  | $ | 555 |  |  |  |  |  |  | $ | 7,454 |  |  | $ | 607 |  |  |  |  |  |  |
  (was, 2021-11-02, similarity 0.7384):
[0001564590-21-053547:note_history:13]
|  |  | As of September 27, 2021 |  |  | As of December 28, 2020 |
|  |  | Debt Issuance Costs |  |  | Debt Discount |  |  | Effective Interest Rate |  |  | Debt Issuance Costs |  |  | Debt Discount |  |  | Effective Interest Rate |  |  |
|  |  | (In thousands, except interest rates) |
| Senior Notes due March 2029 |  | $ | 6,114 |  |  | $ | — |  |  |  | 4.19 |  | % | $ | — |  |  | $ | — |  |  |  | — |  | % |
| Term Loan due September 2024 |  |  | 2,183 |  |  |  | 660 |  |  |  | 4.66 |  |  |  | 2,695 |  |  |  | 814 |  |  |  | 4.66 |  |  |
| Senior Notes due October 2025 |  | — |  |  | — |  |  |  | — |  |  |  | 4,517 |  |  | — |  |  |  | 5.92 |  |  |
|  |  | $ | 8,297 |  |  | $ | 660 |  |  |  |  |  |  | $ | 7,212 |  |  | $ | 814 |  |  |  |  |  |  |


## us-gaap:LongTermDebtTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2022-05-11):
[0001564590-22-019520:note_history:14]
The following table summarizes the long-term debt of the Company as of April 4, 2022 and January 3, 2022:
  (was, 2021-11-02, similarity 0.8844):
[0001564590-21-053547:note_history:14]
The following table summarizes the long-term debt of the Company as of September 27, 2021 and December 28, 2020:

- changed (2022-05-11):
[0001564590-22-019520:note_history:15]
|  |  | Interest Rate as of April 4, 2022 |  |  | Principal Outstanding as of April 4, 2022 |  |  | Interest Rate as of January 3, 2022 |  |  | Principal Outstanding as of January 3, 2022 |  |
|  |  | (In thousands) |  |
| Senior Notes due March 2029 |  |  | 4.00 |  | % | $ | 500,000 |  |  |  | 4.00 |  | % | $ | 500,000 |  |
| Term Loan due September 2024 |  |  | 2.93 |  |  |  | 405,879 |  |  |  | 2.60 |  |  |  | 405,879 |  |
| Asia ABL Revolving Loan due June 2024 |  |  | 1.83 |  |  |  | 30,000 |  |  |  | 1.50 |  |  |  | 30,000 |  |
|  |  |  |  |  |  |  | 935,879 |  |  |  |  |  |  |  | 935,879 |  |
| Less: Long-term debt unamortized discount |  |  |  |  |  |  | (555 | ) |  |  |  |  |  |  | (607 | ) |
| Long-term debt unamortized debt issuance costs |  |  |  |  |  |  | (7,114 | ) |  |  |  |  |  |  | (7,454 | ) |
|  |  |  |  |  |  |  | 928,210 |  |  |  |  |  |  |  | 927,818 |  |
| Less: current maturities |  |  |  |  |  |  | — |  |  |  |  |  |  |  | — |  |
| Long-term debt, less current maturities |  |  |  |  |  | $ | 928,210 |  |  |  |  |  |  | $ | 927,818 |  |
  (was, 2021-11-02, similarity 0.674):
[0001564590-21-053547:note_history:15]
|  |  | Interest Rate as of September 27, 2021 |  |  | Principal Outstanding as of September 27, 2021 |  |  | Interest Rate as of December 28, 2020 |  |  | Principal Outstanding as of December 28, 2020 |  |
|  |  | (In thousands) |  |
| Senior Notes due March 2029 |  |  | 4.00 |  | % | $ | 500,000 |  |  |  | — |  | % | $ | — |  |
| Term Loan due September 2024 |  |  | 2.59 |  |  |  | 405,879 |  |  |  | 2.65 |  |  |  | 405,879 |  |
| Senior Notes due October 2025 |  |  | — |  |  |  | — |  |  |  | 5.63 |  |  |  | 375,000 |  |
| U.S. ABL Revolving Loan due June 2024 |  |  | — |  |  |  | — |  |  |  | 1.40 |  |  |  | 40,000 |  |
| Asia ABL Revolving Loan due June 2024 |  |  | 1.49 |  |  |  | 30,000 |  |  |  | 1.55 |  |  |  | 30,000 |  |
|  |  |  |  |  |  |  | 935,879 |  |  |  |  |  |  |  | 850,879 |  |
| Less: Long-term debt unamortized discount |  |  |  |  |  |  | (660 | ) |  |  |  |  |  |  | (814 | ) |
| Long-term debt unamortized debt issuance costs |  |  |  |  |  |  | (8,297 | ) |  |  |  |  |  |  | (7,212 | ) |
|  |  |  |  |  |  |  | 926,922 |  |  |  |  |  |  |  | 842,853 |  |
| Less: current maturities |  |  |  |  |  |  | — |  |  |  |  |  |  |  | — |  |
| Long-term debt, less current maturities |  |  |  |  |  | $ | 926,922 |  |  |  |  |  |  | $ | 842,853 |  |

- changed (2022-05-11):
[0001564590-22-019520:note_history:16]
Borrowings under the Senior Notes due 2029 and Term Loan Facility are subject to certain affirmative and negative covenants, including limitations on indebtedness, corporate transactions, investments, dispositions, and share payments.
  (was, 2021-11-02, similarity 0.9183):
[0001564590-21-053547:note_history:16]
Borrowings under the Term Loan and Senior Notes due 2029 are subject to certain affirmative and negative covenants, including limitations on indebtedness, corporate transactions, investments, dispositions, and share payments.

- added (2022-05-11):
[0001564590-22-019520:note_history:17]
Under the occurrence of certain events, the U.S. Asset-Based Lending Credit Agreement (U.S. ABL) and Asia Asset-Based Lending Credit Agreement (Asia ABL) (collectively, the ABL Revolving Loans), are subject to various financial covenants, including leverage and fixed charge coverage ratios.

- changed (2022-05-11):
[0001564590-22-019520:note_history:18]
As of April 4, 2022 and January 3, 2022, remaining unamortized debt discount and debt issuance costs for the Senior Notes due 2029 and Term Loan Facility are as follows:
  (was, 2021-11-02, similarity 0.8521):
[0001564590-21-053547:note_history:18]
As of September 27, 2021 and December 28, 2020, remaining unamortized debt discount and debt issuance costs for the Senior Notes due 2029, Term Loan Facility and Senior Notes due 2025 are as follows:

- changed (2022-05-11):
[0001564590-22-019520:note_history:19]
|  |  | As of April 4, 2022 |  |  | As of January 3, 2022 |
|  |  | Debt Issuance Costs |  |  | Debt Discount |  |  | Effective Interest Rate |  |  | Debt Issuance Costs |  |  | Debt Discount |  |  | Effective Interest Rate |  |  |
|  |  | (In thousands, except interest rates) |
| Senior Notes due March 2029 |  | $ | 5,280 |  |  | $ | — |  |  |  | 4.18 |  | % | $ | 5,444 |  |  | $ | — |  |  |  | 4.18 |  | % |
| Term Loan due September 2024 |  |  | 1,834 |  |  |  | 555 |  |  |  | 4.66 |  |  |  | 2,010 |  |  |  | 607 |  |  |  | 4.66 |  |  |
|  |  | $ | 7,114 |  |  | $ | 555 |  |  |  |  |  |  | $ | 7,454 |  |  | $ | 607 |  |  |  |  |  |  |
  (was, 2021-11-02, similarity 0.7384):
[0001564590-21-053547:note_history:19]
|  |  | As of September 27, 2021 |  |  | As of December 28, 2020 |
|  |  | Debt Issuance Costs |  |  | Debt Discount |  |  | Effective Interest Rate |  |  | Debt Issuance Costs |  |  | Debt Discount |  |  | Effective Interest Rate |  |  |
|  |  | (In thousands, except interest rates) |
| Senior Notes due March 2029 |  | $ | 6,114 |  |  | $ | — |  |  |  | 4.19 |  | % | $ | — |  |  | $ | — |  |  |  | — |  | % |
| Term Loan due September 2024 |  |  | 2,183 |  |  |  | 660 |  |  |  | 4.66 |  |  |  | 2,695 |  |  |  | 814 |  |  |  | 4.66 |  |  |
| Senior Notes due October 2025 |  | — |  |  | — |  |  |  | — |  |  |  | 4,517 |  |  | — |  |  |  | 5.92 |  |  |
|  |  | $ | 8,297 |  |  | $ | 660 |  |  |  |  |  |  | $ | 7,212 |  |  | $ | 814 |  |  |  |  |  |  |

- changed (2022-05-11):
[0001564590-22-019520:note_history:20]
Remaining unamortized debt issuance costs for the ABL Revolving Loans of $1,214 and $1,355 as of April 4, 2022 and January 3, 2022, respectively, are included in other non-current assets and are amortized to interest expense over the duration of the ABL Revolving Loans using the straight-line method of amortization.
  (was, 2021-11-02, similarity 0.9256):
[0001564590-21-053547:note_history:20]
Remaining unamortized debt issuance costs for the ABL Revolving Loans of $1,496 and $1,919 as of September 27, 2021 and December 28, 2020, respectively, are included in other non-current assets and are amortized to interest expense over the duration of the ABL Revolving Loans using the straight-line method of amortization.

- changed (2022-05-11):
[0001564590-22-019520:note_history:21]
As of April 4, 2022, the remaining weighted average amortization period for all unamortized debt discount and debt issuance costs was 5.1 years.
  (was, 2021-11-02, similarity 0.964):
[0001564590-21-053547:note_history:21]
As of September 27, 2021, the remaining weighted average amortization period for all unamortized debt discount and debt issuance costs was 5.5 years.

- changed (2022-05-11):
[0001564590-22-019520:note_history:22]
During the quarter ended March 29, 2021, the Company recognized losses of $15,217 associated with the premium paid on extinguishment of debt and the write-off of the remaining unamortized debt issuance costs as a result of the repayment of the remaining outstanding balance of the Senior Notes due 2025.
  (was, 2021-11-02, similarity 0.9404):
[0001564590-21-053547:note_history:22]
During the three quarters ended September 27, 2021, the Company recognized losses of $15,217 associated with the premium paid on extinguishment of debt and the write-off of the remaining unamortized debt issuance costs as a result of the repayment of the remaining outstanding balance of the Senior Notes due 2025.

- removed (2022-05-11):
[0001564590-21-053547:note_history:23]
Pursuant to the Term Loan Credit Agreement, the Company may reinvest the cash proceeds received from the sale of the Mobility business unit for a period of twelve months commencing September 3, 2020. If the proceeds are not reinvested during that

- removed (2022-05-11):
[0001564590-21-053547:note_history:24]
time, the Company is required to use the proceeds to prepay the Term Loan. The Company used a portion of the cash proceeds to repay $400,000 of the Term Loan during the year ended December 28, 2020 and used the remaining cash proceeds for reinvestment pursuant to the Term Loan Credit Agreement. Permitted investments, as defined in the Term Loan Credit Agreement, include extensions of trade credit in the ordinary course of business, investments in cash and cash equivalents, permitted acquisitions, investments in assets useful in the business of the Company and its restricted subsidiaries, investments in joint ventures and unrestricted subsidiaries among others.

- removed (2022-05-11):
[0001564590-21-053547:note_history:25]
Senior Notes due 2029

- removed (2022-05-11):
[0001564590-21-053547:note_history:26]
On March 10, 2021, the Company issued $500,000 of Senior Notes due 2029, which are included in long-term debt and bear interest at a rate of 4.0% per annum. Interest is payable semiannually in arrears on March 1 and September 1 of each year beginning September 1, 2021. The Senior Notes due 2029 will mature on March 1, 2029.

- removed (2022-05-11):
[0001564590-21-053547:note_history:27]
The Company used a portion of the net proceeds from the issuance of the Senior Notes due 2029 during the quarter ended March 29, 2021 to: (i) fund the early retirement of $375,000 Senior Notes due 2025, (ii) fund the repayment of $40,000 outstanding under the U.S. Asset-Based Lending Credit Agreement (U.S. ABL) Revolving credit facility (but not terminate the commitments thereunder), and (iii) pay related premiums, fees and expenses. The Company has and intends to use the remaining net proceeds for general corporate purposes.

- removed (2022-05-11):
[0001564590-21-053547:note_history:28]
Asset-Based Lending Agreements

- removed (2022-05-11):
[0001564590-21-053547:note_history:29]
As of September 27, 2021, letters of credit in the amount of $12,346 were outstanding under the U.S. ABL and $2,606 were outstanding under the Asia Asset-Based Lending Credit Agreement (Asia ABL) with various expiration dates through September 2021. Available borrowing capacity under the U.S. ABL and the Asia ABL was $137,654 and $117,394, respectively, which considers letters of credit outstanding as of September 27, 2021.

- removed (2022-05-11):
[0001564590-21-053547:note_history:30]
Under the occurrence of certain events, the U.S. ABL and Asia ABL (collectively, the ABL Revolving Loans), are subject to various financial covenants, including leverage and fixed charge coverage ratios.


## us-gaap:ScheduleOfDebtInstrumentsTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2022-05-11):
[0001564590-22-019520:note_history:31]
The following table summarizes the long-term debt of the Company as of April 4, 2022 and January 3, 2022:
  (was, 2021-11-02, similarity 0.8844):
[0001564590-21-053547:note_history:31]
The following table summarizes the long-term debt of the Company as of September 27, 2021 and December 28, 2020:

- changed (2022-05-11):
[0001564590-22-019520:note_history:32]
|  |  | Interest Rate as of April 4, 2022 |  |  | Principal Outstanding as of April 4, 2022 |  |  | Interest Rate as of January 3, 2022 |  |  | Principal Outstanding as of January 3, 2022 |  |
|  |  | (In thousands) |  |
| Senior Notes due March 2029 |  |  | 4.00 |  | % | $ | 500,000 |  |  |  | 4.00 |  | % | $ | 500,000 |  |
| Term Loan due September 2024 |  |  | 2.93 |  |  |  | 405,879 |  |  |  | 2.60 |  |  |  | 405,879 |  |
| Asia ABL Revolving Loan due June 2024 |  |  | 1.83 |  |  |  | 30,000 |  |  |  | 1.50 |  |  |  | 30,000 |  |
|  |  |  |  |  |  |  | 935,879 |  |  |  |  |  |  |  | 935,879 |  |
| Less: Long-term debt unamortized discount |  |  |  |  |  |  | (555 | ) |  |  |  |  |  |  | (607 | ) |
| Long-term debt unamortized debt issuance costs |  |  |  |  |  |  | (7,114 | ) |  |  |  |  |  |  | (7,454 | ) |
|  |  |  |  |  |  |  | 928,210 |  |  |  |  |  |  |  | 927,818 |  |
| Less: current maturities |  |  |  |  |  |  | — |  |  |  |  |  |  |  | — |  |
| Long-term debt, less current maturities |  |  |  |  |  | $ | 928,210 |  |  |  |  |  |  | $ | 927,818 |  |
  (was, 2021-11-02, similarity 0.674):
[0001564590-21-053547:note_history:32]
|  |  | Interest Rate as of September 27, 2021 |  |  | Principal Outstanding as of September 27, 2021 |  |  | Interest Rate as of December 28, 2020 |  |  | Principal Outstanding as of December 28, 2020 |  |
|  |  | (In thousands) |  |
| Senior Notes due March 2029 |  |  | 4.00 |  | % | $ | 500,000 |  |  |  | — |  | % | $ | — |  |
| Term Loan due September 2024 |  |  | 2.59 |  |  |  | 405,879 |  |  |  | 2.65 |  |  |  | 405,879 |  |
| Senior Notes due October 2025 |  |  | — |  |  |  | — |  |  |  | 5.63 |  |  |  | 375,000 |  |
| U.S. ABL Revolving Loan due June 2024 |  |  | — |  |  |  | — |  |  |  | 1.40 |  |  |  | 40,000 |  |
| Asia ABL Revolving Loan due June 2024 |  |  | 1.49 |  |  |  | 30,000 |  |  |  | 1.55 |  |  |  | 30,000 |  |
|  |  |  |  |  |  |  | 935,879 |  |  |  |  |  |  |  | 850,879 |  |
| Less: Long-term debt unamortized discount |  |  |  |  |  |  | (660 | ) |  |  |  |  |  |  | (814 | ) |
| Long-term debt unamortized debt issuance costs |  |  |  |  |  |  | (8,297 | ) |  |  |  |  |  |  | (7,212 | ) |
|  |  |  |  |  |  |  | 926,922 |  |  |  |  |  |  |  | 842,853 |  |
| Less: current maturities |  |  |  |  |  |  | — |  |  |  |  |  |  |  | — |  |
| Long-term debt, less current maturities |  |  |  |  |  | $ | 926,922 |  |  |  |  |  |  | $ | 842,853 |  |


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2022-05-11):
[0001564590-22-019520:note_history:33]
|  |  | Quarter Ended April 4, 2022 |  |  |
|  |  | PCB |  |  | RF&S Components |  |  | Total |  |  |
| End Markets |  | (In thousands) |  |  |
| Aerospace and Defense |  | $ | 172,180 |  |  | $ | — |  |  | $ | 172,180 |  |  |
| Automotive |  |  | 115,236 |  |  |  | — |  |  |  | 115,236 |  |  |
| Data Center Computing |  |  | 91,784 |  |  |  | — |  |  |  | 91,784 |  |  |
| Medical/Industrial/Instrumentation |  |  | 120,362 |  |  |  | 1,538 |  |  |  | 121,900 |  |  |
| Networking/Communications |  |  | 63,643 |  |  |  | 13,757 |  |  |  | 77,400 |  |  |
| Other |  |  | 2,865 |  |  |  | (105 | ) |  |  | 2,760 |  |  |
| Total |  | $ | 566,070 |  |  | $ | 15,190 |  |  | $ | 581,260 |  |  |
  (was, 2021-11-02, similarity 0.6732):
[0001564590-21-053547:note_history:33]
|  |  | Quarter Ended September 27, 2021 |  |  | Quarter Ended September 28, 2020 |  |  |
|  |  | PCB |  |  | RF&S Components |  |  | Total |  |  | PCB |  |  | RF&S Components |  |  | Other (1) |  |  | Total |  |  |
| End Markets |  | (In thousands) |  |  |
| Aerospace and Defense |  | $ | 173,894 |  |  | $ | 12 |  |  | $ | 173,906 |  |  | $ | 182,558 |  |  | $ | 180 |  |  | $ | 18 |  |  | $ | 182,756 |  |  |
| Automotive |  |  | 99,205 |  |  |  | — |  |  |  | 99,205 |  |  |  | 63,114 |  |  |  | — |  |  |  | 10,097 |  |  |  | 73,211 |  |  |
| Cellular Phone |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 38 |  |  |  | — |  |  |  | — |  |  |  | 38 |  |  |
| Data Center Computing (2) |  |  | 81,202 |  |  |  | — |  |  |  | 81,202 |  |  |  | 62,554 |  |  |  | 186 |  |  |  | 34 |  |  |  | 62,774 |  |  |
| Medical/Industrial/Instrumentation |  |  | 108,879 |  |  |  | 1,467 |  |  |  | 110,346 |  |  |  | 91,836 |  |  |  | 742 |  |  |  | 2,939 |  |  |  | 95,517 |  |  |
| Networking/Communications |  |  | 74,316 |  |  |  | 12,848 |  |  |  | 87,164 |  |  |  | 74,366 |  |  |  | 7,203 |  |  |  | 8,919 |  |  |  | 90,488 |  |  |
| Other |  |  | 3,622 |  |  |  | 1,339 |  |  |  | 4,961 |  |  |  | 6,845 |  |  |  | 3,431 |  |  |  | (1,484 | ) |  |  | 8,792 |  |  |
| Total |  | $ | 541,118 |  |  | $ | 15,666 |  |  | $ | 556,784 |  |  | $ | 481,311 |  |  | $ | 11,742 |  |  | $ | 20,523 |  |  | $ | 513,576 |  |  |

- changed (2022-05-11):
[0001564590-22-019520:note_history:34]
|  |  | Quarter Ended March 29, 2021 |  |  |
|  |  | PCB |  |  | RF&S Components |  |  | Other (1) |  |  | Total |  |  |
| End Markets |  | (In thousands) |
| Aerospace and Defense |  | $ | 186,539 |  |  | $ | 6 |  |  | $ | — |  |  | $ | 186,545 |  |  |
| Automotive |  |  | 91,792 |  |  |  | — |  |  |  | 3,642 |  |  |  | 95,434 |  |  |
| Data Center Computing |  |  | 71,759 |  |  |  | 432 |  |  |  | — |  |  |  | 72,191 |  |  |
| Medical/Industrial/Instrumentation |  |  | 90,770 |  |  |  | 1,081 |  |  |  | 25 |  |  |  | 91,876 |  |  |
| Networking/Communications |  |  | 66,938 |  |  |  | 10,653 |  |  |  | 1 |  |  |  | 77,592 |  |  |
| Other |  |  | 2,688 |  |  |  | 518 |  |  |  | (412 | ) |  |  | 2,794 |  |  |
| Total |  | $ | 510,486 |  |  | $ | 12,690 |  |  | $ | 3,256 |  |  | $ | 526,432 |  |  |
  (was, 2021-11-02, similarity 0.696):
[0001564590-21-053547:note_history:34]
|  |  | Three Quarters Ended September 27, 2021 |  |  | Three Quarters Ended September 28, 2020 |  |  |
|  |  | PCB |  |  | RF&S Components |  |  | Other (1) |  |  | Total |  |  | PCB |  |  | RF&S Components |  |  | Other (1) |  |  | Total |  |  |
| End Markets |  | (In thousands) |  |  |
| Aerospace and Defense |  | $ | 545,585 |  |  | $ | 24 |  |  | $ | — |  |  | $ | 545,609 |  |  | $ | 555,882 |  |  | $ | 189 |  |  | $ | 38 |  |  | $ | 556,109 |  |  |
| Automotive |  |  | 293,890 |  |  |  | — |  |  |  | 3,642 |  |  |  | 297,532 |  |  |  | 182,970 |  |  |  | — |  |  |  | 28,693 |  |  |  | 211,663 |  |  |
| Cellular Phone |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 1,334 |  |  |  | — |  |  |  | — |  |  |  | 1,334 |  |  |
| Data Center Computing (2) |  |  | 235,191 |  |  |  | 456 |  |  |  | — |  |  |  | 235,647 |  |  |  | 192,209 |  |  |  | 663 |  |  |  | 124 |  |  |  | 192,996 |  |  |
| Medical/Industrial/Instrumentation |  |  | 303,661 |  |  |  | 3,615 |  |  |  | 25 |  |  |  | 307,301 |  |  |  | 298,117 |  |  |  | 2,336 |  |  |  | 9,247 |  |  |  | 309,700 |  |  |
| Networking/Communications |  |  | 216,982 |  |  |  | 35,451 |  |  |  | 1 |  |  |  | 252,434 |  |  |  | 240,215 |  |  |  | 19,173 |  |  |  | 20,560 |  |  |  | 279,948 |  |  |
| Other |  |  | 9,775 |  |  |  | 2,713 |  |  |  | (412 | ) |  |  | 12,076 |  |  |  | 21,429 |  |  |  | 10,913 |  |  |  | (2,572 | ) |  |  | 29,770 |  |  |
| Total |  | $ | 1,605,084 |  |  | $ | 42,259 |  |  | $ | 3,256 |  |  | $ | 1,650,599 |  |  | $ | 1,492,156 |  |  | $ | 33,274 |  |  | $ | 56,090 |  |  | $ | 1,581,520 |  |  |

- changed (2022-05-11):
[0001564590-22-019520:note_history:35]
| (1) | Other represents results from the now closed Shanghai (SH E-MS) and Shenzhen (SZ) facilities previously utilized by the Company’s former E-M Solutions business unit. |
  (was, 2021-11-02, similarity 0.6328):
[0001564590-21-053547:note_history:35]
| (1) | Other represents results from the now closed SH E-MS and SZ facilities. |

- removed (2022-05-11):
[0001564590-21-053547:note_history:36]
| (2) | Beginning in the first quarter of 2021, the Computing/Storage/Peripherals end market was renamed to Data Center Computing to better reflect the customer mix and growth prospects. There was no change to the customers included in this end market. |


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2022-05-11):
[0001564590-22-019520:note_history:37]
As of April 4, 2022, the aggregate amount of the transaction price allocated to remaining performance obligations for long-term contracts was $11,877. The Company expects to recognize revenue on approximately 48% of the remaining performance obligations for the Company’s long-term contracts over the next twelve months.
  (was, 2021-11-02, similarity 0.9774):
[0001564590-21-053547:note_history:37]
As of September 27, 2021, the aggregate amount of the transaction price allocated to remaining performance obligations for long-term contracts was $11,008. The Company expects to recognize revenue on approximately 84% of the remaining performance obligations for the Company’s long-term contracts over the next twelve months.

- changed (2022-05-11):
[0001564590-22-019520:note_history:38]
Revenue from products and services transferred to customers over time and at a point in time accounted for 97% and 3%, respectively, of the Company’s revenue for the quarter ended April 4, 2022, and 98% and 2%, respectively, of the Company’s revenue for the quarter ended March 29, 2021.
  (was, 2021-11-02, similarity 0.835):
[0001564590-21-053547:note_history:38]
Revenue from products and services transferred to customers over time and at a point in time accounted for 97% and 3%, respectively, of the Company’s revenue for the quarter and three quarters ended September 27, 2021, and 98% and 2%, respectively, of the Company’s revenue for the quarter and three quarters ended September 28, 2020.

- changed (2022-05-11):
[0001564590-22-019520:note_history:39]
|  |  | Quarter Ended April 4, 2022 |  |  |
|  |  | PCB |  |  | RF&S Components |  |  | Total |  |  |
| End Markets |  | (In thousands) |  |  |
| Aerospace and Defense |  | $ | 172,180 |  |  | $ | — |  |  | $ | 172,180 |  |  |
| Automotive |  |  | 115,236 |  |  |  | — |  |  |  | 115,236 |  |  |
| Data Center Computing |  |  | 91,784 |  |  |  | — |  |  |  | 91,784 |  |  |
| Medical/Industrial/Instrumentation |  |  | 120,362 |  |  |  | 1,538 |  |  |  | 121,900 |  |  |
| Networking/Communications |  |  | 63,643 |  |  |  | 13,757 |  |  |  | 77,400 |  |  |
| Other |  |  | 2,865 |  |  |  | (105 | ) |  |  | 2,760 |  |  |
| Total |  | $ | 566,070 |  |  | $ | 15,190 |  |  | $ | 581,260 |  |  |
  (was, 2021-11-02, similarity 0.6732):
[0001564590-21-053547:note_history:39]
|  |  | Quarter Ended September 27, 2021 |  |  | Quarter Ended September 28, 2020 |  |  |
|  |  | PCB |  |  | RF&S Components |  |  | Total |  |  | PCB |  |  | RF&S Components |  |  | Other (1) |  |  | Total |  |  |
| End Markets |  | (In thousands) |  |  |
| Aerospace and Defense |  | $ | 173,894 |  |  | $ | 12 |  |  | $ | 173,906 |  |  | $ | 182,558 |  |  | $ | 180 |  |  | $ | 18 |  |  | $ | 182,756 |  |  |
| Automotive |  |  | 99,205 |  |  |  | — |  |  |  | 99,205 |  |  |  | 63,114 |  |  |  | — |  |  |  | 10,097 |  |  |  | 73,211 |  |  |
| Cellular Phone |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 38 |  |  |  | — |  |  |  | — |  |  |  | 38 |  |  |
| Data Center Computing (2) |  |  | 81,202 |  |  |  | — |  |  |  | 81,202 |  |  |  | 62,554 |  |  |  | 186 |  |  |  | 34 |  |  |  | 62,774 |  |  |
| Medical/Industrial/Instrumentation |  |  | 108,879 |  |  |  | 1,467 |  |  |  | 110,346 |  |  |  | 91,836 |  |  |  | 742 |  |  |  | 2,939 |  |  |  | 95,517 |  |  |
| Networking/Communications |  |  | 74,316 |  |  |  | 12,848 |  |  |  | 87,164 |  |  |  | 74,366 |  |  |  | 7,203 |  |  |  | 8,919 |  |  |  | 90,488 |  |  |
| Other |  |  | 3,622 |  |  |  | 1,339 |  |  |  | 4,961 |  |  |  | 6,845 |  |  |  | 3,431 |  |  |  | (1,484 | ) |  |  | 8,792 |  |  |
| Total |  | $ | 541,118 |  |  | $ | 15,666 |  |  | $ | 556,784 |  |  | $ | 481,311 |  |  | $ | 11,742 |  |  | $ | 20,523 |  |  | $ | 513,576 |  |  |

- changed (2022-05-11):
[0001564590-22-019520:note_history:40]
|  |  | Quarter Ended March 29, 2021 |  |  |
|  |  | PCB |  |  | RF&S Components |  |  | Other (1) |  |  | Total |  |  |
| End Markets |  | (In thousands) |
| Aerospace and Defense |  | $ | 186,539 |  |  | $ | 6 |  |  | $ | — |  |  | $ | 186,545 |  |  |
| Automotive |  |  | 91,792 |  |  |  | — |  |  |  | 3,642 |  |  |  | 95,434 |  |  |
| Data Center Computing |  |  | 71,759 |  |  |  | 432 |  |  |  | — |  |  |  | 72,191 |  |  |
| Medical/Industrial/Instrumentation |  |  | 90,770 |  |  |  | 1,081 |  |  |  | 25 |  |  |  | 91,876 |  |  |
| Networking/Communications |  |  | 66,938 |  |  |  | 10,653 |  |  |  | 1 |  |  |  | 77,592 |  |  |
| Other |  |  | 2,688 |  |  |  | 518 |  |  |  | (412 | ) |  |  | 2,794 |  |  |
| Total |  | $ | 510,486 |  |  | $ | 12,690 |  |  | $ | 3,256 |  |  | $ | 526,432 |  |  |
  (was, 2021-11-02, similarity 0.696):
[0001564590-21-053547:note_history:40]
|  |  | Three Quarters Ended September 27, 2021 |  |  | Three Quarters Ended September 28, 2020 |  |  |
|  |  | PCB |  |  | RF&S Components |  |  | Other (1) |  |  | Total |  |  | PCB |  |  | RF&S Components |  |  | Other (1) |  |  | Total |  |  |
| End Markets |  | (In thousands) |  |  |
| Aerospace and Defense |  | $ | 545,585 |  |  | $ | 24 |  |  | $ | — |  |  | $ | 545,609 |  |  | $ | 555,882 |  |  | $ | 189 |  |  | $ | 38 |  |  | $ | 556,109 |  |  |
| Automotive |  |  | 293,890 |  |  |  | — |  |  |  | 3,642 |  |  |  | 297,532 |  |  |  | 182,970 |  |  |  | — |  |  |  | 28,693 |  |  |  | 211,663 |  |  |
| Cellular Phone |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 1,334 |  |  |  | — |  |  |  | — |  |  |  | 1,334 |  |  |
| Data Center Computing (2) |  |  | 235,191 |  |  |  | 456 |  |  |  | — |  |  |  | 235,647 |  |  |  | 192,209 |  |  |  | 663 |  |  |  | 124 |  |  |  | 192,996 |  |  |
| Medical/Industrial/Instrumentation |  |  | 303,661 |  |  |  | 3,615 |  |  |  | 25 |  |  |  | 307,301 |  |  |  | 298,117 |  |  |  | 2,336 |  |  |  | 9,247 |  |  |  | 309,700 |  |  |
| Networking/Communications |  |  | 216,982 |  |  |  | 35,451 |  |  |  | 1 |  |  |  | 252,434 |  |  |  | 240,215 |  |  |  | 19,173 |  |  |  | 20,560 |  |  |  | 279,948 |  |  |
| Other |  |  | 9,775 |  |  |  | 2,713 |  |  |  | (412 | ) |  |  | 12,076 |  |  |  | 21,429 |  |  |  | 10,913 |  |  |  | (2,572 | ) |  |  | 29,770 |  |  |
| Total |  | $ | 1,605,084 |  |  | $ | 42,259 |  |  | $ | 3,256 |  |  | $ | 1,650,599 |  |  | $ | 1,492,156 |  |  | $ | 33,274 |  |  | $ | 56,090 |  |  | $ | 1,581,520 |  |  |

- changed (2022-05-11):
[0001564590-22-019520:note_history:41]
| (1) | Other represents results from the now closed Shanghai (SH E-MS) and Shenzhen (SZ) facilities previously utilized by the Company’s former E-M Solutions business unit. |
  (was, 2021-11-02, similarity 0.6328):
[0001564590-21-053547:note_history:41]
| (1) | Other represents results from the now closed SH E-MS and SZ facilities. |

- removed (2022-05-11):
[0001564590-21-053547:note_history:42]
| (2) | Beginning in the first quarter of 2021, the Computing/Storage/Peripherals end market was renamed to Data Center Computing to better reflect the customer mix and growth prospects. There was no change to the customers included in this end market. |


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: no_prior_note, score: 0.0

- added (2022-05-11):
[0001564590-22-019520:note_history:43]
(18) Subsequent Events

- added (2022-05-11):
[0001564590-22-019520:note_history:44]
On April 18, 2022, the Company entered into a definitive share purchase agreement to purchase all of the issued and outstanding capital stock of Telephonics Corporation and ISC Farmingdale Corp. for an aggregate purchase price of $330,000 in cash, subject to customary working capital and certain other adjustments. The transaction is expected to close in the second quarter of 2022.
