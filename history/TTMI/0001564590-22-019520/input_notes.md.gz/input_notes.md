# TTMI notes — 0001564590-22-019520


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureAndSignificantAccountingPoliciesTextBlock

[0001564590-22-019520:notes:1]
[same as prior period, unchanged from 0001564590-21-053547:notes:1]

[0001564590-22-019520:notes:2]
TTM Technologies, Inc. (the Company or TTM) is a leading global printed circuit board (PCB) manufacturer, focusing on quick-turn and volume production of technologically advanced PCBs and backplane assemblies as well as a global designer and manufacturer of high-frequency radio frequency (RF) and microwave/microelectronics components and assemblies. The Company provides time-to-market and volume production of advanced technology products and offers a one-stop design, engineering, and manufacturing solution to customers. This one-stop design, engineering, and manufacturing solution allows the Company to align technology developments with the diverse needs of the Company’s customers and to enable them to reduce the time required to develop new products and bring them to market.

[0001564590-22-019520:notes:3]
[same as prior period, unchanged from 0001564590-21-053547:notes:3]

[0001564590-22-019520:notes:4]
The accompanying consolidated condensed financial statements have been prepared by the Company, without audit, pursuant to the rules and regulations of the Securities and Exchange Commission (SEC). Certain information and disclosures normally included in financial statements prepared in accordance with accounting principles generally accepted in the United States of America (U.S. GAAP) have been condensed or omitted pursuant to such rules and regulations. It is suggested that these consolidated condensed financial statements be read in conjunction with the consolidated financial statements and the notes thereto included in the Company’s most recent Annual Report on Form 10-K. The preparation of financial statements in accordance with U.S. GAAP requires management to make estimates and assumptions that affect the amounts reported in the Company’s consolidated condensed financial statements and accompanying notes. Due, in part, to the on-going coronavirus (COVID-19) global pandemic, the global economy and financial markets have been volatile, and the pandemic has contributed to disruptions in global supply chains and labor shortages and high inflation, and there is a significant amount of uncertainty about the length and severity of the consequences caused by the ongoing pandemic. The Company has considered information available to it as of the date of issuance of these financial statements and is not aware of any specific events or circumstances that would require an update to its estimates or judgments, or a revision to the carrying value of its assets or liabilities. Actual results could differ materially from those estimates. The Company uses a 52/53 week fiscal calendar with the fourth quarter ending on the Monday nearest December 31.

[0001564590-22-019520:notes:5]
[same as prior period, unchanged from 0001564590-21-053547:notes:9]

[0001564590-22-019520:notes:6]
Recently Adopted Accounting Standards

[0001564590-22-019520:notes:7]
In October 2021, the Financial Accounting Standards Board (FASB) issued Accounting Standards Update (ASU) 2021-08, Business Combinations (Topic 805): Accounting for Contract Assets and Contract Liabilities from Contracts with Customers, which requires that an acquirer recognize and measure contract assets and contract liabilities acquired in a business combination in accordance with Accounting Standards Codification (ASC) 606, Revenue from Contracts with Customers, as if it had originated the contracts. Prior to this ASU, an acquirer generally recognizes contract assets acquired and contract liabilities assumed that arose from contracts with customers at fair value on the acquisition date. The ASU is effective for fiscal years beginning after December 15, 2022, with early adoption permitted. The ASU is to be applied prospectively to business combinations occurring on or after the effective date of the amendment (or if adopted early as of an interim period, as of the beginning of the fiscal year that includes the interim period of early application). The Company early adopted ASU 2021-08 on April 4, 2022 and any impact on the condensed consolidated financial statements will be dependent on the magnitude and nature of future acquired entities.

[0001564590-22-019520:notes:8]
Recently Issued Accounting Standards Not Yet Adopted

[0001564590-22-019520:notes:9]
In November 2021, the FASB issued ASU 2021-10, Government Assistance (Topic 832): Disclosures by Business Entities about Government Assistance, which provides guidance on disclosures for transactions with a government that are accounted for by applying a grant or contribution accounting model by analogy. The guidance is effective for annual periods beginning after December 15, 2021. Early adoption is permitted. The Company does not anticipate the adoption will have a material impact on the consolidated financial statements and related disclosures.


## us-gaap:TreasuryStockTextBlock

[0001564590-22-019520:notes:10]
(2) Share Repurchase Program

[0001564590-22-019520:notes:11]
On February 3, 2021, the Company’s Board of Directors authorized and approved a share repurchase program. Under the program, the Company may repurchase up to $100,000 in value of the Company’s outstanding shares of common stock from time to time through February 3, 2023. The Company may repurchase shares through open market purchases, privately-negotiated transactions, or otherwise in accordance with applicable federal securities laws, including Rule 10b-18 of the Securities Exchange Act of 1934, as amended (the Exchange Act) which sets certain restrictions on the method, timing, price, and volume of open market stock repurchases. In addition, the Company adopted a trading plan, which may be amended from time to time, in accordance with Rule 10b5-1 of the Exchange Act to facilitate certain purchases that may be effected under the share repurchase program. The timing, manner, price, and amount of any repurchases are determined at the Company’s discretion, and the share repurchase program may be suspended, terminated, or modified at any time for any reason. The repurchase program does not obligate the Company to acquire any specific number of shares.

[0001564590-22-019520:notes:12]
During the quarter ended April 4, 2022, the Company repurchased 2,373 shares of common stock for a total cost of $30,232 (including commissions). As of April 4, 2022, the remaining amount available to be repurchased under the Company’s share repurchase program was $5,184. Subsequent to April 4, 2022, the Company repurchased 374 shares of common stock for a total cost of $5,192 (including commissions) and there are no amounts available for repurchase as of May 4, 2022.


## us-gaap:LesseeOperatingLeasesTextBlock

[0001564590-22-019520:notes:13]
[same as prior period, unchanged from 0001564590-21-053547:notes:26]

[0001564590-22-019520:notes:14]
The Company leases some of its manufacturing and assembly plants, sales offices and equipment under non-cancellable operating leases and finance leases that expire at various dates through 2049. The majority of the Company’s lease arrangements are comprised of fixed payments, and certain leases consist of variable payments based on equipment usage. These variable payments are not included in the measurement of the right-of-use (ROU) asset or lease liability due to uncertainty of the payment amount and are recorded as lease expense in the period incurred. Certain leases contain renewal provisions at the Company’s option. Most of the leases require the Company to pay for certain other costs such as property taxes and maintenance. Certain leases also contain rent escalation clauses (step rents) that require additional rental amounts in the later years of the term. Rent expense for leases with step rents is recognized on a straight-line basis over the minimum lease term. The lease agreements do not contain any material residual value guarantees or material restrictive covenants.

[0001564590-22-019520:notes:15]
[same as prior period, unchanged from 0001564590-21-053547:notes:28]

[0001564590-22-019520:notes:16]
|  |  | Quarter Ended |  |
|  |  | April 4, 2022 |  |  | March 29, 2021 |  |
|  |  | (In thousands) |  |
| Operating lease cost |  | $ | 1,884 |  |  | $ | 2,208 |  |
| Variable lease cost |  |  | 246 |  |  |  | 234 |  |
| Short-term lease cost |  |  | 140 |  |  |  | 54 |  |
| Finance lease costs: |  |  |  |  |  |  |  |  |
| Amortization of right-of-use assets |  |  | 344 |  |  |  | — |  |
| Interest on lease liabilities |  |  | 98 |  |  |  | — |  |

[0001564590-22-019520:notes:17]
[same as prior period, unchanged from 0001564590-21-053547:notes:30]

[0001564590-22-019520:notes:18]
|  |  | Quarter Ended |  |
|  |  | April 4, 2022 |  |  | March 29, 2021 |  |
|  |  | (In thousands) |  |
| Cash paid for amounts included in the measurement of lease liabilities: |  |  |  |  |  |  |  |  |
| Operating cash flows for operating leases |  | $ | 1,861 |  |  | $ | 2,159 |  |
| Right-of-use assets obtained in exchange for new lease obligations: |  |  |  |  |  |  |  |  |
| Operating leases |  |  | 421 |  |  |  | 284 |  |

[0001564590-22-019520:notes:19]
[same as prior period, unchanged from 0001564590-21-053547:notes:32]

[0001564590-22-019520:notes:20]
|  |  |  |  | As of |  |
|  |  | Balance Sheet Location |  | April 4, 2022 |  |  | January 3, 2022 |  |
|  |  |  |  | (In thousands) |  |
| Assets: |  |  |  |  |  |  |  |  |  |  |
| Operating leases |  | Operating lease right-of-use assets |  | $ | 19,503 |  |  | $ | 20,802 |  |
| Finance leases |  | Property, plant and equipment, net |  |  | 14,415 |  |  |  | 14,759 |  |
| Total lease assets |  |  |  | $ | 33,918 |  |  | $ | 35,561 |  |
| Liabilities: |  |  |  |  |  |  |  |  |  |  |
| Current: |  |  |  |  |  |  |  |  |  |  |
| Operating leases |  | Other current liabilities |  | $ | 6,423 |  |  | $ | 6,362 |  |
| Finance leases |  | Other current liabilities |  |  | 702 |  |  |  | 698 |  |
| Long-term: |  |  |  |  |  |  |  |  |  |  |
| Operating leases |  | Operating lease liabilities |  |  | 13,917 |  |  |  | 15,252 |  |
| Finance leases |  | Other long-term liabilities |  |  | 14,139 |  |  |  | 14,317 |  |
| Total lease liabilities |  |  |  | $ | 35,181 |  |  | $ | 36,629 |  |

[0001564590-22-019520:notes:21]
|  |  | As of |  |
|  |  | April 4, 2022 |  |  | January 3, 2022 |  |
| Weighted average remaining lease term (years): |  |  |  |  |  |  |  |  |
| Operating leases |  | 3.7 |  |  | 3.9 |  |
| Finance leases |  | 14.3 |  |  | 14.6 |  |
| Weighted average discount rate: |  |  |  |  |  |  |  |  |
| Operating leases |  |  | 2.60 | % |  |  | 2.56 | % |
| Finance leases |  |  | 2.68 | % |  |  | 2.68 | % |

[0001564590-22-019520:notes:22]
Maturities of lease liabilities were as follows:

[0001564590-22-019520:notes:23]
|  |  | Operating Leases (1) |  |  | Finance Leases |  |
|  |  | (In thousands) |  |
| Less than one year |  | $ | 5,195 |  |  | $ | 817 |  |
| 1 - 2 years |  |  | 6,196 |  |  |  | 1,110 |  |
| 2 - 3 years |  |  | 5,014 |  |  |  | 1,135 |  |
| 3 - 4 years |  |  | 2,639 |  |  |  | 1,146 |  |
| 4 - 5 years |  |  | 1,474 |  |  |  | 1,175 |  |
| Thereafter |  |  | 904 |  |  |  | 12,656 |  |
| Total lease payments |  |  | 21,422 |  |  |  | 18,039 |  |
| Less imputed interest |  |  | (1,082 | ) |  |  | (3,198 | ) |
| Total |  | $ | 20,340 |  |  | $ | 14,841 |  |

[0001564590-22-019520:notes:24]
[same as prior period, unchanged from 0001564590-21-053547:notes:37]


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0001564590-22-019520:notes:25]
[same as prior period, unchanged from 0001564590-21-053547:notes:38]

[0001564590-22-019520:notes:26]
As of April 4, 2022, the aggregate amount of the transaction price allocated to remaining performance obligations for long-term contracts was $11,877. The Company expects to recognize revenue on approximately 48% of the remaining performance obligations for the Company’s long-term contracts over the next twelve months.

[0001564590-22-019520:notes:27]
Revenue from products and services transferred to customers over time and at a point in time accounted for 97% and 3%, respectively, of the Company’s revenue for the quarter ended April 4, 2022, and 98% and 2%, respectively, of the Company’s revenue for the quarter ended March 29, 2021.

[0001564590-22-019520:notes:28]
[same as prior period, unchanged from 0001564590-21-053547:notes:41]

[0001564590-22-019520:notes:29]
|  |  | Quarter Ended April 4, 2022 |  |  |
|  |  | PCB |  |  | RF&S Components |  |  | Total |  |  |
| End Markets |  | (In thousands) |  |  |
| Aerospace and Defense |  | $ | 172,180 |  |  | $ | — |  |  | $ | 172,180 |  |  |
| Automotive |  |  | 115,236 |  |  |  | — |  |  |  | 115,236 |  |  |
| Data Center Computing |  |  | 91,784 |  |  |  | — |  |  |  | 91,784 |  |  |
| Medical/Industrial/Instrumentation |  |  | 120,362 |  |  |  | 1,538 |  |  |  | 121,900 |  |  |
| Networking/Communications |  |  | 63,643 |  |  |  | 13,757 |  |  |  | 77,400 |  |  |
| Other |  |  | 2,865 |  |  |  | (105 | ) |  |  | 2,760 |  |  |
| Total |  | $ | 566,070 |  |  | $ | 15,190 |  |  | $ | 581,260 |  |  |

[0001564590-22-019520:notes:30]
|  |  | Quarter Ended March 29, 2021 |  |  |
|  |  | PCB |  |  | RF&S Components |  |  | Other (1) |  |  | Total |  |  |
| End Markets |  | (In thousands) |
| Aerospace and Defense |  | $ | 186,539 |  |  | $ | 6 |  |  | $ | — |  |  | $ | 186,545 |  |  |
| Automotive |  |  | 91,792 |  |  |  | — |  |  |  | 3,642 |  |  |  | 95,434 |  |  |
| Data Center Computing |  |  | 71,759 |  |  |  | 432 |  |  |  | — |  |  |  | 72,191 |  |  |
| Medical/Industrial/Instrumentation |  |  | 90,770 |  |  |  | 1,081 |  |  |  | 25 |  |  |  | 91,876 |  |  |
| Networking/Communications |  |  | 66,938 |  |  |  | 10,653 |  |  |  | 1 |  |  |  | 77,592 |  |  |
| Other |  |  | 2,688 |  |  |  | 518 |  |  |  | (412 | ) |  |  | 2,794 |  |  |
| Total |  | $ | 510,486 |  |  | $ | 12,690 |  |  | $ | 3,256 |  |  | $ | 526,432 |  |  |

[0001564590-22-019520:notes:31]
| (1) | Other represents results from the now closed Shanghai (SH E-MS) and Shenzhen (SZ) facilities previously utilized by the Company’s former E-M Solutions business unit. |


## us-gaap:AdditionalFinancialInformationDisclosureTextBlock

[0001564590-22-019520:notes:32]
[same as prior period, unchanged from 0001564590-21-053547:notes:46]

[0001564590-22-019520:notes:33]
|  |  | As of |  |
|  |  | April 4, 2022 |  |  | January 3, 2022 |  |
|  |  | (In thousands) |  |
| Inventories: |  |  |  |  |  |  |  |  |
| Raw materials |  | $ | 123,322 |  |  | $ | 114,653 |  |
| Work-in-process |  |  | 9,424 |  |  |  | 9,620 |  |
| Finished goods |  |  | 4,597 |  |  |  | 3,339 |  |
|  |  | $ | 137,343 |  |  | $ | 127,612 |  |
| Property, plant and equipment, net: |  |  |  |  |  |  |  |  |
| Land and land use rights |  | $ | 62,080 |  |  | $ | 62,015 |  |
| Buildings and improvements |  |  | 434,308 |  |  |  | 429,344 |  |
| Machinery and equipment |  |  | 906,406 |  |  |  | 891,925 |  |
| Furniture and fixtures and other |  |  | 10,406 |  |  |  | 10,360 |  |
| Construction-in-progress |  |  | 23,277 |  |  |  | 25,554 |  |
|  |  |  | 1,436,477 |  |  |  | 1,419,198 |  |
| Less: Accumulated depreciation |  |  | (773,083 | ) |  |  | (753,443 | ) |
|  |  | $ | 663,394 |  |  | $ | 665,755 |  |
| Other current liabilities: |  |  |  |  |  |  |  |  |
| Sales return and allowances |  | $ | 12,463 |  |  | $ | 12,853 |  |
| Income taxes payable |  |  | 10,531 |  |  |  | 7,162 |  |
| Operating lease |  |  | 6,423 |  |  |  | 6,362 |  |
| Interest |  |  | 1,948 |  |  |  | 8,741 |  |
| Derivative liabilities |  |  | 1,437 |  |  |  | 4,295 |  |
| Finance leases |  |  | 702 |  |  |  | 698 |  |
| Other |  |  | 57,617 |  |  |  | 52,918 |  |
|  |  | $ | 91,121 |  |  | $ | 93,029 |  |
| Other long-term liabilities: |  |  |  |  |  |  |  |  |
| Deferred income taxes |  | $ | 26,344 |  |  | $ | 28,361 |  |
| Finance leases |  |  | 14,139 |  |  |  | 14,317 |  |
| Defined benefit pension plan liability |  |  | 5,013 |  |  |  | 5,276 |  |
| Other |  |  | 22,130 |  |  |  | 20,958 |  |
|  |  | $ | 67,626 |  |  | $ | 68,912 |  |


## us-gaap:GoodwillDisclosureTextBlock

[0001564590-22-019520:notes:34]
[same as prior period, unchanged from 0001564590-21-053547:notes:48]

[0001564590-22-019520:notes:35]
As of April 4, 2022 and January 3, 2022, goodwill by reportable segment was as follows:

[0001564590-22-019520:notes:36]
|  |  | PCB |  | RF&S Components |  | Total |  |
|  |  | (In thousands) |  |
| Balance as of January 3, 2022 and April 4, 2022 |  |  |  |  |  |  |  |  |  |  |
| Goodwill |  | $ | 700,724 |  | $ | 177,200 |  | $ | 877,924 |  |
| Accumulated impairment losses |  |  | (171,400 | ) |  | (69,200 | ) |  | (240,600 | ) |
|  |  | $ | 529,324 |  | $ | 108,000 |  | $ | 637,324 |  |


## us-gaap:IntangibleAssetsDisclosureTextBlock

[0001564590-22-019520:notes:37]
[same as prior period, unchanged from 0001564590-21-053547:notes:51]

[0001564590-22-019520:notes:38]
As of April 4, 2022 and January 3, 2022, the components of definite-lived intangibles were as follows:

[0001564590-22-019520:notes:39]
|  |  | Gross Amount |  |  | Accumulated Amortization |  |  | Net Carrying Amount |  |  | Weighted Average Amortization Period |  |
|  |  | (In thousands) |  |  | (In years) |  |
| April 4, 2022 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Customer relationships |  | $ | 366,071 |  |  | $ | (162,736 | ) |  | $ | 203,335 |  |  |  | 11.3 |  |
| Technology |  |  | 47,650 |  |  |  | (20,725 | ) |  |  | 26,925 |  |  |  | 9.5 |  |
|  |  | $ | 413,721 |  |  | $ | (183,461 | ) |  | $ | 230,260 |  |  |  |  |  |
| January 3, 2022 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Customer relationships |  | $ | 366,071 |  |  | $ | (154,461 | ) |  | $ | 211,610 |  |  |  | 11.3 |  |
| Technology |  |  | 47,650 |  |  |  | (19,342 | ) |  |  | 28,308 |  |  |  | 9.5 |  |
|  |  | $ | 413,721 |  |  | $ | (173,803 | ) |  | $ | 239,918 |  |  |  |  |  |

[0001564590-22-019520:notes:40]
Definite-lived intangibles are amortized using the straight-line method of amortization over the useful life. Amortization expense was $9,658 and $10,905 for the quarters ended April 4, 2022 and March 29, 2021, respectively. For both the quarters ended April 4, 2022 and March 29, 2021, $1,384 of amortization expense is included in cost of goods sold.

[0001564590-22-019520:notes:41]
[same as prior period, unchanged from 0001564590-21-053547:notes:55]

[0001564590-22-019520:notes:42]
|  |  | (In thousands) |  |
| Remaining 2022 |  | $ | 28,973 |  |
| 2023 |  |  | 36,699 |  |
| 2024 |  |  | 29,516 |  |
| 2025 |  |  | 25,397 |  |
| 2026 |  |  | 25,397 |  |
| Thereafter |  |  | 84,278 |  |
|  |  | $ | 230,260 |  |


## us-gaap:LongTermDebtTextBlock

[0001564590-22-019520:notes:43]
(8) Long-term Debt and Letters of Credit

[0001564590-22-019520:notes:44]
The following table summarizes the long-term debt of the Company as of April 4, 2022 and January 3, 2022:

[0001564590-22-019520:notes:45]
|  |  | Interest Rate as of April 4, 2022 |  |  | Principal Outstanding as of April 4, 2022 |  |  | Interest Rate as of January 3, 2022 |  |  | Principal Outstanding as of January 3, 2022 |  |
|  |  | (In thousands) |  |
| Senior Notes due March 2029 |  |  | 4.00 |  | % | $ | 500,000 |  |  |  | 4.00 |  | % | $ | 500,000 |  |
| Term Loan due September 2024 |  |  | 2.93 |  |  |  | 405,879 |  |  |  | 2.60 |  |  |  | 405,879 |  |
| Asia ABL Revolving Loan due June 2024 |  |  | 1.83 |  |  |  | 30,000 |  |  |  | 1.50 |  |  |  | 30,000 |  |
|  |  |  |  |  |  |  | 935,879 |  |  |  |  |  |  |  | 935,879 |  |
| Less: Long-term debt unamortized discount |  |  |  |  |  |  | (555 | ) |  |  |  |  |  |  | (607 | ) |
| Long-term debt unamortized debt issuance costs |  |  |  |  |  |  | (7,114 | ) |  |  |  |  |  |  | (7,454 | ) |
|  |  |  |  |  |  |  | 928,210 |  |  |  |  |  |  |  | 927,818 |  |
| Less: current maturities |  |  |  |  |  |  | — |  |  |  |  |  |  |  | — |  |
| Long-term debt, less current maturities |  |  |  |  |  | $ | 928,210 |  |  |  |  |  |  | $ | 927,818 |  |

[0001564590-22-019520:notes:46]
Debt Covenants

[0001564590-22-019520:notes:47]
Borrowings under the Senior Notes due 2029 and Term Loan Facility are subject to certain affirmative and negative covenants, including limitations on indebtedness, corporate transactions, investments, dispositions, and share payments.

[0001564590-22-019520:notes:48]
Under the occurrence of certain events, the U.S. Asset-Based Lending Credit Agreement (U.S. ABL) and Asia Asset-Based Lending Credit Agreement (Asia ABL) (collectively, the ABL Revolving Loans), are subject to various financial covenants, including leverage and fixed charge coverage ratios.

[0001564590-22-019520:notes:49]
Debt Issuance and Debt Discount

[0001564590-22-019520:notes:50]
As of April 4, 2022 and January 3, 2022, remaining unamortized debt discount and debt issuance costs for the Senior Notes due 2029 and Term Loan Facility are as follows:

[0001564590-22-019520:notes:51]
|  |  | As of April 4, 2022 |  |  | As of January 3, 2022 |
|  |  | Debt Issuance Costs |  |  | Debt Discount |  |  | Effective Interest Rate |  |  | Debt Issuance Costs |  |  | Debt Discount |  |  | Effective Interest Rate |  |  |
|  |  | (In thousands, except interest rates) |
| Senior Notes due March 2029 |  | $ | 5,280 |  |  | $ | — |  |  |  | 4.18 |  | % | $ | 5,444 |  |  | $ | — |  |  |  | 4.18 |  | % |
| Term Loan due September 2024 |  |  | 1,834 |  |  |  | 555 |  |  |  | 4.66 |  |  |  | 2,010 |  |  |  | 607 |  |  |  | 4.66 |  |  |
|  |  | $ | 7,114 |  |  | $ | 555 |  |  |  |  |  |  | $ | 7,454 |  |  | $ | 607 |  |  |  |  |  |  |

[0001564590-22-019520:notes:52]
The above debt discount and debt issuance costs are recorded as a reduction of the debt and are amortized into interest expense using an effective interest rate over the duration of the debt.

[0001564590-22-019520:notes:53]
Remaining unamortized debt issuance costs for the ABL Revolving Loans of $1,214 and $1,355 as of April 4, 2022 and January 3, 2022, respectively, are included in other non-current assets and are amortized to interest expense over the duration of the ABL Revolving Loans using the straight-line method of amortization.

[0001564590-22-019520:notes:54]
As of April 4, 2022, the remaining weighted average amortization period for all unamortized debt discount and debt issuance costs was 5.1 years.

[0001564590-22-019520:notes:55]
Loss on Extinguishment of Debt

[0001564590-22-019520:notes:56]
During the quarter ended March 29, 2021, the Company recognized losses of $15,217 associated with the premium paid on extinguishment of debt and the write-off of the remaining unamortized debt issuance costs as a result of the repayment of the remaining outstanding balance of the Senior Notes due 2025.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001564590-22-019520:notes:57]
[same as prior period, unchanged from 0001564590-21-053547:notes:78]

[0001564590-22-019520:notes:58]
[same as prior period, unchanged from 0001564590-21-053547:notes:79]

[0001564590-22-019520:notes:59]
During the quarter ended April 4, 2022, the Company’s effective tax rate was impacted by a net discrete benefit of $2,047. This is mainly related to the approval of the Company’s renewal application for High and New Tax Enterprise status for two of the Company’s manufacturing subsidiaries in China, and windfall tax benefit of the stock-based compensation releases, which are offset by accrued interest expense on existing uncertain tax positions.

[0001564590-22-019520:notes:60]
[same as prior period, unchanged from 0001564590-21-053547:notes:81]


## us-gaap:FinancialInstrumentsDisclosureTextBlock

[0001564590-22-019520:notes:61]
[same as prior period, unchanged from 0001564590-21-053547:notes:82]

[0001564590-22-019520:notes:62]
[same as prior period, unchanged from 0001564590-21-053547:notes:83]

[0001564590-22-019520:notes:63]
[same as prior period, unchanged from 0001564590-21-053547:notes:84]

[0001564590-22-019520:notes:64]
[same as prior period, unchanged from 0001564590-21-053547:notes:85]

[0001564590-22-019520:notes:65]
[same as prior period, unchanged from 0001564590-21-053547:notes:86]

[0001564590-22-019520:notes:66]
At inception, the Company designated the interest rate swap as a cash flow hedge and the fair value of the interest rate swap was zero. As of April 4, 2022, the fair value of the interest rate swap was recorded as a liability in the amount of $1,385 and included as a component of other current liabilities. The change in the fair value of the interest rate swap is recorded as a component of accumulated other comprehensive loss, net of tax, in the Company’s consolidated condensed balance sheets. No ineffectiveness was recognized for the quarters ended April 4, 2022 and March 29, 2021. The interest rate swap increased interest expense by $2,706 and $2,740 for the quarters ended April 4, 2022 and March 29, 2021, respectively.

[0001564590-22-019520:notes:67]
[same as prior period, unchanged from 0001564590-21-053547:notes:88]

[0001564590-22-019520:notes:68]
The Company’s foreign subsidiaries may at times purchase forward exchange contracts to manage their foreign currency risks in relation to certain purchases of machinery denominated in foreign currencies other than the Company’s functional currencies. The notional amount of the foreign exchange contracts as of April 4, 2022 was approximately $1,625 (Euro (EUR) 1.4 million). There were no foreign exchange contracts as of January 3, 2022.

[0001564590-22-019520:notes:69]
[same as prior period, unchanged from 0001564590-21-053547:notes:90]

[0001564590-22-019520:notes:70]
The Company uses various raw materials in the manufacturing of PCBs. In particular, the Company has been experiencing increasing prices and lead times of copper clad laminates (CCLs), a key raw material for the manufacture of PCBs. CCLs are made from epoxy resin, glass cloth and copper foil, all of which are seeing limited supply and resulting increased prices. The Company only buys a small amount of copper directly. However, copper is a major driver of laminate cost. As such, the Company enters into commodity contracts to hedge copper as a proxy for hedging laminate. As of April 4, 2022, the Company has commodity contracts with a notional quantity of (i) 0.5 metric tonnes for the period beginning April 5, 2022 and ending on June 29, 2022, (ii) 0.6 metric tonnes for the period beginning June 30, 2022 and ending on October 3, 2022, (iii) 0.7 metric tonnes for the period beginning October 4, 2022 and ending on January 3, 2023, and (iv) 0.7 metric tonnes for the period beginning January 1, 2023 and ending on March 31, 2023. As of April 4, 2022, the fair value of the commodity contracts was recorded as an asset in the amount of $1,699 and included as a component of prepaid expenses and other current assets. The changes in the fair value of these commodity contracts are recorded in cost of goods sold in the consolidated condensed statements of operations. The commodity contracts decreased cost of goods sold by $1,402 for the quarter ended April 4, 2022. These commodity contracts are not designated as accounting hedges.

[0001564590-22-019520:notes:71]
[same as prior period, unchanged from 0001564590-21-053547:notes:93]

[0001564590-22-019520:notes:72]
|  |  |  |  | Asset/(Liability) Fair Value |  |
|  |  | Balance Sheet Location |  | April 4, 2022 |  |  | January 3, 2022 |  |
|  |  |  |  | (In thousands) |  |
| Cash flow derivative instruments designated as hedges: |  |  |  |  |  |  |  |  |
| Interest rate swap |  | Other current liabilities |  | $ | (1,385 | ) |  | $ | (4,295 | ) |
| Cash flow derivative instruments not designated as hedges: |  |  |  |  |  |  |  |  |
| Commodity contracts |  | Prepaid expenses and other current assets |  |  | 1,699 |  |  |  | 297 |  |
| Foreign exchange contracts |  | Other current liabilities |  |  | (52 | ) |  |  | — |  |

[0001564590-22-019520:notes:73]
The following table provides information about the amounts recorded in accumulated other comprehensive loss related to derivatives designated as cash flow hedges, as well as the amounts recorded in each caption in the consolidated condensed statements of operations when derivative amounts are reclassified out of accumulated other comprehensive loss for the quarters ended April 4, 2022 and March 29, 2021:

[0001564590-22-019520:notes:74]
|  |  |  | Quarter Ended April 4, 2022 |  |  | Quarter Ended March 29, 2021 |  |  |
|  |  | Financial Statement Caption | Gain Recognized in Other Comprehensive Income |  |  | Loss Reclassified into Income |  |  | Loss Recognized in Other Comprehensive Loss |  |  | Loss Reclassified into Income |  |  |
|  |  |  | (In thousands) |
| Cash flow hedge: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Interest rate swap |  | Interest expense | $ | 204 |  |  | $ | (2,706 | ) |  | $ | (351 | ) |  | $ | (2,740 | ) |  |

[0001564590-22-019520:notes:75]
The following table provides a summary of the activity associated with the designated cash flow hedges reflected in accumulated other comprehensive loss for the quarters ended April 4, 2022 and March 29, 2021:

[0001564590-22-019520:notes:76]
|  |  | Quarter Ended |
|  |  | April 4, |  |  | March 29, |  |  |
|  |  | 2022 |  |  | 2021 |  |  |
|  |  | (In thousands) |
| Beginning balance, net of tax |  | $ | (3,223 | ) |  | $ | (11,231 | ) |  |
| Changes in fair value gain (loss), net of tax |  |  | 153 |  |  |  | (263 | ) |  |
| Reclassification to earnings |  |  | 2,034 |  |  |  | 2,052 |  |  |
| Ending balance, net of tax |  | $ | (1,036 | ) |  | $ | (9,442 | ) |  |

[0001564590-22-019520:notes:77]
Based on the current yield curve, the Company expects that losses of approximately $1,087 of the accumulated other comprehensive loss will be reclassified into the statement of operations, net of tax, in the next quarter since the interest rate swap arrangement is expiring on June 1, 2022.


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0001564590-22-019520:notes:78]
[same as prior period, unchanged from 0001564590-21-053547:notes:101]

[0001564590-22-019520:notes:79]
The following provides a summary of the components of accumulated other comprehensive loss, net of tax, as of April 4, 2022 and January 3, 2022:

[0001564590-22-019520:notes:80]
|  |  | Foreign Currency Translation |  |  | Pension Obligation |  |  | (Losses) Gains on Cash Flow Hedges |  |  | Total |  |
|  |  | (In thousands) |  |
| Ending balance as of January 3, 2022 |  | $ | (23,899 | ) |  | $ | (133 | ) |  | $ | (3,223 | ) |  | $ | (27,255 | ) |
| Other comprehensive (loss) income before reclassifications |  |  | (36 | ) |  |  | — |  |  |  | 153 |  |  |  | 117 |  |
| Amounts reclassified from accumulated other comprehensive loss |  |  | — |  |  |  | — |  |  |  | 2,034 |  |  |  | 2,034 |  |
| Other comprehensive (loss) income |  |  | (36 | ) |  |  | — |  |  |  | 2,187 |  |  |  | 2,151 |  |
| Ending balance as of April 4, 2022 |  | $ | (23,935 | ) |  | $ | (133 | ) |  | $ | (1,036 | ) |  | $ | (25,104 | ) |


## us-gaap:ConcentrationRiskDisclosureTextBlock

[0001564590-22-019520:notes:81]
[same as prior period, unchanged from 0001564590-21-053547:notes:104]

[0001564590-22-019520:notes:82]
[same as prior period, unchanged from 0001564590-21-053547:notes:105]

[0001564590-22-019520:notes:83]
[same as prior period, unchanged from 0001564590-21-053547:notes:106]

[0001564590-22-019520:notes:84]
For the quarters ended April 4, 2022 and March 29, 2021, one customer accounted for approximately 10% and 13% of the Company’s net sales, respectively.


## us-gaap:FairValueDisclosuresTextBlock

[0001564590-22-019520:notes:85]
[same as prior period, unchanged from 0001564590-21-053547:notes:108]

[0001564590-22-019520:notes:86]
[same as prior period, unchanged from 0001564590-21-053547:notes:109]

[0001564590-22-019520:notes:87]
The carrying amount and estimated fair value of the Company’s financial instruments as of April 4, 2022 and January 3, 2022 were as follows:

[0001564590-22-019520:notes:88]
|  |  | As of |  |  | As of |  |
|  |  | April 4, 2022 |  |  | January 3, 2022 |  |
|  |  | Carrying Amount |  |  | Fair Value |  |  | Carrying Amount |  |  | Fair Value |  |
|  |  | (In thousands) |  |
| Derivative assets, current |  | $ | 1,699 |  |  | $ | 1,699 |  |  | $ | 297 |  |  | $ | 297 |  |
| Derivative liabilities, current |  |  | 1,437 |  |  |  | 1,437 |  |  |  | 4,295 |  |  |  | 4,295 |  |
| Senior Notes due March 2029 |  |  | 494,720 |  |  |  | 465,035 |  |  |  | 494,556 |  |  |  | 498,200 |  |
| Term Loan due September 2024 |  |  | 403,490 |  |  |  | 404,357 |  |  |  | 403,262 |  |  |  | 406,135 |  |
| ABL Revolving Loans |  |  | 30,000 |  |  |  | 30,000 |  |  |  | 30,000 |  |  |  | 30,000 |  |

[0001564590-22-019520:notes:89]
[same as prior period, unchanged from 0001564590-21-053547:notes:112]

[0001564590-22-019520:notes:90]
The fair value of the long-term debt was estimated based on quoted market prices or discounting the debt over its life using current market rates for similar debt as of April 4, 2022 and January 3, 2022, which are considered Level 2 inputs.

[0001564590-22-019520:notes:91]
As of April 4, 2022 and January 3, 2022, the Company’s other financial instruments included cash and cash equivalents, accounts receivable, contract assets, accounts payable, and contract liabilities. Due to short-term maturities, the carrying amount of these instruments approximates fair value. The Company’s cash and cash equivalents as of April 4, 2022 consisted of $332,757 held in the U.S., with the remaining $186,322 held by foreign subsidiaries.

[0001564590-22-019520:notes:92]
[same as prior period, unchanged from 0001564590-21-053547:notes:115]


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001564590-22-019520:notes:93]
(14) Commitments and Contingencies

[0001564590-22-019520:notes:94]
Legal Matters

[0001564590-22-019520:notes:95]
The Company is subject to various legal matters, which it considers normal for its business activities. While the Company currently believes that the amount of any reasonably possible loss for known matters would not be material to the Company’s financial condition, the outcome of these actions is inherently difficult to predict. In the event of an adverse outcome, the ultimate potential loss could have a material adverse effect on the Company’s financial condition or results of operations in a particular period. The Company has accrued amounts for its loss contingencies which are probable and estimable as of April 4, 2022 and January 3, 2022. However, these amounts are not material to the consolidated condensed financial statements of the Company.


## us-gaap:EarningsPerShareTextBlock

[0001564590-22-019520:notes:96]
(15) Earnings (Loss) Per Share

[0001564590-22-019520:notes:97]
The following is a reconciliation of the numerator and denominator used to calculate basic earnings (loss) per share and diluted earnings (loss) per share for the quarters ended April 4, 2022 and March 29, 2021:

[0001564590-22-019520:notes:98]
|  |  | Quarter Ended |  |
|  |  | April 4, 2022 |  |  | March 29, 2021 |  |
|  |  | (In thousands, except per share amounts) |  |
| Net income (loss) |  | $ | 17,246 |  |  | $ | (3,192 | ) |
| Basic weighted average shares |  |  | 102,613 |  |  |  | 106,825 |  |
| Dilutive effect of performance-based restricted stock units, restricted stock units and stock options |  |  | 1,685 |  |  |  | — |  |
| Dilutive effect of outstanding warrants |  |  | 6 |  |  |  | — |  |
| Diluted shares |  |  | 104,304 |  |  |  | 106,825 |  |
| Earnings (loss) per share: |  |  |  |  |  |  |  |  |
| Basic |  | $ | 0.17 |  |  | $ | (0.03 | ) |
| Diluted |  | $ | 0.17 |  |  | $ | (0.03 | ) |

[0001564590-22-019520:notes:99]
Performance-based restricted stock units (PRUs), restricted stock units (RSUs), and stock options to purchase 975 shares of common stock for the quarter ended April 4, 2022 were not included in the computation of diluted earnings per share. The PRUs were not included in the computation of diluted earnings per share because the performance conditions had not been met at April 4, 2022, and for RSUs and stock options, the options’ exercise prices or the total expected proceeds under the treasury stock method was greater than the average market price of common stock during the applicable quarter and, as a result, the impact would be anti-dilutive.

[0001564590-22-019520:notes:100]
For the quarter ended March 29, 2021, potential shares of common stock, consisting of stock options to purchase approximately 60 shares of common stock at exercise prices ranging from $11.83 to $16.60 per share, 2,897 RSUs, and 289 PRUs were not included in the computation of diluted earnings per share because the Company incurred a net loss during that quarter and as a result, the impact would be anti-dilutive.

[0001564590-22-019520:notes:101]
Outstanding warrants for the quarter ended March 29, 2021 to purchase common stock were not included in the computation of dilutive earnings per share because the strike price of the warrants to purchase the Company’s common stock was greater than the average market price of common shares during the applicable quarter and because the Company incurred a net loss during that quarter, and therefore, the effect would be anti-dilutive.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001564590-22-019520:notes:102]
[same as prior period, unchanged from 0001564590-21-053547:notes:125]

[0001564590-22-019520:notes:103]
[same as prior period, unchanged from 0001564590-21-053547:notes:126]

[0001564590-22-019520:notes:104]
|  |  | Quarter Ended |
|  |  | April 4, |  |  | March 29, |  |  |
|  |  | 2022 |  |  | 2021 |  |  |
|  |  | (In thousands) |
| Cost of goods sold |  | $ | 1,276 |  |  | $ | 1,165 |  |  |
| Selling and marketing |  |  | 650 |  |  |  | 646 |  |  |
| General and administrative |  |  | 2,053 |  |  |  | 2,355 |  |  |
| Research and development |  |  | 255 |  |  |  | 43 |  |  |
| Stock-based compensation expense recognized |  | $ | 4,234 |  |  | $ | 4,209 |  |  |

[0001564590-22-019520:notes:105]
[same as prior period, unchanged from 0001564590-21-053547:notes:128]

[0001564590-22-019520:notes:106]
The following is a summary of total unrecognized compensation costs as of April 4, 2022:

[0001564590-22-019520:notes:107]
|  |  | Unrecognized Stock-Based Compensation Cost |  |  | Remaining Weighted Average Recognition Period |  |
|  |  | (In thousands) |  |  | (In years) |  |
| RSU awards |  | $ | 20,594 |  |  |  | 1.4 |  |
| PRU awards |  |  | 1,092 |  |  |  | 0.8 |  |
| Stock options |  |  | 25 |  |  |  | 0.5 |  |
|  |  | $ | 21,711 |  |  |  |  |  |


## us-gaap:SegmentReportingDisclosureTextBlock

[0001564590-22-019520:notes:108]
[same as prior period, unchanged from 0001564590-21-053547:notes:131]

[0001564590-22-019520:notes:109]
The reportable segments shown below are the Company’s segments for which separate financial information is available and upon which operating results are evaluated by the chief operating decision maker to assess performance and to allocate resources.

[0001564590-22-019520:notes:110]
[same as prior period, unchanged from 0001564590-21-053547:notes:133]

[0001564590-22-019520:notes:111]
|  |  | Quarter Ended |  |
|  |  | April 4, 2022 |  |  | March 29, 2021 |  |
|  |  | (In thousands) |  |
| Net Sales: |  |  |  |  |  |  |  |  |
| PCB |  | $ | 566,070 |  |  | $ | 510,486 |  |
| RF&S Components |  |  | 15,190 |  |  |  | 12,690 |  |
| Other (1) |  |  | — |  |  |  | 3,256 |  |
| Total net sales |  | $ | 581,260 |  |  | $ | 526,432 |  |
| Operating Segment Income (Loss): |  |  |  |  |  |  |  |  |
| PCB |  | $ | 56,540 |  |  | $ | 57,232 |  |
| RF&S Components |  |  | 5,750 |  |  |  | 3,862 |  |
| Corporate and Other (1) |  |  | (26,764 | ) |  |  | (30,389 | ) |
| Total operating segment income |  |  | 35,526 |  |  |  | 30,705 |  |
| Amortization of definite-lived intangibles (2) |  |  | (9,658 | ) |  |  | (10,905 | ) |
| Total operating income |  |  | 25,868 |  |  |  | 19,800 |  |
| Total other expense |  |  | (9,391 | ) |  |  | (24,099 | ) |
| Income (loss) before income taxes |  | $ | 16,477 |  |  | $ | (4,299 | ) |

[0001564590-22-019520:notes:112]
|  |  | As of |  |
|  |  | April 4, 2022 |  |  | January 3, 2022 |  |
|  |  | (In thousands) |  |
| Segment Assets: |  |  |  |  |  |  |  |  |
| PCB |  | $ | 1,634,299 |  |  | $ | 1,655,401 |  |
| RF&S Components |  |  | 213,139 |  |  |  | 216,737 |  |
| Corporate and Other (1) |  |  | 1,196,710 |  |  |  | 1,153,409 |  |
| Total assets |  | $ | 3,044,148 |  |  | $ | 3,025,547 |  |

[0001564590-22-019520:notes:113]
| (1) | Other represents results from the now closed SH E-MS and SZ facilities. |

[0001564590-22-019520:notes:114]
| (2) | Amortization of definite-lived intangibles primarily relates to the PCB and RF&S Components reportable segments. For both the quarters ended April 4, 2022 and March 29, 2021, $1,384 of amortization expense is included in cost of goods sold. |

[0001564590-22-019520:notes:115]
[same as prior period, unchanged from 0001564590-21-053547:notes:137]

[0001564590-22-019520:notes:116]
[same as prior period, unchanged from 0001564590-21-053547:notes:138]

[0001564590-22-019520:notes:117]
|  |  | Quarter Ended |  |
|  |  | April 4, 2022 |  |  | March 29, 2021 |  |
|  |  | (In thousands) |  |
| Net Sales: |  |  |  |  |  |  |  |  |
| United States |  | $ | 264,401 |  |  | $ | 268,467 |  |
| China |  |  | 77,205 |  |  |  | 81,709 |  |
| Other |  |  | 239,654 |  |  |  | 176,256 |  |
| Total net sales |  | $ | 581,260 |  |  | $ | 526,432 |  |

[0001564590-22-019520:notes:118]
[same as prior period, unchanged from 0001564590-21-053547:notes:140]


## us-gaap:SubsequentEventsTextBlock

[0001564590-22-019520:notes:119]
(18) Subsequent Events

[0001564590-22-019520:notes:120]
On April 18, 2022, the Company entered into a definitive share purchase agreement to purchase all of the issued and outstanding capital stock of Telephonics Corporation and ISC Farmingdale Corp. for an aggregate purchase price of $330,000 in cash, subject to customary working capital and certain other adjustments. The transaction is expected to close in the second quarter of 2022.
