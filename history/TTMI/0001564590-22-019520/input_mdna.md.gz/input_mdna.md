# TTMI MD&A — 0001564590-22-019520


## mdna

[0001564590-22-019520:mdna:1]
[same as prior period, unchanged from 0001564590-21-053547:mdna:1]

[0001564590-22-019520:mdna:2]
[same as prior period, unchanged from 0001564590-21-053547:mdna:2]

[0001564590-22-019520:mdna:3]
We are a leading global printed circuit board (PCB) manufacturer, focusing on quick-turn and volume production of technologically advanced PCBs and backplane assemblies as well as a global designer and manufacturer of high-frequency radio frequency (RF) and microwave/microelectronics components and assemblies. We focus on providing time-to-market and volume production of advanced technology products and offer a one-stop design, engineering, and manufacturing solution to our customers. This one-stop design, engineering, and manufacturing solution allows us to align technology development with the diverse needs of our customers and to enable them to reduce the time required to develop new products and bring them to market. We serve a diversified customer base consisting of approximately 1,000 customers in various markets throughout the world, including aerospace and defense, data center computing, automotive components, medical, industrial and instrumentation related products, as well as networking/communications infrastructure products. Our customers include both original equipment manufacturers (OEMs) and electronic manufacturing services (EMS) providers.

[0001564590-22-019520:mdna:4]
[same as prior period, unchanged from 0001564590-21-053547:mdna:4]

[0001564590-22-019520:mdna:5]
The coronavirus (COVID-19) pandemic initially caused business disruption to our operations in China in January 2020. By March 2020, the situation escalated as the scope of the COVID-19 pandemic worsened outside of the Asia-Pacific region, with Europe and North America being affected by the pandemic. With the development and deployment of vaccines, certain of the adverse societal and economic effects of the pandemic have declined. However, as new variants of the virus emerge and evolve, we could see a rebound in the severity of the adverse effects of the pandemic. As a result, we expect continued impacts on our production, as well as ongoing significant uncertainty relating to the actual and potential impacts of the COVID-19 pandemic, and we cannot reasonably estimate its duration or severity. For example, during the first quarter, an outbreak in Mainland China forced temporary lockdown orders in several cities in which we operate. Further, in North America, there was a surge in cases resulting from the Omicron variant from December 2021 through January 2022 which resulted in production inefficiencies caused by a combination of quarantine impacts and direct labor shortages on our overall production. The COVID-19 pandemic has created and continues to create various global macroeconomic, customer demand, operational and supply chain risks and has contributed to high inflation, each of which could have a material and adverse impact on our business going forward. See Item 1A, Risk Factors, of Part II below for further information related to the COVID-19 pandemic.

[0001564590-22-019520:mdna:6]
We have taken active measures to seek to protect our employees, suppliers, and customers by implementing extensive pandemic related protocols, establishing situational leadership teams in Asia-Pacific and North America along with regularly scheduled executive reviews and planning calls, implementing global travel restrictions, and conforming to the guidance and direction of local governments and global health organizations. We are monitoring the impacts the COVID-19 pandemic has had, and continues to have, on our supply chain and are collaborating with our third-party partners with the goal of mitigating, to the extent reasonably practicable, significant delays in delivery of our products.

[0001564590-22-019520:mdna:7]
We continue to experience supply chain constraints and inflationary pressures. We have been actively taking measures intended to manage both supply chain constraints and higher raw materials costs, including, without limitation, through such measures as supplier diversification, ongoing operational efficiency efforts and quotation adjustments to mitigate the impact on our business.

[0001564590-22-019520:mdna:8]
[same as prior period, unchanged from 0001564590-21-053547:mdna:8]

[0001564590-22-019520:mdna:9]
On April 18, 2022, we entered into a definitive share purchase agreement to purchase all of the issued and outstanding capital stock of Telephonics Corporation and ISC Farmingdale Corp. for an aggregate purchase price of $330.0 million in cash, subject to customary working capital and certain other adjustments. Consummation of the transaction is subject to certain closing conditions, and the share purchase agreement may be terminated in certain circumstances.

[0001564590-22-019520:mdna:10]
20

[0001564590-22-019520:mdna:11]
On March 1, 2022, we announced that we will open a new, state of the art, highly automated PCB manufacturing facility in Penang, Malaysia. We expect construction to begin later in 2022 with equipment installation in 2023. We expect that the total capital spending for this facility will be $130.0 million and this investment will be spread from 2022 through 2025.

[0001564590-22-019520:mdna:12]
[same as prior period, unchanged from 0001564590-21-053547:mdna:9]

[0001564590-22-019520:mdna:13]
While our customers include both OEMs and EMS providers, we measure customers based on OEM companies, as they are the ultimate end customers. Sales to our ten largest customers collectively accounted for 45% of our net sales for both the quarters ended April 4, 2022 and March 29, 2021. We sell to OEMs both directly and indirectly through EMS providers.

[0001564590-22-019520:mdna:14]
[same as prior period, unchanged from 0001564590-21-053547:mdna:13]

[0001564590-22-019520:mdna:15]
|  |  | Quarter Ended |  |  |
| End Markets (1) |  | April 4, 2022 |  |  |  | March 29, 2021 |  |  |
| Aerospace and Defense |  |  | 30 |  | % |  |  | 35 |  | % |
| Automotive |  |  | 20 |  |  |  |  | 18 |  |  |
| Data Center Computing |  |  | 16 |  |  |  |  | 14 |  |  |
| Medical/Industrial/Instrumentation |  |  | 21 |  |  |  |  | 17 |  |  |
| Networking/Communications |  |  | 13 |  |  |  |  | 15 |  |  |
| Other (2) |  |  | — |  |  |  |  | 1 |  |  |
| Total |  |  | 100 |  | % |  |  | 100 |  | % |

[0001564590-22-019520:mdna:16]
[same as prior period, unchanged from 0001564590-21-053547:mdna:15]

[0001564590-22-019520:mdna:17]
| (2) | Other end market reflects direct sales to EMS and distributor customers. |

[0001564590-22-019520:mdna:18]
We derive revenues primarily from the sale of PCBs, custom electronic assemblies using customer-supplied engineering and design plans as well as our long-term contracts related to the design and manufacture of RF and microwave/microelectronics components, assemblies, and subsystems. Orders for products generally correspond to the production schedules of our customers and are supported with firm purchase orders. Our customers have continuous control of the work in progress and finished goods throughout the PCB and custom electronic assemblies manufacturing process, as these are built to customer specifications with no alternative use, and there is an enforceable right of payment for work performed to date. As a result, we recognize revenue progressively over time based on the extent of progress towards completion of the performance obligation. We recognize revenue based on a cost method as it best depicts the transfer of control to the customer which takes place as we incur costs. Revenues are recorded proportionally as costs are incurred.

[0001564590-22-019520:mdna:19]
[same as prior period, unchanged from 0001564590-21-053547:mdna:19]

[0001564590-22-019520:mdna:20]
Net sales consist of gross sales less an allowance for returns, which typically have been approximately 2% of gross sales. We provide our customers a limited right of return for defective PCBs including components, subsystems, and assemblies. We record an estimate for sales returns and allowances at the time of sale based on historical results and anticipated returns.

[0001564590-22-019520:mdna:21]
[same as prior period, unchanged from 0001564590-21-053547:mdna:21]

[0001564590-22-019520:mdna:22]
[same as prior period, unchanged from 0001564590-21-053547:mdna:22]

[0001564590-22-019520:mdna:23]
General and administrative costs primarily include the salaries for executive, finance, accounting, information technology, and human resources personnel, as well as expenses for accounting and legal assistance, incentive compensation expense, and gains or losses on the sale or disposal of property, plant, and equipment.

[0001564590-22-019520:mdna:24]
[same as prior period, unchanged from 0001564590-21-053547:mdna:24]

[0001564590-22-019520:mdna:25]
21

[0001564590-22-019520:mdna:26]
[same as prior period, unchanged from 0001564590-21-053547:mdna:25]

[0001564590-22-019520:mdna:27]
[same as prior period, unchanged from 0001564590-21-053547:mdna:26]

[0001564590-22-019520:mdna:28]
See Item 7, Management’s Discussion and Analysis of Financial Condition and Results of Operations, in our Annual Report on Form 10-K for the fiscal year ended January 3, 2022 for further discussion of critical accounting policies and estimates. There were no material changes to our critical accounting policies and estimates since January 3, 2022.

[0001564590-22-019520:mdna:29]
[same as prior period, unchanged from 0001564590-21-053547:mdna:28]

[0001564590-22-019520:mdna:30]
[same as prior period, unchanged from 0001564590-21-053547:mdna:29]

[0001564590-22-019520:mdna:31]
|  |  | Quarter Ended |
|  |  | April 4, 2022 |  |  |  | March 29, 2021 |  |  |
| Net sales |  |  | 100.0 |  | % |  |  | 100.0 |  | % |
| Cost of goods sold |  |  | 84.4 |  |  |  |  | 84.5 |  |  |
| Gross profit |  |  | 15.6 |  |  |  |  | 15.5 |  |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |
| Selling and marketing |  |  | 3.1 |  |  |  |  | 3.1 |  |  |
| General and administrative |  |  | 5.6 |  |  |  |  | 6.0 |  |  |
| Research and development |  |  | 1.0 |  |  |  |  | 0.8 |  |  |
| Amortization of definite-lived intangibles |  |  | 1.4 |  |  |  |  | 1.8 |  |  |
| Total operating expenses |  |  | 11.1 |  |  |  |  | 11.7 |  |  |
| Operating income |  |  | 4.5 |  |  |  |  | 3.8 |  |  |
| Other (expense) income: |  |  |  |  |  |  |  |  |  |  |
| Interest expense |  |  | (2.0 | ) |  |  |  | (2.2 | ) |  |
| Loss on extinguishment of debt |  |  | — |  |  |  |  | (2.9 | ) |  |
| Other, net |  |  | 0.3 |  |  |  |  | 0.5 |  |  |
| Total other expense, net |  |  | (1.7 | ) |  |  |  | (4.6 | ) |  |
| Income (loss) before income taxes |  |  | 2.8 |  |  |  |  | (0.8 | ) |  |
| Income tax benefit |  |  | 0.2 |  |  |  |  | 0.2 |  |  |
| Net income (loss) |  |  | 3.0 |  | % |  |  | (0.6 | ) | % |

[0001564590-22-019520:mdna:32]
[same as prior period, unchanged from 0001564590-21-053547:mdna:32]

[0001564590-22-019520:mdna:33]
Total net sales increased $54.8 million, or 10.4%, to $581.3 million for the first quarter of 2022 from $526.4 million for the first quarter of 2021. The primary driver for the increase in total net sales was an increase in net sales for the PCB reportable segment of $55.6 million, or 10.8%, to $566.1 million for the first quarter of 2022 from $510.5 million for the first quarter of 2021, which was primarily due to higher demand in most of our commercial end markets which more than offset a decline in our Aerospace and Defense end market due to commercial aerospace softness and production challenges in North America. The increase in PCB net sales also benefitted from a 7.6% increase in the volume of PCB shipments and a 3.9% increase in the average price per square foot as compared to the first quarter of 2021. Another contributing factor to the increase in total net sales was an increase in net sales for the RF&S Components reportable segment of $2.5 million, or 19.7%, to $15.2 million for the first quarter of 2022 from $12.7 million for the first quarter of 2021, which was primarily due to higher demand in our Networking/Communications end market. Partially offsetting the PCB and RF&S Components increases was a $3.3 million reduction in net sales due to the closure of our two assembly plants.

[0001564590-22-019520:mdna:34]
[same as prior period, unchanged from 0001564590-21-053547:mdna:35]

[0001564590-22-019520:mdna:35]
Overall gross margin increased to 15.6% for the first quarter of 2022 from 15.5% for the first quarter of 2021. Gross margin for the PCB reportable segment decreased to 14.7% for the first quarter of 2022 from 15.7% for the first quarter of 2021. This decline was primarily due to labor and production challenges in North America partially offset by revenue growth in our commercial businesses. During the quarter, we did experience significant material cost increases, but we were able to mitigate the profit impact of those increases through customer price increases and manufacturing efficiencies. Gross margin for the RF&S Components reportable segment increased to 57.0% for the first quarter of 2022 from 47.5% for the first quarter of 2021, primarily due to higher sales.

[0001564590-22-019520:mdna:36]
Capacity utilization is a key driver for us, which is measured by the actual production as a percentage of maximum capacity. This measure is particularly important in our high-volume facilities in Asia, as a significant portion of our operating costs are fixed in

[0001564590-22-019520:mdna:37]
nature. Capacity utilization for the first quarter of 2022 in our Asia and North America PCB facilities was 85% and 46%, respectively, compared to 80% and 55%, respectively, for the first quarter of 2021. The increase in capacity utilization in our Asia PCB facilities was due to an increase in production resulting from increased sales in our commercial end markets. The decrease in our capacity utilization in our North America PCB facilities was primarily due to increased capacity resulting from equipment expansion and the challenges posed by COVID-19 absences and direct labor shortages.

[0001564590-22-019520:mdna:38]
Selling and Marketing Expenses

[0001564590-22-019520:mdna:39]
Selling and marketing expense increased $2.0 million, to $18.3 million for the first quarter of 2022 from $16.3 million for the first quarter of 2021. As a percentage of net sales, selling and marketing expense was 3.1% for both the first quarter of 2022 and 2021. The increase in selling and marketing expenses was primarily due to an increase in commission expense and labor costs.

[0001564590-22-019520:mdna:40]
General and Administrative Expenses

[0001564590-22-019520:mdna:41]
General and administrative expense increased $1.4 million to $33.0 million, or 5.6% of net sales, for the first quarter of 2022 from $31.5 million, or 6.0% of net sales, for the first quarter of 2021. This increase was primarily due to an increase in labor costs, bad debt, acquisition/integration costs, and other general and administrative spending. These increases were partially offset by the decrease in restructuring charges of $3.0 million associated with the restructuring of our E-M Solutions business unit during the first quarter of 2021.

[0001564590-22-019520:mdna:42]
[same as prior period, unchanged from 0001564590-21-053547:mdna:45]

[0001564590-22-019520:mdna:43]
Other expense, net decreased $14.7 million to $9.4 million for the first quarter of 2022 from $24.1 million for the first quarter of 2021. This decrease was primarily the result of the absence of $15.2 million loss on extinguishment of debt partially offset by a decrease in other income of $0.5 million for the first quarter of 2022 due to lower government subsidies.

[0001564590-22-019520:mdna:44]
[same as prior period, unchanged from 0001564590-21-053547:mdna:48]

[0001564590-22-019520:mdna:45]
Income tax benefit decreased by $0.3 million to $0.8 million of tax benefit for the first quarter of 2022 from $1.1 million of tax benefit for the first quarter of 2021. The decrease in income tax benefit for the first quarter of 2022 was primarily due to an increase in pre-tax income partially offset by the tax benefit resulting from the approval of the Company’s renewal application for High and New Enterprise status for two of the Company’s manufacturing subsidiaries in China.

[0001564590-22-019520:mdna:46]
Our effective tax rate is primarily impacted by tax rates in China and Hong Kong, the U.S. federal income tax rate, apportioned state income tax rates, the generation of credits and deductions available to the Company as well as changes in valuation allowances and certain non-deductible items. We had a net deferred income tax asset of approximately $10.2 million and $16.0 million as of April 4, 2022 and March 29, 2021, respectively.

[0001564590-22-019520:mdna:47]
[same as prior period, unchanged from 0001564590-21-053547:mdna:54]

[0001564590-22-019520:mdna:48]
Our principal sources of liquidity have been cash provided by operations, the issuance of debt, and borrowings under our Revolving Credit Facility. Our principal uses of cash have been to finance capital expenditures, finance acquisitions, fund working capital requirements, to repay debt obligations, and to repurchase common stock. We anticipate that financing capital expenditures, financing acquisitions including our potential acquisition of Telephonics Corporation and ISC Farmingdale Corp., which is expected to close in the second quarter of 2022, funding working capital requirements, and servicing debt will be the principal demands on our cash in the future.

[0001564590-22-019520:mdna:49]
Cash flow provided by operating activities during the first quarter of 2022 was $36.0 million as compared to cash flow provided by operating activities of $41.1 million in the same period in 2021. The decrease in cash flow was primarily due to increased investment in working capital.

[0001564590-22-019520:mdna:50]
Net cash used in investing activities was approximately $23.4 million for the first quarter of 2022, comprised of purchases of property, plant and equipment and other assets. Net cash used in investing activities was approximately $21.0 million for the first quarter of 2021, reflecting $21.8 million for purchases of property, plant and equipment and other assets less $0.8 million for proceeds from sale of property, plant and equipment and other assets.

[0001564590-22-019520:mdna:51]
Net cash used in financing activities during the first quarter of 2022 was $31.1 million, primarily reflecting repurchases of common stock of $30.2 million and cash used to settle warrants of $0.9 million. Net cash provided by financing activities during the first quarter of 2021 was $68.1 million, primarily reflecting proceeds from long-term debt borrowing of $500.0 million, less the repayment of long-term debt borrowings of $425.8 million and payment of debt issuance costs of $4.8 million.

[0001564590-22-019520:mdna:52]
As of April 4, 2022, we had cash and cash equivalents of approximately $519.1 million, of which approximately $186.3 million was held by our foreign subsidiaries, primarily in China. Should we choose to remit cash to the United States from our foreign locations, we may incur tax obligations which would reduce the amount of cash ultimately available to the United States. However, we believe there would be no material tax consequences not previously accrued for the repatriation of this cash.

[0001564590-22-019520:mdna:53]
Our total 2022 capital expenditures are expected to be in the range of $110.0 million to $130.0 million.

[0001564590-22-019520:mdna:54]
Share Repurchases

[0001564590-22-019520:mdna:55]
On February 3, 2021, our board of directors authorized a share repurchase program allowing us to repurchase up to $100.0 million of our common stock. During the first quarter of 2022, we repurchased a total of 2.4 million shares of our common stock for $30.2 million (including commissions). Subsequent to April 4, 2022, we repurchased a total of 0.4 million shares of our common stock for $5.2 million (including commissions) and there are no amounts available for repurchase as of May 4, 2022. We repurchased a total of 7.5 million shares of our common stock for $100.0 million under the share repurchase program.

[0001564590-22-019520:mdna:56]
[same as prior period, unchanged from 0001564590-21-053547:mdna:61]

[0001564590-22-019520:mdna:57]
As of April 4, 2022, we had $928.2 million of outstanding debt, net of discount and debt issuance costs, composed of $494.7 million of Senior Notes due March 2029, $403.5 million of a Term Loan due September 2024, and $30.0 million under the Asia Asset-Based Lending Credit Agreement (Asia ABL).

[0001564590-22-019520:mdna:58]
Pursuant to the terms of the Term Loan Facility and Senior Notes due 2029, we are subject to certain affirmative and negative covenants, including limitations on indebtedness, corporate transactions, investments, dispositions, and share payments. Under the occurrence of certain events, under the U.S. Asset-Based Lending Credit Agreement (U.S. ABL) and Asia ABL (collectively, the ABL Revolving Loans), we are also subject to various financial covenants, including leverage and fixed charge coverage ratios. As of April 4, 2022, we were in compliance with the covenants under the Term Loan Facility, Senior Notes due 2029 and ABL Revolving Loans.

[0001564590-22-019520:mdna:59]
[same as prior period, unchanged from 0001564590-21-053547:mdna:64]

[0001564590-22-019520:mdna:60]
[same as prior period, unchanged from 0001564590-21-053547:mdna:65]

[0001564590-22-019520:mdna:61]
As part of our ongoing operations, we enter into contractual arrangements that obligate us to make future cash payments. These obligations impact our liquidity and capital resource needs. Our estimated future obligations consist of long-term debt obligations, interest on debt obligations, derivative liabilities, purchase obligations, and leases as of April 4, 2022. As of the date of this report, other than the share purchase agreement we entered into on April 18, 2022 to purchase all of the issued and outstanding capital stock of Telephonics Corporation and ISC Farmingdale Corp., there were no material changes outside the ordinary course of business since January 3, 2022 to our contractual obligations and commitments and the related cash requirements.

[0001564590-22-019520:mdna:62]
[same as prior period, unchanged from 0001564590-21-053547:mdna:72]

[0001564590-22-019520:mdna:63]
Historically, we experienced significant seasonality in revenues with a softer first half of the fiscal year and generally ramping volumes in the third quarter which usually peaked in the fourth quarter. After the divestiture of our former Mobility business unit in 2020, this pattern has changed. Barring end market demand changes, we now tend to experience modest seasonal softness in the first and third quarters due to holidays and vacation periods in China and North America, respectively, which limit production leading to stronger revenue levels in the second and fourth quarters.

[0001564590-22-019520:mdna:64]
Recently Issued Accounting Standards

[0001564590-22-019520:mdna:65]
[same as prior period, unchanged from 0001564590-21-053547:mdna:75]
