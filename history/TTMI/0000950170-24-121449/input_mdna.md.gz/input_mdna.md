# TTMI MD&A — 0000950170-24-121449


## mdna

[0000950170-24-121449:mdna:1]
[same as prior period, unchanged from 0000950170-24-091772:mdna:1]

[0000950170-24-121449:mdna:2]
[same as prior period, unchanged from 0000950170-24-091772:mdna:2]

[0000950170-24-121449:mdna:3]
[same as prior period, unchanged from 0000950170-24-091772:mdna:3]

[0000950170-24-121449:mdna:4]
[same as prior period, unchanged from 0000950170-24-091772:mdna:4]

[0000950170-24-121449:mdna:5]
We are a leading global manufacturer of technology solutions including mission systems, radio frequency (RF) components, RF microwave/microelectronic assemblies, and quick-turn and technologically advanced printed circuit boards (PCB). We focus on providing time-to-market and volume production of advanced technology products and offer a one-stop design, engineering, and manufacturing solution to our customers. This solution allows us to align technology development with the diverse needs of our customers and to enable them to reduce the time required to develop new products and bring them to market. We serve a diversified customer base consisting of approximately 1,500 customers in various markets throughout the world, including aerospace and defense, data center computing, automotive, medical, industrial and instrumentation, and networking. Our customers include original equipment manufacturers (OEMs), electronic manufacturing services (EMS) providers, original design manufacturers (ODMs), distributors, and government agencies (both domestic and allied foreign governments).

[0000950170-24-121449:mdna:6]
[same as prior period, unchanged from 0000950170-24-091772:mdna:6]

[0000950170-24-121449:mdna:7]
On August 1, 2024, we entered into a First Amendment to our Amended and Restated Term Loan Credit Agreement, dated as of May 30, 2023, by and among us, as Borrower, JPMorgan Chase Bank, N.A., as Administrative Agent, and the several lenders from time to time parties thereto, pursuant to which we closed our $346.5 million new senior secured term loan (Term Loan Facility) that bears interest at a floating rate of 1-month Chicago Mercantile Exchange (CME) Term Secured Overnight Financing Rate (SOFR) plus an applicable margin of 2.25%, 50 basis points lower than our previous term loan facility issued in May 2023. The Term Loan Facility amends and restates our previous term loan facility. The Term Loan Facility is issued at par, maintains the same maturity of May 30, 2030 as the previous term loan facility, and the majority is a cashless rollover from the previous term loan facility.

[0000950170-24-121449:mdna:8]
On November 1, 2023, we announced our selection of Syracuse, New York as the location for a new proposed advanced technology PCB manufacturing facility. We expect that the proposed facility will bring advanced technology capability for our domestic high-volume production of ultra-high-density interconnect (HDI) PCBs in support of national security requirements. We believe the planned investment aligns with New York State’s continuing focus on the region as a premier technology hub for U.S. electronics and the recent selection of Buffalo-Rochester-Syracuse (BRS) for the Federal Tech Hub designation. The project reflects our support for cultivating a stronger microelectronics ecosystem in New York and across the U.S. Aerospace and Defense industrial base. We have broken ground on the 24-acre property adjacent to our existing facility in Syracuse for the campus expansion and the site for the new facility, and we expect initial low rate production within 18 to 24 months. Phase one of the proposed project, including capital for campus-wide improvements is estimated to be $100.0 million to $130.0 million, and we expect to receive support in the form of grants, awards, and tax credits from both Federal and New York State sources of approximately $52.0 million in the aggregate, subject to certain requirements and contingencies, which would serve to offset the initial capital investment and lower operating expenses.

[0000950170-24-121449:mdna:9]
In addition, we also have plans to consolidate two smaller PCB facilities in Elizabeth City, North Carolina and Huntington, New York into existing facilities in order to improve efficiencies. This consolidation will occur over the next three quarters and is not expected to have a material impact on our results of operations, cash flows, or financial position.

[0000950170-24-121449:mdna:10]
19

[0000950170-24-121449:mdna:11]
[same as prior period, unchanged from 0000950170-24-091772:mdna:10]

[0000950170-24-121449:mdna:12]
While our customers include both OEMs and EMS providers, we measure customers based on OEM companies, as they are the ultimate end customers. Sales to our ten largest customers collectively accounted for 54% and 53% of our net sales for the quarter and three quarters ended September 30, 2024, respectively. Sales to our ten largest customers collectively accounted for 53% and 50% of our net sales for the quarter and three quarters ended October 2, 2023, respectively. We sell to OEMs both directly and indirectly through EMS providers.

[0000950170-24-121449:mdna:13]
[same as prior period, unchanged from 0000950170-24-091772:mdna:12]

[0000950170-24-121449:mdna:14]
|  |  | Quarter Ended |  | Three Quarters Ended |
|  |  | September 30, 2024 |  | October 2, 2023 |  | September 30, 2024 |  | October 2, 2023 |
| End Markets (1): |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Aerospace and Defense |  |  | 46 |  | % |  |  | 45 |  | % |  |  | 46 |  | % |  |  | 45 |  | % |
| Automotive |  |  | 14 |  |  |  |  | 15 |  |  |  |  | 14 |  |  |  |  | 16 |  |  |
| Data Center Computing |  |  | 19 |  |  |  |  | 17 |  |  |  |  | 20 |  |  |  |  | 13 |  |  |
| Medical/Industrial/Instrumentation |  |  | 14 |  |  |  |  | 16 |  |  |  |  | 14 |  |  |  |  | 17 |  |  |
| Networking |  |  | 7 |  |  |  |  | 7 |  |  |  |  | 6 |  |  |  |  | 9 |  |  |
| Total |  |  | 100 |  | % |  |  | 100 |  | % |  |  | 100 |  | % |  |  | 100 |  | % |

[0000950170-24-121449:mdna:15]
[same as prior period, unchanged from 0000950170-24-091772:mdna:14]

[0000950170-24-121449:mdna:16]
[same as prior period, unchanged from 0000950170-24-091772:mdna:15]

[0000950170-24-121449:mdna:17]
[same as prior period, unchanged from 0000950170-24-091772:mdna:16]

[0000950170-24-121449:mdna:18]
[same as prior period, unchanged from 0000950170-24-091772:mdna:17]

[0000950170-24-121449:mdna:19]
Cost of goods sold consists of materials, labor, outside services, and overhead expenses incurred in the manufacture and testing of our products. Shipping and handling fees and related freight costs and supplies associated with shipping products are also included as a component of cost of goods sold. Many factors affect our gross margin, including capacity utilization, product mix, production volume, supply chain costs, and yield.

[0000950170-24-121449:mdna:20]
[same as prior period, unchanged from 0000950170-24-091772:mdna:19]

[0000950170-24-121449:mdna:21]
[same as prior period, unchanged from 0000950170-24-091772:mdna:20]

[0000950170-24-121449:mdna:22]
[same as prior period, unchanged from 0000950170-24-091772:mdna:21]

[0000950170-24-121449:mdna:23]
[same as prior period, unchanged from 0000950170-24-091772:mdna:22]

[0000950170-24-121449:mdna:24]
[same as prior period, unchanged from 0000950170-24-091772:mdna:23]

[0000950170-24-121449:mdna:25]
20

[0000950170-24-121449:mdna:26]
[same as prior period, unchanged from 0000950170-24-091772:mdna:24]

[0000950170-24-121449:mdna:27]
[same as prior period, unchanged from 0000950170-24-091772:mdna:25]

[0000950170-24-121449:mdna:28]
[same as prior period, unchanged from 0000950170-24-091772:mdna:26]

[0000950170-24-121449:mdna:29]
|  |  | Quarter Ended |  | Three Quarters Ended |
|  |  | September 30, 2024 |  | October 2, 2023 |  | September 30, 2024 |  | October 2, 2023 |
| Net sales |  |  | 100.0 |  | % |  |  | 100.0 |  | % |  |  | 100.0 |  | % |  |  | 100.0 |  | % |
| Cost of goods sold |  |  | 78.9 |  |  |  |  | 80.2 |  |  |  |  | 80.4 |  |  |  |  | 82.1 |  |  |
| Gross profit |  |  | 21.1 |  |  |  |  | 19.8 |  |  |  |  | 19.6 |  |  |  |  | 17.9 |  |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Selling and marketing |  |  | 3.2 |  |  |  |  | 3.3 |  |  |  |  | 3.4 |  |  |  |  | 3.5 |  |  |
| General and administrative |  |  | 6.9 |  |  |  |  | 6.8 |  |  |  |  | 7.0 |  |  |  |  | 6.7 |  |  |
| Research and development |  |  | 1.3 |  |  |  |  | 1.1 |  |  |  |  | 1.3 |  |  |  |  | 1.2 |  |  |
| Amortization of definite-lived intangibles |  |  | 1.1 |  |  |  |  | 2.0 |  |  |  |  | 1.6 |  |  |  |  | 2.2 |  |  |
| Impairment of goodwill |  |  | — |  |  |  |  | 7.7 |  |  |  |  | — |  |  |  |  | 2.7 |  |  |
| Restructuring charges |  |  | 0.3 |  |  |  |  | 0.7 |  |  |  |  | 0.3 |  |  |  |  | 1.1 |  |  |
| Total operating expenses |  |  | 12.8 |  |  |  |  | 21.6 |  |  |  |  | 13.6 |  |  |  |  | 17.4 |  |  |
| Operating income (loss) |  |  | 8.3 |  |  |  |  | (1.8 | ) |  |  |  | 6.0 |  |  |  |  | 0.5 |  |  |
| Other (expense) income: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Interest expense |  |  | (1.9 | ) |  |  |  | (1.8 | ) |  |  |  | (2.0 | ) |  |  |  | (2.1 | ) |  |
| Loss on extinguishment of debt |  |  | — |  |  |  |  | — |  |  |  |  | — |  |  |  |  | (0.1 | ) |  |
| Gain on sale of subsidiary |  |  | — |  |  |  |  | — |  |  |  |  | — |  |  |  |  | 0.1 |  |  |
| Other, net |  |  | (2.3 | ) |  |  |  | 0.5 |  |  |  |  | (0.1 | ) |  |  |  | 0.6 |  |  |
| Total other expense, net |  |  | (4.2 | ) |  |  |  | (1.3 | ) |  |  |  | (2.1 | ) |  |  |  | (1.5 | ) |  |
| Income (loss) before income taxes |  |  | 4.1 |  |  |  |  | (3.1 | ) |  |  |  | 3.9 |  |  |  |  | (1.0 | ) |  |
| Income tax provision |  |  | (1.8 | ) |  |  |  | (3.5 | ) |  |  |  | (1.0 | ) |  |  |  | (1.1 | ) |  |
| Net income (loss) |  |  | 2.3 |  | % |  |  | (6.6 | ) | % |  |  | 2.9 |  | % |  |  | (2.1 | ) | % |

[0000950170-24-121449:mdna:30]
The following discussion and analysis is for the quarter and three quarters ended September 30, 2024, compared to the quarter and three quarters ended October 2, 2023, unless otherwise stated.

[0000950170-24-121449:mdna:31]
[same as prior period, unchanged from 0000950170-24-091772:mdna:29]

[0000950170-24-121449:mdna:32]
Total net sales increased $43.9 million, or 7.7%, to $616.5 million for the third quarter of 2024 from $572.6 million for the third quarter of 2023. The increase in total net sales primarily resulted from an increase in net sales for the PCB reportable segment of $43.1 million, or 7.6%, to $606.8 million for the third quarter of 2024 from $563.7 million for the third quarter of 2023. The primary driver of this increase was demand growth in our aerospace and defense and data center computing end markets as well as demand recovery in our networking end market, partially offset by demand weakness in our medical, industrial, and instrumentation and automotive end markets. Net sales for the RF&S Components reportable segment increased $0.8 million, or 9.4%, to $9.7 million for the third quarter of 2024 from $8.9 million for the third quarter of 2023, which was primarily due to higher demand in our networking end market.

[0000950170-24-121449:mdna:33]
Total net sales increased $128.3 million, or 7.7%, to $1,791.8 million for the first three quarters of 2024 from $1,663.5 million for the first three quarters of 2023. This increase in total net sales primarily resulted from an increase in net sales for the PCB reportable segment of $130.4 million, or 8.0%, to $1,764.7 million for the first three quarters of 2024 from $1,634.3 million for the first three quarters of 2023. The primary driver of this increase was demand growth in our data center computing and aerospace and defense end markets, partially offset by demand weakness in our automotive, networking, and medical, industrial, and instrumentation end markets, and by the sale of our Shanghai backplane business in the first quarter of 2023, which had the effect of reducing $8.4 million of net sales when comparing the first three quarters of 2024 to the first three quarters of 2023. Net sales for the RF&S Components reportable segment decreased $2.2 million, or 7.4%, to $27.0 million for the first three quarters of 2024 from $29.2 million for the first three quarters of 2023, which was primarily due to lower demand in our networking end market.

[0000950170-24-121449:mdna:34]
[same as prior period, unchanged from 0000950170-24-091772:mdna:32]

[0000950170-24-121449:mdna:35]
Overall gross margin increased to 21.1% for the third quarter of 2024 from 19.8% for the third quarter of 2023. The increase in overall gross margin was due to the increase in gross margin for the PCB reportable segment to 21.9% for the third quarter of 2024 from 21.1% for the third quarter of 2023. This increase was due to higher sales volume, particularly in the aerospace and defense and data center computing end markets, and improved operational execution. Gross margin for the RF&S Components reportable segment decreased to 50.4% for the third quarter of 2024 from 56.4% for the third quarter of 2023, primarily due to unfavorable product mix.

[0000950170-24-121449:mdna:36]
Overall gross margin increased to 19.6% for the first three quarters of 2024 from 17.9% for the first three quarters of 2023. The increase in overall gross margin was due to the increase in gross margin for the PCB reportable segment to 20.5% for the first three quarters of 2024 from 18.8% for the first three quarters of 2023. This increase was due to higher sales volume, particularly in the aerospace and defense and data center computing end markets, and improved operational execution. Gross margin for the RF&S Components reportable segment decreased to 49.3% for the first three quarters of 2024 from 54.3% for the first three quarters of 2023, primarily due to lower sales.

[0000950170-24-121449:mdna:37]
An important factor affecting gross margins is capacity utilization, which is measured by the actual production as a percentage of maximum capacity. This measure is particularly important in our high-volume PCB facilities in Asia, as a significant portion of our operating costs are fixed in nature. We believe that our North America utilization figures are not as meaningful as Asia because bottlenecks in these high mix low volume facilities tend to occur in areas outside of plating, which is the core process that we use for calculating utilization rates. Capacity utilization for the third quarter of 2024 in our Asia and North America PCB facilities was 60% and 35%, respectively, compared to 46% and 38%, respectively, for the third quarter of 2023. Capacity utilization for the first three quarters of 2024 in our Asia and North America PCB facilities was 59% and 37%, respectively, compared to 48% and 39%, respectively, for the first three quarters of 2023. The increase in capacity utilization in our Asia PCB facilities was due to continued strong data center demand.

[0000950170-24-121449:mdna:38]
[same as prior period, unchanged from 0000950170-24-091772:mdna:36]

[0000950170-24-121449:mdna:39]
Selling and marketing expenses increased $1.2 million to $20.0 million, or 3.2% of net sales, for the third quarter of 2024 from $18.8 million, or 3.3% of net sales, for the third quarter of 2023. The increase in selling and marketing expenses was primarily due to higher labor costs and stock-based compensation. Selling and marketing expenses as a percentage of net sales decreased as a result of higher net sales.

[0000950170-24-121449:mdna:40]
Selling and marketing expenses increased $1.8 million to $60.1 million, or 3.4% of net sales, for the first three quarters of 2024 from $58.2 million, or 3.5% of net sales, for the first three quarters of 2023. The increase in selling and marketing expenses was primarily due to higher labor costs, stock-based compensation, and travel costs, partially offset by a decrease in commissions. Selling and marketing expenses as a percentage of net sales decreased as a result of higher net sales.

[0000950170-24-121449:mdna:41]
[same as prior period, unchanged from 0000950170-24-091772:mdna:39]

[0000950170-24-121449:mdna:42]
General and administrative expenses increased $3.7 million to $42.6 million, or 6.9% of net sales, for the third quarter of 2024 from $38.9 million, or 6.8% of net sales, for the third quarter of 2023. The increase in general and administrative expenses was primarily due to increases in consulting expenses, labor costs, and stock-based compensation, partially offset by decreases in spending on supplies.

[0000950170-24-121449:mdna:43]
General and administrative expenses increased $13.0 million to $124.8 million, or 7.0% of net sales, for the first three quarters of 2024 from $111.8 million, or 6.7% of net sales, for the first three quarters of 2023. The increase in general and administrative expenses was primarily due to increases in consulting and legal expenses, labor costs, stock-based compensation, bad debt, incentive compensation, and the write down of our Hong Kong building of $6.1 million, partially offset by gains on the sale of assets primarily related to the sale of two buildings vacated by the closure of our Anaheim and Santa Clara plants of $14.4 million and decreases in spending on supplies.

[0000950170-24-121449:mdna:44]
[same as prior period, unchanged from 0000950170-24-091772:mdna:42]

[0000950170-24-121449:mdna:45]
Research and development expenses increased $1.9 million to $8.1 million, or 1.3% of net sales, for the third quarter of 2024 from $6.2 million, or 1.1% of net sales, for the third quarter of 2023. The increase in research and development expenses was primarily due to increases in labor costs and research and development projects.

[0000950170-24-121449:mdna:46]
Research and development expenses increased $4.2 million to $23.9 million, or 1.3% of net sales, for the first three quarters of 2024 from $19.7 million, or 1.2% of net sales, for the first three quarters of 2023. The increase in research and development expenses was primarily due to increases in labor costs and research and development projects.

[0000950170-24-121449:mdna:47]
[same as prior period, unchanged from 0000950170-24-091772:mdna:45]

[0000950170-24-121449:mdna:48]
Total other expense, net increased $18.9 million to $25.9 million for the third quarter of 2024 from $7.1 million for the third quarter of 2023. During the third quarter of 2024, there was a $17.8 million foreign exchange loss, compared to a $0.9 million foreign exchange gain in the third quarter of 2023. We utilize the Chinese Renminbi (RMB) and Malaysian Ringgit (MYR) at our China and Malaysia facilities, respectively, for employee-related and other costs of running our operations in foreign countries. However, the current year impact was primarily driven by $14.3 million of unrealized foreign exchange losses from translation of our China and Malaysia balance sheets from local currency into the U.S. dollar functional currency, which experienced significant devaluation against the RMB and MYR during the third quarter of 2024 as compared to the third quarter of 2023. Interest expense increased $1.7 million in the third quarter of 2024 as compared to the same period of 2023, partially offset by a $1.0 million increase in interest income.

[0000950170-24-121449:mdna:49]
Total other expense, net increased $12.1 million to $37.4 million for the first three quarters of 2024 from $25.3 million for the first three quarters of 2023. This increase was primarily due to the foreign currency impacts discussed in the paragraph above, which resulted in a $12.9 million foreign currency loss in the first three quarters of 2024 ($12.0 million of which was unrealized) as compared to a $3.1 million foreign currency gain in the first three quarters of 2023 ($4.1 million of which was unrealized). Interest expense increased $1.6 million in the first three quarters of 2024 as compared to the same period of 2023, partially offset by a $4.3 million increase in interest income and government subsidies of $0.8 million.

[0000950170-24-121449:mdna:50]
[same as prior period, unchanged from 0000950170-24-091772:mdna:48]

[0000950170-24-121449:mdna:51]
Income tax expense decreased $9.1 million to $10.7 million for the third quarter of 2024 from $19.8 million for the third quarter of 2023. The decrease in income tax expense was primarily due to a change in the mix of projected foreign and U.S. income resulting in a decrease in our effective tax rate. Such decrease was partially offset by the finalization of Hong Kong corporate income tax returns and the absence in the third quarter of 2024 of finalization of the U.S. income tax return.

[0000950170-24-121449:mdna:52]
Income tax expense stayed constant at $18.5 million for the first three quarters of 2024 compared to the first three quarters of 2023, but with changes in the components. The changes in income tax expense components for the first three quarters of 2024 was primarily due to a windfall tax benefit of the stock-based compensation releases and a net tax benefit of the finalization of China, Canada, and Hong Kong corporate income tax returns, which was offset by the absence of the release of uncertain tax position benefits and finalization of the U.S. income tax return that existed in the first three quarters of 2023.

[0000950170-24-121449:mdna:53]
Our effective tax rate is primarily impacted by the mix of foreign and U.S. income, tax rates in China and Hong Kong, the U.S. federal income tax rate, apportioned state income tax rates, the generation of credits and deductions available to us as well as changes in valuation allowances and certain non-deductible items. We had a net deferred income tax liability of $40.4 million and $56.8 million as of September 30, 2024 and October 2, 2023, respectively.

[0000950170-24-121449:mdna:54]
[same as prior period, unchanged from 0000950170-24-091772:mdna:52]

[0000950170-24-121449:mdna:55]
Our principal sources of liquidity have been cash provided by operations, the issuance of debt, and borrowings under our revolving credit facility. Our principal uses of cash have been to finance capital expenditures, finance acquisitions, fund working capital requirements, repay debt obligations, and repurchase common stock. We anticipate that financing capital expenditures, financing acquisitions, funding working capital requirements, servicing debt, and repurchasing common stock will be the principal demands on our cash in the future.

[0000950170-24-121449:mdna:56]
Cash flow provided by operating activities during the first three quarters of 2024 was $150.8 million as compared to cash flow provided by operating activities of $139.8 million in the same period in 2023. The increase in cash flow was primarily due to an increase in net income of $87.2 million partially offset by an increased investment in working capital.

[0000950170-24-121449:mdna:57]
Net cash used in investing activities during the first three quarters of 2024 was $93.4 million, primarily resulting from the use of $129.7 million for purchases of property, plant and equipment and other assets. This is partially offset by the receipt of $29.6 million of proceeds from the sale of property, plant, and equipment and other assets primarily related to the sale of two buildings vacated by the closure of our Anaheim and Santa Clara plants and $6.7 million of proceeds from the sale of property associated with our Shanghai E‑MS subsidiary. Net cash used in investing activities was approximately $46.1 million for the first three quarters of 2023, primarily reflecting the use of $114.2 million for purchases of property, plant, and equipment and other assets, partially offset by the receipt of $61.8 million of proceeds from the sale of property associated with our Shanghai E‑MS subsidiary and $6.0 million of proceeds from the sale of our Shanghai Backplane Assembly subsidiary, net of cash disposed.

[0000950170-24-121449:mdna:58]
Net cash used in financing activities during the first three quarters of 2024 was $38.2 million reflecting the use of $34.5 million for repurchases of common stock, $8.7 million for the repayment of long-term debt borrowings, and $1.1 million for payment of debt issuance costs, partially offset by $6.1 million of proceeds from long-term debt borrowings related to the refinancing of our Term Loan Facility. Net cash used in financing activities during the first three quarters of 2023 was $87.9 million, primarily reflecting repayment of long-term debt borrowings of $291.5 million, repurchases of common stock of $14.6 million, refunding of customer deposits of $7.5 million, payment of debt issuance costs of $5.5 million, and payment of the original issue discount of $3.5 million, partially offset by the receipt of proceeds from long-term debt borrowing of $234.8 million.

[0000950170-24-121449:mdna:59]
As of September 30, 2024, we had cash and cash equivalents of $469.5 million, of which $189.0 million was held by our foreign subsidiaries, primarily in China. Should we choose to remit cash to the United States from our foreign locations, we may incur tax obligations which would reduce the amount of cash ultimately available to the United States. However, we believe there would be no material tax consequences not previously accrued for the repatriation of this cash.

[0000950170-24-121449:mdna:60]
Our total 2024 capital expenditures are expected to be in the range of $175.0 million to $195.0 million.

[0000950170-24-121449:mdna:61]
[same as prior period, unchanged from 0000950170-24-091772:mdna:59]

[0000950170-24-121449:mdna:62]
On May 3, 2023, our Board of Directors authorized a share repurchase program (2023 Repurchase Program) allowing us to repurchase up to $100.0 million of our common stock from time to time through May 3, 2025. We did not repurchase any shares of our common stock during the quarter ended September 30, 2024. During the three quarters ended September 30, 2024, we repurchased 2.0 million shares of our common stock for a total cost of $34.5 million (including commissions). As of September 30, 2024, the remaining amount in value available to be repurchased under the 2023 Repurchase Program was approximately $41.1 million.

[0000950170-24-121449:mdna:63]
[same as prior period, unchanged from 0000950170-24-091772:mdna:61]

[0000950170-24-121449:mdna:64]
As of September 30, 2024, we had $916.3 million of outstanding debt, net of discount and debt issuance costs, composed of $496.5 million of Senior Notes due March 2029, $339.8 million under the Term Loan Facility, and $80.0 million under the Asia Asset-Based Lending Credit Agreement (Asia ABL).

[0000950170-24-121449:mdna:65]
Pursuant to the terms of the Senior Notes due March 2029 and Term Loan Facility, we are subject to certain affirmative and negative covenants, including limitations on indebtedness, corporate transactions, investments, dispositions, and restricted payments. Under the U.S. Asset-Based Lending Credit Agreement (U.S. ABL) and Asia ABL (collectively, the ABL Revolving Loans), we are also subject to various financial covenants, including leverage and fixed charge coverage ratios. As of September 30, 2024, we were in compliance with the covenants under the Senior Notes due March 2029, Term Loan Facility, and ABL Revolving Loans.

[0000950170-24-121449:mdna:66]
[same as prior period, unchanged from 0000950170-24-091772:mdna:64]

[0000950170-24-121449:mdna:67]
[same as prior period, unchanged from 0000950170-24-091772:mdna:65]

[0000950170-24-121449:mdna:68]
We have agreements with financial institutions to facilitate payments to certain suppliers. Under the terms of the agreements, we confirm the validity of each supplier invoice to the respective financial institution upon receipt. The supplier receives payment from the financial institution, and we pay the financial institution based on the terms negotiated, which generally range from 160 days to 360 days. Liabilities associated with these agreements are recorded in accounts payable on the consolidated condensed balance sheets and amounted to $18.3 million and $18.8 million as of September 30, 2024 and January 1, 2024, respectively.

[0000950170-24-121449:mdna:69]
[same as prior period, unchanged from 0000950170-24-091772:mdna:67]

[0000950170-24-121449:mdna:70]
As part of our on-going operations, we enter into contractual arrangements that obligate us to make future cash payments. These obligations impact our liquidity and capital resource needs. Our estimated future obligations consist of long-term debt obligations, interest on debt obligations, derivative liabilities, purchase obligations, and leases. As of September 30, 2024, there were no material changes outside the ordinary course of business since January 1, 2024 to our contractual obligations and commitments and the related cash requirements except for future interest on debt obligations. Our projected aggregate future interest on debt obligations as of September 30, 2024 amounted to $243.8 million, which we expect to settle as follows: $49.7 million within 1 year, $98.6 million within 1-3 years, $80.1 million within 4-5 years, and $15.4 million after 5 years. For debt obligations based on variable rates, interest rates used are as of September 30, 2024.

[0000950170-24-121449:mdna:71]
[same as prior period, unchanged from 0000950170-24-091772:mdna:69]

[0000950170-24-121449:mdna:72]
We have and may continue to enter into industrial cooperation agreements, sometimes referred to as offset agreements, as a condition to obtaining orders for our products and services from customers in foreign countries. As of September 30, 2024, we had outstanding offset agreements of approximately $27.3 million, some of which extend through 2028. Offset programs usually extend over several years and in some cases provide for penalties in the event we fail to perform in accordance with contract requirements. To date, we have not been obligated to pay any such penalties. For details about our offset agreements, see Part I, Item 1, Note 14, Commitments and Contingencies, of the Notes to Consolidated Condensed Financial Statements included in this Report.

[0000950170-24-121449:mdna:73]
[same as prior period, unchanged from 0000950170-24-091772:mdna:71]

[0000950170-24-121449:mdna:74]
[same as prior period, unchanged from 0000950170-24-091772:mdna:72]

[0000950170-24-121449:mdna:75]
Recently Issued Accounting Standards

[0000950170-24-121449:mdna:76]
[same as prior period, unchanged from 0000950170-24-091772:mdna:74]
