# TTMI notes — 0000950170-24-121449


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureAndSignificantAccountingPoliciesTextBlock

[0000950170-24-121449:notes:1]
[same as prior period, unchanged from 0000950170-24-091772:notes:1]

[0000950170-24-121449:notes:2]
TTM Technologies, Inc. (the Company or TTM) is a leading global manufacturer of technology solutions including mission systems, radio frequency (RF) components, RF microwave/microelectronic assemblies, and quick-turn and technologically advanced printed circuit boards (PCB). The Company provides time-to-market and volume production of advanced technology products and offers a one-stop design, engineering, and manufacturing solution to customers. This solution allows the Company to align technology developments with the diverse needs of the Company’s customers and to enable them to reduce the time required to develop new products and bring them to market.

[0000950170-24-121449:notes:3]
[same as prior period, unchanged from 0000950170-24-091772:notes:3]

[0000950170-24-121449:notes:4]
The accompanying unaudited consolidated condensed financial statements have been prepared by the Company pursuant to the rules and regulations of the Securities and Exchange Commission (SEC). Certain information and disclosures normally included in financial statements prepared in accordance with accounting principles generally accepted in the United States of America (U.S. GAAP) have been condensed or omitted pursuant to such rules and regulations. These consolidated condensed financial statements should be read in conjunction with the consolidated financial statements and the notes thereto included in the Company’s most recent Annual Report on Form 10-K. The preparation of financial statements in accordance with U.S. GAAP requires management to make estimates and assumptions that affect the amounts reported in the Company’s consolidated condensed financial statements and accompanying notes. Due, in part, to the conflict between Russia and Ukraine, and the conflict in the Middle East, the global economy and financial markets have been volatile. As such, the Company has considered information available to it as of the date of issuance of these financial statements and is not aware of any specific events or circumstances that would require an update to its estimates or judgments, or a revision to the carrying value of its assets or liabilities. The actual results the Company experienced may differ materially and adversely from its estimates. The Company uses a 52/53 week fiscal calendar with the fourth quarter ending on the Monday nearest December 31.

[0000950170-24-121449:notes:5]
Recently Issued Accounting Standards Not Yet Adopted

[0000950170-24-121449:notes:6]
In November 2024, the Financial Accounting Standards Board (FASB) issued Accounting Standards Update (ASU) 2024-03, Income Statement - Reporting Comprehensive Income - Expense Disaggregation Disclosures (Subtopic 220-40): Disaggregation of Income Statement Expenses, which requires disclosure in the notes to the financial statements of specified information about certain costs and expenses. The amendments are effective for fiscal years beginning after December 15, 2026, and for interim periods within fiscal years beginning after December 15, 2027. Early adoption is permitted. The amendments should be applied either prospectively to financial statements issued for reporting periods after the effective date of this ASU or retrospectively to any or all prior periods presented in the financial statements. The Company is currently evaluating the new guidance to determine the impact it may have on its consolidated financial statements and related disclosures, but expects additional disclosures upon adoption.

[0000950170-24-121449:notes:7]
In March 2024, the FASB issued ASU 2024-02, Codification Improvements - Amendments to Remove References to the Concepts Statements, to remove various references to concepts statements from the Accounting Standards Codification (ASC). These amendments clarify guidance, simplify wording or structure of guidance, and include other minor improvements. The amendments are effective for fiscal years beginning after December 15, 2024, applied prospectively, with early adoption and retrospective application permitted. The impact of the adoption of the amendments in this update is not expected to be material to the Company's consolidated financial statements and related disclosures.

[0000950170-24-121449:notes:8]
In December 2023, the FASB issued ASU 2023-09, Income Taxes (Topic 740): Improvements to Income Tax Disclosures, which requires disclosure of disaggregated income taxes paid, prescribes standard categories for the components of the effective tax rate reconciliation, and modifies other income tax-related disclosures. The update will be effective for annual periods beginning after December 15, 2024. Early adoption is permitted for annual financial statements not yet issued or made available for issuance. The Company is currently evaluating the new guidance to determine the impact it may have on its consolidated financial statements and related disclosures, but expects additional disclosures upon adoption.

[0000950170-24-121449:notes:9]
In November 2023, the FASB issued ASU 2023-07, Segment Reporting (Topic 280): Improvements to Reportable Segment Disclosures, which updates reportable segment disclosure requirements primarily through enhanced disclosures about significant segment expenses. The amendments are effective for fiscal years beginning after December 15, 2023, and for interim periods within fiscal years beginning after December 15, 2024. Early adoption is permitted. The amendments should be applied retrospectively to all prior periods presented in the financial statements. The Company will adopt ASU 2023-07 in its 2024 fiscal year Form 10-K using a retrospective transition method. This ASU will impact only the Company's disclosures with no impacts to the results of operations, cash flows, and financial condition.

[0000950170-24-121449:notes:10]
In October 2023, the FASB issued ASU 2023-06, Disclosure Improvements: Codification Amendments in Response to the Securities and Exchange Commission’s Disclosure Update and Simplification Initiative, which modifies the disclosure or presentation requirements of a variety of topics in the ASC in response to the SEC’s Release No. 33-10532, Disclosure Update and Simplification Initiative, and align the ASC requirements with the SEC’s regulations. For entities subject to the SEC's existing disclosure requirements, the effective date for each amendment will be the date on which the SEC's removal of that related disclosure from Regulation S-X or Regulation S-K becomes effective. However, if by June 30, 2027, the SEC has not removed the related disclosure from its regulations, the amendments will be removed from the Codification and not become effective. Early adoption is prohibited. The Company is currently evaluating the new guidance to determine the impact it may have on the presentation of its consolidated financial statements and related disclosures.


## us-gaap:TreasuryStockTextBlock

[0000950170-24-121449:notes:11]
[same as prior period, unchanged from 0000950170-24-091772:notes:10]

[0000950170-24-121449:notes:12]
[same as prior period, unchanged from 0000950170-24-091772:notes:11]

[0000950170-24-121449:notes:13]
During the quarter ended September 30, 2024, the Company did not repurchase any shares. During the three quarters ended September 30, 2024, the Company repurchased 1,990 shares of common stock for a total cost of $34,479 (including commissions). As of September 30, 2024, the remaining amount in value available to be repurchased under the 2023 Repurchase Program was approximately $41,088.


## us-gaap:ConcentrationRiskDisclosureTextBlock

[0000950170-24-121449:notes:14]
[same as prior period, unchanged from 0000950170-24-091772:notes:13]

[0000950170-24-121449:notes:15]
[same as prior period, unchanged from 0000950170-24-091772:notes:14]

[0000950170-24-121449:notes:16]
The Company had cash and cash equivalents held by its foreign subsidiaries of $188,952 and $195,928 as of September 30, 2024 and January 1, 2024, respectively. The Company maintains its cash and cash equivalents with major financial institutions and such balances exceed Federal Deposit Insurance Corporation insurance limits. The Company has not experienced any losses in such accounts and believes it is not exposed to any significant risk on cash and cash equivalents.

[0000950170-24-121449:notes:17]
In the normal course of business, the Company extends credit to its customers. Some customers to whom the Company extends credit are located outside the United States. The Company performs on-going credit evaluations of customers, does not require collateral, and considers the credit risk profile of the entity from which the receivable is due in further evaluating collection risk. As of September 30, 2024 and January 1, 2024, there were no customers that accounted for 10% or more of the Company's accounts receivable.

[0000950170-24-121449:notes:18]
The Company’s customers include both OEMs and EMS companies. The Company’s OEM customers often direct a significant portion of their purchases through EMS companies. While the Company’s customers include both OEM and EMS providers, the Company measures customer concentration based on OEM companies, as they are the ultimate end customers.
For the quarter and three quarters ended September 30, 2024, one customer accounted for approximately 11% of the Company's net sales. For the quarter ended October 2, 2023, two customers collectively accounted for approximately 23% of the Company's net sales. For the three quarters ended October 2, 2023, one customer accounted for approximately 13% of the Company's net sales.


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0000950170-24-121449:notes:19]
[same as prior period, unchanged from 0000950170-24-091772:notes:18]

[0000950170-24-121449:notes:20]
As of September 30, 2024, the aggregate amount of the transaction price allocated to remaining performance obligations for long-term contracts was $481,400. The Company expects to recognize revenue on approximately 46% of the remaining performance obligations for the Company’s long-term contracts over the next 12 months with the remaining amount expected to be recognized thereafter.

[0000950170-24-121449:notes:21]
For contracts in which anticipated total costs exceed the total expected revenue, an estimated loss is recognized in the period when identifiable. A provision for the entire amount of the estimated loss is recorded on a cumulative basis. The estimated remaining costs to complete for loss contracts as of September 30, 2024 and January 1, 2024 were $34,703 and $25,213, respectively.

[0000950170-24-121449:notes:22]
Revenue recognized for the three quarters ended September 30, 2024 from amounts recorded as contract liabilities as of January 1, 2024 was $33,331. Revenue recognized for the three quarters ended October 2, 2023 from amounts recorded as contract liabilities as of January 2, 2023 was $33,939.

[0000950170-24-121449:notes:23]
Revenue from products and services transferred to customers over time and at a point in time accounted for 96% and 4%, respectively, of the Company’s revenue for both the quarter and three quarters ended September 30, 2024 and October 2, 2023.

[0000950170-24-121449:notes:24]
Disaggregated revenue by principal end markets within reportable segments was as follows:

[0000950170-24-121449:notes:25]
|  |  | Quarter Ended September 30, 2024 |  |  | Quarter Ended October 2, 2023 |  |
|  |  | PCB |  |  | RF and Specialty Components (RF&S Components) |  |  | Total |  |  | PCB |  |  | RF&S Components |  |  | Total |  |
|  |  | (In thousands) |  |
| End Markets: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Aerospace and Defense |  | $ | 284,275 |  |  | $ | — |  |  | $ | 284,275 |  |  | $ | 255,618 |  |  | $ | — |  |  | $ | 255,618 |  |
| Automotive |  |  | 85,015 |  |  |  | — |  |  |  | 85,015 |  |  |  | 86,803 |  |  |  | — |  |  |  | 86,803 |  |
| Data Center Computing |  |  | 119,299 |  |  |  | 201 |  |  |  | 119,500 |  |  |  | 99,584 |  |  |  | — |  |  |  | 99,584 |  |
| Medical/Industrial/Instrumentation |  |  | 86,185 |  |  |  | 579 |  |  |  | 86,764 |  |  |  | 89,818 |  |  |  | 895 |  |  |  | 90,713 |  |
| Networking |  |  | 32,019 |  |  |  | 8,965 |  |  |  | 40,984 |  |  |  | 31,853 |  |  |  | 8,011 |  |  |  | 39,864 |  |
| Total |  | $ | 606,793 |  |  | $ | 9,745 |  |  | $ | 616,538 |  |  | $ | 563,676 |  |  | $ | 8,906 |  |  | $ | 572,582 |  |

[0000950170-24-121449:notes:26]
|  |  | Three Quarters Ended September 30, 2024 |  |  | Three Quarters Ended October 2, 2023 |  |
|  |  | PCB |  |  | RF&S Components |  |  | Total |  |  | PCB |  |  | RF&S Components |  |  | Total |  |
|  |  | (In thousands) |  |
| End Markets: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Aerospace and Defense |  | $ | 821,840 |  |  | $ | — |  |  | $ | 821,840 |  |  | $ | 742,194 |  |  | $ | — |  |  | $ | 742,194 |  |
| Automotive |  |  | 241,330 |  |  |  | — |  |  |  | 241,330 |  |  |  | 272,644 |  |  |  | — |  |  |  | 272,644 |  |
| Data Center Computing |  |  | 362,728 |  |  |  | 323 |  |  |  | 363,051 |  |  |  | 221,759 |  |  |  | 51 |  |  |  | 221,810 |  |
| Medical/Industrial/Instrumentation |  |  | 251,394 |  |  |  | 2,035 |  |  |  | 253,429 |  |  |  | 279,565 |  |  |  | 2,557 |  |  |  | 282,122 |  |
| Networking |  |  | 87,449 |  |  |  | 24,689 |  |  |  | 112,138 |  |  |  | 118,156 |  |  |  | 26,602 |  |  |  | 144,758 |  |
| Total |  | $ | 1,764,741 |  |  | $ | 27,047 |  |  | $ | 1,791,788 |  |  | $ | 1,634,318 |  |  | $ | 29,210 |  |  | $ | 1,663,528 |  |


## us-gaap:AdditionalFinancialInformationDisclosureTextBlock

[0000950170-24-121449:notes:27]
[same as prior period, unchanged from 0000950170-24-091772:notes:26]

[0000950170-24-121449:notes:28]
|  |  | As of |  |
|  |  | September 30, 2024 |  |  | January 1, 2024 |  |
|  |  | (In thousands) |  |
| Inventories: |  |  |  |  |  |  |
| Raw materials |  | $ | 179,736 |  |  | $ | 165,666 |  |
| Work-in-process |  |  | 45,451 |  |  |  | 45,494 |  |
| Finished goods |  |  | 2,726 |  |  |  | 1,915 |  |
| Inventories |  | $ | 227,913 |  |  | $ | 213,075 |  |
| Property, plant, and equipment, net: |  |  |  |  |  |  |
| Land and land use rights |  | $ | 73,363 |  |  | $ | 71,131 |  |
| Buildings and improvements |  |  | 513,534 |  |  |  | 512,148 |  |
| Machinery and equipment |  |  | 1,090,943 |  |  |  | 986,527 |  |
| Furniture and fixtures and other |  |  | 11,046 |  |  |  | 10,157 |  |
| Construction-in-progress |  |  | 75,001 |  |  |  | 90,940 |  |
| Property, plant, and equipment, gross |  |  | 1,763,887 |  |  |  | 1,670,903 |  |
| Less: Accumulated depreciation |  |  | (904,640 | ) |  |  | (863,236 | ) |
| Property, plant, and equipment, net |  | $ | 859,247 |  |  | $ | 807,667 |  |
| Other current liabilities: |  |  |  |  |  |  |
| Accrued capital expenditures |  | $ | 15,300 |  |  | $ | 35,026 |  |
| Sales return and allowances |  |  | 12,155 |  |  |  | 12,301 |  |
| Accrued facility operating costs |  |  | 9,801 |  |  |  | 10,172 |  |
| Income taxes payable |  |  | 9,197 |  |  |  | 5,466 |  |
| Housing fund |  |  | 8,274 |  |  |  | 7,749 |  |
| Operating leases |  |  | 7,981 |  |  |  | 8,433 |  |
| Warranty |  |  | 6,619 |  |  |  | 10,557 |  |
| Interest |  |  | 3,751 |  |  |  | 9,399 |  |
| Accrued professional fees |  |  | 3,382 |  |  |  | 3,276 |  |
| Restructuring |  |  | 817 |  |  |  | 1,179 |  |
| Derivative liabilities |  |  | — |  |  |  | 297 |  |
| Other |  |  | 44,453 |  |  |  | 36,951 |  |
| Other current liabilities |  | $ | 121,730 |  |  | $ | 140,806 |  |
| Other long-term liabilities: |  |  |  |  |  |  |
| Deferred income taxes |  | $ | 42,454 |  |  | $ | 44,238 |  |
| Customer deposits |  |  | 28,390 |  |  |  | 29,820 |  |
| Finance leases |  |  | 12,198 |  |  |  | 12,799 |  |
| Derivative liabilities |  |  | 1,414 |  |  |  | 1,476 |  |
| Defined benefit pension plan liability |  |  | 704 |  |  |  | 836 |  |
| Other |  |  | 26,199 |  |  |  | 24,349 |  |
| Other long-term liabilities |  | $ | 111,359 |  |  | $ | 113,518 |  |


## us-gaap:GoodwillDisclosureTextBlock

[0000950170-24-121449:notes:29]
[same as prior period, unchanged from 0000950170-24-091772:notes:28]

[0000950170-24-121449:notes:30]
[same as prior period, unchanged from 0000950170-24-091772:notes:29]

[0000950170-24-121449:notes:31]
|  |  | PCB |  |  | RF&S Components |  |  | Total |  |
|  |  | (In thousands) |  |
| As of September 30, 2024 and January 1, 2024 |  |  |  |  |  |  |  |  |  |
| Goodwill |  | $ | 810,235 |  |  | $ | 177,200 |  |  | $ | 987,435 |  |
| Accumulated impairment losses |  |  | (171,400 | ) |  |  | (113,300 | ) |  |  | (284,700 | ) |
| Carrying amount |  | $ | 638,835 |  |  | $ | 63,900 |  |  | $ | 702,735 |  |


## us-gaap:IntangibleAssetsDisclosureTextBlock

[0000950170-24-121449:notes:32]
[same as prior period, unchanged from 0000950170-24-091772:notes:31]

[0000950170-24-121449:notes:33]
[same as prior period, unchanged from 0000950170-24-091772:notes:32]

[0000950170-24-121449:notes:34]
|  |  | GrossAmount |  |  | AccumulatedAmortization |  |  | NetCarryingAmount |  |  | WeightedAverageAmortizationPeriod |  |
|  |  | (In thousands) |  |  | (In years) |  |
| As of September 30, 2024 |  |  |  |  |  |  |  |  |  |  |  |  |
| Customer relationships |  | $ | 324,730 |  |  | $ | (156,026 | ) |  | $ | 168,704 |  |  |  | 11.8 |  |
| Technology |  |  | 66,650 |  |  |  | (34,285 | ) |  |  | 32,365 |  |  |  | 8.2 |  |
| Total |  | $ | 391,380 |  |  | $ | (190,311 | ) |  | $ | 201,069 |  |  |  |  |
| As of January 1, 2024 |  |  |  |  |  |  |  |  |  |  |  |  |
| Customer relationships |  | $ | 416,230 |  |  | $ | (222,766 | ) |  | $ | 193,464 |  |  |  | 11.2 |  |
| Technology |  |  | 66,650 |  |  |  | (27,278 | ) |  |  | 39,372 |  |  |  | 8.2 |  |
| Backlog |  |  | 13,000 |  |  |  | (9,750 | ) |  |  | 3,250 |  |  |  | 2.0 |  |
| Trade names |  |  | 2,500 |  |  |  | (1,875 | ) |  |  | 625 |  |  |  | 2.0 |  |
| Total |  | $ | 498,380 |  |  | $ | (261,669 | ) |  | $ | 236,711 |  |  |  |  |

[0000950170-24-121449:notes:35]
Definite-lived intangibles are amortized using the straight-line method of amortization over the useful life. Amortization expense was $9,286 and $35,642 for the quarter and three quarters ended September 30, 2024, respectively, and $13,764 and $47,811 for the quarter and three quarters ended October 2, 2023, respectively. For the quarter and three quarters ended September 30, 2024, $2,335 and $7,006, respectively, of amortization expense was included in cost of goods sold. For the quarter and three quarters ended October 2, 2023, $2,335 and $10,566, respectively, of amortization expense was included in cost of goods sold.

[0000950170-24-121449:notes:36]
In connection with the finalization of acquired identifiable intangible asset valuation during the second quarter of 2023 related to the Company's acquisition in 2022 of Telephonics, the Company recorded amortization expense of $20,064 related to the acquired identifiable intangible assets during the three quarters ended October 2, 2023 (of which $5,627 corresponded to the fiscal year ended January 2, 2023 due to the change in amortization period). For the three quarters ended October 2, 2023, $7,375 of amortization expense related to the acquired identifiable intangible assets was included in cost of goods sold (of which $2,950 corresponded to the fiscal year ended January 2, 2023).

[0000950170-24-121449:notes:37]
[same as prior period, unchanged from 0000950170-24-091772:notes:36]

[0000950170-24-121449:notes:38]
|  |  | (In thousands) |  |
| Remaining 2024 |  | $ | 9,250 |  |
| 2025 |  |  | 36,897 |  |
| 2026 |  |  | 36,897 |  |
| 2027 |  |  | 34,543 |  |
| 2028 |  |  | 30,997 |  |
| Thereafter |  |  | 52,485 |  |
| Total |  | $ | 201,069 |  |


## us-gaap:LongTermDebtTextBlock

[0000950170-24-121449:notes:39]
(8) Long-term Debt and Letters of Credit

[0000950170-24-121449:notes:40]
Long-term debt was as follows:

[0000950170-24-121449:notes:41]
|  |  | As of September 30, 2024 |  |  | As of January 1, 2024 |  |
|  |  | Interest Rate |  | PrincipalOutstanding |  |  | Interest Rate |  | PrincipalOutstanding |  |
|  |  | (In thousands, except interest rates) |  |
| Senior Notes due March 2029 |  |  | 4.00 |  | % |  | $ | 500,000 |  |  |  | 4.00 |  | % |  | $ | 500,000 |  |
| Term Loan due May 2030 |  |  | 7.10 |  |  |  |  | 346,500 |  |  |  | 8.10 |  |  |  |  | 349,125 |  |
| Asia ABL Revolving Loan due June 2028 |  |  | 6.15 |  |  |  |  | 80,000 |  |  |  | 6.65 |  |  |  |  | 80,000 |  |
| Total debt |  |  |  |  |  |  | 926,500 |  |  |  |  |  |  |  | 929,125 |  |
| Less: Unamortized debt issuance costs |  |  |  |  |  |  | (7,275 | ) |  |  |  |  |  |  | (8,021 | ) |
| Less: Unamortized debt discount |  |  |  |  |  |  | (2,951 | ) |  |  |  |  |  |  | (3,268 | ) |
| Subtotal |  |  |  |  |  |  | 916,274 |  |  |  |  |  |  |  | 917,836 |  |
| Less: Current maturities |  |  |  |  |  |  | (3,465 | ) |  |  |  |  |  |  | (3,500 | ) |
| Long-term debt, less current maturities |  |  |  |  |  | $ | 912,809 |  |  |  |  |  |  | $ | 914,336 |  |

[0000950170-24-121449:notes:42]
Refinancing of Term Loan Facility

[0000950170-24-121449:notes:43]
On August 1, 2024, the Company entered into a First Amendment to its Amended and Restated Term Loan Credit Agreement, dated as of May 30, 2023, by and among the Company, as Borrower, JPMorgan Chase Bank, N.A., as Administrative Agent, and the several lenders from time to time parties thereto, pursuant to which the Company closed its $346,500 new senior secured term loan (Term Loan Facility) that bears interest at a floating rate of 1-month Chicago Mercantile Exchange (CME) Term Secured Overnight Financing Rate (SOFR) plus an applicable margin of 2.25%, 50 basis points lower than the previous term loan facility issued in May 2023. The Term Loan Facility is issued at par, maintains the same maturity of May 30, 2030 as the previous term loan facility, and the majority is a cashless rollover from the previous term loan facility.

[0000950170-24-121449:notes:44]
Debt Covenants

[0000950170-24-121449:notes:45]
Borrowings under the Senior Notes due March 2029 and Term Loan Facility are subject to certain affirmative and negative covenants, including limitations on indebtedness, corporate transactions, investments, dispositions, and restricted payments.

[0000950170-24-121449:notes:46]
Under the occurrence of certain events, the U.S. Asset-Based Lending Credit Agreement (U.S. ABL) and Asia Asset-Based Lending Credit Agreement (Asia ABL) (collectively, the ABL Revolving Loans) are subject to various financial covenants, including leverage and fixed charge coverage ratios.

[0000950170-24-121449:notes:47]
Debt Issuance Costs and Debt Discount

[0000950170-24-121449:notes:48]
Remaining unamortized debt issuance costs and debt discount were as follows:

[0000950170-24-121449:notes:49]
|  |  | As of September 30, 2024 |  | As of January 1, 2024 |
|  |  | DebtIssuance Costs |  |  | DebtDiscount |  |  | EffectiveInterest Rate |  | DebtIssuance Costs |  |  | DebtDiscount |  |  | EffectiveInterest Rate |
|  |  | (In thousands, except interest rates) |
| Senior Notes due March 2029 |  | $ | 3,546 |  |  | $ | — |  |  |  | 4.18 |  | % |  | $ | 4,085 |  |  | $ | — |  |  |  | 4.18 |  | % |
| Term Loan due May 2030 |  |  | 3,729 |  |  |  | 2,951 |  |  |  | 8.01 |  |  |  |  | 3,936 |  |  |  | 3,268 |  |  |  | 8.26 |  |  |
| Total |  | $ | 7,275 |  |  | $ | 2,951 |  |  |  |  |  |  | $ | 8,021 |  |  | $ | 3,268 |  |  |  |  |  |

[0000950170-24-121449:notes:50]
The above debt issuance costs and debt discount are recorded as a reduction of the debt and are amortized into interest expense using an effective interest rate over the duration of the debt.

[0000950170-24-121449:notes:51]
The remaining unamortized debt issuance costs for the ABL Revolving Loans of $1,329 and $1,603 as of September 30, 2024 and January 1, 2024, respectively, are included in deposits and other non-current assets and are amortized to interest expense over the duration of the ABL Revolving Loans using the straight-line method of amortization.

[0000950170-24-121449:notes:52]
As of September 30, 2024, the remaining weighted average amortization period for all unamortized debt issuance costs and debt discount was 5.1 years.


## us-gaap:IncomeTaxDisclosureTextBlock

[0000950170-24-121449:notes:53]
[same as prior period, unchanged from 0000950170-24-091772:notes:52]

[0000950170-24-121449:notes:54]
[same as prior period, unchanged from 0000950170-24-091772:notes:53]

[0000950170-24-121449:notes:55]
During the quarter and three quarters ended September 30, 2024, the Company’s effective tax rate was impacted by a net discrete expense of $610 and net discrete benefit of $2,251, respectively. This was primarily due to the finalization of the Hong Kong corporate income tax return and accrued interest expense on existing uncertain tax positions in the quarter ended September 30, 2024, which was offset by a windfall tax benefit of the stock-based compensation releases in the quarter ended July 1, 2024.

[0000950170-24-121449:notes:56]
[same as prior period, unchanged from 0000950170-24-091772:notes:55]


## us-gaap:SegmentReportingDisclosureTextBlock

[0000950170-24-121449:notes:57]
[same as prior period, unchanged from 0000950170-24-091772:notes:56]

[0000950170-24-121449:notes:58]
[same as prior period, unchanged from 0000950170-24-091772:notes:57]

[0000950170-24-121449:notes:59]
[same as prior period, unchanged from 0000950170-24-091772:notes:58]

[0000950170-24-121449:notes:60]
|  |  | Quarter Ended |  |  | Three Quarters Ended |  |  |
|  |  | September 30, 2024 |  |  | October 2, 2023 |  |  | September 30, 2024 |  |  | October 2, 2023 |  |  |
|  |  | (In thousands) |
| Net Sales: |  |  |  |  |  |  |  |  |  |  |  |  |  |
| PCB |  | $ | 606,793 |  |  | $ | 563,676 |  |  | $ | 1,764,741 |  |  | $ | 1,634,318 |  |  |
| RF&S Components |  |  | 9,745 |  |  |  | 8,906 |  |  |  | 27,047 |  |  |  | 29,210 |  |  |
| Total net sales |  | $ | 616,538 |  |  | $ | 572,582 |  |  | $ | 1,791,788 |  |  | $ | 1,663,528 |  |  |
| Operating Segment Income: |  |  |  |  |  |  |  |  |  |  |  |  |  |
| PCB |  | $ | 96,659 |  |  | $ | 82,868 |  |  | $ | 257,238 |  |  | $ | 192,981 |  |  |
| RF&S Components |  |  | 2,427 |  |  |  | (41,441 | ) |  |  | 6,141 |  |  |  | (36,071 | ) |  |
| Corporate and Other |  |  | (38,838 | ) |  |  | (37,865 | ) |  |  | (120,722 | ) |  |  | (101,361 | ) |  |
| Total operating segment income |  |  | 60,248 |  |  |  | 3,562 |  |  |  | 142,657 |  |  |  | 55,549 |  |  |
| Amortization of definite-lived intangibles (1) |  |  | (9,286 | ) |  |  | (13,764 | ) |  |  | (35,642 | ) |  |  | (47,811 | ) |  |
| Total operating income (loss) |  |  | 50,962 |  |  |  | (10,202 | ) |  |  | 107,015 |  |  |  | 7,738 |  |  |
| Total other expense, net |  |  | (25,945 | ) |  |  | (7,057 | ) |  |  | (37,397 | ) |  |  | (25,325 | ) |  |
| Income (loss) before income taxes |  | $ | 25,017 |  |  | $ | (17,259 | ) |  | $ | 69,618 |  |  | $ | (17,587 | ) |  |

[0000950170-24-121449:notes:61]
|  |  | As of |  |
|  |  | September 30, 2024 |  |  | January 1, 2024 |  |
|  |  | (In thousands) |  |
| Segment Assets: |  |  |  |  |  |  |
| PCB |  | $ | 2,168,242 |  |  | $ | 2,032,202 |  |
| RF&S Components |  |  | 134,832 |  |  |  | 142,520 |  |
| Corporate and Other |  |  | 1,115,744 |  |  |  | 1,148,941 |  |
| Total assets |  | $ | 3,418,818 |  |  | $ | 3,323,663 |  |

[0000950170-24-121449:notes:62]
(1)
Amortization of definite-lived intangibles relates to the PCB and RF&S Components reportable segments. For the quarter and three quarters ended September 30, 2024, $2,335 and $7,006, respectively, of amortization expense is included in cost of goods sold. For the quarter and three quarters ended October 2, 2023, $2,335 and $10,566, respectively, of amortization expense is included in cost of goods sold.

[0000950170-24-121449:notes:63]
During the quarter and three quarters ended October 2, 2023, the Company recorded a non-cash goodwill impairment charge of $44,100 related to its RF&S Components reportable segment.

[0000950170-24-121449:notes:64]
[same as prior period, unchanged from 0000950170-24-091772:notes:62]

[0000950170-24-121449:notes:65]
[same as prior period, unchanged from 0000950170-24-091772:notes:63]

[0000950170-24-121449:notes:66]
|  |  | Quarter Ended |  |  | Three Quarters Ended |  |
|  |  | September 30, 2024 |  |  | October 2, 2023 |  |  | September 30, 2024 |  |  | October 2, 2023 |  |
|  |  | (In thousands) |  |
| Net Sales: |  |  |  |  |  |  |  |  |  |  |  |  |
| United States |  | $ | 316,508 |  |  | $ | 319,105 |  |  | $ | 926,241 |  |  | $ | 949,668 |  |
| Taiwan |  |  | 63,607 |  |  |  | 55,368 |  |  |  | 206,462 |  |  |  | 120,750 |  |
| Other |  |  | 236,423 |  |  |  | 198,109 |  |  |  | 659,085 |  |  |  | 593,110 |  |
| Total net sales |  | $ | 616,538 |  |  | $ | 572,582 |  |  | $ | 1,791,788 |  |  | $ | 1,663,528 |  |


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0000950170-24-121449:notes:67]
[same as prior period, unchanged from 0000950170-24-091772:notes:65]

[0000950170-24-121449:notes:68]
[same as prior period, unchanged from 0000950170-24-091772:notes:66]

[0000950170-24-121449:notes:69]
|  |  | ForeignCurrencyTranslation |  |  | PensionObligation |  |  | Cash FlowHedges |  |  | Total |  |
|  |  | (In thousands) |  |
| Balance as of January 1, 2024 |  | $ | (32,860 | ) |  | $ | 2,530 |  |  | $ | 1,263 |  |  | $ | (29,067 | ) |
| Other comprehensive (loss) income before reclassifications |  |  | (533 | ) |  |  | — |  |  |  | 835 |  |  |  | 302 |  |
| Amounts reclassified from accumulated other comprehensive loss |  |  | — |  |  |  | — |  |  |  | (2,579 | ) |  |  | (2,579 | ) |
| Net year to date other comprehensive loss |  |  | (533 | ) |  |  | — |  |  |  | (1,744 | ) |  |  | (2,277 | ) |
| Balance as of September 30, 2024 |  | $ | (33,393 | ) |  | $ | 2,530 |  |  | $ | (481 | ) |  | $ | (31,344 | ) |


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0000950170-24-121449:notes:70]
(12) Stock-Based Compensation

[0000950170-24-121449:notes:71]
[same as prior period, unchanged from 0000950170-24-091772:notes:103]

[0000950170-24-121449:notes:72]
The Company maintains a long-term incentive program for executives that provides for the issuance of performance-based restricted stock units (PRUs), representing hypothetical shares of the Company’s common stock that may be issued. Under the PRU program, a target number of PRUs is awarded at the beginning of each three-year performance period. The number of shares of common stock released at the end of the performance period depends on performance during the period and may range from zero to 2.4 times the target number for PRUs awarded before 2023 and zero to 2.0 times the target number for PRUs awarded in 2023 and thereafter. For PRUs awarded before 2023, the performance metrics of the PRU program are based on (a) annual financial targets, which are based on revenue and earnings before interest, tax, depreciation, and amortization expense (EBITDA), each equally weighted, and (b) an overall modifier based on the Company’s total stockholder return (TSR) relative to a group of peer companies selected by the Company’s compensation committee, over the three‑year performance period. For PRUs awarded in 2023 and thereafter, the performance metrics of the PRU program are based on (a) annual financial targets, which are based on revenue and EBITDA, each equally weighted, and (b) the three-year TSR performance result, which will be an additive component to the Company’s financial results of the aggregated three-year measurement period.

[0000950170-24-121449:notes:73]
[same as prior period, unchanged from 0000950170-24-091772:notes:105]

[0000950170-24-121449:notes:74]
[same as prior period, unchanged from 0000950170-24-091772:notes:106]

[0000950170-24-121449:notes:75]
[same as prior period, unchanged from 0000950170-24-091772:notes:107]

[0000950170-24-121449:notes:76]
[same as prior period, unchanged from 0000950170-24-091772:notes:108]

[0000950170-24-121449:notes:77]
|  |  | Quarter Ended |  |  | Three Quarters Ended |  |
|  |  | September 30, 2024 |  |  | October 2, 2023 |  |  | September 30, 2024 |  |  | October 2, 2023 |  |
|  |  | (In thousands) |  |
| Cost of goods sold |  | $ | 2,719 |  |  | $ | 2,212 |  |  | $ | 6,689 |  |  | $ | 5,371 |  |
| Selling and marketing |  |  | 1,087 |  |  |  | 888 |  |  |  | 2,791 |  |  |  | 2,327 |  |
| General and administrative |  |  | 4,192 |  |  |  | 2,958 |  |  |  | 11,255 |  |  |  | 8,197 |  |
| Research and development |  |  | 332 |  |  |  | 309 |  |  |  | 962 |  |  |  | 833 |  |
| Total |  | $ | 8,330 |  |  | $ | 6,367 |  |  | $ | 21,697 |  |  | $ | 16,728 |  |

[0000950170-24-121449:notes:78]
A summary of total unrecognized compensation costs as of September 30, 2024 was as follows:

[0000950170-24-121449:notes:79]
|  |  | UnrecognizedCompensation Costs |  |  | Remaining Weighted AverageRecognition Period |  |
|  |  | (In thousands) |  |  | (In years) |  |
| Restricted stock unit (RSU) awards |  | $ | 49,754 |  |  |  | 1.5 |  |
| PRU awards |  |  | 6,268 |  |  |  | 1.7 |  |
| Total |  | $ | 56,022 |  |  |  |  |


## us-gaap:FairValueDisclosuresTextBlock

[0000950170-24-121449:notes:80]
[same as prior period, unchanged from 0000950170-24-091772:notes:83]

[0000950170-24-121449:notes:81]
[same as prior period, unchanged from 0000950170-24-091772:notes:84]

[0000950170-24-121449:notes:82]
[same as prior period, unchanged from 0000950170-24-091772:notes:85]

[0000950170-24-121449:notes:83]
|  |  | As of September 30, 2024 |  |  | As of January 1, 2024 |  |
|  |  | Carrying Amount |  |  | Fair Value |  |  | Carrying Amount |  |  | Fair Value |  |
|  |  | (In thousands) |  |
| Derivative assets, current |  | $ | 1,810 |  |  | $ | 1,810 |  |  | $ | 3,282 |  |  | $ | 3,282 |  |
| Derivative liabilities, current |  |  | — |  |  |  | — |  |  |  | 297 |  |  |  | 297 |  |
| Derivative liabilities, non-current |  |  | 1,414 |  |  |  | 1,414 |  |  |  | 1,476 |  |  |  | 1,476 |  |
| Senior Notes due March 2029 |  |  | 496,454 |  |  |  | 474,415 |  |  |  | 495,915 |  |  |  | 455,035 |  |
| Term Loan due May 2030 |  |  | 339,820 |  |  |  | 347,799 |  |  |  | 341,921 |  |  |  | 351,743 |  |
| ABL Revolving Loans |  |  | 80,000 |  |  |  | 80,000 |  |  |  | 80,000 |  |  |  | 80,000 |  |

[0000950170-24-121449:notes:84]
[same as prior period, unchanged from 0000950170-24-091772:notes:87]

[0000950170-24-121449:notes:85]
The fair value of the long-term debt was estimated based on quoted market prices or discounting the debt over its life using current market rates for similar debt as of September 30, 2024 and January 1, 2024, which are considered Level 2 inputs.

[0000950170-24-121449:notes:86]
As of September 30, 2024 and January 1, 2024, the Company’s other financial instruments included cash and cash equivalents, accounts receivable, contract assets, accounts payable, and contract liabilities. The carrying amount of these instruments approximates fair value.

[0000950170-24-121449:notes:87]
[same as prior period, unchanged from 0000950170-24-091772:notes:90]


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0000950170-24-121449:notes:88]
(14) Commitments and Contingencies

[0000950170-24-121449:notes:89]
Legal Matters

[0000950170-24-121449:notes:90]
The Company is subject to various legal matters, which it considers normal for its business activities. While the Company currently believes that the amount of any reasonably possible loss for known matters would not be material to the Company’s financial condition, the outcome of these actions is inherently difficult to predict. In the event of an adverse outcome, the ultimate potential loss could have a material adverse effect on the Company’s financial condition or results of operations in a particular period. The Company has accrued amounts for its loss contingencies which are probable and estimable as of September 30, 2024 and January 1, 2024 and included as a component of other current liabilities. However, these amounts are not material to the consolidated condensed financial statements of the Company.

[0000950170-24-121449:notes:91]
Offset Agreements

[0000950170-24-121449:notes:92]
The Company has and may continue to enter into industrial cooperation agreements, sometimes referred to as offset agreements, as a condition to obtaining orders for products and services from customers in foreign countries. These agreements are intended to promote investment in the applicable country, and the Company’s obligations under these agreements may be satisfied through activities that do not require the Company to use cash, including transferring technology or providing manufacturing and other consulting support. The obligations under these agreements may also be satisfied through the use of cash for activities such as purchasing supplies from in-country vendors, setting up support centers, research and development investments, acquisitions, and building or leasing facilities for in-country operations. The amount of the offset requirement is determined by contract value awarded and negotiated percentages with customers. As of September 30, 2024, the Company had outstanding offset agreements of approximately $27,268, some of which extend through 2028. Offset programs usually extend over several years and in some cases provide for penalties in the event the Company fails to perform in accordance with contract requirements. To date, the Company has not been obligated to pay any such penalties.

[0000950170-24-121449:notes:93]
Supplier Finance Program Obligations

[0000950170-24-121449:notes:94]
The Company has agreements with financial institutions to facilitate payments to certain suppliers. Under the terms of the agreements, the Company confirms the validity of each supplier invoice to the respective financial institution upon receipt. The supplier receives payment from the financial institution, and the Company pays the financial institution based on the terms negotiated, which generally range from 160 days to 360 days. Liabilities associated with these agreements are recorded in accounts payable on the consolidated condensed balance sheets and amounted to $18,278 and $18,832 as of September 30, 2024 and January 1, 2024, respectively.


## us-gaap:EarningsPerShareTextBlock

[0000950170-24-121449:notes:95]
(15) Earnings (Loss) Per Share

[0000950170-24-121449:notes:96]
[same as prior period, unchanged from 0000950170-24-091772:notes:99]

[0000950170-24-121449:notes:97]
|  |  | Quarter Ended |  |  | Three Quarters Ended |  |
|  |  | September 30, 2024 |  |  | October 2, 2023 |  |  | September 30, 2024 |  |  | October 2, 2023 |  |
|  |  | (In thousands, except per share amounts) |  |
| Net income (loss) |  | $ | 14,311 |  |  | $ | (37,066 | ) |  | $ | 51,129 |  |  | $ | (36,056 | ) |
| Basic weighted average shares |  |  | 101,958 |  |  |  | 103,510 |  |  |  | 101,704 |  |  |  | 102,873 |  |
| Dilutive effect of PRUs, RSUs, and stock options |  |  | 1,870 |  |  |  | — |  |  |  | 2,224 |  |  |  | — |  |
| Diluted shares |  |  | 103,828 |  |  |  | 103,510 |  |  |  | 103,928 |  |  |  | 102,873 |  |
| Earnings (loss) per share: |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  | $ | 0.14 |  |  | $ | (0.36 | ) |  | $ | 0.50 |  |  | $ | (0.35 | ) |
| Diluted |  | $ | 0.14 |  |  | $ | (0.36 | ) |  | $ | 0.49 |  |  | $ | (0.35 | ) |

[0000950170-24-121449:notes:98]
PRUs, RSUs, and stock options to purchase 144 and 166 shares of common stock for the quarter and three quarters ended September 30, 2024, respectively, were not included in the computation of diluted earnings per share. The PRUs were not included in the computation of diluted earnings per share because the performance conditions had not been met at September 30, 2024, and for the RSUs and stock options, the options’ exercise prices or the total expected proceeds under the treasury stock method was greater than the average market price of common stock during the applicable quarter and three quarters and, as a result, the impact would be anti-dilutive.

[0000950170-24-121449:notes:99]
For the quarter and three quarters ended October 2, 2023, potential shares of common stock, consisting of stock options to purchase 60 shares of common stock at exercise prices ranging from $11.83 to $16.60 per share and 697 PRUs were not included in the computation of diluted earnings per share because the Company incurred a net loss and as a result, the impact would be anti‑dilutive. For the quarter and three quarters ended October 2, 2023, potential shares of common stock consisting of 3,533 and 3,204 RSUs, respectively were not included in the computation of diluted earnings per share because the Company incurred a net loss and as a result, the impact would be anti-dilutive.


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0000950170-24-121449:notes:100]
(16) Restructuring Charges

[0000950170-24-121449:notes:101]
On February 8, 2023, the Company announced a consolidation plan, pursuant to which the Company ceased operations at three of its manufacturing facilities during the fiscal year ended January 1, 2024 and consolidated the operations of those facilities into other Company facilities. The three manufacturing facilities were PCB operations located in Anaheim and Santa Clara, California, and Hong Kong. The Company recorded $26,637 of restructuring charges and $6,032 of accelerated depreciation since the February 8, 2023 announcement.

[0000950170-24-121449:notes:102]
In addition to this consolidation plan, the Company recognized employee separation, contract termination, and other costs during the quarter and three quarters ended September 30, 2024 and October 2, 2023 in connection with other global realignment restructuring efforts. Contract termination and other costs primarily represented plant closure costs.

[0000950170-24-121449:notes:103]
[same as prior period, unchanged from 0000950170-24-091772:notes:115]

[0000950170-24-121449:notes:104]
|  |  | Quarter Ended September 30, 2024 |  |  | Quarter Ended October 2, 2023 |  |
|  |  | EmployeeSeparation/Severance |  |  | ContractTerminationand Other Costs |  |  | Total |  |  | EmployeeSeparation/Severance |  |  | ContractTerminationand Other Costs |  |  | Total |  |
|  |  | (In thousands) |  |
| Reportable Segment: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| PCB |  | $ | 139 |  |  | $ | 1,269 |  |  | $ | 1,408 |  |  | $ | 1,924 |  |  | $ | 2,167 |  |  | $ | 4,091 |  |
| Corporate and Other |  |  | — |  |  |  | (15 | ) |  |  | (15 | ) |  |  | — |  |  |  | — |  |  |  | — |  |
| Total |  | $ | 139 |  |  | $ | 1,254 |  |  | $ | 1,393 |  |  | $ | 1,924 |  |  | $ | 2,167 |  |  | $ | 4,091 |  |

[0000950170-24-121449:notes:105]
|  |  | Three Quarters Ended September 30, 2024 |  |  | Three Quarters Ended October 2, 2023 |  |
|  |  | EmployeeSeparation/Severance |  |  | ContractTerminationand Other Costs |  |  | Total |  |  | EmployeeSeparation/Severance |  |  | ContractTerminationand Other Costs |  |  | Total |  |
|  |  | (In thousands) |  |
| Reportable Segment: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| PCB |  | $ | 139 |  |  | $ | 6,212 |  |  | $ | 6,351 |  |  | $ | 13,066 |  |  | $ | 5,352 |  |  | $ | 18,418 |  |
| RF&S Components |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 14 |  |  |  | — |  |  |  | 14 |  |
| Corporate and Other |  |  | — |  |  |  | 16 |  |  |  | 16 |  |  |  | 305 |  |  |  | 324 |  |  |  | 629 |  |
| Total |  | $ | 139 |  |  | $ | 6,228 |  |  | $ | 6,367 |  |  | $ | 13,385 |  |  | $ | 5,676 |  |  | $ | 19,061 |  |

[0000950170-24-121449:notes:106]
[same as prior period, unchanged from 0000950170-24-091772:notes:118]

[0000950170-24-121449:notes:107]
|  |  | EmployeeSeparation/Severance |  |  | ContractTerminationand Other Costs |  |  | Total |  |
|  |  | (In thousands) |  |
| Accrued as of January 1, 2024 |  | $ | 994 |  |  | $ | 185 |  |  | $ | 1,179 |  |
| Charged to expense |  |  | 139 |  |  |  | 6,228 |  |  |  | 6,367 |  |
| Amount paid |  |  | (416 | ) |  |  | (6,313 | ) |  |  | (6,729 | ) |
| Accrued as of September 30, 2024 |  | $ | 717 |  |  | $ | 100 |  |  | $ | 817 |  |


## ecd:MtrlTermsOfTrdArrTextBlock

[0000950170-24-121449:notes:108]
Rule 10b5-1 Trading Plans

[0000950170-24-121449:notes:109]
During the quarter ended September 30, 2024, our directors and/or officers (as defined in Rule 16a-1(f) under the Securities Exchange Act of 1934, as amended (Exchange Act)) adopted or terminated the contracts, instructions, or written plans for the purchase or sale of our securities set forth in the table below.

[0000950170-24-121449:notes:110]
| Name and Title |  | Action |  | Adoption / Termination Date |  | Rule 10b5-1 (1) |  | Non-Rule 10b5-1 (2) |  | Total Number of Shares of Common Stock to be Sold (3) |  | Expiration Date |
| Daniel L. Boehle (Executive Vice President and CFO) |  | Adoption |  | August 8, 2024 |  | X |  |  |  | Indeterminable (4) |  | August 29, 2025 |
| Thomas Clapprood (President, Radar Systems and Sensors Business Unit) |  | Adoption |  | August 30, 2024 |  | X |  |  |  | Indeterminable (4) |  | November 28, 2025 |
| Thomas T. Edman (CEO, President and Director) |  | Adoption |  | August 8, 2024 |  | X |  |  |  | Indeterminable (4) |  | July 31, 2025 |
| Robert Farrell (President, Communication and Computing Business Unit) |  | Adoption |  | August 30, 2024 |  | X |  |  |  | Indeterminable (5) |  | November 28, 2025 |
| Catherine A. Gridley (Executive Vice President and President, Aerospace & Defense Sector) |  | Adoption |  | August 14, 2024 |  | X |  |  |  | Indeterminable (4) |  | July 31, 2025 |
| Jeffrey S. Jankowsky (President, C4ISR + Space Business Unit) |  | Adoption |  | August 29, 2024 |  | X |  |  |  | Up to 10,000 |  | November 28, 2025 |
| Jeffrey S. Jankowsky (President, C4ISR + Space Business Unit) |  | Adoption |  | August 29, 2024 |  | X |  |  |  | Indeterminable (4) |  | July 31, 2025 |
| Dale Knecht (Senior Vice President of Global Information Technology) |  | Adoption |  | August 14, 2024 |  | X |  |  |  | Up to 39,098 (6) |  | July 31, 2025 |
| Dale Knecht (Senior Vice President of Global Information Technology) |  | Adoption |  | August 14, 2024 |  | X |  |  |  | Indeterminable (4) |  | July 31, 2025 |
| Shawn Powers (Executive Vice President and Chief HR Officer) |  | Adoption |  | August 16, 2024 |  | X |  |  |  | Up to 12,400 |  | November 28, 2025 |

[0000950170-24-121449:notes:111]
| Name and Title |  | Action |  | Adoption / Termination Date |  | Rule 10b5-1 (1) |  | Non-Rule 10b5-1 (2) |  | Total Number of Shares of Common Stock to be Sold (3) |  | Expiration Date |
| Shawn Powers (Executive Vice President and Chief HR Officer) |  | Adoption |  | August 16, 2024 |  | X |  |  |  | Indeterminable (4) |  | July 31, 2025 |
| Antonio J. Sanchez (Vice President and Corporate Controller) |  | Adoption |  | August 28, 2024 |  | X |  |  |  | Up to 10,971 (7) |  | July 31, 2025 |
| Douglas L. Soder (Executive Vice President and President, Commercial Sector) |  | Adoption |  | August 8, 2024 |  | X |  |  |  | Up to 50,000 |  | November 28, 2025 |
| Douglas L. Soder (Executive Vice President and President, Commercial Sector) |  | Adoption |  | August 8, 2024 |  | X |  |  |  | Indeterminable (4) |  | July 31, 2025 |
| Philip Titterton (Executive Vice President and COO) |  | Adoption |  | August 8, 2024 |  | X |  |  |  | Up to 73,815 (8) |  | July 31, 2025 |
| Daniel J. Weber (Executive Vice President, Chief Legal Officer and Secretary) |  | Adoption |  | August 29, 2024 |  | X |  |  |  | Indeterminable (4) |  | July 31, 2025 |

[0000950170-24-121449:notes:112]
(1)
Contract, instruction or written plan intended to satisfy the affirmative defense conditions of Rule 10b5-1(c) under the Exchange Act.

[0000950170-24-121449:notes:113]
(2)
“Non-Rule 10b5-1 trading arrangement” as defined in Item 408(c) of Regulation S-K under the Exchange Act.

[0000950170-24-121449:notes:114]
(3)
Represents the maximum number of shares that may be sold pursuant to the 10b5-1 arrangement. The number of shares sold will be dependent on the satisfaction of certain conditions as set forth in the trading plan.

[0000950170-24-121449:notes:115]
(4)
Rule 10b5-1 trading arrangement that is intended to provide for “eligible sell-to-cover transactions” (as described in Rule 10b5-1(c)(1)(ii)(D)(3) under the Exchange Act) to satisfy tax withholding obligations arising exclusively from vesting of restricted stock units (RSUs) or performance-based restricted stock units (PRUs). The number of shares subject to covered RSUs or PSUs that will be sold to satisfy applicable tax withholding obligations upon vesting is not currently determinable as the number will vary based on the market price of our common stock and the extent to which vesting conditions are satisfied. This sell-to-cover arrangement provides solely for the automatic sale of shares that would otherwise be issuable in respect of a covered RSU or PSU in an amount sufficient to satisfy the applicable withholding obligation, with the proceeds of the sale delivered to us in satisfaction of the applicable withholding obligation.

[0000950170-24-121449:notes:116]
(5)
Mr. Farrell’s trading plan provides for (i) sales of up to 1,660 shares of common stock that may be received upon the vesting of certain RSUs, and (ii) sales of a currently indeterminable number of shares of common stock to cover estimated tax withholding obligations and customary brokerage fees arising from vesting of certain other RSUs.

[0000950170-24-121449:notes:117]
(6)
This trading plan for Mr. Knecht provides for sales of up to 39,098 shares of common stock that may be received upon the vesting of certain RSUs or PSUs, in each case, net of the number of shares sold pursuant to Mr. Knecht’s other trading plan concurrently adopted on August 14, 2024, as disclosed in the table, which other trading plan is intended to provide solely for “eligible sell-to-cover transactions” (as described above in Footnote 4).

[0000950170-24-121449:notes:118]
(7)
Mr. Sanchez’s trading plan provides for sales of up to 10,971 shares of common stock that may be received upon the vesting of certain RSUs.

[0000950170-24-121449:notes:119]
(8)
Mr. Titterton’s trading plan provides for sales of up to 73,815 shares of common stock that may be received upon the vesting of certain RSUs or PSUs.
