# TTMI note change history — 0000950170-24-091772 → 0000950170-24-121449


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2024-11-05):
[0000950170-24-121449:note_history:1]
The Company is subject to various legal matters, which it considers normal for its business activities. While the Company currently believes that the amount of any reasonably possible loss for known matters would not be material to the Company’s financial condition, the outcome of these actions is inherently difficult to predict. In the event of an adverse outcome, the ultimate potential loss could have a material adverse effect on the Company’s financial condition or results of operations in a particular period. The Company has accrued amounts for its loss contingencies which are probable and estimable as of September 30, 2024 and January 1, 2024 and included as a component of other current liabilities. However, these amounts are not material to the consolidated condensed financial statements of the Company.
  (was, 2024-08-06, similarity 0.992):
[0000950170-24-091772:note_history:1]
The Company is subject to various legal matters, which it considers normal for its business activities. While the Company currently believes that the amount of any reasonably possible loss for known matters would not be material to the Company’s financial condition, the outcome of these actions is inherently difficult to predict. In the event of an adverse outcome, the ultimate potential loss could have a material adverse effect on the Company’s financial condition or results of operations in a particular period. The Company has accrued amounts for its loss contingencies which are probable and estimable as of July 1, 2024 and January 1, 2024 and included as a component of other current liabilities. However, these amounts are not material to the consolidated condensed financial statements of the Company.

- changed (2024-11-05):
[0000950170-24-121449:note_history:2]
The Company has and may continue to enter into industrial cooperation agreements, sometimes referred to as offset agreements, as a condition to obtaining orders for products and services from customers in foreign countries. These agreements are intended to promote investment in the applicable country, and the Company’s obligations under these agreements may be satisfied through activities that do not require the Company to use cash, including transferring technology or providing manufacturing and other consulting support. The obligations under these agreements may also be satisfied through the use of cash for activities such as purchasing supplies from in-country vendors, setting up support centers, research and development investments, acquisitions, and building or leasing facilities for in-country operations. The amount of the offset requirement is determined by contract value awarded and negotiated percentages with customers. As of September 30, 2024, the Company had outstanding offset agreements of approximately $27,268, some of which extend through 2028. Offset programs usually extend over several years and in some cases provide for penalties in the event the Company fails to perform in accordance with contract requirements. To date, the Company has not been obligated to pay any such penalties.
  (was, 2024-08-06, similarity 0.995):
[0000950170-24-091772:note_history:2]
The Company has and may continue to enter into industrial cooperation agreements, sometimes referred to as offset agreements, as a condition to obtaining orders for products and services from customers in foreign countries. These agreements are intended to promote investment in the applicable country, and the Company’s obligations under these agreements may be satisfied through activities that do not require the Company to use cash, including transferring technology or providing manufacturing and other consulting support. The obligations under these agreements may also be satisfied through the use of cash for activities such as purchasing supplies from in-country vendors, setting up support centers, research and development investments, acquisitions, and building or leasing facilities for in-country operations. The amount of the offset requirement is determined by contract value awarded and negotiated percentages with customers. As of July 1, 2024, the Company had outstanding offset agreements of approximately $27,963, some of which extend through 2028. Offset programs usually extend over several years and in some cases provide for penalties in the event the Company fails to perform in accordance with contract requirements. To date, the Company has not been obligated to pay any such penalties.

- changed (2024-11-05):
[0000950170-24-121449:note_history:3]
The Company has agreements with financial institutions to facilitate payments to certain suppliers. Under the terms of the agreements, the Company confirms the validity of each supplier invoice to the respective financial institution upon receipt. The supplier receives payment from the financial institution, and the Company pays the financial institution based on the terms negotiated, which generally range from 160 days to 360 days. Liabilities associated with these agreements are recorded in accounts payable on the consolidated condensed balance sheets and amounted to $18,278 and $18,832 as of September 30, 2024 and January 1, 2024, respectively.
  (was, 2024-08-06, similarity 0.9753):
[0000950170-24-091772:note_history:3]
The Company has agreements with financial institutions to facilitate payments to certain suppliers. Under the terms of the agreements, the Company confirms the validity of each supplier invoice to the respective financial institution upon receipt. The supplier receives payment from the financial institution, and the Company pays the financial institution based on the terms negotiated, which generally range from 160 days to 360 days. Liabilities associated with these agreements are recorded in accounts payable on the consolidated condensed balance sheets and amounted to $5,057 and $18,832 as of July 1, 2024 and January 1, 2024, respectively.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureAndSignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2024-11-05):
[0000950170-24-121449:note_history:4]
TTM Technologies, Inc. (the Company or TTM) is a leading global manufacturer of technology solutions including mission systems, radio frequency (RF) components, RF microwave/microelectronic assemblies, and quick-turn and technologically advanced printed circuit boards (PCB). The Company provides time-to-market and volume production of advanced technology products and offers a one-stop design, engineering, and manufacturing solution to customers. This solution allows the Company to align technology developments with the diverse needs of the Company’s customers and to enable them to reduce the time required to develop new products and bring them to market.
  (was, 2024-08-06, similarity 0.9977):
[0000950170-24-091772:note_history:4]
TTM Technologies, Inc. (the Company or TTM) is a leading global manufacturer of technology solutions including mission systems, radio frequency (RF) components/RF microwave/microelectronic assemblies, and quick-turn and technologically advanced printed circuit boards (PCB). The Company provides time-to-market and volume production of advanced technology products and offers a one-stop design, engineering, and manufacturing solution to customers. This solution allows the Company to align technology developments with the diverse needs of the Company’s customers and to enable them to reduce the time required to develop new products and bring them to market.

- changed (2024-11-05):
[0000950170-24-121449:note_history:5]
The accompanying unaudited consolidated condensed financial statements have been prepared by the Company pursuant to the rules and regulations of the Securities and Exchange Commission (SEC). Certain information and disclosures normally included in financial statements prepared in accordance with accounting principles generally accepted in the United States of America (U.S. GAAP) have been condensed or omitted pursuant to such rules and regulations. These consolidated condensed financial statements should be read in conjunction with the consolidated financial statements and the notes thereto included in the Company’s most recent Annual Report on Form 10-K. The preparation of financial statements in accordance with U.S. GAAP requires management to make estimates and assumptions that affect the amounts reported in the Company’s consolidated condensed financial statements and accompanying notes. Due, in part, to the conflict between Russia and Ukraine, and the conflict in the Middle East, the global economy and financial markets have been volatile. As such, the Company has considered information available to it as of the date of issuance of these financial statements and is not aware of any specific events or circumstances that would require an update to its estimates or judgments, or a revision to the carrying value of its assets or liabilities. The actual results the Company experienced may differ materially and adversely from its estimates. The Company uses a 52/53 week fiscal calendar with the fourth quarter ending on the Monday nearest December 31.
  (was, 2024-08-06, similarity 0.9873):
[0000950170-24-091772:note_history:5]
The accompanying unaudited consolidated condensed financial statements have been prepared by the Company pursuant to the rules and regulations of the Securities and Exchange Commission (SEC). Certain information and disclosures normally included in financial statements prepared in accordance with accounting principles generally accepted in the United States of America (U.S. GAAP) have been condensed or omitted pursuant to such rules and regulations. These consolidated condensed financial statements should be read in conjunction with the consolidated financial statements and the notes thereto included in the Company’s most recent Annual Report on Form 10-K. The preparation of financial statements in accordance with U.S. GAAP requires management to make estimates and assumptions that affect the amounts reported in the Company’s consolidated condensed financial statements and accompanying notes. Due, in part, to the conflict between Russia and Ukraine, and the conflict in Israel and the Gaza Strip, the global economy and financial markets have been volatile. As such, the Company has considered information available to it as of the date of issuance of these financial statements and is not aware of any specific events or circumstances that would require an update to its estimates or judgments, or a revision to the carrying value of its assets or liabilities. The actual results the Company experienced may differ materially and adversely from its estimates. The Company uses a 52/53 week fiscal calendar with the fourth quarter ending on the Monday nearest December 31.

- added (2024-11-05):
[0000950170-24-121449:note_history:6]
In November 2024, the Financial Accounting Standards Board (FASB) issued Accounting Standards Update (ASU) 2024-03, Income Statement - Reporting Comprehensive Income - Expense Disaggregation Disclosures (Subtopic 220-40): Disaggregation of Income Statement Expenses, which requires disclosure in the notes to the financial statements of specified information about certain costs and expenses. The amendments are effective for fiscal years beginning after December 15, 2026, and for interim periods within fiscal years beginning after December 15, 2027. Early adoption is permitted. The amendments should be applied either prospectively to financial statements issued for reporting periods after the effective date of this ASU or retrospectively to any or all prior periods presented in the financial statements. The Company is currently evaluating the new guidance to determine the impact it may have on its consolidated financial statements and related disclosures, but expects additional disclosures upon adoption.

- changed (2024-11-05):
[0000950170-24-121449:note_history:7]
In March 2024, the FASB issued ASU 2024-02, Codification Improvements - Amendments to Remove References to the Concepts Statements, to remove various references to concepts statements from the Accounting Standards Codification (ASC). These amendments clarify guidance, simplify wording or structure of guidance, and include other minor improvements. The amendments are effective for fiscal years beginning after December 15, 2024, applied prospectively, with early adoption and retrospective application permitted. The impact of the adoption of the amendments in this update is not expected to be material to the Company's consolidated financial statements and related disclosures.
  (was, 2024-08-06, similarity 0.9261):
[0000950170-24-091772:note_history:7]
In March 2024, the Financial Accounting Standards Board (FASB) issued Accounting Standards Update (ASU) 2024-02, Codification Improvements - Amendments to Remove References to the Concepts Statements, to remove various references to concepts statements from the Accounting Standards Codification (ASC). These amendments clarify guidance, simplify wording or structure of guidance, and other minor improvements. The amendments are effective for fiscal years beginning after December 15, 2024, applied prospectively, with early adoption and retrospective application permitted. The impact of the adoption of the amendments in this update is not expected to be material to the Company's consolidated financial statements and related disclosures.

- changed (2024-11-05):
[0000950170-24-121449:note_history:8]
In November 2023, the FASB issued ASU 2023-07, Segment Reporting (Topic 280): Improvements to Reportable Segment Disclosures, which updates reportable segment disclosure requirements primarily through enhanced disclosures about significant segment expenses. The amendments are effective for fiscal years beginning after December 15, 2023, and for interim periods within fiscal years beginning after December 15, 2024. Early adoption is permitted. The amendments should be applied retrospectively to all prior periods presented in the financial statements. The Company will adopt ASU 2023-07 in its 2024 fiscal year Form 10-K using a retrospective transition method. This ASU will impact only the Company's disclosures with no impacts to the results of operations, cash flows, and financial condition.
  (was, 2024-08-06, similarity 0.7317):
[0000950170-24-091772:note_history:8]
In November 2023, the FASB issued ASU 2023-07, Segment Reporting (Topic 280): Improvements to Reportable Segment Disclosures, which updates reportable segment disclosure requirements primarily through enhanced disclosures about significant segment expenses. The amendments are effective for fiscal years beginning after December 15, 2023, and for interim periods within fiscal years beginning after December 15, 2024. Early adoption is permitted. The amendments should be applied retrospectively to all prior periods presented in the financial statements. The Company is currently evaluating the new guidance to determine the impact it may have on its consolidated financial statements and related disclosures, but expects additional disclosures upon adoption.

- changed (2024-11-05):
[0000950170-24-121449:note_history:9]
In October 2023, the FASB issued ASU 2023-06, Disclosure Improvements: Codification Amendments in Response to the Securities and Exchange Commission’s Disclosure Update and Simplification Initiative, which modifies the disclosure or presentation requirements of a variety of topics in the ASC in response to the SEC’s Release No. 33-10532, Disclosure Update and Simplification Initiative, and align the ASC requirements with the SEC’s regulations. For entities subject to the SEC's existing disclosure requirements, the effective date for each amendment will be the date on which the SEC's removal of that related disclosure from Regulation S-X or Regulation S-K becomes effective. However, if by June 30, 2027, the SEC has not removed the related disclosure from its regulations, the amendments will be removed from the Codification and not become effective. Early adoption is prohibited. The Company is currently evaluating the new guidance to determine the impact it may have on the presentation of its consolidated financial statements and related disclosures.
  (was, 2024-08-06, similarity 0.9903):
[0000950170-24-091772:note_history:9]
In October 2023, the FASB issued ASU 2023-06, Disclosure Improvements: Codification Amendments in Response to the Securities and Exchange Commission’s Disclosure Update and Simplification Initiative, which modifies the disclosure or presentation requirements of a variety of topics in the ASC in response to the SEC’s Release No. 33-10532, Disclosure Update and Simplification Initiative, and align the ASC requirements with the SEC’s regulations. For entities subject to the SEC's existing disclosure requirements, the effective date for each amendment will be the date on which the SEC's removal of that related disclosure from Regulation S-X or Regulation S-K becomes effective. However, if by June 30, 2027, the SEC has not removed the related disclosure from its regulations, the amendments will be removed from the Codification and not become effective. Early adoption is prohibited. The Company is currently evaluating the new guidance to determine the impact it may have on its consolidated financial statements and related disclosures.


## ttmi:ScheduleOfUnamortizedDiscountAndDebtIssuanceCostsTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2024-11-05):
[0000950170-24-121449:note_history:10]
|  |  | As of September 30, 2024 |  | As of January 1, 2024 |
|  |  | DebtIssuance Costs |  |  | DebtDiscount |  |  | EffectiveInterest Rate |  | DebtIssuance Costs |  |  | DebtDiscount |  |  | EffectiveInterest Rate |
|  |  | (In thousands, except interest rates) |
| Senior Notes due March 2029 |  | $ | 3,546 |  |  | $ | — |  |  |  | 4.18 |  | % |  | $ | 4,085 |  |  | $ | — |  |  |  | 4.18 |  | % |
| Term Loan due May 2030 |  |  | 3,729 |  |  |  | 2,951 |  |  |  | 8.01 |  |  |  |  | 3,936 |  |  |  | 3,268 |  |  |  | 8.26 |  |  |
| Total |  | $ | 7,275 |  |  | $ | 2,951 |  |  |  |  |  |  | $ | 8,021 |  |  | $ | 3,268 |  |  |  |  |  |
  (was, 2024-08-06, similarity 0.9871):
[0000950170-24-091772:note_history:10]
|  |  | As of July 1, 2024 |  | As of January 1, 2024 |
|  |  | DebtIssuance Costs |  |  | DebtDiscount |  |  | EffectiveInterest Rate |  | DebtIssuance Costs |  |  | DebtDiscount |  |  | EffectiveInterest Rate |
|  |  | (In thousands, except interest rates) |
| Senior Notes due March 2029 |  | $ | 3,727 |  |  | $ | — |  |  |  | 4.18 |  | % |  | $ | 4,085 |  |  | $ | — |  |  |  | 4.18 |  | % |
| Term Loan due May 2030 |  |  | 3,671 |  |  |  | 3,049 |  |  |  | 8.26 |  |  |  |  | 3,936 |  |  |  | 3,268 |  |  |  | 8.26 |  |  |
| Total |  | $ | 7,398 |  |  | $ | 3,049 |  |  |  |  |  |  | $ | 8,021 |  |  | $ | 3,268 |  |  |  |  |  |


## us-gaap:LongTermDebtTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2024-11-05):
[0000950170-24-121449:note_history:11]
|  |  | As of September 30, 2024 |  |  | As of January 1, 2024 |  |
|  |  | Interest Rate |  | PrincipalOutstanding |  |  | Interest Rate |  | PrincipalOutstanding |  |
|  |  | (In thousands, except interest rates) |  |
| Senior Notes due March 2029 |  |  | 4.00 |  | % |  | $ | 500,000 |  |  |  | 4.00 |  | % |  | $ | 500,000 |  |
| Term Loan due May 2030 |  |  | 7.10 |  |  |  |  | 346,500 |  |  |  | 8.10 |  |  |  |  | 349,125 |  |
| Asia ABL Revolving Loan due June 2028 |  |  | 6.15 |  |  |  |  | 80,000 |  |  |  | 6.65 |  |  |  |  | 80,000 |  |
| Total debt |  |  |  |  |  |  | 926,500 |  |  |  |  |  |  |  | 929,125 |  |
| Less: Unamortized debt issuance costs |  |  |  |  |  |  | (7,275 | ) |  |  |  |  |  |  | (8,021 | ) |
| Less: Unamortized debt discount |  |  |  |  |  |  | (2,951 | ) |  |  |  |  |  |  | (3,268 | ) |
| Subtotal |  |  |  |  |  |  | 916,274 |  |  |  |  |  |  |  | 917,836 |  |
| Less: Current maturities |  |  |  |  |  |  | (3,465 | ) |  |  |  |  |  |  | (3,500 | ) |
| Long-term debt, less current maturities |  |  |  |  |  | $ | 912,809 |  |  |  |  |  |  | $ | 914,336 |  |
  (was, 2024-08-06, similarity 0.9923):
[0000950170-24-091772:note_history:11]
|  |  | As of July 1, 2024 |  |  | As of January 1, 2024 |  |
|  |  | Interest Rate |  | PrincipalOutstanding |  |  | Interest Rate |  | PrincipalOutstanding |  |
|  |  | (In thousands, except interest rates) |  |
| Senior Notes due March 2029 |  |  | 4.00 |  | % |  | $ | 500,000 |  |  |  | 4.00 |  | % |  | $ | 500,000 |  |
| Term Loan due May 2030 |  |  | 8.08 |  |  |  |  | 346,500 |  |  |  | 8.10 |  |  |  |  | 349,125 |  |
| Asia ABL Revolving Loan due June 2028 |  |  | 6.63 |  |  |  |  | 80,000 |  |  |  | 6.65 |  |  |  |  | 80,000 |  |
| Total debt |  |  |  |  |  |  | 926,500 |  |  |  |  |  |  |  | 929,125 |  |
| Less: Unamortized debt issuance costs |  |  |  |  |  |  | (7,398 | ) |  |  |  |  |  |  | (8,021 | ) |
| Less: Unamortized debt discount |  |  |  |  |  |  | (3,049 | ) |  |  |  |  |  |  | (3,268 | ) |
| Subtotal |  |  |  |  |  |  | 916,053 |  |  |  |  |  |  |  | 917,836 |  |
| Less: Current maturities |  |  |  |  |  |  | (2,625 | ) |  |  |  |  |  |  | (3,500 | ) |
| Long-term debt, less current maturities |  |  |  |  |  | $ | 913,428 |  |  |  |  |  |  | $ | 914,336 |  |

- added (2024-11-05):
[0000950170-24-121449:note_history:12]
On August 1, 2024, the Company entered into a First Amendment to its Amended and Restated Term Loan Credit Agreement, dated as of May 30, 2023, by and among the Company, as Borrower, JPMorgan Chase Bank, N.A., as Administrative Agent, and the several lenders from time to time parties thereto, pursuant to which the Company closed its $346,500 new senior secured term loan (Term Loan Facility) that bears interest at a floating rate of 1-month Chicago Mercantile Exchange (CME) Term Secured Overnight Financing Rate (SOFR) plus an applicable margin of 2.25%, 50 basis points lower than the previous term loan facility issued in May 2023. The Term Loan Facility is issued at par, maintains the same maturity of May 30, 2030 as the previous term loan facility, and the majority is a cashless rollover from the previous term loan facility.

- changed (2024-11-05):
[0000950170-24-121449:note_history:13]
Borrowings under the Senior Notes due March 2029 and Term Loan Facility are subject to certain affirmative and negative covenants, including limitations on indebtedness, corporate transactions, investments, dispositions, and restricted payments.
  (was, 2024-08-06, similarity 0.9565):
[0000950170-24-091772:note_history:13]
Borrowings under the Senior Notes due March 2029 and Term Loan due May 2030 (Term Loan Facility) are subject to certain affirmative and negative covenants, including limitations on indebtedness, corporate transactions, investments, dispositions, and restricted payments.

- changed (2024-11-05):
[0000950170-24-121449:note_history:14]
|  |  | As of September 30, 2024 |  | As of January 1, 2024 |
|  |  | DebtIssuance Costs |  |  | DebtDiscount |  |  | EffectiveInterest Rate |  | DebtIssuance Costs |  |  | DebtDiscount |  |  | EffectiveInterest Rate |
|  |  | (In thousands, except interest rates) |
| Senior Notes due March 2029 |  | $ | 3,546 |  |  | $ | — |  |  |  | 4.18 |  | % |  | $ | 4,085 |  |  | $ | — |  |  |  | 4.18 |  | % |
| Term Loan due May 2030 |  |  | 3,729 |  |  |  | 2,951 |  |  |  | 8.01 |  |  |  |  | 3,936 |  |  |  | 3,268 |  |  |  | 8.26 |  |  |
| Total |  | $ | 7,275 |  |  | $ | 2,951 |  |  |  |  |  |  | $ | 8,021 |  |  | $ | 3,268 |  |  |  |  |  |
  (was, 2024-08-06, similarity 0.9871):
[0000950170-24-091772:note_history:14]
|  |  | As of July 1, 2024 |  | As of January 1, 2024 |
|  |  | DebtIssuance Costs |  |  | DebtDiscount |  |  | EffectiveInterest Rate |  | DebtIssuance Costs |  |  | DebtDiscount |  |  | EffectiveInterest Rate |
|  |  | (In thousands, except interest rates) |
| Senior Notes due March 2029 |  | $ | 3,727 |  |  | $ | — |  |  |  | 4.18 |  | % |  | $ | 4,085 |  |  | $ | — |  |  |  | 4.18 |  | % |
| Term Loan due May 2030 |  |  | 3,671 |  |  |  | 3,049 |  |  |  | 8.26 |  |  |  |  | 3,936 |  |  |  | 3,268 |  |  |  | 8.26 |  |  |
| Total |  | $ | 7,398 |  |  | $ | 3,049 |  |  |  |  |  |  | $ | 8,021 |  |  | $ | 3,268 |  |  |  |  |  |

- changed (2024-11-05):
[0000950170-24-121449:note_history:15]
The remaining unamortized debt issuance costs for the ABL Revolving Loans of $1,329 and $1,603 as of September 30, 2024 and January 1, 2024, respectively, are included in deposits and other non-current assets and are amortized to interest expense over the duration of the ABL Revolving Loans using the straight-line method of amortization.
  (was, 2024-08-06, similarity 0.9796):
[0000950170-24-091772:note_history:15]
The remaining unamortized debt issuance costs for the ABL Revolving Loans of $1,421 and $1,603 as of July 1, 2024 and January 1, 2024, respectively, are included in deposits and other non-current assets and are amortized to interest expense over the duration of the ABL Revolving Loans using the straight-line method of amortization.

- changed (2024-11-05):
[0000950170-24-121449:note_history:16]
As of September 30, 2024, the remaining weighted average amortization period for all unamortized debt issuance costs and debt discount was 5.1 years.
  (was, 2024-08-06, similarity 0.9531):
[0000950170-24-091772:note_history:16]
As of July 1, 2024, the remaining weighted average amortization period for all unamortized debt issuance costs and debt discount was 5.3 years.

- removed (2024-11-05):
[0000950170-24-091772:note_history:17]
On August 1, 2024, the Company entered into a First Amendment to its Amended and Restated Term Loan Credit Agreement, dated as of May 30, 2023, by and among the Company, as Borrower, JPMorgan Chase Bank, N.A., as Administrative Agent, and the several lenders from time to time parties thereto, pursuant to which the Company closed its $346,500 of a senior secured term loan (New Term Loan Facility) that bears interest at a floating rate of 1-month Chicago Mercantile Exchange (CME) Term Secured Overnight Financing Rate (SOFR) plus an applicable margin of 2.25%, 50 basis points lower than the previous Term Loan Facility issued in May 2023. The New Term Loan Facility is issued at par, maintains the same maturity of May 30, 2030 as the previous Term Loan Facility, and the majority is a cashless rollover from the previous Term Loan Facility.


## us-gaap:ScheduleOfDebtInstrumentsTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2024-11-05):
[0000950170-24-121449:note_history:18]
|  |  | As of September 30, 2024 |  |  | As of January 1, 2024 |  |
|  |  | Interest Rate |  | PrincipalOutstanding |  |  | Interest Rate |  | PrincipalOutstanding |  |
|  |  | (In thousands, except interest rates) |  |
| Senior Notes due March 2029 |  |  | 4.00 |  | % |  | $ | 500,000 |  |  |  | 4.00 |  | % |  | $ | 500,000 |  |
| Term Loan due May 2030 |  |  | 7.10 |  |  |  |  | 346,500 |  |  |  | 8.10 |  |  |  |  | 349,125 |  |
| Asia ABL Revolving Loan due June 2028 |  |  | 6.15 |  |  |  |  | 80,000 |  |  |  | 6.65 |  |  |  |  | 80,000 |  |
| Total debt |  |  |  |  |  |  | 926,500 |  |  |  |  |  |  |  | 929,125 |  |
| Less: Unamortized debt issuance costs |  |  |  |  |  |  | (7,275 | ) |  |  |  |  |  |  | (8,021 | ) |
| Less: Unamortized debt discount |  |  |  |  |  |  | (2,951 | ) |  |  |  |  |  |  | (3,268 | ) |
| Subtotal |  |  |  |  |  |  | 916,274 |  |  |  |  |  |  |  | 917,836 |  |
| Less: Current maturities |  |  |  |  |  |  | (3,465 | ) |  |  |  |  |  |  | (3,500 | ) |
| Long-term debt, less current maturities |  |  |  |  |  | $ | 912,809 |  |  |  |  |  |  | $ | 914,336 |  |
  (was, 2024-08-06, similarity 0.9923):
[0000950170-24-091772:note_history:18]
|  |  | As of July 1, 2024 |  |  | As of January 1, 2024 |  |
|  |  | Interest Rate |  | PrincipalOutstanding |  |  | Interest Rate |  | PrincipalOutstanding |  |
|  |  | (In thousands, except interest rates) |  |
| Senior Notes due March 2029 |  |  | 4.00 |  | % |  | $ | 500,000 |  |  |  | 4.00 |  | % |  | $ | 500,000 |  |
| Term Loan due May 2030 |  |  | 8.08 |  |  |  |  | 346,500 |  |  |  | 8.10 |  |  |  |  | 349,125 |  |
| Asia ABL Revolving Loan due June 2028 |  |  | 6.63 |  |  |  |  | 80,000 |  |  |  | 6.65 |  |  |  |  | 80,000 |  |
| Total debt |  |  |  |  |  |  | 926,500 |  |  |  |  |  |  |  | 929,125 |  |
| Less: Unamortized debt issuance costs |  |  |  |  |  |  | (7,398 | ) |  |  |  |  |  |  | (8,021 | ) |
| Less: Unamortized debt discount |  |  |  |  |  |  | (3,049 | ) |  |  |  |  |  |  | (3,268 | ) |
| Subtotal |  |  |  |  |  |  | 916,053 |  |  |  |  |  |  |  | 917,836 |  |
| Less: Current maturities |  |  |  |  |  |  | (2,625 | ) |  |  |  |  |  |  | (3,500 | ) |
| Long-term debt, less current maturities |  |  |  |  |  | $ | 913,428 |  |  |  |  |  |  | $ | 914,336 |  |


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2024-11-05):
[0000950170-24-121449:note_history:19]
Disaggregated revenue by principal end markets within reportable segments was as follows:
  (was, 2024-08-06, similarity 0.9886):
[0000950170-24-091772:note_history:19]
Disaggregated revenue by principal end markets with reportable segments was as follows:

- changed (2024-11-05):
[0000950170-24-121449:note_history:20]
|  |  | Quarter Ended September 30, 2024 |  |  | Quarter Ended October 2, 2023 |  |
|  |  | PCB |  |  | RF and Specialty Components (RF&S Components) |  |  | Total |  |  | PCB |  |  | RF&S Components |  |  | Total |  |
|  |  | (In thousands) |  |
| End Markets: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Aerospace and Defense |  | $ | 284,275 |  |  | $ | — |  |  | $ | 284,275 |  |  | $ | 255,618 |  |  | $ | — |  |  | $ | 255,618 |  |
| Automotive |  |  | 85,015 |  |  |  | — |  |  |  | 85,015 |  |  |  | 86,803 |  |  |  | — |  |  |  | 86,803 |  |
| Data Center Computing |  |  | 119,299 |  |  |  | 201 |  |  |  | 119,500 |  |  |  | 99,584 |  |  |  | — |  |  |  | 99,584 |  |
| Medical/Industrial/Instrumentation |  |  | 86,185 |  |  |  | 579 |  |  |  | 86,764 |  |  |  | 89,818 |  |  |  | 895 |  |  |  | 90,713 |  |
| Networking |  |  | 32,019 |  |  |  | 8,965 |  |  |  | 40,984 |  |  |  | 31,853 |  |  |  | 8,011 |  |  |  | 39,864 |  |
| Total |  | $ | 606,793 |  |  | $ | 9,745 |  |  | $ | 616,538 |  |  | $ | 563,676 |  |  | $ | 8,906 |  |  | $ | 572,582 |  |
  (was, 2024-08-06, similarity 0.9833):
[0000950170-24-091772:note_history:20]
|  |  | Quarter Ended July 1, 2024 |  |  | Quarter Ended July 3, 2023 |  |
|  |  | PCB |  |  | RF and Specialty Components (RF&S Components) |  |  | Total |  |  | PCB |  |  | RF&S Components |  |  | Total |  |
|  |  | (In thousands) |  |
| End Markets: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Aerospace and Defense |  | $ | 272,789 |  |  | $ | — |  |  | $ | 272,789 |  |  | $ | 254,284 |  |  | $ | — |  |  | $ | 254,284 |  |
| Automotive |  |  | 82,698 |  |  |  | — |  |  |  | 82,698 |  |  |  | 92,374 |  |  |  | — |  |  |  | 92,374 |  |
| Data Center Computing |  |  | 124,052 |  |  |  | 63 |  |  |  | 124,115 |  |  |  | 64,305 |  |  |  | 51 |  |  |  | 64,356 |  |
| Medical/Industrial/Instrumentation |  |  | 86,416 |  |  |  | 722 |  |  |  | 87,138 |  |  |  | 88,979 |  |  |  | 745 |  |  |  | 89,724 |  |
| Networking |  |  | 30,152 |  |  |  | 8,245 |  |  |  | 38,397 |  |  |  | 36,589 |  |  |  | 9,182 |  |  |  | 45,771 |  |
| Total |  | $ | 596,107 |  |  | $ | 9,030 |  |  | $ | 605,137 |  |  | $ | 536,531 |  |  | $ | 9,978 |  |  | $ | 546,509 |  |

- changed (2024-11-05):
[0000950170-24-121449:note_history:21]
|  |  | Three Quarters Ended September 30, 2024 |  |  | Three Quarters Ended October 2, 2023 |  |
|  |  | PCB |  |  | RF&S Components |  |  | Total |  |  | PCB |  |  | RF&S Components |  |  | Total |  |
|  |  | (In thousands) |  |
| End Markets: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Aerospace and Defense |  | $ | 821,840 |  |  | $ | — |  |  | $ | 821,840 |  |  | $ | 742,194 |  |  | $ | — |  |  | $ | 742,194 |  |
| Automotive |  |  | 241,330 |  |  |  | — |  |  |  | 241,330 |  |  |  | 272,644 |  |  |  | — |  |  |  | 272,644 |  |
| Data Center Computing |  |  | 362,728 |  |  |  | 323 |  |  |  | 363,051 |  |  |  | 221,759 |  |  |  | 51 |  |  |  | 221,810 |  |
| Medical/Industrial/Instrumentation |  |  | 251,394 |  |  |  | 2,035 |  |  |  | 253,429 |  |  |  | 279,565 |  |  |  | 2,557 |  |  |  | 282,122 |  |
| Networking |  |  | 87,449 |  |  |  | 24,689 |  |  |  | 112,138 |  |  |  | 118,156 |  |  |  | 26,602 |  |  |  | 144,758 |  |
| Total |  | $ | 1,764,741 |  |  | $ | 27,047 |  |  | $ | 1,791,788 |  |  | $ | 1,634,318 |  |  | $ | 29,210 |  |  | $ | 1,663,528 |  |
  (was, 2024-08-06, similarity 0.9606):
[0000950170-24-091772:note_history:21]
|  |  | Two Quarters Ended July 1, 2024 |  |  | Two Quarters Ended July 3, 2023 |  |
|  |  | PCB |  |  | RF&S Components |  |  | Total |  |  | PCB |  |  | RF&S Components |  |  | Total |  |
|  |  | (In thousands) |  |
| End Markets: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Aerospace and Defense |  | $ | 537,565 |  |  | $ | — |  |  | $ | 537,565 |  |  | $ | 486,576 |  |  | $ | — |  |  | $ | 486,576 |  |
| Automotive |  |  | 156,315 |  |  |  | — |  |  |  | 156,315 |  |  |  | 185,841 |  |  |  | — |  |  |  | 185,841 |  |
| Data Center Computing |  |  | 243,429 |  |  |  | 122 |  |  |  | 243,551 |  |  |  | 122,175 |  |  |  | 51 |  |  |  | 122,226 |  |
| Medical/Industrial/Instrumentation |  |  | 165,209 |  |  |  | 1,456 |  |  |  | 166,665 |  |  |  | 189,747 |  |  |  | 1,662 |  |  |  | 191,409 |  |
| Networking |  |  | 55,430 |  |  |  | 15,724 |  |  |  | 71,154 |  |  |  | 86,303 |  |  |  | 18,591 |  |  |  | 104,894 |  |
| Total |  | $ | 1,157,948 |  |  | $ | 17,302 |  |  | $ | 1,175,250 |  |  | $ | 1,070,642 |  |  | $ | 20,304 |  |  | $ | 1,090,946 |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2024-11-05):
[0000950170-24-121449:note_history:22]
As of September 30, 2024, the aggregate amount of the transaction price allocated to remaining performance obligations for long-term contracts was $481,400. The Company expects to recognize revenue on approximately 46% of the remaining performance obligations for the Company’s long-term contracts over the next 12 months with the remaining amount expected to be recognized thereafter.
  (was, 2024-08-06, similarity 0.9823):
[0000950170-24-091772:note_history:22]
As of July 1, 2024, the aggregate amount of the transaction price allocated to remaining performance obligations for long-term contracts was $413,941. The Company expects to recognize revenue on approximately 49% of the remaining performance obligations for the Company’s long-term contracts over the next 12 months with the remaining amount expected to be recognized thereafter.

- changed (2024-11-05):
[0000950170-24-121449:note_history:23]
For contracts in which anticipated total costs exceed the total expected revenue, an estimated loss is recognized in the period when identifiable. A provision for the entire amount of the estimated loss is recorded on a cumulative basis. The estimated remaining costs to complete for loss contracts as of September 30, 2024 and January 1, 2024 were $34,703 and $25,213, respectively.
  (was, 2024-08-06, similarity 0.982):
[0000950170-24-091772:note_history:23]
For contracts in which anticipated total costs exceed the total expected revenue, an estimated loss is recognized in the period when identifiable. A provision for the entire amount of the estimated loss is recorded on a cumulative basis. The estimated remaining costs to complete for loss contracts as of July 1, 2024 and January 1, 2024 were $35,227 and $25,213, respectively.

- added (2024-11-05):
[0000950170-24-121449:note_history:24]
Revenue recognized for the three quarters ended September 30, 2024 from amounts recorded as contract liabilities as of January 1, 2024 was $33,331. Revenue recognized for the three quarters ended October 2, 2023 from amounts recorded as contract liabilities as of January 2, 2023 was $33,939.

- changed (2024-11-05):
[0000950170-24-121449:note_history:25]
Revenue from products and services transferred to customers over time and at a point in time accounted for 96% and 4%, respectively, of the Company’s revenue for both the quarter and three quarters ended September 30, 2024 and October 2, 2023.
  (was, 2024-08-06, similarity 0.8767):
[0000950170-24-091772:note_history:25]
Revenue from products and services transferred to customers over time and at a point in time accounted for 96% and 4%, respectively, of the Company’s revenue for both the quarter and two quarters ended July 1, 2024 and July 3, 2023.

- changed (2024-11-05):
[0000950170-24-121449:note_history:26]
Disaggregated revenue by principal end markets within reportable segments was as follows:
  (was, 2024-08-06, similarity 0.9886):
[0000950170-24-091772:note_history:26]
Disaggregated revenue by principal end markets with reportable segments was as follows:

- changed (2024-11-05):
[0000950170-24-121449:note_history:27]
|  |  | Quarter Ended September 30, 2024 |  |  | Quarter Ended October 2, 2023 |  |
|  |  | PCB |  |  | RF and Specialty Components (RF&S Components) |  |  | Total |  |  | PCB |  |  | RF&S Components |  |  | Total |  |
|  |  | (In thousands) |  |
| End Markets: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Aerospace and Defense |  | $ | 284,275 |  |  | $ | — |  |  | $ | 284,275 |  |  | $ | 255,618 |  |  | $ | — |  |  | $ | 255,618 |  |
| Automotive |  |  | 85,015 |  |  |  | — |  |  |  | 85,015 |  |  |  | 86,803 |  |  |  | — |  |  |  | 86,803 |  |
| Data Center Computing |  |  | 119,299 |  |  |  | 201 |  |  |  | 119,500 |  |  |  | 99,584 |  |  |  | — |  |  |  | 99,584 |  |
| Medical/Industrial/Instrumentation |  |  | 86,185 |  |  |  | 579 |  |  |  | 86,764 |  |  |  | 89,818 |  |  |  | 895 |  |  |  | 90,713 |  |
| Networking |  |  | 32,019 |  |  |  | 8,965 |  |  |  | 40,984 |  |  |  | 31,853 |  |  |  | 8,011 |  |  |  | 39,864 |  |
| Total |  | $ | 606,793 |  |  | $ | 9,745 |  |  | $ | 616,538 |  |  | $ | 563,676 |  |  | $ | 8,906 |  |  | $ | 572,582 |  |
  (was, 2024-08-06, similarity 0.9833):
[0000950170-24-091772:note_history:27]
|  |  | Quarter Ended July 1, 2024 |  |  | Quarter Ended July 3, 2023 |  |
|  |  | PCB |  |  | RF and Specialty Components (RF&S Components) |  |  | Total |  |  | PCB |  |  | RF&S Components |  |  | Total |  |
|  |  | (In thousands) |  |
| End Markets: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Aerospace and Defense |  | $ | 272,789 |  |  | $ | — |  |  | $ | 272,789 |  |  | $ | 254,284 |  |  | $ | — |  |  | $ | 254,284 |  |
| Automotive |  |  | 82,698 |  |  |  | — |  |  |  | 82,698 |  |  |  | 92,374 |  |  |  | — |  |  |  | 92,374 |  |
| Data Center Computing |  |  | 124,052 |  |  |  | 63 |  |  |  | 124,115 |  |  |  | 64,305 |  |  |  | 51 |  |  |  | 64,356 |  |
| Medical/Industrial/Instrumentation |  |  | 86,416 |  |  |  | 722 |  |  |  | 87,138 |  |  |  | 88,979 |  |  |  | 745 |  |  |  | 89,724 |  |
| Networking |  |  | 30,152 |  |  |  | 8,245 |  |  |  | 38,397 |  |  |  | 36,589 |  |  |  | 9,182 |  |  |  | 45,771 |  |
| Total |  | $ | 596,107 |  |  | $ | 9,030 |  |  | $ | 605,137 |  |  | $ | 536,531 |  |  | $ | 9,978 |  |  | $ | 546,509 |  |

- changed (2024-11-05):
[0000950170-24-121449:note_history:28]
|  |  | Three Quarters Ended September 30, 2024 |  |  | Three Quarters Ended October 2, 2023 |  |
|  |  | PCB |  |  | RF&S Components |  |  | Total |  |  | PCB |  |  | RF&S Components |  |  | Total |  |
|  |  | (In thousands) |  |
| End Markets: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Aerospace and Defense |  | $ | 821,840 |  |  | $ | — |  |  | $ | 821,840 |  |  | $ | 742,194 |  |  | $ | — |  |  | $ | 742,194 |  |
| Automotive |  |  | 241,330 |  |  |  | — |  |  |  | 241,330 |  |  |  | 272,644 |  |  |  | — |  |  |  | 272,644 |  |
| Data Center Computing |  |  | 362,728 |  |  |  | 323 |  |  |  | 363,051 |  |  |  | 221,759 |  |  |  | 51 |  |  |  | 221,810 |  |
| Medical/Industrial/Instrumentation |  |  | 251,394 |  |  |  | 2,035 |  |  |  | 253,429 |  |  |  | 279,565 |  |  |  | 2,557 |  |  |  | 282,122 |  |
| Networking |  |  | 87,449 |  |  |  | 24,689 |  |  |  | 112,138 |  |  |  | 118,156 |  |  |  | 26,602 |  |  |  | 144,758 |  |
| Total |  | $ | 1,764,741 |  |  | $ | 27,047 |  |  | $ | 1,791,788 |  |  | $ | 1,634,318 |  |  | $ | 29,210 |  |  | $ | 1,663,528 |  |
  (was, 2024-08-06, similarity 0.9606):
[0000950170-24-091772:note_history:28]
|  |  | Two Quarters Ended July 1, 2024 |  |  | Two Quarters Ended July 3, 2023 |  |
|  |  | PCB |  |  | RF&S Components |  |  | Total |  |  | PCB |  |  | RF&S Components |  |  | Total |  |
|  |  | (In thousands) |  |
| End Markets: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Aerospace and Defense |  | $ | 537,565 |  |  | $ | — |  |  | $ | 537,565 |  |  | $ | 486,576 |  |  | $ | — |  |  | $ | 486,576 |  |
| Automotive |  |  | 156,315 |  |  |  | — |  |  |  | 156,315 |  |  |  | 185,841 |  |  |  | — |  |  |  | 185,841 |  |
| Data Center Computing |  |  | 243,429 |  |  |  | 122 |  |  |  | 243,551 |  |  |  | 122,175 |  |  |  | 51 |  |  |  | 122,226 |  |
| Medical/Industrial/Instrumentation |  |  | 165,209 |  |  |  | 1,456 |  |  |  | 166,665 |  |  |  | 189,747 |  |  |  | 1,662 |  |  |  | 191,409 |  |
| Networking |  |  | 55,430 |  |  |  | 15,724 |  |  |  | 71,154 |  |  |  | 86,303 |  |  |  | 18,591 |  |  |  | 104,894 |  |
| Total |  | $ | 1,157,948 |  |  | $ | 17,302 |  |  | $ | 1,175,250 |  |  | $ | 1,070,642 |  |  | $ | 20,304 |  |  | $ | 1,090,946 |  |

- removed (2024-11-05):
[0000950170-24-091772:note_history:29]
Revenue recognized for the two quarters ended July 1, 2024 from amounts recorded as contract liabilities as of January 1, 2024 was $28,205. Revenue recognized for the two quarters ended July 3, 2023 from amounts recorded as contract liabilities as of January 2, 2023 was $27,069.
