# TTMI notes — 0001564590-21-040796


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureAndSignificantAccountingPoliciesTextBlock

[0001564590-21-040796:notes:1]
[same as prior period, unchanged from 0001564590-21-024040:notes:1]

[0001564590-21-040796:notes:2]
[same as prior period, unchanged from 0001564590-21-024040:notes:2]

[0001564590-21-040796:notes:3]
[same as prior period, unchanged from 0001564590-21-024040:notes:3]

[0001564590-21-040796:notes:4]
The accompanying consolidated condensed financial statements have been prepared by the Company, without audit, pursuant to the rules and regulations of the Securities and Exchange Commission (SEC). Certain information and disclosures normally included in financial statements prepared in accordance with accounting principles generally accepted in the United States of America (U.S. GAAP) have been condensed or omitted pursuant to such rules and regulations. It is suggested that these consolidated condensed financial statements be read in conjunction with the consolidated financial statements and the notes thereto included in the Company’s most recent Annual Report on Form 10-K. The preparation of financial statements in accordance with U.S. GAAP requires management to make estimates and assumptions that affect the amounts reported in the Company’s consolidated condensed financial statements and accompanying notes. Due to the coronavirus (COVID-19) global pandemic, the global economy and financial markets have been volatile and there is a significant amount of uncertainty about the length and severity of the consequences caused by the on-going pandemic. The Company has considered information available to it as of the date of issuance of these financial statements and is not aware of any specific events or circumstances that would require an update to its estimates or judgments, or a revision to the carrying value of its assets or liabilities. Actual results could differ materially from those estimates. The Company uses a 13-week fiscal quarter accounting period with the fourth quarter ending on the Monday nearest December 31.

[0001564590-21-040796:notes:5]
On January 19, 2020, the Company entered into a definitive equity interests purchase agreement with AKMMeadville Electronics (Xiamen) Co., Ltd (the Purchaser) for the sale of the Company’s following subsidiaries, which was completed on April 17, 2020: Shanghai Kaiser Electronics Co., Ltd. (SKE), Shanghai Meadville Electronics Co., Ltd. (SME), Shanghai Meadville Science & Technology Co., Ltd. (SP) and Guangzhou Meadville Electronics Co., Ltd. (GME) (collectively, the Mobility business unit). For all periods presented in the consolidated condensed statements of operations, all sales, costs, expenses, income taxes and gain on sale attributable to the Mobility business unit have been aggregated under the caption “Income from discontinued operations, net of income taxes”. Refer to Note 2, Discontinued Operations, for additional information.

[0001564590-21-040796:notes:6]
[same as prior period, unchanged from 0001564590-21-024040:notes:6]

[0001564590-21-040796:notes:7]
[same as prior period, unchanged from 0001564590-21-024040:notes:7]

[0001564590-21-040796:notes:8]
The Company currently has two reportable segments: PCB and RF and Specialty Components (RF&S Components). In fiscal 2020, subsequent to the quarter ended June 29, 2020, RF&S Components was added as a reportable segment. As a result, the Company had three reportable segments as of December 28, 2020: PCB, RF&S Components, and E-M Solutions. On April 29, 2020, the Company announced the restructuring of its E-M Solutions business unit. In prior periods, the Company’s E-M Solutions business unit consisted of three Chinese manufacturing facilities with two being in Shanghai (SH BPA and SH E-MS) and one in Shenzhen (SZ). The Company closed the SH E-MS and SZ facilities at the end of 2020 and integrated the SH BPA facility into its PCB operations. As of March 29, 2021, E-M Solutions no longer met the criteria for segment reporting. As a result of the addition of the RF&S Components reportable segment and the restructuring of the E-M Solutions business unit, certain prior year amounts have been reclassified to conform to this new presentation.

[0001564590-21-040796:notes:9]
Immaterial Correction of Error

[0001564590-21-040796:notes:10]
During the quarter ended September 28, 2020, the Company paid for certain transaction costs related to the sale of the Mobility business unit totaling $11,043. These transaction costs should have been recorded as an expense earlier in the year and recorded in the period ending June 29, 2020, which would have reduced the gain on sale of Mobility business unit, during the quarter ended June 29, 2020. The Company overstated both the income from discontinued operations, net of income taxes and net income by $11,043, both basic earnings per share from discontinued operations and basic earnings per share of $0.10 and $0.11 in the quarter and two quarters ended June 29, 2020, respectively, and both diluted earnings per share from discontinued operations and diluted earnings per share of $0.10 in the quarter and two quarters ended June 29, 2020. Management concluded that this error in the timing of recording the expense was not material to the consolidated condensed financial statements for the quarter and two quarters ended June 29, 2020. Prior period amounts have been revised to correct the error.

[0001564590-21-040796:notes:11]
[same as prior period, unchanged from 0001564590-21-024040:notes:9]

[0001564590-21-040796:notes:12]
Recently Adopted Accounting Standards

[0001564590-21-040796:notes:13]
In December 2019, the Financial Accounting Standards Board (FASB) issued ASU 2019-12, Income Taxes (Topic 740): Simplifying the Accounting for Income Taxes, which is intended to simplify various aspects related to accounting for income taxes. ASU 2019-12 removes certain exceptions to the general principles in Topic 740 and also clarifies and amends existing guidance to improve consistent application. The guidance is effective for fiscal years beginning after December 15, 2020, including interim periods within those fiscal years. Early adoption is permitted. The Company adopted this ASU as of December 29, 2020 and it did not have a material impact on its consolidated condensed financial statements and related disclosures.


## us-gaap:DisposalGroupsIncludingDiscontinuedOperationsDisclosureTextBlock

[0001564590-21-040796:notes:14]
[same as prior period, unchanged from 0001564590-21-024040:notes:13]

[0001564590-21-040796:notes:15]
On January 19, 2020, the Company entered into a definitive equity interests purchase agreement for the sale of the Company’s Mobility business unit. The sale was completed on April 17, 2020 for a base purchase price of $550,000, subject to customary purchase price adjustments. The base purchase price did not include certain accounts receivable of the divested business, which were estimated to total approximately $95,000. After the price adjustments, the final purchase price was $569,246, which did not include approximately $83,000 accounts receivable of the divested business.

[0001564590-21-040796:notes:16]
[same as prior period, unchanged from 0001564590-21-024040:notes:15]

[0001564590-21-040796:notes:17]
[same as prior period, unchanged from 0001564590-21-024040:notes:16]

[0001564590-21-040796:notes:18]
[same as prior period, unchanged from 0001564590-21-024040:notes:17]

[0001564590-21-040796:notes:19]
The following table summarizes the results of Mobility operations for the quarter and two quarters ended June 29, 2020 prior to sale:

[0001564590-21-040796:notes:20]
|  |  | Quarter Ended |  |  | Two Quarters Ended |  |
|  |  | June 29, |  |  | June 29, |  |
|  |  | 2020 |  |  | 2020 |  |
|  |  | (In thousands, except per share data) |  |
| Net sales |  | $ | 30,777 |  |  | $ | 143,951 |  |
| Cost of goods sold |  |  | 28,375 |  |  |  | 136,800 |  |
| Gross profit |  |  | 2,402 |  |  |  | 7,151 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |
| Selling and marketing |  |  | 285 |  |  |  | 1,461 |  |
| General and administrative |  |  | 1,007 |  |  |  | 2,317 |  |
| Research and development |  |  | — |  |  |  | 147 |  |
| Amortization of definite-lived intangibles |  |  | 134 |  |  |  | 809 |  |
| Total operating expenses |  |  | 1,426 |  |  |  | 4,734 |  |
| Operating income |  |  | 976 |  |  |  | 2,417 |  |
| Other (expense) income: |  |  |  |  |  |  |  |  |
| Interest expense |  |  | — |  |  |  | (223 | ) |
| Gain on sale of the Mobility business unit |  |  | 237,820 |  |  |  | 237,820 |  |
| Other, net |  |  | (411 | ) |  |  | 1,160 |  |
| Total other income, net |  |  | 237,409 |  |  |  | 238,757 |  |
| Income from discontinued operations before income taxes |  |  | 238,385 |  |  |  | 241,174 |  |
| Income tax provision |  |  | (65,964 | ) |  |  | (66,707 | ) |
| Income from discontinued operations, net of income taxes |  | $ | 172,421 |  |  | $ | 174,467 |  |
| Earnings per share from discontinued operations: |  |  |  |  |  |  |  |  |
| Basic earnings per share |  | $ | 1.62 |  |  | $ | 1.64 |  |
| Diluted earnings per share |  | $ | 1.60 |  |  | $ | 1.62 |  |

[0001564590-21-040796:notes:21]
Depreciation expense related to the discontinued operations for the quarter and two quarters ended June 29, 2020 was $3,117 and $21,382, respectively.

[0001564590-21-040796:notes:22]
During the quarter and two quarters ended June 29, 2020, the Company’s income tax expense related to the discontinued operations was impacted by a net discrete expense of $65,774. As a result of the sale of the Mobility business unit, the discrete income tax expense is related mainly to (i) China withholding tax related to gain on sale, (ii) U.S. income tax related to Global Intangible Low Taxed Income (GILTI) inclusion net of IRC Section 250 deduction and foreign tax credits, and offset by (iii) release of U.S. FIN 48 uncertain tax positions.

[0001564590-21-040796:notes:23]
Proceeds from the sale of the Company’s Mobility business unit have been presented in the consolidated condensed statements of cash flows within net cash provided by investing activities from discontinued operations. The following is a reconciliation of the final gain recorded for the sale of the Company’s Mobility business unit (in thousands):

[0001564590-21-040796:notes:24]
| Net proceeds from the sale of the Mobility business unit (1) |  | $ | 569,246 |  |
| Mobility business unit assets: |  |  |  |  |
| Cash and cash equivalents |  |  | 12,513 |  |
| Restricted cash |  |  | 35,412 |  |
| Accounts receivable, net |  |  | 12 |  |
| Contract assets |  |  | 40,072 |  |
| Inventories |  |  | 4,988 |  |
| Prepaid expenses and other current assets |  |  | 4,593 |  |
| Property, plant and equipment, net |  |  | 328,648 |  |
| Goodwill |  |  | 68,267 |  |
| Definite-lived intangibles, net |  |  | 5,520 |  |
| Deposits and other non-current assets |  |  | 6,291 |  |
| Total Mobility business unit assets |  |  | 506,316 |  |
| Mobility business unit liabilities: |  |  |  |  |
| Accounts payable |  |  | 142,636 |  |
| Accrued salaries, wages and benefits |  |  | 9,392 |  |
| Other current liabilities |  |  | 8,890 |  |
| Other long-term liabilities |  |  | 303 |  |
| Total Mobility business unit liabilities |  |  | 161,221 |  |
| Derecognition of foreign currency translation adjustments and unrealized losses on cash flow hedges recorded in accumulated other comprehensive loss |  |  | 26,957 |  |
| Other transaction costs incurred as part of the sale of the Mobility business unit (2) |  |  | 13,855 |  |
| Gain on sale of the Mobility business unit before income taxes |  | $ | 237,253 |  |

[0001564590-21-040796:notes:25]
| (1) | Net proceeds from the sale of the Mobility business unit are net of customary purchase price adjustments. |

[0001564590-21-040796:notes:26]
| (2) | Costs directly incurred as a result of the sale of the Company’s Mobility business unit, including bank fees, legal fees, professional fees, and other costs. |


## us-gaap:ScheduleOfDisposalGroupsIncludingDiscontinuedOperationsIncomeStatementBalanceSheetAndAdditionalDisclosuresTextBlock

[0001564590-21-040796:notes:27]
The following is a reconciliation of the final gain recorded for the sale of the Company’s Mobility business unit (in thousands):


## us-gaap:LesseeOperatingLeasesTextBlock

[0001564590-21-040796:notes:28]
[same as prior period, unchanged from 0001564590-21-024040:notes:21]

[0001564590-21-040796:notes:29]
The Company leases some of its manufacturing and assembly plants, sales offices and equipment under non-cancellable operating leases that expire at various dates through 2049. The majority of the Company’s lease arrangements are comprised of fixed payments and certain leases consist of variable payments based on equipment usage. These variable payments are not included in the measurement of the right-of-use (ROU) asset or lease liability due to uncertainty of the payment amount and are recorded as lease expense in the period incurred. Certain leases contain renewal provisions at the Company’s option. Most of the leases require the Company to pay for certain other costs such as property taxes and maintenance. Certain leases also contain rent escalation clauses (step rents) that require additional rental amounts in the later years of the term. Rent expense for leases with step rents is recognized on a straight-line basis over the minimum lease term. The lease agreements do not contain any material residual value guarantees or material restrictive covenants.

[0001564590-21-040796:notes:30]
[same as prior period, unchanged from 0001564590-21-024040:notes:23]

[0001564590-21-040796:notes:31]
|  |  | Quarter Ended |  |  | Two Quarters Ended |  |
|  |  | June 28, 2021 |  |  | June 29, 2020 |  |  | June 28, 2021 |  |  | June 29, 2020 |  |
|  |  | (In thousands) |  |
| Operating lease cost |  | $ | 1,924 |  |  | $ | 2,227 |  |  | $ | 4,132 |  |  | $ | 4,708 |  |
| Variable lease cost |  |  | 140 |  |  |  | 137 |  |  |  | 374 |  |  |  | 243 |  |
| Short-term lease cost |  |  | 55 |  |  |  | 169 |  |  |  | 109 |  |  |  | 398 |  |

[0001564590-21-040796:notes:32]
[same as prior period, unchanged from 0001564590-21-024040:notes:25]

[0001564590-21-040796:notes:33]
|  |  | Two Quarters Ended |  |
|  |  | June 28, 2021 |  |  | June 29, 2020 |  |
|  |  | (In thousands) |  |
| Cash paid for amounts included in the measurement of lease liabilities: |  |  |  |  |  |  |  |  |
| Operating cash flows from operating leases |  | $ | 4,104 |  |  | $ | 4,342 |  |
| Right-of-use assets obtained in exchange for new lease obligations: |  |  |  |  |  |  |  |  |
| Operating leases |  |  | 802 |  |  |  | 3,205 |  |

[0001564590-21-040796:notes:34]
[same as prior period, unchanged from 0001564590-21-024040:notes:27]

[0001564590-21-040796:notes:35]
|  |  | As of |  |
|  |  | June 28, 2021 |  |  | December 28, 2020 |  |
|  |  | (In thousands) |  |
| Operating lease right-of-use assets |  | $ | 20,134 |  |  | $ | 24,340 |  |
| Other current liabilities |  |  | 6,190 |  |  |  | 8,144 |  |
| Operating lease liabilities |  |  | 14,836 |  |  |  | 17,211 |  |
| Total operating lease liabilities |  | $ | 21,026 |  |  | $ | 25,355 |  |

[0001564590-21-040796:notes:36]
|  |  | As of |  |
|  |  | June 28, 2021 |  |  | December 28, 2020 |  |
| Weighted average remaining lease term |  | 4.2 years |  |  | 4.2 years |  |
| Weighted average discount rate |  |  | 3.25 | % |  |  | 3.31 | % |

[0001564590-21-040796:notes:37]
[same as prior period, unchanged from 0001564590-21-024040:notes:30]

[0001564590-21-040796:notes:38]
|  |  | (In thousands) |  |
| Less than one year |  | $ | 6,750 |  |
| 1 - 2 years |  |  | 5,081 |  |
| 2 - 3 years |  |  | 4,180 |  |
| 3 - 4 years |  |  | 3,157 |  |
| 4 - 5 years |  |  | 1,888 |  |
| Thereafter |  |  | 1,477 |  |
| Total lease payments |  |  | 22,533 |  |
| Less imputed interest |  |  | (1,507 | ) |
| Total |  | $ | 21,026 |  |

[0001564590-21-040796:notes:39]
[same as prior period, unchanged from 0001564590-21-024040:notes:32]


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0001564590-21-040796:notes:40]
[same as prior period, unchanged from 0001564590-21-024040:notes:33]

[0001564590-21-040796:notes:41]
As of June 28, 2021, the aggregate amount of the transaction price allocated to remaining performance obligations for long-term contracts was $11,905. The Company expects to recognize revenue on approximately 82% of the remaining performance obligations for the Company’s long-term contracts over the next twelve months.

[0001564590-21-040796:notes:42]
Revenue from products and services transferred to customers over time and at a point in time accounted for 98% and 2%, respectively, of the Company’s revenue for both quarter and two quarters ended June 28, 2021 and June 29, 2020.

[0001564590-21-040796:notes:43]
[same as prior period, unchanged from 0001564590-21-024040:notes:36]

[0001564590-21-040796:notes:44]
|  |  | Quarter Ended June 28, 2021 |  |  | Quarter Ended June 29, 2020 |  |  |
|  |  | PCB |  |  | RF&S Components |  |  | Total |  |  | PCB |  |  | RF&S Components |  |  | Other (1) |  |  | Total |  |  |
| End Markets |  | (In thousands) |  |  |
| Aerospace and Defense |  | $ | 185,152 |  |  | $ | 6 |  |  | $ | 185,158 |  |  | $ | 188,910 |  |  | $ | 9 |  |  | $ | 20 |  |  | $ | 188,939 |  |  |
| Automotive |  |  | 102,893 |  |  |  | — |  |  |  | 102,893 |  |  |  | 57,998 |  |  |  | — |  |  |  | 11,583 |  |  |  | 69,581 |  |  |
| Data Center Computing (2) |  |  | 82,230 |  |  |  | 24 |  |  |  | 82,254 |  |  |  | 71,541 |  |  |  | 273 |  |  |  | 36 |  |  |  | 71,850 |  |  |
| Medical/Industrial/Instrumentation |  |  | 104,012 |  |  |  | 1,067 |  |  |  | 105,079 |  |  |  | 115,813 |  |  |  | 800 |  |  |  | 2,988 |  |  |  | 119,601 |  |  |
| Networking/Communications |  |  | 75,728 |  |  |  | 11,950 |  |  |  | 87,678 |  |  |  | 95,416 |  |  |  | 10,560 |  |  |  | 7,446 |  |  |  | 113,422 |  |  |
| Other |  |  | 3,465 |  |  |  | 856 |  |  |  | 4,321 |  |  |  | 7,165 |  |  |  | 449 |  |  |  | (709 | ) |  |  | 6,905 |  |  |
| Total |  | $ | 553,480 |  |  | $ | 13,903 |  |  | $ | 567,383 |  |  | $ | 536,843 |  |  | $ | 12,091 |  |  | $ | 21,364 |  |  | $ | 570,298 |  |  |

[0001564590-21-040796:notes:45]
|  |  | Two Quarters Ended June 28, 2021 |  |  | Two Quarters Ended June 29, 2020 |  |  |
|  |  | PCB |  |  | RF&S Components |  |  | Other (1) |  |  | Total |  |  | PCB |  |  | RF&S Components |  |  | Other (1) |  |  | Total |  |  |
| End Markets |  | (In thousands) |  |  |
| Aerospace and Defense |  | $ | 371,691 |  |  |  | 12 |  |  | $ | — |  |  | $ | 371,703 |  |  | $ | 373,324 |  |  | $ | 9 |  |  | $ | 20 |  |  | $ | 373,353 |  |  |
| Automotive |  |  | 194,685 |  |  |  | — |  |  |  | 3,642 |  |  |  | 198,327 |  |  |  | 119,856 |  |  |  | — |  |  |  | 18,596 |  |  |  | 138,452 |  |  |
| Cellular Phone |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 1,296 |  |  |  | — |  |  |  | — |  |  |  | 1,296 |  |  |
| Data Center Computing (2) |  |  | 153,989 |  |  |  | 456 |  |  |  | — |  |  |  | 154,445 |  |  |  | 129,655 |  |  |  | 476 |  |  |  | 90 |  |  |  | 130,221 |  |  |
| Medical/Industrial/Instrumentation |  |  | 194,782 |  |  |  | 2,148 |  |  |  | 25 |  |  |  | 196,955 |  |  |  | 206,281 |  |  |  | 1,594 |  |  |  | 6,308 |  |  |  | 214,183 |  |  |
| Networking/Communications |  |  | 142,666 |  |  |  | 22,603 |  |  |  | 1 |  |  |  | 165,270 |  |  |  | 165,849 |  |  |  | 18,627 |  |  |  | 11,641 |  |  |  | 196,117 |  |  |
| Other |  |  | 6,153 |  |  |  | 1,374 |  |  |  | (412 | ) |  |  | 7,115 |  |  |  | 14,584 |  |  |  | 826 |  |  |  | (1,088 | ) |  |  | 14,322 |  |  |
| Total |  | $ | 1,063,966 |  |  | $ | 26,593 |  |  | $ | 3,256 |  |  | $ | 1,093,815 |  |  | $ | 1,010,845 |  |  | $ | 21,532 |  |  | $ | 35,567 |  |  | $ | 1,067,944 |  |  |

[0001564590-21-040796:notes:46]
[same as prior period, unchanged from 0001564590-21-024040:notes:39]

[0001564590-21-040796:notes:47]
| (2) | Beginning in the first quarter of 2021, the Computing/Storage/Peripherals end market was renamed to Data Center Computing to better reflect the customer mix and growth prospects. There was no change to the customers included in this end market. |


## us-gaap:AdditionalFinancialInformationDisclosureTextBlock

[0001564590-21-040796:notes:48]
[same as prior period, unchanged from 0001564590-21-024040:notes:41]

[0001564590-21-040796:notes:49]
|  |  | As of |  |
|  |  | June 28, 2021 |  |  | December 28, 2020 |  |
|  |  | (In thousands) |  |
| Inventories: |  |  |  |  |  |  |  |  |
| Raw materials |  | $ | 113,546 |  |  | $ | 103,890 |  |
| Work-in-process |  |  | 9,265 |  |  |  | 7,841 |  |
| Finished goods |  |  | 3,544 |  |  |  | 3,920 |  |
|  |  | $ | 126,355 |  |  | $ | 115,651 |  |
| Property, plant and equipment, net: |  |  |  |  |  |  |  |  |
| Land and land use rights |  | $ | 62,061 |  |  | $ | 61,781 |  |
| Buildings and improvements |  |  | 404,802 |  |  |  | 398,540 |  |
| Machinery and equipment |  |  | 855,892 |  |  |  | 832,723 |  |
| Furniture and fixtures and other |  |  | 10,218 |  |  |  | 10,304 |  |
| Construction-in-progress |  |  | 36,177 |  |  |  | 33,191 |  |
|  |  |  | 1,369,150 |  |  |  | 1,336,539 |  |
| Less: Accumulated depreciation |  |  | (718,386 | ) |  |  | (686,104 | ) |
|  |  | $ | 650,764 |  |  | $ | 650,435 |  |
| Other current liabilities: |  |  |  |  |  |  |  |  |
| Sales returns and allowances |  | $ | 13,623 |  |  | $ | 13,015 |  |
| Income taxes payable |  |  | 10,108 |  |  |  | 2,428 |  |
| Derivative liabilities |  |  | 10,000 |  |  |  | — |  |
| Interest |  |  | 7,996 |  |  |  | 7,157 |  |
| Operating lease |  |  | 6,190 |  |  |  | 8,144 |  |
| Restructuring |  |  | 97 |  |  |  | 7,382 |  |
| Other |  |  | 52,901 |  |  |  | 51,296 |  |
|  |  | $ | 100,915 |  |  | $ | 89,422 |  |
| Other long-term liabilities: |  |  |  |  |  |  |  |  |
| Deferred income taxes |  | $ | 24,043 |  |  | $ | 23,704 |  |
| Defined benefit pension plan liability |  |  | 9,313 |  |  |  | 9,986 |  |
| Derivative liabilities |  |  | — |  |  |  | 14,968 |  |
| Other |  |  | 25,900 |  |  |  | 25,167 |  |
|  |  | $ | 59,256 |  |  | $ | 73,825 |  |


## us-gaap:GoodwillDisclosureTextBlock

[0001564590-21-040796:notes:50]
[same as prior period, unchanged from 0001564590-21-024040:notes:43]

[0001564590-21-040796:notes:51]
As of June 28, 2021 and December 28, 2020, goodwill by reportable segment was as follows:

[0001564590-21-040796:notes:52]
|  |  | PCB |  | RF&S Components |  | Total |  |
|  |  | (In thousands) |  |
| Balance as of December 28, 2020 and June 28, 2021 |  |  |  |  |  |  |  |  |  |  |
| Goodwill |  | $ | 700,724 |  | $ | 177,200 |  | $ | 877,924 |  |
| Accumulated impairment losses |  |  | (171,400 | ) |  | (69,200 | ) |  | (240,600 | ) |
|  |  | $ | 529,324 |  | $ | 108,000 |  | $ | 637,324 |  |


## us-gaap:IntangibleAssetsDisclosureTextBlock

[0001564590-21-040796:notes:53]
[same as prior period, unchanged from 0001564590-21-024040:notes:46]

[0001564590-21-040796:notes:54]
As of June 28, 2021 and December 28, 2020, the components of definite-lived intangibles were as follows:

[0001564590-21-040796:notes:55]
|  |  | Gross Amount |  |  | Accumulated Amortization |  |  | Net Carrying Amount |  |  | Weighted Average Amortization Period |  |
|  |  | (In thousands) |  |  | (In years) |  |
| June 28, 2021 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Customer relationships |  | $ | 397,500 |  |  | $ | (168,705 | ) |  | $ | 228,795 |  |  |  | 10.9 |  |
| Technology |  |  | 47,650 |  |  |  | (16,468 | ) |  |  | 31,182 |  |  |  | 9.5 |  |
|  |  | $ | 445,150 |  |  | $ | (185,173 | ) |  | $ | 259,977 |  |  |  |  |  |
| December 28, 2020 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Customer relationships |  | $ | 397,500 |  |  | $ | (150,142 | ) |  | $ | 247,358 |  |  |  | 10.9 |  |
| Technology |  |  | 47,650 |  |  |  | (13,701 | ) |  |  | 33,949 |  |  |  | 9.5 |  |
|  |  | $ | 445,150 |  |  | $ | (163,843 | ) |  | $ | 281,307 |  |  |  |  |  |

[0001564590-21-040796:notes:56]
Definite-lived intangibles are amortized using the straight-line method of amortization over the useful life. Amortization expense was $10,425 and $10,945 for the quarters ended June 28, 2021 and June 29, 2020, respectively, and $21,330 and $21,890 for the two quarters ended June 28, 2021 and June 29, 2020, respectively. For the quarter and two quarters ended June 28, 2021, $1,383 and $2,767, respectively, of amortization expense is included in cost of goods sold. For the quarter and two quarters ended June 29, 2020, $1,384 and $2,767, respectively, of amortization expense is included in cost of goods sold.

[0001564590-21-040796:notes:57]
[same as prior period, unchanged from 0001564590-21-024040:notes:50]

[0001564590-21-040796:notes:58]
|  |  | (In thousands) |  |
| Remaining 2021 |  | $ | 19,849 |  |
| 2022 |  |  | 38,631 |  |
| 2023 |  |  | 36,713 |  |
| 2024 |  |  | 29,713 |  |
| 2025 |  |  | 25,397 |  |
| Thereafter |  |  | 109,674 |  |
|  |  | $ | 259,977 |  |


## us-gaap:LongTermDebtTextBlock

[0001564590-21-040796:notes:59]
(8) Long-term Debt and Letters of Credit

[0001564590-21-040796:notes:60]
The following table summarizes the long-term debt of the Company as of June 28, 2021 and December 28, 2020:

[0001564590-21-040796:notes:61]
|  |  | Interest Rate as of June 28, 2021 |  |  | Principal Outstanding as of June 28, 2021 |  |  | Interest Rate as of December 28, 2020 |  |  | Principal Outstanding as of December 28, 2020 |  |
|  |  | (In thousands) |  |
| Senior Notes due March 2029 |  |  | 4.00 |  | % | $ | 500,000 |  |  |  | — |  | % | $ | — |  |
| Term Loan due September 2024 |  |  | 2.60 |  |  |  | 405,879 |  |  |  | 2.65 |  |  |  | 405,879 |  |
| Senior Notes due October 2025 |  |  | — |  |  |  | — |  |  |  | 5.63 |  |  |  | 375,000 |  |
| U.S. ABL Revolving Loan due June 2024 |  |  | — |  |  |  | — |  |  |  | 1.40 |  |  |  | 40,000 |  |
| Asia ABL Revolving Loan due June 2024 |  |  | 1.50 |  |  |  | 30,000 |  |  |  | 1.55 |  |  |  | 30,000 |  |
|  |  |  |  |  |  |  | 935,879 |  |  |  |  |  |  |  | 850,879 |  |
| Less: Long-term debt unamortized discount |  |  |  |  |  |  | (712 | ) |  |  |  |  |  |  | (814 | ) |
| Long-term debt unamortized debt issuance costs |  |  |  |  |  |  | (8,644 | ) |  |  |  |  |  |  | (7,212 | ) |
|  |  |  |  |  |  |  | 926,523 |  |  |  |  |  |  |  | 842,853 |  |
| Less: current maturities |  |  |  |  |  |  | — |  |  |  |  |  |  |  | — |  |
| Long-term debt, less current maturities |  |  |  |  |  | $ | 926,523 |  |  |  |  |  |  | $ | 842,853 |  |

[0001564590-21-040796:notes:62]
Pursuant to the Term Loan Credit Agreement, the Company may reinvest the cash proceeds received from the sale of the Mobility business unit for a period of twelve months commencing September 3, 2020. If the proceeds are not reinvested during that time, the Company is required to use the proceeds to prepay the Term Loan. The Company used a portion of the cash proceeds to

[0001564590-21-040796:notes:63]
repay $400,000 of the Term Loan during the year ended December 28, 2020 and used the remaining cash proceeds for reinvestment pursuant to the Term Loan Credit Agreement. Permitted investments, as defined in the Term Loan Credit Agreement, include extensions of trade credit in the ordinary course of business, investments in cash and cash equivalents, permitted acquisitions, investments in assets useful in the business of the Company and its restricted subsidiaries, investments in joint ventures and unrestricted subsidiaries among others.

[0001564590-21-040796:notes:64]
Senior Notes due 2029

[0001564590-21-040796:notes:65]
On March 10, 2021, the Company issued $500,000 of Senior Notes due 2029, which are included in long-term debt and bear interest at a rate of 4.0% per annum. Interest is payable semiannually in arrears on March 1 and September 1 of each year beginning September 1, 2021. The Senior Notes due 2029 will mature on March 1, 2029.

[0001564590-21-040796:notes:66]
The Company used a portion of the net proceeds from the issuance of the Senior Notes due 2029 during the quarter ended March 29, 2021 to: (i) fund the early retirement of $375,000 Senior Notes due 2025, (ii) fund the repayment of $40,000 outstanding under the U.S. Asset-Based Lending Credit Agreement (U.S. ABL) Revolving credit facility (but not terminate the commitments thereunder), and (iii) pay related premiums, fees and expenses. The Company intends to use the remaining net proceeds for general corporate purposes.

[0001564590-21-040796:notes:67]
Asset-Based Lending Agreements

[0001564590-21-040796:notes:68]
As of June 28, 2021, letters of credit in the amount of $12,201 were outstanding under the U.S. ABL and $3,475 were outstanding under the Asia Asset-Based Lending Credit Agreement (Asia ABL) with various expiration dates through July 2021. Available borrowing capacity under the U.S. ABL and the Asia ABL was $137,799 and $116,525, respectively, which considers letters of credit outstanding as of June 28, 2021.

[0001564590-21-040796:notes:69]
Debt Covenants

[0001564590-21-040796:notes:70]
Borrowings under the Term Loan and Senior Notes due 2029 are subject to certain affirmative and negative covenants, including limitations on indebtedness, corporate transactions, investments, dispositions, and share payments.

[0001564590-21-040796:notes:71]
Under the occurrence of certain events, the U.S. ABL and Asia ABL (collectively, the ABL Revolving Loans), are subject to various financial covenants, including leverage and fixed charge coverage ratios.

[0001564590-21-040796:notes:72]
Debt Issuance and Debt Discount

[0001564590-21-040796:notes:73]
As of June 28, 2021 and December 28, 2020, remaining unamortized debt discount and debt issuance costs for the Senior Notes due 2029, Term Loan Facility and Senior Notes due 2025 are as follows:

[0001564590-21-040796:notes:74]
|  |  | As of June 28, 2021 |  |  | As of December 28, 2020 |
|  |  | Debt Issuance Costs |  |  | Debt Discount |  |  | Effective Interest Rate |  |  | Debt Issuance Costs |  |  | Debt Discount |  |  | Effective Interest Rate |  |  |
|  |  | (In thousands, except interest rates) |
| Senior Notes due March 2029 |  | $ | 6,289 |  |  | $ | — |  |  |  | 4.19 |  | % | $ | — |  |  | $ | — |  |  |  | — |  | % |
| Term Loan due September 2024 |  |  | 2,355 |  |  |  | 712 |  |  |  | 4.66 |  |  |  | 2,695 |  |  |  | 814 |  |  |  | 4.66 |  |  |
| Senior Notes due October 2025 |  | — |  |  | — |  |  |  | — |  |  |  | 4,517 |  |  | — |  |  |  | 5.92 |  |  |
|  |  | $ | 8,644 |  |  | $ | 712 |  |  |  |  |  |  | $ | 7,212 |  |  | $ | 814 |  |  |  |  |  |  |

[0001564590-21-040796:notes:75]
The above debt discount and debt issuance costs are recorded as a reduction of the debt and are amortized into interest expense using an effective interest rate over the duration of the debt.

[0001564590-21-040796:notes:76]
Remaining unamortized debt issuance costs for the ABL Revolving Loans of $1,637 and $1,919 as of June 28, 2021 and December 28, 2020, respectively, are included in other non-current assets and are amortized to interest expense over the duration of the ABL Revolving Loans using the straight-line method of amortization.

[0001564590-21-040796:notes:77]
As of June 28, 2021, the remaining weighted average amortization period for all unamortized debt discount and debt issuance costs was 5.7 years.

[0001564590-21-040796:notes:78]
Loss on Extinguishment of Debt

[0001564590-21-040796:notes:79]
During the two quarters ended June 28, 2021, the Company recognized losses of $15,217 associated with the premium paid on extinguishment of debt and the write-off of the remaining unamortized debt issuance costs as a result of the repayment of the remaining outstanding balance of the Senior Notes due 2025.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001564590-21-040796:notes:80]
[same as prior period, unchanged from 0001564590-21-024040:notes:73]

[0001564590-21-040796:notes:81]
[same as prior period, unchanged from 0001564590-21-024040:notes:74]

[0001564590-21-040796:notes:82]
During the quarter and two quarters ended June 28, 2021, the Company’s effective tax rate was impacted by a net discrete benefit of $1,843 and $2,226, respectively. This is related mainly to (i) the release of uncertain tax positions due to the expiration of the statute of limitation in foreign jurisdictions, (ii) stock based compensation releases, (iii) the approval of the Company’s renewal application for High and New Tax Enterprise status for two of the Company’s manufacturing subsidiaries in China (including the impact on the respective Company’s deferred tax amounts), and (iv) accrued interest for existing uncertain tax positions.

[0001564590-21-040796:notes:83]
[same as prior period, unchanged from 0001564590-21-024040:notes:76]


## us-gaap:FinancialInstrumentsDisclosureTextBlock

[0001564590-21-040796:notes:84]
[same as prior period, unchanged from 0001564590-21-024040:notes:77]

[0001564590-21-040796:notes:85]
[same as prior period, unchanged from 0001564590-21-024040:notes:78]

[0001564590-21-040796:notes:86]
[same as prior period, unchanged from 0001564590-21-024040:notes:79]

[0001564590-21-040796:notes:87]
[same as prior period, unchanged from 0001564590-21-024040:notes:80]

[0001564590-21-040796:notes:88]
[same as prior period, unchanged from 0001564590-21-024040:notes:81]

[0001564590-21-040796:notes:89]
At inception, the Company designated the interest rate swap as a cash flow hedge and the fair value of the interest rate swap was zero. As of June 28, 2021, the fair value of the interest rate swap was recorded as a liability in the amount of $10,000 and included as a component of other current liabilities. The change in the fair value of the interest rate swap is recorded as a component of accumulated other comprehensive loss, net of tax. No ineffectiveness was recognized for the quarter and two quarters ended June 28, 2021 and June 29, 2020. The interest rate swap increased interest expense by $2,763 and $2,342 for the quarters ended June 28, 2021 and June 29, 2020, respectively, and $5,503 and $3,517 for the two quarters ended June 28, 2021 and June 29, 2020, respectively.

[0001564590-21-040796:notes:90]
[same as prior period, unchanged from 0001564590-21-024040:notes:83]

[0001564590-21-040796:notes:91]
The Company enters into foreign currency forward contracts to mitigate the impact of changes in foreign currency exchange rates and to reduce the volatility of purchases and other obligations generated in currencies other than its functional currencies. The Company’s foreign subsidiaries may at times purchase forward exchange contracts to manage their foreign currency risks in relation to certain purchases of machinery denominated in foreign currencies other than the Company’s functional currencies. The notional amount of the foreign exchange contracts as of June 28, 2021 and December 28, 2020 was approximately $1,245 (Japanese Yen (JPY) 132.3 million) and $1,181 (JPY 125.0 million), respectively. The Company has designated certain of these foreign exchange contracts as cash flow hedges.

[0001564590-21-040796:notes:92]
Commodity Price Risk Management

[0001564590-21-040796:notes:93]
The Company uses copper in the manufacturing of PCBs. In order to reduce the impact of volatility of copper prices, the Company enters into commodity contracts. As of June 28, 2021, the Company has commodity contracts with a notional quantity of 0.5 metric tonnes each for the periods (i) beginning June 29, 2021 and ending on September 23, 2021, (ii) beginning September 28, 2021 and ending on December 30, 2021, (iii) beginning January 4, 2022 and ending on March 31, 2022, and (iv) beginning April 5, 2022 and ending on June 29, 2022. As of June 28, 2021, the fair value of the commodity contracts was recorded as an asset in the amount of $99 and included as a component of prepaid expenses and other current assets. The changes in the fair value of these commodity contracts are recorded in cost of goods sold in the consolidated condensed statements of operations. The commodity contracts decreased cost of goods sold by $99 for both the quarter and two quarters ended June 28, 2021. These commodity contracts are not designated as accounting hedges.

[0001564590-21-040796:notes:94]
[same as prior period, unchanged from 0001564590-21-024040:notes:85]

[0001564590-21-040796:notes:95]
|  |  |  |  | Asset/(Liability) Fair Value |  |
|  |  | Balance Sheet Location |  | June 28, 2021 |  |  | December 28, 2020 |  |
|  |  |  |  | (In thousands) |  |
| Cash flow derivative instruments designated as hedges: |  |  |  |  |  |  |  |  |
| Interest rate swap |  | Other current liabilities |  | $ | (10,000 | ) |  | $ | — |  |
| Interest rate swap |  | Other long-term liabilities |  |  | — |  |  |  | (14,968 | ) |
| Foreign exchange contracts |  | Other current liabilities |  |  | (47 | ) |  |  | — |  |
| Cash flow derivative instruments not designated as hedges: |  |  |  |  |  |  |  |  |
| Foreign exchange contracts |  | Prepaid expenses and other current assets |  |  | — |  |  |  | 28 |  |
| Commodity contracts |  | Prepaid expenses and other current assets |  |  | 99 |  |  |  | — |  |

[0001564590-21-040796:notes:96]
The following table provides information about the amounts recorded in accumulated other comprehensive loss related to derivatives designated as cash flow hedges, as well as the amounts recorded in each caption in the consolidated condensed statements of operations when derivative amounts are reclassified out of accumulated other comprehensive loss for the quarter and two quarters ended June 28, 2021 and June 29, 2020:

[0001564590-21-040796:notes:97]
|  |  |  | Quarter Ended June 28, 2021 |  |  | Quarter Ended June 29, 2020 |  |  |
|  |  | Financial Statement Caption | Loss Recognized in Other Comprehensive Loss |  |  | Loss Reclassified into Income |  |  | Loss Recognized in Other Comprehensive Loss |  |  | Loss Reclassified into Income |  |  |
|  |  |  | (In thousands) |
| Cash flow hedge: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Interest rate swap |  | Interest expense | $ | (184 | ) |  | $ | (2,763 | ) |  | $ | (2,583 | ) |  | $ | (2,342 | ) |  |

[0001564590-21-040796:notes:98]
|  |  |  | Two Quarters Ended June 28, 2021 |  |  | Two Quarters Ended June 29, 2020 |  |  |
|  |  | Financial Statement Caption | Loss Recognized in Other Comprehensive Loss |  |  | Loss Reclassified into Income |  |  | Loss Recognized in Other Comprehensive Loss |  |  | Loss Reclassified into Income |  |  |
|  |  |  | (In thousands) |
| Cash flow hedge: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Interest rate swap |  | Interest expense | $ | (535 | ) |  | $ | (5,503 | ) |  | $ | (11,032 | ) |  | $ | (3,517 | ) |  |

[0001564590-21-040796:notes:99]
The following table provides a summary of the activity associated with the designated cash flow hedges reflected in accumulated other comprehensive loss for the two quarters ended June 28, 2021 and June 29, 2020:

[0001564590-21-040796:notes:100]
|  |  | Two Quarters Ended |
|  |  | June 28, |  |  | June 29, |  |  |
|  |  | 2021 |  |  | 2020 |  |  |
|  |  | (In thousands) |
| Beginning balance, net of tax |  | $ | (11,231 | ) |  | $ | (9,617 | ) |  |
| Changes in fair value loss, net of tax |  |  | (203 | ) |  |  | (8,012 | ) |  |
| Reclassification to earnings |  |  | 3,984 |  |  |  | 2,629 |  |  |
| Derecognition of unrealized losses on cash flow hedge due to sale of Mobility business unit |  |  | — |  |  |  | 384 |  |  |
| Ending balance, net of tax |  | $ | (7,450 | ) |  | $ | (14,616 | ) |  |

[0001564590-21-040796:notes:101]
Based on the current yield curve, the Company expects that losses of approximately $8,068 of the accumulated other comprehensive loss will be reclassified into the statement of operations, net of tax, in the next twelve months.


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0001564590-21-040796:notes:102]
[same as prior period, unchanged from 0001564590-21-024040:notes:92]

[0001564590-21-040796:notes:103]
The following provides a summary of the components of accumulated other comprehensive loss, net of tax, as of June 28, 2021 and December 28, 2020:

[0001564590-21-040796:notes:104]
|  |  | Foreign Currency Translation |  |  | Pension Obligation |  |  | (Losses) Gains on Cash Flow Hedges |  |  | Total |  |
|  |  | (In thousands) |  |
| Ending balance as of December 28, 2020 |  | $ | (24,827 | ) |  | $ | (2,855 | ) |  | $ | (11,231 | ) |  | $ | (38,913 | ) |
| Other comprehensive income (loss) before reclassifications |  |  | 414 |  |  |  | 29 |  |  |  | (203 | ) |  |  | 240 |  |
| Amounts reclassified from accumulated other comprehensive loss |  |  | — |  |  |  | — |  |  |  | 3,984 |  |  |  | 3,984 |  |
| Other comprehensive income |  |  | 414 |  |  |  | 29 |  |  |  | 3,781 |  |  |  | 4,224 |  |
| Ending balance as of June 28, 2021 |  | $ | (24,413 | ) |  | $ | (2,826 | ) |  | $ | (7,450 | ) |  | $ | (34,689 | ) |


## us-gaap:ConcentrationRiskDisclosureTextBlock

[0001564590-21-040796:notes:105]
[same as prior period, unchanged from 0001564590-21-024040:notes:95]

[0001564590-21-040796:notes:106]
In the normal course of business, the Company extends credit to its customers. Some customers to whom the Company extends credit are located outside the United States. The Company performs ongoing credit evaluations of customers, does not require collateral, and considers the credit risk profile of the entity from which the receivable is due in further evaluating collection risk. As of June 28, 2021, there was one customer that accounted for 10% of the Company’s accounts receivable. There were no customers that accounted for 10% or more of accounts receivable as of December 28, 2020.

[0001564590-21-040796:notes:107]
[same as prior period, unchanged from 0001564590-21-024040:notes:97]

[0001564590-21-040796:notes:108]
There were no customers that accounted for 10% or more of net sales for the quarter ended June 28, 2021 and two quarters ended June 29, 2020. For the two quarters ended June 28, 2021 and the quarter ended June 29, 2020, there was one customer that accounted for approximately 11% of the Company’s net sales.


## us-gaap:FairValueDisclosuresTextBlock

[0001564590-21-040796:notes:109]
[same as prior period, unchanged from 0001564590-21-024040:notes:99]

[0001564590-21-040796:notes:110]
[same as prior period, unchanged from 0001564590-21-024040:notes:100]

[0001564590-21-040796:notes:111]
The carrying amount and estimated fair value of the Company’s financial instruments as of June 28, 2021 and December 28, 2020 were as follows:

[0001564590-21-040796:notes:112]
|  |  | As of |  |  | As of |  |
|  |  | June 28, 2021 |  |  | December 28, 2020 |  |
|  |  | Carrying Amount |  |  | Fair Value |  |  | Carrying Amount |  |  | Fair Value |  |
|  |  | (In thousands) |  |
| Derivative assets, current |  | $ | 99 |  |  | $ | 99 |  |  | $ | 28 |  |  | $ | 28 |  |
| Derivative liabilities, current |  |  | 10,047 |  |  |  | 10,047 |  |  |  | — |  |  |  | — |  |
| Derivative liabilities, non-current |  |  | — |  |  |  | — |  |  |  | 14,968 |  |  |  | 14,968 |  |
| Senior Notes due March 2029 |  |  | 493,711 |  |  |  | 500,920 |  |  |  | — |  |  |  | — |  |
| Term Loan due September 2024 |  |  | 402,812 |  |  |  | 405,120 |  |  |  | 402,370 |  |  |  | 407,909 |  |
| Senior Notes due October 2025 |  |  | — |  |  |  | — |  |  |  | 370,483 |  |  |  | 383,974 |  |
| ABL Revolving Loans |  |  | 30,000 |  |  |  | 30,000 |  |  |  | 70,000 |  |  |  | 70,000 |  |

[0001564590-21-040796:notes:113]
[same as prior period, unchanged from 0001564590-21-024040:notes:103]

[0001564590-21-040796:notes:114]
The fair value of the long-term debt was estimated based on quoted market prices or discounting the debt over its life using current market rates for similar debt as of June 28, 2021 and December 28, 2020, which are considered Level 2 inputs.

[0001564590-21-040796:notes:115]
As of June 28, 2021 and December 28, 2020, the Company’s other financial instruments included cash and cash equivalents, accounts receivable, and accounts payable. Due to short-term maturities, the carrying amount of these instruments approximates fair value. The Company’s cash and cash equivalents as of June 28, 2021 consisted of $319,388 held in the U.S., with the remaining $238,903 held by foreign subsidiaries.

[0001564590-21-040796:notes:116]
[same as prior period, unchanged from 0001564590-21-024040:notes:107]


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001564590-21-040796:notes:117]
(14) Commitments and Contingencies

[0001564590-21-040796:notes:118]
Legal Matters

[0001564590-21-040796:notes:119]
The Company is subject to various legal matters, which it considers normal for its business activities. While the Company currently believes that the amount of any reasonably possible loss for known matters would not be material to the Company’s financial condition, the outcome of these actions is inherently difficult to predict. In the event of an adverse outcome, the ultimate potential loss could have a material adverse effect on the Company’s financial condition or results of operations in a particular period. The Company has accrued amounts for its loss contingencies which are probable and estimable as of June 28, 2021 and December 28, 2020. However, these amounts are not material to the consolidated condensed financial statements of the Company.


## us-gaap:EarningsPerShareTextBlock

[0001564590-21-040796:notes:120]
(15) Earnings Per Share

[0001564590-21-040796:notes:121]
The following is a reconciliation of the numerator and denominator used to calculate basic earnings per share and diluted earnings per share from continuing operations for the quarter and two quarters ended June 28, 2021 and June 29, 2020:

[0001564590-21-040796:notes:122]
|  |  | Quarter Ended |  |  | Two Quarters Ended |  |
|  |  | June 28, 2021 |  |  | June 29, 2020 |  |  | June 28, 2021 |  |  | June 29, 2020 |  |
|  |  | (In thousands, except per share amounts) |  |
| Net income from continuing operations |  | $ | 28,261 |  |  | $ | 9,346 |  |  | $ | 25,069 |  |  | $ | 6,126 |  |
| Basic weighted average shares |  |  | 107,148 |  |  |  | 106,295 |  |  |  | 106,987 |  |  |  | 105,990 |  |
| Dilutive effect of performance-based restricted stock units, restricted stock units and stock options |  |  | 1,845 |  |  |  | 1,190 |  |  |  | 1,862 |  |  |  | 1,441 |  |
| Dilutive effect of outstanding warrants |  |  | 802 |  |  |  | — |  |  |  | 401 |  |  |  | — |  |
| Diluted shares |  |  | 109,795 |  |  |  | 107,485 |  |  |  | 109,250 |  |  |  | 107,431 |  |
| Earnings per share: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  | $ | 0.26 |  |  | $ | 0.09 |  |  | $ | 0.23 |  |  | $ | 0.06 |  |
| Diluted |  | $ | 0.26 |  |  | $ | 0.09 |  |  | $ | 0.23 |  |  | $ | 0.06 |  |

[0001564590-21-040796:notes:123]
PRUs, RSUs, and stock options to purchase 1,452 and 802 shares of common stock for the quarter and two quarters ended June 28, 2021, respectively, and 1,162 and 750 shares of common stock for the quarter and two quarters ended June 29, 2020, respectively, were not included in the computation of diluted earnings per share. The PRUs were not included in the computation of diluted earnings per share because the performance conditions had not been met at June 28, 2021 and June 29, 2020, and for RSUs and stock options, the options’ exercise prices or the total expected proceeds under the treasury stock method was greater than the average market price of common stock during the applicable quarter and two quarters and, as a result, the impact would be anti-dilutive.

[0001564590-21-040796:notes:124]
Outstanding warrants for the quarter and two quarters ended June 29, 2020 to purchase common stock were not included in the computation of dilutive earnings per share because the strike price of the warrants to purchase the Company’s common stock was greater than the average market price of common stock during the applicable quarter, and therefore, the effect would be anti-dilutive.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001564590-21-040796:notes:125]
[same as prior period, unchanged from 0001564590-21-024040:notes:116]

[0001564590-21-040796:notes:126]
[same as prior period, unchanged from 0001564590-21-024040:notes:117]

[0001564590-21-040796:notes:127]
|  |  | Quarter Ended |  | Two Quarters Ended |
|  |  | June 28, |  |  | June 29, |  |  |  | June 28, |  |  | June 29, |  |  |
|  |  | 2021 |  |  | 2020 |  |  |  | 2021 |  |  | 2020 |  |  |
|  |  | (In thousands) |  | (In thousands) |
| Cost of goods sold |  | $ | 861 |  |  | $ | 620 |  |  |  | $ | 2,026 |  |  | $ | 1,470 |  |  |
| Selling and marketing |  |  | 442 |  |  |  | 291 |  |  |  |  | 1,088 |  |  |  | 742 |  |  |
| General and administrative |  |  | 2,015 |  |  |  | 1,690 |  |  |  |  | 4,370 |  |  |  | 5,167 |  |  |
| Research and development |  |  | 32 |  |  |  | 46 |  |  |  |  | 75 |  |  |  | 103 |  |  |
| Stock-based compensation expense recognized |  | $ | 3,350 |  |  | $ | 2,647 |  |  |  | $ | 7,559 |  |  | $ | 7,482 |  |  |

[0001564590-21-040796:notes:128]
[same as prior period, unchanged from 0001564590-21-024040:notes:119]

[0001564590-21-040796:notes:129]
The following is a summary of total unrecognized compensation costs as of June 28, 2021:

[0001564590-21-040796:notes:130]
|  |  | Unrecognized Stock-Based Compensation Cost |  |  | Remaining Weighted Average Recognition Period |  |
|  |  | (In thousands) |  |  | (In years) |  |
| RSU awards |  | $ | 33,983 |  |  |  | 1.7 |  |
| PRU awards |  |  | 3,159 |  |  |  | 1.2 |  |
| Stock options |  |  | 90 |  |  |  | 1.0 |  |
|  |  | $ | 37,232 |  |  |  |  |  |


## us-gaap:SegmentReportingDisclosureTextBlock

[0001564590-21-040796:notes:131]
[same as prior period, unchanged from 0001564590-21-024040:notes:122]

[0001564590-21-040796:notes:132]
The reportable segments shown below are the Company’s segments for which separate financial information is available and upon which operating results are evaluated by the chief operating decision maker to assess performance and to allocate resources. In fiscal 2020, subsequent to the quarter ended June 29, 2020, RF&S Components was added as a reportable segment. As a result, the Company had three reportable segments as of December 28, 2020: PCB, RF&S Components, and E-M Solutions. On April 29, 2020, the Company announced the restructuring of its E-M Solutions business unit. In prior periods, the Company’s E-M Solutions business unit consisted of three Chinese manufacturing facilities with two being in Shanghai (SH BPA and SH E-MS) and one in Shenzhen (SZ). The Company closed the SH E-MS and SZ facilities at the end of 2020 and integrated the SH BPA facility into its PCB operations. As of March 29, 2021, E-M Solutions no longer met the criteria for segment reporting. As a result of the addition of the RF&S Components reportable segment and the restructuring of the E-M Solutions business unit, certain prior year amounts have been reclassified to conform to this new presentation.

[0001564590-21-040796:notes:133]
[same as prior period, unchanged from 0001564590-21-024040:notes:124]

[0001564590-21-040796:notes:134]
|  |  | Quarter Ended |  |  | Two Quarters Ended |  |
|  |  | June 28, 2021 |  |  | June 29, 2020 |  |  | June 28, 2021 |  |  | June 29, 2020 |  |
|  |  | (In thousands) |  |
| Net Sales: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| PCB |  | $ | 553,480 |  |  | $ | 536,843 |  |  | $ | 1,063,966 |  |  | $ | 1,010,845 |  |
| RF&S Components |  |  | 13,903 |  |  |  | 12,091 |  |  |  | 26,593 |  |  |  | 21,532 |  |
| Other (1) |  |  | — |  |  |  | 21,364 |  |  |  | 3,256 |  |  |  | 35,567 |  |
| Total net sales |  | $ | 567,383 |  |  | $ | 570,298 |  |  | $ | 1,093,815 |  |  | $ | 1,067,944 |  |
| Operating Segment Income: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| PCB |  | $ | 73,055 |  |  | $ | 77,714 |  |  | $ | 130,287 |  |  | $ | 137,952 |  |
| RF&S Components |  |  | 4,730 |  |  |  | 4,310 |  |  |  | 8,592 |  |  |  | 6,218 |  |
| Corporate and Other (1) |  |  | (26,472 | ) |  |  | (48,083 | ) |  |  | (56,861 | ) |  |  | (83,102 | ) |
| Total operating segment income |  |  | 51,313 |  |  |  | 33,941 |  |  |  | 82,018 |  |  |  | 61,068 |  |
| Amortization of definite-lived intangibles (2) |  |  | (10,425 | ) |  |  | (10,945 | ) |  |  | (21,330 | ) |  |  | (21,890 | ) |
| Total operating income |  |  | 40,888 |  |  |  | 22,996 |  |  |  | 60,688 |  |  |  | 39,178 |  |
| Total other expense |  |  | (10,773 | ) |  |  | (18,117 | ) |  |  | (34,872 | ) |  |  | (35,396 | ) |
| Income before income taxes |  | $ | 30,115 |  |  | $ | 4,879 |  |  | $ | 25,816 |  |  | $ | 3,782 |  |

[0001564590-21-040796:notes:135]
|  |  | As of |  |
|  |  | June 28, 2021 |  |  | December 28, 2020 |  |
|  |  | (In thousands) |  |
| Segment Assets: |  |  |  |  |  |  |  |  |
| PCB |  | $ | 1,619,282 |  |  | $ | 1,529,102 |  |
| RF&S Components |  |  | 218,919 |  |  |  | 227,990 |  |
| Corporate and Other (1) |  |  | 1,187,535 |  |  |  | 1,138,852 |  |
| Total assets |  | $ | 3,025,736 |  |  | $ | 2,895,944 |  |

[0001564590-21-040796:notes:136]
| (2) | Amortization of definite-lived intangibles primarily relates to the PCB and RF&S Components reportable segments. For the quarter and two quarters ended June 28, 2021, $1,383 and $2,767, respectively, of amortization expense is included in cost of goods sold. For the quarter and two quarters ended June 29, 2020, $1,384 and $2,767, respectively, of amortization expense is included in cost of goods sold. |

[0001564590-21-040796:notes:137]
The Corporate category primarily includes operating expenses that are not included in the segment operating performance measures. Corporate consists primarily of corporate governance functions such as finance, accounting, information technology and human resources personnel, as well as global sales and marketing personnel, research and development costs, and acquisition and integration costs associated with acquisitions and divestitures.

[0001564590-21-040796:notes:138]
The Company markets and sells its products in approximately 45 countries. Other than in the United States and China, the Company does not conduct business in any country in which its net sales in that country exceed 10% of the Company’s total net sales. Net sales are as follows:

[0001564590-21-040796:notes:139]
|  |  | Quarter Ended |  |  | Two Quarters Ended |  |
|  |  | June 28, 2021 |  |  | June 29, 2020 |  |  | June 28, 2021 |  |  | June 29, 2020 |  |
|  |  | (In thousands) |  |
| Net Sales: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| United States |  | $ | 260,944 |  |  | $ | 267,602 |  |  | $ | 529,411 |  |  | $ | 529,881 |  |
| China |  |  | 80,160 |  |  |  | 101,896 |  |  |  | 161,869 |  |  |  | 176,825 |  |
| Other |  |  | 226,279 |  |  |  | 200,800 |  |  |  | 402,535 |  |  |  | 361,238 |  |
| Total net sales |  | $ | 567,383 |  |  | $ | 570,298 |  |  | $ | 1,093,815 |  |  | $ | 1,067,944 |  |

[0001564590-21-040796:notes:140]
[same as prior period, unchanged from 0001564590-21-024040:notes:131]


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0001564590-21-040796:notes:141]
[same as prior period, unchanged from 0001564590-21-024040:notes:132]

[0001564590-21-040796:notes:142]
On April 29, 2020, the Company announced the restructuring of its E-M Solutions business unit. The E-M Solutions business unit consisted of three Chinese manufacturing facilities with two being in Shanghai (SH BPA and SH E-MS) and one in Shenzhen (SZ). The Company ceased operations at the SH E-MS and SZ facilities while integrating the SH BPA facility into its PCB operations. The restructuring is another step in advancing the Company’s stated strategy of increasing its focus on differentiated higher margin products that more fully leverage the Company’s early engagement capabilities and industry leading engineering-based technology solutions. The Company closed the SH E-MS and SZ facilities at the end of 2020. As of June 28, 2021, the Company has incurred approximately $19,625 of restructuring charges and $6,702 of accelerated depreciation expense since the April 29, 2020 announcement.

[0001564590-21-040796:notes:143]
In connection with the restructuring of its E-M Solutions business unit and other global realignment restructuring efforts, the Company recognized employee separation, contract termination and other costs during the quarter and two quarters ended June 28, 2021 and June 29, 2020. Contract termination and other costs primarily represented plant closure costs.

[0001564590-21-040796:notes:144]
The table below summarizes such restructuring costs by reportable segment, which are included as a component of general and administrative expenses in the consolidated condensed statements of operations, for the quarter and two quarters ended June 28, 2021 and June 29, 2020:

[0001564590-21-040796:notes:145]
|  |  | Quarter Ended June 28, 2021 |  |  | Two Quarters Ended June 28, 2021 |  |  |
|  |  | Employee Separation/ Severance |  |  | Contract Termination and Other Costs |  |  | Total |  |  | Employee Separation/ Severance |  |  | Contract Termination and Other Costs |  |  | Total |  |  |
|  |  | (In thousands) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Reportable Segment: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| PCB |  | $ | 128 |  |  | $ | 111 |  |  | $ | 239 |  |  | $ | 470 |  |  | $ | 123 |  |  | $ | 593 |  |  |
| Corporate and Other (1) |  |  | 56 |  |  |  | 264 |  |  |  | 320 |  |  |  | 415 |  |  |  | 2,783 |  |  |  | 3,198 |  |  |
|  |  | $ | 184 |  |  | $ | 375 |  |  | $ | 559 |  |  | $ | 885 |  |  | $ | 2,906 |  |  | $ | 3,791 |  |  |

[0001564590-21-040796:notes:146]
|  |  | Quarter Ended June 29, 2020 |  |  | Two Quarters Ended June 29, 2020 |  |  |
|  |  | Employee Separation/ Severance |  |  | Contract Termination and Other Costs |  |  | Total |  |  | Employee Separation/ Severance |  |  | Contract Termination and Other Costs |  |  | Total |  |  |
|  |  | (In thousands) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Reportable Segment: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| PCB |  | $ | (8 | ) |  | $ | 1 |  |  | $ | (7 | ) |  | $ | (8 | ) |  | $ | 14 |  |  | $ | 6 |  |  |
| Corporate and Other (1) |  |  | 13,085 |  |  |  | 336 |  |  |  | 13,421 |  |  |  | 13,394 |  |  |  | 342 |  |  |  | 13,736 |  |  |
|  |  | $ | 13,077 |  |  | $ | 337 |  |  | $ | 13,414 |  |  | $ | 13,386 |  |  | $ | 356 |  |  | $ | 13,742 |  |  |

[0001564590-21-040796:notes:147]
Accrued restructuring costs are included as a component of other current liabilities in the consolidated condensed balance sheet. The table below shows the utilization of the accrued restructuring costs during the two quarters ended June 28, 2021:

[0001564590-21-040796:notes:148]
|  |  | Employee Separation/ Severance |  |  | Contract Termination and Other Costs |  |  | Total |  |
|  |  | (In thousands) |  |
| Accrued as of December 28, 2020 |  | $ | 7,063 |  |  | $ | 319 |  |  | $ | 7,382 |  |
| Charged to expense |  |  | 886 |  |  |  | 2,905 |  |  |  | 3,791 |  |
| Amount paid |  |  | (7,897 | ) |  |  | (3,179 | ) |  |  | (11,076 | ) |
| Accrued as of June 28, 2021 |  | $ | 52 |  |  | $ | 45 |  |  | $ | 97 |  |


## us-gaap:TreasuryStockTextBlock

[0001564590-21-040796:notes:149]
(19) Share Repurchase Program

[0001564590-21-040796:notes:150]
On February 3, 2021, the Company announced that its Board of Directors authorized and approved a share repurchase program. Under the program, the Company may repurchase up to $100,000 in value of the Company’s outstanding shares of common stock from time to time through February 3, 2023. The Company may repurchase shares through open market purchases, privately-negotiated transactions, or otherwise in accordance with applicable federal securities laws, including Rule 10b-18 of the Securities Exchange Act of 1934, as amended (the Exchange Act) which sets certain restrictions on the method, timing, price and volume of open market stock repurchases. In addition, the Company adopted a trading plan, which may be amended from time to time, in accordance with Rule 10b5-1 of the Exchange Act to facilitate certain purchases that may be effected under the share repurchase program. The timing, manner, price and amount of any repurchases will be determined at the Company’s discretion, and the share repurchase program may be suspended, terminated or modified at any time for any reason. The repurchase program does not obligate the Company to acquire any specific number of shares.

[0001564590-21-040796:notes:151]
During the quarter and two quarters ended June 28, 2021, the Company repurchased 411 shares of common stock for a total cost of $6,145. As of June 28, 2021, the remaining amount available to be repurchased under the Company’s share repurchase program was $93,855.
