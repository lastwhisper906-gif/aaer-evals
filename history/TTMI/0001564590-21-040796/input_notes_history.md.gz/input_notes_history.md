# TTMI note change history — 0001564590-21-024040 → 0001564590-21-040796


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2021-08-04):
[0001564590-21-040796:note_history:1]
The Company is subject to various legal matters, which it considers normal for its business activities. While the Company currently believes that the amount of any reasonably possible loss for known matters would not be material to the Company’s financial condition, the outcome of these actions is inherently difficult to predict. In the event of an adverse outcome, the ultimate potential loss could have a material adverse effect on the Company’s financial condition or results of operations in a particular period. The Company has accrued amounts for its loss contingencies which are probable and estimable as of June 28, 2021 and December 28, 2020. However, these amounts are not material to the consolidated condensed financial statements of the Company.
  (was, 2021-05-05, similarity 0.994):
[0001564590-21-024040:note_history:1]
The Company is subject to various legal matters, which it considers normal for its business activities. While the Company currently believes that the amount of any reasonably possible loss for known matters would not be material to the Company’s financial condition, the outcome of these actions is inherently difficult to predict. In the event of an adverse outcome, the ultimate potential loss could have a material adverse effect on the Company’s financial condition or results of operations in a particular period. The Company has accrued amounts for its loss contingencies which are probable and estimable as of March 29, 2021 and December 28, 2020. However, these amounts are not material to the consolidated condensed financial statements of the Company.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureAndSignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2021-08-04):
[0001564590-21-040796:note_history:2]
The accompanying consolidated condensed financial statements have been prepared by the Company, without audit, pursuant to the rules and regulations of the Securities and Exchange Commission (SEC). Certain information and disclosures normally included in financial statements prepared in accordance with accounting principles generally accepted in the United States of America (U.S. GAAP) have been condensed or omitted pursuant to such rules and regulations. It is suggested that these consolidated condensed financial statements be read in conjunction with the consolidated financial statements and the notes thereto included in the Company’s most recent Annual Report on Form 10-K. The preparation of financial statements in accordance with U.S. GAAP requires management to make estimates and assumptions that affect the amounts reported in the Company’s consolidated condensed financial statements and accompanying notes. Due to the coronavirus (COVID-19) global pandemic, the global economy and financial markets have been volatile and there is a significant amount of uncertainty about the length and severity of the consequences caused by the on-going pandemic. The Company has considered information available to it as of the date of issuance of these financial statements and is not aware of any specific events or circumstances that would require an update to its estimates or judgments, or a revision to the carrying value of its assets or liabilities. Actual results could differ materially from those estimates. The Company uses a 13-week fiscal quarter accounting period with the fourth quarter ending on the Monday nearest December 31.
  (was, 2021-05-05, similarity 0.9244):
[0001564590-21-024040:note_history:2]
The accompanying consolidated condensed financial statements have been prepared by the Company, without audit, pursuant to the rules and regulations of the Securities and Exchange Commission (SEC). Certain information and disclosures normally included in financial statements prepared in accordance with accounting principles generally accepted in the United States of America (U.S. GAAP) have been condensed or omitted pursuant to such rules and regulations. It is suggested that these consolidated condensed financial statements be read in conjunction with the consolidated financial statements and the notes thereto included in the Company’s most recent Annual Report on Form 10-K. The preparation of financial statements in accordance with U.S. GAAP requires management to make estimates and assumptions that affect the amounts reported in the Company’s consolidated condensed financial statements and accompanying notes. Due to the coronavirus (COVID-19) global pandemic, the global economy and financial markets have been disrupted and there is a significant amount of uncertainty about the length and severity of the consequences caused by the pandemic. The Company has considered information available to it as of the date of issuance of these financial statements and is not aware of any specific events or circumstances that would require an update to its estimates or judgments, or a revision to the carrying value of its assets or liabilities. Actual results could differ materially from those estimates. The Company uses a 13-week fiscal quarter accounting period with the fourth quarter ending on the Monday nearest December 31.

- changed (2021-08-04):
[0001564590-21-040796:note_history:3]
On January 19, 2020, the Company entered into a definitive equity interests purchase agreement with AKMMeadville Electronics (Xiamen) Co., Ltd (the Purchaser) for the sale of the Company’s following subsidiaries, which was completed on April 17, 2020: Shanghai Kaiser Electronics Co., Ltd. (SKE), Shanghai Meadville Electronics Co., Ltd. (SME), Shanghai Meadville Science & Technology Co., Ltd. (SP) and Guangzhou Meadville Electronics Co., Ltd. (GME) (collectively, the Mobility business unit). For all periods presented in the consolidated condensed statements of operations, all sales, costs, expenses, income taxes and gain on sale attributable to the Mobility business unit have been aggregated under the caption “Income from discontinued operations, net of income taxes”. Refer to Note 2, Discontinued Operations, for additional information.
  (was, 2021-05-05, similarity 0.9958):
[0001564590-21-024040:note_history:3]
On January 19, 2020, the Company entered into a definitive equity interests purchase agreement with AKMMeadville Electronics (Xiamen) Co., Ltd (the Purchaser) for the sale of the Company’s following subsidiaries, which was completed on April 17, 2020: Shanghai Kaiser Electronics Co., Ltd. (SKE), Shanghai Meadville Electronics Co., Ltd. (SME), Shanghai Meadville Science & Technology Co., Ltd. (SP) and Guangzhou Meadville Electronics Co., Ltd. (GME) (collectively, the Mobility business unit). For all periods presented in the consolidated condensed statements of operations, all sales, costs, expenses, income taxes and gain on sale attributable to the Mobility business unit have been aggregated under the caption “Income (loss) from discontinued operations, net of income taxes”. Refer to Note 2, Discontinued Operations, for additional information.

- changed (2021-08-04):
[0001564590-21-040796:note_history:4]
The Company currently has two reportable segments: PCB and RF and Specialty Components (RF&S Components). In fiscal 2020, subsequent to the quarter ended June 29, 2020, RF&S Components was added as a reportable segment. As a result, the Company had three reportable segments as of December 28, 2020: PCB, RF&S Components, and E-M Solutions. On April 29, 2020, the Company announced the restructuring of its E-M Solutions business unit. In prior periods, the Company’s E-M Solutions business unit consisted of three Chinese manufacturing facilities with two being in Shanghai (SH BPA and SH E-MS) and one in Shenzhen (SZ). The Company closed the SH E-MS and SZ facilities at the end of 2020 and integrated the SH BPA facility into its PCB operations. As of March 29, 2021, E-M Solutions no longer met the criteria for segment reporting. As a result of the addition of the RF&S Components reportable segment and the restructuring of the E-M Solutions business unit, certain prior year amounts have been reclassified to conform to this new presentation.
  (was, 2021-05-05, similarity 0.9936):
[0001564590-21-024040:note_history:4]
The Company currently has two reportable segments: PCB and RF and Specialty Components (RF&S Components). In fiscal 2020, subsequent to the quarter ended March 30, 2020, RF&S Components was added as a reportable segment. As a result, the Company had three reportable segments as of December 28, 2020: PCB, RF&S Components, and E-M Solutions. On April 29, 2020, the Company announced the restructuring of its E-M Solutions business unit. In prior periods, the Company’s E-M Solutions business unit consisted of three Chinese manufacturing facilities with two being in Shanghai (SH BPA and SH E-MS) and one in Shenzhen (SZ). The Company closed the SH E-MS and SZ facilities at the end of 2020 and integrated the SH BPA facility into its PCB operations. As of March 29, 2021, E-M Solutions no longer meets the criteria for segment reporting. As a result of the addition of the RF&S Components reportable segment and the restructuring of the E-M Solutions business unit, certain prior year amounts have been reclassified to conform to this new presentation.

- added (2021-08-04):
[0001564590-21-040796:note_history:5]
Immaterial Correction of Error

- added (2021-08-04):
[0001564590-21-040796:note_history:6]
During the quarter ended September 28, 2020, the Company paid for certain transaction costs related to the sale of the Mobility business unit totaling $11,043. These transaction costs should have been recorded as an expense earlier in the year and recorded in the period ending June 29, 2020, which would have reduced the gain on sale of Mobility business unit, during the quarter ended June 29, 2020. The Company overstated both the income from discontinued operations, net of income taxes and net income by $11,043, both basic earnings per share from discontinued operations and basic earnings per share of $0.10 and $0.11 in the quarter and two quarters ended June 29, 2020, respectively, and both diluted earnings per share from discontinued operations and diluted earnings per share of $0.10 in the quarter and two quarters ended June 29, 2020. Management concluded that this error in the timing of recording the expense was not material to the consolidated condensed financial statements for the quarter and two quarters ended June 29, 2020. Prior period amounts have been revised to correct the error.

- added (2021-08-04):
[0001564590-21-040796:note_history:7]
In December 2019, the Financial Accounting Standards Board (FASB) issued ASU 2019-12, Income Taxes (Topic 740): Simplifying the Accounting for Income Taxes, which is intended to simplify various aspects related to accounting for income taxes. ASU 2019-12 removes certain exceptions to the general principles in Topic 740 and also clarifies and amends existing guidance to improve consistent application. The guidance is effective for fiscal years beginning after December 15, 2020, including interim periods within those fiscal years. Early adoption is permitted. The Company adopted this ASU as of December 29, 2020 and it did not have a material impact on its consolidated condensed financial statements and related disclosures.

- removed (2021-08-04):
[0001564590-21-024040:note_history:8]
In December 2019, the Financial Accounting Standards Board (FASB) issued ASU 2019-12, Income Taxes (Topic 740): Simplifying the Accounting for Income Taxes, which is intended to simplify various aspects related to accounting for income taxes.

- removed (2021-08-04):
[0001564590-21-024040:note_history:9]
ASU 2019-12 removes certain exceptions to the general principles in Topic 740 and also clarifies and amends existing guidance to improve consistent application. The guidance is effective for fiscal years beginning after December 15, 2020, including interim periods within those fiscal years. Early adoption is permitted. The Company adopted this ASU as of December 29, 2020 and it did not have a material impact on its consolidated condensed financial statements and related disclosures.


## ttmi:ScheduleOfUnamortizedDiscountAndDebtIssuanceCostsTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2021-08-04):
[0001564590-21-040796:note_history:10]
As of June 28, 2021 and December 28, 2020, remaining unamortized debt discount and debt issuance costs for the Senior Notes due 2029, Term Loan Facility and Senior Notes due 2025 are as follows:
  (was, 2021-05-05, similarity 0.9745):
[0001564590-21-024040:note_history:10]
As of March 29, 2021 and December 28, 2020, remaining unamortized debt discount and debt issuance costs for the Senior Notes due 2029, Term Loan Facility and Senior Notes due 2025 are as follows:

- changed (2021-08-04):
[0001564590-21-040796:note_history:11]
|  |  | As of June 28, 2021 |  |  | As of December 28, 2020 |
|  |  | Debt Issuance Costs |  |  | Debt Discount |  |  | Effective Interest Rate |  |  | Debt Issuance Costs |  |  | Debt Discount |  |  | Effective Interest Rate |  |  |
|  |  | (In thousands, except interest rates) |
| Senior Notes due March 2029 |  | $ | 6,289 |  |  | $ | — |  |  |  | 4.19 |  | % | $ | — |  |  | $ | — |  |  |  | — |  | % |
| Term Loan due September 2024 |  |  | 2,355 |  |  |  | 712 |  |  |  | 4.66 |  |  |  | 2,695 |  |  |  | 814 |  |  |  | 4.66 |  |  |
| Senior Notes due October 2025 |  | — |  |  | — |  |  |  | — |  |  |  | 4,517 |  |  | — |  |  |  | 5.92 |  |  |
|  |  | $ | 8,644 |  |  | $ | 712 |  |  |  |  |  |  | $ | 7,212 |  |  | $ | 814 |  |  |  |  |  |  |
  (was, 2021-05-05, similarity 0.9925):
[0001564590-21-024040:note_history:11]
|  |  | As of March 29, 2021 |  |  | As of December 28, 2020 |
|  |  | Debt Issuance Costs |  |  | Debt Discount |  |  | Effective Interest Rate |  |  | Debt Issuance Costs |  |  | Debt Discount |  |  | Effective Interest Rate |  |  |
|  |  | (In thousands, except interest rates) |
| Senior Notes due March 2029 |  | $ | 6,462 |  |  | $ | — |  |  |  | 4.19 |  | % | $ | — |  |  | $ | — |  |  |  | — |  | % |
| Term Loan due September 2024 |  |  | 2,526 |  |  |  | 763 |  |  |  | 4.66 |  |  |  | 2,695 |  |  |  | 814 |  |  |  | 4.66 |  |  |
| Senior Notes due October 2025 |  | — |  |  | — |  |  |  | — |  |  |  | 4,517 |  |  | — |  |  |  | 5.92 |  |  |
|  |  | $ | 8,988 |  |  | $ | 763 |  |  |  |  |  |  | $ | 7,212 |  |  | $ | 814 |  |  |  |  |  |  |


## us-gaap:LongTermDebtTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2021-08-04):
[0001564590-21-040796:note_history:12]
The following table summarizes the long-term debt of the Company as of June 28, 2021 and December 28, 2020:
  (was, 2021-05-05, similarity 0.9538):
[0001564590-21-024040:note_history:12]
The following table summarizes the long-term debt of the Company as of March 29, 2021 and December 28, 2020:

- changed (2021-08-04):
[0001564590-21-040796:note_history:13]
|  |  | Interest Rate as of June 28, 2021 |  |  | Principal Outstanding as of June 28, 2021 |  |  | Interest Rate as of December 28, 2020 |  |  | Principal Outstanding as of December 28, 2020 |  |
|  |  | (In thousands) |  |
| Senior Notes due March 2029 |  |  | 4.00 |  | % | $ | 500,000 |  |  |  | — |  | % | $ | — |  |
| Term Loan due September 2024 |  |  | 2.60 |  |  |  | 405,879 |  |  |  | 2.65 |  |  |  | 405,879 |  |
| Senior Notes due October 2025 |  |  | — |  |  |  | — |  |  |  | 5.63 |  |  |  | 375,000 |  |
| U.S. ABL Revolving Loan due June 2024 |  |  | — |  |  |  | — |  |  |  | 1.40 |  |  |  | 40,000 |  |
| Asia ABL Revolving Loan due June 2024 |  |  | 1.50 |  |  |  | 30,000 |  |  |  | 1.55 |  |  |  | 30,000 |  |
|  |  |  |  |  |  |  | 935,879 |  |  |  |  |  |  |  | 850,879 |  |
| Less: Long-term debt unamortized discount |  |  |  |  |  |  | (712 | ) |  |  |  |  |  |  | (814 | ) |
| Long-term debt unamortized debt issuance costs |  |  |  |  |  |  | (8,644 | ) |  |  |  |  |  |  | (7,212 | ) |
|  |  |  |  |  |  |  | 926,523 |  |  |  |  |  |  |  | 842,853 |  |
| Less: current maturities |  |  |  |  |  |  | — |  |  |  |  |  |  |  | — |  |
| Long-term debt, less current maturities |  |  |  |  |  | $ | 926,523 |  |  |  |  |  |  | $ | 842,853 |  |
  (was, 2021-05-05, similarity 0.9908):
[0001564590-21-024040:note_history:13]
|  |  | Interest Rate as of March 29, 2021 |  |  | Principal Outstanding as of March 29, 2021 |  |  | Interest Rate as of December 28, 2020 |  |  | Principal Outstanding as of December 28, 2020 |  |
|  |  | (In thousands) |  |
| Senior Notes due March 2029 |  |  | 4.00 |  | % | $ | 500,000 |  |  |  | — |  | % | $ | — |  |
| Term Loan due September 2024 |  |  | 2.61 |  |  |  | 405,879 |  |  |  | 2.65 |  |  |  | 405,879 |  |
| Senior Notes due October 2025 |  |  | — |  |  |  | — |  |  |  | 5.63 |  |  |  | 375,000 |  |
| U.S. ABL Revolving Loan due June 2024 |  |  | — |  |  |  | — |  |  |  | 1.40 |  |  |  | 40,000 |  |
| Asia ABL Revolving Loan due June 2024 |  |  | 1.51 |  |  |  | 30,000 |  |  |  | 1.55 |  |  |  | 30,000 |  |
|  |  |  |  |  |  |  | 935,879 |  |  |  |  |  |  |  | 850,879 |  |
| Less: Long-term debt unamortized discount |  |  |  |  |  |  | (763 | ) |  |  |  |  |  |  | (814 | ) |
| Long-term debt unamortized debt issuance costs |  |  |  |  |  |  | (8,988 | ) |  |  |  |  |  |  | (7,212 | ) |
|  |  |  |  |  |  |  | 926,128 |  |  |  |  |  |  |  | 842,853 |  |
| Less: current maturities |  |  |  |  |  |  | — |  |  |  |  |  |  |  | — |  |
| Long-term debt, less current maturities |  |  |  |  |  | $ | 926,128 |  |  |  |  |  |  | $ | 842,853 |  |

- added (2021-08-04):
[0001564590-21-040796:note_history:14]
Pursuant to the Term Loan Credit Agreement, the Company may reinvest the cash proceeds received from the sale of the Mobility business unit for a period of twelve months commencing September 3, 2020. If the proceeds are not reinvested during that time, the Company is required to use the proceeds to prepay the Term Loan. The Company used a portion of the cash proceeds to

- added (2021-08-04):
[0001564590-21-040796:note_history:15]
repay $400,000 of the Term Loan during the year ended December 28, 2020 and used the remaining cash proceeds for reinvestment pursuant to the Term Loan Credit Agreement. Permitted investments, as defined in the Term Loan Credit Agreement, include extensions of trade credit in the ordinary course of business, investments in cash and cash equivalents, permitted acquisitions, investments in assets useful in the business of the Company and its restricted subsidiaries, investments in joint ventures and unrestricted subsidiaries among others.

- changed (2021-08-04):
[0001564590-21-040796:note_history:16]
As of June 28, 2021, letters of credit in the amount of $12,201 were outstanding under the U.S. ABL and $3,475 were outstanding under the Asia Asset-Based Lending Credit Agreement (Asia ABL) with various expiration dates through July 2021. Available borrowing capacity under the U.S. ABL and the Asia ABL was $137,799 and $116,525, respectively, which considers letters of credit outstanding as of June 28, 2021.
  (was, 2021-05-05, similarity 0.8074):
[0001564590-21-024040:note_history:16]
As of March 29, 2021, letters of credit in the amount of $10,753 were outstanding under the U.S. ABL and $11,721 were outstanding under the Asia ABL with various expiration dates through July 2021. Available borrowing capacity under the U.S. ABL and the Asia ABL was $139,247 and $108,279, respectively, which considers letters of credit outstanding as of March 29, 2021.

- changed (2021-08-04):
[0001564590-21-040796:note_history:17]
Under the occurrence of certain events, the U.S. ABL and Asia ABL (collectively, the ABL Revolving Loans), are subject to various financial covenants, including leverage and fixed charge coverage ratios.
  (was, 2021-05-05, similarity 0.8933):
[0001564590-21-024040:note_history:17]
Under the occurrence of certain events, the U.S. ABL and Asia Asset-Based Lending Credit Agreement (Asia ABL) (collectively, the ABL Revolving Loans), are subject to various financial covenants, including leverage and fixed charge coverage ratios.

- changed (2021-08-04):
[0001564590-21-040796:note_history:18]
As of June 28, 2021 and December 28, 2020, remaining unamortized debt discount and debt issuance costs for the Senior Notes due 2029, Term Loan Facility and Senior Notes due 2025 are as follows:
  (was, 2021-05-05, similarity 0.9745):
[0001564590-21-024040:note_history:18]
As of March 29, 2021 and December 28, 2020, remaining unamortized debt discount and debt issuance costs for the Senior Notes due 2029, Term Loan Facility and Senior Notes due 2025 are as follows:

- changed (2021-08-04):
[0001564590-21-040796:note_history:19]
|  |  | As of June 28, 2021 |  |  | As of December 28, 2020 |
|  |  | Debt Issuance Costs |  |  | Debt Discount |  |  | Effective Interest Rate |  |  | Debt Issuance Costs |  |  | Debt Discount |  |  | Effective Interest Rate |  |  |
|  |  | (In thousands, except interest rates) |
| Senior Notes due March 2029 |  | $ | 6,289 |  |  | $ | — |  |  |  | 4.19 |  | % | $ | — |  |  | $ | — |  |  |  | — |  | % |
| Term Loan due September 2024 |  |  | 2,355 |  |  |  | 712 |  |  |  | 4.66 |  |  |  | 2,695 |  |  |  | 814 |  |  |  | 4.66 |  |  |
| Senior Notes due October 2025 |  | — |  |  | — |  |  |  | — |  |  |  | 4,517 |  |  | — |  |  |  | 5.92 |  |  |
|  |  | $ | 8,644 |  |  | $ | 712 |  |  |  |  |  |  | $ | 7,212 |  |  | $ | 814 |  |  |  |  |  |  |
  (was, 2021-05-05, similarity 0.9925):
[0001564590-21-024040:note_history:19]
|  |  | As of March 29, 2021 |  |  | As of December 28, 2020 |
|  |  | Debt Issuance Costs |  |  | Debt Discount |  |  | Effective Interest Rate |  |  | Debt Issuance Costs |  |  | Debt Discount |  |  | Effective Interest Rate |  |  |
|  |  | (In thousands, except interest rates) |
| Senior Notes due March 2029 |  | $ | 6,462 |  |  | $ | — |  |  |  | 4.19 |  | % | $ | — |  |  | $ | — |  |  |  | — |  | % |
| Term Loan due September 2024 |  |  | 2,526 |  |  |  | 763 |  |  |  | 4.66 |  |  |  | 2,695 |  |  |  | 814 |  |  |  | 4.66 |  |  |
| Senior Notes due October 2025 |  | — |  |  | — |  |  |  | — |  |  |  | 4,517 |  |  | — |  |  |  | 5.92 |  |  |
|  |  | $ | 8,988 |  |  | $ | 763 |  |  |  |  |  |  | $ | 7,212 |  |  | $ | 814 |  |  |  |  |  |  |

- changed (2021-08-04):
[0001564590-21-040796:note_history:20]
Remaining unamortized debt issuance costs for the ABL Revolving Loans of $1,637 and $1,919 as of June 28, 2021 and December 28, 2020, respectively, are included in other non-current assets and are amortized to interest expense over the duration of the ABL Revolving Loans using the straight-line method of amortization.
  (was, 2021-05-05, similarity 0.985):
[0001564590-21-024040:note_history:20]
Remaining unamortized debt issuance costs for the ABL Revolving Loans of $1,778 and $1,919 as of March 29, 2021 and December 28, 2020, respectively, are included in other non-current assets and are amortized to interest expense over the duration of the ABL Revolving Loans using the straight-line method of amortization.

- changed (2021-08-04):
[0001564590-21-040796:note_history:21]
As of June 28, 2021, the remaining weighted average amortization period for all unamortized debt discount and debt issuance costs was 5.7 years.
  (was, 2021-05-05, similarity 0.967):
[0001564590-21-024040:note_history:21]
As of March 29, 2021, the remaining weighted average amortization period for all unamortized debt discount and debt issuance costs was 5.9 years.

- added (2021-08-04):
[0001564590-21-040796:note_history:22]
During the two quarters ended June 28, 2021, the Company recognized losses of $15,217 associated with the premium paid on extinguishment of debt and the write-off of the remaining unamortized debt issuance costs as a result of the repayment of the remaining outstanding balance of the Senior Notes due 2025.

- removed (2021-08-04):
[0001564590-21-024040:note_history:23]
The Company has twelve months from September 3, 2020 to reinvest the cash proceeds received from the sale of the Mobility business unit. If the proceeds are not reinvested, the Company is required to use the proceeds to prepay the Term Loan. The Company used a portion of the cash proceeds to repay $400,000 of the Term Loan during the year ended December 28, 2020 and plans to use

- removed (2021-08-04):
[0001564590-21-024040:note_history:24]
the remaining cash proceeds for reinvestment. Permitted investments, as defined in the Term Loan Credit Agreement, include extensions of trade credit in the ordinary course of business, investments in cash and cash equivalents, permitted acquisitions, investments in assets useful in the business of the Company and its restricted subsidiaries, investments in joint ventures and unrestricted subsidiaries among others.

- removed (2021-08-04):
[0001564590-21-024040:note_history:25]
During the quarter ended March 29, 2021, the Company recognized losses of $15,217 associated with the premium paid on extinguishment of debt and the write-off of the remaining unamortized debt issuance costs as a result of the repayment of the remaining outstanding balance of the Senior Notes due 2025.


## us-gaap:ScheduleOfDebtInstrumentsTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2021-08-04):
[0001564590-21-040796:note_history:26]
The following table summarizes the long-term debt of the Company as of June 28, 2021 and December 28, 2020:
  (was, 2021-05-05, similarity 0.9538):
[0001564590-21-024040:note_history:26]
The following table summarizes the long-term debt of the Company as of March 29, 2021 and December 28, 2020:

- changed (2021-08-04):
[0001564590-21-040796:note_history:27]
|  |  | Interest Rate as of June 28, 2021 |  |  | Principal Outstanding as of June 28, 2021 |  |  | Interest Rate as of December 28, 2020 |  |  | Principal Outstanding as of December 28, 2020 |  |
|  |  | (In thousands) |  |
| Senior Notes due March 2029 |  |  | 4.00 |  | % | $ | 500,000 |  |  |  | — |  | % | $ | — |  |
| Term Loan due September 2024 |  |  | 2.60 |  |  |  | 405,879 |  |  |  | 2.65 |  |  |  | 405,879 |  |
| Senior Notes due October 2025 |  |  | — |  |  |  | — |  |  |  | 5.63 |  |  |  | 375,000 |  |
| U.S. ABL Revolving Loan due June 2024 |  |  | — |  |  |  | — |  |  |  | 1.40 |  |  |  | 40,000 |  |
| Asia ABL Revolving Loan due June 2024 |  |  | 1.50 |  |  |  | 30,000 |  |  |  | 1.55 |  |  |  | 30,000 |  |
|  |  |  |  |  |  |  | 935,879 |  |  |  |  |  |  |  | 850,879 |  |
| Less: Long-term debt unamortized discount |  |  |  |  |  |  | (712 | ) |  |  |  |  |  |  | (814 | ) |
| Long-term debt unamortized debt issuance costs |  |  |  |  |  |  | (8,644 | ) |  |  |  |  |  |  | (7,212 | ) |
|  |  |  |  |  |  |  | 926,523 |  |  |  |  |  |  |  | 842,853 |  |
| Less: current maturities |  |  |  |  |  |  | — |  |  |  |  |  |  |  | — |  |
| Long-term debt, less current maturities |  |  |  |  |  | $ | 926,523 |  |  |  |  |  |  | $ | 842,853 |  |
  (was, 2021-05-05, similarity 0.9908):
[0001564590-21-024040:note_history:27]
|  |  | Interest Rate as of March 29, 2021 |  |  | Principal Outstanding as of March 29, 2021 |  |  | Interest Rate as of December 28, 2020 |  |  | Principal Outstanding as of December 28, 2020 |  |
|  |  | (In thousands) |  |
| Senior Notes due March 2029 |  |  | 4.00 |  | % | $ | 500,000 |  |  |  | — |  | % | $ | — |  |
| Term Loan due September 2024 |  |  | 2.61 |  |  |  | 405,879 |  |  |  | 2.65 |  |  |  | 405,879 |  |
| Senior Notes due October 2025 |  |  | — |  |  |  | — |  |  |  | 5.63 |  |  |  | 375,000 |  |
| U.S. ABL Revolving Loan due June 2024 |  |  | — |  |  |  | — |  |  |  | 1.40 |  |  |  | 40,000 |  |
| Asia ABL Revolving Loan due June 2024 |  |  | 1.51 |  |  |  | 30,000 |  |  |  | 1.55 |  |  |  | 30,000 |  |
|  |  |  |  |  |  |  | 935,879 |  |  |  |  |  |  |  | 850,879 |  |
| Less: Long-term debt unamortized discount |  |  |  |  |  |  | (763 | ) |  |  |  |  |  |  | (814 | ) |
| Long-term debt unamortized debt issuance costs |  |  |  |  |  |  | (8,988 | ) |  |  |  |  |  |  | (7,212 | ) |
|  |  |  |  |  |  |  | 926,128 |  |  |  |  |  |  |  | 842,853 |  |
| Less: current maturities |  |  |  |  |  |  | — |  |  |  |  |  |  |  | — |  |
| Long-term debt, less current maturities |  |  |  |  |  | $ | 926,128 |  |  |  |  |  |  | $ | 842,853 |  |


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2021-08-04):
[0001564590-21-040796:note_history:28]
|  |  | Quarter Ended June 28, 2021 |  |  | Quarter Ended June 29, 2020 |  |  |
|  |  | PCB |  |  | RF&S Components |  |  | Total |  |  | PCB |  |  | RF&S Components |  |  | Other (1) |  |  | Total |  |  |
| End Markets |  | (In thousands) |  |  |
| Aerospace and Defense |  | $ | 185,152 |  |  | $ | 6 |  |  | $ | 185,158 |  |  | $ | 188,910 |  |  | $ | 9 |  |  | $ | 20 |  |  | $ | 188,939 |  |  |
| Automotive |  |  | 102,893 |  |  |  | — |  |  |  | 102,893 |  |  |  | 57,998 |  |  |  | — |  |  |  | 11,583 |  |  |  | 69,581 |  |  |
| Data Center Computing (2) |  |  | 82,230 |  |  |  | 24 |  |  |  | 82,254 |  |  |  | 71,541 |  |  |  | 273 |  |  |  | 36 |  |  |  | 71,850 |  |  |
| Medical/Industrial/Instrumentation |  |  | 104,012 |  |  |  | 1,067 |  |  |  | 105,079 |  |  |  | 115,813 |  |  |  | 800 |  |  |  | 2,988 |  |  |  | 119,601 |  |  |
| Networking/Communications |  |  | 75,728 |  |  |  | 11,950 |  |  |  | 87,678 |  |  |  | 95,416 |  |  |  | 10,560 |  |  |  | 7,446 |  |  |  | 113,422 |  |  |
| Other |  |  | 3,465 |  |  |  | 856 |  |  |  | 4,321 |  |  |  | 7,165 |  |  |  | 449 |  |  |  | (709 | ) |  |  | 6,905 |  |  |
| Total |  | $ | 553,480 |  |  | $ | 13,903 |  |  | $ | 567,383 |  |  | $ | 536,843 |  |  | $ | 12,091 |  |  | $ | 21,364 |  |  | $ | 570,298 |  |  |
  (was, 2021-05-05, similarity 0.625):
[0001564590-21-024040:note_history:28]
|  |  | Quarter Ended March 29, 2021 |  |  |
|  |  | PCB |  |  | RF&S Components |  |  | Other (1) |  |  | Total |  |  |
| End Markets |  | (In thousands) |  |  |
| Aerospace and Defense |  | $ | 186,539 |  |  | $ | 6 |  |  | $ | — |  |  | $ | 186,545 |  |  |
| Automotive |  |  | 91,792 |  |  |  | — |  |  |  | 3,642 |  |  |  | 95,434 |  |  |
| Data Center Computing (2) |  |  | 71,759 |  |  |  | 432 |  |  |  | — |  |  |  | 72,191 |  |  |
| Medical/Industrial/Instrumentation |  |  | 90,770 |  |  |  | 1,081 |  |  |  | 25 |  |  |  | 91,876 |  |  |
| Networking/Communications |  |  | 66,938 |  |  |  | 10,653 |  |  |  | 1 |  |  |  | 77,592 |  |  |
| Other |  |  | 2,688 |  |  |  | 518 |  |  |  | (412 | ) |  |  | 2,794 |  |  |
| Total |  | $ | 510,486 |  |  | $ | 12,690 |  |  | $ | 3,256 |  |  | $ | 526,432 |  |  |

- changed (2021-08-04):
[0001564590-21-040796:note_history:29]
|  |  | Two Quarters Ended June 28, 2021 |  |  | Two Quarters Ended June 29, 2020 |  |  |
|  |  | PCB |  |  | RF&S Components |  |  | Other (1) |  |  | Total |  |  | PCB |  |  | RF&S Components |  |  | Other (1) |  |  | Total |  |  |
| End Markets |  | (In thousands) |  |  |
| Aerospace and Defense |  | $ | 371,691 |  |  |  | 12 |  |  | $ | — |  |  | $ | 371,703 |  |  | $ | 373,324 |  |  | $ | 9 |  |  | $ | 20 |  |  | $ | 373,353 |  |  |
| Automotive |  |  | 194,685 |  |  |  | — |  |  |  | 3,642 |  |  |  | 198,327 |  |  |  | 119,856 |  |  |  | — |  |  |  | 18,596 |  |  |  | 138,452 |  |  |
| Cellular Phone |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 1,296 |  |  |  | — |  |  |  | — |  |  |  | 1,296 |  |  |
| Data Center Computing (2) |  |  | 153,989 |  |  |  | 456 |  |  |  | — |  |  |  | 154,445 |  |  |  | 129,655 |  |  |  | 476 |  |  |  | 90 |  |  |  | 130,221 |  |  |
| Medical/Industrial/Instrumentation |  |  | 194,782 |  |  |  | 2,148 |  |  |  | 25 |  |  |  | 196,955 |  |  |  | 206,281 |  |  |  | 1,594 |  |  |  | 6,308 |  |  |  | 214,183 |  |  |
| Networking/Communications |  |  | 142,666 |  |  |  | 22,603 |  |  |  | 1 |  |  |  | 165,270 |  |  |  | 165,849 |  |  |  | 18,627 |  |  |  | 11,641 |  |  |  | 196,117 |  |  |
| Other |  |  | 6,153 |  |  |  | 1,374 |  |  |  | (412 | ) |  |  | 7,115 |  |  |  | 14,584 |  |  |  | 826 |  |  |  | (1,088 | ) |  |  | 14,322 |  |  |
| Total |  | $ | 1,063,966 |  |  | $ | 26,593 |  |  | $ | 3,256 |  |  | $ | 1,093,815 |  |  | $ | 1,010,845 |  |  | $ | 21,532 |  |  | $ | 35,567 |  |  | $ | 1,067,944 |  |  |
  (was, 2021-05-05, similarity 0.6562):
[0001564590-21-024040:note_history:29]
|  |  | Quarter Ended March 30, 2020 |  |  |
|  |  | PCB |  |  | RF&S Components |  |  | Other (1) |  |  | Total |  |  |
| End Markets |  | (In thousands) |  |  |
| Aerospace and Defense |  | $ | 184,414 |  |  | $ | — |  |  | $ | — |  |  | $ | 184,414 |  |  |
| Automotive |  |  | 61,858 |  |  |  | — |  |  |  | 7,013 |  |  |  | 68,871 |  |  |
| Cellular Phone |  |  | 2,775 |  |  |  | — |  |  |  | — |  |  |  | 2,775 |  |  |
| Data Center Computing (2) |  |  | 58,114 |  |  |  | 203 |  |  |  | 54 |  |  |  | 58,371 |  |  |
| Medical/Industrial/Instrumentation |  |  | 90,468 |  |  |  | 794 |  |  |  | 3,320 |  |  |  | 94,582 |  |  |
| Networking/Communications |  |  | 70,433 |  |  |  | 8,067 |  |  |  | 4,195 |  |  |  | 82,695 |  |  |
| Other |  |  | 5,940 |  |  |  | 377 |  |  |  | (379 | ) |  |  | 5,938 |  |  |
| Total |  | $ | 474,002 |  |  | $ | 9,441 |  |  | $ | 14,203 |  |  | $ | 497,646 |  |  |

- changed (2021-08-04):
[0001564590-21-040796:note_history:30]
| (2) | Beginning in the first quarter of 2021, the Computing/Storage/Peripherals end market was renamed to Data Center Computing to better reflect the customer mix and growth prospects. There was no change to the customers included in this end market. |
  (was, 2021-05-05, similarity 0.883):
[0001564590-21-024040:note_history:30]
| (2) | In the current period, the Computing/Storage/Peripherals end market was renamed to Data Center Computing to better reflect the customer mix and growth prospects. There was no change to the customers included in this end market. |


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2021-08-04):
[0001564590-21-040796:note_history:31]
As of June 28, 2021, the aggregate amount of the transaction price allocated to remaining performance obligations for long-term contracts was $11,905. The Company expects to recognize revenue on approximately 82% of the remaining performance obligations for the Company’s long-term contracts over the next twelve months.
  (was, 2021-05-05, similarity 0.9854):
[0001564590-21-024040:note_history:31]
As of March 29, 2021, the aggregate amount of the transaction price allocated to remaining performance obligations for long-term contracts was $12,850. The Company expects to recognize revenue on approximately 100% of the remaining performance obligations for the Company’s long-term contracts over the next twelve months.

- changed (2021-08-04):
[0001564590-21-040796:note_history:32]
Revenue from products and services transferred to customers over time and at a point in time accounted for 98% and 2%, respectively, of the Company’s revenue for both quarter and two quarters ended June 28, 2021 and June 29, 2020.
  (was, 2021-05-05, similarity 0.8047):
[0001564590-21-024040:note_history:32]
Revenue from products and services transferred to customers over time and at a point in time accounted for 98% and 2%, respectively, of the Company’s revenue for the both the quarters ended March 29, 2021 and March 30, 2020.

- changed (2021-08-04):
[0001564590-21-040796:note_history:33]
|  |  | Quarter Ended June 28, 2021 |  |  | Quarter Ended June 29, 2020 |  |  |
|  |  | PCB |  |  | RF&S Components |  |  | Total |  |  | PCB |  |  | RF&S Components |  |  | Other (1) |  |  | Total |  |  |
| End Markets |  | (In thousands) |  |  |
| Aerospace and Defense |  | $ | 185,152 |  |  | $ | 6 |  |  | $ | 185,158 |  |  | $ | 188,910 |  |  | $ | 9 |  |  | $ | 20 |  |  | $ | 188,939 |  |  |
| Automotive |  |  | 102,893 |  |  |  | — |  |  |  | 102,893 |  |  |  | 57,998 |  |  |  | — |  |  |  | 11,583 |  |  |  | 69,581 |  |  |
| Data Center Computing (2) |  |  | 82,230 |  |  |  | 24 |  |  |  | 82,254 |  |  |  | 71,541 |  |  |  | 273 |  |  |  | 36 |  |  |  | 71,850 |  |  |
| Medical/Industrial/Instrumentation |  |  | 104,012 |  |  |  | 1,067 |  |  |  | 105,079 |  |  |  | 115,813 |  |  |  | 800 |  |  |  | 2,988 |  |  |  | 119,601 |  |  |
| Networking/Communications |  |  | 75,728 |  |  |  | 11,950 |  |  |  | 87,678 |  |  |  | 95,416 |  |  |  | 10,560 |  |  |  | 7,446 |  |  |  | 113,422 |  |  |
| Other |  |  | 3,465 |  |  |  | 856 |  |  |  | 4,321 |  |  |  | 7,165 |  |  |  | 449 |  |  |  | (709 | ) |  |  | 6,905 |  |  |
| Total |  | $ | 553,480 |  |  | $ | 13,903 |  |  | $ | 567,383 |  |  | $ | 536,843 |  |  | $ | 12,091 |  |  | $ | 21,364 |  |  | $ | 570,298 |  |  |
  (was, 2021-05-05, similarity 0.625):
[0001564590-21-024040:note_history:33]
|  |  | Quarter Ended March 29, 2021 |  |  |
|  |  | PCB |  |  | RF&S Components |  |  | Other (1) |  |  | Total |  |  |
| End Markets |  | (In thousands) |  |  |
| Aerospace and Defense |  | $ | 186,539 |  |  | $ | 6 |  |  | $ | — |  |  | $ | 186,545 |  |  |
| Automotive |  |  | 91,792 |  |  |  | — |  |  |  | 3,642 |  |  |  | 95,434 |  |  |
| Data Center Computing (2) |  |  | 71,759 |  |  |  | 432 |  |  |  | — |  |  |  | 72,191 |  |  |
| Medical/Industrial/Instrumentation |  |  | 90,770 |  |  |  | 1,081 |  |  |  | 25 |  |  |  | 91,876 |  |  |
| Networking/Communications |  |  | 66,938 |  |  |  | 10,653 |  |  |  | 1 |  |  |  | 77,592 |  |  |
| Other |  |  | 2,688 |  |  |  | 518 |  |  |  | (412 | ) |  |  | 2,794 |  |  |
| Total |  | $ | 510,486 |  |  | $ | 12,690 |  |  | $ | 3,256 |  |  | $ | 526,432 |  |  |

- changed (2021-08-04):
[0001564590-21-040796:note_history:34]
|  |  | Two Quarters Ended June 28, 2021 |  |  | Two Quarters Ended June 29, 2020 |  |  |
|  |  | PCB |  |  | RF&S Components |  |  | Other (1) |  |  | Total |  |  | PCB |  |  | RF&S Components |  |  | Other (1) |  |  | Total |  |  |
| End Markets |  | (In thousands) |  |  |
| Aerospace and Defense |  | $ | 371,691 |  |  |  | 12 |  |  | $ | — |  |  | $ | 371,703 |  |  | $ | 373,324 |  |  | $ | 9 |  |  | $ | 20 |  |  | $ | 373,353 |  |  |
| Automotive |  |  | 194,685 |  |  |  | — |  |  |  | 3,642 |  |  |  | 198,327 |  |  |  | 119,856 |  |  |  | — |  |  |  | 18,596 |  |  |  | 138,452 |  |  |
| Cellular Phone |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 1,296 |  |  |  | — |  |  |  | — |  |  |  | 1,296 |  |  |
| Data Center Computing (2) |  |  | 153,989 |  |  |  | 456 |  |  |  | — |  |  |  | 154,445 |  |  |  | 129,655 |  |  |  | 476 |  |  |  | 90 |  |  |  | 130,221 |  |  |
| Medical/Industrial/Instrumentation |  |  | 194,782 |  |  |  | 2,148 |  |  |  | 25 |  |  |  | 196,955 |  |  |  | 206,281 |  |  |  | 1,594 |  |  |  | 6,308 |  |  |  | 214,183 |  |  |
| Networking/Communications |  |  | 142,666 |  |  |  | 22,603 |  |  |  | 1 |  |  |  | 165,270 |  |  |  | 165,849 |  |  |  | 18,627 |  |  |  | 11,641 |  |  |  | 196,117 |  |  |
| Other |  |  | 6,153 |  |  |  | 1,374 |  |  |  | (412 | ) |  |  | 7,115 |  |  |  | 14,584 |  |  |  | 826 |  |  |  | (1,088 | ) |  |  | 14,322 |  |  |
| Total |  | $ | 1,063,966 |  |  | $ | 26,593 |  |  | $ | 3,256 |  |  | $ | 1,093,815 |  |  | $ | 1,010,845 |  |  | $ | 21,532 |  |  | $ | 35,567 |  |  | $ | 1,067,944 |  |  |
  (was, 2021-05-05, similarity 0.6562):
[0001564590-21-024040:note_history:34]
|  |  | Quarter Ended March 30, 2020 |  |  |
|  |  | PCB |  |  | RF&S Components |  |  | Other (1) |  |  | Total |  |  |
| End Markets |  | (In thousands) |  |  |
| Aerospace and Defense |  | $ | 184,414 |  |  | $ | — |  |  | $ | — |  |  | $ | 184,414 |  |  |
| Automotive |  |  | 61,858 |  |  |  | — |  |  |  | 7,013 |  |  |  | 68,871 |  |  |
| Cellular Phone |  |  | 2,775 |  |  |  | — |  |  |  | — |  |  |  | 2,775 |  |  |
| Data Center Computing (2) |  |  | 58,114 |  |  |  | 203 |  |  |  | 54 |  |  |  | 58,371 |  |  |
| Medical/Industrial/Instrumentation |  |  | 90,468 |  |  |  | 794 |  |  |  | 3,320 |  |  |  | 94,582 |  |  |
| Networking/Communications |  |  | 70,433 |  |  |  | 8,067 |  |  |  | 4,195 |  |  |  | 82,695 |  |  |
| Other |  |  | 5,940 |  |  |  | 377 |  |  |  | (379 | ) |  |  | 5,938 |  |  |
| Total |  | $ | 474,002 |  |  | $ | 9,441 |  |  | $ | 14,203 |  |  | $ | 497,646 |  |  |

- changed (2021-08-04):
[0001564590-21-040796:note_history:35]
| (2) | Beginning in the first quarter of 2021, the Computing/Storage/Peripherals end market was renamed to Data Center Computing to better reflect the customer mix and growth prospects. There was no change to the customers included in this end market. |
  (was, 2021-05-05, similarity 0.883):
[0001564590-21-024040:note_history:35]
| (2) | In the current period, the Computing/Storage/Peripherals end market was renamed to Data Center Computing to better reflect the customer mix and growth prospects. There was no change to the customers included in this end market. |
