# TTMI MD&A — 0001564590-21-040796


## mdna

[0001564590-21-040796:mdna:1]
[same as prior period, unchanged from 0001564590-21-024040:mdna:1]

[0001564590-21-040796:mdna:2]
[same as prior period, unchanged from 0001564590-21-024040:mdna:2]

[0001564590-21-040796:mdna:3]
We are a leading global printed circuit board (PCB) manufacturer, focusing on quick-turn and volume production of technologically advanced PCBs and backplane assemblies as well as a global designer and manufacturer of high-frequency radio frequency (RF) and microwave components and assemblies. We focus on providing time-to-market and volume production of advanced technology products and offer a one-stop design, engineering and manufacturing solution to our customers. This one-stop design, engineering and manufacturing solution allows us to align technology development with the diverse needs of our customers and to enable them to reduce the time required to develop new products and bring them to market. We serve a diversified customer base consisting of approximately 1,300 customers in various markets throughout the world, including aerospace and defense, data center computing, automotive components, medical, industrial and instrumentation related products, as well as networking/communications infrastructure products. Our customers include both original equipment manufacturers (OEMs) and electronic manufacturing services (EMS) providers.

[0001564590-21-040796:mdna:4]
[same as prior period, unchanged from 0001564590-21-024040:mdna:4]

[0001564590-21-040796:mdna:5]
The coronavirus (COVID-19) pandemic first caused business disruption in our operations in China in January 2020. By March 2020, the situation escalated as the scope of the COVID-19 pandemic worsened outside of the Asia-Pacific region, with Europe and North America being affected by the pandemic. With the development and deployment of vaccines, the pandemic has declined. However, as new variants evolve, we could see a rebound in the severity of the pandemic. As a result, we expect continued impacts on our production, as well as ongoing significant uncertainty relating to the actual and potential impacts of the COVID-19 pandemic, and we cannot reasonably estimate its duration or severity. The COVID-19 pandemic has created and continues to create various global macroeconomic, customer demand, operational and supply chain risks any one of which could have a material and adverse impact on our business going forward. See Item 1A, Risk Factors, of Part II below for further information related to the COVID-19 pandemic. We have taken active measures to protect our employees, suppliers and customers by implementing our extensive pandemic recovery protocols, establishing situational leadership teams in Asia-Pacific and North America along with regularly scheduled executive review and planning calls, implementing global travel restrictions, and conforming to the guidance and direction of local governments and global health organizations. We are monitoring the impacts the COVID-19 pandemic has had, and continues to have, on our supply chain and are collaborating with our third-party partners with the goal of mitigating, to the extent reasonably practicable, significant delays in delivery of our products.

[0001564590-21-040796:mdna:6]
We have been experiencing increasing prices and lead times of copper clad laminates (CCLs) and other raw materials used in the manufacture of PCBs. CCLs are made from epoxy resin, glass cloth and copper foil, all of which are seeing limited supply has resulted in increased prices. We are actively managing higher raw materials costs by seeking to pass on the increase in costs to our customers, implementing ongoing operational efficiencies, and through supplier diversification.

[0001564590-21-040796:mdna:7]
[same as prior period, unchanged from 0001564590-21-024040:mdna:7]

[0001564590-21-040796:mdna:8]
[same as prior period, unchanged from 0001564590-21-024040:mdna:8]

[0001564590-21-040796:mdna:9]
While our customers include both OEMs and EMS providers, we measure customers based on OEM companies, as they are the ultimate end customers. Sales to our ten largest customers collectively accounted for 40% and 42% of our net sales for the quarter and two quarters ended June 28, 2021. Sales to our ten largest customers accounted for 36% and 38% of our net sales for the quarter and two quarters ended June 29, 2020, respectively. We sell to OEMs both directly and indirectly through EMS providers.

[0001564590-21-040796:mdna:10]
[same as prior period, unchanged from 0001564590-21-024040:mdna:10]

[0001564590-21-040796:mdna:11]
|  |  | Quarter Ended |  |  |  | Two Quarters Ended |  |  |
| End Markets (1) |  | June 28, 2021 |  |  |  | June 29, 2020 |  |  |  | June 28, 2021 |  |  |  | June 29, 2020 |  |  |
| Aerospace and Defense |  |  | 33 |  | % |  |  | 33 |  | % |  |  | 34 |  | % |  |  | 35 |  | % |
| Automotive |  |  | 18 |  |  |  |  | 12 |  |  |  |  | 18 |  |  |  |  | 13 |  |  |
| Data Center Computing (2) |  |  | 14 |  |  |  |  | 13 |  |  |  |  | 14 |  |  |  |  | 12 |  |  |
| Medical/Industrial/Instrumentation |  |  | 19 |  |  |  |  | 21 |  |  |  |  | 18 |  |  |  |  | 20 |  |  |
| Networking/Communications |  |  | 15 |  |  |  |  | 20 |  |  |  |  | 15 |  |  |  |  | 19 |  |  |
| Other (3) |  |  | 1 |  |  |  |  | 1 |  |  |  |  | 1 |  |  |  |  | 1 |  |  |
| Total |  |  | 100 |  | % |  |  | 100 |  | % |  |  | 100 |  | % |  |  | 100 |  | % |

[0001564590-21-040796:mdna:12]
[same as prior period, unchanged from 0001564590-21-024040:mdna:12]

[0001564590-21-040796:mdna:13]
| (2) | Beginning in the first quarter of 2021, the Computing/Storage/Peripherals end market was renamed to Data Center Computing to better reflect the customer mix and growth prospects. There was no change to the customers included in this end market. |

[0001564590-21-040796:mdna:14]
[same as prior period, unchanged from 0001564590-21-024040:mdna:14]

[0001564590-21-040796:mdna:15]
[same as prior period, unchanged from 0001564590-21-024040:mdna:15]

[0001564590-21-040796:mdna:16]
[same as prior period, unchanged from 0001564590-21-024040:mdna:16]

[0001564590-21-040796:mdna:17]
[same as prior period, unchanged from 0001564590-21-024040:mdna:17]

[0001564590-21-040796:mdna:18]
[same as prior period, unchanged from 0001564590-21-024040:mdna:18]

[0001564590-21-040796:mdna:19]
[same as prior period, unchanged from 0001564590-21-024040:mdna:19]

[0001564590-21-040796:mdna:20]
General and administrative costs primarily include the salaries for executive, finance, accounting, information technology, and human resources personnel, as well as expenses for accounting and legal assistance, incentive compensation expense, and gains or losses on the sale or disposal of property, plant and equipment.

[0001564590-21-040796:mdna:21]
[same as prior period, unchanged from 0001564590-21-024040:mdna:21]

[0001564590-21-040796:mdna:22]
[same as prior period, unchanged from 0001564590-21-024040:mdna:22]

[0001564590-21-040796:mdna:23]
[same as prior period, unchanged from 0001564590-21-024040:mdna:23]

[0001564590-21-040796:mdna:24]
[same as prior period, unchanged from 0001564590-21-024040:mdna:24]

[0001564590-21-040796:mdna:25]
[same as prior period, unchanged from 0001564590-21-024040:mdna:25]

[0001564590-21-040796:mdna:26]
[same as prior period, unchanged from 0001564590-21-024040:mdna:26]

[0001564590-21-040796:mdna:27]
|  |  | Quarter Ended |  | Two Quarters Ended |
|  |  | June 28, 2021 |  |  |  | June 29, 2020 |  |  |  | June 28, 2021 |  |  |  | June 29, 2020 |  |  |
| Net sales |  |  | 100.0 |  | % |  |  | 100.0 |  | % |  |  | 100.0 |  | % |  |  | 100.0 |  | % |
| Cost of goods sold |  |  | 82.4 |  |  |  |  | 82.4 |  |  |  |  | 83.4 |  |  |  |  | 83.0 |  |  |
| Gross profit |  |  | 17.6 |  |  |  |  | 17.6 |  |  |  |  | 16.6 |  |  |  |  | 17.0 |  |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Selling and marketing |  |  | 2.6 |  |  |  |  | 2.8 |  |  |  |  | 2.8 |  |  |  |  | 3.0 |  |  |
| General and administrative |  |  | 5.5 |  |  |  |  | 8.2 |  |  |  |  | 5.7 |  |  |  |  | 7.6 |  |  |
| Research and development |  |  | 0.7 |  |  |  |  | 0.9 |  |  |  |  | 0.8 |  |  |  |  | 0.9 |  |  |
| Amortization of definite-lived intangibles |  |  | 1.6 |  |  |  |  | 1.7 |  |  |  |  | 1.7 |  |  |  |  | 1.8 |  |  |
| Total operating expenses |  |  | 10.4 |  |  |  |  | 13.6 |  |  |  |  | 11.0 |  |  |  |  | 13.3 |  |  |
| Operating income |  |  | 7.2 |  |  |  |  | 4.0 |  |  |  |  | 5.6 |  |  |  |  | 3.7 |  |  |
| Other (expense) income: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Interest expense |  |  | (2.0 | ) |  |  |  | (3.3 | ) |  |  |  | (2.1 | ) |  |  |  | (3.6 | ) |  |
| Loss on extinguishment of debt |  |  | — |  |  |  |  | — |  |  |  |  | (1.4 | ) |  |  |  | — |  |  |
| Other, net |  |  | 0.1 |  |  |  |  | 0.1 |  |  |  |  | 0.3 |  |  |  |  | 0.3 |  |  |
| Total other expense, net |  |  | (1.9 | ) |  |  |  | (3.2 | ) |  |  |  | (3.2 | ) |  |  |  | (3.3 | ) |  |
| Income from continuing operations before income taxes |  |  | 5.3 |  |  |  |  | 0.8 |  |  |  |  | 2.4 |  |  |  |  | 0.4 |  |  |
| Income tax (provision) benefit |  |  | (0.3 | ) |  |  |  | 0.8 |  |  |  |  | (0.1 | ) |  |  |  | 0.2 |  |  |
| Net income from continuing operations |  |  | 5.0 |  | % |  |  | 1.6 |  | % |  |  | 2.3 |  | % |  |  | 0.6 |  | % |

[0001564590-21-040796:mdna:28]
As of March 29, 2021, E-M Solutions no longer met the criteria for segment reporting and the SH BPA facility has been integrated into the PCB reportable segment. In fiscal 2020, subsequent to the quarter ended June 29, 2020, RF&S Components was added as a reportable segment. As a result, we reclassified prior periods to reflect these changes to our segments.

[0001564590-21-040796:mdna:29]
[same as prior period, unchanged from 0001564590-21-024040:mdna:29]

[0001564590-21-040796:mdna:30]
Total net sales decreased $2.9 million, or 0.5%, to $567.4 million for the second quarter of 2021 from $570.3 million for the second quarter of 2020. This decrease in total net sales primarily resulted from a $21.3 million reduction in net sales due to the closure of the two plants from our discontinued E-M solutions segment. This decrease was partially offset by an increase in net sales for the PCB reportable segment of $16.6 million, or 3.1%, to $553.5 million for the second quarter of 2021 from $536.8 million for the second quarter of 2020 primarily due to higher demand in our Automotive and Data Center Computing end markets partially offset by lower demand in our Networking/Communications and Medical/Industrial/Instrumentation end markets. These changes in the PCB reportable segment resulted in a 32.6% increase in the volume of PCB shipments, however the resulting increase in net sales was partially offset by a 19.8% lower price per square foot, driven mainly by product mix shift as compared to the second quarter of 2020. Additionally, there was an increase in net sales for the RF&S Components reportable segment of $1.8 million, or 15.0%, to $13.9 million for the second quarter of 2021 from $12.1 million for the second quarter of 2020 primarily due to higher demand in our Networking/Communications end market.

[0001564590-21-040796:mdna:31]
Despite the closure of the two plants from our discontinued E-M Solutions segment, which accounted for a $32.3 million reduction in net sales, total net sales increased $25.9 million, or 2.4%, to $1,093.8 million for the first two quarters of 2021 from $1,067.9 million for the first two quarters of 2020. This increase in total net sales primarily resulted from an increase in net sales for the PCB reportable segment of $53.1 million, or 5.3%, to $1,064.0 million for the first two quarters of 2021 from $1,010.8 million for the first two quarters of 2020 primarily due to higher demand in our Automotive and Data Center Computing end markets, partially offset by lower demand in our Networking/Communications, Medical/Industrial/Instrumentation and Other end markets. These changes in the PCB reportable segment resulted in a 30.7% increase in the volume of PCB shipments, however the resulting increase in net sales was partially offset by a 17.9% lower price per square foot, driven mainly by product mix shift as compared to the first two quarters of 2020. Also contributing to the increase in total net sales was an increase in net sales for the RF&S Components reportable segment of $5.1 million, or 23.5%, to $26.6 million for the first two quarters of 2021 from $21.5 million for the first two quarters of 2020 primarily due to higher demand in our Networking/Communications end market.

[0001564590-21-040796:mdna:32]
[same as prior period, unchanged from 0001564590-21-024040:mdna:31]

[0001564590-21-040796:mdna:33]
Overall gross margin was 17.6% for both the second quarter of 2021 and the second quarter of 2020. Gross margin for the PCB reportable segment decreased to 17.4% for the second quarter of 2021 from 18.8% for the second quarter of 2020. This decline was

[0001564590-21-040796:mdna:34]
primarily due to unfavorable foreign exchange rates which increased our cost of operations and production and labor inefficiencies related to COVID-19. We were able to mitigate most of these costs through higher revenue and production and spending efficiencies including savings from the closure of two of our E-M Solutions factories. Gross margin for the RF&S Components reportable segment decreased to 52.4% for the second quarter of 2021 from 57.3% for the second quarter of 2020, primarily due to unfavorable product mix.

[0001564590-21-040796:mdna:35]
Overall gross margin decreased to 16.6% for the first two quarters of 2021 from 17.0% for the first two quarters of 2020. This decrease was primarily driven by a decrease in gross margin for the PCB reportable segment to 16.6% for the first two quarters of 2021 from 18.2% for the first two quarters of 2020. This decline was primarily due to unfavorable foreign exchange rates which increased our cost of operations, higher raw material costs due to increased commodity prices, primarily copper, and production and labor inefficiencies related to COVID-19. We were able to mitigate most of these costs through higher revenue and production and spending efficiencies including savings from the closure of two of our E-M Solutions factories. Gross margin for the RF&S Components reportable segment decreased to 52.0% for the first two quarters of 2021 from 52.3% for the first two quarters of 2020, primarily due to unfavorable product mix partially offset by higher sales.

[0001564590-21-040796:mdna:36]
Capacity utilization is a key driver for us, which is measured by actual production as a percentage of maximum capacity. This measure is particularly important in our high-volume facilities in Asia, as a significant portion of our operating costs are fixed in nature. Capacity utilization for the second quarter of 2021 in our Asia and North America PCB facilities was 88% and 49%, respectively, compared to 70% and 63%, respectively, for the second quarter of 2020. Capacity utilization for the first two quarters of 2021 in our Asia and North America PCB facilities was 84% and 52%, respectively, compared to 61% and 65%, respectively for the first two quarters of 2020. The increase in capacity utilization in our Asia PCB facilities was due to an increase in production resulting from increased sales in our Automotive and Data Center Computing end markets. The decrease in our capacity utilization in our North America PCB facilities was due to increased capacity resulting from equipment expansion in the second quarter of 2021 and production inefficiencies related to COVID-19.

[0001564590-21-040796:mdna:37]
[same as prior period, unchanged from 0001564590-21-024040:mdna:35]

[0001564590-21-040796:mdna:38]
Selling and marketing expenses decreased $1.4 million, to $14.6 million for the second quarter of 2021 from $16.0 million for the second quarter of 2020. As a percentage of net sales, selling and marketing expenses was 2.6% for the second quarter of 2021, as compared to 2.8% for the second quarter of 2020. The decrease in selling and marketing expense for the second quarter of 2021 was primarily due to a decrease in commission expense.

[0001564590-21-040796:mdna:39]
Selling and marketing expenses decreased $1.3 million, to $30.9 million for the first two quarters of 2021 from $32.1 million for the first two quarters of 2020. As a percentage of net sales, selling and marketing expenses was 2.8% for the first two quarters of 2021, as compared to 3.0% for the first two quarters of 2020. The decrease in selling and marketing expense for the first two quarters of 2021 was primarily due to a decrease in commission expense and reduced travel costs due to the COVID-19 pandemic, which has decreased travel on what we believe to be a temporary basis.

[0001564590-21-040796:mdna:40]
[same as prior period, unchanged from 0001564590-21-024040:mdna:37]

[0001564590-21-040796:mdna:41]
General and administrative expenses decreased $15.5 million to $31.2 million, or 5.5% of net sales, for the second quarter of 2021 from $46.7 million, or 8.2% of net sales, for the second quarter of 2020. This decrease was primarily due to a decrease in restructuring charges of $12.9 million associated with the restructuring of our E-M Solutions business unit, supplies and acquisition/integration costs.

[0001564590-21-040796:mdna:42]
General and administrative expenses decreased $18.7 million to $62.7 million, or 5.7% of net sales, for the first two quarters of 2021 from $81.4 million, or 7.6% of net sales, for the first two quarters of 2020. This decrease was primarily due to a decrease in restructuring charges of $10.0 million associated with the restructuring of our E-M Solutions business unit, supplies, acquisition/integration costs, and bad debt.

[0001564590-21-040796:mdna:43]
[same as prior period, unchanged from 0001564590-21-024040:mdna:39]

[0001564590-21-040796:mdna:44]
Other expense, net decreased $7.3 million to $10.8 million for the second quarter of 2021 from $18.1 million for the second quarter of 2020. This decrease was primarily the result of a decrease in interest expense of $7.5 million due to overall lower levels of debt outstanding and the refinancing of our bond.

[0001564590-21-040796:mdna:45]
Other expense, net decreased $0.5 million to $34.9 million for the first two quarters of 2021 from $35.4 million for the first two quarters of 2020. This decrease was primarily the result of a decrease in interest expense of $15.9 million due to overall lower levels of debt outstanding, partially offset by $15.2 million of loss on extinguishment of debt.

[0001564590-21-040796:mdna:46]
[same as prior period, unchanged from 0001564590-21-024040:mdna:41]

[0001564590-21-040796:mdna:47]
Income tax expense increased by $6.3 million to $1.8 million of tax expense for the second quarter of 2021 from $4.5 million of tax benefit for the second quarter of 2020. The increase in income tax expense for the second quarter of 2021 was primarily due to an increase in pre-tax income from continuing operations and a lower uncertain tax position release benefit due to the expiration of

[0001564590-21-040796:mdna:48]
the statute of limitation in foreign jurisdictions, partially offset by the absence of tax expense associated with the two E-M Solutions plants that we closed in 2020.

[0001564590-21-040796:mdna:49]
Income tax expense increased by $3.1 million to $0.8 million of tax expense for the first two quarters of 2021 from $2.3 million of tax benefit for the first two quarters of 2020. The increase in income tax expense for the first two quarters of 2021 was primarily due to a lower uncertain tax position release benefit due to the expiration of the statute of limitation in foreign jurisdictions, partially offset by (i) the absence of tax expense associated with the two E-M Solutions plants that we closed in 2020, and (ii) the approval of the Company’s renewal application for High and New Enterprise status for two of the Company’s manufacturing subsidiaries in China in the current year.

[0001564590-21-040796:mdna:50]
Our effective tax rate is primarily impacted by tax rates in China and Hong Kong, the U.S. federal income tax rate, apportioned state income tax rates, the generation of credits and deductions available to the Company as well as changes in valuation allowances and certain non-deductible items. We had a net deferred income tax asset of approximately $15.2 million and $10.9 million as of June 28, 2021 and June 29, 2020, respectively.

[0001564590-21-040796:mdna:51]
On March 11, 2021, the President of the United States signed the American Rescue Plan (ARP) providing additional economic relief for the disruptions caused by the COVID-19 pandemic. Accounting Standard Codification (ASC) 740, Accounting for Income Taxes, requires companies to recognize the effect of tax law changes in the period of enactment regardless of the effective date of those tax law changes. We considered the impact to our financial statements of the corporate income tax aspects of the ARP and determined the impact is not material to our financial statements.

[0001564590-21-040796:mdna:52]
[same as prior period, unchanged from 0001564590-21-024040:mdna:45]

[0001564590-21-040796:mdna:53]
[same as prior period, unchanged from 0001564590-21-024040:mdna:46]

[0001564590-21-040796:mdna:54]
Cash flow provided by operating activities for continuing operations during the first two quarters of 2021 was $98.1 million as compared to cash flow provided by operating activities for continuing operations of $107.4 million in the same period in 2020. The decrease in cash flow was primarily due to increased investment in working capital, partially offset by an increase in net income from continuing operations of $18.9 million.

[0001564590-21-040796:mdna:55]
Net cash used in investing activities for continuing operations was approximately $43.7 million for the first two quarters of 2021, reflecting $44.6 million for purchases of property, plant and equipment and other assets less $0.9 million for proceeds from sale of property, plant and equipment and other assets. Net cash used in investing activities for continuing operations was approximately $45.3 million for the first two quarters of 2020, reflecting purchases of property, plant and equipment and other assets.

[0001564590-21-040796:mdna:56]
Net cash provided by financing activities for continuing operations during the first two quarters of 2021 was $52.0 million, primarily reflecting proceeds from long-term debt borrowing of $500.0 million, less the repayment of long-term debt borrowings of $425.8 million, capital equipment financing of $7.1 million, repurchases of common stock of $6.1 million, payment of debt issuance costs of $5.8 million, and cash used to settle warrants of $3.1 million. There was no activity related to cash flows from financing activities for the first two quarters of 2020.

[0001564590-21-040796:mdna:57]
As of June 28, 2021, we had cash and cash equivalents of approximately $558.3 million, of which approximately $238.9 million was held by our foreign subsidiaries, primarily in China. Should we choose to remit cash to the United States from our foreign locations, we may incur tax obligations which would reduce the amount of cash ultimately available to the United States. However, we believe there would be no material tax consequences not previously accrued for on the repatriation of this cash.

[0001564590-21-040796:mdna:58]
Our total 2021 capital expenditures are expected to be in the range of $80.0 million to $90.0 million.

[0001564590-21-040796:mdna:59]
[same as prior period, unchanged from 0001564590-21-024040:mdna:53]

[0001564590-21-040796:mdna:60]
As of June 28, 2021, we had $926.5 million of outstanding debt, net of discount and debt issuance costs, composed of $493.7 million of Senior Notes due March 2029, $402.8 million of a Term Loan due September 2024, and $30.0 million under the Asia Asset-Based Lending Credit Agreement (Asia ABL).

[0001564590-21-040796:mdna:61]
Pursuant to the terms of the Term Loan Facility and Senior Notes due 2029, we are subject to certain affirmative and negative covenants, including limitations on indebtedness, corporate transactions, investments, dispositions, and share payments. Under the occurrence of certain events, as a result of the U.S. Asset-Based Lending Credit Agreement (U.S. ABL) and Asia ABL (collectively, the ABL Revolving Loans), we are also subject to various financial covenants, including leverage and fixed charge coverage ratios. As of June 28, 2021, we were in compliance with the covenants under the Term Loan Facility, Senior Notes due 2029 and ABL Revolving Loans.

[0001564590-21-040796:mdna:62]
[same as prior period, unchanged from 0001564590-21-024040:mdna:56]

[0001564590-21-040796:mdna:63]
[same as prior period, unchanged from 0001564590-21-024040:mdna:57]

[0001564590-21-040796:mdna:64]
The following table provides information on our contractual obligations as of June 28, 2021:

[0001564590-21-040796:mdna:65]
|  |  | Total |  |  | Less Than 1 Year |  |  | 1 - 3 Years |  |  | 4 - 5 Years |  |  | After 5 Years |  |
| Contractual Obligations (1) |  | (In thousands) |  |
| Long-term debt obligations |  | $ | 935,879 |  |  | $ | — |  |  | $ | 30,000 |  |  | $ | 405,879 |  |  | $ | 500,000 |  |
| Interest on debt obligations (2) |  |  | 195,697 |  |  |  | 32,469 |  |  |  | 62,255 |  |  |  | 42,584 |  |  |  | 58,389 |  |
| Derivative liabilities |  |  | 10,047 |  |  |  | 10,047 |  |  |  | — |  |  |  | — |  |  |  | — |  |
| Purchase obligations |  |  | 151,206 |  |  |  | 123,607 |  |  |  | 18,938 |  |  |  | 718 |  |  |  | 7,943 |  |
| Total contractual obligations |  | $ | 1,292,829 |  |  | $ | 166,123 |  |  | $ | 111,193 |  |  | $ | 449,181 |  |  | $ | 566,332 |  |

[0001564590-21-040796:mdna:66]
| (1) | Unrecognized uncertain tax benefits of $1.6 million are not included in the table above as the settlement timing is uncertain. Operating leases are not included in the table above – see Part I, Item 1, Note 3, Leases, of the Notes to Consolidated Condensed Financial Statements included in this Quarterly Report on Form 10-Q for further details. |

[0001564590-21-040796:mdna:67]
| (2) | For debt obligations based on variable rates, interest rates used are as of June 28, 2021. |

[0001564590-21-040796:mdna:68]
[same as prior period, unchanged from 0001564590-21-024040:mdna:61]

[0001564590-21-040796:mdna:69]
[same as prior period, unchanged from 0001564590-21-024040:mdna:62]

[0001564590-21-040796:mdna:70]
[same as prior period, unchanged from 0001564590-21-024040:mdna:63]

[0001564590-21-040796:mdna:71]
Historically, we experienced significant seasonality in revenues with a softer first half and ramping volumes in the third quarter which usually peaked in the fourth quarter. Post the Mobility divestiture, this pattern has changed. Barring end market demand changes, we now tend to experience modest seasonal softness in the first and third quarters due to holidays and vacation periods in China and North America, respectively which limit production leading to stronger revenue levels in the second and fourth quarters.

[0001564590-21-040796:mdna:72]
Recently Issued Accounting Standards

[0001564590-21-040796:mdna:73]
[same as prior period, unchanged from 0001564590-21-024040:mdna:66]
