# TTMI note change history — 0001193125-17-251481 → 0001193125-17-337320


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2017-11-08):
[0001193125-17-337320:note_history:1]
The Company is subject to various legal matters, which it
 considers normal for its business activities. While the Company
 currently believes that the amount of any reasonably possible loss
 for known matters would not be material to the Company’s
 financial condition, the outcome of these actions is inherently
 difficult to predict. In the event of an adverse outcome, the
 ultimate potential loss could have a material adverse effect on the
 Company’s financial condition or results of operations in a
 particular period. The Company has accrued amounts for its loss
 contingencies which are probable and estimable as of
 October 2, 2017 and January 2, 2017. However, these
 amounts are not material to the consolidated condensed financial
 statements of the Company.
  (was, 2017-08-08, similarity 0.9927):
[0001193125-17-251481:note_history:1]
The Company is subject to various legal matters, which it
 considers normal for its business activities. While the Company
 currently believes that the amount of any reasonably possible loss
 for known matters would not be material to the Company’s
 financial condition, the outcome of these actions is inherently
 difficult to predict. In the event of an adverse outcome, the
 ultimate potential loss could have a material adverse effect on the
 Company’s financial condition or results of operations in a
 particular period. The Company has accrued amounts for its loss
 contingencies which are probable and estimable as of July 3,
 2017 and January 2, 2017. However, these amounts are not
 material to the consolidated condensed financial statements of the
 Company.

- added (2017-11-08):
[0001193125-17-337320:note_history:2]
The process to manufacture PCBs requires adherence to domestic
 and foreign jurisdictional environmental laws regulations regarding
 the storage, use, handling, recycling and disposal of liquid and
 solid wastes, as well as compliance with air quality standards and
 chemical use reporting. The Company believes that its facilities in
 North America comply in all material respects with applicable
 environmental laws and regulations. In China, governmental
 authorities have adopted new rules and regulations governing
 environmental issues. The Company believes it has developed plans
 acceptable to the Chinese government and is in the process of
 implementing these plans. The Company does not anticipate any
 immediate risk of government fines or temporary closure of its
 Chinese plants. The Company has established and enacted an
 investment plan related to the efforts to come into full compliance
 with the new regulations in a timely fashion. The 2017 capital
 expenditure costs expected for these plans are included in the
 Company’s capital expenditure projections.

- removed (2017-11-08):
[0001193125-17-251481:note_history:3]
The process to manufacture PCBs requires adherence to city,
 county, state, federal, and foreign environmental regulations
 regarding the storage, use, handling and disposal of chemicals,
 solid wastes and other hazardous materials, as well as compliance
 with air quality standards and chemical use reporting. The Company
 believes that its facilities in the United States and Canada comply
 in all material respects with applicable environmental laws and
 regulations. In China, governmental authorities have adopted new
 rules and regulations governing environmental issues. An update to
 the Chinese environmental waste water law was issued in late 2012,
 allowing for an interim period in which plants subject to such law
 may install equipment that meets the new regulatory regime. Some of
 the Company’s plants in China are not yet in full compliance
 with the updated environmental regulations. The Company believes it
 has developed plans acceptable to the Chinese government and is in
 the process of implementing these plans. The Company does not
 anticipate any immediate risk of government fines or temporary
 closure of its Chinese plants. The Company has established and
 enacted an investment plan related to the efforts to come into full
 compliance with the new regulations in a timely fashion. The 2017
 capital expenditure costs expected for these plans are included in
 the Company’s capital expenditure projections.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- added (2017-11-08):
[0001193125-17-337320:note_history:4]
TTM Technologies, Inc. (the Company or TTM) is a leading global
 printed circuit board (PCB) manufacturer, focusing on quick-turn
 and volume production of technologically complex PCBs and
 electro-mechanical solutions (E-M Solutions). The Company provides
 time-to-market and volume
 production of advanced technology products and offers a
 one-stop manufacturing
 solution to customers from engineering support to prototype
 development through final mass production. This one-stop manufacturing solution
 enables the Company to align technology developments with the
 diverse needs of the Company’s customers and to enable them
 to reduce the time required to develop new products and bring them
 to market.

- changed (2017-11-08):
[0001193125-17-337320:note_history:5]
The Company serves a diversified customer base in various
 markets throughout the world, including aerospace and defense,
 automotive components, smartphones and touchscreen tablets,
 high-end computing,
 medical, industrial and instrumentation related products, as well
 as networking/communications infrastructure products. The
 Company’s customers include both original equipment
 manufacturers (OEMs) and electronic manufacturing services (EMS)
 providers.
  (was, 2017-08-08, similarity 0.6734):
[0001193125-17-251481:note_history:5]
The Company serves a diversified customer base in various
 markets throughout the world, including networking/communications
 infrastructure products, smartphones and touchscreen tablets, as
 well as aerospace and defense, automotive, high-end computing, and medical,
 industrial and instrumentation related products. The
 Company’s customers include both original equipment
 manufacturers (OEMs) and electronic manufacturing services (EMS)
 providers.

- added (2017-11-08):
[0001193125-17-337320:note_history:6]
In August 2017, the Financial Accounting Standards Board (FASB)
 issued Accounting Standards Update (ASU) 2017-12, Derivatives and Hedging
 (Topic 815): Targeted Improvements to Accounting for Hedging
 Activities. This ASU amends and simplifies existing guidance in
 order to allow companies to more accurately present the economic
 effects of risk management activities in the financial statements.
 ASU 2017-12 also amends
 the guidance surrounding the recognition of the value of hedged
 instruments to include the entire change in value, rather than just
 the effective portion, in other comprehensive income and recognized
 in earnings at the same time that the hedged item affects earnings
 for cash flow and net investment hedges. This ASU is effective for
 fiscal years beginning after December 15, 2018, including
 interim periods within those fiscal years. Early adoption is
 permitted. The Company is currently evaluating the new guidance to
 determine the impact it may have on its consolidated condensed
 financial statements and related disclosures.

- changed (2017-11-08):
[0001193125-17-337320:note_history:7]
In January 2017, the FASB issued ASU 2017-04, Intangibles (Topic 350):
 Goodwill and Other. This ASU simplifies the accounting for
 goodwill impairment and removes Step 2 of the goodwill impairment
 test. Goodwill impairment will now be the amount by which a
 reporting unit’s carrying value exceeds its fair value
 limited to the total amount of goodwill allocated to that reporting
 unit. Entities will continue to have the option to perform a
 qualitative assessment to determine if a quantitative impairment
 test is necessary. The Company elected to early adopt ASU
 2017-04 on a prospective
 basis during the second quarter of 2017, and the adoption did
 not have a material impact on its consolidated condensed financial
 statements and related disclosures.
  (was, 2017-08-08, similarity 0.9381):
[0001193125-17-251481:note_history:7]
In January 2017, the Financial Accounting Standards Board
 (FASB) issued Accounting Standards Update (ASU) 2017-04, Intangibles (Topic 350):
 Goodwill and other. This ASU simplifies the accounting for
 goodwill impairment and removes Step 2 of the goodwill impairment
 test. Goodwill impairment will now be the amount by which a
 reporting unit’s carrying value exceeds its fair value
 limited to the total amount of goodwill allocated to that reporting
 unit. Entities will continue to have the option to perform a
 qualitative assessment to determine if a quantitative impairment
 test is necessary. The Company elected to early adopt
 ASU 2017-04 on a prospective basis during
 the second quarter of 2017, and the adoption did not have a
 material impact on its consolidated condensed financial statements
 and related disclosures.

- changed (2017-11-08):
[0001193125-17-337320:note_history:8]
In October 2016, the FASB issued ASU 2016-16, Income Taxes (Topic 740):
 Intra-Entity Transfers of Assets Other Than Inventory. The
 objective of this update is to improve the accounting for the
 income tax consequences of intra-entity transfers of assets other
 than inventory by recognizing the income tax consequences when the
 transfer occurs. This ASU is effective for fiscal years beginning
 after December 15, 2017, including interim periods within
 those fiscal years. Early adoption is permitted. The adoption of
 this standard is not expected to have a material impact on the
 Company’s consolidated condensed financial statements or
 related disclosures.
  (was, 2017-08-08, similarity 0.7762):
[0001193125-17-251481:note_history:8]
In October 2016, the FASB issued ASU 2016-16, Income Taxes (Topic 740):
 Intra-Entity Transfers of Assets Other Than Inventory. The objective of this
 update is to improve the accounting for the income tax consequences
 of intra-entity transfers of assets other than inventory by
 recognizing the income tax consequences when the transfer occurs.
 This ASU is effective for fiscal years beginning after
 December 15, 2017, including interim periods within those
 fiscal years. Early adoption is permitted. The Company is currently
 evaluating the new guidance to determine the impact it may have on
 its consolidated condensed financial statements.

- changed (2017-11-08):
[0001193125-17-337320:note_history:9]
In February 2016, the FASB issued ASU 2016-02, Leases (Topic 842).
 The objective of this update is to increase transparency and
 comparability among organizations by recognizing lease assets and
 lease liabilities on the balance sheet and disclosing key
 information about leasing arrangements. This ASU is effective for
 fiscal years beginning after December 15, 2018, including
 interim periods within those annual periods and is to be applied
 utilizing a modified retrospective approach. While the Company
 continues to evaluate the new guidance to determine the impact it
 may have on its consolidated condensed financial statements and
 related disclosures, the primary effect of adopting this update
 will be to record assets and obligations for current operating
 leases.
  (was, 2017-08-08, similarity 0.69):
[0001193125-17-251481:note_history:9]
In February 2016, the FASB issued ASU 2016-02, Leases (Topic 842). The
 objective of this update is to increase transparency and
 comparability among organizations by recognizing lease assets and
 lease liabilities on the balance sheet and disclosing key
 information about leasing arrangements. This ASU is effective for
 fiscal years beginning after December 15, 2018, including
 interim periods within those annual periods and is to be applied
 utilizing a modified retrospective approach. The Company is
 currently evaluating the new guidance to determine the impact it
 may have on its consolidated financial statements and related
 disclosures.

- added (2017-11-08):
[0001193125-17-337320:note_history:10]
In January 2016, the FASB issued ASU 2016-01, Financial
 Instruments—Overall (Topic 825): Recognition and
 Measurement of Financial Assets and Financial Liabilities. This
 ASU amends certain aspects of recognition, measurement,
 presentation and disclosure of financial instruments, and
 supersedes the guidance to classify equity securities with readily
 determinable fair values into different categories (that is,
 trading or available-for-sale) and
 requires equity securities to be measured at fair value with
 changes in the fair value recognized through net income. This ASU
 is effective for annual and interim periods beginning after
 December 15, 2017. The Company does not anticipate the
 adoption will have a material impact on its consolidated condensed
 financial statements and related disclosures.

- changed (2017-11-08):
[0001193125-17-337320:note_history:11]
In May 2014, the FASB issued ASU 2014-09, Revenue from Contracts
 with Customers, as amended, which requires an entity to
 recognize the amount of revenue to which it expects to be entitled
 for the transfer of promised goods or services to customers. The
 ASU will replace most existing revenue recognition guidance in U.S.
 GAAP when it becomes effective. The new standard is effective for
 the Company at the beginning of fiscal year 2018. The standard
 permits the use of either the retrospective or cumulative effect
 transition method. The Company has assessed that the impact of the
 new guidance will result in a change to the timing of revenue
 recognition for the Company’s revenue stream from
 “point in time” upon physical delivery to an
 “over time” model and believes this transition could
 have a material impact on the Company’s consolidated
 financial statements upon adoption. As of October 2, 2017,
 management intends to apply the cumulative effect transition
 method. The Company has identified and implemented changes to its
 processes and internal controls to meet the standard update’s
 reporting and disclosure requirements.
  (was, 2017-08-08, similarity 0.9592):
[0001193125-17-251481:note_history:11]
In May 2014, the FASB issued ASU 2014-09, Revenue from Contracts with
 Customers, as amended, which requires an entity to recognize
 the amount of revenue to which it expects to be entitled for the
 transfer of promised goods or services to customers. The ASU will
 replace most existing revenue recognition guidance in U.S. GAAP
 when it becomes effective. The new standard is effective for the
 Company at the beginning of fiscal year 2018. The standard permits
 the use of either the retrospective or cumulative effect transition
 method. The Company has assessed that the impact of the new
 guidance will result in a change to the timing of revenue
 recognition for the Company’s revenue stream from
 “point in time” upon physical delivery to an
 “over time” model and believes this transition could
 have a material impact on the Company’s consolidated
 financial statements upon adoption. As of July 3, 2017,
 management intends to apply the cumulative effect transition
 method. The Company has identified and is in the process of
 implementing changes to its systems, processes and internal
 controls to meet the standard update’s reporting and
 disclosure requirements.

- removed (2017-11-08):
[0001193125-17-251481:note_history:12]
TTM Technologies, Inc. (the Company or TTM) is a leading global
 printed circuit board (PCB) manufacturer, focusing on quick-turn
 and volume production of technologically complex PCBs and
 electro-mechanical solutions (E-M Solutions). The Company
 provides time-to-market and advanced technology
 products and offers a one-stop manufacturing solution to
 customers from engineering support to prototype development through
 final mass production. This one-stop manufacturing solution allows
 the Company to align technology developments with the diverse needs
 of the Company’s customers and to enable them to reduce the
 time required to develop new products and bring them to
 market.


## ttmi:ScheduleOfComponentsOfInterestExpenseFromConvertibleNotesTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2017-11-08):
[0001193125-17-337320:note_history:13]
The components of interest expense resulting from the
 convertible senior notes for the quarters and three quarters ended
 October 2, 2017 and September 26, 2016 are as
 follows:
  (was, 2017-08-08, similarity 0.913):
[0001193125-17-251481:note_history:13]
The components of interest expense resulting from the
 convertible senior notes for the quarters and two quarters ended
 July 3, 2017 and June 27, 2016 are as follows:

- added (2017-11-08):
[0001193125-17-337320:note_history:14]
|  |  | For the Quarter Ended |  |  | For the Three Quarters Ended |  |
|  |  | October 2, 2017 |  |  | September 26, 2016 |  |  | October 2, 2017 |  |  | September 26, 2016 |  |
|  |  | (In thousands) |  |
| Contractual coupon interest |  | $ | 1,094 |  |  | $ | 1,094 |  |  | $ | 3,281 |  |  | $ | 3,281 |  |
| Amortization of debt discount |  | $ | 2,159 |  |  | $ | 2,025 |  |  | $ | 6,376 |  |  | $ | 5,977 |  |
| Amortization of debt issuance costs |  | $ | 216 |  |  | $ | 202 |  |  | $ | 639 |  |  | $ | 599 |  |

- removed (2017-11-08):
[0001193125-17-251481:note_history:15]
|  |  | For the Quarter Ended |  |  | For the Two Quarters Ended |  |
|  |  | July 3, 2017 |  |  | June 27, 2016 |  |  | July 3, 2017 |  |  | June 27, 2016 |  |
|  |  | (In thousands) |  |
| Contractual coupon interest |  | $ | 1,093 |  |  | $ | 1,093 |  |  | $ | 2,187 |  |  | $ | 2,187 |  |
| Amortization of debt discount |  | $ | 2,125 |  |  | $ | 1,992 |  |  | $ | 4,216 |  |  | $ | 3,952 |  |
| Amortization of debt issuance costs |  | $ | 214 |  |  | $ | 200 |  |  | $ | 423 |  |  | $ | 396 |  |


## ttmi:ScheduleOfUnamortizedDiscountAndDebtIssuanceCostsTableTextBlock (debt) — matched_by: no_prior_note, score: 0.0

- added (2017-11-08):
[0001193125-17-337320:note_history:16]
As of October 2, 2017 and January 2, 2017, remaining
 unamortized debt discount and debt issuance costs for the Term Loan
 Facility, Senior Notes, Convertible Senior Notes and 2016 Term Loan
 are as follows:

- added (2017-11-08):
[0001193125-17-337320:note_history:17]
|  |  | As of October 2, 2017 |  |  | As of January 2, 2017 |  |
|  |  | Debt Issuance Costs |  |  | Debt Discount |  |  | Effective Interest Rate |  |  | Debt Issuance Costs |  |  | Debt Discount |  |  | Effective Interest Rate |  |
|  |  | (in thousands) |  |
| Term Loan due September 2024 |  | $ | 2,803 |  |  | $ | 1,750 |  |  |  | 3.95 | % |  |  | — |  |  |  | — |  |  |  | — |  |
| Senior Notes due October 2025 |  |  | 6,849 |  |  |  | — |  |  |  | 5.91 | % |  |  | — |  |  |  | — |  |  |  | — |  |
| Convertible Senior Notes |  |  | 3,108 |  |  |  | 31,014 |  |  |  | 6.48 | % |  | $ | 3,747 |  |  | $ | 37,392 |  |  |  | 6.48 | % |
| Term Loan due May 2021 |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 977 |  |  |  | — |  |  |  | 5.48 | % |
|  |  | $ | 12,760 |  |  | $ | 32,764 |  |  |  |  |  |  | $ | 4,724 |  |  | $ | 37,392 |  |  |  |  |  |


## us-gaap:ConvertibleDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2017-11-08):
[0001193125-17-337320:note_history:18]
As of October 2, 2017 and January 2, 2017, the
 following summarizes the equity components of the convertible
 senior notes included in additional paid-in capital:
  (was, 2017-08-08, similarity 0.9635):
[0001193125-17-251481:note_history:18]
As of July 3, 2017 and January 2, 2017, the following
 summarizes the equity components of the convertible senior notes
 included in additional paid-in capital:

- changed (2017-11-08):
[0001193125-17-337320:note_history:19]
|  |  | As of October 2, 2017 |  |  | As of January 2, 2017 |  |
|  |  | Embedded conversion option — Convertible Senior Notes |  |  | Embedded conversion option — Convertible Senior Notes Issuance Costs |  |  | Total |  |  | Embedded conversion option — Convertible Senior Notes |  |  | Embedded conversion option — Convertible Senior Notes Issuance Costs |  |  | Total |  |
|  |  | (in thousands) |  |
| Convertible senior notes due 2020 |  | $ | 60,216 |  |  | $ | (1,916 | ) |  | $ | 58,300 |  |  | $ | 60,227 |  |  | $ | (1,916 | ) |  | $ | 58,311 |  |
  (was, 2017-08-08, similarity 0.9887):
[0001193125-17-251481:note_history:19]
|  |  | As of July 3, 2017 |  |  | As of January 2, 2017 |  |
|  |  | Embedded conversion option — Convertible Senior Notes |  |  | Embedded conversion option — Convertible Senior Notes Issuance Costs |  |  | Total |  |  | Embedded conversion option — Convertible Senior Notes |  |  | Embedded conversion option — Convertible Senior Notes Issuance Costs |  |  | Total |  |
|  |  | (in thousands) |  |
| Convertible senior notes due 2020 |  | $ | 60,216 |  |  | $ | (1,916 | ) |  | $ | 58,300 |  |  | $ | 60,227 |  |  | $ | (1,916 | ) |  | $ | 58,311 |  |


## us-gaap:LongTermDebtTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2017-11-08):
[0001193125-17-337320:note_history:20]
The following table summarizes the long-term debt of the
 Company as of October 2, 2017 and January 2,
 2017:
  (was, 2017-08-08, similarity 0.9436):
[0001193125-17-251481:note_history:20]
The following table summarizes the long-term debt of the
 Company as of July 3, 2017 and January 2,
 2017:

- added (2017-11-08):
[0001193125-17-337320:note_history:21]
|  |  | Interest Rate as of October 2, 2017 |  |  | Principal Outstanding as of October 2, 2017 |  |  | Interest Rate as of January 2, 2017 |  |  | Principal Outstanding as of January 2, 2017 |  |
|  |  | (In thousands) |  |
| Term Loan due September 2024 |  |  | 3.73 | % |  | $ | 350,000 |  |  |  | — |  |  |  | — |  |
| Senior Notes due October 2025 |  |  | 5.63 | % |  |  | 375,000 |  |  |  | — |  |  |  | — |  |
| Term Loan due May 2021 |  |  | — |  |  |  | — |  |  |  | 5.25 | % |  | $ | 700,000 |  |
| Convertible Senior Notes due December 2020 |  |  | 1.75 | % |  |  | 249,985 |  |  |  | 1.75 | % |  |  | 250,000 |  |
| U.S. ABL Revolving Loan due May 2020 |  |  | 2.73 | % |  |  | 17,000 |  |  |  | 2.27 | % |  |  | 80,000 |  |
| Asia ABL Revolving Loan due May 2020 |  |  | 2.63 | % |  |  | 30,000 |  |  |  | 2.17 | % |  |  | 30,000 |  |
| Capital Lease |  |  | 6.43 | % |  |  | 1,884 |  |  |  | 6.43 | % |  |  | 1,798 |  |
|  |  |  |  |  |  |  | 1,023,869 |  |  |  |  |  |  |  | 1,061,798 |  |
| Less: Long-term debt unamortized discount |  |  |  |  |  |  | (32,764 | ) |  |  |  |  |  |  | (37,392 | ) |
| Long-term debt unamortized debt issuance costs |  |  |  |  |  |  | (12,760 | ) |  |  |  |  |  |  | (4,724 | ) |
|  |  |  |  |  |  |  | 978,345 |  |  |  |  |  |  |  | 1,019,682 |  |
| Less: current maturities |  |  |  |  |  |  | (4,184 | ) |  |  |  |  |  |  | (110,652 | ) |
| Long-term debt, less current maturities |  |  |  |  |  | $ | 974,161 |  |  |  |  |  |  | $ | 909,030 |  |

- added (2017-11-08):
[0001193125-17-337320:note_history:22]
On September 28, 2017, the Company entered into a $350,000
 Term Loan Facility due 2024 (Term Loan Facility), and issued
 $375,000 of Senior Notes due 2025 (Senior Notes). In conjunction
 with the issuance of the Term Loan Facility and Senior Notes, the
 Company repaid in full the remaining outstanding balance of the
 September 27, 2016 Term Loan Credit Agreement (2016 Term Loan)
 and repaid $63,000 on its existing U.S. Asset-Based Lending Credit
 Agreement. The Company recognized a loss on extinguishment of debt
 of $768 primarily associated with the write off of the remaining
 2016 Term Loan debt issuance costs.

- added (2017-11-08):
[0001193125-17-337320:note_history:23]
Term Loan
 Facility

- added (2017-11-08):
[0001193125-17-337320:note_history:24]
The Term Loan Facility, of which $3,500 is included in
 short-term debt and $346,500 is included in long-term debt, was
 issued at a discount at 99.5% and bears interest, at the
 Company’s option, at a floating rate of LIBOR, plus an
 applicable interest margin of 2.5%, or an alternate base rate,
 (defined as the greater of the JP Morgan prime, the New York Fed
 bank rate plus 0.9% or LIBOR plus 1.0%), subject to a 1.0% floor
 plus an applicable margin of 1.5%. At October 2, 2017 the
 interest rate on the outstanding borrowings under the Term Loan
 Facility was 3.73%. There is no provision, other than an event of
 default, for the interest margin to increase. The Term Loan
 Facility will mature on September 28, 2024. The Term Loan
 Facility is secured by a significant amount of the assets of the
 Company and a pledge of 65% of voting stock of the Company’s
 first tier foreign subsidiaries and is structurally senior to the
 Company’s Senior Notes and Convertible Senior Notes. See
 Senior Notes and Convertible Senior Notes below.

- added (2017-11-08):
[0001193125-17-337320:note_history:25]
The Company is required to make scheduled payments of the
 outstanding Term Loan Facility balance on a quarterly basis
 beginning January 1, 2018. Based on certain parameters defined
 in the Term Loan Facility, including a First Lien Leverage Ratio,
 the Company may be required to make an additional principal payment
 on an annual basis beginning after fiscal year 2018, if the
 Company’s First Lien Leverage Ratio is greater than 2.0. Any
 additional annual payments or prepayments would reduce future
 required scheduled payments. Any remaining outstanding balances
 under the Term Loan Facility are due at the maturity date of
 September 28, 2024.

- added (2017-11-08):
[0001193125-17-337320:note_history:26]
Borrowings under the Term Loan Facility are subject to certain
 affirmative and negative covenants, including limitations on
 indebtedness, corporate transactions, investments and dispositions,
 and share payments. The Company and its domestic subsidiaries have
 fully and unconditionally guaranteed the full and timely payment of
 Term Loan Facility related obligations.

- added (2017-11-08):
[0001193125-17-337320:note_history:27]
Senior
 Notes

- added (2017-11-08):
[0001193125-17-337320:note_history:28]
The $375,000 of Senior Notes issued, which is included in
 long-term debt, bear interest at a rate of 5.63% per annum.
 Interest is payable semiannually in arrears on April 1 and
 October 1 of each year beginning April 1, 2018. The
 Senior Notes will mature on October 1, 2025. The Senior Notes
 are unsecured obligations and are guaranteed by the Company’s
 subsidiaries that guarantee its senior secured credit facilities,
 subject to certain exceptions.

- added (2017-11-08):
[0001193125-17-337320:note_history:29]
Borrowings under the Senior Notes are subject to certain
 affirmative and negative covenants, including limitations on
 indebtedness, corporate transactions, investments and dispositions,
 and share payments.

- changed (2017-11-08):
[0001193125-17-337320:note_history:30]
The Company maintains 1.75% convertible senior notes in the
 amount of $249,985 due December 15, 2020. The convertible
 senior notes bear interest at a rate of 1.75% per annum.
 Interest is payable semiannually in arrears on June 15 and
 December 15 of each year. The convertible senior notes are
 unsecured obligations, are subordinated to the Senior Notes above,
 and would rank equally to the Company’s future unsecured
 senior indebtedness and are senior in right of payment to any of
 the Company’s future subordinated indebtedness.
  (was, 2017-08-08, similarity 0.9343):
[0001193125-17-251481:note_history:30]
The Company maintains 1.75% convertible senior notes in the
 amount of $249,985 due December 15, 2020. The convertible
 senior notes bear interest at a rate of 1.75% per annum.
 Interest is payable semiannually in arrears on June 15 and
 December 15 of each year. The convertible senior notes are
 senior unsecured obligations and rank equally to the
 Company’s future unsecured senior indebtedness and are senior
 in right of payment to any of the Company’s future
 subordinated indebtedness.

- changed (2017-11-08):
[0001193125-17-337320:note_history:31]
As of October 2, 2017 and January 2, 2017, the
 following summarizes the equity components of the convertible
 senior notes included in additional paid-in capital:
  (was, 2017-08-08, similarity 0.9635):
[0001193125-17-251481:note_history:31]
As of July 3, 2017 and January 2, 2017, the following
 summarizes the equity components of the convertible senior notes
 included in additional paid-in capital:

- changed (2017-11-08):
[0001193125-17-337320:note_history:32]
|  |  | As of October 2, 2017 |  |  | As of January 2, 2017 |  |
|  |  | Embedded conversion option — Convertible Senior Notes |  |  | Embedded conversion option — Convertible Senior Notes Issuance Costs |  |  | Total |  |  | Embedded conversion option — Convertible Senior Notes |  |  | Embedded conversion option — Convertible Senior Notes Issuance Costs |  |  | Total |  |
|  |  | (in thousands) |  |
| Convertible senior notes due 2020 |  | $ | 60,216 |  |  | $ | (1,916 | ) |  | $ | 58,300 |  |  | $ | 60,227 |  |  | $ | (1,916 | ) |  | $ | 58,311 |  |
  (was, 2017-08-08, similarity 0.9887):
[0001193125-17-251481:note_history:32]
|  |  | As of July 3, 2017 |  |  | As of January 2, 2017 |  |
|  |  | Embedded conversion option — Convertible Senior Notes |  |  | Embedded conversion option — Convertible Senior Notes Issuance Costs |  |  | Total |  |  | Embedded conversion option — Convertible Senior Notes |  |  | Embedded conversion option — Convertible Senior Notes Issuance Costs |  |  | Total |  |
|  |  | (in thousands) |  |
| Convertible senior notes due 2020 |  | $ | 60,216 |  |  | $ | (1,916 | ) |  | $ | 58,300 |  |  | $ | 60,227 |  |  | $ | (1,916 | ) |  | $ | 58,311 |  |

- changed (2017-11-08):
[0001193125-17-337320:note_history:33]
The components of interest expense resulting from the
 convertible senior notes for the quarters and three quarters ended
 October 2, 2017 and September 26, 2016 are as
 follows:
  (was, 2017-08-08, similarity 0.913):
[0001193125-17-251481:note_history:33]
The components of interest expense resulting from the
 convertible senior notes for the quarters and two quarters ended
 July 3, 2017 and June 27, 2016 are as follows:

- added (2017-11-08):
[0001193125-17-337320:note_history:34]
|  |  | For the Quarter Ended |  |  | For the Three Quarters Ended |  |
|  |  | October 2, 2017 |  |  | September 26, 2016 |  |  | October 2, 2017 |  |  | September 26, 2016 |  |
|  |  | (In thousands) |  |
| Contractual coupon interest |  | $ | 1,094 |  |  | $ | 1,094 |  |  | $ | 3,281 |  |  | $ | 3,281 |  |
| Amortization of debt discount |  | $ | 2,159 |  |  | $ | 2,025 |  |  | $ | 6,376 |  |  | $ | 5,977 |  |
| Amortization of debt issuance costs |  | $ | 216 |  |  | $ | 202 |  |  | $ | 639 |  |  | $ | 599 |  |

- added (2017-11-08):
[0001193125-17-337320:note_history:35]
Asset-Based Lending
 Agreements

- changed (2017-11-08):
[0001193125-17-337320:note_history:36]
The Company continues to maintain a $200,000 U.S. Asset-Based
 Lending Credit Agreement (U.S. ABL), and a $150,000 Asia
 Asset-Based Lending Credit Agreement (Asia ABL) (collectively the
 ABL Revolving Loans).
  (was, 2017-08-08, similarity 0.8278):
[0001193125-17-251481:note_history:36]
The Company maintains a Term Loan Credit Agreement (Term Loan),
 a $200,000 U.S. Asset-Based Lending Credit Agreement (U.S. ABL),
 and a $150,000 Asia Asset-Based Lending Credit Agreement (Asia ABL)
 (collectively the ABL Revolving Loans).

- changed (2017-11-08):
[0001193125-17-337320:note_history:37]
The U.S. ABL consists of three tranches comprised of a
 revolving credit facility of up to $200,000, a letter of credit
 facility of up to $50,000, and swingline loans of up to $30,000,
 provided that at no time may amounts outstanding under the tranches
 exceed in aggregate $200,000 or the applicable borrowing base,
 which is a percentage of the principal amount of Eligible Accounts,
 as defined in the U.S. ABL agreement. Borrowings under the U.S. ABL
 bear interest at either a floating rate of LIBOR plus a margin of
 150 basis points or JP Morgan Chase Bank’s prime rate plus a
 margin of 50 basis points, at the Company’s option. At
 October 2, 2017, the interest rate on the outstanding
 borrowings under the U.S. ABL was 2.73%. The applicable margin can
 vary based on the remaining availability of the facility, from 125
 to 175 basis points for LIBOR-based loans and from 25 to 75 basis
 points for JP Morgan Chase Bank’s prime rate-based loans.
 Other than availability and an event of default, there are no other
 provisions for the interest margin to increase. The U.S. ABL will
 mature on May 31, 2020. Loans made under the U.S. ABL are
 secured first by all of the Company’s domestic cash,
 receivables and inventories as well as by a second position against
 a significant amount of the assets of the Company and a pledge of
 65% of voting stock of the Company’s first tier foreign
 subsidiaries and are structurally senior to the Company’s
 Senior Notes and Convertible Senior Notes. See Senior Notes and
 Convertible Senior Notes above. As noted earlier, concurrent with
 the issuance of the Term Loan Facility and Senior Notes, the
 Company paid down $63,000 of the outstanding balance of its U.S.
 ABL. The Company and its domestic subsidiaries have fully and
 unconditionally guaranteed the full and timely payment of U.S. ABL
 related obligations. At October 2, 2017, $17,000 of the U.S.
 ABL was outstanding and classified as long-term debt, which is
 consistent with its maturity date.
  (was, 2017-08-08, similarity 0.7899):
[0001193125-17-251481:note_history:37]
The U.S. ABL consists of three tranches comprised of a
 revolving credit facility of up to $200,000, a letter of credit
 facility of up to $50,000, and swingline loans of up to $30,000,
 provided that at no time may amounts outstanding under the tranches
 exceed in aggregate $200,000 or the applicable borrowing base,
 which is a percentage of the principal amount of Eligible Accounts,
 as defined in the U.S. ABL agreement. Borrowings under the U.S. ABL
 bear interest at either a floating rate of LIBOR plus a margin of
 150 basis points or JP Morgan Chase Bank’s prime rate plus a
 margin of 50 basis points, at the Company’s option. At
 July 3, 2017, the weighted average interest rate on the
 outstanding borrowings under the U.S. ABL was 2.73%. The applicable
 margin can vary based on the remaining availability of the
 facility, from 125 to 175 basis points for LIBOR-based loans and
 from 25 to 75 basis points for JP Morgan Chase Bank’s prime
 rate-based loans. Other than availability and an event of default,
 there are no other provisions for the interest margin to increase.
 The U.S. ABL will mature on May 31, 2020. Loans made under the
 U.S. ABL are secured first by all of the Company’s domestic
 cash, receivables and inventories as well as by a second position
 against a significant amount of the assets of the Company and a
 pledge of 65% of voting stock of the Company’s first tier
 foreign subsidiaries and are structurally senior to the
 Company’s convertible senior notes. See Convertible Senior
 Notes below. At July 3, 2017, $80,000 of the U.S. ABL was
 outstanding and classified as short-term debt. The Company and its
 domestic subsidiaries have fully and unconditionally guaranteed the
 full and timely payment of all Term Loan and U.S. ABL related
 obligations.

- changed (2017-11-08):
[0001193125-17-337320:note_history:38]
The Asia ABL consists of two tranches comprised of a revolving
 credit facility of up to $150,000 and a letter of credit facility
 of up to $100,000, provided that at no time may amounts outstanding
 under both tranches exceed in aggregate $150,000 or the applicable
 borrowing base, which is a percentage of the principal amount of
 Eligible Accounts, as defined in the Asia ABL agreement. Borrowings
 under the Asia ABL bear interest at a floating rate of LIBOR plus
 140 basis points. At October 2, 2017, the interest rate on the
 outstanding borrowings under the Asia ABL was 2.63%. There is no
 provision, other than an event of default, for the interest margin
 to increase. The Asia ABL will mature on May 22, 2020. Loans
 made under the Asia ABL are secured by a portion of the
 Company’s Asia Pacific cash and receivables and are
 structurally senior to the Company’s domestic obligations,
 including the Senior Notes and Convertible Senior Notes. See Senior
 Notes and Convertible Senior Notes above. The Company’s Asia
 Pacific subsidiary and certain of its subsidiaries have fully and
 unconditionally guaranteed the full and timely payment of all Asia
 ABL related obligations. At October 2, 2017, $30,000 of the
 Asia ABL was outstanding and classified as long-term debt, which is
 consistent with its maturity date.
  (was, 2017-08-08, similarity 0.7877):
[0001193125-17-251481:note_history:38]
The Asia ABL consists of two tranches comprised of a revolving
 credit facility of up to $150,000 and a letter of credit facility
 of up to $100,000, provided that at no time may amounts outstanding
 under both tranches exceed in aggregate $150,000 or the applicable
 borrowing base, which is a percentage of the principal amount of
 Eligible Accounts, as defined in the Asia ABL agreement. Borrowings
 under the Asia ABL bear interest at a floating rate of LIBOR plus
 140 basis points. At July 3, 2017, the weighted average
 interest rate on the outstanding borrowings under the Asia ABL was
 2.63%. There is no provision, other than an event of default, for
 the interest margin to increase. The Asia ABL will mature on
 May 22, 2020. Loans made under the Asia ABL are secured by a
 portion of the Company’s Asia Pacific cash and receivables
 and are structurally senior to the Company’s domestic
 obligations, including the convertible senior notes. See
 Convertible Senior Notes below. The Company’s Asia Pacific
 subsidiary and certain of its subsidiaries have fully and
 unconditionally guaranteed the full and timely payment of all Asia
 ABL related obligations. At July 3, 2017, $30,000 of the Asia
 ABL was outstanding.

- added (2017-11-08):
[0001193125-17-337320:note_history:39]
The Company has up to $50,000 and $100,000 Letters of Credit
 Facilities under the U.S. ABL and the Asia ABL, respectively. As of
 October 2, 2017 letters of credit in the amount of $7,612 were
 outstanding under the U.S. ABL and $45,026 were outstanding under
 the Asia ABL with various expiration dates through March 2019.
 Available borrowing capacity under the U.S. ABL and the Asia ABL
 was $175,388 and $74,974, respectively, which considers letters of
 credit outstanding of $7,612 and $45,026, respectively, at
 October 2, 2017.

- added (2017-11-08):
[0001193125-17-337320:note_history:40]
The Company is required to pay a commitment fee of 0.25% to
 0.375% per annum on any unused portion of the U.S ABL and the
 Asia ABL. The Company incurred total commitment fees related to
 unused borrowing availability of $179 and $171 for the quarters
 ended October 2, 2017 and September 26, 2016,
 respectively, and $546 and $516 for the three quarters ended
 October 2, 2017 and September 26, 2016,
 respectively.

- added (2017-11-08):
[0001193125-17-337320:note_history:41]
Under the occurrence of certain events, the ABL Revolving Loans
 are subject to various financial and operational covenants,
 including maintaining minimum fixed charge coverage
 ratios.

- changed (2017-11-08):
[0001193125-17-337320:note_history:42]
Additionally, the Company is party to a revolving loan credit
 facility (Chinese Revolver) with a lender in China. Under this
 arrangement, the lender has made available to the Company
 approximately $31,700 in unsecured borrowing with all terms of the
 borrowing to be negotiated at the time the Chinese Revolver is
 drawn upon. There are no commitment fees on the unused portion of
 the Chinese Revolver, and this arrangement expires in January 2018.
 As of October 2, 2017, the Chinese Revolver had not been drawn
 upon.
  (was, 2017-08-08, similarity 0.9209):
[0001193125-17-251481:note_history:42]
Additionally, the Company is party to a revolving loan credit
 facility (Chinese Revolver) with a lender in China. Under this
 arrangement, the lender has made available to the Company
 approximately $31,000 in unsecured borrowing with all terms of the
 borrowing to be negotiated at the time the Chinese Revolver is
 drawn upon. There are no commitment fees on the unused portion of
 the Chinese Revolver, and this arrangement expires in January 2018.
 As of July 3, 2017, the Chinese Revolver had not been drawn
 upon.

- added (2017-11-08):
[0001193125-17-337320:note_history:43]
Debt Issuance and
 Debt Discount

- added (2017-11-08):
[0001193125-17-337320:note_history:44]
As of October 2, 2017 and January 2, 2017, remaining
 unamortized debt discount and debt issuance costs for the Term Loan
 Facility, Senior Notes, Convertible Senior Notes and 2016 Term Loan
 are as follows:

- added (2017-11-08):
[0001193125-17-337320:note_history:45]
|  |  | As of October 2, 2017 |  |  | As of January 2, 2017 |  |
|  |  | Debt Issuance Costs |  |  | Debt Discount |  |  | Effective Interest Rate |  |  | Debt Issuance Costs |  |  | Debt Discount |  |  | Effective Interest Rate |  |
|  |  | (in thousands) |  |
| Term Loan due September 2024 |  | $ | 2,803 |  |  | $ | 1,750 |  |  |  | 3.95 | % |  |  | — |  |  |  | — |  |  |  | — |  |
| Senior Notes due October 2025 |  |  | 6,849 |  |  |  | — |  |  |  | 5.91 | % |  |  | — |  |  |  | — |  |  |  | — |  |
| Convertible Senior Notes |  |  | 3,108 |  |  |  | 31,014 |  |  |  | 6.48 | % |  | $ | 3,747 |  |  | $ | 37,392 |  |  |  | 6.48 | % |
| Term Loan due May 2021 |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 977 |  |  |  | — |  |  |  | 5.48 | % |
|  |  | $ | 12,760 |  |  | $ | 32,764 |  |  |  |  |  |  | $ | 4,724 |  |  | $ | 37,392 |  |  |  |  |  |

- added (2017-11-08):
[0001193125-17-337320:note_history:46]
The above debt discount and debt issuance costs are recorded as
 a reduction of the debt and are amortized into interest expense
 using an effective interest rate over the duration of the
 debt.

- added (2017-11-08):
[0001193125-17-337320:note_history:47]
Debt issuance costs for the ABL Revolving Loans of $2,672 and
 $3,423 as of October 2, 2017 and January 2, 2017,
 respectively, are included in other non-current assets and are amortized
 to interest expense over the duration of the ABL Revolving Loans
 using the straight line method of amortization.

- added (2017-11-08):
[0001193125-17-337320:note_history:48]
At October 2, 2017, the remaining weighted average
 amortization period for all unamortized debt discount and debt
 issuance costs was 4.2 years.

- removed (2017-11-08):
[0001193125-17-251481:note_history:49]
|  |  | Average Effective Interest Rate as of July 3, 2017 |  |  | July 3, 2017 |  |  | Average Effective Interest Rate as of January 2, 2017 |  |  | January 2, 2017 |  |
|  |  | (In thousands) |  |
| Term loan due May 2021 |  |  | 5.48% |  |  | $ | 650,000 |  |  |  | 5.25% |  |  | $ | 700,000 |  |
| U.S. ABL revolving loan due May 2020 |  |  | 2.73% |  |  |  | 80,000 |  |  |  | 2.27% |  |  |  | 80,000 |  |
| Asia ABL revolving loan due May 2020 |  |  | 2.63% |  |  |  | 30,000 |  |  |  | 2.17% |  |  |  | 30,000 |  |
| Convertible Senior Notes due December 2020 |  |  | 1.75% |  |  |  | 249,985 |  |  |  | 1.75% |  |  |  | 250,000 |  |
| Capital lease |  |  | 6.43% |  |  |  | 1,844 |  |  |  | 6.43% |  |  |  | 1,798 |  |
|  |  |  |  |  |  |  | 1,011,829 |  |  |  |  |  |  |  | 1,061,798 |  |
| Less: Long-term debt unamortized discount |  |  |  |  |  |  | (33,174 | ) |  |  |  |  |  |  | (37,392 | ) |
| Long-term debt unamortized debt issuance costs |  |  |  |  |  |  | (4,139 | ) |  |  |  |  |  |  | (4,724 | ) |
|  |  |  |  |  |  |  | 974,516 |  |  |  |  |  |  |  | 1,019,682 |  |
| Less: current maturities |  |  |  |  |  |  | (110,669 | ) |  |  |  |  |  |  | (110,652 | ) |
| Long-term debt, less current maturities |  |  |  |  |  | $ | 863,847 |  |  |  |  |  |  | $ | 909,030 |  |

- removed (2017-11-08):
[0001193125-17-251481:note_history:50]
Term
 and Revolving Loans

- removed (2017-11-08):
[0001193125-17-251481:note_history:51]
The Term Loan bears interest at a floating rate of LIBOR, with
 a 1.0% LIBOR floor, plus an applicable interest margin of 4.25%, or
 JP Morgan Chase Bank’s prime rate, with a 2% floor, plus a
 margin of 3.25%, at the Company’s option. At July 3,
 2017 the weighted average interest rate on the outstanding
 borrowings under the Term Loan was 5.48%. There is no provision,
 other than an event of default, for the interest margin to
 increase. The Term Loan will mature on May 31, 2021. The Term
 Loan is secured by a significant amount of the assets of the
 Company and a pledge of 65% of voting stock of the Company’s
 first tier foreign subsidiaries and is structurally senior to the
 Company’s convertible senior notes. See Convertible Senior
 Notes below.

- removed (2017-11-08):
[0001193125-17-251481:note_history:52]
The Company is no longer required to make any quarterly
 scheduled payments for the remaining term of the outstanding Term
 Loan balance due to mandatory payments and optional loan
 prepayments applied to date. Additionally, based on certain
 parameters defined in the Term Loan agreement, including a secured
 leverage ratio, the Company is also not required to make any
 additional principal payments for fiscal year 2017 as our secured
 leverage ratio is less than or equal to 1.5. The Company may be
 required to make additional principal payments in future years, if
 the Company’s secured leverage ratio is greater than 1.5. Any
 remaining outstanding balances under the Term Loan are due at the
 maturity date of May 31, 2021. During the quarter ended
 July 3, 2017, the Company made an optional debt principal
 prepayment totaling $50,000. Borrowings under the Term Loan are
 subject to financial and operating covenants including maintaining
 a maximum total leverage ratio. Under the occurrence of certain
 events, the U.S. ABL and the Asia ABL are subject to financial and
 operational covenants, including maintaining minimum fixed charge
 coverage ratios. At July 3, 2017, the Company was in
 compliance with the covenants under the Term Loan, the U.S. ABL and
 the Asia ABL.

- removed (2017-11-08):
[0001193125-17-251481:note_history:53]
As of July 3, 2017 and January 2, 2017, remaining
 unamortized debt issuance costs of $815 and $977, respectively,
 related to the Term Loan. These debt issuance costs are recorded as
 a reduction of the Term Loan at July 3, 2017 and
 January 2, 2017, respectively, and are amortized over the
 duration of the Term Loan into interest expense using an effective
 interest rate of 5.48%.

- removed (2017-11-08):
[0001193125-17-251481:note_history:54]
Additionally, remaining unamortized debt issuance costs related
 to the ABL Revolving Loans were $2,922 and $3,423 as of
 July 3, 2017 and January 2, 2017, respectively. These
 debt issuance costs are included in
 other non-current assets
 and are amortized to interest expense over the duration of the ABL
 Revolving Loans using the straight line method of amortization. At
 July 3, 2017, the remaining weighted average amortization
 period for the unamortized debt issuance costs for both the Term
 Loan and the ABL Revolving Loans was 3.1 years.

- removed (2017-11-08):
[0001193125-17-251481:note_history:55]
The Company is required to pay a commitment fee of 0.25% to
 0.375% per annum on any unused portion of the U.S. ABL or Asia
 ABL. The Company incurred total commitment fees related to unused
 borrowing availability of $180 and $150 for the quarters ended
 July 3, 2017 and June 27, 2016, respectively, and $367
 and $344 for the two quarters ended July 3, 2017 and
 June 27, 2016, respectively. As of July 3, 2017, the
 outstanding amount of the Term Loan was $650,000 which is included
 as long-term debt. Additionally, $80,000 of the U.S. ABL and
 $30,000 of the Asia ABL was outstanding as of July 3, 2017.
 Available borrowing capacity under the U.S. ABL and Asia ABL was
 $112,388 and $78,310, which considers letters of credit outstanding
 of $7,612 and $41,690 mentioned below, respectively, at
 July 3, 2017.

- removed (2017-11-08):
[0001193125-17-251481:note_history:56]
Letters
 of Credit

- removed (2017-11-08):
[0001193125-17-251481:note_history:57]
The Company has up to $50,000 and $100,000 Letters of Credit
 Facilities under the U.S. ABL and the Asia ABL, respectively, as
 mentioned above. As of July 3, 2017, letters of credit in the
 amount of $7,612 were outstanding under the U.S. ABL and $41,690
 were outstanding under the Asia ABL with various expiration dates
 through September 2018.

- removed (2017-11-08):
[0001193125-17-251481:note_history:58]
Conversion: At any time prior
 to March 15, 2020, holders may convert their convertible
 senior notes into cash and, if applicable, into shares of the
 Company’s common stock based on a conversion rate of 103.7613
 shares of the Company’s common stock per $1 principal amount
 of convertible senior notes, subject to adjustment, under the
 following circumstances: (1) during any calendar quarter
 beginning after March 31, 2015 (and only during such calendar
 quarter), if the last reported sale price of our common stock for
 at least 20 trading days during the 30 consecutive trading days
 ending on the last trading day of the immediately preceding
 calendar quarter is greater than or equal to 130% of the applicable
 conversion price on each applicable trading day of such preceding
 calendar quarter; (2) during the five business day period
 after any 10 consecutive trading day period in which the trading
 price per note for each day of that 10 consecutive trading day
 period was less than 98% of the product of the last reported sale
 price of the Company’s common stock and the conversion rate
 on such day; or (3) upon the occurrence of specified corporate
 transactions described in the indenture governing the notes. As of
 July 3, 2017, the conversion criteria had been met under
 condition (1) as described above, allowing holders to give
 notice of conversion in both the second and third quarter of
 2017.

- removed (2017-11-08):
[0001193125-17-251481:note_history:59]
On or after March 15, 2020 until the close of business on
 the third scheduled trading day preceding the maturity date,
 holders may convert their notes at any time, regardless of the
 foregoing circumstances. Upon conversion, for each $1 principal
 amount of notes, the Company will pay shares of our common stock,
 cash or a combination of cash and shares of our common stock at its
 election, if applicable, based on a daily conversion value
 calculated on a proportionate basis for each day of the 80 trading
 day observation period. All conversions occurring on the same date
 or on or after March 15, 2020 shall be settled using the same
 settlement method. Additionally, in the event of a fundamental
 change as defined in the indenture governing the notes, or other
 conversion rate adjustments such as share splits or combinations,
 other distributions of shares, cash or other assets to
 stockholders, including self-tender transactions (Other Conversion
 Rate Adjustments), the conversion rate may be modified to adjust
 the number of shares per $1 principal amount of the notes. As of
 July 3, 2017, none of the criteria for a fundamental change or
 a conversion rate adjustment had been met.

- removed (2017-11-08):
[0001193125-17-251481:note_history:60]
The maximum number of shares issuable upon conversion,
 including the effect of a fundamental change and subject to Other
 Conversion Rate Adjustments, would be 32,423.

- removed (2017-11-08):
[0001193125-17-251481:note_history:61]
Note Repurchase: The Company is
 not permitted to redeem the convertible senior notes at any time
 prior to maturity. In the event of a fundamental change or certain
 default events, as defined in the indenture governing the notes,
 holders may require the Company to repurchase for cash all or a
 portion of their convertible senior notes at a price equal to 100%
 of the principal amount, plus any accrued and unpaid
 interest.

- removed (2017-11-08):
[0001193125-17-251481:note_history:62]
Convertible Note Hedge and Warrant
 Transaction: In connection with the
 issuance of the convertible senior notes due 2020, the Company
 entered into a convertible note hedge and warrant transaction (Call
 Spread Transaction), with respect to the Company’s common
 stock. The convertible note hedge consists of the Company’s
 option to purchase up to 25,939 common stock shares at a price of
 $9.64 per share. The hedge expires on December 15, 2020 and
 can only be executed upon the conversion of the above mentioned
 convertible senior notes due 2020. Additionally, the Company sold
 warrants to purchase 25,940 shares of its common stock at a price
 of $14.26 per share. The warrants expire ratably from March 2021
 through January 2022. The 2020 Call Spread Transaction has no
 effect on the terms of the convertible senior notes due 2020 and
 reduces potential dilution by effectively increasing the conversion
 price of the convertible senior notes due 2020 to $14.26 per share
 of the Company’s common stock.

- removed (2017-11-08):
[0001193125-17-251481:note_history:63]
|  |  | For the Quarter Ended |  |  | For the Two Quarters Ended |  |
|  |  | July 3, 2017 |  |  | June 27, 2016 |  |  | July 3, 2017 |  |  | June 27, 2016 |  |
|  |  | (In thousands) |  |
| Contractual coupon interest |  | $ | 1,093 |  |  | $ | 1,093 |  |  | $ | 2,187 |  |  | $ | 2,187 |  |
| Amortization of debt discount |  | $ | 2,125 |  |  | $ | 1,992 |  |  | $ | 4,216 |  |  | $ | 3,952 |  |
| Amortization of debt issuance costs |  | $ | 214 |  |  | $ | 200 |  |  | $ | 423 |  |  | $ | 396 |  |

- removed (2017-11-08):
[0001193125-17-251481:note_history:64]
As of July 3, 2017 and January 2, 2017, there remains
 unamortized debt discount of $33,174 and $37,392, respectively, and
 debt issuance costs of $3,324 and $3,747, respectively, related to
 the convertible senior notes. These debt discount and debt discount
 issuance costs are recorded as a reduction of the convertible
 senior notes and are being amortized to interest expense over the
 term of the convertible senior notes using the effective interest
 rate method. At July 3, 2017, the remaining weighted average
 amortization period for the unamortized senior convertible note
 discount and debt issuance costs was 3.5 years.

- removed (2017-11-08):
[0001193125-17-251481:note_history:65]
For the quarters and two quarters ended July 3, 2017 and
 June 27, 2016, the amortization of the convertible senior
 notes due 2020 debt discount and debt issuance costs is based on an
 effective interest rate of 6.48%.


## us-gaap:ScheduleOfDebtInstrumentsTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2017-11-08):
[0001193125-17-337320:note_history:66]
The following table summarizes the long-term debt of the
 Company as of October 2, 2017 and January 2,
 2017:
  (was, 2017-08-08, similarity 0.9436):
[0001193125-17-251481:note_history:66]
The following table summarizes the long-term debt of the
 Company as of July 3, 2017 and January 2,
 2017:

- added (2017-11-08):
[0001193125-17-337320:note_history:67]
|  |  | Interest Rate as of October 2, 2017 |  |  | Principal Outstanding as of October 2, 2017 |  |  | Interest Rate as of January 2, 2017 |  |  | Principal Outstanding as of January 2, 2017 |  |
|  |  | (In thousands) |  |
| Term Loan due September 2024 |  |  | 3.73 | % |  | $ | 350,000 |  |  |  | — |  |  |  | — |  |
| Senior Notes due October 2025 |  |  | 5.63 | % |  |  | 375,000 |  |  |  | — |  |  |  | — |  |
| Term Loan due May 2021 |  |  | — |  |  |  | — |  |  |  | 5.25 | % |  | $ | 700,000 |  |
| Convertible Senior Notes due December 2020 |  |  | 1.75 | % |  |  | 249,985 |  |  |  | 1.75 | % |  |  | 250,000 |  |
| U.S. ABL Revolving Loan due May 2020 |  |  | 2.73 | % |  |  | 17,000 |  |  |  | 2.27 | % |  |  | 80,000 |  |
| Asia ABL Revolving Loan due May 2020 |  |  | 2.63 | % |  |  | 30,000 |  |  |  | 2.17 | % |  |  | 30,000 |  |
| Capital Lease |  |  | 6.43 | % |  |  | 1,884 |  |  |  | 6.43 | % |  |  | 1,798 |  |
|  |  |  |  |  |  |  | 1,023,869 |  |  |  |  |  |  |  | 1,061,798 |  |
| Less: Long-term debt unamortized discount |  |  |  |  |  |  | (32,764 | ) |  |  |  |  |  |  | (37,392 | ) |
| Long-term debt unamortized debt issuance costs |  |  |  |  |  |  | (12,760 | ) |  |  |  |  |  |  | (4,724 | ) |
|  |  |  |  |  |  |  | 978,345 |  |  |  |  |  |  |  | 1,019,682 |  |
| Less: current maturities |  |  |  |  |  |  | (4,184 | ) |  |  |  |  |  |  | (110,652 | ) |
| Long-term debt, less current maturities |  |  |  |  |  | $ | 974,161 |  |  |  |  |  |  | $ | 909,030 |  |

- removed (2017-11-08):
[0001193125-17-251481:note_history:68]
|  |  | Average Effective Interest Rate as of July 3, 2017 |  |  | July 3, 2017 |  |  | Average Effective Interest Rate as of January 2, 2017 |  |  | January 2, 2017 |  |
|  |  | (In thousands) |  |
| Term loan due May 2021 |  |  | 5.48% |  |  | $ | 650,000 |  |  |  | 5.25% |  |  | $ | 700,000 |  |
| U.S. ABL revolving loan due May 2020 |  |  | 2.73% |  |  |  | 80,000 |  |  |  | 2.27% |  |  |  | 80,000 |  |
| Asia ABL revolving loan due May 2020 |  |  | 2.63% |  |  |  | 30,000 |  |  |  | 2.17% |  |  |  | 30,000 |  |
| Convertible Senior Notes due December 2020 |  |  | 1.75% |  |  |  | 249,985 |  |  |  | 1.75% |  |  |  | 250,000 |  |
| Capital lease |  |  | 6.43% |  |  |  | 1,844 |  |  |  | 6.43% |  |  |  | 1,798 |  |
|  |  |  |  |  |  |  | 1,011,829 |  |  |  |  |  |  |  | 1,061,798 |  |
| Less: Long-term debt unamortized discount |  |  |  |  |  |  | (33,174 | ) |  |  |  |  |  |  | (37,392 | ) |
| Long-term debt unamortized debt issuance costs |  |  |  |  |  |  | (4,139 | ) |  |  |  |  |  |  | (4,724 | ) |
|  |  |  |  |  |  |  | 974,516 |  |  |  |  |  |  |  | 1,019,682 |  |
| Less: current maturities |  |  |  |  |  |  | (110,669 | ) |  |  |  |  |  |  | (110,652 | ) |
| Long-term debt, less current maturities |  |  |  |  |  | $ | 863,847 |  |  |  |  |  |  | $ | 909,030 |  |


## us-gaap:RelatedPartyTransactionsDisclosureTextBlock (related_parties) — matched_by: tag_name, score: 1.0

- changed (2017-11-08):
[0001193125-17-337320:note_history:69]
In the
 normal course of business, the Company’s foreign subsidiaries
 purchase laminate and prepreg from related parties in which a
 significant shareholder of the Company holds an equity interest.
 The Company purchased laminate and prepreg from these related
 parties in the amount of $13,225 and $12,292 for the quarters ended
 October 2, 2017 and September 26, 2016, respectively, and
 $38,886 and $42,549 for the three quarters ended October 2,
 2017 and September 26, 2016, respectively.
  (was, 2017-08-08, similarity 0.897):
[0001193125-17-251481:note_history:69]
In the normal course of
 business, the Company’s foreign subsidiaries purchase
 laminate and prepreg from related parties in which a significant
 shareholder of the Company holds an equity interest. The Company
 purchased laminate and prepreg from these related parties in the
 amount of $12,121 and $14,259 for the quarters ended July 3,
 2017 and June 27, 2016, respectively, and $25,611 and $30,257
 for the two quarters ended July 3, 2017 and June 27,
 2016, respectively.

- changed (2017-11-08):
[0001193125-17-337320:note_history:70]
The
 Company also sells PCBs to a related party which is a wholly owned
 subsidiary of an entity in which a significant shareholder of the
 Company holds an equity interest. Sales to this related party for
 the quarters ended October 2, 2017 and September 26, 2016
 were $5 and $254, respectively, and $53 and $863 for the three
 quarters ended October 2, 2017 and September 26, 2016,
 respectively.
  (was, 2017-08-08, similarity 0.8743):
[0001193125-17-251481:note_history:70]
The Company also sells
 PCBs to a related party which is a wholly owned subsidiary of an
 entity in which a significant shareholder of the Company holds an
 equity interest. Sales to this related party for the quarters ended
 July 3, 2017 and June 27, 2016 were $17 and $298,
 respectively, and $48 and $610 for the two quarters ended
 July 3, 2017 and June 27, 2016,
 respectively.

- changed (2017-11-08):
[0001193125-17-337320:note_history:71]
As of
 October 2, 2017 and January 2, 2017, the Company’s
 consolidated condensed balance sheets included $15,490 and $15,836,
 respectively, in accounts payable due to related parties primarily
 for purchases of laminate and prepreg and such balances are
 included as a component of accounts payable on the consolidated
 condensed balance sheets. Additionally, the Company’s
 consolidated condensed balance sheets included $9 and $192,
 respectively, in accounts receivable due from a related party for
 sales of PCBs, as mentioned above, and such balances are included
 as a component of accounts receivable, net on the consolidated
 condensed balance sheets.
  (was, 2017-08-08, similarity 0.9768):
[0001193125-17-251481:note_history:71]
As of July 3, 2017
 and January 2, 2017, the Company’s consolidated
 condensed balance sheets included $16,934 and $15,836,
 respectively, in accounts payable due to related parties primarily
 for purchases of laminate and prepreg and such balances are
 included as a component of accounts payable on the consolidated
 condensed balance sheets. Additionally, the Company’s
 consolidated condensed balance sheets included $31 and $192,
 respectively, in accounts receivable due from a related party for
 sales of PCBs, as mentioned above, and such balances are included
 as a component of accounts receivable, net on the consolidated
 condensed balance sheets.
