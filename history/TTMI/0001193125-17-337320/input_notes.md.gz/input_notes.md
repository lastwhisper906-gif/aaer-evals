# TTMI notes — 0001193125-17-337320


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001193125-17-337320:notes:1]
(11) Commitments and
 Contingencies

[0001193125-17-337320:notes:2]
Legal
 Matters

[0001193125-17-337320:notes:3]
The Company is subject to various legal matters, which it
 considers normal for its business activities. While the Company
 currently believes that the amount of any reasonably possible loss
 for known matters would not be material to the Company’s
 financial condition, the outcome of these actions is inherently
 difficult to predict. In the event of an adverse outcome, the
 ultimate potential loss could have a material adverse effect on the
 Company’s financial condition or results of operations in a
 particular period. The Company has accrued amounts for its loss
 contingencies which are probable and estimable as of
 October 2, 2017 and January 2, 2017. However, these
 amounts are not material to the consolidated condensed financial
 statements of the Company.

[0001193125-17-337320:notes:4]
Environmental
 Matters

[0001193125-17-337320:notes:5]
The process to manufacture PCBs requires adherence to domestic
 and foreign jurisdictional environmental laws regulations regarding
 the storage, use, handling, recycling and disposal of liquid and
 solid wastes, as well as compliance with air quality standards and
 chemical use reporting. The Company believes that its facilities in
 North America comply in all material respects with applicable
 environmental laws and regulations. In China, governmental
 authorities have adopted new rules and regulations governing
 environmental issues. The Company believes it has developed plans
 acceptable to the Chinese government and is in the process of
 implementing these plans. The Company does not anticipate any
 immediate risk of government fines or temporary closure of its
 Chinese plants. The Company has established and enacted an
 investment plan related to the efforts to come into full compliance
 with the new regulations in a timely fashion. The 2017 capital
 expenditure costs expected for these plans are included in the
 Company’s capital expenditure projections.


## us-gaap:ConvertibleDebtTableTextBlock

[0001193125-17-337320:notes:6]
As of October 2, 2017 and January 2, 2017, the
 following summarizes the equity components of the convertible
 senior notes included in additional paid-in capital:

[0001193125-17-337320:notes:7]
|  |  | As of October 2, 2017 |  |  | As of January 2, 2017 |  |
|  |  | Embedded conversion option — Convertible Senior Notes |  |  | Embedded conversion option — Convertible Senior Notes Issuance Costs |  |  | Total |  |  | Embedded conversion option — Convertible Senior Notes |  |  | Embedded conversion option — Convertible Senior Notes Issuance Costs |  |  | Total |  |
|  |  | (in thousands) |  |
| Convertible senior notes due 2020 |  | $ | 60,216 |  |  | $ | (1,916 | ) |  | $ | 58,300 |  |  | $ | 60,227 |  |  | $ | (1,916 | ) |  | $ | 58,311 |  |


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001193125-17-337320:notes:8]
(13) Stock-Based
 Compensation

[0001193125-17-337320:notes:9]
[same as prior period, unchanged from 0001193125-17-251481:notes:9]

[0001193125-17-337320:notes:10]
|  |  | Quarter Ended |  |  | Three Quarters Ended |  |
|  |  | October 2, 2017 |  |  | September 26, 2016 |  |  | October 2, 2017 |  |  | September 26, 2016 |  |
|  |  | (In thousands) |  |
| Cost of goods sold |  | $ | 606 |  |  | $ | 412 |  |  | $ | 1,639 |  |  | $ | 1,161 |  |
| Selling and marketing |  |  | 369 |  |  |  | 268 |  |  |  | 1,008 |  |  |  | 749 |  |
| General and administrative |  |  | 3,703 |  |  |  | 2,119 |  |  |  | 10,659 |  |  |  | 5,980 |  |
| Stock-based compensation expense recognized |  | $ | 4,678 |  |  | $ | 2,799 |  |  | $ | 13,306 |  |  | $ | 7,890 |  |

[0001193125-17-337320:notes:11]
Performance-based
 Restricted Stock Units

[0001193125-17-337320:notes:12]
[same as prior period, unchanged from 0001193125-17-251481:notes:12]

[0001193125-17-337320:notes:13]
The Company records stock-based compensation expense for PRU
 awards granted based on management’s periodic assessment of
 the probability of the PRU awards vesting. For the three quarters
 ended October 2, 2017, management determined that vesting of
 the PRU awards was probable. PRUs activity for the three quarters
 ended October 2, 2017 was as follows:

[0001193125-17-337320:notes:14]
|  |  | Shares |  |  | Weighted Average Fair Value |  |
|  |  | (In thousands) |  |  |  |  |
| Outstanding target shares at January 2, 2017 |  |  | 406 |  |  | $ | 8.31 |  |
| Granted |  |  | 363 |  |  |  | 22.90 |  |
| Change in units due to annual financial target performance achievement |  |  | (19 | ) |  |  | 22.90 |  |
| Outstanding target shares at October 2, 2017 |  |  | 750 |  |  | $ | 15.01 |  |

[0001193125-17-337320:notes:15]
Restricted Stock
 Units

[0001193125-17-337320:notes:16]
The Company granted 1,007 and 1,814 restricted stock units
 during the three quarters ended October 2, 2017 and
 September 26, 2016, respectively. The RSUs granted have a
 weighted-average fair value per unit of $15.82 and $6.74 for the
 three quarters ended October 2, 2017 and September 26,
 2016, respectively. The fair value for RSUs granted is based on the
 closing share price of the Company’s common stock on the date
 of grant. There were no restricted stock units granted during the
 quarters ended October 2, 2017 and September 26,
 2016.

[0001193125-17-337320:notes:17]
[same as prior period, unchanged from 0001193125-17-251481:notes:17]

[0001193125-17-337320:notes:18]
The Company did not grant any stock option awards during the
 quarters and three quarters ended October 2, 2017 and
 September 26, 2016.

[0001193125-17-337320:notes:19]
Summary of Unrecognized
 Compensation Costs

[0001193125-17-337320:notes:20]
The following is a summary of total unrecognized compensation
 costs as of October 2, 2017:

[0001193125-17-337320:notes:21]
|  |  | Unrecognized Stock-Based Compensation Cost |  |  | Remaining Weighted Average Recognition Period |  |
|  |  | (In thousands) |  |  | (In years) |  |
| RSU awards |  | $ | 18,921 |  |  |  | 1.4 |  |
| PRU awards |  |  | 5,383 |  |  |  | 1.3 |  |
| Stock options |  |  | 103 |  |  |  | 2.0 |  |
|  |  | $ | 24,407 |  |  |  |  |  |


## us-gaap:InventoryDisclosureTextBlock

[0001193125-17-337320:notes:22]
[same as prior period, unchanged from 0001193125-17-251481:notes:22]

[0001193125-17-337320:notes:23]
Inventories as of October 2, 2017 and January 2, 2017
 consisted of the following:

[0001193125-17-337320:notes:24]
|  |  | As of |  |
|  |  | October 2, 2017 |  |  | January 2, 2017 |  |
|  |  | (In thousands) |  |
| Inventories: |  |  |  |  |  |  |  |  |
| Raw materials |  | $ | 76,467 |  |  | $ | 73,497 |  |
| Work-in-process |  |  | 119,291 |  |  |  | 105,094 |  |
| Finished goods |  |  | 99,521 |  |  |  | 90,621 |  |
|  |  | $ | 295,279 |  |  | $ | 269,212 |  |


## us-gaap:NewAccountingPronouncementsPolicyPolicyTextBlock

[0001193125-17-337320:notes:25]
Recently Adopted and
 Issued Accounting Standards

[0001193125-17-337320:notes:26]
In August 2017, the Financial Accounting Standards Board (FASB)
 issued Accounting Standards Update (ASU) 2017-12, Derivatives and Hedging
 (Topic 815): Targeted Improvements to Accounting for Hedging
 Activities. This ASU amends and simplifies existing guidance in
 order to allow companies to more accurately present the economic
 effects of risk management activities in the financial statements.
 ASU 2017-12 also amends
 the guidance surrounding the recognition of the value of hedged
 instruments to include the entire change in value, rather than just
 the effective portion, in other comprehensive income and recognized
 in earnings at the same time that the hedged item affects earnings
 for cash flow and net investment hedges. This ASU is effective for
 fiscal years beginning after December 15, 2018, including
 interim periods within those fiscal years. Early adoption is
 permitted. The Company is currently evaluating the new guidance to
 determine the impact it may have on its consolidated condensed
 financial statements and related disclosures.

[0001193125-17-337320:notes:27]
In January 2017, the FASB issued ASU 2017-04, Intangibles (Topic 350):
 Goodwill and Other. This ASU simplifies the accounting for
 goodwill impairment and removes Step 2 of the goodwill impairment
 test. Goodwill impairment will now be the amount by which a
 reporting unit’s carrying value exceeds its fair value
 limited to the total amount of goodwill allocated to that reporting
 unit. Entities will continue to have the option to perform a
 qualitative assessment to determine if a quantitative impairment
 test is necessary. The Company elected to early adopt ASU
 2017-04 on a prospective
 basis during the second quarter of 2017, and the adoption did
 not have a material impact on its consolidated condensed financial
 statements and related disclosures.

[0001193125-17-337320:notes:28]
In October 2016, the FASB issued ASU 2016-16, Income Taxes (Topic 740):
 Intra-Entity Transfers of Assets Other Than Inventory. The
 objective of this update is to improve the accounting for the
 income tax consequences of intra-entity transfers of assets other
 than inventory by recognizing the income tax consequences when the
 transfer occurs. This ASU is effective for fiscal years beginning
 after December 15, 2017, including interim periods within
 those fiscal years. Early adoption is permitted. The adoption of
 this standard is not expected to have a material impact on the
 Company’s consolidated condensed financial statements or
 related disclosures.

[0001193125-17-337320:notes:29]
In August 2016, the FASB issued ASU 2016-15, Statement of Cash Flows
 (Topic 230). The objective of this update is to add or clarify
 guidance on the classification of certain cash receipts and
 payments in the statement of cash flows. This ASU is effective for
 fiscal years beginning after December 15, 2017, including
 interim periods within those annual periods and is to be applied
 utilizing a retrospective approach. Early adoption is permitted.
 The Company adopted this ASU 2016-15 in the first quarter of 2017
 and the adoption did not have a material impact on its consolidated
 condensed financial statements and related disclosures.

[0001193125-17-337320:notes:30]
In March 2016, the FASB issued ASU 2016-09, Stock Compensation (Topic
 718): Improvements to Employee Share-Based Payment Accounting.
 The objective of this update is to simplify several aspects of the
 accounting for employee share-based payment transactions, including
 the income tax consequences, classification of awards as either
 equity or liabilities, and classification on the statement of cash
 flows. This ASU is effective for fiscal years beginning after
 December 15, 2016, including interim periods within those
 fiscal years. The Company adopted ASU 2016-09 on January 3, 2017. The
 adoption did not have a material impact on the consolidated
 condensed financial statements and related disclosures.

[0001193125-17-337320:notes:31]
In February 2016, the FASB issued ASU 2016-02, Leases (Topic 842).
 The objective of this update is to increase transparency and
 comparability among organizations by recognizing lease assets and
 lease liabilities on the balance sheet and disclosing key
 information about leasing arrangements. This ASU is effective for
 fiscal years beginning after December 15, 2018, including
 interim periods within those annual periods and is to be applied
 utilizing a modified retrospective approach. While the Company
 continues to evaluate the new guidance to determine the impact it
 may have on its consolidated condensed financial statements and
 related disclosures, the primary effect of adopting this update
 will be to record assets and obligations for current operating
 leases.

[0001193125-17-337320:notes:32]
In January 2016, the FASB issued ASU 2016-01, Financial
 Instruments—Overall (Topic 825): Recognition and
 Measurement of Financial Assets and Financial Liabilities. This
 ASU amends certain aspects of recognition, measurement,
 presentation and disclosure of financial instruments, and
 supersedes the guidance to classify equity securities with readily
 determinable fair values into different categories (that is,
 trading or available-for-sale) and
 requires equity securities to be measured at fair value with
 changes in the fair value recognized through net income. This ASU
 is effective for annual and interim periods beginning after
 December 15, 2017. The Company does not anticipate the
 adoption will have a material impact on its consolidated condensed
 financial statements and related disclosures.

[0001193125-17-337320:notes:33]
In May 2014, the FASB issued ASU 2014-09, Revenue from Contracts
 with Customers, as amended, which requires an entity to
 recognize the amount of revenue to which it expects to be entitled
 for the transfer of promised goods or services to customers. The
 ASU will replace most existing revenue recognition guidance in U.S.
 GAAP when it becomes effective. The new standard is effective for
 the Company at the beginning of fiscal year 2018. The standard
 permits the use of either the retrospective or cumulative effect
 transition method. The Company has assessed that the impact of the
 new guidance will result in a change to the timing of revenue
 recognition for the Company’s revenue stream from
 “point in time” upon physical delivery to an
 “over time” model and believes this transition could
 have a material impact on the Company’s consolidated
 financial statements upon adoption. As of October 2, 2017,
 management intends to apply the cumulative effect transition
 method. The Company has identified and implemented changes to its
 processes and internal controls to meet the standard update’s
 reporting and disclosure requirements.


## us-gaap:ReconciliationOfOperatingProfitLossFromSegmentsToConsolidatedTextBlock

[0001193125-17-337320:notes:34]
The Company accounts for inter-segment sales and transfers
 consistent with the Company’s revenue recognition policy. The
 inter-segment sales for the quarters and three quarters ended
 October 2, 2017 and September 26, 2016 were sales
 primarily from the PCB to the E-M Solutions reportable
 segment.

[0001193125-17-337320:notes:35]
|  |  | Quarter Ended |  |  | Three Quarters Ended |  |
|  |  | October 2, 2017 |  |  | September 26, 2016 |  |  | October 2, 2017 |  |  | September 26, 2016 |  |
|  |  | (In thousands) |  |
| Net Sales: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| PCB |  | $ | 609,742 |  |  | $ | 598,656 |  |  | $ | 1,773,003 |  |  | $ | 1,692,175 |  |
| E-M Solutions |  |  | 60,620 |  |  |  | 46,246 |  |  |  | 155,187 |  |  |  | 143,151 |  |
| Total sales |  |  | 670,362 |  |  |  | 644,902 |  |  |  | 1,928,190 |  |  |  | 1,835,326 |  |
| Inter-segment sales |  |  | (3,548 | ) |  |  | (3,182 | ) |  |  | (8,947 | ) |  |  | (8,501 | ) |
| Total net sales |  | $ | 666,814 |  |  | $ | 641,720 |  |  | $ | 1,919,243 |  |  | $ | 1,826,825 |  |
| Reportable Segment Income (loss): |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| PCB |  | $ | 70,443 |  |  | $ | 75,501 |  |  | $ | 222,134 |  |  | $ | 189,838 |  |
| E-M Solutions |  |  | 2,870 |  |  |  | 1,421 |  |  |  | 3,917 |  |  |  | 1,655 |  |
| Corporate |  |  | (23,318 | ) |  |  | (20,747 | ) |  |  | (66,608 | ) |  |  | (69,841 | ) |
| Total reportable segment income |  |  | 49,995 |  |  |  | 56,175 |  |  |  | 159,443 |  |  |  | 121,652 |  |
| Amortization of definite-lived intangibles |  |  | (5,905 | ) |  |  | (5,949 | ) |  |  | (17,727 | ) |  |  | (17,845 | ) |
| Total operating income |  |  | 44,090 |  |  |  | 50,226 |  |  |  | 141,716 |  |  |  | 103,807 |  |
| Total other expense |  |  | (21,350 | ) |  |  | (14,943 | ) |  |  | (55,403 | ) |  |  | (52,411 | ) |
| Income before income taxes |  | $ | 22,740 |  |  | $ | 35,283 |  |  | $ | 86,313 |  |  | $ | 51,396 |  |


## us-gaap:RestructuringImpairmentAndOtherActivitiesDisclosureTextBlock

[0001193125-17-337320:notes:36]
(2) Consolidation Plan,
 Restructuring and Impairment Charges

[0001193125-17-337320:notes:37]
On September 29, 2015, the Company announced a
 consolidation plan that resulted in the closure of the
 Company’s facilities in Cleveland, Ohio, Milpitas, California
 and Juarez, Mexico (the Consolidation Plan) and laid off
 approximately 480 employees at these sites. The Consolidation Plan
 was part of the Company’s integration strategy to improve
 total plant utilization, operational performance and customer focus
 following its acquisition of Viasystems on May 31, 2015. In
 accordance with the Consolidation Plan, the Company has combined
 its Cleveland and Milpitas facilities into its North Jackson, Ohio
 and Silicon Valley, California facilities, respectively, and closed
 its Juarez, Mexico facility.

[0001193125-17-337320:notes:38]
In connection with the Consolidation Plan and other global
 realignment restructuring efforts, the Company recognized employee
 separation, contract termination and other costs during the
 quarters and three quarters ended October 2, 2017 and
 September 26, 2016. Contract termination and other costs
 primarily represented plant closure costs for Cleveland, Ohio,
 Milpitas, California and Juarez, Mexico, as well as costs related
 to building operating leases associated with the downsizing of the
 St. Louis, Missouri office.

[0001193125-17-337320:notes:39]
The below table summarizes such restructuring costs by
 reportable segment for the quarter and three quarters ended
 October 2, 2017:

[0001193125-17-337320:notes:40]
|  |  | Quarter Ended October 2, 2017 |  |  | Three Quarters Ended October 2, 2017 |  |
|  |  | Employee separation/ severance |  |  | Contract termination and other costs |  |  | Total |  |  | Employee separation/ severance |  |  | Contract termination and other costs |  |  | Total |  |
|  |  | (In thousands) |  |
| Reportable Segment: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| PCB |  | $ | 8 |  |  |  | — |  |  | $ | 8 |  |  | $ | 178 |  |  | $ | 99 |  |  | $ | 277 |  |
| E-M Solutions |  |  | — |  |  |  | 5 |  |  |  | 5 |  |  |  | — |  |  |  | 520 |  |  |  | 520 |  |
| Corporate |  |  | — |  |  |  | 87 |  |  |  | 87 |  |  |  | 32 |  |  |  | 296 |  |  |  | 328 |  |
|  |  | $ | 8 |  |  | $ | 92 |  |  | $ | 100 |  |  | $ | 210 |  |  | $ | 915 |  |  | $ | 1,125 |  |

[0001193125-17-337320:notes:41]
The below table summarizes such restructuring costs by
 reportable segment for the quarter and three quarters ended
 September 26, 2016:

[0001193125-17-337320:notes:42]
|  |  | Quarter Ended September 26, 2016 |  |  | Three Quarters Ended September 26, 2016 |  |
|  |  | Employee separation/ severance |  |  | Contract termination and other costs |  |  | Total |  |  | Employee separation/ severance |  |  | Contract termination and other costs |  |  | Total |  |
|  |  | (In thousands) |  |
| Reportable Segment: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| PCB |  | $ | 157 |  |  | $ | 778 |  |  | $ | 935 |  |  | $ | 1,425 |  |  | $ | 1,878 |  |  | $ | 3,303 |  |
| E-M Solutions |  |  | 222 |  |  |  | 1,072 |  |  |  | 1,294 |  |  |  | 956 |  |  |  | 3,016 |  |  |  | 3,972 |  |
| Corporate |  |  | (121 | ) |  |  | (5 | ) |  |  | (126 | ) |  |  | (112 | ) |  |  | 842 |  |  |  | 730 |  |
|  |  | $ | 258 |  |  | $ | 1,845 |  |  | $ | 2,103 |  |  | $ | 2,269 |  |  | $ | 5,736 |  |  | $ | 8,005 |  |

[0001193125-17-337320:notes:43]
The below table shows the utilization of the accrued
 restructuring costs during the three quarters ended October 2,
 2017:

[0001193125-17-337320:notes:44]
|  |  | Employee separation/ severance |  |  | Contract termination and other Costs |  |  | Total |  |
|  |  | (In thousands) |  |
| Accrued at January 2, 2017 |  | $ | 124 |  |  | $ | 1,042 |  |  | $ | 1,166 |  |
| Charged to expense |  |  | 210 |  |  |  | 915 |  |  |  | 1,125 |  |
| Amount paid |  |  | (334 | ) |  | $ | (1,402 | ) |  |  | (1,736 | ) |
| Accrued at October 2, 2017 |  | $ | — |  |  | $ | 555 |  |  | $ | 555 |  |

[0001193125-17-337320:notes:45]
The remaining accrual for unpaid estimated contract termination
 and other costs as of October 2, 2017 are included as a
 component of other accrued expenses in the consolidated condensed
 balance sheet.

[0001193125-17-337320:notes:46]
As of October 2, 2017, the Company had incurred
 approximately $17,457 of restructuring charges since the
 September 29, 2015 announcement. The Company estimates that it
 will incur total charges related to the Consolidation Plan of
 approximately $20,000.

[0001193125-17-337320:notes:47]
The Company recognized $3,346 in impairment charges during the
 three quarters ended September 26, 2016. As a result of the
 above mentioned plant closures and other plant realignment efforts,
 $1,393 of impairment charges were recognized in the consolidated
 condensed statement of operations related to machinery and
 equipment in the PCB reportable segment. In addition, $1,953 of
 impairment charges were recognized in the consolidated condensed
 statement of operations related to capitalized software costs in
 the Corporate operating segment.


## us-gaap:ScheduleOfAccumulatedOtherComprehensiveIncomeLossTableTextBlock

[0001193125-17-337320:notes:48]
The following provides a summary of the components of
 accumulated other comprehensive income (loss) as of October 2,
 2017 and January 2, 2017:

[0001193125-17-337320:notes:49]
|  |  | Foreign Currency Translation |  |  | Gains (Losses) on Cash Flow Hedges |  |  | Total |  |
|  |  | (In thousands) |  |
| Ending balance at January 2, 2017 |  | $ | (43,149 | ) |  | $ | (1,180 | ) |  | $ | (44,329 | ) |
| Other comprehensive income before reclassifications |  |  | 34,307 |  |  |  | 194 |  |  |  | 34,501 |  |
| Amounts reclassified from accumulated other comprehensive income |  |  | — |  |  |  | 130 |  |  |  | 130 |  |
| Other comprehensive income |  |  | 34,307 |  |  |  | 324 |  |  |  | 34,631 |  |
| Ending balance at October 2, 2017 |  | $ | (8,842 | ) |  | $ | (856 | ) |  | $ | (9,698 | ) |


## us-gaap:ScheduleOfDebtInstrumentsTextBlock

[0001193125-17-337320:notes:50]
The following table summarizes the long-term debt of the
 Company as of October 2, 2017 and January 2,
 2017:

[0001193125-17-337320:notes:51]
|  |  | Interest Rate as of October 2, 2017 |  |  | Principal Outstanding as of October 2, 2017 |  |  | Interest Rate as of January 2, 2017 |  |  | Principal Outstanding as of January 2, 2017 |  |
|  |  | (In thousands) |  |
| Term Loan due September 2024 |  |  | 3.73 | % |  | $ | 350,000 |  |  |  | — |  |  |  | — |  |
| Senior Notes due October 2025 |  |  | 5.63 | % |  |  | 375,000 |  |  |  | — |  |  |  | — |  |
| Term Loan due May 2021 |  |  | — |  |  |  | — |  |  |  | 5.25 | % |  | $ | 700,000 |  |
| Convertible Senior Notes due December 2020 |  |  | 1.75 | % |  |  | 249,985 |  |  |  | 1.75 | % |  |  | 250,000 |  |
| U.S. ABL Revolving Loan due May 2020 |  |  | 2.73 | % |  |  | 17,000 |  |  |  | 2.27 | % |  |  | 80,000 |  |
| Asia ABL Revolving Loan due May 2020 |  |  | 2.63 | % |  |  | 30,000 |  |  |  | 2.17 | % |  |  | 30,000 |  |
| Capital Lease |  |  | 6.43 | % |  |  | 1,884 |  |  |  | 6.43 | % |  |  | 1,798 |  |
|  |  |  |  |  |  |  | 1,023,869 |  |  |  |  |  |  |  | 1,061,798 |  |
| Less: Long-term debt unamortized discount |  |  |  |  |  |  | (32,764 | ) |  |  |  |  |  |  | (37,392 | ) |
| Long-term debt unamortized debt issuance costs |  |  |  |  |  |  | (12,760 | ) |  |  |  |  |  |  | (4,724 | ) |
|  |  |  |  |  |  |  | 978,345 |  |  |  |  |  |  |  | 1,019,682 |  |
| Less: current maturities |  |  |  |  |  |  | (4,184 | ) |  |  |  |  |  |  | (110,652 | ) |
| Long-term debt, less current maturities |  |  |  |  |  | $ | 974,161 |  |  |  |  |  |  | $ | 909,030 |  |


## us-gaap:IncomeTaxDisclosureTextBlock

[0001193125-17-337320:notes:52]
[same as prior period, unchanged from 0001193125-17-251481:notes:49]

[0001193125-17-337320:notes:53]
The Company’s effective tax rate will generally differ
 from the U.S. federal statutory rate of 35% due to favorable tax
 rates associated with earnings from the Company’s operations
 in lower-tax jurisdictions
 such as China, the apportioned state income tax rates, generation
 of other credits and deductions available to the Company, including
 research and development deductions in China, changes in valuation
 allowances, and certain non-deductible items.

[0001193125-17-337320:notes:54]
During the quarter and three quarters ended October 2,
 2017, the Company’s effective tax rate was impacted by a net
 discrete benefit of $1,345 and $5,992, respectively, related to
 (i) certain tax incentives, (ii) release of uncertain tax
 positions due to the expiration of the statute of limitations in
 foreign jurisdictions, and (iii) accrued interest expense on
 existing uncertain tax positions. Additionally, no tax benefit was
 recorded on losses incurred in various jurisdictions where there
 were corresponding increases in the valuation allowances in those
 jurisdictions. The Company’s foreign earnings will be
 indefinitely reinvested outside of the U.S. Therefore, no deferred
 tax liabilities for U.S. income taxes on undistributed earnings
 have been recorded, but deferred tax liabilities have been recorded
 for certain subsidiaries in China to provide for distributions up
 to the ultimate, foreign holding company.

[0001193125-17-337320:notes:55]
Certain entities in China operated under tax incentives
 effective in 2017. For the quarter ended October 2, 2017,
 the tax incentives decreased Chinese taxes by $953, which increased
 both basic and dilutive earnings per share by $0.01 for the quarter
 ended October 2, 2017. For the three quarters ended
 October 2, 2017, the tax incentives decreased Chinese taxes by
 $6,611, which increased basic earnings per share by $0.07 and
 dilutive earnings per share by $0.05 for the three quarters ended
 October 2, 2017.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0001193125-17-337320:notes:56]
(1) Nature of Operations
 and Basis of Presentation

[0001193125-17-337320:notes:57]
TTM Technologies, Inc. (the Company or TTM) is a leading global
 printed circuit board (PCB) manufacturer, focusing on quick-turn
 and volume production of technologically complex PCBs and
 electro-mechanical solutions (E-M Solutions). The Company provides
 time-to-market and volume
 production of advanced technology products and offers a
 one-stop manufacturing
 solution to customers from engineering support to prototype
 development through final mass production. This one-stop manufacturing solution
 enables the Company to align technology developments with the
 diverse needs of the Company’s customers and to enable them
 to reduce the time required to develop new products and bring them
 to market.

[0001193125-17-337320:notes:58]
The Company serves a diversified customer base in various
 markets throughout the world, including aerospace and defense,
 automotive components, smartphones and touchscreen tablets,
 high-end computing,
 medical, industrial and instrumentation related products, as well
 as networking/communications infrastructure products. The
 Company’s customers include both original equipment
 manufacturers (OEMs) and electronic manufacturing services (EMS)
 providers.

[0001193125-17-337320:notes:59]
The accompanying consolidated condensed financial statements
 have been prepared by the Company, without audit, pursuant to the
 rules and regulations of the Securities and Exchange Commission
 (SEC). Certain information and disclosures normally included in
 financial statements prepared in accordance with accounting
 principles generally accepted in the United States of America (U.S.
 GAAP) have been condensed or omitted pursuant to such rules and
 regulations. These consolidated condensed financial statements
 reflect all adjustments (consisting only of normal recurring
 adjustments) which, in the opinion of management, are necessary to
 present fairly the financial position, the results of operations
 and cash flows of the Company for the periods presented. It is
 suggested that these consolidated condensed financial statements be
 read in conjunction with the consolidated financial statements and
 the notes thereto included in the Company’s most recent
 Annual Report on Form 10-K. The results of operations for
 the interim periods are not necessarily indicative of the results
 to be expected for the full year. The preparation of financial
 statements in accordance with U.S. GAAP requires management to make
 estimates and assumptions that affect the amounts reported in the
 Company’s consolidated condensed financial statements and
 accompanying notes. Actual results could differ materially from
 those estimates. The Company uses a 13-week fiscal quarter accounting
 period with the fourth quarter ending on the Monday nearest
 December 31.


## us-gaap:ScheduleOfEarningsPerShareBasicAndDilutedTableTextBlock

[0001193125-17-337320:notes:60]
The
 following is a reconciliation of the numerator and denominator used
 to calculate basic earnings per share and diluted earnings per
 share for the quarters and three quarters ended October 2,
 2017 and September 26, 2016:

[0001193125-17-337320:notes:61]
|  |  | Quarter Ended |  |  | Three Quarters Ended |  |
|  |  | October 2, 2017 |  |  | September 26, 2016 |  |  | October 2, 2017 |  |  | September 26, 2016 |  |
|  |  | (In thousands, except per share amounts) |  |
| Basic earnings: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic earning |  | $ | 21,453 |  |  | $ | 25,582 |  |  | $ | 75,003 |  |  | $ | 36,866 |  |
| Diluted earnings: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Net income attributable to TTM Technologies, Inc. stockholders |  | $ | 21,453 |  |  | $ | 25,582 |  |  | $ | 75,003 |  |  | $ | 36,866 |  |
| Interest expense from convertible senior notes, net of tax |  |  | 3,469 |  |  |  | 3,321 |  |  |  | 10,296 |  |  |  | — |  |
| Diluted earnings |  | $ | 24,922 |  |  | $ | 28,903 |  |  | $ | 85,299 |  |  | $ | 36,866 |  |
| Basic shares |  |  | 101,814 |  |  |  | 100,245 |  |  |  | 101,501 |  |  |  | 100,004 |  |
| Dilutive effect of performance-based restricted stock units, restricted stock units and stock options |  |  | 1,692 |  |  |  | 1,460 |  |  |  | 1,721 |  |  |  | 1,090 |  |
| Dilutive effect of outstanding warrants |  |  | 2,151 |  |  |  | — |  |  |  | 2,753 |  |  |  | — |  |
| Dilutive effect of assumed conversion of convertible senior notes outstanding |  |  | 25,939 |  |  |  | 25,940 |  |  |  | 25,939 |  |  |  | — |  |
| Diluted shares |  |  | 131,596 |  |  |  | 127,645 |  |  |  | 131,914 |  |  |  | 101,094 |  |
| Earnings per share attributable to TTM Technologies, Inc. stockholders: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  | $ | 0.21 |  |  | $ | 0.26 |  |  | $ | 0.74 |  |  | $ | 0.37 |  |
| Diluted |  | $ | 0.19 |  |  | $ | 0.23 |  |  | $ | 0.65 |  |  | $ | 0.36 |  |


## us-gaap:ScheduleofFiniteLivedIntangibleAssetsFutureAmortizationExpenseTableTextBlock

[0001193125-17-337320:notes:62]
[same as prior period, unchanged from 0001193125-17-251481:notes:59]

[0001193125-17-337320:notes:63]
|  |  | (In thousands) |  |
| Remaining 2017 |  | $ | 5,913 |  |
| 2018 |  |  | 22,841 |  |
| 2019 |  |  | 18,746 |  |
| 2020 |  |  | 18,746 |  |
| 2021 |  |  | 14,921 |  |
| Thereafter |  |  | 27,674 |  |
|  |  | $ | 108,841 |  |


## us-gaap:ScheduleOfGoodwillTextBlock

[0001193125-17-337320:notes:64]
As of October 2, 2017 and January 2, 2017, goodwill
 was as follows:

[0001193125-17-337320:notes:65]
|  |  | Total |  |
|  |  | (In thousands) |  |
| Balance as of January 2, 2017 |  | $ | 372,609 |  |
| Foreign currency translation adjustment |  |  | (85 | ) |
| Balance as of October 2, 2017 |  | $ | 372,524 |  |


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0001193125-17-337320:notes:66]
(8) Accumulated Other
 Comprehensive Income (Loss)

[0001193125-17-337320:notes:67]
Amounts reclassified out of accumulated other comprehensive
 income (loss) to depreciation expense related to cash flow hedges
 was $43 and $47 net of tax for the quarters ended October 2,
 2017 and September 26, 2016, respectively, and $130 and $128
 net of tax for the three quarters ended October 2, 2017 and
 September 26, 2016, respectively.


## us-gaap:FairValueLiabilitiesMeasuredOnRecurringBasisTextBlock

[0001193125-17-337320:notes:68]
The
 carrying amount and estimated fair value of the Company’s
 financial instruments at October 2, 2017 and January 2,
 2017 were as follows:

[0001193125-17-337320:notes:69]
|  |  | October 2, 2017 |  |  | January 2, 2017 |  |
|  |  | Carrying Amount |  |  | Fair Value |  |  | Carrying Amount |  |  | Fair Value |  |
|  |  | (In thousands) |  |
| Term Loan due September 2024 |  | $ | 345,447 |  |  | $ | 347,594 |  |  |  | — |  |  |  | — |  |
| Term Loan due May 2021 |  |  | — |  |  |  | — |  |  | $ | 699,023 |  |  | $ | 708,750 |  |
| Senior Notes due October 2025 |  |  | 368,151 |  |  |  | 380,430 |  |  |  | — |  |  |  | — |  |
| Convertible Senior Notes |  |  | 215,863 |  |  |  | 423,050 |  |  |  | 208,861 |  |  |  | 380,875 |  |
| ABL Revolving Loans |  |  | 47,000 |  |  |  | 47,000 |  |  |  | 110,000 |  |  |  | 110,000 |  |
| Capital Lease |  |  | 1,884 |  |  |  | 1,884 |  |  |  | 1,798 |  |  |  | 1,798 |  |


## us-gaap:IntangibleAssetsDisclosureTextBlock

[0001193125-17-337320:notes:70]
(5) Definite-lived
 Intangibles

[0001193125-17-337320:notes:71]
As of October 2, 2017 and January 2, 2017, the
 components of definite-lived intangibles were as
 follows:

[0001193125-17-337320:notes:72]
|  |  | Gross Amount |  |  | Accumulated Amortization |  |  | Foreign Currency Translation Adjustment |  |  | Net Carrying Amount |  |  | Weighted Average Amortization Period |  |
|  |  | (In thousands) |  |  | (years) |  |
| October 2, 2017: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Customer relationships |  | $ | 203,563 |  |  | $ | (95,433 | ) |  | $ | 57 |  |  | $ | 108,187 |  |  |  | 8.1 |  |
| Technology |  |  | 3,000 |  |  |  | (2,346 | ) |  |  | — |  |  |  | 654 |  |  |  | 3.0 |  |
|  |  | $ | 206,563 |  |  | $ | (97,779 | ) |  | $ | 57 |  |  | $ | 108,841 |  |  |  |  |  |
| January 2, 2017: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Customer relationships |  | $ | 203,563 |  |  | $ | (78,473 | ) |  | $ | 119 |  |  | $ | 125,209 |  |  |  | 8.1 |  |
| Technology |  |  | 3,000 |  |  |  | (1,596 | ) |  |  | — |  |  |  | 1,404 |  |  |  | 3.0 |  |
|  |  | $ | 206,563 |  |  | $ | (80,069 | ) |  | $ | 119 |  |  | $ | 126,613 |  |  |  |  |  |

[0001193125-17-337320:notes:73]
The October 2, 2017 and January 2, 2017
 definite-lived intangible balances include foreign currency
 translation adjustments related to foreign subsidiaries with
 functional currencies other than the U.S. dollar.

[0001193125-17-337320:notes:74]
Definite-lived intangibles are generally amortized using the
 straight line method of amortization over the useful life, with the
 exception of certain customer relationship intangibles, which are
 amortized using an accelerated method of amortization based on
 estimated cash flows. Amortization expense was $5,905 and $5,949
 for the quarters ended October 2, 2017 and September 26,
 2016, respectively, and $17,727 and $17,845 for the three quarters
 October 2, 2017 and September 26, 2016,
 respectively.


## us-gaap:ConcentrationRiskDisclosureTextBlock

[0001193125-17-337320:notes:75]
(9) Significant Customers
 and Concentration of Credit Risk

[0001193125-17-337320:notes:76]
In the
 normal course of business, the Company extends credit to its
 customers. Most customers to which the Company extends credit are
 located outside the United States. The Company performs ongoing
 credit evaluations of customers, does not require collateral, and
 considers the credit risk profile of the entity from which the
 receivable is due in further evaluating collection risk.

[0001193125-17-337320:notes:77]
The
 Company’s customers include both OEMs and EMS companies. The
 Company’s OEM customers often direct a significant portion of
 their purchases through EMS companies. While the Company’s
 customers include both OEM and EMS providers, the Company measures
 customer concentration based on OEM companies, as they are the
 ultimate end customers.

[0001193125-17-337320:notes:78]
For
 the quarters ended October 2, 2017 and September 26,
 2016, one customer accounted for approximately 21% and 17%,
 respectively, of the Company’s net sales. For the three
 quarters ended October 2, 2017 and September 26, 2016,
 one customer accounted for approximately 18% and 13%, respectively,
 of the Company’s net sales. There were no other customers
 that accounted for 10% or more of net sales for the quarters or
 three quarters ended October 2, 2017 and September 26,
 2016.


## us-gaap:EarningsPerShareTextBlock

[0001193125-17-337320:notes:79]
(12) Earnings Per
 Share

[0001193125-17-337320:notes:80]
Performance-based restricted stock units (PRUs), restricted
 stock units (RSUs) and stock options to purchase 631 and 233 shares
 of common stock for the quarter ended ended October 2,
 2017 and September 26, 2016, respectively, and 275 and 1,174
 for the three quarters ended October 2, 2017 and
 September 26, 2016, respectively, were not considered in
 calculating diluted earnings per share because the options’
 exercise prices or the total expected proceeds under the treasury
 stock method for PRUs, RSUs or stock options was greater than the
 average market price of common shares during the applicable quarter
 and, therefore, the effect would be anti-dilutive.

[0001193125-17-337320:notes:81]
For
 the three quarters ended September 26, 2016, the effect of
 shares of common stock related to the Company’s convertible
 senior notes, based on the if-converted method, were not included
 in the computation of dilutive earnings per share as the impact
 would be anti-dilutive.

[0001193125-17-337320:notes:82]
For
 both the quarter and three quarters ended September 26, 2016,
 outstanding warrants to purchase 25,940 shares were not included in
 the computation of dilutive earnings per share because the strike
 price of the warrants to purchase the Company’s common stock
 were greater than the average market price of common shares during
 the applicable quarter and three quarters, and therefore, the
 effect would be anti-dilutive.


## us-gaap:FairValueDisclosuresTextBlock

[0001193125-17-337320:notes:83]
(10) Fair Value
 Measures

[0001193125-17-337320:notes:84]
The
 Company measures at fair value its financial and non-financial assets by using a fair
 value hierarchy that prioritizes the inputs to valuation techniques
 used to measure fair value. Fair value is the price that would be
 received to sell an asset or paid to transfer a liability in an
 orderly transaction between market participants at the measurement
 date, essentially an exit price, based on the highest and best use
 of the asset or liability.

[0001193125-17-337320:notes:85]
The
 fair value of the long-term debt was estimated based on quoted
 market prices or discounting the debt over its life using current
 market rates for similar debt as of October 2, 2017 and
 January 2, 2017, which are considered Level 2
 inputs.

[0001193125-17-337320:notes:86]
The
 fair value of the convertible senior notes was estimated based on
 quoted market prices of the securities on an active exchange, which
 are considered Level 2 inputs.

[0001193125-17-337320:notes:87]
As of
 October 2, 2017 and January 2, 2017, the Company’s
 other financial instruments also included cash and cash
 equivalents, accounts receivable, accounts payable and equipment
 payables. Due to short-term maturities, the carrying amount of
 these instruments approximates fair value. Our cash and cash
 equivalents at October 2, 2017 consisted of $95,471 held in
 the U.S., with the remaining $206,463 held by foreign
 subsidiaries.

[0001193125-17-337320:notes:88]
The
 majority of the Company’s non-financial assets and liabilities,
 which include goodwill, intangible assets, inventories, and
 property, plant and equipment, are not required to be carried at
 fair value on a recurring basis. However, if certain triggering
 events occur (or are tested at least annually in the case of
 goodwill) such that a non-financial instrument is required to
 be evaluated for impairment, based upon a comparison of the
 non-financial
 instrument’s fair value to its carrying value, an impairment
 is recorded to reduce the carrying value to the fair value, if the
 carrying value exceeds the fair value.

[0001193125-17-337320:notes:89]
The
 Company recognized impairment charges related to long-lived assets
 of $3,346 in the three quarters ended September 26, 2016. The
 fair values of their impaired long-lived assets were based on level
 3 inputs. There was no impairment of long-lived assets recognized
 in the quarter ended September 26, 2016 or for the quarter and
 three quarters ended October 2, 2017.


## us-gaap:GoodwillDisclosureTextBlock

[0001193125-17-337320:notes:90]
[same as prior period, unchanged from 0001193125-17-251481:notes:91]

[0001193125-17-337320:notes:91]
[same as prior period, unchanged from 0001193125-17-251481:notes:92]

[0001193125-17-337320:notes:92]
[same as prior period, unchanged from 0001193125-17-251481:notes:93]


## us-gaap:LongTermDebtTextBlock

[0001193125-17-337320:notes:93]
(6) Long-term Debt and
 Letters of Credit

[0001193125-17-337320:notes:94]
On September 28, 2017, the Company entered into a $350,000
 Term Loan Facility due 2024 (Term Loan Facility), and issued
 $375,000 of Senior Notes due 2025 (Senior Notes). In conjunction
 with the issuance of the Term Loan Facility and Senior Notes, the
 Company repaid in full the remaining outstanding balance of the
 September 27, 2016 Term Loan Credit Agreement (2016 Term Loan)
 and repaid $63,000 on its existing U.S. Asset-Based Lending Credit
 Agreement. The Company recognized a loss on extinguishment of debt
 of $768 primarily associated with the write off of the remaining
 2016 Term Loan debt issuance costs.

[0001193125-17-337320:notes:95]
Term Loan
 Facility

[0001193125-17-337320:notes:96]
The Term Loan Facility, of which $3,500 is included in
 short-term debt and $346,500 is included in long-term debt, was
 issued at a discount at 99.5% and bears interest, at the
 Company’s option, at a floating rate of LIBOR, plus an
 applicable interest margin of 2.5%, or an alternate base rate,
 (defined as the greater of the JP Morgan prime, the New York Fed
 bank rate plus 0.9% or LIBOR plus 1.0%), subject to a 1.0% floor
 plus an applicable margin of 1.5%. At October 2, 2017 the
 interest rate on the outstanding borrowings under the Term Loan
 Facility was 3.73%. There is no provision, other than an event of
 default, for the interest margin to increase. The Term Loan
 Facility will mature on September 28, 2024. The Term Loan
 Facility is secured by a significant amount of the assets of the
 Company and a pledge of 65% of voting stock of the Company’s
 first tier foreign subsidiaries and is structurally senior to the
 Company’s Senior Notes and Convertible Senior Notes. See
 Senior Notes and Convertible Senior Notes below.

[0001193125-17-337320:notes:97]
The Company is required to make scheduled payments of the
 outstanding Term Loan Facility balance on a quarterly basis
 beginning January 1, 2018. Based on certain parameters defined
 in the Term Loan Facility, including a First Lien Leverage Ratio,
 the Company may be required to make an additional principal payment
 on an annual basis beginning after fiscal year 2018, if the
 Company’s First Lien Leverage Ratio is greater than 2.0. Any
 additional annual payments or prepayments would reduce future
 required scheduled payments. Any remaining outstanding balances
 under the Term Loan Facility are due at the maturity date of
 September 28, 2024.

[0001193125-17-337320:notes:98]
Borrowings under the Term Loan Facility are subject to certain
 affirmative and negative covenants, including limitations on
 indebtedness, corporate transactions, investments and dispositions,
 and share payments. The Company and its domestic subsidiaries have
 fully and unconditionally guaranteed the full and timely payment of
 Term Loan Facility related obligations.

[0001193125-17-337320:notes:99]
Senior
 Notes

[0001193125-17-337320:notes:100]
The $375,000 of Senior Notes issued, which is included in
 long-term debt, bear interest at a rate of 5.63% per annum.
 Interest is payable semiannually in arrears on April 1 and
 October 1 of each year beginning April 1, 2018. The
 Senior Notes will mature on October 1, 2025. The Senior Notes
 are unsecured obligations and are guaranteed by the Company’s
 subsidiaries that guarantee its senior secured credit facilities,
 subject to certain exceptions.

[0001193125-17-337320:notes:101]
Borrowings under the Senior Notes are subject to certain
 affirmative and negative covenants, including limitations on
 indebtedness, corporate transactions, investments and dispositions,
 and share payments.

[0001193125-17-337320:notes:102]
Convertible Senior
 Notes due 2020

[0001193125-17-337320:notes:103]
The Company maintains 1.75% convertible senior notes in the
 amount of $249,985 due December 15, 2020. The convertible
 senior notes bear interest at a rate of 1.75% per annum.
 Interest is payable semiannually in arrears on June 15 and
 December 15 of each year. The convertible senior notes are
 unsecured obligations, are subordinated to the Senior Notes above,
 and would rank equally to the Company’s future unsecured
 senior indebtedness and are senior in right of payment to any of
 the Company’s future subordinated indebtedness.

[0001193125-17-337320:notes:104]
The components of interest expense resulting from the
 convertible senior notes for the quarters and three quarters ended
 October 2, 2017 and September 26, 2016 are as
 follows:

[0001193125-17-337320:notes:105]
|  |  | For the Quarter Ended |  |  | For the Three Quarters Ended |  |
|  |  | October 2, 2017 |  |  | September 26, 2016 |  |  | October 2, 2017 |  |  | September 26, 2016 |  |
|  |  | (In thousands) |  |
| Contractual coupon interest |  | $ | 1,094 |  |  | $ | 1,094 |  |  | $ | 3,281 |  |  | $ | 3,281 |  |
| Amortization of debt discount |  | $ | 2,159 |  |  | $ | 2,025 |  |  | $ | 6,376 |  |  | $ | 5,977 |  |
| Amortization of debt issuance costs |  | $ | 216 |  |  | $ | 202 |  |  | $ | 639 |  |  | $ | 599 |  |

[0001193125-17-337320:notes:106]
Asset-Based Lending
 Agreements

[0001193125-17-337320:notes:107]
The Company continues to maintain a $200,000 U.S. Asset-Based
 Lending Credit Agreement (U.S. ABL), and a $150,000 Asia
 Asset-Based Lending Credit Agreement (Asia ABL) (collectively the
 ABL Revolving Loans).

[0001193125-17-337320:notes:108]
The U.S. ABL consists of three tranches comprised of a
 revolving credit facility of up to $200,000, a letter of credit
 facility of up to $50,000, and swingline loans of up to $30,000,
 provided that at no time may amounts outstanding under the tranches
 exceed in aggregate $200,000 or the applicable borrowing base,
 which is a percentage of the principal amount of Eligible Accounts,
 as defined in the U.S. ABL agreement. Borrowings under the U.S. ABL
 bear interest at either a floating rate of LIBOR plus a margin of
 150 basis points or JP Morgan Chase Bank’s prime rate plus a
 margin of 50 basis points, at the Company’s option. At
 October 2, 2017, the interest rate on the outstanding
 borrowings under the U.S. ABL was 2.73%. The applicable margin can
 vary based on the remaining availability of the facility, from 125
 to 175 basis points for LIBOR-based loans and from 25 to 75 basis
 points for JP Morgan Chase Bank’s prime rate-based loans.
 Other than availability and an event of default, there are no other
 provisions for the interest margin to increase. The U.S. ABL will
 mature on May 31, 2020. Loans made under the U.S. ABL are
 secured first by all of the Company’s domestic cash,
 receivables and inventories as well as by a second position against
 a significant amount of the assets of the Company and a pledge of
 65% of voting stock of the Company’s first tier foreign
 subsidiaries and are structurally senior to the Company’s
 Senior Notes and Convertible Senior Notes. See Senior Notes and
 Convertible Senior Notes above. As noted earlier, concurrent with
 the issuance of the Term Loan Facility and Senior Notes, the
 Company paid down $63,000 of the outstanding balance of its U.S.
 ABL. The Company and its domestic subsidiaries have fully and
 unconditionally guaranteed the full and timely payment of U.S. ABL
 related obligations. At October 2, 2017, $17,000 of the U.S.
 ABL was outstanding and classified as long-term debt, which is
 consistent with its maturity date.

[0001193125-17-337320:notes:109]
The Asia ABL consists of two tranches comprised of a revolving
 credit facility of up to $150,000 and a letter of credit facility
 of up to $100,000, provided that at no time may amounts outstanding
 under both tranches exceed in aggregate $150,000 or the applicable
 borrowing base, which is a percentage of the principal amount of
 Eligible Accounts, as defined in the Asia ABL agreement. Borrowings
 under the Asia ABL bear interest at a floating rate of LIBOR plus
 140 basis points. At October 2, 2017, the interest rate on the
 outstanding borrowings under the Asia ABL was 2.63%. There is no
 provision, other than an event of default, for the interest margin
 to increase. The Asia ABL will mature on May 22, 2020. Loans
 made under the Asia ABL are secured by a portion of the
 Company’s Asia Pacific cash and receivables and are
 structurally senior to the Company’s domestic obligations,
 including the Senior Notes and Convertible Senior Notes. See Senior
 Notes and Convertible Senior Notes above. The Company’s Asia
 Pacific subsidiary and certain of its subsidiaries have fully and
 unconditionally guaranteed the full and timely payment of all Asia
 ABL related obligations. At October 2, 2017, $30,000 of the
 Asia ABL was outstanding and classified as long-term debt, which is
 consistent with its maturity date.

[0001193125-17-337320:notes:110]
The Company has up to $50,000 and $100,000 Letters of Credit
 Facilities under the U.S. ABL and the Asia ABL, respectively. As of
 October 2, 2017 letters of credit in the amount of $7,612 were
 outstanding under the U.S. ABL and $45,026 were outstanding under
 the Asia ABL with various expiration dates through March 2019.
 Available borrowing capacity under the U.S. ABL and the Asia ABL
 was $175,388 and $74,974, respectively, which considers letters of
 credit outstanding of $7,612 and $45,026, respectively, at
 October 2, 2017.

[0001193125-17-337320:notes:111]
The Company is required to pay a commitment fee of 0.25% to
 0.375% per annum on any unused portion of the U.S ABL and the
 Asia ABL. The Company incurred total commitment fees related to
 unused borrowing availability of $179 and $171 for the quarters
 ended October 2, 2017 and September 26, 2016,
 respectively, and $546 and $516 for the three quarters ended
 October 2, 2017 and September 26, 2016,
 respectively.

[0001193125-17-337320:notes:112]
Under the occurrence of certain events, the ABL Revolving Loans
 are subject to various financial and operational covenants,
 including maintaining minimum fixed charge coverage
 ratios.

[0001193125-17-337320:notes:113]
Other Credit
 Facility

[0001193125-17-337320:notes:114]
Additionally, the Company is party to a revolving loan credit
 facility (Chinese Revolver) with a lender in China. Under this
 arrangement, the lender has made available to the Company
 approximately $31,700 in unsecured borrowing with all terms of the
 borrowing to be negotiated at the time the Chinese Revolver is
 drawn upon. There are no commitment fees on the unused portion of
 the Chinese Revolver, and this arrangement expires in January 2018.
 As of October 2, 2017, the Chinese Revolver had not been drawn
 upon.

[0001193125-17-337320:notes:115]
Debt Issuance and
 Debt Discount

[0001193125-17-337320:notes:116]
As of October 2, 2017 and January 2, 2017, remaining
 unamortized debt discount and debt issuance costs for the Term Loan
 Facility, Senior Notes, Convertible Senior Notes and 2016 Term Loan
 are as follows:

[0001193125-17-337320:notes:117]
|  |  | As of October 2, 2017 |  |  | As of January 2, 2017 |  |
|  |  | Debt Issuance Costs |  |  | Debt Discount |  |  | Effective Interest Rate |  |  | Debt Issuance Costs |  |  | Debt Discount |  |  | Effective Interest Rate |  |
|  |  | (in thousands) |  |
| Term Loan due September 2024 |  | $ | 2,803 |  |  | $ | 1,750 |  |  |  | 3.95 | % |  |  | — |  |  |  | — |  |  |  | — |  |
| Senior Notes due October 2025 |  |  | 6,849 |  |  |  | — |  |  |  | 5.91 | % |  |  | — |  |  |  | — |  |  |  | — |  |
| Convertible Senior Notes |  |  | 3,108 |  |  |  | 31,014 |  |  |  | 6.48 | % |  | $ | 3,747 |  |  | $ | 37,392 |  |  |  | 6.48 | % |
| Term Loan due May 2021 |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 977 |  |  |  | — |  |  |  | 5.48 | % |
|  |  | $ | 12,760 |  |  | $ | 32,764 |  |  |  |  |  |  | $ | 4,724 |  |  | $ | 37,392 |  |  |  |  |  |

[0001193125-17-337320:notes:118]
The above debt discount and debt issuance costs are recorded as
 a reduction of the debt and are amortized into interest expense
 using an effective interest rate over the duration of the
 debt.

[0001193125-17-337320:notes:119]
Debt issuance costs for the ABL Revolving Loans of $2,672 and
 $3,423 as of October 2, 2017 and January 2, 2017,
 respectively, are included in other non-current assets and are amortized
 to interest expense over the duration of the ABL Revolving Loans
 using the straight line method of amortization.

[0001193125-17-337320:notes:120]
At October 2, 2017, the remaining weighted average
 amortization period for all unamortized debt discount and debt
 issuance costs was 4.2 years.


## us-gaap:MinorityInterestDisclosureTextBlock

[0001193125-17-337320:notes:121]
(16) Noncontrolling
 Interest Holdings

[0001193125-17-337320:notes:122]
Subsequent to October 2, 2017, the Company entered into an
 agreement with Desay Industrial to acquire Desay Industrial’s
 5% noncontrolling equity interest in the manufacturing facility in
 Huiyang, China otherwise owned by the Company for 56,400 Chinese
 RMB or approximately $8,500. Any difference between the purchase
 price and the carrying value of the noncontrolling interest will be
 recorded in additional paid in capital. The Company expects this
 transaction to be completed by the end of 2017.


## us-gaap:RelatedPartyTransactionsDisclosureTextBlock

[0001193125-17-337320:notes:123]
(15) Related Party
 Transactions

[0001193125-17-337320:notes:124]
In the
 normal course of business, the Company’s foreign subsidiaries
 purchase laminate and prepreg from related parties in which a
 significant shareholder of the Company holds an equity interest.
 The Company purchased laminate and prepreg from these related
 parties in the amount of $13,225 and $12,292 for the quarters ended
 October 2, 2017 and September 26, 2016, respectively, and
 $38,886 and $42,549 for the three quarters ended October 2,
 2017 and September 26, 2016, respectively.

[0001193125-17-337320:notes:125]
The
 Company also sells PCBs to a related party which is a wholly owned
 subsidiary of an entity in which a significant shareholder of the
 Company holds an equity interest. Sales to this related party for
 the quarters ended October 2, 2017 and September 26, 2016
 were $5 and $254, respectively, and $53 and $863 for the three
 quarters ended October 2, 2017 and September 26, 2016,
 respectively.

[0001193125-17-337320:notes:126]
As of
 October 2, 2017 and January 2, 2017, the Company’s
 consolidated condensed balance sheets included $15,490 and $15,836,
 respectively, in accounts payable due to related parties primarily
 for purchases of laminate and prepreg and such balances are
 included as a component of accounts payable on the consolidated
 condensed balance sheets. Additionally, the Company’s
 consolidated condensed balance sheets included $9 and $192,
 respectively, in accounts receivable due from a related party for
 sales of PCBs, as mentioned above, and such balances are included
 as a component of accounts receivable, net on the consolidated
 condensed balance sheets.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001193125-17-337320:notes:127]
(14) Segment
 Information

[0001193125-17-337320:notes:128]
The reportable segments below are the Company’s segments
 for which separate financial information is available and upon
 which operating results are evaluated by the chief operating
 decision maker to assess performance and to allocate resources. The
 Company has two reportable segments: PCB and E-M Solutions. The PCB reportable
 segment is comprised of multiple operating segments. Factors
 considered to determine whether operating segments can be
 aggregated into reportable segments included similarity regarding
 economic characteristics, products, production processes, type or
 classes of customers, distribution methods, and regulatory
 environments.

[0001193125-17-337320:notes:129]
The Company, including the chief operating decision maker,
 evaluates segment performance based on reportable segment income,
 which is operating income before amortization of intangibles.
 Interest expense and interest income are not presented by segment
 since they are not included in the measure of segment profitability
 reviewed by the chief operating decision maker. All inter-segment
 transactions have been eliminated.

[0001193125-17-337320:notes:130]
The Corporate category includes operating expenses that are not
 included in the reportable segment operating performance measures.
 Corporate consists primarily of corporate governance functions such
 as finance, accounting, corporate sales, information technology,
 facilities, corporate operations and human resources
 personnel.
