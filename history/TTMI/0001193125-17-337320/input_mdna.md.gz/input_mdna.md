# TTMI MD&A — 0001193125-17-337320


## mdna

[0001193125-17-337320:mdna:1]
[same as prior period, unchanged from 0001193125-17-251481:mdna:1]

[0001193125-17-337320:mdna:2]
[same as prior period, unchanged from 0001193125-17-251481:mdna:2]

[0001193125-17-337320:mdna:3]
[same as prior period, unchanged from 0001193125-17-251481:mdna:3]

[0001193125-17-337320:mdna:4]
[same as prior period, unchanged from 0001193125-17-251481:mdna:4]

[0001193125-17-337320:mdna:5]
[same as prior period, unchanged from 0001193125-17-251481:mdna:5]

[0001193125-17-337320:mdna:6]
[same as prior period, unchanged from 0001193125-17-251481:mdna:6]

[0001193125-17-337320:mdna:7]
[same as prior period, unchanged from 0001193125-17-251481:mdna:7]

[0001193125-17-337320:mdna:8]
[same as prior period, unchanged from 0001193125-17-251481:mdna:8]

[0001193125-17-337320:mdna:9]
|  | • |  | Adverse outcomes in litigation or proceedings with governmental authorities or administrative agencies, or changes in the regulatory environment, any of which could encumber or impede our efforts to improve operating results or the value of assets; |

[0001193125-17-337320:mdna:10]
[same as prior period, unchanged from 0001193125-17-251481:mdna:10]

[0001193125-17-337320:mdna:11]
[same as prior period, unchanged from 0001193125-17-251481:mdna:11]

[0001193125-17-337320:mdna:12]
[same as prior period, unchanged from 0001193125-17-251481:mdna:12]

[0001193125-17-337320:mdna:13]
[same as prior period, unchanged from 0001193125-17-251481:mdna:13]

[0001193125-17-337320:mdna:14]
[same as prior period, unchanged from 0001193125-17-251481:mdna:14]

[0001193125-17-337320:mdna:15]
[same as prior period, unchanged from 0001193125-17-251481:mdna:15]

[0001193125-17-337320:mdna:16]
[same as prior period, unchanged from 0001193125-17-251481:mdna:16]

[0001193125-17-337320:mdna:17]
We are a leading global printed circuit board (PCB) manufacturer, focusing on quick-turn and volume production of technologically complex PCBs and electro-mechanical solutions (E-M Solutions). We focus on providing time-to-market and volume production of advanced technology products and offer a one-stop manufacturing solution to our customers from engineering support to prototype development through final mass production. This one-stop manufacturing solution enables
us to align technology development with the diverse needs of our customers and to enable them to reduce the time required to develop new products and bring them to market. We serve a diversified customer base consisting of approximately 1,700
customers in various markets throughout the world, including aerospace and defense, automotive components, smartphones and touchscreen tablets, high-end computing, medical, industrial and instrumentation
related products, as well as networking/communications infrastructure products. Our customers include both original equipment manufacturers (OEMs) and electronic manufacturing services (EMS) providers.

[0001193125-17-337320:mdna:18]
[same as prior period, unchanged from 0001193125-17-251481:mdna:18]

[0001193125-17-337320:mdna:19]
On September 28, 2017, we entered into a new $350.0 million
Term Loan Facility due 2024 (Term Loan Facility) at a floating rate of LIBOR plus an applicable margin of 2.5%, or 3.73% at October 2, 2017, and issued $375.0 million of Senior Notes due 2025 (Senior Notes) at a rate of 5.63%. In conjunction
with the issuance of the Term Loan Facility and Senior Notes, we repaid in full the remaining outstanding balance of the September 27, 2016 Term Loan Credit Agreement (2016 Term Loan), which had a floating rate of LIBOR, with a 1.0% LIBOR
floor, plus a margin of 3.25% and repaid $63.0 million on our existing U.S. Asset-Based Lending Credit Agreement (U.S. ABL).

[0001193125-17-337320:mdna:20]
In the normal course of operations, we are exposed to risks associated with fluctuations in foreign currency exchange rates. Specifically, we are subject to risks associated with transactions that are
denominated in currencies other than our functional currencies. Our primary foreign exchange exposure is to the Chinese Renminbi (RMB). For the quarter and three quarters ended October 2, 2017, our consolidated condensed statement of operations
included a foreign exchange loss of approximately $7.4 million and $17.6 million, respectively, due primarily to the rapid appreciation of the RMB against the U.S. dollar. We do not engage in hedging to manage foreign currency risk related
to revenue and expenses denominated in RMB nor do we currently use derivative instruments to reduce exposure to foreign currency risk for a majority of our loans due from our foreign subsidiaries.

[0001193125-17-337320:mdna:21]
While our customers include both OEMs and EMS providers, we measure customers based on OEM companies, as they are the
ultimate end customers. Sales to our 10 largest customers accounted for 50% and 46% of our net sales for the quarters ended October 2, 2017 and September 26, 2016, respectively, and 46% and 42% for the three quarters ended October 2,
2017 and September 26, 2016, respectively. We sell to OEMs both directly and indirectly through EMS providers.

[0001193125-17-337320:mdna:22]
[same as prior period, unchanged from 0001193125-17-251481:mdna:23]

[0001193125-17-337320:mdna:23]
|  |  | Quarter Ended |  |  | Three Quarters Ended |  |
| End Markets(1)(2) |  | October 2,2017 |  |  | September 26,2016 |  |  | October 2,2017 |  |  | September 26,2016 |  |
| Aerospace and Defense |  |  | 16 | % |  |  | 15 | % |  |  | 16 | % |  |  | 15 | % |
| Automotive |  |  | 20 |  |  |  | 19 |  |  |  | 20 |  |  |  | 20 |  |
| Cellular Phone(2) |  |  | 17 |  |  |  | 17 |  |  |  | 15 |  |  |  | 12 |  |
| Computing/Storage/Peripherals(2) |  |  | 14 |  |  |  | 12 |  |  |  | 14 |  |  |  | 13 |  |
| Medical/Industrial/Instrumentation |  |  | 14 |  |  |  | 14 |  |  |  | 14 |  |  |  | 15 |  |
| Networking/Communications |  |  | 17 |  |  |  | 21 |  |  |  | 19 |  |  |  | 23 |  |
| Other(2) |  |  | 2 |  |  |  | 2 |  |  |  | 2 |  |  |  | 2 |  |
| Total |  |  | 100 | % |  |  | 100 | % |  |  | 100 | % |  |  | 100 | % |

[0001193125-17-337320:mdna:24]
[same as prior period, unchanged from 0001193125-17-251481:mdna:25]

[0001193125-17-337320:mdna:25]
| (2) | Smartphones are included in the Cellular Phone end market, tablets are included in the Computing/Storage/Peripherals end market and other consumer devices that include wearables, portable video devices and personal headphones are included in Other end market. |

[0001193125-17-337320:mdna:26]
[same as prior period, unchanged from 0001193125-17-251481:mdna:27]

[0001193125-17-337320:mdna:27]
[same as prior period, unchanged from 0001193125-17-251481:mdna:28]

[0001193125-17-337320:mdna:28]
[same as prior period, unchanged from 0001193125-17-251481:mdna:29]

[0001193125-17-337320:mdna:29]
General and administrative costs primarily include the salaries for executive, finance, accounting, information technology, and human resources personnel, as well as expenses for accounting and legal
assistance, incentive compensation expense, and gains or losses on the sale or disposal of property, plant and equipment.

[0001193125-17-337320:mdna:30]
21

[0001193125-17-337320:mdna:31]
[same as prior period, unchanged from 0001193125-17-251481:mdna:31]

[0001193125-17-337320:mdna:32]
[same as prior period, unchanged from 0001193125-17-251481:mdna:32]

[0001193125-17-337320:mdna:33]
[same as prior period, unchanged from 0001193125-17-251481:mdna:33]

[0001193125-17-337320:mdna:34]
[same as prior period, unchanged from 0001193125-17-251481:mdna:34]

[0001193125-17-337320:mdna:35]
[same as prior period, unchanged from 0001193125-17-251481:mdna:35]

[0001193125-17-337320:mdna:36]
|  |  | Quarter Ended |  |  | Three Quarters Ended |  |
|  |  | October 2, 2017 |  |  | September 26, 2016 |  |  | October 2, 2017 |  |  | September 26, 2016 |  |
| Net sales |  |  | 100.0 | % |  |  | 100.0 | % |  |  | 100.0 | % |  |  | 100.0 | % |
| Cost of goods sold |  |  | 85.5 |  |  |  | 82.9 |  |  |  | 84.5 |  |  |  | 84.1 |  |
| Gross profit |  |  | 14.5 |  |  |  | 17.1 |  |  |  | 15.5 |  |  |  | 15.9 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Selling and marketing |  |  | 2.4 |  |  |  | 2.4 |  |  |  | 2.5 |  |  |  | 2.7 |  |
| General and administrative |  |  | 4.6 |  |  |  | 5.6 |  |  |  | 4.6 |  |  |  | 5.9 |  |
| Amortization of definite-lived intangibles |  |  | 0.9 |  |  |  | 0.9 |  |  |  | 0.9 |  |  |  | 1.0 |  |
| Restructuring charges |  |  | — |  |  |  | 0.4 |  |  |  | 0.1 |  |  |  | 0.4 |  |
| Impairment of long-lived assets |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 0.2 |  |
| Total operating expenses |  |  | 7.9 |  |  |  | 9.3 |  |  |  | 8.1 |  |  |  | 10.2 |  |
| Operating income |  |  | 6.6 |  |  |  | 7.8 |  |  |  | 7.4 |  |  |  | 5.7 |  |
| Other income (expense): |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Interest expense |  |  | (2.0 | ) |  |  | (2.9 | ) |  |  | (2.1 | ) |  |  | (3.3 | ) |
| Loss on extinguishment of debt |  |  | (0.1 | ) |  |  | — |  |  |  | — |  |  |  | — |  |
| Other, net |  |  | (1.1 | ) |  |  | 0.6 |  |  |  | (0.8 | ) |  |  | 0.4 |  |
| Total other expense, net |  |  | (3.2 | ) |  |  | (2.3 | ) |  |  | (2.9 | ) |  |  | (2.9 | ) |
| Income before income taxes |  |  | 3.4 |  |  |  | 5.5 |  |  |  | 4.5 |  |  |  | 2.8 |  |
| Income tax provision |  |  | (0.2 | ) |  |  | (1.5 | ) |  |  | (0.6 | ) |  |  | (0.8 | ) |
| Net income |  |  | 3.2 |  |  |  | 4.0 |  |  |  | 3.9 |  |  |  | 2.0 |  |
| Less: Net income attributable to noncontrolling interest |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |
| Net income attributable to TTM Technologies, Inc. stockholders |  |  | 3.2 | % |  |  | 4.0 | % |  |  | 3.9 | % |  |  | 2.0 | % |

[0001193125-17-337320:mdna:37]
We have two reportable segments: PCB and E-M
Solutions. Factors considered to determine whether operating segments can be aggregated into reportable segments included similarity regarding economic characteristics, products, production processes, type or classes of customers, distribution
methods, and regulatory environments.

[0001193125-17-337320:mdna:38]
The following table compares net sales by reportable segment for the
quarters and three quarters ended October 2, 2017 and September 26, 2016:

[0001193125-17-337320:mdna:39]
|  |  | Quarter Ended |  |  | Three Quarters Ended |  |
|  |  | October 2, 2017 |  |  | September 26, 2016 |  |  | October 2, 2017 |  |  | September 26, 2016 |  |
|  |  | (In thousands) |  |
| Net Sales: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| PCB |  | $ | 609,742 |  |  | $ | 598,656 |  |  | $ | 1,773,003 |  |  | $ | 1,692,175 |  |
| E-M Solutions |  |  | 60,620 |  |  |  | 46,246 |  |  |  | 155,187 |  |  |  | 143,151 |  |
| Total sales |  |  | 670,362 |  |  |  | 644,902 |  |  |  | 1,928,190 |  |  |  | 1,835,326 |  |
| Inter-segment sales |  |  | (3,548 | ) |  |  | (3,182 | ) |  |  | (8,947 | ) |  |  | (8,501 | ) |
| Total net sales |  | $ | 666,814 |  |  | $ | 641,720 |  |  | $ | 1,919,243 |  |  | $ | 1,826,825 |  |

[0001193125-17-337320:mdna:40]
[same as prior period, unchanged from 0001193125-17-251481:mdna:40]

[0001193125-17-337320:mdna:41]
Total net sales increased $25.1 million, or 3.9%, from $641.7 million for the third quarter of 2016 to $666.8 million for the third quarter of 2017. Net sales for the PCB reportable
segment, excluding inter-segment sales, increased $10.7 million, or 1.8%, from $595.5 million for the third quarter of 2016 to $606.2 million for the third quarter of 2017. This increase was primarily due to higher demand in our
Computing/Storage/Peripherals, Aerospace/Defense, Medical/Industrial/Instrumentation and Cellular Phone end markets compared to the third quarter of 2016, partially offset by lower demand in our Networking/Communications end market. While these
changes resulted in a 2.4% decrease in PCB shipments as compared to the third quarter of 2016, average PCB selling price increased by 4.9%, which was driven by a product mix shift. Net sales for the E-M
Solutions reportable segment increased $14.4 million, or 31.2%, from $46.2 million for the third quarter of 2016 to $60.6 million for the third quarter of 2017. This increase was primarily due to higher demand in our Automotive end
market.

[0001193125-17-337320:mdna:42]
Total net sales increased $92.4 million, or 5.1%, from $1,826.8 million for the three
quarters of 2016 to $1,919.2 million for the three quarters of 2017. Net sales for the PCB reportable segment, excluding inter-segment sales, increased $80.4 million, or 4.8%, from $1,683.7 million for the three quarters of 2016 to
$1,764.1 million for the three quarters of 2017. The increase was primarily due to higher demand in our Cellular Phone, Computing/Storage/Peripherals and Aerospace/Defense end markets, partially offset by a decline in our
Networking/Communications end market. These changes resulted in a 2.7% increase in PCB shipments as compared to the three quarters of 2016, and an average PCB selling price increase of 1.9%, which was driven by a product mix shift. Net sales for the
E-M Solutions reportable segment increased $12.0 million, or 8.4%, from $143.2 million for the three quarters of 2016 to $155.2 million for the three quarters of 2017. The increase was primarily
due to higher demand in our Automotive end market, partially offset by lower demand in our Networking/Communications and Medical/Industrial/Instrumentation end market.

[0001193125-17-337320:mdna:43]
[same as prior period, unchanged from 0001193125-17-251481:mdna:43]

[0001193125-17-337320:mdna:44]
Overall gross margin decreased from
17.1% for the third quarter of 2016 to 14.5% for the third quarter of 2017. Gross margin for the PCB reportable segment decreased from 17.7% for the third quarter of 2016 to 15.5% for the third quarter of 2017, primarily due to the change in
classification of certain facilities and labor support related costs from general and administrative expenses to cost of goods sold due to changes in our business structure and higher costs in our Cellular Phone focused facilities due to multiple
new products ramping using a new technology. Gross margin for the E-M Solutions reportable segment decreased from 11.0% for the third quarter of 2016 to 8.7% for the third quarter of 2017, primarily due to mix
shift toward higher direct material content work.

[0001193125-17-337320:mdna:45]
Overall gross margin decreased from 15.9% for the three
quarters of 2016 to 15.5% for the three quarters of 2017. Gross margin for the PCB reportable segment decreased from 16.9% for the three quarters of 2016 to 16.6% for the three quarters of 2017, primarily due to the change of certain facilities and
labor support related costs from general and administrative expenses to cost of goods sold due to changes in our business structure and higher costs in our Cellular Phone focused facilities due to multiple new products ramping using a new
technology, partially offset by higher net sales due to increased volumes at our Cellular Phone and Computing/Storage/ Peripherals focused facilities. Gross margin for the E-M Solutions reportable segment
decreased from 8.6% for the three quarters of 2016 to 7.5% for the three quarters of 2017, primarily due to mix shift toward revenue with a higher direct material content work.

[0001193125-17-337320:mdna:46]
Capacity utilization is a key driver for us, particularly in our high volume Asia facilities, as a significant portion of
our operating costs are fixed in nature. Capacity utilization for the third quarter of 2016 in our Asia and North America PCB facilities was 86% and 58%, respectively, compared to 86% and 55%, respectively, in the third quarter of 2017. Capacity
utilization for the three quarters of 2016 in our Asia and North America PCB facilities was 79% and 58%, respectively, compared to 83% and 55%, respectively, in the third quarter of 2017.

[0001193125-17-337320:mdna:47]
23

[0001193125-17-337320:mdna:48]
[same as prior period, unchanged from 0001193125-17-251481:mdna:46]

[0001193125-17-337320:mdna:49]
Selling and marketing expenses increased $0.7 million, from $15.6 million for the third quarter of 2016 to
$16.3 million for the third quarter of 2017. As a percentage of net sales, selling and marketing expenses was 2.4% for both the third quarter of 2016 and the third quarter of 2017. The increase in selling and marketing expense primarily
related to higher sales commission expenses due to higher sales.

[0001193125-17-337320:mdna:50]
Selling and marketing expenses decreased
$0.7 million, from $49.5 million for the three quarters of 2016 to $48.8 million for the three quarters of 2017. As a percentage of net sales, selling and marketing expenses was 2.7% for the three quarters of 2016, as compared to 2.5%
for the three quarters of 2017. The decrease in selling and marketing expense primarily related to reduced headcount and lower travel expenses.

[0001193125-17-337320:mdna:51]
[same as prior period, unchanged from 0001193125-17-251481:mdna:48]

[0001193125-17-337320:mdna:52]
General and
administrative expenses decreased $5.1 million from $35.6 million, or 5.6% of net sales, for the third quarter of 2016 to $30.5 million, or 4.6% of net sales, for the third quarter of 2017. General and administrative expenses
decreased $19.8 million from $108.2 million, or 5.9% of net sales, for the three quarters of 2016 to $88.4 million, or 4.6% of net sales, for the three quarters of 2017. The decrease in expense for both comparative periods primarily
related to the change in classification of certain facilities and labor support related costs to cost of goods sold due to changes in our business structure and lower bad debt expense.

[0001193125-17-337320:mdna:53]
[same as prior period, unchanged from 0001193125-17-251481:mdna:54]

[0001193125-17-337320:mdna:54]
Other expense, net increased
$6.5 million from $14.9 million for the third quarter of 2016 to $21.4 million for the third quarter of 2017, resulting in an overall increase of $3.0 million from $52.4 million for the three quarters of 2016 to
$55.4 million for the three quarters of 2017. The net increase in other expense for the third quarter and three quarters of 2017 was primarily due to a $7.4 million and $17.6 million foreign currency loss, respectively, which was
partially offset in the case of the third quarter of 2017, and substantially offset in the case of the three quarters of 2017, by a decrease in interest expense. The foreign currency loss is primarily due to the appreciation of the RMB, which is the
functional currency at certain of our Asia facilities. The decrease in interest expense for both the quarter and three quarters of 2017 is due to lower principal outstanding resulting from net debt principal payments of $161.1 million during
the fourth quarter of 2016 and the first two quarters of 2017, a lower 2016 Term Loan interest rate by 75 basis points, and lower amortization of debt issuance costs and debt discount after the full repayment of our prior term loan in the fourth
quarter of 2016.

[0001193125-17-337320:mdna:55]
[same as prior period, unchanged from 0001193125-17-251481:mdna:57]

[0001193125-17-337320:mdna:56]
The provision for income taxes decreased by $8.3 million from $9.5 million of tax expense for the third quarter of 2016 to a provision of $1.2 million for the third quarter of 2017. The
decrease in income tax expense in the third quarter of 2017 was primarily due to decreased operating income and an increase in tax benefits from tax incentives, including a change in estimate of research and development deductions in China.

[0001193125-17-337320:mdna:57]
The provision for income taxes decreased by $3.1 million from $14.0 million of tax expense for the
three quarters of 2016 to $10.9 million of tax expense for the three quarters of 2017. The decrease in income tax expense for the three quarters of 2017 was primarily due to increased operating income in lower tax rate jurisdictions combined
with an increase in tax benefits from tax incentives, including a change in estimate of research and development deductions in China, partially offset by a reduction of benefits from the release of uncertain tax positions for the three quarters of
2017 compared to the benefits for the three quarters of 2016.

[0001193125-17-337320:mdna:58]
Our effective tax rate was primarily impacted
by tax rates in the U.S. (federal and apportioned state income), China and Hong Kong, the generation of other credits and deductions and certain non-deductible items. U.S. federal and state and certain foreign
losses generated are not more likely than not to be realizable and thus, no income tax benefit has been recognized on these losses. As of October 2, 2017, we had net deferred income tax liabilities of approximately $9.1 million and as of
January 2, 2017, we had net deferred income tax liabilities of approximately $14.0 million.

[0001193125-17-337320:mdna:59]
[same as prior period, unchanged from 0001193125-17-251481:mdna:62]

[0001193125-17-337320:mdna:60]
Our principal sources of liquidity have been cash provided by operations, the issuance of convertible
senior notes, senior notes, term loans, and revolving debt. Our principal uses of cash have been to finance acquisitions and capital expenditures, meet debt service requirements, fund working capital requirements, and repay existing debt. We
anticipate that servicing debt, financing capital expenditures, financing acquisitions, and funding working capital requirements will continue to be the principal demands on our cash in the future.

[0001193125-17-337320:mdna:61]
Cash flow provided by operating activities during the three quarters of
2017 was $180.1 million compared to $200.7 million for the same period in 2016. The decrease in cash flow was due to increased investment in working capital somewhat offset by higher net income. Cash cycle days were 45 days for the
third quarter of 2017 as compared to 46 days for the same quarter of 2016. As of October 2, 2017, we had net working capital of approximately $438.2 million compared to $323.8 million as of January 2, 2017.

[0001193125-17-337320:mdna:62]
Net cash used in investing activities was approximately $91.9 million for the three quarters of 2017 primarily
reflecting purchases of property, plant and equipment of $118.9 million less proceeds from sale of property, plant and equipment and assets held for sale of $27.0 million. Net cash used in investing activities was approximately
$57.5 million for the three quarters of 2016 primarily reflecting purchases of property, plant and equipment, net of proceeds from sales of property, plant and equipment and assets held for sale of $61.0 million, less release of restricted
cash to cash and cash equivalents of $3.5 million.

[0001193125-17-337320:mdna:63]
Net cash used by financing activities was
approximately $45.0 million the three quarters of 2017 reflecting proceeds from long-term debt totaling $725.0 million, offset by the repayment of $700.0 million of long-term debt, repayment of $63.0 million of a revolving loan,
and payment of debt issuance costs and original issue discount of $7.1 million associated with the Term Loan Facility and Senior Notes. Net cash used in financing activities was approximately $106.4 million for the three quarters of 2016
primarily reflecting the repayment of normally scheduled principal payments as well as additional prepayments of principal of long-term debt.

[0001193125-17-337320:mdna:64]
As of October 2, 2017, we had cash and cash equivalents of approximately $301.9 million, of which approximately $206.5 million was held by our foreign subsidiaries, primarily Asia. Cash and
cash equivalents held by our foreign locations are expected to be used in local operations.

[0001193125-17-337320:mdna:65]
Our 2017 net
capital expenditure is expected to be in the range of $155 million to $165 million, of which 40 percent are planned for technology enhancements, 30 percent for capacity expansions and 30 percent for compliance and
maintenance related expenditures.

[0001193125-17-337320:mdna:66]
Long-term Debt and Letters of Credit

[0001193125-17-337320:mdna:67]
On September 28, 2017, we entered into a $350.0 million Term Loan Facility, and issued $375.0 million of
Senior Notes. In conjunction with the issuance of the Term Loan Facility and Senior Notes, we repaid in full the remaining outstanding balance of the 2016 Term Loan and repaid $63.0 million of our existing U.S. ABL. We recognized a loss on
extinguishment of debt of $0.8 million primarily associated with the write off of the remaining 2016 Term Loan debt issuance costs.

[0001193125-17-337320:mdna:68]
Term Loan Facility

[0001193125-17-337320:mdna:69]
The Term Loan Facility, of which $3.5 million is included in short-term debt and $346.5 million is included in long-term debt, was issued at a discount at 99.5% and bears interest, at our
option, at a floating rate of LIBOR, plus an applicable interest margin of 2.5%, or an alternate base rate, (defined as the greater of the JP Morgan prime, the New York Fed bank rate plus 0.9% or LIBOR plus 1%), subject to a 1% floor plus an
applicable margin of 1.5%. At October 2, 2017 the interest rate on the outstanding borrowings under the Term Loan Facility was 3.73%. There is no provision, other than an event of default, for the interest margin to increase. The Term Loan
Facility will mature on September 28, 2024. The Term Loan Facility is secured by a significant amount of our assets and a pledge of 65% of voting stock of our first tier foreign subsidiaries and is structurally senior to our Senior Notes and
Convertible Senior Notes. See Senior Notes and Convertible Senior Notes below.

[0001193125-17-337320:mdna:70]
We are required to make
scheduled payments of the outstanding Term Loan Facility balance on a quarterly basis beginning January 1, 2018. Based on certain parameters defined in the Term Loan Facility, including a First Lien Leverage Ratio, we may be required to make an
additional principal payment on an annual basis beginning after fiscal year 2018, if our First Lien Leverage Ratio is greater than 2.0. Any additional annual payments or prepayments would reduce future required scheduled payments. Any remaining
outstanding balances under the Term Loan Facility are due at the maturity date of September 28, 2024.

[0001193125-17-337320:mdna:71]
Borrowings under the Term Loan Facility are subject to certain affirmative and negative covenants, including limitations
on indebtedness, corporate transactions, investments and dispositions, and share payments. At October 2, 2017, we were in compliance with the covenants under the Term Loan Facility. We and our domestic subsidiaries have fully and
unconditionally guaranteed the full and timely payment of Term Loan Facility related obligations.

[0001193125-17-337320:mdna:72]
Senior Notes

[0001193125-17-337320:mdna:73]
The $375.0 million of Senior Notes issued, which is included in long-term debt, bear interest at a rate of 5.63% per
annum. Interest is payable semiannually in arrears on April 1 and October 1 of each year beginning April 1, 2018. The Senior Notes will mature on October 1, 2025. The Senior Notes are unsecured obligations and are guaranteed by
our subsidiaries that guarantee our senior secured credit facilities, subject to certain exceptions.

[0001193125-17-337320:mdna:74]
Borrowings under the Senior Notes are subject to certain affirmative and negative covenants, including limitations on
indebtedness, corporate transactions, investments and dispositions, and share payments. At October 2, 2017, we were in compliance with the covenants under the Senior Notes.

[0001193125-17-337320:mdna:75]
Convertible Senior Notes due 2020

[0001193125-17-337320:mdna:76]
We maintain 1.75%
convertible senior notes in the amount of $250.0 million due December 15, 2020. The convertible senior notes bear interest at a rate of 1.75% per annum. Interest is payable semiannually in arrears on June 15 and December 15
of each year. The convertible senior notes are unsecured obligations, are subordinated to the Senior Notes above, and would rank equally to our future unsecured senior indebtedness and are senior in right of payment to any of our future subordinated
indebtedness.

[0001193125-17-337320:mdna:77]
Asset-Based Lending Agreements

[0001193125-17-337320:mdna:78]
We continue to maintain a $200.0 million U.S. ABL, and a $150.0 million Asia Asset-Based Lending Credit Agreement (Asia ABL) (collectively the ABL Revolving Loans).

[0001193125-17-337320:mdna:79]
The U.S. ABL consists of three tranches comprised of a revolving credit facility of up to $200.0 million, a letter
of credit facility of up to $50.0 million, and swingline loans of up to $30.0 million, provided that at no time may amounts outstanding under the tranches exceed in aggregate $200.0 million or the applicable borrowing base, which is a
percentage of the principal amount of Eligible Accounts, as defined in the U.S. ABL agreement. Borrowings under the U.S. ABL bear interest at either a floating rate of LIBOR plus a margin of 150 basis points or JP Morgan Chase Bank’s prime rate
plus a margin of 50 basis points, at our option. At October 2, 2017, the interest rate on the outstanding borrowings under the U.S. ABL was 2.73%. The applicable margin can vary based on the remaining availability of the facility, from 125 to
175 basis points for LIBOR-based loans and from 25 to 75 basis points for JP Morgan Chase Bank’s prime rate-based loans. Other than availability and an event of default, there are no other provisions for the interest margin to increase. The
U.S. ABL will mature on May 31, 2020. Loans made under the U.S. ABL are secured first by all of our domestic cash, receivables and inventories as well as by a second position against a significant amount of our assets and a pledge of 65% of
voting stock of our first tier foreign subsidiaries and are structurally senior to our Senior Notes and Convertible Senior Notes. See Senior Notes and Convertible Senior Notes above. As noted earlier, concurrent with the issuance of the Term Loan
Facility and Senior Notes, we paid down $63.0 million of the outstanding balance of our U.S. ABL. We and our domestic subsidiaries have fully and unconditionally guaranteed the full and timely payment of U.S. ABL related obligations. At
October 2, 2017, $17.0 million of the U.S. ABL was outstanding and classified as long-term debt, which is consistent with its maturity date.

[0001193125-17-337320:mdna:80]
The Asia ABL consists of two tranches comprised of a revolving credit facility of up to $150.0 million and a letter of credit facility of up to $100.0 million, provided that at no time may
amounts outstanding under both tranches exceed in aggregate $150.0 million or the applicable borrowing base, which is a percentage of the principal amount of Eligible Accounts, as defined in the Asia ABL agreement. Borrowings under the Asia ABL
bear interest at a floating rate of LIBOR plus 140 basis points. At October 2, 2017, the interest rate on the outstanding borrowings under the Asia ABL was 2.63%. There is no provision, other than an event of default, for the interest margin to
increase. The Asia ABL will mature on May 22, 2020. Loans made under the Asia ABL are secured by a portion of our Asia cash and receivables and are structurally senior to our domestic obligations, including the Senior Notes and Convertible
Senior Notes. See Senior Notes and Convertible Senior Notes above. Our Asian subsidiaries and certain of their subsidiaries have fully and unconditionally guaranteed the full and timely payment of all Asia ABL related obligations. At October 2,
2017, $30.0 million of the Asia ABL was outstanding and classified as long-term debt, which is consistent with its maturity date.

[0001193125-17-337320:mdna:81]
We have up to $50.0 million and $100.0 million Letters of Credit Facilities under the U.S. ABL and the Asia ABL, respectively. As of October 2, 2017 letters of credit in the amount of
$7.6 million were outstanding under the U.S. ABL and $45.0 million were outstanding under the Asia ABL with various expiration dates through March 2019. Available borrowing capacity under the U.S. ABL and the Asia ABL was
$175.4 million and $75.0 million, respectively, which considers letters of credit outstanding of $7.6 million and $45.0 million, respectively, at October 2, 2017.

[0001193125-17-337320:mdna:82]
We are required to pay a commitment fee of 0.25% to 0.375% per annum on any unused portion of the U.S ABL and the
Asia ABL. We incurred total commitment fees related to unused borrowing availability of $0.2 million for both of the quarters ended October 2, 2017 and September 26, 2016, and $0.5 million for both of the three quarters ended
October 2, 2017 and September 26, 2016.

[0001193125-17-337320:mdna:83]
Under the occurrence of certain events, the ABL Revolving Loans are
subject to various financial and operational covenants, including maintaining minimum fixed charge coverage ratios. At October 2, 2017, we were in compliance with the covenants under the ABL Revolving Loans.

[0001193125-17-337320:mdna:84]
Other Credit Facility

[0001193125-17-337320:mdna:85]
Additionally, we are party to a revolving loan credit facility (Chinese Revolver) with a lender in China. Under this arrangement, the lender has made available to us approximately $31.7 million in
unsecured borrowing with all terms of the borrowing to be negotiated at the time the Chinese Revolver is drawn upon. There are no commitment fees on the unused portion of the Chinese Revolver, and this arrangement expires in January 2018. As of
October 2, 2017, the Chinese Revolver had not been drawn upon.

[0001193125-17-337320:mdna:86]
The following table provides information
on our contractual obligations as of October 2, 2017:

[0001193125-17-337320:mdna:87]
|  |  | Total |  |  | Less Than1 Year |  |  | 1 - 3 Years |  |  | 4 - 5 Years |  |  | After5 Years |  |
| Contractual Obligations (1) |  | (In thousands) |  |
| Long-term debt obligations |  | $ | 773,884 |  |  | $ | 4,184 |  |  | $ | 53,899 |  |  | $ | 8,301 |  |  | $ | 707,500 |  |
| Convertible debt obligations |  |  | 249,985 |  |  |  | — |  |  |  | — |  |  |  | 249,985 |  |  |  | — |  |
| Interest on debt obligations |  |  | 277,664 |  |  |  | 40,478 |  |  |  | 68,544 |  |  |  | 80,591 |  |  |  | 88,051 |  |
| Equipment payables |  |  | 63,842 |  |  |  | 63,137 |  |  |  | 705 |  |  |  | — |  |  |  | — |  |
| Purchase obligations |  |  | 103,366 |  |  |  | 91,799 |  |  |  | 3,068 |  |  |  | 596 |  |  |  | 7,903 |  |
| Operating lease commitments |  |  | 27,990 |  |  |  | 7,963 |  |  |  | 9,304 |  |  |  | 4,428 |  |  |  | 6,295 |  |
| Total contractual obligations |  | $ | 1,496,731 |  |  | $ | 207,561 |  |  | $ | 135,520 |  |  | $ | 343,901 |  |  | $ | 809,749 |  |

[0001193125-17-337320:mdna:88]
| (1) | Unrecognized uncertain tax benefits of $41.1 million are not included in the table above as the settlement timing is uncertain. |

[0001193125-17-337320:mdna:89]
[same as prior period, unchanged from 0001193125-17-251481:mdna:93]

[0001193125-17-337320:mdna:90]
[same as prior period, unchanged from 0001193125-17-251481:mdna:94]

[0001193125-17-337320:mdna:91]
[same as prior period, unchanged from 0001193125-17-251481:mdna:95]

[0001193125-17-337320:mdna:92]
[same as prior period, unchanged from 0001193125-17-251481:mdna:96]
