# TTMI note change history — 0001193125-17-166200 → 0001193125-17-251481


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2017-08-08):
[0001193125-17-251481:note_history:1]
The Company is subject to various legal matters, which it
 considers normal for its business activities. While the Company
 currently believes that the amount of any reasonably possible loss
 for known matters would not be material to the Company’s
 financial condition, the outcome of these actions is inherently
 difficult to predict. In the event of an adverse outcome, the
 ultimate potential loss could have a material adverse effect on the
 Company’s financial condition or results of operations in a
 particular period. The Company has accrued amounts for its loss
 contingencies which are probable and estimable as of July 3,
 2017 and January 2, 2017. However, these amounts are not
 material to the consolidated condensed financial statements of the
 Company.
  (was, 2017-05-11, similarity 0.9753):
[0001193125-17-166200:note_history:1]
The
 Company is subject to various legal matters, which it considers
 normal for its business activities. While the Company currently
 believes that the amount of any reasonably possible loss for known
 matters would not be material to the Company’s financial
 condition, the outcome of these actions is inherently difficult to
 predict. In the event of an adverse outcome, the ultimate potential
 loss could have a material adverse effect on the Company’s
 financial condition or results of operations in a particular
 period. The Company has accrued amounts for its loss contingencies
 which are probable and estimable as of April 3, 2017 and
 January 2, 2017. However, these amounts are not material to
 the consolidated condensed financial statements of the
 Company.

- changed (2017-08-08):
[0001193125-17-251481:note_history:2]
The process to manufacture PCBs requires adherence to city,
 county, state, federal, and foreign environmental regulations
 regarding the storage, use, handling and disposal of chemicals,
 solid wastes and other hazardous materials, as well as compliance
 with air quality standards and chemical use reporting. The Company
 believes that its facilities in the United States and Canada comply
 in all material respects with applicable environmental laws and
 regulations. In China, governmental authorities have adopted new
 rules and regulations governing environmental issues. An update to
 the Chinese environmental waste water law was issued in late 2012,
 allowing for an interim period in which plants subject to such law
 may install equipment that meets the new regulatory regime. Some of
 the Company’s plants in China are not yet in full compliance
 with the updated environmental regulations. The Company believes it
 has developed plans acceptable to the Chinese government and is in
 the process of implementing these plans. The Company does not
 anticipate any immediate risk of government fines or temporary
 closure of its Chinese plants. The Company has established and
 enacted an investment plan related to the efforts to come into full
 compliance with the new regulations in a timely fashion. The 2017
 capital expenditure costs expected for these plans are included in
 the Company’s capital expenditure projections.
  (was, 2017-05-11, similarity 0.9822):
[0001193125-17-166200:note_history:2]
The
 process to manufacture PCBs requires adherence to city, county,
 state, federal, and foreign environmental regulations regarding the
 storage, use, handling and disposal of chemicals, solid wastes and
 other hazardous materials, as well as compliance with air quality
 standards and chemical use reporting. The Company believes that its
 facilities in the United States, Canada and Mexico comply in all
 material respects with applicable environmental laws and
 regulations. In China, governmental authorities have adopted new
 rules and regulations governing environmental issues. An update to
 the Chinese environmental waste water law was issued in late 2012,
 allowing for an interim period in which plants subject to such law
 may install equipment that meets the new regulatory regime. Some of
 the Company’s plants in China are not yet in full compliance
 with the updated environmental regulations. The Company believes it
 has developed plans acceptable to the Chinese government and is in
 the process of implementing these plans. The Company does not
 anticipate any immediate risk of government fines or temporary
 closure of its Chinese plants. The Company has established and
 enacted an investment plan related to the efforts to come into full
 compliance with the new regulations. The 2017 capital expenditure
 costs expected for these plans are included in the Company’s
 capital expenditure projections.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- added (2017-08-08):
[0001193125-17-251481:note_history:3]
In January 2017, the Financial Accounting Standards Board
 (FASB) issued Accounting Standards Update (ASU) 2017-04, Intangibles (Topic 350):
 Goodwill and other. This ASU simplifies the accounting for
 goodwill impairment and removes Step 2 of the goodwill impairment
 test. Goodwill impairment will now be the amount by which a
 reporting unit’s carrying value exceeds its fair value
 limited to the total amount of goodwill allocated to that reporting
 unit. Entities will continue to have the option to perform a
 qualitative assessment to determine if a quantitative impairment
 test is necessary. The Company elected to early adopt
 ASU 2017-04 on a prospective basis during
 the second quarter of 2017, and the adoption did not have a
 material impact on its consolidated condensed financial statements
 and related disclosures.

- changed (2017-08-08):
[0001193125-17-251481:note_history:4]
In October 2016, the FASB issued ASU 2016-16, Income Taxes (Topic 740):
 Intra-Entity Transfers of Assets Other Than Inventory. The objective of this
 update is to improve the accounting for the income tax consequences
 of intra-entity transfers of assets other than inventory by
 recognizing the income tax consequences when the transfer occurs.
 This ASU is effective for fiscal years beginning after
 December 15, 2017, including interim periods within those
 fiscal years. Early adoption is permitted. The Company is currently
 evaluating the new guidance to determine the impact it may have on
 its consolidated condensed financial statements.
  (was, 2017-05-11, similarity 0.9276):
[0001193125-17-166200:note_history:4]
In October 2016, the Financial Accounting Standards Board
 (FASB) issued Accounting Standards Update (ASU) 2016-16, Income Taxes (Topic 740):
 Intra-Entity Transfers of Assets Other Than Inventory. The
 objective of this update is to improve the accounting for the
 income tax consequences of intra-entity transfers of assets other
 than inventory by recognizing the income tax consequences when the
 transfer occurs. This ASU is effective for fiscal years beginning
 after December 15, 2017, including interim periods within
 those fiscal years. Early adoption is permitted. The Company is
 currently evaluating the new guidance to determine the impact it
 may have on its consolidated condensed financial
 statements.

- changed (2017-08-08):
[0001193125-17-251481:note_history:5]
In March 2016, the FASB issued ASU 2016-09, Stock Compensation (Topic
 718): Improvements to Employee Share-Based Payment Accounting.
 The objective of this update is to simplify several aspects of the
 accounting for employee share-based payment transactions, including
 the income tax consequences, classification of awards as either
 equity or liabilities, and classification on the statement of cash
 flows. This ASU is effective for fiscal years beginning after
 December 15, 2016, including interim periods within those
 fiscal years. The Company adopted ASU 2016-09 on January 3, 2017. The
 adoption did not have a material impact on the consolidated
 condensed financial statements and related disclosures.
  (was, 2017-05-11, similarity 0.9898):
[0001193125-17-166200:note_history:5]
In March 2016, the FASB issued ASU 2016-09, Stock Compensation (Topic
 718): Improvements to Employee Share-Based Payment Accounting.
 The objective of this update is to simplify several aspects of the
 accounting for employee share-based payment transactions, including
 the income tax consequences, classification of awards as either
 equity or liabilities, and classification on the statement of cash
 flows. This ASU is effective for fiscal years beginning after
 December 15, 2016, including interim periods within those
 fiscal years. The Company adopted ASU 2016-09 on January 3, 2017. The
 impact of the adoption did not have a material impact on the
 consolidated condensed financial statements and related
 disclosures.

- changed (2017-08-08):
[0001193125-17-251481:note_history:6]
In May 2014, the FASB issued ASU 2014-09, Revenue from Contracts with
 Customers, as amended, which requires an entity to recognize
 the amount of revenue to which it expects to be entitled for the
 transfer of promised goods or services to customers. The ASU will
 replace most existing revenue recognition guidance in U.S. GAAP
 when it becomes effective. The new standard is effective for the
 Company at the beginning of fiscal year 2018. The standard permits
 the use of either the retrospective or cumulative effect transition
 method. The Company has assessed that the impact of the new
 guidance will result in a change to the timing of revenue
 recognition for the Company’s revenue stream from
 “point in time” upon physical delivery to an
 “over time” model and believes this transition could
 have a material impact on the Company’s consolidated
 financial statements upon adoption. As of July 3, 2017,
 management intends to apply the cumulative effect transition
 method. The Company has identified and is in the process of
 implementing changes to its systems, processes and internal
 controls to meet the standard update’s reporting and
 disclosure requirements.
  (was, 2017-05-11, similarity 0.7432):
[0001193125-17-166200:note_history:6]
In May 2014, the FASB issued ASU 2014-09, Revenue from Contracts
 with Customers, as amended, which requires an entity to
 recognize the amount of revenue to which it expects to be entitled
 for the transfer of promised goods or services to customers. The
 ASU will replace most existing revenue recognition guidance in U.S.
 GAAP when it becomes effective. The new standard is effective for
 the Company at the beginning of fiscal year 2018, however
 application of the standard is allowed as early as the beginning of
 fiscal 2017. The standard permits the use of either the
 retrospective or cumulative effect transition method. The Company
 has assessed that the impact of the new guidance will result in a
 change to the timing of revenue recognition for the Company’s
 revenue stream from “point in time” upon physical
 delivery to an “over time” model and believes this
 transition could have a material impact on the Company’s
 consolidated financial statements upon adoption. As of
 April 3, 2017, management intends to apply the cumulative
 effect transition method. The Company has identified and is in the
 process of implementing changes to its systems, processes and
 internal controls to meet the standard update’s reporting and
 disclosure requirements.


## ttmi:ScheduleOfComponentsOfInterestExpenseFromConvertibleNotesTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2017-08-08):
[0001193125-17-251481:note_history:7]
The components of interest expense resulting from the
 convertible senior notes for the quarters and two quarters ended
 July 3, 2017 and June 27, 2016 are as follows:
  (was, 2017-05-11, similarity 0.8889):
[0001193125-17-166200:note_history:7]
The components of interest expense resulting from the
 convertible senior notes for the quarters ended April 3, 2017
 and March 28, 2016 are as follows:

- added (2017-08-08):
[0001193125-17-251481:note_history:8]
|  |  | For the Quarter Ended |  |  | For the Two Quarters Ended |  |
|  |  | July 3, 2017 |  |  | June 27, 2016 |  |  | July 3, 2017 |  |  | June 27, 2016 |  |
|  |  | (In thousands) |  |
| Contractual coupon interest |  | $ | 1,093 |  |  | $ | 1,093 |  |  | $ | 2,187 |  |  | $ | 2,187 |  |
| Amortization of debt discount |  | $ | 2,125 |  |  | $ | 1,992 |  |  | $ | 4,216 |  |  | $ | 3,952 |  |
| Amortization of debt issuance costs |  | $ | 214 |  |  | $ | 200 |  |  | $ | 423 |  |  | $ | 396 |  |

- removed (2017-08-08):
[0001193125-17-166200:note_history:9]
|  |  | For the Quarter Ended |  |
|  |  | April 3, 2017 |  |  | March 28, 2016 |  |
|  |  | (In thousands) |  |
| Contractual coupon interest |  | $ | 1,094 |  |  | $ | 1,094 |  |
| Amortization of debt discount |  | $ | 2,091 |  |  | $ | 1,960 |  |
| Amortization of debt issuance costs |  | $ | 209 |  |  | $ | 196 |  |


## us-gaap:ConvertibleDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2017-08-08):
[0001193125-17-251481:note_history:10]
As of July 3, 2017 and January 2, 2017, the following
 summarizes the equity components of the convertible senior notes
 included in additional paid-in capital:
  (was, 2017-05-11, similarity 0.9766):
[0001193125-17-166200:note_history:10]
As of April 3, 2017 and January 2, 2017, the
 following summarizes the equity components of the convertible
 senior notes included in additional paid-in capital:

- changed (2017-08-08):
[0001193125-17-251481:note_history:11]
|  |  | As of July 3, 2017 |  |  | As of January 2, 2017 |  |
|  |  | Embedded conversion option — Convertible Senior Notes |  |  | Embedded conversion option — Convertible Senior Notes Issuance Costs |  |  | Total |  |  | Embedded conversion option — Convertible Senior Notes |  |  | Embedded conversion option — Convertible Senior Notes Issuance Costs |  |  | Total |  |
|  |  | (in thousands) |  |
| Convertible senior notes due 2020 |  | $ | 60,216 |  |  | $ | (1,916 | ) |  | $ | 58,300 |  |  | $ | 60,227 |  |  | $ | (1,916 | ) |  | $ | 58,311 |  |
  (was, 2017-05-11, similarity 0.7019):
[0001193125-17-166200:note_history:11]
|  |  | As of April 3, 2017 and January 2, 2017 |  |
|  |  | Embedded conversion option — Convertible Senior Notes |  |  | Embedded conversion option — Convertible Senior Notes Issuance Costs |  |  | Total |  |
|  |  | (in thousands) |  |
| Convertible senior notes due 2020 |  | $ | 60,227 |  |  | $ | (1,916 | ) |  | $ | 58,311 |  |


## us-gaap:LongTermDebtTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2017-08-08):
[0001193125-17-251481:note_history:12]
The following table summarizes the long-term debt of the
 Company as of July 3, 2017 and January 2,
 2017:
  (was, 2017-05-11, similarity 0.9637):
[0001193125-17-166200:note_history:12]
The following table summarizes the long-term debt of the
 Company as of April 3, 2017 and January 2,
 2017:

- changed (2017-08-08):
[0001193125-17-251481:note_history:13]
|  |  | Average Effective Interest Rate as of July 3, 2017 |  |  | July 3, 2017 |  |  | Average Effective Interest Rate as of January 2, 2017 |  |  | January 2, 2017 |  |
|  |  | (In thousands) |  |
| Term loan due May 2021 |  |  | 5.48% |  |  | $ | 650,000 |  |  |  | 5.25% |  |  | $ | 700,000 |  |
| U.S. ABL revolving loan due May 2020 |  |  | 2.73% |  |  |  | 80,000 |  |  |  | 2.27% |  |  |  | 80,000 |  |
| Asia ABL revolving loan due May 2020 |  |  | 2.63% |  |  |  | 30,000 |  |  |  | 2.17% |  |  |  | 30,000 |  |
| Convertible Senior Notes due December 2020 |  |  | 1.75% |  |  |  | 249,985 |  |  |  | 1.75% |  |  |  | 250,000 |  |
| Capital lease |  |  | 6.43% |  |  |  | 1,844 |  |  |  | 6.43% |  |  |  | 1,798 |  |
|  |  |  |  |  |  |  | 1,011,829 |  |  |  |  |  |  |  | 1,061,798 |  |
| Less: Long-term debt unamortized discount |  |  |  |  |  |  | (33,174 | ) |  |  |  |  |  |  | (37,392 | ) |
| Long-term debt unamortized debt issuance costs |  |  |  |  |  |  | (4,139 | ) |  |  |  |  |  |  | (4,724 | ) |
|  |  |  |  |  |  |  | 974,516 |  |  |  |  |  |  |  | 1,019,682 |  |
| Less: current maturities |  |  |  |  |  |  | (110,669 | ) |  |  |  |  |  |  | (110,652 | ) |
| Long-term debt, less current maturities |  |  |  |  |  | $ | 863,847 |  |  |  |  |  |  | $ | 909,030 |  |
  (was, 2017-05-11, similarity 0.9792):
[0001193125-17-166200:note_history:13]
|  |  | Average Effective Interest Rate as of April 3, 2017 |  |  | April 3, 2017 |  |  | Average Effective Interest Rate as of January 2, 2017 |  |  | January 2, 2017 |  |
|  |  | (In thousands) |  |
| Term loan due May 2021 |  |  | 5.25% |  |  | $ | 700,000 |  |  |  | 5.25% |  |  | $ | 700,000 |  |
| U.S. ABL revolving loan due May 2020 |  |  | 2.48% |  |  |  | 80,000 |  |  |  | 2.27% |  |  |  | 80,000 |  |
| Asia ABL revolving loan due May 2020 |  |  | 2.38% |  |  |  | 30,000 |  |  |  | 2.17% |  |  |  | 30,000 |  |
| Convertible Senior Notes due December 2020 |  |  | 1.75% |  |  |  | 250,000 |  |  |  | 1.75% |  |  |  | 250,000 |  |
| Capital lease |  |  | 6.43% |  |  |  | 1,815 |  |  |  | 6.43% |  |  |  | 1,798 |  |
|  |  |  |  |  |  |  | 1,061,815 |  |  |  |  |  |  |  | 1,061,798 |  |
| Less: Long-term debt unamortized discount |  |  |  |  |  |  | (35,301 | ) |  |  |  |  |  |  | (37,392 | ) |
| Long-term debt unamortized debt issuance costs |  |  |  |  |  |  | (4,465 | ) |  |  |  |  |  |  | (4,724 | ) |
|  |  |  |  |  |  |  | 1,022,049 |  |  |  |  |  |  |  | 1,019,682 |  |
| Less: current maturities |  |  |  |  |  |  | (160,658 | ) |  |  |  |  |  |  | (110,652 | ) |
| Long-term debt, less current maturities |  |  |  |  |  | $ | 861,391 |  |  |  |  |  |  | $ | 909,030 |  |

- changed (2017-08-08):
[0001193125-17-251481:note_history:14]
The Term Loan bears interest at a floating rate of LIBOR, with
 a 1.0% LIBOR floor, plus an applicable interest margin of 4.25%, or
 JP Morgan Chase Bank’s prime rate, with a 2% floor, plus a
 margin of 3.25%, at the Company’s option. At July 3,
 2017 the weighted average interest rate on the outstanding
 borrowings under the Term Loan was 5.48%. There is no provision,
 other than an event of default, for the interest margin to
 increase. The Term Loan will mature on May 31, 2021. The Term
 Loan is secured by a significant amount of the assets of the
 Company and a pledge of 65% of voting stock of the Company’s
 first tier foreign subsidiaries and is structurally senior to the
 Company’s convertible senior notes. See Convertible Senior
 Notes below.
  (was, 2017-05-11, similarity 0.9938):
[0001193125-17-166200:note_history:14]
The Term Loan bears interest at a floating rate of LIBOR, with
 a 1.0% LIBOR floor, plus an applicable interest margin of 4.25%, or
 JP Morgan Chase Bank’s prime rate, with a 2% floor, plus a
 margin of 3.25%, at the Company’s option. At April 3,
 2017 the weighted average interest rate on the outstanding
 borrowings under the Term Loan was 5.25%. There is no provision,
 other than an event of default, for the interest margin to
 increase. The Term Loan will mature on May 31, 2021. The Term
 Loan is secured by a significant amount of the assets of the
 Company and a pledge of 65% of voting stock of the Company’s
 first tier foreign subsidiaries and is structurally senior to the
 Company’s convertible senior notes. See Convertible Senior
 Notes below.

- changed (2017-08-08):
[0001193125-17-251481:note_history:15]
The U.S. ABL consists of three tranches comprised of a
 revolving credit facility of up to $200,000, a letter of credit
 facility of up to $50,000, and swingline loans of up to $30,000,
 provided that at no time may amounts outstanding under the tranches
 exceed in aggregate $200,000 or the applicable borrowing base,
 which is a percentage of the principal amount of Eligible Accounts,
 as defined in the U.S. ABL agreement. Borrowings under the U.S. ABL
 bear interest at either a floating rate of LIBOR plus a margin of
 150 basis points or JP Morgan Chase Bank’s prime rate plus a
 margin of 50 basis points, at the Company’s option. At
 July 3, 2017, the weighted average interest rate on the
 outstanding borrowings under the U.S. ABL was 2.73%. The applicable
 margin can vary based on the remaining availability of the
 facility, from 125 to 175 basis points for LIBOR-based loans and
 from 25 to 75 basis points for JP Morgan Chase Bank’s prime
 rate-based loans. Other than availability and an event of default,
 there are no other provisions for the interest margin to increase.
 The U.S. ABL will mature on May 31, 2020. Loans made under the
 U.S. ABL are secured first by all of the Company’s domestic
 cash, receivables and inventories as well as by a second position
 against a significant amount of the assets of the Company and a
 pledge of 65% of voting stock of the Company’s first tier
 foreign subsidiaries and are structurally senior to the
 Company’s convertible senior notes. See Convertible Senior
 Notes below. At July 3, 2017, $80,000 of the U.S. ABL was
 outstanding and classified as short-term debt. The Company and its
 domestic subsidiaries have fully and unconditionally guaranteed the
 full and timely payment of all Term Loan and U.S. ABL related
 obligations.
  (was, 2017-05-11, similarity 0.9947):
[0001193125-17-166200:note_history:15]
The U.S. ABL consists of three tranches comprised of a
 revolving credit facility of up to $200,000, a letter of credit
 facility of up to $50,000, and swingline loans of up to $30,000,
 provided that at no time may amounts outstanding under the tranches
 exceed in aggregate $200,000 or the applicable borrowing base,
 which is a percentage of the principal amount of Eligible Accounts,
 as defined in the U.S. ABL agreement. Borrowings under the U.S. ABL
 bear interest at either a floating rate of LIBOR plus a margin of
 150 basis points or JP Morgan Chase Bank’s prime rate plus a
 margin of 50 basis points, at the Company’s option. At
 April 3, 2017, the weighted average interest rate on the
 outstanding borrowings under the U.S. ABL was 2.48%. The applicable
 margin can vary based on the remaining availability of the
 facility, from 125 to 175 basis points for LIBOR-based loans and
 from 25 to 75 basis points for JP Morgan Chase Bank’s prime
 rate-based loans. Other than availability and an event of default,
 there are no other provisions for the interest margin to increase.
 The U.S. ABL will mature on May 31, 2020. Loans made under the
 U.S. ABL are secured first by all of the Company’s domestic
 cash, receivables and inventories as well as by a second position
 against a significant amount of the assets of the Company and a
 pledge of 65% of voting stock of the Company’s first tier
 foreign subsidiaries and are structurally senior to the
 Company’s convertible senior notes. See Convertible Senior
 Notes below. At April 3, 2017, $80,000 of the U.S. ABL was
 outstanding and classified as short-term debt. The Company and its
 domestic subsidiaries have fully and unconditionally guaranteed the
 full and timely payment of all Term Loan and U.S. ABL related
 obligations.

- changed (2017-08-08):
[0001193125-17-251481:note_history:16]
The Asia ABL consists of two tranches comprised of a revolving
 credit facility of up to $150,000 and a letter of credit facility
 of up to $100,000, provided that at no time may amounts outstanding
 under both tranches exceed in aggregate $150,000 or the applicable
 borrowing base, which is a percentage of the principal amount of
 Eligible Accounts, as defined in the Asia ABL agreement. Borrowings
 under the Asia ABL bear interest at a floating rate of LIBOR plus
 140 basis points. At July 3, 2017, the weighted average
 interest rate on the outstanding borrowings under the Asia ABL was
 2.63%. There is no provision, other than an event of default, for
 the interest margin to increase. The Asia ABL will mature on
 May 22, 2020. Loans made under the Asia ABL are secured by a
 portion of the Company’s Asia Pacific cash and receivables
 and are structurally senior to the Company’s domestic
 obligations, including the convertible senior notes. See
 Convertible Senior Notes below. The Company’s Asia Pacific
 subsidiary and certain of its subsidiaries have fully and
 unconditionally guaranteed the full and timely payment of all Asia
 ABL related obligations. At July 3, 2017, $30,000 of the Asia
 ABL was outstanding.
  (was, 2017-05-11, similarity 0.9923):
[0001193125-17-166200:note_history:16]
The Asia ABL consists of two tranches comprised of a revolving
 credit facility of up to $150,000 and a letter of credit facility
 of up to $100,000, provided that at no time may amounts outstanding
 under both tranches exceed in aggregate $150,000 or the applicable
 borrowing base, which is a percentage of the principal amount of
 Eligible Accounts, as defined in the Asia ABL agreement. Borrowings
 under the Asia ABL bear interest at a floating rate of LIBOR plus
 140 basis points. At April 3, 2017, the weighted average
 interest rate on the outstanding borrowings under the Asia ABL was
 2.38%. There is no provision, other than an event of default, for
 the interest margin to increase. The Asia ABL will mature on
 May 22, 2020. Loans made under the Asia ABL are secured by a
 portion of the Company’s Asia Pacific cash and receivables
 and are structurally senior to the Company’s domestic
 obligations, including the convertible senior notes. See
 Convertible Senior Notes below. The Company’s Asia Pacific
 subsidiary and certain of its subsidiaries have fully and
 unconditionally guaranteed the full and timely payment of all Asia
 ABL related obligations. At April 3, 2017, $30,000 of the Asia
 ABL was outstanding.

- changed (2017-08-08):
[0001193125-17-251481:note_history:17]
The Company is no longer required to make any quarterly
 scheduled payments for the remaining term of the outstanding Term
 Loan balance due to mandatory payments and optional loan
 prepayments applied to date. Additionally, based on certain
 parameters defined in the Term Loan agreement, including a secured
 leverage ratio, the Company is also not required to make any
 additional principal payments for fiscal year 2017 as our secured
 leverage ratio is less than or equal to 1.5. The Company may be
 required to make additional principal payments in future years, if
 the Company’s secured leverage ratio is greater than 1.5. Any
 remaining outstanding balances under the Term Loan are due at the
 maturity date of May 31, 2021. During the quarter ended
 July 3, 2017, the Company made an optional debt principal
 prepayment totaling $50,000. Borrowings under the Term Loan are
 subject to financial and operating covenants including maintaining
 a maximum total leverage ratio. Under the occurrence of certain
 events, the U.S. ABL and the Asia ABL are subject to financial and
 operational covenants, including maintaining minimum fixed charge
 coverage ratios. At July 3, 2017, the Company was in
 compliance with the covenants under the Term Loan, the U.S. ABL and
 the Asia ABL.
  (was, 2017-05-11, similarity 0.9714):
[0001193125-17-166200:note_history:17]
The Company is no longer required to make any quarterly
 scheduled payments for the remaining term of the outstanding Term
 Loan balance due to mandatory payments and optional loan
 prepayments applied to date. Additionally, based on certain
 parameters defined in the Term Loan agreement, including a secured
 leverage ratio, the Company is also not required to make any
 additional principal payments for fiscal year 2017 as our secured
 leverage ratio is less than or equal to 1.5. The Company may be
 required to make additional principal payments in future years, if
 the Company’s secured leverage ratio is greater than 1.5. Any
 remaining outstanding balances under the Term Loan are due at the
 maturity date of May 31, 2021. Subsequent to the quarter ended
 April 3, 2017, the Company made an optional debt principal
 prepayment totaling $50,000. Borrowings under the Term Loan are
 subject to financial and operating covenants including maintaining
 a maximum total leverage ratio. Under the occurrence of certain
 events, the U.S. ABL and the Asia ABL are subject to financial and
 operational covenants, including maintaining minimum fixed charge
 coverage ratios. At April 3, 2017, the Company was in
 compliance with the covenants under the Term Loan, the U.S. ABL and
 the Asia ABL.

- changed (2017-08-08):
[0001193125-17-251481:note_history:18]
As of July 3, 2017 and January 2, 2017, remaining
 unamortized debt issuance costs of $815 and $977, respectively,
 related to the Term Loan. These debt issuance costs are recorded as
 a reduction of the Term Loan at July 3, 2017 and
 January 2, 2017, respectively, and are amortized over the
 duration of the Term Loan into interest expense using an effective
 interest rate of 5.48%.
  (was, 2017-05-11, similarity 0.9746):
[0001193125-17-166200:note_history:18]
As of April 3, 2017 and January 2, 2017, remaining
 unamortized debt issuance costs of $927 and $977, respectively,
 related to the Term Loan. These debt issuance costs are recorded as
 a reduction of the Term Loan at April 3, 2017 and
 January 2, 2017, respectively, and are amortized over the
 duration of the Term Loan into interest expense using an effective
 interest rate of 5.29%.

- changed (2017-08-08):
[0001193125-17-251481:note_history:19]
Additionally, remaining unamortized debt issuance costs related
 to the ABL Revolving Loans were $2,922 and $3,423 as of
 July 3, 2017 and January 2, 2017, respectively. These
 debt issuance costs are included in
 other non-current assets
 and are amortized to interest expense over the duration of the ABL
 Revolving Loans using the straight line method of amortization. At
 July 3, 2017, the remaining weighted average amortization
 period for the unamortized debt issuance costs for both the Term
 Loan and the ABL Revolving Loans was 3.1 years.
  (was, 2017-05-11, similarity 0.7963):
[0001193125-17-166200:note_history:19]
Additionally, remaining unamortized debt issuance costs related
 to the ABL Revolving Loans were $3,173 and $3,423 as of
 April 3, 2017 and January 2, 2017, respectively. These
 debt issuance costs are included in other non-current assets and are amortized to
 interest expense over the duration of the ABL Revolving Loans using
 the straight line method of amortization.

- changed (2017-08-08):
[0001193125-17-251481:note_history:20]
The Company is required to pay a commitment fee of 0.25% to
 0.375% per annum on any unused portion of the U.S. ABL or Asia
 ABL. The Company incurred total commitment fees related to unused
 borrowing availability of $180 and $150 for the quarters ended
 July 3, 2017 and June 27, 2016, respectively, and $367
 and $344 for the two quarters ended July 3, 2017 and
 June 27, 2016, respectively. As of July 3, 2017, the
 outstanding amount of the Term Loan was $650,000 which is included
 as long-term debt. Additionally, $80,000 of the U.S. ABL and
 $30,000 of the Asia ABL was outstanding as of July 3, 2017.
 Available borrowing capacity under the U.S. ABL and Asia ABL was
 $112,388 and $78,310, which considers letters of credit outstanding
 of $7,612 and $41,690 mentioned below, respectively, at
 July 3, 2017.
  (was, 2017-05-11, similarity 0.7701):
[0001193125-17-166200:note_history:20]
The Company is required to pay a commitment fee of 0.25% to
 0.375% per annum on any unused portion of the U.S. ABL or Asia
 ABL. The Company incurred total commitment fees related to unused
 borrowing availability of $187 and $194 for the quarters ended
 April 3, 2017 and March 28, 2016, respectively. As of
 April 3, 2017, the outstanding amount of the Term Loan was
 $700,000, of which $50,000 is included in short-term debt and the
 remaining $650,000 is included as long-term debt. Additionally,
 $80,000 of the U.S. ABL and $30,000 of the Asia ABL was outstanding
 as of April 3, 2017. Available borrowing capacity under the
 U.S. ABL and Asia ABL was $113,503 and $99,628, which considers
 letters of credit outstanding of $6,497 and $20,372 mentioned
 below, respectively, at April 3, 2017.

- changed (2017-08-08):
[0001193125-17-251481:note_history:21]
The Company has up to $50,000 and $100,000 Letters of Credit
 Facilities under the U.S. ABL and the Asia ABL, respectively, as
 mentioned above. As of July 3, 2017, letters of credit in the
 amount of $7,612 were outstanding under the U.S. ABL and $41,690
 were outstanding under the Asia ABL with various expiration dates
 through September 2018.
  (was, 2017-05-11, similarity 0.9599):
[0001193125-17-166200:note_history:21]
The Company has up to $50,000 and $100,000 Letters of Credit
 Facilities under the U.S. ABL and the Asia ABL, respectively, as
 mentioned above. As of April 3, 2017, letters of credit in the
 amount of $6,497 were outstanding under the U.S. ABL and $20,372
 were outstanding under the Asia ABL with various expiration dates
 through March 2018.

- changed (2017-08-08):
[0001193125-17-251481:note_history:22]
The Company maintains 1.75% convertible senior notes in the
 amount of $249,985 due December 15, 2020. The convertible
 senior notes bear interest at a rate of 1.75% per annum.
 Interest is payable semiannually in arrears on June 15 and
 December 15 of each year. The convertible senior notes are
 senior unsecured obligations and rank equally to the
 Company’s future unsecured senior indebtedness and are senior
 in right of payment to any of the Company’s future
 subordinated indebtedness.
  (was, 2017-05-11, similarity 0.8962):
[0001193125-17-166200:note_history:22]
The Company issued 1.75% convertible senior notes due
 December 15, 2020, in a public offering for an aggregate
 principal amount of $250,000 in 2013. The convertible senior notes
 bear interest at a rate of 1.75% per annum. Interest is
 payable semiannually in arrears on June 15 and
 December 15 of each year. The convertible senior notes are
 senior unsecured obligations and rank equally to the
 Company’s future unsecured senior indebtedness and are senior
 in right of payment to any of the Company’s future
 subordinated indebtedness.

- changed (2017-08-08):
[0001193125-17-251481:note_history:23]
Conversion: At any time prior
 to March 15, 2020, holders may convert their convertible
 senior notes into cash and, if applicable, into shares of the
 Company’s common stock based on a conversion rate of 103.7613
 shares of the Company’s common stock per $1 principal amount
 of convertible senior notes, subject to adjustment, under the
 following circumstances: (1) during any calendar quarter
 beginning after March 31, 2015 (and only during such calendar
 quarter), if the last reported sale price of our common stock for
 at least 20 trading days during the 30 consecutive trading days
 ending on the last trading day of the immediately preceding
 calendar quarter is greater than or equal to 130% of the applicable
 conversion price on each applicable trading day of such preceding
 calendar quarter; (2) during the five business day period
 after any 10 consecutive trading day period in which the trading
 price per note for each day of that 10 consecutive trading day
 period was less than 98% of the product of the last reported sale
 price of the Company’s common stock and the conversion rate
 on such day; or (3) upon the occurrence of specified corporate
 transactions described in the indenture governing the notes. As of
 July 3, 2017, the conversion criteria had been met under
 condition (1) as described above, allowing holders to give
 notice of conversion in both the second and third quarter of
 2017.
  (was, 2017-05-11, similarity 0.9857):
[0001193125-17-166200:note_history:23]
Conversion: At any time prior to
 March 15, 2020, holders may convert their convertible senior
 notes into cash and, if applicable, into shares of the
 Company’s common stock based on a conversion rate of 103.7613
 shares of the Company’s common stock per $1 principal amount
 of convertible senior notes, subject to adjustment, under the
 following circumstances: (1) during any calendar quarter
 beginning after March 31, 2015 (and only during such calendar
 quarter), if the last reported sale price of our common stock for
 at least 20 trading days during the 30 consecutive trading days
 ending on the last trading day of the immediately preceding
 calendar quarter is greater than or equal to 130% of the applicable
 conversion price on each applicable trading day of such preceding
 calendar quarter; (2) during the five business day period
 after any 10 consecutive trading day period in which the trading
 price per note for each day of that 10 consecutive trading day
 period was less than 98% of the product of the last reported sale
 price of the Company’s common stock and the conversion rate
 on such day; or (3) upon the occurrence of specified corporate
 transactions described in the indenture governing the notes. As of
 April 3, 2017, the conversion criteria had been met under
 condition (1) as described above, allowing holders to give
 notice of conversion in both the first and second quarter of
 2017.

- changed (2017-08-08):
[0001193125-17-251481:note_history:24]
On or after March 15, 2020 until the close of business on
 the third scheduled trading day preceding the maturity date,
 holders may convert their notes at any time, regardless of the
 foregoing circumstances. Upon conversion, for each $1 principal
 amount of notes, the Company will pay shares of our common stock,
 cash or a combination of cash and shares of our common stock at its
 election, if applicable, based on a daily conversion value
 calculated on a proportionate basis for each day of the 80 trading
 day observation period. All conversions occurring on the same date
 or on or after March 15, 2020 shall be settled using the same
 settlement method. Additionally, in the event of a fundamental
 change as defined in the indenture governing the notes, or other
 conversion rate adjustments such as share splits or combinations,
 other distributions of shares, cash or other assets to
 stockholders, including self-tender transactions (Other Conversion
 Rate Adjustments), the conversion rate may be modified to adjust
 the number of shares per $1 principal amount of the notes. As of
 July 3, 2017, none of the criteria for a fundamental change or
 a conversion rate adjustment had been met.
  (was, 2017-05-11, similarity 0.9329):
[0001193125-17-166200:note_history:24]
On or after March 15, 2020 until the close of business on
 the third scheduled trading day preceding the maturity date,
 holders may convert their notes at any time, regardless of the
 foregoing circumstances. Upon conversion, for each $1 principal
 amount of notes, the Company will pay shares of our common stock,
 cash or a combination of cash and shares of our common stock at its
 election, if applicable, based on a daily conversion value
 calculated on a proportionate basis for each day of the 80 trading
 day observation period. All conversions occurring on the same date
 or on or after March 15, 2020 shall be settled using the same
 settlement method. Additionally, in the event of a fundamental
 change as defined in the indenture governing the notes, or other
 conversion rate adjustments such as share splits or combinations,
 other distributions of shares, cash or other assets to
 stockholders, including self-tender transactions (Other Conversion
 Rate Adjustments), the conversion rate may be modified to adjust
 the number of shares per $1 principal amount of the notes. As of
 April 3, 2017, none of the criteria for a fundamental change
 or a conversion rate adjustment had been met.

- changed (2017-08-08):
[0001193125-17-251481:note_history:25]
As of July 3, 2017 and January 2, 2017, the following
 summarizes the equity components of the convertible senior notes
 included in additional paid-in capital:
  (was, 2017-05-11, similarity 0.9766):
[0001193125-17-166200:note_history:25]
As of April 3, 2017 and January 2, 2017, the
 following summarizes the equity components of the convertible
 senior notes included in additional paid-in capital:

- changed (2017-08-08):
[0001193125-17-251481:note_history:26]
|  |  | As of July 3, 2017 |  |  | As of January 2, 2017 |  |
|  |  | Embedded conversion option — Convertible Senior Notes |  |  | Embedded conversion option — Convertible Senior Notes Issuance Costs |  |  | Total |  |  | Embedded conversion option — Convertible Senior Notes |  |  | Embedded conversion option — Convertible Senior Notes Issuance Costs |  |  | Total |  |
|  |  | (in thousands) |  |
| Convertible senior notes due 2020 |  | $ | 60,216 |  |  | $ | (1,916 | ) |  | $ | 58,300 |  |  | $ | 60,227 |  |  | $ | (1,916 | ) |  | $ | 58,311 |  |
  (was, 2017-05-11, similarity 0.7019):
[0001193125-17-166200:note_history:26]
|  |  | As of April 3, 2017 and January 2, 2017 |  |
|  |  | Embedded conversion option — Convertible Senior Notes |  |  | Embedded conversion option — Convertible Senior Notes Issuance Costs |  |  | Total |  |
|  |  | (in thousands) |  |
| Convertible senior notes due 2020 |  | $ | 60,227 |  |  | $ | (1,916 | ) |  | $ | 58,311 |  |

- changed (2017-08-08):
[0001193125-17-251481:note_history:27]
The components of interest expense resulting from the
 convertible senior notes for the quarters and two quarters ended
 July 3, 2017 and June 27, 2016 are as follows:
  (was, 2017-05-11, similarity 0.8889):
[0001193125-17-166200:note_history:27]
The components of interest expense resulting from the
 convertible senior notes for the quarters ended April 3, 2017
 and March 28, 2016 are as follows:

- added (2017-08-08):
[0001193125-17-251481:note_history:28]
|  |  | For the Quarter Ended |  |  | For the Two Quarters Ended |  |
|  |  | July 3, 2017 |  |  | June 27, 2016 |  |  | July 3, 2017 |  |  | June 27, 2016 |  |
|  |  | (In thousands) |  |
| Contractual coupon interest |  | $ | 1,093 |  |  | $ | 1,093 |  |  | $ | 2,187 |  |  | $ | 2,187 |  |
| Amortization of debt discount |  | $ | 2,125 |  |  | $ | 1,992 |  |  | $ | 4,216 |  |  | $ | 3,952 |  |
| Amortization of debt issuance costs |  | $ | 214 |  |  | $ | 200 |  |  | $ | 423 |  |  | $ | 396 |  |

- changed (2017-08-08):
[0001193125-17-251481:note_history:29]
As of July 3, 2017 and January 2, 2017, there remains
 unamortized debt discount of $33,174 and $37,392, respectively, and
 debt issuance costs of $3,324 and $3,747, respectively, related to
 the convertible senior notes. These debt discount and debt discount
 issuance costs are recorded as a reduction of the convertible
 senior notes and are being amortized to interest expense over the
 term of the convertible senior notes using the effective interest
 rate method. At July 3, 2017, the remaining weighted average
 amortization period for the unamortized senior convertible note
 discount and debt issuance costs was 3.5 years.
  (was, 2017-05-11, similarity 0.7483):
[0001193125-17-166200:note_history:29]
As of April 3, 2017 and January 2, 2017, there
 remains unamortized debt discount of $35,301 and $37,392,
 respectively, and debt issuance costs of $3,538 and $3,747,
 respectively, related to the convertible senior notes. These debt
 discount and debt discount issuance costs are recorded as a
 reduction of the convertible senior notes and are being amortized
 to interest expense over the term of the convertible senior notes
 using the effective interest rate method. At April 3, 2017,
 the remaining weighted average amortization period for the
 unamortized senior convertible note discount and debt issuance
 costs was 3.7 years.

- changed (2017-08-08):
[0001193125-17-251481:note_history:30]
For the quarters and two quarters ended July 3, 2017 and
 June 27, 2016, the amortization of the convertible senior
 notes due 2020 debt discount and debt issuance costs is based on an
 effective interest rate of 6.48%.
  (was, 2017-05-11, similarity 0.9143):
[0001193125-17-166200:note_history:30]
For the quarters ended April 3, 2017 and March 28,
 2016, the amortization of the convertible senior notes due 2020
 debt discount and debt issuance costs is based on an effective
 interest rate of 6.48%.

- changed (2017-08-08):
[0001193125-17-251481:note_history:31]
Additionally, the Company is party to a revolving loan credit
 facility (Chinese Revolver) with a lender in China. Under this
 arrangement, the lender has made available to the Company
 approximately $31,000 in unsecured borrowing with all terms of the
 borrowing to be negotiated at the time the Chinese Revolver is
 drawn upon. There are no commitment fees on the unused portion of
 the Chinese Revolver, and this arrangement expires in January 2018.
 As of July 3, 2017, the Chinese Revolver had not been drawn
 upon.
  (was, 2017-05-11, similarity 0.991):
[0001193125-17-166200:note_history:31]
Additionally, the Company is party to a revolving loan credit
 facility (Chinese Revolver) with a lender in China. Under this
 arrangement, the lender has made available to the Company
 approximately $30,500 in unsecured borrowing with all terms of the
 borrowing to be negotiated at the time the Chinese Revolver is
 drawn upon. There are no commitment fees on the unused portion of
 the Chinese Revolver, and this arrangement expires in January 2018.
 As of April 3, 2017, the Chinese Revolver had not been drawn
 upon.

- removed (2017-08-08):
[0001193125-17-166200:note_history:32]
At April 3, 2017, the remaining weighted average
 amortization period for the unamortized debt issuance costs for
 both the Term Loan and the ABL Revolving Loans was 3.4
 years.

- removed (2017-08-08):
[0001193125-17-166200:note_history:33]
|  |  | For the Quarter Ended |  |
|  |  | April 3, 2017 |  |  | March 28, 2016 |  |
|  |  | (In thousands) |  |
| Contractual coupon interest |  | $ | 1,094 |  |  | $ | 1,094 |  |
| Amortization of debt discount |  | $ | 2,091 |  |  | $ | 1,960 |  |
| Amortization of debt issuance costs |  | $ | 209 |  |  | $ | 196 |  |


## us-gaap:ScheduleOfDebtInstrumentsTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2017-08-08):
[0001193125-17-251481:note_history:34]
The following table summarizes the long-term debt of the
 Company as of July 3, 2017 and January 2,
 2017:
  (was, 2017-05-11, similarity 0.9637):
[0001193125-17-166200:note_history:34]
The following table summarizes the long-term debt of the
 Company as of April 3, 2017 and January 2,
 2017:

- changed (2017-08-08):
[0001193125-17-251481:note_history:35]
|  |  | Average Effective Interest Rate as of July 3, 2017 |  |  | July 3, 2017 |  |  | Average Effective Interest Rate as of January 2, 2017 |  |  | January 2, 2017 |  |
|  |  | (In thousands) |  |
| Term loan due May 2021 |  |  | 5.48% |  |  | $ | 650,000 |  |  |  | 5.25% |  |  | $ | 700,000 |  |
| U.S. ABL revolving loan due May 2020 |  |  | 2.73% |  |  |  | 80,000 |  |  |  | 2.27% |  |  |  | 80,000 |  |
| Asia ABL revolving loan due May 2020 |  |  | 2.63% |  |  |  | 30,000 |  |  |  | 2.17% |  |  |  | 30,000 |  |
| Convertible Senior Notes due December 2020 |  |  | 1.75% |  |  |  | 249,985 |  |  |  | 1.75% |  |  |  | 250,000 |  |
| Capital lease |  |  | 6.43% |  |  |  | 1,844 |  |  |  | 6.43% |  |  |  | 1,798 |  |
|  |  |  |  |  |  |  | 1,011,829 |  |  |  |  |  |  |  | 1,061,798 |  |
| Less: Long-term debt unamortized discount |  |  |  |  |  |  | (33,174 | ) |  |  |  |  |  |  | (37,392 | ) |
| Long-term debt unamortized debt issuance costs |  |  |  |  |  |  | (4,139 | ) |  |  |  |  |  |  | (4,724 | ) |
|  |  |  |  |  |  |  | 974,516 |  |  |  |  |  |  |  | 1,019,682 |  |
| Less: current maturities |  |  |  |  |  |  | (110,669 | ) |  |  |  |  |  |  | (110,652 | ) |
| Long-term debt, less current maturities |  |  |  |  |  | $ | 863,847 |  |  |  |  |  |  | $ | 909,030 |  |
  (was, 2017-05-11, similarity 0.9792):
[0001193125-17-166200:note_history:35]
|  |  | Average Effective Interest Rate as of April 3, 2017 |  |  | April 3, 2017 |  |  | Average Effective Interest Rate as of January 2, 2017 |  |  | January 2, 2017 |  |
|  |  | (In thousands) |  |
| Term loan due May 2021 |  |  | 5.25% |  |  | $ | 700,000 |  |  |  | 5.25% |  |  | $ | 700,000 |  |
| U.S. ABL revolving loan due May 2020 |  |  | 2.48% |  |  |  | 80,000 |  |  |  | 2.27% |  |  |  | 80,000 |  |
| Asia ABL revolving loan due May 2020 |  |  | 2.38% |  |  |  | 30,000 |  |  |  | 2.17% |  |  |  | 30,000 |  |
| Convertible Senior Notes due December 2020 |  |  | 1.75% |  |  |  | 250,000 |  |  |  | 1.75% |  |  |  | 250,000 |  |
| Capital lease |  |  | 6.43% |  |  |  | 1,815 |  |  |  | 6.43% |  |  |  | 1,798 |  |
|  |  |  |  |  |  |  | 1,061,815 |  |  |  |  |  |  |  | 1,061,798 |  |
| Less: Long-term debt unamortized discount |  |  |  |  |  |  | (35,301 | ) |  |  |  |  |  |  | (37,392 | ) |
| Long-term debt unamortized debt issuance costs |  |  |  |  |  |  | (4,465 | ) |  |  |  |  |  |  | (4,724 | ) |
|  |  |  |  |  |  |  | 1,022,049 |  |  |  |  |  |  |  | 1,019,682 |  |
| Less: current maturities |  |  |  |  |  |  | (160,658 | ) |  |  |  |  |  |  | (110,652 | ) |
| Long-term debt, less current maturities |  |  |  |  |  | $ | 861,391 |  |  |  |  |  |  | $ | 909,030 |  |


## us-gaap:RelatedPartyTransactionsDisclosureTextBlock (related_parties) — matched_by: tag_name, score: 1.0

- added (2017-08-08):
[0001193125-17-251481:note_history:36]
In the normal course of
 business, the Company’s foreign subsidiaries purchase
 laminate and prepreg from related parties in which a significant
 shareholder of the Company holds an equity interest. The Company
 purchased laminate and prepreg from these related parties in the
 amount of $12,121 and $14,259 for the quarters ended July 3,
 2017 and June 27, 2016, respectively, and $25,611 and $30,257
 for the two quarters ended July 3, 2017 and June 27,
 2016, respectively.

- added (2017-08-08):
[0001193125-17-251481:note_history:37]
The Company also sells
 PCBs to a related party which is a wholly owned subsidiary of an
 entity in which a significant shareholder of the Company holds an
 equity interest. Sales to this related party for the quarters ended
 July 3, 2017 and June 27, 2016 were $17 and $298,
 respectively, and $48 and $610 for the two quarters ended
 July 3, 2017 and June 27, 2016,
 respectively.

- changed (2017-08-08):
[0001193125-17-251481:note_history:38]
As of July 3, 2017
 and January 2, 2017, the Company’s consolidated
 condensed balance sheets included $16,934 and $15,836,
 respectively, in accounts payable due to related parties primarily
 for purchases of laminate and prepreg and such balances are
 included as a component of accounts payable on the consolidated
 condensed balance sheets. Additionally, the Company’s
 consolidated condensed balance sheets included $31 and $192,
 respectively, in accounts receivable due from a related party for
 sales of PCBs, as mentioned above, and such balances are included
 as a component of accounts receivable, net on the consolidated
 condensed balance sheets.
  (was, 2017-05-11, similarity 0.9729):
[0001193125-17-166200:note_history:38]
As of April 3, 2017 and January 2, 2017, the
 Company’s consolidated condensed balance sheets included
 $17,884 and $15,836, respectively, in accounts payable due to
 related parties primarily for purchases of laminate and prepreg and
 such balances are included as a component of accounts payable on
 the consolidated condensed balance sheets. Additionally, the
 Company’s consolidated condensed balance sheets included $124
 and $192, respectively, in accounts receivable due from a related
 party for sales of PCBs to SYE, as mentioned above, and such
 balances are included as a component of accounts receivable, net on
 the consolidated condensed balance sheets.

- removed (2017-08-08):
[0001193125-17-166200:note_history:39]
In the normal course of business, the Company’s foreign
 subsidiaries purchase laminate and prepreg from related parties in
 which a significant shareholder of the Company holds an equity
 interest. For the quarters ended April 3, 2017 and
 March 28, 2016, the Company’s foreign subsidiaries
 purchased $13,540 and $15,998, respectively, of laminate and
 prepreg from these related parties.

- removed (2017-08-08):
[0001193125-17-166200:note_history:40]
Dongguan Shengyi Electronics Ltd. (SYE) is also a related party
 as it is a wholly owned subsidiary of an entity in which a
 significant shareholder of the Company holds an equity interest.
 The Company sells PCBs to SYE and purchases PCBs including various
 services relating to PCB manufacturing from SYE. Sales to SYE for
 the quarters ended April 3, 2017 and March 28, 2016 were
 $31 and $311, respectively. Purchases of PCBs including various
 services relating to PCB manufacturing for the quarter ended
 March 28, 2016 was $28. There were no purchases of PCBs or any
 services relating to PCB manufacturing for the quarter ended
 April 3, 2017.
