# TTMI MD&A — 0001193125-17-251481


## mdna

[0001193125-17-251481:mdna:1]
Item 2. Management’s Discussion and Analysis of
Financial Condition and Results of Operations

[0001193125-17-251481:mdna:2]
CAUTIONARY STATEMENT REGARDING FORWARD-LOOKING STATEMENTS

[0001193125-17-251481:mdna:3]
The following discussion of our financial condition and results of operations should be read in
conjunction with our consolidated condensed financial statements and the related notes and the other financial information included in this Quarterly Report on Form 10-Q. This Quarterly Report on Form 10-Q contains forward-looking statements regarding business strategies, market potential, future events, our future financial and operational performance, and other matters. Forward-looking statements
include all statements that are not historical facts, including statements regarding markets for our products; trends in net sales, gross profits and estimated expense levels; liquidity and anticipated cash needs and availability. The words
“anticipate,” “believe,” “plan,” “forecast,” “foresee,” “estimate,” “project,” “expect,” “seek,” “target,” “intend,” “goal” and
other similar expressions, among others, generally identify “forward-looking statements,” which speak only as of the date the statements were made and are not guarantees of performance. The forward-looking statements included in this
report reflect our current expectations and beliefs expressed in good faith, and we believe such statements to have a reasonable basis. We do not undertake publicly to update or revise these statements except as required by law, even if experience
or future changes make it clear that any projected results expressed in this annual report or future quarterly reports to stockholders, press releases or company statements will not be realized. In addition, the inclusion of any statement in this
report does not constitute an admission by us that the events or circumstances described in such statement are material. Furthermore, we wish to caution and advise readers that these statements are based on assumptions that may not materialize and
may involve risks and uncertainties, many of which are beyond our control that could cause actual events or performance to differ materially from those contained or implied in these forward-looking statements. Factors, risks, trends, and
uncertainties that could actual results or events to differ materially from those projected, anticipated, or implied include the matters described below under “Management’s Discussion and Analysis of Financial Condition and Results of
Operations,” the statements made under the captions “Risk Factors” and “Management’s Discussion and Analysis of Financial Condition and Results of Operations” contained in our 2016 Annual Report on Form 10-K, and the following other factors, risks, trends and uncertainties:

[0001193125-17-251481:mdna:4]
|  | • |  | Business conditions and growth or decline in our customers’ industries, the printed circuit board industry, and general economic trends and conditions; |

[0001193125-17-251481:mdna:5]
|  | • |  | Risks and uncertainties related to strategic acquisitions or investments, including distraction of management attention, incurrence of additional debt, integration challenges, and failure to realize expected benefits or synergies or to operate businesses effectively following acquisitions; |

[0001193125-17-251481:mdna:6]
|  | • |  | Variability in the exchange rate relative to the U.S. dollar of currencies in foreign jurisdictions in which we operate, particularly regarding the Chinese Renminbi; |

[0001193125-17-251481:mdna:7]
|  | • |  | Our substantial international operations, and the resulting risks related to our operating internationally, including weak global economic conditions, instability in global credit markets, and governmental restrictions on the transfer of funds to us from our operations outside the U.S.; |

[0001193125-17-251481:mdna:8]
|  | • |  | Our dependence on a small number of OEM customers and on certain industries; |

[0001193125-17-251481:mdna:9]
|  | • |  | Adverse outcomes in litigation or proceedings with governmental authorities or administrative agencies, or changes in the regulatory environment, any of which could encumber or impede our efforts to improve operating results or the value of assets; |

[0001193125-17-251481:mdna:10]
|  | • |  | Our ability to maintain our engineering, technological and manufacturing process expertise; |

[0001193125-17-251481:mdna:11]
|  | • |  | Competitive pressures in the markets in which we operate; |

[0001193125-17-251481:mdna:12]
|  | • |  | Our ability to protect our intellectual property or defend successfully against infringement claims; |

[0001193125-17-251481:mdna:13]
|  | • |  | Potential disruption or interruption of our Information Technology (IT) systems due to accidents, extraordinary weather events, civil unrest, political events, terrorism or cyber security attacks; |

[0001193125-17-251481:mdna:14]
|  | • |  | The susceptibility of our production levels to the variability of customer requirements, including seasonal influences on the demand for certain end products; and |

[0001193125-17-251481:mdna:15]
|  | • |  | Other uncertainties relating to general economic, political, business, industry, regulatory and market conditions. |

[0001193125-17-251481:mdna:16]
[same as prior period, unchanged from 0001193125-17-166200:mdna:2]

[0001193125-17-251481:mdna:17]
We are a leading global printed circuit board (PCB) manufacturer, focusing on quick-turn and volume production of technologically complex PCBs and electro-mechanical solutions (E-M Solutions). We focus on providing time-to-market and volume production of advanced technology products and offer a one-stop manufacturing solution to our customers from engineering support to prototype development through final mass production. This one-stop manufacturing solution allows
us to align technology development with the diverse needs of our customers and to enable them to reduce the time required to develop new products and bring them to market. We serve a diversified customer base consisting of approximately 1,500
customers in various markets throughout the world, including manufacturers of networking/communications infrastructure products, smartphones and touchscreen tablets, as well as aerospace and defense, automotive,
high-end computing, and medical, industrial and instrumentation related products. Our customers include both original equipment manufacturers (OEMs) and electronic manufacturing services (EMS) providers.

[0001193125-17-251481:mdna:18]
[same as prior period, unchanged from 0001193125-17-166200:mdna:10]

[0001193125-17-251481:mdna:19]
For the first two quarters of 2017, we experienced higher demand in our
Cellular Phone, Computing/Storage/Peripherals, Aerospace/ Defense and Automotive end markets compared to the first two quarters of 2016. This increase in sales resulted in higher capacity utilization especially at our Cellular Phone and
Computing/Storage/Peripherals focused facilities resulting in higher gross margins.

[0001193125-17-251481:mdna:20]
In the normal course of
operations, we are exposed to risks associated with fluctuations in foreign currency exchange rates. Specifically, we are subject to risks associated with transactions that are denominated in currencies other than our functional currencies. Our
primary foreign exchange exposure is to the Chinese Renminbi (RMB). For the quarter and two quarters ended July 3, 2017, our consolidated condensed statement of operations included an unrealized foreign exchange loss of approximately
$6.5 million and $10.2 million, respectively, due primarily to the rapid appreciation of the RMB against the U.S. dollar. We do not engage in hedging to manage foreign currency risk related to revenue and expenses denominated in RMB nor do
we currently use derivative instruments to reduce exposure to foreign currency risk for a majority of our loans due from our foreign subsidiaries.

[0001193125-17-251481:mdna:21]
From time to time, we may make additional principal payments on our outstanding debt in the normal course of business as cash flow allows. During the quarter ended July 3, 2017, we made a
$50.0 million additional prepayment of principal on the Term Loan Credit Agreement (Term Loan).

[0001193125-17-251481:mdna:22]
While
our customers include both OEMs and EMS providers, we measure customers based on OEM companies, as they are the ultimate end customers. Sales to our 10 largest customers accounted for 45% and 40% of our net sales for both the quarters and two
quarters ended July 3, 2017 and June 27, 2016, respectively. We sell to OEMs both directly and indirectly through EMS providers.

[0001193125-17-251481:mdna:23]
The following table shows the percentage of our net sales attributable to each of the principal end markets we served for the periods indicated:

[0001193125-17-251481:mdna:24]
|  |  | Quarter Ended |  |  | Two Quarters Ended |  |
| End Markets(1)(2) |  | July 3,2017 |  |  | June 27,2016 |  |  | July 3,2017 |  |  | June 27,2016 |  |
| Aerospace and Defense |  |  | 17 | % |  |  | 16 | % |  |  | 16 | % |  |  | 16 | % |
| Automotive |  |  | 20 |  |  |  | 19 |  |  |  | 20 |  |  |  | 20 |  |
| Cellular Phone(2) |  |  | 13 |  |  |  | 10 |  |  |  | 13 |  |  |  | 10 |  |
| Computing/Storage/Peripherals(2) |  |  | 14 |  |  |  | 13 |  |  |  | 15 |  |  |  | 13 |  |
| Medical/Industrial/Instrumentation |  |  | 15 |  |  |  | 16 |  |  |  | 15 |  |  |  | 16 |  |
| Networking/Communications |  |  | 20 |  |  |  | 25 |  |  |  | 20 |  |  |  | 24 |  |
| Other(2) |  |  | 1 |  |  |  | 1 |  |  |  | 1 |  |  |  | 1 |  |
| Total |  |  | 100 | % |  |  | 100 | % |  |  | 100 | % |  |  | 100 | % |

[0001193125-17-251481:mdna:25]
[same as prior period, unchanged from 0001193125-17-166200:mdna:8]

[0001193125-17-251481:mdna:26]
[same as prior period, unchanged from 0001193125-17-166200:mdna:9]

[0001193125-17-251481:mdna:27]
We derive revenues primarily from the sale of PCBs and custom electronic assemblies using customer-supplied engineering and design plans. We recognize revenues when persuasive evidence of a sales
arrangement exists, the sales terms are fixed or determinable, title and risk of loss have transferred, and collectability is reasonably assured — generally when products are shipped to the customer. Net sales consist of gross sales less an
allowance for returns, which typically have been less than 3% of gross sales. We provide our customers a limited right of return for defective PCBs and backplane assemblies. We record an estimate for sales returns and allowances at the time of sale
based on historical results. Purchase orders may be cancelled prior to shipment. We generally charge customers a fee, based on the percentage completed, if an order is cancelled once it has entered production.

[0001193125-17-251481:mdna:28]
Cost of goods sold consists of materials, labor, outside services, and overhead expenses incurred in the manufacture and
testing of our products. Shipping and handling fees and related freight costs and supplies associated with shipping products are also included as a component of cost of goods sold. Many factors affect our gross margin, including capacity
utilization, product mix, production volume, and yield. We generally do not participate in any significant long-term contracts with suppliers, and we believe there are a number of potential suppliers for the raw materials we use.

[0001193125-17-251481:mdna:29]
Selling and marketing expenses consist primarily of salaries, labor related benefits, and commissions paid to our
internal sales force, independent sales representatives, and our sales support staff, as well as costs associated with marketing materials and trade shows.

[0001193125-17-251481:mdna:30]
General and administrative costs primarily include the salaries for
executive, finance, accounting, information technology, and human resources personnel, as well as expenses for accounting and legal assistance, incentive compensation expense, and gains or losses on the sale or disposal of property, plant and
equipment.

[0001193125-17-251481:mdna:31]
[same as prior period, unchanged from 0001193125-17-166200:mdna:15]

[0001193125-17-251481:mdna:32]
Our consolidated condensed financial statements included in this report have been prepared in accordance with U.S. GAAP.
The preparation of these financial statements requires management to make estimates and assumptions that affect the reported amounts of assets, liabilities, net sales and expenses, and related disclosure of contingent assets and liabilities.

[0001193125-17-251481:mdna:33]
See Item 7, Management’s Discussion and Analysis of Financial Condition and Results of
Operations, in our Annual Report on Form 10-K for the fiscal year ended January 2, 2017 for further discussion of critical accounting policies and estimates. There were no material changes to our
critical accounting policies and estimates since January 2, 2017.

[0001193125-17-251481:mdna:34]
[same as prior period, unchanged from 0001193125-17-166200:mdna:19]

[0001193125-17-251481:mdna:35]
[same as prior period, unchanged from 0001193125-17-166200:mdna:20]

[0001193125-17-251481:mdna:36]
|  |  | Quarter Ended |  |  | Two Quarters Ended |  |
|  |  | July 3, 2017 |  |  | June 27, 2016 |  |  | July 3, 2017 |  |  | June 27, 2016 |  |
| Net sales |  |  | 100.0 | % |  |  | 100.0 | % |  |  | 100.0 | % |  |  | 100.0 | % |
| Cost of goods sold |  |  | 84.7 |  |  |  | 83.8 |  |  |  | 84.0 |  |  |  | 84.7 |  |
| Gross profit |  |  | 15.3 |  |  |  | 16.2 |  |  |  | 16.0 |  |  |  | 15.3 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Selling and marketing |  |  | 2.5 |  |  |  | 2.8 |  |  |  | 2.6 |  |  |  | 2.9 |  |
| General and administrative |  |  | 4.6 |  |  |  | 6.0 |  |  |  | 4.6 |  |  |  | 6.1 |  |
| Amortization of definite-lived intangibles |  |  | 0.9 |  |  |  | 1.0 |  |  |  | 0.9 |  |  |  | 1.0 |  |
| Restructuring charges |  |  | 0.1 |  |  |  | 0.7 |  |  |  | 0.1 |  |  |  | 0.5 |  |
| Impairment of long-lived assets |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 0.3 |  |
| Total operating expenses |  |  | 8.1 |  |  |  | 10.5 |  |  |  | 8.2 |  |  |  | 10.8 |  |
| Operating income |  |  | 7.2 |  |  |  | 5.7 |  |  |  | 7.8 |  |  |  | 4.5 |  |
| Other income (expense): |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Interest expense |  |  | (2.1 | ) |  |  | (3.3 | ) |  |  | (2.1 | ) |  |  | (3.5 | ) |
| Other, net |  |  | (0.9 | ) |  |  | 0.6 |  |  |  | (0.6 | ) |  |  | 0.3 |  |
| Total other expense, net |  |  | (3.0 | ) |  |  | (2.7 | ) |  |  | (2.7 | ) |  |  | (3.2 | ) |
| Income before income taxes |  |  | 4.2 |  |  |  | 3.0 |  |  |  | 5.1 |  |  |  | 1.3 |  |
| Income tax (provision) benefit |  |  | (0.9 | ) |  |  | 0.1 |  |  |  | (0.8 | ) |  |  | (0.3 | ) |
| Net income |  |  | 3.3 |  |  |  | 3.1 |  |  |  | 4.3 |  |  |  | 1.0 |  |
| Less: Net income attributable to noncontrolling interest |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |
| Net income attributable to TTM Technologies, Inc. stockholders |  |  | 3.3 | % |  |  | 3.1 | % |  |  | 4.3 | % |  |  | 1.0 | % |

[0001193125-17-251481:mdna:37]
We have two reportable operating segments: PCB and
E-M Solutions. This determination was made based on the criteria of earning revenues and incurring expenses, our organizational structure which has segment managers who report to the chief operating decision
maker, discrete financial information, and the aggregation of similar operating segments into reportable operating segments for the PCB reportable operating segment.

[0001193125-17-251481:mdna:38]
The following table compares net sales by reportable segment for the
quarters and two quarters ended July 3, 2017 and June 27, 2016:

[0001193125-17-251481:mdna:39]
|  |  | Quarter Ended |  |  | Two Quarters Ended |  |
|  |  | July 3, 2017 |  |  | June 27, 2016 |  |  | July 3, 2017 |  |  | June 27, 2016 |  |
|  |  | (In thousands) |  |
| Net Sales: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| PCB |  | $ | 576,566 |  |  | $ | 563,574 |  |  | $ | 1,163,261 |  |  | $ | 1,093,519 |  |
| E-M Solutions |  |  | 52,898 |  |  |  | 40,427 |  |  |  | 94,567 |  |  |  | 96,905 |  |
| Total sales |  |  | 629,464 |  |  |  | 604,001 |  |  |  | 1,257,828 |  |  |  | 1,190,424 |  |
| Inter-segment sales |  |  | (2,282 | ) |  |  | (2,154 | ) |  |  | (5,399 | ) |  |  | (5,319 | ) |
| Total net sales |  | $ | 627,182 |  |  | $ | 601,847 |  |  | $ | 1,252,429 |  |  | $ | 1,185,105 |  |

[0001193125-17-251481:mdna:40]
[same as prior period, unchanged from 0001193125-17-166200:mdna:25]

[0001193125-17-251481:mdna:41]
Total net sales increased $25.4 million, or 4.2%, from $601.8 million for the second quarter of 2016 to $627.2 million for the second quarter of 2017. Net sales for the PCB operating
segment, excluding inter-segment sales, increased $12.9 million, or 2.3%, from $561.4 million for the second quarter of 2016 to $574.3 million for the second quarter of 2017. This increase was primarily due to higher demand in our
Cellular Phone, Computing/Storage/Peripherals and Aerospace/Defense end markets, partially offset by a decline in our Networking/Communications end market. These changes resulted in a 1.9% increase in PCB shipments as compared to the second quarter
of 2016, and an average PCB selling price decrease of 0.5%, which was driven by a product mix shift. Net sales for the E-M Solutions operating segment increased $12.5 million, or 30.9%, from
$40.4 million for the second quarter of 2016 to $52.9 million for the second quarter of 2017. This increase was primarily due to higher demand in our Automotive end market.

[0001193125-17-251481:mdna:42]
Total net sales increased $67.3 million, or 5.7%, from $1,185.1 million for the first two quarters of 2016 to
$1,252.4 million for the first two quarters of 2017. Net sales for the PCB operating segment, excluding inter-segment sales, increased $69.7 million, or 6.4%, from $1,088.2 million for the first two quarters of 2016 to
$1,157.9 million for the first two quarters of 2017. The increase was primarily due to higher demand in our Cellular Phone, Computing/Storage/Peripherals and Aerospace/Defense end markets, partially offset by a decline in our
Networking/Communications end market. These changes resulted in a 5.5% increase in PCB shipments as compared to the first two quarters of 2016, and an average PCB selling price increase of 0.4%, which was driven by a product mix shift. Net sales for
the E-M Solutions operating segment decreased $2.3 million, or 2.4%, from $96.9 million for the first two quarters of 2016 to $94.6 million for the first two quarters of 2017. The decrease was
primarily due to lower demand in our Networking/Communications and Computing/Storage/Peripherals partially offset by higher demand in our Automotive end market.

[0001193125-17-251481:mdna:43]
[same as prior period, unchanged from 0001193125-17-166200:mdna:30]

[0001193125-17-251481:mdna:44]
Overall gross margin decreased from
16.2% for the second quarter of 2016 to 15.3% for the second quarter of 2017. Gross margin for the PCB operating segment decreased from 17.1% for the second quarter of 2016 to 16.1% for the second quarter of 2017, primarily due to the change in
classification of certain facilities and labor support related costs from general and administrative expenses to cost of goods sold due to changes in our business structure and the impact of annual salary increases, partially offset by higher net
sales due to increased volumes at our Cellular Phone and Computing/Storage/Peripherals focused facilities. Gross margin for the E-M Solutions operating segment increased from 8.5% for the second quarter of
2016 to 10.0% for the second quarter of 2017, primarily due to increased volumes.

[0001193125-17-251481:mdna:45]
Overall gross margin
increased from 15.3% for the first two quarters of 2016 to 16.0% for the first two quarters of 2017. Gross margin for the PCB operating segment increased from 16.4% for the first two quarters of 2016 to 17.1% for the first two quarters of 2017,
primarily due to increased volumes at our Cellular Phone and Computing/Storage/Peripherals focused facilities, savings from our synergy initiatives, and a $3.0 million insurance settlement from a fire in our Anaheim, California, facility a year
ago, partially offset by the change in classification of certain facilities and labor support related costs from general and administrative expenses to cost of goods sold due to changes in our business structure. Gross margin for the E-M Solutions operating segment decreased from 7.4% for the first two quarters of 2016 to 6.8% for the first two quarters of 2017, primarily due to decreased volumes and higher inventory reserves.

[0001193125-17-251481:mdna:46]
[same as prior period, unchanged from 0001193125-17-166200:mdna:32]

[0001193125-17-251481:mdna:47]
Selling and marketing expenses decreased $0.7 million, from $16.6 million for the second quarter of 2016 to $15.9 million for the second quarter of 2017. Selling and marketing expenses
decreased $1.4 million, from $33.9 million for the first two quarters of 2016 to $32.5 million for the first two quarters of 2017. As a percentage of net sales, selling and marketing expenses was 2.8% for the second quarter of 2016,
as compared to 2.5% for the second quarter of 2017, and 2.9% for the first two quarters of 2016, as compared to 2.6% for the first two quarters of 2017. The decrease in selling and marketing expense primarily related to reduced headcount and
lower travel expenses.

[0001193125-17-251481:mdna:48]
[same as prior period, unchanged from 0001193125-17-166200:mdna:34]

[0001193125-17-251481:mdna:49]
General and administrative expenses decreased $7.9 million from $36.5 million, or 6.0% of net sales, for the
second quarter of 2016 to $28.6 million, or 4.6% of net sales, for the second quarter of 2017. General and administrative expenses decreased $14.7 million from $72.6 million, or 6.1% of net sales, for the first two quarters of 2016 to
$57.9 million, or 4.6% of net sales, for the first two quarters of 2017. The decrease in expense primarily related to the change in classification of certain facilities and labor support related costs to cost of goods sold due to changes in our
business structure and lower bad debt expense.

[0001193125-17-251481:mdna:50]
[same as prior period, unchanged from 0001193125-17-166200:mdna:36]

[0001193125-17-251481:mdna:51]
For the second quarter and the first two quarters of 2017, we incurred restructuring charges of $0.4 million and
$1.0 million, respectively, related to a consolidation plan announced on September 29, 2015, that resulted in the closure of our facilities in Cleveland, Ohio, Milpitas, California, and Juarez, Mexico (the Consolidation Plan). These
charges primarily represent severance and contract termination and other costs. Approximately $0.1 million and $0.3 million of these restructuring charges were recognized in our PCB operating segment for the second quarter and the first
two quarters of 2017, respectively, and $0.2 million and $0.5 million were recognized in our E-M Solutions operating segment for the second quarter and the first two quarters of 2017, respectively,
and $0.1 million and $0.2 million were recognized in our Corporate operating segment for the second quarter and the first two quarters of 2017, respectively. As of July 3, 2017, the Company has incurred approximately
$17.4 million of restructuring charges since the September 29, 2015 announcement.

[0001193125-17-251481:mdna:52]
Additionally, as
a result of the above mentioned plant closures and other plant realignment efforts, we also recognized impairment charges of $3.3 million for the first two quarters of 2016, of which $1.4 million were recognized in our PCB operating
segment and $1.9 million were recognized in the Corporate operating segment. The impairment charge for the PCB operating segment related to machinery and equipment while the impairment charge for the Corporate operating segment related to the write-off of capitalized software costs.

[0001193125-17-251481:mdna:53]
If forecasts and assumptions used
to support the realizability of our long-lived assets change in the future, significant impairment or restructuring charges could result that would adversely affect our results of operations.

[0001193125-17-251481:mdna:54]
Other Income (Expense)

[0001193125-17-251481:mdna:55]
Other expense, net increased
$1.8 million from $16.9 million for the second quarter of 2016 to $18.7 million for the second quarter of 2017. The net increase in other expense is primarily due to a $6.5 million foreign currency loss for the quarter ended
July 3, 2017, primarily due to the appreciation of the RMB, which is utilized at certain of our Asia operations. The increase was partially offset by a decrease in interest expense due to lower principal outstanding resulting from net debt
principal payments of $161.1 million during the second half of 2016 and the first two quarters of 2017, a lower Term Loan interest rate by 75 basis points, and lower amortization of debt issuance costs and debt discount after the full repayment
of our prior term loan in the fourth quarter of 2016.

[0001193125-17-251481:mdna:56]
Other expense, net decreased $3.4 million from
$37.5 million for the first two quarters of 2016 to $34.1 million for the first two quarters of 2017. The decrease in other expense, net was primarily due to a decrease in interest expense due to lower principal outstanding resulting from
net debt principal payments of $161.1 million during the second half of 2016 and the first two quarters of 2017, a lower Term Loan interest rate by 75 basis points, and lower amortization of debt issuance costs and debt discount after the full
repayment of our prior term loan in the fourth quarter of 2016. This decrease was partially offset by a $10.2 million foreign currency loss for the two quarters ended July 3, 2017, primarily due to the appreciation of the RMB, which is
utilized at certain of our Asia operations.

[0001193125-17-251481:mdna:57]
[same as prior period, unchanged from 0001193125-17-166200:mdna:42]

[0001193125-17-251481:mdna:58]
The provision for income taxes increased by $6.6 million from a benefit of $1.0 million for the second quarter
of 2016 to a provision of $5.6 million for the second quarter of 2017. The increase in income tax expense in 2017 was primarily due to increased operating income, the absence of benefits from the release of uncertain tax positions in the second
quarter of 2017 for which there was benefit in the second quarter of 2016 and a decrease in tax benefits from tax incentives.

[0001193125-17-251481:mdna:59]
The provision for income taxes increased by $5.2 million from $4.5 million of tax expense for the first two quarters of 2016 to $9.7 million of tax expense for the first two quarters of
2017. The increase in income tax expense in 2017 was primarily due to increased operating income in higher tax rate jurisdictions, the absence of benefits from the release of uncertain tax positions for the two quarters of 2017 for which there was
benefit for the two quarters of 2016, offset by an increase in tax benefits from tax incentives.

[0001193125-17-251481:mdna:60]
[same as prior period, unchanged from 0001193125-17-166200:mdna:56]

[0001193125-17-251481:mdna:61]
Our effective tax rate was primarily impacted by tax rates in the U.S.
(federal and apportioned state income), China and Hong Kong, the generation of other credits and deductions and certain non-deductible items. U.S. federal and state and certain foreign losses generated are not
more likely than not to be realizable and thus, no income tax benefit has been recognized on these losses. As of July 3, 2017, we had net deferred income tax liabilities of approximately $14.1 million and as of January 2, 2017, we had
net deferred income tax liabilities of approximately $14.0 million.

[0001193125-17-251481:mdna:62]
LIQUIDITY AND CAPITAL RESOURCES

[0001193125-17-251481:mdna:63]
Our principal sources of liquidity have been cash provided by operations, the issuance of convertible senior notes, and
term and revolving debt. Our principal uses of cash have been to finance acquisitions and capital expenditures, meet debt service requirements, fund working capital requirements, and repay existing debt. We anticipate that servicing debt, financing
capital expenditures, financing acquisitions, and funding working capital requirements will continue to be the principal demands on our cash in the future.

[0001193125-17-251481:mdna:64]
Cash flow provided by operating activities during the first two quarters of 2017 was $108.7 million as compared to $97.9 million in the same period in 2016. The increase in cash flow was due to
higher net income. Cash cycle days improved to 47 days the second quarter of 2017 as compared to 52 days the same quarter of 2016. As of July 3, 2017, we had net working capital of approximately $302.6 million compared to
$323.8 million as of January 2, 2017.

[0001193125-17-251481:mdna:65]
Net cash used in investing activities was approximately
$69.0 million for the first two quarters of 2017 primarily reflecting purchases of property, plant and equipment of $87.1 million less proceeds from sale of property, plant and equipment and assets held for sale of $18.1 million. For
the first two quarters of 2016, net cash used in investing activities was approximately $31.9 million, which reflects purchases of property, plant and equipment, net of proceeds from sales of property, plant and equipment and assets held for
sale of $35.4 million, less the release of restricted cash to cash and cash equivalents of $3.5 million.

[0001193125-17-251481:mdna:66]
Net cash used by financing activities was approximately $49.9 million the first two quarters of 2017 reflecting additional prepayments of principal of long-term debt of $50.0 million less
proceeds from exercise of common stock options of $0.1 million. Net cash used in financing activities was approximately $106.5 million for the first two quarters of 2016 reflecting the repayment of normally scheduled principal payments as
well as additional prepayments of principal of long-term debt.

[0001193125-17-251481:mdna:67]
As of July 3, 2017, we had cash and cash
equivalents of approximately $246.9 million, of which approximately $171.4 million was held by our foreign subsidiaries, primarily Asia. Cash and cash equivalents held by our foreign locations are expected to be used in local operations.

[0001193125-17-251481:mdna:68]
[same as prior period, unchanged from 0001193125-17-166200:mdna:51]

[0001193125-17-251481:mdna:69]
[same as prior period, unchanged from 0001193125-17-166200:mdna:52]

[0001193125-17-251481:mdna:70]
[same as prior period, unchanged from 0001193125-17-166200:mdna:53]

[0001193125-17-251481:mdna:71]
The
Term Loan bears interest at a floating rate of LIBOR, with a 1.0% LIBOR floor, plus an applicable interest margin of 4.25%, or JP Morgan Chase Bank’s prime rate, with a 2% floor, plus a margin of 3.25%, at the our option. At July 3, 2017,
the weighted average interest rate on the outstanding borrowings under the Term Loan was 5.48%. There is no provision, other than an event of default, for the interest margin to increase. The Term Loan will mature on May 31, 2021. The Term Loan
is secured by a significant amount of our assets and a pledge of 65% of voting stock of our first tier foreign subsidiaries and is structurally senior to our convertible senior notes. See Convertible Senior Notes below.

[0001193125-17-251481:mdna:72]
The U.S. ABL consists of three tranches comprised of a revolving credit facility of up to $200.0 million, a letter
of credit facility of up to $50.0 million, and swingline loans of up to $30.0 million, provided that at no time may amounts outstanding under the tranches exceed in aggregate $200.0 million or the applicable borrowing base, which is a
percentage of the principal amount of Eligible Accounts, as defined in the U.S. ABL agreement. Borrowings under the U.S. ABL bear interest at either a floating rate of LIBOR plus a margin of 150 basis points or JP Morgan Chase Bank’s prime rate
plus a margin of 50 basis points, at our option. At July 3, 2017, the weighted average interest rate on the outstanding borrowings under the U.S. ABL was 2.73%. The applicable margin can vary based on the remaining availability of the facility,
from 125 to 175 basis points for LIBOR-based loans and from 25 to 75 basis points for JP Morgan Chase Bank’s prime rate-based loans. Other than availability and an event of default, there are no other provisions for the interest margin to
increase. The U.S. ABL will mature on May 31, 2020. Loans made under the U.S. ABL are secured first by all of our domestic cash, receivables and inventories as well as by a second position against a significant amount of our assets and a pledge
of 65% of voting stock of our first tier foreign subsidiaries and are structurally senior to our convertible senior notes. See Convertible Senior Notes below. At July 3, 2017, $80.0 million of the U.S. ABL was outstanding. We and our
domestic subsidiaries have fully and unconditionally guaranteed the full and timely payment of all Term Loan and U.S. ABL related obligations.

[0001193125-17-251481:mdna:73]
25

[0001193125-17-251481:mdna:74]
The Asia ABL consists of two tranches comprised of a revolving credit
facility of up to $150.0 million and a letter of credit facility of up to $100.0 million, provided that at no time may amounts outstanding under both tranches exceed in aggregate $150.0 million or the applicable borrowing base, which
is a percentage of the principal amount of Eligible Accounts, as defined in the Asia ABL agreement. Borrowings under the Asia ABL bear interest at a floating rate of LIBOR plus 140 basis points. At July 3, 2017, the weighted average interest
rate on the outstanding borrowings under the Asia ABL was 2.63%. There is no provision, other than an event of default, for the interest margin to increase. The Asia ABL will mature on May 22, 2020. Loans made under the Asia ABL are secured by
a portion of our Asia Pacific cash and receivables and are structurally senior to our domestic obligations, including the convertible senior notes. See Convertible Senior Notes below. Our Asia Pacific subsidiary and certain of our subsidiaries have
fully and unconditionally guaranteed the full and timely payment of all Asia ABL related obligations. At July 3, 2017, $30.0 million of the Asia ABL was outstanding.

[0001193125-17-251481:mdna:75]
We are no longer required to make quarterly scheduled payments for the remaining term of the outstanding Term Loan
balance due to mandatory payments and optional loan prepayments applied to date. Additionally, based on certain parameters defined in the Term Loan agreement, including a secured leverage ratio, we are also not required to make an additional
principal payment for fiscal year 2017 as our secured leverage ratio is less than or equal to 1.5. We may be required to make additional principal payments in future years, if our secured leverage ratio is greater than 1.5. Any remaining outstanding
balances under the Term Loan are due at the maturity date of May 31, 2021. During the quarter ended July 3, 2017, the Company made an optional debt principal prepayment on our Term Loan totaling $50.0 million. Borrowings under the
Term Loan are subject to financial and operating covenants including maintaining a maximum total leverage ratio. Under the occurrence of certain events, the U.S. ABL and the Asia ABL are subject to financial and operational covenants, including
maintaining minimum fixed charge coverage ratios. At July 3, 2017, we were in compliance with the covenants under the Term Loan, the U.S. ABL and the Asia ABL.

[0001193125-17-251481:mdna:76]
We are required to pay a commitment fee of 0.25% to 0.375% per annum on any unused portion of the U.S. ABL or Asia
ABL. We incurred total commitment fees related to unused borrowing availability of $0.2 million and $0.4 million for the quarter and two quarters ended July 3, 2017, respectively. As of July 3, 2017, the outstanding amount of the
Term Loan was $650.0 million, all of which is included in long-term debt. Additionally, $80.0 million of the U.S. ABL and $30.0 million of the Asia ABL were outstanding as of July 3, 2017, which were classified as short-term
debt. Available borrowing capacity under the U.S. ABL and Asia ABL was $112.4 million and $78.3 million, which includes letters of credit outstanding of $7.6 million and $41.7 million mentioned below, respectively, at
July 3, 2017.

[0001193125-17-251481:mdna:77]
[same as prior period, unchanged from 0001193125-17-166200:mdna:61]

[0001193125-17-251481:mdna:78]
We have up to $50.0 million and $100.0 million Letters of Credit Facilities available under the U.S. ABL and the Asia ABL, respectively. As of July 3, 2017, letters of credit in the amount
of $7.6 million were outstanding under the U.S. ABL and $41.7 million were outstanding under the Asia ABL with various expiration dates through September 2018.

[0001193125-17-251481:mdna:79]
[same as prior period, unchanged from 0001193125-17-166200:mdna:63]

[0001193125-17-251481:mdna:80]
We are party to a revolving loan credit
facility with a lender in China. Under this arrangement, the lender has made available to us approximately $31.0 million in unsecured borrowing with all terms of the borrowing to be negotiated at the time the Chinese Revolver is drawn upon.
There are no commitment fees on the unused portion of the Chinese Revolver, and this arrangement expires in January 2018. As of July 3, 2017, the Chinese Revolver had not been drawn upon.

[0001193125-17-251481:mdna:81]
Convertible Senior Notes due 2020

[0001193125-17-251481:mdna:82]
We maintain 1.75% convertible senior notes in the amount of $250.0 million due December 15, 2020. The convertible senior notes bear interest at a rate of 1.75% per annum. Interest is
payable semiannually in arrears on June 15 and December 15 of each year. The convertible senior notes are senior unsecured obligations and rank equally to our future unsecured senior indebtedness and senior in right of payment to any of
our future subordinated indebtedness. Offering expenses are being amortized to interest expense over the term of the convertible senior notes.

[0001193125-17-251481:mdna:83]
Conversion: At any time prior to March 15, 2020, holders may convert their convertible senior notes into cash and, if applicable, into shares of our common stock based on a conversion
rate of 103.7613 shares of our common stock per $1,000 principal amount of convertible senior notes, subject to adjustment, under the following circumstances: (1) during any calendar quarter beginning after March 31, 2015 (and only during
such calendar quarter), if the last reported sale price of our common stock for at least 20 trading days during the 30 consecutive trading days ending on the last trading day of the immediately preceding calendar quarter is greater than or equal to
130% of the applicable conversion price on each applicable trading day of such preceding calendar quarter; (2) during the five business day period after any 10 consecutive trading day period in which the trading price per note for each day of
that 10 consecutive trading day period was less than 98% of the product of the last reported sale price of our common stock and the conversion rate on such day; or (3) upon the occurrence of specified corporate transactions described in the
indenture governing the notes. As of July 3, 2017, the conversion criteria had been met under the condition (1) as described above, allowing holders to give notice of conversion in both the second and third quarter of 2017.

[0001193125-17-251481:mdna:84]
On or after March 15, 2020 until the close of business on the
third scheduled trading day preceding the maturity date, holders may convert their notes at any time, regardless of the foregoing circumstances. Upon conversion, for each $1,000 principal amount of notes, we will pay shares of our common stock, cash
or a combination of cash and shares of our common stock at our election, if applicable, based on a daily conversion value calculated on a proportionate basis for each day of the 80 trading day observation period. All conversions occurring on the
same date or on or after March 15, 2020 shall be settled using the same settlement method. Additionally, in the event of a fundamental change as defined in the indenture governing the notes, or other conversion rate adjustments such as share
splits or combinations, other distributions of shares, cash or other assets to stockholders, including self-tender transactions (Other Conversion Rate Adjustments), the conversion rate may be modified to adjust the number of shares per $1,000
principal amount of the notes. As of July 3, 2017, none of the criteria for a fundamental change or a conversion rate adjustment had been met.

[0001193125-17-251481:mdna:85]
The maximum number of shares issuable upon conversion, including the effect of a fundamental change and subject to Other Conversion Rate Adjustments, would be 32.4 million.

[0001193125-17-251481:mdna:86]
Note Repurchase: We are not permitted to redeem the convertible senior notes at any time prior to maturity.
In the event of a fundamental change or certain default events, as defined in the indenture governing the notes, holders may require us to repurchase for cash all or a portion of their convertible senior notes at a price equal to 100% of the
principal amount, plus any accrued and unpaid interest.

[0001193125-17-251481:mdna:87]
In connection with the issuance of the convertible
senior notes due 2020, we entered into a convertible note hedge and warrant transaction (the Call Spread Transaction), with respect to our common stock. The convertible note hedge consists of our option to purchase up to 25.9 million common
stock shares at a price of $9.64 per share. The hedge expires on December 15, 2020 and can only be executed upon the conversion of the above mentioned convertible senior notes due 2020. Additionally, we sold warrants to purchase
25.9 million shares of our common stock at a price of $14.26 per share. The warrants expire ratably from March 2021 through January 2022. The Call Spread Transaction has no effect on the terms of the convertible senior notes due 2020 and
reduces potential dilution by effectively increasing the conversion price of the convertible senior notes due 2020 to $14.26 per share of our common stock.

[0001193125-17-251481:mdna:88]
Based on our current level of operations, we believe that cash generated from operations, cash on hand and cash from the issuance of term and revolving debt will be adequate to meet our currently
anticipated capital expenditure, debt service, and working capital needs for the next 12 months.

[0001193125-17-251481:mdna:89]
[same as prior period, unchanged from 0001193125-17-166200:mdna:74]

[0001193125-17-251481:mdna:90]
The following table provides information on our contractual obligations as of July 3, 2017:

[0001193125-17-251481:mdna:91]
|  |  | Total |  |  | Less Than1 Year |  |  | 1 - 3 Years |  |  | 4 - 5 Years |  |  | After5 Years |  |
| Contractual Obligations (1) |  | (In thousands) |  |
| Long-term debt obligations |  | $ | 761,844 |  |  | $ | 110,669 |  |  | $ | 758 |  |  | $ | 650,417 |  |  | $ | — |  |
| Convertible debt obligations |  |  | 249,985 |  |  |  | — |  |  |  | — |  |  |  | 249,985 |  |  |  | — |  |
| Interest on debt obligations |  |  | 160,192 |  |  |  | 43,688 |  |  |  | 81,164 |  |  |  | 35,340 |  |  |  | — |  |
| Equipment payables |  |  | 56,326 |  |  |  | 56,326 |  |  |  | — |  |  |  | — |  |  |  | — |  |
| Purchase obligations |  |  | 112,875 |  |  |  | 97,954 |  |  |  | 6,530 |  |  |  | 584 |  |  |  | 7,807 |  |
| Operating lease commitments |  |  | 27,821 |  |  |  | 8,116 |  |  |  | 9,606 |  |  |  | 4,580 |  |  |  | 5,519 |  |
| Total contractual obligations |  | $ | 1,369,043 |  |  | $ | 316,753 |  |  | $ | 98,058 |  |  | $ | 940,906 |  |  | $ | 13,326 |  |

[0001193125-17-251481:mdna:92]
| (1) | Unrecognized uncertain tax benefits of $39.4 million are not included in the table above as the settlement timing is uncertain. |

[0001193125-17-251481:mdna:93]
[same as prior period, unchanged from 0001193125-17-166200:mdna:78]

[0001193125-17-251481:mdna:94]
[same as prior period, unchanged from 0001193125-17-166200:mdna:79]

[0001193125-17-251481:mdna:95]
[same as prior period, unchanged from 0001193125-17-166200:mdna:80]

[0001193125-17-251481:mdna:96]
[same as prior period, unchanged from 0001193125-17-166200:mdna:81]
