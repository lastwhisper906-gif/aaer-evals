# TTMI notes — 0001193125-17-251481


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001193125-17-251481:notes:1]
(11)
 Commitments and Contingencies

[0001193125-17-251481:notes:2]
Legal
 Matters

[0001193125-17-251481:notes:3]
The Company is subject to various legal matters, which it
 considers normal for its business activities. While the Company
 currently believes that the amount of any reasonably possible loss
 for known matters would not be material to the Company’s
 financial condition, the outcome of these actions is inherently
 difficult to predict. In the event of an adverse outcome, the
 ultimate potential loss could have a material adverse effect on the
 Company’s financial condition or results of operations in a
 particular period. The Company has accrued amounts for its loss
 contingencies which are probable and estimable as of July 3,
 2017 and January 2, 2017. However, these amounts are not
 material to the consolidated condensed financial statements of the
 Company.

[0001193125-17-251481:notes:4]
Environmental Matters

[0001193125-17-251481:notes:5]
The process to manufacture PCBs requires adherence to city,
 county, state, federal, and foreign environmental regulations
 regarding the storage, use, handling and disposal of chemicals,
 solid wastes and other hazardous materials, as well as compliance
 with air quality standards and chemical use reporting. The Company
 believes that its facilities in the United States and Canada comply
 in all material respects with applicable environmental laws and
 regulations. In China, governmental authorities have adopted new
 rules and regulations governing environmental issues. An update to
 the Chinese environmental waste water law was issued in late 2012,
 allowing for an interim period in which plants subject to such law
 may install equipment that meets the new regulatory regime. Some of
 the Company’s plants in China are not yet in full compliance
 with the updated environmental regulations. The Company believes it
 has developed plans acceptable to the Chinese government and is in
 the process of implementing these plans. The Company does not
 anticipate any immediate risk of government fines or temporary
 closure of its Chinese plants. The Company has established and
 enacted an investment plan related to the efforts to come into full
 compliance with the new regulations in a timely fashion. The 2017
 capital expenditure costs expected for these plans are included in
 the Company’s capital expenditure projections.


## us-gaap:ConvertibleDebtTableTextBlock

[0001193125-17-251481:notes:6]
As of July 3, 2017 and January 2, 2017, the following
 summarizes the equity components of the convertible senior notes
 included in additional paid-in capital:

[0001193125-17-251481:notes:7]
|  |  | As of July 3, 2017 |  |  | As of January 2, 2017 |  |
|  |  | Embedded conversion option — Convertible Senior Notes |  |  | Embedded conversion option — Convertible Senior Notes Issuance Costs |  |  | Total |  |  | Embedded conversion option — Convertible Senior Notes |  |  | Embedded conversion option — Convertible Senior Notes Issuance Costs |  |  | Total |  |
|  |  | (in thousands) |  |
| Convertible senior notes due 2020 |  | $ | 60,216 |  |  | $ | (1,916 | ) |  | $ | 58,300 |  |  | $ | 60,227 |  |  | $ | (1,916 | ) |  | $ | 58,311 |  |


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001193125-17-251481:notes:8]
[same as prior period, unchanged from 0001193125-17-166200:notes:8]

[0001193125-17-251481:notes:9]
[same as prior period, unchanged from 0001193125-17-166200:notes:9]

[0001193125-17-251481:notes:10]
|  |  | Quarter Ended |  |  | Two Quarters Ended |  |
|  |  | July 3, 2017 |  |  | June 27, 2016 |  |  | July 3, 2017 |  |  | June 27, 2016 |  |
|  |  | (In thousands) |  |
| Cost of goods sold |  | $ | 639 |  |  | $ | 429 |  |  | $ | 1,033 |  |  | $ | 749 |  |
| Selling and marketing |  |  | 386 |  |  |  | 271 |  |  |  | 639 |  |  |  | 481 |  |
| General and administrative |  |  | 3,975 |  |  |  | 2,145 |  |  |  | 6,956 |  |  |  | 3,861 |  |
| Stock-based compensation expense recognized |  | $ | 5,000 |  |  | $ | 2,845 |  |  | $ | 8,628 |  |  | $ | 5,091 |  |

[0001193125-17-251481:notes:11]
[same as prior period, unchanged from 0001193125-17-166200:notes:11]

[0001193125-17-251481:notes:12]
[same as prior period, unchanged from 0001193125-17-166200:notes:12]

[0001193125-17-251481:notes:13]
The Company records stock-based compensation expense for PRU
 awards granted based on management’s periodic assessment of
 the probability of the PRU awards vesting. For the two quarters
 ended July 3, 2017, management determined that vesting of the
 PRU awards was probable. PRUs activity for the two quarters ended
 July 3, 2017 was as follows:

[0001193125-17-251481:notes:14]
|  |  | Shares |  |  | Weighted Average Fair Value |  |
|  |  | (In thousands) |  |  |  |  |
| Outstanding target shares at January 2, 2017 |  |  | 406 |  |  | $ | 8.31 |  |
| Granted |  |  | 363 |  |  |  | 22.90 |  |
| Change in units due to annual financial target performance achievement |  |  | 7 |  |  |  | 22.90 |  |
| Outstanding target shares at July 3, 2017 |  |  | 776 |  |  | $ | 15.27 |  |

[0001193125-17-251481:notes:15]
[same as prior period, unchanged from 0001193125-17-166200:notes:19]

[0001193125-17-251481:notes:16]
The Company granted 61 and 131 RSUs during the quarters ended
 July 3, 2017 and June 27, 2016, respectively, and 1,007
 and 1,814 RSUs during the two quarters ended July 3, 2017 and
 June 27, 2016, respectively. The RSUs granted have a
 weighted-average fair value per unit of $16.52 and $6.53 for the
 quarters ended July 3, 2017 and June 27, 2016,
 respectively, and $15.82 and $6.74 for the two quarters ended
 July 3, 2017 and June 27, 2016, respectively. The fair
 value for RSUs granted is based on the closing share price of the
 Company’s common stock on the date of grant.

[0001193125-17-251481:notes:17]
[same as prior period, unchanged from 0001193125-17-166200:notes:21]

[0001193125-17-251481:notes:18]
The Company did not grant any stock option awards during the
 quarters and two quarters ended July 3, 2017 and June 27,
 2016.

[0001193125-17-251481:notes:19]
[same as prior period, unchanged from 0001193125-17-166200:notes:23]

[0001193125-17-251481:notes:20]
The following is a summary of total unrecognized compensation
 costs as of July 3, 2017:

[0001193125-17-251481:notes:21]
|  |  | Unrecognized Stock-Based Compensation Cost |  |  | Remaining Weighted Average Recognition Period |  |
|  |  | (In thousands) |  |  | (In years) |  |
| RSU awards |  | $ | 22,467 |  |  |  | 1.5 |  |
| PRU awards |  |  | 7,553 |  |  |  | 1.5 |  |
| Stock options |  |  | 112 |  |  |  | 2.1 |  |
|  |  | $ | 30,132 |  |  |  |  |  |


## us-gaap:InventoryDisclosureTextBlock

[0001193125-17-251481:notes:22]
[same as prior period, unchanged from 0001193125-17-166200:notes:26]

[0001193125-17-251481:notes:23]
Inventories as of July 3, 2017 and January 2, 2017
 consist of the following:

[0001193125-17-251481:notes:24]
|  |  | As of |  |
|  |  | July 3, 2017 |  |  | January 2, 2017 |  |
|  |  | (In thousands) |  |
| Inventories: |  |  |  |  |  |  |  |  |
| Raw materials |  | $ | 75,280 |  |  | $ | 73,497 |  |
| Work-in-process |  |  | 111,245 |  |  |  | 105,094 |  |
| Finished goods |  |  | 95,960 |  |  |  | 90,621 |  |
|  |  | $ | 282,485 |  |  | $ | 269,212 |  |


## us-gaap:NewAccountingPronouncementsPolicyPolicyTextBlock

[0001193125-17-251481:notes:25]
Recently Adopted and Issued Accounting
 Standards

[0001193125-17-251481:notes:26]
In January 2017, the Financial Accounting Standards Board
 (FASB) issued Accounting Standards Update (ASU) 2017-04, Intangibles (Topic 350):
 Goodwill and other. This ASU simplifies the accounting for
 goodwill impairment and removes Step 2 of the goodwill impairment
 test. Goodwill impairment will now be the amount by which a
 reporting unit’s carrying value exceeds its fair value
 limited to the total amount of goodwill allocated to that reporting
 unit. Entities will continue to have the option to perform a
 qualitative assessment to determine if a quantitative impairment
 test is necessary. The Company elected to early adopt
 ASU 2017-04 on a prospective basis during
 the second quarter of 2017, and the adoption did not have a
 material impact on its consolidated condensed financial statements
 and related disclosures.

[0001193125-17-251481:notes:27]
In October 2016, the FASB issued ASU 2016-16, Income Taxes (Topic 740):
 Intra-Entity Transfers of Assets Other Than Inventory. The objective of this
 update is to improve the accounting for the income tax consequences
 of intra-entity transfers of assets other than inventory by
 recognizing the income tax consequences when the transfer occurs.
 This ASU is effective for fiscal years beginning after
 December 15, 2017, including interim periods within those
 fiscal years. Early adoption is permitted. The Company is currently
 evaluating the new guidance to determine the impact it may have on
 its consolidated condensed financial statements.

[0001193125-17-251481:notes:28]
In August 2016, the FASB issued ASU 2016-15, Statement of Cash Flows
 (Topic 230). The objective of this update is to add or clarify
 guidance on the classification of certain cash receipts and
 payments in the statement of cash flows. This ASU is effective for
 fiscal years beginning after December 15, 2017, including
 interim periods within those annual periods and is to be applied
 utilizing a retrospective approach. Early adoption is permitted.
 The Company adopted this ASU 2016-15 in the first quarter of 2017
 and the adoption did not have a material impact on its consolidated
 condensed financial statements and related disclosures.

[0001193125-17-251481:notes:29]
In March 2016, the FASB issued ASU 2016-09, Stock Compensation (Topic
 718): Improvements to Employee Share-Based Payment Accounting.
 The objective of this update is to simplify several aspects of the
 accounting for employee share-based payment transactions, including
 the income tax consequences, classification of awards as either
 equity or liabilities, and classification on the statement of cash
 flows. This ASU is effective for fiscal years beginning after
 December 15, 2016, including interim periods within those
 fiscal years. The Company adopted ASU 2016-09 on January 3, 2017. The
 adoption did not have a material impact on the consolidated
 condensed financial statements and related disclosures.

[0001193125-17-251481:notes:30]
In February 2016, the FASB issued ASU 2016-02, Leases (Topic 842). The
 objective of this update is to increase transparency and
 comparability among organizations by recognizing lease assets and
 lease liabilities on the balance sheet and disclosing key
 information about leasing arrangements. This ASU is effective for
 fiscal years beginning after December 15, 2018, including
 interim periods within those annual periods and is to be applied
 utilizing a modified retrospective approach. The Company is
 currently evaluating the new guidance to determine the impact it
 may have on its consolidated financial statements and related
 disclosures.

[0001193125-17-251481:notes:31]
In May 2014, the FASB issued ASU 2014-09, Revenue from Contracts with
 Customers, as amended, which requires an entity to recognize
 the amount of revenue to which it expects to be entitled for the
 transfer of promised goods or services to customers. The ASU will
 replace most existing revenue recognition guidance in U.S. GAAP
 when it becomes effective. The new standard is effective for the
 Company at the beginning of fiscal year 2018. The standard permits
 the use of either the retrospective or cumulative effect transition
 method. The Company has assessed that the impact of the new
 guidance will result in a change to the timing of revenue
 recognition for the Company’s revenue stream from
 “point in time” upon physical delivery to an
 “over time” model and believes this transition could
 have a material impact on the Company’s consolidated
 financial statements upon adoption. As of July 3, 2017,
 management intends to apply the cumulative effect transition
 method. The Company has identified and is in the process of
 implementing changes to its systems, processes and internal
 controls to meet the standard update’s reporting and
 disclosure requirements.


## us-gaap:ReconciliationOfOperatingProfitLossFromSegmentsToConsolidatedTextBlock

[0001193125-17-251481:notes:32]
The Company accounts for inter-segment sales and transfers
 consistent with the Company’s revenue recognition policy. The
 inter-segment sales for the quarters and two quarters ended
 July 3, 2017 and June 27, 2016, are sales primarily from
 the PCB to the E-M Solutions operating
 segment.

[0001193125-17-251481:notes:33]
|  |  | Quarter Ended |  |  | Two Quarters Ended |  |
|  |  | July 3, 2017 |  |  | June 27, 2016 |  |  | July 3, 2017 |  |  | June 27, 2016 |  |
|  |  | (In thousands) |  |
| Net Sales: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| PCB |  | $ | 576,566 |  |  | $ | 563,574 |  |  | $ | 1,163,261 |  |  | $ | 1,093,519 |  |
| E-M Solutions |  |  | 52,898 |  |  |  | 40,427 |  |  |  | 94,567 |  |  |  | 96,905 |  |
| Total sales |  |  | 629,464 |  |  |  | 604,001 |  |  |  | 1,257,828 |  |  |  | 1,190,424 |  |
| Inter-segment sales |  |  | (2,282 | ) |  |  | (2,154 | ) |  |  | (5,399 | ) |  |  | (5,319 | ) |
| Total net sales |  | $ | 627,182 |  |  | $ | 601,847 |  |  | $ | 1,252,429 |  |  | $ | 1,185,105 |  |
| Operating Segment Income(loss): |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| PCB |  | $ | 69,435 |  |  | $ | 64,970 |  |  | $ | 151,691 |  |  | $ | 114,337 |  |
| E-M Solutions |  |  | 2,689 |  |  |  | (153 | ) |  |  | 1,047 |  |  |  | 234 |  |
| Corporate |  |  | (21,158 | ) |  |  | (24,189 | ) |  |  | (43,290 | ) |  |  | (49,094 | ) |
| Total operating segment income |  |  | 50,966 |  |  |  | 40,628 |  |  |  | 109,448 |  |  |  | 65,477 |  |
| Amortization of definite-lived intangibles |  |  | (5,910 | ) |  |  | (5,949 | ) |  |  | (11,822 | ) |  |  | (11,896 | ) |
| Total operating income |  |  | 45,056 |  |  |  | 34,679 |  |  |  | 97,626 |  |  |  | 53,581 |  |
| Total other expense |  |  | (18,747 | ) |  |  | (16,893 | ) |  |  | (34,053 | ) |  |  | (37,468 | ) |
| Income before income taxes |  | $ | 26,309 |  |  | $ | 17,786 |  |  | $ | 63,573 |  |  | $ | 16,113 |  |


## us-gaap:RestructuringImpairmentAndOtherActivitiesDisclosureTextBlock

[0001193125-17-251481:notes:34]
[same as prior period, unchanged from 0001193125-17-166200:notes:37]

[0001193125-17-251481:notes:35]
[same as prior period, unchanged from 0001193125-17-166200:notes:38]

[0001193125-17-251481:notes:36]
In connection with the Consolidation Plan and other global
 realignment restructuring efforts, the Company recognized employee
 separation, contract termination and other costs during the
 quarters and two quarters ended July 3, 2017 and June 27,
 2016. Contract termination and other costs primarily
 represented plant closure costs for Cleveland, Ohio, Milpitas,
 California and Juarez, Mexico, as well as costs related to building
 operating leases associated with the downsizing of the St. Louis,
 Missouri office.

[0001193125-17-251481:notes:37]
The below table summarizes such restructuring costs by
 operating segment for the quarter and two quarters ended
 July 3, 2017:

[0001193125-17-251481:notes:38]
|  |  | Quarter Ended July 3, 2017 |  |  | Two Quarters Ended July 3, 2017 |  |
|  |  | Employee separation/ severance |  |  | Contract termination and other costs |  |  | Total |  |  | Employee separation/ severance |  |  | Contract termination and other costs |  |  | Total |  |
|  |  | (In thousands) |  |
| Operating Segment: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| PCB |  | $ | 43 |  |  | $ | — |  |  | $ | 43 |  |  | $ | 170 |  |  | $ | 99 |  |  | $ | 269 |  |
| E-M Solutions |  |  | — |  |  |  | 244 |  |  |  | 244 |  |  |  | — |  |  |  | 516 |  |  |  | 516 |  |
| Corporate |  |  | — |  |  |  | 129 |  |  |  | 129 |  |  |  | 33 |  |  |  | 207 |  |  |  | 240 |  |
|  |  | $ | 43 |  |  | $ | 373 |  |  | $ | 416 |  |  | $ | 203 |  |  | $ | 822 |  |  | $ | 1,025 |  |

[0001193125-17-251481:notes:39]
The below table summarizes such restructuring costs by
 operating segment for the quarter and two quarters ended
 June 27, 2016:

[0001193125-17-251481:notes:40]
|  |  | Quarter Ended June 27, 2016 |  |  | Two Quarters Ended June 27, 2016 |  |
|  |  | Employee separation/ severance |  |  | Contract termination and other costs |  |  | Total |  |  | Employee separation/ severance |  |  | Contract termination and other costs |  |  | Total |  |
|  |  | (In thousands) |  |
| Operating Segment: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| PCB |  | $ | 668 |  |  | $ | 488 |  |  | $ | 1,156 |  |  | $ | 1,267 |  |  | $ | 1,100 |  |  | $ | 2,367 |  |
| E-M Solutions |  |  | 578 |  |  |  | 1,425 |  |  |  | 2,003 |  |  |  | 734 |  |  |  | 1,944 |  |  |  | 2,678 |  |
| Corporate |  |  | 40 |  |  |  | 790 |  |  |  | 830 |  |  |  | 9 |  |  |  | 848 |  |  |  | 857 |  |
|  |  | $ | 1,286 |  |  | $ | 2,703 |  |  | $ | 3,989 |  |  | $ | 2,010 |  |  | $ | 3,892 |  |  | $ | 5,902 |  |

[0001193125-17-251481:notes:41]
The below table shows the utilization of the accrued
 restructuring costs during the two quarters ended July 3,
 2017:

[0001193125-17-251481:notes:42]
|  |  | Employee separation/ severance |  |  | Contract termination and other Costs |  |  | Total |  |
|  |  | (In thousands) |  |
| Accrued at January 2, 2017 |  | $ | 124 |  |  | $ | 1,042 |  |  | $ | 1,166 |  |
| Charged to expense |  |  | 203 |  |  |  | 822 |  |  |  | 1,025 |  |
| Amount paid |  |  | (327 | ) |  | $ | (1,287 | ) |  |  | (1,614 | ) |
| Accrued at July 3, 2017 |  | $ | — |  |  | $ | 577 |  |  | $ | 577 |  |

[0001193125-17-251481:notes:43]
As of July 3, 2017, the Company has incurred approximately
 $17,357 of restructuring charges since the September 29, 2015
 announcement. The Company estimates that it will incur total
 charges related to the Consolidation Plan of approximately
 $20,000.

[0001193125-17-251481:notes:44]
The Company recognized $3,346 in impairment charges during the
 two quarters ended June 27, 2016. As a result of the above
 mentioned plant closures and other plant realignment efforts,
 $1,393 of impairment charges were recognized in the consolidated
 condensed statement of operations related to machinery and
 equipment in the PCB operating segment. In addition, $1,953 of
 impairment charges were recognized in the consolidated condensed
 statement of operations related to capitalized software costs in
 the Corporate operating segment.


## us-gaap:ScheduleOfAccumulatedOtherComprehensiveIncomeLossTableTextBlock

[0001193125-17-251481:notes:45]
The following provides a summary of the components of
 accumulated other comprehensive income (loss) as of July 3,
 2017 and January 2, 2017:

[0001193125-17-251481:notes:46]
|  |  | Foreign Currency Translation |  |  | Gains (Losses) on Cash Flow Hedges |  |  | Total |  |
|  |  | (In thousands) |  |
| Ending balance at January 2, 2017 |  | $ | (43,149 | ) |  | $ | (1,180 | ) |  | $ | (44,329 | ) |
| Other comprehensive income before reclassifications |  |  | 18,638 |  |  |  | 164 |  |  |  | 18,802 |  |
| Amounts reclassified from accumulated other comprehensive income |  |  | — |  |  |  | 87 |  |  |  | 87 |  |
| Other comprehensive income |  |  | 18,638 |  |  |  | 251 |  |  |  | 18,889 |  |
| Ending balance at July 3, 2017 |  | $ | (24,511 | ) |  | $ | (929 | ) |  | $ | (25,440 | ) |


## us-gaap:ScheduleOfDebtInstrumentsTextBlock

[0001193125-17-251481:notes:47]
The following table summarizes the long-term debt of the
 Company as of July 3, 2017 and January 2,
 2017:

[0001193125-17-251481:notes:48]
|  |  | Average Effective Interest Rate as of July 3, 2017 |  |  | July 3, 2017 |  |  | Average Effective Interest Rate as of January 2, 2017 |  |  | January 2, 2017 |  |
|  |  | (In thousands) |  |
| Term loan due May 2021 |  |  | 5.48% |  |  | $ | 650,000 |  |  |  | 5.25% |  |  | $ | 700,000 |  |
| U.S. ABL revolving loan due May 2020 |  |  | 2.73% |  |  |  | 80,000 |  |  |  | 2.27% |  |  |  | 80,000 |  |
| Asia ABL revolving loan due May 2020 |  |  | 2.63% |  |  |  | 30,000 |  |  |  | 2.17% |  |  |  | 30,000 |  |
| Convertible Senior Notes due December 2020 |  |  | 1.75% |  |  |  | 249,985 |  |  |  | 1.75% |  |  |  | 250,000 |  |
| Capital lease |  |  | 6.43% |  |  |  | 1,844 |  |  |  | 6.43% |  |  |  | 1,798 |  |
|  |  |  |  |  |  |  | 1,011,829 |  |  |  |  |  |  |  | 1,061,798 |  |
| Less: Long-term debt unamortized discount |  |  |  |  |  |  | (33,174 | ) |  |  |  |  |  |  | (37,392 | ) |
| Long-term debt unamortized debt issuance costs |  |  |  |  |  |  | (4,139 | ) |  |  |  |  |  |  | (4,724 | ) |
|  |  |  |  |  |  |  | 974,516 |  |  |  |  |  |  |  | 1,019,682 |  |
| Less: current maturities |  |  |  |  |  |  | (110,669 | ) |  |  |  |  |  |  | (110,652 | ) |
| Long-term debt, less current maturities |  |  |  |  |  | $ | 863,847 |  |  |  |  |  |  | $ | 909,030 |  |


## us-gaap:IncomeTaxDisclosureTextBlock

[0001193125-17-251481:notes:49]
[same as prior period, unchanged from 0001193125-17-166200:notes:50]

[0001193125-17-251481:notes:50]
The Company’s effective tax rate will generally differ
 from the U.S. federal statutory rate of 35% due to favorable tax
 rates associated with earnings from the Company’s operations
 in lower-tax jurisdictions such as China,
 the apportioned state income tax rates, generation of other credits
 and deductions available to the Company, changes in valuation
 allowances, and certain non-deductible items.

[0001193125-17-251481:notes:51]
During the quarter and two quarters ended July 3, 2017,
 the Company’s effective tax rate was impacted by a net
 discrete benefit of $2,107 and $4,647, respectively, related to
 (i) a tax incentive, (ii) release of uncertain tax
 positions due to the expiration of the statute of limitations in
 foreign jurisdictions, and (iii) accrued interest expense on
 existing uncertain tax positions. Additionally, no tax benefit was
 recorded on the losses incurred in the U.S. and certain foreign
 jurisdictions as a result of corresponding increases in the
 valuation allowances in these jurisdictions. The Company’s
 foreign earnings will be indefinitely reinvested outside of the
 U.S. Therefore, no deferred tax liabilities for U.S. income taxes
 on undistributed earnings have been recorded, but deferred tax
 liabilities have been recorded for certain subsidiaries in China to
 provide for distributions up to the ultimate, foreign holding
 company.

[0001193125-17-251481:notes:52]
Certain entities in China operated under tax incentives
 effective through 2017. For the quarter ended July 3, 2017,
 the tax incentives decreased Chinese taxes by $481, which did not
 have any impact on basic or dilutive earnings per share for the
 quarter ended July 3, 2017. For the two quarters ended
 July 3, 2017, the tax incentives decreased Chinese taxes by
 $5,962, which increased basic earnings per share by $0.06 and
 dilutive earnings per share by $0.05 for the two quarters ended
 July 3, 2017.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0001193125-17-251481:notes:53]
(1) Nature
 of Operations and Basis of Presentation

[0001193125-17-251481:notes:54]
TTM Technologies, Inc. (the Company or TTM) is a leading global
 printed circuit board (PCB) manufacturer, focusing on quick-turn
 and volume production of technologically complex PCBs and
 electro-mechanical solutions (E-M Solutions). The Company
 provides time-to-market and advanced technology
 products and offers a one-stop manufacturing solution to
 customers from engineering support to prototype development through
 final mass production. This one-stop manufacturing solution allows
 the Company to align technology developments with the diverse needs
 of the Company’s customers and to enable them to reduce the
 time required to develop new products and bring them to
 market.

[0001193125-17-251481:notes:55]
The Company serves a diversified customer base in various
 markets throughout the world, including networking/communications
 infrastructure products, smartphones and touchscreen tablets, as
 well as aerospace and defense, automotive, high-end computing, and medical,
 industrial and instrumentation related products. The
 Company’s customers include both original equipment
 manufacturers (OEMs) and electronic manufacturing services (EMS)
 providers.

[0001193125-17-251481:notes:56]
The accompanying consolidated condensed financial statements
 have been prepared by the Company, without audit, pursuant to the
 rules and regulations of the Securities and Exchange Commission
 (SEC). Certain information and disclosures normally included in
 financial statements prepared in accordance with accounting
 principles generally accepted in the United States of America (U.S.
 GAAP) have been condensed or omitted pursuant to such rules and
 regulations. These consolidated condensed financial statements
 reflect all adjustments (consisting only of normal recurring
 adjustments) which, in the opinion of management, are necessary to
 present fairly the financial position, the results of operations
 and cash flows of the Company for the periods presented. It is
 suggested that these consolidated condensed financial statements be
 read in conjunction with the consolidated financial statements and
 the notes thereto included in the Company’s most recent
 Annual Report on Form 10-K. The results of operations for
 the interim periods are not necessarily indicative of the results
 to be expected for the full year. The preparation of financial
 statements in accordance with U.S. GAAP requires management to make
 estimates and assumptions that affect the amounts reported in the
 Company’s consolidated condensed financial statements and
 accompanying notes. Actual results could differ materially from
 those estimates. The Company uses a 13-week fiscal quarter accounting
 period with the fourth quarter ending on the Monday nearest
 December 31.


## us-gaap:ScheduleOfEarningsPerShareBasicAndDilutedTableTextBlock

[0001193125-17-251481:notes:57]
The following is a reconciliation of the numerator and
 denominator used to calculate basic earnings per share and diluted
 earnings per share for the quarters and two quarters ended
 July 3, 2017 and June 27, 2016:

[0001193125-17-251481:notes:58]
|  |  | Quarter Ended |  |  | Two Quarters Ended |  |
|  |  | July 3, 2017 |  |  | June 27, 2016 |  |  | July 3, 2017 |  |  | June 27, 2016 |  |
|  |  | (In thousands, except per share amounts) |  |
| Basic earnings: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic earning |  | $ | 20,591 |  |  | $ | 18,548 |  |  | $ | 53,550 |  |  | $ | 11,284 |  |
| Diluted earnings: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Net income attributable to TTM Technologies, Inc. stockholders |  | $ | 20,591 |  |  | $ | 18,548 |  |  | $ | 53,550 |  |  | $ | 11,284 |  |
| Interest expense from convertible senior notes, net of tax |  |  | 3,432 |  |  |  | 3,285 |  |  |  | 6,826 |  |  |  | — |  |
| Diluted earnings |  | $ | 24,023 |  |  | $ | 21,833 |  |  | $ | 60,376 |  |  | $ | 11,284 |  |
| Basic shares |  |  | 101,756 |  |  |  | 100,170 |  |  |  | 101,344 |  |  |  | 99,883 |  |
| Dilutive effect of performance-based stock units, restricted stock units and stock options |  |  | 1,604 |  |  |  | 840 |  |  |  | 1,735 |  |  |  | 907 |  |
| Dilutive effect of outstanding warrants |  |  | 3,924 |  |  |  | — |  |  |  | 3,054 |  |  |  | — |  |
| Dilutive effect of assumed conversion of convertible senior notes outstanding |  |  | 25,940 |  |  |  | 25,940 |  |  |  | 25,940 |  |  |  | — |  |
| Diluted shares |  |  | 133,224 |  |  |  | 126,950 |  |  |  | 132,073 |  |  |  | 100,790 |  |
| Income per share attributable to TTM Technologies, Inc. stockholders: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  | $ | 0.20 |  |  | $ | 0.19 |  |  | $ | 0.53 |  |  | $ | 0.11 |  |
| Diluted |  | $ | 0.18 |  |  | $ | 0.17 |  |  | $ | 0.46 |  |  | $ | 0.11 |  |


## us-gaap:ScheduleofFiniteLivedIntangibleAssetsFutureAmortizationExpenseTableTextBlock

[0001193125-17-251481:notes:59]
[same as prior period, unchanged from 0001193125-17-166200:notes:60]

[0001193125-17-251481:notes:60]
|  |  | (In thousands) |  |
| Remaining 2017 |  | $ | 11,823 |  |
| 2018 |  |  | 22,841 |  |
| 2019 |  |  | 18,746 |  |
| 2020 |  |  | 18,746 |  |
| 2021 |  |  | 18,746 |  |
| Thereafter |  |  | 23,848 |  |
|  |  | $ | 114,750 |  |


## us-gaap:ScheduleOfGoodwillTextBlock

[0001193125-17-251481:notes:61]
As of July 3, 2017 and January 2, 2017, goodwill was
 as follows:

[0001193125-17-251481:notes:62]
|  |  | Total |  |
|  |  | (In thousands) |  |
| Balance as of January 2, 2017 |  | $ | 372,609 |  |
| Foreign currency translation adjustment and other |  |  | (80 | ) |
| Balance as of July 3, 2017 |  | $ | 372,529 |  |


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0001193125-17-251481:notes:63]
(8)
 Accumulated Other Comprehensive Income (Loss)

[0001193125-17-251481:notes:64]
For the quarter and two quarters ended July 3, 2017, $43
 and $87 net of tax, respectively, were reclassified out of
 accumulated other comprehensive income (loss) to depreciation
 expense related to cash flow hedges. For the quarter and two
 quarters ended June 27, 2016, $39 and $81 net of tax,
 respectively, were reclassified out of accumulated other
 comprehensive income (loss) to depreciation expense related to cash
 flow hedges.


## us-gaap:FairValueAssetsMeasuredOnNonrecurringBasisTextBlock

[0001193125-17-251481:notes:65]
For the two quarters ended June 27, 2016, the following
 assets were measured at fair value on a nonrecurring basis using
 the type of inputs shown:

[0001193125-17-251481:notes:66]
|  |  |  |  |  | Fair Value Measurements Using: |  |
|  |  | June 27, 2016 |  |  | Level 1 Inputs |  |  | Level 2 Inputs |  |  | Level 3 Inputs |  |  | Total Losses for the two Quarters Ended June 27, 2016 |  |
|  |  | (In thousands) |  |
| Assets held for sale |  | $ | 155 |  |  | $ | — |  |  | $ | 155 |  |  | $ | — |  |  | $ | 1,393 |  |
| Long-lived assets held and use |  |  | 2,254 |  |  |  | — |  |  |  | — |  |  |  | 2,254 |  |  |  | 1,953 |  |
|  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | $ | 3,346 |  |


## us-gaap:IntangibleAssetsDisclosureTextBlock

[0001193125-17-251481:notes:67]
(5)
 Definite-lived Intangibles

[0001193125-17-251481:notes:68]
As of July 3, 2017 and January 2, 2017, the
 components of definite-lived intangibles were as
 follows:

[0001193125-17-251481:notes:69]
|  |  | Gross Amount |  |  | Accumulated Amortization |  |  | Foreign Currency Translation Adjustment |  |  | Net Carrying Amount |  |  | Weighted Average Amortization Period |  |
|  |  | (In thousands) |  |  | (years) |  |
| July 3, 2017: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Customer relationships |  | $ | 203,563 |  |  | $ | (89,777 | ) |  | $ | 60 |  |  | $ | 113,846 |  |  |  | 8.1 |  |
| Technology |  |  | 3,000 |  |  |  | (2,096 | ) |  |  | — |  |  |  | 904 |  |  |  | 3.0 |  |
|  |  | $ | 206,563 |  |  | $ | (91,873 | ) |  | $ | 60 |  |  | $ | 114,750 |  |  |  |  |  |
| January 2, 2017: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Customer relationships |  | $ | 203,563 |  |  | $ | (78,473 | ) |  | $ | 119 |  |  | $ | 125,209 |  |  |  | 8.1 |  |
| Technology |  |  | 3,000 |  |  |  | (1,596 | ) |  |  | — |  |  |  | 1,404 |  |  |  | 3.0 |  |
|  |  | $ | 206,563 |  |  | $ | (80,069 | ) |  | $ | 119 |  |  | $ | 126,613 |  |  |  |  |  |

[0001193125-17-251481:notes:70]
The July 3, 2017 and January 2, 2017 definite-lived
 intangible balances include foreign currency translation
 adjustments related to foreign subsidiaries with functional
 currencies other than the U.S. dollar.

[0001193125-17-251481:notes:71]
Definite-lived intangibles are generally amortized using the
 straight line method of amortization over the useful life, with the
 exception of certain customer relationship intangibles, which are
 amortized using an accelerated method of amortization based on
 estimated cash flows. Amortization expense was $5,910 and $5,949
 for the quarters ended July 3, 2017 and June 27, 2016,
 respectively, and $11,822 and $11,896 for the two quarters ended
 July 3, 2017 and June 27, 2016, respectively.


## us-gaap:ConcentrationRiskDisclosureTextBlock

[0001193125-17-251481:notes:72]
(9)
 Significant Customers and Concentration of Credit
 Risk

[0001193125-17-251481:notes:73]
In the normal course of business, the Company extends credit to
 its customers. Most customers to which the Company extends credit
 are located outside the United States. The Company performs ongoing
 credit evaluations of customers, does not require collateral, and
 considers the credit risk profile of the entity from which the
 receivable is due in further evaluating collection risk.

[0001193125-17-251481:notes:74]
The Company’s customers include both OEMs and EMS
 companies. The Company’s OEM customers often direct a
 significant portion of their purchases through EMS companies. While
 the Company’s customers include both OEM and EMS providers,
 the Company measures customer concentration based on OEM companies,
 as they are the ultimate end customers.

[0001193125-17-251481:notes:75]
For both the quarters and two quarters ended July 3, 2017
 and June 27, 2016, one customer accounted for approximately
 16% and 10%, respectively, of the Company’s net sales. There
 were no other customers that accounted for 10% or more of net sales
 for the quarters or two quarters ended July 3, 2017 and
 June 27, 2016.


## us-gaap:EarningsPerShareTextBlock

[0001193125-17-251481:notes:76]
[same as prior period, unchanged from 0001193125-17-166200:notes:77]

[0001193125-17-251481:notes:77]
Performance-based restricted stock units (PRUs), restricted
 stock units (RSUs) and stock options to purchase 15 and 347 shares
 of common stock for the quarter ended July 3, 2017 and
 June 27, 2016, respectively, and 97 and 1,644 for the two
 quarters ended July 3, 2017 and June 27, 2016,
 respectively, were not considered in calculating diluted earnings
 per share because the options’ exercise prices or the total
 expected proceeds under the treasury stock method for PRUs, RSUs or
 stock options was greater than the average market price of common
 shares during the applicable quarter and, therefore, the effect
 would be anti-dilutive.

[0001193125-17-251481:notes:78]
For the two quarters ended June 27, 2016, the effect of
 shares of common stock related to the Company’s convertible
 senior notes, based on the if-converted method,
 were not included in the computation of dilutive earnings per share
 as the impact would be anti-dilutive.

[0001193125-17-251481:notes:79]
For both the quarter and two quarters ended June 27, 2016,
 outstanding warrants to purchase 25,940 shares were not included in
 the computation of dilutive earnings per share because the strike
 price of the warrants to purchase the Company’s common stock
 were greater than the average market price of common shares during
 the applicable quarter and two quarters, and therefore, the effect
 would be anti-dilutive.


## us-gaap:FairValueDisclosuresTextBlock

[0001193125-17-251481:notes:80]
(10) Fair
 Value Measures

[0001193125-17-251481:notes:81]
The Company measures at fair value its financial
 and non-financial assets
 by using a fair value hierarchy that prioritizes the inputs to
 valuation techniques used to measure fair value. Fair value is the
 price that would be received to sell an asset or paid to transfer a
 liability in an orderly transaction between market participants at
 the measurement date, essentially an exit price, based on the
 highest and best use of the asset or liability.

[0001193125-17-251481:notes:82]
The carrying amount and estimated fair value of the
 Company’s financial instruments at July 3, 2017 and
 January 2, 2017 were as follows:

[0001193125-17-251481:notes:83]
|  |  | July 3, 2017 |  |  | January 2, 2017 |  |
|  |  | Carrying Amount |  |  | Fair Value |  |  | Carrying Amount |  |  | Fair Value |  |
|  |  | (In thousands) |  |
| Term and Revolving Loans |  | $ | 759,185 |  |  | $ | 764,875 |  |  | $ | 809,023 |  |  | $ | 818,750 |  |
| Convertible senior notes due 2020 |  |  | 213,487 |  |  |  | 470,972 |  |  |  | 208,861 |  |  |  | 380,875 |  |
| Capital lease |  |  | 1,844 |  |  |  | 1,844 |  |  |  | 1,798 |  |  |  | 1,798 |  |

[0001193125-17-251481:notes:84]
The fair value of the long-term debt was estimated based on
 quoted market prices or discounting the debt over its life using
 current market rates for similar debt as of July 3, 2017 and
 January 2, 2017, which are considered Level 1 and
 Level 2 inputs.

[0001193125-17-251481:notes:85]
[same as prior period, unchanged from 0001193125-17-166200:notes:87]

[0001193125-17-251481:notes:86]
As of July 3, 2017 and January 2, 2017, the
 Company’s other financial instruments also included cash and
 cash equivalents, accounts receivable, accounts payable and
 equipment payables. Due to short-term maturities, the carrying
 amount of these instruments approximates fair value. Our cash and
 cash equivalents at July 3, 2017 consisted of $75,544 held in
 the U.S., with the remaining $171,403 held by foreign
 subsidiaries.

[0001193125-17-251481:notes:87]
The majority of the
 Company’s non-financial assets
 and liabilities, which include goodwill, intangible assets,
 inventories, and property, plant and equipment, are not required to
 be carried at fair value on a recurring basis. However, if certain
 triggering events occur (or are tested at least annually in the
 case of goodwill) such that a non-financialinstrument is required to
 be evaluated for impairment, based upon a comparison of
 the non-financial instrument’s
 fair value to its carrying value, an impairment is recorded to
 reduce the carrying value to the fair value, if the carrying value
 exceeds the fair value.

[0001193125-17-251481:notes:88]
There was no impairment of long-lived assets recognized for the
 quarter ended June 27, 2016 or for the quarter and two
 quarters ended July 3, 2017.

[0001193125-17-251481:notes:89]
[same as prior period, unchanged from 0001193125-17-166200:notes:91]

[0001193125-17-251481:notes:90]
Additionally, the Company had capitalized software costs in
 accordance with U.S. GAAP. During the two quarters ended
 June 27, 2016 , the Company determined that certain
 capitalized costs no longer had benefit. Because the primary
 determination of fair value was based on management’s
 assumptions and estimates of capitalized costs to dispose, the
 resulting fair value is considered a Level 3 input.


## us-gaap:GoodwillDisclosureTextBlock

[0001193125-17-251481:notes:91]
[same as prior period, unchanged from 0001193125-17-166200:notes:93]

[0001193125-17-251481:notes:92]
All goodwill relates to the Company’s PCB reportable
 segment.

[0001193125-17-251481:notes:93]
Goodwill balances include foreign currency translation
 adjustments related to foreign subsidiaries with functional
 currencies other than the U.S. dollar.


## us-gaap:LongTermDebtTextBlock

[0001193125-17-251481:notes:94]
(6)
 Long-term Debt and Letters of Credit

[0001193125-17-251481:notes:95]
Term
 and Revolving Loans

[0001193125-17-251481:notes:96]
The Company maintains a Term Loan Credit Agreement (Term Loan),
 a $200,000 U.S. Asset-Based Lending Credit Agreement (U.S. ABL),
 and a $150,000 Asia Asset-Based Lending Credit Agreement (Asia ABL)
 (collectively the ABL Revolving Loans).

[0001193125-17-251481:notes:97]
The Term Loan bears interest at a floating rate of LIBOR, with
 a 1.0% LIBOR floor, plus an applicable interest margin of 4.25%, or
 JP Morgan Chase Bank’s prime rate, with a 2% floor, plus a
 margin of 3.25%, at the Company’s option. At July 3,
 2017 the weighted average interest rate on the outstanding
 borrowings under the Term Loan was 5.48%. There is no provision,
 other than an event of default, for the interest margin to
 increase. The Term Loan will mature on May 31, 2021. The Term
 Loan is secured by a significant amount of the assets of the
 Company and a pledge of 65% of voting stock of the Company’s
 first tier foreign subsidiaries and is structurally senior to the
 Company’s convertible senior notes. See Convertible Senior
 Notes below.

[0001193125-17-251481:notes:98]
The U.S. ABL consists of three tranches comprised of a
 revolving credit facility of up to $200,000, a letter of credit
 facility of up to $50,000, and swingline loans of up to $30,000,
 provided that at no time may amounts outstanding under the tranches
 exceed in aggregate $200,000 or the applicable borrowing base,
 which is a percentage of the principal amount of Eligible Accounts,
 as defined in the U.S. ABL agreement. Borrowings under the U.S. ABL
 bear interest at either a floating rate of LIBOR plus a margin of
 150 basis points or JP Morgan Chase Bank’s prime rate plus a
 margin of 50 basis points, at the Company’s option. At
 July 3, 2017, the weighted average interest rate on the
 outstanding borrowings under the U.S. ABL was 2.73%. The applicable
 margin can vary based on the remaining availability of the
 facility, from 125 to 175 basis points for LIBOR-based loans and
 from 25 to 75 basis points for JP Morgan Chase Bank’s prime
 rate-based loans. Other than availability and an event of default,
 there are no other provisions for the interest margin to increase.
 The U.S. ABL will mature on May 31, 2020. Loans made under the
 U.S. ABL are secured first by all of the Company’s domestic
 cash, receivables and inventories as well as by a second position
 against a significant amount of the assets of the Company and a
 pledge of 65% of voting stock of the Company’s first tier
 foreign subsidiaries and are structurally senior to the
 Company’s convertible senior notes. See Convertible Senior
 Notes below. At July 3, 2017, $80,000 of the U.S. ABL was
 outstanding and classified as short-term debt. The Company and its
 domestic subsidiaries have fully and unconditionally guaranteed the
 full and timely payment of all Term Loan and U.S. ABL related
 obligations.

[0001193125-17-251481:notes:99]
The Asia ABL consists of two tranches comprised of a revolving
 credit facility of up to $150,000 and a letter of credit facility
 of up to $100,000, provided that at no time may amounts outstanding
 under both tranches exceed in aggregate $150,000 or the applicable
 borrowing base, which is a percentage of the principal amount of
 Eligible Accounts, as defined in the Asia ABL agreement. Borrowings
 under the Asia ABL bear interest at a floating rate of LIBOR plus
 140 basis points. At July 3, 2017, the weighted average
 interest rate on the outstanding borrowings under the Asia ABL was
 2.63%. There is no provision, other than an event of default, for
 the interest margin to increase. The Asia ABL will mature on
 May 22, 2020. Loans made under the Asia ABL are secured by a
 portion of the Company’s Asia Pacific cash and receivables
 and are structurally senior to the Company’s domestic
 obligations, including the convertible senior notes. See
 Convertible Senior Notes below. The Company’s Asia Pacific
 subsidiary and certain of its subsidiaries have fully and
 unconditionally guaranteed the full and timely payment of all Asia
 ABL related obligations. At July 3, 2017, $30,000 of the Asia
 ABL was outstanding.

[0001193125-17-251481:notes:100]
The Company is no longer required to make any quarterly
 scheduled payments for the remaining term of the outstanding Term
 Loan balance due to mandatory payments and optional loan
 prepayments applied to date. Additionally, based on certain
 parameters defined in the Term Loan agreement, including a secured
 leverage ratio, the Company is also not required to make any
 additional principal payments for fiscal year 2017 as our secured
 leverage ratio is less than or equal to 1.5. The Company may be
 required to make additional principal payments in future years, if
 the Company’s secured leverage ratio is greater than 1.5. Any
 remaining outstanding balances under the Term Loan are due at the
 maturity date of May 31, 2021. During the quarter ended
 July 3, 2017, the Company made an optional debt principal
 prepayment totaling $50,000. Borrowings under the Term Loan are
 subject to financial and operating covenants including maintaining
 a maximum total leverage ratio. Under the occurrence of certain
 events, the U.S. ABL and the Asia ABL are subject to financial and
 operational covenants, including maintaining minimum fixed charge
 coverage ratios. At July 3, 2017, the Company was in
 compliance with the covenants under the Term Loan, the U.S. ABL and
 the Asia ABL.

[0001193125-17-251481:notes:101]
As of July 3, 2017 and January 2, 2017, remaining
 unamortized debt issuance costs of $815 and $977, respectively,
 related to the Term Loan. These debt issuance costs are recorded as
 a reduction of the Term Loan at July 3, 2017 and
 January 2, 2017, respectively, and are amortized over the
 duration of the Term Loan into interest expense using an effective
 interest rate of 5.48%.

[0001193125-17-251481:notes:102]
Additionally, remaining unamortized debt issuance costs related
 to the ABL Revolving Loans were $2,922 and $3,423 as of
 July 3, 2017 and January 2, 2017, respectively. These
 debt issuance costs are included in
 other non-current assets
 and are amortized to interest expense over the duration of the ABL
 Revolving Loans using the straight line method of amortization. At
 July 3, 2017, the remaining weighted average amortization
 period for the unamortized debt issuance costs for both the Term
 Loan and the ABL Revolving Loans was 3.1 years.

[0001193125-17-251481:notes:103]
The Company is required to pay a commitment fee of 0.25% to
 0.375% per annum on any unused portion of the U.S. ABL or Asia
 ABL. The Company incurred total commitment fees related to unused
 borrowing availability of $180 and $150 for the quarters ended
 July 3, 2017 and June 27, 2016, respectively, and $367
 and $344 for the two quarters ended July 3, 2017 and
 June 27, 2016, respectively. As of July 3, 2017, the
 outstanding amount of the Term Loan was $650,000 which is included
 as long-term debt. Additionally, $80,000 of the U.S. ABL and
 $30,000 of the Asia ABL was outstanding as of July 3, 2017.
 Available borrowing capacity under the U.S. ABL and Asia ABL was
 $112,388 and $78,310, which considers letters of credit outstanding
 of $7,612 and $41,690 mentioned below, respectively, at
 July 3, 2017.

[0001193125-17-251481:notes:104]
Letters
 of Credit

[0001193125-17-251481:notes:105]
The Company has up to $50,000 and $100,000 Letters of Credit
 Facilities under the U.S. ABL and the Asia ABL, respectively, as
 mentioned above. As of July 3, 2017, letters of credit in the
 amount of $7,612 were outstanding under the U.S. ABL and $41,690
 were outstanding under the Asia ABL with various expiration dates
 through September 2018.

[0001193125-17-251481:notes:106]
Convertible Senior Notes due 2020

[0001193125-17-251481:notes:107]
The Company maintains 1.75% convertible senior notes in the
 amount of $249,985 due December 15, 2020. The convertible
 senior notes bear interest at a rate of 1.75% per annum.
 Interest is payable semiannually in arrears on June 15 and
 December 15 of each year. The convertible senior notes are
 senior unsecured obligations and rank equally to the
 Company’s future unsecured senior indebtedness and are senior
 in right of payment to any of the Company’s future
 subordinated indebtedness.

[0001193125-17-251481:notes:108]
Conversion: At any time prior
 to March 15, 2020, holders may convert their convertible
 senior notes into cash and, if applicable, into shares of the
 Company’s common stock based on a conversion rate of 103.7613
 shares of the Company’s common stock per $1 principal amount
 of convertible senior notes, subject to adjustment, under the
 following circumstances: (1) during any calendar quarter
 beginning after March 31, 2015 (and only during such calendar
 quarter), if the last reported sale price of our common stock for
 at least 20 trading days during the 30 consecutive trading days
 ending on the last trading day of the immediately preceding
 calendar quarter is greater than or equal to 130% of the applicable
 conversion price on each applicable trading day of such preceding
 calendar quarter; (2) during the five business day period
 after any 10 consecutive trading day period in which the trading
 price per note for each day of that 10 consecutive trading day
 period was less than 98% of the product of the last reported sale
 price of the Company’s common stock and the conversion rate
 on such day; or (3) upon the occurrence of specified corporate
 transactions described in the indenture governing the notes. As of
 July 3, 2017, the conversion criteria had been met under
 condition (1) as described above, allowing holders to give
 notice of conversion in both the second and third quarter of
 2017.

[0001193125-17-251481:notes:109]
On or after March 15, 2020 until the close of business on
 the third scheduled trading day preceding the maturity date,
 holders may convert their notes at any time, regardless of the
 foregoing circumstances. Upon conversion, for each $1 principal
 amount of notes, the Company will pay shares of our common stock,
 cash or a combination of cash and shares of our common stock at its
 election, if applicable, based on a daily conversion value
 calculated on a proportionate basis for each day of the 80 trading
 day observation period. All conversions occurring on the same date
 or on or after March 15, 2020 shall be settled using the same
 settlement method. Additionally, in the event of a fundamental
 change as defined in the indenture governing the notes, or other
 conversion rate adjustments such as share splits or combinations,
 other distributions of shares, cash or other assets to
 stockholders, including self-tender transactions (Other Conversion
 Rate Adjustments), the conversion rate may be modified to adjust
 the number of shares per $1 principal amount of the notes. As of
 July 3, 2017, none of the criteria for a fundamental change or
 a conversion rate adjustment had been met.

[0001193125-17-251481:notes:110]
The maximum number of shares issuable upon conversion,
 including the effect of a fundamental change and subject to Other
 Conversion Rate Adjustments, would be 32,423.

[0001193125-17-251481:notes:111]
Note Repurchase: The Company is
 not permitted to redeem the convertible senior notes at any time
 prior to maturity. In the event of a fundamental change or certain
 default events, as defined in the indenture governing the notes,
 holders may require the Company to repurchase for cash all or a
 portion of their convertible senior notes at a price equal to 100%
 of the principal amount, plus any accrued and unpaid
 interest.

[0001193125-17-251481:notes:112]
Convertible Note Hedge and Warrant
 Transaction: In connection with the
 issuance of the convertible senior notes due 2020, the Company
 entered into a convertible note hedge and warrant transaction (Call
 Spread Transaction), with respect to the Company’s common
 stock. The convertible note hedge consists of the Company’s
 option to purchase up to 25,939 common stock shares at a price of
 $9.64 per share. The hedge expires on December 15, 2020 and
 can only be executed upon the conversion of the above mentioned
 convertible senior notes due 2020. Additionally, the Company sold
 warrants to purchase 25,940 shares of its common stock at a price
 of $14.26 per share. The warrants expire ratably from March 2021
 through January 2022. The 2020 Call Spread Transaction has no
 effect on the terms of the convertible senior notes due 2020 and
 reduces potential dilution by effectively increasing the conversion
 price of the convertible senior notes due 2020 to $14.26 per share
 of the Company’s common stock.

[0001193125-17-251481:notes:113]
The components of interest expense resulting from the
 convertible senior notes for the quarters and two quarters ended
 July 3, 2017 and June 27, 2016 are as follows:

[0001193125-17-251481:notes:114]
|  |  | For the Quarter Ended |  |  | For the Two Quarters Ended |  |
|  |  | July 3, 2017 |  |  | June 27, 2016 |  |  | July 3, 2017 |  |  | June 27, 2016 |  |
|  |  | (In thousands) |  |
| Contractual coupon interest |  | $ | 1,093 |  |  | $ | 1,093 |  |  | $ | 2,187 |  |  | $ | 2,187 |  |
| Amortization of debt discount |  | $ | 2,125 |  |  | $ | 1,992 |  |  | $ | 4,216 |  |  | $ | 3,952 |  |
| Amortization of debt issuance costs |  | $ | 214 |  |  | $ | 200 |  |  | $ | 423 |  |  | $ | 396 |  |

[0001193125-17-251481:notes:115]
As of July 3, 2017 and January 2, 2017, there remains
 unamortized debt discount of $33,174 and $37,392, respectively, and
 debt issuance costs of $3,324 and $3,747, respectively, related to
 the convertible senior notes. These debt discount and debt discount
 issuance costs are recorded as a reduction of the convertible
 senior notes and are being amortized to interest expense over the
 term of the convertible senior notes using the effective interest
 rate method. At July 3, 2017, the remaining weighted average
 amortization period for the unamortized senior convertible note
 discount and debt issuance costs was 3.5 years.

[0001193125-17-251481:notes:116]
For the quarters and two quarters ended July 3, 2017 and
 June 27, 2016, the amortization of the convertible senior
 notes due 2020 debt discount and debt issuance costs is based on an
 effective interest rate of 6.48%.

[0001193125-17-251481:notes:117]
Other
 Credit Facility

[0001193125-17-251481:notes:118]
Additionally, the Company is party to a revolving loan credit
 facility (Chinese Revolver) with a lender in China. Under this
 arrangement, the lender has made available to the Company
 approximately $31,000 in unsecured borrowing with all terms of the
 borrowing to be negotiated at the time the Chinese Revolver is
 drawn upon. There are no commitment fees on the unused portion of
 the Chinese Revolver, and this arrangement expires in January 2018.
 As of July 3, 2017, the Chinese Revolver had not been drawn
 upon.


## us-gaap:RelatedPartyTransactionsDisclosureTextBlock

[0001193125-17-251481:notes:119]
(15)
 Related Party Transactions

[0001193125-17-251481:notes:120]
In the normal course of
 business, the Company’s foreign subsidiaries purchase
 laminate and prepreg from related parties in which a significant
 shareholder of the Company holds an equity interest. The Company
 purchased laminate and prepreg from these related parties in the
 amount of $12,121 and $14,259 for the quarters ended July 3,
 2017 and June 27, 2016, respectively, and $25,611 and $30,257
 for the two quarters ended July 3, 2017 and June 27,
 2016, respectively.

[0001193125-17-251481:notes:121]
The Company also sells
 PCBs to a related party which is a wholly owned subsidiary of an
 entity in which a significant shareholder of the Company holds an
 equity interest. Sales to this related party for the quarters ended
 July 3, 2017 and June 27, 2016 were $17 and $298,
 respectively, and $48 and $610 for the two quarters ended
 July 3, 2017 and June 27, 2016,
 respectively.

[0001193125-17-251481:notes:122]
As of July 3, 2017
 and January 2, 2017, the Company’s consolidated
 condensed balance sheets included $16,934 and $15,836,
 respectively, in accounts payable due to related parties primarily
 for purchases of laminate and prepreg and such balances are
 included as a component of accounts payable on the consolidated
 condensed balance sheets. Additionally, the Company’s
 consolidated condensed balance sheets included $31 and $192,
 respectively, in accounts receivable due from a related party for
 sales of PCBs, as mentioned above, and such balances are included
 as a component of accounts receivable, net on the consolidated
 condensed balance sheets.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001193125-17-251481:notes:123]
(14)
 Segment Information

[0001193125-17-251481:notes:124]
The operating segments reported below are the Company’s
 segments for which separate financial information is available and
 upon which operating results are evaluated by the chief operating
 decision maker to assess performance and to allocate resources. The
 Company has two reportable operating segments: PCB and E-M Solutions. The PCB reportable
 segment is comprised of multiple operating segments. This
 determination was made based on the criteria of earning revenues
 and incurring expenses, the Company’s organizational
 structure which has segment managers who report to the chief
 operating decision maker, discrete financial information, and the
 aggregation of similar operating segments into reportable operating
 segments. Factors considered to determine whether operating
 segments can be aggregated into reportable segments included
 similarity regarding economic characteristics, products, production
 processes, type or classes of customers, distribution methods, and
 regulatory environments.

[0001193125-17-251481:notes:125]
The Company, including the chief operating decision maker,
 evaluates segment performance based on operating segment income,
 which is operating income before amortization of intangibles.
 Interest expense and interest income are not presented by segment
 since they are not included in the measure of segment profitability
 reviewed by the chief operating decision maker. All inter-segment
 transactions have been eliminated.

[0001193125-17-251481:notes:126]
The Corporate category includes operating expenses that are not
 included in the segment operating performance measures. Corporate
 consists primarily of corporate governance functions such as
 finance, accounting, corporate sales, information technology,
 facilities, corporate operations and human resources
 personnel.
