# TTMI MD&A — 0000950170-23-060227


## mdna

[0000950170-23-060227:mdna:1]
[same as prior period, unchanged from 0000950170-23-041297:mdna:1]

[0000950170-23-060227:mdna:2]
[same as prior period, unchanged from 0000950170-23-041297:mdna:2]

[0000950170-23-060227:mdna:3]
[same as prior period, unchanged from 0000950170-23-041297:mdna:3]

[0000950170-23-060227:mdna:4]
[same as prior period, unchanged from 0000950170-23-041297:mdna:4]

[0000950170-23-060227:mdna:5]
[same as prior period, unchanged from 0000950170-23-041297:mdna:5]

[0000950170-23-060227:mdna:6]
[same as prior period, unchanged from 0000950170-23-041297:mdna:6]

[0000950170-23-060227:mdna:7]
On November 1, 2023, we announced that we have selected New York State as the location for a new greenfield high-tech manufacturing facility. The planned investment aligns with New York State’s continued emphasis as a premier technology hub for U.S. electronics and the recent selection of Buffalo-Rochester-Syracuse (BRS) for the Federal Tech Hub designation. The project reflects our support for cultivating an even stronger microelectronics ecosystem in New York and across the U.S. Aerospace & Defense industrial base. It is expected that the proposed facility will bring disruptive capability for the domestic high-volume production of ultra-high-density interconnect (HDI) PCBs in support of national security requirements. It is expected to be the highest-technology PCB manufacturing site in North America, providing customers with reduced lead times and a significant increase in domestic capacity for ultra-HDI PCBs. In addition, this facility will be our most sustainable site in North America. We are in the advanced stages of project planning, having identified the 24-acre property adjacent to our existing facility in Syracuse for the campus expansion and the site for the new facility. We have completed initial building designs and site layout, and are now applying for the required permitting. The increase in campus size will also allow for additional capacity expansion already being considered for future phases of development. Groundbreaking is anticipated in the first half of 2024, with the project's final scale, scope, and timeline subject to finalizing funding with various stakeholders. Phase one of the proposed project, including capital for campus-wide improvements is estimated to be $100.0 million to $130.0 million, and is anticipated to run through 2026. Our planned capital investment commitments will be determined after finalizing terms with various stakeholders.

[0000950170-23-060227:mdna:8]
On February 8, 2023, we announced our plan to close PCB manufacturing operations in Anaheim and Santa Clara, California, and Hong Kong and to consolidate the business from these sites into our remaining facilities. The plant closures are expected to improve both facility and talent utilization across our footprint resulting in improved profitability. We expect to record between $22.0 million and $28.0 million in separation, accelerated depreciation and disposal costs related to this restructuring during 2023. Approximately 80% of these costs are expected to be in the form of cash expenditures and the rest in the form of non-cash charges. As of October 2, 2023, we have substantially closed the Hong Kong and Anaheim manufacturing facilities. We expect the Santa Clara facility to be substantially closed by the end of 2023.

[0000950170-23-060227:mdna:9]
On December 22, 2022, our land, building, and relevant ancillary assets related to our former Shanghai E-MS (SH E-MS) manufacturing facility was expropriated by the Chinese government for a compensation fee of Renminbi (RMB) 477.6 million resulting in a gain on the sale of $51.8 million. We have received 90% of the proceeds as of October 2, 2023 and expect to receive the remaining

[0000950170-23-060227:mdna:10]
10% of the proceeds before December 30, 2023. As of October 2, 2023 and January 2, 2023, the receivable from sale of the SH E-MS property was $6.6 million and $69.2 million, respectively.

[0000950170-23-060227:mdna:11]
[same as prior period, unchanged from 0000950170-23-041297:mdna:13]

[0000950170-23-060227:mdna:12]
While our customers include both OEMs and EMS providers, we measure customers based on OEM companies, as they are the ultimate end customers. Sales to our ten largest customers collectively accounted for 53% and 50% of our net sales for the quarter and three quarters ended October 2, 2023, respectively. Sales to our ten largest customers collectively accounted for 45% and 43% of our net sales for the quarter and three quarters ended October 3, 2022, respectively. We sell to OEMs both directly and indirectly through EMS providers.

[0000950170-23-060227:mdna:13]
While demand in the Aerospace and Defense end market remains strong, bookings in our commercial end markets have stabilized at a low level given continued customer inventory reductions and weaker end market demand. This resulted in a decline to revenues during the quarter ended October 2, 2023 when compared to the same quarter last year.

[0000950170-23-060227:mdna:14]
[same as prior period, unchanged from 0000950170-23-041297:mdna:15]

[0000950170-23-060227:mdna:15]
|  |  | Quarter Ended |  |  |  | Three Quarters Ended |  |  |
| End Markets (1) |  | October 2, 2023 |  |  |  | October 3, 2022 |  |  |  | October 2, 2023 |  |  |  | October 3, 2022 |  |  |
| Aerospace and Defense |  |  | 45 |  | % |  |  | 38 |  | % |  |  | 45 |  | % |  |  | 33 |  | % |
| Automotive |  |  | 15 |  |  |  |  | 15 |  |  |  |  | 16 |  |  |  |  | 17 |  |  |
| Data Center Computing |  |  | 17 |  |  |  |  | 14 |  |  |  |  | 13 |  |  |  |  | 16 |  |  |
| Medical/Industrial/Instrumentation |  |  | 16 |  |  |  |  | 19 |  |  |  |  | 17 |  |  |  |  | 21 |  |  |
| Networking |  |  | 7 |  |  |  |  | 14 |  |  |  |  | 9 |  |  |  |  | 13 |  |  |
| Total |  |  | 100 |  | % |  |  | 100 |  | % |  |  | 100 |  | % |  |  | 100 |  | % |

[0000950170-23-060227:mdna:16]
[same as prior period, unchanged from 0000950170-23-041297:mdna:17]

[0000950170-23-060227:mdna:17]
We derive revenues primarily from the sale of PCBs, engineered systems using customer-supplied engineering and design plans as well as our long-term contracts related to the design and manufacture of highly sophisticated intelligence, surveillance and communications solutions, and RF and microwave/microelectronics components, assemblies, and subsystems. Orders for products generally correspond to the production schedules of our customers and are supported with firm purchase orders. Our customers have continuous control of the work in progress and finished goods throughout the PCB and engineered systems manufacturing process, as these are built to customer specifications with no alternative use, and there is an enforceable right of payment for work performed to date. As a result, we recognize revenue progressively over time based on the extent of progress towards completion of the performance obligation. We recognize revenue based on a cost method as it best depicts the transfer of control to the customer which takes place as we incur costs. Revenues are recorded proportionally as costs are incurred.

[0000950170-23-060227:mdna:18]
[same as prior period, unchanged from 0000950170-23-041297:mdna:19]

[0000950170-23-060227:mdna:19]
[same as prior period, unchanged from 0000950170-23-041297:mdna:20]

[0000950170-23-060227:mdna:20]
[same as prior period, unchanged from 0000950170-23-041297:mdna:21]

[0000950170-23-060227:mdna:21]
[same as prior period, unchanged from 0000950170-23-041297:mdna:22]

[0000950170-23-060227:mdna:22]
[same as prior period, unchanged from 0000950170-23-041297:mdna:23]

[0000950170-23-060227:mdna:23]
[same as prior period, unchanged from 0000950170-23-041297:mdna:24]

[0000950170-23-060227:mdna:24]
[same as prior period, unchanged from 0000950170-23-041297:mdna:25]

[0000950170-23-060227:mdna:25]
Our consolidated condensed financial statements included in this report have been prepared in accordance with accounting principles generally accepted in the United States of America (U.S. GAAP). The preparation of these financial statements requires management to make estimates and assumptions that affect the reported amounts of assets, liabilities, net sales and expenses, and related disclosure of contingent assets and liabilities.

[0000950170-23-060227:mdna:26]
See Item 7, Management’s Discussion and Analysis of Financial Condition and Results of Operations, in our Annual Report on Form 10-K for the fiscal year ended January 2, 2023 for further discussion of critical accounting policies and estimates. There were no material changes to our critical accounting policies and estimates since January 2, 2023, except for the estimates used in the quantitative goodwill impairment analysis performed as of October 2, 2023. See Part I, Item 1, Note 6, Goodwill, of the Notes to Consolidated Condensed Financial Statements included in this Quarterly Report on Form 10-Q for further information.

[0000950170-23-060227:mdna:27]
[same as prior period, unchanged from 0000950170-23-041297:mdna:29]

[0000950170-23-060227:mdna:28]
[same as prior period, unchanged from 0000950170-23-041297:mdna:30]

[0000950170-23-060227:mdna:29]
|  |  | Quarter Ended |  | Three Quarters Ended |
|  |  | October 2, 2023 |  |  |  | October 3, 2022 |  |  |  | October 2, 2023 |  |  |  | October 3, 2022 |  |  |
| Net sales |  |  | 100.0 |  | % |  |  | 100.0 |  | % |  |  | 100.0 |  | % |  |  | 100.0 |  | % |
| Cost of goods sold |  |  | 80.2 |  |  |  |  | 80.8 |  |  |  |  | 82.1 |  |  |  |  | 82.1 |  |  |
| Gross profit |  |  | 19.8 |  |  |  |  | 19.2 |  |  |  |  | 17.9 |  |  |  |  | 17.9 |  |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Selling and marketing |  |  | 3.3 |  |  |  |  | 3.0 |  |  |  |  | 3.5 |  |  |  |  | 2.9 |  |  |
| General and administrative |  |  | 6.8 |  |  |  |  | 6.1 |  |  |  |  | 6.7 |  |  |  |  | 6.5 |  |  |
| Research and development |  |  | 1.1 |  |  |  |  | 1.1 |  |  |  |  | 1.2 |  |  |  |  | 1.0 |  |  |
| Amortization of definite-lived intangibles |  |  | 2.0 |  |  |  |  | 1.5 |  |  |  |  | 2.2 |  |  |  |  | 1.4 |  |  |
| Impairment of goodwill |  |  | 7.7 |  |  |  |  | — |  |  |  |  | 2.7 |  |  |  |  | — |  |  |
| Restructuring charges |  |  | 0.7 |  |  |  |  | 0.1 |  |  |  |  | 1.1 |  |  |  |  | 0.1 |  |  |
| Total operating expenses |  |  | 21.6 |  |  |  |  | 11.8 |  |  |  |  | 17.4 |  |  |  |  | 11.9 |  |  |
| Operating (loss) income |  |  | (1.8 | ) |  |  |  | 7.4 |  |  |  |  | 0.5 |  |  |  |  | 6.0 |  |  |
| Other (expense) income: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Interest expense |  |  | (1.8 | ) |  |  |  | (1.6 | ) |  |  |  | (2.1 | ) |  |  |  | (1.8 | ) |  |
| Loss on extinguishment of debt |  |  | — |  |  |  |  | — |  |  |  |  | (0.1 | ) |  |  |  | — |  |  |
| Gain on sale of subsidiary |  |  | — |  |  |  |  | — |  |  |  |  | 0.1 |  |  |  |  | — |  |  |
| Other, net |  |  | 0.5 |  |  |  |  | 1.5 |  |  |  |  | 0.6 |  |  |  |  | 1.1 |  |  |
| Total other expense, net |  |  | (1.3 | ) |  |  |  | (0.1 | ) |  |  |  | (1.5 | ) |  |  |  | (0.7 | ) |  |
| (Loss) income before income taxes |  |  | (3.1 | ) |  |  |  | 7.3 |  |  |  |  | (1.0 | ) |  |  |  | 5.3 |  |  |
| Income tax provision |  |  | (3.5 | ) |  |  |  | (0.8 | ) |  |  |  | (1.1 | ) |  |  |  | (0.6 | ) |  |
| Net (loss) income |  |  | (6.6 | ) | % |  |  | 6.5 |  | % |  |  | (2.1 | ) | % |  |  | 4.7 |  | % |

[0000950170-23-060227:mdna:30]
The following discussion and analysis is for the quarter and the three quarters ended October 2, 2023, compared to the same periods ended October 3, 2022, unless otherwise stated.

[0000950170-23-060227:mdna:31]
[same as prior period, unchanged from 0000950170-23-041297:mdna:33]

[0000950170-23-060227:mdna:32]
Total net sales decreased $98.5 million, or 14.7%, to $572.6 million for the third quarter of 2023 from $671.1 million for the third quarter of 2022. The decrease in total net sales primarily resulted from a decrease in net sales for the PCB reportable segment of $93.5 million, or 14.2%, to $563.7 million for the third quarter of 2023 from $657.2 million for the third quarter of 2022. The primary driver of this decrease was demand weakness in our Networking, Medical, Industrial and Instrumentation, and Automotive end markets, partially offset by growth in our Data Center Computing and Aerospace and Defense end markets. In addition, the Shanghai Backplane Assembly entity, which we sold in the first quarter of 2023, contributed $16.2 million in sales to the PCB reportable segment in the third quarter of 2022. Net sales for the RF&S Components reportable segment decreased $5.0 million, or 36.0%, to $8.9 million for the third quarter of 2023 from $13.9 million for the third quarter of 2022, which was primarily due to lower demand in our Networking end market.

[0000950170-23-060227:mdna:33]
Total net sales decreased $214.4 million, or 11.4%, to $1,663.5 million for the first three quarters of 2023 from $1,877.9 million for the first three quarters of 2022. This decrease in total net sales primarily resulted from a decrease in net sales for the PCB reportable segment of $198.4 million, or 10.8%, to $1,634.3 million for the first three quarters of 2023 from $1,832.7 million for the first three quarters of 2022. The primary driver of this decrease was demand weakness in our commercial end markets and decrease in sales of $23.9 million from the Shanghai Backplane Assembly entity we sold in the first quarter of 2023, partially offset by the inclusion of

[0000950170-23-060227:mdna:34]
results of Telephonics commencing with its acquisition in June 2022 as well as organic growth in our Aerospace and Defense end market. Additionally, there was a decrease in net sales for the RF&S Components reportable segment of $16.0 million, or 35.4%, to $29.2 million for the first three quarters of 2023 from $45.2 million for the first three quarters of 2022 primarily due to lower demand in our Networking end market.

[0000950170-23-060227:mdna:35]
[same as prior period, unchanged from 0000950170-23-041297:mdna:36]

[0000950170-23-060227:mdna:36]
Overall gross margin increased to 19.8% for the third quarter of 2023 from 19.2% for the third quarter of 2022. Gross margin for the PCB reportable segment increased to 21.1% for the third quarter of 2023 from 19.1% for the third quarter of 2022. This increase was primarily due to improved execution in our North America region. Gross margin for the RF&S Components reportable segment decreased to 56.4% for the third quarter of 2023 from 63.5% for the third quarter of 2022, primarily due to lower sales.

[0000950170-23-060227:mdna:37]
Overall gross margin was 17.9% for both the first three quarters of 2023 and the first three quarters of 2022. Gross margin for the PCB reportable segment increased to 18.8% for the first three quarters of 2023 from 17.9% for the first three quarters of 2022 due to improved execution in our North America region. Gross margin for the RF&S Components reportable segment decreased to 54.3% for the first three quarters of 2023 from 61.3% for the first three quarters of 2022, primarily due to lower sales.

[0000950170-23-060227:mdna:38]
Capacity utilization is a key driver for us, which is measured by actual production as a percentage of capacity. This measure is particularly important in our high-volume facilities in Asia, as a significant portion of our operating costs are fixed in nature. Capacity utilization for the third quarter of 2023 in our Asia and North America PCB facilities was 46% and 38%, respectively, compared to 72% and 45%, respectively, for the third quarter of 2022. Capacity utilization for the first three quarters of 2023 in our Asia and North America PCB facilities was 48% and 39%, respectively, compared to 77% and 46%, respectively, for the first three quarters of 2022. The decrease in capacity utilization in our Asia PCB facilities was caused by a decline in production volumes due to demand weakness in our commercial end markets while the decrease in our North America PCB facilities was due to the additional plating capacity added as well as a greater mix of higher technology product that requires less finish plating.

[0000950170-23-060227:mdna:39]
[same as prior period, unchanged from 0000950170-23-041297:mdna:41]

[0000950170-23-060227:mdna:40]
Selling and marketing expenses decreased $1.0 million to $18.8 million for the third quarter of 2023 from $19.8 million for the third quarter of 2022. The decrease in selling and marketing expenses was primarily due to a decrease in commission expense. However, because of lower net sales, selling and marketing expenses as a percentage of net sales increased to 3.3% for the third quarter of 2023 from 3.0% for the third quarter of 2022.

[0000950170-23-060227:mdna:41]
Selling and marketing expenses increased $2.6 million to $58.2 million for the first three quarters of 2023 from $55.6 million for the first three quarters of 2022. As a percentage of net sales, selling and marketing expenses were 3.5% for the first three quarters of 2023, as compared to 2.9% for the first three quarters of 2022. The increase in selling and marketing expenses for the first three quarters of 2023 was primarily due to $4.2 million of selling and marketing expenses incurred in the first two quarters of 2023 by Telephonics post acquisition and an increase in labor and travel costs, partially offset by a $2.7 million decrease in commission expense.

[0000950170-23-060227:mdna:42]
[same as prior period, unchanged from 0000950170-23-041297:mdna:44]

[0000950170-23-060227:mdna:43]
General and administrative expenses decreased $1.8 million to $38.9 million, or 6.8% of net sales, for the third quarter of 2023 from $40.7 million, or 6.1% of net sales, for the third quarter of 2022. The decrease in the amount of general and administrative expenses was primarily due to $1.9 million of reduced acquisition and integration costs, while the increase on a percentage basis resulted from lower net sales.

[0000950170-23-060227:mdna:44]
General and administrative expenses decreased $10.1 million to $111.8 million, or 6.7% of net sales, for the first three quarters of 2023 from $121.9 million, or 6.5% of net sales, for the first three quarters of 2022. The decrease in the amount of general and administrative expenses primarily resulted from $12.8 million of reduced acquisition and integration costs mainly related to the acquisition of Telephonics on June 27, 2022, partially offset by $3.6 million of general and administrative expenses incurred in the first two quarters of 2023 by Telephonics post acquisition.

[0000950170-23-060227:mdna:45]
[same as prior period, unchanged from 0000950170-23-041297:mdna:47]

[0000950170-23-060227:mdna:46]
Research and development expenses decreased $1.1 million to $6.2 million, or 1.1% of net sales, for the third quarter of 2023 from $7.3 million, or 1.1% of net sales, for the third quarter of 2022. The decrease in the expense amount was primarily due to a decrease in labor costs and supplies spending, while the percentage of net sales was flat as a result of lower net sales.

[0000950170-23-060227:mdna:47]
Research and development expenses increased $1.6 million to $19.7 million, or 1.2% of net sales, for the first three quarters of 2023 from $18.1 million, or 1.0% of net sales, for the first three quarters of 2022. The increase in expense was primarily due to $3.2 million of research and development expense incurred in the first two quarters of 2023 by Telephonics post acquisition, partially offset by a decrease in labor costs and supplies spending.

[0000950170-23-060227:mdna:48]
Impairment of Goodwill

[0000950170-23-060227:mdna:49]
During the third quarter of 2023, we performed an interim evaluation of goodwill in connection with the preparation and review of our Consolidated Condensed Financial Statements included in this Quarterly Report on Form 10-Q, as we believed there were impairment triggering events and circumstances that warranted an evaluation. The circumstances included lower than anticipated results, lower forecasted sales in future years, and a continued decline in sales in the RF&S Components reporting unit. As a result, we recorded a non-cash goodwill impairment charge in the amount of $44.1 million in the third quarter of 2023.

[0000950170-23-060227:mdna:50]
[same as prior period, unchanged from 0000950170-23-041297:mdna:50]

[0000950170-23-060227:mdna:51]
Total other expense, net increased $6.5 million to $7.1 million for the third quarter of 2023, primarily due to foreign currency losses resulting from the strengthening RMB in the third quarter of 2023 compared to the third quarter of 2022, partially offset by an increase in interest income of $1.8 million. We utilize the RMB at our China facilities for employee-related expenses, RMB denominated purchases, and other costs of running our operations in China.

[0000950170-23-060227:mdna:52]
Total other expense, net increased $12.2 million to $25.3 million for the first three quarters of 2023, primarily due to foreign currency losses resulting from the strengthening RMB in the first three quarters of 2023 compared to the first three quarters of 2022, a loss on extinguishment of debt of $1.3 million, and an increase in interest expense of $1.7 million due to higher interest rates, partially offset by an increase in interest income of $3.9 million.

[0000950170-23-060227:mdna:53]
[same as prior period, unchanged from 0000950170-23-041297:mdna:53]

[0000950170-23-060227:mdna:54]
Income tax expense increased $14.2 million to $19.8 million for the third quarter of 2023 from $5.6 million for the third quarter of 2022. The increase in income tax expense was primarily due to a change in the valuation allowance on U.S. deferred tax assets in the third quarter of 2023 which was absent in the third quarter of 2022.

[0000950170-23-060227:mdna:55]
Income tax expense increased $7.3 million to $18.5 million for the first three quarters of 2023 from $11.2 million for the first three quarters of 2022. The increase in income tax expense for the first three quarters of 2023 was primarily due to a change in the valuation allowance on U.S. deferred tax assets in the first three quarters of 2023 which was absent in the first three quarters of 2022.

[0000950170-23-060227:mdna:56]
Our effective tax rate is primarily impacted by the mix of foreign and U.S. income, tax rates in China and Hong Kong, the U.S. federal income tax rate, apportioned state income tax rates, the generation of credits and deductions available to the Company as well as changes in valuation allowances and certain non-deductible items. We had a net deferred income tax liability of approximately $56.8 million and $8.9 million as of October 2, 2023 and October 3, 2022, respectively. The increase in the deferred income tax liability was primarily due to the recording of a full valuation allowance for the U.S. in the last quarter of 2022.

[0000950170-23-060227:mdna:57]
[same as prior period, unchanged from 0000950170-23-041297:mdna:57]

[0000950170-23-060227:mdna:58]
Our principal sources of liquidity have been cash provided by operations, the issuance of debt, and borrowings under our revolving credit facility. Our principal uses of cash have been to finance capital expenditures, finance acquisitions, fund working capital requirements, to repay debt obligations, and to repurchase common stock. We anticipate that financing capital expenditures, financing acquisitions, funding working capital requirements, servicing debt, and repurchasing common stock will be the principal demands on our cash in the future.

[0000950170-23-060227:mdna:59]
Cash flow provided by operating activities during the first three quarters of 2023 was $139.8 million as compared to cash flow provided by operating activities of $195.3 million in the same period in 2022. The decrease in cash flow was primarily due to the $124.6 million decrease in net income.

[0000950170-23-060227:mdna:60]
Net cash used in investing activities was approximately $46.1 million for the first three quarters of 2023, primarily reflecting the use of $114.2 million for purchases of property, plant and equipment and other assets, partially offset by the receipt of $61.8 million of proceeds from the sale of property associated with our Shanghai E-MS subsidiary and $6.0 million of proceeds from the sale of our Shanghai Backplane Assembly subsidiary, net of cash disposed. Net cash used in investing activities was approximately $374.7 million for the first three quarters of 2022, primarily reflecting the use of $298.3 million for the acquisition of Telephonics and $76.2 million for purchases of property, plant and equipment and other assets.

[0000950170-23-060227:mdna:61]
Net cash used in financing activities during the first three quarters of 2023 was $87.9 million, reflecting repayment of long-term debt borrowings of $291.5 million, repurchases of common stock of $14.6 million, refund of customer deposits of $7.5 million, payment of debt issuance costs of $5.5 million and payment of original issue discount of $3.5 million, partially offset by the receipt of proceeds from long-term debt borrowing of $234.8 million. Net cash used in financing activities during the first three quarters of 2022 was $21.3 million, primarily reflecting repurchases of common stock of $35.4 million, cash used to settle warrants of $0.9 million, less customer deposits of $15.0 million.

[0000950170-23-060227:mdna:62]
As of October 2, 2023, we had cash and cash equivalents of approximately $408.3 million, of which approximately $198.3 million was held by our foreign subsidiaries, primarily in Hong Kong. Should we choose to remit cash to the United States from our foreign locations, we may incur tax obligations which would reduce the amount of cash ultimately available to the United States. However, we believe there would be no material tax consequences not previously accrued for the repatriation of this cash.

[0000950170-23-060227:mdna:63]
Our total 2023 capital expenditures are expected to be in the range of $200.0 million to $220.0 million, of which approximately $115.0 million relate to our construction of our new plant in Penang, Malaysia.

[0000950170-23-060227:mdna:64]
[same as prior period, unchanged from 0000950170-23-041297:mdna:64]

[0000950170-23-060227:mdna:65]
As of October 2, 2023, we had $867.4 million of outstanding debt, net of discount and debt issuance costs, composed of $495.7 million of Senior Notes due March 2029, $341.7 million of a Term Loan due May 2030, and $30.0 million under the Asia ABL.

[0000950170-23-060227:mdna:66]
Pursuant to the terms of the Term Loan Facility and Senior Notes due 2029, we are subject to certain affirmative and negative covenants, including limitations on indebtedness, corporate transactions, investments, dispositions, and restricted payments. Under the U.S. ABL and Asia ABL (collectively, the ABL Revolving Loans), we are also subject to various financial covenants, including leverage and fixed charge coverage ratios. As of October 2, 2023, we were in compliance with the covenants under the Term Loan Facility, Senior Notes due 2029 and ABL Revolving Loans.

[0000950170-23-060227:mdna:67]
[same as prior period, unchanged from 0000950170-23-041297:mdna:67]

[0000950170-23-060227:mdna:68]
[same as prior period, unchanged from 0000950170-23-041297:mdna:68]

[0000950170-23-060227:mdna:69]
As part of our on-going operations, we enter into contractual arrangements that obligate us to make future cash payments. These obligations impact our liquidity and capital resource needs. Our estimated future obligations consist of long-term debt obligations, interest on debt obligations, purchase obligations, and leases as of October 2, 2023. As of the date of this report, there were no material changes outside the ordinary course of business since January 2, 2023 to our contractual obligations and commitments and the related cash requirements, except for our interest on debt obligations. Our aggregate interest on debt obligations as of October 2, 2023 amounted to $302.0 million, which are expected to be settled as follows: $50.4 million within 1 year, $100.0 million within 1-3 years, $98.8 million within 4-5 years, and $52.8 million after 5 years. For debt obligations based on variable rates, interest rates used are as of October 2, 2023.

[0000950170-23-060227:mdna:70]
[same as prior period, unchanged from 0000950170-23-041297:mdna:70]

[0000950170-23-060227:mdna:71]
Following the acquisition of Telephonics on June 27, 2022, we have and may continue to enter into industrial cooperation agreements, sometimes referred to as offset agreements, as a condition to obtaining orders for our products and services from customers in foreign countries. These agreements are intended to promote investment in the applicable country, and our obligations under these agreements may be satisfied through activities that do not require us to use cash, including transferring technology or providing manufacturing and other consulting support. The obligations under these agreements may also be satisfied through the use of cash for such activities as purchasing supplies from in-country vendors, setting up support centers, research and development investments, acquisitions, and building or leasing facilities for in-country operations. The amount of the offset requirement is determined by contract value awarded and negotiated percentages with customers. As of October 2, 2023, we had outstanding offset agreements of approximately $28.0 million, some of which extend through 2028. Offset programs usually extend over several years and in some cases provide for penalties in the event we fail to perform in accordance with contract requirements. Historically, we have not paid any such penalties, and as of October 2, 2023, no such penalties have been paid.

[0000950170-23-060227:mdna:72]
[same as prior period, unchanged from 0000950170-23-041297:mdna:72]

[0000950170-23-060227:mdna:73]
[same as prior period, unchanged from 0000950170-23-041297:mdna:73]

[0000950170-23-060227:mdna:74]
Recently Issued Accounting Standards

[0000950170-23-060227:mdna:75]
[same as prior period, unchanged from 0000950170-23-041297:mdna:75]
