# TTMI notes — 0000950170-23-060227


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureAndSignificantAccountingPoliciesTextBlock

[0000950170-23-060227:notes:1]
[same as prior period, unchanged from 0000950170-23-041297:notes:1]

[0000950170-23-060227:notes:2]
[same as prior period, unchanged from 0000950170-23-041297:notes:2]

[0000950170-23-060227:notes:3]
[same as prior period, unchanged from 0000950170-23-041297:notes:3]

[0000950170-23-060227:notes:4]
The accompanying consolidated condensed financial statements have been prepared by the Company, without audit, pursuant to the rules and regulations of the Securities and Exchange Commission (SEC). Certain information and disclosures normally included in financial statements prepared in accordance with accounting principles generally accepted in the United States of America (U.S. GAAP) have been condensed or omitted pursuant to such rules and regulations. These consolidated condensed financial statements should be read in conjunction with the consolidated financial statements and the notes thereto included in the Company’s most recent Annual Report on Form 10-K. The preparation of financial statements in accordance with U.S. GAAP requires management to make estimates and assumptions that affect the amounts reported in the Company’s consolidated condensed financial statements and accompanying notes. Due, in part, to the coronavirus (COVID-19) and its variants, the conflict between Russia and Ukraine, and the current conflict in Israel and the Gaza Strip, the global economy and financial markets have been volatile. In addition, the global economy and financial markets have experienced on-going disruptions in global supply chains, labor shortages, high inflation, and a potential recession. The Company has considered information available to it as of the date of issuance of these financial statements and is not aware of any specific events or circumstances that would require an update to its estimates or judgments, or a revision to the carrying value of its assets or liabilities. The actual results the Company experienced may differ materially and adversely from its estimates. The Company uses a 52/53 week fiscal calendar with the fourth quarter ending on the Monday nearest December 31.

[0000950170-23-060227:notes:5]
Reclassifications

[0000950170-23-060227:notes:6]
Certain amounts in the prior period financial statements have been reclassified to conform to the presentation of the current period financial statements. These reclassifications had no effect on the previously reported net income.

[0000950170-23-060227:notes:7]
[same as prior period, unchanged from 0000950170-23-041297:notes:5]

[0000950170-23-060227:notes:8]
Recently Adopted Accounting Standards

[0000950170-23-060227:notes:9]
In September 2022, the Financial Accounting Standards Board (FASB) issued Accounting Standards Update (ASU) 2022-04, Liabilities - Supplier Finance Programs (Topic 450-50): Disclosure of Supplier Finance Program Obligations, that requires entities that use supplier finance programs in connection with the purchase of goods and services to disclose the key terms of the programs and information about obligations outstanding at the end of the reporting period, including a rollforward of those obligations. The guidance does not affect the recognition, measurement or financial statement presentation of supplier finance program obligations. The amendments are effective for all entities for fiscal years beginning after December 15, 2022 on a retrospective basis, including interim periods within those fiscal years, except for the requirement to disclose rollforward information, which is effective prospectively for fiscal years beginning after December 15, 2023. The Company adopted ASU 2022-04 as of April 3, 2023. The Company has agreements with financial institutions to facilitate the payments to certain suppliers. Under the terms of the agreements, the Company confirms the validity of each supplier invoice to the respective financial institution upon receipt. The supplier receives payment from the financial institution, and the Company pays the financial institution based on the terms negotiated, which generally range from 160 days to 360 days. Liabilities associated with these agreements are recorded in accounts payable on the consolidated condensed balance sheets and amounted to $15,945 and $6,653 as of October 2, 2023 and January 2, 2023, respectively.

[0000950170-23-060227:notes:10]
In December 2022, the FASB issued ASU 2022-06, Reference Rate Reform (Topic 848): Deferral of the Sunset Date of Topic 848, which deferred the sunset date of Topic 848 to December 31, 2024, after which entities will no longer be permitted to apply the optional expedients and exceptions in Topic 848. On March 23, 2023, the Company entered into a four-year pay-fixed, receive floating (1-month CME Term Secured Overnight Financing Rate (SOFR)), interest rate swap arrangement with a notional amount of $250,000 for the period beginning April 1, 2023 and ending on April 1, 2027. Under the terms of the interest rate swap, the Company pays a fixed rate of 3.49% against a portion of its Term SOFR-based debt and receives a floating 1-month CME Term SOFR during

[0000950170-23-060227:notes:11]
the swap period. The Company elected optional expedients provided in Topic 848 which allow the designation of the interest rate swap as a cash flow hedge.


## us-gaap:BusinessCombinationDisclosureTextBlock

[0000950170-23-060227:notes:12]
[same as prior period, unchanged from 0000950170-23-041297:notes:9]

[0000950170-23-060227:notes:13]
[same as prior period, unchanged from 0000950170-23-041297:notes:10]

[0000950170-23-060227:notes:14]
For the quarter and three quarters ended October 2, 2023, legal, accounting, and other professional service costs associated with the acquisition of $90 and $598, respectively, have been expensed and recorded as general and administrative expense in the consolidated condensed statements of operations. For the quarter and three quarters ended October 3, 2022, bank fees and legal, accounting, and other professional service costs associated with the acquisition of $270 and $10,978, respectively, were expensed and recorded as general and administrative expense in the consolidated condensed statements of operations.

[0000950170-23-060227:notes:15]
[same as prior period, unchanged from 0000950170-23-041297:notes:12]

[0000950170-23-060227:notes:16]
The purchase price was allocated to tangible and intangible assets acquired, and liabilities assumed based on the fair value at the date of the acquisition, June 27, 2022. The excess of the purchase price over the fair value of net assets acquired was allocated to goodwill. The fair values were based on management’s analysis, including work performed by third-party valuation specialists. The Company finalized the allocation of the purchase price during the second quarter of 2023.

[0000950170-23-060227:notes:17]
The fair values assigned are based on reasonable methods applicable to the nature of the assets acquired and liabilities assumed. The following summarizes the final assigned fair values of net assets acquired:

[0000950170-23-060227:notes:18]
[same as prior period, unchanged from 0000950170-23-041297:notes:15]

[0000950170-23-060227:notes:19]
[same as prior period, unchanged from 0000950170-23-041297:notes:16]

[0000950170-23-060227:notes:20]
Acquired identifiable intangible assets include customer relationships, technology, backlog, and trade names. The fair value of the identifiable intangible assets was determined using various valuation methods including relief from royalty and excess earnings to determine the present value of expected future cash flows for each identifiable intangible asset based on discount rates. The expected cash flows were estimated using available historical data adjusted based on a market participant perspective. The Company used risk adjusted discount rates between 7.0% and 8.0% to discount the expected future cash flows.

[0000950170-23-060227:notes:21]
The Company finalized the acquired identifiable intangible asset valuation during the second quarter of 2023. The Company recorded amortization expense of $20,064 related to the acquired identifiable intangible assets during the three quarters ended October 2, 2023 (of which $5,627 corresponded to the year ended January 2, 2023 due to the change in amortization period). For the three quarters ended October 2, 2023, $7,375 of amortization expense is included in cost of goods sold (of which $2,950 corresponded to the year ended January 2, 2023).

[0000950170-23-060227:notes:22]
[same as prior period, unchanged from 0000950170-23-041297:notes:20]

[0000950170-23-060227:notes:23]
Goodwill represents the excess of the purchase price over the fair value of assets acquired and liabilities assumed. The Company believes that the acquisition of Telephonics will strengthen the Company’s differentiated position in the Aerospace and Defense market. The Company believes that these factors support the amount of goodwill recognized as a result of the purchase price paid for Telephonics, in relation to other acquired tangible and intangible assets. The goodwill acquired in the acquisition is not deductible for income tax purposes.

[0000950170-23-060227:notes:24]
[same as prior period, unchanged from 0000950170-23-041297:notes:22]

[0000950170-23-060227:notes:25]
Included in the consolidated condensed statements of operations are net sales of $159,950 and $68,255, excluding intercompany sales, for the three quarters ended October 2, 2023 and October 3, 2022, respectively. Included in the consolidated condensed statements of operations are pre-tax income of $15,883 and $6,997, excluding amortization of intangibles, for the three quarters ended October 2, 2023 and October 3, 2022, respectively.

[0000950170-23-060227:notes:26]
[same as prior period, unchanged from 0000950170-23-041297:notes:24]

[0000950170-23-060227:notes:27]
[same as prior period, unchanged from 0000950170-23-041297:notes:25]

[0000950170-23-060227:notes:28]
[same as prior period, unchanged from 0000950170-23-041297:notes:26]

[0000950170-23-060227:notes:29]
|  |  | Quarter Ended |  |  | Three Quarters Ended |  |
|  |  | October 2, 2023 |  |  | October 3, 2022 |  |  | October 2, 2023 |  |  | October 3, 2022 |  |
|  |  | (In thousands, except per share amounts) |  |
| Net sales |  | $ | 572,582 |  |  | $ | 671,080 |  |  | $ | 1,663,528 |  |  | $ | 1,984,958 |  |
| Net (loss) income |  |  | (37,066 | ) |  |  | 41,254 |  |  |  | (30,626 | ) |  |  | 88,905 |  |
| Basic (loss) earnings per share |  | $ | (0.36 | ) |  | $ | 0.40 |  |  | $ | (0.30 | ) |  | $ | 0.87 |  |
| Diluted (loss) earnings per share |  | $ | (0.36 | ) |  | $ | 0.40 |  |  | $ | (0.30 | ) |  | $ | 0.86 |  |


## us-gaap:LesseeOperatingLeasesTextBlock

[0000950170-23-060227:notes:30]
[same as prior period, unchanged from 0000950170-23-041297:notes:28]

[0000950170-23-060227:notes:31]
The Company leases some of its manufacturing and assembly plants, sales offices and equipment under non-cancellable operating leases and finance leases that expire at various dates through 2043. The majority of the Company’s lease arrangements are comprised of fixed payments and certain leases consist of variable payments based on equipment usage. These variable payments are not included in the measurement of the right-of-use (ROU) asset or lease liability due to uncertainty of the payment amount and are recorded as lease expense in the period incurred. Certain leases contain renewal provisions at the Company’s option. Most of the leases require the Company to pay for certain other costs such as property taxes and maintenance. Certain leases also contain rent escalation clauses (step rents) that require additional rental amounts in the later years of the term. Rent expense for leases with step rents is recognized on a straight-line basis over the minimum lease term. The lease agreements do not contain any material residual value guarantees or material restrictive covenants.

[0000950170-23-060227:notes:32]
[same as prior period, unchanged from 0000950170-23-041297:notes:30]

[0000950170-23-060227:notes:33]
|  |  | Quarter Ended |  |  | Three Quarters Ended |  |
|  |  | October 2, 2023 |  |  | October 3, 2022 |  |  | October 2, 2023 |  |  | October 3, 2022 |  |
|  |  | (In thousands) |  |
| Operating lease cost |  | $ | 1,754 |  |  | $ | 2,080 |  |  | $ | 5,562 |  |  | $ | 5,756 |  |
| Variable lease cost |  |  | 179 |  |  |  | 383 |  |  |  | 674 |  |  |  | 837 |  |
| Short-term lease cost |  |  | 170 |  |  |  | 199 |  |  |  | 445 |  |  |  | 513 |  |
| Finance lease costs: |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of right-of-use assets |  |  | 344 |  |  |  | 344 |  |  |  | 1,031 |  |  |  | 1,031 |  |
| Interest on lease liabilities |  |  | 94 |  |  |  | 98 |  |  |  | 281 |  |  |  | 295 |  |

[0000950170-23-060227:notes:34]
[same as prior period, unchanged from 0000950170-23-041297:notes:32]

[0000950170-23-060227:notes:35]
|  |  | Three Quarters Ended |  |
|  |  | October 2, 2023 |  |  | October 3, 2022 |  |
|  |  | (In thousands) |  |
| Cash paid for amounts included in the measurement of lease liabilities: |  |  |  |  |  |  |
| Operating cash flows for operating leases |  | $ | 5,632 |  |  | $ | 5,796 |  |
| Right-of-use assets obtained in exchange for new lease obligations: |  |  |  |  |  |  |
| Operating leases |  |  | 77,840 |  |  |  | 5,196 |  |

[0000950170-23-060227:notes:36]
[same as prior period, unchanged from 0000950170-23-041297:notes:34]

[0000950170-23-060227:notes:37]
|  |  |  |  | As of |  |
|  |  | Balance Sheet Location |  | October 2, 2023 |  |  | January 2, 2023 |  |
|  |  |  |  | (In thousands) |  |
| Assets: |  |  |  |  |  |  |  |  |
| Operating leases |  | Operating lease right-of-use assets |  | $ | 89,290 |  |  | $ | 18,862 |  |
| Finance leases |  | Property, plant and equipment, net |  |  | 12,354 |  |  |  | 13,384 |  |
| Total lease assets |  |  |  | $ | 101,644 |  |  | $ | 32,246 |  |
| Liabilities: |  |  |  |  |  |  |  |  |
| Current: |  |  |  |  |  |  |  |  |
| Operating leases |  | Other current liabilities |  | $ | 7,846 |  |  | $ | 7,368 |  |
| Finance leases |  | Other current liabilities |  |  | 778 |  |  |  | 736 |  |
| Long-term: |  |  |  |  |  |  |  |  |
| Operating leases |  | Operating lease liabilities |  |  | 82,103 |  |  |  | 12,249 |  |
| Finance leases |  | Other long-term liabilities |  |  | 12,993 |  |  |  | 13,579 |  |
| Total lease liabilities |  |  |  | $ | 103,720 |  |  | $ | 33,932 |  |

[0000950170-23-060227:notes:38]
|  |  | As of |  |
|  |  | October 2, 2023 |  |  | January 2, 2023 |  |
| Weighted average remaining lease term (years): |  |  |  |  |  |  |
| Operating leases |  | 13.1 |  |  | 3.3 |  |
| Finance leases |  | 12.9 |  |  | 13.6 |  |
| Weighted average discount rate: |  |  |  |  |  |  |
| Operating leases |  |  | 6.11 | % |  |  | 3.09 | % |
| Finance leases |  |  | 2.69 | % |  |  | 2.69 | % |

[0000950170-23-060227:notes:39]
[same as prior period, unchanged from 0000950170-23-041297:notes:37]

[0000950170-23-060227:notes:40]
|  |  | OperatingLeases (1) |  |  | FinanceLeases |  |
|  |  | (In thousands) |  |
| Less than one year |  | $ | 12,978 |  |  | $ | 1,136 |  |
| 1 - 2 years |  |  | 11,403 |  |  |  | 1,133 |  |
| 2 - 3 years |  |  | 9,038 |  |  |  | 1,175 |  |
| 3 - 4 years |  |  | 8,203 |  |  |  | 1,184 |  |
| 4 - 5 years |  |  | 7,844 |  |  |  | 1,228 |  |
| Thereafter |  |  | 87,535 |  |  |  | 10,538 |  |
| Total lease payments |  |  | 137,001 |  |  |  | 16,394 |  |
| Less imputed interest |  |  | (47,052 | ) |  |  | (2,623 | ) |
| Total |  | $ | 89,949 |  |  | $ | 13,771 |  |

[0000950170-23-060227:notes:41]
(1)
Excludes $851 of legally binding minimum lease payments for leases signed but not yet commenced.


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0000950170-23-060227:notes:42]
[same as prior period, unchanged from 0000950170-23-041297:notes:40]

[0000950170-23-060227:notes:43]
As of October 2, 2023, the aggregate amount of the transaction price allocated to remaining performance obligations for long-term contracts was $353,941. The Company expects to recognize revenue on approximately 56% of the remaining performance obligations for the Company’s long-term contracts over the next twelve months with the remaining amount expected to be recognized thereafter.

[0000950170-23-060227:notes:44]
For contracts in which anticipated total costs exceed the total expected revenue, an estimated loss is recognized in the period when identifiable. A provision for the entire amount of the estimated loss is recorded on a cumulative basis. The estimated remaining costs to complete for loss contracts as of October 2, 2023 and January 2, 2023 were $19,202 and $21,632, respectively.

[0000950170-23-060227:notes:45]
Revenue recognized for the three quarters ended October 2, 2023 from amounts recorded as contract liabilities as of January 2, 2023 was $33,939.

[0000950170-23-060227:notes:46]
Revenue from products and services transferred to customers over time and at a point in time accounted for 96% and 4%, respectively, of the Company’s revenue for the quarter and three quarters ended October 2, 2023, and 98% and 2%, respectively, of the Company’s revenue for the quarter and three quarters ended October 3, 2022.

[0000950170-23-060227:notes:47]
[same as prior period, unchanged from 0000950170-23-041297:notes:45]

[0000950170-23-060227:notes:48]
|  |  | Quarter Ended October 2, 2023 |  |  | Quarter Ended October 3, 2022 (1) |  |
|  |  | PCB |  |  | RF&S Components |  |  | Total |  |  | PCB |  |  | RF&S Components |  |  | Total |  |
| End Markets |  | (In thousands) |  |
| Aerospace and Defense |  | $ | 255,618 |  |  | $ | — |  |  | $ | 255,618 |  |  | $ | 254,285 |  |  | $ | — |  |  | $ | 254,285 |  |
| Automotive |  |  | 86,803 |  |  |  | — |  |  |  | 86,803 |  |  |  | 100,811 |  |  |  | — |  |  |  | 100,811 |  |
| Data Center Computing |  |  | 99,584 |  |  |  | — |  |  |  | 99,584 |  |  |  | 95,830 |  |  |  | 13 |  |  |  | 95,843 |  |
| Medical/Industrial/Instrumentation |  |  | 89,818 |  |  |  | 895 |  |  |  | 90,713 |  |  |  | 128,444 |  |  |  | 1,239 |  |  |  | 129,683 |  |
| Networking |  |  | 31,853 |  |  |  | 8,011 |  |  |  | 39,864 |  |  |  | 78,181 |  |  |  | 12,494 |  |  |  | 90,675 |  |
| Other |  |  | — |  |  |  | — |  |  |  | — |  |  |  | (376 | ) |  |  | 159 |  |  |  | (217 | ) |
| Total |  | $ | 563,676 |  |  | $ | 8,906 |  |  | $ | 572,582 |  |  | $ | 657,175 |  |  | $ | 13,905 |  |  | $ | 671,080 |  |

[0000950170-23-060227:notes:49]
|  |  | Three Quarters Ended October 2, 2023 |  |  | Three Quarters Ended October 3, 2022 (1) |  |  |
|  |  | PCB |  |  | RF&S Components |  |  | Total |  |  | PCB |  |  | RF&S Components |  |  | Total |  |  |
| End Markets |  | (In thousands) |  |  |
| Aerospace and Defense |  | $ | 742,194 |  |  | $ | — |  |  | $ | 742,194 |  |  | $ | 616,141 |  |  | $ | — |  |  | $ | 616,141 |  |  |
| Automotive |  |  | 272,644 |  |  |  | — |  |  |  | 272,644 |  |  |  | 327,825 |  |  |  | — |  |  |  | 327,825 |  |  |
| Data Center Computing |  |  | 221,759 |  |  |  | 51 |  |  |  | 221,810 |  |  |  | 293,802 |  |  |  | 33 |  |  |  | 293,835 |  |  |
| Medical/Industrial/Instrumentation |  |  | 279,565 |  |  |  | 2,557 |  |  |  | 282,122 |  |  |  | 379,867 |  |  |  | 5,023 |  |  |  | 384,890 |  |  |
| Networking |  |  | 118,156 |  |  |  | 26,602 |  |  |  | 144,758 |  |  |  | 211,590 |  |  |  | 41,360 |  |  |  | 252,950 |  |  |
| Other |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 3,449 |  |  |  | (1,200 | ) |  |  | 2,249 |  |  |
| Total |  | $ | 1,634,318 |  |  | $ | 29,210 |  |  | $ | 1,663,528 |  |  | $ | 1,832,674 |  |  | $ | 45,216 |  |  | $ | 1,877,890 |  |  |

[0000950170-23-060227:notes:50]
(1)
Amended for Telephonics integration.


## us-gaap:AdditionalFinancialInformationDisclosureTextBlock

[0000950170-23-060227:notes:51]
[same as prior period, unchanged from 0000950170-23-041297:notes:48]

[0000950170-23-060227:notes:52]
|  |  | As of |  |
|  |  | October 2, 2023 |  |  | January 2, 2023 |  |
|  |  | (In thousands) |  |
| Inventories: |  |  |  |  |  |  |
| Raw materials |  | $ | 161,870 |  |  | $ | 145,561 |  |
| Work-in-process |  |  | 40,378 |  |  |  | 20,114 |  |
| Finished goods |  |  | 3,928 |  |  |  | 4,964 |  |
|  |  | $ | 206,176 |  |  | $ | 170,639 |  |
| Property, plant and equipment, net: |  |  |  |  |  |  |
| Land and land use rights |  | $ | 76,811 |  |  | $ | 76,811 |  |
| Buildings and improvements |  |  | 448,756 |  |  |  | 443,353 |  |
| Machinery and equipment |  |  | 986,615 |  |  |  | 989,935 |  |
| Furniture and fixtures and other |  |  | 10,155 |  |  |  | 11,327 |  |
| Construction-in-progress |  |  | 141,135 |  |  |  | 27,774 |  |
|  |  |  | 1,663,472 |  |  |  | 1,549,200 |  |
| Less: Accumulated depreciation |  |  | (855,101 | ) |  |  | (824,996 | ) |
|  |  | $ | 808,371 |  |  | $ | 724,204 |  |
| Other current liabilities: |  |  |  |  |  |  |
| Accrued capital expenditures |  | $ | 48,181 |  |  | $ | — |  |
| Income taxes payable |  |  | 16,944 |  |  |  | 28,057 |  |
| Sales return and allowances |  |  | 12,216 |  |  |  | 12,319 |  |
| Accrued facility operating costs |  |  | 9,516 |  |  |  | 9,081 |  |
| Operating leases |  |  | 7,846 |  |  |  | 7,368 |  |
| Warranty |  |  | 7,929 |  |  |  | 8,045 |  |
| Housing fund |  |  | 7,410 |  |  |  | 7,440 |  |
| Restructuring |  |  | 5,738 |  |  |  | 2,513 |  |
| Accrued professional fees |  |  | 2,805 |  |  |  | 5,123 |  |
| Interest |  |  | 1,902 |  |  |  | 9,336 |  |
| Derivative liabilities |  |  | 1,040 |  |  |  | 1,622 |  |
| Other |  |  | 31,775 |  |  |  | 39,128 |  |
|  |  | $ | 153,302 |  |  | $ | 130,032 |  |
| Other long-term liabilities: |  |  |  |  |  |  |
| Deferred income taxes |  | $ | 59,130 |  |  | $ | 54,268 |  |
| Customer deposits |  |  | 31,250 |  |  |  | 38,750 |  |
| Finance leases |  |  | 12,993 |  |  |  | 13,579 |  |
| Defined benefit pension plan liability |  |  | 2,475 |  |  |  | 2,471 |  |
| Other |  |  | 24,327 |  |  |  | 25,976 |  |
|  |  | $ | 130,175 |  |  | $ | 135,044 |  |

[0000950170-23-060227:notes:53]
On December 22, 2022, land, building, and relevant ancillary assets related to the Company’s former Shanghai E-MS (SH E-MS) manufacturing facility were expropriated by the Chinese government for a compensation fee of Renminbi (RMB) 477.6 million generating a gain on the sale of $51,804. The Company has received 90% of the proceeds as of October 2, 2023 and expects to receive the remaining 10% of the proceeds before December 30, 2023. As of October 2, 2023 and January 2, 2023, the receivable from sale of SH E-MS property was $6,554 and $69,240, respectively.


## us-gaap:GoodwillDisclosureTextBlock

[0000950170-23-060227:notes:54]
[same as prior period, unchanged from 0000950170-23-041297:notes:51]

[0000950170-23-060227:notes:55]
As of October 2, 2023 and January 2, 2023, goodwill by reportable segment was as follows:

[0000950170-23-060227:notes:56]
|  |  | PCB |  |  | RF&S Components |  |  | Total |  |
|  |  | (In thousands) |  |
| Balance as of January 2, 2023 |  |  |  |  |  |  |  |  |  |
| Goodwill |  | $ | 823,837 |  |  | $ | 177,200 |  |  | $ | 1,001,037 |  |
| Accumulated impairment losses |  |  | (171,400 | ) |  |  | (69,200 | ) |  |  | (240,600 | ) |
|  |  |  | 652,437 |  |  |  | 108,000 |  |  |  | 760,437 |  |
| Impairment loss during the three quarters ended October 2, 2023 |  |  | — |  |  |  | (44,100 | ) |  |  | (44,100 | ) |
| Goodwill adjustment during the three quarters ended October 2, 2023 |  |  | (10,787 | ) |  |  | — |  |  |  | (10,787 | ) |
| Derecognition of goodwill due to sale of subsidiary |  |  | (2,815 | ) |  |  | — |  |  |  | (2,815 | ) |
| Balance as of October 2, 2023 |  |  |  |  |  |  |  |  |  |
| Goodwill |  |  | 810,235 |  |  |  | 177,200 |  |  |  | 987,435 |  |
| Accumulated impairment losses |  |  | (171,400 | ) |  |  | (113,300 | ) |  |  | (284,700 | ) |
|  |  | $ | 638,835 |  |  | $ | 63,900 |  |  | $ | 702,735 |  |

[0000950170-23-060227:notes:57]
The Company evaluates its goodwill on an annual basis during its fourth fiscal quarter and at other times when events or changes in circumstances – such as significant adverse changes in the business climate or operating results or changes in management strategy, coupled with a decline in the market price of its stock and market capitalization – indicate that there may be a potential impairment. The Company assesses qualitative factors to determine whether it is more likely than not that the fair value of a reporting unit is less than its carrying amount or performs a quantitative impairment test.

[0000950170-23-060227:notes:58]
During the third quarter of 2023, the Company experienced lower than anticipated results, lower forecasted sales in future years, and a continued decline in sales in the RF and Specialty Components (RF&S Components) reporting unit. The Company considered these factors to be indicators of potential impairment requiring the Company to test the related goodwill for impairment. As of October 2, 2023, the Company completed a quantitative goodwill impairment analysis related to its RF&S Components reporting unit by comparing the fair value of the reporting unit with its carrying amount. In making this assessment, management relies on a number of factors, including expected future operating results, business plans, economic projections, anticipated future cash flows, business trends and declines in the Company’s market capitalization. The Company determined the fair value of the reporting unit by using both a discounted cash flow (DCF) and a market approach. Under the market approach, the Company used revenue and earnings multiples based on comparable industry multiples to estimate the fair value of the reporting unit. If the carrying amount of a reporting unit exceeds the reporting unit’s fair value, the amount by which the carrying value exceeds the fair value is recognized as an impairment loss.

[0000950170-23-060227:notes:59]
Under the DCF approach, the Company estimated the future cash flows, as well as selected a risk-adjusted discount rate to measure the present value of the anticipated cash flows. When determining future cash flow estimates, the Company considered historical results adjusted to reflect current and anticipated future operating conditions. The Company estimated cash flows for the reporting unit over a discrete period and a terminal period (considering expected long-term growth rates and trends).

[0000950170-23-060227:notes:60]
Based on its analysis, the Company determined that the fair value of the RF&S Components reporting unit was less than its carrying value and recorded a non-cash goodwill impairment charge of $44,100 during the quarter ended October 2, 2023. If the Company's future cash flow projections and other fair value assumptions for its reporting unit change, the Company’s goodwill may be subject to potential additional impairment charges in subsequent quarters. Estimating the fair value of the reporting unit requires the Company to make assumptions and estimates in such areas as future economic conditions, industry-specific conditions, product pricing, and necessary capital expenditures. The use of different assumptions or estimates for future cash flows, discount rates, or terminal growth rates could produce substantially different estimates of the fair value of the reporting unit.

[0000950170-23-060227:notes:61]
In addition, the Company decreased goodwill by $10,787 during the three quarters ended October 2, 2023 due to an adjustment to the estimate of fair value for identifiable intangible assets and deferred taxes. Goodwill recognized as a result of the acquisition of Telephonics was finalized during the second quarter of 2023. See Note 2, Acquisition of Gritel and ISC Farmingdale Corp., for further information.


## us-gaap:IntangibleAssetsDisclosureTextBlock

[0000950170-23-060227:notes:62]
[same as prior period, unchanged from 0000950170-23-041297:notes:55]

[0000950170-23-060227:notes:63]
As of October 2, 2023 and January 2, 2023, the components of definite-lived intangibles were as follows:

[0000950170-23-060227:notes:64]
|  |  | GrossAmount |  |  | AccumulatedAmortization |  |  | NetCarryingAmount |  |  | WeightedAverageAmortizationPeriod |  |
|  |  | (In thousands) |  |  | (In years) |  |
| October 2, 2023 |  |  |  |  |  |  |  |  |  |  |  |  |
| Customer relationships |  | $ | 416,230 |  |  | $ | (213,274 | ) |  | $ | 202,956 |  |  |  | 11.2 |  |
| Technology |  |  | 66,650 |  |  |  | (24,942 | ) |  |  | 41,708 |  |  |  | 8.2 |  |
| Backlog |  |  | 13,000 |  |  |  | (8,125 | ) |  |  | 4,875 |  |  |  | 2.0 |  |
| Trade names |  |  | 2,500 |  |  |  | (1,563 | ) |  |  | 937 |  |  |  | 2.0 |  |
|  |  | $ | 498,380 |  |  | $ | (247,904 | ) |  | $ | 250,476 |  |  |  |  |
| January 2, 2023 |  |  |  |  |  |  |  |  |  |  |  |  |
| Customer relationships |  | $ | 366,071 |  |  | $ | (187,560 | ) |  | $ | 178,511 |  |  |  | 11.3 |  |
| Technology |  |  | 47,650 |  |  |  | (24,876 | ) |  |  | 22,774 |  |  |  | 9.5 |  |
| Acquired intangibles from acquisition |  |  |  |  |  |  |  |  |  |  |  |  |
| Customer relationships |  |  | 82,500 |  |  |  | (3,173 | ) |  |  | 79,327 |  |  |  | 13.0 |  |
| Trade names |  |  | 8,250 |  |  |  | (825 | ) |  |  | 7,425 |  |  |  | 5.0 |  |
|  |  | $ | 504,471 |  |  | $ | (216,434 | ) |  | $ | 288,037 |  |  |  |  |

[0000950170-23-060227:notes:65]
[same as prior period, unchanged from 0000950170-23-041297:notes:58]

[0000950170-23-060227:notes:66]
Definite-lived intangibles are amortized using the straight-line method of amortization over the useful life. Amortization expense was $13,764 and $11,657 for the quarters ended October 2, 2023 and October 3, 2022, respectively, and $47,811 and $30,973 for the three quarters ended October 2, 2023 and October 3, 2022, respectively. For the quarter and three quarters ended October 2, 2023, $2,335 and $10,566, respectively, of amortization expense is included in cost of goods sold. For the quarter and three quarters ended October 3, 2022, $1,384 and $4,151, respectively, of amortization expense is included in cost of goods sold.

[0000950170-23-060227:notes:67]
[same as prior period, unchanged from 0000950170-23-041297:notes:60]

[0000950170-23-060227:notes:68]
|  |  | (In thousands) |  |
| Remaining 2023 |  | $ | 13,766 |  |
| 2024 |  |  | 44,892 |  |
| 2025 |  |  | 36,897 |  |
| 2026 |  |  | 36,897 |  |
| 2027 |  |  | 34,543 |  |
| Thereafter |  |  | 83,481 |  |
|  |  | $ | 250,476 |  |


## us-gaap:LongTermDebtTextBlock

[0000950170-23-060227:notes:69]
(8) Long-term Debt and Letters of Credit

[0000950170-23-060227:notes:70]
The following table summarizes the long-term debt of the Company as of October 2, 2023 and January 2, 2023:

[0000950170-23-060227:notes:71]
|  |  | Interest Rate as ofOctober 2, 2023 |  |  |  | PrincipalOutstandingas ofOctober 2, 2023 |  |  | Interest Rate as ofJanuary 2, 2023 |  |  |  | PrincipalOutstandingas ofJanuary 2, 2023 |  |
|  |  | (In thousands, except interest rates) |  |
| Senior Notes due March 2029 |  |  | 4.00 |  | % |  | $ | 500,000 |  |  |  | 4.00 |  | % |  | $ | 500,000 |  |
| Term Loan due May 2030 |  |  | 8.07 |  |  |  |  | 349,125 |  |  |  | — |  |  |  |  | — |  |
| Asia ABL Revolving Loan due June 2028 |  |  | 6.62 |  |  |  |  | 30,000 |  |  |  | 5.79 |  |  |  |  | 30,000 |  |
| Term Loan due September 2024 |  |  | — |  |  |  |  | — |  |  |  | 6.89 |  |  |  |  | 405,879 |  |
|  |  |  |  |  |  |  | 879,125 |  |  |  |  |  |  |  | 935,879 |  |
| Less: Long-term debt unamortized debt issuance costs |  |  |  |  |  |  | (8,312 | ) |  |  |  |  |  |  | (6,080 | ) |
| Long-term debt unamortized discount |  |  |  |  |  |  | (3,364 | ) |  |  |  |  |  |  | (392 | ) |
|  |  |  |  |  |  |  | 867,449 |  |  |  |  |  |  |  | 929,407 |  |
| Less: current maturities |  |  |  |  |  |  | (2,625 | ) |  |  |  |  |  |  | (50,000 | ) |
| Long-term debt, less current maturities |  |  |  |  |  | $ | 864,824 |  |  |  |  |  |  | $ | 879,407 |  |

[0000950170-23-060227:notes:72]
Term Loan Facility

[0000950170-23-060227:notes:73]
On May 30, 2023, pursuant to an Amended & Restated Term Loan Credit Agreement by and among the Company, JPMorgan Chase Bank, N.A., as Administrative Agent, and the several lenders from time to time parties thereto (Term Loan Credit Agreement), the Company closed its $350,000 senior secured Term Loan due 2030 (Term Loan Facility). This Term Loan Facility had an outstanding balance of $349,125 as of October 2, 2023, of which $2,625 is included in short-term debt and $346,500 is included in long-term debt. The Term Loan Facility was issued with a 1.0% original issue discount and bears interest at a floating rate of 1-month CME Term SOFR plus an applicable margin of 2.75%. There is no provision, other than an event of default, for the interest margin to increase. The Company is required to make quarterly principal repayments in an aggregate annual amount equal to 1% of the initial aggregate principal amount of the Term Loan Facility. Such principal repayment is payable quarterly on January 1, April 1, July 1, and October 1 and ending with the last such day to occur prior to May 30, 2030. The remaining principal under the Term Loan Facility is scheduled to mature on May 30, 2030. In addition, the Term Loan Credit Agreement permits the Company to add one or more senior secured incremental term loan facilities to the Term Loan Facility subject to the satisfaction of certain conditions.

[0000950170-23-060227:notes:74]
The Company used $234,818 under the Term Loan Facility and $115,182 of cashless rollover from continuing lenders, together with cash on hand, to refinance the full amount of indebtedness outstanding under the Company’s previous Term Loan Facility that was due to mature in 2024, as well as to pay related fees and expenses.

[0000950170-23-060227:notes:75]
The obligations under the Term Loan Facility are unconditionally guaranteed by each Subsidiary Guarantor of the Company, subject to certain exceptions (Guarantors). The Term Loan Facility is secured by (i) a perfected first priority security interest in substantially all of the assets of the Company and the Guarantors (other than the U.S. ABL Priority Collateral (as defined below)), including all of the total outstanding voting capital stock held by the Company and the Guarantors (subject to a limitation of 65% on pledges of such capital stock of certain foreign subsidiaries and domestic holding companies of foreign subsidiaries) and (ii) a perfected second priority interest in all of the U.S. ABL Priority Collateral. The Term Loan Facility is structurally senior to the Company’s Senior Notes due 2029.

[0000950170-23-060227:notes:76]
Asset-Based Lending Agreements

[0000950170-23-060227:notes:77]
The Company amended and restated its U.S. Asset-Based Lending Credit Agreement (U.S. ABL) on May 30, 2023 and its Asia Asset-Based Lending Credit Agreement (Asia ABL) on June 14, 2023. Both agreements were amended for the benchmark interest rate and margins and maturity was extended to May 2028 and June 2028 for the U.S. ABL and the Asia ABL, respectively.

[0000950170-23-060227:notes:78]
The U.S. ABL is comprised of a revolving credit facility for up to $150,000 and a sublimit for letter of credit for up to $50,000, provided that at no time may amounts outstanding under the agreement exceed in the aggregate $150,000 or the applicable borrowing base, which is the sum of (i) a percentage of the principal amount of “Eligible Accounts”, plus (ii) a percentage of the net orderly liquidation value of (x) “Eligible Inventory”, minus (y) “Inventory Reserves” applicable thereto, minus (iii) “Reserves”, each as defined in the U.S. ABL agreement.

[0000950170-23-060227:notes:79]
Borrowings under the U.S. ABL bear interest at a floating rate of Term SOFR plus a margin ranging from 1.25% to 1.50%. The applicable margin can vary based on the remaining availability of the facility, from 1.25% to 1.50% for Term SOFR-based loans and from 0.25% to 0.50% for JPMorgan Chase Bank’s prime rate-based loans. Other than availability and an event of default, there are no other provisions for the interest margin to increase. The Company is also required to pay certain fees in connection with the U.S. ABL

[0000950170-23-060227:notes:80]
agreement, including unused commitment fees based on the average daily unused portion of the U.S. ABL facility, equal to 0.25% on an annual basis.

[0000950170-23-060227:notes:81]
The U.S. ABL is scheduled to mature on May 30, 2028. The Guarantors have also fully guaranteed the full and timely payment of all obligations in respect of the U.S. ABL. Loans made under the U.S. ABL are secured by a perfected first priority security interest in certain deposit accounts, cash and cash equivalents, accounts receivable and certain U.S. inventory (U.S. ABL Priority Collateral) as well as by a perfected second priority interest in all of the collateral securing the Term Loan Facility.

[0000950170-23-060227:notes:82]
The Asia ABL is comprised of a revolving credit facility for up to $150,000 and a sublimit for letter of credit for up to $100,000, provided that at no time may amounts outstanding under the agreement exceed in aggregate $150,000 or the applicable borrowing base, which is a percentage of the principal amount of Eligible Accounts, as defined in the Asia ABL agreement.

[0000950170-23-060227:notes:83]
Borrowings under the Asia ABL bear interest at a floating rate of Term SOFR plus 1.30%. There is no provision, other than an event of default, for the interest margin to increase. The Company is also required to pay certain fees in connection with the Asia ABL agreement, including unused commitment fees based on the average daily unused portion of the Asia ABL facility, equal to 0.25% on an annual basis.

[0000950170-23-060227:notes:84]
The Asia ABL is scheduled to mature on June 13, 2028. Loans made under the Asia ABL are secured by a portion of the Company’s Asia Pacific cash and receivables and are structurally senior to the Company’s domestic obligations, including the Senior Notes due 2029.

[0000950170-23-060227:notes:85]
As of October 2, 2023, letters of credit in the amount of $6,191 were outstanding under the U.S. ABL and $21,961 were outstanding under the Asia ABL with various maturities through November 2024. Available borrowing capacity under the U.S. ABL and the Asia ABL was $143,809 and $98,039, respectively, which considers letters of credit outstanding as of October 2, 2023.

[0000950170-23-060227:notes:86]
Debt Covenants

[0000950170-23-060227:notes:87]
Borrowings under the Senior Notes due 2029 and Term Loan Facility are subject to certain affirmative and negative covenants, including limitations on indebtedness, corporate transactions, investments, dispositions, and restricted payments.

[0000950170-23-060227:notes:88]
Under the occurrence of certain events, the U.S. Asset-Based Lending Credit Agreement (U.S. ABL) and Asia Asset-Based Lending Credit Agreement (Asia ABL) (collectively, the ABL Revolving Loans), are subject to various financial covenants, including leverage and fixed charge coverage ratios.

[0000950170-23-060227:notes:89]
Debt Issuance and Debt Discount

[0000950170-23-060227:notes:90]
As of October 2, 2023 and January 2, 2023, remaining unamortized debt issuance costs and debt discount for the Senior Notes due 2029 and Term Loan Facility are as follows:

[0000950170-23-060227:notes:91]
|  |  | As of October 2, 2023 |  |  |  | As of January 2, 2023 |
|  |  | DebtIssuance Costs |  |  | DebtDiscount |  |  | EffectiveInterest Rate |  |  |  | DebtIssuance Costs |  |  | DebtDiscount |  |  | EffectiveInterest Rate |  |  |
|  |  | (In thousands, except interest rates) |
| Senior Notes due March 2029 |  | $ | 4,260 |  |  | $ | — |  |  |  | 4.18 |  | % |  | $ | 4,779 |  |  | $ | — |  |  |  | 4.18 |  | % |
| Term Loan due May 2030 |  |  | 4,052 |  |  |  | 3,364 |  |  |  | 8.26 |  |  |  |  | — |  |  |  | — |  |  |  | — |  |  |
| Term Loan due September 2024 |  |  | — |  |  |  | — |  |  |  | — |  |  |  |  | 1,301 |  |  |  | 392 |  |  |  | 4.66 |  |  |
|  |  | $ | 8,312 |  |  | $ | 3,364 |  |  |  |  |  |  | $ | 6,080 |  |  | $ | 392 |  |  |  |  |  |

[0000950170-23-060227:notes:92]
The above debt issuance costs and debt discount are recorded as a reduction of the debt and are amortized into interest expense using an effective interest rate over the duration of the debt.

[0000950170-23-060227:notes:93]
The remaining unamortized debt issuance costs for the ABL Revolving Loans of $1,695 and $792 as of October 2, 2023 and January 2, 2023, respectively, are included in other non-current assets and are amortized to interest expense over the duration of the ABL Revolving Loans using the straight-line method of amortization.

[0000950170-23-060227:notes:94]
As of October 2, 2023, the remaining weighted average amortization period for all unamortized debt issuance costs and debt discount was 6.0 years.

[0000950170-23-060227:notes:95]
Loss on Extinguishment of Debt

[0000950170-23-060227:notes:96]
During the three quarters ended October 2, 2023, the Company recognized loss on extinguishment of debt of $1,154, primarily associated with the write-off of the remaining unamortized debt issuance costs and debt discount as a result of the repayment of the remaining outstanding balance of the Term Loan Facility that was due to mature September 2024.


## us-gaap:IncomeTaxDisclosureTextBlock

[0000950170-23-060227:notes:97]
[same as prior period, unchanged from 0000950170-23-041297:notes:89]

[0000950170-23-060227:notes:98]
[same as prior period, unchanged from 0000950170-23-041297:notes:90]

[0000950170-23-060227:notes:99]
During the quarter and three quarters ended October 2, 2023, the Company’s effective tax rate was impacted by a net discrete benefit of $1,286. This is primarily related to the finalization of the Company’s U.S. and Hong Kong corporate income tax returns, which included adjustments to various income and expense components.

[0000950170-23-060227:notes:100]
[same as prior period, unchanged from 0000950170-23-041297:notes:92]


## us-gaap:SegmentReportingDisclosureTextBlock

[0000950170-23-060227:notes:101]
[same as prior period, unchanged from 0000950170-23-041297:notes:93]

[0000950170-23-060227:notes:102]
[same as prior period, unchanged from 0000950170-23-041297:notes:94]

[0000950170-23-060227:notes:103]
[same as prior period, unchanged from 0000950170-23-041297:notes:95]

[0000950170-23-060227:notes:104]
|  |  | Quarter Ended |  |  | Three Quarters Ended |  |  |
|  |  | October 2, 2023 |  |  | October 3, 2022 |  |  | October 2, 2023 |  |  | October 3, 2022 |  |  |
|  |  | (In thousands) |
| Net Sales: |  |  |  |  |  |  |  |  |  |  |  |  |  |
| PCB (1) |  | $ | 563,676 |  |  | $ | 657,175 |  |  | $ | 1,634,318 |  |  | $ | 1,832,674 |  |  |
| RF&S Components |  |  | 8,906 |  |  |  | 13,905 |  |  |  | 29,210 |  |  |  | 45,216 |  |  |
| Total net sales |  | $ | 572,582 |  |  | $ | 671,080 |  |  | $ | 1,663,528 |  |  | $ | 1,877,890 |  |  |
| Operating Segment (Loss) Income: |  |  |  |  |  |  |  |  |  |  |  |  |  |
| PCB (1) |  | $ | 82,868 |  |  | $ | 89,868 |  |  | $ | 192,981 |  |  | $ | 238,316 |  |  |
| RF&S Components |  |  | (41,441 | ) |  |  | 5,984 |  |  |  | (36,071 | ) |  |  | 18,412 |  |  |
| Corporate and Other (1) |  |  | (37,865 | ) |  |  | (34,417 | ) |  |  | (101,361 | ) |  |  | (112,907 | ) |  |
| Total operating segment income |  |  | 3,562 |  |  |  | 61,435 |  |  |  | 55,549 |  |  |  | 143,821 |  |  |
| Amortization of definite-lived intangibles (2) |  |  | (13,764 | ) |  |  | (11,657 | ) |  |  | (47,811 | ) |  |  | (30,973 | ) |  |
| Total operating (loss) income |  |  | (10,202 | ) |  |  | 49,778 |  |  |  | 7,738 |  |  |  | 112,848 |  |  |
| Total other expense, net |  |  | (7,057 | ) |  |  | (615 | ) |  |  | (25,325 | ) |  |  | (13,079 | ) |  |
| (Loss) income before income taxes |  | $ | (17,259 | ) |  | $ | 49,163 |  |  | $ | (17,587 | ) |  | $ | 99,769 |  |  |

[0000950170-23-060227:notes:105]
|  |  | As of |  |
|  |  | October 2, 2023 |  |  | January 2, 2023 |  |
|  |  | (In thousands) |  |
| Segment Assets: |  |  |  |  |  |  |
| PCB |  | $ | 2,016,088 |  |  | $ | 1,890,723 |  |
| RF&S Components |  |  | 145,364 |  |  |  | 202,619 |  |
| Corporate and Other |  |  | 1,105,050 |  |  |  | 1,230,262 |  |
| Total assets |  | $ | 3,266,502 |  |  | $ | 3,323,604 |  |

[0000950170-23-060227:notes:106]
(2)
Amortization of definite-lived intangibles relates to the PCB and RF&S Components reportable segments. For the quarter and three quarters ended October 2, 2023, $2,335 and $10,566, respectively, of amortization expense is included in cost of goods sold. For the quarter and three quarters ended October 3, 2022, $1,384 and $4,151, respectively, of amortization expense is included in cost of goods sold.

[0000950170-23-060227:notes:107]
During the quarter and three quarters ended October 2, 2023, the Company recorded a non-cash goodwill impairment charge of $44,100 related to its RF&S Components reportable segment.

[0000950170-23-060227:notes:108]
The Corporate and Other category primarily includes operating expenses that are not included in the segment operating performance measures. Corporate and Other consists primarily of corporate governance functions such as finance, accounting, information technology and human resources personnel, as well as global sales and marketing personnel, research and development costs, and acquisition and integration costs associated with acquisitions and divestitures.

[0000950170-23-060227:notes:109]
[same as prior period, unchanged from 0000950170-23-041297:notes:101]

[0000950170-23-060227:notes:110]
|  |  | Quarter Ended |  |  | Three Quarters Ended |  |  |
|  |  | October 2, 2023 |  |  | October 3, 2022 |  |  | October 2, 2023 |  |  | October 3, 2022 |  |  |
|  |  | (In thousands) |
| Net Sales: |  |  |  |  |  |  |  |  |  |  |  |  |  |
| United States |  | $ | 319,105 |  |  | $ | 343,696 |  |  | $ | 949,668 |  |  | $ | 882,577 |  |  |
| China (1) |  |  | 35,376 |  |  |  | 88,280 |  |  |  | 127,653 |  |  |  | 273,068 |  |  |
| Other |  |  | 218,101 |  |  |  | 239,104 |  |  |  | 586,207 |  |  |  | 722,245 |  |  |
| Total net sales |  | $ | 572,582 |  |  | $ | 671,080 |  |  | $ | 1,663,528 |  |  | $ | 1,877,890 |  |  |

[0000950170-23-060227:notes:111]
(1)
Includes Hong Kong

[0000950170-23-060227:notes:112]
[same as prior period, unchanged from 0000950170-23-041297:notes:103]


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0000950170-23-060227:notes:113]
[same as prior period, unchanged from 0000950170-23-041297:notes:104]

[0000950170-23-060227:notes:114]
The following provides a summary of the components of accumulated other comprehensive loss, net of tax, as of October 2, 2023 and January 2, 2023:

[0000950170-23-060227:notes:115]
|  |  | ForeignCurrencyTranslation |  |  | PensionObligation |  |  | Gains (Losses) on Cash FlowHedges |  |  | Total |  |
|  |  | (In thousands) |  |
| Ending balance as of January 2, 2023 |  | $ | (25,984 | ) |  | $ | 1,279 |  |  | $ | (85 | ) |  | $ | (24,790 | ) |
| Other comprehensive (loss) income before reclassifications |  |  | (7,112 | ) |  |  | — |  |  |  | 8,150 |  |  |  | 1,038 |  |
| Amounts reclassified from accumulated other comprehensive loss |  |  | — |  |  |  | — |  |  |  | (1,558 | ) |  |  | (1,558 | ) |
| Other comprehensive (loss) income |  |  | (7,112 | ) |  |  | — |  |  |  | 6,592 |  |  |  | (520 | ) |
| Ending balance as of October 2, 2023 |  | $ | (33,096 | ) |  | $ | 1,279 |  |  | $ | 6,507 |  |  | $ | (25,310 | ) |


## us-gaap:ConcentrationRiskDisclosureTextBlock

[0000950170-23-060227:notes:116]
[same as prior period, unchanged from 0000950170-23-041297:notes:107]

[0000950170-23-060227:notes:117]
[same as prior period, unchanged from 0000950170-23-041297:notes:108]

[0000950170-23-060227:notes:118]
The Company had cash and cash equivalents held by its foreign subsidiaries of $198,286 and $161,708 as of October 2, 2023 and January 2, 2023, respectively. The Company maintains its cash and cash equivalents with major financial institutions and such balances exceed Federal Deposit Insurance Corporation insurance limits. The Company has not experienced any losses in such accounts and believes it is not exposed to any significant risk on cash and cash equivalents.

[0000950170-23-060227:notes:119]
In the normal course of business, the Company extends credit to its customers. Some customers to whom the Company extends credit are located outside the United States. The Company performs on-going credit evaluations of customers, does not require collateral, and considers the credit risk profile of the entity from which the receivable is due in further evaluating collection risk. There were no customers that accounted for 10% or more of accounts receivable as of October 2, 2023. As of January 2, 2023, there was one customer that accounted for 11% of the Company’s accounts receivable.

[0000950170-23-060227:notes:120]
[same as prior period, unchanged from 0000950170-23-041297:notes:111]

[0000950170-23-060227:notes:121]
For the quarter ended October 2, 2023, two customers collectively accounted for approximately 23% of the Company’s net sales. There were no customers that accounted for 10% or more of net sales for the quarter ended October 3, 2022. For the three quarters ended October 2, 2023 and October 3, 2022, one customer accounted for approximately 13% and 10% of the Company’s net sales, respectively.


## us-gaap:FairValueDisclosuresTextBlock

[0000950170-23-060227:notes:122]
[same as prior period, unchanged from 0000950170-23-041297:notes:113]

[0000950170-23-060227:notes:123]
[same as prior period, unchanged from 0000950170-23-041297:notes:114]

[0000950170-23-060227:notes:124]
The carrying amount and estimated fair value of the Company’s financial instruments as of October 2, 2023 and January 2, 2023 were as follows:

[0000950170-23-060227:notes:125]
|  |  | As of |  |  | As of |  |
|  |  | October 2, 2023 |  |  | January 2, 2023 |  |
|  |  | CarryingAmount |  |  | Fair Value |  |  | CarryingAmount |  |  | Fair Value |  |
|  |  | (In thousands) |  |
| Derivative assets, current |  | $ | 4,434 |  |  | $ | 4,434 |  |  | $ | — |  |  | $ | — |  |
| Derivative assets, non-current |  |  | 4,279 |  |  |  | 4,279 |  |  |  | — |  |  |  | — |  |
| Derivative liabilities, current |  |  | 1,040 |  |  |  | 1,040 |  |  |  | 1,622 |  |  |  | 1,622 |  |
| Senior Notes due March 2029 |  |  | 495,740 |  |  |  | 415,865 |  |  |  | 495,221 |  |  |  | 430,165 |  |
| Term Loan due May 2030 |  |  | 341,709 |  |  |  | 349,781 |  |  |  | — |  |  |  | — |  |
| Term Loan due September 2024 |  |  | — |  |  |  | — |  |  |  | 404,186 |  |  |  | 405,628 |  |
| ABL Revolving Loans |  |  | 30,000 |  |  |  | 30,000 |  |  |  | 30,000 |  |  |  | 30,000 |  |

[0000950170-23-060227:notes:126]
[same as prior period, unchanged from 0000950170-23-041297:notes:117]

[0000950170-23-060227:notes:127]
The fair value of the long-term debt was estimated based on quoted market prices or discounting the debt over its life using current market rates for similar debt as of October 2, 2023 and January 2, 2023, which are considered Level 2 inputs.

[0000950170-23-060227:notes:128]
As of October 2, 2023 and January 2, 2023, the Company’s other financial instruments included cash and cash equivalents, accounts receivable, contract assets, accounts payable, and contract liabilities. The carrying amount of these instruments approximates fair value.

[0000950170-23-060227:notes:129]
[same as prior period, unchanged from 0000950170-23-041297:notes:120]

[0000950170-23-060227:notes:130]
As of October 2, 2023, the Company’s goodwill balance related to its RF&S Components reporting unit of $63,900 was measured at fair value on a nonrecurring basis. The Company recorded a non-cash goodwill impairment charge of $44,100 related to its RF&S Components reporting unit during the quarter and three quarters ended October 2, 2023. The fair value of goodwill was determined using both a DCF and a market approach, which are considered Level 3 inputs.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0000950170-23-060227:notes:131]
(14) Commitments and Contingencies

[0000950170-23-060227:notes:132]
Legal Matters

[0000950170-23-060227:notes:133]
The Company is subject to various legal matters, which it considers normal for its business activities. While the Company currently believes that the amount of any reasonably possible loss for known matters would not be material to the Company’s financial condition, the outcome of these actions is inherently difficult to predict. In the event of an adverse outcome, the ultimate potential loss could have a material adverse effect on the Company’s financial condition or results of operations in a particular period. The Company has accrued amounts for its loss contingencies which are probable and estimable as of October 2, 2023 and January 2, 2023 and included as a component of other current liabilities. However, these amounts are not material to the consolidated condensed financial statements of the Company.

[0000950170-23-060227:notes:134]
Offset Agreements

[0000950170-23-060227:notes:135]
The Company has and may continue to enter into industrial cooperation agreements, sometimes referred to as offset agreements, as a condition to obtaining orders for products and services from customers in foreign countries. These agreements are intended to promote investment in the applicable country, and the Company’s obligations under these agreements may be satisfied through activities that do not require the Company to use cash, including transferring technology or providing manufacturing and other consulting support. The obligations under these agreements may also be satisfied through the use of cash for activities such as purchasing supplies from in-country vendors, setting up support centers, research and development investments, acquisitions, and building or leasing facilities for in-country operations. The amount of the offset requirement is determined by contract value awarded

[0000950170-23-060227:notes:136]
and negotiated percentages with customers. As of October 2, 2023, the Company had outstanding offset agreements of approximately $27,963, some of which extend through 2028. Offset programs usually extend over several years and in some cases provide for penalties in the event the Company fails to perform in accordance with contract requirements. Historically, the Company has not paid any such penalties, and as of October 2, 2023, no such penalties have been paid.


## us-gaap:EarningsPerShareTextBlock

[0000950170-23-060227:notes:137]
(15) (Loss) Earnings Per Share

[0000950170-23-060227:notes:138]
The following is a reconciliation of the numerator and denominator used to calculate basic earnings per share and diluted earnings per share for the quarter and three quarters ended October 2, 2023 and October 3, 2022:

[0000950170-23-060227:notes:139]
|  |  | Quarter Ended |  |  | Three Quarters Ended |  |
|  |  | October 2, |  |  | October 3, |  |  | October 2, |  |  | October 3, |  |
|  |  | 2023 |  |  | 2022 |  |  | 2023 |  |  | 2022 |  |
|  |  | (In thousands, except per share amounts) |  |
| Net (loss) income |  | $ | (37,066 | ) |  | $ | 43,528 |  |  | $ | (36,056 | ) |  | $ | 88,566 |  |
| Basic weighted average shares |  |  | 103,510 |  |  |  | 102,196 |  |  |  | 102,873 |  |  |  | 102,016 |  |
| Dilutive effect of performance-based restricted stock units, restricted stock units and stock options |  |  | — |  |  |  | 1,524 |  |  |  | — |  |  |  | 1,720 |  |
| Dilutive effect of outstanding warrants |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 2 |  |
| Diluted shares |  |  | 103,510 |  |  |  | 103,720 |  |  |  | 102,873 |  |  |  | 103,738 |  |
| (Loss) earnings per share: |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  | $ | (0.36 | ) |  | $ | 0.43 |  |  | $ | (0.35 | ) |  | $ | 0.87 |  |
| Diluted |  | $ | (0.36 | ) |  | $ | 0.42 |  |  | $ | (0.35 | ) |  | $ | 0.85 |  |

[0000950170-23-060227:notes:140]
For the quarter and three quarters ended October 2, 2023, potential shares of common stock, consisting of stock options to purchase approximately 60 shares of common stock at exercise prices ranging from $11.83 to $16.60 per share and 697 performance-based restricted stock units (PRUs) were not included in the computation of diluted earnings per share because the Company incurred a net loss and as a result, the impact would be anti-dilutive. For the quarter and three quarters ended October 2, 2023, potential shares of common stock, consisting of 3,533 and 3,204 restricted stock units (RSUs), respectively were not included in the computation of diluted earnings per share because the Company incurred a net loss and as a result, the impact would be anti-dilutive.

[0000950170-23-060227:notes:141]
PRUs, RSUs, and stock options to purchase 41 and 690 shares of common stock for the quarter and three quarters ended October 3, 2022, respectively, were not included in the computation of diluted earnings per share. The PRUs were not included in the computation of diluted earnings per share because the performance conditions had not been met at October 3, 2022, and for RSUs and stock options, the options’ exercise prices or the total expected proceeds under the treasury stock method was greater than the average market price of common stock during the applicable quarter and three quarters and, as a result, the impact would be anti-dilutive.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0000950170-23-060227:notes:142]
[same as prior period, unchanged from 0000950170-23-041297:notes:130]

[0000950170-23-060227:notes:143]
[same as prior period, unchanged from 0000950170-23-041297:notes:131]

[0000950170-23-060227:notes:144]
|  |  | Quarter Ended |  | Three Quarters Ended |
|  |  | October 2, |  |  | October 3, |  |  |  | October 2, |  |  | October 3, |  |  |
|  |  | 2023 |  |  | 2022 |  |  |  | 2023 |  |  | 2022 |  |  |
|  |  | (In thousands) |
| Cost of goods sold |  | $ | 2,212 |  |  | $ | 1,699 |  |  |  | $ | 5,371 |  |  | $ | 4,147 |  |  |
| Selling and marketing |  |  | 888 |  |  |  | 762 |  |  |  |  | 2,327 |  |  |  | 2,032 |  |  |
| General and administrative |  |  | 2,958 |  |  |  | 2,685 |  |  |  |  | 8,197 |  |  |  | 7,134 |  |  |
| Research and development |  |  | 309 |  |  |  | 324 |  |  |  |  | 833 |  |  |  | 818 |  |  |
| Stock-based compensation expense recognized |  | $ | 6,367 |  |  | $ | 5,470 |  |  |  | $ | 16,728 |  |  | $ | 14,131 |  |  |

[0000950170-23-060227:notes:145]
[same as prior period, unchanged from 0000950170-23-041297:notes:133]

[0000950170-23-060227:notes:146]
The following is a summary of total unrecognized compensation costs as of October 2, 2023:

[0000950170-23-060227:notes:147]
|  |  | Unrecognized Stock-Based Compensation Cost |  |  | Remaining Weighted AverageRecognition Period |  |
|  |  | (In thousands) |  |  | (In years) |  |
| RSU awards |  | $ | 41,382 |  |  |  | 1.6 |  |
| PRU awards |  |  | 2,919 |  |  |  | 1.6 |  |
|  |  | $ | 44,301 |  |  |  |  |


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0000950170-23-060227:notes:148]
[same as prior period, unchanged from 0000950170-23-041297:notes:136]

[0000950170-23-060227:notes:149]
On February 8, 2023, the Company announced a consolidation plan, which includes closing three of its manufacturing facilities and consolidating the operations of those facilities into other Company facilities. The three manufacturing facilities are PCB operations located in Anaheim and Santa Clara, California, and Hong Kong. As of October 2, 2023, the Company has ceased operations at the Hong Kong and Anaheim manufacturing facilities. The Company expects the Santa Clara facility to cease operations by the end of 2023. The Company expects to record between $22,000 and $28,000 in separation, accelerated depreciation and disposal costs related to this restructuring during 2023. Approximately 80% of these costs are expected to be in the form of cash expenditures and the rest in the form of non-cash charges. As of October 2, 2023, the Company has incurred approximately $15,525 of restructuring charges and $3,374 of accelerated depreciation expense since the February 8, 2023 announcement.

[0000950170-23-060227:notes:150]
In addition to this consolidation plan, the Company recognized employee separation, contract termination and other costs during the quarter and three quarters ended October 2, 2023 and October 3, 2022 in connection with other global realignment restructuring efforts. Contract termination and other costs primarily represented plant closure costs.

[0000950170-23-060227:notes:151]
The below table summarizes such restructuring costs by reportable segment for the quarter and three quarters ended October 2, 2023 and October 3, 2022:

[0000950170-23-060227:notes:152]
|  |  | Quarter Ended October 2, 2023 |  |  | Three Quarters Ended October 2, 2023 |  |  |
|  |  | EmployeeSeparation/Severance |  |  | ContractTerminationand OtherCosts |  |  | Total |  |  | EmployeeSeparation/Severance |  |  | ContractTerminationand OtherCosts |  |  | Total |  |  |
|  |  | (In thousands) |  |  |
| Reportable Segment: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| PCB |  | $ | 1,924 |  |  | $ | 2,167 |  |  | $ | 4,091 |  |  | $ | 13,066 |  |  | $ | 5,352 |  |  | $ | 18,418 |  |  |
| RF&S Components |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 14 |  |  |  | — |  |  |  | 14 |  |  |
| Corporate and Other |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 305 |  |  |  | 324 |  |  |  | 629 |  |  |
|  |  | $ | 1,924 |  |  | $ | 2,167 |  |  | $ | 4,091 |  |  | $ | 13,385 |  |  | $ | 5,676 |  |  | $ | 19,061 |  |  |

[0000950170-23-060227:notes:153]
|  |  | Quarter Ended October 3, 2022 |  |  | Three Quarters Ended October 3, 2022 |  |  |
|  |  | EmployeeSeparation/Severance |  |  | ContractTerminationand OtherCosts |  |  | Total |  |  | EmployeeSeparation/Severance |  |  | ContractTerminationand OtherCosts |  |  | Total |  |  |
|  |  | (In thousands) |  |  |
| Reportable Segment: (1) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| PCB |  | $ | — |  |  | $ | 506 |  |  | $ | 506 |  |  | $ | — |  |  | $ | 849 |  |  | $ | 849 |  |  |
| Corporate and Other |  |  | — |  |  |  | 121 |  |  |  | 121 |  |  |  | 31 |  |  |  | 387 |  |  |  | 418 |  |  |
|  |  | $ | — |  |  | $ | 627 |  |  | $ | 627 |  |  | $ | 31 |  |  | $ | 1,236 |  |  | $ | 1,267 |  |  |

[0000950170-23-060227:notes:154]
(1)
There were no restructuring costs incurred for RF&S Components reportable segment during the quarter and three quarters ended October 3, 2022.

[0000950170-23-060227:notes:155]
Accrued restructuring costs are included as a component of other current liabilities in the consolidated condensed balance sheet. The below table shows the utilization of the accrued restructuring costs during the three quarters ended October 2, 2023:

[0000950170-23-060227:notes:156]
|  |  | EmployeeSeparation/Severance |  |  | ContractTerminationand OtherCosts |  |  | Total |  |
|  |  | (In thousands) |  |
| Accrued as of January 2, 2023 |  | $ | 2,510 |  |  | $ | 3 |  |  | $ | 2,513 |  |
| Charged to expense |  |  | 13,385 |  |  |  | 5,676 |  |  |  | 19,061 |  |
| Amount paid, net of government contributions eligible for offsetting |  |  | (10,980 | ) |  |  | (4,856 | ) |  |  | (15,836 | ) |
| Accrued as of October 2, 2023 |  | $ | 4,915 |  |  | $ | 823 |  |  | $ | 5,738 |  |


## us-gaap:TreasuryStockTextBlock

[0000950170-23-060227:notes:157]
(18) Share Repurchase Program

[0000950170-23-060227:notes:158]
On May 3, 2023, the Company's Board of Directors authorized and approved a share repurchase program (the “2023 Repurchase Program”), under which the Company may repurchase up to $100,000 in value of the Company’s outstanding shares of common stock from time to time through May 3, 2025. The Company may repurchase shares through open market purchases, privately-negotiated transactions, or otherwise in accordance with applicable federal securities laws, including Rule 10b-18 of the Securities Exchange Act of 1934, as amended (Exchange Act), which sets certain restrictions on the method, timing, price and volume of open market stock repurchases. In addition, the Company expects to adopt one or more trading plans in accordance with Rule 10b5-1 of the Exchange Act to facilitate certain purchases that may be effected under the share repurchase program. The timing, manner, price and amount of any repurchases will be determined at the Company’s discretion, and the share repurchase program may be suspended, terminated or modified at any time for any reason. The repurchase program does not obligate the Company to acquire any specific number of shares.

[0000950170-23-060227:notes:159]
During the quarter and three quarters ended October 2, 2023, the Company repurchased 1,020 shares of common stock for a total cost of approximately $14,617 (including commissions). As of October 2, 2023, the remaining amount in value available to be repurchased under the 2023 Repurchase Program was approximately $85,383.


## us-gaap:FinancialInstrumentsDisclosureTextBlock

[0000950170-23-060227:notes:160]
(19) Financial Instruments

[0000950170-23-060227:notes:161]
Derivatives

[0000950170-23-060227:notes:162]
Interest Rate Swaps

[0000950170-23-060227:notes:163]
The Company’s business is exposed to risk resulting from fluctuations in interest rates on certain SOFR-based variable rate debt. Increases in interest rates increase interest expenses relating to the outstanding variable rate borrowings and increase the cost of debt. Fluctuations in interest rates can also lead to significant fluctuations in the fair value of the debt obligations.

[0000950170-23-060227:notes:164]
On March 23, 2023, the Company entered into a four-year pay-fixed, receive floating (1-month CME Term SOFR), interest rate swap arrangement with a notional amount of $250,000 for the period beginning April 1, 2023 and ending on April 1, 2027. Under the terms of the interest rate swap, the Company pays a fixed rate of 3.49% against a portion of its Term SOFR-based debt and receives a floating 1-month CME Term SOFR during the swap period.

[0000950170-23-060227:notes:165]
At inception, the Company designated the interest rate swap as a cash flow hedge and the fair value of the interest rate swap was zero. As of October 2, 2023, the fair value of the interest rate swap was recorded as an asset, of which $4,434 is included as a component of prepaid expenses and other current assets and $4,279 is included as a component of deposits and other non-current assets. The change in the fair value of the interest rate swap is recorded as a component of accumulated other comprehensive loss, net of tax in the Company's consolidated condensed balance sheets. No ineffectiveness was recognized for the quarter and three quarters ended October 2, 2023. The interest rate swap decreased interest expense by $1,116 and $2,084 for the quarter and three quarters ended October 2, 2023, respectively.

[0000950170-23-060227:notes:166]
Foreign Exchange Contracts

[0000950170-23-060227:notes:167]
The Company’s foreign subsidiaries may at times purchase forward exchange contracts to manage their foreign currency risks in relation to certain purchases of machinery denominated in foreign currencies other than the Company’s functional currencies. The notional amount of the foreign exchange contracts was $1,925 (Euro (EUR) 1.8 million) and $1,625 (EUR 1.4 million) as of October 2, 2023 and January 2, 2023, respectively. The Company has designated certain of these foreign exchange contracts as cash flow hedges.

[0000950170-23-060227:notes:168]
Commodity Price Risk Management

[0000950170-23-060227:notes:169]
The Company uses various raw materials in the manufacturing of PCBs. Copper clad laminates (CCLs), a key raw material for the manufacture of PCBs, are made from epoxy resin, glass cloth and copper foil. The Company only buys a small amount of copper directly. However, copper is a major driver of laminate cost. The Company enters into commodity contracts to hedge copper as a proxy for hedging laminate. As of October 2, 2023, the Company has commodity contracts with a notional quantity of (i) 0.7 metric tonnes for the period beginning October 1, 2023 and ending on December 31, 2023, (ii) 0.7 metric tonnes for the period beginning January 1, 2024 and ending on March 31, 2024, (iii) 0.6 metric tonnes for the period beginning April 1, 2024 and ending on June 30, 2024, and (iv) 0.6 metric tonnes for the period beginning July 1, 2024 and ending on September 30, 2024. As of October 2, 2023, the fair value of the commodity contracts was recorded as a liability in the amount of $997 and included as a component of other current liabilities. The changes in the fair value of these commodity contracts are recorded in cost of goods sold in the consolidated condensed statements of operations. The commodity contracts increased cost of goods sold by $997 and $1,152 for the quarter and three quarters ended October 2, 2023, respectively. The commodity contracts increased cost of goods sold by $1,204 and $5,011 for the quarter and three quarters ended October 3, 2022, respectively. These commodity contracts are not designated as accounting hedges.

[0000950170-23-060227:notes:170]
The fair values of derivative instruments in the consolidated condensed balance sheets are as follows:

[0000950170-23-060227:notes:171]
|  |  |  |  | Asset/(Liability) Fair Value |  |
|  |  | Balance Sheet Location |  | October 2, 2023 |  |  | January 2, 2023 |  |
|  |  |  |  | (In thousands) |  |
| Cash flow derivative instruments designated as hedges: |  |  |  |  |  |  |
| Interest rate swap |  | Prepaid expenses and other current assets |  | $ | 4,434 |  |  | $ | — |  |
| Interest rate swap |  | Deposits and other non-current assets |  |  | 4,279 |  |  |  | — |  |
| Foreign exchange contracts |  | Other current liabilities |  |  | (43 | ) |  |  | (133 | ) |
| Cash flow derivative instruments not designated as hedges: |  |  |  |  |  |  |
| Commodity contracts |  | Other current liabilities |  |  | (997 | ) |  |  | (1,489 | ) |

[0000950170-23-060227:notes:172]
The following table provides information about the amounts recorded in accumulated other comprehensive loss related to derivatives designated as cash flow hedges, as well as the amounts recorded in each caption in the consolidated condensed statements of operations when derivative amounts are reclassified out of accumulated other comprehensive loss for the quarter and three quarters ended October 2, 2023 and October 3, 2022:

[0000950170-23-060227:notes:173]
|  |  |  | Quarter Ended October 2, 2023 |  |  | Quarter Ended October 3, 2022 |  |  |
|  |  | FinancialStatement Caption | Gain Recognized in Other Comprehensive Loss |  |  | AmountsReclassifiedinto Income |  |  | Gain Recognizedin OtherComprehensive Income |  |  | AmountsReclassifiedinto Income |  |  |
|  |  |  | (In thousands) |
| Cash flow hedge: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Interest rate swap |  | Interest expense | $ | 3,988 |  |  | $ | (1,116 | ) |  | $ | — |  |  | $ | — |  |  |

[0000950170-23-060227:notes:174]
|  |  |  | Three Quarters Ended October 2, 2023 |  |  | Three Quarters Ended October 3, 2022 |  |  |
|  |  | FinancialStatement Caption | Gain Recognized in Other Comprehensive Loss |  |  | AmountsReclassifiedinto Income |  |  | Gain Recognizedin OtherComprehensive Income |  |  | AmountsReclassifiedinto Income |  |  |
|  |  |  | (In thousands) |
| Cash flow hedge: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Interest rate swap |  | Interest expense | $ | 10,797 |  |  | $ | (2,084 | ) |  |  | 190 |  |  | $ | (4,105 | ) |  |

[0000950170-23-060227:notes:175]
The following table provides a summary of the activity associated with the designated cash flow hedges reflected in accumulated other comprehensive loss for the three quarters ended October 2, 2023 and October 3, 2022:

[0000950170-23-060227:notes:176]
|  |  | Three Quarters Ended |  |  |
|  |  | October 2, |  |  | October 3, |  |  |
|  |  | 2023 |  |  | 2022 |  |  |
|  |  | (In thousands) |
| Beginning balance, net of tax |  | $ | (85 | ) |  | $ | (3,223 | ) |  |
| Changes in fair value gain (loss), net of tax |  |  | 8,150 |  |  |  | 24 |  |  |
| Reclassification to earnings |  |  | (1,558 | ) |  |  | 3,092 |  |  |
| Ending balance, net of tax |  | $ | 6,507 |  |  | $ | (107 | ) |  |
