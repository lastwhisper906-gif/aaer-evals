# TTMI notes — 0001193125-14-295293


## us-gaap:ScheduleOfOtherDerivativesNotDesignatedAsHedgingInstrumentsStatementsOfFinancialPerformanceAndFinancialPositionLocationTableTextBlock

[0001193125-14-295293:notes:1]
[same as prior period, unchanged from 0001193125-14-184523:notes:1]

[0001193125-14-295293:notes:2]
|  |  | For the Quarter Ended |  |  | For the Two Quarters Ended |  |
|  |  | June 30, 2014 |  |  | July 1, 2013 |  |  | June 30, 2014 |  |  | July 1, 2013 |  |
|  |  | (In thousands) |  |
| Derivative instruments not designated as hedges: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Foreign exchange contracts |  | $ | 432 |  |  | $ | (134 | ) |  | $ | 954 |  |  | $ | (665 | ) |
| Interest rate swap |  |  | — |  |  |  | 143 |  |  |  | — |  |  |  | 620 |  |
|  |  | $ | 432 |  |  | $ | 9 |  |  | $ | 954 |  |  | $ | (45 | ) |


## us-gaap:ReconciliationOfOperatingProfitLossFromSegmentsToConsolidatedTextBlock

[0001193125-14-295293:notes:3]
|  |  | Quarter Ended |  |  | Two Quarters Ended |  |
|  |  | June 30, 2014 |  |  | July 1, 2013 |  |  | June 30, 2014 |  |  | July 1, 2013 |  |
|  |  | (In thousands) |  |
| Net Sales: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Asia Pacific |  | $ | 166,699 |  |  | $ | 209,631 |  |  | $ | 332,365 |  |  | $ | 412,214 |  |
| North America |  |  | 131,594 |  |  |  | 129,669 |  |  |  | 258,183 |  |  |  | 253,258 |  |
| Total sales |  |  | 298,293 |  |  |  | 339,300 |  |  |  | 590,548 |  |  |  | 665,472 |  |
| Inter-segment sales |  |  | (658 | ) |  |  | (1,279 | ) |  |  | (1,018 | ) |  |  | (2,059 | ) |
| Total net sales |  | $ | 297,635 |  |  | $ | 338,021 |  |  | $ | 589,530 |  |  | $ | 663,413 |  |
| Operating Segment Income (Loss): |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Asia Pacific |  | $ | (1,925 | ) |  | $ | 23,642 |  |  | $ | 1,942 |  |  | $ | 34,767 |  |
| North America |  |  | 7,359 |  |  |  | 7,032 |  |  |  | 10,181 |  |  |  | 10,889 |  |
| Total operating segment income |  |  | 5,434 |  |  |  | 30,674 |  |  |  | 12,123 |  |  |  | 45,656 |  |
| Amortization of definite-lived intangibles |  |  | (2,236 | ) |  |  | (2,327 | ) |  |  | (4,472 | ) |  |  | (4,655 | ) |
| Total operating income |  |  | 3,198 |  |  |  | 28,347 |  |  |  | 7,651 |  |  |  | 41,001 |  |
| Total other expense |  |  | (5,794 | ) |  |  | (5,290 | ) |  |  | (15,901 | ) |  |  | (10,567 | ) |
| (Loss) income before income taxes |  | $ | (2,596 | ) |  | $ | 23,057 |  |  | $ | (8,250 | ) |  | $ | 30,434 |  |


## us-gaap:ScheduleOfAccumulatedOtherComprehensiveIncomeLossTableTextBlock

[0001193125-14-295293:notes:4]
The following provides a summary of the components of
 accumulated other comprehensive income as of June 30, 2014 and
 December 30, 2013:

[0001193125-14-295293:notes:5]
|  |  | Foreign Currency Translation |  |  | Gains (Losses) on Cash Flow Hedges |  |  | Unrealized Gains (Losses) on Available for Sale Securities |  |  | Total |  |
|  |  | (In thousands) |  |
| Ending balance at December 30, 2013 |  | $ | 47,280 |  |  | $ | (1,613 | ) |  | $ | (63 | ) |  | $ | 45,604 |  |
| Other comprehensive income (loss) before reclassifications |  |  | (12,816 | ) |  |  | 120 |  |  |  | (20 | ) |  |  | (12,716 | ) |
| Amounts reclassified from accumulated other comprehensive income |  |  | — |  |  |  | 65 |  |  |  | 83 |  |  |  | 148 |  |
| Other comprehensive (loss) income |  |  | (12,816 | ) |  |  | 185 |  |  |  | 63 |  |  |  | (12,568 | ) |
| Ending balance at June 30, 2014 |  | $ | 34,464 |  |  | $ | (1,428 | ) |  | $ | — |  |  | $ | 33,036 |  |


## us-gaap:ScheduleOfFairValueAssetsAndLiabilitiesMeasuredOnRecurringBasisTableTextBlock

[0001193125-14-295293:notes:6]
At June 30, 2014 and December 30, 2013, the following
 financial assets and liabilities were measured at fair value on a
 recurring basis using the type of inputs shown:

[0001193125-14-295293:notes:7]
|  |  | June 30, 2014 |  |  | Fair Value Measurements Using: |  |
|  |  |  | Level 1 Inputs |  |  | Level 2 Inputs |  |  | Level 3 Inputs |  |
|  |  | (In thousands) |  |
| Money market funds |  | $ | 129,011 |  |  | $ | 129,011 |  |  | $ | — |  |  |  | — |  |
| Foreign exchange derivative assets |  |  | 292 |  |  |  | — |  |  |  | 292 |  |  |  | — |  |
| Foreign exchange derivative liabilities |  |  | 848 |  |  |  | — |  |  |  | 848 |  |  |  | — |  |
|  |  | December 30, 2013 |  |  | Fair Value Measurements Using: |  |
|  |  |  | Level 1 Inputs |  |  | Level 2 Inputs |  |  | Level 3 Inputs |  |
|  |  | (In thousands) |  |
| Money market funds |  | $ | 23,838 |  |  | $ | 23,838 |  |  | $ | — |  |  |  | — |  |
| Available for sale securities |  |  | 148 |  |  |  | 148 |  |  |  | — |  |  |  | — |  |
| Foreign exchange derivative assets |  |  | 657 |  |  |  | — |  |  |  | 657 |  |  |  | — |  |
| Foreign exchange derivative liabilities |  |  | 2,938 |  |  |  | — |  |  |  | 2,938 |  |  |  | — |  |


## us-gaap:ScheduleOfUnrecognizedCompensationCostNonvestedAwardsTableTextBlock

[0001193125-14-295293:notes:8]
The following is a summary of total unrecognized compensation
 costs as of June 30, 2014:

[0001193125-14-295293:notes:9]
|  |  | Unrecognized Stock-Based Compensation Cost |  |  | Remaining Weighted Average Recognition Period |
|  |  | (In thousands) |  |  | (years) |
| PRU awards |  | $ | 1,717 |  |  | 1.7 |
| RSU awards |  |  | 9,712 |  |  | 1.4 |
| Stock option awards |  |  | 17 |  |  | 0.3 |
|  |  | $ | 11,446 |  |  |  |


## us-gaap:ScheduleOfInventoryCurrentTableTextBlock

[0001193125-14-295293:notes:10]
Inventories as of June 30, 2014 and December 30, 2013
 consist of the following:

[0001193125-14-295293:notes:11]
|  |  | As of |  |
|  |  | June 30, 2014 |  |  | December 30, 2013 |  |
|  |  | (In thousands) |  |
| Inventories: |  |  |  |  |  |  |  |  |
| Raw materials |  | $ | 45,380 |  |  | $ | 42,533 |  |
| Work-in-process |  |  | 50,419 |  |  |  | 48,338 |  |
| Finished goods |  |  | 50,314 |  |  |  | 47,274 |  |
|  |  | $ | 146,113 |  |  | $ | 138,145 |  |


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001193125-14-295293:notes:12]
[same as prior period, unchanged from 0001193125-14-184523:notes:14]

[0001193125-14-295293:notes:13]
[same as prior period, unchanged from 0001193125-14-184523:notes:15]

[0001193125-14-295293:notes:14]
The Company enters into foreign currency forward contracts to
 mitigate the impact of changes in foreign currency exchange rates
 and to reduce the volatility of purchases and other obligations
 generated in currencies other than the functional currencies. The
 Company’s foreign subsidiaries may at times purchase forward
 exchange contracts to manage their foreign currency risks in
 relation to certain purchases of machinery denominated in foreign
 currencies other than the Company’s foreign functional
 currency. The notional amount of the foreign exchange contracts as
 of June 30, 2014 and December 30, 2013 was approximately
 $32,864 and $47,000, respectively. The Company has designated
 certain of these foreign exchange contracts as cash flow
 hedges.

[0001193125-14-295293:notes:15]
[same as prior period, unchanged from 0001193125-14-184523:notes:17]

[0001193125-14-295293:notes:16]
|  |  |  |  | Asset / (Liability) Fair Value |  |
|  |  | Balance Sheet Location |  | June 30, 2014 |  |  | December 30, 2013 |  |
|  |  |  |  | (In thousands) |  |
| Cash flow derivative instruments designated as hedges: |  |  |  |  |  |
| Foreign exchange contracts |  | Other accrued expenses |  | $ | — |  |  | $ | (751 | ) |
| Foreign exchange contracts |  | Deposits and other non-current assets |  |  | — |  |  |  | 10 |  |
| Cash flow derivative instruments not designated as hedges: |  |  |  |  |  |  |  |  |
| Foreign exchange contracts |  | Prepaid expenses and other current assets |  |  | 292 |  |  |  | 647 |  |
| Foreign exchange contracts |  | Other accrued expenses |  |  | (232 | ) |  |  | (899 | ) |
| Foreign exchange contracts |  | Other long-term liabilities |  |  | (616 | ) |  |  | (1,288 | ) |
|  |  |  |  | $ | (556 | ) |  | $ | (2,281 | ) |

[0001193125-14-295293:notes:17]
[same as prior period, unchanged from 0001193125-14-184523:notes:19]

[0001193125-14-295293:notes:18]
|  |  |  |  | Quarter Ended |  |
|  |  |  |  | June 30, 2014 |  |  | July 1, 2013 |  |
|  |  |  |  | Effective Portion |  |  | Ineffective Portion |  |  | Effective Portion |  |  | Ineffective Portion |  |
|  |  | Financial Statement Caption |  | Gain/(Loss) Recognized in Other Comprehensive Income |  |  | Gain/(Loss) Reclassified into Income |  |  | Gain/(Loss) Reclassified into Income |  |  | Gain/(Loss) Recognized in Other Comprehensive Income |  |  | Gain/(Loss) Reclassified into Income |  |  | Gain/(Loss) Recognized into Income |  |
|  |  | (In thousands) |  |
| Cash flow hedge: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Foreign currency forward |  | Depreciation expense |  | $ | — |  |  | $ | 40 |  |  | $ | — |  |  | $ | 184 |  |  | $ | — |  |  | $ | — |  |
|  |  |  |  | $ | — |  |  | $ | 40 |  |  | $ | — |  |  | $ | 184 |  |  | $ | — |  |  | $ | — |  |
|  |  |  |  | Two Quarters Ended |  |
|  |  |  |  | June 30, 2014 |  |  | July 1, 2013 |  |
|  |  |  |  | Effective Portion |  |  | Ineffective Portion |  |  | Effective Portion |  |  | Ineffective Portion |  |
|  |  | Financial Statement Caption |  | Gain/(Loss) Recognized in Other Comprehensive Income |  |  | Gain/(Loss) Reclassified into Income |  |  | Gain/(Loss) Reclassified into Income |  |  | Gain/(Loss) Recognized in Other Comprehensive Income |  |  | Gain/(Loss) Reclassified into Income |  |  | Gain/(Loss) Recognized into Income |  |
|  |  | (In thousands) |  |
| Cash flow hedge: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Foreign currency forward |  | Depreciation expense |  | $ | 120 |  |  | $ | 65 |  |  | $ | — |  |  | $ | (197 | ) |  | $ | — |  |  | $ | — |  |
|  |  |  |  | $ | 120 |  |  | $ | 65 |  |  | $ | — |  |  | $ | (197 | ) |  | $ | — |  |  | $ | — |  |

[0001193125-14-295293:notes:19]
The following table provides a summary of the activity
 associated with the designated cash flow hedges reflected in
 accumulated other comprehensive income for the two quarters ended
 June 30, 2014 and July 1, 2013:

[0001193125-14-295293:notes:20]
|  |  | For the Two Quarters Ended |  |
|  |  | June 30, 2014 |  |  | July 1, 2013 |  |
|  |  | (In thousands) |  |
| Beginning balance unrealized loss, net of tax |  | $ | (1,613 | ) |  | $ | (15 | ) |
| Changes in fair value, net of tax |  |  | 120 |  |  |  | (197 | ) |
| Reclassification to earnings |  |  | 65 |  |  |  | — |  |
| Ending balance unrealized loss, net of tax |  | $ | (1,428 | ) |  | $ | (212 | ) |

[0001193125-14-295293:notes:21]
[same as prior period, unchanged from 0001193125-14-184523:notes:23]

[0001193125-14-295293:notes:22]
[same as prior period, unchanged from 0001193125-14-184523:notes:24]

[0001193125-14-295293:notes:23]
The carrying amount and estimated fair value of the
 Company’s financial instruments at June 30, 2014 and
 December 30, 2013 were as follows:

[0001193125-14-295293:notes:24]
|  |  | June 30, 2014 |  |  | December 30, 2013 |  |
|  |  | Carrying Amount |  |  | Fair Value |  |  | Carrying Amount |  |  | Fair Value |  |
|  |  | (In thousands) |  |
| Available for sale securities |  | $ | — |  |  | $ | — |  |  | $ | 148 |  |  | $ | 148 |  |
| Derivative assets, current |  |  | 292 |  |  |  | 292 |  |  |  | 647 |  |  |  | 647 |  |
| Derivative liabilities, current |  |  | 232 |  |  |  | 232 |  |  |  | 1,650 |  |  |  | 1,650 |  |
| Derivative assets, non-current |  |  | — |  |  |  | — |  |  |  | 10 |  |  |  | 10 |  |
| Derivative liabilities, non-current |  |  | 616 |  |  |  | 616 |  |  |  | 1,288 |  |  |  | 1,288 |  |
| Long-term debt |  |  | 321,906 |  |  |  | 320,986 |  |  |  | 370,008 |  |  |  | 369,402 |  |
| Convertible senior notes due 2015 |  |  | 31,129 |  |  |  | 33,030 |  |  |  | 36,568 |  |  |  | 39,960 |  |
| Convertible senior notes due 2020 |  |  | 193,455 |  |  |  | 272,175 |  |  |  | 167,167 |  |  |  | 237,050 |  |

[0001193125-14-295293:notes:25]
[same as prior period, unchanged from 0001193125-14-184523:notes:27]

[0001193125-14-295293:notes:26]
[same as prior period, unchanged from 0001193125-14-184523:notes:28]

[0001193125-14-295293:notes:27]
The fair value of the long-term debt was estimated based on
 discounting the debt over its life using current market rates for
 similar debt as of June 30, 2014 and December 30,
 2013.

[0001193125-14-295293:notes:28]
[same as prior period, unchanged from 0001193125-14-184523:notes:30]

[0001193125-14-295293:notes:29]
As of June 30, 2014 and December 30, 2013, the
 Company’s other financial instruments also included cash and
 cash equivalents, accounts receivable, accounts payable and
 equipment payables. Due to short-term maturities, the carrying
 amount of these instruments approximates fair value.


## us-gaap:ScheduleOfShareBasedCompensationArrangementByShareBasedPaymentAwardPerformanceBasedUnitsVestedAndExpectedToVestTableTextBlock

[0001193125-14-295293:notes:30]
PRUs activity for the two quarters ended June 30, 2014 was
 as follows:

[0001193125-14-295293:notes:31]
|  |  | Shares |  |
|  |  | (In thousands) |  |
| Outstanding target shares at December 30, 2013 |  |  | 353 |  |
| Granted: |  |  |  |  |
| Third tranche of 2012 grant |  |  | 59 |  |
| Second tranche of 2013 grant |  |  | 113 |  |
| First tranche of 2014 grant |  |  | 86 |  |
| Change in units due to annual performance achievement |  |  | (29 | ) |
| Vested |  |  | (90 | ) |
| Forfeitures / cancellations |  |  | (34 | ) |
| Outstanding target shares at June 30, 2014 |  |  | 458 |  |


## us-gaap:FairValueDisclosuresTextBlock

[0001193125-14-295293:notes:32]
[same as prior period, unchanged from 0001193125-14-184523:notes:34]

[0001193125-14-295293:notes:33]
[same as prior period, unchanged from 0001193125-14-184523:notes:35]

[0001193125-14-295293:notes:34]
There were no transfers of financial assets or liabilities
 between Level 1 and Level 2 inputs for the quarter or two quarters
 ended June 30, 2014 and July 1, 2013.


## us-gaap:ConcentrationRiskDisclosureTextBlock

[0001193125-14-295293:notes:35]
(9) Significant
 Customers and Concentration of Credit Risk

[0001193125-14-295293:notes:36]
In the normal course of business, the Company extends credit to
 its customers, which are concentrated primarily in the computer,
 cellular phone, networking and communications, and aerospace and
 defense industries. Most are located outside the United States,
 with the exception of aerospace and defense industries. The Company
 performs ongoing credit evaluations of customers, does not require
 collateral and considers the credit risk profile of the entity from
 which the receivable is due in further evaluating collection
 risk.

[0001193125-14-295293:notes:37]
The Company’s customers include both OEMs and EMS
 companies. The Company’s OEM customers often direct a
 significant portion of their purchases through EMS companies. While
 the Company’s customers include both OEM and EMS providers,
 the Company measures customer concentration based on OEM companies,
 as they are the ultimate end customers.

[0001193125-14-295293:notes:38]
For the quarter ended June 30, 2014 no one customer
 accounted for 10% or more of the Company’s net sales. For the
 quarter ended July 1, 2013 one customer accounted for
 approximately 14% of the Company’s net sales. For the two
 quarters ended June 30, 2014 and July 1, 2013 one
 customer accounted for approximately 12% and 14%, respectively, of
 the Company’s net sales.


## us-gaap:ScheduleOfMaturitiesOfLongTermDebtTableTextBlock

[0001193125-14-295293:notes:39]
The
 calendar maturities of long-term debt through 2016 are as
 follows:

[0001193125-14-295293:notes:40]
|  |  | (In thousands) |  |
| Remaining 2014 |  | $ | 48,102 |  |
| 2015 |  |  | 96,204 |  |
| 2016 |  |  | 177,600 |  |
|  |  | $ | 321,906 |  |


## us-gaap:InventoryDisclosureTextBlock

[0001193125-14-295293:notes:41]
(2)
 Inventories


## us-gaap:ScheduleOfEarningsPerShareBasicAndDilutedTableTextBlock

[0001193125-14-295293:notes:42]
The following is a reconciliation of the numerator and
 denominator used to calculate basic earnings per share and diluted
 earnings per share for the quarter and two quarters ended
 June 30, 2014 and July 1, 2013:

[0001193125-14-295293:notes:43]
|  |  | Quarter Ended |  |  | Two Quarters Ended |  |
|  |  | June 30, 2014 |  |  | July 1, 2013 |  |  | June 30, 2014 |  |  | July 1, 2013 |  |
|  |  | (In thousands, except per share amounts) |  |
| Net (loss) income attributable to TTM Technologies, Inc. stockholders |  | $ | (3,104 | ) |  | $ | 13,137 |  |  | $ | (6,903 | ) |  | $ | 18,289 |  |
| Weighted average shares outstanding |  |  | 83,336 |  |  |  | 82,595 |  |  |  | 83,130 |  |  |  | 82,373 |  |
| Dilutive effect of performance-based stock units, restricted stock units and stock options |  |  | — |  |  |  | 380 |  |  |  | — |  |  |  | 535 |  |
| Diluted shares |  |  | 83,336 |  |  |  | 82,975 |  |  |  | 83,130 |  |  |  | 82,908 |  |
| (Loss) earnings per share attributable to TTM Technologies, Inc. stockholders: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  | $ | (0.04 | ) |  | $ | 0.16 |  |  | $ | (0.08 | ) |  | $ | 0.22 |  |
| Diluted |  | $ | (0.04 | ) |  | $ | 0.16 |  |  | $ | (0.08 | ) |  | $ | 0.22 |  |


## us-gaap:LongTermDebtTextBlock

[0001193125-14-295293:notes:44]
(4) Long-term Debt and
 Letters of Credit

[0001193125-14-295293:notes:45]
The following table summarizes the long-term debt of the
 Company as of June 30, 2014 and December 30,
 2013:

[0001193125-14-295293:notes:46]
|  |  | Average Effective Interest Rate as of June 30, 2014 |  | June 30, 2014 |  |  | Average Effective Interest Rate as of December 30, 2013 |  | December 30, 2013 |  |
|  |  | (In thousands) |  |
| Term loan due September 2016 |  | 2.54% |  | $ | 321,900 |  |  | 2.55% |  | $ | 370,000 |  |
| Other |  | 6.00% |  |  | 6 |  |  | 6.00% |  |  | 8 |  |
|  |  |  |  |  | 321,906 |  |  |  |  |  | 370,008 |  |
| Less: current maturities |  |  |  |  | (96,205 | ) |  |  |  |  | (96,204 | ) |
| Long-term debt, less current maturities |  |  |  | $ | 225,701 |  |  |  |  | $ | 273,804 |  |

[0001193125-14-295293:notes:47]
The calendar maturities of long-term debt through 2016 are as
 follows:

[0001193125-14-295293:notes:48]
Credit
 Agreement

[0001193125-14-295293:notes:49]
In 2012, the Company became a party to a facility agreement
 (Credit Agreement) consisting of a $370,000 senior secured term
 loan (Term Loan), a $90,000 senior secured revolving loan
 (Revolving Loan), and a secured $80,000 letters of credit facility
 (Letters of Credit Facility). The Term Loan and Letters of Credit
 Facility will mature on September 14, 2016. The Revolving Loan
 will mature on March 14, 2016. The Credit Agreement is secured
 by substantially all of the assets of the Company’s Asia
 Pacific operating segment and is senior to all other debt,
 including the convertible senior notes. See Note 5. The Company has
 fully and unconditionally guaranteed the full and timely payment of
 all Credit Agreement related obligations of its Asia Pacific
 operating segment.

[0001193125-14-295293:notes:50]
As of June 30, 2014 and December 30, 2013, the
 remaining unamortized debt issuance costs included in other
 non-current assets was $1,525 and $1,937, respectively, and is
 amortized to interest expense over the term of the Company’s
 Credit Agreement using the effective interest rate method. At
 June 30, 2014, the remaining amortization period for the
 unamortized debt issuance costs was 2.0 years.

[0001193125-14-295293:notes:51]
The Company is also required to pay a commitment fee of
 0.50% per annum on any unused portion of the loan and letters
 of credit facility granted under the Credit Agreement. The Company
 incurred commitment fees related to unused borrowing availability
 of $151 and $95 for the quarters ended June 30, 2014 and
 July 1, 2013, respectively, and $284 and $191 for the two
 quarters ended June 30, 2014 and July 1, 2013,
 respectively. As of June 30, 2014, the outstanding amount of
 the Term Loan under the Credit Agreement was $321,900, of which
 $96,200 is due for repayment through March 2015 and is included as
 short-term debt, with the remaining $225,700 included as long-term
 debt. None of the Revolver was outstanding under the Credit
 Agreement as of June 30, 2014. Available borrowing capacity
 under the Revolving Loan was $90,000 at June 30,
 2014.

[0001193125-14-295293:notes:52]
Other Credit
 Facility

[0001193125-14-295293:notes:53]
Additionally, the Company is party to a revolving loan credit
 facility with a lender in the People’s Republic of China
 (PRC). Under this arrangement, the lender has made available to the
 Company approximately $46,600 in unsecured borrowing with all terms
 of the borrowing to be negotiated at the time the revolver is drawn
 upon. There are no commitment fees on the unused portion of the
 revolver and this arrangement expires in December 2014. As of
 June 30, 2014, the revolver had not been drawn
 upon.

[0001193125-14-295293:notes:54]
Letters of
 Credit

[0001193125-14-295293:notes:55]
The Company has an $80,000 Letters of Credit Facility under the
 Credit Agreement, as mentioned above. As of June 30, 2014,
 letters of credit in the amount of $46,183 were outstanding under
 this Credit Agreement. The Company has other standby letters of
 credit outstanding in the amount of $3,894, as well other unused
 letter of credit facilities in the amount of $24,100. The
 outstanding standby letters of credit and unused letter of credit
 facilities expire between December 31, 2014 and
 February 28, 2015.


## us-gaap:ReclassificationOutOfAccumulatedOtherComprehensiveIncomeTableTextBlock

[0001193125-14-295293:notes:56]
The following provides a summary of reclassifications out of
 accumulated other comprehensive income for the quarter and two
 quarters ended June 30, 2014 and July 1, 2013:

[0001193125-14-295293:notes:57]
|  |  |  |  | Amount Reclassified from Accumulated Other Comprehensive Income |  |
|  |  |  |  | For the Quarter Ended |  |  | For the Two Quarters Ended |  |
| Details about Accumulated Other Comprehensive Income Components |  | Statement of Operations Location |  | June 30, 2014 |  |  | July 1, 2013 |  |  | June 30, 2014 |  |  | July 1, 2013 |  |
| Gain on foreign currency translation |  | Gain on sale of assets, net of tax |  | $ | — |  |  | $ | (14,266 | ) |  | $ | — |  |  | $ | (14,266 | ) |
| Loss on cash flow hedges |  | Depreciation expense, net of tax |  | $ | 40 |  |  | $ | — |  |  | $ | 65 |  |  | $ | — |  |
| Loss on available for sale securities |  | Other, net, net of tax |  | $ | 46 |  |  | $ | 4 |  |  | $ | 83 |  |  | $ | 4 |  |


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0001193125-14-295293:notes:58]
(8) Accumulated Other
 Comprehensive Income

[0001193125-14-295293:notes:59]
Foreign currency translation amounts as of June 30, 2014
 and December 30, 2013 are net of taxes of $2,990 and $3,132,
 respectively.


## us-gaap:EarningsPerShareTextBlock

[0001193125-14-295293:notes:60]
(12) Earnings Per
 Share

[0001193125-14-295293:notes:61]
For the quarter and two quarters ended June 30, 2014,
 potential shares of common stock, consisting of stock options to
 purchase approximately 563 shares of common stock at exercise
 prices ranging from $5.78 to $16.82 per share, 1,729 restricted
 stock units, and 229 performance-based restricted stock units were
 not included in the computation of diluted earnings per share
 because the Company incurred a net loss and, as a result, the
 impact would be anti-dilutive.

[0001193125-14-295293:notes:62]
For the quarter and two quarters ended July 1, 2013,
 performance-based stock units, restricted stock units and stock
 options to purchase 2,162 and 2,335 shares of common stock,
 respectively, were not considered in calculating diluted earnings
 per share because the options’ exercise prices or the total
 expected proceeds under the treasury stock method for
 performance-based stock units, restricted stock units or stock
 options was greater than the average market price of common shares
 during the period and, therefore, the effect would be
 anti-dilutive.

[0001193125-14-295293:notes:63]
For the quarters and two quarters ended June 30, 2014, the
 effect of 27,970 shares of common stock, related to the
 Company’s convertible senior notes and warrants to purchase
 28,020 shares of common stock were not included in the computation
 of dilutive earnings per share because the effect would be
 anti-dilutive. For the quarters and two quarters ended July 1,
 2013, the effect of 10,963 shares of common stock, related to the
 Company’s convertible senior notes and warrants to purchase
 10,963 shares of common stock were not included in the computation
 of dilutive earnings per share because the effect would be
 anti-dilutive.


## us-gaap:RelatedPartyTransactionsDisclosureTextBlock

[0001193125-14-295293:notes:64]
(15) Related Party
 Transactions

[0001193125-14-295293:notes:65]
In the normal course of business, the Company’s foreign
 subsidiaries purchase laminate and prepreg from related parties in
 which a significant shareholder of the Company holds an equity
 interest. The Company purchased laminate and prepreg from these
 related parties in the amount of $13,390 and $18,472 for the
 quarters ended June 30, 2014 and July 1, 2013,
 respectively, and $25,180 and $37,609 for the two quarters ended
 June 30, 2014 and July 1, 2013, respectively.

[0001193125-14-295293:notes:66]
Dongguan Shengyi Electronics Ltd., (SYE) is a related party as
 a significant shareholder of the Company holds an equity interest
 in the parent company of SYE. Subsequent to the Company’s
 sale of its controlling interest in SYE in June 2013, the Company
 began selling PCBs to, and purchasing PCBs from, SYE. Sales to SYE
 for the quarter and two quarters ended June 30, 2014 were
 approximately $9,100 and $19,253, respectively, and $4,009 for both
 the quarter and two quarters ended July 1, 2013. Additionally,
 purchases from SYE for the quarter and two quarters ended
 June 30, 2014 were approximately $201 and $472, respectively.
 There were no purchases from SYE for the quarter or two quarters
 ended July 1, 2013.

[0001193125-14-295293:notes:67]
As of June 30, 2014 and December 30, 2013, the
 Company’s consolidated condensed balance sheet included
 $20,482 and $19,547, respectively, in accounts payable due to, and
 $14,269 and $13,312, respectively, in accounts receivable due from
 related parties for the purchase of laminate and prepreg, and sales
 of PCBs to SYE, as mentioned above.


## us-gaap:ScheduleOfEmployeeServiceShareBasedCompensationAllocationOfRecognizedPeriodCostsTextBlock

[0001193125-14-295293:notes:68]
[same as prior period, unchanged from 0001193125-14-184523:notes:72]

[0001193125-14-295293:notes:69]
|  |  | Quarter Ended |  |  | Two Quarters Ended |  |
|  |  | June 30, 2014 |  |  | July 1, 2013 |  |  | June 30, 2014 |  |  | July 1, 2013 |  |
|  |  | (In thousands) |  |
| Cost of goods sold |  | $ | 199 |  |  | $ | 254 |  |  | $ | 462 |  |  | $ | 557 |  |
| Selling and marketing |  |  | 253 |  |  |  | 335 |  |  |  | 588 |  |  |  | 697 |  |
| General and administrative |  |  | 1,479 |  |  |  | 1,994 |  |  |  | 3,049 |  |  |  | 3,659 |  |
| Stock-based compensation expense recognized |  |  | 1,931 |  |  |  | 2,583 |  |  |  | 4,099 |  |  |  | 4,913 |  |
| Income tax benefit recognized |  |  | (494 | ) |  |  | (684 | ) |  |  | (1,063 | ) |  |  | (1,181 | ) |
| Total stock-based compensation expense after income taxes |  | $ | 1,437 |  |  | $ | 1,899 |  |  | $ | 3,036 |  |  | $ | 3,732 |  |


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0001193125-14-295293:notes:70]
[same as prior period, unchanged from 0001193125-14-184523:notes:74]

[0001193125-14-295293:notes:71]
TTM Technologies, Inc. (the Company or TTM) is a leading global
 provider of time-critical and technologically complex printed
 circuit board (PCB) products and backplane assemblies (PCBs
 populated with electronic components), which serve as the
 foundation of sophisticated electronic products. The Company
 provides advanced technology products and offers a one-stop
 manufacturing solution to customers from engineering support to
 prototype development through final volume production. The Company
 serves a diversified customer base in various markets throughout
 the world, including manufacturers of networking/communications
 infrastructure products, touch screen tablets and smartphones. The
 Company also serves aerospace and defense, high-end computing, and
 industrial/medical industries. The Company’s customers
 include both original equipment manufacturers (OEMs) and electronic
 manufacturing services (EMS) providers.

[0001193125-14-295293:notes:72]
The accompanying consolidated condensed financial statements
 have been prepared by the Company, without audit, pursuant to the
 rules and regulations of the Securities and Exchange Commission
 (SEC). Certain information and disclosures normally included in
 financial statements prepared in accordance with accounting
 principles generally accepted in the United States of America have
 been condensed or omitted pursuant to such rules and regulations.
 These consolidated condensed financial statements reflect all
 adjustments (consisting only of normal recurring adjustments)
 which, in the opinion of management, are necessary to present
 fairly the financial position, the results of operations and cash
 flows of the Company for the periods presented. It is suggested
 that these consolidated condensed financial statements be read in
 conjunction with the consolidated financial statements and the
 notes thereto included in the Company’s most recent Annual
 Report on Form 10-K. The results of operations for the interim
 periods are not necessarily indicative of the results to be
 expected for the full year. The preparation of financial statements
 in accordance with U.S. generally accepted accounting principles
 requires management to make estimates and assumptions that affect
 the amounts reported in the Company’s consolidated condensed
 financial statements and accompanying notes. Actual results could
 differ materially from those estimates. The Company uses a 13-week
 fiscal quarter accounting period with fourth quarter ending on the
 Monday nearest December 31.

[0001193125-14-295293:notes:73]
Recently Issued
 Accounting Standards

[0001193125-14-295293:notes:74]
On May 28, 2014, the Financial Accounting Standards Board
 (FASB) issued Accounting Standards Update No. (ASU) 2014-09,
 Revenue from Contracts with Customers, which requires an
 entity to recognize the amount of revenue to which it expects to be
 entitled for the transfer of promised goods or services to
 customers. The ASU will replace most existing revenue recognition
 guidance in U.S. GAAP when it becomes effective. The new standard
 is effective for the Company on January 1, 2017. Early
 application is not permitted. The standard permits the use of
 either the retrospective or cumulative effect transition method.
 The Company is evaluating the effect that ASU 2014-09 will have on
 its consolidated financial statements and related disclosures. The
 Company has not yet selected a transition method nor has it
 determined the effect of the standard on its ongoing financial
 reporting.

[0001193125-14-295293:notes:75]
In July 2013, the FASB issued an update that would require an
 unrecognized tax benefit, or a portion of an unrecognized benefit,
 to be presented in the financial statements as a reduction to a
 deferred tax asset for a net operating loss carryforward, a similar
 tax loss, or a tax credit carryforward. This update is effective
 for interim and annual periods beginning after December 15,
 2013, with early adoption permitted. The Company adopted the
 amendment on January 1, 2014, and its adoption did not have a
 material impact on its financial statements.


## us-gaap:ScheduleOfShareBasedPaymentAwardStockOptionsValuationAssumptionsTableTextBlock

[0001193125-14-295293:notes:76]
For the two quarters ended June 30, 2014 and July 1,
 2013, the following assumptions were used in determining the fair
 value:

[0001193125-14-295293:notes:77]
|  |  | June 30, 20141 |  |  | July 1, 20132 |  |
| Weighted-average fair value |  | $ | 5.80 |  |  | $ | 6.79 |  |
| Risk-free interest rate |  |  | 0.4 | % |  |  | 0.3 | % |
| Dividend yield |  |  | — |  |  |  | — |  |
| Expected volatility |  |  | 41 | % |  |  | 49 | % |
| Expected term in months |  |  | 23 |  |  |  | 25 |  |

[0001193125-14-295293:notes:78]
[same as prior period, unchanged from 0001193125-14-184523:notes:79]

[0001193125-14-295293:notes:79]
[same as prior period, unchanged from 0001193125-14-184523:notes:80]


## us-gaap:IncomeTaxDisclosureTextBlock

[0001193125-14-295293:notes:80]
[same as prior period, unchanged from 0001193125-14-184523:notes:81]

[0001193125-14-295293:notes:81]
The Company’s effective tax rate was (19.6)% and 40.5%
 for the quarters ended June 30, 2014 and July 1, 2013,
 respectively, and 16.3% and 33.3% for the two quarters ended
 June 30, 2014 and July 1, 2013, respectively. The
 Company’s effective tax rate will generally differ from the
 U.S. federal statutory rate of 35% due to favorable tax rates
 associated with earnings from the Company’s operations in
 lower-tax jurisdictions in China, the apportioned state income tax
 rates, generation of other credits and deductions available to us,
 and certain non-deductible items.

[0001193125-14-295293:notes:82]
During the quarter ended June 30, 2014, the
 Company’s effective tax rate was impacted by losses incurred
 in certain foreign jurisdictions for which no tax benefit was
 recorded as a result of full valuation allowances. During the two
 quarters ended June 30, 2014, the Company’s effective
 tax rate was further impacted by a discrete tax benefit resulting
 from the retroactive approval of the high technology enterprise
 status for certain Chinese subsidiaries within the Company’s
 Asia Pacific operating segment.

[0001193125-14-295293:notes:83]
The Company’s effective tax rate for the quarter and two
 quarters ended July 1, 2013 was impacted by the gain on sale
 of assets in one of the Company’s foreign operations and an
 increase in income earned in higher tax jurisdictions, offset by
 the impact of discrete tax benefits from the extension of federal
 research and development credit laws, and from the approval of
 research and development deduction in China.

[0001193125-14-295293:notes:84]
[same as prior period, unchanged from 0001193125-14-184523:notes:84]


## us-gaap:MinorityInterestDisclosureTextBlock

[0001193125-14-295293:notes:85]
(16) Noncontrolling
 Interest Holdings

[0001193125-14-295293:notes:86]
On June 17, 2013, the Company completed the sale of its
 70.2% controlling equity interest in Dongguan Shengyi Electronics
 Ltd. (SYE) to its noncontrolling partner, Shengyi Technology Co.
 Ltd. (Sytech), for 702,000,000 Chinese RMB or $114,495. The Company
 recognized a gain on the sale of SYE of $17,917. Consideration net
 of cash sold was $67,147.

[0001193125-14-295293:notes:87]
Additionally, the Company acquired Sytech’s 20.0%
 noncontrolling equity interest in Dongguan Meadville Circuits Ltd.
 (DMC) for 180,000,000 Chinese RMB or $29,358. The Company recorded
 a decrease to additional paid-in capital for the difference between
 the purchase price and the carrying value of the noncontrolling
 interest for $71.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001193125-14-295293:notes:88]
[same as prior period, unchanged from 0001193125-14-184523:notes:85]

[0001193125-14-295293:notes:89]
[same as prior period, unchanged from 0001193125-14-184523:notes:86]

[0001193125-14-295293:notes:90]
[same as prior period, unchanged from 0001193125-14-184523:notes:87]

[0001193125-14-295293:notes:91]
The Company records stock-based compensation expense for PRU
 awards granted based on management’s periodic assessment of
 the probability of the PRU awards vesting. For the quarter and two
 quarters ended June 30, 2014, management determined that
 vesting of the PRU awards was probable. PRUs activity for the two
 quarters ended June 30, 2014 was as follows:

[0001193125-14-295293:notes:92]
The fair value for PRUs granted is calculated using a Monte
 Carlo simulation model, as the TSR modifier contains a market
 condition. For the two quarters ended June 30, 2014 and
 July 1, 2013, the following assumptions were used in
 determining the fair value:

[0001193125-14-295293:notes:93]
[same as prior period, unchanged from 0001193125-14-184523:notes:90]

[0001193125-14-295293:notes:94]
The Company granted 73 and 67 restricted stock units during the
 quarters ended June 30, 2014 and July 1, 2013,
 respectively, and 833 and 894 restricted stock units during the two
 quarters ended June 30, 2014 and July 1, 2013,
 respectively. The units granted have a weighted-average fair value
 per unit of $7.96 and $6.96 for the quarters ended June 30,
 2014 and July 1, 2013, respectively, and $8.00 and $8.17 for
 the two quarters ended June 30, 2014 and July 1, 2013,
 respectively. The fair value for restricted stock units granted is
 based on the closing share price of the Company’s common
 stock on the date of grant.

[0001193125-14-295293:notes:95]
[same as prior period, unchanged from 0001193125-14-184523:notes:92]

[0001193125-14-295293:notes:96]
The Company did not grant any stock option awards during the
 quarter or two quarters ended June 30, 2014 and July 1,
 2013.

[0001193125-14-295293:notes:97]
Summary of
 Unrecognized Compensation Costs


## us-gaap:SegmentReportingDisclosureTextBlock

[0001193125-14-295293:notes:98]
[same as prior period, unchanged from 0001193125-14-184523:notes:95]

[0001193125-14-295293:notes:99]
The operating segments reported below are the Company’s
 segments for which separate financial information is available and
 upon which operating results are evaluated by the chief operating
 decision maker to assess performance and to allocate resources. The
 Company manages its worldwide operations based on two geographic
 operating segments: 1) Asia Pacific, which consists of five PCB
 fabrication plants and one drilling facility, and 2) North America,
 which consists of seven domestic PCB fabrication plants, including
 a facility that provides follow-on value-added services primarily
 for one of the PCB fabrication plants, and one backplane assembly
 plant in Shanghai, China, which is managed in conjunction with the
 Company’s U.S. operations. Each segment operates
 predominantly in the same industry with production facilities that
 produce similar customized products for its customers and use
 similar means of product distribution.

[0001193125-14-295293:notes:100]
The Company evaluates segment performance based on operating
 segment income, which is operating income before amortization of
 intangibles. Interest expense and interest income are not presented
 by segment since they are not included in the measure of segment
 profitability reviewed by the chief operating decision maker. All
 inter-segment transactions have been eliminated. Reportable segment
 assets exclude short-term investments, which are managed
 centrally.

[0001193125-14-295293:notes:101]
The Company accounts for inter-segment sales and transfers as
 if the sale or transfer were to third parties: at arms length and
 consistent with the Company’s revenue recognition policy. The
 inter-segment sales for the quarter and the two quarters ended
 June 30, 2014 and July 1, 2013 are sales from the Asia
 Pacific operating segment to the North America operating
 segment.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001193125-14-295293:notes:102]
(11) Commitments and
 Contingencies

[0001193125-14-295293:notes:103]
Legal
 Matters

[0001193125-14-295293:notes:104]
The Company is subject to various legal matters, which it
 considers normal for its business activities. While the Company
 currently believes that the amount of any reasonably possible or
 probable loss for known matters would not be material to the
 Company’s financial condition, the outcome of these actions
 is inherently difficult to predict. In the event of an adverse
 outcome, the ultimate potential loss could have a material adverse
 effect on the Company’s financial condition or results of
 operations in a particular period. The Company has accrued amounts
 for its loss contingencies which are probable and estimable at
 June 30, 2014 and December 30, 2013. However, these
 amounts are not material to the consolidated condensed financial
 statements of the Company.

[0001193125-14-295293:notes:105]
Environmental
 Matters

[0001193125-14-295293:notes:106]
The process to manufacture PCBs requires adherence to city,
 county, state, federal and foreign environmental regulations
 regarding the storage, use, handling and disposal of chemicals,
 solid wastes and other hazardous materials as well as compliance
 with air quality standards. The Company believes that its
 facilities in the United States comply in all material respects
 with applicable environmental laws and regulations. In China,
 governmental authorities are taking various steps to tighten the
 rules and regulations governing environmental issues. An
 update to Chinese environmental law was issued in late 2012, but
 allows for an interim period in which foreign entities may adjust
 to the new regulatory regime and come into full compliance with the
 new laws. The Company’s plants in China are not yet in
 full compliance with the current environmental regulations as
 updated in late 2012. The Company expects to come into
 compliance and does not anticipate any immediate risk of government
 fines or temporary closure of its Chinese plants. The Company
 has established and enacted an investment plan, which includes
 capital expenditures estimated to be approximately $10,000 for
 2014, to address the regulatory changes in order to come into full
 compliance during the interim period.


## ttmi:ScheduleOfComponentsOfInterestExpenseFromConvertibleNotesTableTextBlock

[0001193125-14-295293:notes:107]
The components of interest expense resulting from the
 convertible senior notes for the quarter and two quarters ended
 June 30, 2014 and July 1, 2013 are as follows:

[0001193125-14-295293:notes:108]
|  |  | For the Quarter Ended |  |  | For the Two Quarters Ended |  |
|  |  | June 30, 2014 |  |  | July 1, 2013 |  |  | June 30, 2014 |  |  | July 1, 2013 |  |
|  |  | (In thousands) |  |  | (In thousands) |  |
| Contractual coupon interest |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Convertible senior notes due 2020 |  | $ | 1,094 |  |  | $ | — |  |  | $ | 2,179 |  |  | $ | — |  |
| Convertible senior notes due 2015 |  |  | 263 |  |  |  | 1,422 |  |  |  | 526 |  |  |  | 2,844 |  |
|  |  | $ | 1,357 |  |  | $ | 1,422 |  |  | $ | 2,705 |  |  | $ | 2,844 |  |
| Amortization of debt discount |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Convertible senior notes due 2020 |  | $ | 1,751 |  |  | $ | — |  |  | $ | 3,515 |  |  | $ | — |  |
| Convertible senior notes due 2015 |  |  | 345 |  |  |  | 1,715 |  |  |  | 683 |  |  |  | 3,395 |  |
|  |  | $ | 2,096 |  |  | $ | 1,715 |  |  | $ | 4,198 |  |  | $ | 3,395 |  |
| Amortization of debt issuance costs |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Convertible senior notes due 2020 |  | $ | 175 |  |  | $ | — |  |  | $ | 353 |  |  | $ | — |  |
| Convertible senior notes due 2015 |  |  | 35 |  |  |  | 174 |  |  |  | 69 |  |  |  | 343 |  |
|  |  | $ | 210 |  |  | $ | 174 |  |  | $ | 422 |  |  | $ | 343 |  |


## ttmi:ScheduleOfLiabilityAndEquityComponentsOfConvertibleNotesTableTextBlock

[0001193125-14-295293:notes:109]
As of June 30, 2014 and December 30, 2013, the
 following summarizes the liability and equity components of the
 convertible senior notes:

[0001193125-14-295293:notes:110]
|  |  | As of June 30, 2014 |  |  | As of December 30, 2013 |  |
|  |  | Principal |  |  | Unamortized Discount |  |  | Net Carrying Amount |  |  | Principal |  |  | Unamortized Discount |  |  | Net Carrying Amount |  |
|  |  | (in thousands) |  |
| Liability components: |  |  |  |  |
| Convertible senior notes due 2020 |  | $ | 250,000 |  |  | $ | (56,545 | ) |  | $ | 193,455 |  |  | $ | 220,000 |  |  | $ | (52,833 | ) |  | $ | 167,167 |  |
| Convertible senior notes due 2015 |  |  | 32,395 |  |  |  | (1,266 | ) |  |  | 31,129 |  |  |  | 38,909 |  |  |  | (2,341 | ) |  |  | 36,568 |  |
| Total |  | $ | 282,395 |  |  | $ | (57,811 | ) |  | $ | 224,584 |  |  | $ | 258,909 |  |  | $ | (55,174 | ) |  | $ | 203,735 |  |
|  |  | As of June 30, 2014 |  |  | As of December 30, 2013 |  |
|  |  | Embedded conversion option — Convertible Senior Notes |  |  | Embedded conversion option — Convertible Senior Notes Issuance Costs |  |  | Total |  |  | Embedded conversion option — Convertible Senior Notes |  |  | Embedded conversion option — Convertible Senior Notes Issuance Costs |  |  | Total |  |
|  |  | (in thousands) |  |
| Equity components: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Additional paid-in capital: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Convertible senior notes due 2020 |  | $ | 60,227 |  |  | $ | (1,916 | ) |  | $ | 58,311 |  |  | $ | 53,000 |  |  | $ | (1,644 | ) |  | $ | 51,356 |  |
| Convertible senior notes due 2015 |  |  | 39,781 |  |  | $ | (1,413 | ) |  |  | 38,368 |  |  |  | 39,928 |  |  |  | (1,413 | ) |  |  | 38,515 |  |
|  |  | $ | 100,008 |  |  | $ | (3,329 | ) |  | $ | 96,679 |  |  | $ | 92,928 |  |  | $ | (3,057 | ) |  | $ | 89,871 |  |


## ttmi:ConvertibleSeniorNotesTextBlock

[0001193125-14-295293:notes:111]
[same as prior period, unchanged from 0001193125-14-184523:notes:109]

[0001193125-14-295293:notes:112]
Convertible Senior Notes due 2020

[0001193125-14-295293:notes:113]
In December 2013, the Company issued 1.75% convertible
 senior notes due December 15, 2020, in a public offering for
 an aggregate principal amount of $220,000. The convertible senior
 notes bear interest at a rate of 1.75% per annum. Interest is
 payable semiannually in arrears on June 15 and
 December 15 of each year. The convertible senior notes are
 senior unsecured obligations and rank equally to the
 Company’s future unsecured senior indebtedness and senior in
 right of payment to any of the Company’s future subordinated
 indebtedness.

[0001193125-14-295293:notes:114]
In January 2014, the Company closed the sale of an additional
 $30,000 aggregate principal amount of its 1.75% convertible senior
 notes due 2020 (Additional Notes). The Additional Notes were sold
 pursuant to the exercise of an over-allotment option granted by the
 Company in the underwriting agreement related to the offer and sale
 of $220,000 aggregate principal amount of its 1.75% convertible
 senior notes due 2020.

[0001193125-14-295293:notes:115]
In connection with the offering of the Additional Notes, the
 Company entered into additional convertible note hedge and warrant
 transactions (Additional Call Spread Transaction) with respect to
 shares of its common stock. The additional convertible note hedge,
 which cost an aggregate $7,953 and was recorded, net of tax, as a
 reduction of additional paid-in capital, consists of the
 Company’s option to purchase up to 3,100 common stock shares
 at a price of $9.64 per share and will expire upon the maturity of
 the notes. Additionally, the Company sold warrants to purchase
 3,100 shares of its common stock at a price of $14.26 per
 share. The warrants expire ratably from March 2021 through January
 2022. The proceeds from the sale of warrants of $4,053 was recorded
 as an increase to additional paid-in capital. The 2020 Additional
 Call Spread Transaction has no effect on the terms of the
 convertible senior notes due 2020 and reduces potential dilution by
 effectively increasing the conversion price of the convertible
 senior notes due 2020 to $14.26 per share of the Company’s
 common stock.

[0001193125-14-295293:notes:116]
[same as prior period, unchanged from 0001193125-14-184523:notes:114]

[0001193125-14-295293:notes:117]
Convertible Senior Notes due 2015

[0001193125-14-295293:notes:118]
In May 2008, the Company issued 3.25% convertible senior
 notes due May 15, 2015, in a public offering for an aggregate
 principal amount of $175,000. The convertible senior notes bear
 interest at a rate of 3.25% per annum. Interest is payable
 semiannually in arrears on May 15 and November 15 of each
 year. The convertible senior notes are senior unsecured obligations
 and rank equally to the Company’s future unsecured senior
 indebtedness and senior in right of payment to any of the
 Company’s future subordinated indebtedness.

[0001193125-14-295293:notes:119]
In January 2014, the Company repurchased $6,514 of notes at
 approximately 103.4% of their principal amount. The repurchase of
 the convertible senior notes was accounted for as an extinguishment
 of debt, and accordingly, the Company recognized a $506 loss
 primarily associated with the premium paid to repurchase the
 convertible senior notes and the recognition of certain remaining
 unamortized debt discount and issuance costs.

[0001193125-14-295293:notes:120]
[same as prior period, unchanged from 0001193125-14-184523:notes:118]

[0001193125-14-295293:notes:121]
[same as prior period, unchanged from 0001193125-14-184523:notes:119]

[0001193125-14-295293:notes:122]
As of June 30, 2014 and December 30, 2013, remaining
 unamortized debt issuance costs included in other non-current
 assets were $5,795 and $5,399, respectively. The debt issuance
 costs and debt discount are being amortized to interest expense
 over the term of the convertible senior notes using the effective
 interest rate method. At June 30, 2014, the remaining weighted
 average amortization period for the unamortized senior convertible
 note discount and debt issuance costs was
 6.3 years.

[0001193125-14-295293:notes:123]
For the quarter and two quarters ended June 30, 2014, the
 amortization of debt discount and debt issuance costs for the 2020
 convertible senior notes and the 2015 convertible senior notes is
 based on an effective interest rate of 6.48% and 8.37%,
 respectively. For the quarter and two quarters ended July 1,
 2013, the amortization of debt discount and debt issuance costs for
 the 2015 convertible senior notes is based on an effective interest
 rate of 8.37%.


## ttmi:TangibleAssetImpairmentChargesTextBlock

[0001193125-14-295293:notes:124]
(3) Impairment of
 Long-Lived Assets

[0001193125-14-295293:notes:125]
In conjunction with the closure of its Suzhou, China
 manufacturing facility in 2013, the Company determined that certain
 long-lived assets, primarily consisting of held for sale machinery
 and equipment, were impaired. As a result, the Company recorded a
 charge for the impairment of long-lived assets in the amount of
 $10,782 for the year ended December 30, 2013 and reclassified
 such assets to assets held for sale, which were included in other
 current assets in the December 30, 2013 consolidated balance
 sheet.

[0001193125-14-295293:notes:126]
In the quarter ended June 30, 2014, the Company recorded
 an impairment charge for additional assets, related to the closure
 of the Suzhou, China manufacturing facility, which were originally
 designated to be transferred to other facilities in China as well
 as the disposal of a substantial portion of the assets held for
 sale. As a result, the Company recognized an additional impairment
 charge in the amount of $1,845 as the carrying value of the assets
 was greater than the market value at the date of
 disposal.
