# TTMI 8-K — 0001171843-14-003548 filed 2014-07-30

## item codes, every 8-K on or before 2014-08-05

- 2014-08-05 0001193125-14-295808 — 1.01, 5.02, 9.01
- 2014-07-30 0001171843-14-003548 — 2.02, 9.01
- 2014-04-30 0001171843-14-002017 — 2.02, 9.01
- 2014-04-25 0001193125-14-160146 — 5.02, 5.07, 9.01
- 2014-04-10 0001171843-14-001656 — 2.02, 9.01
- 2014-03-04 0001193125-14-082534 — 4.01, 9.01
- 2014-02-05 0001171843-14-000553 — 2.02, 9.01
- 2014-01-14 0001193125-14-010922 — 1.01, 2.03, 3.02, 8.01, 9.01
- 2013-12-27 0001193125-13-486144 — 5.02, 9.01
- 2013-12-20 0001193125-13-481141 — 1.01, 1.02, 2.03, 3.02, 8.01, 9.01
- 2013-12-17 0001193125-13-476207 — 5.03
- 2013-10-30 0001193125-13-418572 — 2.02, 5.02, 9.01
- 2013-09-12 0001193125-13-365420 — 2.05
- 2013-08-14 0001193125-13-334349 — 7.01, 9.01
- 2013-08-01 0001171843-13-003138 — 2.02, 9.01
- 2013-06-25 0001193125-13-270725 — 5.02, 9.01
- 2013-05-02 0001171843-13-001746 — 2.02, 9.01
- 2013-04-29 0001193125-13-182083 — 5.02, 5.07, 9.01
- 2013-03-18 0001193125-13-111308 — 1.01, 7.01, 9.01
- 2013-03-06 0001193125-13-093625 — 5.02, 9.01
- 2013-03-01 0001193125-13-087439 — 2.02 — amendment of 0001171843-13-000414
- 2013-02-28 0001193125-13-084764 — 5.02
- 2013-02-05 0001171843-13-000414 — 2.02, 9.01
- 2013-01-31 0001193125-13-032848 — 5.02, 9.01
- 2013-01-17 0001193125-13-015928 — 7.01, 9.01
- 2013-01-16 0001193125-13-014581 — 2.02, 9.01
- 2012-12-11 0001193125-12-498644 — 5.02, 9.01
- 2012-11-15 0001193125-12-472451 — 7.01, 9.01
- 2012-11-01 0001171843-12-003890 — 2.02, 9.01
- 2012-09-19 0001193125-12-396969 — 1.01, 2.03, 7.01, 9.01
- 2012-09-11 0001193125-12-388130 — 7.01, 9.01
- 2012-07-31 0001171843-12-002829 — 2.02, 9.01
- 2012-05-15 0001193125-12-233501 — 7.01, 9.01
- 2012-05-01 0001171843-12-001574 — 2.02, 9.01
- 2012-04-27 0001193125-12-191623 — 5.07
- 2012-03-01 0001193125-12-090623 — 2.02 — amendment of 0001171843-12-000382
- 2012-02-07 0001171843-12-000382 — 2.02, 9.01
- 2012-01-19 0001193125-12-016588 — 5.02, 9.01
- 2011-11-15 0000950123-11-098812 — 7.01, 9.01
- 2011-11-02 0001171843-11-003248 — 2.02, 9.01
- 2011-09-28 0000950123-11-087344 — 7.01, 9.01
- 2011-09-19 0000950123-11-085128 — 5.02, 9.01
- 2011-09-15 0000950123-11-084704 — 5.07 — amendment of 0000950123-11-054296
- 2011-08-04 0001171843-11-002356 — 2.02, 9.01
- 2011-07-27 0000950123-11-068987 — 1.01, 2.03, 9.01
- 2011-06-21 0000950123-11-060477 — 7.01, 9.01
- 2011-06-06 0000950123-11-056971 — 5.03, 9.01
- 2011-05-26 0000950123-11-054296 — 5.07
- 2011-05-10 0000950123-11-048462 — 8.01, 9.01
- 2011-05-05 0001171843-11-001344 — 2.02, 9.01
- 2011-03-22 0000950123-11-027824 — 7.01, 9.01
- 2011-03-18 0000950123-11-026913 — 4.01
- 2011-03-18 0000950123-11-026910 — 4.01, 9.01 — amendment, the index does not say of what
- 2011-03-02 0000950123-11-020941 — 5.03, 9.01
- 2011-02-10 0001171843-11-000391 — 2.02, 9.01
- 2011-01-13 0000950123-11-002528 — 7.01, 9.01
- 2011-01-13 0000950123-11-002446 — 2.02, 9.01
- 2010-11-29 0000950123-10-109448 — 4.01, 9.01 — amendment, the index does not say of what
- 2010-11-17 0000950123-10-106706 — 4.01
- 2010-11-15 0000950123-10-105479 — 5.02, 9.01
- 2010-11-04 0001171843-10-002324 — 2.02, 9.01
- 2010-10-22 0000950123-10-095179 — 1.01, 9.01
- 2010-10-04 0000950123-10-090949 — 1.01, 5.03, 9.01
- 2010-08-05 0001171843-10-001587 — 2.02, 9.01
- 2010-08-05 0000950123-10-073258 — 1.01, 2.03, 9.01
- 2010-08-05 0000950123-10-073256 — 9.01 — amendment of 0000950123-10-034163
- 2010-07-12 0000950123-10-064794 — 5.02, 8.01, 9.01
- 2010-06-10 0000950123-10-057166 — 7.01, 9.01
- 2010-06-02 0000950123-10-055111 — 1.01, 5.07, 9.01
- 2010-05-06 0001171843-10-000819 — 2.02, 9.01
- 2010-04-26 0000950123-10-037806 — 8.01, 9.01 — amendment of 0000950123-10-034163
- 2010-04-13 0000950123-10-034163 — 1.01, 2.01, 2.03, 5.02, 7.01, 9.01
- 2010-03-30 0000950123-10-030123 — 1.01, 5.02, 9.01
- 2010-03-24 0000950123-10-027317 — 1.01, 5.02, 9.01
- 2010-03-16 0000950123-10-024853 — 7.01, 9.01 — amendment of 0001171843-10-000140
- 2010-03-15 0000950123-10-024637 — 5.07
- 2010-02-04 0001171843-10-000140 — 2.02, 9.01
- 2010-02-02 0000950123-10-007780 — 8.01, 9.01
- 2010-01-13 0000950123-10-002245 — 7.01, 9.01
- 2009-12-23 0000950123-09-073069 — 1.01, 9.01
- 2009-12-15 0000950123-09-070868 — 8.01, 9.01
- 2009-11-16 0000950123-09-062630 — 1.01, 7.01, 9.01
- 2009-11-04 0001171843-09-001103 — 2.02, 9.01
- 2009-09-04 0000950123-09-041133 — 2.05, 9.01
- 2009-07-29 0001171843-09-000743 — 2.02, 9.01
- 2009-06-09 0000950123-09-012507 — 7.01, 9.01
- 2009-04-30 0001171843-09-000427 — 2.02, 9.01
- 2009-04-28 0001362310-09-005960 — 8.01
- 2009-02-19 0001362310-09-002454 — 5.03, 9.01
- 2009-02-10 0001171843-09-000123 — 2.02, 9.01
- 2009-01-16 0000950153-09-000040 — 2.05, 9.01
- 2009-01-08 0000950153-09-000023 — 7.01, 9.01
- 2008-10-29 0001157523-08-008533 — 2.02, 9.01
- 2008-07-29 0001157523-08-005998 — 2.02, 9.01
- 2008-05-22 0000950153-08-001035 — 1.01, 2.03, 3.02, 9.01
- 2008-05-22 0000950153-08-001034 — 7.01, 9.01
- 2008-05-15 0000950153-08-000987 — 1.01, 1.02, 2.03, 3.02, 9.01
- 2008-04-30 0001157523-08-003483 — 2.02, 9.01
- 2008-02-07 0001157523-08-001077 — 2.02, 9.01
- 2008-01-08 0000950153-08-000033 — 7.01, 9.01
- 2007-11-15 0000950153-07-002440 — 7.01, 9.01
- 2007-11-14 0000950153-07-002426 — 7.01, 9.01
- 2007-11-14 0000950153-07-002421 — 5.03, 9.01
- 2007-10-31 0001157523-07-010491 — 2.02, 9.01
- 2007-10-02 0000950153-07-002094 — 7.01, 9.01
- 2007-07-31 0000950153-07-001622 — 2.02, 9.01
- 2007-06-13 0000950153-07-001327 — 7.01, 9.01
- 2007-05-02 0000950153-07-000941 — 2.02, 9.01
- 2007-04-12 0000950153-07-000763 — 5.02, 9.01
- 2007-02-15 0000950153-07-000339 — 2.02, 9.01
- 2007-01-11 0000950153-07-000076 — 7.01, 9.01
- 2007-01-10 0000950153-07-000071 — 2.01, 9.01 — amendment, the index does not say of what
- 2006-12-11 0000950153-06-002967 — 2.05, 9.01
- 2006-11-15 0000950153-06-002843 — 7.01, 9.01
- 2006-11-14 0000950153-06-002837 — 7.01, 9.01
- 2006-11-02 0000950153-06-002682 — 1.01, 1.02, 2.03, 9.01
- 2006-11-01 0000950153-06-002668 — 2.02, 9.01
- 2006-10-30 0000950124-06-006210 — 2.01, 9.01
- 2006-08-04 0000950153-06-002025 — 1.01, 9.01
- 2006-07-26 0000950153-06-001937 — 2.02, 9.01
- 2006-06-28 0000950153-06-001716 — 1.01, 9.01
- 2006-06-13 0000950153-06-001597 — 7.01, 9.01
- 2006-04-26 0000950153-06-001079 — 2.02, 9.01
- 2006-02-08 0001104659-06-006985 — 2.02, 9.01
- 2006-01-12 0001104659-06-001893 — 7.01, 9.01
- 2005-12-05 0001104659-05-058918 — 1.01, 5.02, 9.01
- 2005-10-26 0001104659-05-050306 — 2.02, 9.01
- 2005-09-20 0001104659-05-044954 — 8.01
- 2005-08-30 0001104659-05-042053 — 3.03, 8.01, 9.01
- 2005-07-27 0001104659-05-034437 — 2.02, 5.02, 9.01
- 2005-07-21 0001104659-05-033462 — 1.01, 1.02, 2.03, 9.01
- 2005-06-13 0001104659-05-027969 — 8.01
- 2005-06-08 0001104659-05-027364 — 7.01, 9.01
- 2005-05-17 0001104659-05-024118 — 7.01, 9.01
- 2005-05-12 0001104659-05-022993 — 7.01, 9.01
- 2005-05-11 0001104659-05-022606 — 1.01, 9.01
- 2005-05-02 0001104659-05-019649 — 2.02, 5.02, 9.01
- 2005-04-26 0001104659-05-018233 — 7.01, 9.01
- 2005-02-08 0001104659-05-004642 — 2.02, 9.01
- 2005-01-12 0001104659-05-001194 — 7.01, 9.01
- 2004-12-22 0001104659-04-040933 — 5.02
- 2004-12-08 0001104659-04-038850 — 7.01, 9.01
- 2004-10-26 0001104659-04-031931 — 2.02, 9.01
- 2004-10-01 0001104659-04-029361 — 5.02
- 2004-08-02 0001104659-04-021785 — 9
- 2004-07-29 0001104659-04-021529 — 12
- 2004-05-06 0001104659-04-012742 — 9
- 2004-04-26 0001104659-04-011228 — 12
- 2004-02-03 0001104659-04-002424 — 9
- 2004-01-28 0001104659-04-001980 — 12
- 2004-01-09 0001104659-04-000457 — 9
- 2003-10-21 0001104659-03-023304 — 12
- 2003-07-29 0001104659-03-015999 — 12
- 2003-05-08 0001104659-03-008647 — 9
- 2003-05-08 0001104659-03-008462 — 9
- 2003-05-01 0001104659-03-007866 — 9
- 2003-03-07 0001104659-03-003816 — 2, 7 — amendment of 0000950153-02-002190
- 2002-12-27 0000950153-02-002190 — 2, 7
- 2002-05-17 0000912057-02-021145 — 4, 7
- 2001-12-21 0000912057-01-544281 — 7
- 2000-10-27 0000912057-00-046109 — 5

## late-filing notifications on or before 2014-08-05

- none on or before 2014-08-05

## item 2.02 — earnings release, exhibit 99.1

[0001171843-14-003548:8k_2_02:1]
EX-99
2
newsrelease.htm
PRESS RELEASE

[0001171843-14-003548:8k_2_02:2]
TTM Technologies, Inc. Reports Second Quarter 2014 Results
EXHIBIT 99.1

[0001171843-14-003548:8k_2_02:3]
TTM Technologies, Inc. Reports Second Quarter 2014 Results

[0001171843-14-003548:8k_2_02:4]
COSTA MESA, Calif., July 30, 2014 (GLOBE NEWSWIRE) -- TTM Technologies, Inc. (Nasdaq:TTMI), a major global printed circuit board (PCB) manufacturer, today reported results for the second quarter 2014, which ended June 30, 2014.

[0001171843-14-003548:8k_2_02:5]
Second Quarter 2014 Highlights

[0001171843-14-003548:8k_2_02:6]
Net sales were $297.6 million

[0001171843-14-003548:8k_2_02:7]
GAAP net loss was $3.1 million, or $0.04 per share

[0001171843-14-003548:8k_2_02:8]
Non-GAAP net income was $3.9 million, or $0.05 per diluted share

[0001171843-14-003548:8k_2_02:9]
Second Quarter 2014 Financial Results

[0001171843-14-003548:8k_2_02:10]
Net sales for the second quarter of 2014 were $297.6 million compared to $291.9 million in the first quarter of 2014 and $338.0 million in the second quarter of 2013.

[0001171843-14-003548:8k_2_02:11]
GAAP operating income for the second quarter of 2014 was $3.2 million compared to operating income of $4.5 million in the first quarter of 2014 and operating income of $28.3 million in the second quarter of 2013. Operating results for the second quarter of 2013 included a gain of $17.9 million resulting from TTM's sale of its equity interest in the SYE plant. Excluding this gain, operating income was $10.4 million in the second quarter of 2013.

[0001171843-14-003548:8k_2_02:12]
GAAP net loss for the second quarter of 2014 was $3.1 million, or $0.04 per share. This compares to a GAAP net loss of $3.8 million, or $0.05 per share, in the first quarter of 2014 and GAAP net income of $13.1 million, or $0.16 per diluted share in the second quarter of 2013.

[0001171843-14-003548:8k_2_02:13]
On a non-GAAP basis, net income for the second quarter of 2014 was $3.9 million, or $0.05 per diluted share. This compares to non-GAAP net income of $1.2 million, or $0.01 per diluted share, for the first quarter of 2014 and $7.7 million, or $0.09 per diluted share, for the second quarter of 2013.

[0001171843-14-003548:8k_2_02:14]
Adjusted EBITDA for the second quarter of 2014 was $32.8 million, or 11.0 percent of net sales, compared to adjusted EBITDA of $29.1 million, or 10.0 percent of net sales, for the first quarter of 2014 and $39.1 million, or 11.6 percent of net sales, for the second quarter of 2013.

[0001171843-14-003548:8k_2_02:15]
"We generated sales and non-GAAP earnings in line with our expectations for the second quarter," said Tom Edman, CEO of TTM. "We are pleased with our strong performance in the networking/ communications and aerospace & defense end markets. In most other end markets, we experienced normal seasonality, with somewhat broader softness in the computing end market."

[0001171843-14-003548:8k_2_02:16]
"Based on our backlog and customer product ramps, we continue to expect our financial performance to be stronger in the second half of the year. Accordingly, we expect robust sales growth for the third quarter with improved utilization levels in our advanced technology facilities," concluded Mr. Edman.

[0001171843-14-003548:8k_2_02:17]
Business Outlook

[0001171843-14-003548:8k_2_02:18]
For the third quarter of 2014, TTM estimates that revenue will be in the range of $325 million to $355 million, and non-GAAP earnings in the range of $0.11 to $0.17 per diluted share.

[0001171843-14-003548:8k_2_02:19]
To Access the Live Webcast/Conference Call

[0001171843-14-003548:8k_2_02:20]
The Company will host a conference call and webcast to discuss second quarter 2014 results and third quarter 2014 outlook on Wednesday, July 30, 2014, at 4:30 p.m. Eastern Time (1:30 p.m. Pacific Time).

[0001171843-14-003548:8k_2_02:21]
Telephone access is available by dialing domestic 1-888-539-3612 or international 1-719-325-2420 (ID 3718229). The conference call also will be webcast on TTM Technologies' website at www.ttmtech.com.

[0001171843-14-003548:8k_2_02:22]
To Access a Replay of the Webcast

[0001171843-14-003548:8k_2_02:23]
The replay of the webcast will remain accessible for one week following the live event on TTM Technologies' website at www.ttmtech.com.

[0001171843-14-003548:8k_2_02:24]
About Our Non-GAAP Financial Measures

[0001171843-14-003548:8k_2_02:25]
This release includes information about the Company's adjusted EBITDA, non-GAAP net income attributable to stockholders and non-GAAP earnings per share attributable to stockholders, all of which are non-GAAP financial measures. The Company presents non-GAAP financial information to enable investors to see the company through the eyes of management and to provide better insight into the Company's ongoing financial performance.

[0001171843-14-003548:8k_2_02:26]
Management believes that the non-GAAP financial information – which add back amortization of intangibles, stock-based compensation expense, non-cash interest expense on debt, asset impairments, restructuring and other unusual or infrequent items (such as the gain realized on the SYE transaction) as well as the associated tax impact of these charges and discrete tax items – provides additional useful information to investors regarding the Company's ongoing financial condition and results of operations.

[0001171843-14-003548:8k_2_02:27]
A material limitation associated with the use of the above non-GAAP financial measures is that they have no standardized measurement prescribed by GAAP and may not be comparable to similar non-GAAP financial measures used by other companies. The Company compensates for these limitations by providing full disclosure of each non-GAAP financial measure and reconciliation to the most directly comparable GAAP financial measure. However, the non-GAAP financial measures should not be considered in isolation from, or as a substitute for, financial information prepared in accordance with GAAP.

[0001171843-14-003548:8k_2_02:28]
Safe Harbor Statement

[0001171843-14-003548:8k_2_02:29]
This release contains forward-looking statements that relate to future events or performance. We caution you that such statements are simply predictions and actual events or results may differ materially. These statements reflect the company's current expectations and the company does not undertake to update or revise these forward looking statements, even if experience or future changes make it clear that any projected results expressed or implied in this or other company statements will not be realized. Further, these statements involve risks and uncertainties, many of which are beyond the company's control, which could cause actual results to differ materially from the forward-looking statements. These risks and uncertainties include, but are not limited to, general market and economic conditions, including interest rates, currency exchange rates and consumer spending, demand for the company's products, market pressures on prices of the company's products, warranty claims, changes in product mix, contemplated significant capital expenditures and related financing requirements, the company's dependence upon a small number of customers and other "Risk Factors" set forth in the company's most recent SEC filings.

[0001171843-14-003548:8k_2_02:30]
About TTM

[0001171843-14-003548:8k_2_02:31]
TTM Technologies, Inc. is a major global printed circuit board manufacturer, focusing on quick-turn and technologically advanced PCBs and the backplane and sub-system assembly business. TTM stands for time-to-market, representing how the Company's time-critical, one-stop manufacturing services enable customers to shorten the time required to develop new products and bring them to market. Additional information can be found at www.ttmtech.com.

[0001171843-14-003548:8k_2_02:32]
- Tables Follow -

[0001171843-14-003548:8k_2_02:33]
| TTM TECHNOLOGIES, INC. |
| Selected Unaudited Financial Information |
| (In thousands, except per share data) |
|  | Second Quarter | First Quarter | First Two Quarters |
|  | 2014 | 2013 | 2014 | 2014 | 2013 |
| CONSOLIDATED CONDENSED STATEMENTS OF OPERATIONS |  |  |  |  |  |
| Net sales | $ 297,635 | $ 338,021 | $ 291,895 | $ 589,530 | $ 663,413 |
| Cost of goods sold | 259,035 | 289,564 | 253,389 | 512,424 | 564,226 |
| Gross profit | 38,600 | 48,457 | 38,506 | 77,106 | 99,187 |
| Operating expenses: |  |  |  |  |  |
| Selling and marketing | 8,637 | 9,559 | 9,323 | 17,960 | 18,749 |
| General and administrative | 22,647 | 26,141 | 22,518 | 45,165 | 52,699 |
| Amortization of definite-lived intangibles | 2,236 | 2,327 | 2,236 | 4,472 | 4,655 |
| Restructuring charges | 37 | -- | (24) | 13 | -- |
| Impairment of long-lived assets | 1,845 | -- | -- | 1,845 | -- |
| Gain on sale of assets | -- | (17,917) | -- | -- | (17,917) |
| Total operating expenses | 35,402 | 20,110 | 34,053 | 69,455 | 58,186 |
| Operating income | 3,198 | 28,347 | 4,453 | 7,651 | 41,001 |
| Interest expense | (5,915) | (5,923) | (6,206) | (12,121) | (12,201) |
| Loss on extinguishment of debt | -- | -- | (506) | (506) | -- |
| Other, net | 121 | 633 | (3,395) | (3,274) | 1,634 |
| (Loss) income before income taxes | (2,596) | 23,057 | (5,654) | (8,250) | 30,434 |
| Income tax (provision) benefit | (508) | (9,345) | 1,855 | 1,347 | (10,129) |
| Net (loss) income | (3,104) | 13,712 | (3,799) | (6,903) | 20,305 |
| Net income attributable to noncontrolling interest | -- | (575) | -- | -- | (2,016) |
| Net (loss) income attributable to stockholders | $ (3,104) | $ 13,137 | $ (3,799) | $ (6,903) | $ 18,289 |
| (Loss) earnings per share attributable to stockholders: |  |  |  |  |  |
| Basic | $ (0.04) | $ 0.16 | $ (0.05) | $ (0.08) | $ 0.22 |
| Diluted | $ (0.04) | $ 0.16 | $ (0.05) | $ (0.08) | $ 0.22 |
| Weighted-average shares used in computing per share amounts: |  |  |  |  |  |
| Basic | 83,336 | 82,595 | 82,925 | 83,130 | 82,373 |
| Diluted | 83,336 | 82,975 | 82,925 | 83,130 | 82,908 |

[0001171843-14-003548:8k_2_02:34]
| SELECTED BALANCE SHEET DATA |  |
|  | June 30, 2014 | December 30, 2013 |
| Cash and cash equivalents | $ 282,043 | $ 330,554 |
| Accounts and notes receivable, net | 230,165 | 277,070 |
| Inventories | 146,113 | 138,145 |
| Total current assets | 707,223 | 804,991 |
| Property, plant and equipment, net | 780,445 | 810,672 |
| Other non-current assets | 52,072 | 57,912 |
| Total assets | 1,539,740 | 1,673,575 |
| Short-term debt, including current portion long-term debt | $ 127,334 | $ 96,204 |
| Accounts payable | 148,973 | 192,357 |
| Total current liabilities | 403,341 | 458,003 |
| Debt, net of discount | 419,156 | 477,539 |
| Total long-term liabilities | 443,952 | 510,277 |
| Total stockholders' equity | 692,447 | 705,295 |
| Total liabilities and stockholders' equity | 1,539,740 | 1,673,575 |

[0001171843-14-003548:8k_2_02:35]
| SUPPLEMENTAL DATA |
|  | Second Quarter | First Quarter | First Two Quarters |
|  | 2014 | 2013 | 2014 | 2014 | 2013 |
| Gross margin | 13.0% | 14.3% | 13.2% | 13.1% | 15.0% |
| Operating margin | 1.1% | 8.4% | 1.5% | 1.3% | 6.2% |
| End Market Breakdown: |  |  |  |  |  |
|  | Second Quarter | First Quarter |  |  |
|  | 2014 | 2013 | 2014 |  |  |
| Aerospace/Defense | 18% | 16% | 17% |  |  |
| Cellular Phone | 12% | 17% | 15% |  |  |
| Computing/Storage/Peripherals | 14% | 16% | 18% |  |  |
| Medical/Industrial/Instrumentation | 11% | 8% | 10% |  |  |
| Networking/Communications | 40% | 38% | 34% |  |  |
| Other | 5% | 5% | 6% |  |  |
| Stock-based Compensation: |  |  |  |  |  |
|  | Second Quarter | First Quarter |  |  |
|  | 2014 | 2013 | 2014 |  |  |
| Amount included in: |  |  |  |  |  |
| Cost of goods sold | $ 199 | $ 254 | $ 263 |  |  |
| Selling and marketing | 253 | 335 | 335 |  |  |
| General and administrative | 1,479 | 1,994 | 1,570 |  |  |
| Total stock-based compensation expense | $ 1,931 | $ 2,583 | $ 2,168 |  |  |
| Operating Segment Data: |  |  |  |  |  |
|  | Second Quarter | First Quarter |  |  |
| Net sales: | 2014 | 2013 | 2014 |  |  |
| Asia Pacific | $ 166,699 | $ 209,631 | $ 165,666 |  |  |
| North America | 131,594 | 129,669 | 126,589 |  |  |
| Total sales | 298,293 | 339,300 | 292,255 |  |  |
| Inter-segment sales | (658) | (1,279) | (360) |  |  |
| Total net sales | $ 297,635 | $ 338,021 | $ 291,895 |  |  |
| Operating segment income: |  |  |  |  |  |
| Asia Pacific | $ (1,925) | $ 23,642 | $ 3,867 |  |  |
| North America | 7,359 | 7,032 | 2,822 |  |  |
| Total operating segment income | 5,434 | 30,674 | 6,689 |  |  |
| Amortization of definite-lived intangibles | (2,236) | (2,327) | (2,236) |  |  |
| Total operating income | 3,198 | 28,347 | 4,453 |  |  |
| Total other expense | (5,794) | (5,290) | (10,107) |  |  |
| (Loss) income before income taxes | $ (2,596) | $ 23,057 | $ (5,654) |  |  |

[0001171843-14-003548:8k_2_02:36]
| RECONCILIATIONS1 |  |
|  | Second Quarter | First Quarter | First Two Quarters |
|  | 2014 | 2013 | 2014 | 2014 | 2013 |
| Non-GAAP gross profit reconciliation2: |  |  |  |  |  |
| GAAP gross profit | $ 38,600 | $ 48,457 | $ 38,506 | $ 77,106 | $ 99,187 |
| Add back item: |  |  |  |  |  |
| Stock-based compensation | 199 | 254 | 263 | 462 | 557 |
| Non-GAAP gross profit | $ 38,799 | $ 48,711 | $ 38,769 | $ 77,568 | $ 99,744 |
| Non-GAAP gross margin | 13.0% | 14.4% | 13.3% | 13.2% | 15.0% |
| Non-GAAP operating income reconciliation3: |  |  |  |  |  |
| GAAP operating income | $ 3,198 | $ 28,347 | $ 4,453 | $ 7,651 | $ 41,001 |
| Add back items: |  |  |  |  |  |
| Amortization of definite-lived intangibles | 2,236 | 2,327 | 2,236 | 4,472 | 4,655 |
| Stock-based compensation | 1,931 | 2,583 | 2,168 | 4,099 | 4,913 |
| Gain on sale of assets | -- | (17,917) | -- | -- | (17,917) |
| Impairments and restructuring charges | 1,882 | -- | (24) | 1,858 | -- |
| Non-GAAP operating income | $ 9,247 | $ 15,340 | $ 8,833 | $ 18,080 | $ 32,652 |
| Non-GAAP operating margin | 3.1% | 4.5% | 3.0% | 3.1% | 4.9% |
| Non-GAAP net income and EPS attributable to stockholders reconciliation4: |  |  |  |  |  |
| GAAP net (loss) income attributable to stockholders | $ (3,104) | $ 13,137 | $ (3,799) | $ (6,903) | $ 18,289 |
| Add back items: |  |  |  |  |  |
| Amortization of definite-lived intangibles | 2,236 | 2,327 | 2,236 | 4,472 | 4,655 |
| Stock-based compensation | 1,931 | 2,583 | 2,168 | 4,099 | 4,913 |
| Non-cash interest expense | 2,509 | 2,094 | 2,523 | 5,032 | 4,149 |
| Gain on sale of assets | -- | (17,917) | -- | -- | (17,917) |
| Impairments, restructuring and other charges | 1,882 | -- | 482 | 2,364 | -- |
| Income taxes | (1,587) | 5,480 | (2,393) | (3,980) | 3,400 |
| Non-GAAP net income attributable to stockholders | $ 3,867 | $ 7,704 | $ 1,217 | $ 5,084 | $ 17,489 |
| Non-GAAP earnings per diluted share attributable to stockholders | $ 0.05 | $ 0.09 | $ 0.01 | $ 0.06 | $ 0.21 |
| Adjusted EBITDA reconciliation5: |  |  |  |  |  |
| GAAP net (loss) income | $ (3,104) | $ 13,712 | $ (3,799) | $ (6,903) | $ 20,305 |
| Add back items: |  |  |  |  |  |
| Income tax provision (benefit) | 508 | 9,345 | (1,855) | (1,347) | 10,129 |
| Interest expense | 5,915 | 5,923 | 6,206 | 12,121 | 12,201 |
| Amortization of definite-lived intangibles | 2,236 | 2,327 | 2,236 | 4,472 | 4,655 |
| Depreciation expense | 23,437 | 23,118 | 23,707 | 47,144 | 46,255 |
| Stock-based compensation | 1,931 | 2,583 | 2,168 | 4,099 | 4,913 |
| Gain on sale of assets | -- | (17,917) | -- | -- | (17,917) |
| Impairments, restructuring and other charges | 1,882 | -- | 482 | 2,364 | -- |
| Adjusted EBITDA | $ 32,805 | $ 39,091 | $ 29,145 | $ 61,950 | $ 80,541 |
| Adjusted EBITDA margin | 11.0% | 11.6% | 10.0% | 10.5% | 12.1% |

[0001171843-14-003548:8k_2_02:37]
| 1 This information provides a reconciliation of non-GAAP gross profit, non-GAAP operating income, non-GAAP net income attributable to stockholders, non-GAAP EPS attributable to stockholders, and adjusted EBITDA to the financial information in our consolidated condensed statements of operations. |
| 2 Non-GAAP gross profit and gross margin measures exclude stock-based compensation expense. |
| 3 Non-GAAP operating income and operating margin measures exclude amortization of intangibles, stock-based compensation expense, gain on sale of assets, and restructuring and impairment charges. |
| 4 This information provides non-GAAP net income attributable to stockholders and non-GAAP EPS attributable to stockholders, which are non-GAAP financial measures. Management believes that both measures --- which add back amortization of intangibles, stock-based compensation expense, non-cash interest expense on debt (before consideration of capitalized interest), gain on sale of assets, asset impairments, restructuring and other charges as well as the associated tax impact of these charges and discrete tax items --- provide additional useful information to investors regarding the Company's ongoing financial condition and results of operations. |
| 5 Adjusted EBITDA is defined as earnings before interest expense, income taxes, depreciation, amortization of intangibles, stock-based compensation expense, gain on sale of assets, asset impairments, restructuring and other charges. We present adjusted EBITDA to enhance the understanding of our operating results, and it is a key measure we use to evaluate our operations. In addition, we provide our adjusted EBITDA because we believe that investors and securities analysts will find adjusted EBITDA to be a useful measure for evaluating our operating performance and comparing our operating performance with that of similar companies that have different capital structures and for evaluating our ability to meet our future debt service, capital expenditures, and working capital requirements. However, adjusted EBITDA should not be considered as an alternative to cash flows from operating activities as a measure of liquidity or as an alternative to net income as a measure of operating results in accordance with accounting principles generally accepted in the United States of America. |

[0001171843-14-003548:8k_2_02:38]
CONTACT: Todd Schull, CFO
         714-327-3000
