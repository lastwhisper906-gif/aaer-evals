# TTMI MD&A — 0001193125-14-295293


## mdna

[0001193125-14-295293:mdna:1]
Item 2. Management’s Discussion and Analysis
of Financial Condition and Results of Operations

[0001193125-14-295293:mdna:2]
This discussion and analysis should be read in conjunction with “Management’s Discussion and Analysis of
Financial Condition and Results of Operations” set forth in our Annual Report on Form 10-K for the fiscal year ended December 30, 2013, filed with the SEC.

[0001193125-14-295293:mdna:3]
[same as prior period, unchanged from 0001193125-14-184523:mdna:3]

[0001193125-14-295293:mdna:4]
We are a leading global
provider of time-critical and technologically complex printed circuit board (PCB) products and backplane assemblies (PCBs populated with electronic components), which serve as the foundation of sophisticated electronic products. We provide our
customers time-to-market and advanced technology products and offer a one-stop manufacturing solution to customers from engineering support to prototype development through final volume production. We serve a diversified customer base in various
markets throughout the world, including manufacturers of networking/communications infrastructure products, touch screen tablets, mobile media devices and smartphones. We also serve the aerospace and defense, high-end computing, and
industrial/medical industries. Our customers include both original equipment manufacturers (OEMs) and electronic manufacturing services (EMS) providers.

[0001193125-14-295293:mdna:5]
Our Asia Pacific operating segment experiences revenue fluctuations, caused in part by seasonal patterns in the touch screen tablet and cellular phone industries, which together have become a significant
portion of the end markets we serve. This seasonality typically results in higher net sales in the third and fourth quarters due to end customer demand to meet fourth quarter sales of consumer electronics products.

[0001193125-14-295293:mdna:6]
In the normal course of operations, we are exposed to risks associated with fluctuations in foreign currency exchange
rates. Specifically, we are subject to risks associated with transactions that are denominated in currencies other than our functional currencies. Our primary foreign exchange exposure is to the Chinese Renminbi (RMB). For the two quarters ended
June 30, 2014, our consolidated condensed statement of operations included an unrealized foreign exchange loss of approximately $3.6 million, due to the rapid depreciation of the RMB against the U.S. Dollar during the first quarter of
2014. Unrealized foreign exchange losses during the second quarter of 2014 were less than $0.1 million. We do not engage in hedging to manage foreign currency risk related to revenue and expenses denominated in RMB nor do we currently use derivative
instruments to reduce exposure to foreign currency risk for loans due from our foreign subsidiaries.

[0001193125-14-295293:mdna:7]
Labor
costs represent a significant portion of our total manufacturing costs. Our labor costs in the People’s Republic of China (PRC) have increased rapidly over the past number of years as a result of mandated increases in the minimum wage and
increased compensation offered to our labor force due to the reduction of overtime hours that we implemented to meet standards required by some of our global customers. These increases in labor costs have reduced the gross and operating margins of
our Asia Pacific operating segment. We believe annual labor rate increases together with increased pricing pressures from our principal customers and the reduction in our first quarter and second quarter operating leverage due to the seasonal nature
of our business will occur each year for the foreseeable future and may further reduce gross and operating margins in our Asia Pacific operating segment.

[0001193125-14-295293:mdna:8]
We sell to OEMs both directly and indirectly through EMS providers. While our customers include both OEMs and EMS providers, we measure customers based on OEM companies as they are the ultimate end
customers. Sales to our 10 largest OEM customers accounted for 52% of our net sales for both quarters ended June 30, 2014 and July 1, 2013. Sales to our 10 largest OEM customers accounted for 53% and 52% of our net sales for the two
quarters ended June 30, 2014 and July 1, 2013, respectively.

[0001193125-14-295293:mdna:9]
The following table shows the
percentage of our net sales attributable to each of the principal end markets we serve for the periods indicated.

[0001193125-14-295293:mdna:10]
|  |  | Quarter Ended |  |  | Two Quarters Ended |  |
| End Markets(1) |  | June 30,2014 |  |  | July 1,2013 |  |  | June 30,2014 |  |  | July 1,2013 |  |
| Aerospace/Defense |  |  | 18 | % |  |  | 16 | % |  |  | 17 | % |  |  | 16 | % |
| Cellular Phone(2) |  |  | 12 |  |  |  | 17 |  |  |  | 13 |  |  |  | 17 |  |
| Computing/Storage/Peripherals(2) |  |  | 14 |  |  |  | 16 |  |  |  | 16 |  |  |  | 18 |  |
| Medical/Industrial/Instrumentation |  |  | 11 |  |  |  | 8 |  |  |  | 11 |  |  |  | 8 |  |
| Networking/Communications |  |  | 40 |  |  |  | 38 |  |  |  | 37 |  |  |  | 36 |  |
| Other(2) |  |  | 5 |  |  |  | 5 |  |  |  | 6 |  |  |  | 5 |  |
| Total |  |  | 100 | % |  |  | 100 | % |  |  | 100 | % |  |  | 100 | % |

[0001193125-14-295293:mdna:11]
[same as prior period, unchanged from 0001193125-14-184523:mdna:11]

[0001193125-14-295293:mdna:12]
[same as prior period, unchanged from 0001193125-14-184523:mdna:12]

[0001193125-14-295293:mdna:13]
[same as prior period, unchanged from 0001193125-14-184523:mdna:14]

[0001193125-14-295293:mdna:14]
[same as prior period, unchanged from 0001193125-14-184523:mdna:15]

[0001193125-14-295293:mdna:15]
[same as prior period, unchanged from 0001193125-14-184523:mdna:16]

[0001193125-14-295293:mdna:16]
[same as prior period, unchanged from 0001193125-14-184523:mdna:17]

[0001193125-14-295293:mdna:17]
General and
administrative costs primarily include the salaries for executive, finance, accounting, information technology, facilities, research and development, and human resources personnel, as well as insurance expenses, expenses for accounting and legal
assistance, incentive compensation expense, stock-based compensation expense, bad debt expense, gains or losses on the sale or disposal of property, plant and equipment, and acquisition-related expenses.

[0001193125-14-295293:mdna:18]
[same as prior period, unchanged from 0001193125-14-184523:mdna:19]

[0001193125-14-295293:mdna:19]
Our consolidated condensed financial statements included in this report have been prepared in accordance with accounting principles generally accepted in the United States of America. The preparation of
these financial statements requires management to make estimates and assumptions that affect the reported amounts of assets, liabilities, net sales and expenses, and related disclosure of contingent assets and liabilities.

[0001193125-14-295293:mdna:20]
See Item 7, Management’s Discussion and Analysis of Financial Condition and Results of Operations, in
the Company’s Annual Report on Form 10-K for the fiscal year ended December 30, 2013 for further discussion of critical accounting policies and estimates. There were no material changes to our critical accounting policies and estimates
since December 30, 2013.

[0001193125-14-295293:mdna:21]
[same as prior period, unchanged from 0001193125-14-184523:mdna:22]

[0001193125-14-295293:mdna:22]
[same as prior period, unchanged from 0001193125-14-184523:mdna:23]

[0001193125-14-295293:mdna:23]
|  |  | Quarter Ended |  |  | Two Quarters Ended |  |
|  |  | June 30, 2014 |  |  | July 1, 2013 |  |  | June 30, 2014 |  |  | July 1, 2013 |  |
| Net sales |  |  | 100.0 | % |  |  | 100.0 | % |  |  | 100.0 | % |  |  | 100.0 | % |
| Cost of goods sold |  |  | 87.0 |  |  |  | 85.7 |  |  |  | 86.9 |  |  |  | 85.0 |  |
| Gross profit |  |  | 13.0 |  |  |  | 14.3 |  |  |  | 13.1 |  |  |  | 15.0 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Selling and marketing |  |  | 2.9 |  |  |  | 2.8 |  |  |  | 3.0 |  |  |  | 2.8 |  |
| General and administrative |  |  | 7.6 |  |  |  | 7.7 |  |  |  | 7.7 |  |  |  | 7.9 |  |
| Amortization of definite-lived intangibles |  |  | 0.8 |  |  |  | 0.7 |  |  |  | 0.8 |  |  |  | 0.8 |  |
| Impairment of long-lived assets |  |  | 0.6 |  |  |  | — |  |  |  | 0.3 |  |  |  | — |  |
| Gain on sale of assets |  |  | — |  |  |  | (5.3 | ) |  |  | — |  |  |  | (2.7 | ) |
| Total operating expenses |  |  | 11.9 |  |  |  | 5.9 |  |  |  | 11.8 |  |  |  | 8.8 |  |
| Operating income |  |  | 1.1 |  |  |  | 8.4 |  |  |  | 1.3 |  |  |  | 6.2 |  |
| Other income (expense): |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Interest expense |  |  | (2.0 | ) |  |  | (1.8 | ) |  |  | (2.1 | ) |  |  | (1.8 | ) |
| Loss on extinguishment of debt |  |  | — |  |  |  | — |  |  |  | (0.1 | ) |  |  | — |  |
| Other, net |  |  | — |  |  |  | 0.2 |  |  |  | (0.5 | ) |  |  | 0.2 |  |
| Total other expense, net |  |  | (2.0 | ) |  |  | (1.6 | ) |  |  | (2.7 | ) |  |  | (1.6 | ) |
| (Loss) income before income taxes |  |  | (0.9 | ) |  |  | 6.8 |  |  |  | (1.4 | ) |  |  | 4.6 |  |
| Income tax (provision) benefit |  |  | (0.1 | ) |  |  | (2.7 | ) |  |  | 0.2 |  |  |  | (1.5 | ) |
| Net (loss) income |  |  | (1.0 | ) |  |  | 4.1 |  |  |  | (1.2 | ) |  |  | 3.1 |  |
| Less: Net income attributable to noncontrolling interest |  |  | — |  |  |  | (0.2 | ) |  |  | — |  |  |  | (0.3 | ) |
| Net (loss) income attributable to TTM Technologies, Inc. stockholders |  |  | (1.0 | )% |  |  | 3.9 | % |  |  | (1.2 | )% |  |  | 2.8 | % |

[0001193125-14-295293:mdna:24]
[same as prior period, unchanged from 0001193125-14-184523:mdna:25]

[0001193125-14-295293:mdna:25]
The following table
compares net sales by reportable segment for the quarter and two quarters ended June 30, 2014 and July 1, 2013:

[0001193125-14-295293:mdna:26]
|  |  | Quarter Ended |  |  | Two Quarters Ended |  |
|  |  | June 30, 2014 |  |  | July 1, 2013 |  |  | June 30, 2014 |  |  | July 1, 2013 |  |
|  |  | (In thousands) |  |
| Net Sales: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Asia Pacific |  | $ | 166,699 |  |  | $ | 209,631 |  |  | $ | 332,365 |  |  | $ | 412,214 |  |
| North America |  |  | 131,594 |  |  |  | 129,669 |  |  |  | 258,183 |  |  |  | 253,258 |  |
| Total sales |  |  | 298,293 |  |  |  | 339,300 |  |  |  | 590,548 |  |  |  | 665,472 |  |
| Inter-segment sales |  |  | (658 | ) |  |  | (1,279 | ) |  |  | (1,018 | ) |  |  | (2,059 | ) |
| Total net sales |  | $ | 297,635 |  |  | $ | 338,021 |  |  | $ | 589,530 |  |  | $ | 663,413 |  |

[0001193125-14-295293:mdna:27]
[same as prior period, unchanged from 0001193125-14-184523:mdna:28]

[0001193125-14-295293:mdna:28]
[same as prior period, unchanged from 0001193125-14-184523:mdna:29]

[0001193125-14-295293:mdna:29]
Total net sales decreased $40.4 million, or 12.0%, from $338.0 million for the second quarter of 2013 to $297.6 million
for the second quarter of 2014. Net sales for the Asia Pacific segment, excluding inter-segment sales, decreased $42.4 million, or 20.3%, from $208.4 million in the second quarter of 2013 to $166.0 million in the second quarter of 2014. This
decrease was primarily due to the absence of net sales resulting from the sale of a controlling equity interest in a subsidiary in the second quarter of 2013 combined with lower demand in our Cellular Phone and Computing/Storage/Peripherals end
markets, which resulted in a 23% decrease in PCB shipments from the second quarter 2013. Net sales for the North America segment increased $1.9 million, or 1.5%, from $129.7 million in the second quarter of 2013 to $131.6 million in the second
quarter of 2014. This increase was primarily due to a 25% increase in demand for backplane assemblies and for PCB products primarily in the Medical/Industrial/Instrumentation end market, partially offset by reduced revenue for PCB products in the
Networking/Communications end market.

[0001193125-14-295293:mdna:30]
Total net sales decreased $73.9 million, or 11.1%, from $663.4 million
for the first two quarters of 2013 to $589.5 million for the first two quarters of 2014. Net sales for the Asia Pacific segment, excluding inter-segment sales, decreased $78.9 million, or 19.2%, from $410.2 million in the first two quarters of 2013
to $331.3 million in the first two quarters of 2014. This decrease is primarily due to the absence of net sales resulting from the sale of a controlling equity interest in a subsidiary in the second quarter of 2013 combined with lower demand in our
Cellular Phone and Computing/Storage/Peripherals end markets, which resulted in a 26% decrease in PCB shipments from the first two quarters of 2013. This decrease in net sales was partially offset by an 8% increase in the average PCB selling price,
which was driven by product mix shift. Net sales for the North America segment increased $4.9 million, or 1.9%, from $253.3 million in the first two quarters of 2013 to $258.2 million in the first two quarters of 2014. This increase was primarily
due to a 26% increase in demand for backplane assemblies for the Networking/Communications end market, partially offset by a 6% decrease in demand for PCB products, primarily in the same end market.

[0001193125-14-295293:mdna:31]
[same as prior period, unchanged from 0001193125-14-184523:mdna:33]

[0001193125-14-295293:mdna:32]
Gross margin decreased from 14.3% for the second quarter of 2013 to 13.0% for the second quarter of 2014. Gross margin for the Asia Pacific segment decreased from 12.4% for the second quarter of 2013 to
10.7% for the second quarter of 2014, primarily due to unfavorable product mix in our advanced technology plants and a decrease in the volume of advanced technology business. Gross margin for the North America segment decreased from 17.4% for the
second quarter of 2013 to 15.9% for the second quarter of 2014, primarily due to a mix shift toward lower margin assembly products and lower cost absorption due to lower production volumes at certain PCB fabrication plants.

[0001193125-14-295293:mdna:33]
Gross margin decreased from 15.0% for the first two quarters of 2013 to 13.1% for the first two quarters of 2014. Gross
margin for the Asia Pacific segment decreased from 14.0% for the first two quarters of 2013 to 11.8% for the first two quarters of 2014, primarily due to unfavorable product mix, lower utilization and increased equipment-related expenses at our
advanced technology plants. Gross margin for the North America segment decreased from 16.5% for the first two quarters of 2013 to 14.7% for the first two quarters of 2014, primarily due to a mix shift toward lower margin assembly products and lower
cost absorption due to lower production volumes at certain PCB fabrication plants.

[0001193125-14-295293:mdna:34]
[same as prior period, unchanged from 0001193125-14-184523:mdna:37]

[0001193125-14-295293:mdna:35]
Selling and marketing expenses decreased $1.0 million, or 10.4%, from $9.6 million for the second quarter of 2013 to $8.6
million for the second quarter of 2014. As a percentage of net sales, selling and marketing expenses were 2.8% and 2.9% for the second quarters of 2013 and 2014, respectively. Selling and marketing expenses decreased $0.7 million, or 3.7%, from
$18.7 million for the first two quarters of 2013 to $18.0 million for the first two quarters of 2014. As a percentage of net sales, selling and marketing expenses were 2.8% and 3.0% for the first two quarters of 2013 and 2014, respectively. The
decrease in selling and marketing expenses for the quarter and first two quarters of 2014 is primarily due to reduced commissions, due to lower sales, and lower travel expenses over the comparable periods of the prior year. Additionally, the
increase in selling and marketing expense as a percentage of net sales for the quarter and first two quarters of 2014, is primarily due to lower net sales.

[0001193125-14-295293:mdna:36]
[same as prior period, unchanged from 0001193125-14-184523:mdna:39]

[0001193125-14-295293:mdna:37]
General and
administrative expenses decreased $3.4 million from $26.1 million, or 7.7% of net sales, for the second quarter of 2013 to $22.7 million, or 7.6% of net sales, for the second quarter of 2014. General and administrative expenses decreased $7.5
million from $52.7 million, or 7.9% of net sales, for the first two quarters of 2013 to $45.2 million, or 7.7% of net sales, for the first two quarters of 2014. The decrease in general and administrative expense primarily relates to costs savings
resulting from the sale of our controlling equity interest in a subsidiary in the Asia Pacific operating segment, and lower incentive compensation expense.

[0001193125-14-295293:mdna:38]
[same as prior period, unchanged from 0001193125-14-184523:mdna:41]

[0001193125-14-295293:mdna:39]
Other expense, net increased $0.5 million from $5.3 million for the second quarter of 2013 to $5.8 million for the second
quarter of 2014. The increase in other expense, net was primarily due to a decrease in currency transaction and derivative gains.

[0001193125-14-295293:mdna:40]
Other expense, net increased $5.3 million from $10.6 million for the first two quarters of 2013 to $15.9 million for the first two quarters of 2014. The increase in other expense, net was primarily due to
unrealized foreign currency transaction losses of $3.6 million due to the rapid depreciation of the Chinese RMB against the U.S. Dollar, and $0.5 million loss on the extinguishment of debt related to repurchase of a portion of convertible
senior notes due 2015, both in the first quarter of 2014.

[0001193125-14-295293:mdna:41]
[same as prior period, unchanged from 0001193125-14-184523:mdna:43]

[0001193125-14-295293:mdna:42]
The provision for income taxes decreased $8.8 million from $9.3 million for the second quarter of 2013 to $0.5 million for
the second quarter of 2014. The decrease in income taxes expense is primarily due to losses incurred in lower tax jurisdictions compared to income earned in the same period of the prior year. Further, the income tax expense in 2013 was higher
primarily due to a gain on sale of assets in one of our foreign operations.

[0001193125-14-295293:mdna:43]
The provision for income taxes
decreased $11.4 million from $10.1 million tax expense for the first two quarters of 2013 to $1.3 million tax benefit for the first two quarters of 2014. Our effective tax rate was 33.3% for the first two quarters of 2013 and 16.3% for the first two
quarters of 2014. The decrease in our provision for income taxes is primarily due to losses incurred for the first two quarters of 2014 compared to the same period of the prior year, combined with a $1.5 million discrete tax benefit recorded in the
first quarter of 2014 resulting from the retroactive approval of the high technology enterprise status for a subsidiary within the Asia Pacific operating segment.

[0001193125-14-295293:mdna:44]
Our effective tax rate is primarily impacted by the U.S. federal income tax rate, apportioned state income tax rates, tax
rates in China and Hong Kong, generation of other credits and deductions available to us, and certain non-deductible items. Certain foreign losses generated are not more than likely to be realizable, and thus no income tax benefit has been
recognized on these losses. Additionally, as of June 30, 2014 and December 30, 2013, we had net deferred income tax assets of approximately $6.2 million and $5.4 million, respectively. Based on our forecast for future taxable earnings, we
believe it is more likely than not that we will utilize the deferred income tax assets in future periods.

[0001193125-14-295293:mdna:45]
Liquidity and Capital
Resources

[0001193125-14-295293:mdna:46]
Our principal sources of liquidity have been cash provided by operations, the issuance of
convertible senior notes, and term and revolving debt. Our principal uses of cash have been to refinance existing debt, finance capital expenditures, meet debt service requirements, fund working capital requirements and finance acquisitions. We
anticipate that servicing debt, financing capital expenditures, funding working capital requirements, and financing acquisitions will continue to be the principal demands on our cash in the future.

[0001193125-14-295293:mdna:47]
As of June 30, 2014, we had net working capital of approximately $303.9 million compared to $347.0 million as of
December 30, 2013.

[0001193125-14-295293:mdna:48]
As of June 30, 2014, we had cash and cash equivalents of approximately $282.0
million, of which approximately $62.2 million was held by our foreign subsidiaries. Of the cash and cash equivalents held by our foreign subsidiaries as of June 30, 2014, $58.7 million was located in Asia and $3.5 million was located in Europe.
Cash and cash equivalents located in our Asia Pacific operating segment are expected to be used in local operations. Cash and cash equivalents located in our backplane assembly facility in Shanghai, China, as well as in Europe, which are managed in
conjunction with our U.S. operations, totaled approximately $10.9 million and are available for repatriation and will be subject to U.S. income tax.

[0001193125-14-295293:mdna:49]
[same as prior period, unchanged from 0001193125-14-184523:mdna:49]

[0001193125-14-295293:mdna:50]
Based on our current level of operations, we believe that cash generated from operations, cash on hand and cash available
from borrowings under our existing credit arrangements will be adequate to meet our currently anticipated capital expenditure, debt service, and working capital needs for the next 12 months. However, we may enter into new borrowing arrangements, if
needed, to fund our business operations, refinance existing debt, or fund acquisitions.

[0001193125-14-295293:mdna:51]
[same as prior period, unchanged from 0001193125-14-184523:mdna:51]

[0001193125-14-295293:mdna:52]
We are party to a facility agreement (Credit Agreement) consisting of a $370.0 million senior secured Term Loan, a $90.0
million senior secured Revolving Loan and a secured $80.0 million Letters of Credit Facility. The Term Loan and Letters of Credit Facility will mature on September 14, 2016, and the Revolving Loan will mature on March 14, 2016. The Credit
Agreement is secured by substantially all of the assets of our Asia Pacific operating segment and is senior to all of our other debt, including the convertible senior notes. We have fully and unconditionally guaranteed the full and timely payment of
all Credit Agreement related obligations of the Asia Pacific operating segment.

[0001193125-14-295293:mdna:53]
Borrowings under the Credit
Agreement bear interest at a floating rate of LIBOR plus an interest margin of 2.38%. At June 30, 2014, the weighted average interest rate on the outstanding borrowings under the Credit Agreement was 2.54%.

[0001193125-14-295293:mdna:54]
Borrowings under the Credit Agreement are subject to certain financial and operating covenants that include maintaining
maximum total leverage ratios and minimum net worth, current ratio, and interest coverage ratios for both us and our Asia Pacific operating segment. In addition, our Credit Agreement includes a covenant that the Principal Shareholders (as defined in
the Shareholders Agreement dated April 9, 2010 as amended on September 14, 2012) will not reduce their shareholding below 15 percent of TTM’s issued shares. At June 30, 2014, we were in compliance with the covenants.

[0001193125-14-295293:mdna:55]
We are required to pay a commitment fee of 0.50% per annum on any unused portion of the loans and letters of credit
facility granted under the Credit Agreement. We incurred $0.2 million and $0.3 million for the quarter and two quarters ended June 30, 2014, respectively, in commitment fees. As of June 30, 2014, the outstanding amount of the Term Loan was
$321.9 million, of which $96.2 million is due for repayment through March 2015 and is included as short-term debt, with the remaining $225.7 million included as long-term debt. None of the Revolving Loan associated with the Credit Agreement was
outstanding at June 30, 2014. Available borrowing capacity under the Revolving Loan was $90.0 million as of June 30, 2014.

[0001193125-14-295293:mdna:56]
We have an $80.0 million Letters of Credit Facility under the Credit Agreement. As of June 30, 2014, letters of credit in the amount of $46.2 million were outstanding under our Credit Agreement. We
have other standby letters of credit outstanding in the amount of $3.9 million, as well as other unused letter of credit facilities in the amount of $24.1 million. The outstanding standby letters of credit and unused letter of credit facilities
expire between December 31, 2014 and February 28, 2015.

[0001193125-14-295293:mdna:57]
We are party to a revolving loan credit
facility with a lender in the PRC. Under this arrangement, the lender has made available to us approximately $46.6 million in unsecured borrowing with all terms of the borrowing to be negotiated at the time the revolver is drawn upon. There are no
commitment fees on the unused portion of the revolver and this arrangement expires in December 2014. As of June 30, 2014, the revolver had not been drawn upon.

[0001193125-14-295293:mdna:58]
Convertible Senior Notes due 2020

[0001193125-14-295293:mdna:59]
On December 20, 2013, we issued 1.75% convertible senior notes due December 15, 2020, in a public offering
for an aggregate principal amount of $220.0 million. The convertible senior notes bear interest at a rate of 1.75% per annum. Interest is payable semiannually in arrears on June 15 and December 15 of each year. The convertible senior
notes are senior unsecured obligations and rank equally to our future unsecured senior indebtedness and senior in right of payment to any of our future subordinated indebtedness. Offering expenses are being amortized to interest expense over the
term of the convertible senior notes.

[0001193125-14-295293:mdna:60]
In January 2014, we closed the sale of an additional $30.0 million
aggregate principal amount of our 1.75% convertible senior notes due 2020 (Additional Notes). The Additional Notes were sold pursuant to the exercise of an over-allotment option granted by us in the underwriting agreement related to the offer and
sale of $220.0 million aggregate principal amount of our 1.75% convertible senior notes due 2020. In connection with the offering of the Additional Notes, we entered into additional convertible note hedge transactions with respect to shares of our
common stock. The additional purchased call options cover up to approximately 3.1 million shares of common stock, at a strike price of $9.64 and will expire upon the maturity of the notes. Additionally, we also entered into additional warrant
transactions, whereby we sold warrants to acquire up to approximately 3.1 million shares of common stock at a strike price of $14.26.

[0001193125-14-295293:mdna:61]
Convertible Senior Notes due 2015

[0001193125-14-295293:mdna:62]
In May 2008, we issued
$175.0 million of convertible senior notes. The convertible senior notes bear interest at a rate of 3.25% per annum. Interest is payable semiannually in arrears on May 15 and November 15 of each year. The convertible senior notes
are senior unsecured obligations and rank equally to our future unsecured senior indebtedness and senior in right of payment to any of our future subordinated indebtedness. Offering expenses are being amortized to interest expense over the term of
the convertible senior notes.

[0001193125-14-295293:mdna:63]
In January 2014, we repurchased $6.5 million principal amount of notes at
approximately 103.4% of their principal amount. This repurchase was also accounted for as an extinguishment of debt and, accordingly, we recognized a loss of approximately $0.5 million, primarily associated with the premium paid to repurchase the
convertible senior notes and the recognition of certain remaining unamortized debt discount and issuance costs. At June 30, 2014 $32,395 of principal related to the convertible senior notes due 2015 remain outstanding.

[0001193125-14-295293:mdna:64]
[same as prior period, unchanged from 0001193125-14-184523:mdna:64]

[0001193125-14-295293:mdna:65]
The following table provides information on our contractual obligations as of June 30, 2014:

[0001193125-14-295293:mdna:66]
|  |  | Total |  |  | Less Than1 Year |  |  | 1 - 3 Years |  |  | 4 - 5 Years |  |  | After5 Years |  |
|  |  | (In thousands) |  |
| Contractual Obligations(1) |  |  |  |
| Long-term debt obligations |  | $ | 321,906 |  |  | $ | 96,205 |  |  | $ | 225,701 |  |  | $ | — |  |  | $ | — |  |
| Convertible debt obligations |  |  | 282,395 |  |  |  | 32,395 |  |  |  | — |  |  |  | — |  |  |  | 250,000 |  |
| Interest on debt obligations |  |  | 41,582 |  |  |  | 12,341 |  |  |  | 13,928 |  |  |  | 8,750 |  |  |  | 6,563 |  |
| Foreign currency forward contract liabilities |  |  | 848 |  |  |  | 232 |  |  |  | 616 |  |  |  | — |  |  |  | — |  |
| Equipment payables |  |  | 56,716 |  |  |  | 44,529 |  |  |  | 12,187 |  |  |  | — |  |  |  | — |  |
| Purchase obligations |  |  | 22,119 |  |  |  | 17,572 |  |  |  | 4,547 |  |  |  | — |  |  |  | — |  |
| Operating lease commitments |  |  | 6,011 |  |  |  | 2,405 |  |  |  | 2,374 |  |  |  | 1,037 |  |  |  | 195 |  |
| Total contractual obligations |  | $ | 731,577 |  |  | $ | 205,679 |  |  | $ | 259,353 |  |  | $ | 9,787 |  |  | $ | 256,758 |  |

[0001193125-14-295293:mdna:67]
| (1) | Unrecognized uncertain tax benefits of $2.6 million are not included in the table above as we have not determined when the amount will be paid. |

[0001193125-14-295293:mdna:68]
[same as prior period, unchanged from 0001193125-14-184523:mdna:68]

[0001193125-14-295293:mdna:69]
[same as prior period, unchanged from 0001193125-14-184523:mdna:69]

[0001193125-14-295293:mdna:70]
[same as prior period, unchanged from 0001193125-14-184523:mdna:70]

[0001193125-14-295293:mdna:71]
As a result of the product and customer mix of our Asia Pacific operating segment, our revenue is subject to seasonal fluctuations. These fluctuations include seasonal patterns in the computer and
cellular phone industries, which together have become a significant portion of the end markets we serve. This seasonality typically results in higher net sales in the third and fourth quarters due to end customer demand to meet fourth quarter sales
of consumer electronics products.

[0001193125-14-295293:mdna:72]
Recently Issued Accounting Standards

[0001193125-14-295293:mdna:73]
On May 28, 2014, the Financial Accounting Standards Board (FASB) issued Accounting Standards Update No. (ASU)
2014-09, Revenue from Contracts with Customers, which requires an entity to recognize the amount of revenue to which it expects to be entitled for the transfer of promised goods or services to customers. The ASU will replace most existing
revenue recognition guidance in U.S. GAAP when it becomes effective. The new standard is effective for us on January 1, 2017. Early application is not permitted. The standard permits the use of either the retrospective or cumulative effect
transition method. We are evaluating the effect that ASU 2014-09 will have on our consolidated financial statements and related disclosures. We have not yet selected a transition method nor have we determined the effect of the standard on our
ongoing financial reporting.

[0001193125-14-295293:mdna:74]
In July 2013, the FASB issued an update that would require an unrecognized tax
benefit, or a portion of an unrecognized benefit, to be presented in the financial statements as a reduction to a deferred tax asset for a net operating loss carryforward, a similar tax loss, or a tax credit carryforward. This update is effective
for interim and annual periods beginning after December 15, 2013, with early adoption permitted. We adopted the amendment on January 1, 2014, and our adoption did not have a material impact on our financial statements.
