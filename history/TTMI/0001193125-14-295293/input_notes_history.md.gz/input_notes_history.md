# TTMI note change history — 0001193125-14-184523 → 0001193125-14-295293


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2014-08-05):
[0001193125-14-295293:note_history:1]
The Company is subject to various legal matters, which it
 considers normal for its business activities. While the Company
 currently believes that the amount of any reasonably possible or
 probable loss for known matters would not be material to the
 Company’s financial condition, the outcome of these actions
 is inherently difficult to predict. In the event of an adverse
 outcome, the ultimate potential loss could have a material adverse
 effect on the Company’s financial condition or results of
 operations in a particular period. The Company has accrued amounts
 for its loss contingencies which are probable and estimable at
 June 30, 2014 and December 30, 2013. However, these
 amounts are not material to the consolidated condensed financial
 statements of the Company.
  (was, 2014-05-06, similarity 0.9941):
[0001193125-14-184523:note_history:1]
The Company is subject to various legal matters, which it
 considers normal for its business activities. While the Company
 currently believes that the amount of any reasonably possible or
 probable loss for known matters would not be material to the
 Company’s financial condition, the outcome of these actions
 is inherently difficult to predict. In the event of an adverse
 outcome, the ultimate potential loss could have a material adverse
 effect on the Company’s financial condition or results of
 operations in a particular period. The Company has accrued amounts
 for its loss contingencies which are probable and estimable at
 March 31, 2014 and December 30, 2013. However, these
 amounts are not material to the consolidated condensed financial
 statements of the Company.

- changed (2014-08-05):
[0001193125-14-295293:note_history:2]
The process to manufacture PCBs requires adherence to city,
 county, state, federal and foreign environmental regulations
 regarding the storage, use, handling and disposal of chemicals,
 solid wastes and other hazardous materials as well as compliance
 with air quality standards. The Company believes that its
 facilities in the United States comply in all material respects
 with applicable environmental laws and regulations. In China,
 governmental authorities are taking various steps to tighten the
 rules and regulations governing environmental issues. An
 update to Chinese environmental law was issued in late 2012, but
 allows for an interim period in which foreign entities may adjust
 to the new regulatory regime and come into full compliance with the
 new laws. The Company’s plants in China are not yet in
 full compliance with the current environmental regulations as
 updated in late 2012. The Company expects to come into
 compliance and does not anticipate any immediate risk of government
 fines or temporary closure of its Chinese plants. The Company
 has established and enacted an investment plan, which includes
 capital expenditures estimated to be approximately $10,000 for
 2014, to address the regulatory changes in order to come into full
 compliance during the interim period.
  (was, 2014-05-06, similarity 0.984):
[0001193125-14-184523:note_history:2]
The process to manufacture PCBs requires adherence to city,
 county, state, federal and foreign environmental regulations
 regarding the storage, use, handling and disposal of chemicals,
 solid wastes and other hazardous materials as well as compliance
 with air quality standards. The Company believes that its
 facilities in the United States comply in all material respects
 with applicable environmental laws and regulations. In China,
 governmental authorities are taking various steps to tighten the
 rules and regulations governing environmental issues. An
 update to Chinese environmental law was issued in late 2012, but
 allows for an interim period in which foreign entities may adjust
 to the new regulatory regime and come into full compliance with the
 new laws. The Company’s plants in China are not yet in
 full compliance with the current environmental regulations as
 updated in late 2012. The Company does not anticipate any
 immediate risk of government fines or temporary closure of Chinese
 plants. The Company has established and enacted an investment
 plan, which includes capital expenditures estimated to be
 approximately $4,700 for 2014, to address the regulatory changes in
 order to come into full compliance during the interim
 period.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- added (2014-08-05):
[0001193125-14-295293:note_history:3]
Recently Issued
 Accounting Standards

- added (2014-08-05):
[0001193125-14-295293:note_history:4]
On May 28, 2014, the Financial Accounting Standards Board
 (FASB) issued Accounting Standards Update No. (ASU) 2014-09,
 Revenue from Contracts with Customers, which requires an
 entity to recognize the amount of revenue to which it expects to be
 entitled for the transfer of promised goods or services to
 customers. The ASU will replace most existing revenue recognition
 guidance in U.S. GAAP when it becomes effective. The new standard
 is effective for the Company on January 1, 2017. Early
 application is not permitted. The standard permits the use of
 either the retrospective or cumulative effect transition method.
 The Company is evaluating the effect that ASU 2014-09 will have on
 its consolidated financial statements and related disclosures. The
 Company has not yet selected a transition method nor has it
 determined the effect of the standard on its ongoing financial
 reporting.

- added (2014-08-05):
[0001193125-14-295293:note_history:5]
In July 2013, the FASB issued an update that would require an
 unrecognized tax benefit, or a portion of an unrecognized benefit,
 to be presented in the financial statements as a reduction to a
 deferred tax asset for a net operating loss carryforward, a similar
 tax loss, or a tax credit carryforward. This update is effective
 for interim and annual periods beginning after December 15,
 2013, with early adoption permitted. The Company adopted the
 amendment on January 1, 2014, and its adoption did not have a
 material impact on its financial statements.


## ttmi:ConvertibleSeniorNotesTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2014-08-05):
[0001193125-14-295293:note_history:6]
In January 2014, the Company closed the sale of an additional
 $30,000 aggregate principal amount of its 1.75% convertible senior
 notes due 2020 (Additional Notes). The Additional Notes were sold
 pursuant to the exercise of an over-allotment option granted by the
 Company in the underwriting agreement related to the offer and sale
 of $220,000 aggregate principal amount of its 1.75% convertible
 senior notes due 2020.
  (was, 2014-05-06, similarity 0.9475):
[0001193125-14-184523:note_history:6]
During the quarter ended March 31, 2014, the Company
 closed the sale of an additional $30,000 aggregate principal amount
 of its 1.75% convertible senior notes due 2020 (Additional Notes).
 The Additional Notes were sold pursuant to the exercise of an
 over-allotment option granted by the Company in the underwriting
 agreement related to the offer and sale of $220,000 aggregate
 principal amount of its 1.75% convertible senior notes due
 2020.

- changed (2014-08-05):
[0001193125-14-295293:note_history:7]
In January 2014, the Company repurchased $6,514 of notes at
 approximately 103.4% of their principal amount. The repurchase of
 the convertible senior notes was accounted for as an extinguishment
 of debt, and accordingly, the Company recognized a $506 loss
 primarily associated with the premium paid to repurchase the
 convertible senior notes and the recognition of certain remaining
 unamortized debt discount and issuance costs.
  (was, 2014-05-06, similarity 0.9505):
[0001193125-14-184523:note_history:7]
During the quarter ended March 31, 2014, the Company
 repurchased $6,514 of notes at approximately 103.4% of their
 principal amount. The repurchase of the convertible senior notes
 was accounted for as an extinguishment of debt, and accordingly,
 the Company recognized a $506 loss primarily associated with the
 premium paid to repurchase the convertible senior notes and the
 recognition of certain remaining unamortized debt discount and
 issuance costs.

- changed (2014-08-05):
[0001193125-14-295293:note_history:8]
As of June 30, 2014 and December 30, 2013, the
 following summarizes the liability and equity components of the
 convertible senior notes:
  (was, 2014-05-06, similarity 0.9641):
[0001193125-14-184523:note_history:8]
As of March 31, 2014 and December 30, 2013, the
 following summarizes the liability and equity components of the
 convertible senior notes:

- added (2014-08-05):
[0001193125-14-295293:note_history:9]
|  |  | As of June 30, 2014 |  |  | As of December 30, 2013 |  |
|  |  | Principal |  |  | Unamortized Discount |  |  | Net Carrying Amount |  |  | Principal |  |  | Unamortized Discount |  |  | Net Carrying Amount |  |
|  |  | (in thousands) |  |
| Liability components: |  |  |  |  |
| Convertible senior notes due 2020 |  | $ | 250,000 |  |  | $ | (56,545 | ) |  | $ | 193,455 |  |  | $ | 220,000 |  |  | $ | (52,833 | ) |  | $ | 167,167 |  |
| Convertible senior notes due 2015 |  |  | 32,395 |  |  |  | (1,266 | ) |  |  | 31,129 |  |  |  | 38,909 |  |  |  | (2,341 | ) |  |  | 36,568 |  |
| Total |  | $ | 282,395 |  |  | $ | (57,811 | ) |  | $ | 224,584 |  |  | $ | 258,909 |  |  | $ | (55,174 | ) |  | $ | 203,735 |  |
|  |  | As of June 30, 2014 |  |  | As of December 30, 2013 |  |
|  |  | Embedded conversion option — Convertible Senior Notes |  |  | Embedded conversion option — Convertible Senior Notes Issuance Costs |  |  | Total |  |  | Embedded conversion option — Convertible Senior Notes |  |  | Embedded conversion option — Convertible Senior Notes Issuance Costs |  |  | Total |  |
|  |  | (in thousands) |  |
| Equity components: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Additional paid-in capital: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Convertible senior notes due 2020 |  | $ | 60,227 |  |  | $ | (1,916 | ) |  | $ | 58,311 |  |  | $ | 53,000 |  |  | $ | (1,644 | ) |  | $ | 51,356 |  |
| Convertible senior notes due 2015 |  |  | 39,781 |  |  | $ | (1,413 | ) |  |  | 38,368 |  |  |  | 39,928 |  |  |  | (1,413 | ) |  |  | 38,515 |  |
|  |  | $ | 100,008 |  |  | $ | (3,329 | ) |  | $ | 96,679 |  |  | $ | 92,928 |  |  | $ | (3,057 | ) |  | $ | 89,871 |  |

- changed (2014-08-05):
[0001193125-14-295293:note_history:10]
The components of interest expense resulting from the
 convertible senior notes for the quarter and two quarters ended
 June 30, 2014 and July 1, 2013 are as follows:
  (was, 2014-05-06, similarity 0.8919):
[0001193125-14-184523:note_history:10]
The components of interest expense resulting from the
 convertible senior notes for the quarters ended March 31, 2014
 and April 1, 2013 are as follows:

- added (2014-08-05):
[0001193125-14-295293:note_history:11]
|  |  | For the Quarter Ended |  |  | For the Two Quarters Ended |  |
|  |  | June 30, 2014 |  |  | July 1, 2013 |  |  | June 30, 2014 |  |  | July 1, 2013 |  |
|  |  | (In thousands) |  |  | (In thousands) |  |
| Contractual coupon interest |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Convertible senior notes due 2020 |  | $ | 1,094 |  |  | $ | — |  |  | $ | 2,179 |  |  | $ | — |  |
| Convertible senior notes due 2015 |  |  | 263 |  |  |  | 1,422 |  |  |  | 526 |  |  |  | 2,844 |  |
|  |  | $ | 1,357 |  |  | $ | 1,422 |  |  | $ | 2,705 |  |  | $ | 2,844 |  |
| Amortization of debt discount |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Convertible senior notes due 2020 |  | $ | 1,751 |  |  | $ | — |  |  | $ | 3,515 |  |  | $ | — |  |
| Convertible senior notes due 2015 |  |  | 345 |  |  |  | 1,715 |  |  |  | 683 |  |  |  | 3,395 |  |
|  |  | $ | 2,096 |  |  | $ | 1,715 |  |  | $ | 4,198 |  |  | $ | 3,395 |  |
| Amortization of debt issuance costs |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Convertible senior notes due 2020 |  | $ | 175 |  |  | $ | — |  |  | $ | 353 |  |  | $ | — |  |
| Convertible senior notes due 2015 |  |  | 35 |  |  |  | 174 |  |  |  | 69 |  |  |  | 343 |  |
|  |  | $ | 210 |  |  | $ | 174 |  |  | $ | 422 |  |  | $ | 343 |  |

- changed (2014-08-05):
[0001193125-14-295293:note_history:12]
As of June 30, 2014 and December 30, 2013, remaining
 unamortized debt issuance costs included in other non-current
 assets were $5,795 and $5,399, respectively. The debt issuance
 costs and debt discount are being amortized to interest expense
 over the term of the convertible senior notes using the effective
 interest rate method. At June 30, 2014, the remaining weighted
 average amortization period for the unamortized senior convertible
 note discount and debt issuance costs was
 6.3 years.
  (was, 2014-05-06, similarity 0.9806):
[0001193125-14-184523:note_history:12]
As of March 31, 2014 and December 30, 2013, remaining
 unamortized debt issuance costs included in other non-current
 assets were $6,005 and $5,399, respectively. The debt issuance
 costs and debt discount are being amortized to interest expense
 over the term of the convertible senior notes using the effective
 interest rate method. At March 31, 2014, the remaining
 weighted average amortization period for the unamortized senior
 convertible note discount and debt issuance costs was
 6.6 years.

- changed (2014-08-05):
[0001193125-14-295293:note_history:13]
For the quarter and two quarters ended June 30, 2014, the
 amortization of debt discount and debt issuance costs for the 2020
 convertible senior notes and the 2015 convertible senior notes is
 based on an effective interest rate of 6.48% and 8.37%,
 respectively. For the quarter and two quarters ended July 1,
 2013, the amortization of debt discount and debt issuance costs for
 the 2015 convertible senior notes is based on an effective interest
 rate of 8.37%.
  (was, 2014-05-06, similarity 0.908):
[0001193125-14-184523:note_history:13]
For the quarter ended March 31, 2014, the amortization of
 debt discount and debt issuance costs for the 2020 convertible
 senior notes and the 2015 convertible senior notes is based on an
 effective interest rate of 6.48% and 8.37%, respectively. For the
 quarter ended April 1, 2013, the amortization of debt discount
 and debt issuance costs for the 2015 convertible senior notes is
 based on an effective interest rate of 8.37%.

- removed (2014-08-05):
[0001193125-14-184523:note_history:14]
|  |  | As of March 31, 2014 |  |  | As of December 30, 2013 |  |
|  |  | Principal |  |  | Unamortized Discount |  |  | Net Carrying Amount |  |  | Principal |  |  | Unamortized Discount |  |  | Net Carrying Amount |  |
|  |  | (in thousands) |  |
| Liability components: |  |  |  |  |
| Convertible senior notes due 2020 |  | $ | 250,000 |  |  | $ | (58,295 | ) |  | $ | 191,705 |  |  | $ | 220,000 |  |  | $ | (52,833 | ) |  | $ | 167,167 |  |
| Convertible senior notes due 2015 |  |  | 32,395 |  |  |  | (1,612 | ) |  |  | 30,783 |  |  |  | 38,909 |  |  |  | (2,341 | ) |  |  | 36,568 |  |
| Total |  | $ | 282,395 |  |  | $ | (59,907 | ) |  | $ | 222,488 |  |  | $ | 258,909 |  |  | $ | (55,174 | ) |  | $ | 203,735 |  |

- removed (2014-08-05):
[0001193125-14-184523:note_history:15]
|  |  | As of March 31, 2014 |  |  | As of December 30, 2013 |  |
|  |  | Embedded conversion option — Convertible Senior Notes |  |  | Embedded conversion option — Convertible Senior Notes Issuance Costs |  |  | Total |  |  | Embedded conversion option — Convertible Senior Notes |  |  | Embedded conversion option — Convertible Senior Notes Issuance Costs |  |  | Total |  |
|  |  | (in thousands) |  |
| Equity components: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Additional paid-in capital: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Convertible senior notes due 2020 |  | $ | 60,227 |  |  | $ | (1,916 | ) |  | $ | 58,311 |  |  | $ | 53,000 |  |  | $ | (1,644 | ) |  | $ | 51,356 |  |
| Convertible senior notes due 2015 |  |  | 39,781 |  |  | $ | (1,413 | ) |  |  | 38,368 |  |  |  | 39,928 |  |  | $ | (1,413 | ) |  |  | 38,515 |  |
|  |  | $ | 100,008 |  |  | $ | (3,329 | ) |  | $ | 96,679 |  |  | $ | 92,928 |  |  | $ | (3,057 | ) |  | $ | 89,871 |  |

- removed (2014-08-05):
[0001193125-14-184523:note_history:16]
|  |  | For the Quarter Ended |  |
|  |  | March 31, 2014 |  |  | April 1, 2013 |  |
|  |  | (In thousands) |  |
| Contractual coupon interest |  |  |  |  |  |  |  |  |
| Convertible senior notes due 2020 |  | $ | 1,085 |  |  | $ | — |  |
| Convertible senior notes due 2015 |  |  | 263 |  |  |  | 1,422 |  |
|  |  | $ | 1,348 |  |  | $ | 1,422 |  |
| Amortization of debt discount |  |  |  |  |  |  |  |  |
| Convertible senior notes due 2020 |  | $ | 1,764 |  |  | $ | — |  |
| Convertible senior notes due 2015 |  |  | 338 |  |  |  | 1,680 |  |
|  |  | $ | 2,102 |  |  | $ | 1,680 |  |
| Amortization of debt issuance costs |  |  |  |  |  |  |  |  |
| Convertible senior notes due 2020 |  | $ | 177 |  |  | $ | — |  |
| Convertible senior notes due 2015 |  |  | 34 |  |  |  | 169 |  |
|  |  | $ | 211 |  |  | $ | 169 |  |


## ttmi:ScheduleOfComponentsOfInterestExpenseFromConvertibleNotesTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2014-08-05):
[0001193125-14-295293:note_history:17]
The components of interest expense resulting from the
 convertible senior notes for the quarter and two quarters ended
 June 30, 2014 and July 1, 2013 are as follows:
  (was, 2014-05-06, similarity 0.8919):
[0001193125-14-184523:note_history:17]
The components of interest expense resulting from the
 convertible senior notes for the quarters ended March 31, 2014
 and April 1, 2013 are as follows:

- added (2014-08-05):
[0001193125-14-295293:note_history:18]
|  |  | For the Quarter Ended |  |  | For the Two Quarters Ended |  |
|  |  | June 30, 2014 |  |  | July 1, 2013 |  |  | June 30, 2014 |  |  | July 1, 2013 |  |
|  |  | (In thousands) |  |  | (In thousands) |  |
| Contractual coupon interest |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Convertible senior notes due 2020 |  | $ | 1,094 |  |  | $ | — |  |  | $ | 2,179 |  |  | $ | — |  |
| Convertible senior notes due 2015 |  |  | 263 |  |  |  | 1,422 |  |  |  | 526 |  |  |  | 2,844 |  |
|  |  | $ | 1,357 |  |  | $ | 1,422 |  |  | $ | 2,705 |  |  | $ | 2,844 |  |
| Amortization of debt discount |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Convertible senior notes due 2020 |  | $ | 1,751 |  |  | $ | — |  |  | $ | 3,515 |  |  | $ | — |  |
| Convertible senior notes due 2015 |  |  | 345 |  |  |  | 1,715 |  |  |  | 683 |  |  |  | 3,395 |  |
|  |  | $ | 2,096 |  |  | $ | 1,715 |  |  | $ | 4,198 |  |  | $ | 3,395 |  |
| Amortization of debt issuance costs |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Convertible senior notes due 2020 |  | $ | 175 |  |  | $ | — |  |  | $ | 353 |  |  | $ | — |  |
| Convertible senior notes due 2015 |  |  | 35 |  |  |  | 174 |  |  |  | 69 |  |  |  | 343 |  |
|  |  | $ | 210 |  |  | $ | 174 |  |  | $ | 422 |  |  | $ | 343 |  |

- removed (2014-08-05):
[0001193125-14-184523:note_history:19]
|  |  | For the Quarter Ended |  |
|  |  | March 31, 2014 |  |  | April 1, 2013 |  |
|  |  | (In thousands) |  |
| Contractual coupon interest |  |  |  |  |  |  |  |  |
| Convertible senior notes due 2020 |  | $ | 1,085 |  |  | $ | — |  |
| Convertible senior notes due 2015 |  |  | 263 |  |  |  | 1,422 |  |
|  |  | $ | 1,348 |  |  | $ | 1,422 |  |
| Amortization of debt discount |  |  |  |  |  |  |  |  |
| Convertible senior notes due 2020 |  | $ | 1,764 |  |  | $ | — |  |
| Convertible senior notes due 2015 |  |  | 338 |  |  |  | 1,680 |  |
|  |  | $ | 2,102 |  |  | $ | 1,680 |  |
| Amortization of debt issuance costs |  |  |  |  |  |  |  |  |
| Convertible senior notes due 2020 |  | $ | 177 |  |  | $ | — |  |
| Convertible senior notes due 2015 |  |  | 34 |  |  |  | 169 |  |
|  |  | $ | 211 |  |  | $ | 169 |  |


## ttmi:ScheduleOfLiabilityAndEquityComponentsOfConvertibleNotesTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2014-08-05):
[0001193125-14-295293:note_history:20]
As of June 30, 2014 and December 30, 2013, the
 following summarizes the liability and equity components of the
 convertible senior notes:
  (was, 2014-05-06, similarity 0.9641):
[0001193125-14-184523:note_history:20]
As of March 31, 2014 and December 30, 2013, the
 following summarizes the liability and equity components of the
 convertible senior notes:

- added (2014-08-05):
[0001193125-14-295293:note_history:21]
|  |  | As of June 30, 2014 |  |  | As of December 30, 2013 |  |
|  |  | Principal |  |  | Unamortized Discount |  |  | Net Carrying Amount |  |  | Principal |  |  | Unamortized Discount |  |  | Net Carrying Amount |  |
|  |  | (in thousands) |  |
| Liability components: |  |  |  |  |
| Convertible senior notes due 2020 |  | $ | 250,000 |  |  | $ | (56,545 | ) |  | $ | 193,455 |  |  | $ | 220,000 |  |  | $ | (52,833 | ) |  | $ | 167,167 |  |
| Convertible senior notes due 2015 |  |  | 32,395 |  |  |  | (1,266 | ) |  |  | 31,129 |  |  |  | 38,909 |  |  |  | (2,341 | ) |  |  | 36,568 |  |
| Total |  | $ | 282,395 |  |  | $ | (57,811 | ) |  | $ | 224,584 |  |  | $ | 258,909 |  |  | $ | (55,174 | ) |  | $ | 203,735 |  |
|  |  | As of June 30, 2014 |  |  | As of December 30, 2013 |  |
|  |  | Embedded conversion option — Convertible Senior Notes |  |  | Embedded conversion option — Convertible Senior Notes Issuance Costs |  |  | Total |  |  | Embedded conversion option — Convertible Senior Notes |  |  | Embedded conversion option — Convertible Senior Notes Issuance Costs |  |  | Total |  |
|  |  | (in thousands) |  |
| Equity components: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Additional paid-in capital: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Convertible senior notes due 2020 |  | $ | 60,227 |  |  | $ | (1,916 | ) |  | $ | 58,311 |  |  | $ | 53,000 |  |  | $ | (1,644 | ) |  | $ | 51,356 |  |
| Convertible senior notes due 2015 |  |  | 39,781 |  |  | $ | (1,413 | ) |  |  | 38,368 |  |  |  | 39,928 |  |  |  | (1,413 | ) |  |  | 38,515 |  |
|  |  | $ | 100,008 |  |  | $ | (3,329 | ) |  | $ | 96,679 |  |  | $ | 92,928 |  |  | $ | (3,057 | ) |  | $ | 89,871 |  |

- removed (2014-08-05):
[0001193125-14-184523:note_history:22]
|  |  | As of March 31, 2014 |  |  | As of December 30, 2013 |  |
|  |  | Principal |  |  | Unamortized Discount |  |  | Net Carrying Amount |  |  | Principal |  |  | Unamortized Discount |  |  | Net Carrying Amount |  |
|  |  | (in thousands) |  |
| Liability components: |  |  |  |  |
| Convertible senior notes due 2020 |  | $ | 250,000 |  |  | $ | (58,295 | ) |  | $ | 191,705 |  |  | $ | 220,000 |  |  | $ | (52,833 | ) |  | $ | 167,167 |  |
| Convertible senior notes due 2015 |  |  | 32,395 |  |  |  | (1,612 | ) |  |  | 30,783 |  |  |  | 38,909 |  |  |  | (2,341 | ) |  |  | 36,568 |  |
| Total |  | $ | 282,395 |  |  | $ | (59,907 | ) |  | $ | 222,488 |  |  | $ | 258,909 |  |  | $ | (55,174 | ) |  | $ | 203,735 |  |

- removed (2014-08-05):
[0001193125-14-184523:note_history:23]
|  |  | As of March 31, 2014 |  |  | As of December 30, 2013 |  |
|  |  | Embedded conversion option — Convertible Senior Notes |  |  | Embedded conversion option — Convertible Senior Notes Issuance Costs |  |  | Total |  |  | Embedded conversion option — Convertible Senior Notes |  |  | Embedded conversion option — Convertible Senior Notes Issuance Costs |  |  | Total |  |
|  |  | (in thousands) |  |
| Equity components: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Additional paid-in capital: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Convertible senior notes due 2020 |  | $ | 60,227 |  |  | $ | (1,916 | ) |  | $ | 58,311 |  |  | $ | 53,000 |  |  | $ | (1,644 | ) |  | $ | 51,356 |  |
| Convertible senior notes due 2015 |  |  | 39,781 |  |  | $ | (1,413 | ) |  |  | 38,368 |  |  |  | 39,928 |  |  | $ | (1,413 | ) |  |  | 38,515 |  |
|  |  | $ | 100,008 |  |  | $ | (3,329 | ) |  | $ | 96,679 |  |  | $ | 92,928 |  |  | $ | (3,057 | ) |  | $ | 89,871 |  |


## us-gaap:LongTermDebtTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2014-08-05):
[0001193125-14-295293:note_history:24]
The following table summarizes the long-term debt of the
 Company as of June 30, 2014 and December 30,
 2013:
  (was, 2014-05-06, similarity 0.9538):
[0001193125-14-184523:note_history:24]
The following table summarizes the long-term debt of the
 Company as of March 31, 2014 and December 30,
 2013:

- changed (2014-08-05):
[0001193125-14-295293:note_history:25]
|  |  | Average Effective Interest Rate as of June 30, 2014 |  | June 30, 2014 |  |  | Average Effective Interest Rate as of December 30, 2013 |  | December 30, 2013 |  |
|  |  | (In thousands) |  |
| Term loan due September 2016 |  | 2.54% |  | $ | 321,900 |  |  | 2.55% |  | $ | 370,000 |  |
| Other |  | 6.00% |  |  | 6 |  |  | 6.00% |  |  | 8 |  |
|  |  |  |  |  | 321,906 |  |  |  |  |  | 370,008 |  |
| Less: current maturities |  |  |  |  | (96,205 | ) |  |  |  |  | (96,204 | ) |
| Long-term debt, less current maturities |  |  |  | $ | 225,701 |  |  |  |  | $ | 273,804 |  |
  (was, 2014-05-06, similarity 0.9602):
[0001193125-14-184523:note_history:25]
|  |  | Average Effective Interest Rate as of March 31, 2014 |  | March 31, 2014 |  |  | Average Effective Interest Rate as of December 30, 2013 |  | December 30, 2013 |  |
|  |  | (In thousands) |  |
| Term loan due September 2016 |  | 2.53% |  | $ | 321,900 |  |  | 2.55% |  | $ | 370,000 |  |
| Other |  | 6.00% |  |  | 7 |  |  | 6.00% |  |  | 8 |  |
|  |  |  |  |  | 321,907 |  |  |  |  |  | 370,008 |  |
| Less: current maturities |  |  |  |  | (96,205 | ) |  |  |  |  | (96,204 | ) |
| Long-term debt, less current maturities |  |  |  | $ | 225,702 |  |  |  |  | $ | 273,804 |  |

- changed (2014-08-05):
[0001193125-14-295293:note_history:26]
In 2012, the Company became a party to a facility agreement
 (Credit Agreement) consisting of a $370,000 senior secured term
 loan (Term Loan), a $90,000 senior secured revolving loan
 (Revolving Loan), and a secured $80,000 letters of credit facility
 (Letters of Credit Facility). The Term Loan and Letters of Credit
 Facility will mature on September 14, 2016. The Revolving Loan
 will mature on March 14, 2016. The Credit Agreement is secured
 by substantially all of the assets of the Company’s Asia
 Pacific operating segment and is senior to all other debt,
 including the convertible senior notes. See Note 5. The Company has
 fully and unconditionally guaranteed the full and timely payment of
 all Credit Agreement related obligations of its Asia Pacific
 operating segment.
  (was, 2014-05-06, similarity 0.9905):
[0001193125-14-184523:note_history:26]
In 2012, the Company became a party to a facility agreement
 (Credit Agreement) consisting of a $370,000 senior secured term
 loan (Term Loan), a $90,000 senior secured revolving loan
 (Revolving Loan), and a secured $80,000 letters of credit facility
 (Letters of Credit Facility). The Term Loan and Letters of Credit
 Facility will mature on September 14, 2016. The Revolving Loan
 will mature on March 14, 2016. The Credit Agreement is secured
 by substantially all of the assets of the Company’s Asia
 Pacific operating segment and is senior to all other debt,
 including the convertible senior notes. See Note 5. The Company has
 fully and unconditionally guaranteed the full and punctual payment
 of all Credit Agreement related obligations of its Asia Pacific
 operating segment.

- changed (2014-08-05):
[0001193125-14-295293:note_history:27]
As of June 30, 2014 and December 30, 2013, the
 remaining unamortized debt issuance costs included in other
 non-current assets was $1,525 and $1,937, respectively, and is
 amortized to interest expense over the term of the Company’s
 Credit Agreement using the effective interest rate method. At
 June 30, 2014, the remaining amortization period for the
 unamortized debt issuance costs was 2.0 years.
  (was, 2014-05-06, similarity 0.9558):
[0001193125-14-184523:note_history:27]
As of March 31, 2014 and December 30, 2013, the
 remaining unamortized debt issuance costs included in other
 non-current assets was $1,728 and $1,937 and is amortized to
 interest expense over the term of the Company’s Credit
 Agreement using the effective interest rate method. At
 March 31, 2014, the remaining amortization period for the
 unamortized debt issuance costs was 2.2 years.

- added (2014-08-05):
[0001193125-14-295293:note_history:28]
The Company is also required to pay a commitment fee of
 0.50% per annum on any unused portion of the loan and letters
 of credit facility granted under the Credit Agreement. The Company
 incurred commitment fees related to unused borrowing availability
 of $151 and $95 for the quarters ended June 30, 2014 and
 July 1, 2013, respectively, and $284 and $191 for the two
 quarters ended June 30, 2014 and July 1, 2013,
 respectively. As of June 30, 2014, the outstanding amount of
 the Term Loan under the Credit Agreement was $321,900, of which
 $96,200 is due for repayment through March 2015 and is included as
 short-term debt, with the remaining $225,700 included as long-term
 debt. None of the Revolver was outstanding under the Credit
 Agreement as of June 30, 2014. Available borrowing capacity
 under the Revolving Loan was $90,000 at June 30,
 2014.

- changed (2014-08-05):
[0001193125-14-295293:note_history:29]
Additionally, the Company is party to a revolving loan credit
 facility with a lender in the People’s Republic of China
 (PRC). Under this arrangement, the lender has made available to the
 Company approximately $46,600 in unsecured borrowing with all terms
 of the borrowing to be negotiated at the time the revolver is drawn
 upon. There are no commitment fees on the unused portion of the
 revolver and this arrangement expires in December 2014. As of
 June 30, 2014, the revolver had not been drawn
 upon.
  (was, 2014-05-06, similarity 0.9908):
[0001193125-14-184523:note_history:29]
Additionally, the Company is party to a revolving loan credit
 facility with a lender in the People’s Republic of China
 (PRC). Under this arrangement, the lender has made available to the
 Company approximately $46,700 in unsecured borrowing with all terms
 of the borrowing to be negotiated at the time the revolver is drawn
 upon. There are no commitment fees on the unused portion of the
 revolver and this arrangement expires in December 2014. As of
 March 31, 2014, the revolver had not been drawn
 upon.

- changed (2014-08-05):
[0001193125-14-295293:note_history:30]
The Company has an $80,000 Letters of Credit Facility under the
 Credit Agreement, as mentioned above. As of June 30, 2014,
 letters of credit in the amount of $46,183 were outstanding under
 this Credit Agreement. The Company has other standby letters of
 credit outstanding in the amount of $3,894, as well other unused
 letter of credit facilities in the amount of $24,100. The
 outstanding standby letters of credit and unused letter of credit
 facilities expire between December 31, 2014 and
 February 28, 2015.
  (was, 2014-05-06, similarity 0.9811):
[0001193125-14-184523:note_history:30]
The Company has an $80,000 Letters of Credit Facility under the
 Credit Agreement, as mentioned above. As of March 31, 2014,
 letters of credit in the amount of $56,986 were outstanding under
 this Credit Agreement. The Company has other standby letters of
 credit outstanding in the amount of $3,394 million, as well other
 unused letter of credit facilities in the amount of $31,100. The
 outstanding standby letters of credit and unused letter of credit
 facilities expire between December 31, 2014 and
 February 28, 2015.

- removed (2014-08-05):
[0001193125-14-184523:note_history:31]
The Company is also required to pay a commitment fee of
 0.50% per annum on any unused portion of the loan and letters
 of credit facility granted under the Credit Agreement. The Company
 incurred commitment fees related to unused borrowing availability
 of $133 and $96 for the quarters ended March 31, 2014 and
 April 1, 2013, respectively. As of March 31, 2014, the
 outstanding amount of the Term Loan under the Credit Agreement is
 $321,900, of which $96,200 is due for repayment in September 2014
 and March 2015 and is included as short-term debt, with the
 remaining $225,700 included as long-term debt. None of the Revolver
 was outstanding under the Credit Agreement as of March 31,
 2014. Available borrowing capacity under the Revolving Loan was
 $90,000 at March 31, 2014.


## us-gaap:ScheduleOfDebtInstrumentsTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2014-08-05):
[0001193125-14-295293:note_history:32]
The following table summarizes the long-term debt of the
 Company as of June 30, 2014 and December 30,
 2013:
  (was, 2014-05-06, similarity 0.9538):
[0001193125-14-184523:note_history:32]
The following table summarizes the long-term debt of the
 Company as of March 31, 2014 and December 30,
 2013:

- changed (2014-08-05):
[0001193125-14-295293:note_history:33]
|  |  | Average Effective Interest Rate as of June 30, 2014 |  | June 30, 2014 |  |  | Average Effective Interest Rate as of December 30, 2013 |  | December 30, 2013 |  |
|  |  | (In thousands) |  |
| Term loan due September 2016 |  | 2.54% |  | $ | 321,900 |  |  | 2.55% |  | $ | 370,000 |  |
| Other |  | 6.00% |  |  | 6 |  |  | 6.00% |  |  | 8 |  |
|  |  |  |  |  | 321,906 |  |  |  |  |  | 370,008 |  |
| Less: current maturities |  |  |  |  | (96,205 | ) |  |  |  |  | (96,204 | ) |
| Long-term debt, less current maturities |  |  |  | $ | 225,701 |  |  |  |  | $ | 273,804 |  |
  (was, 2014-05-06, similarity 0.9602):
[0001193125-14-184523:note_history:33]
|  |  | Average Effective Interest Rate as of March 31, 2014 |  | March 31, 2014 |  |  | Average Effective Interest Rate as of December 30, 2013 |  | December 30, 2013 |  |
|  |  | (In thousands) |  |
| Term loan due September 2016 |  | 2.53% |  | $ | 321,900 |  |  | 2.55% |  | $ | 370,000 |  |
| Other |  | 6.00% |  |  | 7 |  |  | 6.00% |  |  | 8 |  |
|  |  |  |  |  | 321,907 |  |  |  |  |  | 370,008 |  |
| Less: current maturities |  |  |  |  | (96,205 | ) |  |  |  |  | (96,204 | ) |
| Long-term debt, less current maturities |  |  |  | $ | 225,702 |  |  |  |  | $ | 273,804 |  |


## us-gaap:RelatedPartyTransactionsDisclosureTextBlock (related_parties) — matched_by: tag_name, score: 1.0

- added (2014-08-05):
[0001193125-14-295293:note_history:34]
In the normal course of business, the Company’s foreign
 subsidiaries purchase laminate and prepreg from related parties in
 which a significant shareholder of the Company holds an equity
 interest. The Company purchased laminate and prepreg from these
 related parties in the amount of $13,390 and $18,472 for the
 quarters ended June 30, 2014 and July 1, 2013,
 respectively, and $25,180 and $37,609 for the two quarters ended
 June 30, 2014 and July 1, 2013, respectively.

- added (2014-08-05):
[0001193125-14-295293:note_history:35]
Dongguan Shengyi Electronics Ltd., (SYE) is a related party as
 a significant shareholder of the Company holds an equity interest
 in the parent company of SYE. Subsequent to the Company’s
 sale of its controlling interest in SYE in June 2013, the Company
 began selling PCBs to, and purchasing PCBs from, SYE. Sales to SYE
 for the quarter and two quarters ended June 30, 2014 were
 approximately $9,100 and $19,253, respectively, and $4,009 for both
 the quarter and two quarters ended July 1, 2013. Additionally,
 purchases from SYE for the quarter and two quarters ended
 June 30, 2014 were approximately $201 and $472, respectively.
 There were no purchases from SYE for the quarter or two quarters
 ended July 1, 2013.

- changed (2014-08-05):
[0001193125-14-295293:note_history:36]
As of June 30, 2014 and December 30, 2013, the
 Company’s consolidated condensed balance sheet included
 $20,482 and $19,547, respectively, in accounts payable due to, and
 $14,269 and $13,312, respectively, in accounts receivable due from
 related parties for the purchase of laminate and prepreg, and sales
 of PCBs to SYE, as mentioned above.
  (was, 2014-05-06, similarity 0.9366):
[0001193125-14-184523:note_history:36]
As of March 31, 2014 and December 30, 2013, the
 Company’s consolidated condensed balance sheet included
 $19,882 and $19,547, respectively, in accounts payable due to, and
 $16,975 and $13,312, respectively, in accounts receivable due from
 a related party for the purchase of laminate and prepreg, and sales
 of PCBs to SYE, as mentioned above.

- removed (2014-08-05):
[0001193125-14-184523:note_history:37]
In the normal course of business, the Company’s foreign
 subsidiaries purchase laminate and prepreg from related parties in
 which a significant shareholder of the Company holds an equity
 interest. For the quarters ended March 31, 2014 and
 April 1, 2013, the Company’s foreign subsidiaries
 purchased $11,790 and $19,137 respectively, of laminate and prepreg
 from these related parties.

- removed (2014-08-05):
[0001193125-14-184523:note_history:38]
Dongguan Shengyi Electronics Ltd., (SYE) is a related party as
 a significant shareholder of the Company holds an equity interest
 in the parent company of SYE. Subsequent to the Company’s
 sale of its controlling interest in SYE in June 2013, the Company
 began selling PCBs to, and purchasing PCBs from, SYE. Sales to and
 purchases from SYE, for the quarter ended March 31, 2014 were
 approximately $10,147 and $271, respectively. There were no sales
 to or purchases from SYE for the quarter ended April 1,
 2013.
