# TTMI note change history — 0001193125-14-404493 → 0001193125-15-170026


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2015-05-05):
[0001193125-15-170026:note_history:1]
The Company is subject to various legal matters, which it
 considers normal for its business activities. While the Company
 currently believes that the amount of any reasonably possible or
 probable loss for known matters would not be material to the
 Company’s financial condition, the outcome of these actions
 is inherently difficult to predict. In the event of an adverse
 outcome, the ultimate potential loss could have a material adverse
 effect on the Company’s financial condition or results of
 operations in a particular period. The Company has accrued amounts
 for its loss contingencies which are probable and estimable as of
 March 30, 2015 and December 29, 2014. However, these
 amounts are not material to the consolidated financial statements
 of the Company.
  (was, 2014-11-10, similarity 0.9795):
[0001193125-14-404493:note_history:1]
The
 Company is subject to various legal matters, which it considers
 normal for its business activities. While the Company currently
 believes that the amount of any reasonably possible or probable
 loss for known matters would not be material to the Company’s
 financial condition, the outcome of these actions is inherently
 difficult to predict. In the event of an adverse outcome, the
 ultimate potential loss could have a material adverse effect on the
 Company’s financial condition or results of operations in a
 particular period. The Company has accrued amounts for its loss
 contingencies which are probable and estimable at
 September 29, 2014 and December 30, 2013. However, these
 amounts are not material to the consolidated condensed financial
 statements of the Company.

- changed (2015-05-05):
[0001193125-15-170026:note_history:2]
The Lawsuits seek injunctive relief to enjoin the defendants
 from completing the Merger on the agreed-upon terms, rescinding, to
 the extent already implemented, the Merger Agreement or any of the
 terms therein, costs and disbursements and attorneys’ and
 experts’ fees and costs, as well as other equitable relief as
 the respective court deems proper. The Delaware Lawsuit also seeks:
 (1) in the event the Merger is consummated prior to the entry
 of the court’s final judgment, rescissory damages as an
 alternative to rescission, and (2) an accounting by all
 defendants to the plaintiff and other members of the class for all
 damages caused by the defendants and for all profits and any
 special benefits obtained as a result of their alleged breaches of
 their fiduciary duties.
  (was, 2014-11-10, similarity 0.9718):
[0001193125-14-404493:note_history:2]
The
 Lawsuits seek injunctive relief to enjoin the defendants from
 completing the Merger on the agreed-upon terms, rescinding, to the
 extent already implemented, the Merger Agreement or any of the
 terms therein, costs and disbursements and attorneys’ and
 experts’ fees and costs, as well as other equitable relief as
 the respective court deems proper. The Delaware Lawsuit also seeks:
 (1) in the event the Merger is consummated prior to the entry
 of the court’s final judgment, rescissory damages as an
 alternative to rescission, and (2) an accounting by all
 defendants to the plaintiff and other members of the class for all
 damages caused by the defendants and for all profits and any
 special benefits obtained as a result of their alleged breaches of
 their fiduciary duties. TTM believes the Lawsuits are without
 merit.

- added (2015-05-05):
[0001193125-15-170026:note_history:3]
On January 6, 2015, the parties to the Missouri Lawsuit
 entered into a Memorandum of Understanding (MOU) with respect to a
 proposed settlement that will terminate both Lawsuits upon entry of
 the final judgment. The parties are in the process of
 negotiating this settlement agreement. Pursuant to the MOU,
 the settlement agreement will provide for payment of
 attorneys’ fees and reimbursement of expenses, and releases
 of all claims and relief sought in both Lawsuits.

- added (2015-05-05):
[0001193125-15-170026:note_history:4]
The process to manufacture PCBs requires adherence to city,
 county, state, federal, and foreign environmental regulations
 regarding the storage, use, handling and disposal of chemicals,
 solid wastes and other hazardous materials, as well as compliance
 with air quality standards and chemical use reporting. The Company
 believes that its facilities in the United States comply in all
 material respects with applicable environmental laws and
 regulations. In China, governmental authorities have adopted
 new rules and regulations governing environmental issues. An
 update to the Chinese environmental waste water law was issued in
 late 2012, but allows for an interim period in which plants subject
 to such law may install equipment that meets the new regulatory
 regime. Some of the Company’s plants in China are not yet in
 full compliance with the updated environmental
 regulations. The Company believes it has developed plans
 acceptable to the Chinese government and is in the process of
 implementing these plans. The Company does not anticipate any
 immediate risk of government fines or temporary closure of its
 Chinese plants. The Company has established and enacted an
 investment plan related to the efforts to come into full compliance
 with the new regulations. The 2015 capital expenditure costs
 expected for these plans are included in the Company’s
 capital expenditure projections.

- removed (2015-05-05):
[0001193125-14-404493:note_history:5]
The
 process to manufacture PCBs requires adherence to city, county,
 state, federal and foreign environmental regulations regarding the
 storage, use, handling and disposal of chemicals, solid wastes and
 other hazardous materials as well as compliance with air quality
 standards and chemical use reporting. The Company believes that its
 facilities in the United States comply in all material respects
 with applicable environmental laws and regulations. In China,
 governmental authorities have adopted new rules and regulations
 governing environmental issues. An update to Chinese
 environmental water waste law was issued in late 2012, but allows
 for an interim period in which plants subject to such law may
 install equipment that meets the new regulatory regime and come
 into full compliance with the new laws in 2014 and 2015, depending
 on the province of China in which such plant is located. The
 Company’s plants in China are not yet in full compliance with
 the newly adopted environmental regulations as updated in late
 2012. The Company expects to come into compliance and does not
 anticipate any immediate risk of government fines or temporary
 closure of its Chinese plants. The Company has established and
 enacted an investment plan, which includes capital expenditures
 estimated to be approximately $15, 000 through 2015, to address the
 regulatory changes in order to come into full compliance during the
 interim period.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- added (2015-05-05):
[0001193125-15-170026:note_history:6]
TTM Technologies, Inc. (the Company or TTM) is a leading global
 provider of time-critical and technologically complex printed
 circuit board (PCB) products and backplane assemblies (i.e., PCBs
 populated with electronic components), which serve as the
 foundation of sophisticated electronic products. The Company
 provides time-to-market and advanced technology products and offers
 a one-stop manufacturing solution to customers from engineering
 support to prototype development through final volume production.
 This one-stop manufacturing solution allows the Company to align
 technology developments with the diverse needs of the
 Company’s customers and to enable them to reduce the time
 required to develop new products and bring them to
 market.

- changed (2015-05-05):
[0001193125-15-170026:note_history:7]
Additionally, the Company serves a diversified customer base in
 various markets throughout the world, including manufacturers of
 networking/communications infrastructure products, touchscreen
 tablets and smartphones, as well as the aerospace and defense,
 high-end computing, and industrial/medical industries. The
 Company’s customers include both original equipment
 manufacturers (OEMs) and electronic manufacturing services (EMS)
 providers.
  (was, 2014-11-10, similarity 0.6079):
[0001193125-14-404493:note_history:7]
TTM Technologies, Inc. (the Company or TTM) is a leading global
 provider of time-critical and technologically complex printed
 circuit board (PCB) products and backplane assemblies (PCBs
 populated with electronic components), which serve as the
 foundation of sophisticated electronic products. The Company
 provides advanced technology products and offers a one-stop
 manufacturing solution to customers from engineering support to
 prototype development through final volume production. The Company
 serves a diversified customer base in various markets throughout
 the world, including manufacturers of networking/communications
 infrastructure products, touch screen tablets and smartphones. The
 Company also serves aerospace and defense, high-end computing, and
 industrial/medical industries. The Company’s customers
 include both original equipment manufacturers (OEMs) and electronic
 manufacturing services (EMS) providers.

- changed (2015-05-05):
[0001193125-15-170026:note_history:8]
The accompanying consolidated condensed financial statements
 have been prepared by the Company, without audit, pursuant to the
 rules and regulations of the Securities and Exchange Commission
 (SEC). Certain information and disclosures normally included in
 financial statements prepared in accordance with accounting
 principles generally accepted in the United States of America (U.S.
 GAAP) have been condensed or omitted pursuant to such rules and
 regulations. These consolidated condensed financial statements
 reflect all adjustments (consisting only of normal recurring
 adjustments) which, in the opinion of management, are necessary to
 present fairly the financial position, the results of operations
 and cash flows of the Company for the periods presented. It is
 suggested that these consolidated condensed financial statements be
 read in conjunction with the consolidated financial statements and
 the notes thereto included in the Company’s most recent
 Annual Report on Form 10-K. The results of operations for the
 interim periods are not necessarily indicative of the results to be
 expected for the full year. The preparation of financial statements
 in accordance with U.S. GAAP requires management to make estimates
 and assumptions that affect the amounts reported in the
 Company’s consolidated condensed financial statements and
 accompanying notes. Actual results could differ materially from
 those estimates. The Company uses a 13-week fiscal quarter
 accounting period with the fourth quarter ending on the Monday
 nearest December 31.
  (was, 2014-11-10, similarity 0.9826):
[0001193125-14-404493:note_history:8]
The accompanying consolidated condensed financial statements
 have been prepared by the Company, without audit, pursuant to the
 rules and regulations of the Securities and Exchange Commission
 (SEC). Certain information and disclosures normally included in
 financial statements prepared in accordance with accounting
 principles generally accepted in the United States of America have
 been condensed or omitted pursuant to such rules and regulations.
 These consolidated condensed financial statements reflect all
 adjustments (consisting only of normal recurring adjustments)
 which, in the opinion of management, are necessary to present
 fairly the financial position, the results of operations and cash
 flows of the Company for the periods presented. It is suggested
 that these consolidated condensed financial statements be read in
 conjunction with the consolidated financial statements and the
 notes thereto included in the Company’s most recent Annual
 Report on Form 10-K. The results of operations for the interim
 periods are not necessarily indicative of the results to be
 expected for the full year. The preparation of financial statements
 in accordance with U.S. generally accepted accounting principles
 requires management to make estimates and assumptions that affect
 the amounts reported in the Company’s consolidated condensed
 financial statements and accompanying notes. Actual results could
 differ materially from those estimates. The Company uses a 13-week
 fiscal quarter accounting period with the fourth quarter ending on
 the Monday nearest December 31.

- added (2015-05-05):
[0001193125-15-170026:note_history:9]
In April 2015, the Financial Accounting Standards Board (FASB)
 issued Accounting Standard Update (ASU) 2015-03,
 Interest-Imputation of Interest, which requires an entity to
 record debt issuance costs related to a note reported in the
 balance sheet as a direct deduction from the face amount of that
 note. The update is effective for annual periods ending after
 December 15, 2015. Early application is permitted. The
 standard requires the use of the retrospective transition method.
 The impact on the Company’s financial statements is not
 expected to be material.

- added (2015-05-05):
[0001193125-15-170026:note_history:10]
In August 2014, the FASB issued ASU 2014-15 Disclosure of
 Uncertainties About an Entity’s Ability to Continue as a
 Going Concern, which provides guidance on determining when and
 how to disclose going concern uncertainties in the financial
 statements. The new standard requires management to perform interim
 and annual assessments of an entity’s ability to continue as
 a going concern. The update is effective for annual periods ending
 after December 15, 2016, and interim periods thereafter. Early
 adoption is permitted. The impact on the Company’s financial
 statements of adopting ASU 2014-15 is not expected to be
 material.

- added (2015-05-05):
[0001193125-15-170026:note_history:11]
In May 2014, the FASB issued ASU 2014-09, Revenue from
 Contracts with Customers, which requires an entity to recognize
 the amount of revenue to which it expects to be entitled for the
 transfer of promised goods or services to customers. ASU 2014-09
 will replace most existing revenue recognition guidance in U.S.
 GAAP when it becomes effective. The new standard is effective for
 the Company at the beginning of fiscal year 2017. Early application
 is not permitted. The standard permits the use of either the
 retrospective or cumulative effect transition method. We are
 evaluating the effect that ASU 2014-09 will have on the
 Company’s consolidated financial statements and related
 disclosures. The Company has not yet selected a transition method,
 nor has the Company determined the effect of the standard on its
 ongoing financial reporting.

- removed (2015-05-05):
[0001193125-14-404493:note_history:12]
On May 28, 2014, the Financial Accounting Standards Board
 (FASB) issued Accounting Standards Update No. (ASU) 2014-09,
 Revenue from Contracts with Customers, which requires an
 entity to recognize the amount of revenue to which it expects to be
 entitled for the transfer of promised goods or services to
 customers. The ASU will replace most existing revenue recognition
 guidance in U.S. GAAP when it becomes effective. The new standard
 is effective for the Company at the beginning of fiscal year 2017.
 Early application is not permitted. The standard permits the use of
 either the retrospective or cumulative effect transition method.
 The Company is evaluating the effect that ASU 2014-09 will have on
 its consolidated financial statements and related disclosures. The
 Company has not yet selected a transition method nor has it
 determined the effect of the standard on its ongoing financial
 reporting.

- removed (2015-05-05):
[0001193125-14-404493:note_history:13]
In July 2013, the FASB issued an update that would require an
 unrecognized tax benefit, or a portion of an unrecognized benefit,
 to be presented in the financial statements as a reduction to a
 deferred tax asset for a net operating loss carryforward, a similar
 tax loss, or a tax credit carryforward. This update is effective
 for interim and annual periods beginning after December 15,
 2013, with early adoption permitted. The Company adopted the
 amendment on January 1, 2014, and its adoption did not have a
 material impact on its financial statements.


## ttmi:ConvertibleSeniorNotesTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2015-05-05):
[0001193125-15-170026:note_history:14]
The Company issued 1.75% convertible senior notes due
 December 15, 2020, in a public offering for an aggregate
 principal amount of $250,000. The convertible senior notes bear
 interest at a rate of 1.75% per annum. Interest is payable
 semiannually in arrears on June 15 and December 15 of
 each year. The convertible senior notes are senior unsecured
 obligations and rank equally to the Company’s future
 unsecured senior indebtedness and senior in right of payment to any
 of the Company’s future subordinated indebtedness.
  (was, 2014-11-10, similarity 0.9862):
[0001193125-14-404493:note_history:14]
In December 2013, the Company issued 1.75% convertible
 senior notes due December 15, 2020, in a public offering for
 an aggregate principal amount of $220,000. The convertible senior
 notes bear interest at a rate of 1.75% per annum. Interest is
 payable semiannually in arrears on June 15 and
 December 15 of each year. The convertible senior notes are
 senior unsecured obligations and rank equally to the
 Company’s future unsecured senior indebtedness and senior in
 right of payment to any of the Company’s future subordinated
 indebtedness.

- changed (2015-05-05):
[0001193125-15-170026:note_history:15]
The maximum number of shares issuable upon conversion,
 including the effect of a fundamental change and subject to certain
 conversion adjustments, would be 32,425.
  (was, 2014-11-10, similarity 0.959):
[0001193125-14-404493:note_history:15]
The maximum number of shares issuable upon conversion,
 including the effect of a fundamental change and subject to Other
 Conversion Rate Adjustments, would be 32,425.

- added (2015-05-05):
[0001193125-15-170026:note_history:16]
Convertible Note Hedge and Warrant
 Transaction: In connection with the issuance of the
 convertible senior notes due 2020, the Company entered into a
 convertible note hedge and warrant transaction (Call Spread
 Transaction), with respect to the Company’s common stock. The
 convertible note hedge consists of the Company’s option to
 purchase up to 25,940 common stock shares at a price of $9.64 per
 share. The hedge expires on December 15, 2020 and can only be
 executed upon the conversion of the above mentioned convertible
 senior notes due 2020. Additionally, the Company sold warrants to
 purchase 25,940 shares of its common stock at a price of
 $14.26 per share. The warrants expire ratably from March 2021
 through January 2022. The 2020 Call Spread Transaction has no
 effect on the terms of the convertible senior notes due 2020 and
 reduces potential dilution by effectively increasing the conversion
 price of the convertible senior notes due 2020 to $14.26 per share
 of the Company’s common stock.

- added (2015-05-05):
[0001193125-15-170026:note_history:17]
The Company issued 3.25% convertible senior notes due on
 May 15, 2015, in a public offering for an aggregate principal
 amount of $175,000. On May 15, 2015, the outstanding principal
 of $32,395 plus accrued interest is due and payable. The
 convertible senior notes are senior unsecured obligations and rank
 equally to the Company’s future unsecured senior indebtedness
 and senior in right of payment to any of the Company’s future
 subordinated indebtedness.

- changed (2015-05-05):
[0001193125-15-170026:note_history:18]
The maximum number of shares issuable upon conversion,
 including the effect of a fundamental change and subject to certain
 conversion adjustments, would be 2,587.
  (was, 2014-11-10, similarity 0.959):
[0001193125-14-404493:note_history:18]
The maximum number of shares issuable upon conversion,
 including the effect of a fundamental change and subject to Other
 Conversion Rate Adjustments, would be 2,587.

- changed (2015-05-05):
[0001193125-15-170026:note_history:19]
As of March 30, 2015 and December 29, 2014, the
 following summarizes the liability and equity components of the
 convertible senior notes:
  (was, 2014-11-10, similarity 0.9609):
[0001193125-14-404493:note_history:19]
As of September 29, 2014 and December 30, 2013, the
 following summarizes the liability and equity components of the
 convertible senior notes:

- added (2015-05-05):
[0001193125-15-170026:note_history:20]
|  |  | As of March 30, 2015 |  |  | As of December 29, 2014 |  |
|  |  | Principal |  |  | Unamortized Discount |  |  | Net Carrying Amount |  |  | Principal |  |  | Unamortized Discount |  |  | Net Carrying Amount |  |
|  |  | (in thousands) |  |
| Liability components: |  |  |  |  |
| Convertible senior notes due 2020 |  | $ | 250,000 |  |  | $ | (51,120 | ) |  | $ | 198,880 |  |  | $ | 250,000 |  |  | $ | (52,958 | ) |  | $ | 197,042 |  |
| Convertible senior notes due 2015 |  |  | 32,395 |  |  |  | (187 | ) |  |  | 32,208 |  |  |  | 32,395 |  |  |  | (554 | ) |  |  | 31,841 |  |
| Total |  | $ | 282,395 |  |  | $ | (51,307 | ) |  | $ | 231,088 |  |  | $ | 282,395 |  |  | $ | (53,512 | ) |  | $ | 228,883 |  |

- added (2015-05-05):
[0001193125-15-170026:note_history:21]
|  |  | As of March 30, 2015 and December 29, 2014 |  |
|  |  | Embedded conversion option — Convertible Senior Notes |  |  | Embedded conversion option — Convertible Senior Notes Issuance Costs |  |  | Total |  |
|  |  | (in thousands) |  |
| Equity components: |  |  |  |  |  |  |  |  |  |  |  |  |
| Additional paid-in capital: |  |  |  |  |  |  |  |  |  |  |  |  |
| Convertible senior notes due 2020 |  | $ | 60,227 |  |  | $ | (1,916 | ) |  | $ | 58,311 |  |
| Convertible senior notes due 2015 |  |  | 39,781 |  |  |  | (1,413 | ) |  |  | 38,368 |  |
|  |  | $ | 100,008 |  |  | $ | (3,329 | ) |  | $ | 96,679 |  |

- changed (2015-05-05):
[0001193125-15-170026:note_history:22]
The components of interest expense resulting from the
 convertible senior notes for the quarters ended March 30, 2015
 and March 31, 2014 are as follows:
  (was, 2014-11-10, similarity 0.8766):
[0001193125-14-404493:note_history:22]
The components of interest expense resulting from the
 convertible senior notes for the quarter and three quarters ended
 September 29, 2014 and September 30, 2013 are as
 follows:

- changed (2015-05-05):
[0001193125-15-170026:note_history:23]
|  |  | For the Quarter Ended |  |
|  |  | March 30, 2015 |  |  | March 31, 2014 |  |
|  |  | (In thousands) |  |
| Contractual coupon interest |  |  |  |  |  |  |  |  |
| Convertible senior notes due 2020 |  | $ | 1,094 |  |  | $ | 1,085 |  |
| Convertible senior notes due 2015 |  |  | 263 |  |  |  | 263 |  |
|  |  | $ | 1,357 |  |  | $ | 1,348 |  |
| Amortization of debt discount |  |  |  |  |  |  |  |  |
| Convertible senior notes due 2020 |  | $ | 1,838 |  |  | $ | 1,764 |  |
| Convertible senior notes due 2015 |  |  | 367 |  |  |  | 338 |  |
|  |  | $ | 2,205 |  |  | $ | 2,102 |  |
| Amortization of debt issuance costs |  |  |  |  |  |  |  |  |
| Convertible senior notes due 2020 |  | $ | 184 |  |  | $ | 177 |  |
| Convertible senior notes due 2015 |  |  | 37 |  |  |  | 34 |  |
|  |  | $ | 221 |  |  | $ | 211 |  |
  (was, 2014-11-10, similarity 0.7235):
[0001193125-14-404493:note_history:23]
|  |  | For the Quarter Ended |  |  | For the Three Quarters Ended |  |
|  |  | September 29, 2014 |  |  | September 30, 2013 |  |  | September 29, 2014 |  |  | September 30, 2013 |  |
|  |  | (In thousands) |  |  | (In thousands) |  |
| Contractual coupon interest |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Convertible senior notes due 2020 |  | $ | 1,094 |  |  | $ | — |  |  | $ | 3,273 |  |  | $ | — |  |
| Convertible senior notes due 2015 |  |  | 263 |  |  |  | 1,422 |  |  |  | 790 |  |  |  | 4,266 |  |
|  |  | $ | 1,357 |  |  | $ | 1,422 |  |  | $ | 4,063 |  |  | $ | 4,266 |  |
| Amortization of debt discount |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Convertible senior notes due 2020 |  | $ | 1,779 |  |  | $ | — |  |  | $ | 5,294 |  |  | $ | — |  |
| Convertible senior notes due 2015 |  |  | 352 |  |  |  | 1,751 |  |  |  | 1,036 |  |  |  | 5,147 |  |
|  |  | $ | 2,131 |  |  | $ | 1,751 |  |  | $ | 6,330 |  |  | $ | 5,147 |  |
| Amortization of debt issuance costs |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Convertible senior notes due 2020 |  | $ | 178 |  |  | $ | — |  |  | $ | 531 |  |  | $ | — |  |
| Convertible senior notes due 2015 |  |  | 36 |  |  |  | 177 |  |  |  | 104 |  |  |  | 519 |  |
|  |  | $ | 214 |  |  | $ | 177 |  |  | $ | 635 |  |  | $ | 519 |  |

- changed (2015-05-05):
[0001193125-15-170026:note_history:24]
As of March 30, 2015 and December 29, 2014, remaining
 unamortized debt issuance costs included in other non-current
 assets were $5,142 and $5,363, respectively. The debt issuance
 costs and debt discount are being amortized to interest expense
 over the term of the convertible senior notes using the effective
 interest rate method. At March 30, 2015, the remaining
 weighted average amortization period for the unamortized senior
 convertible note discount and debt issuance costs was
 5.7 years.
  (was, 2014-11-10, similarity 0.9701):
[0001193125-14-404493:note_history:24]
As of September 29, 2014 and December 30, 2013,
 remaining unamortized debt issuance costs included in other
 non-current assets were $5,580 and $5,399, respectively. The debt
 issuance costs and debt discount are being amortized to interest
 expense over the term of the convertible senior notes using the
 effective interest rate method. At September 29, 2014, the
 remaining weighted average amortization period for the unamortized
 senior convertible note discount and debt issuance costs was
 6.1 years.

- changed (2015-05-05):
[0001193125-15-170026:note_history:25]
For the quarters ended March 30, 2015 and March 31,
 2014, the amortization of debt discount and debt issuance costs for
 the 2020 convertible senior notes and the 2015 convertible senior
 notes is based on an effective interest rate of 6.48% and 8.37%,
 respectively.
  (was, 2014-11-10, similarity 0.6287):
[0001193125-14-404493:note_history:25]
For the quarter and three quarters ended September 29,
 2014, the amortization of debt discount and debt issuance costs for
 the 2020 convertible senior notes and the 2015 convertible senior
 notes is based on an effective interest rate of 6.48% and 8.37%,
 respectively. For the quarter and three quarters ended
 September 30, 2013, the amortization of debt discount and debt
 issuance costs for the 2015 convertible senior notes is based on an
 effective interest rate of 8.37%.

- removed (2015-05-05):
[0001193125-14-404493:note_history:26]
In January 2014, the Company closed the sale of an additional
 $30,000 aggregate principal amount of its 1.75% convertible senior
 notes due 2020 (Additional Notes). The Additional Notes were sold
 pursuant to the exercise of an over-allotment option granted by the
 Company in the underwriting agreement related to the offer and sale
 of $220,000 aggregate principal amount of its 1.75% convertible
 senior notes due 2020.

- removed (2015-05-05):
[0001193125-14-404493:note_history:27]
In connection with the offering of the Additional Notes, the
 Company entered into additional convertible note hedge and warrant
 transactions (Additional Call Spread Transaction) with respect to
 shares of its common stock. The additional convertible note hedge,
 which cost an aggregate $7,953 and was recorded, net of tax, as a
 reduction of additional paid-in capital, consists of the
 Company’s option to purchase up to 3,100 common stock shares
 at a price of $9.64 per share and will expire upon the maturity of
 the notes. Additionally, the Company sold warrants to purchase
 3,100 shares of its common stock at a price of $14.26 per
 share. The warrants expire ratably from March 2021 through January
 2022. The proceeds from the sale of warrants of $4,053 was recorded
 as an increase to additional paid-in capital. The 2020 Additional
 Call Spread Transaction has no effect on the terms of the
 convertible senior notes due 2020 and reduces potential dilution by
 effectively increasing the conversion price of the convertible
 senior notes due 2020 to $14.26 per share of the Company’s
 common stock.

- removed (2015-05-05):
[0001193125-14-404493:note_history:28]
In May 2008, the Company issued 3.25% convertible senior
 notes due May 15, 2015, in a public offering for an aggregate
 principal amount of $175,000. The convertible senior notes bear
 interest at a rate of 3.25% per annum. Interest is payable
 semiannually in arrears on May 15 and November 15 of each
 year. The convertible senior notes are senior unsecured obligations
 and rank equally to the Company’s future unsecured senior
 indebtedness and senior in right of payment to any of the
 Company’s future subordinated indebtedness.

- removed (2015-05-05):
[0001193125-14-404493:note_history:29]
In January 2014, the Company repurchased $6,514 of notes at
 approximately 103.4% of their principal amount. The repurchase of
 the convertible senior notes was accounted for as an extinguishment
 of debt, and accordingly, the Company recognized a $506 loss
 primarily associated with the premium paid to repurchase the
 convertible senior notes and the recognition of certain remaining
 unamortized debt discount and issuance costs.

- removed (2015-05-05):
[0001193125-14-404493:note_history:30]
|  |  | As of September 29, 2014 |  |  | As of December 30, 2013 |  |
|  |  | Principal |  |  | Unamortized Discount |  |  | Net Carrying Amount |  |  | Principal |  |  | Unamortized Discount |  |  | Net Carrying Amount |  |
|  |  | (in thousands) |  |
| Liability components: |  |  |  |  |
| Convertible senior notes due 2020 |  | $ | 250,000 |  |  | $ | (54,766 | ) |  | $ | 195,234 |  |  | $ | 220,000 |  |  | $ | (52,833 | ) |  | $ | 167,167 |  |
| Convertible senior notes due 2015 |  |  | 32,395 |  |  |  | (914 | ) |  |  | 31,481 |  |  |  | 38,909 |  |  |  | (2,341 | ) |  |  | 36,568 |  |
| Total |  | $ | 282,395 |  |  | $ | (55,680 | ) |  | $ | 226,715 |  |  | $ | 258,909 |  |  | $ | (55,174 | ) |  | $ | 203,735 |  |
|  |  | As of September 29, 2014 |  |  | As of December 30, 2013 |  |
|  |  | Embedded conversion option — Convertible Senior Notes |  |  | Embedded conversion option — Convertible Senior Notes Issuance Costs |  |  | Total |  |  | Embedded conversion option — Convertible Senior Notes |  |  | Embedded conversion option — Convertible Senior Notes Issuance Costs |  |  | Total |  |
|  |  | (in thousands) |  |
| Equity components: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Additional paid-in capital: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Convertible senior notes due 2020 |  | $ | 60,227 |  |  | $ | (1,916 | ) |  | $ | 58,311 |  |  | $ | 53,000 |  |  | $ | (1,644 | ) |  | $ | 51,356 |  |
| Convertible senior notes due 2015 |  |  | 39,781 |  |  |  | (1,413 | ) |  |  | 38,368 |  |  |  | 39,928 |  |  |  | (1,413 | ) |  |  | 38,515 |  |
|  |  | $ | 100,008 |  |  | $ | (3,329 | ) |  | $ | 96,679 |  |  | $ | 92,928 |  |  | $ | (3,057 | ) |  | $ | 89,871 |  |


## ttmi:ScheduleOfComponentsOfInterestExpenseFromConvertibleNotesTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2015-05-05):
[0001193125-15-170026:note_history:31]
The components of interest expense resulting from the
 convertible senior notes for the quarters ended March 30, 2015
 and March 31, 2014 are as follows:
  (was, 2014-11-10, similarity 0.8766):
[0001193125-14-404493:note_history:31]
The components of interest expense resulting from the
 convertible senior notes for the quarter and three quarters ended
 September 29, 2014 and September 30, 2013 are as
 follows:

- changed (2015-05-05):
[0001193125-15-170026:note_history:32]
|  |  | For the Quarter Ended |  |
|  |  | March 30, 2015 |  |  | March 31, 2014 |  |
|  |  | (In thousands) |  |
| Contractual coupon interest |  |  |  |  |  |  |  |  |
| Convertible senior notes due 2020 |  | $ | 1,094 |  |  | $ | 1,085 |  |
| Convertible senior notes due 2015 |  |  | 263 |  |  |  | 263 |  |
|  |  | $ | 1,357 |  |  | $ | 1,348 |  |
| Amortization of debt discount |  |  |  |  |  |  |  |  |
| Convertible senior notes due 2020 |  | $ | 1,838 |  |  | $ | 1,764 |  |
| Convertible senior notes due 2015 |  |  | 367 |  |  |  | 338 |  |
|  |  | $ | 2,205 |  |  | $ | 2,102 |  |
| Amortization of debt issuance costs |  |  |  |  |  |  |  |  |
| Convertible senior notes due 2020 |  | $ | 184 |  |  | $ | 177 |  |
| Convertible senior notes due 2015 |  |  | 37 |  |  |  | 34 |  |
|  |  | $ | 221 |  |  | $ | 211 |  |
  (was, 2014-11-10, similarity 0.7235):
[0001193125-14-404493:note_history:32]
|  |  | For the Quarter Ended |  |  | For the Three Quarters Ended |  |
|  |  | September 29, 2014 |  |  | September 30, 2013 |  |  | September 29, 2014 |  |  | September 30, 2013 |  |
|  |  | (In thousands) |  |  | (In thousands) |  |
| Contractual coupon interest |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Convertible senior notes due 2020 |  | $ | 1,094 |  |  | $ | — |  |  | $ | 3,273 |  |  | $ | — |  |
| Convertible senior notes due 2015 |  |  | 263 |  |  |  | 1,422 |  |  |  | 790 |  |  |  | 4,266 |  |
|  |  | $ | 1,357 |  |  | $ | 1,422 |  |  | $ | 4,063 |  |  | $ | 4,266 |  |
| Amortization of debt discount |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Convertible senior notes due 2020 |  | $ | 1,779 |  |  | $ | — |  |  | $ | 5,294 |  |  | $ | — |  |
| Convertible senior notes due 2015 |  |  | 352 |  |  |  | 1,751 |  |  |  | 1,036 |  |  |  | 5,147 |  |
|  |  | $ | 2,131 |  |  | $ | 1,751 |  |  | $ | 6,330 |  |  | $ | 5,147 |  |
| Amortization of debt issuance costs |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Convertible senior notes due 2020 |  | $ | 178 |  |  | $ | — |  |  | $ | 531 |  |  | $ | — |  |
| Convertible senior notes due 2015 |  |  | 36 |  |  |  | 177 |  |  |  | 104 |  |  |  | 519 |  |
|  |  | $ | 214 |  |  | $ | 177 |  |  | $ | 635 |  |  | $ | 519 |  |


## ttmi:ScheduleOfLiabilityAndEquityComponentsOfConvertibleNotesTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2015-05-05):
[0001193125-15-170026:note_history:33]
As of March 30, 2015 and December 29, 2014, the
 following summarizes the liability and equity components of the
 convertible senior notes:
  (was, 2014-11-10, similarity 0.9609):
[0001193125-14-404493:note_history:33]
As of September 29, 2014 and December 30, 2013, the
 following summarizes the liability and equity components of the
 convertible senior notes:

- added (2015-05-05):
[0001193125-15-170026:note_history:34]
|  |  | As of March 30, 2015 |  |  | As of December 29, 2014 |  |
|  |  | Principal |  |  | Unamortized Discount |  |  | Net Carrying Amount |  |  | Principal |  |  | Unamortized Discount |  |  | Net Carrying Amount |  |
|  |  | (in thousands) |  |
| Liability components: |  |  |  |  |
| Convertible senior notes due 2020 |  | $ | 250,000 |  |  | $ | (51,120 | ) |  | $ | 198,880 |  |  | $ | 250,000 |  |  | $ | (52,958 | ) |  | $ | 197,042 |  |
| Convertible senior notes due 2015 |  |  | 32,395 |  |  |  | (187 | ) |  |  | 32,208 |  |  |  | 32,395 |  |  |  | (554 | ) |  |  | 31,841 |  |
| Total |  | $ | 282,395 |  |  | $ | (51,307 | ) |  | $ | 231,088 |  |  | $ | 282,395 |  |  | $ | (53,512 | ) |  | $ | 228,883 |  |

- added (2015-05-05):
[0001193125-15-170026:note_history:35]
|  |  | As of March 30, 2015 and December 29, 2014 |  |
|  |  | Embedded conversion option — Convertible Senior Notes |  |  | Embedded conversion option — Convertible Senior Notes Issuance Costs |  |  | Total |  |
|  |  | (in thousands) |  |
| Equity components: |  |  |  |  |  |  |  |  |  |  |  |  |
| Additional paid-in capital: |  |  |  |  |  |  |  |  |  |  |  |  |
| Convertible senior notes due 2020 |  | $ | 60,227 |  |  | $ | (1,916 | ) |  | $ | 58,311 |  |
| Convertible senior notes due 2015 |  |  | 39,781 |  |  |  | (1,413 | ) |  |  | 38,368 |  |
|  |  | $ | 100,008 |  |  | $ | (3,329 | ) |  | $ | 96,679 |  |

- removed (2015-05-05):
[0001193125-14-404493:note_history:36]
|  |  | As of September 29, 2014 |  |  | As of December 30, 2013 |  |
|  |  | Principal |  |  | Unamortized Discount |  |  | Net Carrying Amount |  |  | Principal |  |  | Unamortized Discount |  |  | Net Carrying Amount |  |
|  |  | (in thousands) |  |
| Liability components: |  |  |  |  |
| Convertible senior notes due 2020 |  | $ | 250,000 |  |  | $ | (54,766 | ) |  | $ | 195,234 |  |  | $ | 220,000 |  |  | $ | (52,833 | ) |  | $ | 167,167 |  |
| Convertible senior notes due 2015 |  |  | 32,395 |  |  |  | (914 | ) |  |  | 31,481 |  |  |  | 38,909 |  |  |  | (2,341 | ) |  |  | 36,568 |  |
| Total |  | $ | 282,395 |  |  | $ | (55,680 | ) |  | $ | 226,715 |  |  | $ | 258,909 |  |  | $ | (55,174 | ) |  | $ | 203,735 |  |
|  |  | As of September 29, 2014 |  |  | As of December 30, 2013 |  |
|  |  | Embedded conversion option — Convertible Senior Notes |  |  | Embedded conversion option — Convertible Senior Notes Issuance Costs |  |  | Total |  |  | Embedded conversion option — Convertible Senior Notes |  |  | Embedded conversion option — Convertible Senior Notes Issuance Costs |  |  | Total |  |
|  |  | (in thousands) |  |
| Equity components: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Additional paid-in capital: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Convertible senior notes due 2020 |  | $ | 60,227 |  |  | $ | (1,916 | ) |  | $ | 58,311 |  |  | $ | 53,000 |  |  | $ | (1,644 | ) |  | $ | 51,356 |  |
| Convertible senior notes due 2015 |  |  | 39,781 |  |  |  | (1,413 | ) |  |  | 38,368 |  |  |  | 39,928 |  |  |  | (1,413 | ) |  |  | 38,515 |  |
|  |  | $ | 100,008 |  |  | $ | (3,329 | ) |  | $ | 96,679 |  |  | $ | 92,928 |  |  | $ | (3,057 | ) |  | $ | 89,871 |  |


## us-gaap:LongTermDebtTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2015-05-05):
[0001193125-15-170026:note_history:37]
The following table summarizes the long-term debt of the
 Company as of March 30, 2015 and December 29,
 2014:
  (was, 2014-11-10, similarity 0.95):
[0001193125-14-404493:note_history:37]
The following table summarizes the long-term debt of the
 Company as of September 29, 2014 and December 30,
 2013:

- changed (2015-05-05):
[0001193125-15-170026:note_history:38]
|  |  | Average Effective Interest Rate as of March 30, 2015 |  | March 30, 2015 |  |  | Average Effective Interest Rate as of December 29, 2014 |  | December 29, 2014 |  |
|  |  | (In thousands) |  |
| Term loan due September 2016 |  | 2.56% |  | $ | 225,700 |  |  | 2.55% |  | $ | 273,800 |  |
| Other |  | 6.00% |  |  | 2 |  |  | 6.00% |  |  | 4 |  |
|  |  |  |  |  | 225,702 |  |  |  |  |  | 273,804 |  |
| Less: current maturities |  |  |  |  | (96,202 | ) |  |  |  |  | (96,204 | ) |
| Long-term debt, less current maturities |  |  |  | $ | 129,500 |  |  |  |  | $ | 177,600 |  |
  (was, 2014-11-10, similarity 0.9497):
[0001193125-14-404493:note_history:38]
|  |  | Average Effective Interest Rate as of September 29, 2014 |  | September 29, 2014 |  |  | Average Effective Interest Rate as of December 30, 2013 |  | December 30, 2013 |  |
|  |  | (In thousands) |  |
| Term loan due September 2016 |  | 2.53% |  | $ | 273,800 |  |  | 2.55% |  | $ | 370,000 |  |
| Other |  | 6.00% |  |  | 5 |  |  | 6.00% |  |  | 8 |  |
|  |  |  |  |  | 273,805 |  |  |  |  |  | 370,008 |  |
| Less: current maturities |  |  |  |  | (96,205 | ) |  |  |  |  | (96,204 | ) |
| Long-term debt, less current maturities |  |  |  | $ | 177,600 |  |  |  |  | $ | 273,804 |  |

- changed (2015-05-05):
[0001193125-15-170026:note_history:39]
|  |  | (In thousands) |  |
| Remaining 2015 |  | $ | 48,102 |  |
| 2016 |  |  | 177,600 |  |
|  |  | $ | 225,702 |  |
  (was, 2014-11-10, similarity 0.9367):
[0001193125-14-404493:note_history:39]
|  |  | (In thousands) |  |
| 2015 |  | $ | 96,205 |  |
| 2016 |  |  | 177,600 |  |
|  |  | $ | 273,805 |  |

- changed (2015-05-05):
[0001193125-15-170026:note_history:40]
In 2012, the Company became a party to a facility agreement
 (Credit Agreement) consisting of a $370,000 senior secured term
 loan (Term Loan), a $90,000 senior secured revolving loan
 (Revolving Loan), and a secured $80,000 letters of credit facility
 (Letters of Credit Facility). The Term Loan and Letters of Credit
 Facility will mature on September 14, 2016. The Revolving Loan
 will mature on March 14, 2016. The Credit Agreement is secured
 by substantially all of the assets of the Company’s Asia
 Pacific operating segment and is senior to all other debt,
 including the convertible senior notes. See Note 6 to these
 Consolidated Condensed Financial Statements. The Company has fully
 and unconditionally guaranteed the full and timely payment of all
 Credit Agreement related obligations of its Asia Pacific operating
 segment.
  (was, 2014-11-10, similarity 0.9833):
[0001193125-14-404493:note_history:40]
In 2012, the Company became a party to a facility agreement
 (Credit Agreement) consisting of a $370,000 senior secured term
 loan (Term Loan), a $90,000 senior secured revolving loan
 (Revolving Loan), and a secured $80,000 letters of credit facility
 (Letters of Credit Facility). The Term Loan and Letters of Credit
 Facility will mature on September 14, 2016. The Revolving Loan
 will mature on March 14, 2016. The Credit Agreement is secured
 by substantially all of the assets of the Company’s Asia
 Pacific operating segment and is senior to all other debt,
 including the convertible senior notes. See Note 6 to these
 Consolidated Condensed Financial Statements for additional
 information. The Company has fully and unconditionally guaranteed
 the full and timely payment of all Credit Agreement related
 obligations of its Asia Pacific operating segment.

- changed (2015-05-05):
[0001193125-15-170026:note_history:41]
As of March 30, 2015 and December 29, 2014, the
 remaining unamortized debt issuance costs included in other
 non-current assets was $924 and $1,123, respectively, and is
 amortized to interest expense over the term of the Company’s
 Credit Agreement using the effective interest rate method. At
 March 30, 2015, the remaining amortization period for the
 unamortized debt issuance costs was 1.3 years.
  (was, 2014-11-10, similarity 0.9626):
[0001193125-14-404493:note_history:41]
As of September 29, 2014 and December 30, 2013, the
 remaining unamortized debt issuance costs included in other
 non-current assets was $1,323 and $1,937, respectively, and is
 amortized to interest expense over the term of the Company’s
 Credit Agreement using the effective interest rate method. At
 September 29, 2014, the remaining amortization period for the
 unamortized debt issuance costs was 1.7 years.

- added (2015-05-05):
[0001193125-15-170026:note_history:42]
The Company is also required to pay a commitment fee of
 0.50% per annum on any unused portion of the Revolving Loan
 and Letters of Credit Facility granted under the Credit Agreement.
 The Company incurred commitment fees related to unused borrowing
 availability of $173 and $133 for the quarters ended March 30,
 2015 and March 31, 2014, respectively. As of March 30,
 2015, the outstanding amount of the Term Loan under the Credit
 Agreement is $225,700, of which $96,200 is due for repayment in
 September 2015 and March 2016 and is included as short-term debt,
 with the remaining $129,500 included as long-term debt. None of the
 Revolving Loan was outstanding under the Credit Agreement as of
 March 30, 2015. Available borrowing capacity under the
 Revolving Loan was $90,000 at March 30, 2015.

- changed (2015-05-05):
[0001193125-15-170026:note_history:43]
Additionally, the Company is party to a revolving loan credit
 facility (Chinese Revolver) with a lender in China. Under this
 arrangement, the lender has made available to the Company
 approximately $37,000 in unsecured borrowing with all terms of the
 borrowing to be negotiated at the time the Chinese Revolver is
 drawn upon. There are no commitment fees on the unused portion of
 the Chinese Revolver, and this arrangement expires in December
 2015. As of March 30, 2015, the Chinese Revolver had not been
 drawn upon.
  (was, 2014-11-10, similarity 0.86):
[0001193125-14-404493:note_history:43]
Additionally, the Company is party to a revolving loan credit
 facility with a lender in the People’s Republic of China
 (China). Under this arrangement, the lender has made available to
 the Company approximately $47,300 in unsecured borrowing with all
 terms of the borrowing to be negotiated at the time the revolver is
 drawn upon. There are no commitment fees on the unused portion of
 the revolver and this arrangement expires in December 2014. As of
 September 29, 2014, the revolver had not been drawn
 upon.

- changed (2015-05-05):
[0001193125-15-170026:note_history:44]
The Company has an $80,000 Letters of Credit Facility under the
 Credit Agreement, as mentioned above. As of March 30, 2015,
 letters of credit in the amount of $30,893 were outstanding under
 this Credit Agreement. The Company has other standby letters of
 credit outstanding in the amount of $4,257, which expire between
 December 31, 2015 and February 28, 2016.
  (was, 2014-11-10, similarity 0.9787):
[0001193125-14-404493:note_history:44]
The Company has an $80,000 Letters of Credit Facility under the
 Credit Agreement, as mentioned above. As of September 29,
 2014, letters of credit in the amount of $43,234 were outstanding
 under this Credit Agreement. The Company has other standby letters
 of credit outstanding in the amount of $3,894, which expire between
 December 31, 2014 and February 28, 2015.

- removed (2015-05-05):
[0001193125-14-404493:note_history:45]
The Company is also required to pay a commitment fee of
 0.50% per annum on any unused portion of the loan and letters
 of credit facility granted under the Credit Agreement. The Company
 incurred commitment fees related to unused borrowing availability
 of $155 and $129 for the quarters ended September 29, 2014 and
 September 30, 2013, respectively, and $439 and $320 for the
 three quarters ended September 29, 2014 and September 30,
 2013, respectively. As of September 29, 2014, the outstanding
 amount of the Term Loan under the Credit Agreement was $273,800, of
 which $96,200 is due for repayment through September 2015 and is
 included as short-term debt, with the remaining $177,600 included
 as long-term debt. None of the Revolving Loan was outstanding under
 the Credit Agreement as of September 29, 2014. Available
 borrowing capacity under the Revolving Loan was $90,000 at
 September 29, 2014.


## us-gaap:ScheduleOfDebtInstrumentsTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2015-05-05):
[0001193125-15-170026:note_history:46]
The following table summarizes the long-term debt of the
 Company as of March 30, 2015 and December 29,
 2014:
  (was, 2014-11-10, similarity 0.95):
[0001193125-14-404493:note_history:46]
The following table summarizes the long-term debt of the
 Company as of September 29, 2014 and December 30,
 2013:

- changed (2015-05-05):
[0001193125-15-170026:note_history:47]
|  |  | Average Effective Interest Rate as of March 30, 2015 |  | March 30, 2015 |  |  | Average Effective Interest Rate as of December 29, 2014 |  | December 29, 2014 |  |
|  |  | (In thousands) |  |
| Term loan due September 2016 |  | 2.56% |  | $ | 225,700 |  |  | 2.55% |  | $ | 273,800 |  |
| Other |  | 6.00% |  |  | 2 |  |  | 6.00% |  |  | 4 |  |
|  |  |  |  |  | 225,702 |  |  |  |  |  | 273,804 |  |
| Less: current maturities |  |  |  |  | (96,202 | ) |  |  |  |  | (96,204 | ) |
| Long-term debt, less current maturities |  |  |  | $ | 129,500 |  |  |  |  | $ | 177,600 |  |
  (was, 2014-11-10, similarity 0.9497):
[0001193125-14-404493:note_history:47]
|  |  | Average Effective Interest Rate as of September 29, 2014 |  | September 29, 2014 |  |  | Average Effective Interest Rate as of December 30, 2013 |  | December 30, 2013 |  |
|  |  | (In thousands) |  |
| Term loan due September 2016 |  | 2.53% |  | $ | 273,800 |  |  | 2.55% |  | $ | 370,000 |  |
| Other |  | 6.00% |  |  | 5 |  |  | 6.00% |  |  | 8 |  |
|  |  |  |  |  | 273,805 |  |  |  |  |  | 370,008 |  |
| Less: current maturities |  |  |  |  | (96,205 | ) |  |  |  |  | (96,204 | ) |
| Long-term debt, less current maturities |  |  |  | $ | 177,600 |  |  |  |  | $ | 273,804 |  |


## us-gaap:ScheduleOfMaturitiesOfLongTermDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2015-05-05):
[0001193125-15-170026:note_history:48]
|  |  | (In thousands) |  |
| Remaining 2015 |  | $ | 48,102 |  |
| 2016 |  |  | 177,600 |  |
|  |  | $ | 225,702 |  |
  (was, 2014-11-10, similarity 0.9367):
[0001193125-14-404493:note_history:48]
|  |  | (In thousands) |  |
| 2015 |  | $ | 96,205 |  |
| 2016 |  |  | 177,600 |  |
|  |  | $ | 273,805 |  |


## us-gaap:RelatedPartyTransactionsDisclosureTextBlock (related_parties) — matched_by: tag_name, score: 1.0

- changed (2015-05-05):
[0001193125-15-170026:note_history:49]
In the
 normal course of business, the Company’s foreign subsidiaries
 purchase laminate and prepreg from related parties in which a
 significant shareholder of the Company holds an equity interest.
 For the quarters ended March 30, 2015 and March 31, 2014,
 the Company’s foreign subsidiaries purchased $9,945 and
 $11,790, respectively, of laminate and prepreg from these related
 parties.
  (was, 2014-11-10, similarity 0.6002):
[0001193125-14-404493:note_history:49]
In the
 normal course of business, the Company’s foreign subsidiaries
 purchase laminate and prepreg from related parties in which a
 significant shareholder of the Company holds an equity interest.
 The Company purchased laminate and prepreg from these related
 parties in the amount of $11,469 and $13,740 for the quarters ended
 September 29, 2014 and September 30, 2013, respectively,
 and $36,647 and $51,349 for the three quarters ended
 September 29, 2014 and September 30, 2013,
 respectively.

- added (2015-05-05):
[0001193125-15-170026:note_history:50]
Dongguan Shengyi Electronics Ltd. (SYE) is a related party, as
 a significant shareholder of the Company holds an equity interest
 in the parent company of SYE. Sales to SYE for the quarters ended
 March 30, 2015 and March 31, 2014 were $1,481 and
 $10,147, respectively. Additionally, purchases from SYE for the
 quarters ended March 30, 2015 and March 31, 2014 were
 approximately $439 and $271, respectively.

- added (2015-05-05):
[0001193125-15-170026:note_history:51]
As of
 March 30, 2015 and December 29, 2014, the Company’s
 consolidated balance sheets included $16,852 and $17,950,
 respectively, in accounts payable due to, and $4,022 and $4,934,
 respectively, in accounts receivable due from a related party for
 the purchase of laminate and prepreg, and sales of PCBs to SYE, as
 mentioned above.

- removed (2015-05-05):
[0001193125-14-404493:note_history:52]
Dongguan Shengyi Electronics Ltd., (SYE) is a related party as
 a significant shareholder of the Company holds an equity interest
 in the parent company of SYE. Sales to SYE for the quarters ended
 September 29, 2014 and September 30, 2013 were $2,282 and
 $14,351, respectively, and $21,535 and $18,361 for the three
 quarters ended September 29, 2014 and September 30, 2013,
 respectively. Additionally, purchases from SYE for the quarter and
 three quarters ended September 29, 2014 were approximately $78
 and $550, respectively. There were no purchases from SYE for the
 quarter or three quarters ended September 30, 2013.

- removed (2015-05-05):
[0001193125-14-404493:note_history:53]
As of
 September 29, 2014 and December 30, 2013, the
 Company’s consolidated condensed balance sheet included
 $19,884 and $19,547, respectively, in accounts payable due to, and
 $8,924 and $13,312, respectively, in accounts receivable due from
 related parties for the purchase of laminate and prepreg, and sales
 of PCBs to SYE, as mentioned above.
