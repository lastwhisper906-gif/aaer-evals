# TTMI 8-K — 0001171843-15-002307 filed 2015-04-29

## item codes, every 8-K on or before 2015-05-05

- 2015-05-05 0001171843-15-002499 — 7.01, 9.01
- 2015-04-29 0001171843-15-002307 — 2.02, 9.01
- 2015-04-21 0001193125-15-139239 — 7.01, 9.01
- 2015-04-21 0001171843-15-002065 — 2.02, 9.01
- 2015-02-04 0001171843-15-000599 — 2.02, 9.01
- 2015-01-20 0001193125-15-014019 — 7.01, 9.01
- 2014-12-30 0001193125-14-457111 — 7.01, 9.01
- 2014-12-15 0001193125-14-442645 — 1.01, 9.01
- 2014-12-04 0001193125-14-433658 — 8.01, 9.01
- 2014-11-18 0001193125-14-415889 — 7.01, 9.01
- 2014-10-29 0001171843-14-005051 — 2.02, 9.01
- 2014-10-27 0001193125-14-383428 — 1.01, 9.01
- 2014-09-22 0001193125-14-348697 — 1.01, 7.01, 9.01
- 2014-08-05 0001193125-14-295808 — 1.01, 5.02, 9.01
- 2014-07-30 0001171843-14-003548 — 2.02, 9.01
- 2014-04-30 0001171843-14-002017 — 2.02, 9.01
- 2014-04-25 0001193125-14-160146 — 5.02, 5.07, 9.01
- 2014-04-10 0001171843-14-001656 — 2.02, 9.01
- 2014-03-04 0001193125-14-082534 — 4.01, 9.01
- 2014-02-05 0001171843-14-000553 — 2.02, 9.01
- 2014-01-14 0001193125-14-010922 — 1.01, 2.03, 3.02, 8.01, 9.01
- 2013-12-27 0001193125-13-486144 — 5.02, 9.01
- 2013-12-20 0001193125-13-481141 — 1.01, 1.02, 2.03, 3.02, 8.01, 9.01
- 2013-12-17 0001193125-13-476207 — 5.03
- 2013-10-30 0001193125-13-418572 — 2.02, 5.02, 9.01
- 2013-09-12 0001193125-13-365420 — 2.05
- 2013-08-14 0001193125-13-334349 — 7.01, 9.01
- 2013-08-01 0001171843-13-003138 — 2.02, 9.01
- 2013-06-25 0001193125-13-270725 — 5.02, 9.01
- 2013-05-02 0001171843-13-001746 — 2.02, 9.01
- 2013-04-29 0001193125-13-182083 — 5.02, 5.07, 9.01
- 2013-03-18 0001193125-13-111308 — 1.01, 7.01, 9.01
- 2013-03-06 0001193125-13-093625 — 5.02, 9.01
- 2013-03-01 0001193125-13-087439 — 2.02 — amendment of 0001171843-13-000414
- 2013-02-28 0001193125-13-084764 — 5.02
- 2013-02-05 0001171843-13-000414 — 2.02, 9.01
- 2013-01-31 0001193125-13-032848 — 5.02, 9.01
- 2013-01-17 0001193125-13-015928 — 7.01, 9.01
- 2013-01-16 0001193125-13-014581 — 2.02, 9.01
- 2012-12-11 0001193125-12-498644 — 5.02, 9.01
- 2012-11-15 0001193125-12-472451 — 7.01, 9.01
- 2012-11-01 0001171843-12-003890 — 2.02, 9.01
- 2012-09-19 0001193125-12-396969 — 1.01, 2.03, 7.01, 9.01
- 2012-09-11 0001193125-12-388130 — 7.01, 9.01
- 2012-07-31 0001171843-12-002829 — 2.02, 9.01
- 2012-05-15 0001193125-12-233501 — 7.01, 9.01
- 2012-05-01 0001171843-12-001574 — 2.02, 9.01
- 2012-04-27 0001193125-12-191623 — 5.07
- 2012-03-01 0001193125-12-090623 — 2.02 — amendment of 0001171843-12-000382
- 2012-02-07 0001171843-12-000382 — 2.02, 9.01
- 2012-01-19 0001193125-12-016588 — 5.02, 9.01
- 2011-11-15 0000950123-11-098812 — 7.01, 9.01
- 2011-11-02 0001171843-11-003248 — 2.02, 9.01
- 2011-09-28 0000950123-11-087344 — 7.01, 9.01
- 2011-09-19 0000950123-11-085128 — 5.02, 9.01
- 2011-09-15 0000950123-11-084704 — 5.07 — amendment of 0000950123-11-054296
- 2011-08-04 0001171843-11-002356 — 2.02, 9.01
- 2011-07-27 0000950123-11-068987 — 1.01, 2.03, 9.01
- 2011-06-21 0000950123-11-060477 — 7.01, 9.01
- 2011-06-06 0000950123-11-056971 — 5.03, 9.01
- 2011-05-26 0000950123-11-054296 — 5.07
- 2011-05-10 0000950123-11-048462 — 8.01, 9.01
- 2011-05-05 0001171843-11-001344 — 2.02, 9.01
- 2011-03-22 0000950123-11-027824 — 7.01, 9.01
- 2011-03-18 0000950123-11-026913 — 4.01
- 2011-03-18 0000950123-11-026910 — 4.01, 9.01 — amendment, the index does not say of what
- 2011-03-02 0000950123-11-020941 — 5.03, 9.01
- 2011-02-10 0001171843-11-000391 — 2.02, 9.01
- 2011-01-13 0000950123-11-002528 — 7.01, 9.01
- 2011-01-13 0000950123-11-002446 — 2.02, 9.01
- 2010-11-29 0000950123-10-109448 — 4.01, 9.01 — amendment, the index does not say of what
- 2010-11-17 0000950123-10-106706 — 4.01
- 2010-11-15 0000950123-10-105479 — 5.02, 9.01
- 2010-11-04 0001171843-10-002324 — 2.02, 9.01
- 2010-10-22 0000950123-10-095179 — 1.01, 9.01
- 2010-10-04 0000950123-10-090949 — 1.01, 5.03, 9.01
- 2010-08-05 0001171843-10-001587 — 2.02, 9.01
- 2010-08-05 0000950123-10-073258 — 1.01, 2.03, 9.01
- 2010-08-05 0000950123-10-073256 — 9.01 — amendment of 0000950123-10-034163
- 2010-07-12 0000950123-10-064794 — 5.02, 8.01, 9.01
- 2010-06-10 0000950123-10-057166 — 7.01, 9.01
- 2010-06-02 0000950123-10-055111 — 1.01, 5.07, 9.01
- 2010-05-06 0001171843-10-000819 — 2.02, 9.01
- 2010-04-26 0000950123-10-037806 — 8.01, 9.01 — amendment of 0000950123-10-034163
- 2010-04-13 0000950123-10-034163 — 1.01, 2.01, 2.03, 5.02, 7.01, 9.01
- 2010-03-30 0000950123-10-030123 — 1.01, 5.02, 9.01
- 2010-03-24 0000950123-10-027317 — 1.01, 5.02, 9.01
- 2010-03-16 0000950123-10-024853 — 7.01, 9.01 — amendment of 0001171843-10-000140
- 2010-03-15 0000950123-10-024637 — 5.07
- 2010-02-04 0001171843-10-000140 — 2.02, 9.01
- 2010-02-02 0000950123-10-007780 — 8.01, 9.01
- 2010-01-13 0000950123-10-002245 — 7.01, 9.01
- 2009-12-23 0000950123-09-073069 — 1.01, 9.01
- 2009-12-15 0000950123-09-070868 — 8.01, 9.01
- 2009-11-16 0000950123-09-062630 — 1.01, 7.01, 9.01
- 2009-11-04 0001171843-09-001103 — 2.02, 9.01
- 2009-09-04 0000950123-09-041133 — 2.05, 9.01
- 2009-07-29 0001171843-09-000743 — 2.02, 9.01
- 2009-06-09 0000950123-09-012507 — 7.01, 9.01
- 2009-04-30 0001171843-09-000427 — 2.02, 9.01
- 2009-04-28 0001362310-09-005960 — 8.01
- 2009-02-19 0001362310-09-002454 — 5.03, 9.01
- 2009-02-10 0001171843-09-000123 — 2.02, 9.01
- 2009-01-16 0000950153-09-000040 — 2.05, 9.01
- 2009-01-08 0000950153-09-000023 — 7.01, 9.01
- 2008-10-29 0001157523-08-008533 — 2.02, 9.01
- 2008-07-29 0001157523-08-005998 — 2.02, 9.01
- 2008-05-22 0000950153-08-001035 — 1.01, 2.03, 3.02, 9.01
- 2008-05-22 0000950153-08-001034 — 7.01, 9.01
- 2008-05-15 0000950153-08-000987 — 1.01, 1.02, 2.03, 3.02, 9.01
- 2008-04-30 0001157523-08-003483 — 2.02, 9.01
- 2008-02-07 0001157523-08-001077 — 2.02, 9.01
- 2008-01-08 0000950153-08-000033 — 7.01, 9.01
- 2007-11-15 0000950153-07-002440 — 7.01, 9.01
- 2007-11-14 0000950153-07-002426 — 7.01, 9.01
- 2007-11-14 0000950153-07-002421 — 5.03, 9.01
- 2007-10-31 0001157523-07-010491 — 2.02, 9.01
- 2007-10-02 0000950153-07-002094 — 7.01, 9.01
- 2007-07-31 0000950153-07-001622 — 2.02, 9.01
- 2007-06-13 0000950153-07-001327 — 7.01, 9.01
- 2007-05-02 0000950153-07-000941 — 2.02, 9.01
- 2007-04-12 0000950153-07-000763 — 5.02, 9.01
- 2007-02-15 0000950153-07-000339 — 2.02, 9.01
- 2007-01-11 0000950153-07-000076 — 7.01, 9.01
- 2007-01-10 0000950153-07-000071 — 2.01, 9.01 — amendment, the index does not say of what
- 2006-12-11 0000950153-06-002967 — 2.05, 9.01
- 2006-11-15 0000950153-06-002843 — 7.01, 9.01
- 2006-11-14 0000950153-06-002837 — 7.01, 9.01
- 2006-11-02 0000950153-06-002682 — 1.01, 1.02, 2.03, 9.01
- 2006-11-01 0000950153-06-002668 — 2.02, 9.01
- 2006-10-30 0000950124-06-006210 — 2.01, 9.01
- 2006-08-04 0000950153-06-002025 — 1.01, 9.01
- 2006-07-26 0000950153-06-001937 — 2.02, 9.01
- 2006-06-28 0000950153-06-001716 — 1.01, 9.01
- 2006-06-13 0000950153-06-001597 — 7.01, 9.01
- 2006-04-26 0000950153-06-001079 — 2.02, 9.01
- 2006-02-08 0001104659-06-006985 — 2.02, 9.01
- 2006-01-12 0001104659-06-001893 — 7.01, 9.01
- 2005-12-05 0001104659-05-058918 — 1.01, 5.02, 9.01
- 2005-10-26 0001104659-05-050306 — 2.02, 9.01
- 2005-09-20 0001104659-05-044954 — 8.01
- 2005-08-30 0001104659-05-042053 — 3.03, 8.01, 9.01
- 2005-07-27 0001104659-05-034437 — 2.02, 5.02, 9.01
- 2005-07-21 0001104659-05-033462 — 1.01, 1.02, 2.03, 9.01
- 2005-06-13 0001104659-05-027969 — 8.01
- 2005-06-08 0001104659-05-027364 — 7.01, 9.01
- 2005-05-17 0001104659-05-024118 — 7.01, 9.01
- 2005-05-12 0001104659-05-022993 — 7.01, 9.01
- 2005-05-11 0001104659-05-022606 — 1.01, 9.01
- 2005-05-02 0001104659-05-019649 — 2.02, 5.02, 9.01
- 2005-04-26 0001104659-05-018233 — 7.01, 9.01
- 2005-02-08 0001104659-05-004642 — 2.02, 9.01
- 2005-01-12 0001104659-05-001194 — 7.01, 9.01
- 2004-12-22 0001104659-04-040933 — 5.02
- 2004-12-08 0001104659-04-038850 — 7.01, 9.01
- 2004-10-26 0001104659-04-031931 — 2.02, 9.01
- 2004-10-01 0001104659-04-029361 — 5.02
- 2004-08-02 0001104659-04-021785 — 9
- 2004-07-29 0001104659-04-021529 — 12
- 2004-05-06 0001104659-04-012742 — 9
- 2004-04-26 0001104659-04-011228 — 12
- 2004-02-03 0001104659-04-002424 — 9
- 2004-01-28 0001104659-04-001980 — 12
- 2004-01-09 0001104659-04-000457 — 9
- 2003-10-21 0001104659-03-023304 — 12
- 2003-07-29 0001104659-03-015999 — 12
- 2003-05-08 0001104659-03-008647 — 9
- 2003-05-08 0001104659-03-008462 — 9
- 2003-05-01 0001104659-03-007866 — 9
- 2003-03-07 0001104659-03-003816 — 2, 7 — amendment of 0000950153-02-002190
- 2002-12-27 0000950153-02-002190 — 2, 7
- 2002-05-17 0000912057-02-021145 — 4, 7
- 2001-12-21 0000912057-01-544281 — 7
- 2000-10-27 0000912057-00-046109 — 5

## late-filing notifications on or before 2015-05-05

- none on or before 2015-05-05

## item 2.02 — earnings release, exhibit 99.1

[0001171843-15-002307:8k_2_02:1]
EX-99
2
newsrelease.htm
PRESS RELEASE

[0001171843-15-002307:8k_2_02:2]
TTM Technologies, Inc. Reports First Quarter 2015 Results
EXHIBIT 99.1

[0001171843-15-002307:8k_2_02:3]
TTM Technologies, Inc. Reports First Quarter 2015 Results

[0001171843-15-002307:8k_2_02:4]
COSTA MESA, Calif., April 29, 2015 (GLOBE NEWSWIRE) -- TTM Technologies, Inc. (Nasdaq:TTMI), a major global printed circuit board ("PCB") manufacturer, today reported results for the first quarter 2015, which ended March 30, 2015.

[0001171843-15-002307:8k_2_02:5]
First Quarter 2015 Highlights

[0001171843-15-002307:8k_2_02:6]
Net sales were $329.2 million

[0001171843-15-002307:8k_2_02:7]
GAAP net income was $3.4 million, or $0.04 per diluted share

[0001171843-15-002307:8k_2_02:8]
Non-GAAP net income was $10.8 million, or $0.13 per diluted share

[0001171843-15-002307:8k_2_02:9]
First Quarter 2015 Financial Results

[0001171843-15-002307:8k_2_02:10]
Net sales for the first quarter of 2015 were $329.2 million compared to $390.9 million in the fourth quarter of 2014 and $291.9 million in the first quarter of 2014.

[0001171843-15-002307:8k_2_02:11]
GAAP operating income for the first quarter of 2015 was $8.3 million compared to GAAP operating income of $26.6 million in the fourth quarter of 2014 and $4.5 million in the first quarter of 2014.

[0001171843-15-002307:8k_2_02:12]
GAAP net income for the first quarter of 2015 was $3.4 million, or $0.04 per diluted share. This compares to GAAP net income of $13.9 million, or $0.17 per diluted share, in the fourth quarter of 2014 and a net loss of $3.8 million, or $0.05 per share, in the first quarter of 2014.

[0001171843-15-002307:8k_2_02:13]
On a non-GAAP basis, net income for the first quarter of 2015 was $10.8 million, or $0.13 per diluted share. This compares to non-GAAP net income of $23.2 million, or $0.28 per diluted share, for the fourth quarter of 2014 and $1.2 million, or $0.01 per diluted share, for the first quarter of 2014.

[0001171843-15-002307:8k_2_02:14]
Adjusted EBITDA for the first quarter of 2015 was $42.5 million, or 12.9 percent of net sales, compared to adjusted EBITDA of $60.5 million, or 15.5 percent of net sales, for the fourth quarter of 2014 and $29.1 million, or 10.0 percent of net sales, for the first quarter of 2014.

[0001171843-15-002307:8k_2_02:15]
"We are pleased to report strong operating results in the first quarter, with revenue at the high end and non-GAAP earnings above our initial guidance ranges," said Tom Edman, CEO of TTM. "We are encouraged by the year-over-year improvement in revenue driven by strong cellular phone demand as well as the ongoing bookings strength in the aerospace and defense market."

[0001171843-15-002307:8k_2_02:16]
Mr. Edman continued, "While our acquisition of Viasystems is still subject to U.S. regulatory approvals, we expect to complete the acquisition during the second quarter of 2015.  Viasystems will bring TTM meaningful strength in the automotive end market and will complement our position in other end markets, enabling us to continue to broaden our product portfolio to address an increasingly diverse set of end markets."

[0001171843-15-002307:8k_2_02:17]
Business Outlook

[0001171843-15-002307:8k_2_02:18]
For the second quarter of 2015, TTM estimates that revenue will be in the range of $330 million to $350 million, and non-GAAP net income will be in the range of $0.11 to $0.17 per diluted share.

[0001171843-15-002307:8k_2_02:19]
The Acquisition of Viasystems Group, Inc.

[0001171843-15-002307:8k_2_02:20]
As previously announced, TTM entered into a definitive agreement under which TTM will acquire all outstanding shares of Viasystems for a combined consideration of $11.33 in cash and 0.706 shares of TTM common stock per Viasystems' share of common stock. The parties currently expect to close the transaction in the second quarter of 2015. The transaction is subject to customary closing conditions, including United States regulatory approvals.

[0001171843-15-002307:8k_2_02:21]
To Access the Live Webcast/Conference Call

[0001171843-15-002307:8k_2_02:22]
TTM will host a conference call and webcast to discuss first quarter 2015 results and second quarter 2015 outlook on Wednesday, April 29, 2015, at 4:30 p.m. Eastern Time (1:30 p.m. Pacific Time). The conference call may include forward-looking statements.

[0001171843-15-002307:8k_2_02:23]
Telephone access is available by dialing domestic 1-888-539-3678 or international 1-719-325-2420 (ID 2158367). The conference call also will be webcast on TTM's website at www.ttmtech.com.

[0001171843-15-002307:8k_2_02:24]
To Access a Replay of the Webcast

[0001171843-15-002307:8k_2_02:25]
The replay of the webcast will remain accessible for one week following the live event on TTM's website at www.ttmtech.com.

[0001171843-15-002307:8k_2_02:26]
About TTM

[0001171843-15-002307:8k_2_02:27]
TTM Technologies, Inc. is a major global printed circuit board manufacturer, focusing on quick-turn and technologically advanced PCBs and the backplane and sub-system assembly business. TTM stands for time-to-market, representing how TTM's time-critical, one-stop manufacturing services enable customers to shorten the time required to develop new products and bring them to market. Additional information can be found at www.ttmtech.com.

[0001171843-15-002307:8k_2_02:28]
Forward-Looking Statements

[0001171843-15-002307:8k_2_02:29]
This release contains forward-looking statements that relate to future events or performance. TTM cautions you that such statements are simply predictions and actual events or results may differ materially. These statements reflect TTM's current expectations, and TTM does not undertake to update or revise these forward looking statements, even if experience or future changes make it clear that any projected results expressed or implied in this or other TTM statements will not be realized. Further, these statements involve risks and uncertainties, many of which are beyond TTM's control, which could cause actual results to differ materially from the forward-looking statements. These risks and uncertainties include, but are not limited to, the timing and consummation of the proposed acquisition, the ability of the parties to consummate the proposed acquisition and the satisfaction of the conditions precedent to consummation of the proposed acquisition, including the ability to secure regulatory approvals in a timely manner or at all, general market and economic conditions, including interest rates, currency exchange rates and consumer spending, demand for TTM's products, market pressures on prices of TTM's products, warranty claims, changes in product mix, contemplated significant capital expenditures and related financing requirements, TTM's dependence upon a small number of customers and other "Risk Factors" set forth in TTM's most recent SEC filings.

[0001171843-15-002307:8k_2_02:30]
About Our Non-GAAP Financial Measures

[0001171843-15-002307:8k_2_02:31]
This release includes information about TTM's adjusted EBITDA, non-GAAP net income and non-GAAP earnings per share, all of which are non-GAAP financial measures. TTM presents non-GAAP financial information to enable investors to see TTM through the eyes of management and to provide better insight into TTM's ongoing financial performance.

[0001171843-15-002307:8k_2_02:32]
Adjusted EBITDA is defined as earnings before interest expense, income taxes, depreciation, amortization of intangibles, stock-based compensation expense, gain on sale of assets, asset impairments, restructuring, costs related to acquisitions, and other charges.  Management believes that the non-GAAP financial information – which adds back amortization of intangibles, stock-based compensation expense, non-cash interest expense on debt, acquisition-related costs, asset impairments, restructuring and other unusual or infrequent items as well as the associated tax impact of these charges and discrete tax items – provides additional useful information to investors regarding TTM's ongoing financial condition and results of operations.

[0001171843-15-002307:8k_2_02:33]
A material limitation associated with the use of the above non-GAAP financial measures is that they have no standardized measurement prescribed by GAAP and may not be comparable to similar non-GAAP financial measures used by other companies.  TTM compensates for these limitations by providing full disclosure of each non-GAAP financial measure and reconciliation to the most directly comparable GAAP financial measure.  However, the non-GAAP financial measures should not be considered in isolation from, or as a substitute for, financial information prepared in accordance with GAAP.

[0001171843-15-002307:8k_2_02:34]
| TTM TECHNOLOGIES, INC. |
| Selected Unaudited Financial Information |
| (In thousands, except per share data) |
|  | First Quarter | Fourth Quarter |
|  | 2015 | 2014 | 2014 |
| CONSOLIDATED CONDENSED STATEMENTS OF OPERATIONS |  |  |  |
| Net sales | $ 329,164 | $ 291,895 | $ 390,912 |
| Cost of goods sold | 277,605 | 253,389 | 322,437 |
| Gross profit | 51,559 | 38,506 | 68,475 |
| Operating expenses: |  |  |  |
| Selling and marketing | 9,455 | 9,323 | 9,926 |
| General and administrative | 33,990 | 22,518 | 30,046 |
| Amortization of definite-lived intangibles | 1,874 | 2,236 | 1,935 |
| Restructuring charges | 479 | (24) | (7) |
| Gain on sale of assets | (2,504) | -- | -- |
| Total operating expenses | 43,294 | 34,053 | 41,900 |
| Operating income | 8,265 | 4,453 | 26,575 |
| Interest expense | (5,765) | (6,206) | (5,691) |
| Loss on extinguishment of debt | -- | (506) | -- |
| Other, net | (415) | (3,395) | 1,620 |
| Income (loss) before income taxes | 2,085 | (5,654) | 22,504 |
| Income tax benefit (provision) | 1,361 | 1,855 | (8,566) |
| Net income (loss) | $ 3,446 | $ (3,799) | $ 13,938 |
| Earnings per share: |  |  |  |
| Basic | $ 0.04 | $ (0.05) | $ 0.17 |
| Diluted | $ 0.04 | $ (0.05) | $ 0.17 |
| Weighted-average shares used in computing per share amounts: |  |  |  |
| Basic | 83,603 | 82,925 | 83,345 |
| Diluted | 84,465 | 82,925 | 84,205 |
| SELECTED BALANCE SHEET DATA |  |  |  |
|  | March 30, 2015 | December 29, 2014 |  |
| Cash and cash equivalents | $ 282,968 | $ 279,042 |  |
| Accounts and notes receivable, net | 239,645 | 307,933 |  |
| Inventories | 153,920 | 145,187 |  |
| Total current assets | 730,453 | 798,123 |  |
| Property, plant and equipment, net | 746,649 | 754,718 |  |
| Other non-current assets | 44,772 | 48,448 |  |
| Total assets | 1,521,874 | 1,601,289 |  |
| Short-term debt, including current portion long-term debt | $ 128,410 | $ 128,045 |  |
| Accounts payable | 194,186 | 217,326 |  |
| Total current liabilities | 456,608 | 496,012 |  |
| Debt, net of discount | 328,380 | 374,642 |  |
| Total long-term liabilities | 345,071 | 389,813 |  |
| Total stockholders' equity | 720,195 | 715,464 |  |
| Total liabilities and stockholders' equity | 1,521,874 | 1,601,289 |  |
| SUPPLEMENTAL DATA |  |  |  |
|  | First Quarter | Fourth Quarter |
|  | 2015 | 2014 | 2014 |
| Gross margin | 15.7% | 13.2% | 17.5% |
| Operating margin | 2.5% | 1.5% | 6.8% |
| End Market Breakdown: |  |  |  |
|  | First Quarter | Fourth Quarter |
|  | 2015 | 2014 | 2014 |
| Aerospace/Defense | 15% | 17% | 14% |
| Cellular Phone | 30% | 15% | 35% |
| Computing/Storage/Peripherals | 11% | 18% | 10% |
| Medical/Industrial/Instrumentation | 9% | 10% | 8% |
| Networking/Communications | 29% | 34% | 27% |
| Other | 6% | 6% | 6% |
| Stock-based Compensation: |  |  |  |
|  | First Quarter | Fourth Quarter |
|  | 2015 | 2014 | 2014 |
| Amount included in: |  |  |  |
| Cost of goods sold | $ 225 | $ 263 | $ 197 |
| Selling and marketing | 271 | 335 | 263 |
| General and administrative | 1,544 | 1,570 | 1,287 |
| Total stock-based compensation expense | $ 2,040 | $ 2,168 | $ 1,747 |
| Operating Segment Data: |  |  |  |
|  | First Quarter | Fourth Quarter |
| Net sales: | 2015 | 2014 | 2014 |
| Asia Pacific | $ 205,365 | $ 165,666 | $ 264,015 |
| North America | 124,321 | 126,589 | 127,433 |
| Total sales | 329,686 | 292,255 | 391,448 |
| Inter-segment sales | (522) | (360) | (536) |
| Total net sales | $ 329,164 | $ 291,895 | $ 390,912 |
| Operating segment income: |  |  |  |
| Asia Pacific | $ 14,441 | $ 3,867 | $ 27,263 |
| North America | (4,302) | 2,822 | 1,247 |
| Total operating segment income | 10,139 | 6,689 | 28,510 |
| Amortization of definite-lived intangibles | (1,874) | (2,236) | (1,935) |
| Total operating income | 8,265 | 4,453 | 26,575 |
| Total other expense | (6,180) | (10,107) | (4,071) |
| Income before income taxes | $ 2,085 | $ (5,654) | $ 22,504 |
| RECONCILIATIONS1 |  |  |  |
|  | First Quarter | Fourth Quarter |
|  | 2015 | 2014 | 2014 |
| Non-GAAP gross profit reconciliation2: |  |  |  |
| GAAP gross profit | $ 51,559 | $ 38,506 | $ 68,475 |
| Add back item: |  |  |  |
| Stock-based compensation | 225 | 263 | 197 |
| Non-GAAP gross profit | $ 51,784 | $ 38,769 | $ 68,672 |
| Non-GAAP gross margin | 15.7% | 13.3% | 17.6% |
| Non-GAAP operating income reconciliation3: |  |  |  |
| GAAP operating income | $ 8,265 | $ 4,453 | $ 26,575 |
| Add back items: |  |  |  |
| Amortization of definite-lived intangibles | 1,874 | 2,236 | 1,935 |
| Stock-based compensation | 2,040 | 2,168 | 1,747 |
| Gain on sale of assets | (2,504) | -- | -- |
| Acquisition-related costs | 8,235 | -- | 4,349 |
| Impairments and restructuring charges | 479 | (24) | (7) |
| Non-GAAP operating income | $ 18,389 | $ 8,833 | $ 34,599 |
| Non-GAAP operating margin | 5.6% | 3.0% | 8.9% |
| Non-GAAP net income and EPS4: |  |  |  |
| GAAP net income | $ 3,446 | $ (3,799) | $ 13,938 |
| Add back items: |  |  |  |
| Amortization of definite-lived intangibles | 1,874 | 2,236 | 1,935 |
| Stock-based compensation | 2,040 | 2,168 | 1,747 |
| Non-cash interest expense | 2,625 | 2,523 | 2,585 |
| Gain on sale of assets | (2,504) | -- | -- |
| Acquisition-related costs | 8,235 | -- | 4,349 |
| Impairments, restructuring and other charges | 479 | 482 | (7) |
| Income taxes | (5,366) | (2,393) | (1,332) |
| Non-GAAP net income | $ 10,829 | $ 1,217 | $ 23,215 |
| Non-GAAP earnings per diluted share | $ 0.13 | $ 0.01 | $ 0.28 |
| Adjusted EBITDA reconciliation5: |  |  |  |
| GAAP net income | $ 3,446 | $ (3,799) | $ 13,938 |
| Add back items: |  |  |  |
| Income tax provision | (1,361) | (1,855) | 8,566 |
| Interest expense | 5,765 | 6,206 | 5,691 |
| Amortization of definite-lived intangibles | 1,874 | 2,236 | 1,935 |
| Depreciation expense | 24,536 | 23,707 | 24,318 |
| Stock-based compensation | 2,040 | 2,168 | 1,747 |
| Gain on sale of assets | (2,504) | -- | -- |
| Acquisition-related costs | 8,235 | -- | 4,349 |
| Impairments, restructuring and other charges | 479 | 482 | (7) |
| Adjusted EBITDA | $ 42,510 | $ 29,145 | $ 60,537 |
| Adjusted EBITDA margin | 12.9% | 10.0% | 15.5% |
| 1 This information provides a reconciliation of non-GAAP gross profit, non-GAAP operating income, non-GAAP net income, non-GAAP EPS, and adjusted EBITDA to the financial information in our consolidated condensed statements of operations. |
| 2 Non-GAAP gross profit and gross margin measures exclude stock-based compensation expense. |
| 3 Non-GAAP operating income and operating margin measures exclude amortization of intangibles, stock-based compensation expense, gain on sale of assets, acquisition-related costs and restructuring and impairment charges. |
| 4 This information provides non-GAAP net income and non-GAAP EPS, which are non-GAAP financial measures. Management believes that both measures --- which add back amortization of intangibles, stock-based compensation expense, non-cash interest expense on debt (before consideration of capitalized interest), gain on sale of assets, acquisition-related costs, asset impairments, restructuring and other charges as well as the associated tax impact of these charges and discrete tax items --- provide additional useful information to investors regarding the Company's ongoing financial condition and results of operations. |
| 5 Adjusted EBITDA is defined as earnings before interest expense, income taxes, depreciation, amortization of intangibles, stock-based compensation expense, gain on sale of assets, acquisition-related costs, asset impairments, restructuring and other charges. We present adjusted EBITDA to enhance the understanding of our operating results, and it is a key measure we use to evaluate our operations. In addition, we provide our adjusted EBITDA because we believe that investors and securities analysts will find adjusted EBITDA to be a useful measure for evaluating our operating performance and comparing our operating performance with that of similar companies that have different capital structures and for evaluating our ability to meet our future debt service, capital expenditures, and working capital requirements. However, adjusted EBITDA should not be considered as an alternative to cash flows from operating activities as a measure of liquidity or as an alternative to net income as a measure of operating results in accordance with accounting principles generally accepted in the United States of America. |

[0001171843-15-002307:8k_2_02:35]
CONTACT: Todd Schull, CFO
         714-327-3000
