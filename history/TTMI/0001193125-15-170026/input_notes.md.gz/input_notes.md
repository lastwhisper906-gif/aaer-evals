# TTMI notes — 0001193125-15-170026


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001193125-15-170026:notes:1]
(12) Commitments and
 Contingencies

[0001193125-15-170026:notes:2]
Legal
 Matters

[0001193125-15-170026:notes:3]
The Company is subject to various legal matters, which it
 considers normal for its business activities. While the Company
 currently believes that the amount of any reasonably possible or
 probable loss for known matters would not be material to the
 Company’s financial condition, the outcome of these actions
 is inherently difficult to predict. In the event of an adverse
 outcome, the ultimate potential loss could have a material adverse
 effect on the Company’s financial condition or results of
 operations in a particular period. The Company has accrued amounts
 for its loss contingencies which are probable and estimable as of
 March 30, 2015 and December 29, 2014. However, these
 amounts are not material to the consolidated financial statements
 of the Company.

[0001193125-15-170026:notes:4]
Class Action Complaints
 related to Viasystems Acquisition

[0001193125-15-170026:notes:5]
Since the public announcement on September 22, 2014 of the
 execution of the Merger Agreement, Viasystems, TTM, Merger Sub, and
 the members of the Viasystems Board have been named as defendants
 in two putative class action complaints challenging the Merger. The
 first lawsuit, filed in the Circuit Court of St. Louis County,
 Missouri on September 30, 2014 (the Missouri Lawsuit), and the
 second lawsuit, filed in the Court of Chancery of the State of
 Delaware on October 13, 2014 (the Delaware Lawsuit and,
 together with the Missouri Lawsuit, the Lawsuits), generally allege
 that the Merger fails to properly value Viasystems, that the
 individual defendants breached their fiduciary duties in approving
 the Merger Agreement, and that those breaches were aided and
 abetted by TTM, Merger Sub, and Viasystems.

[0001193125-15-170026:notes:6]
The Delaware Lawsuit specifically alleges, among other
 allegations, that (1) the Viasystems Board breached its
 fiduciary duties by: (a) agreeing to the Merger for grossly
 inadequate consideration, (b) agreeing to lock up the Merger
 with deal protection devices that prevent other bidders from making
 a successful competing offer for Viasystems, and
 (c) participating in a transaction where the loyalties of the
 Viasystems Board and management are divided; (2) the voting
 agreements entered into between the Company and certain of
 Viasystems’ significant stockholders prevent Viasystems
 stockholders from providing a meaningful vote on the proposal to
 adopt the Merger; and (3) that those breaches of fiduciary
 duties were aided and abetted by TTM, Merger Sub, and Viasystems.
 Further, the Missouri Lawsuit specifically alleges, among other
 allegations, that (1) the proposed Merger is unfair and the
 consideration to be paid in connection with the Merger is
 inadequate; (2) the Viasystems Board and Viasystems’
 management have a conflict of interest due to the cash pool bonus
 and change in control payments to be made to certain executive
 officers and key employees if the Merger is consummated; and
 (3) the Merger Agreement contains impermissible deal
 protection devices.

[0001193125-15-170026:notes:7]
The Lawsuits seek injunctive relief to enjoin the defendants
 from completing the Merger on the agreed-upon terms, rescinding, to
 the extent already implemented, the Merger Agreement or any of the
 terms therein, costs and disbursements and attorneys’ and
 experts’ fees and costs, as well as other equitable relief as
 the respective court deems proper. The Delaware Lawsuit also seeks:
 (1) in the event the Merger is consummated prior to the entry
 of the court’s final judgment, rescissory damages as an
 alternative to rescission, and (2) an accounting by all
 defendants to the plaintiff and other members of the class for all
 damages caused by the defendants and for all profits and any
 special benefits obtained as a result of their alleged breaches of
 their fiduciary duties.

[0001193125-15-170026:notes:8]
On January 6, 2015, the parties to the Missouri Lawsuit
 entered into a Memorandum of Understanding (MOU) with respect to a
 proposed settlement that will terminate both Lawsuits upon entry of
 the final judgment. The parties are in the process of
 negotiating this settlement agreement. Pursuant to the MOU,
 the settlement agreement will provide for payment of
 attorneys’ fees and reimbursement of expenses, and releases
 of all claims and relief sought in both Lawsuits.

[0001193125-15-170026:notes:9]
Environmental
 Matters

[0001193125-15-170026:notes:10]
The process to manufacture PCBs requires adherence to city,
 county, state, federal, and foreign environmental regulations
 regarding the storage, use, handling and disposal of chemicals,
 solid wastes and other hazardous materials, as well as compliance
 with air quality standards and chemical use reporting. The Company
 believes that its facilities in the United States comply in all
 material respects with applicable environmental laws and
 regulations. In China, governmental authorities have adopted
 new rules and regulations governing environmental issues. An
 update to the Chinese environmental waste water law was issued in
 late 2012, but allows for an interim period in which plants subject
 to such law may install equipment that meets the new regulatory
 regime. Some of the Company’s plants in China are not yet in
 full compliance with the updated environmental
 regulations. The Company believes it has developed plans
 acceptable to the Chinese government and is in the process of
 implementing these plans. The Company does not anticipate any
 immediate risk of government fines or temporary closure of its
 Chinese plants. The Company has established and enacted an
 investment plan related to the efforts to come into full compliance
 with the new regulations. The 2015 capital expenditure costs
 expected for these plans are included in the Company’s
 capital expenditure projections.


## us-gaap:EarningsPerShareTextBlock

[0001193125-15-170026:notes:11]
[same as prior period, unchanged from 0001193125-14-404493:notes:10]

[0001193125-15-170026:notes:12]
The
 following is a reconciliation of the numerator and denominator used
 to calculate basic earnings per share and diluted earnings per
 share for the quarters ended March 30, 2015 and March 31,
 2014:

[0001193125-15-170026:notes:13]
|  |  | Quarter Ended |  |
|  |  | March 30, 2015 |  |  | March 31, 2014 |  |
|  |  | (In thousands, except per share amounts) |  |
| Net income (loss) |  | $ | 3,446 |  |  | $ | (3,799 | ) |
| Weighted average shares outstanding |  |  | 83,603 |  |  |  | 82,925 |  |
| Dilutive effect of performance-based stock units, restricted stock units and stock options |  |  | 862 |  |  |  | — |  |
| Diluted shares |  |  | 84,465 |  |  |  | 82,925 |  |
| Earnings (loss) per share: |  |  |  |  |  |  |  |  |
| Basic |  | $ | 0.04 |  |  | $ | (0.05 | ) |
| Diluted |  | $ | 0.04 |  |  | $ | (0.05 | ) |

[0001193125-15-170026:notes:14]
For
 the quarter ended March 30, 2015, performance-based restricted
 stock units (PRUs), restricted stock units (RSUs), and stock
 options to purchase 438 shares of common stock were not considered
 in calculating diluted earnings per share because the
 options’ exercise prices or the total assumed proceeds under
 the treasury stock method for PRUs, RSUs, or stock options was
 greater than the average market price of common shares during the
 applicable year and, therefore, the effect would be
 anti-dilutive.

[0001193125-15-170026:notes:15]
For
 the quarter ended March 31, 2014, potential shares of common
 stock, consisting of stock options to purchase approximately 597
 shares of common stock at exercise prices ranging from $5.78 to
 $16.82 per share, 1,769 RSUs, and 229 PRUs were not included in the
 computation of diluted earnings per share because the Company
 incurred a net loss and, as a result, the impact would be
 anti-dilutive.

[0001193125-15-170026:notes:16]
Additionally, for both of the quarters ended March 30,
 2015 and March 31, 2014 the effect of 27,970 shares of common
 stock, related to the Company’s convertible senior notes, and
 warrants to purchase 28,020 shares of common stock, were not
 included in the computation of dilutive earnings per share because
 the conversion price of the convertible senior notes and the strike
 price of the warrants to purchase the Company’s common stock
 were greater than the average market price of common shares during
 the applicable year, and therefore, the effect would be
 anti-dilutive.


## us-gaap:ScheduleOfDerivativeInstrumentsTextBlock

[0001193125-15-170026:notes:17]
The fair values of derivative instruments in the consolidated
 condensed balance sheets are as follows:

[0001193125-15-170026:notes:18]
|  |  |  |  | Asset / (Liability) Fair Value |  |
|  |  | Balance Sheet Location |  | March 30, 2015 |  |  | December 29, 2014 |  |
|  |  |  |  | (In thousands) |  |
| Cash flow derivative instruments designated as hedges: |  |  |  |  |  |
| Foreign exchange contracts |  | Other accrued expenses |  | $ | (55 | ) |  | $ | (12 | ) |
| Cash flow derivative instruments not designated as hedges: |  |  |  |  |  |  |  |  |
| Foreign exchange contracts |  | Other accrued expenses |  |  | (3,497 | ) |  |  | (5,050 | ) |
|  |  |  |  | $ | (3,552 | ) |  | $ | (5,062 | ) |


## us-gaap:ScheduleOfFairValueAssetsAndLiabilitiesMeasuredOnRecurringBasisTableTextBlock

[0001193125-15-170026:notes:19]
At March 30, 2015 and December 29, 2014, the
 following financial assets and liabilities were measured at fair
 value on a recurring basis using the type of inputs
 shown:

[0001193125-15-170026:notes:20]
|  |  | March 30, 2015 |  |  | Fair Value Measurements Using: |  |
|  |  |  | Level 1 Inputs |  |  | Level 2 Inputs |  |  | Level 3 Inputs |  |
|  |  | (In thousands) |  |
| Money market funds |  | $ | 84,015 |  |  | $ | 84,015 |  |  | $ | — |  |  |  | — |  |
| Foreign exchange derivative liabilities |  |  | 3,552 |  |  |  | — |  |  |  | 3,552 |  |  |  | — |  |
|  |  | December 29, 2014 |  |  | Fair Value Measurements Using: |  |
|  |  |  | Level 1 Inputs |  |  | Level 2 Inputs |  |  | Level 3 Inputs |  |
|  |  | (In thousands) |  |
| Money market funds |  | $ | 129,012 |  |  | $ | 129,012 |  |  | $ | — |  |  |  | — |  |
| Foreign exchange derivative liabilities |  |  | 5,062 |  |  |  | — |  |  |  | 5,062 |  |  |  | — |  |


## us-gaap:ScheduleOfShareBasedPaymentAwardStockOptionsValuationAssumptionsTableTextBlock

[0001193125-15-170026:notes:21]
For the quarters ended March 30, 2015 and March 31,
 2014 the following assumptions were used in determining the fair
 value:

[0001193125-15-170026:notes:22]
|  |  | March 30, 20151 |  |  | March 31, 20142 |  |
| Weighted-average fair value |  | $ | 7.22 |  |  | $ | 5.80 |  |
| Risk-free interest rate |  |  | 0.5 | % |  |  | 0.4 | % |
| Dividend yield |  |  | — |  |  |  | — |  |
| Expected volatility |  |  | 37 | % |  |  | 41 | % |
| Expected term in months |  |  | 22 |  |  |  | 23 |  |

[0001193125-15-170026:notes:23]
| (1) | Reflects the weighted-averages for the third year of the three-year performance period applicable to PRUs granted in 2013, second year of the three-year performance period applicable to PRUs granted in 2014 and first year of the three-year performance period applicable to PRUs granted in 2015. |

[0001193125-15-170026:notes:24]
| (2) | Reflects the weighted-averages for the third year of the three-year performance period applicable to PRUs granted in 2012, second year of the three-year performance period applicable to PRUs granted in 2013 and first year of the three-year performance period applicable to PRUs granted in 2014. |


## us-gaap:ConcentrationRiskDisclosureTextBlock

[0001193125-15-170026:notes:25]
[same as prior period, unchanged from 0001193125-14-404493:notes:24]

[0001193125-15-170026:notes:26]
In the
 normal course of business, the Company extends credit to its
 customers, which are concentrated primarily in the computer and
 networking, communications and aerospace and defense industries.
 Most customers to which the Company extends credit are located
 outside the United States, with the exception of certain customers
 in the aerospace and defense industries. The Company performs
 ongoing credit evaluations of customers, does not require
 collateral, and considers the credit risk profile of the entity
 from which the receivable is due in further evaluating collection
 risk.

[0001193125-15-170026:notes:27]
The
 Company’s customers include both OEMs and EMS companies. The
 Company’s OEM customers often direct a significant portion of
 their purchases through EMS companies. While the Company’s
 customers include both OEM and EMS providers, the Company measures
 customer concentration based on OEM companies, as they are the
 ultimate end customers.

[0001193125-15-170026:notes:28]
For
 the quarters ended March 30, 2015 and March 31, 2014, one
 customer accounted for approximately 27% and 16%, respectively, of
 the Company’s net sales. There were no other customers that
 accounted for 10% or more of net sales for the quarters ended
 March 30, 2015 and March 31, 2014.


## us-gaap:ScheduleOfInventoryCurrentTableTextBlock

[0001193125-15-170026:notes:29]
Inventories as of March 30, 2015 and December 29,
 2014 consist of the following:

[0001193125-15-170026:notes:30]
|  |  | As of |  |
|  |  | March 30, 2015 |  |  | December 29, 2014 |  |
|  |  | (In thousands) |  |
| Inventories: |  |  |  |  |  |  |  |  |
| Raw materials |  | $ | 46,069 |  |  | $ | 44,477 |  |
| Work-in-process |  |  | 60,200 |  |  |  | 57,544 |  |
| Finished goods |  |  | 47,651 |  |  |  | 43,166 |  |
|  |  | $ | 153,920 |  |  | $ | 145,187 |  |


## us-gaap:SegmentReportingDisclosureTextBlock

[0001193125-15-170026:notes:31]
[same as prior period, unchanged from 0001193125-14-404493:notes:30]

[0001193125-15-170026:notes:32]
The
 operating segments reported below are the Company’s segments
 for which separate financial information is available and upon
 which operating results are evaluated by the chief operating
 decision maker to assess performance and to allocate resources. The
 Company manages its worldwide operations based on two geographic
 operating segments: 1) Asia Pacific, which consists of five PCB
 fabrication plants, and 2) North America, which consists of seven
 domestic PCB fabrication plants, including a facility that provides
 follow-on value-added services primarily for one of the PCB
 fabrication plants, and one backplane assembly plant in Shanghai,
 China, which is managed in conjunction with the Company’s
 U.S. operations. Each segment operates predominantly in the same
 industry with production facilities that produce customized
 products for its customers and use similar means of product
 distribution.

[0001193125-15-170026:notes:33]
The
 Company evaluates segment performance based on operating segment
 income, which is operating income before amortization of
 intangibles. Interest expense and interest income are not presented
 by segment since they are not included in the measure of segment
 profitability reviewed by the chief operating decision maker. All
 inter-segment transactions have been eliminated. Reportable segment
 assets exclude short-term investments, which are managed
 centrally.

[0001193125-15-170026:notes:34]
|  |  | For the Quarter Ended |  |
|  |  | March 30, 2015 |  |  | March 31, 2014 |  |
|  |  | (In thousands) |  |
| Net Sales: |  |  |  |  |  |  |  |  |
| Asia Pacific |  | $ | 205,365 |  |  | $ | 165,666 |  |
| North America |  |  | 124,321 |  |  |  | 126,589 |  |
| Total sales |  |  | 329,686 |  |  |  | 292,255 |  |
| Inter-segment sales |  |  | (522 | ) |  |  | (360 | ) |
| Total net sales |  | $ | 329,164 |  |  | $ | 291,895 |  |
| Operating Segment Income (Loss): |  |  |  |  |  |  |  |  |
| Asia Pacific |  | $ | 14,441 |  |  | $ | 3,867 |  |
| North America |  |  | (4,302 | ) |  |  | 2,822 |  |
| Total operating segment income |  |  | 10,139 |  |  |  | 6,689 |  |
| Amortization of definite-lived intangibles |  |  | (1,874 | ) |  |  | (2,236 | ) |
| Total operating income |  |  | 8,265 |  |  |  | 4,453 |  |
| Total other expense |  |  | (6,180 | ) |  |  | (10,107 | ) |
| Income (loss) before income taxes |  | $ | 2,085 |  |  | $ | (5,654 | ) |

[0001193125-15-170026:notes:35]
The
 Company accounts for inter-segment sales and transfers as if the
 sale or transfer were to third parties: at arms length and
 consistent with the Company’s revenue recognition policy. The
 inter-segment sales for the quarters ended March 30, 2015 and
 March 31, 2014 are sales from the Asia Pacific operating
 segment to the North America operating segment.


## us-gaap:InventoryDisclosureTextBlock

[0001193125-15-170026:notes:36]
[same as prior period, unchanged from 0001193125-14-404493:notes:35]


## us-gaap:RelatedPartyTransactionsDisclosureTextBlock

[0001193125-15-170026:notes:37]
(16) Related Party
 Transactions

[0001193125-15-170026:notes:38]
In the
 normal course of business, the Company’s foreign subsidiaries
 purchase laminate and prepreg from related parties in which a
 significant shareholder of the Company holds an equity interest.
 For the quarters ended March 30, 2015 and March 31, 2014,
 the Company’s foreign subsidiaries purchased $9,945 and
 $11,790, respectively, of laminate and prepreg from these related
 parties.

[0001193125-15-170026:notes:39]
Dongguan Shengyi Electronics Ltd. (SYE) is a related party, as
 a significant shareholder of the Company holds an equity interest
 in the parent company of SYE. Sales to SYE for the quarters ended
 March 30, 2015 and March 31, 2014 were $1,481 and
 $10,147, respectively. Additionally, purchases from SYE for the
 quarters ended March 30, 2015 and March 31, 2014 were
 approximately $439 and $271, respectively.

[0001193125-15-170026:notes:40]
As of
 March 30, 2015 and December 29, 2014, the Company’s
 consolidated balance sheets included $16,852 and $17,950,
 respectively, in accounts payable due to, and $4,022 and $4,934,
 respectively, in accounts receivable due from a related party for
 the purchase of laminate and prepreg, and sales of PCBs to SYE, as
 mentioned above.


## us-gaap:ScheduleOfEmployeeServiceShareBasedCompensationAllocationOfRecognizedPeriodCostsTextBlock

[0001193125-15-170026:notes:41]
[same as prior period, unchanged from 0001193125-14-404493:notes:40]

[0001193125-15-170026:notes:42]
|  |  | Quarter Ended |  |
|  |  | March 30, 2015 |  |  | March 31, 2014 |  |
|  |  | (In thousands) |  |
| Cost of goods sold |  | $ | 225 |  |  | $ | 263 |  |
| Selling and marketing |  |  | 271 |  |  |  | 335 |  |
| General and administrative |  |  | 1,544 |  |  |  | 1,570 |  |
| Stock-based compensation expense recognized |  |  | 2,040 |  |  |  | 2,168 |  |
| Income tax benefit recognized |  |  | (522 | ) |  |  | (570 | ) |
| Total stock-based compensation expense after income taxes |  | $ | 1,518 |  |  | $ | 1,598 |  |


## us-gaap:ScheduleOfShareBasedCompensationArrangementByShareBasedPaymentAwardPerformanceBasedUnitsVestedAndExpectedToVestTableTextBlock

[0001193125-15-170026:notes:43]
PRUs activity for the quarter ended March 30, 2015 was as
 follows:

[0001193125-15-170026:notes:44]
|  |  | Shares |  |  | Weighted Average Fair Value |  |
|  |  | (In thousands) |  |  |  |  |
| Outstanding target shares at December 29, 2014 |  |  | 275 |  |  | $ | 8.03 |  |
| Granted |  |  | 295 |  |  |  | 7.22 |  |
| Change in units due to annual financial target performance achievement |  |  | 7 |  |  |  | 7.22 |  |
| Outstanding target shares at March 30, 2015 |  |  | 577 |  |  | $ | 7.61 |  |


## us-gaap:ScheduleOfUnrecognizedCompensationCostNonvestedAwardsTableTextBlock

[0001193125-15-170026:notes:45]
The
 following is a summary of total unrecognized compensation costs as
 of March 30, 2015:

[0001193125-15-170026:notes:46]
|  |  | Unrecognized Stock-Based Compensation Cost |  |  | Remaining Weighted Average Recognition Period |
|  |  | (In thousands) |  |  | (years) |
| RSU awards |  | $ | 12,626 |  |  | 1.67 |
| PRU awards |  |  | 2,673 |  |  | 1.80 |
|  |  | $ | 15,299 |  |  |  |


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001193125-15-170026:notes:47]
[same as prior period, unchanged from 0001193125-14-404493:notes:48]

[0001193125-15-170026:notes:48]
[same as prior period, unchanged from 0001193125-14-404493:notes:49]

[0001193125-15-170026:notes:49]
The Company enters into foreign currency forward contracts to
 mitigate the impact of changes in foreign currency exchange rates
 and to reduce the volatility of purchases and other obligations
 generated in currencies other than the functional currencies. The
 Company’s foreign subsidiaries may at times purchase forward
 exchange contracts to manage their foreign currency risks in
 relation to certain purchases of machinery denominated in foreign
 currencies other than the Company’s foreign functional
 currency. The notional amount of the foreign exchange contracts as
 of March 30, 2015 and December 29, 2014 was approximately
 $19,867 and $29,142, respectively. The Company has designated
 certain of these foreign exchange contracts as cash flow
 hedges.

[0001193125-15-170026:notes:50]
The following table provides information about the amounts
 recorded in accumulated other comprehensive income related to
 derivatives designated as cash flow hedges, as well as the amounts
 recorded in each caption in the consolidated condensed statements
 of operations when derivative amounts are reclassified out of
 accumulated other comprehensive income:

[0001193125-15-170026:notes:51]
|  |  |  |  |  | For the Quarter Ended |  |
|  |  |  |  |  | March 30, 2015 |  |  | March 31, 2014 |  |
|  |  |  |  |  | Effective Portion |  |  | Ineffective Portion |  |  | Effective Portion |  |  | Ineffective Portion |  |
|  |  | Financial Statement Caption |  |  | Gain/(Loss) Recognized in Other Comprehensive Income |  |  | Gain/(Loss) Reclassified into Income |  |  | Gain/(Loss) Reclassified into Income |  |  | Gain/(Loss) Recognized in Other Comprehensive Income |  |  | Gain/(Loss) Reclassified into Income |  |  | Gain/(Loss) Recognized into Income |  |
|  |  | (In thousands) |  |
| Cash flow hedge: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Foreign currency forward |  |  | Depreciation expense |  |  | $ | (53 | ) |  | $ | (42 | ) |  | $ | — |  |  | $ | 120 |  |  | $ | (25 | ) |  | $ | — |  |
|  |  |  |  |  |  | $ | (53 | ) |  | $ | (42 | ) |  | $ | — |  |  | $ | 120 |  |  | $ | (25 | ) |  | $ | — |  |

[0001193125-15-170026:notes:52]
The following table provides a summary of the activity
 associated with the designated cash flow hedges reflected in
 accumulated other comprehensive income (loss) for the quarters
 ended March 30, 2015 and March 31, 2014:

[0001193125-15-170026:notes:53]
|  |  | For the Quarter Ended |  |
|  |  | March 30, 2015 |  |  | March 31, 2014 |  |
|  |  | (In thousands) |  |
| Beginning balance unrealized loss, net of tax |  | $ | (1,424 | ) |  | $ | (1,613 | ) |
| Changes in fair value (loss) gain, net of tax |  |  | (53 | ) |  |  | 120 |  |
| Reclassification to earnings |  |  | 42 |  |  |  | 25 |  |
| Ending balance unrealized loss, net of tax |  | $ | (1,435 | ) |  | $ | (1,468 | ) |

[0001193125-15-170026:notes:54]
The Company expects that approximately $175 of expense will be
 reclassified into the statement of operations, net of tax, in the
 next 12 months.

[0001193125-15-170026:notes:55]
The net gain recognized in other, net in the consolidated
 condensed statements of operations related to foreign exchange
 contracts not designated as hedges was $83 and $522 for the
 quarters ended March 30, 2015 and March 31, 2014,
 respectively.


## us-gaap:ScheduleOfAccumulatedOtherComprehensiveIncomeLossTableTextBlock

[0001193125-15-170026:notes:56]
The following provides a summary of the components of
 accumulated other comprehensive income (loss) as of March 30,
 2015 and December 29, 2014:

[0001193125-15-170026:notes:57]
|  |  | Foreign Currency Translation |  |  | Gains (Losses) on Cash Flow Hedges |  |  | Total |  |
|  |  | (In thousands) |  |
| Ending balance at December 29, 2014 |  | $ | 32,439 |  |  | $ | (1,424 | ) |  | $ | 31,015 |  |
| Other comprehensive income (loss) before reclassifications |  |  | 1,063 |  |  |  | (53 | ) |  |  | 1,010 |  |
| Amounts reclassified from accumulated other comprehensive income |  |  | (1,786 | ) |  |  | 42 |  |  |  | (1,744 | ) |
| Other comprehensive loss |  |  | (723 | ) |  |  | (11 | ) |  |  | (734 | ) |
| Ending balance at March 30, 2015 |  | $ | 31,716 |  |  | $ | (1,435 | ) |  | $ | 30,281 |  |


## us-gaap:ScheduleOfDebtInstrumentsTextBlock

[0001193125-15-170026:notes:58]
The following table summarizes the long-term debt of the
 Company as of March 30, 2015 and December 29,
 2014:

[0001193125-15-170026:notes:59]
|  |  | Average Effective Interest Rate as of March 30, 2015 |  | March 30, 2015 |  |  | Average Effective Interest Rate as of December 29, 2014 |  | December 29, 2014 |  |
|  |  | (In thousands) |  |
| Term loan due September 2016 |  | 2.56% |  | $ | 225,700 |  |  | 2.55% |  | $ | 273,800 |  |
| Other |  | 6.00% |  |  | 2 |  |  | 6.00% |  |  | 4 |  |
|  |  |  |  |  | 225,702 |  |  |  |  |  | 273,804 |  |
| Less: current maturities |  |  |  |  | (96,202 | ) |  |  |  |  | (96,204 | ) |
| Long-term debt, less current maturities |  |  |  | $ | 129,500 |  |  |  |  | $ | 177,600 |  |


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001193125-15-170026:notes:60]
[same as prior period, unchanged from 0001193125-14-404493:notes:71]

[0001193125-15-170026:notes:61]
On
 September 21, 2014, TTM, Viasystems Group, Inc. (Viasystems),
 and Vector Acquisition Corp. (Merger Sub) entered into an Agreement
 and Plan of Merger (the Merger Agreement) under which, subject to
 the satisfaction of certain conditions, TTM expects to acquire all
 outstanding shares of Viasystems (the Merger) for a combined
 consideration of $11.33 in cash and 0.706 shares of TTM common
 stock per outstanding share of Viasystems common stock, which based
 on the closing market price on April 24, 2015 was valued at
 $17.84 per share of Viasystems common stock, or approximately
 $387.0 million. The total purchase price of the transaction,
 including debt assumed, is approximately $997.4 million, which was
 based on the closing market price of the Company’s common
 stock on April 24, 2015 and is subject to change prior to the
 consummation of the Merger.

[0001193125-15-170026:notes:62]
Concurrently with the execution of the Merger Agreement, the
 Company obtained a debt financing commitment in an aggregate amount
 of $1,115 million in connection with financing the transactions
 contemplated by the Merger Agreement. Assuming consummation of the
 Merger, the Company currently intends to use approximately $1,030
 million of the proceeds of such financing commitment, or
 alternative financing arrangements, to finance the Merger, to
 refinance certain existing indebtedness of Viasystems, to refinance
 certain of the Company’s existing indebtedness, and to pay
 the fees and expenses incurred in connection with the Merger. The
 Company is in the process of finalizing the specific financing
 arrangements.

[0001193125-15-170026:notes:63]
Viasystems is a worldwide provider of complex multi-layer
 rigid, flexible, and rigid-flex PCBs and electro-mechanical
 solutions (E-M Solutions). Viasystems’ products are found in
 a wide variety of commercial products, including automotive engine
 controls, hybrid converters, automotive electronics for navigation,
 safety, and entertainment, telecommunications switching equipment,
 data networking equipment, computer storage equipment,
 semiconductor test equipment, wind and solar energy applications,
 off-shore drilling equipment, communications applications, flight
 control systems, and complex industrial, medical, and other
 technical instruments. Viasystems’ E-M Solutions services can
 be bundled with its PCBs to provide an integrated solution to
 customers. Viasystems operates 15 manufacturing facilities
 worldwide: eight in the United States, five in the People’s
 Republic of China (China), one each in Canada and Mexico.
 Viasystems serves a diversified customer base of over 1,000
 customers in various markets throughout the world.

[0001193125-15-170026:notes:64]
The
 Merger Agreement provides that Viasystems is entitled to receive a
 reverse breakup fee of $40 million from TTM in the event that the
 Merger Agreement is terminated following specific
 conditions.

[0001193125-15-170026:notes:65]
Since
 the public announcement on September 22, 2014 of the execution
 of the Merger Agreement, TTM, Viasystems, Merger Sub, and the
 members of the Viasystems board of directors (the Viasystems Board)
 have been named as defendants in two putative class action
 complaints challenging the Merger. See Note 12 to these
 Consolidated Condensed Financial Statements for additional
 information.

[0001193125-15-170026:notes:66]
Bank
 fees and legal, accounting, and other professional service costs
 associated with the acquisition of Viasystems of $8,235 for the
 quarter ended March 30, 2015 have been expensed and recorded
 as general and administrative expense in the consolidated condensed
 statement of operations. There were no bank fees or legal,
 accounting, or other professional service costs associated with the
 acquisition for the quarter ended March 31, 2014.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001193125-15-170026:notes:67]
[same as prior period, unchanged from 0001193125-14-404493:notes:77]

[0001193125-15-170026:notes:68]
The
 Company’s effective tax rate will generally differ from the
 U.S. federal statutory rate of 35% due to favorable tax rates
 associated with earnings from the Company’s operations in
 lower-tax jurisdictions in China, the apportioned state income tax
 rates, generation of other credits and deductions available to us,
 and certain non-deductible items. For both quarters ended
 March 30, 2015 and March 31, 2014, the Company’s
 effective tax rate was further impacted by a discrete tax benefit
 resulting from the retroactive approval of the high technology
 enterprise status for certain subsidiaries in China within the
 Company’s Asia Pacific operating segment.

[0001193125-15-170026:notes:69]
[same as prior period, unchanged from 0001193125-14-404493:notes:81]


## us-gaap:LongTermDebtTextBlock

[0001193125-15-170026:notes:70]
(5) Long-term Debt and
 Letters of Credit

[0001193125-15-170026:notes:71]
The calendar maturities of long-term debt through 2016 are as
 follows:

[0001193125-15-170026:notes:72]
|  |  | (In thousands) |  |
| Remaining 2015 |  | $ | 48,102 |  |
| 2016 |  |  | 177,600 |  |
|  |  | $ | 225,702 |  |

[0001193125-15-170026:notes:73]
Credit
 Agreement

[0001193125-15-170026:notes:74]
In 2012, the Company became a party to a facility agreement
 (Credit Agreement) consisting of a $370,000 senior secured term
 loan (Term Loan), a $90,000 senior secured revolving loan
 (Revolving Loan), and a secured $80,000 letters of credit facility
 (Letters of Credit Facility). The Term Loan and Letters of Credit
 Facility will mature on September 14, 2016. The Revolving Loan
 will mature on March 14, 2016. The Credit Agreement is secured
 by substantially all of the assets of the Company’s Asia
 Pacific operating segment and is senior to all other debt,
 including the convertible senior notes. See Note 6 to these
 Consolidated Condensed Financial Statements. The Company has fully
 and unconditionally guaranteed the full and timely payment of all
 Credit Agreement related obligations of its Asia Pacific operating
 segment.

[0001193125-15-170026:notes:75]
As of March 30, 2015 and December 29, 2014, the
 remaining unamortized debt issuance costs included in other
 non-current assets was $924 and $1,123, respectively, and is
 amortized to interest expense over the term of the Company’s
 Credit Agreement using the effective interest rate method. At
 March 30, 2015, the remaining amortization period for the
 unamortized debt issuance costs was 1.3 years.

[0001193125-15-170026:notes:76]
The Company is also required to pay a commitment fee of
 0.50% per annum on any unused portion of the Revolving Loan
 and Letters of Credit Facility granted under the Credit Agreement.
 The Company incurred commitment fees related to unused borrowing
 availability of $173 and $133 for the quarters ended March 30,
 2015 and March 31, 2014, respectively. As of March 30,
 2015, the outstanding amount of the Term Loan under the Credit
 Agreement is $225,700, of which $96,200 is due for repayment in
 September 2015 and March 2016 and is included as short-term debt,
 with the remaining $129,500 included as long-term debt. None of the
 Revolving Loan was outstanding under the Credit Agreement as of
 March 30, 2015. Available borrowing capacity under the
 Revolving Loan was $90,000 at March 30, 2015.

[0001193125-15-170026:notes:77]
Other Credit
 Facility

[0001193125-15-170026:notes:78]
Additionally, the Company is party to a revolving loan credit
 facility (Chinese Revolver) with a lender in China. Under this
 arrangement, the lender has made available to the Company
 approximately $37,000 in unsecured borrowing with all terms of the
 borrowing to be negotiated at the time the Chinese Revolver is
 drawn upon. There are no commitment fees on the unused portion of
 the Chinese Revolver, and this arrangement expires in December
 2015. As of March 30, 2015, the Chinese Revolver had not been
 drawn upon.

[0001193125-15-170026:notes:79]
Letters of
 Credit

[0001193125-15-170026:notes:80]
The Company has an $80,000 Letters of Credit Facility under the
 Credit Agreement, as mentioned above. As of March 30, 2015,
 letters of credit in the amount of $30,893 were outstanding under
 this Credit Agreement. The Company has other standby letters of
 credit outstanding in the amount of $4,257, which expire between
 December 31, 2015 and February 28, 2016.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0001193125-15-170026:notes:81]
[same as prior period, unchanged from 0001193125-14-404493:notes:93]

[0001193125-15-170026:notes:82]
TTM Technologies, Inc. (the Company or TTM) is a leading global
 provider of time-critical and technologically complex printed
 circuit board (PCB) products and backplane assemblies (i.e., PCBs
 populated with electronic components), which serve as the
 foundation of sophisticated electronic products. The Company
 provides time-to-market and advanced technology products and offers
 a one-stop manufacturing solution to customers from engineering
 support to prototype development through final volume production.
 This one-stop manufacturing solution allows the Company to align
 technology developments with the diverse needs of the
 Company’s customers and to enable them to reduce the time
 required to develop new products and bring them to
 market.

[0001193125-15-170026:notes:83]
Additionally, the Company serves a diversified customer base in
 various markets throughout the world, including manufacturers of
 networking/communications infrastructure products, touchscreen
 tablets and smartphones, as well as the aerospace and defense,
 high-end computing, and industrial/medical industries. The
 Company’s customers include both original equipment
 manufacturers (OEMs) and electronic manufacturing services (EMS)
 providers.

[0001193125-15-170026:notes:84]
The accompanying consolidated condensed financial statements
 have been prepared by the Company, without audit, pursuant to the
 rules and regulations of the Securities and Exchange Commission
 (SEC). Certain information and disclosures normally included in
 financial statements prepared in accordance with accounting
 principles generally accepted in the United States of America (U.S.
 GAAP) have been condensed or omitted pursuant to such rules and
 regulations. These consolidated condensed financial statements
 reflect all adjustments (consisting only of normal recurring
 adjustments) which, in the opinion of management, are necessary to
 present fairly the financial position, the results of operations
 and cash flows of the Company for the periods presented. It is
 suggested that these consolidated condensed financial statements be
 read in conjunction with the consolidated financial statements and
 the notes thereto included in the Company’s most recent
 Annual Report on Form 10-K. The results of operations for the
 interim periods are not necessarily indicative of the results to be
 expected for the full year. The preparation of financial statements
 in accordance with U.S. GAAP requires management to make estimates
 and assumptions that affect the amounts reported in the
 Company’s consolidated condensed financial statements and
 accompanying notes. Actual results could differ materially from
 those estimates. The Company uses a 13-week fiscal quarter
 accounting period with the fourth quarter ending on the Monday
 nearest December 31.

[0001193125-15-170026:notes:85]
Recently Issued
 Accounting Standards

[0001193125-15-170026:notes:86]
In April 2015, the Financial Accounting Standards Board (FASB)
 issued Accounting Standard Update (ASU) 2015-03,
 Interest-Imputation of Interest, which requires an entity to
 record debt issuance costs related to a note reported in the
 balance sheet as a direct deduction from the face amount of that
 note. The update is effective for annual periods ending after
 December 15, 2015. Early application is permitted. The
 standard requires the use of the retrospective transition method.
 The impact on the Company’s financial statements is not
 expected to be material.

[0001193125-15-170026:notes:87]
In August 2014, the FASB issued ASU 2014-15 Disclosure of
 Uncertainties About an Entity’s Ability to Continue as a
 Going Concern, which provides guidance on determining when and
 how to disclose going concern uncertainties in the financial
 statements. The new standard requires management to perform interim
 and annual assessments of an entity’s ability to continue as
 a going concern. The update is effective for annual periods ending
 after December 15, 2016, and interim periods thereafter. Early
 adoption is permitted. The impact on the Company’s financial
 statements of adopting ASU 2014-15 is not expected to be
 material.

[0001193125-15-170026:notes:88]
In May 2014, the FASB issued ASU 2014-09, Revenue from
 Contracts with Customers, which requires an entity to recognize
 the amount of revenue to which it expects to be entitled for the
 transfer of promised goods or services to customers. ASU 2014-09
 will replace most existing revenue recognition guidance in U.S.
 GAAP when it becomes effective. The new standard is effective for
 the Company at the beginning of fiscal year 2017. Early application
 is not permitted. The standard permits the use of either the
 retrospective or cumulative effect transition method. We are
 evaluating the effect that ASU 2014-09 will have on the
 Company’s consolidated financial statements and related
 disclosures. The Company has not yet selected a transition method,
 nor has the Company determined the effect of the standard on its
 ongoing financial reporting.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001193125-15-170026:notes:89]
[same as prior period, unchanged from 0001193125-14-404493:notes:99]

[0001193125-15-170026:notes:90]
[same as prior period, unchanged from 0001193125-14-404493:notes:100]

[0001193125-15-170026:notes:91]
The Company maintains a long-term incentive program for
 executives that provides for the issuance of PRUs, representing
 hypothetical shares of the Company’s common stock that may be
 issued. Under the PRU program, a target number of PRUs is awarded
 at the beginning of each three-year performance period. The number
 of shares of common stock released at the end of the performance
 period will range from zero to 2.4 times the target number
 depending on performance during the period. The performance metrics
 of the PRU program are based on (a) annual financial targets,
 which are based on revenue and EBITDA (earnings before interest,
 tax, depreciation, and amortization expense), each equally
 weighted, and (b) an overall modifier based on the
 Company’s total stockholder return (TSR) relative to a group
 of peer companies selected by the Company’s compensation
 committee, over the three-year performance period.

[0001193125-15-170026:notes:92]
The Company records stock-based compensation expense for PRU
 awards granted based on management’s periodic assessment of
 the probability of the PRU awards vesting. For the quarter ended
 March 30, 2015, management determined that vesting of the PRU
 awards was probable. PRUs activity for the quarter ended
 March 30, 2015 was as follows:

[0001193125-15-170026:notes:93]
The fair value for PRUs granted is calculated using a Monte
 Carlo simulation model, as the TSR modifier contains a market
 condition. For the quarters ended March 30, 2015 and
 March 31, 2014 the following assumptions were used in
 determining the fair value:

[0001193125-15-170026:notes:94]
[same as prior period, unchanged from 0001193125-14-404493:notes:104]

[0001193125-15-170026:notes:95]
The Company granted 970 and 760 RSUs during the quarters ended
 March 30, 2015 and March 31, 2014, respectively. The RSUs
 granted have a weighted-average fair value per unit of $8.80 and
 $8.00 for the quarters ended March 30, 2015 and March 31,
 2014, respectively. The fair value for RSUs granted is based on the
 closing share price of the Company’s common stock on the date
 of grant.

[0001193125-15-170026:notes:96]
[same as prior period, unchanged from 0001193125-14-404493:notes:106]

[0001193125-15-170026:notes:97]
The Company did not grant any stock option awards during the
 quarters ended March 30, 2015 and March 31,
 2014.

[0001193125-15-170026:notes:98]
[same as prior period, unchanged from 0001193125-14-404493:notes:108]

[0001193125-15-170026:notes:99]
The following is a summary of total unrecognized compensation
 costs as of March 30, 2015:


## us-gaap:FairValueDisclosuresTextBlock

[0001193125-15-170026:notes:100]
[same as prior period, unchanged from 0001193125-14-404493:notes:109]

[0001193125-15-170026:notes:101]
[same as prior period, unchanged from 0001193125-14-404493:notes:110]

[0001193125-15-170026:notes:102]
The carrying amount and estimated fair value of the
 Company’s financial instruments at March 30, 2015 and
 December 29, 2014 were as follows:

[0001193125-15-170026:notes:103]
|  |  | March 30, 2015 |  |  | December 29, 2014 |  |
|  |  | Carrying Amount |  |  | Fair Value |  |  | Carrying Amount |  |  | Fair Value |  |
|  |  | (In thousands) |  |
| Derivative liabilities, current |  | $ | 3,552 |  |  | $ | 3,552 |  |  | $ | 5,062 |  |  | $ | 5,062 |  |
| Long-term debt |  |  | 225,702 |  |  |  | 226,403 |  |  |  | 273,804 |  |  |  | 273,820 |  |
| Convertible senior notes due 2015 |  |  | 32,208 |  |  |  | 33,053 |  |  |  | 31,841 |  |  |  | 32,631 |  |
| Convertible senior notes due 2020 |  |  | 198,880 |  |  |  | 274,200 |  |  |  | 197,042 |  |  |  | 241,875 |  |

[0001193125-15-170026:notes:104]
The fair value of the derivative instruments was determined
 using pricing models developed based on the LIBOR swap rate,
 foreign currency exchange rates, and other observable market data,
 including quoted market prices, as appropriate. The values were
 adjusted to reflect nonperformance risk of the counterparty and the
 Company, as necessary.

[0001193125-15-170026:notes:105]
The fair value of the long-term debt was estimated based on
 discounting the debt over its life using current market rates for
 similar debt as of March 30, 2015 and December 29, 2014,
 which are considered Level 1 and Level 2 inputs.

[0001193125-15-170026:notes:106]
The fair value of the convertible senior notes was estimated
 based on quoted market prices of the securities on an active
 exchange, which are considered Level 1 and Level 2
 inputs.

[0001193125-15-170026:notes:107]
As of March 30, 2015 and December 29, 2014, the
 Company’s other financial instruments also included cash and
 cash equivalents, accounts receivable, accounts payable and
 equipment payables. Due to short-term maturities, the carrying
 amount of these instruments approximates fair value.

[0001193125-15-170026:notes:108]
There were no transfers of financial assets or liabilities
 between Level 1 and Level 2 inputs for the quarters ended
 March 30, 2015 and March 31, 2014.


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0001193125-15-170026:notes:109]
[same as prior period, unchanged from 0001193125-14-404493:notes:112]

[0001193125-15-170026:notes:110]
Foreign currency translation ending balances, summarized above,
 are reported net of tax of $2,989 and $2,979 as of March 30,
 2015 and December 29, 2014, respectively.

[0001193125-15-170026:notes:111]
The following provides a summary of reclassifications out of
 accumulated other comprehensive income for the quarters ended
 March 30, 2015 and March 31, 2014:

[0001193125-15-170026:notes:112]
|  |  |  |  | Amount Reclassified from Accumulated Other Comprehensive Income |  |
|  |  |  |  | For the Quarter Ended |  |
| Details about Accumulated Other Comprehensive Income Components |  | Statement of Operations Location |  | March 30, 2015 |  |  | March 31, 2014 |  |
| Gain on foreign currency translation |  | Gain on sale of assets, net of tax |  | $ | (1,786 | ) |  | $ | — |  |
| Loss on cash flow hedges |  | Depreciation expense, net of tax |  | $ | 42 |  |  | $ | 25 |  |
| Loss on available for sale securities |  | Other, net, net of tax |  | $ | — |  |  | $ | 37 |  |


## ttmi:ScheduleOfLiabilityAndEquityComponentsOfConvertibleNotesTableTextBlock

[0001193125-15-170026:notes:113]
As of March 30, 2015 and December 29, 2014, the
 following summarizes the liability and equity components of the
 convertible senior notes:

[0001193125-15-170026:notes:114]
|  |  | As of March 30, 2015 |  |  | As of December 29, 2014 |  |
|  |  | Principal |  |  | Unamortized Discount |  |  | Net Carrying Amount |  |  | Principal |  |  | Unamortized Discount |  |  | Net Carrying Amount |  |
|  |  | (in thousands) |  |
| Liability components: |  |  |  |  |
| Convertible senior notes due 2020 |  | $ | 250,000 |  |  | $ | (51,120 | ) |  | $ | 198,880 |  |  | $ | 250,000 |  |  | $ | (52,958 | ) |  | $ | 197,042 |  |
| Convertible senior notes due 2015 |  |  | 32,395 |  |  |  | (187 | ) |  |  | 32,208 |  |  |  | 32,395 |  |  |  | (554 | ) |  |  | 31,841 |  |
| Total |  | $ | 282,395 |  |  | $ | (51,307 | ) |  | $ | 231,088 |  |  | $ | 282,395 |  |  | $ | (53,512 | ) |  | $ | 228,883 |  |

[0001193125-15-170026:notes:115]
|  |  | As of March 30, 2015 and December 29, 2014 |  |
|  |  | Embedded conversion option — Convertible Senior Notes |  |  | Embedded conversion option — Convertible Senior Notes Issuance Costs |  |  | Total |  |
|  |  | (in thousands) |  |
| Equity components: |  |  |  |  |  |  |  |  |  |  |  |  |
| Additional paid-in capital: |  |  |  |  |  |  |  |  |  |  |  |  |
| Convertible senior notes due 2020 |  | $ | 60,227 |  |  | $ | (1,916 | ) |  | $ | 58,311 |  |
| Convertible senior notes due 2015 |  |  | 39,781 |  |  |  | (1,413 | ) |  |  | 38,368 |  |
|  |  | $ | 100,008 |  |  | $ | (3,329 | ) |  | $ | 96,679 |  |


## ttmi:ScheduleOfComponentsOfInterestExpenseFromConvertibleNotesTableTextBlock

[0001193125-15-170026:notes:116]
The components of interest expense resulting from the
 convertible senior notes for the quarters ended March 30, 2015
 and March 31, 2014 are as follows:

[0001193125-15-170026:notes:117]
|  |  | For the Quarter Ended |  |
|  |  | March 30, 2015 |  |  | March 31, 2014 |  |
|  |  | (In thousands) |  |
| Contractual coupon interest |  |  |  |  |  |  |  |  |
| Convertible senior notes due 2020 |  | $ | 1,094 |  |  | $ | 1,085 |  |
| Convertible senior notes due 2015 |  |  | 263 |  |  |  | 263 |  |
|  |  | $ | 1,357 |  |  | $ | 1,348 |  |
| Amortization of debt discount |  |  |  |  |  |  |  |  |
| Convertible senior notes due 2020 |  | $ | 1,838 |  |  | $ | 1,764 |  |
| Convertible senior notes due 2015 |  |  | 367 |  |  |  | 338 |  |
|  |  | $ | 2,205 |  |  | $ | 2,102 |  |
| Amortization of debt issuance costs |  |  |  |  |  |  |  |  |
| Convertible senior notes due 2020 |  | $ | 184 |  |  | $ | 177 |  |
| Convertible senior notes due 2015 |  |  | 37 |  |  |  | 34 |  |
|  |  | $ | 221 |  |  | $ | 211 |  |


## ttmi:ConvertibleSeniorNotesTextBlock

[0001193125-15-170026:notes:118]
[same as prior period, unchanged from 0001193125-14-404493:notes:122]

[0001193125-15-170026:notes:119]
Convertible Senior
 Notes due 2020

[0001193125-15-170026:notes:120]
The Company issued 1.75% convertible senior notes due
 December 15, 2020, in a public offering for an aggregate
 principal amount of $250,000. The convertible senior notes bear
 interest at a rate of 1.75% per annum. Interest is payable
 semiannually in arrears on June 15 and December 15 of
 each year. The convertible senior notes are senior unsecured
 obligations and rank equally to the Company’s future
 unsecured senior indebtedness and senior in right of payment to any
 of the Company’s future subordinated indebtedness.

[0001193125-15-170026:notes:121]
The maximum number of shares issuable upon conversion,
 including the effect of a fundamental change and subject to certain
 conversion adjustments, would be 32,425.

[0001193125-15-170026:notes:122]
Convertible Note Hedge and Warrant
 Transaction: In connection with the issuance of the
 convertible senior notes due 2020, the Company entered into a
 convertible note hedge and warrant transaction (Call Spread
 Transaction), with respect to the Company’s common stock. The
 convertible note hedge consists of the Company’s option to
 purchase up to 25,940 common stock shares at a price of $9.64 per
 share. The hedge expires on December 15, 2020 and can only be
 executed upon the conversion of the above mentioned convertible
 senior notes due 2020. Additionally, the Company sold warrants to
 purchase 25,940 shares of its common stock at a price of
 $14.26 per share. The warrants expire ratably from March 2021
 through January 2022. The 2020 Call Spread Transaction has no
 effect on the terms of the convertible senior notes due 2020 and
 reduces potential dilution by effectively increasing the conversion
 price of the convertible senior notes due 2020 to $14.26 per share
 of the Company’s common stock.

[0001193125-15-170026:notes:123]
Convertible Senior
 Notes due 2015

[0001193125-15-170026:notes:124]
The Company issued 3.25% convertible senior notes due on
 May 15, 2015, in a public offering for an aggregate principal
 amount of $175,000. On May 15, 2015, the outstanding principal
 of $32,395 plus accrued interest is due and payable. The
 convertible senior notes are senior unsecured obligations and rank
 equally to the Company’s future unsecured senior indebtedness
 and senior in right of payment to any of the Company’s future
 subordinated indebtedness.

[0001193125-15-170026:notes:125]
The maximum number of shares issuable upon conversion,
 including the effect of a fundamental change and subject to certain
 conversion adjustments, would be 2,587.

[0001193125-15-170026:notes:126]
As of March 30, 2015 and December 29, 2014, remaining
 unamortized debt issuance costs included in other non-current
 assets were $5,142 and $5,363, respectively. The debt issuance
 costs and debt discount are being amortized to interest expense
 over the term of the convertible senior notes using the effective
 interest rate method. At March 30, 2015, the remaining
 weighted average amortization period for the unamortized senior
 convertible note discount and debt issuance costs was
 5.7 years.

[0001193125-15-170026:notes:127]
For the quarters ended March 30, 2015 and March 31,
 2014, the amortization of debt discount and debt issuance costs for
 the 2020 convertible senior notes and the 2015 convertible senior
 notes is based on an effective interest rate of 6.48% and 8.37%,
 respectively.


## ttmi:AssetsHeldForSaleDisclosureTextBlock

[0001193125-15-170026:notes:128]
(4) Sale of Suzhou,
 China Manufacturing Facility

[0001193125-15-170026:notes:129]
During the quarter ended March 30, 2015, the Company sold its
 Meadville Aspocomp (Suzhou) Electronic Co., Ltd. subsidiary, which
 held its Suzhou, China manufacturing facility, for $21,275 and
 recognized a gain of $2,504. This subsidiary was included in the
 Company’s Asia Pacific operating segment. The Company ceased
 manufacturing at this facility and shutdown its operations in
 2013. In the fourth quarter of 2014, the Company commenced the
 process of selling this subsidiary and classified its net assets as
 assets held for sale at December 29, 2014. Assets held for
 sale are included in other current assets in the December 29,
 2014 consolidated condensed balance sheet. As of March 30,
 2015, the Company held a receivable for the uncollected portion of
 the sales consideration in the amount of $14,093, which is included
 in other current assets in the consolidated condensed balance
 sheet. The Company expects to collect the remaining consideration
 during the second quarter of 2015.
