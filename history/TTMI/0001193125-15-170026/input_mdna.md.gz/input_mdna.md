# TTMI MD&A — 0001193125-15-170026


## mdna

[0001193125-15-170026:mdna:1]
[same as prior period, unchanged from 0001193125-14-404493:mdna:1]

[0001193125-15-170026:mdna:2]
This discussion and analysis should be read in conjunction with “Management’s Discussion and Analysis of
Financial Condition and Results of Operations” set forth in our Annual Report on Form 10-K for the fiscal year ended December 29, 2014, filed with the SEC.

[0001193125-15-170026:mdna:3]
[same as prior period, unchanged from 0001193125-14-404493:mdna:3]

[0001193125-15-170026:mdna:4]
We are a leading global
provider of time-critical and technologically complex printed circuit board products and backplane assemblies (i.e., PCBs populated with electronic components), which serve as the foundation of sophisticated electronic products. We focus on
providing time-to-market and advanced technology products and offer a one-stop manufacturing solution to our customers from engineering support to prototype development through final volume production. This one-stop manufacturing solution allows us
to align technology development with the diverse needs of our customers and to enable them to reduce the time required to develop new products and bring them to market. We serve a diversified customer base consisting of approximately 1,000 customers
in various markets throughout the world, including manufacturers of networking/communications infrastructure products, smartphones and touchscreen tablets, as well as the aerospace and defense, high-end computing, and industrial/medical industries.
Our customers include both original equipment manufacturers and electronic manufacturing services providers.

[0001193125-15-170026:mdna:5]
On September 21, 2014, TTM, Viasystems, and Merger Sub entered into the Merger Agreement under which, subject to the
satisfaction of certain conditions, we expect to acquire all outstanding shares of Viasystems for a combined consideration of $11.33 in cash and 0.706 shares of TTM common stock per outstanding share of Viasystems common stock, which based on the
closing market price on April 24, 2015 was valued at $17.84 per share of Viasystems common stock, or approximately $387.0 million. The total purchase price of the transaction, including debt assumed, is approximately $997.4 million, which was
based on our common stock closing market price on April 24, 2015 and is subject to change prior to the consummation of the Merger.

[0001193125-15-170026:mdna:6]
Concurrently with the execution of the Merger Agreement, we obtained a debt financing commitment in an aggregate amount of $1,115 million in connection with financing the transactions contemplated by the
Merger Agreement. Assuming consummation of the Merger, we currently intend to use approximately $1,030 million of the proceeds of such financing commitment, or alternative financing arrangements, to finance the Merger, to refinance certain existing
indebtedness of Viasystems, to refinance certain of our existing indebtedness, and to pay the fees and expenses incurred in connection with the Merger. We are in the process of finalizing the specific financing arrangements.

[0001193125-15-170026:mdna:7]
For the first quarter of 2015, we experienced higher demand in our Cellular Phone end market compared to that of the same
period in 2014. This increase in demand resulted in higher capacity utilization at our advanced technology plants resulting in higher net sales and gross margins. Additionally, we had improved operating efficiencies at certain of our plants in our
North America operating segment.

[0001193125-15-170026:mdna:8]
While our customers include both OEMs and EMS providers, we measure
customers based on OEM companies, as they are the ultimate end customers. Sales to our 10 largest customers accounted for 59% and 53% of our net sales for the quarters ended March 30, 2015 and March 31, 2014, respectively. We sell to OEMs
both directly and indirectly through EMS providers.

[0001193125-15-170026:mdna:9]
The following table shows the percentage of our net sales
attributable to each of the principal end markets we serve for the periods indicated.

[0001193125-15-170026:mdna:10]
|  |  | Quarter Ended |  |
| End Markets(1) |  | March 30,2015 |  |  | March 31,2014 |  |
| Aerospace/Defense |  |  | 15 | % |  |  | 17 | % |
| Cellular Phone(2) |  |  | 30 |  |  |  | 15 |  |
| Computing/Storage/Peripherals(2) |  |  | 11 |  |  |  | 18 |  |
| Medical/Industrial/Instrumentation |  |  | 9 |  |  |  | 10 |  |
| Networking/Communications |  |  | 29 |  |  |  | 34 |  |
| Other(2) |  |  | 6 |  |  |  | 6 |  |
| Total |  |  | 100 | % |  |  | 100 | % |

[0001193125-15-170026:mdna:11]
[same as prior period, unchanged from 0001193125-14-404493:mdna:13]

[0001193125-15-170026:mdna:12]
| (2) | Smartphones are included in the Cellular Phone end market, touchscreen tablets are included in the Computing/Storage/Peripherals end market and other mobile devices such as e-readers are included in the Other end market. |

[0001193125-15-170026:mdna:13]
Purchase orders may be cancelled prior to shipment. We charge customers a
fee, based on percentage completed, if an order is cancelled once it has entered production. We derive revenues primarily from the sale of PCBs and backplane assemblies using customer-supplied engineering and design plans. We recognize revenues when
persuasive evidence of a sales arrangement exists, the sales terms are fixed or determinable, title and risk of loss have transferred, and collectability is reasonably assured — generally when products are shipped to the customer. Net
sales consist of gross sales less an allowance for returns, which typically have been less than 3% of gross sales. We provide our customers a limited right of return for defective PCBs and backplane assemblies. We record an estimate for sales
returns and allowances at the time of sale based on historical results.

[0001193125-15-170026:mdna:14]
Cost of goods sold consists of
materials, labor, outside services, and overhead expenses incurred in the manufacture and testing of our products. Many factors affect our gross margin, including capacity utilization, product mix, production volume, and yield. We generally do not
participate in any significant long-term contracts with suppliers, and we believe there are a number of potential suppliers for the raw materials we use.

[0001193125-15-170026:mdna:15]
Selling and marketing expenses consist primarily of salaries, labor related benefits, and commissions paid to our internal sales force, independent sales representatives, and our sales support staff, as
well as costs associated with marketing materials and trade shows.

[0001193125-15-170026:mdna:16]
General and administrative costs primarily
include the salaries for executive, finance, accounting, information technology, facilities and human resources personnel, discretionary meals for employees in Asia, as well as insurance expenses, expenses for accounting and legal assistance,
incentive compensation expense, and gains or losses on the sale or disposal of property, plant and equipment.

[0001193125-15-170026:mdna:17]
CRITICAL ACCOUNTING POLICIES
AND ESTIMATES

[0001193125-15-170026:mdna:18]
Our consolidated condensed financial statements included in this report have been prepared
in accordance with U.S. GAAP. The preparation of these financial statements requires management to make estimates and assumptions that affect the reported amounts of assets, liabilities, net sales and expenses, and related disclosure of contingent
assets and liabilities.

[0001193125-15-170026:mdna:19]
See Item 7, Management’s Discussion and Analysis of Financial Condition
and Results of Operation, in our Annual Report on Form 10-K for the fiscal year ended December 29, 2014 for further discussion of critical accounting policies and estimates. There were no material changes to our critical accounting policies
and estimates since December 29, 2014.

[0001193125-15-170026:mdna:20]
[same as prior period, unchanged from 0001193125-14-404493:mdna:24]

[0001193125-15-170026:mdna:21]
The following table sets forth the relationship of various items to net sales in our consolidated condensed statements of
operations:

[0001193125-15-170026:mdna:22]
|  |  | Quarter Ended |  |
|  |  | March 30,2015 |  |  | March 31,2014 |  |
| Net sales |  |  | 100.0 | % |  |  | 100.0 | % |
| Cost of goods sold |  |  | 84.3 |  |  |  | 86.8 |  |
| Gross profit |  |  | 15.7 |  |  |  | 13.2 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |
| Selling and marketing |  |  | 2.9 |  |  |  | 3.2 |  |
| General and administrative |  |  | 10.5 |  |  |  | 7.7 |  |
| Amortization of definite-lived intangibles |  |  | 0.6 |  |  |  | 0.8 |  |
| Gain on sale of assets |  |  | (0.8 | ) |  |  | — |  |
| Total operating expenses |  |  | 13.2 |  |  |  | 11.7 |  |
| Operating income |  |  | 2.5 |  |  |  | 1.5 |  |
| Other income (expense): |  |  |  |  |  |  |  |  |
| Interest expense |  |  | (1.8 | ) |  |  | (2.1 | ) |
| Loss on extinguishment of debt |  |  | — |  |  |  | (0.2 | ) |
| Other, net |  |  | (0.1 | ) |  |  | (1.1 | ) |
| Total other expense, net |  |  | (1.9 | ) |  |  | (3.4 | ) |
| Income (loss) before income taxes |  |  | 0.6 |  |  |  | (1.9 | ) |
| Income tax benefit |  |  | 0.4 |  |  |  | 0.6 |  |
| Net income (loss) |  |  | 1.0 | % |  |  | (1.3 | )% |

[0001193125-15-170026:mdna:23]
We manage our worldwide operations based on two geographic operating segments: 1) Asia
Pacific, which consists of five PCB fabrication plants and 2) North America, which consists of seven domestic PCB fabrication plants, including a facility that provides follow-on value-added services primarily for one of the PCB fabrication plants,
and one backplane assembly plant in Shanghai, China, which is managed in conjunction with our U.S. operations. Each segment operates predominantly in the same industry with production facilities that produce customized products for their customers
and use similar means of product distribution.

[0001193125-15-170026:mdna:24]
The following table compares net sales by reportable segment
for the quarters ended March 30, 2015 and March 31, 2014:

[0001193125-15-170026:mdna:25]
|  |  | Quarter Ended |  |
|  |  | March 30,2015 |  |  | March 31,2014 |  |
|  |  | (In thousands) |  |
| Net Sales: |  |  |  |  |  |  |  |  |
| Asia Pacific |  | $ | 205,365 |  |  | $ | 165,666 |  |
| North America |  |  | 124,321 |  |  |  | 126,589 |  |
| Total sales |  |  | 329,686 |  |  |  | 292,255 |  |
| Inter-segment sales |  |  | (522 | ) |  |  | (360 | ) |
| Total net sales |  | $ | 329,164 |  |  | $ | 291,895 |  |

[0001193125-15-170026:mdna:26]
22

[0001193125-15-170026:mdna:27]
[same as prior period, unchanged from 0001193125-14-404493:mdna:31]

[0001193125-15-170026:mdna:28]
Net sales increased $37.3 million, or 12.8%, from $291.9 million for the first quarter of 2014 to $329.2 million for the
first quarter of 2015.

[0001193125-15-170026:mdna:29]
Net sales for the Asia Pacific operating segment, excluding inter-segment sales,
increased $39.5 million, or 23.9%, from $165.3 million in the first quarter of 2014 to $204.8 million in the first quarter of 2015. This increase is primarily due to higher demand in our Cellular Phone end market, partially offset with lower
demand in our Computing/Storage/Peripherals and Networking/Communications end markets, which resulted in a 24% increase in PCB shipments from the first quarter of 2014. Additionally, the average PCB selling price increased 10%, which was driven by
product mix shift.

[0001193125-15-170026:mdna:30]
Net sales for the North America operating segment decreased $2.3 million, or 1.8%, from
$126.6 million in the first quarter of 2014 to $124.3 million in the first quarter of 2015. This decrease was primarily due to lower demand in our Computing/Storage/Peripherals end market, partially offset with higher demand in our Aerospace/Defense
end market. This decrease in net sales was primarily the result of a 2% decrease in production. The average PCB selling price remained constant to that of the first quarter of 2014.

[0001193125-15-170026:mdna:31]
[same as prior period, unchanged from 0001193125-14-404493:mdna:34]

[0001193125-15-170026:mdna:32]
Gross margin increased from 13.2% for
the first quarter of 2014 to 15.7% for the first quarter of 2015.

[0001193125-15-170026:mdna:33]
Gross margin for the Asia Pacific segment
increased from 13.0% for the first quarter of 2014 to 15.9% for the first quarter of 2015, primarily due to higher utilization at our advanced technology plants.

[0001193125-15-170026:mdna:34]
Gross margin for the North America segment increased from 13.5% for the first quarter of 2014 to 15.3% for the first
quarter of 2015. While overall sales declined, gross margin improved primarily due to improved operating efficiencies at certain plants.

[0001193125-15-170026:mdna:35]
[same as prior period, unchanged from 0001193125-14-404493:mdna:37]

[0001193125-15-170026:mdna:36]
Selling and marketing expenses increased $0.2 million, from $9.3 million for the first quarter of 2014 to $9.5 million for the first quarter of 2015. As a percentage of net sales, selling and marketing
expenses were 3.2% for the first quarter of 2014, as compared to 2.9% for the first quarter of 2015. The decrease in selling and marketing expense as a percentage of net sales is primarily due to higher net sales.

[0001193125-15-170026:mdna:37]
General and Administrative Expenses

[0001193125-15-170026:mdna:38]
General and administrative expenses increased $12.0 million from $22.5 million, or 7.7% of net sales, for the first quarter of 2014 to $34.5 million, or 10.5% of net sales, for the first quarter of 2015.
The increase in expense primarily relates to $8.2 million of acquisition-related costs and higher indirect taxes at our Asia Pacific operating segment resulting from that segment’s improved operating performance.

[0001193125-15-170026:mdna:39]
[same as prior period, unchanged from 0001193125-14-404493:mdna:41]

[0001193125-15-170026:mdna:40]
Other expense, net decreased $3.9 million from $10.1 million for the first quarter of 2014 to $6.2 million for the first quarter of 2015. The decrease in other expense, net was primarily due to
significantly lower foreign currency transaction losses, which for the first quarter of 2014 amounted to $3.6 million due to the rapid depreciation of the Chinese RMB against the U.S. Dollar, and the absence of a $0.5 million loss on the
extinguishment of debt related to repurchase of a portion of convertible senior notes due 2015, also in the first quarter of 2014.

[0001193125-15-170026:mdna:41]
[same as prior period, unchanged from 0001193125-14-404493:mdna:44]

[0001193125-15-170026:mdna:42]
The benefit for income taxes decreased by $0.5 million from a $1.9 million tax benefit for the first quarter of 2014 to a $1.4 million tax benefit for the first quarter of 2015. The decrease in our
benefit for income taxes is primarily due to an increase in earnings in the first quarter of 2015 compared to the first quarter of 2014 and by a discrete tax benefit resulting from the retroactive approval of the high technology enterprise status
for certain subsidiaries in China within our Asia Pacific operating segment. Our effective tax rate is primarily impacted by the U.S. federal income tax rate, apportioned state income tax rates, favorable tax rates in China and Hong Kong, generation
of other credits and deductions available to us, and certain non-deductible items. Certain foreign losses generated are not more than likely to be realizable, and thus no income tax benefit has been recognized on these losses. Additionally, as of
March 30, 2015 and December 29, 2014, we had net deferred income tax assets of approximately $0.4 million and $2.9 million, respectively. Based on our forecast for future taxable earnings, we believe it is more likely than not that we will
utilize the deferred income tax assets in future periods.

[0001193125-15-170026:mdna:43]
[same as prior period, unchanged from 0001193125-14-404493:mdna:48]

[0001193125-15-170026:mdna:44]
Our principal sources of liquidity have been cash provided by operations, the issuance of convertible senior notes, and
term and revolving debt. Our principal uses of cash have been to finance capital expenditures, meet debt service requirements, fund working capital requirements, finance acquisitions, and refinance existing debt. We anticipate that financing
acquisitions, servicing debt, financing capital expenditures, and funding working capital requirements will continue to be the principal demands on our cash in the future.

[0001193125-15-170026:mdna:45]
As of March 30, 2015, we had net working capital of approximately $273.8 million compared to $302.1 million as of
December 29, 2014. The decrease in working capital is primarily attributable to a decrease in accounts receivable, somewhat offset by decreases in accounts payable, equipment payable, and accrued salaries. Cash flow provided by operating
activities during the first quarter of 2015 was $67.4 million as compared to $45.4 million in the same period in 2014. The improved cash flow was the result of stronger operational performance as well as the working capital changes mentioned
above.

[0001193125-15-170026:mdna:46]
As of March 30, 2015, we had cash and cash equivalents of approximately $283.0 million, of which
approximately $111.8 million was held by our foreign subsidiaries. Of the cash and cash equivalents held by our foreign subsidiaries as of March 30, 2015, $108.1 million was located in Asia and $3.7 million was located in Europe. Cash and
cash equivalents held by our Asia Pacific operating segment are expected to be used in local operations. Cash and cash equivalents held by our backplane assembly facility in Shanghai, China, as well as in Europe, which are managed in conjunction
with our U.S. operations, totaled approximately $17.1 million and are available for repatriation, and a deferred tax liability for U.S. income taxes on undistributed earnings has been recorded.

[0001193125-15-170026:mdna:47]
Our 2015 capital expenditure plan is expected to total approximately $100 million (of which approximately $80 million
relates to our Asia Pacific operating segment). The expenditures will fund capital equipment purchases to increase production capacity, especially for advanced technology manufacturing, comply with changing environmental regulations, replace aging
equipment, and expand our technological capabilities. While our cash capital expenditures are expected to be approximately $100 million in 2015, we expect new capital expenditure purchases in 2015 to approximate $70 million.

[0001193125-15-170026:mdna:48]
Credit Agreement and Chinese Revolver

[0001193125-15-170026:mdna:49]
We are party to a Credit Agreement consisting of a $370.0 million senior secured Term Loan, a $90.0 million senior secured
Revolving Loan and a secured $80.0 million Letters of Credit Facility. The Term Loan and Letters of Credit Facility will mature on September 14, 2016, and the Revolving Loan will mature on March 14, 2016. The Credit Agreement is secured by
substantially all of the assets of our Asia Pacific operating segment and is senior to all of our other debt, including the convertible senior notes. We have fully and unconditionally guaranteed the full and timely payment of all Credit Agreement
related obligations of our Asia Pacific operating segment.

[0001193125-15-170026:mdna:50]
Borrowings under the Credit Agreement bear
interest at a floating rate of LIBOR plus an interest margin of 2.38%. At March 30, 2015, the weighted average interest rate on the outstanding borrowings under the Credit Agreement was 2.56%.

[0001193125-15-170026:mdna:51]
Borrowings under the Credit Agreement are subject to certain financial and operating covenants that include maintaining
maximum total leverage ratios and minimum net worth, current ratio, and interest coverage ratios for both us and our Asia Pacific operating segment. In addition, our Credit Agreement includes a covenant that the Principal Shareholders (as defined in
the Shareholders Agreement dated April 9, 2010 as amended on September 14, 2012) will not reduce their shareholding below 15 percent of our issued shares. At March 30, 2015, we were in compliance with the covenants under the
Credit Agreement.

[0001193125-15-170026:mdna:52]
We are required to pay a commitment fee of 0.50% per annum on any unused portion of
the Revolving Loan and Letters of Credit Facility granted under the Credit Agreement. We incurred $0.2 million for the year ended March 30, 2015 in commitment fees. As of March 30, 2015, the outstanding amount of the Term Loan was $225.7
million, of which $96.2 million is due for repayment in September 2015 and March 2016 and is included as short-term debt, with the remaining $129.5 million included as long-term debt. None of the Revolving Loan associated with the Credit Agreement
was outstanding at March 30, 2015. Available borrowing capacity under the Revolving Loan was $90.0 million as of March 30, 2015.

[0001193125-15-170026:mdna:53]
We have an $80.0 million Letters of Credit Facility under the Credit Agreement, as mentioned above. As of March 30, 2015, letters of credit in the amount of $30.9 million were outstanding under our
Credit Agreement, and other standby letters of credit were outstanding in the amount of $4.3 million. The other outstanding standby letters of credit expire between December 31, 2015 and February 28, 2016.

[0001193125-15-170026:mdna:54]
We are party to a revolving loan credit facility with a lender in China. Under this arrangement, the lender has made
available to us approximately $37.0 million in unsecured borrowing with all terms of the borrowing to be negotiated at the time the Chinese Revolver is drawn upon. There are no commitment fees on the unused portion of the Chinese Revolver, and this
arrangement expires in December 2015. As of March 30, 2015, the Chinese Revolver had not been drawn upon.

[0001193125-15-170026:mdna:55]
Convertible Senior Notes due 2020

[0001193125-15-170026:mdna:56]
We issued 1.75% convertible senior notes due December 15, 2020, in a public offering for an aggregate principal
amount of $250.0 million. The convertible senior notes bear interest at a rate of 1.75% per annum. Interest is payable semiannually in arrears on June 15 and December 15 of each year. The convertible senior notes are senior unsecured
obligations and rank equally to our future unsecured senior indebtedness and senior in right of payment to any of our future subordinated indebtedness. Offering expenses are being amortized to interest expense over the term of the convertible senior
notes.

[0001193125-15-170026:mdna:57]
In connection with the issuance of the convertible senior notes due 2020 we entered into a convertible
note hedge and warrant transaction, with respect to our common stock. The convertible note hedge consists of our option to purchase up to 25.9 million common stock shares at a price of $9.64 per share. The hedge expires on December 15,
2020 and can only be executed upon the conversion of the above mentioned convertible senior notes due 2020. Additionally, we sold warrants to purchase 25.9 million shares of our common stock at a price of $14.26 per share. The warrants expire
ratably from March 2021 through January 2022. The 2020 Call Spread Transaction has no effect on the terms of the convertible senior notes due 2020 and reduces potential dilution by effectively increasing the conversion price of the convertible
senior notes due 2020 to $14.26 per share of our common stock.

[0001193125-15-170026:mdna:58]
Convertible Senior Notes due 2015

[0001193125-15-170026:mdna:59]
We issued 3.25% convertible senior notes due on May 15, 2015, in a public offering for an aggregate
principal amount of $175.0 million. On May 15, 2015, all outstanding principal in the amount of $32.4 million and accrued interest is due and payable. The convertible senior notes are senior unsecured obligations and rank equally to our future
unsecured senior indebtedness and senior in right of payment to any of our future subordinated indebtedness. Offering expenses are being amortized to interest expense over the term of the convertible senior notes.

[0001193125-15-170026:mdna:60]
Financing Commitment and Current Liquidity Needs

[0001193125-15-170026:mdna:61]
Concurrently with the execution of the Merger Agreement, we obtained a debt financing commitment in an aggregate amount of
$1,115 million in connection with financing the transactions contemplated by the Merger Agreement. Assuming consummation of the Merger, we currently intend to use approximately $1,030 million of the proceeds of such financing commitment, or
alternative financing arrangements, to finance the Merger, to refinance certain existing indebtedness of Viasystems, to refinance certain of our existing indebtedness, and to pay the fees and expenses incurred in connection with the Merger. We are
in the process of finalizing the specific financing arrangements.

[0001193125-15-170026:mdna:62]
Based on our current level of operations,
we believe that cash generated from operations, cash on hand and cash available from borrowings under our existing credit arrangements will be adequate to meet our currently anticipated capital expenditure, debt service, and working capital needs
for the next 12 months. However, assuming consummation of the Merger, we will enter into new borrowing arrangements to fund the Merger, fund our business operations, or refinance existing debt.

[0001193125-15-170026:mdna:63]
Prior to the Merger, our principal sources of liquidity have been cash provided by operations, the issuance of
convertible senior notes, and term and revolving debt. Following the Merger, we expect that our principal sources of liquidity will continue to be our existing cash and cash equivalents, cash flow from operations, as well as from funds available
from financing arrangements entered into in connection with the Merger. We expect that servicing debt, funding working capital requirements, financing capital expenditures, and financing acquisitions will continue to be the principal demands on our
cash.

[0001193125-15-170026:mdna:64]
[same as prior period, unchanged from 0001193125-14-404493:mdna:68]

[0001193125-15-170026:mdna:65]
The following table provides information on our contractual obligations as of March 30, 2015:

[0001193125-15-170026:mdna:66]
|  |  | Total |  |  | Less Than1 Year |  |  | 1 - 3 Years |  |  | 4 - 5 Years |  |  | After5 Years |  |
|  |  | (In thousands) |  |
| Contractual Obligations(1) |  |  |  |
| Long-term debt obligations |  | $ | 225,702 |  |  | $ | 96,202 |  |  | $ | 129,500 |  |  | $ | — |  |  | $ | — |  |
| Convertible debt obligations |  |  | 282,395 |  |  |  | 32,395 |  |  |  | — |  |  |  | — |  |  |  | 250,000 |  |
| Interest on debt obligations |  |  | 33,460 |  |  |  | 10,021 |  |  |  | 10,314 |  |  |  | 8,750 |  |  |  | 4,375 |  |
| Foreign currency forward contract liabilities |  |  | 3,552 |  |  |  | 3,552 |  |  |  | — |  |  |  | — |  |  |  | — |  |
| Equipment payables |  |  | 39,059 |  |  |  | 39,059 |  |  |  | — |  |  |  | — |  |  |  | — |  |
| Purchase obligations |  |  | 15,347 |  |  |  | 14,476 |  |  |  | 871 |  |  |  | — |  |  |  | — |  |
| Operating lease commitments |  |  | 5,746 |  |  |  | 2,585 |  |  |  | 2,227 |  |  |  | 888 |  |  |  | 46 |  |
| Total contractual obligations |  | $ | 605,261 |  |  | $ | 198,290 |  |  | $ | 142,912 |  |  | $ | 9,638 |  |  | $ | 254,421 |  |

[0001193125-15-170026:mdna:67]
| (1) | Unrecognized uncertain tax benefits of $1.2 million are not included in the table above as we have not determined when the amount will be paid. |

[0001193125-15-170026:mdna:68]
[same as prior period, unchanged from 0001193125-14-404493:mdna:72]

[0001193125-15-170026:mdna:69]
[same as prior period, unchanged from 0001193125-14-404493:mdna:73]

[0001193125-15-170026:mdna:70]
[same as prior period, unchanged from 0001193125-14-404493:mdna:74]

[0001193125-15-170026:mdna:71]
Our Asia Pacific operating segment experiences revenue fluctuations, caused in part by seasonal patterns in the cellular phone and touchscreen tablet industries, which together have become a significant
portion of the end markets that we serve. This seasonality typically results in higher net sales in the third and fourth quarters due to end customer demand in the fourth quarter for consumer electronics products. Seasonal fluctuations also include
the Chinese New Year holidays in the first quarter, which typically results in lower net sales. We attribute this decline to shutdowns of our customers’ manufacturing facilities surrounding the Chinese New Year public holidays, which normally
occur in January or February of each year.
