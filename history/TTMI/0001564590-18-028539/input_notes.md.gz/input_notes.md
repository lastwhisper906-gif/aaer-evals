# TTMI notes — 0001564590-18-028539


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0001564590-18-028539:notes:1]
[same as prior period, unchanged from 0001564590-18-020718:notes:1]

[0001564590-18-028539:notes:2]
TTM Technologies, Inc. (the Company or TTM) is a leading global printed circuit board (PCB) manufacturer, focusing on quick-turn and volume production of technologically complex PCBs, backplane assemblies and electro-mechanical solutions (E-M Solutions) as well as a global designer and manufacturer of RF and microwave components and assemblies. The Company provides time-to-market and volume production of advanced technology products and offers a one-stop manufacturing solution to customers from engineering support to prototype development through final mass production. This one-stop manufacturing solution enables the Company to align technology developments with the diverse needs of the Company’s customers and to enable them to reduce the time required to develop new products and bring them to market.

[0001564590-18-028539:notes:3]
[same as prior period, unchanged from 0001564590-18-020718:notes:3]

[0001564590-18-028539:notes:4]
[same as prior period, unchanged from 0001564590-18-020718:notes:4]

[0001564590-18-028539:notes:5]
[same as prior period, unchanged from 0001564590-18-020718:notes:5]

[0001564590-18-028539:notes:6]
In May 2014, the Financial Accounting Standards Board (FASB) issued Accounting Standards Update (ASU) 2014-09, Revenue from Contracts with Customers (Topic 606), which replaces most existing revenue recognition guidance in U.S. GAAP, including industry specific requirements, and provides companies with a single revenue recognition model for recognizing revenue of contracts with customers. The core principle of the new revenue standard is that a company should recognize revenue to depict the transfer of promised goods or services to customers in an amount that reflects the consideration to which the company expects to be entitled in exchange for those goods or services.

[0001564590-18-028539:notes:7]
The Company assessed the new guidance and adopted the new revenue standard on January 2, 2018, which resulted in a change to the timing of revenue recognition for certain of the Company’s revenue streams from “point in time” upon physical delivery to an “over time” model. Additionally, the Company elected the cumulative effect transition method with adjustment to the opening balance of retained earnings at January 2, 2018 for all open contracts as of January 1, 2018. Therefore, comparative information has not been adjusted and continues to be reported under previous U.S. GAAP guidance for the consolidated balance sheet at January 1, 2018 and the consolidated condensed statement of operations for the quarter and three quarters ended October 2, 2017.

[0001564590-18-028539:notes:8]
[same as prior period, unchanged from 0001564590-18-020718:notes:8]

[0001564590-18-028539:notes:9]
[same as prior period, unchanged from 0001564590-18-020718:notes:9]

[0001564590-18-028539:notes:10]
[same as prior period, unchanged from 0001564590-18-020718:notes:10]

[0001564590-18-028539:notes:11]
Additionally, the disclosure below summarizes the impact of the adoption of the new revenue standard on the Company’s consolidated condensed balance sheet as of October 1, 2018, statement of operations for the quarter and three quarters ended October 1, 2018 and statement of cash flows for the three quarters ended October 1, 2018 for which the As Reported reflects the new revenue standard and Balances without New Revenue Standard Adjustment reflects the Company’s replaced revenue recognition policy of “point in time” and upon physical delivery, for certain revenue streams, as appropriate.

[0001564590-18-028539:notes:12]
|  |  | October 1, 2018 |  |
|  |  | As reported |  |  | Effect of Change Increase (Decrease) |  |  | Balances without New Revenue Standard Adjustment |  |
|  |  | (In thousands) |  |
| Balance Sheet |  |  |  |  |  |  |  |  |  |  |  |  |
| Assets |  |  |  |  |  |  |  |  |  |  |  |  |
| Accounts receivable, net |  | $ | 569,215 |  |  | $ | 8,171 |  |  | $ | 561,044 |  |
| Contract assets |  |  | 296,836 |  |  |  | 288,723 |  |  |  | 8,113 |  |
| Inventories |  |  | 122,232 |  |  |  | (241,839 | ) |  |  | 364,071 |  |
| Liabilities |  |  |  |  |  |  |  |  |  |  |  |  |
| Other accrued expenses |  |  | 112,005 |  |  |  | 13,945 |  |  |  | 98,060 |  |
| Other long-term liabilities |  |  | 100,724 |  |  |  | 3,163 |  |  |  | 97,561 |  |
| Equity |  |  |  |  |  |  |  |  |  |  |  |  |
| Retained earnings |  |  | 343,177 |  |  |  | 37,947 |  |  |  | 305,230 |  |

[0001564590-18-028539:notes:13]
|  |  | Quarter ended October 1, 2018 |  |  | Three quarters ended October 1, 2018 |  |
|  |  | As reported |  |  | Effect of Change Increase (Decrease) |  |  | Balances without New Revenue Standard Adjustment |  |  | As reported |  |  | Effect of Change Increase |  |  | Balances without New Revenue Standard Adjustment |  |
|  |  | (In thousands) |  |  | (In thousands) |  |
| Net sales |  | $ | 755,837 |  |  | $ | (4,303 | ) |  | $ | 760,140 |  |  | $ | 2,136,306 |  |  | $ | 27,508 |  |  | $ | 2,108,798 |  |
| Cost of goods sold |  |  | 626,253 |  |  |  | (4,056 | ) |  |  | 630,309 |  |  |  | 1,801,904 |  |  |  | 18,263 |  |  |  | 1,783,641 |  |
| Gross profit |  |  | 129,584 |  |  |  | (247 | ) |  |  | 129,831 |  |  |  | 334,402 |  |  |  | 9,245 |  |  |  | 325,157 |  |
| Net income |  |  | 27,001 |  |  |  | (247 | ) |  |  | 27,248 |  |  |  | 121,102 |  |  |  | 9,373 |  |  |  | 111,729 |  |

[0001564590-18-028539:notes:14]
Included in the Effect of Change Increase (Decrease) columns for the three quarters ended October 1, 2018 are $14,408, $11,375 and $3,033 of net sales, cost of goods sold and gross profit, respectively, related to the opening balance sheet of Anaren Inc. which was acquired on April 18, 2018 (See Note 3), and not to the activity during the three quarters of 2018.

[0001564590-18-028539:notes:15]
|  |  | Three Quarters ended October 1, 2018 |  |
|  |  | As reported |  |  | Effect of Change Increase (Decrease) |  |  | Balances without New Revenue Standard Adjustment |  |
|  |  | (In thousands) |  |
| Cash flows from operating activities: |  |  |  |  |  |  |  |  |  |  |  |  |
| Net income |  | $ | 121,102 |  |  | $ | 9,373 |  |  | $ | 111,729 |  |
| Adjustments to reconcile net income to net cash used in operating activities: |  |  |  |  |  |  |  |  |  |  |  |  |
| Deferred income taxes |  |  | (64,516 | ) |  |  | (128 | ) |  |  | (64,388 | ) |
| Changes in operating assets and liabilities: |  |  |  |  |  |  |  |  |  |  |  |  |
| Accounts receivable, net |  |  | (44,685 | ) |  |  | — |  |  |  | (44,685 | ) |
| Contract assets |  |  | (12,597 | ) |  |  | (28,069 | ) |  |  | 15,472 |  |
| Inventories |  |  | 5,399 |  |  |  | 18,263 |  |  |  | (12,864 | ) |
| Accrued salaries, wages and benefits and other accrued expenses |  |  | (43,758 | ) |  |  | 561 |  |  |  | (44,319 | ) |

[0001564590-18-028539:notes:16]
In August 2017, the FASB issued ASU 2017-12, Derivatives and Hedging (Topic 815): Targeted Improvements to Accounting for Hedging Activities. This ASU amends and simplifies existing guidance in order to allow companies to more accurately present the economic effects of risk management activities in the financial statements. ASU 2017-12 also amends the guidance surrounding the recognition of the value of hedged instruments to include the entire change in value, rather than just the effective portion, in other comprehensive income and recognized in earnings at the same time that the hedged item affects earnings for cash flow and net investment hedges. This ASU is effective for fiscal years beginning after December 15, 2018, including interim periods within those fiscal years. Early adoption is permitted. The adoption of this standard is not expected to have a material impact on the consolidated financial statements or related disclosures.

[0001564590-18-028539:notes:17]
In February 2016, the FASB issued ASU 2016-02, Leases (Topic 842). The objective of this update is to increase transparency and comparability among organizations by recognizing lease assets and lease liabilities on the balance sheet and disclosing key information about leasing arrangements. This ASU is effective for fiscal years beginning after December 15, 2018, including interim periods within those annual periods. The FASB also provided a practical expedient transition method to adopt the new lease requirements by allowing entities to initially apply requirements by recognizing a cumulative-effect adjustment to the opening balance of retained earnings in the period of adoption that would enable the Company to not provide comparative period financial statements. Instead, the Company would apply the transition provisions of the lease standard at its effective date. The Company is planning  on electing the practical expedient transition method as well as the package of practical expedients to not reassess prior conclusions related to contracts containing leases, lease classification and initial direct costs, and is evaluating other practical expedients available under the guidance. The Company expects the impact of adopting this new accounting standard to be material to its consolidated balance sheet, but is still evaluating the impact to its consolidated statement of income.


## us-gaap:SignificantAccountingPoliciesTextBlock

[0001564590-18-028539:notes:18]
[same as prior period, unchanged from 0001564590-18-020718:notes:18]

[0001564590-18-028539:notes:19]
[same as prior period, unchanged from 0001564590-18-020718:notes:19]

[0001564590-18-028539:notes:20]
The Company derives revenues primarily from the sale of PCBs, custom electronic assemblies using customer-supplied engineering and design plans as well as the design and manufacture of RF and microwave components and assemblies.

[0001564590-18-028539:notes:21]
For the PCBs and custom electronic assemblies, orders for products generally correspond to the production schedules of the Company’s customers and are supported with firm purchase orders. The Company’s customers have continuous control of the work in progress and finished goods throughout the PCB manufacturing process, as PCBs are built to customer specifications and do not have an alternative use. The customer typically controls the work in progress and finished goods as evidenced either by contractual termination clauses or by the Company’s rights to payment for work performed to date, plus a reasonable profit.  As a result, the Company records revenue in accordance with the “over time” revenue standard as discussed in Note 1 Nature of Operations and Basis of Presentation ─ Recently Adopted and Issued Accounting Standards, beginning in the first quarter of 2018, the Company now recognizes revenue progressively over time based on the extent of progress towards completion of the performance obligation.

[0001564590-18-028539:notes:22]
[same as prior period, unchanged from 0001564590-18-020718:notes:23]

[0001564590-18-028539:notes:23]
[same as prior period, unchanged from 0001564590-18-020718:notes:24]

[0001564590-18-028539:notes:24]
[same as prior period, unchanged from 0001564590-18-020718:notes:25]

[0001564590-18-028539:notes:25]
The Company provides customers a limited right of return for defective PCBs including components and subsystems, and assemblies. The Company accrues an estimate for sales returns and allowances progressively over time based on the extent of progress towards completion of the performance obligation using the Company’s judgment based on historical results and anticipated returns.  To the extent actual experience varies from its historical experience, revisions to the sales returns and allowances accrual may be required. Sales returns and allowances are recorded as a reduction of revenue and included as a component of accrued liabilities on the condensed consolidated balance sheet.


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001564590-18-028539:notes:26]
[same as prior period, unchanged from 0001564590-18-020718:notes:27]

[0001564590-18-028539:notes:27]
On April 18, 2018, the Company completed its acquisition of all issued and outstanding common stock of Anaren Holding Corp. for a total consideration of $787,911, subject to customary working capital and certain other adjustments. Other than the equity interests of Anaren, Inc. (Anaren), Anaren Holding Corp. had no material assets or liabilities and has no material independent operations. Anaren is a leading provider of mission-critical RF solutions, microelectronics, and microwave components and assemblies for the wireless infrastructure and aerospace and defense electronics markets.

[0001564590-18-028539:notes:28]
For the quarter and three quarters ended October 1, 2018, bank fees and legal, accounting, and other professional service costs associated with the acquisition of $312 and $11,137, respectively, have been expensed and recorded as general and administrative expense in the consolidated condensed financial statements. There were no bank fees or legal, accounting, or other professional service costs associated with the acquisition for the quarter and three quarters ended October 2, 2017.

[0001564590-18-028539:notes:29]
[same as prior period, unchanged from 0001564590-18-020718:notes:30]

[0001564590-18-028539:notes:30]
[same as prior period, unchanged from 0001564590-18-020718:notes:31]

[0001564590-18-028539:notes:31]
[same as prior period, unchanged from 0001564590-18-020718:notes:32]

[0001564590-18-028539:notes:32]
[same as prior period, unchanged from 0001564590-18-020718:notes:33]

[0001564590-18-028539:notes:33]
[same as prior period, unchanged from 0001564590-18-020718:notes:34]

[0001564590-18-028539:notes:34]
|  |  | (In thousands) |  |
| Cash |  | $ | 12,911 |  |
| Trade and notes receivables |  |  | 32,457 |  |
| Contract assets |  |  | 23,585 |  |
| Inventories |  |  | 56,619 |  |
| Other current assets |  |  | 1,373 |  |
| Property, plant and equipment |  |  | 45,115 |  |
| Identifiable intangible assets |  |  | 336,000 |  |
| Other assets |  |  | 300 |  |
| Goodwill |  |  | 393,296 |  |
| Trade accounts payable |  |  | (14,623 | ) |
| Contract liabilities |  |  | (7,778 | ) |
| Other current liabilities |  |  | (7,643 | ) |
| Long-term debt |  |  | (178,604 | ) |
| Non-current deferred tax liabilities |  |  | (75,265 | ) |
| Other liabilities |  |  | (8,436 | ) |
| Total |  | $ | 609,307 |  |

[0001564590-18-028539:notes:35]
The Company’s fair value estimates for the purchase price allocation are preliminary and may change during the allowable measurement period, which is up to the point the Company obtains and analyzes the information that existed as of the date of the acquisition necessary to determine the fair values of the assets acquired and liabilities assumed, but in no case to exceed more than one year from the date of acquisition. As of October 1, 2018, the Company had not finalized the determination of fair values allocated to various assets and liabilities, including, but not limited to, deferred taxes, goodwill, tax uncertainties, income taxes payable and assumed liabilities. Any changes in the fair values of the assets acquired and liabilities assumed during the measurement period may result in material adjustments to goodwill.

[0001564590-18-028539:notes:36]
[same as prior period, unchanged from 0001564590-18-020718:notes:37]

[0001564590-18-028539:notes:37]
The Company acquired $56,619 of inventories as a result of the acquisition. Finished goods were preliminarily valued at estimated selling prices less costs of disposal and a reasonable profit for the selling effort. Work-in-process inventory was valued at estimated selling prices less costs to complete, costs of disposal and a reasonable profit allowance for the completion and selling effort. Raw materials were preliminarily valued at estimated replacement cost.

[0001564590-18-028539:notes:38]
[same as prior period, unchanged from 0001564590-18-020718:notes:39]

[0001564590-18-028539:notes:39]
[same as prior period, unchanged from 0001564590-18-020718:notes:40]

[0001564590-18-028539:notes:40]
[same as prior period, unchanged from 0001564590-18-020718:notes:41]

[0001564590-18-028539:notes:41]
[same as prior period, unchanged from 0001564590-18-020718:notes:42]

[0001564590-18-028539:notes:42]
|  |  | Estimated fair value |  |  | Weighted- average amortization period |
|  |  | (In thousands) |  |  |  |
| Customer relationships |  | $ | 267,500 |  |  | 12.2 years |
| Developed technology |  |  | 39,500 |  |  | 9.4 years |
| Backlog |  |  | 29,000 |  |  | 0.9 years |
|  |  | $ | 336,000 |  |  |  |

[0001564590-18-028539:notes:43]
[same as prior period, unchanged from 0001564590-18-020718:notes:44]

[0001564590-18-028539:notes:44]
Goodwill represents the excess of the purchase price over the fair value of assets acquired and liabilities assumed.

[0001564590-18-028539:notes:45]
During the quarter ended October 1, 2018, goodwill was adjusted to reflect a decrease of $2,214 in property, plant and equipment, a decrease of $1,000 in identifiable intangible assets and a net increase of $3,804 to liabilities due to additional information received regarding the valuation of certain property acquired, identifiable intangible assets, and others, respectively.

[0001564590-18-028539:notes:46]
The Company has two reportable segments: PCB and E-M Solutions and has integrated Anaren into the PCB reportable segment. The excess purchase price over the fair value of assets acquired and liabilities assumed has been completely allocated to the PCB reportable segment.

[0001564590-18-028539:notes:47]
[same as prior period, unchanged from 0001564590-18-020718:notes:46]

[0001564590-18-028539:notes:48]
[same as prior period, unchanged from 0001564590-18-020718:notes:47]

[0001564590-18-028539:notes:49]
[same as prior period, unchanged from 0001564590-18-020718:notes:48]

[0001564590-18-028539:notes:50]
[same as prior period, unchanged from 0001564590-18-020718:notes:49]

[0001564590-18-028539:notes:51]
[same as prior period, unchanged from 0001564590-18-020718:notes:50]

[0001564590-18-028539:notes:52]
[same as prior period, unchanged from 0001564590-18-020718:notes:51]

[0001564590-18-028539:notes:53]
[same as prior period, unchanged from 0001564590-18-020718:notes:52]

[0001564590-18-028539:notes:54]
Included in the consolidated condensed statements of operations are net sales of $64,129 and $126,140, excluding intercompany sales, for the quarter and three quarters ended October 1, 2018, respectively. Pre-tax net income included in the consolidated condensed statements of operations from the Anaren operations for the quarter and three quarters ended October 1, 2018 have not been reported as it is impracticable to do so given the integration and other efficiency and cost saving measures in process during the third quarter ended October 1, 2018.

[0001564590-18-028539:notes:55]
[same as prior period, unchanged from 0001564590-18-020718:notes:54]

[0001564590-18-028539:notes:56]
[same as prior period, unchanged from 0001564590-18-020718:notes:55]

[0001564590-18-028539:notes:57]
[same as prior period, unchanged from 0001564590-18-020718:notes:56]

[0001564590-18-028539:notes:58]
|  |  | Quarter Ended |  |  | Three Quarters Ended |  |
|  |  | October 1, |  |  | October 2, |  |  | October 1, |  |  | October 2, |  |
|  |  | 2018 |  |  | 2017 |  |  | 2018 |  |  | 2017 |  |
|  |  | (In thousands) |  |  | (In thousands) |  |
| Net sales |  | $ | 755,837 |  |  | $ | 724,463 |  |  | $ | 2,204,980 |  |  | $ | 2,093,982 |  |
| Net income attributable to TTM Technologies, Inc. stockholders |  |  | 27,001 |  |  |  | 21,992 |  |  |  | 134,608 |  |  |  | 70,021 |  |
| Basic earnings per share |  | $ | 0.26 |  |  | $ | 0.22 |  |  | $ | 1.30 |  |  | $ | 0.69 |  |
| Dilutive earnings per share |  | $ | 0.22 |  |  | $ | 0.19 |  |  | $ | 1.08 |  |  | $ | 0.61 |  |


## ttmi:ContractWithCustomerAssetLiabilitiesTextBlock

[0001564590-18-028539:notes:59]
[same as prior period, unchanged from 0001564590-18-020718:notes:58]

[0001564590-18-028539:notes:60]
A contract asset is recognized when the Company has recognized revenue, but not issued an invoice for payment.  Contract assets are classified as current assets and transferred to receivables when the entitlement to payment becomes unconditional. The Company’s contract assets are generally converted to trade account receivables within 90 days, at which time the Company is entitled to payment of the fixed price upon delivery of the finished product subject to customer payment terms. Contract assets were $296,836 as of October 1, 2018 and represent unbilled amounts for work performed to date, plus a reasonable profit. There were no contract assets as of January 1, 2018.

[0001564590-18-028539:notes:61]
A contract liability is recognized when the Company has received payment in advance for the future transfer of goods or services. The Company’s contract liabilities are generally converted to revenue within 90 days. Contract liabilities were $5,025 as of October 1, 2018 and represent customer advances for work yet to be performed, plus a reasonable profit. There were no contract liabilities as of January 1, 2018.


## us-gaap:InventoryDisclosureTextBlock

[0001564590-18-028539:notes:62]
[same as prior period, unchanged from 0001564590-18-020718:notes:61]

[0001564590-18-028539:notes:63]
Inventories as of October 1, 2018 and January 1, 2018 consisted of the following:

[0001564590-18-028539:notes:64]
|  |  | As of |  |
|  |  | October 1, 2018 |  |  | January 1, 2018 |  |
|  |  | (in thousands) |  |
| Inventories: |  |  |  |  |  |  |  |  |
| Raw materials |  | $ | 107,912 |  |  | $ | 75,835 |  |
| Work-in-process |  |  | 11,604 |  |  |  | 120,031 |  |
| Finished goods |  |  | 2,716 |  |  |  | 98,722 |  |
|  |  | $ | 122,232 |  |  | $ | 294,588 |  |


## us-gaap:GoodwillDisclosureTextBlock

[0001564590-18-028539:notes:65]
[same as prior period, unchanged from 0001564590-18-020718:notes:64]

[0001564590-18-028539:notes:66]
As of October 1, 2018 and January 1, 2018, goodwill was as follows:

[0001564590-18-028539:notes:67]
|  |  | Total |  |
|  |  | (In thousands) |  |
| Balance as of January 1, 2018 |  |  |  |  |
| Goodwill |  | $ | 543,971 |  |
| Accumulated impairment losses |  |  | (171,400 | ) |
|  |  |  | 372,571 |  |
| Goodwill recognized during the three quarters ended October 1, 2018 |  |  | 393,296 |  |
| Balance as of October 1, 2018 |  |  |  |  |
| Goodwill |  |  | 937,267 |  |
| Accumulated impairment losses |  |  | (171,400 | ) |
|  |  | $ | 765,867 |  |

[0001564590-18-028539:notes:68]
All goodwill related to the Company’s PCB reportable segment.

[0001564590-18-028539:notes:69]
[same as prior period, unchanged from 0001564590-18-020718:notes:67]


## us-gaap:IntangibleAssetsDisclosureTextBlock

[0001564590-18-028539:notes:70]
[same as prior period, unchanged from 0001564590-18-020718:notes:68]

[0001564590-18-028539:notes:71]
As of October 1, 2018 and January 1, 2018, the components of definite-lived intangibles were as follows:

[0001564590-18-028539:notes:72]
|  |  | Gross Amount |  |  | Accumulated Amortization |  |  | Foreign Currency Translation Adjustment |  |  | Net Carrying Amount |  | Weighted Average Amortization Period |  |
|  |  | (In thousands) |  | (years) |  |
| October 1, 2018 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Customer relationships |  | $ | 203,634 |  |  | $ | (117,913 | ) |  | $ | — |  |  | $ | 85,721 |  |  | 8.1 |  |
| Technology |  |  | 3,000 |  |  |  | (3,000 | ) |  |  | — |  |  |  | — |  |  | 3 |  |
| Acquired intangibles from acquisition |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Customer relationships |  |  | 267,500 |  |  |  | (10,073 | ) |  |  | — |  |  |  | 257,427 |  |  | 12.2 |  |
| Developed technology |  |  | 39,500 |  |  |  | (2,165 | ) |  |  | — |  |  |  | 37,335 |  |  | 9.4 |  |
| Backlog |  |  | 29,000 |  |  |  | (14,658 | ) |  |  | — |  |  |  | 14,342 |  |  | 0.9 |  |
|  |  | $ | 542,634 |  |  | $ | (147,809 | ) |  | $ | — |  |  | $ | 394,825 |  |  |  |  |
| January 1, 2018: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Customer relationships |  | $ | 203,563 |  |  | $ | (101,089 | ) |  | $ | 72 |  |  | $ | 102,546 |  |  | 8.1 |  |
| Technology |  |  | 3,000 |  |  |  | (2,596 | ) |  |  | — |  |  |  | 404 |  |  | 3 |  |
|  |  | $ | 206,563 |  |  | $ | (103,685 | ) |  | $ | 72 |  |  | $ | 102,950 |  |  |  |  |

[0001564590-18-028539:notes:73]
[same as prior period, unchanged from 0001564590-18-020718:notes:71]

[0001564590-18-028539:notes:74]
Definite-lived intangibles are generally amortized using the straight line method of amortization over the estimated useful life, with the exception of certain customer relationship intangibles, which are amortized using an accelerated method of amortization based on estimated cash flows. Amortization expense was $18,774 and $5,905 for the quarters ended October 1, 2018 and October 2, 2017, respectively, and $44,124 and $17,727 for the three quarters ended October 1, 2018 and October 2, 2017, respectively.

[0001564590-18-028539:notes:75]
[same as prior period, unchanged from 0001564590-18-020718:notes:73]

[0001564590-18-028539:notes:76]
|  |  | (In thousands) |  |
| Remaining 2018 |  | $ | 18,927 |  |
| 2019 |  |  | 53,136 |  |
| 2020 |  |  | 45,419 |  |
| 2021 |  |  | 42,108 |  |
| 2022 |  |  | 39,002 |  |
| Thereafter |  |  | 196,233 |  |
|  |  | $ | 394,825 |  |


## us-gaap:LongTermDebtTextBlock

[0001564590-18-028539:notes:77]
(8) Long-term Debt and Letters of Credit

[0001564590-18-028539:notes:78]
The following table summarizes the long-term debt of the Company as of October 1, 2018 and January 1, 2018:

[0001564590-18-028539:notes:79]
|  |  | Interest Rate as of October 1, 2018 |  |  | Principal Outstanding as of October 1, 2018 |  |  | Interest Rate as of January 1, 2018 |  |  | Principal Outstanding as of January 1, 2018 |  |
|  |  | (In thousands) |  |
| Term Loan due September 2024 |  | 4.77% |  |  | $ | 905,879 |  |  | 4.06% |  |  | $ | 349,125 |  |
| Senior Notes due October 2025 |  | 5.63% |  |  |  | 375,000 |  |  | 5.63% |  |  |  | 375,000 |  |
| Convertible Senior Notes due December 2020 |  | 1.75% |  |  |  | 249,985 |  |  | 1.75% |  |  |  | 249,985 |  |
| U.S. ABL Revolving Loan due May 2020 |  | 3.77% |  |  |  | 40,000 |  |  | 3.06% |  |  |  | 17,000 |  |
| Asia ABL Revolving Loan due May 2020 |  | 3.67% |  |  |  | 30,000 |  |  | 2.96% |  |  |  | 30,000 |  |
| Capital Lease |  |  | — |  |  |  | — |  |  | 6.43% |  |  |  | 1,919 |  |
|  |  |  |  |  |  |  | 1,600,864 |  |  |  |  |  |  |  | 1,023,029 |  |
| Less: Long-term debt unamortized discount |  |  |  |  |  |  | (24,823 | ) |  |  |  |  |  |  | (30,513 | ) |
| Long-term debt unamortized debt issuance costs |  |  |  |  |  |  | (17,726 | ) |  |  |  |  |  |  | (12,459 | ) |
|  |  |  |  |  |  |  | 1,558,315 |  |  |  |  |  |  |  | 980,057 |  |
| Less: current maturities |  |  |  |  |  |  | (40,000 | ) |  |  |  |  |  |  | (4,578 | ) |
| Long-term debt, less current maturities |  |  |  |  |  | $ | 1,518,315 |  |  |  |  |  |  | $ | 975,479 |  |

[0001564590-18-028539:notes:80]
Term Loan Facility

[0001564590-18-028539:notes:81]
On April 18, 2018, the Company closed its $600,000 commitment of incremental loans concurrent with the completion of its acquisition of Anaren. At issuance, these incremental loans increased the Company’s existing balance of its Term Loan Facility due 2024 from $348,250 to $948,250. The Term Loan Facility had an outstanding balance of $905,879 as of October 1, 2018, of which $40,000 is included in short-term debt and $865,879 is included in long-term debt. The Term Loan Facility was issued at a weighted average discount of 99.7% and bears interest, at the Company’s option, at a floating rate of LIBOR, plus an applicable interest margin of 2.50%, or an alternate base rate, (defined as the greater of the JP Morgan prime, the New York Fed bank rate plus 0.5% or LIBOR plus 1.0%), subject to a 1.0% floor plus an applicable margin of 1.5%. At October 1, 2018 the interest rate on the outstanding borrowings under the Term Loan Facility was 4.77%. There is no provision, other than an event of default, for the interest margin to increase. The Term Loan Facility will mature on September 28, 2024. The Term Loan Facility is secured by a significant amount of the domestic assets of the Company and a pledge of 65% of voting stock of the Company’s first tier foreign subsidiaries and is structurally senior to the Company’s Senior Notes and Convertible Senior Notes. See Senior Notes and Convertible Senior Notes below.

[0001564590-18-028539:notes:82]
Subsequent to October 1, 2018, the Company made an optional debt principal prepayment of $40,000. As a result of the principal prepayments, the Company is no longer required to make any quarterly scheduled payments. However, based on certain parameters defined in the Term Loan Facility, including a First Lien Leverage Ratio, the Company may be required to make an additional principal payment on an annual basis beginning after fiscal year 2018. Any remaining outstanding balance under the Term Loan Facility is due at the maturity date of September 28, 2024.

[0001564590-18-028539:notes:83]
Borrowings under the Term Loan Facility are subject to certain affirmative and negative covenants, including limitations on indebtedness, corporate transactions, investments and dispositions, and share payments.

[0001564590-18-028539:notes:84]
Senior Notes

[0001564590-18-028539:notes:85]
The $375,000 of Senior Notes, which is included in long-term debt, bear interest at a rate of 5.63% per annum. Interest is payable semiannually in arrears on April 1 and October 1 of each year beginning April 1, 2018. The Senior Notes will mature on October 1, 2025.

[0001564590-18-028539:notes:86]
Borrowings under the Senior Notes are subject to certain affirmative and negative covenants, including limitations on indebtedness, corporate transactions, investments, dispositions, and share payments.

[0001564590-18-028539:notes:87]
Convertible Senior Notes due 2020

[0001564590-18-028539:notes:88]
The Company maintains 1.75% convertible senior notes in the amount of $249,985 due December 15, 2020. The convertible senior notes bear interest at a rate of 1.75% per annum. Interest is payable semiannually in arrears on June 15 and December 15 of each year. The convertible senior notes are senior unsecured obligations and rank equally to the Company’s future unsecured senior indebtedness and are senior in right of payment to any of the Company’s future subordinated indebtedness.

[0001564590-18-028539:notes:89]
As of October 1, 2018 and January 1, 2018, the following summarizes the equity components of the convertible senior notes included in additional paid-in capital:

[0001564590-18-028539:notes:90]
|  |  | As of October 1, 2018 and January 1, 2018 |  |
|  |  | Embedded conversion option — Convertible Senior Notes |  |  | Embedded conversion option — Convertible Senior Notes Issuance Costs |  |  | Total |  |
|  |  | (in thousands) |  |
| Convertible Senior Notes due 2020 |  | $ | 60,216 |  |  | $ | (1,916 | ) |  | $ | 58,300 |  |

[0001564590-18-028539:notes:91]
The components of interest expense resulting from the convertible senior notes for the quarters and three quarters ended October 1, 2018 and October 2, 2017 are as follows:

[0001564590-18-028539:notes:92]
|  |  | Quarter Ended |  |  | Three Quarters Ended |  |
|  |  | October 1, |  |  | October 2, |  |  | October 1, |  |  | October 2, |  |
|  |  | 2018 |  |  | 2017 |  |  | 2018 |  |  | 2017 |  |
|  |  | (In thousands) |  |  | (In thousands) |  |
| Contractual coupon interest |  | $ | 1,094 |  |  | $ | 1,094 |  |  | $ | 3,281 |  |  | $ | 3,281 |  |
| Amortization of debt discount |  | $ | 2,303 |  |  | $ | 2,159 |  |  | $ | 6,800 |  |  | $ | 6,376 |  |
| Amortization of debt issuance costs |  | $ | 231 |  |  | $ | 216 |  |  | $ | 682 |  |  | $ | 639 |  |

[0001564590-18-028539:notes:93]
Asset-Based Lending Agreements

[0001564590-18-028539:notes:94]
The Company maintains a $200,000 U.S. Asset-Based Lending Credit Agreement (U.S. ABL), and a $150,000 Asia Asset-Based Lending Credit Agreement (Asia ABL) (collectively the ABL Revolving Loans).

[0001564590-18-028539:notes:95]
The U.S. ABL consists of three tranches comprised of a revolving credit facility for up to $200,000, a letter of credit facility for up to $50,000, and swingline loans for up to $30,000, provided that at no time may amounts outstanding under the tranches exceed in aggregate $200,000 or the applicable borrowing base, which is a percentage of the principal amount of Eligible Accounts, as defined in the U.S. ABL agreement. Borrowings under the U.S. ABL bear interest at either a floating rate of LIBOR plus a margin of 150 basis points or JP Morgan Chase Bank’s prime rate plus a margin of 50 basis points, at the Company’s option. At October 1, 2018, the interest rate on the outstanding borrowings under the U.S. ABL was 3.77%. The applicable margin can vary based on the remaining availability of the facility, from 125 to 175 basis points for LIBOR-based loans and from 25 to 75 basis points for JP Morgan Chase Bank’s prime rate-based loans. Other than availability and an event of default, there are no other provisions for the interest margin to increase. The U.S. ABL will mature on May 31, 2020. Loans made under the U.S. ABL are secured first by all of the Company’s domestic cash, receivables and certain inventories as well as by a second position against a significant amount of the domestic assets of the Company and a pledge of 65% of the voting stock of the Company’s first tier foreign subsidiaries and are structurally senior to the Company’s Senior Notes and Convertible Senior Notes. See Senior Notes and Convertible Senior Notes above. At October 1, 2018, $40,000 of the U.S. ABL was outstanding and classified as long-term debt, which is consistent with its maturity date.

[0001564590-18-028539:notes:96]
The Asia ABL consists of two tranches comprised of a revolving credit facility for up to $150,000 and a letter of credit facility for up to $100,000, provided that at no time may amounts outstanding under both tranches exceed in aggregate $150,000 or the applicable borrowing base, which is a percentage of the principal amount of Eligible Accounts, as defined in the Asia ABL agreement. Borrowings under the Asia ABL bear interest at a floating rate of LIBOR plus 140 basis points. At October 1, 2018, the interest rate on the outstanding borrowings under the Asia ABL was 3.67%. There is no provision, other than an event of default, for the interest margin to increase. The Asia ABL will mature on May 22, 2020. Loans made under the Asia ABL are secured by a portion of the Company’s Asia Pacific cash and receivables and are structurally senior to the Company’s domestic obligations, including the Senior Notes and Convertible Senior Notes. See Senior Notes and Convertible Senior Notes above. At October 1, 2018, $30,000 of the Asia ABL was outstanding and classified as long-term debt, which is consistent with its maturity date.

[0001564590-18-028539:notes:97]
The Company has up to $50,000 and $100,000 Letters of Credit Facilities under the U.S. ABL and the Asia ABL, respectively. As of October 1, 2018, letters of credit in the amount of $6,701 were outstanding under the U.S. ABL and $9,287 were outstanding under the Asia ABL with various expiration dates through December 2019. Available borrowing capacity under the U.S. ABL and the Asia ABL was $153,299 and $110,713, respectively, which considers letters of credit outstanding at October 1, 2018.

[0001564590-18-028539:notes:98]
The Company is required to pay a commitment fee of 0.25% to 0.375% per annum on any unused portion of the U.S. ABL or Asia ABL. The Company incurred total commitment fees related to unused borrowing availability of $251 and $179 for the quarters ended October 1, 2018 and October 2, 2017, respectively, and $739 and $546 for the three quarters ended October 1, 2018 and October 2, 2017, respectively. Under the occurrence of certain events, the ABL Revolving Loans are subject to various financial and operational covenants, including maintaining minimum fixed charge coverage ratios.

[0001564590-18-028539:notes:99]
Other Credit Facility

[0001564590-18-028539:notes:100]
Additionally, the Company is party to a revolving loan credit facility (Chinese Revolver) with a lender in China. Under this arrangement, the lender has made available to the Company approximately $30,600 in unsecured borrowing with all terms of the borrowing to be negotiated at the time the Chinese Revolver is drawn upon. There are no commitment fees on the unused portion of the Chinese Revolver, and this arrangement expires in January 2019. As of October 1, 2018, the Chinese Revolver had not been drawn upon.

[0001564590-18-028539:notes:101]
Debt Issuance and Debt Discount

[0001564590-18-028539:notes:102]
As of October 1, 2018 and January 1, 2018, remaining unamortized debt discount and debt issuance costs for the Term Loan Facility, Senior Notes and Convertible Senior Notes are as follows:

[0001564590-18-028539:notes:103]
|  |  | As of October 1, 2018 |  |  | As of January 1, 2018 |  |
|  |  | Debt Issuance Costs |  |  | Debt Discount |  |  | Effective Interest Rate |  |  | Debt Issuance Costs |  |  | Debt Discount |  |  | Effective Interest Rate |  |
|  |  | (in thousands) |  |
| Term Loan due September 2024 |  | $ | 9,266 |  |  | $ | 2,804 |  |  | 4.66% |  |  | $ | 2,788 |  |  | $ | 1,691 |  |  | 3.96% |  |
| Senior Notes due October 2025 |  |  | 6,253 |  |  | — |  |  | 5.92% |  |  |  | 6,782 |  |  | — |  |  | 5.92% |  |
| Convertible Senior Notes |  |  | 2,207 |  |  |  | 22,019 |  |  | 6.48% |  |  |  | 2,889 |  |  |  | 28,822 |  |  | 6.48% |  |
|  |  | $ | 17,726 |  |  | $ | 24,823 |  |  |  |  |  |  | $ | 12,459 |  |  | $ | 30,513 |  |  |  |  |  |

[0001564590-18-028539:notes:104]
The above debt discount and debt issuance costs are recorded as a reduction of the debt and are amortized into interest expense using an effective interest rate over the duration of the debt.

[0001564590-18-028539:notes:105]
Remaining unamortized debt issuance costs for the ABL Revolving Loans of $1,670 and $2,421 as of October 1, 2018 and January 1, 2018, respectively, are included in other non-current assets and are amortized to interest expense over the duration of the ABL Revolving Loans using the straight line method of amortization.

[0001564590-18-028539:notes:106]
At October 1, 2018, the remaining weighted average amortization period for all unamortized debt discount and debt issuance costs was 3.9 years.

[0001564590-18-028539:notes:107]
Loss on Extinguishment of Debt

[0001564590-18-028539:notes:108]
During the quarter ended October 2, 2017, the Company recognized loss on extinguishment of debt of $768, primarily associated with the write off of the remaining unamortized debt issuance and debt discount for the 2016 Term Loan.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001564590-18-028539:notes:109]
[same as prior period, unchanged from 0001564590-18-020718:notes:105]

[0001564590-18-028539:notes:110]
[same as prior period, unchanged from 0001564590-18-020718:notes:106]

[0001564590-18-028539:notes:111]
During the quarter and three quarters ended October 1, 2018, the Company’s effective tax rate was impacted by a net discrete benefit of $1,567 and $67,996, respectively. This is related to accrued interest expense on existing uncertain tax positions, tax incentives, release of uncertain tax positions due to the expiration of the statute of limitations in foreign jurisdictions, release of a portion of the Company’s valuation allowance against its U.S. federal and state net deferred tax assets, return to provision benefits, and an additional expense related to the non U.S. income tax effect of a change in assertion with respect to the Company’s indefinite reinvestment policy outside of the U.S. Additionally, no tax benefit was recorded on the losses incurred in certain foreign jurisdictions as a result of corresponding increases in the valuation allowances in these jurisdictions.

[0001564590-18-028539:notes:112]
During the quarter ended July 2, 2018, the Company recorded a discrete tax benefit of $74,599 (included in the net amount reported in the previous paragraph) related to the release of a portion of the Company’s valuation allowance against its U.S. federal and state net deferred tax assets as a result of the net deferred tax liability established with the acquisition of Anaren. The Company expects its earnings attributable to foreign subsidiaries will be indefinitely reinvested outside of the U.S. but to facilitate more efficient cash management outside of the U.S., the Company revised its assertion during the quarter ended July 2, 2018 such that a majority of foreign earnings can be repatriated up to the top tier foreign holding company and as such, has provided for an additional accrual of deferred tax liabilities as a discrete tax expense of $9,963 (also included in the net amount reported in the previous paragraph) for the quarter ended July 2, 2018.  The Company continues to maintain its indefinite reinvestment of earnings attributable to foreign subsidiaries with respect to the U.S. and, therefore, no deferred tax liabilities for U.S. income taxes on undistributed earnings are recorded.

[0001564590-18-028539:notes:113]
[same as prior period, unchanged from 0001564590-18-020718:notes:109]

[0001564590-18-028539:notes:114]
[same as prior period, unchanged from 0001564590-18-020718:notes:110]

[0001564590-18-028539:notes:115]
[same as prior period, unchanged from 0001564590-18-020718:notes:111]

[0001564590-18-028539:notes:116]
[same as prior period, unchanged from 0001564590-18-020718:notes:112]

[0001564590-18-028539:notes:117]
[same as prior period, unchanged from 0001564590-18-020718:notes:113]

[0001564590-18-028539:notes:118]
Effects of tax law changes where a reasonable estimate of the accounting effects cannot yet been made include the one-time mandatory repatriation transition tax on the net accumulated earnings and profits of the Company’s foreign subsidiaries earned post 1986. For the year ended January 1, 2018, the Company had performed a preliminary earnings and profits analysis with consideration given to foreign loss carryforwards acquired as a result of the Company’s acquisitions and determined on a provisional basis that there should be no income tax effect in the current or any future period. For the quarter and three quarters ended October 1, 2018, the Company has continued to gather documentation to support its position and maintains that there should be no income tax effect.

[0001564590-18-028539:notes:119]
The Company has determined that the following provisions that are effective January 1, 2018 and relevant to the Company will not impact the quarter and three quarters ended October 1, 2018 tax expense, primarily as a result of the full valuation allowance in the U.S.: limitations on certain entertainment expenses, the inclusion of commissions and performance based compensation in determining the excessive compensation limitation, limitation on the current deductibility of net interest expense in excess of 30 percent of adjusted taxable income, and a minimum tax on certain foreign earnings in excess of 10 percent of the foreign subsidiaries tangible assets (i.e., global intangible low-taxed income or GILTI). The Company has decided to make a policy election to treat the GILTI tax as a period expense and as such, no U.S. deferred taxes will be calculated on foreign earnings that are expected to generate GILTI income when they reverse in future years.

[0001564590-18-028539:notes:120]
For the quarter and three quarters ended October 1, 2018, other than as noted above, the Company has not made any changes to its previously provisional estimate of the impact U.S. Tax Reform and the Company continues to analyze and model the impact and will record said impact as it becomes more certain. This includes the mandatory repatriation tax and the indefinite criterion assertion on foreign earnings (with respect to repatriation to the U.S.).


## us-gaap:FinancialInstrumentsDisclosureTextBlock

[0001564590-18-028539:notes:121]
[same as prior period, unchanged from 0001564590-18-020718:notes:117]

[0001564590-18-028539:notes:122]
[same as prior period, unchanged from 0001564590-18-020718:notes:118]

[0001564590-18-028539:notes:123]
[same as prior period, unchanged from 0001564590-18-020718:notes:119]

[0001564590-18-028539:notes:124]
[same as prior period, unchanged from 0001564590-18-020718:notes:120]

[0001564590-18-028539:notes:125]
On May 15, 2018, the Company entered into a four-year pay-fixed, receive floating (1-month LIBOR), interest rate swap arrangement with a notional amount of $400,000 for the period beginning June 1, 2018 and ending on June 1, 2022. Under the terms of the interest rate swap, the Company pays a fixed rate of 2.84% against the first interest payments of a portion of its LIBOR-based debt and receives floating 1-month LIBOR during the swap period.

[0001564590-18-028539:notes:126]
At inception, the Company designated the interest rate swap as a cash flow hedge and the fair value of the interest rate swap was zero. As of October 1, 2018, the fair value of the interest rate swap was recorded as an asset in the amount of $977 and included as a component of other assets. The change in the fair value of the interest rate swap is recorded as a component of accumulated other comprehensive income, net of tax, in the Company’s consolidated condensed balance sheet. No ineffectiveness was recognized for the quarter and three quarters ended October 1, 2018. During the quarter and three quarters ended October 1, 2018, the interest rate swap increased interest expense by $752 and $1,055, respectively.

[0001564590-18-028539:notes:127]
[same as prior period, unchanged from 0001564590-18-020718:notes:123]

[0001564590-18-028539:notes:128]
The Company enters into foreign currency forward contracts to mitigate the impact of changes in foreign currency exchange rates and to reduce the volatility of purchases and other obligations generated in currencies other than its functional currencies. The Company’s foreign subsidiaries may at times purchase forward exchange contracts to manage their foreign currency risks in relation to certain purchases of machinery denominated in foreign currencies other than the Company’s functional currencies. The notional amount of the foreign exchange contracts at October 1, 2018 and January 1, 2018 was approximately $6,482 and $10,927, respectively. The Company has designated certain of these foreign exchange contracts as cash flow hedges.

[0001564590-18-028539:notes:129]
[same as prior period, unchanged from 0001564590-18-020718:notes:125]

[0001564590-18-028539:notes:130]
|  |  |  |  | Asset/(Liability) Fair Value |  |
|  |  | Balance Sheet Location |  | October 1, 2018 |  |  | January 1, 2018 |  |
|  |  |  |  | (In thousands) |  |
| Cash flow derivative instruments designated as hedges: |  |  |  |  |  |  |  |  |
| Interest rate swap |  | Other assets |  | $ | 977 |  |  |  |  |  |
| Foreign exchange contracts |  | Other accrued expenses |  |  |  |  |  | $ | (6 | ) |
| Cash flow derivative instruments not designated as hedges: |  |  |  |  |  |  |  |  |
| Foreign exchange contracts |  | Prepaid expenses and other current assets |  |  |  |  |  |  | 107 |  |
| Foreign exchange contracts |  | Other accrued expenses |  |  | (346 | ) |  |  | (132 | ) |
| Foreign exchange contracts |  | Other long-term liabilities |  |  |  |  |  |  | (13 | ) |

[0001564590-18-028539:notes:131]
[same as prior period, unchanged from 0001564590-18-020718:notes:127]

[0001564590-18-028539:notes:132]
|  |  |  | Quarter ended October 1, 2018 |  |  | Quarter ended October 2, 2017 |  |
|  |  |  | Effective Portion |  |  | Ineffective Portion |  |  | Effective Portion |  |  | Ineffective Portion |  |
|  |  | Financial Statement Caption | Gain/(Loss) Recognized in Other Comprehensive Income |  |  | Gain/(Loss) Reclassified into Income |  |  | Gain/(Loss) Reclassified into Income |  |  | Gain/(Loss) Recognized in Other Comprehensive Income |  |  | Gain/(Loss) Reclassified into Income |  |  | Gain/(Loss) Reclassified into Income |  |
|  |  |  | (In thousands) |  |
| Cash flow hedge: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Interest rate swap |  | Interest expense | $ | 1,641 |  |  | $ | (752 | ) |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |
| Foreign currency forward |  | Depreciation expense |  | — |  |  |  | (12 | ) |  |  | — |  |  |  | 30 |  |  |  | (43 | ) |  |  | — |  |
|  |  |  | Three Quarters ended October 1, 2018 |  |  | Three Quarters ended October 2, 2017 |  |
|  |  |  | Effective Portion |  |  | Ineffective Portion |  |  | Effective Portion |  |  | Ineffective Portion |  |
|  |  | Financial Statement Caption | Gain/(Loss) Recognized in Other Comprehensive Income |  |  | Gain/(Loss) Reclassified into Income |  |  | Gain/(Loss) Reclassified into Income |  |  | Gain/(Loss) Recognized in Other Comprehensive Income |  |  | Gain/(Loss) Reclassified into Income |  |  | Gain/(Loss) Reclassified into Income |  |
|  |  |  | (In thousands) |  |
| Cash flow hedge: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Interest rate swap |  | Interest expense | $ | (78 | ) |  | $ | (1,055 | ) |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |
| Foreign currency forward |  | Depreciation expense |  | (26 | ) |  |  | (92 | ) |  |  | — |  |  |  | 194 |  |  |  | (130 | ) |  |  | — |  |

[0001564590-18-028539:notes:133]
The following table provides a summary of the activity associated with the designated cash flow hedges reflected in accumulated other comprehensive income for the three quarters ended October 1, 2018 and October 2, 2017:

[0001564590-18-028539:notes:134]
|  |  | Three Quarters Ended |  |
|  |  | October 1, |  |  | October 2, |  |
|  |  | 2018 |  |  | 2017 |  |
|  |  | (In thousands) |  |
| Beginning balance, net of tax |  | $ | (742 | ) |  | $ | (1,180 | ) |
| Changes in fair value gain (loss), net of tax |  |  | (104 | ) |  |  | 194 |  |
| Reclassification to earnings |  |  | 1,147 |  |  |  | 130 |  |
| Ending balance, net of tax |  | $ | 301 |  |  | $ | (856 | ) |

[0001564590-18-028539:notes:135]
The Company expects that losses of approximately $1,064 of the accumulated other comprehensive income (loss) will be reclassified into the statement of operations, net of tax, in the next 12 months.

[0001564590-18-028539:notes:136]
[same as prior period, unchanged from 0001564590-18-020718:notes:132]

[0001564590-18-028539:notes:137]
|  |  | Quarter Ended |  |  | Three Quarters Ended |  |
|  |  | October 1, |  |  | October 2, |  |  | October 1, |  |  | October 2, |  |
|  |  | 2018 |  |  | 2017 |  |  | 2018 |  |  | 2017 |  |
|  |  | (In thousands) |  |
| Derivative instruments not designated as hedges: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Foreign exchange contracts |  | $ | (197 | ) |  | $ | 67 |  |  | $ | (94 | ) |  | $ | 38 |  |


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0001564590-18-028539:notes:138]
[same as prior period, unchanged from 0001564590-18-020718:notes:134]

[0001564590-18-028539:notes:139]
The following provides a summary of the components of accumulated other comprehensive income as of October 1, 2018 and January 1, 2018:

[0001564590-18-028539:notes:140]
|  |  | Foreign Currency Translation |  |  | Gains (Losses) on Cash Flow Hedges |  |  | Total |  |
|  |  | (In thousands) |  |
| Ending balance at January 1, 2018 |  | $ | 4,145 |  |  | $ | (742 | ) |  | $ | 3,403 |  |
| Other comprehensive income (loss) before reclassifications |  |  | (2,327 | ) |  |  | (104 | ) |  |  | (2,431 | ) |
| Amounts reclassified from accumulated other comprehensive income |  |  | — |  |  |  | 1,147 |  |  |  | 1,147 |  |
| Other comprehensive income (loss) |  |  | (2,327 | ) |  |  | 1,043 |  |  |  | (1,284 | ) |
| Ending balance at October 1, 2018 |  | $ | 1,818 |  |  | $ | 301 |  |  | $ | 2,119 |  |


## us-gaap:ConcentrationRiskDisclosureTextBlock

[0001564590-18-028539:notes:141]
[same as prior period, unchanged from 0001564590-18-020718:notes:137]

[0001564590-18-028539:notes:142]
[same as prior period, unchanged from 0001564590-18-020718:notes:138]

[0001564590-18-028539:notes:143]
[same as prior period, unchanged from 0001564590-18-020718:notes:139]

[0001564590-18-028539:notes:144]
For the quarters ended October 1, 2018 and October 2, 2017, one customer accounted for approximately 20% and 21%, respectively, of the Company’s net sales. For the three quarters ended October 1, 2018 and October 2, 2017, one customer accounted for approximately 15% and 18%, respectively, of the Company’s net sales. There were no other customers that accounted for 10% or more of net sales for the quarters or three quarters ended October 1, 2018 and October 2, 2017.


## us-gaap:FairValueDisclosuresTextBlock

[0001564590-18-028539:notes:145]
[same as prior period, unchanged from 0001564590-18-020718:notes:141]

[0001564590-18-028539:notes:146]
[same as prior period, unchanged from 0001564590-18-020718:notes:142]

[0001564590-18-028539:notes:147]
The carrying amount and estimated fair value of the Company’s financial instruments at October 1, 2018 and January 1, 2018 were as follows:

[0001564590-18-028539:notes:148]
|  |  | October 1, 2018 |  |  | January 1, 2018 |  |
|  |  | Carrying Amount |  |  | Fair Value |  |  | Carrying Amount |  |  | Fair Value |  |
|  |  | (In thousands) |  |
| Derivative assets, current |  | $ | 977 |  |  |  | 977 |  |  | $ | 107 |  |  | $ | 107 |  |
| Derivative liabilities, current |  |  | 346 |  |  |  | 346 |  |  |  | 151 |  |  |  | 151 |  |
| Term Loan due September 2024 |  |  | 893,809 |  |  |  | 909,276 |  |  |  | 344,646 |  |  |  | 346,943 |  |
| Senior Notes due October 2025 |  |  | 368,747 |  |  |  | 373,838 |  |  |  | 368,218 |  |  |  | 384,769 |  |
| Convertible Senior Notes |  |  | 225,759 |  |  |  | 420,100 |  |  |  | 218,274 |  |  |  | 429,199 |  |
| ABL Revolving Loans |  |  | 70,000 |  |  |  | 70,000 |  |  |  | 47,000 |  |  |  | 47,000 |  |
| Capital lease |  |  | — |  |  |  | — |  |  |  | 1,919 |  |  |  | 1,919 |  |

[0001564590-18-028539:notes:149]
[same as prior period, unchanged from 0001564590-18-020718:notes:145]

[0001564590-18-028539:notes:150]
The fair value of the long-term debt was estimated based on quoted market prices or discounting the debt over its life using current market rates for similar debt as of October 1, 2018 and January 1, 2018, which are considered Level 1 and Level 2 inputs.

[0001564590-18-028539:notes:151]
[same as prior period, unchanged from 0001564590-18-020718:notes:147]

[0001564590-18-028539:notes:152]
As of October 1, 2018 and January 1, 2018, the Company’s other financial instruments also included cash and cash equivalents, accounts receivable, and accounts payable. Due to short-term maturities, the carrying amount of these instruments approximates fair value. The Company’s cash and cash equivalents at October 1, 2018 consisted of $27,082 held in the U.S., with the remaining $180,870 held by foreign subsidiaries.

[0001564590-18-028539:notes:153]
[same as prior period, unchanged from 0001564590-18-020718:notes:149]


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001564590-18-028539:notes:154]
(14) Commitments and Contingencies

[0001564590-18-028539:notes:155]
Legal Matters

[0001564590-18-028539:notes:156]
The Company is subject to various legal matters, which it considers normal for its business activities. While the Company currently believes that the amount of any reasonably possible loss for known matters would not be material to the Company’s financial condition, the outcome of these actions is inherently difficult to predict. In the event of an adverse outcome, the ultimate potential loss could have a material adverse effect on the Company’s financial condition or results of operations in a particular period. The Company has accrued amounts for its loss contingencies which are probable and estimable as of October 1, 2018 and January 1, 2018. However, these amounts are not material to the consolidated condensed financial statements of the Company.

[0001564590-18-028539:notes:157]
Environmental Matters

[0001564590-18-028539:notes:158]
The process to manufacture PCBs requires adherence to city, county, state, federal regulations as well as foreign environmental regulations regarding the storage, use, handling and disposal of chemicals, solid wastes and other hazardous materials, as well as compliance with air quality standards and chemical use reporting. The Company believes that its facilities in the United States and Canada comply in all material respects with applicable environmental laws and regulations. In China, governmental authorities have adopted new rules and regulations governing environmental issues. An update to the Chinese environmental waste water law was issued in late 2012, allowing for an interim period in which plants subject to such law may install equipment that meets the new regulatory regime. Some of the Company’s plants in China are not yet in full compliance with the updated environmental regulations. The Company has established and enacted an investment plan related to the efforts to come into full compliance with the new regulations. The 2018 capital expenditure costs expected for these plans are included in the Company’s capital expenditure projections.


## us-gaap:EarningsPerShareTextBlock

[0001564590-18-028539:notes:159]
[same as prior period, unchanged from 0001564590-18-020718:notes:155]

[0001564590-18-028539:notes:160]
The following is a reconciliation of the numerator and denominator used to calculate basic earnings per share and diluted earnings per share for the quarters and three quarters ended October 1, 2018 and October 2, 2017:

[0001564590-18-028539:notes:161]
|  |  | Quarter Ended |  |  | Three Quarters Ended |  |
|  |  | October 1, 2018 |  |  | October 2, 2017 |  |  | October 1, 2018 |  |  | October 2, 2017 |  |
|  |  | (In thousands, except per share amounts) |  |
| Basic earnings: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic earnings |  | $ | 27,001 |  |  | $ | 21,453 |  |  | $ | 121,102 |  |  | $ | 75,003 |  |
| Diluted earnings: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Net income attributable to TTM Technologies, Inc. stockholders |  | $ | 27,001 |  |  | $ | 21,453 |  |  | $ | 121,102 |  |  | $ | 75,003 |  |
| Interest expense from convertible senior notes, net of tax |  |  | 3,628 |  |  |  | 3,469 |  |  |  | 10,763 |  |  |  | 10,296 |  |
| Diluted earnings |  | $ | 30,629 |  |  | $ | 24,922 |  |  | $ | 131,865 |  |  | $ | 85,299 |  |
| Basic weighted average shares |  |  | 103,676 |  |  |  | 101,814 |  |  |  | 103,246 |  |  |  | 101,501 |  |
| Dilutive effect of performance-based restricted stock units, restricted stock units and stock options |  |  | 1,595 |  |  |  | 1,692 |  |  |  | 1,600 |  |  |  | 1,721 |  |
| Dilutive effect of outstanding warrants |  |  | 5,226 |  |  |  | 2,151 |  |  |  | 4,086 |  |  |  | 2,753 |  |
| Dilutive effect of assumed conversion of convertible senior notes outstanding |  |  | 25,938 |  |  |  | 25,939 |  |  |  | 25,939 |  |  |  | 25,939 |  |
| Diluted shares |  |  | 136,435 |  |  |  | 131,596 |  |  |  | 134,871 |  |  |  | 131,914 |  |
| Earnings per share attributable to TTM Technologies, Inc. stockholders: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  | $ | 0.26 |  |  |  | 0.21 |  |  | $ | 1.17 |  |  | $ | 0.74 |  |
| Diluted |  | $ | 0.22 |  |  |  | 0.19 |  |  | $ | 0.98 |  |  | $ | 0.65 |  |

[0001564590-18-028539:notes:162]
Performance-based restricted stock units (PRUs), restricted stock units (RSUs) and stock options to purchase 30 and 631 shares of common stock for the quarters ended October 1, 2018 and October 2, 2017, respectively, and 335 and 275 for the three quarters ended October 1, 2018 and October 2, 2017, respectively, were not considered in calculating diluted earnings per share because the options’ exercise prices or the total expected proceeds under the treasury stock method for PRUs, RSUs or stock options was greater than the average market price of common shares during the applicable quarter and three quarters and, therefore, the effect would be anti-dilutive.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001564590-18-028539:notes:163]
[same as prior period, unchanged from 0001564590-18-020718:notes:159]

[0001564590-18-028539:notes:164]
[same as prior period, unchanged from 0001564590-18-020718:notes:160]

[0001564590-18-028539:notes:165]
|  |  | Quarter Ended |  |  | Three Quarters Ended |  |
|  |  | October 1, |  |  | October 2, |  |  | October 1, |  |  | October 2, |  |
|  |  | 2018 |  |  | 2017 |  |  | 2018 |  |  | 2017 |  |
|  |  | (In thousands) |  |  | (In thousands) |  |
| Cost of goods sold |  | $ | 774 |  |  | $ | 606 |  |  | $ | 2,132 |  |  | $ | 1,639 |  |
| Selling and marketing |  |  | 520 |  |  |  | 369 |  |  |  | 1,439 |  |  |  | 1,008 |  |
| General and administrative |  |  | 4,165 |  |  |  | 3,703 |  |  |  | 11,377 |  |  |  | 10,659 |  |
| Stock-based compensation expense recognized |  | $ | 5,459 |  |  | $ | 4,678 |  |  | $ | 14,948 |  |  | $ | 13,306 |  |

[0001564590-18-028539:notes:166]
[same as prior period, unchanged from 0001564590-18-020718:notes:162]

[0001564590-18-028539:notes:167]
The Company maintains a long-term incentive program for executives that provides for the issuance of PRUs, representing hypothetical shares of the Company’s common stock that may be issued. Under the PRU program, a target number of PRUs is awarded at the beginning of each three-year performance period. The number of shares of common stock released at the end of the performance period will range from zero to 2.4 times the target number depending on performance and market conditions during the period. The performance and market condition metrics of the PRU program are based on (a) annual financial targets, which are based on revenue and EBITDA (earnings before interest, tax, depreciation, and amortization expense), each equally weighted, and (b) an overall modifier based on the Company’s total stockholder return (TSR) relative to a group of peer companies selected by the Company’s compensation committee, over the three-year performance period.

[0001564590-18-028539:notes:168]
The Company records stock-based compensation expense for PRU awards granted based on management’s periodic assessment of the annual financial performance goals to be achieved. For the three quarters ended October 1, 2018, management determined that vesting of the PRU awards was probable. PRUs activity for the three quarters ended October 1, 2018 was as follows:

[0001564590-18-028539:notes:169]
|  |  | Shares |  |  | Weighted Average Fair Value |  |
|  |  | (In thousands) |  |  |  |  |  |
| Outstanding target shares at January 1, 2018 |  |  | 409 |  |  | $ | 16.39 |  |
| Granted |  |  | 335 |  |  |  | 19.59 |  |
| Change in units due to annual performance achievement |  |  | (40 | ) |  |  | 19.59 |  |
| Outstanding target shares at October 1, 2018 |  |  | 704 |  |  | $ | 17.73 |  |

[0001564590-18-028539:notes:170]
[same as prior period, unchanged from 0001564590-18-020718:notes:166]

[0001564590-18-028539:notes:171]
The Company granted 5 RSUs during the quarter ended October 1, 2018, and the RSUs granted have a weighted-average fair value per unit of $17.57.  The Company granted 1,028 and 1,007 RSUs during the three quarters ended October 1, 2018 and October 2, 2017, respectively. The RSUs granted have a weighted-average fair value per unit of $15.45 and $15.82 for the three quarters ended October 1, 2018 and October 2, 2017, respectively. The fair value for RSUs granted is based on the closing share price of the Company’s common stock on the date of grant. The Company did not grant RSUs during the quarter ended October 2, 2017.

[0001564590-18-028539:notes:172]
[same as prior period, unchanged from 0001564590-18-020718:notes:168]

[0001564590-18-028539:notes:173]
During the three quarters ended October 1, 2018, The Company granted 20 stock option awards to a newly appointed member of the board which were estimated to have a fair value per share of $8.92. The fair value calculation is based on stock options granted during the period using the Black-Scholes option-pricing model on the date of grant. For the three quarters ended October 1, 2018, the fair value was determined using 3.0% as the risk-free interest rate, 43% as the expected volatility, 8.5 years as the expected term and no dividend yield. The Company did not grant stock option awards during the quarter ended October 1, 2018, or during the quarter and three quarters ended October 2, 2017.

[0001564590-18-028539:notes:174]
[same as prior period, unchanged from 0001564590-18-020718:notes:170]

[0001564590-18-028539:notes:175]
The following is a summary of total unrecognized compensation costs as of October 1, 2018:

[0001564590-18-028539:notes:176]
|  |  | Unrecognized Stock- Based Compensation Cost |  |  | Remaining Weighted Average Recognition Period |  |
|  |  | (In thousands) |  |  | (In years) |  |
| RSU awards |  | $ | 21,077 |  |  |  | 1.4 |  |
| PRU awards |  |  | 4,514 |  |  |  | 1.1 |  |
| Stock options |  |  | 230 |  |  |  | 2.0 |  |
|  |  | $ | 25,821 |  |  |  |  |  |


## us-gaap:SegmentReportingDisclosureTextBlock

[0001564590-18-028539:notes:177]
[same as prior period, unchanged from 0001564590-18-020718:notes:173]

[0001564590-18-028539:notes:178]
The reportable segments reported below are the Company’s segments for which separate financial information is available and upon which operating results are evaluated by the chief operating decision maker to assess performance and to allocate resources. The Company has two reportable segments: PCB and E-M Solutions. As of the third quarter of 2018, the Company completed the integration of Anaren and reassessed its reportable segments, which resulted in the inclusion of Anaren into the PCB reportable segment. The PCB reportable segment is comprised of multiple operating segments. Factors considered to determine whether operating segments can be aggregated into reportable segments included similarity regarding economic characteristics, products, production processes, type or classes of customers, distribution methods, and regulatory environments.

[0001564590-18-028539:notes:179]
[same as prior period, unchanged from 0001564590-18-020718:notes:175]

[0001564590-18-028539:notes:180]
The inter-segment sales for the quarters and three quarters ended October 1, 2018 and October 2, 2017, are sales primarily from the PCB to the E-M Solutions reportable segment.

[0001564590-18-028539:notes:181]
|  |  | Quarter Ended |  |  | Three Quarters ended |  |
|  |  | October 1, 2018 |  |  | October 2, 2017 |  |  | October 1, 2018 |  |  | October 2, 2017 |  |
|  |  | (In thousands) |  |  | (In thousands) |  |
| Net Sales: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| PCB (1) |  | $ | 698,983 |  |  | $ | 609,742 |  |  | $ | 1,975,913 |  |  | $ | 1,773,003 |  |
| E-M Solutions |  |  | 59,481 |  |  |  | 60,620 |  |  |  | 168,474 |  |  |  | 155,187 |  |
| Total sales |  |  | 758,464 |  |  |  | 670,362 |  |  |  | 2,144,387 |  |  |  | 1,928,190 |  |
| Inter-segment sales |  |  | (2,627 | ) |  |  | (3,548 | ) |  |  | (8,081 | ) |  |  | (8,947 | ) |
| Total net sales (1) |  | $ | 755,837 |  |  | $ | 666,814 |  |  | $ | 2,136,306 |  |  | $ | 1,919,243 |  |
| Operating Segment Income (Loss): |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| PCB (1) |  | $ | 98,039 |  |  | $ | 70,443 |  |  | $ | 242,467 |  |  | $ | 222,134 |  |
| E-M Solutions |  |  | 2,205 |  |  |  | 2,870 |  |  |  | 4,741 |  |  |  | 3,917 |  |
| Corporate |  |  | (26,920 | ) |  |  | (23,318 | ) |  |  | (86,799 | ) |  |  | (66,608 | ) |
| Total operating segment income |  |  | 73,324 |  |  |  | 49,995 |  |  |  | 160,409 |  |  |  | 159,443 |  |
| Amortization of definite-lived intangibles (2) |  |  | (18,774 | ) |  |  | (5,905 | ) |  |  | (44,124 | ) |  |  | (17,727 | ) |
| Total operating income |  |  | 54,550 |  |  |  | 44,090 |  |  |  | 116,285 |  |  |  | 141,716 |  |
| Total other expense |  |  | (20,012 | ) |  |  | (21,350 | ) |  |  | (49,141 | ) |  |  | (55,403 | ) |
| Income before income taxes |  | $ | 34,538 |  |  | $ | 22,740 |  |  | $ | 67,144 |  |  | $ | 86,313 |  |

[0001564590-18-028539:notes:182]
| (1) | Figures for the quarter and three quarters ended October 2, 2017 do not include Anaren, as the acquisition occurred on April 18, 2018. |

[0001564590-18-028539:notes:183]
| (2) | Amortization of definite-lived intangibles primarily relates to the PCB reportable segment. |

[0001564590-18-028539:notes:184]
The Corporate category includes operating expenses that are not included in the segment operating performance measures. Corporate consists primarily of corporate governance functions such as finance, accounting, corporate sales, information technology, facilities, corporate operations and human resources personnel. Bank fees and legal, accounting, and other professional service costs associated with the acquisition of Anaren in the amount of $312 and $11,137 for the quarter and three quarters ended October 1, 2018, respectively, are also included in Corporate. See Note 3 Acquisition of Anaren Inc.


## us-gaap:RelatedPartyTransactionsDisclosureTextBlock

[0001564590-18-028539:notes:185]
(18) Related Party Transactions

[0001564590-18-028539:notes:186]
In the normal course of business, the Company’s foreign subsidiaries purchase laminate and prepreg from related parties in which a member of the Board of Directors of the Company holds an equity interest. The Company’s foreign subsidiaries purchased laminate and prepreg from these related parties in the amount of $10,437 and $13,225 for the quarters ended October 1, 2018 and October 2, 2017, respectively, and $35,695 and $38,886 for the three quarters ended October 1, 2018 and October 2, 2017, respectively.

[0001564590-18-028539:notes:187]
As of October 1, 2018 and January 1, 2018, the Company’s consolidated condensed balance sheets included $10,745 and $14,452, respectively, in accounts payable due to related parties primarily for purchases of laminate and prepreg and such balances are included as a component of accounts payable on the consolidated condensed balance sheets.
