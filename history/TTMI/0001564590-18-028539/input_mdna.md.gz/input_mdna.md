# TTMI MD&A — 0001564590-18-028539


## mdna

[0001564590-18-028539:mdna:1]
[same as prior period, unchanged from 0001564590-18-020718:mdna:1]

[0001564590-18-028539:mdna:2]
[same as prior period, unchanged from 0001564590-18-020718:mdna:2]

[0001564590-18-028539:mdna:3]
We are a leading global printed circuit board (PCB) manufacturer, focusing on quick-turn and volume production of technologically complex PCBs, backplane assemblies and electro-mechanical solutions (E-M Solutions) as well as a global designer and manufacturer of RF and microwave components and assemblies. We focus on providing time-to-market and volume production of advanced technology products and offer a one-stop manufacturing solution to our customers from engineering support to prototype development through final mass production. This one-stop manufacturing solution allows us to align technology development with the diverse needs of our customers and to enable them to reduce the time required to develop new products and bring them to market. We serve a diversified customer base consisting of approximately 2,200 customers in various markets throughout the world, including aerospace and defense, automotive components, smartphones and touchscreen tablets, high-end computing, and medical, industrial and instrumentation related products as well as networking/communications infrastructure products. Our customers include both original equipment manufacturers (OEMs) and electronic manufacturing services (EMS) providers.

[0001564590-18-028539:mdna:4]
[same as prior period, unchanged from 0001564590-18-020718:mdna:4]

[0001564590-18-028539:mdna:5]
On April 18, 2018, we acquired all of the issued and outstanding common stock of Anaren Holding Corp. for total consideration of $787.9 million subject to customary working capital and certain other adjustments. Other than the equity interests of Anaren, Inc. (Anaren), Anaren Holding Corp. has no material assets or liabilities and has no material independent operations. Anaren is a leading provider of mission-critical RF solutions, microelectronics, and microwave components and assemblies for the wireless infrastructure and aerospace and defense electronics markets.

[0001564590-18-028539:mdna:6]
Additionally, on April 18, 2018 we closed our $600.0 million commitment for incremental loans concurrent with the completion of our acquisition of Anaren. We used the proceeds of the incremental loans, along with cash on hand to fund the purchase price of the acquisition and to pay related fees and expenses.

[0001564590-18-028539:mdna:7]
[same as prior period, unchanged from 0001564590-18-020718:mdna:7]

[0001564590-18-028539:mdna:8]
While our customers include both OEMs and EMS providers, we measure customers based on OEM companies, as they are the ultimate end customers. Sales to our 10 largest customers accounted for 49% and 50% of our net sales for the quarters ended October 1, 2018 and October 2, 2017, respectively, and 45% and 46% for the three quarters ended October 1, 2018 and October 2, 2017, respectively. We sell to OEMs both directly and indirectly through EMS providers.

[0001564590-18-028539:mdna:9]
[same as prior period, unchanged from 0001564590-18-020718:mdna:9]

[0001564590-18-028539:mdna:10]
|  |  | Quarter Ended |  |  |  | Three Quarters Ended |  |  |
| End Markets(1)(2) |  | October 1, 2018 |  |  |  | October 2, 2017 |  |  |  | October 1, 2018 |  |  |  | October 2, 2017 |  |  |
| Aerospace and Defense |  |  | 23 |  | % |  |  | 16 |  | % |  |  | 22 |  | % |  |  | 16 |  | % |
| Automotive |  |  | 15 |  |  |  |  | 20 |  |  |  |  | 18 |  |  |  |  | 20 |  |  |
| Cellular Phone(2) |  |  | 17 |  |  |  |  | 17 |  |  |  |  | 13 |  |  |  |  | 15 |  |  |
| Computing/Storage/Peripherals(2) |  |  | 14 |  |  |  |  | 14 |  |  |  |  | 14 |  |  |  |  | 14 |  |  |
| Medical/Industrial/Instrumentation |  |  | 13 |  |  |  |  | 14 |  |  |  |  | 14 |  |  |  |  | 14 |  |  |
| Networking/Communications |  |  | 17 |  |  |  |  | 17 |  |  |  |  | 17 |  |  |  |  | 19 |  |  |
| Other(3) |  |  | 1 |  |  |  |  | 2 |  |  |  |  | 2 |  |  |  |  | 2 |  |  |
| Total |  |  | 100 |  | % |  |  | 100 |  | % |  |  | 100 |  | % |  |  | 100 |  | % |

[0001564590-18-028539:mdna:11]
[same as prior period, unchanged from 0001564590-18-020718:mdna:11]

[0001564590-18-028539:mdna:12]
[same as prior period, unchanged from 0001564590-18-020718:mdna:12]

[0001564590-18-028539:mdna:13]
[same as prior period, unchanged from 0001564590-18-020718:mdna:13]

[0001564590-18-028539:mdna:14]
We derive revenues primarily from the sale of PCBs, custom electronic assemblies using customer-supplied engineering and design plans as well as the design and manufacture of RF and microwave components and assemblies. Most orders for products generally correspond to the production schedules of our customers and are supported with firm purchase orders. Most of our customers have continuous control of the work in progress and finished goods throughout the PCB manufacturing process, as PCBs are built to customer specifications and do not have an alternative use. The customer typically controls the work in progress and finished goods as evidenced either by contractual termination clauses or by our right to payment for work performed to date, plus a reasonable profit. As a result, and in light of our adoption of the new “over time” revenue standard as further discussed below in the “CRITICAL ACCOUNTING POLICIES AND ESTIMATES,” beginning in the first quarter of 2018, we recognize revenue progressively over time based on the extent of progress towards completion of the performance obligation rather than upon shipment as we had in the past.

[0001564590-18-028539:mdna:15]
[same as prior period, unchanged from 0001564590-18-020718:mdna:15]

[0001564590-18-028539:mdna:16]
Additionally, we have certain long-term contracts related to the manufacture of components, assemblies, and subsystems. These long-term contracts, many of which provide for periodic payments, are recognized over time under the percentage-of completion method. Estimated manufacturing cost-at-completion for these contracts are reviewed on a periodic basis, and adjustments are made periodically to the estimated cost-at-completion, based on actual costs incurred, progress made, and estimates of costs required to complete the contractual requirements. When the estimated manufacturing cost-at-completion exceeds the contract value, the contract is written down to its net realizable value and the loss resulting from the cost overruns are immediately recognized.

[0001564590-18-028539:mdna:17]
We also manufacture certain components, assemblies, and subsystems for which we recognize revenue at a point in time as the customer does not simultaneously receive or consume the benefits provided by our performance and the asset being manufactured has alternative uses to us.

[0001564590-18-028539:mdna:18]
[same as prior period, unchanged from 0001564590-18-020718:mdna:18]

[0001564590-18-028539:mdna:19]
[same as prior period, unchanged from 0001564590-18-020718:mdna:19]

[0001564590-18-028539:mdna:20]
[same as prior period, unchanged from 0001564590-18-020718:mdna:20]

[0001564590-18-028539:mdna:21]
[same as prior period, unchanged from 0001564590-18-020718:mdna:21]

[0001564590-18-028539:mdna:22]
[same as prior period, unchanged from 0001564590-18-020718:mdna:22]

[0001564590-18-028539:mdna:23]
[same as prior period, unchanged from 0001564590-18-020718:mdna:23]

[0001564590-18-028539:mdna:24]
See Item 7, Management’s Discussion and Analysis of Financial Condition and Results of Operations, in our Annual Report on Form 10-K for the fiscal year ended January 1, 2018 for further discussion of critical accounting policies and estimates. There were no material changes to our critical accounting policies and estimates since January 1, 2018, except for the adoption of Accounting Standards Update (ASU) 2014-09, Revenue from Contracts with Customers (new revenue standard) on January 2, 2018.

[0001564590-18-028539:mdna:25]
The new revenue standard replaced most existing revenue recognition guidance in U.S. GAAP, including industry specific requirements, and provides companies with a single revenue recognition model for recognizing revenue of contracts with customers. The core principle of the new revenue standard is that a company should recognize revenue to depict the transfer of promised goods or services to customers in an amount that reflects the consideration to which the company expects to be entitled in exchange for those goods or services.  We assessed the new guidance and adopted the new revenue standard on January 2, 2018, which resulted in a change to the timing of revenue recognition for most of our revenue streams from “point in time” upon physical delivery to an “over time” model.

[0001564590-18-028539:mdna:26]
[same as prior period, unchanged from 0001564590-18-020718:mdna:26]

[0001564590-18-028539:mdna:27]
The quarter and three quarters ended October 2, 2017 do not include the results of operations from our acquisition of Anaren, as the acquisition occurred on April 18, 2018. The following table sets forth the relationship of various items to net sales in our consolidated condensed statements of operations:

[0001564590-18-028539:mdna:28]
|  |  | Quarter Ended |  |  |  | Three Quarters Ended |  |  |
|  |  | October 1, 2018 |  |  |  | October 2, 2017 |  |  |  | October 1, 2018 |  |  |  | October 2, 2017 |  |  |
| Net sales |  |  | 100.0 |  | % |  |  | 100.0 |  | % |  |  | 100.0 |  | % |  |  | 100.0 |  | % |
| Cost of goods sold |  |  | 82.9 |  |  |  |  | 85.5 |  |  |  |  | 84.3 |  |  |  |  | 84.5 |  |  |
| Gross profit |  |  | 17.1 |  |  |  |  | 14.5 |  |  |  |  | 15.7 |  |  |  |  | 15.5 |  |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Selling and marketing |  |  | 2.5 |  |  |  |  | 2.4 |  |  |  |  | 2.6 |  |  |  |  | 2.5 |  |  |
| General and administrative |  |  | 5.3 |  |  |  |  | 4.6 |  |  |  |  | 5.7 |  |  |  |  | 4.7 |  |  |
| Amortization of definite-lived intangibles |  |  | 2.2 |  |  |  |  | 0.9 |  |  |  |  | 2.0 |  |  |  |  | 0.9 |  |  |
| Total operating expenses |  |  | 10.0 |  |  |  |  | 7.9 |  |  |  |  | 10.3 |  |  |  |  | 8.1 |  |  |
| Operating income |  |  | 7.1 |  |  |  |  | 6.6 |  |  |  |  | 5.4 |  |  |  |  | 7.4 |  |  |
| Other income (expense): |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Interest expense |  |  | (2.9 | ) |  |  |  | (2.1 | ) |  |  |  | (2.6 | ) |  |  |  | (2.1 | ) |  |
| Other, net |  |  | 0.3 |  |  |  |  | (1.1 | ) |  |  |  | 0.3 |  |  |  |  | (0.8 | ) |  |
| Total other expense, net |  |  | (2.6 | ) |  |  |  | (3.2 | ) |  |  |  | (2.3 | ) |  |  |  | (2.9 | ) |  |
| Income before income taxes |  |  | 4.5 |  |  |  |  | 3.4 |  |  |  |  | 3.1 |  |  |  |  | 4.5 |  |  |
| Income tax provision |  |  | (0.9 | ) |  |  |  | (0.2 | ) |  |  |  | 2.6 |  |  |  |  | (0.6 | ) |  |
| Net income |  |  | 3.6 |  |  |  |  | 3.2 |  |  |  |  | 5.7 |  |  |  |  | 3.9 |  |  |
| Less: Net income attributable to the non- controlling interest |  |  | — |  |  |  |  | — |  |  |  |  | — |  |  |  |  | — |  |  |
| Net income attributable to TTM Technologies, Inc. stockholders |  |  | 3.6 |  | % |  |  | 3.2 |  | % |  |  | 5.7 |  | % |  |  | 3.9 |  | % |

[0001564590-18-028539:mdna:29]
We have two reportable segments: PCB and E-M Solutions. Following the acquisition of Anaren on April 18, 2018, we classified Anaren as a reportable segment. See Notes to Consolidated Condensed Financial Statements ─ Note 3 Acquisition of Anaren, Inc. However, as of the third quarter of 2018, we completed our integration of Anaren and reassessed our reportable segments, which resulted in the inclusion of Anaren into the PCB reportable segment. The PCB reportable segment is comprised of multiple operating segments. Factors considered in determining whether operating segments can be aggregated into reportable segments included similarity regarding economic characteristics, products, production process, type or class of customers, distribution methods and regulatory environments.

[0001564590-18-028539:mdna:30]
The following table compares net sales by reportable segment for the quarters and three quarters ended October 1, 2018 and October 2, 2017:

[0001564590-18-028539:mdna:31]
|  |  | Quarter Ended |  |  | Three Quarters Ended |  |
|  |  | October 1, 2018 |  |  | October 2, 2017 |  |  | October 1, 2018 |  |  | October 2, 2017 |  |
|  |  | (In thousands) |  |  | (In thousands) |  |
| Net Sales |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| PCB (1) |  | $ | 698,983 |  |  | $ | 609,742 |  |  | $ | 1,975,913 |  |  | $ | 1,773,003 |  |
| E-M Solutions |  |  | 59,481 |  |  |  | 60,620 |  |  |  | 168,474 |  |  |  | 155,187 |  |
| Total sales |  |  | 758,464 |  |  |  | 670,362 |  |  |  | 2,144,387 |  |  |  | 1,928,190 |  |
| Inter-segment sales |  |  | (2,627 | ) |  |  | (3,548 | ) |  |  | (8,081 | ) |  |  | (8,947 | ) |
| Total net sales (1) |  | $ | 755,837 |  |  | $ | 666,814 |  |  | $ | 2,136,306 |  |  | $ | 1,919,243 |  |

[0001564590-18-028539:mdna:32]
(1) Figures for the quarter and three quarters ended October 2, 2017 do not include sales of Anaren, as the acquisition occurred on April 18, 2018.

[0001564590-18-028539:mdna:33]
[same as prior period, unchanged from 0001564590-18-020718:mdna:33]

[0001564590-18-028539:mdna:34]
Total net sales increased $89.0 million, or 13.3%, from $666.8 million for the third quarter of 2017 to $755.8 million for the third quarter of 2018. Net sales for the PCB reportable segment, excluding inter-segment sales, increased $90.2 million, or 14.9%, from $606.2 million for the third quarter of 2017 to $696.4 million for the third quarter of 2018. This increase was primarily due to the acquisition of Anaren, which accounted for $64.1 million in sales in the third quarter of 2018, as well as higher demand in the

[0001564590-18-028539:mdna:35]
Aerospace and Defense, Computing/Storage/Peripherals and Cellular Phone end markets, partially offset by a decline in our Automotive end market. These changes resulted in an average PCB selling price increase of 15.5%, driven mainly by product mix shift, however the resulting increase in net sales was partially offset by a 6.7% decrease in the volume of PCB shipments as compared to the third quarter of 2017. Net sales for the E-M Solutions reportable segment decreased $1.1 million from $60.6 million for the third quarter of 2017 to $59.5 million for the third quarter of 2018. The decrease was primarily due to lower demand in our Automotive and Medical/Industrial/Instrumentation end markets.

[0001564590-18-028539:mdna:36]
Total net sales increased $217.1 million, or 11.3%, from $1,919.2 million for the first three quarters of 2017 to $2,136.3 million for the first three quarters of 2018. Net sales for the PCB reportable segment, excluding inter-segment sales, increased $203.7 million, or 11.5%, from $1,764.1 million for the first three quarters of 2017 to $1,967.8 million for the first three quarters of 2018. This increase was primarily due to the acquisition of Anaren, which accounted for $126.1 million in sales in the first three quarters of 2018.  Additionally, the increase in PCB sales was due to higher demand in the Aerospace and Defense, Medical/Industrial/Instrumentation and Computing/Storage/Peripherals end markets, partially offset by a decline in our Networking/Communications end market. These changes resulted in an average PCB selling price increase of 9.7%, driven mainly by product mix shift, however the resulting increase in net sales was partially offset by a 4.1% decrease in the volume of PCB shipments as compared to the first three quarters of 2017. Net sales for the E-M Solutions reportable segment increased $13.3 million, or 8.6%, from $155.2 million for the first three quarters of 2017 to $168.5 million for the first three quarters of 2018. The increase was primarily due to higher demand in our Automotive end market in the first two quarters of 2018, partially offset by the lower demand noted above in the third quarter of 2018.

[0001564590-18-028539:mdna:37]
[same as prior period, unchanged from 0001564590-18-020718:mdna:38]

[0001564590-18-028539:mdna:38]
Overall gross margin increased from 14.5% for the third quarter of 2017 to 17.1% for the third quarter of 2018. Gross margin for the PCB reportable segment increased from 15.5% for the third quarter of 2017 to 18.6% for the third quarter of 2018 primarily due to the acquisition of Anaren and higher capacity utilization at our Aerospace & Defense focused facilities. Gross margin for the E-M Solutions reportable segment decreased from 8.7% for the third quarter of 2017 to 8.0% for the third quarter of 2018 primarily due to unfavorable product mix.

[0001564590-18-028539:mdna:39]
Overall gross margin increased from 15.5% for the first three quarters of 2017 to 15.7% for the first three quarters of 2018. Gross margin for the PCB reportable segment increased from 16.6% for the first three quarters of 2017 to 16.8% for the first three quarters of 2018, primarily due to the acquisition of Anaren and higher capacity utilization at our Aerospace & Defense focused facilities, partially offset by decreased volumes at our Cellular facilities. Gross margin for the E-M Solutions reportable segment decreased from 7.5% for the first three quarters of 2017 to 7.3% for the first three quarters of 2018, primarily due to unfavorable product mix in the third quarter of 2018.

[0001564590-18-028539:mdna:40]
Capacity utilization is a key driver for us, particularly in our high volume facilities in Asia, as a significant portion of our operating costs are fixed in nature. Capacity utilization for the third quarter of 2017 in our Asia and North America PCB facilities was 86% and 55%, respectively, compared to 80% and 60%, respectively, in the third quarter of 2018. Capacity utilization for the first three quarters of 2017 in our Asia and North America PCB facilities was 83% and 55%, respectively, compared to 76% and 61%, respectively, in the first three quarters of 2018.

[0001564590-18-028539:mdna:41]
[same as prior period, unchanged from 0001564590-18-020718:mdna:42]

[0001564590-18-028539:mdna:42]
Selling and marketing expenses increased $2.2 million, from $16.3 million for the third quarter of 2017 to $18.5 million for the third quarter of 2018. Selling and marketing expenses increased $6.0 million, from $48.8 million for the first three quarters of 2017 to $54.8 million for the first three quarters of 2018. As a percentage of net sales, selling and marketing expenses was 2.4% for the third quarter of 2017, as compared to 2.5% for the third quarter of 2018, and 2.5% for the first three quarters of 2017, as compared to 2.6% for the first three quarters of 2018. The increase in selling and marketing expense for both the quarter and three quarters ended October 1, 2018 primarily related to the acquisition of Anaren on April 18, 2018.

[0001564590-18-028539:mdna:43]
[same as prior period, unchanged from 0001564590-18-020718:mdna:44]

[0001564590-18-028539:mdna:44]
General and administrative expenses increased $9.3 million from $30.6 million, or 4.6% of net sales, for the third quarter of 2017 to $39.9 million, or 5.3% of net sales, for the third quarter of 2018. General and administrative expenses increased $31.9 million from $89.5 million, or 4.6% of net sales, for the first three quarters of 2017 to $121.4 million, or 5.7% of net sales, for the first three quarters of 2018. The increase in expense primarily relates to general and administrative expenses incurred by Anaren post acquisition and $0.3 million and $11.1 million of acquisition-related costs during the quarter and three quarters ended October 1, 2018, respectively, associated with the acquisition of Anaren on April 18, 2018.

[0001564590-18-028539:mdna:45]
[same as prior period, unchanged from 0001564590-18-020718:mdna:46]

[0001564590-18-028539:mdna:46]
Other expense, net decreased $1.4 million from $21.4 million for the third quarter of 2017 to $20.0 million for the third quarter of 2018. Other expense, net decreased $6.3 million from $55.4 million for the first three quarters of 2017 to $49.1 million for the first three quarters of 2018. The decrease in other expense, net for both the quarter and three quarters ended October 1, 2018 was primarily the result of foreign currency gains of $1.8 million and $3.2 million for the quarter and three quarters ended October 1, 2018, respectively, due to the depreciation of the Chinese Renminbi (RMB) compared with foreign currency losses in the prior year

[0001564590-18-028539:mdna:47]
periods and the absence of $0.8 million loss on extinguishment of debt in 2018. This was partially offset by an increase in interest expense of $8.6 million and $16.3 million for the quarter and three quarters ended October 1, 2018, respectively, primarily related to the $600.0 million incremental borrowing in conjunction with the Anaren acquisition. We utilize the RMB at our China facilities for employee-related expenses, foreign currency denominated purchases, and other costs of running our operations in China.

[0001564590-18-028539:mdna:48]
[same as prior period, unchanged from 0001564590-18-020718:mdna:48]

[0001564590-18-028539:mdna:49]
The provision for income taxes increased by $6.3 million from $1.2 million for the third quarter of 2017 to $7.5 million for the third quarter of 2018. The provision for income taxes decreased by $64.9 million from $10.9 million of tax expense for the first three quarters of 2017 to $54.0 million of tax benefit for the first three quarters of 2018. The decrease in income tax expense for the first three quarters in 2018 was primarily due to a release of a portion of our valuation allowance, decreased operating income, additional benefits from the release of uncertain tax positions, additional tax incentives, and an offset by an additional accrual of tax expense related to a change in our policy of indefinite reinvestment outside of the U.S.

[0001564590-18-028539:mdna:50]
[same as prior period, unchanged from 0001564590-18-020718:mdna:50]

[0001564590-18-028539:mdna:51]
[same as prior period, unchanged from 0001564590-18-020718:mdna:51]

[0001564590-18-028539:mdna:52]
[same as prior period, unchanged from 0001564590-18-020718:mdna:52]

[0001564590-18-028539:mdna:53]
To the extent that a company’s accounting for certain income tax effects of the Tax Act is incomplete but is able to be reasonably estimated, the Company must record a provisional estimate in the financial statements. If a company cannot determine a provisional estimate to be included in the financial statements, it should continue to apply ASC 740 on the basis of the provisions of the tax laws that were in effect immediately before the enactment of the Tax Act. More specifically, SAB 118 summarizes a three-step process to be applied at each reporting period to account for and disclose the tax effects of the Tax Act. The steps are (1) to record the effects of the change in tax law for which accounting is complete; (2) to record provisional amounts (or adjustments to provisional amounts) for the effects of the tax law where accounting is not complete, but for which a reasonable estimate has been determined; and (3) where a reasonable estimate cannot yet be made, to continue to apply ASC 740 based on the tax law in effect prior to enactment of the Tax Act.

[0001564590-18-028539:mdna:54]
[same as prior period, unchanged from 0001564590-18-020718:mdna:54]

[0001564590-18-028539:mdna:55]
[same as prior period, unchanged from 0001564590-18-020718:mdna:55]

[0001564590-18-028539:mdna:56]
We have determined that the following provisions that are effective January 1, 2018 and relevant to us will not impact the current quarter tax expense, primarily as a result of the full valuation allowance in the U.S.: limitations on certain entertainment expenses, the inclusion of commissions and performance based compensation in determining the excessive compensation limitation, limitation on the current deductibility of net interest expense in excess of 30 percent of adjusted taxable income, and a minimum tax on certain foreign earnings in excess of 10 percent of the foreign subsidiaries tangible assets (i.e., global intangible low-taxed income or GILTI). The Company has decided to make a policy election to treat the GILTI tax as a period expense and as such, no U.S. deferred taxes will be calculated on foreign earnings that are expected to generate GILTI income when they reverse in future years.

[0001564590-18-028539:mdna:57]
Significant judgment is required in determining our worldwide provision for income taxes. In the ordinary course of our business, there are many transactions for which the ultimate tax determination is uncertain. Our calculations of income taxes are based on our interpretations of applicable tax laws in the jurisdictions in which we file.

[0001564590-18-028539:mdna:58]
Our effective tax rate was primarily impacted by tax rates in China and Hong Kong, the U.S. federal income tax rate, apportioned state income tax rates, generation of other credits and deductions available to us, as well as changes in valuation allowances, and certain non-deductible items. Certain foreign losses generated are not more likely than not to be realizable, and thus

[0001564590-18-028539:mdna:59]
no income tax benefit has been recognized on these losses. We had a net deferred income tax liability of approximately $18.9 million and $4.9 million as of October 1, 2018 and January 1, 2018, respectively.

[0001564590-18-028539:mdna:60]
[same as prior period, unchanged from 0001564590-18-020718:mdna:59]

[0001564590-18-028539:mdna:61]
[same as prior period, unchanged from 0001564590-18-020718:mdna:60]

[0001564590-18-028539:mdna:62]
Cash flow provided by operating activities during the first three quarters of 2018 was $121.4 million as compared to $180.1 million in the same period in 2017. The decrease in cash flow was primarily due to increased investment in working capital in 2018, primarily due to the impact of the Anaren Acquisition. As of October 1, 2018, we had net working capital of approximately $537.7 million compared to $501.0 million as of January 1, 2018.

[0001564590-18-028539:mdna:63]
Net cash used in investing activities was approximately $712.5 million for the first three quarters of 2018, reflecting $596.4 million for the acquisition of Anaren, net of debt assumed, and $116.1 million for purchases of property, plant and equipment. Net cash used in investing activities was approximately $91.9 million for the first three quarters of 2017 reflecting purchases of property, plant and equipment of $118.9 million less proceeds from sale of property, plant and equipment and assets held for sale of $27.0 million.

[0001564590-18-028539:mdna:64]
Net cash provided by financing activities was approximately $391.1 million for the first three quarters of 2018, primarily reflecting proceeds of $623.0 million from the incremental term and revolving loan borrowings, offset by the repayment of assumed long-term debt related to the acquisition of Anaren of $178.6 million, repayment of long-term debt $44.4 million, and payment of debt issuance costs and original issue discount of $9.2 million associated with the incremental term loans. Net cash used by financing activities was approximately $45.0 million for the first three quarters of 2017 reflecting proceeds from long-term debt totaling $725.0 million, offset by the repayment of $700.0 million of long-term debt, repayment of $63.0 million of a revolving loan, and payment of debt issuance costs and original issue discount of $7.1 million associated with the Term Loan Facility and Senior Notes.

[0001564590-18-028539:mdna:65]
As of October 1, 2018, we had cash and cash equivalents of approximately $208.0 million, of which approximately $180.9 million was held by our foreign subsidiaries, primarily in China. Cash and cash equivalents held by our foreign locations are expected to be used in local operations.

[0001564590-18-028539:mdna:66]
[same as prior period, unchanged from 0001564590-18-020718:mdna:65]

[0001564590-18-028539:mdna:67]
[same as prior period, unchanged from 0001564590-18-020718:mdna:66]

[0001564590-18-028539:mdna:68]
[same as prior period, unchanged from 0001564590-18-020718:mdna:67]

[0001564590-18-028539:mdna:69]
On April 18, 2018, we closed our $600.0 million commitment of incremental loans concurrent with the completion of our acquisition of Anaren. We used the proceeds of the incremental loans along with cash on hand to fund the purchase of the acquisition and to pay related fees and expenses. These incremental loans increased the existing balance of our Term Loan Facility due 2024 from $348.3 million to $948.3 million. The Term Loan Facility had an outstanding balance of $905.9 million as of October 1, 2018, of which $40.0 million is included in short-term debt and $865.9 million is included in long-term debt, was issued at a weighted average discount of 99.7% and bears interest, at our option, at a floating rate of LIBOR, plus an applicable interest margin of 2.5%, or an alternate base rate, (defined as the greater of the JP Morgan prime, the New York Fed bank rate plus 0.5% or LIBOR plus 1%), subject to a 1% floor plus an applicable margin of 1.5%. At October 1, 2018, the interest rate on the outstanding borrowings under the Term Loan Facility was 4.77%. There is no provision, other than an event of default, for the interest margin to increase. The Term Loan Facility will mature on September 28, 2024. The Term Loan Facility is secured by a significant amount of our domestic assets and a pledge of 65% of voting stock of our first tier foreign subsidiaries and is structurally senior to our Senior Notes and Convertible Senior Notes. See Senior Notes and Convertible Senior Notes below.

[0001564590-18-028539:mdna:70]
Subsequent to October 1, 2018, we made an optional debt principal prepayment of $40.0 million.  As a result of our prepayments, we are no longer required to make any quarterly scheduled payments. However, based on certain parameters defined in the Term Loan Facility, including a First Lien Leverage Ratio, we may be required to make an additional principal payment on an annual basis beginning after fiscal year 2018. Any remaining outstanding balance under the Term Loan Facility is due at the maturity date of September 28, 2024.

[0001564590-18-028539:mdna:71]
Borrowings under the Term Loan Facility are subject to certain affirmative and negative covenants, including limitations on indebtedness, corporate transactions, investments and dispositions, and share payments. At October 1, 2018, we were in compliance with the covenants under the Term Loan Facility.

[0001564590-18-028539:mdna:72]
[same as prior period, unchanged from 0001564590-18-020718:mdna:71]

[0001564590-18-028539:mdna:73]
[same as prior period, unchanged from 0001564590-18-020718:mdna:72]

[0001564590-18-028539:mdna:74]
Borrowings under the Senior Notes are subject to certain affirmative and negative covenants, including limitations on indebtedness, corporate transactions, investments, dispositions, and share payments. At October 1, 2018, we were in compliance with the covenants under the Senior Notes.

[0001564590-18-028539:mdna:75]
Convertible Senior Notes due 2020

[0001564590-18-028539:mdna:76]
[same as prior period, unchanged from 0001564590-18-020718:mdna:75]

[0001564590-18-028539:mdna:77]
[same as prior period, unchanged from 0001564590-18-020718:mdna:76]

[0001564590-18-028539:mdna:78]
[same as prior period, unchanged from 0001564590-18-020718:mdna:77]

[0001564590-18-028539:mdna:79]
The U.S. ABL consists of three tranches comprised of a revolving credit facility of up to $200.0 million, a letter of credit facility for up to $50.0 million, and swingline loans for up to $30.0 million, provided that at no time may amounts outstanding under the tranches exceed in aggregate $200.0 million or the applicable borrowing base, which is a percentage of the principal amount of Eligible Accounts, as defined in the U.S. ABL agreement. Borrowings under the U.S. ABL bear interest at either a floating rate of LIBOR plus a margin of 150 basis points or JP Morgan Chase Bank’s prime rate plus a margin of 50 basis points, at our option. At October 1, 2018, the interest rate on the outstanding borrowings under the U.S. ABL was 3.77%. The applicable margin can vary based on the remaining availability of the facility, from 125 to 175 basis points for LIBOR-based loans and from 25 to 75 basis points for JP Morgan Chase Bank’s prime rate-based loans. Other than availability and an event of default, there are no other provisions for the interest margin to increase. The U.S. ABL will mature on May 31, 2020. Loans made under the U.S. ABL are secured first by all of our domestic cash, receivables and certain inventories as well as by a second position against a significant amount of our domestic assets and a pledge of 65% of the voting stock of our first tier foreign subsidiaries and are structurally senior to our Senior Notes and Convertible Senior Notes. See Senior Notes and Convertible Senior Notes elsewhere in this section. At October 1, 2018, $40.0 million of the U.S. ABL was outstanding and classified as long-term debt, which is consistent with its maturity date.

[0001564590-18-028539:mdna:80]
The Asia ABL consists of two tranches comprised of a revolving credit facility for up to $150.0 million and a letter of credit facility for up to $100.0 million, provided that at no time may amounts outstanding under both tranches exceed in aggregate $150.0 million or the applicable borrowing base, which is a percentage of the principal amount of Eligible Accounts, as defined in the Asia ABL agreement. Borrowings under the Asia ABL bear interest at a floating rate of LIBOR plus 140 basis points. At October 1, 2018, the interest rate on the outstanding borrowings under the Asia ABL was 3.67%. There is no provision, other than an event of default, for the interest margin to increase. The Asia ABL will mature on May 22, 2020. Loans made under the Asia ABL are secured by a portion of our Asia cash and receivables and are structurally senior to our domestic obligations, including the Senior Notes and Convertible Senior Notes. See Senior Notes and Convertible Senior Notes elsewhere in this section. At October 1, 2018, $30.0 million of the Asia ABL was outstanding and classified as long-term debt, which is consistent with its maturity date.

[0001564590-18-028539:mdna:81]
We have up to $50.0 million and $100.0 million Letters of Credit Facilities under the U.S. ABL and the Asia ABL, respectively. As of October 1, 2018, letters of credit in the amount of $6.7 million were outstanding under the U.S. ABL and $9.3 million were outstanding under the Asia ABL with various expiration dates through December 2019. Available borrowing capacity under the U.S. ABL and the Asia ABL was $153.3 million and $110.7 million, respectively, which considers letters of credit outstanding at October 1, 2018.

[0001564590-18-028539:mdna:82]
We are required to pay a commitment fee of 0.25% to 0.375% per annum on any unused portion of the ABL Revolving Loans. We paid commitment fees of $0.3 million and $0.7 million for the quarter and three quarters ended October 1, 2018, respectively. Under the occurrence of certain events, the ABL Revolving Loans are subject to various financial and operational covenants, including maintaining minimum fixed charge coverage ratios. At October 1, 2018, we were in compliance with the covenants under the ABL Revolving Loans.

[0001564590-18-028539:mdna:83]
Other Credit Facility

[0001564590-18-028539:mdna:84]
Additionally, we are party to a revolving loan credit facility (Chinese Revolver) with a lender in China. Under this arrangement, the lender has made available to us approximately $30.6 million in unsecured borrowing with all terms of the borrowing to be negotiated at the time the Chinese Revolver is drawn upon. There are no commitment fees on the unused portion of

[0001564590-18-028539:mdna:85]
the Chinese Revolver, and this arrangement expires in January 2019. As of October 1, 2018, the Chinese Revolver had not been drawn upon.

[0001564590-18-028539:mdna:86]
[same as prior period, unchanged from 0001564590-18-020718:mdna:84]

[0001564590-18-028539:mdna:87]
[same as prior period, unchanged from 0001564590-18-020718:mdna:85]

[0001564590-18-028539:mdna:88]
The following table provides information on our contractual obligations as of October 1, 2018:

[0001564590-18-028539:mdna:89]
|  |  | Total |  |  | Less Than 1 year |  |  | 1 - 3 Years |  |  | 4 - 5 Years |  |  | After 5 Years |  |
| Contractual Obligations (1) |  | (In thousands) |  |
| Long-term debt obligations |  | $ | 1,350,879 |  |  | $ | 40,000 |  |  | $ | 70,000 |  |  | $ | — |  |  | $ | 1,240,879 |  |
| Convertible debt obligations |  |  | 249,985 |  |  |  | — |  |  |  | 249,985 |  |  |  | — |  |  |  | — |  |
| Interest on debt obligations |  |  | 413,850 |  |  |  | 59,396 |  |  |  | 133,918 |  |  |  | 136,974 |  |  |  | 83,562 |  |
| Derivative liabilities |  |  | 1,292 |  |  |  | 1,292 |  |  |  | — |  |  |  | — |  |  |  | — |  |
| Purchase obligations |  |  | 104,386 |  |  |  | 90,415 |  |  |  | 4,704 |  |  |  | 684 |  |  |  | 8,583 |  |
| Operating lease commitments |  |  | 48,128 |  |  |  | 29,489 |  |  |  | 9,237 |  |  |  | 4,175 |  |  |  | 5,227 |  |
| Total contractual obligations |  | $ | 2,168,520 |  |  | $ | 220,592 |  |  | $ | 467,844 |  |  | $ | 141,833 |  |  | $ | 1,338,251 |  |

[0001564590-18-028539:mdna:90]
(1) Unrecognized uncertain tax benefits of $40.4 million are not included in the table above as the settlement timing is uncertain.

[0001564590-18-028539:mdna:91]
[same as prior period, unchanged from 0001564590-18-020718:mdna:89]

[0001564590-18-028539:mdna:92]
[same as prior period, unchanged from 0001564590-18-020718:mdna:90]

[0001564590-18-028539:mdna:93]
[same as prior period, unchanged from 0001564590-18-020718:mdna:91]

[0001564590-18-028539:mdna:94]
[same as prior period, unchanged from 0001564590-18-020718:mdna:92]
