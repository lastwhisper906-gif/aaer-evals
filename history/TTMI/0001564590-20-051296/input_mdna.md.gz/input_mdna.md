# TTMI MD&A — 0001564590-20-051296


## mdna

[0001564590-20-051296:mdna:1]
[same as prior period, unchanged from 0001564590-20-037715:mdna:1]

[0001564590-20-051296:mdna:2]
[same as prior period, unchanged from 0001564590-20-037715:mdna:2]

[0001564590-20-051296:mdna:3]
[same as prior period, unchanged from 0001564590-20-037715:mdna:3]

[0001564590-20-051296:mdna:4]
[same as prior period, unchanged from 0001564590-20-037715:mdna:4]

[0001564590-20-051296:mdna:5]
The recent coronavirus (COVID-19) pandemic first caused some business disruption in our operations in China beginning in January 2020. By March 2020, the situation escalated as the scope of the COVID-19 pandemic worsened outside of the Asia-Pacific region, with Europe and North America being affected by the pandemic. There is significant uncertainty relating to the potential impacts of the COVID-19 pandemic, and we cannot reasonably estimate its duration or severity. The COVID-19 pandemic creates various global macroeconomic, customer demand, operational and supply chain risks any one of which could have a material and adverse impact on our business going forward. See Item 1A, Risk Factors, of Part II below for further information related to the COVID-19 pandemic. We have taken measures to protect our employees, suppliers and customers by implementing our pandemic recovery protocols, establishing situational leadership teams in Asia-Pacific and North America along with regularly scheduled executive review and planning calls, implementing global travel restrictions, and conforming to the guidance and direction of local governments and global health organizations. We are monitoring the impacts the COVID-19 pandemic has had, and continues to have, on our supply chain and are collaborating with our third-party partners with the goal of mitigating, to the extent reasonably practicable, significant delays in delivery of our products.

[0001564590-20-051296:mdna:6]
[same as prior period, unchanged from 0001564590-20-037715:mdna:6]

[0001564590-20-051296:mdna:7]
On April 17, 2020, we completed the sale of our Mobility business unit for a final purchase price of $569.2 million, received proceeds from the sale, net of cash disposed of $507.5 million, and recorded a gain on sale before income taxes of $237.3 million. Results related to our Mobility business unit are reported as discontinued operations for all periods presented. See Part I, Item 1, Note 2, Discontinued Operations, of the Notes to Consolidated Condensed Financial Statements included in this Quarterly Report on Form 10-Q for further information. Unless otherwise noted, amounts and disclosures throughout our Management’s Discussion and Analysis of Financial Condition and Results of Operations relate to our continuing operations.

[0001564590-20-051296:mdna:8]
While our customers include both OEMs and EMS providers, we measure customers based on OEM companies, as they are the ultimate end customers. Sales to our ten largest customers accounted for 40% and 38% of our net sales for the quarter and three quarters ended September 28, 2020, respectively. Sales to our ten largest customers accounted for 39% and 41% of our net sales for the quarter and three quarters ended September 30, 2019, respectively. We sell to OEMs both directly and indirectly through EMS providers.

[0001564590-20-051296:mdna:9]
[same as prior period, unchanged from 0001564590-20-037715:mdna:9]

[0001564590-20-051296:mdna:10]
|  |  | Quarter Ended |  |  |  | Three Quarters Ended |  |  |
| End Markets (1) |  | September 28, 2020 |  |  |  | September 30, 2019 |  |  |  | September 28, 2020 |  |  |  | September 30, 2019 |  |  |
| Aerospace and Defense |  |  | 36 |  | % |  |  | 32 |  | % |  |  | 35 |  | % |  |  | 32 |  | % |
| Automotive |  |  | 14 |  |  |  |  | 21 |  |  |  |  | 14 |  |  |  |  | 19 |  |  |
| Cellular Phone |  |  | — |  |  |  |  | — |  |  |  |  | — |  |  |  |  | — |  |  |
| Computing/Storage/Peripherals |  |  | 12 |  |  |  |  | 11 |  |  |  |  | 12 |  |  |  |  | 11 |  |  |
| Medical/Industrial/Instrumentation |  |  | 19 |  |  |  |  | 17 |  |  |  |  | 19 |  |  |  |  | 17 |  |  |
| Networking/Communications |  |  | 17 |  |  |  |  | 17 |  |  |  |  | 18 |  |  |  |  | 19 |  |  |
| Other (2) |  |  | 2 |  |  |  |  | 2 |  |  |  |  | 2 |  |  |  |  | 2 |  |  |
| Total |  |  | 100 |  | % |  |  | 100 |  | % |  |  | 100 |  | % |  |  | 100 |  | % |

[0001564590-20-051296:mdna:11]
[same as prior period, unchanged from 0001564590-20-037715:mdna:11]

[0001564590-20-051296:mdna:12]
[same as prior period, unchanged from 0001564590-20-037715:mdna:12]

[0001564590-20-051296:mdna:13]
[same as prior period, unchanged from 0001564590-20-037715:mdna:13]

[0001564590-20-051296:mdna:14]
We also manufacture certain components, assemblies, and subsystems which service our RF and Specialty Components (RF&S Components) customers. We recognize revenue at a point in time upon transfer of control of the products to our customer. Point in time recognition was determined as our customers do not simultaneously receive or consume the benefits provided by our performance and the asset being manufactured has alternative uses to us.

[0001564590-20-051296:mdna:15]
[same as prior period, unchanged from 0001564590-20-037715:mdna:15]

[0001564590-20-051296:mdna:16]
[same as prior period, unchanged from 0001564590-20-037715:mdna:16]

[0001564590-20-051296:mdna:17]
[same as prior period, unchanged from 0001564590-20-037715:mdna:17]

[0001564590-20-051296:mdna:18]
[same as prior period, unchanged from 0001564590-20-037715:mdna:18]

[0001564590-20-051296:mdna:19]
[same as prior period, unchanged from 0001564590-20-037715:mdna:19]

[0001564590-20-051296:mdna:20]
[same as prior period, unchanged from 0001564590-20-037715:mdna:20]

[0001564590-20-051296:mdna:21]
[same as prior period, unchanged from 0001564590-20-037715:mdna:21]

[0001564590-20-051296:mdna:22]
See Item 7, Management’s Discussion and Analysis of Financial Condition and Results of Operations, in our Annual Report on Form 10-K for the fiscal year ended December 30, 2019 for further discussion of critical accounting policies and estimates. There were no material changes to our critical accounting policies and estimates since December 30, 2019, except for the estimates used in

[0001564590-20-051296:mdna:23]
the quantitative goodwill impairment analysis performed as of September 28, 2020. See Part I, Item 1, Note 6, Goodwill, of the Notes to Consolidated Condensed Financial Statements included in this Quarterly Report on Form 10-Q for further information.

[0001564590-20-051296:mdna:24]
[same as prior period, unchanged from 0001564590-20-037715:mdna:23]

[0001564590-20-051296:mdna:25]
[same as prior period, unchanged from 0001564590-20-037715:mdna:24]

[0001564590-20-051296:mdna:26]
|  |  | Quarter Ended |  | Three Quarters Ended |
|  |  | September 28, 2020 |  |  |  | September 30, 2019 |  |  |  | September 28, 2020 |  |  |  | September 30, 2019 |  |  |
| Net sales |  |  | 100.0 |  | % |  |  | 100.0 |  | % |  |  | 100.0 |  | % |  |  | 100.0 |  | % |
| Cost of goods sold |  |  | 82.6 |  |  |  |  | 84.0 |  |  |  |  | 82.9 |  |  |  |  | 82.7 |  |  |
| Gross profit |  |  | 17.4 |  |  |  |  | 16.0 |  |  |  |  | 17.1 |  |  |  |  | 17.3 |  |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Selling and marketing |  |  | 3.1 |  |  |  |  | 3.2 |  |  |  |  | 3.0 |  |  |  |  | 3.2 |  |  |
| General and administrative |  |  | 5.7 |  |  |  |  | 6.2 |  |  |  |  | 7.0 |  |  |  |  | 6.0 |  |  |
| Research and development |  |  | 1.0 |  |  |  |  | 0.8 |  |  |  |  | 0.9 |  |  |  |  | 0.8 |  |  |
| Amortization of definite-lived intangibles |  |  | 2.0 |  |  |  |  | 1.8 |  |  |  |  | 1.8 |  |  |  |  | 2.3 |  |  |
| Impairment of goodwill |  |  | 13.4 |  |  |  |  | — |  |  |  |  | 4.4 |  |  |  |  | — |  |  |
| Total operating expenses |  |  | 25.2 |  |  |  |  | 12.0 |  |  |  |  | 17.1 |  |  |  |  | 12.3 |  |  |
| Operating (loss) income |  |  | (7.8 | ) |  |  |  | 4.0 |  |  |  |  | — |  |  |  |  | 5.0 |  |  |
| Other (expense) income: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Interest expense |  |  | (3.9 | ) |  |  |  | (3.8 | ) |  |  |  | (3.7 | ) |  |  |  | (3.9 | ) |  |
| Other, net |  |  | (0.5 | ) |  |  |  | 1.0 |  |  |  |  | — |  |  |  |  | 0.5 |  |  |
| Total other expense, net |  |  | (4.4 | ) |  |  |  | (2.8 | ) |  |  |  | (3.7 | ) |  |  |  | (3.4 | ) |  |
| (Loss) income from continuing operations before income taxes |  |  | (12.2 | ) |  |  |  | 1.2 |  |  |  |  | (3.7 | ) |  |  |  | 1.6 |  |  |
| Income tax benefit (provision) |  |  | 0.3 |  |  |  |  | (0.8 | ) |  |  |  | 0.2 |  |  |  |  | (0.3 | ) |  |
| Net (loss) income from continuing operations |  |  | (11.9 | ) | % |  |  | 0.4 |  | % |  |  | (3.5 | ) | % |  |  | 1.3 |  | % |

[0001564590-20-051296:mdna:27]
During the quarter ended September 28, 2020, our RF&S Components operating segment met the quantitative threshold for separate presentation of a reportable segment. In prior periods, we had two reportable segments: PCB and E-M Solutions. The RF&S Components reportable segment was previously aggregated with the PCB reportable segment. The PCB reportable segment is comprised of multiple operating segments. Factors considered in determining whether operating segments can be aggregated into reportable segments included similarity regarding economic characteristics, products, production process, type or class of customers, distribution methods and regulatory environments.

[0001564590-20-051296:mdna:28]
[same as prior period, unchanged from 0001564590-20-037715:mdna:27]

[0001564590-20-051296:mdna:29]
Total net sales decreased $20.6 million, or 3.9%, to $513.6 million for the third quarter of 2020 from $534.2 million for the third quarter of 2019. This decrease primarily resulted from a decrease in net sales for the E-M Solutions reportable segment of $29.5 million, or 43.6%, to $38.2 million for the third quarter of 2020 from $67.7 million for the third quarter of 2019 primarily due to winding down of this reportable segment and lower demand in our Automotive end market. Also contributing to this decrease in total net sales was a decrease in net sales for the RF&S Components reportable segment of $1.9 million, or 13.9%, to $11.7 million for the third quarter of 2020 from $13.6 million for the third quarter of 2019 primarily due to lower demand in our Networking/Communications end market. The decrease in total net sales was partially offset by an increase in net sales for the PCB reportable segment of $10.8 million, or 2.4%, to $463.7 million for the third quarter of 2020 from $452.8 million for the third quarter of 2019. The increase was primarily due to increased demand in our Aerospace and Defense, Medical/Industrial/Instrumentation, and Computing/Storage/Peripherals end markets, partially offset by lower demand in our Automotive end market. In addition, these changes in the PCB reportable segment resulted in an increase in the average price per square foot of 13.3%, driven mainly by product mix shift. The resulting increase in net sales, however, was partially offset by a 4.4% decrease in the volume of PCB shipments as compared to the third quarter of 2019.

[0001564590-20-051296:mdna:30]
Total net sales decreased $16.0 million, or 1.0%, to $1,581.5 million for the first three quarters of 2020 from $1,597.5 million for the first three quarters of 2019. This decrease primarily resulted from a decrease in net sales for the E-M Solutions reportable segment of $60.4 million, or 33.7%, to $118.6 million for the first three quarters of 2020 from $179.0 million for the first three quarters of 2019 primarily due to winding down of this reportable segment and lower demand in our Automotive end market. Also contributing to this decrease in total net sales was a decrease in net sales for the RF&S Components reportable segment of $18.5 million, or 35.7%, to $33.3 million for the first three quarters of 2020 from $51.7 million for the first three quarters of 2019 primarily due to a loss of a key customer in this reportable segment and coupled with the impact of COVID-19, resulted in lower demand in our Networking/Communications end market. The decrease in total net sales was partially offset by an increase in net sales for the

[0001564590-20-051296:mdna:31]
PCB reportable segment of $62.9 million, or 4.6%, to $1,429.6 million for the first three quarters of 2020 from $1,366.8 million for the first three quarters of 2019. The increase was primarily due to increased demand in our Aerospace and Defense, Medical/Industrial/Instrumentation, and Computing/Storage/Peripherals end markets, partially offset by lower demand in our Automotive and Networking/Communications end markets. In addition, these changes in the PCB reportable segment resulted in an increase in the average price per square foot of 20.7%, driven mainly by product mix shift. The resulting increase in net sales, however, was partially offset by a 14.2% decrease in the volume of PCB shipments as compared to the first three quarters of 2019.

[0001564590-20-051296:mdna:32]
[same as prior period, unchanged from 0001564590-20-037715:mdna:30]

[0001564590-20-051296:mdna:33]
Overall gross margin increased to 17.4% for the third quarter of 2020 from 16.0% for the third quarter of 2019. This increase was primarily driven by an increase in gross margin for the PCB reportable segment increased to 18.7% for the third quarter of 2020 from 16.7% for the third quarter of 2019, primarily due to higher volumes. Gross margin for the RF&S Components and E-M Solutions reportable segments decreased to 48.1% and 5.3%, respectively, for the third quarter of 2020 from 60.7% and 7.9%, respectively, for the third quarter of 2019, in each case primarily due to lower sales.

[0001564590-20-051296:mdna:34]
Overall gross margin decreased to 17.1% for the first three quarters of 2020 from 17.3% for the first three quarters of 2019. Gross margin for the PCB reportable segment increased to 18.8% for the first three quarters of 2020 from 17.6% for the first three quarters of 2019. However, the decrease in overall gross margin was primarily driven by the gross margin for the RF&S Components reportable segment, which decreased to 50.8% for the first three quarters of 2020 from 64.3% for the first three quarters of 2019, primarily due to lower sales. Furthermore, gross margin for the E-M Solutions reportable segment decreased to (0.2%) for the first three quarters of 2020 from 7.2% for the first three quarters of 2019, primarily due to lower sales and an additional provision for excess and obsolete inventories.

[0001564590-20-051296:mdna:35]
Capacity utilization is a key driver for us, which is measured by the actual production as a percentage of maximum capacity. This measure is particularly important in our high volume facilities in Asia, as a significant portion of our operating costs are fixed in nature. Capacity utilization for the third quarter of 2020 in our Asia and North America PCB facilities was 63% and 61%, respectively, compared to 60% and 58%, respectively, for the third quarter of 2019. Capacity utilization for the first three quarters of 2020 in our Asia and North America PCB facilities was 62% and 63%, respectively, compared to 61% and 60%, respectively for the first three quarters of 2019. The increase in capacity utilization in our Asia and North America PCB facilities was due to an increase in production related to increased sales in our Aerospace and Defense, Medical/Industrial/Instrumentation, and Computing/Storage/Peripherals end markets.

[0001564590-20-051296:mdna:36]
[same as prior period, unchanged from 0001564590-20-037715:mdna:35]

[0001564590-20-051296:mdna:37]
Selling and marketing expenses decreased $1.3 million, to $15.9 million for the third quarter of 2020 from $17.2 million for the third quarter of 2019. As a percentage of net sales, selling and marketing expenses was 3.1% for the third quarter of 2020, as compared to 3.2% for the third quarter of 2019. The decrease in selling and marketing expense for the third quarter of 2020 was primarily due to reduced travel expense due to the COVID-19 pandemic, which has decreased travel on a temporary basis.

[0001564590-20-051296:mdna:38]
Selling and marketing expenses decreased $3.6 million, to $48.0 million for the first three quarters of 2020 from $51.6 million for the first three quarters of 2019. As a percentage of net sales, selling and marketing expenses was 3.0% for the first three quarters of 2020, as compared to 3.2% for the first three quarters of 2019. The decrease in selling and marketing expense for the first three quarters of 2020 was primarily due to reduced travel and commission expense.

[0001564590-20-051296:mdna:39]
[same as prior period, unchanged from 0001564590-20-037715:mdna:38]

[0001564590-20-051296:mdna:40]
General and administrative expenses decreased $4.0 million to $29.1 million, or 5.7% of net sales, for the third quarter of 2020 from $33.1 million, or 6.2% of net sales, for the third quarter of 2019. This decrease was primarily due to a decrease in acquisition costs and supplies expense.

[0001564590-20-051296:mdna:41]
General and administrative expenses increased $15.2 million to $110.5 million, or 7.0% of net sales, for the first three quarters of 2020 from $95.3 million, or 6.0% of net sales, for the first three quarters of 2019. This increase was primarily due to the $14.7 million restructuring charges associated with the E-M Solutions business unit.

[0001564590-20-051296:mdna:42]
Impairment of Goodwill

[0001564590-20-051296:mdna:43]
During the third quarter of 2020, we performed an interim evaluation of goodwill as we believed there were impairment triggering events and circumstances that warranted an evaluation. These circumstances included a permanent loss of a key customer in the RF&S Components reporting unit that coupled with the impact of COVID-19, resulted in lower than anticipated results and continued decline in sales. As a result, we recorded a charge for the impairment of goodwill in the amount of $69.2 million in the third quarter of 2020.

[0001564590-20-051296:mdna:44]
Other Expense

[0001564590-20-051296:mdna:45]
Other expense, net increased $7.8 million to $22.5 million for the third quarter of 2020 from $14.5 million for the third quarter of 2019. This increase was primarily the result of foreign currency losses in the current quarter due to the strengthening of the Chinese Renminbi (RMB) in the third quarter of 2020 compared to the third quarter of 2019. We utilize the RMB at our China facilities for employee-related expenses, RMB denominated purchases, and other costs of running our operations in China.

[0001564590-20-051296:mdna:46]
Other expense, net increased $4.3 million to $57.9 million for the first three quarters of 2020 from $53.6 million for the first three quarters of 2019. This increase was primarily the result of foreign currency losses due to the strengthening of the RMB in the first three quarters of 2020 compared to the first three quarters of 2019. The foreign currency loss was partially offset by a decrease in interest expense of $3.6 million mainly as a result of the $400.0 million debt principal prepayment for the Term Loan made during the third quarter of 2020.

[0001564590-20-051296:mdna:47]
[same as prior period, unchanged from 0001564590-20-037715:mdna:44]

[0001564590-20-051296:mdna:48]
Income tax benefit increased by $5.5 million to $1.3 million of tax benefit for the third quarter of 2020 from $4.2 million of tax expense for the third quarter of 2019. The increase in income tax benefit for the third quarter of 2020 was primarily due to a decrease in continuing operating income, a change in the estimated tax benefit related to Global Intangible Low Taxed Income (GILTI) in the United States and unrealized foreign exchange gain and loss in Hong Kong.

[0001564590-20-051296:mdna:49]
The income tax benefit increased by $9.1 million to $3.6 million of tax benefit for the first three quarters of 2020 from $5.5 million of tax expense for the first three quarters of 2019. The increase in income tax benefit for the first three quarters of 2020 was primarily due to (i) a decrease in continuing operating income, (ii) an increase in the release of uncertain tax positions due to the expiration of the statute of limitation in foreign jurisdictions, netted against (iii) an increase related to the retroactive approval of the Company’s renewal application for High and New Tax Enterprise status in China, and (iv) an increase in the valuation allowance and withholding tax deferred tax liability related to the announced closure of two of the E-M Solutions plants.

[0001564590-20-051296:mdna:50]
Our effective tax rate is primarily impacted by tax rates in China and Hong Kong, the U.S. federal income tax rate, apportioned state income tax rates, the generation of credits and deductions available to us, as well as changes in valuation allowances and certain non-deductible items.

[0001564590-20-051296:mdna:51]
On March 27, 2020, the President of the United States signed the Coronavirus Aid, Relief, and Economic Security Act (CARES Act) providing economic relief to disruptions caused by the Coronavirus pandemic. Accounting Standard Codification (ASC) 740, Accounting for Income Taxes, requires companies to recognize the effect of tax law changes in the period of enactment regardless of the effective date of those tax law changes. We considered the impact to our financial statements of the corporate income tax aspects of the CARES Act and determined the impact is not material to our financial statements. The CARES Act includes a number of provisions, including the increase of IRC Section 163(j) interest expense deduction limitation of Adjusted Tax Income (ATI) from 30% to 50%. This is applicable to the 2019 and 2020 tax years. The Company accounted for such change in the Q1 2020 provision calculation. There are also provisions that allow for a 100% refund of Alternative Minimum Tax Credit carryforwards and which postpone tax compliance deadlines and payments ordinarily due April 15, 2020.

[0001564590-20-051296:mdna:52]
[same as prior period, unchanged from 0001564590-20-037715:mdna:49]

[0001564590-20-051296:mdna:53]
Our principal sources of liquidity have been cash provided by operations, the issuance of debt, and borrowings under our Revolving Credit Facility. Our principal uses of cash have been to finance capital expenditures, finance acquisitions, fund working capital requirements, and to repay existing debt. We anticipate that servicing debt, financing capital expenditures, financing acquisitions, and funding working capital requirements will continue to be the principal demands on our cash in the future.

[0001564590-20-051296:mdna:54]
Cash flow provided by operating activities for continuing operations during the first three quarters of 2020 was $192.2 million as compared to cash flow provided by operating activities for continuing operations of $169.6 million in the same period in 2019. The increase in cash flow was primarily due to less investment in working capital.

[0001564590-20-051296:mdna:55]
Net cash used in investing activities for continuing operations was approximately $75.0 million for the first three quarters of 2020, comprised primarily of $74.5 million for purchases of property, plant and equipment and other assets. Net cash used in investing activities for continuing operations was approximately $68.6 million for the first three quarters of 2019, reflecting $74.6 million for purchases of property, plant and equipment and other assets less proceeds from sale of property, plant and equipment and other assets of $6.0 million.

[0001564590-20-051296:mdna:56]
Net cash used in financing activities for continuing operations during the first three quarters of 2020 was $392.5 million, reflecting repayment of long-term debt of $400.0 million, offset by $7.3 million for capital equipment financing. Net cash used in financing activities was approximately $31.6 million for the first three quarters of 2019, reflecting repayment of long-term debt of $30.0 million and payment of debt issuance costs of $1.6 million.

[0001564590-20-051296:mdna:57]
We received proceeds from the sale of the Mobility business unit, net of cash disposed of $507.5 million during the first three quarters of 2020, which have been presented in the consolidated condensed statements of cash flows within net cash provided by investing activities from discontinued operations.

[0001564590-20-051296:mdna:58]
As of September 28, 2020, we had cash, cash equivalents, and restricted cash of approximately $663.3 million, of which approximately $233.8 million was held by our foreign subsidiaries, primarily in Hong Kong and China. As of September 28, 2020, our restricted cash balance of $250.0 million consisted of a specific deposit account to be used for principal payment on the Convertible Senior Notes due December 2020.

[0001564590-20-051296:mdna:59]
Our 2020 capital expenditures are expected to be approximately $100.0 million.

[0001564590-20-051296:mdna:60]
[same as prior period, unchanged from 0001564590-20-037715:mdna:56]

[0001564590-20-051296:mdna:61]
[same as prior period, unchanged from 0001564590-20-037715:mdna:57]

[0001564590-20-051296:mdna:62]
As of September 28, 2020, we had $1,090.0 million of outstanding debt, net of discount and debt issuance costs, composed of $402.2 million of Term Loan debt due September 2024, $370.3 million of Senior Notes due October 2025, $247.6 million of Convertible Senior Notes due December 2020, $40.0 million under the U.S. ABL, and $30.0 million under the Asia ABL.

[0001564590-20-051296:mdna:63]
Borrowings under the Term Loan Facility and Senior Notes Facility are subject to certain affirmative and negative covenants, including limitations on indebtedness, corporate transactions, investments, dispositions, and share payments. Under the occurrence of certain events, the ABL Revolving Loans are subject to various financial and operational covenants, including maintaining minimum fixed charge coverage ratios. As of September 28, 2020, we were in compliance with the covenants under the Term Loan Facility, Senior Notes Facility and ABL Revolving Loans.

[0001564590-20-051296:mdna:64]
[same as prior period, unchanged from 0001564590-20-037715:mdna:60]

[0001564590-20-051296:mdna:65]
[same as prior period, unchanged from 0001564590-20-037715:mdna:61]

[0001564590-20-051296:mdna:66]
[same as prior period, unchanged from 0001564590-20-037715:mdna:62]

[0001564590-20-051296:mdna:67]
[same as prior period, unchanged from 0001564590-20-037715:mdna:63]

[0001564590-20-051296:mdna:68]
[same as prior period, unchanged from 0001564590-20-037715:mdna:64]

[0001564590-20-051296:mdna:69]
[same as prior period, unchanged from 0001564590-20-037715:mdna:65]

[0001564590-20-051296:mdna:70]
[same as prior period, unchanged from 0001564590-20-037715:mdna:66]

[0001564590-20-051296:mdna:71]
Recently Issued Accounting Standards

[0001564590-20-051296:mdna:72]
[same as prior period, unchanged from 0001564590-20-037715:mdna:68]
