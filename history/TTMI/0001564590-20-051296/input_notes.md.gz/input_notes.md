# TTMI notes — 0001564590-20-051296


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureAndSignificantAccountingPoliciesTextBlock

[0001564590-20-051296:notes:1]
[same as prior period, unchanged from 0001564590-20-037715:notes:1]

[0001564590-20-051296:notes:2]
[same as prior period, unchanged from 0001564590-20-037715:notes:2]

[0001564590-20-051296:notes:3]
[same as prior period, unchanged from 0001564590-20-037715:notes:3]

[0001564590-20-051296:notes:4]
[same as prior period, unchanged from 0001564590-20-037715:notes:4]

[0001564590-20-051296:notes:5]
On January 19, 2020, the Company entered into a definitive equity interests purchase agreement with AKMMeadville Electronics (Xiamen) Co., Ltd (the Purchaser) for the sale of the Company’s following subsidiaries, which was completed on April 17, 2020: Shanghai Kaiser Electronics Co., Ltd. (SKE), Shanghai Meadville Electronics Co., Ltd. (SME), Shanghai Meadville Science & Technology Co., Ltd. (SP) and Guangzhou Meadville Electronics Co., Ltd. (GME) (collectively, the Mobility business unit). Prior to the closing of the sale of the Company’s Mobility business unit, all assets and liabilities attributable to the Mobility business unit have been aggregated under the captions “Current assets held for sale”, “Non-current assets held for sale”, “Current liabilities held for sale” and “Non-current liabilities held for sale”. For all periods presented in the consolidated condensed statements of operations, all sales, costs, expenses, income taxes and gain on sale attributable to the Mobility business unit have been aggregated under the caption “Income (loss) from discontinued operations, net of income taxes”. Prior year results have been recast to conform with the current presentation. Refer to Note 2, Discontinued Operations, for additional information.

[0001564590-20-051296:notes:6]
[same as prior period, unchanged from 0001564590-20-037715:notes:6]

[0001564590-20-051296:notes:7]
[same as prior period, unchanged from 0001564590-20-037715:notes:7]

[0001564590-20-051296:notes:8]
Certain prior year amounts in the consolidated condensed financial statements have been reclassified due to the sale of the Company’s Mobility business unit. Refer to Note 2, Discontinued Operations, for further information regarding this sale and the resulting prior year reclassifications.

[0001564590-20-051296:notes:9]
During the quarter ended September 28, 2020, the Company’s RF and Specialty Components (RF&S Components) operating segment met the quantitative threshold for separate presentation of a reportable segment. In prior periods, the Company had two reportable segments: PCB and E-M Solutions. The RF&S Components reportable segment was previously aggregated with the PCB reportable segment. As a result, certain prior year amounts and prior quarters within the current year have been reclassified to conform with this new presentation.

[0001564590-20-051296:notes:10]
Further, in 2020, the Company began presenting research and development expenses as a separate line item on the consolidated condensed statements of operations to better align with similar presentation made by peers and to provide additional disclosure that is meaningful for investors. The prior year consolidated condensed statements of operations were adjusted to conform with this new presentation. Research and development expense were previously presented within general and administrative expense on the consolidated condensed statements of operations.

[0001564590-20-051296:notes:11]
Immaterial Correction of Error

[0001564590-20-051296:notes:12]
During the quarter ended September 28, 2020, the Company paid for certain transaction costs related to the sale of the Mobility business unit totaling $11,043. This should have been recorded as an expense, which would have reduced the gain on sale of Mobility business unit, during the quarter ended June 29, 2020. The Company overstated both the income from discontinued operations, net of income taxes and net income by $11,043, both basic earnings per share from discontinued operations and basic earnings per share of $0.10 and $0.11 in the quarter and two quarters ended June 29, 2020, respectively, and both diluted earnings per share from discontinued operations and diluted earnings per share of $0.10 in the quarter and two quarters ended June 29, 2020. Further, total current liabilities were understated by $11,043 and retained earnings were overstated by $11,043 as of June 29, 2020. Management concluded that this error was not material to the consolidated condensed financial statements for the quarter and two quarters ended June 29, 2020. Prior period amounts have been revised to correct the error.

[0001564590-20-051296:notes:13]
[same as prior period, unchanged from 0001564590-20-037715:notes:9]

[0001564590-20-051296:notes:14]
Recently Adopted Accounting Standards

[0001564590-20-051296:notes:15]
In March 2020, the FASB issued ASU 2020-04, Reference Rate Reform (Topic 848): Facilitation of the Effects of Reference Rate Reform on Financial Reporting, which provides temporary relief to the GAAP guidance on contract modifications and hedge accounting to ease the financial reporting burdens of the expected market transition from LIBOR and other interbank offered rates to alternative rates. This guidance became effective beginning on March 12, 2020 and will remain in effect through December 31, 2022. The guidance on contract modifications can be applied prospectively from any date beginning March 12, 2020 and may also be applied to modifications of existing contracts made earlier in the interim period that included March 12, 2020. The guidance on hedging can be applied to eligible hedging relationships existing at the beginning of the interim period that included March 12, 2020 and to new eligible hedging relationships entered into after the beginning of that interim period. The Company adopted this ASU and it did not have a material impact on its financial statements.

[0001564590-20-051296:notes:16]
In June 2016, the FASB issued ASU 2016-13, Financial Instruments - Credit Losses (Topic 326): Measurement of Credit Losses on Financial Instruments, which amends the current accounting guidance and requires the measurement of all expected losses based on historical experience, current conditions and reasonable and supportable forecasts. For trade receivables, loans, and other financial instruments, the Company will be required to use a forward-looking expected loss model that reflects losses that are probable rather than the incurred loss model for recognizing credit losses. The standard became effective for interim and annual periods beginning after December 15, 2019. Application of the amendments is through a cumulative-effect adjustment to retained earnings as of the effective date. The Company adopted this ASU as of December 31, 2019 and it did not have a material impact on its financial statements.

[0001564590-20-051296:notes:17]
Recently Issued Accounting Standards Not Yet Adopted

[0001564590-20-051296:notes:18]
In December 2019, the FASB issued ASU 2019-12, Income Taxes (Topic 740): Simplifying the Accounting for Income Taxes, which is intended to simplify various aspects related to accounting for income taxes. ASU 2019-12 removes certain exceptions to the general principles in Topic 740 and also clarifies and amends existing guidance to improve consistent application. The guidance is effective for fiscal years beginning after December 15, 2020, including interim periods within those fiscal years. Early adoption is permitted. The Company has evaluated the new guidance to determine the impact it may have on its consolidated condensed financial statements and related disclosures and the impact is not expected to be material.

[0001564590-20-051296:notes:19]
In August 2018, the FASB issued ASU 2018-14, Compensation—Retirement Benefits—Defined Benefit Plans—General (Subtopic 715-20)—Disclosure Framework—Changes to the Disclosure Requirements for Defined Benefit Plans. The amendments in this update change the disclosure requirements for employers that sponsor defined benefit pension and/or other postretirement benefit plans. It eliminates requirements for certain disclosures that are no longer considered cost beneficial and requires new disclosures that the FASB considers pertinent. The guidance is effective for fiscal years ending after December 15, 2020. Early adoption is permitted. The Company does not anticipate the adoption will have a material impact on its consolidated condensed financial statements and related disclosures.


## us-gaap:DisposalGroupsIncludingDiscontinuedOperationsDisclosureTextBlock

[0001564590-20-051296:notes:20]
[same as prior period, unchanged from 0001564590-20-037715:notes:16]

[0001564590-20-051296:notes:21]
On January 19, 2020, the Company entered into a definitive equity interests purchase agreement for the sale of the Company’s Mobility business unit. The sale was completed on April 17, 2020 for a base purchase price of $550,000, subject to customary purchase price adjustments. The base purchase price does not include certain accounts receivable of the divested business, which were estimated to total approximately $95,000. Subsequently, the final purchase price was $569,246 after customary purchase price adjustments, which did not include approximately $83,000 accounts receivable of the divested business.

[0001564590-20-051296:notes:22]
On April 18, 2020, the Company also entered into a Transition Services Agreement (TSA) with the Purchaser pursuant to which the Purchaser is receiving certain services (the Services) to enable it to operate the Mobility business unit after the closing of the sale of the Mobility business unit. The Services include finance and accounting, human resources, legal and compliance, sales, information technology, and other corporate support services. Under the TSA, the Services are being provided at cost for a period of up to 24 months. There was no material impact on the Company’s consolidated condensed financial statements.

[0001564590-20-051296:notes:23]
Further, on June 29, 2020, the Company entered into a Sales Force Agreement with the Purchaser pursuant to which the Company’s sales representatives will assist the Purchaser in selling PCBs manufactured by the Purchaser to certain customers for a commission for a period up to April 17, 2021. There was no material impact on the Company’s consolidated condensed financial statements.

[0001564590-20-051296:notes:24]
[same as prior period, unchanged from 0001564590-20-037715:notes:20]

[0001564590-20-051296:notes:25]
[same as prior period, unchanged from 0001564590-20-037715:notes:21]

[0001564590-20-051296:notes:26]
|  |  | Quarter Ended |  |  | Three Quarters Ended |  |
|  |  | September 28, |  |  | September 30, |  |  | September 28, |  |  | September 30, |  |
|  |  | 2020 |  |  | 2019 |  |  | 2020 |  |  | 2019 |  |
|  |  | (In thousands, except per share data) |  |
| Net sales |  | $ | — |  |  | $ | 182,644 |  |  | $ | 143,951 |  |  | $ | 372,560 |  |
| Cost of goods sold |  |  | — |  |  |  | 164,068 |  |  |  | 136,800 |  |  |  | 372,358 |  |
| Gross profit |  |  | — |  |  |  | 18,576 |  |  |  | 7,151 |  |  |  | 202 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Selling and marketing |  |  | — |  |  |  | 1,247 |  |  |  | 1,461 |  |  |  | 3,557 |  |
| General and administrative |  |  | — |  |  |  | 1,424 |  |  |  | 2,317 |  |  |  | 4,166 |  |
| Research and development |  |  | — |  |  |  | — |  |  |  | 147 |  |  |  | — |  |
| Amortization of definite-lived intangibles |  |  | — |  |  |  | 675 |  |  |  | 809 |  |  |  | 2,023 |  |
| Total operating expenses |  |  | — |  |  |  | 3,346 |  |  |  | 4,734 |  |  |  | 9,746 |  |
| Operating income (loss) |  |  | — |  |  |  | 15,230 |  |  |  | 2,417 |  |  |  | (9,544 | ) |
| Other (expense) income: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Interest expense |  |  | — |  |  |  | (145 | ) |  |  | (223 | ) |  |  | (1,016 | ) |
| Gain on sale of the Mobility business unit |  |  | — |  |  |  | — |  |  |  | 237,253 |  |  |  | — |  |
| Other, net |  |  | — |  |  |  | 2,251 |  |  |  | 1,160 |  |  |  | 3,692 |  |
| Total other income, net |  |  | — |  |  |  | 2,106 |  |  |  | 238,190 |  |  |  | 2,676 |  |
| Income (loss) from discontinued operations before income taxes |  |  | — |  |  |  | 17,336 |  |  |  | 240,607 |  |  |  | (6,868 | ) |
| Income tax benefit (provision) |  |  | 20,021 |  |  |  | (3,859 | ) |  |  | (46,686 | ) |  |  | 1,786 |  |
| Income (loss) from discontinued operations, net of income taxes |  | $ | 20,021 |  |  | $ | 13,477 |  |  | $ | 193,921 |  |  | $ | (5,082 | ) |
| Earnings (loss) per share from discontinued operations: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic earnings (loss) per share |  | $ | 0.19 |  |  | $ | 0.13 |  |  | $ | 1.83 |  |  | $ | (0.05 | ) |
| Diluted earnings (loss) per share |  | $ | 0.19 |  |  | $ | 0.13 |  |  | $ | 1.83 |  |  | $ | (0.05 | ) |

[0001564590-20-051296:notes:27]
There was no depreciation expense related to the discontinued operations for the quarter ended September 28, 2020 and depreciation expense for the quarter ended September 30, 2019 was $18,704. Depreciation expense related to the discontinued operations for the three quarters ended September 28, 2020 and September 30, 2019 was $21,382 and $54,645, respectively.

[0001564590-20-051296:notes:28]
During the quarter and three quarters ended September 28, 2020, the Company’s income tax expense related to the discontinued operations was impacted by a net discrete tax benefit of $20,021 and a net discrete tax expense of $46,686, respectively. As a result of the sale of the Mobility business unit, the discrete income tax benefit during the quarter ended September 28, 2020 is due to recognition of additional Internal Revenue Code (IRC) Section 250 deduction and foreign tax credit benefits. The net income tax expense for the three quarters ended September 28, 2020 is related mainly to (i) China withholding tax related to gain on sale, (ii) U.S. income tax related to Global Intangible Low Taxed Income (GILTI) inclusion net of IRC Section 250 deduction and foreign tax credits, and offset by (iii) release of U.S. uncertain tax positions.

[0001564590-20-051296:notes:29]
Proceeds from the sale of the Company’s Mobility business unit have been presented in the consolidated condensed statements of cash flows within net cash provided by investing activities from discontinued operations. The following is a reconciliation of the gain recorded for the sale of the Company’s Mobility business unit (in thousands):

[0001564590-20-051296:notes:30]
| Net proceeds from the sale of the Mobility business unit (1) |  | $ | 569,246 |  |
| Mobility business unit assets: |  |  |  |  |
| Cash and cash equivalents |  |  | 12,513 |  |
| Restricted cash |  |  | 35,412 |  |
| Accounts receivable, net |  |  | 12 |  |
| Contract assets |  |  | 40,072 |  |
| Inventories |  |  | 4,988 |  |
| Prepaid expenses and other current assets |  |  | 4,593 |  |
| Property, plant and equipment, net |  |  | 328,648 |  |
| Goodwill |  |  | 68,267 |  |
| Definite-lived intangibles, net |  |  | 5,520 |  |
| Deposits and other non-current assets |  |  | 6,291 |  |
| Total Mobility business unit assets |  |  | 506,316 |  |
| Mobility business unit liabilities: |  |  |  |  |
| Accounts payable |  |  | 142,636 |  |
| Accrued salaries, wages and benefits |  |  | 9,392 |  |
| Other current liabilities |  |  | 8,890 |  |
| Other long-term liabilities |  |  | 303 |  |
| Total Mobility business unit liabilities |  |  | 161,221 |  |
| Derecognition of foreign currency translation adjustments and unrealized losses on cash flow hedges recorded in accumulated other comprehensive loss |  |  | 26,957 |  |
| Other transaction costs incurred as part of the sale of the Mobility business unit (2) |  |  | 13,855 |  |
| Gain on sale of the Mobility business unit before income taxes |  | $ | 237,253 |  |

[0001564590-20-051296:notes:31]
| (1) | Net proceeds from the sale of the Mobility business unit are net of customary purchase price adjustments. |

[0001564590-20-051296:notes:32]
| (2) | Costs directly incurred as a result of the sale of the Company’s Mobility business unit, including bank fees, legal fees, professional fees, and other costs. |


## us-gaap:ScheduleOfDisposalGroupsIncludingDiscontinuedOperationsIncomeStatementBalanceSheetAndAdditionalDisclosuresTextBlock

[0001564590-20-051296:notes:33]
[same as prior period, unchanged from 0001564590-20-037715:notes:29]


## us-gaap:LesseeOperatingLeasesTextBlock

[0001564590-20-051296:notes:34]
[same as prior period, unchanged from 0001564590-20-037715:notes:30]

[0001564590-20-051296:notes:35]
The Company leases some of its manufacturing and assembly plants, sales offices and equipment under non-cancellable operating leases that expire at various dates through 2049. The majority of the Company’s lease arrangements are comprised of fixed payments and certain leases consist of variable payments based on equipment usage. These variable payments are not included in the measurement of the right-of-use (ROU) asset or lease liability due to uncertainty of the payment amount and are recorded as lease expense in the period incurred. Certain leases contain renewal provisions at the Company’s option. Most of the leases require the Company to pay for certain other costs such as property taxes and maintenance. Certain leases also contain rent escalation clauses (step rents) that require additional rental amounts in the later years of the term. Rent expense for leases with step rents is recognized on a straight-line basis over the minimum lease term. The lease agreements do not contain any material residual value guarantees or material restrictive covenants.

[0001564590-20-051296:notes:36]
[same as prior period, unchanged from 0001564590-20-037715:notes:32]

[0001564590-20-051296:notes:37]
|  |  | Quarter Ended |  |  | Three Quarters Ended |  |
|  |  | September 28, 2020 |  |  | September 30, 2019 |  |  | September 28, 2020 |  |  | September 30, 2019 |  |
|  |  | (In thousands) |  |
| Operating lease cost |  | $ | 2,333 |  |  | $ | 2,202 |  |  | $ | 7,041 |  |  | $ | 6,367 |  |
| Variable lease cost |  |  | 133 |  |  |  | 137 |  |  |  | 376 |  |  |  | 398 |  |
| Short-term lease cost |  |  | 84 |  |  |  | 95 |  |  |  | 482 |  |  |  | 280 |  |

[0001564590-20-051296:notes:38]
[same as prior period, unchanged from 0001564590-20-037715:notes:34]

[0001564590-20-051296:notes:39]
|  |  | Three Quarters Ended |  |
|  |  | September 28, 2020 |  |  | September 30, 2019 |  |
|  |  | (In thousands) |  |
| Cash paid for amounts included in the measurement of lease liabilities: |  |  |  |  |  |  |  |  |
| Operating cash flows from operating leases |  | $ | 6,636 |  |  | $ | 6,240 |  |
| Right-of-use assets obtained in exchange for new lease obligations: |  |  |  |  |  |  |  |  |
| Operating leases |  |  | 6,559 |  |  |  | 13,058 |  |

[0001564590-20-051296:notes:40]
[same as prior period, unchanged from 0001564590-20-037715:notes:36]

[0001564590-20-051296:notes:41]
|  |  | As of |  |
|  |  | September 28, 2020 |  |  | December 30, 2019 |  |
|  |  | (In thousands) |  |
| Operating lease right-of-use assets |  | $ | 22,993 |  |  | $ | 22,173 |  |
| Other current liabilities |  |  | 7,945 |  |  |  | 7,111 |  |
| Operating lease liabilities |  |  | 15,885 |  |  |  | 15,413 |  |
| Total operating lease liabilities |  | $ | 23,830 |  |  | $ | 22,524 |  |

[0001564590-20-051296:notes:42]
|  |  | As of |  |
|  |  | September 28, 2020 |  |  | December 30, 2019 |  |
| Weighted average remaining lease term |  | 4.1 years |  |  | 4.4 years |  |
| Weighted average discount rate |  |  | 3.53 | % |  |  | 3.92 | % |

[0001564590-20-051296:notes:43]
[same as prior period, unchanged from 0001564590-20-037715:notes:39]

[0001564590-20-051296:notes:44]
|  |  | (In thousands) |  |
| Less than one year |  | $ | 9,309 |  |
| 1 - 2 years |  |  | 5,114 |  |
| 2 - 3 years |  |  | 4,030 |  |
| 3 - 4 years |  |  | 3,011 |  |
| 4 - 5 years |  |  | 2,046 |  |
| Thereafter |  |  | 2,148 |  |
| Total lease payments |  |  | 25,658 |  |
| Less imputed interest |  |  | (1,828 | ) |
| Total |  | $ | 23,830 |  |

[0001564590-20-051296:notes:45]
| (1) | Excludes $969 of legally binding minimum lease payments for leases signed but not yet commenced. |


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0001564590-20-051296:notes:46]
[same as prior period, unchanged from 0001564590-20-037715:notes:42]

[0001564590-20-051296:notes:47]
As of September 28, 2020, the aggregate amount of the transaction price allocated to remaining performance obligations for long-term contracts was $19,606. The Company expects to recognize revenue on approximately 86% of the remaining performance obligations for the Company’s long-term contracts over the next twelve months with the remaining amount recognized thereafter. The remaining performance obligations for the Company’s short-term contracts are expected to be recognized within one year.

[0001564590-20-051296:notes:48]
Revenue from products and services transferred to customers over time and at a point in time accounted for 98% and 2%, respectively, of the Company’s revenue for the quarter and three quarters ended September 28, 2020. Revenue from products and services transferred to customers over time and at a point in time accounted for 97% and 3%, respectively, of the Company’s revenue for the quarter and three quarters ended September 30, 2019.

[0001564590-20-051296:notes:49]
[same as prior period, unchanged from 0001564590-20-037715:notes:45]

[0001564590-20-051296:notes:50]
|  | Quarter Ended September 28, 2020 |  |  | Quarter Ended September 30, 2019 |  |  |
|  | PCB |  |  | RF&S Components |  |  | E-M Solutions |  | Total |  |  | PCB |  |  | RF&S Components |  |  | E-M Solutions |  | Total |  |  |
| End Markets | (In thousands) |  |  |
| Aerospace and Defense | $ | 182,709 |  |  | $ | 180 |  |  | $ | 16 |  | $ | 182,905 |  |  | $ | 170,651 |  |  | $ | 729 |  |  | $ | 1 |  | $ | 171,381 |  |  |
| Automotive |  | 64,375 |  |  |  | — |  |  |  | 8,891 |  |  | 73,266 |  |  |  | 72,597 |  |  |  | — |  |  |  | 39,559 |  |  | 112,156 |  |  |
| Cellular Phone |  | 39 |  |  |  | — |  |  |  | — |  |  | 39 |  |  |  | 3,512 |  |  |  | — |  |  |  | — |  |  | 3,512 |  |  |
| Computing/Storage/ Peripherals |  | 62,606 |  |  |  | 186 |  |  |  | 30 |  |  | 62,822 |  |  |  | 57,367 |  |  |  | 592 |  |  |  | 72 |  |  | 58,031 |  |  |
| Medical/Industrial/ Instrumentation |  | 92,059 |  |  |  | 742 |  |  |  | 2,769 |  |  | 95,570 |  |  |  | 84,178 |  |  |  | 705 |  |  |  | 5,775 |  |  | 90,658 |  |  |
| Networking/Communications |  | 55,905 |  |  |  | 7,203 |  |  |  | 27,185 |  |  | 90,293 |  |  |  | 58,782 |  |  |  | 7,971 |  |  |  | 22,746 |  |  | 89,499 |  |  |
| Other |  | 5,971 |  |  |  | 3,431 |  |  |  | (721 | ) |  | 8,681 |  |  |  | 5,729 |  |  |  | 3,647 |  |  |  | (440 | ) |  | 8,936 |  |  |
| Total | $ | 463,664 |  |  | $ | 11,742 |  |  | $ | 38,170 |  | $ | 513,576 |  |  | $ | 452,816 |  |  | $ | 13,644 |  |  | $ | 67,713 |  | $ | 534,173 |  |  |

[0001564590-20-051296:notes:51]
|  | Three Quarters Ended September 28, 2020 |  |  | Three Quarters Ended September 30, 2019 |  |  |
|  | PCB |  |  | RF&S Components |  |  | E-M Solutions |  | Total |  |  | PCB |  |  | RF&S Components |  |  | E-M Solutions |  | Total |  |  |
| End Markets | (In thousands) |  |  |
| Aerospace and Defense | $ | 555,771 |  |  | $ | 189 |  |  | $ | 36 |  | $ | 555,996 |  |  | $ | 510,210 |  |  | $ | 777 |  |  | $ | 367 |  | $ | 511,354 |  |  |
| Automotive |  | 183,896 |  |  |  | — |  |  |  | 27,816 |  |  | 211,712 |  |  |  | 227,239 |  |  |  | — |  |  |  | 83,317 |  |  | 310,556 |  |  |
| Cellular Phone |  | 1,203 |  |  |  | — |  |  |  | — |  |  | 1,203 |  |  |  | 5,416 |  |  |  | — |  |  |  | — |  |  | 5,416 |  |  |
| Computing/Storage/ Peripherals |  | 192,275 |  |  |  | 663 |  |  |  | 170 |  |  | 193,108 |  |  |  | 170,914 |  |  |  | 1,373 |  |  |  | 261 |  |  | 172,548 |  |  |
| Medical/Industrial/ Instrumentation |  | 292,794 |  |  |  | 2,336 |  |  |  | 9,714 |  |  | 304,844 |  |  |  | 246,889 |  |  |  | 2,629 |  |  |  | 23,583 |  |  | 273,101 |  |  |
| Networking/ Communications |  | 178,428 |  |  |  | 19,173 |  |  |  | 82,429 |  |  | 280,030 |  |  |  | 188,069 |  |  |  | 37,192 |  |  |  | 72,011 |  |  | 297,272 |  |  |
| Other |  | 25,262 |  |  |  | 10,913 |  |  |  | (1,548 | ) |  | 34,627 |  |  |  | 18,025 |  |  |  | 9,754 |  |  |  | (531 | ) |  | 27,248 |  |  |
| Total | $ | 1,429,629 |  |  | $ | 33,274 |  |  | $ | 118,617 |  | $ | 1,581,520 |  |  | $ | 1,366,762 |  |  | $ | 51,725 |  |  | $ | 179,008 |  | $ | 1,597,495 |  |  |


## us-gaap:AdditionalFinancialInformationDisclosureTextBlock

[0001564590-20-051296:notes:52]
[same as prior period, unchanged from 0001564590-20-037715:notes:48]

[0001564590-20-051296:notes:53]
|  |  | As of |  |
|  |  | September 28, 2020 |  |  | December 30, 2019 |  |
|  |  | (In thousands) |  |
| Inventories: |  |  |  |  |  |  |  |  |
| Raw materials |  | $ | 116,090 |  |  | $ | 97,660 |  |
| Work-in-process |  |  | 8,059 |  |  |  | 10,898 |  |
| Finished goods |  |  | 3,439 |  |  |  | 5,195 |  |
|  |  | $ | 127,588 |  |  | $ | 113,753 |  |
| Property, plant and equipment, net: |  |  |  |  |  |  |  |  |
| Land and land use rights |  | $ | 62,009 |  |  | $ | 62,009 |  |
| Buildings and improvements |  |  | 397,361 |  |  |  | 381,980 |  |
| Machinery and equipment |  |  | 833,790 |  |  |  | 777,916 |  |
| Furniture and fixtures and other |  |  | 10,461 |  |  |  | 10,329 |  |
| Construction-in-progress |  |  | 27,604 |  |  |  | 58,195 |  |
|  |  |  | 1,331,225 |  |  |  | 1,290,429 |  |
| Less: Accumulated depreciation |  |  | (676,388 | ) |  |  | (612,228 | ) |
|  |  | $ | 654,837 |  |  | $ | 678,201 |  |
| Other current liabilities: |  |  |  |  |  |  |  |  |
| Income taxes payable |  | $ | 14,489 |  |  | $ | 13,035 |  |
| Interest |  |  | 13,739 |  |  |  | 8,893 |  |
| Sales return and allowances |  |  | 12,754 |  |  |  | 13,544 |  |
| Restructuring |  |  | 11,695 |  |  |  | 502 |  |
| Other |  |  | 62,641 |  |  |  | 56,508 |  |
|  |  | $ | 115,318 |  |  | $ | 92,482 |  |


## us-gaap:GoodwillDisclosureTextBlock

[0001564590-20-051296:notes:54]
[same as prior period, unchanged from 0001564590-20-037715:notes:50]

[0001564590-20-051296:notes:55]
As of September 28, 2020 and December 30, 2019, goodwill by reportable segment was as follows:

[0001564590-20-051296:notes:56]
|  |  | PCB |  | RF&S Components |  | Total |  |
|  |  | (In thousands) |  |
| Balance as of December 30, 2019 |  |  |  |  |  |  |  |  |  |  |
| Goodwill |  | $ | 700,724 |  | $ | 177,200 |  | $ | 877,924 |  |
| Accumulated impairment loss |  |  | (171,400 | ) |  | — |  |  | (171,400 | ) |
|  |  |  | 529,324 |  |  | 177,200 |  |  | 706,524 |  |
| Impairment loss during the three quarters ended September 28, 2020 |  |  | — |  |  | (69,200 | ) |  | (69,200 | ) |
| Balance as of September 28, 2020 |  |  |  |  |  |  |  |  |  |  |
| Goodwill |  |  | 700,724 |  |  | 177,200 |  |  | 877,924 |  |
| Accumulated impairment loss |  |  | (171,400 | ) |  | (69,200 | ) |  | (240,600 | ) |
|  |  | $ | 529,324 |  | $ | 108,000 |  | $ | 637,324 |  |

[0001564590-20-051296:notes:57]
The Company evaluates its goodwill on an annual basis during its fourth fiscal quarter and at other times when events or changes in circumstances – such as significant adverse changes in the business climate or operating results or changes in management strategy, coupled with a decline in the market price of its stock and market capitalization – indicate that there may be a potential impairment.

[0001564590-20-051296:notes:58]
During the third quarter of 2020, the Company determined that there was a permanent loss of a key customer in the RF&S Components reporting unit that coupled with the impact of COVID-19, resulted in lower than anticipated results and continued decline in sales. The Company considered these factors to be indicators of potential impairment requiring the Company to test the related goodwill for impairment. As of September 28, 2020, the Company completed a quantitative goodwill impairment analysis related to its RF&S Components reporting unit by comparing the fair value of the reporting unit with its carrying amount. The Company determined the fair value of the reporting unit by using both a discounted cash flow (DCF) and a market approach. Under the market

[0001564590-20-051296:notes:59]
approach, the Company used revenue and earnings multiples based on comparable industry multiples to estimate the fair value of the reporting unit.

[0001564590-20-051296:notes:60]
Under the DCF approach, the Company estimated the future cash flows, as well as selected a risk-adjusted discount rate to measure the present value of the anticipated cash flows. When determining future cash flow estimates, the Company considered historical results adjusted to reflect current and anticipated future operating conditions. The Company estimated cash flows for the reporting unit over a discrete period and a terminal period (considering expected long-term growth rates and trends).

[0001564590-20-051296:notes:61]
Based on its analysis, the Company determined that the fair value of the RF&S Components reporting unit was less than its carrying value and recorded a non-cash goodwill impairment charge of $69,200 during the quarter ended September 28, 2020. If the Company’s future cash flow projections and other fair value assumptions for its reporting unit change, the Company may be subject to potential additional impairment in subsequent quarters. Estimating the fair value of the reporting unit requires the Company to make assumptions and estimates in such areas as future economic conditions, industry-specific conditions, product pricing, and necessary capital expenditures. The use of different assumptions or estimates for future cash flows, discount rates, or terminal growth rates could produce substantially different estimates of the fair value of the reporting unit.


## us-gaap:IntangibleAssetsDisclosureTextBlock

[0001564590-20-051296:notes:62]
[same as prior period, unchanged from 0001564590-20-037715:notes:54]

[0001564590-20-051296:notes:63]
As of September 28, 2020 and December 30, 2019, the components of definite-lived intangibles were as follows:

[0001564590-20-051296:notes:64]
|  |  | Gross Amount |  |  | Accumulated Amortization |  |  | Net Carrying Amount |  |  | Weighted Average Amortization Period |  |
|  |  | (In thousands) |  |  | (In years) |  |
| September 28, 2020 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Customer relationships |  | $ | 397,500 |  |  | $ | (140,552 | ) |  | $ | 256,948 |  |  |  | 10.9 |  |
| Technology |  |  | 47,650 |  |  |  | (12,318 | ) |  |  | 35,332 |  |  |  | 9.5 |  |
|  |  | $ | 445,150 |  |  | $ | (152,870 | ) |  | $ | 292,280 |  |  |  |  |  |
| December 30, 2019 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Customer relationships |  | $ | 396,270 |  |  | $ | (111,272 | ) |  | $ | 284,998 |  |  |  | 11.0 |  |
| Technology |  |  | 39,500 |  |  |  | (8,064 | ) |  |  | 31,436 |  |  |  | 9.4 |  |
| Acquired intangibles from acquisition in 2019 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Customer relationships |  |  | 1,230 |  |  |  | (31 | ) |  |  | 1,199 |  |  |  | 5.0 |  |
| Technology |  |  | 8,150 |  |  |  | (103 | ) |  |  | 8,047 |  |  |  | 10.0 |  |
|  |  | $ | 445,150 |  |  | $ | (119,470 | ) |  | $ | 325,680 |  |  |  |  |  |

[0001564590-20-051296:notes:65]
Definite-lived intangibles are generally amortized using the straight-line method of amortization over the estimated useful life. Amortization expense was $11,510 and $10,680 for the quarters ended September 28, 2020 and September 30, 2019, respectively, and $33,400 and $39,784 for the three quarters ended September 28, 2020 and September 30, 2019, respectively. For the quarter and three quarters ended September 28, 2020, $1,384 and $4,151, respectively, of amortization expense is included in cost of goods sold. For the quarter and three quarters ended September 30, 2019, $1,180 and $3,539, respectively, of amortization expense is included in cost of goods sold.

[0001564590-20-051296:notes:66]
[same as prior period, unchanged from 0001564590-20-037715:notes:58]

[0001564590-20-051296:notes:67]
|  |  | (In thousands) |  |
| Remaining 2020 |  | $ | 10,973 |  |
| 2021 |  |  | 41,179 |  |
| 2022 |  |  | 38,631 |  |
| 2023 |  |  | 36,713 |  |
| 2024 |  |  | 29,713 |  |
| Thereafter |  |  | 135,071 |  |
|  |  | $ | 292,280 |  |


## us-gaap:LongTermDebtTextBlock

[0001564590-20-051296:notes:68]
(8) Long-term Debt and Letters of Credit

[0001564590-20-051296:notes:69]
The following table summarizes the long-term debt of the Company as of September 28, 2020 and December 30, 2019:

[0001564590-20-051296:notes:70]
|  |  | Interest Rate as of September 28, 2020 |  |  | Principal Outstanding as of September 28, 2020 |  |  | Interest Rate as of December 30, 2019 |  |  | Principal Outstanding as of December 30, 2019 |  |
|  |  | (In thousands) |  |
| Term Loan due September 2024 |  |  | 2.65 |  | % | $ | 405,879 |  |  |  | 4.28 |  | % | $ | 805,879 |  |
| Senior Notes due October 2025 |  |  | 5.63 |  |  |  | 375,000 |  |  |  | 5.63 |  |  |  | 375,000 |  |
| Convertible Senior Notes due December 2020 |  |  | 1.75 |  |  |  | 249,975 |  |  |  | 1.75 |  |  |  | 249,975 |  |
| U.S. ABL Revolving Loan due June 2024 |  |  | 1.40 |  |  |  | 40,000 |  |  |  | 3.03 |  |  |  | 40,000 |  |
| Asia ABL Revolving Loan due June 2024 |  |  | 1.55 |  |  |  | 30,000 |  |  |  | 3.18 |  |  |  | 30,000 |  |
|  |  |  |  |  |  |  | 1,100,854 |  |  |  |  |  |  |  | 1,500,854 |  |
| Less: Long-term debt unamortized discount |  |  |  |  |  |  | (3,054 | ) |  |  |  |  |  |  | (11,943 | ) |
| Long-term debt unamortized debt issuance costs |  |  |  |  |  |  | (7,802 | ) |  |  |  |  |  |  | (12,974 | ) |
|  |  |  |  |  |  |  | 1,089,998 |  |  |  |  |  |  |  | 1,475,937 |  |
| Less: current maturities |  |  |  |  |  |  | (249,975 | ) |  |  |  |  |  |  | (249,975 | ) |
| Long-term debt, less current maturities |  |  |  |  |  | $ | 840,023 |  |  |  |  |  |  | $ | 1,225,962 |  |

[0001564590-20-051296:notes:71]
As of September 28, 2020, the Company’s restricted cash balance of $249,975 consisted of a specific deposit account to be used for principal payment on the Convertible Senior Notes due December 2020.

[0001564590-20-051296:notes:72]
The Company has twelve months to reinvest the cash proceeds received from the sale of the Mobility business unit. If the proceeds are not reinvested, the Company is required to use the proceeds to prepay the Term Loan. The Company used a portion of the cash proceeds to repay $400,000 of the Term Loan during the quarter ended September 28, 2020 and plans to use the remaining cash proceeds for reinvestment. Permitted investments, as defined in the Term Loan Credit Agreement, include extensions of trade credit in the ordinary course of business, investments in cash and cash equivalents, permitted acquisitions, investments in assets useful in the business of the Company and its restricted subsidiaries, investments in joint ventures and unrestricted subsidiaries among others.

[0001564590-20-051296:notes:73]
Debt Covenants

[0001564590-20-051296:notes:74]
Borrowings under the Term Loan and Senior Notes are subject to certain affirmative and negative covenants, including limitations on indebtedness, corporate transactions, investments and dispositions, and share payments.

[0001564590-20-051296:notes:75]
Under the occurrence of certain events, the U.S. Asset-Based Lending Credit Agreement (U.S. ABL) and Asia Asset-Based Lending Credit Agreement (Asia ABL) (collectively, the ABL Revolving Loans), are subject to various financial and operational covenants, including maintaining minimum fixed charge coverage ratios.

[0001564590-20-051296:notes:76]
Debt Issuance and Debt Discount

[0001564590-20-051296:notes:77]
As of September 28, 2020 and December 30, 2019, remaining unamortized debt discount and debt issuance costs for the Term Loan Facility, Senior Notes and Convertible Senior Notes are as follows:

[0001564590-20-051296:notes:78]
|  |  | As of September 28, 2020 |  |  | As of December 30, 2019 |
|  |  | Debt Issuance Costs |  |  | Debt Discount |  |  | Effective Interest Rate |  |  | Debt Issuance Costs |  |  | Debt Discount |  |  | Effective Interest Rate |  |  |
|  |  | (In thousands, except interest rates) |
| Term Loan due September 2024 |  | $ | 2,862 |  |  | $ | 866 |  |  |  | 4.66 |  | % | $ | 6,663 |  |  | $ | 2,016 |  |  |  | 4.66 |  | % |
| Senior Notes due October 2025 |  |  | 4,721 |  |  | — |  |  |  | 5.92 |  |  |  | 5,316 |  |  | — |  |  |  | 5.92 |  |  |
| Convertible Senior Notes |  |  | 219 |  |  |  | 2,188 |  |  |  | 6.48 |  |  |  | 995 |  |  |  | 9,927 |  |  |  | 6.48 |  |  |
|  |  | $ | 7,802 |  |  | $ | 3,054 |  |  |  |  |  |  | $ | 12,974 |  |  | $ | 11,943 |  |  |  |  |  |  |

[0001564590-20-051296:notes:79]
The above debt discount and debt issuance costs are recorded as a reduction of the debt and are amortized into interest expense using an effective interest rate over the duration of the debt.

[0001564590-20-051296:notes:80]
Remaining unamortized debt issuance costs for the ABL Revolving Loans of $2,084 and $2,511 as of September 28, 2020 and December 30, 2019, respectively, are included in other non-current assets and are amortized to interest expense over the duration of the ABL Revolving Loans using the straight-line method of amortization.

[0001564590-20-051296:notes:81]
As of September 28, 2020, the remaining weighted average amortization period for all unamortized debt discount and debt issuance costs was 3.6 years.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001564590-20-051296:notes:82]
[same as prior period, unchanged from 0001564590-20-037715:notes:73]

[0001564590-20-051296:notes:83]
[same as prior period, unchanged from 0001564590-20-037715:notes:74]

[0001564590-20-051296:notes:84]
During the quarter and three quarters ended September 28, 2020, the Company’s effective tax rate was impacted by a net discrete benefit of $1,072 and $5,890, respectively. This is related mainly to release of uncertain tax positions due to the expiration of the statute of limitation in foreign jurisdictions, change in the estimated tax benefits in the United States for GILTI and in Hong Kong related to unrealized foreign exchange gain and loss, netted against (i) an increase of valuation allowance and withholding tax expense related to the announced closure of two of the Company’s E-M Solutions plants, (ii) retroactive approval of the Company’s renewal application for High and New Tax Enterprise status for two of the Company’s manufacturing subsidiaries in China (including the impact on the respective Company’s deferred tax assets) and (iii) by the accrued interest expense on existing uncertain tax positions.

[0001564590-20-051296:notes:85]
[same as prior period, unchanged from 0001564590-20-037715:notes:76]


## us-gaap:FinancialInstrumentsDisclosureTextBlock

[0001564590-20-051296:notes:86]
[same as prior period, unchanged from 0001564590-20-037715:notes:77]

[0001564590-20-051296:notes:87]
[same as prior period, unchanged from 0001564590-20-037715:notes:78]

[0001564590-20-051296:notes:88]
[same as prior period, unchanged from 0001564590-20-037715:notes:79]

[0001564590-20-051296:notes:89]
[same as prior period, unchanged from 0001564590-20-037715:notes:80]

[0001564590-20-051296:notes:90]
[same as prior period, unchanged from 0001564590-20-037715:notes:81]

[0001564590-20-051296:notes:91]
At inception, the Company designated the interest rate swap as a cash flow hedge and the fair value of the interest rate swap was zero. As of September 28, 2020, the fair value of the interest rate swap was recorded as a liability in the amount of $17,461 and included as a component of other long-term liabilities. The change in the fair value of the interest rate swap is recorded as a component of accumulated other comprehensive loss, net of tax. No ineffectiveness was recognized for the quarter and three quarters ended September 28, 2020 and September 30, 2019. The interest rate swap increased interest expense by $2,707 and $602 for the quarters ended September 28, 2020 and September 30, 2019, respectively, and $6,224 and $1,308 for the three quarters ended September 28, 2020 and September 30, 2019, respectively.

[0001564590-20-051296:notes:92]
[same as prior period, unchanged from 0001564590-20-037715:notes:83]

[0001564590-20-051296:notes:93]
The Company enters into foreign currency forward contracts to mitigate the impact of changes in foreign currency exchange rates and to reduce the volatility of purchases and other obligations generated in currencies other than its functional currencies. The Company’s foreign subsidiaries may at times purchase forward exchange contracts to manage their foreign currency risks in relation to certain purchases of machinery denominated in foreign currencies other than the Company’s functional currencies. The notional amount of the foreign exchange contracts as of September 28, 2020 and December 30, 2019 was approximately $1,968 (Japanese Yen (JPY) 209.0 million) and $1,994 (JPY 215.8 million), respectively. The Company has designated certain of these foreign exchange contracts as cash flow hedges.

[0001564590-20-051296:notes:94]
[same as prior period, unchanged from 0001564590-20-037715:notes:85]

[0001564590-20-051296:notes:95]
|  |  |  |  | Asset/(Liability) Fair Value |  |
|  |  | Balance Sheet Location |  | September 28, 2020 |  |  | December 30, 2019 |  |
|  |  |  |  | (In thousands) |  |
| Cash flow derivative instruments designated as hedges: |  |  |  |  |  |  |  |  |
| Interest rate swap |  | Other long-term liabilities |  | $ | (17,461 | ) |  | $ | (12,067 | ) |
| Cash flow derivative instruments not designated as hedges: |  |  |  |  |  |  |  |  |
| Foreign exchange contracts |  | Prepaid expenses and other current assets |  |  | 19 |  |  |  | 1 |  |
| Foreign exchange contracts |  | Other current liabilities |  |  | — |  |  |  | (3 | ) |

[0001564590-20-051296:notes:96]
The following table provides information about the amounts recorded in accumulated other comprehensive loss related to derivatives designated as cash flow hedges, as well as the amounts recorded in each caption in the consolidated condensed statements of operations when derivative amounts are reclassified out of accumulated other comprehensive loss for the quarter and three quarters ended September 28, 2020 and September 30, 2019:

[0001564590-20-051296:notes:97]
|  |  |  | Quarter Ended September 28, 2020 |  |  | Quarter Ended September 30, 2019 |  |  |
|  |  | Financial Statement Caption | Loss Recognized in Other Comprehensive Loss |  |  | Loss Reclassified into Income |  |  | Loss Recognized in Other Comprehensive Loss |  |  | Loss Reclassified into Income |  |  |
|  |  |  | (In thousands) |
| Cash flow hedge: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Interest rate swap |  | Interest expense | $ | (586 | ) |  | $ | (2,707 | ) |  | $ | (1,923 | ) |  | $ | (602 | ) |  |

[0001564590-20-051296:notes:98]
|  |  |  | Three Quarters Ended September 28, 2020 |  |  | Three Quarters Ended September 30, 2019 |  |  |
|  |  | Financial Statement Caption | Loss Recognized in Other Comprehensive Loss |  |  | Loss Reclassified into Income |  |  | Loss Recognized in Other Comprehensive Loss |  |  | Loss Reclassified into Income |  |  |
|  |  |  | (In thousands) |
| Cash flow hedge: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Interest rate swap |  | Interest expense | $ | (11,618 | ) |  | $ | (6,224 | ) |  | $ | (10,586 | ) |  | $ | (1,308 | ) |  |

[0001564590-20-051296:notes:99]
The following table provides a summary of the activity associated with the designated cash flow hedges reflected in accumulated other comprehensive loss for the three quarters ended September 30, 2020 and September 30, 2019:

[0001564590-20-051296:notes:100]
|  |  | Three Quarters Ended |
|  |  | September 28, |  |  | September 30, |  |  |
|  |  | 2020 |  |  | 2019 |  |  |
|  |  | (In thousands) |
| Beginning balance, net of tax |  | $ | (9,617 | ) |  | $ | (4,214 | ) |  |
| Changes in fair value loss, net of tax |  |  | (8,667 | ) |  |  | (8,164 | ) |  |
| Reclassification to earnings, net of tax |  |  | 4,727 |  |  |  | 1,128 |  |  |
| Derecognition of unrealized losses on cash flow hedge due to sale of Mobility business unit |  |  | 384 |  |  |  | — |  |  |
| Ending balance, net of tax |  | $ | (13,173 | ) |  | $ | (11,250 | ) |  |

[0001564590-20-051296:notes:101]
Based on the current yield curve, the Company expects that losses of approximately $7,961 of the accumulated other comprehensive loss will be reclassified into the statement of operations, net of tax, in the next twelve months.


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0001564590-20-051296:notes:102]
[same as prior period, unchanged from 0001564590-20-037715:notes:93]

[0001564590-20-051296:notes:103]
The following provides a summary of the components of accumulated other comprehensive loss, net of tax, as of September 28, 2020 and December 30, 2019:

[0001564590-20-051296:notes:104]
|  |  | Foreign Currency Translation |  |  | Pension Obligation |  |  | (Losses) Gains on Cash Flow Hedges |  |  | Total |  |
|  |  | (In thousands) |  |
| Ending balance as of December 30, 2019 |  | $ | 1,115 |  |  | $ | (1,584 | ) |  | $ | (9,617 | ) |  | $ | (10,086 | ) |
| Other comprehensive income (loss) before reclassifications |  |  | 778 |  |  |  | 4 |  |  |  | (8,667 | ) |  |  | (7,885 | ) |
| Amounts reclassified from accumulated other comprehensive loss |  |  | — |  |  |  | — |  |  |  | 4,727 |  |  |  | 4,727 |  |
| Reclassification adjustment for foreign currency translation |  |  | (346 | ) |  |  | — |  |  |  | — |  |  |  | (346 | ) |
| Derecognition of foreign currency translation adjustments due to sale of Mobility business unit |  |  | (27,341 | ) |  |  | — |  |  |  | — |  |  |  | (27,341 | ) |
| Derecognition of unrealized losses on cash flow hedge due to sale of Mobility business unit |  |  | — |  |  |  | — |  |  |  | 384 |  |  |  | 384 |  |
| Other comprehensive (loss) income |  |  | (26,909 | ) |  |  | 4 |  |  |  | (3,556 | ) |  |  | (30,461 | ) |
| Ending balance as of September 28, 2020 |  | $ | (25,794 | ) |  | $ | (1,580 | ) |  | $ | (13,173 | ) |  | $ | (40,547 | ) |


## us-gaap:ConcentrationRiskDisclosureTextBlock

[0001564590-20-051296:notes:105]
[same as prior period, unchanged from 0001564590-20-037715:notes:96]

[0001564590-20-051296:notes:106]
In the normal course of business, the Company extends credit to its customers. Some customers to which the Company extends credit are located outside the United States. The Company performs ongoing credit evaluations of customers, does not require collateral, and considers the credit risk profile of the entity from which the receivable is due in further evaluating collection risk.

[0001564590-20-051296:notes:107]
The Company’s customers include both OEMs and EMS companies. The Company’s OEM customers often direct a significant portion of their purchases through EMS companies. While the Company’s customers include both OEM and EMS providers, the Company measures customer concentration based on OEM companies, as they are the ultimate end customers. For the quarter and three quarters ended September 28, 2020, one customer accounted for approximately 13% and 10% of the Company’s net sales, respectively. There were no other customers that accounted for 10% or more of net sales for the quarter and three quarters ended September 28, 2020. There were no customers that accounted for 10% or more of net sales for the quarter and three quarters ended September 30, 2019.


## us-gaap:FairValueDisclosuresTextBlock

[0001564590-20-051296:notes:108]
[same as prior period, unchanged from 0001564590-20-037715:notes:99]

[0001564590-20-051296:notes:109]
[same as prior period, unchanged from 0001564590-20-037715:notes:100]

[0001564590-20-051296:notes:110]
The carrying amount and estimated fair value of the Company’s financial instruments as of September 28, 2020 and December 30, 2019 were as follows:

[0001564590-20-051296:notes:111]
|  |  | As of |  |  | As of |  |
|  |  | September 28, 2020 |  |  | December 30, 2019 |  |
|  |  | Carrying Amount |  |  | Fair Value |  |  | Carrying Amount |  |  | Fair Value |  |
|  |  | (In thousands) |  |
| Derivative assets, current |  | $ | 19 |  |  | $ | 19 |  |  | $ | 1 |  |  | $ | 1 |  |
| Derivative liabilities, current |  |  | — |  |  |  | — |  |  |  | 3 |  |  |  | 3 |  |
| Derivative liabilities, non-current |  |  | 17,461 |  |  |  | 17,461 |  |  |  | 12,067 |  |  |  | 12,067 |  |
| Term Loan due September 2024 |  |  | 402,151 |  |  |  | 396,240 |  |  |  | 797,200 |  |  |  | 808,901 |  |
| Senior Notes due October 2025 |  |  | 370,279 |  |  |  | 384,240 |  |  |  | 369,684 |  |  |  | 390,143 |  |
| Convertible Senior Notes due December 2020 |  |  | 247,568 |  |  |  | 297,145 |  |  |  | 239,053 |  |  |  | 391,686 |  |
| ABL Revolving Loans |  |  | 70,000 |  |  |  | 70,000 |  |  |  | 70,000 |  |  |  | 70,000 |  |

[0001564590-20-051296:notes:112]
[same as prior period, unchanged from 0001564590-20-037715:notes:103]

[0001564590-20-051296:notes:113]
The fair value of the long-term debt was estimated based on quoted market prices or discounting the debt over its life using current market rates for similar debt as of September 28, 2020 and December 30, 2019, which are considered Level 2 inputs.

[0001564590-20-051296:notes:114]
[same as prior period, unchanged from 0001564590-20-037715:notes:105]

[0001564590-20-051296:notes:115]
As of September 28, 2020 and December 30, 2019, the Company’s other financial instruments also included cash and cash equivalents, restricted cash, accounts receivable, and accounts payable. Due to short-term maturities, the carrying amount of these instruments approximates fair value. The Company’s cash, cash equivalents, and restricted cash as of September 28, 2020 consisted of $429,470 held in the U.S., with the remaining $233,815 held by foreign subsidiaries.

[0001564590-20-051296:notes:116]
[same as prior period, unchanged from 0001564590-20-037715:notes:107]

[0001564590-20-051296:notes:117]
As of September 28, 2020, the Company’s goodwill balance related to its RF&S Components reporting unit of $108,000 was measured at fair value on a nonrecurring basis. The Company recorded a non-cash goodwill impairment charge of $69,200 during the quarter and three quarters ended September 28, 2020. The fair value of goodwill was determined using both a DCF and a market approach, which are considered Level 3 inputs.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001564590-20-051296:notes:118]
(14) Commitments and Contingencies

[0001564590-20-051296:notes:119]
Legal Matters

[0001564590-20-051296:notes:120]
The Company is subject to various legal matters, which it considers normal for its business activities. While the Company currently believes that the amount of any reasonably possible loss for known matters would not be material to the Company’s financial condition, the outcome of these actions is inherently difficult to predict. In the event of an adverse outcome, the ultimate potential loss could have a material adverse effect on the Company’s financial condition or results of operations in a particular period. The Company has accrued amounts for its loss contingencies which are probable and estimable as of September 28, 2020 and December 30, 2019. However, these amounts are not material to the consolidated condensed financial statements of the Company.


## us-gaap:EarningsPerShareTextBlock

[0001564590-20-051296:notes:121]
[same as prior period, unchanged from 0001564590-20-037715:notes:111]

[0001564590-20-051296:notes:122]
The following is a reconciliation of the numerator and denominator used to calculate basic earnings per share and diluted earnings per share from continuing operations for the quarter and three quarters ended September 28, 2020 and September 30, 2019:

[0001564590-20-051296:notes:123]
|  |  | Quarter Ended |  |  | Three Quarters Ended |  |
|  |  | September 28, 2020 |  |  | September 30, 2019 |  |  | September 28, 2020 |  |  | September 30, 2019 |  |
|  |  | (In thousands, except per share amounts) |  |
| Net (loss) income from continuing operations |  | $ | (61,472 | ) |  | $ | 2,393 |  |  | $ | (55,346 | ) |  | $ | 21,124 |  |
| Basic weighted average shares |  |  | 106,729 |  |  |  | 105,492 |  |  |  | 106,130 |  |  |  | 105,092 |  |
| Dilutive effect of performance-based restricted stock units, restricted stock units and stock options |  |  | — |  |  |  | 982 |  |  |  | — |  |  |  | 973 |  |
| Diluted shares |  |  | 106,729 |  |  |  | 106,474 |  |  |  | 106,130 |  |  |  | 106,065 |  |
| (Loss) earnings per share: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  | $ | (0.58 | ) |  | $ | 0.02 |  |  | $ | (0.52 | ) |  | $ | 0.20 |  |
| Diluted |  | $ | (0.58 | ) |  | $ | 0.02 |  |  | $ | (0.52 | ) |  | $ | 0.20 |  |

[0001564590-20-051296:notes:124]
For the quarter and three quarters ended September 28, 2020, potential shares of common stock, consisting of stock options to purchase approximately 80 shares of common stock at exercise prices ranging from $11.83 to $16.60 per share, 3,187 restricted stock units (RSUs), and 216 performance-based restricted stock units (PRUs) were not included in the computation of diluted earnings per share because the Company incurred a net loss and as a result, the impact would be anti-dilutive.

[0001564590-20-051296:notes:125]
PRUs, RSUs and stock options to purchase 407 and 862 shares of common stock for the quarter and three quarters ended September 30, 2019, respectively, were not included in the computation of diluted earnings per share. The PRUs were not included in the computation of diluted earnings per share because the performance conditions had not been met at September 30, 2019, and for RSUs and stock options, the options’ exercise prices or the total expected proceeds under the treasury stock method was greater than the average market price of common shares during the applicable quarter and three quarters and, as a result, the impact would be anti-dilutive.

[0001564590-20-051296:notes:126]
Outstanding warrants for the quarter and three quarters ended September 28, 2020 and September 30, 2019, to purchase common stock were not included in the computation of dilutive earnings per share because the strike price of the warrants to purchase the Company’s common stock were greater than the average market price of common shares during the applicable quarter, and therefore, the effect would be anti-dilutive or because the Company incurred a net loss.

[0001564590-20-051296:notes:127]
During the quarter ended September 28, 2020, the Company calculated the dilutive effect of Convertible Senior Notes using the treasury stock method because the Company now has the intent and ability to settle the Convertible Senior Notes in cash. This change in policy from the if-converted method to treasury stock method is applied on a prospective basis. For the quarter and three quarters ended September 28, 2020, the effect of shares of common stock related to the Company’s Convertible Senior Notes, based on the treasury stock method, were not included in the computation of dilutive earnings per share as the impact would be anti-dilutive.

[0001564590-20-051296:notes:128]
For the quarter and three quarters ended September 30, 2019, the effect of shares of common stock related to the Company’s Convertible Senior Notes, based on the if-converted method, were not included in the computation of dilutive earnings per share as the impact would be anti-dilutive.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001564590-20-051296:notes:129]
[same as prior period, unchanged from 0001564590-20-037715:notes:117]

[0001564590-20-051296:notes:130]
[same as prior period, unchanged from 0001564590-20-037715:notes:118]

[0001564590-20-051296:notes:131]
|  |  | Quarter Ended |  | Three Quarters Ended |
|  |  | September 28, |  |  | September 30, |  |  |  | September 28, |  |  | September 30, |  |  |
|  |  | 2020 |  |  | 2019 |  |  |  | 2020 |  |  | 2019 |  |  |
|  |  | (In thousands) |  | (In thousands) |
| Cost of goods sold |  | $ | 1,173 |  |  | $ | 937 |  |  |  | $ | 2,643 |  |  | $ | 2,210 |  |  |
| Selling and marketing |  |  | 557 |  |  |  | 574 |  |  |  |  | 1,299 |  |  |  | 1,408 |  |  |
| General and administrative |  |  | 2,705 |  |  |  | 3,089 |  |  |  |  | 7,872 |  |  |  | 8,421 |  |  |
| Research and development |  |  | 44 |  |  |  | 62 |  |  |  |  | 147 |  |  |  | 151 |  |  |
| Stock-based compensation expense recognized |  | $ | 4,479 |  |  | $ | 4,662 |  |  |  | $ | 11,961 |  |  | $ | 12,190 |  |  |

[0001564590-20-051296:notes:132]
[same as prior period, unchanged from 0001564590-20-037715:notes:120]

[0001564590-20-051296:notes:133]
The following is a summary of total unrecognized compensation costs as of September 28, 2020:

[0001564590-20-051296:notes:134]
|  |  | Unrecognized Stock-Based Compensation Cost |  |  | Remaining Weighted Average Recognition Period |  |
|  |  | (In thousands) |  |  | (In years) |  |
| RSU awards |  | $ | 24,422 |  |  |  | 1.5 |  |
| PRU awards |  |  | 2,402 |  |  |  | 1.6 |  |
| Stock options |  |  | 154 |  |  |  | 1.4 |  |
|  |  | $ | 26,978 |  |  |  |  |  |


## us-gaap:SegmentReportingDisclosureTextBlock

[0001564590-20-051296:notes:135]
[same as prior period, unchanged from 0001564590-20-037715:notes:123]

[0001564590-20-051296:notes:136]
The reportable segments shown below are the Company’s segments for which separate financial information is available and upon which operating results are evaluated by the chief operating decision maker to assess performance and to allocate resources. During the quarter ended September 28, 2020, the Company’s RF&S Components operating segment met the quantitative threshold for separate presentation of a reportable segment. In prior periods, the Company had two reportable segments: PCB and E-M Solutions. The RF&S Components reportable segment was previously aggregated with the PCB reportable segment. As a result, certain prior year amounts have been reclassified to conform with this new presentation. The PCB reportable segment is comprised of multiple operating segments. Factors considered to determine whether operating segments can be aggregated into reportable segments included similarity regarding economic characteristics, products, production processes, type or classes of customers, distribution methods, and regulatory environments.

[0001564590-20-051296:notes:137]
[same as prior period, unchanged from 0001564590-20-037715:notes:125]

[0001564590-20-051296:notes:138]
|  |  | Quarter Ended |  |  | Three Quarters Ended |  |
|  |  | September 28, 2020 |  |  | September 30, 2019 |  |  | September 28, 2020 |  |  | September 30, 2019 |  |
|  |  | (In thousands) |  |
| Net Sales: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| PCB |  | $ | 463,664 |  |  | $ | 452,816 |  |  | $ | 1,429,629 |  |  | $ | 1,366,762 |  |
| RF&S Components |  |  | 11,742 |  |  |  | 13,644 |  |  |  | 33,274 |  |  |  | 51,725 |  |
| E-M Solutions |  |  | 38,170 |  |  |  | 67,713 |  |  |  | 118,617 |  |  |  | 179,008 |  |
| Total net sales |  | $ | 513,576 |  |  | $ | 534,173 |  |  | $ | 1,581,520 |  |  | $ | 1,597,495 |  |
| Operating Segment (Loss) Income: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| PCB |  | $ | 64,219 |  |  | $ | 51,326 |  |  | $ | 199,683 |  |  | $ | 164,458 |  |
| RF&S Components |  |  | (66,098 | ) |  |  | 5,999 |  |  |  | (59,880 | ) |  |  | 25,824 |  |
| E-M Solutions |  |  | (873 | ) |  |  | 3,236 |  |  |  | (20,779 | ) |  |  | 5,278 |  |
| Corporate |  |  | (25,990 | ) |  |  | (28,750 | ) |  |  | (86,698 | ) |  |  | (75,537 | ) |
| Total operating segment income |  |  | (28,742 | ) |  |  | 31,811 |  |  |  | 32,326 |  |  |  | 120,023 |  |
| Amortization of definite-lived intangibles (1) |  |  | (11,510 | ) |  |  | (10,680 | ) |  |  | (33,400 | ) |  |  | (39,784 | ) |
| Total operating (loss) income |  |  | (40,252 | ) |  |  | 21,131 |  |  |  | (1,074 | ) |  |  | 80,239 |  |
| Total other expense |  |  | (22,520 | ) |  |  | (14,548 | ) |  |  | (57,916 | ) |  |  | (53,586 | ) |
| (Loss) income before income taxes |  | $ | (62,772 | ) |  | $ | 6,583 |  |  | $ | (58,990 | ) |  | $ | 26,653 |  |

[0001564590-20-051296:notes:139]
| (1) | Amortization of definite-lived intangibles primarily relates to the PCB and RF&S Components reportable segments. For the quarter and three quarters ended September 28, 2020, $1,384 and $4,151, respectively, of amortization expense is included in cost of goods sold. For the quarter and three quarters ended September 30, 2019, $1,180 and $3,539, respectively, of amortization expense is included in cost of goods sold. |

[0001564590-20-051296:notes:140]
During the quarter and three quarters ended September 28, 2020, the Company recorded an impairment charge for goodwill of $69,200 related to its RF&S Components reportable segment.

[0001564590-20-051296:notes:141]
[same as prior period, unchanged from 0001564590-20-037715:notes:128]

[0001564590-20-051296:notes:142]
The Company markets and sells its products in approximately 53 countries. Other than in the United States and China, the Company does not conduct business in any country in which its net sales in that country exceed 10% of the Company’s total net sales. Net sales are as follows:

[0001564590-20-051296:notes:143]
|  |  | Quarter Ended |  |  | Three Quarters Ended |  |
|  |  | September 28, 2020 |  |  | September 30, 2019 |  |  | September 28, 2020 |  |  | September 30, 2019 |  |
|  |  | (In thousands) |  |
| Net Sales: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| United States |  | $ | 271,050 |  |  | $ | 281,875 |  |  | $ | 802,681 |  |  | $ | 841,196 |  |
| China |  |  | 80,696 |  |  |  | 75,692 |  |  |  | 252,736 |  |  |  | 254,888 |  |
| Other |  |  | 161,830 |  |  |  | 176,606 |  |  |  | 526,103 |  |  |  | 501,411 |  |
| Total net sales |  | $ | 513,576 |  |  | $ | 534,173 |  |  | $ | 1,581,520 |  |  | $ | 1,597,495 |  |

[0001564590-20-051296:notes:144]
Net sales are attributed to countries by country invoiced.


## us-gaap:RelatedPartyTransactionsDisclosureTextBlock

[0001564590-20-051296:notes:145]
(18) Related Party Transactions

[0001564590-20-051296:notes:146]
In the normal course of business, the Company’s foreign subsidiaries purchase laminate and prepreg from related parties in which a significant shareholder of the Company holds an equity interest. The Company’s foreign subsidiaries purchased laminate and prepreg from these related parties in the amount of $5,760 and $7,151 for the quarters ended September 28, 2020 and September 30, 2019, respectively, and $17,527 and $22,847 for the three quarters ended September 28, 2020 and September 30, 2019, respectively.

[0001564590-20-051296:notes:147]
As of September 28, 2020 and December 30, 2019, the Company’s consolidated condensed balance sheets included $6,786 and $9,220, respectively, in accounts payable due to related parties for purchases of laminate and prepreg and such balances are included as a component of accounts payable on the consolidated condensed balance sheets.


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0001564590-20-051296:notes:148]
[same as prior period, unchanged from 0001564590-20-037715:notes:132]

[0001564590-20-051296:notes:149]
On April 29, 2020, the Company announced the restructuring of its E-M Solutions business unit. The E-M Solutions business unit consists of three Chinese manufacturing facilities with two being in Shanghai (SH BPA and SH E-MS) and one in Shenzhen (SZ). The Company will discontinue operations at the SH E-MS and SZ facilities while integrating the SH BPA facility into its PCB operations. The restructuring is another step in advancing the Company’s stated strategy of increasing its focus on differentiated higher margin products that more fully leverage the Company’s early engagement capabilities and industry leading engineering-based technology solutions. The closure of the SH E-MS and SZ facilities will not be immediate as the Company has obligations to fulfill with customers. The Company anticipates phasing out production over the remainder of 2020. As of September 28, 2020, the Company has incurred approximately $14,671 of restructuring charges and $5,694 of accelerated depreciation expense since the April 29, 2020 announcement. The Company estimates that it will incur total charges related to restructuring of its E-M Solutions business unit of approximately $18,500 and accelerated depreciation expense of approximately $8,000.

[0001564590-20-051296:notes:150]
In connection with the restructuring of its E-M Solutions business unit and other global realignment restructuring efforts, the Company recognized employee separation, contract termination and other costs during the quarter and three quarters ended September 28, 2020 and September 30, 2019. Contract termination and other costs primarily represented plant closure costs.

[0001564590-20-051296:notes:151]
The below table summarizes such restructuring costs by reportable segment, which are included as a component of general and administrative expenses in the consolidated condensed statements of operations, for the quarter and three quarters ended

[0001564590-20-051296:notes:152]
September 28, 2020 and September 30, 2019:

[0001564590-20-051296:notes:153]
|  |  | Quarter Ended September 28, 2020 |  |  | Three Quarters Ended September 28, 2020 |  |  |
|  |  | Employee Separation/ Severance |  |  | Contract Termination and Other Costs |  |  | Total |  |  | Employee Separation/ Severance |  |  | Contract Termination and Other Costs |  |  | Total |  |  |
|  |  | (In thousands) |  |  |
| Reportable Segment: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| PCB |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | (8 | ) |  | $ | 14 |  |  | $ | 6 |  |  |
| E-M Solutions |  |  | 979 |  |  |  | 7 |  |  |  | 986 |  |  |  | 14,373 |  |  |  | 298 |  |  |  | 14,671 |  |  |
| Corporate |  |  | — |  |  |  | 102 |  |  |  | 102 |  |  |  | — |  |  |  | 153 |  |  |  | 153 |  |  |
|  |  | $ | 979 |  |  | $ | 109 |  |  | $ | 1,088 |  |  | $ | 14,365 |  |  | $ | 465 |  |  | $ | 14,830 |  |  |

[0001564590-20-051296:notes:154]
|  |  | Quarter Ended September 30, 2019 |  |  | Three Quarters Ended September 30, 2019 |  |  |
|  |  | Employee Separation/ Severance |  |  | Contract Termination and Other Costs |  |  | Total |  |  | Employee Separation/ Severance |  |  | Contract Termination and Other Costs |  |  | Total |  |  |
|  |  | (In thousands) |  |  |
| Reportable Segment: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| PCB |  | $ | 5 |  |  | $ | — |  |  | $ | 5 |  |  | $ | 2,941 |  |  | $ | — |  |  | $ | 2,941 |  |  |
| RF&S Components |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 52 |  |  |  | — |  |  |  | 52 |  |  |
| Corporate |  |  | — |  |  |  | 7 |  |  |  | 7 |  |  |  | 160 |  |  |  | 23 |  |  |  | 183 |  |  |
|  |  | $ | 5 |  |  | $ | 7 |  |  | $ | 12 |  |  | $ | 3,153 |  |  | $ | 23 |  |  | $ | 3,176 |  |  |

[0001564590-20-051296:notes:155]
Accrued restructuring costs are included as a component of other current liabilities in the consolidated condensed balance sheet. The below table shows the utilization of the accrued restructuring costs during the three quarters ended September 28, 2020:

[0001564590-20-051296:notes:156]
|  |  | Employee Separation/ Severance |  |  | Contract Termination and Other Costs |  |  | Total |  |
|  |  | (In thousands) |  |
| Accrued as of December 30, 2019 |  | $ | 260 |  |  | $ | 242 |  |  | $ | 502 |  |
| Charged to expense |  |  | 14,365 |  |  |  | 465 |  |  |  | 14,830 |  |
| Amount paid |  |  | (3,139 | ) |  |  | (498 | ) |  |  | (3,637 | ) |
| Accrued as of September 28, 2020 |  | $ | 11,486 |  |  | $ | 209 |  |  | $ | 11,695 |  |
