# POWL notes — 0000080420-18-000007


## us-gaap:AllowanceForCreditLossesOnFinancingReceivablesTableTextBlock

[0000080420-18-000007:notes:1]
[same as prior period, unchanged from 0000080420-17-000020:notes:1]

[0000080420-18-000007:notes:2]
|  | Three months ended December 31, |
|  | 2017 |  | 2016 |
| Balance at beginning of period | $ | 179 |  |  | $ | 811 |  |
| Bad debt expense (recovery) | (20 | ) |  | (113 | ) |
| Uncollectible accounts written off, net of recoveries | (1 | ) |  | (28 | ) |
| Change due to foreign currency translation | — |  |  | (6 | ) |
| Balance at end of period | $ | 158 |  |  | $ | 664 |  |


## us-gaap:BasisOfAccountingPolicyPolicyTextBlock

[0000080420-18-000007:notes:3]
[same as prior period, unchanged from 0000080420-17-000020:notes:3]

[0000080420-18-000007:notes:4]
These unaudited condensed consolidated financial statements include the accounts of Powell and its wholly-owned subsidiaries. All significant intercompany accounts and transactions have been eliminated in consolidation.

[0000080420-18-000007:notes:5]
These unaudited condensed consolidated financial statements have been prepared in accordance with the instructions to Form 10-Q and Rule 10-01 of Regulation S-X for interim financial information. Certain information and footnote disclosures, normally included in annual financial statements prepared in accordance with accounting principles generally accepted in the United States (U.S. GAAP), have been condensed or omitted pursuant to those rules and regulations. In the opinion of management, all adjustments, consisting only of normal recurring adjustments, necessary to fairly state the financial position, results of operations and cash flows with respect to the interim condensed consolidated financial statements have been included. The results of operations for the interim periods are not necessarily indicative of the results for the entire fiscal year. We believe that these financial statements contain all adjustments necessary so that they are not misleading.

[0000080420-18-000007:notes:6]
These unaudited condensed consolidated financial statements should be read in conjunction with the audited consolidated financial statements and notes thereto of Powell and its subsidiaries included in Powell’s Annual Report on Form 10-K for the year ended September 30, 2017, which was filed with the Securities and Exchange Commission (SEC) on December 6, 2017.

[0000080420-18-000007:notes:7]
References to Fiscal 2018 and Fiscal 2017 used throughout this report shall mean our fiscal years ended September 30, 2018 and 2017, respectively.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0000080420-18-000007:notes:8]
COMMITMENTS AND CONTINGENCIES

[0000080420-18-000007:notes:9]
Letters of Credit, Surety Bonds and Bank Guarantees

[0000080420-18-000007:notes:10]
Certain customers require us to post letters of credit or surety bonds which assure that we will perform under the terms of our contract. In the event of default, the counterparty may demand payment from the bank under a letter of credit or performance by the surety under a bond. To date, there have been no significant expenses related to either letters of credit or surety bonds for the periods reported. We were contingently liable for letters of credit of $27.0 million as of December 31, 2017. We also had surety bonds totaling $217.0 million that were outstanding, with additional bonding capacity of $533.0 million available, at December 31, 2017.

[0000080420-18-000007:notes:11]
Additionally, we have a $6.7 million facility agreement (Facility Agreement) between Powell (UK) Limited and a large international bank. This Facility Agreement provides Powell (UK) Limited the ability to enter into bank guarantees as well as forward exchange contracts and currency options. At December 31, 2017, we had outstanding guarantees totaling $3.9 million under this Facility Agreement and amounts available under this Facility Agreement were $2.8 million. This facility expires in May 2018. The Facility Agreement provides for financial covenants and customary events of default, and carries cross-default provisions with our U.S. Revolver. If an event of default (as defined in the Facility Agreement) occurs and is continuing, per the terms and subject to the conditions set forth therein, obligations outstanding under the Facility Agreement may be accelerated and declared immediately due and payable. As of December 31, 2017, we were in compliance with all of the financial covenants of the Facility Agreement.

[0000080420-18-000007:notes:12]
Litigation

[0000080420-18-000007:notes:13]
We are involved in various legal proceedings, claims and other disputes arising from our commercial operations, projects, employees and other matters which, in general, are subject to uncertainties and in which the outcomes are not predictable. Although we can give no assurances about the resolution of pending claims, litigation or other disputes and the effect such outcomes may have on us, management believes that any ultimate liability resulting from the outcome of such proceedings, to the extent not otherwise provided or covered by insurance, will not have a material adverse effect on our consolidated financial position or results of operations or liquidity.

[0000080420-18-000007:notes:14]
Liquidated Damages

[0000080420-18-000007:notes:15]
Certain of our customer contracts have schedule and performance obligation clauses that, if we fail to meet them, could require us to pay liquidated damages. Each individual contract defines the conditions under which the customer may make a claim against us. As of December 31, 2017, our exposure to possible liquidated damages was $2.4 million, of which approximately $1.5 million is probable. Based on our actual or projected failure to meet these various contractual commitments, $1.4 million has been recorded as a reduction to revenue. We will attempt to obtain change orders, contract extensions or accelerate project completion which may resolve the potential for any unaccrued liquidated damage. Should we fail to achieve relief on some or all of these contractual obligations, we could be required to pay additional liquidated damages, which could negatively impact our future operating results.


## us-gaap:CostsInExcessOfBillingsAndBillingsInExcessOfCostsTableTextBlock

[0000080420-18-000007:notes:16]
[same as prior period, unchanged from 0000080420-17-000020:notes:16]

[0000080420-18-000007:notes:17]
|  | December 31, 2017 |  | September 30, 2017 |
| Costs incurred on uncompleted contracts | $ | 984,882 |  |  | $ | 987,164 |  |
| Estimated earnings | 311,391 |  |  | 316,970 |  |
|  | 1,296,273 |  |  | 1,304,134 |  |
| Less: Billings to date | (1,294,017 | ) |  | (1,278,746 | ) |
| Net underbilled position | $ | 2,256 |  |  | $ | 25,388 |  |
| Included in the accompanying balance sheets under the following captions: |  |  |  |
| Costs and estimated earnings in excess of billings on uncompleted contracts | $ | 38,985 |  |  | $ | 51,554 |  |
| Billings in excess of costs and estimated earnings on uncompleted contracts | (36,729 | ) |  | (26,166 | ) |
| Net underbilled position | $ | 2,256 |  |  | $ | 25,388 |  |


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0000080420-18-000007:notes:18]
[same as prior period, unchanged from 0000080420-17-000020:notes:18]

[0000080420-18-000007:notes:19]
Refer to our Annual Report on Form 10-K for the fiscal year ended September 30, 2017 for a full description of our existing stock-based compensation plans.

[0000080420-18-000007:notes:20]
[same as prior period, unchanged from 0000080420-17-000020:notes:20]

[0000080420-18-000007:notes:21]
We issue restricted stock units (RSUs) to certain officers and key employees of the Company. The fair value of the RSUs is based on the closing price of our common stock as reported on the NASDAQ Global Market on the grant dates. The typical annual grant vests over a three-year period from the date of issuance. Sixty percent of those grants are time-based and vest over a three-year period on each anniversary of the grant date, based on continued employment. The remaining forty percent of the grant will be earned based on the three-year earnings performance of the Company following the grant date. At December 31, 2017, there were 206,584 RSUs outstanding. The RSUs do not have voting rights but do receive dividend equivalents upon vesting; additionally, the shares of common stock underlying the RSUs are not considered issued and outstanding until vested and common stock is issued.

[0000080420-18-000007:notes:22]
RSU activity (number of shares) for the three months ended December 31, 2017 is summarized below:

[0000080420-18-000007:notes:23]
|  | Number ofRestrictedStockUnits |  | WeightedAverageFair ValuePer Share |
| Outstanding at September 30, 2017 | 177,737 |  |  | $ | 37.00 |  |
| Granted | 86,500 |  |  | 29.88 |  |
| Vested | (34,853 | ) |  | 35.64 |  |
| Forfeited/canceled | (22,800 | ) |  | 41.88 |  |
| Outstanding at December 31, 2017 | 206,584 |  |  | $ | 33.71 |  |

[0000080420-18-000007:notes:24]
During the three months ended December 31, 2017 and 2016, we recorded compensation expense of $1.0 million and $0.9 million, respectively, related to the RSUs.

[0000080420-18-000007:notes:25]
[same as prior period, unchanged from 0000080420-17-000020:notes:25]

[0000080420-18-000007:notes:26]
Each non-employee director receives 2,000 restricted shares of the Company’s common stock annually. Fifty-percent of the restricted stock granted to each of our non-employee directors vests immediately, while the remaining fifty-percent will vest on the first anniversary of the grant date. Compensation expense is recognized immediately for the first fifty-percent of the restricted stock granted, while compensation expense for the remaining fifty-percent is recognized over the remaining vesting period based on the price per share on the grant date. During the first quarter of Fiscal 2017 and Fiscal 2016, there were no restricted shares granted.

[0000080420-18-000007:notes:27]
During the three months ended December 31, 2017 and 2016, we recorded compensation expense of $0.1 million, respectively, related to restricted stock.


## us-gaap:EarningsPerShareTextBlock

[0000080420-18-000007:notes:28]
[same as prior period, unchanged from 0000080420-17-000020:notes:28]

[0000080420-18-000007:notes:29]
[same as prior period, unchanged from 0000080420-17-000020:notes:29]

[0000080420-18-000007:notes:30]
[same as prior period, unchanged from 0000080420-17-000020:notes:30]

[0000080420-18-000007:notes:31]
|  | Three months ended December 31, |
|  | 2017 |  | 2016 |
| Numerator: |  |  |  |
| Net loss | $ | (5,662 | ) |  | $ | (300 | ) |
| Denominator: |  |  |  |
| Weighted average basic shares | 11,497 |  |  | 11,438 |  |
| Dilutive effect of restricted stock units | — |  |  | — |  |
| Weighted average diluted shares with assumed conversions | 11,497 |  |  | 11,438 |  |
| Net loss per share: |  |  |  |
| Basic | $ | (0.49 | ) |  | $ | (0.03 | ) |
| Diluted | $ | (0.49 | ) |  | $ | (0.03 | ) |

[0000080420-18-000007:notes:32]
For the quarters ended December 31, 2017 and 2016, we incurred net losses and therefore all potential common shares were deemed to be anti-dilutive.


## us-gaap:FairValueDisclosuresTextBlock

[0000080420-18-000007:notes:33]
[same as prior period, unchanged from 0000080420-17-000020:notes:33]

[0000080420-18-000007:notes:34]
[same as prior period, unchanged from 0000080420-17-000020:notes:34]

[0000080420-18-000007:notes:35]
[same as prior period, unchanged from 0000080420-17-000020:notes:35]

[0000080420-18-000007:notes:36]
[same as prior period, unchanged from 0000080420-17-000020:notes:36]

[0000080420-18-000007:notes:37]
[same as prior period, unchanged from 0000080420-17-000020:notes:37]

[0000080420-18-000007:notes:38]
[same as prior period, unchanged from 0000080420-17-000020:notes:38]

[0000080420-18-000007:notes:39]
The following table summarizes the fair value of our assets and liabilities that were accounted for at fair value on a recurring basis as of December 31, 2017 (in thousands):

[0000080420-18-000007:notes:40]
|  | Fair Value Measurements at December 31, 2017 |
|  | Quoted Prices inActive Markets forIdentical Assets(Level 1) |  | Significant OtherObservableInputs(Level 2) |  | SignificantUnobservableInputs(Level 3) |  | Fair Value at December 31, 2017 |
| Assets: |  |  |  |  |  |  |  |
| Cash and cash equivalents | $ | 49,587 |  |  | $ | — |  |  | $ | — |  |  | $ | 49,587 |  |
| Short-term investments | 23,101 |  |  | — |  |  | — |  |  | 23,101 |  |
| Restricted cash | 27,776 |  |  | — |  |  | — |  |  | 27,776 |  |
| Deferred compensation | — |  |  | 6,641 |  |  | — |  |  | 6,641 |  |
| Liabilities: |  |  |  |  |  |  |  |
| Deferred compensation | — |  |  | 5,322 |  |  | — |  |  | 5,322 |  |

[0000080420-18-000007:notes:41]
The following table summarizes the fair value of our assets and liabilities that were accounted for at fair value on a recurring basis as of September 30, 2017 (in thousands):

[0000080420-18-000007:notes:42]
|  | Fair Value Measurements at September 30, 2017 |
|  | Quoted Prices inActive Markets forIdentical Assets(Level 1) |  | Significant OtherObservableInputs(Level 2) |  | SignificantUnobservableInputs(Level 3) |  | Fair Value at September 30, 2017 |
| Assets: |  |  |  |  |  |  |  |
| Cash and cash equivalents | $ | 68,359 |  |  | $ | — |  |  | $ | — |  |  | $ | 68,359 |  |
| Short-term investments | 26,829 |  |  |  |  |  |  | 26,829 |  |
| Restricted cash | 24,851 |  |  |  |  |  |  | 24,851 |  |
| Deferred compensation | — |  |  | 6,442 |  |  | — |  |  | 6,442 |  |
| Liabilities: |  |  |  |  |  |  |  |
| Deferred compensation | — |  |  | 4,991 |  |  | — |  |  | 4,991 |  |

[0000080420-18-000007:notes:43]
[same as prior period, unchanged from 0000080420-17-000020:notes:45]

[0000080420-18-000007:notes:44]
Cash and cash equivalents

[0000080420-18-000007:notes:45]
Cash and cash equivalents, primarily funds held in money market savings instruments, are reported at their current carrying value which approximates fair value due to the short-term nature of these instruments and are included in cash and cash equivalents in our Condensed Consolidated Balance Sheets.

[0000080420-18-000007:notes:46]
[same as prior period, unchanged from 0000080420-17-000020:notes:46]

[0000080420-18-000007:notes:47]
Restricted Cash – Restricted cash represents a pledged cash collateral balance which is required under our U.S.  Revolver and is held in an interest-bearing savings account. See Note D for further discussion on restricted cash.

[0000080420-18-000007:notes:48]
Deferred Compensation – We hold investments in an irrevocable Rabbi Trust for our deferred compensation plan. These assets include both mutual fund investments and company-owned life insurance policies. Under the plan, participants designate investment options to serve as the basis for measurement of the notional value of their accounts. The mutual funds and company-owned life insurance policies are combined in the plan and are therefore categorized as Level 2 in the fair value measurement hierarchy.

[0000080420-18-000007:notes:49]
There were no transfers between levels within the fair value measurement hierarchy during the three months ended December 31, 2017.


## us-gaap:IncomeTaxDisclosureTextBlock

[0000080420-18-000007:notes:50]
[same as prior period, unchanged from 0000080420-17-000020:notes:56]

[0000080420-18-000007:notes:51]
[same as prior period, unchanged from 0000080420-17-000020:notes:57]

[0000080420-18-000007:notes:52]
|  | Three months ended December 31, |
|  | 2017 |  | 2016 |
| Loss before income taxes | $ | (6,733 | ) |  | $ | (1,741 | ) |
| Income tax benefit | (1,071 | ) |  | (1,441 | ) |
| Net loss | $ | (5,662 | ) |  | $ | (300 | ) |
| Effective tax rate | 16 | % |  | 83 | % |

[0000080420-18-000007:notes:53]
On December 22, 2017, the U.S. Tax Cuts and Jobs Act (the Act) was signed into law. The Act lowers the corporate tax rate for C corporations from 35% to 21% effective January 1, 2018. As a result, the effective tax rate for the three months ended December 31, 2017 represents a reduced blended U.S. tax rate of 24.5%, but was partially offset by deferred tax expense of $0.7 million due to the re-measurement of our U.S. deferred tax assets, which are not expected to be realized prior to the end of Fiscal 2018. The final impact of the Act may differ from our estimates based on changes in interpretations or assumptions we make, as well as the issuance of additional guidance. Additionally, our effective tax rate for the three months ended December 31, 2017 was reduced by a $0.2 million foreign tax loss which is reserved with a valuation allowance.

[0000080420-18-000007:notes:54]
The effective tax rate for the three months ended December 31, 2016 was favorably impacted by the lower tax rate in the United Kingdom, the relative amounts of income/loss recognized in various jurisdictions, as well as the utilization of net operating loss carryforwards in Canada that are fully reserved with a valuation allowance. We also completed an IRS audit during the three months ended December 2016, which favorably impacted the effective tax rate due to the release of a $0.3 million FIN 48 reserve relating to the Research and Development Tax Credit.


## us-gaap:LongTermDebtTextBlock

[0000080420-18-000007:notes:55]
LONG-TERM DEBT

[0000080420-18-000007:notes:56]
Long-term debt consisted of the following (in thousands):

[0000080420-18-000007:notes:57]
|  | December 31, 2017 |  | September 30, 2017 |
| Industrial development revenue bonds | $ | 1,600 |  |  | $ | 2,000 |  |
| Less current portion | (400 | ) |  | (400 | ) |
| Total long-term debt | $ | 1,200 |  |  | $ | 1,600 |  |

[0000080420-18-000007:notes:58]
U.S. Revolver

[0000080420-18-000007:notes:59]
We have a $75.0 million revolving credit facility (U.S. Revolver) to provide working capital support and letters of credit which expires on June 27, 2022. The amount available under the U.S. Revolver at December 31, 2017 was reduced by $27.0 million for our outstanding letters of credit. There were no loans outstanding under the U.S. Revolver as of December 31, 2017. Amounts available under the U.S. Revolver were $48.0 million at December 31, 2017.

[0000080420-18-000007:notes:60]
Per the terms of the U.S. Revolver, we are required to maintain a cash balance in a pledged cash collateral account equal to 102% of the outstanding amount of any loans and letter of credit obligations until we meet certain financial ratios. As of December 31, 2017, the balance in the pledged account was $27.8 million. The cash collateral associated with the outstanding letters of credit that are due to expire beyond twelve months has been classified as non-current restricted cash on the balance sheet as of December 31, 2017.

[0000080420-18-000007:notes:61]
The interest rate for amounts outstanding under the U.S. Revolver is a floating rate based upon the higher of the Federal Funds Rate plus 0.5%, the bank’s prime rate, or the Eurocurrency rate plus 1.00%. Once the applicable rate is determined, a margin ranging up to 1.25% is added to the applicable rate.

[0000080420-18-000007:notes:62]
The U.S. Revolver is collateralized by a pledge of 100% of the voting capital stock of each of our domestic subsidiaries and 65% of the voting capital stock of each non-domestic subsidiary. The U.S. Revolver provides for customary events of default and carries cross-default provisions with other existing debt agreements. If an event of default (as defined in the U.S. Revolver) occurs and is continuing, on the terms and subject to the conditions set forth in the U.S. Revolver, amounts outstanding under the U.S. Revolver may be accelerated and may become immediately due and payable. It also contains financial covenants defining various financial measures and the levels of these measures with which we must comply, as well as a “material adverse change” clause. A “material adverse change” is defined as a material change in our operations, business, properties, liabilities or condition (financial or otherwise) or a material impairment of our ability to perform our obligations under our credit agreements. As of December 31, 2017, we were in compliance with all of the financial covenants of the U.S. Revolver.

[0000080420-18-000007:notes:63]
Industrial Development Revenue Bonds

[0000080420-18-000007:notes:64]
We borrowed $8.0 million in October 2001 through a loan agreement funded with proceeds from tax-exempt industrial development revenue bonds (Bonds). These Bonds were issued by the Illinois Development Finance Authority and were used for the completion of our Northlake, Illinois facility. Pursuant to the Bond issuance, a reimbursement agreement between us and a major domestic bank required an issuance by the bank of an irrevocable direct-pay letter of credit (Bond LC), as collateral, to the Bonds’ trustee to guarantee payment of the Bonds’ principal and interest when due. The Bond LC is subject to both early termination and extension provisions customary to such agreements, as well as various covenants, for which we were in compliance at December 31, 2017. While the Bonds mature in 2021, the reimbursement agreement requires annual redemptions of $0.4 million that commenced on October 25, 2002. A sinking fund is used for the redemption of the Bonds. The Bonds bear interest at a floating rate determined weekly by the Bonds’ remarketing agent, which was the underwriter for the Bonds and is an affiliate of the bank. This interest rate was 1.90% as of December 31, 2017.


## us-gaap:NewAccountingPronouncementsPolicyPolicyTextBlock

[0000080420-18-000007:notes:65]
New Accounting Standards

[0000080420-18-000007:notes:66]
In May 2014, the Financial Accounting Standards Board (FASB) issued a new standard on revenue recognition that supersedes previously issued revenue recognition guidance. This standard provides a five-step approach to be applied to all contracts with customers and requires expanded disclosures about the nature, amount, timing and uncertainty of revenue (and the related cash flows) arising from customer contracts, significant judgments and changes in judgments used in applying the revenue model and the assets recognized from costs incurred to obtain or fulfill a contract. This standard is effective for fiscal years, and interim periods within those years, beginning after December 15, 2017, which would be our fiscal year ending September 30, 2019. We plan to use the modified retrospective basis upon adoption. While we are still evaluating the potential impact of this standard on our financial statements, we believe accounting for variable consideration and the number of performance obligations contained in each contract will have the greatest significance. The materiality of this guidance on our financial statements will be determined in large part by the contracts that are in progress as of the adoption date.

[0000080420-18-000007:notes:67]
In November 2015, the FASB issued an amendment to the topic regarding income taxes which requires an entity to separate deferred income tax liabilities and assets into current and noncurrent amounts in the statement of financial position.  Deferred tax liabilities and assets are classified as current or noncurrent based on the classification of the related asset or liability for financial reporting.  Deferred tax liabilities and assets that are not related to an asset or liability for financial reporting are classified according to the expected reversal date of the temporary difference. To simplify the presentation of deferred income taxes, the amendments require that deferred income tax liabilities and assets be classified as noncurrent in a classified statement of financial position. We have adopted this topic prospectively in Fiscal 2018 and our statement of financial position at December 31, 2017 reflects this reclassification. We have not retrospectively adjusted prior periods.

[0000080420-18-000007:notes:68]
In February 2016, the FASB issued a new topic on leases which requires lessees to recognize lease assets and lease liabilities on the balance sheet for all leases with terms longer than twelve months. Leases will be classified as either finance or operating, with classification affecting the pattern of expense recognition in the income statement. A modified retrospective transition approach is required for lessees for capital and operating leases existing at, or entered into after, the beginning of the earliest comparative period presented in the financial statements, with certain practical expedients available. The new standard is effective for fiscal years beginning after December 15, 2018, including interim periods within those fiscal years. This would be our fiscal year ending September 30, 2020. We are still evaluating the potential impact of this topic on our financial statements.

[0000080420-18-000007:notes:69]
In November 2016, the FASB issued new standards on the statement of cash flows and restricted cash that change the presentation of restricted cash and cash equivalents on the statement of cash flows. Restricted cash and restricted cash equivalents will be included with cash and cash equivalents when reconciling the beginning-of-period and end-of-period total amounts shown on the statement of cash flows. These standards are effective for public business entities for fiscal years beginning after December 15, 2017, and interim periods within those fiscal years, which would be our fiscal year ending September 30, 2019. We have no plans for early adoption. We are still evaluating these new standards, but we do not expect them to have a material impact on our consolidated financial position or results of operations.

[0000080420-18-000007:notes:70]
In January 2017, the FASB issued new guidance on goodwill impairment intended to simplify the testing for goodwill impairment by the elimination of Step 2 in the determination on whether goodwill should be considered impaired. The annual and/or interim assessments are still required to be completed. This guidance is effective for fiscal years (including interim periods) beginning after December 15, 2019, which would be our fiscal year ending September 30, 2021. The adoption of this guidance is not expected to have a material impact on our consolidated financial position or results of operations.

[0000080420-18-000007:notes:71]
In May 2017, the FASB issued a new topic on modification accounting with regards to stock based compensation. This new topic clarifies when a change to the terms or conditions of a share-based payment award should be accounted for as a modification. An entity should account for the effects of a modification unless the fair value, vesting conditions and classification, as an equity instrument or a liability instrument, of the modified award are the same before and after a change to the terms or conditions of the share-based payment award. This topic is effective for annual reporting periods beginning after December 15, 2017, which is our fiscal year ending September 30, 2019. We do not expect this topic to have a material impact on our consolidated financial position or results of operations.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureAndSignificantAccountingPoliciesTextBlock

[0000080420-18-000007:notes:72]
[same as prior period, unchanged from 0000080420-17-000020:notes:81]

[0000080420-18-000007:notes:73]
[same as prior period, unchanged from 0000080420-17-000020:notes:82]

[0000080420-18-000007:notes:74]
Powell Industries, Inc. (we, us, our, Powell or the Company) was incorporated in the state of Delaware in 2004 as a successor to a Nevada company incorporated in 1968. The Nevada company was the successor to a company founded by William E. Powell in 1947, which merged into the Company in 1977. Our major subsidiaries, all of which are wholly owned, include: Powell Electrical Systems, Inc.; Powell (UK) Limited; Powell Canada Inc. and Powell Industries International, B.V.

[0000080420-18-000007:notes:75]
We develop, design, manufacture and service custom-engineered products and systems for the distribution, control and monitoring of electrical energy. Headquartered in Houston, Texas, we serve the oil and gas refining, onshore and offshore oil and gas production, petrochemical, pipeline, terminal, mining and metals, light rail traction power, electric utility, pulp and paper and other heavy industrial markets.

[0000080420-18-000007:notes:76]
[same as prior period, unchanged from 0000080420-17-000020:notes:85]

[0000080420-18-000007:notes:77]
The preparation of condensed consolidated financial statements in conformity with U.S. GAAP requires management to make estimates and assumptions that affect the amounts reported in the condensed consolidated financial statements and accompanying footnotes. The most significant estimates used in our condensed consolidated financial statements affect revenue and cost recognition for construction contracts, the allowance for doubtful accounts, provision for excess and obsolete inventory, warranty accruals and income taxes. The amounts recorded for warranties, legal, income taxes, impairment of long-lived assets (when applicable) and other contingent liabilities require judgments regarding the amount of expenses that will ultimately be incurred. We base our estimates on historical experience and on various other assumptions, as well as the specific circumstances surrounding these contingent liabilities, in evaluating the amount of liability that should be recorded. Additionally, the recognition of deferred tax assets requires estimates related to future income and other assumptions regarding timing and future profitability. Estimates routinely change as new events occur, additional information becomes available or operating environments change. Actual results may differ from our prior estimates.


## us-gaap:ScheduleOfInventoryCurrentTableTextBlock

[0000080420-18-000007:notes:78]
[same as prior period, unchanged from 0000080420-17-000020:notes:91]

[0000080420-18-000007:notes:79]
|  | December 31, 2017 |  | September 30, 2017 |
| Raw materials, parts and subassemblies, net | $ | 17,701 |  |  | $ | 17,848 |  |
| Work-in-progress | 834 |  |  | 600 |  |
| Total inventories | $ | 18,535 |  |  | $ | 18,448 |  |


## us-gaap:ScheduleOfProductWarrantyLiabilityTableTextBlock

[0000080420-18-000007:notes:80]
[same as prior period, unchanged from 0000080420-17-000020:notes:93]

[0000080420-18-000007:notes:81]
|  | Three months ended December 31, |
|  | 2017 |  | 2016 |
| Balance at beginning of period | $ | 3,174 |  |  | $ | 4,639 |  |
| Increase to warranty expense | 195 |  |  | 370 |  |
| Deduction for warranty charges | (478 | ) |  | (725 | ) |
| Change due to foreign currency translation | (1 | ) |  | (54 | ) |
| Balance at end of period | $ | 2,890 |  |  | $ | 4,230 |  |


## us-gaap:SubsequentEventsTextBlock

[0000080420-18-000007:notes:82]
SUBSEQUENT EVENTS

[0000080420-18-000007:notes:83]
On February 5, 2018, our Board of Directors declared a quarterly cash dividend on our common stock in the amount of $0.26 per share. The dividend is payable on March 21, 2018 to shareholders of record at the close of business on February 21, 2018.


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0000080420-18-000007:notes:84]
[same as prior period, unchanged from 0000080420-17-000020:notes:97]

[0000080420-18-000007:notes:85]
[same as prior period, unchanged from 0000080420-17-000020:notes:98]

[0000080420-18-000007:notes:86]
[same as prior period, unchanged from 0000080420-17-000020:notes:99]

[0000080420-18-000007:notes:87]
[same as prior period, unchanged from 0000080420-17-000020:notes:100]

[0000080420-18-000007:notes:88]
[same as prior period, unchanged from 0000080420-17-000020:notes:101]
