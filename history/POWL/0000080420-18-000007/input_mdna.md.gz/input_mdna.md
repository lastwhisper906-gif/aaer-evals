# POWL MD&A — 0000080420-18-000007


## mdna

[0000080420-18-000007:mdna:1]
[same as prior period, unchanged from 0000080420-17-000020:mdna:1]

[0000080420-18-000007:mdna:2]
The following discussion and analysis of our financial condition and results of operations should be read in conjunction with the accompanying condensed consolidated financial statements and related notes included elsewhere in this Quarterly Report on Form 10-Q and with our Annual Report on Form 10-K for the year ended September 30, 2017 which was filed with the Securities and Exchange Commission (SEC) on December 6, 2017 and is available on the SEC’s website at www.sec.gov.

[0000080420-18-000007:mdna:3]
[same as prior period, unchanged from 0000080420-17-000020:mdna:3]

[0000080420-18-000007:mdna:4]
We develop, design, manufacture and service custom-engineered equipment and systems for the distribution, control and monitoring of electrical energy. Headquartered in Houston, Texas, we serve the oil and gas refining, onshore and offshore oil and gas production, petrochemical, pipeline, terminal, mining and metals, light rail traction power, electric utility, pulp and paper and other heavy industrial markets. Revenues and costs are primarily related to custom engineered-to-order equipment and systems and are accounted for under percentage-of-completion accounting which precludes us from providing detailed price and volume information. Our backlog includes various projects that typically take a number of months to produce.

[0000080420-18-000007:mdna:5]
The markets in which we participate are capital intensive and cyclical in nature. Cyclicality is predominantly driven by customer demand, global economic conditions and anticipated environmental, safety or regulatory changes that affect the manner in which our customers proceed with capital investments. Our customers analyze various factors including the demand and price for oil, gas and electrical energy, the overall economic and financial environment, governmental budgets, regulatory actions and environmental concerns. These factors influence the release of new capital projects by our customers, which are traditionally awarded in competitive bid situations. Scheduling of projects is matched to the customer requirements and projects typically take a number of months to produce. Schedules may change during the course of any particular project and our operating results can therefore be impacted by factors outside of our control.

[0000080420-18-000007:mdna:6]
Due to the significant decline in oil and gas prices from peak 2014 levels, many of our customers have reduced their capital budgets and cut costs, and in certain instances have delayed or cancelled projects that we were pursuing. As a result, our revenues and project backlog have declined, and may continue to decline, which may further negatively impact our operations. In response to our reduced project backlog and the challenging market outlook in our core oil, gas and petrochemical markets, we took steps in Fiscal 2016 and 2017 to reduce our overall cost structure and better align our costs with future production requirements.

[0000080420-18-000007:mdna:7]
[same as prior period, unchanged from 0000080420-17-000020:mdna:6]

[0000080420-18-000007:mdna:8]
Quarter Ended December 31, 2017 Compared to the Quarter Ended December 31, 2016 (Unaudited)

[0000080420-18-000007:mdna:9]
[same as prior period, unchanged from 0000080420-17-000020:mdna:8]

[0000080420-18-000007:mdna:10]
Revenues decreased by 18%, or $20.2 million, to $90.2 million in the first quarter of Fiscal 2018, compared to the first quarter of Fiscal 2017, primarily due to the continued decrease in our project backlog as we complete existing projects and continue to see lower demand from our customers in our core oil, gas and petrochemical markets. Domestic revenues decreased by 30%, or $25.6 million, to $60.1 million in the first quarter of Fiscal 2018, compared to the first quarter of Fiscal 2017, and international revenues increased by 22%, or $5.4 million, to $30.1 million in the first quarter of Fiscal 2018, compared to the first quarter of Fiscal 2017. The reduction in domestic revenues year over year was driven by the decline in our project backlog mentioned above. However, short-term, high demand remediation efforts following Hurricane Harvey resulted in approximately $7 million of revenue which partially offset the market challenges discussed above. Revenues from commercial and industrial customers decreased by 16%, or $11.9 million, to $60.8 million in the first quarter of Fiscal 2018, compared to the first quarter of Fiscal 2017, primarily due to lower demand in our core oil, gas and petrochemical markets. Revenues from public and private utilities increased by 53%, or $8.7 million, to $25.3 million in the first quarter of Fiscal 2018, compared to the first quarter of Fiscal 2017. Revenues from municipal and transit projects decreased by 80%, or $17.0 million, to $4.1 million in the first quarter of Fiscal 2018, compared to the first quarter of Fiscal 2017. The increase in public and private utilities and the decrease in municipal and transit revenues were primarily due to the timing of projects.

[0000080420-18-000007:mdna:11]
Gross profit for the first quarter of Fiscal 2018 decreased by 30%, or $4.4 million, to $10.6 million, compared to the first quarter of Fiscal 2017. Gross profit as a percentage of revenues decreased to 12% in the first quarter of Fiscal 2018, compared to 14% in the first quarter of Fiscal 2017. Gross profit and margins continued to be negatively impacted by our reduced volume resulting in under absorption of our manufacturing facility costs and a shift in project mix to smaller projects. This decline in volume and margins is primarily due to the decline in our project backlogs at the beginning of the respective periods resulting from depressed market conditions and competitive pricing pressures primarily in our core oil, gas and petrochemical markets. Gross profit and margins were also negatively impacted by costs incurred on an oil and gas project for which change orders have not been finalized.

[0000080420-18-000007:mdna:12]
[same as prior period, unchanged from 0000080420-17-000020:mdna:11]

[0000080420-18-000007:mdna:13]
Selling, general and administrative expenses increased by 3%, or $0.5 million, to $16.2 million during the first quarter of Fiscal 2018, compared to the first quarter of Fiscal 2017 primarily due to the timing of variable performance based compensation.  Selling, general and administrative expenses, as a percentage of revenues, increased to 18% during the first quarter of Fiscal 2018, compared to 14% during the first quarter of Fiscal 2017, primarily due to the reduction in revenue and slight increase in costs quarter over quarter.

[0000080420-18-000007:mdna:14]
[same as prior period, unchanged from 0000080420-17-000020:mdna:30]

[0000080420-18-000007:mdna:15]
We recorded an income tax benefit of $1.1 million in the first quarter of Fiscal 2018, compared to an income tax benefit of $1.4 million in the first quarter of Fiscal 2017. The effective tax rate for the first quarter of Fiscal 2018 was 16% compared to an effective tax rate of 83% in the first quarter of Fiscal 2017. The effective tax rate for the first quarter of Fiscal 2018 was reduced by the U.S. Tax Cuts and Jobs Act (the Act). The Act lowers the corporate tax rate for C corporations from 35% to 21% effective January 1, 2018. As a result, the effective tax rate for the first quarter of Fiscal 2018 represents a reduced blended U.S. tax rate of 24.5% for Fiscal 2018, but was partially offset by deferred tax expense of $0.7 million due to the re-measurement of our U.S. deferred tax assets, which are not expected to be realized prior to the end of Fiscal 2018. The final impact of the Act may differ from our estimates based on changes in interpretations or assumptions we make, as well as the issuance of additional guidance. Additionally our effective tax rate for the first quarter of Fiscal 2018 was reduced by a $0.2 million foreign tax loss which is reserved with a valuation allowance.

[0000080420-18-000007:mdna:16]
The effective tax rate for the first quarter of Fiscal 2017 was favorably impacted by the lower tax rate in the United Kingdom, the relative amounts of income/loss recognized in various jurisdictions, as well as the utilization of net operating loss carryforwards in Canada that are fully reserved with a valuation allowance. We also completed an IRS audit during the first quarter of Fiscal 2017, which favorably impacted the effective tax rate due to the release of a $0.3 million FIN 48 reserve relating to the Research and Development Tax Credit.

[0000080420-18-000007:mdna:17]
Net loss

[0000080420-18-000007:mdna:18]
In the first quarter of Fiscal 2018, we recorded a loss of $5.7 million, or $0.49 per diluted share compared to a net loss of $0.3 million, or $0.03 per diluted share, in the first quarter of Fiscal 2017. The increase in our net loss compared to the prior year was primarily due to a decline in our project backlog due to depressed market conditions and competitive pricing pressures, primarily in our core oil, gas and petrochemical markets and the reduction in our effective tax rate as a result of the Act.

[0000080420-18-000007:mdna:19]
[same as prior period, unchanged from 0000080420-17-000020:mdna:20]

[0000080420-18-000007:mdna:20]
The order backlog at December 31, 2017 was $260.3 million, an increase from the $250.1 million at September 30, 2017, primarily due to an increase in commercial and industrial projects. New orders increased during the first quarter of Fiscal 2018 to $100.0 million, compared to $90.8 million in the first quarter of Fiscal 2017.

[0000080420-18-000007:mdna:21]
[same as prior period, unchanged from 0000080420-17-000020:mdna:36]

[0000080420-18-000007:mdna:22]
As of December 31, 2017, current assets exceeded current liabilities by 2.8 times and our debt to total capitalization was 0.51%.

[0000080420-18-000007:mdna:23]
Cash, cash equivalents and short-term investments decreased to $72.7 million at December 31, 2017, compared to $95.2 million at September 30, 2017. We had restricted cash held in a pledged collateral account related to our U.S. Revolver of $27.8 million at December 31, 2017 and $24.9 million at September 30, 2017. For further information regarding our U.S. Revolver, see Note D of Notes to Condensed Consolidated Financial Statements.

[0000080420-18-000007:mdna:24]
Our U.S. Revolver is a $75.0 million revolving credit facility in the U.S. As of December 31, 2017, there were no amounts borrowed under this facility. Total letters of credit outstanding under our U.S. Revolver, which reduce our availability, were $27.0 million at December 31, 2017 and $24.1 million at September 30, 2017. The amount available under our U.S. Revolver at December 31, 2017 was $48.0 million. Total long-term debt, including current maturities, totaled $1.6 million at December 31, 2017, compared to $2.0 million at September 30, 2017. For further information regarding our debt, see Notes D and E of Notes to Condensed Consolidated Financial Statements.

[0000080420-18-000007:mdna:25]
Approximately $35 million of our cash and short-term investments at December 31, 2017 was held outside of the United States for international operations. It is our intention to indefinitely reinvest all current and future foreign earnings internationally in order to ensure sufficient working capital to support our international operations. In the event that we elect to repatriate some or

[0000080420-18-000007:mdna:26]
all of the foreign earnings that were previously deemed to be indefinitely reinvested outside the U.S., under current tax laws we would incur additional tax expense upon such repatriation.

[0000080420-18-000007:mdna:27]
We believe that cash and short-term investments available and borrowing capacity under our U.S. Revolver should be sufficient to finance future operating activities, capital improvements and debt repayments for the foreseeable future. We continue to monitor the factors that drive our markets and will continue to strive to maintain our leadership and competitive advantage in the markets we serve while aligning our cost structures with market conditions.

[0000080420-18-000007:mdna:28]
[same as prior period, unchanged from 0000080420-17-000020:mdna:42]

[0000080420-18-000007:mdna:29]
Cash used by operating activities decreased to $14.1 million for the first quarter of Fiscal 2018, compared to cash provided by operating activities of $3.4 million during the same period in Fiscal 2017. This decrease in operating cash flow for the first quarter of Fiscal 2018 was primarily due to the reduction in earnings year over year and increases in accounts receivable, partially offset by project billings. Cash flow from operations is primarily influenced by project volume, the timing of milestone payments from our customers and the payment terms with our suppliers.

[0000080420-18-000007:mdna:30]
[same as prior period, unchanged from 0000080420-17-000020:mdna:44]

[0000080420-18-000007:mdna:31]
Net cash used in investing activities during the first quarter of Fiscal 2018 totaled $0.9 million compared to $15.8 million during the same period in Fiscal 2017. For the first quarter of Fiscal 2018, our net short-term investment activity was $3.7 million and we spent approximately $1.7 million on purchases of plant improvements and equipment. In the first quarter of Fiscal 2017, we had purchases of short-term investments of $14.9 million.

[0000080420-18-000007:mdna:32]
[same as prior period, unchanged from 0000080420-17-000020:mdna:46]

[0000080420-18-000007:mdna:33]
Net cash used in financing activities was $3.8 million for the both the first quarter of Fiscal 2018 and Fiscal 2017. This was primarily for cash dividends of $3.0 million in both periods.

[0000080420-18-000007:mdna:34]
[same as prior period, unchanged from 0000080420-17-000020:mdna:50]

[0000080420-18-000007:mdna:35]
See Note A of Notes to Condensed Consolidated Financial Statements included in this report for information on new accounting standards.

[0000080420-18-000007:mdna:36]
Critical Accounting Policies and Estimates

[0000080420-18-000007:mdna:37]
[same as prior period, unchanged from 0000080420-17-000020:mdna:53]

[0000080420-18-000007:mdna:38]
There have been no material changes to our critical accounting policies as disclosed in our Annual Report on Form 10-K for the year ended September 30, 2017.

[0000080420-18-000007:mdna:39]
For the three months ended December 31, 2017, our operating loss was positively impacted by $2.0 million, as a result of changes in contract estimates related to projects in progress at the beginning of the respective periods. These changes in estimates resulted primarily from, among other things, successful execution and close-out improvements, as well as other changes in facts and circumstances during these periods.

[0000080420-18-000007:mdna:40]
[same as prior period, unchanged from 0000080420-17-000020:mdna:55]

[0000080420-18-000007:mdna:41]
[same as prior period, unchanged from 0000080420-17-000020:mdna:56]

[0000080420-18-000007:mdna:42]
A significant portion of our revenues have historically been from the oil, gas and petrochemical markets. Unfavorable oil and gas commodity price levels have caused, and we anticipate will continue to cause, our customers to delay their investments. The reduction in available projects across the markets we serve has increased price pressures during this market cycle. This reduction in new business opportunities and increased market price pressures have impacted, and may continue to negatively impact, our backlog, revenues and operating results.

[0000080420-18-000007:mdna:43]
Our operating results have been, and we anticipate will continue to be, negatively impacted by factors such as the timing of new order awards, customer approval of final engineering and design specifications and delays in customer construction schedules, all of which have and will continue to have, a negative impact on the timing of project execution. Our operating results also have been, and will continue to be, impacted by the timing and resolution of change orders, project close-out and resolution of potential contract claims and liquidated damages, all of which could improve or deteriorate gross margins during the period in which these items are resolved with our customers. These factors may result in periods of underutilization of our resources and facilities and negatively impact our ability to cover our fixed costs. If our core oil, gas and petrochemical markets do not improve, or decline further, our project backlog and revenue could continue to decline and negatively impact our operations. In response to our reduced project backlog and depressed market outlook, we took steps in Fiscal 2016 and 2017 to reduce our overall cost structure and better align our costs with future production requirements. We continue to assess our cost structure, operating performance and service offerings as the oil, gas and petrochemical markets remain challenging and uncertain. We anticipate that in Fiscal 2018, additional actions may be necessary.

[0000080420-18-000007:mdna:44]
We believe that our strong working capital position, cash available, low debt position and borrowing capacity under our existing credit facility should be sufficient to finance future operating activities, research and development initiatives, capital improvements and debt repayments for the foreseeable future. We continue to monitor the factors that drive our markets and will continue to strive to maintain our leadership and competitive advantage in the markets we serve while aligning our cost structures with market conditions.
