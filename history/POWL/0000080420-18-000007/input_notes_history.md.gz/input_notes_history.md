# POWL note change history — 0000080420-17-000020 → 0000080420-18-000007


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2018-02-07):
[0000080420-18-000007:note_history:1]
Letters of Credit, Surety Bonds and Bank Guarantees
  (was, 2017-08-09, similarity 0.7059):
[0000080420-17-000020:note_history:1]
Letters of Credit and Surety Bonds

- added (2018-02-07):
[0000080420-18-000007:note_history:2]
Certain customers require us to post letters of credit or surety bonds which assure that we will perform under the terms of our contract. In the event of default, the counterparty may demand payment from the bank under a letter of credit or performance by the surety under a bond. To date, there have been no significant expenses related to either letters of credit or surety bonds for the periods reported. We were contingently liable for letters of credit of $27.0 million as of December 31, 2017. We also had surety bonds totaling $217.0 million that were outstanding, with additional bonding capacity of $533.0 million available, at December 31, 2017.

- changed (2018-02-07):
[0000080420-18-000007:note_history:3]
Additionally, we have a $6.7 million facility agreement (Facility Agreement) between Powell (UK) Limited and a large international bank. This Facility Agreement provides Powell (UK) Limited the ability to enter into bank guarantees as well as forward exchange contracts and currency options. At December 31, 2017, we had outstanding guarantees totaling $3.9 million under this Facility Agreement and amounts available under this Facility Agreement were $2.8 million. This facility expires in May 2018. The Facility Agreement provides for financial covenants and customary events of default, and carries cross-default provisions with our U.S. Revolver. If an event of default (as defined in the Facility Agreement) occurs and is continuing, per the terms and subject to the conditions set forth therein, obligations outstanding under the Facility Agreement may be accelerated and declared immediately due and payable. As of December 31, 2017, we were in compliance with all of the financial covenants of the Facility Agreement.
  (was, 2017-08-09, similarity 0.9725):
[0000080420-17-000020:note_history:3]
We have a $6.5 million facility agreement (Facility Agreement) between Powell (UK) Limited and a large international bank. This Facility Agreement provides Powell (UK) Limited the ability to enter into bank guarantees as well as forward exchange contracts and currency options. At June 30, 2017, we had outstanding guarantees totaling $4.2 million under this Facility Agreement and amounts available under this Facility Agreement were $2.3 million.  This facility expires in May 2018. The Facility Agreement provides for financial covenants and customary events of default, and carries cross-default provisions with our U.S. Revolver. If an event of default (as defined in the Facility Agreement) occurs and is continuing, per the terms and subject to the conditions set forth therein, obligations outstanding under the Facility Agreement may be accelerated and may become or be declared immediately due and payable. As of June 30, 2017, we were in compliance with all of the financial covenants of the Facility Agreement.

- changed (2018-02-07):
[0000080420-18-000007:note_history:4]
Certain of our customer contracts have schedule and performance obligation clauses that, if we fail to meet them, could require us to pay liquidated damages. Each individual contract defines the conditions under which the customer may make a claim against us. As of December 31, 2017, our exposure to possible liquidated damages was $2.4 million, of which approximately $1.5 million is probable. Based on our actual or projected failure to meet these various contractual commitments, $1.4 million has been recorded as a reduction to revenue. We will attempt to obtain change orders, contract extensions or accelerate project completion which may resolve the potential for any unaccrued liquidated damage. Should we fail to achieve relief on some or all of these contractual obligations, we could be required to pay additional liquidated damages, which could negatively impact our future operating results.
  (was, 2017-08-09, similarity 0.9933):
[0000080420-17-000020:note_history:4]
Certain of our customer contracts have schedule and performance obligation clauses that, if we fail to meet them, could require us to pay liquidated damages. Each individual contract defines the conditions under which the customer may make a claim against us. As of June 30, 2017, our exposure to possible liquidated damages was $6.8 million, of which approximately $1.5 million is probable.  Based on our actual or projected failure to meet these various contractual commitments, $1.5 million has been recorded as a reduction to revenue. We will attempt to obtain change orders, contract extensions or accelerate project completion which may resolve the potential for any unaccrued liquidated damage. Should we fail to achieve relief on some or all of these contractual obligations, we could be required to pay additional liquidated damages, which could negatively impact our future operating results.

- removed (2018-02-07):
[0000080420-17-000020:note_history:5]
Certain customers require us to post bank letter of credit guarantees or surety bonds. These guarantees and surety bonds assure that we will perform under the terms of our contract. In the event of default, the counterparty may demand payment from the bank under a letter of credit or performance by the surety under a bond. To date, there have been no significant expenses related to either letters of credit or surety bonds for the periods reported. We were contingently liable for secured and unsecured letters of credit of $24.6 million as of June 30, 2017. We also had surety bonds totaling $221.7 million that were outstanding, with additional bonding capacity of $528.3 million available, at June 30, 2017.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureAndSignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2018-02-07):
[0000080420-18-000007:note_history:6]
Powell Industries, Inc. (we, us, our, Powell or the Company) was incorporated in the state of Delaware in 2004 as a successor to a Nevada company incorporated in 1968. The Nevada company was the successor to a company founded by William E. Powell in 1947, which merged into the Company in 1977. Our major subsidiaries, all of which are wholly owned, include: Powell Electrical Systems, Inc.; Powell (UK) Limited; Powell Canada Inc. and Powell Industries International, B.V.
  (was, 2017-08-09, similarity 0.9848):
[0000080420-17-000020:note_history:6]
Powell Industries, Inc. (we, us, our, Powell or the Company) was incorporated in the state of Delaware in 2004 as a successor to a Nevada company incorporated in 1968. The Nevada corporation was the successor to a company founded by William E. Powell in 1947, which merged into the Company in 1977. Our major subsidiaries, all of which are wholly owned, include: Powell Electrical Systems, Inc.; Powell (UK) Limited; Powell Canada Inc. and Powell Industries International, B.V.

- changed (2018-02-07):
[0000080420-18-000007:note_history:7]
We develop, design, manufacture and service custom-engineered products and systems for the distribution, control and monitoring of electrical energy. Headquartered in Houston, Texas, we serve the oil and gas refining, onshore and offshore oil and gas production, petrochemical, pipeline, terminal, mining and metals, light rail traction power, electric utility, pulp and paper and other heavy industrial markets.
  (was, 2017-08-09, similarity 0.9566):
[0000080420-17-000020:note_history:7]
We develop, design, manufacture and service custom-engineered equipment and systems for the distribution, control and monitoring of electrical energy. Headquartered in Houston, Texas, we serve the oil and gas refining, offshore oil and gas production, petrochemical, pipeline, terminal, mining and metals, light rail traction power, electric utility, pulp and paper and other industrial markets.

- changed (2018-02-07):
[0000080420-18-000007:note_history:8]
The preparation of condensed consolidated financial statements in conformity with U.S. GAAP requires management to make estimates and assumptions that affect the amounts reported in the condensed consolidated financial statements and accompanying footnotes. The most significant estimates used in our condensed consolidated financial statements affect revenue and cost recognition for construction contracts, the allowance for doubtful accounts, provision for excess and obsolete inventory, warranty accruals and income taxes. The amounts recorded for warranties, legal, income taxes, impairment of long-lived assets (when applicable) and other contingent liabilities require judgments regarding the amount of expenses that will ultimately be incurred. We base our estimates on historical experience and on various other assumptions, as well as the specific circumstances surrounding these contingent liabilities, in evaluating the amount of liability that should be recorded. Additionally, the recognition of deferred tax assets requires estimates related to future income and other assumptions regarding timing and future profitability. Estimates routinely change as new events occur, additional information becomes available or operating environments change. Actual results may differ from our prior estimates.
  (was, 2017-08-09, similarity 0.9528):
[0000080420-17-000020:note_history:8]
The preparation of condensed consolidated financial statements in conformity with U.S. GAAP requires management to make estimates and assumptions that affect the amounts reported in the condensed consolidated financial statements and accompanying footnotes. The most significant estimates used in our condensed consolidated financial statements affect revenue and cost recognition for construction contracts, the allowance for doubtful accounts, provision for excess and obsolete inventory, self-insurance, warranty accruals, liquidated damages and income taxes. The amounts recorded for insurance claims, warranties, legal, liquidated damages, income taxes and other contingent liabilities require judgments regarding the amount of expenses that will ultimately be incurred. We base our estimates on historical experience and on various other assumptions, as well as the specific circumstances surrounding these contingent liabilities, in evaluating the amount of liability that should be recorded. Additionally, the recognition of deferred tax assets requires estimates related to future income and other assumptions regarding timing and future profitability. Estimates routinely change as new events occur, additional information becomes available or operating environments change. Actual results may differ from our prior estimates.

- added (2018-02-07):
[0000080420-18-000007:note_history:9]
In May 2014, the Financial Accounting Standards Board (FASB) issued a new standard on revenue recognition that supersedes previously issued revenue recognition guidance. This standard provides a five-step approach to be applied to all contracts with customers and requires expanded disclosures about the nature, amount, timing and uncertainty of revenue (and the related cash flows) arising from customer contracts, significant judgments and changes in judgments used in applying the revenue model and the assets recognized from costs incurred to obtain or fulfill a contract. This standard is effective for fiscal years, and interim periods within those years, beginning after December 15, 2017, which would be our fiscal year ending September 30, 2019. We plan to use the modified retrospective basis upon adoption. While we are still evaluating the potential impact of this standard on our financial statements, we believe accounting for variable consideration and the number of performance obligations contained in each contract will have the greatest significance. The materiality of this guidance on our financial statements will be determined in large part by the contracts that are in progress as of the adoption date.

- changed (2018-02-07):
[0000080420-18-000007:note_history:10]
In November 2015, the FASB issued an amendment to the topic regarding income taxes which requires an entity to separate deferred income tax liabilities and assets into current and noncurrent amounts in the statement of financial position.  Deferred tax liabilities and assets are classified as current or noncurrent based on the classification of the related asset or liability for financial reporting.  Deferred tax liabilities and assets that are not related to an asset or liability for financial reporting are classified according to the expected reversal date of the temporary difference. To simplify the presentation of deferred income taxes, the amendments require that deferred income tax liabilities and assets be classified as noncurrent in a classified statement of financial position. We have adopted this topic prospectively in Fiscal 2018 and our statement of financial position at December 31, 2017 reflects this reclassification. We have not retrospectively adjusted prior periods.
  (was, 2017-08-09, similarity 0.7603):
[0000080420-17-000020:note_history:10]
In November 2015, the FASB issued an amendment to the topic regarding income taxes which requires an entity to separate deferred income tax liabilities and assets into current and noncurrent amounts in the statement of financial position.  Deferred tax liabilities and assets are classified as current or noncurrent based on the classification of the related asset or liability for financial reporting.  Deferred tax liabilities and assets that are not related to an asset or liability for financial reporting are classified according to the expected reversal date of the temporary difference. To simplify the presentation of deferred income taxes, the amendments require that deferred income tax liabilities and assets be classified as noncurrent in a classified statement of financial position.  This amendment is effective for annual reporting periods beginning after December 15, 2016, which would be our fiscal year ending September 30, 2018. We have no plans for early adoption. We are still evaluating this new amendment, but we do not expect it to have a material impact on our consolidated financial position or results of operations.

- changed (2018-02-07):
[0000080420-18-000007:note_history:11]
In February 2016, the FASB issued a new topic on leases which requires lessees to recognize lease assets and lease liabilities on the balance sheet for all leases with terms longer than twelve months. Leases will be classified as either finance or operating, with classification affecting the pattern of expense recognition in the income statement. A modified retrospective transition approach is required for lessees for capital and operating leases existing at, or entered into after, the beginning of the earliest comparative period presented in the financial statements, with certain practical expedients available. The new standard is effective for fiscal years beginning after December 15, 2018, including interim periods within those fiscal years. This would be our fiscal year ending September 30, 2020. We are still evaluating the potential impact of this topic on our financial statements.
  (was, 2017-08-09, similarity 0.8706):
[0000080420-17-000020:note_history:11]
In February 2016, the FASB issued a new topic on leases which requires lessees to recognize lease assets and lease liabilities on the balance sheet for all leases with terms longer than twelve months. Leases will be classified as either finance or operating, with classification affecting the pattern of expense recognition in the income statement. A modified retrospective transition approach is required for lessees for capital and operating leases existing at, or entered into after, the beginning of the earliest comparative period presented in the financial statements, with certain practical expedients available. The new standard is effective for fiscal years beginning after December 15, 2018, including interim periods within those fiscal years. This would be our fiscal year ending September 30, 2020.  We plan to adopt this new standard beginning in Fiscal 2018, and do not expect it to have a material impact on our consolidated financial position or results of operations.

- added (2018-02-07):
[0000080420-18-000007:note_history:12]
In January 2017, the FASB issued new guidance on goodwill impairment intended to simplify the testing for goodwill impairment by the elimination of Step 2 in the determination on whether goodwill should be considered impaired. The annual and/or interim assessments are still required to be completed. This guidance is effective for fiscal years (including interim periods) beginning after December 15, 2019, which would be our fiscal year ending September 30, 2021. The adoption of this guidance is not expected to have a material impact on our consolidated financial position or results of operations.

- changed (2018-02-07):
[0000080420-18-000007:note_history:13]
In May 2017, the FASB issued a new topic on modification accounting with regards to stock based compensation. This new topic clarifies when a change to the terms or conditions of a share-based payment award should be accounted for as a modification. An entity should account for the effects of a modification unless the fair value, vesting conditions and classification, as an equity instrument or a liability instrument, of the modified award are the same before and after a change to the terms or conditions of the share-based payment award. This topic is effective for annual reporting periods beginning after December 15, 2017, which is our fiscal year ending September 30, 2019. We do not expect this topic to have a material impact on our consolidated financial position or results of operations.
  (was, 2017-08-09, similarity 0.9823):
[0000080420-17-000020:note_history:13]
In May 2017, the FASB issued a new topic on modification accounting with regards to stock based compensation. This new topic clarifies when a change to the terms or conditions of a share-based payment award should be accounted for as a modification. An entity should account for the effects of a modification unless the fair value, vesting conditions and classification, as an equity instrument or a liability instrument, of the modified award are the same before and after a change to the terms or conditions of the share-based payment award. The standard is effective for annual reporting periods beginning after December 15, 2017, which would be our fiscal year ending September 30, 2018. We do not expect this topic to have a material impact on our consolidated financial position or results of operations.

- removed (2018-02-07):
[0000080420-17-000020:note_history:14]
For the three and nine months ended June 30, 2017, our operating loss was positively impacted by $3.6 million and $7.4 million, respectively, as a result of changes in contract estimates related to projects in progress at the beginning of the respective periods. These changes in estimates resulted primarily from, among other things, successful execution and close-out improvements, as well as other changes in facts and circumstances during these periods.

- removed (2018-02-07):
[0000080420-17-000020:note_history:15]
In May 2014, the Financial Accounting Standards Board (FASB) issued a new standard on revenue recognition that supersedes previously issued revenue recognition guidance. This standard provides a five-step approach to be applied to all contracts with customers and requires expanded disclosures about the nature, amount, timing and uncertainty of revenue (and the related cash flows) arising from customer contracts, significant judgments and changes in judgments used in applying the revenue model and the assets recognized from costs incurred to obtain or fulfill a contract. This standard is effective for fiscal years, and interim periods within those years, beginning after December 15, 2017, which would be our fiscal year ending September 30, 2019. We continue to work with various other companies in our industry as well as outside accounting advisors to evaluate this standard and understand the impact that the adoption of this new standard will have on our consolidated financial statements and related disclosures. We believe that we will continue to recognize revenue over time utilizing the cost-to-cost method to measure our progress for the vast majority of our contracts. We have not yet selected a transition method nor have we determined the effect of the standard on our ongoing financial reporting.


## us-gaap:LongTermDebtTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2018-02-07):
[0000080420-18-000007:note_history:16]
|  | December 31, 2017 |  | September 30, 2017 |
| Industrial development revenue bonds | $ | 1,600 |  |  | $ | 2,000 |  |
| Less current portion | (400 | ) |  | (400 | ) |
| Total long-term debt | $ | 1,200 |  |  | $ | 1,600 |  |
  (was, 2017-08-09, similarity 0.9735):
[0000080420-17-000020:note_history:16]
|  | June 30, 2017 |  | September 30, 2016 |
| Industrial development revenue bonds | $ | 2,000 |  |  | $ | 2,400 |  |
| Less current portion | (400 | ) |  | (400 | ) |
| Total long-term debt | $ | 1,600 |  |  | $ | 2,000 |  |

- added (2018-02-07):
[0000080420-18-000007:note_history:17]
We have a $75.0 million revolving credit facility (U.S. Revolver) to provide working capital support and letters of credit which expires on June 27, 2022. The amount available under the U.S. Revolver at December 31, 2017 was reduced by $27.0 million for our outstanding letters of credit. There were no loans outstanding under the U.S. Revolver as of December 31, 2017. Amounts available under the U.S. Revolver were $48.0 million at December 31, 2017.

- added (2018-02-07):
[0000080420-18-000007:note_history:18]
Per the terms of the U.S. Revolver, we are required to maintain a cash balance in a pledged cash collateral account equal to 102% of the outstanding amount of any loans and letter of credit obligations until we meet certain financial ratios. As of December 31, 2017, the balance in the pledged account was $27.8 million. The cash collateral associated with the outstanding letters of credit that are due to expire beyond twelve months has been classified as non-current restricted cash on the balance sheet as of December 31, 2017.

- changed (2018-02-07):
[0000080420-18-000007:note_history:19]
The interest rate for amounts outstanding under the U.S. Revolver is a floating rate based upon the higher of the Federal Funds Rate plus 0.5%, the bank’s prime rate, or the Eurocurrency rate plus 1.00%. Once the applicable rate is determined, a margin ranging up to 1.25% is added to the applicable rate.
  (was, 2017-08-09, similarity 0.7306):
[0000080420-17-000020:note_history:19]
The interest rate for amounts outstanding under the U.S. Revolver is a floating rate based upon the higher of the Federal Funds Rate plus 0.5%, the bank’s prime rate, or the Eurocurrency rate plus 1.00%. Once the applicable rate is determined, a margin ranging up to 1.25% is added to the applicable rate. The U.S. Revolver provides for the issuance of letters of credit which reduce the amounts that may be borrowed under this revolver. We had $24.6 million of outstanding letters of credit under the U.S. Revolver at June 30, 2017.

- changed (2018-02-07):
[0000080420-18-000007:note_history:20]
The U.S. Revolver is collateralized by a pledge of 100% of the voting capital stock of each of our domestic subsidiaries and 65% of the voting capital stock of each non-domestic subsidiary. The U.S. Revolver provides for customary events of default and carries cross-default provisions with other existing debt agreements. If an event of default (as defined in the U.S. Revolver) occurs and is continuing, on the terms and subject to the conditions set forth in the U.S. Revolver, amounts outstanding under the U.S. Revolver may be accelerated and may become immediately due and payable. It also contains financial covenants defining various financial measures and the levels of these measures with which we must comply, as well as a “material adverse change” clause. A “material adverse change” is defined as a material change in our operations, business, properties, liabilities or condition (financial or otherwise) or a material impairment of our ability to perform our obligations under our credit agreements. As of December 31, 2017, we were in compliance with all of the financial covenants of the U.S. Revolver.
  (was, 2017-08-09, similarity 0.6607):
[0000080420-17-000020:note_history:20]
The U.S. Revolver is collateralized by a pledge of 100% of the voting capital stock of each of our domestic subsidiaries and 65% of the voting capital stock of each non-domestic subsidiary. The U.S. Revolver provides for customary events of default and carries cross-default provisions with other existing debt agreements. If an event of default (as defined in the U.S. Revolver) occurs and is continuing, on the terms and subject to the conditions set forth in the U.S. Revolver, amounts outstanding under the U.S. Revolver may be accelerated and may become immediately due and payable. As of June 30, 2017, we were in compliance with all of the financial covenants of the U.S. Revolver.

- changed (2018-02-07):
[0000080420-18-000007:note_history:21]
We borrowed $8.0 million in October 2001 through a loan agreement funded with proceeds from tax-exempt industrial development revenue bonds (Bonds). These Bonds were issued by the Illinois Development Finance Authority and were used for the completion of our Northlake, Illinois facility. Pursuant to the Bond issuance, a reimbursement agreement between us and a major domestic bank required an issuance by the bank of an irrevocable direct-pay letter of credit (Bond LC), as collateral, to the Bonds’ trustee to guarantee payment of the Bonds’ principal and interest when due. The Bond LC is subject to both early termination and extension provisions customary to such agreements, as well as various covenants, for which we were in compliance at December 31, 2017. While the Bonds mature in 2021, the reimbursement agreement requires annual redemptions of $0.4 million that commenced on October 25, 2002. A sinking fund is used for the redemption of the Bonds. The Bonds bear interest at a floating rate determined weekly by the Bonds’ remarketing agent, which was the underwriter for the Bonds and is an affiliate of the bank. This interest rate was 1.90% as of December 31, 2017.
  (was, 2017-08-09, similarity 0.9895):
[0000080420-17-000020:note_history:21]
We borrowed $8.0 million in October 2001 through a loan agreement funded with proceeds from tax-exempt industrial development revenue bonds (Bonds). These Bonds were issued by the Illinois Development Finance Authority and were used for the completion of our Northlake, Illinois facility. Pursuant to the Bond issuance, a reimbursement agreement between us and a major domestic bank required an issuance by the bank of an irrevocable direct-pay letter of credit (Bond LC), as collateral, to the Bonds’ trustee to guarantee payment of the Bonds’ principal and interest when due. The Bond LC is subject to both early termination and extension provisions customary to such agreements, as well as various covenants, for which we were in compliance at June 30, 2017. While the Bonds mature in 2021, the reimbursement agreement requires annual redemptions of $0.4 million that commenced on October 25, 2002. A sinking fund is used for the redemption of the Bonds. The Bonds bear interest at a floating rate determined weekly by the Bonds’ remarketing agent, which was the underwriter for the Bonds and is an affiliate of the bank. This interest rate was 1.05% as of June 30, 2017.

- removed (2018-02-07):
[0000080420-17-000020:note_history:22]
We have a $75.0 million revolving credit facility (U.S. Revolver) to provide working capital support and letters of credit. In June 2017, we entered into the Third Amendment to the Credit Agreement (the Third Amendment). The Third Amendment, among other things, (i) extended the Maturity Date from December 2018 to June 2022; (ii) amended the definition of Applicable Rate by (a) providing that Pricing Level I shall apply when a Cash Collateral Period (described below) is in effect and that Pricing Level II shall apply when no Cash Collateral Period is in effect, (b) decreasing the Letter of Credit Fee percentage for Pricing Level I from 1.00% to 0.875% and (c) increasing the Commitment Fee percentage for both Pricing Level I and Pricing Level II from 0.1875% to 0.20%; (iii) added a new requirement that during a Cash Collateral Period we maintain a cash balance in a pledged cash collateral account equal to at least 102% of the Outstanding Amount of Revolving Loans and Letter of Credit Obligations and (iv) modified the Financial Covenants by requiring that, during any Cash Collateral Period, the Consolidated Current Ratio be no less than 1.10 to 1.0. Price Level 3 has been removed and our ability to pay dividends remains subject to financial covenant restrictions.

- removed (2018-02-07):
[0000080420-17-000020:note_history:23]
Generally, a Cash Collateral Period under the Third Amendment is defined as a fiscal quarter during which we have pledged our cash collateral account to the Administrative Agent. A Cash Collateral Period will terminate on the last day of the fiscal quarter in which we satisfy the Level II Pricing Covenants set forth in the Third Amendment for two consecutive fiscal quarters. If we are not in compliance with the Level II Pricing Covenants, we are subject to Level I Pricing Covenants.

- removed (2018-02-07):
[0000080420-17-000020:note_history:24]
The Cash Collateral Period was in effect as of June 30, 2017, therefore we placed $25.3 million in a pledged cash collateral account, which was 102% of our outstanding letters of credit as of June 30, 2017. The cash collateral associated with the outstanding letters of credit that are due to expire beyond twelve months has been classified as non-current restricted cash on the balance sheet as of June 30, 2017.

- removed (2018-02-07):
[0000080420-17-000020:note_history:25]
There were no borrowings outstanding under the U.S. Revolver as of June 30, 2017. Amounts available under the U.S. Revolver were $50.4 million at June 30, 2017. The U.S. Revolver expires on June 27, 2022.

- removed (2018-02-07):
[0000080420-17-000020:note_history:26]
Canadian Revolver

- removed (2018-02-07):
[0000080420-17-000020:note_history:27]
We had a $7.7 million credit agreement with a major international bank in Canada (the Canadian Revolver) to provide working capital support and letters of credit for our operations in Canada. There were no borrowings or outstanding letters of credit under the Canadian Revolver as of June 30, 2017 and therefore subsequent to June 30, 2017, we canceled the Canadian Revolver. We believe that the cash available in Canada and the U.S. should be sufficient to fund our Canadian operations for the foreseeable future.


## us-gaap:ScheduleOfDebtInstrumentsTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2018-02-07):
[0000080420-18-000007:note_history:28]
|  | December 31, 2017 |  | September 30, 2017 |
| Industrial development revenue bonds | $ | 1,600 |  |  | $ | 2,000 |  |
| Less current portion | (400 | ) |  | (400 | ) |
| Total long-term debt | $ | 1,200 |  |  | $ | 1,600 |  |
  (was, 2017-08-09, similarity 0.9735):
[0000080420-17-000020:note_history:28]
|  | June 30, 2017 |  | September 30, 2016 |
| Industrial development revenue bonds | $ | 2,000 |  |  | $ | 2,400 |  |
| Less current portion | (400 | ) |  | (400 | ) |
| Total long-term debt | $ | 1,600 |  |  | $ | 2,000 |  |


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: tag_name, score: 1.0

- added (2018-02-07):
[0000080420-18-000007:note_history:29]
On February 5, 2018, our Board of Directors declared a quarterly cash dividend on our common stock in the amount of $0.26 per share. The dividend is payable on March 21, 2018 to shareholders of record at the close of business on February 21, 2018.

- removed (2018-02-07):
[0000080420-17-000020:note_history:30]
On August 8, 2017, our Board of Directors declared a quarterly cash dividend on our common stock in the amount of $0.26 per share. The dividend is payable on September 13, 2017 to shareholders of record at the close of business on August 23, 2017.
