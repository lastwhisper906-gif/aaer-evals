# POWL MD&A — 0000080420-20-000027


## mdna

[0000080420-20-000027:mdna:1]
[same as prior period, unchanged from 0000080420-20-000020:mdna:1]

[0000080420-20-000027:mdna:2]
[same as prior period, unchanged from 0000080420-20-000020:mdna:2]

[0000080420-20-000027:mdna:3]
[same as prior period, unchanged from 0000080420-20-000020:mdna:3]

[0000080420-20-000027:mdna:4]
[same as prior period, unchanged from 0000080420-20-000020:mdna:4]

[0000080420-20-000027:mdna:5]
[same as prior period, unchanged from 0000080420-20-000020:mdna:5]

[0000080420-20-000027:mdna:6]
Within the industrial sector, specifically oil, gas and petrochemical, the demand for our electrical distribution solutions is very cyclical and highly correlated to the level of capital expenditures of our end user customers as well as prevailing global economic conditions.

[0000080420-20-000027:mdna:7]
Beginning in late Fiscal 2018, the combination of a growing global economy and abundant sources of favorably priced natural gas feedstock drove an increase in capital investment opportunities, specifically across the oil, gas and petrochemical sectors. We have seen opportunities for natural gas related projects targeting global demand for cleaner burning fuels. Additionally, projects within the domestic petrochemical sector have benefited from the low feedstock prices of natural gas. Specific to natural gas, the business was awarded a substantial contract in the second quarter of Fiscal 2020  that will support the integrated electrical distribution requirements for a large domestic industrial complex. This specific project will take over three years to design, manufacture, integrate, test and ship.

[0000080420-20-000027:mdna:8]
Impact of the COVID-19 Pandemic and Oil and Gas Commodity Market Volatility on Powell

[0000080420-20-000027:mdna:9]
The spread of COVID-19 has created significant uncertainty and economic disruption across the world during the second half of Fiscal 2020.  This pandemic has negatively impacted energy demand, which in turn has resulted in considerable volatility across the oil and gas commodity markets. The demand for our products and services as well as our operations have been negatively impacted by COVID-19, reductions in oil and gas demand and volatility in commodity prices noted above.

[0000080420-20-000027:mdna:10]
From an operations standpoint, although our facilities are located in areas that have in the past been subject to stay-at-home orders, we have not closed any of our facilities for an extended period of time and have operated as an "essential business" under local government orders. However, as a result of the uncertainty our customers are experiencing, certain of our customers have asked that we delay our manufacturing on their projects as their operations have been negatively impacted by this pandemic and the reduced oil and gas demand. We have experienced supply disruptions and anticipate that these supply disruptions may continue. We continue to monitor and work with our suppliers who have been impacted by this pandemic to ensure we are able to meet our customer commitments. We also have reviewed and will continue to review contracts with our suppliers, making adjustments accordingly. We continue to take the necessary steps to ensure the safety of our employees, customers and vendors. These steps include, among others, promoting increased social distancing practices and enhanced cleaning efforts in our offices and facilities. We are utilizing and exploring the use of technology across our operations to further enhance social distancing and improve safety. These safety precautions have and may continue to have an adverse impact on our costs, efficiency and productivity going forward.

[0000080420-20-000027:mdna:11]
In response to the lower demand across select end markets, we have and will continue to take various actions to reduce costs. During the third quarter of Fiscal 2020, we reduced our global workforce by approximately 12% resulting in severance costs of $1.4 million. Additionally, we instituted a temporary furlough program for our salaried workforce in North America which is expected to reduce salaried compensation by $1.3 million in the second half of Fiscal 2020. Additionally, we have also reduced our capital and discretionary spending in response to current business conditions.

[0000080420-20-000027:mdna:12]
As discussed further under the heading "Outlook" below, it is difficult to predict the economic impact that this pandemic, as well as reduced oil and gas demand and commodity price volatility may have on our business, results of operations and cash flows going forward.

[0000080420-20-000027:mdna:13]
[same as prior period, unchanged from 0000080420-20-000020:mdna:10]

[0000080420-20-000027:mdna:14]
Quarter Ended June 30, 2020 Compared to the Quarter Ended June 30, 2019 (Unaudited)

[0000080420-20-000027:mdna:15]
[same as prior period, unchanged from 0000080420-20-000020:mdna:12]

[0000080420-20-000027:mdna:16]
Revenues decreased by 13%, or $17.5 million, to $118.1 million in the third quarter of Fiscal 2020, due to a decrease in orders resulting from a decline in demand across our industrial end markets, as well as project delays and cancellations of potential projects associated with the global decline in demand across the oil and gas markets resulting from COVID-19. Domestic revenues decreased by 12%, or $12.4 million, to $91.3 million in the third quarter of Fiscal 2020. International revenues decreased by 16%, or $5.1 million, to $26.8 million in the third quarter of Fiscal 2020 as a result of lower commercial activity across our international operations. Our international revenues include both revenues generated from our international facilities as well as revenues from export projects generated at our domestic facilities.

[0000080420-20-000027:mdna:17]
Revenue from our oil and gas end markets decreased by 26%, or $16.5 million, to $45.9 million in the third quarter of Fiscal 2020 while petrochemical revenue increased by 39%, or $8.2 million, to $29.3 million in the third quarter of Fiscal 2020. The decrease in demand across the oil and gas end markets has negatively impacted our orders rate and revenue. The increase in petrochemical revenues continues to be driven primarily by execution of previously booked orders from the petrochemical end markets and lower natural gas prices. Revenue from utility markets decreased by 37%, or $9.7 million, to $16.7 million and traction market revenue increased by 23%, or $1.7 million, to $9.1 million in the third quarter of Fiscal 2020, as the mix of our projects shifts across our global operating facilities. Revenue from all other markets combined decreased by $1.2 million to $17.1 million in the third quarter of Fiscal 2020.

[0000080420-20-000027:mdna:18]
Gross profit decreased by 10%, or $2.4 million, to $21.3 million, for the third quarter of Fiscal 2020 as a result of lower revenues. Gross profit as a percentage of revenues increased to 18% in the third quarter of Fiscal 2020, compared to 17% in the third quarter of Fiscal 2019 due to stronger margins in backlog as well as cost efficiencies, while absorbing the operational challenges resulting from COVID-19.

[0000080420-20-000027:mdna:19]
[same as prior period, unchanged from 0000080420-20-000020:mdna:17]

[0000080420-20-000027:mdna:20]
Selling, general and administrative expenses decreased by 9%, or $1.6 million, to $15.5 million in the third quarter of Fiscal 2020, primarily due to decreased personnel costs. Additionally, travel related costs have temporarily declined as a result of COVID-19. Selling, general and administrative expenses, as a percentage of revenues, was 13% during the third quarter of Fiscal 2020 and Fiscal 2019, primarily due to our continued focus on our cost structure.

[0000080420-20-000027:mdna:21]
Restructuring and Other, Net

[0000080420-20-000027:mdna:22]
In response to the COVID-19 pandemic, reductions in oil and gas demand and volatility of commodity prices, we implemented workforce reductions across the business. As a result, we recorded $1.4 million of separation costs during the third quarter of Fiscal 2020.

[0000080420-20-000027:mdna:23]
Income Tax Benefit/Provision

[0000080420-20-000027:mdna:24]
We recorded an income tax benefit of $0.6 million in the third quarter of Fiscal 2020, compared to an income tax provision of $0.8 million in the third quarter of Fiscal 2019. The effective tax rate for the third quarter of Fiscal 2020 was negative 19%, compared to an effective tax rate of 14% in the third quarter of Fiscal 2019. For the three months ended June 30, 2020, the effective tax rate was favorably impacted by the tax benefits related to the Research and Development Tax Credit (R&D Tax Credit) and the projected utilization of net operating loss carryforwards in Canada that were fully reserved with a valuation allowance. In addition, as a result of the expiration of certain U.S. federal statutes of limitations and the effective settlement of an Internal Revenue Service (IRS) audit, $1.7 million of reserves for unrecognized tax benefits related to these matters was released. These benefits were partially offset by losses recognized in various foreign jurisdictions that were reserved with a valuation allowance.

[0000080420-20-000027:mdna:25]
For the third quarter of Fiscal 2019, the effective tax rate was favorably impacted by the relative amounts of income recognized in various foreign jurisdictions that were reserved with a valuation allowance.

[0000080420-20-000027:mdna:26]
[same as prior period, unchanged from 0000080420-20-000020:mdna:21]

[0000080420-20-000027:mdna:27]
In the third quarter of Fiscal 2020, net income of $3.5 million, or $0.30 per diluted share, decreased from net income of $5.1 million, or $0.44 per diluted share, in the third quarter of Fiscal 2019, primarily due to a decline in revenues and gross profit resulting from lower orders caused by adverse market conditions as well as $1.4 million of separation costs. This was partially offset by the favorable impact from the reversal of the reserves for unrecognized tax benefits as a discrete item in the third quarter of Fiscal 2020.

[0000080420-20-000027:mdna:28]
[same as prior period, unchanged from 0000080420-20-000020:mdna:23]

[0000080420-20-000027:mdna:29]
The order backlog at June 30, 2020 was $532.2 million, a decrease of 6% from $566.4 million at March 31, 2020 and a 31% increase over the $407.0 million backlog at June 30, 2019. The increase in backlog at June 30, 2020 is due in large part to the substantial contract awarded in the second quarter of Fiscal 2020 that will support the integrated electrical distribution requirements for a large domestic industrial complex. New orders decreased by 44% in the third quarter of Fiscal 2020 to $81.4 million, compared to $144.8 million in the third quarter of Fiscal 2019, primarily due to decreased demand from our customers in our core oil and gas markets.

[0000080420-20-000027:mdna:30]
Nine Months Ended June 30, 2020 Compared to the Nine Months Ended June 30, 2019 (Unaudited)

[0000080420-20-000027:mdna:31]
[same as prior period, unchanged from 0000080420-20-000020:mdna:26]

[0000080420-20-000027:mdna:32]
Revenues increased by 10%, or $35.1 million, to $403.8 million in the nine months ended June 30, 2020. This increase is attributable to the first half of Fiscal 2020 revenues and is the result of the solid backlog at the beginning of Fiscal 2020 driven by the improved market conditions in our petrochemical and oil and gas markets beginning in late Fiscal 2018. Domestic revenues increased by 9%, or $27.4 million, to $318.2 million in the nine months ended June 30, 2020. International revenues increased by 10%, or $7.7 million, to $85.6 million in the nine months ended June 30, 2020, primarily driven by increased activity in our international operations and end markets. Our international revenues include both revenues generated from our international facilities as well as revenues from export projects generated at our domestic facilities.

[0000080420-20-000027:mdna:33]
Revenue from our oil and gas markets decreased by 6%, or $10.2 million, to $157.8 million in the nine months ended June 30, 2020 while petrochemical revenue increased by 69%, or $43.7 million, to $107.1 million in the nine months ended June 30, 2020 driven by the previous strength across the core oil and gas and petrochemical end markets when these projects were awarded in Fiscal 2018 and 2019.  Revenue from utility markets decreased by 3%, or $2.1 million, to $64.0 million and traction market revenue increased by 70%, or $13.0 million, to $31.4 million in the nine months ended June 30, 2020, primarily driven by our mix of projects. Revenue from all other markets combined decreased by $9.3 million to $43.5 million in the nine months ended June 30, 2020.

[0000080420-20-000027:mdna:34]
Gross profit increased by 25%, or $14.4 million, to $72.9 million, for the nine months ended June 30, 2020. Gross profit as a percentage of revenues increased to 18% in the nine months ended June 30, 2020, compared to 16% in the nine months ended June 30, 2019 due to strong margins in backlog as well as cost efficiencies and increased volume in our domestic and international manufacturing facilities.

[0000080420-20-000027:mdna:35]
[same as prior period, unchanged from 0000080420-20-000020:mdna:30]

[0000080420-20-000027:mdna:36]
Selling, general and administrative expenses increased by 2%, or $1.1 million, to $51.4 million in the nine months ended June 30, 2020, primarily due to increased variable incentive compensation associated with increased project volume and profitability. Selling, general and administrative expenses, as a percentage of revenues, decreased to 13% during the nine months ended June 30, 2020, compared to 14% during the nine months ended June 30, 2019, primarily due to the increase in revenues and our continued focus on our cost structure.

[0000080420-20-000027:mdna:37]
Restructuring and Other, Net

[0000080420-20-000027:mdna:38]
In response to the COVID-19 pandemic, reductions in oil and gas demand and volatility of commodity prices, we implemented workforce reductions across the business. As a result, we recorded $1.4 million of separation costs during the third quarter of Fiscal 2020.

[0000080420-20-000027:mdna:39]
[same as prior period, unchanged from 0000080420-20-000020:mdna:19]

[0000080420-20-000027:mdna:40]
We recorded an income tax provision of $2.1 million in the nine months ended June 30, 2020, compared to an income tax provision of $1.0 million in the nine months ended June 30, 2019. The effective tax rate for the nine months ended June 30, 2020 was 13%, compared to an effective tax rate of 22% for the nine months ended June 30, 2019. For the nine months ended June 30, 2020, the effective tax rate was favorably impacted by the current year estimated R&D Tax Credit as well as the projected utilization of net

[0000080420-20-000027:mdna:41]
operating loss carryforwards in Canada that were fully reserved with a valuation allowance. Likewise, the discrete items recorded in the third quarter of Fiscal 2020 in the amount of $1.7 million associated with the release of reserves for unrecognized tax benefits as a result of the expiration of statutes of limitations and the IRS audit settlement favorably impacted the effective tax rate. The effective tax rate was negatively impacted by the discrete item recorded in the second quarter of Fiscal 2020 for the valuation allowance against our UK deferred tax assets in the amount of $0.5 million as well as by the losses recognized in various foreign jurisdictions that were reserved with a valuation allowance. For the nine months ended June 30, 2019, the effective tax rate of 22% approximated the U.S. federal statutory rate as the immaterial losses incurred by various foreign jurisdictions reserved with a valuation allowance had a minimal impact on the effective tax rate. The effective tax rate for the nine months ended June 30, 2019 approximated the U.S. federal statutory rate as the impact from foreign jurisdictions with losses reserved with a valuation allowance were insignificant.

[0000080420-20-000027:mdna:42]
[same as prior period, unchanged from 0000080420-20-000020:mdna:34]

[0000080420-20-000027:mdna:43]
In the nine months ended June 30, 2020, net income of $13.7 million, or $1.17 per diluted share, improved from net income of $3.4 million, or $0.29 per diluted share, in the nine months ended June 30, 2019 primarily from increased revenues and gross profit in the first half of Fiscal 2020 and from the favorable impact from the reversal of the reserves for unrecognized tax benefits as a discrete item which was partially offset by the separation costs in the third quarter of Fiscal 2020.

[0000080420-20-000027:mdna:44]
[same as prior period, unchanged from 0000080420-20-000020:mdna:36]

[0000080420-20-000027:mdna:45]
The order backlog at June 30, 2020 was $532.2 million, a 27% increase from the $419.0 million at September 30, 2019. New orders increased by 1% during the nine months ended June 30, 2020 to $519.5 million, compared to $513.9 million in the nine months ended June 30, 2019. Backlog and orders benefited from a substantial contract awarded in the second quarter of Fiscal 2020 that will support the integrated electrical distribution requirements for a large domestic industrial complex.

[0000080420-20-000027:mdna:46]
[same as prior period, unchanged from 0000080420-20-000020:mdna:38]

[0000080420-20-000027:mdna:47]
[same as prior period, unchanged from 0000080420-20-000020:mdna:39]

[0000080420-20-000027:mdna:48]
A significant portion of our revenues have historically been from the oil, gas and petrochemical markets. Oil and gas commodity price levels have been unstable over the last several years, and our customers delayed some of their major capital investment projects. Beginning in late Fiscal 2018, our customers' decisions to invest in projects in our key oil and gas and petrochemical markets were influenced somewhat by the stabilization of commodity prices and the increased global demand for cleaner burning fuels during that period of time. We believe that change in market sentiment during that period of time had a favorable impact on our orders and backlog entering Fiscal 2020, although we anticipate that recent declines in oil prices will negatively impact our business going forward, as discussed in more detail below. Specific to natural gas, the business was awarded a substantial contract in the second quarter of Fiscal 2020 that will support the integrated electrical distribution requirements for a large domestic industrial complex. This specific project will take over three years to design, manufacture, integrate, test and ship.

[0000080420-20-000027:mdna:49]
Our operating results are impacted by factors such as the timing of new order awards, customer approval of final engineering and design specifications and delays in customer construction schedules, all of which contribute to short-term earnings variability and the timing of project execution. Our operating results also have been, and could continue to be, impacted by the timing and resolution of change orders, project close-out and resolution of potential contract claims and liquidated damages, all of which could improve or deteriorate gross margins during the period in which these items are resolved with our customers. These factors may result in periods of underutilization of our resources and facilities and negatively impact our ability to cover our fixed costs. The increased orders in Fiscal 2018 and 2019 have led to improvement in revenues and operating results for the first half of Fiscal 2020. We continue to monitor the factors that drive our markets and will continue to strive to maintain our leadership and competitive advantage in the markets we serve while aligning our cost structure and workforce with these changing market conditions.

[0000080420-20-000027:mdna:50]
The spread of COVID-19 has created and continues to create significant uncertainty and economic disruption across the world during the second half of Fiscal 2020. This pandemic has negatively impacted energy demand, which in turn has resulted in considerable volatility across the oil and gas commodity markets. Certain of our customers have asked that we delay our manufacturing on their projects as their operations have been negatively impacted by this pandemic, the reduced oil and gas demand and the commodity price volatility.

[0000080420-20-000027:mdna:51]
As a result of these circumstances, we anticipate that a decrease in commercial activity will negatively impact our business, results of operations and cash flows going forward. We have and may need to continue to adjust our workforce and labor costs to correspond to the reduced customer demand. We will take prudent measures to maintain our strong liquidity and cash position, which may include reducing our capital expenditures and research and development costs, as well as reducing or eliminating future dividend payments. However, the extent to which the COVID-19 pandemic specifically will impact our business will depend on numerous factors that are hard to predict, some of which include: the duration, spread and severity of the pandemic; governmental actions in response to the pandemic, including travel restrictions and quarantine or related governmental orders; any closures of our offices and facilities or those of our suppliers as a result of the pandemic, and how quickly and to what extent normal economic and operating conditions can resume. Therefore, the magnitude of the impact on our business, results of operations and cash flows is not currently known.

[0000080420-20-000027:mdna:52]
[same as prior period, unchanged from 0000080420-20-000020:mdna:45]

[0000080420-20-000027:mdna:53]
As of June 30, 2020, current assets exceeded current liabilities by 2.1 times and our debt to total capitalization was 0.26%.

[0000080420-20-000027:mdna:54]
Cash, cash equivalents and short-term investments increased to $163.4 million at June 30, 2020, compared to $124.7 million at September 30, 2019. This increase in cash was primarily driven by the timing of contract billing milestones related to our recent contract award for a large domestic industrial project. We believe that our strong working capital position, available borrowings under our credit facility (U.S. Revolver) and available cash should be sufficient to finance future operating activities, capital improvements, research and development initiatives and debt repayments for the foreseeable future.

[0000080420-20-000027:mdna:55]
Our U.S. Revolver is a $75.0 million revolving credit facility, which is available for both borrowings and letters of credit. As of June 30, 2020, there were no amounts borrowed under this facility, and letters of credit outstanding were $33.1 million. As of June 30, 2020, $41.9 million was available for the issuance of letters of credit and borrowing under the U.S. Revolver. Total long-term debt, including current maturities, totaled $0.8 million at June 30, 2020 related to outstanding industrial development revenue bonds. For further information regarding our debt, see Note E of Notes to Condensed Consolidated Financial Statements.

[0000080420-20-000027:mdna:56]
Approximately $23.7 million of our cash and cash equivalents at June 30, 2020 was held outside of the U.S. for international operations. It is our intention to indefinitely reinvest all current and future foreign earnings internationally in order to ensure sufficient working capital to support our international operations. In the event that we elect to repatriate some or all of the foreign earnings that were previously deemed to be indefinitely reinvested outside the U.S., we may incur additional tax expense upon such repatriation under current tax laws.

[0000080420-20-000027:mdna:57]
[same as prior period, unchanged from 0000080420-20-000020:mdna:50]

[0000080420-20-000027:mdna:58]
Operating activities provided net cash of $53.4 million during the nine months ended June 30, 2020 and $33.9 million during the same period in Fiscal 2019. Cash flow from operations is primarily influenced by project volume, the timing of milestone payments from our customers and the payment terms with our suppliers. This increase in operating cash flow was primarily due to the timing of contract billing milestones related to our recent contract award for a large domestic industrial project.

[0000080420-20-000027:mdna:59]
[same as prior period, unchanged from 0000080420-20-000020:mdna:52]

[0000080420-20-000027:mdna:60]
Investing activities used $5.5 million during the nine months ended June 30, 2020 compared to $4.0 million provided during the same period in Fiscal 2019. The decrease in cash provided by investing activities in the first nine months of Fiscal 2020 was primarily due to short-term investment activity.

[0000080420-20-000027:mdna:61]
[same as prior period, unchanged from 0000080420-20-000020:mdna:54]

[0000080420-20-000027:mdna:62]
Net cash used in financing activities was $10.1 million during the nine months ended June 30, 2020 and $10.5 million during the same period in Fiscal 2019, which primarily consisted of approximately $9.0 million of dividends paid in each period.

[0000080420-20-000027:mdna:63]
[same as prior period, unchanged from 0000080420-20-000020:mdna:56]

[0000080420-20-000027:mdna:64]
[same as prior period, unchanged from 0000080420-20-000020:mdna:57]

[0000080420-20-000027:mdna:65]
[same as prior period, unchanged from 0000080420-20-000020:mdna:58]

[0000080420-20-000027:mdna:66]
[same as prior period, unchanged from 0000080420-20-000020:mdna:59]

[0000080420-20-000027:mdna:67]
[same as prior period, unchanged from 0000080420-20-000020:mdna:60]
