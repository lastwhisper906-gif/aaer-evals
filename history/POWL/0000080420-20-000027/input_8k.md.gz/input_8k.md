# POWL 8-K — 0000080420-20-000024 filed 2020-08-04

## item codes, every 8-K on or before 2020-08-05

- 2020-08-04 0000080420-20-000024 — 2.02, 8.01, 9.01
- 2020-05-05 0000080420-20-000017 — 2.02, 8.01, 9.01
- 2020-02-21 0000080420-20-000008 — 5.07
- 2020-02-04 0000080420-20-000003 — 2.02, 8.01, 9.01
- 2019-12-04 0001193125-19-306243 — 2.02, 9.01
- 2019-11-08 0000080420-19-000032 — 8.01, 9.01
- 2019-10-03 0000080420-19-000030 — 1.01, 2.03
- 2019-09-24 0000080420-19-000028 — 8.01, 9.01
- 2019-08-06 0000080420-19-000022 — 2.02, 8.01, 9.01
- 2019-05-08 0000080420-19-000017 — 5.02, 9.01
- 2019-05-07 0000080420-19-000011 — 2.02, 8.01, 9.01
- 2019-02-22 0001193125-19-048366 — 5.07
- 2019-02-05 0000080420-19-000003 — 2.02, 8.01
- 2018-12-21 0000080420-18-000038 — 5.02, 9.01
- 2018-12-12 0000080420-18-000031 — 2.02
- 2018-11-05 0000080420-18-000029 — 8.01, 9.01
- 2018-11-01 0000080420-18-000027 — 5.02, 8.01, 9.01
- 2018-10-01 0000080420-18-000024 — 5.02
- 2018-08-07 0000080420-18-000020 — 2.02, 8.01
- 2018-05-15 0000080420-18-000016 — 5.02, 8.01
- 2018-05-09 0000080420-18-000011 — 2.02, 8.01
- 2018-02-22 0000080420-18-000009 — 5.07
- 2018-02-06 0000080420-18-000003 — 2.02, 8.01
- 2017-12-27 0001193125-17-379928 — 5.02
- 2017-12-05 0000080420-17-000028 — 2.02, 9.01
- 2017-11-08 0000080420-17-000024 — 8.01, 9.01
- 2017-11-03 0000080420-17-000022 — 5.02
- 2017-08-09 0000080420-17-000017 — 2.02, 8.01
- 2017-06-30 0000080420-17-000014 — 1.01, 9.01
- 2017-05-03 0000080420-17-000006 — 2.02, 8.01, 9.01
- 2017-02-23 0000080420-17-000004 — 5.07
- 2017-02-08 0001628280-17-000965 — 2.02 — amendment of 0001628280-17-000949
- 2017-02-07 0001628280-17-000949 — 2.01, 8.01, 9.01
- 2016-12-07 0001193125-16-787354 — 2.02, 9.01
- 2016-11-01 0001193125-16-755475 — 8.01, 9.01
- 2016-09-30 0001193125-16-726999 — 5.02, 8.01, 9.01
- 2016-08-03 0001193125-16-669308 — 2.02, 8.01, 9.01
- 2016-05-04 0001193125-16-576528 — 2.02, 8.01, 9.01
- 2016-02-25 0001193125-16-477896 — 5.07
- 2016-02-03 0001193125-16-449052 — 2.02, 8.01, 9.01
- 2015-12-31 0001193125-15-418363 — 5.02, 7.01, 9.01
- 2015-12-02 0001193125-15-393109 — 2.02, 9.01
- 2015-11-05 0001193125-15-368085 — 8.01, 9.01
- 2015-09-25 0001193125-15-329031 — 5.02
- 2015-08-05 0001193125-15-277912 — 2.02, 8.01, 9.01
- 2015-05-06 0001193125-15-174291 — 2.02, 8.01, 9.01
- 2015-03-06 0001193125-15-081070 — 5.02
- 2015-03-02 0001193125-15-072946 — 5.07
- 2015-02-03 0001193125-15-031772 — 2.02, 8.01, 9.01
- 2014-12-18 0001193125-14-446513 — 8.01, 9.01
- 2014-12-03 0001193125-14-431745 — 2.02, 9.01
- 2014-11-05 0001193125-14-397955 — 8.01, 9.01
- 2014-09-26 0001193125-14-353741 — 7.01, 9.01
- 2014-08-05 0001193125-14-296001 — 2.02, 8.01, 9.01
- 2014-05-07 0001193125-14-187496 — 2.02, 8.01, 9.01
- 2014-03-03 0001193125-14-079843 — 5.02, 5.07
- 2014-02-05 0001193125-14-036633 — 2.02, 8.01, 9.01
- 2014-01-17 0001193125-14-014351 — 1.01, 8.01, 9.01
- 2014-01-06 0001193125-14-002795 — 1.01, 2.03
- 2013-12-06 0001564590-13-001411 — 2.02, 9.01
- 2013-12-05 0001564590-13-001406 — 5.02, 8.01, 9.01
- 2013-11-07 0001193125-13-432950 — 8.01, 9.01
- 2013-08-07 0001193125-13-324337 — 2.02, 9.01
- 2013-05-08 0001193125-13-206800 — 2.02, 9.01
- 2013-02-22 0001193125-13-070971 — 5.02, 5.07
- 2013-02-06 0001193125-13-040556 — 2.02, 9.01
- 2012-12-18 0001193125-12-506417 — 5.02, 9.01
- 2012-12-05 0001193125-12-491749 — 2.02, 9.01
- 2012-10-12 0001193125-12-421889 — 3.03, 5.02, 5.03, 9.01
- 2012-08-09 0001193125-12-344617 — 5.02, 8.01, 9.01
- 2012-08-08 0001193125-12-343630 — 2.02, 9.01
- 2012-05-09 0001193125-12-221356 — 2.02, 9.01
- 2012-02-08 0001193125-12-046560 — 2.02, 9.01
- 2011-12-08 0001193125-11-334810 — 2.02, 9.01
- 2011-11-08 0000950123-11-096524 — 2.02, 2.06, 4.02, 9.01
- 2011-10-14 0000950123-11-090124 — 5.02
- 2011-10-06 0000950123-11-088969 — 5.02
- 2011-09-19 0000950123-11-085224 — 5.02, 9.01
- 2011-09-15 0000950123-11-084806 — 5.02, 9.01
- 2011-08-04 0000950123-11-072788 — 2.02, 9.01
- 2011-07-22 0000950123-11-067402 — 5.07
- 2011-05-24 0000950123-11-053550 — 1.01, 2.03, 9.01
- 2011-05-04 0000950123-11-044561 — 2.02, 9.01
- 2011-02-02 0000950123-11-008188 — 2.02, 9.01
- 2010-12-08 0000950123-10-111987 — 2.02, 9.01
- 2010-08-05 0000950123-10-073114 — 2.02, 9.01
- 2010-05-18 0000950123-10-050900 — 5.02
- 2010-05-05 0000950123-10-044499 — 2.02, 9.01
- 2010-02-03 0000950123-10-008278 — 2.02, 9.01
- 2009-12-21 0000950123-09-072269 — 1.01, 2.01, 2.03, 8.01, 9.01
- 2009-12-09 0000950123-09-069525 — 2.02, 9.01
- 2009-10-27 0000950123-09-053501 — 1.01, 8.01, 9.01
- 2009-08-04 0000950123-09-029476 — 2.02, 9.01
- 2009-05-06 0000950129-09-001498 — 2.02, 9.01
- 2009-03-05 0000950129-09-000749 — 1.01, 9.01
- 2009-02-10 0000950129-09-000349 — 2.02, 9.01
- 2008-12-10 0000950134-08-021934 — 2.02, 9.01
- 2008-08-06 0000950129-08-004267 — 2.02, 9.01
- 2008-07-24 0000950129-08-004063 — 1.01, 5.02, 8.01, 9.01
- 2008-06-16 0000950129-08-003500 — 9.01 — amendment of 0000950134-06-015374
- 2008-06-05 0000950129-08-003378 — 5.02, 9.01
- 2008-05-08 0000950129-08-002843 — 2.02, 9.01
- 2008-02-06 0000950129-08-000533 — 2.02, 9.01
- 2007-12-19 0000950129-07-006277 — 1.01, 2.03, 9.01
- 2007-12-06 0000950129-07-006003 — 2.02, 9.01
- 2007-08-21 0000950129-07-004181 — 2.02, 9.01
- 2007-05-31 0000950129-07-002810 — 2.02, 9.01
- 2007-05-21 0000950129-07-002668 — 2.02, 3.01, 4.02, 9.01
- 2007-04-16 0000950129-07-002002 — 2.02, 4.02, 9.01
- 2007-03-01 0000950129-07-001104 — 5.02, 8.01, 9.01
- 2007-02-08 0000950129-07-000451 — 2.02, 9.01
- 2006-12-08 0000950129-06-010041 — 2.02, 9.01
- 2006-09-08 0000950129-06-008379 — 2.02, 9.01
- 2006-08-09 0000950134-06-015374 — 1.01, 2.01, 8.01, 9.01
- 2006-06-08 0000950129-06-006127 — 2.02, 9.01
- 2006-03-09 0000950129-06-002455 — 2.02, 9.01
- 2005-12-16 0000950129-05-012031 — 2.02, 5.03, 9.01
- 2005-09-13 0000950129-05-009181 — 2.01, 9.01 — amendment of 0000950129-05-006889
- 2005-09-12 0000950129-05-009151 — 2.02, 9.01
- 2005-07-06 0000950129-05-006889 — 1.01, 1.02, 2.01, 2.03, 9.01
- 2005-06-10 0000950129-05-006128 — 2.02, 9.01
- 2005-04-20 0000080420-05-000031 — 5.02
- 2005-03-11 0000080420-05-000024 — 9.01
- 2005-02-25 0000080420-05-000018 — 7.01, 9.01
- 2005-01-21 0000080420-05-000009 — 7.01, 9.01
- 2004-12-17 0000080420-04-000049 — 2.02, 9.01
- 2004-11-01 0000080420-04-000045 — 8.01, 9.01
- 2004-10-08 0001169232-04-005133 — 2.05
- 2004-09-14 0000080420-04-000037 — 5.02
- 2004-09-02 0000080420-04-000030 — 2.02, 9.01
- 2004-06-08 0000080420-04-000021 — 7
- 2004-05-13 0000080420-04-000019 — 4
- 2004-02-27 0000080420-04-000013 — 7
- 2003-12-16 0000950129-03-006136 — 12, 7
- 2003-08-29 0000950129-03-004531 — 12, 7
- 2003-06-03 0000950129-03-003035 — 7, 9
- 2003-05-15 0000950129-03-002812 — 7, 9
- 2002-05-29 0000950129-02-002795 — 4
- 2000-12-21 0000950129-00-006093 — 5, 7
- 1998-09-04 0000950129-98-003802 — 5
- 1996-08-09 0000950129-96-001705 — 2, 7

## late-filing notifications on or before 2020-08-05

- 2007-05-11 0000950129-07-002494 — NT 10-Q, for the period ended 2007-03-31
- 2005-01-18 0000080420-05-000004 — NT 10-K, for the period ended 2004-10-31

## item 2.02 — earnings release, exhibit 99.1

[0000080420-20-000024:8k_2_02:1]
EX-99.1
2
ex991-q320earningsrelease.htm
EXHIBIT 99.1

[0000080420-20-000024:8k_2_02:2]
Exhibit

[0000080420-20-000024:8k_2_02:3]
Exhibit 99.1

[0000080420-20-000024:8k_2_02:4]
PRESS RELEASE

[0000080420-20-000024:8k_2_02:5]
FOR IMMEDIATE RELEASE

[0000080420-20-000024:8k_2_02:6]
Contacts:    Michael W. Metcalf, CFO

[0000080420-20-000024:8k_2_02:7]
Powell Industries, Inc.

[0000080420-20-000024:8k_2_02:8]
713-947-4422

[0000080420-20-000024:8k_2_02:9]
Ken Dennard / Natalie Hairston

[0000080420-20-000024:8k_2_02:10]
Dennard Lascar Investor Relations

[0000080420-20-000024:8k_2_02:11]
POWL@dennardlascar.com

[0000080420-20-000024:8k_2_02:12]
713-529-6600

[0000080420-20-000024:8k_2_02:13]
POWELL INDUSTRIES ANNOUNCES

[0000080420-20-000024:8k_2_02:14]
FISCAL 2020 THIRD QUARTER RESULTS

[0000080420-20-000024:8k_2_02:15]
HOUSTON  —  AUGUST 4, 2020  — Powell Industries, Inc. (NASDAQ: POWL), a leading supplier of custom engineered solutions for the management, control and distribution of electrical energy, today announced results for the fiscal 2020 third quarter ended June 30, 2020.

[0000080420-20-000024:8k_2_02:16]
Revenues for the third quarter of fiscal 2020 were $118.1 million compared to revenues of $151.6 million for the second quarter of fiscal 2020 and revenues of $135.6 million for the third quarter of fiscal 2019.  Net income for the third quarter of fiscal 2020 was $3.5 million, or $0.30 per diluted share, compared to net income of $7.4 million, or $0.64 per diluted share, for the second quarter of fiscal 2020 and net income of $5.1 million, or $0.44 per diluted share for the third quarter of fiscal 2019.  During the fiscal third quarter, net income was reduced by $1.2 million, or $0.12 per share due to restructuring costs and was offset by $1.7 million, or a $0.14 per share gain resulting from tax benefits recognized.  New orders placed during the third quarter of fiscal 2020 totaled $81 million compared to $145 million in the third quarter of fiscal 2019 and $301 million in the second quarter of fiscal 2020 which included the largest order in Company history.  The Company’s backl

[0000080420-20-000024:8k_2_02:17]
og as of June 30, 2020 was $532 million, a decrease of 6% sequentially from $566 million at March 31, 2020 and compared to $407 million as of June 30, 2019.

[0000080420-20-000024:8k_2_02:18]
Brett A. Cope, Powell’s Chairman and Chief Executive Officer, stated, “As we continue to navigate through the global market uncertainty and challenges associated with the COVID-19 pandemic, our number one priority remains the safety of our employees, customers and suppliers.  I am very proud of all of our employees globally for their continued efforts embracing safe work practices across all of our facilities.”

[0000080420-20-000024:8k_2_02:19]
Mr. Cope continued, “Our third quarter results reflected another quarter of solid operating performance resulting in strong margins and cash flow despite the lower sequential and year-over-year revenues.  Third quarter gross profit as a percentage of revenue was 18.1%, up 60 basis points from 17.5% in the same period of last year as a result of strong project execution and cost management.  Additionally, our focus on both operating costs and working capital throughout fiscal 2020 has enabled the business to further enhance our liquidity position, generating $46 million of operating cash flow during the fiscal third quarter.”

[0000080420-20-000024:8k_2_02:20]
“We have entered an unprecedented cycle across our industrial end markets, with increased uncertainty across the geographies where we operate and compete.  Considering this and in an effort to align operating costs with the current market activity, during the quarter we took the difficult, but necessary decision to reduce our workforce in order to align operating costs with the current market activity.”

[0000080420-20-000024:8k_2_02:21]
Mr. Cope concluded by stating, “Looking forward, our backlog is solid at $532 million, up $125 million from the prior year and our balance sheet is very strong, particularly our current liquidity position coupled with minimal leverage.  We remain focused on the success of our customers, by continuing to deliver high performance electrical distribution products, solutions and service support.”

[0000080420-20-000024:8k_2_02:22]
2

[0000080420-20-000024:8k_2_02:23]
OUTLOOK

[0000080420-20-000024:8k_2_02:24]
Commenting on the company's outlook, Michael Metcalf, Powell’s Chief Financial Officer said, “We continue to show solid operational momentum through the fiscal third quarter of 2020, with both orders and earnings per share at their highest levels through the first nine months of the year dating back to fiscal 2015.  As we close out fiscal 2020, we anticipate a more challenging commercial environment with respect to our broader industrial end markets.  However, given our robust backlog position, as well as our year-to-date earnings and operational cash flow, we are confident that fiscal 2020 will be a strong year financially for the company.”

[0000080420-20-000024:8k_2_02:25]
CONFERENCE CALL

[0000080420-20-000024:8k_2_02:26]
Powell Industries has scheduled a conference call for Wednesday, August 5, 2020 at 11:00 a.m. Eastern time.   To participate in the conference call, dial 412-902-0030 at least 10 minutes before the call begins and ask for the Powell Industries conference call.  A replay of the call will be available approximately two hours after the live broadcast ends and will be accessible until August 12, 2020.  To access the replay, dial 201-612-7415 using a passcode of 13706826#.

[0000080420-20-000024:8k_2_02:27]
Investors, analysts and the general public will also have the opportunity to listen to the conference call over the Internet by visiting powellind.com. To listen to the live call on the web, please visit the website at least 15 minutes before the call begins to register, download and install any necessary audio software.  For those who cannot listen to the live webcast, an archive will be available shortly after the call and will remain available for approximately 90 days at powellind.com.

[0000080420-20-000024:8k_2_02:28]
Powell Industries, Inc., headquartered in Houston, designs, manufactures and services custom-engineered equipment and systems for the distribution, control and monitoring of electrical energy.  Powell markets include large industrial customers such as utilities, oil and gas producers, refineries, petrochemical plants, pulp and paper producers, mining operations and commuter railways.   For more information, please visit powellind.com.

[0000080420-20-000024:8k_2_02:29]
4

[0000080420-20-000024:8k_2_02:30]
POWELL INDUSTRIES, INC. & SUBSIDIARIES

[0000080420-20-000024:8k_2_02:31]
CONDENSED CONSOLIDATED STATEMENT OF OPERATIONS

[0000080420-20-000024:8k_2_02:32]
|  | Three Months EndedJune 30, |  | Nine Months EndedJune 30, |
|  | 2020 |  | 2019 |  | 2020 |  | 2019 |
| (In thousands, except per share data) |  |  |  |  |  |  |  |
|  | (Unaudited) |
| Revenues | $ | 118,062 |  |  | $ | 135,588 |  |  | $ | 403,781 |  |  | $ | 368,676 |  |
| Cost of goods sold | 96,718 |  |  | 111,873 |  |  | 330,926 |  |  | 310,255 |  |
| Gross profit | 21,344 |  |  | 23,715 |  |  | 72,855 |  |  | 58,421 |  |
| Selling, general and administrative expenses | 15,511 |  |  | 17,117 |  |  | 51,372 |  |  | 50,240 |  |
| Research and development expenses | 1,605 |  |  | 1,631 |  |  | 4,863 |  |  | 4,988 |  |
| Amortization of intangible assets | 44 |  |  | 44 |  |  | 132 |  |  | 132 |  |
| Insurance proceeds | — |  |  | (950 | ) |  | — |  |  | (950 | ) |
| Restructuring and other, net | 1,400 |  |  | 233 |  |  | 1,400 |  |  | 233 |  |
| Operating income | 2,784 |  |  | 5,640 |  |  | 15,088 |  |  | 3,778 |  |
| Interest expense | 52 |  |  | 59 |  |  | 179 |  |  | 170 |  |
| Interest income | (190 | ) |  | (305 | ) |  | (901 | ) |  | (707 | ) |
| Income before income taxes | 2,922 |  |  | 5,886 |  |  | 15,810 |  |  | 4,315 |  |
| Income tax provision (benefit) | (559 | ) |  | 797 |  |  | 2,133 |  |  | 963 |  |
| Net income | $ | 3,481 |  |  | $ | 5,089 |  |  | $ | 13,677 |  |  | $ | 3,352 |  |
| Earnings per share: |  |  |  |  |  |  |  |
| Basic | $ | 0.30 |  |  | $ | 0.44 |  |  | $ | 1.18 |  |  | $ | 0.29 |  |
| Diluted | $ | 0.30 |  |  | $ | 0.44 |  |  | $ | 1.17 |  |  | $ | 0.29 |  |
| Weighted average shares: |  |  |  |  |  |  |  |
| Basic | 11,631 |  |  | 11,579 |  |  | 11,622 |  |  | 11,567 |  |
| Diluted | 11,698 |  |  | 11,603 |  |  | 11,686 |  |  | 11,589 |  |
| SELECTED FINANCIAL DATA: |  |  |  |  |  |  |  |
| Depreciation and Amortization | $ | 2,637 |  |  | $ | 2,948 |  |  | $ | 7,878 |  |  | $ | 9,408 |  |
| Capital Expenditures | $ | 809 |  |  | $ | 1,269 |  |  | $ | 4,311 |  |  | $ | 3,241 |  |
| Dividends Paid | $ | 3,019 |  |  | $ | 3,003 |  |  | $ | 9,047 |  |  | $ | 8,991 |  |

[0000080420-20-000024:8k_2_02:33]
5

[0000080420-20-000024:8k_2_02:34]
POWELL INDUSTRIES, INC. & SUBSIDIARIES

[0000080420-20-000024:8k_2_02:35]
CONDENSED CONSOLIDATED BALANCE SHEETS

[0000080420-20-000024:8k_2_02:36]
|  | June 30, 2020 |  | September 30, 2019 |
| (In thousands) | (Unaudited) |
| Assets: |  |  |  |
| Cash, cash equivalents and short-term investments | $ | 163,356 |  |  | $ | 124,681 |  |
| Other current assets | 186,795 |  |  | 203,887 |  |
| Property, plant and equipment, net | 114,826 |  |  | 120,812 |  |
| Long-term assets | 22,221 |  |  | 18,031 |  |
| Total assets | $ | 487,198 |  |  | $ | 467,411 |  |
| Liabilities and equity: |  |  |  |
| Current liabilities | $ | 170,499 |  |  | $ | 157,896 |  |
| Long-term debt, net of current maturities | 400 |  |  | 800 |  |
| Deferred and other long-term liabilities | 12,728 |  |  | 9,562 |  |
| Stockholders’ equity | 303,571 |  |  | 299,153 |  |
| Total liabilities and stockholders’ equity | $ | 487,198 |  |  | $ | 467,411 |  |
| SELECTED FINANCIAL DATA: |  |  |  |
| Working capital | $ | 179,652 |  |  | $ | 170,672 |  |
