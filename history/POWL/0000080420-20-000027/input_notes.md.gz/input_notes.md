# POWL notes — 0000080420-20-000027


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureAndSignificantAccountingPoliciesTextBlock

[0000080420-20-000027:notes:1]
Overview and Summary of Significant Accounting Policies
Overview

[0000080420-20-000027:notes:2]
[same as prior period, unchanged from 0000080420-20-000020:notes:81]

[0000080420-20-000027:notes:3]
[same as prior period, unchanged from 0000080420-20-000020:notes:82]

[0000080420-20-000027:notes:4]
Impact of the COVID-19 Pandemic and Oil and Gas Commodity Market Volatility on Powell

[0000080420-20-000027:notes:5]
The spread of COVID-19 has created significant uncertainty and economic disruption across the world during the second half of Fiscal 2020. This pandemic has negatively impacted energy demand, which in turn has resulted in considerable volatility across the oil and gas commodity markets. As a result, some of our industrial customers are deferring or suspending their planned capital expenditures. Certain of our customers have asked that we delay our manufacturing on their projects as their operations have been negatively impacted by this pandemic and the reduced oil and gas demand. We continue to work with and review the contracts with our key suppliers who have been impacted by this pandemic to ensure that we are able to meet our customer commitments.

[0000080420-20-000027:notes:6]
From an operations standpoint, although our facilities are located in areas that have been or continue to be subject to stay-at-home orders, we have not closed any of our facilities for an extended amount of time and have continued to operate as an "essential business" under these orders across all of our locations. We continue to take the necessary steps to ensure the safety of our employees, customers and vendors. These steps include, among others, promoting increased social distancing practices and enhanced cleaning efforts in our offices and facilities. We are also using technology across our operations to further enhance social distancing and improve safety. These increased safety precautions may have an adverse impact on our efficiency and productivity going forward.

[0000080420-20-000027:notes:7]
As a result of the circumstances noted above, we anticipate that a decrease in commercial activity will negatively impact our business, results of operations and cash flows going forward. We have and may need to continue to adjust our workforce and labor costs to correspond to the reduced customer demand. We will take prudent measures to maintain our strong liquidity and cash position, which may include reducing our capital expenditures and research and development costs, as well as reducing or eliminating future dividend payments. However, the extent to which the COVID-19 pandemic specifically will impact our business will depend on numerous factors that are hard to predict, some of which include: the duration, spread and severity of the pandemic; governmental actions in response to the pandemic, including travel restrictions and quarantine or related governmental orders; any closures of our offices and facilities or those of our suppliers as a result of the pandemic, and how quickly and to what extent normal economic and operating conditions can resume. Therefore, the magnitude of the impact on our business, results of operations and cash flows is not currently known.

[0000080420-20-000027:notes:8]
Basis of Presentation

[0000080420-20-000027:notes:9]
These unaudited condensed consolidated financial statements include the accounts of Powell and its wholly-owned subsidiaries. All significant intercompany accounts and transactions have been eliminated in consolidation.

[0000080420-20-000027:notes:10]
These unaudited condensed consolidated financial statements have been prepared in accordance with the instructions to Form 10-Q and Rule 10-01 of Regulation S-X for interim financial information. Certain information and footnote disclosures, normally included in annual financial statements prepared in accordance with accounting principles generally accepted in the United States (U.S. GAAP), have been condensed or omitted pursuant to those rules and regulations. In the opinion of management, all adjustments, consisting only of normal recurring adjustments, necessary to fairly state the financial position, results of operations and cash flows with respect to the interim condensed consolidated financial statements have been included. The results of operations for the interim periods are not necessarily indicative of the results for the entire fiscal year. We believe that these financial statements contain all adjustments necessary so that they are not misleading.

[0000080420-20-000027:notes:11]
These unaudited condensed consolidated financial statements should be read in conjunction with the audited consolidated financial statements and notes thereto of Powell and its subsidiaries included in Powell’s Annual Report on Form 10-K for the year ended September 30, 2019, which was filed with the Securities and Exchange Commission (SEC) on December 5, 2019.

[0000080420-20-000027:notes:12]
References to Fiscal 2020 and Fiscal 2019 used throughout this report shall mean our fiscal years ended September 30, 2020 and 2019, respectively.

[0000080420-20-000027:notes:13]
[same as prior period, unchanged from 0000080420-20-000020:notes:83]

[0000080420-20-000027:notes:14]
[same as prior period, unchanged from 0000080420-20-000020:notes:84]

[0000080420-20-000027:notes:15]
New Accounting Standards

[0000080420-20-000027:notes:16]
Effective October 1, 2019, we adopted the new lease accounting standard and recorded operating lease assets and operating lease liabilities of approximately $7.0 million and determined that no adjustment to retained earnings was necessary. Financial results for reporting periods after October 1, 2019 are reported under the new standard; however financial results for prior periods were not adjusted and will continue to be presented in accordance with the previous standard. Upon adoption, we elected a package of practical expedients which, among other things, allowed for the historical classification of our existing leases to carryforward. Additionally, we elected to separate non-lease components for our real estate and IT infrastructure asset classes.  All other asset classes account for both lease and non-lease components in the operating lease asset and operating lease liability calculations. See Note I for further discussion of leases.

[0000080420-20-000027:notes:17]
In June 2016, the Financial Accounting Standards Board (FASB) issued a new topic on measurement of credit losses. The topic introduces an impairment model known as the current expected credit loss (CECL) model that is based on an expected loss methodology rather than an incurred loss methodology for financial instruments. Under the new topic, an entity recognizes as an allowance its estimate of expected credit losses with the intention of improving financial reporting by requiring timelier recognition of such losses. Enhanced disclosure of information regarding how a company developed its allowance, including changes in the factors that influenced management's estimate of expected credit losses and the reasons for those changes, will be required upon adoption. The new topic is effective for fiscal years beginning after December 15, 2019, including interim periods within those fiscal years.  This would be our fiscal year ending September 30, 2021. We are still evaluating the impact this new topic will have on our consolidated financial statements.


## us-gaap:EarningsPerShareTextBlock

[0000080420-20-000027:notes:18]
Earnings Per Share
We compute basic earnings per share by dividing net income by the weighted average number of common shares outstanding during the period. Diluted earnings per common and potential common share includes the weighted average of additional shares associated with the incremental effect of dilutive restricted stock and restricted stock units, as prescribed by the FASB guidance on earnings per share.

[0000080420-20-000027:notes:19]
[same as prior period, unchanged from 0000080420-20-000020:notes:32]

[0000080420-20-000027:notes:20]
|  | Three months ended June 30, |  | Nine months ended June 30, |
|  | 2020 |  | 2019 |  | 2020 |  | 2019 |
| Numerator: |  |  |  |  |  |  |  |
| Net income | $ | 3,481 |  |  | $ | 5,089 |  |  | $ | 13,677 |  |  | $ | 3,352 |  |
| Denominator: |  |  |  |  |  |  |  |
| Weighted average basic shares | 11,631 |  |  | 11,579 |  |  | 11,622 |  |  | 11,567 |  |
| Dilutive effect of restricted stock units | 67 |  |  | 24 |  |  | 64 |  |  | 22 |  |
| Weighted average diluted shares | 11,698 |  |  | 11,603 |  |  | 11,686 |  |  | 11,589 |  |
| Income per share: |  |  |  |  |  |  |  |
| Basic | $ | 0.30 |  |  | $ | 0.44 |  |  | $ | 1.18 |  |  | $ | 0.29 |  |
| Diluted | $ | 0.30 |  |  | $ | 0.44 |  |  | $ | 1.17 |  |  | $ | 0.29 |  |


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0000080420-20-000027:notes:21]
Detail of Selected Balance Sheet Accounts
Allowance for Doubtful Accounts

[0000080420-20-000027:notes:22]
Activity in our allowance for doubtful accounts consisted of the following (in thousands):

[0000080420-20-000027:notes:23]
|  | Three months ended June 30, |  | Nine months ended June 30, |
|  | 2020 |  | 2019 |  | 2020 |  | 2019 |
| Balance at beginning of period | $ | 300 |  |  | $ | 214 |  |  | $ | 301 |  |  | $ | 157 |  |
| Bad debt expense | 136 |  |  | 25 |  |  | 187 |  |  | 126 |  |
| Uncollectible accounts written off, net of recoveries | (2 | ) |  | (31 | ) |  | (57 | ) |  | (74 | ) |
| Change due to foreign currency translation | — |  |  | (3 | ) |  | 3 |  |  | (4 | ) |
| Balance at end of period | $ | 434 |  |  | $ | 205 |  |  | $ | 434 |  |  | $ | 205 |  |

[0000080420-20-000027:notes:24]
[same as prior period, unchanged from 0000080420-20-000020:notes:127]

[0000080420-20-000027:notes:25]
The components of inventories are summarized below (in thousands):

[0000080420-20-000027:notes:26]
|  | June 30, 2020 |  | September 30, 2019 |
| Raw materials, parts and sub-assemblies, net | $ | 30,481 |  |  | $ | 28,102 |  |
| Work-in-progress | 1,182 |  |  | 1,100 |  |
| Total inventories | $ | 31,663 |  |  | $ | 29,202 |  |

[0000080420-20-000027:notes:27]
[same as prior period, unchanged from 0000080420-20-000020:notes:128]

[0000080420-20-000027:notes:28]
Activity in our product warranty accrual consisted of the following (in thousands):

[0000080420-20-000027:notes:29]
|  | Three months ended June 30, |  | Nine months ended June 30, |
|  | 2020 |  | 2019 |  | 2020 |  | 2019 |
| Balance at beginning of period | $ | 3,276 |  |  | $ | 2,986 |  |  | $ | 2,946 |  |  | $ | 2,604 |  |
| Increase in warranty expense | 276 |  |  | 945 |  |  | 1,904 |  |  | 2,572 |  |
| Deduction for warranty charges | (555 | ) |  | (754 | ) |  | (1,826 | ) |  | (1,992 | ) |
| Change due to foreign currency translation | 14 |  |  | 3 |  |  | (13 | ) |  | (4 | ) |
| Balance at end of period | $ | 3,011 |  |  | $ | 3,180 |  |  | $ | 3,011 |  |  | $ | 3,180 |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0000080420-20-000027:notes:30]
Revenue
Revenue Recognition

[0000080420-20-000027:notes:31]
The majority of our revenues are generated from the manufacturing of custom-engineered products and systems under long-term fixed-price contracts under which we agree to manufacture various products such as traditional and arc-resistant distribution switchgear and control gear, medium-voltage circuit breakers, monitoring and control communications systems, motor control centers and bus duct systems. These products may be sold separately as an engineered solution, but are typically integrated into custom-built enclosures which we also build.  These enclosures are referred to as power control room substations (PCRs®), custom-engineered modules or electrical houses (E-Houses). Some contracts may also include the installation and the commissioning of these enclosures.

[0000080420-20-000027:notes:32]
Revenue from these contracts is generally recognized over time utilizing the cost-to-cost method to measure the extent of progress toward the completion of the performance obligation and the recognition of revenue over time. We believe that this method is the most accurate representation of our performance, because it directly measures the value of the services transferred to the customer over time as we incur costs on our contracts.  Contract costs include all direct materials, labor, and indirect costs related to contract performance, which may include indirect labor, supplies, tools, repairs and depreciation costs.

[0000080420-20-000027:notes:33]
We also have contracts to provide value-added services such as field service inspection, installation, commissioning, modification and repair, as well as retrofit and retrofill components for existing systems.  As a practical expedient, if the service contract terms give us the right to invoice the customer for an amount that corresponds directly with the value of our performance completed to date (i.e., a service contract in which we bill a fixed amount for each hour of service provided), then we recognize revenue over

[0000080420-20-000027:notes:34]
time in each reporting period corresponding to the amount with which we have the right to invoice.  Our performance obligations are satisfied as the work progresses. Revenues from our custom-engineered products and value-added services transferred to customers over time accounted for approximately 95% of total revenues for the three and nine months ended June 30, 2020 and 93% of total revenues for the three and nine months ended June 30, 2019.

[0000080420-20-000027:notes:35]
We also have sales orders for spare parts and replacement circuit breakers for switchgear that are obsolete or that are no longer produced by the original manufacturer. Revenues from these sales orders are recognized at the time we fulfill our performance obligation to the customer, which is typically upon shipment and represented approximately 5% of total revenues for the three and nine months ended June 30, 2020 and 7% of total revenues for the three and nine months ended June 30, 2019.

[0000080420-20-000027:notes:36]
Additionally, some contracts may contain a cancellation clause that could limit the amount of revenue we are able to recognize over time. In these instances, revenue and costs associated with these contracts are deferred and recognized at a point in time when the performance obligation is fulfilled.

[0000080420-20-000027:notes:37]
[same as prior period, unchanged from 0000080420-20-000020:notes:108]

[0000080420-20-000027:notes:38]
Performance Obligations

[0000080420-20-000027:notes:39]
A performance obligation is a promise in a contract or with a customer to transfer a distinct good or service. A contract’s transaction price is allocated to each distinct performance obligation and recognized as revenue as the performance obligations are satisfied. To determine the proper revenue recognition for contracts, we evaluate whether a contract should be accounted for as more than one performance obligation or, less commonly, whether two or more contracts should be combined and accounted for as one performance obligation.  This evaluation of performance obligations requires significant judgment.  The majority of our contracts have a single performance obligation where multiple engineered products and services are combined into a single custom-engineered solution. Our contracts generally include a standard assurance warranty that typically ends 18 months after shipment. Occasionally, we provide service-type warranties that will extend the warranty period. These extended warranties qualify as a separate performance obligation, and revenue is deferred and recognized over the warranty period. If we determine during the evaluation of the contract that there are multiple performance obligations, we allocate the transaction price to each performance obligation using our best estimate of the standalone selling price of each distinct good or service in the contract.

[0000080420-20-000027:notes:40]
Remaining unsatisfied performance obligations, which we refer to as backlog, represent the estimated transaction price for goods and services for which we have a material right but work has not been performed. As of June 30, 2020, we had backlog of $532.2 million, of which approximately $342.4 million is expected to be recognized as revenue within the next twelve months. Backlog may not be indicative of future operating results as orders may be cancelled or modified by our customers. Our backlog does not include service and maintenance-type contracts for which we have the right to invoice as services are performed.

[0000080420-20-000027:notes:41]
Contract Estimates

[0000080420-20-000027:notes:42]
Actual revenues and project costs may vary from previous estimates due to changes in a variety of factors. The cost estimation process is based upon the professional knowledge and experience of our engineers, project managers and financial professionals. Factors that are considered in estimating the work to be completed and ultimate contract recovery include the availability and productivity of labor, the nature and complexity of the work to be performed, the availability of materials, and the effect of any delays on our project performance. We periodically review our job performance, job conditions, estimated profitability and final contract settlements, including our estimate of total costs and make revisions to costs and income in the period in which the revisions are probable and reasonably estimable. Whenever revisions of estimated contract costs and contract values indicate that the contract costs will exceed estimated revenues, thus creating a loss, a provision for the total estimated loss is recorded in that period.

[0000080420-20-000027:notes:43]
For the nine months ended June 30, 2020 and 2019, our operating results were positively impacted by $10.8 million and $4.3 million, respectively, as a result of changes in contract estimates related to projects in progress at the beginning of the respective period. These changes in estimates spread across the entire portfolio with no significant changes in a single contract and resulted primarily from favorable project execution and negotiations of variable consideration, discussed below, as well as other changes in facts and circumstances during these periods.

[0000080420-20-000027:notes:44]
Variable Consideration

[0000080420-20-000027:notes:45]
It is common for our long-term contracts to contain variable consideration that can either increase or decrease the transaction price. Due to the nature of our contracts, estimating total cost and revenue can be complex and subject to variability due to change orders, back charges, spare parts, early completion bonuses, customer allowances and liquidated damages. We estimate the amount of variable consideration based on the expected value method, which is the sum of probability-weighted amount, or the most likely amount method which uses various factors including experience with similar transactions and assessment of our anticipated performance. Variable consideration is included in the transaction price if legally enforceable and to the extent it is probable that a significant reversal of cumulative revenue recognized will not occur once the uncertainty associated with the variable consideration is resolved.

[0000080420-20-000027:notes:46]
Contract Modifications

[0000080420-20-000027:notes:47]
Contracts may be modified for changes in contract specifications and requirements. We consider contract modifications to exist when the modification either creates new or changes the enforceable rights and obligations under the contract. Most of our contract modifications are for goods and services that are not distinct from the existing performance obligation. Contract modifications result in a cumulative catch-up adjustment to revenue based on our measure of progress for the performance obligation.

[0000080420-20-000027:notes:48]
Contract Balances

[0000080420-20-000027:notes:49]
The timing of revenue recognition, billings and cash collections affects accounts receivable, costs and estimated earnings in excess of billings on uncompleted contracts (contract assets) and billings in excess of costs and estimated earnings on uncompleted contracts (contract liabilities) in our Condensed Consolidated Balance Sheet.

[0000080420-20-000027:notes:50]
Contract assets are recorded when revenues are recognized in excess of amounts billed for fixed-price contracts as determined by the billing milestone schedule. Contract assets are transferred to accounts receivable when billing milestones have been met, or we have an unconditional right to payment.

[0000080420-20-000027:notes:51]
Contract liabilities typically represent advance payments from contractual billing milestones and billings in excess of revenue recognized. It is unusual to have advanced milestone payments with a term greater than one year, which could represent a financing component on the contract.

[0000080420-20-000027:notes:52]
Our contract assets and liabilities are reported in a net position on a contract-by-contract basis at the end of each reporting period and are generally classified as current.

[0000080420-20-000027:notes:53]
Contract assets and liabilities as of June 30, 2020 and September 30, 2019 are summarized below (in thousands):

[0000080420-20-000027:notes:54]
|  | June 30, 2020 |  | September 30, 2019 |
| Contract assets | $ | 51,723 |  |  | $ | 55,374 |  |
| Contract liabilities | (97,969 | ) |  | (71,464 | ) |
| Net contract liability | $ | (46,246 | ) |  | $ | (16,090 | ) |

[0000080420-20-000027:notes:55]
The increase in net contract liability at June 30, 2020 from September 30, 2019 was primarily due to our progress towards completion on our projects and the timing of contract billing milestones and new orders. This increase was primarily driven by the timing of contract billing milestones related to our recent contract award for a large industrial project in the United States. To determine the amount of revenue recognized during the period from contract liabilities, we first allocate revenue to the individual contract liability balance outstanding at the beginning of the period until the revenue exceeds that balance. During the three and nine months ended June 30, 2020, we recognized revenue of approximately $34.6 million and $67.1 million related to contract liabilities outstanding at September 30, 2019.

[0000080420-20-000027:notes:56]
The timing of our invoice process is typically dependent on the completion of certain milestones and contract terms and subject to agreement by our customer.  Payment is typically expected within 30 days of invoice. Any uncollected invoiced amounts for our performance obligations recognized over time, including contract retentions, are recorded as accounts receivable in the Condensed Consolidated Balance Sheets. Certain contracts contain retention provisions that become due upon completion of contractual requirements. As of June 30, 2020 and September 30, 2019, accounts receivable included retention amounts of $6.7 million and $5.6 million, respectively. Of the retained amount at June 30, 2020, $5.6 million is expected to be collected in the next twelve months and is recorded in accounts receivable. The remaining $1.1 million is recorded in other assets.

[0000080420-20-000027:notes:57]
[same as prior period, unchanged from 0000080420-20-000020:notes:113]

[0000080420-20-000027:notes:58]
The following tables present our disaggregated revenue by geographic destination and market sector for the three and nine months ended June 30, 2020 and 2019 (in thousands):

[0000080420-20-000027:notes:59]
|  | Three months ended June 30, |  | Nine months ended June 30, |
|  | 2020 |  | 2019 |  | 2020 |  | 2019 |
| United States | $ | 89,499 |  |  | $ | 99,745 |  |  | $ | 318,009 |  |  | $ | 292,049 |  |
| Canada | 16,970 |  |  | 20,206 |  |  | 46,831 |  |  | 45,015 |  |
| Europe, Middle East and Africa | 6,422 |  |  | 9,659 |  |  | 25,404 |  |  | 20,608 |  |
| Asia/Pacific | 4,643 |  |  | 4,682 |  |  | 11,784 |  |  | 9,155 |  |
| Mexico, Central and South America | 528 |  |  | 1,296 |  |  | 1,753 |  |  | 1,849 |  |
| Total revenues by geographic destination | $ | 118,062 |  |  | $ | 135,588 |  |  | $ | 403,781 |  |  | $ | 368,676 |  |

[0000080420-20-000027:notes:60]
|  | Three months ended June 30, |  | Nine months ended June 30, |
|  | 2020 |  | 2019 |  | 2020 |  | 2019 |
| Oil and gas | $ | 45,851 |  |  | $ | 62,356 |  |  | $ | 157,798 |  |  | $ | 167,954 |  |
| Petrochemical | 29,293 |  |  | 21,086 |  |  | 107,057 |  |  | 63,387 |  |
| Electric utility | 16,725 |  |  | 26,425 |  |  | 63,994 |  |  | 66,066 |  |
| Traction power | 9,122 |  |  | 7,423 |  |  | 31,417 |  |  | 18,457 |  |
| All others | 17,071 |  |  | 18,298 |  |  | 43,515 |  |  | 52,812 |  |
| Total revenues by market sector | $ | 118,062 |  |  | $ | 135,588 |  |  | $ | 403,781 |  |  | $ | 368,676 |  |


## us-gaap:RevenueFromContractWithCustomerPolicyTextBlock

[0000080420-20-000027:notes:61]
Contract liabilities typically represent advance payments from contractual billing milestones and billings in excess of revenue recognized. It is unusual to have advanced milestone payments with a term greater than one year, which could represent a financing component on the contract.  
Our contract assets and liabilities are reported in a net position on a contract-by-contract basis at the end of each reporting period and are generally classified as current.
Performance Obligations

[0000080420-20-000027:notes:62]
A performance obligation is a promise in a contract or with a customer to transfer a distinct good or service. A contract’s transaction price is allocated to each distinct performance obligation and recognized as revenue as the performance obligations are satisfied. To determine the proper revenue recognition for contracts, we evaluate whether a contract should be accounted for as more than one performance obligation or, less commonly, whether two or more contracts should be combined and accounted for as one performance obligation.  This evaluation of performance obligations requires significant judgment.  The majority of our contracts have a single performance obligation where multiple engineered products and services are combined into a single custom-engineered solution. Our contracts generally include a standard assurance warranty that typically ends 18 months after shipment. Occasionally, we provide service-type warranties that will extend the warranty period. These extended warranties qualify as a separate performance obligation, and revenue is deferred and recognized over the warranty period. If we determine during the evaluation of the contract that there are multiple performance obligations, we allocate the transaction price to each performance obligation using our best estimate of the standalone selling price of each distinct good or service in the contract. 
Remaining unsatisfied performance obligations, which we refer to as backlog, represent the estimated transaction price for goods and services for which we have a material right but work has not been performed.The timing of our invoice process is typically dependent on the completion of certain milestones and contract terms and subject to agreement by our customer.  Payment is typically expected within 30 days of invoice. Any uncollected invoiced amounts for our performance obligations recognized over time, including contract retentions, are recorded as accounts receivable in the Condensed Consolidated Balance Sheets. Certain contracts contain retention provisions that become due upon completion of contractual requirements.
Revenue Recognition

[0000080420-20-000027:notes:63]
Additionally, some contracts may contain a cancellation clause that could limit the amount of revenue we are able to recognize over time. In these instances, revenue and costs associated with these contracts are deferred and recognized at a point in time when the performance obligation is fulfilled.
Selling and administrative costs incurred in relation to obtaining a contract are typically expensed as incurred. We periodically utilize a third-party sales agent to obtain a contract and will pay a commission to that agent. We record the full commission liability to the third-party sales agents at the order date, with a corresponding deferred asset. As the project progresses, we record commission expense based on percentage of completion rates that correlate to the project and reduce the deferred asset. Once we have been paid by the customer, we pay the commission and the deferred liability is reduced
Contract Estimates


## us-gaap:LongTermDebtTextBlock

[0000080420-20-000027:notes:64]
Long-Term Debt
Long-term debt consisted of the following (in thousands):

[0000080420-20-000027:notes:65]
|  | June 30, 2020 |  | September 30, 2019 |
| Industrial development revenue bonds | $ | 800 |  |  | $ | 1,200 |  |
| Less: current portion | (400 | ) |  | (400 | ) |
| Total long-term debt | $ | 400 |  |  | $ | 800 |  |

[0000080420-20-000027:notes:66]
U.S. Revolver

[0000080420-20-000027:notes:67]
On September 27, 2019, we entered into an Amended and Restated Credit Agreement with Bank of America, N.A. (the " "U.S. Revolver"), which replaced our prior credit agreement. The U.S. Revolver is a $75.0 million revolving credit facility that is available for both borrowings and letters of credit and expires September 2024. As of June 30, 2020, there were no amounts borrowed under this facility and letters of credit outstanding were $33.1 million. There was $41.9 million available for the issuance of letters of credit and borrowings under the U.S. Revolver as of June 30, 2020.

[0000080420-20-000027:notes:68]
We are required to maintain certain financial covenants, the most significant of which are a consolidated leverage ratio less than 3.0 to 1.0 and a consolidated interest coverage ratio of greater than 3.0 to 1.0. Additionally, we must maintain a consolidated cash balance of $30 million at all times. The U.S. Revolver also contains a "material adverse effect" clause which is a material change in our operations, business, properties, liabilities or condition (financial or otherwise) or a material impairment of our ability to perform our obligations under our credit agreements. As of June 30, 2020, we were in compliance with all of the financial covenants of the U.S. Revolver.

[0000080420-20-000027:notes:69]
The U.S. Revolver allows the Company to elect that any borrowing under the facility bear an interest rate based on either the base rate or the eurocurrency rate, in each case, plus the applicable rate. The base rate is generally the highest of (a) the federal funds rate plus 0.50%, (b) the Bank of America prime rate or (c) the London Interbank Offered Rate ("LIBOR") plus 1.00%. The applicable rate is generally a range from (0.25)% to 1.75% depending on the type of loan and the Company's consolidated leverage ratio.

[0000080420-20-000027:notes:70]
The U.S. Revolver is collateralized by a pledge of 100% of the voting capital stock of each of our domestic subsidiaries and 65% of the voting capital stock of each non-domestic subsidiary. The U.S. Revolver provides for customary events of default and carries cross-default provisions with other existing debt agreements. If an event of default (as defined in the U.S. Revolver) occurs and is continuing, on the terms and subject to the conditions set forth in the U.S. Revolver, amounts and letters of credit outstanding under the U.S. Revolver may be accelerated and may become immediately due and payable.

[0000080420-20-000027:notes:71]
Industrial Development Revenue Bonds

[0000080420-20-000027:notes:72]
We borrowed $8.0 million in October 2001 through a loan agreement funded with proceeds from tax-exempt industrial development revenue bonds (Bonds). These Bonds were issued by the Illinois Development Finance Authority and were used for the completion of our Northlake, Illinois facility. Pursuant to the Bond issuance, a reimbursement agreement between us and a major domestic bank required an issuance by the bank of an irrevocable direct-pay letter of credit (Bond LC), as collateral, to the Bonds’ trustee to guarantee payment of the Bonds’ principal and interest when due. The Bond LC is subject to both early termination and extension provisions customary to such agreements, as well as various covenants, for which we were in compliance at June 30, 2020. While the Bonds mature in 2021, the reimbursement agreement requires annual redemptions of $0.4 million that commenced on October 25, 2002. A sinking fund is used for the annual principal payment. The Bonds bear interest at a floating rate determined weekly by the Bonds’ remarketing agent, which was the underwriter for the Bonds and is an affiliate of the bank. This interest rate was 0.36% as of June 30, 2020.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0000080420-20-000027:notes:73]
Commitments and Contingencies
Letters of Credit, Surety Bonds and Bank Guarantees

[0000080420-20-000027:notes:74]
Certain customers require us to post letters of credit, bank guarantees or surety bonds. These security instruments assure that we will perform under the terms of our contract. In the event of default, the counterparty may demand payment from the bank under a letter of credit or bank guarantee, or performance by the surety under a bond. To date, there have been no significant draws or claims related to security instruments for the periods reported. We were contingently liable for letters of credit of $33.1 million as of June 30, 2020. We also had surety bonds totaling $162.0 million that were outstanding, with additional bonding capacity of $588.0 million available, at June 30, 2020.

[0000080420-20-000027:notes:75]
We have an $8.6 million facility agreement (Facility Agreement) between Powell (UK) Limited and a large international bank that provides Powell (UK) Limited the ability to enter into bank guarantees as well as forward exchange contracts and currency options. At June 30, 2020, we had outstanding guarantees totaling $7.9 million and amounts available under this Facility Agreement were $0.7 million. The Facility Agreement provides for financial covenants and customary events of default, and carries cross-default provisions with our U.S. Revolver. If an event of default (as defined in the Facility Agreement) occurs and is continuing, per the terms and subject to the conditions set forth therein, obligations outstanding under the Facility Agreement may be accelerated and declared immediately due and payable. As of June 30, 2020, we were in compliance with all of the financial covenants of the Facility Agreement.

[0000080420-20-000027:notes:76]
Litigation

[0000080420-20-000027:notes:77]
We are involved in various legal proceedings, claims and other disputes arising from our commercial operations, projects, employees and other matters which, in general, are subject to uncertainties and in which the outcomes are not predictable. Although we can give no assurances about the resolution of pending claims, litigation or other disputes and the effect such outcomes may have on us, management believes that any ultimate liability resulting from the outcome of such proceedings, to the extent not otherwise provided or covered by insurance, will not have a material adverse effect on our consolidated financial position or results of operations or liquidity.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0000080420-20-000027:notes:78]
Stock-Based Compensation
Refer to our Annual Report on Form 10-K for the fiscal year ended September 30, 2019 for a full description of our existing stock-based compensation plans.

[0000080420-20-000027:notes:79]
[same as prior period, unchanged from 0000080420-20-000020:notes:23]

[0000080420-20-000027:notes:80]
We issue restricted stock units (RSUs) to certain officers and key employees of the Company. The fair value of the RSUs is based on the price of our common stock as reported on the NASDAQ Global Market on the grant dates. The typical annual grant vests over a three-year period from the date of issuance and is a blend of time-based and performance-based shares. The portion of the grant that is time-based typically vests over a three-year period on each anniversary of the grant date, based on continued employment. The performance-based shares vest based on the three-year earnings performance of the Company following the grant date. At June 30, 2020, there were 154,034 RSUs outstanding. The RSUs do not have voting rights but do receive dividend equivalents upon vesting. Additionally, the shares of common stock underlying the RSUs are not considered issued and outstanding until vested and common stock is issued.

[0000080420-20-000027:notes:81]
Total RSU activity (number of shares) for the nine months ended June 30, 2020 is summarized below:

[0000080420-20-000027:notes:82]
|  | Number ofRestrictedStockUnits |  | WeightedAverageFair ValuePer Share |
| Outstanding at September 30, 2019 | 131,850 |  |  | $ | 33.76 |  |
| Granted | 70,500 |  |  | 38.53 |  |
| Vested | (47,566 | ) |  | 35.63 |  |
| Forfeited/canceled | (750 | ) |  | 33.16 |  |
| Outstanding at June 30, 2020 | 154,034 |  |  | 35.37 |  |

[0000080420-20-000027:notes:83]
During the nine months ended June 30, 2020 and 2019, we recorded compensation expense of $1.9 million and $1.8 million, respectively, related to the RSUs.

[0000080420-20-000027:notes:84]
Restricted Stock
Each non-employee director receives 2,400 restricted shares of the Company’s common stock annually. Fifty-percent of the restricted stock granted to each of our non-employee directors vests immediately, while the remaining fifty-percent vests on the anniversary of the grant date. Compensation expense is recognized immediately for the first fifty-percent of the restricted stock granted, while compensation expense for the remaining fifty-percent is recognized over the remaining vesting period. In February 2020, 16,800 shares of restricted stock were issued to our non-employee directors under the 2014 Director Plan at a price of $36.25 per share. During the nine months ended June 30, 2020 and 2019, we recorded compensation expense of $0.5 million and $0.4 million, respectively, related to restricted stock.


## us-gaap:FairValueDisclosuresTextBlock

[0000080420-20-000027:notes:85]
Fair Value Measurements
We measure certain financial assets and liabilities at fair value. Fair value is defined as an “exit price” which represents the amount that would be received to sell an asset or paid to transfer a liability in an orderly transaction between market participants as of the measurement date. As such, fair value is a market-based measurement that should be determined based on assumptions that market participants would use in valuing an asset or liability. The accounting guidance requires the use of valuation techniques to measure fair value that maximize the use of observable inputs and minimize the use of unobservable inputs. As a basis for considering such assumptions and inputs, a fair value hierarchy has been established which identifies and prioritizes three levels of inputs to be used in measuring fair value.

[0000080420-20-000027:notes:86]
[same as prior period, unchanged from 0000080420-20-000020:notes:37]

[0000080420-20-000027:notes:87]
[same as prior period, unchanged from 0000080420-20-000020:notes:38]

[0000080420-20-000027:notes:88]
[same as prior period, unchanged from 0000080420-20-000020:notes:39]

[0000080420-20-000027:notes:89]
[same as prior period, unchanged from 0000080420-20-000020:notes:40]

[0000080420-20-000027:notes:90]
The following table summarizes the fair value of our assets and liabilities that were accounted for at fair value on a recurring basis as of June 30, 2020 (in thousands):

[0000080420-20-000027:notes:91]
|  | Fair Value Measurements at June 30, 2020 |
|  | Quoted Prices inActive Markets forIdentical Assets(Level 1) |  | Significant OtherObservableInputs(Level 2) |  | SignificantUnobservableInputs(Level 3) |  | Fair Value at June 30, 2020 |
| Assets: |  |  |  |  |  |  |  |
| Cash and cash equivalents | $ | 156,026 |  |  | $ | — |  |  | $ | — |  |  | $ | 156,026 |  |
| Short-term investments | 7,330 |  |  | — |  |  | — |  |  | 7,330 |  |
| Other assets | — |  |  | 6,997 |  |  | — |  |  | 6,997 |  |
| Liabilities: |  |  |  |  |  |  |  |
| Deferred compensation | — |  |  | 6,370 |  |  | — |  |  | 6,370 |  |

[0000080420-20-000027:notes:92]
[same as prior period, unchanged from 0000080420-20-000020:notes:43]

[0000080420-20-000027:notes:93]
[same as prior period, unchanged from 0000080420-20-000020:notes:44]

[0000080420-20-000027:notes:94]
[same as prior period, unchanged from 0000080420-20-000020:notes:45]

[0000080420-20-000027:notes:95]
[same as prior period, unchanged from 0000080420-20-000020:notes:46]

[0000080420-20-000027:notes:96]
[same as prior period, unchanged from 0000080420-20-000020:notes:47]

[0000080420-20-000027:notes:97]
[same as prior period, unchanged from 0000080420-20-000020:notes:48]

[0000080420-20-000027:notes:98]
There were no transfers between levels within the fair value measurement hierarchy during the quarter ended June 30, 2020.


## us-gaap:LesseeOperatingLeasesTextBlock

[0000080420-20-000027:notes:99]
[same as prior period, unchanged from 0000080420-20-000020:notes:63]

[0000080420-20-000027:notes:100]
Our leases consist primarily of office and manufacturing space, construction equipment and office equipment. All of our future lease obligations are related to non-cancelable operating leases. The most significant portion of our lease portfolio relates to leases of office and manufacturing facilities in Canada which we no longer occupy. We currently sublease the majority of these Canadian facilities. The following table provides a summary of lease cost components for the three and nine months ended June 30, 2020 (in thousands):

[0000080420-20-000027:notes:101]
| Lease Cost |  | Three months ended June 30, 2020 |  | Nine months ended June 30, 2020 |
| Operating lease cost |  | $ | 571 |  |  | $ | 1,779 |  |
| Less: sublease income |  | (156 | ) |  | (393 | ) |
| Variable lease cost(1) |  | 86 |  |  | 265 |  |
| Short-term lease cost(2) |  | 148 |  |  | 496 |  |
| Total lease cost |  | $ | 649 |  |  | $ | 2,147 |  |

[0000080420-20-000027:notes:102]
(1) Variable lease cost represents common area maintenance charges related to our Canadian office space leases.

[0000080420-20-000027:notes:103]
(2) Short-term lease cost includes leases and rentals with initial terms of one year or less.

[0000080420-20-000027:notes:104]
We recognize operating lease assets and operating lease liabilities representing the present value of the remaining lease payments for leases with initial terms greater than twelve months. Leases with initial terms of twelve months or less are not recorded in our Condensed Consolidated Balance Sheets. Our operating lease assets have been reduced by a lease accrual of $0.6 million related to certain unused facility leases in Canada. The following table provides a summary of the operating lease assets and operating lease liabilities included in our Condensed Consolidated Balance Sheets as of June 30, 2020 (in thousands):

[0000080420-20-000027:notes:105]
| Operating Leases |  | June 30, 2020 |
| Assets: |  |  |
| Operating lease assets, net |  | $ | 5,542 |  |
| Liabilities: |  |  |
| Current operating lease liabilities |  | 2,306 |  |
| Long-term operating lease liabilities |  | 3,870 |  |
| Total lease liabilities |  | $ | 6,176 |  |

[0000080420-20-000027:notes:106]
The following table provides the maturities of our operating lease liabilities as of June 30, 2020 (in thousands):

[0000080420-20-000027:notes:107]
|  |  | Operating Leases |
| Remainder of 2020 |  | $ | 773 |  |
| 2021 |  | 2,414 |  |
| 2022 |  | 2,140 |  |
| 2023 |  | 1,109 |  |
| 2024 |  | 85 |  |
| Thereafter |  | — |  |
| Total future minimum lease payments |  | 6,521 |  |
| Less: present value discount (imputed interest) |  | (345 | ) |
| Present value of lease liabilities |  | $ | 6,176 |  |

[0000080420-20-000027:notes:108]
The weighted average discount rate as of June 30, 2020 was 4.22%. The weighted average remaining lease term was 2.7 years at June 30, 2020.


## us-gaap:IncomeTaxDisclosureTextBlock

[0000080420-20-000027:notes:109]
Income Taxes
The calculation of the effective tax rate is as follows (in thousands):

[0000080420-20-000027:notes:110]
|  | Three months ended June 30, |  | Nine months ended June 30, |
|  | 2020 |  | 2019 |  | 2020 |  | 2019 |
| Income before income taxes | $ | 2,922 |  |  | $ | 5,886 |  |  | $ | 15,810 |  |  | $ | 4,315 |  |
| Income tax provision (benefit) | (559 | ) |  | 797 |  |  | 2,133 |  |  | 963 |  |
| Net income | $ | 3,481 |  |  | $ | 5,089 |  |  | $ | 13,677 |  |  | $ | 3,352 |  |
| Effective tax rate | (19 | )% |  | 14 | % |  | 13 | % |  | 22 | % |

[0000080420-20-000027:notes:111]
Our income tax (benefit) provision reflects an effective tax rate on pre-tax income of negative 19% for the third quarter of Fiscal 2020 compared to 14% in the third quarter of Fiscal 2019. The effective tax rate for the quarter ended June 30, 2020 was favorably impacted by the tax benefits related to the Research and Development Tax Credit (R&D Tax Credit) and the projected utilization of net operating loss carryforwards in Canada that were fully reserved with a valuation allowance. In addition, as a result of the expiration of certain U.S. federal statutes of limitations and the effective settlement of an Internal Revenue Service (IRS) audit, $1.7 million of reserves for unrecognized tax benefits related to these matters was released. These benefits were partially offset by losses recognized in various foreign jurisdictions that were reserved with a valuation allowance. For the third quarter of Fiscal 2019, the effective tax rate was favorably impacted by the relative amounts of income recognized in various foreign jurisdictions that were reserved with a valuation allowance.

[0000080420-20-000027:notes:112]
The effective tax rate of 13% for the nine months ended June 30, 2020 was favorably impacted by the current year estimated R&D Tax Credit as well as the projected utilization of net operating loss carryforwards in Canada that were fully reserved with a valuation allowance. Likewise, the discrete items recorded in the third quarter of Fiscal 2020 in the amount of $1.7 million associated with the release of reserves for unrecognized tax benefits as a result of the expiration of statutes of limitations and the IRS audit settlement favorably impacted the effective tax rate. The effective tax rate was negatively impacted by the discrete item recorded in the second quarter of Fiscal 2020 for the valuation allowance against our UK deferred tax assets in the amount of $0.5 million as well as by the losses recognized in various foreign jurisdictions that were reserved with a valuation allowance. For the nine months ended June 30, 2019, the effective tax rate of 22% approximated the U.S. federal statutory rate as the immaterial losses incurred by various foreign jurisdictions reserved with a valuation allowance had a minimal impact on the effective tax rate. There were no material discrete items recognized in the first nine months of Fiscal 2019.

[0000080420-20-000027:notes:113]
[same as prior period, unchanged from 0000080420-20-000020:notes:55]

[0000080420-20-000027:notes:114]
Due to the expiration of certain federal statutes of limitations and the settlement of the IRS audit discussed above, management believes that, within the next twelve months, it is reasonably possible that the unrecognized tax benefits will remain materially unchanged. We are unable to make reasonably reliable estimates regarding the timing of future cash outflows, if any, associated with the remaining unrecognized tax benefits for the open periods of Fiscal 2018 - 2020.


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0000080420-20-000027:notes:115]
Separation Costs

[0000080420-20-000027:notes:116]
In response to the COVID-19 pandemic, reductions in oil and gas demand and volatility of commodity prices, we implemented workforce reductions at most of our locations. As a result, we recorded $1.4 million of separation costs in restructuring and other, net on the Condensed Consolidated Statement of Operations during the third quarter of Fiscal 2020.


## us-gaap:SubsequentEventsTextBlock

[0000080420-20-000027:notes:117]
Subsequent Events
Quarterly Dividend Declared

[0000080420-20-000027:notes:118]
On August 4, 2020, our Board of Directors declared a quarterly cash dividend on our common stock in the amount of $0.26 per share. The dividend is payable on September 16, 2020 to shareholders of record at the close of business on August 19, 2020.
