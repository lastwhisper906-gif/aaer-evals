# POWL MD&A — 0000080420-26-000070


## mdna

[0000080420-26-000070:mdna:1]
[same as prior period, unchanged from 0000080420-26-000015:mdna:1]

[0000080420-26-000070:mdna:2]
[same as prior period, unchanged from 0000080420-26-000015:mdna:2]

[0000080420-26-000070:mdna:3]
[same as prior period, unchanged from 0000080420-26-000015:mdna:3]

[0000080420-26-000070:mdna:4]
[same as prior period, unchanged from 0000080420-26-000015:mdna:4]

[0000080420-26-000070:mdna:5]
In the second quarter of Fiscal 2026, we reported revenue of $296.6 million, net income of $45.9 million, and generated $51.2 million in cash from operating activities. As of March 31, 2026, we had total assets of $1.2 billion.

[0000080420-26-000070:mdna:6]
On April 2, 2026, we effected a three-for-one forward split of our common stock and proportionately increased the number of authorized common stock from 30,000,000 to 90,000,000 (the Stock Split). Each shareholder of record as of the close of trading on March 20, 2026 (the Record Date) received, after the close of trading on April 2, 2026, two additional shares for every one share held on the Record Date. Trading began on a split-adjusted basis at market open on April 6, 2026.

[0000080420-26-000070:mdna:7]
[same as prior period, unchanged from 0000080420-26-000015:mdna:6]

[0000080420-26-000070:mdna:8]
Our backlog increased to $1.8 billion as of March 31, 2026, with approximately $1.1 billion expected to be recognized as revenue within the next twelve months. During the first half of Fiscal 2026, commercial activity remained favorable across most of our end markets, with particularly strong demand in the commercial and other industrial, electric utility, and oil and gas (excluding petrochemical) markets.

[0000080420-26-000070:mdna:9]
The diversification of our business over the past several years, including expansion into secular growth markets such as electric utility and data centers, has reduced the cyclicality of our business. This diversification allows us to see beyond the current cycle and invest alongside our customers with greater visibility. Customer relationships in these markets are increasingly strategic and consultative, with opportunities ranging from discrete project engagements to broader, infrastructure planning arrangements.

[0000080420-26-000070:mdna:10]
During the first half of Fiscal 2026, we secured four mega orders, including two data center projects, one Liquefied Natural Gas (LNG) project, and one project in the electric utility market, reflecting continued customer investment and strong activity across these end markets. Subsequent to the second fiscal quarter, we secured an additional mega order in the data center market with a value in excess of $400 million. We remain encouraged by the outlook for both the data center and electric utility end markets and the durability of the current investment cycles. Notwithstanding this momentum, we continue to monitor macroeconomic conditions and geopolitical developments that could affect customer spending behavior or the timing of project awards. While current demand indicators remain positive, these external factors could influence future levels of market activity.

[0000080420-26-000070:mdna:11]
Oil and gas and petrochemical markets. The North American oil and gas end markets continue to exhibit strong commercial activity levels in response to rising global demand for LNG and gas-to‑chemical processes that leverage low‑cost natural gas feedstocks. We believe the fundamentals of the U.S. natural gas market, through abundant supply and competitive cost, continue to support investments in LNG facilities and related gas processing infrastructure. These dynamics contributed to sustained order activity, including a mega LNG project award during the first fiscal quarter. Commercial activity in the petrochemical market has remained subdued over the past several quarters. However, we are cautiously optimistic that the petrochemical market may be entering the early stages of a cyclical inflection following an extended period of reduced investment activity. Beyond traditional crude oil refining and other oil and gas downstream operations, we have broadened our end markets into hydrogen production, carbon capture as well as alternative fuels, such as biofuels and sustainable aviation fuel, aligned with growing demand for cleaner energy solutions.

[0000080420-26-000070:mdna:12]
Electric utility market. Aligned with our strategy of end-market diversification, we continue to focus on growth in electrical distribution substations while also addressing a resurgence of power generation investment in this market. During the second quarter of Fiscal 2026, we secured a mega order of approximately $75 million, reflecting continued customer investment in grid modernization and generation capacity.

[0000080420-26-000070:mdna:13]
Commercial and other industrial markets. As a result of a mix of factors, we are experiencing strong growth in commercial facilities that provide for the production of various consumer goods and the expansion of data centers that support cloud computing and increasing investments in artificial intelligence. During the first half of Fiscal 2026, we were awarded projects

[0000080420-26-000070:mdna:14]
related to data center infrastructure with a combined value exceeding $300 million, including two mega projects, each with an order value greater than $75 million. Subsequent to the second fiscal quarter, we secured an additional mega order in the data center market with a value in excess of $400 million. Commercial activity in this market sector reflects the continued investment in data center infrastructure, and we are also observing increased activity across other industrial end markets.

[0000080420-26-000070:mdna:15]
[same as prior period, unchanged from 0000080420-26-000015:mdna:11]

[0000080420-26-000070:mdna:16]
[same as prior period, unchanged from 0000080420-26-000015:mdna:12]

[0000080420-26-000070:mdna:17]
[same as prior period, unchanged from 0000080420-26-000015:mdna:13]

[0000080420-26-000070:mdna:18]
[same as prior period, unchanged from 0000080420-26-000015:mdna:14]

[0000080420-26-000070:mdna:19]
During the first half of Fiscal 2026, we continued experiencing high volatility in commodity prices, and ongoing supply chain delays for specific engineered components remained a persistent challenge for us. Moreover, ongoing and recently proposed changes to U.S. global trade policy (including legal changes thereto), along with potential international retaliatory measures, and concerns over inflation, recession and slowing growth have continued to cause high volatility in global markets and uncertainty around short- and long-term economic impacts in the United States and other markets we serve. We continue to evaluate and monitor the potential impacts of these changes and measures, including the imposition of tariffs, on our business and operations. We could potentially face the challenge of increased costs of raw materials and engineered components as well as negative impacts on our margins; however, it is not possible to predict the impact, if any, of any changes or proposed changes to the U.S. global trade policy, or any international retaliatory measures, on our business and operations. In response to the rising cost environment and persistent supply chain challenges, we are taking strategic measures to effectively manage our product pricing, refine delivery schedules, and manage bid validity dates with our customers. Our supplier engagement includes improving forecasting and negotiating favorable terms that allow us to meet or exceed customer timelines. Additionally, we remain focused on enhancing factory efficiencies and improving project execution to mitigate risks and maintain customer satisfaction.

[0000080420-26-000070:mdna:20]
[same as prior period, unchanged from 0000080420-26-000015:mdna:16]

[0000080420-26-000070:mdna:21]
Quarter Ended March 31, 2026 Compared to the Quarter Ended March 31, 2025 (Unaudited)

[0000080420-26-000070:mdna:22]
[same as prior period, unchanged from 0000080420-26-000015:mdna:18]

[0000080420-26-000070:mdna:23]
Revenue increased by 6%, or $18.0 million, to $296.6 million in the second quarter of Fiscal 2026. Domestic revenue increased by 2%, or $4.4 million, to $232.3 million in the second quarter of Fiscal 2026. International revenue increased by 27%, or $13.5 million, to $64.3 million in the second quarter of Fiscal 2026, primarily driven by increased activities in the Middle East and Africa, Europe, as well as the Asia/Pacific regions. International revenue includes both revenue generated at our international facilities and export project revenue produced at our domestic facilities.

[0000080420-26-000070:mdna:24]
In the second quarter of Fiscal 2026, revenue growth was led by strength in our commercial and other industrial, electric utility, and oil and gas (excluding petrochemical) markets. Revenue from the commercial and other industrial market increased 35%, or $14.1 million, to $54.4 million; while revenue from the electric utility market grew by 14%, or $10.1 million, to $80.5 million. Revenue from the oil and gas market (excluding petrochemical) increased 11%, or $11.6 million, to $112.7 million. These

[0000080420-26-000070:mdna:25]
increases were primarily driven by our strategic initiative to expand into higher-growth electric utility and commercial and other industrial markets, supported by strong backlog and robust booking activity in these end markets. Partially offsetting these increases, revenue from the petrochemical market declined by 37%, or $16.2 million, to $27.6 million, and revenue from the light rail traction power market decreased 10%, or $1.0 million, to $9.0 million. These declines were primarily attributable to lower booking activity, particularly within the petrochemical market. Revenue from all other markets combined decreased 5%, or $0.7 million, to $12.3 million in the second quarter of Fiscal 2026.

[0000080420-26-000070:mdna:26]
Gross profit increased 5%, or $4.5 million, to $87.9 million for the second quarter of Fiscal 2026. Gross profit as a percentage of revenue remained flat at 30% compared to the second quarter of Fiscal 2025. The increase in gross profit was primarily attributable to higher revenue.

[0000080420-26-000070:mdna:27]
[same as prior period, unchanged from 0000080420-26-000015:mdna:22]

[0000080420-26-000070:mdna:28]
Selling, general and administrative expenses increased 19%, or $4.1 million, to $25.8 million in the second quarter of Fiscal 2026, primarily due to higher compensation expenses. As a percentage of revenue, selling, general and administrative expenses increased to 9% during the second quarter of Fiscal 2026, compared to 8% in the second quarter of Fiscal 2025.

[0000080420-26-000070:mdna:29]
[same as prior period, unchanged from 0000080420-26-000015:mdna:24]

[0000080420-26-000070:mdna:30]
We recorded an income tax provision of $15.9 million in the second quarter of Fiscal 2026, compared to an income tax provision of $16.1 million in the second quarter of Fiscal 2025 resulting in an effective tax rate of 26% for the second quarters of Fiscal 2026 and Fiscal 2025. For each of the three months ended March 31, 2026 and 2025, the effective tax rates were favorably impacted by the estimated Research and Development (R&D) Tax Credit, which was offset by the tax expense related to certain nondeductible items. For additional information regarding our income taxes, see Note L. Income Taxes of Notes to Condensed Consolidated Financial Statements.

[0000080420-26-000070:mdna:31]
[same as prior period, unchanged from 0000080420-26-000015:mdna:26]

[0000080420-26-000070:mdna:32]
In the second quarter of Fiscal 2026, we recorded net income of $45.9 million, or $1.25 per diluted share, compared to net income of $46.3 million, or $1.27 per diluted share (as adjusted for the Stock Split), in the second quarter of Fiscal 2025. The decrease in net income was primarily driven by higher selling, general and administrative expenses and increased research and development expenses, partially offset by higher gross profit in the second quarter of Fiscal 2026.

[0000080420-26-000070:mdna:33]
[same as prior period, unchanged from 0000080420-26-000015:mdna:28]

[0000080420-26-000070:mdna:34]
The order backlog, which represents our remaining unsatisfied performance obligations, reflects the estimated transaction price for goods and services for which we have a material right but for which work has not yet been performed. Order backlog at March 31, 2026 totaled $1.8 billion, representing a 12% increase from $1.6 billion at December 31, 2025. This increase was mainly driven by growth in the commercial and other industrial and electric utility markets. As of March 31, 2026, the electric utility market represented 30% of total backlog, while the oil and gas market (excluding petrochemical) and the commercial and other industrial market each accounted for 29%.

[0000080420-26-000070:mdna:35]
Bookings, net of cancellations and scope reductions, increased 97% in the second quarter of Fiscal 2026 to $489.7 million, compared to $249.0 million in the second quarter of Fiscal 2025. This increase was primarily driven by stronger booking activity across most of our end markets, particularly within the commercial and other industrial and electric utility markets.

[0000080420-26-000070:mdna:36]
Six Months Ended March 31, 2026 Compared to the Six Months Ended March 31, 2025 (Unaudited)

[0000080420-26-000070:mdna:37]
Revenue and Gross Profit

[0000080420-26-000070:mdna:38]
Revenue increased 5%, or $27.7 million, to $547.8 million in the six months ended March 31, 2026. Domestic revenue increased modestly by 0.4%, or $1.5 million, to $427.2 million, while international revenue increased 27.7%, or $26.2 million, to $120.6 million. The increase in international revenue was primarily driven by increased activity in the Middle East and Africa region, as well as the Asia/Pacific and Europe regions. International revenue includes both revenue generated at our international facilities and export project revenue produced at our domestic facilities.

[0000080420-26-000070:mdna:39]
Revenue growth during the six months ended March 31, 2026 was led by strength in the electric utility, commercial and other industrial, and oil and gas (excluding petrochemical) markets. Revenue from the electric utility market increased 23%, or $28.2 million, to $149.8 million, while revenue from the commercial and other industrial market increased 12%, or $10.4 million, to $95.1 million. Revenue from the oil and gas market (excluding petrochemical) increased 7%, or $13.8 million, to $210.6 million. These increases were primarily driven by our strategic initiative to expand our business into the electric utility and

[0000080420-26-000070:mdna:40]
commercial and other industrial markets, as well as improved market activities in these end markets. Partially offsetting these increases, revenue from the petrochemical market decreased 35%, or $26.6 million, to $50.3 million, and revenue from the light rail traction power market decreased 3%, or $0.6 million, to $17.7 million in the first half of Fiscal 2026. These declines were primarily attributable to a reduction in backlog within the petrochemical market following the completion of a large petrochemical order secured in Fiscal 2023, as well as lower booking activity in these markets. Revenue from all other markets combined increased 11%, or $2.5 million, to $24.4 million in the six months ended March 31, 2026.

[0000080420-26-000070:mdna:41]
Gross profit increased 11%, or $16.4 million, to $159.4 million for the six months ended March 31, 2026. Gross profit as a percentage of revenue increased to 29% in the first half of Fiscal 2026, as compared to 27% in the six months ended March 31, 2025. The increase in gross profit was primarily driven by higher revenues, as well as improved gross profit margin resulting from favorable volume leverage and strong project execution in a stable pricing environment.

[0000080420-26-000070:mdna:42]
Selling, General and Administrative Expenses

[0000080420-26-000070:mdna:43]
Selling, general and administrative expenses increased 18%, or $7.8 million, to $51.0 million in the six months ended March 31, 2026, primarily due to higher compensation expenses and increased infrastructure expenses. As a percentage of revenue, selling, general and administrative expenses increased to 9% during the first half of Fiscal 2026, compared to 8% during the first half of Fiscal 2025.

[0000080420-26-000070:mdna:44]
Income Tax Provision

[0000080420-26-000070:mdna:45]
We recorded an income tax provision of $21.5 million in the six months ended March 31, 2026, compared to an income tax provision of $20.8 million in the six months ended March 31, 2025 resulting in an effective tax rate of 20% for the first half of Fiscal 2026 and Fiscal 2025. For each of the six months ended March 31, 2026 and 2025, the effective tax rates were favorably impacted by discrete items related to the vesting of RSUs and the estimated R&D Tax Credit. The lower effective tax rates relative to statutory rates were primarily driven by higher stock prices associated with the vested RSUs. For additional information regarding our income taxes, see Note L. Income Taxes of Notes to Condensed Consolidated Financial Statements.

[0000080420-26-000070:mdna:46]
Net Income

[0000080420-26-000070:mdna:47]
In the six months ended March 31, 2026, we recorded net income of $87.3 million, or $2.39 per diluted share, compared to net income of $81.1 million, or $2.22 per diluted share (as adjusted for the Stock Split), in the six months ended March 31, 2025. The increase in net income was primarily driven by higher gross profit during the first half of Fiscal 2026.

[0000080420-26-000070:mdna:48]
Backlog

[0000080420-26-000070:mdna:49]
Order backlog, which represents our remaining unsatisfied performance obligations, reflects the estimated transaction price for goods and services for which we have a material right but for which work has not yet been performed. Order backlog at March 31, 2026 totaled $1.8 billion, representing a 28% increase from $1.4 billion at September 30, 2025. This increase was mainly driven by growth in the commercial and other industrial, electric utility and oil and gas (excluding petrochemical) markets. As of March 31, 2026, the electric utility market represented 30% of total backlog, while the oil and gas market (excluding petrochemical) and the commercial and other industrial market each accounted for 29%.

[0000080420-26-000070:mdna:50]
Bookings, net of cancellations and scope reductions, increased 79% to $928.5 million during the six months ended March 31, 2026, compared to $517.6 million during the six months ended March 31, 2025. This increase was primarily driven by stronger booking activity in the commercial and other industrial and electric utility markets as well as continued growth in the oil and gas market (excluding petrochemical).

[0000080420-26-000070:mdna:51]
[same as prior period, unchanged from 0000080420-26-000015:mdna:31]

[0000080420-26-000070:mdna:52]
As of March 31, 2026, current assets exceeded current liabilities by 2.3 times.

[0000080420-26-000070:mdna:53]
Cash, cash equivalents and short-term investments increased to $544.9 million at March 31, 2026, compared to $475.5 million at September 30, 2025. The increase was primarily driven by our strong earnings performance, partially offset by cash payments related to shares withheld in lieu of employee tax withholding and dividend payments. We invest our cash, cash equivalents and short-term investments in accordance with the Company’s investment policy approved by the Board of Directors. We believe that our cash, cash equivalents and short-term investments, together with available borrowings under our U.S. credit facility, will be sufficient to support our ongoing operating activities, dividend payments and future organic and inorganic business growth, as well as research and development initiatives for the next twelve months and beyond.

[0000080420-26-000070:mdna:54]
As we evaluate our capital allocation framework relative to our strategic objectives, we intend to continue deploying capital toward both organic and inorganic initiatives while maintaining a disciplined approach to other capital allocation strategies aimed at enhancing shareholder value. We regularly reassess our capital allocation priorities, which currently include funding working capital requirements, research and development, capital expenditures, and other organic growth opportunities, while also returning capital to shareholders and selectively pursuing strategic inorganic growth opportunities. Our capital allocation decisions are influenced by a number of factors, including market conditions, our financial position and capital requirements, competing uses of cash, and other relevant considerations.

[0000080420-26-000070:mdna:55]
Approximately $124.1 million of our cash, cash equivalents and short-term investments at March 31, 2026 was held outside of the U.S. to support our international operations. We intend to indefinitely reinvest all current and future foreign earnings internationally to ensure adequate liquidity and working capital for our international business. In the event that we elect to repatriate some or all of the foreign earnings that were previously deemed to be indefinitely reinvested outside the U.S., we may incur additional tax expense upon such repatriation under current tax laws.

[0000080420-26-000070:mdna:56]
[same as prior period, unchanged from 0000080420-26-000015:mdna:37]

[0000080420-26-000070:mdna:57]
[same as prior period, unchanged from 0000080420-26-000015:mdna:38]

[0000080420-26-000070:mdna:58]
As of March 31, 2026, there were no amounts borrowed under the U.S. Revolver, and letters of credit outstanding were $78.7 million. There was $71.3 million available for the issuance of letters of credit and borrowings under the U.S. Revolver as of March 31, 2026. For further information regarding our debt, see Notes F. Long-Term Debt and G. Commitments and Contingencies of Notes to Condensed Consolidated Financial Statements.

[0000080420-26-000070:mdna:59]
[same as prior period, unchanged from 0000080420-26-000015:mdna:40]

[0000080420-26-000070:mdna:60]
[same as prior period, unchanged from 0000080420-26-000015:mdna:41]

[0000080420-26-000070:mdna:61]
Operating activities provided net cash of $94.8 million during the six months ended March 31, 2026 and provided net cash of $59.5 million during the same period in Fiscal 2025. Cash flow from operations is primarily influenced by project volume and margins, working capital requirements, the timing of milestone payments from customers, and payment terms with suppliers. The increase in operating cash flow was primarily driven by improved earnings and higher milestone payments associated with strong booking activity.

[0000080420-26-000070:mdna:62]
[same as prior period, unchanged from 0000080420-26-000015:mdna:43]

[0000080420-26-000070:mdna:63]
Investing activities provided $14.0 million of cash during the six months ended March 31, 2026 and provided $4.6 million of cash during the same period in Fiscal 2025. Cash provided by investing activities in the first six months of Fiscal 2026 was primarily due to maturities of short-term investments, partially offset by capital spending. We continue to progress the expansion of our Jacintoport fabrication yard in Houston, which is planned to be completed by the end of Fiscal 2026.

[0000080420-26-000070:mdna:64]
[same as prior period, unchanged from 0000080420-26-000015:mdna:45]

[0000080420-26-000070:mdna:65]
Net cash used in financing activities was $21.0 million during the six months ended March 31, 2026 compared to $18.4 million used during the same period in Fiscal 2025. The increase in cash used in financing activities was primarily due to cash payments related to shares withheld in lieu of employee tax withholding, largely driven by the increase of our share price in the first half of Fiscal 2026 compared to the same period of Fiscal 2025.

[0000080420-26-000070:mdna:66]
[same as prior period, unchanged from 0000080420-26-000015:mdna:47]

[0000080420-26-000070:mdna:67]
The discussion and analysis of our financial condition and results of operations are based on our condensed consolidated financial statements, which have been prepared in accordance with U.S. GAAP. The preparation of our condensed consolidated financial statements requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities, disclosures of contingent assets and liabilities known to exist at the date of the condensed consolidated financial statements and the reported amounts of revenues and expenses during the reporting period. We evaluate our estimates on an ongoing basis, based on historical experience and on various other assumptions that are believed to be reasonable under the circumstances. There can be no assurance that actual results will be consistent with those estimates. There have been no material changes to our critical accounting policies as disclosed in our Annual Report on Form 10-K for the fiscal year ended September 30, 2025, which was filed with the SEC on November 19, 2025.
