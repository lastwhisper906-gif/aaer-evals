# POWL note change history — 0000080420-26-000015 → 0000080420-26-000070


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2026-05-05):
[0000080420-26-000070:note_history:1]
Certain customers require us to post letters of credit, bank guarantees or surety bonds. These security instruments assure that we will perform under the terms of our contract. In the event of default, the counterparty may demand payment from the bank under a letter of credit or bank guarantee, or performance by the surety under a bond. To date, there have been no significant draws or claims related to security instruments for the periods reported. We were contingently liable for letters of credit of $78.7 million as of March 31, 2026. We also had surety bonds totaling $432.8 million that were outstanding, with additional bonding capacity of $767.2 million available, at March 31, 2026. We have strong surety relationships; however, a change in market conditions or the sureties’ assessment of our financial position could cause the sureties to require cash collateralization for undischarged liabilities under the bonds.
  (was, 2026-02-04, similarity 0.9857):
[0000080420-26-000015:note_history:1]
Certain customers require us to post letters of credit, bank guarantees or surety bonds. These security instruments assure that we will perform under the terms of our contract. In the event of default, the counterparty may demand payment from the bank under a letter of credit or bank guarantee, or performance by the surety under a bond. To date, there have been no significant draws or claims related to security instruments for the periods reported. We were contingently liable for letters of credit of $65.1 million as of December 31, 2025. We also had surety bonds totaling $433.8 million that were outstanding, with additional bonding capacity of $766.2 million available, at December 31, 2025. We have strong surety relationships; however, a change in market conditions or the sureties’ assessment of our financial position could cause the sureties to require cash collateralization for undischarged liabilities under the bonds.

- changed (2026-05-05):
[0000080420-26-000070:note_history:2]
We have a $19.8 million facility agreement (Facility Agreement) between Powell (UK) Limited and a large international bank that provides Powell (UK) Limited the ability to enter into bank guarantees as well as forward exchange contracts and currency options. At March 31, 2026, we had outstanding guarantees totaling $6.4 million, with an additional capacity of $13.4 million available under this Facility Agreement. The Facility Agreement provides for customary events of default and carries cross-default provisions with the U.S. Revolver. If an event of default (as defined in the Facility Agreement) occurs and is continuing, per the terms and subject to the conditions set forth therein, obligations outstanding under the Facility Agreement may be accelerated and declared immediately due and payable. Additionally, we are required to maintain cash collateral for guarantees greater than two years. As of March 31, 2026, we were in compliance with all of the financial covenants of the Facility Agreement.
  (was, 2026-02-04, similarity 0.9869):
[0000080420-26-000015:note_history:2]
We have a $20.2 million facility agreement (Facility Agreement) between Powell (UK) Limited and a large international bank that provides Powell (UK) Limited the ability to enter into bank guarantees as well as forward exchange contracts and currency options. At December 31, 2025, we had outstanding guarantees totaling $7.6 million, with an additional capacity of $12.6 million available under this Facility Agreement. The Facility Agreement provides for customary events of default and carries cross-default provisions with the U.S. Revolver. If an event of default (as defined in the Facility Agreement) occurs and is continuing, per the terms and subject to the conditions set forth therein, obligations outstanding under the Facility Agreement may be accelerated and declared immediately due and payable. Additionally, we are required to maintain cash collateral for guarantees greater than two years. As of December 31, 2025, we were in compliance with all of the financial covenants of the Facility Agreement.

- changed (2026-05-05):
[0000080420-26-000070:note_history:3]
Certain of our customer contracts have schedule and performance obligation clauses that, if we fail to meet them, could require us to pay liquidated damages. Each individual contract defines the conditions under which the customer may make a claim against us. As of March 31, 2026, certain contracts had a probable exposure to liquidated damages claims of $4.4 million, which could possibly increase to $7.5 million under certain circumstances. Based on our actual or projected failure to meet these various contractual commitments, $3.8 million has been recorded as a reduction to revenue. We will attempt to obtain change orders, contract extensions or accelerate project completion, which may resolve the potential for any unrecorded liquidated damages claims. Should we fail to achieve relief on some or all of these contractual obligations, we could be required to pay additional liquidated damages, which could negatively impact our future operating results.
  (was, 2026-02-04, similarity 0.9932):
[0000080420-26-000015:note_history:3]
Certain of our customer contracts have schedule and performance obligation clauses that, if we fail to meet them, could require us to pay liquidated damages. Each individual contract defines the conditions under which the customer may make a claim against us. As of December 31, 2025, certain contracts had a probable exposure to liquidated damages claims of $4.0 million, which could possibly increase to $4.5 million under certain circumstances. Based on our actual or projected failure to meet these various contractual commitments, $3.1 million has been recorded as a reduction to revenue. We will attempt to obtain change orders, contract extensions or accelerate project completion, which may resolve the potential for any unrecorded liquidated damages claims. Should we fail to achieve relief on some or all of these contractual obligations, we could be required to pay additional liquidated damages, which could negatively impact our future operating results.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureAndSignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- added (2026-05-05):
[0000080420-26-000070:note_history:4]
Common Stock Split

- added (2026-05-05):
[0000080420-26-000070:note_history:5]
On March 31, 2026, the Company’s Board of Directors adopted an amendment to the Company’s Amended and Restated Certificate of Incorporation to proportionately increase the number of shares of the Company’s authorized common stock from 30,000,000 to 90,000,000 in connection with a forward stock split.

- added (2026-05-05):
[0000080420-26-000070:note_history:6]
On April 2, 2026, the Company effected a three-for-one forward split of its common stock and proportionately increased the number of shares of authorized common stock from 30,000,000 to 90,000,000 (the Stock Split). Each shareholder of record as of the close of trading on March 20, 2026 (the Record Date) received, after the close of trading on April 2, 2026, two additional shares for every one share held on the Record Date. The shares of common stock retain a par value of $0.01 per share. Trading began on a split-adjusted basis at market open on April 6, 2026.

- added (2026-05-05):
[0000080420-26-000070:note_history:7]
Share and per share amounts included in the accompanying consolidated financial statements and applicable disclosures  throughout this Quarterly Report on Form 10-Q have been retroactively adjusted to reflect the Stock Split.

- removed (2026-05-05):
[0000080420-26-000015:note_history:8]
Recently Adopted Accounting Standards Update

- removed (2026-05-05):
[0000080420-26-000015:note_history:9]
The Company adopted the Financial Accounting Standard Board (FASB) Accounting Standards Update (ASU) 2023‑07, Segment Reporting (Topic 280): Improvements to Reportable Segment Disclosures, effective October 1, 2024, on a retrospective basis. This standard requires expanded annual and interim segment disclosures, including significant segment expenses regularly reviewed by the chief operating decision maker (CODM), along with disclosure of the CODM’s title and how segment information is used in evaluating performance and allocating resources. It also clarifies that entities with a single reportable segment must provide all required Topic 280 disclosures. Adoption of the standard did not have a material impact on the unaudited condensed consolidated financial statements. Additional details are included in Note K. Segment Information.


## us-gaap:LongTermDebtTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2026-05-05):
[0000080420-26-000070:note_history:10]
As of March 31, 2026, there were no amounts borrowed under the U.S. Revolver, and letters of credit outstanding were $78.7 million. There was $71.3 million available for the issuance of letters of credit and borrowings under the U.S. Revolver as of March 31, 2026.
  (was, 2026-02-04, similarity 0.9317):
[0000080420-26-000015:note_history:10]
As of December 31, 2025, there were no amounts borrowed under the U.S. Revolver, and letters of credit outstanding were $65.1 million. There was $84.9 million available for the issuance of letters of credit and borrowings under the U.S. Revolver as of December 31, 2025.

- changed (2026-05-05):
[0000080420-26-000070:note_history:11]
As of March 31, 2026, we were in compliance with all of the financial covenants of the U.S. Revolver.
  (was, 2026-02-04, similarity 0.9534):
[0000080420-26-000015:note_history:11]
As of December 31, 2025, we were in compliance with all of the financial covenants of the U.S. Revolver.


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2026-05-05):
[0000080420-26-000070:note_history:12]
The following tables present our disaggregated revenue by geographic destination and market sector for the three and six months ended March 31, 2026 and 2025 (in thousands):
  (was, 2026-02-04, similarity 0.9477):
[0000080420-26-000015:note_history:12]
The following tables present our disaggregated revenue by geographic destination and market sector for the three months ended December 31, 2025 and 2024 (in thousands):

- changed (2026-05-05):
[0000080420-26-000070:note_history:13]
|  | Three months ended March 31, |  | Six months ended March 31, |
|  | 2026 |  | 2025 |  | 2026 |  | 2025 |
| United States | $ | 232,272 |  |  | $ | 227,834 |  |  | $ | 427,150 |  |  | $ | 425,606 |  |
| Canada | 29,823 |  |  | 33,970 |  |  | 62,282 |  |  | 65,664 |  |
| Middle East and Africa | 13,618 |  |  | 8,282 |  |  | 23,490 |  |  | 12,840 |  |
| Europe | 10,478 |  |  | 5,897 |  |  | 18,704 |  |  | 11,425 |  |
| Asia/Pacific | 9,840 |  |  | 1,646 |  |  | 15,143 |  |  | 3,226 |  |
| Mexico, Central and South America | 584 |  |  | 1,002 |  |  | 1,030 |  |  | 1,301 |  |
| Total revenues by geographic destination | $ | 296,615 |  |  | $ | 278,631 |  |  | $ | 547,799 |  |  | $ | 520,062 |  |
  (was, 2026-02-04, similarity 0.7136):
[0000080420-26-000015:note_history:13]
|  | Three months ended December 31, |  |  |
|  | 2025 |  | 2024 |  |  |  |  |
| United States | $ | 194,878 |  |  | $ | 197,772 |  |  |  |  |  |
| Canada | 32,459 |  |  | 31,694 |  |  |  |  |  |
| Middle East and Africa | 9,872 |  |  | 4,558 |  |  |  |  |  |
| Europe | 8,226 |  |  | 5,528 |  |  |  |  |  |
| Asia/Pacific | 5,303 |  |  | 1,580 |  |  |  |  |  |
| Mexico, Central and South America | 446 |  |  | 299 |  |  |  |  |  |
| Total revenues by geographic destination | $ | 251,184 |  |  | $ | 241,431 |  |  |  |  |  |

- added (2026-05-05):
[0000080420-26-000070:note_history:14]
|  | Three months ended March 31, |  | Six months ended March 31, |
|  | 2026 |  | 2025 |  | 2026 |  | 2025 |
| Oil and gas (excludes petrochemical) | $ | 112,744 |  |  | $ | 101,167 |  |  | $ | 210,633 |  |  | $ | 196,846 |  |
| Electric utility | 80,479 |  |  | 70,339 |  |  | 149,752 |  |  | 121,579 |  |
| Commercial and other industrial | 54,446 |  |  | 40,369 |  |  | 95,071 |  |  | 84,669 |  |
| Petrochemical | 27,551 |  |  | 43,704 |  |  | 50,329 |  |  | 76,887 |  |
| Light rail traction power | 9,048 |  |  | 10,008 |  |  | 17,662 |  |  | 18,236 |  |
| All others | 12,347 |  |  | 13,044 |  |  | 24,352 |  |  | 21,845 |  |
| Total revenues by market sector | $ | 296,615 |  |  | $ | 278,631 |  |  | $ | 547,799 |  |  | $ | 520,062 |  |

- removed (2026-05-05):
[0000080420-26-000015:note_history:15]
|  | Three months ended December 31, |  |  |
|  | 2025 |  | 2024 |  |  |  |  |
| Oil and gas (excludes petrochemical) | $ | 97,889 |  |  | $ | 95,679 |  |  |  |  |  |
| Electric utility | 69,273 |  |  | 51,240 |  |  |  |  |  |
| Commercial and other industrial | 40,625 |  |  | 44,300 |  |  |  |  |  |
| Petrochemical | 22,778 |  |  | 33,183 |  |  |  |  |  |
| Light rail traction power | 8,614 |  |  | 8,228 |  |  |  |  |  |
| All others | 12,005 |  |  | 8,801 |  |  |  |  |  |
| Total revenues by market sector | $ | 251,184 |  |  | $ | 241,431 |  |  |  |  |  |


## us-gaap:RevenueFromContractWithCustomerPolicyTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2026-05-05):
[0000080420-26-000070:note_history:16]
We also have contracts to provide field service inspection, installation, commissioning, modification, and repair services, as well as retrofit and retrofill components for existing systems. If the service contract terms give us the right to invoice the customer for an amount that corresponds directly with the value of our performance completed to date (i.e., a service contract in which we bill a fixed amount for each hour of service provided), then we recognize revenue over time in each reporting period corresponding to the amount that we have the right to invoice. Our performance obligations are satisfied as the work progresses. Revenues from our custom-engineered products and value-added services transferred to customers over time accounted for approximately 95% of revenues for both the three and six months ended March 31, 2026, 95% of revenues for the three months ended March 31, 2025, and 96% of revenues for the six months ended March 31, 2025.
  (was, 2026-02-04, similarity 0.9203):
[0000080420-26-000015:note_history:16]
We also have contracts to provide field service inspection, installation, commissioning, modification, and repair services, as well as retrofit and retrofill components for existing systems. If the service contract terms give us the right to invoice the customer for an amount that corresponds directly with the value of our performance completed to date (i.e., a service contract in which we bill a fixed amount for each hour of service provided), then we recognize revenue over time in each reporting period corresponding to the amount that we have the right to invoice. Our performance obligations are satisfied as the work progresses. Revenues from our custom-engineered products and value-added services transferred to customers over time accounted for approximately 94% and 97% of revenues for the three months ended December 31, 2025 and December 31, 2024, respectively.

- changed (2026-05-05):
[0000080420-26-000070:note_history:17]
We also have sales orders for spare parts and replacement circuit breakers for switchgear that are obsolete or that are no longer produced by the original manufacturer. Revenues from these sales orders are recognized at the time we fulfill our performance obligation to the customer, which is typically upon shipment and represented approximately 5% of revenues for both the three and six months ended March 31, 2026, 5% of revenues for the three months ended March 31, 2025, and 4% of revenues for the six months ended March 31, 2025.
  (was, 2026-02-04, similarity 0.7699):
[0000080420-26-000015:note_history:17]
We also have sales orders for spare parts and replacement circuit breakers for switchgear that are obsolete or that are no longer produced by the original manufacturer. Revenues from these sales orders are recognized at the time we fulfill our performance obligation to the customer, which is typically upon shipment and represented approximately 6% and 3% of revenues for the three months ended December 31, 2025 and December 31, 2024, respectively.

- changed (2026-05-05):
[0000080420-26-000070:note_history:18]
A performance obligation is a promise in a contract or with a customer to transfer a distinct good or service. A contract’s transaction price is allocated to each distinct performance obligation and recognized as revenue as the performance obligations are satisfied. To determine the proper revenue recognition for contracts, we evaluate whether a contract should be accounted for as more than one performance obligation or, less commonly, whether two or more contracts should be combined and accounted for as one performance obligation. This evaluation of performance obligations requires significant judgment. The majority of our contracts have a single performance obligation where multiple engineered products and services are combined into a single custom-engineered solution. Our contracts include a standard one-year assurance warranty. Occasionally, we provide service-type warranties that will extend the warranty period. These extended warranties qualify as a separate performance obligation, and revenue is deferred and recognized over the warranty period. If we determine during the evaluation of the contract that there are multiple performance obligations, we allocate the transaction price to each performance obligation using our best estimate of the standalone selling price of each distinct good or service in the contract. 
Remaining unsatisfied performance obligations, which we refer to as backlog, represent the estimated transaction price for goods and services for which we have a material right, but work has not yet been performed. As of March 31, 2026, we had backlog of $1.8 billion, of which approximately $1.1 billion is expected to be recognized as revenue within the next twelve months. Backlog may not be indicative of future operating results as orders may be cancelled or modified by our customers. Our backlog does not include service and maintenance-type contracts for which we have the right to invoice as services are performed.
Contract Estimates
  (was, 2026-02-04, similarity 0.9952):
[0000080420-26-000015:note_history:18]
A performance obligation is a promise in a contract or with a customer to transfer a distinct good or service. A contract’s transaction price is allocated to each distinct performance obligation and recognized as revenue as the performance obligations are satisfied. To determine the proper revenue recognition for contracts, we evaluate whether a contract should be accounted for as more than one performance obligation or, less commonly, whether two or more contracts should be combined and accounted for as one performance obligation. This evaluation of performance obligations requires significant judgment. The majority of our contracts have a single performance obligation where multiple engineered products and services are combined into a single custom-engineered solution. Our contracts include a standard one-year assurance warranty. Occasionally, we provide service-type warranties that will extend the warranty period. These extended warranties qualify as a separate performance obligation, and revenue is deferred and recognized over the warranty period. If we determine during the evaluation of the contract that there are multiple performance obligations, we allocate the transaction price to each performance obligation using our best estimate of the standalone selling price of each distinct good or service in the contract. 
Remaining unsatisfied performance obligations, which we refer to as backlog, represent the estimated transaction price for goods and services for which we have a material right, but work has not been performed. As of December 31, 2025, we had backlog of $1.6 billion, of which approximately $933 million is expected to be recognized as revenue within the next twelve months. Backlog may not be indicative of future operating results as orders may be cancelled or modified by our customers. Our backlog does not include service and maintenance-type contracts for which we have the right to invoice as services are performed.
Contract Estimates

- changed (2026-05-05):
[0000080420-26-000070:note_history:19]
Actual revenues and project costs may vary from previous estimates due to changes in a variety of factors. The cost estimation process is based on the professional knowledge and experience of our engineers, project managers and financial professionals. Factors that are considered in estimating the work to be completed and ultimate contract recovery include the availability and productivity of labor, the nature and complexity of the work to be performed, the availability of materials, and the effect of any delays on our project performance. We periodically review our job performance, job conditions, estimated profitability and final contract settlements, including our estimate of total costs and make revisions to costs and income in the period in which the revisions are probable and reasonably estimable. We bear the risk of cost overruns in most of our contracts, which may result in
  (was, 2026-02-04, similarity 0.8817):
[0000080420-26-000015:note_history:19]
Actual revenues and project costs may vary from previous estimates due to changes in a variety of factors. The cost estimation process is based on the professional knowledge and experience of our engineers, project managers and financial professionals. Factors that are considered in estimating the work to be completed and ultimate contract recovery include the availability and productivity of labor, the nature and complexity of the work to be performed, the availability of materials, and the effect of any delays on our project performance. We periodically review our job performance, job conditions, estimated profitability and final contract settlements, including our estimate of total costs and make revisions to costs and income in the period in which the revisions are probable and reasonably estimable. We bear the risk of cost overruns in most of our contracts, which may result in reduced profits. Whenever revisions of estimated contract costs and contract values indicate that the contract costs will exceed estimated revenues, thus creating a loss, a provision for the total estimated loss is recorded in that period.

- added (2026-05-05):
[0000080420-26-000070:note_history:20]
reduced profits. Whenever revisions of estimated contract costs and contract values indicate that the contract costs will exceed estimated revenues, thus creating a loss, a provision for the total estimated loss is recorded in that period.


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2026-05-05):
[0000080420-26-000070:note_history:21]
We also have contracts to provide field service inspection, installation, commissioning, modification, and repair services, as well as retrofit and retrofill components for existing systems. If the service contract terms give us the right to invoice the customer for an amount that corresponds directly with the value of our performance completed to date (i.e., a service contract in which we bill a fixed amount for each hour of service provided), then we recognize revenue over time in each reporting period corresponding to the amount that we have the right to invoice. Our performance obligations are satisfied as the work progresses. Revenues from our custom-engineered products and value-added services transferred to customers over time accounted for approximately 95% of revenues for both the three and six months ended March 31, 2026, 95% of revenues for the three months ended March 31, 2025, and 96% of revenues for the six months ended March 31, 2025.
  (was, 2026-02-04, similarity 0.9203):
[0000080420-26-000015:note_history:21]
We also have contracts to provide field service inspection, installation, commissioning, modification, and repair services, as well as retrofit and retrofill components for existing systems. If the service contract terms give us the right to invoice the customer for an amount that corresponds directly with the value of our performance completed to date (i.e., a service contract in which we bill a fixed amount for each hour of service provided), then we recognize revenue over time in each reporting period corresponding to the amount that we have the right to invoice. Our performance obligations are satisfied as the work progresses. Revenues from our custom-engineered products and value-added services transferred to customers over time accounted for approximately 94% and 97% of revenues for the three months ended December 31, 2025 and December 31, 2024, respectively.

- changed (2026-05-05):
[0000080420-26-000070:note_history:22]
We also have sales orders for spare parts and replacement circuit breakers for switchgear that are obsolete or that are no longer produced by the original manufacturer. Revenues from these sales orders are recognized at the time we fulfill our performance obligation to the customer, which is typically upon shipment and represented approximately 5% of revenues for both the three and six months ended March 31, 2026, 5% of revenues for the three months ended March 31, 2025, and 4% of revenues for the six months ended March 31, 2025.
  (was, 2026-02-04, similarity 0.7699):
[0000080420-26-000015:note_history:22]
We also have sales orders for spare parts and replacement circuit breakers for switchgear that are obsolete or that are no longer produced by the original manufacturer. Revenues from these sales orders are recognized at the time we fulfill our performance obligation to the customer, which is typically upon shipment and represented approximately 6% and 3% of revenues for the three months ended December 31, 2025 and December 31, 2024, respectively.

- changed (2026-05-05):
[0000080420-26-000070:note_history:23]
Remaining unsatisfied performance obligations, which we refer to as backlog, represent the estimated transaction price for goods and services for which we have a material right, but work has not yet been performed. As of March 31, 2026, we had backlog of $1.8 billion, of which approximately $1.1 billion is expected to be recognized as revenue within the next twelve months. Backlog may not be indicative of future operating results as orders may be cancelled or modified by our customers. Our backlog does not include service and maintenance-type contracts for which we have the right to invoice as services are performed.
  (was, 2026-02-04, similarity 0.9845):
[0000080420-26-000015:note_history:23]
Remaining unsatisfied performance obligations, which we refer to as backlog, represent the estimated transaction price for goods and services for which we have a material right, but work has not been performed. As of December 31, 2025, we had backlog of $1.6 billion, of which approximately $933 million is expected to be recognized as revenue within the next twelve months. Backlog may not be indicative of future operating results as orders may be cancelled or modified by our customers. Our backlog does not include service and maintenance-type contracts for which we have the right to invoice as services are performed.

- changed (2026-05-05):
[0000080420-26-000070:note_history:24]
Actual revenues and project costs may vary from previous estimates due to changes in a variety of factors. The cost estimation process is based on the professional knowledge and experience of our engineers, project managers and financial professionals. Factors that are considered in estimating the work to be completed and ultimate contract recovery include the availability and productivity of labor, the nature and complexity of the work to be performed, the availability of materials, and the effect of any delays on our project performance. We periodically review our job performance, job conditions, estimated profitability and final contract settlements, including our estimate of total costs and make revisions to costs and income in the period in which the revisions are probable and reasonably estimable. We bear the risk of cost overruns in most of our contracts, which may result in
  (was, 2026-02-04, similarity 0.8817):
[0000080420-26-000015:note_history:24]
Actual revenues and project costs may vary from previous estimates due to changes in a variety of factors. The cost estimation process is based on the professional knowledge and experience of our engineers, project managers and financial professionals. Factors that are considered in estimating the work to be completed and ultimate contract recovery include the availability and productivity of labor, the nature and complexity of the work to be performed, the availability of materials, and the effect of any delays on our project performance. We periodically review our job performance, job conditions, estimated profitability and final contract settlements, including our estimate of total costs and make revisions to costs and income in the period in which the revisions are probable and reasonably estimable. We bear the risk of cost overruns in most of our contracts, which may result in reduced profits. Whenever revisions of estimated contract costs and contract values indicate that the contract costs will exceed estimated revenues, thus creating a loss, a provision for the total estimated loss is recorded in that period.

- added (2026-05-05):
[0000080420-26-000070:note_history:25]
reduced profits. Whenever revisions of estimated contract costs and contract values indicate that the contract costs will exceed estimated revenues, thus creating a loss, a provision for the total estimated loss is recorded in that period.

- changed (2026-05-05):
[0000080420-26-000070:note_history:26]
For the six months ended March 31, 2026 and 2025, our operating results were positively impacted by $14.2 million and $8.8 million, respectively, as a result of net changes in contract estimates related to projects in progress at the beginning of the respective period. These changes in estimates resulted primarily from favorable project execution, reduced cost estimates and negotiations of variable consideration, discussed below, as well as revenue recognized from project cancellations and other changes in facts and circumstances during these periods. Gross unfavorable changes in contract estimates were immaterial for both the six months ended March 31, 2026 and 2025.
  (was, 2026-02-04, similarity 0.9103):
[0000080420-26-000015:note_history:26]
For the three months ended December 31, 2025 and 2024, our operating results were positively impacted by $10.5 million and $2.4 million, respectively, as a result of net changes in contract estimates related to projects in progress at the beginning of the respective period. These changes in estimates resulted primarily from favorable project execution, reduced cost estimates and negotiations of variable consideration, discussed below, as well as revenue recognized from project cancellations and other changes in facts and circumstances during these periods. Gross unfavorable changes in contract estimates were immaterial for both the three months ended December 31, 2025 and 2024.

- changed (2026-05-05):
[0000080420-26-000070:note_history:27]
Contract assets and liabilities as of March 31, 2026 and September 30, 2025 are summarized below (in thousands):
  (was, 2026-02-04, similarity 0.9565):
[0000080420-26-000015:note_history:27]
Contract assets and liabilities as of December 31, 2025 and September 30, 2025 are summarized below (in thousands):

- changed (2026-05-05):
[0000080420-26-000070:note_history:28]
|  | March 31, 2026 |  | September 30, 2025 |
| Contract assets | $ | 113,297 |  |  | $ | 136,679 |  |
| Contract liabilities | (314,506) |  |  | (297,949) |  |
| Net contract liability | $ | (201,209) |  |  | $ | (161,270) |  |
  (was, 2026-02-04, similarity 0.9739):
[0000080420-26-000015:note_history:28]
|  | December 31, 2025 |  | September 30, 2025 |
| Contract assets | $ | 121,543 |  |  | $ | 136,679 |  |
| Contract liabilities | (302,143) |  |  | (297,949) |  |
| Net contract liability | $ | (180,600) |  |  | $ | (161,270) |  |

- changed (2026-05-05):
[0000080420-26-000070:note_history:29]
Our net contract billing position remained a net liability at both March 31, 2026 and September 30, 2025, primarily due to favorable contract billing milestones. We typically allocate a significant percentage of the progress billing to the early stages of the contract. To determine the amount of revenue recognized during the period from contract liabilities, we first allocate revenue to the individual contract liability balance outstanding at the beginning of the period until the revenue exceeds that balance. During the six months ended March 31, 2026, we recognized revenue of $204.3 million that was related to contract liabilities outstanding at September 30, 2025.
  (was, 2026-02-04, similarity 0.9524):
[0000080420-26-000015:note_history:29]
Our net contract billing position remained a net liability at both December 31, 2025 and September 30, 2025, primarily due to favorable contract billing milestones. We typically allocate a significant percentage of the progress billing to the early stages of the contract. To determine the amount of revenue recognized during the period from contract liabilities, we first allocate revenue to the individual contract liability balance outstanding at the beginning of the period until the revenue exceeds that balance. During the three months ended December 31, 2025, we recognized revenue of $120.3 million that was related to contract liabilities outstanding at September 30, 2025.

- added (2026-05-05):
[0000080420-26-000070:note_history:30]
The timing of our invoice process is typically dependent on the completion of certain milestones and contract terms and is subject to agreement by our customer. Payment is typically expected within 30 days of invoice. Any uncollected invoiced

- added (2026-05-05):
[0000080420-26-000070:note_history:31]
amounts for our performance obligations recognized over time, including contract retentions, are recorded as accounts receivable in the Condensed Consolidated Balance Sheets. Certain contracts allow customers to withhold a small percentage of billings pursuant to retainage provisions, and such amounts are generally due upon completion of the contract and acceptance of the project by the customer. Based on our experience in recent years, the majority of these retainage balances are expected to be collected within approximately twelve months. As of March 31, 2026 and September 30, 2025, we had retention amounts of $6.0 million and $8.1 million, respectively. Of the retained amount at March 31, 2026, $5.8 million is expected to be collected in the next twelve months and is recorded in accounts receivable. The remaining $0.2 million is recorded in other assets.

- changed (2026-05-05):
[0000080420-26-000070:note_history:32]
The following tables present our disaggregated revenue by geographic destination and market sector for the three and six months ended March 31, 2026 and 2025 (in thousands):
  (was, 2026-02-04, similarity 0.9477):
[0000080420-26-000015:note_history:32]
The following tables present our disaggregated revenue by geographic destination and market sector for the three months ended December 31, 2025 and 2024 (in thousands):

- changed (2026-05-05):
[0000080420-26-000070:note_history:33]
|  | Three months ended March 31, |  | Six months ended March 31, |
|  | 2026 |  | 2025 |  | 2026 |  | 2025 |
| United States | $ | 232,272 |  |  | $ | 227,834 |  |  | $ | 427,150 |  |  | $ | 425,606 |  |
| Canada | 29,823 |  |  | 33,970 |  |  | 62,282 |  |  | 65,664 |  |
| Middle East and Africa | 13,618 |  |  | 8,282 |  |  | 23,490 |  |  | 12,840 |  |
| Europe | 10,478 |  |  | 5,897 |  |  | 18,704 |  |  | 11,425 |  |
| Asia/Pacific | 9,840 |  |  | 1,646 |  |  | 15,143 |  |  | 3,226 |  |
| Mexico, Central and South America | 584 |  |  | 1,002 |  |  | 1,030 |  |  | 1,301 |  |
| Total revenues by geographic destination | $ | 296,615 |  |  | $ | 278,631 |  |  | $ | 547,799 |  |  | $ | 520,062 |  |
  (was, 2026-02-04, similarity 0.7136):
[0000080420-26-000015:note_history:33]
|  | Three months ended December 31, |  |  |
|  | 2025 |  | 2024 |  |  |  |  |
| United States | $ | 194,878 |  |  | $ | 197,772 |  |  |  |  |  |
| Canada | 32,459 |  |  | 31,694 |  |  |  |  |  |
| Middle East and Africa | 9,872 |  |  | 4,558 |  |  |  |  |  |
| Europe | 8,226 |  |  | 5,528 |  |  |  |  |  |
| Asia/Pacific | 5,303 |  |  | 1,580 |  |  |  |  |  |
| Mexico, Central and South America | 446 |  |  | 299 |  |  |  |  |  |
| Total revenues by geographic destination | $ | 251,184 |  |  | $ | 241,431 |  |  |  |  |  |

- added (2026-05-05):
[0000080420-26-000070:note_history:34]
|  | Three months ended March 31, |  | Six months ended March 31, |
|  | 2026 |  | 2025 |  | 2026 |  | 2025 |
| Oil and gas (excludes petrochemical) | $ | 112,744 |  |  | $ | 101,167 |  |  | $ | 210,633 |  |  | $ | 196,846 |  |
| Electric utility | 80,479 |  |  | 70,339 |  |  | 149,752 |  |  | 121,579 |  |
| Commercial and other industrial | 54,446 |  |  | 40,369 |  |  | 95,071 |  |  | 84,669 |  |
| Petrochemical | 27,551 |  |  | 43,704 |  |  | 50,329 |  |  | 76,887 |  |
| Light rail traction power | 9,048 |  |  | 10,008 |  |  | 17,662 |  |  | 18,236 |  |
| All others | 12,347 |  |  | 13,044 |  |  | 24,352 |  |  | 21,845 |  |
| Total revenues by market sector | $ | 296,615 |  |  | $ | 278,631 |  |  | $ | 547,799 |  |  | $ | 520,062 |  |

- removed (2026-05-05):
[0000080420-26-000015:note_history:35]
The timing of our invoice process is typically dependent on the completion of certain milestones and contract terms and is subject to agreement by our customer. Payment is typically expected within 30 days of invoice. Any uncollected invoiced amounts for our performance obligations recognized over time, including contract retentions, are recorded as accounts receivable in the Condensed Consolidated Balance Sheets. Certain contracts allow customers to withhold a small percentage of billings pursuant to retainage provisions, and such amounts are generally due upon completion of the contract and acceptance of

- removed (2026-05-05):
[0000080420-26-000015:note_history:36]
the project by the customer. Based on our experience in recent years, the majority of these retainage balances are expected to be collected within approximately twelve months. As of December 31, 2025 and September 30, 2025, we had retention amounts of $7.2 million and $8.1 million, respectively. Of the retained amount at December 31, 2025, $7.0 million is expected to be collected in the next twelve months and is recorded in accounts receivable. The remaining $0.2 million is recorded in other assets.

- removed (2026-05-05):
[0000080420-26-000015:note_history:37]
|  | Three months ended December 31, |  |  |
|  | 2025 |  | 2024 |  |  |  |  |
| Oil and gas (excludes petrochemical) | $ | 97,889 |  |  | $ | 95,679 |  |  |  |  |  |
| Electric utility | 69,273 |  |  | 51,240 |  |  |  |  |  |
| Commercial and other industrial | 40,625 |  |  | 44,300 |  |  |  |  |  |
| Petrochemical | 22,778 |  |  | 33,183 |  |  |  |  |  |
| Light rail traction power | 8,614 |  |  | 8,228 |  |  |  |  |  |
| All others | 12,005 |  |  | 8,801 |  |  |  |  |  |
| Total revenues by market sector | $ | 251,184 |  |  | $ | 241,431 |  |  |  |  |  |


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: tag_name, score: 1.0

- added (2026-05-05):
[0000080420-26-000070:note_history:38]
Subsequent Events
Common Stock Split

- added (2026-05-05):
[0000080420-26-000070:note_history:39]
On April 2, 2026, the Company effected a three-for-one forward split of its common stock and proportionately increased the number of shares of authorized common stock from 30,000,000 to 90,000,000. Each shareholder of record as of the close of trading on March 20, 2026 received, after the close of trading on April 2, 2026, two additional shares for every one share held on the Record Date. The shares of common stock retain a par value of $0.01 per share. Trading began on a split-adjusted basis at market open on April 6, 2026. See Note A. Overview and Summary of Significant Accounting Policies for addition information regarding the Common Stock Split.

- changed (2026-05-05):
[0000080420-26-000070:note_history:40]
Quarterly Dividend Declared
  (was, 2026-02-04, similarity 0.75):
[0000080420-26-000015:note_history:40]
Subsequent Events
Quarterly Dividend Declared

- added (2026-05-05):
[0000080420-26-000070:note_history:41]
On May 5, 2026, our Board of Directors declared a quarterly cash dividend on our common stock in the amount of $0.09 per share. The dividend is payable on June 17, 2026 to shareholders of record at the close of business on May 20, 2026.

- removed (2026-05-05):
[0000080420-26-000015:note_history:42]
On February 3, 2026, our Board of Directors approved an increase to the quarterly cash dividend on our common stock to $0.27 per share, equating to an annualized dividend of $1.08 per share from the current amount of $1.07 per share. The dividend is payable on March 18, 2026 to shareholders of record at the close of business on February 18, 2026.
