# POWL 8-K — 0000080420-26-000063 filed 2026-05-04

## item codes, every 8-K on or before 2026-05-05

- 2026-05-05 0000080420-26-000067 — 8.01, 9.01
- 2026-05-04 0000080420-26-000063 — 2.02, 9.01
- 2026-03-31 0000080420-26-000054 — 5.03, 9.01
- 2026-02-18 0000080420-26-000028 — 5.07, 8.01
- 2026-02-03 0000080420-26-000013 — 2.02, 8.01, 9.01
- 2026-01-06 0000080420-26-000009 — 5.02
- 2025-11-18 0000080420-25-000145 — 2.02, 9.01
- 2025-11-04 0000080420-25-000140 — 8.01, 9.01
- 2025-08-05 0000080420-25-000095 — 2.02, 8.01, 9.01
- 2025-07-22 0000080420-25-000087 — 5.02
- 2025-05-06 0000080420-25-000057 — 2.02, 8.01, 9.01
- 2025-02-24 0000080420-25-000044 — 3.03, 5.03, 9.01
- 2025-02-19 0000080420-25-000034 — 5.03, 5.07, 9.01
- 2025-02-06 0000080420-25-000026 — 2.02, 9.01
- 2025-02-04 0000080420-25-000020 — 8.01, 9.01
- 2024-11-19 0000080420-24-000084 — 2.02, 9.01
- 2024-11-05 0000080420-24-000081 — 8.01, 9.01
- 2024-07-30 0000080420-24-000057 — 2.02, 8.01, 9.01
- 2024-04-30 0000080420-24-000026 — 2.02, 8.01, 9.01
- 2024-02-15 0000080420-24-000014 — 5.02, 5.07
- 2024-01-30 0000080420-24-000005 — 2.02, 8.01, 9.01
- 2024-01-08 0000080420-24-000002 — 5.02
- 2023-12-05 0000080420-23-000047 — 2.02, 9.01
- 2023-11-03 0000080420-23-000044 — 8.01, 9.01
- 2023-10-11 0000080420-23-000041 — 1.01, 2.03
- 2023-08-01 0000080420-23-000036 — 2.02, 8.01, 9.01
- 2023-05-19 0001193125-23-149334 — 5.07 — amendment of 0000080420-23-000011
- 2023-05-03 0000080420-23-000025 — 2.02, 8.01, 9.01
- 2023-04-06 0000080420-23-000020 — 1.01, 2.03, 9.01
- 2023-04-05 0000080420-23-000018 — 5.02
- 2023-02-16 0000080420-23-000011 — 5.02, 5.07, 9.01
- 2023-01-31 0000080420-23-000004 — 2.02, 8.01
- 2022-12-05 0000080420-22-000034 — 2.02, 9.01
- 2022-08-02 0000080420-22-000030 — 2.02, 8.01, 9.01
- 2022-05-13 0000080420-22-000024 — 5.02, 9.01
- 2022-05-03 0000080420-22-000016 — 2.02, 9.01
- 2022-05-03 0000080420-22-000015 — 8.01, 9.01
- 2022-02-17 0000080420-22-000010 — 5.07
- 2022-02-08 0000080420-22-000005 — 2.02, 9.01
- 2022-02-01 0000080420-22-000002 — 8.01, 9.01
- 2021-12-07 0000080420-21-000043 — 2.02, 9.01
- 2021-08-03 0000080420-21-000036 — 2.02, 8.01, 9.01
- 2021-05-04 0000080420-21-000026 — 2.02, 8.01, 9.01
- 2021-03-16 0001193125-21-082878 — 1.01, 2.03, 9.01
- 2021-03-05 0000080420-21-000021 — 5.02, 8.01, 9.01
- 2021-02-26 0000080420-21-000018 — 5.03
- 2021-02-18 0000080420-21-000016 — 5.07
- 2021-02-02 0000080420-21-000010 — 2.02, 8.01, 9.01
- 2020-12-08 0000080420-20-000032 — 2.02, 9.01
- 2020-11-12 0000080420-20-000030 — 8.01, 9.01
- 2020-08-04 0000080420-20-000024 — 2.02, 8.01, 9.01
- 2020-05-05 0000080420-20-000017 — 2.02, 8.01, 9.01
- 2020-02-21 0000080420-20-000008 — 5.07
- 2020-02-04 0000080420-20-000003 — 2.02, 8.01, 9.01
- 2019-12-04 0001193125-19-306243 — 2.02, 9.01
- 2019-11-08 0000080420-19-000032 — 8.01, 9.01
- 2019-10-03 0000080420-19-000030 — 1.01, 2.03
- 2019-09-24 0000080420-19-000028 — 8.01, 9.01
- 2019-08-06 0000080420-19-000022 — 2.02, 8.01, 9.01
- 2019-05-08 0000080420-19-000017 — 5.02, 9.01
- 2019-05-07 0000080420-19-000011 — 2.02, 8.01, 9.01
- 2019-02-22 0001193125-19-048366 — 5.07
- 2019-02-05 0000080420-19-000003 — 2.02, 8.01
- 2018-12-21 0000080420-18-000038 — 5.02, 9.01
- 2018-12-12 0000080420-18-000031 — 2.02
- 2018-11-05 0000080420-18-000029 — 8.01, 9.01
- 2018-11-01 0000080420-18-000027 — 5.02, 8.01, 9.01
- 2018-10-01 0000080420-18-000024 — 5.02
- 2018-08-07 0000080420-18-000020 — 2.02, 8.01
- 2018-05-15 0000080420-18-000016 — 5.02, 8.01
- 2018-05-09 0000080420-18-000011 — 2.02, 8.01
- 2018-02-22 0000080420-18-000009 — 5.07
- 2018-02-06 0000080420-18-000003 — 2.02, 8.01
- 2017-12-27 0001193125-17-379928 — 5.02
- 2017-12-05 0000080420-17-000028 — 2.02, 9.01
- 2017-11-08 0000080420-17-000024 — 8.01, 9.01
- 2017-11-03 0000080420-17-000022 — 5.02
- 2017-08-09 0000080420-17-000017 — 2.02, 8.01
- 2017-06-30 0000080420-17-000014 — 1.01, 9.01
- 2017-05-03 0000080420-17-000006 — 2.02, 8.01, 9.01
- 2017-02-23 0000080420-17-000004 — 5.07
- 2017-02-08 0001628280-17-000965 — 2.02 — amendment of 0001628280-17-000949
- 2017-02-07 0001628280-17-000949 — 2.01, 8.01, 9.01
- 2016-12-07 0001193125-16-787354 — 2.02, 9.01
- 2016-11-01 0001193125-16-755475 — 8.01, 9.01
- 2016-09-30 0001193125-16-726999 — 5.02, 8.01, 9.01
- 2016-08-03 0001193125-16-669308 — 2.02, 8.01, 9.01
- 2016-05-04 0001193125-16-576528 — 2.02, 8.01, 9.01
- 2016-02-25 0001193125-16-477896 — 5.07
- 2016-02-03 0001193125-16-449052 — 2.02, 8.01, 9.01
- 2015-12-31 0001193125-15-418363 — 5.02, 7.01, 9.01
- 2015-12-02 0001193125-15-393109 — 2.02, 9.01
- 2015-11-05 0001193125-15-368085 — 8.01, 9.01
- 2015-09-25 0001193125-15-329031 — 5.02
- 2015-08-05 0001193125-15-277912 — 2.02, 8.01, 9.01
- 2015-05-06 0001193125-15-174291 — 2.02, 8.01, 9.01
- 2015-03-06 0001193125-15-081070 — 5.02
- 2015-03-02 0001193125-15-072946 — 5.07
- 2015-02-03 0001193125-15-031772 — 2.02, 8.01, 9.01
- 2014-12-18 0001193125-14-446513 — 8.01, 9.01
- 2014-12-03 0001193125-14-431745 — 2.02, 9.01
- 2014-11-05 0001193125-14-397955 — 8.01, 9.01
- 2014-09-26 0001193125-14-353741 — 7.01, 9.01
- 2014-08-05 0001193125-14-296001 — 2.02, 8.01, 9.01
- 2014-05-07 0001193125-14-187496 — 2.02, 8.01, 9.01
- 2014-03-03 0001193125-14-079843 — 5.02, 5.07
- 2014-02-05 0001193125-14-036633 — 2.02, 8.01, 9.01
- 2014-01-17 0001193125-14-014351 — 1.01, 8.01, 9.01
- 2014-01-06 0001193125-14-002795 — 1.01, 2.03
- 2013-12-06 0001564590-13-001411 — 2.02, 9.01
- 2013-12-05 0001564590-13-001406 — 5.02, 8.01, 9.01
- 2013-11-07 0001193125-13-432950 — 8.01, 9.01
- 2013-08-07 0001193125-13-324337 — 2.02, 9.01
- 2013-05-08 0001193125-13-206800 — 2.02, 9.01
- 2013-02-22 0001193125-13-070971 — 5.02, 5.07
- 2013-02-06 0001193125-13-040556 — 2.02, 9.01
- 2012-12-18 0001193125-12-506417 — 5.02, 9.01
- 2012-12-05 0001193125-12-491749 — 2.02, 9.01
- 2012-10-12 0001193125-12-421889 — 3.03, 5.02, 5.03, 9.01
- 2012-08-09 0001193125-12-344617 — 5.02, 8.01, 9.01
- 2012-08-08 0001193125-12-343630 — 2.02, 9.01
- 2012-05-09 0001193125-12-221356 — 2.02, 9.01
- 2012-02-08 0001193125-12-046560 — 2.02, 9.01
- 2011-12-08 0001193125-11-334810 — 2.02, 9.01
- 2011-11-08 0000950123-11-096524 — 2.02, 2.06, 4.02, 9.01
- 2011-10-14 0000950123-11-090124 — 5.02
- 2011-10-06 0000950123-11-088969 — 5.02
- 2011-09-19 0000950123-11-085224 — 5.02, 9.01
- 2011-09-15 0000950123-11-084806 — 5.02, 9.01
- 2011-08-04 0000950123-11-072788 — 2.02, 9.01
- 2011-07-22 0000950123-11-067402 — 5.07
- 2011-05-24 0000950123-11-053550 — 1.01, 2.03, 9.01
- 2011-05-04 0000950123-11-044561 — 2.02, 9.01
- 2011-02-02 0000950123-11-008188 — 2.02, 9.01
- 2010-12-08 0000950123-10-111987 — 2.02, 9.01
- 2010-08-05 0000950123-10-073114 — 2.02, 9.01
- 2010-05-18 0000950123-10-050900 — 5.02
- 2010-05-05 0000950123-10-044499 — 2.02, 9.01
- 2010-02-03 0000950123-10-008278 — 2.02, 9.01
- 2009-12-21 0000950123-09-072269 — 1.01, 2.01, 2.03, 8.01, 9.01
- 2009-12-09 0000950123-09-069525 — 2.02, 9.01
- 2009-10-27 0000950123-09-053501 — 1.01, 8.01, 9.01
- 2009-08-04 0000950123-09-029476 — 2.02, 9.01
- 2009-05-06 0000950129-09-001498 — 2.02, 9.01
- 2009-03-05 0000950129-09-000749 — 1.01, 9.01
- 2009-02-10 0000950129-09-000349 — 2.02, 9.01
- 2008-12-10 0000950134-08-021934 — 2.02, 9.01
- 2008-08-06 0000950129-08-004267 — 2.02, 9.01
- 2008-07-24 0000950129-08-004063 — 1.01, 5.02, 8.01, 9.01
- 2008-06-16 0000950129-08-003500 — 9.01 — amendment of 0000950134-06-015374
- 2008-06-05 0000950129-08-003378 — 5.02, 9.01
- 2008-05-08 0000950129-08-002843 — 2.02, 9.01
- 2008-02-06 0000950129-08-000533 — 2.02, 9.01
- 2007-12-19 0000950129-07-006277 — 1.01, 2.03, 9.01
- 2007-12-06 0000950129-07-006003 — 2.02, 9.01
- 2007-08-21 0000950129-07-004181 — 2.02, 9.01
- 2007-05-31 0000950129-07-002810 — 2.02, 9.01
- 2007-05-21 0000950129-07-002668 — 2.02, 3.01, 4.02, 9.01
- 2007-04-16 0000950129-07-002002 — 2.02, 4.02, 9.01
- 2007-03-01 0000950129-07-001104 — 5.02, 8.01, 9.01
- 2007-02-08 0000950129-07-000451 — 2.02, 9.01
- 2006-12-08 0000950129-06-010041 — 2.02, 9.01
- 2006-09-08 0000950129-06-008379 — 2.02, 9.01
- 2006-08-09 0000950134-06-015374 — 1.01, 2.01, 8.01, 9.01
- 2006-06-08 0000950129-06-006127 — 2.02, 9.01
- 2006-03-09 0000950129-06-002455 — 2.02, 9.01
- 2005-12-16 0000950129-05-012031 — 2.02, 5.03, 9.01
- 2005-09-13 0000950129-05-009181 — 2.01, 9.01 — amendment of 0000950129-05-006889
- 2005-09-12 0000950129-05-009151 — 2.02, 9.01
- 2005-07-06 0000950129-05-006889 — 1.01, 1.02, 2.01, 2.03, 9.01
- 2005-06-10 0000950129-05-006128 — 2.02, 9.01
- 2005-04-20 0000080420-05-000031 — 5.02
- 2005-03-11 0000080420-05-000024 — 9.01
- 2005-02-25 0000080420-05-000018 — 7.01, 9.01
- 2005-01-21 0000080420-05-000009 — 7.01, 9.01
- 2004-12-17 0000080420-04-000049 — 2.02, 9.01
- 2004-11-01 0000080420-04-000045 — 8.01, 9.01
- 2004-10-08 0001169232-04-005133 — 2.05
- 2004-09-14 0000080420-04-000037 — 5.02
- 2004-09-02 0000080420-04-000030 — 2.02, 9.01
- 2004-06-08 0000080420-04-000021 — 7
- 2004-05-13 0000080420-04-000019 — 4
- 2004-02-27 0000080420-04-000013 — 7
- 2003-12-16 0000950129-03-006136 — 12, 7
- 2003-08-29 0000950129-03-004531 — 12, 7
- 2003-06-03 0000950129-03-003035 — 7, 9
- 2003-05-15 0000950129-03-002812 — 7, 9
- 2002-05-29 0000950129-02-002795 — 4
- 2000-12-21 0000950129-00-006093 — 5, 7
- 1998-09-04 0000950129-98-003802 — 5
- 1996-08-09 0000950129-96-001705 — 2, 7

## late-filing notifications on or before 2026-05-05

- 2007-05-11 0000950129-07-002494 — NT 10-Q, for the period ended 2007-03-31
- 2005-01-18 0000080420-05-000004 — NT 10-K, for the period ended 2004-10-31

## item 2.02 — earnings release, exhibit 99.1

[0000080420-26-000063:8k_2_02:1]
EX-99.1
2
ex991-powlq2xfy2026earning.htm
EX-99.1

[0000080420-26-000063:8k_2_02:2]
Document

[0000080420-26-000063:8k_2_02:3]
Exhibit 99.1

[0000080420-26-000063:8k_2_02:4]
PRESS RELEASE

[0000080420-26-000063:8k_2_02:5]
| For Immediate Release |  |  | Contact: | Michael Metcalf, CFO |
|  |  |  |  | Powell Industries, Inc. |
|  |  |  |  | 713-947-4422 |
|  |  |  |  | Robert Winters or Ryan Coleman |
|  |  |  |  | Alpha IR Group |
|  |  |  |  | POWL@alpha-ir.com |
|  |  |  |  | 312-445-2870 |

[0000080420-26-000063:8k_2_02:6]
POWELL INDUSTRIES ANNOUNCES SECOND QUARTER FISCAL 2026 RESULTS

[0000080420-26-000063:8k_2_02:7]
HOUSTON — May 4, 2026 — Powell Industries, Inc. (NASDAQ: POWL) (“Powell” or the “Company”), a leading supplier of custom-engineered solutions for the management, control and distribution of electrical energy, today announced results for the second quarter Fiscal 2026 ended March 31, 2026. All comparisons are to the second quarter of Fiscal 2025, unless otherwise noted.

[0000080420-26-000063:8k_2_02:8]
Key Highlights:

[0000080420-26-000063:8k_2_02:9]
•Revenues of $297 million increased 6%;

[0000080420-26-000063:8k_2_02:10]
•Gross profit of $88 million, or 29.6% of revenue, increased 5%;

[0000080420-26-000063:8k_2_02:11]
•Net income of $45.9 million, or $1.25 per diluted share(1), declined 1%;

[0000080420-26-000063:8k_2_02:12]
•New orders(2) totaled $490 million, an increase of 97%;

[0000080420-26-000063:8k_2_02:13]
•Backlog(3) as of March 31, 2026 totaled $1.8 billion, an increase of 33%;

[0000080420-26-000063:8k_2_02:14]
•Cash and short-term investments as of March 31, 2026 totaled $545 million;

[0000080420-26-000063:8k_2_02:15]
•Subsequent to quarter end, Powell was awarded a mega(4) data center order with a value exceeding $400 million.

[0000080420-26-000063:8k_2_02:16]
Exhibit 99.1

[0000080420-26-000063:8k_2_02:17]
Brett A. Cope, Powell’s Chairman and Chief Executive Officer, stated, “The commercial momentum we observed to start the fiscal year continued throughout the second quarter, driving a well-balanced and strong order total of $490 million which led to a 1.7x book-to-bill ratio. That momentum has continued into our fiscal third quarter as evidenced by the mega(4) data center order we were awarded after the fiscal second quarter-end with a value in excess of $400 million – the largest order in Powell history.  Meanwhile, the team continues to demonstrate high levels of project execution, delivering a gross margin of 29.6% in the quarter. We remain acutely focused on executing our key growth objectives and delivering on project schedules for our customers to further Powell’s competitive position against a favorable demand landscape for engineered-to-order distribution solutions.”

[0000080420-26-000063:8k_2_02:18]
Second Quarter Fiscal 2026 Results

[0000080420-26-000063:8k_2_02:19]
Revenues totaled $296.6 million, an increase of 6% compared to $278.6 million in the prior year, and a sequential increase of 18% compared to $251.2 million in the first quarter of Fiscal 2026. The growth compared to the prior year was driven by higher revenue levels from the Commercial & Other Industrial market, which grew 35%, as well as from the Electric Utility and Oil & Gas markets, which grew 14% and 11%, respectively. This was partially offset by lower revenue within the Petrochemical market, which declined 37%. The sequential increase was consistent with the typical seasonal acceleration from the first fiscal quarter driven by a higher number of working days.

[0000080420-26-000063:8k_2_02:20]
Gross profit of $87.9 million, or 29.6% of revenue, increased 5% compared to $83.4 million, or 29.9% of revenue, in the prior year and increased sequentially by 23% compared to $71.4 million, or 28.4% of revenue, in the first quarter of Fiscal 2026.  The year‑over‑year increase in gross profit was primarily driven by higher revenues, while the sequential improvement also reflected favorable volume leverage, strong project execution, and a continued stable pricing environment.

[0000080420-26-000063:8k_2_02:21]
New orders totaled $490 million compared to $249 million in the prior year and $439 million in the first quarter of Fiscal 2026. The increases were driven by improved bookings across the Company’s core markets, including the Electric Utility, Commercial & Other Industrial, and Oil & Gas markets. During the quarter, the Company was awarded a mega(4) electric utility order and a mega(4) data center order, each with a value exceeding $75 million. In addition to these mega orders booked in the second fiscal quarter of 2026, subsequent to the end of the second quarter, the

[0000080420-26-000063:8k_2_02:22]
Exhibit 99.1

[0000080420-26-000063:8k_2_02:23]
Company was awarded an additional mega(4) data center order with a value exceeding $400 million related to a behind-the-meter design of on-site generation assets.

[0000080420-26-000063:8k_2_02:24]
Backlog totaled $1.8 billion as of March 31, 2026, an increase of 12% compared to $1.6 billion as of December 31, 2025, and an increase of 33% compared to $1.3 billion as of March 31, 2025.

[0000080420-26-000063:8k_2_02:25]
Net income of $45.9 million, or $1.25 per diluted share, declined 1% compared to $46.3 million, or $1.27 per diluted share as adjusted for the Stock Split(1), in the prior year. The decline was the result of higher SG&A expenses, driven by higher compensation expenses, as well as an increase in R&D expenses. Net income in the quarter increased sequentially by 11% compared to $41.4 million, or $1.13 per diluted share as adjusted for the Stock Split(1), in the first quarter of Fiscal 2026.

[0000080420-26-000063:8k_2_02:26]
On April 2, 2026, we effected a three-for-one forward split of our common stock and proportionately increased the number of authorized common stock from 30,000,000 to 90,000,000. Each shareholder of record as of the close of trading on March 20, 2026 (the “Record Date”) received, after the close of trading on April 2, 2026, two additional shares for every one share held on the Record Date. Trading began on a split-adjusted basis at market open on April 6, 2026.

[0000080420-26-000063:8k_2_02:27]
OUTLOOK

[0000080420-26-000063:8k_2_02:28]
Commenting on the Company’s expectations for Fiscal 2026, Cope added, “Market activity across each of our core markets remains favorable. We remain optimistic that the ongoing investment cycle to support data center build outs and AI capacity growth, in addition to addressing future power demand, will remain supportive of overall activity in our commercial and electric utility end markets. We also anticipate that activity within the gas market, including LNG, gas pipeline and gas-to-chemical end markets, will remain active, driven by the advantaged competitive position which we believe U.S.-based exporters currently maintain.”

[0000080420-26-000063:8k_2_02:29]
Michael Metcalf, Powell’s Chief Financial Officer, commented, “Our year-to-date financial results show sustainable growth over the prior year and reinforce our conviction in delivering another year of solid financial performance in Fiscal 2026. Looking at the current composition of our backlog, we expect margins to remain consistent with the performance levels achieved in the prior year. The recent acceleration in backlog growth further strengthens our confidence to prudently invest in incremental capacity to complement our existing manufacturing footprint, including the most recent capacity expansion projects at our facilities. We continue to evaluate

[0000080420-26-000063:8k_2_02:30]
Exhibit 99.1

[0000080420-26-000063:8k_2_02:31]
potential capacity investments with an emphasis on ensuring adequate returns, supported by the visibility provided by our backlog and the commercial outlook across our core markets.”

[0000080420-26-000063:8k_2_02:32]
CONFERENCE CALL

[0000080420-26-000063:8k_2_02:33]
Powell Industries has scheduled a conference call for Tuesday, May 5, 2026 at 11:00 a.m. Eastern time. To participate in the conference call, dial 1-833-953-2431 (domestic) or 1-412-317-5760 (international) at least 10 minutes before the call begins and ask for the Powell Industries conference call. A telephonic replay of the conference call will be available through May 12, 2026 and may be accessed by calling 1-855-669-9658 (domestic) or 1-412-317-0088 (international) and using passcode 7179345#.

[0000080420-26-000063:8k_2_02:34]
Investors, analysts and the general public will also have the opportunity to listen to the conference call over the Internet by visiting powellind.com. To listen to the live call on the web, please visit the website at least 15 minutes before the call begins to register, download and install any necessary audio software.  For those who cannot listen to the live webcast, an archive will be available shortly after the call and will remain available for approximately twelve months at powellind.com.

[0000080420-26-000063:8k_2_02:35]
About Powell Industries

[0000080420-26-000063:8k_2_02:36]
Powell Industries, Inc., headquartered in Houston, Texas, develops, designs, manufactures and services custom-engineered equipment and systems that distribute, control and monitor the flow of electrical energy and provide protection to motors, transformers and other electrically powered equipment.  Powell Industries, Inc. primarily serves the oil and gas and petrochemical markets, the electric utility market, and commercial and other industrial markets. Beyond these major markets, we also provide products and services to the light rail traction power market and other markets that include universities and government entities. We are continuously developing new channels to electrical markets through original equipment manufacturers and distribution market channels.   For more information, please visit powellind.com.

[0000080420-26-000063:8k_2_02:37]
Exhibit 99.1

[0000080420-26-000063:8k_2_02:38]
Exhibit 99.1

[0000080420-26-000063:8k_2_02:39]
POWELL INDUSTRIES, INC. & SUBSIDIARIES

[0000080420-26-000063:8k_2_02:40]
CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS

[0000080420-26-000063:8k_2_02:41]
|  | Three Months EndedMarch 31, |  | Six Months EndedMarch 31, |
|  | 2026 |  | 2025 |  | 2026 |  | 2025 |
| (In thousands, except per share data) |  |  |  |  |  |  |  |
|  | (Unaudited) |
| Revenues | $ | 296,615 |  |  | $ | 278,631 |  |  | $ | 547,799 |  |  | $ | 520,062 |  |
| Cost of goods sold | 208,679 |  |  | 195,199 |  |  | 388,445 |  |  | 377,106 |  |
| Gross profit | 87,936 |  | 83,432 |  | 159,354 |  | 142,956 |
| Selling, general and administrative expenses | 25,843 |  |  | 21,767 |  |  | 51,001 |  |  | 43,243 |  |
| Research and development expenses | 4,289 |  |  | 2,746 |  |  | 7,556 |  |  | 5,222 |  |
| Amortization of intangible assets | 223 |  |  | — |  |  | 445 |  |  | — |  |
| Operating income | 57,581 |  |  | 58,919 |  |  | 100,352 |  |  | 94,491 |  |
| Other expenses (income): |  |  |  |  |  |  |  |
| Interest income, net | (4,203) |  |  | (3,555) |  |  | (8,468) |  |  | (7,420) |  |
| Income before income taxes | 61,784 |  | 62,474 |  | 108,820 |  | 101,911 |
| Income tax provision | 15,897 |  |  | 16,144 |  |  | 21,543 |  |  | 20,818 |  |
| Net income | $ | 45,887 |  |  | $ | 46,330 |  |  | $ | 87,277 |  |  | $ | 81,093 |  |
| Earnings per share(1): |  |  |  |  |  |  |  |
| Basic | $ | 1.26 |  |  | $ | 1.28 |  |  | $ | 2.40 |  |  | $ | 2.24 |  |
| Diluted | $ | 1.25 |  |  | $ | 1.27 |  |  | $ | 2.39 |  |  | $ | 2.22 |  |
| Weighted average shares(1): |  |  |  |  |  |  |  |
| Basic | 36,429 |  |  | 36,206 |  |  | 36,378 |  |  | 36,159 |  |
| Diluted | 36,584 |  |  | 36,523 |  |  | 36,543 |  |  | 36,489 |  |
| SELECTED FINANCIAL DATA: |  |  |  |  |  |  |  |
| Depreciation and Amortization | $ | 2,182 |  |  | $ | 1,718 |  |  | $ | 4,331 |  |  | $ | 3,473 |  |
| Capital Expenditures | $ | 1,832 |  |  | $ | 4,074 |  |  | $ | 3,861 |  |  | $ | 6,263 |  |
| Dividends Paid | $ | 3,278 |  |  | $ | 3,227 |  |  | $ | 6,513 |  |  | $ | 6,412 |  |

[0000080420-26-000063:8k_2_02:42]
Exhibit 99.1

[0000080420-26-000063:8k_2_02:43]
POWELL INDUSTRIES, INC. & SUBSIDIARIES

[0000080420-26-000063:8k_2_02:44]
CONDENSED CONSOLIDATED BALANCE SHEETS

[0000080420-26-000063:8k_2_02:45]
|  | March 31, 2026 |  | September 30, 2025 |
| (In thousands) |  |
|  | (Unaudited) |  |  |
| Assets: |  |  |  |
| Cash, cash equivalents and short-term investments | $ | 544,889 |  |  | $ | 475,527 |  |
| All other current assets | 463,497 |  |  | 456,189 |  |
| Property, plant and equipment, net | 111,822 |  |  | 111,049 |  |
| Long-term assets | 59,831 |  |  | 66,219 |  |
| Total assets | $ | 1,180,039 |  |  | $ | 1,108,984 |  |
| Liabilities and equity: |  |  |  |
| Current liabilities | $ | 447,280 |  |  | $ | 446,387 |  |
| Deferred and other long-term liabilities | 23,690 |  |  | 21,827 |  |
| Stockholders’ equity | 709,069 |  |  | 640,770 |  |
| Total liabilities and stockholders’ equity | $ | 1,180,039 |  |  | $ | 1,108,984 |  |
| SELECTED FINANCIAL DATA: |  |  |  |
| Working capital(5) | $ | 561,106 |  |  | $ | 485,329 |  |

[0000080420-26-000063:8k_2_02:46]
(1)On April 2, 2026, the Company effected a three-for-one forward split of its common stock (the “Stock Split”). Share and per-share amounts disclosed for all periods have been retroactively adjusted to reflect the effect of the Stock Split.

[0000080420-26-000063:8k_2_02:47]
(2)New orders (bookings) represent the estimated value of contracts added to existing backlog (unsatisfied performance obligations).

[0000080420-26-000063:8k_2_02:48]
(3)The amounts recorded in backlog may not be a reliable indicator of our future operating results and may not be indicative of continuing revenue performance over future fiscal quarters or years primarily due to unexpected contract adjustments, cancellations or scope reductions.

[0000080420-26-000063:8k_2_02:49]
(4)A mega order is defined as an order with a contract value exceeding $50 million.

[0000080420-26-000063:8k_2_02:50]
(5)Working capital is equal to current assets (including cash and short-term investments) minus current liabilities.
