# POWL notes — 0000080420-26-000070


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureAndSignificantAccountingPoliciesTextBlock

[0000080420-26-000070:notes:1]
[same as prior period, unchanged from 0000080420-26-000015:notes:1]

[0000080420-26-000070:notes:2]
[same as prior period, unchanged from 0000080420-26-000015:notes:2]

[0000080420-26-000070:notes:3]
[same as prior period, unchanged from 0000080420-26-000015:notes:3]

[0000080420-26-000070:notes:4]
[same as prior period, unchanged from 0000080420-26-000015:notes:4]

[0000080420-26-000070:notes:5]
[same as prior period, unchanged from 0000080420-26-000015:notes:5]

[0000080420-26-000070:notes:6]
[same as prior period, unchanged from 0000080420-26-000015:notes:6]

[0000080420-26-000070:notes:7]
[same as prior period, unchanged from 0000080420-26-000015:notes:7]

[0000080420-26-000070:notes:8]
[same as prior period, unchanged from 0000080420-26-000015:notes:8]

[0000080420-26-000070:notes:9]
[same as prior period, unchanged from 0000080420-26-000015:notes:9]

[0000080420-26-000070:notes:10]
[same as prior period, unchanged from 0000080420-26-000015:notes:10]

[0000080420-26-000070:notes:11]
Common Stock Split

[0000080420-26-000070:notes:12]
On March 31, 2026, the Company’s Board of Directors adopted an amendment to the Company’s Amended and Restated Certificate of Incorporation to proportionately increase the number of shares of the Company’s authorized common stock from 30,000,000 to 90,000,000 in connection with a forward stock split.

[0000080420-26-000070:notes:13]
On April 2, 2026, the Company effected a three-for-one forward split of its common stock and proportionately increased the number of shares of authorized common stock from 30,000,000 to 90,000,000 (the Stock Split). Each shareholder of record as of the close of trading on March 20, 2026 (the Record Date) received, after the close of trading on April 2, 2026, two additional shares for every one share held on the Record Date. The shares of common stock retain a par value of $0.01 per share. Trading began on a split-adjusted basis at market open on April 6, 2026.

[0000080420-26-000070:notes:14]
Share and per share amounts included in the accompanying consolidated financial statements and applicable disclosures  throughout this Quarterly Report on Form 10-Q have been retroactively adjusted to reflect the Stock Split.

[0000080420-26-000070:notes:15]
[same as prior period, unchanged from 0000080420-26-000015:notes:13]

[0000080420-26-000070:notes:16]
In December 2023, the FASB issued ASU 2023-09, Improvements to Income Tax Disclosures, which enhances the transparency of income tax disclosures. It requires greater disaggregation of information in the tax rate reconciliation and income taxes paid disaggregated by jurisdiction. This ASU is effective for fiscal years beginning after December 15, 2024, and should be applied on a prospective basis. Retrospective application and early adoption were permitted. We are currently evaluating the impacts of the new standard.

[0000080420-26-000070:notes:17]
In November 2024, the FASB issued ASU No. 2024-03, Reporting Comprehensive Income – Expense Disaggregation Disclosures, which requires additional qualitative and quantitative information about specific expense categories in the notes to financial statements for both interim and annual reporting periods. In January 2025, the FASB further clarified the effective date for interim reporting periods. This ASU is effective for fiscal years beginning after December 15, 2026 and interim periods within those fiscal years beginning after December 15, 2027, with early adoption permitted. We are currently evaluating the impacts of the new standard.


## us-gaap:EarningsPerShareTextBlock

[0000080420-26-000070:notes:18]
Earnings Per Share
We compute basic earnings per share by dividing net income by the weighted average number of common shares outstanding during the period. Diluted earnings per common and potential common share include the weighted average of additional shares associated with the incremental effect of dilutive restricted stock and restricted stock units. Outstanding share and per-share amounts disclosed for all periods below have been retroactively adjusted to reflect the effect of the Stock Split.

[0000080420-26-000070:notes:19]
The following table reconciles basic and diluted weighted average shares used in the computation of earnings per share (in thousands, except per share data), as adjusted for the Stock Split:

[0000080420-26-000070:notes:20]
|  | Three months ended March 31, |  | Six months ended March 31, |
|  | 2026 |  | 2025 |  | 2026 |  | 2025 |
| Numerator: |  |  |  |  |  |  |  |
| Net income | $ | 45,887 |  |  | $ | 46,330 |  |  | $ | 87,277 |  |  | $ | 81,093 |  |
| Denominator: |  |  |  |  |  |  |  |
| Weighted average basic shares | 36,429 |  |  | 36,206 |  |  | 36,378 |  |  | 36,159 |  |
| Dilutive effect of restricted stock and restricted stock units | 155 |  |  | 317 |  |  | 165 |  |  | 330 |  |
| Weighted average diluted shares | 36,584 |  |  | 36,523 |  |  | 36,543 |  |  | 36,489 |  |
| Earnings per share: |  |  |  |  |  |  |  |
| Basic | $ | 1.26 |  |  | $ | 1.28 |  |  | $ | 2.40 |  |  | $ | 2.24 |  |
| Diluted | $ | 1.25 |  |  | $ | 1.27 |  |  | $ | 2.39 |  |  | $ | 2.22 |  |


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0000080420-26-000070:notes:21]
[same as prior period, unchanged from 0000080420-26-000015:notes:19]

[0000080420-26-000070:notes:22]
[same as prior period, unchanged from 0000080420-26-000015:notes:20]

[0000080420-26-000070:notes:23]
|  | March 31, 2026 |  | September 30, 2025 |
| Raw materials, parts and sub-assemblies | $ | 92,881 |  |  | $ | 90,743 |  |
| Work-in-progress | 2,057 |  |  | 2,222 |  |
| Provision for excess and obsolete inventories | (8,634) |  |  | (8,246) |  |
| Total inventories | $ | 86,304 |  |  | $ | 84,719 |  |

[0000080420-26-000070:notes:24]
[same as prior period, unchanged from 0000080420-26-000015:notes:22]

[0000080420-26-000070:notes:25]
[same as prior period, unchanged from 0000080420-26-000015:notes:23]

[0000080420-26-000070:notes:26]
|  | March 31, 2026 |  | September 30, 2025 |  |  |  |  |
| Land | $ | 24,387 |  |  | $ | 24,436 |  |  |  |  |  |
| Buildings and improvements | 133,187 |  |  | 133,455 |  |  |  |  |  |
| Machinery and equipment | 100,534 |  |  | 99,840 |  |  |  |  |  |
| Furniture and fixtures | 3,530 |  |  | 3,056 |  |  |  |  |  |
| Construction in process | 5,728 |  |  | 2,110 |  |  |  |  |  |
|  | $ | 267,366 |  |  | $ | 262,897 |  |  |  |  |  |
| Less: Accumulated depreciation | (155,544) |  |  | (151,848) |  |  |  |  |  |
| Total property, plant and equipment, net | $ | 111,822 |  |  | $ | 111,049 |  |  |  |  |  |

[0000080420-26-000070:notes:27]
There were no assets under finance lease as of March 31, 2026 or September 30, 2025.

[0000080420-26-000070:notes:28]
[same as prior period, unchanged from 0000080420-26-000015:notes:26]

[0000080420-26-000070:notes:29]
[same as prior period, unchanged from 0000080420-26-000015:notes:27]

[0000080420-26-000070:notes:30]
|  | Three months ended March 31, |  | Six months ended March 31, |
|  | 2026 |  | 2025 |  | 2026 |  | 2025 |
| Balance at beginning of period | $ | 6,676 |  |  | $ | 6,106 |  |  | $ | 6,356 |  |  | $ | 5,822 |  |
| Increase to warranty expense | 1,694 |  |  | 1,357 |  |  | 3,663 |  |  | 2,854 |  |
| Deduction for warranty charges | (1,710) |  |  | (1,192) |  |  | (3,376) |  |  | (2,341) |  |
| Change due to foreign currency translation | (23) |  |  | 13 |  |  | (6) |  |  | (51) |  |
| Balance at end of period | $ | 6,637 |  |  | $ | 6,284 |  |  | $ | 6,637 |  |  | $ | 6,284 |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0000080420-26-000070:notes:31]
[same as prior period, unchanged from 0000080420-26-000015:notes:29]

[0000080420-26-000070:notes:32]
[same as prior period, unchanged from 0000080420-26-000015:notes:30]

[0000080420-26-000070:notes:33]
[same as prior period, unchanged from 0000080420-26-000015:notes:31]

[0000080420-26-000070:notes:34]
[same as prior period, unchanged from 0000080420-26-000015:notes:32]

[0000080420-26-000070:notes:35]
We also have contracts to provide field service inspection, installation, commissioning, modification, and repair services, as well as retrofit and retrofill components for existing systems. If the service contract terms give us the right to invoice the customer for an amount that corresponds directly with the value of our performance completed to date (i.e., a service contract in which we bill a fixed amount for each hour of service provided), then we recognize revenue over time in each reporting period corresponding to the amount that we have the right to invoice. Our performance obligations are satisfied as the work progresses. Revenues from our custom-engineered products and value-added services transferred to customers over time accounted for approximately 95% of revenues for both the three and six months ended March 31, 2026, 95% of revenues for the three months ended March 31, 2025, and 96% of revenues for the six months ended March 31, 2025.

[0000080420-26-000070:notes:36]
We also have sales orders for spare parts and replacement circuit breakers for switchgear that are obsolete or that are no longer produced by the original manufacturer. Revenues from these sales orders are recognized at the time we fulfill our performance obligation to the customer, which is typically upon shipment and represented approximately 5% of revenues for both the three and six months ended March 31, 2026, 5% of revenues for the three months ended March 31, 2025, and 4% of revenues for the six months ended March 31, 2025.

[0000080420-26-000070:notes:37]
[same as prior period, unchanged from 0000080420-26-000015:notes:35]

[0000080420-26-000070:notes:38]
[same as prior period, unchanged from 0000080420-26-000015:notes:36]

[0000080420-26-000070:notes:39]
[same as prior period, unchanged from 0000080420-26-000015:notes:37]

[0000080420-26-000070:notes:40]
[same as prior period, unchanged from 0000080420-26-000015:notes:38]

[0000080420-26-000070:notes:41]
Remaining unsatisfied performance obligations, which we refer to as backlog, represent the estimated transaction price for goods and services for which we have a material right, but work has not yet been performed. As of March 31, 2026, we had backlog of $1.8 billion, of which approximately $1.1 billion is expected to be recognized as revenue within the next twelve months. Backlog may not be indicative of future operating results as orders may be cancelled or modified by our customers. Our backlog does not include service and maintenance-type contracts for which we have the right to invoice as services are performed.

[0000080420-26-000070:notes:42]
[same as prior period, unchanged from 0000080420-26-000015:notes:40]

[0000080420-26-000070:notes:43]
Actual revenues and project costs may vary from previous estimates due to changes in a variety of factors. The cost estimation process is based on the professional knowledge and experience of our engineers, project managers and financial professionals. Factors that are considered in estimating the work to be completed and ultimate contract recovery include the availability and productivity of labor, the nature and complexity of the work to be performed, the availability of materials, and the effect of any delays on our project performance. We periodically review our job performance, job conditions, estimated profitability and final contract settlements, including our estimate of total costs and make revisions to costs and income in the period in which the revisions are probable and reasonably estimable. We bear the risk of cost overruns in most of our contracts, which may result in

[0000080420-26-000070:notes:44]
reduced profits. Whenever revisions of estimated contract costs and contract values indicate that the contract costs will exceed estimated revenues, thus creating a loss, a provision for the total estimated loss is recorded in that period.

[0000080420-26-000070:notes:45]
For the six months ended March 31, 2026 and 2025, our operating results were positively impacted by $14.2 million and $8.8 million, respectively, as a result of net changes in contract estimates related to projects in progress at the beginning of the respective period. These changes in estimates resulted primarily from favorable project execution, reduced cost estimates and negotiations of variable consideration, discussed below, as well as revenue recognized from project cancellations and other changes in facts and circumstances during these periods. Gross unfavorable changes in contract estimates were immaterial for both the six months ended March 31, 2026 and 2025.

[0000080420-26-000070:notes:46]
[same as prior period, unchanged from 0000080420-26-000015:notes:43]

[0000080420-26-000070:notes:47]
[same as prior period, unchanged from 0000080420-26-000015:notes:44]

[0000080420-26-000070:notes:48]
[same as prior period, unchanged from 0000080420-26-000015:notes:45]

[0000080420-26-000070:notes:49]
[same as prior period, unchanged from 0000080420-26-000015:notes:46]

[0000080420-26-000070:notes:50]
[same as prior period, unchanged from 0000080420-26-000015:notes:47]

[0000080420-26-000070:notes:51]
[same as prior period, unchanged from 0000080420-26-000015:notes:48]

[0000080420-26-000070:notes:52]
[same as prior period, unchanged from 0000080420-26-000015:notes:49]

[0000080420-26-000070:notes:53]
[same as prior period, unchanged from 0000080420-26-000015:notes:50]

[0000080420-26-000070:notes:54]
[same as prior period, unchanged from 0000080420-26-000015:notes:51]

[0000080420-26-000070:notes:55]
Contract assets and liabilities as of March 31, 2026 and September 30, 2025 are summarized below (in thousands):

[0000080420-26-000070:notes:56]
|  | March 31, 2026 |  | September 30, 2025 |
| Contract assets | $ | 113,297 |  |  | $ | 136,679 |  |
| Contract liabilities | (314,506) |  |  | (297,949) |  |
| Net contract liability | $ | (201,209) |  |  | $ | (161,270) |  |

[0000080420-26-000070:notes:57]
Our net contract billing position remained a net liability at both March 31, 2026 and September 30, 2025, primarily due to favorable contract billing milestones. We typically allocate a significant percentage of the progress billing to the early stages of the contract. To determine the amount of revenue recognized during the period from contract liabilities, we first allocate revenue to the individual contract liability balance outstanding at the beginning of the period until the revenue exceeds that balance. During the six months ended March 31, 2026, we recognized revenue of $204.3 million that was related to contract liabilities outstanding at September 30, 2025.

[0000080420-26-000070:notes:58]
The timing of our invoice process is typically dependent on the completion of certain milestones and contract terms and is subject to agreement by our customer. Payment is typically expected within 30 days of invoice. Any uncollected invoiced

[0000080420-26-000070:notes:59]
amounts for our performance obligations recognized over time, including contract retentions, are recorded as accounts receivable in the Condensed Consolidated Balance Sheets. Certain contracts allow customers to withhold a small percentage of billings pursuant to retainage provisions, and such amounts are generally due upon completion of the contract and acceptance of the project by the customer. Based on our experience in recent years, the majority of these retainage balances are expected to be collected within approximately twelve months. As of March 31, 2026 and September 30, 2025, we had retention amounts of $6.0 million and $8.1 million, respectively. Of the retained amount at March 31, 2026, $5.8 million is expected to be collected in the next twelve months and is recorded in accounts receivable. The remaining $0.2 million is recorded in other assets.

[0000080420-26-000070:notes:60]
[same as prior period, unchanged from 0000080420-26-000015:notes:57]

[0000080420-26-000070:notes:61]
The following tables present our disaggregated revenue by geographic destination and market sector for the three and six months ended March 31, 2026 and 2025 (in thousands):

[0000080420-26-000070:notes:62]
|  | Three months ended March 31, |  | Six months ended March 31, |
|  | 2026 |  | 2025 |  | 2026 |  | 2025 |
| United States | $ | 232,272 |  |  | $ | 227,834 |  |  | $ | 427,150 |  |  | $ | 425,606 |  |
| Canada | 29,823 |  |  | 33,970 |  |  | 62,282 |  |  | 65,664 |  |
| Middle East and Africa | 13,618 |  |  | 8,282 |  |  | 23,490 |  |  | 12,840 |  |
| Europe | 10,478 |  |  | 5,897 |  |  | 18,704 |  |  | 11,425 |  |
| Asia/Pacific | 9,840 |  |  | 1,646 |  |  | 15,143 |  |  | 3,226 |  |
| Mexico, Central and South America | 584 |  |  | 1,002 |  |  | 1,030 |  |  | 1,301 |  |
| Total revenues by geographic destination | $ | 296,615 |  |  | $ | 278,631 |  |  | $ | 547,799 |  |  | $ | 520,062 |  |

[0000080420-26-000070:notes:63]
|  | Three months ended March 31, |  | Six months ended March 31, |
|  | 2026 |  | 2025 |  | 2026 |  | 2025 |
| Oil and gas (excludes petrochemical) | $ | 112,744 |  |  | $ | 101,167 |  |  | $ | 210,633 |  |  | $ | 196,846 |  |
| Electric utility | 80,479 |  |  | 70,339 |  |  | 149,752 |  |  | 121,579 |  |
| Commercial and other industrial | 54,446 |  |  | 40,369 |  |  | 95,071 |  |  | 84,669 |  |
| Petrochemical | 27,551 |  |  | 43,704 |  |  | 50,329 |  |  | 76,887 |  |
| Light rail traction power | 9,048 |  |  | 10,008 |  |  | 17,662 |  |  | 18,236 |  |
| All others | 12,347 |  |  | 13,044 |  |  | 24,352 |  |  | 21,845 |  |
| Total revenues by market sector | $ | 296,615 |  |  | $ | 278,631 |  |  | $ | 547,799 |  |  | $ | 520,062 |  |


## us-gaap:RevenueFromContractWithCustomerPolicyTextBlock

[0000080420-26-000070:notes:64]
[same as prior period, unchanged from 0000080420-26-000015:notes:61]

[0000080420-26-000070:notes:65]
A performance obligation is a promise in a contract or with a customer to transfer a distinct good or service. A contract’s transaction price is allocated to each distinct performance obligation and recognized as revenue as the performance obligations are satisfied. To determine the proper revenue recognition for contracts, we evaluate whether a contract should be accounted for as more than one performance obligation or, less commonly, whether two or more contracts should be combined and accounted for as one performance obligation. This evaluation of performance obligations requires significant judgment. The majority of our contracts have a single performance obligation where multiple engineered products and services are combined into a single custom-engineered solution. Our contracts include a standard one-year assurance warranty. Occasionally, we provide service-type warranties that will extend the warranty period. These extended warranties qualify as a separate performance obligation, and revenue is deferred and recognized over the warranty period. If we determine during the evaluation of the contract that there are multiple performance obligations, we allocate the transaction price to each performance obligation using our best estimate of the standalone selling price of each distinct good or service in the contract. 
Remaining unsatisfied performance obligations, which we refer to as backlog, represent the estimated transaction price for goods and services for which we have a material right, but work has not yet been performed. As of March 31, 2026, we had backlog of $1.8 billion, of which approximately $1.1 billion is expected to be recognized as revenue within the next twelve months. Backlog may not be indicative of future operating results as orders may be cancelled or modified by our customers. Our backlog does not include service and maintenance-type contracts for which we have the right to invoice as services are performed.
Contract Estimates

[0000080420-26-000070:notes:66]
Contract liabilities typically represent advance payments from contractual billing milestones and billings in excess of revenue recognized. It is unusual to have advanced milestone payments with a term greater than one year, which could represent a financing component of the contract.  
Our contract assets and liabilities are reported in a net position on a contract-by-contract basis at the end of each reporting period and are generally classified as current.
The timing of our invoice process is typically dependent on the completion of certain milestones and contract terms and is subject to agreement by our customer. Payment is typically expected within 30 days of invoice. Any uncollected invoiced 
amounts for our performance obligations recognized over time, including contract retentions, are recorded as accounts receivable in the Condensed Consolidated Balance Sheets. Certain contracts allow customers to withhold a small percentage of billings pursuant to retainage provisions, and such amounts are generally due upon completion of the contract and acceptance of the project by the customer. Based on our experience in recent years, the majority of these retainage balances are expected to be collected within approximately twelve months.


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0000080420-26-000070:notes:67]
Goodwill and Other Intangible Assets
Our intangible assets include goodwill of $6.0 million, which is not being amortized, and other intangible assets of $5.6 million being amortized over their estimated useful lives. No impairment expense has been recorded for the last three fiscal years.

[0000080420-26-000070:notes:68]
[same as prior period, unchanged from 0000080420-26-000015:notes:65]

[0000080420-26-000070:notes:69]
The changes in the carrying amount of goodwill for the six months ended March 31, 2026 for our single reporting segment are as follows (in thousands):

[0000080420-26-000070:notes:70]
|  |  | Total |
| Balance as of September 30, 2025 |  | $ | 6,125 |  |
| Foreign currency translation adjustment |  | (86) |  |
| Balance as of March 31, 2026 |  | $ | 6,039 |  |

[0000080420-26-000070:notes:71]
[same as prior period, unchanged from 0000080420-26-000015:notes:68]

[0000080420-26-000070:notes:72]
Intangible asset balances, subject to amortization, at March 31, 2026 and September 30, 2025 consisted of the following (in thousands):

[0000080420-26-000070:notes:73]
|  | March 31, 2026 |
|  | Weighted Average Remaining Useful Lives in Years |  | GrossCarryingValue |  | AccumulatedAmortization |  | NetCarryingValue |
| Customer relationships | 12 |  | $ | 2,165 |  |  | $ | (113) |  |  | $ | 2,052 |  |
| Technologies | 5 |  | 3,467 |  |  | (371) |  |  | 3,096 |  |
| Trademarks | 10 |  | 467 |  |  | (30) |  |  | 437 |  |
| Order backlog | 1 |  | 54 |  |  | (33) |  |  | 21 |  |
| Total intangible assets |  |  | $ | 6,153 |  |  | $ | (547) |  |  | $ | 5,606 |  |
|  | September 30, 2025 |
|  | Weighted Average Remaining Useful Lives in Years |  | GrossCarryingValue |  | AccumulatedAmortization |  | NetCarryingValue |
| Customer relationships | 12 |  | $ | 2,202 |  |  | $ | (23) |  |  | $ | 2,179 |  |
| Technologies | 5 |  | 3,518 |  |  | (76) |  |  | 3,442 |  |
| Trademarks | 10 |  | 475 |  |  | (6) |  |  | 469 |  |
| Order backlog | 1 |  | 55 |  |  | (7) |  |  | 48 |  |
| Total intangible assets |  |  | $ | 6,250 |  |  | $ | (112) |  |  | $ | 6,138 |  |

[0000080420-26-000070:notes:74]
[same as prior period, unchanged from 0000080420-26-000015:notes:71]

[0000080420-26-000070:notes:75]
As of March 31, 2026, the estimated future amortization expense of intangible assets is as follows (in thousands):

[0000080420-26-000070:notes:76]
| Remainder of 2026 | $ | 431 |  |
| 2027 | 921 |  |
| 2028 | 921 |  |
| 2029 | 921 |  |
| 2030 | 846 |  |
| Thereafter | 1,566 |  |
| Total | $ | 5,606 |  |


## us-gaap:LongTermDebtTextBlock

[0000080420-26-000070:notes:77]
Long-Term Debt
U.S. Revolver

[0000080420-26-000070:notes:78]
We have a credit agreement with Bank of America, N.A. and Texas Capital Bank with an aggregate commitment of $150.0 million, consisting of $100.0 million committed by Bank of America and $50.0 million committed by Texas Capital Bank (the U.S. Revolver). The U.S. Revolver has an expiration date of October 4, 2028.

[0000080420-26-000070:notes:79]
As of March 31, 2026, there were no amounts borrowed under the U.S. Revolver, and letters of credit outstanding were $78.7 million. There was $71.3 million available for the issuance of letters of credit and borrowings under the U.S. Revolver as of March 31, 2026.

[0000080420-26-000070:notes:80]
As of March 31, 2026, we were in compliance with all of the financial covenants of the U.S. Revolver.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0000080420-26-000070:notes:81]
Commitments and Contingencies
Letters of Credit, Bank Guarantees and Bonds

[0000080420-26-000070:notes:82]
Certain customers require us to post letters of credit, bank guarantees or surety bonds. These security instruments assure that we will perform under the terms of our contract. In the event of default, the counterparty may demand payment from the bank under a letter of credit or bank guarantee, or performance by the surety under a bond. To date, there have been no significant draws or claims related to security instruments for the periods reported. We were contingently liable for letters of credit of $78.7 million as of March 31, 2026. We also had surety bonds totaling $432.8 million that were outstanding, with additional bonding capacity of $767.2 million available, at March 31, 2026. We have strong surety relationships; however, a change in market conditions or the sureties’ assessment of our financial position could cause the sureties to require cash collateralization for undischarged liabilities under the bonds.

[0000080420-26-000070:notes:83]
We have a $19.8 million facility agreement (Facility Agreement) between Powell (UK) Limited and a large international bank that provides Powell (UK) Limited the ability to enter into bank guarantees as well as forward exchange contracts and currency options. At March 31, 2026, we had outstanding guarantees totaling $6.4 million, with an additional capacity of $13.4 million available under this Facility Agreement. The Facility Agreement provides for customary events of default and carries cross-default provisions with the U.S. Revolver. If an event of default (as defined in the Facility Agreement) occurs and is continuing, per the terms and subject to the conditions set forth therein, obligations outstanding under the Facility Agreement may be accelerated and declared immediately due and payable. Additionally, we are required to maintain cash collateral for guarantees greater than two years. As of March 31, 2026, we were in compliance with all of the financial covenants of the Facility Agreement.

[0000080420-26-000070:notes:84]
Litigation

[0000080420-26-000070:notes:85]
We are involved in various legal proceedings, claims and other disputes arising from our commercial operations, projects, employees and other matters which, in general, are subject to uncertainties and in which the outcomes are not predictable. Although we can give no assurances about the resolution of pending claims, litigation or other disputes, and the effect such outcomes may have on us, management believes that any ultimate liability resulting from the outcome of such proceedings, to the extent not otherwise provided or covered by insurance, will not have a material adverse effect on our consolidated financial position, or results of operations or liquidity.

[0000080420-26-000070:notes:86]
Liquidated Damages

[0000080420-26-000070:notes:87]
Certain of our customer contracts have schedule and performance obligation clauses that, if we fail to meet them, could require us to pay liquidated damages. Each individual contract defines the conditions under which the customer may make a claim against us. As of March 31, 2026, certain contracts had a probable exposure to liquidated damages claims of $4.4 million, which could possibly increase to $7.5 million under certain circumstances. Based on our actual or projected failure to meet these various contractual commitments, $3.8 million has been recorded as a reduction to revenue. We will attempt to obtain change orders, contract extensions or accelerate project completion, which may resolve the potential for any unrecorded liquidated damages claims. Should we fail to achieve relief on some or all of these contractual obligations, we could be required to pay additional liquidated damages, which could negatively impact our future operating results.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0000080420-26-000070:notes:88]
[same as prior period, unchanged from 0000080420-26-000015:notes:85]

[0000080420-26-000070:notes:89]
[same as prior period, unchanged from 0000080420-26-000015:notes:86]

[0000080420-26-000070:notes:90]
We issue restricted stock units (RSUs) to certain officers and key employees of the Company. The fair value of the RSUs is based on the price of our common stock as reported on the NASDAQ Global Market during a specified period prior to the grant dates. Typically, these grants vest over a three-year period from the date of issuance and are a blend of time-based and performance-based shares. The portion of the grant that is time-based typically vests over a three-year period on each anniversary of the grant date, based on continued employment. The performance-based shares vest based on the three-year revenue growth, earnings and safety performance of the Company following the grant date. At March 31, 2026, there were 166,431 RSUs outstanding, as adjusted for the Stock Split. The RSUs do not have voting rights but do receive dividend equivalents upon vesting, which are accrued quarterly. Additionally, the shares of common stock underlying the RSUs are not considered issued and outstanding until vested and common stock is issued.

[0000080420-26-000070:notes:91]
Total RSU activity (number of shares), as adjusted for the Stock Split, for the six months ended March 31, 2026 is summarized below:

[0000080420-26-000070:notes:92]
|  | Number ofRestrictedStockUnits |  | WeightedAverageGrant ValuePer Share |
| Outstanding at September 30, 2025 | 350,658 |  |  | $ | 21.60 |  |
| Granted | 59,085 |  |  | 95.75 |  |
| Vested | (243,312) |  |  | 12.74 |  |
| Forfeited/canceled | — |  |  | — |  |
| Outstanding at March 31, 2026 | 166,431 |  |  | $ | 55.84 |  |

[0000080420-26-000070:notes:93]
During the six months ended March 31, 2026 and 2025, we recorded compensation expense of $2.5 million and $2.2 million, respectively, related to the RSUs.

[0000080420-26-000070:notes:94]
Restricted Stock
Each year, every non-employee director receives restricted shares of the Company’s common stock with a grant-date value of $0.1 million. The number of granted shares is calculated by dividing the $0.1 million by the average of high and low prices of our common stock on the grant date. The shares shall vest on the earlier of the grant anniversary date or the date of the next annual meeting of stockholders, whichever occurs first. In February 2026, 4,200 shares of restricted stock were issued to our non-employee directors at a price of $184.83 per share, as adjusted for the Stock Split. During both the six months ended March 31, 2026 and 2025, we recorded compensation expense of $0.4 million related to restricted stock.


## us-gaap:FairValueDisclosuresTextBlock

[0000080420-26-000070:notes:95]
[same as prior period, unchanged from 0000080420-26-000015:notes:92]

[0000080420-26-000070:notes:96]
[same as prior period, unchanged from 0000080420-26-000015:notes:93]

[0000080420-26-000070:notes:97]
[same as prior period, unchanged from 0000080420-26-000015:notes:94]

[0000080420-26-000070:notes:98]
[same as prior period, unchanged from 0000080420-26-000015:notes:95]

[0000080420-26-000070:notes:99]
[same as prior period, unchanged from 0000080420-26-000015:notes:96]

[0000080420-26-000070:notes:100]
[same as prior period, unchanged from 0000080420-26-000015:notes:97]

[0000080420-26-000070:notes:101]
The following table summarizes the fair value of our assets and liabilities that were accounted for at fair value on a recurring basis as of March 31, 2026 (in thousands):

[0000080420-26-000070:notes:102]
|  | Fair Value Measurements at March 31, 2026 |
|  | Quoted Prices inActive Markets forIdentical Assets(Level 1) |  | Significant OtherObservableInputs(Level 2) |  | SignificantUnobservableInputs(Level 3) |  | Fair Value at March 31,2026 |
| Assets: |  |  |  |  |  |  |  |
| Cash and cash equivalents | $ | 537,712 |  |  | $ | — |  |  | $ | — |  |  | $ | 537,712 |  |
| Short-term investments | 7,177 |  |  | — |  |  | — |  |  | 7,177 |  |
| Rabbi trust assets | — |  |  | 15,050 |  |  | — |  |  | 15,050 |  |
| Liabilities: |  |  |  |  |  |  |  |
| Deferred compensation | — |  |  | 14,831 |  |  | — |  |  | 14,831 |  |
| Contingent future payments related to the acquisition of Remsdaq | — |  |  | — |  |  | 2,574 |  |  | 2,574 |  |

[0000080420-26-000070:notes:103]
[same as prior period, unchanged from 0000080420-26-000015:notes:100]

[0000080420-26-000070:notes:104]
[same as prior period, unchanged from 0000080420-26-000015:notes:101]

[0000080420-26-000070:notes:105]
[same as prior period, unchanged from 0000080420-26-000015:notes:102]

[0000080420-26-000070:notes:106]
[same as prior period, unchanged from 0000080420-26-000015:notes:103]

[0000080420-26-000070:notes:107]
[same as prior period, unchanged from 0000080420-26-000015:notes:104]

[0000080420-26-000070:notes:108]
[same as prior period, unchanged from 0000080420-26-000015:notes:105]

[0000080420-26-000070:notes:109]
Contingent future payments related to the acquisition of Remsdaq – The contingent future payments were calculated using a probability outcome model based on internally developed assumptions; accordingly, they are categorized as Level 3 in the fair value measurement hierarchy.

[0000080420-26-000070:notes:110]
There were no transfers between levels within the fair value measurement hierarchy during the quarter ended March 31, 2026.


## us-gaap:LesseeOperatingLeasesTextBlock

[0000080420-26-000070:notes:111]
Leases
Our leases consist primarily of office and warehouse space and construction equipment. All of our future lease obligations are related to non-cancelable operating leases. The following table provides a summary of lease cost components for the three and six months ended March 31, 2026 and 2025, respectively (in thousands):

[0000080420-26-000070:notes:112]
|  |  | Three months ended March 31, |  | Six months ended March 31, |
| Lease Cost |  | 2026 |  | 2025 |  | 2026 |  | 2025 |
| Operating lease cost |  | $ | 299 |  |  | $ | 247 |  |  | $ | 583 |  |  | $ | 445 |  |
| Variable lease cost(1) |  | 48 |  |  | 47 |  |  | 91 |  |  | 81 |  |
| Short-term lease cost(2) |  | 620 |  |  | 668 |  |  | 1,211 |  |  | 1,307 |  |
| Total lease cost |  | $ | 967 |  |  | $ | 962 |  |  | $ | 1,885 |  |  | $ | 1,833 |  |

[0000080420-26-000070:notes:113]
[same as prior period, unchanged from 0000080420-26-000015:notes:112]

[0000080420-26-000070:notes:114]
[same as prior period, unchanged from 0000080420-26-000015:notes:113]

[0000080420-26-000070:notes:115]
We recognize operating lease assets and operating lease liabilities representing the present value of the remaining lease payments for leases with initial terms greater than twelve months. Leases with initial terms of twelve months or less are not recorded in our Condensed Consolidated Balance Sheets. The following table provides a summary of the operating lease assets and operating lease liabilities included in our Condensed Consolidated Balance Sheets as of March 31, 2026 and September 30, 2025, respectively (in thousands):

[0000080420-26-000070:notes:116]
| Operating Leases |  | March 31, 2026 |  | September 30, 2025 |
| Assets: |  |  |  |  |
| Operating lease assets, net |  | $ | 1,955 |  |  | $ | 1,664 |  |
| Liabilities: |  |  |  |  |
| Current operating lease liabilities |  | $ | 880 |  |  | $ | 882 |  |
| Long-term operating lease liabilities |  | 1,075 |  |  | 782 |  |
| Total lease liabilities |  | $ | 1,955 |  |  | $ | 1,664 |  |

[0000080420-26-000070:notes:117]
The following table provides the maturities of our operating lease liabilities as of March 31, 2026 (in thousands):

[0000080420-26-000070:notes:118]
|  |  | Operating Leases |  |  |
| Remainder of 2026 |  | $ | 557 |  |  |  |
| 2027 |  | 877 |  |  |  |
| 2028 |  | 529 |  |  |  |
| 2029 |  | 162 |  |  |  |
| 2030 |  | — |  |  |  |
| Thereafter |  | — |  |  |  |
| Total future minimum lease payments |  | $ | 2,125 |  |  |  |
| Less: present value discount (imputed interest) |  | (170) |  |  |  |
| Present value of lease liabilities |  | $ | 1,955 |  |  |  |

[0000080420-26-000070:notes:119]
The weighted average discount rate as of March 31, 2026 and 2025 were 7.47% and 6.55%, respectively. The weighted average remaining lease term was 2.17 years and 2.34 years, respectively, at March 31, 2026 and 2025.


## us-gaap:SegmentReportingDisclosureTextBlock

[0000080420-26-000070:notes:120]
Segment Information
We manage our business as one reportable operating segment and our revenues are primarily generated from the development, design, manufacturing and servicing of custom-engineered equipment and systems for the distribution, control and monitoring of electrical energy.

[0000080420-26-000070:notes:121]
Our chief operating decision maker (“CODM”) is our chief executive officer. The CODM manages and allocates resources on a total consolidated basis by assessing performance of revenues and earnings before interest and taxes (“EBIT”) using actual-to-actual, actual-to-plan and actual-to-forecast variance analysis. The measure of segment profit and loss regularly provided to the CODM that is most consistent with GAAP is consolidated net income, as presented in our Consolidated Statements of Operations. The CODM does not manage cost components by product, customer type or service type, nor does the CODM regularly receive disaggregated information at this level.

[0000080420-26-000070:notes:122]
For the three and six months ended March 31, 2026 and 2025, the summary of segment net income, including segment expenses, for our single reportable segment were as follows (in thousands):

[0000080420-26-000070:notes:123]
|  | Three months ended March 31, |  | Six months ended March 31, |
|  | 2026 |  | 2025 |  | 2026 |  | 2025 |
| Revenues | $ | 296,615 |  |  | $ | 278,631 |  |  | $ | 547,799 |  |  | $ | 520,062 |  |
| Segment operating expenses: |  |  |  |  |  |  |  |
| Cost of goods sold | 208,679 |  |  | 195,199 |  |  | 388,445 |  |  | 377,106 |  |
| General and administrative expenses | 17,646 |  |  | 14,624 |  |  | 34,938 |  |  | 29,475 |  |
| Sales and marketing expenses | 8,365 |  |  | 6,933 |  |  | 16,110 |  |  | 13,664 |  |
| Research and development expenses | 4,289 |  |  | 2,746 |  |  | 7,556 |  |  | 5,222 |  |
| Amortization | 223 |  |  | — |  |  | 445 |  |  | — |  |
| Realized currency (gain) loss | (168) |  |  | 210 |  |  | (47) |  |  | 104 |  |
| Total segment operating expenses | 239,034 |  |  | 219,712 |  |  | 447,447 |  |  | 425,571 |  |
| Operating income / EBIT | 57,581 |  |  | 58,919 |  |  | 100,352 |  |  | 94,491 |  |
| Interest income, net | (4,203) |  |  | (3,555) |  |  | (8,468) |  |  | (7,420) |  |
| Income tax provision | 15,897 |  |  | 16,144 |  |  | 21,543 |  |  | 20,818 |  |
| Segment net income | $ | 45,887 |  |  | $ | 46,330 |  |  | $ | 87,277 |  |  | $ | 81,093 |  |
| Gross profit | $ | 87,936 |  |  | $ | 83,432 |  |  | $ | 159,354 |  |  | $ | 142,956 |  |

[0000080420-26-000070:notes:124]
Revenues by country represent sales to unaffiliated customers as determined by the ultimate destination of our products and services, summarized for the three and six months ended March 31, 2026 and 2025 (in thousands):

[0000080420-26-000070:notes:125]
|  | Three months ended March 31, |  | Six months ended March 31, |
|  | 2026 |  | 2025 |  | 2026 |  | 2025 |
| United States | $ | 232,272 |  |  | $ | 227,834 |  |  | $ | 427,150 |  |  | $ | 425,606 |  |
| Canada | 29,823 |  |  | 33,970 |  |  | 62,282 |  |  | 65,664 |  |
| Middle East and Africa | 13,618 |  |  | 8,282 |  |  | 23,490 |  |  | 12,840 |  |
| Europe | 10,478 |  |  | 5,897 |  |  | 18,704 |  |  | 11,425 |  |
| Asia/Pacific | 9,840 |  |  | 1,646 |  |  | 15,143 |  |  | 3,226 |  |
| Mexico, Central and South America | 584 |  |  | 1,002 |  |  | 1,030 |  |  | 1,301 |  |
| Total revenues | $ | 296,615 |  |  | $ | 278,631 |  |  | $ | 547,799 |  |  | $ | 520,062 |  |

[0000080420-26-000070:notes:126]
[same as prior period, unchanged from 0000080420-26-000015:notes:129]

[0000080420-26-000070:notes:127]
|  | March 31, 2026 |  | September 30, 2025 |
| Long-lived assets: |  |  |  |
| United States | $ | 72,540 |  |  | $ | 70,699 |  |
| Canada | 32,102 |  |  | 32,744 |  |
| United Kingdom | 7,180 |  |  | 7,606 |  |
| Total | $ | 111,822 |  |  | $ | 111,049 |  |


## us-gaap:IncomeTaxDisclosureTextBlock

[0000080420-26-000070:notes:128]
[same as prior period, unchanged from 0000080420-26-000015:notes:131]

[0000080420-26-000070:notes:129]
|  | Three months ended March 31, |  | Six months ended March 31, |
|  | 2026 |  | 2025 |  | 2026 |  | 2025 |
| Income before income taxes | $ | 61,784 |  |  | $ | 62,474 |  |  | $ | 108,820 |  |  | $ | 101,911 |  |
| Income tax provision | 15,897 |  |  | 16,144 |  |  | 21,543 |  |  | 20,818 |  |
| Net income | $ | 45,887 |  |  | $ | 46,330 |  |  | $ | 87,277 |  |  | $ | 81,093 |  |
| Effective tax rate | 26 | % |  | 26 | % |  | 20 | % |  | 20 | % |

[0000080420-26-000070:notes:130]
Our income tax provision reflects an effective tax rate on pre-tax income of 26% and 20% for the three and six months ended March 31, 2026 and March 31, 2025. The effective tax rates for each period were favorably impacted by the estimated Research and Development (R&D) Tax Credit, which was offset by the tax expense related to certain nondeductible items. In addition, discrete items related to the vesting of RSUs recorded in the first quarters of Fiscal 2026 and Fiscal 2025 favorably impacted the effective tax rate for the six months ended March 31, 2026 and March 31, 2025.


## us-gaap:SubsequentEventsTextBlock

[0000080420-26-000070:notes:131]
Subsequent Events
Common Stock Split

[0000080420-26-000070:notes:132]
On April 2, 2026, the Company effected a three-for-one forward split of its common stock and proportionately increased the number of shares of authorized common stock from 30,000,000 to 90,000,000. Each shareholder of record as of the close of trading on March 20, 2026 received, after the close of trading on April 2, 2026, two additional shares for every one share held on the Record Date. The shares of common stock retain a par value of $0.01 per share. Trading began on a split-adjusted basis at market open on April 6, 2026. See Note A. Overview and Summary of Significant Accounting Policies for addition information regarding the Common Stock Split.

[0000080420-26-000070:notes:133]
Quarterly Dividend Declared

[0000080420-26-000070:notes:134]
On May 5, 2026, our Board of Directors declared a quarterly cash dividend on our common stock in the amount of $0.09 per share. The dividend is payable on June 17, 2026 to shareholders of record at the close of business on May 20, 2026.


## ecd:MtrlTermsOfTrdArrTextBlock

[0000080420-26-000070:notes:135]
On February 11, 2026, Richard E. Williams, Director of the Company, adopted a “Rule 10b5-1 trading arrangement,” as the term is defined in Item 408(a) of Regulation S-K, for the sale of up to 7,500 shares of the Company’s common stock as adjusted for the Stock Split, subject to certain conditions, from May 14, 2026 through December 31, 2026.

[0000080420-26-000070:notes:136]
On February 27, 2026, Mohit Singh, Director of the Company, adopted a “Rule 10b5-1 trading arrangement,” as the term is defined in Item 408(a) of Regulation S-K, for the sale of up to 1,350 shares of the Company’s common stock as adjusted for the Stock Split, subject to certain conditions, from May 28, 2026 through February 26, 2027.
