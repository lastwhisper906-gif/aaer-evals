# POWL MD&A — 0000080420-21-000045


## mdna

[0000080420-21-000045:mdna:1]
Item 7. Management’s Discussion and Analysis of Financial Condition and Results of Operations

[0000080420-21-000045:mdna:2]
Overview

[0000080420-21-000045:mdna:3]
We develop, design, manufacture and service custom-engineered equipment and systems which (1) distribute, control and monitor the flow of electrical energy and (2) provide protection to motors, transformers and other electrically powered equipment. We are headquartered in Houston, Texas, and serve the oil and gas and petrochemical markets, which includes onshore and offshore production, LNG facilities and terminals, pipelines, refineries and petrochemical plants. Additional markets include electric utility and light rail traction power as well as mining and metals, pulp and paper and other municipal, commercial and industrial markets. Revenues and costs are primarily related to custom engineered-to-order equipment and systems and are accounted for under percentage-of-completion accounting, which precludes us from providing detailed price and volume information. Our backlog includes various projects that typically take a number of months to produce.

[0000080420-21-000045:mdna:4]
The markets in which we participate are capital-intensive and cyclical in nature. Cyclicality is predominantly driven by customer demand, global economic conditions and anticipated environmental, safety or regulatory changes that affect the manner in which our customers proceed with capital investments. Our customers analyze various factors, including the demand and price for oil, gas and electrical energy, the overall economic and financial environment, governmental budgets, regulatory actions and environmental concerns. These factors influence the release of new capital projects by our customers, which are traditionally awarded in competitive bid situations. Scheduling of projects is matched to the customer requirements, and projects typically take a number of months to produce. Schedules may change during the course of any particular project, and our operating results can, therefore, be impacted by factors outside of our control.

[0000080420-21-000045:mdna:5]
Within the industrial sector, specifically oil, gas and petrochemical, the demand for our electrical distribution solutions is very cyclical and closely correlated to the level of capital expenditures of our end-user customers as well as prevailing global economic conditions.

[0000080420-21-000045:mdna:6]
Historically, the combination of a growing global economy, abundant sources of favorably priced natural gas feedstock, and an energy industry focus on transition to natural gas and cleaner-burning fuels drove an increase in capital investment opportunities, specifically across the oil, gas and petrochemical sectors. Some of these opportunities were for natural gas related projects targeting global demand for cleaner-burning fuels. Additionally, projects within the domestic petrochemical sector benefited from the low feedstock prices of natural gas. Specific to natural gas, the business was awarded a substantial contract in the second quarter of Fiscal 2020 that will support the integrated electrical distribution requirements for a large domestic industrial complex and should be substantially completed in Fiscal 2022. We began to experience reduced commercial activity in Fiscal 2020 driven in large part by the uncertainties across our industrial end markets in the U.S. resulting from the COVID-19 pandemic. Considering the long cycle nature of our business, these cyclical conditions may persist into Fiscal 2022.

[0000080420-21-000045:mdna:7]
Impact of the COVID-19 Pandemic and Oil and Gas Commodity Market Volatility on Powell

[0000080420-21-000045:mdna:8]
The COVID-19 pandemic continues to impact global energy markets. This pandemic has negatively impacted demand, which in turn has resulted in considerable volatility across global oil and gas commodity markets. Throughout the pandemic, the demand for our products and services as well as our operations have been negatively impacted, resulting from the associated reduction in oil and gas demand and volatility in commodity prices noted above. As a result, some of our industrial customers are deferring or suspending their planned capital expenditures. Certain of our customers have asked that we delay or cancel our manufacturing on their projects as their operations have been negatively impacted by this pandemic and the reduced oil and gas demand which has resulted in recognition of cancellation fees based on contract terms and the extent of our progress on the projects. We continue to work with our key suppliers who have been impacted by this pandemic to ensure that we are able to meet our customer commitments.

[0000080420-21-000045:mdna:9]
In response to the lower demand across select end markets, we have taken and will continue to take various actions to reduce costs. During Fiscal 2020, we reduced our global workforce and reduced our capital and discretionary spending in response to business conditions. We continued to operate at these lower thresholds throughout Fiscal 2021 and are consistently monitoring macro-economic conditions as we head into Fiscal 2022.

[0000080420-21-000045:mdna:10]
As discussed further under the heading "Outlook" below, it is difficult to predict the economic impact that this pandemic, as well as reduced oil and gas demand and commodity price volatility, may have on our business, results of operations and cash flows going forward.

[0000080420-21-000045:mdna:11]
Results of Operations

[0000080420-21-000045:mdna:12]
Twelve Months Ended September 30, 2021 Compared to Twelve Months Ended September 30, 2020

[0000080420-21-000045:mdna:13]
Revenue and Gross Profit

[0000080420-21-000045:mdna:14]
Revenues decreased by 9%, or $47.9 million, to $470.6 million in Fiscal 2021, due to a decrease in orders as well as project delays and cancellations of potential projects associated with the global economic impact resulting from the COVID-19 pandemic and associated reduction in demand across our industrial end markets. Domestic revenues decreased by 12%, or $46.6 million, to $351.5 million in Fiscal 2021. International revenues decreased by 1%, or $1.4 million, to $119.1 million. Our international revenues include both revenues generated from our international facilities as well as revenues from export projects generated at our domestic facilities.

[0000080420-21-000045:mdna:15]
Revenue from our core oil and gas markets (excluding petrochemical) decreased by 4%, or $7.5 million, to $187.7 million while petrochemical revenue decreased by 53%, or $67.7 million, to $59.0 million in Fiscal 2021 as noted above. Revenue from utility markets increased by 25%, or $22.4 million, to $111.2 million and traction market revenue increased by 39%, or $16.7 million, to $59.1 million in Fiscal 2021. Revenue from all other markets combined decreased by $11.8 million to $53.6 million in Fiscal 2021.

[0000080420-21-000045:mdna:16]
The reduction in revenue led to a reduction in gross profit of 21%, or $19.5 million, in Fiscal 2021. However, gross profit of $75.1 million in Fiscal 2021 benefited from favorable close out gains on certain projects resulting from cost and productivity efficiencies and to a lesser extent from cancellation fees from certain contracts in our North American manufacturing facilities, which was partially offset by international project execution, higher global commodity prices and U.S. factory underutilization. Gross profit as a percentage of revenues decreased to 16% in Fiscal 2021, compared to 18% in Fiscal 2020 as a result of the reduction in revenue noted above.

[0000080420-21-000045:mdna:17]
Selling, General and Administrative Expenses

[0000080420-21-000045:mdna:18]
Selling, general and administrative expenses decreased by 1%, or $0.4 million, to $67.2 million in Fiscal 2021, partially due to the restructuring action taken in Fiscal 2020 as well as lower travel-related costs. Selling, general and administrative expenses, as a percentage of revenues, increased to 14% in Fiscal 2021, compared to 13% in Fiscal 2020, primarily due to the decrease in revenues.

[0000080420-21-000045:mdna:19]
Restructuring and Other, Net

[0000080420-21-000045:mdna:20]
In response to the COVID-19 pandemic, reductions in global oil and gas demand and volatility of commodity prices, we implemented workforce reductions across the business. As a result, we recorded $1.4 million of separation costs during Fiscal 2020.

[0000080420-21-000045:mdna:21]
Other Income

[0000080420-21-000045:mdna:22]
During Fiscal 2020, we recorded other income of $0.5 million related to a death benefit received from our company-owned life insurance policy related to a retired employee.

[0000080420-21-000045:mdna:23]
Income Tax Provision

[0000080420-21-000045:mdna:24]
We recorded an income tax provision of $0.5 million in Fiscal 2021, resulting in an effective tax rate of 42%, compared to an income tax provision of $3.7 million in Fiscal 2020 at an effective tax rate of 18%. In both Fiscal 2021 and Fiscal 2020, the effective tax rate was negatively impacted by our inability to recognize a tax benefit related to losses incurred in various jurisdictions outside of the United States. The effective tax rate was also negatively impacted by the valuation allowances set up against our deferred tax assets in Fiscal 2021 and Fiscal 2020 related to Mexico in the amount of $0.1 million and the U.K. in the amount of $0.5 million. The estimated Research and Development Tax Credit (R&D Tax Credit) as well as the utilization of net operating loss carryforwards in Canada that were fully reserved with a valuation allowance provided a tax benefit for Fiscal 2021 and Fiscal 2020. In Fiscal 2020, we reversed a reserve of $1.7 million resulting from a favorable settlement of an IRS audit and the expiration of statutes of limitations.

[0000080420-21-000045:mdna:25]
Net Income

[0000080420-21-000045:mdna:26]
In Fiscal 2021, we recorded net income of $0.6 million, or $0.05 per diluted share, compared to net income of $16.7 million, or $1.42 per diluted share in Fiscal 2020, primarily due to a decline in revenues and gross profit resulting from lower orders and project delays caused by the economic impact resulting from the COVID-19 pandemic and the associated reduction in global demand across our industrial end markets.

[0000080420-21-000045:mdna:27]
Backlog

[0000080420-21-000045:mdna:28]
The order backlog at September 30, 2021 was $414.9 million, a 13% decrease from $476.8 million at September 30, 2020. Bookings, net of cancellations and scope reductions, decreased by 30% in Fiscal 2021 to $403.9 million, compared to $576.8 million in Fiscal 2020. The large year-over-year decrease in bookings in Fiscal 2021 was primarily due to the large contract awarded in Fiscal 2020 and decreased global demand across our industrial end markets.

[0000080420-21-000045:mdna:29]
Outlook

[0000080420-21-000045:mdna:30]
As noted in "Overview" above, the markets in which we participate are capital-intensive and cyclical in nature. A significant portion of our revenues has historically been from the oil, gas and petrochemical markets. Oil and gas commodity price levels have been unstable over the last several years, and our customers have in certain cases, delayed or cancelled some of their major capital investment projects. Beginning in late Fiscal 2018 through the first quarter of Fiscal 2020, our customers' decisions to invest in projects in our key oil and gas and petrochemical markets were influenced to some extent by relative stabilization of commodity prices and the increased global demand for cleaner-burning fuels during that period of time. We believe that this change in market sentiment during that period of time had a favorable impact on our orders and backlog entering Fiscal 2020. However, the uncertainty in oil prices and the global economic impacts from COVID-19 have had, and may continue to have, a negative impact on our business going forward, as discussed in more detail below. Specific to the energy industry focus on transitioning to natural gas and cleaner-burning fuels, the business was awarded a substantial contract in Fiscal 2020 that will support the integrated electrical distribution requirements for a large domestic industrial complex and should be substantially completed in Fiscal 2022.

[0000080420-21-000045:mdna:31]
Our operating results are impacted by factors such as the timing of new order awards, customer approval of final engineering and design specifications and delays in customer construction schedules, all of which contribute to short-term earnings variability and the timing of project execution. Our operating results also have been, and may continue to be, impacted by the timing and resolution of change orders, project close-out and resolution of potential contract claims and liquidated damages, all of which could improve or deteriorate gross margins during the period in which these items are resolved with our customers. These factors may result in periods of underutilization of our resources and facilities, which may negatively impact our ability

[0000080420-21-000045:mdna:32]
to cover our fixed costs. We will continue to monitor potential labor shortages and increased labor costs and the impact on our operations.

[0000080420-21-000045:mdna:33]
The strong commercial activity and subsequent orders in Fiscal 2018 and 2019 led to solid revenue and operating results for Fiscal 2020. We began to experience lower commercial activity in Fiscal 2020 driven in large part from the uncertainty resulting from the COVID-19 pandemic, as discussed in "Overview" above. Considering the long cycle nature of our business, these cyclical conditions may persist into Fiscal 2022. We will continue to monitor the variables that impact our markets while adjusting to the global conditions in order to maintain competitive costs and technological advantages in the markets that we serve.

[0000080420-21-000045:mdna:34]
The consequences of a prolonged economic decline could include, but are not limited to, a continued reduction in commercial and industrial activity. Accordingly, the Company cannot reasonably estimate the duration or severity of this pandemic, potential labor shortages, increased labor costs, or the  extent to which these disruptions may materially impact our business, results of operations or cash flows. We will take prudent measures to maintain our strong liquidity and cash position, which may include reducing our capital expenditures and research and development costs, as well as reducing or eliminating future dividend payments.

[0000080420-21-000045:mdna:35]
Liquidity and Capital Resources

[0000080420-21-000045:mdna:36]
As of September 30, 2021, current assets exceeded current liabilities by 2.5 times, and our debt to total capitalization was 0.13%.

[0000080420-21-000045:mdna:37]
Cash, cash equivalents and short-term investments decreased to $134.0 million at September 30, 2021, compared to $178.9 million at September 30, 2020. This decrease in cash was primarily driven by the timing of contract billing milestones. We believe that our strong working capital position, available borrowings under our credit facility and available cash should be sufficient to finance future operating activities, capital improvements, research and development initiatives and debt repayments for the foreseeable future.

[0000080420-21-000045:mdna:38]
We have a credit agreement with Bank of America, N.A. (the "U.S. Revolver") which is a $75.0 million revolving credit facility available for both borrowings and letters of credit and expires September 27, 2024. On March 12, 2021, we entered into a first amendment to the U.S. Revolver which, among other things, amended certain terms related to the calculation of the consolidated leverage ratio from gross leverage to net leverage. As a result of the first amendment, up to $30 million may be deducted from the amount of letters of credit outstanding (not to be less than zero) when calculating the consolidated funded indebtedness which is a component of the consolidated net leverage ratio. Additionally, we have the option to cash collateralize all or a portion of the letters of credit outstanding, which would favorably impact the consolidated funded indebtedness calculation and the consolidated net leverage ratio.

[0000080420-21-000045:mdna:39]
As of September 30, 2021, there were no amounts borrowed under this facility, and letters of credit outstanding were $34.8 million. As of September 30, 2021, $40.2 million was available for the issuance of letters of credit and borrowing under the U.S. Revolver. Total long-term debt, including current maturities, totaled $0.4 million at September 30, 2021 related to outstanding industrial development revenue bonds. We are required to maintain certain financial covenants, the most significant of which are a consolidated net leverage ratio less than 3.0 to 1.0 and a consolidated interest coverage ratio of greater than 3.0 to 1.0. Our most restrictive covenant, the consolidated net leverage ratio, is the ratio of earnings before interest, taxes, depreciation, amortization and stock-based compensation (EBITDAS) to funded indebtedness, which includes letters of credit. An increase in indebtedness or a decrease in EBITDAS could restrict our ability to issue letters of credit or borrow under the U.S. Revolver. For further information regarding our debt, see Notes G and H of Notes to Consolidated Financial Statements.

[0000080420-21-000045:mdna:40]
Approximately $30.6 million of our cash, cash equivalents and short-term investments at September 30, 2021 was held outside of the U.S. for our international operations. It is our intention to indefinitely reinvest all current and future foreign earnings internationally in order to ensure sufficient working capital to support our international operations. In the event that we elect to repatriate some or all of the foreign earnings that were previously deemed to be indefinitely reinvested outside the U.S., we may incur additional tax expense upon such repatriation under current tax laws.

[0000080420-21-000045:mdna:41]
Operating Activities

[0000080420-21-000045:mdna:42]
Operating activities used net cash of $30.5 million in Fiscal 2021 and provided net cash of $72.4 million in Fiscal 2020. Cash flow from operations is primarily influenced by the timing of milestone payments from our customers, project volume and the payment terms with our suppliers. This decrease in operating cash flows was primarily due to the timing of contract billing milestones and cash used on our large industrial project discussed above.

[0000080420-21-000045:mdna:43]
Investing Activities

[0000080420-21-000045:mdna:44]
Investing activities used $2.5 million of cash during Fiscal 2021 compared to $17.5 million of cash used in Fiscal 2020. The decrease in cash used by investing activities in Fiscal 2021 was primarily due to a decrease in net purchases of short-term investments and a decrease in capital expenditures. Additionally, the proceeds received from a Company-owned life insurance policy related to a retired employee provided investing cash flow in Fiscal 2021.

[0000080420-21-000045:mdna:45]
Financing Activities

[0000080420-21-000045:mdna:46]
Net cash used in financing activities was $13.2 million in Fiscal 2021 and $13.1 million in Fiscal 2020, which primarily consisted of $12.1 million of dividends paid in each year.

[0000080420-21-000045:mdna:47]
Other Commercial Commitments

[0000080420-21-000045:mdna:48]
We are contingently liable for letters of credit and bank guarantees totaling $42.2 million as of September 30, 2021, with the following potential cash outflows in the event that we are unable to perform under our contracts (in thousands):

[0000080420-21-000045:mdna:49]
| Payments Due by Period: | Letters ofCredit/Bank Guarantees |
| Less than 1 year | $ | 16,504 |  |
| 1 to 3 years | 24,416 |  |
| More than 3 years | 1,275 |  |
| Total long-term commercial obligations | $ | 42,195 |  |

[0000080420-21-000045:mdna:50]
We also had surety bonds totaling $143.0 million that were outstanding at September 30, 2021. Surety bonds are primarily used to guarantee our contract performance to our customers.

[0000080420-21-000045:mdna:51]
Off-Balance Sheet Arrangements

[0000080420-21-000045:mdna:52]
We had no significant off-balance sheet arrangements during the periods presented.

[0000080420-21-000045:mdna:53]
Effects of Inflation

[0000080420-21-000045:mdna:54]
We are subject to inflation, which can cause increases in our costs of labor and raw materials, primarily copper, aluminum and steel. Fixed-price contracts can limit our ability to pass these increases to our customers, thus negatively impacting our earnings. Inflation in commodity prices has negatively impacted our financial results in Fiscal 2021. Additionally, inflation related to commodity and labor prices may potentially impact our operations in future years.

[0000080420-21-000045:mdna:55]
Critical Accounting Estimates

[0000080420-21-000045:mdna:56]
The preparation of consolidated financial statements in conformity with accounting principles generally accepted in the U.S. requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities, disclosures of contingent assets and liabilities known to exist at the date of the consolidated financial statements and the reported amounts of revenues and expenses during the reporting period. We evaluate our estimates on an ongoing basis, based on historical experience and on various other assumptions that are believed to be reasonable under the circumstances. There can be no assurance that actual results will not differ from those estimates.

[0000080420-21-000045:mdna:57]
We believe the following accounting estimates to be critical in the preparation and reporting of our consolidated financial statements.

[0000080420-21-000045:mdna:58]
Revenue Recognition

[0000080420-21-000045:mdna:59]
Our revenues are primarily generated from the manufacturing of custom-engineered products and systems under long-term fixed-price contracts under which we agree to manufacture various products such as traditional and arc-resistant distribution switchgear and control gear, medium-voltage circuit breakers, monitoring and control communications systems, motor control centers, switches and bus duct systems. These products may be sold separately as an engineered solution, but are typically integrated into custom-built enclosures which we also build.  These enclosures are referred to as power control room substations (PCRs®), custom-engineered modules or electrical houses (E-Houses). Some contracts may also include the installation and the commissioning of these enclosures.

[0000080420-21-000045:mdna:60]
Revenue from these contracts is generally recognized over time utilizing the cost-to-cost method. Under the cost-to-cost method, the extent of progress towards completion is measured based on the ratio of costs incurred to date to the total estimated costs at completion of the performance obligation. We believe that this method is the most accurate representation of our performance, because it directly measures the value of the services transferred to the customer over time as we incur costs on our contracts. Contract costs include all direct materials, labor, and indirect costs related to contract performance, which may include indirect labor, supplies, tools, repairs and depreciation costs.

[0000080420-21-000045:mdna:61]
Contract Estimates

[0000080420-21-000045:mdna:62]
Actual revenues and project costs may vary from previous estimates due to changes in a variety of factors. The cost estimation process is based upon the professional knowledge and experience of our engineers, project managers and financial professionals. Factors that are considered in estimating the work to be completed and ultimate contract recovery include the availability and productivity of labor, the nature and complexity of the work to be performed, the availability of materials, and the effect of any delays on our project performance. We periodically review our job performance, job conditions, estimated profitability and final contract settlements, including our estimate of total costs and make revisions to costs and income in the period in which the revisions are probable and reasonably estimable. We bear the risk of cost overruns in most of our contracts, which may result in reduced profits. Whenever revisions of estimated contract costs and contract values indicate that the contract costs will exceed estimated revenues, thus creating a loss, a provision for the total estimated loss is recorded in that period. See Note E of Notes to Consolidated Financial Statements for disclosures related to changes in contract estimates.

[0000080420-21-000045:mdna:63]
Performance Obligations

[0000080420-21-000045:mdna:64]
A performance obligation is a promise in a contract or with a customer to transfer a distinct good or service. A contract’s transaction price is allocated to each distinct performance obligation and recognized as revenue as the performance obligations are satisfied. To determine the proper revenue recognition for contracts, we evaluate whether a contract should be accounted for as more than one performance obligation or, less commonly, whether two or more contracts should be combined and accounted for as one performance obligation. This evaluation of performance obligations requires significant judgment. The majority of our contracts have a single performance obligation where multiple engineered products and services are combined into a single, custom-engineered solution. Our contracts include a standard one-year assurance warranty. Occasionally, we provide service-type warranties that will extend the warranty period. These extended warranties qualify as separate performance obligations, and revenue is deferred and recognized over the warranty period. If we determine during the evaluation of the contract that there are multiple performance obligations, we allocate the transaction price to each performance obligation using our best estimate of the standalone selling price of each distinct good or service in the contract.

[0000080420-21-000045:mdna:65]
Variable Consideration

[0000080420-21-000045:mdna:66]
It is common for our long-term contracts to contain variable consideration that can either increase or decrease the transaction price. Due to the nature of our contracts, estimating total cost and revenue can be complex and subject to variability due to change orders, back charges, spare parts, early completion bonuses, customer allowances and liquidated damages. We estimate the amount of variable consideration based on the expected value method, which is the sum of probability-weighted amount, or the most likely amount method, which uses various factors including experience with similar transactions and assessment of our anticipated performance. Variable consideration is included in the transaction price if legally enforceable and to the extent it is probable that a significant reversal of cumulative revenue recognized will not occur once the uncertainty associated with the variable consideration is resolved.

[0000080420-21-000045:mdna:67]
Contract Modifications

[0000080420-21-000045:mdna:68]
Contracts may be modified for changes in contract specifications and requirements. We consider contract modifications to exist when the modification either creates new or changes the enforceable rights and obligations under the contract. Most of our contract modifications are for goods and services that are not distinct from the existing performance obligation. Contract

[0000080420-21-000045:mdna:69]
modifications result in a cumulative catch-up adjustment to revenue based on our measure of progress for the performance obligation.

[0000080420-21-000045:mdna:70]
Impairment of Long-Lived Assets

[0000080420-21-000045:mdna:71]
We review long-lived assets for impairment whenever events or changes in circumstances indicate that the carrying value may not be realizable. If an evaluation is required, the estimated future undiscounted cash flows associated with the asset are compared to the asset’s carrying amount to determine if recording an impairment of such asset is necessary. This requires us to make long-term forecasts of the future revenues and costs related to the assets subject to review. Forecasts require assumptions about demand for our products and future market conditions. Estimating future cash flows requires significant judgment, and our projections may vary from cash flows eventually realized. Future events and unanticipated changes to assumptions could require a provision for impairment in a future period. The effect of any impairment would be reflected in income (loss) from operations in the Consolidated Statements of Operations. In addition, we estimate the useful lives of our long-lived assets and other intangibles and periodically review these estimates to determine whether these lives are appropriate.

[0000080420-21-000045:mdna:72]
Accruals for Contingent Liabilities

[0000080420-21-000045:mdna:73]
From time to time, contingencies such as insurance-related claims, liquidated damages and legal claims arise in the normal course of business. Pursuant to applicable accounting standards, we must evaluate such contingencies to subjectively determine the likelihood that an asset has been impaired, or a liability has been incurred at the date of the financial statements, as well as evaluate whether the amount of the loss can be reasonably estimated. If the likelihood is determined to be probable, and it can be reasonably estimated, the estimated loss is recorded. The amounts we record for contingent liabilities require judgments regarding the amount of expenses that will ultimately be incurred. We use past experience and history, as well as the specific circumstances surrounding each contingent liability, including estimated legal costs, in evaluating the amount of liability that should be recorded. Actual results could differ from our estimates.

[0000080420-21-000045:mdna:74]
Warranty Costs

[0000080420-21-000045:mdna:75]
Estimated costs of warranties are accrued based on historical warranty claim costs in relation to current revenues. In addition, specific provisions are made when product failures are projected outside historical experience. Our standard terms and conditions of sale include a warranty for parts and service for one year. Occasionally, we provide service-type warranties that will extend the warranty period. Actual results could differ from our estimate.

[0000080420-21-000045:mdna:76]
Projects may require, on occasion, warranty terms that are longer than our standard terms due to the nature of the project. Extended warranty terms may be negotiated and included in our contracts. The allocated revenue associated with the extended warranty is deferred and recorded as a contract liability and recognized as revenue over the extended warranty period.

[0000080420-21-000045:mdna:77]
Accounting for Income Taxes

[0000080420-21-000045:mdna:78]
We account for income taxes under the asset and liability method, based on the income tax laws and rates in the countries in which operations are conducted, and income is earned. This approach requires the recognition of deferred tax assets and liabilities for the expected future tax consequences of temporary differences between the carrying amounts and the tax basis of assets and liabilities. Developing our provision for income taxes requires significant judgment and expertise in federal, international and state income tax laws, regulations and strategies, including the determination of deferred tax assets and liabilities and, if necessary, any valuation allowances that may be required for deferred tax assets. In assessing the extent to which net deferred tax assets may be realized, we consider whether it is more likely than not that some portion or all of the net deferred tax assets may not be realized. The ultimate realization of net deferred tax assets is dependent on the generation of future taxable income during the periods in which those temporary differences become deductible. Estimates may change as new events occur, estimates of future taxable income during the carryforward period are reduced or increased, additional information becomes available, or operating environments change, which may result in a full or partial reversal of the valuation allowance. We will continue to assess the adequacy of the valuation allowance on a quarterly basis. Our judgments and tax strategies are subject to audit by various taxing authorities.

[0000080420-21-000045:mdna:79]
The objectives of accounting for income taxes are to recognize the amount of taxes payable or refundable for the current year and deferred tax liabilities and assets for the future tax consequences of events that have been recognized in an entity’s financial statements or tax returns. We recognize the tax benefit from an uncertain tax position only if it is more likely than not that the tax position will be sustained on examination by the taxing authorities, based on the technical merits of the position. The tax benefits recognized in the financial statements from such a position should be measured based on the largest benefit that has a greater than 50% likelihood of being realized upon ultimate settlement. Accounting literature also provides guidance on

[0000080420-21-000045:mdna:80]
derecognition of income tax assets and liabilities, classification of current and deferred income tax assets and liabilities, accounting for interest and penalties associated with tax positions, and income tax disclosures. Judgment is required in assessing the future tax consequences of events that have been recognized in our financial statements or tax returns. Variations in the actual outcome of these future tax consequences could materially impact our financial position and results of operations.

[0000080420-21-000045:mdna:81]
See Note I of Notes to Consolidated Financial Statements for disclosures related to the valuation allowance recorded in relation to foreign deferred taxes.
