# POWL note change history — 0000080420-23-000007 → 0000080420-23-000027


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2023-05-03):
[0000080420-23-000027:note_history:1]
Certain customers require us to post letters of credit, bank guarantees or surety bonds. These security instruments assure that we will perform under the terms of our contract. In the event of default, the counterparty may demand payment from the bank under a letter of credit or bank guarantee, or performance by the surety under a bond. To date, there have been no significant draws or claims related to security instruments for the periods reported. We were contingently liable for letters of credit of $44.8 million as of March 31, 2023. We also had surety bonds totaling $294.2 million that were outstanding, with additional bonding capacity of $305.8 million available, at March 31, 2023. We have strong surety relationships; however, a change in market conditions or the sureties' assessment of our financial position could cause the sureties to require cash collateralization for undischarged liabilities under the bonds.
  (was, 2023-02-01, similarity 0.9857):
[0000080420-23-000007:note_history:1]
Certain customers require us to post letters of credit, bank guarantees or surety bonds. These security instruments assure that we will perform under the terms of our contract. In the event of default, the counterparty may demand payment from the bank under a letter of credit or bank guarantee, or performance by the surety under a bond. To date, there have been no significant draws or claims related to security instruments for the periods reported. We were contingently liable for letters of credit of $33.8 million as of December 31, 2022. We also had surety bonds totaling $284.5 million that were outstanding, with additional bonding capacity of $315.5 million available, at December 31, 2022. We have strong surety relationships; however, a change in market conditions or the sureties' assessment of our financial position could cause the sureties to require cash collateralization for undischarged liabilities under the bonds.

- changed (2023-05-03):
[0000080420-23-000027:note_history:2]
We have a $9.9 million facility agreement (Facility Agreement) between Powell (UK) Limited and a large international bank that provides Powell (UK) Limited the ability to enter into bank guarantees as well as forward exchange contracts and currency options. At March 31, 2023, we had outstanding guarantees totaling $7.7 million. The Facility Agreement provides for customary events of default and carries cross-default provisions with our Second Amendment. If an event of default (as defined in the Facility Agreement) occurs and is continuing, per the terms and subject to the conditions set forth therein, obligations outstanding under the Facility Agreement may be accelerated and declared immediately due and payable. Additionally, we are required to maintain cash collateral for guarantees greater than two years. As of March 31, 2023, we were in compliance with all of the financial covenants of the Facility Agreement.
  (was, 2023-02-01, similarity 0.9698):
[0000080420-23-000007:note_history:2]
We have a $9.7 million facility agreement (Facility Agreement) between Powell (UK) Limited and a large international bank that provides Powell (UK) Limited the ability to enter into bank guarantees as well as forward exchange contracts and currency options. At December 31, 2022, we had outstanding guarantees totaling $6.8 million. The Facility Agreement provides for customary events of default and carries cross-default provisions with our U.S. Revolver. If an event of default (as defined in the Facility Agreement) occurs and is continuing, per the terms and subject to the conditions set forth therein, obligations outstanding under the Facility Agreement may be accelerated and declared immediately due and payable. Additionally, we are required to maintain cash collateral for guarantees greater than two years. As of December 31, 2022, we were in compliance with all of the financial covenants of the Facility Agreement.


## us-gaap:LongTermDebtTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2023-05-03):
[0000080420-23-000027:note_history:3]
Long-Term Debt
U.S Revolver
  (was, 2023-02-01, similarity 0.9818):
[0000080420-23-000007:note_history:3]
Long-Term Debt
U.S. Revolver

- added (2023-05-03):
[0000080420-23-000027:note_history:4]
On March 31, 2023, we entered into a second amendment (the Second Amendment) to our credit agreement with Bank of America, N.A. (as amended, the U.S. Revolver). The Second Amendment increased the revolving credit facility extended to us under the U.S. Revolver, which is available for both borrowings and letters of credit and expires September 27, 2024, from $75.0 million to $125.0 million. As amended by the Second Amendment, the U.S. Revolver states that the lesser of $50 million or 50% of readily and available cash may be deducted from the amount of letters of credit outstanding (not to be less than zero) when calculating the consolidated funded indebtedness, which is a component of the consolidated net leverage ratio. We have the option to cash collateralize all or a portion of the letters of credit outstanding, which would favorably impact the consolidated funded indebtedness calculation and the consolidated net leverage ratio. As of March 31, 2023, there were no amounts borrowed under the U.S. Revolver, and letters of credit outstanding were $44.8 million. There was $80.2 million available for the issuance of letters of credit and borrowings under the U.S. Revolver as of March 31, 2023.

- changed (2023-05-03):
[0000080420-23-000027:note_history:5]
We are required to maintain certain financial covenants, the most significant of which are a consolidated net leverage ratio less than 3.0 to 1.0 and a consolidated interest coverage ratio of greater than 3.0 to 1.0. Our most restrictive covenant, the consolidated net leverage ratio, is the ratio of earnings before interest, taxes, depreciation, amortization and stock-based compensation (EBITDAS) to funded indebtedness. An increase in indebtedness, which includes letters of credit, or a decrease in EBITDAS could restrict our ability to issue letters of credit or borrow under the U.S. Revolver. Additionally, we must maintain a consolidated cash balance of $50 million at all times, which can be deducted from the letters of credit outstanding as noted above. The U.S. Revolver also contains a "material adverse effect" clause which is a material change in our operations, business, properties, liabilities or condition (financial or otherwise) or a material impairment of our ability to perform our obligations under our credit agreements. As of March 31, 2023, we were in compliance with all of the financial covenants of the U.S. Revolver.
  (was, 2023-02-01, similarity 0.7155):
[0000080420-23-000007:note_history:5]
in EBITDAS could restrict our ability to issue letters of credit or borrow under the U.S. Revolver. Additionally, we must maintain a consolidated cash balance of $30 million at all times, which can be deducted from the letters of credit outstanding as noted above. The U.S. Revolver also contains a "material adverse effect" clause which is a material change in our operations, business, properties, liabilities or condition (financial or otherwise) or a material impairment of our ability to perform our obligations under our credit agreements. As of December 31, 2022, we were in compliance with all of the financial covenants of the U.S. Revolver.

- changed (2023-05-03):
[0000080420-23-000027:note_history:6]
The U.S. Revolver allows the Company to elect that any borrowing under the facility bears an interest rate based on either the base rate or the eurocurrency rate, in each case, plus the applicable rate. The base rate is generally the highest of (a) the federal funds rate plus 0.50%, (b) the Bank of America prime rate or (c) the Bloomberg Short-Term Bank Yield Index (BSBY) rate plus 1.00%. The applicable rate is generally a range from 0% to 2% depending on the type of loan and the Company's consolidated net leverage ratio.
  (was, 2023-02-01, similarity 0.6963):
[0000080420-23-000007:note_history:6]
The U.S. Revolver allows the Company to elect that any borrowing under the facility bears an interest rate based on either the base rate or the eurocurrency rate, in each case, plus the applicable rate. The base rate is generally the highest of (a) the federal funds rate plus 0.50%, (b) the Bank of America prime rate or (c) the Bloomberg Short-Term Bank Yield Index (BSBY) rate plus 1.00%. The applicable rate is generally a range from (0.25)% to 1.75% depending on the type of loan and the Company's consolidated net leverage ratio. On November 10, 2022, the Company entered into a second LIBOR Transition Amendment with Bank of America that states that LIBOR for U.S. dollar loans will be replaced with the BSBY rate in accordance with the U.S. Revolver.

- removed (2023-05-03):
[0000080420-23-000007:note_history:7]
We have a credit agreement with Bank of America, N.A. (as amended, the U.S. Revolver), which is a $75.0 million revolving credit facility that is available for both borrowings and letters of credit and expires September 27, 2024. The U.S. Revolver states that up to $30 million may be deducted from the amount of letters of credit outstanding (not to be less than zero) when calculating the consolidated funded indebtedness, which is a component of the consolidated net leverage ratio. Additionally, we have the option to cash collateralize all or a portion of the letters of credit outstanding, which would favorably impact the consolidated funded indebtedness calculation and the consolidated net leverage ratio. As of December 31, 2022, there were no amounts borrowed under the U.S. Revolver, and letters of credit outstanding were $33.8 million. There was $41.2 million available for the issuance of letters of credit and borrowings under the U.S. Revolver as of December 31, 2022.

- removed (2023-05-03):
[0000080420-23-000007:note_history:8]
We are required to maintain certain financial covenants, the most significant of which are a consolidated net leverage ratio less than 3.0 to 1.0 and a consolidated interest coverage ratio of greater than 3.0 to 1.0. Our most restrictive covenant, the consolidated net leverage ratio, is the ratio of earnings before interest, taxes, depreciation, amortization and stock-based compensation (EBITDAS) to funded indebtedness. An increase in indebtedness, which includes letters of credit, or a decrease


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2023-05-03):
[0000080420-23-000027:note_history:9]
The following tables present our disaggregated revenue by geographic destination and market sector for the three and six months ended March 31, 2023 and 2022 (in thousands):
  (was, 2023-02-01, similarity 0.9477):
[0000080420-23-000007:note_history:9]
The following tables present our disaggregated revenue by geographic destination and market sector for the three months ended December 31, 2022 and 2021 (in thousands):

- changed (2023-05-03):
[0000080420-23-000027:note_history:10]
|  | Three months ended March 31, |  | Six months ended March 31, |
|  | 2023 |  | 2022 |  | 2023 |  | 2022 |
| United States | $ | 134,161 |  |  | $ | 86,992 |  |  | $ | 234,273 |  |  | $ | 169,137 |  |
| Canada | 21,995 |  |  | 22,053 |  |  | 40,491 |  |  | 37,178 |  |
| Europe, Middle East and Africa | 11,957 |  |  | 15,551 |  |  | 18,516 |  |  | 23,381 |  |
| Asia/Pacific | 1,788 |  |  | 1,646 |  |  | 2,564 |  |  | 2,590 |  |
| Mexico, Central and South America | 1,543 |  |  | 1,612 |  |  | 2,458 |  |  | 2,137 |  |
| Total revenues by geographic destination | $ | 171,444 |  |  | $ | 127,854 |  |  | $ | 298,302 |  |  | $ | 234,423 |  |
  (was, 2023-02-01, similarity 0.7057):
[0000080420-23-000007:note_history:10]
|  | Three months ended December 31, |  |  |
|  | 2022 |  | 2021 |  |  |  |  |
| United States | $ | 100,112 |  |  | $ | 82,145 |  |  |  |  |  |
| Canada | 18,496 |  |  | 15,125 |  |  |  |  |  |
| Europe, Middle East and Africa | 6,559 |  |  | 7,830 |  |  |  |  |  |
| Asia/Pacific | 776 |  |  | 944 |  |  |  |  |  |
| Mexico, Central and South America | 915 |  |  | 525 |  |  |  |  |  |
| Total revenues by geographic destination | $ | 126,858 |  |  | $ | 106,569 |  |  |  |  |  |

- changed (2023-05-03):
[0000080420-23-000027:note_history:11]
|  | Three months ended March 31, |  | Six months ended March 31, |
|  | 2023 |  | 2022 |  | 2023 |  | 2022 |
| Oil and gas (excludes petrochemical) | $ | 62,597 |  |  | $ | 53,634 |  |  | $ | 106,107 |  |  | $ | 96,655 |  |
| Petrochemical | 25,887 |  |  | 18,853 |  |  | 48,377 |  |  | 36,081 |  |
| Electric utility | 42,668 |  |  | 30,374 |  |  | 71,075 |  |  | 51,907 |  |
| Traction power | 7,317 |  |  | 10,054 |  |  | 14,389 |  |  | 21,426 |  |
| Commercial and other industrial | 22,270 |  |  | 5,785 |  |  | 39,320 |  |  | 15,618 |  |
| All others | 10,705 |  |  | 9,154 |  |  | 19,034 |  |  | 12,736 |  |
| Total revenues by market sector | $ | 171,444 |  |  | $ | 127,854 |  |  | $ | 298,302 |  |  | $ | 234,423 |  |
  (was, 2023-02-01, similarity 0.676):
[0000080420-23-000007:note_history:11]
|  | Three months ended December 31, |  |  |
|  | 2022 |  | 2021 |  |  |  |  |
| Oil and gas (excludes petrochemical) | $ | 43,510 |  |  | $ | 43,021 |  |  |  |  |  |
| Petrochemical | 22,490 |  |  | 17,228 |  |  |  |  |  |
| Electric utility | 28,407 |  |  | 21,533 |  |  |  |  |  |
| Traction power | 7,072 |  |  | 11,372 |  |  |  |  |  |
| Commercial and other industrial | 17,050 |  |  | 5,646 |  |  |  |  |  |
| All others | 8,329 |  |  | 7,769 |  |  |  |  |  |
| Total revenues by market sector | $ | 126,858 |  |  | $ | 106,569 |  |  |  |  |  |


## us-gaap:RevenueFromContractWithCustomerPolicyTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2023-05-03):
[0000080420-23-000027:note_history:12]
We also have contracts to provide field service inspection, installation, commissioning, modification, and repair services, as well as retrofit and retrofill components for existing systems. If the service contract terms give us the right to invoice the customer for an amount that corresponds directly with the value of our performance completed to date (i.e., a service contract in which we bill a fixed amount for each hour of service provided), then we recognize revenue over time in each reporting period corresponding to the amount with which we have the right to invoice. Our performance obligations are satisfied as the work progresses. Revenues from our custom-engineered products and value-added services transferred to customers over time accounted for approximately 93% of total revenues for the three and six months ended March 31, 2023 and 94% of total revenues for the three and six months ended March 31, 2022.
  (was, 2023-02-01, similarity 0.9482):
[0000080420-23-000007:note_history:12]
We also have contracts to provide field service inspection, installation, commissioning, modification, and repair services, as well as retrofit and retrofill components for existing systems. If the service contract terms give us the right to invoice the customer for an amount that corresponds directly with the value of our performance completed to date (i.e., a service contract in which we bill a fixed amount for each hour of service provided), then we recognize revenue over time in each reporting period corresponding to the amount with which we have the right to invoice. Our performance obligations are satisfied as the work progresses. Revenues from our custom-engineered products and value-added services transferred to customers over time accounted for approximately 93% of total revenues for the three months ended December 31, 2022 and 94% of total revenues for the three months ended December 31, 2021.

- changed (2023-05-03):
[0000080420-23-000027:note_history:13]
We also have sales orders for spare parts and replacement circuit breakers for switchgear that are obsolete or that are no longer produced by the original manufacturer. Revenues from these sales orders are recognized at the time we fulfill our performance obligation to the customer, which is typically upon shipment and represented approximately 7% of total revenues for the three and six months ended March 31, 2023 and 6% of total revenues for the three and six months ended March 31, 2022.
  (was, 2023-02-01, similarity 0.8931):
[0000080420-23-000007:note_history:13]
We also have sales orders for spare parts and replacement circuit breakers for switchgear that are obsolete or that are no longer produced by the original manufacturer. Revenues from these sales orders are recognized at the time we fulfill our performance obligation to the customer, which is typically upon shipment and represented approximately 7% of total revenues for the three months ended December 31, 2022 and 6% of total revenues for the three months ended December 31, 2021.


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2023-05-03):
[0000080420-23-000027:note_history:14]
We also have contracts to provide field service inspection, installation, commissioning, modification, and repair services, as well as retrofit and retrofill components for existing systems. If the service contract terms give us the right to invoice the customer for an amount that corresponds directly with the value of our performance completed to date (i.e., a service contract in which we bill a fixed amount for each hour of service provided), then we recognize revenue over time in each reporting period corresponding to the amount with which we have the right to invoice. Our performance obligations are satisfied as the work progresses. Revenues from our custom-engineered products and value-added services transferred to customers over time accounted for approximately 93% of total revenues for the three and six months ended March 31, 2023 and 94% of total revenues for the three and six months ended March 31, 2022.
  (was, 2023-02-01, similarity 0.9482):
[0000080420-23-000007:note_history:14]
We also have contracts to provide field service inspection, installation, commissioning, modification, and repair services, as well as retrofit and retrofill components for existing systems. If the service contract terms give us the right to invoice the customer for an amount that corresponds directly with the value of our performance completed to date (i.e., a service contract in which we bill a fixed amount for each hour of service provided), then we recognize revenue over time in each reporting period corresponding to the amount with which we have the right to invoice. Our performance obligations are satisfied as the work progresses. Revenues from our custom-engineered products and value-added services transferred to customers over time accounted for approximately 93% of total revenues for the three months ended December 31, 2022 and 94% of total revenues for the three months ended December 31, 2021.

- changed (2023-05-03):
[0000080420-23-000027:note_history:15]
We also have sales orders for spare parts and replacement circuit breakers for switchgear that are obsolete or that are no longer produced by the original manufacturer. Revenues from these sales orders are recognized at the time we fulfill our performance obligation to the customer, which is typically upon shipment and represented approximately 7% of total revenues for the three and six months ended March 31, 2023 and 6% of total revenues for the three and six months ended March 31, 2022.
  (was, 2023-02-01, similarity 0.8931):
[0000080420-23-000007:note_history:15]
We also have sales orders for spare parts and replacement circuit breakers for switchgear that are obsolete or that are no longer produced by the original manufacturer. Revenues from these sales orders are recognized at the time we fulfill our performance obligation to the customer, which is typically upon shipment and represented approximately 7% of total revenues for the three months ended December 31, 2022 and 6% of total revenues for the three months ended December 31, 2021.

- changed (2023-05-03):
[0000080420-23-000027:note_history:16]
Remaining unsatisfied performance obligations, which we refer to as backlog, represent the estimated transaction price for goods and services for which we have a material right, but work has not been performed. As of March 31, 2023, we had backlog of $1.0 billion, of which approximately $584.4 million is expected to be recognized as revenue within the next twelve months. Backlog may not be indicative of future operating results as orders may be cancelled or modified by our customers. Our backlog does not include service and maintenance-type contracts for which we have the right to invoice as services are performed.
  (was, 2023-02-01, similarity 0.9877):
[0000080420-23-000007:note_history:16]
Remaining unsatisfied performance obligations, which we refer to as backlog, represent the estimated transaction price for goods and services for which we have a material right, but work has not been performed. As of December 31, 2022, we had backlog of $679.8 million, of which approximately $464.2 million is expected to be recognized as revenue within the next twelve months. Backlog may not be indicative of future operating results as orders may be cancelled or modified by our customers. Our backlog does not include service and maintenance-type contracts for which we have the right to invoice as services are performed.

- changed (2023-05-03):
[0000080420-23-000027:note_history:17]
For the six months ended March 31, 2023 and 2022, our operating results were positively impacted by $7.4 million and $5.6 million, respectively, as a result of net changes in contract estimates related to projects in progress at the beginning of the respective period. These changes in estimates resulted primarily from favorable project execution and negotiations of variable consideration, discussed below, as well as revenue and reduced costs recognized from project cancellations and other changes in facts and circumstances during these periods. Gross unfavorable changes in contract estimates were immaterial for both the six months ended March 31, 2023 and 2022.
  (was, 2023-02-01, similarity 0.8624):
[0000080420-23-000007:note_history:17]
For the three months ended December 31, 2022 and 2021, our operating results were positively impacted by $3.6 million and $2.8 million, respectively, as a result of changes in contract estimates related to projects in progress at the beginning of the respective period. These changes in estimates resulted primarily from favorable project execution and negotiations of variable consideration, discussed below, as well as revenue and reduced costs recognized from project cancellations and other changes in facts and circumstances during these periods.

- changed (2023-05-03):
[0000080420-23-000027:note_history:18]
Contract assets and liabilities as of March 31, 2023 and September 30, 2022 are summarized below (in thousands):
  (was, 2023-02-01, similarity 0.9565):
[0000080420-23-000007:note_history:18]
Contract assets and liabilities as of December 31, 2022 and September 30, 2022 are summarized below (in thousands):

- changed (2023-05-03):
[0000080420-23-000027:note_history:19]
|  | March 31, 2023 |  | September 30, 2022 |
| Contract assets | $ | 63,560 |  |  | $ | 88,351 |  |
| Contract liabilities | (178,217) |  |  | (79,857) |  |
| Net contract asset (liability) | $ | (114,657) |  |  | $ | 8,494 |  |
  (was, 2023-02-01, similarity 0.9748):
[0000080420-23-000007:note_history:19]
|  | December 31, 2022 |  | September 30, 2022 |
| Contract assets | $ | 63,911 |  |  | $ | 88,351 |  |
| Contract liabilities | (133,753) |  |  | (79,857) |  |
| Net contract asset (liability) | $ | (69,842) |  |  | $ | 8,494 |  |

- added (2023-05-03):
[0000080420-23-000027:note_history:20]
Our net contract billing position improved to a net liability at March 31, 2023 from a net asset position at September 30, 2022 primarily due to favorable contract billing milestones. We typically allocate a significant percentage of the progress billing to the early stages of the contract. These favorable billing milestones along with our increase in project backlog are driving the

- added (2023-05-03):
[0000080420-23-000027:note_history:21]
increase in the net contract liability at March 31, 2023. To determine the amount of revenue recognized during the period from contract liabilities, we first allocate revenue to the individual contract liability balance outstanding at the beginning of the period until the revenue exceeds that balance. During the six months ended March 31, 2023, we recognized revenue of approximately $58.7 million that was related to contract liabilities outstanding at September 30, 2022.

- changed (2023-05-03):
[0000080420-23-000027:note_history:22]
The timing of our invoice process is typically dependent on the completion of certain milestones and contract terms and subject to agreement by our customer. Payment is typically expected within 30 days of invoice. Any uncollected invoiced amounts for our performance obligations recognized over time, including contract retentions, are recorded as accounts receivable in the Condensed Consolidated Balance Sheets. Certain contracts allow customers to withhold a small percentage of billings pursuant to retainage provisions, and such amounts are generally due upon completion of the contract and acceptance of the project by the customer. Based on our experience in recent years, the majority of these retainage balances are expected to be collected within approximately twelve months. As of March 31, 2023 and September 30, 2022, accounts receivable included retention amounts of $6.6 million and $6.9 million, respectively. Of the retained amount at March 31, 2023, $6.4 million is expected to be collected in the next twelve months and is recorded in accounts receivable. The remaining $0.2 million is recorded in other assets.
  (was, 2023-02-01, similarity 0.9883):
[0000080420-23-000007:note_history:22]
The timing of our invoice process is typically dependent on the completion of certain milestones and contract terms and subject to agreement by our customer. Payment is typically expected within 30 days of invoice. Any uncollected invoiced amounts for our performance obligations recognized over time, including contract retentions, are recorded as accounts receivable in the Condensed Consolidated Balance Sheets. Certain contracts allow customers to withhold a small percentage of billings pursuant to retainage provisions, and such amounts are generally due upon completion of the contract and acceptance of the project by the customer. Based on our experience in recent years, the majority of these retainage balances are expected to be collected within approximately twelve months. As of December 31, 2022 and September 30, 2022, accounts receivable included retention amounts of $7.2 million and $6.9 million, respectively. Of the retained amount at December 31, 2022, $6.9 million is expected to be collected in the next twelve months and is recorded in accounts receivable. The remaining $0.3 million is recorded in other assets.

- changed (2023-05-03):
[0000080420-23-000027:note_history:23]
The following tables present our disaggregated revenue by geographic destination and market sector for the three and six months ended March 31, 2023 and 2022 (in thousands):
  (was, 2023-02-01, similarity 0.9477):
[0000080420-23-000007:note_history:23]
The following tables present our disaggregated revenue by geographic destination and market sector for the three months ended December 31, 2022 and 2021 (in thousands):

- changed (2023-05-03):
[0000080420-23-000027:note_history:24]
|  | Three months ended March 31, |  | Six months ended March 31, |
|  | 2023 |  | 2022 |  | 2023 |  | 2022 |
| United States | $ | 134,161 |  |  | $ | 86,992 |  |  | $ | 234,273 |  |  | $ | 169,137 |  |
| Canada | 21,995 |  |  | 22,053 |  |  | 40,491 |  |  | 37,178 |  |
| Europe, Middle East and Africa | 11,957 |  |  | 15,551 |  |  | 18,516 |  |  | 23,381 |  |
| Asia/Pacific | 1,788 |  |  | 1,646 |  |  | 2,564 |  |  | 2,590 |  |
| Mexico, Central and South America | 1,543 |  |  | 1,612 |  |  | 2,458 |  |  | 2,137 |  |
| Total revenues by geographic destination | $ | 171,444 |  |  | $ | 127,854 |  |  | $ | 298,302 |  |  | $ | 234,423 |  |
  (was, 2023-02-01, similarity 0.7057):
[0000080420-23-000007:note_history:24]
|  | Three months ended December 31, |  |  |
|  | 2022 |  | 2021 |  |  |  |  |
| United States | $ | 100,112 |  |  | $ | 82,145 |  |  |  |  |  |
| Canada | 18,496 |  |  | 15,125 |  |  |  |  |  |
| Europe, Middle East and Africa | 6,559 |  |  | 7,830 |  |  |  |  |  |
| Asia/Pacific | 776 |  |  | 944 |  |  |  |  |  |
| Mexico, Central and South America | 915 |  |  | 525 |  |  |  |  |  |
| Total revenues by geographic destination | $ | 126,858 |  |  | $ | 106,569 |  |  |  |  |  |

- changed (2023-05-03):
[0000080420-23-000027:note_history:25]
|  | Three months ended March 31, |  | Six months ended March 31, |
|  | 2023 |  | 2022 |  | 2023 |  | 2022 |
| Oil and gas (excludes petrochemical) | $ | 62,597 |  |  | $ | 53,634 |  |  | $ | 106,107 |  |  | $ | 96,655 |  |
| Petrochemical | 25,887 |  |  | 18,853 |  |  | 48,377 |  |  | 36,081 |  |
| Electric utility | 42,668 |  |  | 30,374 |  |  | 71,075 |  |  | 51,907 |  |
| Traction power | 7,317 |  |  | 10,054 |  |  | 14,389 |  |  | 21,426 |  |
| Commercial and other industrial | 22,270 |  |  | 5,785 |  |  | 39,320 |  |  | 15,618 |  |
| All others | 10,705 |  |  | 9,154 |  |  | 19,034 |  |  | 12,736 |  |
| Total revenues by market sector | $ | 171,444 |  |  | $ | 127,854 |  |  | $ | 298,302 |  |  | $ | 234,423 |  |
  (was, 2023-02-01, similarity 0.676):
[0000080420-23-000007:note_history:25]
|  | Three months ended December 31, |  |  |
|  | 2022 |  | 2021 |  |  |  |  |
| Oil and gas (excludes petrochemical) | $ | 43,510 |  |  | $ | 43,021 |  |  |  |  |  |
| Petrochemical | 22,490 |  |  | 17,228 |  |  |  |  |  |
| Electric utility | 28,407 |  |  | 21,533 |  |  |  |  |  |
| Traction power | 7,072 |  |  | 11,372 |  |  |  |  |  |
| Commercial and other industrial | 17,050 |  |  | 5,646 |  |  |  |  |  |
| All others | 8,329 |  |  | 7,769 |  |  |  |  |  |
| Total revenues by market sector | $ | 126,858 |  |  | $ | 106,569 |  |  |  |  |  |

- removed (2023-05-03):
[0000080420-23-000007:note_history:26]
Our net contract billing position improved to a net liability at December 31, 2022 from a net asset position at September 30, 2022 primarily due to favorable contract billing milestones. To determine the amount of revenue recognized during the period from contract liabilities, we first allocate revenue to the individual contract liability balance outstanding at the beginning of the

- removed (2023-05-03):
[0000080420-23-000007:note_history:27]
period until the revenue exceeds that balance. During the three months ended December 31, 2022, we recognized revenue of approximately $36.4 million that was related to contract liabilities outstanding at September 30, 2022.


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: tag_name, score: 1.0

- changed (2023-05-03):
[0000080420-23-000027:note_history:28]
On May 2, 2023, our Board of Directors declared a quarterly cash dividend on our common stock in the amount of $0.2625 per share. The dividend is payable on June 14, 2023 to shareholders of record at the close of business on May 17, 2023.
  (was, 2023-02-01, similarity 0.6765):
[0000080420-23-000007:note_history:28]
On January 31, 2023, our Board of Directors approved a 1% increase to the quarterly cash dividend on our common stock to $0.2625 per share, equating to an annualized dividend of $1.05 per share from the current amount of $1.04 per share. The dividend is payable on March 15, 2023 to shareholders of record at the close of business on February 15, 2023.
