# POWL 8-K — 0000080420-23-000025 filed 2023-05-03

## item codes, every 8-K on or before 2023-05-03

- 2023-05-03 0000080420-23-000025 — 2.02, 8.01, 9.01
- 2023-04-06 0000080420-23-000020 — 1.01, 2.03, 9.01
- 2023-04-05 0000080420-23-000018 — 5.02
- 2023-02-16 0000080420-23-000011 — 5.02, 5.07, 9.01
- 2023-01-31 0000080420-23-000004 — 2.02, 8.01
- 2022-12-05 0000080420-22-000034 — 2.02, 9.01
- 2022-08-02 0000080420-22-000030 — 2.02, 8.01, 9.01
- 2022-05-13 0000080420-22-000024 — 5.02, 9.01
- 2022-05-03 0000080420-22-000016 — 2.02, 9.01
- 2022-05-03 0000080420-22-000015 — 8.01, 9.01
- 2022-02-17 0000080420-22-000010 — 5.07
- 2022-02-08 0000080420-22-000005 — 2.02, 9.01
- 2022-02-01 0000080420-22-000002 — 8.01, 9.01
- 2021-12-07 0000080420-21-000043 — 2.02, 9.01
- 2021-08-03 0000080420-21-000036 — 2.02, 8.01, 9.01
- 2021-05-04 0000080420-21-000026 — 2.02, 8.01, 9.01
- 2021-03-16 0001193125-21-082878 — 1.01, 2.03, 9.01
- 2021-03-05 0000080420-21-000021 — 5.02, 8.01, 9.01
- 2021-02-26 0000080420-21-000018 — 5.03
- 2021-02-18 0000080420-21-000016 — 5.07
- 2021-02-02 0000080420-21-000010 — 2.02, 8.01, 9.01
- 2020-12-08 0000080420-20-000032 — 2.02, 9.01
- 2020-11-12 0000080420-20-000030 — 8.01, 9.01
- 2020-08-04 0000080420-20-000024 — 2.02, 8.01, 9.01
- 2020-05-05 0000080420-20-000017 — 2.02, 8.01, 9.01
- 2020-02-21 0000080420-20-000008 — 5.07
- 2020-02-04 0000080420-20-000003 — 2.02, 8.01, 9.01
- 2019-12-04 0001193125-19-306243 — 2.02, 9.01
- 2019-11-08 0000080420-19-000032 — 8.01, 9.01
- 2019-10-03 0000080420-19-000030 — 1.01, 2.03
- 2019-09-24 0000080420-19-000028 — 8.01, 9.01
- 2019-08-06 0000080420-19-000022 — 2.02, 8.01, 9.01
- 2019-05-08 0000080420-19-000017 — 5.02, 9.01
- 2019-05-07 0000080420-19-000011 — 2.02, 8.01, 9.01
- 2019-02-22 0001193125-19-048366 — 5.07
- 2019-02-05 0000080420-19-000003 — 2.02, 8.01
- 2018-12-21 0000080420-18-000038 — 5.02, 9.01
- 2018-12-12 0000080420-18-000031 — 2.02
- 2018-11-05 0000080420-18-000029 — 8.01, 9.01
- 2018-11-01 0000080420-18-000027 — 5.02, 8.01, 9.01
- 2018-10-01 0000080420-18-000024 — 5.02
- 2018-08-07 0000080420-18-000020 — 2.02, 8.01
- 2018-05-15 0000080420-18-000016 — 5.02, 8.01
- 2018-05-09 0000080420-18-000011 — 2.02, 8.01
- 2018-02-22 0000080420-18-000009 — 5.07
- 2018-02-06 0000080420-18-000003 — 2.02, 8.01
- 2017-12-27 0001193125-17-379928 — 5.02
- 2017-12-05 0000080420-17-000028 — 2.02, 9.01
- 2017-11-08 0000080420-17-000024 — 8.01, 9.01
- 2017-11-03 0000080420-17-000022 — 5.02
- 2017-08-09 0000080420-17-000017 — 2.02, 8.01
- 2017-06-30 0000080420-17-000014 — 1.01, 9.01
- 2017-05-03 0000080420-17-000006 — 2.02, 8.01, 9.01
- 2017-02-23 0000080420-17-000004 — 5.07
- 2017-02-08 0001628280-17-000965 — 2.02 — amendment of 0001628280-17-000949
- 2017-02-07 0001628280-17-000949 — 2.01, 8.01, 9.01
- 2016-12-07 0001193125-16-787354 — 2.02, 9.01
- 2016-11-01 0001193125-16-755475 — 8.01, 9.01
- 2016-09-30 0001193125-16-726999 — 5.02, 8.01, 9.01
- 2016-08-03 0001193125-16-669308 — 2.02, 8.01, 9.01
- 2016-05-04 0001193125-16-576528 — 2.02, 8.01, 9.01
- 2016-02-25 0001193125-16-477896 — 5.07
- 2016-02-03 0001193125-16-449052 — 2.02, 8.01, 9.01
- 2015-12-31 0001193125-15-418363 — 5.02, 7.01, 9.01
- 2015-12-02 0001193125-15-393109 — 2.02, 9.01
- 2015-11-05 0001193125-15-368085 — 8.01, 9.01
- 2015-09-25 0001193125-15-329031 — 5.02
- 2015-08-05 0001193125-15-277912 — 2.02, 8.01, 9.01
- 2015-05-06 0001193125-15-174291 — 2.02, 8.01, 9.01
- 2015-03-06 0001193125-15-081070 — 5.02
- 2015-03-02 0001193125-15-072946 — 5.07
- 2015-02-03 0001193125-15-031772 — 2.02, 8.01, 9.01
- 2014-12-18 0001193125-14-446513 — 8.01, 9.01
- 2014-12-03 0001193125-14-431745 — 2.02, 9.01
- 2014-11-05 0001193125-14-397955 — 8.01, 9.01
- 2014-09-26 0001193125-14-353741 — 7.01, 9.01
- 2014-08-05 0001193125-14-296001 — 2.02, 8.01, 9.01
- 2014-05-07 0001193125-14-187496 — 2.02, 8.01, 9.01
- 2014-03-03 0001193125-14-079843 — 5.02, 5.07
- 2014-02-05 0001193125-14-036633 — 2.02, 8.01, 9.01
- 2014-01-17 0001193125-14-014351 — 1.01, 8.01, 9.01
- 2014-01-06 0001193125-14-002795 — 1.01, 2.03
- 2013-12-06 0001564590-13-001411 — 2.02, 9.01
- 2013-12-05 0001564590-13-001406 — 5.02, 8.01, 9.01
- 2013-11-07 0001193125-13-432950 — 8.01, 9.01
- 2013-08-07 0001193125-13-324337 — 2.02, 9.01
- 2013-05-08 0001193125-13-206800 — 2.02, 9.01
- 2013-02-22 0001193125-13-070971 — 5.02, 5.07
- 2013-02-06 0001193125-13-040556 — 2.02, 9.01
- 2012-12-18 0001193125-12-506417 — 5.02, 9.01
- 2012-12-05 0001193125-12-491749 — 2.02, 9.01
- 2012-10-12 0001193125-12-421889 — 3.03, 5.02, 5.03, 9.01
- 2012-08-09 0001193125-12-344617 — 5.02, 8.01, 9.01
- 2012-08-08 0001193125-12-343630 — 2.02, 9.01
- 2012-05-09 0001193125-12-221356 — 2.02, 9.01
- 2012-02-08 0001193125-12-046560 — 2.02, 9.01
- 2011-12-08 0001193125-11-334810 — 2.02, 9.01
- 2011-11-08 0000950123-11-096524 — 2.02, 2.06, 4.02, 9.01
- 2011-10-14 0000950123-11-090124 — 5.02
- 2011-10-06 0000950123-11-088969 — 5.02
- 2011-09-19 0000950123-11-085224 — 5.02, 9.01
- 2011-09-15 0000950123-11-084806 — 5.02, 9.01
- 2011-08-04 0000950123-11-072788 — 2.02, 9.01
- 2011-07-22 0000950123-11-067402 — 5.07
- 2011-05-24 0000950123-11-053550 — 1.01, 2.03, 9.01
- 2011-05-04 0000950123-11-044561 — 2.02, 9.01
- 2011-02-02 0000950123-11-008188 — 2.02, 9.01
- 2010-12-08 0000950123-10-111987 — 2.02, 9.01
- 2010-08-05 0000950123-10-073114 — 2.02, 9.01
- 2010-05-18 0000950123-10-050900 — 5.02
- 2010-05-05 0000950123-10-044499 — 2.02, 9.01
- 2010-02-03 0000950123-10-008278 — 2.02, 9.01
- 2009-12-21 0000950123-09-072269 — 1.01, 2.01, 2.03, 8.01, 9.01
- 2009-12-09 0000950123-09-069525 — 2.02, 9.01
- 2009-10-27 0000950123-09-053501 — 1.01, 8.01, 9.01
- 2009-08-04 0000950123-09-029476 — 2.02, 9.01
- 2009-05-06 0000950129-09-001498 — 2.02, 9.01
- 2009-03-05 0000950129-09-000749 — 1.01, 9.01
- 2009-02-10 0000950129-09-000349 — 2.02, 9.01
- 2008-12-10 0000950134-08-021934 — 2.02, 9.01
- 2008-08-06 0000950129-08-004267 — 2.02, 9.01
- 2008-07-24 0000950129-08-004063 — 1.01, 5.02, 8.01, 9.01
- 2008-06-16 0000950129-08-003500 — 9.01 — amendment of 0000950134-06-015374
- 2008-06-05 0000950129-08-003378 — 5.02, 9.01
- 2008-05-08 0000950129-08-002843 — 2.02, 9.01
- 2008-02-06 0000950129-08-000533 — 2.02, 9.01
- 2007-12-19 0000950129-07-006277 — 1.01, 2.03, 9.01
- 2007-12-06 0000950129-07-006003 — 2.02, 9.01
- 2007-08-21 0000950129-07-004181 — 2.02, 9.01
- 2007-05-31 0000950129-07-002810 — 2.02, 9.01
- 2007-05-21 0000950129-07-002668 — 2.02, 3.01, 4.02, 9.01
- 2007-04-16 0000950129-07-002002 — 2.02, 4.02, 9.01
- 2007-03-01 0000950129-07-001104 — 5.02, 8.01, 9.01
- 2007-02-08 0000950129-07-000451 — 2.02, 9.01
- 2006-12-08 0000950129-06-010041 — 2.02, 9.01
- 2006-09-08 0000950129-06-008379 — 2.02, 9.01
- 2006-08-09 0000950134-06-015374 — 1.01, 2.01, 8.01, 9.01
- 2006-06-08 0000950129-06-006127 — 2.02, 9.01
- 2006-03-09 0000950129-06-002455 — 2.02, 9.01
- 2005-12-16 0000950129-05-012031 — 2.02, 5.03, 9.01
- 2005-09-13 0000950129-05-009181 — 2.01, 9.01 — amendment of 0000950129-05-006889
- 2005-09-12 0000950129-05-009151 — 2.02, 9.01
- 2005-07-06 0000950129-05-006889 — 1.01, 1.02, 2.01, 2.03, 9.01
- 2005-06-10 0000950129-05-006128 — 2.02, 9.01
- 2005-04-20 0000080420-05-000031 — 5.02
- 2005-03-11 0000080420-05-000024 — 9.01
- 2005-02-25 0000080420-05-000018 — 7.01, 9.01
- 2005-01-21 0000080420-05-000009 — 7.01, 9.01
- 2004-12-17 0000080420-04-000049 — 2.02, 9.01
- 2004-11-01 0000080420-04-000045 — 8.01, 9.01
- 2004-10-08 0001169232-04-005133 — 2.05
- 2004-09-14 0000080420-04-000037 — 5.02
- 2004-09-02 0000080420-04-000030 — 2.02, 9.01
- 2004-06-08 0000080420-04-000021 — 7
- 2004-05-13 0000080420-04-000019 — 4
- 2004-02-27 0000080420-04-000013 — 7
- 2003-12-16 0000950129-03-006136 — 12, 7
- 2003-08-29 0000950129-03-004531 — 12, 7
- 2003-06-03 0000950129-03-003035 — 7, 9
- 2003-05-15 0000950129-03-002812 — 7, 9
- 2002-05-29 0000950129-02-002795 — 4
- 2000-12-21 0000950129-00-006093 — 5, 7
- 1998-09-04 0000950129-98-003802 — 5
- 1996-08-09 0000950129-96-001705 — 2, 7

## late-filing notifications on or before 2023-05-03

- 2007-05-11 0000950129-07-002494 — NT 10-Q, for the period ended 2007-03-31
- 2005-01-18 0000080420-05-000004 — NT 10-K, for the period ended 2004-10-31

## item 2.02 — earnings release, exhibit 99.1

[0000080420-23-000025:8k_2_02:1]
EX-99.1
2
ex99-1q22023earningsrelease.htm
EX-99.1

[0000080420-23-000025:8k_2_02:2]
Document

[0000080420-23-000025:8k_2_02:3]
Exhibit 99.1

[0000080420-23-000025:8k_2_02:4]
PRESS RELEASE

[0000080420-23-000025:8k_2_02:5]
For Immediate Release    Contacts:    Michael W. Metcalf, CFO

[0000080420-23-000025:8k_2_02:6]
Powell Industries, Inc.

[0000080420-23-000025:8k_2_02:7]
713-947-4422

[0000080420-23-000025:8k_2_02:8]
Robert Winters or Ryan Coleman

[0000080420-23-000025:8k_2_02:9]
Alpha IR Group

[0000080420-23-000025:8k_2_02:10]
POWL@alpha-ir.com

[0000080420-23-000025:8k_2_02:11]
312-445-2870

[0000080420-23-000025:8k_2_02:12]
POWELL INDUSTRIES ANNOUNCES FISCAL 2023 SECOND QUARTER RESULTS

[0000080420-23-000025:8k_2_02:13]
HOUSTON — May 2, 2023 — Powell Industries, Inc. (NASDAQ: POWL), a leading supplier of custom-engineered solutions for the management, control and distribution of electrical energy, today announced results for the fiscal 2023 second quarter ended March 31, 2023. All comparisons are to the comparable period in the prior fiscal year, unless otherwise noted.

[0000080420-23-000025:8k_2_02:14]
Fiscal Second Quarter Key Highlights:

[0000080420-23-000025:8k_2_02:15]
•Revenues strengthened to $171 million, an increase of 34%;

[0000080420-23-000025:8k_2_02:16]
•Backlog more than doubled to a record $1.0 billion;

[0000080420-23-000025:8k_2_02:17]
•New orders(1) more than tripled to $508 million;

[0000080420-23-000025:8k_2_02:18]
•Gross margin improved 460 basis points to 19.5%;

[0000080420-23-000025:8k_2_02:19]
•Net Income was $8.5 million, or $0.70 per diluted share; and

[0000080420-23-000025:8k_2_02:20]
•Cash and short-term investments as of March 31, 2023 totaled $163 million.

[0000080420-23-000025:8k_2_02:21]
Brett A. Cope, Powell’s Chairman and Chief Executive Officer, stated, “Powell delivered quarterly results that were among the best in its history, as our continued execution against our strategic initiatives combined with the cyclical recovery of our core markets drove new orders of $508 million – our highest ever quarterly total. We also delivered $171 million of revenue, an

[0000080420-23-000025:8k_2_02:22]
increase of 34% compared to last year, which resulted in a book-to-bill ratio(2) of 3.0x – the sixth consecutive quarter above 1.0x. Further, our order backlog is now over $1.0 billion as the breadth of order activity across our end markets remains healthy and is complementing a strong recovery of commercial activity within our core Industrial markets. Overall, we feel very confident that our strategic efforts are positioning Powell for long-term success and that we are well-positioned to drive improved earnings in fiscal 2023.”

[0000080420-23-000025:8k_2_02:23]
Revenues for the second fiscal quarter totaled $171.4 million, an increase of 34% compared to $127.9 million in the prior year, which represents sequential growth of 35% compared to $126.9 million in the first fiscal quarter.

[0000080420-23-000025:8k_2_02:24]
Gross profit in the quarter totaled $33.4 million, an increase of $14.4 million, or 75%, compared to the prior year, and compared to $19.5 million in the fiscal first quarter. Gross margin in the second quarter was 19.5%, an increase of 460 basis points compared to the prior year and 420 basis points compared to the fiscal first quarter.

[0000080420-23-000025:8k_2_02:25]
New orders placed in the second quarter more than tripled to $508 million compared to $151 million in the prior year, and more than doubled compared to $212 million in the first quarter.

[0000080420-23-000025:8k_2_02:26]
Backlog as of March 31, 2023 was a record $1.0 billion, an increase of 50% compared to $680 million as of December 31, 2022, and compared to $440 million at the end of the fiscal second quarter in the prior year.

[0000080420-23-000025:8k_2_02:27]
Net income in the second fiscal quarter totaled $8.5 million, or $0.70 per diluted share, compared to a net loss of $1.2 million, or a loss of $0.10 per diluted share, in the prior year and net income of $1.2 million, or $0.10 per diluted share, in the first fiscal quarter.

[0000080420-23-000025:8k_2_02:28]
Cope added, “Order activity in our core Oil, Gas & Petrochemical markets accelerated in our second quarter as we were awarded another large domestic LNG project during the quarter, marking three consecutive quarters with significant new activity in these markets.  We are also very fortunate and pleased to have secured a large Petrochemical project during the quarter, also for the US domestic market.  The nature and scope of these projects are core to what Powell does best. Our 75-year history of success and leadership in the industry has earned us our current

[0000080420-23-000025:8k_2_02:29]
position in this cycle and leaves us very comfortable with our ability to fulfill our backlog with the same level of service and execution that has earned us our reputation. We have taken every dollar of our backlog thoughtfully and on schedules that we are confident we can achieve.”

[0000080420-23-000025:8k_2_02:30]
OUTLOOK

[0000080420-23-000025:8k_2_02:31]
Commenting on the Company's outlook, Michael Metcalf, Powell’s Chief Financial Officer, said, “We are very encouraged by the level of commercial activity across our core end markets, while many of the margin initiatives that we have been working on are beginning to deliver positive results. Further, the current cadence of project activity in our $1.0 billion backlog, combined with our capacity levels and the strength of the balance sheet, put us in a strong position to execute on our order book and fulfill our commitments to our customers. Concurrent with these operational objectives, we continue to evaluate both new organic investments into the business as well as inorganic opportunities as we progress our corporate strategy. As such, and given the current activity levels across our market sectors, we took an important step forward in the second fiscal quarter, amending our credit facility by increasing the capacity in order to ensure our continued commercial success. Taken altogether, we are confident that Powell will deliver improved revenues and earnings in fiscal 2023 and into fiscal 2024.”

[0000080420-23-000025:8k_2_02:32]
CONFERENCE CALL

[0000080420-23-000025:8k_2_02:33]
Powell Industries has scheduled a conference call for Wednesday, May 3, 2023, at 11:00 a.m. Eastern time.  To participate in the conference call, dial 1-833-953-2431 (domestic) or 1-412-317-5760 (international) and ask for the Powell Industries conference call.  A telephonic replay of the conference call will be available through May 10, 2023 and may be accessed by calling 1-877-344-7529 (domestic) or 1-412-317-0088 (international) and using passcode 2136094#.

[0000080420-23-000025:8k_2_02:34]
Investors, analysts and the general public will also have the opportunity to listen to the conference call over the Internet by visiting powellind.com. To listen to the live call on the web, please visit the website at least 15 minutes before the call begins to register, download and install any necessary audio software.  For those who cannot listen to the live webcast, an archive will be available shortly after the call and will remain available for approximately 90 days at powellind.com.

[0000080420-23-000025:8k_2_02:35]
3

[0000080420-23-000025:8k_2_02:36]
Powell Industries, Inc., headquartered in Houston, designs, manufactures and services custom-engineered equipment and systems for the distribution, control and monitoring of electrical energy.  Powell markets include large industrial customers such as utilities, oil and gas producers, refineries, liquefied natural gas facilities, petrochemical plants, pulp and paper producers, mining operations and commuter railways.   For more information, please visit powellind.com.

[0000080420-23-000025:8k_2_02:37]
POWELL INDUSTRIES, INC. & SUBSIDIARIES

[0000080420-23-000025:8k_2_02:38]
CONDENSED CONSOLIDATED STATEMENT OF OPERATIONS

[0000080420-23-000025:8k_2_02:39]
|  | Three Months Ended March 31, |  | Six Months Ended March 31, |
|  | 2023 |  | 2022 |  | 2023 |  | 2022 |
| (In thousands, except per share data) |  |  |  |  |  |  |  |
|  | (Unaudited) |
| Revenues | $ | 171,444 |  |  | $ | 127,854 |  |  | $ | 298,302 |  |  | $ | 234,423 |  |
| Cost of goods sold | 138,007 |  |  | 108,771 |  |  | 245,401 |  |  | 201,904 |  |
| Gross profit | 33,437 |  | 19,083 |  | 52,901 |  | 32,519 |
| Selling, general and administrative expenses | 21,820 |  |  | 17,067 |  |  | 38,693 |  |  | 32,969 |  |
| Research and development expenses | 1,543 |  |  | 1,713 |  |  | 3,044 |  |  | 3,537 |  |
| Operating income (loss) | 10,074 |  |  | 303 |  |  | 11,164 |  |  | (3,987) |  |
| Other income | — |  |  | (279) |  |  | — |  |  | (279) |  |
| Interest income, net | (899) |  |  | (13) |  |  | (1,423) |  |  | (16) |  |
| Income (loss) before income taxes | 10,973 |  |  | 595 |  |  | 12,587 |  |  | (3,692) |  |
| Income tax provision | 2,500 |  |  | 1,812 |  |  | 2,951 |  |  | 371 |  |
| Net income (loss) | $ | 8,473 |  |  | $ | (1,217) |  |  | $ | 9,636 |  |  | $ | (4,063) |  |
| Earnings (loss) per share: |  |  |  |  |  |  |  |
| Basic | $ | 0.71 |  |  | $ | (0.10) |  |  | $ | 0.81 |  |  | $ | (0.34) |  |
| Diluted | $ | 0.70 |  |  | $ | (0.10) |  |  | $ | 0.80 |  |  | $ | (0.34) |  |
| Weighted average shares: |  |  |  |  |  |  |  |
| Basic | 11,878 |  |  | 11,801 |  |  | 11,869 |  |  | 11,783 |  |
| Diluted | 12,149 |  |  | 11,801 |  |  | 12,109 |  |  | 11,783 |  |
| SELECTED FINANCIAL DATA: |  |  |  |  |  |  |  |
| Depreciation | $ | 2,176 |  |  | $ | 2,417 |  |  | $ | 4,312 |  |  | $ | 4,831 |  |
| Capital Expenditures | $ | 630 |  |  | $ | 680 |  |  | $ | 3,356 |  |  | $ | 1,116 |  |
| Dividends Paid | $ | 3,106 |  |  | $ | 3,058 |  |  | $ | 6,180 |  |  | $ | 6,106 |  |

[0000080420-23-000025:8k_2_02:40]
5

[0000080420-23-000025:8k_2_02:41]
POWELL INDUSTRIES, INC. & SUBSIDIARIES

[0000080420-23-000025:8k_2_02:42]
CONDENSED CONSOLIDATED BALANCE SHEETS

[0000080420-23-000025:8k_2_02:43]
|  | March 31, 2023 |  | September 30, 2022 |
| (In thousands) |  |  |  |
|  | (Unaudited) |
| Assets: |  |  |  |
| Cash, cash equivalents and short-term investments | $ | 163,124 |  |  | $ | 116,508 |  |
| Other current assets | 300,076 |  |  | 253,475 |  |
| Property, plant and equipment, net | 97,910 |  |  | 98,628 |  |
| Long-term assets | 25,986 |  |  | 24,769 |  |
| Total assets | $ | 587,096 |  |  | $ | 493,380 |  |
| Liabilities and equity: |  |  |  |
| Current liabilities | $ | 269,691 |  |  | $ | 186,373 |  |
| Deferred and other long-term liabilities | 11,610 |  | 9,801 |
| Stockholders’ equity | 305,795 |  |  | 297,206 |  |
| Total liabilities and stockholders’ equity | $ | 587,096 |  |  | $ | 493,380 |  |
| SELECTED FINANCIAL DATA: |  |  |  |
| Working capital | $ | 193,509 |  |  | $ | 183,610 |  |

[0000080420-23-000025:8k_2_02:44]
(1)    New orders (bookings) represent the estimated value of contracts added to existing backlog (unsatisfied performance obligations).

[0000080420-23-000025:8k_2_02:45]
(2)     The book-to-bill ratio represents the ratio of new orders (bookings) received in the period divided by the revenues recognized in the period. We believe the book-to-bill  ratio is an important metric for readers as it relates to the change in the backlog level. A ratio greater than 1.0 indicates growing backlog levels, while a ratio less than 1.0 indicates that the business is experiencing a period of contracting backlog. The amounts recorded in backlog may not be a reliable indicator of our future operating results and may not be indicative of continuing revenue performance over future fiscal quarters or years primarily due to unexpected contract adjustments, cancellations or scope reductions.
