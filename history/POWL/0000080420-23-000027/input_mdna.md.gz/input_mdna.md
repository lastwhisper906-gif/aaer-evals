# POWL MD&A — 0000080420-23-000027


## mdna

[0000080420-23-000027:mdna:1]
[same as prior period, unchanged from 0000080420-23-000007:mdna:1]

[0000080420-23-000027:mdna:2]
[same as prior period, unchanged from 0000080420-23-000007:mdna:2]

[0000080420-23-000027:mdna:3]
[same as prior period, unchanged from 0000080420-23-000007:mdna:3]

[0000080420-23-000027:mdna:4]
[same as prior period, unchanged from 0000080420-23-000007:mdna:4]

[0000080420-23-000027:mdna:5]
[same as prior period, unchanged from 0000080420-23-000007:mdna:5]

[0000080420-23-000027:mdna:6]
[same as prior period, unchanged from 0000080420-23-000007:mdna:6]

[0000080420-23-000027:mdna:7]
One element of our strategic focus is to strengthen our project portfolio beyond our core oil, gas and petrochemical end market sectors. Over the past year these efforts have contributed to a record backlog of projects coming into Fiscal 2023. There has been an increase in the planning and capital funding within North America on LNG and related facilities as the market responds to the increased international demand for LNG and gas to chemical processes utilizing low cost gas feedstocks. As a result, the business has been awarded a number of large contracts that have had a positive impact on our backlog. Additionally, diversification efforts outside of our core oil, gas and petrochemical end markets have resulted in an increase in backlog across the utility and commercial and other industrial sectors as well.

[0000080420-23-000027:mdna:8]
Various factors resulting in global economic uncertainty negatively impacted our results over the past two years. Uncertainty and demand disruptions resulted in considerable volatility across commodity markets. We continue to experience supply chain disruptions driven predominately by availability and cost volatility across our raw materials, components and labor force. All of these factors contributed to the lower margins realized in Fiscal 2022 relative to prior oil and gas cycles. As we address supply chain disruptions, we continue to work with our suppliers of key components and commodities to meet our customer commitments. Additionally, we have adjusted our pricing models with our customers in response to the increased cost environment.

[0000080420-23-000027:mdna:9]
[same as prior period, unchanged from 0000080420-23-000007:mdna:11]

[0000080420-23-000027:mdna:10]
Quarter Ended March 31, 2023 Compared to the Quarter Ended March 31, 2022 (Unaudited)

[0000080420-23-000027:mdna:11]
[same as prior period, unchanged from 0000080420-23-000007:mdna:13]

[0000080420-23-000027:mdna:12]
Revenues increased by 34%, or $43.6 million, to $171.4 million in the second quarter of Fiscal 2023, primarily driven by the increase in project backlog. Domestic revenues increased by 54%, or $47.2 million, to $134.2 million in the second quarter of Fiscal 2023. Included in our domestic oil and gas sector revenues is the large domestic industrial project awarded in Fiscal 2020, which accounted for approximately 8% of our consolidated revenues for the second quarter of Fiscal 2023 compared to 16% in the same period in the prior year. International revenues decreased by 9%, or $3.6 million, to $37.2 million in the second quarter of Fiscal 2023. Our international revenues include both revenues generated from our international facilities as well as revenues from export projects generated at our domestic facilities.

[0000080420-23-000027:mdna:13]
Revenue from our core oil and gas markets (excluding petrochemical) increased by 17%, or $9.0 million, to $62.6 million in the second quarter of Fiscal 2023, while petrochemical revenue increased by 37%, or $7.0 million, to $25.9 million in the second quarter of Fiscal 2023. Revenue from our utility markets increased by 40%, or $12.3 million, to $42.7 million in the second quarter of Fiscal 2023. Commercial and other industrial market revenue increased by 285%, or $16.5 million, to $22.2 million, driven by an increase in traditionally non-core markets such as data centers, university projects and other miscellaneous applications. Revenue from all other markets combined increased by 17%, or $1.6 million, to $10.7 million in the second quarter of Fiscal 2023. These increases in revenue were driven by improved market conditions and our strategic effort to diversify our business. Revenue from our traction market decreased by 27%, or $2.7 million, to $7.3 million in the second quarter of Fiscal 2023.

[0000080420-23-000027:mdna:14]
Gross profit increased by 75%, or $14.4 million, to $33.4 million for the second quarter of Fiscal 2023.  Gross profit as a percentage of revenues increased to 20% in the second quarter of Fiscal 2023, compared to 15% in the second quarter of Fiscal 2022. The increase in gross profit was directly attributable to volume leverage and factory efficiencies as a result of the increase in volume, project execution, as well as effectively managing inflationary pressures while maintaining pricing models to correspond to current cost levels.

[0000080420-23-000027:mdna:15]
[same as prior period, unchanged from 0000080420-23-000007:mdna:17]

[0000080420-23-000027:mdna:16]
Selling, general and administrative expenses increased by 28%, or $4.8 million, to $21.8 million in the second quarter of Fiscal 2023, primarily due to $2.4 million of increased variable incentive compensation resulting from improved earnings. Selling, general and administrative expenses as a percentage of revenues remained flat at 13% during both the second quarter of Fiscal 2023 and the second quarter of Fiscal 2022.

[0000080420-23-000027:mdna:17]
Income Tax Provision

[0000080420-23-000027:mdna:18]
We recorded an income tax provision of $2.5 million in the second quarter of Fiscal 2023, compared to an income tax provision of $1.8 million in the second quarter of Fiscal 2022. The effective tax rate for the second quarter of Fiscal 2023 was 23%, compared to an effective tax rate of 305% for the second quarter of Fiscal 2022. For the three months ended March 31, 2023, the effective tax rate was favorably impacted by the estimated Research and Development Tax Credit (R&D Tax Credit), in addition to the projected utilization of net operating loss carryforwards in the UK that have been fully reserved with a valuation allowance. These benefits were offset by state income tax expense, certain nondeductible expenses and an income inclusion related to U.S. global intangible income.

[0000080420-23-000027:mdna:19]
[same as prior period, unchanged from 0000080420-23-000007:mdna:21]

[0000080420-23-000027:mdna:20]
In the second quarter of Fiscal 2023, we recorded net income of $8.5 million, or $0.70 per diluted share, compared to a net loss of $1.2 million, or $0.10 per diluted share, in the second quarter of Fiscal 2022. This increase in net income was primarily due to the increase in bookings over the last 12 to 18 months which has led to an increase in revenues.

[0000080420-23-000027:mdna:21]
[same as prior period, unchanged from 0000080420-23-000007:mdna:23]

[0000080420-23-000027:mdna:22]
The order backlog at March 31, 2023 was $1.0 billion, an increase of 50% from $679.8 million at December 31, 2022 and an increase of 132% from $440.0 million at March 31, 2022. Bookings, net of cancellations and scope reductions, increased by 237% in the second quarter of Fiscal 2023 to $508.2 million, compared to $150.8 million in the second quarter of Fiscal 2022, primarily driven by improved strength across our core oil, gas and petrochemical market sectors.

[0000080420-23-000027:mdna:23]
Six Months Ended March 31, 2023 Compared to Six Months Ended March 31, 2022 (Unaudited)

[0000080420-23-000027:mdna:24]
Revenue and Gross Profit

[0000080420-23-000027:mdna:25]
Revenues increased by 27%, or $63.9 million, to $298.3 million in the six months ended March 31, 2023. Domestic revenues increased by 39%, or $65.1 million, to $234.3 million in the six months ended March 31, 2023. International revenues decreased by 1.9%, or $1.2 million, to $64.0 million. Our international revenues include both revenues generated from our international facilities as well as revenues from export projects generated at our domestic facilities.

[0000080420-23-000027:mdna:26]
Revenues from our core oil and gas markets (excluding petrochemical) increased by 10%, or $9.5 million, to $106.1 million in the six months ended March 31, 2023, while petrochemical revenue increased by 34%, or $12.3 million, to $48.4 million in the first half of Fiscal 2023. Revenue from our utility markets increased by 37%, or $19.2 million, to $71.1 million in the six months ended March 31, 2023. Traction market revenue decreased by 33%, or $7.0 million, to $14.4 million in the six months ended March 31, 2023. Commercial and other industrial market revenue increased by 152%, or $23.7 million, to $39.3 million, and revenues from all other markets combined increased by 49%, or $6.3 million, to $19.0 million in the first six months of Fiscal 2023.

[0000080420-23-000027:mdna:27]
Gross profit increased by 63%, or $20.4 million, to $52.9 million in the six months ended March 31, 2023 as compared to the first half of Fiscal 2022. Gross profit as a percentage of revenues increased to 18% in the first six months of Fiscal 2023 as compared to 14% in the six months ended March 31, 2022. The increase in gross profit was directly attributable to volume leverage and factory efficiencies as a result of the increase in volume, project execution, as well as effectively managing inflationary pressures while maintaining pricing models to correspond to current cost levels.

[0000080420-23-000027:mdna:28]
Selling, General and Administrative Expenses

[0000080420-23-000027:mdna:29]
Selling, general and administrative expenses increased by 17%, or $5.7 million, to $38.7 million in the six months ended March 31, 2023, primarily due to $3.2 million of increased variable incentive compensation resulting from improved earnings. Selling, general and administrative expenses as a percentage of revenues decreased to 13% during the six months ended March 31, 2023 compared to 14% during the six months ended March 31, 2022.

[0000080420-23-000027:mdna:30]
Other Income

[0000080420-23-000027:mdna:31]
We recorded other income of $0.3 million in the six months ended March 31, 2022 related to a gain on the sale of land. We did not record other income during the six months ended March 31, 2023.

[0000080420-23-000027:mdna:32]
Income Tax Provision

[0000080420-23-000027:mdna:33]
We recorded an income tax provision of $3.0 million in the six months ended March 31, 2023, compared to an income tax provision of $0.4 million in the six months ended March 31, 2022. The effective tax rate for the six months ended March 31, 2023 was 23%, compared to an effective tax rate of negative 10% for the six months ended March 31, 2022. For the six months ended March 31, 2023, the effective tax rate was favorably impacted by the estimated R&D Tax Credit, in addition to the projected utilization of net operating loss carryforwards in the UK that have been fully reserved with a valuation allowance. These benefits were offset by state income tax expense, certain nondeductible expenses and an income inclusion related to U.S. global intangible income. Similarly, the effective tax rate for the six months ended March 31, 2022 was favorably impacted by the estimated R&D Tax Credit and the projected utilization of net operating loss carryforwards in Canada that were fully reserved with a valuation allowance.

[0000080420-23-000027:mdna:34]
Net Income/Loss

[0000080420-23-000027:mdna:35]
In the six months ended March 31, 2023, we recorded net income of $9.6 million, or $0.80 per diluted share, compared to a net loss of $4.1 million, or $0.34 per diluted share, in the six months ended March 31, 2022. This increase in net income was primarily due to the increase in bookings over the last 12 to 18 months which has led to an increase in revenues.

[0000080420-23-000027:mdna:36]
Backlog

[0000080420-23-000027:mdna:37]
The order backlog at March 31, 2023 was $1.0 billion, an increase of 72% from $592.2 million at September 30, 2022. Bookings, net of cancellations and scope reductions, increased by 178% during the six months ended March 31, 2023 to $720.0 million, compared to $258.5 million during the six months ended March 31, 2022.  The significant year-over-year increase was due to strength across our petrochemical, oil & gas and commercial and other industrial market sectors.

[0000080420-23-000027:mdna:38]
[same as prior period, unchanged from 0000080420-23-000007:mdna:25]

[0000080420-23-000027:mdna:39]
Recently we have seen cyclical recovery across our core oil, gas and petrochemical markets combined with increased global demand for cleaner-burning fuels as well as related processes utilizing low cost gas feedstocks. Our order activity in our core markets has been strong and includes some large domestic LNG and petrochemical projects. This strong commercial activity has increased our backlog to over $1.0 billion, which is a record for Powell. Additionally, diversification efforts outside of our core oil, gas and petrochemical end markets have also been a driver of our increase in backlog. This strong backlog of projects and pricing initiatives in response to persistent inflationary pressures should continue to drive increased revenue volumes throughout the remainder of 2023 and into 2024.

[0000080420-23-000027:mdna:40]
Our operating results are impacted by factors such as the timing of new order awards, project backlog, customer approval of final engineering and design specifications and delays in customer construction schedules, all of which contribute to short-term earnings variability and the timing of project execution. Our operating results also have been, and may continue to be, impacted by the timing and resolution of change orders, project close-out and resolution of potential contract claims and liquidated damages, all of which could improve or deteriorate gross margins during the period in which these items are resolved with our customers. Disruption in the global supply chain has negatively impacted our business and operating results as well due to the reduction in availability and uncertainty in the timing of the receipt of certain key component parts and commodities. These factors may result in periods of underutilization of our resources and facilities, which may negatively impact our ability to cover our fixed costs, or inhibit our ability to deliver completed products on time. We will continue to remain focused on the variables that impact our markets as well as cost management, labor and supply chain challenges. We will also continue to adjust to the global conditions in order to maintain competitive cost and technological advantages in the markets that we serve.

[0000080420-23-000027:mdna:41]
[same as prior period, unchanged from 0000080420-23-000007:mdna:28]

[0000080420-23-000027:mdna:42]
As of March 31, 2023, current assets exceeded current liabilities by 1.7 times.

[0000080420-23-000027:mdna:43]
Cash, cash equivalents and short-term investments increased to $163.1 million at March 31, 2023, compared to $116.5 million at September 30, 2022. This increase in cash was primarily driven by increased project volume and the timing of contract billing milestones. We typically allocate a significant percentage of the progress billing to the early stages of the contract. These favorable billing milestones along with our increase in project backlog are the primary drivers for our increase in cash at March 31, 2023. We believe that our strong working capital position, available borrowings under our credit facility and available cash should be sufficient to finance future operating activities, capital improvements and research and development initiatives for the foreseeable future.

[0000080420-23-000027:mdna:44]
On March 31, 2023, we entered into a second amendment (the Second Amendment) to our credit agreement with Bank of America, N.A. (as amended, the U.S. Revolver). The Second Amendment increased the revolving credit facility extended to us under the U.S. Revolver, which is available for both borrowings and letters of credit and expires September 27, 2024, from $75.0 million to $125.0 million. As amended by the Second Amendment, the U.S. Revolver states the lesser of $50 million or 50% of readily and available cash may be deducted from the amount of letters of credit outstanding (not to be less than zero) when calculating the consolidated funded indebtedness, which is a component of the consolidated net leverage ratio. We have the option to cash collateralize all or a portion of the letters of credit outstanding, which would favorably impact the consolidated funded indebtedness calculation and the consolidated net leverage ratio.

[0000080420-23-000027:mdna:45]
As of March 31, 2023, there were no amounts borrowed under the U.S Revolver, and letters of credit outstanding were $44.8 million. As of March 31, 2023, $80.2 million was available for the issuance of letters of credit and borrowing under the U.S. Revolver. We are required to maintain certain financial covenants, the most significant of which are a consolidated net leverage ratio of less than 3.0 to 1.0 and a consolidated interest coverage ratio of greater than 3.0 to 1.0. Our most restrictive covenant, the consolidated net leverage ratio, is the ratio of earnings before interest, taxes, depreciation, amortization and stock-based compensation (EBITDAS) to funded indebtedness, which includes letters of credit. An increase in indebtedness or a decrease in EBITDAS could restrict our ability to issue letters of credit or borrow under the U.S. Revolver. For further information regarding our debt, see Notes E and F of Notes to Condensed Consolidated Financial Statements.

[0000080420-23-000027:mdna:46]
Approximately $32.6 million of our cash, cash equivalents and short-term investments at March 31, 2023 was held outside of the U.S. for our international operations. It is our intention to indefinitely reinvest all current and future foreign earnings internationally in order to ensure sufficient working capital to support our international operations. In the event that we elect to repatriate some or all of the foreign earnings that were previously deemed to be indefinitely reinvested outside the U.S., we may incur additional tax expense upon such repatriation under current tax laws.

[0000080420-23-000027:mdna:47]
[same as prior period, unchanged from 0000080420-23-000007:mdna:35]

[0000080420-23-000027:mdna:48]
Operating activities provided net cash of $55.5 million during the six months ended March 31, 2023 and used net cash of $13.0 million during the same period in Fiscal 2022. Cash flow from operations is primarily influenced by the timing of milestone payments from our customers, project volume and the associated working capital requirements, as well as payment terms with our suppliers. This increase in operating cash flow was primarily due to the favorable timing of contract billing milestones resulting in increased cash flow as our backlog of projects has increased (as noted above).

[0000080420-23-000027:mdna:49]
[same as prior period, unchanged from 0000080420-23-000007:mdna:37]

[0000080420-23-000027:mdna:50]
Investing activities provided $0.3 million during the six months ended March 31, 2023 and used $7.6 million during the same period in Fiscal 2022. The increase in cash provided by investing activities in the first six months of Fiscal 2023 is primarily due to short-term investment activity.

[0000080420-23-000027:mdna:51]
[same as prior period, unchanged from 0000080420-23-000007:mdna:39]

[0000080420-23-000027:mdna:52]
Net cash used in financing activities was $6.8 million during the six months ended March 31, 2023 and $7.2 million during the same period in Fiscal 2022, which primarily consisted of approximately $6.1 million of dividends paid in each period.

[0000080420-23-000027:mdna:53]
[same as prior period, unchanged from 0000080420-23-000007:mdna:41]

[0000080420-23-000027:mdna:54]
[same as prior period, unchanged from 0000080420-23-000007:mdna:42]

[0000080420-23-000027:mdna:55]
[same as prior period, unchanged from 0000080420-23-000007:mdna:43]
