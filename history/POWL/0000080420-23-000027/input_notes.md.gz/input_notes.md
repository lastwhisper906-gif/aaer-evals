# POWL notes — 0000080420-23-000027


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureAndSignificantAccountingPoliciesTextBlock

[0000080420-23-000027:notes:1]
[same as prior period, unchanged from 0000080420-23-000007:notes:1]

[0000080420-23-000027:notes:2]
[same as prior period, unchanged from 0000080420-23-000007:notes:2]

[0000080420-23-000027:notes:3]
[same as prior period, unchanged from 0000080420-23-000007:notes:3]

[0000080420-23-000027:notes:4]
[same as prior period, unchanged from 0000080420-23-000007:notes:4]

[0000080420-23-000027:notes:5]
[same as prior period, unchanged from 0000080420-23-000007:notes:5]

[0000080420-23-000027:notes:6]
[same as prior period, unchanged from 0000080420-23-000007:notes:6]

[0000080420-23-000027:notes:7]
[same as prior period, unchanged from 0000080420-23-000007:notes:7]

[0000080420-23-000027:notes:8]
[same as prior period, unchanged from 0000080420-23-000007:notes:8]

[0000080420-23-000027:notes:9]
[same as prior period, unchanged from 0000080420-23-000007:notes:9]


## us-gaap:EarningsPerShareTextBlock

[0000080420-23-000027:notes:10]
[same as prior period, unchanged from 0000080420-23-000007:notes:10]

[0000080420-23-000027:notes:11]
[same as prior period, unchanged from 0000080420-23-000007:notes:11]

[0000080420-23-000027:notes:12]
|  | Three months ended March 31, |  | Six months ended March 31, |
|  | 2023 |  | 2022 |  | 2023 |  | 2022 |
| Numerator: |  |  |  |  |  |  |  |
| Net income (loss) | $ | 8,473 |  |  | $ | (1,217) |  |  | $ | 9,636 |  |  | $ | (4,063) |  |
| Denominator: |  |  |  |  |  |  |  |
| Weighted average basic shares | 11,878 |  |  | 11,801 |  |  | 11,869 |  |  | 11,783 |  |
| Dilutive effect of restricted stock units | 271 |  |  | — |  |  | 240 |  |  | — |  |
| Weighted average diluted shares | 12,149 |  |  | 11,801 |  |  | 12,109 |  |  | 11,783 |  |
| Earnings (loss) per share: |  |  |  |  |  |  |  |
| Basic | $ | 0.71 |  |  | $ | (0.10) |  |  | $ | 0.81 |  |  | $ | (0.34) |  |
| Diluted | $ | 0.70 |  |  | $ | (0.10) |  |  | $ | 0.80 |  |  | $ | (0.34) |  |

[0000080420-23-000027:notes:13]
For each of the three and six months ended March 31, 2022, we incurred net losses and therefore all potential common shares were deemed to be anti-dilutive.


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0000080420-23-000027:notes:14]
[same as prior period, unchanged from 0000080420-23-000007:notes:14]

[0000080420-23-000027:notes:15]
[same as prior period, unchanged from 0000080420-23-000007:notes:15]

[0000080420-23-000027:notes:16]
|  | March 31, 2023 |  | September 30, 2022 |
| Raw materials, parts and sub-assemblies, net | $ | 57,701 |  |  | $ | 49,213 |  |
| Work-in-progress | 989 |  |  | 1,202 |  |
| Total inventories | $ | 58,690 |  |  | $ | 50,415 |  |

[0000080420-23-000027:notes:17]
[same as prior period, unchanged from 0000080420-23-000007:notes:17]

[0000080420-23-000027:notes:18]
[same as prior period, unchanged from 0000080420-23-000007:notes:18]

[0000080420-23-000027:notes:19]
|  | Three months ended March 31, |  | Six months ended March 31, |
|  | 2023 |  | 2022 |  | 2023 |  | 2022 |
| Balance at beginning of period | $ | 2,380 |  |  | $ | 2,443 |  |  | $ | 2,345 |  |  | $ | 2,531 |  |
| Increase to warranty expense | 1,211 |  |  | 323 |  |  | 1,690 |  |  | 616 |  |
| Deduction for warranty charges | (882) |  |  | (421) |  |  | (1,335) |  |  | (803) |  |
| Change due to foreign currency translation | 2 |  |  | 2 |  |  | 11 |  |  | 3 |  |
| Balance at end of period | $ | 2,711 |  |  | $ | 2,347 |  |  | $ | 2,711 |  |  | $ | 2,347 |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0000080420-23-000027:notes:20]
[same as prior period, unchanged from 0000080420-23-000007:notes:20]

[0000080420-23-000027:notes:21]
[same as prior period, unchanged from 0000080420-23-000007:notes:21]

[0000080420-23-000027:notes:22]
[same as prior period, unchanged from 0000080420-23-000007:notes:22]

[0000080420-23-000027:notes:23]
[same as prior period, unchanged from 0000080420-23-000007:notes:23]

[0000080420-23-000027:notes:24]
We also have contracts to provide field service inspection, installation, commissioning, modification, and repair services, as well as retrofit and retrofill components for existing systems. If the service contract terms give us the right to invoice the customer for an amount that corresponds directly with the value of our performance completed to date (i.e., a service contract in which we bill a fixed amount for each hour of service provided), then we recognize revenue over time in each reporting period corresponding to the amount with which we have the right to invoice. Our performance obligations are satisfied as the work progresses. Revenues from our custom-engineered products and value-added services transferred to customers over time accounted for approximately 93% of total revenues for the three and six months ended March 31, 2023 and 94% of total revenues for the three and six months ended March 31, 2022.

[0000080420-23-000027:notes:25]
We also have sales orders for spare parts and replacement circuit breakers for switchgear that are obsolete or that are no longer produced by the original manufacturer. Revenues from these sales orders are recognized at the time we fulfill our performance obligation to the customer, which is typically upon shipment and represented approximately 7% of total revenues for the three and six months ended March 31, 2023 and 6% of total revenues for the three and six months ended March 31, 2022.

[0000080420-23-000027:notes:26]
[same as prior period, unchanged from 0000080420-23-000007:notes:26]

[0000080420-23-000027:notes:27]
[same as prior period, unchanged from 0000080420-23-000007:notes:27]

[0000080420-23-000027:notes:28]
[same as prior period, unchanged from 0000080420-23-000007:notes:28]

[0000080420-23-000027:notes:29]
[same as prior period, unchanged from 0000080420-23-000007:notes:29]

[0000080420-23-000027:notes:30]
Remaining unsatisfied performance obligations, which we refer to as backlog, represent the estimated transaction price for goods and services for which we have a material right, but work has not been performed. As of March 31, 2023, we had backlog of $1.0 billion, of which approximately $584.4 million is expected to be recognized as revenue within the next twelve months. Backlog may not be indicative of future operating results as orders may be cancelled or modified by our customers. Our backlog does not include service and maintenance-type contracts for which we have the right to invoice as services are performed.

[0000080420-23-000027:notes:31]
[same as prior period, unchanged from 0000080420-23-000007:notes:31]

[0000080420-23-000027:notes:32]
[same as prior period, unchanged from 0000080420-23-000007:notes:32]

[0000080420-23-000027:notes:33]
[same as prior period, unchanged from 0000080420-23-000007:notes:33]

[0000080420-23-000027:notes:34]
For the six months ended March 31, 2023 and 2022, our operating results were positively impacted by $7.4 million and $5.6 million, respectively, as a result of net changes in contract estimates related to projects in progress at the beginning of the respective period. These changes in estimates resulted primarily from favorable project execution and negotiations of variable consideration, discussed below, as well as revenue and reduced costs recognized from project cancellations and other changes in facts and circumstances during these periods. Gross unfavorable changes in contract estimates were immaterial for both the six months ended March 31, 2023 and 2022.

[0000080420-23-000027:notes:35]
[same as prior period, unchanged from 0000080420-23-000007:notes:35]

[0000080420-23-000027:notes:36]
[same as prior period, unchanged from 0000080420-23-000007:notes:36]

[0000080420-23-000027:notes:37]
[same as prior period, unchanged from 0000080420-23-000007:notes:37]

[0000080420-23-000027:notes:38]
[same as prior period, unchanged from 0000080420-23-000007:notes:38]

[0000080420-23-000027:notes:39]
[same as prior period, unchanged from 0000080420-23-000007:notes:39]

[0000080420-23-000027:notes:40]
[same as prior period, unchanged from 0000080420-23-000007:notes:40]

[0000080420-23-000027:notes:41]
[same as prior period, unchanged from 0000080420-23-000007:notes:41]

[0000080420-23-000027:notes:42]
[same as prior period, unchanged from 0000080420-23-000007:notes:42]

[0000080420-23-000027:notes:43]
[same as prior period, unchanged from 0000080420-23-000007:notes:43]

[0000080420-23-000027:notes:44]
Contract assets and liabilities as of March 31, 2023 and September 30, 2022 are summarized below (in thousands):

[0000080420-23-000027:notes:45]
|  | March 31, 2023 |  | September 30, 2022 |
| Contract assets | $ | 63,560 |  |  | $ | 88,351 |  |
| Contract liabilities | (178,217) |  |  | (79,857) |  |
| Net contract asset (liability) | $ | (114,657) |  |  | $ | 8,494 |  |

[0000080420-23-000027:notes:46]
Our net contract billing position improved to a net liability at March 31, 2023 from a net asset position at September 30, 2022 primarily due to favorable contract billing milestones. We typically allocate a significant percentage of the progress billing to the early stages of the contract. These favorable billing milestones along with our increase in project backlog are driving the

[0000080420-23-000027:notes:47]
increase in the net contract liability at March 31, 2023. To determine the amount of revenue recognized during the period from contract liabilities, we first allocate revenue to the individual contract liability balance outstanding at the beginning of the period until the revenue exceeds that balance. During the six months ended March 31, 2023, we recognized revenue of approximately $58.7 million that was related to contract liabilities outstanding at September 30, 2022.

[0000080420-23-000027:notes:48]
The timing of our invoice process is typically dependent on the completion of certain milestones and contract terms and subject to agreement by our customer. Payment is typically expected within 30 days of invoice. Any uncollected invoiced amounts for our performance obligations recognized over time, including contract retentions, are recorded as accounts receivable in the Condensed Consolidated Balance Sheets. Certain contracts allow customers to withhold a small percentage of billings pursuant to retainage provisions, and such amounts are generally due upon completion of the contract and acceptance of the project by the customer. Based on our experience in recent years, the majority of these retainage balances are expected to be collected within approximately twelve months. As of March 31, 2023 and September 30, 2022, accounts receivable included retention amounts of $6.6 million and $6.9 million, respectively. Of the retained amount at March 31, 2023, $6.4 million is expected to be collected in the next twelve months and is recorded in accounts receivable. The remaining $0.2 million is recorded in other assets.

[0000080420-23-000027:notes:49]
[same as prior period, unchanged from 0000080420-23-000007:notes:49]

[0000080420-23-000027:notes:50]
The following tables present our disaggregated revenue by geographic destination and market sector for the three and six months ended March 31, 2023 and 2022 (in thousands):

[0000080420-23-000027:notes:51]
|  | Three months ended March 31, |  | Six months ended March 31, |
|  | 2023 |  | 2022 |  | 2023 |  | 2022 |
| United States | $ | 134,161 |  |  | $ | 86,992 |  |  | $ | 234,273 |  |  | $ | 169,137 |  |
| Canada | 21,995 |  |  | 22,053 |  |  | 40,491 |  |  | 37,178 |  |
| Europe, Middle East and Africa | 11,957 |  |  | 15,551 |  |  | 18,516 |  |  | 23,381 |  |
| Asia/Pacific | 1,788 |  |  | 1,646 |  |  | 2,564 |  |  | 2,590 |  |
| Mexico, Central and South America | 1,543 |  |  | 1,612 |  |  | 2,458 |  |  | 2,137 |  |
| Total revenues by geographic destination | $ | 171,444 |  |  | $ | 127,854 |  |  | $ | 298,302 |  |  | $ | 234,423 |  |

[0000080420-23-000027:notes:52]
|  | Three months ended March 31, |  | Six months ended March 31, |
|  | 2023 |  | 2022 |  | 2023 |  | 2022 |
| Oil and gas (excludes petrochemical) | $ | 62,597 |  |  | $ | 53,634 |  |  | $ | 106,107 |  |  | $ | 96,655 |  |
| Petrochemical | 25,887 |  |  | 18,853 |  |  | 48,377 |  |  | 36,081 |  |
| Electric utility | 42,668 |  |  | 30,374 |  |  | 71,075 |  |  | 51,907 |  |
| Traction power | 7,317 |  |  | 10,054 |  |  | 14,389 |  |  | 21,426 |  |
| Commercial and other industrial | 22,270 |  |  | 5,785 |  |  | 39,320 |  |  | 15,618 |  |
| All others | 10,705 |  |  | 9,154 |  |  | 19,034 |  |  | 12,736 |  |
| Total revenues by market sector | $ | 171,444 |  |  | $ | 127,854 |  |  | $ | 298,302 |  |  | $ | 234,423 |  |


## us-gaap:RevenueFromContractWithCustomerPolicyTextBlock

[0000080420-23-000027:notes:53]
[same as prior period, unchanged from 0000080420-23-000007:notes:53]

[0000080420-23-000027:notes:54]
[same as prior period, unchanged from 0000080420-23-000007:notes:54]

[0000080420-23-000027:notes:55]
[same as prior period, unchanged from 0000080420-23-000007:notes:55]

[0000080420-23-000027:notes:56]
[same as prior period, unchanged from 0000080420-23-000007:notes:56]

[0000080420-23-000027:notes:57]
[same as prior period, unchanged from 0000080420-23-000007:notes:57]


## us-gaap:LongTermDebtTextBlock

[0000080420-23-000027:notes:58]
Long-Term Debt
U.S Revolver

[0000080420-23-000027:notes:59]
On March 31, 2023, we entered into a second amendment (the Second Amendment) to our credit agreement with Bank of America, N.A. (as amended, the U.S. Revolver). The Second Amendment increased the revolving credit facility extended to us under the U.S. Revolver, which is available for both borrowings and letters of credit and expires September 27, 2024, from $75.0 million to $125.0 million. As amended by the Second Amendment, the U.S. Revolver states that the lesser of $50 million or 50% of readily and available cash may be deducted from the amount of letters of credit outstanding (not to be less than zero) when calculating the consolidated funded indebtedness, which is a component of the consolidated net leverage ratio. We have the option to cash collateralize all or a portion of the letters of credit outstanding, which would favorably impact the consolidated funded indebtedness calculation and the consolidated net leverage ratio. As of March 31, 2023, there were no amounts borrowed under the U.S. Revolver, and letters of credit outstanding were $44.8 million. There was $80.2 million available for the issuance of letters of credit and borrowings under the U.S. Revolver as of March 31, 2023.

[0000080420-23-000027:notes:60]
We are required to maintain certain financial covenants, the most significant of which are a consolidated net leverage ratio less than 3.0 to 1.0 and a consolidated interest coverage ratio of greater than 3.0 to 1.0. Our most restrictive covenant, the consolidated net leverage ratio, is the ratio of earnings before interest, taxes, depreciation, amortization and stock-based compensation (EBITDAS) to funded indebtedness. An increase in indebtedness, which includes letters of credit, or a decrease in EBITDAS could restrict our ability to issue letters of credit or borrow under the U.S. Revolver. Additionally, we must maintain a consolidated cash balance of $50 million at all times, which can be deducted from the letters of credit outstanding as noted above. The U.S. Revolver also contains a "material adverse effect" clause which is a material change in our operations, business, properties, liabilities or condition (financial or otherwise) or a material impairment of our ability to perform our obligations under our credit agreements. As of March 31, 2023, we were in compliance with all of the financial covenants of the U.S. Revolver.

[0000080420-23-000027:notes:61]
The U.S. Revolver allows the Company to elect that any borrowing under the facility bears an interest rate based on either the base rate or the eurocurrency rate, in each case, plus the applicable rate. The base rate is generally the highest of (a) the federal funds rate plus 0.50%, (b) the Bank of America prime rate or (c) the Bloomberg Short-Term Bank Yield Index (BSBY) rate plus 1.00%. The applicable rate is generally a range from 0% to 2% depending on the type of loan and the Company's consolidated net leverage ratio.

[0000080420-23-000027:notes:62]
The U.S. Revolver is collateralized by a pledge of 100% of the voting capital stock of each of our domestic subsidiaries and 65% of the voting capital stock of each non-domestic subsidiary. The U.S. Revolver provides for customary events of default and carries cross-default provisions with other existing debt agreements. If an event of default (as defined in the U.S. Revolver) occurs and is continuing, on the terms and subject to the conditions set forth in the U.S. Revolver, amounts and letters of credit outstanding under the U.S. Revolver may be accelerated and may become immediately due and payable.

[0000080420-23-000027:notes:63]
Industrial Development Revenue Bonds

[0000080420-23-000027:notes:64]
We borrowed $8.0 million in October 2001 through a loan agreement funded with proceeds from tax-exempt industrial development revenue bonds (Bonds) for the completion of our Northlake, Illinois facility. The Bonds matured on October 1, 2021 and our final payment of $0.4 million was made.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0000080420-23-000027:notes:65]
Commitments and Contingencies
Letters of Credit, Bank Guarantees and Bonds

[0000080420-23-000027:notes:66]
Certain customers require us to post letters of credit, bank guarantees or surety bonds. These security instruments assure that we will perform under the terms of our contract. In the event of default, the counterparty may demand payment from the bank under a letter of credit or bank guarantee, or performance by the surety under a bond. To date, there have been no significant draws or claims related to security instruments for the periods reported. We were contingently liable for letters of credit of $44.8 million as of March 31, 2023. We also had surety bonds totaling $294.2 million that were outstanding, with additional bonding capacity of $305.8 million available, at March 31, 2023. We have strong surety relationships; however, a change in market conditions or the sureties' assessment of our financial position could cause the sureties to require cash collateralization for undischarged liabilities under the bonds.

[0000080420-23-000027:notes:67]
We have a $9.9 million facility agreement (Facility Agreement) between Powell (UK) Limited and a large international bank that provides Powell (UK) Limited the ability to enter into bank guarantees as well as forward exchange contracts and currency options. At March 31, 2023, we had outstanding guarantees totaling $7.7 million. The Facility Agreement provides for customary events of default and carries cross-default provisions with our Second Amendment. If an event of default (as defined in the Facility Agreement) occurs and is continuing, per the terms and subject to the conditions set forth therein, obligations outstanding under the Facility Agreement may be accelerated and declared immediately due and payable. Additionally, we are required to maintain cash collateral for guarantees greater than two years. As of March 31, 2023, we were in compliance with all of the financial covenants of the Facility Agreement.

[0000080420-23-000027:notes:68]
Litigation

[0000080420-23-000027:notes:69]
We are involved in various legal proceedings, claims and other disputes arising from our commercial operations, projects, employees and other matters which, in general, are subject to uncertainties and in which the outcomes are not predictable. Although we can give no assurances about the resolution of pending claims, litigation or other disputes, and the effect such outcomes may have on us, management believes that any ultimate liability resulting from the outcome of such proceedings, to the extent not otherwise provided or covered by insurance, will not have a material adverse effect on our consolidated financial position or results of operations or liquidity.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0000080420-23-000027:notes:70]
[same as prior period, unchanged from 0000080420-23-000007:notes:71]

[0000080420-23-000027:notes:71]
[same as prior period, unchanged from 0000080420-23-000007:notes:72]

[0000080420-23-000027:notes:72]
On February 15, 2023, at the 2023 Annual Meeting of Stockholders, our stockholders approved an amendment to the Company's 2014 Equity Incentive Plan (the 2014 Plan) that extended the term of the 2014 Plan by five years and increased the number of shares of common stock that may be issued under the 2014 Plan by 600,000 shares for a total of 1,350,000 shares.

[0000080420-23-000027:notes:73]
We issue restricted stock units (RSUs) to certain officers and key employees of the Company. The fair value of the RSUs is based on the price of our common stock as reported on the NASDAQ Global Market on the grant dates. Typically, these grants vest over a three-year period from the date of issuance and are a blend of time-based and performance-based shares. The portion of the grant that is time-based typically vests over a three-year period on each anniversary of the grant date, based on continued employment. The performance-based shares vest based on the three-year earnings performance of the Company following the grant date. At March 31, 2023, there were 295,417 RSUs outstanding. The RSUs do not have voting rights but do receive dividend equivalents upon vesting which are accrued quarterly. Additionally, the shares of common stock underlying the RSUs are not considered issued and outstanding until vested and common stock is issued.

[0000080420-23-000027:notes:74]
Total RSU activity (number of shares) for the six months ended March 31, 2023 is summarized below:

[0000080420-23-000027:notes:75]
|  | Number ofRestrictedStockUnits |  | WeightedAverageGrant ValuePer Share |
| Outstanding at September 30, 2022 | 239,862 |  |  | $ | 26.11 |  |
| Granted | 147,100 |  |  | 21.26 |  |
| Vested | (76,834) |  |  | 29.42 |  |
| Forfeited/canceled | (14,711) |  |  | 38.58 |  |
| Outstanding at March 31, 2023 | 295,417 |  |  | $ | 22.85 |  |

[0000080420-23-000027:notes:76]
During the six months ended March 31, 2023 and 2022, we recorded compensation expense of $2.5 million and $1.4 million, respectively, related to the RSUs.

[0000080420-23-000027:notes:77]
Restricted Stock
Each non-employee director receives 2,400 restricted shares of the Company’s common stock annually. Fifty-percent of the restricted stock granted to each of our non-employee directors vests immediately, while the remaining fifty-percent vests on the anniversary of the grant date. Compensation expense is recognized immediately for the first fifty-percent of the restricted stock granted, while compensation expense for the remaining fifty-percent is recognized over the remaining vesting period. In February 2023, 16,800 shares of restricted stock were issued to our non-employee directors under the 2014 Non-Employee Director Equity Incentive Plan, as amended, at a price of $43.22 per share. During the six months ended March 31, 2023 and 2022, we recorded compensation expense of less than $0.5 million and $0.3 million, respectively, related to restricted stock.


## us-gaap:FairValueDisclosuresTextBlock

[0000080420-23-000027:notes:78]
[same as prior period, unchanged from 0000080420-23-000007:notes:78]

[0000080420-23-000027:notes:79]
[same as prior period, unchanged from 0000080420-23-000007:notes:79]

[0000080420-23-000027:notes:80]
[same as prior period, unchanged from 0000080420-23-000007:notes:80]

[0000080420-23-000027:notes:81]
[same as prior period, unchanged from 0000080420-23-000007:notes:81]

[0000080420-23-000027:notes:82]
[same as prior period, unchanged from 0000080420-23-000007:notes:82]

[0000080420-23-000027:notes:83]
The following table summarizes the fair value of our assets and liabilities that were accounted for at fair value on a recurring basis as of March 31, 2023 (in thousands):

[0000080420-23-000027:notes:84]
|  | Fair Value Measurements at March 31, 2023 |
|  | Quoted Prices inActive Markets forIdentical Assets(Level 1) |  | Significant OtherObservableInputs(Level 2) |  | SignificantUnobservableInputs(Level 3) |  | Fair Value at March 31,2023 |
| Assets: |  |  |  |  |  |  |  |
| Cash and cash equivalents | $ | 152,039 |  |  | $ | — |  |  | $ | — |  |  | $ | 152,039 |  |
| Short-term investments | 11,085 |  |  | — |  |  | — |  |  | 11,085 |  |
| Other assets | — |  |  | 8,404 |  |  | — |  |  | 8,404 |  |
| Liabilities: |  |  |  |  |  |  |  |
| Deferred compensation | — |  |  | 9,098 |  |  | — |  |  | 9,098 |  |

[0000080420-23-000027:notes:85]
[same as prior period, unchanged from 0000080420-23-000007:notes:85]

[0000080420-23-000027:notes:86]
[same as prior period, unchanged from 0000080420-23-000007:notes:86]

[0000080420-23-000027:notes:87]
[same as prior period, unchanged from 0000080420-23-000007:notes:87]

[0000080420-23-000027:notes:88]
[same as prior period, unchanged from 0000080420-23-000007:notes:88]

[0000080420-23-000027:notes:89]
[same as prior period, unchanged from 0000080420-23-000007:notes:89]

[0000080420-23-000027:notes:90]
[same as prior period, unchanged from 0000080420-23-000007:notes:90]

[0000080420-23-000027:notes:91]
There were no transfers between levels within the fair value measurement hierarchy during the quarter ended March 31, 2023.


## us-gaap:LesseeOperatingLeasesTextBlock

[0000080420-23-000027:notes:92]
Leases
Our leases consist primarily of office and manufacturing space and construction equipment. All of our future lease obligations are related to non-cancelable operating leases. The most significant portion of our lease portfolio relates to leases of office and manufacturing facilities in Canada that we no longer occupy. We currently sublease the majority of these Canadian facilities. The following table provides a summary of lease cost components for the three and six months ended March 31, 2023 and 2022, respectively (in thousands):

[0000080420-23-000027:notes:93]
|  |  | Three months ended March 31, |  | Six months ended March 31, |
| Lease Cost |  | 2023 |  | 2022 |  | 2023 |  | 2022 |
| Operating lease cost |  | $ | 378 |  |  | $ | 573 |  |  | $ | 755 |  |  | $ | 1,143 |  |
| Less: sublease income |  | (163) |  |  | (173) |  |  | (324) |  |  | (347) |  |
| Variable lease cost(1) |  | 88 |  |  | 117 |  |  | 195 |  |  | 258 |  |
| Short-term lease cost(2) |  | 430 |  |  | 579 |  |  | 817 |  |  | 852 |  |
| Total lease cost |  | $ | 733 |  |  | $ | 1,096 |  |  | $ | 1,443 |  |  | $ | 1,906 |  |

[0000080420-23-000027:notes:94]
[same as prior period, unchanged from 0000080420-23-000007:notes:94]

[0000080420-23-000027:notes:95]
[same as prior period, unchanged from 0000080420-23-000007:notes:95]

[0000080420-23-000027:notes:96]
We recognize operating lease assets and operating lease liabilities representing the present value of the remaining lease payments for leases with initial terms greater than twelve months. Leases with initial terms of twelve months or less are not recorded in our Condensed Consolidated Balance Sheets. As of both March 31, 2023 and September 30, 2022, our operating lease assets have been reduced by a lease accrual of $0.1 million related to certain unused facility leases in Canada. The following table provides a summary of the operating lease assets and operating lease liabilities included in our Condensed Consolidated Balance Sheets as of March 31, 2023 and September 30, 2022, respectively (in thousands):

[0000080420-23-000027:notes:97]
| Operating Leases |  | March 31, 2023 |  | September 30, 2022 |
| Assets: |  |  |  |  |
| Operating lease assets, net |  | $ | 1,665 |  |  | $ | 2,179 |  |
| Liabilities: |  |  |  |  |
| Current operating lease liabilities |  | 989 |  |  | 1,777 |  |
| Long-term operating lease liabilities |  | 731 |  |  | 545 |  |
| Total lease liabilities |  | $ | 1,720 |  |  | $ | 2,322 |  |

[0000080420-23-000027:notes:98]
The following table provides the maturities of our operating lease liabilities as of March 31, 2023 (in thousands):

[0000080420-23-000027:notes:99]
|  |  | Operating Leases |  |  |
| Remainder of 2023 |  | $ | 756 |  |  |  |
| 2024 |  | 502 |  |  |  |
| 2025 |  | 233 |  |  |  |
| 2026 |  | 144 |  |  |  |
| 2027 |  | 131 |  |  |  |
| Thereafter |  | 18 |  |  |  |
| Total future minimum lease payments |  | $ | 1,784 |  |  |  |
| Less: present value discount (imputed interest) |  | (64) |  |  |  |
| Present value of lease liabilities |  | $ | 1,720 |  |  |  |

[0000080420-23-000027:notes:100]
The weighted average discount rate as of March 31, 2023 was 3.5%. The weighted average remaining lease term was 2.35 years at March 31, 2023.


## us-gaap:IncomeTaxDisclosureTextBlock

[0000080420-23-000027:notes:101]
[same as prior period, unchanged from 0000080420-23-000007:notes:101]

[0000080420-23-000027:notes:102]
|  | Three months ended March 31, |  | Six months ended March 31, |
|  | 2023 |  | 2022 |  | 2023 |  | 2022 |
| Income (loss) before income taxes | $ | 10,973 |  |  | $ | 595 |  |  | $ | 12,587 |  |  | $ | (3,692) |  |
| Income tax provision | 2,500 |  |  | 1,812 |  |  | 2,951 |  |  | 371 |  |
| Net income (loss) | $ | 8,473 |  |  | $ | (1,217) |  |  | $ | 9,636 |  |  | $ | (4,063) |  |
| Effective tax rate | 23 | % |  | 305 | % |  | 23 | % |  | (10) | % |

[0000080420-23-000027:notes:103]
Our income tax provision reflects an effective tax rate on pre-tax income of 23% for both the three and six months ended March 31, 2023 compared to an income tax provision that reflects an effective tax rate on pre-tax income of 305% for the three months ended March 31, 2022 and negative 10% for the six months ended March 31, 2022. The effective tax rate for the three and six months ended March 31, 2023 approximated the U.S. federal statutory rate. The favorable impacts of the estimated Research and Development Tax Credit (R&D Tax Credit) and the projected utilization of net operating loss carryforwards in the UK that have been fully reserved with a valuation allowance were offset by state income tax expense, certain nondeductible expenses and an income inclusion related to U.S. global intangible income.
For the three and six months ended March 31, 2022, the effective tax rate was largely impacted by the change in the annual estimated relative amounts of income (loss) recognized in the various tax jurisdictions as well as the impacts of accounting for income taxes in interim reporting periods. During interim reporting periods, the provision for income taxes is calculated by applying an estimated annual effective tax rate to year-to-date ordinary pre-tax income (loss). As a result, a significant variation in the customary relationship between income tax expense and pre-tax income may occur. Due to the estimated R&D Tax Credit as well as the projected utilization of net operating loss carryforwards in Canada that were fully reserved with a valuation allowance, we projected an income tax benefit for the full fiscal year ended September 30, 2022, which resulted in a negative effective tax rate. When this annual effective tax rate was applied to the year-to-date loss, a tax provision resulted for the three and six months ended March 31, 2022.


## us-gaap:SubsequentEventsTextBlock

[0000080420-23-000027:notes:104]
Subsequent Events
Quarterly Dividend Declared

[0000080420-23-000027:notes:105]
On May 2, 2023, our Board of Directors declared a quarterly cash dividend on our common stock in the amount of $0.2625 per share. The dividend is payable on June 14, 2023 to shareholders of record at the close of business on May 17, 2023.
