# POWL MD&A — 0000080420-25-000098


## mdna

[0000080420-25-000098:mdna:1]
[same as prior period, unchanged from 0000080420-25-000061:mdna:1]

[0000080420-25-000098:mdna:2]
[same as prior period, unchanged from 0000080420-25-000061:mdna:2]

[0000080420-25-000098:mdna:3]
[same as prior period, unchanged from 0000080420-25-000061:mdna:3]

[0000080420-25-000098:mdna:4]
[same as prior period, unchanged from 0000080420-25-000061:mdna:4]

[0000080420-25-000098:mdna:5]
In the third quarter of Fiscal 2025, we reported revenues of $286.3 million, net income of $48.2 million, and generated $106.9 million in cash from operating activities. As of June 30, 2025, we had total assets of $1.0 billion.

[0000080420-25-000098:mdna:6]
[same as prior period, unchanged from 0000080420-25-000061:mdna:6]

[0000080420-25-000098:mdna:7]
Our backlog increased to $1.4 billion as of June 30, 2025, of which approximately $913 million is expected to be recognized as revenue within the next twelve months. Although current commercial activity remains active in most of the markets that we compete in, we remain attentive to the macro environment and geopolitical events that may have an impact on future market activity.

[0000080420-25-000098:mdna:8]
Oil and gas and petrochemical markets. The North American market is responding to increased international demand for Liquefied Natural Gas (LNG) and gas-to-chemical processes utilizing low-cost gas feedstocks. We believe the fundamentals of the U.S. natural gas market, through abundant supply and low cost, will continue to support investments in LNG, related gas processing, and petrochemical processes, and as a result, will continue to sustain our order activity associated with such markets, which is evidenced by two large, domestic LNG project awards during the first half of Fiscal 2025. Other oil and gas end markets are also experiencing increased commercial activity as we secured two large, offshore projects in our core oil and gas end markets during the third fiscal quarter. In addition to the traditional crude oil refining and other oil and gas downstream processes, we have expanded our end markets into hydrogen production, carbon capture as well as alternative fuels, such as biofuels and sustainable aviation fuel, in response to the demand for clean energy.

[0000080420-25-000098:mdna:9]
Electric utility market. Aligned with our strategy of end-market diversification, we seek to continue our focus and growth in electrical distribution substations, while also addressing a resurgence of power generation investment in this market. During the third fiscal quarter, we won a project for a new power generation plant, representing the largest electric utility award in the Company's history.

[0000080420-25-000098:mdna:10]
Commercial and other industrial markets. As a result of a mix of factors we are experiencing strong growth in commercial facilities that provide for the production of various consumer goods and the expansion of data centers that support cloud computing and increasing investments in artificial intelligence. We are also experiencing increased activity in other industrial end markets which includes the large mining project that we secured in the first half of Fiscal 2025 for the production of potash.

[0000080420-25-000098:mdna:11]
Additionally, we booked an order for a domestic traction power project in the current quarter, representing the first large traction power project booked in several quarters.

[0000080420-25-000098:mdna:12]
[same as prior period, unchanged from 0000080420-25-000061:mdna:11]

[0000080420-25-000098:mdna:13]
[same as prior period, unchanged from 0000080420-25-000061:mdna:12]

[0000080420-25-000098:mdna:14]
Our operating results are impacted by several factors such as the timing of new order awards, project backlog, changes in project cost estimates, customer approval of final engineering specifications and delays in customer construction schedules, all of which contribute to short-term earnings variability and the timing of project execution. Our operating results also have been,

[0000080420-25-000098:mdna:15]
and may continue to be, impacted by the timing and resolution of change orders and the resolution of potential contract claims and liquidated damages, all of which could improve or deteriorate gross margins during the period in which these items are resolved with our customers. Disruptions in the global supply chain have negatively impacted and may continue to negatively impact our business and operating results due to the limited supply of, delays for and uncertainty in the timing of the receipt of key component parts and commodities. We continue to remain focused on the variables that impact our markets as well as cost management, labor availability and supply chain challenges.

[0000080420-25-000098:mdna:16]
[same as prior period, unchanged from 0000080420-25-000061:mdna:15]

[0000080420-25-000098:mdna:17]
During the first nine months of Fiscal 2025, we experienced an increase in volatility for commodity prices and ongoing supply chain delays for specific engineered components that remain a persistent challenge. Moreover, ongoing and recently proposed changes to U.S. global trade policy, along with potential international retaliatory measures, have continued to cause high volatility in global markets and uncertainty around short- and long-term economic impacts in the United States and other markets we serve, including concerns over inflation, recession and slowing growth. We continue to evaluate and monitor the potential impacts of these changes and measures, including the imposition of tariffs, on our business and operations. We could potentially face the challenge of increased costs of raw materials and engineered components as well as negative impacts on our margins; however, it is not possible to predict the impact, if any, of any changes or proposed changes to the U.S. global trade policy, or any international retaliatory measures, on our business and operations. In response to the rising cost environment and persistent supply chain challenges, we are taking strategic measures to effectively manage our product pricing, refine delivery schedules, and manage bid validity dates with our customers. Our supplier engagement includes improving forecasting and negotiating favorable terms that allow us to meet or exceed customer timelines. Additionally, we remain focused on enhancing factory efficiencies and improving project execution to mitigate risks and maintain customer satisfaction.

[0000080420-25-000098:mdna:18]
On July 4, 2025, President Trump signed into law the One Big Beautiful Bill Act (the OBBBA), which includes a broad range of tax reform provisions affecting businesses. The OBBBA extends and modifies certain key 2017 Tax Cuts & Jobs Act (TCJA) provisions (both domestic and international) and revamps some of the TCJA’s provisions on the taxation of corporations’ foreign income. The OBBBA also expands certain Inflation Reduction Act incentives while accelerating the phase-out of others. We are currently evaluating the impact of the OBBBA on our operations, financial results and liquidity.

[0000080420-25-000098:mdna:19]
[same as prior period, unchanged from 0000080420-25-000061:mdna:17]

[0000080420-25-000098:mdna:20]
Quarter Ended June 30, 2025 Compared to the Quarter Ended June 30, 2024 (Unaudited)

[0000080420-25-000098:mdna:21]
[same as prior period, unchanged from 0000080420-25-000061:mdna:19]

[0000080420-25-000098:mdna:22]
Revenues decreased by 1%, or $1.9 million, to $286.3 million in the third quarter of Fiscal 2025. Domestic revenues decreased by 8%, or $19.2 million, to $224.5 million in the third quarter of Fiscal 2025. International revenues increased by 39%, or $17.3 million, to $61.7 million in the third quarter of Fiscal 2025, primarily driven by increased project volume from our Canada operations and increased activity in the Middle East and Africa region. Our international revenues include both revenues generated from our international facilities as well as revenues from export projects generated at our domestic facilities.

[0000080420-25-000098:mdna:23]
In the third quarter of Fiscal 2025, revenue from our electric utility market increased by 31%, or $17.9 million, to $74.9 million; commercial and other industrial market revenue increased by 18%, or $7.5 million, to $49.5 million; and revenue from our light rail traction power market increased by 61%, or $3.2 million, to $8.5 million. These increases in revenue were primarily driven by our strategic effort to expand our business into electric utility and commercial and other industrial markets and the improved market conditions in these end markets. Revenue from our oil and gas market (excluding petrochemical) decreased by 8%, or $8.9 million, to $105.5 million; and revenue from our petrochemical market decreased by 36%, or $20.4 million, to $36.3 million in the third quarter of Fiscal 2025. These decreases in revenue were primarily driven by project timing within the oil and gas market as well as the reduction in backlog within the petrochemical market as the business nears completion of the large petrochemical order secured in Fiscal 2023. Revenue from all other markets combined decreased by 9%, or $1.2 million, to $11.5 million in the third quarter of Fiscal 2025 due to less project volume.

[0000080420-25-000098:mdna:24]
Gross profit increased by 8%, or $6.2 million, to $87.9 million for the third quarter of Fiscal 2025. Gross profit as a percentage of revenues increased to 31% in the third quarter of Fiscal 2025, as compared to 28% in the third quarter of Fiscal 2024. The increase in gross profit was primarily driven by favorable volume leverage, strong project execution, as well as the benefit from project closeouts in the third quarter of Fiscal 2025.

[0000080420-25-000098:mdna:25]
[same as prior period, unchanged from 0000080420-25-000061:mdna:23]

[0000080420-25-000098:mdna:26]
Selling, general and administrative expenses increased by 14%, or $3.1 million, to $25.1 million in the third quarter of Fiscal 2025, primarily due to increased compensation and acquisition related expense. Selling, general and administrative expenses as a percentage of revenues increased to 9% during the third quarter of Fiscal 2025 compared to 8% during the third quarter of Fiscal 2024.

[0000080420-25-000098:mdna:27]
[same as prior period, unchanged from 0000080420-25-000061:mdna:25]

[0000080420-25-000098:mdna:28]
We recorded an income tax provision of $15.9 million in the third quarter of Fiscal 2025, compared to an income tax provision of $15.6 million in the third quarter of Fiscal 2024. The effective tax rate for the third quarter of Fiscal 2025 and 2024 was 25%. For each of the three months ended June 30, 2025 and 2024, the effective tax rate was favorably impacted by the estimated Research and Development (R&D) Tax Credit, which was offset by the tax expense related to certain nondeductible items. Additionally, in the third quarter of Fiscal 2024, this benefit was offset by an income inclusion related to U.S. global intangible income. For further information regarding our income taxes, see Note J of the Notes to Condensed Consolidated Financial Statements.

[0000080420-25-000098:mdna:29]
[same as prior period, unchanged from 0000080420-25-000061:mdna:27]

[0000080420-25-000098:mdna:30]
In the third quarter of Fiscal 2025, we recorded net income of $48.2 million, or $3.96 per diluted share, compared to net income of $46.2 million, or $3.79 per diluted share, in the third quarter of Fiscal 2024. The increase in net income was primarily driven by improved gross profit margin in the third quarter of Fiscal 2025.

[0000080420-25-000098:mdna:31]
[same as prior period, unchanged from 0000080420-25-000061:mdna:29]

[0000080420-25-000098:mdna:32]
The order backlog, which is our remaining unsatisfied performance obligations, represents the estimated transaction price for goods and services for which we have a material right, but work has not been performed. The order backlog at June 30, 2025 was $1.4 billion, a 7% increase from our $1.3 billion backlog at March 31, 2025. This increase was mainly driven by electric utility, oil and gas, and light rail traction power markets, partially offset by a decrease in the petrochemical market. As of June 30, 2025, oil and gas (excluding petrochemical) market accounted for 36%, electric utility market accounted for 32%, and commercial and other industrial market accounted for 11% of our backlog.

[0000080420-25-000098:mdna:33]
Bookings, net of cancellations and scope reductions, increased by 2% in the third quarter of Fiscal 2025 to $362.1 million, compared to $356.3 million in the third quarter of Fiscal 2024.

[0000080420-25-000098:mdna:34]
Nine Months Ended June 30, 2025 Compared to the Nine Months Ended June 30, 2024 (Unaudited)

[0000080420-25-000098:mdna:35]
[same as prior period, unchanged from 0000080420-25-000061:mdna:32]

[0000080420-25-000098:mdna:36]
Revenues increased by 9%, or $69.0 million, to $806.3 million in the nine months ended June 30, 2025, primarily driven by strong project backlog at the end of Fiscal 2024 and strong bookings that continued in the first nine months of Fiscal 2025. Domestic revenues increased by 5%, or $29.6 million, to $650.1 million in the nine months ended June 30, 2025. International revenues increased by 34%, or $39.4 million, to $156.2 million in the nine months ended June 30, 2025, primarily driven by increased project volume from our Canada operations and increased activity in the Middle East and Africa region. Our international revenues include both revenues generated from our international facilities as well as revenues from export projects generated at our domestic facilities.

[0000080420-25-000098:mdna:37]
In the nine months ended June 30, 2025, revenue from our oil and gas market (excluding petrochemical) increased by $0.5 million, to $302.3 million; revenue from our electric utility market increased by 35%, or $51.3 million, to $196.5 million; commercial and other industrial market revenue increased by 32%, or $32.6 million, to $134.2 million; and revenue from our light rail traction power market increased by 89%, or $12.6 million, to $26.8 million. These increases in revenue were primarily driven by our strategic effort to expand our business into electric utility and commercial and other industrial markets and the improved market conditions in these end markets. Revenue from our petrochemical market decreased by 16%, or $22.0 million, to $113.2 million with the reduction in backlog in this market and as the business nears completion of the large petrochemical order secured in Fiscal 2023. Revenue from all other markets combined decreased by 15%, or $5.9 million, to $33.3 million in the nine months ended June 30, 2025 due to less project volume.

[0000080420-25-000098:mdna:38]
Gross profit increased by 20%, or $38.2 million, to $230.9 million for the nine months ended June 30, 2025. Gross profit as a percentage of revenues increased to 29% in the first nine months of Fiscal 2025, compared to 26% in the first nine months of

[0000080420-25-000098:mdna:39]
Fiscal 2024. The increase in gross profit was primarily driven by higher revenues in the first nine months of Fiscal 2025 and strong gross profit margin in Fiscal 2025 due to favorable volume leverage, strong project execution, as well as the benefit from project closeouts in the period.

[0000080420-25-000098:mdna:40]
[same as prior period, unchanged from 0000080420-25-000061:mdna:36]

[0000080420-25-000098:mdna:41]
Selling, general and administrative expenses increased by 8%, or $5.0 million, to $68.4 million in the nine months ended June 30, 2025, primarily due to increased compensation and acquisition related expense. Selling, general and administrative expenses as a percentage of revenues decreased to 8% during the first nine months of Fiscal 2025, compared to 9% during the first nine months of Fiscal 2024, resulting from higher revenues on our existing cost structure.

[0000080420-25-000098:mdna:42]
[same as prior period, unchanged from 0000080420-25-000061:mdna:38]

[0000080420-25-000098:mdna:43]
We recorded an income tax provision of $36.7 million in the nine months ended June 30, 2025, compared to an income tax provision of $31.8 million in the nine months ended June 30, 2024. The effective tax rate for the nine months ended June 30, 2025 was 22%, compared to an effective tax rate of 23% for the nine months ended June 30, 2024. For each of the nine months ended June 30, 2025 and 2024, the effective tax rate was favorably impacted by discrete items primarily related to the vesting of RSUs and the estimated R&D Tax Credit, which was offset by the tax expense related to certain nondeductible items. For further information regarding our income taxes, see Note J of the Notes to Condensed Consolidated Financial Statements.

[0000080420-25-000098:mdna:44]
[same as prior period, unchanged from 0000080420-25-000061:mdna:40]

[0000080420-25-000098:mdna:45]
In the nine months ended June 30, 2025, we recorded net income of $129.3 million, or $10.63 per diluted share, compared to net income of $103.8 million, or $8.52 per diluted share, in the nine months ended June 30, 2024. The increase in net income was primarily driven by higher revenue and improved gross profit margin in the first nine months of Fiscal 2025.

[0000080420-25-000098:mdna:46]
[same as prior period, unchanged from 0000080420-25-000061:mdna:42]

[0000080420-25-000098:mdna:47]
The order backlog, which is our remaining unsatisfied performance obligations, represents the estimated transaction price for goods and services for which we have a material right, but work has not been performed. The order backlog at June 30, 2025 was $1.4 billion, a 6% increase from our $1.3 billion backlog at September 30, 2024. This increase was mainly driven by electric utility, and oil and gas markets, partially offset by a decrease in the petrochemical market. As of June 30, 2025, oil and gas (excluding petrochemical) market accounted for 36%, electric utility market accounted for 32%, and commercial and other industrial market accounted for 11% of our backlog.

[0000080420-25-000098:mdna:48]
Bookings, net of cancellations and scope reductions, increased by 11% during the nine months ended June 30, 2025 to $879.7 million, compared to $789.2 million during the nine months ended June 30, 2024. This increase was primarily driven by improved bookings in oil and gas, electric utility and light rail traction power markets, partially offset by decreased net bookings in petrochemical and commercial and other industrial markets.

[0000080420-25-000098:mdna:49]
[same as prior period, unchanged from 0000080420-25-000061:mdna:44]

[0000080420-25-000098:mdna:50]
As of June 30, 2025, current assets exceeded current liabilities by 2.1 times.

[0000080420-25-000098:mdna:51]
Cash, cash equivalents and short-term investments increased to $433.0 million at June 30, 2025, compared to $358.4 million at September 30, 2024. The increase in cash, cash equivalents and short-term investments was primarily driven by our improved earnings due to higher gross profit, partially offset by capital spending, dividend payments, and cash payments related to shares withheld in lieu of employee tax withholding. We believe that our cash, cash equivalents and short-term investments, as well as available borrowings under our U.S. credit facility, will be sufficient to support our future operating activities, working capital requirements, payment of dividends and capital spending, as well as research and development initiatives for the next twelve months and beyond. As we assess our capital allocation framework relative to our strategic objectives, we will continue to deploy capital to both organic and inorganic initiatives, as well as maintain a prudent approach to other methods that improve shareholder value.

[0000080420-25-000098:mdna:52]
Approximately $73.3 million of our cash, cash equivalents and short-term investments at June 30, 2025 was held outside of the U.S. for our international operations. It is our intention to indefinitely reinvest all current and future foreign earnings internationally in order to ensure sufficient working capital to support our international operations. In the event that we elect to repatriate some or all of the foreign earnings that were previously deemed to be indefinitely reinvested outside the U.S., we may incur additional tax expense upon such repatriation under current tax laws.

[0000080420-25-000098:mdna:53]
[same as prior period, unchanged from 0000080420-25-000061:mdna:48]

[0000080420-25-000098:mdna:54]
[same as prior period, unchanged from 0000080420-25-000061:mdna:49]

[0000080420-25-000098:mdna:55]
As of June 30, 2025, there were no amounts borrowed under the U.S. Revolver, and letters of credit outstanding were $76.0 million. There was $74.0 million available for the issuance of letters of credit and borrowings under the U.S. Revolver as of June 30, 2025. For further information regarding our debt, see Notes E and F of the Notes to Condensed Consolidated Financial Statements.

[0000080420-25-000098:mdna:56]
[same as prior period, unchanged from 0000080420-25-000061:mdna:51]

[0000080420-25-000098:mdna:57]
[same as prior period, unchanged from 0000080420-25-000061:mdna:52]

[0000080420-25-000098:mdna:58]
Operating activities provided net cash of $106.9 million during the nine months ended June 30, 2025, and provided net cash of $114.7 million during the same period in Fiscal 2024. Cash flow from operations is primarily influenced by project volume and margins, as well as working capital requirements, the timing of milestone payments from our customers, and payment terms with our suppliers. The decrease in operating cash flow was primarily due to working capital impact as we allocate capital to projects in the order book, partially offset by higher earnings.

[0000080420-25-000098:mdna:59]
[same as prior period, unchanged from 0000080420-25-000061:mdna:54]

[0000080420-25-000098:mdna:60]
Investing activities used $4.2 million of cash during the nine months ended June 30, 2025 and used $13.0 million of cash during the same period in Fiscal 2024. Cash used by investing activities in the first nine months of Fiscal 2025 was primarily due to capital spending on the facility expansion and improvement project at our electrical products facility in Houston, partially offset by net maturities of short-term investments. In December 2023, we acquired intellectual property for a total consideration of $0.5 million, of which $250 thousand was paid in cash.

[0000080420-25-000098:mdna:61]
The $11 million expansion and improvement project at our electrical products facility in Houston has been completed and the incremental capacity is now in service.

[0000080420-25-000098:mdna:62]
[same as prior period, unchanged from 0000080420-25-000061:mdna:57]

[0000080420-25-000098:mdna:63]
Net cash used in financing activities was $21.7 million during the nine months ended June 30, 2025 compared to $16.0 million used during the same period in Fiscal 2024. The increase in cash used in financing activities was primarily due to cash payments related to shares withheld in lieu of employee tax withholding, largely driven by the significant increase in our share price in the first nine months of Fiscal 2025 compared to the same period of Fiscal 2024.

[0000080420-25-000098:mdna:64]
[same as prior period, unchanged from 0000080420-25-000061:mdna:59]

[0000080420-25-000098:mdna:65]
[same as prior period, unchanged from 0000080420-25-000061:mdna:60]

[0000080420-25-000098:mdna:66]
[same as prior period, unchanged from 0000080420-25-000061:mdna:61]
