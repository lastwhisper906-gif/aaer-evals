# POWL 8-K — 0000080420-25-000095 filed 2025-08-05

## item codes, every 8-K on or before 2025-08-06

- 2025-08-05 0000080420-25-000095 — 2.02, 8.01, 9.01
- 2025-07-22 0000080420-25-000087 — 5.02
- 2025-05-06 0000080420-25-000057 — 2.02, 8.01, 9.01
- 2025-02-24 0000080420-25-000044 — 3.03, 5.03, 9.01
- 2025-02-19 0000080420-25-000034 — 5.03, 5.07, 9.01
- 2025-02-06 0000080420-25-000026 — 2.02, 9.01
- 2025-02-04 0000080420-25-000020 — 8.01, 9.01
- 2024-11-19 0000080420-24-000084 — 2.02, 9.01
- 2024-11-05 0000080420-24-000081 — 8.01, 9.01
- 2024-07-30 0000080420-24-000057 — 2.02, 8.01, 9.01
- 2024-04-30 0000080420-24-000026 — 2.02, 8.01, 9.01
- 2024-02-15 0000080420-24-000014 — 5.02, 5.07
- 2024-01-30 0000080420-24-000005 — 2.02, 8.01, 9.01
- 2024-01-08 0000080420-24-000002 — 5.02
- 2023-12-05 0000080420-23-000047 — 2.02, 9.01
- 2023-11-03 0000080420-23-000044 — 8.01, 9.01
- 2023-10-11 0000080420-23-000041 — 1.01, 2.03
- 2023-08-01 0000080420-23-000036 — 2.02, 8.01, 9.01
- 2023-05-19 0001193125-23-149334 — 5.07 — amendment of 0000080420-23-000011
- 2023-05-03 0000080420-23-000025 — 2.02, 8.01, 9.01
- 2023-04-06 0000080420-23-000020 — 1.01, 2.03, 9.01
- 2023-04-05 0000080420-23-000018 — 5.02
- 2023-02-16 0000080420-23-000011 — 5.02, 5.07, 9.01
- 2023-01-31 0000080420-23-000004 — 2.02, 8.01
- 2022-12-05 0000080420-22-000034 — 2.02, 9.01
- 2022-08-02 0000080420-22-000030 — 2.02, 8.01, 9.01
- 2022-05-13 0000080420-22-000024 — 5.02, 9.01
- 2022-05-03 0000080420-22-000016 — 2.02, 9.01
- 2022-05-03 0000080420-22-000015 — 8.01, 9.01
- 2022-02-17 0000080420-22-000010 — 5.07
- 2022-02-08 0000080420-22-000005 — 2.02, 9.01
- 2022-02-01 0000080420-22-000002 — 8.01, 9.01
- 2021-12-07 0000080420-21-000043 — 2.02, 9.01
- 2021-08-03 0000080420-21-000036 — 2.02, 8.01, 9.01
- 2021-05-04 0000080420-21-000026 — 2.02, 8.01, 9.01
- 2021-03-16 0001193125-21-082878 — 1.01, 2.03, 9.01
- 2021-03-05 0000080420-21-000021 — 5.02, 8.01, 9.01
- 2021-02-26 0000080420-21-000018 — 5.03
- 2021-02-18 0000080420-21-000016 — 5.07
- 2021-02-02 0000080420-21-000010 — 2.02, 8.01, 9.01
- 2020-12-08 0000080420-20-000032 — 2.02, 9.01
- 2020-11-12 0000080420-20-000030 — 8.01, 9.01
- 2020-08-04 0000080420-20-000024 — 2.02, 8.01, 9.01
- 2020-05-05 0000080420-20-000017 — 2.02, 8.01, 9.01
- 2020-02-21 0000080420-20-000008 — 5.07
- 2020-02-04 0000080420-20-000003 — 2.02, 8.01, 9.01
- 2019-12-04 0001193125-19-306243 — 2.02, 9.01
- 2019-11-08 0000080420-19-000032 — 8.01, 9.01
- 2019-10-03 0000080420-19-000030 — 1.01, 2.03
- 2019-09-24 0000080420-19-000028 — 8.01, 9.01
- 2019-08-06 0000080420-19-000022 — 2.02, 8.01, 9.01
- 2019-05-08 0000080420-19-000017 — 5.02, 9.01
- 2019-05-07 0000080420-19-000011 — 2.02, 8.01, 9.01
- 2019-02-22 0001193125-19-048366 — 5.07
- 2019-02-05 0000080420-19-000003 — 2.02, 8.01
- 2018-12-21 0000080420-18-000038 — 5.02, 9.01
- 2018-12-12 0000080420-18-000031 — 2.02
- 2018-11-05 0000080420-18-000029 — 8.01, 9.01
- 2018-11-01 0000080420-18-000027 — 5.02, 8.01, 9.01
- 2018-10-01 0000080420-18-000024 — 5.02
- 2018-08-07 0000080420-18-000020 — 2.02, 8.01
- 2018-05-15 0000080420-18-000016 — 5.02, 8.01
- 2018-05-09 0000080420-18-000011 — 2.02, 8.01
- 2018-02-22 0000080420-18-000009 — 5.07
- 2018-02-06 0000080420-18-000003 — 2.02, 8.01
- 2017-12-27 0001193125-17-379928 — 5.02
- 2017-12-05 0000080420-17-000028 — 2.02, 9.01
- 2017-11-08 0000080420-17-000024 — 8.01, 9.01
- 2017-11-03 0000080420-17-000022 — 5.02
- 2017-08-09 0000080420-17-000017 — 2.02, 8.01
- 2017-06-30 0000080420-17-000014 — 1.01, 9.01
- 2017-05-03 0000080420-17-000006 — 2.02, 8.01, 9.01
- 2017-02-23 0000080420-17-000004 — 5.07
- 2017-02-08 0001628280-17-000965 — 2.02 — amendment of 0001628280-17-000949
- 2017-02-07 0001628280-17-000949 — 2.01, 8.01, 9.01
- 2016-12-07 0001193125-16-787354 — 2.02, 9.01
- 2016-11-01 0001193125-16-755475 — 8.01, 9.01
- 2016-09-30 0001193125-16-726999 — 5.02, 8.01, 9.01
- 2016-08-03 0001193125-16-669308 — 2.02, 8.01, 9.01
- 2016-05-04 0001193125-16-576528 — 2.02, 8.01, 9.01
- 2016-02-25 0001193125-16-477896 — 5.07
- 2016-02-03 0001193125-16-449052 — 2.02, 8.01, 9.01
- 2015-12-31 0001193125-15-418363 — 5.02, 7.01, 9.01
- 2015-12-02 0001193125-15-393109 — 2.02, 9.01
- 2015-11-05 0001193125-15-368085 — 8.01, 9.01
- 2015-09-25 0001193125-15-329031 — 5.02
- 2015-08-05 0001193125-15-277912 — 2.02, 8.01, 9.01
- 2015-05-06 0001193125-15-174291 — 2.02, 8.01, 9.01
- 2015-03-06 0001193125-15-081070 — 5.02
- 2015-03-02 0001193125-15-072946 — 5.07
- 2015-02-03 0001193125-15-031772 — 2.02, 8.01, 9.01
- 2014-12-18 0001193125-14-446513 — 8.01, 9.01
- 2014-12-03 0001193125-14-431745 — 2.02, 9.01
- 2014-11-05 0001193125-14-397955 — 8.01, 9.01
- 2014-09-26 0001193125-14-353741 — 7.01, 9.01
- 2014-08-05 0001193125-14-296001 — 2.02, 8.01, 9.01
- 2014-05-07 0001193125-14-187496 — 2.02, 8.01, 9.01
- 2014-03-03 0001193125-14-079843 — 5.02, 5.07
- 2014-02-05 0001193125-14-036633 — 2.02, 8.01, 9.01
- 2014-01-17 0001193125-14-014351 — 1.01, 8.01, 9.01
- 2014-01-06 0001193125-14-002795 — 1.01, 2.03
- 2013-12-06 0001564590-13-001411 — 2.02, 9.01
- 2013-12-05 0001564590-13-001406 — 5.02, 8.01, 9.01
- 2013-11-07 0001193125-13-432950 — 8.01, 9.01
- 2013-08-07 0001193125-13-324337 — 2.02, 9.01
- 2013-05-08 0001193125-13-206800 — 2.02, 9.01
- 2013-02-22 0001193125-13-070971 — 5.02, 5.07
- 2013-02-06 0001193125-13-040556 — 2.02, 9.01
- 2012-12-18 0001193125-12-506417 — 5.02, 9.01
- 2012-12-05 0001193125-12-491749 — 2.02, 9.01
- 2012-10-12 0001193125-12-421889 — 3.03, 5.02, 5.03, 9.01
- 2012-08-09 0001193125-12-344617 — 5.02, 8.01, 9.01
- 2012-08-08 0001193125-12-343630 — 2.02, 9.01
- 2012-05-09 0001193125-12-221356 — 2.02, 9.01
- 2012-02-08 0001193125-12-046560 — 2.02, 9.01
- 2011-12-08 0001193125-11-334810 — 2.02, 9.01
- 2011-11-08 0000950123-11-096524 — 2.02, 2.06, 4.02, 9.01
- 2011-10-14 0000950123-11-090124 — 5.02
- 2011-10-06 0000950123-11-088969 — 5.02
- 2011-09-19 0000950123-11-085224 — 5.02, 9.01
- 2011-09-15 0000950123-11-084806 — 5.02, 9.01
- 2011-08-04 0000950123-11-072788 — 2.02, 9.01
- 2011-07-22 0000950123-11-067402 — 5.07
- 2011-05-24 0000950123-11-053550 — 1.01, 2.03, 9.01
- 2011-05-04 0000950123-11-044561 — 2.02, 9.01
- 2011-02-02 0000950123-11-008188 — 2.02, 9.01
- 2010-12-08 0000950123-10-111987 — 2.02, 9.01
- 2010-08-05 0000950123-10-073114 — 2.02, 9.01
- 2010-05-18 0000950123-10-050900 — 5.02
- 2010-05-05 0000950123-10-044499 — 2.02, 9.01
- 2010-02-03 0000950123-10-008278 — 2.02, 9.01
- 2009-12-21 0000950123-09-072269 — 1.01, 2.01, 2.03, 8.01, 9.01
- 2009-12-09 0000950123-09-069525 — 2.02, 9.01
- 2009-10-27 0000950123-09-053501 — 1.01, 8.01, 9.01
- 2009-08-04 0000950123-09-029476 — 2.02, 9.01
- 2009-05-06 0000950129-09-001498 — 2.02, 9.01
- 2009-03-05 0000950129-09-000749 — 1.01, 9.01
- 2009-02-10 0000950129-09-000349 — 2.02, 9.01
- 2008-12-10 0000950134-08-021934 — 2.02, 9.01
- 2008-08-06 0000950129-08-004267 — 2.02, 9.01
- 2008-07-24 0000950129-08-004063 — 1.01, 5.02, 8.01, 9.01
- 2008-06-16 0000950129-08-003500 — 9.01 — amendment of 0000950134-06-015374
- 2008-06-05 0000950129-08-003378 — 5.02, 9.01
- 2008-05-08 0000950129-08-002843 — 2.02, 9.01
- 2008-02-06 0000950129-08-000533 — 2.02, 9.01
- 2007-12-19 0000950129-07-006277 — 1.01, 2.03, 9.01
- 2007-12-06 0000950129-07-006003 — 2.02, 9.01
- 2007-08-21 0000950129-07-004181 — 2.02, 9.01
- 2007-05-31 0000950129-07-002810 — 2.02, 9.01
- 2007-05-21 0000950129-07-002668 — 2.02, 3.01, 4.02, 9.01
- 2007-04-16 0000950129-07-002002 — 2.02, 4.02, 9.01
- 2007-03-01 0000950129-07-001104 — 5.02, 8.01, 9.01
- 2007-02-08 0000950129-07-000451 — 2.02, 9.01
- 2006-12-08 0000950129-06-010041 — 2.02, 9.01
- 2006-09-08 0000950129-06-008379 — 2.02, 9.01
- 2006-08-09 0000950134-06-015374 — 1.01, 2.01, 8.01, 9.01
- 2006-06-08 0000950129-06-006127 — 2.02, 9.01
- 2006-03-09 0000950129-06-002455 — 2.02, 9.01
- 2005-12-16 0000950129-05-012031 — 2.02, 5.03, 9.01
- 2005-09-13 0000950129-05-009181 — 2.01, 9.01 — amendment of 0000950129-05-006889
- 2005-09-12 0000950129-05-009151 — 2.02, 9.01
- 2005-07-06 0000950129-05-006889 — 1.01, 1.02, 2.01, 2.03, 9.01
- 2005-06-10 0000950129-05-006128 — 2.02, 9.01
- 2005-04-20 0000080420-05-000031 — 5.02
- 2005-03-11 0000080420-05-000024 — 9.01
- 2005-02-25 0000080420-05-000018 — 7.01, 9.01
- 2005-01-21 0000080420-05-000009 — 7.01, 9.01
- 2004-12-17 0000080420-04-000049 — 2.02, 9.01
- 2004-11-01 0000080420-04-000045 — 8.01, 9.01
- 2004-10-08 0001169232-04-005133 — 2.05
- 2004-09-14 0000080420-04-000037 — 5.02
- 2004-09-02 0000080420-04-000030 — 2.02, 9.01
- 2004-06-08 0000080420-04-000021 — 7
- 2004-05-13 0000080420-04-000019 — 4
- 2004-02-27 0000080420-04-000013 — 7
- 2003-12-16 0000950129-03-006136 — 12, 7
- 2003-08-29 0000950129-03-004531 — 12, 7
- 2003-06-03 0000950129-03-003035 — 7, 9
- 2003-05-15 0000950129-03-002812 — 7, 9
- 2002-05-29 0000950129-02-002795 — 4
- 2000-12-21 0000950129-00-006093 — 5, 7
- 1998-09-04 0000950129-98-003802 — 5
- 1996-08-09 0000950129-96-001705 — 2, 7

## late-filing notifications on or before 2025-08-06

- 2007-05-11 0000950129-07-002494 — NT 10-Q, for the period ended 2007-03-31
- 2005-01-18 0000080420-05-000004 — NT 10-K, for the period ended 2004-10-31

## item 2.02 — earnings release, exhibit 99.1

[0000080420-25-000095:8k_2_02:1]
EX-99.1
2
ex991-powlq3xfy2025earning.htm
EX-99.1

[0000080420-25-000095:8k_2_02:2]
Document

[0000080420-25-000095:8k_2_02:3]
Exhibit 99.1

[0000080420-25-000095:8k_2_02:4]
PRESS RELEASE

[0000080420-25-000095:8k_2_02:5]
| For Immediate Release |  |  | Contact: | Michael Metcalf, CFO |
|  |  |  |  | Powell Industries, Inc. |
|  |  |  |  | 713-947-4422 |
|  |  |  |  | Robert Winters or Ryan Coleman |
|  |  |  |  | Alpha IR Group |
|  |  |  |  | POWL@alpha-ir.com |
|  |  |  |  | 312-445-2870 |

[0000080420-25-000095:8k_2_02:6]
POWELL INDUSTRIES ANNOUNCES THIRD QUARTER FISCAL 2025 RESULTS

[0000080420-25-000095:8k_2_02:7]
HOUSTON — August 5, 2025 — Powell Industries, Inc. (NASDAQ: POWL), a leading supplier of custom-engineered solutions for the management, control and distribution of electrical energy, today announced results for the third quarter of fiscal 2025 ended June 30, 2025. All comparisons are to the third quarter of fiscal 2024, unless otherwise noted.

[0000080420-25-000095:8k_2_02:8]
Third Quarter Key Financial and Strategic Highlights:

[0000080420-25-000095:8k_2_02:9]
•Revenues of $286 million, were essentially unchanged;

[0000080420-25-000095:8k_2_02:10]
•Gross profit of $88 million, or 30.7% of revenue, increased 8%;

[0000080420-25-000095:8k_2_02:11]
•Net income of $48 million, or $3.96 per diluted share, increased 4%;

[0000080420-25-000095:8k_2_02:12]
•New orders(1) totaled $362 million;

[0000080420-25-000095:8k_2_02:13]
•Backlog(2) as of June 30, 2025 totaled $1.4 billion, increased 7% compared to the second fiscal quarter;

[0000080420-25-000095:8k_2_02:14]
•Cash and short-term investments as of June 30, 2025 totaled $433 million.

[0000080420-25-000095:8k_2_02:15]
•Subsequent to quarter end, Powell announced a definitive agreement to acquire Remsdaq Ltd., a U.K.-based manufacturer of SCADA Remote Terminal Units for electrical substation control and automation in generation, transmission and distribution.

[0000080420-25-000095:8k_2_02:16]
Brett A. Cope, Powell’s Chairman and Chief Executive Officer, stated, “I am very proud of the Powell team as we delivered another strong quarter of results.  We continue to execute our project backlog at a high level, achieving a gross margin of 30.7% in the current quarter, an improvement of 230 basis points compared to the prior year.  Our strong brand of trusted execution supports another quarter of robust order activity highlighted by a book-to-bill ratio(3) of 1.3x and sequential backlog growth of 7%. While new order activity was strong across most of our key markets, notable awards in the quarter included a $60 million award in the Electric Utility market - the largest utility order in Powell’s history and a testament to our long-term focus of growth within this market. We were also awarded over $80 million combined from two separate awards for custom offshore modules for oil and gas production; and we received a $30 million order for a large Traction Power project based in the United States.”

[0000080420-25-000095:8k_2_02:17]
Third Quarter Fiscal 2025 Results

[0000080420-25-000095:8k_2_02:18]
Revenues totaled $286.3 million, a decrease of 1% compared to $288.2 million in the prior year, and an increase of 3% compared to $278.6 million in the second quarter of fiscal 2025. The decline compared to the prior year was driven by lower revenue levels from the Oil & Gas and Petrochemical markets, which declined by 8% and 36%, respectively, largely offset by higher revenue levels in the Electric Utility and Commercial & Other Industrial markets, which grew by 31% and 18%, respectively, as well as a 61% increase in revenue in the Light Rail Traction Power market.

[0000080420-25-000095:8k_2_02:19]
Gross profit of $87.9 million, or 30.7% of revenue, increased 8% compared to $81.7 million, or 28.4% of revenue, in the prior year and increased 5% from $83.4 million, or 29.9% of revenue, in the second quarter of fiscal 2025. The improvement compared to the prior year was primarily due to favorable volume leverage, strong project execution, as well as the benefit from project closeouts in the third quarter of fiscal 2025.

[0000080420-25-000095:8k_2_02:20]
New orders totaled $362 million compared to $356 million in the prior year and $249 million in the second quarter. The growth compared to the prior year was spread evenly across our markets.

[0000080420-25-000095:8k_2_02:21]
Backlog totaled $1.4 billion as of June 30, 2025, a 7% increase compared to backlog at March 31, 2025, and a 5% increase compared to backlog at June 30, 2024.

[0000080420-25-000095:8k_2_02:22]
Net income of $48.2 million, or $3.96 per diluted share, increased 4% compared to $46.2 million, or $3.79 per diluted share, in the prior year, and $46.3 million, or $3.81 per diluted share, in the second quarter of fiscal 2025.

[0000080420-25-000095:8k_2_02:23]
Cope added, “We continue to execute against our strategic plan to support Powell’s profitable growth and long-term success. Our recently announced acquisition of Remsdaq significantly strengthens our Electric Automation platform and is an important building block in our ability to serve our markets with a Powell solution. In parallel, our latest product initiatives and development wins are generating strong commercial momentum as we continue to diversify and expand our product portfolio.  These internal initiatives, combined with what we see as sustained demand drivers across our key markets, reinforce our outlook for continued strong operational and financial performance. Overall, we remain very encouraged by the strong demand across the markets we serve and are confident in our ability to deliver value for our customers and shareholders alike.”

[0000080420-25-000095:8k_2_02:24]
OUTLOOK

[0000080420-25-000095:8k_2_02:25]
Commenting on the Company's outlook, Michael Metcalf, Powell’s Chief Financial Officer, said, “We are very pleased with our operational and financial performance through the first nine months of fiscal 2025.  As we approach the fiscal year end, we remain confident in the Company’s strategic positioning and the momentum behind our growth initiatives.  Looking ahead, the strength and consistency of commercial activity across all our end markets reinforces the broadening of our business strategies and provides a solid foundation as we plan for fiscal 2026.  Operationally, we are executing effectively and are well positioned to continue delivering strong financial performance through the fourth quarter of fiscal 2025, and into the next fiscal year.”

[0000080420-25-000095:8k_2_02:26]
3

[0000080420-25-000095:8k_2_02:27]
CONFERENCE CALL

[0000080420-25-000095:8k_2_02:28]
Powell Industries has scheduled a conference call for Wednesday, August 6, 2025 at 11:00 a.m. Eastern time. To participate in the conference call, dial 1-833-953-2431 (domestic) or 1-412-317-5760 (international) at least 10 minutes before the call begins and ask for the Powell Industries conference call. A telephonic replay of the conference call will be available through August 13, 2025 and may be accessed by calling 1-877-344-7529 (domestic) or 1-412-317-0088 (international) and using passcode 4260247#.

[0000080420-25-000095:8k_2_02:29]
Investors, analysts and the general public will also have the opportunity to listen to the conference call over the Internet by visiting powellind.com. To listen to the live call on the web, please visit the website at least 15 minutes before the call begins to register, download and install any necessary audio software.  For those who cannot listen to the live webcast, an archive will be available shortly after the call and will remain available for approximately 90 days at powellind.com.

[0000080420-25-000095:8k_2_02:30]
About Powell Industries

[0000080420-25-000095:8k_2_02:31]
Powell Industries, Inc., headquartered in Houston, Texas, develops, designs, manufactures and services custom-engineered equipment and systems that distribute, control and monitor the flow of electrical energy and provide protection to motors, transformers and other electrically powered equipment.  Powell Industries, Inc. primarily serves the oil and gas and petrochemical markets, the electric utility market, and commercial and other industrial markets. Beyond these major markets, we also provide products and services to the light rail traction power market and other markets that include universities and government entities. We are continuously developing new channels to electrical markets through original equipment manufacturers and distribution market channels.   For more information, please visit powellind.com.

[0000080420-25-000095:8k_2_02:32]
5

[0000080420-25-000095:8k_2_02:33]
POWELL INDUSTRIES, INC. & SUBSIDIARIES

[0000080420-25-000095:8k_2_02:34]
CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS

[0000080420-25-000095:8k_2_02:35]
|  | Three Months EndedJune 30, |  | Nine Months EndedJune 30, |
|  | 2025 |  | 2024 |  | 2025 |  | 2024 |
| (In thousands, except per share data) |  |  |  |  |  |  |  |
|  | (Unaudited) |
| Revenues | $ | 286,273 |  |  | $ | 288,168 |  |  | $ | 806,335 |  |  | $ | 737,293 |  |
| Cost of goods sold | 198,374 |  |  | 206,428 |  |  | 575,480 |  |  | 544,639 |  |
| Gross profit | 87,899 |  | 81,740 |  | 230,855 |  | 192,654 |
| Selling, general and administrative expenses | 25,116 |  |  | 22,022 |  |  | 68,359 |  |  | 63,316 |  |
| Research and development expenses | 2,659 |  |  | 2,430 |  |  | 7,881 |  |  | 6,681 |  |
| Operating income | 60,124 |  |  | 57,288 |  |  | 154,615 |  |  | 122,657 |  |
| Other expenses (income): |  |  |  |  |  |  |  |
| Interest income, net | (3,977) |  |  | (4,508) |  |  | (11,397) |  |  | (12,934) |  |
| Income before income taxes | 64,101 |  | 61,796 |  | 166,012 |  | 135,591 |
| Income tax provision | 15,867 |  |  | 15,573 |  |  | 36,685 |  |  | 31,795 |  |
| Net income | $ | 48,234 |  |  | $ | 46,223 |  |  | $ | 129,327 |  |  | $ | 103,796 |  |
| Earnings per share: |  |  |  |  |  |  |  |
| Basic | $ | 4.00 |  |  | $ | 3.85 |  |  | $ | 10.72 |  |  | $ | 8.67 |  |
| Diluted | $ | 3.96 |  |  | $ | 3.79 |  |  | $ | 10.63 |  |  | $ | 8.52 |  |
| Weighted average shares: |  |  |  |  |  |  |  |
| Basic | 12,071 |  |  | 11,998 |  |  | 12,059 |  |  | 11,977 |  |
| Diluted | 12,175 |  |  | 12,205 |  |  | 12,166 |  |  | 12,180 |  |
| SELECTED FINANCIAL DATA: |  |  |  |  |  |  |  |
| Depreciation | $ | 1,742 |  |  | $ | 1,709 |  |  | $ | 5,215 |  |  | $ | 5,074 |  |
| Capital Expenditures | $ | 5,117 |  |  | $ | 1,389 |  |  | $ | 11,380 |  |  | $ | 3,527 |  |
| Dividends Paid | $ | 3,228 |  |  | $ | 3,176 |  |  | $ | 9,640 |  |  | $ | 9,475 |  |

[0000080420-25-000095:8k_2_02:36]
6

[0000080420-25-000095:8k_2_02:37]
POWELL INDUSTRIES, INC. & SUBSIDIARIES

[0000080420-25-000095:8k_2_02:38]
CONDENSED CONSOLIDATED BALANCE SHEETS

[0000080420-25-000095:8k_2_02:39]
|  | June 30, 2025 |  | September 30, 2024 |
| (In thousands) |  |
|  | (Unaudited) |  |  |
| Assets: |  |  |  |
| Cash, cash equivalents and short-term investments | $ | 433,040 |  |  | $ | 358,392 |  |
| All other current assets | 447,119 |  |  | 418,089 |  |
| Property, plant and equipment, net | 109,376 |  |  | 103,421 |  |
| Long-term assets | 52,681 |  |  | 48,278 |  |
| Total assets | $ | 1,042,216 |  |  | $ | 928,180 |  |
| Liabilities and equity: |  |  |  |
| Current liabilities | $ | 427,345 |  |  | $ | 428,015 |  |
| Deferred and other long-term liabilities | 19,966 |  |  | 17,092 |  |
| Stockholders’ equity | 594,905 |  |  | 483,073 |  |
| Total liabilities and stockholders’ equity | $ | 1,042,216 |  |  | $ | 928,180 |  |
| SELECTED FINANCIAL DATA: |  |  |  |
| Working capital(4) | $ | 452,814 |  |  | $ | 348,466 |  |

[0000080420-25-000095:8k_2_02:40]
(1)New orders (bookings) represent the estimated value of contracts added to existing backlog (unsatisfied performance obligations).

[0000080420-25-000095:8k_2_02:41]
(2)The amounts recorded in backlog may not be a reliable indicator of our future operating results and may not be indicative of continuing revenue performance over future fiscal quarters or years primarily due to unexpected contract adjustments, cancellations or scope reductions.

[0000080420-25-000095:8k_2_02:42]
(3)The book-to-bill ratio represents the ratio of new orders (bookings) received in the period divided by the revenues recognized in the period.

[0000080420-25-000095:8k_2_02:43]
(4)Working Capital is equal to current assets (including Cash and ST Investments) minus current liabilities.
