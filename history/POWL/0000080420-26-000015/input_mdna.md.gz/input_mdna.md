# POWL MD&A — 0000080420-26-000015


## mdna

[0000080420-26-000015:mdna:1]
[same as prior period, unchanged from 0000080420-25-000098:mdna:1]

[0000080420-26-000015:mdna:2]
The following discussion and analysis of our financial condition and results of operations should be read in conjunction with the accompanying condensed consolidated financial statements and related notes included in this Quarterly Report on Form 10-Q and with our Annual Report on Form 10-K for the fiscal year ended September 30, 2025, which was filed with the SEC on November 19, 2025 and is available on the SEC’s website at www.sec.gov.

[0000080420-26-000015:mdna:3]
[same as prior period, unchanged from 0000080420-25-000098:mdna:3]

[0000080420-26-000015:mdna:4]
[same as prior period, unchanged from 0000080420-25-000098:mdna:4]

[0000080420-26-000015:mdna:5]
In the first quarter of Fiscal 2026, we reported revenues of $251.2 million, net income of $41.4 million, and generated $43.6 million in cash from operating activities. As of December 31, 2025, we had total assets of $1.1 billion.

[0000080420-26-000015:mdna:6]
Market Outlook

[0000080420-26-000015:mdna:7]
Our backlog increased to $1.6 billion as of December 31, 2025, of which approximately $933 million is expected to be recognized as revenue within the next twelve months. Commercial activity remained favorable during the first quarter of Fiscal 2026 across most of our key markets, with particularly strong demand across the Commercial and Other Industrial and Oil and Gas markets. During the quarter, we secured a large data center project in addition to a major Liquefied Natural Gas (LNG) project, underscoring continued investment and robust customer activity in these end markets. Despite this momentum, we continue to closely monitor macroeconomic conditions and ongoing geopolitical developments that may influence customer spending patterns or the timing of project awards. Although current demand indicators remain stable, these external factors could affect future levels of market activity.

[0000080420-26-000015:mdna:8]
Oil and gas and petrochemical markets. The North American oil and gas end markets continue to exhibit strong commercial activity levels in response to rising global demand for LNG and gas-to‑chemical processes that leverage low‑cost natural gas feedstocks. We believe the fundamentals of the U.S. natural gas market, through abundant supply and competitive cost, continue to support investments in LNG facilities and related gas processing infrastructure. As a result, these market dynamics have sustained our order activity, which includes a large LNG project award during the first fiscal quarter. Other oil and gas end markets related to production and downstream operations, and to a lesser extent, the Petrochemical market remain steady. Beyond traditional crude oil refining and other oil and gas downstream operations, we have broadened our end markets into hydrogen production, carbon capture as well as alternative fuels, such as biofuels and sustainable aviation fuel, aligned with growing demand for cleaner energy solutions.

[0000080420-26-000015:mdna:9]
Electric utility market. Aligned with our strategy of end-market diversification, we seek to continue our focus and growth in electrical distribution substations, while also addressing a resurgence of power generation investment in this market.

[0000080420-26-000015:mdna:10]
Commercial and other industrial markets. As a result of a mix of factors, we are experiencing strong growth in commercial facilities that provide for the production of various consumer goods and the expansion of data centers that support cloud computing and increasing investments in artificial intelligence. During the first quarter of Fiscal 2026, we were awarded projects in excess of $100 million attributable to data center infrastructure, of which one project had an order value of approximately $75 million. The commercial activity in this sector reflects the continued investment in this end market. We are also experiencing increased activity in other industrial end markets.

[0000080420-26-000015:mdna:11]
[same as prior period, unchanged from 0000080420-25-000098:mdna:12]

[0000080420-26-000015:mdna:12]
[same as prior period, unchanged from 0000080420-25-000098:mdna:13]

[0000080420-26-000015:mdna:13]
Our operating results are impacted by several factors such as the timing of new order awards, project backlog, changes in project cost estimates, customer approval of final engineering specifications and delays in customer construction schedules, all of which contribute to short-term earnings variability and the timing of project execution. Our operating results also have been, and may continue to be, impacted by the timing and resolution of change orders and the resolution of potential contract claims and liquidated damages, all of which could improve or deteriorate gross margins during the period in which these items are resolved with our customers. Disruptions in the global supply chain have negatively impacted and may continue to negatively impact our business and operating results due to the limited supply of, delays for and uncertainty in the timing of the receipt of key component parts and commodities. We continue to remain focused on the variables that impact our markets as well as cost management, labor availability and supply chain challenges.

[0000080420-26-000015:mdna:14]
[same as prior period, unchanged from 0000080420-25-000098:mdna:16]

[0000080420-26-000015:mdna:15]
During the first quarter of Fiscal 2026, we continued experiencing high volatility in commodity prices, and ongoing supply chain delays for specific engineered components remained a persistent challenge for us. Moreover, ongoing and recently proposed changes to U.S. global trade policy (including legal changes thereto), along with potential international retaliatory measures, and concerns over inflation, recession and slowing growth have continued to cause high volatility in global markets and uncertainty around short- and long-term economic impacts in the United States and other markets we serve. We continue to evaluate and monitor the potential impacts of these changes and measures, including the imposition of tariffs, on our business and operations. We could potentially face the challenge of increased costs of raw materials and engineered components as well as negative impacts on our margins; however, it is not possible to predict the impact, if any, of any changes or proposed changes to the U.S. global trade policy, or any international retaliatory measures, on our business and operations. In response to the rising cost environment and persistent supply chain challenges, we are taking strategic measures to effectively manage our product pricing, refine delivery schedules, and manage bid validity dates with our customers. Our supplier engagement includes improving forecasting and negotiating favorable terms that allow us to meet or exceed customer timelines. Additionally, we remain focused on enhancing factory efficiencies and improving project execution to mitigate risks and maintain customer satisfaction.

[0000080420-26-000015:mdna:16]
[same as prior period, unchanged from 0000080420-25-000098:mdna:19]

[0000080420-26-000015:mdna:17]
Quarter Ended December 31, 2025 Compared to the Quarter Ended December 31, 2024 (Unaudited)

[0000080420-26-000015:mdna:18]
[same as prior period, unchanged from 0000080420-25-000098:mdna:21]

[0000080420-26-000015:mdna:19]
Revenues increased by 4%, or $9.8 million, to $251.2 million in the first quarter of Fiscal 2026. Domestic revenues decreased by 1%, or $2.9 million, to $194.9 million in the first quarter of Fiscal 2026. International revenues increased by 29%, or $12.6 million, to $56.3 million in the first quarter of Fiscal 2026, primarily driven by increased activities in the Middle East and Africa region and the Asia/Pacific and Europe regions. Our international revenues include both revenues generated from our international facilities as well as revenues from export projects generated at our domestic facilities.

[0000080420-26-000015:mdna:20]
In the first quarter of Fiscal 2026, revenue from our electric utility market increased by 35%, or $18.0 million, to $69.3 million; revenue from our oil and gas market (excluding petrochemical) increased by 2%, or $2.2 million, to $97.9 million; and revenue from our light rail traction power market increased by 5%, or $0.4 million, to $8.6 million. These increases in revenue were primarily driven by our strategic effort to expand our business into electric utility and the improved market conditions in this end market. Revenue from our petrochemical market decreased by 31%, or $10.4 million, to $22.8 million; and commercial and other industrial market revenue decreased by 8%, or $3.7 million, to $40.6 million in the first quarter of Fiscal 2026. These decreases in revenue were primarily driven by the reduction in backlog within the petrochemical market as the business nears completion of the large petrochemical order secured in Fiscal 2023 and less booking activity in this market. Revenue from all other markets combined increased by 36%, or $3.2 million, to $12.0 million in the first quarter of Fiscal 2026.

[0000080420-26-000015:mdna:21]
Gross profit increased by 20%, or $11.9 million, to $71.4 million for the first quarter of Fiscal 2026. Gross profit as a percentage of revenues increased to 28% in the first quarter of Fiscal 2026, as compared to 25% in the first quarter of Fiscal 2025. The increase in gross profit was primarily driven by higher revenues and improved gross profit margin due to favorable volume leverage and strong project execution in a stable pricing environment.

[0000080420-26-000015:mdna:22]
[same as prior period, unchanged from 0000080420-25-000098:mdna:25]

[0000080420-26-000015:mdna:23]
Selling, general and administrative expenses increased by 17%, or $3.7 million, to $25.2 million in the first quarter of Fiscal 2026, primarily due to higher compensation costs and increased infrastructure expenses. Selling, general and administrative expenses as a percentage of revenues increased to 10% during the first quarter of Fiscal 2026, compared to 9% during the first quarter of Fiscal 2025.

[0000080420-26-000015:mdna:24]
[same as prior period, unchanged from 0000080420-25-000098:mdna:27]

[0000080420-26-000015:mdna:25]
We recorded an income tax provision of $5.6 million in the first quarter of Fiscal 2026, compared to an income tax provision of $4.7 million in the first quarter of Fiscal 2025 resulting in an effective tax rate of 12% for the first quarters of Fiscal 2026 and Fiscal 2025. For each of the three months ended December 31, 2025 and 2024, the effective tax rates were favorably impacted by discrete items related to the vesting of restricted stock units (RSUs) and the estimated Research and Development (R&D) Tax Credit. The decreased effective tax rates were primarily driven by the higher stock prices associated with the vested RSUs. For further information regarding our income taxes, see Note L. Income Taxes of Notes to Condensed Consolidated Financial Statements.

[0000080420-26-000015:mdna:26]
[same as prior period, unchanged from 0000080420-25-000098:mdna:29]

[0000080420-26-000015:mdna:27]
In the first quarter of Fiscal 2026, we recorded net income of $41.4 million, or $3.40 per diluted share, compared to net income of $34.8 million, or $2.86 per diluted share, in the first quarter of Fiscal 2025. The increase in net income was primarily driven by increased revenues and higher gross profit margin in the first quarter of Fiscal 2026.

[0000080420-26-000015:mdna:28]
[same as prior period, unchanged from 0000080420-25-000098:mdna:31]

[0000080420-26-000015:mdna:29]
The order backlog, which is our remaining unsatisfied performance obligations, represents the estimated transaction price for goods and services for which we have a material right, but work has not been performed. The order backlog at December 31, 2025 was $1.6 billion, a 14% increase from our $1.4 billion backlog at September 30, 2025. This increase was mainly driven by commercial and other industrial as well as oil and gas markets. As of December 31, 2025, the oil and gas (excluding petrochemical) market accounted for 32% of our backlog, the electric utility market accounted for 30% of our backlog, and the commercial and other industrial market accounted for 22% of our backlog.

[0000080420-26-000015:mdna:30]
Bookings, net of cancellations and scope reductions, increased by 63% in the first quarter of Fiscal 2026 to $438.8 million, compared to $268.6 million in the first quarter of Fiscal 2025. This increase was primarily driven by improved bookings in the commercial and other industrial market.

[0000080420-26-000015:mdna:31]
[same as prior period, unchanged from 0000080420-25-000098:mdna:49]

[0000080420-26-000015:mdna:32]
As of December 31, 2025, current assets exceeded current liabilities by 2.3 times.

[0000080420-26-000015:mdna:33]
Cash, cash equivalents and short-term investments increased to $500.8 million at December 31, 2025, compared to $475.5 million at September 30, 2025. The increase in cash, cash equivalents and short-term investments was primarily driven by our strong earnings, partially offset by cash payments related to shares withheld in lieu of employee tax withholding and payments of dividends. We invest our cash, cash equivalents and short-term investments in accordance with the Company’s investment policy approved by the Board of Directors. We believe that our cash, cash equivalents and short-term investments, as well as available borrowings under our U.S. credit facility, will be sufficient to support our ongoing operating activities, dividend payments and future organic and inorganic business growth, as well as research and development initiatives for the next twelve months and beyond.

[0000080420-26-000015:mdna:34]
As we assess our capital allocation framework relative to our strategic objectives, we will continue to deploy capital to both organic and inorganic initiatives, as well as maintain a prudent approach to other methods that improve shareholder value. We regularly assess our capital allocation framework. Our current intention is to prioritize our working capital needs, fund research and development, capital expenditures and other organic growth opportunities, while also returning capital to shareholders and evaluating strategic inorganic opportunities as they arise. Our capital allocation plan depends upon a number of factors,

[0000080420-26-000015:mdna:35]
including market conditions, our financial position and capital requirements, financial conditions, competing uses for cash, and other factors.

[0000080420-26-000015:mdna:36]
Approximately $92.7 million of our cash, cash equivalents and short-term investments at December 31, 2025 was held outside of the U.S. for our international operations. It is our intention to indefinitely reinvest all current and future foreign earnings internationally in order to ensure sufficient working capital to support our international operations. In the event that we elect to repatriate some or all of the foreign earnings that were previously deemed to be indefinitely reinvested outside the U.S., we may incur additional tax expense upon such repatriation under current tax laws.

[0000080420-26-000015:mdna:37]
[same as prior period, unchanged from 0000080420-25-000098:mdna:53]

[0000080420-26-000015:mdna:38]
[same as prior period, unchanged from 0000080420-25-000098:mdna:54]

[0000080420-26-000015:mdna:39]
As of December 31, 2025, there were no amounts borrowed under the U.S. Revolver, and letters of credit outstanding were $65.1 million. There was $84.9 million available for the issuance of letters of credit and borrowings under the U.S. Revolver as of December 31, 2025. For further information regarding our debt, see Notes F. Long-Term Debt and G. Commitments and Contingencies of Notes to Condensed Consolidated Financial Statements.

[0000080420-26-000015:mdna:40]
[same as prior period, unchanged from 0000080420-25-000098:mdna:56]

[0000080420-26-000015:mdna:41]
[same as prior period, unchanged from 0000080420-25-000098:mdna:57]

[0000080420-26-000015:mdna:42]
Operating activities provided net cash of $43.6 million during the three months ended December 31, 2025 and provided net cash of $37.1 million during the same period in Fiscal 2025. Cash flow from operations is primarily influenced by project volume and margins, as well as working capital requirements, the timing of milestone payments from our customers, and payment terms with our suppliers. The increase in operating cash flow was primarily driven by improved earnings.

[0000080420-26-000015:mdna:43]
[same as prior period, unchanged from 0000080420-25-000098:mdna:59]

[0000080420-26-000015:mdna:44]
Investing activities provided $12.9 million of cash during the three months ended December 31, 2025 and used $9.5 million of cash during the same period in Fiscal 2025. Cash provided by investing activities in the first three months of Fiscal 2026 was primarily due to maturities of short-term investments, partially offset by capital spending.

[0000080420-26-000015:mdna:45]
[same as prior period, unchanged from 0000080420-25-000098:mdna:62]

[0000080420-26-000015:mdna:46]
Net cash used in financing activities was $17.3 million during the three months ended December 31, 2025 compared to $15.2 million used during the same period in Fiscal 2025. The increase in cash used in financing activities was primarily due to cash payments related to shares withheld in lieu of employee tax withholding, largely driven by the increase of our share price in the first quarter of Fiscal 2026 compared to the same period of Fiscal 2025.

[0000080420-26-000015:mdna:47]
[same as prior period, unchanged from 0000080420-25-000098:mdna:64]

[0000080420-26-000015:mdna:48]
[same as prior period, unchanged from 0000080420-25-000098:mdna:65]

[0000080420-26-000015:mdna:49]
There have been no material changes to our critical accounting policies as disclosed in our Annual Report on Form 10-K for the fiscal year ended September 30, 2025, which was filed with the SEC on November 19, 2025.
