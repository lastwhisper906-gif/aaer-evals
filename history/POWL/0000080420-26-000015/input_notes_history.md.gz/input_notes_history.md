# POWL note change history — 0000080420-25-000098 → 0000080420-26-000015


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2026-02-04):
[0000080420-26-000015:note_history:1]
Certain customers require us to post letters of credit, bank guarantees or surety bonds. These security instruments assure that we will perform under the terms of our contract. In the event of default, the counterparty may demand payment from the bank under a letter of credit or bank guarantee, or performance by the surety under a bond. To date, there have been no significant draws or claims related to security instruments for the periods reported. We were contingently liable for letters of credit of $65.1 million as of December 31, 2025. We also had surety bonds totaling $433.8 million that were outstanding, with additional bonding capacity of $766.2 million available, at December 31, 2025. We have strong surety relationships; however, a change in market conditions or the sureties’ assessment of our financial position could cause the sureties to require cash collateralization for undischarged liabilities under the bonds.
  (was, 2025-08-06, similarity 0.9857):
[0000080420-25-000098:note_history:1]
Certain customers require us to post letters of credit, bank guarantees or surety bonds. These security instruments assure that we will perform under the terms of our contract. In the event of default, the counterparty may demand payment from the bank under a letter of credit or bank guarantee, or performance by the surety under a bond. To date, there have been no significant draws or claims related to security instruments for the periods reported. We were contingently liable for letters of credit of $76.0 million as of June 30, 2025. We also had surety bonds totaling $432.6 million that were outstanding, with additional bonding capacity of $767.4 million available, at June 30, 2025. We have strong surety relationships; however, a change in market conditions or the sureties' assessment of our financial position could cause the sureties to require cash collateralization for undischarged liabilities under the bonds.

- changed (2026-02-04):
[0000080420-26-000015:note_history:2]
We have a $20.2 million facility agreement (Facility Agreement) between Powell (UK) Limited and a large international bank that provides Powell (UK) Limited the ability to enter into bank guarantees as well as forward exchange contracts and currency options. At December 31, 2025, we had outstanding guarantees totaling $7.6 million, with an additional capacity of $12.6 million available under this Facility Agreement. The Facility Agreement provides for customary events of default and carries cross-default provisions with the U.S. Revolver. If an event of default (as defined in the Facility Agreement) occurs and is continuing, per the terms and subject to the conditions set forth therein, obligations outstanding under the Facility Agreement may be accelerated and declared immediately due and payable. Additionally, we are required to maintain cash collateral for guarantees greater than two years. As of December 31, 2025, we were in compliance with all of the financial covenants of the Facility Agreement.
  (was, 2025-08-06, similarity 0.9879):
[0000080420-25-000098:note_history:2]
We have a $20.5 million facility agreement (Facility Agreement) between Powell (UK) Limited and a large international bank that provides Powell (UK) Limited the ability to enter into bank guarantees as well as forward exchange contracts and currency options. At June 30, 2025, we had outstanding guarantees totaling $7.0 million, with an additional capacity of $13.5 million available under this Facility Agreement. The Facility Agreement provides for customary events of default and carries cross-default provisions with the U.S. Revolver. If an event of default (as defined in the Facility Agreement) occurs and is continuing, per the terms and subject to the conditions set forth therein, obligations outstanding under the Facility Agreement may be accelerated and declared immediately due and payable. Additionally, we are required to maintain cash collateral for guarantees greater than two years. As of June 30, 2025, we were in compliance with all of the financial covenants of the Facility Agreement.

- changed (2026-02-04):
[0000080420-26-000015:note_history:3]
We are involved in various legal proceedings, claims and other disputes arising from our commercial operations, projects, employees and other matters which, in general, are subject to uncertainties and in which the outcomes are not predictable. Although we can give no assurances about the resolution of pending claims, litigation or other disputes, and the effect such outcomes may have on us, management believes that any ultimate liability resulting from the outcome of such proceedings, to the extent not otherwise provided or covered by insurance, will not have a material adverse effect on our consolidated financial position, or results of operations or liquidity.
  (was, 2025-08-06, similarity 0.9955):
[0000080420-25-000098:note_history:3]
We are involved in various legal proceedings, claims and other disputes arising from our commercial operations, projects, employees and other matters which, in general, are subject to uncertainties and for which the outcomes are not predictable. Although we can give no assurances about the resolution of pending claims, litigation or other disputes, and the effect such outcomes may have on us, management believes that any ultimate liability resulting from the outcome of such proceedings, to the extent not otherwise provided or covered by insurance, will not have a material adverse effect on our consolidated financial position or results of operations or liquidity.

- changed (2026-02-04):
[0000080420-26-000015:note_history:4]
Certain of our customer contracts have schedule and performance obligation clauses that, if we fail to meet them, could require us to pay liquidated damages. Each individual contract defines the conditions under which the customer may make a claim against us. As of December 31, 2025, certain contracts had a probable exposure to liquidated damages claims of $4.0 million, which could possibly increase to $4.5 million under certain circumstances. Based on our actual or projected failure to meet these various contractual commitments, $3.1 million has been recorded as a reduction to revenue. We will attempt to obtain change orders, contract extensions or accelerate project completion, which may resolve the potential for any unrecorded liquidated damages claims. Should we fail to achieve relief on some or all of these contractual obligations, we could be required to pay additional liquidated damages, which could negatively impact our future operating results.
  (was, 2025-08-06, similarity 0.9937):
[0000080420-25-000098:note_history:4]
Certain of our customer contracts have schedule and performance obligation clauses that, if we fail to meet them, could require us to pay liquidated damages. Each individual contract defines the conditions under which the customer may make a claim against us. As of June 30, 2025, certain contracts had a probable exposure to liquidated damages claims of $2.9 million, which could possibly increase to $4.0 million under certain circumstances. Based on our actual or projected failure to meet these various contractual commitments, $2.7 million has been recorded as a reduction to revenue. We will attempt to obtain change orders, contract extensions or accelerate project completion, which may resolve the potential for any unrecorded liquidated damages claims. Should we fail to achieve relief on some or all of these contractual obligations, we could be required to pay additional liquidated damages, which could negatively impact our future operating results.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureAndSignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2026-02-04):
[0000080420-26-000015:note_history:5]
Powell Industries, Inc. (we, us, our, Powell or the Company) is a Delaware corporation founded by William E. Powell in 1947. We develop, design, manufacture and service custom-engineered equipment and systems that distribute, control and monitor the flow of electrical energy and provide protection to motors, transformers and other electrically powered equipment. Our major subsidiaries, all of which are wholly owned, include Powell Electrical Systems, Inc.; Powell Canada Inc.; Powell (UK) Limited;  and Powell Industries International Limited.
  (was, 2025-08-06, similarity 0.9861):
[0000080420-25-000098:note_history:5]
Powell Industries, Inc. (we, us, our, Powell or the Company) is a Delaware corporation founded by William E. Powell in 1947. We develop, design, manufacture and service custom-engineered equipment and systems that distribute, control and monitor the flow of electrical energy and provide protection to motors, transformers and other electrically powered equipment. Our major subsidiaries, all of which are wholly owned, include Powell Electrical Systems, Inc.; Powell Canada Inc.; Powell (UK) Limited; and Powell Industries International, B.V.

- added (2026-02-04):
[0000080420-26-000015:note_history:6]
We are headquartered in Houston, Texas, and primarily serve the oil and gas and petrochemical markets, the electric utility market, and commercial and other industrial markets. Beyond these major markets, we also provide products and services to the light rail traction power market and other markets that include universities and government entities. We are continuously developing new channels to electrical markets through original equipment manufacturers and distribution market channels.

- changed (2026-02-04):
[0000080420-26-000015:note_history:7]
The unaudited condensed consolidated financial statements include the accounts of Powell and our wholly-owned subsidiaries. All intercompany accounts and transactions have been eliminated in consolidation.
  (was, 2025-08-06, similarity 0.9668):
[0000080420-25-000098:note_history:7]
The unaudited condensed consolidated financial statements include the accounts of Powell and our wholly owned subsidiaries. All significant intercompany accounts and transactions have been eliminated in consolidation.

- changed (2026-02-04):
[0000080420-26-000015:note_history:8]
The preparation of condensed consolidated financial statements in conformity with U.S. GAAP requires management to make estimates and assumptions that affect the amounts reported in the condensed consolidated financial statements and accompanying footnotes. The most significant estimates used in our condensed consolidated financial statements affect revenue recognition and estimated cost recognition on our customer contracts, allowance for credit losses, provision for excess and obsolete inventory, warranty accruals and income taxes. The amounts recorded for warranties, legal, income taxes, impairment of long-lived assets, intangible assets and goodwill (when applicable), liquidated damages and other contingent liabilities require judgments regarding the amount of expenses that will ultimately be incurred. We base our estimates on historical experience, forecasts and various other assumptions, as well as the specific circumstances surrounding these contingent liabilities, in evaluating the amount of liability that should be recorded. Additionally, the basis for recognition of deferred tax assets requires estimates related to future income and other assumptions regarding timing and future profitability because the ultimate realization of net deferred tax assets is dependent on the generation of future taxable income during periods in which temporary differences become deductible. Estimates routinely change as new events occur, additional information becomes available or operating environments change. Actual results may differ from our prior estimates.
  (was, 2025-08-06, similarity 0.9897):
[0000080420-25-000098:note_history:8]
The preparation of condensed consolidated financial statements in conformity with U.S. GAAP requires management to make estimates and assumptions that affect the amounts reported in the condensed consolidated financial statements and accompanying footnotes. The most significant estimates used in our condensed consolidated financial statements affect revenue recognition and estimated cost recognition on our customer contracts, allowance for credit losses, provision for excess and obsolete inventory, warranty accruals and income taxes. The amounts recorded for warranties, legal, income taxes, impairment of long-lived assets (when applicable), liquidated damages and other contingent liabilities require judgments regarding the amount of expenses that will ultimately be incurred. We base our estimates on historical experience, forecasts and various other assumptions, as well as the specific circumstances surrounding these contingent liabilities, in evaluating the amount of liability that should be recorded. Additionally, the basis for recognition of deferred tax assets requires estimates related to future income and other assumptions regarding timing and future profitability because the ultimate realization of net deferred tax assets is dependent on the generation of future taxable income during periods in which temporary differences become deductible. Estimates routinely change as new events occur, additional information becomes available or operating environments change. Actual results may differ from our prior estimates.

- added (2026-02-04):
[0000080420-26-000015:note_history:9]
Recently Adopted Accounting Standards Update

- added (2026-02-04):
[0000080420-26-000015:note_history:10]
The Company adopted the Financial Accounting Standard Board (FASB) Accounting Standards Update (ASU) 2023‑07, Segment Reporting (Topic 280): Improvements to Reportable Segment Disclosures, effective October 1, 2024, on a retrospective basis. This standard requires expanded annual and interim segment disclosures, including significant segment expenses regularly reviewed by the chief operating decision maker (CODM), along with disclosure of the CODM’s title and how segment information is used in evaluating performance and allocating resources. It also clarifies that entities with a single reportable segment must provide all required Topic 280 disclosures. Adoption of the standard did not have a material impact on the unaudited condensed consolidated financial statements. Additional details are included in Note K. Segment Information.

- changed (2026-02-04):
[0000080420-26-000015:note_history:11]
Accounting Standards Updates Issued but Not Yet Adopted
  (was, 2025-08-06, similarity 0.8397):
[0000080420-25-000098:note_history:11]
Accounting Standards Updates and Disclosure Rules Issued but Not Yet Adopted

- changed (2026-02-04):
[0000080420-26-000015:note_history:12]
In December 2023, the FASB issued ASU 2023-09, Improvements to Income Tax Disclosures, which enhances the transparency of income tax disclosures. It requires greater disaggregation of information in the tax rate reconciliation and income taxes paid disaggregated by jurisdiction. This ASU is effective for fiscal years beginning after December 15, 2024, and should be applied on a prospective basis. Retrospective application and early adoption were permitted. We are currently evaluating the impacts of the new standard.
  (was, 2025-08-06, similarity 0.8586):
[0000080420-25-000098:note_history:12]
In December 2023, the FASB issued ASU 2023-09, Improvements to Income Tax Disclosures, which enhances the transparency of income tax disclosures. It requires greater disaggregation of information in the tax rate reconciliation and income taxes paid disaggregated by jurisdiction. This ASU is effective for fiscal years beginning after December 15, 2024, and should be applied on a prospective basis. Retrospective application and early adoption are permitted. We are currently evaluating the impacts of the new standard.

- removed (2026-02-04):
[0000080420-25-000098:note_history:13]
We are headquartered in Houston, Texas and primarily serve the oil and gas and petrochemical markets, the electric utility market, and commercial and other industrial markets. Beyond these major markets, we also provide products and services to the light rail traction power market and other markets that include universities and government entities. We are continuously developing new channels to electrical markets through original equipment manufacturers and distribution market channels.

- removed (2026-02-04):
[0000080420-25-000098:note_history:14]
In November 2023, the Financial Accounting Standard Board (FASB) issued Accounting Standards Update (ASU) 2023-07,

- removed (2026-02-04):
[0000080420-25-000098:note_history:15]
Segment Reporting (Topic 280): Improvements to Reportable Segment Disclosures, which requires that public entities disclose significant segment expenses that are regularly provided to the chief operating decision maker (CODM) on an annual and interim basis. It also requires that public entities disclose the title and position of the CODM and an explanation of how the CODM uses the reported measures in assessing segment performance and resource allocation. Additionally, it requires that all existing annual disclosures about segment profit or loss and assets must be provided on an interim basis and clarifies that single reportable segment entities are subject to the disclosure requirement under Topic 280 in its entirety. ASU 2023-07 is effective for fiscal years beginning after December 15, 2023 and interim periods within fiscal years beginning after December 15, 2024. A public entity should apply ASU 2023-07 retrospectively to all prior periods presented in the financial statements. Early adoption is permitted. We will implement the new disclosure requirements beginning with our Fiscal 2025 Form 10-K.


## us-gaap:LongTermDebtTextBlock (debt) — matched_by: tag_name, score: 1.0

- added (2026-02-04):
[0000080420-26-000015:note_history:16]
As of December 31, 2025, there were no amounts borrowed under the U.S. Revolver, and letters of credit outstanding were $65.1 million. There was $84.9 million available for the issuance of letters of credit and borrowings under the U.S. Revolver as of December 31, 2025.

- changed (2026-02-04):
[0000080420-26-000015:note_history:17]
As of December 31, 2025, we were in compliance with all of the financial covenants of the U.S. Revolver.
  (was, 2025-08-06, similarity 0.9479):
[0000080420-25-000098:note_history:17]
As of June 30, 2025, we were in compliance with all of the financial covenants of the U.S. Revolver.

- removed (2026-02-04):
[0000080420-25-000098:note_history:18]
As of June 30, 2025, there were no amounts borrowed under the U.S. Revolver, and letters of credit outstanding were $76.0 million. There was $74.0 million available for the issuance of letters of credit and borrowings under the U.S. Revolver as of June 30, 2025.


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2026-02-04):
[0000080420-26-000015:note_history:19]
The following tables present our disaggregated revenue by geographic destination and market sector for the three months ended December 31, 2025 and 2024 (in thousands):
  (was, 2025-08-06, similarity 0.9415):
[0000080420-25-000098:note_history:19]
The following tables present our disaggregated revenue by geographic destination and market sector for the three and nine months ended June 30, 2025 and 2024 (in thousands):

- added (2026-02-04):
[0000080420-26-000015:note_history:20]
|  | Three months ended December 31, |  |  |
|  | 2025 |  | 2024 |  |  |  |  |
| United States | $ | 194,878 |  |  | $ | 197,772 |  |  |  |  |  |
| Canada | 32,459 |  |  | 31,694 |  |  |  |  |  |
| Middle East and Africa | 9,872 |  |  | 4,558 |  |  |  |  |  |
| Europe | 8,226 |  |  | 5,528 |  |  |  |  |  |
| Asia/Pacific | 5,303 |  |  | 1,580 |  |  |  |  |  |
| Mexico, Central and South America | 446 |  |  | 299 |  |  |  |  |  |
| Total revenues by geographic destination | $ | 251,184 |  |  | $ | 241,431 |  |  |  |  |  |

- added (2026-02-04):
[0000080420-26-000015:note_history:21]
|  | Three months ended December 31, |  |  |
|  | 2025 |  | 2024 |  |  |  |  |
| Oil and gas (excludes petrochemical) | $ | 97,889 |  |  | $ | 95,679 |  |  |  |  |  |
| Electric utility | 69,273 |  |  | 51,240 |  |  |  |  |  |
| Commercial and other industrial | 40,625 |  |  | 44,300 |  |  |  |  |  |
| Petrochemical | 22,778 |  |  | 33,183 |  |  |  |  |  |
| Light rail traction power | 8,614 |  |  | 8,228 |  |  |  |  |  |
| All others | 12,005 |  |  | 8,801 |  |  |  |  |  |
| Total revenues by market sector | $ | 251,184 |  |  | $ | 241,431 |  |  |  |  |  |

- removed (2026-02-04):
[0000080420-25-000098:note_history:22]
|  | Three months ended June 30, |  | Nine months ended June 30, |
|  | 2025 |  | 2024 |  | 2025 |  | 2024 |
| United States | $ | 224,537 |  |  | $ | 243,744 |  |  | $ | 650,143 |  |  | $ | 620,537 |  |
| Canada | 42,611 |  |  | 29,695 |  |  | 108,275 |  |  | 74,205 |  |
| Europe | 5,522 |  |  | 9,464 |  |  | 16,947 |  |  | 24,261 |  |
| Middle East and Africa | 9,917 |  |  | 2,322 |  |  | 22,757 |  |  | 8,400 |  |
| Mexico, Central and South America | 1,881 |  |  | 1,962 |  |  | 3,182 |  |  | 6,778 |  |
| Asia/Pacific | 1,805 |  |  | 981 |  |  | 5,031 |  |  | 3,112 |  |
| Total revenues by geographic destination | $ | 286,273 |  |  | $ | 288,168 |  |  | $ | 806,335 |  |  | $ | 737,293 |  |

- removed (2026-02-04):
[0000080420-25-000098:note_history:23]
|  | Three months ended June 30, |  | Nine months ended June 30, |
|  | 2025 |  | 2024 |  | 2025 |  | 2024 |
| Oil and gas (excludes petrochemical) | $ | 105,464 |  |  | $ | 114,336 |  |  | $ | 302,310 |  |  | $ | 301,792 |  |
| Petrochemical | 36,349 |  |  | 56,784 |  |  | 113,236 |  |  | 135,221 |  |
| Electric utility | 74,909 |  |  | 57,009 |  |  | 196,488 |  |  | 145,214 |  |
| Commercial and other industrial | 49,519 |  |  | 42,044 |  |  | 134,188 |  |  | 101,610 |  |
| Light rail traction power | 8,549 |  |  | 5,322 |  |  | 26,785 |  |  | 14,184 |  |
| All others | 11,483 |  |  | 12,673 |  |  | 33,328 |  |  | 39,272 |  |
| Total revenues by market sector | $ | 286,273 |  |  | $ | 288,168 |  |  | $ | 806,335 |  |  | $ | 737,293 |  |


## us-gaap:RevenueFromContractWithCustomerPolicyTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2026-02-04):
[0000080420-26-000015:note_history:24]
Our revenues are primarily generated from the manufacturing of custom-engineered products and systems under long-term fixed-price contracts under which we agree to manufacture various products such as traditional and arc-resistant distribution switchgear and control gear, medium-voltage circuit breakers, monitoring and control communications systems, motor control centers, switches and bus duct systems. These products may be sold separately as an engineered solution but are typically integrated into custom-built enclosures which we also build. These enclosures are referred to as power control room substations (PCRs®), custom-engineered modules or electrical houses (E-Houses). Some contracts may also include the installation and the commissioning of these enclosures.
  (was, 2025-08-06, similarity 0.9994):
[0000080420-25-000098:note_history:24]
Our revenues are primarily generated from the manufacturing of custom-engineered products and systems under long-term, fixed-price contracts under which we agree to manufacture various products such as traditional and arc-resistant distribution switchgear and control gear, medium-voltage circuit breakers, monitoring and control communications systems, motor control centers, switches and bus duct systems. These products may be sold separately as an engineered solution but are typically integrated into custom-built enclosures which we also build. These enclosures are referred to as power control room substations (PCRs®), custom-engineered modules or electrical houses (E-Houses). Some contracts may also include the installation and the commissioning of these enclosures.

- added (2026-02-04):
[0000080420-26-000015:note_history:25]
Revenue from these contracts is generally recognized over time utilizing the cost-to-cost method. Under the cost-to-cost method, the extent of progress towards completion is measured based on the ratio of costs incurred to date to the total estimated

- changed (2026-02-04):
[0000080420-26-000015:note_history:26]
costs at completion of the performance obligation. We believe that this method is the most accurate representation of our performance because it directly measures the value of the services transferred to the customer over time as we incur costs on our contracts. Contract costs include all direct materials, labor and indirect costs related to contract performance, which may include indirect labor, supplies, tools, repairs and depreciation costs.
  (was, 2025-08-06, similarity 0.7114):
[0000080420-25-000098:note_history:26]
Revenue from these contracts is generally recognized over time utilizing the cost-to-cost method. Under the cost-to-cost method, the extent of progress towards completion is measured based on the ratio of costs incurred to date to the total estimated costs at completion of the performance obligation. We believe that this method is the most accurate representation of our performance because it directly measures the value of the services transferred to the customer over time as we incur costs on our contracts. Contract costs include all direct materials, labor and indirect costs related to contract performance, which may include indirect labor, supplies, tools, repairs and depreciation costs.

- changed (2026-02-04):
[0000080420-26-000015:note_history:27]
We also have contracts to provide field service inspection, installation, commissioning, modification, and repair services, as well as retrofit and retrofill components for existing systems. If the service contract terms give us the right to invoice the customer for an amount that corresponds directly with the value of our performance completed to date (i.e., a service contract in which we bill a fixed amount for each hour of service provided), then we recognize revenue over time in each reporting period corresponding to the amount that we have the right to invoice. Our performance obligations are satisfied as the work progresses. Revenues from our custom-engineered products and value-added services transferred to customers over time accounted for approximately 94% and 97% of revenues for the three months ended December 31, 2025 and December 31, 2024, respectively.
  (was, 2025-08-06, similarity 0.9157):
[0000080420-25-000098:note_history:27]
We also have contracts to provide field service inspection, installation, commissioning, modification, and repair services, as well as retrofit and retrofill components for existing systems. If the service contract terms give us the right to invoice the customer for an amount that corresponds directly with the value of our performance completed to date (i.e., a service contract in which we bill a fixed amount for each hour of service provided), then we recognize revenue over time in each reporting period corresponding to the amount that we have the right to invoice. Our performance obligations are satisfied as the work progresses. Revenues from our custom-engineered products and value-added services transferred to customers over time accounted for approximately 95% and 96% of revenues for the three and nine months ended June 30, 2025, respectively, and approximately 96% and 95% of revenues for the three and nine months ended June 30, 2024, respectively.

- changed (2026-02-04):
[0000080420-26-000015:note_history:28]
We also have sales orders for spare parts and replacement circuit breakers for switchgear that are obsolete or that are no longer produced by the original manufacturer. Revenues from these sales orders are recognized at the time we fulfill our performance obligation to the customer, which is typically upon shipment and represented approximately 6% and 3% of revenues for the three months ended December 31, 2025 and December 31, 2024, respectively.
  (was, 2025-08-06, similarity 0.8311):
[0000080420-25-000098:note_history:28]
We also have sales orders for spare parts and replacement circuit breakers for switchgear that are obsolete or that are no longer produced by the original manufacturer. Revenues from these sales orders are recognized at the time we fulfill our performance obligation to the customer, which is typically upon shipment and represented approximately 5% and 4% of revenues for the three and nine months ended June 30, 2025, respectively, and approximately 4% and 5% of revenues for the three and nine months ended June 30, 2024, respectively.

- changed (2026-02-04):
[0000080420-26-000015:note_history:29]
Selling and administrative costs incurred in relation to obtaining a contract are typically expensed as incurred. We periodically utilize a third-party sales agent to obtain a contract and will pay a commission to that agent. We record the full commission liability to the third-party sales agents at the order date, with a corresponding deferred asset. As the project progresses, we record commission expense based on percentage of completion rates that correlate to the project and reduce the deferred asset. Once we have been paid by the customer, we pay the commission, and the deferred liability is reduced.
  (was, 2025-08-06, similarity 0.9786):
[0000080420-25-000098:note_history:29]
Selling and administrative costs incurred in relation to obtaining a contract are typically expensed as incurred. We periodically utilize a third-party sales agent to obtain a contract and will pay a commission to that agent. We record the full commission liability to the third-party sales agents at the order date, with a corresponding deferred asset. As the project progresses, we record commission expense based on percentage of completion rates that correlate to the project and reduce the deferred asset. Once we have been paid by the customer, we pay the commission and the liability is reduced.

- changed (2026-02-04):
[0000080420-26-000015:note_history:30]
A performance obligation is a promise in a contract or with a customer to transfer a distinct good or service. A contract’s transaction price is allocated to each distinct performance obligation and recognized as revenue as the performance obligations are satisfied. To determine the proper revenue recognition for contracts, we evaluate whether a contract should be accounted for as more than one performance obligation or, less commonly, whether two or more contracts should be combined and accounted for as one performance obligation. This evaluation of performance obligations requires significant judgment. The majority of our contracts have a single performance obligation where multiple engineered products and services are combined into a single custom-engineered solution. Our contracts include a standard one-year assurance warranty. Occasionally, we provide service-type warranties that will extend the warranty period. These extended warranties qualify as a separate performance obligation, and revenue is deferred and recognized over the warranty period. If we determine during the evaluation of the contract that there are multiple performance obligations, we allocate the transaction price to each performance obligation using our best estimate of the standalone selling price of each distinct good or service in the contract. 
Remaining unsatisfied performance obligations, which we refer to as backlog, represent the estimated transaction price for goods and services for which we have a material right, but work has not been performed. As of December 31, 2025, we had backlog of $1.6 billion, of which approximately $933 million is expected to be recognized as revenue within the next twelve months. Backlog may not be indicative of future operating results as orders may be cancelled or modified by our customers. Our backlog does not include service and maintenance-type contracts for which we have the right to invoice as services are performed.
Contract Estimates
  (was, 2025-08-06, similarity 0.8762):
[0000080420-25-000098:note_history:30]
A performance obligation is a promise in a contract or with a customer to transfer a distinct good or service. A contract’s transaction price is allocated to each distinct performance obligation and recognized as revenue as the performance obligations are satisfied. To determine the proper revenue recognition for contracts, we evaluate whether a contract should be accounted for as more than one performance obligation or, less commonly, whether two or more contracts should be combined and accounted for as one performance obligation. This evaluation of performance obligations requires significant judgment. The majority of our contracts have a single performance obligation where multiple engineered products and services are combined into a single custom-engineered solution. Our contracts include a standard one-year assurance warranty. Occasionally, we provide service-type warranties that will extend the warranty period. These extended warranties qualify as a separate performance obligation, and revenue is deferred and recognized over the warranty period. If we determine during the evaluation of the contract that there are multiple performance obligations, we allocate the transaction price to each performance obligation using our best estimate of the standalone selling price of each distinct good or service in the contract. 
Remaining unsatisfied performance obligations, which we refer to as backlog, represent the estimated transaction price for goods and services for which we have a material right, but work has not been performed.
Contract Estimates

- changed (2026-02-04):
[0000080420-26-000015:note_history:31]
Actual revenues and project costs may vary from previous estimates due to changes in a variety of factors. The cost estimation process is based on the professional knowledge and experience of our engineers, project managers and financial professionals. Factors that are considered in estimating the work to be completed and ultimate contract recovery include the availability and productivity of labor, the nature and complexity of the work to be performed, the availability of materials, and the effect of any delays on our project performance. We periodically review our job performance, job conditions, estimated profitability and final contract settlements, including our estimate of total costs and make revisions to costs and income in the period in which the revisions are probable and reasonably estimable. We bear the risk of cost overruns in most of our contracts, which may result in reduced profits. Whenever revisions of estimated contract costs and contract values indicate that the contract costs will exceed estimated revenues, thus creating a loss, a provision for the total estimated loss is recorded in that period.
  (was, 2025-08-06, similarity 0.9991):
[0000080420-25-000098:note_history:31]
Actual revenues and project costs may vary from previous estimates due to changes in a variety of factors. The cost estimation process is based upon the professional knowledge and experience of our engineers, project managers and financial professionals. Factors that are considered in estimating the work to be completed and ultimate contract recovery include the availability and productivity of labor, the nature and complexity of the work to be performed, the availability of materials, and the effect of any delays on our project performance. We periodically review our job performance, job conditions, estimated profitability and final contract settlements, including our estimate of total costs and make revisions to costs and income in the period in which the revisions are probable and reasonably estimable. We bear the risk of cost overruns in most of our contracts, which may result in reduced profits. Whenever revisions of estimated contract costs and contract values indicate that the contract costs will exceed estimated revenues, thus creating a loss, a provision for the total estimated loss is recorded in that period.

- changed (2026-02-04):
[0000080420-26-000015:note_history:32]
Contract liabilities typically represent advance payments from contractual billing milestones and billings in excess of revenue recognized. It is unusual to have advanced milestone payments with a term greater than one year, which could represent a financing component of the contract.  
Our contract assets and liabilities are reported in a net position on a contract-by-contract basis at the end of each reporting period and are generally classified as current.
The timing of our invoice process is typically dependent on the completion of certain milestones and contract terms and is subject to agreement by our customer. Payment is typically expected within 30 days of invoice. Any uncollected invoiced amounts for our performance obligations recognized over time, including contract retentions, are recorded as accounts receivable in the Condensed Consolidated Balance Sheets. Certain contracts allow customers to withhold a small percentage of billings pursuant to retainage provisions, and such amounts are generally due upon completion of the contract and acceptance of 
the project by the customer. Based on our experience in recent years, the majority of these retainage balances are expected to be collected within approximately twelve months.
  (was, 2025-08-06, similarity 0.9984):
[0000080420-25-000098:note_history:32]
Contract liabilities typically represent advance payments from contractual billing milestones and billings in excess of revenue recognized. It is unusual to have advanced milestone payments with a term greater than one year, which could represent a financing component of the contract.  
Our contract assets and liabilities are reported in a net position on a contract-by-contract basis at the end of each reporting period and are generally classified as current.The timing of our invoice process is typically dependent on the completion of certain milestones and contract terms and subject to agreement by our customer. Payment is typically expected within 30 days of invoice. Any uncollected invoiced amounts for our performance obligations recognized over time, including contract retentions, are recorded as accounts receivable in the Condensed Consolidated Balance Sheets. Certain contracts allow customers to withhold a small percentage of billings pursuant to retainage provisions, and such amounts are generally due upon completion of the contract and acceptance of the project by the customer. Based on our experience in recent years, the majority of these retainage balances are expected to be collected within approximately twelve months.


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2026-02-04):
[0000080420-26-000015:note_history:33]
Our revenues are primarily generated from the manufacturing of custom-engineered products and systems under long-term fixed-price contracts under which we agree to manufacture various products such as traditional and arc-resistant distribution switchgear and control gear, medium-voltage circuit breakers, monitoring and control communications systems, motor control centers, switches and bus duct systems. These products may be sold separately as an engineered solution but are typically integrated into custom-built enclosures which we also build. These enclosures are referred to as power control room substations (PCRs®), custom-engineered modules or electrical houses (E-Houses). Some contracts may also include the installation and the commissioning of these enclosures.
  (was, 2025-08-06, similarity 0.9994):
[0000080420-25-000098:note_history:33]
Our revenues are primarily generated from the manufacturing of custom-engineered products and systems under long-term, fixed-price contracts under which we agree to manufacture various products such as traditional and arc-resistant distribution switchgear and control gear, medium-voltage circuit breakers, monitoring and control communications systems, motor control centers, switches and bus duct systems. These products may be sold separately as an engineered solution but are typically integrated into custom-built enclosures which we also build. These enclosures are referred to as power control room substations (PCRs®), custom-engineered modules or electrical houses (E-Houses). Some contracts may also include the installation and the commissioning of these enclosures.

- added (2026-02-04):
[0000080420-26-000015:note_history:34]
Revenue from these contracts is generally recognized over time utilizing the cost-to-cost method. Under the cost-to-cost method, the extent of progress towards completion is measured based on the ratio of costs incurred to date to the total estimated

- changed (2026-02-04):
[0000080420-26-000015:note_history:35]
costs at completion of the performance obligation. We believe that this method is the most accurate representation of our performance because it directly measures the value of the services transferred to the customer over time as we incur costs on our contracts. Contract costs include all direct materials, labor and indirect costs related to contract performance, which may include indirect labor, supplies, tools, repairs and depreciation costs.
  (was, 2025-08-06, similarity 0.7114):
[0000080420-25-000098:note_history:35]
Revenue from these contracts is generally recognized over time utilizing the cost-to-cost method. Under the cost-to-cost method, the extent of progress towards completion is measured based on the ratio of costs incurred to date to the total estimated costs at completion of the performance obligation. We believe that this method is the most accurate representation of our performance because it directly measures the value of the services transferred to the customer over time as we incur costs on our contracts. Contract costs include all direct materials, labor and indirect costs related to contract performance, which may include indirect labor, supplies, tools, repairs and depreciation costs.

- changed (2026-02-04):
[0000080420-26-000015:note_history:36]
We also have contracts to provide field service inspection, installation, commissioning, modification, and repair services, as well as retrofit and retrofill components for existing systems. If the service contract terms give us the right to invoice the customer for an amount that corresponds directly with the value of our performance completed to date (i.e., a service contract in which we bill a fixed amount for each hour of service provided), then we recognize revenue over time in each reporting period corresponding to the amount that we have the right to invoice. Our performance obligations are satisfied as the work progresses. Revenues from our custom-engineered products and value-added services transferred to customers over time accounted for approximately 94% and 97% of revenues for the three months ended December 31, 2025 and December 31, 2024, respectively.
  (was, 2025-08-06, similarity 0.9157):
[0000080420-25-000098:note_history:36]
We also have contracts to provide field service inspection, installation, commissioning, modification, and repair services, as well as retrofit and retrofill components for existing systems. If the service contract terms give us the right to invoice the customer for an amount that corresponds directly with the value of our performance completed to date (i.e., a service contract in which we bill a fixed amount for each hour of service provided), then we recognize revenue over time in each reporting period corresponding to the amount that we have the right to invoice. Our performance obligations are satisfied as the work progresses. Revenues from our custom-engineered products and value-added services transferred to customers over time accounted for approximately 95% and 96% of revenues for the three and nine months ended June 30, 2025, respectively, and approximately 96% and 95% of revenues for the three and nine months ended June 30, 2024, respectively.

- changed (2026-02-04):
[0000080420-26-000015:note_history:37]
We also have sales orders for spare parts and replacement circuit breakers for switchgear that are obsolete or that are no longer produced by the original manufacturer. Revenues from these sales orders are recognized at the time we fulfill our performance obligation to the customer, which is typically upon shipment and represented approximately 6% and 3% of revenues for the three months ended December 31, 2025 and December 31, 2024, respectively.
  (was, 2025-08-06, similarity 0.8311):
[0000080420-25-000098:note_history:37]
We also have sales orders for spare parts and replacement circuit breakers for switchgear that are obsolete or that are no longer produced by the original manufacturer. Revenues from these sales orders are recognized at the time we fulfill our performance obligation to the customer, which is typically upon shipment and represented approximately 5% and 4% of revenues for the three and nine months ended June 30, 2025, respectively, and approximately 4% and 5% of revenues for the three and nine months ended June 30, 2024, respectively.

- changed (2026-02-04):
[0000080420-26-000015:note_history:38]
Selling and administrative costs incurred in relation to obtaining a contract are typically expensed as incurred. We periodically utilize a third-party sales agent to obtain a contract and will pay a commission to that agent. We record the full commission liability to the third-party sales agents at the order date, with a corresponding deferred asset. As the project progresses, we record commission expense based on percentage of completion rates that correlate to the project and reduce the deferred asset. Once we have been paid by the customer, we pay the commission, and the deferred liability is reduced.
  (was, 2025-08-06, similarity 0.9786):
[0000080420-25-000098:note_history:38]
Selling and administrative costs incurred in relation to obtaining a contract are typically expensed as incurred. We periodically utilize a third-party sales agent to obtain a contract and will pay a commission to that agent. We record the full commission liability to the third-party sales agents at the order date, with a corresponding deferred asset. As the project progresses, we record commission expense based on percentage of completion rates that correlate to the project and reduce the deferred asset. Once we have been paid by the customer, we pay the commission and the liability is reduced.

- changed (2026-02-04):
[0000080420-26-000015:note_history:39]
Remaining unsatisfied performance obligations, which we refer to as backlog, represent the estimated transaction price for goods and services for which we have a material right, but work has not been performed. As of December 31, 2025, we had backlog of $1.6 billion, of which approximately $933 million is expected to be recognized as revenue within the next twelve months. Backlog may not be indicative of future operating results as orders may be cancelled or modified by our customers. Our backlog does not include service and maintenance-type contracts for which we have the right to invoice as services are performed.
  (was, 2025-08-06, similarity 0.7318):
[0000080420-25-000098:note_history:39]
Remaining unsatisfied performance obligations, which we refer to as backlog, represent the estimated transaction price for goods and services for which we have a material right, but work has not been performed. As of June 30, 2025, we had backlog of $1.4 billion, of which approximately $913 million is expected to be recognized as revenue within the next twelve months.

- changed (2026-02-04):
[0000080420-26-000015:note_history:40]
Actual revenues and project costs may vary from previous estimates due to changes in a variety of factors. The cost estimation process is based on the professional knowledge and experience of our engineers, project managers and financial professionals. Factors that are considered in estimating the work to be completed and ultimate contract recovery include the availability and productivity of labor, the nature and complexity of the work to be performed, the availability of materials, and the effect of any delays on our project performance. We periodically review our job performance, job conditions, estimated profitability and final contract settlements, including our estimate of total costs and make revisions to costs and income in the period in which the revisions are probable and reasonably estimable. We bear the risk of cost overruns in most of our contracts, which may result in reduced profits. Whenever revisions of estimated contract costs and contract values indicate that the contract costs will exceed estimated revenues, thus creating a loss, a provision for the total estimated loss is recorded in that period.
  (was, 2025-08-06, similarity 0.9991):
[0000080420-25-000098:note_history:40]
Actual revenues and project costs may vary from previous estimates due to changes in a variety of factors. The cost estimation process is based upon the professional knowledge and experience of our engineers, project managers and financial professionals. Factors that are considered in estimating the work to be completed and ultimate contract recovery include the availability and productivity of labor, the nature and complexity of the work to be performed, the availability of materials, and the effect of any delays on our project performance. We periodically review our job performance, job conditions, estimated profitability and final contract settlements, including our estimate of total costs and make revisions to costs and income in the period in which the revisions are probable and reasonably estimable. We bear the risk of cost overruns in most of our contracts, which may result in reduced profits. Whenever revisions of estimated contract costs and contract values indicate that the contract costs will exceed estimated revenues, thus creating a loss, a provision for the total estimated loss is recorded in that period.

- changed (2026-02-04):
[0000080420-26-000015:note_history:41]
For the three months ended December 31, 2025 and 2024, our operating results were positively impacted by $10.5 million and $2.4 million, respectively, as a result of net changes in contract estimates related to projects in progress at the beginning of the respective period. These changes in estimates resulted primarily from favorable project execution, reduced cost estimates and negotiations of variable consideration, discussed below, as well as revenue recognized from project cancellations and other changes in facts and circumstances during these periods. Gross unfavorable changes in contract estimates were immaterial for both the three months ended December 31, 2025 and 2024.
  (was, 2025-08-06, similarity 0.9103):
[0000080420-25-000098:note_history:41]
For the nine months ended June 30, 2025 and 2024, our operating results were positively impacted by $15.1 million and $14.2 million, respectively, as a result of net changes in contract estimates related to projects in progress at the beginning of the respective period. These changes in estimates resulted primarily from favorable project execution, reduced cost estimates and negotiations of variable consideration, discussed below, as well as revenue recognized from project cancellations and other changes in facts and circumstances during these periods. Gross unfavorable changes in contract estimates were immaterial for both the nine months ended June 30, 2025 and 2024.

- changed (2026-02-04):
[0000080420-26-000015:note_history:42]
Contract assets and liabilities as of December 31, 2025 and September 30, 2025 are summarized below (in thousands):
  (was, 2025-08-06, similarity 0.9515):
[0000080420-25-000098:note_history:42]
Contract assets and liabilities as of June 30, 2025 and September 30, 2024 are summarized below (in thousands):

- changed (2026-02-04):
[0000080420-26-000015:note_history:43]
|  | December 31, 2025 |  | September 30, 2025 |
| Contract assets | $ | 121,543 |  |  | $ | 136,679 |  |
| Contract liabilities | (302,143) |  |  | (297,949) |  |
| Net contract liability | $ | (180,600) |  |  | $ | (161,270) |  |
  (was, 2025-08-06, similarity 0.9709):
[0000080420-25-000098:note_history:43]
|  | June 30, 2025 |  | September 30, 2024 |
| Contract assets | $ | 133,015 |  |  | $ | 102,827 |  |
| Contract liabilities | (299,512) |  |  | (287,763) |  |
| Net contract liability | $ | (166,497) |  |  | $ | (184,936) |  |

- changed (2026-02-04):
[0000080420-26-000015:note_history:44]
Our net contract billing position remained a net liability at both December 31, 2025 and September 30, 2025, primarily due to favorable contract billing milestones. We typically allocate a significant percentage of the progress billing to the early stages of the contract. To determine the amount of revenue recognized during the period from contract liabilities, we first allocate revenue to the individual contract liability balance outstanding at the beginning of the period until the revenue exceeds that balance. During the three months ended December 31, 2025, we recognized revenue of $120.3 million that was related to contract liabilities outstanding at September 30, 2025.
  (was, 2025-08-06, similarity 0.9531):
[0000080420-25-000098:note_history:44]
Our net contract billing position remained a net liability at both June 30, 2025 and September 30, 2024, primarily due to favorable contract billing milestones. We typically allocate a significant percentage of the progress billing to the early stages of the contract. To determine the amount of revenue recognized during the period from contract liabilities, we first allocate revenue to the individual contract liability balance outstanding at the beginning of the period until the revenue exceeds that balance. During the nine months ended June 30, 2025, we recognized revenue of $244.4 million that was related to contract liabilities outstanding at September 30, 2024.

- changed (2026-02-04):
[0000080420-26-000015:note_history:45]
The timing of our invoice process is typically dependent on the completion of certain milestones and contract terms and is subject to agreement by our customer. Payment is typically expected within 30 days of invoice. Any uncollected invoiced amounts for our performance obligations recognized over time, including contract retentions, are recorded as accounts receivable in the Condensed Consolidated Balance Sheets. Certain contracts allow customers to withhold a small percentage of billings pursuant to retainage provisions, and such amounts are generally due upon completion of the contract and acceptance of
  (was, 2025-08-06, similarity 0.7194):
[0000080420-25-000098:note_history:45]
The timing of our invoice process is typically dependent on the completion of certain milestones and contract terms and subject to agreement by our customer. Payment is typically expected within 30 days of invoice. Any uncollected invoiced amounts for our performance obligations recognized over time, including contract retentions, are recorded as accounts receivable in the Condensed Consolidated Balance Sheets. Certain contracts allow customers to withhold a small percentage of billings pursuant to retainage provisions, and such amounts are generally due upon completion of the contract and acceptance of the project by the customer. Based on our experience in recent years, the majority of these retainage balances are expected to be collected within approximately twelve months. As of June 30, 2025 and September 30, 2024, we had retention amounts of $8.0 million and $7.1 million, respectively. Of the retained amount at June 30, 2025, $7.5 million is expected to be collected in the next twelve months and is recorded in accounts receivable. The remaining $0.5 million is recorded in other assets.

- added (2026-02-04):
[0000080420-26-000015:note_history:46]
the project by the customer. Based on our experience in recent years, the majority of these retainage balances are expected to be collected within approximately twelve months. As of December 31, 2025 and September 30, 2025, we had retention amounts of $7.2 million and $8.1 million, respectively. Of the retained amount at December 31, 2025, $7.0 million is expected to be collected in the next twelve months and is recorded in accounts receivable. The remaining $0.2 million is recorded in other assets.

- changed (2026-02-04):
[0000080420-26-000015:note_history:47]
The following tables present our disaggregated revenue by geographic destination and market sector for the three months ended December 31, 2025 and 2024 (in thousands):
  (was, 2025-08-06, similarity 0.9415):
[0000080420-25-000098:note_history:47]
The following tables present our disaggregated revenue by geographic destination and market sector for the three and nine months ended June 30, 2025 and 2024 (in thousands):

- added (2026-02-04):
[0000080420-26-000015:note_history:48]
|  | Three months ended December 31, |  |  |
|  | 2025 |  | 2024 |  |  |  |  |
| United States | $ | 194,878 |  |  | $ | 197,772 |  |  |  |  |  |
| Canada | 32,459 |  |  | 31,694 |  |  |  |  |  |
| Middle East and Africa | 9,872 |  |  | 4,558 |  |  |  |  |  |
| Europe | 8,226 |  |  | 5,528 |  |  |  |  |  |
| Asia/Pacific | 5,303 |  |  | 1,580 |  |  |  |  |  |
| Mexico, Central and South America | 446 |  |  | 299 |  |  |  |  |  |
| Total revenues by geographic destination | $ | 251,184 |  |  | $ | 241,431 |  |  |  |  |  |

- added (2026-02-04):
[0000080420-26-000015:note_history:49]
|  | Three months ended December 31, |  |  |
|  | 2025 |  | 2024 |  |  |  |  |
| Oil and gas (excludes petrochemical) | $ | 97,889 |  |  | $ | 95,679 |  |  |  |  |  |
| Electric utility | 69,273 |  |  | 51,240 |  |  |  |  |  |
| Commercial and other industrial | 40,625 |  |  | 44,300 |  |  |  |  |  |
| Petrochemical | 22,778 |  |  | 33,183 |  |  |  |  |  |
| Light rail traction power | 8,614 |  |  | 8,228 |  |  |  |  |  |
| All others | 12,005 |  |  | 8,801 |  |  |  |  |  |
| Total revenues by market sector | $ | 251,184 |  |  | $ | 241,431 |  |  |  |  |  |

- removed (2026-02-04):
[0000080420-25-000098:note_history:50]
Backlog may not be indicative of future operating results as orders may be cancelled or modified by our customers. Our backlog does not include service and maintenance-type contracts for which we have the right to invoice as services are performed.

- removed (2026-02-04):
[0000080420-25-000098:note_history:51]
|  | Three months ended June 30, |  | Nine months ended June 30, |
|  | 2025 |  | 2024 |  | 2025 |  | 2024 |
| United States | $ | 224,537 |  |  | $ | 243,744 |  |  | $ | 650,143 |  |  | $ | 620,537 |  |
| Canada | 42,611 |  |  | 29,695 |  |  | 108,275 |  |  | 74,205 |  |
| Europe | 5,522 |  |  | 9,464 |  |  | 16,947 |  |  | 24,261 |  |
| Middle East and Africa | 9,917 |  |  | 2,322 |  |  | 22,757 |  |  | 8,400 |  |
| Mexico, Central and South America | 1,881 |  |  | 1,962 |  |  | 3,182 |  |  | 6,778 |  |
| Asia/Pacific | 1,805 |  |  | 981 |  |  | 5,031 |  |  | 3,112 |  |
| Total revenues by geographic destination | $ | 286,273 |  |  | $ | 288,168 |  |  | $ | 806,335 |  |  | $ | 737,293 |  |

- removed (2026-02-04):
[0000080420-25-000098:note_history:52]
|  | Three months ended June 30, |  | Nine months ended June 30, |
|  | 2025 |  | 2024 |  | 2025 |  | 2024 |
| Oil and gas (excludes petrochemical) | $ | 105,464 |  |  | $ | 114,336 |  |  | $ | 302,310 |  |  | $ | 301,792 |  |
| Petrochemical | 36,349 |  |  | 56,784 |  |  | 113,236 |  |  | 135,221 |  |
| Electric utility | 74,909 |  |  | 57,009 |  |  | 196,488 |  |  | 145,214 |  |
| Commercial and other industrial | 49,519 |  |  | 42,044 |  |  | 134,188 |  |  | 101,610 |  |
| Light rail traction power | 8,549 |  |  | 5,322 |  |  | 26,785 |  |  | 14,184 |  |
| All others | 11,483 |  |  | 12,673 |  |  | 33,328 |  |  | 39,272 |  |
| Total revenues by market sector | $ | 286,273 |  |  | $ | 288,168 |  |  | $ | 806,335 |  |  | $ | 737,293 |  |


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: tag_name, score: 1.0

- changed (2026-02-04):
[0000080420-26-000015:note_history:53]
Subsequent Events
Quarterly Dividend Declared
  (was, 2025-08-06, similarity 0.75):
[0000080420-25-000098:note_history:53]
Quarterly Dividend Declared

- added (2026-02-04):
[0000080420-26-000015:note_history:54]
On February 3, 2026, our Board of Directors approved an increase to the quarterly cash dividend on our common stock to $0.27 per share, equating to an annualized dividend of $1.08 per share from the current amount of $1.07 per share. The dividend is payable on March 18, 2026 to shareholders of record at the close of business on February 18, 2026.

- removed (2026-02-04):
[0000080420-25-000098:note_history:55]
Subsequent Events
Business Acquisition

- removed (2026-02-04):
[0000080420-25-000098:note_history:56]
As previously announced, on July 15, 2025, we entered into a definitive agreement to acquire Remsdaq Ltd. (Remsdaq), a U.K.-based manufacturer of Supervisory Control and Data Acquisition Remote Terminal Units for electrical substation control and automation in generation, transmission and distribution, for total consideration of £12.2 million Pounds Sterling, or approximately $16.3 million, which will be funded with cash on hand. The consideration included an upfront payment of £9.2 million Pounds Sterling with the remaining portion contingent upon Remsdaq meeting certain technical and financial milestones. We expect the transaction to close during the fourth quarter of Fiscal 2025, subject to customary closing conditions.

- removed (2026-02-04):
[0000080420-25-000098:note_history:57]
One Big Beautiful Bill Act

- removed (2026-02-04):
[0000080420-25-000098:note_history:58]
On July 4, 2025, President Trump signed into law the One Big Beautiful Bill Act (the OBBBA), which includes a broad range of tax reform provisions affecting businesses. The OBBBA extends and modifies certain key 2017 Tax Cuts & Jobs Act (TCJA) provisions (both domestic and international) and revamps some of the TCJA’s provisions on the taxation of corporations’ foreign income. The OBBBA also expands certain Inflation Reduction Act incentives while accelerating the phase-out of others. We are currently evaluating the impact of the OBBBA on our operations, financial results and liquidity.

- removed (2026-02-04):
[0000080420-25-000098:note_history:59]
On August 5, 2025, our Board of Directors declared a quarterly cash dividend on our common stock in the amount of $0.2675 per share. The dividend is payable on September 17, 2025 to shareholders of record at the close of business on August 20, 2025.
