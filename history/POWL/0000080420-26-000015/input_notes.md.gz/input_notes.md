# POWL notes — 0000080420-26-000015


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureAndSignificantAccountingPoliciesTextBlock

[0000080420-26-000015:notes:1]
[same as prior period, unchanged from 0000080420-25-000098:notes:1]

[0000080420-26-000015:notes:2]
Powell Industries, Inc. (we, us, our, Powell or the Company) is a Delaware corporation founded by William E. Powell in 1947. We develop, design, manufacture and service custom-engineered equipment and systems that distribute, control and monitor the flow of electrical energy and provide protection to motors, transformers and other electrically powered equipment. Our major subsidiaries, all of which are wholly owned, include Powell Electrical Systems, Inc.; Powell Canada Inc.; Powell (UK) Limited;  and Powell Industries International Limited.

[0000080420-26-000015:notes:3]
We are headquartered in Houston, Texas, and primarily serve the oil and gas and petrochemical markets, the electric utility market, and commercial and other industrial markets. Beyond these major markets, we also provide products and services to the light rail traction power market and other markets that include universities and government entities. We are continuously developing new channels to electrical markets through original equipment manufacturers and distribution market channels.

[0000080420-26-000015:notes:4]
[same as prior period, unchanged from 0000080420-25-000098:notes:4]

[0000080420-26-000015:notes:5]
The unaudited condensed consolidated financial statements include the accounts of Powell and our wholly-owned subsidiaries. All intercompany accounts and transactions have been eliminated in consolidation.

[0000080420-26-000015:notes:6]
[same as prior period, unchanged from 0000080420-25-000098:notes:6]

[0000080420-26-000015:notes:7]
The unaudited condensed consolidated financial statements should be read in conjunction with the audited consolidated financial statements and notes thereto of Powell and its subsidiaries included in Powell’s Annual Report on Form 10-K for the year ended September 30, 2025, which was filed with the Securities and Exchange Commission (SEC) on November 19, 2025.

[0000080420-26-000015:notes:8]
References to Fiscal 2026 and Fiscal 2025 used throughout this report shall mean the current fiscal year ending September 30, 2026 and the prior fiscal year ended September 30, 2025, respectively.

[0000080420-26-000015:notes:9]
[same as prior period, unchanged from 0000080420-25-000098:notes:9]

[0000080420-26-000015:notes:10]
The preparation of condensed consolidated financial statements in conformity with U.S. GAAP requires management to make estimates and assumptions that affect the amounts reported in the condensed consolidated financial statements and accompanying footnotes. The most significant estimates used in our condensed consolidated financial statements affect revenue recognition and estimated cost recognition on our customer contracts, allowance for credit losses, provision for excess and obsolete inventory, warranty accruals and income taxes. The amounts recorded for warranties, legal, income taxes, impairment of long-lived assets, intangible assets and goodwill (when applicable), liquidated damages and other contingent liabilities require judgments regarding the amount of expenses that will ultimately be incurred. We base our estimates on historical experience, forecasts and various other assumptions, as well as the specific circumstances surrounding these contingent liabilities, in evaluating the amount of liability that should be recorded. Additionally, the basis for recognition of deferred tax assets requires estimates related to future income and other assumptions regarding timing and future profitability because the ultimate realization of net deferred tax assets is dependent on the generation of future taxable income during periods in which temporary differences become deductible. Estimates routinely change as new events occur, additional information becomes available or operating environments change. Actual results may differ from our prior estimates.

[0000080420-26-000015:notes:11]
Recently Adopted Accounting Standards Update

[0000080420-26-000015:notes:12]
The Company adopted the Financial Accounting Standard Board (FASB) Accounting Standards Update (ASU) 2023‑07, Segment Reporting (Topic 280): Improvements to Reportable Segment Disclosures, effective October 1, 2024, on a retrospective basis. This standard requires expanded annual and interim segment disclosures, including significant segment expenses regularly reviewed by the chief operating decision maker (CODM), along with disclosure of the CODM’s title and how segment information is used in evaluating performance and allocating resources. It also clarifies that entities with a single reportable segment must provide all required Topic 280 disclosures. Adoption of the standard did not have a material impact on the unaudited condensed consolidated financial statements. Additional details are included in Note K. Segment Information.

[0000080420-26-000015:notes:13]
Accounting Standards Updates Issued but Not Yet Adopted

[0000080420-26-000015:notes:14]
In December 2023, the FASB issued ASU 2023-09, Improvements to Income Tax Disclosures, which enhances the transparency of income tax disclosures. It requires greater disaggregation of information in the tax rate reconciliation and income taxes paid disaggregated by jurisdiction. This ASU is effective for fiscal years beginning after December 15, 2024, and should be applied on a prospective basis. Retrospective application and early adoption were permitted. We are currently evaluating the impacts of the new standard.

[0000080420-26-000015:notes:15]
In November 2024, the FASB issued ASU No. 2024-03, Reporting Comprehensive Income – Expense Disaggregation Disclosures, which requires additional qualitative and quantitative information about specific expense categories in the notes to financial statements for both interim and annual reporting periods. In January 2025, the FASB further clarified the effective date for interim reporting periods. This ASU is effective for fiscal years beginning after December 15, 2026 and interim periods within those fiscal years beginning after December 15, 2027, with early adoption permitted. We are currently evaluating the impacts of the new standard.


## us-gaap:EarningsPerShareTextBlock

[0000080420-26-000015:notes:16]
[same as prior period, unchanged from 0000080420-25-000098:notes:16]

[0000080420-26-000015:notes:17]
[same as prior period, unchanged from 0000080420-25-000098:notes:17]

[0000080420-26-000015:notes:18]
|  | Three months ended December 31, |  |  |
|  | 2025 |  | 2024 |  |  |  |  |
| Numerator: |  |  |  |  |  |  |  |
| Net income | $ | 41,390 |  |  | $ | 34,763 |  |  |  |  |  |
| Denominator: |  |  |  |  |  |  |  |
| Weighted average basic shares | 12,109 |  |  | 12,037 |  |  |  |  |  |
| Dilutive effect of restricted stock and restricted stock units | 54 |  |  | 115 |  |  |  |  |  |
| Weighted average diluted shares | 12,163 |  |  | 12,152 |  |  |  |  |  |
| Earnings per share: |  |  |  |  |  |  |  |
| Basic | $ | 3.42 |  |  | $ | 2.89 |  |  |  |  |  |
| Diluted | $ | 3.40 |  |  | $ | 2.86 |  |  |  |  |  |


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0000080420-26-000015:notes:19]
[same as prior period, unchanged from 0000080420-25-000098:notes:19]

[0000080420-26-000015:notes:20]
[same as prior period, unchanged from 0000080420-25-000098:notes:20]

[0000080420-26-000015:notes:21]
|  | December 31, 2025 |  | September 30, 2025 |
| Raw materials, parts and sub-assemblies | $ | 91,038 |  |  | $ | 90,743 |  |
| Work-in-progress | 2,093 |  |  | 2,222 |  |
| Provision for excess and obsolete inventories | (8,172) |  |  | (8,246) |  |
| Total inventories | $ | 84,959 |  |  | $ | 84,719 |  |

[0000080420-26-000015:notes:22]
[same as prior period, unchanged from 0000080420-25-000098:notes:22]

[0000080420-26-000015:notes:23]
[same as prior period, unchanged from 0000080420-25-000098:notes:23]

[0000080420-26-000015:notes:24]
|  | December 31, 2025 |  | September 30, 2025 |  |  |  |  |
| Land | $ | 24,510 |  |  | $ | 24,436 |  |  |  |  |  |
| Buildings and improvements | 133,759 |  |  | 133,455 |  |  |  |  |  |
| Machinery and equipment | 100,412 |  |  | 99,840 |  |  |  |  |  |
| Furniture and fixtures | 3,284 |  |  | 3,056 |  |  |  |  |  |
| Construction in process | 4,041 |  |  | 2,110 |  |  |  |  |  |
|  | $ | 266,006 |  |  | $ | 262,897 |  |  |  |  |  |
| Less: Accumulated depreciation | (154,174) |  |  | (151,848) |  |  |  |  |  |
| Total property, plant and equipment, net | $ | 111,832 |  |  | $ | 111,049 |  |  |  |  |  |

[0000080420-26-000015:notes:25]
There were no assets under finance lease as of December 31, 2025 or September 30, 2025.

[0000080420-26-000015:notes:26]
[same as prior period, unchanged from 0000080420-25-000098:notes:26]

[0000080420-26-000015:notes:27]
[same as prior period, unchanged from 0000080420-25-000098:notes:27]

[0000080420-26-000015:notes:28]
|  | Three months ended December 31, |  |  |
|  | 2025 |  | 2024 |  |  |  |  |
| Balance at beginning of period | $ | 6,356 |  |  | $ | 5,822 |  |  |  |  |  |
| Increase to warranty expense | 1,970 |  |  | 1,497 |  |  |  |  |  |
| Deduction for warranty charges | (1,666) |  |  | (1,149) |  |  |  |  |  |
| Change due to foreign currency translation | 16 |  |  | (64) |  |  |  |  |  |
| Balance at end of period | $ | 6,676 |  |  | $ | 6,106 |  |  |  |  |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0000080420-26-000015:notes:29]
[same as prior period, unchanged from 0000080420-25-000098:notes:29]

[0000080420-26-000015:notes:30]
Our revenues are primarily generated from the manufacturing of custom-engineered products and systems under long-term fixed-price contracts under which we agree to manufacture various products such as traditional and arc-resistant distribution switchgear and control gear, medium-voltage circuit breakers, monitoring and control communications systems, motor control centers, switches and bus duct systems. These products may be sold separately as an engineered solution but are typically integrated into custom-built enclosures which we also build. These enclosures are referred to as power control room substations (PCRs®), custom-engineered modules or electrical houses (E-Houses). Some contracts may also include the installation and the commissioning of these enclosures.

[0000080420-26-000015:notes:31]
Revenue from these contracts is generally recognized over time utilizing the cost-to-cost method. Under the cost-to-cost method, the extent of progress towards completion is measured based on the ratio of costs incurred to date to the total estimated

[0000080420-26-000015:notes:32]
costs at completion of the performance obligation. We believe that this method is the most accurate representation of our performance because it directly measures the value of the services transferred to the customer over time as we incur costs on our contracts. Contract costs include all direct materials, labor and indirect costs related to contract performance, which may include indirect labor, supplies, tools, repairs and depreciation costs.

[0000080420-26-000015:notes:33]
We also have contracts to provide field service inspection, installation, commissioning, modification, and repair services, as well as retrofit and retrofill components for existing systems. If the service contract terms give us the right to invoice the customer for an amount that corresponds directly with the value of our performance completed to date (i.e., a service contract in which we bill a fixed amount for each hour of service provided), then we recognize revenue over time in each reporting period corresponding to the amount that we have the right to invoice. Our performance obligations are satisfied as the work progresses. Revenues from our custom-engineered products and value-added services transferred to customers over time accounted for approximately 94% and 97% of revenues for the three months ended December 31, 2025 and December 31, 2024, respectively.

[0000080420-26-000015:notes:34]
We also have sales orders for spare parts and replacement circuit breakers for switchgear that are obsolete or that are no longer produced by the original manufacturer. Revenues from these sales orders are recognized at the time we fulfill our performance obligation to the customer, which is typically upon shipment and represented approximately 6% and 3% of revenues for the three months ended December 31, 2025 and December 31, 2024, respectively.

[0000080420-26-000015:notes:35]
[same as prior period, unchanged from 0000080420-25-000098:notes:34]

[0000080420-26-000015:notes:36]
Selling and administrative costs incurred in relation to obtaining a contract are typically expensed as incurred. We periodically utilize a third-party sales agent to obtain a contract and will pay a commission to that agent. We record the full commission liability to the third-party sales agents at the order date, with a corresponding deferred asset. As the project progresses, we record commission expense based on percentage of completion rates that correlate to the project and reduce the deferred asset. Once we have been paid by the customer, we pay the commission, and the deferred liability is reduced.

[0000080420-26-000015:notes:37]
[same as prior period, unchanged from 0000080420-25-000098:notes:36]

[0000080420-26-000015:notes:38]
[same as prior period, unchanged from 0000080420-25-000098:notes:37]

[0000080420-26-000015:notes:39]
Remaining unsatisfied performance obligations, which we refer to as backlog, represent the estimated transaction price for goods and services for which we have a material right, but work has not been performed. As of December 31, 2025, we had backlog of $1.6 billion, of which approximately $933 million is expected to be recognized as revenue within the next twelve months. Backlog may not be indicative of future operating results as orders may be cancelled or modified by our customers. Our backlog does not include service and maintenance-type contracts for which we have the right to invoice as services are performed.

[0000080420-26-000015:notes:40]
[same as prior period, unchanged from 0000080420-25-000098:notes:40]

[0000080420-26-000015:notes:41]
Actual revenues and project costs may vary from previous estimates due to changes in a variety of factors. The cost estimation process is based on the professional knowledge and experience of our engineers, project managers and financial professionals. Factors that are considered in estimating the work to be completed and ultimate contract recovery include the availability and productivity of labor, the nature and complexity of the work to be performed, the availability of materials, and the effect of any delays on our project performance. We periodically review our job performance, job conditions, estimated profitability and final contract settlements, including our estimate of total costs and make revisions to costs and income in the period in which the revisions are probable and reasonably estimable. We bear the risk of cost overruns in most of our contracts, which may result in reduced profits. Whenever revisions of estimated contract costs and contract values indicate that the contract costs will exceed estimated revenues, thus creating a loss, a provision for the total estimated loss is recorded in that period.

[0000080420-26-000015:notes:42]
For the three months ended December 31, 2025 and 2024, our operating results were positively impacted by $10.5 million and $2.4 million, respectively, as a result of net changes in contract estimates related to projects in progress at the beginning of the respective period. These changes in estimates resulted primarily from favorable project execution, reduced cost estimates and negotiations of variable consideration, discussed below, as well as revenue recognized from project cancellations and other changes in facts and circumstances during these periods. Gross unfavorable changes in contract estimates were immaterial for both the three months ended December 31, 2025 and 2024.

[0000080420-26-000015:notes:43]
[same as prior period, unchanged from 0000080420-25-000098:notes:43]

[0000080420-26-000015:notes:44]
[same as prior period, unchanged from 0000080420-25-000098:notes:44]

[0000080420-26-000015:notes:45]
[same as prior period, unchanged from 0000080420-25-000098:notes:45]

[0000080420-26-000015:notes:46]
[same as prior period, unchanged from 0000080420-25-000098:notes:46]

[0000080420-26-000015:notes:47]
[same as prior period, unchanged from 0000080420-25-000098:notes:47]

[0000080420-26-000015:notes:48]
[same as prior period, unchanged from 0000080420-25-000098:notes:48]

[0000080420-26-000015:notes:49]
[same as prior period, unchanged from 0000080420-25-000098:notes:49]

[0000080420-26-000015:notes:50]
[same as prior period, unchanged from 0000080420-25-000098:notes:50]

[0000080420-26-000015:notes:51]
[same as prior period, unchanged from 0000080420-25-000098:notes:51]

[0000080420-26-000015:notes:52]
Contract assets and liabilities as of December 31, 2025 and September 30, 2025 are summarized below (in thousands):

[0000080420-26-000015:notes:53]
|  | December 31, 2025 |  | September 30, 2025 |
| Contract assets | $ | 121,543 |  |  | $ | 136,679 |  |
| Contract liabilities | (302,143) |  |  | (297,949) |  |
| Net contract liability | $ | (180,600) |  |  | $ | (161,270) |  |

[0000080420-26-000015:notes:54]
Our net contract billing position remained a net liability at both December 31, 2025 and September 30, 2025, primarily due to favorable contract billing milestones. We typically allocate a significant percentage of the progress billing to the early stages of the contract. To determine the amount of revenue recognized during the period from contract liabilities, we first allocate revenue to the individual contract liability balance outstanding at the beginning of the period until the revenue exceeds that balance. During the three months ended December 31, 2025, we recognized revenue of $120.3 million that was related to contract liabilities outstanding at September 30, 2025.

[0000080420-26-000015:notes:55]
The timing of our invoice process is typically dependent on the completion of certain milestones and contract terms and is subject to agreement by our customer. Payment is typically expected within 30 days of invoice. Any uncollected invoiced amounts for our performance obligations recognized over time, including contract retentions, are recorded as accounts receivable in the Condensed Consolidated Balance Sheets. Certain contracts allow customers to withhold a small percentage of billings pursuant to retainage provisions, and such amounts are generally due upon completion of the contract and acceptance of

[0000080420-26-000015:notes:56]
the project by the customer. Based on our experience in recent years, the majority of these retainage balances are expected to be collected within approximately twelve months. As of December 31, 2025 and September 30, 2025, we had retention amounts of $7.2 million and $8.1 million, respectively. Of the retained amount at December 31, 2025, $7.0 million is expected to be collected in the next twelve months and is recorded in accounts receivable. The remaining $0.2 million is recorded in other assets.

[0000080420-26-000015:notes:57]
[same as prior period, unchanged from 0000080420-25-000098:notes:56]

[0000080420-26-000015:notes:58]
The following tables present our disaggregated revenue by geographic destination and market sector for the three months ended December 31, 2025 and 2024 (in thousands):

[0000080420-26-000015:notes:59]
|  | Three months ended December 31, |  |  |
|  | 2025 |  | 2024 |  |  |  |  |
| United States | $ | 194,878 |  |  | $ | 197,772 |  |  |  |  |  |
| Canada | 32,459 |  |  | 31,694 |  |  |  |  |  |
| Middle East and Africa | 9,872 |  |  | 4,558 |  |  |  |  |  |
| Europe | 8,226 |  |  | 5,528 |  |  |  |  |  |
| Asia/Pacific | 5,303 |  |  | 1,580 |  |  |  |  |  |
| Mexico, Central and South America | 446 |  |  | 299 |  |  |  |  |  |
| Total revenues by geographic destination | $ | 251,184 |  |  | $ | 241,431 |  |  |  |  |  |

[0000080420-26-000015:notes:60]
|  | Three months ended December 31, |  |  |
|  | 2025 |  | 2024 |  |  |  |  |
| Oil and gas (excludes petrochemical) | $ | 97,889 |  |  | $ | 95,679 |  |  |  |  |  |
| Electric utility | 69,273 |  |  | 51,240 |  |  |  |  |  |
| Commercial and other industrial | 40,625 |  |  | 44,300 |  |  |  |  |  |
| Petrochemical | 22,778 |  |  | 33,183 |  |  |  |  |  |
| Light rail traction power | 8,614 |  |  | 8,228 |  |  |  |  |  |
| All others | 12,005 |  |  | 8,801 |  |  |  |  |  |
| Total revenues by market sector | $ | 251,184 |  |  | $ | 241,431 |  |  |  |  |  |


## us-gaap:RevenueFromContractWithCustomerPolicyTextBlock

[0000080420-26-000015:notes:61]
[same as prior period, unchanged from 0000080420-25-000098:notes:60]

[0000080420-26-000015:notes:62]
A performance obligation is a promise in a contract or with a customer to transfer a distinct good or service. A contract’s transaction price is allocated to each distinct performance obligation and recognized as revenue as the performance obligations are satisfied. To determine the proper revenue recognition for contracts, we evaluate whether a contract should be accounted for as more than one performance obligation or, less commonly, whether two or more contracts should be combined and accounted for as one performance obligation. This evaluation of performance obligations requires significant judgment. The majority of our contracts have a single performance obligation where multiple engineered products and services are combined into a single custom-engineered solution. Our contracts include a standard one-year assurance warranty. Occasionally, we provide service-type warranties that will extend the warranty period. These extended warranties qualify as a separate performance obligation, and revenue is deferred and recognized over the warranty period. If we determine during the evaluation of the contract that there are multiple performance obligations, we allocate the transaction price to each performance obligation using our best estimate of the standalone selling price of each distinct good or service in the contract. 
Remaining unsatisfied performance obligations, which we refer to as backlog, represent the estimated transaction price for goods and services for which we have a material right, but work has not been performed. As of December 31, 2025, we had backlog of $1.6 billion, of which approximately $933 million is expected to be recognized as revenue within the next twelve months. Backlog may not be indicative of future operating results as orders may be cancelled or modified by our customers. Our backlog does not include service and maintenance-type contracts for which we have the right to invoice as services are performed.
Contract Estimates

[0000080420-26-000015:notes:63]
Contract liabilities typically represent advance payments from contractual billing milestones and billings in excess of revenue recognized. It is unusual to have advanced milestone payments with a term greater than one year, which could represent a financing component of the contract.  
Our contract assets and liabilities are reported in a net position on a contract-by-contract basis at the end of each reporting period and are generally classified as current.
The timing of our invoice process is typically dependent on the completion of certain milestones and contract terms and is subject to agreement by our customer. Payment is typically expected within 30 days of invoice. Any uncollected invoiced amounts for our performance obligations recognized over time, including contract retentions, are recorded as accounts receivable in the Condensed Consolidated Balance Sheets. Certain contracts allow customers to withhold a small percentage of billings pursuant to retainage provisions, and such amounts are generally due upon completion of the contract and acceptance of 
the project by the customer. Based on our experience in recent years, the majority of these retainage balances are expected to be collected within approximately twelve months.


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0000080420-26-000015:notes:64]
Goodwill and Other Intangible Assets
Our intangible assets include goodwill of $6.1 million, which is not being amortized, and other intangible assets of $5.9 million being amortized over their estimated useful lives. No impairment expense has been recorded for the last three fiscal years.

[0000080420-26-000015:notes:65]
Goodwill

[0000080420-26-000015:notes:66]
The changes in the carrying amount of goodwill for the three months ended December 31, 2025 for our single reporting segment are as follows (in thousands):

[0000080420-26-000015:notes:67]
|  |  | Total |
| Balance as of September 30, 2025 |  | $ | 6,125 |  |
| Foreign currency translation adjustment |  | 5 |  |
| Balance as of December 31, 2025 |  | $ | 6,130 |  |

[0000080420-26-000015:notes:68]
Other Intangible Assets

[0000080420-26-000015:notes:69]
Intangible asset balances, subject to amortization, at December 31, 2025 and September 30, 2025 consisted of the following (in thousands):

[0000080420-26-000015:notes:70]
|  | December 31, 2025 |
|  | Weighted Average Remaining Useful Lives in Years |  | GrossCarryingValue |  | AccumulatedAmortization |  | NetCarryingValue |
| Customer relationships | 12 |  | $ | 2,204 |  |  | $ | (69) |  |  | $ | 2,135 |  |
| Technologies | 5 |  | 3,521 |  |  | (227) |  |  | 3,294 |  |
| Trademarks | 10 |  | 475 |  |  | (18) |  |  | 457 |  |
| Order backlog | 1 |  | 55 |  |  | (20) |  |  | 35 |  |
| Total intangible assets |  |  | $ | 6,255 |  |  | $ | (334) |  |  | $ | 5,921 |  |
|  | September 30, 2025 |
|  | Weighted Average Remaining Useful Lives in Years |  | GrossCarryingValue |  | AccumulatedAmortization |  | NetCarryingValue |
| Customer relationships | 12 |  | $ | 2,202 |  |  | $ | (23) |  |  | $ | 2,179 |  |
| Technologies | 5 |  | 3,518 |  |  | (76) |  |  | 3,442 |  |
| Trademarks | 10 |  | 475 |  |  | (6) |  |  | 469 |  |
| Order backlog | 1 |  | 55 |  |  | (7) |  |  | 48 |  |
| Total intangible assets |  |  | $ | 6,250 |  |  | $ | (112) |  |  | $ | 6,138 |  |

[0000080420-26-000015:notes:71]
We have an additional technology intangible asset of $0.5 million associated with an intellectual property acquired in December 2023 which has not yet been subject to amortization.

[0000080420-26-000015:notes:72]
As of December 31, 2025, the estimated future amortization expense of intangible assets is as follows (in thousands):

[0000080420-26-000015:notes:73]
| Remainder of 2026 | $ | 662 |  |
| 2027 | 935 |  |
| 2028 | 935 |  |
| 2029 | 935 |  |
| 2030 | 860 |  |
| Thereafter | 1,594 |  |
| Total | $ | 5,921 |  |


## us-gaap:LongTermDebtTextBlock

[0000080420-26-000015:notes:74]
Long-Term Debt
U.S. Revolver

[0000080420-26-000015:notes:75]
We have a credit agreement with Bank of America, N.A. and Texas Capital Bank with an aggregate commitment of $150.0 million, consisting of $100.0 million committed by Bank of America and $50.0 million committed by Texas Capital Bank (the U.S. Revolver). The U.S. Revolver has an expiration date of October 4, 2028.

[0000080420-26-000015:notes:76]
As of December 31, 2025, there were no amounts borrowed under the U.S. Revolver, and letters of credit outstanding were $65.1 million. There was $84.9 million available for the issuance of letters of credit and borrowings under the U.S. Revolver as of December 31, 2025.

[0000080420-26-000015:notes:77]
As of December 31, 2025, we were in compliance with all of the financial covenants of the U.S. Revolver.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0000080420-26-000015:notes:78]
Commitments and Contingencies
Letters of Credit, Bank Guarantees and Bonds

[0000080420-26-000015:notes:79]
Certain customers require us to post letters of credit, bank guarantees or surety bonds. These security instruments assure that we will perform under the terms of our contract. In the event of default, the counterparty may demand payment from the bank under a letter of credit or bank guarantee, or performance by the surety under a bond. To date, there have been no significant draws or claims related to security instruments for the periods reported. We were contingently liable for letters of credit of $65.1 million as of December 31, 2025. We also had surety bonds totaling $433.8 million that were outstanding, with additional bonding capacity of $766.2 million available, at December 31, 2025. We have strong surety relationships; however, a change in market conditions or the sureties’ assessment of our financial position could cause the sureties to require cash collateralization for undischarged liabilities under the bonds.

[0000080420-26-000015:notes:80]
We have a $20.2 million facility agreement (Facility Agreement) between Powell (UK) Limited and a large international bank that provides Powell (UK) Limited the ability to enter into bank guarantees as well as forward exchange contracts and currency options. At December 31, 2025, we had outstanding guarantees totaling $7.6 million, with an additional capacity of $12.6 million available under this Facility Agreement. The Facility Agreement provides for customary events of default and carries cross-default provisions with the U.S. Revolver. If an event of default (as defined in the Facility Agreement) occurs and is continuing, per the terms and subject to the conditions set forth therein, obligations outstanding under the Facility Agreement may be accelerated and declared immediately due and payable. Additionally, we are required to maintain cash collateral for guarantees greater than two years. As of December 31, 2025, we were in compliance with all of the financial covenants of the Facility Agreement.

[0000080420-26-000015:notes:81]
Litigation

[0000080420-26-000015:notes:82]
We are involved in various legal proceedings, claims and other disputes arising from our commercial operations, projects, employees and other matters which, in general, are subject to uncertainties and in which the outcomes are not predictable. Although we can give no assurances about the resolution of pending claims, litigation or other disputes, and the effect such outcomes may have on us, management believes that any ultimate liability resulting from the outcome of such proceedings, to the extent not otherwise provided or covered by insurance, will not have a material adverse effect on our consolidated financial position, or results of operations or liquidity.

[0000080420-26-000015:notes:83]
Liquidated Damages

[0000080420-26-000015:notes:84]
Certain of our customer contracts have schedule and performance obligation clauses that, if we fail to meet them, could require us to pay liquidated damages. Each individual contract defines the conditions under which the customer may make a claim against us. As of December 31, 2025, certain contracts had a probable exposure to liquidated damages claims of $4.0 million, which could possibly increase to $4.5 million under certain circumstances. Based on our actual or projected failure to meet these various contractual commitments, $3.1 million has been recorded as a reduction to revenue. We will attempt to obtain change orders, contract extensions or accelerate project completion, which may resolve the potential for any unrecorded liquidated damages claims. Should we fail to achieve relief on some or all of these contractual obligations, we could be required to pay additional liquidated damages, which could negatively impact our future operating results.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0000080420-26-000015:notes:85]
Stock-Based Compensation
Refer to our Annual Report on Form 10-K for the fiscal year ended September 30, 2025 for a full description of our existing stock-based compensation plans.

[0000080420-26-000015:notes:86]
[same as prior period, unchanged from 0000080420-25-000098:notes:75]

[0000080420-26-000015:notes:87]
We issue restricted stock units (RSUs) to certain officers and key employees of the Company. The fair value of the RSUs is based on the price of our common stock as reported on the NASDAQ Global Market during a specified period prior to the grant dates. Typically, these grants vest over a three-year period from the date of issuance and are a blend of time-based and performance-based shares. The portion of the grant that is time-based typically vests over a three-year period on each anniversary of the grant date, based on continued employment. The performance-based shares vest based on the three-year revenue growth, earnings and safety performance of the Company following the grant date. At December 31, 2025, there were 54,504 RSUs outstanding. The RSUs do not have voting rights but do receive dividend equivalents upon vesting, which are accrued quarterly. Additionally, the shares of common stock underlying the RSUs are not considered issued and outstanding until vested and common stock is issued.

[0000080420-26-000015:notes:88]
Total RSU activity (number of shares) for the three months ended December 31, 2025 is summarized below:

[0000080420-26-000015:notes:89]
|  | Number ofRestrictedStockUnits |  | WeightedAverageGrant ValuePer Share |
| Outstanding at September 30, 2025 | 116,886 |  |  | $ | 64.79 |  |
| Granted | 15,495 |  |  | 287.28 |  |
| Vested | (77,877) |  |  | 32.67 |  |
| Forfeited/canceled | — |  |  | — |  |
| Outstanding at December 31, 2025 | 54,504 |  |  | $ | 173.93 |  |

[0000080420-26-000015:notes:90]
During the three months ended December 31, 2025 and 2024, we recorded compensation expense of $1.4 million and $1.3 million, respectively, related to the RSUs.

[0000080420-26-000015:notes:91]
Restricted Stock
Each year, every non-employee director receives restricted shares of the Company’s common stock with a grant-date value of $0.1 million. The number of granted shares is calculated by dividing the $0.1 million by the average of high and low prices of our common stock on the grant date. The shares shall vest on the earlier of the grant anniversary date or the date of the next annual meeting of stockholders, whichever occurs first. During both the three months ended December 31, 2025 and 2024, we recorded compensation expense of $0.2 million related to restricted stock.


## us-gaap:FairValueDisclosuresTextBlock

[0000080420-26-000015:notes:92]
[same as prior period, unchanged from 0000080420-25-000098:notes:81]

[0000080420-26-000015:notes:93]
[same as prior period, unchanged from 0000080420-25-000098:notes:82]

[0000080420-26-000015:notes:94]
[same as prior period, unchanged from 0000080420-25-000098:notes:83]

[0000080420-26-000015:notes:95]
[same as prior period, unchanged from 0000080420-25-000098:notes:84]

[0000080420-26-000015:notes:96]
[same as prior period, unchanged from 0000080420-25-000098:notes:85]

[0000080420-26-000015:notes:97]
Recurring Fair Value Measurements

[0000080420-26-000015:notes:98]
The following table summarizes the fair value of our assets and liabilities that were accounted for at fair value on a recurring basis as of December 31, 2025 (in thousands):

[0000080420-26-000015:notes:99]
|  | Fair Value Measurements at December 31, 2025 |
|  | Quoted Prices inActive Markets forIdentical Assets(Level 1) |  | Significant OtherObservableInputs(Level 2) |  | SignificantUnobservableInputs(Level 3) |  | Fair Value at December 31,2025 |
| Assets: |  |  |  |  |  |  |  |
| Cash and cash equivalents | $ | 490,631 |  |  | $ | — |  |  | $ | — |  |  | $ | 490,631 |  |
| Short-term investments | 10,212 |  |  | — |  |  | — |  |  | 10,212 |  |
| Rabbi trust assets | — |  |  | 14,160 |  |  | — |  |  | 14,160 |  |
| Liabilities: |  |  |  |  |  |  |  |
| Deferred compensation | — |  |  | 15,394 |  |  | — |  |  | 15,394 |  |
| Contingent future payments related to the acquisition of Remsdaq | — |  |  | — |  |  | 2,344 |  |  | 2,344 |  |

[0000080420-26-000015:notes:100]
The following table summarizes the fair value of our assets and liabilities that were accounted for at fair value on a recurring basis as of September 30, 2025 (in thousands):

[0000080420-26-000015:notes:101]
|  | Fair Value Measurements at September 30, 2025 |
|  | Quoted Prices inActive Markets forIdentical Assets(Level 1) |  | Significant OtherObservableInputs(Level 2) |  | SignificantUnobservableInputs(Level 3) |  | Fair Value at September 30,2025 |
| Assets: |  |  |  |  |  |  |  |
| Cash and cash equivalents | $ | 450,739 |  |  | $ | — |  |  | $ | — |  |  | $ | 450,739 |  |
| Short-term investments | 24,788 |  |  | — |  |  | — |  |  | 24,788 |  |
| Rabbi trust assets | — |  |  | 13,931 |  |  | — |  |  | 13,931 |  |
| Liabilities: |  |  |  |  |  |  |  |
| Deferred compensation | — |  |  | 13,707 |  |  | — |  |  | 13,707 |  |
| Contingent future payments related to the acquisition of Remsdaq | — |  |  | — |  |  | 2,344 |  |  | 2,344 |  |

[0000080420-26-000015:notes:102]
Fair value guidance requires certain fair value disclosures be presented in both interim and annual reports. The estimated fair value amounts of financial instruments have been determined using available market information and valuation methodologies described below.

[0000080420-26-000015:notes:103]
[same as prior period, unchanged from 0000080420-25-000098:notes:91]

[0000080420-26-000015:notes:104]
[same as prior period, unchanged from 0000080420-25-000098:notes:92]

[0000080420-26-000015:notes:105]
[same as prior period, unchanged from 0000080420-25-000098:notes:93]

[0000080420-26-000015:notes:106]
Contingent future payments related to the acquisition of Remsdaq – The contingent future payments were calculated using a

[0000080420-26-000015:notes:107]
probability outcome model based on internally developed assumptions; accordingly, they are categorized as Level 3 in the fair

[0000080420-26-000015:notes:108]
value measurement hierarchy.

[0000080420-26-000015:notes:109]
There were no transfers between levels within the fair value measurement hierarchy during the quarter ended December 31, 2025.


## us-gaap:LesseeOperatingLeasesTextBlock

[0000080420-26-000015:notes:110]
Leases
Our leases consist primarily of office and warehouse space and construction equipment. All of our future lease obligations are related to non-cancelable operating leases. The following table provides a summary of lease cost components for the three months ended December 31, 2025 and 2024, respectively (in thousands):

[0000080420-26-000015:notes:111]
|  |  | Three months ended December 31, |  |  |
| Lease Cost |  | 2025 |  | 2024 |  |  |  |  |
| Operating lease cost |  | $ | 284 |  |  | $ | 198 |  |  |  |  |  |
| Variable lease cost(1) |  | 43 |  |  | 34 |  |  |  |  |  |
| Short-term lease cost(2) |  | 591 |  |  | 639 |  |  |  |  |  |
| Total lease cost |  | $ | 918 |  |  | $ | 871 |  |  |  |  |  |

[0000080420-26-000015:notes:112]
[same as prior period, unchanged from 0000080420-25-000098:notes:97]

[0000080420-26-000015:notes:113]
[same as prior period, unchanged from 0000080420-25-000098:notes:98]

[0000080420-26-000015:notes:114]
We recognize operating lease assets and operating lease liabilities representing the present value of the remaining lease payments for leases with initial terms greater than twelve months. Leases with initial terms of twelve months or less are not recorded in our Condensed Consolidated Balance Sheets. The following table provides a summary of the operating lease assets and operating lease liabilities included in our Condensed Consolidated Balance Sheets as of December 31, 2025 and September 30, 2025, respectively (in thousands):

[0000080420-26-000015:notes:115]
| Operating Leases |  | December 31, 2025 |  | September 30, 2025 |
| Assets: |  |  |  |  |
| Operating lease assets, net |  | $ | 1,458 |  |  | $ | 1,664 |  |
| Liabilities: |  |  |  |  |
| Current operating lease liabilities |  | 796 |  |  | 882 |  |
| Long-term operating lease liabilities |  | 662 |  |  | 782 |  |
| Total lease liabilities |  | $ | 1,458 |  |  | $ | 1,664 |  |

[0000080420-26-000015:notes:116]
The following table provides the maturities of our operating lease liabilities as of December 31, 2025 (in thousands):

[0000080420-26-000015:notes:117]
|  |  | Operating Leases |  |  |
| Remainder of 2026 |  | $ | 700 |  |  |  |
| 2027 |  | 614 |  |  |  |
| 2028 |  | 215 |  |  |  |
| 2029 |  | 29 |  |  |  |
| 2030 |  | — |  |  |  |
| Thereafter |  | — |  |  |  |
| Total future minimum lease payments |  | $ | 1,558 |  |  |  |
| Less: present value discount (imputed interest) |  | (100) |  |  |  |
| Present value of lease liabilities |  | $ | 1,458 |  |  |  |

[0000080420-26-000015:notes:118]
The weighted average discount rate as of December 31, 2025 and 2024 were 7.15% and 6.13%, respectively. The weighted average remaining lease term was 1.92 years and 2.46 years, respectively, at December 31, 2025 and 2024.


## us-gaap:SegmentReportingDisclosureTextBlock

[0000080420-26-000015:notes:119]
Segment Information
We manage our business as one reportable operating segment and our revenues are primarily generated from the development,

[0000080420-26-000015:notes:120]
design, manufacturing and servicing of custom-engineered equipment and systems for the distribution, control and monitoring

[0000080420-26-000015:notes:121]
of electrical energy.

[0000080420-26-000015:notes:122]
Our chief operating decision maker (“CODM”) is our chief executive officer. The CODM manages and allocates resources on a

[0000080420-26-000015:notes:123]
total consolidated basis by assessing performance of revenues and earnings before interest and taxes (“EBIT”) using actual-to-actual, actual-to-plan and actual-to-forecast variance analysis. The measure of segment profit and loss regularly provided to the

[0000080420-26-000015:notes:124]
CODM that is most consistent with GAAP is consolidated net income, as presented in our Consolidated Statements of Operations. The CODM does not manage cost components by product, customer type or service type, nor does the CODM regularly receive disaggregated information at this level.

[0000080420-26-000015:notes:125]
For the three months ended December 31, 2025 and 2024, the summary of segment net income, including segment expenses, for our single reportable segment were as follows (in thousands):

[0000080420-26-000015:notes:126]
|  | Three months ended December 31, |
|  | 2025 |  | 2024 |
| Revenues | $ | 251,184 |  |  | $ | 241,431 |  |
| Segment operating expenses: |  |  |  |
| Cost of goods sold | 179,766 |  |  | 181,907 |  |
| General and administrative expenses | 17,292 |  |  | 14,851 |  |
| Sales and marketing expenses | 7,745 |  |  | 6,731 |  |
| Research and development expenses | 3,267 |  |  | 2,476 |  |
| Other expense (income)(1) | 343 |  |  | (106) |  |
| Total segment operating expenses | 208,413 |  |  | 205,859 |  |
| Operating income / EBIT | 42,771 |  |  | 35,572 |  |
| Interest income, net | (4,265) |  |  | (3,865) |  |
| Income tax provision | 5,646 |  |  | 4,674 |  |
| Segment net income | $ | 41,390 |  |  | $ | 34,763 |  |
| Gross profit | 71,418 |  |  | 59,524 |  |
| (1) Other expense includes realized currency loss (gain) of $0.1 million and $(0.1) million, respectively. |

[0000080420-26-000015:notes:127]
Revenues by country represent sales to unaffiliated customers as determined by the ultimate destination of our products and services, summarized for the three months ended December 31, 2025 and 2024 (in thousands):

[0000080420-26-000015:notes:128]
|  | Three months ended December 31, |  |  |
|  | 2025 |  | 2024 |  |  |  |  |
| United States | $ | 194,878 |  |  | $ | 197,772 |  |  |  |  |  |
| Canada | 32,459 |  |  | 31,694 |  |  |  |  |  |
| Middle East and Africa | 9,872 |  |  | 4,558 |  |  |  |  |  |
| Europe | 8,226 |  |  | 5,528 |  |  |  |  |  |
| Asia/Pacific | 5,303 |  |  | 1,580 |  |  |  |  |  |
| Mexico, Central and South America | 446 |  |  | 299 |  |  |  |  |  |
| Total revenues | $ | 251,184 |  |  | $ | 241,431 |  |  |  |  |  |

[0000080420-26-000015:notes:129]
Long-lived assets by country consist of property, plant and equipment, net of accumulated depreciation and are determined based on the location of the tangible assets, summarized below (in thousands):

[0000080420-26-000015:notes:130]
|  | December 31, 2025 |  | September 30, 2025 |
| Long-lived assets: |  |  |  |
| United States | $ | 71,437 |  |  | $ | 70,699 |  |
| Canada | 32,931 |  |  | 32,744 |  |
| United Kingdom | 7,464 |  |  | 7,606 |  |
| Total | $ | 111,832 |  |  | $ | 111,049 |  |


## us-gaap:IncomeTaxDisclosureTextBlock

[0000080420-26-000015:notes:131]
[same as prior period, unchanged from 0000080420-25-000098:notes:104]

[0000080420-26-000015:notes:132]
|  | Three months ended December 31, |  |  |
|  | 2025 |  | 2024 |  |  |  |  |
| Income before income taxes | $ | 47,036 |  |  | $ | 39,437 |  |  |  |  |  |
| Income tax provision | 5,646 |  |  | 4,674 |  |  |  |  |  |
| Net income | $ | 41,390 |  |  | $ | 34,763 |  |  |  |  |  |
| Effective tax rate | 12 | % |  | 12 | % |  |  |  |  |

[0000080420-26-000015:notes:133]
Our income tax provision reflects an effective tax rate on pre-tax income of 12% for both the three months ended December 31, 2025 and 2024. The effective tax rates for the first quarters of Fiscal 2026 and Fiscal 2025 were favorably impacted by discrete items related to the vesting of RSUs and the estimated Research and Development (R&D) Tax Credit, which were partially offset by the tax expense related to certain nondeductible items.


## us-gaap:SubsequentEventsTextBlock

[0000080420-26-000015:notes:134]
Subsequent Events
Quarterly Dividend Declared

[0000080420-26-000015:notes:135]
On February 3, 2026, our Board of Directors approved an increase to the quarterly cash dividend on our common stock to $0.27 per share, equating to an annualized dividend of $1.08 per share from the current amount of $1.07 per share. The dividend is payable on March 18, 2026 to shareholders of record at the close of business on February 18, 2026.


## ecd:MtrlTermsOfTrdArrTextBlock

[0000080420-26-000015:notes:136]
On November 26, 2025, Brett A. Cope, President and Chief Executive Officer, adopted a “Rule 10b5-1 trading arrangement,” as the term is defined in Item 408(a) of Regulation S-K, for the sale of up to 8,900 shares of the Company’s common stock, subject to certain conditions, from March 12, 2026 through December 31, 2026.

[0000080420-26-000015:notes:137]
On December 2, 2025, Michael W. Metcalf, Executive Vice President, Chief Financial and Principal Accounting Officer, adopted a “Rule 10b5-1 trading arrangement,” as the term is defined in Item 408(a) of Regulation S-K, for the sale of up to 4,500 shares of the Company’s common stock, subject to certain conditions, from March 31, 2026 through December 31, 2026.
