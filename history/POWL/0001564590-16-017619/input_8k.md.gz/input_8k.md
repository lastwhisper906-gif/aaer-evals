# POWL 8-K — 0001193125-16-576528 filed 2016-05-04

## item codes, every 8-K on or before 2016-05-04

- 2016-05-04 0001193125-16-576528 — 2.02, 8.01, 9.01
- 2016-02-25 0001193125-16-477896 — 5.07
- 2016-02-03 0001193125-16-449052 — 2.02, 8.01, 9.01
- 2015-12-31 0001193125-15-418363 — 5.02, 7.01, 9.01
- 2015-12-02 0001193125-15-393109 — 2.02, 9.01
- 2015-11-05 0001193125-15-368085 — 8.01, 9.01
- 2015-09-25 0001193125-15-329031 — 5.02
- 2015-08-05 0001193125-15-277912 — 2.02, 8.01, 9.01
- 2015-05-06 0001193125-15-174291 — 2.02, 8.01, 9.01
- 2015-03-06 0001193125-15-081070 — 5.02
- 2015-03-02 0001193125-15-072946 — 5.07
- 2015-02-03 0001193125-15-031772 — 2.02, 8.01, 9.01
- 2014-12-18 0001193125-14-446513 — 8.01, 9.01
- 2014-12-03 0001193125-14-431745 — 2.02, 9.01
- 2014-11-05 0001193125-14-397955 — 8.01, 9.01
- 2014-09-26 0001193125-14-353741 — 7.01, 9.01
- 2014-08-05 0001193125-14-296001 — 2.02, 8.01, 9.01
- 2014-05-07 0001193125-14-187496 — 2.02, 8.01, 9.01
- 2014-03-03 0001193125-14-079843 — 5.02, 5.07
- 2014-02-05 0001193125-14-036633 — 2.02, 8.01, 9.01
- 2014-01-17 0001193125-14-014351 — 1.01, 8.01, 9.01
- 2014-01-06 0001193125-14-002795 — 1.01, 2.03
- 2013-12-06 0001564590-13-001411 — 2.02, 9.01
- 2013-12-05 0001564590-13-001406 — 5.02, 8.01, 9.01
- 2013-11-07 0001193125-13-432950 — 8.01, 9.01
- 2013-08-07 0001193125-13-324337 — 2.02, 9.01
- 2013-05-08 0001193125-13-206800 — 2.02, 9.01
- 2013-02-22 0001193125-13-070971 — 5.02, 5.07
- 2013-02-06 0001193125-13-040556 — 2.02, 9.01
- 2012-12-18 0001193125-12-506417 — 5.02, 9.01
- 2012-12-05 0001193125-12-491749 — 2.02, 9.01
- 2012-10-12 0001193125-12-421889 — 3.03, 5.02, 5.03, 9.01
- 2012-08-09 0001193125-12-344617 — 5.02, 8.01, 9.01
- 2012-08-08 0001193125-12-343630 — 2.02, 9.01
- 2012-05-09 0001193125-12-221356 — 2.02, 9.01
- 2012-02-08 0001193125-12-046560 — 2.02, 9.01
- 2011-12-08 0001193125-11-334810 — 2.02, 9.01
- 2011-11-08 0000950123-11-096524 — 2.02, 2.06, 4.02, 9.01
- 2011-10-14 0000950123-11-090124 — 5.02
- 2011-10-06 0000950123-11-088969 — 5.02
- 2011-09-19 0000950123-11-085224 — 5.02, 9.01
- 2011-09-15 0000950123-11-084806 — 5.02, 9.01
- 2011-08-04 0000950123-11-072788 — 2.02, 9.01
- 2011-07-22 0000950123-11-067402 — 5.07
- 2011-05-24 0000950123-11-053550 — 1.01, 2.03, 9.01
- 2011-05-04 0000950123-11-044561 — 2.02, 9.01
- 2011-02-02 0000950123-11-008188 — 2.02, 9.01
- 2010-12-08 0000950123-10-111987 — 2.02, 9.01
- 2010-08-05 0000950123-10-073114 — 2.02, 9.01
- 2010-05-18 0000950123-10-050900 — 5.02
- 2010-05-05 0000950123-10-044499 — 2.02, 9.01
- 2010-02-03 0000950123-10-008278 — 2.02, 9.01
- 2009-12-21 0000950123-09-072269 — 1.01, 2.01, 2.03, 8.01, 9.01
- 2009-12-09 0000950123-09-069525 — 2.02, 9.01
- 2009-10-27 0000950123-09-053501 — 1.01, 8.01, 9.01
- 2009-08-04 0000950123-09-029476 — 2.02, 9.01
- 2009-05-06 0000950129-09-001498 — 2.02, 9.01
- 2009-03-05 0000950129-09-000749 — 1.01, 9.01
- 2009-02-10 0000950129-09-000349 — 2.02, 9.01
- 2008-12-10 0000950134-08-021934 — 2.02, 9.01
- 2008-08-06 0000950129-08-004267 — 2.02, 9.01
- 2008-07-24 0000950129-08-004063 — 1.01, 5.02, 8.01, 9.01
- 2008-06-16 0000950129-08-003500 — 9.01 — amendment of 0000950134-06-015374
- 2008-06-05 0000950129-08-003378 — 5.02, 9.01
- 2008-05-08 0000950129-08-002843 — 2.02, 9.01
- 2008-02-06 0000950129-08-000533 — 2.02, 9.01
- 2007-12-19 0000950129-07-006277 — 1.01, 2.03, 9.01
- 2007-12-06 0000950129-07-006003 — 2.02, 9.01
- 2007-08-21 0000950129-07-004181 — 2.02, 9.01
- 2007-05-31 0000950129-07-002810 — 2.02, 9.01
- 2007-05-21 0000950129-07-002668 — 2.02, 3.01, 4.02, 9.01
- 2007-04-16 0000950129-07-002002 — 2.02, 4.02, 9.01
- 2007-03-01 0000950129-07-001104 — 5.02, 8.01, 9.01
- 2007-02-08 0000950129-07-000451 — 2.02, 9.01
- 2006-12-08 0000950129-06-010041 — 2.02, 9.01
- 2006-09-08 0000950129-06-008379 — 2.02, 9.01
- 2006-08-09 0000950134-06-015374 — 1.01, 2.01, 8.01, 9.01
- 2006-06-08 0000950129-06-006127 — 2.02, 9.01
- 2006-03-09 0000950129-06-002455 — 2.02, 9.01
- 2005-12-16 0000950129-05-012031 — 2.02, 5.03, 9.01
- 2005-09-13 0000950129-05-009181 — 2.01, 9.01 — amendment of 0000950129-05-006889
- 2005-09-12 0000950129-05-009151 — 2.02, 9.01
- 2005-07-06 0000950129-05-006889 — 1.01, 1.02, 2.01, 2.03, 9.01
- 2005-06-10 0000950129-05-006128 — 2.02, 9.01
- 2005-04-20 0000080420-05-000031 — 5.02
- 2005-03-11 0000080420-05-000024 — 9.01
- 2005-02-25 0000080420-05-000018 — 7.01, 9.01
- 2005-01-21 0000080420-05-000009 — 7.01, 9.01
- 2004-12-17 0000080420-04-000049 — 2.02, 9.01
- 2004-11-01 0000080420-04-000045 — 8.01, 9.01
- 2004-10-08 0001169232-04-005133 — 2.05
- 2004-09-14 0000080420-04-000037 — 5.02
- 2004-09-02 0000080420-04-000030 — 2.02, 9.01
- 2004-06-08 0000080420-04-000021 — 7
- 2004-05-13 0000080420-04-000019 — 4
- 2004-02-27 0000080420-04-000013 — 7
- 2003-12-16 0000950129-03-006136 — 12, 7
- 2003-08-29 0000950129-03-004531 — 12, 7
- 2003-06-03 0000950129-03-003035 — 7, 9
- 2003-05-15 0000950129-03-002812 — 7, 9
- 2002-05-29 0000950129-02-002795 — 4
- 2000-12-21 0000950129-00-006093 — 5, 7
- 1998-09-04 0000950129-98-003802 — 5
- 1996-08-09 0000950129-96-001705 — 2, 7

## late-filing notifications on or before 2016-05-04

- 2007-05-11 0000950129-07-002494 — NT 10-Q, for the period ended 2007-03-31
- 2005-01-18 0000080420-05-000004 — NT 10-K, for the period ended 2004-10-31

## item 2.02 — earnings release, exhibit 99.1

[0001193125-16-576528:8k_2_02:1]
EX-99.1
2
d189859dex991.htm
EX-99.1

[0001193125-16-576528:8k_2_02:2]
EX-99.1

[0001193125-16-576528:8k_2_02:3]
Exhibit 99.1

[0001193125-16-576528:8k_2_02:4]
|  |  | PRESS RELEASE |

[0001193125-16-576528:8k_2_02:5]
| FOR IMMEDIATE RELEASE |  | Contacts: Don R. Madison, CFO Powell Industries, Inc. 713-947-4422 |

[0001193125-16-576528:8k_2_02:6]
POWELL INDUSTRIES ANNOUNCES FISCAL 2016

[0001193125-16-576528:8k_2_02:7]
SECOND QUARTER RESULTS

[0001193125-16-576528:8k_2_02:8]
Company reports adjusted diluted EPS of $0.69

[0001193125-16-576528:8k_2_02:9]
HOUSTON — MAY 3, 2016 — Powell Industries, Inc. (NASDAQ: POWL), a leading supplier of custom engineered solutions for the management, control and
distribution of electrical energy, today announced results for the fiscal 2016 second quarter ended March 31, 2016.

[0001193125-16-576528:8k_2_02:10]
Revenues for the
second quarter of fiscal 2016 were $152.3 million compared to revenues of $170.2 million for the second quarter of fiscal 2015. The Company reported net income for the second quarter of $5.6 million, or $0.49 per diluted share, compared to a net
loss of $3.7 million, or $0.31 per diluted share, for the second quarter of fiscal 2015. Excluding restructuring and separation costs, net income for the second quarter of fiscal 2016 was $7.9 million, or $0.69 per diluted share. A
reconciliation of this non-GAAP financial measure to net income is included in the financial tables below.

[0001193125-16-576528:8k_2_02:11]
Thomas W. Powell, President
and Chief Executive Officer, stated, “Across the company, we are realizing positive results from our focus on solid project execution and cost reduction initiatives. We are particularly pleased with the improved operational performance of our
Canadian operation.

[0001193125-16-576528:8k_2_02:12]
“During the second quarter, the impact of reduced capital spending in our primary oil and gas markets reduced
available project opportunities and, as a result, we anticipate these lower order rates to persist through the remainder of the year and into 2017. Operationally, our strong project execution capabilities enable us to support our customers with
their ongoing capital projects. Most notably, with $57 million in cash and virtually no debt, we are well positioned to manage our businesses through the current market cycle.”

[0001193125-16-576528:8k_2_02:13]
New orders placed during the second quarter of fiscal 2016 totaled $117 million compared to $102
million in the first quarter of fiscal 2016 and $167 million in the second quarter of fiscal 2015. The Company’s backlog as of March 31, 2016 was $357 million compared to $391 million as of December 31, 2015 and compared to $499
million at the end of last year’s second quarter.

[0001193125-16-576528:8k_2_02:14]
OUTLOOK

[0001193125-16-576528:8k_2_02:15]
The following statements are based on the current expectations of the Company. These statements are forward-looking, and actual results may
differ materially as further elaborated in the last paragraph below.

[0001193125-16-576528:8k_2_02:16]
Reflecting current backlog and business conditions, Powell expects
full year fiscal 2016 revenues to range between $520 million and $560 million, unchanged from previous guidance, and fiscal year 2016 earnings to range between $0.80 and $1.10 per diluted share, compared to previous earnings guidance of a range
between $0.65 and $1.05 per diluted share. The Company’s earnings guidance excludes restructuring and separations costs. Powell recorded $4.8 million in restructuring and separation costs, net of tax, in the first six months of fiscal 2016 and
will continue to evaluate additional restructuring that may be required to align operating costs with anticipated market conditions.

[0001193125-16-576528:8k_2_02:17]
CONFERENCE CALL

[0001193125-16-576528:8k_2_02:18]
Powell Industries has scheduled a conference call for Wednesday, May 4, 2016 at 11:00 a.m. eastern time. To participate in the
conference call, dial 412-902-0030 at least 10 minutes before the call begins and ask for the Powell Industries conference call. A replay of the call will be available approximately two hours after the live broadcast ends and will be accessible
until May 11, 2016. To access the replay, dial 201-612-7415 using a passcode of 13635395#.

[0001193125-16-576528:8k_2_02:19]
Investors, analysts and the general
public will also have the opportunity to listen to the conference call over the Internet by visiting powellind.com. To listen to the live call on the web, please visit the website at least fifteen minutes before the call begins to register,
download and install any necessary audio software. For those who cannot listen to the live webcast, an archive will be available shortly after the call and will remain available for approximately 90 days at powellind.com.

[0001193125-16-576528:8k_2_02:20]
2

[0001193125-16-576528:8k_2_02:21]
Powell Industries, Inc., headquartered in Houston, engineers packaged solutions and systems for the management,
control and distribution of electrical energy. Powell markets include large industrial customers such as utilities, oil and gas producers, refineries, petrochemical plants, pulp and paper producers, mining operations and commuter
railways. For more information, please visit powellind.com.

[0001193125-16-576528:8k_2_02:22]
This press release contains references to certain non-GAAP financial measures discussed above. Please see the financial table
below for more details on these non-GAAP financial measures, including a reconciliation of these non-GAAP financial measures to net income and the reasons management believes these measures are useful to investors.

[0001193125-16-576528:8k_2_02:23]
3

[0001193125-16-576528:8k_2_02:24]
POWELL INDUSTRIES, INC. & SUBSIDIARIES

[0001193125-16-576528:8k_2_02:25]
CONDENSED CONSOLIDATED STATEMENT OF OPERATIONS

[0001193125-16-576528:8k_2_02:26]
|  |  | Three months endedMarch 31, |  |  | Six months endedMarch 31, |  |
|  |  | 2016 |  |  | 2015 |  |  | 2016 |  |  | 2015 |  |
| (In thousands, except per share data) |  |  |  |  |  |  | (Unaudited) |  |  |  |  |  |
| Revenues |  | $ | 152,266 |  |  | $ | 170,199 |  |  | $ | 302,243 |  |  | $ | 322,800 |  |
| Cost of goods sold |  |  | 122,172 |  |  |  | 145,898 |  |  |  | 248,999 |  |  |  | 277,430 |  |
| Gross profit |  |  | 30,094 |  |  |  | 24,301 |  |  |  | 53,244 |  |  |  | 45,370 |  |
| Selling, general and administrative expenses |  |  | 19,024 |  |  |  | 19,464 |  |  |  | 38,425 |  |  |  | 40,279 |  |
| Research and development expenses |  |  | 1,959 |  |  |  | 1,626 |  |  |  | 3,813 |  |  |  | 3,466 |  |
| Restructuring and separation expenses |  |  | 3,259 |  |  |  | 1,332 |  |  |  | 7,056 |  |  |  | 1,332 |  |
| Amortization of intangible assets |  |  | 86 |  |  |  | 113 |  |  |  | 174 |  |  |  | 232 |  |
| Operating income |  |  | 5,766 |  |  |  | 1,766 |  |  |  | 3,776 |  |  |  | 61 |  |
| Other income |  |  | (507 | ) |  |  | (879 | ) |  |  | (1,015 | ) |  |  | (1,386 | ) |
| Interest expense |  |  | 50 |  |  |  | 33 |  |  |  | 74 |  |  |  | 69 |  |
| Interest income |  |  | (71 | ) |  |  | (84 | ) |  |  | (71 | ) |  |  | (88 | ) |
| Income before income taxes |  |  | 6,294 |  |  |  | 2,696 |  |  |  | 4,788 |  |  |  | 1,466 |  |
| Income tax provision (benefit) |  |  | 727 |  |  |  | 6,379 |  |  |  | (320 | ) |  |  | 5,388 |  |
| Net income |  | $ | 5,567 |  |  | $ | (3,683 | ) |  | $ | 5,108 |  |  | $ | (3,922 | ) |
| Earnings per share: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  | $ | 0.49 |  |  | $ | (0.31 | ) |  | $ | 0.45 |  |  | $ | (0.33 | ) |
| Diluted |  | $ | 0.49 |  |  | $ | (0.31 | ) |  | $ | 0.45 |  |  | $ | (0.33 | ) |
| Weighted average shares: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  |  | 11,369 |  |  |  | 12,018 |  |  |  | 11,382 |  |  |  | 12,029 |  |
| Diluted |  |  | 11,422 |  |  |  | 12,018 |  |  |  | 11,415 |  |  |  | 12,029 |  |
| SELECTED FINANCIAL DATA: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Depreciation and Amortization |  | $ | 3,408 |  |  | $ | 3,358 |  |  | $ | 6,692 |  |  | $ | 6,794 |  |
| Capital Expenditures |  | $ | 497 |  |  | $ | 9,730 |  |  | $ | 1,126 |  |  | $ | 28,692 |  |
| Dividends Paid |  | $ | 2,929 |  |  | $ | 3,136 |  |  | $ | 5,921 |  |  | $ | 6,264 |  |

[0001193125-16-576528:8k_2_02:27]
4

[0001193125-16-576528:8k_2_02:28]
POWELL INDUSTRIES, INC. & SUBSIDIARIES

[0001193125-16-576528:8k_2_02:29]
CONDENSED CONSOLIDATED BALANCE SHEETS

[0001193125-16-576528:8k_2_02:30]
|  |  | March 31,2016 |  |  | September 30,2015 |  |
| (In thousands) |  | (Unaudited) |  |
| Assets: |  |  |  |  |  |  |  |  |
| Cash |  | $ | 57,358 |  |  | $ | 43,569 |  |
| Other current assets |  |  | 235,848 |  |  |  | 253,530 |  |
| Property, plant and equipment (net) |  |  | 150,722 |  |  |  | 154,594 |  |
| Long-term assets |  |  | 16,831 |  |  |  | 17,131 |  |
| Total assets |  | $ | 460,759 |  |  | $ | 468,824 |  |
| Liabilities & equity: |  |  |  |  |  |  |  |  |
| Current liabilities |  | $ | 117,749 |  |  | $ | 124,952 |  |
| Long-term debt, net of current maturities |  |  | 2,000 |  |  |  | 2,400 |  |
| Deferred and other long-term liabilities |  |  | 7,976 |  |  |  | 8,210 |  |
| Stockholders’ equity |  |  | 333,034 |  |  |  | 333,262 |  |
| Total liabilities and stockholders’ equity |  | $ | 460,759 |  |  | $ | 468,824 |  |
| SELECTED FINANCIAL DATA: |  |  |  |  |  |  |  |  |
| Working capital |  | $ | 175,457 |  |  | $ | 172,147 |  |

[0001193125-16-576528:8k_2_02:31]
5

[0001193125-16-576528:8k_2_02:32]
POWELL INDUSTRIES, INC. & SUBSIDIARIES

[0001193125-16-576528:8k_2_02:33]
NON-GAAP NET INCOME RECONCILIATION

[0001193125-16-576528:8k_2_02:34]
|  |  | Three months endedMarch 31, |  |  | Six months endedMarch 31, |  |
| (In thousands) |  | 2016 |  |  | 2015 |  |  | 2016 |  |  | 2015 |  |
|  |  | (Unaudited) |  |  | (Unaudited) |  |
| Net Income: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Income (loss) from continuing operations |  | $ | 5,567 |  |  | $ | (3,683 | ) |  | $ | 5,108 |  |  | $ | (3,922 | ) |
| Restructuring and separation costs, net of tax |  |  | 2,296 |  |  |  | 866 |  |  |  | 4,764 |  |  |  | 866 |  |
| Income tax reserve release (FIN 48) |  |  | — |  |  |  | (4,149 | ) |  |  | — |  |  |  | (4,149 | ) |
| Canadian tax valuation allowance |  |  | — |  |  |  | 8,996 |  |  |  | — |  |  |  | 8,996 |  |
| Non-GAAP net income |  | $ | 7,863 |  |  | $ | 2,030 |  |  | $ | 9,872 |  |  | $ | 1,791 |  |
| Diluted shares outstanding |  |  | 11,422 |  |  |  | 12,018 |  |  |  | 11,415 |  |  |  | 12,029 |  |
| Diluted Earnings Per Share: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Earnings (loss) per share |  | $ | 0.49 |  |  | $ | (0.31 | ) |  | $ | 0.45 |  |  | $ | (0.33 | ) |
| Non-GAAP earnings per share |  | $ | 0.69 |  |  | $ | 0.17 |  |  | $ | 0.86 |  |  | $ | 0.15 |  |

[0001193125-16-576528:8k_2_02:35]
For all periods presented, the Company defines non-GAAP net income as net income from continuing operations which excludes:
1) Restructuring and separation costs, net of tax; 2) the Income tax reserve release (FIN 48); and 3) the Canadian tax valuation allowance. Non-GAAP financial measures should not be considered a substitute for, or superior to, measures of financial
performance prepared in accordance with GAAP. However, the Company believes by excluding these items, these non-GAAP financial measures are helpful in comparing the historical results to current results and measuring operating earnings trends. The
Company also believes the disclosure of non-GAAP net income will help investors meaningfully evaluate and compare its cash flow generating capacity from quarter to quarter and year to year.

[0001193125-16-576528:8k_2_02:36]
The non-GAAP adjustments, and the basis for excluding them from GAAP financial measures, are outlined below:

[0001193125-16-576528:8k_2_02:37]
|  | • |  | Restructuring and separation costs, net of tax – For the six months ended March 31, 2016, we recorded $4.8 million in restructuring and separation costs due to the restructuring of our senior management team and the alignment of our salaried and hourly workforce with future production requirements. In the second quarter of Fiscal 2015, we incurred approximately $0.9 million in restructuring and separation costs. |

[0001193125-16-576528:8k_2_02:38]
|  | • |  | Income tax reserve release (FIN 48) – In the second quarter of Fiscal 2015, we released an income tax reserve of $4.1 million for R&D tax credits upon the closing of an IRS audit |

[0001193125-16-576528:8k_2_02:39]
|  | • |  | Canadian tax valuation allowance – In the second quarter of Fiscal 2015, we established a $9.0 million valuation allowance against the Canadian deferred tax assets because we anticipated that we may not be able to realize the benefits of the net operating loss carryforwards and other deductible differences. |

[0001193125-16-576528:8k_2_02:40]
Due to the nature
of these items, the Company does not believe that these items reflect its ongoing operations.

[0001193125-16-576528:8k_2_02:41]
# # #

[0001193125-16-576528:8k_2_02:42]
6
