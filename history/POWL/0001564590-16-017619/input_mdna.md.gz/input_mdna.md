# POWL MD&A — 0001564590-16-017619


## mdna

[0001564590-16-017619:mdna:1]
[same as prior period, unchanged from 0001564590-16-012239:mdna:1]

[0001564590-16-017619:mdna:2]
[same as prior period, unchanged from 0001564590-16-012239:mdna:2]

[0001564590-16-017619:mdna:3]
[same as prior period, unchanged from 0001564590-16-012239:mdna:3]

[0001564590-16-017619:mdna:4]
We develop, design, manufacture and service custom-engineered equipment and systems for the distribution, control and monitoring of electrical energy. Headquartered in Houston, Texas, we serve the oil and gas refining, offshore oil and gas production, petrochemical, pipeline, terminal, mining and metals, light rail traction power, electric utility, pulp and paper and other industrial markets. Revenues and costs are primarily related to custom engineered-to-order equipment and systems and are accounted for under percentage-of-completion accounting which precludes us from providing detailed price and volume information. Our backlog includes various projects which take a number of months to produce.

[0001564590-16-017619:mdna:5]
The markets in which we participate are capital intensive and cyclical in nature. Cyclicality is predominantly driven by customer demand, global economic conditions and anticipated environmental or regulatory changes which affect the manner in which our customers proceed with capital investments. Our customers analyze various factors including the demand and price for oil, gas and electrical energy, the overall economic and financial environment, governmental budgets, regulatory actions and environmental concerns. These factors influence the release of new capital projects by our customers, which are traditionally awarded in competitive bid situations. Scheduling of projects is matched to the customer requirements and projects typically take a number of months to produce; but schedules may change during the course of any particular project. Our operating results can be impacted by factors outside of our control.

[0001564590-16-017619:mdna:6]
Our strategy in Canada has been to replicate our U.S. project-based integration model which allows for the design, fabrication, integration and testing of our products at a single location.  This strategic initiative presented challenges for our Canadian operations over the last two years resulting in inefficiencies that led to higher operating costs, gross margin deterioration and operating losses.

[0001564590-16-017619:mdna:7]
During Fiscal 2015, our operating results were negatively impacted by operational inefficiencies resulting from increased volume and project scheduling delays. Our inability to meet contractual commitments on existing projects, as well as delays in customer construction schedules, negatively impacted the timing and costs related to project execution. Our operating results were negatively impacted by the timing and resolution of change orders, project close-out and resolution of potential liquidated damage claims, all of which impact gross margins during the period in which these items are resolved with our customers.

[0001564590-16-017619:mdna:8]
During Fiscal 2016, the decline in the number and size of projects in the markets we serve has decreased our revenues and backlog of projects.  In response to our reduced project backlog and continued weak market conditions, we have taken steps to reduce our cost structure, restructure our senior management team and align our salaried and hourly workforce with future production requirements. We have continued to take various actions that have improved our operational efficiencies in Canada.

[0001564590-16-017619:mdna:9]
[same as prior period, unchanged from 0001564590-16-012239:mdna:8]

[0001564590-16-017619:mdna:10]
Quarter Ended March 31, 2016 Compared to the Quarter Ended March 31, 2015 (Unaudited)

[0001564590-16-017619:mdna:11]
[same as prior period, unchanged from 0001564590-16-012239:mdna:9]

[0001564590-16-017619:mdna:12]
Revenues decreased by 11%, or $17.9 million, to $152.3 million in the second quarter of Fiscal 2016, compared to the second quarter of Fiscal 2015, primarily due to the continued decrease in our project backlog mainly driven by lower demand from our customers in the oil and gas markets.  Domestic revenues decreased by 11%, or $13.6 million, to $106.8 million in the second quarter of Fiscal 2016, compared to the second quarter of Fiscal 2015, and international revenues decreased by 9%, or $4.3 million, to $45.5 million in the second quarter of Fiscal 2016, compared to the second quarter of Fiscal 2015 due to the reduced number of large projects in our overseas markets year over year. Revenues from commercial and industrial customers decreased $13.1 million to $115.7 million in the second quarter of Fiscal 2016, compared to the second quarter of Fiscal 2015. Revenues from public and private utilities increased $3.2 million to $26.4 million in the second quarter of Fiscal 2016, compared to the second quarter of Fiscal 2015.  Revenues from municipal and transit projects decreased $8.0 million to $10.2 million in the second quarter of Fiscal 2016, compared to the second quarter of Fiscal 2015.

[0001564590-16-017619:mdna:13]
Gross profit for the second quarter of Fiscal 2016 increased 24%, or $5.8 million, to $30.1 million, compared to the second quarter of Fiscal 2015.  Gross profit as a percentage of revenues increased to 20% in the second quarter of Fiscal 2016, compared to 14% in the second quarter of Fiscal 2015, due to improvements in our international operations primarily driven by improved project execution and reduced costs in our Canadian operations.

[0001564590-16-017619:mdna:14]
[same as prior period, unchanged from 0001564590-16-012239:mdna:12]

[0001564590-16-017619:mdna:15]
Selling, general and administrative expenses decreased $0.4 million to $19.0 million during the second quarter of Fiscal 2016 compared to the second quarter of Fiscal 2015, primarily due to cost reduction efforts.  Selling, general and administrative expenses, as a percentage of revenues, increased to 13% during the second quarter of Fiscal 2016, compared to 11% during the second quarter of Fiscal 2015 primarily due to the reduction in revenue quarter over quarter.

[0001564590-16-017619:mdna:16]
[same as prior period, unchanged from 0001564590-16-012239:mdna:15]

[0001564590-16-017619:mdna:17]
In the second quarter of Fiscal 2016, we incurred $3.3 million of separation costs as we continued to restructure our senior management team and align our salaried and hourly workforce with future production requirements. In the second quarter of Fiscal 2015, we incurred $1.3 million of restructuring and separation costs.

[0001564590-16-017619:mdna:18]
[same as prior period, unchanged from 0001564590-16-012239:mdna:17]

[0001564590-16-017619:mdna:19]
We recorded an income tax provision of $0.7 million in the second quarter of Fiscal 2016, compared to an income tax provision of $6.4 million in the second quarter of Fiscal 2015.  The effective tax rate for the second quarter of Fiscal 2016 was 12% compared to an effective tax rate of 237% in the second quarter of Fiscal 2015.  The effective tax rate for Fiscal 2016 was favorably impacted by the mix of income from our Canadian operations and the utilization of net operating loss carryforwards  in Canada that have been fully reserved with a valuation allowance.  The effective tax rate for the second quarter of Fiscal 2015 was impacted by discrete items which included a valuation allowance recorded against our Canadian deferred tax assets in the amount of $9.0 million, partially offset by the release of a FIN 48 reserve related to the Federal Research and Development Tax Credit (R&D Credit) in the amount of $4.1 million upon closing an Internal Revenue Service (IRS) audit.

[0001564590-16-017619:mdna:20]
Net income (loss)

[0001564590-16-017619:mdna:21]
In the second quarter of Fiscal 2016, we recorded income of $5.6 million, or $0.49 per diluted share compared to a loss of $3.7 million, or $0.31 per diluted share, in the second quarter of Fiscal 2015.  This increase in income was primarily due to our improvement in gross profit in our international operations, primarily driven by improved project execution and reduced costs in our Canadian operations during the second quarter of Fiscal 2016, offset by the $3.3 million of separation costs.

[0001564590-16-017619:mdna:22]
[same as prior period, unchanged from 0001564590-16-012239:mdna:21]

[0001564590-16-017619:mdna:23]
The order backlog at March 31, 2016 was $357.4 million, which declined from $441.4 million at September 30, 2015.  New orders declined during the second quarter of Fiscal 2016 to $116.9 million, compared to $167.1 million in the second quarter of Fiscal 2015, primarily due to the continued decline in the oil and gas markets.

[0001564590-16-017619:mdna:24]
Six Months Ended March 31, 2016 Compared to the Six Months Ended March 31, 2015 (Unaudited)

[0001564590-16-017619:mdna:25]
Revenue and Gross Profit

[0001564590-16-017619:mdna:26]
Revenues decreased by 6%, or $20.6 million, to $302.2 million for the six months ended March 31, 2016, compared to the six months ended March 31, 2015.  Domestic revenues decreased by 2%, or $5.1 million, to $212.2 million for the six months ended March 31, 2016, compared to the six months ended March 31, 2015, and international revenues decreased by 15%, or $15.4 million, to $90.0 million for the six months ended March 31, 2016, compared to the six months ended March 31, 2015.  All revenues decreased in the six months ended March 31, 2016 primarily due to the continued decrease in our project backlog.  Revenues from commercial and industrial customers decreased $23.2 million to $228.1 million for the six months ended March 31, 2016, compared to the six months ended March 31, 2015. Revenues from public and private utilities increased $7.5 million to $55.2 million for the six months ended March 31, 2016, compared to the six months ended March 31, 2015. Revenues from municipal and transit projects decreased $4.9 million to $18.9 million for the six months ended March 31, 2016, compared to the six months ended March 31, 2015.

[0001564590-16-017619:mdna:27]
Gross profit for the six months ended March 31, 2016 increased by 17%, or $7.9 million, to $53.2 million, compared to the six months ended March 31, 2015.  Gross profit as a percentage of revenues was 18% for the six months ended March 31, 2016, compared to 14% for the six months ended March 31, 2015.  Our gross profit as a percentage of revenues improved in the six months ended March 31, 2016, compared to the six months ended March 31, 2015, due to improvements in our international operations primarily driven by improved project execution and reduced costs in our Canadian operations.

[0001564590-16-017619:mdna:28]
Selling, General and Administrative Expenses

[0001564590-16-017619:mdna:29]
Selling, general and administrative expenses decreased $1.9 million to $38.4 million for the six months ended March 31, 2016 compared to the $40.3 million that we recorded for the six months ended March 31, 2015. Selling, general and administrative expenses, as a percentage of revenues remained flat at approximately 13% for both six month periods ended March 31, 2016 and 2015.

[0001564590-16-017619:mdna:30]
Restructuring and separation costs

[0001564590-16-017619:mdna:31]
In the six months ended March 31, 2016, we incurred approximately $7.1 million in separation costs as we continued to restructure our senior management team and align our salaried and hourly workforce with future production requirements, as well as the departure of our former Chief Executive Officer in December 2015.  In the six months ended March 31, 2015, we incurred $1.3 million of restructuring and separation costs.

[0001564590-16-017619:mdna:32]
Other Income

[0001564590-16-017619:mdna:33]
We recorded other income of $1.0 million in the six months ended March 31, 2016 from the amortization of the deferred gain from the amended supply agreement, discussed in Note D of Notes to Condensed Consolidated Financial Statements.  For the six months ended March 31, 2015, we recorded the same $1.0 million from the amortization of the deferred gain as well as a $0.3 million death benefit received from our Company-owned life insurance policy.

[0001564590-16-017619:mdna:34]
Income Tax Provision

[0001564590-16-017619:mdna:35]
We recorded an income tax benefit of $0.3 million for the six months ended March 31, 2016, compared to an income tax provision of $5.4 million for the six months ended March 31, 2015.  The effective tax rate for the six months ended March 31, 2016 was a 7% benefit compared to an effective tax rate of 368% for the six months ended March 31, 2015.  The effective tax rate for Fiscal 2016 was favorably impacted by the mix of income from our Canadian operations and the utilization of net operating loss carryforwards in Canada that have been fully reserved with a valuation allowance.  Additionally, the effective tax rate for the six months ended March 31, 2016 was favorably impacted by a $0.8 million discrete item recorded in the first quarter of Fiscal 2016 related to the retroactive reinstatement of the R&D Tax Credit for the previously expired period from January 1, 2015 to September 30, 2015.  On December 18, 2015, the “Protecting Americans from Tax Hikes Act of 2015” was enacted which retroactively reinstated and made permanent the R&D Tax Credit.

[0001564590-16-017619:mdna:36]
In the first six months of Fiscal 2015, our effective tax rate increased due to a $9.0 million valuation allowance recorded against our Canadian deferred tax assets.  In the second quarter of Fiscal 2015, we recorded a valuation allowance against the Canadian net deferred tax assets. Due to the historical Canadian losses, and the projected losses in the near term, we were required under the more-likely-than-not accounting standard to record a valuation allowance against the Canadian net deferred tax assets because we anticipated that we may not be able to realize the benefits of the net operating loss carryforwards and other deductible differences.   This was partially offset by the release of a $4.1 million FIN 48 reserve related to the R&D Tax Credit upon closing an IRS audit. We recorded a $0.6 million discrete item for the six months ended March 31, 2015 also related to the retroactive reinstatement of the R&D Tax Credit referred to above.

[0001564590-16-017619:mdna:37]
Net income (loss)

[0001564590-16-017619:mdna:38]
For the six months ended March 31, 2016, we recorded income of $5.1 million, or $0.45 per share, compared to a loss of $3.9 million, or $0.33 per diluted share, for the six months ended March 31, 2015. This increase in net income was primarily due to our improvement in gross profit in our international operations, driven by improved project execution in our Canadian operations in the first half of Fiscal 2016, offset by the $5.7 million increase in restructuring and separation costs.  Additionally, net income has increased due to lower income tax expense in Fiscal 2016, due to the utilization of net operating losses to offset Canadian income.

[0001564590-16-017619:mdna:39]
Backlog

[0001564590-16-017619:mdna:40]
The order backlog at March 31, 2016 was $357.4 million, which declined from $441.4 million at September 30, 2015.  New orders placed during the six months ended March 31, 2016 totaled $218.6 million compared to $321.5 million for the six months ended March 31, 2015.  The year over year decrease in new orders was primarily due the continued decline in the oil and gas markets.

[0001564590-16-017619:mdna:41]
[same as prior period, unchanged from 0001564590-16-012239:mdna:23]

[0001564590-16-017619:mdna:42]
Cash and cash equivalents increased to $57.4 million at March 31, 2016, compared to $43.6 million at September 30, 2015.  As of March 31, 2016, current assets exceeded current liabilities by 2.5 times and our debt to total capitalization was 0.72%.

[0001564590-16-017619:mdna:43]
We have a $75.0 million revolving credit facility in the U.S., which expires in December 2018. As of March 31, 2016, there were no amounts borrowed under this line of credit. We also have a $7.7 million revolving credit facility in Canada. At March 31, 2016, there was no balance outstanding under the Canadian revolving credit facility. Total long-term debt, including current maturities, totaled $2.4 million at March 31, 2016, compared to $2.8 million at September 30, 2015. Total letters of credit outstanding were $24.7 million at March 31, 2016 and $21.1 million at September 30, 2015, which reduced our availability under our U.S. credit facility. Amounts available at March 31, 2016 under the U.S. and Canadian revolving credit facilities were $50.3 million and $7.7 million, respectively.  For further information regarding our debt, see Notes E and F of Notes to Condensed Consolidated Financial Statements.

[0001564590-16-017619:mdna:44]
Approximately $27 million of our cash at March 31, 2016, was held outside of the United States for international operations. It is our intention to indefinitely reinvest all current and future foreign earnings internationally in order to ensure sufficient working capital to support and expand these international operations.  In the event that we elect to repatriate some or all of the foreign earnings that were previously deemed to be indefinitely reinvested outside the U.S., under current tax laws we would incur additional tax expense upon such repatriation.

[0001564590-16-017619:mdna:45]
[same as prior period, unchanged from 0001564590-16-012239:mdna:27]

[0001564590-16-017619:mdna:46]
[same as prior period, unchanged from 0001564590-16-012239:mdna:28]

[0001564590-16-017619:mdna:47]
Cash provided by operating activities increased to $25.2 million for the six months ended March 31, 2016, compared to cash used in operating activities of $4.1 million during the same period in Fiscal 2015.  This increase was primarily due to favorable improvements in accounts receivable, continued focus on inventory reduction and timing of cash payments on accrued liabilities in the six months ended March 31, 2016, compared to the same period in the prior year.  Cash flow from operations is primarily influenced by the timing of milestone payments from our customers and the payment terms with our suppliers.

[0001564590-16-017619:mdna:48]
[same as prior period, unchanged from 0001564590-16-012239:mdna:30]

[0001564590-16-017619:mdna:49]
Purchases of property, plant and equipment during six months ended March 31, 2016 totaled $1.1 million compared to $28.7 million during the same period in Fiscal 2015.  This decrease in Fiscal 2016 was due to the completion of the expansion of our Canadian facilities in Fiscal 2015.

[0001564590-16-017619:mdna:50]
[same as prior period, unchanged from 0001564590-16-012239:mdna:32]

[0001564590-16-017619:mdna:51]
Net cash used in financing activities was $10.9 million for the six months ended March 31, 2016 and $13.0 million during the same period in Fiscal 2015.  This reduction was primarily due to the completion of our share repurchase program in December 2015 discussed below.

[0001564590-16-017619:mdna:52]
[same as prior period, unchanged from 0001564590-16-012239:mdna:34]

[0001564590-16-017619:mdna:53]
On December 17, 2014, our Board of Directors authorized a share repurchase program which allowed us to repurchase up to $25 million of our outstanding stock.  The purchases were made from time to time in the open market, through privately negotiated transactions and Rule 10b5-1 trading plans in accordance with applicable laws, rules and regulations.  The Repurchase Program was funded from cash on hand and cash provided by operating activities.  The Repurchase Program expired on December 31, 2015.  As of December 31, 2015, we had purchased 806,018 shares at an aggregate cost of $25 million under the Repurchase Program. The average purchase price per share since inception of the program was $31.02.

[0001564590-16-017619:mdna:54]
[same as prior period, unchanged from 0001564590-16-012239:mdna:36]

[0001564590-16-017619:mdna:55]
[same as prior period, unchanged from 0001564590-16-012239:mdna:37]

[0001564590-16-017619:mdna:56]
[same as prior period, unchanged from 0001564590-16-012239:mdna:38]

[0001564590-16-017619:mdna:57]
[same as prior period, unchanged from 0001564590-16-012239:mdna:39]

[0001564590-16-017619:mdna:58]
[same as prior period, unchanged from 0001564590-16-012239:mdna:40]

[0001564590-16-017619:mdna:59]
[same as prior period, unchanged from 0001564590-16-012239:mdna:41]

[0001564590-16-017619:mdna:60]
The markets in which we participate are capital-intensive and cyclical in nature. Cyclicality is predominantly driven by customer demand, global economic conditions and anticipated environmental or regulatory changes which affect the manner in which our customers proceed with capital investments. Our customers analyze various factors including the demand and price for oil, gas and electrical energy, the overall economic and financial environment, governmental budgets, regulatory actions and environmental concerns. These factors influence the release of new capital projects by our customers, which are traditionally awarded in competitive bid situations. Scheduling of projects is matched to the customer requirements and projects typically take a number of months to produce, but schedules may change during the course of any particular project.

[0001564590-16-017619:mdna:61]
A significant portion of our revenues have historically been from the oil and gas markets.  Unfavorable long-term commodity price levels can cause oil and gas companies to change their strategies or delay or cancel projects.  Due to the precipitous decline in oil and gas prices since late 2014, many of our customers have reduced their capital budgets and cut costs, and in certain instances have deferred or cancelled projects that we were pursuing.  We believe that sustained lower oil and gas prices from a continued global supply/demand imbalance will continue to negatively impact future orders due to reduced capital spending by our customers.  The reduction in available projects, across the markets we serve, has increased market price pressures during this downward cycle. This reduction in new business opportunities and increased market price pressures will negatively impact our revenues, backlog, operating results and cash flows from operations.  If commodity prices do not continue to improve from current levels, or they decline, the number of projects in our markets could further decline.

[0001564590-16-017619:mdna:62]
Our operating results have been, and may continue to be, negatively impacted by factors such as the timing of new order awards, customer approval of final engineering and design specifications and delays in customer construction schedules, all of which have and may continue to have, a negative impact on the timing of project execution.  These factors have resulted, and may continue to result in, periods when our factory resources are not in balance with our customers’ scheduling requirements, resulting in higher production costs due to inefficiencies.  Our operating results also have been, and may continue to be, impacted by the timing and resolution of change orders, project close-out and resolution of potential contract claims, all of which could improve or deteriorate gross margins during the period in which these items are resolved with our customers.

[0001564590-16-017619:mdna:63]
[same as prior period, unchanged from 0001564590-16-012239:mdna:47]
