# POWL note change history — 0001564590-16-012239 → 0001564590-16-017619


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2016-05-04):
[0001564590-16-017619:note_history:1]
Letters of Credit and Surety Bonds
  (was, 2016-02-03, similarity 0.8852):
[0001564590-16-012239:note_history:1]
Letters of Credit and Bonds

- changed (2016-05-04):
[0001564590-16-017619:note_history:2]
Certain customers require us to post bank letter of credit guarantees or surety bonds. These guarantees and surety bonds assure that we will perform under the terms of our contract. In the event of default, the counterparty may demand payment from the bank under a letter of credit or performance by the surety under a bond. To date, there have been no significant expenses related to either letters of credit or surety bonds for the periods reported. We were contingently liable for secured and unsecured letters of credit of $24.7 million as of March 31, 2016. We also had surety bonds totaling $298.9 million that were outstanding, with additional bonding capacity of $451.1 million available, at March 31, 2016.
  (was, 2016-02-03, similarity 0.895):
[0001564590-16-012239:note_history:2]
Certain customers require us to post bank letter of credit guarantees or performance bonds issued by a surety. These guarantees and performance bonds assure that we will perform under the terms of our contract. In the event of default, the counterparty may demand payment from the bank under a letter of credit or performance by the surety under a performance bond. To date, there have been no significant expenses related to either letters of credit or performance bonds for the periods reported. We were contingently liable for secured and unsecured letters of credit of $21.6 million as of December 31, 2015. We also had performance and maintenance bonds totaling $307.5 million that were outstanding, with additional bonding capacity of $442.5 million available, at December 31, 2015.

- changed (2016-05-04):
[0001564590-16-017619:note_history:3]
We have a $14.4 million facility agreement (Facility Agreement) between Powell (UK) Limited and a large international bank. This Facility Agreement provides Powell (UK) the ability to enter into bank guarantees as well as forward exchange contracts and currency options. At March 31, 2016, we had outstanding guarantees totaling $2.8 million under this Facility Agreement and amounts available under this Facility Agreement were $11.6 million.  This facility is renewable in May 2016.
  (was, 2016-02-03, similarity 0.9861):
[0001564590-16-012239:note_history:3]
We have a $14.8 million facility agreement (Facility Agreement) between Powell (UK) Limited and a large international bank. This Facility Agreement provides Powell (UK) the ability to enter into bank guarantees as well as forward exchange contracts and currency options. At December 31, 2015, we had outstanding guarantees totaling $3.0 million under this Facility Agreement and amounts available under this Facility Agreement were $11.8 million.  This facility is renewable in May 2016.

- changed (2016-05-04):
[0001564590-16-017619:note_history:4]
The Facility Agreement provides for financial covenants and customary events of default, and carries cross-default provisions with our Amended Credit Facility. If an event of default (as defined in the Facility Agreement) occurs and is continuing, per the terms and subject to the conditions set forth therein, obligations outstanding under the Facility Agreement may be accelerated and may become or be declared immediately due and payable. As of March 31, 2016, we were in compliance with all of the financial covenants of the Facility Agreement.
  (was, 2016-02-03, similarity 0.988):
[0001564590-16-012239:note_history:4]
The Facility Agreement provides for financial covenants and customary events of default, and carries cross-default provisions with our Amended Credit Facility. If an event of default (as defined in the Facility Agreement) occurs and is continuing, per the terms and subject to the conditions set forth therein, obligations outstanding under the Facility Agreement may be accelerated and may become or be declared immediately due and payable. As of December 31, 2015, we were in compliance with all of the financial covenants of the Facility Agreement.

- changed (2016-05-04):
[0001564590-16-017619:note_history:5]
Certain of our customer contracts have schedule and performance obligation clauses that, if we fail to meet them, could require us to pay liquidated damages.  Each individual contract defines the conditions under which the customer may make a claim against us.  As of March 31, 2016, our exposure to possible liquidated damages was $8.9 million, of which approximately $2.0 million is estimated to be probable.  Based on our actual or projected failure to meet these various contractual commitments, $1.6 million has been recorded as a reduction to revenue.  We believe that we will be successful in obtaining change orders or contract extensions that should resolve the potential for any unaccrued liquidated damages; however, should we fail to achieve relief on some or all of these contractual obligations, we could be required to pay additional liquidated damages which could negatively impact our future operating results.
  (was, 2016-02-03, similarity 0.7032):
[0001564590-16-012239:note_history:5]
Certain of our customer contracts have schedule and performance obligation clauses that, if we fail to meet them, could subject us to liquidated damages.  Each individual contract defines the conditions under which the customer may make a claim against us.  As of December 31, 2015, our exposure to possible liquidated damages is $7.5 million, of which approximately $2.2 million is probable.  Based on our actual or projected failure to meet these various contractual commitments, $1.7 million has been recorded against revenue in our statement of operations.  We believe that we will be successful in obtaining change orders or contract extensions that should resolve the potential for any unaccrued liquidated damages; however, should we fail to achieve relief on some or all of these contractual obligations, we could be subject to additional liquidated damages which could impact our future operating results.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureAndSignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2016-05-04):
[0001564590-16-017619:note_history:6]
In July 2015, the FASB issued a new topic on simplifying the measurement of inventory.  The current standard is to measure inventory at lower of cost or market; where market could be replacement cost, net realizable value, or net realizable value less an approximate normal profit margin. This topic updates this guidance to measure inventory at the lower of cost and net realizable value; where net realizable value is the estimated selling prices in the ordinary course of business, less reasonably predictable costs of completion, disposal, and transportation. This update is effective for annual reporting periods beginning after December 15, 2016, which would be our fiscal year ending September 30, 2018.  The amendments should be applied prospectively with earlier application permitted as of the beginning of an interim or annual reporting period. This topic is not expected to have a material impact on our consolidated financial position or results of operations.
  (was, 2016-02-03, similarity 0.999):
[0001564590-16-012239:note_history:6]
In July 2015, the FASB issued a new topic on simplifying the measurement of inventory.  The current standard is to measure inventory at lower of cost or market; where market could be replacement cost, net realizable value, or net realizable value less an approximately normal profit margin. This topic updates this guidance to measure inventory at the lower of cost and net realizable value; where net realizable value is the estimated selling prices in the ordinary course of business, less reasonably predictable costs of completion, disposal, and transportation. This update is effective for annual reporting periods beginning after December 15, 2016, which would be our fiscal year ending September 30, 2018.  The amendments should be applied prospectively with earlier application permitted as of the beginning of an interim or annual reporting period. This topic is not expected to have a material impact on our consolidated financial position or results of operations.

- changed (2016-05-04):
[0001564590-16-017619:note_history:7]
In November 2015, the FASB issued an amendment to the topic regarding income taxes which requires an entity to separate deferred income tax liabilities and assets into current and noncurrent amounts in the statement of financial position.  Deferred tax liabilities and assets are classified as current or noncurrent based on the classification of the related asset or liability for financial reporting.  Deferred tax liabilities and assets that are not related to an asset or liability for financial reporting are classified according to the expected reversal date of the temporary difference.  To simplify the presentation of deferred income taxes, the amendments require that deferred income tax liabilities and assets be classified as noncurrent in a classified statement of financial position.  This amendment is effective for annual reporting periods beginning after December 15, 2016, which would be our fiscal year ending September 30, 2018.  We have no plans for early adoption.  The adoption of this guidance is not expected to have a material impact on our consolidated financial position or results of operations.
  (was, 2016-02-03, similarity 0.7803):
[0001564590-16-012239:note_history:7]
In November 2015, the FASB issued an amendment to the topic regarding income taxes which requires an entity to separate deferred income tax liabilities and assets into current and noncurrent amounts in the statement of financial position.  Deferred tax liabilities and assets are classified as current or noncurrent based on the classification of the related asset or liability for financial reporting.  Deferred tax liabilities and assets that are not related to an asset or liability for financial reporting are classified according to the expected reversal date of the temporary difference.  To simplify the presentation of deferred income taxes, the amendments require that deferred income tax liabilities and assets be classified as noncurrent in a classified statement of financial position.  This amendment is effective for us beginning with fiscal year 2018 and we have no plans for early adoption.  The adoption of t his guidance is not expected to have a material impact on our consolidated financial position or results of operations.

- added (2016-05-04):
[0001564590-16-017619:note_history:8]
In February 2016, the FASB issued a new topic on leases which requires lessees to recognize lease assets and lease liabilities on the balance sheet for all leases with terms longer than twelve months.  Leases will be classified as either finance or operating, with classification affecting the pattern of expense recognition in the income statement.  A modified retrospective transition approach is required for lessees for capital and operating leases existing at, or entered into after, the beginning of the earliest comparative period presented in the financial statements, with certain practical expedients available. The new standard is effective for fiscal years beginning after December 15, 2018, including interim periods within those fiscal years. This would be our fiscal year ending September 30, 2020.  We are currently evaluating the impact of our pending adoption of the new standard on our consolidated financial statements.

- added (2016-05-04):
[0001564590-16-017619:note_history:9]
In March 2016, the FASB issued new guidance on stock-based compensation. The new guidance simplifies several aspects of the accounting for share-based payment transactions, including the income tax consequences, classification of awards as either equity or liabilities, and classification on the statement of cash flows. For public companies, the amendments in this standard are effective for annual periods beginning after December 15, 2016, including interim periods within those annual periods.  This would be our fiscal year ending September 30, 2018.  We have no plans for early adoption. The adoption of this guidance is not expected to have a material impact on our consolidated financial statements.

- removed (2016-05-04):
[0001564590-16-012239:note_history:10]
In June 2014, the FASB issued an amendment to the topic regarding share-based payments and instances where terms of an award provide that a performance target can be achieved after the requisite service period.  This guidance has been provided to resolve the diversity in practice concerning employee share-based payments that contain performance targets that could be achieved after the requisite service period. The updated guidance requires that a performance target that affects vesting and that can be achieved after the requisite service period be treated as a performance condition. Compensation cost should be recognized in the period in which it becomes probable that the performance target will be achieved and is attributable to the periods for which service has been rendered. If the performance target becomes probable of being achieved before the end of the service period, the remaining unrecognized compensation cost for which requisite service has not yet been rendered is recognized prospectively over the remaining service period. The total amount of compensation cost recognized during and after the service period should reflect the number of awards that are expected to vest and should be adjusted to reflect those awards that ultimately vest. The updated guidance is effective for annual and interim periods beginning after December 15, 2015, with early adoption permitted. The adoption of this guidance is not expected to have a material impact on our consolidated financial position or results of operations.


## us-gaap:LongTermDebtTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2016-05-04):
[0001564590-16-017619:note_history:11]
|  | March 31, 2016 |  |  | September 30, 2015 |  |
| Industrial development revenue bonds | $ | 2,400 |  |  | $ | 2,800 |  |
| Less current portion |  | (400 | ) |  |  | (400 | ) |
| Total long-term debt and capital lease obligations | $ | 2,000 |  |  | $ | 2,400 |  |
  (was, 2016-02-03, similarity 0.7655):
[0001564590-16-012239:note_history:11]
|  | December 31, 2015 |  |  | September 30, 2015 |  |
| Industrial development revenue bonds......................................... | $ | 2,400 |  |  | $ | 2,800 |  |
| Less current portion..................................................... |  | (400 | ) |  |  | (400 | ) |
| Total long-term debt and capital lease obligations............................... | $ | 2,000 |  |  | $ | 2,400 |  |

- changed (2016-05-04):
[0001564590-16-017619:note_history:12]
The U.S. Revolver provides for the issuance of letters of credit which reduce the amounts that may be borrowed under this revolver. The amount available under the U.S. Revolver was reduced by $24.7 million for our outstanding letters of credit at March 31, 2016.
  (was, 2016-02-03, similarity 0.9745):
[0001564590-16-012239:note_history:12]
The U.S. Revolver provides for the issuance of letters of credit which reduce the amounts that may be borrowed under this revolver. The amount available under the U.S. Revolver was reduced by $21.6 million for our outstanding letters of credit at December 31, 2015.

- changed (2016-05-04):
[0001564590-16-017619:note_history:13]
There were no borrowings outstanding under the U.S. Revolver as of March 31, 2016.  Amounts available under the U.S. Revolver were $50.3 million at March 31, 2016. The U.S. Revolver expires on December 31, 2018.
  (was, 2016-02-03, similarity 0.9531):
[0001564590-16-012239:note_history:13]
There were no borrowings outstanding under the U.S. Revolver as of December 31, 2015.  Amounts available under the U.S. Revolver were $53.4 million at December 31, 2015. The U.S. Revolver expires on December 31, 2018.

- changed (2016-05-04):
[0001564590-16-017619:note_history:14]
The Amended Credit Agreement is collateralized by a pledge of 100% of the voting capital stock of each of our domestic subsidiaries and 65% of the voting capital stock of each non-domestic subsidiary, excluding Powell Canada. The Amended Credit Agreement provides for customary events of default and carries cross-default provisions with other existing debt agreements. If an event of default (as defined in the Amended Credit Agreement) occurs and is continuing, on the terms and subject to the conditions set forth in the Amended Credit Agreement, amounts outstanding under the Amended Credit Agreement may be accelerated and may become immediately due and payable. As of March 31, 2016, we were in compliance with all of the financial covenants of the Amended Credit Agreement.
  (was, 2016-02-03, similarity 0.9916):
[0001564590-16-012239:note_history:14]
The Amended Credit Agreement is collateralized by a pledge of 100% of the voting capital stock of each of our domestic subsidiaries and 65% of the voting capital stock of each non-domestic subsidiary, excluding Powell Canada. The Amended Credit Agreement provides for customary events of default and carries cross-default provisions with other existing debt agreements. If an event of default (as defined in the Amended Credit Agreement) occurs and is continuing, on the terms and subject to the conditions set forth in the Amended Credit Agreement, amounts outstanding under the Amended Credit Agreement may be accelerated and may become immediately due and payable. As of December 31, 2015, we were in compliance with all of the financial covenants of the Amended Credit Agreement.

- changed (2016-05-04):
[0001564590-16-017619:note_history:15]
We have a $7.7 million credit agreement with a major international bank in Canada (the Canadian Revolver) to provide working capital support and letters of credit for our operations in Canada. The Canadian Revolver provides for the issuance of letters of credit which reduce the amounts that may be borrowed under this revolver.  There were no outstanding letters of credit under the Canadian Revolver at March 31, 2016.
  (was, 2016-02-03, similarity 0.9842):
[0001564590-16-012239:note_history:15]
We have a $7.2 million credit agreement with a major international bank in Canada (the Canadian Revolver) to provide working capital support and letters of credit for our operations in Canada. The Canadian Revolver provides for the issuance of letters of credit which reduce the amounts that may be borrowed under this revolver.  There were no outstanding letters of credit under the Canadian Revolver at December 31, 2015.

- changed (2016-05-04):
[0001564590-16-017619:note_history:16]
There were no borrowings outstanding under the Canadian Revolver as of March 31, 2016 and amounts available under the Canadian Revolver were $7.7 million at March 31, 2016.  The interest rate for amounts outstanding under the Canadian Revolver is a floating interest rate based upon either the Canadian Prime Rate, or the lender’s Bankers’ Acceptance Rate. Once the applicable rate is determined, a margin of 0.50% to 1.75%, as determined by our consolidated leverage ratio, is added to the applicable rate. The Canadian Revolver expires on March 31, 2018.
  (was, 2016-02-03, similarity 0.9756):
[0001564590-16-012239:note_history:16]
There were no borrowings outstanding under the Canadian Revolver as of December 31, 2015 and amounts available under the Canadian Revolver were $7.2 million at December 31, 2015.  The interest rate for amounts outstanding under the Canadian Revolver is a floating interest rate based upon either the Canadian Prime Rate, or the lender’s Bankers’ Acceptance Rate. Once the applicable rate is determined, a margin of 0.50% to 1.75%, as determined by our consolidated leverage ratio, is added to the applicable rate. The Canadian Revolver expires on March 31, 2018.

- changed (2016-05-04):
[0001564590-16-017619:note_history:17]
The Canadian Revolver is secured by the assets of our Canadian operations and provides for customary events of default and carries cross-default provisions with our existing debt agreements. If an event of default (as defined in the Canadian Revolver) occurs and is continuing, per the terms and subject to the conditions set forth in the Canadian Revolver, amounts outstanding under the Canadian Revolver may be accelerated and may become immediately due and payable. As of March 31, 2016, we were in compliance with all of the financial covenants of the Canadian Revolver.
  (was, 2016-02-03, similarity 0.9886):
[0001564590-16-012239:note_history:17]
The Canadian Revolver is secured by the assets of our Canadian operations and provides for customary events of default and carries cross-default provisions with our existing debt agreements. If an event of default (as defined in the Canadian Revolver) occurs and is continuing, per the terms and subject to the conditions set forth in the Canadian Revolver, amounts outstanding under the Canadian Revolver may be accelerated and may become immediately due and payable. As of December 31, 2015, we were in compliance with all of the financial covenants of the Canadian Revolver.

- changed (2016-05-04):
[0001564590-16-017619:note_history:18]
We borrowed $8.0 million in October 2001 through a loan agreement funded with proceeds from tax-exempt industrial development revenue bonds (Bonds). These Bonds were issued by the Illinois Development Finance Authority and were used for the completion of our Northlake, Illinois facility. Pursuant to the Bond issuance, a reimbursement agreement between us and a major domestic bank required an issuance by the bank of an irrevocable direct-pay letter of credit (Bond LC), as collateral, to the Bonds’ trustee to guarantee payment of the Bonds’ principal and interest when due. The Bond LC is subject to both early termination and extension provisions customary to such agreements, as well as various covenants, for which we were in compliance at March 31, 2016. While the Bonds mature in 2021, the reimbursement agreement requires annual redemptions of $0.4 million that commenced on October 25, 2002. A sinking fund is used for the redemption of the Bonds. The Bonds bear interest at a floating rate determined weekly by the Bonds’ remarketing agent, which was the underwriter for the Bonds and is an affiliate of the bank. This interest rate was 0.57% as of March 31, 2016.
  (was, 2016-02-03, similarity 0.9887):
[0001564590-16-012239:note_history:18]
We borrowed $8.0 million in October 2001 through a loan agreement funded with proceeds from tax-exempt industrial development revenue bonds (Bonds). These Bonds were issued by the Illinois Development Finance Authority and were used for the completion of our Northlake, Illinois facility. Pursuant to the Bond issuance, a reimbursement agreement between us and a major domestic bank required an issuance by the bank of an irrevocable direct-pay letter of credit (Bond LC), as collateral, to the Bonds’ trustee to guarantee payment of the Bonds’ principal and interest when due. The Bond LC is subject to both early termination and extension provisions customary to such agreements, as well as various covenants, for which we were in compliance at December 31, 2015. While the Bonds mature in 2021, the reimbursement agreement requires annual redemptions of $0.4 million that commenced on October 25, 2002. A sinking fund is used for the redemption of the Bonds. The Bonds bear interest at a floating rate determined weekly by the Bonds’ remarketing agent, which was the underwriter for the Bonds and is an affiliate of the bank. This interest rate was 0.15% as of December 31, 2015.


## us-gaap:ScheduleOfDebtInstrumentsTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2016-05-04):
[0001564590-16-017619:note_history:19]
|  | March 31, 2016 |  |  | September 30, 2015 |  |
| Industrial development revenue bonds | $ | 2,400 |  |  | $ | 2,800 |  |
| Less current portion |  | (400 | ) |  |  | (400 | ) |
| Total long-term debt and capital lease obligations | $ | 2,000 |  |  | $ | 2,400 |  |
  (was, 2016-02-03, similarity 0.7655):
[0001564590-16-012239:note_history:19]
|  | December 31, 2015 |  |  | September 30, 2015 |  |
| Industrial development revenue bonds......................................... | $ | 2,400 |  |  | $ | 2,800 |  |
| Less current portion..................................................... |  | (400 | ) |  |  | (400 | ) |
| Total long-term debt and capital lease obligations............................... | $ | 2,000 |  |  | $ | 2,400 |  |
