# POWL notes — 0001564590-16-017619


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureAndSignificantAccountingPoliciesTextBlock

[0001564590-16-017619:notes:1]
[same as prior period, unchanged from 0001564590-16-012239:notes:1]

[0001564590-16-017619:notes:2]
[same as prior period, unchanged from 0001564590-16-012239:notes:2]

[0001564590-16-017619:notes:3]
[same as prior period, unchanged from 0001564590-16-012239:notes:3]

[0001564590-16-017619:notes:4]
[same as prior period, unchanged from 0001564590-16-012239:notes:4]

[0001564590-16-017619:notes:5]
[same as prior period, unchanged from 0001564590-16-012239:notes:5]

[0001564590-16-017619:notes:6]
These unaudited condensed consolidated financial statements include the accounts of Powell and its wholly-owned subsidiaries.  All significant intercompany accounts and transactions have been eliminated in consolidation.

[0001564590-16-017619:notes:7]
These unaudited condensed consolidated financial statements have been prepared in accordance with the instructions to Form 10-Q and Rule 10-01 of Regulation S-X for interim financial information.  Certain information and footnote disclosures, normally included in annual financial statements prepared in accordance with accounting principles generally accepted in the United States (U.S. GAAP), have been condensed or omitted pursuant to those rules and regulations. In the opinion of management, all adjustments, consisting only of normal recurring adjustments, necessary to fairly state the financial position, results of operations and cash flows with respect to the interim consolidated financial statements have been included. The results of operations for the interim periods are not necessarily indicative of the results for the entire fiscal year.  We believe that these financial statements contain all adjustments necessary so that they are not misleading. The year-end balance sheet data was derived from audited financial statements, but does not include all disclosures required by U.S. GAAP.

[0001564590-16-017619:notes:8]
[same as prior period, unchanged from 0001564590-16-012239:notes:8]

[0001564590-16-017619:notes:9]
[same as prior period, unchanged from 0001564590-16-012239:notes:9]

[0001564590-16-017619:notes:10]
[same as prior period, unchanged from 0001564590-16-012239:notes:10]

[0001564590-16-017619:notes:11]
The preparation of financial statements in conformity with U.S. GAAP requires management to make estimates and assumptions that affect the amounts reported in the consolidated financial statements and accompanying footnotes. The most significant estimates used in our financial statements affect revenue and cost recognition for construction contracts, the allowance for doubtful accounts, provision for excess and obsolete inventory, goodwill and intangible assets, self-insurance, warranty accruals, liquidated damages and income taxes. The amounts recorded for insurance claims, warranties, legal, liquidated damages, income taxes and other contingent liabilities require judgments regarding the amount of expenses that will ultimately be incurred. We base our estimates on historical experience and on various other assumptions, as well as the specific circumstances surrounding these contingent liabilities, in evaluating the amount of liability that should be recorded. Additionally, the recognition of deferred tax assets requires estimates related to future income and other assumptions regarding timing and future profitability.  Estimates may change as new events occur, additional information becomes available or operating environments change. Actual results may differ from our estimates.

[0001564590-16-017619:notes:12]
[same as prior period, unchanged from 0001564590-16-012239:notes:12]

[0001564590-16-017619:notes:13]
In May 2014, the FASB issued a new standard on revenue recognition that supersedes previously issued revenue recognition guidance.  This standard provides a five-step approach to be applied to all contracts with customers and requires expanded disclosures about the nature, amount, timing and uncertainty of revenue (and the related cash flows) arising from customer contracts, significant judgments and changes in judgments used in applying the revenue model and the assets recognized from costs incurred to obtain or fulfill a contract.  This guidance is now effective for fiscal years, and interim periods within those years, beginning after December 15, 2017, which would be our fiscal year ending September 30, 2019.  The standard permits the use of either the retrospective or cumulative effect transition method therefore we are evaluating the effect that this new guidance will have on our consolidated financial statements and related disclosures. We have not yet selected a transition method nor have we determined the effect of the standard on our ongoing financial reporting.

[0001564590-16-017619:notes:14]
In July 2015, the FASB issued a new topic on simplifying the measurement of inventory.  The current standard is to measure inventory at lower of cost or market; where market could be replacement cost, net realizable value, or net realizable value less an approximate normal profit margin. This topic updates this guidance to measure inventory at the lower of cost and net realizable value; where net realizable value is the estimated selling prices in the ordinary course of business, less reasonably predictable costs of completion, disposal, and transportation. This update is effective for annual reporting periods beginning after December 15, 2016, which would be our fiscal year ending September 30, 2018.  The amendments should be applied prospectively with earlier application permitted as of the beginning of an interim or annual reporting period. This topic is not expected to have a material impact on our consolidated financial position or results of operations.

[0001564590-16-017619:notes:15]
In November 2015, the FASB issued an amendment to the topic regarding income taxes which requires an entity to separate deferred income tax liabilities and assets into current and noncurrent amounts in the statement of financial position.  Deferred tax liabilities and assets are classified as current or noncurrent based on the classification of the related asset or liability for financial reporting.  Deferred tax liabilities and assets that are not related to an asset or liability for financial reporting are classified according to the expected reversal date of the temporary difference.  To simplify the presentation of deferred income taxes, the amendments require that deferred income tax liabilities and assets be classified as noncurrent in a classified statement of financial position.  This amendment is effective for annual reporting periods beginning after December 15, 2016, which would be our fiscal year ending September 30, 2018.  We have no plans for early adoption.  The adoption of this guidance is not expected to have a material impact on our consolidated financial position or results of operations.

[0001564590-16-017619:notes:16]
In February 2016, the FASB issued a new topic on leases which requires lessees to recognize lease assets and lease liabilities on the balance sheet for all leases with terms longer than twelve months.  Leases will be classified as either finance or operating, with classification affecting the pattern of expense recognition in the income statement.  A modified retrospective transition approach is required for lessees for capital and operating leases existing at, or entered into after, the beginning of the earliest comparative period presented in the financial statements, with certain practical expedients available. The new standard is effective for fiscal years beginning after December 15, 2018, including interim periods within those fiscal years. This would be our fiscal year ending September 30, 2020.  We are currently evaluating the impact of our pending adoption of the new standard on our consolidated financial statements.

[0001564590-16-017619:notes:17]
In March 2016, the FASB issued new guidance on stock-based compensation. The new guidance simplifies several aspects of the accounting for share-based payment transactions, including the income tax consequences, classification of awards as either equity or liabilities, and classification on the statement of cash flows. For public companies, the amendments in this standard are effective for annual periods beginning after December 15, 2016, including interim periods within those annual periods.  This would be our fiscal year ending September 30, 2018.  We have no plans for early adoption. The adoption of this guidance is not expected to have a material impact on our consolidated financial statements.


## us-gaap:EarningsPerShareTextBlock

[0001564590-16-017619:notes:18]
[same as prior period, unchanged from 0001564590-16-012239:notes:17]

[0001564590-16-017619:notes:19]
We compute basic earnings per share by dividing net income by the weighted average number of common shares outstanding during the period. Diluted earnings per common and potential common share includes the weighted average of additional shares associated with the incremental effect of dilutive restricted stock and restricted stock units, as prescribed by the FASB guidance on earnings per share.

[0001564590-16-017619:notes:20]
[same as prior period, unchanged from 0001564590-16-012239:notes:19]

[0001564590-16-017619:notes:21]
|  | Three months ended March 31, |  |  | Six months ended March 31, |  |
|  | 2016 |  |  | 2015 |  |  | 2016 |  |  | 2015 |  |
| Numerator: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Net income (loss) | $ | 5,567 |  |  | $ | (3,683 | ) |  | $ | 5,108 |  |  | $ | (3,922 | ) |
| Denominator: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Weighted average basic shares |  | 11,369 |  |  |  | 12,018 |  |  |  | 11,382 |  |  |  | 12,029 |  |
| Dilutive effect of restricted stock units |  | 53 |  |  |  | — |  |  |  | 33 |  |  |  | - |  |
| Weighted average diluted shares with assumed conversions |  | 11,422 |  |  |  | 12,018 |  |  |  | 11,415 |  |  |  | 12,029 |  |
| Net income (loss) per share: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic | $ | 0.49 |  |  | $ | (0.31 | ) |  | $ | 0.45 |  |  | $ | (0.33 | ) |
| Diluted | $ | 0.49 |  |  | $ | (0.31 | ) |  | $ | 0.45 |  |  | $ | (0.33 | ) |

[0001564590-16-017619:notes:22]
For the quarter and six months ended March 31, 2015, we incurred net losses and therefore all potential common shares were deemed to be anti-dilutive.


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0001564590-16-017619:notes:23]
[same as prior period, unchanged from 0001564590-16-012239:notes:22]

[0001564590-16-017619:notes:24]
[same as prior period, unchanged from 0001564590-16-012239:notes:23]

[0001564590-16-017619:notes:25]
[same as prior period, unchanged from 0001564590-16-012239:notes:24]

[0001564590-16-017619:notes:26]
|  | Three months ended March 31, |  |  | Six months ended March 31, |  |
|  | 2016 |  |  | 2015 |  |  | 2016 |  |  | 2015 |  |
| Balance at beginning of period | $ | 1,010 |  |  | $ | 1,844 |  |  | $ | 746 |  |  | $ | 1,577 |  |
| Bad debt expense |  | 92 |  |  |  | 186 |  |  |  | 339 |  |  |  | 469 |  |
| Uncollectible accounts written off, net of recoveries |  | (141 | ) |  |  | (120 | ) |  |  | (114 | ) |  |  | (122 | ) |
| Change in foreign currency translation |  | 15 |  |  |  | (29 | ) |  |  | 5 |  |  |  | (43 | ) |
| Balance at end of period | $ | 976 |  |  | $ | 1,881 |  |  | $ | 976 |  |  | $ | 1,881 |  |

[0001564590-16-017619:notes:27]
[same as prior period, unchanged from 0001564590-16-012239:notes:26]

[0001564590-16-017619:notes:28]
[same as prior period, unchanged from 0001564590-16-012239:notes:27]

[0001564590-16-017619:notes:29]
|  | March 31, 2016 |  |  | September 30, 2015 |  |
| Raw materials, parts and subassemblies, net | $ | 29,414 |  |  | $ | 31,807 |  |
| Work-in-progress |  | 813 |  |  |  | 1,084 |  |
| Total inventories | $ | 30,227 |  |  | $ | 32,891 |  |

[0001564590-16-017619:notes:30]
[same as prior period, unchanged from 0001564590-16-012239:notes:29]

[0001564590-16-017619:notes:31]
[same as prior period, unchanged from 0001564590-16-012239:notes:30]

[0001564590-16-017619:notes:32]
|  | March 31, 2016 |  |  | September 30, 2015 |  |
| Costs incurred on uncompleted contracts | $ | 1,000,967 |  |  | $ | 912,237 |  |
| Estimated earnings |  | 308,608 |  |  |  | 271,640 |  |
|  |  | 1,309,575 |  |  |  | 1,183,877 |  |
| Less: Billings to date |  | (1,259,161 | ) |  |  | (1,121,141 | ) |
| Net underbilled position | $ | 50,414 |  |  | $ | 62,736 |  |
| Included in the accompanying balance sheets under the following captions: |  |  |  |  |  |  |  |
| Costs and estimated earnings in excess of billings on uncompleted contracts – underbilled | $ | 89,970 |  |  | $ | 104,793 |  |
| Billings in excess of costs and estimated earnings on uncompleted contracts – overbilled |  | (39,556 | ) |  |  | (42,057 | ) |
| Net underbilled position | $ | 50,414 |  |  | $ | 62,736 |  |

[0001564590-16-017619:notes:33]
[same as prior period, unchanged from 0001564590-16-012239:notes:32]

[0001564590-16-017619:notes:34]
[same as prior period, unchanged from 0001564590-16-012239:notes:33]

[0001564590-16-017619:notes:35]
|  | Three months ended March 31, |  |  | Six months ended March 31, |  |
|  | 2016 |  |  | 2015 |  |  | 2016 |  |  | 2015 |  |
| Balance at beginning of period | $ | 5,105 |  |  | $ | 4,480 |  |  | $ | 4,930 |  |  | $ | 4,557 |  |
| Increase to warranty expense |  | 832 |  |  |  | 530 |  |  |  | 2,158 |  |  |  | 1,067 |  |
| Deduction for warranty charges |  | (1,175 | ) |  |  | (504 | ) |  |  | (2,275 | ) |  |  | (1,028 | ) |
| Change in foreign currency translation |  | 25 |  |  |  | (131 | ) |  |  | (26 | ) |  |  | (221 | ) |
| Balance at end of period | $ | 4,787 |  |  | $ | 4,375 |  |  | $ | 4,787 |  |  | $ | 4,375 |  |


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0001564590-16-017619:notes:36]
[same as prior period, unchanged from 0001564590-16-012239:notes:35]

[0001564590-16-017619:notes:37]
Our intangible assets consist of goodwill, which is not being amortized, and purchased technology, which is amortized over its estimated useful life.  Intangible assets balances, subject to amortization, at March 31, 2016 and September 30, 2015 consisted of the following (in thousands):

[0001564590-16-017619:notes:38]
|  | March 31, 2016 |  |  | September 30, 2015 |  |
|  | Gross |  |  |  |  |  |  | Net |  |  | Gross |  |  |  |  |  |  | Net |  |
|  | Carrying |  |  | Accumulated |  |  | Carrying |  |  | Carrying |  |  | Accumulated |  |  | Carrying |  |
|  | Value |  |  | Amortization |  |  | Value |  |  | Value |  |  | Amortization |  |  | Value |  |
| Purchased technology | $ | 11,749 |  |  | $ | (10,518 | ) |  | $ | 1,231 |  |  | $ | 11,749 |  |  | $ | (10,359 | ) |  | $ | 1,390 |  |
| Goodwill |  | 1,003 |  |  |  | — |  |  |  | 1,003 |  |  |  | 1,003 |  |  |  | — |  |  |  | 1,003 |  |
| Total | $ | 12,752 |  |  | $ | (10,518 | ) |  | $ | 2,234 |  |  | $ | 12,752 |  |  | $ | (10,359 | ) |  | $ | 2,393 |  |

[0001564590-16-017619:notes:39]
Amortization of intangible assets was $0.2 million for the six months ended March 31, 2016 and 2015.

[0001564590-16-017619:notes:40]
On August 7, 2006, we purchased certain assets related to the manufacturing of ANSI medium-voltage switchgear and circuit breaker business from General Electric Company (GE).  In connection with the acquisition, we entered into a 15 year supply agreement with GE pursuant to which GE would purchase from the Company all of its requirements for ANSI medium-voltage switchgear and circuit breakers and other related equipment and components (the Products).  In connection with the acquisition, we recorded an intangible asset related to this supply agreement.  On December 30, 2013, the Company and GE amended the supply agreement to allow GE to manufacture similar Products for sale immediately and allow GE to begin purchasing Products from other suppliers beginning December 31, 2014.  In return, GE paid us $10 million upon execution of the amended supply agreement and agreed to pay an additional $7 million over three years, subject to certain conditions.  As of March 31, 2016, we had $2.3 million recorded in other current assets and the remaining $2.3 million is recorded as a long-term receivable.  The $2.3 million recorded in other current assets was received in April 2016. We wrote off the intangible asset related to the original supply agreement and recorded a deferred credit in the amount of $8.1 million at December 31, 2013, the amount by which the proceeds from GE exceeded the unamortized balance of our intangible asset. We are amortizing this deferred credit over the four-year life of the agreement and have recognized gains in other income of $1.0 million for the six months ended March 31, 2016 and 2015.


## us-gaap:LongTermDebtTextBlock

[0001564590-16-017619:notes:41]
E. LONG-TERM DEBT

[0001564590-16-017619:notes:42]
Long-term debt consisted of the following (in thousands):

[0001564590-16-017619:notes:43]
|  | March 31, 2016 |  |  | September 30, 2015 |  |
| Industrial development revenue bonds | $ | 2,400 |  |  | $ | 2,800 |  |
| Less current portion |  | (400 | ) |  |  | (400 | ) |
| Total long-term debt and capital lease obligations | $ | 2,000 |  |  | $ | 2,400 |  |

[0001564590-16-017619:notes:44]
U.S. Revolver

[0001564590-16-017619:notes:45]
In Fiscal 2014, we amended and restated our existing credit agreement (the Amended Credit Agreement) with a major domestic bank. In Fiscal 2015, we entered into the Second Amendment of the Amended Credit Agreement (the Second Amendment).  The Second Amendment provided for the expansion of our Canadian manufacturing facility and allowed for the repurchase of our common stock pursuant to a share repurchase program announced in December 2014.  The Amended Credit Agreement provides for a $75.0 million revolving credit facility (U.S. Revolver). Obligations are collateralized by the stock of certain of our subsidiaries.

[0001564590-16-017619:notes:46]
The interest rate for amounts outstanding under the Amended Credit Agreement for the U.S. Revolver is a floating rate based upon the higher of the Federal Funds Rate plus 0.5%, the bank’s prime rate, or the Eurocurrency rate plus 1.00%. Once the applicable rate is determined, a margin ranging up to 1.75%, as determined by our consolidated leverage ratio, is added to the applicable rate.

[0001564590-16-017619:notes:47]
The U.S. Revolver provides for the issuance of letters of credit which reduce the amounts that may be borrowed under this revolver. The amount available under the U.S. Revolver was reduced by $24.7 million for our outstanding letters of credit at March 31, 2016.

[0001564590-16-017619:notes:48]
There were no borrowings outstanding under the U.S. Revolver as of March 31, 2016.  Amounts available under the U.S. Revolver were $50.3 million at March 31, 2016. The U.S. Revolver expires on December 31, 2018.

[0001564590-16-017619:notes:49]
The Amended Credit Agreement contains certain restrictive and maintenance-type covenants, such as restrictions on the amount of capital expenditures allowed. It also contains financial covenants defining various financial measures and the levels of these measures with which we must comply, as well as a “material adverse change” clause. A “material adverse change” is defined as a material change in our operations, business, properties, liabilities or condition (financial or otherwise) or a material impairment of our ability to perform our obligations under our credit agreements.

[0001564590-16-017619:notes:50]
The Amended Credit Agreement is collateralized by a pledge of 100% of the voting capital stock of each of our domestic subsidiaries and 65% of the voting capital stock of each non-domestic subsidiary, excluding Powell Canada. The Amended Credit Agreement provides for customary events of default and carries cross-default provisions with other existing debt agreements. If an event of default (as defined in the Amended Credit Agreement) occurs and is continuing, on the terms and subject to the conditions set forth in the Amended Credit Agreement, amounts outstanding under the Amended Credit Agreement may be accelerated and may become immediately due and payable. As of March 31, 2016, we were in compliance with all of the financial covenants of the Amended Credit Agreement.

[0001564590-16-017619:notes:51]
Canadian Revolver

[0001564590-16-017619:notes:52]
We have a $7.7 million credit agreement with a major international bank in Canada (the Canadian Revolver) to provide working capital support and letters of credit for our operations in Canada. The Canadian Revolver provides for the issuance of letters of credit which reduce the amounts that may be borrowed under this revolver.  There were no outstanding letters of credit under the Canadian Revolver at March 31, 2016.

[0001564590-16-017619:notes:53]
There were no borrowings outstanding under the Canadian Revolver as of March 31, 2016 and amounts available under the Canadian Revolver were $7.7 million at March 31, 2016.  The interest rate for amounts outstanding under the Canadian Revolver is a floating interest rate based upon either the Canadian Prime Rate, or the lender’s Bankers’ Acceptance Rate. Once the applicable rate is determined, a margin of 0.50% to 1.75%, as determined by our consolidated leverage ratio, is added to the applicable rate. The Canadian Revolver expires on March 31, 2018.

[0001564590-16-017619:notes:54]
The principal financial covenants are consistent with those described in our Amended Credit Agreement. The Canadian Revolver contains a “material adverse effect” clause. A “material adverse effect” is defined as a material change in the operations of Powell or Powell Canada in relation to our financial condition, property, business operations, expected net cash flows, liabilities or capitalization.

[0001564590-16-017619:notes:55]
The Canadian Revolver is secured by the assets of our Canadian operations and provides for customary events of default and carries cross-default provisions with our existing debt agreements. If an event of default (as defined in the Canadian Revolver) occurs and is continuing, per the terms and subject to the conditions set forth in the Canadian Revolver, amounts outstanding under the Canadian Revolver may be accelerated and may become immediately due and payable. As of March 31, 2016, we were in compliance with all of the financial covenants of the Canadian Revolver.

[0001564590-16-017619:notes:56]
Industrial Development Revenue Bonds

[0001564590-16-017619:notes:57]
We borrowed $8.0 million in October 2001 through a loan agreement funded with proceeds from tax-exempt industrial development revenue bonds (Bonds). These Bonds were issued by the Illinois Development Finance Authority and were used for the completion of our Northlake, Illinois facility. Pursuant to the Bond issuance, a reimbursement agreement between us and a major domestic bank required an issuance by the bank of an irrevocable direct-pay letter of credit (Bond LC), as collateral, to the Bonds’ trustee to guarantee payment of the Bonds’ principal and interest when due. The Bond LC is subject to both early termination and extension provisions customary to such agreements, as well as various covenants, for which we were in compliance at March 31, 2016. While the Bonds mature in 2021, the reimbursement agreement requires annual redemptions of $0.4 million that commenced on October 25, 2002. A sinking fund is used for the redemption of the Bonds. The Bonds bear interest at a floating rate determined weekly by the Bonds’ remarketing agent, which was the underwriter for the Bonds and is an affiliate of the bank. This interest rate was 0.57% as of March 31, 2016.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001564590-16-017619:notes:58]
F. COMMITMENTS AND CONTINGENCIES

[0001564590-16-017619:notes:59]
Long-Term Debt

[0001564590-16-017619:notes:60]
See Note E herein for discussion of our long-term debt.

[0001564590-16-017619:notes:61]
Letters of Credit and Surety Bonds

[0001564590-16-017619:notes:62]
Certain customers require us to post bank letter of credit guarantees or surety bonds. These guarantees and surety bonds assure that we will perform under the terms of our contract. In the event of default, the counterparty may demand payment from the bank under a letter of credit or performance by the surety under a bond. To date, there have been no significant expenses related to either letters of credit or surety bonds for the periods reported. We were contingently liable for secured and unsecured letters of credit of $24.7 million as of March 31, 2016. We also had surety bonds totaling $298.9 million that were outstanding, with additional bonding capacity of $451.1 million available, at March 31, 2016.

[0001564590-16-017619:notes:63]
We have a $14.4 million facility agreement (Facility Agreement) between Powell (UK) Limited and a large international bank. This Facility Agreement provides Powell (UK) the ability to enter into bank guarantees as well as forward exchange contracts and currency options. At March 31, 2016, we had outstanding guarantees totaling $2.8 million under this Facility Agreement and amounts available under this Facility Agreement were $11.6 million.  This facility is renewable in May 2016.

[0001564590-16-017619:notes:64]
The Facility Agreement provides for financial covenants and customary events of default, and carries cross-default provisions with our Amended Credit Facility. If an event of default (as defined in the Facility Agreement) occurs and is continuing, per the terms and subject to the conditions set forth therein, obligations outstanding under the Facility Agreement may be accelerated and may become or be declared immediately due and payable. As of March 31, 2016, we were in compliance with all of the financial covenants of the Facility Agreement.

[0001564590-16-017619:notes:65]
Litigation

[0001564590-16-017619:notes:66]
We are involved in various legal proceedings, claims and other disputes arising from our commercial operations, projects, employees and other matters which, in general, are subject to uncertainties and in which the outcomes are not predictable. Although we can give no assurances about the resolution of pending claims, litigation or other disputes and the effect such outcomes may have on us, management believes that any ultimate liability resulting from the outcome of such proceedings, to the extent not otherwise provided or covered by insurance, will not have a material adverse effect on our consolidated financial position or results of operations or liquidity.

[0001564590-16-017619:notes:67]
Liquidated Damages

[0001564590-16-017619:notes:68]
Certain of our customer contracts have schedule and performance obligation clauses that, if we fail to meet them, could require us to pay liquidated damages.  Each individual contract defines the conditions under which the customer may make a claim against us.  As of March 31, 2016, our exposure to possible liquidated damages was $8.9 million, of which approximately $2.0 million is estimated to be probable.  Based on our actual or projected failure to meet these various contractual commitments, $1.6 million has been recorded as a reduction to revenue.  We believe that we will be successful in obtaining change orders or contract extensions that should resolve the potential for any unaccrued liquidated damages; however, should we fail to achieve relief on some or all of these contractual obligations, we could be required to pay additional liquidated damages which could negatively impact our future operating results.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001564590-16-017619:notes:69]
| G. | STOCK-BASED COMPENSATION |

[0001564590-16-017619:notes:70]
[same as prior period, unchanged from 0001564590-16-012239:notes:69]

[0001564590-16-017619:notes:71]
[same as prior period, unchanged from 0001564590-16-012239:notes:70]

[0001564590-16-017619:notes:72]
We issue restricted stock units (RSUs) to certain officers and key employees of the Company.  The fair value of the RSUs is based on the closing price of our common stock as reported on the NASDAQ Global Market on the grant dates. These grants vest over a three-year period from their date of issuance.  In February 2016, the Board of Directors voted to modify the RSU awards.  The modification provides that sixty percent of the grant is time-based and vests over a three-year period on each anniversary of the grant date, based on continued employment.  The remaining forty percent of the grant will be earned based on the three-year earnings performance of the Company following the grant date.  At March 31, 2016, there were 142,688 RSUs outstanding. The RSUs do not have voting rights but receive dividend equivalents upon vesting; additionally, the shares of common stock underlying the RSUs are not considered issued and outstanding until vested and common stock is issued.

[0001564590-16-017619:notes:73]
RSU activity (number of shares) for the six months ending March 31, 2016 is summarized below:

[0001564590-16-017619:notes:74]
|  | Number of |  |  | Weighted |  |
|  | Restricted |  |  | Average |  |
|  | Stock |  |  | Fair Value |  |
|  | Units |  |  | Per Share |  |
| Outstanding at September 30, 2015 |  | 133,506 |  |  | $ | 50.26 |  |
| Granted |  | 136,800 |  |  |  | 29.80 |  |
| Vested(1) |  | (116,568 | ) |  |  | 33.10 |  |
| Forfeited/cancelled |  | (11,050 | ) |  |  | 30.27 |  |
| Outstanding at March 31, 2016 |  | 142,688 |  |  | $ | 46.22 |  |

[0001564590-16-017619:notes:75]
| (1) | Includes the accelerated vesting of 84,043 shares previously issued to our former Chief Executive Officer and other senior managers as part of their separation packages, see Note J. |

[0001564590-16-017619:notes:76]
During the six months ended March 31, 2016 and 2015, we recorded compensation expense of $2.7 million and $0.9 million, respectively, related to the RSUs.  The increase in compensation expense recorded in the six months ended March 31, 2016, was primarily due to the early vesting of shares associated with executive separation costs, see Note J.

[0001564590-16-017619:notes:77]
[same as prior period, unchanged from 0001564590-16-012239:notes:76]

[0001564590-16-017619:notes:78]
Restricted stock grants vest equally over their respective vesting period on each anniversary of the grant date and compensation expense is recognized over their respective vesting periods based on the price per share on the grant date.  In February 2016, 16,000 shares of restricted stock were issued to our non-employee directors at a price of $25.63 per share under the 2014 Director Plan. The annual restricted stock grants vest 50% per year over a two-year period on each anniversary of the grant date.

[0001564590-16-017619:notes:79]
During the six months ended March 31, 2016 and 2015, we recorded compensation expense of $0.4 million and $0.7 million, respectively, related to restricted stock grants.


## us-gaap:FairValueDisclosuresTextBlock

[0001564590-16-017619:notes:80]
[same as prior period, unchanged from 0001564590-16-012239:notes:79]

[0001564590-16-017619:notes:81]
[same as prior period, unchanged from 0001564590-16-012239:notes:80]

[0001564590-16-017619:notes:82]
[same as prior period, unchanged from 0001564590-16-012239:notes:81]

[0001564590-16-017619:notes:83]
[same as prior period, unchanged from 0001564590-16-012239:notes:82]

[0001564590-16-017619:notes:84]
[same as prior period, unchanged from 0001564590-16-012239:notes:83]

[0001564590-16-017619:notes:85]
[same as prior period, unchanged from 0001564590-16-012239:notes:84]

[0001564590-16-017619:notes:86]
The following table summarizes the fair value of our assets and liabilities that were accounted for at fair value on a recurring basis as of March 31, 2016 (in thousands):

[0001564590-16-017619:notes:87]
|  | Fair Value Measurements at March 31, 2016 |  |
|  | Quoted Prices in |  |  | Significant Other |  |  | Significant |  |  |  |  |  |
|  | Active Markets for |  |  | Observable |  |  | Unobservable |  |  | Fair Value at |  |
|  | Identical Assets |  |  | Inputs |  |  | Inputs |  |  | March 31, |  |
|  | (Level 1) |  |  | (Level 2) |  |  | (Level 3) |  |  | 2016 |  |
| Assets: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cash equivalents | $ | 234 |  |  | $ | — |  |  | $ | — |  |  | $ | 234 |  |
| Deferred compensation |  | 1,581 |  |  |  | 3,922 |  |  |  | — |  |  |  | 5,503 |  |
| Liabilities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Deferred compensation |  | — |  |  |  | 5,248 |  |  |  | — |  |  |  | 5,248 |  |

[0001564590-16-017619:notes:88]
[same as prior period, unchanged from 0001564590-16-012239:notes:87]

[0001564590-16-017619:notes:89]
|  | Fair Value Measurements at September 30, 2015 |  |
|  | Quoted Prices in |  |  | Significant Other |  |  | Significant |  |  |  |  |  |
|  | Active Markets for |  |  | Observable |  |  | Unobservable |  |  | Fair Value at |  |
|  | Identical Assets |  |  | Inputs |  |  | Inputs |  |  | September 30, |  |
|  | (Level 1) |  |  | (Level 2) |  |  | (Level 3) |  |  | 2015 |  |
| Assets: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cash equivalents | $ | 434 |  |  | $ | — |  |  | $ | — |  |  | $ | 434 |  |
| Deferred compensation |  | 1,879 |  |  |  | 2,904 |  |  |  | — |  |  |  | 4,783 |  |
| Liabilities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Deferred compensation |  | — |  |  |  | 4,487 |  |  |  | — |  |  |  | 4,487 |  |

[0001564590-16-017619:notes:90]
[same as prior period, unchanged from 0001564590-16-012239:notes:89]

[0001564590-16-017619:notes:91]
[same as prior period, unchanged from 0001564590-16-012239:notes:90]

[0001564590-16-017619:notes:92]
Fair value guidance requires certain fair value disclosures be presented in both interim and annual reports.  The estimated fair value amounts of financial instruments have been determined using available market information and valuation methodologies described below.

[0001564590-16-017619:notes:93]
Deferred Compensation – We hold investments in an irrevocable Rabbi Trust for our deferred compensation plan. These assets include both mutual fund investments and company-owned life insurance policies. Under the plan, participants designate investment options to serve as the basis for measurement of the notional value of their accounts.  The fair values of the underlying securities of these funds are based on quoted market prices and are categorized as Level 1 in the fair value measurement hierarchy.  The company-owned life insurance policies are valued at cash surrender value and are therefore categorized as Level 2 in the fair value measurement hierarchy.

[0001564590-16-017619:notes:94]
Industrial Development Revenue Bond – The fair value of our long-term debt depends primarily on the coupon rate of our industrial development revenue bonds.  The carrying value of our long-term debt at March 31, 2016, approximates fair value based on the current coupon rate of the bonds, which is reset weekly, and is classified as a Level 2 input in the fair value measurement hierarchy as there is an active market for the trading of these industrial development revenue bonds.

[0001564590-16-017619:notes:95]
There were no transfers between levels within the fair value measurement hierarchy during the three months ended March 31, 2016.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001564590-16-017619:notes:96]
[same as prior period, unchanged from 0001564590-16-012239:notes:95]

[0001564590-16-017619:notes:97]
[same as prior period, unchanged from 0001564590-16-012239:notes:96]

[0001564590-16-017619:notes:98]
|  | Three months ended March 31, |  |  | Six months ended March 31, |  |
|  | 2016 |  |  | 2015 |  |  | 2016 |  |  | 2015 |  |
| Income before income taxes | $ | 6,294 |  |  | $ | 2,696 |  |  | $ | 4,788 |  |  | $ | 1,466 |  |
| Income tax provision (benefit) |  | 727 |  |  |  | 6,379 |  |  |  | (320 | ) |  |  | 5,388 |  |
| Net income (loss) | $ | 5,567 |  |  | $ | (3,683 | ) |  | $ | 5,108 |  |  | $ | (3,922 | ) |
| Effective tax rate |  | 12 | % |  |  | 237 | % |  |  | (7) | % |  |  | 368 | % |

[0001564590-16-017619:notes:99]
|  | Six months ended March 31, |  |
|  | 2016 |  |  | 2015 |  |
| Statutory rate |  | 35 | % |  |  | 35 | % |
| Foreign valuation allowance |  | (11 | ) |  |  | 661 |  |
| Research and development credit |  | (24 | ) |  |  | (327 | ) |
| State income taxes, net of federal benefit |  | 2 |  |  |  | 2 |  |
| Rate differential and other |  | (9 | ) |  |  | (3 | ) |
| Effective tax rate |  | (7 | )% |  |  | 368 | % |

[0001564590-16-017619:notes:100]
We recorded an income tax benefit of $0.3 million for the six months ended March 31, 2016, compared to an income tax provision of $5.4 million for the six months ended March 31, 2015.  The effective tax rate for the six months ended March 31, 2016 was a 7% benefit compared to an effective tax rate of 368% for the six months ended March 31, 2015.  The effective tax rate for Fiscal 2016 was favorably impacted by the mix of income from our Canadian operations and the utilization of net operating loss carryforwards in Canada that have been fully reserved with a valuation allowance.  Additionally, the effective tax rate for the six months ended March 31, 2016 was favorably impacted by a $0.8 million discrete item recorded in the first quarter of Fiscal 2016 related to the retroactive reinstatement of the Research and Development Tax Credit (R&D Tax Credit) for the previously expired period from January 1, 2015 to September 30, 2015.  On December 18, 2015, the “Protecting Americans from Tax Hikes Act of 2015” was enacted which retroactively reinstated and made permanent the R&D Tax Credit.

[0001564590-16-017619:notes:101]
In the first six months of Fiscal 2015, our effective tax rate increased due to a $9.0 million valuation allowance recorded against our Canadian deferred tax assets.  In the second quarter of Fiscal 2015, we recorded a valuation allowance against the Canadian net deferred tax assets. Due to the historical Canadian losses, and the projected losses in the near term, we were required under the more-likely-than-not accounting standard to record a valuation allowance against the Canadian net deferred tax assets because we anticipated that we may not be able to realize the benefits of the net operating loss carryforwards and other deductible differences.   This was partially offset by the release of a $4.1 million FIN 48 reserve related to the R&D Tax Credit upon closing an IRS audit. We recorded a $0.6 million discrete item for the six months ended March 31, 2015 also related to the retroactive reinstatement of the R&D Tax Credit referred to above.


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0001564590-16-017619:notes:102]
[same as prior period, unchanged from 0001564590-16-012239:notes:102]

[0001564590-16-017619:notes:103]
We have taken various actions during Fiscal 2016 in response to challenging conditions in the oil and gas markets.  In the second quarter of Fiscal 2016, we incurred $3.3 million of separation costs as we continued to restructure our senior management team and align our salaried and hourly workforce with future production requirements.  In the first quarter of Fiscal 2016, we incurred $3.8 million of restructuring costs due to the departure of our former Chief Executive Officer in December 2015. Of the $7.1 million in restructuring and separation costs expensed in the six months ended March 31, 2016, $3.5 million has been paid and the remaining $3.6 million will be paid over the next nine months.  In the second quarter of Fiscal 2015, we incurred $1.3 million of restructuring and separation costs.
