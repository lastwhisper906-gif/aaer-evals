# POWL note change history — 0000080420-24-000059 → 0000080420-25-000029


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2025-02-07):
[0000080420-25-000029:note_history:1]
Certain customers require us to post letters of credit, bank guarantees or surety bonds. These security instruments assure that we will perform under the terms of our contract. In the event of default, the counterparty may demand payment from the bank under a letter of credit or bank guarantee, or performance by the surety under a bond. To date, there have been no significant draws or claims related to security instruments for the periods reported. We were contingently liable for letters of credit of $56.1 million as of December 31, 2024. We also had surety bonds totaling $432.1 million that were outstanding, with additional bonding capacity of $767.9 million available, at December 31, 2024. We have strong surety relationships; however, a change in market conditions or the sureties' assessment of our financial position could cause the sureties to require cash collateralization for undischarged liabilities under the bonds.
  (was, 2024-07-31, similarity 0.9868):
[0000080420-24-000059:note_history:1]
Certain customers require us to post letters of credit, bank guarantees or surety bonds. These security instruments assure that we will perform under the terms of our contract. In the event of default, the counterparty may demand payment from the bank under a letter of credit or bank guarantee, or performance by the surety under a bond. To date, there have been no significant draws or claims related to security instruments for the periods reported. We were contingently liable for letters of credit of $68.4 million as of June 30, 2024. We also had surety bonds totaling $422.1 million that were outstanding, with additional bonding capacity of $777.9 million available, at June 30, 2024. We have strong surety relationships; however, a change in market conditions or the sureties' assessment of our financial position could cause the sureties to require cash collateralization for undischarged liabilities under the bonds.

- changed (2025-02-07):
[0000080420-25-000029:note_history:2]
We have an $18.8 million facility agreement (Facility Agreement) between Powell (UK) Limited and a large international bank that provides Powell (UK) Limited the ability to enter into bank guarantees as well as forward exchange contracts and currency options. At December 31, 2024, we had outstanding guarantees totaling $7.7 million, with an additional capacity of $11.1 million available under this Facility Agreement. The Facility Agreement provides for customary events of default and carries cross-default provisions with the U.S. Revolver. If an event of default (as defined in the Facility Agreement) occurs and is continuing, per the terms and subject to the conditions set forth therein, obligations outstanding under the Facility Agreement may be accelerated and declared immediately due and payable. Additionally, we are required to maintain cash collateral for guarantees greater than two years. As of December 31, 2024, we were in compliance with all of the financial covenants of the Facility Agreement.
  (was, 2024-07-31, similarity 0.9874):
[0000080420-24-000059:note_history:2]
We have a $19.0 million facility agreement (Facility Agreement) between Powell (UK) Limited and a large international bank that provides Powell (UK) Limited the ability to enter into bank guarantees as well as forward exchange contracts and currency options. At June 30, 2024, we had outstanding guarantees totaling $6.4 million, with an additional capacity of $12.6 million available under this Facility Agreement. The Facility Agreement provides for customary events of default and carries cross-default provisions with the U.S. Revolver. If an event of default (as defined in the Facility Agreement) occurs and is continuing, per the terms and subject to the conditions set forth therein, obligations outstanding under the Facility Agreement may be accelerated and declared immediately due and payable. Additionally, we are required to maintain cash collateral for guarantees greater than two years. As of June 30, 2024, we were in compliance with all of the financial covenants of the Facility Agreement.

- added (2025-02-07):
[0000080420-25-000029:note_history:3]
Certain of our customer contracts have schedule and performance obligation clauses that, if we fail to meet them, could require us to pay liquidated damages. Each individual contract defines the conditions under which the customer may make a claim against us. As of December 31, 2024, certain contracts had a probable exposure to liquidated damages claims of $2.4 million, which could possibly increase to $3.1 million under certain circumstances. Based on our actual or projected failure to meet these various contractual commitments, $2.0 million has been recorded as a reduction to revenue. We will attempt to obtain change orders, contract extensions or accelerate project completion, which may resolve the potential for any unrecorded liquidated damages claims. Should we fail to achieve relief on some or all of these contractual obligations, we could be required to pay additional liquidated damages, which could negatively impact our future operating results.

- removed (2025-02-07):
[0000080420-24-000059:note_history:4]
Certain of our customer contracts have schedule and performance obligation clauses that, if we fail to meet them, could require us to pay liquidated damages. Each individual contract defines the conditions under which the customer may make a claim against us. As of June 30, 2024, certain contracts had a probable exposure to liquidated damages claims of $2.5 million, which

- removed (2025-02-07):
[0000080420-24-000059:note_history:5]
could possibly increase to $2.8 million under certain circumstances. Based on our actual or projected failure to meet these various contractual commitments, $1.7 million has been recorded as a reduction to revenue. We will attempt to obtain change orders, contract extensions or accelerate project completion, which may resolve the potential for any unrecorded liquidated damages claims. Should we fail to achieve relief on some or all of these contractual obligations, we could be required to pay additional liquidated damages, which could negatively impact our future operating results.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureAndSignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- added (2025-02-07):
[0000080420-25-000029:note_history:6]
Powell Industries, Inc. (we, us, our, Powell or the Company) is a Delaware corporation founded by William E. Powell in 1947. We develop, design, manufacture and service custom-engineered equipment and systems that distribute, control and monitor the flow of electrical energy and provide protection to motors, transformers and other electrically powered equipment. Our major subsidiaries, all of which are wholly owned, include Powell Electrical Systems, Inc.; Powell Canada Inc.; Powell (UK) Limited; and Powell Industries International, B.V.

- added (2025-02-07):
[0000080420-25-000029:note_history:7]
We are headquartered in Houston, Texas and primarily serve the oil and gas and petrochemical markets, the electric utility market, and commercial and other industrial markets. Beyond these major markets, we also provide products and services to the light rail traction power market and other markets that include universities and government entities. We are continuously developing new channels to electrical markets through original equipment manufacturers and distribution market channels.

- changed (2025-02-07):
[0000080420-25-000029:note_history:8]
The unaudited condensed consolidated financial statements should be read in conjunction with the audited consolidated financial statements and notes thereto of Powell and its subsidiaries included in Powell’s Annual Report on Form 10-K for the year ended September 30, 2024, which was filed with the Securities and Exchange Commission (SEC) on November 20, 2024.
  (was, 2024-07-31, similarity 0.9914):
[0000080420-24-000059:note_history:8]
The unaudited condensed consolidated financial statements should be read in conjunction with the audited consolidated financial statements and notes thereto of Powell and its subsidiaries included in Powell’s Annual Report on Form 10-K for the year ended September 30, 2023, which was filed with the Securities and Exchange Commission (SEC) on December 6, 2023.

- changed (2025-02-07):
[0000080420-25-000029:note_history:9]
Segment Reporting (Topic 280): Improvements to Reportable Segment Disclosures, which requires that public entities disclose significant segment expenses that are regularly provided to the chief operating decision maker (CODM) on an annual and interim basis. It also requires that public entities disclose the title and position of the CODM and an explanation of how the CODM uses the reported measures in assessing segment performance and resource allocation. Additionally, it requires that all existing annual disclosures about segment profit or loss and assets must be provided on an interim basis and clarifies that single reportable segment entities are subject to the disclosure requirement under Topic 280 in its entirety. ASU 2023-07 is effective for fiscal years beginning after December 15, 2023 and interim periods within fiscal years beginning after December 15, 2024. A public entity should apply ASU 2023-07 retrospectively to all prior periods presented in the financial statements. Early adoption is permitted. We are currently evaluating the impacts of the new standard.
  (was, 2024-07-31, similarity 0.9972):
[0000080420-24-000059:note_history:9]
Segment Reporting (Topic 280): Improvements to Reportable Segment Disclosures, which requires that public entities disclose significant segment expenses that are regularly provided to the chief operating decision maker (CODM) on an annual and interim basis. It also requires that public entities disclose the title and position of the CODM and an explanation of how the CODM uses the reported measures in assessing segment performance and resource allocation. Additionally, it requires that all existing annual disclosures about segment profit or loss and assets must be provided on an interim basis and clarifies that single reportable segment entities are subject to the disclosure requirement under Topic 280 in its entirety. ASU 2023-07 is effective for fiscal years beginning after December 15, 2023 and interim periods within those fiscal years beginning after December 15, 2024. A public entity should apply ASU 2023-07 retrospectively to all prior periods presented in the financial statements. Early adoption is permitted. We are currently evaluating the impacts of the new standard.

- added (2025-02-07):
[0000080420-25-000029:note_history:10]
In December 2023, the FASB issued ASU 2023-09, Improvements to Income Tax Disclosures, which enhances the transparency of income tax disclosures. It requires greater disaggregation of information in the tax rate reconciliation and income taxes paid disaggregated by jurisdiction. This ASU is effective for fiscal years beginning after December 15, 2024, and should be applied on a prospective basis. Retrospective application and early adoption are permitted. We are currently evaluating the impacts of the new standard.

- changed (2025-02-07):
[0000080420-25-000029:note_history:11]
In March 2024, the SEC adopted final rules designed to enhance and standardize disclosures related to the risks and impacts of climate-related matters. The final rules require registrants to disclose certain climate-related information in registration statements and annual reports. Such information relates to climate-related risks and risk management processes for, and governance and oversight activities of, such risks. The final rules also include requirements to disclose the financial effects of severe weather events and other natural conditions in the audited financial statements. In addition, larger registrants will be required to disclose information about greenhouse gas emissions, which will be subject to a phased-in assurance requirement. These disclosure requirements were scheduled to be effective for the Company's fiscal year beginning October 1, 2025. However, in April 2024, the SEC voluntarily stayed the final rules as a result of pending legal challenges. We are currently evaluating the impacts of the final rules on our consolidated financial statements and related disclosures.
  (was, 2024-07-31, similarity 0.6362):
[0000080420-24-000059:note_history:11]
In December 2023, the FASB issued ASU 2023-09, Improvements to Income Tax Disclosures, which enhances the transparency of income tax disclosures. It requires greater disaggregation of information in the tax rate reconciliation and income taxes paid disaggregated by jurisdiction. This ASU is effective for fiscal years beginning after December 15, 2024, and should be applied on a prospective basis. Retrospective application and early adoption are permitted. We are currently evaluating the impacts of the new standard.
In March 2024, the SEC adopted final rules designed to enhance and standardize disclosures related to the risks and impacts of climate-related matters. The final rules require registrants to disclose certain climate-related information in registration statements and annual reports. Such information relates to climate-related risks and risk management processes for, and governance and oversight activities of such risks. The final rules also include requirements to disclose the financial effects of severe weather events and other natural conditions in the audited financial statements. In addition, larger registrants will be required to disclose information about greenhouse gas emissions, which will be subject to a phased-in assurance requirement. These disclosure requirements will be effective for the Company's fiscal year beginning October 1, 2025. In April 2024, the SEC voluntarily stayed the final rules as a result of pending legal challenges. We are currently evaluating the impacts of the final rules on our consolidated financial statements and related disclosures.

- added (2025-02-07):
[0000080420-25-000029:note_history:12]
In November 2024, the FASB issued ASU No. 2024-03, Reporting Comprehensive Income – Expense Disaggregation Disclosures, which requires additional qualitative and quantitative information about specific expense categories in the notes to financial statements for both interim and annual reporting periods. In January 2025, the FASB further clarified the effective date for interim reporting periods. This ASU is effective for fiscal years beginning after December 15, 2026 and interim periods within those fiscal years beginning after December 15, 2027, with early adoption permitted. We are currently evaluating the impacts of the new standard.

- removed (2025-02-07):
[0000080420-24-000059:note_history:13]
Powell Industries, Inc. (we, us, our, Powell or the Company) is a Delaware corporation founded by William E. Powell in 1947. Our major subsidiaries, all of which are wholly owned, include Powell Electrical Systems, Inc.; Powell (UK) Limited; Powell Canada Inc.; and Powell Industries International, B.V.

- removed (2025-02-07):
[0000080420-24-000059:note_history:14]
We develop, design, manufacture and service custom-engineered equipment and systems that distribute, control and monitor the flow of electrical energy and provide protection to motors, transformers and other electrically powered equipment. We are headquartered in Houston, Texas, and serve the oil and gas and petrochemical markets that include onshore and offshore production, hydrogen, carbon capture, liquefied natural gas (LNG) facilities and terminals, pipelines, refineries and petrochemical plants. Additional markets include electric utility, light rail traction power, and commercial and other industrial markets that include end markets such as data centers, mining and metals, and pulp and paper.


## us-gaap:LongTermDebtTextBlock (debt) — matched_by: tag_name, score: 1.0

- added (2025-02-07):
[0000080420-25-000029:note_history:15]
We have a credit agreement with Bank of America, N.A. and Texas Capital Bank with an aggregate commitment of $150.0 million, consisting of $100.0 million committed by Bank of America and $50.0 million committed by Texas Capital Bank (the U.S. Revolver). The U.S. Revolver has an expiration date of October 4, 2028.

- added (2025-02-07):
[0000080420-25-000029:note_history:16]
As of December 31, 2024, there were no amounts borrowed under the U.S. Revolver, and letters of credit outstanding were $56.1 million. There was $93.9 million available for the issuance of letters of credit and borrowings under the U.S. Revolver as of December 31, 2024.

- changed (2025-02-07):
[0000080420-25-000029:note_history:17]
As of December 31, 2024, we were in compliance with all of the financial covenants of the U.S. Revolver.
  (was, 2024-07-31, similarity 0.9479):
[0000080420-24-000059:note_history:17]
As of June 30, 2024, we were in compliance with all of the financial covenants of the U.S. Revolver.

- removed (2025-02-07):
[0000080420-24-000059:note_history:18]
On October 4, 2023, we entered into a third amendment (the Third Amendment) to our credit agreement with Bank of America, N.A. (as amended, the U.S. Revolver). The Third Amendment added Texas Capital Bank as Syndication Agent and a lender, increased the amount of the revolving line of credit from $125.0 million to $150.0 million, and extended the expiry date to October 4, 2028. The aggregate commitment of $150.0 million consists of $100.0 million committed by Bank of America and $50.0 million committed by Texas Capital Bank. As amended by the Third Amendment, the lesser of (a) $60 million, (b) 60% of available cash, and (c) the aggregate face amount of the issued but undrawn letters of credit that are not cash-secured, shall be deducted from consolidated funded indebtedness, when calculating the consolidated net leverage ratio. We have the option to cash collateralize all or a portion of the letters of credit outstanding, which would favorably impact the consolidated funded indebtedness calculation and the consolidated net leverage ratio. On June 26, 2024, in connection with the expected discontinuation of the publication of the Canadian Dollar Offered Rate (CDOR), we further amended the U.S. Revolver by entering into a Canadian benchmark replacement conforming changes amendment with Bank of America, N.A. that added and amended certain terms related to the replacement of the CDOR as a benchmark rate with the forward-looking term rate based on the Canadian Overnight Repo Rate Average.

- removed (2025-02-07):
[0000080420-24-000059:note_history:19]
As of June 30, 2024, there were no amounts borrowed under the U.S. Revolver, and letters of credit outstanding were $68.4 million. There was $81.6 million available for the issuance of letters of credit and borrowings under the U.S. Revolver as of June 30, 2024.


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2025-02-07):
[0000080420-25-000029:note_history:20]
The following tables present our disaggregated revenue by geographic destination and market sector for the three months ended December 31, 2024 and 2023 (in thousands):
  (was, 2024-07-31, similarity 0.9415):
[0000080420-24-000059:note_history:20]
The following tables present our disaggregated revenue by geographic destination and market sector for the three and nine months ended June 30, 2024 and 2023 (in thousands):

- changed (2025-02-07):
[0000080420-25-000029:note_history:21]
|  | Three months ended December 31, |  |  |
|  | 2024 |  | 2023 |  |  |  |  |
| United States | $ | 197,772 |  |  | $ | 159,860 |  |  |  |  |  |
| Canada | 31,694 |  |  | 20,350 |  |  |  |  |  |
| Europe | 5,528 |  |  | 6,532 |  |  |  |  |  |
| Middle East and Africa | 4,558 |  |  | 3,275 |  |  |  |  |  |
| Mexico, Central and South America | 299 |  |  | 2,657 |  |  |  |  |  |
| Asia/Pacific | 1,580 |  |  | 1,343 |  |  |  |  |  |
| Total revenues by geographic destination | $ | 241,431 |  |  | $ | 194,017 |  |  |  |  |  |
  (was, 2024-07-31, similarity 0.6159):
[0000080420-24-000059:note_history:21]
|  | Three months ended June 30, |  | Nine months ended June 30, |
|  | 2024 |  | 2023 |  | 2024 |  | 2023 |
| United States | $ | 243,744 |  |  | $ | 153,258 |  |  | $ | 620,537 |  |  | $ | 387,531 |  |
| Canada | 29,695 |  |  | 21,765 |  |  | 74,205 |  |  | 62,255 |  |
| Europe | 9,464 |  |  | 8,038 |  |  | 24,261 |  |  | 20,125 |  |
| Middle East and Africa | 2,322 |  |  | 3,966 |  |  | 8,400 |  |  | 10,396 |  |
| Mexico, Central and South America | 1,962 |  |  | 3,000 |  |  | 6,778 |  |  | 5,457 |  |
| Asia/Pacific | 981 |  |  | 2,338 |  |  | 3,112 |  |  | 4,903 |  |
| Total revenues by geographic destination | $ | 288,168 |  |  | $ | 192,365 |  |  | $ | 737,293 |  |  | $ | 490,667 |  |

- changed (2025-02-07):
[0000080420-25-000029:note_history:22]
|  | Three months ended December 31, |  |  |
|  | 2024 |  | 2023 |  |  |  |  |
| Oil and gas (excludes petrochemical) | $ | 95,679 |  |  | $ | 83,636 |  |  |  |  |  |
| Petrochemical | 33,183 |  |  | 28,367 |  |  |  |  |  |
| Electric utility | 51,240 |  |  | 40,703 |  |  |  |  |  |
| Commercial and other industrial | 44,300 |  |  | 24,672 |  |  |  |  |  |
| Light rail traction power | 8,228 |  |  | 4,345 |  |  |  |  |  |
| All others | 8,801 |  |  | 12,294 |  |  |  |  |  |
| Total revenues by market sector | $ | 241,431 |  |  | $ | 194,017 |  |  |  |  |  |
  (was, 2024-07-31, similarity 0.724):
[0000080420-24-000059:note_history:22]
|  | Three months ended June 30, |  | Nine months ended June 30, |
|  | 2024 |  | 2023 |  | 2024 |  | 2023 |
| Oil and gas (excludes petrochemical) | $ | 114,336 |  |  | $ | 73,452 |  |  | $ | 301,792 |  |  | $ | 179,560 |  |
| Petrochemical | 56,784 |  |  | 21,995 |  |  | 135,221 |  |  | 70,372 |  |
| Electric utility | 57,009 |  |  | 43,824 |  |  | 145,214 |  |  | 114,899 |  |
| Commercial and other industrial | 42,044 |  |  | 35,527 |  |  | 101,610 |  |  | 74,846 |  |
| Light rail traction power | 5,322 |  |  | 7,143 |  |  | 14,184 |  |  | 21,532 |  |
| All others | 12,673 |  |  | 10,424 |  |  | 39,272 |  |  | 29,458 |  |
| Total revenues by market sector | $ | 288,168 |  |  | $ | 192,365 |  |  | $ | 737,293 |  |  | $ | 490,667 |  |


## us-gaap:RevenueFromContractWithCustomerPolicyTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2025-02-07):
[0000080420-25-000029:note_history:23]
Our revenues are primarily generated from the manufacturing of custom-engineered products and systems under long-term, fixed-price contracts under which we agree to manufacture various products such as traditional and arc-resistant distribution switchgear and control gear, medium-voltage circuit breakers, monitoring and control communications systems, motor control centers, switches and bus duct systems. These products may be sold separately as an engineered solution but are typically integrated into custom-built enclosures which we also build. These enclosures are referred to as power control room substations (PCRs®), custom-engineered modules or electrical houses (E-Houses). Some contracts may also include the installation and the commissioning of these enclosures.
  (was, 2024-07-31, similarity 0.9994):
[0000080420-24-000059:note_history:23]
Our revenues are primarily generated from the manufacturing of custom-engineered products and systems under long-term fixed-price contracts under which we agree to manufacture various products such as traditional and arc-resistant distribution switchgear and control gear, medium-voltage circuit breakers, monitoring and control communications systems, motor control centers, switches and bus duct systems. These products may be sold separately as an engineered solution but are typically integrated into custom-built enclosures which we also build. These enclosures are referred to as power control room substations (PCRs®), custom-engineered modules or electrical houses (E-Houses). Some contracts may also include the installation and the commissioning of these enclosures.

- changed (2025-02-07):
[0000080420-25-000029:note_history:24]
We also have contracts to provide field service inspection, installation, commissioning, modification, and repair services, as well as retrofit and retrofill components for existing systems. If the service contract terms give us the right to invoice the customer for an amount that corresponds directly with the value of our performance completed to date (i.e., a service contract in which we bill a fixed amount for each hour of service provided), then we recognize revenue over time in each reporting period corresponding to the amount that we have the right to invoice. Our performance obligations are satisfied as the work progresses. Revenues from our custom-engineered products and value-added services transferred to customers over time accounted for approximately 97% and 94% of revenues for the three months ended December 31, 2024 and December 31, 2023, respectively.
  (was, 2024-07-31, similarity 0.9157):
[0000080420-24-000059:note_history:24]
We also have contracts to provide field service inspection, installation, commissioning, modification, and repair services, as well as retrofit and retrofill components for existing systems. If the service contract terms give us the right to invoice the customer for an amount that corresponds directly with the value of our performance completed to date (i.e., a service contract in which we bill a fixed amount for each hour of service provided), then we recognize revenue over time in each reporting period corresponding to the amount that we have the right to invoice. Our performance obligations are satisfied as the work progresses. Revenues from our custom-engineered products and value-added services transferred to customers over time accounted for approximately 96% and 95% of revenues for the three and nine months ended June 30, 2024, respectively, and approximately 94% and 93% of revenues for the three and nine months ended June 30, 2023, respectively.

- changed (2025-02-07):
[0000080420-25-000029:note_history:25]
We also have sales orders for spare parts and replacement circuit breakers for switchgear that are obsolete or that are no longer produced by the original manufacturer. Revenues from these sales orders are recognized at the time we fulfill our performance obligation to the customer, which is typically upon shipment and represented approximately 3% and 6% of revenues for the three months ended December 31, 2024 and December 31, 2023, respectively.
  (was, 2024-07-31, similarity 0.8311):
[0000080420-24-000059:note_history:25]
We also have sales orders for spare parts and replacement circuit breakers for switchgear that are obsolete or that are no longer produced by the original manufacturer. Revenues from these sales orders are recognized at the time we fulfill our performance obligation to the customer, which is typically upon shipment and represented approximately 4% and 5% of revenues for the three and nine months ended June 30, 2024, respectively, and approximately 6% and 7% of revenues for the three and nine months ended June 30, 2023, respectively.

- changed (2025-02-07):
[0000080420-25-000029:note_history:26]
Additionally, some contracts may contain a cancellation clause that could limit the amount of revenue we are able to recognize over time. In these instances, revenue and costs associated with these contracts are deferred and recognized at a point in time when the performance obligation is fulfilled.
Selling and administrative costs incurred in relation to obtaining a contract are typically expensed as incurred. We periodically utilize a third-party sales agent to obtain a contract and will pay a commission to that agent. We record the full commission liability to the third-party sales agents at the order date, with a corresponding deferred asset. As the project progresses, we record commission expense based on percentage of completion rates that correlate to the project and reduce the deferred asset. Once we have been paid by the customer, we pay the commission and the liability is reduced
Performance Obligations
  (was, 2024-07-31, similarity 0.9952):
[0000080420-24-000059:note_history:26]
Additionally, some contracts may contain a cancellation clause that could limit the amount of revenue we are able to recognize over time. In these instances, revenue and costs associated with these contracts are deferred and recognized at a point in time when the performance obligation is fulfilled.
Selling and administrative costs incurred in relation to obtaining a contract are typically expensed as incurred. We periodically utilize a third-party sales agent to obtain a contract and will pay a commission to that agent. We record the full commission liability to the third-party sales agents at the order date, with a corresponding deferred asset. As the project progresses, we record commission expense based on percentage of completion rates that correlate to the project and reduce the deferred asset. Once we have been paid by the customer, we pay the commission and the deferred liability is reduced
Performance Obligations


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2025-02-07):
[0000080420-25-000029:note_history:27]
Our revenues are primarily generated from the manufacturing of custom-engineered products and systems under long-term, fixed-price contracts under which we agree to manufacture various products such as traditional and arc-resistant distribution switchgear and control gear, medium-voltage circuit breakers, monitoring and control communications systems, motor control centers, switches and bus duct systems. These products may be sold separately as an engineered solution but are typically integrated into custom-built enclosures which we also build. These enclosures are referred to as power control room substations (PCRs®), custom-engineered modules or electrical houses (E-Houses). Some contracts may also include the installation and the commissioning of these enclosures.
  (was, 2024-07-31, similarity 0.9994):
[0000080420-24-000059:note_history:27]
Our revenues are primarily generated from the manufacturing of custom-engineered products and systems under long-term fixed-price contracts under which we agree to manufacture various products such as traditional and arc-resistant distribution switchgear and control gear, medium-voltage circuit breakers, monitoring and control communications systems, motor control centers, switches and bus duct systems. These products may be sold separately as an engineered solution but are typically integrated into custom-built enclosures which we also build. These enclosures are referred to as power control room substations (PCRs®), custom-engineered modules or electrical houses (E-Houses). Some contracts may also include the installation and the commissioning of these enclosures.

- changed (2025-02-07):
[0000080420-25-000029:note_history:28]
We also have contracts to provide field service inspection, installation, commissioning, modification, and repair services, as well as retrofit and retrofill components for existing systems. If the service contract terms give us the right to invoice the customer for an amount that corresponds directly with the value of our performance completed to date (i.e., a service contract in which we bill a fixed amount for each hour of service provided), then we recognize revenue over time in each reporting period corresponding to the amount that we have the right to invoice. Our performance obligations are satisfied as the work progresses. Revenues from our custom-engineered products and value-added services transferred to customers over time accounted for approximately 97% and 94% of revenues for the three months ended December 31, 2024 and December 31, 2023, respectively.
  (was, 2024-07-31, similarity 0.9157):
[0000080420-24-000059:note_history:28]
We also have contracts to provide field service inspection, installation, commissioning, modification, and repair services, as well as retrofit and retrofill components for existing systems. If the service contract terms give us the right to invoice the customer for an amount that corresponds directly with the value of our performance completed to date (i.e., a service contract in which we bill a fixed amount for each hour of service provided), then we recognize revenue over time in each reporting period corresponding to the amount that we have the right to invoice. Our performance obligations are satisfied as the work progresses. Revenues from our custom-engineered products and value-added services transferred to customers over time accounted for approximately 96% and 95% of revenues for the three and nine months ended June 30, 2024, respectively, and approximately 94% and 93% of revenues for the three and nine months ended June 30, 2023, respectively.

- changed (2025-02-07):
[0000080420-25-000029:note_history:29]
We also have sales orders for spare parts and replacement circuit breakers for switchgear that are obsolete or that are no longer produced by the original manufacturer. Revenues from these sales orders are recognized at the time we fulfill our performance obligation to the customer, which is typically upon shipment and represented approximately 3% and 6% of revenues for the three months ended December 31, 2024 and December 31, 2023, respectively.
  (was, 2024-07-31, similarity 0.8311):
[0000080420-24-000059:note_history:29]
We also have sales orders for spare parts and replacement circuit breakers for switchgear that are obsolete or that are no longer produced by the original manufacturer. Revenues from these sales orders are recognized at the time we fulfill our performance obligation to the customer, which is typically upon shipment and represented approximately 4% and 5% of revenues for the three and nine months ended June 30, 2024, respectively, and approximately 6% and 7% of revenues for the three and nine months ended June 30, 2023, respectively.

- changed (2025-02-07):
[0000080420-25-000029:note_history:30]
Selling and administrative costs incurred in relation to obtaining a contract are typically expensed as incurred. We periodically utilize a third-party sales agent to obtain a contract and will pay a commission to that agent. We record the full commission liability to the third-party sales agents at the order date, with a corresponding deferred asset. As the project progresses, we record commission expense based on percentage of completion rates that correlate to the project and reduce the deferred asset. Once we have been paid by the customer, we pay the commission and the liability is reduced.
  (was, 2024-07-31, similarity 0.9926):
[0000080420-24-000059:note_history:30]
Selling and administrative costs incurred in relation to obtaining a contract are typically expensed as incurred. We periodically utilize a third-party sales agent to obtain a contract and will pay a commission to that agent. We record the full commission liability to the third-party sales agents at the order date, with a corresponding deferred asset. As the project progresses, we record commission expense based on percentage of completion rates that correlate to the project and reduce the deferred asset. Once we have been paid by the customer, we pay the commission and the deferred liability is reduced.

- changed (2025-02-07):
[0000080420-25-000029:note_history:31]
Remaining unsatisfied performance obligations, which we refer to as backlog, represent the estimated transaction price for goods and services for which we have a material right, but work has not been performed. As of December 31, 2024, we had backlog of $1.3 billion, of which approximately $893 million is expected to be recognized as revenue within the next twelve months. Backlog may not be indicative of future operating results as orders may be cancelled or modified by our customers.
  (was, 2024-07-31, similarity 0.8486):
[0000080420-24-000059:note_history:31]
Remaining unsatisfied performance obligations, which we refer to as backlog, represent the estimated transaction price for goods and services for which we have a material right, but work has not been performed. As of June 30, 2024, we had backlog of $1.3 billion, of which approximately $841 million is expected to be recognized as revenue within the next twelve months.

- changed (2025-02-07):
[0000080420-25-000029:note_history:32]
Our backlog does not include service and maintenance-type contracts for which we have the right to invoice as services are performed.
  (was, 2024-07-31, similarity 0.6772):
[0000080420-24-000059:note_history:32]
Backlog may not be indicative of future operating results as orders may be cancelled or modified by our customers. Our backlog does not include service and maintenance-type contracts for which we have the right to invoice as services are performed.

- changed (2025-02-07):
[0000080420-25-000029:note_history:33]
For the three months ended December 31, 2024 and 2023, our operating results were positively impacted by $2.4 million and $5.4 million, respectively, as a result of net changes in contract estimates related to projects in progress at the beginning of the respective period. These changes in estimates resulted primarily from favorable project execution, reduced cost estimates and negotiations of variable consideration, discussed below, as well as revenue recognized from project cancellations and other changes in facts and circumstances during these periods. Gross unfavorable changes in contract estimates were immaterial for both the three months ended December 31, 2024 and 2023.
  (was, 2024-07-31, similarity 0.8395):
[0000080420-24-000059:note_history:33]
For the nine months ended June 30, 2024 and 2023, our operating results were positively impacted by $14.2 million and $13.2 million, respectively, as a result of net changes in contract estimates related to projects in progress at the beginning of the respective period. These changes in estimates resulted primarily from favorable project execution, reduced cost estimates and negotiations of variable consideration, discussed below, as well as revenue recognized from project cancellations and other changes in facts and circumstances during these periods. Project cancellations on two projects increased gross profit for the nine months ended June 30, 2023 by $3.4 million. Gross unfavorable changes in contract estimates were immaterial for both the nine months ended June 30, 2024 and 2023.

- changed (2025-02-07):
[0000080420-25-000029:note_history:34]
Contract assets and liabilities as of December 31, 2024 and September 30, 2024 are summarized below (in thousands):
  (was, 2024-07-31, similarity 0.9515):
[0000080420-24-000059:note_history:34]
Contract assets and liabilities as of June 30, 2024 and September 30, 2023 are summarized below (in thousands):

- changed (2025-02-07):
[0000080420-25-000029:note_history:35]
|  | December 31, 2024 |  | September 30, 2024 |
| Contract assets | $ | 92,349 |  |  | $ | 102,827 |  |
| Contract liabilities | (282,595) |  |  | (287,763) |  |
| Net contract liability | $ | (190,246) |  |  | $ | (184,936) |  |
  (was, 2024-07-31, similarity 0.9709):
[0000080420-24-000059:note_history:35]
|  | June 30, 2024 |  | September 30, 2023 |
| Contract assets | $ | 90,955 |  |  | $ | 60,621 |  |
| Contract liabilities | (282,924) |  |  | (279,796) |  |
| Net contract liability | $ | (191,969) |  |  | $ | (219,175) |  |

- changed (2025-02-07):
[0000080420-25-000029:note_history:36]
Our net contract billing position remained a net liability at both December 31, 2024 and September 30, 2024, primarily due to favorable contract billing milestones. We typically allocate a significant percentage of the progress billing to the early stages of the contract. To determine the amount of revenue recognized during the period from contract liabilities, we first allocate revenue to the individual contract liability balance outstanding at the beginning of the period until the revenue exceeds that balance. During the three months ended December 31, 2024, we recognized revenue of $116.9 million that was related to contract liabilities outstanding at September 30, 2024.
  (was, 2024-07-31, similarity 0.9531):
[0000080420-24-000059:note_history:36]
Our net contract billing position remained a net liability at both June 30, 2024 and September 30, 2023, primarily due to favorable contract billing milestones. We typically allocate a significant percentage of the progress billing to the early stages of the contract. To determine the amount of revenue recognized during the period from contract liabilities, we first allocate revenue to the individual contract liability balance outstanding at the beginning of the period until the revenue exceeds that balance. During the nine months ended June 30, 2024, we recognized revenue of $228.9 million that was related to contract liabilities outstanding at September 30, 2023.

- changed (2025-02-07):
[0000080420-25-000029:note_history:37]
The timing of our invoice process is typically dependent on the completion of certain milestones and contract terms and subject to agreement by our customer. Payment is typically expected within 30 days of invoice. Any uncollected invoiced amounts for our performance obligations recognized over time, including contract retentions, are recorded as accounts receivable in the Condensed Consolidated Balance Sheets. Certain contracts allow customers to withhold a small percentage of billings pursuant to retainage provisions, and such amounts are generally due upon completion of the contract and acceptance of the project by the customer. Based on our experience in recent years, the majority of these retainage balances are expected to be collected within approximately twelve months. As of December 31, 2024 and September 30, 2024, we had retention amounts of $7.5 million and $7.1 million, respectively. Of the retained amount at December 31, 2024, $6.7 million is expected to be collected in the next twelve months and is recorded in accounts receivable. The remaining $0.8 million is recorded in other assets.
  (was, 2024-07-31, similarity 0.9889):
[0000080420-24-000059:note_history:37]
The timing of our invoice process is typically dependent on the completion of certain milestones and contract terms and subject to agreement by our customer. Payment is typically expected within 30 days of invoice. Any uncollected invoiced amounts for our performance obligations recognized over time, including contract retentions, are recorded as accounts receivable in the Condensed Consolidated Balance Sheets. Certain contracts allow customers to withhold a small percentage of billings pursuant to retainage provisions, and such amounts are generally due upon completion of the contract and acceptance of the project by the customer. Based on our experience in recent years, the majority of these retainage balances are expected to be collected within approximately twelve months. As of June 30, 2024 and September 30, 2023, we had retention amounts of $6.6 million and $7.4 million, respectively. Of the retained amount at June 30, 2024, $5.9 million is expected to be collected in the next twelve months and is recorded in accounts receivable. The remaining $0.7 million is recorded in other assets.

- changed (2025-02-07):
[0000080420-25-000029:note_history:38]
The following tables present our disaggregated revenue by geographic destination and market sector for the three months ended December 31, 2024 and 2023 (in thousands):
  (was, 2024-07-31, similarity 0.9415):
[0000080420-24-000059:note_history:38]
The following tables present our disaggregated revenue by geographic destination and market sector for the three and nine months ended June 30, 2024 and 2023 (in thousands):

- changed (2025-02-07):
[0000080420-25-000029:note_history:39]
|  | Three months ended December 31, |  |  |
|  | 2024 |  | 2023 |  |  |  |  |
| United States | $ | 197,772 |  |  | $ | 159,860 |  |  |  |  |  |
| Canada | 31,694 |  |  | 20,350 |  |  |  |  |  |
| Europe | 5,528 |  |  | 6,532 |  |  |  |  |  |
| Middle East and Africa | 4,558 |  |  | 3,275 |  |  |  |  |  |
| Mexico, Central and South America | 299 |  |  | 2,657 |  |  |  |  |  |
| Asia/Pacific | 1,580 |  |  | 1,343 |  |  |  |  |  |
| Total revenues by geographic destination | $ | 241,431 |  |  | $ | 194,017 |  |  |  |  |  |
  (was, 2024-07-31, similarity 0.6159):
[0000080420-24-000059:note_history:39]
|  | Three months ended June 30, |  | Nine months ended June 30, |
|  | 2024 |  | 2023 |  | 2024 |  | 2023 |
| United States | $ | 243,744 |  |  | $ | 153,258 |  |  | $ | 620,537 |  |  | $ | 387,531 |  |
| Canada | 29,695 |  |  | 21,765 |  |  | 74,205 |  |  | 62,255 |  |
| Europe | 9,464 |  |  | 8,038 |  |  | 24,261 |  |  | 20,125 |  |
| Middle East and Africa | 2,322 |  |  | 3,966 |  |  | 8,400 |  |  | 10,396 |  |
| Mexico, Central and South America | 1,962 |  |  | 3,000 |  |  | 6,778 |  |  | 5,457 |  |
| Asia/Pacific | 981 |  |  | 2,338 |  |  | 3,112 |  |  | 4,903 |  |
| Total revenues by geographic destination | $ | 288,168 |  |  | $ | 192,365 |  |  | $ | 737,293 |  |  | $ | 490,667 |  |

- changed (2025-02-07):
[0000080420-25-000029:note_history:40]
|  | Three months ended December 31, |  |  |
|  | 2024 |  | 2023 |  |  |  |  |
| Oil and gas (excludes petrochemical) | $ | 95,679 |  |  | $ | 83,636 |  |  |  |  |  |
| Petrochemical | 33,183 |  |  | 28,367 |  |  |  |  |  |
| Electric utility | 51,240 |  |  | 40,703 |  |  |  |  |  |
| Commercial and other industrial | 44,300 |  |  | 24,672 |  |  |  |  |  |
| Light rail traction power | 8,228 |  |  | 4,345 |  |  |  |  |  |
| All others | 8,801 |  |  | 12,294 |  |  |  |  |  |
| Total revenues by market sector | $ | 241,431 |  |  | $ | 194,017 |  |  |  |  |  |
  (was, 2024-07-31, similarity 0.724):
[0000080420-24-000059:note_history:40]
|  | Three months ended June 30, |  | Nine months ended June 30, |
|  | 2024 |  | 2023 |  | 2024 |  | 2023 |
| Oil and gas (excludes petrochemical) | $ | 114,336 |  |  | $ | 73,452 |  |  | $ | 301,792 |  |  | $ | 179,560 |  |
| Petrochemical | 56,784 |  |  | 21,995 |  |  | 135,221 |  |  | 70,372 |  |
| Electric utility | 57,009 |  |  | 43,824 |  |  | 145,214 |  |  | 114,899 |  |
| Commercial and other industrial | 42,044 |  |  | 35,527 |  |  | 101,610 |  |  | 74,846 |  |
| Light rail traction power | 5,322 |  |  | 7,143 |  |  | 14,184 |  |  | 21,532 |  |
| All others | 12,673 |  |  | 10,424 |  |  | 39,272 |  |  | 29,458 |  |
| Total revenues by market sector | $ | 288,168 |  |  | $ | 192,365 |  |  | $ | 737,293 |  |  | $ | 490,667 |  |


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: tag_name, score: 1.0

- changed (2025-02-07):
[0000080420-25-000029:note_history:41]
Subsequent Events
Quarterly Dividend Declared
  (was, 2024-07-31, similarity 0.75):
[0000080420-24-000059:note_history:41]
Quarterly Dividend Declared

- added (2025-02-07):
[0000080420-25-000029:note_history:42]
On February 4, 2025, our Board of Directors approved an increase to the quarterly cash dividend on our common stock to $0.2675 per share, equating to an annualized dividend of $1.07 per share from the current amount of $1.06 per share. The dividend is payable on March 19, 2025 to shareholders of record at the close of business on February 19, 2025.

- removed (2025-02-07):
[0000080420-24-000059:note_history:43]
Subsequent Events
Cash Acquisition of Property, Plant and Equipment

- removed (2025-02-07):
[0000080420-24-000059:note_history:44]
On July 1, 2024, we acquired land and buildings in Houston, Texas, for a total cash purchase price of approximately $5.5 million to help further facilitate executing the current backlog as well as planning for modest future volume growth.

- removed (2025-02-07):
[0000080420-24-000059:note_history:45]
Hurricane Beryl

- removed (2025-02-07):
[0000080420-24-000059:note_history:46]
During the second week of July 2024, operations across our three facilities located in Houston, Texas, experienced a temporary power outage and subsequent shutdown of our operations resulting from Hurricane Beryl. These facilities resumed limited operations within the same week. We are evaluating the potential financial impact, if any, associated with this event.

- removed (2025-02-07):
[0000080420-24-000059:note_history:47]
On July 30, 2024, our Board of Directors declared a quarterly cash dividend on our common stock in the amount of $0.2650 per share. The dividend is payable on September 18, 2024 to stockholders of record at the close of business on August 14, 2024.
