# POWL MD&A — 0000080420-25-000029


## mdna

[0000080420-25-000029:mdna:1]
[same as prior period, unchanged from 0000080420-24-000059:mdna:1]

[0000080420-25-000029:mdna:2]
The following discussion and analysis of our financial condition and results of operations should be read in conjunction with the accompanying condensed consolidated financial statements and related notes included in this Quarterly Report on Form 10-Q and with our Annual Report on Form 10-K for the fiscal year ended September 30, 2024, which was filed with the SEC on November 20, 2024 and is available on the SEC’s website at www.sec.gov.

[0000080420-25-000029:mdna:3]
Executive Overview

[0000080420-25-000029:mdna:4]
We develop, design, manufacture and service custom-engineered equipment and systems that distribute, control and monitor the flow of electrical energy and provide protection to motors, transformers and other electrically powered equipment. We are headquartered in Houston, Texas and primarily serve the oil and gas and petrochemical markets, the electric utility market, and commercial and other industrial markets. Beyond these major markets, we also provide products and services to the light rail traction power market and other markets that include universities and government entities. We are continuously developing new channels to electrical markets through original equipment manufacturers and distribution market channels.

[0000080420-25-000029:mdna:5]
In the first quarter of Fiscal 2025, we reported revenues of $241.4 million, net income of $34.8 million, and generated $37.1 million in cash from operating activities. As of December 31, 2024, we had total assets of $912.7 million.

[0000080420-25-000029:mdna:6]
[same as prior period, unchanged from 0000080420-24-000059:mdna:37]

[0000080420-25-000029:mdna:7]
Our backlog remained at $1.3 billion as of December 31, 2024, of which approximately $893 million is expected to be recognized as revenue within the next twelve months. Although current commercial activity remains active in most of the markets that we compete in, we remain attentive to the macro environment and geopolitical events that may have an impact on future market activity.

[0000080420-25-000029:mdna:8]
Oil and gas and petrochemical markets. The North American market is responding to increased international demand for Liquefied Natural Gas (LNG) and gas-to-chemical processes utilizing low-cost gas feedstocks. We believe the fundamentals of the U.S. natural gas market, through abundant supply and low cost, will continue to support investments in LNG, related gas processing, and petrochemical processes, and as a result, will continue to sustain our order activity associated with such markets, which is evidenced by a large, domestic LNG project award during the current quarter. In addition to the traditional crude oil refining and other oil and gas downstream processes, we have recently expanded our end markets into hydrogen production, carbon capture as well as alternative fuels, such as biofuels and sustainable aviation fuel, in response to the demand for clean energy.

[0000080420-25-000029:mdna:9]
Electric utility market. Aligned with our strategy of end-market diversification, we seek to continue our focus and growth in electrical distribution substations, while also addressing a resurgence of power generation investment in this market.

[0000080420-25-000029:mdna:10]
Commercial and other industrial markets. We have experienced strong growth in these end markets driven by a mix of factors including increased investment in commercial and light industrial facilities for the production of various goods, the expansion of data centers and cloud computing, as well as the growing demand in industrial applications to support new technologies driving the energy transition. We are cautiously optimistic regarding the anticipated investment across AI applications that may drive data center growth and subsequently power generation demand.

[0000080420-25-000029:mdna:11]
Business Environment

[0000080420-25-000029:mdna:12]
[same as prior period, unchanged from 0000080420-24-000059:mdna:5]

[0000080420-25-000029:mdna:13]
Our operating results are impacted by several factors such as the timing of new order awards, project backlog, changes in project cost estimates, customer approval of final engineering specifications and delays in customer construction schedules, all of which contribute to short-term earnings variability and the timing of project execution. Our operating results also have been, and may continue to be, impacted by the timing and resolution of change orders and the resolution of potential contract claims and liquidated damages, all of which could improve or deteriorate gross margins during the period in which these items are resolved with our customers. Disruptions in the global supply chain have negatively impacted and may continue to negatively impact our business and operating results due to the limited supply of, delays for and uncertainty in the timing of the receipt of

[0000080420-25-000029:mdna:14]
key component parts and commodities. We continue to remain focused on the variables that impact our markets as well as cost management, labor availability and supply chain challenges.

[0000080420-25-000029:mdna:15]
We are subject to inflation, which can cause increases in our costs of labor, indirect expenses and raw materials, primarily copper, aluminum and steel. Fixed-price contracts can limit our ability to pass these increases to our customers, thus negatively impacting our earnings and operations in future periods.

[0000080420-25-000029:mdna:16]
During the first quarter of Fiscal 2025, we experienced an increase in volatility for commodity prices, in addition to ongoing supply chain delays for specific engineered components that remain a persistent challenge. In response to the rising cost environment and persistent supply chain challenges, we are taking strategic measures to effectively manage our product pricing, refine delivery schedules, and manage bid validity dates with our customers.  Our supplier engagement includes improving forecasting and negotiating favorable terms that allow us to meet or exceed customer timelines. Additionally, we remain focused on enhancing factory efficiencies and improving project execution to mitigate risks and maintain customer satisfaction.

[0000080420-25-000029:mdna:17]
[same as prior period, unchanged from 0000080420-24-000059:mdna:10]

[0000080420-25-000029:mdna:18]
Quarter Ended December 31, 2024 Compared to the Quarter Ended December 31, 2023 (Unaudited)

[0000080420-25-000029:mdna:19]
[same as prior period, unchanged from 0000080420-24-000059:mdna:12]

[0000080420-25-000029:mdna:20]
Revenues increased by 24%, or $47.4 million, to $241.4 million in the first quarter of Fiscal 2025, primarily driven by strong project backlog at the end of Fiscal 2024 and strong bookings that continued in the first quarter of Fiscal 2025. Domestic revenues increased by 24%, or $37.9 million, to $197.8 million in the first quarter of Fiscal 2025. International revenues increased by 28%, or $9.5 million, to $43.6 million in the first quarter of Fiscal 2025, primarily driven by increased project volume from our Canada operations. Our international revenues include both revenues generated from our international facilities as well as revenues from export projects generated at our domestic facilities.

[0000080420-25-000029:mdna:21]
In the first quarter of Fiscal 2025, revenue from our oil and gas market (excluding petrochemical) increased by 14%, or $12.0 million, to $95.7 million; petrochemical market revenue increased by 17%, or $4.8 million, to $33.2 million; revenue from our electric utility market increased by 26%, or $10.5 million, to $51.2 million; commercial and other industrial market revenue increased by 80%, or $19.6 million, to $44.3 million; and revenue from our light rail traction power market increased by 89%, or $3.9 million, to $8.2 million. These increases in revenue were driven by improved market conditions in our end markets, increased capital spending in our core oil, gas and petrochemical markets, as well as our strategic effort to expand our business into electric utility and commercial and other industrial markets. Revenue from all other markets combined decreased by 28%, or $3.5 million, to $8.8 million in the first quarter of Fiscal 2025 due to less project volume.

[0000080420-25-000029:mdna:22]
Gross profit increased by 24%, or $11.3 million, to $59.5 million for the first quarter of Fiscal 2025. Gross profit as a percentage of revenues remained flat at 25% in the first quarter of Fiscal 2025, as compared to the first quarter of Fiscal 2024. The increase in gross profit was primarily driven by higher revenues in the first quarter of Fiscal 2025.

[0000080420-25-000029:mdna:23]
[same as prior period, unchanged from 0000080420-24-000059:mdna:16]

[0000080420-25-000029:mdna:24]
Selling, general and administrative expenses increased by 6%, or $1.1 million, to $21.5 million in the first quarter of Fiscal 2025, primarily due to increased compensation expense. Selling, general and administrative expenses as a percentage of revenues decreased to 9% during the first quarter of Fiscal 2025, compared to 10% during the first quarter of Fiscal 2024, resulting from higher revenues on our existing cost structure.

[0000080420-25-000029:mdna:25]
[same as prior period, unchanged from 0000080420-24-000059:mdna:18]

[0000080420-25-000029:mdna:26]
We recorded an income tax provision of $4.7 million in the first quarter of Fiscal 2025, compared to an income tax provision of $5.8 million in the first quarter of Fiscal 2024. The effective tax rate for the first quarter of Fiscal 2025 was 12%, compared to an effective tax rate of 19% for the first quarter of Fiscal 2024. For each of the three months ended December 31, 2024 and 2023, the effective tax rate was favorably impacted by discrete items related to the vesting of restricted stock units (RSUs) and the estimated Research and Development (R&D) Tax Credit. The decreased effective tax rate for the first quarter of Fiscal 2025 was primarily driven by higher stock prices associated with the vested RSUs. For further information regarding our income taxes, see Note J of Notes to Condensed Consolidated Financial Statements.

[0000080420-25-000029:mdna:27]
[same as prior period, unchanged from 0000080420-24-000059:mdna:20]

[0000080420-25-000029:mdna:28]
In the first quarter of Fiscal 2025, we recorded net income of $34.8 million, or $2.86 per diluted share, compared to net income of $24.1 million, or $1.98 per diluted share, in the first quarter of Fiscal 2024. The increase in net income was primarily driven by higher revenues in the current quarter.

[0000080420-25-000029:mdna:29]
[same as prior period, unchanged from 0000080420-24-000059:mdna:22]

[0000080420-25-000029:mdna:30]
The order backlog, which is our remaining unsatisfied performance obligations, represents the estimated transaction price for goods and services for which we have a material right, but work has not been performed. The order backlog at December 31, 2024 was $1.3 billion, consistent with our backlog at September 30, 2024. Bookings, net of cancellations and scope reductions, increased by 36% in the first quarter of Fiscal 2025 to $268.6 million, compared to $197.5 million in the first quarter of Fiscal 2024.

[0000080420-25-000029:mdna:31]
[same as prior period, unchanged from 0000080420-24-000059:mdna:41]

[0000080420-25-000029:mdna:32]
As of December 31, 2024, current assets exceeded current liabilities by 1.9 times.

[0000080420-25-000029:mdna:33]
Cash, cash equivalents and short-term investments increased to $373.4 million at December 31, 2024, compared to $358.4 million at September 30, 2024. The increase in cash, cash equivalents and short-term investments was primarily driven by our improved earnings due to higher revenues, partially offset by capital spending, dividend payments, and cash payments related to shares withheld in lieu of employee tax withholding. We believe that our cash, cash equivalents and short-term investments, as well as available borrowings under our U.S. credit facility, will be sufficient to support our future operating activities, working capital requirements, payment of dividends and capital spending, as well as research and development initiatives for the next twelve months and beyond.

[0000080420-25-000029:mdna:34]
Approximately $65.1 million of our cash, cash equivalents and short-term investments at December 31, 2024 was held outside of the U.S. for our international operations. It is our intention to indefinitely reinvest all current and future foreign earnings internationally in order to ensure sufficient working capital to support our international operations. In the event that we elect to repatriate some or all of the foreign earnings that were previously deemed to be indefinitely reinvested outside the U.S., we may incur additional tax expense upon such repatriation under current tax laws.

[0000080420-25-000029:mdna:35]
U.S. Revolver

[0000080420-25-000029:mdna:36]
We have a credit agreement with Bank of America, N.A. and Texas Capital Bank with an aggregate commitment of $150.0 million, consisting of $100.0 million committed by Bank of America and $50.0 million committed by Texas Capital Bank (the U.S. Revolver). The U.S. Revolver has an expiration date of October 4, 2028.

[0000080420-25-000029:mdna:37]
As of December 31, 2024, there were no amounts borrowed under the U.S. Revolver, and letters of credit outstanding were $56.1 million. There was $93.9 million available for the issuance of letters of credit and borrowings under the U.S. Revolver as of December 31, 2024. For further information regarding our debt, see Notes E and F of Notes to Condensed Consolidated Financial Statements.

[0000080420-25-000029:mdna:38]
Cash Flows

[0000080420-25-000029:mdna:39]
[same as prior period, unchanged from 0000080420-24-000059:mdna:48]

[0000080420-25-000029:mdna:40]
Operating activities provided net cash of $37.1 million during the three months ended December 31, 2024 and provided net cash of $83.9 million during the same period in Fiscal 2024. Cash flow from operations is primarily influenced by project volume and margins, as well as working capital requirements, the timing of milestone payments from our customers, and payment terms with our suppliers. The decrease in operating cash flow was primarily due to working capital impact as we allocate capital to projects in the order book, partially offset by improved net income driven by higher revenues.

[0000080420-25-000029:mdna:41]
[same as prior period, unchanged from 0000080420-24-000059:mdna:50]

[0000080420-25-000029:mdna:42]
Investing activities used $9.5 million of cash during the three months ended December 31, 2024 and used $1.5 million of cash during the same period in Fiscal 2024. The increase in cash used in investing activities in the first quarter of Fiscal 2025 was primarily due to increased net purchases of short-term investments and higher capital spending. During the first quarter of

[0000080420-25-000029:mdna:43]
Fiscal 2024, we acquired intellectual property for a total consideration of $0.5 million, of which $250 thousand was paid in cash.

[0000080420-25-000029:mdna:44]
[same as prior period, unchanged from 0000080420-24-000059:mdna:52]

[0000080420-25-000029:mdna:45]
Net cash used in financing activities was $15.2 million during the three months ended December 31, 2024 compared to $7.9 million used during the same period in Fiscal 2024. The increase in cash used in financing activities was primarily due to cash payments related to shares withheld in lieu of employee tax withholding, largely driven by the significant increase in our share price in the first three months of Fiscal 2025 compared to the same period of Fiscal 2024.

[0000080420-25-000029:mdna:46]
Capital Expenditure Requirements

[0000080420-25-000029:mdna:47]
We have planned capital spending of approximately $11 million on a facility expansion and improvement project at our products factory in Houston. We are on schedule to complete the expansion project by mid-Fiscal 2025.

[0000080420-25-000029:mdna:48]
[same as prior period, unchanged from 0000080420-24-000059:mdna:54]

[0000080420-25-000029:mdna:49]
[same as prior period, unchanged from 0000080420-24-000059:mdna:55]

[0000080420-25-000029:mdna:50]
There have been no material changes to our critical accounting policies as disclosed in our Annual Report on Form 10-K for the fiscal year ended September 30, 2024, which was filed with the SEC on November 20, 2024.
