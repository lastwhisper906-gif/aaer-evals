# POWL notes — 0000080420-25-000029


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureAndSignificantAccountingPoliciesTextBlock

[0000080420-25-000029:notes:1]
[same as prior period, unchanged from 0000080420-24-000059:notes:1]

[0000080420-25-000029:notes:2]
Powell Industries, Inc. (we, us, our, Powell or the Company) is a Delaware corporation founded by William E. Powell in 1947. We develop, design, manufacture and service custom-engineered equipment and systems that distribute, control and monitor the flow of electrical energy and provide protection to motors, transformers and other electrically powered equipment. Our major subsidiaries, all of which are wholly owned, include Powell Electrical Systems, Inc.; Powell Canada Inc.; Powell (UK) Limited; and Powell Industries International, B.V.

[0000080420-25-000029:notes:3]
We are headquartered in Houston, Texas and primarily serve the oil and gas and petrochemical markets, the electric utility market, and commercial and other industrial markets. Beyond these major markets, we also provide products and services to the light rail traction power market and other markets that include universities and government entities. We are continuously developing new channels to electrical markets through original equipment manufacturers and distribution market channels.

[0000080420-25-000029:notes:4]
[same as prior period, unchanged from 0000080420-24-000059:notes:4]

[0000080420-25-000029:notes:5]
[same as prior period, unchanged from 0000080420-24-000059:notes:5]

[0000080420-25-000029:notes:6]
[same as prior period, unchanged from 0000080420-24-000059:notes:6]

[0000080420-25-000029:notes:7]
The unaudited condensed consolidated financial statements should be read in conjunction with the audited consolidated financial statements and notes thereto of Powell and its subsidiaries included in Powell’s Annual Report on Form 10-K for the year ended September 30, 2024, which was filed with the Securities and Exchange Commission (SEC) on November 20, 2024.

[0000080420-25-000029:notes:8]
References to Fiscal 2025 and Fiscal 2024 used throughout this report shall mean the current fiscal year ending September 30, 2025 and the prior fiscal year ended September 30, 2024, respectively.

[0000080420-25-000029:notes:9]
[same as prior period, unchanged from 0000080420-24-000059:notes:9]

[0000080420-25-000029:notes:10]
[same as prior period, unchanged from 0000080420-24-000059:notes:10]

[0000080420-25-000029:notes:11]
[same as prior period, unchanged from 0000080420-24-000059:notes:11]

[0000080420-25-000029:notes:12]
In November 2023, the Financial Accounting Standard Board (FASB) issued Accounting Standards Update (ASU) 2023-07,

[0000080420-25-000029:notes:13]
Segment Reporting (Topic 280): Improvements to Reportable Segment Disclosures, which requires that public entities disclose significant segment expenses that are regularly provided to the chief operating decision maker (CODM) on an annual and interim basis. It also requires that public entities disclose the title and position of the CODM and an explanation of how the CODM uses the reported measures in assessing segment performance and resource allocation. Additionally, it requires that all existing annual disclosures about segment profit or loss and assets must be provided on an interim basis and clarifies that single reportable segment entities are subject to the disclosure requirement under Topic 280 in its entirety. ASU 2023-07 is effective for fiscal years beginning after December 15, 2023 and interim periods within fiscal years beginning after December 15, 2024. A public entity should apply ASU 2023-07 retrospectively to all prior periods presented in the financial statements. Early adoption is permitted. We are currently evaluating the impacts of the new standard.

[0000080420-25-000029:notes:14]
In December 2023, the FASB issued ASU 2023-09, Improvements to Income Tax Disclosures, which enhances the transparency of income tax disclosures. It requires greater disaggregation of information in the tax rate reconciliation and income taxes paid disaggregated by jurisdiction. This ASU is effective for fiscal years beginning after December 15, 2024, and should be applied on a prospective basis. Retrospective application and early adoption are permitted. We are currently evaluating the impacts of the new standard.

[0000080420-25-000029:notes:15]
In March 2024, the SEC adopted final rules designed to enhance and standardize disclosures related to the risks and impacts of climate-related matters. The final rules require registrants to disclose certain climate-related information in registration statements and annual reports. Such information relates to climate-related risks and risk management processes for, and governance and oversight activities of, such risks. The final rules also include requirements to disclose the financial effects of severe weather events and other natural conditions in the audited financial statements. In addition, larger registrants will be required to disclose information about greenhouse gas emissions, which will be subject to a phased-in assurance requirement. These disclosure requirements were scheduled to be effective for the Company's fiscal year beginning October 1, 2025. However, in April 2024, the SEC voluntarily stayed the final rules as a result of pending legal challenges. We are currently evaluating the impacts of the final rules on our consolidated financial statements and related disclosures.

[0000080420-25-000029:notes:16]
In November 2024, the FASB issued ASU No. 2024-03, Reporting Comprehensive Income – Expense Disaggregation Disclosures, which requires additional qualitative and quantitative information about specific expense categories in the notes to financial statements for both interim and annual reporting periods. In January 2025, the FASB further clarified the effective date for interim reporting periods. This ASU is effective for fiscal years beginning after December 15, 2026 and interim periods within those fiscal years beginning after December 15, 2027, with early adoption permitted. We are currently evaluating the impacts of the new standard.


## us-gaap:EarningsPerShareTextBlock

[0000080420-25-000029:notes:17]
[same as prior period, unchanged from 0000080420-24-000059:notes:15]

[0000080420-25-000029:notes:18]
[same as prior period, unchanged from 0000080420-24-000059:notes:16]

[0000080420-25-000029:notes:19]
|  | Three months ended December 31, |  |  |
|  | 2024 |  | 2023 |  |  |  |  |
| Numerator: |  |  |  |  |  |  |  |
| Net income | $ | 34,763 |  |  | $ | 24,085 |  |  |  |  |  |
| Denominator: |  |  |  |  |  |  |  |
| Weighted average basic shares | 12,037 |  |  | 11,941 |  |  |  |  |  |
| Dilutive effect of restricted stock and restricted stock units | 115 |  |  | 233 |  |  |  |  |  |
| Weighted average diluted shares | 12,152 |  |  | 12,174 |  |  |  |  |  |
| Earnings per share: |  |  |  |  |  |  |  |
| Basic | $ | 2.89 |  |  | $ | 2.02 |  |  |  |  |  |
| Diluted | $ | 2.86 |  |  | $ | 1.98 |  |  |  |  |  |


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0000080420-25-000029:notes:20]
[same as prior period, unchanged from 0000080420-24-000059:notes:18]

[0000080420-25-000029:notes:21]
[same as prior period, unchanged from 0000080420-24-000059:notes:19]

[0000080420-25-000029:notes:22]
|  | December 31, 2024 |  | September 30, 2024 |
| Raw materials, parts and sub-assemblies | $ | 94,785 |  |  | $ | 92,314 |  |
| Work-in-progress | 1,163 |  |  | 920 |  |
| Provision for excess and obsolete inventories | (7,840) |  |  | (7,361) |  |
| Total inventories | $ | 88,108 |  |  | $ | 85,873 |  |

[0000080420-25-000029:notes:23]
[same as prior period, unchanged from 0000080420-24-000059:notes:21]

[0000080420-25-000029:notes:24]
[same as prior period, unchanged from 0000080420-24-000059:notes:22]

[0000080420-25-000029:notes:25]
|  | December 31, 2024 |  | September 30, 2024 |  |  |  |  |
| Land | $ | 23,684 |  |  | $ | 24,110 |  |  |  |  |  |
| Buildings and improvements | 124,474 |  |  | 127,094 |  |  |  |  |  |
| Machinery and equipment | 93,923 |  |  | 94,889 |  |  |  |  |  |
| Furniture and fixtures | 2,828 |  |  | 2,885 |  |  |  |  |  |
| Construction in process | 5,816 |  |  | 3,317 |  |  |  |  |  |
|  | $ | 250,725 |  |  | $ | 252,295 |  |  |  |  |  |
| Less: Accumulated depreciation | (148,768) |  |  | (148,874) |  |  |  |  |  |
| Total property, plant and equipment, net | $ | 101,957 |  |  | $ | 103,421 |  |  |  |  |  |

[0000080420-25-000029:notes:26]
There were no assets under finance lease as of December 31, 2024 or September 30, 2024.

[0000080420-25-000029:notes:27]
[same as prior period, unchanged from 0000080420-24-000059:notes:27]

[0000080420-25-000029:notes:28]
[same as prior period, unchanged from 0000080420-24-000059:notes:28]

[0000080420-25-000029:notes:29]
|  | Three months ended December 31, |  |  |
|  | 2024 |  | 2023 |  |  |  |  |
| Balance at beginning of period | $ | 5,822 |  |  | $ | 3,305 |  |  |  |  |  |
| Increase to warranty expense | 1,497 |  |  | 1,127 |  |  |  |  |  |
| Deduction for warranty charges | (1,149) |  |  | (774) |  |  |  |  |  |
| Change due to foreign currency translation | (64) |  |  | 22 |  |  |  |  |  |
| Balance at end of period | $ | 6,106 |  |  | $ | 3,680 |  |  |  |  |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0000080420-25-000029:notes:30]
[same as prior period, unchanged from 0000080420-24-000059:notes:30]

[0000080420-25-000029:notes:31]
Our revenues are primarily generated from the manufacturing of custom-engineered products and systems under long-term, fixed-price contracts under which we agree to manufacture various products such as traditional and arc-resistant distribution switchgear and control gear, medium-voltage circuit breakers, monitoring and control communications systems, motor control centers, switches and bus duct systems. These products may be sold separately as an engineered solution but are typically integrated into custom-built enclosures which we also build. These enclosures are referred to as power control room substations (PCRs®), custom-engineered modules or electrical houses (E-Houses). Some contracts may also include the installation and the commissioning of these enclosures.

[0000080420-25-000029:notes:32]
[same as prior period, unchanged from 0000080420-24-000059:notes:32]

[0000080420-25-000029:notes:33]
We also have contracts to provide field service inspection, installation, commissioning, modification, and repair services, as well as retrofit and retrofill components for existing systems. If the service contract terms give us the right to invoice the customer for an amount that corresponds directly with the value of our performance completed to date (i.e., a service contract in which we bill a fixed amount for each hour of service provided), then we recognize revenue over time in each reporting period corresponding to the amount that we have the right to invoice. Our performance obligations are satisfied as the work progresses. Revenues from our custom-engineered products and value-added services transferred to customers over time accounted for approximately 97% and 94% of revenues for the three months ended December 31, 2024 and December 31, 2023, respectively.

[0000080420-25-000029:notes:34]
We also have sales orders for spare parts and replacement circuit breakers for switchgear that are obsolete or that are no longer produced by the original manufacturer. Revenues from these sales orders are recognized at the time we fulfill our performance obligation to the customer, which is typically upon shipment and represented approximately 3% and 6% of revenues for the three months ended December 31, 2024 and December 31, 2023, respectively.

[0000080420-25-000029:notes:35]
[same as prior period, unchanged from 0000080420-24-000059:notes:35]

[0000080420-25-000029:notes:36]
Selling and administrative costs incurred in relation to obtaining a contract are typically expensed as incurred. We periodically utilize a third-party sales agent to obtain a contract and will pay a commission to that agent. We record the full commission liability to the third-party sales agents at the order date, with a corresponding deferred asset. As the project progresses, we record commission expense based on percentage of completion rates that correlate to the project and reduce the deferred asset. Once we have been paid by the customer, we pay the commission and the liability is reduced.

[0000080420-25-000029:notes:37]
[same as prior period, unchanged from 0000080420-24-000059:notes:37]

[0000080420-25-000029:notes:38]
[same as prior period, unchanged from 0000080420-24-000059:notes:38]

[0000080420-25-000029:notes:39]
Remaining unsatisfied performance obligations, which we refer to as backlog, represent the estimated transaction price for goods and services for which we have a material right, but work has not been performed. As of December 31, 2024, we had backlog of $1.3 billion, of which approximately $893 million is expected to be recognized as revenue within the next twelve months. Backlog may not be indicative of future operating results as orders may be cancelled or modified by our customers.

[0000080420-25-000029:notes:40]
Our backlog does not include service and maintenance-type contracts for which we have the right to invoice as services are performed.

[0000080420-25-000029:notes:41]
[same as prior period, unchanged from 0000080420-24-000059:notes:41]

[0000080420-25-000029:notes:42]
[same as prior period, unchanged from 0000080420-24-000059:notes:42]

[0000080420-25-000029:notes:43]
For the three months ended December 31, 2024 and 2023, our operating results were positively impacted by $2.4 million and $5.4 million, respectively, as a result of net changes in contract estimates related to projects in progress at the beginning of the respective period. These changes in estimates resulted primarily from favorable project execution, reduced cost estimates and negotiations of variable consideration, discussed below, as well as revenue recognized from project cancellations and other changes in facts and circumstances during these periods. Gross unfavorable changes in contract estimates were immaterial for both the three months ended December 31, 2024 and 2023.

[0000080420-25-000029:notes:44]
[same as prior period, unchanged from 0000080420-24-000059:notes:44]

[0000080420-25-000029:notes:45]
[same as prior period, unchanged from 0000080420-24-000059:notes:45]

[0000080420-25-000029:notes:46]
[same as prior period, unchanged from 0000080420-24-000059:notes:46]

[0000080420-25-000029:notes:47]
[same as prior period, unchanged from 0000080420-24-000059:notes:47]

[0000080420-25-000029:notes:48]
[same as prior period, unchanged from 0000080420-24-000059:notes:48]

[0000080420-25-000029:notes:49]
[same as prior period, unchanged from 0000080420-24-000059:notes:49]

[0000080420-25-000029:notes:50]
[same as prior period, unchanged from 0000080420-24-000059:notes:50]

[0000080420-25-000029:notes:51]
[same as prior period, unchanged from 0000080420-24-000059:notes:51]

[0000080420-25-000029:notes:52]
[same as prior period, unchanged from 0000080420-24-000059:notes:52]

[0000080420-25-000029:notes:53]
Contract assets and liabilities as of December 31, 2024 and September 30, 2024 are summarized below (in thousands):

[0000080420-25-000029:notes:54]
|  | December 31, 2024 |  | September 30, 2024 |
| Contract assets | $ | 92,349 |  |  | $ | 102,827 |  |
| Contract liabilities | (282,595) |  |  | (287,763) |  |
| Net contract liability | $ | (190,246) |  |  | $ | (184,936) |  |

[0000080420-25-000029:notes:55]
Our net contract billing position remained a net liability at both December 31, 2024 and September 30, 2024, primarily due to favorable contract billing milestones. We typically allocate a significant percentage of the progress billing to the early stages of the contract. To determine the amount of revenue recognized during the period from contract liabilities, we first allocate revenue to the individual contract liability balance outstanding at the beginning of the period until the revenue exceeds that balance. During the three months ended December 31, 2024, we recognized revenue of $116.9 million that was related to contract liabilities outstanding at September 30, 2024.

[0000080420-25-000029:notes:56]
The timing of our invoice process is typically dependent on the completion of certain milestones and contract terms and subject to agreement by our customer. Payment is typically expected within 30 days of invoice. Any uncollected invoiced amounts for our performance obligations recognized over time, including contract retentions, are recorded as accounts receivable in the Condensed Consolidated Balance Sheets. Certain contracts allow customers to withhold a small percentage of billings pursuant to retainage provisions, and such amounts are generally due upon completion of the contract and acceptance of the project by the customer. Based on our experience in recent years, the majority of these retainage balances are expected to be collected within approximately twelve months. As of December 31, 2024 and September 30, 2024, we had retention amounts of $7.5 million and $7.1 million, respectively. Of the retained amount at December 31, 2024, $6.7 million is expected to be collected in the next twelve months and is recorded in accounts receivable. The remaining $0.8 million is recorded in other assets.

[0000080420-25-000029:notes:57]
[same as prior period, unchanged from 0000080420-24-000059:notes:57]

[0000080420-25-000029:notes:58]
The following tables present our disaggregated revenue by geographic destination and market sector for the three months ended December 31, 2024 and 2023 (in thousands):

[0000080420-25-000029:notes:59]
|  | Three months ended December 31, |  |  |
|  | 2024 |  | 2023 |  |  |  |  |
| United States | $ | 197,772 |  |  | $ | 159,860 |  |  |  |  |  |
| Canada | 31,694 |  |  | 20,350 |  |  |  |  |  |
| Europe | 5,528 |  |  | 6,532 |  |  |  |  |  |
| Middle East and Africa | 4,558 |  |  | 3,275 |  |  |  |  |  |
| Mexico, Central and South America | 299 |  |  | 2,657 |  |  |  |  |  |
| Asia/Pacific | 1,580 |  |  | 1,343 |  |  |  |  |  |
| Total revenues by geographic destination | $ | 241,431 |  |  | $ | 194,017 |  |  |  |  |  |

[0000080420-25-000029:notes:60]
|  | Three months ended December 31, |  |  |
|  | 2024 |  | 2023 |  |  |  |  |
| Oil and gas (excludes petrochemical) | $ | 95,679 |  |  | $ | 83,636 |  |  |  |  |  |
| Petrochemical | 33,183 |  |  | 28,367 |  |  |  |  |  |
| Electric utility | 51,240 |  |  | 40,703 |  |  |  |  |  |
| Commercial and other industrial | 44,300 |  |  | 24,672 |  |  |  |  |  |
| Light rail traction power | 8,228 |  |  | 4,345 |  |  |  |  |  |
| All others | 8,801 |  |  | 12,294 |  |  |  |  |  |
| Total revenues by market sector | $ | 241,431 |  |  | $ | 194,017 |  |  |  |  |  |


## us-gaap:RevenueFromContractWithCustomerPolicyTextBlock

[0000080420-25-000029:notes:61]
[same as prior period, unchanged from 0000080420-24-000059:notes:61]

[0000080420-25-000029:notes:62]
Additionally, some contracts may contain a cancellation clause that could limit the amount of revenue we are able to recognize over time. In these instances, revenue and costs associated with these contracts are deferred and recognized at a point in time when the performance obligation is fulfilled.
Selling and administrative costs incurred in relation to obtaining a contract are typically expensed as incurred. We periodically utilize a third-party sales agent to obtain a contract and will pay a commission to that agent. We record the full commission liability to the third-party sales agents at the order date, with a corresponding deferred asset. As the project progresses, we record commission expense based on percentage of completion rates that correlate to the project and reduce the deferred asset. Once we have been paid by the customer, we pay the commission and the liability is reduced
Performance Obligations

[0000080420-25-000029:notes:63]
[same as prior period, unchanged from 0000080420-24-000059:notes:63]

[0000080420-25-000029:notes:64]
[same as prior period, unchanged from 0000080420-24-000059:notes:64]


## us-gaap:LongTermDebtTextBlock

[0000080420-25-000029:notes:65]
Long-Term Debt
U.S. Revolver

[0000080420-25-000029:notes:66]
We have a credit agreement with Bank of America, N.A. and Texas Capital Bank with an aggregate commitment of $150.0 million, consisting of $100.0 million committed by Bank of America and $50.0 million committed by Texas Capital Bank (the U.S. Revolver). The U.S. Revolver has an expiration date of October 4, 2028.

[0000080420-25-000029:notes:67]
As of December 31, 2024, there were no amounts borrowed under the U.S. Revolver, and letters of credit outstanding were $56.1 million. There was $93.9 million available for the issuance of letters of credit and borrowings under the U.S. Revolver as of December 31, 2024.

[0000080420-25-000029:notes:68]
As of December 31, 2024, we were in compliance with all of the financial covenants of the U.S. Revolver.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0000080420-25-000029:notes:69]
Commitments and Contingencies
Letters of Credit, Bank Guarantees and Bonds

[0000080420-25-000029:notes:70]
Certain customers require us to post letters of credit, bank guarantees or surety bonds. These security instruments assure that we will perform under the terms of our contract. In the event of default, the counterparty may demand payment from the bank under a letter of credit or bank guarantee, or performance by the surety under a bond. To date, there have been no significant draws or claims related to security instruments for the periods reported. We were contingently liable for letters of credit of $56.1 million as of December 31, 2024. We also had surety bonds totaling $432.1 million that were outstanding, with additional bonding capacity of $767.9 million available, at December 31, 2024. We have strong surety relationships; however, a change in market conditions or the sureties' assessment of our financial position could cause the sureties to require cash collateralization for undischarged liabilities under the bonds.

[0000080420-25-000029:notes:71]
We have an $18.8 million facility agreement (Facility Agreement) between Powell (UK) Limited and a large international bank that provides Powell (UK) Limited the ability to enter into bank guarantees as well as forward exchange contracts and currency options. At December 31, 2024, we had outstanding guarantees totaling $7.7 million, with an additional capacity of $11.1 million available under this Facility Agreement. The Facility Agreement provides for customary events of default and carries cross-default provisions with the U.S. Revolver. If an event of default (as defined in the Facility Agreement) occurs and is continuing, per the terms and subject to the conditions set forth therein, obligations outstanding under the Facility Agreement may be accelerated and declared immediately due and payable. Additionally, we are required to maintain cash collateral for guarantees greater than two years. As of December 31, 2024, we were in compliance with all of the financial covenants of the Facility Agreement.

[0000080420-25-000029:notes:72]
Litigation

[0000080420-25-000029:notes:73]
We are involved in various legal proceedings, claims and other disputes arising from our commercial operations, projects, employees and other matters which, in general, are subject to uncertainties and for which the outcomes are not predictable. Although we can give no assurances about the resolution of pending claims, litigation or other disputes, and the effect such outcomes may have on us, management believes that any ultimate liability resulting from the outcome of such proceedings, to the extent not otherwise provided or covered by insurance, will not have a material adverse effect on our consolidated financial position or results of operations or liquidity.

[0000080420-25-000029:notes:74]
Liquidated Damages

[0000080420-25-000029:notes:75]
Certain of our customer contracts have schedule and performance obligation clauses that, if we fail to meet them, could require us to pay liquidated damages. Each individual contract defines the conditions under which the customer may make a claim against us. As of December 31, 2024, certain contracts had a probable exposure to liquidated damages claims of $2.4 million, which could possibly increase to $3.1 million under certain circumstances. Based on our actual or projected failure to meet these various contractual commitments, $2.0 million has been recorded as a reduction to revenue. We will attempt to obtain change orders, contract extensions or accelerate project completion, which may resolve the potential for any unrecorded liquidated damages claims. Should we fail to achieve relief on some or all of these contractual obligations, we could be required to pay additional liquidated damages, which could negatively impact our future operating results.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0000080420-25-000029:notes:76]
Stock-Based Compensation
Refer to our Annual Report on Form 10-K for the fiscal year ended September 30, 2024 for a full description of our existing stock-based compensation plans.

[0000080420-25-000029:notes:77]
[same as prior period, unchanged from 0000080420-24-000059:notes:78]

[0000080420-25-000029:notes:78]
We issue restricted stock units (RSUs) to certain officers and key employees of the Company. The fair value of the RSUs is based on the price of our common stock as reported on the NASDAQ Global Market during a specified period prior to the grant dates. Typically, these grants vest over a three-year period from the date of issuance and are a blend of time-based and performance-based shares. The portion of the grant that is time-based typically vests over a three-year period on each anniversary of the grant date, based on continued employment. The performance-based shares vest based on the three-year earnings and safety performance of the Company following the grant date. At December 31, 2024, there were 119,216 RSUs outstanding. The RSUs do not have voting rights but do receive dividend equivalents upon vesting, which are accrued quarterly. Additionally, the shares of common stock underlying the RSUs are not considered issued and outstanding until vested and common stock is issued.

[0000080420-25-000029:notes:79]
Total RSU activity (number of shares) for the three months ended December 31, 2024 is summarized below:

[0000080420-25-000029:notes:80]
|  | Number ofRestrictedStockUnits |  | WeightedAverageGrant ValuePer Share |
| Outstanding at September 30, 2024 | 192,011 |  |  | $ | 35.38 |  |
| Granted | 19,600 |  |  | 182.14 |  |
| Vested | (91,332) |  |  | 30.18 |  |
| Forfeited/canceled | (1,063) |  |  | 45.09 |  |
| Outstanding at December 31, 2024 | 119,216 |  |  | $ | 63.72 |  |

[0000080420-25-000029:notes:81]
During the three months ended December 31, 2024 and 2023, we recorded compensation expense of $1.3 million and $1.6 million, respectively, related to the RSUs.

[0000080420-25-000029:notes:82]
Restricted Stock
Each non-employee director receives restricted shares of the Company's common stock valued at $0.1 million annually. The number of granted shares is calculated by dividing the $0.1 million by the average of high and low prices of our common stock on the grant date. The shares shall vest on the earlier of the grant anniversary date or the date of the next annual meeting of stockholders, whichever occurs first. During the three months ended December 31, 2024 and 2023, we recorded compensation expense of $0.2 million and less than $0.1 million, respectively, related to restricted stock.


## us-gaap:FairValueDisclosuresTextBlock

[0000080420-25-000029:notes:83]
[same as prior period, unchanged from 0000080420-24-000059:notes:84]

[0000080420-25-000029:notes:84]
[same as prior period, unchanged from 0000080420-24-000059:notes:85]

[0000080420-25-000029:notes:85]
[same as prior period, unchanged from 0000080420-24-000059:notes:86]

[0000080420-25-000029:notes:86]
[same as prior period, unchanged from 0000080420-24-000059:notes:87]

[0000080420-25-000029:notes:87]
[same as prior period, unchanged from 0000080420-24-000059:notes:88]

[0000080420-25-000029:notes:88]
The following table summarizes the fair value of our assets and liabilities that were accounted for at fair value on a recurring basis as of December 31, 2024 (in thousands):

[0000080420-25-000029:notes:89]
|  | Fair Value Measurements at December 31, 2024 |
|  | Quoted Prices inActive Markets forIdentical Assets(Level 1) |  | Significant OtherObservableInputs(Level 2) |  | SignificantUnobservableInputs(Level 3) |  | Fair Value at December 31,2024 |
| Assets: |  |  |  |  |  |  |  |
| Cash and cash equivalents | $ | 325,598 |  |  | $ | — |  |  | $ | — |  |  | $ | 325,598 |  |
| Short-term investments | 47,799 |  |  | — |  |  | — |  |  | 47,799 |  |
| Rabbi trust assets | — |  |  | 12,037 |  |  | — |  |  | 12,037 |  |
| Liabilities: |  |  |  |  |  |  |  |
| Deferred compensation | — |  |  | 12,999 |  |  | — |  |  | 12,999 |  |

[0000080420-25-000029:notes:90]
The following table summarizes the fair value of our assets and liabilities that were accounted for at fair value on a recurring basis as of September 30, 2024 (in thousands):

[0000080420-25-000029:notes:91]
|  | Fair Value Measurements at September 30, 2024 |
|  | Quoted Prices inActive Markets forIdentical Assets(Level 1) |  | Significant OtherObservableInputs(Level 2) |  | SignificantUnobservableInputs(Level 3) |  | Fair Value at September 30,2024 |
| Assets: |  |  |  |  |  |  |  |
| Cash and cash equivalents | $ | 315,331 |  |  | $ | — |  |  | $ | — |  |  | $ | 315,331 |  |
| Short-term investments | 43,061 |  |  | — |  |  | — |  |  | 43,061 |  |
| Rabbi trust assets | — |  |  | 12,324 |  |  | — |  |  | 12,324 |  |
| Liabilities: |  |  |  |  |  |  |  |
| Deferred compensation | — |  |  | 12,027 |  |  | — |  |  | 12,027 |  |

[0000080420-25-000029:notes:92]
[same as prior period, unchanged from 0000080420-24-000059:notes:93]

[0000080420-25-000029:notes:93]
[same as prior period, unchanged from 0000080420-24-000059:notes:94]

[0000080420-25-000029:notes:94]
[same as prior period, unchanged from 0000080420-24-000059:notes:95]

[0000080420-25-000029:notes:95]
[same as prior period, unchanged from 0000080420-24-000059:notes:96]

[0000080420-25-000029:notes:96]
There were no transfers between levels within the fair value measurement hierarchy during the quarter ended December 31, 2024.


## us-gaap:LesseeOperatingLeasesTextBlock

[0000080420-25-000029:notes:97]
Leases
Our leases consist primarily of office and construction equipment. All of our future lease obligations are related to non-cancelable operating leases. The following table provides a summary of lease cost components for the three months ended December 31, 2024 and 2023, respectively (in thousands):

[0000080420-25-000029:notes:98]
|  |  | Three months ended December 31, |  |  |
| Lease Cost |  | 2024 |  | 2023 |  |  |  |  |
| Operating lease cost |  | $ | 198 |  |  | $ | 256 |  |  |  |  |  |
| Less: sublease income |  | — |  |  | — |  |  |  |  |  |
| Variable lease cost(1) |  | 34 |  |  | 30 |  |  |  |  |  |
| Short-term lease cost(2) |  | 639 |  |  | 400 |  |  |  |  |  |
| Total lease cost |  | $ | 871 |  |  | $ | 686 |  |  |  |  |  |

[0000080420-25-000029:notes:99]
[same as prior period, unchanged from 0000080420-24-000059:notes:100]

[0000080420-25-000029:notes:100]
[same as prior period, unchanged from 0000080420-24-000059:notes:101]

[0000080420-25-000029:notes:101]
We recognize operating lease assets and operating lease liabilities representing the present value of the remaining lease payments for leases with initial terms greater than twelve months. Leases with initial terms of twelve months or less are not recorded in our Condensed Consolidated Balance Sheets. The following table provides a summary of the operating lease assets and operating lease liabilities included in our Condensed Consolidated Balance Sheets as of December 31, 2024 and September 30, 2024, respectively (in thousands):

[0000080420-25-000029:notes:102]
| Operating Leases |  | December 31, 2024 |  | September 30, 2024 |
| Assets: |  |  |  |  |
| Operating lease assets, net |  | $ | 1,365 |  |  | $ | 1,216 |  |
| Liabilities: |  |  |  |  |
| Current operating lease liabilities |  | 630 |  |  | 595 |  |
| Long-term operating lease liabilities |  | 735 |  |  | 621 |  |
| Total lease liabilities |  | $ | 1,365 |  |  | $ | 1,216 |  |

[0000080420-25-000029:notes:103]
The following table provides the maturities of our operating lease liabilities as of December 31, 2024 (in thousands):

[0000080420-25-000029:notes:104]
|  |  | Operating Leases |  |  |
| Remainder of 2025 |  | $ | 558 |  |  |  |
| 2026 |  | 493 |  |  |  |
| 2027 |  | 319 |  |  |  |
| 2028 |  | 71 |  |  |  |
| 2029 |  | 28 |  |  |  |
| Thereafter |  | — |  |  |  |
| Total future minimum lease payments |  | $ | 1,469 |  |  |  |
| Less: present value discount (imputed interest) |  | (104) |  |  |  |
| Present value of lease liabilities |  | $ | 1,365 |  |  |  |

[0000080420-25-000029:notes:105]
The weighted average discount rate as of December 31, 2024 was 6.13%. The weighted average remaining lease term was 2.46 years at December 31, 2024.


## us-gaap:IncomeTaxDisclosureTextBlock

[0000080420-25-000029:notes:106]
[same as prior period, unchanged from 0000080420-24-000059:notes:107]

[0000080420-25-000029:notes:107]
|  | Three months ended December 31, |  |  |
|  | 2024 |  | 2023 |  |  |  |  |
| Income before income taxes | $ | 39,437 |  |  | $ | 29,878 |  |  |  |  |  |
| Income tax provision | 4,674 |  |  | 5,793 |  |  |  |  |  |
| Net income | $ | 34,763 |  |  | $ | 24,085 |  |  |  |  |  |
| Effective tax rate | 12 | % |  | 19 | % |  |  |  |  |

[0000080420-25-000029:notes:108]
Our income tax provision reflects an effective tax rate on pre-tax income of 12% for the three months ended December 31, 2024 compared to 19% for the three months ended December 31, 2023. The effective tax rates for the first quarter of Fiscal 2025 and Fiscal 2024 were favorably impacted by discrete items related to the vesting of RSUs and the estimated Research and Development (R&D) Tax Credit, which were partially offset by the tax expense related to certain nondeductible items. In addition, the favorable tax impact in the first quarter of Fiscal 2024 was partially offset by an income inclusion related to U.S. global intangible income.


## us-gaap:SubsequentEventsTextBlock

[0000080420-25-000029:notes:109]
Subsequent Events
Quarterly Dividend Declared

[0000080420-25-000029:notes:110]
On February 4, 2025, our Board of Directors approved an increase to the quarterly cash dividend on our common stock to $0.2675 per share, equating to an annualized dividend of $1.07 per share from the current amount of $1.06 per share. The dividend is payable on March 19, 2025 to shareholders of record at the close of business on February 19, 2025.


## ecd:MtrlTermsOfTrdArrTextBlock

[0000080420-25-000029:notes:111]
On November 26, 2024, Michael W. Metcalf, Executive Vice President and Chief Financial Officer, adopted a “Rule 10b5-1 trading arrangement,” as the term is defined in Item 408(a) of Regulation S-K, for the sale of up to 10,500 shares of the Company’s common stock, subject to certain conditions, from March  20, 2025 through November 26, 2025.

[0000080420-25-000029:notes:112]
On November 26, 2024, Brett A. Cope, President and Chief Executive Officer, adopted a “Rule 10b5-1 trading arrangement,” as the term is defined in Item 408(a) of Regulation S-K, for the sale of up to 11,100 shares of the Company’s common stock, subject to certain conditions, from March 6, 2025 through December 31, 2025.
