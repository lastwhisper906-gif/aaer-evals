# POWL 8-K — 0000080420-25-000026 filed 2025-02-06

## item codes, every 8-K on or before 2025-02-07

- 2025-02-06 0000080420-25-000026 — 2.02, 9.01
- 2025-02-04 0000080420-25-000020 — 8.01, 9.01
- 2024-11-19 0000080420-24-000084 — 2.02, 9.01
- 2024-11-05 0000080420-24-000081 — 8.01, 9.01
- 2024-07-30 0000080420-24-000057 — 2.02, 8.01, 9.01
- 2024-04-30 0000080420-24-000026 — 2.02, 8.01, 9.01
- 2024-02-15 0000080420-24-000014 — 5.02, 5.07
- 2024-01-30 0000080420-24-000005 — 2.02, 8.01, 9.01
- 2024-01-08 0000080420-24-000002 — 5.02
- 2023-12-05 0000080420-23-000047 — 2.02, 9.01
- 2023-11-03 0000080420-23-000044 — 8.01, 9.01
- 2023-10-11 0000080420-23-000041 — 1.01, 2.03
- 2023-08-01 0000080420-23-000036 — 2.02, 8.01, 9.01
- 2023-05-19 0001193125-23-149334 — 5.07 — amendment of 0000080420-23-000011
- 2023-05-03 0000080420-23-000025 — 2.02, 8.01, 9.01
- 2023-04-06 0000080420-23-000020 — 1.01, 2.03, 9.01
- 2023-04-05 0000080420-23-000018 — 5.02
- 2023-02-16 0000080420-23-000011 — 5.02, 5.07, 9.01
- 2023-01-31 0000080420-23-000004 — 2.02, 8.01
- 2022-12-05 0000080420-22-000034 — 2.02, 9.01
- 2022-08-02 0000080420-22-000030 — 2.02, 8.01, 9.01
- 2022-05-13 0000080420-22-000024 — 5.02, 9.01
- 2022-05-03 0000080420-22-000016 — 2.02, 9.01
- 2022-05-03 0000080420-22-000015 — 8.01, 9.01
- 2022-02-17 0000080420-22-000010 — 5.07
- 2022-02-08 0000080420-22-000005 — 2.02, 9.01
- 2022-02-01 0000080420-22-000002 — 8.01, 9.01
- 2021-12-07 0000080420-21-000043 — 2.02, 9.01
- 2021-08-03 0000080420-21-000036 — 2.02, 8.01, 9.01
- 2021-05-04 0000080420-21-000026 — 2.02, 8.01, 9.01
- 2021-03-16 0001193125-21-082878 — 1.01, 2.03, 9.01
- 2021-03-05 0000080420-21-000021 — 5.02, 8.01, 9.01
- 2021-02-26 0000080420-21-000018 — 5.03
- 2021-02-18 0000080420-21-000016 — 5.07
- 2021-02-02 0000080420-21-000010 — 2.02, 8.01, 9.01
- 2020-12-08 0000080420-20-000032 — 2.02, 9.01
- 2020-11-12 0000080420-20-000030 — 8.01, 9.01
- 2020-08-04 0000080420-20-000024 — 2.02, 8.01, 9.01
- 2020-05-05 0000080420-20-000017 — 2.02, 8.01, 9.01
- 2020-02-21 0000080420-20-000008 — 5.07
- 2020-02-04 0000080420-20-000003 — 2.02, 8.01, 9.01
- 2019-12-04 0001193125-19-306243 — 2.02, 9.01
- 2019-11-08 0000080420-19-000032 — 8.01, 9.01
- 2019-10-03 0000080420-19-000030 — 1.01, 2.03
- 2019-09-24 0000080420-19-000028 — 8.01, 9.01
- 2019-08-06 0000080420-19-000022 — 2.02, 8.01, 9.01
- 2019-05-08 0000080420-19-000017 — 5.02, 9.01
- 2019-05-07 0000080420-19-000011 — 2.02, 8.01, 9.01
- 2019-02-22 0001193125-19-048366 — 5.07
- 2019-02-05 0000080420-19-000003 — 2.02, 8.01
- 2018-12-21 0000080420-18-000038 — 5.02, 9.01
- 2018-12-12 0000080420-18-000031 — 2.02
- 2018-11-05 0000080420-18-000029 — 8.01, 9.01
- 2018-11-01 0000080420-18-000027 — 5.02, 8.01, 9.01
- 2018-10-01 0000080420-18-000024 — 5.02
- 2018-08-07 0000080420-18-000020 — 2.02, 8.01
- 2018-05-15 0000080420-18-000016 — 5.02, 8.01
- 2018-05-09 0000080420-18-000011 — 2.02, 8.01
- 2018-02-22 0000080420-18-000009 — 5.07
- 2018-02-06 0000080420-18-000003 — 2.02, 8.01
- 2017-12-27 0001193125-17-379928 — 5.02
- 2017-12-05 0000080420-17-000028 — 2.02, 9.01
- 2017-11-08 0000080420-17-000024 — 8.01, 9.01
- 2017-11-03 0000080420-17-000022 — 5.02
- 2017-08-09 0000080420-17-000017 — 2.02, 8.01
- 2017-06-30 0000080420-17-000014 — 1.01, 9.01
- 2017-05-03 0000080420-17-000006 — 2.02, 8.01, 9.01
- 2017-02-23 0000080420-17-000004 — 5.07
- 2017-02-08 0001628280-17-000965 — 2.02 — amendment of 0001628280-17-000949
- 2017-02-07 0001628280-17-000949 — 2.01, 8.01, 9.01
- 2016-12-07 0001193125-16-787354 — 2.02, 9.01
- 2016-11-01 0001193125-16-755475 — 8.01, 9.01
- 2016-09-30 0001193125-16-726999 — 5.02, 8.01, 9.01
- 2016-08-03 0001193125-16-669308 — 2.02, 8.01, 9.01
- 2016-05-04 0001193125-16-576528 — 2.02, 8.01, 9.01
- 2016-02-25 0001193125-16-477896 — 5.07
- 2016-02-03 0001193125-16-449052 — 2.02, 8.01, 9.01
- 2015-12-31 0001193125-15-418363 — 5.02, 7.01, 9.01
- 2015-12-02 0001193125-15-393109 — 2.02, 9.01
- 2015-11-05 0001193125-15-368085 — 8.01, 9.01
- 2015-09-25 0001193125-15-329031 — 5.02
- 2015-08-05 0001193125-15-277912 — 2.02, 8.01, 9.01
- 2015-05-06 0001193125-15-174291 — 2.02, 8.01, 9.01
- 2015-03-06 0001193125-15-081070 — 5.02
- 2015-03-02 0001193125-15-072946 — 5.07
- 2015-02-03 0001193125-15-031772 — 2.02, 8.01, 9.01
- 2014-12-18 0001193125-14-446513 — 8.01, 9.01
- 2014-12-03 0001193125-14-431745 — 2.02, 9.01
- 2014-11-05 0001193125-14-397955 — 8.01, 9.01
- 2014-09-26 0001193125-14-353741 — 7.01, 9.01
- 2014-08-05 0001193125-14-296001 — 2.02, 8.01, 9.01
- 2014-05-07 0001193125-14-187496 — 2.02, 8.01, 9.01
- 2014-03-03 0001193125-14-079843 — 5.02, 5.07
- 2014-02-05 0001193125-14-036633 — 2.02, 8.01, 9.01
- 2014-01-17 0001193125-14-014351 — 1.01, 8.01, 9.01
- 2014-01-06 0001193125-14-002795 — 1.01, 2.03
- 2013-12-06 0001564590-13-001411 — 2.02, 9.01
- 2013-12-05 0001564590-13-001406 — 5.02, 8.01, 9.01
- 2013-11-07 0001193125-13-432950 — 8.01, 9.01
- 2013-08-07 0001193125-13-324337 — 2.02, 9.01
- 2013-05-08 0001193125-13-206800 — 2.02, 9.01
- 2013-02-22 0001193125-13-070971 — 5.02, 5.07
- 2013-02-06 0001193125-13-040556 — 2.02, 9.01
- 2012-12-18 0001193125-12-506417 — 5.02, 9.01
- 2012-12-05 0001193125-12-491749 — 2.02, 9.01
- 2012-10-12 0001193125-12-421889 — 3.03, 5.02, 5.03, 9.01
- 2012-08-09 0001193125-12-344617 — 5.02, 8.01, 9.01
- 2012-08-08 0001193125-12-343630 — 2.02, 9.01
- 2012-05-09 0001193125-12-221356 — 2.02, 9.01
- 2012-02-08 0001193125-12-046560 — 2.02, 9.01
- 2011-12-08 0001193125-11-334810 — 2.02, 9.01
- 2011-11-08 0000950123-11-096524 — 2.02, 2.06, 4.02, 9.01
- 2011-10-14 0000950123-11-090124 — 5.02
- 2011-10-06 0000950123-11-088969 — 5.02
- 2011-09-19 0000950123-11-085224 — 5.02, 9.01
- 2011-09-15 0000950123-11-084806 — 5.02, 9.01
- 2011-08-04 0000950123-11-072788 — 2.02, 9.01
- 2011-07-22 0000950123-11-067402 — 5.07
- 2011-05-24 0000950123-11-053550 — 1.01, 2.03, 9.01
- 2011-05-04 0000950123-11-044561 — 2.02, 9.01
- 2011-02-02 0000950123-11-008188 — 2.02, 9.01
- 2010-12-08 0000950123-10-111987 — 2.02, 9.01
- 2010-08-05 0000950123-10-073114 — 2.02, 9.01
- 2010-05-18 0000950123-10-050900 — 5.02
- 2010-05-05 0000950123-10-044499 — 2.02, 9.01
- 2010-02-03 0000950123-10-008278 — 2.02, 9.01
- 2009-12-21 0000950123-09-072269 — 1.01, 2.01, 2.03, 8.01, 9.01
- 2009-12-09 0000950123-09-069525 — 2.02, 9.01
- 2009-10-27 0000950123-09-053501 — 1.01, 8.01, 9.01
- 2009-08-04 0000950123-09-029476 — 2.02, 9.01
- 2009-05-06 0000950129-09-001498 — 2.02, 9.01
- 2009-03-05 0000950129-09-000749 — 1.01, 9.01
- 2009-02-10 0000950129-09-000349 — 2.02, 9.01
- 2008-12-10 0000950134-08-021934 — 2.02, 9.01
- 2008-08-06 0000950129-08-004267 — 2.02, 9.01
- 2008-07-24 0000950129-08-004063 — 1.01, 5.02, 8.01, 9.01
- 2008-06-16 0000950129-08-003500 — 9.01 — amendment of 0000950134-06-015374
- 2008-06-05 0000950129-08-003378 — 5.02, 9.01
- 2008-05-08 0000950129-08-002843 — 2.02, 9.01
- 2008-02-06 0000950129-08-000533 — 2.02, 9.01
- 2007-12-19 0000950129-07-006277 — 1.01, 2.03, 9.01
- 2007-12-06 0000950129-07-006003 — 2.02, 9.01
- 2007-08-21 0000950129-07-004181 — 2.02, 9.01
- 2007-05-31 0000950129-07-002810 — 2.02, 9.01
- 2007-05-21 0000950129-07-002668 — 2.02, 3.01, 4.02, 9.01
- 2007-04-16 0000950129-07-002002 — 2.02, 4.02, 9.01
- 2007-03-01 0000950129-07-001104 — 5.02, 8.01, 9.01
- 2007-02-08 0000950129-07-000451 — 2.02, 9.01
- 2006-12-08 0000950129-06-010041 — 2.02, 9.01
- 2006-09-08 0000950129-06-008379 — 2.02, 9.01
- 2006-08-09 0000950134-06-015374 — 1.01, 2.01, 8.01, 9.01
- 2006-06-08 0000950129-06-006127 — 2.02, 9.01
- 2006-03-09 0000950129-06-002455 — 2.02, 9.01
- 2005-12-16 0000950129-05-012031 — 2.02, 5.03, 9.01
- 2005-09-13 0000950129-05-009181 — 2.01, 9.01 — amendment of 0000950129-05-006889
- 2005-09-12 0000950129-05-009151 — 2.02, 9.01
- 2005-07-06 0000950129-05-006889 — 1.01, 1.02, 2.01, 2.03, 9.01
- 2005-06-10 0000950129-05-006128 — 2.02, 9.01
- 2005-04-20 0000080420-05-000031 — 5.02
- 2005-03-11 0000080420-05-000024 — 9.01
- 2005-02-25 0000080420-05-000018 — 7.01, 9.01
- 2005-01-21 0000080420-05-000009 — 7.01, 9.01
- 2004-12-17 0000080420-04-000049 — 2.02, 9.01
- 2004-11-01 0000080420-04-000045 — 8.01, 9.01
- 2004-10-08 0001169232-04-005133 — 2.05
- 2004-09-14 0000080420-04-000037 — 5.02
- 2004-09-02 0000080420-04-000030 — 2.02, 9.01
- 2004-06-08 0000080420-04-000021 — 7
- 2004-05-13 0000080420-04-000019 — 4
- 2004-02-27 0000080420-04-000013 — 7
- 2003-12-16 0000950129-03-006136 — 12, 7
- 2003-08-29 0000950129-03-004531 — 12, 7
- 2003-06-03 0000950129-03-003035 — 7, 9
- 2003-05-15 0000950129-03-002812 — 7, 9
- 2002-05-29 0000950129-02-002795 — 4
- 2000-12-21 0000950129-00-006093 — 5, 7
- 1998-09-04 0000950129-98-003802 — 5
- 1996-08-09 0000950129-96-001705 — 2, 7

## late-filing notifications on or before 2025-02-07

- 2007-05-11 0000950129-07-002494 — NT 10-Q, for the period ended 2007-03-31
- 2005-01-18 0000080420-05-000004 — NT 10-K, for the period ended 2004-10-31

## item 2.02 — earnings release, exhibit 99.1

[0000080420-25-000026:8k_2_02:1]
EX-99.1
2
ex991-powlq1xfy2025earning.htm
EX-99.1

[0000080420-25-000026:8k_2_02:2]
Document

[0000080420-25-000026:8k_2_02:3]
Exhibit 99.1

[0000080420-25-000026:8k_2_02:4]
PRESS RELEASE

[0000080420-25-000026:8k_2_02:5]
| For Immediate Release |  |  | Contact: | Michael Metcalf, CFO |
|  |  |  |  | Powell Industries, Inc. |
|  |  |  |  | 713-947-4422 |
|  |  |  |  | Robert Winters or Ryan Coleman |
|  |  |  |  | Alpha IR Group |
|  |  |  |  | POWL@alpha-ir.com |
|  |  |  |  | 312-445-2870 |

[0000080420-25-000026:8k_2_02:6]
POWELL INDUSTRIES ANNOUNCES FIRST QUARTER FISCAL 2025 RESULTS

[0000080420-25-000026:8k_2_02:7]
HOUSTON — February 6, 2025 — Powell Industries, Inc. (NASDAQ: POWL), a leading supplier of custom-engineered solutions for the management, control and distribution of electrical energy, today announced results for the first quarter fiscal 2025 ended December 31, 2024. All comparisons are to the first quarter of fiscal 2024, unless otherwise noted.

[0000080420-25-000026:8k_2_02:8]
First Quarter Key Financial Highlights:

[0000080420-25-000026:8k_2_02:9]
•Revenues totaled $241 million, an increase of 24%;

[0000080420-25-000026:8k_2_02:10]
•Gross profit of $60 million, or 24.7% of revenue;

[0000080420-25-000026:8k_2_02:11]
•Net income of $35 million, or $2.86 per diluted share, increased 44%;

[0000080420-25-000026:8k_2_02:12]
•New orders(1) totaled $269 million;

[0000080420-25-000026:8k_2_02:13]
•Backlog(2) as of December 31, 2024 remained at $1.3 billion;

[0000080420-25-000026:8k_2_02:14]
•Cash and short-term investments as of December 31, 2024 totaled $373 million.

[0000080420-25-000026:8k_2_02:15]
Brett A. Cope, Powell’s Chairman and Chief Executive Officer, stated, “Powell recorded a strong start to Fiscal 2025 highlighted by new order growth of 36%. We saw strong order activity across each of our market sectors, as our Electric Utility and Oil & Gas markets continue to benefit

[0000080420-25-000026:8k_2_02:16]
from robust tailwinds that support our expectation for volume growth in 2025. We were awarded a large LNG project situated along the U.S. Gulf Coast during the quarter as we expect this market sector to see improved activity levels relative to Fiscal 2024. Revenue also grew 24% and we delivered earnings per diluted share of $2.86 despite what is typically a seasonally softer first quarter. Overall, we remain very encouraged by both our backlog as well as the volume and composition of projects in our pipeline.”

[0000080420-25-000026:8k_2_02:17]
First Quarter Fiscal 2025 Results

[0000080420-25-000026:8k_2_02:18]
Revenues totaled $241.4 million, an increase of 24% compared to $194.0 million in the prior year, and a 12% decline compared to $275.1 million in the fourth quarter of Fiscal 2024, as the first quarter has historically been seasonally lower than the remainder of the fiscal year. The increase compared to the prior year was driven by higher revenue levels across all major market sectors. Revenue from the Oil & Gas sector increased 14% to $95.7 million, while revenue from the Electric Utility and Commercial & Other Industrial sectors grew 26% to $51.2 million and 80% to $44.3 million, respectively.

[0000080420-25-000026:8k_2_02:19]
Gross profit of $59.5 million, or 24.7% of revenue, increased 24% compared to $48.2 million, or 24.8% of revenue, in the prior year, but decreased 26% compared to $80.4 million, or 29.2% of revenue, in the fourth quarter.  Gross margin improved compared to the prior year, primarily due to higher revenues with the gross profit margin percentage remaining flat, while the sequential decline in gross margin was mainly driven by typical seasonality we have historically experienced during the first fiscal quarter.

[0000080420-25-000026:8k_2_02:20]
New orders totaled $269 million compared to $198 million in the prior year and $267 million in the fourth quarter. The growth compared to the prior year was driven by robust order activity in the Oil & Gas market sector as well as strong bookings within the Electric Utility market sector.

[0000080420-25-000026:8k_2_02:21]
Backlog totaled $1.3 billion as of December 31, 2024, essentially remaining the same as the backlog at both September 30, 2024 and December 31, 2023.

[0000080420-25-000026:8k_2_02:22]
Net income of $34.8 million, or $2.86 per diluted share, increased 44% compared to $24.1 million, or $1.98 per diluted share, in the prior year, and decreased 25% compared to $46.1 million, or $3.77 per diluted share, in the fourth quarter.

[0000080420-25-000026:8k_2_02:23]
Cope added, “Our planned manufacturing capacity upgrades remain on track to be completed during the middle of fiscal 2025, which will help to facilitate organic growth within our targeted markets and commercialize new products. Our diversification efforts continue to present new opportunities and awards for Powell across markets such as data centers, utilities, carbon capture, hydrogen, and more. As a result, our backlog today is more diverse across market sectors than ever before, increasingly comprised of rapidly expanding applications for our custom-engineered products.”

[0000080420-25-000026:8k_2_02:24]
OUTLOOK

[0000080420-25-000026:8k_2_02:25]
Commenting on the Company's outlook, Michael Metcalf, Powell’s Chief Financial Officer, said, “As we look ahead to the remainder of Fiscal 2025, we are encouraged by the sustained commercial momentum across our end markets through the first fiscal quarter, which has allowed us to maintain both the quality and quantity of our backlog.  Combined with our ongoing focus on optimizing margin levers and the strength of our balance sheet, Powell is well-positioned to deliver robust revenue and earnings throughout the rest of Fiscal 2025.”

[0000080420-25-000026:8k_2_02:26]
CONFERENCE CALL

[0000080420-25-000026:8k_2_02:27]
Powell Industries has scheduled a conference call for Friday, February 7, 2025 at 11:00 a.m. Eastern time. To participate in the conference call, dial 1-833-953-2431 (domestic) or 1-412-317-5760 (international) at least 10 minutes before the call begins and ask for the Powell Industries conference call. A telephonic replay of the conference call will be available through February 14, 2025 and may be accessed by calling 1-877-344-7529 (domestic) or 1-412-317-0088 (international) and using passcode 2987033#.

[0000080420-25-000026:8k_2_02:28]
Investors, analysts and the general public will also have the opportunity to listen to the conference call over the Internet by visiting powellind.com. To listen to the live call on the web, please visit the website at least 15 minutes before the call begins to register, download and install any necessary audio software.  For those who cannot listen to the live webcast, an archive will be available shortly after the call and will remain available for approximately 90 days at powellind.com.

[0000080420-25-000026:8k_2_02:29]
3

[0000080420-25-000026:8k_2_02:30]
About Powell Industries

[0000080420-25-000026:8k_2_02:31]
Powell Industries, Inc., headquartered in Houston, Texas, develops, designs, manufactures and services custom-engineered equipment and systems that distribute, control and monitor the flow of electrical energy and provide protection to motors, transformers and other electrically powered equipment.  Powell Industries, Inc. primarily serves the oil and gas and petrochemical markets, the electric utility market, and commercial and other industrial markets. Beyond these major markets, we also provide products and services to the light rail traction power market and other markets that include universities and government entities. We are continuously developing new channels to electrical markets through original equipment manufacturers and distribution market channels.   For more information, please visit powellind.com.

[0000080420-25-000026:8k_2_02:32]
POWELL INDUSTRIES, INC. & SUBSIDIARIES

[0000080420-25-000026:8k_2_02:33]
CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS

[0000080420-25-000026:8k_2_02:34]
|  | Three Months EndedDecember 31, |
|  | 2024 |  | 2023 |
| (In thousands, except per share data) |  |  |  |
|  | (Unaudited) |
| Revenues | $ | 241,431 |  |  | $ | 194,017 |  |
| Cost of goods sold | 181,907 |  |  | 145,823 |  |
| Gross profit | 59,524 |  | 48,194 |
| Selling, general and administrative expenses | 21,476 |  |  | 20,347 |  |
| Research and development expenses | 2,476 |  |  | 1,967 |  |
| Operating income | 35,572 |  |  | 25,880 |  |
| Other expenses (income): |  |  |  |
| Interest income, net | (3,865) |  |  | (3,998) |  |
| Income before income taxes | 39,437 |  | 29,878 |
| Income tax provision | 4,674 |  |  | 5,793 |  |
| Net income | $ | 34,763 |  |  | $ | 24,085 |  |
| Earnings per share: |  |  |  |
| Basic | $ | 2.89 |  |  | $ | 2.02 |  |
| Diluted | $ | 2.86 |  |  | $ | 1.98 |  |
| Weighted average shares: |  |  |  |
| Basic | 12,037 |  |  | 11,941 |  |
| Diluted | 12,152 |  |  | 12,174 |  |
| SELECTED FINANCIAL DATA: |  |  |  |
| Depreciation | $ | 1,755 |  |  | $ | 1,641 |  |
| Capital Expenditures | $ | 2,189 |  |  | $ | 1,235 |  |
| Dividends Paid | $ | 3,185 |  |  | $ | 3,124 |  |

[0000080420-25-000026:8k_2_02:35]
5

[0000080420-25-000026:8k_2_02:36]
POWELL INDUSTRIES, INC. & SUBSIDIARIES

[0000080420-25-000026:8k_2_02:37]
CONDENSED CONSOLIDATED BALANCE SHEETS

[0000080420-25-000026:8k_2_02:38]
|  | December 31, 2024 |  | September 30, 2024 |
| (In thousands) |  |
|  | (Unaudited) |  |  |
| Assets: |  |  |  |
| Cash, cash equivalents and short-term investments | $ | 373,397 |  |  | $ | 358,392 |  |
| Other current assets | 388,539 |  |  | 418,089 |  |
| Property, plant and equipment, net | 101,957 |  |  | 103,421 |  |
| Long-term assets | 48,782 |  |  | 48,278 |  |
| Total assets | $ | 912,675 |  |  | $ | 928,180 |  |
| Liabilities and equity: |  |  |  |
| Current liabilities | $ | 396,669 |  |  | $ | 428,015 |  |
| Deferred and other long-term liabilities | 19,674 |  |  | 17,092 |  |
| Stockholders’ equity | 496,332 |  |  | 483,073 |  |
| Total liabilities and stockholders’ equity | $ | 912,675 |  |  | $ | 928,180 |  |
| SELECTED FINANCIAL DATA: |  |  |  |
| Working capital | $ | 365,267 |  |  | $ | 348,466 |  |

[0000080420-25-000026:8k_2_02:39]
(1)New orders (bookings) represent the estimated value of contracts added to existing backlog (unsatisfied performance obligations).

[0000080420-25-000026:8k_2_02:40]
(2)The amounts recorded in backlog may not be a reliable indicator of our future operating results and may not be indicative of continuing revenue performance over future fiscal quarters or years primarily due to unexpected contract adjustments, cancellations or scope reductions.
