# POWL MD&A — 0000080420-19-000024


## mdna

[0000080420-19-000024:mdna:1]
[same as prior period, unchanged from 0000080420-19-000013:mdna:1]

[0000080420-19-000024:mdna:2]
[same as prior period, unchanged from 0000080420-19-000013:mdna:2]

[0000080420-19-000024:mdna:3]
[same as prior period, unchanged from 0000080420-19-000013:mdna:3]

[0000080420-19-000024:mdna:4]
[same as prior period, unchanged from 0000080420-19-000013:mdna:4]

[0000080420-19-000024:mdna:5]
[same as prior period, unchanged from 0000080420-19-000013:mdna:5]

[0000080420-19-000024:mdna:6]
[same as prior period, unchanged from 0000080420-19-000013:mdna:6]

[0000080420-19-000024:mdna:7]
[same as prior period, unchanged from 0000080420-19-000013:mdna:7]

[0000080420-19-000024:mdna:8]
Quarter Ended June 30, 2019 Compared to the Quarter Ended June 30, 2018 (Unaudited)

[0000080420-19-000024:mdna:9]
[same as prior period, unchanged from 0000080420-19-000013:mdna:9]

[0000080420-19-000024:mdna:10]
Revenues increased by 11%, or $13.4 million, to $135.6 million in the third quarter of Fiscal 2019, compared to the third quarter of Fiscal 2018, primarily due to an increase in orders over the past few quarters from improved market conditions, primarily in our oil and gas markets. Domestic revenues increased by 14%, or $12.3 million, to $103.6 million in the third quarter of Fiscal 2019, compared to the third quarter of Fiscal 2018. International revenues increased by 4%, or $1.1 million, to $32.0 million in the third quarter of Fiscal 2019, compared to the third quarter of Fiscal 2018, primarily driven by increased activity in our Canadian operations. Our international revenue includes both revenue generated from our international facilities as well as export revenues from our domestic facilities.

[0000080420-19-000024:mdna:11]
Revenues from commercial and industrial projects increased by 6%, or $5.8 million, to $99.1 million in the third quarter of Fiscal 2019, compared to the third quarter of Fiscal 2018, primarily driven by the continued strengthening of the core oil and gas and petrochemical end markets. Revenues from public and private utilities increased by 37%, or $7.1 million, to $26.4 million in the third quarter of Fiscal 2019, compared to the third quarter of Fiscal 2018 as the business nears completion of select large utility projects in the backlog.  Revenues from municipal and transit projects increased by 6%, or $0.6 million, to $10.1 million in the third quarter of Fiscal 2019, compared to the third quarter of Fiscal 2018, primarily impacted by project timing and product mix as this market remains stable versus the prior year.

[0000080420-19-000024:mdna:12]
Gross profit for the third quarter of Fiscal 2019 increased by 29%, or $5.3 million, to $23.7 million, compared to the third quarter of Fiscal 2018. Gross profit as a percentage of revenues increased to 17% in the third quarter of Fiscal 2019, compared to 15% in the third quarter of Fiscal 2018. Gross profit and margins increased due to improved market conditions and efficiencies resulting from increased volume in our domestic and Canadian manufacturing facilities.

[0000080420-19-000024:mdna:13]
[same as prior period, unchanged from 0000080420-19-000013:mdna:13]

[0000080420-19-000024:mdna:14]
Selling, general and administrative expenses increased by 6%, or $0.9 million, to $17.1 million during the third quarter of Fiscal 2019, compared to $16.2 million in the third quarter of Fiscal 2018, primarily due to increased personnel costs associated with increased project volume. Selling, general and administrative expenses, as a percentage of revenues, remained flat at 13% during the third quarter of Fiscal 2019 as compared to the third quarter of Fiscal 2018.

[0000080420-19-000024:mdna:15]
Insurance Proceeds

[0000080420-19-000024:mdna:16]
In the third quarter of Fiscal 2019, we reached a final settlement with respect to a 2017 business interruption insurance claim resulting from Hurricane Harvey.  The settlement resulted in insurance proceeds of $1.0 million, which is included within operating income.

[0000080420-19-000024:mdna:17]
Income Tax Expense

[0000080420-19-000024:mdna:18]
We recorded income tax expense of $0.8 million in the third quarter of Fiscal 2019, compared to income tax expense of $0.4 million in the third quarter of Fiscal 2018. The effective tax rate for the third quarter of Fiscal 2019 was 14%, compared to an effective tax rate of 56% in the third quarter of Fiscal 2018. On December 22, 2017, the new tax law lowered the corporate tax rate from 35% to 21% effective January 1, 2018. As a result, the U.S. federal statutory rate for Fiscal 2019 is 21%, compared to the blended statutory rate of 24.5% effective for Fiscal 2018. For the three months ended June 30, 2019, the effective tax rate was positively impacted by income recognized in foreign jurisdictions that was reserved with a valuation allowance while the effective tax rate for the three months ended June 30, 2018 was negatively impacted by foreign  losses recognized that we reserved with a valuation allowance.

[0000080420-19-000024:mdna:19]
Net Income

[0000080420-19-000024:mdna:20]
In the third quarter of Fiscal 2019, we recorded net income of $5.1 million, or $0.44 per diluted share, compared to net income of $0.3 million, or $0.03 per diluted share, in the third quarter of Fiscal 2018. This improvement in operating results over the prior year was primarily due to improved market conditions and efficiencies resulting from increased volume in our domestic and Canadian manufacturing facilities.

[0000080420-19-000024:mdna:21]
[same as prior period, unchanged from 0000080420-19-000013:mdna:19]

[0000080420-19-000024:mdna:22]
Our backlog includes various projects that can take a number of months to produce. The order backlog at June 30, 2019 increased to $407.0 million, compared to $397.2 million at March 31, 2019, primarily due to increased demand from our customers in our core oil and gas and petrochemical markets. New orders placed during the third quarter of Fiscal 2019 increased to $144.8 million, compared to $139.2 million in the third quarter of Fiscal 2018, primarily due to increased demand from our customers in our core oil and gas and petrochemical markets.

[0000080420-19-000024:mdna:23]
Nine Months Ended June 30, 2019 Compared to the Nine Months Ended June 30, 2018 (Unaudited)

[0000080420-19-000024:mdna:24]
[same as prior period, unchanged from 0000080420-19-000013:mdna:22]

[0000080420-19-000024:mdna:25]
Revenues increased  by 17%, or $54.9 million, to $368.7 million for the nine months ended June 30, 2019, compared to the nine months ended June 30, 2018, primarily due to an increase in orders over the past few quarters from improved market conditions, primarily in our oil and gas markets. Domestic revenues increased by 30%, or $67.9 million, to $290.9 million for the nine months ended June 30, 2019, compared to the nine months ended June 30, 2018. International revenues decreased by 14%, or $13.1 million, to $77.8 million for the nine months ended June 30, 2019, compared to the nine months ended June 30, 2018, primarily due to a decrease in export projects from our domestic facilities. Our international revenue includes both revenue generated from our international facilities as well as export revenues from our domestic facilities.

[0000080420-19-000024:mdna:26]
Revenues from commercial and industrial projects increased by 22%, or $49.2 million, to $273.9 million for the nine months ended June 30, 2019, compared to the nine months ended June 30, 2018, driven by the strength across the core oil and gas and petrochemical end markets.  Revenues from public and private utilities decreased by 2%, or $1.4 million, to $66.1 million for the nine months ended June 30, 2019, compared to the nine months ended June 30, 2018, as the business nears completion of select large utility projects in the backlog. Revenues from municipal and transit projects increased by 33%, or $7.0 million, to $28.7 million for the nine months ended June 30, 2019, compared to the nine months ended June 30, 2018, primarily impacted by the project timing and product mix of projects at or near completion for some of our key municipal customers.

[0000080420-19-000024:mdna:27]
Gross profit for the nine months ended June 30, 2019 increased by 41%, or $17.1 million, to $58.4 million, compared to the nine months ended June 30, 2018. Gross profit as a percentage of revenues increased to 16% for the nine months ended June 30, 2019, compared to 13% for the nine months ended June 30, 2018.  Gross profit increased due to improved market conditions and efficiencies resulting from increased volume in our domestic and Canadian manufacturing facilities.

[0000080420-19-000024:mdna:28]
[same as prior period, unchanged from 0000080420-19-000013:mdna:26]

[0000080420-19-000024:mdna:29]
Selling, general and administrative expenses increased by 4%, or $1.8 million, to $50.2 million for the nine months ended June 30, 2019, compared to the nine months ended June 30, 2018, primarily due to increased personnel costs associated with increased project volume. Selling, general and administrative expenses, as a percentage of revenues, decreased to 14% during the nine months ended June 30, 2019, compared to 15% during the nine months ended June 30, 2018, primarily due to the increase in revenues and our continued focus on our cost structure.

[0000080420-19-000024:mdna:30]
Insurance Proceeds

[0000080420-19-000024:mdna:31]
In the nine months ended June 30, 2019, we reached a final settlement with respect to a 2017 business interruption insurance claim resulting from Hurricane Harvey.  The settlement resulted in insurance proceeds of $1.0 million, which is included within operating income.

[0000080420-19-000024:mdna:32]
[same as prior period, unchanged from 0000080420-19-000013:mdna:15]

[0000080420-19-000024:mdna:33]
We recorded income tax expense of $1.0 million for the nine months ended June 30, 2019 compared to an income tax benefit of $2.4 million for the nine months ended June 30, 2018.  The effective tax rate for both the nine months ended June 30, 2019 and the nine months ended June 30, 2018 was 22%. For the nine months ended June 30, 2019, the effective tax rate approximated the U.S. federal statutory rate as foreign jurisdictions with losses reserved with a valuation allowance were insignificant. The effective tax rate for the same period in 2018 was negatively impacted by foreign tax losses that were reserved with a valuation allowance. The income tax benefit for the nine months ended June 30, 2018 was also negatively impacted by tax expense of $0.7 million due to the re-measurement of U.S. deferred tax assets.

[0000080420-19-000024:mdna:34]
Net Income (Loss)

[0000080420-19-000024:mdna:35]
For the nine months ended June 30, 2019, we recorded net income of $3.4 million, or $0.29 per diluted share, compared to a net loss of $8.7 million, or $0.76 per diluted share, for the nine months ended June 30, 2018.  The improvement in our operating results over the prior year was primarily due to improved market conditions and efficiencies resulting from increased volume in our domestic and Canadian manufacturing facilities.

[0000080420-19-000024:mdna:36]
[same as prior period, unchanged from 0000080420-19-000013:mdna:32]

[0000080420-19-000024:mdna:37]
The order backlog at June 30, 2019 was $407.0 million, an increase from the $260.9 million at September 30, 2018, primarily due to increased demand from our customers in our core oil and gas and petrochemical markets. New orders increased during the nine months ended June 30, 2019 to $513.9 million, compared to $380.6 million for the nine months ended June 30, 2018, primarily due to improved market conditions.

[0000080420-19-000024:mdna:38]
[same as prior period, unchanged from 0000080420-19-000013:mdna:34]

[0000080420-19-000024:mdna:39]
[same as prior period, unchanged from 0000080420-19-000013:mdna:35]

[0000080420-19-000024:mdna:40]
A significant portion of our revenues have historically been from the oil, gas and petrochemical markets. Oil and gas commodity price levels have been unstable over the last several years and our customers delayed some of their major capital investment projects. Commodity prices have stabilized and customers continue to invest in projects in our key oil and gas and petrochemical markets, and this shift in market sentiment has had a favorable impact on our orders and backlog over recent quarters.

[0000080420-19-000024:mdna:41]
Our operating results are impacted by factors such as the timing of new order awards, customer approval of final engineering and design specifications and delays in customer construction schedules, all of which contribute to short-term earnings variability and the timing of project execution. Our operating results also have been, and could continue to be, impacted by the timing and resolution of change orders, project close-out and resolution of potential contract claims and liquidated damages, all of which could improve or deteriorate gross margins during the period in which these items are resolved with our customers. These factors may result in periods of underutilization of our resources and facilities and negatively impact our ability to cover our fixed costs.  The increased orders in Fiscal 2018 and 2019 have led to improvement in revenues and operating results that we anticipate will

[0000080420-19-000024:mdna:42]
continue for the remainder of Fiscal 2019. We continue to focus on maintaining our cash position, improving efficiencies in production and investing in future business opportunities.

[0000080420-19-000024:mdna:43]
[same as prior period, unchanged from 0000080420-19-000013:mdna:39]

[0000080420-19-000024:mdna:44]
[same as prior period, unchanged from 0000080420-19-000013:mdna:40]

[0000080420-19-000024:mdna:45]
As of June 30, 2019, current assets exceeded current liabilities by 2.2 times and our debt to total capitalization was 0.40%.

[0000080420-19-000024:mdna:46]
Cash, cash equivalents and short-term investments increased to $78.0 million at June 30, 2019, compared to $49.8 million at September 30, 2018. We also had restricted cash held in a pledged collateral account related to our amended credit agreement (U.S. Revolver) of $16.7 million at June 30, 2019 and $25.1 million at September 30, 2018. For further information regarding our U.S. Revolver, see Note E of Notes to Condensed Consolidated Financial Statements.

[0000080420-19-000024:mdna:47]
Our U.S. Revolver is a $75.0 million revolving credit facility in the U.S. As of June 30, 2019, there were no amounts borrowed under this facility. Total letters of credit outstanding under our U.S. Revolver, which reduce our availability, were $11.8 million at June 30, 2019 and $23.1 million at September 30, 2018. Currently, our U.S. Revolver can only be used for letters of credit until we meet certain financial ratios as described in Note E of Notes to Condensed Consolidated Financial Statements. As of June 30, 2019, there was $63.2 million available for the issuance of letters of credit under the U.S. Revolver. Total long-term debt, including current maturities, totaled $1.2 million at June 30, 2019, compared to $1.6 million at September 30, 2018.

[0000080420-19-000024:mdna:48]
Approximately $22.8 million of our cash and short-term investments at June 30, 2019 was held outside of the U.S. for international operations. It is our intention to indefinitely reinvest all current and future foreign earnings internationally in order to ensure sufficient working capital to support our international operations. In the event that we elect to repatriate some or all of the foreign earnings that were previously deemed to be indefinitely reinvested outside the U.S., under current tax laws we would incur additional tax expense upon such repatriation.

[0000080420-19-000024:mdna:49]
[same as prior period, unchanged from 0000080420-19-000013:mdna:45]

[0000080420-19-000024:mdna:50]
Cash provided by operating activities increased to $33.9 million during the nine months ended June 30, 2019, compared to cash used in operating activities of $26.1 million during the same period in Fiscal 2018. This increase in operating cash flow for the nine months ended June 30, 2019 was primarily due to the completion and cash collection of contractual billing milestones, the collection of accounts receivable and the receipt of a $6.6 million income tax refund. Cash flow from operations is primarily influenced by project volume, the timing of milestone payments from our customers and the payment terms with our suppliers.

[0000080420-19-000024:mdna:51]
[same as prior period, unchanged from 0000080420-19-000013:mdna:47]

[0000080420-19-000024:mdna:52]
Net cash provided by investing activities during the nine months ended June 30, 2019 totaled $4.0 million compared to cash provided by investing activities of $6.8 million during the same period in Fiscal 2018. This decrease in cash provided by investing activities in the current period was primarily due to a decrease in the net maturities of short-term investments compared to the same period in the prior year.

[0000080420-19-000024:mdna:53]
[same as prior period, unchanged from 0000080420-19-000013:mdna:49]

[0000080420-19-000024:mdna:54]
Net cash used in financing activities was $10.5 million and $9.9 million during the nine months ended June 30, 2019 and 2018, respectively. These amounts primarily consisted of cash dividends of approximately $9.0 million during the nine months ended June 30, 2019 and $8.9 million during the nine months ended June 30, 2018.

[0000080420-19-000024:mdna:55]
[same as prior period, unchanged from 0000080420-19-000013:mdna:51]

[0000080420-19-000024:mdna:56]
[same as prior period, unchanged from 0000080420-19-000013:mdna:52]

[0000080420-19-000024:mdna:57]
[same as prior period, unchanged from 0000080420-19-000013:mdna:53]

[0000080420-19-000024:mdna:58]
[same as prior period, unchanged from 0000080420-19-000013:mdna:54]

[0000080420-19-000024:mdna:59]
[same as prior period, unchanged from 0000080420-19-000013:mdna:55]
