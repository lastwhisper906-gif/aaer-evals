# POWL 8-K — 0000080420-19-000022 filed 2019-08-06

## item codes, every 8-K on or before 2019-08-07

- 2019-08-06 0000080420-19-000022 — 2.02, 8.01, 9.01
- 2019-05-08 0000080420-19-000017 — 5.02, 9.01
- 2019-05-07 0000080420-19-000011 — 2.02, 8.01, 9.01
- 2019-02-22 0001193125-19-048366 — 5.07
- 2019-02-05 0000080420-19-000003 — 2.02, 8.01
- 2018-12-21 0000080420-18-000038 — 5.02, 9.01
- 2018-12-12 0000080420-18-000031 — 2.02
- 2018-11-05 0000080420-18-000029 — 8.01, 9.01
- 2018-11-01 0000080420-18-000027 — 5.02, 8.01, 9.01
- 2018-10-01 0000080420-18-000024 — 5.02
- 2018-08-07 0000080420-18-000020 — 2.02, 8.01
- 2018-05-15 0000080420-18-000016 — 5.02, 8.01
- 2018-05-09 0000080420-18-000011 — 2.02, 8.01
- 2018-02-22 0000080420-18-000009 — 5.07
- 2018-02-06 0000080420-18-000003 — 2.02, 8.01
- 2017-12-27 0001193125-17-379928 — 5.02
- 2017-12-05 0000080420-17-000028 — 2.02, 9.01
- 2017-11-08 0000080420-17-000024 — 8.01, 9.01
- 2017-11-03 0000080420-17-000022 — 5.02
- 2017-08-09 0000080420-17-000017 — 2.02, 8.01
- 2017-06-30 0000080420-17-000014 — 1.01, 9.01
- 2017-05-03 0000080420-17-000006 — 2.02, 8.01, 9.01
- 2017-02-23 0000080420-17-000004 — 5.07
- 2017-02-08 0001628280-17-000965 — 2.02 — amendment of 0001628280-17-000949
- 2017-02-07 0001628280-17-000949 — 2.01, 8.01, 9.01
- 2016-12-07 0001193125-16-787354 — 2.02, 9.01
- 2016-11-01 0001193125-16-755475 — 8.01, 9.01
- 2016-09-30 0001193125-16-726999 — 5.02, 8.01, 9.01
- 2016-08-03 0001193125-16-669308 — 2.02, 8.01, 9.01
- 2016-05-04 0001193125-16-576528 — 2.02, 8.01, 9.01
- 2016-02-25 0001193125-16-477896 — 5.07
- 2016-02-03 0001193125-16-449052 — 2.02, 8.01, 9.01
- 2015-12-31 0001193125-15-418363 — 5.02, 7.01, 9.01
- 2015-12-02 0001193125-15-393109 — 2.02, 9.01
- 2015-11-05 0001193125-15-368085 — 8.01, 9.01
- 2015-09-25 0001193125-15-329031 — 5.02
- 2015-08-05 0001193125-15-277912 — 2.02, 8.01, 9.01
- 2015-05-06 0001193125-15-174291 — 2.02, 8.01, 9.01
- 2015-03-06 0001193125-15-081070 — 5.02
- 2015-03-02 0001193125-15-072946 — 5.07
- 2015-02-03 0001193125-15-031772 — 2.02, 8.01, 9.01
- 2014-12-18 0001193125-14-446513 — 8.01, 9.01
- 2014-12-03 0001193125-14-431745 — 2.02, 9.01
- 2014-11-05 0001193125-14-397955 — 8.01, 9.01
- 2014-09-26 0001193125-14-353741 — 7.01, 9.01
- 2014-08-05 0001193125-14-296001 — 2.02, 8.01, 9.01
- 2014-05-07 0001193125-14-187496 — 2.02, 8.01, 9.01
- 2014-03-03 0001193125-14-079843 — 5.02, 5.07
- 2014-02-05 0001193125-14-036633 — 2.02, 8.01, 9.01
- 2014-01-17 0001193125-14-014351 — 1.01, 8.01, 9.01
- 2014-01-06 0001193125-14-002795 — 1.01, 2.03
- 2013-12-06 0001564590-13-001411 — 2.02, 9.01
- 2013-12-05 0001564590-13-001406 — 5.02, 8.01, 9.01
- 2013-11-07 0001193125-13-432950 — 8.01, 9.01
- 2013-08-07 0001193125-13-324337 — 2.02, 9.01
- 2013-05-08 0001193125-13-206800 — 2.02, 9.01
- 2013-02-22 0001193125-13-070971 — 5.02, 5.07
- 2013-02-06 0001193125-13-040556 — 2.02, 9.01
- 2012-12-18 0001193125-12-506417 — 5.02, 9.01
- 2012-12-05 0001193125-12-491749 — 2.02, 9.01
- 2012-10-12 0001193125-12-421889 — 3.03, 5.02, 5.03, 9.01
- 2012-08-09 0001193125-12-344617 — 5.02, 8.01, 9.01
- 2012-08-08 0001193125-12-343630 — 2.02, 9.01
- 2012-05-09 0001193125-12-221356 — 2.02, 9.01
- 2012-02-08 0001193125-12-046560 — 2.02, 9.01
- 2011-12-08 0001193125-11-334810 — 2.02, 9.01
- 2011-11-08 0000950123-11-096524 — 2.02, 2.06, 4.02, 9.01
- 2011-10-14 0000950123-11-090124 — 5.02
- 2011-10-06 0000950123-11-088969 — 5.02
- 2011-09-19 0000950123-11-085224 — 5.02, 9.01
- 2011-09-15 0000950123-11-084806 — 5.02, 9.01
- 2011-08-04 0000950123-11-072788 — 2.02, 9.01
- 2011-07-22 0000950123-11-067402 — 5.07
- 2011-05-24 0000950123-11-053550 — 1.01, 2.03, 9.01
- 2011-05-04 0000950123-11-044561 — 2.02, 9.01
- 2011-02-02 0000950123-11-008188 — 2.02, 9.01
- 2010-12-08 0000950123-10-111987 — 2.02, 9.01
- 2010-08-05 0000950123-10-073114 — 2.02, 9.01
- 2010-05-18 0000950123-10-050900 — 5.02
- 2010-05-05 0000950123-10-044499 — 2.02, 9.01
- 2010-02-03 0000950123-10-008278 — 2.02, 9.01
- 2009-12-21 0000950123-09-072269 — 1.01, 2.01, 2.03, 8.01, 9.01
- 2009-12-09 0000950123-09-069525 — 2.02, 9.01
- 2009-10-27 0000950123-09-053501 — 1.01, 8.01, 9.01
- 2009-08-04 0000950123-09-029476 — 2.02, 9.01
- 2009-05-06 0000950129-09-001498 — 2.02, 9.01
- 2009-03-05 0000950129-09-000749 — 1.01, 9.01
- 2009-02-10 0000950129-09-000349 — 2.02, 9.01
- 2008-12-10 0000950134-08-021934 — 2.02, 9.01
- 2008-08-06 0000950129-08-004267 — 2.02, 9.01
- 2008-07-24 0000950129-08-004063 — 1.01, 5.02, 8.01, 9.01
- 2008-06-16 0000950129-08-003500 — 9.01 — amendment of 0000950134-06-015374
- 2008-06-05 0000950129-08-003378 — 5.02, 9.01
- 2008-05-08 0000950129-08-002843 — 2.02, 9.01
- 2008-02-06 0000950129-08-000533 — 2.02, 9.01
- 2007-12-19 0000950129-07-006277 — 1.01, 2.03, 9.01
- 2007-12-06 0000950129-07-006003 — 2.02, 9.01
- 2007-08-21 0000950129-07-004181 — 2.02, 9.01
- 2007-05-31 0000950129-07-002810 — 2.02, 9.01
- 2007-05-21 0000950129-07-002668 — 2.02, 3.01, 4.02, 9.01
- 2007-04-16 0000950129-07-002002 — 2.02, 4.02, 9.01
- 2007-03-01 0000950129-07-001104 — 5.02, 8.01, 9.01
- 2007-02-08 0000950129-07-000451 — 2.02, 9.01
- 2006-12-08 0000950129-06-010041 — 2.02, 9.01
- 2006-09-08 0000950129-06-008379 — 2.02, 9.01
- 2006-08-09 0000950134-06-015374 — 1.01, 2.01, 8.01, 9.01
- 2006-06-08 0000950129-06-006127 — 2.02, 9.01
- 2006-03-09 0000950129-06-002455 — 2.02, 9.01
- 2005-12-16 0000950129-05-012031 — 2.02, 5.03, 9.01
- 2005-09-13 0000950129-05-009181 — 2.01, 9.01 — amendment of 0000950129-05-006889
- 2005-09-12 0000950129-05-009151 — 2.02, 9.01
- 2005-07-06 0000950129-05-006889 — 1.01, 1.02, 2.01, 2.03, 9.01
- 2005-06-10 0000950129-05-006128 — 2.02, 9.01
- 2005-04-20 0000080420-05-000031 — 5.02
- 2005-03-11 0000080420-05-000024 — 9.01
- 2005-02-25 0000080420-05-000018 — 7.01, 9.01
- 2005-01-21 0000080420-05-000009 — 7.01, 9.01
- 2004-12-17 0000080420-04-000049 — 2.02, 9.01
- 2004-11-01 0000080420-04-000045 — 8.01, 9.01
- 2004-10-08 0001169232-04-005133 — 2.05
- 2004-09-14 0000080420-04-000037 — 5.02
- 2004-09-02 0000080420-04-000030 — 2.02, 9.01
- 2004-06-08 0000080420-04-000021 — 7
- 2004-05-13 0000080420-04-000019 — 4
- 2004-02-27 0000080420-04-000013 — 7
- 2003-12-16 0000950129-03-006136 — 12, 7
- 2003-08-29 0000950129-03-004531 — 12, 7
- 2003-06-03 0000950129-03-003035 — 7, 9
- 2003-05-15 0000950129-03-002812 — 7, 9
- 2002-05-29 0000950129-02-002795 — 4
- 2000-12-21 0000950129-00-006093 — 5, 7
- 1998-09-04 0000950129-98-003802 — 5
- 1996-08-09 0000950129-96-001705 — 2, 7

## late-filing notifications on or before 2019-08-07

- 2007-05-11 0000950129-07-002494 — NT 10-Q, for the period ended 2007-03-31
- 2005-01-18 0000080420-05-000004 — NT 10-K, for the period ended 2004-10-31

## item 2.02 — earnings release, exhibit 99.1

[0000080420-19-000022:8k_2_02:1]
EX-99.1
2
ex991-q319earningsrelease.htm
EXHIBIT 99.1

[0000080420-19-000022:8k_2_02:2]
Exhibit

[0000080420-19-000022:8k_2_02:3]
Exhibit 99.1

[0000080420-19-000022:8k_2_02:4]
PRESS RELEASE

[0000080420-19-000022:8k_2_02:5]
FOR IMMEDIATE RELEASE

[0000080420-19-000022:8k_2_02:6]
Contacts:    Michael W. Metcalf, CFO

[0000080420-19-000022:8k_2_02:7]
Powell Industries, Inc.

[0000080420-19-000022:8k_2_02:8]
713-947-4422

[0000080420-19-000022:8k_2_02:9]
Ken Dennard / Natalie Hairston

[0000080420-19-000022:8k_2_02:10]
Dennard Lascar Investor Relations

[0000080420-19-000022:8k_2_02:11]
POWL@dennardlascar.com

[0000080420-19-000022:8k_2_02:12]
713-529-6600

[0000080420-19-000022:8k_2_02:13]
POWELL INDUSTRIES ANNOUNCES

[0000080420-19-000022:8k_2_02:14]
FISCAL 2019 THIRD QUARTER RESULTS

[0000080420-19-000022:8k_2_02:15]
Highest Backlog Since Fiscal 2016

[0000080420-19-000022:8k_2_02:16]
HOUSTON — AUGUST 6, 2019 — Powell Industries, Inc. (NASDAQ: POWL), a leading supplier of custom engineered solutions for the management, control and distribution of electrical energy, today announced results for the fiscal 2019 third quarter ended June 30, 2019.

[0000080420-19-000022:8k_2_02:17]
Revenues for the third quarter of fiscal 2019 were $135.6 million compared to revenues of $123.7 million for the second quarter of fiscal 2019 and revenues of $122.1 million for the third quarter of fiscal 2018.  The Company reported net income for the third quarter of $5.1 million, or $0.44 per diluted share, compared to net income of $1.0 million, or $0.08 per diluted share, for the second quarter of fiscal 2019 and net income of $0.3 million, or $0.03 per diluted share, for the third quarter of fiscal 2018.

[0000080420-19-000022:8k_2_02:18]
New orders placed during the third quarter of fiscal 2019 totaled $145 million compared to $197 million in the second quarter of fiscal 2019 and compared to $139 million in the third quarter of fiscal 2018.  The Company’s backlog as of June 30, 2019 was $407 million up 2.5% sequentially from $397 million as of March 31, 2019 and compared to $316 million at the end of last year’s third quarter.

[0000080420-19-000022:8k_2_02:19]
Brett A. Cope, Powell’s President and Chief Executive Officer, stated, “We continue to build on the momentum from the previous quarter, delivering on our customer commitments while also improving the utilization of our people and facilities.  Our third quarter results reflect our continued focus on operational execution across the company while we continue to work towards an improved quality and mix of our backlog.”

[0000080420-19-000022:8k_2_02:20]
Cope added, “Powell’s $145 million of new orders in the third quarter were driven more broadly from our core oil, gas, and petrochemical customers, as well as the industrial and utility sectors from both domestic and international markets. We enter the fourth quarter with a strong backlog and a healthy funnel of inquiry activity, particularly in the US Gulf Coast region where we continue to support the development of several, larger projects driven in part by the availability of low cost natural gas.”

[0000080420-19-000022:8k_2_02:21]
OUTLOOK

[0000080420-19-000022:8k_2_02:22]
Commenting on the company's outlook, Michael Metcalf, Powell’s Chief Financial Officer said, “Looking ahead, we expect continued growth across our key end markets, specifically within the industrial sector.  Similar to the third quarter, our fourth quarter focus on operational priorities should generate increased productivity from both volume leverage and associated SG&A cost efficiencies, all of which are providing margin uplift.  Additionally, we expect to deliver solid operating cash flow through the remainder of fiscal 2019 with strong working capital discipline.”

[0000080420-19-000022:8k_2_02:23]
“Finally, we anticipate that our customer focus, coupled with sustained end market activity will provide a platform for continued profitability in the fourth quarter of fiscal 2019 and into fiscal 2020,” Metcalf concluded.

[0000080420-19-000022:8k_2_02:24]
CONFERENCE CALL

[0000080420-19-000022:8k_2_02:25]
Powell Industries has scheduled a conference call for Wednesday, August 7, 2019 at 11:00 a.m. Eastern time.  To participate in the conference call, dial 412-902-0030 at least 10 minutes before the call begins and ask for the Powell Industries conference call.  A replay of the call will be available approximately two hours after the live broadcast ends and will be accessible until August 14, 2019.  To access the replay, dial 201-612-7415 using a passcode of 13691710#.

[0000080420-19-000022:8k_2_02:26]
Investors, analysts and the general public will also have the opportunity to listen to the conference call over the Internet by visiting powellind.com. To listen to the live call on the web,

[0000080420-19-000022:8k_2_02:27]
please visit the website at least 15 minutes before the call begins to register, download and install any necessary audio software.  For those who cannot listen to the live webcast, an archive will be available shortly after the call and will remain available for approximately 90 days at powellind.com.

[0000080420-19-000022:8k_2_02:28]
Powell Industries, Inc., headquartered in Houston, designs, manufactures and services custom-engineered equipment and systems for the distribution, control and monitoring of electrical energy.  Powell markets include large industrial customers such as utilities, oil and gas producers, refineries, petrochemical plants, pulp and paper producers, mining operations and commuter railways.   For more information, please visit powellind.com.

[0000080420-19-000022:8k_2_02:29]
3

[0000080420-19-000022:8k_2_02:30]
POWELL INDUSTRIES, INC. & SUBSIDIARIES

[0000080420-19-000022:8k_2_02:31]
CONSOLIDATED STATEMENT OF OPERATIONS

[0000080420-19-000022:8k_2_02:32]
|  | Three Months EndedJune 30, |  | Nine Months EndedJune 30, |
|  | 2019 |  | 2018 |  | 2019 |  | 2018 |
| (In thousands, except per share data) |  |  |  |  |  |  |  |
|  | (Unaudited) |
| Revenues | $ | 135,588 |  |  | $ | 122,130 |  |  | $ | 368,676 |  |  | $ | 313,819 |  |
| Cost of goods sold | 111,873 |  |  | 103,755 |  |  | 310,255 |  |  | 272,469 |  |
| Gross profit | 23,715 |  |  | 18,375 |  |  | 58,421 |  |  | 41,350 |  |
| Selling, general and administrative expenses | 17,117 |  |  | 16,174 |  |  | 50,240 |  |  | 48,462 |  |
| Research and development expenses | 1,631 |  |  | 1,632 |  |  | 4,988 |  |  | 4,926 |  |
| Amortization of intangible assets | 44 |  |  | 44 |  |  | 132 |  |  | 161 |  |
| Insurance proceeds | (950 | ) |  | — |  |  | (950 | ) |  | — |  |
| Restructuring and other, net | 233 |  |  | — |  |  | 233 |  |  | — |  |
| Operating income (loss) | 5,640 |  |  | 525 |  |  | 3,778 |  |  | (12,199 | ) |
| Other income | — |  |  | — |  |  | — |  |  | (507 | ) |
| Interest expense | 59 |  |  | 51 |  |  | 170 |  |  | 153 |  |
| Interest income | (305 | ) |  | (215 | ) |  | (707 | ) |  | (711 | ) |
| Income (loss) before income taxes | 5,886 |  |  | 689 |  |  | 4,315 |  |  | (11,134 | ) |
| Income tax expense (benefit) | 797 |  |  | 388 |  |  | 963 |  |  | (2,443 | ) |
| Net income (loss) | $ | 5,089 |  |  | $ | 301 |  |  | $ | 3,352 |  |  | $ | (8,691 | ) |
| Income (loss) per share: |  |  |  |  |  |  |  |
| Basic | $ | 0.44 |  |  | $ | 0.03 |  |  | $ | 0.29 |  |  | $ | (0.76 | ) |
| Diluted | $ | 0.44 |  |  | $ | 0.03 |  |  | $ | 0.29 |  |  | $ | (0.76 | ) |
| Weighted average shares: |  |  |  |  |  |  |  |
| Basic | 11,579 |  |  | 11,514 |  |  | 11,567 |  |  | 11,503 |  |
| Diluted | 11,603 |  |  | 11,587 |  |  | 11,589 |  |  | 11,503 |  |
| SELECTED FINANCIAL DATA: |  |  |  |  |  |  |  |
| Depreciation and Amortization | $ | 2,948 |  |  | $ | 3,231 |  |  | $ | 9,408 |  |  | $ | 9,655 |  |
| Capital Expenditures | $ | 1,269 |  |  | $ | 1,163 |  |  | $ | 3,241 |  |  | $ | 3,978 |  |
| Dividends Paid | $ | 3,003 |  |  | $ | 2,980 |  |  | $ | 8,991 |  |  | $ | 8,934 |  |

[0000080420-19-000022:8k_2_02:33]
4

[0000080420-19-000022:8k_2_02:34]
POWELL INDUSTRIES, INC. & SUBSIDIARIES

[0000080420-19-000022:8k_2_02:35]
CONSOLIDATED BALANCE SHEETS

[0000080420-19-000022:8k_2_02:36]
|  | June 30, 2019 |  | September 30, 2018 |
| (In thousands) | (Unaudited) |
| Assets: |  |  |  |
| Cash, cash equivalents and short-term investments | $ | 78,030 |  |  | $ | 49,754 |  |
| Restricted cash | 8,188 |  |  | 19,154 |  |
| Other current assets | 201,052 |  |  | 207,754 |  |
| Property, plant and equipment (net) | 121,909 |  |  | 128,764 |  |
| Restricted cash (non-current) | 8,476 |  |  | 5,987 |  |
| Long-term assets | 19,451 |  |  | 18,538 |  |
| Total assets | $ | 437,106 |  |  | $ | 429,951 |  |
| Liabilities and equity: |  |  |  |
| Current liabilities | $ | 129,801 |  |  | $ | 117,849 |  |
| Long-term debt, net of current maturities | 800 |  |  | 1,200 |  |
| Deferred and other long-term liabilities | 10,846 |  |  | 9,258 |  |
| Stockholders’ equity | 295,659 |  |  | 301,644 |  |
| Total liabilities and stockholders’ equity | $ | 437,106 |  |  | $ | 429,951 |  |
| SELECTED FINANCIAL DATA: |  |  |  |
| Working capital | $ | 157,469 |  |  | $ | 158,813 |  |
