# POWL note change history — 0000080420-20-000005 → 0000080420-20-000020


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2020-05-06):
[0000080420-20-000020:note_history:1]
Certain customers require us to post letters of credit, bank guarantees or surety bonds. These security instruments assure that we will perform under the terms of our contract. In the event of default, the counterparty may demand payment from the bank under a letter of credit or bank guarantee, or performance by the surety under a bond. To date, there have been no significant draws or claims related to security instruments for the periods reported. We were contingently liable for letters of credit of $35.1 million as of March 31, 2020. We also had surety bonds totaling $162.8 million that were outstanding, with additional bonding capacity of $587.2 million available, at March 31, 2020.
  (was, 2020-02-05, similarity 0.9807):
[0000080420-20-000005:note_history:1]
Certain customers require us to post letters of credit, bank guarantees or surety bonds. These security instruments assure that we will perform under the terms of our contract. In the event of default, the counterparty may demand payment from the bank under a letter of credit or bank guarantee, or performance by the surety under a bond. To date, there have been no significant draws or claims related to security instruments for the periods reported. We were contingently liable for letters of credit of $13.4 million as of December 31, 2019. We also had surety bonds totaling $180.0 million that were outstanding, with additional bonding capacity of $570.0 million available, at December 31, 2019.

- changed (2020-05-06):
[0000080420-20-000020:note_history:2]
We have an $11.1 million facility agreement (Facility Agreement) between Powell (UK) Limited and a large international bank that provides Powell (UK) Limited the ability to enter into bank guarantees as well as forward exchange contracts and currency options. At March 31, 2020, we had outstanding guarantees totaling $3.1 million and amounts available under this Facility Agreement were $8.0 million. The Facility Agreement expires in May 2020 and provides for financial covenants and customary events of default, and carries cross-default provisions with our U.S. Revolver. If an event of default (as defined in the Facility Agreement) occurs and is continuing, per the terms and subject to the conditions set forth therein, obligations outstanding under the Facility Agreement may be accelerated and declared immediately due and payable. As of March 31, 2020, we were in compliance with all of the financial covenants of the Facility Agreement.
  (was, 2020-02-05, similarity 0.986):
[0000080420-20-000005:note_history:2]
We have an $11.9 million facility agreement (Facility Agreement) between Powell (UK) Limited and a large international bank that provides Powell (UK) Limited the ability to enter into bank guarantees as well as forward exchange contracts and currency options. At December 31, 2019, we had outstanding guarantees totaling $5.2 million and amounts available under this Facility Agreement were $6.7 million. The Facility Agreement expires in May 2020 and provides for financial covenants and customary events of default, and carries cross-default provisions with our U.S. Revolver. If an event of default (as defined in the Facility Agreement) occurs and is continuing, per the terms and subject to the conditions set forth therein, obligations outstanding under the Facility Agreement may be accelerated and declared immediately due and payable. As of December 31, 2019, we were in compliance with all of the financial covenants of the Facility Agreement.


## us-gaap:LongTermDebtTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2020-05-06):
[0000080420-20-000020:note_history:3]
|  | March 31, 2020 |  | September 30, 2019 |
| Industrial development revenue bonds | $ | 800 |  |  | $ | 1,200 |  |
| Less: current portion | (400 | ) |  | (400 | ) |
| Total long-term debt | $ | 400 |  |  | $ | 800 |  |
  (was, 2020-02-05, similarity 0.9764):
[0000080420-20-000005:note_history:3]
|  | December 31, 2019 |  | September 30, 2019 |
| Industrial development revenue bonds | $ | 800 |  |  | $ | 1,200 |  |
| Less: current portion | (400 | ) |  | (400 | ) |
| Total long-term debt | $ | 400 |  |  | $ | 800 |  |

- changed (2020-05-06):
[0000080420-20-000020:note_history:4]
On September 27, 2019, we entered into an Amended and Restated Credit Agreement with Bank of America, N.A. (the " "U.S. Revolver"), which replaced our prior credit agreement. The U.S. Revolver is a $75.0 million revolving credit facility that is available for both borrowings and letters of credit and expires September 2024. As of March 31, 2020, there were no amounts borrowed under this facility and letters of credit outstanding were $35.1 million. There was $39.9 million available for the issuance of letters of credit and borrowings under the U.S. Revolver as of March 31, 2020.
  (was, 2020-02-05, similarity 0.9686):
[0000080420-20-000005:note_history:4]
On September 27, 2019, we entered into an Amended and Restated Credit Agreement with Bank of America, N.A. (the " "U.S. Revolver"), which replaced our prior credit agreement. The U.S. Revolver is a $75.0 million revolving credit facility, that is available for both borrowings and letters of credit and expires September 2024. As of December 31, 2019, there were no amounts borrowed under this facility and letters of credit outstanding were $13.4 million. There was $61.6 million available for the issuance of letters of credit and borrowings under the U.S. Revolver as of December 31, 2019.

- changed (2020-05-06):
[0000080420-20-000020:note_history:5]
We are required to maintain certain financial covenants, the most significant of which are a consolidated leverage ratio less than 3.0 to 1.0 and a consolidated interest coverage ratio of greater than 3.0 to 1.0. Additionally, we must maintain a consolidated cash balance of $30 million at all times. The U.S. Revolver also contains a "material adverse effect" clause which is a material change in our operations, business, properties, liabilities or condition (financial or otherwise) or a material impairment of our ability to perform our obligations under our credit agreements. As of March 31, 2020, we were in compliance with all of the financial covenants of the U.S. Revolver.
  (was, 2020-02-05, similarity 0.9903):
[0000080420-20-000005:note_history:5]
We are required to maintain certain financial covenants, the most significant of which are a consolidated leverage ratio less than 3.0 to 1.0 and a consolidated interest coverage ratio of greater than 3.0 to 1.0. Additionally, we must maintain a consolidated cash balance of $30 million at all times. The U.S. Revolver also contains a "material adverse effect" clause which is a material change in our operations, business, properties, liabilities or condition (financial or otherwise) or a material impairment of our ability to perform our obligations under our credit agreements. As of December 31, 2019, we were in compliance with all of the financial covenants of the U.S. Revolver.

- changed (2020-05-06):
[0000080420-20-000020:note_history:6]
We borrowed $8.0 million in October 2001 through a loan agreement funded with proceeds from tax-exempt industrial development revenue bonds (Bonds). These Bonds were issued by the Illinois Development Finance Authority and were used for the completion of our Northlake, Illinois facility. Pursuant to the Bond issuance, a reimbursement agreement between us and a major domestic bank required an issuance by the bank of an irrevocable direct-pay letter of credit (Bond LC), as collateral, to the Bonds’ trustee to guarantee payment of the Bonds’ principal and interest when due. The Bond LC is subject to both early termination and extension provisions customary to such agreements, as well as various covenants, for which we were in compliance at March 31, 2020. While the Bonds mature in 2021, the reimbursement agreement requires annual redemptions of $0.4 million that commenced on October 25, 2002. A sinking fund is used for the annual principal payment. The Bonds bear interest at a floating rate determined weekly by the Bonds’ remarketing agent, which was the underwriter for the Bonds and is an affiliate of the bank. This interest rate was 5.08% as of March 31, 2020 and subsequently declined to 0.57% as of April 30, 2020.
  (was, 2020-02-05, similarity 0.9684):
[0000080420-20-000005:note_history:6]
We borrowed $8.0 million in October 2001 through a loan agreement funded with proceeds from tax-exempt industrial development revenue bonds (Bonds). These Bonds were issued by the Illinois Development Finance Authority and were used for the completion of our Northlake, Illinois facility. Pursuant to the Bond issuance, a reimbursement agreement between us and a major domestic bank required an issuance by the bank of an irrevocable direct-pay letter of credit (Bond LC), as collateral, to the Bonds’ trustee to guarantee payment of the Bonds’ principal and interest when due. The Bond LC is subject to both early termination and extension provisions customary to such agreements, as well as various covenants, for which we were in compliance at December 31, 2019. While the Bonds mature in 2021, the reimbursement agreement requires annual redemptions of $0.4 million that commenced on October 25, 2002. A sinking fund is used for the annual principal payment. The Bonds bear interest at a floating rate determined weekly by the Bonds’ remarketing agent, which was the underwriter for the Bonds and is an affiliate of the bank. This interest rate was 1.79% as of December 31, 2019.


## us-gaap:ScheduleOfDebtInstrumentsTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2020-05-06):
[0000080420-20-000020:note_history:7]
|  | March 31, 2020 |  | September 30, 2019 |
| Industrial development revenue bonds | $ | 800 |  |  | $ | 1,200 |  |
| Less: current portion | (400 | ) |  | (400 | ) |
| Total long-term debt | $ | 400 |  |  | $ | 800 |  |
  (was, 2020-02-05, similarity 0.9764):
[0000080420-20-000005:note_history:7]
|  | December 31, 2019 |  | September 30, 2019 |
| Industrial development revenue bonds | $ | 800 |  |  | $ | 1,200 |  |
| Less: current portion | (400 | ) |  | (400 | ) |
| Total long-term debt | $ | 400 |  |  | $ | 800 |  |


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2020-05-06):
[0000080420-20-000020:note_history:8]
The following tables present our disaggregated revenue by geographic destination and market sector for the six months ended March 31, 2020 and 2019 (in thousands):
  (was, 2020-02-05, similarity 0.946):
[0000080420-20-000005:note_history:8]
The following tables present our disaggregated revenue by geographic destination and market sector for the three months ended December 31, 2019 and 2018 (in thousands):

- changed (2020-05-06):
[0000080420-20-000020:note_history:9]
|  | Three months ended March 31, |  | Six months ended March 31, |
|  | 2020 |  | 2019 |  | 2020 |  | 2019 |
| United States | $ | 121,432 |  |  | $ | 102,406 |  |  | $ | 228,510 |  |  | $ | 192,304 |  |
| Canada | 15,407 |  |  | 15,094 |  |  | 29,861 |  |  | 24,809 |  |
| Europe, Middle East and Africa | 8,816 |  |  | 5,508 |  |  | 18,982 |  |  | 10,949 |  |
| Asia/Pacific | 5,456 |  |  | 729 |  |  | 7,142 |  |  | 4,473 |  |
| Mexico, Central and South America | 459 |  |  | — |  |  | 1,225 |  |  | 553 |  |
| Total revenues by geographic destination | $ | 151,570 |  |  | $ | 123,737 |  |  | $ | 285,720 |  |  | $ | 233,088 |  |
  (was, 2020-02-05, similarity 0.7125):
[0000080420-20-000005:note_history:9]
|  | Three months ended December 31, 2019 |  | Three months ended December 31, 2018 |
| United States | $ | 107,078 |  |  | $ | 89,898 |  |
| Canada | 14,454 |  |  | 9,715 |  |
| Europe, Middle East and Africa | 10,166 |  |  | 5,441 |  |
| Asia/Pacific | 1,686 |  |  | 3,744 |  |
| Mexico, Central and South America | 766 |  |  | 553 |  |
| Total revenues by geographic destination | $ | 134,150 |  |  | $ | 109,351 |  |

- changed (2020-05-06):
[0000080420-20-000020:note_history:10]
|  | Three months ended March 31, |  | Six months ended March 31, |
|  | 2020 |  | 2019 |  | 2020 |  | 2019 |
| Oil and gas | $ | 51,954 |  |  | $ | 56,022 |  |  | $ | 111,948 |  |  | $ | 105,598 |  |
| Petrochemical | 47,337 |  |  | 22,523 |  |  | 77,763 |  |  | 42,301 |  |
| Electric utility | 24,255 |  |  | 20,383 |  |  | 47,270 |  |  | 39,641 |  |
| Traction power | 13,944 |  |  | 6,025 |  |  | 22,295 |  |  | 11,034 |  |
| All others | 14,080 |  |  | 18,784 |  |  | 26,444 |  |  | 34,514 |  |
| Total revenues by market sector | $ | 151,570 |  |  | $ | 123,737 |  |  | $ | 285,720 |  |  | $ | 233,088 |  |
  (was, 2020-02-05, similarity 0.6704):
[0000080420-20-000005:note_history:10]
|  | Three months ended December 31, 2019 |  | Three months ended December 31, 2018 |
| Oil and gas | $ | 59,994 |  |  | $ | 49,576 |  |
| Petrochemical | 30,426 |  |  | 19,778 |  |
| Electric utility | 23,015 |  |  | 19,258 |  |
| Traction power | 8,351 |  |  | 5,009 |  |
| All others | 12,364 |  |  | 15,730 |  |
| Total revenues by market sector | $ | 134,150 |  |  | $ | 109,351 |  |


## us-gaap:RevenueFromContractWithCustomerPolicyTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2020-05-06):
[0000080420-20-000020:note_history:11]
We also have contracts to provide value-added services such as field service inspection, installation, commissioning, modification and repair, as well as retrofit and retrofill components for existing systems.  As a practical expedient, if the service contract terms give us the right to invoice the customer for an amount that corresponds directly with the value of our performance completed to date (i.e., a service contract in which we bill a fixed amount for each hour of service provided), then we recognize revenue over time in each reporting period corresponding to the amount with which we have the right to invoice.  Our performance obligations are satisfied as the work progresses. Revenues from our custom-engineered products and value-added services transferred to customers over time accounted for approximately 96% of total revenues for the three and six months ended March 31, 2020 and 93% of total revenues for the three and six months ended March 31, 2019.
  (was, 2020-02-05, similarity 0.9304):
[0000080420-20-000005:note_history:11]
We also have contracts to provide value-added services such as field service inspection, installation, commissioning, modification and repair, as well as retrofit and retrofill components for existing systems.  As a practical expedient, if the service contract terms give us the right to invoice the customer for an amount that corresponds directly with the value of our performance completed to date (i.e., a service contract in which we bill a fixed amount for each hour of service provided), then we recognize revenue over time in each reporting period corresponding to the amount with which we have the right to invoice.  Our performance obligations are satisfied as the work progresses. Revenues from our custom-engineered products and value-added services transferred to customers over time accounted for approximately 95% and 93% of total revenues for the three months ended December 31, 2019 and 2018, respectively.

- changed (2020-05-06):
[0000080420-20-000020:note_history:12]
We also have sales orders for spare parts and replacement circuit breakers for switchgear that are obsolete or that are no longer produced by the original manufacturer. Revenues from these sales orders are recognized at the time we fulfill our performance obligation to the customer, which is typically upon shipment and represented approximately 4% of total revenues for the three and six months ended March 31, 2020 and 7% of total revenues for the three and six months ended March 31, 2019.
  (was, 2020-02-05, similarity 0.8581):
[0000080420-20-000005:note_history:12]
We also have sales orders for spare parts and replacement circuit breakers for switchgear that are obsolete or that are no longer produced by the original manufacturer. Revenues from these sales orders are recognized at the time we fulfill our performance obligation to the customer, which is typically upon shipment and represented approximately 5% and 7% of total revenues for the three months ended December 31, 2019 and 2018, respectively.

- changed (2020-05-06):
[0000080420-20-000020:note_history:13]
Contract assets are recorded when revenues are recognized in excess of amounts billed for fixed-price contracts as determined by the billing milestone schedule. Contract assets are transferred to accounts receivable when billing milestones have been met, or we have an unconditional right to payment.
  (was, 2020-02-05, similarity 0.9983):
[0000080420-20-000005:note_history:13]
Contract assets are recorded when revenues are recognized in excess of amounts billed for fixed-price contracts as determined by the billing milestone schedule. Contract assets are transferred to accounts receivables when billing milestones have been met, or we have an unconditional right to payment.


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2020-05-06):
[0000080420-20-000020:note_history:14]
We also have contracts to provide value-added services such as field service inspection, installation, commissioning, modification and repair, as well as retrofit and retrofill components for existing systems.  As a practical expedient, if the service contract terms give us the right to invoice the customer for an amount that corresponds directly with the value of our performance completed to date (i.e., a service contract in which we bill a fixed amount for each hour of service provided), then we recognize revenue over time in each reporting period corresponding to the amount with which we have the right to invoice.  Our performance obligations are satisfied as the work progresses. Revenues from our custom-engineered products and value-added services transferred to customers over time accounted for approximately 96% of total revenues for the three and six months ended March 31, 2020 and 93% of total revenues for the three and six months ended March 31, 2019.
  (was, 2020-02-05, similarity 0.9304):
[0000080420-20-000005:note_history:14]
We also have contracts to provide value-added services such as field service inspection, installation, commissioning, modification and repair, as well as retrofit and retrofill components for existing systems.  As a practical expedient, if the service contract terms give us the right to invoice the customer for an amount that corresponds directly with the value of our performance completed to date (i.e., a service contract in which we bill a fixed amount for each hour of service provided), then we recognize revenue over time in each reporting period corresponding to the amount with which we have the right to invoice.  Our performance obligations are satisfied as the work progresses. Revenues from our custom-engineered products and value-added services transferred to customers over time accounted for approximately 95% and 93% of total revenues for the three months ended December 31, 2019 and 2018, respectively.

- changed (2020-05-06):
[0000080420-20-000020:note_history:15]
We also have sales orders for spare parts and replacement circuit breakers for switchgear that are obsolete or that are no longer produced by the original manufacturer. Revenues from these sales orders are recognized at the time we fulfill our performance obligation to the customer, which is typically upon shipment and represented approximately 4% of total revenues for the three and six months ended March 31, 2020 and 7% of total revenues for the three and six months ended March 31, 2019.
  (was, 2020-02-05, similarity 0.8581):
[0000080420-20-000005:note_history:15]
We also have sales orders for spare parts and replacement circuit breakers for switchgear that are obsolete or that are no longer produced by the original manufacturer. Revenues from these sales orders are recognized at the time we fulfill our performance obligation to the customer, which is typically upon shipment and represented approximately 5% and 7% of total revenues for the three months ended December 31, 2019 and 2018, respectively.

- changed (2020-05-06):
[0000080420-20-000020:note_history:16]
Remaining unsatisfied performance obligations, which we refer to as backlog, represent the estimated transaction price for goods and services for which we have a material right but work has not been performed. As of March 31, 2020, we had backlog of $566.4 million, of which approximately $342.9 million is expected to be recognized as revenue within the next twelve months. Backlog may not be indicative of future operating results as orders may be cancelled or modified by our customers. Our backlog does not include service and maintenance-type contracts for which we have the right to invoice as services are performed.
  (was, 2020-02-05, similarity 0.9894):
[0000080420-20-000005:note_history:16]
Remaining unsatisfied performance obligations, which we refer to as backlog, represent the estimated transaction price for goods and services for which we have a material right but work has not been performed. As of December 31, 2019, we had backlog of $425.9 million, of which approximately $367.4 million is expected to be recognized as revenue within the next twelve months. Backlog may not be indicative of future operating results as orders may be cancelled or modified by our customers. Our backlog does not include service and maintenance-type contracts for which we have the right to invoice as services are performed.

- changed (2020-05-06):
[0000080420-20-000020:note_history:17]
For the six months ended March 31, 2020 and 2019, our operating results were positively impacted by $9.0 million and $4.3 million, respectively, as a result of changes in contract estimates related to projects in progress at the beginning of the respective period. These changes in estimates resulted primarily from favorable project execution and negotiations of variable consideration, discussed below, as well as other changes in facts and circumstances during these periods.
  (was, 2020-02-05, similarity 0.9476):
[0000080420-20-000005:note_history:17]
For the three months ended December 31, 2019 and 2018, our operating results were positively impacted by $4.3 million and $3.1 million, respectively, as a result of changes in contract estimates related to projects in progress at the beginning of the respective period. These changes in estimates resulted primarily from favorable project execution and negotiations of variable consideration, discussed below, as well as other changes in facts and circumstances during these periods.

- changed (2020-05-06):
[0000080420-20-000020:note_history:18]
Contract assets are recorded when revenues are recognized in excess of amounts billed for fixed-price contracts as determined by the billing milestone schedule. Contract assets are transferred to accounts receivable when billing milestones have been met, or we have an unconditional right to payment.
  (was, 2020-02-05, similarity 0.9983):
[0000080420-20-000005:note_history:18]
Contract assets are recorded when revenues are recognized in excess of amounts billed for fixed-price contracts as determined by the billing milestone schedule. Contract assets are transferred to accounts receivables when billing milestones have been met, or we have an unconditional right to payment.

- changed (2020-05-06):
[0000080420-20-000020:note_history:19]
Contract assets and liabilities as of March 31, 2020 and September 30, 2019 are summarized below (in thousands):
  (was, 2020-02-05, similarity 0.9565):
[0000080420-20-000005:note_history:19]
Contract assets and liabilities as of December 31, 2019 and September 30, 2019 are summarized below (in thousands):

- changed (2020-05-06):
[0000080420-20-000020:note_history:20]
|  | March 31, 2020 |  | September 30, 2019 |
| Contract assets | $ | 61,336 |  |  | $ | 55,374 |  |
| Contract liabilities | (57,821 | ) |  | (71,464 | ) |
| Net contract asset (liability) | $ | 3,515 |  |  | $ | (16,090 | ) |
  (was, 2020-02-05, similarity 0.9672):
[0000080420-20-000005:note_history:20]
|  | December 31, 2019 |  | September 30, 2019 |
| Contract assets | $ | 60,296 |  |  | $ | 55,374 |  |
| Contract liabilities | (77,556 | ) |  | (71,464 | ) |
| Net contract asset (liability) | $ | (17,260 | ) |  | $ | (16,090 | ) |

- changed (2020-05-06):
[0000080420-20-000020:note_history:21]
The increase in net contract asset at March 31, 2020 from September 30, 2019 was primarily due to our progress towards completion on our projects and the timing of contract billing milestones and new orders. To determine the amount of revenue recognized during the period from contract liabilities, we first allocate revenue to the individual contract liability balance outstanding at the beginning of the period until the revenue exceeds that balance. During the three and six months ended March 31, 2020, we recognized revenue of approximately $50.8 million and $65.0 million related to contract liabilities outstanding at September 30, 2019.
  (was, 2020-02-05, similarity 0.7646):
[0000080420-20-000005:note_history:21]
The increase in net contract liability at December 31, 2019 from September 30, 2019 was primarily due to our progress towards completion on our projects and the timing of contract billing milestones and new orders. To determine the amount of revenue recognized during the period from contract liabilities, we first allocate revenue to the individual contract liability balance outstanding at the beginning of the period until the revenue exceeds that balance. During the three months ended December 31, 2019, we recognized revenue of approximately $45.6 million related to contract liabilities outstanding at September 30, 2019.

- changed (2020-05-06):
[0000080420-20-000020:note_history:22]
The timing of our invoice process is typically dependent on the completion of certain milestones and contract terms and subject to agreement by our customer.  Payment is typically expected within 30 days of invoice. Any uncollected invoiced amounts for our performance obligations recognized over time, including contract retentions, are recorded as accounts receivable in the Condensed Consolidated Balance Sheets. Certain contracts contain retention provisions that become due upon completion of contractual requirements. As of March 31, 2020 and September 30, 2019, accounts receivable included retention amounts of $6.0 million and $5.6 million, respectively. Of the retained amount at March 31, 2020, $3.7 million is expected to be collected in the next twelve months and is recorded in accounts receivable. The remaining $2.3 million is recorded in other assets.
  (was, 2020-02-05, similarity 0.9846):
[0000080420-20-000005:note_history:22]
The timing of our invoice process is typically dependent on the completion of certain milestones and contract terms and subject to agreement by our customer.  Payment is typically expected within 30 days of invoice. Any uncollected invoiced amounts for our performance obligations recognized over time, including contract retentions, are recorded as accounts receivable in the Condensed Consolidated Balance Sheets. Certain contracts contain retention provisions that become due upon completion of contractual requirements. As of December 31, 2019 and September 30, 2019, accounts receivable included retention amounts of $5.9 million and $5.6 million, respectively. Of the retained amount at December 31, 2019, $5.6 million is expected to be collected in the next twelve months and is recorded in accounts receivable. The remaining $0.3 million is recorded in other assets.

- changed (2020-05-06):
[0000080420-20-000020:note_history:23]
The following tables present our disaggregated revenue by geographic destination and market sector for the six months ended March 31, 2020 and 2019 (in thousands):
  (was, 2020-02-05, similarity 0.946):
[0000080420-20-000005:note_history:23]
The following tables present our disaggregated revenue by geographic destination and market sector for the three months ended December 31, 2019 and 2018 (in thousands):

- changed (2020-05-06):
[0000080420-20-000020:note_history:24]
|  | Three months ended March 31, |  | Six months ended March 31, |
|  | 2020 |  | 2019 |  | 2020 |  | 2019 |
| United States | $ | 121,432 |  |  | $ | 102,406 |  |  | $ | 228,510 |  |  | $ | 192,304 |  |
| Canada | 15,407 |  |  | 15,094 |  |  | 29,861 |  |  | 24,809 |  |
| Europe, Middle East and Africa | 8,816 |  |  | 5,508 |  |  | 18,982 |  |  | 10,949 |  |
| Asia/Pacific | 5,456 |  |  | 729 |  |  | 7,142 |  |  | 4,473 |  |
| Mexico, Central and South America | 459 |  |  | — |  |  | 1,225 |  |  | 553 |  |
| Total revenues by geographic destination | $ | 151,570 |  |  | $ | 123,737 |  |  | $ | 285,720 |  |  | $ | 233,088 |  |
  (was, 2020-02-05, similarity 0.7125):
[0000080420-20-000005:note_history:24]
|  | Three months ended December 31, 2019 |  | Three months ended December 31, 2018 |
| United States | $ | 107,078 |  |  | $ | 89,898 |  |
| Canada | 14,454 |  |  | 9,715 |  |
| Europe, Middle East and Africa | 10,166 |  |  | 5,441 |  |
| Asia/Pacific | 1,686 |  |  | 3,744 |  |
| Mexico, Central and South America | 766 |  |  | 553 |  |
| Total revenues by geographic destination | $ | 134,150 |  |  | $ | 109,351 |  |

- changed (2020-05-06):
[0000080420-20-000020:note_history:25]
|  | Three months ended March 31, |  | Six months ended March 31, |
|  | 2020 |  | 2019 |  | 2020 |  | 2019 |
| Oil and gas | $ | 51,954 |  |  | $ | 56,022 |  |  | $ | 111,948 |  |  | $ | 105,598 |  |
| Petrochemical | 47,337 |  |  | 22,523 |  |  | 77,763 |  |  | 42,301 |  |
| Electric utility | 24,255 |  |  | 20,383 |  |  | 47,270 |  |  | 39,641 |  |
| Traction power | 13,944 |  |  | 6,025 |  |  | 22,295 |  |  | 11,034 |  |
| All others | 14,080 |  |  | 18,784 |  |  | 26,444 |  |  | 34,514 |  |
| Total revenues by market sector | $ | 151,570 |  |  | $ | 123,737 |  |  | $ | 285,720 |  |  | $ | 233,088 |  |
  (was, 2020-02-05, similarity 0.6704):
[0000080420-20-000005:note_history:25]
|  | Three months ended December 31, 2019 |  | Three months ended December 31, 2018 |
| Oil and gas | $ | 59,994 |  |  | $ | 49,576 |  |
| Petrochemical | 30,426 |  |  | 19,778 |  |
| Electric utility | 23,015 |  |  | 19,258 |  |
| Traction power | 8,351 |  |  | 5,009 |  |
| All others | 12,364 |  |  | 15,730 |  |
| Total revenues by market sector | $ | 134,150 |  |  | $ | 109,351 |  |


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: tag_name, score: 1.0

- added (2020-05-06):
[0000080420-20-000020:note_history:26]
Quarterly Dividend Declared

- changed (2020-05-06):
[0000080420-20-000020:note_history:27]
On May 5, 2020, our Board of Directors declared a quarterly cash dividend on our common stock in the amount of $0.26 per share. The dividend is payable on June 17, 2020 to shareholders of record at the close of business on May 20, 2020.
  (was, 2020-02-05, similarity 0.6517):
[0000080420-20-000005:note_history:27]
On February 4, 2020, our Board of Directors declared a quarterly cash dividend on our common stock in the amount of $0.26 per share. The dividend is payable on March 18, 2020 to shareholders of record at the close of business on February 19, 2020.

- added (2020-05-06):
[0000080420-20-000020:note_history:28]
Impact of the COVID-19 Pandemic and Oil Price Volatility on Powell

- added (2020-05-06):
[0000080420-20-000020:note_history:29]
The global spread of COVID-19 has created significant volatility, uncertainty and economic disruption across the globe during Fiscal 2020. In addition, there have recently been significant reductions in oil and gas demand and steep declines in oil prices.  Certain of our customers have asked that we delay our manufacturing on their projects as their operations have been negatively impacted by this pandemic and the reduced oil and gas demand and steep declines in oil prices. We continue to monitor and work with our suppliers who have been impacted by this pandemic to ensure we are able to meet our customer commitments. We also have reviewed and will continue to review our contracts with our suppliers, and we may need to make adjustments accordingly. From an operations standpoint, although our facilities are located in areas that have been or continue to be subject to stay-at-home orders, we have not closed any of our facilities for an extended amount of time and have continued to operate as an "essential business" under these orders across all of our locations. We continue to take the necessary steps to promote social distancing and enhanced cleaning efforts in our offices and facilities in an effort to keep our employees, customers and vendors safe. We are also exploring the use of technology across our operations to further enhance social distancing and improve safety. These safety precautions may have an adverse impact on our efficiency and productivity going forward.

- added (2020-05-06):
[0000080420-20-000020:note_history:30]
As a result of the circumstances noted above, we anticipate a decrease in commercial activity which will negatively impact our business, results of operations and cash flows going forward. We have and may need to continue to adjust our workforce and labor costs to correspond to the reduced customer demand. We will take prudent measures to maintain our strong liquidity and cash position, which may include reducing our capital expenditures and research and development costs, as well as reducing or eliminating future dividend payments. However, the extent to which the COVID-19 pandemic specifically will impact our business will depend on numerous factors that are hard to predict, some of which include: the duration, spread and severity of the pandemic; governmental actions in response to the pandemic, including travel restrictions and quarantine or related orders; any closures of our offices and facilities or those of our suppliers as a result of the pandemic, and how quickly and to what extent normal economic and operating conditions can resume. Therefore, the magnitude of the impact on our business, results of operations and cash flows is not currently known.

- added (2020-05-06):
[0000080420-20-000020:note_history:31]
Due to the circumstances noted above, we made a reduction in our workforce across the business in early May which will result in severance and restructuring costs of less than $1 million. We may have to make additional adjustments to our workforce and labor costs in response to further changes to customer demand.
