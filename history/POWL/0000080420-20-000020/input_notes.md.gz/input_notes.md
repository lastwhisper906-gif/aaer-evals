# POWL notes — 0000080420-20-000020


## powl:LesseeAssetsAndLiabilitiesTableTextBlock

[0000080420-20-000020:notes:1]
The following table provides a summary of the operating lease assets and operating lease liabilities included in our Condensed Consolidated Balance Sheets as of March 31, 2020 (in thousands):

[0000080420-20-000020:notes:2]
| Operating Leases |  | March 31, 2020 |
| Assets: |  |  |
| Operating lease assets, net |  | $ | 5,606 |  |
| Liabilities: |  |  |
| Current operating lease liabilities |  | 2,062 |  |
| Long-term operating lease liabilities |  | 4,229 |  |
| Total lease liabilities |  | $ | 6,291 |  |


## us-gaap:AllowanceForCreditLossesOnFinancingReceivablesTableTextBlock

[0000080420-20-000020:notes:3]
[same as prior period, unchanged from 0000080420-20-000005:notes:3]

[0000080420-20-000020:notes:4]
|  | Three months ended March 31, |  | Six months ended March 31, |
|  | 2020 |  | 2019 |  | 2020 |  | 2019 |
| Balance at beginning of period | $ | 346 |  |  | $ | 139 |  |  | $ | 301 |  |  | $ | 157 |  |
| Bad debt expense | 9 |  |  | 74 |  |  | 51 |  |  | 101 |  |
| Uncollectible accounts written off, net of recoveries | (45 | ) |  | (2 | ) |  | (55 | ) |  | (44 | ) |
| Change due to foreign currency translation | (10 | ) |  | 3 |  |  | 3 |  |  | — |  |
| Balance at end of period | $ | 300 |  |  | $ | 214 |  |  | $ | 300 |  |  | $ | 214 |  |


## us-gaap:BasisOfAccountingPolicyPolicyTextBlock

[0000080420-20-000020:notes:5]
[same as prior period, unchanged from 0000080420-20-000005:notes:5]

[0000080420-20-000020:notes:6]
[same as prior period, unchanged from 0000080420-20-000005:notes:6]

[0000080420-20-000020:notes:7]
[same as prior period, unchanged from 0000080420-20-000005:notes:7]

[0000080420-20-000020:notes:8]
[same as prior period, unchanged from 0000080420-20-000005:notes:8]

[0000080420-20-000020:notes:9]
[same as prior period, unchanged from 0000080420-20-000005:notes:9]


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0000080420-20-000020:notes:10]
Commitments and Contingencies

[0000080420-20-000020:notes:11]
Letters of Credit, Surety Bonds and Bank Guarantees

[0000080420-20-000020:notes:12]
Certain customers require us to post letters of credit, bank guarantees or surety bonds. These security instruments assure that we will perform under the terms of our contract. In the event of default, the counterparty may demand payment from the bank under a letter of credit or bank guarantee, or performance by the surety under a bond. To date, there have been no significant draws or claims related to security instruments for the periods reported. We were contingently liable for letters of credit of $35.1 million as of March 31, 2020. We also had surety bonds totaling $162.8 million that were outstanding, with additional bonding capacity of $587.2 million available, at March 31, 2020.

[0000080420-20-000020:notes:13]
We have an $11.1 million facility agreement (Facility Agreement) between Powell (UK) Limited and a large international bank that provides Powell (UK) Limited the ability to enter into bank guarantees as well as forward exchange contracts and currency options. At March 31, 2020, we had outstanding guarantees totaling $3.1 million and amounts available under this Facility Agreement were $8.0 million. The Facility Agreement expires in May 2020 and provides for financial covenants and customary events of default, and carries cross-default provisions with our U.S. Revolver. If an event of default (as defined in the Facility Agreement) occurs and is continuing, per the terms and subject to the conditions set forth therein, obligations outstanding under the Facility Agreement may be accelerated and declared immediately due and payable. As of March 31, 2020, we were in compliance with all of the financial covenants of the Facility Agreement.

[0000080420-20-000020:notes:14]
Litigation

[0000080420-20-000020:notes:15]
We are involved in various legal proceedings, claims and other disputes arising from our commercial operations, projects, employees and other matters which, in general, are subject to uncertainties and in which the outcomes are not predictable. Although we can give no assurances about the resolution of pending claims, litigation or other disputes and the effect such outcomes may have on us, management believes that any ultimate liability resulting from the outcome of such proceedings, to the extent not otherwise provided or covered by insurance, will not have a material adverse effect on our consolidated financial position or results of operations or liquidity.


## us-gaap:ContractWithCustomerAssetAndLiabilityTableTextBlock

[0000080420-20-000020:notes:16]
Contract assets and liabilities as of March 31, 2020 and September 30, 2019 are summarized below (in thousands):

[0000080420-20-000020:notes:17]
|  | March 31, 2020 |  | September 30, 2019 |
| Contract assets | $ | 61,336 |  |  | $ | 55,374 |  |
| Contract liabilities | (57,821 | ) |  | (71,464 | ) |
| Net contract asset (liability) | $ | 3,515 |  |  | $ | (16,090 | ) |


## us-gaap:DisaggregationOfRevenueTableTextBlock

[0000080420-20-000020:notes:18]
The following tables present our disaggregated revenue by geographic destination and market sector for the six months ended March 31, 2020 and 2019 (in thousands):

[0000080420-20-000020:notes:19]
|  | Three months ended March 31, |  | Six months ended March 31, |
|  | 2020 |  | 2019 |  | 2020 |  | 2019 |
| United States | $ | 121,432 |  |  | $ | 102,406 |  |  | $ | 228,510 |  |  | $ | 192,304 |  |
| Canada | 15,407 |  |  | 15,094 |  |  | 29,861 |  |  | 24,809 |  |
| Europe, Middle East and Africa | 8,816 |  |  | 5,508 |  |  | 18,982 |  |  | 10,949 |  |
| Asia/Pacific | 5,456 |  |  | 729 |  |  | 7,142 |  |  | 4,473 |  |
| Mexico, Central and South America | 459 |  |  | — |  |  | 1,225 |  |  | 553 |  |
| Total revenues by geographic destination | $ | 151,570 |  |  | $ | 123,737 |  |  | $ | 285,720 |  |  | $ | 233,088 |  |

[0000080420-20-000020:notes:20]
|  | Three months ended March 31, |  | Six months ended March 31, |
|  | 2020 |  | 2019 |  | 2020 |  | 2019 |
| Oil and gas | $ | 51,954 |  |  | $ | 56,022 |  |  | $ | 111,948 |  |  | $ | 105,598 |  |
| Petrochemical | 47,337 |  |  | 22,523 |  |  | 77,763 |  |  | 42,301 |  |
| Electric utility | 24,255 |  |  | 20,383 |  |  | 47,270 |  |  | 39,641 |  |
| Traction power | 13,944 |  |  | 6,025 |  |  | 22,295 |  |  | 11,034 |  |
| All others | 14,080 |  |  | 18,784 |  |  | 26,444 |  |  | 34,514 |  |
| Total revenues by market sector | $ | 151,570 |  |  | $ | 123,737 |  |  | $ | 285,720 |  |  | $ | 233,088 |  |


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0000080420-20-000020:notes:21]
[same as prior period, unchanged from 0000080420-20-000005:notes:21]

[0000080420-20-000020:notes:22]
[same as prior period, unchanged from 0000080420-20-000005:notes:22]

[0000080420-20-000020:notes:23]
[same as prior period, unchanged from 0000080420-20-000005:notes:23]

[0000080420-20-000020:notes:24]
We issue restricted stock units (RSUs) to certain officers and key employees of the Company. The fair value of the RSUs is based on the price of our common stock as reported on the NASDAQ Global Market on the grant dates. The typical annual grant vests over a three-year period from the date of issuance and is a blend of time-based and performance-based shares. The portion of the grant that is time-based typically vests over a three-year period on each anniversary of the grant date, based on continued employment. The performance-based shares vest based on the three-year earnings performance of the Company following the grant date. At March 31, 2020, there were 154,200 RSUs outstanding. The RSUs do not have voting rights but do receive dividend equivalents upon vesting. Additionally, the shares of common stock underlying the RSUs are not considered issued and outstanding until vested and common stock is issued.

[0000080420-20-000020:notes:25]
Total RSU activity (number of shares) for the six months ended March 31, 2020 is summarized below:

[0000080420-20-000020:notes:26]
|  | Number ofRestrictedStockUnits |  | WeightedAverageFair ValuePer Share |
| Outstanding at September 30, 2019 | 131,850 |  |  | $ | 33.76 |  |
| Granted | 70,000 |  |  | 38.57 |  |
| Vested | (46,900 | ) |  | 35.65 |  |
| Forfeited/canceled | (750 | ) |  | 33.16 |  |
| Outstanding at March 31, 2020 | 154,200 |  |  | 35.37 |  |

[0000080420-20-000020:notes:27]
During the six months ended March 31, 2020 and 2019, we recorded compensation expense of $1.5 million and $1.6 million, respectively, related to the RSUs.

[0000080420-20-000020:notes:28]
[same as prior period, unchanged from 0000080420-20-000005:notes:28]

[0000080420-20-000020:notes:29]
Each non-employee director receives 2,400 restricted shares of the Company’s common stock annually. Fifty-percent of the restricted stock granted to each of our non-employee directors vests immediately, while the remaining fifty-percent vests on the anniversary of the grant date. Compensation expense is recognized immediately for the first fifty-percent of the restricted stock granted, while compensation expense for the remaining fifty-percent is recognized over the remaining vesting period. In February 2020, 16,800 shares of restricted stock were issued to our non-employee directors under the 2014 Director Plan at a price of $36.25 per share. During the six months ended March 31, 2020 and 2019, we recorded compensation expense of $0.4 million and $0.3 million, respectively, related to restricted stock.


## us-gaap:EarningsPerShareTextBlock

[0000080420-20-000020:notes:30]
[same as prior period, unchanged from 0000080420-20-000005:notes:30]

[0000080420-20-000020:notes:31]
[same as prior period, unchanged from 0000080420-20-000005:notes:31]

[0000080420-20-000020:notes:32]
[same as prior period, unchanged from 0000080420-20-000005:notes:32]

[0000080420-20-000020:notes:33]
|  | Three months ended March 31, |  | Six months ended March 31, |
|  | 2020 |  | 2019 |  | 2020 |  | 2019 |
| Numerator: |  |  |  |  |  |  |  |
| Net income (loss) | $ | 7,421 |  |  | $ | 958 |  |  | $ | 10,196 |  |  | $ | (1,737 | ) |
| Denominator: |  |  |  |  |  |  |  |
| Weighted average basic shares | 11,621 |  |  | 11,570 |  |  | 11,617 |  |  | 11,560 |  |
| Dilutive effect of restricted stock units | 60 |  |  | 62 |  |  | 56 |  |  | — |  |
| Weighted average diluted shares | 11,681 |  |  | 11,632 |  |  | 11,673 |  |  | 11,560 |  |
| Income (loss) per share: |  |  |  |  |  |  |  |
| Basic | $ | 0.64 |  |  | $ | 0.08 |  |  | $ | 0.88 |  |  | $ | (0.15 | ) |
| Diluted | $ | 0.64 |  |  | $ | 0.08 |  |  | $ | 0.87 |  |  | $ | (0.15 | ) |

[0000080420-20-000020:notes:34]
For the six months ended March 31, 2019, we incurred a net loss and therefore all potential common shares were deemed to be anti-dilutive.


## us-gaap:FairValueDisclosuresTextBlock

[0000080420-20-000020:notes:35]
[same as prior period, unchanged from 0000080420-20-000005:notes:35]

[0000080420-20-000020:notes:36]
[same as prior period, unchanged from 0000080420-20-000005:notes:36]

[0000080420-20-000020:notes:37]
[same as prior period, unchanged from 0000080420-20-000005:notes:37]

[0000080420-20-000020:notes:38]
[same as prior period, unchanged from 0000080420-20-000005:notes:38]

[0000080420-20-000020:notes:39]
[same as prior period, unchanged from 0000080420-20-000005:notes:39]

[0000080420-20-000020:notes:40]
[same as prior period, unchanged from 0000080420-20-000005:notes:40]

[0000080420-20-000020:notes:41]
The following table summarizes the fair value of our assets and liabilities that were accounted for at fair value on a recurring basis as of March 31, 2020 (in thousands):

[0000080420-20-000020:notes:42]
|  | Fair Value Measurements at March 31, 2020 |
|  | Quoted Prices inActive Markets forIdentical Assets(Level 1) |  | Significant OtherObservableInputs(Level 2) |  | SignificantUnobservableInputs(Level 3) |  | Fair Value at March 31, 2020 |
| Assets: |  |  |  |  |  |  |  |
| Cash and cash equivalents | $ | 120,571 |  |  | $ | — |  |  | $ | — |  |  | $ | 120,571 |  |
| Other assets | — |  |  | 6,143 |  |  | — |  |  | 6,143 |  |
| Liabilities: |  |  |  |  |  |  |  |
| Deferred compensation | — |  |  | 5,484 |  |  | — |  |  | 5,484 |  |

[0000080420-20-000020:notes:43]
[same as prior period, unchanged from 0000080420-20-000005:notes:43]

[0000080420-20-000020:notes:44]
[same as prior period, unchanged from 0000080420-20-000005:notes:44]

[0000080420-20-000020:notes:45]
[same as prior period, unchanged from 0000080420-20-000005:notes:45]

[0000080420-20-000020:notes:46]
[same as prior period, unchanged from 0000080420-20-000005:notes:46]

[0000080420-20-000020:notes:47]
[same as prior period, unchanged from 0000080420-20-000005:notes:47]

[0000080420-20-000020:notes:48]
[same as prior period, unchanged from 0000080420-20-000005:notes:48]

[0000080420-20-000020:notes:49]
There were no transfers between levels within the fair value measurement hierarchy during the quarter ended March 31, 2020.


## us-gaap:IncomeTaxDisclosureTextBlock

[0000080420-20-000020:notes:50]
[same as prior period, unchanged from 0000080420-20-000005:notes:50]

[0000080420-20-000020:notes:51]
[same as prior period, unchanged from 0000080420-20-000005:notes:51]

[0000080420-20-000020:notes:52]
|  | Three months ended March 31, |  | Six months ended March 31, |
|  | 2020 |  | 2019 |  | 2020 |  | 2019 |
| Income (loss) before income taxes | $ | 9,555 |  |  | $ | 1,363 |  |  | $ | 12,888 |  |  | $ | (1,571 | ) |
| Income tax provision | 2,134 |  |  | 405 |  |  | 2,692 |  |  | 166 |  |
| Net income (loss) | $ | 7,421 |  |  | $ | 958 |  |  | $ | 10,196 |  |  | $ | (1,737 | ) |
| Effective tax rate | 22 | % |  | 30 | % |  | 21 | % |  | (11 | )% |

[0000080420-20-000020:notes:53]
Our income tax provision reflects an effective tax rate on pre-tax income of 22% for the second quarter of Fiscal 2020 compared to 30% in the second quarter of Fiscal 2019. The effective tax rate for the quarter ended March 31, 2020 approximated the U.S. federal statutory rate as the tax benefits related to the Research and Development Tax Credit (R&D Tax Credit) and the projected utilization of net operating loss carryforwards in Canada that were fully reserved with a valuation allowance were partially offset by a discrete item recorded in the second quarter of Fiscal 2020 in the amount of $0.5 million.  This discrete item was related to the establishment of a valuation allowance against the deferred tax assets in the United Kingdom (UK) as discussed below.  For the second quarter of Fiscal 2019, the effective tax rate was negatively impacted by Canadian tax losses that were reserved with a valuation allowance.

[0000080420-20-000020:notes:54]
The effective tax rate of 21% for the six months ended March 31, 2020 was favorably impacted by the R&D Tax Credit as well as the projected utilization of net operating loss carryforwards in Canada that were fully reserved with a valuation allowance. Conversely, we recorded a valuation allowance against our UK deferred tax assets as a discrete item during the second quarter of Fiscal 2020 that negatively impacted the effective tax rate for the six months ended March 31, 2020. For the six months ended March 31, 2019, the effective tax rate of negative 11% was adversely impacted by the losses recognized in Canada reserved with a valuation allowance. There were no material discrete items recognized in the first six months of Fiscal 2019.

[0000080420-20-000020:notes:55]
During our assessment of deferred income taxes, in the second quarter of Fiscal 2020, we recorded a valuation allowance of $0.5 million against our UK net deferred tax assets.  In assessing the realizability of net deferred tax assets, we determined it was more-likely-than-not that the net deferred tax assets may not be realized based upon recent UK tax losses and anticipated results in the near term.  Estimates may change as new events occur, estimates of future taxable income are reduced or increased, additional information becomes available, or operating environments change, which may result in a full or partial reversal of the valuation allowance.

[0000080420-20-000020:notes:56]
Due to the expiration of certain federal statutes of limitations and voluntary filings, management believes that, within the next twelve months, it is reasonably possible that the unrecognized tax benefits will decrease by approximately $0.7 million and would positively impact our effective tax rate. We are unable to make reasonably reliable estimates regarding the timing of future cash outflows, if any, associated with the remaining unrecognized tax benefits.


## us-gaap:LeaseCostTableTextBlock

[0000080420-20-000020:notes:57]
The following table provides a summary of lease cost components for the three months ended March 31, 2020 (in thousands):

[0000080420-20-000020:notes:58]
| Lease Cost |  | Three months ended March 31, 2020 |  | Six months ended March 31, 2020 |
| Operating lease cost |  | $ | 580 |  |  | $ | 1,208 |  |
| Less: sublease income |  | (158 | ) |  | (237 | ) |
| Variable lease cost(1) |  | 84 |  |  | 178 |  |
| Short-term lease cost(2) |  | 159 |  |  | 349 |  |
| Total lease cost |  | $ | 665 |  |  | $ | 1,498 |  |

[0000080420-20-000020:notes:59]
[same as prior period, unchanged from 0000080420-20-000005:notes:57]

[0000080420-20-000020:notes:60]
[same as prior period, unchanged from 0000080420-20-000005:notes:58]


## us-gaap:LesseeOperatingLeaseLiabilityMaturityTableTextBlock

[0000080420-20-000020:notes:61]
The following table provides the maturities of our operating lease liabilities as of March 31, 2020 (in thousands):

[0000080420-20-000020:notes:62]
|  |  | Operating Leases |
| Remainder of 2020 |  | $ | 1,260 |  |
| 2021 |  | 2,290 |  |
| 2022 |  | 2,018 |  |
| 2023 |  | 1,027 |  |
| 2024 |  | 85 |  |
| Thereafter |  | — |  |
| Total future minimum lease payments |  | 6,680 |  |
| Less: present value discount (imputed interest) |  | (389 | ) |
| Present value of lease liabilities |  | $ | 6,291 |  |


## us-gaap:LesseeOperatingLeasesTextBlock

[0000080420-20-000020:notes:63]
[same as prior period, unchanged from 0000080420-20-000005:notes:61]

[0000080420-20-000020:notes:64]
Our leases consist primarily of office and manufacturing space, construction equipment and office equipment. All of our future lease obligations are related to non-cancelable operating leases. The most significant portion of our lease portfolio relates to leases of office and manufacturing facilities in Canada which we no longer occupy. We currently sublease the majority of these Canadian facilities. The following table provides a summary of lease cost components for the three months ended March 31, 2020 (in thousands):

[0000080420-20-000020:notes:65]
We recognize operating lease assets and operating lease liabilities representing the present value of the remaining lease payments for leases with initial terms greater than twelve months. Leases with initial terms of twelve months or less are not recorded in our Condensed Consolidated Balance Sheets. Our operating lease assets have been reduced by a lease accrual of $0.7 million related to certain unused facility leases in Canada. The following table provides a summary of the operating lease assets and operating lease liabilities included in our Condensed Consolidated Balance Sheets as of March 31, 2020 (in thousands):

[0000080420-20-000020:notes:66]
The weighted average discount rate as of March 31, 2020 was 4.25%. The weighted average remaining lease term was 2.9 years at March 31, 2020.


## us-gaap:LongTermDebtTextBlock

[0000080420-20-000020:notes:67]
Long-Term Debt

[0000080420-20-000020:notes:68]
Long-term debt consisted of the following (in thousands):

[0000080420-20-000020:notes:69]
|  | March 31, 2020 |  | September 30, 2019 |
| Industrial development revenue bonds | $ | 800 |  |  | $ | 1,200 |  |
| Less: current portion | (400 | ) |  | (400 | ) |
| Total long-term debt | $ | 400 |  |  | $ | 800 |  |

[0000080420-20-000020:notes:70]
U.S. Revolver

[0000080420-20-000020:notes:71]
On September 27, 2019, we entered into an Amended and Restated Credit Agreement with Bank of America, N.A. (the " "U.S. Revolver"), which replaced our prior credit agreement. The U.S. Revolver is a $75.0 million revolving credit facility that is available for both borrowings and letters of credit and expires September 2024. As of March 31, 2020, there were no amounts borrowed under this facility and letters of credit outstanding were $35.1 million. There was $39.9 million available for the issuance of letters of credit and borrowings under the U.S. Revolver as of March 31, 2020.

[0000080420-20-000020:notes:72]
We are required to maintain certain financial covenants, the most significant of which are a consolidated leverage ratio less than 3.0 to 1.0 and a consolidated interest coverage ratio of greater than 3.0 to 1.0. Additionally, we must maintain a consolidated cash balance of $30 million at all times. The U.S. Revolver also contains a "material adverse effect" clause which is a material change in our operations, business, properties, liabilities or condition (financial or otherwise) or a material impairment of our ability to perform our obligations under our credit agreements. As of March 31, 2020, we were in compliance with all of the financial covenants of the U.S. Revolver.

[0000080420-20-000020:notes:73]
The U.S. Revolver allows the Company to elect that any borrowing under the facility bear an interest rate based on either the base rate or the eurocurrency rate, in each case, plus the applicable rate. The base rate is generally the highest of (a) the federal funds rate plus 0.50%, (b) the Bank of America prime rate or (c) the London Interbank Offered Rate ("LIBOR") plus 1.00%. The applicable rate is generally a range from (0.25)% to 1.75% depending on the type of loan and the Company's consolidated leverage ratio.

[0000080420-20-000020:notes:74]
The U.S. Revolver is collateralized by a pledge of 100% of the voting capital stock of each of our domestic subsidiaries and 65% of the voting capital stock of each non-domestic subsidiary. The U.S. Revolver provides for customary events of default and carries cross-default provisions with other existing debt agreements. If an event of default (as defined in the U.S. Revolver) occurs and is continuing, on the terms and subject to the conditions set forth in the U.S. Revolver, amounts and letters of credit outstanding under the U.S. Revolver may be accelerated and may become immediately due and payable.

[0000080420-20-000020:notes:75]
Industrial Development Revenue Bonds

[0000080420-20-000020:notes:76]
We borrowed $8.0 million in October 2001 through a loan agreement funded with proceeds from tax-exempt industrial development revenue bonds (Bonds). These Bonds were issued by the Illinois Development Finance Authority and were used for the completion of our Northlake, Illinois facility. Pursuant to the Bond issuance, a reimbursement agreement between us and a major domestic bank required an issuance by the bank of an irrevocable direct-pay letter of credit (Bond LC), as collateral, to the Bonds’ trustee to guarantee payment of the Bonds’ principal and interest when due. The Bond LC is subject to both early termination and extension provisions customary to such agreements, as well as various covenants, for which we were in compliance at March 31, 2020. While the Bonds mature in 2021, the reimbursement agreement requires annual redemptions of $0.4 million that commenced on October 25, 2002. A sinking fund is used for the annual principal payment. The Bonds bear interest at a floating rate determined weekly by the Bonds’ remarketing agent, which was the underwriter for the Bonds and is an affiliate of the bank. This interest rate was 5.08% as of March 31, 2020 and subsequently declined to 0.57% as of April 30, 2020.


## us-gaap:NewAccountingPronouncementsPolicyPolicyTextBlock

[0000080420-20-000020:notes:77]
New Accounting Standards

[0000080420-20-000020:notes:78]
Effective October 1, 2019, we adopted the new lease accounting standard and recorded operating lease assets and operating lease liabilities of approximately $7.0 million and determined that no adjustment to retained earnings was necessary. Financial results for reporting periods after October 1, 2019 are reported under the new standard; however financial results for prior periods were not adjusted and will continue to be presented in accordance with the previous standard. Upon adoption, we elected a package of practical expedients which, among other things, allowed for the historical classification of our existing leases to carryforward. Additionally, we elected to separate non-lease components for our real estate and IT infrastructure asset classes.  All other asset classes account for both lease and non-lease components in the operating lease asset and operating lease liability calculations. See Note I for further discussion of leases.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureAndSignificantAccountingPoliciesTextBlock

[0000080420-20-000020:notes:79]
[same as prior period, unchanged from 0000080420-20-000005:notes:77]

[0000080420-20-000020:notes:80]
[same as prior period, unchanged from 0000080420-20-000005:notes:78]

[0000080420-20-000020:notes:81]
[same as prior period, unchanged from 0000080420-20-000005:notes:79]

[0000080420-20-000020:notes:82]
[same as prior period, unchanged from 0000080420-20-000005:notes:80]

[0000080420-20-000020:notes:83]
[same as prior period, unchanged from 0000080420-20-000005:notes:81]

[0000080420-20-000020:notes:84]
[same as prior period, unchanged from 0000080420-20-000005:notes:82]


## us-gaap:RevenueFromContractWithCustomerPolicyTextBlock

[0000080420-20-000020:notes:85]
[same as prior period, unchanged from 0000080420-20-000005:notes:96]

[0000080420-20-000020:notes:86]
[same as prior period, unchanged from 0000080420-20-000005:notes:97]

[0000080420-20-000020:notes:87]
[same as prior period, unchanged from 0000080420-20-000005:notes:98]

[0000080420-20-000020:notes:88]
[same as prior period, unchanged from 0000080420-20-000005:notes:99]

[0000080420-20-000020:notes:89]
[same as prior period, unchanged from 0000080420-20-000005:notes:100]

[0000080420-20-000020:notes:90]
We also have contracts to provide value-added services such as field service inspection, installation, commissioning, modification and repair, as well as retrofit and retrofill components for existing systems.  As a practical expedient, if the service contract terms give us the right to invoice the customer for an amount that corresponds directly with the value of our performance completed to date (i.e., a service contract in which we bill a fixed amount for each hour of service provided), then we recognize revenue over time in each reporting period corresponding to the amount with which we have the right to invoice.  Our performance obligations are satisfied as the work progresses. Revenues from our custom-engineered products and value-added services transferred to customers over time accounted for approximately 96% of total revenues for the three and six months ended March 31, 2020 and 93% of total revenues for the three and six months ended March 31, 2019.

[0000080420-20-000020:notes:91]
We also have sales orders for spare parts and replacement circuit breakers for switchgear that are obsolete or that are no longer produced by the original manufacturer. Revenues from these sales orders are recognized at the time we fulfill our performance obligation to the customer, which is typically upon shipment and represented approximately 4% of total revenues for the three and six months ended March 31, 2020 and 7% of total revenues for the three and six months ended March 31, 2019.

[0000080420-20-000020:notes:92]
[same as prior period, unchanged from 0000080420-20-000005:notes:103]

[0000080420-20-000020:notes:93]
[same as prior period, unchanged from 0000080420-20-000005:notes:104]

[0000080420-20-000020:notes:94]
[same as prior period, unchanged from 0000080420-20-000005:notes:92]

[0000080420-20-000020:notes:95]
[same as prior period, unchanged from 0000080420-20-000005:notes:93]

[0000080420-20-000020:notes:96]
[same as prior period, unchanged from 0000080420-20-000005:notes:94]

[0000080420-20-000020:notes:97]
[same as prior period, unchanged from 0000080420-20-000005:notes:95]

[0000080420-20-000020:notes:98]
[same as prior period, unchanged from 0000080420-20-000005:notes:83]

[0000080420-20-000020:notes:99]
[same as prior period, unchanged from 0000080420-20-000005:notes:84]

[0000080420-20-000020:notes:100]
[same as prior period, unchanged from 0000080420-20-000005:notes:85]

[0000080420-20-000020:notes:101]
[same as prior period, unchanged from 0000080420-20-000005:notes:86]

[0000080420-20-000020:notes:102]
[same as prior period, unchanged from 0000080420-20-000005:notes:87]

[0000080420-20-000020:notes:103]
[same as prior period, unchanged from 0000080420-20-000005:notes:88]

[0000080420-20-000020:notes:104]
Contract assets are recorded when revenues are recognized in excess of amounts billed for fixed-price contracts as determined by the billing milestone schedule. Contract assets are transferred to accounts receivable when billing milestones have been met, or we have an unconditional right to payment.

[0000080420-20-000020:notes:105]
[same as prior period, unchanged from 0000080420-20-000005:notes:90]

[0000080420-20-000020:notes:106]
[same as prior period, unchanged from 0000080420-20-000005:notes:91]


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0000080420-20-000020:notes:107]
[same as prior period, unchanged from 0000080420-20-000005:notes:105]

[0000080420-20-000020:notes:108]
[same as prior period, unchanged from 0000080420-20-000005:notes:106]

[0000080420-20-000020:notes:109]
Remaining unsatisfied performance obligations, which we refer to as backlog, represent the estimated transaction price for goods and services for which we have a material right but work has not been performed. As of March 31, 2020, we had backlog of $566.4 million, of which approximately $342.9 million is expected to be recognized as revenue within the next twelve months. Backlog may not be indicative of future operating results as orders may be cancelled or modified by our customers. Our backlog does not include service and maintenance-type contracts for which we have the right to invoice as services are performed.

[0000080420-20-000020:notes:110]
For the six months ended March 31, 2020 and 2019, our operating results were positively impacted by $9.0 million and $4.3 million, respectively, as a result of changes in contract estimates related to projects in progress at the beginning of the respective period. These changes in estimates resulted primarily from favorable project execution and negotiations of variable consideration, discussed below, as well as other changes in facts and circumstances during these periods.

[0000080420-20-000020:notes:111]
The increase in net contract asset at March 31, 2020 from September 30, 2019 was primarily due to our progress towards completion on our projects and the timing of contract billing milestones and new orders. To determine the amount of revenue recognized during the period from contract liabilities, we first allocate revenue to the individual contract liability balance outstanding at the beginning of the period until the revenue exceeds that balance. During the three and six months ended March 31, 2020, we recognized revenue of approximately $50.8 million and $65.0 million related to contract liabilities outstanding at September 30, 2019.

[0000080420-20-000020:notes:112]
The timing of our invoice process is typically dependent on the completion of certain milestones and contract terms and subject to agreement by our customer.  Payment is typically expected within 30 days of invoice. Any uncollected invoiced amounts for our performance obligations recognized over time, including contract retentions, are recorded as accounts receivable in the Condensed Consolidated Balance Sheets. Certain contracts contain retention provisions that become due upon completion of contractual requirements. As of March 31, 2020 and September 30, 2019, accounts receivable included retention amounts of $6.0 million and $5.6 million, respectively. Of the retained amount at March 31, 2020, $3.7 million is expected to be collected in the next twelve months and is recorded in accounts receivable. The remaining $2.3 million is recorded in other assets.

[0000080420-20-000020:notes:113]
[same as prior period, unchanged from 0000080420-20-000005:notes:111]


## us-gaap:ScheduleOfInventoryCurrentTableTextBlock

[0000080420-20-000020:notes:114]
[same as prior period, unchanged from 0000080420-20-000005:notes:112]

[0000080420-20-000020:notes:115]
|  | March 31, 2020 |  | September 30, 2019 |
| Raw materials, parts and sub-assemblies, net | $ | 30,512 |  |  | $ | 28,102 |  |
| Work-in-progress | 624 |  |  | 1,100 |  |
| Total inventories | $ | 31,136 |  |  | $ | 29,202 |  |


## us-gaap:ScheduleOfProductWarrantyLiabilityTableTextBlock

[0000080420-20-000020:notes:116]
[same as prior period, unchanged from 0000080420-20-000005:notes:114]

[0000080420-20-000020:notes:117]
|  | Three months ended March 31, |  | Six months ended March 31, |
|  | 2020 |  | 2019 |  | 2020 |  | 2019 |
| Balance at beginning of period | $ | 3,162 |  |  | $ | 2,732 |  |  | $ | 2,946 |  |  | $ | 2,604 |  |
| Increase in warranty expense | 784 |  |  | 881 |  |  | 1,627 |  |  | 1,627 |  |
| Deduction for warranty charges | (670 | ) |  | (634 | ) |  | (1,315 | ) |  | (1,238 | ) |
| Change due to foreign currency translation | — |  |  | 7 |  |  | 18 |  |  | (7 | ) |
| Balance at end of period | $ | 3,276 |  |  | $ | 2,986 |  |  | $ | 3,276 |  |  | $ | 2,986 |  |


## us-gaap:SubsequentEventsTextBlock

[0000080420-20-000020:notes:118]
Subsequent Events

[0000080420-20-000020:notes:119]
Quarterly Dividend Declared

[0000080420-20-000020:notes:120]
On May 5, 2020, our Board of Directors declared a quarterly cash dividend on our common stock in the amount of $0.26 per share. The dividend is payable on June 17, 2020 to shareholders of record at the close of business on May 20, 2020.

[0000080420-20-000020:notes:121]
Impact of the COVID-19 Pandemic and Oil Price Volatility on Powell

[0000080420-20-000020:notes:122]
The global spread of COVID-19 has created significant volatility, uncertainty and economic disruption across the globe during Fiscal 2020. In addition, there have recently been significant reductions in oil and gas demand and steep declines in oil prices.  Certain of our customers have asked that we delay our manufacturing on their projects as their operations have been negatively impacted by this pandemic and the reduced oil and gas demand and steep declines in oil prices. We continue to monitor and work with our suppliers who have been impacted by this pandemic to ensure we are able to meet our customer commitments. We also have reviewed and will continue to review our contracts with our suppliers, and we may need to make adjustments accordingly. From an operations standpoint, although our facilities are located in areas that have been or continue to be subject to stay-at-home orders, we have not closed any of our facilities for an extended amount of time and have continued to operate as an "essential business" under these orders across all of our locations. We continue to take the necessary steps to promote social distancing and enhanced cleaning efforts in our offices and facilities in an effort to keep our employees, customers and vendors safe. We are also exploring the use of technology across our operations to further enhance social distancing and improve safety. These safety precautions may have an adverse impact on our efficiency and productivity going forward.

[0000080420-20-000020:notes:123]
As a result of the circumstances noted above, we anticipate a decrease in commercial activity which will negatively impact our business, results of operations and cash flows going forward. We have and may need to continue to adjust our workforce and labor costs to correspond to the reduced customer demand. We will take prudent measures to maintain our strong liquidity and cash position, which may include reducing our capital expenditures and research and development costs, as well as reducing or eliminating future dividend payments. However, the extent to which the COVID-19 pandemic specifically will impact our business will depend on numerous factors that are hard to predict, some of which include: the duration, spread and severity of the pandemic; governmental actions in response to the pandemic, including travel restrictions and quarantine or related orders; any closures of our offices and facilities or those of our suppliers as a result of the pandemic, and how quickly and to what extent normal economic and operating conditions can resume. Therefore, the magnitude of the impact on our business, results of operations and cash flows is not currently known.

[0000080420-20-000020:notes:124]
Due to the circumstances noted above, we made a reduction in our workforce across the business in early May which will result in severance and restructuring costs of less than $1 million. We may have to make additional adjustments to our workforce and labor costs in response to further changes to customer demand.


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0000080420-20-000020:notes:125]
[same as prior period, unchanged from 0000080420-20-000005:notes:118]

[0000080420-20-000020:notes:126]
[same as prior period, unchanged from 0000080420-20-000005:notes:119]

[0000080420-20-000020:notes:127]
[same as prior period, unchanged from 0000080420-20-000005:notes:120]

[0000080420-20-000020:notes:128]
[same as prior period, unchanged from 0000080420-20-000005:notes:121]
