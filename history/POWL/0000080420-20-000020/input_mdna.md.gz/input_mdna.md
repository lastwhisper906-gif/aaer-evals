# POWL MD&A — 0000080420-20-000020


## mdna

[0000080420-20-000020:mdna:1]
[same as prior period, unchanged from 0000080420-20-000005:mdna:1]

[0000080420-20-000020:mdna:2]
[same as prior period, unchanged from 0000080420-20-000005:mdna:2]

[0000080420-20-000020:mdna:3]
[same as prior period, unchanged from 0000080420-20-000005:mdna:3]

[0000080420-20-000020:mdna:4]
[same as prior period, unchanged from 0000080420-20-000005:mdna:4]

[0000080420-20-000020:mdna:5]
[same as prior period, unchanged from 0000080420-20-000005:mdna:5]

[0000080420-20-000020:mdna:6]
[same as prior period, unchanged from 0000080420-20-000005:mdna:6]

[0000080420-20-000020:mdna:7]
Beginning in late Fiscal 2018, the combination of a growing global economy and abundant sources of favorably priced natural gas feedstock are driving an increase in capital investment opportunities, specifically across the oil, gas and petrochemical sectors. We have seen opportunities for natural gas related projects targeting global demand for cleaner burning fuels. Additionally, projects within the domestic petrochemical sector have benefited from the low feedstock prices of natural gas.

[0000080420-20-000020:mdna:8]
Impact of the COVID-19 Pandemic and Oil Price Volatility on Powell

[0000080420-20-000020:mdna:9]
The global spread of COVID-19 has created significant volatility, uncertainty and economic disruption across the globe during Fiscal 2020. In addition, there have recently been significant reductions in oil and gas demand and steep declines in oil prices. We have continued to operate as an "essential business" across all of our locations. As discussed further under the heading "Outlook" below, it is difficult to predict the economic impact that this pandemic, as well as reduced oil and gas demand and the steep decline in oil prices may have on our business, results of operations and cash flows going forward. Our results of operations for the six months ended March 31, 2020 were not impacted by the COVID-19 and reductions in oil and gas demand noted above.

[0000080420-20-000020:mdna:10]
[same as prior period, unchanged from 0000080420-20-000005:mdna:8]

[0000080420-20-000020:mdna:11]
Quarter Ended March 31, 2020 Compared to the Quarter Ended March 31, 2019 (Unaudited)

[0000080420-20-000020:mdna:12]
[same as prior period, unchanged from 0000080420-20-000005:mdna:10]

[0000080420-20-000020:mdna:13]
Revenues increased by 22%, or $27.8 million, to $151.6 million in the second quarter of Fiscal 2020, primarily due to improved market conditions in our petrochemical and oil and gas markets beginning in late Fiscal 2018. Domestic revenues increased by 24%, or $23.5 million, to $120.9 million in the second quarter of Fiscal 2020. International revenues increased by 16%, or $4.3 million, to $30.7 million in the second quarter of Fiscal 2020, primarily driven by increased activity in our international operations. Our international revenues include both revenues generated from our international facilities as well as revenues from export projects generated at our domestic facilities.

[0000080420-20-000020:mdna:14]
Revenue from our oil and gas markets decreased by 7%, or $4.1 million, to $52.0 million in the second quarter of Fiscal 2020 while petrochemical revenue increased by 110%, or $24.8 million, to $47.3 million in the second quarter of Fiscal 2020 driven by the previous strength across the core oil and gas and petrochemical end markets when these projects were awarded in Fiscal

[0000080420-20-000020:mdna:15]
2018 and 2019. The petrochemical sector has benefited from lower natural gas prices. Revenue from utility markets increased by 19%, or $3.9 million, to $24.3 million and traction market revenue increased by 131%, or $7.9 million, to $13.9 million in the second quarter of Fiscal 2020, primarily driven by our mix of projects. Revenue from all other markets combined decreased by $4.7 million to $14.1 million in the second quarter of Fiscal 2020.

[0000080420-20-000020:mdna:16]
Gross profit increased by 48%, or $9.6 million, to $29.7 million, for the second quarter of Fiscal 2020 compared to the second quarter of Fiscal 2019. Gross profit as a percentage of revenues increased to 20% in the second quarter of Fiscal 2020, compared to 16% in the second quarter of Fiscal 2019 due to strong prior period market conditions, cost efficiencies and increased volume in our domestic and international manufacturing facilities.

[0000080420-20-000020:mdna:17]
[same as prior period, unchanged from 0000080420-20-000005:mdna:14]

[0000080420-20-000020:mdna:18]
Selling, general and administrative expenses increased by 8%, or $1.4 million, to $18.6 million in the second quarter of Fiscal 2020, primarily due to increased personnel costs and variable incentive compensation associated with increased project volume and profitability. Selling, general and administrative expenses, as a percentage of revenues, decreased to 12% during the second quarter of Fiscal 2020 compared to 14% in the second quarter of Fiscal 2019, primarily due to the increase in revenues and our continued focus on our cost structure.

[0000080420-20-000020:mdna:19]
Income Tax Provision

[0000080420-20-000020:mdna:20]
We recorded an income tax provision of $2.1 million in the second quarter of Fiscal 2020, compared to an income tax provision of $0.4 million in the second quarter of Fiscal 2019. The effective tax rate for the second quarter of Fiscal 2020 was 22%, compared to an effective tax rate of 30% in the second quarter of Fiscal 2019. For the three months ended March 31, 2020, the effective tax rate was favorably impacted by the Research and Development (R&D) Tax Credit as well as the projected utilization of net operating loss carryforwards in Canada that were fully reserved with a valuation allowance and negatively impacted by a discrete item related to the establishment of a valuation allowance against the UK deferred tax assets. The effective tax rate for the three months ended March 31, 2019 was negatively impacted by Canadian losses recognized that were fully reserved with a valuation allowance.

[0000080420-20-000020:mdna:21]
[same as prior period, unchanged from 0000080420-20-000005:mdna:18]

[0000080420-20-000020:mdna:22]
In the second quarter of Fiscal 2020, net income of $7.4 million, or $0.64 per diluted share, improved from net income of $1.0 million, or $0.08 per diluted share, in the second quarter of Fiscal 2019, primarily due to improved market conditions coming into Fiscal 2020 and efficiencies from increased volume in our domestic and Canadian manufacturing facilities.

[0000080420-20-000020:mdna:23]
[same as prior period, unchanged from 0000080420-20-000005:mdna:20]

[0000080420-20-000020:mdna:24]
The order backlog at March 31, 2020 was $566.4 million, an increase of 33% from $425.9 million at December 31, 2019 and a 43% increase over the $397.2 million backlog at March 31, 2019. New orders increased by 53% in the second quarter of Fiscal 2020 to $300.7 million, compared to $196.7 million in the second quarter of Fiscal 2019, as the business was awarded a substantial contract in January 2020 that will support the integrated electrical distribution requirements for a large industrial complex being built in the United States. This specific project will take over three years to design, manufacture, integrate, test and ship.

[0000080420-20-000020:mdna:25]
Six Months Ended March 31, 2020 Compared to the Six Months Ended March 31, 2019 (Unaudited)

[0000080420-20-000020:mdna:26]
Revenue and Gross Profit

[0000080420-20-000020:mdna:27]
Revenues increased by 23%, or $52.6 million, to $285.7 million in the six months ended March 31, 2020, primarily due to improved market conditions in our petrochemical and oil and gas markets beginning in late Fiscal 2018. Domestic revenues increased by 21%, or $39.8 million, to $227.0 million in the six months ended March 31, 2020. International revenues increased by 28%, or $12.9 million, to $58.7 million in the six months ended March 31, 2020, primarily driven by increased activity in our international operations. Our international revenues include both revenues generated from our international facilities as well as revenues from export projects generated at our domestic facilities.

[0000080420-20-000020:mdna:28]
Revenue from our oil and gas markets increased by 6%, or $6.3 million, to $111.9 million in the six months ended March 31, 2020 while petrochemical revenue increased by 84%, or $35.5 million, to $77.8 million in the six months ended March 31, 2020 driven by the previous strength across the core oil and gas and petrochemical end markets when these projects were awarded in Fiscal 2018 and 2019. Revenue from utility markets increased by 19%, or $7.6 million, to $47.3 million and traction market revenue increased by 102%, or $11.3 million, to $22.3 million in the six months ended March 31, 2020, primarily driven by our mix of projects. Revenue from all other markets combined decreased by $8.1 million to $26.4 million in the six months ended March 31, 2020.

[0000080420-20-000020:mdna:29]
Gross profit increased by 48%, or $16.8 million, to $51.5 million, for the six months ended March 31, 2020 compared to the six months ended March 31, 2019. Gross profit as a percentage of revenues increased to 18% in the six months ended March 31, 2020, compared to 15% in the six months ended March 31, 2019 due to strong prior period market conditions, cost efficiencies and increased volume in our domestic and international manufacturing facilities.

[0000080420-20-000020:mdna:30]
Selling, General and Administrative Expenses

[0000080420-20-000020:mdna:31]
Selling, general and administrative expenses increased by 8%, or $2.7 million, to $35.9 million in the six months ended March 31, 2020, primarily due to increased personnel costs and variable incentive compensation associated with increased project volume and profitability. Selling, general and administrative expenses, as a percentage of revenues, decreased to 13% during the six months ended March 31, 2020, compared to 14% during the six months ended March 31, 2019, primarily due to the increase in revenues and our continued focus on our cost structure.

[0000080420-20-000020:mdna:32]
Income Tax Provision

[0000080420-20-000020:mdna:33]
We recorded an income tax provision of $2.7 million in the six months ended March 31, 2020, compared to an income tax provision of $0.2 million in the six months ended March 31, 2019. The effective tax rate for the six months ended March 31, 2020 was 21%, compared to an effective tax rate of negative 11% for the six months ended March 31, 2019. For the six months ended March 31, 2020, the effective tax rate was favorably impacted by the R&D Tax Credit as well as the projected utilization of net operating loss carryforwards in Canada that were fully reserved with a valuation allowance and negatively impacted by a discrete item related to the establishment of a valuation allowance against the UK deferred tax assets. The effective tax rate for the six months ended March 31, 2019 was adversely impacted by Canadian losses recognized that were fully reserved with a valuation allowance.

[0000080420-20-000020:mdna:34]
Net Income

[0000080420-20-000020:mdna:35]
In the six months ended March 31, 2020, net income of $10.2 million, or $0.87 per diluted share, improved from a net loss of $1.7 million, or $0.15 loss per diluted share, in the six months ended March 31, 2019.

[0000080420-20-000020:mdna:36]
Backlog

[0000080420-20-000020:mdna:37]
The order backlog at March 31, 2020 was $566.4 million, a 35% increase from the $419.0 million at September 30, 2019. New orders increased by 19% during the six months ended March 31, 2020 to $438.1 million, compared to $369.1 million in the six months ended March 31, 2019, due to the timing of select orders awarded in the six months ended March 31, 2020, as the business was awarded a substantial contract in January 2020 that will support the integrated electrical distribution requirements for a large industrial complex being built in the United States. This specific project will take over three years to design, manufacture, integrate, test and ship.

[0000080420-20-000020:mdna:38]
[same as prior period, unchanged from 0000080420-20-000005:mdna:22]

[0000080420-20-000020:mdna:39]
[same as prior period, unchanged from 0000080420-20-000005:mdna:23]

[0000080420-20-000020:mdna:40]
A significant portion of our revenues have historically been from the oil, gas and petrochemical markets. Oil and gas commodity price levels have been unstable over the last several years, and our customers delayed some of their major capital investment projects. Beginning in late Fiscal 2018, our customers' decisions to invest in projects in our key oil and gas and petrochemical markets were influenced somewhat by the stabilization of commodity prices and the increased global demand for cleaner burning fuels during that period of time. We believe that change in market sentiment during that period of time had a favorable impact on our orders and backlog entering Fiscal 2020, although recent declines in oil prices may negatively impact our business going forward, as discussed in more detail below. Specific to natural gas, the business was awarded a substantial contract in January 2020 that will support the integrated electrical distribution requirements for a large industrial complex being built in the United States. This specific project will take over three years to design, manufacture, integrate, test and ship.

[0000080420-20-000020:mdna:41]
Our operating results are impacted by factors such as the timing of new order awards, customer approval of final engineering and design specifications and delays in customer construction schedules, all of which contribute to short-term earnings variability and the timing of project execution. Our operating results also have been, and could continue to be, impacted by the timing and resolution of change orders, project close-out and resolution of potential contract claims and liquidated damages, all of which could improve or deteriorate gross margins during the period in which these items are resolved with our customers. These factors

[0000080420-20-000020:mdna:42]
may result in periods of underutilization of our resources and facilities and negatively impact our ability to cover our fixed costs. The increased orders in Fiscal 2018 and 2019 have led to improvement in revenues and operating results for the first six months of Fiscal 2020. We continue to monitor the factors that drive our markets and will continue to strive to maintain our leadership and competitive advantage in the markets we serve while aligning our cost structure and workforce with these changing market conditions.

[0000080420-20-000020:mdna:43]
The global spread of COVID-19 has created significant volatility, uncertainty and economic disruption across the globe during Fiscal 2020. In addition, there have recently been significant reductions in oil and gas demand and steep declines in oil prices.  Certain of our customers have asked that we delay our manufacturing on their projects as their operations have been negatively impacted by this pandemic and the reduced oil and gas demand and steep declines in oil prices. We continue to monitor and work with our suppliers who have been impacted by this pandemic to ensure we are able to meet our customer commitments. We also have reviewed and will continue to review our contracts with our suppliers, and we may need to make adjustments accordingly. From an operations standpoint, although our facilities are located in areas that have been or continue to be subject to stay-at-home orders, we have not closed any of our facilities for an extended amount of time and have continued to operate as an "essential business" under these orders across all of our locations. We continue to take the necessary steps to promote social distancing and enhanced cleaning efforts in our offices and facilities in an effort to keep our employees, customers and vendors safe. We are also exploring the use of technology across our operations to further enhance social distancing and improve safety. These safety precautions may have an adverse impact on our efficiency and productivity going forward.

[0000080420-20-000020:mdna:44]
As a result of the circumstances noted above, we anticipate a decrease in commercial activity which will negatively impact our business, results of operations and cash flows going forward. We have and may need to continue to adjust our workforce and labor costs to correspond to the reduced customer demand. We will take prudent measures to maintain our strong liquidity and cash position, which may include reducing our capital expenditures and research and development costs, as well as reducing or eliminating future dividend payments. However, the extent to which the COVID-19 pandemic specifically will impact our business will depend on numerous factors that are hard to predict, some of which include: the duration, spread and severity of the pandemic; governmental actions in response to the pandemic, including travel restrictions and quarantine or related orders; any closures of our offices and facilities or those of our suppliers as a result of the pandemic, and how quickly and to what extent normal economic and operating conditions can resume. Therefore, the magnitude of the impact on our business, results of operations and cash flows is not currently known.

[0000080420-20-000020:mdna:45]
[same as prior period, unchanged from 0000080420-20-000005:mdna:26]

[0000080420-20-000020:mdna:46]
As of March 31, 2020, current assets exceeded current liabilities by 2.3 times and our debt to total capitalization was 0.27%.

[0000080420-20-000020:mdna:47]
Cash, cash equivalents and short-term investments decreased to $120.6 million at March 31, 2020, compared to $124.7 million at September 30, 2019. Our increase in project volume typically requires cash to fund operations. We believe that our strong working capital position, available borrowings under our credit facility (U.S. Revolver) and available cash should be sufficient to finance future operating activities, capital improvements, research and development initiatives and debt repayments for the foreseeable future.

[0000080420-20-000020:mdna:48]
Our U.S. Revolver is a $75.0 million revolving credit facility, which is available for both borrowings and letters of credit. As of March 31, 2020, there were no amounts borrowed under this facility, and letters of credit outstanding were $35.1 million. As of March 31, 2020, $39.9 million was available for the issuance of letters of credit and borrowing under the U.S. Revolver. Total long-term debt, including current maturities, totaled $0.8 million at March 31, 2020 related to outstanding industrial development revenue bonds. For further information regarding our debt, see Note E of Notes to Condensed Consolidated Financial Statements.

[0000080420-20-000020:mdna:49]
Approximately $20.8 million of our cash and cash equivalents at March 31, 2020 was held outside of the U.S. for international operations. It is our intention to indefinitely reinvest all current and future foreign earnings internationally in order to ensure sufficient working capital to support our international operations. In the event that we elect to repatriate some or all of the foreign earnings that were previously deemed to be indefinitely reinvested outside the U.S., we may incur additional tax expense upon such repatriation under current tax laws.

[0000080420-20-000020:mdna:50]
[same as prior period, unchanged from 0000080420-20-000005:mdna:31]

[0000080420-20-000020:mdna:51]
Operating activities provided net cash of $7.4 million during the six months ended March 31, 2020 and $26.0 million during the same period in Fiscal 2019. Cash flow from operations is primarily influenced by project volume, the timing of milestone payments from our customers and the payment terms with our suppliers. This decrease in operating cash flow was primarily due to the timing of project billings and the receipt of a $6.6 million income tax refund during the six months ended March 31, 2019.

[0000080420-20-000020:mdna:52]
[same as prior period, unchanged from 0000080420-20-000005:mdna:33]

[0000080420-20-000020:mdna:53]
Investing activities provided $2.7 million during the six months ended March 31, 2020 compared to $5.3 million during the same period in Fiscal 2019. The decrease in cash provided by investing activities in the first six months of in Fiscal 2020 was primarily due to an increase of $1.5 million in the purchases of plant, property and equipment in the first six months of Fiscal 2020 and is primarily related to our increase in project activity.

[0000080420-20-000020:mdna:54]
[same as prior period, unchanged from 0000080420-20-000005:mdna:35]

[0000080420-20-000020:mdna:55]
Net cash used in financing activities was $7.0 million during the six months ended March 31, 2020 and $7.5 million during the same period in Fiscal 2019, which primarily consisted of approximately $6.0 million of dividends paid in each period.

[0000080420-20-000020:mdna:56]
[same as prior period, unchanged from 0000080420-20-000005:mdna:37]

[0000080420-20-000020:mdna:57]
[same as prior period, unchanged from 0000080420-20-000005:mdna:38]

[0000080420-20-000020:mdna:58]
[same as prior period, unchanged from 0000080420-20-000005:mdna:39]

[0000080420-20-000020:mdna:59]
[same as prior period, unchanged from 0000080420-20-000005:mdna:40]

[0000080420-20-000020:mdna:60]
[same as prior period, unchanged from 0000080420-20-000005:mdna:41]
