# POWL note change history — 0001628280-17-000997 → 0000080420-17-000009


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2017-05-03):
[0000080420-17-000009:note_history:1]
Certain customers require us to post bank letter of credit guarantees or surety bonds. These guarantees and surety bonds assure that we will perform under the terms of our contract. In the event of default, the counterparty may demand payment from the bank under a letter of credit or performance by the surety under a bond. To date, there have been no significant expenses related to either letters of credit or surety bonds for the periods reported. We were contingently liable for secured and unsecured letters of credit of $21.4 million as of March 31, 2017. We also had surety bonds totaling $216.0 million that were outstanding, with additional bonding capacity of $534.0 million available, at March 31, 2017.
  (was, 2017-02-08, similarity 0.9813):
[0001628280-17-000997:note_history:1]
Certain customers require us to post bank letter of credit guarantees or surety bonds. These guarantees and surety bonds assure that we will perform under the terms of our contract. In the event of default, the counterparty may demand payment from the bank under a letter of credit or performance by the surety under a bond. To date, there have been no significant expenses related to either letters of credit or surety bonds for the periods reported. We were contingently liable for secured and unsecured letters of credit of $20.3 million as of December 31, 2016. We also had surety bonds totaling $229.4 million that were outstanding, with additional bonding capacity of $520.6 million available, at December 31, 2016.

- changed (2017-05-03):
[0000080420-17-000009:note_history:2]
We have a $6.2 million facility agreement (Facility Agreement) between Powell (UK) Limited and a large international bank. This Facility Agreement provides Powell (UK) Limited the ability to enter into bank guarantees as well as forward exchange contracts and currency options. At March 31, 2017, we had outstanding guarantees totaling $4.7 million under this Facility Agreement and amounts available under this Facility Agreement were $1.5 million.  This facility expires in May 2017. The Facility Agreement provides for financial covenants and customary events of default, and carries cross-default provisions with our U.S. Revolver. If an event of default (as defined in the Facility Agreement) occurs and is continuing, per the terms and subject to the conditions set forth therein, obligations outstanding under the Facility Agreement may be accelerated and may become or be declared immediately due and payable. As of March 31, 2017, we were in compliance with all of the financial covenants of the Facility Agreement.
  (was, 2017-02-08, similarity 0.9871):
[0001628280-17-000997:note_history:2]
We have a $6.2 million facility agreement (Facility Agreement) between Powell (UK) Limited and a large international bank. This Facility Agreement provides Powell (UK) Limited the ability to enter into bank guarantees as well as forward exchange contracts and currency options. At December 31, 2016, we had outstanding guarantees totaling $4.8 million under this Facility Agreement and amounts available under this Facility Agreement were $1.4 million.  This facility expires in May 2017. The Facility Agreement provides for financial covenants and customary events of default, and carries cross-default provisions with our U.S. Revolver. If an event of default (as defined in the Facility Agreement) occurs and is continuing, per the terms and subject to the conditions set forth therein, obligations outstanding under the Facility Agreement may be accelerated and may become or be declared immediately due and payable. As of December 31, 2016, we were in compliance with all of the financial covenants of the Facility Agreement.

- changed (2017-05-03):
[0000080420-17-000009:note_history:3]
Certain of our customer contracts have schedule and performance obligation clauses that, if we fail to meet them, could require us to pay liquidated damages. Each individual contract defines the conditions under which the customer may make a claim against us. As of March 31, 2017, our exposure to possible liquidated damages was $2.7 million, of which approximately $1.7 million is probable.  Based on our actual or projected failure to meet these various contractual commitments, $1.6 million has been recorded as a reduction to revenue. We will attempt to obtain change orders, contract extensions or accelerate project completion which may resolve the potential for any unaccrued liquidated damage. Should we fail to achieve relief on some or all of these contractual obligations, we could be required to pay additional liquidated damages, which could negatively impact our future operating results.
  (was, 2017-02-08, similarity 0.9927):
[0001628280-17-000997:note_history:3]
Certain of our customer contracts have schedule and performance obligation clauses that, if we fail to meet them, could require us to pay liquidated damages. Each individual contract defines the conditions under which the customer may make a claim against us. As of December 31, 2016, our exposure to possible liquidated damages was $2.7 million, of which approximately $1.7 million is probable.  Based on our actual or projected failure to meet these various contractual commitments, $1.5 million has been recorded as a reduction to revenue. We will attempt to obtain change orders, contract extensions or accelerate project completion which may resolve the potential for any unaccrued liquidated damage. Should we fail to achieve relief on some or all of these contractual obligations, we could be required to pay additional liquidated damages, which could negatively impact our future operating results.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureAndSignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2017-05-03):
[0000080420-17-000009:note_history:4]
References to Fiscal 2017 and Fiscal 2016 used throughout this report shall mean our fiscal years ended September 30, 2017 and 2016, respectively.
  (was, 2017-02-08, similarity 0.9597):
[0001628280-17-000997:note_history:4]
References to Fiscal 2017, Fiscal 2016 and Fiscal 2015 used throughout this report shall mean our fiscal years ended September 30, 2017, 2016 and 2015, respectively.

- changed (2017-05-03):
[0000080420-17-000009:note_history:5]
In May 2014, the Financial Accounting Standards Board (FASB) issued a new standard on revenue recognition that supersedes previously issued revenue recognition guidance. This standard provides a five-step approach to be applied to all contracts with customers and requires expanded disclosures about the nature, amount, timing and uncertainty of revenue (and the related cash flows) arising from customer contracts, significant judgments and changes in judgments used in applying the revenue model and the assets recognized from costs incurred to obtain or fulfill a contract. This standard is effective for fiscal years, and interim periods within those years, beginning after December 15, 2017, which would be our fiscal year ending September 30, 2019. We continue to work with various other companies in our industry as well as outside accounting advisors to evaluate this standard and understand the impact that the adoption of this new standard will have on our consolidated financial statements and related disclosures. We believe that we will continue to recognize revenue over time utilizing the cost-to-cost method to measure our progress for the vast majority of our contracts. We have not yet selected a transition method nor have we determined the effect of the standard on our ongoing financial reporting.
  (was, 2017-02-08, similarity 0.6113):
[0001628280-17-000997:note_history:5]
In May 2014, the Financial Accounting Standards Board (FASB) issued a new standard on revenue recognition that supersedes previously issued revenue recognition guidance. This standard provides a five-step approach to be applied to all contracts with customers and requires expanded disclosures about the nature, amount, timing and uncertainty of revenue (and the related cash flows) arising from customer contracts, significant judgments and changes in judgments used in applying the revenue model and the assets recognized from costs incurred to obtain or fulfill a contract. This guidance is now effective for fiscal years, and interim periods within those years, beginning after December 15, 2017, which would be our fiscal year ending September 30, 2019. The standard permits the use of either the full retrospective or modified retrospective transition method; therefore, we are evaluating the effect that this new guidance will have on our consolidated financial statements and related disclosures. We have not yet selected a transition method nor have we determined the effect of the standard on our ongoing financial reporting.

- removed (2017-05-03):
[0001628280-17-000997:note_history:6]
In August 2014, the FASB issued guidance to address the diversity in practice in determining when there is substantial doubt about an entity’s ability to continue as a going concern and when and how an entity must disclose certain relevant conditions and events. This update requires an entity to evaluate whether there are conditions or events, considered in the aggregate, that raise substantial doubt about the entity’s ability to continue as a going concern for a period of one year after the date that the financial statements are issued (or available to be issued). If such conditions or events exist, an entity should disclose that there is substantial doubt about the entity’s ability to continue as a going concern for a period of one year after the date that the financial statements are issued (or available to be issued), along with the principal conditions or events that raise substantial doubt, management’s evaluation of the significance of those conditions or events in relation to the entity’s ability to meet its obligations and management’s plans that are intended to mitigate those conditions or events. This guidance impacts the disclosure and presentation of any substantial doubt about our ability to continue as a going concern, if such substantial doubt were to exist. This guidance is effective for our first quarter ended December 31, 2016 and does not have an impact on disclosures in our condensed consolidated financial statements.

- removed (2017-05-03):
[0001628280-17-000997:note_history:7]
In March 2016, the FASB issued new guidance on stock-based compensation, which includes amendments to existing guidance for employee share-based payment accounting. We elected to early adopt this new guidance in the first quarter of Fiscal 2017.  Beginning with this quarter, stock-based compensation excess tax benefits or deficiencies are reflected in the Condensed Consolidated Statement of Operations as a component of income taxes, whereas they were previously recorded in additional paid in capital in the Condensed Consolidated Statement of Stockholders’ Equity.  Additionally, we will now present excess tax benefits as an operating activity in the Condensed Consolidated Statements of Cash Flows, and prior periods will be adjusted accordingly.  Finally, we will continue to account for forfeitures as they occur, rather than estimate expected forfeitures.


## us-gaap:LongTermDebtTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2017-05-03):
[0000080420-17-000009:note_history:8]
|  | March 31, 2017 |  | September 30, 2016 |
| Industrial development revenue bonds | $ | 2,000 |  |  | $ | 2,400 |  |
| Less current portion | (400 | ) |  | (400 | ) |
| Total long-term debt and capital lease obligations | $ | 1,600 |  |  | $ | 2,000 |  |
  (was, 2017-02-08, similarity 0.9749):
[0001628280-17-000997:note_history:8]
|  | December 31 2016 |  | September 30 2016 |
| Industrial development revenue bonds | $ | 2,000 |  |  | $ | 2,400 |  |
| Less current portion | (400 | ) |  | (400 | ) |
| Total long-term debt and capital lease obligations | $ | 1,600 |  |  | $ | 2,000 |  |

- changed (2017-05-03):
[0000080420-17-000009:note_history:9]
We have a $75.0 million revolving credit facility (U.S. Revolver) to provide working capital support and letters of credit. The interest rate for amounts outstanding under the U.S. Revolver is a floating rate based upon the higher of the Federal Funds Rate plus 0.5%, the bank’s prime rate, or the Eurocurrency rate plus 1.00%. Once the applicable rate is determined, a margin ranging up to 1.75%, as determined by our consolidated leverage ratio, is added to the applicable rate. The U.S. Revolver provides for the issuance of letters of credit which reduce the amounts that may be borrowed under this revolver. We had $21.4 million of outstanding letters of credit under the U.S. Revolver at March 31, 2017.
  (was, 2017-02-08, similarity 0.8749):
[0001628280-17-000997:note_history:9]
We have a $75.0 million revolving credit facility (U.S. Revolver) to provide working capital support and letters of credit. The interest rate for amounts outstanding under the U.S. Revolver is a floating rate based upon the higher of the Federal Funds Rate plus 0.5%, the bank’s prime rate, or the Eurocurrency rate plus 1.00%. Once the applicable rate is determined, a margin ranging up to 1.75%, as determined by our consolidated leverage ratio, is added to the applicable rate. The U.S. Revolver provides for the issuance of letters of credit which reduce the amounts that may be borrowed under this revolver. The amount available under the U.S. Revolver was reduced by $20.3 million for our outstanding letters of credit at December 31, 2016.

- changed (2017-05-03):
[0000080420-17-000009:note_history:10]
There were no borrowings outstanding under the U.S. Revolver as of March 31, 2017. Amounts available under the U.S. Revolver were $53.6 million at March 31, 2017. The U.S. Revolver expires on December 31, 2018.
  (was, 2017-02-08, similarity 0.9531):
[0001628280-17-000997:note_history:10]
There were no borrowings outstanding under the U.S. Revolver as of December 31, 2016.  Amounts available under the U.S. Revolver were $54.7 million at December 31, 2016. The U.S. Revolver expires on December 31, 2018.

- changed (2017-05-03):
[0000080420-17-000009:note_history:11]
The U.S. Revolver is collateralized by a pledge of 100% of the voting capital stock of each of our domestic subsidiaries and 65% of the voting capital stock of each non-domestic subsidiary. The U.S. Revolver provides for customary events of default and carries cross-default provisions with other existing debt agreements. If an event of default (as defined in the U.S. Revolver) occurs and is continuing, on the terms and subject to the conditions set forth in the U.S. Revolver, amounts outstanding under the U.S. Revolver may be accelerated and may become immediately due and payable. As of March 31, 2017, we were in compliance with all of the financial covenants of the U.S. Revolver.
  (was, 2017-02-08, similarity 0.9698):
[0001628280-17-000997:note_history:11]
The U.S. Revolver is collateralized by a pledge of 100% of the voting capital stock of each of our domestic subsidiaries and 65% of the voting capital stock of each non-domestic subsidiary, excluding Powell Canada Inc. The U.S. Revolver provides for customary events of default and carries cross-default provisions with other existing debt agreements. If an event of default (as defined in the U.S. Revolver) occurs and is continuing, on the terms and subject to the conditions set forth in the U.S. Revolver, amounts outstanding under the U.S. Revolver may be accelerated and may become immediately due and payable. As of December 31, 2016, we were in compliance with all of the financial covenants of the U.S. Revolver.

- changed (2017-05-03):
[0000080420-17-000009:note_history:12]
We have a $7.5 million credit agreement with a major international bank in Canada (the Canadian Revolver) to provide working capital support and letters of credit for our operations in Canada. The interest rate for amounts outstanding under the Canadian Revolver is a floating interest rate based upon either the Canadian Prime Rate, or the lender’s Bankers’ Acceptance Rate. Once the applicable rate is determined, a margin of 0.50% to 1.75%, as determined by our consolidated leverage ratio, is added to the applicable rate. The Canadian Revolver provides for the issuance of letters of credit which reduce the amounts that may be borrowed under this revolver. There were no outstanding letters of credit under the Canadian Revolver at March 31, 2017.
  (was, 2017-02-08, similarity 0.6995):
[0001628280-17-000997:note_history:12]
We have a $7.4 million credit agreement with a major international bank in Canada (the Canadian Revolver) to provide working capital support and letters of credit for our operations in Canada. The Canadian Revolver provides for the issuance of letters of credit which reduce the amounts that may be borrowed under this revolver. There were no outstanding letters of credit under the Canadian Revolver at December 31, 2016. The interest rate for amounts outstanding under the Canadian Revolver is a floating interest rate based upon either the Canadian Prime Rate, or the lender’s Bankers’ Acceptance Rate. Once the applicable rate is determined, a margin of 0.50% to 1.75%, as determined by our consolidated leverage ratio, is added to the applicable rate.

- changed (2017-05-03):
[0000080420-17-000009:note_history:13]
There were no borrowings outstanding under the Canadian Revolver as of March 31, 2017 and amounts available under the Canadian Revolver were $7.5 million at March 31, 2017. The Canadian Revolver expires on March 31, 2018.
  (was, 2017-02-08, similarity 0.9366):
[0001628280-17-000997:note_history:13]
There were no borrowings outstanding under the Canadian Revolver as of December 31, 2016 and amounts available under the Canadian Revolver were $7.4 million at December 31, 2016. The Canadian Revolver expires on March 31, 2018.

- changed (2017-05-03):
[0000080420-17-000009:note_history:14]
The Canadian Revolver is secured by the assets of our Canadian operations and provides for customary events of default and carries cross-default provisions with our existing debt agreements. If an event of default (as defined in the Canadian Revolver) occurs and is continuing, per the terms and subject to the conditions set forth in the Canadian Revolver, amounts outstanding under the Canadian Revolver may be accelerated and may become immediately due and payable. As of March 31, 2017, we were in compliance with all of the financial covenants of the Canadian Revolver.
  (was, 2017-02-08, similarity 0.9886):
[0001628280-17-000997:note_history:14]
The Canadian Revolver is secured by the assets of our Canadian operations and provides for customary events of default and carries cross-default provisions with our existing debt agreements. If an event of default (as defined in the Canadian Revolver) occurs and is continuing, per the terms and subject to the conditions set forth in the Canadian Revolver, amounts outstanding under the Canadian Revolver may be accelerated and may become immediately due and payable. As of December 31, 2016, we were in compliance with all of the financial covenants of the Canadian Revolver.

- changed (2017-05-03):
[0000080420-17-000009:note_history:15]
We borrowed $8.0 million in October 2001 through a loan agreement funded with proceeds from tax-exempt industrial development revenue bonds (Bonds). These Bonds were issued by the Illinois Development Finance Authority and were used for the completion of our Northlake, Illinois facility. Pursuant to the Bond issuance, a reimbursement agreement between us and a major domestic bank required an issuance by the bank of an irrevocable direct-pay letter of credit (Bond LC), as collateral, to the Bonds’ trustee to guarantee payment of the Bonds’ principal and interest when due. The Bond LC is subject to both early termination and extension provisions customary to such agreements, as well as various covenants, for which we were in compliance at March 31, 2017. While the Bonds mature in 2021, the reimbursement agreement requires annual redemptions of $0.4 million that commenced on October 25, 2002. A sinking fund is used for the redemption of the Bonds. The Bonds bear interest at a floating rate determined weekly by the Bonds’ remarketing agent, which was the underwriter for the Bonds and is an affiliate of the bank. This interest rate was 1.04% as of March 31, 2017.
  (was, 2017-02-08, similarity 0.9887):
[0001628280-17-000997:note_history:15]
We borrowed $8.0 million in October 2001 through a loan agreement funded with proceeds from tax-exempt industrial development revenue bonds (Bonds). These Bonds were issued by the Illinois Development Finance Authority and were used for the completion of our Northlake, Illinois facility. Pursuant to the Bond issuance, a reimbursement agreement between us and a major domestic bank required an issuance by the bank of an irrevocable direct-pay letter of credit (Bond LC), as collateral, to the Bonds’ trustee to guarantee payment of the Bonds’ principal and interest when due. The Bond LC is subject to both early termination and extension provisions customary to such agreements, as well as various covenants, for which we were in compliance at December 31, 2016. While the Bonds mature in 2021, the reimbursement agreement requires annual redemptions of $0.4 million that commenced on October 25, 2002. A sinking fund is used for the redemption of the Bonds. The Bonds bear interest at a floating rate determined weekly by the Bonds’ remarketing agent, which was the underwriter for the Bonds and is an affiliate of the bank. This interest rate was 0.90% as of December 31, 2016.


## us-gaap:ScheduleOfDebtInstrumentsTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2017-05-03):
[0000080420-17-000009:note_history:16]
|  | March 31, 2017 |  | September 30, 2016 |
| Industrial development revenue bonds | $ | 2,000 |  |  | $ | 2,400 |  |
| Less current portion | (400 | ) |  | (400 | ) |
| Total long-term debt and capital lease obligations | $ | 1,600 |  |  | $ | 2,000 |  |
  (was, 2017-02-08, similarity 0.9749):
[0001628280-17-000997:note_history:16]
|  | December 31 2016 |  | September 30 2016 |
| Industrial development revenue bonds | $ | 2,000 |  |  | $ | 2,400 |  |
| Less current portion | (400 | ) |  | (400 | ) |
| Total long-term debt and capital lease obligations | $ | 1,600 |  |  | $ | 2,000 |  |
