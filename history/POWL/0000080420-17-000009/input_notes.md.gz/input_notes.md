# POWL notes — 0000080420-17-000009


## us-gaap:AllowanceForCreditLossesOnFinancingReceivablesTableTextBlock

[0000080420-17-000009:notes:1]
[same as prior period, unchanged from 0001628280-17-000997:notes:1]

[0000080420-17-000009:notes:2]
|  | Three months ended March 31, |  | Six months ended March 31, |
|  | 2017 |  | 2016 |  | 2017 |  | 2016 |
| Balance at beginning of period | $ | 664 |  |  | $ | 1,010 |  |  | $ | 811 |  |  | $ | 746 |  |
| Bad debt expense (recovery) | 16 |  |  | 92 |  |  | (97 | ) |  | 339 |  |
| Uncollectible accounts written off, net of recoveries | (373 | ) |  | (141 | ) |  | (400 | ) |  | (114 | ) |
| Change due to foreign currency translation | 3 |  |  | 15 |  |  | (4 | ) |  | 5 |  |
| Balance at end of period | $ | 310 |  |  | $ | 976 |  |  | $ | 310 |  |  | $ | 976 |  |


## us-gaap:BasisOfAccountingPolicyPolicyTextBlock

[0000080420-17-000009:notes:3]
[same as prior period, unchanged from 0001628280-17-000997:notes:3]

[0000080420-17-000009:notes:4]
[same as prior period, unchanged from 0001628280-17-000997:notes:4]

[0000080420-17-000009:notes:5]
[same as prior period, unchanged from 0001628280-17-000997:notes:5]

[0000080420-17-000009:notes:6]
[same as prior period, unchanged from 0001628280-17-000997:notes:6]

[0000080420-17-000009:notes:7]
References to Fiscal 2017 and Fiscal 2016 used throughout this report shall mean our fiscal years ended September 30, 2017 and 2016, respectively.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0000080420-17-000009:notes:8]
COMMITMENTS AND CONTINGENCIES

[0000080420-17-000009:notes:9]
Long-Term Debt

[0000080420-17-000009:notes:10]
See Note E herein for discussion of our long-term debt.

[0000080420-17-000009:notes:11]
Letters of Credit and Surety Bonds

[0000080420-17-000009:notes:12]
Certain customers require us to post bank letter of credit guarantees or surety bonds. These guarantees and surety bonds assure that we will perform under the terms of our contract. In the event of default, the counterparty may demand payment from the bank under a letter of credit or performance by the surety under a bond. To date, there have been no significant expenses related to either letters of credit or surety bonds for the periods reported. We were contingently liable for secured and unsecured letters of credit of $21.4 million as of March 31, 2017. We also had surety bonds totaling $216.0 million that were outstanding, with additional bonding capacity of $534.0 million available, at March 31, 2017.

[0000080420-17-000009:notes:13]
We have a $6.2 million facility agreement (Facility Agreement) between Powell (UK) Limited and a large international bank. This Facility Agreement provides Powell (UK) Limited the ability to enter into bank guarantees as well as forward exchange contracts and currency options. At March 31, 2017, we had outstanding guarantees totaling $4.7 million under this Facility Agreement and amounts available under this Facility Agreement were $1.5 million.  This facility expires in May 2017. The Facility Agreement provides for financial covenants and customary events of default, and carries cross-default provisions with our U.S. Revolver. If an event of default (as defined in the Facility Agreement) occurs and is continuing, per the terms and subject to the conditions set forth therein, obligations outstanding under the Facility Agreement may be accelerated and may become or be declared immediately due and payable. As of March 31, 2017, we were in compliance with all of the financial covenants of the Facility Agreement.

[0000080420-17-000009:notes:14]
Litigation

[0000080420-17-000009:notes:15]
We are involved in various legal proceedings, claims and other disputes arising from our commercial operations, projects, employees and other matters which, in general, are subject to uncertainties and in which the outcomes are not predictable. Although we can give no assurances about the resolution of pending claims, litigation or other disputes and the effect such outcomes may have on us, management believes that any ultimate liability resulting from the outcome of such proceedings, to the extent not otherwise provided or covered by insurance, will not have a material adverse effect on our consolidated financial position or results of operations or liquidity.

[0000080420-17-000009:notes:16]
Liquidated Damages

[0000080420-17-000009:notes:17]
Certain of our customer contracts have schedule and performance obligation clauses that, if we fail to meet them, could require us to pay liquidated damages. Each individual contract defines the conditions under which the customer may make a claim against us. As of March 31, 2017, our exposure to possible liquidated damages was $2.7 million, of which approximately $1.7 million is probable.  Based on our actual or projected failure to meet these various contractual commitments, $1.6 million has been recorded as a reduction to revenue. We will attempt to obtain change orders, contract extensions or accelerate project completion which may resolve the potential for any unaccrued liquidated damage. Should we fail to achieve relief on some or all of these contractual obligations, we could be required to pay additional liquidated damages, which could negatively impact our future operating results.


## us-gaap:CostsInExcessOfBillingsAndBillingsInExcessOfCostsTableTextBlock

[0000080420-17-000009:notes:18]
[same as prior period, unchanged from 0001628280-17-000997:notes:18]

[0000080420-17-000009:notes:19]
|  | March 31, 2017 |  | September 30, 2016 |
| Costs incurred on uncompleted contracts | $ | 770,679 |  |  | $ | 1,088,921 |  |
| Estimated earnings | 245,832 |  |  | 350,125 |  |
|  | 1,016,511 |  |  | 1,439,046 |  |
| Less: Billings to date | (992,432 | ) |  | (1,416,914 | ) |
| Net underbilled position | $ | 24,079 |  |  | $ | 22,132 |  |
| Included in the accompanying balance sheets under the following captions: |  |  |  |
| Costs and estimated earnings in excess of billings on uncompleted contracts – underbilled | $ | 56,618 |  |  | $ | 66,106 |  |
| Billings in excess of costs and estimated earnings on uncompleted contracts – overbilled | (32,539 | ) |  | (43,974 | ) |
| Net underbilled position | $ | 24,079 |  |  | $ | 22,132 |  |


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0000080420-17-000009:notes:20]
[same as prior period, unchanged from 0001628280-17-000997:notes:20]

[0000080420-17-000009:notes:21]
[same as prior period, unchanged from 0001628280-17-000997:notes:21]

[0000080420-17-000009:notes:22]
[same as prior period, unchanged from 0001628280-17-000997:notes:22]

[0000080420-17-000009:notes:23]
We issue restricted stock units (RSUs) to certain officers and key employees of the Company.  The fair value of the RSUs is based on the closing price of our common stock as reported on the NASDAQ Global Market on the grant dates. These grants vest over a three-year period from their date of issuance.  Sixty percent of the grant is time-based and vests over a three-year period on each anniversary of the grant date, based on continued employment.  The remaining forty percent of the grant will be earned based on the three-year earnings performance of the Company following the grant date. At March 31, 2017, there were 193,537 RSUs outstanding. The RSUs do not have voting rights but do receive dividend equivalents upon vesting; additionally, the shares of common stock underlying the RSUs are not considered issued and outstanding until vested and common stock is issued.

[0000080420-17-000009:notes:24]
RSU activity (number of shares) for the six months ended March 31, 2017 is summarized below:

[0000080420-17-000009:notes:25]
|  | Number ofRestrictedStockUnits |  | WeightedAverageFair ValuePer Share |
| Outstanding at September 30, 2016 | 159,988 |  |  | $ | 43.12 |  |
| Granted | 61,100 |  |  | 39.65 |  |
| Vested | (27,551 | ) |  | 39.08 |  |
| Outstanding at March 31, 2017 | 193,537 |  |  | $ | 42.60 |  |

[0000080420-17-000009:notes:26]
During the six months ended March 31, 2017 and 2016, we recorded compensation expense of $1.3 million and $2.7 million, respectively, related to the RSUs.  The higher compensation expense recorded in the six months ended March 31, 2016 was primarily due to the departure of our former Chief Executive Officer in December 2015, which included the accelerated vesting of 60,909 shares.

[0000080420-17-000009:notes:27]
[same as prior period, unchanged from 0001628280-17-000997:notes:27]

[0000080420-17-000009:notes:28]
Beginning with the February 2017 grant, fifty-percent of the restricted stock granted to each of our non-employee directors vests immediately, while the remaining fifty-percent will vest on the anniversary of the grant date. Compensation expense will be recognized immediately for the first fifty-percent of the restricted stock granted, while compensation expense for the remaining fifty-percent will be recognized over the remaining vesting period based on the price per share on the grant date.  In February 2017, 17,000 shares of restricted stock were issued to our non-employee directors at a price of $34.24 per share under the 2014 Director Plan.

[0000080420-17-000009:notes:29]
During the six months ended March 31, 2017 and 2016, we recorded compensation expense of $0.5 million and $0.4 million, respectively, related to restricted stock grants.


## us-gaap:EarningsPerShareTextBlock

[0000080420-17-000009:notes:30]
[same as prior period, unchanged from 0001628280-17-000997:notes:30]

[0000080420-17-000009:notes:31]
[same as prior period, unchanged from 0001628280-17-000997:notes:31]

[0000080420-17-000009:notes:32]
[same as prior period, unchanged from 0001628280-17-000997:notes:32]

[0000080420-17-000009:notes:33]
|  | Three months ended March 31, |  | Six months ended March 31, |
|  | 2017 |  | 2016 |  | 2017 |  | 2016 |
| Numerator: |  |  |  |  |  |  |  |
| Net income (loss) | $ | (829 | ) |  | $ | 5,567 |  |  | $ | (1,128 | ) |  | $ | 5,108 |  |
| Denominator: |  |  |  |  |  |  |  |
| Weighted average basic shares | 11,445 |  |  | 11,369 |  |  | 11,441 |  |  | 11,382 |  |
| Dilutive effect of restricted stock units | — |  |  | 53 |  |  | — |  |  | 33 |  |
| Weighted average diluted shares with assumed conversions | 11,445 |  |  | 11,422 |  |  | 11,441 |  |  | 11,415 |  |
| Net income (loss) per share: |  |  |  |  |  |  |  |
| Basic | $ | (0.07 | ) |  | $ | 0.49 |  |  | $ | (0.10 | ) |  | $ | 0.45 |  |
| Diluted | $ | (0.07 | ) |  | $ | 0.49 |  |  | $ | (0.10 | ) |  | $ | 0.45 |  |

[0000080420-17-000009:notes:34]
For the quarter and six months ended March 31, 2017, we incurred net losses and therefore all potential common shares were deemed to be anti-dilutive.


## us-gaap:FairValueDisclosuresTextBlock

[0000080420-17-000009:notes:35]
[same as prior period, unchanged from 0001628280-17-000997:notes:35]

[0000080420-17-000009:notes:36]
[same as prior period, unchanged from 0001628280-17-000997:notes:36]

[0000080420-17-000009:notes:37]
[same as prior period, unchanged from 0001628280-17-000997:notes:37]

[0000080420-17-000009:notes:38]
[same as prior period, unchanged from 0001628280-17-000997:notes:38]

[0000080420-17-000009:notes:39]
[same as prior period, unchanged from 0001628280-17-000997:notes:39]

[0000080420-17-000009:notes:40]
[same as prior period, unchanged from 0001628280-17-000997:notes:40]

[0000080420-17-000009:notes:41]
The following table summarizes the fair value of our assets and liabilities that were accounted for at fair value on a recurring basis as of March 31, 2017 (in thousands):

[0000080420-17-000009:notes:42]
|  | Fair Value Measurements at March 31, 2017 |
|  | Quoted Prices inActive Markets forIdentical Assets(Level 1) |  | Significant OtherObservableInputs(Level 2) |  | SignificantUnobservableInputs(Level 3) |  | Fair Value at March 31, 2017 |
| Assets: |  |  |  |  |  |  |  |
| Cash equivalents | $ | 78,265 |  |  | $ | — |  |  | $ | — |  |  | $ | 78,265 |  |
| Short-term investments | 14,874 |  |  | — |  |  | — |  |  | 14,874 |  |
| Deferred compensation | 782 |  |  | 4,984 |  |  | — |  |  | 5,766 |  |
| Liabilities: |  |  |  |  |  |  |  |
| Deferred compensation | — |  |  | 4,567 |  |  | — |  |  | 4,567 |  |

[0000080420-17-000009:notes:43]
[same as prior period, unchanged from 0001628280-17-000997:notes:43]

[0000080420-17-000009:notes:44]
[same as prior period, unchanged from 0001628280-17-000997:notes:44]

[0000080420-17-000009:notes:45]
[same as prior period, unchanged from 0001628280-17-000997:notes:45]

[0000080420-17-000009:notes:46]
[same as prior period, unchanged from 0001628280-17-000997:notes:46]

[0000080420-17-000009:notes:47]
[same as prior period, unchanged from 0001628280-17-000997:notes:47]

[0000080420-17-000009:notes:48]
Short-term Investments – Short-term investments include time deposits with original maturities of three months or more.

[0000080420-17-000009:notes:49]
[same as prior period, unchanged from 0001628280-17-000997:notes:48]

[0000080420-17-000009:notes:50]
Industrial Development Revenue Bonds– The fair value of our long-term debt depends primarily on the coupon rate of our industrial development revenue bonds.  The carrying value of our long-term debt at March 31, 2017, approximates fair value based on the current coupon rate of the bonds, which is reset weekly. It is classified as a Level 2 input in the fair value measurement hierarchy as there is an active market for the trading of these industrial development revenue bonds.

[0000080420-17-000009:notes:51]
There were no transfers between levels within the fair value measurement hierarchy during the three months ended March 31, 2017.


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0000080420-17-000009:notes:52]
[same as prior period, unchanged from 0001628280-17-000997:notes:51]

[0000080420-17-000009:notes:53]
Our intangible assets consist of goodwill, which is not being amortized, and purchased technology, which is amortized over its estimated useful life.  Intangible assets balances, subject to amortization, at March 31, 2017 and September 30, 2016 consisted of the following (in thousands):

[0000080420-17-000009:notes:54]
|  | March 31, 2017 |  | September 30, 2016 |
|  | GrossCarryingValue |  | AccumulatedAmortization |  | NetCarryingValue |  | GrossCarryingValue |  | AccumulatedAmortization |  | NetCarryingValue |
| Purchased technology | $ | 11,749 |  |  | $ | (10,865 | ) |  | $ | 884 |  |  | $ | 11,749 |  |  | $ | (10,693 | ) |  | $ | 1,056 |  |

[0000080420-17-000009:notes:55]
Amortization of intangible assets was $0.2 million for the six months ended March 31, 2017 and 2016.

[0000080420-17-000009:notes:56]
On August 7, 2006, we purchased certain assets related to the manufacturing of ANSI medium-voltage switchgear and circuit breaker business from General Electric Company (GE). In connection with the acquisition, we entered into a 15-year supply agreement with GE pursuant to which GE would purchase from us all of their requirements for ANSI medium-voltage switchgear and circuit breakers and other related equipment and components (the Products).  In connection with the acquisition, we recorded an intangible asset related to this supply agreement.  On December 30, 2013, we and GE amended the supply agreement to allow GE to manufacture similar Products for sale immediately and allow them to begin purchasing Products from other suppliers beginning December 31, 2014. In return, GE paid us $10 million upon execution of the amended supply agreement and agreed to pay an additional $7 million over three years, beginning March 2015. As of March 31, 2017, the remaining balance of $2.3 million due was classified as other current assets and was received in April 2017. We wrote off the intangible asset related to the original supply agreement and recorded a deferred credit in the amount of $8.1 million at December 31, 2013, the amount by which the proceeds from GE exceeded the unamortized balance of our intangible asset. We are amortizing this deferred credit over the four-year life of the agreement and have recognized gains in other income of $1.0 million for the six months ended March 31, 2017 and 2016.


## us-gaap:IncomeTaxDisclosureTextBlock

[0000080420-17-000009:notes:57]
[same as prior period, unchanged from 0001628280-17-000997:notes:56]

[0000080420-17-000009:notes:58]
[same as prior period, unchanged from 0001628280-17-000997:notes:57]

[0000080420-17-000009:notes:59]
|  | Three months ended March 31, |  | Six months ended March 31, |
|  | 2017 |  | 2016 |  | 2017 |  | 2016 |
| Income (loss) before income taxes | $ | (2,174 | ) |  | $ | 6,294 |  |  | $ | (3,914 | ) |  | $ | 4,788 |  |
| Income tax provision (benefit) | (1,345 | ) |  | 727 |  |  | (2,786 | ) |  | (320 | ) |
| Net income (loss) | $ | (829 | ) |  | $ | 5,567 |  |  | $ | (1,128 | ) |  | $ | 5,108 |  |
| Effective tax rate | 62 | % |  | 12 | % |  | 71 | % |  | (7 | )% |

[0000080420-17-000009:notes:60]
We recorded an income tax benefit of $1.3 million in the second quarter of Fiscal 2017, compared to an income tax provision of $0.7 million in the second quarter of Fiscal 2016.  The effective tax rate for the second quarter of Fiscal 2017 was 62% compared to an effective tax rate of 12% in the second quarter of Fiscal 2016. The effective tax rates for the second quarter of Fiscal 2017 and 2016 were favorably impacted by the lower tax rate in the United Kingdom, the relative amounts of income/loss recognized in various jurisdictions, as well as the utilization of net operating loss carryforwards in Canada that are fully reserved with a valuation allowance.

[0000080420-17-000009:notes:61]
We recorded an income tax benefit of $2.8 million for the six months ended March 31, 2017, compared to an income tax benefit of $0.3 million for the six months ended March 31, 2016.  The effective tax rate was 71% for the six months ended March 31, 2017 compared to a 7% benefit for the six months ended March 31, 2016. The effective tax rates for the six months ended March 31, 2017 and 2016 were favorably impacted by the lower tax rate in the United Kingdom, the relative amounts of income/loss recognized in various jurisdictions, as well as the utilization of net operating loss carryforwards in Canada that are fully reserved with a valuation allowance. A discrete item related to the closing of an IRS audit recorded in the first quarter of Fiscal 2017 also favorably impacted the effective tax rate due to the release of a $0.3 million FIN 48 reserve relating to the Research and Development Tax Credit (R&D Tax Credit).  Additionally, the effective tax rate for the six months ended March 31, 2016 was favorably impacted by a $0.8 million discrete item recorded in the first quarter of Fiscal 2016 related to the retroactive reinstatement of the R&D Tax Credit.


## us-gaap:LongTermDebtTextBlock

[0000080420-17-000009:notes:62]
LONG-TERM DEBT

[0000080420-17-000009:notes:63]
Long-term debt consisted of the following (in thousands):

[0000080420-17-000009:notes:64]
|  | March 31, 2017 |  | September 30, 2016 |
| Industrial development revenue bonds | $ | 2,000 |  |  | $ | 2,400 |  |
| Less current portion | (400 | ) |  | (400 | ) |
| Total long-term debt and capital lease obligations | $ | 1,600 |  |  | $ | 2,000 |  |

[0000080420-17-000009:notes:65]
U.S. Revolver

[0000080420-17-000009:notes:66]
We have a $75.0 million revolving credit facility (U.S. Revolver) to provide working capital support and letters of credit. The interest rate for amounts outstanding under the U.S. Revolver is a floating rate based upon the higher of the Federal Funds Rate plus 0.5%, the bank’s prime rate, or the Eurocurrency rate plus 1.00%. Once the applicable rate is determined, a margin ranging up to 1.75%, as determined by our consolidated leverage ratio, is added to the applicable rate. The U.S. Revolver provides for the issuance of letters of credit which reduce the amounts that may be borrowed under this revolver. We had $21.4 million of outstanding letters of credit under the U.S. Revolver at March 31, 2017.

[0000080420-17-000009:notes:67]
There were no borrowings outstanding under the U.S. Revolver as of March 31, 2017. Amounts available under the U.S. Revolver were $53.6 million at March 31, 2017. The U.S. Revolver expires on December 31, 2018.

[0000080420-17-000009:notes:68]
The U.S. Revolver contains certain restrictive and maintenance-type covenants, such as restrictions on the amount of capital expenditures allowed. It also contains financial covenants defining various financial measures and the levels of these measures with which we must comply, as well as a “material adverse change” clause. A “material adverse change” is defined as a material change in our operations, business, properties, liabilities or condition (financial or otherwise) or a material impairment of our ability to perform our obligations under our credit agreements.

[0000080420-17-000009:notes:69]
The U.S. Revolver is collateralized by a pledge of 100% of the voting capital stock of each of our domestic subsidiaries and 65% of the voting capital stock of each non-domestic subsidiary. The U.S. Revolver provides for customary events of default and carries cross-default provisions with other existing debt agreements. If an event of default (as defined in the U.S. Revolver) occurs and is continuing, on the terms and subject to the conditions set forth in the U.S. Revolver, amounts outstanding under the U.S. Revolver may be accelerated and may become immediately due and payable. As of March 31, 2017, we were in compliance with all of the financial covenants of the U.S. Revolver.

[0000080420-17-000009:notes:70]
Canadian Revolver

[0000080420-17-000009:notes:71]
We have a $7.5 million credit agreement with a major international bank in Canada (the Canadian Revolver) to provide working capital support and letters of credit for our operations in Canada. The interest rate for amounts outstanding under the Canadian Revolver is a floating interest rate based upon either the Canadian Prime Rate, or the lender’s Bankers’ Acceptance Rate. Once the applicable rate is determined, a margin of 0.50% to 1.75%, as determined by our consolidated leverage ratio, is added to the applicable rate. The Canadian Revolver provides for the issuance of letters of credit which reduce the amounts that may be borrowed under this revolver. There were no outstanding letters of credit under the Canadian Revolver at March 31, 2017.

[0000080420-17-000009:notes:72]
There were no borrowings outstanding under the Canadian Revolver as of March 31, 2017 and amounts available under the Canadian Revolver were $7.5 million at March 31, 2017. The Canadian Revolver expires on March 31, 2018.

[0000080420-17-000009:notes:73]
The principal financial covenants are consistent with those described in our U.S. Revolver. The Canadian Revolver contains a “material adverse effect” clause. A “material adverse effect” is defined as a material change in the operations of Powell or Powell Canada Inc. in relation to our financial condition, property, business operations, expected net cash flows, liabilities or capitalization.

[0000080420-17-000009:notes:74]
The Canadian Revolver is secured by the assets of our Canadian operations and provides for customary events of default and carries cross-default provisions with our existing debt agreements. If an event of default (as defined in the Canadian Revolver) occurs and is continuing, per the terms and subject to the conditions set forth in the Canadian Revolver, amounts outstanding under the Canadian Revolver may be accelerated and may become immediately due and payable. As of March 31, 2017, we were in compliance with all of the financial covenants of the Canadian Revolver.

[0000080420-17-000009:notes:75]
Industrial Development Revenue Bonds

[0000080420-17-000009:notes:76]
We borrowed $8.0 million in October 2001 through a loan agreement funded with proceeds from tax-exempt industrial development revenue bonds (Bonds). These Bonds were issued by the Illinois Development Finance Authority and were used for the completion of our Northlake, Illinois facility. Pursuant to the Bond issuance, a reimbursement agreement between us and a major domestic bank required an issuance by the bank of an irrevocable direct-pay letter of credit (Bond LC), as collateral, to the Bonds’ trustee to guarantee payment of the Bonds’ principal and interest when due. The Bond LC is subject to both early termination and extension provisions customary to such agreements, as well as various covenants, for which we were in compliance at March 31, 2017. While the Bonds mature in 2021, the reimbursement agreement requires annual redemptions of $0.4 million that commenced on October 25, 2002. A sinking fund is used for the redemption of the Bonds. The Bonds bear interest at a floating rate determined weekly by the Bonds’ remarketing agent, which was the underwriter for the Bonds and is an affiliate of the bank. This interest rate was 1.04% as of March 31, 2017.


## us-gaap:NewAccountingPronouncementsPolicyPolicyTextBlock

[0000080420-17-000009:notes:77]
New Accounting Standards

[0000080420-17-000009:notes:78]
In May 2014, the Financial Accounting Standards Board (FASB) issued a new standard on revenue recognition that supersedes previously issued revenue recognition guidance. This standard provides a five-step approach to be applied to all contracts with customers and requires expanded disclosures about the nature, amount, timing and uncertainty of revenue (and the related cash flows) arising from customer contracts, significant judgments and changes in judgments used in applying the revenue model and the assets recognized from costs incurred to obtain or fulfill a contract. This standard is effective for fiscal years, and interim periods within those years, beginning after December 15, 2017, which would be our fiscal year ending September 30, 2019. We continue to work with various other companies in our industry as well as outside accounting advisors to evaluate this standard and understand the impact that the adoption of this new standard will have on our consolidated financial statements and related disclosures. We believe that we will continue to recognize revenue over time utilizing the cost-to-cost method to measure our progress for the vast majority of our contracts. We have not yet selected a transition method nor have we determined the effect of the standard on our ongoing financial reporting.

[0000080420-17-000009:notes:79]
In November 2015, the FASB issued an amendment to the topic regarding income taxes which requires an entity to separate deferred income tax liabilities and assets into current and noncurrent amounts in the statement of financial position.  Deferred tax liabilities and assets are classified as current or noncurrent based on the classification of the related asset or liability for financial reporting.  Deferred tax liabilities and assets that are not related to an asset or liability for financial reporting are classified according to the expected reversal date of the temporary difference. To simplify the presentation of deferred income taxes, the amendments require that deferred income tax liabilities and assets be classified as noncurrent in a classified statement of financial position.  This amendment is effective for annual reporting periods beginning after December 15, 2016, which would be our fiscal year ending September 30, 2018.  We have no plans for early adoption. The adoption of this guidance is not expected to have a material impact on our consolidated financial position or results of operations.

[0000080420-17-000009:notes:80]
In February 2016, the FASB issued a new topic on leases which requires lessees to recognize lease assets and lease liabilities on the balance sheet for all leases with terms longer than twelve months. Leases will be classified as either finance or operating, with classification affecting the pattern of expense recognition in the income statement. A modified retrospective transition approach is required for lessees for capital and operating leases existing at, or entered into after, the beginning of the earliest comparative period presented in the financial statements, with certain practical expedients available. The new standard is effective for fiscal years beginning after December 15, 2018, including interim periods within those fiscal years. This would be our fiscal year ending September 30, 2020.  We are currently evaluating the impact of our pending adoption of the new standard, but do not expect it to have a material impact on our consolidated financial position or results of operations.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureAndSignificantAccountingPoliciesTextBlock

[0000080420-17-000009:notes:81]
[same as prior period, unchanged from 0001628280-17-000997:notes:82]

[0000080420-17-000009:notes:82]
[same as prior period, unchanged from 0001628280-17-000997:notes:83]

[0000080420-17-000009:notes:83]
[same as prior period, unchanged from 0001628280-17-000997:notes:84]

[0000080420-17-000009:notes:84]
[same as prior period, unchanged from 0001628280-17-000997:notes:85]

[0000080420-17-000009:notes:85]
[same as prior period, unchanged from 0001628280-17-000997:notes:86]

[0000080420-17-000009:notes:86]
[same as prior period, unchanged from 0001628280-17-000997:notes:87]


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0000080420-17-000009:notes:87]
[same as prior period, unchanged from 0001628280-17-000997:notes:88]

[0000080420-17-000009:notes:88]
During the second quarter of Fiscal 2017, we incurred $0.8 million of restructuring costs as we continue to reduce our overall cost structure to better align our costs with future production requirements.  In the second quarter of Fiscal 2016, we incurred $3.3 million of separation costs due to the restructuring of our senior management team and workforce reductions.

[0000080420-17-000009:notes:89]
For the six months ended March 31, 2016, we incurred $7.1 million of restructuring costs due to the workforce reductions mentioned above, as well as the departure of our former Chief Executive Officer in December 2015.


## us-gaap:ScheduleOfInventoryCurrentTableTextBlock

[0000080420-17-000009:notes:90]
[same as prior period, unchanged from 0001628280-17-000997:notes:90]

[0000080420-17-000009:notes:91]
|  | March 31, 2017 |  | September 30, 2016 |
| Raw materials, parts and subassemblies, net | $ | 19,760 |  |  | $ | 25,525 |  |
| Work-in-progress | 602 |  |  | 996 |  |
| Total inventories | $ | 20,362 |  |  | $ | 26,521 |  |


## us-gaap:ScheduleOfProductWarrantyLiabilityTableTextBlock

[0000080420-17-000009:notes:92]
[same as prior period, unchanged from 0001628280-17-000997:notes:92]

[0000080420-17-000009:notes:93]
|  | Three months ended March 31, |  | Six months ended March 31, |
|  | 2017 |  | 2016 |  | 2017 |  | 2016 |
| Balance at beginning of period | $ | 4,230 |  |  | $ | 5,105 |  |  | $ | 4,639 |  |  | $ | 4,930 |  |
| Increase to warranty expense | 349 |  |  | 832 |  |  | 719 |  |  | 2,158 |  |
| Deduction for warranty charges | (944 | ) |  | (1,175 | ) |  | (1,669 | ) |  | (2,275 | ) |
| Change due to foreign currency translation | 14 |  |  | 25 |  |  | (40 | ) |  | (26 | ) |
| Balance at end of period | $ | 3,649 |  |  | $ | 4,787 |  |  | $ | 3,649 |  |  | $ | 4,787 |  |


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0000080420-17-000009:notes:94]
[same as prior period, unchanged from 0001628280-17-000997:notes:94]

[0000080420-17-000009:notes:95]
[same as prior period, unchanged from 0001628280-17-000997:notes:95]

[0000080420-17-000009:notes:96]
Inventories

[0000080420-17-000009:notes:97]
[same as prior period, unchanged from 0001628280-17-000997:notes:97]

[0000080420-17-000009:notes:98]
Accrued Product Warranty
