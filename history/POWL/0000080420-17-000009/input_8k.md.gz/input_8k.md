# POWL 8-K — 0000080420-17-000006 filed 2017-05-03

## item codes, every 8-K on or before 2017-05-03

- 2017-05-03 0000080420-17-000006 — 2.02, 8.01, 9.01
- 2017-02-23 0000080420-17-000004 — 5.07
- 2017-02-08 0001628280-17-000965 — 2.02 — amendment of 0001628280-17-000949
- 2017-02-07 0001628280-17-000949 — 2.01, 8.01, 9.01
- 2016-12-07 0001193125-16-787354 — 2.02, 9.01
- 2016-11-01 0001193125-16-755475 — 8.01, 9.01
- 2016-09-30 0001193125-16-726999 — 5.02, 8.01, 9.01
- 2016-08-03 0001193125-16-669308 — 2.02, 8.01, 9.01
- 2016-05-04 0001193125-16-576528 — 2.02, 8.01, 9.01
- 2016-02-25 0001193125-16-477896 — 5.07
- 2016-02-03 0001193125-16-449052 — 2.02, 8.01, 9.01
- 2015-12-31 0001193125-15-418363 — 5.02, 7.01, 9.01
- 2015-12-02 0001193125-15-393109 — 2.02, 9.01
- 2015-11-05 0001193125-15-368085 — 8.01, 9.01
- 2015-09-25 0001193125-15-329031 — 5.02
- 2015-08-05 0001193125-15-277912 — 2.02, 8.01, 9.01
- 2015-05-06 0001193125-15-174291 — 2.02, 8.01, 9.01
- 2015-03-06 0001193125-15-081070 — 5.02
- 2015-03-02 0001193125-15-072946 — 5.07
- 2015-02-03 0001193125-15-031772 — 2.02, 8.01, 9.01
- 2014-12-18 0001193125-14-446513 — 8.01, 9.01
- 2014-12-03 0001193125-14-431745 — 2.02, 9.01
- 2014-11-05 0001193125-14-397955 — 8.01, 9.01
- 2014-09-26 0001193125-14-353741 — 7.01, 9.01
- 2014-08-05 0001193125-14-296001 — 2.02, 8.01, 9.01
- 2014-05-07 0001193125-14-187496 — 2.02, 8.01, 9.01
- 2014-03-03 0001193125-14-079843 — 5.02, 5.07
- 2014-02-05 0001193125-14-036633 — 2.02, 8.01, 9.01
- 2014-01-17 0001193125-14-014351 — 1.01, 8.01, 9.01
- 2014-01-06 0001193125-14-002795 — 1.01, 2.03
- 2013-12-06 0001564590-13-001411 — 2.02, 9.01
- 2013-12-05 0001564590-13-001406 — 5.02, 8.01, 9.01
- 2013-11-07 0001193125-13-432950 — 8.01, 9.01
- 2013-08-07 0001193125-13-324337 — 2.02, 9.01
- 2013-05-08 0001193125-13-206800 — 2.02, 9.01
- 2013-02-22 0001193125-13-070971 — 5.02, 5.07
- 2013-02-06 0001193125-13-040556 — 2.02, 9.01
- 2012-12-18 0001193125-12-506417 — 5.02, 9.01
- 2012-12-05 0001193125-12-491749 — 2.02, 9.01
- 2012-10-12 0001193125-12-421889 — 3.03, 5.02, 5.03, 9.01
- 2012-08-09 0001193125-12-344617 — 5.02, 8.01, 9.01
- 2012-08-08 0001193125-12-343630 — 2.02, 9.01
- 2012-05-09 0001193125-12-221356 — 2.02, 9.01
- 2012-02-08 0001193125-12-046560 — 2.02, 9.01
- 2011-12-08 0001193125-11-334810 — 2.02, 9.01
- 2011-11-08 0000950123-11-096524 — 2.02, 2.06, 4.02, 9.01
- 2011-10-14 0000950123-11-090124 — 5.02
- 2011-10-06 0000950123-11-088969 — 5.02
- 2011-09-19 0000950123-11-085224 — 5.02, 9.01
- 2011-09-15 0000950123-11-084806 — 5.02, 9.01
- 2011-08-04 0000950123-11-072788 — 2.02, 9.01
- 2011-07-22 0000950123-11-067402 — 5.07
- 2011-05-24 0000950123-11-053550 — 1.01, 2.03, 9.01
- 2011-05-04 0000950123-11-044561 — 2.02, 9.01
- 2011-02-02 0000950123-11-008188 — 2.02, 9.01
- 2010-12-08 0000950123-10-111987 — 2.02, 9.01
- 2010-08-05 0000950123-10-073114 — 2.02, 9.01
- 2010-05-18 0000950123-10-050900 — 5.02
- 2010-05-05 0000950123-10-044499 — 2.02, 9.01
- 2010-02-03 0000950123-10-008278 — 2.02, 9.01
- 2009-12-21 0000950123-09-072269 — 1.01, 2.01, 2.03, 8.01, 9.01
- 2009-12-09 0000950123-09-069525 — 2.02, 9.01
- 2009-10-27 0000950123-09-053501 — 1.01, 8.01, 9.01
- 2009-08-04 0000950123-09-029476 — 2.02, 9.01
- 2009-05-06 0000950129-09-001498 — 2.02, 9.01
- 2009-03-05 0000950129-09-000749 — 1.01, 9.01
- 2009-02-10 0000950129-09-000349 — 2.02, 9.01
- 2008-12-10 0000950134-08-021934 — 2.02, 9.01
- 2008-08-06 0000950129-08-004267 — 2.02, 9.01
- 2008-07-24 0000950129-08-004063 — 1.01, 5.02, 8.01, 9.01
- 2008-06-16 0000950129-08-003500 — 9.01 — amendment of 0000950134-06-015374
- 2008-06-05 0000950129-08-003378 — 5.02, 9.01
- 2008-05-08 0000950129-08-002843 — 2.02, 9.01
- 2008-02-06 0000950129-08-000533 — 2.02, 9.01
- 2007-12-19 0000950129-07-006277 — 1.01, 2.03, 9.01
- 2007-12-06 0000950129-07-006003 — 2.02, 9.01
- 2007-08-21 0000950129-07-004181 — 2.02, 9.01
- 2007-05-31 0000950129-07-002810 — 2.02, 9.01
- 2007-05-21 0000950129-07-002668 — 2.02, 3.01, 4.02, 9.01
- 2007-04-16 0000950129-07-002002 — 2.02, 4.02, 9.01
- 2007-03-01 0000950129-07-001104 — 5.02, 8.01, 9.01
- 2007-02-08 0000950129-07-000451 — 2.02, 9.01
- 2006-12-08 0000950129-06-010041 — 2.02, 9.01
- 2006-09-08 0000950129-06-008379 — 2.02, 9.01
- 2006-08-09 0000950134-06-015374 — 1.01, 2.01, 8.01, 9.01
- 2006-06-08 0000950129-06-006127 — 2.02, 9.01
- 2006-03-09 0000950129-06-002455 — 2.02, 9.01
- 2005-12-16 0000950129-05-012031 — 2.02, 5.03, 9.01
- 2005-09-13 0000950129-05-009181 — 2.01, 9.01 — amendment of 0000950129-05-006889
- 2005-09-12 0000950129-05-009151 — 2.02, 9.01
- 2005-07-06 0000950129-05-006889 — 1.01, 1.02, 2.01, 2.03, 9.01
- 2005-06-10 0000950129-05-006128 — 2.02, 9.01
- 2005-04-20 0000080420-05-000031 — 5.02
- 2005-03-11 0000080420-05-000024 — 9.01
- 2005-02-25 0000080420-05-000018 — 7.01, 9.01
- 2005-01-21 0000080420-05-000009 — 7.01, 9.01
- 2004-12-17 0000080420-04-000049 — 2.02, 9.01
- 2004-11-01 0000080420-04-000045 — 8.01, 9.01
- 2004-10-08 0001169232-04-005133 — 2.05
- 2004-09-14 0000080420-04-000037 — 5.02
- 2004-09-02 0000080420-04-000030 — 2.02, 9.01
- 2004-06-08 0000080420-04-000021 — 7
- 2004-05-13 0000080420-04-000019 — 4
- 2004-02-27 0000080420-04-000013 — 7
- 2003-12-16 0000950129-03-006136 — 12, 7
- 2003-08-29 0000950129-03-004531 — 12, 7
- 2003-06-03 0000950129-03-003035 — 7, 9
- 2003-05-15 0000950129-03-002812 — 7, 9
- 2002-05-29 0000950129-02-002795 — 4
- 2000-12-21 0000950129-00-006093 — 5, 7
- 1998-09-04 0000950129-98-003802 — 5
- 1996-08-09 0000950129-96-001705 — 2, 7

## late-filing notifications on or before 2017-05-03

- 2007-05-11 0000950129-07-002494 — NT 10-Q, for the period ended 2007-03-31
- 2005-01-18 0000080420-05-000004 — NT 10-K, for the period ended 2004-10-31

## item 2.02 — earnings release, exhibit 99.1

[0000080420-17-000006:8k_2_02:1]
EX-99.1
2
ex991-powlq217earnings.htm
EXHIBIT 99.1

[0000080420-17-000006:8k_2_02:2]
Document

[0000080420-17-000006:8k_2_02:3]
Exhibit 99.1

[0000080420-17-000006:8k_2_02:4]
PRESS RELEASE

[0000080420-17-000006:8k_2_02:5]
Contacts:    Don R. Madison, CFO

[0000080420-17-000006:8k_2_02:6]
Powell Industries, Inc.

[0000080420-17-000006:8k_2_02:7]
713-947-4422

[0000080420-17-000006:8k_2_02:8]
POWELL INDUSTRIES ANNOUNCES FISCAL 2017

[0000080420-17-000006:8k_2_02:9]
SECOND QUARTER RESULTS

[0000080420-17-000006:8k_2_02:10]
HOUSTON — MAY 2, 2017 — Powell Industries, Inc. (NASDAQ: POWL), a leading supplier of custom engineered solutions for the management, control and distribution of electrical energy, today announced results for the fiscal 2017 second quarter ended March 31, 2017.

[0000080420-17-000006:8k_2_02:11]
Revenues for the second quarter of fiscal 2017 were $104.7 million compared to revenues of $152.3 million for the second quarter of fiscal 2016.  The Company reported a net loss for the second quarter of $0.8 million, or $0.07 per share, compared to net income of $5.6 million, or $0.49 per diluted share, for the second quarter of fiscal 2016.  Excluding restructuring and separation costs, net loss for the second quarter of fiscal 2017 was $0.3 million, or $0.02 per share compared to net income for the second quarter of fiscal 2016 of $7.9 million, or $0.69 per diluted share. A reconciliation of this non-GAAP financial measure to net income (loss) is included in the financial tables below.

[0000080420-17-000006:8k_2_02:12]
Brett A. Cope, President and Chief Executive Officer, stated, “Our second quarter results continue to reflect the challenges we faced entering 2017, including a reduced backlog amid

[0000080420-17-000006:8k_2_02:13]
continued downward pressure on Powell’s core oil, gas and petrochemical markets.  Inquiry activity has remained steady relative to what we have seen over the past several quarters, however, new orders fell below our recent run rate primarily due to the timing of order awards.

[0000080420-17-000006:8k_2_02:14]
“Despite current market conditions, Powell remains focused on maintaining our strong financial position and delivering superior project execution and improving efficiencies throughout our operations,” concluded Cope.

[0000080420-17-000006:8k_2_02:15]
New orders placed during the second quarter of fiscal 2017 totaled $62.0 million compared to $91 million in the first quarter of fiscal 2017 and $117 million in the second quarter of fiscal 2016.  The Company’s backlog as of March 31, 2017 was $228 million compared to $271 million as of December 31, 2016 and compared to $357 million at the end of last year’s second quarter.

[0000080420-17-000006:8k_2_02:16]
Looking forward, Powell reaffirms that it expects to report a net loss in fiscal 2017 as the Company continues to be adversely affected by soft market conditions, however, conditions appear to have stabilized.  The Company expects third quarter orders to return to, or exceed, first quarter levels.  Third quarter revenues are expected to decline due to prior lower booking levels as well as customer delays that are pushing orders into the fourth quarter or into fiscal 2018.

[0000080420-17-000006:8k_2_02:17]
CONFERENCE CALL

[0000080420-17-000006:8k_2_02:18]
Powell Industries has scheduled a conference call for Wednesday, May 3, 2017 at 11:00 a.m. eastern time.  To participate in the conference call, dial 412-902-0030 at least 10 minutes before the call begins and ask for the Powell Industries conference call.  A replay of the call will be available approximately two hours after the live broadcast ends and will be accessible until May 10, 2017.  To access the replay, dial 201-612-7415 using a passcode of 13660432#.

[0000080420-17-000006:8k_2_02:19]
Investors, analysts and the general public will also have the opportunity to listen to the conference call over the Internet by visiting powellind.com. To listen to the live call on the web, please visit the website at least fifteen minutes before the call begins to register, download and install any necessary audio software.  For those who cannot listen to the live webcast, an archive will be available shortly after the call and will remain available for approximately 90 days at powellind.com.

[0000080420-17-000006:8k_2_02:20]
Powell Industries, Inc., headquartered in Houston, engineers packaged solutions and systems for the management, control and distribution of electrical energy.  Powell markets include large industrial customers such as utilities, oil and gas producers, refineries, petrochemical plants, pulp and paper producers, mining operations and commuter railways.   For more information, please visit powellind.com.

[0000080420-17-000006:8k_2_02:21]
This press release contains references to certain non-GAAP financial measures discussed above.  Please see the financial table below for more details on these non-GAAP financial measures, including a reconciliation of these non-GAAP financial measures to net income and the reasons management believes these measures are useful to investors.

[0000080420-17-000006:8k_2_02:22]
3

[0000080420-17-000006:8k_2_02:23]
POWELL INDUSTRIES, INC. & SUBSIDIARIES

[0000080420-17-000006:8k_2_02:24]
CONDENSED CONSOLIDATED STATEMENT OF OPERATIONS

[0000080420-17-000006:8k_2_02:25]
|  | Three months ended March 31, |  | Six months ended March 31, |
|  | 2017 |  | 2016 |  | 2017 |  | 2016 |
| Revenues | $ | 104,680 |  |  | $ | 152,266 |  |  | $ | 215,021 |  |  | $ | 302,243 |  |
| Cost of goods sold | 88,858 |  |  | 122,172 |  |  | 184,200 |  |  | 248,999 |  |
| Gross profit | 15,822 |  |  | 30,094 |  |  | 30,821 |  |  | 53,244 |  |
| Selling, general and administrative expenses | 15,994 |  |  | 19,024 |  |  | 31,692 |  |  | 38,425 |  |
| Research and development expenses | 1,623 |  |  | 1,959 |  |  | 3,092 |  |  | 3,813 |  |
| Amortization of intangible assets | 88 |  |  | 86 |  |  | 176 |  |  | 174 |  |
| Restructuring and separation costs | 840 |  |  | 3,259 |  |  | 840 |  |  | 7,056 |  |
| Operating income (loss) | (2,723 | ) |  | 5,766 |  |  | (4,979 | ) |  | 3,776 |  |
| Other income | (507 | ) |  | (507 | ) |  | (1,015 | ) |  | (1,015 | ) |
| Interest expense | 47 |  |  | 50 |  |  | 81 |  |  | 74 |  |
| Interest income | (89 | ) |  | (71 | ) |  | (131 | ) |  | (71 | ) |
| Income (loss) before income taxes | (2,174 | ) |  | 6,294 |  |  | (3,914 | ) |  | 4,788 |  |
| Income tax provision (benefit) | (1,345 | ) |  | 727 |  |  | (2,786 | ) |  | (320 | ) |
| Net income (loss) | $ | (829 | ) |  | $ | 5,567 |  |  | $ | (1,128 | ) |  | $ | 5,108 |  |
| Income (loss) per share: |  |  |  |  |  |  |  |
| Basic | $ | (0.07 | ) |  | $ | 0.49 |  |  | $ | (0.10 | ) |  | $ | 0.45 |  |
| Diluted | $ | (0.07 | ) |  | $ | 0.49 |  |  | $ | (0.10 | ) |  | 0.45 |  |
| Weighted average shares: |  |  |  |  |  |  |  |
| Basic | 11,445 |  |  | 11,369 |  |  | 11,441 |  |  | 11,382 |  |
| Diluted | 11,445 |  |  | 11,422 |  |  | 11,441 |  |  | 11,415 |  |
| Dividends per share | $ | 0.26 |  |  | $ | 0.26 |  |  | $ | 0.52 |  |  | $ | 0.52 |  |
| SELECTED FINANCIAL DATA: |  |  |  |  |  |  |  |
| Depreciation and Amortization | $ | 3,163 |  |  | $ | 3,408 |  |  | $ | 6,314 |  |  | $ | 6,692 |  |
| Capital Expenditures | $ | 774 |  |  | $ | 497 |  |  | $ | 1,702 |  |  | $ | 1,126 |  |
| Dividends Paid | $ | 2,968 |  |  | $ | 2,929 |  |  | $ | 5,934 |  |  | $ | 5,921 |  |

[0000080420-17-000006:8k_2_02:26]
4

[0000080420-17-000006:8k_2_02:27]
POWELL INDUSTRIES, INC. & SUBSIDIARIES

[0000080420-17-000006:8k_2_02:28]
CONDENSED CONSOLIDATED BALANCE SHEETS

[0000080420-17-000006:8k_2_02:29]
|  | March 31, |  | September 30, |
|  | 2017 |  | 2016 |
| (In thousands) | (Unaudited) |
| Assets: |  |  |  |
| Cash, cash equivalents and short-term investments | $ | 108,342 |  |  | $ | 97,720 |  |
| Other current assets | 157,659 |  |  | 206,420 |  |
| Property, plant and equipment (net) | 139,417 |  |  | 144,977 |  |
| Long-term assets | 14,541 |  |  | 13,399 |  |
| Total assets | $ | 419,959 |  |  | $ | 462,516 |  |
| Liabilities & equity: |  |  |  |
| Current liabilities | $ | 83,912 |  |  | $ | 118,248 |  |
| Long-term debt, net of current maturities | 1,600 |  |  | 2,000 |  |
| Deferred and other long-term liabilities | 6,495 |  |  | 6,951 |  |
| Stockholders’ equity | 327,952 |  |  | 335,317 |  |
| Total liabilities and stockholders’ equity | $ | 419,959 |  |  | $ | 462,516 |  |
| SELECTED FINANCIAL DATA: |  |  |  |
| Working capital | $ | 182,089 |  |  | $ | 185,892 |  |

[0000080420-17-000006:8k_2_02:30]
POWELL INDUSTRIES, INC. & SUBSIDIARIES

[0000080420-17-000006:8k_2_02:31]
NON-GAAP NET INCOME (LOSS) RECONCILIATION

[0000080420-17-000006:8k_2_02:32]
|  | Three months ended March 31, |  | Six months ended March 31, |
| (In thousands) | 2017 |  | 2016 |  | 2017 |  | 2016 |
|  | (Unaudited) |
| Reconciliation of GAAP Net Income (Loss) to Non-GAAP Net Income (Loss): |  |  |  |  |  |  |  |
| GAAP Net income (loss) | $ | (829 | ) |  | $ | 5,567 |  |  | $ | (1,128 | ) |  | $ | 5,108 |  |
| Non-GAAP Items: |  |  |  |  |  |  |  |
| Restructuring and separation costs | 840 |  |  | 3,259 |  |  | 840 |  |  | 7,056 |  |
| Income tax effect of non-GAAP items | (294 | ) |  | (963 | ) |  | (294 | ) |  | (2,292 | ) |
| Non-GAAP Net income (loss) | $ | (283 | ) |  | $ | 7,863 |  |  | $ | (582 | ) |  | $ | 9,872 |  |
| Diluted shares outstanding | 11,445 |  |  | 11,422 |  |  | 11,441 |  |  | 11,415 |  |
| Diluted Earnings Per Share: |  |  |  |  |  |  |  |
| GAAP earnings (loss) per share | $ | (0.07 | ) |  | $ | 0.49 |  |  | $ | (0.10 | ) |  | $ | 0.45 |  |
| Non-GAAP earnings (loss) per share | $ | (0.02 | ) |  | $ | 0.69 |  |  | $ | (0.05 | ) |  | $ | 0.86 |  |

[0000080420-17-000006:8k_2_02:33]
For all periods presented, the Company defines non-GAAP net income (loss) as net income (loss) from operations which excludes restructuring and separation costs. The income tax effect is based on the applicable statutory rate. Non-GAAP financial measures should not be considered a substitute for, or superior to, measures of financial performance prepared in accordance with GAAP. However, the Company believes by excluding these items, these non-GAAP financial measures are helpful in comparing the historical results to current results because this non-GAAP information provides consistent measures of the underlying results of our ongoing operations.  The Company also believes the disclosure of non-GAAP net income (loss) will help investors meaningfully evaluate and compare its cash flow generating capacity from quarter to quarter and year to year.

[0000080420-17-000006:8k_2_02:34]
The non-GAAP adjustments, and the basis for excluding them from GAAP financial measures, are outlined below:

[0000080420-17-000006:8k_2_02:35]
| • | Restructuring and separation costs, net of tax – For the three months ended March 31, 2017, we recorded $0.8 million in restructuring and separation costs as we continue to reduce our overall cost structure to better align our costs with future production requirements. For the three and six months ended March 31, 2016, we recorded $3.3 million and $7.1 million, respectively in restructuring and separation costs due to the restructuring of our senior management team and the alignment of our salaried and hourly workforce with future production requirements. |

[0000080420-17-000006:8k_2_02:36]
Due to the nature of these items, the Company does not believe that these items reflect its ongoing operations.

[0000080420-17-000006:8k_2_02:37]
# # #

[0000080420-17-000006:8k_2_02:38]
6
