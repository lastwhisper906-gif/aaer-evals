# POWL MD&A — 0000080420-17-000009


## mdna

[0000080420-17-000009:mdna:1]
[same as prior period, unchanged from 0001628280-17-000997:mdna:1]

[0000080420-17-000009:mdna:2]
[same as prior period, unchanged from 0001628280-17-000997:mdna:2]

[0000080420-17-000009:mdna:3]
[same as prior period, unchanged from 0001628280-17-000997:mdna:3]

[0000080420-17-000009:mdna:4]
We develop, design, manufacture and service custom-engineered equipment and systems for the distribution, control and monitoring of electrical energy. Headquartered in Houston, Texas, we serve the oil and gas refining, offshore oil and gas production, petrochemical, pipeline, terminal, mining and metals, light rail traction power, electric utility, pulp and paper and other industrial markets. Revenues and costs are primarily related to custom engineered-to-order equipment and systems and are accounted for under percentage-of-completion accounting which precludes us from providing detailed price and volume information. Our backlog includes various projects that typically take a number of months to produce.

[0000080420-17-000009:mdna:5]
The markets in which we participate are capital intensive and cyclical in nature. Cyclicality is predominantly driven by customer demand, global economic conditions and anticipated environmental, safety or regulatory changes that affect the manner in which our customers proceed with capital investments. Our customers analyze various factors including the demand and price for oil, gas and electrical energy, the overall economic and financial environment, governmental budgets, regulatory actions and environmental concerns. These factors influence the release of new capital projects by our customers, which are traditionally awarded in competitive bid situations. Scheduling of projects is matched to the customer requirements and projects typically take a number of months to produce.  Schedules may change during the course of any particular project and our operating results can therefore be impacted by factors outside of our control. Due to the significant decline in oil and gas prices from late 2014 levels, many of our customers have reduced their capital budgets and cut costs, and in certain instances have delayed or cancelled projects that we were pursuing.  As a result, our project backlog has declined, and may continue to decline, which may further negatively impact our operations for the foreseeable future. In response to our reduced project backlog and the challenging market outlook in our core oil, gas and petrochemical markets, we took steps in Fiscal 2016, and have taken additional actions in Fiscal 2017, to reduce our overall cost structure and better align our costs with future production requirements.

[0000080420-17-000009:mdna:6]
Our strategy in Canada has been to replicate our project-based integration model that we use in our U.S. operations, which allows for the design, fabrication, integration and testing of our products at a single location. This strategic initiative presented challenges for our Canadian operations in prior years, resulting in inefficiencies that led to higher operating costs, gross margin deterioration and operating losses. We took various actions in Canada to mitigate these challenges and continue to see improvements in operational performance. However, our Canadian project backlog has declined due to the adverse market conditions discussed above and we expect these adverse market conditions to negatively impact our Canadian operations for the foreseeable future.

[0000080420-17-000009:mdna:7]
[same as prior period, unchanged from 0001628280-17-000997:mdna:7]

[0000080420-17-000009:mdna:8]
Quarter Ended March 31, 2017 Compared to the Quarter Ended March 31, 2016 (Unaudited)

[0000080420-17-000009:mdna:9]
[same as prior period, unchanged from 0001628280-17-000997:mdna:9]

[0000080420-17-000009:mdna:10]
Revenues decreased by 31%, or $47.6 million, to $104.7 million in the second quarter of Fiscal 2017, compared to the second quarter of Fiscal 2016, primarily due to the continued decrease in our project backlog as we complete existing projects and continue to see lower demand from our customers in our core oil, gas and petrochemical markets. Domestic revenues decreased by 29%, or $31.2 million, to $75.5 million in the second quarter of Fiscal 2017, compared to the second quarter of Fiscal 2016, and international revenues decreased by 36%, or $16.3 million, to $29.1 million in the second quarter of Fiscal 2017, compared to the second quarter of Fiscal 2016. This reduction in revenue year over year was driven by the decline in our project backlog mentioned above. Revenues from commercial and industrial customers decreased by 40%, or $45.7 million, to $69.9 million in the second quarter of Fiscal 2017, compared to the second quarter of Fiscal 2016. Revenues from public and private utilities decreased by 40%, or $10.4 million, to $16.0 million in the second quarter of Fiscal 2017, compared to the second quarter of Fiscal 2016. Revenues from municipal and transit projects increased by 84%, or $8.6 million, to $18.8 million in the second quarter of Fiscal 2017, compared to the second quarter of Fiscal 2016 due to the timing of transit projects and our ability to ramp up across various facilities to meet our customer schedules.

[0000080420-17-000009:mdna:11]
Gross profit for the second quarter of Fiscal 2017 decreased by 47%, or $14.3 million, to $15.8 million, compared to the second quarter of Fiscal 2016, primarily due to the decrease in revenues.  Gross profit as a percentage of revenues decreased to 15% in the second quarter of Fiscal 2017, compared to 20% in the second quarter of Fiscal 2016. Our Canadian operations continued to see positive improvement in gross profit, which was offset primarily by the decline in gross profit in various domestic operations.

[0000080420-17-000009:mdna:12]
Margins continued to be negatively impacted by our reduced volume as a result of weak oil and gas market conditions, competitive pricing pressures and increased volume from our transit projects, which typically have lower margins.

[0000080420-17-000009:mdna:13]
[same as prior period, unchanged from 0001628280-17-000997:mdna:12]

[0000080420-17-000009:mdna:14]
Selling, general and administrative expenses decreased by 16%, or $3.0 million, to $16.0 million during the second quarter of Fiscal 2017, compared to the second quarter of Fiscal 2016, primarily due to the cost reduction efforts we took in Fiscal 2016 in response to our reduced project backlog and adverse market outlook. Selling, general and administrative expenses, as a percentage of revenues, increased to 15% during the second quarter of Fiscal 2017, compared to 12% during the second quarter of Fiscal 2016, primarily due to the reduction in revenue quarter over quarter.

[0000080420-17-000009:mdna:15]
Restructuring and Separation Costs

[0000080420-17-000009:mdna:16]
In the second quarter of Fiscal 2017, we incurred $0.8 million in restructuring and separation costs as we continue to reduce our overall cost structure to better align our costs with future production requirements.  In the second quarter of Fiscal 2016, we incurred approximately $3.3 million of separation costs due to the restructuring of our senior management team and a reduction in our work force.

[0000080420-17-000009:mdna:17]
Income Tax Provision (Benefit)

[0000080420-17-000009:mdna:18]
We recorded an income tax benefit of $1.3 million in the second quarter of Fiscal 2017, compared to an income tax provision of $0.7 million in the second quarter of Fiscal 2016.  The effective tax rate for the second quarter of Fiscal 2017 was 62% compared to an effective tax rate of 12% in the second quarter of Fiscal 2016. The effective tax rates for the second quarter of Fiscal 2017 and 2016 were favorably impacted by the lower tax rate in the United Kingdom, the relative amounts of income/loss recognized in various jurisdictions, as well as the utilization of net operating loss carryforwards in Canada that are fully reserved with a valuation allowance.

[0000080420-17-000009:mdna:19]
Net income (Loss)

[0000080420-17-000009:mdna:20]
In the second quarter of Fiscal 2017, we recorded a loss of $0.8 million, or $0.07 per diluted share compared to income of $5.6 million, or $0.49 per diluted share, in the second quarter of Fiscal 2016. Our decrease in selling, general and administrative expenses and restructuring and separation costs in the second quarter of Fiscal 2017 partially offset the reduction in revenue and gross profit compared to the second quarter of Fiscal 2016, as our project backlog has declined due to depressed market conditions, primarily in our core oil, gas and petrochemical markets.

[0000080420-17-000009:mdna:21]
[same as prior period, unchanged from 0001628280-17-000997:mdna:20]

[0000080420-17-000009:mdna:22]
The order backlog at March 31, 2017 was $227.9 million, which declined from $291.4 million at September 30, 2016.  New orders declined during the second quarter of Fiscal 2017 to $62.0 million, compared to $116.9 million in the second quarter of Fiscal 2016, primarily due to lower demand from our customers in our core oil, gas and petrochemical markets.

[0000080420-17-000009:mdna:23]
Six Months Ended March 31, 2017 Compared to the Six Months Ended March 31, 2016 (Unaudited)

[0000080420-17-000009:mdna:24]
Revenue and Gross Profit

[0000080420-17-000009:mdna:25]
Revenues decreased by 29% or $87.2 million, to $215.0 million for the six months ended March 31, 2017, compared to the six months ended March 31, 2016, primarily due to the continued decrease in our project backlog as we complete existing projects and continue to see lower demand from our customers in our core oil, gas and petrochemical markets. Domestic revenues decreased by 24%, or $51.1 million, to $161.2 million for the six months ended March 31, 2017, compared to the six months ended March 31, 2016, and international revenues decreased by 40% or $36.2 million, to $53.9 million for the six months ended March 31, 2017, compared to the six months ended March 31, 2016. This reduction in revenue year over year was driven by the decline in our project backlog mentioned above. Revenues from commercial and industrial customers decreased by 37%, or $85.5 million, to $142.6 million for the six months ended March 31, 2017, compared to the six months ended March 31, 2016. Revenues from public and private utilities decreased by 41%, or $22.6 million, to $32.5 million for the six months ended March 31, 2017, compared to the six months ended March 31, 2016. Revenues from municipal and transit projects increased by 111%, or $21.0 million, to $39.9 million for the six months ended March 31, 2017, compared to the six months ended March 31, 2016 due to the timing of transit projects and our ability to ramp up across various facilities to meet our customer schedules.

[0000080420-17-000009:mdna:26]
Gross profit for the six months ended March 31, 2017 decreased by 42%, or $22.4 million, to $30.8 million, compared to the six months ended March 31, 2016, primarily due to the decrease in revenues.  Gross profit as a percentage of revenues decreased to 14% for the six months ended March 31, 2017, compared to 18% for the six months ended March 31, 2016. Our Canadian operations experienced an increase in gross profit, which was offset primarily by the decline in gross profit from our domestic operations. Margins were negatively impacted primarily by our reduced volume as a result of weak oil and gas market conditions, competitive pricing pressure and increased volume from our transit projects, which typically have lower margins.

[0000080420-17-000009:mdna:27]
Selling, General and Administrative Expenses

[0000080420-17-000009:mdna:28]
Selling, general and administrative expenses decreased by 18%, or $6.7 million, to $31.7 million for the six months ended March 31, 2017, compared to the six months ended March 31, 2016, primarily due to the cost reduction efforts we took in Fiscal 2016 in response to our reduced project backlog and adverse market outlook. Selling, general and administrative expenses, as a percentage of revenues, increased to 15% for the six months ended March 31, 2017, compared to13% for the six months ended March 31, 2016, primarily due to the reduction in revenue discussed above.

[0000080420-17-000009:mdna:29]
Restructuring and Separation Costs

[0000080420-17-000009:mdna:30]
For the six months ended March 31, 2017, we incurred $0.8 million in restructuring and separation costs as we continue to reduce our overall cost structure to better align our costs with future production requirements. For the six months ended March 31, 2016, we incurred $7.1 million of separation costs due to workforce reductions, as well as the departure of our former Chief Executive Officer in December 2015.

[0000080420-17-000009:mdna:31]
Income Tax Benefit

[0000080420-17-000009:mdna:32]
We recorded an income tax benefit of $2.8 million for the six months ended March 31, 2017, compared to an income tax benefit of $0.3 million for the six months ended March 31, 2016.  The effective tax rate for the six months ended March 31, 2017 was 71% compared to a 7% benefit for six months ended March 31, 2016. The effective tax rates for the six months ended March 31, 2017 and 2016 were favorably impacted by the lower tax rate in the United Kingdom, the relative amounts of income/loss recognized in various jurisdictions, as well as the utilization of net operating loss carryforwards in Canada that are fully reserved with a valuation allowance. A discrete item related to the closing of an IRS audit recorded in the first quarter of Fiscal 2017 also favorably impacted the effective tax rate due to the release of a $0.3 million FIN 48 reserve relating to the Research and Development Tax Credit (R&D Tax Credit).  Additionally, the effective tax rate for the six months ended March 31, 2016 was favorably impacted by a $0.8 million discrete item recorded in the first quarter of Fiscal 2016 related to the retroactive reinstatement of the R&D Tax Credit.

[0000080420-17-000009:mdna:33]
Net income (Loss)

[0000080420-17-000009:mdna:34]
For the six months ended March 31, 2017, we recorded a loss of $1.1 million, or $0.10 per diluted share compared to income of $5.1 million, or $0.45 per diluted share, for the six months ended March 31, 2016. Our decrease in selling, general and administrative costs in the six months ended March 31, 2017, partially offset the reduction in revenue and gross profit compared to the six months ended March 31, 2016 as our project backlog has declined due to depressed market conditions, primarily in our core oil, gas and petrochemical markets.

[0000080420-17-000009:mdna:35]
Backlog

[0000080420-17-000009:mdna:36]
The order backlog at March 31, 2017 was $227.9 million, which declined from $291.4 million at September 30, 2016.  New orders declined during the six months ended March 31, 2017 to $152.8 million, compared to $218.6 million for the six months ended March 31, 2016, primarily due to lower demand from our customers in our core oil, gas and petrochemical markets.

[0000080420-17-000009:mdna:37]
[same as prior period, unchanged from 0001628280-17-000997:mdna:22]

[0000080420-17-000009:mdna:38]
Cash, cash equivalents and short-term investments increased to $108.3 million at March 31, 2017, compared to $97.7 million at September 30, 2016.  As of March 31, 2017, current assets exceeded current liabilities by 3.2 times and our debt to total capitalization was 0.61%.

[0000080420-17-000009:mdna:39]
We have a $75.0 million revolving credit facility in the U.S. As of March 31, 2017, there were no amounts borrowed under this line of credit. We also have a $7.5 million revolving credit facility in Canada, and as of March 31, 2017 there were no amounts borrowed under this line of credit. Total letters of credit outstanding under our U.S. credit facility, which reduce our availability, were $21.4 million at March 31, 2017 and $26.8 million at September 30, 2016. There were no letters of credit outstanding under

[0000080420-17-000009:mdna:40]
the Canadian revolving credit facility at March 31, 2017 or September 30, 2016. Amounts available at March 31, 2017 under the U.S. and Canadian revolving credit facilities were $53.6 million and $7.5 million, respectively.  Total long-term debt, including current maturities, totaled $2.0 million at March 31, 2017, compared to $2.4 million at September 30, 2016. For further information regarding our debt, see Notes E and F of Notes to Condensed Consolidated Financial Statements.

[0000080420-17-000009:mdna:41]
Approximately $34 million of our cash and short-term investments at March 31, 2017 was held outside of the United States for international operations. It is our intention to indefinitely reinvest all current and future foreign earnings internationally in order to ensure sufficient working capital to support our international operations.  In the event that we elect to repatriate some or all of the foreign earnings that were previously deemed to be indefinitely reinvested outside the U.S., under current tax laws we would incur additional tax expense upon such repatriation.

[0000080420-17-000009:mdna:42]
[same as prior period, unchanged from 0001628280-17-000997:mdna:27]

[0000080420-17-000009:mdna:43]
[same as prior period, unchanged from 0001628280-17-000997:mdna:28]

[0000080420-17-000009:mdna:44]
Cash provided by operating activities decreased to $19.7 million for the six months ended March 31, 2017, compared to cash provided by operating activities of $25.2 million during the same period in Fiscal 2016. This decrease in operating cash flow in the six months ended March 31, 2017 was primarily from increased incentive compensation payments in the first quarter of Fiscal 2017 and the reduction in earnings year over year, offset by reductions in accounts receivable due to lower project activity. Cash flow from operations is primarily influenced by the timing of milestone payments from our customers and the payment terms with our suppliers.

[0000080420-17-000009:mdna:45]
[same as prior period, unchanged from 0001628280-17-000997:mdna:30]

[0000080420-17-000009:mdna:46]
Net cash used in investing activities during the six months ended March 31, 2017 totaled $16.6 million compared to $1.1 million during the same period in Fiscal 2016.  For the six months ended March 31, 2017, we invested $14.9 million in short-term investments and spent approximately $1.7 million on purchases of plant and equipment.

[0000080420-17-000009:mdna:47]
[same as prior period, unchanged from 0001628280-17-000997:mdna:32]

[0000080420-17-000009:mdna:48]
Net cash used in financing activities was $6.7 million for the six months ended March 31, 2017 and $10.9 million during the same period in Fiscal 2016.  This reduction was primarily due to the completion of our share repurchase program in December 2015 discussed below.

[0000080420-17-000009:mdna:49]
[same as prior period, unchanged from 0001628280-17-000997:mdna:34]

[0000080420-17-000009:mdna:50]
On December 17, 2014, our Board of Directors authorized a share repurchase program which allowed us to repurchase up to $25 million of our outstanding stock.  The purchases were made from time to time in the open market through Rule 10b5-1 trading plans in accordance with applicable laws, rules and regulations.  The repurchase of shares was funded from cash on hand and cash provided by operating activities.  The Repurchase Program expired on December 31, 2015.  As of December 31, 2015, we had purchased 806,018 shares at an aggregate cost of $25 million under the Repurchase Program. The average purchase price per share since inception of the program was $31.02.

[0000080420-17-000009:mdna:51]
[same as prior period, unchanged from 0001628280-17-000997:mdna:36]

[0000080420-17-000009:mdna:52]
[same as prior period, unchanged from 0001628280-17-000997:mdna:37]

[0000080420-17-000009:mdna:53]
[same as prior period, unchanged from 0001628280-17-000997:mdna:38]

[0000080420-17-000009:mdna:54]
[same as prior period, unchanged from 0001628280-17-000997:mdna:39]

[0000080420-17-000009:mdna:55]
[same as prior period, unchanged from 0001628280-17-000997:mdna:40]

[0000080420-17-000009:mdna:56]
[same as prior period, unchanged from 0001628280-17-000997:mdna:41]

[0000080420-17-000009:mdna:57]
[same as prior period, unchanged from 0001628280-17-000997:mdna:42]

[0000080420-17-000009:mdna:58]
A significant portion of our revenues have historically been from the oil, gas and petrochemical markets. Unfavorable oil and gas commodity price levels have caused, and may continue to cause, our customers to change their strategies or delay or cancel planned projects. The reduction in available projects across the markets we serve has increased market price pressures during this downward market cycle. This reduction in new business opportunities and increased market price pressures have impacted, and will continue to negatively impact, our backlog, revenues and operating results. It is difficult to predict the duration of the current depressed market cycle.

[0000080420-17-000009:mdna:59]
Our operating results have been, and may continue to be, negatively impacted by factors such as the timing of new order awards, customer approval of final engineering and design specifications and delays in customer construction schedules, all of which have and may continue to have, a negative impact on the timing of project execution. Our operating results also have been, and may continue to be, impacted by the timing and resolution of change orders, project close-out and resolution of potential contract claims and liquidated damages, all of which could improve or deteriorate gross margins during the period in which these items are resolved with our customers. These factors may result in periods of underutilization of our resources and facilities and negatively impact our ability to cover our fixed costs. If our core oil, gas and petrochemical markets remain depressed, or decline further, our project backlog could continue to decline and negatively impact our operations. In response to our reduced project backlog and depressed market outlook, we took steps in Fiscal 2016, and have taken additional actions in Fiscal 2017, to reduce our overall cost structure and better align our costs with future production requirements.  We continue to assess our cost structure, operating performance and service offerings as the oil, gas and petrochemical markets remain challenging and uncertain. However, these actions will not be sufficient to avoid operating losses in the near-term and we expect to report a net loss in Fiscal 2017.

[0000080420-17-000009:mdna:60]
[same as prior period, unchanged from 0001628280-17-000997:mdna:45]
