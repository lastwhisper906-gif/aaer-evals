# POWL MD&A — 0000080420-18-000036


## mdna

[0000080420-18-000036:mdna:1]
Item 7. Management’s Discussion and Analysis of Financial Condition and Results of Operations

[0000080420-18-000036:mdna:2]
Overview

[0000080420-18-000036:mdna:3]
We develop, design, manufacture and service custom-engineered equipment and systems for the distribution, control and monitoring of electrical energy. Headquartered in Houston, Texas, we serve the oil and gas refining, onshore and offshore oil and gas production, petrochemical, pipeline, terminal, mining and metals, light rail traction power, electric utility, pulp and paper and other heavy industrial markets. Revenues and costs are primarily related to custom engineered-to-order equipment and systems and are accounted for under percentage-of-completion accounting, which precludes us from providing detailed price and volume information. Our backlog includes various projects that typically take a number of months to produce.

[0000080420-18-000036:mdna:4]
The markets in which we participate are capital intensive and cyclical in nature. Cyclicality is predominantly driven by customer demand, global economic conditions and anticipated environmental, safety or regulatory changes that affect the manner in which our customers proceed with capital investments. Our customers analyze various factors including the demand and price for oil, gas and electrical energy, the overall economic and financial environment, governmental budgets, regulatory actions and environmental concerns. These factors influence the release of new capital projects by our customers, which are traditionally awarded in competitive bid situations. Scheduling of projects is matched to the customer requirements and projects typically take a number of months to produce. Schedules may change during the course of any particular project and our operating results can therefore be impacted by factors outside of our control.

[0000080420-18-000036:mdna:5]
Due to the significant decline in oil and gas prices from peak 2014 levels, many of our customers have reduced their capital budgets and cut costs, and in certain instances have delayed or cancelled projects that we were pursuing. This has negatively impacted our revenues and project backlog over the last three years. In response to our reduced project backlog and the challenging market outlook in our core oil, gas and petrochemical markets, we took steps in Fiscal 2016 and 2017 to reduce our overall cost structure and better align our costs with future production requirements. Since the second half of Fiscal 2017, our core oil, gas and petrochemical markets have begun to strengthen resulting in increased revenues and orders.

[0000080420-18-000036:mdna:6]
Results of Operations

[0000080420-18-000036:mdna:7]
Twelve Months Ended September 30, 2018 Compared to Twelve Months Ended September 30, 2017

[0000080420-18-000036:mdna:8]
Revenue and Gross Profit

[0000080420-18-000036:mdna:9]
Revenues increased 13%, or $52.8 million, to $448.7 million in Fiscal 2018, compared to Fiscal 2017, primarily due to the increase in orders in Fiscal 2018. Domestic revenues increased 19%, or $52.9 million, to $332.2 million. Our international revenues decreased slightly by less than $0.1 million to $116.5 million in Fiscal 2018, compared to Fiscal 2017 and include both revenue generated from our international facilities, as well as export revenues from our domestic facilities.

[0000080420-18-000036:mdna:10]
Revenues from commercial and industrial projects increased 28%, or $71.0 million, to $325.2 million in Fiscal 2018, compared to Fiscal 2017. Revenues from public and private utilities increased 6%, or $4.6 million, to $89.0 million in Fiscal 2018, compared to Fiscal 2017. Revenues from municipal and transit projects decreased 40%, or $22.8 million, to $34.5 million in Fiscal 2018, compared to Fiscal 2017. The changes in revenues in our market sectors were primarily due to the timing and mix of projects in our backlog. Additionally in Fiscal 2018, remediation efforts after Hurricane Harvey resulted in approximately $7 million of revenue in our commercial and industrial markets.

[0000080420-18-000036:mdna:11]
Gross profit increased 29%, or $14.6 million, to $65.4 million in Fiscal 2018, compared to Fiscal 2017. Gross profit as a percentage of revenues increased to 15% in Fiscal 2018 compared to 13% in Fiscal 2017. Gross profit increased due to improved market conditions and efficiencies resulting from increased volume in our U.S. manufacturing facilities.

[0000080420-18-000036:mdna:12]
Selling, General and Administrative Expenses

[0000080420-18-000036:mdna:13]
Selling, general and administrative expenses increased 9%, or $5.2 million, to $66.8 million in Fiscal 2018, compared to Fiscal 2017, primarily due to the increase in variable performance-based compensation in Fiscal 2018. Selling, general and administrative expenses, as a percentage of revenues, decreased to 15% in Fiscal 2018 compared to 16% in Fiscal 2017, primarily due to the increased revenues discussed above and our continued efforts to align our cost structure with current market conditions.

[0000080420-18-000036:mdna:14]
Restructuring and Separation Expenses

[0000080420-18-000036:mdna:15]
In Fiscal 2018, we incurred $0.8 million of restructuring expense related to anticipated losses on the sublet of a Canadian facility that we exited in a prior period. In Fiscal 2017, we recorded $1.3 million in separation costs as we continued to reduce our overall cost structure to better align our costs with current and future production requirements.

[0000080420-18-000036:mdna:16]
Other Income

[0000080420-18-000036:mdna:17]
We recorded other income of $0.7 million and $2.0 million in Fiscal 2018 and Fiscal 2017, respectively. In Fiscal 2018, we recorded the final $0.5 million amortization of the deferred gain from the amended supply agreement (see Note E of the Notes to Consolidated Financial Statements), as well as a $0.2 million gain from the settlement of a Company-owned life insurance policy. In Fiscal 2017, the $2.0 million of other income was the amortization of the deferred gain mentioned above.

[0000080420-18-000036:mdna:18]
Income Tax Benefit

[0000080420-18-000036:mdna:19]
We recorded an income tax benefit of $0.5 million in Fiscal 2018, compared to the income tax benefit of $7.4 million we recorded in Fiscal 2017. The effective tax rate for Fiscal 2018 was 7% compared to an effective tax rate of 44% for Fiscal 2017. The effective rate for Fiscal 2018 was negatively impacted by the relative amounts of income/loss recognized in the various tax jurisdictions as well as a foreign tax loss which is reserved with a valuation allowance. Additionally, we recorded deferred tax expense of $0.5 million due to the deferred tax rate differential related to the re-measurement of our U.S. deferred tax assets under the Tax Cuts and Jobs Act, which were not realized prior to the end of Fiscal 2018. The effective tax rate for Fiscal 2017 was favorably impacted by the lower tax rate in the U.K., the relative amounts of income/loss recognized in various jurisdictions, the utilization of net operating loss carryforwards in Canada that have been fully reserved with a valuation allowance, as well as $0.9 million of discrete items recognized during the year, primarily related to the Research and Development Tax Credit.

[0000080420-18-000036:mdna:20]
Net Loss

[0000080420-18-000036:mdna:21]
In Fiscal 2018, we recorded a net loss of $7.2 million, or $0.62 per diluted share, an improvement of $2.3 million over the net loss of $9.5 million, or $0.83 per diluted share, that we recorded in Fiscal 2017. The decrease in losses in Fiscal 2018 compared to the prior year were primarily due to increased revenues and gross profit in Fiscal 2018 as we experienced increased demand in our core oil, gas and petrochemical markets.

[0000080420-18-000036:mdna:22]
Backlog

[0000080420-18-000036:mdna:23]
Our backlog includes various projects, some of which are petrochemical, oil and gas construction and transportation infrastructure projects which take a number of months to produce. The order backlog at September 30, 2018 increased to $260.9 million, compared to $250.1 million at September 30, 2017, primarily due to increased demand from municipal and transit projects.

[0000080420-18-000036:mdna:24]
New orders placed in Fiscal 2018 increased to $458.9 million, compared to $355.1 million in Fiscal 2017. This increase in orders was primarily due to improved market conditions in our U.S. commercial and industrial markets.

[0000080420-18-000036:mdna:25]
Twelve Months Ended September 30, 2017 Compared to Twelve Months Ended September 30, 2016

[0000080420-18-000036:mdna:26]
Revenue and Gross Profit

[0000080420-18-000036:mdna:27]
Revenues decreased 30%, or $169.3 million, to $395.9 million in Fiscal 2017, compared to Fiscal 2016, primarily due to the continued decrease in our project backlog as we completed existing projects and continue to see lower demand from our customers in our core oil, gas and petrochemical markets. Domestic revenues decreased 31%, or $126.0 million, to $279.3 million and international revenues decreased 27%, or $43.4 million, to $116.6 million in Fiscal 2017, compared to Fiscal 2016. This reduction in geographic revenues year over year was primarily driven by the decline in our project backlog mentioned above. Revenues from commercial and industrial projects decreased 39%, or $164.9 million, to $254.2 million in Fiscal 2017, compared to Fiscal 2016, primarily due to lower demand in our core oil, gas and petrochemical markets. Revenues from public and private utilities decreased 17%, or $17.5 million, to $84.4 million in Fiscal 2017, compared to Fiscal 2016. Revenues from municipal and transit projects increased 30%, or $13.1 million, to $57.3 million in Fiscal 2017, compared to Fiscal 2016 due to the timing of certain projects.

[0000080420-18-000036:mdna:28]
Gross profit decreased 52%, or $55.4 million, to $50.8 million in Fiscal 2017, compared to Fiscal 2016. Gross profit as a percentage of revenues decreased to 13% in Fiscal 2017 compared to 19% in Fiscal 2016. Gross profit and margins continued to be negatively impacted by our reduced volume resulting in under absorption of our manufacturing facility costs and a shift in our project mix to smaller projects, which typically have lower margins. This decline in volume and margins was primarily due to a decline in our project backlog resulting from depressed market conditions and competitive pricing pressures primarily in our core oil, gas and petrochemical markets. Gross profit margins were negatively impacted by execution challenges on certain municipal transit projects and operating inefficiencies associated with the increased volume from municipal transit projects. The municipal transit market is price competitive and projects typically yield lower margins.

[0000080420-18-000036:mdna:29]
Selling, General and Administrative Expenses

[0000080420-18-000036:mdna:30]
Selling, general and administrative expenses decreased 18%, or $13.4 million, to $61.5 million in Fiscal 2017, compared to Fiscal 2016, primarily due to the cost reduction efforts we took in Fiscal 2016 in response to our adverse market outlook at that time, as well as lower incentive compensation expenses. Selling, general and administrative expenses, as a percentage of revenues, increased to 16% in Fiscal 2017 compared to 13% in Fiscal 2016, primarily due to the reduction in revenue discussed above.

[0000080420-18-000036:mdna:31]
Restructuring and Separation Expenses

[0000080420-18-000036:mdna:32]
In Fiscal 2017, we incurred $1.3 million in separation and restructuring costs, compared to $8.4 million in Fiscal 2016. In Fiscal 2017, we continued to reduce our overall cost structure to better align our costs with current and future production requirements. The separation and restructuring costs incurred in Fiscal 2016 were due to the realignment of our senior management team and workforce reductions as a result of our adverse market outlook at that time, and reductions in project backlog.

[0000080420-18-000036:mdna:33]
Other Income

[0000080420-18-000036:mdna:34]
We recorded other income of $2.0 million in both Fiscal 2017 and Fiscal 2016, which was the amortization of the deferred gain from the amended supply agreement, which was fully amortized at December 31, 2017. See Note E of the Notes to Consolidated Financial Statements.

[0000080420-18-000036:mdna:35]
Income Tax Benefit/Provision

[0000080420-18-000036:mdna:36]
We recorded an income tax benefit of $7.4 million in Fiscal 2017, compared to the income tax provision of $2.3 million we recorded in Fiscal 2016. The effective tax rate for Fiscal 2017 was 44% compared to an effective tax rate of 13% for Fiscal 2016. The effective tax rates for both Fiscal 2017 and 2016 were favorably impacted by the lower tax rate in the U.K., the relative amounts of income/loss recognized in various jurisdictions, as well as the utilization of net operating loss carryforwards in Canada that are fully reserved with a valuation allowance. Additionally, the effective tax rates for both Fiscal 2017 and 2016 were favorably impacted by discrete items recognized, primarily related to the Research and Development Tax Credit (R&D Tax Credit), in the amounts of $0.9 million and $0.8 million, respectively. See Note H of the Notes to Consolidated Financial Statements.

[0000080420-18-000036:mdna:37]
Net Income/Loss

[0000080420-18-000036:mdna:38]
In Fiscal 2017, we recorded a net loss of $9.5 million, or $0.83 per diluted share, a decrease from net income of $15.5 million, or $1.36 per diluted share that we recorded in Fiscal 2016. The reduction in net income compared to the prior year was primarily

[0000080420-18-000036:mdna:39]
due to a decline in our project backlog due to depressed market conditions and competitive pricing pressures, primarily in our core oil, gas and petrochemical markets.

[0000080420-18-000036:mdna:40]
Backlog

[0000080420-18-000036:mdna:41]
Our backlog includes various projects, some of which are petrochemical, oil and gas construction and transportation infrastructure projects, which take a number of months to produce. The order backlog at September 30, 2017 was $250.1 million, compared to $291.4 million at September 30, 2016.

[0000080420-18-000036:mdna:42]
New orders placed in Fiscal 2017 totaled $355.1 million, compared to $417.5 million in Fiscal 2016. This decrease in orders was primarily due to lower demand from our customers in our core oil, gas and petrochemical markets.

[0000080420-18-000036:mdna:43]
Outlook

[0000080420-18-000036:mdna:44]
The markets in which we participate are capital-intensive and cyclical in nature. Cyclicality is predominantly driven by customer demand, global economic conditions and anticipated environmental or regulatory changes which affect the manner in which our customers proceed with capital investments. Our customers analyze various factors including the demand and price for oil, gas and electrical energy, the overall economic and financial environment, governmental budgets, regulatory actions and environmental concerns. These factors influence the release of new capital projects by our customers, which are traditionally awarded in competitive bid situations. Scheduling of projects is matched to customer requirements.  Projects typically take a number of months to produce, and schedules may change during the course of any particular project.

[0000080420-18-000036:mdna:45]
A significant portion of our revenues have historically been from the oil, gas and petrochemical markets. In Fiscal 2018, we saw an increase in customers' investments in maintenance and small projects; however, some customers continue to delay their major capital investments. The reduction in available projects has increased price pressures over the past two years and has impacted, and may continue to negatively impact, our backlog, revenues and operating results.

[0000080420-18-000036:mdna:46]
Our operating results have been impacted by factors such as the timing of new order awards, customer approval of final engineering and design specifications and delays in customer construction schedules, all of which have had a negative impact on the timing of project execution. Our operating results also have been, and could continue to be, impacted by the timing and resolution of change orders, project close-out and resolution of potential contract claims and liquidated damages, all of which could improve or deteriorate gross margins during the period in which these items are resolved with our customers. These factors may result in periods of underutilization of our resources and facilities and negatively impact our ability to cover our fixed costs. We continue to assess our cost structure, operating performance and service offerings as the oil, gas and petrochemical markets remain challenging and uncertain. During Fiscal 2018, we experienced an increase in new orders and saw an improvement in revenues and operating results that we anticipate will continue into Fiscal 2019. We continue to focus on maintaining our cash position, improving efficiencies in production and investing in future business opportunities.

[0000080420-18-000036:mdna:47]
Our increase in project volume has required cash to fund operations, but we believe that our strong working capital position and available cash and short-term investments should be sufficient to finance future operating activities, research and development initiatives, capital improvements and debt repayments for the foreseeable future. We continue to monitor the factors that drive our markets and will continue to strive to maintain our leadership and competitive advantage in the markets we serve while aligning our cost structures with market conditions.

[0000080420-18-000036:mdna:48]
Liquidity and Capital Resources

[0000080420-18-000036:mdna:49]
As of September 30, 2018, current assets exceeded current liabilities by 2.3 times and our debt to total capitalization was 0.53%.

[0000080420-18-000036:mdna:50]
Cash, cash equivalents and short-term investments decreased to $49.8 million at September 30, 2018, compared to $95.2 million at September 30, 2017, as cash has been used in operations to fund working capital requirements from our increased project volume. We also had restricted cash held in a pledged collateral account related to our amended credit agreement (U.S. Revolver) of $25.1 million and $24.9 million, respectively, at September 30, 2018 and 2017. For further information regarding our U.S. Revolver, see Note F of the Notes to Consolidated Financial Statements.

[0000080420-18-000036:mdna:51]
Until we meet certain financial ratios in future quarters, we are unable to borrow under the U.S. Revolver. We believe that our strong working capital position and available cash and short-term investments should be sufficient to finance future operating activities, capital improvements and debt repayments for the foreseeable future. We continue to monitor the factors that drive our markets and will continue to strive to maintain our leadership and competitive advantage in the markets we serve while aligning our cost structures with market conditions.

[0000080420-18-000036:mdna:52]
Our U.S Revolver is a $75.0 million revolving credit facility in the U.S, and as of September 30, 2018, there were no amounts borrowed under this facility. Total letters of credit outstanding under our U.S. Revolver, which reduce the availability of credit under our U.S. Revolver, were $23.1 million at September 30, 2018 and $24.1 million at September 30, 2017. Currently, our U.S. Revolver can only be used for letters of credit until we meet certain financial ratios as described in Note D of the Notes to Consolidated Financial Statements. As of September 30, 2018, $51.9 million was available for the issuance of letters of credit under the U.S. Revolver, subject to the cash collateral requirements mentioned above. Total long-term debt, including current maturities, totaled $1.6 million at September 30, 2018, compared to $2.0 million at September 30, 2017. For further information regarding our debt, see Notes F and G of Notes to Consolidated Financial Statements.

[0000080420-18-000036:mdna:53]
Approximately $26 million of our cash and short-term investments at September 30, 2018 was held outside of the U.S. for international operations. It is our intention to indefinitely reinvest all current and future foreign earnings internationally in order to ensure sufficient working capital to support our international operations. In the event that we elect to repatriate some or all of the foreign earnings that were previously deemed to be indefinitely reinvested outside the U.S., under current tax laws we would incur additional tax expense upon such repatriation.

[0000080420-18-000036:mdna:54]
Operating Activities

[0000080420-18-000036:mdna:55]
During Fiscal 2018, net cash used in operating activities was $28.5 million. During Fiscal 2017, net cash provided by operating activities was $36.8 million and in Fiscal 2016, net cash provided by operating activities was $74.9 million. Cash flow from operations is primarily influenced by the timing of milestone payments from our customers and the payment terms with our suppliers, and is adversely impacted during a ramp up in business as cash is used to fund the projects until billing milestones have been met and payments are collected. Cash flow from operating activities was lower in Fiscal 2018 compared to Fiscal 2017 due to increases in accounts receivable, project billings and inventories as our increased project volume requires cash to fund the growth. Cash flow from operations declined during Fiscal 2017 compared to Fiscal 2016 primarily as a result of our decrease in operating income and the payments of prior year accrued bonuses and commissions. Cash flow from operations in Fiscal 2017 was favorably impacted by the collection of accounts receivable and the reduction in inventories during our down cycle in project activity.

[0000080420-18-000036:mdna:56]
Investing Activities

[0000080420-18-000036:mdna:57]
Purchases of property, plant and equipment during Fiscal 2018 totaled $4.5 million compared to $3.6 million and $3.0 million in Fiscal 2017 and 2016, respectively. The increase in capital spending in Fiscal 2018 was in response to our ramp up in volume. During Fiscal 2018, our net maturities on our short-term investments were reduced to $13.0 million, compared to the $26.8 million in short-term investments we purchased in Fiscal 2017, as we used cash to fund operating activities in Fiscal 2018 as mentioned above. In Fiscal 2017, we reclassified $24.9 million as restricted cash for pledged collateral as stipulated by our amended credit agreement.

[0000080420-18-000036:mdna:58]
Financing Activities

[0000080420-18-000036:mdna:59]
Net cash used in financing activities was $13.0 million in Fiscal 2018, $12.7 million in Fiscal 2017 and $17.4 million in Fiscal 2016 and included approximately $12 million of dividends paid in each of the three years.

[0000080420-18-000036:mdna:60]
Contractual and Other Obligations

[0000080420-18-000036:mdna:61]
At September 30, 2018, our long-term contractual obligations were limited to debt and leases. The table below details our commitments by type of obligation, including interest if applicable, and the period that the payment will become due (in thousands).

[0000080420-18-000036:mdna:62]
| Payments Due by Period: |  |  |  |  |  |
|  | Long-Term Debt Obligations |  | Net Operating Lease Obligations |  | Total |
| Less than 1 year | $ | 421 |  |  | $ | 1,743 |  |  | $ | 2,164 |  |
| 1 to 3 years | 1,221 |  |  | 4,097 |  |  | 5,318 |  |
| 3 to 5 years | — |  |  | 3,173 |  |  | 3,173 |  |
| More than 5 years | — |  |  | — |  |  | — |  |
| Total long-term contractual obligations | $ | 1,642 |  |  | $ | 9,013 |  |  | $ | 10,655 |  |

[0000080420-18-000036:mdna:63]
As of September 30, 2018, the total unrecognized tax benefit related to uncertain tax positions was $1.9 million. We estimate that none of this will be paid within the next 12 months. However, we believe that it is reasonably possible that within the next 12

[0000080420-18-000036:mdna:64]
months, the total unrecognized tax benefits will decrease by approximately 22% due to the expiration of certain statutes of limitations and voluntary filings. We are unable to make reasonably reliable estimates regarding the timing of future cash outflows, if any, associated with the remaining unrecognized tax benefits.

[0000080420-18-000036:mdna:65]
Other Commercial Commitments

[0000080420-18-000036:mdna:66]
We are contingently liable for letters of credit and bank guarantees totaling $26.4 million as of September 30, 2018.

[0000080420-18-000036:mdna:67]
The following table reflects potential cash outflows that may result in the event that we are unable to perform under our contracts (in thousands):

[0000080420-18-000036:mdna:68]
| Payments Due by Period: | Letters ofCredit/Bank Guarantees |
| Less than 1 year | $ | 17,721 |  |
| 1 to 3 years | 5,285 |  |
| More than 3 years | 3,403 |  |
| Total long-term commercial obligations | $ | 26,409 |  |

[0000080420-18-000036:mdna:69]
We also had performance and maintenance bonds totaling $160.6 million that were outstanding at September 30, 2018. Performance and maintenance bonds are primarily used to guarantee our contract performance to our customers.

[0000080420-18-000036:mdna:70]
Off-Balance Sheet Arrangements

[0000080420-18-000036:mdna:71]
We had no off-balance sheet arrangements during the periods presented.

[0000080420-18-000036:mdna:72]
Effects of Inflation

[0000080420-18-000036:mdna:73]
We are subject to inflation, which can cause increases in our costs of raw materials, primarily copper, aluminum and steel. Fixed-price contracts can limit our ability to pass these increases to our customers, thus negatively impacting our earnings. The inflation in commodity prices could potentially impact our operations in future years.

[0000080420-18-000036:mdna:74]
Critical Accounting Policies and Estimates

[0000080420-18-000036:mdna:75]
The preparation of consolidated financial statements in conformity with accounting principles generally accepted in the United States of America requires management to make estimates and assumptions that affect the reported amounts of assets, liabilities, revenues and expenses and the disclosures of contingent assets and liabilities. We base our estimates on historical experience and on various other assumptions that are believed to be reasonable under the circumstances. Actual results may differ from these estimates. We believe the following accounting policies and estimates to be critical in the preparation and reporting of our consolidated financial statements.

[0000080420-18-000036:mdna:76]
For the year ended September 30, 2018, our operating loss was reduced by $3.9 million as a result of changes in contract estimates related to projects in progress at the beginning of the year. These changes in estimates resulted primarily from, among other things, successful execution and close-out improvements, as well as other changes in facts and circumstances during these periods.

[0000080420-18-000036:mdna:77]
Revenue Recognition

[0000080420-18-000036:mdna:78]
Our revenues are primarily generated from the engineering and manufacturing of custom products under long-term contracts that may last from one month to several years, depending on the contract. Revenues from long-term contracts are recognized on the percentage-of-completion method of accounting.

[0000080420-18-000036:mdna:79]
Under the percentage-of-completion method of accounting, revenues are recognized as work is performed. The revenue earned to date is calculated by multiplying the total contract price by the percentage of performance to date, which is based on total costs or total labor dollars incurred to date compared to the total estimated costs or total labor dollars estimated at completion. The method used to determine the percentage of completion is typically the cost method, unless the labor method is a more accurate method of measuring the progress of the project. Application of the percentage-of-completion method of accounting requires the use of estimates of costs to be incurred for the performance of the contract. Contract costs include all direct material costs, direct labor costs and those indirect costs related to contract performance, such as indirect labor, supplies, tools, repairs and all costs

[0000080420-18-000036:mdna:80]
associated with operation of equipment. The cost estimation process is based upon the professional knowledge and experience of our engineers, project managers and financial professionals. Factors that are considered in estimating the work to be completed and ultimate contract recovery include the availability and productivity of labor, the nature and complexity of the work to be performed, the effect of change orders, the availability of materials, the effect of any delays on our project performance and the recoverability of any claims. Changes in job performance, job conditions, estimated profitability and final contract settlements, including our estimate of liquidated damages, if any, may result in revisions to costs and income, with their effects being recognized in the period in which the revisions are determined. Whenever revisions of estimated contract costs and contract values indicate that the contract costs will exceed estimated revenues, thus creating a loss, a provision for the total estimated loss is recorded in that period.

[0000080420-18-000036:mdna:81]
Revenues associated with maintenance, repair and service contracts are recognized when the services are performed. Expenses related to these types of services are recognized as incurred.

[0000080420-18-000036:mdna:82]
Costs and estimated earnings in excess of billings on uncompleted contracts also include certain costs associated with unapproved change orders. These costs are included when change order approval is probable. Amounts are carried at the lower of cost or net realizable value. Revenue is recognized to the extent of costs incurred when recovery is probable. The amounts recorded involve the use of judgments and estimates; thus, actual recoverable amounts could differ from original assumptions.

[0000080420-18-000036:mdna:83]
As discussed in Note B of the Notes to Consolidated Financial Statements, effective for the quarter ending December 31, 2018, we will adopt the new revenue recognition standard using the modified retrospective transition method. The new standard will be applied to contracts with customers that were not substantially complete as of October 1, 2018. Our financial results for reporting periods after October 1, 2018 will be presented under the new standard; however, our financial results for prior periods will not be retrospectively adjusted. We have substantially completed our evaluation of the impact of the new standard on our contracts with customers, including identification of differences that will result from the new requirements. Based on this evaluation, we estimate that the net cumulative adjustment to retained earnings from adoption will not be material to our consolidated financial statements. Our disclosures related to revenue recognition will expand to address new quantitative and qualitative requirements regarding the nature, amount and timing of revenue from contracts with customers and additional information related to contract assets and liabilities.

[0000080420-18-000036:mdna:84]
Allowance for Doubtful Accounts

[0000080420-18-000036:mdna:85]
We maintain and continually assess the adequacy of an allowance for doubtful accounts representing our estimate for losses resulting from the inability of our customers to pay amounts due to us. This estimated allowance is based on historical experience of uncollected accounts, the level of past due accounts, the overall level of outstanding accounts receivable, information about specific customers with respect to their inability to make payments and expectations of future conditions that could impact the collectability of accounts receivable. However, future changes in our customers’ operating performance and cash flows, or in general economic conditions, could have an impact on their ability to fully pay these amounts, which, among other things, could have a material adverse impact on our operating results.

[0000080420-18-000036:mdna:86]
Impairment of Long-Lived Assets

[0000080420-18-000036:mdna:87]
We review long-lived assets for impairment whenever events or changes in circumstances indicate that the carrying value may not be realizable. If an evaluation is required, the estimated future undiscounted cash flows associated with the asset are compared to the asset’s carrying amount to determine if recording an impairment of such asset is necessary. This requires us to make long-term forecasts of the future revenues and costs related to the assets subject to review. Forecasts require assumptions about demand for our products and future market conditions. Estimating future cash flows requires significant judgment, and our projections may vary from cash flows eventually realized. Future events and unanticipated changes to assumptions could require a provision for impairment in a future period. The effect of any impairment would be reflected in income (loss) from operations in the Consolidated Statements of Operations. In addition, we estimate the useful lives of our long-lived assets and other intangibles and periodically review these estimates to determine whether these lives are appropriate.

[0000080420-18-000036:mdna:88]
Accruals for Contingent Liabilities

[0000080420-18-000036:mdna:89]
From time to time, contingencies such as insurance-related claims, liquidated damages and legal claims arise in the normal course of business. Pursuant to applicable accounting standards, we must evaluate such contingencies to subjectively determine the likelihood that an asset has been impaired or a liability has been incurred at the date of the financial statements, as well as evaluate whether the amount of the loss can be reasonably estimated. If the likelihood is determined to be probable and it can be reasonably estimated, the estimated loss is recorded. The amounts we record for contingent liabilities require judgments regarding the amount of expenses that will ultimately be incurred. We use past experience and history, as well as the specific circumstances surrounding

[0000080420-18-000036:mdna:90]
each contingent liability, including estimated legal costs, in evaluating the amount of liability that should be recorded. Actual results could differ from our estimates.

[0000080420-18-000036:mdna:91]
Warranty Costs

[0000080420-18-000036:mdna:92]
We provide for estimated warranty costs with the recognition of revenue based upon historical rates applicable to individual product lines. In addition, specific provisions are made when the costs of such warranties are expected to exceed accruals. Our standard terms and conditions of sale include a warranty for parts and service for the earlier of 18 months from the date of shipment or 12 months from the date of energization, whichever occurs first. Occasionally projects require warranty terms that are longer than our standard terms due to the nature of the project. Extended warranty terms may be negotiated and included in our contracts. We use past experience and historical claims to determine the estimated liability. Actual results could differ from our estimate.

[0000080420-18-000036:mdna:93]
Accounting for Income Taxes

[0000080420-18-000036:mdna:94]
We account for income taxes under the asset and liability method, based on the income tax laws and rates in the countries in which operations are conducted and income is earned. This approach requires the recognition of deferred tax assets and liabilities for the expected future tax consequences of temporary differences between the carrying amounts and the tax basis of assets and liabilities. Developing our provision for income taxes requires significant judgment and expertise in federal, international and state income tax laws, regulations and strategies, including the determination of deferred tax assets and liabilities and, if necessary, any valuation allowances that may be required for deferred tax assets. In assessing the extent to which net deferred tax assets may be realized, we consider whether it is more likely than not that some portion or all of the net deferred tax assets may not be realized. The ultimate realization of net deferred tax assets is dependent on the generation of future taxable income during the periods in which those temporary differences become deductible. Due to the historical Canadian losses, and the losses that we projected at the time of determination, we were required under the more likely than not accounting standard to record a valuation allowance against the Canadian net deferred tax assets because we anticipated that we may not be able to realize the benefits of the net operating loss carryforwards and other deductible differences. Estimates may change as new events occur, estimates of future taxable income during the carryforward period are reduced or increased, additional information becomes available or operating environments change, which may result in a full or partial reversal of the valuation allowance. We will continue to assess the adequacy of the valuation allowance on a quarterly basis. Our judgments and tax strategies are subject to audit by various taxing authorities.

[0000080420-18-000036:mdna:95]
The objectives of accounting for income taxes are to recognize the amount of taxes payable or refundable for the current year and deferred tax liabilities and assets for the future tax consequences of events that have been recognized in an entity’s financial statements or tax returns. We recognize the tax benefit from an uncertain tax position only if it is more likely than not that the tax position will be sustained on examination by the taxing authorities, based on the technical merits of the position. The tax benefits recognized in the financial statements from such a position should be measured based on the largest benefit that has a greater than 50% likelihood of being realized upon ultimate settlement. Accounting literature also provides guidance on derecognition of income tax assets and liabilities, classification of current and deferred income tax assets and liabilities, accounting for interest and penalties associated with tax positions, and income tax disclosures. Judgment is required in assessing the future tax consequences of events that have been recognized in our financial statements or tax returns. Variations in the actual outcome of these future tax consequences could materially impact our financial statements.

[0000080420-18-000036:mdna:96]
See Note H of Notes to Consolidated Financial Statements for disclosures related to the valuation allowance recorded in relation to foreign deferred taxes.

[0000080420-18-000036:mdna:97]
Foreign Currency Translation

[0000080420-18-000036:mdna:98]
The functional currency for our foreign operating subsidiaries is the local currency in which the entity is located. The financial statements of all subsidiaries with a functional currency other than the U.S. Dollar have been translated into U.S. Dollars. All assets and liabilities of foreign operations are translated into U.S. Dollars using year-end exchange rates, and all revenues and expenses are translated at average rates during the respective period. The U.S. Dollar results that arise from such translation, as well as exchange gains and losses on intercompany balances of a long-term investment nature, are included in the cumulative currency translation adjustments in accumulated other comprehensive income in stockholders’ equity.
