# POWL 8-K — 0000080420-18-000031 filed 2018-12-12

## item codes, every 8-K on or before 2018-12-12

- 2018-12-12 0000080420-18-000031 — 2.02
- 2018-11-05 0000080420-18-000029 — 8.01, 9.01
- 2018-11-01 0000080420-18-000027 — 5.02, 8.01, 9.01
- 2018-10-01 0000080420-18-000024 — 5.02
- 2018-08-07 0000080420-18-000020 — 2.02, 8.01
- 2018-05-15 0000080420-18-000016 — 5.02, 8.01
- 2018-05-09 0000080420-18-000011 — 2.02, 8.01
- 2018-02-22 0000080420-18-000009 — 5.07
- 2018-02-06 0000080420-18-000003 — 2.02, 8.01
- 2017-12-27 0001193125-17-379928 — 5.02
- 2017-12-05 0000080420-17-000028 — 2.02, 9.01
- 2017-11-08 0000080420-17-000024 — 8.01, 9.01
- 2017-11-03 0000080420-17-000022 — 5.02
- 2017-08-09 0000080420-17-000017 — 2.02, 8.01
- 2017-06-30 0000080420-17-000014 — 1.01, 9.01
- 2017-05-03 0000080420-17-000006 — 2.02, 8.01, 9.01
- 2017-02-23 0000080420-17-000004 — 5.07
- 2017-02-08 0001628280-17-000965 — 2.02 — amendment of 0001628280-17-000949
- 2017-02-07 0001628280-17-000949 — 2.01, 8.01, 9.01
- 2016-12-07 0001193125-16-787354 — 2.02, 9.01
- 2016-11-01 0001193125-16-755475 — 8.01, 9.01
- 2016-09-30 0001193125-16-726999 — 5.02, 8.01, 9.01
- 2016-08-03 0001193125-16-669308 — 2.02, 8.01, 9.01
- 2016-05-04 0001193125-16-576528 — 2.02, 8.01, 9.01
- 2016-02-25 0001193125-16-477896 — 5.07
- 2016-02-03 0001193125-16-449052 — 2.02, 8.01, 9.01
- 2015-12-31 0001193125-15-418363 — 5.02, 7.01, 9.01
- 2015-12-02 0001193125-15-393109 — 2.02, 9.01
- 2015-11-05 0001193125-15-368085 — 8.01, 9.01
- 2015-09-25 0001193125-15-329031 — 5.02
- 2015-08-05 0001193125-15-277912 — 2.02, 8.01, 9.01
- 2015-05-06 0001193125-15-174291 — 2.02, 8.01, 9.01
- 2015-03-06 0001193125-15-081070 — 5.02
- 2015-03-02 0001193125-15-072946 — 5.07
- 2015-02-03 0001193125-15-031772 — 2.02, 8.01, 9.01
- 2014-12-18 0001193125-14-446513 — 8.01, 9.01
- 2014-12-03 0001193125-14-431745 — 2.02, 9.01
- 2014-11-05 0001193125-14-397955 — 8.01, 9.01
- 2014-09-26 0001193125-14-353741 — 7.01, 9.01
- 2014-08-05 0001193125-14-296001 — 2.02, 8.01, 9.01
- 2014-05-07 0001193125-14-187496 — 2.02, 8.01, 9.01
- 2014-03-03 0001193125-14-079843 — 5.02, 5.07
- 2014-02-05 0001193125-14-036633 — 2.02, 8.01, 9.01
- 2014-01-17 0001193125-14-014351 — 1.01, 8.01, 9.01
- 2014-01-06 0001193125-14-002795 — 1.01, 2.03
- 2013-12-06 0001564590-13-001411 — 2.02, 9.01
- 2013-12-05 0001564590-13-001406 — 5.02, 8.01, 9.01
- 2013-11-07 0001193125-13-432950 — 8.01, 9.01
- 2013-08-07 0001193125-13-324337 — 2.02, 9.01
- 2013-05-08 0001193125-13-206800 — 2.02, 9.01
- 2013-02-22 0001193125-13-070971 — 5.02, 5.07
- 2013-02-06 0001193125-13-040556 — 2.02, 9.01
- 2012-12-18 0001193125-12-506417 — 5.02, 9.01
- 2012-12-05 0001193125-12-491749 — 2.02, 9.01
- 2012-10-12 0001193125-12-421889 — 3.03, 5.02, 5.03, 9.01
- 2012-08-09 0001193125-12-344617 — 5.02, 8.01, 9.01
- 2012-08-08 0001193125-12-343630 — 2.02, 9.01
- 2012-05-09 0001193125-12-221356 — 2.02, 9.01
- 2012-02-08 0001193125-12-046560 — 2.02, 9.01
- 2011-12-08 0001193125-11-334810 — 2.02, 9.01
- 2011-11-08 0000950123-11-096524 — 2.02, 2.06, 4.02, 9.01
- 2011-10-14 0000950123-11-090124 — 5.02
- 2011-10-06 0000950123-11-088969 — 5.02
- 2011-09-19 0000950123-11-085224 — 5.02, 9.01
- 2011-09-15 0000950123-11-084806 — 5.02, 9.01
- 2011-08-04 0000950123-11-072788 — 2.02, 9.01
- 2011-07-22 0000950123-11-067402 — 5.07
- 2011-05-24 0000950123-11-053550 — 1.01, 2.03, 9.01
- 2011-05-04 0000950123-11-044561 — 2.02, 9.01
- 2011-02-02 0000950123-11-008188 — 2.02, 9.01
- 2010-12-08 0000950123-10-111987 — 2.02, 9.01
- 2010-08-05 0000950123-10-073114 — 2.02, 9.01
- 2010-05-18 0000950123-10-050900 — 5.02
- 2010-05-05 0000950123-10-044499 — 2.02, 9.01
- 2010-02-03 0000950123-10-008278 — 2.02, 9.01
- 2009-12-21 0000950123-09-072269 — 1.01, 2.01, 2.03, 8.01, 9.01
- 2009-12-09 0000950123-09-069525 — 2.02, 9.01
- 2009-10-27 0000950123-09-053501 — 1.01, 8.01, 9.01
- 2009-08-04 0000950123-09-029476 — 2.02, 9.01
- 2009-05-06 0000950129-09-001498 — 2.02, 9.01
- 2009-03-05 0000950129-09-000749 — 1.01, 9.01
- 2009-02-10 0000950129-09-000349 — 2.02, 9.01
- 2008-12-10 0000950134-08-021934 — 2.02, 9.01
- 2008-08-06 0000950129-08-004267 — 2.02, 9.01
- 2008-07-24 0000950129-08-004063 — 1.01, 5.02, 8.01, 9.01
- 2008-06-16 0000950129-08-003500 — 9.01 — amendment of 0000950134-06-015374
- 2008-06-05 0000950129-08-003378 — 5.02, 9.01
- 2008-05-08 0000950129-08-002843 — 2.02, 9.01
- 2008-02-06 0000950129-08-000533 — 2.02, 9.01
- 2007-12-19 0000950129-07-006277 — 1.01, 2.03, 9.01
- 2007-12-06 0000950129-07-006003 — 2.02, 9.01
- 2007-08-21 0000950129-07-004181 — 2.02, 9.01
- 2007-05-31 0000950129-07-002810 — 2.02, 9.01
- 2007-05-21 0000950129-07-002668 — 2.02, 3.01, 4.02, 9.01
- 2007-04-16 0000950129-07-002002 — 2.02, 4.02, 9.01
- 2007-03-01 0000950129-07-001104 — 5.02, 8.01, 9.01
- 2007-02-08 0000950129-07-000451 — 2.02, 9.01
- 2006-12-08 0000950129-06-010041 — 2.02, 9.01
- 2006-09-08 0000950129-06-008379 — 2.02, 9.01
- 2006-08-09 0000950134-06-015374 — 1.01, 2.01, 8.01, 9.01
- 2006-06-08 0000950129-06-006127 — 2.02, 9.01
- 2006-03-09 0000950129-06-002455 — 2.02, 9.01
- 2005-12-16 0000950129-05-012031 — 2.02, 5.03, 9.01
- 2005-09-13 0000950129-05-009181 — 2.01, 9.01 — amendment of 0000950129-05-006889
- 2005-09-12 0000950129-05-009151 — 2.02, 9.01
- 2005-07-06 0000950129-05-006889 — 1.01, 1.02, 2.01, 2.03, 9.01
- 2005-06-10 0000950129-05-006128 — 2.02, 9.01
- 2005-04-20 0000080420-05-000031 — 5.02
- 2005-03-11 0000080420-05-000024 — 9.01
- 2005-02-25 0000080420-05-000018 — 7.01, 9.01
- 2005-01-21 0000080420-05-000009 — 7.01, 9.01
- 2004-12-17 0000080420-04-000049 — 2.02, 9.01
- 2004-11-01 0000080420-04-000045 — 8.01, 9.01
- 2004-10-08 0001169232-04-005133 — 2.05
- 2004-09-14 0000080420-04-000037 — 5.02
- 2004-09-02 0000080420-04-000030 — 2.02, 9.01
- 2004-06-08 0000080420-04-000021 — 7
- 2004-05-13 0000080420-04-000019 — 4
- 2004-02-27 0000080420-04-000013 — 7
- 2003-12-16 0000950129-03-006136 — 12, 7
- 2003-08-29 0000950129-03-004531 — 12, 7
- 2003-06-03 0000950129-03-003035 — 7, 9
- 2003-05-15 0000950129-03-002812 — 7, 9
- 2002-05-29 0000950129-02-002795 — 4
- 2000-12-21 0000950129-00-006093 — 5, 7
- 1998-09-04 0000950129-98-003802 — 5
- 1996-08-09 0000950129-96-001705 — 2, 7

## late-filing notifications on or before 2018-12-12

- 2007-05-11 0000950129-07-002494 — NT 10-Q, for the period ended 2007-03-31
- 2005-01-18 0000080420-05-000004 — NT 10-K, for the period ended 2004-10-31

## item 2.02 — earnings release, exhibit 99.1

[0000080420-18-000031:8k_2_02:1]
EX-99.1
2
ex991-q418earningsrelease.htm
EXHIBIT 99.1

[0000080420-18-000031:8k_2_02:2]
Exhibit

[0000080420-18-000031:8k_2_02:3]
Exhibit 99.1

[0000080420-18-000031:8k_2_02:4]
PRESS RELEASE

[0000080420-18-000031:8k_2_02:5]
Contacts:    Don R. Madison, CFO

[0000080420-18-000031:8k_2_02:6]
Powell Industries, Inc.

[0000080420-18-000031:8k_2_02:7]
713-947-4422

[0000080420-18-000031:8k_2_02:8]
POWELL INDUSTRIES ANNOUNCES

[0000080420-18-000031:8k_2_02:9]
FISCAL 2018 FOURTH QUARTER RESULTS

[0000080420-18-000031:8k_2_02:10]
HOUSTON — DECEMBER 11, 2018 — Powell Industries, Inc. (NASDAQ: POWL), a leading supplier of custom engineered solutions for the management, control and distribution of electrical energy, today announced results for the fiscal 2018 fourth quarter and year ended September 30, 2018.

[0000080420-18-000031:8k_2_02:11]
Revenues for the fourth quarter of fiscal 2018 were $134.9 million compared to revenues of $95.0 million for the fourth quarter of fiscal 2017.  The Company reported net income for the fourth quarter of $1.5 million, or $0.13 per diluted share, compared to a net loss of $5.1 million, or $0.45 per diluted share, for the fourth quarter of fiscal 2017.

[0000080420-18-000031:8k_2_02:12]
Brett A. Cope, Powell’s President and Chief Executive Officer, stated, "Our fourth quarter 2018 results reflect our efforts to improve operational efficiencies, with top-line growth driven in large part by our U.S. operations.  While both project size and margins realized during the quarter remain consistent with the first half of this fiscal year, new orders in the fourth quarter dropped below our recent run-rate, partially driven by timing as several orders slipped into the first quarter of fiscal 2019.  Despite this challenge, activity

[0000080420-18-000031:8k_2_02:13]
in our core markets remained strong during the quarter, with brownfield opportunities maintaining a steady pace as the need for smaller, short-cycle work continues."

[0000080420-18-000031:8k_2_02:14]
New orders placed during the fourth quarter of fiscal 2018 totaled $78 million compared to $139 million in the third quarter of fiscal 2018 and compared to $112 million in the fourth quarter of fiscal 2017.  The Company’s backlog as of September 30, 2018 was $261 million compared to $316 million as of June 30, 2018 and compared to $250 million at the end of last year’s fourth quarter.

[0000080420-18-000031:8k_2_02:15]
FISCAL 2018 RESULTS

[0000080420-18-000031:8k_2_02:16]
Revenues for fiscal 2018 were $448.7 million compared to revenues of $395.9 million for fiscal 2017.  Net loss for fiscal 2018 was $7.2 million, or $0.62 per diluted share, compared to a net loss of $9.5 million, or $0.83 per diluted share, in fiscal 2017.

[0000080420-18-000031:8k_2_02:17]
OUTLOOK

[0000080420-18-000031:8k_2_02:18]
Commenting on the company's outlook, Don R. Madison, Powell’s Chief Financial and Administrative Officer said, "As we enter fiscal 2019, we continue to see improvement in terms of project pricing, quality and order volume for both greenfield and brownfield opportunities when compared to one year ago.  We believe that current customer activity will continue to gradually increase with improved margins for fiscal 2019 compared to fiscal 2018.  As a result, we expect fiscal 2019 backlog to improve over 2018, revenues to increase modestly, and earnings to improve to breakeven or slightly better in fiscal 2019."

[0000080420-18-000031:8k_2_02:19]
CONFERENCE CALL

[0000080420-18-000031:8k_2_02:20]
Powell Industries has scheduled a conference call for Wednesday, December 12, 2018 at 11:00 a.m. Eastern time.  To participate in the conference call, dial 412-902-0030 at least 10 minutes before the call begins and ask for the Powell Industries conference call.  A replay of the call will be available approximately two hours after the live broadcast ends and will be accessible until December 19, 2018.  To access the replay, dial 201-612-7415 using a passcode of 13685470#.

[0000080420-18-000031:8k_2_02:21]
Investors, analysts and the general public will also have the opportunity to listen to the conference call over the Internet by visiting powellind.com. To listen to the live call on the web, please visit the website at least fifteen minutes before the call begins to register, download and install any necessary audio software.  For those who cannot listen to the live webcast, an archive will be available shortly after the call and will remain available for approximately 90 days at powellind.com.

[0000080420-18-000031:8k_2_02:22]
Powell Industries, Inc., headquartered in Houston, designs, manufactures and services custom-engineered equipment and systems for the distribution, control and monitoring of electrical energy.  Powell markets include large industrial customers such as utilities, oil and gas producers, refineries, petrochemical plants, pulp and paper producers, mining operations and commuter railways.   For more information, please visit powellind.com.

[0000080420-18-000031:8k_2_02:23]
This press release contains references to certain non-GAAP financial measures discussed above.  Please see the financial table below for more details on these non-GAAP financial measures, including a reconciliation of these non-GAAP financial measures to net income and the reasons management believes these measures are useful to investors.

[0000080420-18-000031:8k_2_02:24]
3

[0000080420-18-000031:8k_2_02:25]
POWELL INDUSTRIES, INC. & SUBSIDIARIES

[0000080420-18-000031:8k_2_02:26]
CONSOLIDATED STATEMENT OF OPERATIONS

[0000080420-18-000031:8k_2_02:27]
|  | Three months ended September 30, |  | Year ended September 30, |
|  | 2018 |  | 2017 |  | 2018 |  | 2017 |
| (In thousands, except per share data) | (Unaudited) |  |  |  |  |
| Revenues | $ | 134,897 |  |  | $ | 94,963 |  |  | $ | 448,716 |  |  | $ | 395,911 |  |
| Cost of goods sold | 110,892 |  |  | 84,069 |  |  | 383,361 |  |  | 345,142 |  |
| Gross profit | 24,005 |  |  | 10,894 |  |  | 65,355 |  |  | 50,769 |  |
| Selling, general and administrative expenses | 18,306 |  |  | 15,071 |  |  | 66,768 |  |  | 61,524 |  |
| Research and development expenses | 1,791 |  |  | 2,088 |  |  | 6,717 |  |  | 6,906 |  |
| Amortization of intangible assets | 44 |  |  | 92 |  |  | 205 |  |  | 355 |  |
| Restructuring and separation expenses | 787 |  |  | 482 |  |  | 787 |  |  | 1,322 |  |
| Operating income (loss) | 3,077 |  |  | (6,839 | ) |  | (9,122 | ) |  | (19,338 | ) |
| Other income | (240 | ) |  | (508 | ) |  | (747 | ) |  | (2,029 | ) |
| Interest expense | 54 |  |  | 46 |  |  | 207 |  |  | 168 |  |
| Interest income | (172 | ) |  | (271 | ) |  | (883 | ) |  | (558 | ) |
| Income (loss) before income taxes | 3,435 |  |  | (6,106 | ) |  | (7,699 | ) |  | (16,919 | ) |
| Income tax provision (benefit) | 1,896 |  |  | (964 | ) |  | (547 | ) |  | (7,433 | ) |
| Net income (loss) | $ | 1,539 |  |  | $ | (5,142 | ) |  | $ | (7,152 | ) |  | $ | (9,486 | ) |
| Earnings (loss) per share: |  |  |  |  |  |  |  |
| Basic | $ | 0.13 |  |  | $ | (0.45 | ) |  | $ | (0.62 | ) |  | $ | (0.83 | ) |
| Diluted | $ | 0.13 |  |  | $ | (0.45 | ) |  | $ | (0.62 | ) |  | $ | (0.83 | ) |
| Weighted average shares: |  |  |  |  |  |  |  |
| Basic | 11,518 |  |  | 11,468 |  |  | 11,507 |  |  | 11,453 |  |
| Diluted | 11,613 |  |  | 11,468 |  |  | 11,507 |  |  | 11,453 |  |
| SELECTED FINANCIAL DATA: |  |  |  |  |  |  |  |
| Depreciation and Amortization | $ | 3,248 |  |  | $ | 3,274 |  |  | $ | 12,903 |  |  | $ | 12,755 |  |
| Capital Expenditures | $ | 524 |  |  | $ | 1,116 |  |  | $ | 4,502 |  |  | $ | 3,636 |  |
| Dividends Paid | $ | 2,982 |  |  | $ | 2,970 |  |  | $ | 11,916 |  |  | $ | 11,875 |  |

[0000080420-18-000031:8k_2_02:28]
POWELL INDUSTRIES, INC. & SUBSIDIARIES

[0000080420-18-000031:8k_2_02:29]
CONSOLIDATED BALANCE SHEETS

[0000080420-18-000031:8k_2_02:30]
|  | September 30, |
|  | 2018 |  | 2017 |
| (In thousands) |  |  |  |
| Assets: |  |  |  |
| Cash, cash equivalents and short-term investments | $ | 49,754 |  |  | $ | 95,188 |  |
| Restricted cash | 19,154 |  |  | 15,104 |  |
| Other current assets | 207,754 |  |  | 139,779 |  |
| Property, plant and equipment (net) | 128,764 |  |  | 139,420 |  |
| Restricted cash (non-current) | 5,987 |  |  | 9,747 |  |
| Long-term assets | 18,538 |  |  | 15,748 |  |
| Total assets | $ | 429,951 |  |  | $ | 414,986 |  |
| Liabilities and equity: |  |  |  |
| Current liabilities | $ | 117,849 |  |  | $ | 85,579 |  |
| Long-term debt, net of current maturities | 1,200 |  |  | 1,600 |  |
| Deferred and other long-term liabilities | 9,258 |  |  | 6,511 |  |
| Stockholders' equity | 301,644 |  |  | 321,296 |  |
| Total liabilities and stockholders’ equity | $ | 429,951 |  |  | $ | 414,986 |  |
| SELECTED FINANCIAL DATA: |  |  |  |
| Working capital | $ | 158,813 |  |  | $ | 164,492 |  |

[0000080420-18-000031:8k_2_02:31]
5
