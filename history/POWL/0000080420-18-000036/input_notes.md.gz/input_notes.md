# POWL notes — 0000080420-18-000036


## powl:CostsAndEstimatedEarningsInExcessOfBillingsOnUncompletedContractsPolicyPolicyTextBlock

[0000080420-18-000036:notes:1]
Costs and Estimated Earnings in Excess of Billings on Uncompleted Contracts

[0000080420-18-000036:notes:2]
Costs and estimated earnings in excess of billings on uncompleted contracts arise when revenues are recorded on a percentage-of-completion basis but cannot be invoiced under the terms of the contract. Such amounts are invoiced upon completion of contractual milestones.

[0000080420-18-000036:notes:3]
Costs and estimated earnings in excess of billings on uncompleted contracts also include certain costs associated with unapproved change orders. These costs are included when the approval of the change order is probable. Amounts are carried at the lower of cost or net realizable value. Revenue is recognized to the extent of costs incurred when recovery is probable. The amounts recorded involve the use of judgments and estimates; thus, actual recoverable amounts could differ from original assumptions.

[0000080420-18-000036:notes:4]
In accordance with industry practice, assets and liabilities related to costs and estimated earnings in excess of billings on uncompleted contracts, as well as billings in excess of costs and estimated earnings on uncompleted contracts, have been classified as current. The contract cycle for certain long-term contracts may extend beyond one year; thus, collection of amounts related to these contracts may extend beyond one year.


## powl:ScheduleofLeaseExpenseandSubleaseIncomeTableTextBlock

[0000080420-18-000036:notes:5]
Lease expense and sublease income from third parties was as follows (in thousands):

[0000080420-18-000036:notes:6]
|  | Year Ended September 30, |
|  | 2018 |  | 2017 |  | 2016 |
| Rental expense | $ | 3,432 |  |  | $ | 3,734 |  |  | $ | 4,469 |  |
| Sublease income from third parties | (1,487 | ) |  | (1,389 | ) |  | (986 | ) |


## us-gaap:AllowanceForCreditLossesOnFinancingReceivablesTableTextBlock

[0000080420-18-000036:notes:7]
Activity in our allowance for doubtful accounts consisted of the following (in thousands):

[0000080420-18-000036:notes:8]
|  | September 30, |
|  | 2018 |  | 2017 |
| Balance at beginning of period | $ | 179 |  |  | $ | 811 |  |
| Bad debt expense (recovery) | 111 |  |  | (160 | ) |
| Uncollectible accounts written off, net of recoveries | (125 | ) |  | (472 | ) |
| Change due to foreign currency translation | (8 | ) |  | — |  |
| Balance at end of period | $ | 157 |  |  | $ | 179 |  |


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0000080420-18-000036:notes:9]
Commitments and Contingencies

[0000080420-18-000036:notes:10]
Long-Term Debt

[0000080420-18-000036:notes:11]
See Note F herein for a discussion of our long-term debt.

[0000080420-18-000036:notes:12]
Leases

[0000080420-18-000036:notes:13]
We lease certain offices, facilities and equipment under operating leases expiring at various dates through 2023. We also sublease certain facilities that we are no longer occupying. Our sublease terms do not fully cover the existing rental commitments on certain facilities.

[0000080420-18-000036:notes:14]
At September 30, 2018, the future minimum annual rental commitments and expected receipts under non-cancelable operating leases having terms in excess of one year were as follows (in thousands):

[0000080420-18-000036:notes:15]
| Years Ended September 30, | Operating Leases Payments |  | Operating Sublease Income |
| 2019 | $ | 3,002 |  |  | $ | (1,259 | ) |
| 2020 | 2,135 |  |  | (38 | ) |
| 2021 | 2,000 |  |  | — |  |
| 2022 | 1,875 |  |  | — |  |
| 2023 | 1,298 |  |  | — |  |
| Thereafter | — |  |  | — |  |
| Total lease commitments | $ | 10,310 |  |  | $ | (1,297 | ) |

[0000080420-18-000036:notes:16]
In Fiscal 2018, we incurred approximately $0.8 million due to anticipated losses on the sublet of a Canadian facility we exited in a prior period. In Fiscal 2016, we incurred approximately $0.5 million of restructuring costs related to a Canadian facility that we leased and exited in the third quarter of Fiscal 2016.

[0000080420-18-000036:notes:17]
Letters of Credit, Bank Guarantees and Bonds

[0000080420-18-000036:notes:18]
Certain customers require us to post letters of credit, bank guarantees or surety bonds. These security instruments assure that we will perform under the terms of our contract. In the event of default, the counterparty may demand payment from the bank under a letter of credit or bank guarantee, or performance by the surety under a bond. To date, there have been no significant expenses related to security instruments for the periods reported. We were contingently liable for letters of credit and bank guarantees of $26.4 million as of September 30, 2018. We also had outstanding surety bonds totaling $160.6 million, with additional bonding capacity of $589.4 million available, at September 30, 2018.

[0000080420-18-000036:notes:19]
We have a $6.5 million facility agreement (Facility Agreement) between Powell (UK) Limited and a large international bank. This Facility Agreement provides Powell (UK) Limited the ability to enter into bank guarantees as well as forward exchange contracts and currency options. At September 30, 2018, we had outstanding guarantees totaling $3.3 million under this Facility Agreement and amounts available under this Facility Agreement were $3.2 million. The Facility Agreement expires in May 2019 and provides for financial covenants and customary events of default, and carries cross-default provisions with our U.S. Revolver. If an event of default (as defined in the Facility Agreement) occurs and is continuing, per the terms and subject to the conditions set forth therein, obligations outstanding under the Facility Agreement may be accelerated and may become or be declared immediately due and payable. As of September 30, 2018, we were in compliance with all of the financial covenants of the Facility Agreement.

[0000080420-18-000036:notes:20]
Litigation

[0000080420-18-000036:notes:21]
We are involved in various legal proceedings, claims and other disputes arising from our commercial operations, projects, employees and other matters which, in general, are subject to uncertainties and in which the outcomes are not predictable. Although we can give no assurances about the resolution of pending claims, litigation or other disputes and the effect such outcomes may have on us, management believes that any ultimate liability resulting from the outcome of such proceedings, to the extent not otherwise provided or covered by insurance, will not have a material adverse effect on our consolidated financial position or results of operations or liquidity.

[0000080420-18-000036:notes:22]
Liquidated Damages

[0000080420-18-000036:notes:23]
Certain of our customer contracts have schedule and performance obligation clauses that, if we fail to meet them, could require us to pay liquidated damages. Each individual contract defines the conditions under which the customer may make a claim against us. As of September 30, 2018, our exposure to possible liquidated damages was $2.4 million, of which approximately $0.7 million was probable. Based on our actual or projected failure to meet these various contractual commitments, $0.7 million has been recorded as a reduction to revenue. We will attempt to obtain change orders, contract extensions or accelerate project completion, which may resolve the potential for any unaccrued liquidated damage. Should we fail to achieve relief on some or all of these contractual obligations, we could be required to pay additional liquidated damages, which could negatively impact our future operating results.


## us-gaap:ConsolidationPolicyTextBlock

[0000080420-18-000036:notes:24]
Principles of Consolidation

[0000080420-18-000036:notes:25]
The consolidated financial statements include the accounts of Powell and our wholly owned subsidiaries. All intercompany accounts and transactions have been eliminated in consolidation.


## us-gaap:CostsInExcessOfBillingsAndBillingsInExcessOfCostsTableTextBlock

[0000080420-18-000036:notes:26]
The components of costs and estimated earnings and related amounts billed on uncompleted contracts are summarized below (in thousands):

[0000080420-18-000036:notes:27]
|  | September 30, |
|  | 2018 |  | 2017 |
| Costs incurred on uncompleted contracts | $ | 872,882 |  |  | $ | 987,164 |  |
| Estimated earnings | 269,268 |  |  | 316,970 |  |
|  | 1,142,150 |  |  | 1,304,134 |  |
| Less: Billings to date | (1,102,779 | ) |  | (1,278,746 | ) |
| Net underbilled position | $ | 39,371 |  |  | $ | 25,388 |  |
| Included in the accompanying balance sheets under the following captions: |  |  |  |
| Costs and estimated earnings in excess of billings on uncompleted contracts – underbilled | $ | 82,545 |  |  | $ | 51,554 |  |
| Billings in excess of costs and estimated earnings on uncompleted contracts – overbilled | (43,174 | ) |  | (26,166 | ) |
| Net underbilled position | $ | 39,371 |  |  | $ | 25,388 |  |


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0000080420-18-000036:notes:28]
Stock-Based Compensation

[0000080420-18-000036:notes:29]
We have the following stock-based compensation plans:

[0000080420-18-000036:notes:30]
2014 Equity Incentive Plan

[0000080420-18-000036:notes:31]
In February 2014, our stockholders approved and adopted at the Annual Meeting of Stockholders the 2014 Equity Incentive Plan (the 2014 Plan), which replaced our 2006 Equity Compensation Plan (2006 Plan). Persons eligible to receive awards under the 2014 Plan include our officers and employees. The 2014 Plan authorizes stock options, stock appreciation rights, restricted stock, restricted stock units and performance-based awards, as well as certain other awards.

[0000080420-18-000036:notes:32]
In accordance with the 2014 Plan, the compensation committee has authorized grants of restricted stock units (RSUs) to certain officers and key employees of the company. The fair value of the RSUs is based on the closing price of our common stock as reported on the NASDAQ Global Market on the grant dates. Typically, these grants vest over a three-year period from their date of issuance. Sixty percent of the grant is time-based and vests over a three-year period on each anniversary of the grant date, based on continued employment. The remaining forty percent of the grant is earned based on the three-year earnings performance of the Company following the grant date. At September 30, 2018, there were 190,500 RSUs outstanding. The RSUs do not have voting rights but do receive dividend equivalents upon vesting; additionally, the shares of common stock underlying the RSUs are not considered issued and outstanding until vested and common stock is issued.

[0000080420-18-000036:notes:33]
Total RSU activity (number of shares) for the past fiscal year is summarized below:

[0000080420-18-000036:notes:34]
|  | Number ofRestrictedStockUnits |  | WeightedAverageGrant ValuePer Share |
| Outstanding at September 30, 2017 | 177,737 |  |  | $ | 37.00 |  |
| Granted | 88,000 |  |  | 29.88 |  |
| Vested | (51,437 | ) |  | 35.11 |  |
| Forfeited/cancelled | (23,800 | ) |  | 41.39 |  |
| Outstanding at September 30, 2018 | 190,500 |  |  | $ | 33.73 |  |

[0000080420-18-000036:notes:35]
We have reserved 750,000 shares of common stock for issuance under the 2014 Plan. As of September 30, 2018, there were 633,011 shares of common stock left available.

[0000080420-18-000036:notes:36]
2014 Non-Employee Director Equity Incentive Plan

[0000080420-18-000036:notes:37]
In February 2014, our stockholders approved and adopted at the Annual Meeting of Stockholders the 2014 Non-Employee Director Equity Incentive Plan (the 2014 Director Plan). The total number of shares of common stock reserved under the plan is 150,000 shares. The plan is administered by the Compensation Committee. Eligibility to participate in the plan is limited to those individuals who are members of the Board of Directors of the Company and who are not employees of the Company or any affiliate of the Company.

[0000080420-18-000036:notes:38]
Under the terms of the 2014 Director Plan, the maximum number of shares that may be granted during any calendar year to any individual is 12,000 shares. The total number of shares that may be issued for awards to any single participant during a calendar year for other stock-based awards (excluding stock options and SARs) is 4,000 shares. The Compensation Committee has determined that each non-employee director will receive 2,000 restricted shares of the Company’s common stock annually. Fifty percent of the restricted stock granted to each of our non-employee directors vests immediately, while the remaining fifty percent vests on the anniversary of the grant date. Compensation expense is recognized immediately for the first fifty percent of the restricted stock granted, while compensation expense for the remaining fifty percent will be recognized over the remaining vesting period based on the closing price per share on the grant date.

[0000080420-18-000036:notes:39]
Under this 2014 Director Plan, in February 2018, we issued 6,000 shares of restricted stock to our non-employee directors at a price of $27.88 per share and in April 2018, we issued 1,000 shares of restricted stock to a single non-employee director at a price of  $27.15. In February 2017, we issued 17,000 shares of restricted stock to our non-employee directors at a price of $34.24 per share. The total number of shares of common stock available for future awards under the 2014 Director plan was 70,600 shares as of September 30, 2018.

[0000080420-18-000036:notes:40]
At September 30, 2018 and 2017, there were 7,000 shares and 16,000 shares of unvested restricted stock outstanding, respectively. Total compensation expense related to restricted stock grants under all plans was $0.5 million, $0.7 million and $0.7 million for the years ended September 30, 2018, 2017 and 2016, respectively. Total compensation expense related to RSU’s under all plans was $2.7 million, $2.0 million and $4.2 million for the years ended September 30, 2018, 2017 and 2016, respectively.

[0000080420-18-000036:notes:41]
We record the amortization of non-vested restricted stock and restricted stock units as an increase to additional paid-in capital. As of September 30, 2018 and 2017, amounts of deferred compensation expense not yet recognized related to non-vested stock totaled $1.2 million and $1.6 million, respectively. As of September 30, 2018, the total weighted average remaining contractual life of our restricted stock and RSU’s is approximately six months and 1.3 years, respectively.


## us-gaap:EarningsPerShareTextBlock

[0000080420-18-000036:notes:42]
Earnings Per Share

[0000080420-18-000036:notes:43]
We compute basic earnings per share by dividing net income by the weighted average number of common shares outstanding during the period. Diluted earnings per common and potential common share includes the weighted average of additional shares associated with the incremental effect of dilutive restricted stock and restricted stock units, as prescribed by the FASB guidance on earnings per share.

[0000080420-18-000036:notes:44]
The following table reconciles basic and diluted weighted average shares used in the computation of earnings per share for the years ended September 30, 2018, 2017 and 2016 (in thousands, except per share data):

[0000080420-18-000036:notes:45]
|  | Year Ended September 30, |
|  | 2018 |  | 2017 |  | 2016 |
| Numerator: |  |  |  |  |  |
| Net income (loss) | $ | (7,152 | ) |  | $ | (9,486 | ) |  | $ | 15,510 |  |
| Denominator: |  |  |  |  |  |
| Weighted average basic shares | 11,507 |  |  | 11,453 |  |  | 11,400 |  |
| Dilutive effect of restricted stock units | — |  |  | — |  |  | 31 |  |
| Weighted average diluted shares with assumed conversions | 11,507 |  |  | 11,453 |  |  | 11,431 |  |
| Net earnings (loss) per share: |  |  |  |  |  |
| Basic earnings (loss) per share | $ | (0.62 | ) |  | $ | (0.83 | ) |  | $ | 1.36 |  |
| Diluted earnings (loss) per share | $ | (0.62 | ) |  | $ | (0.83 | ) |  | $ | 1.36 |  |

[0000080420-18-000036:notes:46]
For the years ended September 30, 2018 and 2017, we incurred net losses and therefore all potential common shares were deemed to be anti-dilutive.


## us-gaap:FairValueDisclosuresTextBlock

[0000080420-18-000036:notes:47]
Fair Value Measurements

[0000080420-18-000036:notes:48]
We measure certain financial assets and liabilities at fair value. Fair value is defined as an “exit price” which represents the amount that would be received to sell an asset or paid to transfer a liability in an orderly transaction between market participants as of the measurement date. As such, fair value is a market-based measurement that should be determined based on assumptions that market participants would use in valuing an asset or liability. The accounting guidance requires the use of valuation techniques to measure fair value that maximize the use of observable inputs and minimize the use of unobservable inputs. As a basis for considering such assumptions and inputs, a fair value hierarchy has been established that identifies and prioritizes three levels of inputs to be used in measuring fair value.

[0000080420-18-000036:notes:49]
The three levels of the fair value hierarchy are as follows:

[0000080420-18-000036:notes:50]
Level 1 — Observable inputs such as quoted prices (unadjusted) in active markets for identical assets or liabilities.

[0000080420-18-000036:notes:51]
Level 2 — Inputs other than the quoted prices in active markets that are observable either directly or indirectly, including: quoted prices for similar assets and liabilities in active markets; quoted prices for identical or similar assets and liabilities in markets that are not active or other inputs that are observable or can be corroborated by observable market data.

[0000080420-18-000036:notes:52]
Level 3 — Unobservable inputs that are supported by little or no market data and require the reporting entity to develop its own assumptions.

[0000080420-18-000036:notes:53]
The following table summarizes the fair value of our assets and liabilities that were accounted for at fair value on a recurring basis as of September 30, 2018 (in thousands):

[0000080420-18-000036:notes:54]
|  | Fair Value Measurements at September 30, 2018 |
|  | Quoted Prices inActive Markets forIdentical Assets(Level 1) |  | Significant OtherObservableInputs(Level 2) |  | SignificantUnobservableInputs(Level 3) |  | Fair Value at September 30, 2018 |
| Assets: |  |  |  |  |  |  |  |
| Cash and cash equivalents | $ | 36,584 |  |  | $ | — |  |  | $ | — |  |  | $ | 36,584 |  |
| Short-term investments | 13,170 |  |  | — |  |  | — |  |  | 13,170 |  |
| Restricted cash | 25,141 |  |  | — |  |  | — |  |  | 25,141 |  |
| Other assets | — |  |  | 6,817 |  |  | — |  |  | 6,817 |  |
| Liabilities: |  |  |  |  |  |  |  |
| Deferred compensation | — |  |  | 5,644 |  |  | — |  |  | 5,644 |  |

[0000080420-18-000036:notes:55]
The following table summarizes the fair value of our assets and liabilities that were accounted for at fair value on a recurring basis as of September 30, 2017 (in thousands):

[0000080420-18-000036:notes:56]
|  | Fair Value Measurements at September 30, 2017 |
|  | Quoted Prices inActive Markets forIdentical Assets(Level 1) |  | Significant OtherObservableInputs(Level 2) |  | SignificantUnobservableInputs(Level 3) |  | Fair Value at September 30, 2017 |
| Assets: |  |  |  |  |  |  |  |
| Cash and cash equivalents | $ | 68,359 |  |  | $ | — |  |  | $ | — |  |  | $ | 68,359 |  |
| Short-term investments | 26,829 |  |  | — |  |  | — |  |  | 26,829 |  |
| Restricted cash | 24,851 |  |  | — |  |  | — |  |  | 24,851 |  |
| Other assets | — |  |  | 6,442 |  |  | — |  |  | 6,442 |  |
| Liabilities: |  |  |  |  |  |  |  |
| Deferred compensation | — |  |  | 4,991 |  |  | — |  |  | 4,991 |  |

[0000080420-18-000036:notes:57]
Fair value guidance requires certain fair value disclosures be presented in both interim and annual reports. The estimated fair value amounts of financial instruments have been determined using available market information and valuation methodologies described below.

[0000080420-18-000036:notes:58]
Cash and cash equivalents

[0000080420-18-000036:notes:59]
Cash and cash equivalents, primarily funds held in money market savings instruments, are reported at their current carrying value, which approximates fair value due to the short-term nature of these instruments and are included in cash and cash equivalents in our Consolidated Balance Sheets.

[0000080420-18-000036:notes:60]
Short-term Investments - Short-term investments include time deposits with original maturities of three months or more.

[0000080420-18-000036:notes:61]
Restricted Cash - Restricted cash represents a pledged cash collateral balance ,which is required under our amended credit agreement and is held in an interest-bearing savings account. See Note F for further discussion on restricted cash.

[0000080420-18-000036:notes:62]
Deferred Compensation – We hold investments in an irrevocable Rabbi Trust for our deferred compensation plan. The assets include both mutual fund investments and company-owned life insurance policies and are included in other assets in the accompanying Consolidated Balance sheets. Because the mutual funds and company-owned life insurance policies are combined in the plan, they are therefore categorized as Level 2 in the fair value measurement hierarchy. The deferred compensation liability represents the investment options that the plan participants have designated to serve as the basis for measurement of the notional value of their accounts.  Because the deferred compensation liability is intended to offset the plan assets, it is therefore also categorized as Level 2 in the fair value measurement hierarchy.


## us-gaap:FairValueMeasurementPolicyPolicyTextBlock

[0000080420-18-000036:notes:63]
Fair Value of Financial Instruments

[0000080420-18-000036:notes:64]
Financial instruments include cash, cash equivalents, short-term investments, restricted cash, receivables, deferred compensation, payables and debt obligations. Except as described below, due to the short-term nature of account receivables and account payables, the book value is representative of their fair value. The carrying value of debt approximates fair value as interest rates are indexed to the Federal Funds Rate or the bank’s prime rate.


## us-gaap:ForeignCurrencyTransactionsAndTranslationsPolicyTextBlock

[0000080420-18-000036:notes:65]
Foreign Currency Translation

[0000080420-18-000036:notes:66]
The functional currency for our foreign subsidiaries is the local currency in which the entity is located. The financial statements of all subsidiaries with a functional currency other than the U.S. Dollar have been translated into U.S. Dollars. All assets and liabilities of foreign operations are translated into U.S. Dollars using year-end exchange rates, and all revenues and expenses are translated at average rates during the respective period. The U.S. Dollar results that arise from such translation, as well as exchange gains and losses on intercompany balances of a long-term investment nature, are included in the cumulative currency translation adjustments in accumulated other comprehensive income (loss) in stockholders’ equity.


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0000080420-18-000036:notes:67]
Goodwill and Intangible Assets

[0000080420-18-000036:notes:68]
Our intangible assets consist of goodwill of $1.0 million, which is not being amortized, and purchased technology of $0.5 million, which is amortized over its estimated useful life. No impairment expense has been recorded for the last three fiscal years.

[0000080420-18-000036:notes:69]
Intangible assets balances, subject to amortization, at September 30, 2018 and 2017 consisted of the following (in thousands):

[0000080420-18-000036:notes:70]
|  | September 30, 2018 |  | September 30, 2017 |
|  | GrossCarryingValue |  | AccumulatedAmortization |  | NetCarryingValue |  | GrossCarryingValue |  | AccumulatedAmortization |  | NetCarryingValue |
| Purchased technology | $ | 11,749 |  |  | $ | (11,239 | ) |  | $ | 510 |  |  | $ | 11,749 |  |  | $ | (11,033 | ) |  | $ | 716 |  |

[0000080420-18-000036:notes:71]
Amortization of intangible assets recorded for the year ended September 30, 2018 was $0.2 million, and $0.4 million for the years ended September 30, 2017 and 2016, respectively.

[0000080420-18-000036:notes:72]
Estimated amortization expense for each of the five subsequent fiscal years is expected to be (in thousands):

[0000080420-18-000036:notes:73]
| Years Ended September 30, | Total |
| 2019 | $ | 177 |  |
| 2020 | 177 |  |
| 2021 | 156 |  |
| 2022 | — |  |
| 2023 | — |  |

[0000080420-18-000036:notes:74]
On August 7, 2006, we purchased certain assets related to the manufacturing of ANSI medium-voltage switchgear and circuit breaker business from General Electric Company (GE). In connection with the acquisition, we entered into a 15-year supply agreement with GE pursuant to which GE would purchase from us all of its requirements for ANSI medium-voltage switchgear and circuit breakers and other related equipment and components (the Products). We recorded an intangible asset related to this supply agreement. On December 30, 2013, we and GE amended the supply agreement to allow GE to manufacture similar Products for sale immediately and allow them to begin purchasing Products from other suppliers beginning December 31, 2014. In return, GE paid us $10 million upon execution of the amended supply agreement and agreed to pay an additional $7 million over three years, beginning March 2015. The final balance of $2.3 million was received in April 2017. We wrote off the intangible asset related to the original supply agreement and recorded a deferred credit in the amount of $8.1 million at December 31, 2013, the amount by which the total proceeds from GE exceeded the unamortized balance of our intangible asset. We amortized this deferred credit over the four-year life of the agreement and recorded $0.5 million in other income in Fiscal 2018, and $2.0 million in both Fiscal 2017 and 2016.


## us-gaap:IncomeTaxDisclosureTextBlock

[0000080420-18-000036:notes:75]
Income Taxes

[0000080420-18-000036:notes:76]
The components of the income tax provision (benefit) were as follows (in thousands):

[0000080420-18-000036:notes:77]
|  | Year Ended September 30, |
|  | 2018 |  | 2017 |  | 2016 |
| Current: |  |  |  |  |  |
| Federal | $ | 973 |  |  | $ | (7,782 | ) |  | $ | (1,395 | ) |
| State | 201 |  |  | (101 | ) |  | 449 |  |
| Foreign | 449 |  |  | 350 |  |  | 899 |  |
|  | 1,623 |  |  | (7,533 | ) |  | (47 | ) |
| Deferred: |  |  |  |  |  |  |  |  |
| Federal | (1,834 | ) |  | 392 |  |  | 1,923 |  |
| State | (247 | ) |  | (515 | ) |  | 47 |  |
| Foreign | (89 | ) |  | 223 |  |  | 360 |  |
|  | (2,170 | ) |  | 100 |  |  | 2,330 |  |
| Total income tax provision (benefit) | $ | (547 | ) |  | $ | (7,433 | ) |  | $ | 2,283 |  |

[0000080420-18-000036:notes:78]
Income (loss) before income taxes was as follows (in thousands):

[0000080420-18-000036:notes:79]
|  | Year Ended September 30, |
|  | 2018 |  | 2017 |  | 2016 |
| U.S. | $ | (2,103 | ) |  | $ | (19,932 | ) |  | $ | 5,087 |  |
| Other than U.S. | (5,596 | ) |  | 3,013 |  |  | 12,706 |  |
| Income (loss) before income taxes | $ | (7,699 | ) |  | $ | (16,919 | ) |  | $ | 17,793 |  |

[0000080420-18-000036:notes:80]
A reconciliation of the statutory U.S. income tax rate and the effective income tax rate, as computed on earnings before income tax provision in each of the three years presented in the Consolidated Statements of Operations, was as follows:

[0000080420-18-000036:notes:81]
|  | Year Ended September 30, |
|  | 2018 |  | 2017 |  | 2016 |
| Statutory rate | 25 | % |  | 35 | % |  | 35 | % |
| State income taxes, net of federal benefit | (2 | ) |  | 2 |  |  | 2 |  |
| Research and development credit | 9 |  |  | 9 |  |  | (8 | ) |
| Foreign rate differential | 1 |  |  | 2 |  |  | (8 | ) |
| Foreign withholding | (3 | ) |  | — |  |  | — |  |
| Foreign valuation allowance | (20 | ) |  | 2 |  |  | (11 | ) |
| NOL carryback impact on deductions | — |  |  | (4 | ) |  | — |  |
| Deferred tax rate differential | (4 | ) |  | — |  |  | — |  |
| Other | 1 |  |  | (2 | ) |  | 3 |  |
| Effective rate | 7 | % |  | 44 | % |  | 13 | % |

[0000080420-18-000036:notes:82]
On December 22, 2017, the Tax Cuts and Jobs Act (the Act) was signed into law.  The act lowers the corporate tax rate from 35% to 21% effective January 1, 2018. As a result, the U.S. federal statutory rate for Fiscal 2018 is a blended U.S. tax rate of 24.5%.

[0000080420-18-000036:notes:83]
Our income tax provision (benefit) reflects an effective tax rate on pre-tax results of 7% in Fiscal 2018 compared to 44% and 13% in Fiscal 2017 and 2016, respectively. The effective rate for Fiscal 2018 was negatively impacted by the relative amounts of income/loss recognized in various jurisdictions as well as a foreign tax loss which is reserved with a valuation allowance.  Additionally, we recorded deferred tax expense of $0.5 million due to the deferred tax rate differential related to the re-measurement of our U.S. deferred tax assets under the Act, which were not realized prior to the end of Fiscal 2018. The effective tax rate for Fiscal 2017 was favorably impacted by the lower tax rate in the U.K., the relative amounts of income/loss recognized in the various tax jurisdictions, the utilization of net operating loss carryforwards in Canada that have been fully reserved with a valuation allowance, as well as $0.9 million of discrete items recognized during the year, primarily related to the Research and Development Tax Credit (R&D Tax Credit). The effective tax rate for Fiscal 2016 was favorably impacted by the statutory tax rates in the U.K. and Canada and the relative amounts of income earned in those jurisdictions, as well as the utilization of net operating loss carryforwards mentioned above. Additionally, the effective tax rate for Fiscal 2016 was favorably impacted by a $0.8 million discrete item recorded in the first quarter of Fiscal 2016 related to the retroactive reinstatement of the R&D Tax Credit for the previously expired period from January 1, 2015 to September 30, 2015.

[0000080420-18-000036:notes:84]
We have not recorded deferred income taxes on $21.1 million of undistributed earnings of our foreign subsidiaries because of management’s intent to indefinitely reinvest such earnings. Upon distribution of these earnings in the form of dividends or otherwise, we may be subject to U.S. income taxes and foreign withholding taxes. It is not practical, however, to estimate the amount of taxes that may be payable on the eventual remittance of these earnings.

[0000080420-18-000036:notes:85]
We are subject to income tax in the U.S., multiple state jurisdictions and certain international jurisdictions, primarily the U.K. and Canada. We do not consider any state in which we do business to be a major tax jurisdiction. We remain open to examination in the other jurisdictions as follows:  Canada 2012 – 2017, United Kingdom 2016 – 2017 and the United States 2013, and 2015 –2017.

[0000080420-18-000036:notes:86]
The net deferred income tax asset was comprised of the following (in thousands):

[0000080420-18-000036:notes:87]
|  | September 30, |
|  | 2018 |  | 2017 |
| Current deferred income taxes: |  |  |  |  |
| Gross assets | $ | — |  |  | $ | 3,978 |  |
| Gross liabilities and valuation allowance | — |  |  | (439 | ) |
| Net current deferred income tax asset | — |  |  | 3,539 |  |
| Noncurrent deferred income taxes: |  |  |  |  |  |
| Gross assets | 22,480 |  |  | 18,559 |  |
| Gross liabilities and valuation allowance | (16,543 | ) |  | (18,330 | ) |
| Net noncurrent deferred income tax asset (liability) | 5,937 |  |  | 229 |  |
| Net deferred income tax asset | $ | 5,937 |  |  | $ | 3,768 |  |

[0000080420-18-000036:notes:88]
The tax effect of temporary differences between U.S. GAAP accounting and federal income tax accounting creating deferred income tax assets and liabilities was as follows (in thousands):

[0000080420-18-000036:notes:89]
|  | September 30, |
|  | 2018 |  | 2017 |
| Deferred Tax Assets: |  |  |  |
| Net operating loss | $ | 13,444 |  |  | $ | 11,823 |  |
| Credit carryforwards | 3,987 |  |  | 3,258 |  |
| Deferred compensation | 1,456 |  |  | 2,009 |  |
| Uniform capitalization and inventory | 1,043 |  |  | 1,432 |  |
| Stock-based compensation | 879 |  |  | 1,094 |  |
| Reserve for accrued employee benefits | 791 |  |  | 1,208 |  |
| Warranty accrual | 448 |  |  | 892 |  |
| Accrued legal | 154 |  |  | 435 |  |
| Postretirement benefits liability | 112 |  |  | 264 |  |
| Allowance for doubtful accounts | — |  |  | 14 |  |
| Goodwill | 54 |  |  | 64 |  |
| Other | 112 |  |  | 44 |  |
| Deferred tax assets | 22,480 |  |  | 22,537 |  |
| Deferred Tax Liabilities: |  |  |  |  |  |
| Depreciation and amortization | (6,946 | ) |  | (10,002 | ) |
| Deferred tax liabilities | (6,946 | ) |  | (10,002 | ) |
| Less: valuation allowance | (9,597 | ) |  | (8,767 | ) |
| Net deferred tax asset | $ | 5,937 |  |  | $ | 3,768 |  |

[0000080420-18-000036:notes:90]
We have established a valuation allowance in the amount of $9.6 million primarily related to the Canadian net deferred tax assets. In assessing the realizability of net deferred tax assets, we consider whether it is more likely than not that some portion or all of the net deferred tax assets may not be realized. The ultimate realization of net deferred tax assets is dependent on the generation of future taxable income during the periods in which those temporary differences become deductible.

[0000080420-18-000036:notes:91]
A rollforward of the valuation allowance for the past three years is summarized below:

[0000080420-18-000036:notes:92]
| Balance at September 30, 2015 | $ | 10,056 |  |
| Charged to cost and expenses | (1,934 | ) |
| Charged to other accounts | 317 |  |
| Balance at September 30, 2016 | $ | 8,439 |  |
| Charged to cost and expenses | (260 | ) |
| Charged to other accounts | 588 |  |
| Balance at September 30, 2017 | $ | 8,767 |  |
| Charged to cost and expenses | 1,575 |  |
| Charged to other accounts | (745 | ) |
| Balance at September 30, 2018 | $ | 9,597 |  |

[0000080420-18-000036:notes:93]
A reconciliation of the beginning and ending amount of the unrecognized tax benefits follows (in thousands):

[0000080420-18-000036:notes:94]
|  | Year Ended September 30, |
|  | 2018 |  | 2017 |  | 2016 |
| Balance at beginning of period | $ | 1,219 |  |  | $ | 1,046 |  |  | $ | 784 |  |
| Increases related to tax positions taken during the current period | 180 |  |  | 179 |  |  | 293 |  |
| Increases related to tax positions taken during a prior period | 455 |  |  | 338 |  |  | — |  |
| Decreases related to expiration of statute of limitations | — |  |  | — |  |  | (31 | ) |
| Decreases related to settlement with taxing authorities | — |  |  | (344 | ) |  | — |  |
| Balance at end of period | $ | 1,854 |  |  | $ | 1,219 |  |  | $ | 1,046 |  |

[0000080420-18-000036:notes:95]
Our policy is to recognize interest and penalties related to income tax matters as tax expense. The amount of interest and penalty expense recorded for the year ended September 30, 2018 was not material.

[0000080420-18-000036:notes:96]
Due to the expiration of certain federal statutes of limitations and voluntary filings, management believes that, within the next 12 months, it is reasonably possible that the unrecognized tax benefits will decrease by approximately 22%.

[0000080420-18-000036:notes:97]
Management believes that an adequate provision has been made for any adjustments that may result from tax examinations. However, the outcome of tax audits cannot be predicted with certainty. If any issues addressed in our tax audits are resolved in a manner not consistent with management’s expectations, we could be required to adjust our provision for income tax in the period such resolution occurs.


## us-gaap:IncomeTaxPolicyTextBlock

[0000080420-18-000036:notes:98]
We account for income taxes under the asset and liability method, based on the income tax laws and rates in the countries in which operations are conducted and income is earned. This approach requires the recognition of deferred tax assets and liabilities for the expected future tax consequences of temporary differences between the carrying amounts and the tax basis of assets and liabilities. Developing our provision for income taxes requires significant judgment and expertise in federal, international and state income tax laws, regulations and strategies, including the determination of deferred tax assets and liabilities and, if necessary, any valuation allowances that may be required for deferred tax assets. In assessing the extent to which net deferred tax assets may be realized, we consider whether it is more likely than not that some portion or all of the net deferred tax assets may not be realized. The ultimate realization of net deferred tax assets is dependent on the generation of future taxable income during the periods in which those temporary differences become deductible. Estimates may change as new events occur, estimates of future taxable income during the carryforward period are reduced or increased, additional information becomes available or operating environments change, which may result in a full or partial reversal of the valuation allowance. We will continue to assess the adequacy of the valuation allowance on a quarterly basis. Our judgments and tax strategies are subject to audit by various taxing authorities.

[0000080420-18-000036:notes:99]
The objectives of accounting for income taxes are to recognize the amount of taxes payable or refundable for the current year and deferred tax liabilities and assets for the future tax consequences of events that have been recognized in an entity’s financial statements or tax returns. We recognize the tax benefit from an uncertain tax position only if it is more likely than not that the tax position will be sustained on examination by the taxing authorities, based on the technical merits of the position. The tax benefits recognized in the financial statements from such a position should be measured based on the largest benefit that has a greater than 50% likelihood of being realized upon ultimate settlement. Accounting literature also provides guidance on derecognition of income tax assets and liabilities, classification of current and deferred income tax assets and liabilities, accounting for interest and penalties associated with tax positions, and income tax disclosures. Judgment is required in assessing the future tax consequences of events that have been recognized in our financial statements or tax returns. Variations in the actual outcome of these future tax consequences could materially impact our financial statements.


## us-gaap:InventoryPolicyTextBlock

[0000080420-18-000036:notes:100]
Inventories

[0000080420-18-000036:notes:101]
Inventories are stated at the lower of cost or net realizable value using weighted-average methods and include the cost of materials, labor and manufacturing overhead. We use estimates in determining the level of reserves required to state inventory at the lower of cost or net realizable value. Our estimates are based on market activity levels, production requirements, the physical condition of products and technological innovation. Changes in any of these factors may result in adjustments to the carrying value of inventory.


## us-gaap:LongLivedAssetsByGeographicAreasTableTextBlock

[0000080420-18-000036:notes:102]
|  | September 30, |
|  | 2018 |  | 2017 |
| Long-lived assets: |  |  |  |
| United States | $ | 76,016 |  |  | $ | 82,589 |  |
| Canada | 48,126 |  |  | 52,122 |  |
| United Kingdom | 4,622 |  |  | 4,709 |  |
| Total | $ | 128,764 |  |  | $ | 139,420 |  |


## us-gaap:LongTermDebtTextBlock

[0000080420-18-000036:notes:103]
Long-term debt consisted of the following (in thousands):

[0000080420-18-000036:notes:104]
|  | September 30, |
|  | 2018 |  | 2017 |
| Industrial development revenue bonds | $ | 1,600 |  |  | $ | 2,000 |  |
| Less: current portion | (400 | ) |  | (400 | ) |
| Total long-term debt | $ | 1,200 |  |  | $ | 1,600 |  |

[0000080420-18-000036:notes:105]
The annual maturities of long-term debt as of September 30, 2018, were as follows (in thousands):

[0000080420-18-000036:notes:106]
| Year Ending September 30, | Long‑TermDebtMaturities |
| 2019 | $ | 400 |  |
| 2020 | 400 |  |
| 2021 | 400 |  |
| 2022 | 400 |  |
| 2023 | — |  |
| Total long-term debt maturities | $ | 1,600 |  |

[0000080420-18-000036:notes:107]
U.S. Revolver

[0000080420-18-000036:notes:108]
We have a $75.0 million revolving credit facility (U.S. Revolver) to provide working capital support and letters of credit which expires June 2022. The amount available under the U.S. Revolver at September 30, 2018 was reduced by $23.1 million for our outstanding letters of credit. Currently, our U.S. Revolver can only be used for letters of credit until we meet certain financial ratios. There were no loans outstanding under the U.S. Revolver as of September 30, 2018.

[0000080420-18-000036:notes:109]
Per the terms of the U.S. Revolver, we are required to maintain cash in a pledged collateral account until we satisfy the following two financial ratios for two consecutive fiscal quarters: a max leverage ratio and a fixed charge coverage ratio. The max leverage ratio requires that the ratio of our consolidated funded indebtedness to our consolidated earnings before interest, taxes and depreciation (EBITDA) for the last four consecutive quarters not exceed 2.75 to 1.00. The fixed charge coverage ratio requires that the ratio of consolidated EBITDA for the last four fiscal quarters, less income taxes, capital expenditures, principal debt payments and interest charges be at least 1.25 to 1.00. If we are not in compliance with the these two ratios, we are required to maintain a cash balance in a pledged cash collateral account equal to 102% of the outstanding amount of any loans and letter of credit obligations until we meet the aforementioned required ratios. As of September 30, 2018, the balance in the cash collateral account was $25.1 million and is recorded as restricted cash in our Consolidated Balance Sheets. The portion of the cash collateral account associated with the outstanding letters of credit that are due to expire beyond twelve months has been classified as non-current restricted cash. As of September 30, 2018, $51.9 million was available for the issuance of letters of credit under the U.S. Revolver, subject to the cash collateral requirements mentioned above.

[0000080420-18-000036:notes:110]
The interest rate for amounts outstanding under the U.S. Revolver is a floating rate based upon the higher of the Federal Funds Rate plus 0.5%, the bank’s prime rate, or the Eurocurrency rate plus 1.00%. Once the applicable rate is determined, a margin ranging up to 1.25%, is added to the applicable rate.

[0000080420-18-000036:notes:111]
The U.S. Revolver is collateralized by a pledge of 100% of the voting capital stock of each of our domestic subsidiaries and 65% of the voting capital stock of each non-domestic subsidiary. The U.S. Revolver provides for customary events of default and carries cross-default provisions with other existing debt agreements. If an event of default (as defined in the U.S. Revolver) occurs and is continuing, on the terms and subject to the conditions set forth in the U.S. Revolver, amounts outstanding under the U.S. Revolver may be accelerated and may become immediately due and payable. It also contains financial covenants defining various financial measures and the levels of these measures with which we must comply, as well as a “material adverse change” clause. A “material adverse change” is defined as a material change in our operations, business, properties, liabilities or condition (financial or otherwise) or a material impairment of our ability to perform our obligations under our credit agreements. As of September 30, 2018, we were in compliance with all of the financial covenants of the U.S. Revolver.

[0000080420-18-000036:notes:112]
Industrial Development Revenue Bonds

[0000080420-18-000036:notes:113]
We borrowed $8.0 million in October 2001 through a loan agreement funded with proceeds from tax-exempt industrial development revenue bonds (Bonds). These Bonds were issued by the Illinois Development Finance Authority and were used for the completion of our Northlake, Illinois facility. Pursuant to the Bond issuance, a reimbursement agreement between us and a major domestic bank required an issuance by the bank of an irrevocable direct-pay letter of credit (Bond LC), as collateral, to the Bonds’ trustee to guarantee payment of the Bonds’ principal and interest when due. The Bond LC is subject to both early termination and extension provisions customary to such agreements. While the Bonds mature in 2021, the reimbursement agreement requires annual redemptions of $0.4 million that commenced on October 25, 2002. A sinking fund is used for the annual principal payment. The Bonds bear interest at a floating rate determined weekly by the Bonds’ remarketing agent, which was the underwriter for the Bonds and is an affiliate of the bank. This interest rate was 1.72% as of September 30, 2018. As of September 30, 2018, we were in compliance with all of the covenants of the Bonds.


## us-gaap:NewAccountingPronouncementsPolicyPolicyTextBlock

[0000080420-18-000036:notes:114]
New Accounting Standards

[0000080420-18-000036:notes:115]
In May 2014, the Financial Accounting Standards Board (FASB) issued a new standard on revenue recognition that supersedes previously issued revenue recognition guidance. This standard provides a five-step approach to be applied to all contracts with customers and requires expanded disclosures about the nature, amount, timing and uncertainty of revenue (and the related cash flows) arising from customer contracts, significant judgments and changes in judgments used in applying the revenue model and the assets recognized from costs incurred to obtain or fulfill a contract. This standard is effective for fiscal years, and interim periods within those years, beginning after December 15, 2017, which would be our fiscal year ending September 30, 2019. We plan to use the modified retrospective basis upon adoption, which could result in a cumulative effect adjustment as of October 1, 2018, if material. We have updated our accounting policies and procedures and determined the impact from this new standard on our contracts outstanding as of October 1, 2018. We have substantially completed our evaluation of the impact of the new standard on our contracts with customers, including identification of differences that will result from the new requirements. Based on this evaluation, we estimate that the net cumulative adjustment to retained earnings from adoption will not be material to our consolidated financial statements. Our disclosures related to revenue recognition will expand to address new quantitative and qualitative requirements regarding the nature, amount and timing of revenue from contracts with customers and additional information related to contract assets and liabilities.

[0000080420-18-000036:notes:116]
In November 2015, the FASB issued an amendment to the topic regarding income taxes which requires an entity to separate deferred income tax liabilities and assets into current and noncurrent amounts in the statement of financial position.  Deferred tax liabilities and assets are classified as current or noncurrent based on the classification of the related asset or liability for financial reporting.  Deferred tax liabilities and assets that are not related to an asset or liability for financial reporting are classified according to the expected reversal date of the temporary difference. To simplify the presentation of deferred income taxes, the amendments require that deferred income tax liabilities and assets be classified as noncurrent in a statement of financial position. We have adopted this topic prospectively in Fiscal 2018 and our statement of financial position reflects this reclassification. We have not retrospectively adjusted prior periods.

[0000080420-18-000036:notes:117]
In February 2016, the FASB issued a new topic on leases which requires lessees to recognize lease assets and lease liabilities on the balance sheet for all leases with terms longer than 12 months. Leases will be classified as either finance or operating, with classification affecting the pattern of expense recognition in the income statement. A modified retrospective transition approach is required for lessees for capital and operating leases existing at, or entered into after, the beginning of the earliest comparative period presented in the financial statements, with certain practical expedients available. The new topic is effective for fiscal years beginning after December 15, 2018, including interim periods within those fiscal years. This would be our fiscal year ending September 30, 2020. We are still evaluating the potential impact of this topic on our financial statements.

[0000080420-18-000036:notes:118]
In November 2016, the FASB issued a new topic on the statement of cash flows that changes the presentation of restricted cash and cash equivalents on the statement of cash flows. Restricted cash and restricted cash equivalents will be included with cash and cash equivalents when reconciling the beginning-of-period and end-of-period total amounts shown on the statement of cash flows. This topic is effective for fiscal years beginning after December 15, 2017, and interim periods within those fiscal years, which would be our fiscal year ending September 30, 2019. We are still evaluating this new topic, but do not expect it to have a material impact on our statement of cash flows.

[0000080420-18-000036:notes:119]
In May 2017, the FASB issued a new topic on modification accounting with regards to stock-based compensation. This new topic clarifies when a change to the terms or conditions of a share-based payment award should be accounted for as a modification. An entity should account for the effects of a modification unless the fair value, vesting conditions and classification, as an equity instrument or a liability instrument, of the modified award are the same before and after a change to the terms or conditions of the share-based payment award. This topic is effective for annual reporting periods beginning after December 15, 2017, which is our fiscal year ending September 30, 2019. We are still evaluating this new topic, but do not expect it to have a material impact on our consolidated financial position or results of operations.


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0000080420-18-000036:notes:120]
Employee Benefit Plans

[0000080420-18-000036:notes:121]
Retirement Plans

[0000080420-18-000036:notes:122]
We have defined employee contribution plans for substantially all of our U.S. employees (401(k) plan) and our Canadian employees (Registered Retirement Savings Plan). We recognized expenses under these plans primarily related to matching contributions of $2.8 million, $2.8 million and $3.9 million in Fiscal 2018, 2017 and 2016, respectively.

[0000080420-18-000036:notes:123]
Deferred Compensation

[0000080420-18-000036:notes:124]
We offer a non-qualified deferred compensation plan to a select group of management and highly compensated individuals. The plan permits the deferral of up to 50% of a participant’s base salary and/or 100% of a participant’s annual incentive bonus. The deferrals are held in a separate trust, an irrevocable rabbi trust (the Rabbi Trust), which has been established to administer the plan. The Rabbi Trust is intended to be used as a source of funds to match respective funding obligations to participants. The assets of the trust are subject to the claims of our creditors in the event that we become insolvent. Consequently, the Rabbi Trust qualifies as a grantor trust for income tax purposes. We make periodic payments into company-owned life insurance policies held in this Rabbi Trust to fund the expected obligations arising under this plan. The assets and liabilities of the plan are recorded in other assets and deferred compensation, respectively, in the accompanying Consolidated Balance Sheets. Changes in the deferred compensation balance are recorded to compensation expense and reflected within the selling, general and administrative line in the Consolidated Statements of Operations. The plan is not qualified under Section 401 of the Internal Revenue code. We recorded net compensation expense adjustments of less than $0.1 million related to this plan in Fiscal 2018. At September 30, 2018, total assets held by the trustee were $6.8 million and the liability was $5.6 million. Of the $6.8 million of assets held by the trustee, $6.7 million is invested in company-owned life insurance policies and the remainder in mutual funds.

[0000080420-18-000036:notes:125]
Certain former executives were provided an executive benefit plan that provides for fixed payments upon normal retirement on or after age 65 and the completion of at least 10 years of continuous employment. The estimated present value of these payments were accrued over the service life of these individuals, and $0.3 million is recorded in deferred compensation related to this executive benefit plan. To assist in funding the deferred compensation liability, we invested in company-owned life insurance policies. The cash surrender value of these policies is presented in other assets and was $3.2 million at September 30, 2018. During the fourth quarter of Fiscal 2018, we received $1.9 million in proceeds from one of these policies.

[0000080420-18-000036:notes:126]
Retiree Medical Plan

[0000080420-18-000036:notes:127]
We have a plan that extends health benefits to retirees that are also available to active employees under our existing health plans. This plan is unfunded. The plan provides coverage for employees with at least 10 years of service who are age 55 or older but less than 65. The retiree is required to pay the COBRA rate less a subsidy provided by us based on years of service at the time of retirement. The unfunded liability is recorded in other long-term liabilities and was $0.9 million and $1.1 million as of September 30, 2018 and 2017, respectively, and our net periodic postretirement benefit expenses have been less than $0.1 million for the last three fiscal years. Due to the immateriality of the costs and liabilities of this plan, no further disclosure is being presented.


## us-gaap:PropertyPlantAndEquipmentPolicyTextBlock

[0000080420-18-000036:notes:128]
Property, Plant and Equipment

[0000080420-18-000036:notes:129]
Property, plant and equipment are stated at cost and are depreciated using the straight-line method over the estimated useful lives of the assets. Expenditures for repairs and maintenance are charged to expense when incurred. Expenditures for major renewals and improvements, which extend the useful lives of existing equipment, are capitalized and depreciated. Upon retirement or disposition of property, plant and equipment, the cost and related accumulated depreciation are removed from the accounts, and any resulting gain or loss is recognized in the Consolidated Statements of Operations.

[0000080420-18-000036:notes:130]
We review property, plant and equipment for impairment whenever events or changes in circumstances indicate that the carrying value may not be realizable. If an evaluation is required, the estimated future undiscounted cash flows associated with the asset are compared to the asset’s carrying amount to determine if recording an impairment of such asset is necessary. If an impairment is indicated, we record an impairment loss equal to the difference between the carrying value and the fair value of the long-lived asset. This requires us to make long-term forecasts of the future revenues and the costs related to the assets subject to review. Forecasts require assumptions about demand for our products and future market conditions. Estimating future cash flows requires significant judgment and our projections may vary from cash flows eventually realized. Future events and unanticipated changes to assumptions could require a provision for impairment in a future period. The effect of any impairment would be reflected in income (loss) from operations in the Consolidated Statements of Operations. In addition, we estimate the useful lives of our property, plant and equipment and periodically review these estimates to determine whether these lives are appropriate.


## us-gaap:PropertyPlantAndEquipmentTextBlock

[0000080420-18-000036:notes:131]
Property, plant and equipment are summarized below (in thousands):

[0000080420-18-000036:notes:132]
|  | September 30, |  | Range of |
|  | 2018 |  | 2017 |  | Asset Lives |
| Land | $ | 22,207 |  |  | $ | 22,441 |  |  | — |
| Buildings and improvements | 123,320 |  |  | 121,960 |  |  | 3 - 39 Years |
| Machinery and equipment | 104,542 |  |  | 106,113 |  |  | 3 - 15 Years |
| Furniture and fixtures | 3,799 |  |  | 3,806 |  |  | 3 - 10 Years |
| Construction in process | 357 |  |  | 1,749 |  |  | — |
|  | $ | 254,225 |  |  | $ | 256,069 |  |  |  |
| Less: Accumulated depreciation | (125,461 | ) |  | (116,649 | ) |  |  |
| Total property, plant and equipment, net | $ | 128,764 |  |  | $ | 139,420 |  |  |  |


## us-gaap:QuarterlyFinancialInformationTextBlock

[0000080420-18-000036:notes:133]
Quarterly Information

[0000080420-18-000036:notes:134]
The table below sets forth the unaudited consolidated operating results by fiscal quarter for the years ended September 30, 2018 and 2017 (in thousands, except per share data):

[0000080420-18-000036:notes:135]
|  | 2018 Quarters |
|  | First |  | Second |  | Third |  | Fourth |  | 2018 |
| Revenues | $ | 90,184 |  |  | $ | 101,505 |  |  | $ | 122,130 |  |  | $ | 134,897 |  |  | $ | 448,716 |  |
| Gross profit | 10,554 |  |  | 12,421 |  |  | 18,375 |  |  | 24,005 |  |  | 65,355 |  |
| Net income (loss) | (5,662 | ) |  | (3,330 | ) |  | 301 |  |  | 1,539 |  |  | (7,152 | ) |
| Earnings (loss) per share: |  |  |  |  |  |  |  |  |  |
| Basic | $ | (0.49 | ) |  | $ | (0.29 | ) |  | $ | 0.03 |  |  | $ | 0.13 |  |  | $ | (0.62 | ) |
| Diluted | $ | (0.49 | ) |  | $ | (0.29 | ) |  | $ | 0.03 |  |  | $ | 0.13 |  |  | $ | (0.62 | ) |

[0000080420-18-000036:notes:136]
|  | 2017 Quarters |
|  | First |  | Second |  | Third |  | Fourth |  | 2017 |
| Revenues | $ | 110,341 |  |  | $ | 104,680 |  |  | $ | 85,927 |  |  | $ | 94,963 |  |  | $ | 395,911 |  |
| Gross profit | 14,999 |  |  | 15,822 |  |  | 9,054 |  |  | 10,894 |  |  | 50,769 |  |
| Net income (loss) | (300 | ) |  | (829 | ) |  | (3,215 | ) |  | (5,142 | ) |  | (9,486 | ) |
| Earnings (loss) per share: |  |  |  |  |  |  |  |  |  |
| Basic | $ | (0.03 | ) |  | $ | (0.07 | ) |  | $ | (0.28 | ) |  | $ | (0.45 | ) |  | $ | (0.83 | ) |
| Diluted | $ | (0.03 | ) |  | $ | (0.07 | ) |  | $ | (0.28 | ) |  | $ | (0.45 | ) |  | $ | (0.83 | ) |

[0000080420-18-000036:notes:137]
The sum of the individual earnings per share amounts may not agree with year-to-date earnings per share as each period’s computation is based on the weighted-average number of shares outstanding during the period.


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0000080420-18-000036:notes:138]
Restructuring and Separation Expenses

[0000080420-18-000036:notes:139]
In Fiscal 2018, we incurred approximately $0.8 million of restructuring costs due to anticipated losses on the sublet of a Canadian facility that we exited in a prior period.

[0000080420-18-000036:notes:140]
In Fiscal 2017, we incurred approximately $1.3 million of restructuring costs, as we continued to reduce our overall cost structure to better align our costs with future production requirements.

[0000080420-18-000036:notes:141]
In Fiscal 2016, we incurred approximately $7.9 million of separation costs, of which $3.8 million were separation costs related to the departure of our former Chief Executive Officer in December 2015. Additionally in Fiscal 2016, we incurred approximately $0.5 million of restructuring costs related to a Canadian facility that we leased and exited in the third quarter of Fiscal 2016.


## us-gaap:RevenueFromExternalCustomersByGeographicAreasTableTextBlock

[0000080420-18-000036:notes:142]
Revenues by country represent sales to unaffiliated customers as determined by the ultimate destination of our products and services, summarized for the last three fiscal years by region in the table below (in thousands):

[0000080420-18-000036:notes:143]
|  | Year Ended September 30, |
|  | 2018 |  | 2017 |  | 2016 |
| United States | $ | 335,743 |  |  | $ | 279,352 |  |  | $ | 405,298 |  |
| Canada | 42,235 |  |  | 45,540 |  |  | 77,252 |  |
| Middle East and Africa | 38,490 |  |  | 26,639 |  |  | 40,294 |  |
| Far East | 12,976 |  |  | 3,877 |  |  | 7,895 |  |
| Europe | 10,538 |  |  | 21,194 |  |  | 26,200 |  |
| Mexico, Central and South America | 8,734 |  |  | 19,309 |  |  | 8,304 |  |
| Total revenues | $ | 448,716 |  |  | $ | 395,911 |  |  | $ | 565,243 |  |


## us-gaap:ScheduleOfCashFlowSupplementalDisclosuresTableTextBlock

[0000080420-18-000036:notes:144]
Supplemental Disclosures of Cash Flow Information (in thousands):

[0000080420-18-000036:notes:145]
|  | Year Ended September 30, |
|  | 2018 |  | 2017 |  | 2016 |
| Cash paid (received) during the period for: |  |  |  |  |  |
| Interest paid, net of interest income | $ | (676 | ) |  | $ | (384 | ) |  | 4 |  |
| Income taxes paid, net of refunds | 354 |  |  | (764 | ) |  | (352 | ) |
| Non-cash capital expenditures | 129 |  |  | 634 |  |  | 221 |  |


## us-gaap:ScheduleOfInventoryCurrentTableTextBlock

[0000080420-18-000036:notes:146]
The components of inventories are summarized below (in thousands):

[0000080420-18-000036:notes:147]
|  | September 30, |
|  | 2018 |  | 2017 |
| Raw materials, parts and subassemblies | $ | 24,563 |  |  | $ | 22,100 |  |
| Work-in-progress | 1,080 |  |  | 600 |  |
| Provision for excess and obsolete inventory | (4,291 | ) |  | (4,252 | ) |
| Total inventories | $ | 21,352 |  |  | $ | 18,448 |  |


## us-gaap:ScheduleOfProductWarrantyLiabilityTableTextBlock

[0000080420-18-000036:notes:148]
Activity in our warranty accrual consisted of the following (in thousands):

[0000080420-18-000036:notes:149]
|  | September 30, |
|  | 2018 |  | 2017 |
| Balance at beginning of period | $ | 3,174 |  |  | $ | 4,639 |  |
| Increase to warranty expense | 2,031 |  |  | 1,806 |  |
| Deduction for warranty charges | (2,574 | ) |  | (3,314 | ) |
| Change due to foreign currency translation | (27 | ) |  | 43 |  |
| Balance at end of period | $ | 2,604 |  |  | $ | 3,174 |  |


## us-gaap:SegmentReportingDisclosureTextBlock

[0000080420-18-000036:notes:150]
Geographic Information

[0000080420-18-000036:notes:151]
Long-lived assets by country consist of property, plant and equipment, net of accumulated depreciation and are determined based on the location of the tangible assets.


## us-gaap:SignificantAccountingPoliciesTextBlock

[0000080420-18-000036:notes:152]
Summary of Significant Accounting Policies

[0000080420-18-000036:notes:153]
Use of Estimates

[0000080420-18-000036:notes:154]
The preparation of financial statements in conformity with accounting principles generally accepted in the United States (U.S. GAAP) requires management to make estimates and assumptions that affect the amounts reported in the consolidated financial statements and accompanying footnotes. The most significant estimates used in our financial statements affect revenue and cost recognition for construction contracts, the allowance for doubtful accounts, provision for excess and obsolete inventory, warranty accruals and income taxes. The amounts recorded for warranties, legal, income taxes, impairment of long-lived assets (when applicable) and other contingent liabilities require judgments regarding the amount of expenses that will ultimately be incurred. We base our estimates on historical experience and on various other assumptions, as well as the specific circumstances surrounding these contingent liabilities, in evaluating the amount of liability that should be recorded. Additionally, the recognition of deferred tax assets requires estimates related to future income and other assumptions regarding timing and future profitability. Estimates may change as new events occur, additional information becomes available or operating environments change. Actual results may differ from our estimates.

[0000080420-18-000036:notes:155]
Cash and Investments

[0000080420-18-000036:notes:156]
Cash and cash equivalents, primarily funds held in money market savings instruments, are reported at their current carrying value which approximates fair value due to the short-term nature of these instruments and are included in cash and cash equivalents in our Consolidated Balance Sheets.

[0000080420-18-000036:notes:157]
Restricted Cash - Restricted cash includes cash and cash equivalents that are unavailable for withdrawal or usage for general obligations. Restricted cash on our Consolidated Balance Sheet represents a pledged cash collateral balance which is required under our amended credit agreement and is held in an interest-bearing savings account. See Note F for further discussion on restricted cash.

[0000080420-18-000036:notes:158]
Accounts Receivable

[0000080420-18-000036:notes:159]
Accounts receivable are stated net of allowances for doubtful accounts. We maintain and continually assess the adequacy of the allowance for doubtful accounts representing our estimate for losses resulting from the inability of our customers to pay amounts due to us. This estimated allowance is based on historical experience of uncollected accounts, the level of past due accounts, the overall level of outstanding accounts receivable, information about specific customers with respect to their inability to make payments and expectations of future conditions that could impact the collectability of accounts receivable. Future changes in our customers’ operating performance and cash flows, or in general economic conditions, could have an impact on their ability to fully pay these amounts, which could have a material impact on our operating results. In most cases, receivables are not collateralized. However, we utilize letters of credit to secure payment on projects when possible. At September 30, 2018 and 2017, we had retention amounts of $4.2 million and $2.1 million, respectively. Retention amounts are in accordance with applicable provisions of contracts and become due upon completion of contractual requirements. Of the retained amount at September 30, 2018, $3.8 million is expected to be collected in the next fiscal year and is recorded in accounts receivable. The remaining $0.4 million is recorded in other assets and will be collected in Fiscal 2020.

[0000080420-18-000036:notes:160]
Revenue Recognition

[0000080420-18-000036:notes:161]
Our revenues are primarily generated from the engineering and manufacturing of custom products under long-term contracts that may last from one month to several years, depending on the contract. Revenues from long-term contracts are recognized on the percentage-of-completion method of accounting. Occasionally a contract may require that we segment the project into specific deliverables for revenue recognition. Segmenting a contract may result in different interim rates of profitability for each scope of service than if we had recognized revenue on a combined basis.

[0000080420-18-000036:notes:162]
Under the percentage-of-completion method of accounting, revenues are recognized as work is performed. The revenue earned to date is calculated by multiplying the total contract price by the percentage of performance to date, which is based on total costs or total labor dollars incurred to date compared to the total estimated costs or total labor dollars estimated at completion. The method used to determine the percentage of completion is typically the cost method, unless the labor method is a more accurate method of measuring the progress of the project. Application of the percentage-of-completion method of accounting requires the use of estimates of costs to be incurred for the performance of the contract. Contract costs include all direct material costs, direct labor costs and those indirect costs related to contract performance, such as indirect labor, supplies, tools, repairs and all costs associated with operation of equipment. The cost estimation process is based upon the professional knowledge and experience of our engineers, project managers and financial professionals. Factors that are considered in estimating the work to be completed and ultimate contract recovery include the availability and productivity of labor, the nature and complexity of the work to be performed, the effect of change orders, the availability of materials, the effect of any delays on our project performance and the recoverability of any claims. Changes in job performance, job conditions, estimated profitability and final contract settlements, including our estimate of liquidated damages, if any, may result in revisions to costs and income, with their effects being recognized in the period in which the revisions are determined. Whenever revisions of estimated contract costs and contract values indicate that the contract costs will exceed estimated revenues, thus creating a loss, a provision for the total estimated loss is recorded in that period.

[0000080420-18-000036:notes:163]
Revenues associated with maintenance, repair and service contracts are recognized when the services are performed. Expenses related to these types of services are recognized as incurred.

[0000080420-18-000036:notes:164]
Warranty Costs

[0000080420-18-000036:notes:165]
We provide for estimated warranty costs with the recognition of revenue based upon historical rates applicable to individual product lines. In addition, specific provisions are made when the costs of such warranties are expected to exceed accruals. Our standard terms and conditions of sale include a warranty for parts and service for the earlier of 18 months from the date of shipment or 12 months from the date of energization, whichever occurs first. Occasionally projects require warranty terms that are longer than our standard terms due to the nature of the project. Extended warranty terms may be negotiated and included in our contracts. We use past experience and historical claims to determine the estimated liability. Actual results could differ from our estimate.

[0000080420-18-000036:notes:166]
Research and Development Expense

[0000080420-18-000036:notes:167]
Research and development activities are directed toward the development of new products and processes as well as improvements in existing products and processes. These costs, which primarily include salaries, contract services and supplies, are expensed as incurred. Such amounts were $6.7 million, $6.9 million and $6.7 million in Fiscal 2018, 2017 and 2016, respectively.

[0000080420-18-000036:notes:168]
We measure stock-based compensation cost at the grant date based on the fair value of the award. Compensation expense is recognized over the period during which the recipient is required to provide service in exchange for the awards, typically the vesting period. Excess income tax benefits related to share-based compensation expense is recognized as income tax expense or benefit in the Consolidated Statement of Operations. Cash paid when directly withholding shares on an employee's behalf for tax withholding purposes is classified as a financing activity. We account for forfeitures as they occur, rather than estimate expected forfeitures.


## us-gaap:SubsequentEventsTextBlock

[0000080420-18-000036:notes:169]
Subsequent Events

[0000080420-18-000036:notes:170]
On November 5, 2018, our Board of Directors declared a quarterly cash dividend on our common stock in the amount of $0.26 per share. The dividend is payable on December 19, 2018 to shareholders of record at the close of business on November 21, 201


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0000080420-18-000036:notes:171]
Detail of Selected Balance Sheet Accounts

[0000080420-18-000036:notes:172]
Allowance for Doubtful Accounts

[0000080420-18-000036:notes:173]
Cost and Estimated Earnings on Uncompleted Contracts

[0000080420-18-000036:notes:174]
There were no assets under capital lease as of September 30, 2018 or September 30, 2017. Depreciation expense was $12.7 million, $12.4 million and $13.0 million for fiscal years 2018, 2017, and 2016, respectively.

[0000080420-18-000036:notes:175]
Warranty Accrual
