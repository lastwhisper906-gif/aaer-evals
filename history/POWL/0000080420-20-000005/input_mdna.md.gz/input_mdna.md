# POWL MD&A — 0000080420-20-000005


## mdna

[0000080420-20-000005:mdna:1]
[same as prior period, unchanged from 0000080420-19-000024:mdna:1]

[0000080420-20-000005:mdna:2]
The following discussion and analysis of our financial condition and results of operations should be read in conjunction with the accompanying condensed consolidated financial statements and related notes included elsewhere in this Quarterly Report on Form 10-Q and with our Annual Report on Form 10-K for the year ended September 30, 2019, which was filed with the Securities and Exchange Commission (SEC) on December 5, 2019 and is available on the SEC’s website at www.sec.gov.

[0000080420-20-000005:mdna:3]
[same as prior period, unchanged from 0000080420-19-000024:mdna:3]

[0000080420-20-000005:mdna:4]
[same as prior period, unchanged from 0000080420-19-000024:mdna:4]

[0000080420-20-000005:mdna:5]
The markets in which we participate are capital-intensive and cyclical in nature. Cyclicality is predominantly driven by customer demand, global economic conditions and anticipated environmental, safety or regulatory changes which affect the manner in which our customers proceed with capital investments. Our customers analyze various factors including the demand and price for oil, gas and electrical energy, the overall economic and financial environment, governmental budgets, regulatory actions and environmental concerns. These factors influence the release of new capital projects by our customers, which are traditionally awarded in competitive bid situations. Scheduling of projects is matched to the customer requirements and projects typically take a number of months to produce. Schedules may change during the course of any particular project, and our operating results can, therefore, be impacted by factors outside of our control.

[0000080420-20-000005:mdna:6]
Within the industrial sector, specifically oil, gas and petrochemical, the demand for our electrical distribution solutions is very cyclical and highly correlated to the level of capital expenditures of our end user customers as well as prevailing global economic conditions. Substantial volatility in commodity prices in recent years has resulted in many of our industrial end user customers deferring, suspending or terminating capital expenditures, resulting in reduced volumes across the business.

[0000080420-20-000005:mdna:7]
More recently, the combination of a growing global economy and abundant sources of favorably priced natural gas feedstock are driving an increase in capital investment opportunities, specifically across the oil, gas and petrochemical sectors. We continue to see opportunities for natural gas related projects targeting growing global demand for cleaner burning fuels. Additionally, and in conjunction with growing global demand, projects within the domestic petrochemical sector are also benefiting from the low feedstock prices of natural gas.

[0000080420-20-000005:mdna:8]
[same as prior period, unchanged from 0000080420-19-000024:mdna:7]

[0000080420-20-000005:mdna:9]
Quarter Ended December 31, 2019 Compared to the Quarter Ended December 31, 2018 (Unaudited)

[0000080420-20-000005:mdna:10]
[same as prior period, unchanged from 0000080420-19-000024:mdna:9]

[0000080420-20-000005:mdna:11]
Revenues increased by 23%, or $24.8 million, to $134.2 million in the first quarter of Fiscal 2020, primarily due to improved market conditions in our petrochemical and oil and gas markets over the past few quarters. Domestic revenues increased by 18%, or $16.2 million, to $106.1 million in the first quarter of Fiscal 2020. International revenues increased by 44%, or $8.6 million, to $28.0 million in the first quarter of Fiscal 2020, primarily driven by increased activity in our international operations. Our international revenues include both revenues generated from our international facilities as well as revenues from export projects generated at our domestic facilities.

[0000080420-20-000005:mdna:12]
Revenue from our oil and gas markets increased by 21%, or $10.4 million, to $60.0 million in the first quarter of Fiscal 2020 while petrochemical revenue increased by 54%, or $10.6 million, to $30.4 million in the first quarter of Fiscal 2020 driven by the strength across the core oil and gas and petrochemical end markets. Revenues from utility markets increased by 20%, or $3.8 million, to $23.0 million and traction market revenues increased by 67%, or $3.3 million, to $8.4 million in the first quarter of Fiscal 2020, primarily driven by our mix of projects. Revenue from all other markets combined decreased by $3.4 million to $12.4 million in the first quarter of Fiscal 2020.

[0000080420-20-000005:mdna:13]
Gross profit increased by 49%, or $7.2 million, to $21.8 million, for the first quarter of Fiscal 2020 compared to the first quarter of Fiscal 2019. Gross profit as a percentage of revenues increased to 16% in the first quarter of Fiscal 2020, compared to 13% in the first quarter of Fiscal 2019 due to improved market conditions and efficiencies from increased volume in our domestic and international manufacturing facilities.

[0000080420-20-000005:mdna:14]
[same as prior period, unchanged from 0000080420-19-000024:mdna:13]

[0000080420-20-000005:mdna:15]
Selling, general and administrative expenses increased by 9%, or $1.4 million, to $17.3 million in the first quarter of Fiscal 2020, primarily due to increased personnel costs associated with increased project volume. Selling, general and administrative expenses, as a percentage of revenues, decreased to 13% during the first quarter of Fiscal 2020 compared to 15% in the first quarter of Fiscal 2019, primarily due to the increase in revenues and our continued focus on our cost structure.

[0000080420-20-000005:mdna:16]
Income Tax Provision/Benefit

[0000080420-20-000005:mdna:17]
We recorded an income tax provision of $0.6 million in the first quarter of Fiscal 2020, compared to an income tax benefit of $0.2 million in the first quarter of Fiscal 2019. The effective tax rate for the first quarter of Fiscal 2020 was 17%, compared to an effective tax rate of 8% in the first quarter of Fiscal 2019. For the three months ended December 31, 2019, the effective tax rate was favorably impacted by the R&D Tax Credit as well as the utilization of net operating loss carryforwards in Canada that were fully reserved with a valuation allowance while the effective tax rate for the three months ended December 31, 2018 was negatively impacted by Canadian losses recognized that were fully reserved with a valuation allowance.

[0000080420-20-000005:mdna:18]
[same as prior period, unchanged from 0000080420-19-000024:mdna:19]

[0000080420-20-000005:mdna:19]
In the first quarter of Fiscal 2020, net income of $2.8 million, or $0.24 per diluted share, improved from a net loss of $2.7 million, or $0.23 per diluted share, in the first quarter of Fiscal 2019, primarily due to improved market conditions and efficiencies from increased volume in our domestic and international manufacturing facilities.

[0000080420-20-000005:mdna:20]
[same as prior period, unchanged from 0000080420-19-000024:mdna:21]

[0000080420-20-000005:mdna:21]
The order backlog at December 31, 2019 was $425.9 million, a slight increase from the $419.0 million at September 30, 2019 and a 32% increase over the $322.0 million backlog at December 31, 2018. New orders decreased by 20% in the first quarter of Fiscal 2020 to $137.4 million, compared to $172.4 million in the first quarter of Fiscal 2019, due to the timing of select orders awarded in the first quarter of Fiscal 2019.

[0000080420-20-000005:mdna:22]
[same as prior period, unchanged from 0000080420-19-000024:mdna:38]

[0000080420-20-000005:mdna:23]
The markets in which we participate are capital-intensive and cyclical in nature. Cyclicality is predominantly driven by customer demand, global economic conditions and anticipated environmental, safety or regulatory changes which affect the manner in which our customers proceed with capital investments. Our customers analyze various factors including the demand and price for oil, gas and electrical energy, the overall economic and financial environment, governmental budgets, regulatory actions and environmental concerns. These factors influence the release of new capital projects by our customers, which are traditionally awarded in competitive bid situations. Scheduling of projects is matched to customer requirements, and projects typically take a number of months to produce. Schedules may change during the course of any particular project, and our operating results can, therefore, be impacted by factors outside of our control.

[0000080420-20-000005:mdna:24]
A significant portion of our revenues have historically been from the oil, gas and petrochemical markets. Oil and gas commodity price levels have been unstable over the last several years, and our customers delayed some of their major capital investment projects. Our customers' decisions to continue to invest in projects in our key oil and gas and petrochemical markets have been influenced somewhat by the stabilization of commodity prices and the increased global demand for cleaner burning fuels. We believe this change in market sentiment over recent quarters had a favorable impact on our orders and backlog. Specific to natural gas, the business was awarded a substantial contract in January 2020 that will support the integrated electrical distribution requirements for a large industrial complex being built in the United States. This specific project will take over three years to design, manufacture, integrate, test and ship.

[0000080420-20-000005:mdna:25]
Our operating results have been impacted by factors such as the timing of new order awards, customer approval of final engineering and design specifications and delays in customer construction schedules, all of which contribute to short-term earnings variability and the timing of project execution. Our operating results also have been, and could continue to be, impacted by the timing and resolution of change orders, project close-out and resolution of potential contract claims and liquidated damages, all of which could improve or deteriorate gross margins during the period in which these items are resolved with our customers. These factors may result in periods of underutilization of our resources and facilities and negatively impact our ability to cover our fixed costs.  The increased orders in Fiscal 2018 and 2019 have led to improvement in revenues and operating results that we anticipate will continue throughout Fiscal 2020. We continue to focus on maintaining our cash position, improving efficiencies in production and investing in future business opportunities and research and development. We also continue to monitor the factors that drive our markets and will continue to strive to maintain our leadership and competitive advantage in the markets we serve while aligning our cost structure with market conditions.

[0000080420-20-000005:mdna:26]
[same as prior period, unchanged from 0000080420-19-000024:mdna:44]

[0000080420-20-000005:mdna:27]
As of December 31, 2019, current assets exceeded current liabilities by 2.1 times and our debt to total capitalization was 0.26%.

[0000080420-20-000005:mdna:28]
Cash, cash equivalents and short-term investments decreased to $121.0 million at December 31, 2019, compared to $124.7 million at September 30, 2019. Our increase in project volume typically requires cash to fund operations. We believe that our strong working capital position, available borrowings under our credit facility (U.S. Revolver) and available cash should be sufficient to finance future operating activities, capital improvements, research and development initiatives and debt repayments for the foreseeable future.

[0000080420-20-000005:mdna:29]
Our U.S. Revolver is a $75.0 million revolving credit facility, which is available for both borrowings and letters of credit. As of December 31, 2019, there were no amounts borrowed under this facility, and letters of credit outstanding were $13.4 million. As of December 31, 2019, $61.6 million was available for the issuance of letters of credit and borrowing under the U.S. Revolver. Total long-term debt, including current maturities, totaled $0.8 million at December 31, 2019 related to outstanding industrial development revenue bonds. For further information regarding our debt, see Note E of Notes to Condensed Consolidated Financial Statements.

[0000080420-20-000005:mdna:30]
Approximately $21.8 million of our cash and cash equivalents at December 31, 2019 was held outside of the U.S. for international operations. It is our intention to indefinitely reinvest all current and future foreign earnings internationally in order to ensure sufficient working capital to support our international operations. In the event that we elect to repatriate some or all of the foreign earnings that were previously deemed to be indefinitely reinvested outside the U.S., we may incur additional tax expense upon such repatriation under current tax laws.

[0000080420-20-000005:mdna:31]
[same as prior period, unchanged from 0000080420-19-000024:mdna:49]

[0000080420-20-000005:mdna:32]
Operating activities provided net cash of $2.1 million during the three months ended December 31, 2019 and $9.1 million during the same period in Fiscal 2019. Cash flow from operations is primarily influenced by project volume, the timing of milestone payments from our customers and the payment terms with our suppliers. This decrease in operating cash flow was primarily due to the receipt of a $6.6 million income tax refund during the three months ended December 31, 2018.

[0000080420-20-000005:mdna:33]
[same as prior period, unchanged from 0000080420-19-000024:mdna:51]

[0000080420-20-000005:mdna:34]
Investing activities provided $3.7 million during the three months ended December 31, 2019 compared to $5.0 million during the same period in Fiscal 2019. The decrease in cash provided by investing activities in Fiscal 2020 was primarily due to an increase in the purchases of plant, property and equipment to $2.4 million in Fiscal 2020 and is primarily related to our increase in project activity.

[0000080420-20-000005:mdna:35]
[same as prior period, unchanged from 0000080420-19-000024:mdna:53]

[0000080420-20-000005:mdna:36]
Net cash used in financing activities was $4.0 million during the three months ended December 31, 2019 and $4.1 million during the same period in Fiscal 2019, which primarily consisted of approximately $3.0 million of dividends paid in each period.

[0000080420-20-000005:mdna:37]
[same as prior period, unchanged from 0000080420-19-000024:mdna:55]

[0000080420-20-000005:mdna:38]
[same as prior period, unchanged from 0000080420-19-000024:mdna:56]

[0000080420-20-000005:mdna:39]
[same as prior period, unchanged from 0000080420-19-000024:mdna:57]

[0000080420-20-000005:mdna:40]
The discussion and analysis of our financial condition and results of operations are based on our condensed consolidated financial statements, which have been prepared in accordance with U.S. GAAP. The preparation of these condensed consolidated financial statements requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities, disclosures of contingent assets and liabilities known to exist at the date of the condensed consolidated financial statements and the reported amounts of revenues and expenses during the reporting period. We evaluate our estimates on an ongoing basis, based on historical experience and on various other assumptions that are believed to be reasonable under the circumstances. There can be no assurance that actual results will not differ from those estimates.

[0000080420-20-000005:mdna:41]
Effective October 1, 2019, we adopted the new lease accounting standard which resulted in changes to our lease policy. See Note I of Notes to Condensed Consolidated Financial Statements for information on the new lease accounting guidance and related disclosures. There have been no other material changes to our critical accounting policies as disclosed in our Annual Report on Form 10-K for the year ended September 30, 2019.
