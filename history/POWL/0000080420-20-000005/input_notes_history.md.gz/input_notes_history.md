# POWL note change history — 0000080420-19-000024 → 0000080420-20-000005


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- added (2020-02-05):
[0000080420-20-000005:note_history:1]
Certain customers require us to post letters of credit, bank guarantees or surety bonds. These security instruments assure that we will perform under the terms of our contract. In the event of default, the counterparty may demand payment from the bank under a letter of credit or bank guarantee, or performance by the surety under a bond. To date, there have been no significant draws or claims related to security instruments for the periods reported. We were contingently liable for letters of credit of $13.4 million as of December 31, 2019. We also had surety bonds totaling $180.0 million that were outstanding, with additional bonding capacity of $570.0 million available, at December 31, 2019.

- changed (2020-02-05):
[0000080420-20-000005:note_history:2]
We have an $11.9 million facility agreement (Facility Agreement) between Powell (UK) Limited and a large international bank that provides Powell (UK) Limited the ability to enter into bank guarantees as well as forward exchange contracts and currency options. At December 31, 2019, we had outstanding guarantees totaling $5.2 million and amounts available under this Facility Agreement were $6.7 million. The Facility Agreement expires in May 2020 and provides for financial covenants and customary events of default, and carries cross-default provisions with our U.S. Revolver. If an event of default (as defined in the Facility Agreement) occurs and is continuing, per the terms and subject to the conditions set forth therein, obligations outstanding under the Facility Agreement may be accelerated and declared immediately due and payable. As of December 31, 2019, we were in compliance with all of the financial covenants of the Facility Agreement.
  (was, 2019-08-07, similarity 0.9283):
[0000080420-19-000024:note_history:2]
Additionally, we have a $6.3 million facility agreement (Facility Agreement) between Powell (UK) Limited and a large international bank. This Facility Agreement provides Powell (UK) Limited the ability to enter into bank guarantees as well as forward exchange contracts and currency options. At June 30, 2019, we had outstanding guarantees totaling $3.7 million under this Facility Agreement and amounts available under this Facility Agreement were $2.6 million. The Facility Agreement provides for financial covenants and customary events of default, and carries cross-default provisions with our U.S. Revolver. If an event of default (as defined in the Facility Agreement) occurs and is continuing, per the terms and subject to the conditions set forth therein, obligations outstanding under the Facility Agreement may be accelerated and declared immediately due and payable. As of June 30, 2019, we were in compliance with all of the financial covenants of the Facility Agreement.

- removed (2020-02-05):
[0000080420-19-000024:note_history:3]
Certain customers require us to post letters of credit or surety bonds which assure that we will perform under the terms of our contract. In the event of default, the counterparty may demand payment from the bank under a letter of credit or performance by the surety under a bond. To date, there have been no significant expenses related to either letters of credit or surety bonds for the periods reported. We were contingently liable for letters of credit of $11.8 million as of June 30, 2019. We also had surety bonds totaling $152.9 million that were outstanding, with additional bonding capacity of $597.1 million available, at June 30, 2019.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureAndSignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2020-02-05):
[0000080420-20-000005:note_history:4]
We develop, design, manufacture and service custom-engineered equipment and systems for the distribution, control and monitoring of electrical energy. Headquartered in Houston, Texas, we serve the oil and gas markets, including onshore and offshore oil and gas production, pipeline, refining and liquid natural gas terminals, as well as petrochemical, electric utility, light rail traction power and other heavy industrial markets.
  (was, 2019-08-07, similarity 0.9803):
[0000080420-19-000024:note_history:4]
We develop, design, manufacture and service custom-engineered products and systems for the distribution, control and monitoring of electrical energy. Headquartered in Houston, Texas, we serve the oil and gas markets, including onshore and offshore oil and gas production, pipeline, refining and liquid natural gas terminals, as well as petrochemical, electric utility, light rail traction power and other heavy industrial markets.

- changed (2020-02-05):
[0000080420-20-000005:note_history:5]
The preparation of condensed consolidated financial statements in conformity with accounting principles generally accepted in the United States (U.S. GAAP) requires management to make estimates and assumptions that affect the amounts reported in the condensed consolidated financial statements and accompanying footnotes. The most significant estimates used in our condensed consolidated financial statements affect revenue recognition and estimated cost recognition on our customer contracts, the allowance for doubtful accounts, provision for excess and obsolete inventory, warranty accruals and income taxes. The amounts recorded for warranties, legal, income taxes, impairment of long-lived assets (when applicable) and other contingent liabilities require judgments regarding the amount of expenses that will ultimately be incurred. We base our estimates on historical experience and on various other assumptions, as well as the specific circumstances surrounding these contingent liabilities, in evaluating the amount of liability that should be recorded. Additionally, the recognition of deferred tax assets requires estimates related to future income and other assumptions regarding timing and future profitability because the ultimate realization of net deferred tax assets is dependent on the generation of future taxable income during the periods in which temporary differences become deductible. Estimates routinely change as new events occur, additional information becomes available or operating environments change. Actual results may differ from our prior estimates.
  (was, 2019-08-07, similarity 0.9794):
[0000080420-19-000024:note_history:5]
The preparation of condensed consolidated financial statements in conformity with U.S. GAAP requires management to make estimates and assumptions that affect the amounts reported in the condensed consolidated financial statements and accompanying footnotes. The most significant estimates used in our condensed consolidated financial statements affect revenue recognition and estimated cost recognition on our customer contracts, the allowance for doubtful accounts, provision for excess and obsolete inventory, warranty accruals and income taxes. The amounts recorded for warranties, legal, income taxes, impairment of long-lived assets (when applicable) and other contingent liabilities require judgments regarding the amount of expenses that will ultimately be incurred. We base our estimates on historical experience and on various other assumptions, as well as the specific circumstances surrounding these contingent liabilities, in evaluating the amount of liability that should be recorded. Additionally, the recognition of deferred tax assets requires estimates related to future income and other assumptions regarding timing and future profitability because the ultimate realization of net deferred tax assets is dependent on the generation of future taxable income during the periods in which temporary differences become deductible. Estimates routinely change as new events occur, additional information becomes available or operating environments change. Actual results may differ from our prior estimates.

- added (2020-02-05):
[0000080420-20-000005:note_history:6]
Effective October 1, 2019, we adopted the new lease accounting standard and recorded operating lease assets and operating lease liabilities of approximately $7.0 million and determined that no adjustment to retained earnings was necessary. Financial results for reporting periods after October 1, 2019 are reported under the new standard; however financial results for prior periods were not adjusted and will continue to be presented in accordance with the previous standard. Upon adoption, we elected a package of practical expedients which, among other things, allowed for the historical classification of our existing leases to carryforward. Additionally, we elected to separate non-lease components for our real estate and IT infrastructure asset classes.  All other asset classes account for both lease and non-lease components in the operating lease asset and operating lease liability calculations. See Note I for further discussion of leases.

- removed (2020-02-05):
[0000080420-19-000024:note_history:7]
In May 2014, the Financial Accounting Standards Board (FASB) issued a new standard on revenue recognition that supersedes previously issued revenue recognition guidance. This standard provides a five-step approach to be applied to all contracts with customers and requires expanded disclosures about the nature, amount, timing and uncertainty of revenue (and the related cash flows) arising from customer contracts, significant judgments and changes in judgments used in applying the revenue model and the assets recognized from costs incurred to obtain or fulfill a contract. Effective October 1, 2018, we adopted this standard using the modified retrospective basis. After evaluating the impact of this new standard on contracts outstanding as of October 1, 2018, we determined that no adjustment to retained earnings was necessary. See Note D for further discussion of revenue.

- removed (2020-02-05):
[0000080420-19-000024:note_history:8]
In February 2016, the FASB issued a new topic on leases which requires lessees to recognize lease assets and lease liabilities on the balance sheet for all leases with terms longer than twelve months. Leases will be classified as either finance or operating, with classification affecting the pattern of expense recognition in the income statement. A modified retrospective transition approach is required for lessees for capital and operating leases existing at, or entered into after, the beginning of the earliest comparative period presented in the financial statements, with certain practical expedients available. The new topic is effective for fiscal years beginning after December 15, 2018, including interim periods within those fiscal years. This would be our fiscal year ending September 30, 2020. In Fiscal 2018, we acquired new lease software designed to assist with our compliance of this new topic. We are still evaluating the impact this new topic will have on our consolidated financial position and results of operations.

- removed (2020-02-05):
[0000080420-19-000024:note_history:9]
In November 2016, the FASB issued a new topic on the statement of cash flows that changes the presentation of restricted cash and cash equivalents on the statement of cash flows. Restricted cash and restricted cash equivalents is to be included with cash and cash equivalents when reconciling the beginning-of-period and end-of-period total amounts shown on the statement of cash flows. We adopted this topic in Fiscal 2019 and our Condensed Consolidated Cash Flow Statements for all periods reflect this presentation.

- removed (2020-02-05):
[0000080420-19-000024:note_history:10]
In May 2017, the FASB issued a new topic on modification accounting with regards to stock based compensation. This new topic clarifies when a change to the terms or conditions of a share-based payment award should be accounted for as a modification. An entity should account for the effects of a modification unless the fair value, vesting conditions and classification, as an equity instrument or a liability instrument, of the modified award are the same before and after a change to the terms or conditions of the share-based payment award. We adopted this topic in Fiscal 2019 and it has not had a material impact on our consolidated financial position or results of operations.


## us-gaap:LongTermDebtTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2020-02-05):
[0000080420-20-000005:note_history:11]
|  | December 31, 2019 |  | September 30, 2019 |
| Industrial development revenue bonds | $ | 800 |  |  | $ | 1,200 |  |
| Less: current portion | (400 | ) |  | (400 | ) |
| Total long-term debt | $ | 400 |  |  | $ | 800 |  |
  (was, 2019-08-07, similarity 0.971):
[0000080420-19-000024:note_history:11]
|  | June 30, 2019 |  | September 30, 2018 |
| Industrial development revenue bonds | $ | 1,200 |  |  | $ | 1,600 |  |
| Less current portion | (400 | ) |  | (400 | ) |
| Total long-term debt | $ | 800 |  |  | $ | 1,200 |  |

- added (2020-02-05):
[0000080420-20-000005:note_history:12]
On September 27, 2019, we entered into an Amended and Restated Credit Agreement with Bank of America, N.A. (the " "U.S. Revolver"), which replaced our prior credit agreement. The U.S. Revolver is a $75.0 million revolving credit facility, that is available for both borrowings and letters of credit and expires September 2024. As of December 31, 2019, there were no amounts borrowed under this facility and letters of credit outstanding were $13.4 million. There was $61.6 million available for the issuance of letters of credit and borrowings under the U.S. Revolver as of December 31, 2019.

- added (2020-02-05):
[0000080420-20-000005:note_history:13]
We are required to maintain certain financial covenants, the most significant of which are a consolidated leverage ratio less than 3.0 to 1.0 and a consolidated interest coverage ratio of greater than 3.0 to 1.0. Additionally, we must maintain a consolidated cash balance of $30 million at all times. The U.S. Revolver also contains a "material adverse effect" clause which is a material change in our operations, business, properties, liabilities or condition (financial or otherwise) or a material impairment of our ability to perform our obligations under our credit agreements. As of December 31, 2019, we were in compliance with all of the financial covenants of the U.S. Revolver.

- added (2020-02-05):
[0000080420-20-000005:note_history:14]
The U.S. Revolver allows the Company to elect that any borrowing under the facility bear an interest rate based on either the base rate or the eurocurrency rate, in each case, plus the applicable rate. The base rate is generally the highest of (a) the federal funds rate plus 0.50%, (b) the Bank of America prime rate or (c) the London Interbank Offered Rate ("LIBOR") plus 1.00%. The applicable rate is generally a range from (0.25)% to 1.75% depending on the type of loan and the Company's consolidated leverage ratio.

- changed (2020-02-05):
[0000080420-20-000005:note_history:15]
The U.S. Revolver is collateralized by a pledge of 100% of the voting capital stock of each of our domestic subsidiaries and 65% of the voting capital stock of each non-domestic subsidiary. The U.S. Revolver provides for customary events of default and carries cross-default provisions with other existing debt agreements. If an event of default (as defined in the U.S. Revolver) occurs and is continuing, on the terms and subject to the conditions set forth in the U.S. Revolver, amounts and letters of credit outstanding under the U.S. Revolver may be accelerated and may become immediately due and payable.
  (was, 2019-08-07, similarity 0.6822):
[0000080420-19-000024:note_history:15]
The U.S. Revolver is collateralized by a pledge of 100% of the voting capital stock of each of our domestic subsidiaries and 65% of the voting capital stock of each non-domestic subsidiary. The U.S. Revolver provides for customary events of default and carries cross-default provisions with other existing debt agreements. If an event of default (as defined in the U.S. Revolver) occurs and is continuing, on the terms and subject to the conditions set forth in the U.S. Revolver, amounts outstanding under the U.S. Revolver may be accelerated and may become immediately due and payable. It also contains financial covenants defining various financial measures and the levels of these measures with which we must comply, as well as a “material adverse change” clause. A “material adverse change” is defined as a material change in our operations, business, properties, liabilities or condition (financial or otherwise) or a material impairment of our ability to perform our obligations under our credit agreements. As of June 30, 2019, we were in compliance with all of the financial covenants of the U.S. Revolver.

- changed (2020-02-05):
[0000080420-20-000005:note_history:16]
We borrowed $8.0 million in October 2001 through a loan agreement funded with proceeds from tax-exempt industrial development revenue bonds (Bonds). These Bonds were issued by the Illinois Development Finance Authority and were used for the completion of our Northlake, Illinois facility. Pursuant to the Bond issuance, a reimbursement agreement between us and a major domestic bank required an issuance by the bank of an irrevocable direct-pay letter of credit (Bond LC), as collateral, to the Bonds’ trustee to guarantee payment of the Bonds’ principal and interest when due. The Bond LC is subject to both early termination and extension provisions customary to such agreements, as well as various covenants, for which we were in compliance at December 31, 2019. While the Bonds mature in 2021, the reimbursement agreement requires annual redemptions of $0.4 million that commenced on October 25, 2002. A sinking fund is used for the annual principal payment. The Bonds bear interest at a floating rate determined weekly by the Bonds’ remarketing agent, which was the underwriter for the Bonds and is an affiliate of the bank. This interest rate was 1.79% as of December 31, 2019.
  (was, 2019-08-07, similarity 0.969):
[0000080420-19-000024:note_history:16]
We borrowed $8.0 million in October 2001 through a loan agreement funded with proceeds from tax-exempt industrial development revenue bonds (Bonds). These Bonds were issued by the Illinois Development Finance Authority and were used for the completion of our Northlake, Illinois facility. Pursuant to the Bond issuance, a reimbursement agreement between us and a major domestic bank required an issuance by the bank of an irrevocable direct-pay letter of credit (Bond LC), as collateral, to the Bonds’ trustee to guarantee payment of the Bonds’ principal and interest when due. The Bond LC is subject to both early termination and extension provisions customary to such agreements, as well as various covenants, for which we were in compliance at June 30, 2019. While the Bonds mature in 2021, the reimbursement agreement requires annual redemptions of $0.4 million that commenced on October 25, 2002. A sinking fund is used for the redemption of the Bonds. The Bonds bear interest at a floating rate determined weekly by the Bonds’ remarketing agent, which was the underwriter for the Bonds and is an affiliate of the bank. This interest rate was 2.03% as of June 30, 2019.

- removed (2020-02-05):
[0000080420-19-000024:note_history:17]
We have a $75.0 million revolving credit facility (U.S. Revolver) to provide working capital support and letters of credit which expires in June 2022. The amount available under the U.S. Revolver at June 30, 2019 was reduced by $11.8 million for our outstanding letters of credit. Currently, our U.S. Revolver can only be used for letters of credit until we meet certain financial ratios. There were no loans outstanding under the U.S. Revolver as of June 30, 2019.

- removed (2020-02-05):
[0000080420-19-000024:note_history:18]
Per the terms of the U.S. Revolver, we are required to maintain cash in a pledged collateral account until we satisfy the following two financial ratios for two consecutive fiscal quarters: a max leverage ratio and a fixed charge coverage ratio. The max leverage ratio requires that the ratio of our consolidated funded indebtedness to our consolidated earnings before interest, taxes and depreciation (EBITDA) for the last four consecutive quarters not exceed 2.75 to 1.00. The fixed charge coverage ratio requires that the ratio of consolidated EBITDA for the last four fiscal quarters, less income taxes, capital expenditures, dividends, principal debt payments and interest charges be at least 1.25 to 1.00. If we are not in compliance with the these two ratios, we are required to maintain a cash balance in a pledged cash collateral account equal to 102% of the outstanding amount of any loans and letter of credit obligations until we meet the aforementioned required ratios. As of June 30, 2019, the balance in the cash collateral account was $16.7 million and is recorded as restricted cash in our Condensed Consolidated Balance Sheets. The portion of the cash collateral associated with the outstanding letters of credit that are due to expire beyond twelve months has been classified as non-current restricted cash on our condensed consolidated balance sheets. As of June 30, 2019, there was $63.2 million available for the issuance of letters of credit under the U.S. Revolver, subject to the cash collateral requirements mentioned above.

- removed (2020-02-05):
[0000080420-19-000024:note_history:19]
The interest rate for amounts outstanding under the U.S. Revolver is a floating rate based upon the higher of the Federal Funds Rate plus 0.5%, the bank’s prime rate, or the Eurocurrency rate plus 1.00%. Once the applicable rate is determined, a margin ranging up to 1.25% is added to the applicable rate.


## us-gaap:ScheduleOfDebtInstrumentsTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2020-02-05):
[0000080420-20-000005:note_history:20]
|  | December 31, 2019 |  | September 30, 2019 |
| Industrial development revenue bonds | $ | 800 |  |  | $ | 1,200 |  |
| Less: current portion | (400 | ) |  | (400 | ) |
| Total long-term debt | $ | 400 |  |  | $ | 800 |  |
  (was, 2019-08-07, similarity 0.971):
[0000080420-19-000024:note_history:20]
|  | June 30, 2019 |  | September 30, 2018 |
| Industrial development revenue bonds | $ | 1,200 |  |  | $ | 1,600 |  |
| Less current portion | (400 | ) |  | (400 | ) |
| Total long-term debt | $ | 800 |  |  | $ | 1,200 |  |


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2020-02-05):
[0000080420-20-000005:note_history:21]
The following tables present our disaggregated revenue by geographic destination and market sector for the three months ended December 31, 2019 and 2018 (in thousands):
  (was, 2019-08-07, similarity 0.9216):
[0000080420-19-000024:note_history:21]
The following tables present our disaggregated revenue by geographic destination and market sector for the three and nine months ended June 30, 2019 (in thousands):

- changed (2020-02-05):
[0000080420-20-000005:note_history:22]
|  | Three months ended December 31, 2019 |  | Three months ended December 31, 2018 |
| United States | $ | 107,078 |  |  | $ | 89,898 |  |
| Canada | 14,454 |  |  | 9,715 |  |
| Europe, Middle East and Africa | 10,166 |  |  | 5,441 |  |
| Asia/Pacific | 1,686 |  |  | 3,744 |  |
| Mexico, Central and South America | 766 |  |  | 553 |  |
| Total revenues by geographic destination | $ | 134,150 |  |  | $ | 109,351 |  |
  (was, 2019-08-07, similarity 0.8812):
[0000080420-19-000024:note_history:22]
|  | Three months ended June 30, 2019 |  | Nine months ended June 30, 2019 |
| United States | $ | 99,745 |  |  | $ | 292,049 |  |
| Canada | 20,206 |  |  | 45,015 |  |
| Europe, Middle East and Africa | 9,659 |  |  | 20,608 |  |
| Asia/Pacific | 4,682 |  |  | 9,155 |  |
| Mexico, Central and South America | 1,296 |  |  | 1,849 |  |
| Total revenues by geographic destination | $ | 135,588 |  |  | $ | 368,676 |  |

- changed (2020-02-05):
[0000080420-20-000005:note_history:23]
|  | Three months ended December 31, 2019 |  | Three months ended December 31, 2018 |
| Oil and gas | $ | 59,994 |  |  | $ | 49,576 |  |
| Petrochemical | 30,426 |  |  | 19,778 |  |
| Electric utility | 23,015 |  |  | 19,258 |  |
| Traction power | 8,351 |  |  | 5,009 |  |
| All others | 12,364 |  |  | 15,730 |  |
| Total revenues by market sector | $ | 134,150 |  |  | $ | 109,351 |  |
  (was, 2019-08-07, similarity 0.8654):
[0000080420-19-000024:note_history:23]
|  | Three months ended June 30, 2019 |  | Nine months ended June 30, 2019 |
| Oil and gas | $ | 62,356 |  |  | $ | 167,954 |  |
| Petrochemical | 21,086 |  |  | 63,387 |  |
| Electric utility | 26,425 |  |  | 66,066 |  |
| Traction power | 7,423 |  |  | 18,457 |  |
| All others | 18,298 |  |  | 52,812 |  |
| Total revenues by market sector | $ | 135,588 |  |  | $ | 368,676 |  |


## us-gaap:RevenueFromContractWithCustomerPolicyTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2020-02-05):
[0000080420-20-000005:note_history:24]
Contracts may be modified for changes in contract specifications and requirements. We consider contract modifications to exist when the modification either creates new or changes the enforceable rights and obligations under the contract. Most of our contract modifications are for goods and services that are not distinct from the existing performance obligation. Contract modifications result in a cumulative catch-up adjustment to revenue based on our measure of progress for the performance obligation.
  (was, 2019-08-07, similarity 0.998):
[0000080420-19-000024:note_history:24]
Contracts may be modified for changes in contract specifications and requirements. We consider contract modifications to exist when the modification either creates new or changes the enforceable rights and obligations under the contract. Most of our contract modifications are for goods and services that are not distinct from the existing performance obligation. Contract modifications result in a cumulative catch up adjustment to revenue based on our measure of progress for the performance obligation.

- changed (2020-02-05):
[0000080420-20-000005:note_history:25]
Contract assets are recorded when revenues are recognized in excess of amounts billed for fixed-price contracts as determined by the billing milestone schedule. Contract assets are transferred to accounts receivables when billing milestones have been met, or we have an unconditional right to payment.
  (was, 2019-08-07, similarity 0.8511):
[0000080420-19-000024:note_history:25]
Contract assets, previously referred to as costs and estimated earnings in excess of billings on uncompleted contracts, are recorded when revenues are recognized in excess of amounts billed for fixed-price contracts as determined by the billing milestone schedule. Contract assets are transferred to accounts receivables when billing milestones have been met or we have an unconditional right to payment.

- changed (2020-02-05):
[0000080420-20-000005:note_history:26]
Contract liabilities typically represent advance payments from contractual billing milestones and billings in excess of revenue recognized. It is unusual to have advanced milestone payments with a term greater than one year, which could represent a financing component on the contract.
  (was, 2019-08-07, similarity 0.6409):
[0000080420-19-000024:note_history:26]
Contract liabilities, previously referred to as billings in excess of costs and estimated earnings on uncompleted contracts, typically represent advance payments from contractual billing milestones and billings in excess of revenue recognized. It is unusual to have advanced milestone payments with a term greater than one year, which could represent a financing component on the contract.

- changed (2020-02-05):
[0000080420-20-000005:note_history:27]
A performance obligation is a promise in a contract or with a customer to transfer a distinct good or service. A contract’s transaction price is allocated to each distinct performance obligation and recognized as revenue as the performance obligations are satisfied. To determine the proper revenue recognition for contracts, we evaluate whether a contract should be accounted for as more than one performance obligation or, less commonly, whether two or more contracts should be combined and accounted for as one performance obligation.  This evaluation of performance obligations requires significant judgment.  The majority of our contracts have a single performance obligation where multiple engineered products and services are combined into a single custom-engineered solution. Our contracts generally include a standard assurance warranty that typically ends 18 months after shipment. Occasionally, we provide service-type warranties that will extend the warranty period. These extended warranties qualify as a separate performance obligation, and revenue is deferred and recognized over the warranty period. If we determine during the evaluation of the contract that there are multiple performance obligations, we allocate the transaction price to each performance obligation using our best estimate of the standalone selling price of each distinct good or service in the contract.
  (was, 2019-08-07, similarity 0.772):
[0000080420-19-000024:note_history:27]
A performance obligation is a promise in a contract or with a customer to transfer a distinct good or service. A contract’s transaction price is allocated to each distinct performance obligation and recognized as revenue as the performance obligations are satisfied. To determine the proper revenue recognition for contracts, we evaluate whether a contract should be accounted for as more than one performance obligation or, less commonly, whether two or more contracts should be combined and accounted for as one performance obligation.  This evaluation of performance obligations requires significant judgement.  The majority of our contracts have a single performance obligation where multiple engineered products and services are combined into a single custom engineered solution. Our contracts generally include a standard assurance warranty that typically ends eighteen months after shipment. Occasionally, we provide service-type warranties that will extend the warranty period. These extended warranties qualify as a separate performance obligation. If we determine during the evaluation of the contract that there are multiple performance obligations, we allocate the transaction price to each performance obligation using our best estimate of the standalone selling price of each distinct good or service in the contract.

- changed (2020-02-05):
[0000080420-20-000005:note_history:28]
The majority of our revenues are generated from the manufacturing of custom-engineered products and systems under long-term fixed-price contracts under which we agree to manufacture various products such as traditional and arc-resistant distribution switchgear and control gear, medium-voltage circuit breakers, monitoring and control communications systems, motor control centers and bus duct systems. These products may be sold separately as an engineered solution, but are typically integrated into custom-built enclosures which we also build.  These enclosures are referred to as power control room substations (PCRs®), custom-engineered modules or electrical houses (E-Houses). Some contracts may also include the installation and the commissioning of these enclosures.
  (was, 2019-08-07, similarity 0.9431):
[0000080420-19-000024:note_history:28]
The majority of our revenues are generated from the manufacturing of custom engineered products and systems under long-term fixed price contracts under which we agree to manufacture various products such as traditional and arc-resistant distribution switchgear and control gear, medium-voltage circuit breakers, monitoring and control communications systems, motor control centers and bus duct systems. These products may be sold separately as an engineered solution, but are typically integrated into custom-built enclosures which we also build.  These enclosures are referred to as power control room substations (PCRs®), custom-engineered modules or electrical houses (E-Houses). Some contracts may also include the installation and the commissioning of these enclosures.

- added (2020-02-05):
[0000080420-20-000005:note_history:29]
Revenue from these contracts is generally recognized over time utilizing the cost-to-cost method to measure the extent of progress toward the completion of the performance obligation and the recognition of revenue over time. We believe that this method is the most accurate representation of our performance, because it directly measures the value of the services transferred to the customer over time as we incur costs on our contracts.  Contract costs include all direct materials, labor, and indirect costs related to contract performance, which may include indirect labor, supplies, tools, repairs and depreciation costs.

- changed (2020-02-05):
[0000080420-20-000005:note_history:30]
We also have contracts to provide value-added services such as field service inspection, installation, commissioning, modification and repair, as well as retrofit and retrofill components for existing systems.  As a practical expedient, if the service contract terms give us the right to invoice the customer for an amount that corresponds directly with the value of our performance completed to date (i.e., a service contract in which we bill a fixed amount for each hour of service provided), then we recognize revenue over time in each reporting period corresponding to the amount with which we have the right to invoice.  Our performance obligations are satisfied as the work progresses. Revenues from our custom-engineered products and value-added services transferred to customers over time accounted for approximately 95% and 93% of total revenues for the three months ended December 31, 2019 and 2018, respectively.
  (was, 2019-08-07, similarity 0.9207):
[0000080420-19-000024:note_history:30]
We also have contracts to provide value-added services such as field service inspection, installation, commissioning, modification and repair, as well as retrofit and retrofill components for existing systems.  As a practical expedient, if the service contract terms give us the right to invoice the customer for an amount that corresponds directly with the value of our performance completed to date (i.e., a service contract in which we bill a fixed amount for each hour of service provided), then we recognize revenue over time in each reporting period corresponding to the amount with which we have the right to invoice.  Our performance obligations are satisfied as the work progresses. Revenues from our custom-engineered products and value-added services transferred to customers over time accounted for approximately 93% of total revenues for both the three and nine months ended June 30, 2019.

- changed (2020-02-05):
[0000080420-20-000005:note_history:31]
We also have sales orders for spare parts and replacement circuit breakers for switchgear that are obsolete or that are no longer produced by the original manufacturer. Revenues from these sales orders are recognized at the time we fulfill our performance obligation to the customer, which is typically upon shipment and represented approximately 5% and 7% of total revenues for the three months ended December 31, 2019 and 2018, respectively.
  (was, 2019-08-07, similarity 0.7506):
[0000080420-19-000024:note_history:31]
We also have sales orders for spare parts and replacement circuit breakers for switchgear that are obsolete or that are no longer produced by the original manufacturer. Revenues from these sales orders are recognized at a point in time when we fulfill our performance obligation to the customer which is typically upon shipment. Revenue related to sales orders represents approximately 7% of total revenues for both the three and nine months ended June 30, 2019.

- removed (2020-02-05):
[0000080420-19-000024:note_history:32]
On October 1, 2018, we adopted the new revenue recognition standard using the modified retrospective transition method. We applied the guidance to customer contracts which were not substantially complete at that time and we determined that no adjustment to retained earnings was necessary. Financial results for reporting periods after October 1, 2018 are reported under the new guidance; however financial results for prior periods were not adjusted and will continue to be presented in accordance with the previous guidance.

- removed (2020-02-05):
[0000080420-19-000024:note_history:33]
Revenue from these contracts is generally recognized over time utilizing the cost to cost method to measure the extent of progress toward the completion of the performance obligation and the recognition of revenue over time. We believe that this method is the most accurate representation of our performance because it directly measures the value of the services transferred to the customer over time as we incur costs on our contracts.  Contract costs include all direct materials, labor, and indirect costs related to contract performance which may include indirect labor, supplies, tools, repairs and depreciation costs.


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2020-02-05):
[0000080420-20-000005:note_history:34]
The majority of our revenues are generated from the manufacturing of custom-engineered products and systems under long-term fixed-price contracts under which we agree to manufacture various products such as traditional and arc-resistant distribution switchgear and control gear, medium-voltage circuit breakers, monitoring and control communications systems, motor control centers and bus duct systems. These products may be sold separately as an engineered solution, but are typically integrated into custom-built enclosures which we also build.  These enclosures are referred to as power control room substations (PCRs®), custom-engineered modules or electrical houses (E-Houses). Some contracts may also include the installation and the commissioning of these enclosures.
  (was, 2019-08-07, similarity 0.9431):
[0000080420-19-000024:note_history:34]
The majority of our revenues are generated from the manufacturing of custom engineered products and systems under long-term fixed price contracts under which we agree to manufacture various products such as traditional and arc-resistant distribution switchgear and control gear, medium-voltage circuit breakers, monitoring and control communications systems, motor control centers and bus duct systems. These products may be sold separately as an engineered solution, but are typically integrated into custom-built enclosures which we also build.  These enclosures are referred to as power control room substations (PCRs®), custom-engineered modules or electrical houses (E-Houses). Some contracts may also include the installation and the commissioning of these enclosures.

- added (2020-02-05):
[0000080420-20-000005:note_history:35]
Revenue from these contracts is generally recognized over time utilizing the cost-to-cost method to measure the extent of progress toward the completion of the performance obligation and the recognition of revenue over time. We believe that this method is the most accurate representation of our performance, because it directly measures the value of the services transferred to the customer over time as we incur costs on our contracts.  Contract costs include all direct materials, labor, and indirect costs related to contract performance, which may include indirect labor, supplies, tools, repairs and depreciation costs.

- changed (2020-02-05):
[0000080420-20-000005:note_history:36]
We also have contracts to provide value-added services such as field service inspection, installation, commissioning, modification and repair, as well as retrofit and retrofill components for existing systems.  As a practical expedient, if the service contract terms give us the right to invoice the customer for an amount that corresponds directly with the value of our performance completed to date (i.e., a service contract in which we bill a fixed amount for each hour of service provided), then we recognize revenue over time in each reporting period corresponding to the amount with which we have the right to invoice.  Our performance obligations are satisfied as the work progresses. Revenues from our custom-engineered products and value-added services transferred to customers over time accounted for approximately 95% and 93% of total revenues for the three months ended December 31, 2019 and 2018, respectively.
  (was, 2019-08-07, similarity 0.9207):
[0000080420-19-000024:note_history:36]
We also have contracts to provide value-added services such as field service inspection, installation, commissioning, modification and repair, as well as retrofit and retrofill components for existing systems.  As a practical expedient, if the service contract terms give us the right to invoice the customer for an amount that corresponds directly with the value of our performance completed to date (i.e., a service contract in which we bill a fixed amount for each hour of service provided), then we recognize revenue over time in each reporting period corresponding to the amount with which we have the right to invoice.  Our performance obligations are satisfied as the work progresses. Revenues from our custom-engineered products and value-added services transferred to customers over time accounted for approximately 93% of total revenues for both the three and nine months ended June 30, 2019.

- changed (2020-02-05):
[0000080420-20-000005:note_history:37]
We also have sales orders for spare parts and replacement circuit breakers for switchgear that are obsolete or that are no longer produced by the original manufacturer. Revenues from these sales orders are recognized at the time we fulfill our performance obligation to the customer, which is typically upon shipment and represented approximately 5% and 7% of total revenues for the three months ended December 31, 2019 and 2018, respectively.
  (was, 2019-08-07, similarity 0.7506):
[0000080420-19-000024:note_history:37]
We also have sales orders for spare parts and replacement circuit breakers for switchgear that are obsolete or that are no longer produced by the original manufacturer. Revenues from these sales orders are recognized at a point in time when we fulfill our performance obligation to the customer which is typically upon shipment. Revenue related to sales orders represents approximately 7% of total revenues for both the three and nine months ended June 30, 2019.

- changed (2020-02-05):
[0000080420-20-000005:note_history:38]
A performance obligation is a promise in a contract or with a customer to transfer a distinct good or service. A contract’s transaction price is allocated to each distinct performance obligation and recognized as revenue as the performance obligations are satisfied. To determine the proper revenue recognition for contracts, we evaluate whether a contract should be accounted for as more than one performance obligation or, less commonly, whether two or more contracts should be combined and accounted for as one performance obligation.  This evaluation of performance obligations requires significant judgment.  The majority of our contracts have a single performance obligation where multiple engineered products and services are combined into a single custom-engineered solution. Our contracts generally include a standard assurance warranty that typically ends 18 months after shipment. Occasionally, we provide service-type warranties that will extend the warranty period. These extended warranties qualify as a separate performance obligation, and revenue is deferred and recognized over the warranty period. If we determine during the evaluation of the contract that there are multiple performance obligations, we allocate the transaction price to each performance obligation using our best estimate of the standalone selling price of each distinct good or service in the contract.
  (was, 2019-08-07, similarity 0.772):
[0000080420-19-000024:note_history:38]
A performance obligation is a promise in a contract or with a customer to transfer a distinct good or service. A contract’s transaction price is allocated to each distinct performance obligation and recognized as revenue as the performance obligations are satisfied. To determine the proper revenue recognition for contracts, we evaluate whether a contract should be accounted for as more than one performance obligation or, less commonly, whether two or more contracts should be combined and accounted for as one performance obligation.  This evaluation of performance obligations requires significant judgement.  The majority of our contracts have a single performance obligation where multiple engineered products and services are combined into a single custom engineered solution. Our contracts generally include a standard assurance warranty that typically ends eighteen months after shipment. Occasionally, we provide service-type warranties that will extend the warranty period. These extended warranties qualify as a separate performance obligation. If we determine during the evaluation of the contract that there are multiple performance obligations, we allocate the transaction price to each performance obligation using our best estimate of the standalone selling price of each distinct good or service in the contract.

- changed (2020-02-05):
[0000080420-20-000005:note_history:39]
Remaining unsatisfied performance obligations, which we refer to as backlog, represent the estimated transaction price for goods and services for which we have a material right but work has not been performed. As of December 31, 2019, we had backlog of $425.9 million, of which approximately $367.4 million is expected to be recognized as revenue within the next twelve months. Backlog may not be indicative of future operating results as orders may be cancelled or modified by our customers. Our backlog does not include service and maintenance-type contracts for which we have the right to invoice as services are performed.
  (was, 2019-08-07, similarity 0.981):
[0000080420-19-000024:note_history:39]
Remaining unsatisfied performance obligations, which we refer to as backlog, represent the estimated transaction price for goods and services for which we have a material right but work has not been performed. As of June 30, 2019, we had backlog of $407.0 million, of which approximately $368.7 million is expected to be recognized within the next twelve months. Backlog may not be indicative of future operating results as orders may be cancelled or modified by our customers. Our backlog does not include service and maintenance-type contracts for which we have the right to invoice as services are performed.

- changed (2020-02-05):
[0000080420-20-000005:note_history:40]
For the three months ended December 31, 2019 and 2018, our operating results were positively impacted by $4.3 million and $3.1 million, respectively, as a result of changes in contract estimates related to projects in progress at the beginning of the respective period. These changes in estimates resulted primarily from favorable project execution and negotiations of variable consideration, discussed below, as well as other changes in facts and circumstances during these periods.
  (was, 2019-08-07, similarity 0.9476):
[0000080420-19-000024:note_history:40]
For the nine months ended June 30, 2019 and 2018, our operating results were positively impacted by $4.3 million and $2.9 million, respectively, as a result of changes in contract estimates related to projects in progress at the beginning of the respective period. These changes in estimates resulted primarily from favorable project execution and negotiations of variable consideration, discussed below, as well as other changes in facts and circumstances during these periods.

- changed (2020-02-05):
[0000080420-20-000005:note_history:41]
Contracts may be modified for changes in contract specifications and requirements. We consider contract modifications to exist when the modification either creates new or changes the enforceable rights and obligations under the contract. Most of our contract modifications are for goods and services that are not distinct from the existing performance obligation. Contract modifications result in a cumulative catch-up adjustment to revenue based on our measure of progress for the performance obligation.
  (was, 2019-08-07, similarity 0.998):
[0000080420-19-000024:note_history:41]
Contracts may be modified for changes in contract specifications and requirements. We consider contract modifications to exist when the modification either creates new or changes the enforceable rights and obligations under the contract. Most of our contract modifications are for goods and services that are not distinct from the existing performance obligation. Contract modifications result in a cumulative catch up adjustment to revenue based on our measure of progress for the performance obligation.

- changed (2020-02-05):
[0000080420-20-000005:note_history:42]
Contract assets are recorded when revenues are recognized in excess of amounts billed for fixed-price contracts as determined by the billing milestone schedule. Contract assets are transferred to accounts receivables when billing milestones have been met, or we have an unconditional right to payment.
  (was, 2019-08-07, similarity 0.8511):
[0000080420-19-000024:note_history:42]
Contract assets, previously referred to as costs and estimated earnings in excess of billings on uncompleted contracts, are recorded when revenues are recognized in excess of amounts billed for fixed-price contracts as determined by the billing milestone schedule. Contract assets are transferred to accounts receivables when billing milestones have been met or we have an unconditional right to payment.

- changed (2020-02-05):
[0000080420-20-000005:note_history:43]
Contract liabilities typically represent advance payments from contractual billing milestones and billings in excess of revenue recognized. It is unusual to have advanced milestone payments with a term greater than one year, which could represent a financing component on the contract.
  (was, 2019-08-07, similarity 0.6409):
[0000080420-19-000024:note_history:43]
Contract liabilities, previously referred to as billings in excess of costs and estimated earnings on uncompleted contracts, typically represent advance payments from contractual billing milestones and billings in excess of revenue recognized. It is unusual to have advanced milestone payments with a term greater than one year, which could represent a financing component on the contract.

- changed (2020-02-05):
[0000080420-20-000005:note_history:44]
Contract assets and liabilities as of December 31, 2019 and September 30, 2019 are summarized below (in thousands):
  (was, 2019-08-07, similarity 0.9515):
[0000080420-19-000024:note_history:44]
Contract assets and liabilities as of June 30, 2019 and September 30, 2018 are summarized below (in thousands):

- changed (2020-02-05):
[0000080420-20-000005:note_history:45]
|  | December 31, 2019 |  | September 30, 2019 |
| Contract assets | $ | 60,296 |  |  | $ | 55,374 |  |
| Contract liabilities | (77,556 | ) |  | (71,464 | ) |
| Net contract asset (liability) | $ | (17,260 | ) |  | $ | (16,090 | ) |
  (was, 2019-08-07, similarity 0.9644):
[0000080420-19-000024:note_history:45]
|  | June 30, 2019 |  | September 30, 2018 |
| Contract assets | $ | 57,231 |  |  | $ | 82,545 |  |
| Contract liabilities | (60,868 | ) |  | (43,174 | ) |
| Net contract asset (liability) | $ | (3,637 | ) |  | $ | 39,371 |  |

- changed (2020-02-05):
[0000080420-20-000005:note_history:46]
The increase in net contract liability at December 31, 2019 from September 30, 2019 was primarily due to our progress towards completion on our projects and the timing of contract billing milestones and new orders. To determine the amount of revenue recognized during the period from contract liabilities, we first allocate revenue to the individual contract liability balance outstanding at the beginning of the period until the revenue exceeds that balance. During the three months ended December 31, 2019, we recognized revenue of approximately $45.6 million related to contract liabilities outstanding at September 30, 2019.
  (was, 2019-08-07, similarity 0.7791):
[0000080420-19-000024:note_history:46]
The decrease in net contract asset (liability) at June 30, 2019 from September 30, 2018 was primarily due to our progress towards completion on our projects and the timing of contract billing milestones and new orders. To determine the amount of revenue recognized during the period from contract liabilities, we first allocate revenue to the individual contract liability balance outstanding at the beginning of the period until the revenue exceeds that balance. During the three and nine months ended June 30, 2019, we recognized revenue of approximately $2.2 million and $39.4 million, respectively, related to contract liabilities outstanding at September 30, 2018.

- changed (2020-02-05):
[0000080420-20-000005:note_history:47]
The timing of our invoice process is typically dependent on the completion of certain milestones and contract terms and subject to agreement by our customer.  Payment is typically expected within 30 days of invoice. Any uncollected invoiced amounts for our performance obligations recognized over time, including contract retentions, are recorded as accounts receivable in the Condensed Consolidated Balance Sheets. Certain contracts contain retention provisions that become due upon completion of contractual requirements. As of December 31, 2019 and September 30, 2019, accounts receivable included retention amounts of $5.9 million and $5.6 million, respectively. Of the retained amount at December 31, 2019, $5.6 million is expected to be collected in the next twelve months and is recorded in accounts receivable. The remaining $0.3 million is recorded in other assets.
  (was, 2019-08-07, similarity 0.9266):
[0000080420-19-000024:note_history:47]
The timing of our invoice process is typically dependent on the completion of certain milestones and contract terms and subject to agreement by our customer.  Payment is typically expected within 30 days of invoice. Any uncollected invoiced amounts for our performance obligations recognized over time, including contract retentions, are recorded as accounts receivable in the Condensed Consolidated Balance Sheets. Certain contracts contain retention provisions that become due upon completion of contractual requirements. As of June 30, 2019 and September 30, 2018, accounts receivable included retention amounts of $4.7 million and $4.2 million, respectively. Of the retained amount at June 30, 2019, $4.4 million is expected to be collected in the next twelve months.

- changed (2020-02-05):
[0000080420-20-000005:note_history:48]
The following tables present our disaggregated revenue by geographic destination and market sector for the three months ended December 31, 2019 and 2018 (in thousands):
  (was, 2019-08-07, similarity 0.9216):
[0000080420-19-000024:note_history:48]
The following tables present our disaggregated revenue by geographic destination and market sector for the three and nine months ended June 30, 2019 (in thousands):

- changed (2020-02-05):
[0000080420-20-000005:note_history:49]
|  | Three months ended December 31, 2019 |  | Three months ended December 31, 2018 |
| United States | $ | 107,078 |  |  | $ | 89,898 |  |
| Canada | 14,454 |  |  | 9,715 |  |
| Europe, Middle East and Africa | 10,166 |  |  | 5,441 |  |
| Asia/Pacific | 1,686 |  |  | 3,744 |  |
| Mexico, Central and South America | 766 |  |  | 553 |  |
| Total revenues by geographic destination | $ | 134,150 |  |  | $ | 109,351 |  |
  (was, 2019-08-07, similarity 0.8812):
[0000080420-19-000024:note_history:49]
|  | Three months ended June 30, 2019 |  | Nine months ended June 30, 2019 |
| United States | $ | 99,745 |  |  | $ | 292,049 |  |
| Canada | 20,206 |  |  | 45,015 |  |
| Europe, Middle East and Africa | 9,659 |  |  | 20,608 |  |
| Asia/Pacific | 4,682 |  |  | 9,155 |  |
| Mexico, Central and South America | 1,296 |  |  | 1,849 |  |
| Total revenues by geographic destination | $ | 135,588 |  |  | $ | 368,676 |  |

- changed (2020-02-05):
[0000080420-20-000005:note_history:50]
|  | Three months ended December 31, 2019 |  | Three months ended December 31, 2018 |
| Oil and gas | $ | 59,994 |  |  | $ | 49,576 |  |
| Petrochemical | 30,426 |  |  | 19,778 |  |
| Electric utility | 23,015 |  |  | 19,258 |  |
| Traction power | 8,351 |  |  | 5,009 |  |
| All others | 12,364 |  |  | 15,730 |  |
| Total revenues by market sector | $ | 134,150 |  |  | $ | 109,351 |  |
  (was, 2019-08-07, similarity 0.8654):
[0000080420-19-000024:note_history:50]
|  | Three months ended June 30, 2019 |  | Nine months ended June 30, 2019 |
| Oil and gas | $ | 62,356 |  |  | $ | 167,954 |  |
| Petrochemical | 21,086 |  |  | 63,387 |  |
| Electric utility | 26,425 |  |  | 66,066 |  |
| Traction power | 7,423 |  |  | 18,457 |  |
| All others | 18,298 |  |  | 52,812 |  |
| Total revenues by market sector | $ | 135,588 |  |  | $ | 368,676 |  |

- removed (2020-02-05):
[0000080420-19-000024:note_history:51]
On October 1, 2018, we adopted the new revenue recognition standard using the modified retrospective transition method. We applied the guidance to customer contracts which were not substantially complete at that time and we determined that no adjustment to retained earnings was necessary. Financial results for reporting periods after October 1, 2018 are reported under the new guidance; however financial results for prior periods were not adjusted and will continue to be presented in accordance with the previous guidance.

- removed (2020-02-05):
[0000080420-19-000024:note_history:52]
Revenue from these contracts is generally recognized over time utilizing the cost to cost method to measure the extent of progress toward the completion of the performance obligation and the recognition of revenue over time. We believe that this method is the most accurate representation of our performance because it directly measures the value of the services transferred to the customer over time as we incur costs on our contracts.  Contract costs include all direct materials, labor, and indirect costs related to contract performance which may include indirect labor, supplies, tools, repairs and depreciation costs.


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: tag_name, score: 1.0

- added (2020-02-05):
[0000080420-20-000005:note_history:53]
On February 4, 2020, our Board of Directors declared a quarterly cash dividend on our common stock in the amount of $0.26 per share. The dividend is payable on March 18, 2020 to shareholders of record at the close of business on February 19, 2020.

- removed (2020-02-05):
[0000080420-19-000024:note_history:54]
On August 6, 2019, our Board of Directors declared a quarterly cash dividend on our common stock in the amount of $0.26 per share. The dividend is payable on September 18, 2019 to shareholders of record at the close of business on August 21, 2019.
