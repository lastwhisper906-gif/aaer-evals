# POWL notes — 0000080420-20-000005


## powl:LesseeAssetsAndLiabilitiesTableTextBlock

[0000080420-20-000005:notes:1]
The following table provides a summary of the operating lease assets and operating lease liabilities included in our Condensed Consolidated Balance Sheets as of December 31, 2019 (in thousands):

[0000080420-20-000005:notes:2]
| Operating Leases |  | December 31, 2019 |
| Assets: |  |  |
| Operating lease assets, net |  | $ | 6,213 |  |
| Liabilities: |  |  |
| Current operating lease liabilities |  | 2,247 |  |
| Long-term operating lease liabilities |  | 4,792 |  |
| Total lease liabilities |  | $ | 7,039 |  |


## us-gaap:AllowanceForCreditLossesOnFinancingReceivablesTableTextBlock

[0000080420-20-000005:notes:3]
Activity in our allowance for doubtful accounts consisted of the following (in thousands):

[0000080420-20-000005:notes:4]
|  | Three months ended December 31, |
|  | 2019 |  | 2018 |
| Balance at beginning of period | $ | 301 |  |  | $ | 157 |  |
| Bad debt expense | 42 |  |  | 27 |  |
| Uncollectible accounts written off, net of recoveries | (10 | ) |  | (42 | ) |
| Change due to foreign currency translation | 13 |  |  | (3 | ) |
| Balance at end of period | $ | 346 |  |  | $ | 139 |  |


## us-gaap:BasisOfAccountingPolicyPolicyTextBlock

[0000080420-20-000005:notes:5]
[same as prior period, unchanged from 0000080420-19-000024:notes:3]

[0000080420-20-000005:notes:6]
[same as prior period, unchanged from 0000080420-19-000024:notes:4]

[0000080420-20-000005:notes:7]
[same as prior period, unchanged from 0000080420-19-000024:notes:5]

[0000080420-20-000005:notes:8]
These unaudited condensed consolidated financial statements should be read in conjunction with the audited consolidated financial statements and notes thereto of Powell and its subsidiaries included in Powell’s Annual Report on Form 10-K for the year ended September 30, 2019, which was filed with the Securities and Exchange Commission (SEC) on December 5, 2019.

[0000080420-20-000005:notes:9]
References to Fiscal 2020 and Fiscal 2019 used throughout this report shall mean our fiscal years ended September 30, 2020 and 2019, respectively.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0000080420-20-000005:notes:10]
Commitments and Contingencies

[0000080420-20-000005:notes:11]
Letters of Credit, Surety Bonds and Bank Guarantees

[0000080420-20-000005:notes:12]
Certain customers require us to post letters of credit, bank guarantees or surety bonds. These security instruments assure that we will perform under the terms of our contract. In the event of default, the counterparty may demand payment from the bank under a letter of credit or bank guarantee, or performance by the surety under a bond. To date, there have been no significant draws or claims related to security instruments for the periods reported. We were contingently liable for letters of credit of $13.4 million as of December 31, 2019. We also had surety bonds totaling $180.0 million that were outstanding, with additional bonding capacity of $570.0 million available, at December 31, 2019.

[0000080420-20-000005:notes:13]
We have an $11.9 million facility agreement (Facility Agreement) between Powell (UK) Limited and a large international bank that provides Powell (UK) Limited the ability to enter into bank guarantees as well as forward exchange contracts and currency options. At December 31, 2019, we had outstanding guarantees totaling $5.2 million and amounts available under this Facility Agreement were $6.7 million. The Facility Agreement expires in May 2020 and provides for financial covenants and customary events of default, and carries cross-default provisions with our U.S. Revolver. If an event of default (as defined in the Facility Agreement) occurs and is continuing, per the terms and subject to the conditions set forth therein, obligations outstanding under the Facility Agreement may be accelerated and declared immediately due and payable. As of December 31, 2019, we were in compliance with all of the financial covenants of the Facility Agreement.

[0000080420-20-000005:notes:14]
Litigation

[0000080420-20-000005:notes:15]
We are involved in various legal proceedings, claims and other disputes arising from our commercial operations, projects, employees and other matters which, in general, are subject to uncertainties and in which the outcomes are not predictable. Although we can give no assurances about the resolution of pending claims, litigation or other disputes and the effect such outcomes may have on us, management believes that any ultimate liability resulting from the outcome of such proceedings, to the extent not otherwise provided or covered by insurance, will not have a material adverse effect on our consolidated financial position or results of operations or liquidity.


## us-gaap:ContractWithCustomerAssetAndLiabilityTableTextBlock

[0000080420-20-000005:notes:16]
Contract assets and liabilities as of December 31, 2019 and September 30, 2019 are summarized below (in thousands):

[0000080420-20-000005:notes:17]
|  | December 31, 2019 |  | September 30, 2019 |
| Contract assets | $ | 60,296 |  |  | $ | 55,374 |  |
| Contract liabilities | (77,556 | ) |  | (71,464 | ) |
| Net contract asset (liability) | $ | (17,260 | ) |  | $ | (16,090 | ) |


## us-gaap:DisaggregationOfRevenueTableTextBlock

[0000080420-20-000005:notes:18]
The following tables present our disaggregated revenue by geographic destination and market sector for the three months ended December 31, 2019 and 2018 (in thousands):

[0000080420-20-000005:notes:19]
|  | Three months ended December 31, 2019 |  | Three months ended December 31, 2018 |
| United States | $ | 107,078 |  |  | $ | 89,898 |  |
| Canada | 14,454 |  |  | 9,715 |  |
| Europe, Middle East and Africa | 10,166 |  |  | 5,441 |  |
| Asia/Pacific | 1,686 |  |  | 3,744 |  |
| Mexico, Central and South America | 766 |  |  | 553 |  |
| Total revenues by geographic destination | $ | 134,150 |  |  | $ | 109,351 |  |

[0000080420-20-000005:notes:20]
|  | Three months ended December 31, 2019 |  | Three months ended December 31, 2018 |
| Oil and gas | $ | 59,994 |  |  | $ | 49,576 |  |
| Petrochemical | 30,426 |  |  | 19,778 |  |
| Electric utility | 23,015 |  |  | 19,258 |  |
| Traction power | 8,351 |  |  | 5,009 |  |
| All others | 12,364 |  |  | 15,730 |  |
| Total revenues by market sector | $ | 134,150 |  |  | $ | 109,351 |  |


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0000080420-20-000005:notes:21]
Stock-Based Compensation

[0000080420-20-000005:notes:22]
Refer to our Annual Report on Form 10-K for the fiscal year ended September 30, 2019 for a full description of our existing stock-based compensation plans.

[0000080420-20-000005:notes:23]
[same as prior period, unchanged from 0000080420-19-000024:notes:21]

[0000080420-20-000005:notes:24]
We issue restricted stock units (RSUs) to certain officers and key employees of the Company. The fair value of the RSUs is based on the price of our common stock as reported on the NASDAQ Global Market on the grant dates. The typical annual grant vests over a three-year period from the date of issuance and is a blend of time-based and performance-based shares. The portion of the grant that is time-based typically vests over a three-year period on each anniversary of the grant date, based on continued employment. The performance-based shares vest based on the three-year earnings performance of the Company following the grant date. At December 31, 2019, there were 154,200 RSUs outstanding. The RSUs do not have voting rights but do receive dividend equivalents upon vesting. Additionally, the shares of common stock underlying the RSUs are not considered issued and outstanding until vested and common stock is issued.

[0000080420-20-000005:notes:25]
Total RSU activity (number of shares) for the three months ended December 31, 2019 is summarized below:

[0000080420-20-000005:notes:26]
|  | Number ofRestrictedStockUnits |  | WeightedAverageFair ValuePer Share |
| Outstanding at September 30, 2019 | 131,850 |  |  | $ | 33.76 |  |
| Granted | 70,000 |  |  | 38.57 |  |
| Vested | (46,900 | ) |  | 35.65 |  |
| Forfeited/canceled | (750 | ) |  | 33.16 |  |
| Outstanding at December 31, 2019 | 154,200 |  |  | 35.37 |  |

[0000080420-20-000005:notes:27]
During the three months ended December 31, 2019 and 2018, we recorded compensation expense of $0.9 million and $1.2 million, respectively, related to the RSUs.

[0000080420-20-000005:notes:28]
[same as prior period, unchanged from 0000080420-19-000024:notes:26]

[0000080420-20-000005:notes:29]
Each non-employee director receives 2,000 restricted shares of the Company’s common stock annually. Fifty-percent of the restricted stock granted to each of our non-employee directors vests immediately, while the remaining fifty-percent vests on the anniversary of the grant date. Compensation expense is recognized immediately for the first fifty-percent of the restricted stock granted, while compensation expense for the remaining fifty-percent is recognized over the remaining vesting period. During the three months ended December 31, 2019 and 2018, there were no restricted shares granted. During the three months ended December 31, 2019 and 2018, we recorded compensation expense of $0.1 million and less than $0.1 million, respectively related to restricted stock.


## us-gaap:EarningsPerShareTextBlock

[0000080420-20-000005:notes:30]
Earnings Per Share

[0000080420-20-000005:notes:31]
[same as prior period, unchanged from 0000080420-19-000024:notes:29]

[0000080420-20-000005:notes:32]
[same as prior period, unchanged from 0000080420-19-000024:notes:30]

[0000080420-20-000005:notes:33]
|  | Three months ended December 31, |
|  | 2019 |  | 2018 |
| Numerator: |  |  |  |
| Net income (loss) | $ | 2,775 |  |  | $ | (2,695 | ) |
| Denominator: |  |  |  |
| Weighted average basic shares | 11,614 |  |  | 11,551 |  |
| Dilutive effect of restricted stock units | 51 |  |  | — |  |
| Weighted average diluted shares | 11,665 |  |  | 11,551 |  |
| Income (loss) per share: |  |  |  |
| Basic | $ | 0.24 |  |  | $ | (0.23 | ) |
| Diluted | $ | 0.24 |  |  | $ | (0.23 | ) |

[0000080420-20-000005:notes:34]
For the three months ended December 31, 2018, we incurred a net loss and therefore all potential common shares were deemed to be anti-dilutive.


## us-gaap:FairValueDisclosuresTextBlock

[0000080420-20-000005:notes:35]
Fair Value Measurements

[0000080420-20-000005:notes:36]
[same as prior period, unchanged from 0000080420-19-000024:notes:34]

[0000080420-20-000005:notes:37]
[same as prior period, unchanged from 0000080420-19-000024:notes:35]

[0000080420-20-000005:notes:38]
[same as prior period, unchanged from 0000080420-19-000024:notes:36]

[0000080420-20-000005:notes:39]
[same as prior period, unchanged from 0000080420-19-000024:notes:37]

[0000080420-20-000005:notes:40]
[same as prior period, unchanged from 0000080420-19-000024:notes:38]

[0000080420-20-000005:notes:41]
The following table summarizes the fair value of our assets and liabilities that were accounted for at fair value on a recurring basis as of December 31, 2019 (in thousands):

[0000080420-20-000005:notes:42]
|  | Fair Value Measurements at December 31, 2019 |
|  | Quoted Prices inActive Markets forIdentical Assets(Level 1) |  | Significant OtherObservableInputs(Level 2) |  | SignificantUnobservableInputs(Level 3) |  | Fair Value at December 31, 2019 |
| Assets: |  |  |  |  |  |  |  |
| Cash and cash equivalents | $ | 120,966 |  |  | $ | — |  |  | $ | — |  |  | $ | 120,966 |  |
| Other assets | — |  |  | 7,205 |  |  | — |  |  | 7,205 |  |
| Liabilities: |  |  |  |  |  |  |  |
| Deferred compensation | — |  |  | 6,869 |  |  | — |  |  | 6,869 |  |

[0000080420-20-000005:notes:43]
The following table summarizes the fair value of our assets and liabilities that were accounted for at fair value on a recurring basis as of September 30, 2019 (in thousands):

[0000080420-20-000005:notes:44]
|  | Fair Value Measurements at September 30, 2019 |
|  | Quoted Prices inActive Markets forIdentical Assets(Level 1) |  | Significant OtherObservableInputs(Level 2) |  | SignificantUnobservableInputs(Level 3) |  | Fair Value at September 30, 2019 |
| Assets: |  |  |  |  |  |  |  |
| Cash and cash equivalents | $ | 118,639 |  |  | $ | — |  |  | $ | — |  |  | $ | 118,639 |  |
| Short-term investments | 6,042 |  |  | — |  |  | — |  |  | 6,042 |  |
| Other assets | — |  |  | 6,825 |  |  | — |  |  | 6,825 |  |
| Liabilities: |  |  |  |  |  |  |  |
| Deferred compensation | — |  |  | 6,249 |  |  | — |  |  | 6,249 |  |

[0000080420-20-000005:notes:45]
[same as prior period, unchanged from 0000080420-19-000024:notes:43]

[0000080420-20-000005:notes:46]
Cash and cash equivalents – Cash and cash equivalents, primarily funds held in money market savings instruments, are reported at their current carrying value, which approximates fair value due to the short-term nature of these instruments and are included in cash and cash equivalents in our Condensed Consolidated Balance Sheets.

[0000080420-20-000005:notes:47]
[same as prior period, unchanged from 0000080420-19-000024:notes:45]

[0000080420-20-000005:notes:48]
Other Assets/Deferred Compensation – We hold investments in an irrevocable Rabbi Trust for our deferred compensation plan. The assets are primarily related to company-owned life insurance policies and are included in other assets in the accompanying Condensed Consolidated Balance sheets. Because the mutual funds and company-owned life insurance policies are combined in the plan, they are categorized as Level 2 in the fair value measurement hierarchy. The deferred compensation liability represents the investment options that the plan participants have designated to serve as the basis for measurement of the notional value of their accounts. Because the deferred compensation liability is intended to offset the plan assets, it is also categorized as Level 2 in the fair value measurement hierarchy.

[0000080420-20-000005:notes:49]
There were no transfers between levels within the fair value measurement hierarchy during the quarter ended December 31, 2019.


## us-gaap:IncomeTaxDisclosureTextBlock

[0000080420-20-000005:notes:50]
Income Taxes

[0000080420-20-000005:notes:51]
[same as prior period, unchanged from 0000080420-19-000024:notes:50]

[0000080420-20-000005:notes:52]
|  | Three months ended December 31, |
|  | 2019 |  | 2018 |
| Income (loss) before income taxes | $ | 3,333 |  |  | $ | (2,934 | ) |
| Income tax provision (benefit) | 558 |  |  | (239 | ) |
| Net income (loss) | $ | 2,775 |  |  | $ | (2,695 | ) |
| Effective tax rate | 17 | % |  | 8 | % |

[0000080420-20-000005:notes:53]
Our income tax provision (benefit) reflects an effective tax rate on pre-tax results of 17% for the first quarter of Fiscal 2020 compared to 8% in the first quarter of Fiscal 2019. The effective tax rate for the three months ended December 31, 2019 was favorably impacted by the Research and Development Tax Credit (R&D Tax Credit) as well as the utilization of net operating loss carryforwards in Canada that were fully reserved with a valuation allowance. Conversely, losses recognized in Canada reserved with a valuation allowance negatively impacted the effective tax rate in the three months ended December 31, 2018. There were no material discrete items recognized in the first quarter of Fiscal 2020 or 2019.

[0000080420-20-000005:notes:54]
Due to the expiration of certain federal statutes of limitations and voluntary filings, management believes that, within the next twelve months, it is reasonably possible that the unrecognized tax benefits will decrease by approximately $0.9 million and would positively impact our effective tax rate. We are unable to make reasonably reliable estimates regarding the timing of future cash outflows, if any, associated with the remaining unrecognized tax benefits.


## us-gaap:LeaseCostTableTextBlock

[0000080420-20-000005:notes:55]
The following table provides a summary of lease cost components for the three months ended December 31, 2019 (in thousands):

[0000080420-20-000005:notes:56]
| Lease Cost |  | Three months ended December 31, 2019 |
| Operating lease cost |  | $ | 628 |  |
| Less: sublease income |  | (79 | ) |
| Variable lease cost(1) |  | 94 |  |
| Short-term lease cost(2) |  | 190 |  |
| Total lease cost |  | $ | 833 |  |

[0000080420-20-000005:notes:57]
(1) Variable lease cost represents common area maintenance charges related to our Canadian office space leases.

[0000080420-20-000005:notes:58]
(2) Short-term lease cost includes leases and rentals with initial terms of one year or less.


## us-gaap:LesseeOperatingLeaseLiabilityMaturityTableTextBlock

[0000080420-20-000005:notes:59]
The following table provides the maturities of our operating lease liabilities as of December 31, 2019 (in thousands):

[0000080420-20-000005:notes:60]
|  |  | Operating Leases |
| Remainder of 2020 |  | $ | 1,811 |  |
| 2021 |  | 2,392 |  |
| 2022 |  | 2,131 |  |
| 2023 |  | 1,103 |  |
| 2024 |  | 85 |  |
| Thereafter |  | — |  |
| Total future minimum lease payments |  | 7,522 |  |
| Less: present value discount (imputed interest) |  | (483 | ) |
| Present value of lease liabilities |  | $ | 7,039 |  |


## us-gaap:LesseeOperatingLeasesTextBlock

[0000080420-20-000005:notes:61]
Leases

[0000080420-20-000005:notes:62]
Our leases consist primarily of office and manufacturing space, construction equipment and office equipment. All of our future lease obligations are related to non-cancelable operating leases. The most significant portion of our lease portfolio relates to leases of office and manufacturing facilities in Canada which we no longer occupy. We currently sublease the majority of these Canadian facilities. The following table provides a summary of lease cost components for the three months ended December 31, 2019 (in thousands):

[0000080420-20-000005:notes:63]
We recognize operating lease assets and operating lease liabilities representing the present value of the remaining lease payments for leases with initial terms greater than twelve months. Leases with initial terms of twelve months or less are not recorded in our Condensed Consolidated Balance Sheets. Our operating lease assets have been reduced by a lease accrual of $0.8 million related to certain unused facility leases in Canada. The following table provides a summary of the operating lease assets and operating lease liabilities included in our Condensed Consolidated Balance Sheets as of December 31, 2019 (in thousands):

[0000080420-20-000005:notes:64]
The weighted average discount rate as of December 31, 2019 was 4.25%. The weighted average remaining lease term was 3.2  years at December 31, 2019.


## us-gaap:LongTermDebtTextBlock

[0000080420-20-000005:notes:65]
Long-Term Debt

[0000080420-20-000005:notes:66]
Long-term debt consisted of the following (in thousands):

[0000080420-20-000005:notes:67]
|  | December 31, 2019 |  | September 30, 2019 |
| Industrial development revenue bonds | $ | 800 |  |  | $ | 1,200 |  |
| Less: current portion | (400 | ) |  | (400 | ) |
| Total long-term debt | $ | 400 |  |  | $ | 800 |  |

[0000080420-20-000005:notes:68]
U.S. Revolver

[0000080420-20-000005:notes:69]
On September 27, 2019, we entered into an Amended and Restated Credit Agreement with Bank of America, N.A. (the " "U.S. Revolver"), which replaced our prior credit agreement. The U.S. Revolver is a $75.0 million revolving credit facility, that is available for both borrowings and letters of credit and expires September 2024. As of December 31, 2019, there were no amounts borrowed under this facility and letters of credit outstanding were $13.4 million. There was $61.6 million available for the issuance of letters of credit and borrowings under the U.S. Revolver as of December 31, 2019.

[0000080420-20-000005:notes:70]
We are required to maintain certain financial covenants, the most significant of which are a consolidated leverage ratio less than 3.0 to 1.0 and a consolidated interest coverage ratio of greater than 3.0 to 1.0. Additionally, we must maintain a consolidated cash balance of $30 million at all times. The U.S. Revolver also contains a "material adverse effect" clause which is a material change in our operations, business, properties, liabilities or condition (financial or otherwise) or a material impairment of our ability to perform our obligations under our credit agreements. As of December 31, 2019, we were in compliance with all of the financial covenants of the U.S. Revolver.

[0000080420-20-000005:notes:71]
The U.S. Revolver allows the Company to elect that any borrowing under the facility bear an interest rate based on either the base rate or the eurocurrency rate, in each case, plus the applicable rate. The base rate is generally the highest of (a) the federal funds rate plus 0.50%, (b) the Bank of America prime rate or (c) the London Interbank Offered Rate ("LIBOR") plus 1.00%. The applicable rate is generally a range from (0.25)% to 1.75% depending on the type of loan and the Company's consolidated leverage ratio.

[0000080420-20-000005:notes:72]
The U.S. Revolver is collateralized by a pledge of 100% of the voting capital stock of each of our domestic subsidiaries and 65% of the voting capital stock of each non-domestic subsidiary. The U.S. Revolver provides for customary events of default and carries cross-default provisions with other existing debt agreements. If an event of default (as defined in the U.S. Revolver) occurs and is continuing, on the terms and subject to the conditions set forth in the U.S. Revolver, amounts and letters of credit outstanding under the U.S. Revolver may be accelerated and may become immediately due and payable.

[0000080420-20-000005:notes:73]
Industrial Development Revenue Bonds

[0000080420-20-000005:notes:74]
We borrowed $8.0 million in October 2001 through a loan agreement funded with proceeds from tax-exempt industrial development revenue bonds (Bonds). These Bonds were issued by the Illinois Development Finance Authority and were used for the completion of our Northlake, Illinois facility. Pursuant to the Bond issuance, a reimbursement agreement between us and a major domestic bank required an issuance by the bank of an irrevocable direct-pay letter of credit (Bond LC), as collateral, to the Bonds’ trustee to guarantee payment of the Bonds’ principal and interest when due. The Bond LC is subject to both early termination and extension provisions customary to such agreements, as well as various covenants, for which we were in compliance at December 31, 2019. While the Bonds mature in 2021, the reimbursement agreement requires annual redemptions of $0.4 million that commenced on October 25, 2002. A sinking fund is used for the annual principal payment. The Bonds bear interest at a floating rate determined weekly by the Bonds’ remarketing agent, which was the underwriter for the Bonds and is an affiliate of the bank. This interest rate was 1.79% as of December 31, 2019.


## us-gaap:NewAccountingPronouncementsPolicyPolicyTextBlock

[0000080420-20-000005:notes:75]
New Accounting Standards

[0000080420-20-000005:notes:76]
Effective October 1, 2019, we adopted the new lease accounting standard and recorded operating lease assets and operating lease liabilities of approximately $7.0 million and determined that no adjustment to retained earnings was necessary. Financial results for reporting periods after October 1, 2019 are reported under the new standard; however financial results for prior periods were not adjusted and will continue to be presented in accordance with the previous standard. Upon adoption, we elected a package of practical expedients which, among other things, allowed for the historical classification of our existing leases to carryforward. Additionally, we elected to separate non-lease components for our real estate and IT infrastructure asset classes.  All other asset classes account for both lease and non-lease components in the operating lease asset and operating lease liability calculations. See Note I for further discussion of leases.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureAndSignificantAccountingPoliciesTextBlock

[0000080420-20-000005:notes:77]
Overview and Summary of Significant Accounting Policies

[0000080420-20-000005:notes:78]
[same as prior period, unchanged from 0000080420-19-000024:notes:70]

[0000080420-20-000005:notes:79]
[same as prior period, unchanged from 0000080420-19-000024:notes:71]

[0000080420-20-000005:notes:80]
We develop, design, manufacture and service custom-engineered equipment and systems for the distribution, control and monitoring of electrical energy. Headquartered in Houston, Texas, we serve the oil and gas markets, including onshore and offshore oil and gas production, pipeline, refining and liquid natural gas terminals, as well as petrochemical, electric utility, light rail traction power and other heavy industrial markets.

[0000080420-20-000005:notes:81]
[same as prior period, unchanged from 0000080420-19-000024:notes:73]

[0000080420-20-000005:notes:82]
The preparation of condensed consolidated financial statements in conformity with accounting principles generally accepted in the United States (U.S. GAAP) requires management to make estimates and assumptions that affect the amounts reported in the condensed consolidated financial statements and accompanying footnotes. The most significant estimates used in our condensed consolidated financial statements affect revenue recognition and estimated cost recognition on our customer contracts, the allowance for doubtful accounts, provision for excess and obsolete inventory, warranty accruals and income taxes. The amounts recorded for warranties, legal, income taxes, impairment of long-lived assets (when applicable) and other contingent liabilities require judgments regarding the amount of expenses that will ultimately be incurred. We base our estimates on historical experience and on various other assumptions, as well as the specific circumstances surrounding these contingent liabilities, in evaluating the amount of liability that should be recorded. Additionally, the recognition of deferred tax assets requires estimates related to future income and other assumptions regarding timing and future profitability because the ultimate realization of net deferred tax assets is dependent on the generation of future taxable income during the periods in which temporary differences become deductible. Estimates routinely change as new events occur, additional information becomes available or operating environments change. Actual results may differ from our prior estimates.


## us-gaap:RevenueFromContractWithCustomerPolicyTextBlock

[0000080420-20-000005:notes:83]
[same as prior period, unchanged from 0000080420-19-000024:notes:80]

[0000080420-20-000005:notes:84]
[same as prior period, unchanged from 0000080420-19-000024:notes:81]

[0000080420-20-000005:notes:85]
[same as prior period, unchanged from 0000080420-19-000024:notes:82]

[0000080420-20-000005:notes:86]
Contracts may be modified for changes in contract specifications and requirements. We consider contract modifications to exist when the modification either creates new or changes the enforceable rights and obligations under the contract. Most of our contract modifications are for goods and services that are not distinct from the existing performance obligation. Contract modifications result in a cumulative catch-up adjustment to revenue based on our measure of progress for the performance obligation.

[0000080420-20-000005:notes:87]
[same as prior period, unchanged from 0000080420-19-000024:notes:84]

[0000080420-20-000005:notes:88]
[same as prior period, unchanged from 0000080420-19-000024:notes:85]

[0000080420-20-000005:notes:89]
Contract assets are recorded when revenues are recognized in excess of amounts billed for fixed-price contracts as determined by the billing milestone schedule. Contract assets are transferred to accounts receivables when billing milestones have been met, or we have an unconditional right to payment.

[0000080420-20-000005:notes:90]
Contract liabilities typically represent advance payments from contractual billing milestones and billings in excess of revenue recognized. It is unusual to have advanced milestone payments with a term greater than one year, which could represent a financing component on the contract.

[0000080420-20-000005:notes:91]
[same as prior period, unchanged from 0000080420-19-000024:notes:88]

[0000080420-20-000005:notes:92]
[same as prior period, unchanged from 0000080420-19-000024:notes:77]

[0000080420-20-000005:notes:93]
A performance obligation is a promise in a contract or with a customer to transfer a distinct good or service. A contract’s transaction price is allocated to each distinct performance obligation and recognized as revenue as the performance obligations are satisfied. To determine the proper revenue recognition for contracts, we evaluate whether a contract should be accounted for as more than one performance obligation or, less commonly, whether two or more contracts should be combined and accounted for as one performance obligation.  This evaluation of performance obligations requires significant judgment.  The majority of our contracts have a single performance obligation where multiple engineered products and services are combined into a single custom-engineered solution. Our contracts generally include a standard assurance warranty that typically ends 18 months after shipment. Occasionally, we provide service-type warranties that will extend the warranty period. These extended warranties qualify as a separate performance obligation, and revenue is deferred and recognized over the warranty period. If we determine during the evaluation of the contract that there are multiple performance obligations, we allocate the transaction price to each performance obligation using our best estimate of the standalone selling price of each distinct good or service in the contract.

[0000080420-20-000005:notes:94]
[same as prior period, unchanged from 0000080420-19-000024:notes:79]

[0000080420-20-000005:notes:95]
[same as prior period, unchanged from 0000080420-19-000024:notes:99]

[0000080420-20-000005:notes:96]
[same as prior period, unchanged from 0000080420-19-000024:notes:97]

[0000080420-20-000005:notes:97]
[same as prior period, unchanged from 0000080420-19-000024:notes:98]

[0000080420-20-000005:notes:98]
[same as prior period, unchanged from 0000080420-19-000024:notes:90]

[0000080420-20-000005:notes:99]
The majority of our revenues are generated from the manufacturing of custom-engineered products and systems under long-term fixed-price contracts under which we agree to manufacture various products such as traditional and arc-resistant distribution switchgear and control gear, medium-voltage circuit breakers, monitoring and control communications systems, motor control centers and bus duct systems. These products may be sold separately as an engineered solution, but are typically integrated into custom-built enclosures which we also build.  These enclosures are referred to as power control room substations (PCRs®), custom-engineered modules or electrical houses (E-Houses). Some contracts may also include the installation and the commissioning of these enclosures.

[0000080420-20-000005:notes:100]
Revenue from these contracts is generally recognized over time utilizing the cost-to-cost method to measure the extent of progress toward the completion of the performance obligation and the recognition of revenue over time. We believe that this method is the most accurate representation of our performance, because it directly measures the value of the services transferred to the customer over time as we incur costs on our contracts.  Contract costs include all direct materials, labor, and indirect costs related to contract performance, which may include indirect labor, supplies, tools, repairs and depreciation costs.

[0000080420-20-000005:notes:101]
We also have contracts to provide value-added services such as field service inspection, installation, commissioning, modification and repair, as well as retrofit and retrofill components for existing systems.  As a practical expedient, if the service contract terms give us the right to invoice the customer for an amount that corresponds directly with the value of our performance completed to date (i.e., a service contract in which we bill a fixed amount for each hour of service provided), then we recognize revenue over time in each reporting period corresponding to the amount with which we have the right to invoice.  Our performance obligations are satisfied as the work progresses. Revenues from our custom-engineered products and value-added services transferred to customers over time accounted for approximately 95% and 93% of total revenues for the three months ended December 31, 2019 and 2018, respectively.

[0000080420-20-000005:notes:102]
We also have sales orders for spare parts and replacement circuit breakers for switchgear that are obsolete or that are no longer produced by the original manufacturer. Revenues from these sales orders are recognized at the time we fulfill our performance obligation to the customer, which is typically upon shipment and represented approximately 5% and 7% of total revenues for the three months ended December 31, 2019 and 2018, respectively.

[0000080420-20-000005:notes:103]
[same as prior period, unchanged from 0000080420-19-000024:notes:95]

[0000080420-20-000005:notes:104]
[same as prior period, unchanged from 0000080420-19-000024:notes:96]


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0000080420-20-000005:notes:105]
Revenue

[0000080420-20-000005:notes:106]
[same as prior period, unchanged from 0000080420-19-000024:notes:101]

[0000080420-20-000005:notes:107]
Remaining unsatisfied performance obligations, which we refer to as backlog, represent the estimated transaction price for goods and services for which we have a material right but work has not been performed. As of December 31, 2019, we had backlog of $425.9 million, of which approximately $367.4 million is expected to be recognized as revenue within the next twelve months. Backlog may not be indicative of future operating results as orders may be cancelled or modified by our customers. Our backlog does not include service and maintenance-type contracts for which we have the right to invoice as services are performed.

[0000080420-20-000005:notes:108]
For the three months ended December 31, 2019 and 2018, our operating results were positively impacted by $4.3 million and $3.1 million, respectively, as a result of changes in contract estimates related to projects in progress at the beginning of the respective period. These changes in estimates resulted primarily from favorable project execution and negotiations of variable consideration, discussed below, as well as other changes in facts and circumstances during these periods.

[0000080420-20-000005:notes:109]
The increase in net contract liability at December 31, 2019 from September 30, 2019 was primarily due to our progress towards completion on our projects and the timing of contract billing milestones and new orders. To determine the amount of revenue recognized during the period from contract liabilities, we first allocate revenue to the individual contract liability balance outstanding at the beginning of the period until the revenue exceeds that balance. During the three months ended December 31, 2019, we recognized revenue of approximately $45.6 million related to contract liabilities outstanding at September 30, 2019.

[0000080420-20-000005:notes:110]
The timing of our invoice process is typically dependent on the completion of certain milestones and contract terms and subject to agreement by our customer.  Payment is typically expected within 30 days of invoice. Any uncollected invoiced amounts for our performance obligations recognized over time, including contract retentions, are recorded as accounts receivable in the Condensed Consolidated Balance Sheets. Certain contracts contain retention provisions that become due upon completion of contractual requirements. As of December 31, 2019 and September 30, 2019, accounts receivable included retention amounts of $5.9 million and $5.6 million, respectively. Of the retained amount at December 31, 2019, $5.6 million is expected to be collected in the next twelve months and is recorded in accounts receivable. The remaining $0.3 million is recorded in other assets.

[0000080420-20-000005:notes:111]
[same as prior period, unchanged from 0000080420-19-000024:notes:106]


## us-gaap:ScheduleOfInventoryCurrentTableTextBlock

[0000080420-20-000005:notes:112]
[same as prior period, unchanged from 0000080420-19-000024:notes:107]

[0000080420-20-000005:notes:113]
|  | December 31, 2019 |  | September 30, 2019 |
| Raw materials, parts and sub-assemblies, net | $ | 31,526 |  |  | $ | 28,102 |  |
| Work-in-progress | 922 |  |  | 1,100 |  |
| Total inventories | $ | 32,448 |  |  | $ | 29,202 |  |


## us-gaap:ScheduleOfProductWarrantyLiabilityTableTextBlock

[0000080420-20-000005:notes:114]
[same as prior period, unchanged from 0000080420-19-000024:notes:109]

[0000080420-20-000005:notes:115]
|  | Three months ended December 31, |
|  | 2019 |  | 2018 |
| Balance at beginning of period | $ | 2,946 |  |  | $ | 2,604 |  |
| Increase in warranty expense | 843 |  |  | 746 |  |
| Deduction for warranty charges | (645 | ) |  | (604 | ) |
| Change due to foreign currency translation | 18 |  |  | (14 | ) |
| Balance at end of period | $ | 3,162 |  |  | $ | 2,732 |  |


## us-gaap:SubsequentEventsTextBlock

[0000080420-20-000005:notes:116]
Subsequent Events

[0000080420-20-000005:notes:117]
On February 4, 2020, our Board of Directors declared a quarterly cash dividend on our common stock in the amount of $0.26 per share. The dividend is payable on March 18, 2020 to shareholders of record at the close of business on February 19, 2020.


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0000080420-20-000005:notes:118]
Detail of Selected Balance Sheet Accounts

[0000080420-20-000005:notes:119]
[same as prior period, unchanged from 0000080420-19-000024:notes:114]

[0000080420-20-000005:notes:120]
[same as prior period, unchanged from 0000080420-19-000024:notes:115]

[0000080420-20-000005:notes:121]
[same as prior period, unchanged from 0000080420-19-000024:notes:116]
