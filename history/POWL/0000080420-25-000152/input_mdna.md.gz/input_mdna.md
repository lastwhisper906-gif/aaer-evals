# POWL MD&A — 0000080420-25-000152


## mdna

[0000080420-25-000152:mdna:1]
Item 7. Management’s Discussion and Analysis of Financial Condition and Results of Operations

[0000080420-25-000152:mdna:2]
Executive Overview

[0000080420-25-000152:mdna:3]
We develop, design, manufacture and service custom-engineered equipment and systems that distribute, control and monitor the flow of electrical energy and provide protection to motors, transformers and other electrically powered equipment. We are headquartered in Houston, Texas and primarily serve the oil and gas and petrochemical markets, the electric utility market, and commercial and other industrial markets. Beyond these major markets, we also provide products and services to the light rail traction power market and other markets that include universities and government entities. We are continuously developing new channels to electrical markets through original equipment manufacturers and distribution market channels. For additional information on the markets we serve, see “Markets” in Part I, Item 1 of this Annual Report.

[0000080420-25-000152:mdna:4]
In Fiscal 2025, we reported revenues of $1.1 billion, net income of $180.7 million, and generated $167.9 million in cash from operating activities. As of September 30, 2025, we had total assets of $1.1 billion.

[0000080420-25-000152:mdna:5]
On August 15, 2025, we completed the previously announced business acquisition of Remsdaq Limited (Remsdaq), a U.K.-based manufacturer of Supervisory Control and Data Acquisition (SCADA) Remote Terminal Units (RTUs) for electrical substation control and automation in generation, transmission and distribution, for a total consideration of £13.6 million Pounds Sterling, or $18.4 million, including cash acquired. The acquisition advances our key strategic initiative to expand our automation platform capabilities. We believe the combination of Powell’s hardware and detection sensors with Remsdaq’s SCADA RTUs creates a highly synergistic integration that positions us to effectively meet the growing demand for more sophisticated solutions that enhance utility operational efficiency, system reliability and security. See Note P. Business Acquisition of the Notes to Consolidated Financial Statements for additional information.

[0000080420-25-000152:mdna:6]
Outlook

[0000080420-25-000152:mdna:7]
Our backlog increased to $1.4 billion as of September 30, 2025, of which approximately $824 million is expected to be recognized as revenue during our fiscal year ending September 30, 2026. Although current commercial activity remains active in most of the markets that we compete in, we remain attentive to the macro environment and geopolitical events that may have an impact on future market activity.

[0000080420-25-000152:mdna:8]
Oil and gas and petrochemical markets. The North American market is responding to increased international demand for  liquefied natural gas (LNG) and gas-to-chemical processes utilizing low-cost gas feedstocks. We believe the fundamentals of the U.S. natural gas market, through abundant supply and low cost, has supported investments in LNG, related gas processing, and petrochemical processes, and as a result, has sustained our order activity associated with such markets, which is evidenced by two large, domestic LNG project awards during the first half of Fiscal 2025. Other oil and gas end markets have remained active as well, and we secured two large, offshore projects in our core oil and gas end markets during the third quarter of Fiscal 2025. In addition to the traditional crude oil refining and other oil and gas downstream processes, we have expanded our end markets into hydrogen production, carbon capture as well as alternative fuels, such as biofuels and sustainable aviation fuel, in response to the demand for clean energy.

[0000080420-25-000152:mdna:9]
Electric utility market. Aligned with our strategy of end-market diversification, we seek to continue our focus and growth in electrical distribution substations, while also addressing a resurgence of power generation investment in this market. During the

[0000080420-25-000152:mdna:10]
third quarter of Fiscal 2025, we won a project for a new power generation plant, representing the largest electric utility award in the Company’s history.

[0000080420-25-000152:mdna:11]
Commercial and other industrial markets. As a result of a mix of factors we are experiencing steady growth in commercial facilities that provide for the production of various consumer goods and the expansion of data centers that support cloud computing and increasing investments in artificial intelligence. We are also experiencing increased activity in other industrial end markets. In the first half of Fiscal 2025, we secured a large mining project for the production of potash, which is expected to be executed in late Fiscal 2027 and beyond.

[0000080420-25-000152:mdna:12]
Additionally, we booked an order for a domestic light rail traction power project in the third quarter of Fiscal 2025, representing the first large traction power project booked in several quarters.

[0000080420-25-000152:mdna:13]
Business Environment

[0000080420-25-000152:mdna:14]
The markets in which we participate are capital-intensive and cyclical in nature. Cyclicality is predominantly driven by customer demand, global economic and geopolitical conditions and anticipated environmental, safety or regulatory changes that affect the manner in which our customers proceed with capital investments. Our customers analyze various factors, including the demand and price for oil, gas and electrical energy, the overall economic and financial environment, governmental budgets, regulatory actions and environmental concerns. These factors influence the release of new capital projects by our customers, which are traditionally awarded in competitive bid situations. Scheduling of projects is matched to customer requirements, and projects typically take a number of months to produce. Schedules may change during the course of any particular project, and our operating results can, therefore, be impacted by factors outside of our control.

[0000080420-25-000152:mdna:15]
Our operating results are impacted by several factors such as the timing of new order awards, project backlog, changes in project cost estimates, customer approval of final engineering specifications and delays in customer construction schedules, all of which contribute to short-term earnings variability and the timing of project execution. Our operating results also have been, and may continue to be, impacted by the timing and resolution of change orders and the resolution of potential contract claims and liquidated damages, all of which could improve or deteriorate gross margins during the period in which these items are resolved with our customers. Disruptions in the global supply chain have negatively impacted and may continue to negatively impact our business and operating results due to the limited supply of, delays for and uncertainty in the timing of the receipt of key component parts and commodities. We continue to remain focused on the variables that impact our markets as well as cost management, labor availability and supply chain challenges.

[0000080420-25-000152:mdna:16]
We are subject to inflation, which can cause increases in our costs of labor, indirect expenses and raw materials, primarily copper, aluminum and steel. Fixed-price contracts can limit our ability to pass these increases to our customers, thus negatively impacting our earnings and operations in future periods.

[0000080420-25-000152:mdna:17]
During Fiscal 2025, we continued experiencing high volatility in commodity prices, and ongoing supply chain delays for specific engineered components remained a persistent challenge for us. Moreover, ongoing and recently proposed changes to U.S. global trade policy, along with potential international retaliatory measures, and concerns over inflation, recession and slowing growth have continued to cause high volatility in global markets and uncertainty around short- and long-term economic impacts in the United States and other markets we serve. We continue to evaluate and monitor the potential impacts of these changes and measures, including the imposition of tariffs, on our business and operations. We could potentially face the challenge of increased costs of raw materials and engineered components as well as negative impacts on our margins; however, it is not possible to predict the impact, if any, of any changes or proposed changes to the U.S. global trade policy, or any international retaliatory measures, on our business and operations. In response to the rising cost environment and persistent supply chain challenges, we are taking strategic measures to effectively manage our product pricing, refine delivery schedules, and manage bid validity dates with our customers. Our supplier engagement includes improving forecasting and negotiating favorable terms that allow us to meet or exceed customer timelines. Additionally, we remain focused on enhancing factory efficiencies and improving project execution to mitigate risks and maintain customer satisfaction.

[0000080420-25-000152:mdna:18]
On July 4, 2025, President Trump signed into law the One Big Beautiful Bill Act (the OBBBA), which includes a broad range of tax reform provisions affecting businesses. The OBBBA extends and modifies certain key 2017 Tax Cuts & Jobs Act (TCJA) provisions (both domestic and international) and revamps some of the TCJA’s provisions on the taxation of corporations’ foreign income. The OBBBA also expands certain Inflation Reduction Act incentives while accelerating the phase-out of others. We are currently evaluating the impact of the OBBBA on our operations, financial results and liquidity.

[0000080420-25-000152:mdna:19]
Results of Operations

[0000080420-25-000152:mdna:20]
Twelve Months Ended September 30, 2025 Compared to Twelve Months Ended September 30, 2024

[0000080420-25-000152:mdna:21]
Revenue and Gross Profit

[0000080420-25-000152:mdna:22]
Revenues and costs are primarily related to custom engineered-to-order equipment and systems and are accounted for under percentage-of-completion accounting, which precludes us from providing detailed price and volume information.

[0000080420-25-000152:mdna:23]
Revenues increased by 9%, or $92.0 million, to $1.1 billion in Fiscal 2025, primarily driven by strong project backlog at the end of Fiscal 2024 and strong bookings that continued throughout Fiscal 2025. Domestic revenues increased by 4%, or $33.7 million, to $880.2 million in Fiscal 2025. International revenues increased by 35%, or $58.3 million, to $224.1 million in Fiscal 2025, primarily driven by increased project volume from our Canada operations and increased activity in the Middle East and Africa region. Our international revenues include both revenues generated from our international facilities as well as revenues from export projects generated at our domestic facilities.

[0000080420-25-000152:mdna:24]
In Fiscal 2025, revenue from our electric utility market increased by 50%, or $92.4 million, to $279.0 million; commercial and other industrial market revenue increased by 19%, or $28.3 million, to $178.2 million; and revenue from our light rail traction power market increased by 87%, or $19.2 million, to $41.3 million. These increases in revenue were primarily driven by our strategic effort to expand our business into electric utility and commercial and other industrial markets and the improved market conditions in these end markets. Revenue from our petrochemical market decreased by 19%, or $34.4 million, to $151.2 million with the reduction in backlog and bookings in this market and as the business nears completion of the large petrochemical order secured in Fiscal 2023. Revenue from our oil and gas market (excluding petrochemical) decreased by 3%, or $10.6 million, to $406.6 million and revenue from all other markets combined decreased by 6%, or $3.0 million to $48.1 million in Fiscal 2025 due to less project volume. For additional information on the markets we serve, see “Markets” in Part I, Item 1 of this Annual Report.

[0000080420-25-000152:mdna:25]
Gross profit increased by 19%, or $51.3 million, to $324.4 million in Fiscal 2025. Gross profit as a percentage of revenues increased to 29% in Fiscal 2025 as compared to 27% in Fiscal 2024. This increase in gross profit was primarily driven by higher revenues and improved gross profit margin due to favorable volume leverage and strong project execution in a stable pricing environment throughout Fiscal 2025.

[0000080420-25-000152:mdna:26]
Selling, General and Administrative Expenses

[0000080420-25-000152:mdna:27]
Selling, general and administrative expenses increased by 12%, or $10.5 million, to $95.4 million in Fiscal 2025, primarily due to higher compensation expense and costs associated with the acquisition of Remsdaq. Selling, general and administrative expenses as a percentage of revenues increased to 9% in Fiscal 2025, compared to 8% in Fiscal 2024.

[0000080420-25-000152:mdna:28]
Income Tax Provision

[0000080420-25-000152:mdna:29]
We recorded an income tax provision of $52.8 million in Fiscal 2025, resulting in an effective tax rate of 23%, compared to an income tax provision of $46.2 million in Fiscal 2024 at an effective tax rate of 24%. For both Fiscal 2025 and 2024, the effective tax rate was favorably impacted by tax benefits related to the vesting of restricted stock units and the estimated Research and Development Tax Credit, which were offset by state income tax expense and certain non-deductible items. Additionally in Fiscal 2024, these benefits were offset by an income inclusion related to U.S. global intangible income.

[0000080420-25-000152:mdna:30]
Net Income

[0000080420-25-000152:mdna:31]
In Fiscal 2025, we recorded net income of $180.7 million, or $14.86 per diluted share, compared to net income of $149.8 million, or $12.29 per diluted share in Fiscal 2024. The increase in net income was primarily driven by higher revenue and improved gross profit margin in Fiscal 2025.

[0000080420-25-000152:mdna:32]
Backlog

[0000080420-25-000152:mdna:33]
The order backlog, which is our remaining unsatisfied performance obligations, represents the estimated transaction price for goods and services for which we have a material right, but work has not been performed. The order backlog at September 30, 2025 was $1.4 billion, a 3% increase from our $1.3 billion backlog at September 30, 2024. This increase was mainly driven by electric utility, commercial and other industrial and light rail traction power markets, partially offset by a decrease in the petrochemical market. As of September 30, 2025, electric utility and oil and gas (excluding petrochemical) markets each

[0000080420-25-000152:mdna:34]
accounted for 33% of our backlog, the commercial and other industrial market accounted for 15% and the petrochemical and light rail traction power markets each accounted for 8% of our backlog.

[0000080420-25-000152:mdna:35]
Bookings, net of cancellations and scope reductions, increased by 9% in Fiscal 2025 to $1.2 billion, compared to $1.1 billion in Fiscal 2024. This increase was primarily driven by improved bookings in oil and gas, electric utility and light rail traction power markets, partially offset by decreased net bookings in the petrochemical market.

[0000080420-25-000152:mdna:36]
Liquidity and Capital Resources

[0000080420-25-000152:mdna:37]
As of September 30, 2025, current assets exceeded current liabilities by 2.1 times.

[0000080420-25-000152:mdna:38]
Cash, cash equivalents and short-term investments increased to $475.5 million at September 30, 2025, compared to $358.4 million at September 30, 2024. The increase in cash, cash equivalents and short-term investments was primarily driven by our strong earnings, partially offset by working capital commitment, cash paid for the Remsdaq acquisition, capital spending, dividend payments, and cash payments related to shares withheld in lieu of employee tax withholding. We invest our cash, cash equivalents and short-term investments in accordance with the Company’s investment policy approved by the Board of Directors. We believe that our cash, cash equivalents and short-term investments, as well as available borrowings under our U.S. credit facility, will be sufficient to support our ongoing operating activities, dividend payments and future organic and inorganic business growth, as well as research and development initiatives for the next twelve months and beyond.

[0000080420-25-000152:mdna:39]
As we assess our capital allocation framework relative to our strategic objectives, we will continue to deploy capital to both organic and inorganic initiatives, as well as maintain a prudent approach to other methods that improve shareholder value. We regularly assess our capital allocation framework. Our current intention is to prioritize our working capital needs, fund research, capital expenditures and other organic growth opportunities, while also returning capital to shareholders and evaluating strategic inorganic opportunities as they arise. Our capital allocation plan depends upon a number of factors, including market conditions, our financial position and capital requirements, financial conditions, competing uses for cash, and other factors.

[0000080420-25-000152:mdna:40]
On October 4, 2023, we entered into a third amendment (the Third Amendment) to our credit agreement with Bank of America, N.A. (as amended, the U.S. Revolver). The Third Amendment which added Texas Capital Bank as Syndication Agent and a lender, increased the amount of the revolving line of credit from $125.0 million to $150.0 million, and extended the expiry date to October 4, 2028. The aggregate commitment of $150.0 million consists of $100.0 million committed by Bank of America and $50.0 million committed by Texas Capital Bank. As amended by the Third Amendment, the lesser of (a) $60 million, (b) 60% of available cash, and (c) the aggregate face amount of the issued but undrawn letters of credit that are not cash-secured shall be deducted from consolidated funded indebtedness, when calculating the consolidated net leverage ratio. We have the option to cash collateralize all or a portion of the letters of credit outstanding, which would favorably impact the consolidated funded indebtedness calculation and the consolidated net leverage ratio. On June 26, 2024, in connection with the expected discontinuation of the publication of the Canadian Dollar Offered Rate (CDOR), we further amended the U.S. Revolver by entering into a Canadian benchmark replacement conforming changes amendment with Bank of America, N.A. that added and amended certain terms related to the replacement of the CDOR as a benchmark rate with the forward-looking term rate based on the Canadian Overnight Repo Rate Average. On September 24, 2024, in connection with the expected discontinuation of the publication of the Bloomberg Short-Term Bank Yield Index Rate as administered by the Bloomberg Index Service Limited (BSBY), we further amended the U.S. Revolver by entering into a conforming changes amendment with Bank of America, N.A. that added and amended certain terms related to the replacement of the BSBY as a benchmark rate with the Secured Overnight Financing Rate as administered by the Federal Reserve Bank of New York. On September 30, 2025, we entered into a fourth amendment to the U.S. Revolver associated with a reorganization of holding companies of our foreign subsidiaries, replacing the prior share pledge on 65% of the equity interests of Powell Industries International, B.V., with the share pledge on 65% of the equity interest of Powell Industries International Limited.

[0000080420-25-000152:mdna:41]
As of September 30, 2025, there were no amounts borrowed under the U.S. Revolver, and letters of credit outstanding were $77.5 million. There was $72.5 million available for the issuance of letters of credit and borrowings under the U.S. Revolver as of September 30, 2025. For further information regarding our debt, see Notes G. Long-Term Debt and H. Commitments and Contingencies of Notes to Consolidated Financial Statements.

[0000080420-25-000152:mdna:42]
Approximately $88.9 million of our cash, cash equivalents and short-term investments at September 30, 2025 was held outside of the U.S. for our international operations. It is our intention to indefinitely reinvest all current and future foreign earnings internationally in order to ensure sufficient working capital to support our international operations. In the event that we elect to repatriate some or all of the foreign earnings that were previously deemed to be indefinitely reinvested outside the U.S., we may incur additional tax expense upon such repatriation under current tax laws.

[0000080420-25-000152:mdna:43]
Cash Flows

[0000080420-25-000152:mdna:44]
Operating Activities

[0000080420-25-000152:mdna:45]
Operating activities provided net cash of $167.9 million during Fiscal 2025 and provided net cash of $108.7 million during Fiscal 2024. Cash flow from operations is primarily influenced by project volume and margins, as well as working capital requirements, the timing of milestone payments from our customers, and payment terms with our suppliers. The increase in operating cash flow was primarily driven by improved earnings and a steady allocation of working capital to projects in the order book.

[0000080420-25-000152:mdna:46]
Investing Activities

[0000080420-25-000152:mdna:47]
Investing activities used $8.3 million of cash during Fiscal 2025 and used $21.9 million of cash in Fiscal 2024. Cash used in investing activities during Fiscal 2025 was primarily attributable to the Remsdaq acquisition and the capital spending on the facility expansion and improvement project at our electrical products facility in Houston. The cash spending was partially offset by net maturities of short-term investments.

[0000080420-25-000152:mdna:48]
During the fourth quarter of Fiscal 2025, we completed the previously announced business acquisition of Remsdaq for a cash consideration of $10.6 million, net of cash acquired, on the acquisition date, and an additional cash payment of $0.9 million in September 2025, as Remsdaq achieved its financial target. See Note P. Business Acquisition of the Notes to Consolidated Financial Statements for additional information.

[0000080420-25-000152:mdna:49]
In Fiscal 2025, the expansion and improvement project at our electrical products facility in Houston was completed and the incremental capacity has been placed into service.

[0000080420-25-000152:mdna:50]
During Fiscal 2024, cash used in investing activities was primarily associated with the net purchase of short-term investments, a cash purchase of land and buildings in Houston, Texas for $5.6 million, and regular capital spending on property, plant and equipment.

[0000080420-25-000152:mdna:51]
Financing Activities

[0000080420-25-000152:mdna:52]
Net cash used in financing activities was $25.1 million during Fiscal 2025 compared to $19.3 million used during Fiscal 2024. The increase in cash used in financing activities was primarily due to cash payments related to shares withheld in lieu of employee tax withholding, largely driven by the significant increase in our share price during Fiscal 2025 compared to Fiscal 2024.

[0000080420-25-000152:mdna:53]
Planned Capital Spending

[0000080420-25-000152:mdna:54]
In August 2025, we announced a $12.4 million investment to expand production capacity at our Jacintoport manufacturing facility in Houston, Texas. The investment will add an incremental 335,000 square feet of productive capacity for Power Control Room laydown area, a 62% increase from the current yard capacity. The investment will also double the length of the existing shoreline bulkhead to 1,150 feet to support increased schedule flexibility and multiple ship lanes for the varied needs and project timelines of our customers. The incremental capacity is initially expected to support the Company’s oil and gas customers but can be utilized to support each of our market sectors.

[0000080420-25-000152:mdna:55]
Construction is expected to begin in the first quarter of Fiscal 2026 and is expected to be completed in the second half of Fiscal 2026.

[0000080420-25-000152:mdna:56]
Other Commercial Commitments

[0000080420-25-000152:mdna:57]
We are contingently liable for letters of credit and bank guarantees totaling $81.4 million as of September 30, 2025, with the following potential cash outflows in the event that we are unable to perform under our contracts (in thousands):

[0000080420-25-000152:mdna:58]
| Payments Due by Period: | Letters ofCredit/ Bank Guarantees |
| Less than 1 year | $ | 38,919 |  |
| 1 to 3 years | 35,426 |  |
| More than 3 years | 7,099 |  |
| Total commercial commitments | $ | 81,444 |  |

[0000080420-25-000152:mdna:59]
We also had surety bonds totaling $417.3 million that were outstanding at September 30, 2025. Surety bonds are primarily used to guarantee our contract performance to our customers.

[0000080420-25-000152:mdna:60]
Off-Balance Sheet Arrangements

[0000080420-25-000152:mdna:61]
We had no significant off-balance sheet arrangements during the periods presented.

[0000080420-25-000152:mdna:62]
Critical Accounting Estimates

[0000080420-25-000152:mdna:63]
The preparation of consolidated financial statements in conformity with accounting principles generally accepted in the United States (U.S. GAAP) requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities, disclosures of contingent assets and liabilities known to exist at the date of the consolidated financial statements and the reported amounts of revenues and expenses during the reporting period. We evaluate our estimates on an ongoing basis, based on historical experience and on various other assumptions that are believed to be reasonable under the circumstances. There can be no assurance that actual results will be consistent with those estimates.

[0000080420-25-000152:mdna:64]
We believe the following accounting estimates to be critical in the preparation and reporting of our consolidated financial statements.

[0000080420-25-000152:mdna:65]
Revenue Recognition

[0000080420-25-000152:mdna:66]
Our revenues are primarily generated from the manufacturing of custom-engineered products and systems under long-term fixed-price contracts under which we agree to manufacture various products such as traditional and arc-resistant distribution switchgear and control gear, medium-voltage circuit breakers, monitoring and control communications systems, motor control centers, switches and bus duct systems. These products may be sold separately as an engineered solution, but are typically integrated into custom-built enclosures which we also build. These enclosures are referred to as power control room substations (PCRs®), custom-engineered modules or electrical houses (E-Houses). Some contracts may also include the installation and commissioning of these enclosures.

[0000080420-25-000152:mdna:67]
Revenue from these contracts is generally recognized over time utilizing the cost-to-cost method. Under the cost-to-cost method, the extent of progress towards completion is measured based on the ratio of costs incurred to date to the total estimated costs at completion of the performance obligation. We believe that this method is the most accurate representation of our performance because it directly measures the value of the services transferred to the customer over time as we incur costs on our contracts. Contract costs include all direct materials, labor and indirect costs related to contract performance, which may include indirect labor, supplies, tools, repairs and depreciation costs.

[0000080420-25-000152:mdna:68]
Performance Obligations

[0000080420-25-000152:mdna:69]
A performance obligation is a promise in a contract or with a customer to transfer a distinct good or service. A contract’s transaction price is allocated to each distinct performance obligation and recognized as revenue as the performance obligations are satisfied. To determine the proper revenue recognition for contracts, we evaluate whether a contract should be accounted for as more than one performance obligation or, less commonly, whether two or more contracts should be combined and accounted for as one performance obligation. This evaluation of performance obligations requires significant judgment. The majority of our contracts have a single performance obligation where multiple engineered products and services are combined into a single custom-engineered solution. Our contracts include a standard one-year assurance warranty. Occasionally, we provide service-type warranties that will extend the warranty period. These extended warranties qualify as separate performance obligations, and revenue is deferred and recognized over the warranty period. If we determine during the evaluation of the contract that there are multiple performance obligations, we allocate the transaction price to each performance obligation using our best estimate of the standalone selling price of each distinct good or service in the contract.

[0000080420-25-000152:mdna:70]
Contract Estimates

[0000080420-25-000152:mdna:71]
Actual revenues and project costs may vary from previous estimates due to changes in a variety of factors. The cost estimation process is based on the professional knowledge and experience of our engineers, project managers and financial professionals. Factors that are considered in estimating the work to be completed and ultimate contract recovery include the availability and productivity of labor, the nature and complexity of the work to be performed, the availability of materials, and the effect of any delays on our project performance. We periodically review our job performance, job conditions, estimated profitability and final contract settlements, including our estimate of total costs and make revisions to costs and income in the period in which the revisions are probable and reasonably estimable. We bear the risk of cost overruns in most of our contracts, which may result in

[0000080420-25-000152:mdna:72]
reduced profits. Whenever revisions of estimated contract costs and contract values indicate that the contract costs will exceed estimated revenues, thus creating a loss, a provision for the total estimated loss is recorded in that period. See Note E. Revenue of the Notes to Consolidated Financial Statements for disclosures related to changes in contract estimates.

[0000080420-25-000152:mdna:73]
Variable Consideration

[0000080420-25-000152:mdna:74]
It is common for our long-term contracts to contain variable consideration that can either increase or decrease the transaction price. Due to the nature of our contracts, estimating total cost and revenue can be complex and subject to variability due to change orders, back charges, spare parts, early completion bonuses, customer allowances and liquidated damages. We estimate the amount of variable consideration based on the expected value method, which is the sum of the probability-weighted amounts, or the most likely amount method, which uses various factors including experience with similar transactions and assessment of our anticipated performance. Variable consideration is included in the transaction price if legally enforceable and to the extent it is probable that a significant reversal of cumulative revenue recognized will not occur once the uncertainty associated with the variable consideration is resolved.

[0000080420-25-000152:mdna:75]
Contract Modifications

[0000080420-25-000152:mdna:76]
Contracts may be modified for changes in contract specifications and requirements. We consider contract modifications to exist when the modification either creates new or changes the enforceable rights and obligations under the contract. Most of our contract modifications are for goods and services that are not distinct from the existing performance obligation. Contract modifications result in a cumulative catch-up adjustment to revenue based on our measure of progress for the performance obligation.

[0000080420-25-000152:mdna:77]
Impairment of Long-Lived Assets

[0000080420-25-000152:mdna:78]
We review long-lived assets for impairment whenever events or changes in circumstances indicate that the carrying value may not be realizable. If an evaluation is required, the estimated future undiscounted cash flows associated with the asset are compared to the asset’s carrying amount to determine if recording an impairment of such asset is necessary. This requires us to make long-term forecasts of the future revenues and costs related to the assets subject to review. Forecasts require assumptions about demand for our products and future market conditions. Estimating future cash flows requires significant judgment, and our projections may vary from cash flows eventually realized. Future events and unanticipated changes to assumptions could require a provision for impairment in a future period. The effect of any impairment would be reflected in operating income in the Consolidated Statements of Operations. In addition, we estimate the useful lives of our long-lived assets and other intangibles, and periodically review these estimates to determine whether these lives are appropriate.

[0000080420-25-000152:mdna:79]
Accruals for Contingent Liabilities

[0000080420-25-000152:mdna:80]
From time to time, contingencies such as insurance-related claims, liquidated damages and legal claims arise in the normal course of business. Pursuant to applicable accounting standards, we must evaluate such contingencies to subjectively determine the likelihood that an asset has been impaired, or a liability has been incurred at the date of the financial statements, as well as evaluate whether the amount of the loss can be reasonably estimated. If the likelihood is determined to be probable, and it can be reasonably estimated, the estimated loss is recorded. The amounts we record for contingent liabilities require judgments regarding the amount of expenses that will ultimately be incurred. We use past experience and history, as well as the specific circumstances surrounding each contingent liability, including estimated legal costs, in evaluating the amount of liability that should be recorded. Actual results could differ from our estimates.

[0000080420-25-000152:mdna:81]
Warranty Costs

[0000080420-25-000152:mdna:82]
Estimated costs of warranties are accrued based on historical warranty claim costs in relation to current revenues. In addition, specific provisions are made when product failures are projected outside historical experience. Our standard terms and conditions of sale include a warranty for parts and service for one year. Occasionally, we provide service-type warranties that will extend the warranty period. Actual results could differ from our estimate.

[0000080420-25-000152:mdna:83]
Projects may require, on occasion, warranty terms that are longer than our standard terms due to the nature of the project. Extended warranty terms may be negotiated and included in our contracts. The allocated revenue associated with the extended warranty is deferred and recorded as a contract liability and recognized as revenue over the extended warranty period.

[0000080420-25-000152:mdna:84]
Accounting for Income Taxes

[0000080420-25-000152:mdna:85]
We account for income taxes under the asset and liability method, based on the income tax laws and rates in the countries in which operations are conducted, and income is earned. This approach requires the recognition of deferred tax assets and liabilities for the expected future tax consequences of temporary differences between the carrying amounts and the tax basis of assets and liabilities. Developing our provision for income taxes requires significant judgment and expertise in federal, international and state income tax laws, regulations and strategies, including the determination of deferred tax assets and liabilities and, if necessary, any valuation allowances that may be required for deferred tax assets. In assessing the extent to which net deferred tax assets may be realized, we consider whether it is more likely than not that some portion or all of the net deferred tax assets may not be realized. The ultimate realization of net deferred tax assets is dependent on the generation of future taxable income during the periods in which those temporary differences become deductible. Estimates may change as new events occur, estimates of future taxable income during the carryforward period are reduced or increased, additional information becomes available, or operating environments change, which may result in a full or partial reversal of the valuation allowance. We will continue to assess the adequacy of the valuation allowance on a quarterly basis. Our judgments and tax strategies are subject to audit by various taxing authorities.

[0000080420-25-000152:mdna:86]
The objectives of accounting for income taxes are to recognize the amount of taxes payable or refundable for the current year and deferred tax liabilities and assets for the future tax consequences of events that have been recognized in an entity’s financial statements or tax returns. We recognize the tax benefit from an uncertain tax position only if it is more likely than not that the tax position will be sustained on examination by the taxing authorities, based on the technical merits of the position. The tax benefits recognized in the financial statements from such a position should be measured based on the largest benefit that has a greater than 50% likelihood of being realized upon ultimate settlement. Accounting literature also provides guidance on derecognition of income tax assets and liabilities, classification of current and deferred income tax assets and liabilities, accounting for interest and penalties associated with tax positions, and income tax disclosures. Judgment is required in assessing the future tax consequences of events that have been recognized in our financial statements or tax returns. Variations in the actual outcome of these future tax consequences could materially impact our financial position and results of operations.

[0000080420-25-000152:mdna:87]
See Note I. Income Taxes of the Notes to Consolidated Financial Statements for disclosures related to the valuation allowance recorded in relation to deferred taxes.

[0000080420-25-000152:mdna:88]
33
