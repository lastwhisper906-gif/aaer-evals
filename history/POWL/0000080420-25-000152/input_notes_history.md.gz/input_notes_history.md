# POWL note change history — 0000080420-25-000061 → 0000080420-25-000098


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2025-08-06):
[0000080420-25-000098:note_history:1]
Certain customers require us to post letters of credit, bank guarantees or surety bonds. These security instruments assure that we will perform under the terms of our contract. In the event of default, the counterparty may demand payment from the bank under a letter of credit or bank guarantee, or performance by the surety under a bond. To date, there have been no significant draws or claims related to security instruments for the periods reported. We were contingently liable for letters of credit of $76.0 million as of June 30, 2025. We also had surety bonds totaling $432.6 million that were outstanding, with additional bonding capacity of $767.4 million available, at June 30, 2025. We have strong surety relationships; however, a change in market conditions or the sureties' assessment of our financial position could cause the sureties to require cash collateralization for undischarged liabilities under the bonds.
  (was, 2025-05-07, similarity 0.9901):
[0000080420-25-000061:note_history:1]
Certain customers require us to post letters of credit, bank guarantees or surety bonds. These security instruments assure that we will perform under the terms of our contract. In the event of default, the counterparty may demand payment from the bank under a letter of credit or bank guarantee, or performance by the surety under a bond. To date, there have been no significant draws or claims related to security instruments for the periods reported. We were contingently liable for letters of credit of $64.4 million as of March 31, 2025. We also had surety bonds totaling $420.3 million that were outstanding, with additional bonding capacity of $779.7 million available, at March 31, 2025. We have strong surety relationships; however, a change in market conditions or the sureties' assessment of our financial position could cause the sureties to require cash collateralization for undischarged liabilities under the bonds.

- changed (2025-08-06):
[0000080420-25-000098:note_history:2]
We have a $20.5 million facility agreement (Facility Agreement) between Powell (UK) Limited and a large international bank that provides Powell (UK) Limited the ability to enter into bank guarantees as well as forward exchange contracts and currency options. At June 30, 2025, we had outstanding guarantees totaling $7.0 million, with an additional capacity of $13.5 million available under this Facility Agreement. The Facility Agreement provides for customary events of default and carries cross-default provisions with the U.S. Revolver. If an event of default (as defined in the Facility Agreement) occurs and is continuing, per the terms and subject to the conditions set forth therein, obligations outstanding under the Facility Agreement may be accelerated and declared immediately due and payable. Additionally, we are required to maintain cash collateral for guarantees greater than two years. As of June 30, 2025, we were in compliance with all of the financial covenants of the Facility Agreement.
  (was, 2025-05-07, similarity 0.9909):
[0000080420-25-000061:note_history:2]
We have a $19.4 million facility agreement (Facility Agreement) between Powell (UK) Limited and a large international bank that provides Powell (UK) Limited the ability to enter into bank guarantees as well as forward exchange contracts and currency options. At March 31, 2025, we had outstanding guarantees totaling $4.0 million, with an additional capacity of $15.4 million available under this Facility Agreement. The Facility Agreement provides for customary events of default and carries cross-default provisions with the U.S. Revolver. If an event of default (as defined in the Facility Agreement) occurs and is continuing, per the terms and subject to the conditions set forth therein, obligations outstanding under the Facility Agreement may be accelerated and declared immediately due and payable. Additionally, we are required to maintain cash collateral for guarantees greater than two years. As of March 31, 2025, we were in compliance with all of the financial covenants of the Facility Agreement.

- changed (2025-08-06):
[0000080420-25-000098:note_history:3]
Certain of our customer contracts have schedule and performance obligation clauses that, if we fail to meet them, could require us to pay liquidated damages. Each individual contract defines the conditions under which the customer may make a claim against us. As of June 30, 2025, certain contracts had a probable exposure to liquidated damages claims of $2.9 million, which could possibly increase to $4.0 million under certain circumstances. Based on our actual or projected failure to meet these various contractual commitments, $2.7 million has been recorded as a reduction to revenue. We will attempt to obtain change orders, contract extensions or accelerate project completion, which may resolve the potential for any unrecorded liquidated damages claims. Should we fail to achieve relief on some or all of these contractual obligations, we could be required to pay additional liquidated damages, which could negatively impact our future operating results.
  (was, 2025-05-07, similarity 0.9953):
[0000080420-25-000061:note_history:3]
Certain of our customer contracts have schedule and performance obligation clauses that, if we fail to meet them, could require us to pay liquidated damages. Each individual contract defines the conditions under which the customer may make a claim against us. As of March 31, 2025, certain contracts had a probable exposure to liquidated damages claims of $2.7 million, which could possibly increase to $3.6 million under certain circumstances. Based on our actual or projected failure to meet these various contractual commitments, $2.5 million has been recorded as a reduction to revenue. We will attempt to obtain change orders, contract extensions or accelerate project completion, which may resolve the potential for any unrecorded liquidated damages claims. Should we fail to achieve relief on some or all of these contractual obligations, we could be required to pay additional liquidated damages, which could negatively impact our future operating results.


## us-gaap:LongTermDebtTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2025-08-06):
[0000080420-25-000098:note_history:4]
As of June 30, 2025, there were no amounts borrowed under the U.S. Revolver, and letters of credit outstanding were $76.0 million. There was $74.0 million available for the issuance of letters of credit and borrowings under the U.S. Revolver as of June 30, 2025.
  (was, 2025-05-07, similarity 0.9469):
[0000080420-25-000061:note_history:4]
As of March 31, 2025, there were no amounts borrowed under the U.S. Revolver, and letters of credit outstanding were $64.4 million. There was $85.6 million available for the issuance of letters of credit and borrowings under the U.S. Revolver as of March 31, 2025.

- changed (2025-08-06):
[0000080420-25-000098:note_history:5]
As of June 30, 2025, we were in compliance with all of the financial covenants of the U.S. Revolver.
  (was, 2025-05-07, similarity 0.9524):
[0000080420-25-000061:note_history:5]
As of March 31, 2025, we were in compliance with all of the financial covenants of the U.S. Revolver.


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2025-08-06):
[0000080420-25-000098:note_history:6]
The following tables present our disaggregated revenue by geographic destination and market sector for the three and nine months ended June 30, 2025 and 2024 (in thousands):
  (was, 2025-05-07, similarity 0.9576):
[0000080420-25-000061:note_history:6]
The following tables present our disaggregated revenue by geographic destination and market sector for the three and six months ended March 31, 2025 and 2024 (in thousands):

- changed (2025-08-06):
[0000080420-25-000098:note_history:7]
|  | Three months ended June 30, |  | Nine months ended June 30, |
|  | 2025 |  | 2024 |  | 2025 |  | 2024 |
| United States | $ | 224,537 |  |  | $ | 243,744 |  |  | $ | 650,143 |  |  | $ | 620,537 |  |
| Canada | 42,611 |  |  | 29,695 |  |  | 108,275 |  |  | 74,205 |  |
| Europe | 5,522 |  |  | 9,464 |  |  | 16,947 |  |  | 24,261 |  |
| Middle East and Africa | 9,917 |  |  | 2,322 |  |  | 22,757 |  |  | 8,400 |  |
| Mexico, Central and South America | 1,881 |  |  | 1,962 |  |  | 3,182 |  |  | 6,778 |  |
| Asia/Pacific | 1,805 |  |  | 981 |  |  | 5,031 |  |  | 3,112 |  |
| Total revenues by geographic destination | $ | 286,273 |  |  | $ | 288,168 |  |  | $ | 806,335 |  |  | $ | 737,293 |  |
  (was, 2025-05-07, similarity 0.9324):
[0000080420-25-000061:note_history:7]
|  | Three months ended March 31, |  | Six months ended March 31, |
|  | 2025 |  | 2024 |  | 2025 |  | 2024 |
| United States | $ | 227,834 |  |  | $ | 216,933 |  |  | $ | 425,606 |  |  | $ | 376,793 |  |
| Canada | 33,970 |  |  | 24,160 |  |  | 65,664 |  |  | 44,510 |  |
| Europe | 5,897 |  |  | 8,265 |  |  | 11,425 |  |  | 14,797 |  |
| Middle East and Africa | 8,282 |  |  | 2,803 |  |  | 12,840 |  |  | 6,078 |  |
| Mexico, Central and South America | 1,002 |  |  | 2,159 |  |  | 1,301 |  |  | 4,816 |  |
| Asia/Pacific | 1,646 |  |  | 788 |  |  | 3,226 |  |  | 2,131 |  |
| Total revenues by geographic destination | $ | 278,631 |  |  | $ | 255,108 |  |  | $ | 520,062 |  |  | $ | 449,125 |  |

- changed (2025-08-06):
[0000080420-25-000098:note_history:8]
|  | Three months ended June 30, |  | Nine months ended June 30, |
|  | 2025 |  | 2024 |  | 2025 |  | 2024 |
| Oil and gas (excludes petrochemical) | $ | 105,464 |  |  | $ | 114,336 |  |  | $ | 302,310 |  |  | $ | 301,792 |  |
| Petrochemical | 36,349 |  |  | 56,784 |  |  | 113,236 |  |  | 135,221 |  |
| Electric utility | 74,909 |  |  | 57,009 |  |  | 196,488 |  |  | 145,214 |  |
| Commercial and other industrial | 49,519 |  |  | 42,044 |  |  | 134,188 |  |  | 101,610 |  |
| Light rail traction power | 8,549 |  |  | 5,322 |  |  | 26,785 |  |  | 14,184 |  |
| All others | 11,483 |  |  | 12,673 |  |  | 33,328 |  |  | 39,272 |  |
| Total revenues by market sector | $ | 286,273 |  |  | $ | 288,168 |  |  | $ | 806,335 |  |  | $ | 737,293 |  |
  (was, 2025-05-07, similarity 0.9363):
[0000080420-25-000061:note_history:8]
|  | Three months ended March 31, |  | Six months ended March 31, |
|  | 2025 |  | 2024 |  | 2025 |  | 2024 |
| Oil and gas (excludes petrochemical) | $ | 101,167 |  |  | $ | 103,820 |  |  | $ | 196,846 |  |  | $ | 187,456 |  |
| Petrochemical | 43,704 |  |  | 50,070 |  |  | 76,887 |  |  | 78,437 |  |
| Electric utility | 70,339 |  |  | 47,502 |  |  | 121,579 |  |  | 88,205 |  |
| Commercial and other industrial | 40,369 |  |  | 34,894 |  |  | 84,669 |  |  | 59,566 |  |
| Light rail traction power | 10,008 |  |  | 4,517 |  |  | 18,236 |  |  | 8,862 |  |
| All others | 13,044 |  |  | 14,305 |  |  | 21,845 |  |  | 26,599 |  |
| Total revenues by market sector | $ | 278,631 |  |  | $ | 255,108 |  |  | $ | 520,062 |  |  | $ | 449,125 |  |


## us-gaap:RevenueFromContractWithCustomerPolicyTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2025-08-06):
[0000080420-25-000098:note_history:9]
We also have contracts to provide field service inspection, installation, commissioning, modification, and repair services, as well as retrofit and retrofill components for existing systems. If the service contract terms give us the right to invoice the customer for an amount that corresponds directly with the value of our performance completed to date (i.e., a service contract in which we bill a fixed amount for each hour of service provided), then we recognize revenue over time in each reporting period corresponding to the amount that we have the right to invoice. Our performance obligations are satisfied as the work progresses. Revenues from our custom-engineered products and value-added services transferred to customers over time accounted for approximately 95% and 96% of revenues for the three and nine months ended June 30, 2025, respectively, and approximately 96% and 95% of revenues for the three and nine months ended June 30, 2024, respectively.
  (was, 2025-05-07, similarity 0.8611):
[0000080420-25-000061:note_history:9]
We also have contracts to provide field service inspection, installation, commissioning, modification, and repair services, as well as retrofit and retrofill components for existing systems. If the service contract terms give us the right to invoice the customer for an amount that corresponds directly with the value of our performance completed to date (i.e., a service contract in which we bill a fixed amount for each hour of service provided), then we recognize revenue over time in each reporting period corresponding to the amount that we have the right to invoice. Our performance obligations are satisfied as the work progresses. Revenues from our custom-engineered products and value-added services transferred to customers over time accounted for approximately 95% of revenues for the three months ended March 31, 2025, 96% of revenues for the six months ended March 31, 2025, 95% of revenues for the three months ended March 31, 2024, and 94% of revenues for the six months ended March 31, 2024.

- changed (2025-08-06):
[0000080420-25-000098:note_history:10]
We also have sales orders for spare parts and replacement circuit breakers for switchgear that are obsolete or that are no longer produced by the original manufacturer. Revenues from these sales orders are recognized at the time we fulfill our performance obligation to the customer, which is typically upon shipment and represented approximately 5% and 4% of revenues for the three and nine months ended June 30, 2025, respectively, and approximately 4% and 5% of revenues for the three and nine months ended June 30, 2024, respectively.
  (was, 2025-05-07, similarity 0.6981):
[0000080420-25-000061:note_history:10]
We also have sales orders for spare parts and replacement circuit breakers for switchgear that are obsolete or that are no longer produced by the original manufacturer. Revenues from these sales orders are recognized at the time we fulfill our performance obligation to the customer, which is typically upon shipment and represented approximately 5% of revenues for the three months ended March 31, 2025, 4% of revenues for the six months ended March 31, 2025, 5% of revenues for the three months ended March 31, 2024, and 6% of revenues for the six months ended March 31, 2024.

- added (2025-08-06):
[0000080420-25-000098:note_history:11]
Additionally, some contracts may contain a cancellation clause that could limit the amount of revenue we are able to recognize over time. In these instances, revenue and costs associated with these contracts are deferred and recognized at a point in time when the performance obligation is fulfilled.

- changed (2025-08-06):
[0000080420-25-000098:note_history:12]
Selling and administrative costs incurred in relation to obtaining a contract are typically expensed as incurred. We periodically utilize a third-party sales agent to obtain a contract and will pay a commission to that agent. We record the full commission liability to the third-party sales agents at the order date, with a corresponding deferred asset. As the project progresses, we record commission expense based on percentage of completion rates that correlate to the project and reduce the deferred asset. Once we have been paid by the customer, we pay the commission and the liability is reduced.
  (was, 2025-05-07, similarity 0.7134):
[0000080420-25-000061:note_history:12]
Additionally, some contracts may contain a cancellation clause that could limit the amount of revenue we are able to recognize over time. In these instances, revenue and costs associated with these contracts are deferred and recognized at a point in time when the performance obligation is fulfilled.
Selling and administrative costs incurred in relation to obtaining a contract are typically expensed as incurred. We periodically utilize a third-party sales agent to obtain a contract and will pay a commission to that agent. We record the full commission liability to the third-party sales agents at the order date, with a corresponding deferred asset. As the project progresses, we record commission expense based on percentage of completion rates that correlate to the project and reduce the deferred asset. Once we have been paid by the customer, we pay the commission and the liability is reduced
Performance Obligations

- added (2025-08-06):
[0000080420-25-000098:note_history:13]
Performance Obligations


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2025-08-06):
[0000080420-25-000098:note_history:14]
We also have contracts to provide field service inspection, installation, commissioning, modification, and repair services, as well as retrofit and retrofill components for existing systems. If the service contract terms give us the right to invoice the customer for an amount that corresponds directly with the value of our performance completed to date (i.e., a service contract in which we bill a fixed amount for each hour of service provided), then we recognize revenue over time in each reporting period corresponding to the amount that we have the right to invoice. Our performance obligations are satisfied as the work progresses. Revenues from our custom-engineered products and value-added services transferred to customers over time accounted for approximately 95% and 96% of revenues for the three and nine months ended June 30, 2025, respectively, and approximately 96% and 95% of revenues for the three and nine months ended June 30, 2024, respectively.
  (was, 2025-05-07, similarity 0.8611):
[0000080420-25-000061:note_history:14]
We also have contracts to provide field service inspection, installation, commissioning, modification, and repair services, as well as retrofit and retrofill components for existing systems. If the service contract terms give us the right to invoice the customer for an amount that corresponds directly with the value of our performance completed to date (i.e., a service contract in which we bill a fixed amount for each hour of service provided), then we recognize revenue over time in each reporting period corresponding to the amount that we have the right to invoice. Our performance obligations are satisfied as the work progresses. Revenues from our custom-engineered products and value-added services transferred to customers over time accounted for approximately 95% of revenues for the three months ended March 31, 2025, 96% of revenues for the six months ended March 31, 2025, 95% of revenues for the three months ended March 31, 2024, and 94% of revenues for the six months ended March 31, 2024.

- changed (2025-08-06):
[0000080420-25-000098:note_history:15]
We also have sales orders for spare parts and replacement circuit breakers for switchgear that are obsolete or that are no longer produced by the original manufacturer. Revenues from these sales orders are recognized at the time we fulfill our performance obligation to the customer, which is typically upon shipment and represented approximately 5% and 4% of revenues for the three and nine months ended June 30, 2025, respectively, and approximately 4% and 5% of revenues for the three and nine months ended June 30, 2024, respectively.
  (was, 2025-05-07, similarity 0.6981):
[0000080420-25-000061:note_history:15]
We also have sales orders for spare parts and replacement circuit breakers for switchgear that are obsolete or that are no longer produced by the original manufacturer. Revenues from these sales orders are recognized at the time we fulfill our performance obligation to the customer, which is typically upon shipment and represented approximately 5% of revenues for the three months ended March 31, 2025, 4% of revenues for the six months ended March 31, 2025, 5% of revenues for the three months ended March 31, 2024, and 6% of revenues for the six months ended March 31, 2024.

- changed (2025-08-06):
[0000080420-25-000098:note_history:16]
Remaining unsatisfied performance obligations, which we refer to as backlog, represent the estimated transaction price for goods and services for which we have a material right, but work has not been performed. As of June 30, 2025, we had backlog of $1.4 billion, of which approximately $913 million is expected to be recognized as revenue within the next twelve months.
  (was, 2025-05-07, similarity 0.769):
[0000080420-25-000061:note_history:16]
Remaining unsatisfied performance obligations, which we refer to as backlog, represent the estimated transaction price for goods and services for which we have a material right, but work has not been performed. As of March 31, 2025, we had

- added (2025-08-06):
[0000080420-25-000098:note_history:17]
Backlog may not be indicative of future operating results as orders may be cancelled or modified by our customers. Our backlog does not include service and maintenance-type contracts for which we have the right to invoice as services are performed.

- changed (2025-08-06):
[0000080420-25-000098:note_history:18]
For the nine months ended June 30, 2025 and 2024, our operating results were positively impacted by $15.1 million and $14.2 million, respectively, as a result of net changes in contract estimates related to projects in progress at the beginning of the respective period. These changes in estimates resulted primarily from favorable project execution, reduced cost estimates and negotiations of variable consideration, discussed below, as well as revenue recognized from project cancellations and other changes in facts and circumstances during these periods. Gross unfavorable changes in contract estimates were immaterial for both the nine months ended June 30, 2025 and 2024.
  (was, 2025-05-07, similarity 0.9173):
[0000080420-25-000061:note_history:18]
For the six months ended March 31, 2025 and 2024, our operating results were positively impacted by $8.8 million and $7.8 million, respectively, as a result of net changes in contract estimates related to projects in progress at the beginning of the respective period. These changes in estimates resulted primarily from favorable project execution, reduced cost estimates and negotiations of variable consideration, discussed below, as well as revenue recognized from project cancellations and other changes in facts and circumstances during these periods. Gross unfavorable changes in contract estimates were immaterial for both the six months ended March 31, 2025 and 2024.

- changed (2025-08-06):
[0000080420-25-000098:note_history:19]
Contract assets and liabilities as of June 30, 2025 and September 30, 2024 are summarized below (in thousands):
  (was, 2025-05-07, similarity 0.9557):
[0000080420-25-000061:note_history:19]
Contract assets and liabilities as of March 31, 2025 and September 30, 2024 are summarized below (in thousands):

- changed (2025-08-06):
[0000080420-25-000098:note_history:20]
|  | June 30, 2025 |  | September 30, 2024 |
| Contract assets | $ | 133,015 |  |  | $ | 102,827 |  |
| Contract liabilities | (299,512) |  |  | (287,763) |  |
| Net contract liability | $ | (166,497) |  |  | $ | (184,936) |  |
  (was, 2025-05-07, similarity 0.9736):
[0000080420-25-000061:note_history:20]
|  | March 31, 2025 |  | September 30, 2024 |
| Contract assets | $ | 115,943 |  |  | $ | 102,827 |  |
| Contract liabilities | (283,372) |  |  | (287,763) |  |
| Net contract liability | $ | (167,429) |  |  | $ | (184,936) |  |

- changed (2025-08-06):
[0000080420-25-000098:note_history:21]
Our net contract billing position remained a net liability at both June 30, 2025 and September 30, 2024, primarily due to favorable contract billing milestones. We typically allocate a significant percentage of the progress billing to the early stages of the contract. To determine the amount of revenue recognized during the period from contract liabilities, we first allocate revenue to the individual contract liability balance outstanding at the beginning of the period until the revenue exceeds that balance. During the nine months ended June 30, 2025, we recognized revenue of $244.4 million that was related to contract liabilities outstanding at September 30, 2024.
  (was, 2025-05-07, similarity 0.959):
[0000080420-25-000061:note_history:21]
Our net contract billing position remained a net liability at both March 31, 2025 and September 30, 2024, primarily due to favorable contract billing milestones. We typically allocate a significant percentage of the progress billing to the early stages of the contract. To determine the amount of revenue recognized during the period from contract liabilities, we first allocate revenue to the individual contract liability balance outstanding at the beginning of the period until the revenue exceeds that balance. During the six months ended March 31, 2025, we recognized revenue of $203.4 million that was related to contract liabilities outstanding at September 30, 2024.

- changed (2025-08-06):
[0000080420-25-000098:note_history:22]
The timing of our invoice process is typically dependent on the completion of certain milestones and contract terms and subject to agreement by our customer. Payment is typically expected within 30 days of invoice. Any uncollected invoiced amounts for our performance obligations recognized over time, including contract retentions, are recorded as accounts receivable in the Condensed Consolidated Balance Sheets. Certain contracts allow customers to withhold a small percentage of billings pursuant to retainage provisions, and such amounts are generally due upon completion of the contract and acceptance of the project by the customer. Based on our experience in recent years, the majority of these retainage balances are expected to be collected within approximately twelve months. As of June 30, 2025 and September 30, 2024, we had retention amounts of $8.0 million and $7.1 million, respectively. Of the retained amount at June 30, 2025, $7.5 million is expected to be collected in the next twelve months and is recorded in accounts receivable. The remaining $0.5 million is recorded in other assets.
  (was, 2025-05-07, similarity 0.9917):
[0000080420-25-000061:note_history:22]
The timing of our invoice process is typically dependent on the completion of certain milestones and contract terms and subject to agreement by our customer. Payment is typically expected within 30 days of invoice. Any uncollected invoiced amounts for our performance obligations recognized over time, including contract retentions, are recorded as accounts receivable in the Condensed Consolidated Balance Sheets. Certain contracts allow customers to withhold a small percentage of billings pursuant to retainage provisions, and such amounts are generally due upon completion of the contract and acceptance of the project by the customer. Based on our experience in recent years, the majority of these retainage balances are expected to be collected within approximately twelve months. As of March 31, 2025 and September 30, 2024, we had retention amounts of $7.9 million and $7.1 million, respectively. Of the retained amount at March 31, 2025, $7.6 million is expected to be collected in the next twelve months and is recorded in accounts receivable. The remaining $0.3 million is recorded in other assets.

- changed (2025-08-06):
[0000080420-25-000098:note_history:23]
The following tables present our disaggregated revenue by geographic destination and market sector for the three and nine months ended June 30, 2025 and 2024 (in thousands):
  (was, 2025-05-07, similarity 0.9576):
[0000080420-25-000061:note_history:23]
The following tables present our disaggregated revenue by geographic destination and market sector for the three and six months ended March 31, 2025 and 2024 (in thousands):

- changed (2025-08-06):
[0000080420-25-000098:note_history:24]
|  | Three months ended June 30, |  | Nine months ended June 30, |
|  | 2025 |  | 2024 |  | 2025 |  | 2024 |
| United States | $ | 224,537 |  |  | $ | 243,744 |  |  | $ | 650,143 |  |  | $ | 620,537 |  |
| Canada | 42,611 |  |  | 29,695 |  |  | 108,275 |  |  | 74,205 |  |
| Europe | 5,522 |  |  | 9,464 |  |  | 16,947 |  |  | 24,261 |  |
| Middle East and Africa | 9,917 |  |  | 2,322 |  |  | 22,757 |  |  | 8,400 |  |
| Mexico, Central and South America | 1,881 |  |  | 1,962 |  |  | 3,182 |  |  | 6,778 |  |
| Asia/Pacific | 1,805 |  |  | 981 |  |  | 5,031 |  |  | 3,112 |  |
| Total revenues by geographic destination | $ | 286,273 |  |  | $ | 288,168 |  |  | $ | 806,335 |  |  | $ | 737,293 |  |
  (was, 2025-05-07, similarity 0.9324):
[0000080420-25-000061:note_history:24]
|  | Three months ended March 31, |  | Six months ended March 31, |
|  | 2025 |  | 2024 |  | 2025 |  | 2024 |
| United States | $ | 227,834 |  |  | $ | 216,933 |  |  | $ | 425,606 |  |  | $ | 376,793 |  |
| Canada | 33,970 |  |  | 24,160 |  |  | 65,664 |  |  | 44,510 |  |
| Europe | 5,897 |  |  | 8,265 |  |  | 11,425 |  |  | 14,797 |  |
| Middle East and Africa | 8,282 |  |  | 2,803 |  |  | 12,840 |  |  | 6,078 |  |
| Mexico, Central and South America | 1,002 |  |  | 2,159 |  |  | 1,301 |  |  | 4,816 |  |
| Asia/Pacific | 1,646 |  |  | 788 |  |  | 3,226 |  |  | 2,131 |  |
| Total revenues by geographic destination | $ | 278,631 |  |  | $ | 255,108 |  |  | $ | 520,062 |  |  | $ | 449,125 |  |

- changed (2025-08-06):
[0000080420-25-000098:note_history:25]
|  | Three months ended June 30, |  | Nine months ended June 30, |
|  | 2025 |  | 2024 |  | 2025 |  | 2024 |
| Oil and gas (excludes petrochemical) | $ | 105,464 |  |  | $ | 114,336 |  |  | $ | 302,310 |  |  | $ | 301,792 |  |
| Petrochemical | 36,349 |  |  | 56,784 |  |  | 113,236 |  |  | 135,221 |  |
| Electric utility | 74,909 |  |  | 57,009 |  |  | 196,488 |  |  | 145,214 |  |
| Commercial and other industrial | 49,519 |  |  | 42,044 |  |  | 134,188 |  |  | 101,610 |  |
| Light rail traction power | 8,549 |  |  | 5,322 |  |  | 26,785 |  |  | 14,184 |  |
| All others | 11,483 |  |  | 12,673 |  |  | 33,328 |  |  | 39,272 |  |
| Total revenues by market sector | $ | 286,273 |  |  | $ | 288,168 |  |  | $ | 806,335 |  |  | $ | 737,293 |  |
  (was, 2025-05-07, similarity 0.9363):
[0000080420-25-000061:note_history:25]
|  | Three months ended March 31, |  | Six months ended March 31, |
|  | 2025 |  | 2024 |  | 2025 |  | 2024 |
| Oil and gas (excludes petrochemical) | $ | 101,167 |  |  | $ | 103,820 |  |  | $ | 196,846 |  |  | $ | 187,456 |  |
| Petrochemical | 43,704 |  |  | 50,070 |  |  | 76,887 |  |  | 78,437 |  |
| Electric utility | 70,339 |  |  | 47,502 |  |  | 121,579 |  |  | 88,205 |  |
| Commercial and other industrial | 40,369 |  |  | 34,894 |  |  | 84,669 |  |  | 59,566 |  |
| Light rail traction power | 10,008 |  |  | 4,517 |  |  | 18,236 |  |  | 8,862 |  |
| All others | 13,044 |  |  | 14,305 |  |  | 21,845 |  |  | 26,599 |  |
| Total revenues by market sector | $ | 278,631 |  |  | $ | 255,108 |  |  | $ | 520,062 |  |  | $ | 449,125 |  |

- removed (2025-08-06):
[0000080420-25-000061:note_history:26]
backlog of $1.3 billion, of which approximately $831 million is expected to be recognized as revenue within the next twelve months. Backlog may not be indicative of future operating results as orders may be cancelled or modified by our customers. Our backlog does not include service and maintenance-type contracts for which we have the right to invoice as services are performed.


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: tag_name, score: 1.0

- added (2025-08-06):
[0000080420-25-000098:note_history:27]
Subsequent Events
Business Acquisition

- added (2025-08-06):
[0000080420-25-000098:note_history:28]
As previously announced, on July 15, 2025, we entered into a definitive agreement to acquire Remsdaq Ltd. (Remsdaq), a U.K.-based manufacturer of Supervisory Control and Data Acquisition Remote Terminal Units for electrical substation control and automation in generation, transmission and distribution, for total consideration of £12.2 million Pounds Sterling, or approximately $16.3 million, which will be funded with cash on hand. The consideration included an upfront payment of £9.2 million Pounds Sterling with the remaining portion contingent upon Remsdaq meeting certain technical and financial milestones. We expect the transaction to close during the fourth quarter of Fiscal 2025, subject to customary closing conditions.

- added (2025-08-06):
[0000080420-25-000098:note_history:29]
One Big Beautiful Bill Act

- added (2025-08-06):
[0000080420-25-000098:note_history:30]
On July 4, 2025, President Trump signed into law the One Big Beautiful Bill Act (the OBBBA), which includes a broad range of tax reform provisions affecting businesses. The OBBBA extends and modifies certain key 2017 Tax Cuts & Jobs Act (TCJA) provisions (both domestic and international) and revamps some of the TCJA’s provisions on the taxation of corporations’ foreign income. The OBBBA also expands certain Inflation Reduction Act incentives while accelerating the phase-out of others. We are currently evaluating the impact of the OBBBA on our operations, financial results and liquidity.

- changed (2025-08-06):
[0000080420-25-000098:note_history:31]
Quarterly Dividend Declared
  (was, 2025-05-07, similarity 0.75):
[0000080420-25-000061:note_history:31]
Subsequent Events
Quarterly Dividend Declared

- changed (2025-08-06):
[0000080420-25-000098:note_history:32]
On August 5, 2025, our Board of Directors declared a quarterly cash dividend on our common stock in the amount of $0.2675 per share. The dividend is payable on September 17, 2025 to shareholders of record at the close of business on August 20, 2025.
  (was, 2025-05-07, similarity 0.6517):
[0000080420-25-000061:note_history:32]
On May 6, 2025, our Board of Directors declared a quarterly cash dividend on our common stock in the amount of $0.2675 per share. The dividend is payable on June 18, 2025 to shareholders of record at the close of business on May 21, 2025.
