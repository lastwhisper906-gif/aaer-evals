# POWL notes — 0000080420-20-000036


## dei:DocumentsIncorporatedByReferenceTextBlock

[0000080420-20-000036:notes:1]
Portions of the registrant’s definitive proxy statement for the 2020 annual meeting of stockholders to be filed not later than 120 days after September 30, 2020, are incorporated by reference into Part III of this Form 10-K.


## us-gaap:SignificantAccountingPoliciesTextBlock

[0000080420-20-000036:notes:2]
Summary of Significant Accounting Policies

[0000080420-20-000036:notes:3]
Principles of Consolidation

[0000080420-20-000036:notes:4]
The consolidated financial statements include the accounts of Powell and our wholly-owned subsidiaries. All intercompany accounts and transactions have been eliminated in consolidation.

[0000080420-20-000036:notes:5]
Use of Estimates

[0000080420-20-000036:notes:6]
The preparation of financial statements in conformity with accounting principles generally accepted in the United States (U.S. GAAP) requires management to make estimates and assumptions that affect the amounts reported in the consolidated financial statements and accompanying footnotes. The most significant estimates used in our financial statements affect revenue recognition and estimated cost recognition on our customer contracts, the allowance for doubtful accounts, provision for excess and obsolete inventory, warranty accruals and income taxes. The amounts recorded for warranties, legal, income taxes, impairment of long-lived assets (when applicable) and other contingent liabilities require judgments regarding the amount of expenses that will ultimately be incurred. We base our estimates on historical experience and on various other assumptions, as well as the specific circumstances surrounding these contingent liabilities, in evaluating the amount of liability that should be recorded. Additionally, the recognition of deferred tax assets requires estimates related to future income and other assumptions regarding timing and future profitability because the ultimate realization of net deferred tax assets is dependent on the generation of future taxable income during periods in which temporary differences become deductible. Estimates routinely change as new events occur, additional information becomes available or operating environments change. Actual results may differ from our prior estimates.

[0000080420-20-000036:notes:7]
Cash and Investments

[0000080420-20-000036:notes:8]
Cash and cash equivalents

[0000080420-20-000036:notes:9]
Cash and cash equivalents, primarily funds held in money market savings instruments, are reported at their current carrying value, which approximates fair value due to the short-term nature of these instruments, and are included in cash and cash equivalents in our Consolidated Balance Sheets.

[0000080420-20-000036:notes:10]
Short-term Investments - Short-term investments include time deposits with original maturities of three months or more.

[0000080420-20-000036:notes:11]
Supplemental Disclosures of Cash Flow Information (in thousands):

[0000080420-20-000036:notes:12]
|  | Year Ended September 30, |
|  | 2020 |  | 2019 |  | 2018 |
| Cash paid (received) during the period for: |  |  |  |  |  |
| Interest received, net of interest expense | $ | (753) |  |  | $ | (873) |  |  | $ | (676) |  |
| Income taxes paid (received), net of refunds | 1,770 |  |  | (5,219) |  |  | 354 |  |
| Non-cash capital expenditures | 264 |  |  | 1,248 |  |  | 129 |  |

[0000080420-20-000036:notes:13]
Fair Value of Financial Instruments

[0000080420-20-000036:notes:14]
Financial instruments include cash, cash equivalents, short-term investments, restricted cash, receivables, deferred compensation, payables and debt obligations. Except as described below, due to the short-term nature of account receivables and account payables, the book value is representative of their fair value. The carrying value of debt approximates fair value as interest rates are indexed to the Federal Funds Rate or the bank’s prime rate.

[0000080420-20-000036:notes:15]
Accounts Receivable

[0000080420-20-000036:notes:16]
Accounts receivable are stated net of allowances for doubtful accounts. We maintain and continually assess the adequacy of the allowance for doubtful accounts representing our estimate for losses resulting from the inability of our customers to pay amounts due to us. This estimated allowance is based on historical experience of uncollected accounts, the level of past due accounts, the overall level of outstanding accounts receivable, information about specific customers with respect to their inability to make payments and expectations of future conditions that could impact the collectability of accounts receivable. Future changes in our customers’ operating performance and cash flows, or in general economic conditions, could have an impact on their ability to fully pay these amounts, which could have a material impact on our operating results. In most cases,

[0000080420-20-000036:notes:17]
receivables are not collateralized. However, we utilize letters of credit to secure payment on projects when possible. As of September 30, 2020 and 2019, accounts receivable included retention amounts of $6.9 million and $5.6 million, respectively. Retention amounts are in accordance with applicable provisions of contracts and become due upon completion of contractual requirements. Of the retained amount at September 30, 2020, $5.9 million is expected to be collected in the next twelve months and is recorded in accounts receivable. The remaining $1.0 million is recorded in other assets and is expected to be collected in Fiscal 2022.

[0000080420-20-000036:notes:18]
Contract Balances

[0000080420-20-000036:notes:19]
The timing of revenue recognition, billings and cash collections affects accounts receivable, contract assets and contract liabilities in our Consolidated Balance Sheets.

[0000080420-20-000036:notes:20]
Contract assets are recorded when revenues are recognized in excess of amounts billed for fixed-price contracts as determined by the billing milestone schedule. Contract assets are transferred to accounts receivable when billing milestones have been met, or we have an unconditional right to payment.

[0000080420-20-000036:notes:21]
Contract liabilities typically represent advance payments from contractual billing milestones and billings in excess of revenue recognized. It is unusual to have advanced milestone payments with a term greater than one year, which could represent a financing component on the contract.

[0000080420-20-000036:notes:22]
Our contract assets and liabilities are reported in a net position on a contract-by-contract basis at the end of each reporting period and are generally classified as current.

[0000080420-20-000036:notes:23]
Inventories

[0000080420-20-000036:notes:24]
Inventories are stated at the lower of cost or net realizable value using weighted-average methods and include the cost of materials, labor and manufacturing overhead. We use estimates in determining the level of reserves required to state inventory at the lower of cost or net realizable value. Our estimates are based on market activity levels, production requirements, the physical condition of products and technological innovation. Changes in any of these factors may result in adjustments to the carrying value of inventory.

[0000080420-20-000036:notes:25]
Property, Plant and Equipment

[0000080420-20-000036:notes:26]
Property, plant and equipment are stated at cost and are depreciated using the straight-line method over the estimated useful lives of the assets. Expenditures for repairs and maintenance are charged to expense when incurred. Expenditures for major renewals and improvements, which extend the useful lives of existing equipment, are capitalized and depreciated. Upon retirement or disposition of property, plant and equipment, the cost and related accumulated depreciation are removed from the accounts, and any resulting gain or loss is recognized in the Consolidated Statements of Operations.

[0000080420-20-000036:notes:27]
We review property, plant and equipment for impairment whenever events or changes in circumstances indicate that the carrying value may not be realizable. If an evaluation is required, the estimated future undiscounted cash flows associated with the asset are compared to the asset’s carrying amount to determine if recording an impairment of such asset is necessary. If an impairment is indicated, we record an impairment loss equal to the difference between the carrying value and the fair value of the long-lived asset. This requires us to make long-term forecasts of the future revenues and the costs related to the assets subject to review. Forecasts require assumptions about demand for our products and future market conditions. Estimating future cash flows requires significant judgment, and our projections may vary from cash flows eventually realized. Future events and unanticipated changes to assumptions could require a provision for impairment in a future period. The effect of any impairment would be reflected in income (loss) from operations in the Consolidated Statements of Operations. In addition, we estimate the useful lives of our property, plant and equipment and periodically review these estimates to determine whether these lives are appropriate.

[0000080420-20-000036:notes:28]
Income Taxes

[0000080420-20-000036:notes:29]
We account for income taxes under the asset and liability method, based on the income tax laws and rates in the countries in which operations are conducted, and income is earned. This approach requires the recognition of deferred tax assets and liabilities for the expected future tax consequences of temporary differences between the carrying amounts and the tax basis of assets and liabilities. Developing our provision for income taxes requires significant judgment and expertise in federal, international and state income tax laws, regulations and strategies, including the determination of deferred tax assets and liabilities and, if necessary, any valuation allowances that may be required for deferred tax assets. In assessing the extent to

[0000080420-20-000036:notes:30]
which net deferred tax assets may be realized, we consider whether it is more likely than not that some portion or all of the net deferred tax assets may not be realized. The ultimate realization of net deferred tax assets is dependent on the generation of future taxable income during the periods in which those temporary differences become deductible. Estimates may change as new events occur, estimates of future taxable income during the carryforward period are reduced or increased, additional information becomes available or operating environments change, which may result in a full or partial reversal of the valuation allowance. We will continue to assess the adequacy of the valuation allowance on a quarterly basis. Our judgments and tax strategies are subject to audit by various taxing authorities.

[0000080420-20-000036:notes:31]
The objectives of accounting for income taxes are to recognize the amount of taxes payable or refundable for the current year and deferred tax liabilities and assets for the future tax consequences of events that have been recognized in an entity’s financial statements or tax returns. We recognize the tax benefit from an uncertain tax position only if it is more likely than not that the tax position will be sustained on examination by the taxing authorities, based on the technical merits of the position. The tax benefits recognized in the financial statements from such a position should be measured based on the largest benefit that has a greater than 50% likelihood of being realized upon ultimate settlement. Accounting literature also provides guidance on derecognition of income tax assets and liabilities, classification of current and deferred income tax assets and liabilities, accounting for interest and penalties associated with tax positions, and income tax disclosures. Judgment is required in assessing the future tax consequences of events that have been recognized in our financial statements or tax returns. Variations in the actual outcome of these future tax consequences could materially impact our financial statements.

[0000080420-20-000036:notes:32]
Revenue Recognition

[0000080420-20-000036:notes:33]
Our revenues are primarily generated from the manufacturing of custom-engineered products and systems under long-term fixed-price contracts that may last from one month to several years, depending on the contract. Revenue from these contracts is generally recognized over time utilizing the cost-to-cost method to measure the extent of progress toward the completion of the performance obligation and the recognition of revenue over time. We believe that this method is the most accurate representation of our performance because it directly measures the value of the services transferred to the customer over time as we incur costs on our contracts. Contract costs include all direct materials, labor and indirect costs related to contract performance, which may include indirect labor, supplies, tools, repairs and depreciation costs.

[0000080420-20-000036:notes:34]
We enter into contracts to provide value-added services such as field service inspection, installation, commissioning, modification and repair, as well as retrofit and retrofill components for existing systems. As a practical expedient, if the service contract terms give us the right to invoice the customer for an amount that corresponds directly with the value of our performance completed to date (i.e., a service contract in which we bill a fixed amount for each hour of service provided), then we recognize revenue over time in each reporting period corresponding to the amount with which we have the right to invoice.  Our performance obligations are satisfied as the work progresses.

[0000080420-20-000036:notes:35]
We also have sales orders for spare parts and replacement circuit breakers for switchgear that are obsolete or that are no longer produced by the original manufacturer. Revenues from these sales orders are recognized at a point in time when we fulfill our performance obligation to the customer, which is typically upon shipment.

[0000080420-20-000036:notes:36]
Additionally, some contracts may contain a cancellation clause that could limit the amount of revenue we are able to recognize over time. In these instances, revenue and costs associated with these contracts are deferred and recognized at a point in time when the performance obligation is fulfilled.

[0000080420-20-000036:notes:37]
Selling and administrative costs incurred in relation to obtaining a contract are typically expensed as incurred. We periodically utilize a third-party sales agent to obtain a contract and will pay a commission to that agent. We record the full commission liability to the third-party sales agent at the order date, with a corresponding deferred asset. As the project progresses, we record commission expense based on percentage of completion rates that correlate to the project and reduce the deferred asset. Once we have been paid by the customer, we pay the commission, and the deferred liability is reduced.

[0000080420-20-000036:notes:38]
Warranty Costs

[0000080420-20-000036:notes:39]
Estimated costs of warranties are accrued based on historical warranty claim costs in relation to current revenues. In addition, specific provisions are made when product failures are projected outside historical experience. Our standard terms and conditions of sale include a warranty for parts and service for the earlier of 18 months from the date of shipment or 12 months from the date of energization, whichever occurs first. Actual results could differ from our estimate.

[0000080420-20-000036:notes:40]
Occasionally projects require warranty terms that are longer than our standard terms due to the nature of the project. Extended warranty terms may be negotiated and included in our contracts. The allocated revenue associated with the extended warranty is deferred and recorded as a contract liability and recognized over the extended warranty period.

[0000080420-20-000036:notes:41]
Research and Development Expense

[0000080420-20-000036:notes:42]
Research and development activities are directed toward the development of new products and processes as well as improvements in existing products and processes. These costs, which primarily include salaries, contract services and supplies, are expensed as incurred. Such amounts were $6.3 million, $6.3 million and $6.7 million in Fiscal 2020, 2019 and 2018, respectively.

[0000080420-20-000036:notes:43]
Foreign Currency Translation

[0000080420-20-000036:notes:44]
The functional currency for our foreign subsidiaries is the local currency in which the entity is located. The financial statements of all subsidiaries with a functional currency other than the U.S. Dollar have been translated into U.S. Dollars. All assets and liabilities of foreign operations are translated into U.S. Dollars using year-end exchange rates, and all revenues and expenses are translated at average rates during the respective period. The U.S. Dollar results that arise from such translation, as well as exchange gains and losses on intercompany balances of a long-term investment nature, are included in the cumulative currency translation adjustments in accumulated other comprehensive loss in stockholders’ equity.

[0000080420-20-000036:notes:45]
Stock-Based Compensation

[0000080420-20-000036:notes:46]
We measure stock-based compensation cost at the grant date based on the fair value of the award. Compensation expense is recognized over the period during which the recipient is required to provide service in exchange for the awards, typically the vesting period. Excess income tax benefits related to share-based compensation expense are recognized as income tax expense or benefit in the Consolidated Statement of Operations. Cash paid when directly withholding shares on an employee's behalf for tax withholding purposes is classified as a financing activity. We account for forfeitures as they occur, rather than estimate expected forfeitures.

[0000080420-20-000036:notes:47]
New Accounting Standards

[0000080420-20-000036:notes:48]
In February 2016, the Financial Accounting Standards Board (FASB) issued a new topic on leases that requires lessees to recognize lease assets and lease liabilities on the balance sheet for all leases with terms longer than twelve months. Leases are classified as either finance or operating, with classification affecting the pattern of expense recognition in the income statement. Effective October 1, 2019, we adopted the new lease accounting standard and recorded operating lease assets and operating lease liabilities of approximately $7.0 million and determined that no adjustment to retained earnings was necessary. Financial results for reporting periods after October 1, 2019 are reported under the new standard; however financial results for prior periods were not adjusted and will continue to be presented in accordance with the previous standard. Upon adoption, we elected a package of practical expedients which, among other things, allowed for the historical classification of our existing leases to carry forward. Additionally, we elected to separate non-lease components for our real estate and IT infrastructure asset classes.  All other asset classes account for both lease and non-lease components in the operating lease asset and operating lease liability calculations. See Note M for further discussion of leases.

[0000080420-20-000036:notes:49]
In June 2016, the FASB issued a new topic on measurement of credit losses. The topic introduces an impairment model known as the current expected credit loss (CECL) model that is based on an expected loss methodology rather than an incurred loss methodology for financial instruments. Under the new topic, an entity recognizes as an allowance its estimate of expected credit losses with the intention of improving financial reporting by requiring timelier recognition of such losses. Enhanced disclosure of information regarding how a company developed its allowance, including changes in the factors that influenced management's estimate of expected credit losses and the reasons for those changes, will be required upon adoption. We are still evaluating the impact this new topic will have on our consolidated financial statements which will be adopted in Fiscal 2021.

[0000080420-20-000036:notes:50]
In November 2016, the FASB issued a new topic on the statement of cash flows that changes the presentation of restricted cash and cash equivalents on the statement of cash flows. Restricted cash and restricted cash equivalents will be included with cash and cash equivalents when reconciling the beginning-of-period and end-of-period total amounts shown on the statement of cash flows. We adopted this topic in Fiscal 2019, and our Consolidated Cash Flow Statements for all periods reflect this presentation.


## us-gaap:RevenueFromContractWithCustomerPolicyTextBlock

[0000080420-20-000036:notes:51]
Performance Obligations

[0000080420-20-000036:notes:52]
A performance obligation is a promise in a contract or with a customer to transfer a distinct good or service. A contract’s transaction price is allocated to each distinct performance obligation and recognized as revenue as the performance obligations are satisfied. To determine the proper revenue recognition for contracts, we evaluate whether a contract should be accounted for as more than one performance obligation or, less commonly, whether two or more contracts should be combined and accounted for as one performance obligation.  This evaluation of performance obligations requires significant judgment.  The majority of our contracts have a single performance obligation where multiple engineered products and services are combined into a single custom-engineered solution. Our contracts generally include a standard assurance warranty that typically ends 18 months after shipment. Occasionally, we provide service-type warranties that will extend the warranty period. These extended warranties qualify as a separate performance obligation, and revenue is deferred and recognized over the warranty period. If we determine during the evaluation of the contract that there are multiple performance obligations, we allocate the transaction price to each performance obligation using our best estimate of the standalone selling price of each distinct good or service in the contract. 
Remaining unsatisfied performance obligations, which we refer to as backlog, represent the estimated transaction price for goods and services for which we have a material right, but work has not been performed.
Contract Estimates

[0000080420-20-000036:notes:53]
Actual revenues and project costs may vary from previous estimates due to changes in a variety of factors. The cost estimation process is based upon the professional knowledge and experience of our engineers, project managers and financial professionals. Factors that are considered in estimating the work to be completed and ultimate contract recovery include the availability and productivity of labor, the nature and complexity of the work to be performed, the availability of materials, and the effect of any delays on our project performance. We periodically review our job performance, job conditions, estimated profitability and final contract settlements, including our estimate of total costs and make revisions to costs and income in the period in which the revisions are probable and reasonably estimable. Whenever revisions of estimated contract costs and contract values indicate that the contract costs will exceed estimated revenues, thus creating a loss, a provision for the total estimated loss is recorded in that period.

[0000080420-20-000036:notes:54]
Variable Consideration

[0000080420-20-000036:notes:55]
It is common for our long-term contracts to contain variable consideration that can either increase or decrease the transaction price. Due to the nature of our contracts, estimating total cost and revenue can be complex and subject to variability due to change orders, back charges, spare parts, early completion bonuses, customer allowances and liquidated damages. We estimate the amount of variable consideration based on the expected value method, which is the sum of probability-weighted amount, or the most likely amount method which uses various factors including experience with similar transactions and assessment of our anticipated performance. Variable consideration is included in the transaction price if legally enforceable and to the extent it is probable that a significant reversal of cumulative revenue recognized will not occur once the uncertainty associated with the variable consideration is resolved.

[0000080420-20-000036:notes:56]
Contract Modifications

[0000080420-20-000036:notes:57]
Contracts may be modified for changes in contract specifications and requirements. We consider contract modifications to exist when the modification either creates new or changes the enforceable rights and obligations under the contract. Most of our contract modifications are for goods and services that are not distinct from the existing performance obligation. Contract modifications result in a cumulative catch-up adjustment to revenue based on our measure of progress for the performance obligation.


## us-gaap:EarningsPerShareTextBlock

[0000080420-20-000036:notes:58]
Earnings Per ShareWe compute basic earnings per share by dividing net income (loss) by the weighted average number of common shares outstanding during the period. Diluted earnings per common and potential common share includes the weighted average of additional shares associated with the incremental effect of dilutive restricted stock and restricted stock units, as prescribed by the FASB guidance on earnings per share.
The following table reconciles basic and diluted weighted average shares used in the computation of earnings per share (in thousands, except per share data):

[0000080420-20-000036:notes:59]
|  | Year Ended September 30, |
|  | 2020 |  | 2019 |  | 2018 |
| Numerator: |  |  |  |  |  |
| Net income (loss) | $ | 16,660 |  |  | $ | 9,890 |  |  | $ | (7,152) |  |
| Denominator: |  |  |  |  |  |
| Weighted average basic shares | 11,624 |  |  | 11,571 |  |  | 11,507 |  |
| Dilutive effect of restricted stock units | 69 |  |  | 63 |  |  | — |  |
| Weighted average diluted shares with assumed conversions | 11,693 |  |  | 11,634 |  |  | 11,507 |  |
| Earnings (loss) per share: |  |  |  |  |  |
| Basic | $ | 1.43 |  |  | $ | 0.85 |  |  | $ | (0.62) |  |
| Diluted | $ | 1.42 |  |  | $ | 0.85 |  |  | $ | (0.62) |  |

[0000080420-20-000036:notes:60]
For the year ended September 30, 2018, we incurred a net loss; therefore, all potential common shares were deemed to be anti-dilutive.


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0000080420-20-000036:notes:61]
Detail of Selected Balance Sheet Accounts
Allowance for Doubtful Accounts

[0000080420-20-000036:notes:62]
Activity in our allowance for doubtful accounts consisted of the following (in thousands):

[0000080420-20-000036:notes:63]
|  | September 30, |
|  | 2020 |  | 2019 |
| Balance at beginning of period | $ | 301 |  |  | $ | 157 |  |
| Bad debt expense | 258 |  |  | 233 |  |
| Uncollectible accounts written off, net of recoveries | (32) |  |  | (81) |  |
| Change due to foreign currency translation | (17) |  |  | (8) |  |
| Balance at end of period | $ | 510 |  |  | $ | 301 |  |

[0000080420-20-000036:notes:64]
The components of inventories are summarized below (in thousands):

[0000080420-20-000036:notes:65]
|  | September 30, |
|  | 2020 |  | 2019 |
| Raw materials, parts and subassemblies | $ | 31,202 |  |  | $ | 31,781 |  |
| Work-in-progress | 1,539 |  |  | 1,100 |  |
| Provision for excess and obsolete inventory | (3,773) |  |  | (3,679) |  |
| Total inventories | $ | 28,968 |  |  | $ | 29,202 |  |

[0000080420-20-000036:notes:66]
Property, plant and equipment are summarized below (in thousands):

[0000080420-20-000036:notes:67]
|  | September 30, |  | Range of |
|  | 2020 |  | 2019 |  | Asset Lives |
| Land | $ | 22,008 |  |  | $ | 21,963 |  |  | — |
| Buildings and improvements | 122,529 |  |  | 122,404 |  |  | 3 - 39 Years |
| Machinery and equipment | 108,439 |  |  | 106,137 |  |  | 3 - 15 Years |
| Furniture and fixtures | 3,611 |  |  | 3,611 |  |  | 3 - 10 Years |
| Construction in process | 1,530 |  |  | 2,118 |  |  | — |
|  | $ | 258,117 |  |  | $ | 256,233 |  |  |  |
| Less: Accumulated depreciation | (143,745) |  |  | (135,421) |  |  |  |
| Total property, plant and equipment, net | $ | 114,372 |  |  | $ | 120,812 |  |  |  |

[0000080420-20-000036:notes:68]
There were no assets under finance lease as of September 30, 2020 or September 30, 2019. Depreciation expense was $10.4 million, $11.9 million and $12.7 million for fiscal years 2020, 2019, and 2018, respectively.

[0000080420-20-000036:notes:69]
Accrued Product Warranty

[0000080420-20-000036:notes:70]
Activity in our product warranty accrual consisted of the following (in thousands):

[0000080420-20-000036:notes:71]
|  | September 30, |
|  | 2020 |  | 2019 |
| Balance at beginning of period | $ | 2,946 |  |  | $ | 2,604 |  |
| Increase to warranty expense | 2,286 |  |  | 3,004 |  |
| Deduction for warranty charges | (2,463) |  |  | (2,649) |  |
| Change due to foreign currency translation | 2 |  |  | (13) |  |
| Balance at end of period | $ | 2,771 |  |  | $ | 2,946 |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0000080420-20-000036:notes:72]
Revenue
On October 1, 2018, we adopted the new revenue recognition standard using the modified retrospective transition method. We applied the guidance in the standard to customer contracts that were not substantially complete at that time and we determined that no adjustment to retained earnings was necessary. Financial results for reporting periods after October 1, 2018 are reported under the new standard; however, financial results for prior periods were not adjusted and will continue to be presented in accordance with the previous standard.

[0000080420-20-000036:notes:73]
Our revenues are primarily generated from the manufacturing of custom-engineered products and systems under long-term fixed-price contracts under which we agree to manufacture various products such as traditional and arc-resistant distribution switchgear and control gear, medium-voltage circuit breakers, monitoring and control communications systems, motor control centers, switches and bus duct systems. These products may be sold separately as an engineered solution, but are typically integrated into custom-built enclosures which we also build.  These enclosures are referred to as power control room substations (PCRs®), custom-engineered modules or electrical houses (E-Houses). Some contracts may also include the installation and the commissioning of these enclosures.

[0000080420-20-000036:notes:74]
Revenue from these contracts is generally recognized over time utilizing the cost-to-cost method to measure the extent of progress toward the completion of the performance obligation and the recognition of revenue over time. We believe that this method is the most accurate representation of our performance, because it directly measures the value of the services transferred to the customer over time as we incur costs on our contracts.  Contract costs include all direct materials, labor, and indirect costs related to contract performance, which may include indirect labor, supplies, tools, repairs and depreciation costs.

[0000080420-20-000036:notes:75]
We also have contracts to provide value-added services such as field service inspection, installation, commissioning, modification and repair, as well as retrofit and retrofill components for existing systems.  As a practical expedient, if the service contract terms give us the right to invoice the customer for an amount that corresponds directly with the value of our

[0000080420-20-000036:notes:76]
performance completed to date (i.e., a service contract in which we bill a fixed amount for each hour of service provided), then we recognize revenue over time in each reporting period corresponding to the amount that we have the right to invoice.  Our performance obligations are satisfied as the work progresses. Revenues from our custom-engineered products and value-added services transferred to customers over time accounted for approximately 95% and 94% of revenues for the years ended September 30, 2020 and September 30, 2019, respectively.

[0000080420-20-000036:notes:77]
We also have sales orders for spare parts and replacement circuit breakers for switchgear that are obsolete or that are no longer produced by the original manufacturer. Revenues from these sales orders are recognized at the time we fulfill our performance obligation to the customer, which is typically upon shipment and represented approximately 5% and 6% of revenues for the years ended September 30, 2020 and September 30, 2019, respectively.

[0000080420-20-000036:notes:78]
A performance obligation is a promise in a contract or with a customer to transfer a distinct good or service. A contract’s transaction price is allocated to each distinct performance obligation and recognized as revenue as the performance obligations are satisfied. To determine the proper revenue recognition for contracts, we evaluate whether a contract should be accounted for as more than one performance obligation or, less commonly, whether two or more contracts should be combined and accounted for as one performance obligation.  This evaluation of performance obligations requires significant judgment.  The majority of our contracts have a single performance obligation where multiple engineered products and services are combined into a single custom-engineered solution. Our contracts generally include a standard assurance warranty that typically ends 18 months after shipment. Occasionally, we provide service-type warranties that will extend the warranty period. These extended warranties qualify as a separate performance obligation, and revenue is deferred and recognized over the warranty period. If we determine during the evaluation of the contract that there are multiple performance obligations, we allocate the transaction price to each performance obligation using our best estimate of the standalone selling price of each distinct good or service in the contract.

[0000080420-20-000036:notes:79]
Remaining unsatisfied performance obligations, which we refer to as backlog, represent the estimated transaction price for goods and services for which we have a material right, but work has not been performed. As of September 30, 2020, we had backlog of $476.8 million, of which approximately $282.5 million is expected to be recognized as revenue within the next twelve months. Backlog may not be indicative of future operating results as orders may be cancelled or modified by our customers. Our backlog does not include service and maintenance-type contracts for which we have the right to invoice as services are performed.

[0000080420-20-000036:notes:80]
Contract Estimates

[0000080420-20-000036:notes:81]
For the years ended September 30, 2020 and 2019, our operating results were positively impacted by $11.3 million and $5.1 million, respectively, as a result of changes in contract estimates related to projects in progress at the beginning of the respective period. These changes in estimates resulted primarily from favorable project execution and negotiations of variable consideration, discussed below, as well as other changes in facts and circumstances during these periods.

[0000080420-20-000036:notes:82]
Contract assets and liabilities as of September 30, 2020 and September 30, 2019 are summarized below (in thousands):

[0000080420-20-000036:notes:83]
|  | September 30, |
|  | 2020 |  | 2019 |
| Contract assets | $ | 50,995 |  |  | $ | 55,374 |  |
| Contract liabilities | (79,445) |  |  | (71,464) |  |
| Net contract liability | $ | (28,450) |  |  | $ | (16,090) |  |

[0000080420-20-000036:notes:84]
The increase in net contract liability at September 30, 2020 from September 30, 2019 was primarily due to our progress towards completion on our projects and the timing of contract billing milestones and new orders. This increase was primarily driven by the timing of contract billing milestones related to our recent contract award for a large industrial project in the United States. To determine the amount of revenue recognized during the period from contract liabilities, we first allocate revenue to the individual contract liability balance outstanding at the beginning of the period until the revenue exceeds that balance. During the year ended September 30, 2020, we recognized revenue of approximately $71 million related to contract liabilities outstanding at September 30, 2019.

[0000080420-20-000036:notes:85]
The timing of our invoice process is typically dependent on the completion of certain milestones and contract terms and subject to agreement by our customer.  Payment is typically expected within 30 days of invoice. Any uncollected invoiced amounts for our performance obligations recognized over time, including contract retentions, are recorded as accounts receivable in the Consolidated Balance Sheets. Certain contracts contain retention provisions that become due upon completion of contractual requirements. As of September 30, 2020 and September 30, 2019, accounts receivable included retention amounts of $6.9 million and $5.6 million, respectively. Of the retained amount at September 30, 2020, $5.9 million is expected to be collected in the next twelve months and is recorded in accounts receivable.  The remaining $1.0 million is recorded in other assets.

[0000080420-20-000036:notes:86]
Disaggregation of Revenue

[0000080420-20-000036:notes:87]
The following tables present our disaggregated revenue by geographic destination and market sector for the years ended September 30, 2020 and September 30, 2019 (in thousands):

[0000080420-20-000036:notes:88]
|  | 2020 |  | 2019 |
| United States | $ | 397,983 |  |  | $ | 406,609 |  |
| Canada | 66,064 |  |  | 64,326 |  |
| Europe, Middle East and Africa | 34,028 |  |  | 32,166 |  |
| Asia/Pacific | 18,079 |  |  | 11,405 |  |
| Mexico, Central and South America | 2,345 |  |  | 2,674 |  |
| Total revenues by geographic destination | $ | 518,499 |  |  | $ | 517,180 |  |

[0000080420-20-000036:notes:89]
|  | 2020 |  | 2019 |
| Oil and gas | $ | 195,209 |  |  | $ | 242,291 |  |
| Petrochemical | 126,698 |  |  | 93,391 |  |
| Electric utility | 88,818 |  |  | 84,993 |  |
| Traction power | 42,373 |  |  | 26,781 |  |
| All others | 65,401 |  |  | 69,724 |  |
| Total revenues by market sector | $ | 518,499 |  |  | $ | 517,180 |  |


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0000080420-20-000036:notes:90]
Goodwill and Intangible Assets
Our intangible assets consist of goodwill of $1.0 million, which is not being amortized, and purchased technology of $0.2 million, which is amortized over its estimated useful life. No impairment expense has been recorded for the last three fiscal years.

[0000080420-20-000036:notes:91]
Intangible assets balances, subject to amortization, at September 30, 2020 and 2019 consisted of the following (in thousands):

[0000080420-20-000036:notes:92]
|  | September 30, 2020 |  | September 30, 2019 |
|  | GrossCarryingValue |  | AccumulatedAmortization |  | NetCarryingValue |  | GrossCarryingValue |  | AccumulatedAmortization |  | NetCarryingValue |
| Purchased technology | $ | 11,749 |  |  | $ | (11,592) |  |  | $ | 157 |  |  | $ | 11,749 |  |  | $ | (11,415) |  |  | $ | 334 |  |

[0000080420-20-000036:notes:93]
Amortization of intangible assets recorded for the years ended September 30, 2020, 2019 and 2018 was $0.2 million, $0.2 million and $0.2 million, respectively.

[0000080420-20-000036:notes:94]
Estimated amortization expense for each of the five subsequent fiscal years is expected to be (in thousands):

[0000080420-20-000036:notes:95]
| Years Ended September 30, | Total |
| 2021 | $ | 157 |  |


## us-gaap:LongTermDebtTextBlock

[0000080420-20-000036:notes:96]
Long-Term Debt
Long-term debt consisted of the following (in thousands):

[0000080420-20-000036:notes:97]
|  | September 30, |
|  | 2020 |  | 2019 |
| Industrial development revenue bonds | $ | 800 |  |  | $ | 1,200 |  |
| Less: current portion | (400) |  |  | (400) |  |
| Total long-term debt | $ | 400 |  |  | $ | 800 |  |

[0000080420-20-000036:notes:98]
The annual maturities of long-term debt as of September 30, 2020, were as follows (in thousands):

[0000080420-20-000036:notes:99]
| Year Ending September 30, | Long‑TermDebtMaturities |
| 2021 | $ | 400 |  |
| Total long-term debt maturities | $ | 400 |  |

[0000080420-20-000036:notes:100]
U.S. Revolver

[0000080420-20-000036:notes:101]
On September 27, 2019, we entered into an Amended and Restated Credit Agreement with Bank of America, N.A. (the "U.S. Revolver"), which replaced our prior credit agreement. The U.S. Revolver is a $75.0 million revolving credit facility, which is available for both borrowings and letters of credit and expires September 2024. As of September 30, 2020, there were no amounts borrowed under this facility, and letters of credit outstanding were $38.7 million. There was $36.3 million available for the issuance of letters of credit and borrowings under the U.S. Revolver as of September 30, 2020.

[0000080420-20-000036:notes:102]
We are required to maintain certain financial covenants, the most significant of which are a consolidated leverage ratio less than 3.0 to 1.0 and a consolidated interest coverage ratio of greater than 3.0 to 1.0. The consolidated leverage ratio is our most restrictive covenant and a decrease in our earnings before interest, taxes, depreciation and amortization (EBITDA) could restrict our ability to issue letters of credit under the U.S. Revolver. Additionally, we must maintain a consolidated cash balance of $30 million at all times. The U.S. Revolver also contains a "material adverse effect" clause which is a material change in our operations, business, properties, liabilities or condition (financial or otherwise) or a material impairment of our ability to perform our obligations under our credit agreements. As of September 30, 2020, we were in compliance with all of the financial covenants of the U.S. Revolver.

[0000080420-20-000036:notes:103]
The U.S. Revolver allows the Company to elect that any borrowing under the facility bears an interest rate based on either the base rate or the eurocurrency rate, in each case, plus the applicable rate. The base rate is generally the highest of (a) the federal funds rate plus 0.50%, (b) the Bank of America prime rate or (c) the London Interbank Offered Rate (“LIBOR”) plus 1.00%. The applicable rate is generally a range from (0.25)% to 1.75% depending on the type of loan and the Company's consolidated leverage ratio.

[0000080420-20-000036:notes:104]
The U.S. Revolver is collateralized by a pledge of 100% of the voting capital stock of each of our domestic subsidiaries and 65% of the voting capital stock of each non-domestic subsidiary. The U.S. Revolver provides for customary events of default and carries cross-default provisions with other existing debt agreements. If an event of default (as defined in the U.S. Revolver) occurs and is continuing, on the terms and subject to the conditions set forth in the U.S. Revolver, amounts and letters of credit outstanding under the U.S. Revolver may be accelerated and may become immediately due and payable.

[0000080420-20-000036:notes:105]
Industrial Development Revenue Bonds
We borrowed $8.0 million in October 2001 through a loan agreement funded with proceeds from tax-exempt industrial development revenue bonds ("Bonds"). These Bonds were issued by the Illinois Development Finance Authority and were used for the completion of our Northlake, Illinois facility. Pursuant to the Bond issuance, a reimbursement agreement between us and a major domestic bank required an issuance by the bank of an irrevocable direct-pay letter of credit ("Bond LC"), as collateral, to the Bonds’ trustee to guarantee payment of the Bonds’ principal and interest when due. The Bond LC is subject to both early termination and extension provisions customary to such agreements, as well as various covenants, for which we were in compliance at September 30, 2020. While the Bonds mature in 2021, the reimbursement agreement requires annual redemptions of $0.4 million that commenced on October 25, 2002. A sinking fund is used for the annual principal payment. The Bonds bear interest at a floating rate determined weekly by the Bonds’ remarketing agent, which was the underwriter for the Bonds and is an affiliate of the bank. This interest rate was 0.27% as of September 30, 2020.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0000080420-20-000036:notes:106]
Commitments and Contingencies
Letters of Credit, Bank Guarantees and Bonds

[0000080420-20-000036:notes:107]
Certain customers require us to post letters of credit, bank guarantees or surety bonds. These security instruments assure that we will perform under the terms of our contract. In the event of default, the counterparty may demand payment from the bank under a letter of credit or bank guarantee, or performance by the surety under a bond. To date, there have been no significant draws or claims related to security instruments for the periods reported. We were contingently liable for letters of credit of

[0000080420-20-000036:notes:108]
$38.7 million as of September 30, 2020. We also had surety bonds totaling $162.4 million that were outstanding, with additional bonding capacity of $587.6 million available, at September 30, 2020.

[0000080420-20-000036:notes:109]
We have a $9.0 million facility agreement ("Facility Agreement") between Powell (UK) Limited and a large international bank that provides Powell (UK) Limited the ability to enter into bank guarantees as well as forward exchange contracts and currency options. At September 30, 2020, we had outstanding guarantees totaling $7.2 million and amounts available under this Facility Agreement were $1.8 million. The Facility Agreement provides for financial covenants and customary events of default, and carries cross-default provisions with our U.S. Revolver. If an event of default (as defined in the Facility Agreement) occurs and is continuing, per the terms and subject to the conditions set forth therein, obligations outstanding under the Facility Agreement may be accelerated and may become or be declared immediately due and payable. Additionally, we are required to maintain cash collateral for guarantees greater than two years. As of September 30, 2020, we were in compliance with all of the financial covenants of the Facility Agreement.

[0000080420-20-000036:notes:110]
Litigation

[0000080420-20-000036:notes:111]
We are involved in various legal proceedings, claims and other disputes arising from our commercial operations, projects, employees and other matters which, in general, are subject to uncertainties and in which the outcomes are not predictable. Although we can give no assurances about the resolution of pending claims, litigation or other disputes and the effect such outcomes may have on us, management believes that any ultimate liability resulting from the outcome of such proceedings, to the extent not otherwise provided or covered by insurance, will not have a material adverse effect on our consolidated financial position or results of operations or liquidity.

[0000080420-20-000036:notes:112]
Liquidated Damages

[0000080420-20-000036:notes:113]
Certain of our customer contracts have schedule and performance obligation clauses that, if we fail to meet them, could require us to pay liquidated damages. Each individual contract defines the conditions under which the customer may make a claim against us. As of September 30, 2020, our exposure to possible liquidated damages was $2.4 million, of which approximately $0.2 million was probable. Based on our actual or projected failure to meet these various contractual commitments, $0.2 million has been recorded as a reduction to revenue. We will attempt to obtain change orders, contract extensions or accelerate project completion, which may resolve the potential for any unrecorded liquidated damage. We have claimed force majeure on certain contracts due to delays associated with the COVID-19 pandemic. Should we fail to achieve relief on some or all of these contractual obligations, we could be required to pay additional liquidated damages, which could negatively impact our future operating results.


## us-gaap:IncomeTaxDisclosureTextBlock

[0000080420-20-000036:notes:114]
Income Taxes 
The components of the income tax provision (benefit) were as follows (in thousands):

[0000080420-20-000036:notes:115]
|  | Year Ended September 30, |
|  | 2020 |  | 2019 |  | 2018 |
| Current: |  |  |  |  |  |
| Federal | $ | 945 |  |  | $ | 1,350 |  |  | $ | 973 |  |
| State | 1,186 |  |  | 186 |  |  | 201 |  |
| Foreign | 66 |  |  | 88 |  |  | 449 |  |
|  | 2,197 |  |  | 1,624 |  |  | 1,623 |  |
| Deferred: |  |  |  |  |  |
| Federal | 1,045 |  |  | 366 |  |  | (1,834) |  |
| State | (91) |  |  | 457 |  |  | (247) |  |
| Foreign | 519 |  |  | (3) |  |  | (89) |  |
|  | 1,473 |  |  | 820 |  |  | (2,170) |  |
| Total income tax provision (benefit) | $ | 3,670 |  |  | $ | 2,444 |  |  | $ | (547) |  |

[0000080420-20-000036:notes:116]
Income (loss) before income taxes was as follows (in thousands):

[0000080420-20-000036:notes:117]
|  | Year Ended September 30, |
|  | 2020 |  | 2019 |  | 2018 |
| U.S. | $ | 21,243 |  |  | $ | 11,859 |  |  | $ | (2,103) |  |
| Foreign | (913) |  |  | 475 |  |  | (5,596) |  |
| Income (loss) before income taxes | $ | 20,330 |  |  | $ | 12,334 |  |  | $ | (7,699) |  |

[0000080420-20-000036:notes:118]
A reconciliation of the statutory U.S. income tax rate and the effective income tax rate, as computed on earnings before income tax provision in each of the three years presented in the Consolidated Statements of Operations, was as follows:

[0000080420-20-000036:notes:119]
|  | Year Ended September 30, |
|  | 2020 |  | 2019 |  | 2018 |
| Statutory rate | 21 | % |  | 21 | % |  | 25 | % |
| State income taxes, net of federal benefit | 5 |  |  | 4 |  |  | (2) |  |
| Research and development credit | (13) |  |  | (7) |  |  | 9 |  |
| Foreign rate differential | — |  |  | 1 |  |  | 1 |  |
| Foreign withholding | — |  |  | 1 |  |  | (3) |  |
| Valuation allowance | 4 |  |  | (2) |  |  | (20) |  |
| Deferred tax rate differential | — |  |  | — |  |  | (4) |  |
| Other | 1 |  |  | 2 |  |  | 1 |  |
| Effective rate | 18 | % |  | 20 | % |  | 7 | % |

[0000080420-20-000036:notes:120]
On December 22, 2017, the new tax law lowered the corporate tax rate from 35% to 21% effective January 1, 2018. As a result, the U.S. federal statutory rate for Fiscal 2020 and 2019 is 21%, compared to the blended statutory rate of 24.5% effective for Fiscal 2018.

[0000080420-20-000036:notes:121]
Our income tax provision (benefit) reflects an effective tax rate on pre-tax results of 18% in Fiscal 2020 compared to 20% and 7% in Fiscal 2019 and 2018, respectively. The effective tax rate of 18% for Fiscal 2020 was favorably impacted by the current year estimated Research and Development Tax Credit ("R&D Tax Credit") as well as the utilization of net operating loss carryforwards in Canada that were fully reserved with a valuation allowance. Likewise, the discrete items recorded in the third quarter of Fiscal 2020 in the amount of $1.7 million associated with the release of reserves for unrecognized tax benefits as a result of the expiration of statutes of limitations and the IRS audit settlement favorably impacted the effective tax rate. The effective tax rate was negatively impacted by the discrete item recorded in the second quarter of Fiscal 2020 for the valuation allowance against our U.K. deferred tax assets in the amount of $0.5 million as well as by the losses recognized in various foreign jurisdictions that were reserved with a valuation allowance. The effective tax rate for Fiscal 2019 approximated the U.S. federal statutory rate as favorable adjustments related to the utilization of net operating loss carryforwards in Canada that were fully reserved with a valuation allowance, and the R&D Tax Credit were largely offset by unfavorable adjustments primarily related to state income taxes and other permanent items. Due to the loss position in Fiscal 2018, the effective tax rate was negatively impacted by foreign losses reserved for with a valuation allowance as well as $0.5 million of tax expense related to the re-measurement of U.S. deferred tax assets as a result of tax reform.

[0000080420-20-000036:notes:122]
During our assessment of deferred income taxes, in the second quarter of Fiscal 2020, we recorded a valuation allowance of $0.5 million against our U.K. net deferred tax assets.  In assessing the realizability of net deferred tax assets, we determined it was more-likely-than-not that the net deferred tax assets may not be realized based upon recent U.K. tax losses and anticipated results in the near term.  Estimates may change as new events occur, estimates of future taxable income are reduced or increased, additional information becomes available, or operating environments change, which may result in a full or partial reversal of the valuation allowance.

[0000080420-20-000036:notes:123]
We have not recorded deferred income taxes on $16.1 million of undistributed earnings of our foreign subsidiaries because of management’s intent to indefinitely reinvest such earnings. Upon distribution of these earnings in the form of dividends or otherwise, we may be subject to U.S. income taxes and foreign withholding taxes. It is not practical, however, to estimate the amount of taxes that may be payable on the eventual remittance of these earnings.

[0000080420-20-000036:notes:124]
We are subject to income tax in the U.S., multiple state jurisdictions and certain international jurisdictions, primarily the U.K. and Canada. We do not consider any state in which we do business to be a major tax jurisdiction. We remain open to examination in the other jurisdictions as follows:  Canada 2013 – 2019, United Kingdom 2018 – 2019 and the United States

[0000080420-20-000036:notes:125]
2018 – 2019. As of September 30, 2020, we did not have any state audits underway that would have a material impact on our financial position or results of operations.

[0000080420-20-000036:notes:126]
The net deferred income tax asset was comprised of the following (in thousands):

[0000080420-20-000036:notes:127]
|  | September 30, |
|  | 2020 |  | 2019 |
| Gross assets | $ | 18,326 |  |  | $ | 18,851 |  |
| Gross liabilities and valuation allowance | (14,682) |  |  | (13,734) |  |
| Net deferred income tax asset | $ | 3,644 |  |  | $ | 5,117 |  |

[0000080420-20-000036:notes:128]
The tax effect of temporary differences between U.S. GAAP accounting and federal income tax accounting creating deferred income tax assets and liabilities was as follows (in thousands):

[0000080420-20-000036:notes:129]
|  | September 30, |
|  | 2020 |  | 2019 |
| Deferred Tax Assets: |  |  |  |
| Net operating loss | $ | 10,823 |  |  | $ | 10,636 |  |
| Credit carryforwards | 1,490 |  |  | 2,895 |  |
| Deferred compensation | 1,681 |  |  | 1,590 |  |
| Uniform capitalization and inventory | 1,067 |  |  | 983 |  |
| Stock-based compensation | 1,079 |  |  | 744 |  |
| Reserve for accrued employee benefits | 929 |  |  | 752 |  |
| Warranty accrual | 655 |  |  | 682 |  |
| Accrued legal | 112 |  |  | 115 |  |
| Postretirement benefits liability | 111 |  |  | 110 |  |
| Other | 379 |  |  | 344 |  |
| Deferred tax assets | $ | 18,326 |  |  | $ | 18,851 |  |
| Deferred Tax Liabilities: |  |  |  |
| Depreciation and amortization | $ | (5,035) |  |  | $ | (5,138) |  |
| Retention and other | (620) |  |  | (365) |  |
| Deferred tax liabilities | $ | (5,655) |  |  | $ | (5,503) |  |
| Less: valuation allowance | (9,027) |  |  | (8,231) |  |
| Net deferred tax asset | $ | 3,644 |  |  | $ | 5,117 |  |

[0000080420-20-000036:notes:130]
As of September 30, 2020, we had tax credit carryforwards of $0.1 million not reserved with a valuation allowance that are available to reduce future U.S. federal tax liabilities. The majority of these tax credit carryforwards expire beginning in 2030. In addition, we had international net operating loss carryforwards of $0.8 million that were not reserved with a valuation allowance available to offset future taxable income in the respective jurisdictions, with approximately $0.2 million expiring in 2029 and 2030 and the remainder having an indefinite carryforward period.

[0000080420-20-000036:notes:131]
We have established a valuation allowance in the amount of $9.0 million primarily related to the Canadian and U.K. net deferred tax assets. The net change in the total valuation allowance during the year was $0.8 million which was largely a result of the establishment of a valuation allowance on the net deferred tax assets of the U.K. In assessing the realizability of net deferred tax assets, we consider whether it is more-likely-than-not that some portion or all of the net deferred tax assets may not be realized. The ultimate realization of net deferred tax assets is dependent on the generation of future taxable income during the periods in which those temporary differences become deductible.

[0000080420-20-000036:notes:132]
A reconciliation of the beginning and ending amount of the unrecognized tax benefits follows (in thousands):

[0000080420-20-000036:notes:133]
|  | Year Ended September 30, |
|  | 2020 |  | 2019 |  | 2018 |
| Balance at beginning of period | $ | 2,703 |  |  | $ | 1,854 |  |  | $ | 1,219 |  |
| Increases related to tax positions taken during the current period | 220 |  |  | 240 |  |  | 180 |  |
| Increases related to tax positions taken during a prior period | 97 |  |  | 609 |  |  | 455 |  |
| Decreases related to expiration of statute of limitations | (545) |  |  | — |  |  | — |  |
| Decreases related to settlement with taxing authorities | (1,223) |  |  | — |  |  | — |  |
| Balance at end of period | $ | 1,252 |  |  | $ | 2,703 |  |  | $ | 1,854 |  |

[0000080420-20-000036:notes:134]
Included in the balance of unrecognized tax benefits at the end of Fiscal 2020, 2019, and 2018 are $0.8 million, $2.1 million, and $1.3 million, respectively, of tax benefits that, if recognized, would affect the effective tax rate. Our policy is to recognize interest and penalties related to income tax matters as tax expense. The amount of interest and penalty expense recorded for the year ended September 30, 2020 was not material.

[0000080420-20-000036:notes:135]
Due to the expiration of certain federal statutes of limitations and the settlement of the IRS audit discussed above, management believes that, within the next twelve months, it is reasonably possible that the unrecognized tax benefits will decrease by approximately $0.1 million due to the settlement with taxing authorities related to voluntary filings. We are unable to make reasonably reliable estimates regarding the timing of future cash outflows, if any, associated with the remaining unrecognized tax benefits for the open periods of Fiscal 2018 – 2020.
Management believes that an adequate provision has been made for any adjustments that may result from tax examinations. However, the outcome of tax audits cannot be predicted with certainty. If any issues addressed in our tax audits are resolved in a manner not consistent with management’s expectations, we could be required to adjust our provision for income tax in the period such resolution occurs.


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0000080420-20-000036:notes:136]
Employee Benefit Plans
Retirement Plans

[0000080420-20-000036:notes:137]
We have defined employee contribution plans for substantially all of our U.S. employees (401(k) plan) and our Canadian employees (Registered Retirement Savings Plan). We recognized expenses under these plans primarily related to matching contributions of $3.1 million, $3.2 million and $2.8 million in Fiscal 2020, 2019 and 2018, respectively.

[0000080420-20-000036:notes:138]
Deferred Compensation

[0000080420-20-000036:notes:139]
We offer a non-qualified deferred compensation plan to a select group of management and highly compensated individuals. The plan permits the deferral of up to 50% of a participant’s base salary and/or 100% of a participant’s annual incentive bonus. The deferrals are held in a separate trust, an irrevocable rabbi trust (the Rabbi Trust), which has been established to administer the plan. The Rabbi Trust is intended to be used as a source of funds to match respective funding obligations to participants. The assets of the trust are subject to the claims of our creditors in the event that we become insolvent. Consequently, the Rabbi Trust qualifies as a grantor trust for income tax purposes. We make periodic payments into company-owned life insurance policies held in this Rabbi Trust to fund the expected obligations arising under this plan. Changes in the deferred compensation balance are recorded to compensation expense and reflected within the selling, general and administrative line in the Consolidated Statements of Operations. The plan is not qualified under Section 401 of the Internal Revenue code. We recorded net compensation expense adjustments of $0.1 million related to this plan in Fiscal 2020. At September 30, 2020, total assets held by the trustee were $7.4 million and recorded in other assets and the liability was $6.6 million and recorded in other long-term liabilities in our Consolidated Balance Sheets. Of the $7.4 million of assets held by the trustee, $7.2 million is invested in company-owned life insurance policies and the remainder in mutual funds.

[0000080420-20-000036:notes:140]
Certain former executives were provided an executive benefit plan that provides for fixed payments upon normal retirement on or after age 65 and the completion of at least 10 years of continuous employment. The estimated present value of these payments was accrued over the service life of these individuals, and $0.1 million is recorded in deferred compensation related to this executive benefit plan. To assist in funding the deferred compensation liability, we invested in company-owned life insurance policies. The cash surrender value of these policies is presented in other assets and was $3.3 million at September 30, 2020.

[0000080420-20-000036:notes:141]
Retiree Medical Plan

[0000080420-20-000036:notes:142]
We have a plan that extends health benefits to retirees that are also available to active employees under our existing health plans. This plan is unfunded. The plan provides coverage for employees with at least 10 years of service who are age 55 or older but less than 65. The retiree is required to pay the COBRA rate less a subsidy provided by us based on years of service at the time of retirement. The unfunded liability is recorded in other long-term liabilities and was $0.9 million as of both September 30, 2020 and 2019. Our net periodic postretirement benefit expenses have been less than $0.1 million for the last three fiscal years. Due to the immateriality of the costs and liabilities of this plan, no further disclosure is being presented.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0000080420-20-000036:notes:143]
Stock-Based Compensation
We have the following stock-based compensation plans:

[0000080420-20-000036:notes:144]
Restricted Stock Units

[0000080420-20-000036:notes:145]
In February 2014, our stockholders approved and adopted at the Annual Meeting of Stockholders the 2014 Equity Incentive Plan (the 2014 Plan), which replaced our 2006 Equity Compensation Plan (2006 Plan). Persons eligible to receive awards under the 2014 Plan include our officers and employees. The 2014 Plan authorizes stock options, stock appreciation rights, restricted stock, restricted stock units and performance-based awards, as well as certain other awards.

[0000080420-20-000036:notes:146]
In accordance with the 2014 Plan, the Compensation Committee has authorized grants of restricted stock units (RSUs) to certain officers and key employees of the company. The fair value of the RSUs is based on the closing price of our common stock as reported on the NASDAQ Global Market on the grant dates. Typically, these grants vest over a three-year period from their date of issuance. Fifty to sixty percent of the grant is time-based and vests over a three-year period on each anniversary of the grant date, based on continued employment. The remaining forty to fifty percent of the grant is earned based on the three-year earnings performance of the Company following the grant date. At September 30, 2020, there were 154,034 RSUs outstanding. The RSUs do not have voting rights but receive dividend equivalents upon vesting. Additionally, the shares of common stock underlying the RSUs are not considered issued and outstanding until vested and common stock is issued.

[0000080420-20-000036:notes:147]
Total RSU activity (number of shares) for the past fiscal year is summarized below:

[0000080420-20-000036:notes:148]
|  | Number ofRestrictedStockUnits |  | WeightedAverageGrant ValuePer Share |
| Outstanding at September 30, 2019 | 131,850 |  |  | $ | 33.76 |  |
| Granted | 72,551 |  |  | 38.13 |  |
| Vested | (49,617) |  |  | 35.16 |  |
| Forfeited/cancelled | (750) |  |  | 33.16 |  |
| Outstanding at September 30, 2020 | 154,034 |  |  | $ | 35.37 |  |

[0000080420-20-000036:notes:149]
We have reserved 750,000 shares of common stock for issuance under the 2014 Plan. As of September 30, 2020, there were 530,036 shares of common stock available for future grants.

[0000080420-20-000036:notes:150]
Restricted Stock

[0000080420-20-000036:notes:151]
In February 2014, our stockholders approved the 2014 Non-Employee Director Equity Incentive Plan (the 2014 Director Plan). The total number of shares of common stock reserved under the plan is 150,000 shares. The plan is administered by the Compensation Committee. Eligibility to participate in the plan is limited to those individuals who are members of the Board of Directors of the Company and who are not employees of the Company or any affiliate of the Company.

[0000080420-20-000036:notes:152]
Under the terms of the 2014 Director Plan, the maximum number of shares that may be granted during any calendar year to any individual is 12,000 shares. The total number of shares that may be issued for awards to any single participant during a calendar year for other stock-based awards (excluding stock options and SARs) is 4,000 shares. The Compensation Committee has determined that each non-employee director will receive 2,400 restricted shares of the Company’s common stock annually. Fifty percent of the restricted stock granted to each of our non-employee directors vests immediately, while the remaining fifty percent vests on the anniversary of the grant date. Compensation expense is recognized immediately for the first fifty percent of the restricted stock granted, while compensation expense for the remaining fifty percent is recognized over the remaining vesting period.

[0000080420-20-000036:notes:153]
Under this 2014 Director Plan, in February 2020, 16,800 shares of restricted stock were issued to our non-employee directors at a price of $36.25 per share. In February 2019, we issued 14,000 shares of restricted stock to our non-employee directors at a

[0000080420-20-000036:notes:154]
price of $34.02 per share. The total number of shares of common stock available for future awards under the 2014 Director plan was 39,800 shares as of September 30, 2020.

[0000080420-20-000036:notes:155]
At September 30, 2020 and 2019, there were 8,400 and 7,000 shares of unvested restricted stock outstanding, respectively. Total compensation expense related to restricted stock grants under all plans was $0.6 million, $0.5 million and $0.5 million for the years ended September 30, 2020, 2019 and 2018, respectively. Total compensation expense related to RSUs under all plans was $2.9 million, $3.3 million and $2.7 million for the years ended September 30, 2020, 2019 and 2018, respectively.
We record the amortization of non-vested restricted stock and restricted stock units as an increase to additional paid-in capital. As of September 30, 2020 and 2019, amounts of deferred compensation expense not yet recognized related to non-vested stock and RSUs totaled $1.2 million and $1.0 million, respectively. As of September 30, 2020, the total weighted average remaining contractual life of our non-vested restricted stock and RSUs is approximately six months and 1.5 years, respectively.


## us-gaap:FairValueDisclosuresTextBlock

[0000080420-20-000036:notes:156]
Fair Value Measurements
We measure certain financial assets and liabilities at fair value. Fair value is defined as an “exit price,” which represents the amount that would be received to sell an asset or paid to transfer a liability in an orderly transaction between market participants as of the measurement date. As such, fair value is a market-based measurement that should be determined based on assumptions that market participants would use in valuing an asset or liability. The accounting guidance requires the use of valuation techniques to measure fair value that maximize the use of observable inputs and minimize the use of unobservable inputs. As a basis for considering such assumptions and inputs, a fair value hierarchy has been established that identifies and prioritizes three levels of inputs to be used in measuring fair value.

[0000080420-20-000036:notes:157]
The three levels of the fair value hierarchy are as follows:

[0000080420-20-000036:notes:158]
Level 1 — Observable inputs such as quoted prices (unadjusted) in active markets for identical assets or liabilities.

[0000080420-20-000036:notes:159]
Level 2 — Inputs other than the quoted prices in active markets that are observable either directly or indirectly, including: quoted prices for similar assets and liabilities in active markets; quoted prices for identical or similar assets and liabilities in markets that are not active or other inputs that are observable or can be corroborated by observable market data.

[0000080420-20-000036:notes:160]
Level 3 — Unobservable inputs that are supported by little or no market data and require the reporting entity to develop its own assumptions.

[0000080420-20-000036:notes:161]
The following table summarizes the fair value of our assets and liabilities that were accounted for at fair value on a recurring basis as of September 30, 2020 (in thousands):

[0000080420-20-000036:notes:162]
|  | Fair Value Measurements at September 30, 2020 |
|  | Quoted Prices inActive Markets forIdentical Assets(Level 1) |  | Significant OtherObservableInputs(Level 2) |  | SignificantUnobservableInputs(Level 3) |  | Fair Value at September 30, 2020 |
| Assets: |  |  |  |  |  |  |  |
| Cash and cash equivalents | $ | 160,216 |  |  | $ | — |  |  | $ | — |  |  | $ | 160,216 |  |
| Short-term investments | 18,705 |  |  | — |  |  | — |  |  | 18,705 |  |
| Other assets | — |  |  | 7,351 |  |  | — |  |  | 7,351 |  |
| Liabilities: |  |  |  |  |  |  |  |
| Deferred compensation | — |  |  | 6,569 |  |  | — |  |  | 6,569 |  |

[0000080420-20-000036:notes:163]
The following table summarizes the fair value of our assets and liabilities that were accounted for at fair value on a recurring basis as of September 30, 2019 (in thousands):

[0000080420-20-000036:notes:164]
|  | Fair Value Measurements at September 30, 2019 |
|  | Quoted Prices inActive Markets forIdentical Assets(Level 1) |  | Significant OtherObservableInputs(Level 2) |  | SignificantUnobservableInputs(Level 3) |  | Fair Value at September 30, 2019 |
| Assets: |  |  |  |  |  |  |  |
| Cash and cash equivalents | $ | 118,639 |  |  | $ | — |  |  | $ | — |  |  | $ | 118,639 |  |
| Short-term investments | 6,042 |  |  | — |  |  | — |  |  | 6,042 |  |
| Other assets | — |  |  | 6,825 |  |  | — |  |  | 6,825 |  |
| Liabilities: |  |  |  |  |  |  |  |
| Deferred compensation | — |  |  | 6,249 |  |  | — |  |  | 6,249 |  |

[0000080420-20-000036:notes:165]
Fair value guidance requires certain fair value disclosures to be presented in both interim and annual reports. The estimated fair value amounts of financial instruments have been determined using available market information and valuation methodologies described below.

[0000080420-20-000036:notes:166]
Cash and cash equivalents - Cash and cash equivalents, primarily funds held in money market savings instruments, are reported at their current carrying value, which approximates fair value due to the short-term nature of these instruments and are included in cash and cash equivalents in our Consolidated Balance Sheets.

[0000080420-20-000036:notes:167]
Other Assets and Deferred Compensation – We hold investments in an irrevocable Rabbi Trust for our deferred compensation plan. The assets are primarily related to company-owned life insurance policies and are included in other assets in the accompanying Consolidated Balance Sheets. Because the mutual funds and company-owned life insurance policies are combined in the plan, they are therefore categorized as Level 2 in the fair value measurement hierarchy. The deferred compensation liability represents the investment options that the plan participants have designated to serve as the basis for measurement of the notional value of their accounts.  Because the deferred compensation liability is intended to offset the plan assets, it is therefore also categorized as Level 2 in the fair value measurement hierarchy.


## us-gaap:LesseeOperatingLeasesTextBlock

[0000080420-20-000036:notes:168]
Leases
Our leases consist primarily of office and manufacturing space, construction equipment and office equipment. All of our future lease obligations are related to non-cancelable operating leases. The most significant portion of our lease portfolio relates to leases of office and manufacturing facilities in Canada which we no longer occupy. We currently sublease the majority of these Canadian facilities. The following table provides a summary of lease cost components for the year ended September 30, 2020 (in thousands):

[0000080420-20-000036:notes:169]
| Lease Cost |  | 2020 |
| Operating lease cost |  | $ | 2,389 |  |
| Less: sublease income |  | (555) |  |
| Variable lease cost(1) |  | 351 |  |
| Short-term lease cost(2) |  | 677 |  |
| Total lease cost |  | $ | 2,862 |  |
| (1) Variable lease cost represents common area maintenance charges related to our Canadian office space lease. |
| (2) Short-term lease cost includes leases and rentals with initial terms of one year or less. |  |  |

[0000080420-20-000036:notes:170]
For the years ended September 30, 2019 and 2018, rent expense related to operating leases was $3.5 million and $3.4 million; however, these amounts did not include rent expense related to leases and rentals with initial terms of one year or less, which are included in short-term cost in the table above. For the years ended September 30, 2019 and 2018, sublease income from third parties was $1.3 million and $1.5 million; however, these amounts included common area maintenance charges, which are included in variable lease cost in the table above.

[0000080420-20-000036:notes:171]
In Fiscal 2019, we recorded additional lease expense of $0.7 million related to certain facility leases in Canada that are no longer utilized in our operations. In Fiscal 2018, we incurred approximately $0.8 million due to anticipated losses on the sublet of a Canadian facility we exited in a prior period.

[0000080420-20-000036:notes:172]
We recognize operating lease assets and operating lease liabilities representing the present value of the remaining lease payments for leases with initial terms greater than twelve months. Leases with initial terms of twelve months or less are not recorded in our Consolidated Balance Sheets. Our operating lease assets have been reduced by a lease accrual of $0.6 million related to certain unused facility leases in Canada. The following table provides a summary of the operating lease assets and operating lease liabilities included in our Consolidated Balance Sheets as of September 30, 2020 (in thousands):

[0000080420-20-000036:notes:173]
| Operating Leases |  | September 30, 2020 |
| Assets: |  |  |
| Operating lease assets, net |  | $ | 5,217 |  |
| Liabilities: |  |  |
| Current operating lease liabilities |  | 2,352 |  |
| Long-term operating lease liabilities |  | 3,434 |  |
| Total lease liabilities |  | $ | 5,786 |  |

[0000080420-20-000036:notes:174]
The following table provides the maturities of our operating lease liabilities as of September 30, 2020 (in thousands):

[0000080420-20-000036:notes:175]
|  |  | Operating Leases |
| 2021 |  | $ | 2,581 |  |
| 2022 |  | 2,231 |  |
| 2023 |  | 1,187 |  |
| 2024 |  | 85 |  |
| 2025 |  | — |  |
| Thereafter |  | — |  |
| Total future minimum lease payments |  | $ | 6,084 |  |
| Less: present value discount (imputed interest) |  | (298) |  |
| Present value of lease liabilities |  | $ | 5,786 |  |

[0000080420-20-000036:notes:176]
The weighted average discount rate as of September 30, 2020 was 4.19%. The weighted average remaining lease term was 2.55 years at September 30, 2020.


## us-gaap:SegmentReportingDisclosureTextBlock

[0000080420-20-000036:notes:177]
Segment Information
We manage our business as one reportable operating segment related to the development, design, manufacturing and servicing of custom-engineered equipment and systems for the distribution, control and monitoring of electrical energy.

[0000080420-20-000036:notes:178]
Revenues by country represent sales to unaffiliated customers as determined by the ultimate destination of our products and services, summarized for the last three fiscal years by region in the table below (in thousands):

[0000080420-20-000036:notes:179]
|  | Year Ended September 30, |
|  | 2020 |  | 2019 |  | 2018 |
| United States | $ | 397,983 |  |  | $ | 406,609 |  |  | $ | 335,743 |  |
| Canada | 66,064 |  |  | 64,326 |  |  | 42,235 |  |
| Middle East and Africa | 18,162 |  |  | 18,420 |  |  | 38,490 |  |
| Far East | 18,079 |  |  | 11,405 |  |  | 12,976 |  |
| Europe | 15,866 |  |  | 13,746 |  |  | 10,538 |  |
| Mexico, Central and South America | 2,345 |  |  | 2,674 |  |  | 8,734 |  |
| Total revenues | $ | 518,499 |  |  | $ | 517,180 |  |  | $ | 448,716 |  |

[0000080420-20-000036:notes:180]
Long-lived assets by country consist of property, plant and equipment, net of accumulated depreciation and are determined based on the location of the tangible assets, summarized for the last two fiscal years in the table below (in thousands):

[0000080420-20-000036:notes:181]
|  | September 30, |
|  | 2020 |  | 2019 |
| Long-lived assets: |  |  |  |
| United States | $ | 67,071 |  |  | $ | 71,325 |  |
| Canada | 42,580 |  |  | 44,933 |  |
| United Kingdom | 4,721 |  |  | 4,554 |  |
| Total | $ | 114,372 |  |  | $ | 120,812 |  |


## us-gaap:QuarterlyFinancialInformationTextBlock

[0000080420-20-000036:notes:182]
Quarterly Information
The table below sets forth the unaudited consolidated operating results by fiscal quarter for the years ended September 30, 2020 and 2019 (in thousands, except per share data):

[0000080420-20-000036:notes:183]
|  | 2020 Quarters |
|  | First(1) |  | Second(1) |  | Third(1) (2) |  | Fourth(1) (3) |  | 2020 |
| Revenues | $ | 134,150 |  |  | $ | 151,570 |  |  | $ | 118,062 |  |  | $ | 114,717 |  |  | $ | 518,499 |  |
| Gross profit | 21,826 |  |  | 29,685 |  |  | 21,344 |  |  | 21,720 |  |  | 94,575 |  |
| Net income | 2,775 |  |  | 7,421 |  |  | 3,481 |  |  | 2,983 |  |  | 16,660 |  |
| Earnings per share: |  |  |  |  |  |  |  |  |  |
| Basic | $ | 0.24 |  |  | $ | 0.64 |  |  | $ | 0.30 |  |  | $ | 0.26 |  |  | $ | 1.43 |  |
| Diluted | $ | 0.24 |  |  | $ | 0.64 |  |  | $ | 0.30 |  |  | $ | 0.25 |  |  | $ | 1.42 |  |
| (1) The results for the first quarter of Fiscal 2020 demonstrated normal seasonality and were negatively impacted by holidays and work schedules related to other quarterly periods. The results for the second quarter of Fiscal 2020 improved due to the timing of orders and execution of backlog while revenues and gross profit decreased during the third and fourth quarters of Fiscal 2020 due to a decrease in orders resulting from a decline in demand across our industrial end markets, as well as project delays, cancellations and scope reductions associated with the global decline in demand across the oil and gas markets resulting from COVID-19. |
| (2) The results for the third quarter of Fiscal 2020 were negatively impacted by separation costs of $1.4 million as a result of workforce reductions. |
| (3) The results for the fourth quarter of Fiscal 2020 were positively impacted by other income of $0.5 million related to a death benefit received from our company-owned life insurance policy related to a retired employee. |

[0000080420-20-000036:notes:184]
|  | 2019 Quarters |
|  | First(1) |  | Second(1) |  | Third(1) (2) |  | Fourth(1) |  | 2019 |
| Revenues | $ | 109,351 |  |  | $ | 123,737 |  |  | $ | 135,588 |  |  | $ | 148,504 |  |  | $ | 517,180 |  |
| Gross profit | 14,631 |  |  | 20,075 |  |  | 23,715 |  |  | 28,555 |  |  | 86,976 |  |
| Net income (loss) | (2,695) |  |  | 958 |  |  | 5,089 |  |  | 6,538 |  |  | 9,890 |  |
| Earnings (loss) per share: |  |  |  |  |  |  |  |  |  |
| Basic | $ | (0.23) |  |  | $ | 0.08 |  |  | $ | 0.44 |  |  | $ | 0.56 |  |  | $ | 0.85 |  |
| Diluted | $ | (0.23) |  |  | $ | 0.08 |  |  | $ | 0.44 |  |  | $ | 0.56 |  |  | $ | 0.85 |  |
| (1) The results for the first quarter of Fiscal 2019 demonstrated normal seasonality and were negatively impacted by holidays and work schedules relative to other quarterly periods. The results for the subsequent quarters of Fiscal 2019 improved due to the timing of orders and execution of backlog. |
| (2) The results for the third quarter of Fiscal 2019 were favorably impacted by the receipt of a $1.0 million non-recurring business interruption insurance settlement recognized within operating income. |

[0000080420-20-000036:notes:185]
The sum of the individual earnings per share amounts may not agree with year-to-date earnings per share as each period’s computation is based on the weighted-average number of shares outstanding during the period.


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0000080420-20-000036:notes:186]
Separation CostsIn response to the COVID-19 pandemic, reductions in oil and gas demand and volatility of commodity prices, we implemented workforce reductions at most of our locations. As a result, we recorded $1.4 million of separation costs in restructuring and other, net on the Consolidated Statement of Operations during the third quarter of Fiscal 2020.


## us-gaap:SubsequentEventsTextBlock

[0000080420-20-000036:notes:187]
Subsequent EventsOn November 3, 2020, our Board of Directors declared a quarterly cash dividend on our common stock in the amount of $0.26 per share. The dividend is payable on December 16, 2020 to shareholders of record at the close of business on November 18, 2020.
