# POWL MD&A — 0000080420-20-000036


## mdna

[0000080420-20-000036:mdna:1]
Item 7. Management’s Discussion and Analysis of Financial Condition and Results of Operations

[0000080420-20-000036:mdna:2]
Overview

[0000080420-20-000036:mdna:3]
We develop, design, manufacture and service custom-engineered equipment and systems for the distribution, control and monitoring of electrical energy. Headquartered in Houston, Texas, we serve the oil and gas markets, including onshore and offshore oil and gas production, pipeline, refining and LNG terminals, as well as petrochemical, electric utility and light traction power. Revenues and costs are primarily related to custom engineered-to-order equipment and systems and are accounted for under percentage-of-completion accounting, which precludes us from providing detailed price and volume information. Our backlog includes various projects that typically take a number of months to produce.

[0000080420-20-000036:mdna:4]
The markets in which we participate are capital-intensive and cyclical in nature. Cyclicality is predominantly driven by customer demand, global economic conditions and anticipated environmental, safety or regulatory changes that affect the manner in which our customers proceed with capital investments. Our customers analyze various factors including the demand and price for oil, gas and electrical energy, the overall economic and financial environment, governmental budgets, regulatory actions and environmental concerns. These factors influence the release of new capital projects by our customers, which are traditionally awarded in competitive bid situations. Scheduling of projects is matched to the customer requirements, and projects typically take a number of months to produce. Schedules may change during the course of any particular project, and our operating results can, therefore, be impacted by factors outside of our control.

[0000080420-20-000036:mdna:5]
Within the industrial sector, specifically oil, gas and petrochemical, the demand for our electrical distribution solutions is very cyclical and closely correlated to the level of capital expenditures of our end user customers as well as prevailing global economic conditions.

[0000080420-20-000036:mdna:6]
Beginning in late Fiscal 2018, the combination of a growing global economy, abundant sources of favorably priced natural gas feedstock, and an energy industry focus on transition to natural gas and cleaner-burning fuels drove an increase in capital investment opportunities, specifically across the oil, gas and petrochemical sectors. We have seen opportunities for natural gas related projects targeting global demand for cleaner-burning fuels. Additionally, projects within the domestic petrochemical sector have benefited from the low feedstock prices of natural gas. Specific to natural gas, the business was awarded a substantial contract in the second quarter of Fiscal 2020 that will support the integrated electrical distribution requirements for a large domestic industrial complex. This specific project will take over three years to design, manufacture, integrate, test and ship.

[0000080420-20-000036:mdna:7]
Impact of the COVID-19 Pandemic and Oil and Gas Commodity Market Volatility on Powell

[0000080420-20-000036:mdna:8]
The spread of COVID-19 has created significant uncertainty and economic disruption across the world during the second half of Fiscal 2020 and continuing into Fiscal 2021.  This pandemic has negatively impacted energy demand, which in turn has resulted in considerable volatility across the oil and gas commodity markets. The demand for our products and services as well as our operations have been negatively impacted by COVID-19, resulting from the associated reduction in oil and gas demand and volatility in commodity prices noted above.

[0000080420-20-000036:mdna:9]
From an operational standpoint, although our facilities are located in areas that have in the past been subject to stay-at-home orders, we have not closed any of our facilities for an extended period of time and have operated as an "essential business" under local government orders. However, as a result of the uncertainty that our customers are currently experiencing, some projects have been cancelled, and certain of our customers have asked that we delay our manufacturing on their projects as their operations have been negatively impacted by this pandemic and the reduced oil and gas demand. We have experienced supply disruptions and anticipate that these supply disruptions may continue. We continue to monitor and work with our suppliers who

[0000080420-20-000036:mdna:10]
have been impacted by this pandemic to ensure that we are able to meet our customer commitments. We also have reviewed and will continue to review contracts with our suppliers, making adjustments accordingly. We continue to take the necessary steps to ensure the safety of our employees, customers and vendors. These steps include, among others, promoting increased social distancing practices and enhanced cleaning efforts in our offices and facilities. We are utilizing and exploring the use of technology across our operations to further enhance social distancing and improve safety. These safety precautions have and may continue to have an adverse impact on our costs, efficiency and productivity going forward.

[0000080420-20-000036:mdna:11]
In response to the lower demand across select end markets, we have and will continue to take various actions to reduce costs. During the third quarter of Fiscal 2020, we reduced our global workforce by approximately 12% resulting in severance costs of $1.4 million. Additionally, we instituted a temporary furlough program for our salaried workforce in North America which reduced salaried compensation by $1.3 million in the second half of Fiscal 2020. We have also reduced our capital and discretionary spending in response to current business conditions and will continue to monitor the economic conditions during Fiscal 2021.

[0000080420-20-000036:mdna:12]
As discussed further under the heading "Outlook" below, it is difficult to predict the economic impact that this pandemic, as well as reduced oil and gas demand and commodity price volatility, may have on our business, results of operations and cash flows going forward.

[0000080420-20-000036:mdna:13]
Results of Operations

[0000080420-20-000036:mdna:14]
Twelve Months Ended September 30, 2020 Compared to Twelve Months Ended September 30, 2019

[0000080420-20-000036:mdna:15]
Revenue and Gross Profit

[0000080420-20-000036:mdna:16]
Revenues increased by $1.3 million, to $518.5 million in Fiscal 2020 resulting from the solid backlog position at the beginning of Fiscal 2020 and the improved market conditions across our petrochemical and oil and gas markets beginning in late Fiscal 2018. Domestic revenues decreased by 2%, or $6.2 million, to $398.8 million in Fiscal 2020. International revenues increased by 7% to $119.7 million in Fiscal 2020, driven largely by increased end market activity across the Middle East and Asia. Our international revenues include both revenues generated from our international facilities as well as revenues from export projects generated at our domestic facilities.

[0000080420-20-000036:mdna:17]
Revenue from our core oil and gas markets decreased by 19%, or $47.1 million, to $195.2 million in Fiscal 2020 while petrochemical revenue increased by 36%, or $33.3 million, to $126.7 million in Fiscal 2020. The economic impact resulting from the COVID-19 pandemic and associated reduction in global demand across the oil and gas end markets has negatively impacted our orders rate and corresponding revenue. The partial offset in favorable petrochemical revenues is being generated by the successful execution of previously booked orders from our petrochemical end markets and lower natural gas prices. Revenue from utility markets increased by 5%, or $3.8 million, to $88.8 million and traction market revenue increased by 58%, or $15.6 million, to $42.4 million in Fiscal 2020, primarily driven by an increase in volume across our international locations. Revenue from all other markets combined decreased by $4.3 million to $65.4 million in Fiscal 2020.

[0000080420-20-000036:mdna:18]
Gross profit increased by 9%, or $7.6 million, to $94.6 million in Fiscal 2020. Gross profit as a percentage of revenues increased to 18% in Fiscal 2020, compared to 17% in Fiscal 2019, due to strong margins in backlog as well as cost efficiencies and productivity in our North American manufacturing facilities.

[0000080420-20-000036:mdna:19]
Selling, General and Administrative Expenses

[0000080420-20-000036:mdna:20]
Selling, general and administrative expenses decreased 3%, or $2.3 million, to $67.7 million in Fiscal 2020, primarily due to decreased personnel costs as a result of workforce reductions and lower travel-related costs resulting from the COVID-19 pandemic. Selling, general and administrative expenses, as a percentage of revenues, decreased to 13% in Fiscal 2020 compared to 14% in Fiscal 2019, primarily due to our continued focus on aligning our cost structure with anticipated volume.

[0000080420-20-000036:mdna:21]
Insurance Proceeds

[0000080420-20-000036:mdna:22]
In Fiscal 2019, we settled a 2017 business interruption insurance claim relating to Hurricane Harvey and received proceeds of $1.0 million, which was included within operating income.

[0000080420-20-000036:mdna:23]
Restructuring and Other, Net

[0000080420-20-000036:mdna:24]
In response to the COVID-19 pandemic, reductions in global oil and gas demand and volatility of commodity prices, we implemented workforce reductions across the business. As a result, we recorded $1.4 million of separation costs during Fiscal 2020.

[0000080420-20-000036:mdna:25]
In Fiscal 2019, we recorded additional lease expense of $0.7 million related to certain unused facility leases in Canada. We also recorded income from a recovery of $0.7 million in Fiscal 2019 as a result of a favorable settlement of a claim related to the divestiture of a subsidiary in Fiscal 2014.

[0000080420-20-000036:mdna:26]
Other Income

[0000080420-20-000036:mdna:27]
During Fiscal 2020, we recorded other income of $0.5 million related to a death benefit received from our company-owned life insurance policy related to a retired employee.

[0000080420-20-000036:mdna:28]
Income Tax Provision

[0000080420-20-000036:mdna:29]
We recorded an income tax provision of $3.7 million in Fiscal 2020, resulting in an effective tax rate of 18%, compared to an income tax provision of $2.4 million in Fiscal 2019 at an effective tax rate of 20%. In Fiscal 2020, the effective tax rate was favorably impacted by the current year estimated Research and Development Tax Credit (R&D Tax Credit) as well as the utilization of net operating loss carryforwards in Canada that were fully reserved with a valuation allowance. Additionally, we reversed a reserve of $1.7 million resulting from a favorable settlement of an IRS audit and the expiration of statutes of limitations. The effective tax rate for Fiscal 2020 was negatively impacted by the valuation allowance set up against our U.K. deferred tax assets in the amount of $0.5 million. The effective tax rate for Fiscal 2019 approximated the U.S. federal statutory rate as the immaterial losses incurred by various foreign jurisdictions reserved with a valuation allowance had a minimal impact on the effective tax rate.

[0000080420-20-000036:mdna:30]
Net Income

[0000080420-20-000036:mdna:31]
In Fiscal 2020, net income of $16.7 million, or $1.42 per diluted share, improved from a net income of $9.9 million, or $0.85 per diluted share in Fiscal 2019, primarily from increased gross profit resulting from favorable productivity, as well as lower selling and administrative costs and the favorable impact of the reversal of the reserves for unrecognized tax benefits, which was partially offset by the separation costs incurred in Fiscal 2020.

[0000080420-20-000036:mdna:32]
Backlog

[0000080420-20-000036:mdna:33]
The order backlog at September 30, 2020 was $476.8 million, a 14% increase from the $419.0 million at September 30, 2019. The increase in backlog is due in large part to the substantial contract awarded in the second quarter of Fiscal 2020 that will support the integrated electrical distribution requirements for a large domestic industrial complex. Bookings, net of cancellations and scope reductions, decreased by 15% in Fiscal 2020 to $576.8 million, compared to $676.1 million in Fiscal 2019, primarily due to decreased global demand across our core oil and gas markets.

[0000080420-20-000036:mdna:34]
Outlook

[0000080420-20-000036:mdna:35]
The markets in which we participate are capital-intensive and cyclical in nature. Cyclicality is predominantly driven by macroeconomic variables that directly impact customer demand. These variables are most often driven by global economic conditions and/or environmental, safety or regulatory changes which may affect the manner in which our customers proceed with capital investments. Our customers routinely analyze various factors including the demand and price for oil, gas and electrical energy, the overall economic and financial environment, governmental budgets, regulatory actions and environmental concerns throughout the procurement decision process. These factors influence the release of new capital projects by our customers, which are traditionally awarded in competitive bid situations. Scheduling of projects is matched to customer requirements, and projects typically take a number of months to produce. Schedules may change during the course of any particular project, and our operating results can, therefore, be impacted by factors outside of our control.

[0000080420-20-000036:mdna:36]
A significant portion of our revenues has historically been from the oil, gas and petrochemical markets. Oil and gas commodity price levels have been unstable over the last several years, and our customers have in certain cases, delayed some of their major capital investment projects. Beginning in late Fiscal 2018 through the first quarter of Fiscal 2020, our customers' decisions to invest in projects across our key oil and gas and petrochemical markets were influenced to some extent by the stabilization of commodity prices and the increased global demand for cleaner-burning fuels during that period of time. We believe that this change in market sentiment during that period of time had a favorable impact on our orders and backlog entering Fiscal 2020.

[0000080420-20-000036:mdna:37]
However, the recent declines in oil prices and the global economic impacts from COVID-19 may have a negative impact on our business going forward, as discussed in more detail below. Specific to the energy industry focus on transition to natural gas and cleaner-burning fuels, the business was awarded a substantial contract in the second quarter of Fiscal 2020 that will support the integrated electrical distribution requirements for a large domestic industrial complex. This specific project has begun and will take over three years to design, manufacture, integrate, test and ship.

[0000080420-20-000036:mdna:38]
Our operating results are impacted by factors such as the timing of new order awards, customer approval of final engineering and design specifications and delays in customer construction schedules, all of which contribute to short-term earnings variability and the timing of project execution. Our operating results also have been, and may continue to be, impacted by the timing and resolution of change orders, project close-out and resolution of potential contract claims and liquidated damages, all of which could improve or deteriorate gross margins during the period in which these items are resolved with our customers. These factors may result in periods of underutilization of our resources and facilities, which may negatively impact our ability to cover our fixed costs. The increased orders recognized in Fiscal 2018 and 2019 have led to improved revenue and operating results for Fiscal 2020. We continue to monitor the variables that impact our markets while adjusting to the global conditions in order to maintain a competitive cost and technological advantage in the markets that we serve.

[0000080420-20-000036:mdna:39]
The spread of COVID-19 has created and continues to create significant uncertainty and economic disruption across the world during the second half of Fiscal 2020 and continuing into Fiscal 2021. This pandemic has negatively impacted global energy demand, which in turn has resulted in considerable volatility across the oil and gas commodity markets. Certain of our customers have asked that we delay our manufacturing on their projects as their operations have been negatively impacted by these factors.

[0000080420-20-000036:mdna:40]
As a result of these circumstances, we anticipate that a decrease in commercial activity may negatively impact our business, results of operations and cash flows going forward. We have and may need to continue to adjust our workforce and labor costs to correspond to the reduced customer demand. We will take prudent measures to maintain our strong liquidity and cash position, which may include reducing our capital expenditures and research and development costs, as well as reducing or eliminating future dividend payments. However, the extent to which the COVID-19 pandemic specifically will continue to impact our business will depend on numerous factors that are difficult to predict, some of which include: the duration, spread and severity of the pandemic; governmental actions in response to the pandemic, including travel restrictions and quarantine or related governmental orders; any closures of our offices and facilities or those of our suppliers as a result of the pandemic, and how quickly and to what extent normal economic and operating conditions can resume. Therefore, the magnitude of the impact on our business, results of operations and cash flows is not currently known.

[0000080420-20-000036:mdna:41]
Liquidity and Capital Resources

[0000080420-20-000036:mdna:42]
As of September 30, 2020, current assets exceeded current liabilities by 2.2 times, and our debt to total capitalization was 0.26%.

[0000080420-20-000036:mdna:43]
Cash, cash equivalents and short-term investments increased to $178.9 million at September 30, 2020, compared to $124.7 million at September 30, 2019. This increase in cash was driven in part by the timing of the contract billing milestones related to our recent contract award for a large domestic industrial project as well as the year-over-year reduction in our accounts receivables balance. We believe that our strong working capital position, available borrowings under our credit facility and available cash should be sufficient to finance future operating activities, capital improvements, research and development initiatives and debt repayments for the foreseeable future.

[0000080420-20-000036:mdna:44]
On September 27, 2019, we entered into an Amended and Restated Credit Agreement with Bank of America, N.A. (the "U.S. Revolver") which replaced our prior credit agreement. The U.S. Revolver is a $75.0 million revolving credit facility, which is available for both borrowings and letters of credit and expires September 2024. As of September 30, 2020, there were no amounts borrowed under this facility, and letters of credit outstanding were $38.7 million. As of September 30, 2020, $36.3 million was available for the issuance of letters of credit and borrowing under the U.S. Revolver. Total long-term debt, including current maturities, totaled $0.8 million at September 30, 2020 related to outstanding industrial development revenue bonds. We are required to maintain certain financial covenants, the most significant of which are a consolidated leverage ratio less than 3.0 to 1.0 and a consolidated interest coverage ratio of greater than 3.0 to 1.0. The consolidated leverage ratio is our most restrictive covenant and a decrease in our earnings before interest, taxes, depreciation and amortization (EBITDA) could restrict our ability to issue letters of credit under the U.S. Revolver. For further information regarding our debt, see Notes G and H of Notes to Consolidated Financial Statements.

[0000080420-20-000036:mdna:45]
Approximately $26.2 million of our cash and cash equivalents at September 30, 2020 was held outside of the U.S. for international operations. It is our intention to indefinitely reinvest all current and future foreign earnings internationally in order to ensure sufficient working capital to support our international operations. In the event that we elect to repatriate some or all of the foreign earnings that were previously deemed to be indefinitely reinvested outside the U.S., we may incur additional tax expense upon such repatriation under current tax laws.

[0000080420-20-000036:mdna:46]
Operating Activities

[0000080420-20-000036:mdna:47]
Operating activities provided net cash of $72.4 million and $68.8 million in Fiscal 2020 and Fiscal 2019, respectively. Cash flow from operations is primarily influenced by project volume, the timing of milestone payments from our customers and the payment terms with our suppliers. This increase in operating cash flows was primarily due to the timing of contract billing milestones related to our recent contract award for a large domestic industrial project awarded in the second quarter of Fiscal 2020 as well as a significant reduction in the accounts receivables balance.

[0000080420-20-000036:mdna:48]
Investing Activities

[0000080420-20-000036:mdna:49]
Investing activities used $17.5 million during Fiscal 2020 compared to $3.0 million provided during the same period in Fiscal 2019. The increase in cash used by investing activities in Fiscal 2020 was primarily due to an increase in short-term investments.

[0000080420-20-000036:mdna:50]
Financing Activities

[0000080420-20-000036:mdna:51]
Net cash used in financing activities was $13.1 million in Fiscal 2020 and $13.9 million in Fiscal 2019, which primarily consisted of approximately $12 million of dividends paid in each year.

[0000080420-20-000036:mdna:52]
Contractual and Other Obligations

[0000080420-20-000036:mdna:53]
At September 30, 2020, our long-term contractual obligations were limited to debt and leases. The table below details our commitments by type of obligation, including interest if applicable, and the period that the payment will become due (in thousands).

[0000080420-20-000036:mdna:54]
| Payments Due by Period: |  |  |  |  |  |
|  | Long-Term Debt Obligations |  | Net Operating Lease Obligations |  | Total |
| Less than 1 year | $ | 400 |  |  | $ | 1,980 |  |  | $ | 2,380 |  |
| 1 to 3 years | 401 |  |  | 2,154 |  |  | 2,555 |  |
| 3 to 5 years | — |  |  | 85 |  |  | 85 |  |
| More than 5 years | — |  |  | — |  |  | — |  |
| Total long-term contractual obligations | $ | 801 |  |  | $ | 4,219 |  |  | $ | 5,020 |  |

[0000080420-20-000036:mdna:55]
As of September 30, 2020, the total unrecognized tax benefit related to uncertain tax positions was $1.3 million. We believe that it is reasonably possible that within the next 12 months, the total unrecognized tax benefits will decrease by approximately $0.1 million due to the settlement with taxing authorities related to voluntary filings. We are unable to make reasonably reliable estimates regarding the timing of future cash outflows, if any, associated with the remaining unrecognized tax benefits.

[0000080420-20-000036:mdna:56]
Other Commercial Commitments

[0000080420-20-000036:mdna:57]
We are contingently liable for letters of credit and bank guarantees totaling $45.9 million as of September 30, 2020, with the following potential cash outflows in the event that we are unable to perform under our contracts (in thousands):

[0000080420-20-000036:mdna:58]
| Payments Due by Period: | Letters ofCredit/Bank Guarantees |
| Less than 1 year | $ | 16,096 |  |
| 1 to 3 years | 8,733 |  |
| More than 3 years | 21,088 |  |
| Total long-term commercial obligations | $ | 45,917 |  |

[0000080420-20-000036:mdna:59]
We also had surety bonds totaling $162.4 million that were outstanding at September 30, 2020. Surety bonds are primarily used to guarantee our contract performance to our customers.

[0000080420-20-000036:mdna:60]
Off-Balance Sheet Arrangements

[0000080420-20-000036:mdna:61]
We had no significant off-balance sheet arrangements during the periods presented.

[0000080420-20-000036:mdna:62]
Effects of Inflation

[0000080420-20-000036:mdna:63]
We are subject to inflation, which can cause increases in our costs of raw materials, primarily copper, aluminum and steel. Fixed-price contracts can limit our ability to pass these increases to our customers, thus negatively impacting our earnings. Inflation in commodity prices could potentially impact our operations in future years.

[0000080420-20-000036:mdna:64]
Critical Accounting Policies and Estimates

[0000080420-20-000036:mdna:65]
The preparation of consolidated financial statements in conformity with accounting principles generally accepted in the U.S. requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities, disclosures of contingent assets and liabilities known to exist at the date of the consolidated financial statements and the reported amounts of revenues and expenses during the reporting period. We evaluate our estimates on an ongoing basis, based on historical experience and on various other assumptions that are believed to be reasonable under the circumstances. There can be no assurance that actual results will not differ from those estimates.

[0000080420-20-000036:mdna:66]
We believe the following accounting policies and estimates to be critical in the preparation and reporting of our consolidated financial statements.

[0000080420-20-000036:mdna:67]
Revenue Recognition

[0000080420-20-000036:mdna:68]
Our revenues are primarily generated from the manufacturing of custom-engineered products and systems under long-term fixed-price contracts under which we agree to manufacture various products such as traditional and arc-resistant distribution switchgear and control gear, medium-voltage circuit breakers, monitoring and control communications systems, motor control centers, switches and bus duct systems. These products may be sold separately as an engineered solution, but are typically integrated into custom-built enclosures which we also build.  These enclosures are referred to as power control room substations (PCRs®), custom-engineered modules or electrical houses (E-Houses). Some contracts may also include the installation and the commissioning of these enclosures.

[0000080420-20-000036:mdna:69]
Revenue from these contracts is generally recognized over time utilizing the cost-to-cost method to measure the extent of progress toward the completion of the performance obligation and the recognition of revenue over time. We believe that this method is the most accurate representation of our performance, because it directly measures the value of the services transferred to the customer over time as we incur costs on our contracts. Contract costs include all direct materials, labor, and indirect costs related to contract performance, which may include indirect labor, supplies, tools, repairs and depreciation costs.

[0000080420-20-000036:mdna:70]
We enter into contracts to provide value-added services such as field service inspection, installation, commissioning, modification and repair, as well as retrofit and retrofill components for existing systems. As a practical expedient, if the service contract terms give us the right to invoice the customer for an amount that corresponds directly with the value of our performance completed to date (i.e., a service contract in which we bill a fixed amount for each hour of service provided), then we recognize revenue over time in each reporting period corresponding to the amount that we have the right to invoice. Our performance obligations are satisfied as the work progresses.

[0000080420-20-000036:mdna:71]
We also have sales orders for spare parts and replacement circuit breakers for switchgear that are obsolete or that are no longer produced by the original manufacturer. Revenues from these sales orders are recognized at a point in time when we fulfill our performance obligation to the customer, which is typically upon shipment.

[0000080420-20-000036:mdna:72]
Additionally, some contracts may contain a cancellation clause that could limit the amount of revenue we are able to recognize over time. In these instances, revenue and costs associated with these contracts are deferred and recognized at a point in time when the performance obligation is fulfilled.

[0000080420-20-000036:mdna:73]
Selling and administrative costs incurred in relation to obtaining a contract are typically expensed as incurred. We periodically utilize a third-party sales agent to obtain a contract and will pay a commission to that agent. We record the full commission liability to the third-party sales agents at the order date, with a corresponding deferred asset. As the project progresses, we

[0000080420-20-000036:mdna:74]
record commission expense based on percentage of completion rates that correlate to the project and reduce the deferred asset. Once we have been paid by the customer, we pay the commission, and the deferred liability is reduced.

[0000080420-20-000036:mdna:75]
Performance Obligations

[0000080420-20-000036:mdna:76]
A performance obligation is a promise in a contract or with a customer to transfer a distinct good or service. A contract’s transaction price is allocated to each distinct performance obligation and recognized as revenue as the performance obligations are satisfied. To determine the proper revenue recognition for contracts, we evaluate whether a contract should be accounted for as more than one performance obligation or, less commonly, whether two or more contracts should be combined and accounted for as one performance obligation. This evaluation of performance obligations requires significant judgment. The majority of our contracts have a single performance obligation where multiple engineered products and services are combined into a single, custom-engineered solution. Our contracts generally include a standard assurance warranty that typically ends 18 months after shipment. Occasionally, we provide service-type warranties that will extend the warranty period. These extended warranties qualify as separate performance obligations, and revenue is deferred and recognized over the warranty period. If we determine during the evaluation of the contract that there are multiple performance obligations, we allocate the transaction price to each performance obligation using our best estimate of the standalone selling price of each distinct good or service in the contract.

[0000080420-20-000036:mdna:77]
Remaining unsatisfied performance obligations, which we refer to as backlog, represent the estimated transaction price for goods and services for which we have a material right, but work has not been performed. Backlog may not be indicative of future operating results as orders may be cancelled or modified by our customers. Our backlog does not include service and maintenance-type contracts for which we have the right to invoice as services are performed.

[0000080420-20-000036:mdna:78]
Contract Estimates

[0000080420-20-000036:mdna:79]
Actual revenues and project costs may vary from previous estimates due to changes in a variety of factors. The cost estimation process is based upon the professional knowledge and experience of our engineers, project managers and financial professionals. Factors that are considered in estimating the work to be completed and ultimate contract recovery include the availability and productivity of labor, the nature and complexity of the work to be performed, the availability of materials, and the effect of any delays on our project performance. We periodically review our job performance, job conditions, estimated profitability and final contract settlements, including our estimate of total costs and make revisions to costs and income in the period in which the revisions are probable and reasonably estimable. Whenever revisions of estimated contract costs and contract values indicate that the contract costs will exceed estimated revenues, thus creating a loss, a provision for the total estimated loss is recorded in that period.

[0000080420-20-000036:mdna:80]
Variable Consideration

[0000080420-20-000036:mdna:81]
It is common for our long-term contracts to contain variable consideration that can either increase or decrease the transaction price. Due to the nature of our contracts, estimating total cost and revenue can be complex and subject to variability due to change orders, back charges, spare parts, early completion bonuses, customer allowances and liquidated damages. We estimate the amount of variable consideration based on the expected value method, which is the sum of probability-weighted amount, or the most likely amount method, which uses various factors including experience with similar transactions and assessment of our anticipated performance. Variable consideration is included in the transaction price if legally enforceable and to the extent it is probable that a significant reversal of cumulative revenue recognized will not occur once the uncertainty associated with the variable consideration is resolved.

[0000080420-20-000036:mdna:82]
Contract Modifications

[0000080420-20-000036:mdna:83]
Contracts may be modified for changes in contract specifications and requirements. We consider contract modifications to exist when the modification either creates new or changes the enforceable rights and obligations under the contract. Most of our contract modifications are for goods and services that are not distinct from the existing performance obligation. Contract modifications result in a cumulative catch-up adjustment to revenue based on our measure of progress for the performance obligation.

[0000080420-20-000036:mdna:84]
Impairment of Long-Lived Assets

[0000080420-20-000036:mdna:85]
We review long-lived assets for impairment whenever events or changes in circumstances indicate that the carrying value may not be realizable. If an evaluation is required, the estimated future undiscounted cash flows associated with the asset are compared to the asset’s carrying amount to determine if recording an impairment of such asset is necessary. This requires us to make long-term forecasts of the future revenues and costs related to the assets subject to review. Forecasts require assumptions

[0000080420-20-000036:mdna:86]
about demand for our products and future market conditions. Estimating future cash flows requires significant judgment, and our projections may vary from cash flows eventually realized. Future events and unanticipated changes to assumptions could require a provision for impairment in a future period. The effect of any impairment would be reflected in income (loss) from operations in the Consolidated Statements of Operations. In addition, we estimate the useful lives of our long-lived assets and other intangibles and periodically review these estimates to determine whether these lives are appropriate.

[0000080420-20-000036:mdna:87]
Accruals for Contingent Liabilities

[0000080420-20-000036:mdna:88]
From time to time, contingencies such as insurance-related claims, liquidated damages and legal claims arise in the normal course of business. Pursuant to applicable accounting standards, we must evaluate such contingencies to subjectively determine the likelihood that an asset has been impaired, or a liability has been incurred at the date of the financial statements, as well as evaluate whether the amount of the loss can be reasonably estimated. If the likelihood is determined to be probable, and it can be reasonably estimated, the estimated loss is recorded. The amounts we record for contingent liabilities require judgments regarding the amount of expenses that will ultimately be incurred. We use past experience and history, as well as the specific circumstances surrounding each contingent liability, including estimated legal costs, in evaluating the amount of liability that should be recorded. Actual results could differ from our estimates.

[0000080420-20-000036:mdna:89]
Warranty Costs

[0000080420-20-000036:mdna:90]
Estimated costs of warranties are accrued based on historical warranty claim costs in relation to current revenues. In addition, specific provisions are made when product failures are projected outside historical experience. Our standard terms and conditions of sale include a warranty for parts and service for the earlier of 18 months from the date of shipment or 12 months from the date of energization, whichever occurs first. Actual results could differ from our estimates.

[0000080420-20-000036:mdna:91]
Occasionally projects require warranty terms that are longer than our standard terms due to the nature of the project. Extended warranty terms may be negotiated and included in our contracts. The allocated revenue associated with the extended warranty is deferred and recorded as a contract liability and recognized over the extended warranty period.

[0000080420-20-000036:mdna:92]
Accounting for Income Taxes

[0000080420-20-000036:mdna:93]
We account for income taxes under the asset and liability method, based on the income tax laws and rates in the countries in which operations are conducted, and income is earned. This approach requires the recognition of deferred tax assets and liabilities for the expected future tax consequences of temporary differences between the carrying amounts and the tax basis of assets and liabilities. Developing our provision for income taxes requires significant judgment and expertise in federal, international and state income tax laws, regulations and strategies, including the determination of deferred tax assets and liabilities and, if necessary, any valuation allowances that may be required for deferred tax assets. In assessing the extent to which net deferred tax assets may be realized, we consider whether it is more likely than not that some portion or all of the net deferred tax assets may not be realized. The ultimate realization of net deferred tax assets is dependent on the generation of future taxable income during the periods in which those temporary differences become deductible. Estimates may change as new events occur, estimates of future taxable income during the carryforward period are reduced or increased, additional information becomes available, or operating environments change, which may result in a full or partial reversal of the valuation allowance. We will continue to assess the adequacy of the valuation allowance on a quarterly basis. Our judgments and tax strategies are subject to audit by various taxing authorities.

[0000080420-20-000036:mdna:94]
The objectives of accounting for income taxes are to recognize the amount of taxes payable or refundable for the current year and deferred tax liabilities and assets for the future tax consequences of events that have been recognized in an entity’s financial statements or tax returns. We recognize the tax benefit from an uncertain tax position only if it is more likely than not that the tax position will be sustained on examination by the taxing authorities, based on the technical merits of the position. The tax benefits recognized in the financial statements from such a position should be measured based on the largest benefit that has a greater than 50% likelihood of being realized upon ultimate settlement. Accounting literature also provides guidance on derecognition of income tax assets and liabilities, classification of current and deferred income tax assets and liabilities, accounting for interest and penalties associated with tax positions, and income tax disclosures. Judgment is required in assessing the future tax consequences of events that have been recognized in our financial statements or tax returns. Variations in the actual outcome of these future tax consequences could materially impact our financial position and results of operations.

[0000080420-20-000036:mdna:95]
See Note I of Notes to Consolidated Financial Statements for disclosures related to the valuation allowance recorded in relation to foreign deferred taxes.

[0000080420-20-000036:mdna:96]
Foreign Currency Translation

[0000080420-20-000036:mdna:97]
The functional currency for our foreign operating subsidiaries is the local currency in which the entity is located. The financial statements of all subsidiaries with a functional currency other than the U.S. Dollar have been translated into U.S. Dollars. All assets and liabilities of foreign operations are translated into U.S. Dollars using year-end exchange rates, and all revenues and expenses are translated at average rates during the respective period. The U.S. Dollar results that arise from such translation, as well as exchange gains and losses on intercompany balances of a long-term investment nature, are included in the cumulative currency translation adjustments in accumulated other comprehensive loss in stockholders’ equity.
