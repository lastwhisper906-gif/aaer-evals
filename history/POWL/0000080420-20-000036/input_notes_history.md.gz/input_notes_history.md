# POWL note change history — 0000080420-20-000020 → 0000080420-20-000027


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2020-08-05):
[0000080420-20-000027:note_history:1]
Commitments and Contingencies
Letters of Credit, Surety Bonds and Bank Guarantees
  (was, 2020-05-06, similarity 0.7727):
[0000080420-20-000020:note_history:1]
Letters of Credit, Surety Bonds and Bank Guarantees

- changed (2020-08-05):
[0000080420-20-000027:note_history:2]
Certain customers require us to post letters of credit, bank guarantees or surety bonds. These security instruments assure that we will perform under the terms of our contract. In the event of default, the counterparty may demand payment from the bank under a letter of credit or bank guarantee, or performance by the surety under a bond. To date, there have been no significant draws or claims related to security instruments for the periods reported. We were contingently liable for letters of credit of $33.1 million as of June 30, 2020. We also had surety bonds totaling $162.0 million that were outstanding, with additional bonding capacity of $588.0 million available, at June 30, 2020.
  (was, 2020-05-06, similarity 0.9866):
[0000080420-20-000020:note_history:2]
Certain customers require us to post letters of credit, bank guarantees or surety bonds. These security instruments assure that we will perform under the terms of our contract. In the event of default, the counterparty may demand payment from the bank under a letter of credit or bank guarantee, or performance by the surety under a bond. To date, there have been no significant draws or claims related to security instruments for the periods reported. We were contingently liable for letters of credit of $35.1 million as of March 31, 2020. We also had surety bonds totaling $162.8 million that were outstanding, with additional bonding capacity of $587.2 million available, at March 31, 2020.

- changed (2020-08-05):
[0000080420-20-000027:note_history:3]
We have an $8.6 million facility agreement (Facility Agreement) between Powell (UK) Limited and a large international bank that provides Powell (UK) Limited the ability to enter into bank guarantees as well as forward exchange contracts and currency options. At June 30, 2020, we had outstanding guarantees totaling $7.9 million and amounts available under this Facility Agreement were $0.7 million. The Facility Agreement provides for financial covenants and customary events of default, and carries cross-default provisions with our U.S. Revolver. If an event of default (as defined in the Facility Agreement) occurs and is continuing, per the terms and subject to the conditions set forth therein, obligations outstanding under the Facility Agreement may be accelerated and declared immediately due and payable. As of June 30, 2020, we were in compliance with all of the financial covenants of the Facility Agreement.
  (was, 2020-05-06, similarity 0.9787):
[0000080420-20-000020:note_history:3]
We have an $11.1 million facility agreement (Facility Agreement) between Powell (UK) Limited and a large international bank that provides Powell (UK) Limited the ability to enter into bank guarantees as well as forward exchange contracts and currency options. At March 31, 2020, we had outstanding guarantees totaling $3.1 million and amounts available under this Facility Agreement were $8.0 million. The Facility Agreement expires in May 2020 and provides for financial covenants and customary events of default, and carries cross-default provisions with our U.S. Revolver. If an event of default (as defined in the Facility Agreement) occurs and is continuing, per the terms and subject to the conditions set forth therein, obligations outstanding under the Facility Agreement may be accelerated and declared immediately due and payable. As of March 31, 2020, we were in compliance with all of the financial covenants of the Facility Agreement.

- removed (2020-08-05):
[0000080420-20-000020:note_history:4]
Commitments and Contingencies


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureAndSignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2020-08-05):
[0000080420-20-000027:note_history:5]
Overview and Summary of Significant Accounting Policies
Overview
  (was, 2020-05-06, similarity 0.9244):
[0000080420-20-000020:note_history:5]
Overview and Summary of Significant Accounting Policies

- added (2020-08-05):
[0000080420-20-000027:note_history:6]
Impact of the COVID-19 Pandemic and Oil and Gas Commodity Market Volatility on Powell

- added (2020-08-05):
[0000080420-20-000027:note_history:7]
The spread of COVID-19 has created significant uncertainty and economic disruption across the world during the second half of Fiscal 2020. This pandemic has negatively impacted energy demand, which in turn has resulted in considerable volatility across the oil and gas commodity markets. As a result, some of our industrial customers are deferring or suspending their planned capital expenditures. Certain of our customers have asked that we delay our manufacturing on their projects as their operations have been negatively impacted by this pandemic and the reduced oil and gas demand. We continue to work with and review the contracts with our key suppliers who have been impacted by this pandemic to ensure that we are able to meet our customer commitments.

- added (2020-08-05):
[0000080420-20-000027:note_history:8]
From an operations standpoint, although our facilities are located in areas that have been or continue to be subject to stay-at-home orders, we have not closed any of our facilities for an extended amount of time and have continued to operate as an "essential business" under these orders across all of our locations. We continue to take the necessary steps to ensure the safety of our employees, customers and vendors. These steps include, among others, promoting increased social distancing practices and enhanced cleaning efforts in our offices and facilities. We are also using technology across our operations to further enhance social distancing and improve safety. These increased safety precautions may have an adverse impact on our efficiency and productivity going forward.

- added (2020-08-05):
[0000080420-20-000027:note_history:9]
As a result of the circumstances noted above, we anticipate that a decrease in commercial activity will negatively impact our business, results of operations and cash flows going forward. We have and may need to continue to adjust our workforce and labor costs to correspond to the reduced customer demand. We will take prudent measures to maintain our strong liquidity and cash position, which may include reducing our capital expenditures and research and development costs, as well as reducing or eliminating future dividend payments. However, the extent to which the COVID-19 pandemic specifically will impact our business will depend on numerous factors that are hard to predict, some of which include: the duration, spread and severity of the pandemic; governmental actions in response to the pandemic, including travel restrictions and quarantine or related governmental orders; any closures of our offices and facilities or those of our suppliers as a result of the pandemic, and how quickly and to what extent normal economic and operating conditions can resume. Therefore, the magnitude of the impact on our business, results of operations and cash flows is not currently known.

- added (2020-08-05):
[0000080420-20-000027:note_history:10]
In June 2016, the Financial Accounting Standards Board (FASB) issued a new topic on measurement of credit losses. The topic introduces an impairment model known as the current expected credit loss (CECL) model that is based on an expected loss methodology rather than an incurred loss methodology for financial instruments. Under the new topic, an entity recognizes as an allowance its estimate of expected credit losses with the intention of improving financial reporting by requiring timelier recognition of such losses. Enhanced disclosure of information regarding how a company developed its allowance, including changes in the factors that influenced management's estimate of expected credit losses and the reasons for those changes, will be required upon adoption. The new topic is effective for fiscal years beginning after December 15, 2019, including interim periods within those fiscal years.  This would be our fiscal year ending September 30, 2021. We are still evaluating the impact this new topic will have on our consolidated financial statements.

- removed (2020-08-05):
[0000080420-20-000020:note_history:11]
Overview


## us-gaap:LongTermDebtTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2020-08-05):
[0000080420-20-000027:note_history:12]
Long-Term Debt
Long-term debt consisted of the following (in thousands):
  (was, 2020-05-06, similarity 0.8837):
[0000080420-20-000020:note_history:12]
Long-term debt consisted of the following (in thousands):

- changed (2020-08-05):
[0000080420-20-000027:note_history:13]
|  | June 30, 2020 |  | September 30, 2019 |
| Industrial development revenue bonds | $ | 800 |  |  | $ | 1,200 |  |
| Less: current portion | (400 | ) |  | (400 | ) |
| Total long-term debt | $ | 400 |  |  | $ | 800 |  |
  (was, 2020-05-06, similarity 0.9761):
[0000080420-20-000020:note_history:13]
|  | March 31, 2020 |  | September 30, 2019 |
| Industrial development revenue bonds | $ | 800 |  |  | $ | 1,200 |  |
| Less: current portion | (400 | ) |  | (400 | ) |
| Total long-term debt | $ | 400 |  |  | $ | 800 |  |

- changed (2020-08-05):
[0000080420-20-000027:note_history:14]
On September 27, 2019, we entered into an Amended and Restated Credit Agreement with Bank of America, N.A. (the " "U.S. Revolver"), which replaced our prior credit agreement. The U.S. Revolver is a $75.0 million revolving credit facility that is available for both borrowings and letters of credit and expires September 2024. As of June 30, 2020, there were no amounts borrowed under this facility and letters of credit outstanding were $33.1 million. There was $41.9 million available for the issuance of letters of credit and borrowings under the U.S. Revolver as of June 30, 2020.
  (was, 2020-05-06, similarity 0.9765):
[0000080420-20-000020:note_history:14]
On September 27, 2019, we entered into an Amended and Restated Credit Agreement with Bank of America, N.A. (the " "U.S. Revolver"), which replaced our prior credit agreement. The U.S. Revolver is a $75.0 million revolving credit facility that is available for both borrowings and letters of credit and expires September 2024. As of March 31, 2020, there were no amounts borrowed under this facility and letters of credit outstanding were $35.1 million. There was $39.9 million available for the issuance of letters of credit and borrowings under the U.S. Revolver as of March 31, 2020.

- changed (2020-08-05):
[0000080420-20-000027:note_history:15]
We are required to maintain certain financial covenants, the most significant of which are a consolidated leverage ratio less than 3.0 to 1.0 and a consolidated interest coverage ratio of greater than 3.0 to 1.0. Additionally, we must maintain a consolidated cash balance of $30 million at all times. The U.S. Revolver also contains a "material adverse effect" clause which is a material change in our operations, business, properties, liabilities or condition (financial or otherwise) or a material impairment of our ability to perform our obligations under our credit agreements. As of June 30, 2020, we were in compliance with all of the financial covenants of the U.S. Revolver.
  (was, 2020-05-06, similarity 0.9932):
[0000080420-20-000020:note_history:15]
We are required to maintain certain financial covenants, the most significant of which are a consolidated leverage ratio less than 3.0 to 1.0 and a consolidated interest coverage ratio of greater than 3.0 to 1.0. Additionally, we must maintain a consolidated cash balance of $30 million at all times. The U.S. Revolver also contains a "material adverse effect" clause which is a material change in our operations, business, properties, liabilities or condition (financial or otherwise) or a material impairment of our ability to perform our obligations under our credit agreements. As of March 31, 2020, we were in compliance with all of the financial covenants of the U.S. Revolver.

- changed (2020-08-05):
[0000080420-20-000027:note_history:16]
We borrowed $8.0 million in October 2001 through a loan agreement funded with proceeds from tax-exempt industrial development revenue bonds (Bonds). These Bonds were issued by the Illinois Development Finance Authority and were used for the completion of our Northlake, Illinois facility. Pursuant to the Bond issuance, a reimbursement agreement between us and a major domestic bank required an issuance by the bank of an irrevocable direct-pay letter of credit (Bond LC), as collateral, to the Bonds’ trustee to guarantee payment of the Bonds’ principal and interest when due. The Bond LC is subject to both early termination and extension provisions customary to such agreements, as well as various covenants, for which we were in compliance at June 30, 2020. While the Bonds mature in 2021, the reimbursement agreement requires annual redemptions of $0.4 million that commenced on October 25, 2002. A sinking fund is used for the annual principal payment. The Bonds bear interest at a floating rate determined weekly by the Bonds’ remarketing agent, which was the underwriter for the Bonds and is an affiliate of the bank. This interest rate was 0.36% as of June 30, 2020.
  (was, 2020-05-06, similarity 0.9683):
[0000080420-20-000020:note_history:16]
We borrowed $8.0 million in October 2001 through a loan agreement funded with proceeds from tax-exempt industrial development revenue bonds (Bonds). These Bonds were issued by the Illinois Development Finance Authority and were used for the completion of our Northlake, Illinois facility. Pursuant to the Bond issuance, a reimbursement agreement between us and a major domestic bank required an issuance by the bank of an irrevocable direct-pay letter of credit (Bond LC), as collateral, to the Bonds’ trustee to guarantee payment of the Bonds’ principal and interest when due. The Bond LC is subject to both early termination and extension provisions customary to such agreements, as well as various covenants, for which we were in compliance at March 31, 2020. While the Bonds mature in 2021, the reimbursement agreement requires annual redemptions of $0.4 million that commenced on October 25, 2002. A sinking fund is used for the annual principal payment. The Bonds bear interest at a floating rate determined weekly by the Bonds’ remarketing agent, which was the underwriter for the Bonds and is an affiliate of the bank. This interest rate was 5.08% as of March 31, 2020 and subsequently declined to 0.57% as of April 30, 2020.

- removed (2020-08-05):
[0000080420-20-000020:note_history:17]
Long-Term Debt


## us-gaap:ScheduleOfDebtInstrumentsTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2020-08-05):
[0000080420-20-000027:note_history:18]
|  | June 30, 2020 |  | September 30, 2019 |
| Industrial development revenue bonds | $ | 800 |  |  | $ | 1,200 |  |
| Less: current portion | (400 | ) |  | (400 | ) |
| Total long-term debt | $ | 400 |  |  | $ | 800 |  |
  (was, 2020-05-06, similarity 0.9761):
[0000080420-20-000020:note_history:18]
|  | March 31, 2020 |  | September 30, 2019 |
| Industrial development revenue bonds | $ | 800 |  |  | $ | 1,200 |  |
| Less: current portion | (400 | ) |  | (400 | ) |
| Total long-term debt | $ | 400 |  |  | $ | 800 |  |


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2020-08-05):
[0000080420-20-000027:note_history:19]
The following tables present our disaggregated revenue by geographic destination and market sector for the three and nine months ended June 30, 2020 and 2019 (in thousands):
  (was, 2020-05-06, similarity 0.925):
[0000080420-20-000020:note_history:19]
The following tables present our disaggregated revenue by geographic destination and market sector for the six months ended March 31, 2020 and 2019 (in thousands):

- changed (2020-08-05):
[0000080420-20-000027:note_history:20]
|  | Three months ended June 30, |  | Nine months ended June 30, |
|  | 2020 |  | 2019 |  | 2020 |  | 2019 |
| United States | $ | 89,499 |  |  | $ | 99,745 |  |  | $ | 318,009 |  |  | $ | 292,049 |  |
| Canada | 16,970 |  |  | 20,206 |  |  | 46,831 |  |  | 45,015 |  |
| Europe, Middle East and Africa | 6,422 |  |  | 9,659 |  |  | 25,404 |  |  | 20,608 |  |
| Asia/Pacific | 4,643 |  |  | 4,682 |  |  | 11,784 |  |  | 9,155 |  |
| Mexico, Central and South America | 528 |  |  | 1,296 |  |  | 1,753 |  |  | 1,849 |  |
| Total revenues by geographic destination | $ | 118,062 |  |  | $ | 135,588 |  |  | $ | 403,781 |  |  | $ | 368,676 |  |
  (was, 2020-05-06, similarity 0.9254):
[0000080420-20-000020:note_history:20]
|  | Three months ended March 31, |  | Six months ended March 31, |
|  | 2020 |  | 2019 |  | 2020 |  | 2019 |
| United States | $ | 121,432 |  |  | $ | 102,406 |  |  | $ | 228,510 |  |  | $ | 192,304 |  |
| Canada | 15,407 |  |  | 15,094 |  |  | 29,861 |  |  | 24,809 |  |
| Europe, Middle East and Africa | 8,816 |  |  | 5,508 |  |  | 18,982 |  |  | 10,949 |  |
| Asia/Pacific | 5,456 |  |  | 729 |  |  | 7,142 |  |  | 4,473 |  |
| Mexico, Central and South America | 459 |  |  | — |  |  | 1,225 |  |  | 553 |  |
| Total revenues by geographic destination | $ | 151,570 |  |  | $ | 123,737 |  |  | $ | 285,720 |  |  | $ | 233,088 |  |

- changed (2020-08-05):
[0000080420-20-000027:note_history:21]
|  | Three months ended June 30, |  | Nine months ended June 30, |
|  | 2020 |  | 2019 |  | 2020 |  | 2019 |
| Oil and gas | $ | 45,851 |  |  | $ | 62,356 |  |  | $ | 157,798 |  |  | $ | 167,954 |  |
| Petrochemical | 29,293 |  |  | 21,086 |  |  | 107,057 |  |  | 63,387 |  |
| Electric utility | 16,725 |  |  | 26,425 |  |  | 63,994 |  |  | 66,066 |  |
| Traction power | 9,122 |  |  | 7,423 |  |  | 31,417 |  |  | 18,457 |  |
| All others | 17,071 |  |  | 18,298 |  |  | 43,515 |  |  | 52,812 |  |
| Total revenues by market sector | $ | 118,062 |  |  | $ | 135,588 |  |  | $ | 403,781 |  |  | $ | 368,676 |  |
  (was, 2020-05-06, similarity 0.954):
[0000080420-20-000020:note_history:21]
|  | Three months ended March 31, |  | Six months ended March 31, |
|  | 2020 |  | 2019 |  | 2020 |  | 2019 |
| Oil and gas | $ | 51,954 |  |  | $ | 56,022 |  |  | $ | 111,948 |  |  | $ | 105,598 |  |
| Petrochemical | 47,337 |  |  | 22,523 |  |  | 77,763 |  |  | 42,301 |  |
| Electric utility | 24,255 |  |  | 20,383 |  |  | 47,270 |  |  | 39,641 |  |
| Traction power | 13,944 |  |  | 6,025 |  |  | 22,295 |  |  | 11,034 |  |
| All others | 14,080 |  |  | 18,784 |  |  | 26,444 |  |  | 34,514 |  |
| Total revenues by market sector | $ | 151,570 |  |  | $ | 123,737 |  |  | $ | 285,720 |  |  | $ | 233,088 |  |


## us-gaap:RevenueFromContractWithCustomerPolicyTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2020-08-05):
[0000080420-20-000027:note_history:22]
Contract liabilities typically represent advance payments from contractual billing milestones and billings in excess of revenue recognized. It is unusual to have advanced milestone payments with a term greater than one year, which could represent a financing component on the contract.  
Our contract assets and liabilities are reported in a net position on a contract-by-contract basis at the end of each reporting period and are generally classified as current.
Performance Obligations
  (was, 2020-05-06, similarity 0.7403):
[0000080420-20-000020:note_history:22]
Contract liabilities typically represent advance payments from contractual billing milestones and billings in excess of revenue recognized. It is unusual to have advanced milestone payments with a term greater than one year, which could represent a financing component on the contract.

- changed (2020-08-05):
[0000080420-20-000027:note_history:23]
A performance obligation is a promise in a contract or with a customer to transfer a distinct good or service. A contract’s transaction price is allocated to each distinct performance obligation and recognized as revenue as the performance obligations are satisfied. To determine the proper revenue recognition for contracts, we evaluate whether a contract should be accounted for as more than one performance obligation or, less commonly, whether two or more contracts should be combined and accounted for as one performance obligation.  This evaluation of performance obligations requires significant judgment.  The majority of our contracts have a single performance obligation where multiple engineered products and services are combined into a single custom-engineered solution. Our contracts generally include a standard assurance warranty that typically ends 18 months after shipment. Occasionally, we provide service-type warranties that will extend the warranty period. These extended warranties qualify as a separate performance obligation, and revenue is deferred and recognized over the warranty period. If we determine during the evaluation of the contract that there are multiple performance obligations, we allocate the transaction price to each performance obligation using our best estimate of the standalone selling price of each distinct good or service in the contract. 
Remaining unsatisfied performance obligations, which we refer to as backlog, represent the estimated transaction price for goods and services for which we have a material right but work has not been performed.The timing of our invoice process is typically dependent on the completion of certain milestones and contract terms and subject to agreement by our customer.  Payment is typically expected within 30 days of invoice. Any uncollected invoiced amounts for our performance obligations recognized over time, including contract retentions, are recorded as accounts receivable in the Condensed Consolidated Balance Sheets. Certain contracts contain retention provisions that become due upon completion of contractual requirements.
Revenue Recognition
  (was, 2020-05-06, similarity 0.7868):
[0000080420-20-000020:note_history:23]
A performance obligation is a promise in a contract or with a customer to transfer a distinct good or service. A contract’s transaction price is allocated to each distinct performance obligation and recognized as revenue as the performance obligations are satisfied. To determine the proper revenue recognition for contracts, we evaluate whether a contract should be accounted for as more than one performance obligation or, less commonly, whether two or more contracts should be combined and accounted for as one performance obligation.  This evaluation of performance obligations requires significant judgment.  The majority of our contracts have a single performance obligation where multiple engineered products and services are combined into a single custom-engineered solution. Our contracts generally include a standard assurance warranty that typically ends 18 months after shipment. Occasionally, we provide service-type warranties that will extend the warranty period. These extended warranties qualify as a separate performance obligation, and revenue is deferred and recognized over the warranty period. If we determine during the evaluation of the contract that there are multiple performance obligations, we allocate the transaction price to each performance obligation using our best estimate of the standalone selling price of each distinct good or service in the contract.

- changed (2020-08-05):
[0000080420-20-000027:note_history:24]
We also have contracts to provide value-added services such as field service inspection, installation, commissioning, modification and repair, as well as retrofit and retrofill components for existing systems.  As a practical expedient, if the service contract terms give us the right to invoice the customer for an amount that corresponds directly with the value of our performance completed to date (i.e., a service contract in which we bill a fixed amount for each hour of service provided), then we recognize revenue over
  (was, 2020-05-06, similarity 0.7072):
[0000080420-20-000020:note_history:24]
We also have contracts to provide value-added services such as field service inspection, installation, commissioning, modification and repair, as well as retrofit and retrofill components for existing systems.  As a practical expedient, if the service contract terms give us the right to invoice the customer for an amount that corresponds directly with the value of our performance completed to date (i.e., a service contract in which we bill a fixed amount for each hour of service provided), then we recognize revenue over time in each reporting period corresponding to the amount with which we have the right to invoice.  Our performance obligations are satisfied as the work progresses. Revenues from our custom-engineered products and value-added services transferred to customers over time accounted for approximately 96% of total revenues for the three and six months ended March 31, 2020 and 93% of total revenues for the three and six months ended March 31, 2019.

- added (2020-08-05):
[0000080420-20-000027:note_history:25]
time in each reporting period corresponding to the amount with which we have the right to invoice.  Our performance obligations are satisfied as the work progresses. Revenues from our custom-engineered products and value-added services transferred to customers over time accounted for approximately 95% of total revenues for the three and nine months ended June 30, 2020 and 93% of total revenues for the three and nine months ended June 30, 2019.

- changed (2020-08-05):
[0000080420-20-000027:note_history:26]
We also have sales orders for spare parts and replacement circuit breakers for switchgear that are obsolete or that are no longer produced by the original manufacturer. Revenues from these sales orders are recognized at the time we fulfill our performance obligation to the customer, which is typically upon shipment and represented approximately 5% of total revenues for the three and nine months ended June 30, 2020 and 7% of total revenues for the three and nine months ended June 30, 2019.
  (was, 2020-05-06, similarity 0.9004):
[0000080420-20-000020:note_history:26]
We also have sales orders for spare parts and replacement circuit breakers for switchgear that are obsolete or that are no longer produced by the original manufacturer. Revenues from these sales orders are recognized at the time we fulfill our performance obligation to the customer, which is typically upon shipment and represented approximately 4% of total revenues for the three and six months ended March 31, 2020 and 7% of total revenues for the three and six months ended March 31, 2019.

- added (2020-08-05):
[0000080420-20-000027:note_history:27]
Additionally, some contracts may contain a cancellation clause that could limit the amount of revenue we are able to recognize over time. In these instances, revenue and costs associated with these contracts are deferred and recognized at a point in time when the performance obligation is fulfilled.
Selling and administrative costs incurred in relation to obtaining a contract are typically expensed as incurred. We periodically utilize a third-party sales agent to obtain a contract and will pay a commission to that agent. We record the full commission liability to the third-party sales agents at the order date, with a corresponding deferred asset. As the project progresses, we record commission expense based on percentage of completion rates that correlate to the project and reduce the deferred asset. Once we have been paid by the customer, we pay the commission and the deferred liability is reduced
Contract Estimates

- removed (2020-08-05):
[0000080420-20-000020:note_history:28]
Contract Estimates

- removed (2020-08-05):
[0000080420-20-000020:note_history:29]
Revenue Recognition

- removed (2020-08-05):
[0000080420-20-000020:note_history:30]
Additionally, some contracts may contain a cancellation clause that could limit the amount of revenue we are able to recognize over time. In these instances, revenue and costs associated with these contracts are deferred and recognized at a point in time when the performance obligation is fulfilled.

- removed (2020-08-05):
[0000080420-20-000020:note_history:31]
Selling and administrative costs incurred in relation to obtaining a contract are typically expensed as incurred. We periodically utilize a third-party sales agent to obtain a contract and will pay a commission to that agent. We record the full commission liability to the third-party sales agents at the order date, with a corresponding deferred asset. As the project progresses, we record commission expense based on percentage of completion rates that correlate to the project and reduce the deferred asset. Once we have been paid by the customer, we pay the commission and the deferred liability is reduced

- removed (2020-08-05):
[0000080420-20-000020:note_history:32]
Performance Obligations

- removed (2020-08-05):
[0000080420-20-000020:note_history:33]
Remaining unsatisfied performance obligations, which we refer to as backlog, represent the estimated transaction price for goods and services for which we have a material right but work has not been performed.

- removed (2020-08-05):
[0000080420-20-000020:note_history:34]
The timing of our invoice process is typically dependent on the completion of certain milestones and contract terms and subject to agreement by our customer.  Payment is typically expected within 30 days of invoice. Any uncollected invoiced amounts for our performance obligations recognized over time, including contract retentions, are recorded as accounts receivable in the Condensed Consolidated Balance Sheets. Certain contracts contain retention provisions that become due upon completion of contractual requirements.

- removed (2020-08-05):
[0000080420-20-000020:note_history:35]
Our contract assets and liabilities are reported in a net position on a contract-by-contract basis at the end of each reporting period and are generally classified as current.


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2020-08-05):
[0000080420-20-000027:note_history:36]
Revenue
Revenue Recognition
  (was, 2020-05-06, similarity 0.8261):
[0000080420-20-000020:note_history:36]
Revenue Recognition

- changed (2020-08-05):
[0000080420-20-000027:note_history:37]
We also have contracts to provide value-added services such as field service inspection, installation, commissioning, modification and repair, as well as retrofit and retrofill components for existing systems.  As a practical expedient, if the service contract terms give us the right to invoice the customer for an amount that corresponds directly with the value of our performance completed to date (i.e., a service contract in which we bill a fixed amount for each hour of service provided), then we recognize revenue over
  (was, 2020-05-06, similarity 0.7072):
[0000080420-20-000020:note_history:37]
We also have contracts to provide value-added services such as field service inspection, installation, commissioning, modification and repair, as well as retrofit and retrofill components for existing systems.  As a practical expedient, if the service contract terms give us the right to invoice the customer for an amount that corresponds directly with the value of our performance completed to date (i.e., a service contract in which we bill a fixed amount for each hour of service provided), then we recognize revenue over time in each reporting period corresponding to the amount with which we have the right to invoice.  Our performance obligations are satisfied as the work progresses. Revenues from our custom-engineered products and value-added services transferred to customers over time accounted for approximately 96% of total revenues for the three and six months ended March 31, 2020 and 93% of total revenues for the three and six months ended March 31, 2019.

- added (2020-08-05):
[0000080420-20-000027:note_history:38]
time in each reporting period corresponding to the amount with which we have the right to invoice.  Our performance obligations are satisfied as the work progresses. Revenues from our custom-engineered products and value-added services transferred to customers over time accounted for approximately 95% of total revenues for the three and nine months ended June 30, 2020 and 93% of total revenues for the three and nine months ended June 30, 2019.

- changed (2020-08-05):
[0000080420-20-000027:note_history:39]
We also have sales orders for spare parts and replacement circuit breakers for switchgear that are obsolete or that are no longer produced by the original manufacturer. Revenues from these sales orders are recognized at the time we fulfill our performance obligation to the customer, which is typically upon shipment and represented approximately 5% of total revenues for the three and nine months ended June 30, 2020 and 7% of total revenues for the three and nine months ended June 30, 2019.
  (was, 2020-05-06, similarity 0.9004):
[0000080420-20-000020:note_history:39]
We also have sales orders for spare parts and replacement circuit breakers for switchgear that are obsolete or that are no longer produced by the original manufacturer. Revenues from these sales orders are recognized at the time we fulfill our performance obligation to the customer, which is typically upon shipment and represented approximately 4% of total revenues for the three and six months ended March 31, 2020 and 7% of total revenues for the three and six months ended March 31, 2019.

- changed (2020-08-05):
[0000080420-20-000027:note_history:40]
Remaining unsatisfied performance obligations, which we refer to as backlog, represent the estimated transaction price for goods and services for which we have a material right but work has not been performed. As of June 30, 2020, we had backlog of $532.2 million, of which approximately $342.4 million is expected to be recognized as revenue within the next twelve months. Backlog may not be indicative of future operating results as orders may be cancelled or modified by our customers. Our backlog does not include service and maintenance-type contracts for which we have the right to invoice as services are performed.
  (was, 2020-05-06, similarity 0.9926):
[0000080420-20-000020:note_history:40]
Remaining unsatisfied performance obligations, which we refer to as backlog, represent the estimated transaction price for goods and services for which we have a material right but work has not been performed. As of March 31, 2020, we had backlog of $566.4 million, of which approximately $342.9 million is expected to be recognized as revenue within the next twelve months. Backlog may not be indicative of future operating results as orders may be cancelled or modified by our customers. Our backlog does not include service and maintenance-type contracts for which we have the right to invoice as services are performed.

- changed (2020-08-05):
[0000080420-20-000027:note_history:41]
For the nine months ended June 30, 2020 and 2019, our operating results were positively impacted by $10.8 million and $4.3 million, respectively, as a result of changes in contract estimates related to projects in progress at the beginning of the respective period. These changes in estimates spread across the entire portfolio with no significant changes in a single contract and resulted primarily from favorable project execution and negotiations of variable consideration, discussed below, as well as other changes in facts and circumstances during these periods.
  (was, 2020-05-06, similarity 0.8703):
[0000080420-20-000020:note_history:41]
For the six months ended March 31, 2020 and 2019, our operating results were positively impacted by $9.0 million and $4.3 million, respectively, as a result of changes in contract estimates related to projects in progress at the beginning of the respective period. These changes in estimates resulted primarily from favorable project execution and negotiations of variable consideration, discussed below, as well as other changes in facts and circumstances during these periods.

- changed (2020-08-05):
[0000080420-20-000027:note_history:42]
Contract assets and liabilities as of June 30, 2020 and September 30, 2019 are summarized below (in thousands):
  (was, 2020-05-06, similarity 0.9557):
[0000080420-20-000020:note_history:42]
Contract assets and liabilities as of March 31, 2020 and September 30, 2019 are summarized below (in thousands):

- changed (2020-08-05):
[0000080420-20-000027:note_history:43]
|  | June 30, 2020 |  | September 30, 2019 |
| Contract assets | $ | 51,723 |  |  | $ | 55,374 |  |
| Contract liabilities | (97,969 | ) |  | (71,464 | ) |
| Net contract liability | $ | (46,246 | ) |  | $ | (16,090 | ) |
  (was, 2020-05-06, similarity 0.9435):
[0000080420-20-000020:note_history:43]
|  | March 31, 2020 |  | September 30, 2019 |
| Contract assets | $ | 61,336 |  |  | $ | 55,374 |  |
| Contract liabilities | (57,821 | ) |  | (71,464 | ) |
| Net contract asset (liability) | $ | 3,515 |  |  | $ | (16,090 | ) |

- added (2020-08-05):
[0000080420-20-000027:note_history:44]
The increase in net contract liability at June 30, 2020 from September 30, 2019 was primarily due to our progress towards completion on our projects and the timing of contract billing milestones and new orders. This increase was primarily driven by the timing of contract billing milestones related to our recent contract award for a large industrial project in the United States. To determine the amount of revenue recognized during the period from contract liabilities, we first allocate revenue to the individual contract liability balance outstanding at the beginning of the period until the revenue exceeds that balance. During the three and nine months ended June 30, 2020, we recognized revenue of approximately $34.6 million and $67.1 million related to contract liabilities outstanding at September 30, 2019.

- changed (2020-08-05):
[0000080420-20-000027:note_history:45]
The timing of our invoice process is typically dependent on the completion of certain milestones and contract terms and subject to agreement by our customer.  Payment is typically expected within 30 days of invoice. Any uncollected invoiced amounts for our performance obligations recognized over time, including contract retentions, are recorded as accounts receivable in the Condensed Consolidated Balance Sheets. Certain contracts contain retention provisions that become due upon completion of contractual requirements. As of June 30, 2020 and September 30, 2019, accounts receivable included retention amounts of $6.7 million and $5.6 million, respectively. Of the retained amount at June 30, 2020, $5.6 million is expected to be collected in the next twelve months and is recorded in accounts receivable. The remaining $1.1 million is recorded in other assets.
  (was, 2020-05-06, similarity 0.9893):
[0000080420-20-000020:note_history:45]
The timing of our invoice process is typically dependent on the completion of certain milestones and contract terms and subject to agreement by our customer.  Payment is typically expected within 30 days of invoice. Any uncollected invoiced amounts for our performance obligations recognized over time, including contract retentions, are recorded as accounts receivable in the Condensed Consolidated Balance Sheets. Certain contracts contain retention provisions that become due upon completion of contractual requirements. As of March 31, 2020 and September 30, 2019, accounts receivable included retention amounts of $6.0 million and $5.6 million, respectively. Of the retained amount at March 31, 2020, $3.7 million is expected to be collected in the next twelve months and is recorded in accounts receivable. The remaining $2.3 million is recorded in other assets.

- changed (2020-08-05):
[0000080420-20-000027:note_history:46]
The following tables present our disaggregated revenue by geographic destination and market sector for the three and nine months ended June 30, 2020 and 2019 (in thousands):
  (was, 2020-05-06, similarity 0.925):
[0000080420-20-000020:note_history:46]
The following tables present our disaggregated revenue by geographic destination and market sector for the six months ended March 31, 2020 and 2019 (in thousands):

- changed (2020-08-05):
[0000080420-20-000027:note_history:47]
|  | Three months ended June 30, |  | Nine months ended June 30, |
|  | 2020 |  | 2019 |  | 2020 |  | 2019 |
| United States | $ | 89,499 |  |  | $ | 99,745 |  |  | $ | 318,009 |  |  | $ | 292,049 |  |
| Canada | 16,970 |  |  | 20,206 |  |  | 46,831 |  |  | 45,015 |  |
| Europe, Middle East and Africa | 6,422 |  |  | 9,659 |  |  | 25,404 |  |  | 20,608 |  |
| Asia/Pacific | 4,643 |  |  | 4,682 |  |  | 11,784 |  |  | 9,155 |  |
| Mexico, Central and South America | 528 |  |  | 1,296 |  |  | 1,753 |  |  | 1,849 |  |
| Total revenues by geographic destination | $ | 118,062 |  |  | $ | 135,588 |  |  | $ | 403,781 |  |  | $ | 368,676 |  |
  (was, 2020-05-06, similarity 0.9254):
[0000080420-20-000020:note_history:47]
|  | Three months ended March 31, |  | Six months ended March 31, |
|  | 2020 |  | 2019 |  | 2020 |  | 2019 |
| United States | $ | 121,432 |  |  | $ | 102,406 |  |  | $ | 228,510 |  |  | $ | 192,304 |  |
| Canada | 15,407 |  |  | 15,094 |  |  | 29,861 |  |  | 24,809 |  |
| Europe, Middle East and Africa | 8,816 |  |  | 5,508 |  |  | 18,982 |  |  | 10,949 |  |
| Asia/Pacific | 5,456 |  |  | 729 |  |  | 7,142 |  |  | 4,473 |  |
| Mexico, Central and South America | 459 |  |  | — |  |  | 1,225 |  |  | 553 |  |
| Total revenues by geographic destination | $ | 151,570 |  |  | $ | 123,737 |  |  | $ | 285,720 |  |  | $ | 233,088 |  |

- changed (2020-08-05):
[0000080420-20-000027:note_history:48]
|  | Three months ended June 30, |  | Nine months ended June 30, |
|  | 2020 |  | 2019 |  | 2020 |  | 2019 |
| Oil and gas | $ | 45,851 |  |  | $ | 62,356 |  |  | $ | 157,798 |  |  | $ | 167,954 |  |
| Petrochemical | 29,293 |  |  | 21,086 |  |  | 107,057 |  |  | 63,387 |  |
| Electric utility | 16,725 |  |  | 26,425 |  |  | 63,994 |  |  | 66,066 |  |
| Traction power | 9,122 |  |  | 7,423 |  |  | 31,417 |  |  | 18,457 |  |
| All others | 17,071 |  |  | 18,298 |  |  | 43,515 |  |  | 52,812 |  |
| Total revenues by market sector | $ | 118,062 |  |  | $ | 135,588 |  |  | $ | 403,781 |  |  | $ | 368,676 |  |
  (was, 2020-05-06, similarity 0.954):
[0000080420-20-000020:note_history:48]
|  | Three months ended March 31, |  | Six months ended March 31, |
|  | 2020 |  | 2019 |  | 2020 |  | 2019 |
| Oil and gas | $ | 51,954 |  |  | $ | 56,022 |  |  | $ | 111,948 |  |  | $ | 105,598 |  |
| Petrochemical | 47,337 |  |  | 22,523 |  |  | 77,763 |  |  | 42,301 |  |
| Electric utility | 24,255 |  |  | 20,383 |  |  | 47,270 |  |  | 39,641 |  |
| Traction power | 13,944 |  |  | 6,025 |  |  | 22,295 |  |  | 11,034 |  |
| All others | 14,080 |  |  | 18,784 |  |  | 26,444 |  |  | 34,514 |  |
| Total revenues by market sector | $ | 151,570 |  |  | $ | 123,737 |  |  | $ | 285,720 |  |  | $ | 233,088 |  |

- removed (2020-08-05):
[0000080420-20-000020:note_history:49]
Revenue

- removed (2020-08-05):
[0000080420-20-000020:note_history:50]
The increase in net contract asset at March 31, 2020 from September 30, 2019 was primarily due to our progress towards completion on our projects and the timing of contract billing milestones and new orders. To determine the amount of revenue recognized during the period from contract liabilities, we first allocate revenue to the individual contract liability balance outstanding at the beginning of the period until the revenue exceeds that balance. During the three and six months ended March 31, 2020, we recognized revenue of approximately $50.8 million and $65.0 million related to contract liabilities outstanding at September 30, 2019.


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: tag_name, score: 1.0

- changed (2020-08-05):
[0000080420-20-000027:note_history:51]
Subsequent Events
Quarterly Dividend Declared
  (was, 2020-05-06, similarity 0.75):
[0000080420-20-000020:note_history:51]
Quarterly Dividend Declared

- changed (2020-08-05):
[0000080420-20-000027:note_history:52]
On August 4, 2020, our Board of Directors declared a quarterly cash dividend on our common stock in the amount of $0.26 per share. The dividend is payable on September 16, 2020 to shareholders of record at the close of business on August 19, 2020.
  (was, 2020-05-06, similarity 0.6517):
[0000080420-20-000020:note_history:52]
On May 5, 2020, our Board of Directors declared a quarterly cash dividend on our common stock in the amount of $0.26 per share. The dividend is payable on June 17, 2020 to shareholders of record at the close of business on May 20, 2020.

- removed (2020-08-05):
[0000080420-20-000020:note_history:53]
Subsequent Events

- removed (2020-08-05):
[0000080420-20-000020:note_history:54]
Impact of the COVID-19 Pandemic and Oil Price Volatility on Powell

- removed (2020-08-05):
[0000080420-20-000020:note_history:55]
The global spread of COVID-19 has created significant volatility, uncertainty and economic disruption across the globe during Fiscal 2020. In addition, there have recently been significant reductions in oil and gas demand and steep declines in oil prices.  Certain of our customers have asked that we delay our manufacturing on their projects as their operations have been negatively impacted by this pandemic and the reduced oil and gas demand and steep declines in oil prices. We continue to monitor and work with our suppliers who have been impacted by this pandemic to ensure we are able to meet our customer commitments. We also have reviewed and will continue to review our contracts with our suppliers, and we may need to make adjustments accordingly. From an operations standpoint, although our facilities are located in areas that have been or continue to be subject to stay-at-home orders, we have not closed any of our facilities for an extended amount of time and have continued to operate as an "essential business" under these orders across all of our locations. We continue to take the necessary steps to promote social distancing and enhanced cleaning efforts in our offices and facilities in an effort to keep our employees, customers and vendors safe. We are also exploring the use of technology across our operations to further enhance social distancing and improve safety. These safety precautions may have an adverse impact on our efficiency and productivity going forward.

- removed (2020-08-05):
[0000080420-20-000020:note_history:56]
As a result of the circumstances noted above, we anticipate a decrease in commercial activity which will negatively impact our business, results of operations and cash flows going forward. We have and may need to continue to adjust our workforce and labor costs to correspond to the reduced customer demand. We will take prudent measures to maintain our strong liquidity and cash position, which may include reducing our capital expenditures and research and development costs, as well as reducing or eliminating future dividend payments. However, the extent to which the COVID-19 pandemic specifically will impact our business will depend on numerous factors that are hard to predict, some of which include: the duration, spread and severity of the pandemic; governmental actions in response to the pandemic, including travel restrictions and quarantine or related orders; any closures of our offices and facilities or those of our suppliers as a result of the pandemic, and how quickly and to what extent normal economic and operating conditions can resume. Therefore, the magnitude of the impact on our business, results of operations and cash flows is not currently known.

- removed (2020-08-05):
[0000080420-20-000020:note_history:57]
Due to the circumstances noted above, we made a reduction in our workforce across the business in early May which will result in severance and restructuring costs of less than $1 million. We may have to make additional adjustments to our workforce and labor costs in response to further changes to customer demand.
