# POWL 8-K — 0000080420-20-000032 filed 2020-12-08

## item codes, every 8-K on or before 2020-12-09

- 2020-12-08 0000080420-20-000032 — 2.02, 9.01
- 2020-11-12 0000080420-20-000030 — 8.01, 9.01
- 2020-08-04 0000080420-20-000024 — 2.02, 8.01, 9.01
- 2020-05-05 0000080420-20-000017 — 2.02, 8.01, 9.01
- 2020-02-21 0000080420-20-000008 — 5.07
- 2020-02-04 0000080420-20-000003 — 2.02, 8.01, 9.01
- 2019-12-04 0001193125-19-306243 — 2.02, 9.01
- 2019-11-08 0000080420-19-000032 — 8.01, 9.01
- 2019-10-03 0000080420-19-000030 — 1.01, 2.03
- 2019-09-24 0000080420-19-000028 — 8.01, 9.01
- 2019-08-06 0000080420-19-000022 — 2.02, 8.01, 9.01
- 2019-05-08 0000080420-19-000017 — 5.02, 9.01
- 2019-05-07 0000080420-19-000011 — 2.02, 8.01, 9.01
- 2019-02-22 0001193125-19-048366 — 5.07
- 2019-02-05 0000080420-19-000003 — 2.02, 8.01
- 2018-12-21 0000080420-18-000038 — 5.02, 9.01
- 2018-12-12 0000080420-18-000031 — 2.02
- 2018-11-05 0000080420-18-000029 — 8.01, 9.01
- 2018-11-01 0000080420-18-000027 — 5.02, 8.01, 9.01
- 2018-10-01 0000080420-18-000024 — 5.02
- 2018-08-07 0000080420-18-000020 — 2.02, 8.01
- 2018-05-15 0000080420-18-000016 — 5.02, 8.01
- 2018-05-09 0000080420-18-000011 — 2.02, 8.01
- 2018-02-22 0000080420-18-000009 — 5.07
- 2018-02-06 0000080420-18-000003 — 2.02, 8.01
- 2017-12-27 0001193125-17-379928 — 5.02
- 2017-12-05 0000080420-17-000028 — 2.02, 9.01
- 2017-11-08 0000080420-17-000024 — 8.01, 9.01
- 2017-11-03 0000080420-17-000022 — 5.02
- 2017-08-09 0000080420-17-000017 — 2.02, 8.01
- 2017-06-30 0000080420-17-000014 — 1.01, 9.01
- 2017-05-03 0000080420-17-000006 — 2.02, 8.01, 9.01
- 2017-02-23 0000080420-17-000004 — 5.07
- 2017-02-08 0001628280-17-000965 — 2.02 — amendment of 0001628280-17-000949
- 2017-02-07 0001628280-17-000949 — 2.01, 8.01, 9.01
- 2016-12-07 0001193125-16-787354 — 2.02, 9.01
- 2016-11-01 0001193125-16-755475 — 8.01, 9.01
- 2016-09-30 0001193125-16-726999 — 5.02, 8.01, 9.01
- 2016-08-03 0001193125-16-669308 — 2.02, 8.01, 9.01
- 2016-05-04 0001193125-16-576528 — 2.02, 8.01, 9.01
- 2016-02-25 0001193125-16-477896 — 5.07
- 2016-02-03 0001193125-16-449052 — 2.02, 8.01, 9.01
- 2015-12-31 0001193125-15-418363 — 5.02, 7.01, 9.01
- 2015-12-02 0001193125-15-393109 — 2.02, 9.01
- 2015-11-05 0001193125-15-368085 — 8.01, 9.01
- 2015-09-25 0001193125-15-329031 — 5.02
- 2015-08-05 0001193125-15-277912 — 2.02, 8.01, 9.01
- 2015-05-06 0001193125-15-174291 — 2.02, 8.01, 9.01
- 2015-03-06 0001193125-15-081070 — 5.02
- 2015-03-02 0001193125-15-072946 — 5.07
- 2015-02-03 0001193125-15-031772 — 2.02, 8.01, 9.01
- 2014-12-18 0001193125-14-446513 — 8.01, 9.01
- 2014-12-03 0001193125-14-431745 — 2.02, 9.01
- 2014-11-05 0001193125-14-397955 — 8.01, 9.01
- 2014-09-26 0001193125-14-353741 — 7.01, 9.01
- 2014-08-05 0001193125-14-296001 — 2.02, 8.01, 9.01
- 2014-05-07 0001193125-14-187496 — 2.02, 8.01, 9.01
- 2014-03-03 0001193125-14-079843 — 5.02, 5.07
- 2014-02-05 0001193125-14-036633 — 2.02, 8.01, 9.01
- 2014-01-17 0001193125-14-014351 — 1.01, 8.01, 9.01
- 2014-01-06 0001193125-14-002795 — 1.01, 2.03
- 2013-12-06 0001564590-13-001411 — 2.02, 9.01
- 2013-12-05 0001564590-13-001406 — 5.02, 8.01, 9.01
- 2013-11-07 0001193125-13-432950 — 8.01, 9.01
- 2013-08-07 0001193125-13-324337 — 2.02, 9.01
- 2013-05-08 0001193125-13-206800 — 2.02, 9.01
- 2013-02-22 0001193125-13-070971 — 5.02, 5.07
- 2013-02-06 0001193125-13-040556 — 2.02, 9.01
- 2012-12-18 0001193125-12-506417 — 5.02, 9.01
- 2012-12-05 0001193125-12-491749 — 2.02, 9.01
- 2012-10-12 0001193125-12-421889 — 3.03, 5.02, 5.03, 9.01
- 2012-08-09 0001193125-12-344617 — 5.02, 8.01, 9.01
- 2012-08-08 0001193125-12-343630 — 2.02, 9.01
- 2012-05-09 0001193125-12-221356 — 2.02, 9.01
- 2012-02-08 0001193125-12-046560 — 2.02, 9.01
- 2011-12-08 0001193125-11-334810 — 2.02, 9.01
- 2011-11-08 0000950123-11-096524 — 2.02, 2.06, 4.02, 9.01
- 2011-10-14 0000950123-11-090124 — 5.02
- 2011-10-06 0000950123-11-088969 — 5.02
- 2011-09-19 0000950123-11-085224 — 5.02, 9.01
- 2011-09-15 0000950123-11-084806 — 5.02, 9.01
- 2011-08-04 0000950123-11-072788 — 2.02, 9.01
- 2011-07-22 0000950123-11-067402 — 5.07
- 2011-05-24 0000950123-11-053550 — 1.01, 2.03, 9.01
- 2011-05-04 0000950123-11-044561 — 2.02, 9.01
- 2011-02-02 0000950123-11-008188 — 2.02, 9.01
- 2010-12-08 0000950123-10-111987 — 2.02, 9.01
- 2010-08-05 0000950123-10-073114 — 2.02, 9.01
- 2010-05-18 0000950123-10-050900 — 5.02
- 2010-05-05 0000950123-10-044499 — 2.02, 9.01
- 2010-02-03 0000950123-10-008278 — 2.02, 9.01
- 2009-12-21 0000950123-09-072269 — 1.01, 2.01, 2.03, 8.01, 9.01
- 2009-12-09 0000950123-09-069525 — 2.02, 9.01
- 2009-10-27 0000950123-09-053501 — 1.01, 8.01, 9.01
- 2009-08-04 0000950123-09-029476 — 2.02, 9.01
- 2009-05-06 0000950129-09-001498 — 2.02, 9.01
- 2009-03-05 0000950129-09-000749 — 1.01, 9.01
- 2009-02-10 0000950129-09-000349 — 2.02, 9.01
- 2008-12-10 0000950134-08-021934 — 2.02, 9.01
- 2008-08-06 0000950129-08-004267 — 2.02, 9.01
- 2008-07-24 0000950129-08-004063 — 1.01, 5.02, 8.01, 9.01
- 2008-06-16 0000950129-08-003500 — 9.01 — amendment of 0000950134-06-015374
- 2008-06-05 0000950129-08-003378 — 5.02, 9.01
- 2008-05-08 0000950129-08-002843 — 2.02, 9.01
- 2008-02-06 0000950129-08-000533 — 2.02, 9.01
- 2007-12-19 0000950129-07-006277 — 1.01, 2.03, 9.01
- 2007-12-06 0000950129-07-006003 — 2.02, 9.01
- 2007-08-21 0000950129-07-004181 — 2.02, 9.01
- 2007-05-31 0000950129-07-002810 — 2.02, 9.01
- 2007-05-21 0000950129-07-002668 — 2.02, 3.01, 4.02, 9.01
- 2007-04-16 0000950129-07-002002 — 2.02, 4.02, 9.01
- 2007-03-01 0000950129-07-001104 — 5.02, 8.01, 9.01
- 2007-02-08 0000950129-07-000451 — 2.02, 9.01
- 2006-12-08 0000950129-06-010041 — 2.02, 9.01
- 2006-09-08 0000950129-06-008379 — 2.02, 9.01
- 2006-08-09 0000950134-06-015374 — 1.01, 2.01, 8.01, 9.01
- 2006-06-08 0000950129-06-006127 — 2.02, 9.01
- 2006-03-09 0000950129-06-002455 — 2.02, 9.01
- 2005-12-16 0000950129-05-012031 — 2.02, 5.03, 9.01
- 2005-09-13 0000950129-05-009181 — 2.01, 9.01 — amendment of 0000950129-05-006889
- 2005-09-12 0000950129-05-009151 — 2.02, 9.01
- 2005-07-06 0000950129-05-006889 — 1.01, 1.02, 2.01, 2.03, 9.01
- 2005-06-10 0000950129-05-006128 — 2.02, 9.01
- 2005-04-20 0000080420-05-000031 — 5.02
- 2005-03-11 0000080420-05-000024 — 9.01
- 2005-02-25 0000080420-05-000018 — 7.01, 9.01
- 2005-01-21 0000080420-05-000009 — 7.01, 9.01
- 2004-12-17 0000080420-04-000049 — 2.02, 9.01
- 2004-11-01 0000080420-04-000045 — 8.01, 9.01
- 2004-10-08 0001169232-04-005133 — 2.05
- 2004-09-14 0000080420-04-000037 — 5.02
- 2004-09-02 0000080420-04-000030 — 2.02, 9.01
- 2004-06-08 0000080420-04-000021 — 7
- 2004-05-13 0000080420-04-000019 — 4
- 2004-02-27 0000080420-04-000013 — 7
- 2003-12-16 0000950129-03-006136 — 12, 7
- 2003-08-29 0000950129-03-004531 — 12, 7
- 2003-06-03 0000950129-03-003035 — 7, 9
- 2003-05-15 0000950129-03-002812 — 7, 9
- 2002-05-29 0000950129-02-002795 — 4
- 2000-12-21 0000950129-00-006093 — 5, 7
- 1998-09-04 0000950129-98-003802 — 5
- 1996-08-09 0000950129-96-001705 — 2, 7

## late-filing notifications on or before 2020-12-09

- 2007-05-11 0000950129-07-002494 — NT 10-Q, for the period ended 2007-03-31
- 2005-01-18 0000080420-05-000004 — NT 10-K, for the period ended 2004-10-31

## item 2.02 — earnings release, exhibit 99.1

[0000080420-20-000032:8k_2_02:1]
EX-99.1
2
ex991-q420earningsrelease.htm
EX-99.1

[0000080420-20-000032:8k_2_02:2]
Document

[0000080420-20-000032:8k_2_02:3]
Exhibit 99.1

[0000080420-20-000032:8k_2_02:4]
PRESS RELEASE

[0000080420-20-000032:8k_2_02:5]
Contacts:    Michael W. Metcalf, CFO

[0000080420-20-000032:8k_2_02:6]
Powell Industries, Inc.

[0000080420-20-000032:8k_2_02:7]
713-947-4422

[0000080420-20-000032:8k_2_02:8]
Robert Winters or Ryan Coleman

[0000080420-20-000032:8k_2_02:9]
Alpha IR Group

[0000080420-20-000032:8k_2_02:10]
POWL@alpha-ir.com

[0000080420-20-000032:8k_2_02:11]
312-445-2870

[0000080420-20-000032:8k_2_02:12]
POWELL INDUSTRIES ANNOUNCES FISCAL 2020 FOURTH QUARTER RESULTS

[0000080420-20-000032:8k_2_02:13]
HOUSTON — DECEMBER 8, 2020 — Powell Industries, Inc. (NASDAQ: POWL), a leading supplier of custom engineered solutions for the management, control and distribution of electrical energy, today announced results for the fiscal 2020 fourth quarter ended September 30, 2020.

[0000080420-20-000032:8k_2_02:14]
Key Highlights:

[0000080420-20-000032:8k_2_02:15]
•Revenues for the fourth quarter of fiscal 2020 totaled $115 million,

[0000080420-20-000032:8k_2_02:16]
•Net Income in the fiscal fourth quarter of 2020 was $3.0 million or $0.25 per diluted share,

[0000080420-20-000032:8k_2_02:17]
•Cash and short-term investments as of September 30, 2020 totaled $179 million,

[0000080420-20-000032:8k_2_02:18]
•Backlog as of September 30, 2020 totaled $477 million.

[0000080420-20-000032:8k_2_02:19]
Brett A. Cope, Powell’s Chairman and Chief Executive Officer, stated, “We closed our fiscal 2020 with another quarter of strong project execution despite the lower volume across our core Oil, Gas, & Petrochemical markets. Consolidated gross margins in our fiscal fourth quarter grew sequentially by 85 basis points, while we generated $18 million of free cash flow as we maintained our diligent focus on working capital initiatives and cost containment efforts. As we navigate through this current cycle, we continue to receive, and adjust to customer requested

[0000080420-20-000032:8k_2_02:20]
changes impacting project schedules as our clients proactively adapt to the current environment.  As we have seen in prior downturns, we are confident that the majority of this work and associated scheduling will improve as clarity within the industrial sector is restored. Powell has weathered prior cycles of lower volumes and customer activity, and we remain confident in our position within our core markets as well as emerging new opportunities that will leverage our expertise.”

[0000080420-20-000032:8k_2_02:21]
Revenues for the fourth quarter of fiscal 2020 totaled $114.7 million compared to $118.1 million in the third fiscal quarter of 2020 and revenue of $148.5 million for the fourth quarter of fiscal 2019.

[0000080420-20-000032:8k_2_02:22]
Net income for the fourth quarter of fiscal 2020 was $3.0 million, or $0.25 per diluted share, compared to net income in the third quarter of fiscal 2020 of $3.5 million, or $0.30 per diluted share, and net income of $6.5 million, or $0.56 per diluted share, for the fourth quarter of fiscal 2019.

[0000080420-20-000032:8k_2_02:23]
New orders placed in the fourth quarter of $57 million included $75 million of gross new orders, partially offset by $18 million of scope reductions and cancelled orders.  The $57 million of net new orders in our fiscal fourth quarter compares to $81 million in the third fiscal quarter of 2020 and $162 million in the fiscal fourth quarter of fiscal 2019.

[0000080420-20-000032:8k_2_02:24]
Backlog as of September 30, 2020 declined 10% sequentially and totaled $477 million compared to $532 million at June 30, 2020 and $566 million at March 31, 2020.

[0000080420-20-000032:8k_2_02:25]
Mr. Cope added, “Looking ahead, we will continue to prioritize the health and safety of our employees and customers. Visibility into our core industrial end-markets remains challenged by the impact of the pandemic and we are positioning for a softer commercial environment as we move into fiscal 2021. We are focused on continuing to drive operational excellence and being diligent on our cost structure.  Finally, given the strength of our balance sheet, this enables us to navigate through periods of lower economic activity, while also positioning us well to capitalize on future opportunities.”

[0000080420-20-000032:8k_2_02:26]
OUTLOOK

[0000080420-20-000032:8k_2_02:27]
Commenting on the company's outlook, Michael Metcalf, Powell’s Chief Financial Officer said, “As we look forward to fiscal 2021, we maintain our expectation of a more challenged industrial environment, particularly across our core Oil, Gas and Petrochemical end-markets.  However, we are seeing strong activity in our Utility and Traction markets that are

[0000080420-20-000032:8k_2_02:28]
helping to utilize and leverage our asset base. Additionally, we are entering fiscal 2021 with $477 million of backlog, roughly 60% of which we expect to convert to revenue throughout this upcoming fiscal year. We will continue to focus on cost containment and effective working capital management as we position ourselves for the eventual return of higher customer order activity.”

[0000080420-20-000032:8k_2_02:29]
CONFERENCE CALL

[0000080420-20-000032:8k_2_02:30]
Powell Industries has scheduled a conference call for Wednesday, December 9, 2020 at 11:00 a.m. Eastern time.   To participate in the conference call, dial 877-270-2148 at least 10 minutes before the call begins and ask for the Powell Industries conference call.  A replay of the call will be available approximately two hours after the live broadcast ends and will be accessible until December 16, 2020.  To access the replay, dial 877-344-7529 using a passcode of 10150185#.

[0000080420-20-000032:8k_2_02:31]
Investors, analysts and the general public will also have the opportunity to listen to the conference call over the Internet by visiting powellind.com. To listen to the live call on the web, please visit the website at least 15 minutes before the call begins to register, download and install any necessary audio software.  For those who cannot listen to the live webcast, an archive will be available shortly after the call and will remain available for approximately 90 days at powellind.com.

[0000080420-20-000032:8k_2_02:32]
Powell Industries, Inc., headquartered in Houston, designs, manufactures and services custom-engineered equipment and systems for the distribution, control and monitoring of electrical energy.  Powell markets include large industrial customers such as utilities, oil and gas producers, refineries, petrochemical plants, pulp and paper producers, mining operations and commuter railways.   For more information, please visit powellind.com.

[0000080420-20-000032:8k_2_02:33]
3

[0000080420-20-000032:8k_2_02:34]
POWELL INDUSTRIES, INC. & SUBSIDIARIES

[0000080420-20-000032:8k_2_02:35]
CONDENSED CONSOLIDATED STATEMENT OF OPERATIONS

[0000080420-20-000032:8k_2_02:36]
|  | Three Months Ended September 30, |  | Year Ended September 30, |  |  |
|  | 2020 |  | 2019 |  | 2020 |  | 2019 |  |  |  |  |
| (In thousands, except per share data) |  |  |  |  |  |  |  |  |  |  |  |
|  | (Unaudited) |  |  |  |  |  |  |  |  |
| Revenues | $ | 114,717 |  |  | $ | 148,504 |  |  | $ | 518,499 |  |  | $ | 517,180 |  |  |  |  |  |
| Cost of goods sold | 92,997 |  |  | 119,949 |  |  | 423,924 |  |  | 430,204 |  |  |  |  |  |
| Gross profit | 21,720 |  | 28,555 |  | 94,575 |  | 86,976 |  |  |  |  |
| Selling, general and administrative expenses | 16,289 |  |  | 19,710 |  |  | 67,662 |  |  | 69,950 |  |  |  |  |  |
| Research and development expenses | 1,403 |  |  | 1,339 |  |  | 6,265 |  |  | 6,327 |  |  |  |  |  |
| Amortization of intangible assets | 45 |  |  | 45 |  |  | 177 |  |  | 177 |  |  |  |  |  |
| Insurance proceeds | — |  |  | — |  |  | — |  |  | (950) |  |  |  |  |  |
| Restructuring and other, net | — |  |  | (222) |  |  | 1,400 |  |  | 11 |  |  |  |  |  |
| Operating income | 3,983 |  |  | 7,683 |  |  | 19,071 |  |  | 11,461 |  |  |  |  |  |
| Other income | (506) |  |  | — |  |  | (506) |  |  | — |  |  |  |  |  |
| Interest expense | 49 |  |  | 60 |  |  | 228 |  |  | 230 |  |  |  |  |  |
| Interest income | (80) |  |  | (396) |  |  | (981) |  |  | (1,103) |  |  |  |  |  |
| Income before income taxes | 4,520 |  |  | 8,019 |  |  | 20,330 |  |  | 12,334 |  |  |  |  |  |
| Income tax provision | 1,537 |  |  | 1,481 |  |  | 3,670 |  |  | 2,444 |  |  |  |  |  |
| Net income | $ | 2,983 |  |  | $ | 6,538 |  |  | $ | 16,660 |  |  | $ | 9,890 |  |  |  |  |  |
| Earnings per share: |  |  |  |  |  |  |  |  |  |  |  |
| Basic | $ | 0.26 |  |  | $ | 0.56 |  |  | $ | 1.43 |  |  | $ | 0.85 |  |  |  |  |  |
| Diluted | $ | 0.25 |  |  | $ | 0.56 |  |  | $ | 1.42 |  |  | $ | 0.85 |  |  |  |  |  |
| Weighted average shares: |  |  |  |  |  |  |  |  |  |  |  |
| Basic | 11,631 |  |  | 11,584 |  |  | 11,624 |  |  | 11,571 |  |  |  |  |  |
| Diluted | 11,705 |  |  | 11,655 |  |  | 11,693 |  |  | 11,634 |  |  |  |  |  |
| SELECTED FINANCIAL DATA: |  |  |  |  |  |  |  |  |  |  |  |
| Depreciation and Amortization | $ | 2,660 |  |  | $ | 2,624 |  |  | $ | 10,538 |  |  | $ | 12,032 |  |  |  |  |  |
| Capital Expenditures | $ | 852 |  |  | $ | 1,065 |  |  | $ | 5,163 |  |  | $ | 4,306 |  |  |  |  |  |
| Dividends Paid | $ | 3,019 |  |  | $ | 3,007 |  |  | $ | 12,066 |  |  | $ | 11,998 |  |  |  |  |  |

[0000080420-20-000032:8k_2_02:37]
POWELL INDUSTRIES, INC. & SUBSIDIARIES

[0000080420-20-000032:8k_2_02:38]
CONDENSED CONSOLIDATED BALANCE SHEETS

[0000080420-20-000032:8k_2_02:39]
|  | September 30, 2020 |  | September 30, 2019 |
| (In thousands) |  |  |  |
| Assets: |  |  |  |
| Cash, cash equivalents and short-term investments | $ | 178,921 |  |  | 124,681 |  |
| Other current assets | 156,737 |  |  | 203,887 |  |
| Property, plant and equipment, net | 114,372 |  |  | 120,812 |  |
| Long-term assets | 22,248 |  |  | 18,031 |  |
| Total assets | $ | 472,278 |  |  | $ | 467,411 |  |
| Liabilities and equity: |  |  |  |
| Current liabilities | $ | 152,947 |  |  | $ | 157,896 |  |
| Long-term debt, net of current maturities | 400 |  |  | 800 |  |
| Deferred and other long-term liabilities | 12,305 |  | 9,562 |
| Stockholders’ equity | 306,626 |  |  | 299,153 |  |
| Total liabilities and stockholders’ equity | $ | 472,278 |  |  | $ | 467,411 |  |
| SELECTED FINANCIAL DATA: |  |  |  |
| Working capital | $ | 182,711 |  |  | $ | 170,672 |  |

[0000080420-20-000032:8k_2_02:40]
5
