# POWL MD&A — 0000080420-22-000036


## mdna

[0000080420-22-000036:mdna:1]
Item 7. Management’s Discussion and Analysis of Financial Condition and Results of Operations

[0000080420-22-000036:mdna:2]
Overview

[0000080420-22-000036:mdna:3]
We develop, design, manufacture and service custom-engineered equipment and systems which (1) distribute, control and monitor the flow of electrical energy and (2) provide protection to motors, transformers and other electrically powered equipment. We are headquartered in Houston, Texas, and serve the oil and gas and petrochemical markets, which include onshore and offshore production, LNG facilities and terminals, pipelines, refineries and petrochemical plants. Additional markets include electric utility and light rail traction power as well as mining and metals, pulp and paper and other municipal, commercial and other industrial markets. Revenues and costs are primarily related to custom engineered-to-order equipment and systems and are accounted for under percentage-of-completion accounting, which precludes us from providing detailed price and volume information. Our backlog includes various projects that typically take a number of months to produce.

[0000080420-22-000036:mdna:4]
The markets in which we participate are capital-intensive and cyclical in nature. Cyclicality is predominantly driven by customer demand, global economic and geopolitical conditions and anticipated environmental, safety or regulatory changes which affect the manner in which our customers proceed with capital investments. Our customers analyze various factors, including the demand and price for oil, gas and electrical energy, the overall economic and financial environment, governmental budgets, regulatory actions and environmental concerns. These factors influence the release of new capital projects by our customers, which are traditionally awarded in competitive bid situations. Scheduling of projects is matched to customer requirements, and projects typically take a number of months to produce. Schedules may change during the course of any particular project, and our operating results can, therefore, be impacted by factors outside of our control.

[0000080420-22-000036:mdna:5]
Within the industrial sector, specifically oil, gas and petrochemical, the demand for our electrical distribution solutions is very cyclical and closely correlated to the level of capital expenditures of our end-user customers as well as prevailing global economic conditions.

[0000080420-22-000036:mdna:6]
Over the past few years, there has been an increase in capital spending within North America on LNG facilities as the market responds to the increased international demand for LNG. As a result, the business was awarded a substantial contract in the second quarter of Fiscal 2020 that will support the integrated electrical distribution requirements for a large domestic LNG industrial complex that was substantially completed in Fiscal 2022.

[0000080420-22-000036:mdna:7]
Impact of Global Economic Uncertainty and Commodity Market Volatility on Powell

[0000080420-22-000036:mdna:8]
Various factors resulting in global economic uncertainty have negatively impacted our results over the past two years. Uncertainty and demand disruptions have resulted in considerable volatility across commodity markets. Although global oil prices have rebounded, our industrial end markets have responded with modest increases in capital expenditures. Additionally, we continue to experience supply chain disruptions driven predominately by availability and cost volatility across our raw materials, components and labor force. All of these factors have contributed to the lower margins realized in Fiscal 2021 and 2022. As we address disruptions and increased costs, we continue to work with our suppliers of key components and commodities to ensure that we are able to meet our customer commitments. Additionally, we have adjusted our pricing models with our customers in response to the increased cost environment.

[0000080420-22-000036:mdna:9]
In response to the lower demand and uncertainty across select end markets, we have taken and will continue to take various actions to maintain or reduce costs. We continue to operate below capacity in some areas and will consistently monitor the macro-economic conditions as we head into our fiscal year ending September 30, 2023.

[0000080420-22-000036:mdna:10]
As discussed further under the heading "Outlook" below, it is difficult to predict the economic impact that this global economic uncertainty, as well as commodity price volatility, may have on our business, results of operations and cash flows going forward.

[0000080420-22-000036:mdna:11]
Results of Operations

[0000080420-22-000036:mdna:12]
Twelve Months Ended September 30, 2022 Compared to Twelve Months Ended September 30, 2021

[0000080420-22-000036:mdna:13]
Revenue and Gross Profit

[0000080420-22-000036:mdna:14]
Revenues increased by 13%, or $62.0 million, to $532.6 million in Fiscal 2022. Domestic revenues increased by 15%, or $53.5 million, to $405.0 million in Fiscal 2022. International revenues increased by 7%, or $8.5 million, to $127.6 million. Our international revenues include both revenues generated from our international facilities as well as revenues from export projects generated at our domestic facilities.

[0000080420-22-000036:mdna:15]
Revenue from our core oil and gas markets (excluding petrochemical) increased by 15%, or $27.5 million, to $215.2 million while petrochemical revenue increased by 13%, or $7.6 million, to $66.5 million in Fiscal 2022, primarily due to increased market activity. Revenue from our utility end markets increased by 10%, or $11.1 million, to $122.4 million and traction market revenue decreased by 24%, or $14.2 million, to $44.9 million in Fiscal 2022. Commercial and other industrial market revenue increased by 109%, or $29.4 million, to $56.5 million driven by an increase in traditionally non-core markets such as data centers, university projects and other miscellaneous applications. Revenue from all other markets combined increased by $0.6 million to $27.1 million in Fiscal 2022.

[0000080420-22-000036:mdna:16]
Gross profit increased by 13%, or $10.0 million, to $85.0 million in Fiscal 2022. Despite the increase in revenues, gross profit as a percentage of revenues remained flat to the prior fiscal year at 16% in Fiscal 2022 due to increased costs impacting older projects in our backlog that were subject to inflationary pressures on raw materials and components, with little or no recourse from the customer to reprice the project. On more recent projects in the backlog, we were able to successfully pass the inflationary impact to the customer in the form of increased pricing. Additionally, favorable project execution, volume leverage and product mix, including fast track service and replacement projects across our service division, all helped to offset the negative inflationary pressure carried by the older projects in the backlog. Additionally, gross profit from our international operations improved over the prior year driven by favorable project execution and increased volume. Throughout the second half of Fiscal 2022, gross margins benefited from favorable close out gains and associated productivity on select projects. Additionally, revenue and gross profit increased by $2.5 million resulting from the settlement of a claim for cost overruns from prior years related to a U.S. based municipal transit project.

[0000080420-22-000036:mdna:17]
Selling, General and Administrative Expenses

[0000080420-22-000036:mdna:18]
Selling, general and administrative expenses increased by 5%, or $3.6 million, to $70.8 million in Fiscal 2022, primarily due to increased variable performance based compensation. Selling, general and administrative expenses, as a percentage of revenues, decreased to 13% in Fiscal 2022, compared to 14% in Fiscal 2021, primarily due to the ability to leverage our cost structure with the increase in revenues.

[0000080420-22-000036:mdna:19]
Other Income

[0000080420-22-000036:mdna:20]
During Fiscal 2022 we recorded other income of $2.3 million related to a gain on the sale of a small, non-core, industrial valve repair and servicing business within our Canadian operations as well as the sale of an excess parcel of land in the U.S. We did not record other income in Fiscal 2021.

[0000080420-22-000036:mdna:21]
Income Tax Provision (Benefit)

[0000080420-22-000036:mdna:22]
We recorded an income tax benefit of $3.9 million in Fiscal 2022, resulting in an effective tax rate of negative 40%, compared to an income tax provision of $0.5 million in Fiscal 2021 at an effective tax rate of 42%. In Fiscal 2022, the tax benefit primarily resulted from the release of the valuation allowance previously recorded against the Canadian net deferred tax assets in the amount of $5.9 million and the estimated Research and Development Tax Credit (R&D Tax Credit). The tax benefit was partially offset by certain non-deductible items, the tax expense related to the gain on the disposition of a small, non-core division of our Canadian operations and the tax impact of U.S. global intangible income.

[0000080420-22-000036:mdna:23]
In Fiscal 2021, the effective tax rate was negatively impacted by our inability to recognize a tax benefit related to losses incurred in various jurisdictions outside of the United States as well as the establishment of a valuation allowance against the deferred tax assets in Mexico. The estimated R&D Tax Credit as well as the utilization of net operating loss carryforwards in Canada that were fully reserved with a valuation allowance provided a tax benefit for Fiscal 2021.

[0000080420-22-000036:mdna:24]
Net Income

[0000080420-22-000036:mdna:25]
In Fiscal 2022, we recorded net income of $13.7 million, or $1.15 per diluted share, compared to net income of $0.6 million, or $0.05 per diluted share in Fiscal 2021. This increase in net income is primarily due to the increase in bookings which led to an increase in revenues, the release of a Canadian valuation allowance recorded against net deferred tax assets, the gain on the sale of a non-core business within our Canadian operations and the settlement of a claim from a project completed in prior years.

[0000080420-22-000036:mdna:26]
Backlog

[0000080420-22-000036:mdna:27]
The order backlog at September 30, 2022 was $592.2 million, a 43% increase from $414.9 million at September 30, 2021. Bookings, net of cancellations and scope reductions, increased by 78% in Fiscal 2022 to $718.6 million, compared to $403.9 million in Fiscal 2021. The large year-over-year increase was due to strength across our utility, petrochemical, and commercial and other industrial end markets.

[0000080420-22-000036:mdna:28]
Outlook

[0000080420-22-000036:mdna:29]
As noted in "Overview" above, the markets in which we participate are capital-intensive and generally cyclical in nature. A significant portion of our revenues has historically been from the oil, gas and petrochemical markets. Oil and gas commodity price levels have been volatile over the last several years, and our customers have in certain cases, delayed or cancelled some of their major capital investment projects due to price volatility and changes in return expectations. Recently we have seen increased global demand for cleaner-burning fuels; however, the uncertainty in oil prices and the global economic impacts from COVID-19, including supply chain disruptions and associated inflationary pressures, as well as other geopolitical events may have a negative impact on our business going forward, as discussed in more detail below. Specific to the energy industry focus on transitioning to natural gas and cleaner-burning fuels, the business was awarded a substantial contract in Fiscal 2020 that will support the integrated electrical distribution requirements for a large domestic industrial complex and was substantially completed in Fiscal 2022. We continue to experience increased demand from markets outside our core oil, gas and petrochemical end markets, as we increase focus on diversification of our project portfolio.

[0000080420-22-000036:mdna:30]
Our operating results are impacted by factors such as the timing of new order awards, customer approval of final engineering and design specifications and delays in customer construction schedules, all of which contribute to short-term earnings variability and the timing of project execution. Our operating results also have been, and may continue to be, impacted by the timing and resolution of change orders, project close-out and resolution of potential contract claims and liquidated damages, all of which could improve or deteriorate gross margins during the period in which these items are resolved with our customers. Disruption in the global supply chain has negatively impacted our business and operating results as well due to the reduction in availability and uncertainty in the timing of the receipt of certain key component parts and commodities. These factors may result in periods of underutilization of our resources and facilities, which may negatively impact our ability to cover our fixed costs or inhibit our ability to deliver completed products on time. Additionally, the increases in commodity and component costs from projects awarded in prior years and increased labor costs may have a negative impact on our operating results in the

[0000080420-22-000036:mdna:31]
event that we are not able to pass these cost increases to our customers. Prior to Fiscal 2022, we experienced periods of lower commercial activity driven in large part from the uncertainty resulting from the COVID-19 pandemic, as discussed in "Overview" above. Considering the long cycle nature of our business, we are exposed to cyclical conditions in our business. We will continue to remain focused on the variables that impact our markets as well as cost management, labor and supply chain challenges. We will also continue to adjust to the global conditions in order to maintain competitive cost and technological advantages in the markets that we serve.

[0000080420-22-000036:mdna:32]
The consequences of a prolonged economic decline could include, but are not limited to, a reduction in commercial and industrial activity. The Company cannot reasonably estimate the duration or severity of these global economic challenges, or the extent to which the resulting disruptions may materially impact our business, results of operations or cash flows. We will take prudent measures to maintain our strong liquidity and cash position, which may include reducing our capital expenditures and research and development costs, as well as reducing or eliminating future dividend payments.

[0000080420-22-000036:mdna:33]
Liquidity and Capital Resources

[0000080420-22-000036:mdna:34]
As of September 30, 2022, current assets exceeded current liabilities by 2.0 times.

[0000080420-22-000036:mdna:35]
Cash, cash equivalents and short-term investments decreased to $116.5 million at September 30, 2022, compared to $134.0 million at September 30, 2021. This decrease in cash was primarily driven by the timing of contract billing milestones which increased accounts receivable and the strategic increase in inventory from the advance purchase of certain raw materials and component parts in response to uncertainty from the global supply challenges. We believe that our strong working capital position, available borrowings under our credit facility and available cash should be sufficient to finance future operating activities, capital improvements and research and development initiatives for the foreseeable future.

[0000080420-22-000036:mdna:36]
We have a credit agreement with Bank of America, N.A. (the U.S. Revolver) which is a $75.0 million revolving credit facility available for both borrowings and letters of credit and expires September 27, 2024. The U.S. Revolver states that up to $30 million may be deducted from the amount of letters of credit outstanding (not to be less than zero) when calculating the consolidated funded indebtedness which is a component of the consolidated net leverage ratio. Additionally, we have the option to cash collateralize all or a portion of the letters of credit outstanding, which would favorably impact the consolidated funded indebtedness calculation and the consolidated net leverage ratio.

[0000080420-22-000036:mdna:37]
On October 1, 2021, our industrial development revenue bonds matured and as a result we had no long-term debt at September 30, 2022. As of September 30, 2022, there were no amounts borrowed under the U.S. Revolver, and letters of credit outstanding were $36.7 million. As of September 30, 2022, $38.3 million was available for the issuance of letters of credit and borrowing under the U.S. Revolver. We are required to maintain certain financial covenants, the most significant of which are a consolidated net leverage ratio of less than 3.0 to 1.0 and a consolidated interest coverage ratio of greater than 3.0 to 1.0. Our most restrictive covenant, the consolidated net leverage ratio, is the ratio of earnings before interest, taxes, depreciation, amortization and stock-based compensation (EBITDAS) to funded indebtedness, which includes letters of credit. An increase in indebtedness or a decrease in EBITDAS could restrict our ability to issue letters of credit or borrow under the U.S. Revolver. For further information regarding our debt, see Notes G and H of Notes to Consolidated Financial Statements.

[0000080420-22-000036:mdna:38]
Approximately $25.8 million of our cash, cash equivalents and short-term investments at September 30, 2022 was held outside of the U.S. for our international operations. It is our intention to indefinitely reinvest all current and future foreign earnings internationally in order to ensure sufficient working capital to support our international operations. In the event that we elect to repatriate some or all of the foreign earnings that were previously deemed to be indefinitely reinvested outside the U.S., we may incur additional tax expense upon such repatriation under current tax laws.

[0000080420-22-000036:mdna:39]
Operating Activities

[0000080420-22-000036:mdna:40]
Operating activities used net cash of $3.6 million in Fiscal 2022 and $30.5 million in Fiscal 2021. Cash flow from operations is primarily influenced by the timing of milestone payments from our customers, project volume and the associated working capital requirements, as well as payment terms with our suppliers. This decrease in cash flows used in operations was primarily due to the timing of contract billing milestones and an increase in accounts payable and accrued liabilities, although offset by the increase in accounts receivable and inventory safety stock levels to mitigate global supply chain risks.

[0000080420-22-000036:mdna:41]
Investing Activities

[0000080420-22-000036:mdna:42]
Investing activities provided $6.5 million of cash during Fiscal 2022 compared to $2.5 million of cash used in Fiscal 2021. The increase in cash provided by investing activities in Fiscal 2022 was primarily due to proceeds of $4.3 million received from the sale of a small, non-core division of our Canadian operations.

[0000080420-22-000036:mdna:43]
Financing Activities

[0000080420-22-000036:mdna:44]
Net cash used in financing activities was $13.3 million in Fiscal 2022 and $13.2 million during the same period in Fiscal 2021, which primarily consisted of approximately $12.2 million and $12.1 million of dividends paid in the respective years.

[0000080420-22-000036:mdna:45]
Other Commercial Commitments

[0000080420-22-000036:mdna:46]
We are contingently liable for letters of credit and bank guarantees totaling $39.7 million as of September 30, 2022, with the following potential cash outflows in the event that we are unable to perform under our contracts (in thousands):

[0000080420-22-000036:mdna:47]
| Payments Due by Period: | Letters ofCredit/Bank Guarantees |
| Less than 1 year | $ | 8,807 |  |
| 1 to 3 years | 24,294 |  |
| More than 3 years | 6,648 |  |
| Total long-term commercial obligations | $ | 39,749 |  |

[0000080420-22-000036:mdna:48]
We also had surety bonds totaling $241.0 million that were outstanding at September 30, 2022. Surety bonds are primarily used to guarantee our contract performance to our customers.

[0000080420-22-000036:mdna:49]
Off-Balance Sheet Arrangements

[0000080420-22-000036:mdna:50]
We had no significant off-balance sheet arrangements during the periods presented.

[0000080420-22-000036:mdna:51]
Effects of Inflation

[0000080420-22-000036:mdna:52]
We are subject to inflation, which can cause increases in our costs of labor, indirect expenses and raw materials, primarily copper, aluminum and steel. Fixed-price contracts can limit our ability to pass these increases to our customers, thus negatively impacting our earnings. Inflation in commodity prices and general indirect expenses had a negative impact on our financial results in Fiscal 2022. Additionally, inflation related specifically to commodity and labor prices may potentially impact our operations in future years.

[0000080420-22-000036:mdna:53]
Critical Accounting Estimates

[0000080420-22-000036:mdna:54]
The preparation of consolidated financial statements in conformity with accounting principles generally accepted in the U.S. requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities, disclosures of contingent assets and liabilities known to exist at the date of the consolidated financial statements and the reported amounts of revenues and expenses during the reporting period. We evaluate our estimates on an ongoing basis, based on historical experience and on various other assumptions that are believed to be reasonable under the circumstances. There can be no assurance that actual results will not differ from those estimates.

[0000080420-22-000036:mdna:55]
We believe the following accounting estimates to be critical in the preparation and reporting of our consolidated financial statements.

[0000080420-22-000036:mdna:56]
Revenue Recognition

[0000080420-22-000036:mdna:57]
Our revenues are primarily generated from the manufacturing of custom-engineered products and systems under long-term fixed-price contracts under which we agree to manufacture various products such as traditional and arc-resistant distribution switchgear and control gear, medium-voltage circuit breakers, monitoring and control communications systems, motor control centers, switches and bus duct systems. These products may be sold separately as an engineered solution, but are typically integrated into custom-built enclosures which we also build.  These enclosures are referred to as power control room

[0000080420-22-000036:mdna:58]
substations (PCRs®), custom-engineered modules or electrical houses (E-Houses). Some contracts may also include the installation and the commissioning of these enclosures.

[0000080420-22-000036:mdna:59]
Revenue from these contracts is generally recognized over time utilizing the cost-to-cost method. Under the cost-to-cost method, the extent of progress towards completion is measured based on the ratio of costs incurred to date to the total estimated costs at completion of the performance obligation. We believe that this method is the most accurate representation of our performance, because it directly measures the value of the services transferred to the customer over time as we incur costs on our contracts. Contract costs include all direct materials, labor, and indirect costs related to contract performance, which may include indirect labor, supplies, tools, repairs and depreciation costs.

[0000080420-22-000036:mdna:60]
Contract Estimates

[0000080420-22-000036:mdna:61]
Actual revenues and project costs may vary from previous estimates due to changes in a variety of factors. The cost estimation process is based upon the professional knowledge and experience of our engineers, project managers and financial professionals. Factors that are considered in estimating the work to be completed and ultimate contract recovery include the availability and productivity of labor, the nature and complexity of the work to be performed, the availability of materials, and the effect of any delays on our project performance. We periodically review our job performance, job conditions, estimated profitability and final contract settlements, including our estimate of total costs and make revisions to costs and income in the period in which the revisions are probable and reasonably estimable. We bear the risk of cost overruns in most of our contracts, which may result in reduced profits. Whenever revisions of estimated contract costs and contract values indicate that the contract costs will exceed estimated revenues, thus creating a loss, a provision for the total estimated loss is recorded in that period. See Note E of Notes to Consolidated Financial Statements for disclosures related to changes in contract estimates.

[0000080420-22-000036:mdna:62]
Performance Obligations

[0000080420-22-000036:mdna:63]
A performance obligation is a promise in a contract or with a customer to transfer a distinct good or service. A contract’s transaction price is allocated to each distinct performance obligation and recognized as revenue as the performance obligations are satisfied. To determine the proper revenue recognition for contracts, we evaluate whether a contract should be accounted for as more than one performance obligation or, less commonly, whether two or more contracts should be combined and accounted for as one performance obligation. This evaluation of performance obligations requires significant judgment. The majority of our contracts have a single performance obligation where multiple engineered products and services are combined into a single, custom-engineered solution. Our contracts include a standard one-year assurance warranty. Occasionally, we provide service-type warranties that will extend the warranty period. These extended warranties qualify as separate performance obligations, and revenue is deferred and recognized over the warranty period. If we determine during the evaluation of the contract that there are multiple performance obligations, we allocate the transaction price to each performance obligation using our best estimate of the standalone selling price of each distinct good or service in the contract.

[0000080420-22-000036:mdna:64]
Variable Consideration

[0000080420-22-000036:mdna:65]
It is common for our long-term contracts to contain variable consideration that can either increase or decrease the transaction price. Due to the nature of our contracts, estimating total cost and revenue can be complex and subject to variability due to change orders, back charges, spare parts, early completion bonuses, customer allowances and liquidated damages. We estimate the amount of variable consideration based on the expected value method, which is the sum of probability-weighted amounts, or the most likely amount method, which uses various factors including experience with similar transactions and assessment of our anticipated performance. Variable consideration is included in the transaction price if legally enforceable and to the extent it is probable that a significant reversal of cumulative revenue recognized will not occur once the uncertainty associated with the variable consideration is resolved.

[0000080420-22-000036:mdna:66]
Contract Modifications

[0000080420-22-000036:mdna:67]
Contracts may be modified for changes in contract specifications and requirements. We consider contract modifications to exist when the modification either creates new or changes the enforceable rights and obligations under the contract. Most of our contract modifications are for goods and services that are not distinct from the existing performance obligation. Contract modifications result in a cumulative catch-up adjustment to revenue based on our measure of progress for the performance obligation.

[0000080420-22-000036:mdna:68]
Impairment of Long-Lived Assets

[0000080420-22-000036:mdna:69]
We review long-lived assets for impairment whenever events or changes in circumstances indicate that the carrying value may not be realizable. If an evaluation is required, the estimated future undiscounted cash flows associated with the asset are compared to the asset’s carrying amount to determine if recording an impairment of such asset is necessary. This requires us to make long-term forecasts of the future revenues and costs related to the assets subject to review. Forecasts require assumptions about demand for our products and future market conditions. Estimating future cash flows requires significant judgment, and our projections may vary from cash flows eventually realized. Future events and unanticipated changes to assumptions could require a provision for impairment in a future period. The effect of any impairment would be reflected in income (loss) from operations in the Consolidated Statements of Operations. In addition, we estimate the useful lives of our long-lived assets and other intangibles and periodically review these estimates to determine whether these lives are appropriate.

[0000080420-22-000036:mdna:70]
Accruals for Contingent Liabilities

[0000080420-22-000036:mdna:71]
From time to time, contingencies such as insurance-related claims, liquidated damages and legal claims arise in the normal course of business. Pursuant to applicable accounting standards, we must evaluate such contingencies to subjectively determine the likelihood that an asset has been impaired, or a liability has been incurred at the date of the financial statements, as well as evaluate whether the amount of the loss can be reasonably estimated. If the likelihood is determined to be probable, and it can be reasonably estimated, the estimated loss is recorded. The amounts we record for contingent liabilities require judgments regarding the amount of expenses that will ultimately be incurred. We use past experience and history, as well as the specific circumstances surrounding each contingent liability, including estimated legal costs, in evaluating the amount of liability that should be recorded. Actual results could differ from our estimates.

[0000080420-22-000036:mdna:72]
Warranty Costs

[0000080420-22-000036:mdna:73]
Estimated costs of warranties are accrued based on historical warranty claim costs in relation to current revenues. In addition, specific provisions are made when product failures are projected outside historical experience. Our standard terms and conditions of sale include a warranty for parts and service for one year. Occasionally, we provide service-type warranties that will extend the warranty period. Actual results could differ from our estimate.

[0000080420-22-000036:mdna:74]
Projects may require, on occasion, warranty terms that are longer than our standard terms due to the nature of the project. Extended warranty terms may be negotiated and included in our contracts. The allocated revenue associated with the extended warranty is deferred and recorded as a contract liability and recognized as revenue over the extended warranty period.

[0000080420-22-000036:mdna:75]
Accounting for Income Taxes

[0000080420-22-000036:mdna:76]
We account for income taxes under the asset and liability method, based on the income tax laws and rates in the countries in which operations are conducted, and income is earned. This approach requires the recognition of deferred tax assets and liabilities for the expected future tax consequences of temporary differences between the carrying amounts and the tax basis of assets and liabilities. Developing our provision for income taxes requires significant judgment and expertise in federal, international and state income tax laws, regulations and strategies, including the determination of deferred tax assets and liabilities and, if necessary, any valuation allowances that may be required for deferred tax assets. In assessing the extent to which net deferred tax assets may be realized, we consider whether it is more likely than not that some portion or all of the net deferred tax assets may not be realized. The ultimate realization of net deferred tax assets is dependent on the generation of future taxable income during the periods in which those temporary differences become deductible. Estimates may change as new events occur, estimates of future taxable income during the carryforward period are reduced or increased, additional information becomes available, or operating environments change, which may result in a full or partial reversal of the valuation allowance. We will continue to assess the adequacy of the valuation allowance on a quarterly basis. Our judgments and tax strategies are subject to audit by various taxing authorities.

[0000080420-22-000036:mdna:77]
The objectives of accounting for income taxes are to recognize the amount of taxes payable or refundable for the current year and deferred tax liabilities and assets for the future tax consequences of events that have been recognized in an entity’s financial statements or tax returns. We recognize the tax benefit from an uncertain tax position only if it is more likely than not that the tax position will be sustained on examination by the taxing authorities, based on the technical merits of the position. The tax benefits recognized in the financial statements from such a position should be measured based on the largest benefit that has a greater than 50% likelihood of being realized upon ultimate settlement. Accounting literature also provides guidance on derecognition of income tax assets and liabilities, classification of current and deferred income tax assets and liabilities, accounting for interest and penalties associated with tax positions, and income tax disclosures. Judgment is required in assessing the future tax consequences of events that have been recognized in our financial statements or tax returns. Variations in the actual outcome of these future tax consequences could materially impact our financial position and results of operations.

[0000080420-22-000036:mdna:78]
See Note I of Notes to Consolidated Financial Statements for disclosures related to the valuation allowance recorded in relation to deferred taxes.
