# POWL 10-K controls and the auditor's report


## auditors_report

[0000080420-22-000036:auditors_report:1]
Report of Independent Registered Public Accounting Firm

[0000080420-22-000036:auditors_report:2]
To the Board of Directors and Stockholders of Powell Industries, Inc.

[0000080420-22-000036:auditors_report:3]
Opinions on the Financial Statements and Internal Control over Financial Reporting

[0000080420-22-000036:auditors_report:4]
We have audited the accompanying consolidated balance sheets of Powell Industries, Inc. and its subsidiaries (the “Company”) as of September 30, 2022 and 2021, and the related consolidated statements of operations, of comprehensive income, of stockholders’ equity and of cash flows for each of the three years in the period ended September 30, 2022, including the related notes (collectively referred to as the “consolidated financial statements”). We also have audited the Company's internal control over financial reporting as of September 30, 2022, based on criteria established in Internal Control - Integrated Framework (2013) issued by the Committee of Sponsoring Organizations of the Treadway Commission (COSO).

[0000080420-22-000036:auditors_report:5]
In our opinion, the consolidated financial statements referred to above present fairly, in all material respects, the financial position of the Company as of September 30, 2022 and 2021, and the results of its operations and its cash flows for each of the three years in the period ended September 30, 2022 in conformity with accounting principles generally accepted in the United States of America. Also in our opinion, the Company maintained, in all material respects, effective internal control over financial reporting as of September 30, 2022, based on criteria established in Internal Control - Integrated Framework (2013) issued by the COSO.

[0000080420-22-000036:auditors_report:6]
Basis for Opinions

[0000080420-22-000036:auditors_report:7]
The Company's management is responsible for these consolidated financial statements, for maintaining effective internal control over financial reporting, and for its assessment of the effectiveness of internal control over financial reporting, included in Management’s Report on Internal Control Over Financial Reporting appearing under Item 9A. Our responsibility is to express opinions on the Company’s consolidated financial statements and on the Company's internal control over financial reporting based on our audits. We are a public accounting firm registered with the Public Company Accounting Oversight Board (United States) (PCAOB) and are required to be independent with respect to the Company in accordance with the U.S. federal securities laws and the applicable rules and regulations of the Securities and Exchange Commission and the PCAOB.

[0000080420-22-000036:auditors_report:8]
We conducted our audits in accordance with the standards of the PCAOB. Those standards require that we plan and perform the audits to obtain reasonable assurance about whether the consolidated financial statements are free of material misstatement, whether due to error or fraud, and whether effective internal control over financial reporting was maintained in all material respects.

[0000080420-22-000036:auditors_report:9]
Our audits of the consolidated financial statements included performing procedures to assess the risks of material misstatement of the consolidated financial statements, whether due to error or fraud, and performing procedures that respond to those risks. Such procedures included examining, on a test basis, evidence regarding the amounts and disclosures in the consolidated financial statements. Our audits also included evaluating the accounting principles used and significant estimates made by management, as well as evaluating the overall presentation of the consolidated financial statements. Our audit of internal control over financial reporting included obtaining an understanding of internal control over financial reporting, assessing the risk that a material weakness exists, and testing and evaluating the design and operating effectiveness of internal control based on the assessed risk. Our audits also included performing such other

[0000080420-22-000036:auditors_report:10]
29

[0000080420-22-000036:auditors_report:11]
procedures as we considered necessary in the circumstances. We believe that our audits provide a reasonable basis for our opinions.

[0000080420-22-000036:auditors_report:12]
Definition and Limitations of Internal Control over Financial Reporting

[0000080420-22-000036:auditors_report:13]
A company’s internal control over financial reporting is a process designed to provide reasonable assurance regarding the reliability of financial reporting and the preparation of financial statements for external purposes in accordance with generally accepted accounting principles. A company’s internal control over financial reporting includes those policies and procedures that (i) pertain to the maintenance of records that, in reasonable detail, accurately and fairly reflect the transactions and dispositions of the assets of the company; (ii) provide reasonable assurance that transactions are recorded as necessary to permit preparation of financial statements in accordance with generally accepted accounting principles, and that receipts and expenditures of the company are being made only in accordance with authorizations of management and directors of the company; and (iii) provide reasonable assurance regarding prevention or timely detection of unauthorized acquisition, use, or disposition of the company’s assets that could have a material effect on the financial statements.

[0000080420-22-000036:auditors_report:14]
Because of its inherent limitations, internal control over financial reporting may not prevent or detect misstatements. Also, projections of any evaluation of effectiveness to future periods are subject to the risk that controls may become inadequate because of changes in conditions, or that the degree of compliance with the policies or procedures may deteriorate.

[0000080420-22-000036:auditors_report:15]
Critical Audit Matters

[0000080420-22-000036:auditors_report:16]
The critical audit matter communicated below is a matter arising from the current period audit of the consolidated financial statements that was communicated or required to be communicated to the audit committee and that (i) relates to accounts or disclosures that are material to the consolidated financial statements and (ii) involved our especially challenging, subjective, or complex judgments. The communication of critical audit matters does not alter in any way our opinion on the consolidated financial statements, taken as a whole, and we are not, by communicating the critical audit matter below, providing a separate opinion on the critical audit matter or on the accounts or disclosures to which it relates.

[0000080420-22-000036:auditors_report:17]
Revenue Recognition – Long-term fixed priced contracts

[0000080420-22-000036:auditors_report:18]
As described in Notes B and E to the consolidated financial statements, approximately 94% of the Company’s total revenue of $532.6 million for the year ended September 30, 2022 was generated from the manufacturing of custom-engineered products and systems under long-term fixed-price contracts. Revenue from these contracts is generally recognized over time utilizing the cost-to-cost method to measure the extent of progress toward the completion of the performance obligation and the recognition of revenue over time. Management believes that this method is the most accurate representation of performance, because it directly measures the value of the services transferred to the customer over time as costs are incurred on the contracts. Contract costs include all direct materials, labor, and indirect costs related to contract performance, which may include indirect labor, supplies, tools, repairs and depreciation costs. Under the cost-to-cost method, the extent of progress towards completion is measured based on the ratio of costs incurred to date to the total estimated costs at completion of the performance obligation. Due to the nature of the contracts, estimating total cost and revenue can be complex and subject to variability due to change orders, back charges, spare parts, early completion bonuses, customer allowances and liquidated damages. Management estimates the amount of variable consideration based on the expected value method, which is the sum of the probability-weighted amount, or the most likely amount method which uses various factors including experience with similar transactions and assessment of anticipated performance.

[0000080420-22-000036:auditors_report:19]
30

[0000080420-22-000036:auditors_report:20]
The principal considerations for our determination that performing procedures relating to revenue recognized over time utilizing the cost-to-cost method is a critical audit matter are the significant judgment by management when determining the estimated total cost and revenue, which in turn led to a high degree of auditor judgment, subjectivity and effort in performing procedures and in evaluating management’s judgment about assumptions related to the estimates of costs to complete and liquidated damages.

[0000080420-22-000036:auditors_report:21]
Addressing the matter involved performing procedures and evaluating audit evidence in connection with forming our overall opinion on the consolidated financial statements. These procedures included testing the effectiveness of controls relating to the revenue recognition process, including controls over the determination of total estimated costs at completion of the performance obligation and determination of total contract price. These procedures also included, among others, evaluating and testing management’s process for determining the estimated total cost and revenue for a sample of contracts, which included (i) obtaining executed purchase orders and agreements, (ii) evaluating the appropriateness of the method to measure estimated total cost and revenue, (iii) testing the completeness and accuracy of the underlying data used by management, and (iv) evaluating the reasonableness of significant assumptions related to the total estimated costs at completion and liquidated damages used by management and considering the factors that can affect the accuracy of those estimates. Evaluating the reasonableness of significant assumptions related to estimated total cost involved assessing management’s ability to reasonably estimate total costs to complete and liquidated damages by testing management’s process to evaluate the remaining direct materials, labor, and indirect costs related to the performance obligation and evaluating the timely identification of circumstances which may warrant a modification to the total estimated costs or liquidated damages.

[0000080420-22-000036:auditors_report:22]
/s/ PricewaterhouseCoopers LLP

[0000080420-22-000036:auditors_report:23]
Houston, Texas

[0000080420-22-000036:auditors_report:24]
December 6, 2022

[0000080420-22-000036:auditors_report:25]
We have served as the Company’s auditor since 2004.

[0000080420-22-000036:auditors_report:26]
31

[0000080420-22-000036:auditors_report:27]
POWELL INDUSTRIES, INC. AND SUBSIDIARIES


## item_9a

[0000080420-22-000036:item_9a:1]
Item 9A. Controls and Procedures

[0000080420-22-000036:item_9a:2]
Evaluation of Disclosure Controls and Procedures

[0000080420-22-000036:item_9a:3]
We have established and maintain a system of disclosure controls and procedures that are designed to provide reasonable assurance that information required to be disclosed in our reports filed with the SEC pursuant to the Securities Exchange Act of 1934, as amended (Exchange Act), is recorded, processed, summarized and reported within the time periods specified in the rules and forms of the SEC and that such information is accumulated and communicated to our management, including our Chief Executive Officer (CEO) and Chief Financial Officer (CFO), as appropriate, to allow timely decisions regarding required disclosures.

[0000080420-22-000036:item_9a:4]
Management, with the participation of our CEO and CFO, has evaluated the effectiveness of the design and operation of our disclosure controls and procedures (as defined in Rules 13a-15(e) and 15d-15(e) of the Exchange Act) as of the end of the period covered by this Annual Report on Form 10-K. Based on such evaluation, our CEO and CFO have each concluded that, as of September 30, 2022, the end of the period covered by this Annual Report on Form 10-K, our disclosure controls and procedures were effective to provide reasonable assurance that information required to be disclosed by us in reports that we file or submit under the Exchange Act is recorded, processed, summarized and reported within the time periods specified in the SEC’s rules and forms and that such information is accumulated and communicated to our management, including the CEO and CFO, as appropriate, to allow timely decisions regarding required disclosures.

[0000080420-22-000036:item_9a:5]
Management’s Report on Internal Control Over Financial Reporting

[0000080420-22-000036:item_9a:6]
Management is responsible for establishing and maintaining effective internal control over financial reporting as defined in Rule 13a-15(f) under the Exchange Act. Our system of internal control was designed using a top-down risk-based approach to provide reasonable assurance regarding the reliability of financial reporting and the preparation of financial statements for external purposes in accordance with generally accepted accounting principles. Due to its inherent limitations, internal control over financial reporting may not prevent or detect misstatements. Also, projections of any evaluation of effectiveness to future periods are subject to the risk that controls may become ineffective due to changes in conditions or deterioration in the degree of compliance with the policies or procedures.

[0000080420-22-000036:item_9a:7]
Management of the Company has assessed the effectiveness of our internal control over financial reporting as of September 30, 2022. Management evaluated the effectiveness of our internal control over financial reporting based on the criteria in Internal Control – Integrated Framework (2013) issued by the Committee of Sponsoring Organizations of the Treadway Commission (COSO). Based on management’s evaluation, management has concluded that our internal control over financial reporting was effective at the reasonable assurance level as of September 30, 2022, based on criteria in Internal Control – Integrated Framework (2013) issued by the COSO.

[0000080420-22-000036:item_9a:8]
PricewaterhouseCoopers LLP, an independent registered public accounting firm, has audited and issued their report on the effectiveness of our internal control over financial reporting as of September 30, 2022, which appears in their report on the financial statements included herein.

[0000080420-22-000036:item_9a:9]
Changes in Internal Control Over Financial Reporting

[0000080420-22-000036:item_9a:10]
There have been no changes in our internal control over financial reporting that occurred during the last fiscal quarter that have materially affected, or are reasonably likely to materially affect, our internal control over financial reporting.
