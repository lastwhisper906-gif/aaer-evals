# POWL notes — 0000080420-22-000036


## dei:DocumentsIncorporatedByReferenceTextBlock

[0000080420-22-000036:notes:1]
Portions of the registrant’s definitive proxy statement for the 2022 annual meeting of stockholders to be filed not later than 120 days after September 30, 2022, are incorporated by reference into Part III of this Form 10-K.


## us-gaap:SignificantAccountingPoliciesTextBlock

[0000080420-22-000036:notes:2]
Summary of Significant Accounting Policies

[0000080420-22-000036:notes:3]
Principles of Consolidation

[0000080420-22-000036:notes:4]
The consolidated financial statements include the accounts of Powell and our wholly-owned subsidiaries. All intercompany accounts and transactions have been eliminated in consolidation.

[0000080420-22-000036:notes:5]
Use of Estimates

[0000080420-22-000036:notes:6]
The preparation of financial statements in conformity with accounting principles generally accepted in the United States (U.S. GAAP) requires management to make estimates and assumptions that affect the amounts reported in the consolidated financial statements and accompanying footnotes. The most significant estimates used in our consolidated financial statements affect revenue recognition and estimated cost recognition on our customer contracts, the allowance for credit losses, provision for excess and obsolete inventory, warranty accruals and income taxes. The amounts recorded for warranties, legal, income taxes, impairment of long-lived assets (when applicable), liquidated damages and other contingent liabilities require judgments regarding the amount of expenses that will ultimately be incurred. We base our estimates on historical experience, forecasts and various other assumptions, as well as the specific circumstances surrounding these contingent liabilities, in evaluating the amount of liability that should be recorded. Additionally, the recognition of deferred tax assets requires estimates related to future income and other assumptions regarding timing and future profitability because the ultimate realization of net deferred tax assets is dependent on the generation of future taxable income during periods in which temporary differences become

[0000080420-22-000036:notes:7]
deductible. Estimates routinely change as new events occur, additional information becomes available or operating environments change. Actual results may differ from our prior estimates.

[0000080420-22-000036:notes:8]
Cash and Investments

[0000080420-22-000036:notes:9]
Cash and cash equivalents - Cash and cash equivalents, primarily funds held in money market savings instruments, are reported at their current carrying value, which approximates fair value due to the short-term nature of these instruments, and are included in cash and cash equivalents in our Consolidated Balance Sheets.

[0000080420-22-000036:notes:10]
Short-term Investments - Short-term investments include time deposits with original maturities of three months or more.

[0000080420-22-000036:notes:11]
Supplemental Disclosures of Cash Flow Information (in thousands):

[0000080420-22-000036:notes:12]
|  | Year Ended September 30, |
|  | 2022 |  | 2021 |  | 2020 |
| Cash paid (received) during the period for: |  |  |  |  |  |
| Interest received, net of interest expense | $ | (334) |  |  | $ | (73) |  |  | $ | (753) |  |
| Income taxes paid, net of refunds | 533 |  |  | 1,886 |  |  | 1,770 |  |
| Non-cash capital expenditures | 1,133 |  |  | 226 |  |  | 264 |  |

[0000080420-22-000036:notes:13]
Fair Value of Financial Instruments

[0000080420-22-000036:notes:14]
Financial instruments include cash, cash equivalents, short-term investments, restricted cash, receivables, deferred compensation, payables and debt obligations. Except as described below, due to the short-term nature of account receivables and account payables, the book value is representative of their fair value. The carrying value of debt approximates fair value as interest rates are indexed to the Federal Funds Rate or the bank’s prime rate.

[0000080420-22-000036:notes:15]
Accounts Receivable

[0000080420-22-000036:notes:16]
Accounts receivable are stated net of allowances for credit losses. We maintain and continually assess the adequacy of the allowance for credit losses representing our estimate for losses resulting from the inability of our customers to pay amounts due to us. This estimated allowance is based on historical experience of uncollected accounts, the level of past due accounts, the overall level of outstanding accounts receivable, information about specific customers with respect to their inability to make payments and expectations of future conditions that could impact the collectability of accounts receivable. Future changes in our customers’ operating performance and cash flows, or in general economic conditions, could have an impact on their ability to fully pay these amounts, which could have a material impact on our operating results. In most cases, receivables are not collateralized. However, we utilize letters of credit to secure payment on projects when possible. As of September 30, 2022 and 2021, accounts receivable included retention amounts of $6.9 million and $9.6 million, respectively. Retention amounts are in accordance with applicable provisions of contracts and become due upon completion of contractual requirements. Of the retained amount at September 30, 2022, $6.0 million is expected to be collected in the next twelve months and is recorded in accounts receivable. The remaining $0.9 million is recorded in other assets and is expected to be collected in the fiscal year ending September 30, 2023.

[0000080420-22-000036:notes:17]
Contract Balances

[0000080420-22-000036:notes:18]
The timing of revenue recognition, billings and cash collections affects accounts receivable, contract assets and contract liabilities in our Consolidated Balance Sheets.

[0000080420-22-000036:notes:19]
Contract assets are recorded when revenues are recognized in excess of amounts billed for fixed-price contracts as determined by the billing milestone schedule. Contract assets are transferred to accounts receivable when billing milestones have been met, or we have an unconditional right to payment.

[0000080420-22-000036:notes:20]
Contract liabilities typically represent advance payments from contractual billing milestones and billings in excess of revenue recognized. It is unusual to have advanced milestone payments with a term greater than one year, which could represent a financing component on the contract.

[0000080420-22-000036:notes:21]
Our contract assets and liabilities are reported in a net position on a contract-by-contract basis at the end of each reporting period and are generally classified as current.

[0000080420-22-000036:notes:22]
Inventories

[0000080420-22-000036:notes:23]
Inventories are stated at the lower of cost or net realizable value using weighted-average methods and include the cost of materials, labor and manufacturing overhead. We use estimates in determining the level of reserves required to state inventory at the lower of cost or net realizable value. Our estimates are based on market activity levels, production requirements, the physical condition of products and technological innovation. Changes in any of these factors may result in adjustments to the carrying value of inventory.

[0000080420-22-000036:notes:24]
Property, Plant and Equipment

[0000080420-22-000036:notes:25]
Property, plant and equipment are stated at cost and are depreciated using the straight-line method over the estimated useful lives of the assets. Expenditures for repairs and maintenance are charged to expense when incurred. Expenditures for major renewals and improvements, which extend the useful lives of existing equipment, are capitalized and depreciated. Upon retirement or disposition of property, plant and equipment, the cost and related accumulated depreciation are removed from the accounts, and any resulting gain or loss is recognized in the Consolidated Statements of Operations.

[0000080420-22-000036:notes:26]
We review property, plant and equipment for impairment whenever events or changes in circumstances indicate that the carrying value may not be realizable. If an evaluation is required, the estimated future undiscounted cash flows associated with the asset are compared to the asset’s carrying amount to determine if recording an impairment of such asset is necessary. If an impairment is indicated, we record an impairment loss equal to the difference between the carrying value and the fair value of the long-lived asset. This requires us to make long-term forecasts of the future revenues and the costs related to the assets subject to review. Forecasts require assumptions about demand for our products and future market conditions. Estimating future cash flows requires significant judgment, and our projections may vary from cash flows eventually realized. Future events and unanticipated changes to assumptions could require a provision for impairment in a future period. The effect of any impairment would be reflected in income (loss) from operations in the Consolidated Statements of Operations. In addition, we estimate the useful lives of our property, plant and equipment and periodically review these estimates to determine whether these lives are appropriate.

[0000080420-22-000036:notes:27]
Income Taxes

[0000080420-22-000036:notes:28]
We account for income taxes under the asset and liability method, based on the income tax laws and rates in the countries in which operations are conducted, and income is earned. This approach requires the recognition of deferred tax assets and liabilities for the expected future tax consequences of temporary differences between the carrying amounts and the tax basis of assets and liabilities. Developing our provision for income taxes requires significant judgment and expertise in federal, international and state income tax laws, regulations and strategies, including the determination of deferred tax assets and liabilities and, if necessary, any valuation allowances that may be required for deferred tax assets. In assessing the extent to which net deferred tax assets may be realized, we consider whether it is more likely than not that some portion or all of the net deferred tax assets may not be realized. The ultimate realization of net deferred tax assets is dependent on the generation of future taxable income during the periods in which those temporary differences become deductible. Estimates may change as new events occur, estimates of future taxable income during the carryforward period are reduced or increased, additional information becomes available or operating environments change, which may result in a full or partial reversal of the valuation allowance. We will continue to assess the adequacy of the valuation allowance on a quarterly basis. Our judgments and tax strategies are subject to audit by various taxing authorities.

[0000080420-22-000036:notes:29]
The objectives of accounting for income taxes are to recognize the amount of taxes payable or refundable for the current year and deferred tax liabilities and assets for the future tax consequences of events that have been recognized in an entity’s financial statements or tax returns. We recognize the tax benefit from an uncertain tax position only if it is more likely than not that the tax position will be sustained on examination by the taxing authorities, based on the technical merits of the position. The tax benefits recognized in the financial statements from such a position should be measured based on the largest benefit that has a greater than 50% likelihood of being realized upon ultimate settlement. Accounting literature also provides guidance on derecognition of income tax assets and liabilities, classification of current and deferred income tax assets and liabilities, accounting for interest and penalties associated with tax positions, and income tax disclosures. Judgment is required in assessing the future tax consequences of events that have been recognized in our financial statements or tax returns. Variations in the actual outcome of these future tax consequences could materially impact our financial statements.

[0000080420-22-000036:notes:30]
Revenue Recognition

[0000080420-22-000036:notes:31]
Our revenues are primarily generated from the manufacturing of custom-engineered products and systems under long-term fixed-price contracts that may last from one month to several years, depending on the contract. Revenue from these contracts is generally recognized over time utilizing the cost-to-cost method. Under the cost-to-cost method, the extent of progress towards

[0000080420-22-000036:notes:32]
completion is measured based on the ratio of costs incurred to date to the total estimated costs at completion of the performance obligation. We believe that this method is the most accurate representation of our performance because it directly measures the value of the services transferred to the customer over time as we incur costs on our contracts. Contract costs include all direct materials, labor and indirect costs related to contract performance, which may include indirect labor, supplies, tools, repairs and depreciation costs.

[0000080420-22-000036:notes:33]
We also have contracts to provide field service inspection, installation, commissioning, modification, and repair services, as well as spare parts, retrofill components for existing systems, and replacement circuit breakers for obsolete or out-of-production switchgear no longer produced by the original manufacturer. If the service contract terms give us the right to invoice the customer for an amount that corresponds directly with the value of our performance completed to date (i.e., a service contract in which we bill a fixed amount for each hour of service provided), then we recognize revenue over time in each reporting period corresponding to the amount with which we have the right to invoice.  Our performance obligations are satisfied as the work progresses.

[0000080420-22-000036:notes:34]
We also have sales orders for spare parts and replacement circuit breakers for switchgear that are obsolete or that are no longer produced by the original manufacturer. Revenues from these sales orders are recognized at the time we fulfill our performance obligation to the customer, which is typically upon shipment.

[0000080420-22-000036:notes:35]
Additionally, some contracts may contain a cancellation clause that could limit the amount of revenue we are able to recognize over time. In these instances, revenue and costs associated with these contracts are deferred and recognized at a point in time when the performance obligation is fulfilled.

[0000080420-22-000036:notes:36]
Selling and administrative costs incurred in relation to obtaining a contract are typically expensed as incurred. We periodically utilize a third-party sales agent to obtain a contract and will pay a commission to that agent. We record the full commission liability to the third-party sales agents at the order date, with a corresponding deferred asset. As the project progresses, we record commission expense based on percentage of completion rates that correlate to the project and reduce the deferred asset. Once we have been paid by the customer, we pay the commission and the liability is reduced.

[0000080420-22-000036:notes:37]
Warranty Costs

[0000080420-22-000036:notes:38]
Estimated costs of warranties are accrued based on historical warranty claim costs in relation to current revenues. In addition, specific provisions are made when product failures are projected outside historical experience. Our standard terms and conditions of sale include a warranty for parts and service for one year. Occasionally, we provide service-type warranties that will extend the warranty period. Actual results could differ from our estimate.

[0000080420-22-000036:notes:39]
Projects may require, on occasion, warranty terms that are longer than our standard terms due to the nature of the project. Extended warranty terms may be negotiated and included in our contracts. The allocated revenue associated with the extended warranty is deferred and recorded as a contract liability and recognized as revenue over the extended warranty period.

[0000080420-22-000036:notes:40]
Research and Development Expense

[0000080420-22-000036:notes:41]
Research and development activities are directed toward the development of new products and processes as well as improvements in existing products and processes. These costs, which primarily include salaries, contract services and supplies, are expensed as incurred. Such amounts were $7.0 million, $6.7 million and $6.3 million in Fiscal 2022, 2021 and 2020, respectively.

[0000080420-22-000036:notes:42]
Foreign Currency Translation

[0000080420-22-000036:notes:43]
The functional currency for our foreign subsidiaries is the local currency in which the entity is located. The financial statements of all subsidiaries with a functional currency other than the U.S. Dollar have been translated into U.S. Dollars. All assets and liabilities of foreign operations are translated into U.S. Dollars using year-end exchange rates, and all revenues and expenses are translated at average rates during the respective period. The U.S. Dollar results that arise from such translation, as well as exchange gains and losses on intercompany balances of a long-term investment nature, are included in the cumulative currency translation adjustments in accumulated other comprehensive loss in stockholders’ equity.

[0000080420-22-000036:notes:44]
Stock-Based Compensation

[0000080420-22-000036:notes:45]
We measure stock-based compensation cost at the grant date based on the fair value of the award. Compensation expense is recognized over the period during which the recipient is required to provide service in exchange for the awards, typically the vesting period. Excess income tax benefits related to share-based compensation expense are recognized as income tax expense or benefit in the Consolidated Statement of Operations. Cash paid when directly withholding shares on an employee's behalf for tax withholding purposes is classified as a financing activity. We account for forfeitures as they occur, rather than estimate expected forfeitures.


## us-gaap:RevenueFromContractWithCustomerPolicyTextBlock

[0000080420-22-000036:notes:46]
Performance Obligations

[0000080420-22-000036:notes:47]
A performance obligation is a promise in a contract or with a customer to transfer a distinct good or service. A contract’s transaction price is allocated to each distinct performance obligation and recognized as revenue as the performance obligations are satisfied. To determine the proper revenue recognition for contracts, we evaluate whether a contract should be accounted for as more than one performance obligation or, less commonly, whether two or more contracts should be combined and accounted for as one performance obligation. This evaluation of performance obligations requires significant judgment. The majority of our contracts have a single performance obligation where multiple engineered products and services are combined into a single custom-engineered solution. Our contracts include a standard one-year assurance warranty. Occasionally, we provide service-type warranties that will extend the warranty period. These extended warranties qualify as a separate performance obligation, and revenue is deferred and recognized over the warranty period. If we determine during the evaluation of the contract that there are multiple performance obligations, we allocate the transaction price to each performance obligation using our best estimate of the standalone selling price of each distinct good or service in the contract. 
Remaining unsatisfied performance obligations, which we refer to as backlog, represent the estimated transaction price for goods and services for which we have a material right, but work has not been performed.
Contract Estimates

[0000080420-22-000036:notes:48]
Actual revenues and project costs may vary from previous estimates due to changes in a variety of factors. The cost estimation process is based upon the professional knowledge and experience of our engineers, project managers and financial professionals. Factors that are considered in estimating the work to be completed and ultimate contract recovery include the availability and productivity of labor, the nature and complexity of the work to be performed, the availability of materials, and the effect of any delays on our project performance. We periodically review our job performance, job conditions, estimated profitability and final contract settlements, including our estimate of total costs and make revisions to costs and income in the period in which the revisions are probable and reasonably estimable. We bear the risk of cost overruns in most of our contracts, which may result in reduced profits. Whenever revisions of estimated contract costs and contract values indicate that the contract costs will exceed estimated revenues, thus creating a loss, a provision for the total estimated loss is recorded in that period.

[0000080420-22-000036:notes:49]
Variable Consideration

[0000080420-22-000036:notes:50]
It is common for our long-term contracts to contain variable consideration that can either increase or decrease the transaction price. Due to the nature of our contracts, estimating total cost and revenue can be complex and subject to variability due to change orders, back charges, spare parts, early completion bonuses, customer allowances and liquidated damages. We estimate the amount of variable consideration based on the expected value method, which is the sum of the probability-weighted amounts, or the most likely amount method which uses various factors including experience with similar transactions and assessment of our anticipated performance. Variable consideration is included in the transaction price if legally enforceable and to the extent it is probable that a significant reversal of cumulative revenue recognized will not occur once the uncertainty associated with the variable consideration is resolved.

[0000080420-22-000036:notes:51]
Contract Modifications

[0000080420-22-000036:notes:52]
Contracts may be modified for changes in contract specifications and requirements. We consider contract modifications to exist when the modification either creates new or changes the enforceable rights and obligations under the contract. Most of our contract modifications are for goods and services that are not distinct from the existing performance obligation. Contract modifications result in a cumulative catch-up adjustment to revenue based on our measure of progress for the performance obligation.


## us-gaap:EarningsPerShareTextBlock

[0000080420-22-000036:notes:53]
Earnings Per Share
We compute basic earnings per share by dividing net income by the weighted average number of common shares outstanding during the period. Diluted earnings per common and potential common share includes the weighted average of additional shares associated with the incremental effect of dilutive restricted stock and restricted stock units, as prescribed by the Financial Accounting Standards Board (FASB) guidance on earnings per share.

[0000080420-22-000036:notes:54]
The following table reconciles basic and diluted weighted average shares used in the computation of earnings per share (in thousands, except per share data):

[0000080420-22-000036:notes:55]
|  | Year Ended September 30, |
|  | 2022 |  | 2021 |  | 2020 |
| Numerator: |  |  |  |  |  |
| Net income | $ | 13,737 |  |  | $ | 631 |  |  | $ | 16,660 |  |
| Denominator: |  |  |  |  |  |
| Weighted average basic shares | 11,797 |  |  | 11,705 |  |  | 11,624 |  |
| Dilutive effect of restricted stock units | 146 |  |  | 84 |  |  | 69 |  |
| Weighted average diluted shares | 11,943 |  |  | 11,789 |  |  | 11,693 |  |
| Earnings per share: |  |  |  |  |  |
| Basic | $ | 1.16 |  |  | $ | 0.05 |  |  | $ | 1.43 |  |
| Diluted | $ | 1.15 |  |  | $ | 0.05 |  |  | $ | 1.42 |  |


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0000080420-22-000036:notes:56]
Detail of Selected Balance Sheet Accounts
Allowance for Credit Losses

[0000080420-22-000036:notes:57]
Activity in our allowance for credit losses consisted of the following (in thousands):

[0000080420-22-000036:notes:58]
|  | September 30, |
|  | 2022 |  | 2021 |
| Balance at beginning of period | $ | 333 |  |  | $ | 510 |  |
| Bad debt expense, net | 162 |  |  | 48 |  |
| Uncollectible accounts written off, net of recoveries | (117) |  |  | (242) |  |
| Change due to foreign currency translation | (34) |  |  | 17 |  |
| Balance at end of period | $ | 344 |  |  | $ | 333 |  |

[0000080420-22-000036:notes:59]
The components of inventories are summarized below (in thousands):

[0000080420-22-000036:notes:60]
|  | September 30, |
|  | 2022 |  | 2021 |
| Raw materials, parts and subassemblies | $ | 54,220 |  |  | $ | 33,149 |  |
| Work-in-progress | 1,202 |  |  | 1,147 |  |
| Provision for excess and obsolete inventory | (5,007) |  |  | (4,461) |  |
| Total inventories | $ | 50,415 |  |  | $ | 29,835 |  |

[0000080420-22-000036:notes:61]
Property, plant and equipment are summarized below (in thousands):

[0000080420-22-000036:notes:62]
|  | September 30, |  | Range of |
|  | 2022 |  | 2021 |  | Asset Lives |
| Land | $ | 21,299 |  |  | $ | 22,355 |  |  | — |
| Buildings and improvements | 120,506 |  |  | 124,798 |  |  | 3 - 39 Years |
| Machinery and equipment | 88,213 |  |  | 96,017 |  |  | 3 - 15 Years |
| Furniture and fixtures | 3,581 |  |  | 3,683 |  |  | 3 - 10 Years |
| Construction in process | 1,728 |  |  | 752 |  |  | — |
|  | $ | 235,327 |  |  | $ | 247,605 |  |  |  |
| Less: Accumulated depreciation | (136,699) |  |  | (138,148) |  |  |  |
| Total property, plant and equipment, net | $ | 98,628 |  |  | $ | 109,457 |  |  |  |

[0000080420-22-000036:notes:63]
There were no assets under finance lease as of September 30, 2022 or September 30, 2021. Depreciation expense was $9.4 million, $10.2 million and $10.4 million for fiscal years 2022, 2021, and 2020, respectively.

[0000080420-22-000036:notes:64]
Accrued Product Warranty

[0000080420-22-000036:notes:65]
Activity in our product warranty accrual consisted of the following (in thousands):

[0000080420-22-000036:notes:66]
|  | September 30, |
|  | 2022 |  | 2021 |
| Balance at beginning of period | $ | 2,531 |  |  | $ | 2,771 |  |
| Increase to warranty expense | 1,425 |  |  | 2,140 |  |
| Deduction for warranty charges | (1,564) |  |  | (2,406) |  |
| Change due to foreign currency translation | (47) |  |  | 26 |  |
| Balance at end of period | $ | 2,345 |  |  | $ | 2,531 |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0000080420-22-000036:notes:67]
Revenue
Revenue Recognition

[0000080420-22-000036:notes:68]
Our revenues are primarily generated from the manufacturing of custom-engineered products and systems under long-term fixed-price contracts under which we agree to manufacture various products such as traditional and arc-resistant distribution switchgear and control gear, medium-voltage circuit breakers, monitoring and control communications systems, motor control centers, switches and bus duct systems. These products may be sold separately as an engineered solution, but are typically integrated into custom-built enclosures which we also build. These enclosures are referred to as power control room substations (PCRs®), custom-engineered modules or electrical houses (E-Houses). Some contracts may also include the installation and the commissioning of these enclosures.

[0000080420-22-000036:notes:69]
Revenue from these contracts is generally recognized over time utilizing the cost-to-cost method. Under the cost-to-cost method, the extent of progress towards completion is measured based on the ratio of costs incurred to date to the total estimated costs at completion of the performance obligation. We believe that this method is the most accurate representation of our

[0000080420-22-000036:notes:70]
performance, because it directly measures the value of the services transferred to the customer over time as we incur costs on our contracts. Contract costs include all direct materials, labor and indirect costs related to contract performance, which may include indirect labor, supplies, tools, repairs and depreciation costs.

[0000080420-22-000036:notes:71]
We also have contracts to provide field service inspection, installation, commissioning, modification, and repair services, as well as retrofit and retrofill components for existing systems. If the service contract terms give us the right to invoice the customer for an amount that corresponds directly with the value of our performance completed to date (i.e., a service contract in which we bill a fixed amount for each hour of service provided), then we recognize revenue over time in each reporting period corresponding to the amount that we have the right to invoice. Our performance obligations are satisfied as the work progresses. Revenues from our custom-engineered products and value-added services transferred to customers over time accounted for approximately 94% and 93% of revenues for the years ended September 30, 2022 and September 30, 2021, respectively.

[0000080420-22-000036:notes:72]
We also have sales orders for spare parts and replacement circuit breakers for switchgear that are obsolete or that are no longer produced by the original manufacturer. Revenues from these sales orders are recognized at the time we fulfill our performance obligation to the customer, which is typically upon shipment and represented approximately 6% and 7% of revenues for the years ended September 30, 2022 and September 30, 2021, respectively.

[0000080420-22-000036:notes:73]
Selling and administrative costs incurred in relation to obtaining a contract are typically expensed as incurred. We periodically utilize a third-party sales agent to obtain a contract and will pay a commission to that agent. We record the full commission liability to the third-party sales agents at the order date, with a corresponding deferred asset. As the project progresses, we record commission expense based on percentage of completion rates that correlate to the project and reduce the deferred asset. Once we have been paid by the customer, we pay the commission, and the deferred liability is reduced.

[0000080420-22-000036:notes:74]
A performance obligation is a promise in a contract or with a customer to transfer a distinct good or service. A contract’s transaction price is allocated to each distinct performance obligation and recognized as revenue as the performance obligations are satisfied. To determine the proper revenue recognition for contracts, we evaluate whether a contract should be accounted for as more than one performance obligation or, less commonly, whether two or more contracts should be combined and accounted for as one performance obligation. This evaluation of performance obligations requires significant judgment. The majority of our contracts have a single performance obligation where multiple engineered products and services are combined into a single custom-engineered solution. Our contracts include a standard one-year assurance warranty. Occasionally, we provide service-type warranties that will extend the warranty period. These extended warranties qualify as a separate performance obligation, and revenue is deferred and recognized over the warranty period. If we determine during the evaluation of the contract that there are multiple performance obligations, we allocate the transaction price to each performance obligation using our best estimate of the standalone selling price of each distinct good or service in the contract.

[0000080420-22-000036:notes:75]
Remaining unsatisfied performance obligations, which we refer to as backlog, represent the estimated transaction price for goods and services for which we have a material right, but work has not been performed. As of September 30, 2022, we had backlog of $592.2 million, of which approximately $375.0 million is expected to be recognized as revenue within the next twelve months. Backlog may not be indicative of future operating results as orders may be cancelled or modified by our customers. Our backlog does not include service and maintenance-type contracts for which we have the right to invoice as services are performed.

[0000080420-22-000036:notes:76]
Contract Estimates

[0000080420-22-000036:notes:77]
For the years ended September 30, 2022 and 2021, our operating results were positively impacted by $11.3 million and $12.5 million, respectively, as a result of changes in contract estimates related to projects in progress at the beginning of the respective period. These changes in estimates resulted primarily from favorable project execution and negotiations of variable consideration, discussed below, as well as revenue and reduced costs recognized from project cancellations and other changes in facts and circumstances during these periods.

[0000080420-22-000036:notes:78]
Our contract assets and liabilities are reported in a net position on a contract-by-contract basis at the end of each reporting period and are generally classified as current. The timing of contract billing milestones related to our Fiscal 2020 contract award for a large industrial project contributed significantly to our net contract liability at September 31, 2020.

[0000080420-22-000036:notes:79]
Contract assets and liabilities as of September 30, 2022 and September 30, 2021 are summarized below (in thousands):

[0000080420-22-000036:notes:80]
|  | September 30, |
|  | 2022 |  | 2021 |
| Contract assets | $ | 88,351 |  |  | $ | 54,199 |  |
| Contract liabilities | (79,857) |  |  | (42,433) |  |
| Net contract asset | $ | 8,494 |  |  | $ | 11,766 |  |

[0000080420-22-000036:notes:81]
The decrease in net contract asset at September 30, 2022 from September 30, 2021 was primarily due to the timing of contract billing milestones and new orders as well as cash used on our large industrial project awarded in Fiscal 2020. To determine the amount of revenue recognized during the period from contract liabilities, we first allocate revenue to the individual contract liability balance outstanding at the beginning of the period until the revenue exceeds that balance. During the year ended September 30, 2022, we recognized revenue of approximately $39.1 million related to contract liabilities outstanding at September 30, 2021.

[0000080420-22-000036:notes:82]
The timing of our invoice process is typically dependent on the completion of certain milestones and contract terms and subject to agreement by our customer. Payment is typically expected within 30 days of invoice. Any uncollected invoiced amounts for our performance obligations recognized over time, including contract retentions, are recorded as accounts receivable in the Consolidated Balance Sheets. Certain contracts allow customers to withhold a small percentage of billings pursuant to retainage provisions, and such amounts are generally due upon completion of the contract and acceptance of the project by the customer.

[0000080420-22-000036:notes:83]
Based on our experience in recent years, the majority of these retainage balances are expected to be collected within approximately twelve months. As of September 30, 2022 and September 30, 2021, accounts receivable included retention amounts of $6.9 million and $9.6 million, respectively. Of the retained amount at September 30, 2022, $6.0 million is expected to be collected in the next twelve months and is recorded in accounts receivable.  The remaining $0.9 million is recorded in other assets.

[0000080420-22-000036:notes:84]
Disaggregation of Revenue

[0000080420-22-000036:notes:85]
The following tables present our disaggregated revenue by geographic destination and market sector for the years ended September 30, 2022 and September 30, 2021 (in thousands):

[0000080420-22-000036:notes:86]
|  | 2022 |  | 2021 |
| United States | $ | 404,973 |  |  | $ | 351,422 |  |
| Canada | 81,218 |  |  | 68,655 |  |
| Europe, Middle East and Africa | 38,411 |  |  | 39,642 |  |
| Asia/Pacific | 4,885 |  |  | 8,889 |  |
| Mexico, Central and South America | 3,095 |  |  | 1,951 |  |
| Total revenues by geographic destination | $ | 532,582 |  |  | $ | 470,559 |  |

[0000080420-22-000036:notes:87]
|  | 2022 |  | 2021 |
| Oil and gas (excludes petrochemical) | $ | 215,235 |  |  | $ | 187,660 |  |
| Petrochemical | 66,538 |  |  | 58,986 |  |
| Electric utility | 122,361 |  |  | 111,244 |  |
| Traction power | 44,930 |  |  | 59,106 |  |
| Commercial and other industrial | 56,448 |  |  | 27,065 |  |
| All others | 27,070 |  |  | 26,498 |  |
| Total revenues by market sector | $ | 532,582 |  |  | $ | 470,559 |  |


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0000080420-22-000036:notes:88]
Goodwill and Intangible AssetsOur intangible assets consist of goodwill of $1.0 million, which is not being amortized. In Fiscal 2021, our purchased technology was fully amortized and we no longer have any intangible assets subject to amortization. No impairment expense has been recorded for the last three fiscal years. Amortization of intangible assets recorded for each of the years ended September 30, 2021 and 2020 was $0.2 million.


## us-gaap:LongTermDebtTextBlock

[0000080420-22-000036:notes:89]
Long-Term Debt
Long-term debt consisted of the following (in thousands):

[0000080420-22-000036:notes:90]
|  | September 30, |
|  | 2022 |  | 2021 |
| Industrial development revenue bonds | $ | — |  |  | $ | 400 |  |
| Less: current portion | — |  |  | (400) |  |
| Total long-term debt | $ | — |  |  | $ | — |  |

[0000080420-22-000036:notes:91]
U.S. Revolver

[0000080420-22-000036:notes:92]
We have a credit agreement with Bank of America, N.A. (the U.S. Revolver), which is a $75.0 million revolving credit facility that is available for both borrowings and letters of credit and expires September 27, 2024. The U.S. Revolver states that up to $30 million may be deducted from the amount of letters of credit outstanding (not to be less than zero) when calculating the consolidated funded indebtedness which is a component of the consolidated net leverage ratio. Additionally, we have the option to cash collateralize all or a portion of the letters of credit outstanding, which would favorably impact the consolidated funded indebtedness calculation and the consolidated net leverage ratio. As of September 30, 2022, there were no amounts borrowed under the U.S. Revolver, and letters of credit outstanding were $36.7 million. There was $38.3 million available for the issuance of letters of credit and borrowings under the U.S. Revolver as of September 30, 2022.

[0000080420-22-000036:notes:93]
We are required to maintain certain financial covenants, the most significant of which are a consolidated net leverage ratio less than 3.0 to 1.0 and a consolidated interest coverage ratio of greater than 3.0 to 1.0. Our most restrictive covenant, the consolidated net leverage ratio, is the ratio of earnings before interest, taxes, depreciation, amortization and stock-based compensation (EBITDAS) to funded indebtedness. An increase in indebtedness, which includes letters of credit, or a decrease in EBITDAS could restrict our ability to issue letters of credit or borrow under the U.S. Revolver. Additionally, we must maintain a consolidated cash balance of $30 million at all times, which can be deducted from the letters of credit outstanding as noted above. The U.S. Revolver also contains a "material adverse effect" clause which is a material change in our operations, business, properties, liabilities or condition (financial or otherwise) or a material impairment of our ability to perform our obligations under our credit agreements. As of September 30, 2022, we were in compliance with all of the financial covenants of the U.S. Revolver.

[0000080420-22-000036:notes:94]
The U.S. Revolver allows the Company to elect that any borrowing under the facility bears an interest rate based on either the base rate or the eurocurrency rate, in each case, plus the applicable rate. The base rate is generally the highest of (a) the federal funds rate plus 0.50%, (b) the Bank of America prime rate or (c) the London Interbank Offered Rate (LIBOR) successor rate plus 1.00%. The applicable rate is generally a range from (0.25)% to 1.75% depending on the type of loan and the Company's consolidated net leverage ratio. On December 31, 2021, the Company entered into a LIBOR Transition Agreement with Bank of America that states that LIBOR will be replaced with a successor rate in accordance with the U.S. Revolver.

[0000080420-22-000036:notes:95]
The U.S. Revolver is collateralized by a pledge of 100% of the voting capital stock of each of our domestic subsidiaries and 65% of the voting capital stock of each non-domestic subsidiary. The U.S. Revolver provides for customary events of default and carries cross-default provisions with other existing debt agreements. If an event of default (as defined in the U.S. Revolver) occurs and is continuing, on the terms and subject to the conditions set forth in the U.S. Revolver, amounts and letters of credit outstanding under the U.S. Revolver may be accelerated and may become immediately due and payable.

[0000080420-22-000036:notes:96]
Industrial Development Revenue Bonds
We borrowed $8.0 million in October 2001 through a loan agreement funded with proceeds from tax-exempt industrial development revenue bonds (Bonds) for the completion of our Northlake, Illinois facility. The Bonds matured on October 1, 2021, and our final payment of $0.4 million was made.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0000080420-22-000036:notes:97]
Commitments and Contingencies
Letters of Credit, Bank Guarantees and Bonds

[0000080420-22-000036:notes:98]
Certain customers require us to post letters of credit, bank guarantees or surety bonds. These security instruments assure that we will perform under the terms of our contract. In the event of default, the counterparty may demand payment from the bank under a letter of credit or bank guarantee, or performance by the surety under a bond. To date, there have been no significant draws or claims related to security instruments for the periods reported. We were contingently liable for letters of credit of $36.7 million as of September 30, 2022. We also had surety bonds totaling $241.0 million that were outstanding, with additional bonding capacity of $359.0 million available, at September 30, 2022. We have strong surety relationships; however, a change in market conditions or the sureties' assessment of our financial position could cause the sureties to require cash collateralization for undischarged liabilities under the bonds.

[0000080420-22-000036:notes:99]
We have a $5.6 million facility agreement (Facility Agreement) between Powell (UK) Limited and a large international bank that provides Powell (UK) Limited the ability to enter into bank guarantees as well as forward exchange contracts and currency options. At September 30, 2022, we had outstanding guarantees totaling $3.1 million and amounts available under this Facility Agreement were $2.5 million. The Facility Agreement provides for customary events of default, and carries cross-default provisions with our U.S. Revolver. If an event of default (as defined in the Facility Agreement) occurs and is continuing, per

[0000080420-22-000036:notes:100]
the terms and subject to the conditions set forth therein, obligations outstanding under the Facility Agreement may be accelerated and declared immediately due and payable. Additionally, we are required to maintain cash collateral for guarantees greater than two years. As of September 30, 2022, we were in compliance with all of the financial covenants of the Facility Agreement.

[0000080420-22-000036:notes:101]
Litigation

[0000080420-22-000036:notes:102]
We are involved in various legal proceedings, claims and other disputes arising from our commercial operations, projects, employees and other matters which, in general, are subject to uncertainties and in which the outcomes are not predictable. Although we can give no assurances about the resolution of pending claims, litigation or other disputes and the effect such outcomes may have on us, management believes that any ultimate liability resulting from the outcome of such proceedings, to the extent not otherwise provided or covered by insurance, will not have a material adverse effect on our consolidated financial position or results of operations or liquidity.

[0000080420-22-000036:notes:103]
Liquidated Damages

[0000080420-22-000036:notes:104]
Certain of our customer contracts have schedule and performance obligation clauses that, if we fail to meet them, could require us to pay liquidated damages. Each individual contract defines the conditions under which the customer may make a claim against us. As of September 30, 2022, our exposure to possible liquidated damages was $3.5 million, of which approximately $2.2 million was probable. Based on our actual or projected failure to meet these various contractual commitments, $1.4 million has been recorded as a reduction to revenue. We will attempt to obtain change orders, contract extensions or accelerate project completion, which may resolve the potential for any unrecorded liquidated damage. We have claimed force majeure on certain contracts due to delays associated with the COVID-19 pandemic. Should we fail to achieve relief on some or all of these contractual obligations, we could be required to pay additional liquidated damages, which could negatively impact our future operating results.


## us-gaap:IncomeTaxDisclosureTextBlock

[0000080420-22-000036:notes:105]
Income Taxes 
The components of the income tax provision were as follows (in thousands):

[0000080420-22-000036:notes:106]
|  | Year Ended September 30, |
|  | 2022 |  | 2021 |  | 2020 |
| Current: |  |  |  |  |  |
| Federal | $ | 557 |  |  | $ | 911 |  |  | $ | 945 |  |
| State | 403 |  |  | 472 |  |  | 1,186 |  |
| Foreign | 7 |  |  | 73 |  |  | 66 |  |
|  | 967 |  |  | 1,456 |  |  | 2,197 |  |
| Deferred: |  |  |  |  |  |
| Federal | (154) |  |  | (1,062) |  |  | 1,045 |  |
| State | (41) |  |  | (30) |  |  | (91) |  |
| Foreign | (4,666) |  |  | 97 |  |  | 519 |  |
|  | (4,861) |  |  | (995) |  |  | 1,473 |  |
| Total income tax provision (benefit) | $ | (3,894) |  |  | $ | 461 |  |  | $ | 3,670 |  |

[0000080420-22-000036:notes:107]
Income before income taxes was as follows (in thousands):

[0000080420-22-000036:notes:108]
|  | Year Ended September 30, |
|  | 2022 |  | 2021 |  | 2020 |
| U.S. | $ | 3,175 |  |  | $ | 3,076 |  |  | $ | 21,243 |  |
| Foreign | 6,668 |  |  | (1,984) |  |  | (913) |  |
| Income before income taxes | $ | 9,843 |  |  | $ | 1,092 |  |  | $ | 20,330 |  |

[0000080420-22-000036:notes:109]
A reconciliation of the statutory U.S. income tax rate and the effective income tax rate, as computed on earnings before income tax provision (benefit) in each of the three years presented in the Consolidated Statements of Operations, was as follows:

[0000080420-22-000036:notes:110]
|  | Year Ended September 30, |
|  | 2022 |  | 2021 |  | 2020 |
| Statutory rate | 21 | % |  | 21 | % |  | 21 | % |
| State income taxes, net of federal benefit | 3 |  |  | 25 |  |  | 5 |  |
| Research and development credit | (14) |  |  | (101) |  |  | (13) |  |
| Foreign rate differential | 1 |  |  | 10 |  |  | — |  |
| Foreign taxes | — |  |  | 10 |  |  | — |  |
| Valuation allowance | (62) |  |  | 62 |  |  | 4 |  |
| Deferred tax rate differential | (1) |  |  | (19) |  |  | — |  |
| Non-deductible expenses | 9 |  |  | 30 |  |  | 1 |  |
| Impact of U.S. global intangible taxes and benefits | 3 |  |  | — |  |  | — |  |
| Other(1) | — |  |  | 4 |  |  | — |  |
| Effective rate | (40) | % |  | 42 | % |  | 18 | % |
| (1) Certain prior year amounts have not been reclassified for consistency with the current year presentation. |

[0000080420-22-000036:notes:111]
Our income tax benefit reflects an effective tax rate on pre-tax results of negative 40% in Fiscal 2022 compared to 42% and 18% in Fiscal 2021 and 2020, respectively. The income tax benefit for Fiscal 2022 was largely a result of the reversal of a valuation allowance on the Canadian deferred tax assets that were previously fully reserved, in addition to the current year estimated Research and Development Tax Credit (R&D Tax Credit). These items were partially offset by the tax expense related to certain nondeductible expenses, the gain on the disposition of a small, non-core division of our Canadian operations and an inclusion related to U.S. global intangible income.

[0000080420-22-000036:notes:112]
The tax provision for Fiscal 2021 and 2020 was favorably impacted by the estimated R&D Tax Credit as well as the utilization of net operating loss carryforwards in Canada that were fully reserved with a valuation allowance. In Fiscal 2021, the tax provision was negatively impacted by the losses recognized in other foreign jurisdictions, primarily in the United Kingdom (U.K.), that were reserved with a valuation allowance as well as the establishment of a valuation allowance against the deferred tax assets in Mexico. While in Fiscal 2020, discrete items recorded in the third quarter in the amount of $1.7 million associated with the release of reserves for unrecognized tax benefits as a result of the expiration of statutes of limitations and the IRS audit settlement favorably impacted the effective tax rate. The effective tax rate was negatively impacted by the discrete item recorded in the second quarter of Fiscal 2020 for the valuation allowance against our U.K. deferred tax assets in the amount of $0.5 million as well as by the losses recognized in various foreign jurisdictions that were reserved with a valuation allowance.

[0000080420-22-000036:notes:113]
We record and maintain valuation allowances against the deferred tax assets of various foreign jurisdictions until sufficient evidence is available to demonstrate that it is more likely than not that the net deferred tax assets will be recognized. As of each reporting date, management considers new evidence, both positive and negative, that could affect its view of the future realization of deferred tax assets. During the period ended June 30, 2022, management determined that there was sufficient positive evidence to conclude that Canadian net deferred tax assets of $5.9 million were realizable. This determination was based on current and anticipated market conditions, continued market diversification, operating results over the past three years and anticipated future taxable income from our Canadian operations. The valuation allowance was released accordingly, and a $5.9 million tax benefit and corresponding increase in the deferred tax assets were recorded. During our assessment of deferred income taxes in Fiscal 2020 and 2021, we recorded a valuation allowance of $0.5 million against our U.K. net deferred tax assets in the second quarter of Fiscal 2020 and a valuation allowance of $0.1 million against our Mexican net deferred tax assets in the fourth quarter of Fiscal 2021. In assessing the realizability of net deferred tax assets, we determined it was more likely than not that the net deferred tax assets may not be realized based upon recent U.K. and Mexican tax losses and anticipated results in the near term. Estimates may change as new events occur, estimates of future taxable income are reduced or increased, additional information becomes available, or operating environments change, which may result in a full or partial reversal of the valuation allowance.

[0000080420-22-000036:notes:114]
We have not recorded deferred income taxes on $13.5 million of undistributed earnings of our foreign subsidiaries because of management’s intent to indefinitely reinvest such earnings. Upon distribution of these earnings in the form of dividends or otherwise, we may be subject to U.S. income taxes and foreign withholding taxes. It is not practical, however, to estimate the amount of taxes that may be payable on the eventual remittance of these earnings.

[0000080420-22-000036:notes:115]
We are subject to income tax in the U.S., multiple state jurisdictions and certain international jurisdictions, primarily the U.K. and Canada. We do not consider any state in which we do business to be a major tax jurisdiction. We remain open to examination in the other jurisdictions as follows: Canada 2015 – 2021, United Kingdom 2021 and the United States 2019 – 2021. As of September 30, 2022, we did not have any state audits underway that would have a material impact on our financial position or results of operations.

[0000080420-22-000036:notes:116]
The net deferred income tax asset was comprised of the following (in thousands):

[0000080420-22-000036:notes:117]
|  | September 30, |
|  | 2022 |  | 2021 |
| Gross assets | $ | 17,941 |  |  | $ | 20,427 |  |
| Gross liabilities and valuation allowance | (8,780) |  |  | (15,788) |  |
| Net deferred income tax asset | $ | 9,161 |  |  | $ | 4,639 |  |

[0000080420-22-000036:notes:118]
The tax effect of temporary differences between U.S. GAAP accounting and federal income tax accounting creating deferred income tax assets and liabilities was as follows (in thousands):

[0000080420-22-000036:notes:119]
|  | September 30, |
|  | 2022 |  | 2021 |
| Deferred Tax Assets: |  |  |  |
| Net operating loss | $ | 10,186 |  |  | $ | 12,682 |  |
| Credit carryforwards | 1,332 |  |  | 1,598 |  |
| Deferred compensation | 1,897 |  |  | 2,095 |  |
| Uniform capitalization and inventory | 1,506 |  |  | 1,222 |  |
| Stock-based compensation | 1,083 |  |  | 921 |  |
| Reserve for accrued employee benefits | 872 |  |  | 718 |  |
| Warranty accrual | 559 |  |  | 579 |  |
| Accrued legal | 161 |  |  | 130 |  |
| Postretirement benefits liability | — |  |  | 156 |  |
| Other | 345 |  |  | 326 |  |
| Deferred tax assets | $ | 17,941 |  |  | $ | 20,427 |  |
| Deferred Tax Liabilities: |  |  |  |
| Depreciation and amortization | $ | (3,764) |  |  | $ | (4,404) |  |
| Retention and other | (1,229) |  |  | (886) |  |
| Deferred tax liabilities | $ | (4,993) |  |  | $ | (5,290) |  |
| Less: valuation allowance | (3,787) |  |  | (10,498) |  |
| Net deferred tax asset | $ | 9,161 |  |  | $ | 4,639 |  |

[0000080420-22-000036:notes:120]
As of September 30, 2022, our tax credit carryforwards are fully reserved with a valuation allowance. We had deferred tax assets related to international net operating loss carryforwards of $7.7 million that were not reserved with a valuation allowance available to offset future tax liabilities in the respective jurisdictions. The majority of these net operating loss carryforwards are related to our Canadian operations and expire beginning in 2033. The remaining unreserved carryforwards related to other jurisdictions have an indefinite carryforward period.

[0000080420-22-000036:notes:121]
We have established a valuation allowance in the amount of $3.8 million primarily related to the U.K. net deferred tax assets. The net decrease in the total valuation allowance during the year was $6.7 million which was largely a result of the reversal of the Canadian valuation allowance. In assessing the realizability of net deferred tax assets, we consider whether it is more likely than not that some portion or all of the net deferred tax assets may not be realized. The ultimate realization of net deferred tax assets is dependent on the generation of future taxable income during the periods in which those temporary differences become deductible.

[0000080420-22-000036:notes:122]
A reconciliation of the beginning and ending amount of the unrecognized tax benefits follows (in thousands):

[0000080420-22-000036:notes:123]
|  | Year Ended September 30, |
|  | 2022 |  | 2021 |  | 2020 |
| Balance at beginning of period | $ | 1,409 |  |  | $ | 1,252 |  |  | $ | 2,703 |  |
| Increases related to tax positions taken during the current period | 240 |  |  | 251 |  |  | 220 |  |
| Increases related to tax positions taken during a prior period | 92 |  |  | 75 |  |  | 97 |  |
| Decreases related to expiration of statute of limitations | (327) |  |  | — |  |  | (545) |  |
| Decreases related to settlement with taxing authorities | (37) |  |  | (169) |  |  | (1,223) |  |
| Balance at end of period | $ | 1,377 |  |  | $ | 1,409 |  |  | $ | 1,252 |  |

[0000080420-22-000036:notes:124]
Included in the balance of unrecognized tax benefits at the end of Fiscal 2022, 2021, and 2020 are $1.1 million, $1.1 million, and $0.8 million, respectively, of tax benefits that, if recognized, would affect the effective tax rate. Our policy is to recognize interest and penalties related to income tax matters as tax expense. The amount of interest and penalty expense recorded for the year ended September 30, 2022 was not material.

[0000080420-22-000036:notes:125]
Management believes that, within the next twelve months, it is reasonably possible that the unrecognized tax benefits will decrease by approximately $0.3 million due to the expiration of certain federal statutes of limitations. We are unable to make reasonably reliable estimates regarding the timing of future cash outflows, if any, associated with the remaining unrecognized tax benefits for the open periods of fiscal years ended September 30, 2019 – 2022.
Management believes that an adequate provision has been made for any adjustments that may result from tax examinations. However, the outcome of tax audits cannot be predicted with certainty. If any issues addressed in our tax audits are resolved in a manner not consistent with management’s expectations, we could be required to adjust our provision for income tax in the period such resolution occurs.


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0000080420-22-000036:notes:126]
Employee Benefit Plans
Retirement Plans

[0000080420-22-000036:notes:127]
We have defined employee contribution plans for substantially all of our U.S. employees (401k plan) and our Canadian employees (Registered Retirement Savings Plan). We recognized expenses under these plans primarily related to matching contributions of $3.0 million, $2.9 million and $3.1 million in Fiscal 2022, 2021 and 2020, respectively.

[0000080420-22-000036:notes:128]
Deferred Compensation

[0000080420-22-000036:notes:129]
We offer a non-qualified deferred compensation plan to a select group of management and highly compensated individuals. The plan permits the deferral of up to 50% of a participant’s base salary and/or 100% of a participant’s annual incentive bonus. The deferrals are held in a separate irrevocable rabbi trust (the Rabbi Trust), which has been established to administer the plan. The Rabbi Trust is intended to be used as a source of funds to match respective funding obligations to participants. The assets of the trust are subject to the claims of our creditors in the event that we become insolvent. Consequently, the Rabbi Trust qualifies as a grantor trust for income tax purposes. We make periodic payments into company-owned life insurance policies held in this Rabbi Trust to fund the expected obligations arising under this plan. Changes in the deferred compensation balance are recorded to compensation expense and reflected within the selling, general and administrative line in the Consolidated Statements of Operations. The plan is not qualified under Section 401 of the Internal Revenue code. We recorded net compensation expense adjustments of $0.3 million related to this plan in Fiscal 2022. At September 30, 2022, total assets held by the trustee were $7.7 million and recorded in other assets and the liability was $7.7 million and recorded in deferred compensation in our Consolidated Balance Sheets. The $7.7 million of assets held by the trustee is invested in company-owned life insurance policies.

[0000080420-22-000036:notes:130]
Certain former executives were provided an executive benefit plan that provides for fixed payments upon normal retirement on or after age 65 and the completion of at least 10 years of continuous employment. The estimated present value of these payments was accrued over the service life of these individuals, and less than $0.1 million is recorded in deferred compensation related to this executive benefit plan. To assist in funding the deferred compensation liability, we invested in company-owned life insurance policies. The cash surrender value of these policies is presented in other assets and was $3.4 million at September 30, 2022.

[0000080420-22-000036:notes:131]
Retiree Medical Plan

[0000080420-22-000036:notes:132]
We have an unfunded plan that extends health benefits to retirees that are also available to active employees under our existing health plans. The current plan provides coverage for employees with at least 10 years of service who are age 55 or older but less than 65. Effective January 1, 2023, eligibility requirements to participate in the plan are changing. At that time, current employees between the ages of 50 to 64 will be eligible to participate in the retiree medical plan once they have completed at least 10 years of service and retire between the ages of 60 and 64. The retiree is required to pay the COBRA rate less a subsidy provided by us based on years of service at the time of retirement. The unfunded liability is recorded in other long-term liabilities and was $0.4 million as of September 30, 2022 and $0.9 million as of September 30, 2021. Our net periodic postretirement benefit expenses were $0.1 million in Fiscal 2022 and less than $0.1 million for both Fiscal  2021 and 2020. Due to the immateriality of the costs and liabilities of this plan, no further disclosure is being presented.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0000080420-22-000036:notes:133]
Stock-Based Compensation
We have the following stock-based compensation plans:

[0000080420-22-000036:notes:134]
Restricted Stock Units

[0000080420-22-000036:notes:135]
In February 2014, our stockholders approved and adopted at the Annual Meeting of Stockholders the 2014 Equity Incentive Plan (the 2014 Plan), which replaced our 2006 Equity Compensation Plan (2006 Plan). Persons eligible to receive awards under the 2014 Plan include our officers and employees. The 2014 Plan authorizes stock options, stock appreciation rights, restricted stock, restricted stock units and performance-based awards, as well as certain other awards.

[0000080420-22-000036:notes:136]
In accordance with the 2014 Plan, the Compensation Committee has authorized grants of restricted stock units (RSUs) to certain officers and key employees of the company. The fair value of the RSUs is based on the price of our common stock as reported on the NASDAQ Global Market on the grant dates. Typically, these grants vest over a three-year period from the date of issuance and are a blend of time-based and performance-based shares. Fifty percent of the grant is time-based and vests over a three-year period on each anniversary of the grant date, based on continued employment. The remaining fifty percent of the grant is earned based on the three-year earnings and safety performance of the Company following the grant date. At September 30, 2022, there were 239,862 RSUs outstanding. The RSUs do not have voting rights but do receive dividend equivalents upon vesting which are accrued quarterly. Additionally, the shares of common stock underlying the RSUs are not considered issued and outstanding until vested and common stock is issued.

[0000080420-22-000036:notes:137]
Total RSU activity (number of shares) for the past fiscal year is summarized below:

[0000080420-22-000036:notes:138]
|  | Number ofRestrictedStockUnits |  | WeightedAverageGrant ValuePer Share |
| Outstanding at September 30, 2021 | 199,919 |  |  | $ | 30.34 |  |
| Granted | 113,860 |  |  | 24.69 |  |
| Vested | (73,517) |  |  | 32.79 |  |
| Forfeited/cancelled | (400) |  |  | 38.58 |  |
| Outstanding at September 30, 2022 | 239,862 |  |  | $ | 26.11 |  |

[0000080420-22-000036:notes:139]
We have reserved 750,000 shares of common stock for issuance under the 2014 Plan.

[0000080420-22-000036:notes:140]
Restricted Stock

[0000080420-22-000036:notes:141]
In February 2022, our stockholders approved an amendment to the 2014 Non-Employee Director Equity Incentive Plan (the 2014 Director Plan) that extended the term of the 2014 Director Plan by ten years and increased the number of shares of common stock that may be issued under the 2014 Director Plan by 200,000 shares for a total of 350,000 shares. The plan is administered by the Compensation Committee. Eligibility to participate in the plan is limited to those individuals who are members of the Board of Directors of the Company and who are not employees of the Company or any affiliate of the Company.

[0000080420-22-000036:notes:142]
Under the terms of the 2014 Director Plan, the maximum number of shares that may be granted during any calendar year to any individual is 12,000 shares. The total number of shares that may be issued for awards to any single participant during a calendar year for other stock-based awards (excluding stock options and SARs) is 4,000 shares. The Compensation Committee has determined that each non-employee director will receive 2,400 restricted shares of the Company’s common stock annually. Fifty percent of the restricted stock granted to each of our non-employee directors vests immediately, while the remaining fifty

[0000080420-22-000036:notes:143]
percent vests on the anniversary of the grant date. Compensation expense is recognized immediately for the first fifty percent of the restricted stock granted, while compensation expense for the remaining fifty percent is recognized over the remaining vesting period.

[0000080420-22-000036:notes:144]
Under this 2014 Director Plan, in February 2022, 16,800 shares of restricted stock were issued to our non-employee directors at a price of $23.09 per share. In February 2021, we issued 16,800 shares of restricted stock to our non-employee directors at a price of $31.33 per share. The total number of shares of common stock available for future awards under the 2014 Director plan was 206,200 shares as of September 30, 2022. At September 30, 2022 and 2021, there were 7,200 shares and 8,400 shares, respectively, of unvested restricted stock outstanding.

[0000080420-22-000036:notes:145]
Compensation Expense

[0000080420-22-000036:notes:146]
Total compensation expense related to restricted stock grants under all plans was $0.4 million, $0.5 million and $0.6 million for the years ended September 30, 2022, 2021 and 2020, respectively. Total compensation expense related to RSUs under all plans was $3.7 million, $2.0 million and $2.9 million for the years ended September 30, 2022, 2021 and 2020, respectively.
We record the amortization of non-vested restricted stock and restricted stock units as an increase to additional paid-in capital. As of September 30, 2022 and 2021, amounts of deferred compensation expense not yet recognized related to non-vested stock and RSUs totaled $1.2 million and $1.1 million, respectively. As of September 30, 2022, the total weighted average remaining contractual life of our non-vested restricted stock and RSUs is approximately six months and 1.5 years, respectively.


## us-gaap:FairValueDisclosuresTextBlock

[0000080420-22-000036:notes:147]
Fair Value Measurements
We measure certain financial assets and liabilities at fair value. Fair value is defined as an “exit price,” which represents the amount that would be received to sell an asset or paid to transfer a liability in an orderly transaction between market participants as of the measurement date. As such, fair value is a market-based measurement that should be determined based on assumptions that market participants would use in valuing an asset or liability. The accounting guidance requires the use of valuation techniques to measure fair value that maximize the use of observable inputs and minimize the use of unobservable inputs. As a basis for considering such assumptions and inputs, a fair value hierarchy has been established that identifies and prioritizes three levels of inputs to be used in measuring fair value.

[0000080420-22-000036:notes:148]
The three levels of the fair value hierarchy are as follows:

[0000080420-22-000036:notes:149]
Level 1 — Observable inputs such as quoted prices (unadjusted) in active markets for identical assets or liabilities.

[0000080420-22-000036:notes:150]
Level 2 — Inputs other than the quoted prices in active markets that are observable either directly or indirectly, including: quoted prices for similar assets and liabilities in active markets; quoted prices for identical or similar assets and liabilities in markets that are not active or other inputs that are observable or can be corroborated by observable market data.

[0000080420-22-000036:notes:151]
Level 3 — Unobservable inputs that are supported by little or no market data and require the reporting entity to develop its own assumptions.

[0000080420-22-000036:notes:152]
The following table summarizes the fair value of our assets and liabilities that were accounted for at fair value on a recurring basis as of September 30, 2022 (in thousands):

[0000080420-22-000036:notes:153]
|  | Fair Value Measurements at September 30, 2022 |
|  | Quoted Prices inActive Markets forIdentical Assets(Level 1) |  | Significant OtherObservableInputs(Level 2) |  | SignificantUnobservableInputs(Level 3) |  | Fair Value at September 30, 2022 |
| Assets: |  |  |  |  |  |  |  |
| Cash and cash equivalents | $ | 101,954 |  |  | $ | — |  |  | $ | — |  |  | $ | 101,954 |  |
| Short-term investments | 14,554 |  |  | — |  |  | — |  |  | 14,554 |  |
| Other assets | — |  |  | 7,730 |  |  | — |  |  | 7,730 |  |
| Liabilities: |  |  |  |  |  |  |  |
| Deferred compensation | — |  |  | 7,714 |  |  | — |  |  | 7,714 |  |

[0000080420-22-000036:notes:154]
The following table summarizes the fair value of our assets and liabilities that were accounted for at fair value on a recurring basis as of September 30, 2021 (in thousands):

[0000080420-22-000036:notes:155]
|  | Fair Value Measurements at September 30, 2021 |
|  | Quoted Prices inActive Markets forIdentical Assets(Level 1) |  | Significant OtherObservableInputs(Level 2) |  | SignificantUnobservableInputs(Level 3) |  | Fair Value at September 30, 2021 |
| Assets: |  |  |  |  |  |  |  |
| Cash and cash equivalents | $ | 114,314 |  |  | $ | — |  |  | $ | — |  |  | $ | 114,314 |  |
| Short-term investments | 19,667 |  |  | — |  |  | — |  |  | 19,667 |  |
| Other assets | — |  |  | 9,100 |  |  | — |  |  | 9,100 |  |
| Liabilities: |  |  |  |  |  |  |  |
| Deferred compensation | — |  |  | 8,527 |  |  | — |  |  | 8,527 |  |

[0000080420-22-000036:notes:156]
Fair value guidance requires certain fair value disclosures to be presented in both interim and annual reports. The estimated fair value amounts of financial instruments have been determined using available market information and valuation methodologies described below.

[0000080420-22-000036:notes:157]
Cash and cash equivalents – Cash and cash equivalents, primarily funds held in money market savings instruments, are reported at their current carrying value, which approximates fair value due to the short-term nature of these instruments and are included in cash and cash equivalents in our Consolidated Balance Sheets.

[0000080420-22-000036:notes:158]
Short-term Investments – Short-term investments include time deposits with original maturities of three months or more.

[0000080420-22-000036:notes:159]
Other Assets and Deferred Compensation – We hold investments in an irrevocable Rabbi Trust for our deferred compensation plan. The assets are primarily related to company-owned life insurance policies and are included in other assets in the accompanying Consolidated Balance Sheets. Because the mutual funds and company-owned life insurance policies are combined in the plan, they are therefore categorized as Level 2 in the fair value measurement hierarchy. The deferred compensation liability represents the investment options that the plan participants have designated to serve as the basis for measurement of the notional value of their accounts. Because the deferred compensation liability is intended to offset the plan assets, it is also categorized as Level 2 in the fair value measurement hierarchy.

[0000080420-22-000036:notes:160]
There were no transfers between levels within the fair value measurement hierarchy during the year ended September 30, 2022.


## us-gaap:LesseeOperatingLeasesTextBlock

[0000080420-22-000036:notes:161]
Leases
Our leases consist primarily of office and manufacturing space, construction equipment and office equipment. All of our future lease obligations are related to non-cancelable operating leases. The most significant portion of our lease portfolio relates to leases of office and manufacturing facilities in Canada which we no longer occupy. We currently sublease the majority of these Canadian facilities. The following table provides a summary of lease cost components for the years ended September 30, 2022 and 2021, respectively (in thousands):

[0000080420-22-000036:notes:162]
| Lease Cost |  | 2022 |  | 2021 |
| Operating lease cost |  | $ | 2,146 |  |  | $ | 2,435 |  |
| Less: sublease income |  | (685) |  |  | (706) |  |
| Variable lease cost(1) |  | 457 |  |  | 443 |  |
| Short-term lease cost(2) |  | 1,643 |  |  | 1,281 |  |
| Total lease cost |  | $ | 3,561 |  |  | $ | 3,453 |  |
| (1) Variable lease cost represents common area maintenance charges related to our Canadian office space lease. |
| (2) Short-term lease cost includes leases and rentals with initial terms of one year or less. |

[0000080420-22-000036:notes:163]
We recognize operating lease assets and operating lease liabilities representing the present value of the remaining lease payments for leases with initial terms greater than twelve months. Leases with initial terms of twelve months or less are not recorded in our Consolidated Balance Sheets. As of September 30, 2022 and 2021, our operating lease assets have been reduced

[0000080420-22-000036:notes:164]
by a lease accrual of $0.1 million and $0.4 million, respectively, related to certain unused facility leases in Canada. The following table provides a summary of the operating lease assets and operating lease liabilities included in our Consolidated Balance Sheets as of September 30, 2022 and 2021, respectively (in thousands):

[0000080420-22-000036:notes:165]
|  |  | September 30, |
| Operating Leases |  | 2022 |  | 2021 |
| Assets: |  |  |  |  |
| Operating lease assets, net |  | $ | 2,179 |  |  | $ | 3,453 |  |
| Liabilities: |  |  |  |  |
| Current operating lease liabilities |  | 1,777 |  |  | 1,415 |  |
| Long-term operating lease liabilities |  | 545 |  |  | 2,413 |  |
| Total lease liabilities |  | $ | 2,322 |  |  | $ | 3,828 |  |

[0000080420-22-000036:notes:166]
The following table provides the maturities of our operating lease liabilities as of September 30, 2022 (in thousands):

[0000080420-22-000036:notes:167]
|  |  | Operating Leases |
| 2023 |  | $ | 1,861 |  |
| 2024 |  | 375 |  |
| 2025 |  | 114 |  |
| 2026 |  | 20 |  |
| 2027 |  | 2 |  |
| Thereafter |  | — |  |
| Total future minimum lease payments |  | $ | 2,372 |  |
| Less: present value discount (imputed interest) |  | (50) |  |
| Present value of lease liabilities |  | $ | 2,322 |  |

[0000080420-22-000036:notes:168]
The weighted average discount rate as of September 30, 2022 was 3.73%. The weighted average remaining lease term was 1.51 years at September 30, 2022.


## us-gaap:SegmentReportingDisclosureTextBlock

[0000080420-22-000036:notes:169]
Segment Information
We manage our business as one reportable operating segment related to the development, design, manufacturing and servicing of custom-engineered equipment and systems for the distribution, control and monitoring of electrical energy.

[0000080420-22-000036:notes:170]
Revenues by country represent sales to unaffiliated customers as determined by the ultimate destination of our products and services, summarized for the last three fiscal years by region in the table below (in thousands):

[0000080420-22-000036:notes:171]
|  | Year Ended September 30, |
|  | 2022 |  | 2021 |  | 2020 |
| United States | $ | 404,973 |  |  | $ | 351,422 |  |  | $ | 397,983 |  |
| Canada | 81,218 |  |  | 68,655 |  |  | 66,064 |  |
| Middle East and Africa | 20,712 |  |  | 26,615 |  |  | 18,162 |  |
| Asia/Pacific | 4,885 |  |  | 8,889 |  |  | 18,079 |  |
| Europe | 17,699 |  |  | 13,027 |  |  | 15,866 |  |
| Mexico, Central and South America | 3,095 |  |  | 1,951 |  |  | 2,345 |  |
| Total revenues | $ | 532,582 |  |  | $ | 470,559 |  |  | $ | 518,499 |  |

[0000080420-22-000036:notes:172]
Long-lived assets by country consist of property, plant and equipment, net of accumulated depreciation and are determined based on the location of the tangible assets, summarized for the last two fiscal years in the table below (in thousands):

[0000080420-22-000036:notes:173]
|  | September 30, |
|  | 2022 |  | 2021 |
| Long-lived assets: |  |  |  |
| United States | $ | 58,531 |  |  | $ | 62,308 |  |
| Canada | 36,381 |  |  | 42,375 |  |
| United Kingdom | 3,716 |  |  | 4,774 |  |
| Total | $ | 98,628 |  |  | $ | 109,457 |  |


## us-gaap:QuarterlyFinancialInformationTextBlock

[0000080420-22-000036:notes:174]
Quarterly Information
The table below sets forth the unaudited consolidated operating results by fiscal quarter for the years ended September 30, 2022 and 2021 (in thousands, except per share data):

[0000080420-22-000036:notes:175]
|  | 2022 Quarters |
|  | First(1) |  | Second |  | Third(2) |  | Fourth(3) |  | 2022 |
| Revenues | $ | 106,569 |  |  | $ | 127,854 |  |  | $ | 135,483 |  |  | $ | 162,676 |  |  | $ | 532,582 |  |
| Gross profit | 13,436 |  |  | 19,083 |  |  | 19,059 |  |  | 33,440 |  |  | 85,018 |  |
| Net income (loss) | (2,846) |  |  | (1,217) |  |  | 9,061 |  |  | 8,739 |  |  | 13,737 |  |
| Earnings (loss) per share: |  |  |  |  |  |  |  |  |  |
| Basic | $ | (0.24) |  |  | $ | (0.10) |  |  | $ | 0.77 |  |  | $ | 0.74 |  |  | $ | 1.16 |  |
| Diluted | $ | (0.24) |  |  | $ | (0.10) |  |  | $ | 0.76 |  |  | $ | 0.73 |  |  | $ | 1.15 |  |
| (1) The results for the first quarter of Fiscal 2022 demonstrated normal seasonality and were negatively impacted by holidays and work schedules compared to other quarterly periods. |
| (2) The results for the third quarter of Fiscal 2022 were positively impacted by the release of a $5.9 million Canadian valuation allowance and a $2.0 million pre-tax gain on the sale of a non-core business within our Canadian operations. |
| (3) The results for the fourth quarter of Fiscal 2022 were positively impacted by a $2.5 million settlement of a claim for cost overruns from prior years related to a U.S. based municipal transit project. |

[0000080420-22-000036:notes:176]
|  | 2021 Quarters |
|  | First(1) |  | Second(1) |  | Third(1) |  | Fourth(2) |  | 2021 |
| Revenues | $ | 106,575 |  |  | $ | 118,716 |  |  | $ | 115,813 |  |  | $ | 129,455 |  |  | $ | 470,559 |  |
| Gross profit | 18,271 |  |  | 17,153 |  |  | 17,167 |  |  | 22,472 |  |  | 75,063 |  |
| Net income (loss) | (364) |  |  | (225) |  |  | (2,041) |  |  | 3,261 |  |  | 631 |  |
| Earnings (loss) per share: |  |  |  |  |  |  |  |  |  |
| Basic | $ | (0.03) |  |  | $ | (0.02) |  |  | $ | (0.17) |  |  | $ | 0.28 |  |  | $ | 0.05 |  |
| Diluted | $ | (0.03) |  |  | $ | (0.02) |  |  | $ | (0.17) |  |  | $ | 0.28 |  |  | $ | 0.05 |  |
| (1) The results for the first quarter of Fiscal 2021 demonstrated normal seasonality and were negatively impacted by holidays and work schedules compared to other quarterly periods. Gross profit decreased during the first three quarters of Fiscal 2021 as compared to Fiscal 2020 due to a decrease in volume, as well as project delays and cancellations of potential projects associated with the global economic impact resulting from the COVID-19 pandemic and associated reduction in demand across our industrial end markets. |
| (2) The results for the fourth quarter of Fiscal 2021 were positively impacted by higher volume and favorable productivity across the service and manufacturing entities. |

[0000080420-22-000036:notes:177]
The sum of the individual earnings per share amounts may not agree with year-to-date earnings per share as each period’s computation is based on the weighted-average number of shares outstanding during the period.


## us-gaap:DisposalGroupsIncludingDiscontinuedOperationsDisclosureTextBlock

[0000080420-22-000036:notes:178]
DivestitureOn June 30, 2022, we sold a non-core, industrial valve repair and servicing business within our Canadian operations and received proceeds of $4.3 million. We recorded a $2.0 million pre-tax gain on this transaction, which has been presented in other income on our Consolidated Statement of Operations for the year ended September 30, 2022.


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0000080420-22-000036:notes:179]
Separation CostsIn response to the COVID-19 pandemic, reductions in oil and gas demand and volatility of commodity prices, we implemented workforce reductions at most of our locations. As a result, we recorded $1.4 million of separation costs in restructuring and other, net on the Consolidated Statement of Operations during the third quarter of Fiscal 2020.


## us-gaap:SubsequentEventsTextBlock

[0000080420-22-000036:notes:180]
Subsequent Event
Quarterly Dividend Declared

[0000080420-22-000036:notes:181]
On November 3, 2022, our Board of Directors declared a quarterly cash dividend on our common stock in the amount of $0.26 per share. The dividend is payable on December 14, 2022 to shareholders of record at the close of business on November 16, 2022.
