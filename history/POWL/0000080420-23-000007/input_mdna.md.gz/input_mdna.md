# POWL MD&A — 0000080420-23-000007


## mdna

[0000080420-23-000007:mdna:1]
[same as prior period, unchanged from 0000080420-22-000032:mdna:1]

[0000080420-23-000007:mdna:2]
The following discussion and analysis of our financial condition and results of operations should be read in conjunction with the accompanying condensed consolidated financial statements and related notes included elsewhere in this Quarterly Report on Form 10-Q and with our Annual Report on Form 10-K for the year ended September 30, 2022, which was filed with the Securities and Exchange Commission (SEC) on December 6, 2022 and is available on the SEC’s website at www.sec.gov.

[0000080420-23-000007:mdna:3]
[same as prior period, unchanged from 0000080420-22-000032:mdna:3]

[0000080420-23-000007:mdna:4]
We develop, design, manufacture and service custom-engineered equipment and systems which (1) distribute, control and monitor the flow of electrical energy and (2) provide protection to motors, transformers and other electrically powered equipment. We are headquartered in Houston, Texas, and serve the oil and gas and petrochemical markets, which include onshore and offshore production, liquefied natural gas (LNG) facilities and terminals, pipelines, refineries and petrochemical plants. Additional markets include electric utility and light rail traction power as well as mining and metals, pulp and paper and other municipal, commercial and other industrial markets. Revenues and costs are primarily related to custom engineered-to-order equipment and systems and are accounted for under percentage-of-completion accounting, which precludes us from providing detailed price and volume information. Our backlog includes various projects that typically take a number of months to produce.

[0000080420-23-000007:mdna:5]
The markets in which we participate are capital-intensive and cyclical in nature. Cyclicality is predominantly driven by customer demand, global economic and geopolitical conditions and anticipated environmental, safety or regulatory changes that affect the manner in which our customers proceed with capital investments. Our customers analyze various factors, including the demand and price for oil, gas and electrical energy, the overall economic and financial environment, governmental budgets, regulatory actions and environmental concerns. These factors influence the release of new capital projects by our customers, which are traditionally awarded in competitive bid situations. Scheduling of projects is matched to customer requirements, and projects typically take a number of months to produce. Schedules may change during the course of any particular project, and our operating results can, therefore, be impacted by factors outside of our control.

[0000080420-23-000007:mdna:6]
[same as prior period, unchanged from 0000080420-22-000032:mdna:6]

[0000080420-23-000007:mdna:7]
One element of our strategic focus is to diversify our project portfolio outside of our core oil, gas and petrochemical end market sectors. These efforts over the past year led to a record backlog of projects coming into Fiscal 2023. Over the past few years, there has been an increase in capital spending within North America on LNG facilities as the market responds to the increased international demand for LNG and processes utilizing gas feedstocks. As a result, the business has been awarded a few large contracts that have had a positive impact on our backlog. The substantial contract we were awarded in Fiscal 2020 will be fully completed in the next few months. Additionally, diversification efforts outside of our core oil, gas and petrochemical end markets have resulted in an increase in backlog across the utility and commercial and other industrial sectors as well.

[0000080420-23-000007:mdna:8]
Impact of Global Economic Uncertainty and Commodity Market Volatility on Powell

[0000080420-23-000007:mdna:9]
Various factors resulting in global economic uncertainty have negatively impacted our results over the past two years. Uncertainty and demand disruptions have resulted in considerable volatility across commodity markets. Although global oil prices have rebounded, the major oil and gas producers have responded with modest increases in capital expenditures. Additionally, we continue to experience supply chain disruptions driven predominately by availability and cost volatility across our raw materials, components and labor force. All of these factors have contributed to the lower margins realized in Fiscal 2022 and may continue to impact margins in Fiscal 2023. As we address disruptions and increased costs, we continue to work with our suppliers of key components and commodities to ensure that we are able to meet our customer commitments. Additionally, we have adjusted our pricing models with our customers in response to the increased cost environment.

[0000080420-23-000007:mdna:10]
As discussed further under the heading "Outlook" below, it is difficult to predict the economic impact that this global economic uncertainty, as well as commodity price volatility, may have on our business, results of operations and cash flows going forward.

[0000080420-23-000007:mdna:11]
[same as prior period, unchanged from 0000080420-22-000032:mdna:12]

[0000080420-23-000007:mdna:12]
Quarter Ended December 31, 2022 Compared to the Quarter Ended December 31, 2021 (Unaudited)

[0000080420-23-000007:mdna:13]
[same as prior period, unchanged from 0000080420-22-000032:mdna:14]

[0000080420-23-000007:mdna:14]
Revenues increased by 19%, or $20.3 million, to $126.9 million in the first quarter of Fiscal 2023, primarily driven by the increase in project backlog at the beginning of Fiscal 2023. Backlog increased 43% to $592.2 million at September 30, 2022 compared to September 30, 2021. Domestic revenues increased by 22%, or $18.0 million, to $100.1 million in the first quarter of Fiscal 2023. Included in our domestic oil and gas sector revenues is the large domestic industrial project awarded in Fiscal 2020, which accounted for approximately 13% of our consolidated revenues for the first quarter of Fiscal 2023 compared to 19% in the same period in the prior year. International revenues increased by 10%, or $2.3 million, to $26.8 million in the first quarter of Fiscal 2023. Our international revenues include both revenues generated from our international facilities as well as revenues from export projects generated at our domestic facilities.

[0000080420-23-000007:mdna:15]
Revenue from our core oil and gas markets (excluding petrochemical) increased by 1%, or $0.5 million, to $43.5 million in the first quarter of Fiscal 2023, while petrochemical revenue increased by 31%, or $5.3 million, to $22.5 million in the first quarter of Fiscal 2023. Revenue from our utility markets increased by 32%, or $6.9 million, to $28.4 million in the first quarter of Fiscal 2023. Commercial and other industrial market revenue increased by 202%, or $11.4 million, to $17.1 million, driven by an increase in traditionally non-core markets such as data centers, university projects and other miscellaneous applications. Revenue from all other markets combined increased by 7%, or $0.6 million, to $8.3 million in the first quarter of Fiscal 2023. These increases in revenue were driven by improved market conditions and our strategic effort to diversify our business. Revenue from our traction market decreased by 38%, or $4.3 million, to $7.1 million in the first quarter of Fiscal 2023.

[0000080420-23-000007:mdna:16]
Gross profit increased by 45%, or $6.0 million, to $19.5 million for the first quarter of Fiscal 2023.  Gross profit as a percentage of revenues increased to 15% in the first quarter of Fiscal 2023, compared to 13% in the first quarter of Fiscal 2022. The increase in gross profit was directly attributable to the increase in revenues and the increase in gross profit as a percentage of revenues was driven by the increased volume and related efficiencies, pricing initiatives and continued project execution.

[0000080420-23-000007:mdna:17]
[same as prior period, unchanged from 0000080420-22-000032:mdna:18]

[0000080420-23-000007:mdna:18]
Selling, general and administrative expenses increased by 6%, or $1.0 million, to $16.9 million in the first quarter of Fiscal 2023, primarily due to increased variable incentive compensation and travel-related expenses. Selling, general and administrative expenses as a percentage of revenues decreased to 13% during the first quarter of Fiscal 2023 compared to 15% during the first quarter of Fiscal 2022, primarily due to increased revenues.

[0000080420-23-000007:mdna:19]
[same as prior period, unchanged from 0000080420-22-000032:mdna:22]

[0000080420-23-000007:mdna:20]
We recorded an income tax provision of $0.5 million in the first quarter of Fiscal 2023, compared to an income tax benefit of $1.4 million in the first quarter of Fiscal 2022. For each of the three months ended December 31, 2022 and December 31, 2021, the effective tax rate was favorably impacted by the estimated Research and Development Tax Credit (R&D Tax Credit), partially offset by discrete items primarily related to the vesting of restricted stock units. In addition, the first quarter of Fiscal 2022 was also impacted by a valuation allowance that prohibited the recognition of certain non-U.S. tax losses.

[0000080420-23-000007:mdna:21]
[same as prior period, unchanged from 0000080420-22-000032:mdna:24]

[0000080420-23-000007:mdna:22]
In the first quarter of Fiscal 2023, we recorded net income of $1.2 million, or $0.10 per diluted share, compared to a net loss of $2.8 million, or $0.24 per diluted share, in the first quarter of Fiscal 2022. This increase in net income was primarily due to the increase in bookings which led to an increase in revenues.

[0000080420-23-000007:mdna:23]
[same as prior period, unchanged from 0000080420-22-000032:mdna:26]

[0000080420-23-000007:mdna:24]
The order backlog at December 31, 2022 was $679.8 million, an increase of 15% from $592.2 million at September 30, 2022 and an increase of 63% from $416.0 million at December 31, 2021. Bookings, net of cancellations and scope reductions, increased by 97% in the first quarter of Fiscal 2023 to $211.8 million, compared to $107.7 million in the first quarter of Fiscal 2022, primarily driven by improved strength across our core oil, gas and petrochemical market sectors.

[0000080420-23-000007:mdna:25]
[same as prior period, unchanged from 0000080420-22-000032:mdna:43]

[0000080420-23-000007:mdna:26]
As noted in "Overview" above, the markets in which we participate are capital-intensive and cyclical in nature. A significant portion of our revenues has historically been from the oil, gas and petrochemical markets. Oil and gas commodity price levels can be volatile and our customers have in certain cases delayed or cancelled some of their major capital investment projects due to price volatility and changes in return expectations. We have been strategically focusing on diversification of our project portfolio to expand outside of our core oil, gas and petrochemical end market sectors. Recently we have seen increased global demand for cleaner-burning fuels as well as related processes utilizing gas feedstocks. As a result, the business has been awarded a few large contracts that have had a positive impact on our backlog. The substantial contract we were awarded in Fiscal 2020 will be fully completed in the next few months. Additionally, diversification efforts outside of our core oil, gas and petrochemical end markets have resulted in an increase in backlog across the utility and commercial and other industrial sectors as well.

[0000080420-23-000007:mdna:27]
Our operating results are impacted by factors such as the timing of new order awards, project backlog, customer approval of final engineering and design specifications and delays in customer construction schedules, all of which contribute to short-term earnings variability and the timing of project execution. Our operating results also have been, and may continue to be, impacted by the timing and resolution of change orders, project close-out and resolution of potential contract claims and liquidated damages, all of which could improve or deteriorate gross margins during the period in which these items are resolved with our customers. Disruption in the global supply chain has negatively impacted our business and operating results as well due to the reduction in availability and uncertainty in the timing of the receipt of certain key component parts and commodities. These factors may result in periods of underutilization of our resources and facilities, which may negatively impact our ability to cover our fixed costs, or inhibit our ability to deliver completed products on time. Additionally, the increases in commodity and component costs from projects awarded in prior years and increased labor costs may have a negative impact on our operating results in the event that we are not able to pass these cost increases to our customers. Considering the long cycle nature of our business, we are exposed to cyclical conditions in our business. We will continue to remain focused on the variables that impact our markets as well as cost management, labor and supply chain challenges. We will also continue to adjust to the global conditions in order to maintain competitive cost and technological advantages in the markets that we serve.

[0000080420-23-000007:mdna:28]
[same as prior period, unchanged from 0000080420-22-000032:mdna:47]

[0000080420-23-000007:mdna:29]
As of December 31, 2022, current assets exceeded current liabilities by 1.9 times.

[0000080420-23-000007:mdna:30]
Cash, cash equivalents and short-term investments decreased to $110.7 million at December 31, 2022, compared to $116.5 million at September 30, 2022. This decrease in cash was primarily driven by the payment of variable incentive compensation during the quarter. We believe that our strong working capital position, available borrowings under our credit facility and available cash should be sufficient to finance future operating activities, capital improvements and research and development initiatives for the foreseeable future.

[0000080420-23-000007:mdna:31]
We have a credit agreement with Bank of America, N.A. (as amended, the "U.S. Revolver") which is a $75.0 million revolving credit facility available for both borrowings and letters of credit and expires September 27, 2024. The U.S. Revolver states that up to $30 million may be deducted from the amount of letters of credit outstanding (not to be less than zero) when calculating the consolidated funded indebtedness, which is a component of the consolidated net leverage ratio. Additionally, we have the option to cash collateralize all or a portion of the letters of credit outstanding, which would favorably impact the consolidated funded indebtedness calculation and the consolidated net leverage ratio.

[0000080420-23-000007:mdna:32]
As of December 31, 2022, there were no amounts borrowed under the U.S. Revolver, and letters of credit outstanding were $33.8 million. As of December 31, 2022, $41.2 million was available for the issuance of letters of credit and borrowing under the U.S. Revolver. We are required to maintain certain financial covenants, the most significant of which are a consolidated net leverage ratio of less than 3.0 to 1.0 and a consolidated interest coverage ratio of greater than 3.0 to 1.0. Our most restrictive covenant, the consolidated net leverage ratio, is the ratio of earnings before interest, taxes, depreciation, amortization and stock-based compensation (EBITDAS) to funded indebtedness, which includes letters of credit. An increase in indebtedness or a decrease in EBITDAS could restrict our ability to issue letters of credit or borrow under the U.S. Revolver. For further information regarding our debt, see Notes E and F of Notes to Condensed Consolidated Financial Statements.

[0000080420-23-000007:mdna:33]
Approximately $26.2 million of our cash, cash equivalents and short-term investments at December 31, 2022 was held outside of the U.S. for our international operations. It is our intention to indefinitely reinvest all current and future foreign earnings

[0000080420-23-000007:mdna:34]
internationally in order to ensure sufficient working capital to support our international operations. In the event that we elect to repatriate some or all of the foreign earnings that were previously deemed to be indefinitely reinvested outside the U.S., we may incur additional tax expense upon such repatriation under current tax laws.

[0000080420-23-000007:mdna:35]
[same as prior period, unchanged from 0000080420-22-000032:mdna:53]

[0000080420-23-000007:mdna:36]
Operating activities used net cash of $0.5 million during the three months ended December 31, 2022 and $27.8 million during the same period in Fiscal 2022. Cash flow from operations is primarily influenced by the timing of milestone payments from our customers, project volume and the associated working capital requirements, as well as payment terms with our suppliers. This increase in operating cash flow was primarily due to the timing of contract billing milestones and the increase in accounts receivable, partially offset by the decrease in accounts payable.

[0000080420-23-000007:mdna:37]
[same as prior period, unchanged from 0000080420-22-000032:mdna:55]

[0000080420-23-000007:mdna:38]
Investing activities provided $1.0 million during the three months ended December 31, 2022 and used $4.4 million during the same period in Fiscal 2022. The increase in cash provided by investing activities in the first quarter of Fiscal 2023 is due to the increase in short-term investment maturities.

[0000080420-23-000007:mdna:39]
[same as prior period, unchanged from 0000080420-22-000032:mdna:57]

[0000080420-23-000007:mdna:40]
Net cash used in financing activities was $3.5 million during the three months ended December 31, 2022 and $4.1 million during the same period in Fiscal 2022, which primarily consisted of approximately $3.0 million of dividends paid in each period.

[0000080420-23-000007:mdna:41]
[same as prior period, unchanged from 0000080420-22-000032:mdna:59]

[0000080420-23-000007:mdna:42]
[same as prior period, unchanged from 0000080420-22-000032:mdna:60]

[0000080420-23-000007:mdna:43]
There have been no material changes to our critical accounting policies as disclosed in our Annual Report on Form 10-K for the fiscal year ended September 30, 2022, which was filed with the SEC on December 6, 2022.
