# POWL 8-K — 0000080420-23-000004 filed 2023-01-31

## item codes, every 8-K on or before 2023-02-01

- 2023-01-31 0000080420-23-000004 — 2.02, 8.01
- 2022-12-05 0000080420-22-000034 — 2.02, 9.01
- 2022-08-02 0000080420-22-000030 — 2.02, 8.01, 9.01
- 2022-05-13 0000080420-22-000024 — 5.02, 9.01
- 2022-05-03 0000080420-22-000016 — 2.02, 9.01
- 2022-05-03 0000080420-22-000015 — 8.01, 9.01
- 2022-02-17 0000080420-22-000010 — 5.07
- 2022-02-08 0000080420-22-000005 — 2.02, 9.01
- 2022-02-01 0000080420-22-000002 — 8.01, 9.01
- 2021-12-07 0000080420-21-000043 — 2.02, 9.01
- 2021-08-03 0000080420-21-000036 — 2.02, 8.01, 9.01
- 2021-05-04 0000080420-21-000026 — 2.02, 8.01, 9.01
- 2021-03-16 0001193125-21-082878 — 1.01, 2.03, 9.01
- 2021-03-05 0000080420-21-000021 — 5.02, 8.01, 9.01
- 2021-02-26 0000080420-21-000018 — 5.03
- 2021-02-18 0000080420-21-000016 — 5.07
- 2021-02-02 0000080420-21-000010 — 2.02, 8.01, 9.01
- 2020-12-08 0000080420-20-000032 — 2.02, 9.01
- 2020-11-12 0000080420-20-000030 — 8.01, 9.01
- 2020-08-04 0000080420-20-000024 — 2.02, 8.01, 9.01
- 2020-05-05 0000080420-20-000017 — 2.02, 8.01, 9.01
- 2020-02-21 0000080420-20-000008 — 5.07
- 2020-02-04 0000080420-20-000003 — 2.02, 8.01, 9.01
- 2019-12-04 0001193125-19-306243 — 2.02, 9.01
- 2019-11-08 0000080420-19-000032 — 8.01, 9.01
- 2019-10-03 0000080420-19-000030 — 1.01, 2.03
- 2019-09-24 0000080420-19-000028 — 8.01, 9.01
- 2019-08-06 0000080420-19-000022 — 2.02, 8.01, 9.01
- 2019-05-08 0000080420-19-000017 — 5.02, 9.01
- 2019-05-07 0000080420-19-000011 — 2.02, 8.01, 9.01
- 2019-02-22 0001193125-19-048366 — 5.07
- 2019-02-05 0000080420-19-000003 — 2.02, 8.01
- 2018-12-21 0000080420-18-000038 — 5.02, 9.01
- 2018-12-12 0000080420-18-000031 — 2.02
- 2018-11-05 0000080420-18-000029 — 8.01, 9.01
- 2018-11-01 0000080420-18-000027 — 5.02, 8.01, 9.01
- 2018-10-01 0000080420-18-000024 — 5.02
- 2018-08-07 0000080420-18-000020 — 2.02, 8.01
- 2018-05-15 0000080420-18-000016 — 5.02, 8.01
- 2018-05-09 0000080420-18-000011 — 2.02, 8.01
- 2018-02-22 0000080420-18-000009 — 5.07
- 2018-02-06 0000080420-18-000003 — 2.02, 8.01
- 2017-12-27 0001193125-17-379928 — 5.02
- 2017-12-05 0000080420-17-000028 — 2.02, 9.01
- 2017-11-08 0000080420-17-000024 — 8.01, 9.01
- 2017-11-03 0000080420-17-000022 — 5.02
- 2017-08-09 0000080420-17-000017 — 2.02, 8.01
- 2017-06-30 0000080420-17-000014 — 1.01, 9.01
- 2017-05-03 0000080420-17-000006 — 2.02, 8.01, 9.01
- 2017-02-23 0000080420-17-000004 — 5.07
- 2017-02-08 0001628280-17-000965 — 2.02 — amendment of 0001628280-17-000949
- 2017-02-07 0001628280-17-000949 — 2.01, 8.01, 9.01
- 2016-12-07 0001193125-16-787354 — 2.02, 9.01
- 2016-11-01 0001193125-16-755475 — 8.01, 9.01
- 2016-09-30 0001193125-16-726999 — 5.02, 8.01, 9.01
- 2016-08-03 0001193125-16-669308 — 2.02, 8.01, 9.01
- 2016-05-04 0001193125-16-576528 — 2.02, 8.01, 9.01
- 2016-02-25 0001193125-16-477896 — 5.07
- 2016-02-03 0001193125-16-449052 — 2.02, 8.01, 9.01
- 2015-12-31 0001193125-15-418363 — 5.02, 7.01, 9.01
- 2015-12-02 0001193125-15-393109 — 2.02, 9.01
- 2015-11-05 0001193125-15-368085 — 8.01, 9.01
- 2015-09-25 0001193125-15-329031 — 5.02
- 2015-08-05 0001193125-15-277912 — 2.02, 8.01, 9.01
- 2015-05-06 0001193125-15-174291 — 2.02, 8.01, 9.01
- 2015-03-06 0001193125-15-081070 — 5.02
- 2015-03-02 0001193125-15-072946 — 5.07
- 2015-02-03 0001193125-15-031772 — 2.02, 8.01, 9.01
- 2014-12-18 0001193125-14-446513 — 8.01, 9.01
- 2014-12-03 0001193125-14-431745 — 2.02, 9.01
- 2014-11-05 0001193125-14-397955 — 8.01, 9.01
- 2014-09-26 0001193125-14-353741 — 7.01, 9.01
- 2014-08-05 0001193125-14-296001 — 2.02, 8.01, 9.01
- 2014-05-07 0001193125-14-187496 — 2.02, 8.01, 9.01
- 2014-03-03 0001193125-14-079843 — 5.02, 5.07
- 2014-02-05 0001193125-14-036633 — 2.02, 8.01, 9.01
- 2014-01-17 0001193125-14-014351 — 1.01, 8.01, 9.01
- 2014-01-06 0001193125-14-002795 — 1.01, 2.03
- 2013-12-06 0001564590-13-001411 — 2.02, 9.01
- 2013-12-05 0001564590-13-001406 — 5.02, 8.01, 9.01
- 2013-11-07 0001193125-13-432950 — 8.01, 9.01
- 2013-08-07 0001193125-13-324337 — 2.02, 9.01
- 2013-05-08 0001193125-13-206800 — 2.02, 9.01
- 2013-02-22 0001193125-13-070971 — 5.02, 5.07
- 2013-02-06 0001193125-13-040556 — 2.02, 9.01
- 2012-12-18 0001193125-12-506417 — 5.02, 9.01
- 2012-12-05 0001193125-12-491749 — 2.02, 9.01
- 2012-10-12 0001193125-12-421889 — 3.03, 5.02, 5.03, 9.01
- 2012-08-09 0001193125-12-344617 — 5.02, 8.01, 9.01
- 2012-08-08 0001193125-12-343630 — 2.02, 9.01
- 2012-05-09 0001193125-12-221356 — 2.02, 9.01
- 2012-02-08 0001193125-12-046560 — 2.02, 9.01
- 2011-12-08 0001193125-11-334810 — 2.02, 9.01
- 2011-11-08 0000950123-11-096524 — 2.02, 2.06, 4.02, 9.01
- 2011-10-14 0000950123-11-090124 — 5.02
- 2011-10-06 0000950123-11-088969 — 5.02
- 2011-09-19 0000950123-11-085224 — 5.02, 9.01
- 2011-09-15 0000950123-11-084806 — 5.02, 9.01
- 2011-08-04 0000950123-11-072788 — 2.02, 9.01
- 2011-07-22 0000950123-11-067402 — 5.07
- 2011-05-24 0000950123-11-053550 — 1.01, 2.03, 9.01
- 2011-05-04 0000950123-11-044561 — 2.02, 9.01
- 2011-02-02 0000950123-11-008188 — 2.02, 9.01
- 2010-12-08 0000950123-10-111987 — 2.02, 9.01
- 2010-08-05 0000950123-10-073114 — 2.02, 9.01
- 2010-05-18 0000950123-10-050900 — 5.02
- 2010-05-05 0000950123-10-044499 — 2.02, 9.01
- 2010-02-03 0000950123-10-008278 — 2.02, 9.01
- 2009-12-21 0000950123-09-072269 — 1.01, 2.01, 2.03, 8.01, 9.01
- 2009-12-09 0000950123-09-069525 — 2.02, 9.01
- 2009-10-27 0000950123-09-053501 — 1.01, 8.01, 9.01
- 2009-08-04 0000950123-09-029476 — 2.02, 9.01
- 2009-05-06 0000950129-09-001498 — 2.02, 9.01
- 2009-03-05 0000950129-09-000749 — 1.01, 9.01
- 2009-02-10 0000950129-09-000349 — 2.02, 9.01
- 2008-12-10 0000950134-08-021934 — 2.02, 9.01
- 2008-08-06 0000950129-08-004267 — 2.02, 9.01
- 2008-07-24 0000950129-08-004063 — 1.01, 5.02, 8.01, 9.01
- 2008-06-16 0000950129-08-003500 — 9.01 — amendment of 0000950134-06-015374
- 2008-06-05 0000950129-08-003378 — 5.02, 9.01
- 2008-05-08 0000950129-08-002843 — 2.02, 9.01
- 2008-02-06 0000950129-08-000533 — 2.02, 9.01
- 2007-12-19 0000950129-07-006277 — 1.01, 2.03, 9.01
- 2007-12-06 0000950129-07-006003 — 2.02, 9.01
- 2007-08-21 0000950129-07-004181 — 2.02, 9.01
- 2007-05-31 0000950129-07-002810 — 2.02, 9.01
- 2007-05-21 0000950129-07-002668 — 2.02, 3.01, 4.02, 9.01
- 2007-04-16 0000950129-07-002002 — 2.02, 4.02, 9.01
- 2007-03-01 0000950129-07-001104 — 5.02, 8.01, 9.01
- 2007-02-08 0000950129-07-000451 — 2.02, 9.01
- 2006-12-08 0000950129-06-010041 — 2.02, 9.01
- 2006-09-08 0000950129-06-008379 — 2.02, 9.01
- 2006-08-09 0000950134-06-015374 — 1.01, 2.01, 8.01, 9.01
- 2006-06-08 0000950129-06-006127 — 2.02, 9.01
- 2006-03-09 0000950129-06-002455 — 2.02, 9.01
- 2005-12-16 0000950129-05-012031 — 2.02, 5.03, 9.01
- 2005-09-13 0000950129-05-009181 — 2.01, 9.01 — amendment of 0000950129-05-006889
- 2005-09-12 0000950129-05-009151 — 2.02, 9.01
- 2005-07-06 0000950129-05-006889 — 1.01, 1.02, 2.01, 2.03, 9.01
- 2005-06-10 0000950129-05-006128 — 2.02, 9.01
- 2005-04-20 0000080420-05-000031 — 5.02
- 2005-03-11 0000080420-05-000024 — 9.01
- 2005-02-25 0000080420-05-000018 — 7.01, 9.01
- 2005-01-21 0000080420-05-000009 — 7.01, 9.01
- 2004-12-17 0000080420-04-000049 — 2.02, 9.01
- 2004-11-01 0000080420-04-000045 — 8.01, 9.01
- 2004-10-08 0001169232-04-005133 — 2.05
- 2004-09-14 0000080420-04-000037 — 5.02
- 2004-09-02 0000080420-04-000030 — 2.02, 9.01
- 2004-06-08 0000080420-04-000021 — 7
- 2004-05-13 0000080420-04-000019 — 4
- 2004-02-27 0000080420-04-000013 — 7
- 2003-12-16 0000950129-03-006136 — 12, 7
- 2003-08-29 0000950129-03-004531 — 12, 7
- 2003-06-03 0000950129-03-003035 — 7, 9
- 2003-05-15 0000950129-03-002812 — 7, 9
- 2002-05-29 0000950129-02-002795 — 4
- 2000-12-21 0000950129-00-006093 — 5, 7
- 1998-09-04 0000950129-98-003802 — 5
- 1996-08-09 0000950129-96-001705 — 2, 7

## late-filing notifications on or before 2023-02-01

- 2007-05-11 0000950129-07-002494 — NT 10-Q, for the period ended 2007-03-31
- 2005-01-18 0000080420-05-000004 — NT 10-K, for the period ended 2004-10-31

## item 2.02 — earnings release, exhibit 99.1

[0000080420-23-000004:8k_2_02:1]
EX-99.1
2
ex99-1q12023earningsrelease.htm
EX-99.1

[0000080420-23-000004:8k_2_02:2]
Document

[0000080420-23-000004:8k_2_02:3]
Exhibit 99.1

[0000080420-23-000004:8k_2_02:4]
PRESS RELEASE

[0000080420-23-000004:8k_2_02:5]
For Immediate Release    Contacts:    Michael W. Metcalf, CFO

[0000080420-23-000004:8k_2_02:6]
Powell Industries, Inc.

[0000080420-23-000004:8k_2_02:7]
713-947-4422

[0000080420-23-000004:8k_2_02:8]
Robert Winters or Ryan Coleman

[0000080420-23-000004:8k_2_02:9]
Alpha IR Group

[0000080420-23-000004:8k_2_02:10]
POWL@alpha-ir.com

[0000080420-23-000004:8k_2_02:11]
312-445-2870

[0000080420-23-000004:8k_2_02:12]
POWELL INDUSTRIES ANNOUNCES FISCAL 2023 FIRST QUARTER RESULTS

[0000080420-23-000004:8k_2_02:13]
HOUSTON — January 31, 2023 — Powell Industries, Inc. (NASDAQ: POWL), a leading supplier of custom-engineered solutions for the management, control and distribution of electrical energy, today announced results for the fiscal 2023 first quarter ended December 31, 2022. All comparisons are to the comparable period in the prior fiscal year, unless otherwise noted.

[0000080420-23-000004:8k_2_02:14]
Fiscal First Quarter Key Highlights:

[0000080420-23-000004:8k_2_02:15]
•Backlog increased 63% to a record $680 million;

[0000080420-23-000004:8k_2_02:16]
•New orders totaled $212 million, an increase of $104 million;

[0000080420-23-000004:8k_2_02:17]
•Revenues totaled $127 million, an increase of 19%;

[0000080420-23-000004:8k_2_02:18]
•Book-to-bill ratio of 1.7x marked the fifth consecutive quarter above 1.0x;

[0000080420-23-000004:8k_2_02:19]
•Net Income was $1 million, or $0.10 per diluted share;

[0000080420-23-000004:8k_2_02:20]
•Cash and short-term investments as of December 31, 2022, totaled $111 million.

[0000080420-23-000004:8k_2_02:21]
Brett A. Cope, Powell’s Chairman and Chief Executive Officer, stated, “We are pleased with the start of our fiscal year in what is typically our seasonally slower quarter. Our gross margin performance of 15.3% marked a strong year-over-year improvement, while the $212 million of new orders in the period drove a book-to-bill ratio of 1.7x – the highest since our second quarter of fiscal 2020. Our strategic efforts to diversify the business and improve its long-term earnings profile also continue to yield tangible near-term wins. The Commercial and Other Industrial sector – which includes end markets where Powell has not historically focused – recorded revenue that roughly tripled compared to the first quarter last year. We are confident that the positive transformational steps being taken internally at the Company, supported by improving conditions across our core end markets, will drive another strong year for Powell.”

[0000080420-23-000004:8k_2_02:22]
Revenues for the first fiscal quarter totaled $126.9 million, an increase of 19% compared to $106.6 million in the prior year, and compares to fiscal fourth quarter revenue of $162.7 million.

[0000080420-23-000004:8k_2_02:23]
Gross profit in the quarter totaled $19.5 million, an increase of $6 million compared to the prior year. Gross margin in the period increased 270 basis points to 15.3% compared to 12.6% in the prior year.

[0000080420-23-000004:8k_2_02:24]
New orders placed in the first quarter nearly doubled to $212 million compared to $108 million of net new orders in the prior year and compared to $259 million in the fiscal fourth quarter.

[0000080420-23-000004:8k_2_02:25]
Backlog as of December 31, 2022 totaled a record $680 million compared to $592 million as of September 30, 2022, which represents sequential growth of 15%, and compares to $416 million at the end of the fiscal first quarter in the prior year.

[0000080420-23-000004:8k_2_02:26]
Net income in the fiscal first quarter was $1.2 million, or $0.10 per diluted share, compared to a net loss of $2.8 million, or a loss of $0.24 per diluted share, in the prior year, and compared to net income of $8.7 million dollars, or $0.73 per diluted share, in the fiscal fourth quarter. The net income in the fiscal fourth quarter included an after-tax gain of $2.0 million, or $0.17 per diluted share, resulting from the favorable cost recovery attributable to a prior year municipal project.

[0000080420-23-000004:8k_2_02:27]
Cope added, “Activity in our core Oil, Gas & Petrochemical markets continues to strengthen, as we booked another large industrial order to support the domestic production of Liquefied Natural Gas.  Meanwhile, market conditions across our Utility, Commercial and Other Industrial sectors remain robust and are largely supported by steady volume of small to mid-sized project activity. Our current record backlog of $680 million provides a diverse mix of project activity that will help to facilitate margin and earnings growth as we focus on executing these projects in fiscal 2023, while continuing to build our backlog supporting fiscal 2024 and beyond.”

[0000080420-23-000004:8k_2_02:28]
OUTLOOK

[0000080420-23-000004:8k_2_02:29]
Commenting on the Company's outlook, Michael Metcalf, Powell’s Chief Financial Officer said, “We remain very encouraged by the continued commercial success that we have experienced across most of our core end markets – specifically in our core Industrial and Utility end markets – and we are optimistic that this momentum will continue.  This, combined with the level and quality of our backlog, our continued focus on accretive margin initiatives, as well as the strength of our balance sheet, positions Powell to deliver both revenue and earnings growth in fiscal 2023.”

[0000080420-23-000004:8k_2_02:30]
CONFERENCE CALL

[0000080420-23-000004:8k_2_02:31]
3

[0000080420-23-000004:8k_2_02:32]
Powell Industries has scheduled a conference call for Wednesday, February 1, 2023, at 11:00 a.m. Eastern time.   To participate in the conference call, dial 1-833-953-2431 (domestic) or 1-412-317-5760 (international) and ask for the Powell Industries conference call.  A telephonic replay of the conference call will be available through February 8, 2023 and may be accessed by calling 1-877-344-7529 (domestic) or 1-412-317-0088 (international) and using passcode 3237665#.

[0000080420-23-000004:8k_2_02:33]
Investors, analysts and the general public will also have the opportunity to listen to the conference call over the Internet by visiting powellind.com. To listen to the live call on the web, please visit the website at least 15 minutes before the call begins to register, download and install any necessary audio software.  For those who cannot listen to the live webcast, an archive will be available shortly after the call and will remain available for approximately 90 days at powellind.com.

[0000080420-23-000004:8k_2_02:34]
Powell Industries, Inc., headquartered in Houston, designs, manufactures and services custom-engineered equipment and systems for the distribution, control and monitoring of electrical energy.  Powell markets include large industrial customers such as utilities, oil and gas producers, refineries, liquefied natural gas facilities, petrochemical plants, pulp and paper producers, mining operations and commuter railways.   For more information, please visit powellind.com.

[0000080420-23-000004:8k_2_02:35]
the Securities and Exchange Commission, copies of which are available from the Company without charge.

[0000080420-23-000004:8k_2_02:36]
5

[0000080420-23-000004:8k_2_02:37]
POWELL INDUSTRIES, INC. & SUBSIDIARIES

[0000080420-23-000004:8k_2_02:38]
CONDENSED CONSOLIDATED STATEMENT OF OPERATIONS

[0000080420-23-000004:8k_2_02:39]
|  | Three Months Ended December 31, |  |  |
|  | 2022 |  | 2021 |  |  |  |  |
| (In thousands, except per share data) |  |  |  |  |  |  |  |
|  | (Unaudited) |  |  |  |  |
| Revenues | $ | 126,858 |  |  | $ | 106,569 |  |  |  |  |  |
| Cost of goods sold | 107,394 |  |  | 93,133 |  |  |  |  |  |
| Gross profit | 19,464 |  | 13,436 |  |  |  |  |
| Selling, general and administrative expenses | 16,873 |  |  | 15,902 |  |  |  |  |  |
| Research and development expenses | 1,501 |  |  | 1,824 |  |  |  |  |  |
| Operating income (loss) | 1,090 |  |  | (4,290) |  |  |  |  |  |
| Interest income, net | (523) |  |  | (3) |  |  |  |  |  |
| Income (loss) before income taxes | 1,613 |  |  | (4,287) |  |  |  |  |  |
| Income tax provision (benefit) | 451 |  |  | (1,441) |  |  |  |  |  |
| Net income (loss) | $ | 1,162 |  |  | $ | (2,846) |  |  |  |  |  |
| Earnings (loss) per share: |  |  |  |  |  |  |  |
| Basic | $ | 0.10 |  |  | $ | (0.24) |  |  |  |  |  |
| Diluted | $ | 0.10 |  |  | $ | (0.24) |  |  |  |  |  |
| Weighted average shares: |  |  |  |  |  |  |  |
| Basic | 11,859 |  |  | 11,765 |  |  |  |  |  |
| Diluted | 12,077 |  |  | 11,765 |  |  |  |  |  |
| SELECTED FINANCIAL DATA: |  |  |  |  |  |  |  |
| Depreciation and Amortization | $ | 2,136 |  |  | $ | 2,414 |  |  |  |  |  |
| Capital Expenditures | $ | 2,726 |  |  | $ | 436 |  |  |  |  |  |
| Dividends Paid | $ | 3,074 |  |  | $ | 3,048 |  |  |  |  |  |

[0000080420-23-000004:8k_2_02:40]
6

[0000080420-23-000004:8k_2_02:41]
POWELL INDUSTRIES, INC. & SUBSIDIARIES

[0000080420-23-000004:8k_2_02:42]
CONDENSED CONSOLIDATED BALANCE SHEETS

[0000080420-23-000004:8k_2_02:43]
|  | December 31, 2022 |  | September 30, 2022 |
| (In thousands) | (Unaudited) |
| Assets: |  |  |  |
| Cash, cash equivalents and short-term investments | $ | 110,702 |  |  | $ | 116,508 |  |
| Other current assets | 278,542 |  |  | 253,475 |  |
| Property, plant and equipment, net | 99,051 |  |  | 98,628 |  |
| Long-term assets | 25,377 |  |  | 24,769 |  |
| Total assets | $ | 513,672 |  |  | $ | 493,380 |  |
| Liabilities and equity: |  |  |  |
| Current liabilities | $ | 203,774 |  |  | $ | 186,373 |  |
| Deferred and other long-term liabilities | 11,426 |  | 9,801 |
| Stockholders’ equity | 298,472 |  |  | 297,206 |  |
| Total liabilities and stockholders’ equity | $ | 513,672 |  |  | $ | 493,380 |  |
| SELECTED FINANCIAL DATA: |  |  |  |
| Working capital | $ | 185,470 |  |  | $ | 183,610 |  |
