# POWL notes — 0000080420-23-000007


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureAndSignificantAccountingPoliciesTextBlock

[0000080420-23-000007:notes:1]
[same as prior period, unchanged from 0000080420-22-000032:notes:1]

[0000080420-23-000007:notes:2]
Powell Industries, Inc. (we, us, our, Powell or the Company) is incorporated in the state of Delaware. Powell's predecessor companies were founded 76 years ago by William E. Powell in 1947. Our major subsidiaries, all of which are wholly owned, include Powell Electrical Systems, Inc.; Powell (UK) Limited; Powell Canada Inc.; and Powell Industries International, B.V.

[0000080420-23-000007:notes:3]
We develop, design, manufacture and service custom-engineered equipment and systems that (1) distribute, control and monitor the flow of electrical energy and (2) provide protection to motors, transformers and other electrically powered equipment. We are headquartered in Houston, Texas and serve the oil and gas and petrochemical markets, which include onshore and offshore production, liquefied natural gas (LNG) facilities and terminals, pipelines, refineries and petrochemical plants. Additional markets include electric utility, light rail traction power as well as mining and metals, pulp and paper and other municipal, commercial and other industrial markets.

[0000080420-23-000007:notes:4]
[same as prior period, unchanged from 0000080420-22-000032:notes:7]

[0000080420-23-000007:notes:5]
These unaudited condensed consolidated financial statements include the accounts of Powell and our wholly-owned subsidiaries. All significant intercompany accounts and transactions have been eliminated in consolidation.

[0000080420-23-000007:notes:6]
[same as prior period, unchanged from 0000080420-22-000032:notes:9]

[0000080420-23-000007:notes:7]
These unaudited condensed consolidated financial statements should be read in conjunction with the audited consolidated financial statements and notes thereto of Powell and its subsidiaries included in Powell’s Annual Report on Form 10-K for the year ended September 30, 2022, which was filed with the Securities and Exchange Commission (SEC) on December 6, 2022.

[0000080420-23-000007:notes:8]
References to Fiscal 2023 and Fiscal 2022 used throughout this report shall mean the current fiscal year ending September 30, 2023 and the prior fiscal year ended September 30, 2022, respectively.

[0000080420-23-000007:notes:9]
Use of Estimates
The preparation of condensed consolidated financial statements in conformity with U.S. GAAP requires management to make estimates and assumptions that affect the amounts reported in the condensed consolidated financial statements and accompanying footnotes. The most significant estimates used in our condensed consolidated financial statements affect revenue recognition and estimated cost recognition on our customer contracts, the allowance for credit losses, provision for excess and obsolete inventory, warranty accruals and income taxes. The amounts recorded for warranties, legal, income taxes, impairment of long-lived assets (when applicable), liquidated damages and other contingent liabilities require judgments regarding the amount of expenses that will ultimately be incurred. We base our estimates on historical experience, forecasts and various other assumptions, as well as the specific circumstances surrounding these contingent liabilities, in evaluating the amount of liability that should be recorded. Additionally, the recognition of deferred tax assets requires estimates related to future income and other assumptions regarding timing and future profitability because the ultimate realization of net deferred tax assets is dependent on the generation of future taxable income during the periods in which temporary differences become deductible. Estimates routinely change as new events occur, additional information becomes available or operating environments change. Actual results may differ from our prior estimates.


## us-gaap:EarningsPerShareTextBlock

[0000080420-23-000007:notes:10]
[same as prior period, unchanged from 0000080420-22-000032:notes:12]

[0000080420-23-000007:notes:11]
[same as prior period, unchanged from 0000080420-22-000032:notes:13]

[0000080420-23-000007:notes:12]
|  | Three months ended December 31, |  |  |
|  | 2022 |  | 2021 |  |  |  |  |
| Numerator: |  |  |  |  |  |  |  |
| Net income (loss) | $ | 1,162 |  |  | $ | (2,846) |  |  |  |  |  |
| Denominator: |  |  |  |  |  |  |  |
| Weighted average basic shares | 11,859 |  |  | 11,765 |  |  |  |  |  |
| Dilutive effect of restricted stock units | 218 |  |  | — |  |  |  |  |  |
| Weighted average diluted shares | 12,077 |  |  | 11,765 |  |  |  |  |  |
| Earnings (loss) per share: |  |  |  |  |  |  |  |
| Basic | $ | 0.10 |  |  | $ | (0.24) |  |  |  |  |  |
| Diluted | $ | 0.10 |  |  | $ | (0.24) |  |  |  |  |  |

[0000080420-23-000007:notes:13]
For the three months ended December 31, 2021, we incurred a net loss and therefore all potential common shares were deemed to be anti-dilutive.


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0000080420-23-000007:notes:14]
Detail of Selected Balance Sheet Accounts
Inventories

[0000080420-23-000007:notes:15]
[same as prior period, unchanged from 0000080420-22-000032:notes:20]

[0000080420-23-000007:notes:16]
|  | December 31, 2022 |  | September 30, 2022 |
| Raw materials, parts and sub-assemblies, net | $ | 53,336 |  |  | $ | 49,213 |  |
| Work-in-progress | 1,666 |  |  | 1,202 |  |
| Total inventories | $ | 55,002 |  |  | $ | 50,415 |  |

[0000080420-23-000007:notes:17]
[same as prior period, unchanged from 0000080420-22-000032:notes:22]

[0000080420-23-000007:notes:18]
[same as prior period, unchanged from 0000080420-22-000032:notes:23]

[0000080420-23-000007:notes:19]
|  | Three months ended December 31, |  |  |
|  | 2022 |  | 2021 |  |  |  |  |
| Balance at beginning of period | $ | 2,345 |  |  | $ | 2,531 |  |  |  |  |  |
| Increase to warranty expense | 479 |  |  | 293 |  |  |  |  |  |
| Deduction for warranty charges | (454) |  |  | (382) |  |  |  |  |  |
| Change due to foreign currency translation | 10 |  |  | 1 |  |  |  |  |  |
| Balance at end of period | $ | 2,380 |  |  | $ | 2,443 |  |  |  |  |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0000080420-23-000007:notes:20]
[same as prior period, unchanged from 0000080420-22-000032:notes:25]

[0000080420-23-000007:notes:21]
Our revenues are primarily generated from the manufacturing of custom-engineered products and systems under long-term fixed-price contracts under which we agree to manufacture various products such as traditional and arc-resistant distribution switchgear and control gear, medium-voltage circuit breakers, monitoring and control communications systems, motor control

[0000080420-23-000007:notes:22]
centers, switches and bus duct systems. These products may be sold separately as an engineered solution but are typically integrated into custom-built enclosures which we also build. These enclosures are referred to as power control room substations (PCRs®), custom-engineered modules or electrical houses (E-Houses). Some contracts may also include the installation and the commissioning of these enclosures.

[0000080420-23-000007:notes:23]
Revenue from these contracts is generally recognized over time utilizing the cost-to-cost method. Under the cost-to-cost method, the extent of progress towards completion is measured based on the ratio of costs incurred to date to the total estimated costs at completion of the performance obligation. We believe that this method is the most accurate representation of our performance because it directly measures the value of the services transferred to the customer over time as we incur costs on our contracts. Contract costs include all direct materials, labor and indirect costs related to contract performance, which may include indirect labor, supplies, tools, repairs and depreciation costs.

[0000080420-23-000007:notes:24]
We also have contracts to provide field service inspection, installation, commissioning, modification, and repair services, as well as retrofit and retrofill components for existing systems. If the service contract terms give us the right to invoice the customer for an amount that corresponds directly with the value of our performance completed to date (i.e., a service contract in which we bill a fixed amount for each hour of service provided), then we recognize revenue over time in each reporting period corresponding to the amount with which we have the right to invoice. Our performance obligations are satisfied as the work progresses. Revenues from our custom-engineered products and value-added services transferred to customers over time accounted for approximately 93% of total revenues for the three months ended December 31, 2022 and 94% of total revenues for the three months ended December 31, 2021.

[0000080420-23-000007:notes:25]
We also have sales orders for spare parts and replacement circuit breakers for switchgear that are obsolete or that are no longer produced by the original manufacturer. Revenues from these sales orders are recognized at the time we fulfill our performance obligation to the customer, which is typically upon shipment and represented approximately 7% of total revenues for the three months ended December 31, 2022 and 6% of total revenues for the three months ended December 31, 2021.

[0000080420-23-000007:notes:26]
Additionally, some contracts may contain a cancellation clause that could limit the amount of revenue we are able to recognize over time. In these instances, revenue and costs associated with these contracts are deferred and recognized at a point in time when the performance obligation is fulfilled.

[0000080420-23-000007:notes:27]
[same as prior period, unchanged from 0000080420-22-000032:notes:31]

[0000080420-23-000007:notes:28]
[same as prior period, unchanged from 0000080420-22-000032:notes:32]

[0000080420-23-000007:notes:29]
A performance obligation is a promise in a contract or with a customer to transfer a distinct good or service. A contract’s transaction price is allocated to each distinct performance obligation and recognized as revenue as the performance obligations are satisfied. To determine the proper revenue recognition for contracts, we evaluate whether a contract should be accounted for as more than one performance obligation or, less commonly, whether two or more contracts should be combined and accounted for as one performance obligation. This evaluation of performance obligations requires significant judgment. The majority of our contracts have a single performance obligation where multiple engineered products and services are combined into a single custom-engineered solution. Our contracts include a standard one-year assurance warranty. Occasionally, we provide service-type warranties that will extend the warranty period. These extended warranties qualify as a separate performance obligation, and revenue is deferred and recognized over the warranty period. If we determine during the evaluation of the contract that there are multiple performance obligations, we allocate the transaction price to each performance obligation using our best estimate of the standalone selling price of each distinct good or service in the contract.

[0000080420-23-000007:notes:30]
Remaining unsatisfied performance obligations, which we refer to as backlog, represent the estimated transaction price for goods and services for which we have a material right, but work has not been performed. As of December 31, 2022, we had backlog of $679.8 million, of which approximately $464.2 million is expected to be recognized as revenue within the next twelve months. Backlog may not be indicative of future operating results as orders may be cancelled or modified by our customers. Our backlog does not include service and maintenance-type contracts for which we have the right to invoice as services are performed.

[0000080420-23-000007:notes:31]
[same as prior period, unchanged from 0000080420-22-000032:notes:35]

[0000080420-23-000007:notes:32]
Actual revenues and project costs may vary from previous estimates due to changes in a variety of factors. The cost estimation process is based upon the professional knowledge and experience of our engineers, project managers and financial

[0000080420-23-000007:notes:33]
professionals. Factors that are considered in estimating the work to be completed and ultimate contract recovery include the availability and productivity of labor, the nature and complexity of the work to be performed, the availability of materials, and the effect of any delays on our project performance. We periodically review our job performance, job conditions, estimated profitability and final contract settlements, including our estimate of total costs and make revisions to costs and income in the period in which the revisions are probable and reasonably estimable. We bear the risk of cost overruns in most of our contracts, which may result in reduced profits. Whenever revisions of estimated contract costs and contract values indicate that the contract costs will exceed estimated revenues, thus creating a loss, a provision for the total estimated loss is recorded in that period.

[0000080420-23-000007:notes:34]
For the three months ended December 31, 2022 and 2021, our operating results were positively impacted by $3.6 million and $2.8 million, respectively, as a result of changes in contract estimates related to projects in progress at the beginning of the respective period. These changes in estimates resulted primarily from favorable project execution and negotiations of variable consideration, discussed below, as well as revenue and reduced costs recognized from project cancellations and other changes in facts and circumstances during these periods.

[0000080420-23-000007:notes:35]
[same as prior period, unchanged from 0000080420-22-000032:notes:38]

[0000080420-23-000007:notes:36]
[same as prior period, unchanged from 0000080420-22-000032:notes:39]

[0000080420-23-000007:notes:37]
[same as prior period, unchanged from 0000080420-22-000032:notes:40]

[0000080420-23-000007:notes:38]
[same as prior period, unchanged from 0000080420-22-000032:notes:41]

[0000080420-23-000007:notes:39]
[same as prior period, unchanged from 0000080420-22-000032:notes:42]

[0000080420-23-000007:notes:40]
[same as prior period, unchanged from 0000080420-22-000032:notes:43]

[0000080420-23-000007:notes:41]
[same as prior period, unchanged from 0000080420-22-000032:notes:44]

[0000080420-23-000007:notes:42]
[same as prior period, unchanged from 0000080420-22-000032:notes:45]

[0000080420-23-000007:notes:43]
[same as prior period, unchanged from 0000080420-22-000032:notes:46]

[0000080420-23-000007:notes:44]
Contract assets and liabilities as of December 31, 2022 and September 30, 2022 are summarized below (in thousands):

[0000080420-23-000007:notes:45]
|  | December 31, 2022 |  | September 30, 2022 |
| Contract assets | $ | 63,911 |  |  | $ | 88,351 |  |
| Contract liabilities | (133,753) |  |  | (79,857) |  |
| Net contract asset (liability) | $ | (69,842) |  |  | $ | 8,494 |  |

[0000080420-23-000007:notes:46]
Our net contract billing position improved to a net liability at December 31, 2022 from a net asset position at September 30, 2022 primarily due to favorable contract billing milestones. To determine the amount of revenue recognized during the period from contract liabilities, we first allocate revenue to the individual contract liability balance outstanding at the beginning of the

[0000080420-23-000007:notes:47]
period until the revenue exceeds that balance. During the three months ended December 31, 2022, we recognized revenue of approximately $36.4 million that was related to contract liabilities outstanding at September 30, 2022.

[0000080420-23-000007:notes:48]
The timing of our invoice process is typically dependent on the completion of certain milestones and contract terms and subject to agreement by our customer. Payment is typically expected within 30 days of invoice. Any uncollected invoiced amounts for our performance obligations recognized over time, including contract retentions, are recorded as accounts receivable in the Condensed Consolidated Balance Sheets. Certain contracts allow customers to withhold a small percentage of billings pursuant to retainage provisions, and such amounts are generally due upon completion of the contract and acceptance of the project by the customer. Based on our experience in recent years, the majority of these retainage balances are expected to be collected within approximately twelve months. As of December 31, 2022 and September 30, 2022, accounts receivable included retention amounts of $7.2 million and $6.9 million, respectively. Of the retained amount at December 31, 2022, $6.9 million is expected to be collected in the next twelve months and is recorded in accounts receivable. The remaining $0.3 million is recorded in other assets.

[0000080420-23-000007:notes:49]
[same as prior period, unchanged from 0000080420-22-000032:notes:51]

[0000080420-23-000007:notes:50]
The following tables present our disaggregated revenue by geographic destination and market sector for the three months ended December 31, 2022 and 2021 (in thousands):

[0000080420-23-000007:notes:51]
|  | Three months ended December 31, |  |  |
|  | 2022 |  | 2021 |  |  |  |  |
| United States | $ | 100,112 |  |  | $ | 82,145 |  |  |  |  |  |
| Canada | 18,496 |  |  | 15,125 |  |  |  |  |  |
| Europe, Middle East and Africa | 6,559 |  |  | 7,830 |  |  |  |  |  |
| Asia/Pacific | 776 |  |  | 944 |  |  |  |  |  |
| Mexico, Central and South America | 915 |  |  | 525 |  |  |  |  |  |
| Total revenues by geographic destination | $ | 126,858 |  |  | $ | 106,569 |  |  |  |  |  |

[0000080420-23-000007:notes:52]
|  | Three months ended December 31, |  |  |
|  | 2022 |  | 2021 |  |  |  |  |
| Oil and gas (excludes petrochemical) | $ | 43,510 |  |  | $ | 43,021 |  |  |  |  |  |
| Petrochemical | 22,490 |  |  | 17,228 |  |  |  |  |  |
| Electric utility | 28,407 |  |  | 21,533 |  |  |  |  |  |
| Traction power | 7,072 |  |  | 11,372 |  |  |  |  |  |
| Commercial and other industrial | 17,050 |  |  | 5,646 |  |  |  |  |  |
| All others | 8,329 |  |  | 7,769 |  |  |  |  |  |
| Total revenues by market sector | $ | 126,858 |  |  | $ | 106,569 |  |  |  |  |  |


## us-gaap:RevenueFromContractWithCustomerPolicyTextBlock

[0000080420-23-000007:notes:53]
[same as prior period, unchanged from 0000080420-22-000032:notes:55]

[0000080420-23-000007:notes:54]
Additionally, some contracts may contain a cancellation clause that could limit the amount of revenue we are able to recognize over time. In these instances, revenue and costs associated with these contracts are deferred and recognized at a point in time when the performance obligation is fulfilled.
Selling and administrative costs incurred in relation to obtaining a contract are typically expensed as incurred. We periodically utilize a third-party sales agent to obtain a contract and will pay a commission to that agent. We record the full commission liability to the third-party sales agents at the order date, with a corresponding deferred asset. As the project progresses, we record commission expense based on percentage of completion rates that correlate to the project and reduce the deferred asset. Once we have been paid by the customer, we pay the commission and the deferred liability is reduced
Performance Obligations

[0000080420-23-000007:notes:55]
A performance obligation is a promise in a contract or with a customer to transfer a distinct good or service. A contract’s transaction price is allocated to each distinct performance obligation and recognized as revenue as the performance obligations are satisfied. To determine the proper revenue recognition for contracts, we evaluate whether a contract should be accounted for as more than one performance obligation or, less commonly, whether two or more contracts should be combined and accounted for as one performance obligation. This evaluation of performance obligations requires significant judgment. The majority of our contracts have a single performance obligation where multiple engineered products and services are combined into a single custom-engineered solution. Our contracts include a standard one-year assurance warranty. Occasionally, we provide service-type warranties that will extend the warranty period. These extended warranties qualify as a separate performance obligation, and revenue is deferred and recognized over the warranty period. If we determine during the evaluation of the contract that there are multiple performance obligations, we allocate the transaction price to each performance obligation using our best estimate of the standalone selling price of each distinct good or service in the contract. 
Remaining unsatisfied performance obligations, which we refer to as backlog, represent the estimated transaction price for goods and services for which we have a material right, but work has not been performed.
Contract Estimates

[0000080420-23-000007:notes:56]
Actual revenues and project costs may vary from previous estimates due to changes in a variety of factors. The cost estimation process is based upon the professional knowledge and experience of our engineers, project managers and financial 
professionals. Factors that are considered in estimating the work to be completed and ultimate contract recovery include the availability and productivity of labor, the nature and complexity of the work to be performed, the availability of materials, and the effect of any delays on our project performance. We periodically review our job performance, job conditions, estimated profitability and final contract settlements, including our estimate of total costs and make revisions to costs and income in the period in which the revisions are probable and reasonably estimable. We bear the risk of cost overruns in most of our contracts, which may result in reduced profits. Whenever revisions of estimated contract costs and contract values indicate that the contract costs will exceed estimated revenues, thus creating a loss, a provision for the total estimated loss is recorded in that period.
Variable Consideration

[0000080420-23-000007:notes:57]
Contract liabilities typically represent advance payments from contractual billing milestones and billings in excess of revenue recognized. It is unusual to have advanced milestone payments with a term greater than one year, which could represent a financing component on the contract.  
Our contract assets and liabilities are reported in a net position on a contract-by-contract basis at the end of each reporting period and are generally classified as current.The timing of our invoice process is typically dependent on the completion of certain milestones and contract terms and subject to agreement by our customer. Payment is typically expected within 30 days of invoice. Any uncollected invoiced amounts for our performance obligations recognized over time, including contract retentions, are recorded as accounts receivable in the Condensed Consolidated Balance Sheets. Certain contracts allow customers to withhold a small percentage of billings pursuant to retainage provisions, and such amounts are generally due upon completion of the contract and acceptance of the project by the customer. Based on our experience in recent years, the majority of these retainage balances are expected to be collected within approximately twelve months.


## us-gaap:LongTermDebtTextBlock

[0000080420-23-000007:notes:58]
Long-Term Debt
U.S. Revolver

[0000080420-23-000007:notes:59]
We have a credit agreement with Bank of America, N.A. (as amended, the U.S. Revolver), which is a $75.0 million revolving credit facility that is available for both borrowings and letters of credit and expires September 27, 2024. The U.S. Revolver states that up to $30 million may be deducted from the amount of letters of credit outstanding (not to be less than zero) when calculating the consolidated funded indebtedness, which is a component of the consolidated net leverage ratio. Additionally, we have the option to cash collateralize all or a portion of the letters of credit outstanding, which would favorably impact the consolidated funded indebtedness calculation and the consolidated net leverage ratio. As of December 31, 2022, there were no amounts borrowed under the U.S. Revolver, and letters of credit outstanding were $33.8 million. There was $41.2 million available for the issuance of letters of credit and borrowings under the U.S. Revolver as of December 31, 2022.

[0000080420-23-000007:notes:60]
We are required to maintain certain financial covenants, the most significant of which are a consolidated net leverage ratio less than 3.0 to 1.0 and a consolidated interest coverage ratio of greater than 3.0 to 1.0. Our most restrictive covenant, the consolidated net leverage ratio, is the ratio of earnings before interest, taxes, depreciation, amortization and stock-based compensation (EBITDAS) to funded indebtedness. An increase in indebtedness, which includes letters of credit, or a decrease

[0000080420-23-000007:notes:61]
in EBITDAS could restrict our ability to issue letters of credit or borrow under the U.S. Revolver. Additionally, we must maintain a consolidated cash balance of $30 million at all times, which can be deducted from the letters of credit outstanding as noted above. The U.S. Revolver also contains a "material adverse effect" clause which is a material change in our operations, business, properties, liabilities or condition (financial or otherwise) or a material impairment of our ability to perform our obligations under our credit agreements. As of December 31, 2022, we were in compliance with all of the financial covenants of the U.S. Revolver.

[0000080420-23-000007:notes:62]
The U.S. Revolver allows the Company to elect that any borrowing under the facility bears an interest rate based on either the base rate or the eurocurrency rate, in each case, plus the applicable rate. The base rate is generally the highest of (a) the federal funds rate plus 0.50%, (b) the Bank of America prime rate or (c) the Bloomberg Short-Term Bank Yield Index (BSBY) rate plus 1.00%. The applicable rate is generally a range from (0.25)% to 1.75% depending on the type of loan and the Company's consolidated net leverage ratio. On November 10, 2022, the Company entered into a second LIBOR Transition Amendment with Bank of America that states that LIBOR for U.S. dollar loans will be replaced with the BSBY rate in accordance with the U.S. Revolver.

[0000080420-23-000007:notes:63]
The U.S. Revolver is collateralized by a pledge of 100% of the voting capital stock of each of our domestic subsidiaries and 65% of the voting capital stock of each non-domestic subsidiary. The U.S. Revolver provides for customary events of default and carries cross-default provisions with other existing debt agreements. If an event of default (as defined in the U.S. Revolver) occurs and is continuing, on the terms and subject to the conditions set forth in the U.S. Revolver, amounts and letters of credit outstanding under the U.S. Revolver may be accelerated and may become immediately due and payable.

[0000080420-23-000007:notes:64]
Industrial Development Revenue Bonds

[0000080420-23-000007:notes:65]
We borrowed $8.0 million in October 2001 through a loan agreement funded with proceeds from tax-exempt industrial development revenue bonds (Bonds) for the completion of our Northlake, Illinois facility. The Bonds matured on October 1, 2021 and our final payment of $0.4 million was made.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0000080420-23-000007:notes:66]
Commitments and Contingencies
Letters of Credit, Bank Guarantees and Bonds

[0000080420-23-000007:notes:67]
Certain customers require us to post letters of credit, bank guarantees or surety bonds. These security instruments assure that we will perform under the terms of our contract. In the event of default, the counterparty may demand payment from the bank under a letter of credit or bank guarantee, or performance by the surety under a bond. To date, there have been no significant draws or claims related to security instruments for the periods reported. We were contingently liable for letters of credit of $33.8 million as of December 31, 2022. We also had surety bonds totaling $284.5 million that were outstanding, with additional bonding capacity of $315.5 million available, at December 31, 2022. We have strong surety relationships; however, a change in market conditions or the sureties' assessment of our financial position could cause the sureties to require cash collateralization for undischarged liabilities under the bonds.

[0000080420-23-000007:notes:68]
We have a $9.7 million facility agreement (Facility Agreement) between Powell (UK) Limited and a large international bank that provides Powell (UK) Limited the ability to enter into bank guarantees as well as forward exchange contracts and currency options. At December 31, 2022, we had outstanding guarantees totaling $6.8 million. The Facility Agreement provides for customary events of default and carries cross-default provisions with our U.S. Revolver. If an event of default (as defined in the Facility Agreement) occurs and is continuing, per the terms and subject to the conditions set forth therein, obligations outstanding under the Facility Agreement may be accelerated and declared immediately due and payable. Additionally, we are required to maintain cash collateral for guarantees greater than two years. As of December 31, 2022, we were in compliance with all of the financial covenants of the Facility Agreement.

[0000080420-23-000007:notes:69]
Litigation

[0000080420-23-000007:notes:70]
We are involved in various legal proceedings, claims and other disputes arising from our commercial operations, projects, employees and other matters which, in general, are subject to uncertainties and in which the outcomes are not predictable. Although we can give no assurances about the resolution of pending claims, litigation or other disputes, and the effect such outcomes may have on us, management believes that any ultimate liability resulting from the outcome of such proceedings, to the extent not otherwise provided or covered by insurance, will not have a material adverse effect on our consolidated financial position or results of operations or liquidity.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0000080420-23-000007:notes:71]
Stock-Based Compensation
Refer to our Annual Report on Form 10-K for the fiscal year ended September 30, 2022 for a full description of our existing stock-based compensation plans.

[0000080420-23-000007:notes:72]
[same as prior period, unchanged from 0000080420-22-000032:notes:74]

[0000080420-23-000007:notes:73]
We issue restricted stock units (RSUs) to certain officers and key employees of the Company. The fair value of the RSUs is based on the price of our common stock as reported on the NASDAQ Global Market on the grant dates. Typically, these grants vest over a three-year period from the date of issuance and are a blend of time-based and performance-based shares. The portion of the grant that is time-based typically vests over a three-year period on each anniversary of the grant date, based on continued employment. The performance-based shares vest based on the three-year earnings performance of the Company following the grant date. At December 31, 2022, there were 308,917 RSUs outstanding. The RSUs do not have voting rights but do receive dividend equivalents upon vesting which are accrued quarterly. Additionally, the shares of common stock underlying the RSUs are not considered issued and outstanding until vested and common stock is issued.

[0000080420-23-000007:notes:74]
Total RSU activity (number of shares) for the three months ended December 31, 2022 is summarized below:

[0000080420-23-000007:notes:75]
|  | Number ofRestrictedStockUnits |  | WeightedAverageGrant ValuePer Share |
| Outstanding at September 30, 2022 | 239,862 |  |  | $ | 26.11 |  |
| Granted | 147,100 |  |  | 21.26 |  |
| Vested | (63,334) |  |  | 30.78 |  |
| Forfeited/canceled | (14,711) |  |  | 38.58 |  |
| Outstanding at December 31, 2022 | 308,917 |  |  | $ | 22.86 |  |

[0000080420-23-000007:notes:76]
During the three months ended December 31, 2022 and 2021, we recorded compensation expense of $1.3 million and $0.9 million, respectively, related to the RSUs.

[0000080420-23-000007:notes:77]
Restricted Stock
Each non-employee director receives 2,400 restricted shares of the Company’s common stock annually. Fifty-percent of the restricted stock granted to each of our non-employee directors vests immediately, while the remaining fifty-percent vests on the anniversary of the grant date. Compensation expense is recognized immediately for the first fifty-percent of the restricted stock granted, while compensation expense for the remaining fifty-percent is recognized over the remaining vesting period. During both the three months ended December 31, 2022 and 2021, there were no restricted shares granted. During the three months ended December 31, 2022 and 2021, we recorded compensation expense of less than $0.1 million and $0.1 million, respectively, related to restricted stock.


## us-gaap:FairValueDisclosuresTextBlock

[0000080420-23-000007:notes:78]
[same as prior period, unchanged from 0000080420-22-000032:notes:80]

[0000080420-23-000007:notes:79]
[same as prior period, unchanged from 0000080420-22-000032:notes:81]

[0000080420-23-000007:notes:80]
[same as prior period, unchanged from 0000080420-22-000032:notes:82]

[0000080420-23-000007:notes:81]
Level 2 — Inputs other than the quoted prices in active markets that are observable either directly or indirectly, including quoted prices for similar assets and liabilities in active markets; quoted prices for identical or similar assets and liabilities in markets that are not active or other inputs that are observable or can be corroborated by observable market data.

[0000080420-23-000007:notes:82]
[same as prior period, unchanged from 0000080420-22-000032:notes:84]

[0000080420-23-000007:notes:83]
The following table summarizes the fair value of our assets and liabilities that were accounted for at fair value on a recurring basis as of December 31, 2022 (in thousands):

[0000080420-23-000007:notes:84]
|  | Fair Value Measurements at December 31, 2022 |
|  | Quoted Prices inActive Markets forIdentical Assets(Level 1) |  | Significant OtherObservableInputs(Level 2) |  | SignificantUnobservableInputs(Level 3) |  | Fair Value at December 31,2022 |
| Assets: |  |  |  |  |  |  |  |
| Cash and cash equivalents | $ | 99,632 |  |  | $ | — |  |  | $ | — |  |  | $ | 99,632 |  |
| Short-term investments | 11,070 |  |  | — |  |  | — |  |  | 11,070 |  |
| Other assets | — |  |  | 8,067 |  |  | — |  |  | 8,067 |  |
| Liabilities: |  |  |  |  |  |  |  |
| Deferred compensation | — |  |  | 8,905 |  |  | — |  |  | 8,905 |  |

[0000080420-23-000007:notes:85]
The following table summarizes the fair value of our assets and liabilities that were accounted for at fair value on a recurring basis as of September 30, 2022 (in thousands):

[0000080420-23-000007:notes:86]
|  | Fair Value Measurements at September 30, 2022 |
|  | Quoted Prices inActive Markets forIdentical Assets(Level 1) |  | Significant OtherObservableInputs(Level 2) |  | SignificantUnobservableInputs(Level 3) |  | Fair Value at September 30,2022 |
| Assets: |  |  |  |  |  |  |  |
| Cash and cash equivalents | $ | 101,954 |  |  | $ | — |  |  | $ | — |  |  | $ | 101,954 |  |
| Short-term investments | 14,554 |  |  | — |  |  | — |  |  | 14,554 |  |
| Other assets | — |  |  | 7,730 |  |  | — |  |  | 7,730 |  |
| Liabilities: |  |  |  |  |  |  |  |
| Deferred compensation | — |  |  | 7,714 |  |  | — |  |  | 7,714 |  |

[0000080420-23-000007:notes:87]
[same as prior period, unchanged from 0000080420-22-000032:notes:89]

[0000080420-23-000007:notes:88]
[same as prior period, unchanged from 0000080420-22-000032:notes:90]

[0000080420-23-000007:notes:89]
[same as prior period, unchanged from 0000080420-22-000032:notes:91]

[0000080420-23-000007:notes:90]
[same as prior period, unchanged from 0000080420-22-000032:notes:92]

[0000080420-23-000007:notes:91]
There were no transfers between levels within the fair value measurement hierarchy during the quarter ended December 31, 2022.


## us-gaap:LesseeOperatingLeasesTextBlock

[0000080420-23-000007:notes:92]
Leases
Our leases consist primarily of office and manufacturing space and construction equipment. All of our future lease obligations are related to non-cancelable operating leases. The most significant portion of our lease portfolio relates to leases of office and manufacturing facilities in Canada that we no longer occupy. We currently sublease the majority of these Canadian facilities. The following table provides a summary of lease cost components for the three months ended December 31, 2022 and 2021, respectively (in thousands):

[0000080420-23-000007:notes:93]
|  |  | Three months ended December 31, |  |  |
| Lease Cost |  | 2022 |  | 2021 |  |  |  |  |
| Operating lease cost |  | $ | 378 |  |  | $ | 571 |  |  |  |  |  |
| Less: sublease income |  | (162) |  |  | (174) |  |  |  |  |  |
| Variable lease cost(1) |  | 108 |  |  | 141 |  |  |  |  |  |
| Short-term lease cost(2) |  | 387 |  |  | 273 |  |  |  |  |  |
| Total lease cost |  | $ | 711 |  |  | $ | 811 |  |  |  |  |  |

[0000080420-23-000007:notes:94]
[same as prior period, unchanged from 0000080420-22-000032:notes:96]

[0000080420-23-000007:notes:95]
[same as prior period, unchanged from 0000080420-22-000032:notes:97]

[0000080420-23-000007:notes:96]
We recognize operating lease assets and operating lease liabilities representing the present value of the remaining lease payments for leases with initial terms greater than twelve months. Leases with initial terms of twelve months or less are not recorded in our Condensed Consolidated Balance Sheets. As of both December 31, 2022 and September 30, 2022, our operating lease assets have been reduced by a lease accrual of $0.1 million related to certain unused facility leases in Canada. The following table provides a summary of the operating lease assets and operating lease liabilities included in our Condensed Consolidated Balance Sheets as of December 31, 2022 and September 30, 2022, respectively (in thousands):

[0000080420-23-000007:notes:97]
| Operating Leases |  | December 31, 2022 |  | September 30, 2022 |
| Assets: |  |  |  |  |
| Operating lease assets, net |  | $ | 2,159 |  |  | $ | 2,179 |  |
| Liabilities: |  |  |  |  |
| Current operating lease liabilities |  | 1,545 |  |  | 1,777 |  |
| Long-term operating lease liabilities |  | 713 |  |  | 545 |  |
| Total lease liabilities |  | $ | 2,258 |  |  | $ | 2,322 |  |

[0000080420-23-000007:notes:98]
The following table provides the maturities of our operating lease liabilities as of December 31, 2022 (in thousands):

[0000080420-23-000007:notes:99]
|  |  | Operating Leases |  |  |
| Remainder of 2023 |  | $ | 1,476 |  |  |  |
| 2024 |  | 455 |  |  |  |
| 2025 |  | 195 |  |  |  |
| 2026 |  | 102 |  |  |  |
| 2027 |  | 87 |  |  |  |
| Thereafter |  | 7 |  |  |  |
| Total future minimum lease payments |  | $ | 2,322 |  |  |  |
| Less: present value discount (imputed interest) |  | (64) |  |  |  |
| Present value of lease liabilities |  | $ | 2,258 |  |  |  |

[0000080420-23-000007:notes:100]
The weighted average discount rate as of December 31, 2022 was 3.61%. The weighted average remaining lease term was 2.04 years at December 31, 2022.


## us-gaap:IncomeTaxDisclosureTextBlock

[0000080420-23-000007:notes:101]
[same as prior period, unchanged from 0000080420-22-000032:notes:103]

[0000080420-23-000007:notes:102]
|  | Three months ended December 31, |  |  |
|  | 2022 |  | 2021 |  |  |  |  |
| Income (loss) before income taxes | $ | 1,613 |  |  | $ | (4,287) |  |  |  |  |  |
| Income tax provision (benefit) | 451 |  |  | (1,441) |  |  |  |  |  |
| Net income (loss) | $ | 1,162 |  |  | $ | (2,846) |  |  |  |  |  |
| Effective tax rate | 28 | % |  | 34 | % |  |  |  |  |

[0000080420-23-000007:notes:103]
Our income tax provision reflects an effective tax rate on pre-tax income of 28% for the first quarter of Fiscal 2023 compared to an income tax benefit that reflects an effective tax rate on pre-tax loss of 34% for the first quarter of Fiscal 2022. The effective tax rate for the first quarters of Fiscal 2023 and Fiscal 2022 were favorably impacted by the estimated Research and Development Tax Credit (R&D Tax Credit), partially offset by discrete items primarily related to the vesting of restricted stock units. In addition, the first quarter of Fiscal 2022 was also impacted by a valuation allowance that prohibited the recognition of certain non-U.S. tax losses


## us-gaap:SubsequentEventsTextBlock

[0000080420-23-000007:notes:104]
Subsequent Events
Quarterly Dividend Declared

[0000080420-23-000007:notes:105]
On January 31, 2023, our Board of Directors approved a 1% increase to the quarterly cash dividend on our common stock to $0.2625 per share, equating to an annualized dividend of $1.05 per share from the current amount of $1.04 per share. The dividend is payable on March 15, 2023 to shareholders of record at the close of business on February 15, 2023.
