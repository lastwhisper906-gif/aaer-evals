# POWL note change history — 0000080420-22-000032 → 0000080420-23-000007


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2023-02-01):
[0000080420-23-000007:note_history:1]
Certain customers require us to post letters of credit, bank guarantees or surety bonds. These security instruments assure that we will perform under the terms of our contract. In the event of default, the counterparty may demand payment from the bank under a letter of credit or bank guarantee, or performance by the surety under a bond. To date, there have been no significant draws or claims related to security instruments for the periods reported. We were contingently liable for letters of credit of $33.8 million as of December 31, 2022. We also had surety bonds totaling $284.5 million that were outstanding, with additional bonding capacity of $315.5 million available, at December 31, 2022. We have strong surety relationships; however, a change in market conditions or the sureties' assessment of our financial position could cause the sureties to require cash collateralization for undischarged liabilities under the bonds.
  (was, 2022-08-03, similarity 0.9868):
[0000080420-22-000032:note_history:1]
Certain customers require us to post letters of credit, bank guarantees or surety bonds. These security instruments assure that we will perform under the terms of our contract. In the event of default, the counterparty may demand payment from the bank under a letter of credit or bank guarantee, or performance by the surety under a bond. To date, there have been no significant draws or claims related to security instruments for the periods reported. We were contingently liable for letters of credit of $30.8 million as of June 30, 2022. We also had surety bonds totaling $159.9 million that were outstanding, with additional bonding capacity of $440.1 million available, at June 30, 2022. We have strong surety relationships; however, a change in market conditions or the sureties' assessment of our financial position could cause the sureties to require cash collateralization for undischarged liabilities under the bonds.

- changed (2023-02-01):
[0000080420-23-000007:note_history:2]
We have a $9.7 million facility agreement (Facility Agreement) between Powell (UK) Limited and a large international bank that provides Powell (UK) Limited the ability to enter into bank guarantees as well as forward exchange contracts and currency options. At December 31, 2022, we had outstanding guarantees totaling $6.8 million. The Facility Agreement provides for customary events of default and carries cross-default provisions with our U.S. Revolver. If an event of default (as defined in the Facility Agreement) occurs and is continuing, per the terms and subject to the conditions set forth therein, obligations outstanding under the Facility Agreement may be accelerated and declared immediately due and payable. Additionally, we are required to maintain cash collateral for guarantees greater than two years. As of December 31, 2022, we were in compliance with all of the financial covenants of the Facility Agreement.
  (was, 2022-08-03, similarity 0.9507):
[0000080420-22-000032:note_history:2]
We have a $6.1 million facility agreement (Facility Agreement) between Powell (UK) Limited and a large international bank that provides Powell (UK) Limited the ability to enter into bank guarantees as well as forward exchange contracts and currency options. At June 30, 2022, we had outstanding guarantees totaling $3.1 million and amounts available under this Facility Agreement were $3.0 million. The Facility Agreement provides for customary events of default, and carries cross-default provisions with our U.S. Revolver. If an event of default (as defined in the Facility Agreement) occurs and is continuing, per the terms and subject to the conditions set forth therein, obligations outstanding under the Facility Agreement may be accelerated and declared immediately due and payable. Additionally, we are required to maintain cash collateral for guarantees greater than two years. As of June 30, 2022, we were in compliance with all of the financial covenants of the Facility Agreement.

- changed (2023-02-01):
[0000080420-23-000007:note_history:3]
We are involved in various legal proceedings, claims and other disputes arising from our commercial operations, projects, employees and other matters which, in general, are subject to uncertainties and in which the outcomes are not predictable. Although we can give no assurances about the resolution of pending claims, litigation or other disputes, and the effect such outcomes may have on us, management believes that any ultimate liability resulting from the outcome of such proceedings, to the extent not otherwise provided or covered by insurance, will not have a material adverse effect on our consolidated financial position or results of operations or liquidity.
  (was, 2022-08-03, similarity 0.9993):
[0000080420-22-000032:note_history:3]
We are involved in various legal proceedings, claims and other disputes arising from our commercial operations, projects, employees and other matters which, in general, are subject to uncertainties and in which the outcomes are not predictable. Although we can give no assurances about the resolution of pending claims, litigation or other disputes and the effect such outcomes may have on us, management believes that any ultimate liability resulting from the outcome of such proceedings, to the extent not otherwise provided or covered by insurance, will not have a material adverse effect on our consolidated financial position or results of operations or liquidity.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureAndSignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2023-02-01):
[0000080420-23-000007:note_history:4]
Powell Industries, Inc. (we, us, our, Powell or the Company) is incorporated in the state of Delaware. Powell's predecessor companies were founded 76 years ago by William E. Powell in 1947. Our major subsidiaries, all of which are wholly owned, include Powell Electrical Systems, Inc.; Powell (UK) Limited; Powell Canada Inc.; and Powell Industries International, B.V.
  (was, 2022-08-03, similarity 0.9986):
[0000080420-22-000032:note_history:4]
Powell Industries, Inc. (we, us, our, Powell or the Company) is incorporated in the state of Delaware. Powell's predecessor companies were founded 75 years ago by William E. Powell in 1947. Our major subsidiaries, all of which are wholly owned, include: Powell Electrical Systems, Inc.; Powell (UK) Limited; Powell Canada Inc.; and Powell Industries International, B.V.

- changed (2023-02-01):
[0000080420-23-000007:note_history:5]
We develop, design, manufacture and service custom-engineered equipment and systems that (1) distribute, control and monitor the flow of electrical energy and (2) provide protection to motors, transformers and other electrically powered equipment. We are headquartered in Houston, Texas and serve the oil and gas and petrochemical markets, which include onshore and offshore production, liquefied natural gas (LNG) facilities and terminals, pipelines, refineries and petrochemical plants. Additional markets include electric utility, light rail traction power as well as mining and metals, pulp and paper and other municipal, commercial and other industrial markets.
  (was, 2022-08-03, similarity 0.8241):
[0000080420-22-000032:note_history:5]
We develop, design, manufacture and service custom-engineered equipment and systems which (1) distribute, control and monitor the flow of electrical energy and (2) provide protection to motors, transformers and other electrically powered equipment. We are headquartered in Houston, Texas and serve the oil and gas and petrochemical markets, which include onshore and offshore production, liquefied natural gas (LNG) facilities and terminals, pipelines, refineries and petrochemical plants. Additional markets include electric utility and light rail traction power as well as mining and metals, pulp and paper and other municipal, commercial and industrial markets.

- changed (2023-02-01):
[0000080420-23-000007:note_history:6]
These unaudited condensed consolidated financial statements include the accounts of Powell and our wholly-owned subsidiaries. All significant intercompany accounts and transactions have been eliminated in consolidation.
  (was, 2022-08-03, similarity 0.9863):
[0000080420-22-000032:note_history:6]
These unaudited condensed consolidated financial statements include the accounts of Powell and its wholly-owned subsidiaries. All significant intercompany accounts and transactions have been eliminated in consolidation.

- added (2023-02-01):
[0000080420-23-000007:note_history:7]
References to Fiscal 2023 and Fiscal 2022 used throughout this report shall mean the current fiscal year ending September 30, 2023 and the prior fiscal year ended September 30, 2022, respectively.

- changed (2023-02-01):
[0000080420-23-000007:note_history:8]
Use of Estimates
The preparation of condensed consolidated financial statements in conformity with U.S. GAAP requires management to make estimates and assumptions that affect the amounts reported in the condensed consolidated financial statements and accompanying footnotes. The most significant estimates used in our condensed consolidated financial statements affect revenue recognition and estimated cost recognition on our customer contracts, the allowance for credit losses, provision for excess and obsolete inventory, warranty accruals and income taxes. The amounts recorded for warranties, legal, income taxes, impairment of long-lived assets (when applicable), liquidated damages and other contingent liabilities require judgments regarding the amount of expenses that will ultimately be incurred. We base our estimates on historical experience, forecasts and various other assumptions, as well as the specific circumstances surrounding these contingent liabilities, in evaluating the amount of liability that should be recorded. Additionally, the recognition of deferred tax assets requires estimates related to future income and other assumptions regarding timing and future profitability because the ultimate realization of net deferred tax assets is dependent on the generation of future taxable income during the periods in which temporary differences become deductible. Estimates routinely change as new events occur, additional information becomes available or operating environments change. Actual results may differ from our prior estimates.
  (was, 2022-08-03, similarity 0.9492):
[0000080420-22-000032:note_history:8]
References to Fiscal 2022 and Fiscal 2021 used throughout this report shall mean our fiscal years ended September 30, 2022 and 2021, respectively.
Use of EstimatesThe preparation of condensed consolidated financial statements in conformity with U.S. GAAP requires management to make estimates and assumptions that affect the amounts reported in the condensed consolidated financial statements and accompanying footnotes. The most significant estimates used in our condensed consolidated financial statements affect revenue recognition and estimated cost recognition on our customer contracts, the allowance for credit losses, provision for excess and obsolete inventory, warranty accruals and income taxes. The amounts recorded for warranties, legal, income taxes, impairment of long-lived assets (when applicable), liquidated damages and other contingent liabilities require judgments regarding the amount of expenses that will ultimately be incurred. We base our estimates on historical experience, forecasts and various other assumptions, as well as the specific circumstances surrounding these contingent liabilities, in evaluating the amount of liability that should be recorded. Additionally, the recognition of deferred tax assets requires estimates related to future income and other assumptions regarding timing and future profitability because the ultimate realization of net deferred tax assets is dependent on the generation of future taxable income during the periods in which temporary differences become deductible. Estimates routinely change as new events occur, additional information becomes available or operating environments change. Actual results may differ from our prior estimates.

- removed (2023-02-01):
[0000080420-22-000032:note_history:9]
Impact of Global Economic Uncertainty and Oil and Gas Commodity Market Volatility on Powell

- removed (2023-02-01):
[0000080420-22-000032:note_history:10]
Various factors resulting in global economic uncertainty have negatively impacted our results over the past two years. Uncertainty and demand disruptions have resulted in considerable volatility across commodity markets. Although global oil prices have rebounded, our industrial end markets have responded with modest increases in capital expenditures. Additionally, we continue to experience supply chain disruptions driven predominately by availability and cost volatility across our raw materials, components and labor force. All of these factors have contributed to the lower margins realized in Fiscal 2022. As we address disruptions and increased costs, we continue to work with our suppliers of key components and commodities to ensure that we are able to meet our customer commitments. Additionally, we have adjusted our pricing models in response to the increased cost environment.

- removed (2023-02-01):
[0000080420-22-000032:note_history:11]
The consequences of a continued and prolonged global economic decline could include, but are not limited to, reductions in commercial and industrial activity in the markets we serve. The Company cannot reasonably estimate the duration or extent to which the resulting disruptions may materially impact our business, results of operations or cash flows. We will take prudent measures to maintain our strong liquidity and cash position, which may include reducing our capital expenditures and research and development costs, as well as reducing or eliminating future dividend payments.


## us-gaap:LongTermDebtTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2023-02-01):
[0000080420-23-000007:note_history:12]
Long-Term Debt
U.S. Revolver
  (was, 2022-08-03, similarity 0.6341):
[0000080420-22-000032:note_history:12]
U.S. Revolver

- changed (2023-02-01):
[0000080420-23-000007:note_history:13]
We have a credit agreement with Bank of America, N.A. (as amended, the U.S. Revolver), which is a $75.0 million revolving credit facility that is available for both borrowings and letters of credit and expires September 27, 2024. The U.S. Revolver states that up to $30 million may be deducted from the amount of letters of credit outstanding (not to be less than zero) when calculating the consolidated funded indebtedness, which is a component of the consolidated net leverage ratio. Additionally, we have the option to cash collateralize all or a portion of the letters of credit outstanding, which would favorably impact the consolidated funded indebtedness calculation and the consolidated net leverage ratio. As of December 31, 2022, there were no amounts borrowed under the U.S. Revolver, and letters of credit outstanding were $33.8 million. There was $41.2 million available for the issuance of letters of credit and borrowings under the U.S. Revolver as of December 31, 2022.
  (was, 2022-08-03, similarity 0.9717):
[0000080420-22-000032:note_history:13]
We have a credit agreement with Bank of America, N.A. (as amended, the "U.S. Revolver"), which is a $75.0 million revolving credit facility that is available for both borrowings and letters of credit and expires September 27, 2024. The U.S. Revolver states that up to $30 million may be deducted from the amount of letters of credit outstanding (not to be less than zero) when calculating the consolidated funded indebtedness which is a component of the consolidated net leverage ratio. Additionally, we have the option to cash collateralize all or a portion of the letters of credit outstanding, which would favorably impact the consolidated funded indebtedness calculation and the consolidated net leverage ratio. As of June 30, 2022, there were no amounts borrowed under the U.S. Revolver and letters of credit outstanding were $30.8 million. There was $44.2 million available for the issuance of letters of credit and borrowings under the U.S. Revolver as of June 30, 2022.

- changed (2023-02-01):
[0000080420-23-000007:note_history:14]
We are required to maintain certain financial covenants, the most significant of which are a consolidated net leverage ratio less than 3.0 to 1.0 and a consolidated interest coverage ratio of greater than 3.0 to 1.0. Our most restrictive covenant, the consolidated net leverage ratio, is the ratio of earnings before interest, taxes, depreciation, amortization and stock-based compensation (EBITDAS) to funded indebtedness. An increase in indebtedness, which includes letters of credit, or a decrease
  (was, 2022-08-03, similarity 0.6054):
[0000080420-22-000032:note_history:14]
We are required to maintain certain financial covenants, the most significant of which are a consolidated net leverage ratio less than 3.0 to 1.0 and a consolidated interest coverage ratio of greater than 3.0 to 1.0. Our most restrictive covenant, the consolidated net leverage ratio, is the ratio of earnings before interest, taxes, depreciation, amortization and stock-based compensation (EBITDAS) to funded indebtedness. An increase in indebtedness, which includes letters of credit, or a decrease in EBITDAS could restrict our ability to issue letters of credit or borrow under the U.S. Revolver. Additionally, we must maintain a consolidated cash balance of $30 million at all times, which can be deducted from the letters of credit outstanding as noted above. The U.S. Revolver also contains a "material adverse effect" clause which is a material change in our operations, business, properties, liabilities or condition (financial or otherwise) or a material impairment of our ability to perform our obligations under our credit agreements. As of June 30, 2022, we were in compliance with all of the financial covenants of the U.S. Revolver.

- added (2023-02-01):
[0000080420-23-000007:note_history:15]
in EBITDAS could restrict our ability to issue letters of credit or borrow under the U.S. Revolver. Additionally, we must maintain a consolidated cash balance of $30 million at all times, which can be deducted from the letters of credit outstanding as noted above. The U.S. Revolver also contains a "material adverse effect" clause which is a material change in our operations, business, properties, liabilities or condition (financial or otherwise) or a material impairment of our ability to perform our obligations under our credit agreements. As of December 31, 2022, we were in compliance with all of the financial covenants of the U.S. Revolver.

- changed (2023-02-01):
[0000080420-23-000007:note_history:16]
The U.S. Revolver allows the Company to elect that any borrowing under the facility bears an interest rate based on either the base rate or the eurocurrency rate, in each case, plus the applicable rate. The base rate is generally the highest of (a) the federal funds rate plus 0.50%, (b) the Bank of America prime rate or (c) the Bloomberg Short-Term Bank Yield Index (BSBY) rate plus 1.00%. The applicable rate is generally a range from (0.25)% to 1.75% depending on the type of loan and the Company's consolidated net leverage ratio. On November 10, 2022, the Company entered into a second LIBOR Transition Amendment with Bank of America that states that LIBOR for U.S. dollar loans will be replaced with the BSBY rate in accordance with the U.S. Revolver.
  (was, 2022-08-03, similarity 0.6767):
[0000080420-22-000032:note_history:16]
The U.S. Revolver allows the Company to elect that any borrowing under the facility bears an interest rate based on either the base rate or the eurocurrency rate, in each case, plus the applicable rate. The base rate is generally the highest of (a) the federal funds rate plus 0.50%, (b) the Bank of America prime rate or (c) the London Interbank Offered Rate (LIBOR) successor rate plus 1.00%. The applicable rate is generally a range from (0.25)% to 1.75% depending on the type of loan and the Company's consolidated net leverage ratio. On December 31, 2021, the Company entered into a LIBOR Transition Amendment with Bank of America that states that LIBOR will be replaced with a successor rate in accordance with the U.S. Revolver.

- removed (2023-02-01):
[0000080420-22-000032:note_history:17]
Long-Term Debt
Long-term debt consisted of the following (in thousands):

- removed (2023-02-01):
[0000080420-22-000032:note_history:18]
|  | June 30, 2022 |  | September 30, 2021 |
| Industrial development revenue bonds | $ | — |  |  | $ | 400 |  |
| Less: current portion | — |  |  | (400) |  |
| Total long-term debt | $ | — |  |  | $ | — |  |


## us-gaap:ScheduleOfDebtInstrumentsTextBlock (debt) — matched_by: no_current_note, score: 0.0

- removed (2023-02-01):
[0000080420-22-000032:note_history:19]
Long-term debt consisted of the following (in thousands):

- removed (2023-02-01):
[0000080420-22-000032:note_history:20]
|  | June 30, 2022 |  | September 30, 2021 |
| Industrial development revenue bonds | $ | — |  |  | $ | 400 |  |
| Less: current portion | — |  |  | (400) |  |
| Total long-term debt | $ | — |  |  | $ | — |  |


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2023-02-01):
[0000080420-23-000007:note_history:21]
The following tables present our disaggregated revenue by geographic destination and market sector for the three months ended December 31, 2022 and 2021 (in thousands):
  (was, 2022-08-03, similarity 0.9415):
[0000080420-22-000032:note_history:21]
The following tables present our disaggregated revenue by geographic destination and market sector for the three and nine months ended June 30, 2022 and 2021 (in thousands):

- changed (2023-02-01):
[0000080420-23-000007:note_history:22]
|  | Three months ended December 31, |  |  |
|  | 2022 |  | 2021 |  |  |  |  |
| United States | $ | 100,112 |  |  | $ | 82,145 |  |  |  |  |  |
| Canada | 18,496 |  |  | 15,125 |  |  |  |  |  |
| Europe, Middle East and Africa | 6,559 |  |  | 7,830 |  |  |  |  |  |
| Asia/Pacific | 776 |  |  | 944 |  |  |  |  |  |
| Mexico, Central and South America | 915 |  |  | 525 |  |  |  |  |  |
| Total revenues by geographic destination | $ | 126,858 |  |  | $ | 106,569 |  |  |  |  |  |
  (was, 2022-08-03, similarity 0.6012):
[0000080420-22-000032:note_history:22]
|  | Three months ended June 30, |  | Nine months ended June 30, |
|  | 2022 |  | 2021 |  | 2022 |  | 2021 |
| United States | $ | 102,931 |  |  | $ | 88,412 |  |  | $ | 272,069 |  |  | $ | 256,937 |  |
| Canada | 23,599 |  |  | 16,529 |  |  | 60,777 |  |  | 48,354 |  |
| Europe, Middle East and Africa | 6,697 |  |  | 8,926 |  |  | 30,078 |  |  | 28,120 |  |
| Asia/Pacific | 1,645 |  |  | 1,651 |  |  | 4,235 |  |  | 6,376 |  |
| Mexico, Central and South America | 611 |  |  | 295 |  |  | 2,748 |  |  | 1,318 |  |
| Total revenues by geographic destination | $ | 135,483 |  |  | $ | 115,813 |  |  | $ | 369,907 |  |  | $ | 341,105 |  |

- changed (2023-02-01):
[0000080420-23-000007:note_history:23]
|  | Three months ended December 31, |  |  |
|  | 2022 |  | 2021 |  |  |  |  |
| Oil and gas (excludes petrochemical) | $ | 43,510 |  |  | $ | 43,021 |  |  |  |  |  |
| Petrochemical | 22,490 |  |  | 17,228 |  |  |  |  |  |
| Electric utility | 28,407 |  |  | 21,533 |  |  |  |  |  |
| Traction power | 7,072 |  |  | 11,372 |  |  |  |  |  |
| Commercial and other industrial | 17,050 |  |  | 5,646 |  |  |  |  |  |
| All others | 8,329 |  |  | 7,769 |  |  |  |  |  |
| Total revenues by market sector | $ | 126,858 |  |  | $ | 106,569 |  |  |  |  |  |
  (was, 2022-08-03, similarity 0.6428):
[0000080420-22-000032:note_history:23]
|  | Three months ended June 30, |  | Nine months ended June 30, |
|  | 2022 |  | 2021 |  | 2022 |  | 2021 |
| Oil and gas (excludes petrochemical) | $ | 58,669 |  |  | $ | 49,272 |  |  | $ | 155,324 |  |  | $ | 139,443 |  |
| Petrochemical | 15,187 |  |  | 15,365 |  |  | 51,268 |  |  | 34,725 |  |
| Electric utility | 30,173 |  |  | 26,175 |  |  | 82,079 |  |  | 82,797 |  |
| Traction power | 9,775 |  |  | 13,821 |  |  | 31,200 |  |  | 42,322 |  |
| All others | 21,679 |  |  | 11,180 |  |  | 50,036 |  |  | 41,818 |  |
| Total revenues by market sector | $ | 135,483 |  |  | $ | 115,813 |  |  | $ | 369,907 |  |  | $ | 341,105 |  |


## us-gaap:RevenueFromContractWithCustomerPolicyTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2023-02-01):
[0000080420-23-000007:note_history:24]
Our revenues are primarily generated from the manufacturing of custom-engineered products and systems under long-term fixed-price contracts under which we agree to manufacture various products such as traditional and arc-resistant distribution switchgear and control gear, medium-voltage circuit breakers, monitoring and control communications systems, motor control
  (was, 2022-08-03, similarity 0.641):
[0000080420-22-000032:note_history:24]
Our revenues are primarily generated from the manufacturing of custom-engineered products and systems under long-term fixed-price contracts under which we agree to manufacture various products such as traditional and arc-resistant distribution switchgear and control gear, medium-voltage circuit breakers, monitoring and control communications systems, motor control centers, switches and bus duct systems. These products may be sold separately as an engineered solution but are typically integrated into custom-built enclosures which we also build. These enclosures are referred to as power control room substations (PCRs®), custom-engineered modules or electrical houses (E-Houses). Some contracts may also include the installation and the commissioning of these enclosures.

- added (2023-02-01):
[0000080420-23-000007:note_history:25]
centers, switches and bus duct systems. These products may be sold separately as an engineered solution but are typically integrated into custom-built enclosures which we also build. These enclosures are referred to as power control room substations (PCRs®), custom-engineered modules or electrical houses (E-Houses). Some contracts may also include the installation and the commissioning of these enclosures.

- changed (2023-02-01):
[0000080420-23-000007:note_history:26]
Revenue from these contracts is generally recognized over time utilizing the cost-to-cost method. Under the cost-to-cost method, the extent of progress towards completion is measured based on the ratio of costs incurred to date to the total estimated costs at completion of the performance obligation. We believe that this method is the most accurate representation of our performance because it directly measures the value of the services transferred to the customer over time as we incur costs on our contracts. Contract costs include all direct materials, labor and indirect costs related to contract performance, which may include indirect labor, supplies, tools, repairs and depreciation costs.
  (was, 2022-08-03, similarity 0.9993):
[0000080420-22-000032:note_history:26]
Revenue from these contracts is generally recognized over time utilizing the cost-to-cost method. Under the cost-to-cost method, the extent of progress towards completion is measured based on the ratio of costs incurred to date to the total estimated costs at completion of the performance obligation. We believe that this method is the most accurate representation of our performance, because it directly measures the value of the services transferred to the customer over time as we incur costs on our contracts. Contract costs include all direct materials, labor and indirect costs related to contract performance, which may include indirect labor, supplies, tools, repairs and depreciation costs.

- changed (2023-02-01):
[0000080420-23-000007:note_history:27]
We also have contracts to provide field service inspection, installation, commissioning, modification, and repair services, as well as retrofit and retrofill components for existing systems. If the service contract terms give us the right to invoice the customer for an amount that corresponds directly with the value of our performance completed to date (i.e., a service contract in which we bill a fixed amount for each hour of service provided), then we recognize revenue over time in each reporting period corresponding to the amount with which we have the right to invoice. Our performance obligations are satisfied as the work progresses. Revenues from our custom-engineered products and value-added services transferred to customers over time accounted for approximately 93% of total revenues for the three months ended December 31, 2022 and 94% of total revenues for the three months ended December 31, 2021.
  (was, 2022-08-03, similarity 0.9018):
[0000080420-22-000032:note_history:27]
We also have contracts to provide value-added services such as field service inspection, installation, commissioning, modification and repair, as well as retrofit and retro-fill components for existing systems.  If the service contract terms give us the right to invoice the customer for an amount that corresponds directly with the value of our performance completed to date (i.e., a service contract in which we bill a fixed amount for each hour of service provided), then we recognize revenue over time in each reporting period corresponding to the amount with which we have the right to invoice.  Our performance obligations are satisfied as the work progresses. Revenues from our custom-engineered products and value-added services transferred to customers over time accounted for approximately 94% of total revenues for the three and nine months ended June 30, 2022, 93% of total revenues for the three months ended June 30, 2021 and 92% of total revenues for the nine months ended June 30, 2021.

- added (2023-02-01):
[0000080420-23-000007:note_history:28]
We also have sales orders for spare parts and replacement circuit breakers for switchgear that are obsolete or that are no longer produced by the original manufacturer. Revenues from these sales orders are recognized at the time we fulfill our performance obligation to the customer, which is typically upon shipment and represented approximately 7% of total revenues for the three months ended December 31, 2022 and 6% of total revenues for the three months ended December 31, 2021.

- changed (2023-02-01):
[0000080420-23-000007:note_history:29]
Additionally, some contracts may contain a cancellation clause that could limit the amount of revenue we are able to recognize over time. In these instances, revenue and costs associated with these contracts are deferred and recognized at a point in time when the performance obligation is fulfilled.
Selling and administrative costs incurred in relation to obtaining a contract are typically expensed as incurred. We periodically utilize a third-party sales agent to obtain a contract and will pay a commission to that agent. We record the full commission liability to the third-party sales agents at the order date, with a corresponding deferred asset. As the project progresses, we record commission expense based on percentage of completion rates that correlate to the project and reduce the deferred asset. Once we have been paid by the customer, we pay the commission and the deferred liability is reduced
Performance Obligations
  (was, 2022-08-03, similarity 0.6967):
[0000080420-22-000032:note_history:29]
Additionally, we have sales orders for spare parts and replacement circuit breakers for switchgear that are obsolete or that are no longer produced by the original manufacturer. Revenues from these sales orders are recognized at the time we fulfill our performance obligation to the customer, which is typically upon shipment and represented approximately 6% of total revenues for the three and nine months ended June 30, 2022, 7% of total revenues for the three months ended June 30, 2021 and 8% of total revenues for the nine months ended June 30, 2021. 
Some contracts may contain a cancellation clause that could limit the amount of revenue we are able to recognize over time. In these instances, revenue and costs associated with these contracts are deferred and recognized at a point in time when the performance obligation is fulfilled.Selling and administrative costs incurred in relation to obtaining a contract are typically expensed as incurred. We periodically utilize a third-party sales agent to obtain a contract and will pay a commission to that agent. We record the full commission liability to the third-party sales agents at the order date, with a corresponding deferred asset. As the project progresses, we record commission expense based on percentage of completion rates that correlate to the project and reduce the deferred asset. Once we have been paid by the customer, we pay the commission and the deferred liability is reduced
Performance Obligations

- changed (2023-02-01):
[0000080420-23-000007:note_history:30]
Actual revenues and project costs may vary from previous estimates due to changes in a variety of factors. The cost estimation process is based upon the professional knowledge and experience of our engineers, project managers and financial 
professionals. Factors that are considered in estimating the work to be completed and ultimate contract recovery include the availability and productivity of labor, the nature and complexity of the work to be performed, the availability of materials, and the effect of any delays on our project performance. We periodically review our job performance, job conditions, estimated profitability and final contract settlements, including our estimate of total costs and make revisions to costs and income in the period in which the revisions are probable and reasonably estimable. We bear the risk of cost overruns in most of our contracts, which may result in reduced profits. Whenever revisions of estimated contract costs and contract values indicate that the contract costs will exceed estimated revenues, thus creating a loss, a provision for the total estimated loss is recorded in that period.
Variable Consideration
  (was, 2022-08-03, similarity 0.99):
[0000080420-22-000032:note_history:30]
Actual revenues and project costs may vary from previous estimates due to changes in a variety of factors. The cost estimation process is based upon the professional knowledge and experience of our engineers, project managers and financial professionals. Factors that are considered in estimating the work to be completed and ultimate contract recovery include the availability and productivity of labor, the nature and complexity of the work to be performed, the availability of materials, and the effect of any delays on our project performance. We periodically review our job performance, job conditions, estimated profitability and final contract settlements, including our estimate of total costs and make revisions to costs and income in the period in which the revisions are probable and reasonably estimable. We bear the risk of cost overruns in most of our contracts, which may result in reduced profits. Whenever revisions of estimated contract costs and contract values indicate that the contract costs will exceed estimated revenues, thus creating a loss, a provision for the total estimated loss is recorded in that period.

- removed (2023-02-01):
[0000080420-22-000032:note_history:31]
Variable Consideration


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2023-02-01):
[0000080420-23-000007:note_history:32]
Our revenues are primarily generated from the manufacturing of custom-engineered products and systems under long-term fixed-price contracts under which we agree to manufacture various products such as traditional and arc-resistant distribution switchgear and control gear, medium-voltage circuit breakers, monitoring and control communications systems, motor control
  (was, 2022-08-03, similarity 0.641):
[0000080420-22-000032:note_history:32]
Our revenues are primarily generated from the manufacturing of custom-engineered products and systems under long-term fixed-price contracts under which we agree to manufacture various products such as traditional and arc-resistant distribution switchgear and control gear, medium-voltage circuit breakers, monitoring and control communications systems, motor control centers, switches and bus duct systems. These products may be sold separately as an engineered solution but are typically integrated into custom-built enclosures which we also build. These enclosures are referred to as power control room substations (PCRs®), custom-engineered modules or electrical houses (E-Houses). Some contracts may also include the installation and the commissioning of these enclosures.

- added (2023-02-01):
[0000080420-23-000007:note_history:33]
centers, switches and bus duct systems. These products may be sold separately as an engineered solution but are typically integrated into custom-built enclosures which we also build. These enclosures are referred to as power control room substations (PCRs®), custom-engineered modules or electrical houses (E-Houses). Some contracts may also include the installation and the commissioning of these enclosures.

- changed (2023-02-01):
[0000080420-23-000007:note_history:34]
Revenue from these contracts is generally recognized over time utilizing the cost-to-cost method. Under the cost-to-cost method, the extent of progress towards completion is measured based on the ratio of costs incurred to date to the total estimated costs at completion of the performance obligation. We believe that this method is the most accurate representation of our performance because it directly measures the value of the services transferred to the customer over time as we incur costs on our contracts. Contract costs include all direct materials, labor and indirect costs related to contract performance, which may include indirect labor, supplies, tools, repairs and depreciation costs.
  (was, 2022-08-03, similarity 0.9993):
[0000080420-22-000032:note_history:34]
Revenue from these contracts is generally recognized over time utilizing the cost-to-cost method. Under the cost-to-cost method, the extent of progress towards completion is measured based on the ratio of costs incurred to date to the total estimated costs at completion of the performance obligation. We believe that this method is the most accurate representation of our performance, because it directly measures the value of the services transferred to the customer over time as we incur costs on our contracts. Contract costs include all direct materials, labor and indirect costs related to contract performance, which may include indirect labor, supplies, tools, repairs and depreciation costs.

- changed (2023-02-01):
[0000080420-23-000007:note_history:35]
We also have contracts to provide field service inspection, installation, commissioning, modification, and repair services, as well as retrofit and retrofill components for existing systems. If the service contract terms give us the right to invoice the customer for an amount that corresponds directly with the value of our performance completed to date (i.e., a service contract in which we bill a fixed amount for each hour of service provided), then we recognize revenue over time in each reporting period corresponding to the amount with which we have the right to invoice. Our performance obligations are satisfied as the work progresses. Revenues from our custom-engineered products and value-added services transferred to customers over time accounted for approximately 93% of total revenues for the three months ended December 31, 2022 and 94% of total revenues for the three months ended December 31, 2021.
  (was, 2022-08-03, similarity 0.9018):
[0000080420-22-000032:note_history:35]
We also have contracts to provide value-added services such as field service inspection, installation, commissioning, modification and repair, as well as retrofit and retro-fill components for existing systems.  If the service contract terms give us the right to invoice the customer for an amount that corresponds directly with the value of our performance completed to date (i.e., a service contract in which we bill a fixed amount for each hour of service provided), then we recognize revenue over time in each reporting period corresponding to the amount with which we have the right to invoice.  Our performance obligations are satisfied as the work progresses. Revenues from our custom-engineered products and value-added services transferred to customers over time accounted for approximately 94% of total revenues for the three and nine months ended June 30, 2022, 93% of total revenues for the three months ended June 30, 2021 and 92% of total revenues for the nine months ended June 30, 2021.

- changed (2023-02-01):
[0000080420-23-000007:note_history:36]
We also have sales orders for spare parts and replacement circuit breakers for switchgear that are obsolete or that are no longer produced by the original manufacturer. Revenues from these sales orders are recognized at the time we fulfill our performance obligation to the customer, which is typically upon shipment and represented approximately 7% of total revenues for the three months ended December 31, 2022 and 6% of total revenues for the three months ended December 31, 2021.
  (was, 2022-08-03, similarity 0.8436):
[0000080420-22-000032:note_history:36]
Additionally, we have sales orders for spare parts and replacement circuit breakers for switchgear that are obsolete or that are no longer produced by the original manufacturer. Revenues from these sales orders are recognized at the time we fulfill our performance obligation to the customer, which is typically upon shipment and represented approximately 6% of total revenues for the three and nine months ended June 30, 2022, 7% of total revenues for the three months ended June 30, 2021 and 8% of total revenues for the nine months ended June 30, 2021.

- added (2023-02-01):
[0000080420-23-000007:note_history:37]
Additionally, some contracts may contain a cancellation clause that could limit the amount of revenue we are able to recognize over time. In these instances, revenue and costs associated with these contracts are deferred and recognized at a point in time when the performance obligation is fulfilled.

- changed (2023-02-01):
[0000080420-23-000007:note_history:38]
Remaining unsatisfied performance obligations, which we refer to as backlog, represent the estimated transaction price for goods and services for which we have a material right, but work has not been performed. As of December 31, 2022, we had backlog of $679.8 million, of which approximately $464.2 million is expected to be recognized as revenue within the next twelve months. Backlog may not be indicative of future operating results as orders may be cancelled or modified by our customers. Our backlog does not include service and maintenance-type contracts for which we have the right to invoice as services are performed.
  (was, 2022-08-03, similarity 0.9902):
[0000080420-22-000032:note_history:38]
Remaining unsatisfied performance obligations, which we refer to as backlog, represent the estimated transaction price for goods and services for which we have a material right, but work has not been performed. As of June 30, 2022, we had backlog of $502.5 million, of which approximately $379.6 million is expected to be recognized as revenue within the next twelve months. Backlog may not be indicative of future operating results as orders may be cancelled or modified by our customers. Our backlog does not include service and maintenance-type contracts for which we have the right to invoice as services are performed.

- added (2023-02-01):
[0000080420-23-000007:note_history:39]
Actual revenues and project costs may vary from previous estimates due to changes in a variety of factors. The cost estimation process is based upon the professional knowledge and experience of our engineers, project managers and financial

- changed (2023-02-01):
[0000080420-23-000007:note_history:40]
professionals. Factors that are considered in estimating the work to be completed and ultimate contract recovery include the availability and productivity of labor, the nature and complexity of the work to be performed, the availability of materials, and the effect of any delays on our project performance. We periodically review our job performance, job conditions, estimated profitability and final contract settlements, including our estimate of total costs and make revisions to costs and income in the period in which the revisions are probable and reasonably estimable. We bear the risk of cost overruns in most of our contracts, which may result in reduced profits. Whenever revisions of estimated contract costs and contract values indicate that the contract costs will exceed estimated revenues, thus creating a loss, a provision for the total estimated loss is recorded in that period.
  (was, 2022-08-03, similarity 0.8307):
[0000080420-22-000032:note_history:40]
Actual revenues and project costs may vary from previous estimates due to changes in a variety of factors. The cost estimation process is based upon the professional knowledge and experience of our engineers, project managers and financial professionals. Factors that are considered in estimating the work to be completed and ultimate contract recovery include the availability and productivity of labor, the nature and complexity of the work to be performed, the availability of materials, and the effect of any delays on our project performance. We periodically review our job performance, job conditions, estimated profitability and final contract settlements, including our estimate of total costs and make revisions to costs and income in the period in which the revisions are probable and reasonably estimable. We bear the risk of cost overruns in most of our contracts, which may result in reduced profits. Whenever revisions of estimated contract costs and contract values indicate that the contract costs will exceed estimated revenues, thus creating a loss, a provision for the total estimated loss is recorded in that period.

- changed (2023-02-01):
[0000080420-23-000007:note_history:41]
For the three months ended December 31, 2022 and 2021, our operating results were positively impacted by $3.6 million and $2.8 million, respectively, as a result of changes in contract estimates related to projects in progress at the beginning of the respective period. These changes in estimates resulted primarily from favorable project execution and negotiations of variable consideration, discussed below, as well as revenue and reduced costs recognized from project cancellations and other changes in facts and circumstances during these periods.
  (was, 2022-08-03, similarity 0.8169):
[0000080420-22-000032:note_history:41]
For the nine months ended June 30, 2022 and 2021, our operating results were positively impacted by $5.9 million and $11.4 million, respectively, as a result of changes in contract estimates related to projects in progress at the beginning of the respective period. These changes in estimates resulted primarily from favorable project execution and negotiations of variable consideration, discussed below, as well as revenue and reduced costs recognized from project cancellations and other changes in facts and circumstances during these periods. The decrease from the prior year is primarily due to the increase in direct materials cost, which we were not able to pass on to our customers for projects awarded in prior years.

- changed (2023-02-01):
[0000080420-23-000007:note_history:42]
Contract assets and liabilities as of December 31, 2022 and September 30, 2022 are summarized below (in thousands):
  (was, 2022-08-03, similarity 0.9515):
[0000080420-22-000032:note_history:42]
Contract assets and liabilities as of June 30, 2022 and September 30, 2021 are summarized below (in thousands):

- changed (2023-02-01):
[0000080420-23-000007:note_history:43]
|  | December 31, 2022 |  | September 30, 2022 |
| Contract assets | $ | 63,911 |  |  | $ | 88,351 |  |
| Contract liabilities | (133,753) |  |  | (79,857) |  |
| Net contract asset (liability) | $ | (69,842) |  |  | $ | 8,494 |  |
  (was, 2022-08-03, similarity 0.9298):
[0000080420-22-000032:note_history:43]
|  | June 30, 2022 |  | September 30, 2021 |
| Contract assets | $ | 68,245 |  |  | $ | 54,199 |  |
| Contract liabilities | (66,582) |  |  | (42,433) |  |
| Net contract asset | $ | 1,663 |  |  | $ | 11,766 |  |

- added (2023-02-01):
[0000080420-23-000007:note_history:44]
Our net contract billing position improved to a net liability at December 31, 2022 from a net asset position at September 30, 2022 primarily due to favorable contract billing milestones. To determine the amount of revenue recognized during the period from contract liabilities, we first allocate revenue to the individual contract liability balance outstanding at the beginning of the

- added (2023-02-01):
[0000080420-23-000007:note_history:45]
period until the revenue exceeds that balance. During the three months ended December 31, 2022, we recognized revenue of approximately $36.4 million that was related to contract liabilities outstanding at September 30, 2022.

- changed (2023-02-01):
[0000080420-23-000007:note_history:46]
The timing of our invoice process is typically dependent on the completion of certain milestones and contract terms and subject to agreement by our customer. Payment is typically expected within 30 days of invoice. Any uncollected invoiced amounts for our performance obligations recognized over time, including contract retentions, are recorded as accounts receivable in the Condensed Consolidated Balance Sheets. Certain contracts allow customers to withhold a small percentage of billings pursuant to retainage provisions, and such amounts are generally due upon completion of the contract and acceptance of the project by the customer. Based on our experience in recent years, the majority of these retainage balances are expected to be collected within approximately twelve months. As of December 31, 2022 and September 30, 2022, accounts receivable included retention amounts of $7.2 million and $6.9 million, respectively. Of the retained amount at December 31, 2022, $6.9 million is expected to be collected in the next twelve months and is recorded in accounts receivable. The remaining $0.3 million is recorded in other assets.
  (was, 2022-08-03, similarity 0.9892):
[0000080420-22-000032:note_history:46]
The timing of our invoice process is typically dependent on the completion of certain milestones and contract terms and subject to agreement by our customer.  Payment is typically expected within 30 days of invoice. Any uncollected invoiced amounts for our performance obligations recognized over time, including contract retentions, are recorded as accounts receivable in the Condensed Consolidated Balance Sheets. Certain contracts allow customers to withhold a small percentage of billings pursuant to retainage provisions, and such amounts are generally due upon completion of the contract and acceptance of the project by the customer. Based on our experience in recent years, the majority of these retainage balances are expected to be collected within approximately twelve months. As of June 30, 2022 and September 30, 2021, accounts receivable included retention amounts of $9.2 million and $9.6 million, respectively. Of the retained amount at June 30, 2022, $8.6 million is expected to be collected in the next twelve months and is recorded in accounts receivable. The remaining $0.6 million is recorded in other assets.

- changed (2023-02-01):
[0000080420-23-000007:note_history:47]
The following tables present our disaggregated revenue by geographic destination and market sector for the three months ended December 31, 2022 and 2021 (in thousands):
  (was, 2022-08-03, similarity 0.9415):
[0000080420-22-000032:note_history:47]
The following tables present our disaggregated revenue by geographic destination and market sector for the three and nine months ended June 30, 2022 and 2021 (in thousands):

- changed (2023-02-01):
[0000080420-23-000007:note_history:48]
|  | Three months ended December 31, |  |  |
|  | 2022 |  | 2021 |  |  |  |  |
| United States | $ | 100,112 |  |  | $ | 82,145 |  |  |  |  |  |
| Canada | 18,496 |  |  | 15,125 |  |  |  |  |  |
| Europe, Middle East and Africa | 6,559 |  |  | 7,830 |  |  |  |  |  |
| Asia/Pacific | 776 |  |  | 944 |  |  |  |  |  |
| Mexico, Central and South America | 915 |  |  | 525 |  |  |  |  |  |
| Total revenues by geographic destination | $ | 126,858 |  |  | $ | 106,569 |  |  |  |  |  |
  (was, 2022-08-03, similarity 0.6012):
[0000080420-22-000032:note_history:48]
|  | Three months ended June 30, |  | Nine months ended June 30, |
|  | 2022 |  | 2021 |  | 2022 |  | 2021 |
| United States | $ | 102,931 |  |  | $ | 88,412 |  |  | $ | 272,069 |  |  | $ | 256,937 |  |
| Canada | 23,599 |  |  | 16,529 |  |  | 60,777 |  |  | 48,354 |  |
| Europe, Middle East and Africa | 6,697 |  |  | 8,926 |  |  | 30,078 |  |  | 28,120 |  |
| Asia/Pacific | 1,645 |  |  | 1,651 |  |  | 4,235 |  |  | 6,376 |  |
| Mexico, Central and South America | 611 |  |  | 295 |  |  | 2,748 |  |  | 1,318 |  |
| Total revenues by geographic destination | $ | 135,483 |  |  | $ | 115,813 |  |  | $ | 369,907 |  |  | $ | 341,105 |  |

- changed (2023-02-01):
[0000080420-23-000007:note_history:49]
|  | Three months ended December 31, |  |  |
|  | 2022 |  | 2021 |  |  |  |  |
| Oil and gas (excludes petrochemical) | $ | 43,510 |  |  | $ | 43,021 |  |  |  |  |  |
| Petrochemical | 22,490 |  |  | 17,228 |  |  |  |  |  |
| Electric utility | 28,407 |  |  | 21,533 |  |  |  |  |  |
| Traction power | 7,072 |  |  | 11,372 |  |  |  |  |  |
| Commercial and other industrial | 17,050 |  |  | 5,646 |  |  |  |  |  |
| All others | 8,329 |  |  | 7,769 |  |  |  |  |  |
| Total revenues by market sector | $ | 126,858 |  |  | $ | 106,569 |  |  |  |  |  |
  (was, 2022-08-03, similarity 0.6428):
[0000080420-22-000032:note_history:49]
|  | Three months ended June 30, |  | Nine months ended June 30, |
|  | 2022 |  | 2021 |  | 2022 |  | 2021 |
| Oil and gas (excludes petrochemical) | $ | 58,669 |  |  | $ | 49,272 |  |  | $ | 155,324 |  |  | $ | 139,443 |  |
| Petrochemical | 15,187 |  |  | 15,365 |  |  | 51,268 |  |  | 34,725 |  |
| Electric utility | 30,173 |  |  | 26,175 |  |  | 82,079 |  |  | 82,797 |  |
| Traction power | 9,775 |  |  | 13,821 |  |  | 31,200 |  |  | 42,322 |  |
| All others | 21,679 |  |  | 11,180 |  |  | 50,036 |  |  | 41,818 |  |
| Total revenues by market sector | $ | 135,483 |  |  | $ | 115,813 |  |  | $ | 369,907 |  |  | $ | 341,105 |  |

- removed (2023-02-01):
[0000080420-22-000032:note_history:50]
Some contracts may contain a cancellation clause that could limit the amount of revenue we are able to recognize over time. In these instances, revenue and costs associated with these contracts are deferred and recognized at a point in time when the performance obligation is fulfilled.

- removed (2023-02-01):
[0000080420-22-000032:note_history:51]
The decrease in net contract asset at June 30, 2022 from September 30, 2021 was primarily due to the timing of contract billing milestones and new orders as well as cash used on our large industrial project awarded in Fiscal 2020. To determine the amount of revenue recognized during the period from contract liabilities, we first allocate revenue to the individual contract liability balance outstanding at the beginning of the period until the revenue exceeds that balance. During the nine months ended June 30, 2022, we recognized revenue of approximately $36.0 million that was related to contract liabilities outstanding at September 30, 2021.


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: tag_name, score: 1.0

- added (2023-02-01):
[0000080420-23-000007:note_history:52]
On January 31, 2023, our Board of Directors approved a 1% increase to the quarterly cash dividend on our common stock to $0.2625 per share, equating to an annualized dividend of $1.05 per share from the current amount of $1.04 per share. The dividend is payable on March 15, 2023 to shareholders of record at the close of business on February 15, 2023.

- removed (2023-02-01):
[0000080420-22-000032:note_history:53]
On August 2, 2022, our Board of Directors declared a quarterly cash dividend on our common stock in the amount of $0.26 per share. The dividend is payable on September 21, 2022 to shareholders of record at the close of business on August 17, 2022.
