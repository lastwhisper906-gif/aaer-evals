# POWL MD&A — 0000080420-17-000020


## mdna

[0000080420-17-000020:mdna:1]
[same as prior period, unchanged from 0000080420-17-000009:mdna:1]

[0000080420-17-000020:mdna:2]
[same as prior period, unchanged from 0000080420-17-000009:mdna:2]

[0000080420-17-000020:mdna:3]
[same as prior period, unchanged from 0000080420-17-000009:mdna:3]

[0000080420-17-000020:mdna:4]
[same as prior period, unchanged from 0000080420-17-000009:mdna:4]

[0000080420-17-000020:mdna:5]
The markets in which we participate are capital intensive and cyclical in nature. Cyclicality is predominantly driven by customer demand, global economic conditions and anticipated environmental, safety or regulatory changes that affect the manner in which our customers proceed with capital investments. Our customers analyze various factors including the demand and price for oil, gas and electrical energy, the overall economic and financial environment, governmental budgets, regulatory actions and environmental concerns. These factors influence the release of new capital projects by our customers, which are traditionally awarded in competitive bid situations. Scheduling of projects is matched to the customer requirements and projects typically take a number of months to produce.  Schedules may change during the course of any particular project and our operating results can therefore be impacted by factors outside of our control. Due to the significant decline in oil and gas prices from late 2014 levels, many of our customers have reduced their capital budgets and cut costs, and in certain instances have delayed or cancelled projects that we were pursuing.  As a result, our project backlog has declined, and may continue to decline, which may further negatively impact our operations. In response to our reduced project backlog and the challenging market outlook in our core oil, gas and petrochemical markets, we took steps in Fiscal 2016, and have taken additional actions in Fiscal 2017, to reduce our overall cost structure and better align our costs with future production requirements.

[0000080420-17-000020:mdna:6]
[same as prior period, unchanged from 0000080420-17-000009:mdna:7]

[0000080420-17-000020:mdna:7]
Quarter Ended June 30, 2017 Compared to the Quarter Ended June 30, 2016 (Unaudited)

[0000080420-17-000020:mdna:8]
[same as prior period, unchanged from 0000080420-17-000009:mdna:9]

[0000080420-17-000020:mdna:9]
Revenues decreased by 35%, or $47.3 million, to $85.9 million in the third quarter of Fiscal 2017, compared to the third quarter of Fiscal 2016, primarily due to the continued decrease in our project backlog as we complete existing projects and continue to see lower demand from our customers in our core oil, gas and petrochemical markets. Domestic revenues decreased by 41%, or $38.9 million, to $55.1 million in the third quarter of Fiscal 2017, compared to the third quarter of Fiscal 2016, and international revenues decreased by 21%, or $8.4 million, to $30.8 million in the third quarter of Fiscal 2017, compared to the third quarter of Fiscal 2016. This reduction in geographic revenues year over year was driven by the decline in our project backlog mentioned above. Revenues from commercial and industrial customers decreased by 52%, or $51.7 million, to $48.0 million in the third quarter of Fiscal 2017, compared to the third quarter of Fiscal 2016, primarily due to lower demand in our core oil, gas and petrochemical markets. Revenues from public and private utilities increased by 25%, or $5.7 million, to $28.5 million in the third quarter of Fiscal 2017, compared to the third quarter of Fiscal 2016. Revenues from municipal and transit projects decreased by 12%, or $1.2 million, to $9.5 million in the third quarter of Fiscal 2017, compared to the third quarter of Fiscal 2016. The decrease in municipal and transit revenues is primarily due to the timing of projects.

[0000080420-17-000020:mdna:10]
Gross profit for the third quarter of Fiscal 2017 decreased by 67%, or $18.2 million, to $9.1 million, compared to the third quarter of Fiscal 2016, primarily due to lower revenues resulting in underutilization of our manufacturing facilities and increased market price pressures.  Gross profit as a percentage of revenues decreased to 11% in the third quarter of Fiscal 2017, compared to 20% in the third quarter of Fiscal 2016 due to the reduction in revenues, underutilization of our manufacturing facilities and market price pressures, partially offset by favorable project execution. However, we continue to see improvement in gross profit margins from project execution as we close out certain projects resulting in changes in contract estimates.

[0000080420-17-000020:mdna:11]
[same as prior period, unchanged from 0000080420-17-000009:mdna:13]

[0000080420-17-000020:mdna:12]
Selling, general and administrative expenses decreased by 24%, or $4.6 million, to $14.8 million during the third quarter of Fiscal 2017, compared to the third quarter of Fiscal 2016, primarily due to the cost reduction efforts we took in Fiscal 2016 in response to our adverse market outlook and lower incentive compensation expenses. Selling, general and administrative expenses, as a

[0000080420-17-000020:mdna:13]
percentage of revenues, increased to 17% during the third quarter of Fiscal 2017, compared to 15% during the third quarter of Fiscal 2016, primarily due to the reduction in revenue quarter over quarter.

[0000080420-17-000020:mdna:14]
[same as prior period, unchanged from 0000080420-17-000009:mdna:15]

[0000080420-17-000020:mdna:15]
We did not incur any restructuring costs in the third quarter of Fiscal 2017. However, in the third quarter of Fiscal 2016, we incurred approximately $0.4 million of separation costs as we continued to align our workforce with future production requirements, with another approximately $0.3 million of restructuring costs related to a leased Canadian facility that we exited in the third quarter of Fiscal 2015.

[0000080420-17-000020:mdna:16]
[same as prior period, unchanged from 0000080420-17-000009:mdna:17]

[0000080420-17-000020:mdna:17]
We recorded an income tax benefit of $3.7 million in the third quarter of Fiscal 2017, compared to an income tax provision of $1.2 million in the third quarter of Fiscal 2016. The effective tax rate for the third quarter of Fiscal 2017 was 53% compared to an effective tax rate of 19% in the third quarter of Fiscal 2016. The effective tax rates for the third quarter of Fiscal 2017 and 2016 were favorably impacted by the utilization of net operating loss carryforwards in Canada that are fully reserved with a valuation allowance. In addition, the effective tax rate for the third quarter of Fiscal 2017 was favorably impacted by discrete items recognized during the quarter, primarily related to the Research and Development Tax Credit (R&D Tax Credit).

[0000080420-17-000020:mdna:18]
[same as prior period, unchanged from 0000080420-17-000009:mdna:19]

[0000080420-17-000020:mdna:19]
In the third quarter of Fiscal 2017, we recorded a loss of $3.2 million, or $0.28 per diluted share compared to income of $4.9 million, or $0.43 per diluted share, in the third quarter of Fiscal 2016. The reduction in revenue and gross profit compared to the third quarter of Fiscal 2016 was due to a decline in project backlog due to weak market conditions and competitive pricing pressures, primarily in our core oil, gas and petrochemical markets.

[0000080420-17-000020:mdna:20]
[same as prior period, unchanged from 0000080420-17-000009:mdna:21]

[0000080420-17-000020:mdna:21]
The order backlog at June 30, 2017 was $232.9 million, which declined from $291.4 million at September 30, 2016.  New orders increased during the third quarter of Fiscal 2017 to $90.7 million, compared to $88.1 million in the third quarter of Fiscal 2016.

[0000080420-17-000020:mdna:22]
Nine Months Ended June 30, 2017 Compared to the Nine Months Ended June 30, 2016 (Unaudited)

[0000080420-17-000020:mdna:23]
[same as prior period, unchanged from 0000080420-17-000009:mdna:24]

[0000080420-17-000020:mdna:24]
Revenues decreased by 31% or $134.5 million, to $300.9 million for the nine months ended June 30, 2017, compared to the nine months ended June 30, 2016, primarily due to the continued decrease in our project backlog as we complete existing projects and continue to see lower demand from our customers in our core oil, gas and petrochemical markets. Domestic revenues decreased by 29%, or $89.9 million, to $216.3 million for the nine months ended June 30, 2017, compared to the nine months ended June 30, 2016, and international revenues decreased by 34% or $44.6 million, to $84.7 million for the nine months ended June 30, 2017, compared to the nine months ended June 30, 2016. This reduction in geographic revenues year over year was driven by the decline in our project backlog mentioned above. Revenues from commercial and industrial customers decreased by 42%, or $137.3 million, to $190.6 million for the nine months ended June 30, 2017, compared to the nine months ended June 30, 2016, primarily due to lower demand in our core oil, gas and petrochemical markets. Revenues from public and private utilities decreased by 22%, or $16.9 million, to $61.0 million for the nine months ended June 30, 2017, compared to the nine months ended June 30, 2016. The decrease in utility revenues was primarily due to the timing of projects. Revenues from municipal and transit projects increased by 67%, or $19.7 million, to $49.4 million for the nine months ended June 30, 2017, compared to the nine months ended June 30, 2016.

[0000080420-17-000020:mdna:25]
Gross profit for the nine months ended June 30, 2017 decreased by 50%, or $40.7 million, to $39.9 million, compared to the nine months ended June 30, 2016, primarily due to the decrease in revenues.  Gross profit as a percentage of revenues decreased to 13% for the nine months ended June 30, 2017, compared to 18% for the nine months ended June 30, 2016. We continue to see improvements in gross profit margins from our Canadian operations and from project execution as we close out certain projects resulting in changes in contract estimates. Margins continued to be negatively impacted by our reduced volume as a result of weak oil and gas market conditions, competitive pricing pressures and increased volume from our municipal transit projects, which typically have lower margins.

[0000080420-17-000020:mdna:26]
[same as prior period, unchanged from 0000080420-17-000009:mdna:27]

[0000080420-17-000020:mdna:27]
Selling, general and administrative expenses decreased by 20%, or $11.3 million, to $46.5 million for the nine months ended June 30, 2017, compared to the nine months ended June 30, 2016, primarily due to the cost reduction efforts we took in Fiscal 2016 in response to our reduced project backlog and adverse market outlook and reductions in incentive compensation. Selling, general and administrative expenses, as a percentage of revenues, increased to 15% for the nine months ended June 30, 2017, compared to 13% for the nine months ended June 30, 2016, primarily due to the reduction in revenue discussed above.

[0000080420-17-000020:mdna:28]
[same as prior period, unchanged from 0000080420-17-000009:mdna:29]

[0000080420-17-000020:mdna:29]
For the nine months ended June 30, 2017, we incurred $0.8 million in restructuring and separation costs as we continue to reduce our overall cost structure to better align our costs with future production requirements. For the nine months ended June 30, 2016, we incurred $7.7 million of separation costs due to the realignment of our senior management team and workforce reductions.

[0000080420-17-000020:mdna:30]
[same as prior period, unchanged from 0000080420-17-000009:mdna:31]

[0000080420-17-000020:mdna:31]
We recorded an income tax benefit of $6.5 million for the nine months ended June 30, 2017, compared to an income tax provision of $0.8 million for the nine months ended June 30, 2016.  The effective tax rate for the nine months ended June 30, 2017 was 60% compared to 8% for nine months ended June 30, 2016. The effective tax rates for the nine months ended June 30, 2017 and 2016 were favorably impacted by the lower tax rate in the United Kingdom, the relative amounts of income/loss recognized in various jurisdictions, as well as the utilization of net operating loss carryforwards in Canada that are fully reserved with a valuation allowance. Additionally, the effective tax rates for the nine months ended June 30, 2017 and 2016 were favorably impacted by discrete items recognized, primarily related to the R&D Tax Credit in the amounts of $0.9 million and $0.8 million, respectively.

[0000080420-17-000020:mdna:32]
[same as prior period, unchanged from 0000080420-17-000009:mdna:33]

[0000080420-17-000020:mdna:33]
For the nine months ended June 30, 2017, we recorded a loss of $4.3 million, or $0.38 per diluted share compared to income of $10.0 million, or $0.87 per diluted share, for the nine months ended June 30, 2016. The reduction in revenue and gross profit compared to the nine months ended June 30, 2016 was due to a decline in our project backlog due to depressed market conditions and competitive pricing pressures, primarily in our core oil, gas and petrochemical markets.

[0000080420-17-000020:mdna:34]
[same as prior period, unchanged from 0000080420-17-000009:mdna:35]

[0000080420-17-000020:mdna:35]
The order backlog at June 30, 2017 was $232.9 million, which declined from $291.4 million at September 30, 2016.  New orders declined during the nine months ended June 30, 2017 to $243.5 million, compared to $306.7 million for the nine months ended June 30, 2016, primarily due to lower demand from our customers in our core oil, gas and petrochemical markets.

[0000080420-17-000020:mdna:36]
[same as prior period, unchanged from 0000080420-17-000009:mdna:37]

[0000080420-17-000020:mdna:37]
As of June 30, 2017, current assets exceeded current liabilities by 2.9 times and our debt to total capitalization was 0.61%.

[0000080420-17-000020:mdna:38]
Cash, cash equivalents and short-term investments decreased to $87.8 million at June 30, 2017, compared to $97.7 million at September 30, 2016. In addition, at June 30, 2017, we had cash of $25.3 million held in a pledged collateral account related to our amended credit agreement. As of September 30, 2016, we did not have any cash balances classified as restricted. For further information regarding this amended credit agreement, see Note E of Notes to Condensed Consolidated Financial Statements.

[0000080420-17-000020:mdna:39]
We have a $75.0 million revolving credit facility in the U.S. As of June 30, 2017, there were no amounts borrowed under this line of credit. Total letters of credit outstanding under our U.S. credit facility, which reduce our availability, were $24.6 million at June 30, 2017 and $26.8 million at September 30, 2016. The amount available under the U.S. revolving credit facility at June 30, 2017 was $50.4 million. Total long-term debt, including current maturities, totaled $2.0 million at June 30, 2017, compared to $2.4 million at September 30, 2016. For further information regarding our debt, see Notes E and F of Notes to Condensed Consolidated Financial Statements.

[0000080420-17-000020:mdna:40]
Approximately $33 million of our cash and short-term investments at June 30, 2017 was held outside of the United States for international operations. It is our intention to indefinitely reinvest all current and future foreign earnings internationally in order to ensure sufficient working capital to support our international operations. In the event that we elect to repatriate some or all of the foreign earnings that were previously deemed to be indefinitely reinvested outside the U.S., under current tax laws we would incur additional tax expense upon such repatriation.

[0000080420-17-000020:mdna:41]
We believe that cash and short-term investments available and borrowing capacity under our existing credit facility should be sufficient to finance future operating activities, capital improvements and debt repayments for the foreseeable future. We continue to monitor the factors that drive our markets and will continue to strive to maintain our leadership and competitive advantage in the markets we serve while aligning our cost structures with market conditions.

[0000080420-17-000020:mdna:42]
[same as prior period, unchanged from 0000080420-17-000009:mdna:43]

[0000080420-17-000020:mdna:43]
Cash provided by operating activities decreased to $27.1 million for the nine months ended June 30, 2017, compared to cash provided by operating activities of $61.8 million during the same period in Fiscal 2016. This decrease in operating cash flow in the nine months ended June 30, 2017 was primarily from the reduction in earnings year over year, partially offset by reductions in accounts receivable and project billings due to lower project activity. Cash flow from operations is primarily influenced by the timing of milestone payments from our customers and the payment terms with our suppliers.

[0000080420-17-000020:mdna:44]
[same as prior period, unchanged from 0000080420-17-000009:mdna:45]

[0000080420-17-000020:mdna:45]
Net cash used in investing activities during the nine months ended June 30, 2017 totaled $83.2 million compared to $1.9 million during the same period in Fiscal 2016.  For the nine months ended June 30, 2017, our net short-term investment activity was $55.4 million and we spent approximately $2.5 million on purchases of plant improvements and equipment.  Additionally, we transferred approximately $25 million to restricted cash as it is pledged to secure 102% of our outstanding letters of credit under our U.S. revolving credit facility.

[0000080420-17-000020:mdna:46]
[same as prior period, unchanged from 0000080420-17-000009:mdna:47]

[0000080420-17-000020:mdna:47]
Net cash used in financing activities was $9.7 million for the nine months ended June 30, 2017 and $14.0 million during the same period in Fiscal 2016. This reduction was primarily due to the completion of our share repurchase program in December 2015 discussed below.

[0000080420-17-000020:mdna:48]
[same as prior period, unchanged from 0000080420-17-000009:mdna:49]

[0000080420-17-000020:mdna:49]
[same as prior period, unchanged from 0000080420-17-000009:mdna:50]

[0000080420-17-000020:mdna:50]
[same as prior period, unchanged from 0000080420-17-000009:mdna:51]

[0000080420-17-000020:mdna:51]
[same as prior period, unchanged from 0000080420-17-000009:mdna:52]

[0000080420-17-000020:mdna:52]
[same as prior period, unchanged from 0000080420-17-000009:mdna:53]

[0000080420-17-000020:mdna:53]
[same as prior period, unchanged from 0000080420-17-000009:mdna:54]

[0000080420-17-000020:mdna:54]
[same as prior period, unchanged from 0000080420-17-000009:mdna:55]

[0000080420-17-000020:mdna:55]
[same as prior period, unchanged from 0000080420-17-000009:mdna:56]

[0000080420-17-000020:mdna:56]
[same as prior period, unchanged from 0000080420-17-000009:mdna:57]

[0000080420-17-000020:mdna:57]
A significant portion of our revenues have historically been from the oil, gas and petrochemical markets. Unfavorable oil and gas commodity price levels have caused, and may continue to cause, our customers to change their investment strategies or delay or cancel planned projects. The reduction in available projects across the markets we serve has increased price pressures during this downward market cycle. This reduction in new business opportunities and increased market price pressures have impacted, and will continue to negatively impact, our backlog, revenues and operating results. It is difficult to predict the duration of the current depressed market cycle.

[0000080420-17-000020:mdna:58]
Our operating results have been, and may continue to be, negatively impacted by factors such as the timing of new order awards, customer approval of final engineering and design specifications and delays in customer construction schedules, all of which have and may continue to have, a negative impact on the timing of project execution. Our operating results also have been, and may continue to be, impacted by the timing and resolution of change orders, project close-out and resolution of potential contract claims and liquidated damages, all of which could improve or deteriorate gross margins during the period in which these items are resolved with our customers. These factors may result in periods of underutilization of our resources and facilities and negatively impact our ability to cover our fixed costs. If our core oil, gas and petrochemical markets remain depressed, or decline further, our project backlog could continue to decline and negatively impact our operations. In response to our reduced project backlog and depressed market outlook, we took steps in Fiscal 2016, and have taken additional actions in Fiscal 2017, to reduce our overall cost structure and better align our costs with future production requirements. We continue to assess our cost structure, operating performance and service offerings as the oil, gas and petrochemical markets remain challenging and uncertain. However, these actions will not be sufficient to avoid operating losses in the near-term and we expect to report a net loss in Fiscal 2017.

[0000080420-17-000020:mdna:59]
We believe that our strong working capital position, cash available, low debt position and borrowing capacity under our existing credit facility should be sufficient to finance future operating activities, research and development initiatives, capital improvements and debt repayments for the foreseeable future. We continue to monitor the factors that drive our markets and will continue to strive to maintain our leadership and competitive advantage in the markets we serve while aligning our cost structures with market conditions.
