# POWL notes — 0000080420-17-000020


## us-gaap:AllowanceForCreditLossesOnFinancingReceivablesTableTextBlock

[0000080420-17-000020:notes:1]
[same as prior period, unchanged from 0000080420-17-000009:notes:1]

[0000080420-17-000020:notes:2]
|  | Three months ended June 30, |  | Nine months ended June 30, |
|  | 2017 |  | 2016 |  | 2017 |  | 2016 |
| Balance at beginning of period | $ | 310 |  |  | $ | 976 |  |  | $ | 811 |  |  | $ | 746 |  |
| Bad debt expense (recovery) | (129 | ) |  | (118 | ) |  | (226 | ) |  | 221 |  |
| Uncollectible accounts written off, net of recoveries | (92 | ) |  | 16 |  |  | (493 | ) |  | (98 | ) |
| Change due to foreign currency translation | 1 |  |  | (3 | ) |  | (2 | ) |  | 2 |  |
| Balance at end of period | $ | 90 |  |  | $ | 871 |  |  | $ | 90 |  |  | $ | 871 |  |


## us-gaap:BasisOfAccountingPolicyPolicyTextBlock

[0000080420-17-000020:notes:3]
[same as prior period, unchanged from 0000080420-17-000009:notes:3]

[0000080420-17-000020:notes:4]
[same as prior period, unchanged from 0000080420-17-000009:notes:4]

[0000080420-17-000020:notes:5]
These unaudited condensed consolidated financial statements have been prepared in accordance with the instructions to Form 10-Q and Rule 10-01 of Regulation S-X for interim financial information.  Certain information and footnote disclosures, normally included in annual financial statements prepared in accordance with accounting principles generally accepted in the United States (U.S. GAAP), have been condensed or omitted pursuant to those rules and regulations. In the opinion of management, all adjustments, consisting only of normal recurring adjustments, necessary to fairly state the financial position, results of operations and cash flows with respect to the interim condensed consolidated financial statements have been included. The results of operations for the interim periods are not necessarily indicative of the results for the entire fiscal year.  We believe that these financial statements contain all adjustments necessary so that they are not misleading.

[0000080420-17-000020:notes:6]
[same as prior period, unchanged from 0000080420-17-000009:notes:6]

[0000080420-17-000020:notes:7]
[same as prior period, unchanged from 0000080420-17-000009:notes:7]


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0000080420-17-000020:notes:8]
COMMITMENTS AND CONTINGENCIES

[0000080420-17-000020:notes:9]
Letters of Credit and Surety Bonds

[0000080420-17-000020:notes:10]
Certain customers require us to post bank letter of credit guarantees or surety bonds. These guarantees and surety bonds assure that we will perform under the terms of our contract. In the event of default, the counterparty may demand payment from the bank under a letter of credit or performance by the surety under a bond. To date, there have been no significant expenses related to either letters of credit or surety bonds for the periods reported. We were contingently liable for secured and unsecured letters of credit of $24.6 million as of June 30, 2017. We also had surety bonds totaling $221.7 million that were outstanding, with additional bonding capacity of $528.3 million available, at June 30, 2017.

[0000080420-17-000020:notes:11]
We have a $6.5 million facility agreement (Facility Agreement) between Powell (UK) Limited and a large international bank. This Facility Agreement provides Powell (UK) Limited the ability to enter into bank guarantees as well as forward exchange contracts and currency options. At June 30, 2017, we had outstanding guarantees totaling $4.2 million under this Facility Agreement and amounts available under this Facility Agreement were $2.3 million.  This facility expires in May 2018. The Facility Agreement provides for financial covenants and customary events of default, and carries cross-default provisions with our U.S. Revolver. If an event of default (as defined in the Facility Agreement) occurs and is continuing, per the terms and subject to the conditions set forth therein, obligations outstanding under the Facility Agreement may be accelerated and may become or be declared immediately due and payable. As of June 30, 2017, we were in compliance with all of the financial covenants of the Facility Agreement.

[0000080420-17-000020:notes:12]
Litigation

[0000080420-17-000020:notes:13]
We are involved in various legal proceedings, claims and other disputes arising from our commercial operations, projects, employees and other matters which, in general, are subject to uncertainties and in which the outcomes are not predictable. Although we can give no assurances about the resolution of pending claims, litigation or other disputes and the effect such outcomes may have on us, management believes that any ultimate liability resulting from the outcome of such proceedings, to the extent not otherwise provided or covered by insurance, will not have a material adverse effect on our consolidated financial position or results of operations or liquidity.

[0000080420-17-000020:notes:14]
Liquidated Damages

[0000080420-17-000020:notes:15]
Certain of our customer contracts have schedule and performance obligation clauses that, if we fail to meet them, could require us to pay liquidated damages. Each individual contract defines the conditions under which the customer may make a claim against us. As of June 30, 2017, our exposure to possible liquidated damages was $6.8 million, of which approximately $1.5 million is probable.  Based on our actual or projected failure to meet these various contractual commitments, $1.5 million has been recorded as a reduction to revenue. We will attempt to obtain change orders, contract extensions or accelerate project completion which may resolve the potential for any unaccrued liquidated damage. Should we fail to achieve relief on some or all of these contractual obligations, we could be required to pay additional liquidated damages, which could negatively impact our future operating results.


## us-gaap:CostsInExcessOfBillingsAndBillingsInExcessOfCostsTableTextBlock

[0000080420-17-000020:notes:16]
[same as prior period, unchanged from 0000080420-17-000009:notes:18]

[0000080420-17-000020:notes:17]
|  | June 30, 2017 |  | September 30, 2016 |
| Costs incurred on uncompleted contracts | $ | 1,025,641 |  |  | $ | 1,088,921 |  |
| Estimated earnings | 334,072 |  |  | 350,125 |  |
|  | 1,359,713 |  |  | 1,439,046 |  |
| Less: Billings to date | (1,355,468 | ) |  | (1,416,914 | ) |
| Net underbilled position | $ | 4,245 |  |  | $ | 22,132 |  |
| Included in the accompanying balance sheets under the following captions: |  |  |  |
| Costs and estimated earnings in excess of billings on uncompleted contracts | $ | 46,127 |  |  | $ | 66,106 |  |
| Billings in excess of costs and estimated earnings on uncompleted contracts | (41,882 | ) |  | (43,974 | ) |
| Net underbilled position | $ | 4,245 |  |  | $ | 22,132 |  |


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0000080420-17-000020:notes:18]
[same as prior period, unchanged from 0000080420-17-000009:notes:20]

[0000080420-17-000020:notes:19]
[same as prior period, unchanged from 0000080420-17-000009:notes:21]

[0000080420-17-000020:notes:20]
[same as prior period, unchanged from 0000080420-17-000009:notes:22]

[0000080420-17-000020:notes:21]
We issue restricted stock units (RSUs) to certain officers and key employees of the Company.  The fair value of the RSUs is based on the closing price of our common stock as reported on the NASDAQ Global Market on the grant dates. These grants vest over a three-year period from their date of issuance.  Sixty percent of the grant is time-based and vests over a three-year period on each anniversary of the grant date, based on continued employment.  The remaining forty percent of the grant will be earned based on the three-year earnings performance of the Company following the grant date. At June 30, 2017, there were 194,537 RSUs outstanding. The RSUs do not have voting rights but do receive dividend equivalents upon vesting; additionally, the shares of common stock underlying the RSUs are not considered issued and outstanding until vested and common stock is issued.

[0000080420-17-000020:notes:22]
RSU activity (number of shares) for the nine months ended June 30, 2017 is summarized below:

[0000080420-17-000020:notes:23]
|  | Number ofRestrictedStockUnits |  | WeightedAverageFair ValuePer Share |
| Outstanding at September 30, 2016 | 159,988 |  |  | $ | 43.12 |  |
| Granted | 62,100 |  |  | 39.57 |  |
| Vested | (27,551 | ) |  | 39.08 |  |
| Outstanding at June 30, 2017 | 194,537 |  |  | $ | 42.56 |  |

[0000080420-17-000020:notes:24]
During the nine months ended June 30, 2017 and 2016, we recorded compensation expense of $1.7 million and $3.7 million, respectively, related to the RSUs.  The higher compensation expense recorded in the nine months ended June 30, 2016 was primarily due to the early vesting of shares associated with executive separation costs, see Note J.

[0000080420-17-000020:notes:25]
[same as prior period, unchanged from 0000080420-17-000009:notes:27]

[0000080420-17-000020:notes:26]
[same as prior period, unchanged from 0000080420-17-000009:notes:28]

[0000080420-17-000020:notes:27]
During the nine months ended June 30, 2017 and 2016, we recorded compensation expense of $0.6 million, respectively, related to restricted stock grants.


## us-gaap:EarningsPerShareTextBlock

[0000080420-17-000020:notes:28]
[same as prior period, unchanged from 0000080420-17-000009:notes:30]

[0000080420-17-000020:notes:29]
[same as prior period, unchanged from 0000080420-17-000009:notes:31]

[0000080420-17-000020:notes:30]
[same as prior period, unchanged from 0000080420-17-000009:notes:32]

[0000080420-17-000020:notes:31]
|  | Three months ended June 30, |  | Nine months ended June 30, |
|  | 2017 |  | 2016 |  | 2017 |  | 2016 |
| Numerator: |  |  |  |  |  |  |  |
| Net income (loss) | $ | (3,215 | ) |  | $ | 4,894 |  |  | $ | (4,343 | ) |  | $ | 10,002 |  |
| Denominator: |  |  |  |  |  |  |  |
| Weighted average basic shares | 11,463 |  |  | 11,397 |  |  | 11,449 |  |  | 11,387 |  |
| Dilutive effect of restricted stock units | — |  |  | 76 |  |  | — |  |  | 48 |  |
| Weighted average diluted shares with assumed conversions | 11,463 |  |  | 11,473 |  |  | 11,449 |  |  | 11,435 |  |
| Net income (loss) per share: |  |  |  |  |  |  |  |
| Basic | $ | (0.28 | ) |  | $ | 0.43 |  |  | $ | (0.38 | ) |  | $ | 0.88 |  |
| Diluted | $ | (0.28 | ) |  | $ | 0.43 |  |  | $ | (0.38 | ) |  | $ | 0.87 |  |

[0000080420-17-000020:notes:32]
For the quarter and nine months ended June 30, 2017, we incurred net losses and therefore all potential common shares were deemed to be anti-dilutive.


## us-gaap:FairValueDisclosuresTextBlock

[0000080420-17-000020:notes:33]
[same as prior period, unchanged from 0000080420-17-000009:notes:35]

[0000080420-17-000020:notes:34]
[same as prior period, unchanged from 0000080420-17-000009:notes:36]

[0000080420-17-000020:notes:35]
[same as prior period, unchanged from 0000080420-17-000009:notes:37]

[0000080420-17-000020:notes:36]
[same as prior period, unchanged from 0000080420-17-000009:notes:38]

[0000080420-17-000020:notes:37]
[same as prior period, unchanged from 0000080420-17-000009:notes:39]

[0000080420-17-000020:notes:38]
[same as prior period, unchanged from 0000080420-17-000009:notes:40]

[0000080420-17-000020:notes:39]
The following table summarizes the fair value of our assets and liabilities that were accounted for at fair value on a recurring basis as of June 30, 2017 (in thousands):

[0000080420-17-000020:notes:40]
|  | Fair Value Measurements at June 30, 2017 |
|  | Quoted Prices inActive Markets forIdentical Assets(Level 1) |  | Significant OtherObservableInputs(Level 2) |  | SignificantUnobservableInputs(Level 3) |  | Fair Value at June 30, 2017 |
| Assets: |  |  |  |  |  |  |  |
| Cash equivalents | $ | 336 |  |  | $ | — |  |  | $ | — |  |  | $ | 336 |  |
| Short-term investments | 55,364 |  |  | — |  |  | — |  |  | 55,364 |  |
| Restricted cash | 25,301 |  |  | — |  |  | — |  |  | 25,301 |  |
| Deferred compensation | 793 |  |  | 5,445 |  |  | — |  |  | 6,238 |  |
| Liabilities: |  |  |  |  |  |  |  |
| Deferred compensation | — |  |  | 4,734 |  |  | — |  |  | 4,734 |  |

[0000080420-17-000020:notes:41]
[same as prior period, unchanged from 0000080420-17-000009:notes:43]

[0000080420-17-000020:notes:42]
[same as prior period, unchanged from 0000080420-17-000009:notes:44]

[0000080420-17-000020:notes:43]
[same as prior period, unchanged from 0000080420-17-000009:notes:45]

[0000080420-17-000020:notes:44]
[same as prior period, unchanged from 0000080420-17-000009:notes:46]

[0000080420-17-000020:notes:45]
[same as prior period, unchanged from 0000080420-17-000009:notes:47]

[0000080420-17-000020:notes:46]
[same as prior period, unchanged from 0000080420-17-000009:notes:48]

[0000080420-17-000020:notes:47]
Restricted Cash – Restricted cash represents a pledged cash collateral balance which is required under our recently amended credit agreement. We have classified this balance as non-current on the balance sheet. See Note E for further discussion on restricted cash.

[0000080420-17-000020:notes:48]
[same as prior period, unchanged from 0000080420-17-000009:notes:49]

[0000080420-17-000020:notes:49]
Industrial Development Revenue Bonds– The fair value of our long-term debt depends primarily on the coupon rate of our industrial development revenue bonds.  The carrying value of our long-term debt at June 30, 2017, approximates fair value based on the current coupon rate of the bonds, which is reset weekly. It is classified as a Level 2 input in the fair value measurement hierarchy as there is an active market for the trading of these industrial development revenue bonds.

[0000080420-17-000020:notes:50]
There were no transfers between levels within the fair value measurement hierarchy during the three months ended June 30, 2017.


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0000080420-17-000020:notes:51]
[same as prior period, unchanged from 0000080420-17-000009:notes:52]

[0000080420-17-000020:notes:52]
Our intangible assets consist of goodwill, which is not being amortized, and purchased technology, which is amortized over its estimated useful life.  Intangible assets balances, subject to amortization, at June 30, 2017 and September 30, 2016 consisted of the following (in thousands):

[0000080420-17-000020:notes:53]
|  | June 30, 2017 |  | September 30, 2016 |
|  | GrossCarryingValue |  | AccumulatedAmortization |  | NetCarryingValue |  | GrossCarryingValue |  | AccumulatedAmortization |  | NetCarryingValue |
| Purchased technology | $ | 11,749 |  |  | $ | (10,930 | ) |  | $ | 819 |  |  | $ | 11,749 |  |  | $ | (10,693 | ) |  | $ | 1,056 |  |

[0000080420-17-000020:notes:54]
Amortization of intangible assets was $0.3 million for the nine months ended June 30, 2017 and 2016.

[0000080420-17-000020:notes:55]
On August 7, 2006, we purchased certain assets related to the manufacturing of ANSI medium-voltage switchgear and circuit breaker business from General Electric Company (GE). In connection with the acquisition, we entered into a 15-year supply agreement with GE pursuant to which GE would purchase from us all of their requirements for ANSI medium-voltage switchgear and circuit breakers and other related equipment and components (the Products).  In connection with the acquisition, we recorded an intangible asset related to this supply agreement.  On December 30, 2013, we and GE amended the supply agreement to allow GE to manufacture similar Products for sale immediately and allow them to begin purchasing Products from other suppliers beginning December 31, 2014. In return, GE paid us $10.0 million upon execution of the amended supply agreement and agreed to pay an additional $7 million over three years, beginning March 2015. The final balance of $2.3 million was received in April 2017. We wrote off the intangible asset related to the original supply agreement and recorded a deferred credit in the amount of $8.1 million at December 31, 2013, the amount by which the proceeds from GE exceeded the unamortized balance of our intangible asset. We are amortizing this deferred credit over the four-year life of the agreement and have recognized gains in other income of $1.5 million for the nine months ended June 30, 2017 and 2016. As of June 30, 2017, there is approximately $1.0 million remaining in the deferred credit balance.


## us-gaap:IncomeTaxDisclosureTextBlock

[0000080420-17-000020:notes:56]
[same as prior period, unchanged from 0000080420-17-000009:notes:57]

[0000080420-17-000020:notes:57]
[same as prior period, unchanged from 0000080420-17-000009:notes:58]

[0000080420-17-000020:notes:58]
|  | Three months ended June 30, |  | Nine months ended June 30, |
|  | 2017 |  | 2016 |  | 2017 |  | 2016 |
| Income (loss) before income taxes | $ | (6,898 | ) |  | $ | 6,058 |  |  | $ | (10,812 | ) |  | $ | 10,846 |  |
| Income tax provision (benefit) | (3,683 | ) |  | 1,164 |  |  | (6,469 | ) |  | 844 |  |
| Net income (loss) | $ | (3,215 | ) |  | $ | 4,894 |  |  | $ | (4,343 | ) |  | $ | 10,002 |  |
| Effective tax rate | 53 | % |  | 19 | % |  | 60 | % |  | 8 | % |

[0000080420-17-000020:notes:59]
We recorded an income tax benefit of $3.7 million in the third quarter of Fiscal 2017, compared to an income tax provision of $1.2 million in the third quarter of Fiscal 2016. The effective tax rate for the third quarter of Fiscal 2017 was 53% compared to an effective tax rate of 19% in the third quarter of Fiscal 2016. The effective tax rates for the third quarter of Fiscal 2017 and 2016 were favorably impacted by the utilization of net operating loss carryforwards in Canada that are fully reserved with a valuation allowance. In addition, the effective tax rate for the third quarter of Fiscal 2017 was favorably impacted by discrete items recognized during the quarter, primarily related to the Research and Development Tax Credit (R&D Tax Credit).

[0000080420-17-000020:notes:60]
We recorded an income tax benefit of $6.5 million for the nine months ended June 30, 2017, compared to an income tax provision of $0.8 million for the nine months ended June 30, 2016. The effective tax rate was 60% for the nine months ended June 30, 2017 compared to 8% for the nine months ended June 30, 2016. The effective tax rates for the nine months ended June 30, 2017 and 2016 were favorably impacted by the lower tax rate in the United Kingdom, the relative amounts of income/loss recognized in various jurisdictions, as well as the utilization of net operating loss carryforwards in Canada that are fully reserved with a valuation allowance. Additionally, the effective tax rates for the nine months ended June 30, 2017 and 2016 were favorably impacted by discrete items recognized, primarily related to the R&D Tax Credit in the amounts of $0.9 million and $0.8 million, respectively.


## us-gaap:LongTermDebtTextBlock

[0000080420-17-000020:notes:61]
LONG-TERM DEBT

[0000080420-17-000020:notes:62]
Long-term debt consisted of the following (in thousands):

[0000080420-17-000020:notes:63]
|  | June 30, 2017 |  | September 30, 2016 |
| Industrial development revenue bonds | $ | 2,000 |  |  | $ | 2,400 |  |
| Less current portion | (400 | ) |  | (400 | ) |
| Total long-term debt | $ | 1,600 |  |  | $ | 2,000 |  |

[0000080420-17-000020:notes:64]
U.S. Revolver

[0000080420-17-000020:notes:65]
We have a $75.0 million revolving credit facility (U.S. Revolver) to provide working capital support and letters of credit. In June 2017, we entered into the Third Amendment to the Credit Agreement (the Third Amendment). The Third Amendment, among other things, (i) extended the Maturity Date from December 2018 to June 2022; (ii) amended the definition of Applicable Rate by (a) providing that Pricing Level I shall apply when a Cash Collateral Period (described below) is in effect and that Pricing Level II shall apply when no Cash Collateral Period is in effect, (b) decreasing the Letter of Credit Fee percentage for Pricing Level I from 1.00% to 0.875% and (c) increasing the Commitment Fee percentage for both Pricing Level I and Pricing Level II from 0.1875% to 0.20%; (iii) added a new requirement that during a Cash Collateral Period we maintain a cash balance in a pledged cash collateral account equal to at least 102% of the Outstanding Amount of Revolving Loans and Letter of Credit Obligations and (iv) modified the Financial Covenants by requiring that, during any Cash Collateral Period, the Consolidated Current Ratio be no less than 1.10 to 1.0. Price Level 3 has been removed and our ability to pay dividends remains subject to financial covenant restrictions.

[0000080420-17-000020:notes:66]
Generally, a Cash Collateral Period under the Third Amendment is defined as a fiscal quarter during which we have pledged our cash collateral account to the Administrative Agent. A Cash Collateral Period will terminate on the last day of the fiscal quarter in which we satisfy the Level II Pricing Covenants set forth in the Third Amendment for two consecutive fiscal quarters. If we are not in compliance with the Level II Pricing Covenants, we are subject to Level I Pricing Covenants.

[0000080420-17-000020:notes:67]
The Cash Collateral Period was in effect as of June 30, 2017, therefore we placed $25.3 million in a pledged cash collateral account, which was 102% of our outstanding letters of credit as of June 30, 2017. The cash collateral associated with the outstanding letters of credit that are due to expire beyond twelve months has been classified as non-current restricted cash on the balance sheet as of June 30, 2017.

[0000080420-17-000020:notes:68]
The interest rate for amounts outstanding under the U.S. Revolver is a floating rate based upon the higher of the Federal Funds Rate plus 0.5%, the bank’s prime rate, or the Eurocurrency rate plus 1.00%. Once the applicable rate is determined, a margin ranging up to 1.25% is added to the applicable rate. The U.S. Revolver provides for the issuance of letters of credit which reduce the amounts that may be borrowed under this revolver. We had $24.6 million of outstanding letters of credit under the U.S. Revolver at June 30, 2017.

[0000080420-17-000020:notes:69]
There were no borrowings outstanding under the U.S. Revolver as of June 30, 2017. Amounts available under the U.S. Revolver were $50.4 million at June 30, 2017. The U.S. Revolver expires on June 27, 2022.

[0000080420-17-000020:notes:70]
The U.S. Revolver is collateralized by a pledge of 100% of the voting capital stock of each of our domestic subsidiaries and 65% of the voting capital stock of each non-domestic subsidiary. The U.S. Revolver provides for customary events of default and carries cross-default provisions with other existing debt agreements. If an event of default (as defined in the U.S. Revolver) occurs and is continuing, on the terms and subject to the conditions set forth in the U.S. Revolver, amounts outstanding under the U.S. Revolver may be accelerated and may become immediately due and payable. As of June 30, 2017, we were in compliance with all of the financial covenants of the U.S. Revolver.

[0000080420-17-000020:notes:71]
Canadian Revolver

[0000080420-17-000020:notes:72]
We had a $7.7 million credit agreement with a major international bank in Canada (the Canadian Revolver) to provide working capital support and letters of credit for our operations in Canada. There were no borrowings or outstanding letters of credit under the Canadian Revolver as of June 30, 2017 and therefore subsequent to June 30, 2017, we canceled the Canadian Revolver. We believe that the cash available in Canada and the U.S. should be sufficient to fund our Canadian operations for the foreseeable future.

[0000080420-17-000020:notes:73]
Industrial Development Revenue Bonds

[0000080420-17-000020:notes:74]
We borrowed $8.0 million in October 2001 through a loan agreement funded with proceeds from tax-exempt industrial development revenue bonds (Bonds). These Bonds were issued by the Illinois Development Finance Authority and were used for the completion of our Northlake, Illinois facility. Pursuant to the Bond issuance, a reimbursement agreement between us and a major domestic bank required an issuance by the bank of an irrevocable direct-pay letter of credit (Bond LC), as collateral, to the Bonds’ trustee to guarantee payment of the Bonds’ principal and interest when due. The Bond LC is subject to both early termination and extension provisions customary to such agreements, as well as various covenants, for which we were in compliance at June 30, 2017. While the Bonds mature in 2021, the reimbursement agreement requires annual redemptions of $0.4 million that commenced on October 25, 2002. A sinking fund is used for the redemption of the Bonds. The Bonds bear interest at a floating rate determined weekly by the Bonds’ remarketing agent, which was the underwriter for the Bonds and is an affiliate of the bank. This interest rate was 1.05% as of June 30, 2017.


## us-gaap:NewAccountingPronouncementsPolicyPolicyTextBlock

[0000080420-17-000020:notes:75]
New Accounting Standards

[0000080420-17-000020:notes:76]
In May 2014, the Financial Accounting Standards Board (FASB) issued a new standard on revenue recognition that supersedes previously issued revenue recognition guidance. This standard provides a five-step approach to be applied to all contracts with customers and requires expanded disclosures about the nature, amount, timing and uncertainty of revenue (and the related cash flows) arising from customer contracts, significant judgments and changes in judgments used in applying the revenue model and the assets recognized from costs incurred to obtain or fulfill a contract. This standard is effective for fiscal years, and interim periods within those years, beginning after December 15, 2017, which would be our fiscal year ending September 30, 2019. We continue to work with various other companies in our industry as well as outside accounting advisors to evaluate this standard and understand the impact that the adoption of this new standard will have on our consolidated financial statements and related disclosures. We believe that we will continue to recognize revenue over time utilizing the cost-to-cost method to measure our progress for the vast majority of our contracts. We have not yet selected a transition method nor have we determined the effect of the standard on our ongoing financial reporting.

[0000080420-17-000020:notes:77]
In November 2015, the FASB issued an amendment to the topic regarding income taxes which requires an entity to separate deferred income tax liabilities and assets into current and noncurrent amounts in the statement of financial position.  Deferred tax liabilities and assets are classified as current or noncurrent based on the classification of the related asset or liability for financial reporting.  Deferred tax liabilities and assets that are not related to an asset or liability for financial reporting are classified according to the expected reversal date of the temporary difference. To simplify the presentation of deferred income taxes, the amendments require that deferred income tax liabilities and assets be classified as noncurrent in a classified statement of financial position.  This amendment is effective for annual reporting periods beginning after December 15, 2016, which would be our fiscal year ending September 30, 2018. We have no plans for early adoption. We are still evaluating this new amendment, but we do not expect it to have a material impact on our consolidated financial position or results of operations.

[0000080420-17-000020:notes:78]
In February 2016, the FASB issued a new topic on leases which requires lessees to recognize lease assets and lease liabilities on the balance sheet for all leases with terms longer than twelve months. Leases will be classified as either finance or operating, with classification affecting the pattern of expense recognition in the income statement. A modified retrospective transition approach is required for lessees for capital and operating leases existing at, or entered into after, the beginning of the earliest comparative period presented in the financial statements, with certain practical expedients available. The new standard is effective for fiscal years beginning after December 15, 2018, including interim periods within those fiscal years. This would be our fiscal year ending September 30, 2020.  We plan to adopt this new standard beginning in Fiscal 2018, and do not expect it to have a material impact on our consolidated financial position or results of operations.

[0000080420-17-000020:notes:79]
In November 2016, the FASB issued new standards on the statement of cash flows and restricted cash that change the presentation of restricted cash and cash equivalents on the statement of cash flows. Restricted cash and restricted cash equivalents will be included with cash and cash equivalents when reconciling the beginning-of-period and end-of-period total amounts shown on the statement of cash flows. These standards are effective for public business entities for fiscal years beginning after December 15, 2017, and interim periods within those fiscal years, which would be our fiscal year ending September 30, 2019.  We have no plans for early adoption. We are still evaluating these new standards, but we do not expect them to have a material impact on our consolidated financial position or results of operations.

[0000080420-17-000020:notes:80]
In May 2017, the FASB issued a new topic on modification accounting with regards to stock based compensation. This new topic clarifies when a change to the terms or conditions of a share-based payment award should be accounted for as a modification. An entity should account for the effects of a modification unless the fair value, vesting conditions and classification, as an equity instrument or a liability instrument, of the modified award are the same before and after a change to the terms or conditions of the share-based payment award. The standard is effective for annual reporting periods beginning after December 15, 2017, which would be our fiscal year ending September 30, 2018. We do not expect this topic to have a material impact on our consolidated financial position or results of operations.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureAndSignificantAccountingPoliciesTextBlock

[0000080420-17-000020:notes:81]
[same as prior period, unchanged from 0000080420-17-000009:notes:81]

[0000080420-17-000020:notes:82]
[same as prior period, unchanged from 0000080420-17-000009:notes:82]

[0000080420-17-000020:notes:83]
[same as prior period, unchanged from 0000080420-17-000009:notes:83]

[0000080420-17-000020:notes:84]
[same as prior period, unchanged from 0000080420-17-000009:notes:84]

[0000080420-17-000020:notes:85]
[same as prior period, unchanged from 0000080420-17-000009:notes:85]

[0000080420-17-000020:notes:86]
The preparation of condensed consolidated financial statements in conformity with U.S. GAAP requires management to make estimates and assumptions that affect the amounts reported in the condensed consolidated financial statements and accompanying footnotes. The most significant estimates used in our condensed consolidated financial statements affect revenue and cost recognition for construction contracts, the allowance for doubtful accounts, provision for excess and obsolete inventory, self-insurance, warranty accruals, liquidated damages and income taxes. The amounts recorded for insurance claims, warranties, legal, liquidated damages, income taxes and other contingent liabilities require judgments regarding the amount of expenses that will ultimately be incurred. We base our estimates on historical experience and on various other assumptions, as well as the specific circumstances surrounding these contingent liabilities, in evaluating the amount of liability that should be recorded. Additionally, the recognition of deferred tax assets requires estimates related to future income and other assumptions regarding timing and future profitability. Estimates routinely change as new events occur, additional information becomes available or operating environments change. Actual results may differ from our prior estimates.

[0000080420-17-000020:notes:87]
For the three and nine months ended June 30, 2017, our operating loss was positively impacted by $3.6 million and $7.4 million, respectively, as a result of changes in contract estimates related to projects in progress at the beginning of the respective periods. These changes in estimates resulted primarily from, among other things, successful execution and close-out improvements, as well as other changes in facts and circumstances during these periods.


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0000080420-17-000020:notes:88]
[same as prior period, unchanged from 0000080420-17-000009:notes:87]

[0000080420-17-000020:notes:89]
We did not incur any restructuring costs in the third quarter of Fiscal 2017. However, in the third quarter of Fiscal 2016, we incurred approximately $0.4 million of separation costs as we continued to align our workforce with future production requirements, with another approximately $0.3 million of restructuring costs related to a leased Canadian facility that we exited in the third quarter of Fiscal 2015.

[0000080420-17-000020:notes:90]
For the nine months ended June 30, 2017, we incurred $0.8 million of restructuring costs as we continued to reduce our overall cost structure to better align our costs with future production requirements. For the nine months ended June 30, 2016, we incurred approximately $7.7 million due to the realignment of our senior management team and workforce reductions.


## us-gaap:ScheduleOfInventoryCurrentTableTextBlock

[0000080420-17-000020:notes:91]
[same as prior period, unchanged from 0000080420-17-000009:notes:90]

[0000080420-17-000020:notes:92]
|  | June 30, 2017 |  | September 30, 2016 |
| Raw materials, parts and subassemblies, net | $ | 18,244 |  |  | $ | 25,525 |  |
| Work-in-progress | 784 |  |  | 996 |  |
| Total inventories | $ | 19,028 |  |  | $ | 26,521 |  |


## us-gaap:ScheduleOfProductWarrantyLiabilityTableTextBlock

[0000080420-17-000020:notes:93]
[same as prior period, unchanged from 0000080420-17-000009:notes:92]

[0000080420-17-000020:notes:94]
|  | Three months ended June 30, |  | Nine months ended June 30, |
|  | 2017 |  | 2016 |  | 2017 |  | 2016 |
| Balance at beginning of period | $ | 3,649 |  |  | $ | 4,787 |  |  | $ | 4,639 |  |  | $ | 4,930 |  |
| Increase to warranty expense | 593 |  |  | 1,174 |  |  | 1,313 |  |  | 3,332 |  |
| Deduction for warranty charges | (949 | ) |  | (1,206 | ) |  | (2,618 | ) |  | (3,481 | ) |
| Change due to foreign currency translation | 39 |  |  | (26 | ) |  | (2 | ) |  | (52 | ) |
| Balance at end of period | $ | 3,332 |  |  | $ | 4,729 |  |  | $ | 3,332 |  |  | $ | 4,729 |  |


## us-gaap:SubsequentEventsTextBlock

[0000080420-17-000020:notes:95]
SUBSEQUENT EVENTS

[0000080420-17-000020:notes:96]
On August 8, 2017, our Board of Directors declared a quarterly cash dividend on our common stock in the amount of $0.26 per share. The dividend is payable on September 13, 2017 to shareholders of record at the close of business on August 23, 2017.


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0000080420-17-000020:notes:97]
[same as prior period, unchanged from 0000080420-17-000009:notes:94]

[0000080420-17-000020:notes:98]
[same as prior period, unchanged from 0000080420-17-000009:notes:95]

[0000080420-17-000020:notes:99]
[same as prior period, unchanged from 0000080420-17-000009:notes:96]

[0000080420-17-000020:notes:100]
[same as prior period, unchanged from 0000080420-17-000009:notes:97]

[0000080420-17-000020:notes:101]
[same as prior period, unchanged from 0000080420-17-000009:notes:98]
