# POWL note change history — 0000080420-17-000009 → 0000080420-17-000020


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2017-08-09):
[0000080420-17-000020:note_history:1]
Certain customers require us to post bank letter of credit guarantees or surety bonds. These guarantees and surety bonds assure that we will perform under the terms of our contract. In the event of default, the counterparty may demand payment from the bank under a letter of credit or performance by the surety under a bond. To date, there have been no significant expenses related to either letters of credit or surety bonds for the periods reported. We were contingently liable for secured and unsecured letters of credit of $24.6 million as of June 30, 2017. We also had surety bonds totaling $221.7 million that were outstanding, with additional bonding capacity of $528.3 million available, at June 30, 2017.
  (was, 2017-05-03, similarity 0.987):
[0000080420-17-000009:note_history:1]
Certain customers require us to post bank letter of credit guarantees or surety bonds. These guarantees and surety bonds assure that we will perform under the terms of our contract. In the event of default, the counterparty may demand payment from the bank under a letter of credit or performance by the surety under a bond. To date, there have been no significant expenses related to either letters of credit or surety bonds for the periods reported. We were contingently liable for secured and unsecured letters of credit of $21.4 million as of March 31, 2017. We also had surety bonds totaling $216.0 million that were outstanding, with additional bonding capacity of $534.0 million available, at March 31, 2017.

- changed (2017-08-09):
[0000080420-17-000020:note_history:2]
We have a $6.5 million facility agreement (Facility Agreement) between Powell (UK) Limited and a large international bank. This Facility Agreement provides Powell (UK) Limited the ability to enter into bank guarantees as well as forward exchange contracts and currency options. At June 30, 2017, we had outstanding guarantees totaling $4.2 million under this Facility Agreement and amounts available under this Facility Agreement were $2.3 million.  This facility expires in May 2018. The Facility Agreement provides for financial covenants and customary events of default, and carries cross-default provisions with our U.S. Revolver. If an event of default (as defined in the Facility Agreement) occurs and is continuing, per the terms and subject to the conditions set forth therein, obligations outstanding under the Facility Agreement may be accelerated and may become or be declared immediately due and payable. As of June 30, 2017, we were in compliance with all of the financial covenants of the Facility Agreement.
  (was, 2017-05-03, similarity 0.991):
[0000080420-17-000009:note_history:2]
We have a $6.2 million facility agreement (Facility Agreement) between Powell (UK) Limited and a large international bank. This Facility Agreement provides Powell (UK) Limited the ability to enter into bank guarantees as well as forward exchange contracts and currency options. At March 31, 2017, we had outstanding guarantees totaling $4.7 million under this Facility Agreement and amounts available under this Facility Agreement were $1.5 million.  This facility expires in May 2017. The Facility Agreement provides for financial covenants and customary events of default, and carries cross-default provisions with our U.S. Revolver. If an event of default (as defined in the Facility Agreement) occurs and is continuing, per the terms and subject to the conditions set forth therein, obligations outstanding under the Facility Agreement may be accelerated and may become or be declared immediately due and payable. As of March 31, 2017, we were in compliance with all of the financial covenants of the Facility Agreement.

- changed (2017-08-09):
[0000080420-17-000020:note_history:3]
Certain of our customer contracts have schedule and performance obligation clauses that, if we fail to meet them, could require us to pay liquidated damages. Each individual contract defines the conditions under which the customer may make a claim against us. As of June 30, 2017, our exposure to possible liquidated damages was $6.8 million, of which approximately $1.5 million is probable.  Based on our actual or projected failure to meet these various contractual commitments, $1.5 million has been recorded as a reduction to revenue. We will attempt to obtain change orders, contract extensions or accelerate project completion which may resolve the potential for any unaccrued liquidated damage. Should we fail to achieve relief on some or all of these contractual obligations, we could be required to pay additional liquidated damages, which could negatively impact our future operating results.
  (was, 2017-05-03, similarity 0.9949):
[0000080420-17-000009:note_history:3]
Certain of our customer contracts have schedule and performance obligation clauses that, if we fail to meet them, could require us to pay liquidated damages. Each individual contract defines the conditions under which the customer may make a claim against us. As of March 31, 2017, our exposure to possible liquidated damages was $2.7 million, of which approximately $1.7 million is probable.  Based on our actual or projected failure to meet these various contractual commitments, $1.6 million has been recorded as a reduction to revenue. We will attempt to obtain change orders, contract extensions or accelerate project completion which may resolve the potential for any unaccrued liquidated damage. Should we fail to achieve relief on some or all of these contractual obligations, we could be required to pay additional liquidated damages, which could negatively impact our future operating results.

- removed (2017-08-09):
[0000080420-17-000009:note_history:4]
Long-Term Debt

- removed (2017-08-09):
[0000080420-17-000009:note_history:5]
See Note E herein for discussion of our long-term debt.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureAndSignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2017-08-09):
[0000080420-17-000020:note_history:6]
These unaudited condensed consolidated financial statements have been prepared in accordance with the instructions to Form 10-Q and Rule 10-01 of Regulation S-X for interim financial information.  Certain information and footnote disclosures, normally included in annual financial statements prepared in accordance with accounting principles generally accepted in the United States (U.S. GAAP), have been condensed or omitted pursuant to those rules and regulations. In the opinion of management, all adjustments, consisting only of normal recurring adjustments, necessary to fairly state the financial position, results of operations and cash flows with respect to the interim condensed consolidated financial statements have been included. The results of operations for the interim periods are not necessarily indicative of the results for the entire fiscal year.  We believe that these financial statements contain all adjustments necessary so that they are not misleading.
  (was, 2017-05-03, similarity 0.9332):
[0000080420-17-000009:note_history:6]
These unaudited condensed consolidated financial statements have been prepared in accordance with the instructions to Form 10-Q and Rule 10-01 of Regulation S-X for interim financial information.  Certain information and footnote disclosures, normally included in annual financial statements prepared in accordance with accounting principles generally accepted in the United States (U.S. GAAP), have been condensed or omitted pursuant to those rules and regulations. In the opinion of management, all adjustments, consisting only of normal recurring adjustments, necessary to fairly state the financial position, results of operations and cash flows with respect to the interim condensed consolidated financial statements have been included. The results of operations for the interim periods are not necessarily indicative of the results for the entire fiscal year.  We believe that these financial statements contain all adjustments necessary so that they are not misleading. The year-end balance sheet data was derived from audited financial statements, but does not include all disclosures required by U.S. GAAP.

- changed (2017-08-09):
[0000080420-17-000020:note_history:7]
The preparation of condensed consolidated financial statements in conformity with U.S. GAAP requires management to make estimates and assumptions that affect the amounts reported in the condensed consolidated financial statements and accompanying footnotes. The most significant estimates used in our condensed consolidated financial statements affect revenue and cost recognition for construction contracts, the allowance for doubtful accounts, provision for excess and obsolete inventory, self-insurance, warranty accruals, liquidated damages and income taxes. The amounts recorded for insurance claims, warranties, legal, liquidated damages, income taxes and other contingent liabilities require judgments regarding the amount of expenses that will ultimately be incurred. We base our estimates on historical experience and on various other assumptions, as well as the specific circumstances surrounding these contingent liabilities, in evaluating the amount of liability that should be recorded. Additionally, the recognition of deferred tax assets requires estimates related to future income and other assumptions regarding timing and future profitability. Estimates routinely change as new events occur, additional information becomes available or operating environments change. Actual results may differ from our prior estimates.
  (was, 2017-05-03, similarity 0.994):
[0000080420-17-000009:note_history:7]
The preparation of condensed consolidated financial statements in conformity with U.S. GAAP requires management to make estimates and assumptions that affect the amounts reported in the condensed consolidated financial statements and accompanying footnotes. The most significant estimates used in our condensed consolidated financial statements affect revenue and cost recognition for construction contracts, the allowance for doubtful accounts, provision for excess and obsolete inventory, self-insurance, warranty accruals, liquidated damages and income taxes. The amounts recorded for insurance claims, warranties, legal, liquidated damages, income taxes and other contingent liabilities require judgments regarding the amount of expenses that will ultimately be incurred. We base our estimates on historical experience and on various other assumptions, as well as the specific circumstances surrounding these contingent liabilities, in evaluating the amount of liability that should be recorded. Additionally, the recognition of deferred tax assets requires estimates related to future income and other assumptions regarding timing and future profitability. Estimates may change as new events occur, additional information becomes available or operating environments change. Actual results may differ from our estimates.

- added (2017-08-09):
[0000080420-17-000020:note_history:8]
For the three and nine months ended June 30, 2017, our operating loss was positively impacted by $3.6 million and $7.4 million, respectively, as a result of changes in contract estimates related to projects in progress at the beginning of the respective periods. These changes in estimates resulted primarily from, among other things, successful execution and close-out improvements, as well as other changes in facts and circumstances during these periods.

- changed (2017-08-09):
[0000080420-17-000020:note_history:9]
In November 2015, the FASB issued an amendment to the topic regarding income taxes which requires an entity to separate deferred income tax liabilities and assets into current and noncurrent amounts in the statement of financial position.  Deferred tax liabilities and assets are classified as current or noncurrent based on the classification of the related asset or liability for financial reporting.  Deferred tax liabilities and assets that are not related to an asset or liability for financial reporting are classified according to the expected reversal date of the temporary difference. To simplify the presentation of deferred income taxes, the amendments require that deferred income tax liabilities and assets be classified as noncurrent in a classified statement of financial position.  This amendment is effective for annual reporting periods beginning after December 15, 2016, which would be our fiscal year ending September 30, 2018. We have no plans for early adoption. We are still evaluating this new amendment, but we do not expect it to have a material impact on our consolidated financial position or results of operations.
  (was, 2017-05-03, similarity 0.9443):
[0000080420-17-000009:note_history:9]
In November 2015, the FASB issued an amendment to the topic regarding income taxes which requires an entity to separate deferred income tax liabilities and assets into current and noncurrent amounts in the statement of financial position.  Deferred tax liabilities and assets are classified as current or noncurrent based on the classification of the related asset or liability for financial reporting.  Deferred tax liabilities and assets that are not related to an asset or liability for financial reporting are classified according to the expected reversal date of the temporary difference. To simplify the presentation of deferred income taxes, the amendments require that deferred income tax liabilities and assets be classified as noncurrent in a classified statement of financial position.  This amendment is effective for annual reporting periods beginning after December 15, 2016, which would be our fiscal year ending September 30, 2018.  We have no plans for early adoption. The adoption of this guidance is not expected to have a material impact on our consolidated financial position or results of operations.

- changed (2017-08-09):
[0000080420-17-000020:note_history:10]
In February 2016, the FASB issued a new topic on leases which requires lessees to recognize lease assets and lease liabilities on the balance sheet for all leases with terms longer than twelve months. Leases will be classified as either finance or operating, with classification affecting the pattern of expense recognition in the income statement. A modified retrospective transition approach is required for lessees for capital and operating leases existing at, or entered into after, the beginning of the earliest comparative period presented in the financial statements, with certain practical expedients available. The new standard is effective for fiscal years beginning after December 15, 2018, including interim periods within those fiscal years. This would be our fiscal year ending September 30, 2020.  We plan to adopt this new standard beginning in Fiscal 2018, and do not expect it to have a material impact on our consolidated financial position or results of operations.
  (was, 2017-05-03, similarity 0.9279):
[0000080420-17-000009:note_history:10]
In February 2016, the FASB issued a new topic on leases which requires lessees to recognize lease assets and lease liabilities on the balance sheet for all leases with terms longer than twelve months. Leases will be classified as either finance or operating, with classification affecting the pattern of expense recognition in the income statement. A modified retrospective transition approach is required for lessees for capital and operating leases existing at, or entered into after, the beginning of the earliest comparative period presented in the financial statements, with certain practical expedients available. The new standard is effective for fiscal years beginning after December 15, 2018, including interim periods within those fiscal years. This would be our fiscal year ending September 30, 2020.  We are currently evaluating the impact of our pending adoption of the new standard, but do not expect it to have a material impact on our consolidated financial position or results of operations.

- added (2017-08-09):
[0000080420-17-000020:note_history:11]
In November 2016, the FASB issued new standards on the statement of cash flows and restricted cash that change the presentation of restricted cash and cash equivalents on the statement of cash flows. Restricted cash and restricted cash equivalents will be included with cash and cash equivalents when reconciling the beginning-of-period and end-of-period total amounts shown on the statement of cash flows. These standards are effective for public business entities for fiscal years beginning after December 15, 2017, and interim periods within those fiscal years, which would be our fiscal year ending September 30, 2019.  We have no plans for early adoption. We are still evaluating these new standards, but we do not expect them to have a material impact on our consolidated financial position or results of operations.

- added (2017-08-09):
[0000080420-17-000020:note_history:12]
In May 2017, the FASB issued a new topic on modification accounting with regards to stock based compensation. This new topic clarifies when a change to the terms or conditions of a share-based payment award should be accounted for as a modification. An entity should account for the effects of a modification unless the fair value, vesting conditions and classification, as an equity instrument or a liability instrument, of the modified award are the same before and after a change to the terms or conditions of the share-based payment award. The standard is effective for annual reporting periods beginning after December 15, 2017, which would be our fiscal year ending September 30, 2018. We do not expect this topic to have a material impact on our consolidated financial position or results of operations.


## us-gaap:LongTermDebtTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2017-08-09):
[0000080420-17-000020:note_history:13]
|  | June 30, 2017 |  | September 30, 2016 |
| Industrial development revenue bonds | $ | 2,000 |  |  | $ | 2,400 |  |
| Less current portion | (400 | ) |  | (400 | ) |
| Total long-term debt | $ | 1,600 |  |  | $ | 2,000 |  |
  (was, 2017-05-03, similarity 0.7901):
[0000080420-17-000009:note_history:13]
|  | March 31, 2017 |  | September 30, 2016 |
| Industrial development revenue bonds | $ | 2,000 |  |  | $ | 2,400 |  |
| Less current portion | (400 | ) |  | (400 | ) |
| Total long-term debt and capital lease obligations | $ | 1,600 |  |  | $ | 2,000 |  |

- added (2017-08-09):
[0000080420-17-000020:note_history:14]
We have a $75.0 million revolving credit facility (U.S. Revolver) to provide working capital support and letters of credit. In June 2017, we entered into the Third Amendment to the Credit Agreement (the Third Amendment). The Third Amendment, among other things, (i) extended the Maturity Date from December 2018 to June 2022; (ii) amended the definition of Applicable Rate by (a) providing that Pricing Level I shall apply when a Cash Collateral Period (described below) is in effect and that Pricing Level II shall apply when no Cash Collateral Period is in effect, (b) decreasing the Letter of Credit Fee percentage for Pricing Level I from 1.00% to 0.875% and (c) increasing the Commitment Fee percentage for both Pricing Level I and Pricing Level II from 0.1875% to 0.20%; (iii) added a new requirement that during a Cash Collateral Period we maintain a cash balance in a pledged cash collateral account equal to at least 102% of the Outstanding Amount of Revolving Loans and Letter of Credit Obligations and (iv) modified the Financial Covenants by requiring that, during any Cash Collateral Period, the Consolidated Current Ratio be no less than 1.10 to 1.0. Price Level 3 has been removed and our ability to pay dividends remains subject to financial covenant restrictions.

- added (2017-08-09):
[0000080420-17-000020:note_history:15]
Generally, a Cash Collateral Period under the Third Amendment is defined as a fiscal quarter during which we have pledged our cash collateral account to the Administrative Agent. A Cash Collateral Period will terminate on the last day of the fiscal quarter in which we satisfy the Level II Pricing Covenants set forth in the Third Amendment for two consecutive fiscal quarters. If we are not in compliance with the Level II Pricing Covenants, we are subject to Level I Pricing Covenants.

- added (2017-08-09):
[0000080420-17-000020:note_history:16]
The Cash Collateral Period was in effect as of June 30, 2017, therefore we placed $25.3 million in a pledged cash collateral account, which was 102% of our outstanding letters of credit as of June 30, 2017. The cash collateral associated with the outstanding letters of credit that are due to expire beyond twelve months has been classified as non-current restricted cash on the balance sheet as of June 30, 2017.

- changed (2017-08-09):
[0000080420-17-000020:note_history:17]
The interest rate for amounts outstanding under the U.S. Revolver is a floating rate based upon the higher of the Federal Funds Rate plus 0.5%, the bank’s prime rate, or the Eurocurrency rate plus 1.00%. Once the applicable rate is determined, a margin ranging up to 1.25% is added to the applicable rate. The U.S. Revolver provides for the issuance of letters of credit which reduce the amounts that may be borrowed under this revolver. We had $24.6 million of outstanding letters of credit under the U.S. Revolver at June 30, 2017.
  (was, 2017-05-03, similarity 0.8498):
[0000080420-17-000009:note_history:17]
We have a $75.0 million revolving credit facility (U.S. Revolver) to provide working capital support and letters of credit. The interest rate for amounts outstanding under the U.S. Revolver is a floating rate based upon the higher of the Federal Funds Rate plus 0.5%, the bank’s prime rate, or the Eurocurrency rate plus 1.00%. Once the applicable rate is determined, a margin ranging up to 1.75%, as determined by our consolidated leverage ratio, is added to the applicable rate. The U.S. Revolver provides for the issuance of letters of credit which reduce the amounts that may be borrowed under this revolver. We had $21.4 million of outstanding letters of credit under the U.S. Revolver at March 31, 2017.

- changed (2017-08-09):
[0000080420-17-000020:note_history:18]
There were no borrowings outstanding under the U.S. Revolver as of June 30, 2017. Amounts available under the U.S. Revolver were $50.4 million at June 30, 2017. The U.S. Revolver expires on June 27, 2022.
  (was, 2017-05-03, similarity 0.9247):
[0000080420-17-000009:note_history:18]
There were no borrowings outstanding under the U.S. Revolver as of March 31, 2017. Amounts available under the U.S. Revolver were $53.6 million at March 31, 2017. The U.S. Revolver expires on December 31, 2018.

- changed (2017-08-09):
[0000080420-17-000020:note_history:19]
The U.S. Revolver is collateralized by a pledge of 100% of the voting capital stock of each of our domestic subsidiaries and 65% of the voting capital stock of each non-domestic subsidiary. The U.S. Revolver provides for customary events of default and carries cross-default provisions with other existing debt agreements. If an event of default (as defined in the U.S. Revolver) occurs and is continuing, on the terms and subject to the conditions set forth in the U.S. Revolver, amounts outstanding under the U.S. Revolver may be accelerated and may become immediately due and payable. As of June 30, 2017, we were in compliance with all of the financial covenants of the U.S. Revolver.
  (was, 2017-05-03, similarity 0.9934):
[0000080420-17-000009:note_history:19]
The U.S. Revolver is collateralized by a pledge of 100% of the voting capital stock of each of our domestic subsidiaries and 65% of the voting capital stock of each non-domestic subsidiary. The U.S. Revolver provides for customary events of default and carries cross-default provisions with other existing debt agreements. If an event of default (as defined in the U.S. Revolver) occurs and is continuing, on the terms and subject to the conditions set forth in the U.S. Revolver, amounts outstanding under the U.S. Revolver may be accelerated and may become immediately due and payable. As of March 31, 2017, we were in compliance with all of the financial covenants of the U.S. Revolver.

- added (2017-08-09):
[0000080420-17-000020:note_history:20]
We had a $7.7 million credit agreement with a major international bank in Canada (the Canadian Revolver) to provide working capital support and letters of credit for our operations in Canada. There were no borrowings or outstanding letters of credit under the Canadian Revolver as of June 30, 2017 and therefore subsequent to June 30, 2017, we canceled the Canadian Revolver. We believe that the cash available in Canada and the U.S. should be sufficient to fund our Canadian operations for the foreseeable future.

- changed (2017-08-09):
[0000080420-17-000020:note_history:21]
We borrowed $8.0 million in October 2001 through a loan agreement funded with proceeds from tax-exempt industrial development revenue bonds (Bonds). These Bonds were issued by the Illinois Development Finance Authority and were used for the completion of our Northlake, Illinois facility. Pursuant to the Bond issuance, a reimbursement agreement between us and a major domestic bank required an issuance by the bank of an irrevocable direct-pay letter of credit (Bond LC), as collateral, to the Bonds’ trustee to guarantee payment of the Bonds’ principal and interest when due. The Bond LC is subject to both early termination and extension provisions customary to such agreements, as well as various covenants, for which we were in compliance at June 30, 2017. While the Bonds mature in 2021, the reimbursement agreement requires annual redemptions of $0.4 million that commenced on October 25, 2002. A sinking fund is used for the redemption of the Bonds. The Bonds bear interest at a floating rate determined weekly by the Bonds’ remarketing agent, which was the underwriter for the Bonds and is an affiliate of the bank. This interest rate was 1.05% as of June 30, 2017.
  (was, 2017-05-03, similarity 0.9921):
[0000080420-17-000009:note_history:21]
We borrowed $8.0 million in October 2001 through a loan agreement funded with proceeds from tax-exempt industrial development revenue bonds (Bonds). These Bonds were issued by the Illinois Development Finance Authority and were used for the completion of our Northlake, Illinois facility. Pursuant to the Bond issuance, a reimbursement agreement between us and a major domestic bank required an issuance by the bank of an irrevocable direct-pay letter of credit (Bond LC), as collateral, to the Bonds’ trustee to guarantee payment of the Bonds’ principal and interest when due. The Bond LC is subject to both early termination and extension provisions customary to such agreements, as well as various covenants, for which we were in compliance at March 31, 2017. While the Bonds mature in 2021, the reimbursement agreement requires annual redemptions of $0.4 million that commenced on October 25, 2002. A sinking fund is used for the redemption of the Bonds. The Bonds bear interest at a floating rate determined weekly by the Bonds’ remarketing agent, which was the underwriter for the Bonds and is an affiliate of the bank. This interest rate was 1.04% as of March 31, 2017.

- removed (2017-08-09):
[0000080420-17-000009:note_history:22]
The U.S. Revolver contains certain restrictive and maintenance-type covenants, such as restrictions on the amount of capital expenditures allowed. It also contains financial covenants defining various financial measures and the levels of these measures with which we must comply, as well as a “material adverse change” clause. A “material adverse change” is defined as a material change in our operations, business, properties, liabilities or condition (financial or otherwise) or a material impairment of our ability to perform our obligations under our credit agreements.

- removed (2017-08-09):
[0000080420-17-000009:note_history:23]
We have a $7.5 million credit agreement with a major international bank in Canada (the Canadian Revolver) to provide working capital support and letters of credit for our operations in Canada. The interest rate for amounts outstanding under the Canadian Revolver is a floating interest rate based upon either the Canadian Prime Rate, or the lender’s Bankers’ Acceptance Rate. Once the applicable rate is determined, a margin of 0.50% to 1.75%, as determined by our consolidated leverage ratio, is added to the applicable rate. The Canadian Revolver provides for the issuance of letters of credit which reduce the amounts that may be borrowed under this revolver. There were no outstanding letters of credit under the Canadian Revolver at March 31, 2017.

- removed (2017-08-09):
[0000080420-17-000009:note_history:24]
There were no borrowings outstanding under the Canadian Revolver as of March 31, 2017 and amounts available under the Canadian Revolver were $7.5 million at March 31, 2017. The Canadian Revolver expires on March 31, 2018.

- removed (2017-08-09):
[0000080420-17-000009:note_history:25]
The principal financial covenants are consistent with those described in our U.S. Revolver. The Canadian Revolver contains a “material adverse effect” clause. A “material adverse effect” is defined as a material change in the operations of Powell or Powell Canada Inc. in relation to our financial condition, property, business operations, expected net cash flows, liabilities or capitalization.

- removed (2017-08-09):
[0000080420-17-000009:note_history:26]
The Canadian Revolver is secured by the assets of our Canadian operations and provides for customary events of default and carries cross-default provisions with our existing debt agreements. If an event of default (as defined in the Canadian Revolver) occurs and is continuing, per the terms and subject to the conditions set forth in the Canadian Revolver, amounts outstanding under the Canadian Revolver may be accelerated and may become immediately due and payable. As of March 31, 2017, we were in compliance with all of the financial covenants of the Canadian Revolver.


## us-gaap:ScheduleOfDebtInstrumentsTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2017-08-09):
[0000080420-17-000020:note_history:27]
|  | June 30, 2017 |  | September 30, 2016 |
| Industrial development revenue bonds | $ | 2,000 |  |  | $ | 2,400 |  |
| Less current portion | (400 | ) |  | (400 | ) |
| Total long-term debt | $ | 1,600 |  |  | $ | 2,000 |  |
  (was, 2017-05-03, similarity 0.7901):
[0000080420-17-000009:note_history:27]
|  | March 31, 2017 |  | September 30, 2016 |
| Industrial development revenue bonds | $ | 2,000 |  |  | $ | 2,400 |  |
| Less current portion | (400 | ) |  | (400 | ) |
| Total long-term debt and capital lease obligations | $ | 1,600 |  |  | $ | 2,000 |  |


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: no_prior_note, score: 0.0

- added (2017-08-09):
[0000080420-17-000020:note_history:28]
SUBSEQUENT EVENTS

- added (2017-08-09):
[0000080420-17-000020:note_history:29]
On August 8, 2017, our Board of Directors declared a quarterly cash dividend on our common stock in the amount of $0.26 per share. The dividend is payable on September 13, 2017 to shareholders of record at the close of business on August 23, 2017.
