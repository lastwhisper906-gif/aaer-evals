# POWL MD&A — 0001564590-15-011208


## mdna

[0001564590-15-011208:mdna:1]
Item 7. Management’s Discussion and Analysis of Financial Condition and Results of Operations

[0001564590-15-011208:mdna:2]
Overview

[0001564590-15-011208:mdna:3]
We develop, design, manufacture and service custom-engineered equipment and systems for the management and control of electrical energy and other critical processes. Headquartered in Houston, Texas, we serve the oil and gas refining, offshore oil and gas production, petrochemical, pipeline, terminal, mining and metals, light rail traction power, electric utility, pulp and paper and other industrial markets. Revenues and costs are primarily related to custom engineered-to-order equipment and systems and accounted for under percentage-of-completion accounting which precludes us from providing detailed price and volume information. Our backlog includes various projects, some of which are petrochemical, oil and gas construction and transportation infrastructure projects which take a number of months to produce.

[0001564590-15-011208:mdna:4]
The markets in which we participate are capital intensive and cyclical in nature. Cyclicality is predominantly driven by customer demand, global economic conditions and anticipated environmental or regulatory changes which affect the manner in which our customers proceed with capital investments. Our customers analyze various factors including the demand and price for oil, gas and electrical energy, the overall economic and financial environment, governmental budgets, regulatory actions and environmental concerns. These factors influence the release of new capital projects by our customers, which are traditionally awarded in competitive bid situations. Scheduling of projects is matched to the customer requirements and projects may take a number of months to produce; but schedules may change during the course of any particular project. Our operating results can be impacted by factors outside of our control.

[0001564590-15-011208:mdna:5]
Our operating results have been negatively impacted by factors such as our operational inefficiencies, our inability to meet contractual commitments on existing projects, customer approval of engineering and design specifications and delays in customer construction schedules, all of which impact the timing and costs related to project execution.  These factors resulted in an imbalance of our factory resources with our customer commitments, resulting in higher production costs due to inefficiencies.  Our operating results were also negatively impacted by the timing and resolution of change orders, project close-out and resolution of potential liquidated damage claims, all of which impacted gross margins during the period in which these items are resolved with our customers.

[0001564590-15-011208:mdna:6]
We anticipate that demand for our solutions in the western Canadian oil and gas markets will continue to be a contributor to our strategic position in the Canadian market place.  We completed the construction of our new Canadian facility and relocated operations in the fall of 2013 and completed a $26 million expansion of this manufacturing facility in the third quarter of Fiscal 2015. The stabilization of our Canadian operations has presented challenges resulting in inefficiencies that led to extended project delivery times, delayed project revenues, higher operating costs, gross margin deterioration and operating losses.  We have taken actions in an effort to mitigate the risks associated with replicating our U.S. project-based integration model which allows for the design, fabrication, integration and testing of our products at a single location.  Prior to the construction of our new Canadian facility, we performed only final assembly operations in Canada.

[0001564590-15-011208:mdna:7]
On January 15, 2014, we sold our wholly-owned subsidiary Transdyn to a global provider of electronic toll collection systems, headquartered in Vienna, Austria.  The purchase price from the sale of this subsidiary totaled $16.0 million, subject to working capital adjustments. We received cash of $14.4 million and the remaining $1.6 million was placed into an escrow account and released to us in July 2015. We have presented the results of these operations as income from discontinued operations, net of tax, in the condensed consolidated statements of operations for all periods presented.  Accordingly, we have removed Transdyn from the Results of Operations discussions below.

[0001564590-15-011208:mdna:8]
Results of Operations

[0001564590-15-011208:mdna:9]
Twelve Months Ended September 30, 2015 Compared to Twelve Months Ended September 30, 2014

[0001564590-15-011208:mdna:10]
Revenue and Gross Profit

[0001564590-15-011208:mdna:11]
Revenues increased 2.2% or $14.0 million, to $661.9 million in Fiscal 2015, primarily due to the increase in domestic revenues.  Domestic revenues increased 30.0%, or $109.6 million, to $474.7 million in Fiscal 2015 primarily due to our production efforts on various large petrochemical projects awarded in Fiscal 2014.  International revenues decreased 33.8%, or $95.6 million, to $187.2 million in Fiscal 2015 primarily due to the substantial completion of several large projects for both the Canadian market and the U.S. export projects.  Revenues from commercial and industrial customers increased $50.0 million to $524.5 million in Fiscal 2015.  Revenues from public and private utilities decreased $41.9 million to $85.1 million in Fiscal 2015.  Revenues from municipal and transit projects increased $5.9 million to $52.2 million in Fiscal 2015.

[0001564590-15-011208:mdna:12]
Gross profit decreased 13.7%, or $17.2 million, to $108.3 million in Fiscal 2015.  Gross profit as a percentage of revenues decreased to 16.4% in Fiscal 2015 compared to 19.4% in Fiscal 2014.  Our gross profit and gross profit as a percentage of revenues decreased in Fiscal 2015 compared to Fiscal 2014, primarily due to inefficiencies resulting from our production efforts and incremental costs required to maintain our customer’s schedules, as well as the overall mix of project types.

[0001564590-15-011208:mdna:13]
Selling, General and Administrative Expenses

[0001564590-15-011208:mdna:14]
Selling, general and administrative expenses decreased by $11.0 million to $76.8 million in Fiscal 2015 compared to Fiscal 2014. Selling, general and administrative expenses, as a percentage of revenues, decreased to 11.6% in Fiscal 2015 compared to 13.5% in Fiscal 2014. These decreases were primarily due to a decrease in performance-based compensation, sales commissions, personnel and administrative costs resulting from reductions in force, reduced bad debt expense and overall cost reduction efforts.

[0001564590-15-011208:mdna:15]
Restructuring and separation costs

[0001564590-15-011208:mdna:16]
In Fiscal 2015, we incurred $3.4 million in restructuring and separation costs. Of this, $2.6 million was from separation and severance costs and the remaining $0.8 million resulted from the exit of a Canadian facility lease and the write-off of associated leasehold improvements.

[0001564590-15-011208:mdna:17]
Other Income

[0001564590-15-011208:mdna:18]
We recorded other income of $2.4 million in Fiscal 2015, of which $2.0 million related to the amortization of the deferred gain from the amended supply agreement, discussed in Note E of the Notes to Condensed Consolidated Financial Statements, and $0.4 million was from a death benefit received from our company-owned life insurance policy.  We recorded other income of $1.5 million in Fiscal 2014, which was solely from the amortization of the deferred gain.

[0001564590-15-011208:mdna:19]
Income Tax Provision

[0001564590-15-011208:mdna:20]
Our provision for income taxes was $13.6 million in Fiscal 2015 compared to $11.1 million in Fiscal 2014.  The effective tax rate in Fiscal 2015 was 58.9% compared to an effective tax rate of 36.1% for Fiscal 2014.  This increase in effective tax rate in Fiscal 2015 was primarily due to the establishment of a valuation allowance against the Canadian net deferred tax assets, partially offset by the resolution of an IRS audit and the retroactive reinstatement of the Federal Research and Development Tax Credit for the second through fourth quarter of Fiscal 2014 (for more detailed information, see Note H of the Notes to Condensed Consolidated Financial Statements included elsewhere in this Annual Report).  The effective tax rate for Fiscal 2014 approximated the combined U.S. federal and state statutory rate as the majority of our income was attributable to the U.S.

[0001564590-15-011208:mdna:21]
Income from Continuing Operations

[0001564590-15-011208:mdna:22]
In Fiscal 2015, we recorded income from continuing operations of $9.4 million, or $0.79 per diluted share compared to $19.6 million, or $1.62 per diluted share in Fiscal 2014. This reduction to net income was primarily due to a valuation allowance recorded against our Canadian deferred tax assets (as discussed above) and higher domestic productions costs caused by inefficiencies resulting from our production efforts and incremental costs to maintain our customers’ scheduling requirements.  These reductions to net income were partially offset by lower selling, general and administrative costs.

[0001564590-15-011208:mdna:23]
Income from Discontinued Operations

[0001564590-15-011208:mdna:24]
In Fiscal 2014, we recorded $9.6 million, or $0.80 per diluted share, of income from discontinued operations which included the gain on the sale. For additional information about this disposition, see Note N of the Notes to Condensed Consolidated Financial Statements.

[0001564590-15-011208:mdna:25]
Backlog

[0001564590-15-011208:mdna:26]
Our backlog includes various projects, some of which are petrochemical, oil and gas construction and transportation infrastructure projects which take a number of months to produce. The order backlog at September 30, 2015 was $441.4 million, compared to $507.1 million at September 30, 2014.  New orders placed in Fiscal 2015 totaled $606.8 million, compared to $725.8 million in Fiscal 2014. This decrease in orders was due to reduced capital investments by our customers primarily in oil and gas and petrochemical industries.

[0001564590-15-011208:mdna:27]
Twelve Months Ended September 30, 2014 Compared to Twelve Months Ended September 30, 2013

[0001564590-15-011208:mdna:28]
Revenue and Gross Profit

[0001564590-15-011208:mdna:29]
Revenues increased 1.1% or $6.9 million, to $647.8 million in Fiscal 2014.  Domestic revenues decreased 2.5%, or $9.3 million, to $365.1 million in Fiscal 2014, primarily due to the mix of projects and international revenues increased 6.1%, or $16.3 million, to $282.7 million in Fiscal 2014. The expansion of our Canadian operations contributed to the increase in international revenues.  Revenues from industrial customers increased $18.8 million to $474.4 million in Fiscal 2014. Revenues from public and private utilities decreased $11.6 million to $127.0 million in Fiscal 2014. Revenues from municipal and transit projects decreased $0.3 million to $46.3 million in Fiscal 2014. Additionally, revenues in Fiscal 2013 were favorably impacted by the recovery of $3.8 million related to cost overruns from a previous year on a large industrial project.

[0001564590-15-011208:mdna:30]
Gross profit decreased 9.4%, or $13.0 million, to $125.5 million in Fiscal 2014.  Gross profit as a percentage of revenues decreased to 19.4% in Fiscal 2014 compared to 21.6% in Fiscal 2013 primarily due to higher costs resulting from the efficiency and utilization challenges associated with the ramp of our Canadian operations.  Additionally, we incurred higher operating costs associated with inefficiencies from the re-implementation of our existing ERP system and added a suite of new software tools to expand our Business Systems.  These higher costs were partially offset by various supply chain and productivity initiatives.  Gross profit for Fiscal 2013 was favorably impacted by the $3.8 million recovery from the project discussed above.

[0001564590-15-011208:mdna:31]
Selling, General and Administrative Expenses

[0001564590-15-011208:mdna:32]
Selling, general and administrative expenses increased by $8.0 million to $87.8 million in Fiscal 2014 compared to Fiscal 2013, primarily due to increased personnel costs, travel and administrative expenses and bad debts.  Selling, general and administrative expenses, as a percentage of revenues, increased to 13.5% in Fiscal 2014 compared to 12.4% in Fiscal 2013. This increase in selling, general and administrative expense was partially offset by a decrease in depreciation expense as our existing Business Systems became fully depreciated in December 2012 and the favorable impact of the capitalization of certain personnel costs associated with the development and implementation of our new Business Systems, which went live in May 2014.  However, going forward, the favorable impact of depreciation expense and capitalization of certain personnel costs will no longer be realized.

[0001564590-15-011208:mdna:33]
Amortization of Intangible Assets

[0001564590-15-011208:mdna:34]
Amortization of intangible assets decreased to $0.8 million in Fiscal 2014 compared to $1.7 million in Fiscal 2013 primarily due to the amendment to the supply agreement which is discussed in Note E of the Notes to Consolidated Financial Statements included elsewhere in this Annual Report.

[0001564590-15-011208:mdna:35]
Other Income

[0001564590-15-011208:mdna:36]
We recorded other income of $1.5 million in Fiscal 2014 which represents the amortization of the deferred gain from the amendment to the supply agreement discussed above.  We did not record other income in Fiscal 2013.

[0001564590-15-011208:mdna:37]
Income Tax Provision

[0001564590-15-011208:mdna:38]
Our provision for income taxes for continuing operations was $11.1 million in Fiscal 2014 compared to $7.4 million in Fiscal 2013.  The effective tax rate in Fiscal 2014 was 36.1%, which approximates the combined U.S. federal and state statutory rates as the majority of our income is attributable to the U.S. Additionally, the Federal Research and Development Tax Credit (R&D Credit) expired December 31, 2013.   The effective tax rate for Fiscal 2013 was 15.7% and was favorably impacted by the release of the $7 million valuation allowance recorded as an offset to the prior years’ Canadian pre-tax losses and the R&D Credit as well as the

[0001564590-15-011208:mdna:39]
utilization of certain foreign tax credits.  For further information on the effective tax rate for Fiscal 2013, see Note H of the Notes to Consolidated Financial Statements included elsewhere in this Annual Report.

[0001564590-15-011208:mdna:40]
Income from Continuing Operations

[0001564590-15-011208:mdna:41]
In Fiscal 2014, we recorded income from continuing operations of $19.6 million, or $1.62 per diluted share, compared to $39.7 million, or $3.32 per diluted share, in Fiscal 2013.  This decrease in income from continuing operations was primarily due to efficiency and utilization challenges associated with the ramp of our Canadian operations, higher operating costs associated with inefficiencies from the re-implementation of our existing ERP system and the mix of projects in process at our domestic operations.

[0001564590-15-011208:mdna:42]
Income from Discontinued Operations

[0001564590-15-011208:mdna:43]
In Fiscal 2014, we recorded $9.6 million, or $0.80 per diluted share, of income from discontinued operations compared to $2.3 million, or $0.19 per diluted share, in Fiscal 2013 as the current fiscal year includes the gain on the sale. For additional information about this disposition, see Note N of the Notes to Consolidated Financial Statements included elsewhere in this Annual Report.

[0001564590-15-011208:mdna:44]
Backlog

[0001564590-15-011208:mdna:45]
The order backlog at September 30, 2014 was $507.1 million compared to $437.9 million at September 30, 2013.  New orders placed in Fiscal 2014 totaled $725.8 million compared to $715.7 million in Fiscal 2013.  The year over year increase in new orders was primarily due to the continued strength in oil and gas production and petrochemical and pipeline projects.

[0001564590-15-011208:mdna:46]
Liquidity and Capital Resources

[0001564590-15-011208:mdna:47]
Cash and cash equivalents decreased to $43.6 million at September 30, 2015, compared to $103.1 million at September 30, 2014.  As of September 30, 2015, current assets exceeded current liabilities by 2.4 times and our total debt-to-capitalization ratio was 0.83%.

[0001564590-15-011208:mdna:48]
We have a $75.0 million revolving credit facility in the U.S., which expires in December 2018.  As of September 30, 2015, there were no amounts borrowed under this line of credit. We also have a $7.5 million revolving credit facility in Canada. At September 30, 2015, there was no balance outstanding under the Canadian revolving credit facility. Total long-term debt and capital lease obligations, including current maturities, totaled $2.8 million at September 30, 2015, compared to $3.2 million at September 30, 2014. Total letters of credit outstanding were $21.1 million and $21.5 million at September 30, 2015 and 2014, respectively, which reduce our availability under our U.S. credit facility and our Canadian revolving credit facility. Amounts available at September 30, 2015 under the U.S. and Canadian revolving credit facilities were $53.9 million and $7.5 million, respectively. For further information regarding our debt, see Notes F and G of the Notes to Consolidated Financial Statements included elsewhere in this Annual Report.

[0001564590-15-011208:mdna:49]
Approximately $10.4 million of our cash at September 30, 2015 was held outside of the United States for international operations. It is our intention to indefinitely reinvest all current and future foreign earnings internationally in order to ensure sufficient working capital to support and expand these international operations. In the event that we elect to repatriate some or all of the foreign earnings that were previously deemed to be indefinitely reinvested outside the U.S., under current tax laws we would incur additional tax expense upon such repatriation.

[0001564590-15-011208:mdna:50]
We believe that cash available and borrowing capacity under our existing credit facilities should be sufficient to finance anticipated operating activities, capital improvements and expansions, as well as debt repayments, for the foreseeable future. We continue to monitor the factors that drive our markets and strive to maintain our leadership and competitive advantage in the markets we serve while aligning our cost structures with market conditions.

[0001564590-15-011208:mdna:51]
Operating Activities

[0001564590-15-011208:mdna:52]
During Fiscal 2015, net cash provided by operating activities was $12.9 million.  During Fiscal 2014, net cash provided by operating activities was $9.1 million and in Fiscal 2013, net cash provided by operating activities was $91.4 million.  Cash flow from operations is primarily influenced by demand for our products and services and is impacted as our progress payment terms with our customers are matched with the payment terms with our suppliers.   During Fiscal 2015, our cash provided by operations increased over Fiscal 2014 primarily due to a decrease in prepaid assets and income taxes receivable.  In Fiscal 2014, we received the $10.0 million payment related to the amended supply agreement discussed in Note E of the Notes to Consolidated Financial Statements included elsewhere in this Annual Report.  In Fiscal 2013, we received $6.8 million in contract settlements related to Fiscal 2012 matters.

[0001564590-15-011208:mdna:53]
Investing Activities

[0001564590-15-011208:mdna:54]
Purchases of property, plant and equipment during Fiscal 2015 totaled $34.7 million compared to $16.5 million and $74.4 million in Fiscal 2014 and 2013, respectively. A significant portion of the investments in Fiscal 2013 were to acquire land and build facilities in the United States and Canada to support continued expansion in our key markets, including the oil and gas markets and Canadian oil sands region. Costs related to the re-implementation and additional software added to our Business Systems were incurred during Fiscal 2013 and were placed into service in the third quarter of Fiscal 2014.

[0001564590-15-011208:mdna:55]
Financing Activities

[0001564590-15-011208:mdna:56]
Net cash used in financing activities was $34.9 in Fiscal 2015, $12.5 million in Fiscal 2014 and $0.5 million in Fiscal 2013. The increase in the use of cash in Fiscal 2014 compared to Fiscal 2013 was primarily due to the payment of dividends.  The increase in Fiscal 2015 was primarily due to our share repurchase program discussed below.

[0001564590-15-011208:mdna:57]
Share Repurchase Program

[0001564590-15-011208:mdna:58]
On December 17, 2014, our Board of Directors authorized a share repurchase program under which we may repurchase up to $25 million of our outstanding stock.  The purchases may be made from time to time in the open market, through privately negotiated transactions and Rule 10b5-1 trading plans in accordance with applicable laws, rules and regulations.  The Repurchase Program is being funded from cash on hand and cash provided by operating activities.  The Repurchase Program will expire as of the close of business on December 31, 2015.  As of September 30, 2015, we had purchased 670,181 shares at a cost of $21.3 million under the Repurchase Program.  The average purchase price per share through September 30, 2015 was $31.72.

[0001564590-15-011208:mdna:59]
Contractual and Other Obligations

[0001564590-15-011208:mdna:60]
At September 30, 2015, our long-term contractual obligations were limited to debt and leases. The table below details our commitments by type of obligation, including interest if applicable, and the period that the payment will become due (in thousands).

[0001564590-15-011208:mdna:61]
| As of September 30, 2015, Payments Due by Period: | Long‑TermDebtObligations |  |  |  | OperatingLeaseObligations |  |  | Total |  |
| Less than 1 year | $ | 404 |  |  |  | $ | 3,768 |  |  | $ | 4,172 |  |
| 1 to 3 years |  | 806 |  |  |  |  | 4,992 |  |  |  | 5,798 |  |
| 3 to 5 years |  | 803 |  |  |  |  | 2,641 |  |  |  | 3,444 |  |
| More than 5 years |  | 801 |  |  |  |  | 5,586 |  |  |  | 6,387 |  |
| Total long-term contractual obligations | $ | 2,814 |  |  |  | $ | 16,987 |  |  | $ | 19,801 |  |

[0001564590-15-011208:mdna:62]
In Fiscal 2015, we exited one of our previously occupied leased facilities in Acheson, Alberta, Canada.  The lease does not expire until October 2019; however, we are currently seeking to sublet the facility.  In Fiscal 2014, we also exited one of our previously occupied leased facilities in Edmonton, Alberta, Canada.  This lease does not expire until July 2023; however, we have sublet that facility through July 2019.

[0001564590-15-011208:mdna:63]
As of September 30, 2015, the total unrecognized tax benefit related to uncertain tax positions was $0.8 million. We estimate that none of this will be paid within the next 12 months.  However, we believe that it is reasonably possible that within the next 12 months, the total unrecognized tax benefits will decrease by approximately 4% due to the expiration of certain statutes of limitations in various state and local jurisdictions.  We are unable to make reasonably reliable estimates regarding the timing of future cash outflows, if any, associated with the remaining unrecognized tax benefits.

[0001564590-15-011208:mdna:64]
Other Commercial Commitments

[0001564590-15-011208:mdna:65]
We are contingently liable for secured and unsecured letters of credit of $25.2 million as of September 30, 2015, of which $21.1 million reduces our borrowing capacity.

[0001564590-15-011208:mdna:66]
The following table reflects potential cash outflows that may result in the event that we are unable to perform under our contracts (in thousands):

[0001564590-15-011208:mdna:67]
| As of September 30, 2015, Payments Due by Period: |  | Letters ofCredit |  |
| Less than 1 year |  | $ | 12,037 |  |
| 1 to 3 years |  |  | 9,741 |  |
| More than 3 years |  |  | 3,386 |  |
| Total long-term commercial obligations |  | $ | 25,164 |  |

[0001564590-15-011208:mdna:68]
We also had performance and maintenance bonds totaling $318.8 million that were outstanding at September 30, 2015. Performance and maintenance bonds are primarily used to guarantee our contract performance to our customers.

[0001564590-15-011208:mdna:69]
Off-Balance Sheet Arrangements

[0001564590-15-011208:mdna:70]
We had no off-balance sheet arrangements during the periods presented.

[0001564590-15-011208:mdna:71]
Outlook

[0001564590-15-011208:mdna:72]
The markets in which we participate are capital-intensive and cyclical in nature. Cyclicality is predominantly driven by customer demand, global economic conditions and anticipated environmental or regulatory changes which affect the manner in which our customers proceed with capital investments. Our customers analyze various factors including the demand and price for oil, gas and electrical energy, the overall economic and financial environment, governmental budgets, regulatory actions and environmental concerns. These factors influence the release of new capital projects by our customers, which are traditionally awarded in competitive bid situations. Scheduling of projects is matched to the customer requirements and projects may take a number of months to produce, but schedules may change during the course of any particular project.

[0001564590-15-011208:mdna:73]
A significant portion of our revenues are derived from the oil and gas markets.  Unfavorable long-term commodity price levels can cause oil and gas companies to change their strategies, delay or cancel projects.  Due to the precipitous decline in oil and gas prices over the past year, many of our customers have reduced their capital budgets and cut costs, and in certain instances have deferred or cancelled projects that we were pursuing.  We believe that sustained lower oil and gas prices from a continued global supply/demand imbalance will negatively impact future orders due to reduced capital spending by our customers which may result in project deferrals and cancellations. The reduction in available projects, across the markets we serve, will increase market price pressures during this downward cycle. This reduction in new business opportunities and market price pressures will negatively impact our revenues, backlog, operating results and cash flows from operations.  If commodity prices do not improve, or they continue to decline, the number of projects in our markets could further decline.  We will continue to monitor our cost structure and continue to take actions to align our resources and facilities with expected production requirements.

[0001564590-15-011208:mdna:74]
Our operating results have been, and may continue to be, negatively impacted by factors such as the timing of new order awards, customer approval of final engineering and design specifications and delays in customer construction schedules, all of which have and may continue to have, a negative impact on the timing of project execution.  These factors have resulted, and may continue to result in, periods when our factory resources are not in balance with our customers’ scheduling requirements, resulting in higher production costs due to inefficiencies.  Our operating results also have been, and may continue to be, impacted by the timing and resolution of change orders, project close-out and resolution of potential contract claims, all of which could improve or deteriorate gross margins during the period in which these items are resolved with our customers.

[0001564590-15-011208:mdna:75]
We completed the construction of our new Acheson, Alberta facility and relocated operations in the fall of 2013 and completed a $26 million expansion of this facility in the third quarter of Fiscal 2015. The production ramp and stabilization of our Canadian operations has presented and may continue to present challenges resulting in inefficiencies and extended project delivery times. These challenges resulted in delayed project revenues, incremental costs to hold customers’ schedules, gross margin deterioration, back charges and operating losses.  We have taken actions to stabilize our Canadian operations and mitigate the risks associated with replicating our U.S. project-based integration model which allows for the design, fabrication, integration and testing of our products at a single location.  However, we may continue to incur operating losses in Canada as we continue to enhance our engineering and project management competencies and improve our overall project execution.

[0001564590-15-011208:mdna:76]
We believe that cash available and borrowing capacity under our existing credit facilities should be sufficient to finance anticipated operating activities, capital improvements, debt repayments and share repurchases for the foreseeable future. We continue to monitor our markets and will strive to maintain our leadership and competitive advantage in the markets we serve.

[0001564590-15-011208:mdna:77]
Effects of Inflation

[0001564590-15-011208:mdna:78]
We are subject to inflation, which can cause increases in our costs of raw materials, primarily copper, aluminum and steel. Fixed-price contracts can limit our ability to pass these increases to our customers, thus negatively impacting our earnings. The inflation in commodity prices could potentially impact our operations in future years.

[0001564590-15-011208:mdna:79]
Critical Accounting Policies and Estimates

[0001564590-15-011208:mdna:80]
The preparation of consolidated financial statements in conformity with accounting principles generally accepted in the United States of America requires management to make estimates and assumptions that affect the reported amounts of assets, liabilities, revenues and expenses and the disclosures of contingent assets and liabilities. We base our estimates on historical experience and on various other assumptions that are believed to be reasonable under the circumstances. Actual results may differ from these estimates. We believe the following accounting policies and estimates to be critical in the preparation and reporting of our consolidated financial statements.

[0001564590-15-011208:mdna:81]
Revenue Recognition

[0001564590-15-011208:mdna:82]
Our revenues are primarily generated from the engineering and manufacturing of custom products under long-term contracts that may last from one month to several years, depending on the contract. Revenues from long-term contracts are recognized on the percentage-of-completion method of accounting. Occasionally a contract may require that we segment the project into specific deliverables for revenue recognition. Segmenting a contract may result in different interim rates of profitability for each scope of service than if we had recognized revenue on a combined basis.

[0001564590-15-011208:mdna:83]
Under the percentage-of-completion method of accounting, revenues are recognized as work is performed. The revenue earned to date is calculated by multiplying the total contract price by the percentage of performance to date, which is based on total costs or total labor dollars incurred to date compared to the total estimated costs or total labor dollars estimated at completion. The method used to determine the percentage of completion is typically the cost method, unless the labor method is a more accurate method of measuring the progress of the project. Application of the percentage-of-completion method of accounting requires the use of estimates of costs to be incurred for the performance of the contract. Contract costs include all direct material costs, direct labor costs and those indirect costs related to contract performance, such as indirect labor, supplies, tools, repairs and all costs associated with operation of equipment. The cost estimation process is based upon the professional knowledge and experience of our engineers, project managers and financial professionals. Factors that are considered in estimating the work to be completed and ultimate contract recovery include the availability and productivity of labor, the nature and complexity of the work to be performed, the effect of change orders, the availability of materials, the effect of any delays on our project performance and the recoverability of any claims. Changes in job performance, job conditions, estimated profitability and final contract settlements, including our estimate of liquidated damages, if any, may result in revisions to costs and income, with their effects being recognized in the period in which the revisions are determined. Whenever revisions of estimated contract costs and contract values indicate that the contract costs will exceed estimated revenues, thus creating a loss, a provision for the total estimated loss is recorded in that period.

[0001564590-15-011208:mdna:84]
Revenues associated with maintenance, repair and service contracts are recognized when the services are performed. Expenses related to these types of services are recognized as incurred.

[0001564590-15-011208:mdna:85]
Costs and estimated earnings in excess of billings on uncompleted contracts also include certain costs associated with unapproved change orders. These costs are included when change order approval is probable. Amounts are carried at the lower of cost or net realizable value. Revenue is recognized to the extent of costs incurred when recovery is probable. The amounts recorded involve the use of judgments and estimates; thus, actual recoverable amounts could differ from original assumptions.

[0001564590-15-011208:mdna:86]
Allowance for Doubtful Accounts

[0001564590-15-011208:mdna:87]
We maintain and continually assess the adequacy of an allowance for doubtful accounts representing our estimate for losses resulting from the inability of our customers to pay amounts due to us. This estimated allowance is based on historical experience of uncollected accounts, the level of past due accounts, the overall level of outstanding accounts receivable, information about specific customers with respect to their inability to make payments and expectations of future conditions that could impact the collectability of accounts receivable. However, future changes in our customers’ operating performance and cash flows, or in general economic conditions, could have an impact on their ability to fully pay these amounts, which, among other things, could have a material adverse impact on our operating results.

[0001564590-15-011208:mdna:88]
Impairment of Long-Lived Assets

[0001564590-15-011208:mdna:89]
We review long-lived assets for impairment whenever events or changes in circumstances indicate that the carrying value may not be realizable. If an evaluation is required, the estimated future undiscounted cash flows associated with the asset are compared to the asset’s carrying amount to determine if an impairment of such asset is necessary. This requires us to make long-term forecasts of the future revenues and costs related to the assets subject to review. Forecasts require assumptions about demand for our products and future market conditions. Estimating future cash flows requires significant judgment, and our projections may vary from cash flows eventually realized. Future events and unanticipated changes to assumptions could require a provision for impairment in a future period. The effect of any impairment would be reflected in income (loss) from operations in the Consolidated Statements of Operations. In addition, we estimate the useful lives of our long-lived assets and other intangibles and periodically review these estimates to determine whether these lives are appropriate.

[0001564590-15-011208:mdna:90]
Accruals for Contingent Liabilities

[0001564590-15-011208:mdna:91]
From time to time, contingencies such as insurance-related claims, liquidated damages and legal claims arise in the normal course of business. Pursuant to current accounting standards, we must evaluate such contingencies to subjectively determine the likelihood that an asset has been impaired or a liability has been incurred at the date of the financial statements, as well as evaluate whether the amount of the loss can be reasonably estimated. If the likelihood is determined to be probable and it can be reasonably estimated, the estimated loss is recorded. The amounts we record for insurance claims, warranties, legal and other contingent liabilities require judgments regarding the amount of expenses that will ultimately be incurred. We use past experience and history, as well as the specific circumstances surrounding each contingent liability, in evaluating the amount of liability that should be recorded. Actual results could differ from our estimates.

[0001564590-15-011208:mdna:92]
Warranty Costs

[0001564590-15-011208:mdna:93]
We provide for estimated warranty costs with the recognition of revenue based upon historical rates applicable to individual product lines. In addition, specific provisions are made when the costs of such warranties are expected to exceed accruals. Our standard terms and conditions of sale include a warranty for parts and service for the earlier of 18 months from the date of shipment or 12 months from the date of energization. Occasionally projects require warranty terms which are longer than our standard terms due to the nature of the project. Extended warranty terms may be negotiated and included in our contracts. We use past experience and historical claims to determine the estimated liability. Actual results could differ from our estimate.

[0001564590-15-011208:mdna:94]
Accounting for Income Taxes

[0001564590-15-011208:mdna:95]
We account for income taxes under the asset and liability method, based on the income tax laws and rates in the countries in which operations are conducted and income is earned. This approach requires the recognition of deferred tax assets and liabilities for the expected future tax consequences of temporary differences between the carrying amounts and the tax basis of assets and liabilities. Developing our provision for income taxes requires significant judgment and expertise in federal, international and state income tax laws, regulations and strategies, including the determination of deferred tax assets and liabilities and, if necessary, any valuation allowances that may be required for deferred tax assets.  In assessing the realizability of net deferred tax assets, we consider whether it is more-likely-than-not that some portion or all of the net deferred tax assets may not be realized.  The ultimate realization of net deferred tax assets is dependent on the generation of future taxable income during the periods in which those temporary differences become deductible.  In light of the historical Canadian losses, and recent changes in projected losses in the near term, we are required under the more-likely-than-not accounting standard to record a valuation allowance against the Canadian net deferred assets because we may not be able to realize the benefits of the net operating loss carryforwards and other deductible differences.  Estimates may change as new events occur, estimates of future taxable income during the carryforward period are reduced or increased, additional information becomes available or operating environments change, which may result in a full or partial reversal of the valuation allowance. We will continue to assess the adequacy of the valuation allowance on a quarterly basis.  Our judgments and tax strategies are subject to audit by various taxing authorities.

[0001564590-15-011208:mdna:96]
The objectives of accounting for income taxes are to recognize the amount of taxes payable or refundable for the current year and deferred tax liabilities and assets for the future tax consequences of events that have been recognized in an entity’s financial statements or tax returns. We recognize the tax benefit from an uncertain tax position only if it is more likely than not that the tax position will be sustained on examination by the taxing authorities, based on the technical merits of the position. The tax benefits recognized in the financial statements from such a position should be measured based on the largest benefit that has a greater than 50% likelihood of being realized upon ultimate settlement. Accounting literature also provides guidance on derecognition of income tax assets and liabilities, classification of current and deferred income tax assets and liabilities, accounting for interest and penalties associated with tax positions, and income tax disclosures. Judgment is required in assessing the future tax consequences of events that have been recognized in our financial statements or tax returns. Variations in the actual outcome of these future tax consequences could materially impact our financial statements.

[0001564590-15-011208:mdna:97]
See Note H of Notes to Consolidated Financial Statements included elsewhere in this Annual Report for disclosures related to the valuation allowance recorded in relation to foreign deferred taxes.

[0001564590-15-011208:mdna:98]
Foreign Currency Translation

[0001564590-15-011208:mdna:99]
The functional currency for our foreign subsidiaries is the local currency in which the entity is located. The financial statements of all subsidiaries with a functional currency other than the U.S. Dollar have been translated into U.S. Dollars. All assets and liabilities of foreign operations are translated into U.S. Dollars using year-end exchange rates, and all revenues and expenses are translated at average rates during the respective period. The U.S. Dollar results that arise from such translation, as well as exchange gains and losses on intercompany balances of a long-term investment nature, are included in the cumulative currency translation adjustments in accumulated other comprehensive income in stockholders’ equity.

[0001564590-15-011208:mdna:100]
New Accounting Standards

[0001564590-15-011208:mdna:101]
From time to time, new accounting pronouncements are issued by the Financial Accounting Standards Board (the FASB), which are adopted by us as of the specified effective date. Unless otherwise discussed, management believes that the impact of recently issued standards, which are not yet effective, will not have a material impact on our consolidated statements upon adoption.

[0001564590-15-011208:mdna:102]
In July 2013, the FASB issued accounting guidance on the presentation of an unrecognized tax benefit when a net operating loss carryforward, a similar tax loss, or a tax credit carryforward exists. The guidance states that an unrecognized tax benefit, or a portion of an unrecognized tax benefit, should be presented in the financial statements as a reduction to a deferred tax asset for a net operating loss carryforward, a similar tax loss, or a tax credit carryforward. To the extent a net operating loss carryforward, a similar tax loss, or a tax credit carryforward is not available at the reporting date under the tax law of the applicable jurisdiction to settle any additional income taxes that would result from the disallowance of a tax position or the tax law of the applicable jurisdiction does not require the entity to use, and the entity does not intend to use, the deferred tax asset for such purpose, the unrecognized tax benefit should be presented in the financial statements as a liability and should not be combined with deferred tax assets. This guidance is effective for fiscal years, and interim periods within those years, beginning after December 15, 2013, which was our fiscal year ending September 30, 2015. This guidance should be applied prospectively to all unrecognized tax benefits that exist at the effective date. Retrospective application is permitted. The adoption of this guidance has not had a significant impact on our consolidated financial position or results of operations.

[0001564590-15-011208:mdna:103]
In April 2014, the FASB issued an amendment to the financial reporting of discontinued operations.  The amendments in this update changed the criteria for reporting discontinued operations while enhancing disclosures in this area. It also addresses sources of confusion and inconsistent application related to the financial reporting of discontinued operations guidance in U.S. GAAP.  Under the new guidance, only disposals representing a strategic shift in operations that have a major effect on the organization’s operations and financial results should be presented as discontinued operations. Examples include a disposal of a major geographic area, a major line of business, or a major equity method investment.  In addition, the new guidance requires expanded disclosures about discontinued operations that will provide financial statement users with more information about the assets, liabilities, income, and expenses of discontinued operations.  The new guidance also requires disclosure of the pre-tax income attributable to a disposal of a significant part of an organization that does not qualify for discontinued operations reporting. This disclosure will provide users with information about the ongoing trends in a reporting organization’s results from continuing operations. The amendments in this update are effective in the first quarter of 2015, which would be in our fiscal year ending September 30, 2016.  Early adoption is permitted for disposals that have not been previously reported as discontinued operations. This amendment is not expected to have a material impact on our consolidated financial position or results of operations.

[0001564590-15-011208:mdna:104]
In May 2014, the FASB issued a new standard on revenue recognition that supersedes previously issued revenue recognition guidance.  This standard provides a five-step approach to be applied to all contracts with customers and requires expanded disclosures about the nature, amount, timing and uncertainty of revenue (and the related cash flows) arising from customer contracts, significant judgments and changes in judgments used in applying the revenue model and the assets recognized from costs incurred to obtain or fulfill a contract.  This guidance is now effective for fiscal years, and interim periods within those years, beginning after December 15, 2017, which would be our fiscal year ending September 30, 2019.  The standard permits the use of either the retrospective or cumulative effect transition method therefore we are evaluating the effect that this new guidance will have on our consolidated financial statements and related disclosures. We have not yet selected a transition method nor have we determined the effect of the standard on our ongoing financial reporting.

[0001564590-15-011208:mdna:105]
In June 2014, the FASB issued an amendment to the topic regarding share-based payments and instances where terms of an award provide that a performance target can be achieved after the requisite service period.  This guidance has been provided to resolve the diversity in practice concerning employee share-based payments that contain performance targets that could be achieved after the requisite service period. The updated guidance requires that a performance target that affects vesting and that can be achieved after the requisite service period be treated as a performance condition. Compensation cost should be recognized in the period in which it

[0001564590-15-011208:mdna:106]
becomes probable that the performance target will be achieved and is attributable to the periods for which service has been rendered. If the performance target becomes probable of being achieved before the end of the service period, the remaining unrecognized compensation cost for which requisite service has not yet been rendered is recognized prospectively over the remaining service period. The total amount of compensation cost recognized during and after the service period should reflect the number of awards that are expected to vest and should be adjusted to reflect those awards that ultimately vest. The updated guidance is effective for annual and interim periods beginning after December 15, 2015, with early adoption permitted. The adoption of this guidance is not expected to have a material impact on our consolidated financial position or results of operations.

[0001564590-15-011208:mdna:107]
In July 2015, the FASB issued a new topic on simplifying the measurement of inventory.  The current standard is to measure inventory at lower of cost or market; where market could be replacement cost, net realizable value, or net realizable value less an approximately normal profit margin. This topic updates this guidance to measure inventory at the lower of cost and net realizable value; where net realizable value is the estimated selling prices in the ordinary course of business, less reasonably predictable costs of completion, disposal, and transportation. This update is effective for annual reporting periods beginning after December 15, 2016, which would be our fiscal year ending September 30, 2018.  The amendments should be applied prospectively with earlier application permitted as of the beginning of an interim or annual reporting period. This topic is not expected to have a material impact on our consolidated financial position or results of operations.

[0001564590-15-011208:mdna:108]
23
