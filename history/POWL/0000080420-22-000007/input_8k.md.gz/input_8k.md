# POWL 8-K — 0000080420-22-000005 filed 2022-02-08

## item codes, every 8-K on or before 2022-02-09

- 2022-02-08 0000080420-22-000005 — 2.02, 9.01
- 2022-02-01 0000080420-22-000002 — 8.01, 9.01
- 2021-12-07 0000080420-21-000043 — 2.02, 9.01
- 2021-08-03 0000080420-21-000036 — 2.02, 8.01, 9.01
- 2021-05-04 0000080420-21-000026 — 2.02, 8.01, 9.01
- 2021-03-16 0001193125-21-082878 — 1.01, 2.03, 9.01
- 2021-03-05 0000080420-21-000021 — 5.02, 8.01, 9.01
- 2021-02-26 0000080420-21-000018 — 5.03
- 2021-02-18 0000080420-21-000016 — 5.07
- 2021-02-02 0000080420-21-000010 — 2.02, 8.01, 9.01
- 2020-12-08 0000080420-20-000032 — 2.02, 9.01
- 2020-11-12 0000080420-20-000030 — 8.01, 9.01
- 2020-08-04 0000080420-20-000024 — 2.02, 8.01, 9.01
- 2020-05-05 0000080420-20-000017 — 2.02, 8.01, 9.01
- 2020-02-21 0000080420-20-000008 — 5.07
- 2020-02-04 0000080420-20-000003 — 2.02, 8.01, 9.01
- 2019-12-04 0001193125-19-306243 — 2.02, 9.01
- 2019-11-08 0000080420-19-000032 — 8.01, 9.01
- 2019-10-03 0000080420-19-000030 — 1.01, 2.03
- 2019-09-24 0000080420-19-000028 — 8.01, 9.01
- 2019-08-06 0000080420-19-000022 — 2.02, 8.01, 9.01
- 2019-05-08 0000080420-19-000017 — 5.02, 9.01
- 2019-05-07 0000080420-19-000011 — 2.02, 8.01, 9.01
- 2019-02-22 0001193125-19-048366 — 5.07
- 2019-02-05 0000080420-19-000003 — 2.02, 8.01
- 2018-12-21 0000080420-18-000038 — 5.02, 9.01
- 2018-12-12 0000080420-18-000031 — 2.02
- 2018-11-05 0000080420-18-000029 — 8.01, 9.01
- 2018-11-01 0000080420-18-000027 — 5.02, 8.01, 9.01
- 2018-10-01 0000080420-18-000024 — 5.02
- 2018-08-07 0000080420-18-000020 — 2.02, 8.01
- 2018-05-15 0000080420-18-000016 — 5.02, 8.01
- 2018-05-09 0000080420-18-000011 — 2.02, 8.01
- 2018-02-22 0000080420-18-000009 — 5.07
- 2018-02-06 0000080420-18-000003 — 2.02, 8.01
- 2017-12-27 0001193125-17-379928 — 5.02
- 2017-12-05 0000080420-17-000028 — 2.02, 9.01
- 2017-11-08 0000080420-17-000024 — 8.01, 9.01
- 2017-11-03 0000080420-17-000022 — 5.02
- 2017-08-09 0000080420-17-000017 — 2.02, 8.01
- 2017-06-30 0000080420-17-000014 — 1.01, 9.01
- 2017-05-03 0000080420-17-000006 — 2.02, 8.01, 9.01
- 2017-02-23 0000080420-17-000004 — 5.07
- 2017-02-08 0001628280-17-000965 — 2.02 — amendment of 0001628280-17-000949
- 2017-02-07 0001628280-17-000949 — 2.01, 8.01, 9.01
- 2016-12-07 0001193125-16-787354 — 2.02, 9.01
- 2016-11-01 0001193125-16-755475 — 8.01, 9.01
- 2016-09-30 0001193125-16-726999 — 5.02, 8.01, 9.01
- 2016-08-03 0001193125-16-669308 — 2.02, 8.01, 9.01
- 2016-05-04 0001193125-16-576528 — 2.02, 8.01, 9.01
- 2016-02-25 0001193125-16-477896 — 5.07
- 2016-02-03 0001193125-16-449052 — 2.02, 8.01, 9.01
- 2015-12-31 0001193125-15-418363 — 5.02, 7.01, 9.01
- 2015-12-02 0001193125-15-393109 — 2.02, 9.01
- 2015-11-05 0001193125-15-368085 — 8.01, 9.01
- 2015-09-25 0001193125-15-329031 — 5.02
- 2015-08-05 0001193125-15-277912 — 2.02, 8.01, 9.01
- 2015-05-06 0001193125-15-174291 — 2.02, 8.01, 9.01
- 2015-03-06 0001193125-15-081070 — 5.02
- 2015-03-02 0001193125-15-072946 — 5.07
- 2015-02-03 0001193125-15-031772 — 2.02, 8.01, 9.01
- 2014-12-18 0001193125-14-446513 — 8.01, 9.01
- 2014-12-03 0001193125-14-431745 — 2.02, 9.01
- 2014-11-05 0001193125-14-397955 — 8.01, 9.01
- 2014-09-26 0001193125-14-353741 — 7.01, 9.01
- 2014-08-05 0001193125-14-296001 — 2.02, 8.01, 9.01
- 2014-05-07 0001193125-14-187496 — 2.02, 8.01, 9.01
- 2014-03-03 0001193125-14-079843 — 5.02, 5.07
- 2014-02-05 0001193125-14-036633 — 2.02, 8.01, 9.01
- 2014-01-17 0001193125-14-014351 — 1.01, 8.01, 9.01
- 2014-01-06 0001193125-14-002795 — 1.01, 2.03
- 2013-12-06 0001564590-13-001411 — 2.02, 9.01
- 2013-12-05 0001564590-13-001406 — 5.02, 8.01, 9.01
- 2013-11-07 0001193125-13-432950 — 8.01, 9.01
- 2013-08-07 0001193125-13-324337 — 2.02, 9.01
- 2013-05-08 0001193125-13-206800 — 2.02, 9.01
- 2013-02-22 0001193125-13-070971 — 5.02, 5.07
- 2013-02-06 0001193125-13-040556 — 2.02, 9.01
- 2012-12-18 0001193125-12-506417 — 5.02, 9.01
- 2012-12-05 0001193125-12-491749 — 2.02, 9.01
- 2012-10-12 0001193125-12-421889 — 3.03, 5.02, 5.03, 9.01
- 2012-08-09 0001193125-12-344617 — 5.02, 8.01, 9.01
- 2012-08-08 0001193125-12-343630 — 2.02, 9.01
- 2012-05-09 0001193125-12-221356 — 2.02, 9.01
- 2012-02-08 0001193125-12-046560 — 2.02, 9.01
- 2011-12-08 0001193125-11-334810 — 2.02, 9.01
- 2011-11-08 0000950123-11-096524 — 2.02, 2.06, 4.02, 9.01
- 2011-10-14 0000950123-11-090124 — 5.02
- 2011-10-06 0000950123-11-088969 — 5.02
- 2011-09-19 0000950123-11-085224 — 5.02, 9.01
- 2011-09-15 0000950123-11-084806 — 5.02, 9.01
- 2011-08-04 0000950123-11-072788 — 2.02, 9.01
- 2011-07-22 0000950123-11-067402 — 5.07
- 2011-05-24 0000950123-11-053550 — 1.01, 2.03, 9.01
- 2011-05-04 0000950123-11-044561 — 2.02, 9.01
- 2011-02-02 0000950123-11-008188 — 2.02, 9.01
- 2010-12-08 0000950123-10-111987 — 2.02, 9.01
- 2010-08-05 0000950123-10-073114 — 2.02, 9.01
- 2010-05-18 0000950123-10-050900 — 5.02
- 2010-05-05 0000950123-10-044499 — 2.02, 9.01
- 2010-02-03 0000950123-10-008278 — 2.02, 9.01
- 2009-12-21 0000950123-09-072269 — 1.01, 2.01, 2.03, 8.01, 9.01
- 2009-12-09 0000950123-09-069525 — 2.02, 9.01
- 2009-10-27 0000950123-09-053501 — 1.01, 8.01, 9.01
- 2009-08-04 0000950123-09-029476 — 2.02, 9.01
- 2009-05-06 0000950129-09-001498 — 2.02, 9.01
- 2009-03-05 0000950129-09-000749 — 1.01, 9.01
- 2009-02-10 0000950129-09-000349 — 2.02, 9.01
- 2008-12-10 0000950134-08-021934 — 2.02, 9.01
- 2008-08-06 0000950129-08-004267 — 2.02, 9.01
- 2008-07-24 0000950129-08-004063 — 1.01, 5.02, 8.01, 9.01
- 2008-06-16 0000950129-08-003500 — 9.01 — amendment of 0000950134-06-015374
- 2008-06-05 0000950129-08-003378 — 5.02, 9.01
- 2008-05-08 0000950129-08-002843 — 2.02, 9.01
- 2008-02-06 0000950129-08-000533 — 2.02, 9.01
- 2007-12-19 0000950129-07-006277 — 1.01, 2.03, 9.01
- 2007-12-06 0000950129-07-006003 — 2.02, 9.01
- 2007-08-21 0000950129-07-004181 — 2.02, 9.01
- 2007-05-31 0000950129-07-002810 — 2.02, 9.01
- 2007-05-21 0000950129-07-002668 — 2.02, 3.01, 4.02, 9.01
- 2007-04-16 0000950129-07-002002 — 2.02, 4.02, 9.01
- 2007-03-01 0000950129-07-001104 — 5.02, 8.01, 9.01
- 2007-02-08 0000950129-07-000451 — 2.02, 9.01
- 2006-12-08 0000950129-06-010041 — 2.02, 9.01
- 2006-09-08 0000950129-06-008379 — 2.02, 9.01
- 2006-08-09 0000950134-06-015374 — 1.01, 2.01, 8.01, 9.01
- 2006-06-08 0000950129-06-006127 — 2.02, 9.01
- 2006-03-09 0000950129-06-002455 — 2.02, 9.01
- 2005-12-16 0000950129-05-012031 — 2.02, 5.03, 9.01
- 2005-09-13 0000950129-05-009181 — 2.01, 9.01 — amendment of 0000950129-05-006889
- 2005-09-12 0000950129-05-009151 — 2.02, 9.01
- 2005-07-06 0000950129-05-006889 — 1.01, 1.02, 2.01, 2.03, 9.01
- 2005-06-10 0000950129-05-006128 — 2.02, 9.01
- 2005-04-20 0000080420-05-000031 — 5.02
- 2005-03-11 0000080420-05-000024 — 9.01
- 2005-02-25 0000080420-05-000018 — 7.01, 9.01
- 2005-01-21 0000080420-05-000009 — 7.01, 9.01
- 2004-12-17 0000080420-04-000049 — 2.02, 9.01
- 2004-11-01 0000080420-04-000045 — 8.01, 9.01
- 2004-10-08 0001169232-04-005133 — 2.05
- 2004-09-14 0000080420-04-000037 — 5.02
- 2004-09-02 0000080420-04-000030 — 2.02, 9.01
- 2004-06-08 0000080420-04-000021 — 7
- 2004-05-13 0000080420-04-000019 — 4
- 2004-02-27 0000080420-04-000013 — 7
- 2003-12-16 0000950129-03-006136 — 12, 7
- 2003-08-29 0000950129-03-004531 — 12, 7
- 2003-06-03 0000950129-03-003035 — 7, 9
- 2003-05-15 0000950129-03-002812 — 7, 9
- 2002-05-29 0000950129-02-002795 — 4
- 2000-12-21 0000950129-00-006093 — 5, 7
- 1998-09-04 0000950129-98-003802 — 5
- 1996-08-09 0000950129-96-001705 — 2, 7

## late-filing notifications on or before 2022-02-09

- 2007-05-11 0000950129-07-002494 — NT 10-Q, for the period ended 2007-03-31
- 2005-01-18 0000080420-05-000004 — NT 10-K, for the period ended 2004-10-31

## item 2.02 — earnings release, exhibit 99.1

[0000080420-22-000005:8k_2_02:1]
EX-99.1
2
ex991-q122earningsrelease.htm
EX-99.1

[0000080420-22-000005:8k_2_02:2]
Document

[0000080420-22-000005:8k_2_02:3]
Exhibit 99.1

[0000080420-22-000005:8k_2_02:4]
PRESS RELEASE

[0000080420-22-000005:8k_2_02:5]
FOR IMMEDIATE RELEASE

[0000080420-22-000005:8k_2_02:6]
Contacts:        Michael W. Metcalf, CFO

[0000080420-22-000005:8k_2_02:7]
Powell Industries, Inc.

[0000080420-22-000005:8k_2_02:8]
713-947-4422

[0000080420-22-000005:8k_2_02:9]
Robert Winters or Ryan Coleman

[0000080420-22-000005:8k_2_02:10]
Alpha IR Group

[0000080420-22-000005:8k_2_02:11]
POWL@alpha-ir.com

[0000080420-22-000005:8k_2_02:12]
312-445-2870

[0000080420-22-000005:8k_2_02:13]
POWELL INDUSTRIES ANNOUNCES FISCAL 2022 FIRST QUARTER RESULTS

[0000080420-22-000005:8k_2_02:14]
HOUSTON — February 8, 2022 — Powell Industries, Inc. (NASDAQ: POWL), a leading supplier of custom-engineered solutions for the management, control and distribution of electrical energy, today announced results for the fiscal 2022 first quarter ended December 31, 2021.

[0000080420-22-000005:8k_2_02:15]
Fiscal First Quarter Key Highlights:

[0000080420-22-000005:8k_2_02:16]
•Revenues totaled $107 million;

[0000080420-22-000005:8k_2_02:17]
•Net Loss was $2.8 million, or a loss of $0.24 per diluted share;

[0000080420-22-000005:8k_2_02:18]
•New orders of $108 million included $122 million of gross new orders, partially offset by $14 million of scope reductions;

[0000080420-22-000005:8k_2_02:19]
•Backlog as of December 31, 2021 totaled $416 million;

[0000080420-22-000005:8k_2_02:20]
•Cash and short-term investments as of December 31, 2021 totaled $102 million.

[0000080420-22-000005:8k_2_02:21]
Brett A. Cope, Powell’s Chairman and Chief Executive Officer, stated, “Operationally, our first fiscal quarter was largely aligned with the seasonal softness that we have experienced in prior periods, while commercial activity across our end markets and the cadence of new orders has remained steady. On a gross basis, new orders of $122 million marks the third consecutive

[0000080420-22-000005:8k_2_02:22]
quarter of increased order activity as the industrial end markets steadily recover from the lower activity levels experienced throughout fiscal 2020 and 2021. Inflation however, continues to pressure our gross margins as key commodities such as steel and copper are lifting our materials costs. Additionally, we are executing backlog on projects that were booked in fiscal 2020 and 2021, that are presently exposed to the higher cost levels, which we outlined last quarter. We are actively working to mitigate these macroeconomic variables, but do expect that margin pressure will persist into the second half of our fiscal 2022. Overall, we are pleased with the steady recovery in our core industrial end markets while our Traction and Utility markets remain active, as evidenced by our book-to-bill ratio in the current fiscal quarter of 1.0x.”

[0000080420-22-000005:8k_2_02:23]
Revenues for the first quarter totaled $106.6 million compared to $129.5 million in the fourth fiscal quarter of 2021 and compared to $106.6 million in the first fiscal quarter 2021.

[0000080420-22-000005:8k_2_02:24]
New orders placed in the first quarter of $108 million included $122 million of gross new orders, partially offset by $14 million of scope reductions on a previously booked project. The $108 million of net new orders is compared to $121 million in the fourth quarter of fiscal 2021 and to $91 million of new orders in the first quarter of fiscal 2021.

[0000080420-22-000005:8k_2_02:25]
Backlog as of December 31, 2021 totaled $416 million which represents a sequential increase of $1 million and compares to $465 million as of December 31, 2020.

[0000080420-22-000005:8k_2_02:26]
Net loss for the fiscal first quarter was $2.8 million, or a loss of $0.24 per diluted share, compared to net income in the fourth quarter of fiscal 2021 of $3.3 million, or $0.28 per diluted share, and compared to a net loss of $0.4 million, or a loss of $0.03 per diluted share, in the first quarter of fiscal 2021.

[0000080420-22-000005:8k_2_02:27]
Cope added, “Over the near-term, we remain encouraged by the firming of our Oil & Gas and Petrochemical end markets and continue to expect the fundamentals within LNG, gas pipeline and gas-to-chemical projects to remain favorable.”

[0000080420-22-000005:8k_2_02:28]
2

[0000080420-22-000005:8k_2_02:29]
OUTLOOK

[0000080420-22-000005:8k_2_02:30]
Commenting on the Company's outlook, Michael Metcalf, Powell’s Chief Financial Officer said, “As we look forward to the remainder of Fiscal 2022, we maintain our cautious optimism relative to the continued recovery of our core industrial end markets. Additionally, we remain acutely focused on the supply side macro-environment, as well as our internal cost management in order to manage inflationary cost pressures and pricing.  Through these efforts, combined with continued stability across our industrial end markets, we anticipate a gradual recovery throughout the remainder of the fiscal year.  Our backlog remains very strong, while the orders cadence continues to improve compared to the prior year.  Considering this, in addition to our strong balance sheet, we are well positioned to deliver improved financial performance as we progress through the remainder of the year.”

[0000080420-22-000005:8k_2_02:31]
CONFERENCE CALL

[0000080420-22-000005:8k_2_02:32]
Powell Industries has scheduled a conference call for Wednesday, February 9, 2022 at 11:00 a.m. Eastern time.   To participate in the conference call, dial 1-833-953-2431 (domestic) or 1-412-317-5760 (international) at least 10 minutes before the call begins and ask for the Powell Industries conference call.  A telephonic replay of the conference call will be available through February 16, 2022 and may be accessed by calling 1-877-344-7529 (domestic) or 1-412-317-0088 (international) and using passcode 4441856#.

[0000080420-22-000005:8k_2_02:33]
Investors, analysts and the general public will also have the opportunity to listen to the conference call over the Internet by visiting powellind.com. To listen to the live call on the web, please visit the website at least 15 minutes before the call begins to register, download and install any necessary audio software.  For those who cannot listen to the live webcast, an archive will be available shortly after the call and will remain available for approximately 90 days at powellind.com.

[0000080420-22-000005:8k_2_02:34]
Powell Industries, Inc., headquartered in Houston, designs, manufactures and services custom-engineered equipment and systems for the distribution, control and monitoring of electrical energy.  Powell markets include large industrial customers such as utilities, oil and gas producers, refineries, liquefied natural gas facilities, petrochemical plants, pulp and paper producers, mining operations and commuter railways.   For more information, please visit powellind.com.

[0000080420-22-000005:8k_2_02:35]
4

[0000080420-22-000005:8k_2_02:36]
POWELL INDUSTRIES, INC. & SUBSIDIARIES

[0000080420-22-000005:8k_2_02:37]
CONDENSED CONSOLIDATED STATEMENT OF OPERATIONS

[0000080420-22-000005:8k_2_02:38]
|  | Three Months Ended December 31, |  |  |
|  | 2021 |  | 2020 |  |  |  |  |
| (In thousands, except per share data) |  |  |  |  |  |  |  |
|  | (Unaudited) |  |  |  |  |
| Revenues | $ | 106,569 |  |  | $ | 106,575 |  |  |  |  |  |
| Cost of goods sold | 93,133 |  |  | 88,304 |  |  |  |  |  |
| Gross profit | 13,436 |  | 18,271 |  |  |  |  |
| Selling, general and administrative expenses | 15,902 |  |  | 16,874 |  |  |  |  |  |
| Research and development expenses | 1,824 |  |  | 1,673 |  |  |  |  |  |
| Amortization of intangible assets | — |  |  | 44 |  |  |  |  |  |
| Operating income (loss) | (4,290) |  |  | (320) |  |  |  |  |  |
| Interest expense | 47 |  |  | 50 |  |  |  |  |  |
| Interest income | (50) |  |  | (111) |  |  |  |  |  |
| Loss before income taxes | (4,287) |  |  | (259) |  |  |  |  |  |
| Income tax provision (benefit) | (1,441) |  |  | 105 |  |  |  |  |  |
| Net loss | $ | (2,846) |  |  | $ | (364) |  |  |  |  |  |
| Loss per share: |  |  |  |  |  |  |  |
| Basic | $ | (0.24) |  |  | $ | (0.03) |  |  |  |  |  |
| Diluted | $ | (0.24) |  |  | $ | (0.03) |  |  |  |  |  |
| Weighted average shares: |  |  |  |  |  |  |  |
| Basic | 11,765 |  |  | 11,674 |  |  |  |  |  |
| Diluted | 11,765 |  |  | 11,674 |  |  |  |  |  |
| SELECTED FINANCIAL DATA: |  |  |  |  |  |  |  |
| Depreciation and Amortization | $ | 2,414 |  |  | $ | 2,630 |  |  |  |  |  |
| Capital Expenditures | $ | 436 |  |  | $ | 961 |  |  |  |  |  |
| Dividends Paid | $ | 3,048 |  |  | $ | 3,028 |  |  |  |  |  |

[0000080420-22-000005:8k_2_02:39]
5

[0000080420-22-000005:8k_2_02:40]
POWELL INDUSTRIES, INC. & SUBSIDIARIES

[0000080420-22-000005:8k_2_02:41]
CONDENSED CONSOLIDATED BALANCE SHEETS

[0000080420-22-000005:8k_2_02:42]
|  | December 31, 2021 |  | September 30, 2021 |
| (In thousands) | (Unaudited) |
| Assets: |  |  |  |
| Cash, cash equivalents and short-term investments | $ | 101,527 |  |  | $ | 133,981 |  |
| Other current assets | 188,881 |  |  | 168,480 |  |
| Property, plant and equipment, net | 107,509 |  |  | 109,457 |  |
| Long-term assets | 25,883 |  |  | 24,274 |  |
| Total assets | $ | 423,800 |  |  | $ | 436,192 |  |
| Liabilities and equity: |  |  |  |
| Current liabilities | $ | 113,668 |  |  | $ | 121,156 |  |
| Deferred and other long-term liabilities | 14,553 |  | 13,813 |
| Stockholders’ equity | 295,579 |  |  | 301,223 |  |
| Total liabilities and stockholders’ equity | $ | 423,800 |  |  | $ | 436,192 |  |
| SELECTED FINANCIAL DATA: |  |  |  |
| Working capital | $ | 176,740 |  |  | $ | 181,305 |  |
