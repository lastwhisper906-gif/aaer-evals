# POWL notes — 0000080420-22-000007


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureAndSignificantAccountingPoliciesTextBlock

[0000080420-22-000007:notes:1]
[same as prior period, unchanged from 0000080420-21-000041:notes:1]

[0000080420-22-000007:notes:2]
Powell Industries, Inc. (we, us, our, Powell or the Company) is incorporated in the state of Delaware. Powell's predecessor companies were founded 75 years ago by William E. Powell in 1947. Our major subsidiaries, all of which are wholly owned, include: Powell Electrical Systems, Inc.; Powell (UK) Limited; Powell Canada Inc.; and Powell Industries International, B.V.

[0000080420-22-000007:notes:3]
We develop, design, manufacture and service custom-engineered equipment and systems which (1) distribute, control and monitor the flow of electrical energy and (2) provide protection to motors, transformers and other electrically powered equipment. We are headquartered in Houston, Texas and serve the oil and gas and petrochemical markets, which include onshore and offshore production, liquefied natural gas (LNG) facilities and terminals, pipelines, refineries and petrochemical plants. Additional markets include electric utility and light rail traction power as well as mining and metals, pulp and paper and other municipal, commercial and industrial markets.

[0000080420-22-000007:notes:4]
[same as prior period, unchanged from 0000080420-21-000041:notes:4]

[0000080420-22-000007:notes:5]
The COVID-19 pandemic continues to impact global energy markets. This pandemic has negatively impacted demand, which in turn has resulted in considerable volatility across global oil and gas commodity markets. As a result, some of our industrial customers are deferring or suspending their planned capital expenditures. Certain of our customers have asked that we delay or cancel our manufacturing on their projects as their operations have been negatively impacted by this pandemic and the reduced oil and gas demand, which has resulted in recognition of cancellation fees based on contract terms and the extent of our progress on the projects. We continue to work with and review the contracts with our key suppliers who have been impacted by this pandemic to ensure that we are able to meet our customer commitments.

[0000080420-22-000007:notes:6]
The consequences of a prolonged global economic decline could include, but are not limited to, a continued reduction in commercial and industrial activity. The Company cannot reasonably estimate the duration or severity of this pandemic, or the extent to which the resulting disruptions may materially impact our business, results of operations or cash flows. We will take prudent measures to maintain our strong liquidity and cash position, which may include reducing our capital expenditures and research and development costs, as well as reducing or eliminating future dividend payments.

[0000080420-22-000007:notes:7]
[same as prior period, unchanged from 0000080420-21-000041:notes:7]

[0000080420-22-000007:notes:8]
[same as prior period, unchanged from 0000080420-21-000041:notes:8]

[0000080420-22-000007:notes:9]
[same as prior period, unchanged from 0000080420-21-000041:notes:9]

[0000080420-22-000007:notes:10]
These unaudited condensed consolidated financial statements should be read in conjunction with the audited consolidated financial statements and notes thereto of Powell and its subsidiaries included in Powell’s Annual Report on Form 10-K for the year ended September 30, 2021, which was filed with the Securities and Exchange Commission (SEC) on December 8, 2021.

[0000080420-22-000007:notes:11]
References to Fiscal 2022 and Fiscal 2021 used throughout this report shall mean our fiscal years ended September 30, 2022 and 2021, respectively.
Use of EstimatesThe preparation of condensed consolidated financial statements in conformity with U.S. GAAP requires management to make estimates and assumptions that affect the amounts reported in the condensed consolidated financial statements and accompanying footnotes. The most significant estimates used in our condensed consolidated financial statements affect revenue recognition and estimated cost recognition on our customer contracts, the allowance for credit losses, provision for excess and obsolete inventory, warranty accruals and income taxes. The amounts recorded for warranties, legal, income taxes, impairment of long-lived assets (when applicable), liquidated damages and other contingent liabilities require judgments regarding the amount of expenses that will ultimately be incurred. We base our estimates on historical experience, forecasts and various other assumptions, as well as the specific circumstances surrounding these contingent liabilities, in evaluating the amount of liability that should be recorded. Additionally, the recognition of deferred tax assets requires estimates related to future income and other assumptions regarding timing and future profitability because the ultimate realization of net deferred tax assets is dependent on the generation of future taxable income during the periods in which temporary differences become deductible. Estimates routinely change as new events occur, additional information becomes available or operating environments change. Actual results may differ from our prior estimates.


## us-gaap:EarningsPerShareTextBlock

[0000080420-22-000007:notes:12]
[same as prior period, unchanged from 0000080420-21-000041:notes:16]

[0000080420-22-000007:notes:13]
[same as prior period, unchanged from 0000080420-21-000041:notes:17]

[0000080420-22-000007:notes:14]
|  | Three months ended December 31, |  |  |
|  | 2021 |  | 2020 |  |  |  |  |
| Numerator: |  |  |  |  |  |  |  |
| Net loss | $ | (2,846) |  |  | $ | (364) |  |  |  |  |  |
| Denominator: |  |  |  |  |  |  |  |
| Weighted average basic shares | 11,765 |  |  | 11,674 |  |  |  |  |  |
| Dilutive effect of restricted stock units | — |  |  | — |  |  |  |  |  |
| Weighted average diluted shares | 11,765 |  |  | 11,674 |  |  |  |  |  |
| Loss per share: |  |  |  |  |  |  |  |
| Basic | $ | (0.24) |  |  | $ | (0.03) |  |  |  |  |  |
| Diluted | $ | (0.24) |  |  | $ | (0.03) |  |  |  |  |  |

[0000080420-22-000007:notes:15]
For each of the three months ended December 31, 2021 and 2020, we incurred net losses and therefore all potential common shares were deemed to be anti-dilutive.


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0000080420-22-000007:notes:16]
[same as prior period, unchanged from 0000080420-21-000041:notes:20]

[0000080420-22-000007:notes:17]
[same as prior period, unchanged from 0000080420-21-000041:notes:21]

[0000080420-22-000007:notes:18]
|  | Three months ended December 31, |  |  |
|  | 2021 |  | 2020 |  |  |  |  |
| Balance at beginning of period | $ | 333 |  |  | $ | 510 |  |  |  |  |  |
| Bad debt expense (recovery), net | 91 |  |  | (19) |  |  |  |  |  |
| Uncollectible accounts written off, net of recoveries | (14) |  |  | (10) |  |  |  |  |  |
| Change due to foreign currency translation | 1 |  |  | 12 |  |  |  |  |  |
| Balance at end of period | $ | 411 |  |  | $ | 493 |  |  |  |  |  |

[0000080420-22-000007:notes:19]
[same as prior period, unchanged from 0000080420-21-000041:notes:23]

[0000080420-22-000007:notes:20]
[same as prior period, unchanged from 0000080420-21-000041:notes:24]

[0000080420-22-000007:notes:21]
|  | December 31, 2021 |  | September 30, 2021 |
| Raw materials, parts and sub-assemblies, net | $ | 35,295 |  |  | $ | 28,688 |  |
| Work-in-progress | 862 |  |  | 1,147 |  |
| Total inventories | $ | 36,157 |  |  | $ | 29,835 |  |

[0000080420-22-000007:notes:22]
[same as prior period, unchanged from 0000080420-21-000041:notes:26]

[0000080420-22-000007:notes:23]
[same as prior period, unchanged from 0000080420-21-000041:notes:27]

[0000080420-22-000007:notes:24]
|  | Three months ended December 31, |  |  |
|  | 2021 |  | 2020 |  |  |  |  |
| Balance at beginning of period | $ | 2,531 |  |  | $ | 2,771 |  |  |  |  |  |
| Increase to warranty expense | 293 |  |  | 658 |  |  |  |  |  |
| Deduction for warranty charges | (382) |  |  | (779) |  |  |  |  |  |
| Change due to foreign currency translation | 1 |  |  | 25 |  |  |  |  |  |
| Balance at end of period | $ | 2,443 |  |  | $ | 2,675 |  |  |  |  |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0000080420-22-000007:notes:25]
[same as prior period, unchanged from 0000080420-21-000041:notes:29]

[0000080420-22-000007:notes:26]
Our revenues are primarily generated from the manufacturing of custom-engineered products and systems under long-term fixed-price contracts under which we agree to manufacture various products such as traditional and arc-resistant distribution switchgear and control gear, medium-voltage circuit breakers, monitoring and control communications systems, motor control centers, switches and bus duct systems. These products may be sold separately as an engineered solution but are typically integrated into custom-built enclosures which we also build. These enclosures are referred to as power control room substations (PCRs®), custom-engineered modules or electrical houses (E-Houses). Some contracts may also include the installation and the commissioning of these enclosures.

[0000080420-22-000007:notes:27]
Revenue from these contracts is generally recognized over time utilizing the cost-to-cost method. Under the cost-to-cost method, the extent of progress towards completion is measured based on the ratio of costs incurred to date to the total estimated costs at completion of the performance obligation. We believe that this method is the most accurate representation of our performance, because it directly measures the value of the services transferred to the customer over time as we incur costs on our contracts. Contract costs include all direct materials, labor and indirect costs related to contract performance, which may include indirect labor, supplies, tools, repairs and depreciation costs.

[0000080420-22-000007:notes:28]
We also have contracts to provide value-added services such as field service inspection, installation, commissioning, modification and repair, as well as retrofit and retrofill components for existing systems.  If the service contract terms give us the right to invoice the customer for an amount that corresponds directly with the value of our performance completed to date (i.e., a service contract in which we bill a fixed amount for each hour of service provided), then we recognize revenue over time in each reporting period corresponding to the amount with which we have the right to invoice.  Our performance obligations are satisfied as the work progresses. Revenues from our custom-engineered products and value-added services transferred to customers over time accounted for approximately 94% of total revenues for the three months ended December 31, 2021 and 92% of total revenues for the three months ended December 31, 2020.

[0000080420-22-000007:notes:29]
Additionally, we have sales orders for spare parts and replacement circuit breakers for switchgear that are obsolete or that are no longer produced by the original manufacturer. Revenues from these sales orders are recognized at the time we fulfill our performance obligation to the customer, which is typically upon shipment and represented approximately 6% of total revenues for the three months ended December 31, 2021 and 8% of total revenues for the three months ended December 31, 2020.

[0000080420-22-000007:notes:30]
Some contracts may contain a cancellation clause that could limit the amount of revenue we are able to recognize over time. In these instances, revenue and costs associated with these contracts are deferred and recognized at a point in time when the performance obligation is fulfilled.

[0000080420-22-000007:notes:31]
Selling and administrative costs incurred in relation to obtaining a contract are typically expensed as incurred. We periodically utilize a third-party sales agent to obtain a contract and will pay a commission to that agent. We record the full commission liability to the third-party sales agents at the order date, with a corresponding deferred asset. As the project progresses, we record commission expense based on percentage of completion rates that correlate to the project and reduce the deferred asset. Once we have been paid by the customer, we pay the commission and the deferred liability is reduced.

[0000080420-22-000007:notes:32]
[same as prior period, unchanged from 0000080420-21-000041:notes:37]

[0000080420-22-000007:notes:33]
A performance obligation is a promise in a contract or with a customer to transfer a distinct good or service. A contract’s transaction price is allocated to each distinct performance obligation and recognized as revenue as the performance obligations are satisfied. To determine the proper revenue recognition for contracts, we evaluate whether a contract should be accounted for as more than one performance obligation or, less commonly, whether two or more contracts should be combined and accounted for as one performance obligation.  This evaluation of performance obligations requires significant judgment.  The majority of our contracts have a single performance obligation where multiple engineered products and services are combined into a single custom-engineered solution. Our contracts include a standard one-year assurance warranty. Occasionally, we provide service-type warranties that will extend the warranty period. These extended warranties qualify as a separate performance obligation, and revenue is deferred and recognized over the warranty period. If we determine during the evaluation of the contract that there are multiple performance obligations, we allocate the transaction price to each performance obligation using our best estimate of the standalone selling price of each distinct good or service in the contract.

[0000080420-22-000007:notes:34]
Remaining unsatisfied performance obligations, which we refer to as backlog, represent the estimated transaction price for goods and services for which we have a material right, but work has not been performed. As of December 31, 2021, we had backlog of $416.0 million, of which approximately $301.7 million is expected to be recognized as revenue within the next twelve months. Backlog may not be indicative of future operating results as orders may be cancelled or modified by our customers. Our backlog does not include service and maintenance-type contracts for which we have the right to invoice as services are performed.

[0000080420-22-000007:notes:35]
[same as prior period, unchanged from 0000080420-21-000041:notes:40]

[0000080420-22-000007:notes:36]
Actual revenues and project costs may vary from previous estimates due to changes in a variety of factors. The cost estimation process is based upon the professional knowledge and experience of our engineers, project managers and financial professionals. Factors that are considered in estimating the work to be completed and ultimate contract recovery include the availability and productivity of labor, the nature and complexity of the work to be performed, the availability of materials, and the effect of any delays on our project performance. We periodically review our job performance, job conditions, estimated profitability and final contract settlements, including our estimate of total costs and make revisions to costs and income in the period in which the revisions are probable and reasonably estimable. We bear the risk of cost overruns in most of our contracts, which may result in reduced profits. Whenever revisions of estimated contract costs and contract values indicate that the contract costs will exceed estimated revenues, thus creating a loss, a provision for the total estimated loss is recorded in that period.

[0000080420-22-000007:notes:37]
For the three months ended December 31, 2021 and 2020, our operating results were positively impacted by $2.8 million and $5.5 million, respectively, as a result of changes in contract estimates related to projects in progress at the beginning of the respective period. These changes in estimates resulted primarily from favorable project execution and negotiations of variable consideration, discussed below, as well as revenue and reduced costs recognized from project cancellations and other changes in facts and circumstances during these periods. The decrease from the prior year is primarily due to the increase in raw material commodity costs.

[0000080420-22-000007:notes:38]
[same as prior period, unchanged from 0000080420-21-000041:notes:43]

[0000080420-22-000007:notes:39]
[same as prior period, unchanged from 0000080420-21-000041:notes:44]

[0000080420-22-000007:notes:40]
[same as prior period, unchanged from 0000080420-21-000041:notes:45]

[0000080420-22-000007:notes:41]
[same as prior period, unchanged from 0000080420-21-000041:notes:46]

[0000080420-22-000007:notes:42]
[same as prior period, unchanged from 0000080420-21-000041:notes:47]

[0000080420-22-000007:notes:43]
[same as prior period, unchanged from 0000080420-21-000041:notes:48]

[0000080420-22-000007:notes:44]
[same as prior period, unchanged from 0000080420-21-000041:notes:49]

[0000080420-22-000007:notes:45]
[same as prior period, unchanged from 0000080420-21-000041:notes:50]

[0000080420-22-000007:notes:46]
Our contract assets and liabilities are reported in a net position on a contract-by-contract basis at the end of each reporting period and are generally classified as current.

[0000080420-22-000007:notes:47]
Contract assets and liabilities as of December 31, 2021 and September 30, 2021 are summarized below (in thousands):

[0000080420-22-000007:notes:48]
|  | December 31, 2021 |  | September 30, 2021 |
| Contract assets | $ | 67,904 |  |  | $ | 54,199 |  |
| Contract liabilities | (49,396) |  |  | (42,433) |  |
| Net contract asset | $ | 18,508 |  |  | $ | 11,766 |  |

[0000080420-22-000007:notes:49]
The increase in net contract asset at December 31, 2021 from September 30, 2021 was primarily due to the timing of contract billing milestones and new orders as well as cash used on our large industrial project awarded in Fiscal 2020. To determine the amount of revenue recognized during the period from contract liabilities, we first allocate revenue to the individual contract liability balance outstanding at the beginning of the period until the revenue exceeds that balance. During the three months ended December 31, 2021, we recognized revenue of approximately $23.3 million that was related to contract liabilities outstanding at September 30, 2021.

[0000080420-22-000007:notes:50]
The timing of our invoice process is typically dependent on the completion of certain milestones and contract terms and subject to agreement by our customer.  Payment is typically expected within 30 days of invoice. Any uncollected invoiced amounts for our performance obligations recognized over time, including contract retentions, are recorded as accounts receivable in the Condensed Consolidated Balance Sheets. Certain contracts allow customers to withhold a small percentage of billings pursuant to retainage provisions, and such amounts are generally due upon completion of the contract and acceptance of the project by the customer. Based on our experience in recent years, the majority of these retainage balances are expected to be collected within approximately twelve months. As of December 31, 2021 and September 30, 2021, accounts receivable included retention amounts of $9.3 million and $9.6 million, respectively. Of the retained amount at December 31, 2021, $6.8 million is expected to be collected in the next twelve months and is recorded in accounts receivable. The remaining $2.5 million is recorded in other assets.

[0000080420-22-000007:notes:51]
[same as prior period, unchanged from 0000080420-21-000041:notes:56]

[0000080420-22-000007:notes:52]
The following tables present our disaggregated revenue by geographic destination and market sector for the three months ended December 31, 2021 and 2020 (in thousands):

[0000080420-22-000007:notes:53]
|  | Three months ended December 31, |  |  |
|  | 2021 |  | 2020 |  |  |  |  |
| United States | $ | 82,145 |  |  | $ | 80,586 |  |  |  |  |  |
| Canada | 15,125 |  |  | 14,091 |  |  |  |  |  |
| Europe, Middle East and Africa | 7,830 |  |  | 8,256 |  |  |  |  |  |
| Asia/Pacific | 944 |  |  | 2,716 |  |  |  |  |  |
| Mexico, Central and South America | 525 |  |  | 926 |  |  |  |  |  |
| Total revenues by geographic destination | $ | 106,569 |  |  | $ | 106,575 |  |  |  |  |  |

[0000080420-22-000007:notes:54]
|  | Three months ended December 31, |  |  |
|  | 2021 |  | 2020 |  |  |  |  |
| Oil and gas (excludes petrochemical) | $ | 43,021 |  |  | $ | 40,028 |  |  |  |  |  |
| Petrochemical | 17,228 |  |  | 9,165 |  |  |  |  |  |
| Electric utility | 21,533 |  |  | 28,171 |  |  |  |  |  |
| Traction power | 11,372 |  |  | 13,361 |  |  |  |  |  |
| All others | 13,415 |  |  | 15,850 |  |  |  |  |  |
| Total revenues by market sector | $ | 106,569 |  |  | $ | 106,575 |  |  |  |  |  |


## us-gaap:RevenueFromContractWithCustomerPolicyTextBlock

[0000080420-22-000007:notes:55]
[same as prior period, unchanged from 0000080420-21-000041:notes:60]

[0000080420-22-000007:notes:56]
Some contracts may contain a cancellation clause that could limit the amount of revenue we are able to recognize over time. In these instances, revenue and costs associated with these contracts are deferred and recognized at a point in time when the performance obligation is fulfilled.
Selling and administrative costs incurred in relation to obtaining a contract are typically expensed as incurred. We periodically utilize a third-party sales agent to obtain a contract and will pay a commission to that agent. We record the full commission liability to the third-party sales agents at the order date, with a corresponding deferred asset. As the project progresses, we record commission expense based on percentage of completion rates that correlate to the project and reduce the deferred asset. Once we have been paid by the customer, we pay the commission and the deferred liability is reduced
Performance Obligations

[0000080420-22-000007:notes:57]
A performance obligation is a promise in a contract or with a customer to transfer a distinct good or service. A contract’s transaction price is allocated to each distinct performance obligation and recognized as revenue as the performance obligations are satisfied. To determine the proper revenue recognition for contracts, we evaluate whether a contract should be accounted for as more than one performance obligation or, less commonly, whether two or more contracts should be combined and accounted for as one performance obligation.  This evaluation of performance obligations requires significant judgment.  The majority of our contracts have a single performance obligation where multiple engineered products and services are combined into a single custom-engineered solution. Our contracts include a standard one-year assurance warranty. Occasionally, we provide service-type warranties that will extend the warranty period. These extended warranties qualify as a separate performance obligation, and revenue is deferred and recognized over the warranty period. If we determine during the evaluation of the contract that there are multiple performance obligations, we allocate the transaction price to each performance obligation using our best estimate of the standalone selling price of each distinct good or service in the contract. 
Remaining unsatisfied performance obligations, which we refer to as backlog, represent the estimated transaction price for goods and services for which we have a material right, but work has not been performed.
Contract Estimates

[0000080420-22-000007:notes:58]
Contract liabilities typically represent advance payments from contractual billing milestones and billings in excess of revenue recognized. It is unusual to have advanced milestone payments with a term greater than one year, which could represent a financing component on the contract.  
Our contract assets and liabilities are reported in a net position on a contract-by-contract basis at the end of each reporting period and are generally classified as current.The timing of our invoice process is typically dependent on the completion of certain milestones and contract terms and subject to agreement by our customer.  Payment is typically expected within 30 days of invoice. Any uncollected invoiced amounts for our performance obligations recognized over time, including contract retentions, are recorded as accounts receivable in the Condensed Consolidated Balance Sheets. Certain contracts allow customers to withhold a small percentage of billings pursuant to retainage provisions, and such amounts are generally due upon completion of the contract and acceptance of the project by the customer. Based on our experience in recent years, the majority of these retainage balances are expected to be collected within approximately twelve months.


## us-gaap:LongTermDebtTextBlock

[0000080420-22-000007:notes:59]
Long-Term Debt
Long-term debt consisted of the following (in thousands):

[0000080420-22-000007:notes:60]
|  | December 31, 2021 |  | September 30, 2021 |
| Industrial development revenue bonds | $ | — |  |  | $ | 400 |  |
| Less: current portion | — |  |  | (400) |  |
| Total long-term debt | $ | — |  |  | $ | — |  |

[0000080420-22-000007:notes:61]
U.S. Revolver

[0000080420-22-000007:notes:62]
We have a credit agreement with Bank of America, N.A. (as amended, the "U.S. Revolver"), which is a $75.0 million revolving credit facility that is available for both borrowings and letters of credit and expires September 27, 2024. The U.S. Revolver states that up to $30 million may be deducted from the amount of letters of credit outstanding (not to be less than zero) when calculating the consolidated funded indebtedness which is a component of the consolidated net leverage ratio. Additionally, we have the option to cash collateralize all or a portion of the letters of credit outstanding, which would favorably impact the consolidated funded indebtedness calculation and the consolidated net leverage ratio. As of December 31, 2021, there were no amounts borrowed under the U.S. Revolver and letters of credit outstanding were $31.2 million. There was $43.8 million available for the issuance of letters of credit and borrowings under the U.S. Revolver as of December 31, 2021.

[0000080420-22-000007:notes:63]
We are required to maintain certain financial covenants, the most significant of which are a consolidated net leverage ratio less than 3.0 to 1.0 and a consolidated interest coverage ratio of greater than 3.0 to 1.0. Our most restrictive covenant, the consolidated net leverage ratio, is the ratio of earnings before interest, taxes, depreciation, amortization and stock-based compensation (EBITDAS) to funded indebtedness. An increase in indebtedness, which includes letters of credit, or a decrease in EBITDAS could restrict our ability to issue letters of credit or borrow under the U.S. Revolver. Additionally, we must maintain a consolidated cash balance of $30 million at all times, which can be deducted from the letters of credit outstanding as noted above. The U.S. Revolver also contains a "material adverse effect" clause which is a material change in our operations, business, properties, liabilities or condition (financial or otherwise) or a material impairment of our ability to perform our obligations under our credit agreements. As of December 31, 2021, we were in compliance with all of the financial covenants of the U.S. Revolver.

[0000080420-22-000007:notes:64]
The U.S. Revolver allows the Company to elect that any borrowing under the facility bears an interest rate based on either the base rate or the eurocurrency rate, in each case, plus the applicable rate. The base rate is generally the highest of (a) the federal funds rate plus 0.50%, (b) the Bank of America prime rate or (c) the London Interbank Offered Rate (LIBOR) successor rate plus 1.00%. The applicable rate is generally a range from (0.25)% to 1.75% depending on the type of loan and the Company's consolidated net leverage ratio. On December 31, 2021, the Company entered into a LIBOR Transition Amendment with Bank of America that states that LIBOR will be replaced with a successor rate in accordance with the U.S. Revolver.

[0000080420-22-000007:notes:65]
The U.S. Revolver is collateralized by a pledge of 100% of the voting capital stock of each of our domestic subsidiaries and 65% of the voting capital stock of each non-domestic subsidiary. The U.S. Revolver provides for customary events of default and carries cross-default provisions with other existing debt agreements. If an event of default (as defined in the U.S. Revolver) occurs and is continuing, on the terms and subject to the conditions set forth in the U.S. Revolver, amounts and letters of credit outstanding under the U.S. Revolver may be accelerated and may become immediately due and payable.

[0000080420-22-000007:notes:66]
Industrial Development Revenue Bonds

[0000080420-22-000007:notes:67]
We borrowed $8.0 million in October 2001 through a loan agreement funded with proceeds from tax-exempt industrial development revenue bonds (Bonds) for the completion of our Northlake, Illinois facility. The Bonds matured on October 1, 2021 and our final payment of $0.4 million was made.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0000080420-22-000007:notes:68]
Commitments and Contingencies
Letters of Credit, Bank Guarantees and Bonds

[0000080420-22-000007:notes:69]
Certain customers require us to post letters of credit, bank guarantees or surety bonds. These security instruments assure that we will perform under the terms of our contract. In the event of default, the counterparty may demand payment from the bank under a letter of credit or bank guarantee, or performance by the surety under a bond. To date, there have been no significant draws or claims related to security instruments for the periods reported. We were contingently liable for letters of credit of $31.2 million as of December 31, 2021. We also had surety bonds totaling $144.4 million that were outstanding, with additional bonding capacity of $455.6 million available, at December 31, 2021. At present, we have strong surety relationships; however, a change in market conditions or the sureties' assessment of our financial position could cause the sureties to require cash collateralization for undischarged liabilities under the bonds.

[0000080420-22-000007:notes:70]
We have a $9.5 million facility agreement (Facility Agreement) between Powell (UK) Limited and a large international bank that provides Powell (UK) Limited the ability to enter into bank guarantees as well as forward exchange contracts and currency options. At December 31, 2021, we had outstanding guarantees totaling $3.3 million and amounts available under this Facility Agreement were $6.2 million. The Facility Agreement provides for customary events of default, and carries cross-default provisions with our U.S. Revolver. If an event of default (as defined in the Facility Agreement) occurs and is continuing, per the terms and subject to the conditions set forth therein, obligations outstanding under the Facility Agreement may be accelerated and declared immediately due and payable. Additionally, we are required to maintain cash collateral for guarantees greater than two years. As of December 31, 2021, we were in compliance with all of the financial covenants of the Facility Agreement. In accordance with the terms of the Facility Agreement, the total amount available was reduced from $9.5 million to $6.8 million in January 2022.

[0000080420-22-000007:notes:71]
Litigation

[0000080420-22-000007:notes:72]
We are involved in various legal proceedings, claims and other disputes arising from our commercial operations, projects, employees and other matters which, in general, are subject to uncertainties and in which the outcomes are not predictable. Although we can give no assurances about the resolution of pending claims, litigation or other disputes and the effect such outcomes may have on us, management believes that any ultimate liability resulting from the outcome of such proceedings, to the extent not otherwise provided or covered by insurance, will not have a material adverse effect on our consolidated financial position or results of operations or liquidity.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0000080420-22-000007:notes:73]
Stock-Based Compensation
Refer to our Annual Report on Form 10-K for the fiscal year ended September 30, 2021 for a full description of our existing stock-based compensation plans.

[0000080420-22-000007:notes:74]
[same as prior period, unchanged from 0000080420-21-000041:notes:80]

[0000080420-22-000007:notes:75]
We issue restricted stock units (RSUs) to certain officers and key employees of the Company. The fair value of the RSUs is based on the price of our common stock as reported on the NASDAQ Global Market on the grant dates. Typically, these grants vest over a three-year period from the date of issuance and are a blend of time-based and performance-based shares. The portion of the grant that is time-based typically vests over a three-year period on each anniversary of the grant date, based on continued employment. The performance-based shares vest based on the three-year earnings performance of the Company following the grant date. At December 31, 2021, there were 235,502 RSUs outstanding. The RSUs do not have voting rights but do receive dividend equivalents upon vesting which are accrued quarterly. Additionally, the shares of common stock underlying the RSUs are not considered issued and outstanding until vested and common stock is issued.

[0000080420-22-000007:notes:76]
Total RSU activity (number of shares) for the three months ended December 31, 2021 is summarized below:

[0000080420-22-000007:notes:77]
|  | Number ofRestrictedStockUnits |  | WeightedAverageGrant ValuePer Share |
| Outstanding at September 30, 2021 | 199,919 |  |  | $ | 30.34 |  |
| Granted | 107,350 |  |  | 24.79 |  |
| Vested | (71,767) |  |  | 32.66 |  |
| Forfeited/canceled | — |  |  | — |  |
| Outstanding at December 31, 2021 | 235,502 |  |  | $ | 26.94 |  |

[0000080420-22-000007:notes:78]
During the three months ended December 31, 2021 and 2020, we recorded compensation expense of $0.9 million and $0.8 million, respectively, related to the RSUs.

[0000080420-22-000007:notes:79]
Restricted Stock
Each non-employee director receives 2,400 restricted shares of the Company’s common stock annually. Fifty-percent of the restricted stock granted to each of our non-employee directors vests immediately, while the remaining fifty-percent vests on the anniversary of the grant date. Compensation expense is recognized immediately for the first fifty-percent of the restricted stock granted, while compensation expense for the remaining fifty-percent is recognized over the remaining vesting period. During the three months ended December 31, 2021 and 2020, there were no restricted shares granted. During both the three months ended December 31, 2021 and 2020, we recorded compensation expense of $0.1 million related to restricted stock.


## us-gaap:FairValueDisclosuresTextBlock

[0000080420-22-000007:notes:80]
[same as prior period, unchanged from 0000080420-21-000041:notes:86]

[0000080420-22-000007:notes:81]
[same as prior period, unchanged from 0000080420-21-000041:notes:87]

[0000080420-22-000007:notes:82]
[same as prior period, unchanged from 0000080420-21-000041:notes:88]

[0000080420-22-000007:notes:83]
[same as prior period, unchanged from 0000080420-21-000041:notes:89]

[0000080420-22-000007:notes:84]
[same as prior period, unchanged from 0000080420-21-000041:notes:90]

[0000080420-22-000007:notes:85]
The following table summarizes the fair value of our assets and liabilities that were accounted for at fair value on a recurring basis as of December 31, 2021 (in thousands):

[0000080420-22-000007:notes:86]
|  | Fair Value Measurements at December 31, 2021 |
|  | Quoted Prices inActive Markets forIdentical Assets(Level 1) |  | Significant OtherObservableInputs(Level 2) |  | SignificantUnobservableInputs(Level 3) |  | Fair Value at December 31,2021 |
| Assets: |  |  |  |  |  |  |  |
| Cash and cash equivalents | $ | 77,905 |  |  | $ | — |  |  | $ | — |  |  | $ | 77,905 |  |
| Short-term investments | 23,622 |  |  | — |  |  | — |  |  | 23,622 |  |
| Other assets | — |  |  | 9,452 |  |  | — |  |  | 9,452 |  |
| Liabilities: |  |  |  |  |  |  |  |
| Deferred compensation | — |  |  | 9,675 |  |  | — |  |  | 9,675 |  |

[0000080420-22-000007:notes:87]
The following table summarizes the fair value of our assets and liabilities that were accounted for at fair value on a recurring basis as of September 30, 2021 (in thousands):

[0000080420-22-000007:notes:88]
|  | Fair Value Measurements at September 30, 2021 |
|  | Quoted Prices inActive Markets forIdentical Assets(Level 1) |  | Significant OtherObservableInputs(Level 2) |  | SignificantUnobservableInputs(Level 3) |  | Fair Value at September 30,2021 |
| Assets: |  |  |  |  |  |  |  |
| Cash and cash equivalents | $ | 114,314 |  |  | $ | — |  |  | $ | — |  |  | $ | 114,314 |  |
| Short-term investments | 19,667 |  |  | — |  |  | — |  |  | 19,667 |  |
| Other assets | — |  |  | 9,100 |  |  | — |  |  | 9,100 |  |
| Liabilities: |  |  |  |  |  |  |  |
| Deferred compensation | — |  |  | 8,527 |  |  | — |  |  | 8,527 |  |

[0000080420-22-000007:notes:89]
[same as prior period, unchanged from 0000080420-21-000041:notes:95]

[0000080420-22-000007:notes:90]
[same as prior period, unchanged from 0000080420-21-000041:notes:96]

[0000080420-22-000007:notes:91]
[same as prior period, unchanged from 0000080420-21-000041:notes:97]

[0000080420-22-000007:notes:92]
[same as prior period, unchanged from 0000080420-21-000041:notes:98]

[0000080420-22-000007:notes:93]
There were no transfers between levels within the fair value measurement hierarchy during the quarter ended December 31, 2021.


## us-gaap:LesseeOperatingLeasesTextBlock

[0000080420-22-000007:notes:94]
Leases
Our leases consist primarily of office and manufacturing space and construction equipment. All of our future lease obligations are related to non-cancelable operating leases. The most significant portion of our lease portfolio relates to leases of office and manufacturing facilities in Canada which we no longer occupy. We currently sublease the majority of these Canadian facilities. The following table provides a summary of lease cost components for the three months ended December 31, 2021 and 2020, respectively (in thousands):

[0000080420-22-000007:notes:95]
|  |  | Three months ended December 31, |  |  |
| Lease Cost |  | 2021 |  | 2020 |  |  |  |  |
| Operating lease cost |  | $ | 571 |  |  | $ | 608 |  |  |  |  |  |
| Less: sublease income |  | (174) |  |  | (180) |  |  |  |  |  |
| Variable lease cost(1) |  | 141 |  |  | 108 |  |  |  |  |  |
| Short-term lease cost(2) |  | 273 |  |  | 169 |  |  |  |  |  |
| Total lease cost |  | $ | 811 |  |  | $ | 705 |  |  |  |  |  |

[0000080420-22-000007:notes:96]
[same as prior period, unchanged from 0000080420-21-000041:notes:102]

[0000080420-22-000007:notes:97]
[same as prior period, unchanged from 0000080420-21-000041:notes:103]

[0000080420-22-000007:notes:98]
We recognize operating lease assets and operating lease liabilities representing the present value of the remaining lease payments for leases with initial terms greater than twelve months. Leases with initial terms of twelve months or less are not recorded in our Condensed Consolidated Balance Sheets. As of December 31, 2021 and September 30, 2021, our operating lease assets have been reduced by a lease accrual of $0.3 million and $0.4 million, respectively, related to certain unused facility leases in Canada. The following table provides a summary of the operating lease assets and operating lease liabilities included in our Condensed Consolidated Balance Sheets as of December 31, 2021 and September 30, 2021, respectively (in thousands):

[0000080420-22-000007:notes:99]
| Operating Leases |  | December 31, 2021 |  | September 30, 2021 |
| Assets: |  |  |  |  |
| Operating lease assets, net |  | $ | 3,526 |  |  | $ | 3,453 |  |
| Liabilities: |  |  |  |  |
| Current operating lease liabilities |  | 1,966 |  |  | 1,415 |  |
| Long-term operating lease liabilities |  | 1,866 |  |  | 2,413 |  |
| Total lease liabilities |  | $ | 3,832 |  |  | $ | 3,828 |  |

[0000080420-22-000007:notes:100]
The following table provides the maturities of our operating lease liabilities as of December 31, 2021 (in thousands):

[0000080420-22-000007:notes:101]
|  |  | Operating Leases |  |  |
| Remainder of 2022 |  | $ | 1,822 |  |  |  |
| 2023 |  | 1,536 |  |  |  |
| 2024 |  | 361 |  |  |  |
| 2025 |  | 204 |  |  |  |
| 2026 |  | 51 |  |  |  |
| Thereafter |  | — |  |  |  |
| Total future minimum lease payments |  | $ | 3,974 |  |  |  |
| Less: present value discount (imputed interest) |  | (142) |  |  |  |
| Present value of lease liabilities |  | $ | 3,832 |  |  |  |

[0000080420-22-000007:notes:102]
The weighted average discount rate as of December 31, 2021 was 3.87%. The weighted average remaining lease term was 2.0 years at December 31, 2021.


## us-gaap:IncomeTaxDisclosureTextBlock

[0000080420-22-000007:notes:103]
[same as prior period, unchanged from 0000080420-21-000041:notes:109]

[0000080420-22-000007:notes:104]
|  | Three months ended December 31, |  |  |
|  | 2021 |  | 2020 |  |  |  |  |
| Loss before income taxes | $ | (4,287) |  |  | $ | (259) |  |  |  |  |  |
| Income tax provision (benefit) | (1,441) |  |  | 105 |  |  |  |  |  |
| Net loss | $ | (2,846) |  |  | $ | (364) |  |  |  |  |  |
| Effective tax rate | 34 | % |  | (41) | % |  |  |  |  |

[0000080420-22-000007:notes:105]
Our income tax benefit reflects an effective tax rate on pre-tax loss of 34% for the first quarter of Fiscal 2022 compared to an income tax provision that reflects a negative 41% in the first quarter of Fiscal 2021. For the three months ended December 31, 2021, the estimated Research and Development Tax Credit (R&D Tax Credit) favorably impacted the effective tax rate. The effective tax rate for the first quarter of Fiscal 2022 and Fiscal 2021 were negatively impacted by the losses recognized in various foreign jurisdictions that were reserved with a valuation allowance as well as discrete items in the amount of $0.1 million primarily related to the vesting of restricted stock units. These unfavorable items offset the benefits related to the estimated R&D Tax Credit and the projected utilization of net operating loss carryforwards in Canada that were fully reserved with a valuation allowance for the three months ended December 31, 2020.


## us-gaap:SubsequentEventsTextBlock

[0000080420-22-000007:notes:106]
Subsequent Events
Quarterly Dividend Declared

[0000080420-22-000007:notes:107]
On February 1, 2022, our Board of Directors declared a quarterly cash dividend on our common stock in the amount of $0.26 per share. The dividend is payable on March 16, 2022 to shareholders of record at the close of business on February 16, 2022.
