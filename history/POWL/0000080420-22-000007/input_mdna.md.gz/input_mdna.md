# POWL MD&A — 0000080420-22-000007


## mdna

[0000080420-22-000007:mdna:1]
[same as prior period, unchanged from 0000080420-21-000041:mdna:1]

[0000080420-22-000007:mdna:2]
The following discussion and analysis of our financial condition and results of operations should be read in conjunction with the accompanying condensed consolidated financial statements and related notes included elsewhere in this Quarterly Report on Form 10-Q and with our Annual Report on Form 10-K for the year ended September 30, 2021, which was filed with the Securities and Exchange Commission (SEC) on December 8, 2021 and is available on the SEC’s website at www.sec.gov.

[0000080420-22-000007:mdna:3]
[same as prior period, unchanged from 0000080420-21-000041:mdna:3]

[0000080420-22-000007:mdna:4]
We develop, design, manufacture and service custom-engineered equipment and systems which (1) distribute, control and monitor the flow of electrical energy and (2) provide protection to motors, transformers and other electrically powered equipment. We are headquartered in Houston, Texas, and serve the oil and gas and petrochemical markets, which include onshore and offshore production, liquefied natural gas (LNG) facilities and terminals, pipelines, refineries and petrochemical plants. Additional markets include electric utility and light rail traction power as well as mining and metals, pulp and paper and other municipal, commercial and industrial markets. Revenues and costs are primarily related to custom engineered-to-order equipment and systems and are accounted for under percentage-of-completion accounting, which precludes us from providing detailed price and volume information. Our backlog includes various projects that typically take a number of months to produce.

[0000080420-22-000007:mdna:5]
The markets in which we participate are capital-intensive and cyclical in nature. Cyclicality is predominantly driven by customer demand, global economic conditions and anticipated environmental, safety or regulatory changes which affect the manner in which our customers proceed with capital investments. Our customers analyze various factors, including the demand and price for oil, gas and electrical energy, the overall economic and financial environment, governmental budgets, regulatory actions and environmental concerns. These factors influence the release of new capital projects by our customers, which are traditionally awarded in competitive bid situations. Scheduling of projects is matched to customer requirements, and projects typically take a number of months to produce. Schedules may change during the course of any particular project, and our operating results can, therefore, be impacted by factors outside of our control.

[0000080420-22-000007:mdna:6]
[same as prior period, unchanged from 0000080420-21-000041:mdna:6]

[0000080420-22-000007:mdna:7]
Historically, the combination of a growing global economy, abundant sources of favorably priced natural gas feedstock, and an energy industry focus on transition to natural gas and cleaner-burning fuels drove an increase in capital investment opportunities, specifically across the oil, gas and petrochemical sectors. Some of these opportunities were for natural gas related projects targeting global demand for cleaner-burning fuels. Additionally, projects within the domestic petrochemical sector benefited from the low feedstock prices of natural gas. Specific to natural gas, the business was awarded a substantial contract in the second quarter of Fiscal 2020 that will support the integrated electrical distribution requirements for a large domestic industrial complex and should be substantially completed in Fiscal 2022. We began to experience reduced commercial activity in Fiscal 2020 driven in large part by the uncertainties across our industrial end markets in the U.S. resulting from the COVID-19 pandemic. Considering the long cycle nature of our business, these cyclical conditions may persist throughout Fiscal 2022.

[0000080420-22-000007:mdna:8]
[same as prior period, unchanged from 0000080420-21-000041:mdna:8]

[0000080420-22-000007:mdna:9]
The COVID-19 pandemic continues to impact global energy markets. This pandemic has negatively impacted demand, which in turn has resulted in considerable volatility across global oil and gas commodity markets. Throughout the pandemic, the demand for our products and services as well as our operations have been negatively impacted, resulting from the associated reduction in oil and gas demand and volatility in commodity prices noted above. As a result, some of our industrial customers are deferring or suspending their planned capital expenditures. Certain of our customers have asked that we delay or cancel our manufacturing on their projects as their operations have been negatively impacted by this pandemic and the reduced oil and gas demand, which has resulted in recognition of cancellation fees based on contract terms and the extent of our progress on the projects. We continue to work with our key suppliers who have been impacted by this pandemic to ensure that we are able to meet our customer commitments.

[0000080420-22-000007:mdna:10]
In response to the lower demand across select end markets, we have taken and will continue to take various actions to reduce costs. During Fiscal 2020, we reduced our global workforce and our capital and discretionary spending in response to business conditions. We continued to operate at these lower thresholds throughout Fiscal 2021 and the first quarter of Fiscal 2022 and will continue to consistently monitor the macro-economic conditions throughout the remainder of Fiscal 2022.

[0000080420-22-000007:mdna:11]
[same as prior period, unchanged from 0000080420-21-000041:mdna:11]

[0000080420-22-000007:mdna:12]
[same as prior period, unchanged from 0000080420-21-000041:mdna:12]

[0000080420-22-000007:mdna:13]
Quarter Ended December 31, 2021 Compared to the Quarter Ended December 31, 2020 (Unaudited)

[0000080420-22-000007:mdna:14]
[same as prior period, unchanged from 0000080420-21-000041:mdna:14]

[0000080420-22-000007:mdna:15]
Revenues remained flat at $106.6 million in the first quarter of Fiscal 2022. Revenues continue to be negatively impacted due to project delays and cancellations of potential projects associated with the global economic impact resulting from the COVID-19 pandemic and associated reduction in demand across our industrial end markets. Domestic revenues increased by 2%, or $1.6 million, to $82.1 million in the first quarter of Fiscal 2022. Included in our domestic revenues in the oil and gas markets is our large domestic industrial project awarded in Fiscal 2020, which accounted for approximately 19% of our consolidated revenues for the first quarter of Fiscal 2022 compared to 13% in the same period of the prior year. International revenues decreased by 6.0%, or $1.6 million, to $24.4 million in the first quarter of Fiscal 2022. Our international revenues include both revenues generated from our international facilities as well as revenues from export projects generated at our domestic facilities.

[0000080420-22-000007:mdna:16]
Revenue from our core oil and gas markets (excluding petrochemical) increased by 7%, or $3.0 million, to $43.0 million in the first quarter of Fiscal 2022, while petrochemical revenue increased by 88%, or $8.1 million, to $17.2 million in the first quarter of Fiscal 2022, primarily due to project mix. Revenue from our utility markets decreased by 24%, or $6.6 million, to $21.5 million, and traction market revenue decreased by 15%, or $2.0 million, to $11.4 million in the first quarter of Fiscal 2022. Revenue from all other markets combined decreased by $2.4 million to $13.4 million in the first quarter of Fiscal 2022.

[0000080420-22-000007:mdna:17]
Gross profit decreased by 26%, or $4.8 million, to $13.4 million for the first quarter of Fiscal 2022.  Gross profit as a percentage of revenues decreased to 13% in the first quarter of Fiscal 2022, compared to 17% in the first quarter of Fiscal 2021. The decline in gross profit was driven predominately by higher global commodity costs, and to a lesser extent, a lower volume of favorable project close-outs in the first quarter of Fiscal 2022. Gross profit may continue to be negatively impacted by higher commodity costs to the extent we are not able to pass these increases to our customers.

[0000080420-22-000007:mdna:18]
[same as prior period, unchanged from 0000080420-21-000041:mdna:18]

[0000080420-22-000007:mdna:19]
Selling, general and administrative expenses decreased by 6%, or $1.0 million, to $15.9 million in the first quarter of Fiscal 2022, primarily due to decreased variable incentive compensation. Selling, general and administrative expenses as a percentage of revenues decreased to 15% during the first quarter of Fiscal 2022 compared to 16% during the first quarter of Fiscal 2021.

[0000080420-22-000007:mdna:20]
Income Tax Benefit/Provision

[0000080420-22-000007:mdna:21]
We recorded an income tax benefit of $1.4 million in the first quarter of Fiscal 2022, compared to an income tax provision of $0.1 million in the first quarter of Fiscal 2021. The effective tax rate for the first quarter of Fiscal 2022 was 34%, compared to an effective tax rate of negative 41% in the first quarter of Fiscal 2021. For the three months ended December 31, 2021, the effective tax rate was favorably impacted by the estimated Research and Development Tax Credit (R&D Tax Credit), while losses recognized in various foreign jurisdictions that were reserved with a valuation allowance and discrete items primarily related to the vesting of restricted stock units negatively impacted the effective tax rate for each of the three months ended December 31, 2021 and December 31, 2020.  These unfavorable items offset the benefits related to the estimated R&D Tax Credit and the projected utilization of net operating loss carryforwards in Canada that were fully reserved with a valuation allowance in the first quarter of Fiscal 2021.

[0000080420-22-000007:mdna:22]
Net Loss

[0000080420-22-000007:mdna:23]
In the first quarter of Fiscal 2022, we recorded a net loss of $2.8 million, or $0.24 per diluted share, compared to a net loss of $0.4 million, or $0.03 per diluted share, in the first quarter of Fiscal 2021. This increase in net loss is due to a decline in gross profit as discussed above.

[0000080420-22-000007:mdna:24]
[same as prior period, unchanged from 0000080420-21-000041:mdna:26]

[0000080420-22-000007:mdna:25]
The order backlog at December 31, 2021 was $416.0 million, a slight increase from $414.9 million at September 30, 2021 and a decrease of 11% from $464.9 million at December 31, 2020. Bookings, net of cancellations and scope reductions, increased by 18% in the first quarter of Fiscal 2022 to $107.7 million, compared to $91.1 million in the first quarter of Fiscal 2021.

[0000080420-22-000007:mdna:26]
[same as prior period, unchanged from 0000080420-21-000041:mdna:43]

[0000080420-22-000007:mdna:27]
As noted in "Overview" above, the markets in which we participate are capital-intensive and cyclical in nature. A significant portion of our revenues has historically been from the oil, gas and petrochemical markets. Oil and gas commodity price levels have been unstable over the last several years, and our customers have in certain cases delayed or cancelled some of their major capital investment projects. Recently we have seen increased global demand for cleaner-burning fuels; however, the uncertainty in oil prices and the global economic impacts from COVID-19 have had, and may continue to have, a negative impact on our business going forward, as discussed in more detail below. Specific to the energy industry focus on transitioning to natural gas and cleaner-burning fuels, the business was awarded a substantial contract in Fiscal 2020 that will support the integrated electrical distribution requirements for a large domestic industrial complex and should be substantially completed in Fiscal 2022.

[0000080420-22-000007:mdna:28]
Our operating results are impacted by factors such as the timing of new order awards, customer approval of final engineering and design specifications and delays in customer construction schedules, all of which contribute to short-term earnings variability and the timing of project execution. Our operating results also have been, and may continue to be, impacted by the timing and resolution of change orders, project close-out and resolution of potential contract claims and liquidated damages, all of which could improve or deteriorate gross margins during the period in which these items are resolved with our customers. These factors may result in periods of underutilization of our resources and facilities, which may negatively impact our ability to cover our fixed costs. We experienced lower commercial activity in Fiscal 2020 and Fiscal 2021 driven in large part from the uncertainty resulting from the COVID-19 pandemic, as discussed in "Overview" above. Considering the long cycle nature of our business, we anticipate these cyclical conditions may persist throughout Fiscal 2022. We will continue to remain focused on the variables that impact our markets as well as our internal cost management and supply chain challenges. We will also continue to adjust to the global conditions in order to maintain competitive cost and technological advantages in the markets that we serve.

[0000080420-22-000007:mdna:29]
The consequences of a prolonged economic decline could include, but are not limited to, a continued reduction in commercial and industrial activity. The Company cannot reasonably estimate the duration or severity of this pandemic, or the extent to which the resulting disruptions may materially impact our business, results of operations or cash flows. We will take prudent measures to maintain our strong liquidity and cash position, which may include reducing our capital expenditures and research and development costs, as well as reducing or eliminating future dividend payments.

[0000080420-22-000007:mdna:30]
[same as prior period, unchanged from 0000080420-21-000041:mdna:47]

[0000080420-22-000007:mdna:31]
As of December 31, 2021, current assets exceeded current liabilities by 2.6 times.

[0000080420-22-000007:mdna:32]
Cash, cash equivalents and short-term investments decreased to $101.5 million at December 31, 2021, compared to $134.0 million at September 30, 2021. This decrease in cash was primarily driven by the timing of contract billing milestones related to our large industrial project awarded in Fiscal 2020. We believe that our strong working capital position, available borrowings under our credit facility and available cash should be sufficient to finance future operating activities, capital improvements, research and development initiatives and debt repayments for the foreseeable future.

[0000080420-22-000007:mdna:33]
We have a credit agreement with Bank of America, N.A. (as amended, the "U.S. Revolver") which is a $75.0 million revolving credit facility available for both borrowings and letters of credit and expires September 27, 2024. The U.S. Revolver states that up to $30 million may be deducted from the amount of letters of credit outstanding (not to be less than zero) when calculating the consolidated funded indebtedness which is a component of the consolidated net leverage ratio. Additionally, we have the option to cash collateralize all or a portion of the letters of credit outstanding, which would favorably impact the consolidated funded indebtedness calculation and the consolidated net leverage ratio.

[0000080420-22-000007:mdna:34]
On October 1, 2021, our industrial development revenue bonds matured and as a result we had no long-term debt at December 31, 2021. As of December 31, 2021, there were no amounts borrowed under the U.S. Revolver, and letters of credit outstanding were $31.2 million. As of December 31, 2021, $43.8 million was available for the issuance of letters of credit and borrowing under the U.S. Revolver. We are required to maintain certain financial covenants, the most significant of which are a consolidated net leverage ratio of less than 3.0 to 1.0 and a consolidated interest coverage ratio of greater than 3.0 to 1.0. Our most restrictive covenant, the consolidated net leverage ratio, is the ratio of earnings before interest, taxes, depreciation, amortization and stock-based compensation (EBITDAS) to funded indebtedness, which includes letters of credit. An increase in indebtedness or a decrease in EBITDAS could restrict our ability to issue letters of credit or borrow under the U.S. Revolver. For further information regarding our debt, see Notes E and F of Notes to Condensed Consolidated Financial Statements.

[0000080420-22-000007:mdna:35]
Approximately $28.6 million of our cash, cash equivalents and short-term investments at December 31, 2021 was held outside of the U.S. for our international operations. It is our intention to indefinitely reinvest all current and future foreign earnings internationally in order to ensure sufficient working capital to support our international operations. In the event that we elect to repatriate some or all of the foreign earnings that were previously deemed to be indefinitely reinvested outside the U.S., we may incur additional tax expense upon such repatriation under current tax laws.

[0000080420-22-000007:mdna:36]
[same as prior period, unchanged from 0000080420-21-000041:mdna:53]

[0000080420-22-000007:mdna:37]
Operating activities used net cash of $27.8 million during the three months ended December 31, 2021 and $25.2 million during the same period in Fiscal 2021. Cash flow from operations is primarily influenced by the timing of milestone payments from our customers, project volume and the payment terms with our suppliers. This decrease in operating cash flow was primarily due to the timing of contract billing milestones and an increase in inventory.

[0000080420-22-000007:mdna:38]
[same as prior period, unchanged from 0000080420-21-000041:mdna:55]

[0000080420-22-000007:mdna:39]
Investing activities used $4.4 million during the three months ended December 31, 2021 compared to $3.0 million provided during the same period in Fiscal 2021. The decrease in cash provided by investing activities in the first three months of Fiscal 2022 was primarily due to short-term investment activity.

[0000080420-22-000007:mdna:40]
[same as prior period, unchanged from 0000080420-21-000041:mdna:57]

[0000080420-22-000007:mdna:41]
Net cash used in financing activities was $4.1 million during each of the three months ended December 31, 2021 and 2020, which primarily consisted of approximately $3.0 million of dividends paid in each period.

[0000080420-22-000007:mdna:42]
[same as prior period, unchanged from 0000080420-21-000041:mdna:61]

[0000080420-22-000007:mdna:43]
[same as prior period, unchanged from 0000080420-21-000041:mdna:62]

[0000080420-22-000007:mdna:44]
There have been no material changes to our critical accounting policies as disclosed in our Annual Report on Form 10-K for the fiscal year ended September 30, 2021, which was filed with the SEC on December 8, 2021.
