# POWL note change history — 0000080420-21-000041 → 0000080420-22-000007


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2022-02-09):
[0000080420-22-000007:note_history:1]
Certain customers require us to post letters of credit, bank guarantees or surety bonds. These security instruments assure that we will perform under the terms of our contract. In the event of default, the counterparty may demand payment from the bank under a letter of credit or bank guarantee, or performance by the surety under a bond. To date, there have been no significant draws or claims related to security instruments for the periods reported. We were contingently liable for letters of credit of $31.2 million as of December 31, 2021. We also had surety bonds totaling $144.4 million that were outstanding, with additional bonding capacity of $455.6 million available, at December 31, 2021. At present, we have strong surety relationships; however, a change in market conditions or the sureties' assessment of our financial position could cause the sureties to require cash collateralization for undischarged liabilities under the bonds.
  (was, 2021-08-04, similarity 0.987):
[0000080420-21-000041:note_history:1]
Certain customers require us to post letters of credit, bank guarantees or surety bonds. These security instruments assure that we will perform under the terms of our contract. In the event of default, the counterparty may demand payment from the bank under a letter of credit or bank guarantee, or performance by the surety under a bond. To date, there have been no significant draws or claims related to security instruments for the periods reported. We were contingently liable for letters of credit of $39.9 million as of June 30, 2021. We also had surety bonds totaling $141.2 million that were outstanding, with additional bonding capacity of $458.8 million available, at June 30, 2021. At present, we have strong surety relationships; however, a change in market conditions or the sureties' assessment of our financial position could cause the sureties to require cash collateralization for undischarged liabilities under the bonds.

- changed (2022-02-09):
[0000080420-22-000007:note_history:2]
We have a $9.5 million facility agreement (Facility Agreement) between Powell (UK) Limited and a large international bank that provides Powell (UK) Limited the ability to enter into bank guarantees as well as forward exchange contracts and currency options. At December 31, 2021, we had outstanding guarantees totaling $3.3 million and amounts available under this Facility Agreement were $6.2 million. The Facility Agreement provides for customary events of default, and carries cross-default provisions with our U.S. Revolver. If an event of default (as defined in the Facility Agreement) occurs and is continuing, per the terms and subject to the conditions set forth therein, obligations outstanding under the Facility Agreement may be accelerated and declared immediately due and payable. Additionally, we are required to maintain cash collateral for guarantees greater than two years. As of December 31, 2021, we were in compliance with all of the financial covenants of the Facility Agreement. In accordance with the terms of the Facility Agreement, the total amount available was reduced from $9.5 million to $6.8 million in January 2022.
  (was, 2021-08-04, similarity 0.9122):
[0000080420-21-000041:note_history:2]
We have a $9.7 million facility agreement (Facility Agreement) between Powell (UK) Limited and a large international bank that provides Powell (UK) Limited the ability to enter into bank guarantees as well as forward exchange contracts and currency options. At June 30, 2021, we had outstanding guarantees totaling $7.7 million and amounts available under this Facility Agreement were $2.0 million. The Facility Agreement provides for financial covenants and customary events of default, and carries cross-default provisions with our U.S. Revolver. If an event of default (as defined in the Facility Agreement) occurs and is continuing, per the terms and subject to the conditions set forth therein, obligations outstanding under the Facility Agreement may be accelerated and declared immediately due and payable. Additionally, we are required to maintain cash collateral for guarantees greater than two years. As of June 30, 2021, we were in compliance with all of the financial covenants of the Facility Agreement.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureAndSignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2022-02-09):
[0000080420-22-000007:note_history:3]
Powell Industries, Inc. (we, us, our, Powell or the Company) is incorporated in the state of Delaware. Powell's predecessor companies were founded 75 years ago by William E. Powell in 1947. Our major subsidiaries, all of which are wholly owned, include: Powell Electrical Systems, Inc.; Powell (UK) Limited; Powell Canada Inc.; and Powell Industries International, B.V.
  (was, 2021-08-04, similarity 0.7217):
[0000080420-21-000041:note_history:3]
Powell Industries, Inc. (we, us, our, Powell or the Company) was incorporated in the state of Delaware in 2004 as a successor to a Nevada company incorporated in 1968. The Nevada company was the successor to a company founded by William E. Powell in 1947, which merged into the Company in 1977. Our major subsidiaries, all of which are wholly owned, include: Powell Electrical Systems, Inc.; Powell (UK) Limited; Powell Canada Inc.; and Powell Industries International, B.V.

- added (2022-02-09):
[0000080420-22-000007:note_history:4]
We develop, design, manufacture and service custom-engineered equipment and systems which (1) distribute, control and monitor the flow of electrical energy and (2) provide protection to motors, transformers and other electrically powered equipment. We are headquartered in Houston, Texas and serve the oil and gas and petrochemical markets, which include onshore and offshore production, liquefied natural gas (LNG) facilities and terminals, pipelines, refineries and petrochemical plants. Additional markets include electric utility and light rail traction power as well as mining and metals, pulp and paper and other municipal, commercial and industrial markets.

- changed (2022-02-09):
[0000080420-22-000007:note_history:5]
The COVID-19 pandemic continues to impact global energy markets. This pandemic has negatively impacted demand, which in turn has resulted in considerable volatility across global oil and gas commodity markets. As a result, some of our industrial customers are deferring or suspending their planned capital expenditures. Certain of our customers have asked that we delay or cancel our manufacturing on their projects as their operations have been negatively impacted by this pandemic and the reduced oil and gas demand, which has resulted in recognition of cancellation fees based on contract terms and the extent of our progress on the projects. We continue to work with and review the contracts with our key suppliers who have been impacted by this pandemic to ensure that we are able to meet our customer commitments.
  (was, 2021-08-04, similarity 0.9744):
[0000080420-21-000041:note_history:5]
Through the first nine months of Fiscal 2021, the COVID-19 pandemic continues to impact global energy markets. This pandemic has negatively impacted demand, which in turn has resulted in considerable volatility across global oil and gas commodity markets. As a result, some of our industrial customers are deferring or suspending their planned capital expenditures. Certain of our customers have asked that we delay or cancel our manufacturing on their projects as their operations have been negatively impacted by this pandemic and the reduced oil and gas demand which has resulted in recognition of cancellation fees based on contract terms and the extent of our progress on the projects. We continue to work with and review the contracts with our key suppliers who have been impacted by this pandemic to ensure that we are able to meet our customer commitments.

- changed (2022-02-09):
[0000080420-22-000007:note_history:6]
The consequences of a prolonged global economic decline could include, but are not limited to, a continued reduction in commercial and industrial activity. The Company cannot reasonably estimate the duration or severity of this pandemic, or the extent to which the resulting disruptions may materially impact our business, results of operations or cash flows. We will take prudent measures to maintain our strong liquidity and cash position, which may include reducing our capital expenditures and research and development costs, as well as reducing or eliminating future dividend payments.
  (was, 2021-08-04, similarity 0.9628):
[0000080420-21-000041:note_history:6]
The consequences of a prolonged global economic decline could include, but are not limited to, a continued reduction in commercial and industrial activity. Accordingly, the Company cannot reasonably estimate the duration or severity of this pandemic, or the extent to which the disruption may materially impact our business, results of operations or cash flows. We will take prudent measures to maintain our strong liquidity and cash position, which may include reducing our capital expenditures and research and development costs, as well as reducing or eliminating future dividend payments.

- changed (2022-02-09):
[0000080420-22-000007:note_history:7]
References to Fiscal 2022 and Fiscal 2021 used throughout this report shall mean our fiscal years ended September 30, 2022 and 2021, respectively.
Use of EstimatesThe preparation of condensed consolidated financial statements in conformity with U.S. GAAP requires management to make estimates and assumptions that affect the amounts reported in the condensed consolidated financial statements and accompanying footnotes. The most significant estimates used in our condensed consolidated financial statements affect revenue recognition and estimated cost recognition on our customer contracts, the allowance for credit losses, provision for excess and obsolete inventory, warranty accruals and income taxes. The amounts recorded for warranties, legal, income taxes, impairment of long-lived assets (when applicable), liquidated damages and other contingent liabilities require judgments regarding the amount of expenses that will ultimately be incurred. We base our estimates on historical experience, forecasts and various other assumptions, as well as the specific circumstances surrounding these contingent liabilities, in evaluating the amount of liability that should be recorded. Additionally, the recognition of deferred tax assets requires estimates related to future income and other assumptions regarding timing and future profitability because the ultimate realization of net deferred tax assets is dependent on the generation of future taxable income during the periods in which temporary differences become deductible. Estimates routinely change as new events occur, additional information becomes available or operating environments change. Actual results may differ from our prior estimates.
  (was, 2021-08-04, similarity 0.9542):
[0000080420-21-000041:note_history:7]
The preparation of condensed consolidated financial statements in conformity with U.S. GAAP requires management to make estimates and assumptions that affect the amounts reported in the condensed consolidated financial statements and accompanying footnotes. The most significant estimates used in our condensed consolidated financial statements affect revenue recognition and estimated cost recognition on our customer contracts, the allowance for credit losses, provision for excess and obsolete inventory, warranty accruals and income taxes. The amounts recorded for warranties, legal, income taxes, impairment of long-lived assets (when applicable), liquidated damages and other contingent liabilities require judgments regarding the amount of expenses that will ultimately be incurred. We base our estimates on historical experience, forecasts and various other assumptions, as well as the specific circumstances surrounding these contingent liabilities, in evaluating the amount of liability that should be recorded. Additionally, the recognition of deferred tax assets requires estimates related to future income and other assumptions regarding timing and future profitability because the ultimate realization of net deferred tax assets is dependent on the generation of future taxable income during the periods in which temporary differences become deductible. Estimates routinely change as new events occur, additional information becomes available or operating environments change. Actual results may differ from our prior estimates.

- removed (2022-02-09):
[0000080420-21-000041:note_history:8]
We develop, design, manufacture and service custom-engineered equipment and systems which (1) distribute, control and monitor the flow of electrical energy and (2) provide protection to motors, transformers and other electrically powered equipment. We are headquartered in Houston, Texas and serve the oil and gas markets, including onshore and offshore oil and gas production, petrochemical, liquefied natural gas (LNG) terminals, pipeline, terminal, mining and metals, light rail traction power, electric utility, pulp and paper and other heavy industrial markets.

- removed (2022-02-09):
[0000080420-21-000041:note_history:9]
References to Fiscal 2021 and Fiscal 2020 used throughout this report shall mean our fiscal years ended September 30, 2021 and 2020, respectively.

- removed (2022-02-09):
[0000080420-21-000041:note_history:10]
Use of Estimates

- removed (2022-02-09):
[0000080420-21-000041:note_history:11]
New Accounting Standard

- removed (2022-02-09):
[0000080420-21-000041:note_history:12]
In June 2016, the Financial Accounting Standards Board (FASB) issued a new topic on measurement of credit losses. The topic introduces an impairment model known as the current expected credit loss (CECL) model that is based on an expected loss methodology rather than an incurred loss methodology for financial instruments. Under the new topic, an entity recognizes as an allowance its estimate of expected credit losses with the intention of improving financial reporting by requiring timelier recognition of such losses. We adopted this topic on October 1, 2020 and such adoption did not have a material impact on our consolidated financial statements.


## us-gaap:LongTermDebtTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2022-02-09):
[0000080420-22-000007:note_history:13]
|  | December 31, 2021 |  | September 30, 2021 |
| Industrial development revenue bonds | $ | — |  |  | $ | 400 |  |
| Less: current portion | — |  |  | (400) |  |
| Total long-term debt | $ | — |  |  | $ | — |  |
  (was, 2021-08-04, similarity 0.9519):
[0000080420-21-000041:note_history:13]
|  | June 30, 2021 |  | September 30, 2020 |
| Industrial development revenue bonds | $ | 400 |  |  | $ | 800 |  |
| Less: current portion | (400) |  |  | (400) |  |
| Total long-term debt | $ | — |  |  | $ | 400 |  |

- changed (2022-02-09):
[0000080420-22-000007:note_history:14]
We have a credit agreement with Bank of America, N.A. (as amended, the "U.S. Revolver"), which is a $75.0 million revolving credit facility that is available for both borrowings and letters of credit and expires September 27, 2024. The U.S. Revolver states that up to $30 million may be deducted from the amount of letters of credit outstanding (not to be less than zero) when calculating the consolidated funded indebtedness which is a component of the consolidated net leverage ratio. Additionally, we have the option to cash collateralize all or a portion of the letters of credit outstanding, which would favorably impact the consolidated funded indebtedness calculation and the consolidated net leverage ratio. As of December 31, 2021, there were no amounts borrowed under the U.S. Revolver and letters of credit outstanding were $31.2 million. There was $43.8 million available for the issuance of letters of credit and borrowings under the U.S. Revolver as of December 31, 2021.
  (was, 2021-08-04, similarity 0.8501):
[0000080420-21-000041:note_history:14]
We have a credit agreement with Bank of America, N.A. (the "U.S. Revolver") which is a $75.0 million revolving credit facility that is available for both borrowings and letters of credit and expires September 27, 2024. On March 12, 2021, we entered into a first amendment to the U.S. Revolver which, among other things, amended certain terms related to the calculation of the consolidated leverage ratio from gross leverage to net leverage. As a result of the first amendment, up to $30 million may be deducted from the amount of letters of credit outstanding (not to be less than zero) when calculating the consolidated funded indebtedness which is a component of the consolidated net leverage ratio. Additionally, we have the option to cash collateralize all or a portion of the letters of credit outstanding, which would favorably impact the consolidated funded indebtedness calculation and the consolidated net leverage ratio. As of June 30, 2021, there were no amounts borrowed under the U.S. Revolver and letters of credit outstanding were $39.9 million. There was $35.1 million available for the issuance of letters of credit and borrowings under the U.S. Revolver as of June 30, 2021.

- changed (2022-02-09):
[0000080420-22-000007:note_history:15]
We are required to maintain certain financial covenants, the most significant of which are a consolidated net leverage ratio less than 3.0 to 1.0 and a consolidated interest coverage ratio of greater than 3.0 to 1.0. Our most restrictive covenant, the consolidated net leverage ratio, is the ratio of earnings before interest, taxes, depreciation, amortization and stock-based compensation (EBITDAS) to funded indebtedness. An increase in indebtedness, which includes letters of credit, or a decrease in EBITDAS could restrict our ability to issue letters of credit or borrow under the U.S. Revolver. Additionally, we must maintain a consolidated cash balance of $30 million at all times, which can be deducted from the letters of credit outstanding as noted above. The U.S. Revolver also contains a "material adverse effect" clause which is a material change in our operations, business, properties, liabilities or condition (financial or otherwise) or a material impairment of our ability to perform our obligations under our credit agreements. As of December 31, 2021, we were in compliance with all of the financial covenants of the U.S. Revolver.
  (was, 2021-08-04, similarity 0.9265):
[0000080420-21-000041:note_history:15]
We are required to maintain certain financial covenants, the most significant of which are a consolidated net leverage ratio less than 3.0 to 1.0 and a consolidated interest coverage ratio of greater than 3.0 to 1.0. Our most restrictive covenant, the consolidated net leverage ratio, is the ratio of earnings before interest, taxes, depreciation, amortization and stock-based compensation (EBITDAS) to funded indebtedness. An increase in indebtedness, which includes letters of credit, or a decrease in EBITDAS could restrict our ability to issue letters of credit or borrow under the U.S. Revolver. Additionally, we must maintain a consolidated cash balance of $30 million at all times, which now can be deducted from the letters of credit outstanding as noted above. The U.S. Revolver also contains a "material adverse effect" clause which is a material change in our operations, business, properties, liabilities or condition (financial or otherwise) or a material impairment of our ability to

- changed (2022-02-09):
[0000080420-22-000007:note_history:16]
The U.S. Revolver allows the Company to elect that any borrowing under the facility bears an interest rate based on either the base rate or the eurocurrency rate, in each case, plus the applicable rate. The base rate is generally the highest of (a) the federal funds rate plus 0.50%, (b) the Bank of America prime rate or (c) the London Interbank Offered Rate (LIBOR) successor rate plus 1.00%. The applicable rate is generally a range from (0.25)% to 1.75% depending on the type of loan and the Company's consolidated net leverage ratio. On December 31, 2021, the Company entered into a LIBOR Transition Amendment with Bank of America that states that LIBOR will be replaced with a successor rate in accordance with the U.S. Revolver.
  (was, 2021-08-04, similarity 0.8284):
[0000080420-21-000041:note_history:16]
The U.S. Revolver allows the Company to elect that any borrowing under the facility bears an interest rate based on either the base rate or the eurocurrency rate, in each case, plus the applicable rate. The base rate is generally the highest of (a) the federal funds rate plus 0.50%, (b) the Bank of America prime rate or (c) the London Interbank Offered Rate (LIBOR) plus 1.00%. The applicable rate is generally a range from (0.25)% to 1.75% depending on the type of loan and the Company's consolidated leverage ratio.

- added (2022-02-09):
[0000080420-22-000007:note_history:17]
We borrowed $8.0 million in October 2001 through a loan agreement funded with proceeds from tax-exempt industrial development revenue bonds (Bonds) for the completion of our Northlake, Illinois facility. The Bonds matured on October 1, 2021 and our final payment of $0.4 million was made.

- removed (2022-02-09):
[0000080420-21-000041:note_history:18]
perform our obligations under our credit agreements. As of June 30, 2021, we were in compliance with all of the financial covenants of the U.S. Revolver.

- removed (2022-02-09):
[0000080420-21-000041:note_history:19]
We borrowed $8.0 million in October 2001 through a loan agreement funded with proceeds from tax-exempt industrial development revenue bonds (Bonds) for the completion of our Northlake, Illinois facility. The Bonds are subject to various covenants, for which we were in compliance at June 30, 2021. The Bonds mature in October 2021 and bear interest at a floating rate determined weekly by the Bonds’ remarketing agent. This interest rate was 0.13% as of June 30, 2021.


## us-gaap:ScheduleOfDebtInstrumentsTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2022-02-09):
[0000080420-22-000007:note_history:20]
|  | December 31, 2021 |  | September 30, 2021 |
| Industrial development revenue bonds | $ | — |  |  | $ | 400 |  |
| Less: current portion | — |  |  | (400) |  |
| Total long-term debt | $ | — |  |  | $ | — |  |
  (was, 2021-08-04, similarity 0.9519):
[0000080420-21-000041:note_history:20]
|  | June 30, 2021 |  | September 30, 2020 |
| Industrial development revenue bonds | $ | 400 |  |  | $ | 800 |  |
| Less: current portion | (400) |  |  | (400) |  |
| Total long-term debt | $ | — |  |  | $ | 400 |  |


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2022-02-09):
[0000080420-22-000007:note_history:21]
The following tables present our disaggregated revenue by geographic destination and market sector for the three months ended December 31, 2021 and 2020 (in thousands):
  (was, 2021-08-04, similarity 0.9415):
[0000080420-21-000041:note_history:21]
The following tables present our disaggregated revenue by geographic destination and market sector for the three and nine months ended June 30, 2021 and 2020 (in thousands):

- changed (2022-02-09):
[0000080420-22-000007:note_history:22]
|  | Three months ended December 31, |  |  |
|  | 2021 |  | 2020 |  |  |  |  |
| United States | $ | 82,145 |  |  | $ | 80,586 |  |  |  |  |  |
| Canada | 15,125 |  |  | 14,091 |  |  |  |  |  |
| Europe, Middle East and Africa | 7,830 |  |  | 8,256 |  |  |  |  |  |
| Asia/Pacific | 944 |  |  | 2,716 |  |  |  |  |  |
| Mexico, Central and South America | 525 |  |  | 926 |  |  |  |  |  |
| Total revenues by geographic destination | $ | 106,569 |  |  | $ | 106,575 |  |  |  |  |  |
  (was, 2021-08-04, similarity 0.6012):
[0000080420-21-000041:note_history:22]
|  | Three months ended June 30, |  | Nine months ended June 30, |
|  | 2021 |  | 2020 |  | 2021 |  | 2020 |
| United States | $ | 88,412 |  |  | $ | 89,499 |  |  | $ | 256,937 |  |  | $ | 318,009 |  |
| Canada | 16,529 |  |  | 16,970 |  |  | 48,354 |  |  | 46,831 |  |
| Europe, Middle East and Africa | 8,926 |  |  | 6,422 |  |  | 28,120 |  |  | 25,404 |  |
| Asia/Pacific | 1,651 |  |  | 4,643 |  |  | 6,376 |  |  | 11,784 |  |
| Mexico, Central and South America | 295 |  |  | 528 |  |  | 1,318 |  |  | 1,753 |  |
| Total revenues by geographic destination | $ | 115,813 |  |  | $ | 118,062 |  |  | $ | 341,105 |  |  | $ | 403,781 |  |

- added (2022-02-09):
[0000080420-22-000007:note_history:23]
|  | Three months ended December 31, |  |  |
|  | 2021 |  | 2020 |  |  |  |  |
| Oil and gas (excludes petrochemical) | $ | 43,021 |  |  | $ | 40,028 |  |  |  |  |  |
| Petrochemical | 17,228 |  |  | 9,165 |  |  |  |  |  |
| Electric utility | 21,533 |  |  | 28,171 |  |  |  |  |  |
| Traction power | 11,372 |  |  | 13,361 |  |  |  |  |  |
| All others | 13,415 |  |  | 15,850 |  |  |  |  |  |
| Total revenues by market sector | $ | 106,569 |  |  | $ | 106,575 |  |  |  |  |  |

- removed (2022-02-09):
[0000080420-21-000041:note_history:24]
|  | Three months ended June 30, |  | Nine months ended June 30, |
|  | 2021 |  | 2020 |  | 2021 |  | 2020 |
| Oil and gas | $ | 49,272 |  |  | $ | 45,851 |  |  | $ | 139,443 |  |  | $ | 157,798 |  |
| Petrochemical | 15,365 |  |  | 29,293 |  |  | 34,725 |  |  | 107,057 |  |
| Electric utility | 26,175 |  |  | 16,725 |  |  | 82,797 |  |  | 63,994 |  |
| Traction power | 13,821 |  |  | 9,122 |  |  | 42,322 |  |  | 31,417 |  |
| All others | 11,180 |  |  | 17,071 |  |  | 41,818 |  |  | 43,515 |  |
| Total revenues by market sector | $ | 115,813 |  |  | $ | 118,062 |  |  | $ | 341,105 |  |  | $ | 403,781 |  |


## us-gaap:RevenueFromContractWithCustomerPolicyTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2022-02-09):
[0000080420-22-000007:note_history:25]
Our revenues are primarily generated from the manufacturing of custom-engineered products and systems under long-term fixed-price contracts under which we agree to manufacture various products such as traditional and arc-resistant distribution switchgear and control gear, medium-voltage circuit breakers, monitoring and control communications systems, motor control centers, switches and bus duct systems. These products may be sold separately as an engineered solution but are typically integrated into custom-built enclosures which we also build. These enclosures are referred to as power control room substations (PCRs®), custom-engineered modules or electrical houses (E-Houses). Some contracts may also include the installation and the commissioning of these enclosures.
  (was, 2021-08-04, similarity 0.9994):
[0000080420-21-000041:note_history:25]
Our revenues are primarily generated from the manufacturing of custom-engineered products and systems under long-term fixed-price contracts under which we agree to manufacture various products such as traditional and arc-resistant distribution switchgear and control gear, medium-voltage circuit breakers, monitoring and control communications systems, motor control centers, switches and bus duct systems. These products may be sold separately as an engineered solution, but are typically integrated into custom-built enclosures which we also build. These enclosures are referred to as power control room substations (PCRs®), custom-engineered modules or electrical houses (E-Houses). Some contracts may also include the installation and the commissioning of these enclosures.

- added (2022-02-09):
[0000080420-22-000007:note_history:26]
Revenue from these contracts is generally recognized over time utilizing the cost-to-cost method. Under the cost-to-cost method, the extent of progress towards completion is measured based on the ratio of costs incurred to date to the total estimated costs at completion of the performance obligation. We believe that this method is the most accurate representation of our performance, because it directly measures the value of the services transferred to the customer over time as we incur costs on our contracts. Contract costs include all direct materials, labor and indirect costs related to contract performance, which may include indirect labor, supplies, tools, repairs and depreciation costs.

- changed (2022-02-09):
[0000080420-22-000007:note_history:27]
We also have contracts to provide value-added services such as field service inspection, installation, commissioning, modification and repair, as well as retrofit and retrofill components for existing systems.  If the service contract terms give us the right to invoice the customer for an amount that corresponds directly with the value of our performance completed to date (i.e., a service contract in which we bill a fixed amount for each hour of service provided), then we recognize revenue over time in each reporting period corresponding to the amount with which we have the right to invoice.  Our performance obligations are satisfied as the work progresses. Revenues from our custom-engineered products and value-added services transferred to customers over time accounted for approximately 94% of total revenues for the three months ended December 31, 2021 and 92% of total revenues for the three months ended December 31, 2020.
  (was, 2021-08-04, similarity 0.706):
[0000080420-21-000041:note_history:27]
We also have contracts to provide value-added services such as field service inspection, installation, commissioning, modification and repair, as well as retrofit and retrofill components for existing systems.  If the service contract terms give us the right to invoice the customer for an amount that corresponds directly with the value of our performance completed to date (i.e., a service contract in which we bill a fixed amount for each hour of service provided), then we recognize revenue over time

- changed (2022-02-09):
[0000080420-22-000007:note_history:28]
Additionally, we have sales orders for spare parts and replacement circuit breakers for switchgear that are obsolete or that are no longer produced by the original manufacturer. Revenues from these sales orders are recognized at the time we fulfill our performance obligation to the customer, which is typically upon shipment and represented approximately 6% of total revenues for the three months ended December 31, 2021 and 8% of total revenues for the three months ended December 31, 2020.
  (was, 2021-08-04, similarity 0.8251):
[0000080420-21-000041:note_history:28]
We also have sales orders for spare parts and replacement circuit breakers for switchgear that are obsolete or that are no longer produced by the original manufacturer. Revenues from these sales orders are recognized at the time we fulfill our performance obligation to the customer, which is typically upon shipment and represented approximately 7% of total revenues for the three months ended June 30, 2021, 8% of total revenues for the nine months ended June 30, 2021 and 5% of total revenues for each of the three and nine months ended June 30, 2020.

- changed (2022-02-09):
[0000080420-22-000007:note_history:29]
Some contracts may contain a cancellation clause that could limit the amount of revenue we are able to recognize over time. In these instances, revenue and costs associated with these contracts are deferred and recognized at a point in time when the performance obligation is fulfilled.
Selling and administrative costs incurred in relation to obtaining a contract are typically expensed as incurred. We periodically utilize a third-party sales agent to obtain a contract and will pay a commission to that agent. We record the full commission liability to the third-party sales agents at the order date, with a corresponding deferred asset. As the project progresses, we record commission expense based on percentage of completion rates that correlate to the project and reduce the deferred asset. Once we have been paid by the customer, we pay the commission and the deferred liability is reduced
Performance Obligations
  (was, 2021-08-04, similarity 0.9421):
[0000080420-21-000041:note_history:29]
Additionally, some contracts may contain a cancellation clause that could limit the amount of revenue we are able to recognize over time. In these instances, revenue and costs associated with these contracts are deferred and recognized at a point in time when the performance obligation is fulfilled.
Selling and administrative costs incurred in relation to obtaining a contract are typically expensed as incurred. We periodically utilize a third-party sales agent to obtain a contract and will pay a commission to that agent. We record the full commission liability to the third-party sales agents at the order date, with a corresponding deferred asset. As the project progresses, we record commission expense based on percentage of completion rates that correlate to the project and reduce the deferred asset. Once we have been paid by the customer, we pay the commission and the liability is reduced
Performance Obligations

- changed (2022-02-09):
[0000080420-22-000007:note_history:30]
A performance obligation is a promise in a contract or with a customer to transfer a distinct good or service. A contract’s transaction price is allocated to each distinct performance obligation and recognized as revenue as the performance obligations are satisfied. To determine the proper revenue recognition for contracts, we evaluate whether a contract should be accounted for as more than one performance obligation or, less commonly, whether two or more contracts should be combined and accounted for as one performance obligation.  This evaluation of performance obligations requires significant judgment.  The majority of our contracts have a single performance obligation where multiple engineered products and services are combined into a single custom-engineered solution. Our contracts include a standard one-year assurance warranty. Occasionally, we provide service-type warranties that will extend the warranty period. These extended warranties qualify as a separate performance obligation, and revenue is deferred and recognized over the warranty period. If we determine during the evaluation of the contract that there are multiple performance obligations, we allocate the transaction price to each performance obligation using our best estimate of the standalone selling price of each distinct good or service in the contract. 
Remaining unsatisfied performance obligations, which we refer to as backlog, represent the estimated transaction price for goods and services for which we have a material right, but work has not been performed.
Contract Estimates
  (was, 2021-08-04, similarity 0.9994):
[0000080420-21-000041:note_history:30]
A performance obligation is a promise in a contract or with a customer to transfer a distinct good or service. A contract’s transaction price is allocated to each distinct performance obligation and recognized as revenue as the performance obligations are satisfied. To determine the proper revenue recognition for contracts, we evaluate whether a contract should be accounted for as more than one performance obligation or, less commonly, whether two or more contracts should be combined and accounted for as one performance obligation.  This evaluation of performance obligations requires significant judgment.  The majority of our contracts have a single performance obligation where multiple engineered products and services are combined into a single custom-engineered solution. Our contracts include a standard one year assurance warranty. Occasionally, we provide service-type warranties that will extend the warranty period. These extended warranties qualify as a separate performance obligation, and revenue is deferred and recognized over the warranty period. If we determine during the evaluation of the contract that there are multiple performance obligations, we allocate the transaction price to each performance obligation using our best estimate of the standalone selling price of each distinct good or service in the contract. 
Remaining unsatisfied performance obligations, which we refer to as backlog, represent the estimated transaction price for goods and services for which we have a material right, but work has not been performed.
Contract Estimates

- changed (2022-02-09):
[0000080420-22-000007:note_history:31]
Actual revenues and project costs may vary from previous estimates due to changes in a variety of factors. The cost estimation process is based upon the professional knowledge and experience of our engineers, project managers and financial professionals. Factors that are considered in estimating the work to be completed and ultimate contract recovery include the availability and productivity of labor, the nature and complexity of the work to be performed, the availability of materials, and the effect of any delays on our project performance. We periodically review our job performance, job conditions, estimated profitability and final contract settlements, including our estimate of total costs and make revisions to costs and income in the period in which the revisions are probable and reasonably estimable. We bear the risk of cost overruns in most of our contracts, which may result in reduced profits. Whenever revisions of estimated contract costs and contract values indicate that the contract costs will exceed estimated revenues, thus creating a loss, a provision for the total estimated loss is recorded in that period.
  (was, 2021-08-04, similarity 0.7559):
[0000080420-21-000041:note_history:31]
Actual revenues and project costs may vary from previous estimates due to changes in a variety of factors. The cost estimation process is based upon the professional knowledge and experience of our engineers, project managers and financial professionals. Factors that are considered in estimating the work to be completed and ultimate contract recovery include the availability and productivity of labor, the nature and complexity of the work to be performed, the availability of materials, and the effect of any delays on our project performance. We periodically review our job performance, job conditions, estimated profitability and final contract settlements, including our estimate of total costs and make revisions to costs and income in the period in which the revisions are probable and reasonably estimable. Whenever revisions of estimated contract costs and contract values indicate that the contract costs will exceed estimated revenues, thus creating a loss, a provision for the total estimated loss is recorded in that period.

- changed (2022-02-09):
[0000080420-22-000007:note_history:32]
Contract liabilities typically represent advance payments from contractual billing milestones and billings in excess of revenue recognized. It is unusual to have advanced milestone payments with a term greater than one year, which could represent a financing component on the contract.  
Our contract assets and liabilities are reported in a net position on a contract-by-contract basis at the end of each reporting period and are generally classified as current.The timing of our invoice process is typically dependent on the completion of certain milestones and contract terms and subject to agreement by our customer.  Payment is typically expected within 30 days of invoice. Any uncollected invoiced amounts for our performance obligations recognized over time, including contract retentions, are recorded as accounts receivable in the Condensed Consolidated Balance Sheets. Certain contracts allow customers to withhold a small percentage of billings pursuant to retainage provisions, and such amounts are generally due upon completion of the contract and acceptance of the project by the customer. Based on our experience in recent years, the majority of these retainage balances are expected to be collected within approximately twelve months.
  (was, 2021-08-04, similarity 0.8124):
[0000080420-21-000041:note_history:32]
Contract liabilities typically represent advance payments from contractual billing milestones and billings in excess of revenue recognized. It is unusual to have advanced milestone payments with a term greater than one year, which could represent a financing component on the contract.  
Our contract assets and liabilities are reported in a net position on a contract-by-contract basis at the end of each reporting period and are generally classified as current.The timing of our invoice process is typically dependent on the completion of certain milestones and contract terms and subject to agreement by our customer.  Payment is typically expected within 30 days of invoice. Any uncollected invoiced amounts for our performance obligations recognized over time, including contract retentions, are recorded as accounts receivable in the Condensed Consolidated Balance Sheets. Certain contracts contain retention provisions that become due upon completion of contractual requirements.

- removed (2022-02-09):
[0000080420-21-000041:note_history:33]
Revenue from these contracts is generally recognized over time utilizing the cost-to-cost method to measure the extent of progress toward the completion of the performance obligation and the recognition of revenue over time. We believe that this method is the most accurate representation of our performance, because it directly measures the value of the services transferred to the customer over time as we incur costs on our contracts. Contract costs include all direct materials, labor, and indirect costs related to contract performance, which may include indirect labor, supplies, tools, repairs and depreciation costs.

- removed (2022-02-09):
[0000080420-21-000041:note_history:34]
in each reporting period corresponding to the amount with which we have the right to invoice.  Our performance obligations are satisfied as the work progresses. Revenues from our custom-engineered products and value-added services transferred to customers over time accounted for approximately 93% of total revenues for the three months ended June 30, 2021,  92% of total revenues for the nine months ended June 30, 2021 and 95% of total revenues for each of the three and nine months ended June 30, 2020.


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2022-02-09):
[0000080420-22-000007:note_history:35]
Our revenues are primarily generated from the manufacturing of custom-engineered products and systems under long-term fixed-price contracts under which we agree to manufacture various products such as traditional and arc-resistant distribution switchgear and control gear, medium-voltage circuit breakers, monitoring and control communications systems, motor control centers, switches and bus duct systems. These products may be sold separately as an engineered solution but are typically integrated into custom-built enclosures which we also build. These enclosures are referred to as power control room substations (PCRs®), custom-engineered modules or electrical houses (E-Houses). Some contracts may also include the installation and the commissioning of these enclosures.
  (was, 2021-08-04, similarity 0.9994):
[0000080420-21-000041:note_history:35]
Our revenues are primarily generated from the manufacturing of custom-engineered products and systems under long-term fixed-price contracts under which we agree to manufacture various products such as traditional and arc-resistant distribution switchgear and control gear, medium-voltage circuit breakers, monitoring and control communications systems, motor control centers, switches and bus duct systems. These products may be sold separately as an engineered solution, but are typically integrated into custom-built enclosures which we also build. These enclosures are referred to as power control room substations (PCRs®), custom-engineered modules or electrical houses (E-Houses). Some contracts may also include the installation and the commissioning of these enclosures.

- added (2022-02-09):
[0000080420-22-000007:note_history:36]
Revenue from these contracts is generally recognized over time utilizing the cost-to-cost method. Under the cost-to-cost method, the extent of progress towards completion is measured based on the ratio of costs incurred to date to the total estimated costs at completion of the performance obligation. We believe that this method is the most accurate representation of our performance, because it directly measures the value of the services transferred to the customer over time as we incur costs on our contracts. Contract costs include all direct materials, labor and indirect costs related to contract performance, which may include indirect labor, supplies, tools, repairs and depreciation costs.

- changed (2022-02-09):
[0000080420-22-000007:note_history:37]
We also have contracts to provide value-added services such as field service inspection, installation, commissioning, modification and repair, as well as retrofit and retrofill components for existing systems.  If the service contract terms give us the right to invoice the customer for an amount that corresponds directly with the value of our performance completed to date (i.e., a service contract in which we bill a fixed amount for each hour of service provided), then we recognize revenue over time in each reporting period corresponding to the amount with which we have the right to invoice.  Our performance obligations are satisfied as the work progresses. Revenues from our custom-engineered products and value-added services transferred to customers over time accounted for approximately 94% of total revenues for the three months ended December 31, 2021 and 92% of total revenues for the three months ended December 31, 2020.
  (was, 2021-08-04, similarity 0.706):
[0000080420-21-000041:note_history:37]
We also have contracts to provide value-added services such as field service inspection, installation, commissioning, modification and repair, as well as retrofit and retrofill components for existing systems.  If the service contract terms give us the right to invoice the customer for an amount that corresponds directly with the value of our performance completed to date (i.e., a service contract in which we bill a fixed amount for each hour of service provided), then we recognize revenue over time

- changed (2022-02-09):
[0000080420-22-000007:note_history:38]
Additionally, we have sales orders for spare parts and replacement circuit breakers for switchgear that are obsolete or that are no longer produced by the original manufacturer. Revenues from these sales orders are recognized at the time we fulfill our performance obligation to the customer, which is typically upon shipment and represented approximately 6% of total revenues for the three months ended December 31, 2021 and 8% of total revenues for the three months ended December 31, 2020.
  (was, 2021-08-04, similarity 0.8251):
[0000080420-21-000041:note_history:38]
We also have sales orders for spare parts and replacement circuit breakers for switchgear that are obsolete or that are no longer produced by the original manufacturer. Revenues from these sales orders are recognized at the time we fulfill our performance obligation to the customer, which is typically upon shipment and represented approximately 7% of total revenues for the three months ended June 30, 2021, 8% of total revenues for the nine months ended June 30, 2021 and 5% of total revenues for each of the three and nine months ended June 30, 2020.

- changed (2022-02-09):
[0000080420-22-000007:note_history:39]
Some contracts may contain a cancellation clause that could limit the amount of revenue we are able to recognize over time. In these instances, revenue and costs associated with these contracts are deferred and recognized at a point in time when the performance obligation is fulfilled.
  (was, 2021-08-04, similarity 0.9181):
[0000080420-21-000041:note_history:39]
Additionally, some contracts may contain a cancellation clause that could limit the amount of revenue we are able to recognize over time. In these instances, revenue and costs associated with these contracts are deferred and recognized at a point in time when the performance obligation is fulfilled.

- changed (2022-02-09):
[0000080420-22-000007:note_history:40]
Selling and administrative costs incurred in relation to obtaining a contract are typically expensed as incurred. We periodically utilize a third-party sales agent to obtain a contract and will pay a commission to that agent. We record the full commission liability to the third-party sales agents at the order date, with a corresponding deferred asset. As the project progresses, we record commission expense based on percentage of completion rates that correlate to the project and reduce the deferred asset. Once we have been paid by the customer, we pay the commission and the deferred liability is reduced.
  (was, 2021-08-04, similarity 0.9926):
[0000080420-21-000041:note_history:40]
Selling and administrative costs incurred in relation to obtaining a contract are typically expensed as incurred. We periodically utilize a third-party sales agent to obtain a contract and will pay a commission to that agent. We record the full commission liability to the third-party sales agents at the order date, with a corresponding deferred asset. As the project progresses, we record commission expense based on percentage of completion rates that correlate to the project and reduce the deferred asset. Once we have been paid by the customer, we pay the commission and the liability is reduced.

- changed (2022-02-09):
[0000080420-22-000007:note_history:41]
A performance obligation is a promise in a contract or with a customer to transfer a distinct good or service. A contract’s transaction price is allocated to each distinct performance obligation and recognized as revenue as the performance obligations are satisfied. To determine the proper revenue recognition for contracts, we evaluate whether a contract should be accounted for as more than one performance obligation or, less commonly, whether two or more contracts should be combined and accounted for as one performance obligation.  This evaluation of performance obligations requires significant judgment.  The majority of our contracts have a single performance obligation where multiple engineered products and services are combined into a single custom-engineered solution. Our contracts include a standard one-year assurance warranty. Occasionally, we provide service-type warranties that will extend the warranty period. These extended warranties qualify as a separate performance obligation, and revenue is deferred and recognized over the warranty period. If we determine during the evaluation of the contract that there are multiple performance obligations, we allocate the transaction price to each performance obligation using our best estimate of the standalone selling price of each distinct good or service in the contract.
  (was, 2021-08-04, similarity 0.9993):
[0000080420-21-000041:note_history:41]
A performance obligation is a promise in a contract or with a customer to transfer a distinct good or service. A contract’s transaction price is allocated to each distinct performance obligation and recognized as revenue as the performance obligations are satisfied. To determine the proper revenue recognition for contracts, we evaluate whether a contract should be accounted for as more than one performance obligation or, less commonly, whether two or more contracts should be combined and accounted for as one performance obligation.  This evaluation of performance obligations requires significant judgment.  The majority of our contracts have a single performance obligation where multiple engineered products and services are combined into a single custom-engineered solution. Our contracts include a standard one year assurance warranty. Occasionally, we provide service-type warranties that will extend the warranty period. These extended warranties qualify as a separate performance obligation, and revenue is deferred and recognized over the warranty period. If we determine during the evaluation of the contract that there are multiple performance obligations, we allocate the transaction price to each performance obligation using our best estimate of the standalone selling price of each distinct good or service in the contract.

- changed (2022-02-09):
[0000080420-22-000007:note_history:42]
Remaining unsatisfied performance obligations, which we refer to as backlog, represent the estimated transaction price for goods and services for which we have a material right, but work has not been performed. As of December 31, 2021, we had backlog of $416.0 million, of which approximately $301.7 million is expected to be recognized as revenue within the next twelve months. Backlog may not be indicative of future operating results as orders may be cancelled or modified by our customers. Our backlog does not include service and maintenance-type contracts for which we have the right to invoice as services are performed.
  (was, 2021-08-04, similarity 0.9902):
[0000080420-21-000041:note_history:42]
Remaining unsatisfied performance obligations, which we refer to as backlog, represent the estimated transaction price for goods and services for which we have a material right, but work has not been performed. As of June 30, 2021, we had backlog of $425.5 million, of which approximately $292.8 million is expected to be recognized as revenue within the next twelve months. Backlog may not be indicative of future operating results as orders may be cancelled or modified by our customers. Our backlog does not include service and maintenance-type contracts for which we have the right to invoice as services are performed.

- changed (2022-02-09):
[0000080420-22-000007:note_history:43]
Actual revenues and project costs may vary from previous estimates due to changes in a variety of factors. The cost estimation process is based upon the professional knowledge and experience of our engineers, project managers and financial professionals. Factors that are considered in estimating the work to be completed and ultimate contract recovery include the availability and productivity of labor, the nature and complexity of the work to be performed, the availability of materials, and the effect of any delays on our project performance. We periodically review our job performance, job conditions, estimated profitability and final contract settlements, including our estimate of total costs and make revisions to costs and income in the period in which the revisions are probable and reasonably estimable. We bear the risk of cost overruns in most of our contracts, which may result in reduced profits. Whenever revisions of estimated contract costs and contract values indicate that the contract costs will exceed estimated revenues, thus creating a loss, a provision for the total estimated loss is recorded in that period.
  (was, 2021-08-04, similarity 0.7559):
[0000080420-21-000041:note_history:43]
Actual revenues and project costs may vary from previous estimates due to changes in a variety of factors. The cost estimation process is based upon the professional knowledge and experience of our engineers, project managers and financial professionals. Factors that are considered in estimating the work to be completed and ultimate contract recovery include the availability and productivity of labor, the nature and complexity of the work to be performed, the availability of materials, and the effect of any delays on our project performance. We periodically review our job performance, job conditions, estimated profitability and final contract settlements, including our estimate of total costs and make revisions to costs and income in the period in which the revisions are probable and reasonably estimable. Whenever revisions of estimated contract costs and contract values indicate that the contract costs will exceed estimated revenues, thus creating a loss, a provision for the total estimated loss is recorded in that period.

- changed (2022-02-09):
[0000080420-22-000007:note_history:44]
For the three months ended December 31, 2021 and 2020, our operating results were positively impacted by $2.8 million and $5.5 million, respectively, as a result of changes in contract estimates related to projects in progress at the beginning of the respective period. These changes in estimates resulted primarily from favorable project execution and negotiations of variable consideration, discussed below, as well as revenue and reduced costs recognized from project cancellations and other changes in facts and circumstances during these periods. The decrease from the prior year is primarily due to the increase in raw material commodity costs.
  (was, 2021-08-04, similarity 0.8735):
[0000080420-21-000041:note_history:44]
For the nine months ended June 30, 2021 and 2020, our operating results were positively impacted by $11.4 million and $10.8 million, respectively, as a result of changes in contract estimates related to projects in progress at the beginning of the respective period. These changes in estimates resulted primarily from favorable project execution and negotiations of variable consideration, discussed below, as well as revenue and reduced costs recognized from project cancellations and other changes in facts and circumstances during these periods.

- changed (2022-02-09):
[0000080420-22-000007:note_history:45]
Our contract assets and liabilities are reported in a net position on a contract-by-contract basis at the end of each reporting period and are generally classified as current.
  (was, 2021-08-04, similarity 0.6542):
[0000080420-21-000041:note_history:45]
Our contract assets and liabilities are reported in a net position on a contract-by-contract basis at the end of each reporting period and are generally classified as current. The timing of contract billing milestones related to our Fiscal 2020 contract award for a large industrial project contributed significantly to our net contract liability at September 30, 2020.

- changed (2022-02-09):
[0000080420-22-000007:note_history:46]
Contract assets and liabilities as of December 31, 2021 and September 30, 2021 are summarized below (in thousands):
  (was, 2021-08-04, similarity 0.9515):
[0000080420-21-000041:note_history:46]
Contract assets and liabilities as of June 30, 2021 and September 30, 2020 are summarized below (in thousands):

- changed (2022-02-09):
[0000080420-22-000007:note_history:47]
|  | December 31, 2021 |  | September 30, 2021 |
| Contract assets | $ | 67,904 |  |  | $ | 54,199 |  |
| Contract liabilities | (49,396) |  |  | (42,433) |  |
| Net contract asset | $ | 18,508 |  |  | $ | 11,766 |  |
  (was, 2021-08-04, similarity 0.9298):
[0000080420-21-000041:note_history:47]
|  | June 30, 2021 |  | September 30, 2020 |
| Contract assets | $ | 50,827 |  |  | $ | 50,995 |  |
| Contract liabilities | (43,140) |  |  | (79,445) |  |
| Net contract asset (liability) | $ | 7,687 |  |  | $ | (28,450) |  |

- added (2022-02-09):
[0000080420-22-000007:note_history:48]
The increase in net contract asset at December 31, 2021 from September 30, 2021 was primarily due to the timing of contract billing milestones and new orders as well as cash used on our large industrial project awarded in Fiscal 2020. To determine the amount of revenue recognized during the period from contract liabilities, we first allocate revenue to the individual contract liability balance outstanding at the beginning of the period until the revenue exceeds that balance. During the three months ended December 31, 2021, we recognized revenue of approximately $23.3 million that was related to contract liabilities outstanding at September 30, 2021.

- changed (2022-02-09):
[0000080420-22-000007:note_history:49]
The timing of our invoice process is typically dependent on the completion of certain milestones and contract terms and subject to agreement by our customer.  Payment is typically expected within 30 days of invoice. Any uncollected invoiced amounts for our performance obligations recognized over time, including contract retentions, are recorded as accounts receivable in the Condensed Consolidated Balance Sheets. Certain contracts allow customers to withhold a small percentage of billings pursuant to retainage provisions, and such amounts are generally due upon completion of the contract and acceptance of the project by the customer. Based on our experience in recent years, the majority of these retainage balances are expected to be collected within approximately twelve months. As of December 31, 2021 and September 30, 2021, accounts receivable included retention amounts of $9.3 million and $9.6 million, respectively. Of the retained amount at December 31, 2021, $6.8 million is expected to be collected in the next twelve months and is recorded in accounts receivable. The remaining $2.5 million is recorded in other assets.
  (was, 2021-08-04, similarity 0.7631):
[0000080420-21-000041:note_history:49]
The timing of our invoice process is typically dependent on the completion of certain milestones and contract terms and subject to agreement by our customer.  Payment is typically expected within 30 days of invoice. Any uncollected invoiced amounts for our performance obligations recognized over time, including contract retentions, are recorded as accounts receivable in the Condensed Consolidated Balance Sheets. Certain contracts contain retention provisions that become due upon completion of contractual requirements. As of June 30, 2021 and September 30, 2020, accounts receivable included retention amounts of $9.3 million and $6.9 million, respectively. Of the retained amount at June 30, 2021, $7.3 million is expected to be collected in the next twelve months and is recorded in accounts receivable. The remaining $2.0 million is recorded in other assets.

- changed (2022-02-09):
[0000080420-22-000007:note_history:50]
The following tables present our disaggregated revenue by geographic destination and market sector for the three months ended December 31, 2021 and 2020 (in thousands):
  (was, 2021-08-04, similarity 0.9415):
[0000080420-21-000041:note_history:50]
The following tables present our disaggregated revenue by geographic destination and market sector for the three and nine months ended June 30, 2021 and 2020 (in thousands):

- changed (2022-02-09):
[0000080420-22-000007:note_history:51]
|  | Three months ended December 31, |  |  |
|  | 2021 |  | 2020 |  |  |  |  |
| United States | $ | 82,145 |  |  | $ | 80,586 |  |  |  |  |  |
| Canada | 15,125 |  |  | 14,091 |  |  |  |  |  |
| Europe, Middle East and Africa | 7,830 |  |  | 8,256 |  |  |  |  |  |
| Asia/Pacific | 944 |  |  | 2,716 |  |  |  |  |  |
| Mexico, Central and South America | 525 |  |  | 926 |  |  |  |  |  |
| Total revenues by geographic destination | $ | 106,569 |  |  | $ | 106,575 |  |  |  |  |  |
  (was, 2021-08-04, similarity 0.6012):
[0000080420-21-000041:note_history:51]
|  | Three months ended June 30, |  | Nine months ended June 30, |
|  | 2021 |  | 2020 |  | 2021 |  | 2020 |
| United States | $ | 88,412 |  |  | $ | 89,499 |  |  | $ | 256,937 |  |  | $ | 318,009 |  |
| Canada | 16,529 |  |  | 16,970 |  |  | 48,354 |  |  | 46,831 |  |
| Europe, Middle East and Africa | 8,926 |  |  | 6,422 |  |  | 28,120 |  |  | 25,404 |  |
| Asia/Pacific | 1,651 |  |  | 4,643 |  |  | 6,376 |  |  | 11,784 |  |
| Mexico, Central and South America | 295 |  |  | 528 |  |  | 1,318 |  |  | 1,753 |  |
| Total revenues by geographic destination | $ | 115,813 |  |  | $ | 118,062 |  |  | $ | 341,105 |  |  | $ | 403,781 |  |

- added (2022-02-09):
[0000080420-22-000007:note_history:52]
|  | Three months ended December 31, |  |  |
|  | 2021 |  | 2020 |  |  |  |  |
| Oil and gas (excludes petrochemical) | $ | 43,021 |  |  | $ | 40,028 |  |  |  |  |  |
| Petrochemical | 17,228 |  |  | 9,165 |  |  |  |  |  |
| Electric utility | 21,533 |  |  | 28,171 |  |  |  |  |  |
| Traction power | 11,372 |  |  | 13,361 |  |  |  |  |  |
| All others | 13,415 |  |  | 15,850 |  |  |  |  |  |
| Total revenues by market sector | $ | 106,569 |  |  | $ | 106,575 |  |  |  |  |  |

- removed (2022-02-09):
[0000080420-21-000041:note_history:53]
Revenue from these contracts is generally recognized over time utilizing the cost-to-cost method to measure the extent of progress toward the completion of the performance obligation and the recognition of revenue over time. We believe that this method is the most accurate representation of our performance, because it directly measures the value of the services transferred to the customer over time as we incur costs on our contracts. Contract costs include all direct materials, labor, and indirect costs related to contract performance, which may include indirect labor, supplies, tools, repairs and depreciation costs.

- removed (2022-02-09):
[0000080420-21-000041:note_history:54]
in each reporting period corresponding to the amount with which we have the right to invoice.  Our performance obligations are satisfied as the work progresses. Revenues from our custom-engineered products and value-added services transferred to customers over time accounted for approximately 93% of total revenues for the three months ended June 30, 2021,  92% of total revenues for the nine months ended June 30, 2021 and 95% of total revenues for each of the three and nine months ended June 30, 2020.

- removed (2022-02-09):
[0000080420-21-000041:note_history:55]
The increase in net contract asset at June 30, 2021 from September 30, 2020 was primarily due to the timing of contract billing milestones and new orders. To determine the amount of revenue recognized during the period from contract liabilities, we first allocate revenue to the individual contract liability balance outstanding at the beginning of the period until the revenue exceeds that balance. During the nine months ended June 30, 2021, we recognized revenue of approximately $63.5 million that was related to contract liabilities outstanding at September 30, 2020.

- removed (2022-02-09):
[0000080420-21-000041:note_history:56]
|  | Three months ended June 30, |  | Nine months ended June 30, |
|  | 2021 |  | 2020 |  | 2021 |  | 2020 |
| Oil and gas | $ | 49,272 |  |  | $ | 45,851 |  |  | $ | 139,443 |  |  | $ | 157,798 |  |
| Petrochemical | 15,365 |  |  | 29,293 |  |  | 34,725 |  |  | 107,057 |  |
| Electric utility | 26,175 |  |  | 16,725 |  |  | 82,797 |  |  | 63,994 |  |
| Traction power | 13,821 |  |  | 9,122 |  |  | 42,322 |  |  | 31,417 |  |
| All others | 11,180 |  |  | 17,071 |  |  | 41,818 |  |  | 43,515 |  |
| Total revenues by market sector | $ | 115,813 |  |  | $ | 118,062 |  |  | $ | 341,105 |  |  | $ | 403,781 |  |


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: tag_name, score: 1.0

- added (2022-02-09):
[0000080420-22-000007:note_history:57]
On February 1, 2022, our Board of Directors declared a quarterly cash dividend on our common stock in the amount of $0.26 per share. The dividend is payable on March 16, 2022 to shareholders of record at the close of business on February 16, 2022.

- removed (2022-02-09):
[0000080420-21-000041:note_history:58]
On August 3, 2021, our Board of Directors declared a quarterly cash dividend on our common stock in the amount of $0.26 per share. The dividend is payable on September 15, 2021 to shareholders of record at the close of business on August 18, 2021.
