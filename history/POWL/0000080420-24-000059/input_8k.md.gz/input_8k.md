# POWL 8-K — 0000080420-24-000057 filed 2024-07-30

## item codes, every 8-K on or before 2024-07-31

- 2024-07-30 0000080420-24-000057 — 2.02, 8.01, 9.01
- 2024-04-30 0000080420-24-000026 — 2.02, 8.01, 9.01
- 2024-02-15 0000080420-24-000014 — 5.02, 5.07
- 2024-01-30 0000080420-24-000005 — 2.02, 8.01, 9.01
- 2024-01-08 0000080420-24-000002 — 5.02
- 2023-12-05 0000080420-23-000047 — 2.02, 9.01
- 2023-11-03 0000080420-23-000044 — 8.01, 9.01
- 2023-10-11 0000080420-23-000041 — 1.01, 2.03
- 2023-08-01 0000080420-23-000036 — 2.02, 8.01, 9.01
- 2023-05-19 0001193125-23-149334 — 5.07 — amendment of 0000080420-23-000011
- 2023-05-03 0000080420-23-000025 — 2.02, 8.01, 9.01
- 2023-04-06 0000080420-23-000020 — 1.01, 2.03, 9.01
- 2023-04-05 0000080420-23-000018 — 5.02
- 2023-02-16 0000080420-23-000011 — 5.02, 5.07, 9.01
- 2023-01-31 0000080420-23-000004 — 2.02, 8.01
- 2022-12-05 0000080420-22-000034 — 2.02, 9.01
- 2022-08-02 0000080420-22-000030 — 2.02, 8.01, 9.01
- 2022-05-13 0000080420-22-000024 — 5.02, 9.01
- 2022-05-03 0000080420-22-000016 — 2.02, 9.01
- 2022-05-03 0000080420-22-000015 — 8.01, 9.01
- 2022-02-17 0000080420-22-000010 — 5.07
- 2022-02-08 0000080420-22-000005 — 2.02, 9.01
- 2022-02-01 0000080420-22-000002 — 8.01, 9.01
- 2021-12-07 0000080420-21-000043 — 2.02, 9.01
- 2021-08-03 0000080420-21-000036 — 2.02, 8.01, 9.01
- 2021-05-04 0000080420-21-000026 — 2.02, 8.01, 9.01
- 2021-03-16 0001193125-21-082878 — 1.01, 2.03, 9.01
- 2021-03-05 0000080420-21-000021 — 5.02, 8.01, 9.01
- 2021-02-26 0000080420-21-000018 — 5.03
- 2021-02-18 0000080420-21-000016 — 5.07
- 2021-02-02 0000080420-21-000010 — 2.02, 8.01, 9.01
- 2020-12-08 0000080420-20-000032 — 2.02, 9.01
- 2020-11-12 0000080420-20-000030 — 8.01, 9.01
- 2020-08-04 0000080420-20-000024 — 2.02, 8.01, 9.01
- 2020-05-05 0000080420-20-000017 — 2.02, 8.01, 9.01
- 2020-02-21 0000080420-20-000008 — 5.07
- 2020-02-04 0000080420-20-000003 — 2.02, 8.01, 9.01
- 2019-12-04 0001193125-19-306243 — 2.02, 9.01
- 2019-11-08 0000080420-19-000032 — 8.01, 9.01
- 2019-10-03 0000080420-19-000030 — 1.01, 2.03
- 2019-09-24 0000080420-19-000028 — 8.01, 9.01
- 2019-08-06 0000080420-19-000022 — 2.02, 8.01, 9.01
- 2019-05-08 0000080420-19-000017 — 5.02, 9.01
- 2019-05-07 0000080420-19-000011 — 2.02, 8.01, 9.01
- 2019-02-22 0001193125-19-048366 — 5.07
- 2019-02-05 0000080420-19-000003 — 2.02, 8.01
- 2018-12-21 0000080420-18-000038 — 5.02, 9.01
- 2018-12-12 0000080420-18-000031 — 2.02
- 2018-11-05 0000080420-18-000029 — 8.01, 9.01
- 2018-11-01 0000080420-18-000027 — 5.02, 8.01, 9.01
- 2018-10-01 0000080420-18-000024 — 5.02
- 2018-08-07 0000080420-18-000020 — 2.02, 8.01
- 2018-05-15 0000080420-18-000016 — 5.02, 8.01
- 2018-05-09 0000080420-18-000011 — 2.02, 8.01
- 2018-02-22 0000080420-18-000009 — 5.07
- 2018-02-06 0000080420-18-000003 — 2.02, 8.01
- 2017-12-27 0001193125-17-379928 — 5.02
- 2017-12-05 0000080420-17-000028 — 2.02, 9.01
- 2017-11-08 0000080420-17-000024 — 8.01, 9.01
- 2017-11-03 0000080420-17-000022 — 5.02
- 2017-08-09 0000080420-17-000017 — 2.02, 8.01
- 2017-06-30 0000080420-17-000014 — 1.01, 9.01
- 2017-05-03 0000080420-17-000006 — 2.02, 8.01, 9.01
- 2017-02-23 0000080420-17-000004 — 5.07
- 2017-02-08 0001628280-17-000965 — 2.02 — amendment of 0001628280-17-000949
- 2017-02-07 0001628280-17-000949 — 2.01, 8.01, 9.01
- 2016-12-07 0001193125-16-787354 — 2.02, 9.01
- 2016-11-01 0001193125-16-755475 — 8.01, 9.01
- 2016-09-30 0001193125-16-726999 — 5.02, 8.01, 9.01
- 2016-08-03 0001193125-16-669308 — 2.02, 8.01, 9.01
- 2016-05-04 0001193125-16-576528 — 2.02, 8.01, 9.01
- 2016-02-25 0001193125-16-477896 — 5.07
- 2016-02-03 0001193125-16-449052 — 2.02, 8.01, 9.01
- 2015-12-31 0001193125-15-418363 — 5.02, 7.01, 9.01
- 2015-12-02 0001193125-15-393109 — 2.02, 9.01
- 2015-11-05 0001193125-15-368085 — 8.01, 9.01
- 2015-09-25 0001193125-15-329031 — 5.02
- 2015-08-05 0001193125-15-277912 — 2.02, 8.01, 9.01
- 2015-05-06 0001193125-15-174291 — 2.02, 8.01, 9.01
- 2015-03-06 0001193125-15-081070 — 5.02
- 2015-03-02 0001193125-15-072946 — 5.07
- 2015-02-03 0001193125-15-031772 — 2.02, 8.01, 9.01
- 2014-12-18 0001193125-14-446513 — 8.01, 9.01
- 2014-12-03 0001193125-14-431745 — 2.02, 9.01
- 2014-11-05 0001193125-14-397955 — 8.01, 9.01
- 2014-09-26 0001193125-14-353741 — 7.01, 9.01
- 2014-08-05 0001193125-14-296001 — 2.02, 8.01, 9.01
- 2014-05-07 0001193125-14-187496 — 2.02, 8.01, 9.01
- 2014-03-03 0001193125-14-079843 — 5.02, 5.07
- 2014-02-05 0001193125-14-036633 — 2.02, 8.01, 9.01
- 2014-01-17 0001193125-14-014351 — 1.01, 8.01, 9.01
- 2014-01-06 0001193125-14-002795 — 1.01, 2.03
- 2013-12-06 0001564590-13-001411 — 2.02, 9.01
- 2013-12-05 0001564590-13-001406 — 5.02, 8.01, 9.01
- 2013-11-07 0001193125-13-432950 — 8.01, 9.01
- 2013-08-07 0001193125-13-324337 — 2.02, 9.01
- 2013-05-08 0001193125-13-206800 — 2.02, 9.01
- 2013-02-22 0001193125-13-070971 — 5.02, 5.07
- 2013-02-06 0001193125-13-040556 — 2.02, 9.01
- 2012-12-18 0001193125-12-506417 — 5.02, 9.01
- 2012-12-05 0001193125-12-491749 — 2.02, 9.01
- 2012-10-12 0001193125-12-421889 — 3.03, 5.02, 5.03, 9.01
- 2012-08-09 0001193125-12-344617 — 5.02, 8.01, 9.01
- 2012-08-08 0001193125-12-343630 — 2.02, 9.01
- 2012-05-09 0001193125-12-221356 — 2.02, 9.01
- 2012-02-08 0001193125-12-046560 — 2.02, 9.01
- 2011-12-08 0001193125-11-334810 — 2.02, 9.01
- 2011-11-08 0000950123-11-096524 — 2.02, 2.06, 4.02, 9.01
- 2011-10-14 0000950123-11-090124 — 5.02
- 2011-10-06 0000950123-11-088969 — 5.02
- 2011-09-19 0000950123-11-085224 — 5.02, 9.01
- 2011-09-15 0000950123-11-084806 — 5.02, 9.01
- 2011-08-04 0000950123-11-072788 — 2.02, 9.01
- 2011-07-22 0000950123-11-067402 — 5.07
- 2011-05-24 0000950123-11-053550 — 1.01, 2.03, 9.01
- 2011-05-04 0000950123-11-044561 — 2.02, 9.01
- 2011-02-02 0000950123-11-008188 — 2.02, 9.01
- 2010-12-08 0000950123-10-111987 — 2.02, 9.01
- 2010-08-05 0000950123-10-073114 — 2.02, 9.01
- 2010-05-18 0000950123-10-050900 — 5.02
- 2010-05-05 0000950123-10-044499 — 2.02, 9.01
- 2010-02-03 0000950123-10-008278 — 2.02, 9.01
- 2009-12-21 0000950123-09-072269 — 1.01, 2.01, 2.03, 8.01, 9.01
- 2009-12-09 0000950123-09-069525 — 2.02, 9.01
- 2009-10-27 0000950123-09-053501 — 1.01, 8.01, 9.01
- 2009-08-04 0000950123-09-029476 — 2.02, 9.01
- 2009-05-06 0000950129-09-001498 — 2.02, 9.01
- 2009-03-05 0000950129-09-000749 — 1.01, 9.01
- 2009-02-10 0000950129-09-000349 — 2.02, 9.01
- 2008-12-10 0000950134-08-021934 — 2.02, 9.01
- 2008-08-06 0000950129-08-004267 — 2.02, 9.01
- 2008-07-24 0000950129-08-004063 — 1.01, 5.02, 8.01, 9.01
- 2008-06-16 0000950129-08-003500 — 9.01 — amendment of 0000950134-06-015374
- 2008-06-05 0000950129-08-003378 — 5.02, 9.01
- 2008-05-08 0000950129-08-002843 — 2.02, 9.01
- 2008-02-06 0000950129-08-000533 — 2.02, 9.01
- 2007-12-19 0000950129-07-006277 — 1.01, 2.03, 9.01
- 2007-12-06 0000950129-07-006003 — 2.02, 9.01
- 2007-08-21 0000950129-07-004181 — 2.02, 9.01
- 2007-05-31 0000950129-07-002810 — 2.02, 9.01
- 2007-05-21 0000950129-07-002668 — 2.02, 3.01, 4.02, 9.01
- 2007-04-16 0000950129-07-002002 — 2.02, 4.02, 9.01
- 2007-03-01 0000950129-07-001104 — 5.02, 8.01, 9.01
- 2007-02-08 0000950129-07-000451 — 2.02, 9.01
- 2006-12-08 0000950129-06-010041 — 2.02, 9.01
- 2006-09-08 0000950129-06-008379 — 2.02, 9.01
- 2006-08-09 0000950134-06-015374 — 1.01, 2.01, 8.01, 9.01
- 2006-06-08 0000950129-06-006127 — 2.02, 9.01
- 2006-03-09 0000950129-06-002455 — 2.02, 9.01
- 2005-12-16 0000950129-05-012031 — 2.02, 5.03, 9.01
- 2005-09-13 0000950129-05-009181 — 2.01, 9.01 — amendment of 0000950129-05-006889
- 2005-09-12 0000950129-05-009151 — 2.02, 9.01
- 2005-07-06 0000950129-05-006889 — 1.01, 1.02, 2.01, 2.03, 9.01
- 2005-06-10 0000950129-05-006128 — 2.02, 9.01
- 2005-04-20 0000080420-05-000031 — 5.02
- 2005-03-11 0000080420-05-000024 — 9.01
- 2005-02-25 0000080420-05-000018 — 7.01, 9.01
- 2005-01-21 0000080420-05-000009 — 7.01, 9.01
- 2004-12-17 0000080420-04-000049 — 2.02, 9.01
- 2004-11-01 0000080420-04-000045 — 8.01, 9.01
- 2004-10-08 0001169232-04-005133 — 2.05
- 2004-09-14 0000080420-04-000037 — 5.02
- 2004-09-02 0000080420-04-000030 — 2.02, 9.01
- 2004-06-08 0000080420-04-000021 — 7
- 2004-05-13 0000080420-04-000019 — 4
- 2004-02-27 0000080420-04-000013 — 7
- 2003-12-16 0000950129-03-006136 — 12, 7
- 2003-08-29 0000950129-03-004531 — 12, 7
- 2003-06-03 0000950129-03-003035 — 7, 9
- 2003-05-15 0000950129-03-002812 — 7, 9
- 2002-05-29 0000950129-02-002795 — 4
- 2000-12-21 0000950129-00-006093 — 5, 7
- 1998-09-04 0000950129-98-003802 — 5
- 1996-08-09 0000950129-96-001705 — 2, 7

## late-filing notifications on or before 2024-07-31

- 2007-05-11 0000950129-07-002494 — NT 10-Q, for the period ended 2007-03-31
- 2005-01-18 0000080420-05-000004 — NT 10-K, for the period ended 2004-10-31

## item 2.02 — earnings release, exhibit 99.1

[0000080420-24-000057:8k_2_02:1]
EX-99.1
2
ex991-powlq3xfy2024earning.htm
EX-99.1

[0000080420-24-000057:8k_2_02:2]
Document

[0000080420-24-000057:8k_2_02:3]
Exhibit 99.1

[0000080420-24-000057:8k_2_02:4]
PRESS RELEASE

[0000080420-24-000057:8k_2_02:5]
For Immediate Release

[0000080420-24-000057:8k_2_02:6]
|  |  |  | Contacts: | Michael W. Metcalf, CFO |
|  |  |  |  | Powell Industries, Inc. |
|  |  |  |  | 713-947-4422 |
|  |  |  |  | Robert Winters or Ryan Coleman |
|  |  |  |  | Alpha IR Group |
|  |  |  |  | POWL@alpha-ir.com |
|  |  |  |  | 312-445-2870 |

[0000080420-24-000057:8k_2_02:7]
POWELL INDUSTRIES ANNOUNCES THIRD QUARTER FISCAL 2024 RESULTS

[0000080420-24-000057:8k_2_02:8]
HOUSTON — July 30, 2024 — Powell Industries, Inc. (NASDAQ: POWL), a leading supplier of custom-engineered solutions for the management, control and distribution of electrical energy, today announced results for the third quarter of fiscal 2024 ended June 30, 2024. All comparisons are to the third quarter of fiscal 2023, unless otherwise noted.

[0000080420-24-000057:8k_2_02:9]
Third Quarter Key Financial Highlights:

[0000080420-24-000057:8k_2_02:10]
•Revenues totaled $288 million, an increase of 50%;

[0000080420-24-000057:8k_2_02:11]
•Gross profit of $82 million, or 28.4% of revenue;

[0000080420-24-000057:8k_2_02:12]
•Net income of $46 million, or $3.79 per diluted share;

[0000080420-24-000057:8k_2_02:13]
•New orders(1) totaled $356 million, spread broadly across our key end markets;

[0000080420-24-000057:8k_2_02:14]
•Backlog(2) as of June 30, 2024 remained at $1.3 billion;

[0000080420-24-000057:8k_2_02:15]
•Cash and short-term investments as of June 30, 2024 totaled $374 million.

[0000080420-24-000057:8k_2_02:16]
Brett A. Cope, Powell’s Chairman and Chief Executive Officer, stated, “Powell’s fiscal third quarter results reflect strong execution across Powell and further validates our strategy as

[0000080420-24-000057:8k_2_02:17]
well as our unique market position as an integrator of complex, engineered-to-order electrical solutions. Revenues in the quarter were 50% higher than the prior period, driven by strength across nearly all of the market sectors we serve. We booked $356 million of new orders in the quarter, which were spread broadly across our key end markets. Importantly, the most significant increase was driven by our Electric Utility sector, while we were also awarded a notable Petrochemical order in the quarter. Overall, I am very pleased to report solid operational performance in the quarter coupled with broad and robust customer activity across our markets.”

[0000080420-24-000057:8k_2_02:18]
Third Quarter Fiscal 2024 Results

[0000080420-24-000057:8k_2_02:19]
Revenues totaled $288.2 million, an increase of 50% compared to $192.4 million in the prior period, and an increase of 13% compared to $255.1 million in the second quarter of fiscal 2024. The increase compared to the prior period was primarily driven by strong growth in the Oil and Gas sector, which grew by 56% to $114.3 million, as well as by the Petrochemical sector, which grew 158% to $56.8 million. Revenues from the Electric Utility sector totaled $57.0 million, an increase of 30%, while revenues within the Commercial and Other Industrial sector increased 18% to $42.0 million.

[0000080420-24-000057:8k_2_02:20]
Gross profit increased 92% to $81.7 million, or 28.4% of revenue, compared to $42.7 million, or 22.2% of revenue, in the prior period and compared to $62.7 million, or 24.6% of revenue, in the second quarter of fiscal 2024. The increase in gross margin was driven by the higher volume levels across all of Powell’s manufacturing facilities generating favorable volume leverage, strong project execution, and continuing efforts to improve factory efficiencies while also managing product pricing that corresponds to current cost levels.

[0000080420-24-000057:8k_2_02:21]
New orders totaled $356 million compared to $505 million in the prior period and compared to $235 million in the second quarter of fiscal 2024. The year-over-year decline was the result of two greenfield LNG projects on the Gulf Coast that combined for roughly $200 million that were awarded in the third quarter of fiscal 2023.

[0000080420-24-000057:8k_2_02:22]
Backlog totaled $1.3 billion as of June 30, 2024, which was essentially unchanged when compared to backlog as of March 31, 2024, as well as backlog as of June 30, 2023.

[0000080420-24-000057:8k_2_02:23]
Net income was $46.2 million, or $3.79 per diluted share, compared to $18.5 million, or $1.52 per diluted share in the prior period and compared to $33.5 million, or $2.75 per diluted share, in the second quarter of fiscal 2024.

[0000080420-24-000057:8k_2_02:24]
Cope added, “We remain very confident in the composition of our current backlog, the near- and medium-term outlook for our key end markets as well as our strong financial position. We have increased our investments to create incremental capacity, which includes both recently completed and newly announced facility expansions.  In the beginning of July, we acquired nine acres of property near our Houston headquarters location to help further facilitate the execution of our current backlog as well as planning for modest volume growth looking forward. Altogether, we continue to expect a favorable operating environment for Powell as we focus on successfully delivering the projects in backlog to our customers and advancing our strategy.”

[0000080420-24-000057:8k_2_02:25]
OUTLOOK

[0000080420-24-000057:8k_2_02:26]
Commenting on the Company's outlook, Michael Metcalf, Powell’s Chief Financial Officer, said, “Looking forward, we remain encouraged with where Powell is positioned as we enter the last quarter of fiscal 2024.  Commercial activity remains strong, providing a tailwind as we close out the year and prepare for fiscal 2025.  Operationally, we continue to make improvements necessary to execute our backlog, while also progressing our plans to thoughtfully expand our capabilities.  Notwithstanding the typical challenges associated with a projects-based business, based upon the quality of our backlog and our liquidity position, we believe that we are well-positioned to sustain our year-to-date financial performance through the fourth quarter, while providing a strong entry point as we look forward to fiscal 2025.”

[0000080420-24-000057:8k_2_02:27]
3

[0000080420-24-000057:8k_2_02:28]
CONFERENCE CALL

[0000080420-24-000057:8k_2_02:29]
Powell Industries has scheduled a conference call for Wednesday, July 31, 2024 at 11:00 a.m. Eastern time. To participate in the conference call, dial 1-833-953-2431 (domestic) or 1-412-317-5760 (international) at least 10 minutes before the call begins and ask for the Powell Industries conference call. A telephonic replay of the conference call will be available through August 7, 2024 and may be accessed by calling 1-877-344-7529 (domestic) or 1-412-317-0088 (international) and using passcode 5961423#.

[0000080420-24-000057:8k_2_02:30]
Investors, analysts and the general public will also have the opportunity to listen to the conference call over the Internet by visiting powellind.com. To listen to the live call on the web, please visit the website at least 15 minutes before the call begins to register, download and install any necessary audio software.  For those who cannot listen to the live webcast, an archive will be available shortly after the call and will remain available for approximately 90 days at powellind.com.

[0000080420-24-000057:8k_2_02:31]
About Powell Industries

[0000080420-24-000057:8k_2_02:32]
Powell Industries, Inc., headquartered in Houston, Texas, develops, designs, manufactures and services custom-engineered equipment and systems that distribute, control and monitor the flow of electrical energy and provide protection to motors, transformers and other electrically powered equipment.  Powell Industries, Inc. serves the oil and gas and petrochemical markets that include onshore and offshore production, hydrogen, carbon capture, liquefied natural gas (LNG) facilities and terminals, pipelines, refineries, and petrochemical plants.  Additional markets include electric utility, light rail traction power, and commercial and other industrial markets that include end markets such as data centers, mining and metals, and pulp and paper.   For more information, please visit powellind.com.

[0000080420-24-000057:8k_2_02:33]
5

[0000080420-24-000057:8k_2_02:34]
POWELL INDUSTRIES, INC. & SUBSIDIARIES

[0000080420-24-000057:8k_2_02:35]
CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS

[0000080420-24-000057:8k_2_02:36]
|  | Three Months Ended June 30, |  | Nine Months Ended June 30, |
|  | 2024 |  | 2023 |  | 2024 |  | 2023 |
| (In thousands, except per share data) |  |  |  |  |  |  |  |
|  | (Unaudited) |
| Revenues | $ | 288,168 |  |  | $ | 192,365 |  |  | $ | 737,293 |  |  | $ | 490,667 |  |
| Cost of goods sold | 206,428 |  |  | 149,695 |  |  | 544,639 |  |  | 395,096 |  |
| Gross profit | 81,740 |  | 42,670 |  | 192,654 |  | 95,571 |
| Selling, general and administrative expenses | 22,022 |  |  | 19,691 |  |  | 63,316 |  |  | 58,384 |  |
| Research and development expenses | 2,430 |  |  | 1,427 |  |  | 6,681 |  |  | 4,471 |  |
| Operating income | 57,288 |  | 21,552 |  | 122,657 |  | 32,716 |
| Interest income, net | (4,508) |  |  | (2,093) |  |  | (12,934) |  |  | (3,516) |  |
| Income before income taxes | 61,796 |  | 23,645 |  | 135,591 |  | 36,232 |
| Income tax provision | 15,573 |  |  | 5,191 |  |  | 31,795 |  |  | 8,142 |  |
| Net income | $ | 46,223 |  |  | $ | 18,454 |  |  | $ | 103,796 |  |  | $ | 28,090 |  |
| Earnings per share: |  |  |  |  |  |  |  |
| Basic | $ | 3.85 |  |  | $ | 1.55 |  |  | $ | 8.67 |  |  | $ | 2.37 |  |
| Diluted | $ | 3.79 |  |  | $ | 1.52 |  |  | $ | 8.52 |  |  | $ | 2.32 |  |
| Weighted average shares: |  |  |  |  |  |  |  |
| Basic | 11,998 |  |  | 11,889 |  |  | 11,977 |  |  | 11,876 |  |
| Diluted | 12,205 |  |  | 12,140 |  |  | 12,180 |  |  | 12,106 |  |
| SELECTED FINANCIAL DATA: |  |  |  |  |  |  |  |
| Depreciation | $ | 1,709 |  |  | $ | 2,188 |  |  | $ | 5,074 |  |  | $ | 6,500 |  |
| Capital Expenditures | $ | 1,389 |  |  | $ | 650 |  |  | $ | 3,527 |  |  | $ | 4,006 |  |
| Dividends Paid | $ | 3,176 |  |  | $ | 3,112 |  |  | $ | 9,475 |  |  | $ | 9,292 |  |

[0000080420-24-000057:8k_2_02:37]
6

[0000080420-24-000057:8k_2_02:38]
POWELL INDUSTRIES, INC. & SUBSIDIARIES

[0000080420-24-000057:8k_2_02:39]
CONDENSED CONSOLIDATED BALANCE SHEETS

[0000080420-24-000057:8k_2_02:40]
|  | June 30, 2024 |  | September 30, 2023 |
| (In thousands) |  |  |  |
|  | (Unaudited) |
| Assets: |  |  |  |
| Cash, cash equivalents and short-term investments | $ | 374,045 |  |  | $ | 279,009 |  |
| Other current assets | 361,649 |  |  | 342,976 |  |
| Property, plant and equipment, net | 96,468 |  |  | 97,625 |  |
| Long-term assets | 36,821 |  |  | 32,632 |  |
| Total assets | $ | 868,983 |  |  | $ | 752,242 |  |
| Liabilities and equity: |  |  |  |
| Current liabilities | $ | 418,435 |  |  | $ | 395,686 |  |
| Deferred and other long-term liabilities | 13,809 |  |  | 11,530 |  |
| Stockholders’ equity | 436,739 |  |  | 345,026 |  |
| Total liabilities and stockholders’ equity | $ | 868,983 |  |  | $ | 752,242 |  |
| SELECTED FINANCIAL DATA: |  |  |  |
| Working capital | $ | 317,259 |  |  | $ | 226,299 |  |
| (1) New orders (bookings) represent the estimated value of contracts added to existing backlog (unsatisfied performance obligations). |
| (2) The amounts recorded in backlog may not be a reliable indicator of our future operating results and may not be indicative of continuing revenue performance over future fiscal quarters or years primarily due to unexpected contract adjustments, cancellations or scope reductions. |
