# POWL MD&A — 0000080420-24-000059


## mdna

[0000080420-24-000059:mdna:1]
[same as prior period, unchanged from 0000080420-24-000030:mdna:1]

[0000080420-24-000059:mdna:2]
[same as prior period, unchanged from 0000080420-24-000030:mdna:2]

[0000080420-24-000059:mdna:3]
[same as prior period, unchanged from 0000080420-24-000030:mdna:3]

[0000080420-24-000059:mdna:4]
We develop, design, manufacture and service custom-engineered equipment and systems that distribute, control and monitor the flow of electrical energy and provide protection to motors, transformers and other electrically powered equipment. We are headquartered in Houston, Texas, and serve the oil and gas and petrochemical markets that include onshore and offshore production, hydrogen, carbon capture, liquefied natural gas (LNG) facilities and terminals, pipelines, refineries and petrochemical plants. Additional markets include electric utility, light rail traction power, and commercial and other industrial markets that include end markets such as data centers, mining and metals, and pulp and paper. Revenues and costs are primarily related to custom engineered-to-order equipment and systems and are accounted for under percentage-of-completion accounting, which precludes us from providing detailed price and volume information. Our backlog includes various projects that typically take a number of months to produce.

[0000080420-24-000059:mdna:5]
[same as prior period, unchanged from 0000080420-24-000030:mdna:5]

[0000080420-24-000059:mdna:6]
[same as prior period, unchanged from 0000080420-24-000030:mdna:6]

[0000080420-24-000059:mdna:7]
One element of our strategic focus is to strengthen our project portfolio beyond our core oil, gas and petrochemical end market sectors. Diversification efforts have resulted in growth in our backlog across the electric utility and commercial and other industrial sectors in Fiscal 2023 and continuing throughout the first nine months of Fiscal 2024. As of June 30, 2024, our backlog remained at $1.3 billion.

[0000080420-24-000059:mdna:8]
During the third fiscal quarter, we experienced commodity price volatility, in addition to the ongoing supply chain delays for specific engineered components that have been persistent throughout the first nine months of Fiscal 2024. We are working closely with our suppliers to meet our customer commitments. In response to the increased cost environment and supply chain challenges, we strive to effectively manage our product pricing, delivery schedules and bid validity dates with our customers, as well as improve factory efficiencies and project execution.

[0000080420-24-000059:mdna:9]
During the second week of July 2024, operations across our three facilities located in Houston, Texas, experienced a temporary power outage and subsequent shutdown of our operations resulting from Hurricane Beryl. These facilities resumed limited operations within the same week. We are evaluating the potential financial impact, if any, associated with this event.

[0000080420-24-000059:mdna:10]
[same as prior period, unchanged from 0000080420-24-000030:mdna:9]

[0000080420-24-000059:mdna:11]
Quarter Ended June 30, 2024 Compared to the Quarter Ended June 30, 2023 (Unaudited)

[0000080420-24-000059:mdna:12]
[same as prior period, unchanged from 0000080420-24-000030:mdna:11]

[0000080420-24-000059:mdna:13]
Revenues increased by 50%, or $95.8 million, to $288.2 million in the third quarter of Fiscal 2024, primarily driven by the increase in project backlog resulting from large contracts awarded in Fiscal 2023 and strong bookings throughout the first nine months of Fiscal 2024. Domestic revenues increased by 59%, or $90.5 million, to $243.7 million in the third quarter of Fiscal 2024. International revenues increased by 14%, or $5.3 million, to $44.4 million in the third quarter of Fiscal 2024. Our international revenues include both revenues generated from our international facilities as well as revenues from export projects generated at our domestic facilities.

[0000080420-24-000059:mdna:14]
In the third quarter of Fiscal 2024, revenue from our core oil and gas market (excluding petrochemical) increased by 56%, or $40.9 million, to $114.3 million; petrochemical market revenue increased by 158%, or $34.8 million, to $56.8 million; revenue from our electric utility market increased by 30%, or $13.2 million, to $57.0 million; commercial and other industrial market revenue increased by 18%, or $6.5 million, to $42.0 million; and revenue from all other markets combined increased by 22%, or $2.2 million, to $12.7 million. These increases in revenue were driven by improved market conditions and increased capital spending in our core oil, gas and petrochemical markets, as well as our strategic effort to diversify our business into electric utility and commercial and other industrial markets. Revenue from our light rail traction power market decreased by 25%, or $1.8 million, to $5.3 million in the third quarter of Fiscal 2024 due to less project volume in this market.

[0000080420-24-000059:mdna:15]
Gross profit increased by 92%, or $39.1 million, to $81.7 million for the third quarter of Fiscal 2024.  Gross profit as a percentage of revenues increased to 28% in the third quarter of Fiscal 2024, compared to 22% in the third quarter of Fiscal 2023. This increase in gross profit is attributable to the higher volume levels across all of Powell's manufacturing facilities generating favorable volume leverage, strong project execution, and continuing effort to improve factory efficiencies while also managing product pricing that corresponds to current cost levels.

[0000080420-24-000059:mdna:16]
[same as prior period, unchanged from 0000080420-24-000030:mdna:16]

[0000080420-24-000059:mdna:17]
Selling, general and administrative expenses increased by 12%, or $2.3 million, to $22.0 million in the third quarter of Fiscal 2024, primarily due to higher spending on infrastructure improvements. Selling, general and administrative expenses as a percentage of revenues decreased to 8% during the third quarter of Fiscal 2024 compared to 10% during the third quarter of Fiscal 2023, resulting from higher revenues on our existing cost structure.

[0000080420-24-000059:mdna:18]
[same as prior period, unchanged from 0000080420-24-000030:mdna:18]

[0000080420-24-000059:mdna:19]
We recorded an income tax provision of $15.6 million in the third quarter of Fiscal 2024, compared to an income tax provision of $5.2 million in the third quarter of Fiscal 2023. The effective tax rate for the third quarter of Fiscal 2024 was 25%, compared to an effective tax rate of 22% for the third quarter of Fiscal 2023. For each of the three months ended June 30, 2024 and 2023, the effective tax rate was favorably impacted by the estimated Research and Development Tax Credit (R&D Tax Credit). Additionally, in the third quarter of Fiscal 2023, we recognized a benefit related to the projected utilization of net operating loss carryforwards in the United Kingdom (the U.K.) that had been fully reserved with a valuation allowance. For each of the three months ended June 30, 2024 and 2023, these benefits were offset by an income inclusion related to U.S. global intangible income and certain nondeductible expenses.

[0000080420-24-000059:mdna:20]
[same as prior period, unchanged from 0000080420-24-000030:mdna:20]

[0000080420-24-000059:mdna:21]
In the third quarter of Fiscal 2024, we recorded net income of $46.2 million, or $3.79 per diluted share, compared to net income of $18.5 million, or $1.52 per diluted share, in the third quarter of Fiscal 2023. This increase in net income was primarily due to the strength and quality of our backlog at the end of Fiscal 2023, as well as strong bookings throughout the first nine months of Fiscal 2024, which has led to an increase in revenue coupled with improved project margins.

[0000080420-24-000059:mdna:22]
[same as prior period, unchanged from 0000080420-24-000030:mdna:22]

[0000080420-24-000059:mdna:23]
The order backlog, which is our remaining unsatisfied performance obligations, represents the estimated transaction price for goods and services for which we have a material right, but work has not been performed. The order backlog at June 30, 2024 was $1.3 billion, consistent with our backlog at both March 31, 2024 and June 30, 2023. Bookings, net of cancellations and scope reductions, decreased by 30% in the third quarter of Fiscal 2024 to $356.3 million, compared to $505.4 million in the third quarter of Fiscal 2023. Despite strong bookings in the third quarter of Fiscal 2024, the decrease in bookings was due to a normalization of the oil and gas sector, with fewer large orders awarded in this sector during Fiscal 2024.

[0000080420-24-000059:mdna:24]
Nine Months Ended June 30, 2024 Compared to Nine Months Ended June 30, 2023 (Unaudited)

[0000080420-24-000059:mdna:25]
[same as prior period, unchanged from 0000080420-24-000030:mdna:25]

[0000080420-24-000059:mdna:26]
Revenues increased by 50%, or $246.6 million, to $737.3 million in the nine months ended June 30, 2024, primarily driven by the increase in project backlog resulting from large contracts awarded throughout Fiscal 2023 and strong bookings throughout the first nine months of Fiscal 2024. Domestic revenues increased by 60%, or $233.0 million, to $620.5 million in the nine months ended June 30, 2024. International revenues increased by 13%, or $13.6 million, to $116.8 million in the nine months ended June 30, 2024. Our international revenues include both revenues generated from our international facilities as well as revenues from export projects generated at our domestic facilities.

[0000080420-24-000059:mdna:27]
In the nine months ended June 30, 2024, revenue from our core oil and gas market (excluding petrochemical) increased by 68%, or $122.2 million, to $301.8 million; petrochemical market revenue increased by 92%, or $64.9 million, to $135.2 million; revenue from our electric utility market increased by 26%, or $30.3 million, to $145.2 million; commercial and other industrial market revenue increased by 36%, or $26.8 million, to $101.6 million; and revenue from all other markets combined increased by 33%, or $9.8 million, to $39.3 million. These increases in revenue were driven by improved market conditions and increased capital spending in our core oil, gas and petrochemical markets, as well as our strategic effort to diversify our business into electric utility and commercial and other industrial markets. Revenue from our light rail traction power market decreased by 34%, or $7.3 million, to $14.2 million in the first nine months of Fiscal 2024 due to less project volume in this market.

[0000080420-24-000059:mdna:28]
Gross profit increased by 102%, or $97.1 million, to $192.7 million for the first nine months of Fiscal 2024. Gross profit as a percentage of revenues increased to 26% in the first nine months of Fiscal 2024, compared to 19% in the first nine months of Fiscal 2023. This increase in gross profit is attributable to the higher volume levels across all of Powell's manufacturing facilities generating favorable volume leverage, strong project execution, and continuing effort to improve factory efficiencies while also managing product pricing that corresponds to current cost levels.

[0000080420-24-000059:mdna:29]
[same as prior period, unchanged from 0000080420-24-000030:mdna:29]

[0000080420-24-000059:mdna:30]
Selling, general and administrative expenses increased by 8%, or $4.9 million, to $63.3 million for the nine months ended June 30, 2024, primarily due to increased compensation expense and higher spending on infrastructure improvements. Selling, general and administrative expenses as a percentage of revenues decreased to 9% during the first nine months of Fiscal 2024 compared to 12% during the first nine months of Fiscal 2023, resulting from higher revenues on our existing cost structure.

[0000080420-24-000059:mdna:31]
[same as prior period, unchanged from 0000080420-24-000030:mdna:31]

[0000080420-24-000059:mdna:32]
We recorded an income tax provision of $31.8 million for the nine months ended June 30, 2024, compared to an income tax provision of $8.1 million for the nine months ended June 30, 2023. The effective tax rate for the nine months ended June 30, 2024 was 23%, compared to an effective tax rate of 22% for the nine months ended June 30, 2023. For each of the nine months ended June 30, 2024 and 2023, the effective tax rate was favorably impacted by the estimated R&D Tax Credit. Additionally, in the nine months ended June 30, 2024, we recognized benefits for discrete items primarily related to the vesting of restricted stock units. In the nine months ended June 30, 2023, we recognized a benefit related to the projected utilization of net operating loss carryforwards in the U.K. that had been fully reserved with a valuation allowance. In both periods, these benefits were offset by an income inclusion related to U.S. global intangible income and certain nondeductible expenses.

[0000080420-24-000059:mdna:33]
[same as prior period, unchanged from 0000080420-24-000030:mdna:33]

[0000080420-24-000059:mdna:34]
In the nine months ended June 30, 2024, we recorded net income of $103.8 million, or $8.52 per diluted share, compared to net income of $28.1 million, or $2.32 per diluted share, in the nine months ended June 30, 2023. This increase in net income was primarily due to the strength and quality of our backlog at the end of Fiscal 2023, as well as strong bookings throughout the first nine months of Fiscal 2024, which has led to an increase in revenue coupled with improved project margins.

[0000080420-24-000059:mdna:35]
[same as prior period, unchanged from 0000080420-24-000030:mdna:35]

[0000080420-24-000059:mdna:36]
The order backlog, which is our remaining unsatisfied performance obligations, represents the estimated transaction price for goods and services for which we have a material right, but work has not been performed. The order backlog at June 30, 2024 was $1.3 billion, consistent with our backlog at September 30, 2023. Bookings, net of cancellations and scope reductions, decreased by 36% during the nine months ended June 30, 2024 to $789.2 million, compared to $1.2 billion during the nine months ended June 30, 2023. Despite strong bookings in the first nine months of Fiscal 2024, the decrease in bookings was due to a normalization of the oil and gas sector with fewer large orders awarded in this sector during Fiscal 2024.

[0000080420-24-000059:mdna:37]
[same as prior period, unchanged from 0000080420-24-000030:mdna:37]

[0000080420-24-000059:mdna:38]
Our order activity in most of our core markets remains active and diversification efforts outside of our core oil, gas and petrochemical markets continue to be a positive catalyst. We believe the fundamentals of the U.S. natural gas market, through abundant supply and low cost, will continue to support investments in LNG, related gas processing, and petrochemical processes. We continue to monitor the Biden administration's efforts to pause or limit LNG exports, which may impact the timing of future project activity. We have achieved strong bookings in electric utility and commercial markets through the first nine months of Fiscal 2024 in the U.S., Canada and the U.K., largely driven by the markets where our operations are based. Our backlog remained at $1.3 billion as of June 30, 2024, of which approximately $841 million is expected to be recognized as revenue within the next twelve months. Although current commercial activity remains active in most of the sectors that we compete in, we remain attentive to the macro environment and geopolitical events that may have an impact on future market activity.

[0000080420-24-000059:mdna:39]
[same as prior period, unchanged from 0000080420-24-000030:mdna:39]

[0000080420-24-000059:mdna:40]
We have planned capital spending of approximately $11 million on a facility expansion project at our products factory in Houston. We expect to complete the expansion project by mid-Fiscal 2025. Additionally, on July 1, 2024, we acquired land and buildings in Houston, Texas, for $5.5 million to help further facilitate executing the current backlog as well as planning for modest future volume growth.

[0000080420-24-000059:mdna:41]
[same as prior period, unchanged from 0000080420-24-000030:mdna:41]

[0000080420-24-000059:mdna:42]
As of June 30, 2024, current assets exceeded current liabilities by 1.8 times.

[0000080420-24-000059:mdna:43]
Cash, cash equivalents and short-term investments increased to $374.0 million at June 30, 2024, compared to $279.0 million at September 30, 2023. This increase in cash, cash equivalents and short-term investments was primarily driven by our improved earnings due to increased project margins and volumes, as well as favorable timing of contract billing milestones on many of our large projects. We typically allocate a significant percentage of the progress billing to the early stages of the contract. We believe that our cash, cash equivalents and short-term investments, as well as available borrowings under the U.S. Revolver, will be sufficient to support our future operating activities, working capital requirements, payment of dividends and capital spending, as well as research and development initiatives for the next twelve months and beyond.

[0000080420-24-000059:mdna:44]
On October 4, 2023, we entered into the Third Amendment to the U.S. Revolver. The Third Amendment added Texas Capital Bank as Syndication Agent and a lender, increased the amount of the revolving line of credit from $125.0 million to $150.0 million, and extended the expiry date to October 4, 2028. The aggregate commitment of $150.0 million consists of $100.0 million committed by Bank of America and $50.0 million committed by Texas Capital Bank. As amended by the Third Amendment, the lesser of (a) $60 million, (b) 60% of available cash, and (c) the aggregate face amount of the issued but undrawn letters of credit that are not cash-secured, shall be deducted from consolidated funded indebtedness, when calculating the consolidated net leverage ratio. We have the option to cash collateralize all or a portion of the letters of credit outstanding, which would favorably impact the consolidated funded indebtedness calculation and the consolidated net leverage ratio. On

[0000080420-24-000059:mdna:45]
June 26, 2024, in connection with the expected discontinuation of the publication of the Canadian Dollar Offered Rate (CDOR), we further amended the U.S. Revolver by entering into a Canadian benchmark replacement conforming changes amendment with Bank of America, N.A. that added and amended certain terms related to the replacement of the CDOR as a benchmark rate with the forward-looking term rate based on the Canadian Overnight Repo Rate Average.

[0000080420-24-000059:mdna:46]
As of June 30, 2024, there were no amounts borrowed under the U.S. Revolver, and letters of credit outstanding were $68.4 million. There was $81.6 million available for the issuance of letters of credit and borrowings under the U.S. Revolver as of June 30, 2024. For further information regarding our debt, see Notes E and F of Notes to Condensed Consolidated Financial Statements.

[0000080420-24-000059:mdna:47]
Approximately $76.1 million of our cash, cash equivalents and short-term investments at June 30, 2024 was held outside of the U.S. for our international operations. It is our intention to indefinitely reinvest all current and future foreign earnings internationally in order to ensure sufficient working capital to support our international operations. In the event that we elect to repatriate some or all of the foreign earnings that were previously deemed to be indefinitely reinvested outside the U.S., we may incur additional tax expense upon such repatriation under current tax laws.

[0000080420-24-000059:mdna:48]
[same as prior period, unchanged from 0000080420-24-000030:mdna:47]

[0000080420-24-000059:mdna:49]
Operating activities provided net cash of $114.7 million during the nine months ended June 30, 2024 and provided net cash of $105.3 million during the same period in Fiscal 2023. Cash flow from operations is primarily influenced by project volume and margins, as well as the associated working capital requirements, the timing of milestone payments from our customers, and payment terms with our suppliers. This increase in operating cash flow was primarily due to higher net income resulting from increased project volume and improved project margins, partially offset by working capital impact as we allocate capital to the projects in the order book.

[0000080420-24-000059:mdna:50]
[same as prior period, unchanged from 0000080420-24-000030:mdna:49]

[0000080420-24-000059:mdna:51]
Investing activities used $13.0 million during the nine months ended June 30, 2024 and used $15.4 million during the same period in Fiscal 2023. The decrease in cash used in investing activities was primarily due to net purchases of short-term investments of $9.2 million in the first nine months of Fiscal 2024 compared to net purchases of short-term investments of $11.4 million in the same period of Fiscal 2023. In December 2023, we acquired intellectual property for a total consideration of $0.5 million, of which $250 thousand was paid in cash.

[0000080420-24-000059:mdna:52]
[same as prior period, unchanged from 0000080420-24-000030:mdna:51]

[0000080420-24-000059:mdna:53]
Net cash used in financing activities was $16.0 million during the nine months ended June 30, 2024 and $9.9 million during the same period in Fiscal 2023. The increase in cash used in financing activities was primarily due to cash payments related to shares withheld in lieu of employee tax withholding, largely driven by the significant increase in our share price in the first nine months of Fiscal 2024 compared to the same period of Fiscal 2023.

[0000080420-24-000059:mdna:54]
[same as prior period, unchanged from 0000080420-24-000030:mdna:53]

[0000080420-24-000059:mdna:55]
[same as prior period, unchanged from 0000080420-24-000030:mdna:54]

[0000080420-24-000059:mdna:56]
[same as prior period, unchanged from 0000080420-24-000030:mdna:55]
