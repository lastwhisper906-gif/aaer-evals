# POWL notes — 0000080420-24-000059


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureAndSignificantAccountingPoliciesTextBlock

[0000080420-24-000059:notes:1]
[same as prior period, unchanged from 0000080420-24-000030:notes:1]

[0000080420-24-000059:notes:2]
[same as prior period, unchanged from 0000080420-24-000030:notes:2]

[0000080420-24-000059:notes:3]
We develop, design, manufacture and service custom-engineered equipment and systems that distribute, control and monitor the flow of electrical energy and provide protection to motors, transformers and other electrically powered equipment. We are headquartered in Houston, Texas, and serve the oil and gas and petrochemical markets that include onshore and offshore production, hydrogen, carbon capture, liquefied natural gas (LNG) facilities and terminals, pipelines, refineries and petrochemical plants. Additional markets include electric utility, light rail traction power, and commercial and other industrial markets that include end markets such as data centers, mining and metals, and pulp and paper.

[0000080420-24-000059:notes:4]
[same as prior period, unchanged from 0000080420-24-000030:notes:4]

[0000080420-24-000059:notes:5]
[same as prior period, unchanged from 0000080420-24-000030:notes:5]

[0000080420-24-000059:notes:6]
[same as prior period, unchanged from 0000080420-24-000030:notes:6]

[0000080420-24-000059:notes:7]
[same as prior period, unchanged from 0000080420-24-000030:notes:7]

[0000080420-24-000059:notes:8]
[same as prior period, unchanged from 0000080420-24-000030:notes:8]

[0000080420-24-000059:notes:9]
[same as prior period, unchanged from 0000080420-24-000030:notes:9]

[0000080420-24-000059:notes:10]
[same as prior period, unchanged from 0000080420-24-000030:notes:10]

[0000080420-24-000059:notes:11]
[same as prior period, unchanged from 0000080420-24-000030:notes:11]

[0000080420-24-000059:notes:12]
In November 2023, the Financial Accounting Standard Board (FASB) issued Accounting Standards Update (ASU) 2023-07,

[0000080420-24-000059:notes:13]
Segment Reporting (Topic 280): Improvements to Reportable Segment Disclosures, which requires that public entities disclose significant segment expenses that are regularly provided to the chief operating decision maker (CODM) on an annual and interim basis. It also requires that public entities disclose the title and position of the CODM and an explanation of how the CODM uses the reported measures in assessing segment performance and resource allocation. Additionally, it requires that all existing annual disclosures about segment profit or loss and assets must be provided on an interim basis and clarifies that single reportable segment entities are subject to the disclosure requirement under Topic 280 in its entirety. ASU 2023-07 is effective for fiscal years beginning after December 15, 2023 and interim periods within those fiscal years beginning after December 15, 2024. A public entity should apply ASU 2023-07 retrospectively to all prior periods presented in the financial statements. Early adoption is permitted. We are currently evaluating the impacts of the new standard.

[0000080420-24-000059:notes:14]
In December 2023, the FASB issued ASU 2023-09, Improvements to Income Tax Disclosures, which enhances the transparency of income tax disclosures. It requires greater disaggregation of information in the tax rate reconciliation and income taxes paid disaggregated by jurisdiction. This ASU is effective for fiscal years beginning after December 15, 2024, and should be applied on a prospective basis. Retrospective application and early adoption are permitted. We are currently evaluating the impacts of the new standard.
In March 2024, the SEC adopted final rules designed to enhance and standardize disclosures related to the risks and impacts of climate-related matters. The final rules require registrants to disclose certain climate-related information in registration statements and annual reports. Such information relates to climate-related risks and risk management processes for, and governance and oversight activities of such risks. The final rules also include requirements to disclose the financial effects of severe weather events and other natural conditions in the audited financial statements. In addition, larger registrants will be required to disclose information about greenhouse gas emissions, which will be subject to a phased-in assurance requirement. These disclosure requirements will be effective for the Company's fiscal year beginning October 1, 2025. In April 2024, the SEC voluntarily stayed the final rules as a result of pending legal challenges. We are currently evaluating the impacts of the final rules on our consolidated financial statements and related disclosures.


## us-gaap:EarningsPerShareTextBlock

[0000080420-24-000059:notes:15]
[same as prior period, unchanged from 0000080420-24-000030:notes:15]

[0000080420-24-000059:notes:16]
[same as prior period, unchanged from 0000080420-24-000030:notes:16]

[0000080420-24-000059:notes:17]
|  | Three months ended June 30, |  | Nine months ended June 30, |
|  | 2024 |  | 2023 |  | 2024 |  | 2023 |
| Numerator: |  |  |  |  |  |  |  |
| Net income | $ | 46,223 |  |  | $ | 18,454 |  |  | $ | 103,796 |  |  | $ | 28,090 |  |
| Denominator: |  |  |  |  |  |  |  |
| Weighted average basic shares | 11,998 |  |  | 11,889 |  |  | 11,977 |  |  | 11,876 |  |
| Dilutive effect of restricted stock and restricted stock units | 207 |  |  | 251 |  |  | 203 |  |  | 230 |  |
| Weighted average diluted shares | 12,205 |  |  | 12,140 |  |  | 12,180 |  |  | 12,106 |  |
| Earnings per share: |  |  |  |  |  |  |  |
| Basic | $ | 3.85 |  |  | $ | 1.55 |  |  | $ | 8.67 |  |  | $ | 2.37 |  |
| Diluted | $ | 3.79 |  |  | $ | 1.52 |  |  | $ | 8.52 |  |  | $ | 2.32 |  |


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0000080420-24-000059:notes:18]
[same as prior period, unchanged from 0000080420-24-000030:notes:18]

[0000080420-24-000059:notes:19]
[same as prior period, unchanged from 0000080420-24-000030:notes:19]

[0000080420-24-000059:notes:20]
|  | June 30, 2024 |  | September 30, 2023 |
| Raw materials, parts and sub-assemblies | $ | 90,839 |  |  | $ | 68,631 |  |
| Work-in-progress | 1,362 |  |  | 1,379 |  |
| Provision for excess and obsolete inventories | (7,062) |  |  | (6,145) |  |
| Total inventories | $ | 85,139 |  |  | $ | 63,865 |  |

[0000080420-24-000059:notes:21]
[same as prior period, unchanged from 0000080420-24-000030:notes:21]

[0000080420-24-000059:notes:22]
[same as prior period, unchanged from 0000080420-24-000030:notes:22]

[0000080420-24-000059:notes:23]
|  | June 30, 2024 |  | September 30, 2023 |  |  |  |  |
| Land | $ | 21,563 |  |  | $ | 21,526 |  |  |  |  |  |
| Buildings and improvements | 123,687 |  |  | 121,454 |  |  |  |  |  |
| Machinery and equipment | 95,064 |  |  | 92,477 |  |  |  |  |  |
| Furniture and fixtures | 3,795 |  |  | 3,726 |  |  |  |  |  |
| Construction in process | 2,427 |  |  | 4,129 |  |  |  |  |  |
|  | $ | 246,536 |  |  | $ | 243,312 |  |  |  |  |  |
| Less: Accumulated depreciation | (150,068) |  |  | (145,687) |  |  |  |  |  |
| Total property, plant and equipment, net | $ | 96,468 |  |  | $ | 97,625 |  |  |  |  |  |

[0000080420-24-000059:notes:24]
There were no assets under finance lease as of June 30, 2024 or September 30, 2023.

[0000080420-24-000059:notes:25]
[same as prior period, unchanged from 0000080420-24-000030:notes:25]

[0000080420-24-000059:notes:26]
[same as prior period, unchanged from 0000080420-24-000030:notes:26]

[0000080420-24-000059:notes:27]
[same as prior period, unchanged from 0000080420-24-000030:notes:27]

[0000080420-24-000059:notes:28]
[same as prior period, unchanged from 0000080420-24-000030:notes:28]

[0000080420-24-000059:notes:29]
|  | Three months ended June 30, |  | Nine months ended June 30, |
|  | 2024 |  | 2023 |  | 2024 |  | 2023 |
| Balance at beginning of period | $ | 4,568 |  |  | $ | 2,711 |  |  | $ | 3,305 |  |  | $ | 2,345 |  |
| Increase to warranty expense | 2,077 |  |  | 1,241 |  |  | 5,071 |  |  | 2,931 |  |
| Deduction for warranty charges | (1,412) |  |  | (760) |  |  | (3,154) |  |  | (2,095) |  |
| Change due to foreign currency translation | (7) |  |  | 10 |  |  | 4 |  |  | 21 |  |
| Balance at end of period | $ | 5,226 |  |  | $ | 3,202 |  |  | $ | 5,226 |  |  | $ | 3,202 |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0000080420-24-000059:notes:30]
[same as prior period, unchanged from 0000080420-24-000030:notes:30]

[0000080420-24-000059:notes:31]
[same as prior period, unchanged from 0000080420-24-000030:notes:31]

[0000080420-24-000059:notes:32]
[same as prior period, unchanged from 0000080420-24-000030:notes:32]

[0000080420-24-000059:notes:33]
We also have contracts to provide field service inspection, installation, commissioning, modification, and repair services, as well as retrofit and retrofill components for existing systems. If the service contract terms give us the right to invoice the customer for an amount that corresponds directly with the value of our performance completed to date (i.e., a service contract in which we bill a fixed amount for each hour of service provided), then we recognize revenue over time in each reporting period corresponding to the amount that we have the right to invoice. Our performance obligations are satisfied as the work progresses. Revenues from our custom-engineered products and value-added services transferred to customers over time accounted for approximately 96% and 95% of revenues for the three and nine months ended June 30, 2024, respectively, and approximately 94% and 93% of revenues for the three and nine months ended June 30, 2023, respectively.

[0000080420-24-000059:notes:34]
We also have sales orders for spare parts and replacement circuit breakers for switchgear that are obsolete or that are no longer produced by the original manufacturer. Revenues from these sales orders are recognized at the time we fulfill our performance obligation to the customer, which is typically upon shipment and represented approximately 4% and 5% of revenues for the three and nine months ended June 30, 2024, respectively, and approximately 6% and 7% of revenues for the three and nine months ended June 30, 2023, respectively.

[0000080420-24-000059:notes:35]
[same as prior period, unchanged from 0000080420-24-000030:notes:35]

[0000080420-24-000059:notes:36]
[same as prior period, unchanged from 0000080420-24-000030:notes:36]

[0000080420-24-000059:notes:37]
[same as prior period, unchanged from 0000080420-24-000030:notes:37]

[0000080420-24-000059:notes:38]
[same as prior period, unchanged from 0000080420-24-000030:notes:38]

[0000080420-24-000059:notes:39]
Remaining unsatisfied performance obligations, which we refer to as backlog, represent the estimated transaction price for goods and services for which we have a material right, but work has not been performed. As of June 30, 2024, we had backlog of $1.3 billion, of which approximately $841 million is expected to be recognized as revenue within the next twelve months.

[0000080420-24-000059:notes:40]
Backlog may not be indicative of future operating results as orders may be cancelled or modified by our customers. Our backlog does not include service and maintenance-type contracts for which we have the right to invoice as services are performed.

[0000080420-24-000059:notes:41]
[same as prior period, unchanged from 0000080420-24-000030:notes:41]

[0000080420-24-000059:notes:42]
[same as prior period, unchanged from 0000080420-24-000030:notes:42]

[0000080420-24-000059:notes:43]
For the nine months ended June 30, 2024 and 2023, our operating results were positively impacted by $14.2 million and $13.2 million, respectively, as a result of net changes in contract estimates related to projects in progress at the beginning of the respective period. These changes in estimates resulted primarily from favorable project execution, reduced cost estimates and negotiations of variable consideration, discussed below, as well as revenue recognized from project cancellations and other changes in facts and circumstances during these periods. Project cancellations on two projects increased gross profit for the nine months ended June 30, 2023 by $3.4 million. Gross unfavorable changes in contract estimates were immaterial for both the nine months ended June 30, 2024 and 2023.

[0000080420-24-000059:notes:44]
[same as prior period, unchanged from 0000080420-24-000030:notes:44]

[0000080420-24-000059:notes:45]
[same as prior period, unchanged from 0000080420-24-000030:notes:45]

[0000080420-24-000059:notes:46]
[same as prior period, unchanged from 0000080420-24-000030:notes:46]

[0000080420-24-000059:notes:47]
[same as prior period, unchanged from 0000080420-24-000030:notes:47]

[0000080420-24-000059:notes:48]
[same as prior period, unchanged from 0000080420-24-000030:notes:48]

[0000080420-24-000059:notes:49]
[same as prior period, unchanged from 0000080420-24-000030:notes:49]

[0000080420-24-000059:notes:50]
[same as prior period, unchanged from 0000080420-24-000030:notes:50]

[0000080420-24-000059:notes:51]
Contract liabilities typically represent advance payments from contractual billing milestones and billings in excess of revenue recognized. It is unusual to have advanced milestone payments with a term greater than one year, which could represent a financing component of the contract.

[0000080420-24-000059:notes:52]
[same as prior period, unchanged from 0000080420-24-000030:notes:52]

[0000080420-24-000059:notes:53]
Contract assets and liabilities as of June 30, 2024 and September 30, 2023 are summarized below (in thousands):

[0000080420-24-000059:notes:54]
|  | June 30, 2024 |  | September 30, 2023 |
| Contract assets | $ | 90,955 |  |  | $ | 60,621 |  |
| Contract liabilities | (282,924) |  |  | (279,796) |  |
| Net contract liability | $ | (191,969) |  |  | $ | (219,175) |  |

[0000080420-24-000059:notes:55]
Our net contract billing position remained a net liability at both June 30, 2024 and September 30, 2023, primarily due to favorable contract billing milestones. We typically allocate a significant percentage of the progress billing to the early stages of the contract. To determine the amount of revenue recognized during the period from contract liabilities, we first allocate revenue to the individual contract liability balance outstanding at the beginning of the period until the revenue exceeds that balance. During the nine months ended June 30, 2024, we recognized revenue of $228.9 million that was related to contract liabilities outstanding at September 30, 2023.

[0000080420-24-000059:notes:56]
The timing of our invoice process is typically dependent on the completion of certain milestones and contract terms and subject to agreement by our customer. Payment is typically expected within 30 days of invoice. Any uncollected invoiced amounts for our performance obligations recognized over time, including contract retentions, are recorded as accounts receivable in the Condensed Consolidated Balance Sheets. Certain contracts allow customers to withhold a small percentage of billings pursuant to retainage provisions, and such amounts are generally due upon completion of the contract and acceptance of the project by the customer. Based on our experience in recent years, the majority of these retainage balances are expected to be collected within approximately twelve months. As of June 30, 2024 and September 30, 2023, we had retention amounts of $6.6 million and $7.4 million, respectively. Of the retained amount at June 30, 2024, $5.9 million is expected to be collected in the next twelve months and is recorded in accounts receivable. The remaining $0.7 million is recorded in other assets.

[0000080420-24-000059:notes:57]
[same as prior period, unchanged from 0000080420-24-000030:notes:57]

[0000080420-24-000059:notes:58]
The following tables present our disaggregated revenue by geographic destination and market sector for the three and nine months ended June 30, 2024 and 2023 (in thousands):

[0000080420-24-000059:notes:59]
|  | Three months ended June 30, |  | Nine months ended June 30, |
|  | 2024 |  | 2023 |  | 2024 |  | 2023 |
| United States | $ | 243,744 |  |  | $ | 153,258 |  |  | $ | 620,537 |  |  | $ | 387,531 |  |
| Canada | 29,695 |  |  | 21,765 |  |  | 74,205 |  |  | 62,255 |  |
| Europe | 9,464 |  |  | 8,038 |  |  | 24,261 |  |  | 20,125 |  |
| Middle East and Africa | 2,322 |  |  | 3,966 |  |  | 8,400 |  |  | 10,396 |  |
| Mexico, Central and South America | 1,962 |  |  | 3,000 |  |  | 6,778 |  |  | 5,457 |  |
| Asia/Pacific | 981 |  |  | 2,338 |  |  | 3,112 |  |  | 4,903 |  |
| Total revenues by geographic destination | $ | 288,168 |  |  | $ | 192,365 |  |  | $ | 737,293 |  |  | $ | 490,667 |  |

[0000080420-24-000059:notes:60]
|  | Three months ended June 30, |  | Nine months ended June 30, |
|  | 2024 |  | 2023 |  | 2024 |  | 2023 |
| Oil and gas (excludes petrochemical) | $ | 114,336 |  |  | $ | 73,452 |  |  | $ | 301,792 |  |  | $ | 179,560 |  |
| Petrochemical | 56,784 |  |  | 21,995 |  |  | 135,221 |  |  | 70,372 |  |
| Electric utility | 57,009 |  |  | 43,824 |  |  | 145,214 |  |  | 114,899 |  |
| Commercial and other industrial | 42,044 |  |  | 35,527 |  |  | 101,610 |  |  | 74,846 |  |
| Light rail traction power | 5,322 |  |  | 7,143 |  |  | 14,184 |  |  | 21,532 |  |
| All others | 12,673 |  |  | 10,424 |  |  | 39,272 |  |  | 29,458 |  |
| Total revenues by market sector | $ | 288,168 |  |  | $ | 192,365 |  |  | $ | 737,293 |  |  | $ | 490,667 |  |


## us-gaap:RevenueFromContractWithCustomerPolicyTextBlock

[0000080420-24-000059:notes:61]
[same as prior period, unchanged from 0000080420-24-000030:notes:61]

[0000080420-24-000059:notes:62]
[same as prior period, unchanged from 0000080420-24-000030:notes:62]

[0000080420-24-000059:notes:63]
[same as prior period, unchanged from 0000080420-24-000030:notes:63]

[0000080420-24-000059:notes:64]
Contract liabilities typically represent advance payments from contractual billing milestones and billings in excess of revenue recognized. It is unusual to have advanced milestone payments with a term greater than one year, which could represent a financing component of the contract.  
Our contract assets and liabilities are reported in a net position on a contract-by-contract basis at the end of each reporting period and are generally classified as current.The timing of our invoice process is typically dependent on the completion of certain milestones and contract terms and subject to agreement by our customer. Payment is typically expected within 30 days of invoice. Any uncollected invoiced amounts for our performance obligations recognized over time, including contract retentions, are recorded as accounts receivable in the Condensed Consolidated Balance Sheets. Certain contracts allow customers to withhold a small percentage of billings pursuant to retainage provisions, and such amounts are generally due upon completion of the contract and acceptance of the project by the customer. Based on our experience in recent years, the majority of these retainage balances are expected to be collected within approximately twelve months.


## us-gaap:LongTermDebtTextBlock

[0000080420-24-000059:notes:65]
Long-Term Debt
U.S. Revolver

[0000080420-24-000059:notes:66]
On October 4, 2023, we entered into a third amendment (the Third Amendment) to our credit agreement with Bank of America, N.A. (as amended, the U.S. Revolver). The Third Amendment added Texas Capital Bank as Syndication Agent and a lender, increased the amount of the revolving line of credit from $125.0 million to $150.0 million, and extended the expiry date to October 4, 2028. The aggregate commitment of $150.0 million consists of $100.0 million committed by Bank of America and $50.0 million committed by Texas Capital Bank. As amended by the Third Amendment, the lesser of (a) $60 million, (b) 60% of available cash, and (c) the aggregate face amount of the issued but undrawn letters of credit that are not cash-secured, shall be deducted from consolidated funded indebtedness, when calculating the consolidated net leverage ratio. We have the option to cash collateralize all or a portion of the letters of credit outstanding, which would favorably impact the consolidated funded indebtedness calculation and the consolidated net leverage ratio. On June 26, 2024, in connection with the expected discontinuation of the publication of the Canadian Dollar Offered Rate (CDOR), we further amended the U.S. Revolver by entering into a Canadian benchmark replacement conforming changes amendment with Bank of America, N.A. that added and amended certain terms related to the replacement of the CDOR as a benchmark rate with the forward-looking term rate based on the Canadian Overnight Repo Rate Average.

[0000080420-24-000059:notes:67]
As of June 30, 2024, there were no amounts borrowed under the U.S. Revolver, and letters of credit outstanding were $68.4 million. There was $81.6 million available for the issuance of letters of credit and borrowings under the U.S. Revolver as of June 30, 2024.

[0000080420-24-000059:notes:68]
As of June 30, 2024, we were in compliance with all of the financial covenants of the U.S. Revolver.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0000080420-24-000059:notes:69]
Commitments and Contingencies
Letters of Credit, Bank Guarantees and Bonds

[0000080420-24-000059:notes:70]
Certain customers require us to post letters of credit, bank guarantees or surety bonds. These security instruments assure that we will perform under the terms of our contract. In the event of default, the counterparty may demand payment from the bank under a letter of credit or bank guarantee, or performance by the surety under a bond. To date, there have been no significant draws or claims related to security instruments for the periods reported. We were contingently liable for letters of credit of $68.4 million as of June 30, 2024. We also had surety bonds totaling $422.1 million that were outstanding, with additional bonding capacity of $777.9 million available, at June 30, 2024. We have strong surety relationships; however, a change in market conditions or the sureties' assessment of our financial position could cause the sureties to require cash collateralization for undischarged liabilities under the bonds.

[0000080420-24-000059:notes:71]
We have a $19.0 million facility agreement (Facility Agreement) between Powell (UK) Limited and a large international bank that provides Powell (UK) Limited the ability to enter into bank guarantees as well as forward exchange contracts and currency options. At June 30, 2024, we had outstanding guarantees totaling $6.4 million, with an additional capacity of $12.6 million available under this Facility Agreement. The Facility Agreement provides for customary events of default and carries cross-default provisions with the U.S. Revolver. If an event of default (as defined in the Facility Agreement) occurs and is continuing, per the terms and subject to the conditions set forth therein, obligations outstanding under the Facility Agreement may be accelerated and declared immediately due and payable. Additionally, we are required to maintain cash collateral for guarantees greater than two years. As of June 30, 2024, we were in compliance with all of the financial covenants of the Facility Agreement.

[0000080420-24-000059:notes:72]
Litigation

[0000080420-24-000059:notes:73]
We are involved in various legal proceedings, claims and other disputes arising from our commercial operations, projects, employees and other matters which, in general, are subject to uncertainties and for which the outcomes are not predictable. Although we can give no assurances about the resolution of pending claims, litigation or other disputes, and the effect such outcomes may have on us, management believes that any ultimate liability resulting from the outcome of such proceedings, to the extent not otherwise provided or covered by insurance, will not have a material adverse effect on our consolidated financial position or results of operations or liquidity.

[0000080420-24-000059:notes:74]
Liquidated Damages

[0000080420-24-000059:notes:75]
Certain of our customer contracts have schedule and performance obligation clauses that, if we fail to meet them, could require us to pay liquidated damages. Each individual contract defines the conditions under which the customer may make a claim against us. As of June 30, 2024, certain contracts had a probable exposure to liquidated damages claims of $2.5 million, which

[0000080420-24-000059:notes:76]
could possibly increase to $2.8 million under certain circumstances. Based on our actual or projected failure to meet these various contractual commitments, $1.7 million has been recorded as a reduction to revenue. We will attempt to obtain change orders, contract extensions or accelerate project completion, which may resolve the potential for any unrecorded liquidated damages claims. Should we fail to achieve relief on some or all of these contractual obligations, we could be required to pay additional liquidated damages, which could negatively impact our future operating results.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0000080420-24-000059:notes:77]
[same as prior period, unchanged from 0000080420-24-000030:notes:75]

[0000080420-24-000059:notes:78]
[same as prior period, unchanged from 0000080420-24-000030:notes:76]

[0000080420-24-000059:notes:79]
We issue restricted stock units (RSUs) to certain officers and key employees of the Company. The fair value of the RSUs is based on the price of our common stock as reported on the NASDAQ Global Market on the grant dates. Typically, these grants vest over a three-year period from the date of issuance and are a blend of time-based and performance-based shares. The portion of the grant that is time-based typically vests over a three-year period on each anniversary of the grant date, based on continued employment. The performance-based shares vest based on the three-year earnings and safety performance of the Company following the grant date. At June 30, 2024, there were 194,981 RSUs outstanding. The RSUs do not have voting rights but do receive dividend equivalents upon vesting which are accrued quarterly. Additionally, the shares of common stock underlying the RSUs are not considered issued and outstanding until vested and common stock is issued.

[0000080420-24-000059:notes:80]
Total RSU activity (number of shares) for the nine months ended June 30, 2024 is summarized below:

[0000080420-24-000059:notes:81]
|  | Number ofRestrictedStockUnits |  | WeightedAverageGrant ValuePer Share |
| Outstanding at September 30, 2023 | 292,497 |  |  | $ | 22.90 |  |
| Granted | 44,670 |  |  | 89.23 |  |
| Vested | (141,261) |  |  | 26.02 |  |
| Forfeited/canceled | (925) |  |  | 120.02 |  |
| Outstanding at June 30, 2024 | 194,981 |  |  | $ | 35.38 |  |

[0000080420-24-000059:notes:82]
During both the nine months ended June 30, 2024 and 2023, we recorded compensation expense of $3.4 million related to the RSUs.

[0000080420-24-000059:notes:83]
Restricted Stock
In December 2023, the Company's Compensation and Human Capital Committee revised the non-employee directors' annual restricted stock compensation from a fixed-shares arrangement to a fixed-value arrangement, retrospectively effective on October 1, 2023. Prior to October 1, 2023, each non-employee director received 2,400 restricted shares of the Company’s common stock annually. Fifty percent of the restricted stock granted to each of our non-employee directors vested immediately, while the remaining fifty percent vested on the anniversary of the grant date. Compensation expense was recognized immediately for the first fifty percent of the restricted stock granted, while compensation expense for the remaining fifty percent was recognized over the remaining vesting period. Subsequent to October 1, 2023, each non-employee director shall receive restricted shares of the Company's common stock valued at $0.1 million annually. The number of granted shares is calculated by dividing the $0.1 million by the average of high and low prices of our common stock on the grant date. The shares shall vest on the earlier of the grant anniversary date or the date of the next annual meeting of stockholders, whichever occurs first. In February 2024, 4,620 shares of restricted stock were issued to our non-employee directors at a price of $153.81 per share. During the nine months ended June 30, 2024 and 2023, we recorded compensation expense of $0.4 million and $0.5 million, respectively, related to restricted stock.


## us-gaap:FairValueDisclosuresTextBlock

[0000080420-24-000059:notes:84]
[same as prior period, unchanged from 0000080420-24-000030:notes:82]

[0000080420-24-000059:notes:85]
[same as prior period, unchanged from 0000080420-24-000030:notes:83]

[0000080420-24-000059:notes:86]
[same as prior period, unchanged from 0000080420-24-000030:notes:84]

[0000080420-24-000059:notes:87]
[same as prior period, unchanged from 0000080420-24-000030:notes:85]

[0000080420-24-000059:notes:88]
[same as prior period, unchanged from 0000080420-24-000030:notes:86]

[0000080420-24-000059:notes:89]
The following table summarizes the fair value of our assets and liabilities that were accounted for at fair value on a recurring basis as of June 30, 2024 (in thousands):

[0000080420-24-000059:notes:90]
|  | Fair Value Measurements at June 30, 2024 |
|  | Quoted Prices inActive Markets forIdentical Assets(Level 1) |  | Significant OtherObservableInputs(Level 2) |  | SignificantUnobservableInputs(Level 3) |  | Fair Value at June 30,2024 |
| Assets: |  |  |  |  |  |  |  |
| Cash and cash equivalents | $ | 332,012 |  |  | $ | — |  |  | $ | — |  |  | $ | 332,012 |  |
| Short-term investments | 42,033 |  |  | — |  |  | — |  |  | 42,033 |  |
| Rabbi trust assets | — |  |  | 11,764 |  |  | — |  |  | 11,764 |  |
| Liabilities: |  |  |  |  |  |  |  |
| Deferred compensation | — |  |  | 11,436 |  |  | — |  |  | 11,436 |  |

[0000080420-24-000059:notes:91]
[same as prior period, unchanged from 0000080420-24-000030:notes:89]

[0000080420-24-000059:notes:92]
[same as prior period, unchanged from 0000080420-24-000030:notes:90]

[0000080420-24-000059:notes:93]
[same as prior period, unchanged from 0000080420-24-000030:notes:91]

[0000080420-24-000059:notes:94]
[same as prior period, unchanged from 0000080420-24-000030:notes:92]

[0000080420-24-000059:notes:95]
[same as prior period, unchanged from 0000080420-24-000030:notes:93]

[0000080420-24-000059:notes:96]
[same as prior period, unchanged from 0000080420-24-000030:notes:94]

[0000080420-24-000059:notes:97]
There were no transfers between levels within the fair value measurement hierarchy during the quarter ended June 30, 2024.


## us-gaap:LesseeOperatingLeasesTextBlock

[0000080420-24-000059:notes:98]
Leases
Our leases consist primarily of office and construction equipment. All of our future lease obligations are related to non-cancelable operating leases. The following table provides a summary of lease cost components for the three and nine months ended June 30, 2024 and 2023, respectively (in thousands):

[0000080420-24-000059:notes:99]
|  |  | Three months ended June 30, |  | Nine months ended June 30, |
| Lease Cost |  | 2024 |  | 2023 |  | 2024 |  | 2023 |
| Operating lease cost |  | $ | 237 |  |  | $ | 391 |  |  | $ | 742 |  |  | $ | 1,147 |  |
| Less: sublease income |  | — |  |  | (163) |  |  | — |  |  | (487) |  |
| Variable lease cost(1) |  | 31 |  |  | 93 |  |  | 84 |  |  | 288 |  |
| Short-term lease cost(2) |  | 754 |  |  | 669 |  |  | 1,798 |  |  | 1,486 |  |
| Total lease cost |  | $ | 1,022 |  |  | $ | 990 |  |  | $ | 2,624 |  |  | $ | 2,434 |  |

[0000080420-24-000059:notes:100]
[same as prior period, unchanged from 0000080420-24-000030:notes:98]

[0000080420-24-000059:notes:101]
[same as prior period, unchanged from 0000080420-24-000030:notes:99]

[0000080420-24-000059:notes:102]
We recognize operating lease assets and operating lease liabilities representing the present value of the remaining lease payments for leases with initial terms greater than twelve months. Leases with initial terms of twelve months or less are not recorded in our Condensed Consolidated Balance Sheets. The following table provides a summary of the operating lease assets and operating lease liabilities included in our Condensed Consolidated Balance Sheets as of June 30, 2024 and September 30, 2023, respectively (in thousands):

[0000080420-24-000059:notes:103]
| Operating Leases |  | June 30, 2024 |  | September 30, 2023 |
| Assets: |  |  |  |  |
| Operating lease assets, net |  | $ | 909 |  |  | $ | 1,436 |  |
| Liabilities: |  |  |  |  |
| Current operating lease liabilities |  | 482 |  |  | 773 |  |
| Long-term operating lease liabilities |  | 427 |  |  | 663 |  |
| Total lease liabilities |  | $ | 909 |  |  | $ | 1,436 |  |

[0000080420-24-000059:notes:104]
The following table provides the maturities of our operating lease liabilities as of June 30, 2024 (in thousands):

[0000080420-24-000059:notes:105]
|  |  | Operating Leases |  |  |
| Remainder of 2024 |  | $ | 137 |  |  |  |
| 2025 |  | 440 |  |  |  |
| 2026 |  | 197 |  |  |  |
| 2027 |  | 156 |  |  |  |
| 2028 |  | 18 |  |  |  |
| Thereafter |  | — |  |  |  |
| Total future minimum lease payments |  | $ | 948 |  |  |  |
| Less: present value discount (imputed interest) |  | (39) |  |  |  |
| Present value of lease liabilities |  | $ | 909 |  |  |  |

[0000080420-24-000059:notes:106]
The weighted average discount rate as of June 30, 2024 was 3.82%. The weighted average remaining lease term was 2.42 years at June 30, 2024.


## us-gaap:IncomeTaxDisclosureTextBlock

[0000080420-24-000059:notes:107]
[same as prior period, unchanged from 0000080420-24-000030:notes:105]

[0000080420-24-000059:notes:108]
|  | Three months ended June 30, |  | Nine months ended June 30, |
|  | 2024 |  | 2023 |  | 2024 |  | 2023 |
| Income before income taxes | $ | 61,796 |  |  | $ | 23,645 |  |  | $ | 135,591 |  |  | $ | 36,232 |  |
| Income tax provision | 15,573 |  |  | 5,191 |  |  | 31,795 |  |  | 8,142 |  |
| Net income | $ | 46,223 |  |  | $ | 18,454 |  |  | $ | 103,796 |  |  | $ | 28,090 |  |
| Effective tax rate | 25 | % |  | 22 | % |  | 23 | % |  | 22 | % |

[0000080420-24-000059:notes:109]
Our income tax provision reflects an effective tax rate on pre-tax income of 25% and 23% for the three and nine months ended June 30, 2024, respectively, compared to 22% for both the three and nine months ended June 30, 2023. The effective tax rate for the three and nine months ended June 30, 2024 was favorably impacted by the estimated Research and Development Tax Credit (R&D Tax Credit). The effective tax rate for the nine months ended June 30, 2024 was also favorably impacted by discrete items primarily related to the vesting of RSUs. These items were offset by an income inclusion related to U.S. global intangible income and the tax expense related to certain nondeductible expenses. The effective tax rate for the three and nine months ended June 30, 2023 approximated the U.S. federal statutory rate and was favorably impacted by the estimated R&D Tax Credit and the projected utilization of net operating loss carryforwards in the U.K. that had been fully reserved with a valuation allowance. The favorable impacts were offset by state income tax expense, certain nondeductible expenses and an income inclusion related to U.S. global intangible income.


## us-gaap:SubsequentEventsTextBlock

[0000080420-24-000059:notes:110]
Subsequent Events
Cash Acquisition of Property, Plant and Equipment

[0000080420-24-000059:notes:111]
On July 1, 2024, we acquired land and buildings in Houston, Texas, for a total cash purchase price of approximately $5.5 million to help further facilitate executing the current backlog as well as planning for modest future volume growth.

[0000080420-24-000059:notes:112]
Hurricane Beryl

[0000080420-24-000059:notes:113]
During the second week of July 2024, operations across our three facilities located in Houston, Texas, experienced a temporary power outage and subsequent shutdown of our operations resulting from Hurricane Beryl. These facilities resumed limited operations within the same week. We are evaluating the potential financial impact, if any, associated with this event.

[0000080420-24-000059:notes:114]
Quarterly Dividend Declared

[0000080420-24-000059:notes:115]
On July 30, 2024, our Board of Directors declared a quarterly cash dividend on our common stock in the amount of $0.2650 per share. The dividend is payable on September 18, 2024 to stockholders of record at the close of business on August 14, 2024.
