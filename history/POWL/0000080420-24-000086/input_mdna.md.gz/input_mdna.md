# POWL MD&A — 0000080420-24-000086


## mdna

[0000080420-24-000086:mdna:1]
Item 7. Management’s Discussion and Analysis of Financial Condition and Results of Operations

[0000080420-24-000086:mdna:2]
Executive Overview

[0000080420-24-000086:mdna:3]
We develop, design, manufacture and service custom-engineered equipment and systems that distribute, control and monitor the flow of electrical energy and provide protection to motors, transformers and other electrically powered equipment. We are headquartered in Houston, Texas and primarily serve the oil and gas and petrochemical markets, the electric utility market, and commercial and other industrial markets. Beyond these major markets, we also provide products and services to the light rail traction power market and other markets that include universities and government entities. We are continuously developing new channels to electrical markets through original equipment manufacturers and distribution market channels. For additional information on the markets we serve, see “Markets” in Part I, Item 1 of this Annual Report.

[0000080420-24-000086:mdna:4]
In Fiscal 2024, we reported revenues of $1.0 billion, net income of $149.8 million, and generated $108.7 million in cash from operating activities. As of September 30, 2024, we had total assets of $928.2 million.

[0000080420-24-000086:mdna:5]
Outlook

[0000080420-24-000086:mdna:6]
Our backlog was $1.3 billion as of September 30, 2024, of which approximately $849 million is expected to be recognized as revenue during our fiscal year ending September 30, 2025. Although current commercial activity remains active in most of the markets that we compete in, we remain attentive to the macro environment and geopolitical events that may have an impact on future market activity.

[0000080420-24-000086:mdna:7]
Oil and gas and petrochemical markets. Our order activity remains strong in these markets. The North American market is responding to increased international demand for LNG and gas-to-chemical processes utilizing low-cost gas feedstocks. We believe the fundamentals of the U.S. natural gas market, through abundant supply and low cost, will continue to support investments in LNG, related gas processing, and petrochemical processes, and as a result, will continue to sustain our order activity associated with such markets. In addition to the traditional crude oil refining and other oil and gas downstream processes, we have recently expanded our end markets into hydrogen production, carbon capture as well as alternative fuels, such as biofuels and sustainable aviation fuel, in response to the demand for clean energy.

[0000080420-24-000086:mdna:8]
Electric utility market. Aligned with our strategy of end-market diversification, we seek to continue our focus and growth in electrical distribution substations, while also addressing a resurgence of power generation investment in this market.

[0000080420-24-000086:mdna:9]
Commercial and other industrial markets. We have experienced strong growth in these end markets driven by a mix of factors including increased investment in commercial and light industrial facilities for the production of various goods, the expansion of data centers and cloud computing, as well as the growing demand in industrial applications to support new technologies driving the energy transition. We are cautiously optimistic regarding the anticipated investment across AI applications that may drive data center growth and subsequently power generation demand.

[0000080420-24-000086:mdna:10]
Business Environment

[0000080420-24-000086:mdna:11]
The markets in which we participate are capital-intensive and cyclical in nature. Cyclicality is predominantly driven by customer demand, global economic and geopolitical conditions and anticipated environmental, safety or regulatory changes that affect the manner in which our customers proceed with capital investments. Our customers analyze various factors, including the demand and price for oil, gas and electrical energy, the overall economic and financial environment, governmental budgets, regulatory actions and environmental concerns. These factors influence the release of new capital projects by our customers, which are traditionally awarded in competitive bid situations. Scheduling of projects is matched to customer requirements, and projects typically take a number of months to produce. Schedules may change during the course of any particular project, and our operating results can, therefore, be impacted by factors outside of our control.

[0000080420-24-000086:mdna:12]
Our operating results are impacted by several factors such as the timing of new order awards, project backlog, changes in project cost estimates, customer approval of final engineering specifications and delays in customer construction schedules, all of which contribute to short-term earnings variability and the timing of project execution. Our operating results also have been, and may continue to be, impacted by the timing and resolution of change orders and the resolution of potential contract claims and liquidated damages, all of which could improve or deteriorate gross margins during the period in which these items are resolved with our customers. Disruptions in the global supply chain have negatively impacted and may continue to negatively impact our business and operating results due to the limited supply of, delays for and uncertainty in the timing of the receipt of key component parts and commodities. We continue to remain focused on the variables that impact our markets as well as cost management, labor availability and supply chain challenges.

[0000080420-24-000086:mdna:13]
We are subject to inflation, which can cause increases in our costs of labor, indirect expenses and raw materials, primarily copper, aluminum and steel. Fixed-price contracts can limit our ability to pass these increases to our customers, thus negatively impacting our earnings and operations in future periods.

[0000080420-24-000086:mdna:14]
During Fiscal 2024, we experienced commodity price volatility, in addition to the ongoing supply chain delays for specific engineered components that have been persistent. We are working closely with our suppliers to meet our customer commitments. In response to the increased cost environment and supply chain challenges, we strive to effectively manage our product pricing, delivery schedules and bid validity dates with our customers, as well as improve factory efficiencies and project execution, and as a result our gross margins have been improved in Fiscal 2024.

[0000080420-24-000086:mdna:15]
Results of Operations

[0000080420-24-000086:mdna:16]
Twelve Months Ended September 30, 2024 Compared to Twelve Months Ended September 30, 2023

[0000080420-24-000086:mdna:17]
Revenue and Gross Profit

[0000080420-24-000086:mdna:18]
Revenues and costs are primarily related to custom engineered-to-order equipment and systems and are accounted for under percentage-of-completion accounting, which precludes us from providing detailed price and volume information.

[0000080420-24-000086:mdna:19]
Revenues increased by 45%, or $313.0 million, to $1.0 billion in Fiscal 2024, primarily driven by the increase in project backlog resulting from large contracts awarded during Fiscal 2023 and strong bookings throughout Fiscal 2024. Domestic revenues increased by 52%, or $288.6 million, to $846.5 million in Fiscal 2024. International revenues increased by 17%, or $24.5 million, to $165.8 million in Fiscal 2024. Our international revenues include both revenues generated from our international facilities as well as revenues from export projects generated at our domestic facilities.

[0000080420-24-000086:mdna:20]
In Fiscal 2024, revenue from our core oil and gas market (excluding petrochemical) increased by 53%, or $144.1 million, to $417.2 million in Fiscal 2024; petrochemical market revenue increased by 97%, or $91.4 million, to $185.6 million; revenue from our electric utility market increased by 18%, or $28.1 million, to $186.5 million; commercial and other industrial market revenue increased by 44%, or $45.9 million, to $149.9 million; and revenue from all other markets combined increased by 23%, or $9.6 million to $51.1 million. These increases in revenue were driven by improved market conditions in most of our end markets, increased capital spending in our core oil, gas and petrochemical markets, as well as our strategic effort to expand our business into electric utility and commercial and other industrial markets. Revenue from our light rail traction power market decreased by 22%, or $6.1 million, to $22.0 million in Fiscal 2024 due to less project volume in this market. For additional information on the markets we serve, see “Markets” in Part I, Item 1 of this Annual Report.

[0000080420-24-000086:mdna:21]
Gross profit increased by 85%, or $125.5 million, to $273.1 million in Fiscal 2024. Gross profit as a percentage of revenues increased to 27% in Fiscal 2024 as compared to 21% in Fiscal 2023. This increase in gross profit is attributable to the higher volume levels across all of Powell's manufacturing facilities generating favorable volume leverage, strong project execution, and continuing effort to improve factory efficiencies while also managing product pricing that corresponds to current cost levels.

[0000080420-24-000086:mdna:22]
Selling, General and Administrative Expenses

[0000080420-24-000086:mdna:23]
Selling, general and administrative expenses increased by 8%, or $6.1 million, to $84.9 million in Fiscal 2024, primarily due to increased compensation expense and higher spending on infrastructure improvements. Selling, general and administrative expenses as a percentage of revenues decreased to 8% in Fiscal 2024, compared to 11% in Fiscal 2023, resulting from higher revenues on our existing cost structure.

[0000080420-24-000086:mdna:24]
Income Tax Provision

[0000080420-24-000086:mdna:25]
We recorded an income tax provision of $46.2 million in Fiscal 2024, resulting in an effective tax rate of 24%, compared to an income tax provision of $14.4 million in Fiscal 2023 at an effective tax rate of 21%. In Fiscal 2024, the effective tax rate was favorably impacted by the estimated Research and Development (R&D) Tax Credit and tax benefits related to the vesting of restricted stock units. These items were offset by state income tax expense, certain non-deductible items, and the tax impact of U.S. global intangible income.

[0000080420-24-000086:mdna:26]
In Fiscal 2023, the effective tax rate approximated the U.S. federal statutory rate. The favorable impacts of the estimated R&D Tax Credit and the release of the valuation allowance previously recorded against the U.K. net deferred tax assets in the amount of $1.9 million were offset by state income tax expense, certain non-deductible items and the tax impact of U.S. global intangible income.

[0000080420-24-000086:mdna:27]
Net Income

[0000080420-24-000086:mdna:28]
In Fiscal 2024, we recorded net income of $149.8 million, or $12.29 per diluted share, compared to net income of $54.5 million, or $4.50 per diluted share in Fiscal 2023. This increase in net income is primarily due to higher revenues coupled with improved gross profit margins, as well as our disciplined cost structure.

[0000080420-24-000086:mdna:29]
Backlog

[0000080420-24-000086:mdna:30]
The order backlog, which is our remaining unsatisfied performance obligations, represents the estimated transaction price for goods and services for which we have a material right, but work has not been performed. The order backlog at September 30, 2024 was $1.3 billion, consistent with our backlog at September 30, 2023. Bookings, net of cancellations and scope reductions, decreased by 24% in Fiscal 2024 to $1.1 billion, compared to $1.4 billion in Fiscal 2023. Despite strong bookings in Fiscal 2024, the decrease in bookings was due to a normalization of the oil and gas sector with fewer large orders awarded in this sector during Fiscal 2024.

[0000080420-24-000086:mdna:31]
Liquidity and Capital Resources

[0000080420-24-000086:mdna:32]
As of September 30, 2024, current assets exceeded current liabilities by 1.8 times.

[0000080420-24-000086:mdna:33]
Cash, cash equivalents and short-term investments increased to $358.4 million at September 30, 2024, compared to $279.0 million at September 30, 2023. This increase in cash, cash equivalents and short-term investments was primarily driven by our improved earnings due to increased project margins and volumes, partially offset by working capital allocated to projects in our order book, capital spending, as well as dividend payments. We believe that our cash, cash equivalents and short-term investments, as well as available borrowings under our U.S. credit facility, will be sufficient to support our future operating activities, working capital requirements, payment of dividends and capital spending, as well as research and development initiatives for the next twelve months and beyond.

[0000080420-24-000086:mdna:34]
On October 4, 2023, we entered into a third amendment (the Third Amendment) to our credit agreement with Bank of America, N.A. (as amended, the U.S. Revolver). The Third Amendment which added Texas Capital Bank as Syndication Agent and a lender, increased the amount of the revolving line of credit from $125.0 million to $150.0 million, and extended the expiry date to October 4, 2028. The aggregate commitment of $150.0 million consists of $100.0 million committed by Bank of America and $50.0 million committed by Texas Capital Bank. As amended by the Third Amendment, the lesser of (a) $60 million, (b) 60% of available cash, and (c) the aggregate face amount of the issued but undrawn letters of credit that are not cash-secured shall be deducted from consolidated funded indebtedness, when calculating the consolidated net leverage ratio. We have the

[0000080420-24-000086:mdna:35]
option to cash collateralize all or a portion of the letters of credit outstanding, which would favorably impact the consolidated funded indebtedness calculation and the consolidated net leverage ratio. On June 26, 2024, in connection with the expected discontinuation of the publication of the Canadian Dollar Offered Rate (CDOR), we further amended the U.S. Revolver by entering into a Canadian benchmark replacement conforming changes amendment with Bank of America, N.A. that added and amended certain terms related to the replacement of the CDOR as a benchmark rate with the forward-looking term rate based on the Canadian Overnight Repo Rate Average. On September 24, 2024, in connection with the expected discontinuation of the publication of the Bloomberg Short-Term Bank Yield Index Rate as administered by the Bloomberg Index Service Limited (BSBY), we further amended the U.S. Revolver by entering into a conforming changes amendment with Bank of America, N.A. that added and amended certain terms related to the replacement of the BSBY as a benchmark rate with the Secured Overnight Financing Rate (SOFR) as administered by the Federal Reserve Bank of New York.

[0000080420-24-000086:mdna:36]
As of September 30, 2024, there were no amounts borrowed under the U.S. Revolver, and letters of credit outstanding were $63.8 million. There was $86.2 million available for the issuance of letters of credit and borrowings under the U.S. Revolver as of September 30, 2024. For further information regarding our debt, see Notes G and H of Notes to Consolidated Financial Statements.

[0000080420-24-000086:mdna:37]
Approximately $77.7 million of our cash, cash equivalents and short-term investments at September 30, 2024 was held outside of the U.S. for our international operations. It is our intention to indefinitely reinvest all current and future foreign earnings internationally in order to ensure sufficient working capital to support our international operations. In the event that we elect to repatriate some or all of the foreign earnings that were previously deemed to be indefinitely reinvested outside the U.S., we may incur additional tax expense upon such repatriation under current tax laws.

[0000080420-24-000086:mdna:38]
Cash Flows

[0000080420-24-000086:mdna:39]
Operating Activities

[0000080420-24-000086:mdna:40]
Operating activities provided net cash of $108.7 million during Fiscal 2024 and provided net cash of $182.6 million during Fiscal 2023. Cash flow from operations is primarily influenced by project volume and margins, as well as working capital requirements, the timing of milestone payments from our customers, and payment terms with our suppliers. The decrease in operating cash flow was primarily due to working capital impact as we allocate capital to the projects in the order book, partially offset by higher net income resulting from increased project volume and improved project margins.

[0000080420-24-000086:mdna:41]
Investing Activities

[0000080420-24-000086:mdna:42]
Investing activities used $21.9 million of cash during Fiscal 2024 and used $26.6 million in Fiscal 2023. The decrease in cash used in investing activities during Fiscal 2024 was primarily due to lower net purchase of short-term investments, partially offset by higher capital spending on property, plant and equipment in Fiscal 2024. During Fiscal 2024, our purchase of short-term investments was $9.7 million compared with net purchase of short-term investments of $18.8 million in Fiscal 2023. In July 2024, we made a cash purchase of land and buildings in Houston, Texas for $5.6 million to help further facilitate executing the current backlog as well as planning for modest future volume growth. In addition, we acquired intellectual property in December 2023 for a total consideration of $0.5 million, of which $250 thousand was paid in cash.

[0000080420-24-000086:mdna:43]
Financing Activities

[0000080420-24-000086:mdna:44]
Net cash used in financing activities was $19.3 million during Fiscal 2024 compared to $13.1 million used during Fiscal 2023. The increase in cash used in financing activities was primarily due to cash payments related to shares withheld in lieu of employee tax withholding, largely driven by the significant increase in our share price during Fiscal 2024 compared to Fiscal 2023.

[0000080420-24-000086:mdna:45]
Planned Capital Spending

[0000080420-24-000086:mdna:46]
We have planned capital spending of approximately $11 million on a facility expansion project at our products factory in Houston. We expect to complete the expansion project by mid-Fiscal 2025. We have spent $1.5 million on the expansion project in Fiscal 2024.

[0000080420-24-000086:mdna:47]
Other Commercial Commitments

[0000080420-24-000086:mdna:48]
We are contingently liable for letters of credit and bank guarantees totaling $71.0 million as of September 30, 2024, with the following potential cash outflows in the event that we are unable to perform under our contracts (in thousands):

[0000080420-24-000086:mdna:49]
| Payments Due by Period: | Letters ofCredit/ Bank Guarantees |
| Less than 1 year | $ | 27,587 |  |
| 1 to 3 years | 42,336 |  |
| More than 3 years | 1,064 |  |
| Total commercial commitments | $ | 70,987 |  |

[0000080420-24-000086:mdna:50]
We also had surety bonds totaling $426.8 million that were outstanding at September 30, 2024. Surety bonds are primarily used to guarantee our contract performance to our customers.

[0000080420-24-000086:mdna:51]
Off-Balance Sheet Arrangements

[0000080420-24-000086:mdna:52]
We had no significant off-balance sheet arrangements during the periods presented.

[0000080420-24-000086:mdna:53]
Critical Accounting Estimates

[0000080420-24-000086:mdna:54]
The preparation of consolidated financial statements in conformity with accounting principles generally accepted in the United States (U.S. GAAP) requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities, disclosures of contingent assets and liabilities known to exist at the date of the consolidated financial statements and the reported amounts of revenues and expenses during the reporting period. We evaluate our estimates on an ongoing basis, based on historical experience and on various other assumptions that are believed to be reasonable under the circumstances. There can be no assurance that actual results will be consistent with those estimates.

[0000080420-24-000086:mdna:55]
We believe the following accounting estimates to be critical in the preparation and reporting of our consolidated financial statements.

[0000080420-24-000086:mdna:56]
Revenue Recognition

[0000080420-24-000086:mdna:57]
Our revenues are primarily generated from the manufacturing of custom-engineered products and systems under long-term fixed-price contracts under which we agree to manufacture various products such as traditional and arc-resistant distribution switchgear and control gear, medium-voltage circuit breakers, monitoring and control communications systems, motor control centers, switches and bus duct systems. These products may be sold separately as an engineered solution, but are typically integrated into custom-built enclosures which we also build. These enclosures are referred to as power control room substations (PCRs®), custom-engineered modules or electrical houses (E-Houses). Some contracts may also include the installation and commissioning of these enclosures.

[0000080420-24-000086:mdna:58]
Revenue from these contracts is generally recognized over time utilizing the cost-to-cost method. Under the cost-to-cost method, the extent of progress towards completion is measured based on the ratio of costs incurred to date to the total estimated costs at completion of the performance obligation. We believe that this method is the most accurate representation of our performance because it directly measures the value of the services transferred to the customer over time as we incur costs on our contracts. Contract costs include all direct materials, labor and indirect costs related to contract performance, which may include indirect labor, supplies, tools, repairs and depreciation costs.

[0000080420-24-000086:mdna:59]
Performance Obligations

[0000080420-24-000086:mdna:60]
A performance obligation is a promise in a contract or with a customer to transfer a distinct good or service. A contract’s transaction price is allocated to each distinct performance obligation and recognized as revenue as the performance obligations are satisfied. To determine the proper revenue recognition for contracts, we evaluate whether a contract should be accounted for as more than one performance obligation or, less commonly, whether two or more contracts should be combined and accounted for as one performance obligation. This evaluation of performance obligations requires significant judgment. The majority of our contracts have a single performance obligation where multiple engineered products and services are combined into a single custom-engineered solution. Our contracts include a standard one-year assurance warranty. Occasionally, we provide service-type warranties that will extend the warranty period. These extended warranties qualify as separate performance obligations, and revenue is deferred and recognized over the warranty period. If we determine during the evaluation of the contract that there are multiple performance obligations, we allocate the transaction price to each performance obligation using our best estimate of the standalone selling price of each distinct good or service in the contract.

[0000080420-24-000086:mdna:61]
Contract Estimates

[0000080420-24-000086:mdna:62]
Actual revenues and project costs may vary from previous estimates due to changes in a variety of factors. The cost estimation process is based on the professional knowledge and experience of our engineers, project managers and financial professionals. Factors that are considered in estimating the work to be completed and ultimate contract recovery include the availability and productivity of labor, the nature and complexity of the work to be performed, the availability of materials, and the effect of any delays on our project performance. We periodically review our job performance, job conditions, estimated profitability and final contract settlements, including our estimate of total costs and make revisions to costs and income in the period in which the revisions are probable and reasonably estimable. We bear the risk of cost overruns in most of our contracts, which may result in reduced profits. Whenever revisions of estimated contract costs and contract values indicate that the contract costs will exceed estimated revenues, thus creating a loss, a provision for the total estimated loss is recorded in that period. See Note E of Notes to Consolidated Financial Statements for disclosures related to changes in contract estimates.

[0000080420-24-000086:mdna:63]
Variable Consideration

[0000080420-24-000086:mdna:64]
It is common for our long-term contracts to contain variable consideration that can either increase or decrease the transaction price. Due to the nature of our contracts, estimating total cost and revenue can be complex and subject to variability due to change orders, back charges, spare parts, early completion bonuses, customer allowances and liquidated damages. We estimate the amount of variable consideration based on the expected value method, which is the sum of probability-weighted amounts, or the most likely amount method, which uses various factors including experience with similar transactions and assessment of our anticipated performance. Variable consideration is included in the transaction price if legally enforceable and to the extent it is probable that a significant reversal of cumulative revenue recognized will not occur once the uncertainty associated with the variable consideration is resolved.

[0000080420-24-000086:mdna:65]
Contract Modifications

[0000080420-24-000086:mdna:66]
Contracts may be modified for changes in contract specifications and requirements. We consider contract modifications to exist when the modification either creates new or changes the enforceable rights and obligations under the contract. Most of our contract modifications are for goods and services that are not distinct from the existing performance obligation. Contract modifications result in a cumulative catch-up adjustment to revenue based on our measure of progress for the performance obligation.

[0000080420-24-000086:mdna:67]
Impairment of Long-Lived Assets

[0000080420-24-000086:mdna:68]
We review long-lived assets for impairment whenever events or changes in circumstances indicate that the carrying value may not be realizable. If an evaluation is required, the estimated future undiscounted cash flows associated with the asset are compared to the asset’s carrying amount to determine if recording an impairment of such asset is necessary. This requires us to make long-term forecasts of the future revenues and costs related to the assets subject to review. Forecasts require assumptions about demand for our products and future market conditions. Estimating future cash flows requires significant judgment, and our projections may vary from cash flows eventually realized. Future events and unanticipated changes to assumptions could require a provision for impairment in a future period. The effect of any impairment would be reflected in operating income in the Consolidated Statements of Operations. In addition, we estimate the useful lives of our long-lived assets and other intangibles, and periodically review these estimates to determine whether these lives are appropriate.

[0000080420-24-000086:mdna:69]
Accruals for Contingent Liabilities

[0000080420-24-000086:mdna:70]
From time to time, contingencies such as insurance-related claims, liquidated damages and legal claims arise in the normal course of business. Pursuant to applicable accounting standards, we must evaluate such contingencies to subjectively determine the likelihood that an asset has been impaired, or a liability has been incurred at the date of the financial statements, as well as evaluate whether the amount of the loss can be reasonably estimated. If the likelihood is determined to be probable, and it can be reasonably estimated, the estimated loss is recorded. The amounts we record for contingent liabilities require judgments regarding the amount of expenses that will ultimately be incurred. We use past experience and history, as well as the specific circumstances surrounding each contingent liability, including estimated legal costs, in evaluating the amount of liability that should be recorded. Actual results could differ from our estimates.

[0000080420-24-000086:mdna:71]
Warranty Costs

[0000080420-24-000086:mdna:72]
Estimated costs of warranties are accrued based on historical warranty claim costs in relation to current revenues. In addition, specific provisions are made when product failures are projected outside historical experience. Our standard terms and conditions of sale include a warranty for parts and service for one year. Occasionally, we provide service-type warranties that will extend the warranty period. Actual results could differ from our estimate.

[0000080420-24-000086:mdna:73]
Projects may require, on occasion, warranty terms that are longer than our standard terms due to the nature of the project. Extended warranty terms may be negotiated and included in our contracts. The allocated revenue associated with the extended warranty is deferred and recorded as a contract liability and recognized as revenue over the extended warranty period.

[0000080420-24-000086:mdna:74]
Accounting for Income Taxes

[0000080420-24-000086:mdna:75]
We account for income taxes under the asset and liability method, based on the income tax laws and rates in the countries in which operations are conducted, and income is earned. This approach requires the recognition of deferred tax assets and liabilities for the expected future tax consequences of temporary differences between the carrying amounts and the tax basis of assets and liabilities. Developing our provision for income taxes requires significant judgment and expertise in federal, international and state income tax laws, regulations and strategies, including the determination of deferred tax assets and liabilities and, if necessary, any valuation allowances that may be required for deferred tax assets. In assessing the extent to which net deferred tax assets may be realized, we consider whether it is more likely than not that some portion or all of the net deferred tax assets may not be realized. The ultimate realization of net deferred tax assets is dependent on the generation of future taxable income during the periods in which those temporary differences become deductible. Estimates may change as new events occur, estimates of future taxable income during the carryforward period are reduced or increased, additional information becomes available, or operating environments change, which may result in a full or partial reversal of the valuation allowance. We will continue to assess the adequacy of the valuation allowance on a quarterly basis. Our judgments and tax strategies are subject to audit by various taxing authorities.

[0000080420-24-000086:mdna:76]
The objectives of accounting for income taxes are to recognize the amount of taxes payable or refundable for the current year and deferred tax liabilities and assets for the future tax consequences of events that have been recognized in an entity’s financial statements or tax returns. We recognize the tax benefit from an uncertain tax position only if it is more likely than not that the tax position will be sustained on examination by the taxing authorities, based on the technical merits of the position. The tax benefits recognized in the financial statements from such a position should be measured based on the largest benefit that has a greater than 50% likelihood of being realized upon ultimate settlement. Accounting literature also provides guidance on derecognition of income tax assets and liabilities, classification of current and deferred income tax assets and liabilities, accounting for interest and penalties associated with tax positions, and income tax disclosures. Judgment is required in assessing the future tax consequences of events that have been recognized in our financial statements or tax returns. Variations in the actual outcome of these future tax consequences could materially impact our financial position and results of operations.

[0000080420-24-000086:mdna:77]
See Note I of Notes to Consolidated Financial Statements for disclosures related to the valuation allowance recorded in relation to deferred taxes.
