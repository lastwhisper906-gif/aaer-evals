# POWL notes — 0000080420-24-000086


## dei:DocumentsIncorporatedByReferenceTextBlock

[0000080420-24-000086:notes:1]
Portions of the registrant’s definitive proxy statement for the 2024 annual meeting of stockholders to be filed not later than 120 days after September 30, 2024, are incorporated by reference into Part III of this Form 10-K.


## us-gaap:SignificantAccountingPoliciesTextBlock

[0000080420-24-000086:notes:2]
Summary of Significant Accounting Policies
Principles of Consolidation

[0000080420-24-000086:notes:3]
The consolidated financial statements include the accounts of Powell and our wholly-owned subsidiaries. All intercompany accounts and transactions have been eliminated in consolidation.

[0000080420-24-000086:notes:4]
Use of Estimates

[0000080420-24-000086:notes:5]
The preparation of financial statements in conformity with accounting principles generally accepted in the United States (U.S. GAAP) requires management to make estimates and assumptions that affect the amounts reported in the consolidated financial statements and accompanying footnotes. The most significant estimates used in our consolidated financial statements affect revenue recognition and estimated cost recognition on our customer contracts, allowance for credit losses, provision for excess and obsolete inventory, warranty accruals and income taxes. The amounts recorded for warranties, legal, income taxes, impairment of long-lived assets (when applicable), liquidated damages and other contingent liabilities require judgments regarding the amount of expenses that will ultimately be incurred. We base our estimates on historical experience, forecasts and various other assumptions, as well as the specific circumstances surrounding these contingent liabilities, in evaluating the amount of liability that should be recorded. Additionally, the basis for recognition of deferred tax assets requires estimates related to future income and other assumptions regarding timing and future profitability because the ultimate realization of net deferred tax assets is dependent on the generation of future taxable income during periods in which temporary differences become deductible. Estimates routinely change as new events occur, additional information becomes available or operating environments change. Actual results may differ from our prior estimates.

[0000080420-24-000086:notes:6]
Cash and Investments

[0000080420-24-000086:notes:7]
Cash and cash equivalents – Cash and cash equivalents, primarily funds held in money market savings instruments, are reported at their current carrying value, which approximates fair value due to the short-term nature of these instruments, and are included in cash and cash equivalents in our Consolidated Balance Sheets.

[0000080420-24-000086:notes:8]
Short-term investments – Short-term investments include time deposits with original maturities of three months or more.

[0000080420-24-000086:notes:9]
Supplemental Disclosures of Cash Flow Information (in thousands):

[0000080420-24-000086:notes:10]
|  | Year Ended September 30, |
|  | 2024 |  | 2023 |  | 2022 |
| Cash paid (received) during the period for: |  |  |  |  |  |
| Interest received, net of interest expense | $ | (15,641) |  |  | $ | (5,465) |  |  | $ | (334) |  |
| Income taxes paid, net of refunds | 50,919 |  |  | 17,232 |  |  | 533 |  |
| Non-cash capital expenditures | 361 |  |  | 183 |  |  | 1,133 |  |

[0000080420-24-000086:notes:11]
Fair Value of Financial Instruments

[0000080420-24-000086:notes:12]
Financial instruments include cash, cash equivalents, short-term investments, receivables, deferred compensation, payables and debt obligations. Except as described below, due to the short-term nature of account receivables and account payables, their book values are representative of their fair values.

[0000080420-24-000086:notes:13]
Accounts Receivable

[0000080420-24-000086:notes:14]
Accounts receivable are stated net of allowances for credit losses. We maintain and continually assess the adequacy of the allowance for credit losses representing our estimate for losses resulting from the inability of our customers to pay amounts due to us. This estimated allowance is based on historical experience of uncollected accounts, the level of past due accounts, the overall level of outstanding accounts receivable, information about specific customers with respect to their inability to make payments and expectations of future conditions that could impact the collectability of accounts receivable. Future changes in our customers’ operating performance and cash flows, or in general economic conditions, could have an impact on their ability to fully pay these amounts, which could have a material impact on our operating results. In most cases, receivables are not collateralized. However, we utilize letters of credit to secure payment on projects when possible. Retention amounts are in accordance with applicable provisions of contracts and become due upon completion of contractual requirements. As of September 30, 2024 and 2023, we had retention amounts of $7.1 million and $7.4 million, respectively. Of the retained amount at September 30, 2024, $6.1 million is expected to be collected in the next twelve months and is recorded in accounts receivable. The remaining $1.0 million is recorded in other assets and is expected to be collected beyond September 30, 2025.

[0000080420-24-000086:notes:15]
Contract Balances

[0000080420-24-000086:notes:16]
The timing of revenue recognition, billings and cash collections affects accounts receivable, contract assets and contract liabilities in our Consolidated Balance Sheets.

[0000080420-24-000086:notes:17]
Contract assets are recorded when revenues are recognized in excess of amounts billed for fixed-price contracts as determined by the billing milestone schedule. Contract assets are transferred to accounts receivable when billing milestones have been met, or we have an unconditional right to payment.

[0000080420-24-000086:notes:18]
Contract liabilities typically represent advance payments from contractual billing milestones and billings in excess of revenue recognized. It is unusual to have advanced milestone payments with a term greater than one year, which could represent a financing component on the contract.

[0000080420-24-000086:notes:19]
Our contract assets and liabilities are reported in a net position on a contract-by-contract basis at the end of each reporting period and are generally classified as current.

[0000080420-24-000086:notes:20]
Inventories

[0000080420-24-000086:notes:21]
Inventories are stated at the lower of cost or net realizable value using weighted-average methods and include the cost of materials, labor and manufacturing overhead. We use estimates in determining the level of reserves required to state inventory at the lower of cost or net realizable value. Our estimates are based on market activity levels, production requirements, the physical condition of products and technological innovation. Changes in any of these factors may result in adjustments to the carrying value of inventory.

[0000080420-24-000086:notes:22]
Property, Plant and Equipment

[0000080420-24-000086:notes:23]
Property, plant and equipment are stated at cost and are depreciated using the straight-line method over the estimated useful lives of the assets. Expenditures for repairs and maintenance are charged to expense when incurred. Expenditures for major renewals and improvements, which extend the useful lives of existing equipment, are capitalized and depreciated. Upon retirement or disposition of property, plant and equipment, the cost and related accumulated depreciation are removed from the accounts, and any resulting gain or loss is recognized in the Consolidated Statements of Operations.

[0000080420-24-000086:notes:24]
We review property, plant and equipment for impairment whenever events or changes in circumstances indicate that the carrying value may not be realizable. If an evaluation is required, the estimated future undiscounted cash flows associated with the asset are compared to the asset’s carrying amount to determine if recording an impairment of such asset is necessary. If an impairment is indicated, we record an impairment loss equal to the difference between the carrying value and the fair value of the long-lived asset. This requires us to make long-term forecasts of the future revenues and the costs related to the assets subject to review. Forecasts require assumptions about demand for our products and future market conditions. Estimating future cash flows requires significant judgment, and our projections may vary from cash flows eventually realized. Future events and unanticipated changes to assumptions could require a provision for impairment in a future period. The effect of any impairment would be reflected in operating income in the Consolidated Statements of Operations. In addition, we estimate the useful lives of our property, plant and equipment and periodically review these estimates to determine whether these lives are appropriate.

[0000080420-24-000086:notes:25]
Income Taxes

[0000080420-24-000086:notes:26]
We account for income taxes under the asset and liability method, based on the income tax laws and rates in the countries in which operations are conducted, and income is earned. This approach requires the recognition of deferred tax assets and liabilities for the expected future tax consequences of temporary differences between the carrying amounts and the tax basis of assets and liabilities. Developing our provision for income taxes requires significant judgment and expertise in federal, international and state income tax laws, regulations and strategies, including the determination of deferred tax assets and liabilities and, if necessary, any valuation allowances that may be required for deferred tax assets. In assessing the extent to which net deferred tax assets may be realized, we consider whether it is more likely than not that some portion or all of the net deferred tax assets may not be realized. The ultimate realization of net deferred tax assets is dependent on the generation of future taxable income during the periods in which those temporary differences become deductible. Estimates may change as new events occur, estimates of future taxable income during the carryforward period are reduced or increased, additional information becomes available or operating environments change, which may result in a full or partial reversal of the valuation allowance. We will continue to assess the adequacy of the valuation allowance on a quarterly basis. Our judgments and tax strategies are subject to audit by various taxing authorities.

[0000080420-24-000086:notes:27]
The objectives of accounting for income taxes are to recognize the amount of taxes payable or refundable for the current year and deferred tax liabilities and assets for the future tax consequences of events that have been recognized in an entity’s financial statements or tax returns. We recognize the tax benefit from an uncertain tax position only if it is more likely than not that the tax position will be sustained on examination by the taxing authorities, based on the technical merits of the position. The tax benefits recognized in the financial statements from such a position should be measured based on the largest benefit that has a greater than 50% likelihood of being realized upon ultimate settlement. Accounting literature also provides guidance on derecognition of income tax assets and liabilities, classification of current and deferred income tax assets and liabilities, accounting for interest and penalties associated with tax positions, and income tax disclosures. Judgment is required in assessing the future tax consequences of events that have been recognized in our financial statements or tax returns. Variations in the actual outcome of these future tax consequences could materially impact our financial statements.

[0000080420-24-000086:notes:28]
Revenue Recognition

[0000080420-24-000086:notes:29]
Our revenues are primarily generated from the manufacturing of custom-engineered products and systems under long-term, fixed-price contracts that may last from one month to several years, depending on the contract. Revenue from these contracts is generally recognized over time utilizing the cost-to-cost method. Under the cost-to-cost method, the extent of progress towards completion is measured based on the ratio of costs incurred to date to the total estimated costs at completion of the performance obligation. We believe that this method is the most accurate representation of our performance because it directly measures the value of the services transferred to the customer over time as we incur costs on our contracts. Contract costs include all direct materials, labor and indirect costs related to contract performance, which may include indirect labor, supplies, tools, repairs and depreciation costs.

[0000080420-24-000086:notes:30]
We also have contracts to provide field service inspection, installation, commissioning, modification, and repair services, as well as retrofit and retrofill components for existing systems. If the service contract terms give us the right to invoice the customer for an amount that corresponds directly with the value of our performance completed to date (i.e., a service contract in

[0000080420-24-000086:notes:31]
which we bill a fixed amount for each hour of service provided), then we recognize revenue over time in each reporting period corresponding to the amount that we have the right to invoice. Our performance obligations are satisfied as the work progresses.

[0000080420-24-000086:notes:32]
We also have sales orders for spare parts and replacement circuit breakers for switchgear that are obsolete or that are no longer produced by the original manufacturer. Revenues from these sales orders are recognized at the time we fulfill our performance obligation to the customer, which is typically upon shipment.

[0000080420-24-000086:notes:33]
Additionally, some contracts may contain a cancellation clause that could limit the amount of revenue we are able to recognize over time. In these instances, revenue and costs associated with these contracts are deferred and recognized at a point in time when the performance obligation is fulfilled.

[0000080420-24-000086:notes:34]
Selling and administrative costs incurred in relation to obtaining a contract are typically expensed as incurred. We periodically utilize a third-party sales agent to obtain a contract and will pay a commission to that agent. We record the full commission liability to the third-party sales agents at the order date, with a corresponding deferred asset. As the project progresses, we record commission expense based on percentage of completion rates that correlate to the project and reduce the deferred asset. Once we have been paid by the customer, we pay the commission, and the liability is reduced.

[0000080420-24-000086:notes:35]
Warranty Costs

[0000080420-24-000086:notes:36]
Estimated costs of warranties are accrued based on historical warranty claim costs in relation to current revenues. In addition, specific provisions are made when product failures are projected outside historical experience. Our standard terms and conditions of sale include a warranty for parts and service for one year. Occasionally, we provide service-type warranties that will extend the warranty period. Actual results could differ from our estimate.

[0000080420-24-000086:notes:37]
Projects may require, on occasion, warranty terms that are longer than our standard terms due to the nature of the project. Extended warranty terms may be negotiated and included in our contracts. The allocated revenue associated with the extended warranty is deferred and recorded as a contract liability and recognized as revenue over the extended warranty period.

[0000080420-24-000086:notes:38]
Research and Development Expense

[0000080420-24-000086:notes:39]
Research and development activities are directed toward the development of new products and processes as well as improvements in existing products and processes. These costs, which primarily include salaries, contract services and supplies, are expensed as incurred. Such amounts were $9.4 million, $6.2 million and $7.0 million in Fiscal 2024, 2023 and 2022, respectively.

[0000080420-24-000086:notes:40]
Foreign Currency Translation

[0000080420-24-000086:notes:41]
The functional currency for our foreign subsidiaries is the local currency in which the entity is located. The financial statements of all subsidiaries with a functional currency other than the U.S. Dollar have been translated into U.S. Dollars. All assets and liabilities of foreign operations are translated into U.S. Dollars using period-end exchange rates, and all revenues and expenses are translated at average rates during the respective period. The U.S. Dollar results that arise from such translation, as well as exchange gains and losses on intercompany balances of a long-term investment nature, are included in the cumulative currency translation adjustments in accumulated other comprehensive loss in stockholders’ equity.

[0000080420-24-000086:notes:42]
Stock-Based Compensation

[0000080420-24-000086:notes:43]
We measure stock-based compensation cost at the grant date based on the fair value of the award. Compensation expense is recognized over the period during which the recipient is required to provide service in exchange for the awards, typically the vesting period. Excess income tax benefits related to stock-based compensation expense are recognized as income tax expense or benefit in the Consolidated Statements of Operations. Cash paid when directly withholding shares on an employee's behalf for tax withholding purposes is classified as a financing activity. We account for forfeitures as they occur, rather than estimate expected forfeitures.

[0000080420-24-000086:notes:44]
Accounting Standards Updates and Disclosure Rules Issued but Not Yet Adopted

[0000080420-24-000086:notes:45]
In November 2023, the Financial Accounting Standard Board (FASB) issued Accounting Standards Update (ASU) 2023-07,

[0000080420-24-000086:notes:46]
Segment Reporting (Topic 280): Improvements to Reportable Segment Disclosures, which requires that public entities disclose significant segment expenses that are regularly provided to the chief operating decision maker (CODM) on an annual and interim basis. It also requires that public entities disclose the title and position of the CODM and an explanation of how the CODM uses the reported measures in assessing segment performance and resource allocation. Additionally, it requires that all existing annual disclosures about segment profit or loss and assets must be provided on an interim basis and clarifies that single

[0000080420-24-000086:notes:47]
reportable segment entities are subject to the disclosure requirement under Topic 280 in its entirety. ASU 2023-07 is effective for fiscal years beginning after December 15, 2023 and interim periods within those fiscal years beginning after December 15, 2024. A public entity should apply ASU 2023-07 retrospectively to all prior periods presented in the financial statements. Early adoption is permitted. We are currently evaluating the impacts of the new standard.

[0000080420-24-000086:notes:48]
In December 2023, the FASB issued ASU 2023-09, Improvements to Income Tax Disclosures, which enhances the transparency of income tax disclosures. It requires greater disaggregation of information in the tax rate reconciliation and income taxes paid disaggregated by jurisdiction. This ASU is effective for fiscal years beginning after December 15, 2024, and should be applied on a prospective basis. Retrospective application and early adoption are permitted. We are currently evaluating the impacts of the new standard.

[0000080420-24-000086:notes:49]
In March 2024, the SEC adopted final rules designed to enhance and standardize disclosures related to the risks and impacts of climate-related matters. The final rules require registrants to disclose certain climate-related information in registration statements and annual reports. Such information relates to climate-related risks and risk management processes for, and governance and oversight activities of, such risks. The final rules also include requirements to disclose the financial effects of severe weather events and other natural conditions in the audited financial statements. In addition, larger registrants will be required to disclose information about greenhouse gas emissions, which will be subject to a phased-in assurance requirement. These disclosure requirements were scheduled to be effective for the Company's fiscal year beginning October 1, 2025. However, in April 2024, the SEC voluntarily stayed the final rules as a result of pending legal challenges. We are currently evaluating the impacts of the final rules on our consolidated financial statements and related disclosures.


## us-gaap:RevenueFromContractWithCustomerPolicyTextBlock

[0000080420-24-000086:notes:50]
Our revenues are primarily generated from the manufacturing of custom-engineered products and systems under long-term fixed-price contracts under which we agree to manufacture various products such as traditional and arc-resistant distribution switchgear and control gear, medium-voltage circuit breakers, monitoring and control communications systems, motor control centers, switches and bus duct systems. These products may be sold separately as an engineered solution but are typically integrated into custom-built enclosures which we also build. These enclosures are referred to as power control room substations (PCRs®), custom-engineered modules or electrical houses (E-Houses). Some contracts may also include the installation and the commissioning of these enclosures.

[0000080420-24-000086:notes:51]
Revenue from these contracts is generally recognized over time utilizing the cost-to-cost method. Under the cost-to-cost method, the extent of progress towards completion is measured based on the ratio of costs incurred to date to the total estimated costs at completion of the performance obligation. We believe that this method is the most accurate representation of our performance because it directly measures the value of the services transferred to the customer over time as we incur costs on our contracts. Contract costs include all direct materials, labor and indirect costs related to contract performance, which may include indirect labor, supplies, tools, repairs and depreciation costs.

[0000080420-24-000086:notes:52]
We also have contracts to provide field service inspection, installation, commissioning, modification, and repair services, as well as retrofit and retrofill components for existing systems. If the service contract terms give us the right to invoice the customer for an amount that corresponds directly with the value of our performance completed to date (i.e., a service contract in which we bill a fixed amount for each hour of service provided), then we recognize revenue over time in each reporting period corresponding to the amount that we have the right to invoice. Our performance obligations are satisfied as the work progresses.

[0000080420-24-000086:notes:53]
Revenues from our custom-engineered products and value-added services transferred to customers over time accounted for approximately 95%  and 94% of revenues for the years ended September 30, 2024 and September 30, 2023, respectively.

[0000080420-24-000086:notes:54]
We also have sales orders for spare parts and replacement circuit breakers for switchgear that are obsolete or that are no longer produced by the original manufacturer. Revenues from these sales orders are recognized at the time we fulfill our performance obligation to the customer, which is typically upon shipment and represented approximately 5% and 6% of revenues for the years ended September 30, 2024 and September 30, 2023, respectively.

[0000080420-24-000086:notes:55]
Additionally, some contracts may contain a cancellation clause that could limit the amount of revenue we are able to recognize over time. In these instances, revenue and costs associated with these contracts are deferred and recognized at a point in time when the performance obligation is fulfilled.
Selling and administrative costs incurred in relation to obtaining a contract are typically expensed as incurred. We periodically utilize a third-party sales agent to obtain a contract and will pay a commission to that agent. We record the full commission liability to the third-party sales agents at the order date, with a corresponding deferred asset. As the project progresses, we record commission expense based on percentage of completion rates that correlate to the project and reduce the deferred asset. Once we have been paid by the customer, we pay the commission, and the deferred liability is reduced.
Performance Obligations

[0000080420-24-000086:notes:56]
A performance obligation is a promise in a contract or with a customer to transfer a distinct good or service. A contract’s transaction price is allocated to each distinct performance obligation and recognized as revenue as the performance obligations are satisfied. To determine the proper revenue recognition for contracts, we evaluate whether a contract should be accounted for as more than one performance obligation or, less commonly, whether two or more contracts should be combined and accounted for as one performance obligation. This evaluation of performance obligations requires significant judgment. The majority of our contracts have a single performance obligation where multiple engineered products and services are combined into a single custom-engineered solution. Our contracts include a standard one-year assurance warranty. Occasionally, we provide service-type warranties that will extend the warranty period. These extended warranties qualify as a separate performance obligation, and revenue is deferred and recognized over the warranty period. If we determine during the evaluation of the contract that there are multiple performance obligations, we allocate the transaction price to each performance obligation using our best estimate of the standalone selling price of each distinct good or service in the contract. 
Remaining unsatisfied performance obligations, which we refer to as backlog, represent the estimated transaction price for goods and services for which we have a material right, but work has not been performed.
Contract Estimates

[0000080420-24-000086:notes:57]
Actual revenues and project costs may vary from previous estimates due to changes in a variety of factors. The cost estimation process is based upon the professional knowledge and experience of our engineers, project managers and financial professionals. Factors that are considered in estimating the work to be completed and ultimate contract recovery include the availability and productivity of labor, the nature and complexity of the work to be performed, the availability of materials, and the effect of any delays on our project performance. We periodically review our job performance, job conditions, estimated profitability and final contract settlements, including our estimate of total costs and make revisions to costs and income in the period in which the revisions are probable and reasonably estimable. We bear the risk of cost overruns in most of our contracts, which may result in reduced profits. Whenever revisions of estimated contract costs and contract values indicate that the contract costs will exceed estimated revenues, thus creating a loss, a provision for the total estimated loss is recorded in that period.

[0000080420-24-000086:notes:58]
Variable Consideration

[0000080420-24-000086:notes:59]
It is common for our long-term contracts to contain variable consideration that can either increase or decrease the transaction price. Due to the nature of our contracts, estimating total cost and revenue can be complex and subject to variability due to change orders, back charges, spare parts, early completion bonuses, customer allowances and liquidated damages. We estimate the amount of variable consideration based on the expected value method, which is the sum of the probability-weighted amounts, or the most likely amount method which uses various factors including experience with similar transactions and assessment of our anticipated performance. Variable consideration is included in the transaction price if legally enforceable and to the extent it is probable that a significant reversal of cumulative revenue recognized will not occur once the uncertainty associated with the variable consideration is resolved.

[0000080420-24-000086:notes:60]
Contract Modifications

[0000080420-24-000086:notes:61]
Contracts may be modified for changes in contract specifications and requirements. We consider contract modifications to exist when the modification either creates new or changes the enforceable rights and obligations under the contract. Most of our contract modifications are for goods and services that are not distinct from the existing performance obligation. Contract modifications result in a cumulative catch-up adjustment to revenue based on our measure of progress for the performance obligation.

[0000080420-24-000086:notes:62]
Contract liabilities typically represent advance payments from contractual billing milestones and billings in excess of revenue recognized. It is unusual to have advanced milestone payments with a term greater than one year, which could represent a financing component on the contract.
Our contract assets and liabilities are reported in a net position on a contract-by-contract basis at the end of each reporting period and are generally classified as current.The timing of our invoice process is typically dependent on the completion of certain milestones and contract terms and subject to agreement by our customer. Payment is typically expected within 30 days of invoice. Any uncollected invoiced amounts for our performance obligations recognized over time, including contract retentions, are recorded as accounts receivable in the Consolidated Balance Sheets. Certain contracts allow customers to withhold a small percentage of billings pursuant to retainage provisions, and such amounts are generally due upon completion of the contract and acceptance of the project by the customer. Based on our experience in recent years, the majority of these retainage balances are expected to be collected within approximately twelve months.


## us-gaap:EarningsPerShareTextBlock

[0000080420-24-000086:notes:63]
Earnings Per Share
We compute basic earnings per share by dividing net income by the weighted average number of common shares outstanding during the period. Diluted earnings per common and potential common share include the weighted average of additional shares associated with the incremental effect of dilutive restricted stock and restricted stock units.

[0000080420-24-000086:notes:64]
The following table reconciles basic and diluted weighted average shares used in the computation of earnings per share (in thousands, except per share data):

[0000080420-24-000086:notes:65]
|  | Year Ended September 30, |
|  | 2024 |  | 2023 |  | 2022 |
| Numerator: |  |  |  |  |  |
| Net income | $ | 149,848 |  |  | $ | 54,525 |  |  | $ | 13,737 |  |
| Denominator: |  |  |  |  |  |
| Weighted average basic shares | 11,982 |  |  | 11,879 |  |  | 11,797 |  |
| Dilutive effect of restricted stock and restricted stock units | 206 |  |  | 241 |  |  | 146 |  |
| Weighted average diluted shares | 12,188 |  |  | 12,120 |  |  | 11,943 |  |
| Earnings per share: |  |  |  |  |  |
| Basic | $ | 12.51 |  |  | $ | 4.59 |  |  | $ | 1.16 |  |
| Diluted | $ | 12.29 |  |  | $ | 4.50 |  |  | $ | 1.15 |  |


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0000080420-24-000086:notes:66]
Detail of Selected Balance Sheet Accounts
Inventories

[0000080420-24-000086:notes:67]
The components of inventories are summarized below (in thousands):

[0000080420-24-000086:notes:68]
|  | September 30, |
|  | 2024 |  | 2023 |
| Raw materials, parts and sub-assemblies | $ | 92,314 |  |  | $ | 68,631 |  |
| Work-in-progress | 920 |  |  | 1,379 |  |
| Provision for excess and obsolete inventories | (7,361) |  |  | (6,145) |  |
| Total inventories | $ | 85,873 |  |  | $ | 63,865 |  |

[0000080420-24-000086:notes:69]
Property, plant and equipment are summarized below (in thousands):

[0000080420-24-000086:notes:70]
|  | September 30, |  | Range of |
|  | 2024 |  | 2023 |  | Asset Lives |
| Land | $ | 24,110 |  |  | $ | 21,526 |  |  | — |
| Buildings and improvements | 127,094 |  |  | 121,454 |  |  | 3 – 39 Years |
| Machinery and equipment | 94,889 |  |  | 92,477 |  |  | 3 – 15 Years |
| Furniture and fixtures | 2,885 |  |  | 3,726 |  |  | 3 – 10 Years |
| Construction in process | 3,317 |  |  | 4,129 |  |  | — |
|  | $ | 252,295 |  |  | $ | 243,312 |  |  |  |
| Less: Accumulated depreciation | (148,874) |  |  | (145,687) |  |  |  |
| Total property, plant and equipment, net | $ | 103,421 |  |  | $ | 97,625 |  |  |  |

[0000080420-24-000086:notes:71]
There were no assets under finance lease as of September 30, 2024 or September 30, 2023. Depreciation expense was $6.9 million, $8.6 million and $9.4 million for fiscal years 2024, 2023, and 2022, respectively.

[0000080420-24-000086:notes:72]
On July 1, 2024, we acquired land and buildings in Houston, Texas, for a total cash purchase price of approximately $5.6 million to help further facilitate executing the current backlog as well as planning for modest future volume growth.

[0000080420-24-000086:notes:73]
Accrued Product Warranty

[0000080420-24-000086:notes:74]
Activity in our product warranty accrual consisted of the following (in thousands):

[0000080420-24-000086:notes:75]
|  | September 30, |
|  | 2024 |  | 2023 |
| Balance at beginning of period | $ | 3,305 |  |  | $ | 2,345 |  |
| Increase to warranty expense | 7,525 |  |  | 3,752 |  |
| Deduction for warranty charges | (5,039) |  |  | (2,800) |  |
| Change due to foreign currency translation | 31 |  |  | 8 |  |
| Balance at end of period | $ | 5,822 |  |  | $ | 3,305 |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0000080420-24-000086:notes:76]
Revenue
Revenue Recognition

[0000080420-24-000086:notes:77]
Selling and administrative costs incurred in relation to obtaining a contract are typically expensed as incurred. We periodically utilize a third-party sales agent to obtain a contract and will pay a commission to that agent. We record the full commission liability to the third-party sales agents at the order date, with a corresponding deferred asset. As the project progresses, we record commission expense based on percentage of completion rates that correlate to the project and reduce the deferred asset. Once we have been paid by the customer, we pay the commission, and the deferred liability is reduced.

[0000080420-24-000086:notes:78]
Performance Obligations

[0000080420-24-000086:notes:79]
A performance obligation is a promise in a contract or with a customer to transfer a distinct good or service. A contract’s transaction price is allocated to each distinct performance obligation and recognized as revenue as the performance obligations are satisfied. To determine the proper revenue recognition for contracts, we evaluate whether a contract should be accounted for as more than one performance obligation or, less commonly, whether two or more contracts should be combined and accounted for as one performance obligation. This evaluation of performance obligations requires significant judgment. The majority of our contracts have a single performance obligation where multiple engineered products and services are combined into a single custom-engineered solution. Our contracts include a standard one-year assurance warranty. Occasionally, we provide service-type warranties that will extend the warranty period. These extended warranties qualify as a separate performance obligation, and revenue is deferred and recognized over the warranty period. If we determine during the evaluation of the contract that there are multiple performance obligations, we allocate the transaction price to each performance obligation using our best estimate of the standalone selling price of each distinct good or service in the contract.

[0000080420-24-000086:notes:80]
Remaining unsatisfied performance obligations, which we refer to as backlog, represent the estimated transaction price for goods and services for which we have a material right, but work has not been performed. As of September 30, 2024, we had backlog of $1.3 billion, of which approximately $848.5 million is expected to be recognized as revenue within the next twelve months. Backlog may not be indicative of future operating results as orders may be cancelled or modified by our customers. Our backlog does not include service and maintenance-type contracts for which we have the right to invoice as services are performed.

[0000080420-24-000086:notes:81]
Contract Estimates

[0000080420-24-000086:notes:82]
For the years ended September 30, 2024 and 2023, our operating results were positively impacted by $16.9 million and $13.6 million, respectively, as a result of net changes in contract estimates related to projects in progress at the beginning of the respective period. These changes in estimates resulted primarily from favorable project execution, reduced cost estimates and negotiations of variable consideration, discussed below, as well as revenue recognized from project cancellations and other changes in facts and circumstances during these periods. Project cancellations increased gross profit by $2.2 million and $4.3 million, respectively, for the years ended September 30, 2024 and September 30, 2023. Gross unfavorable changes in contract estimates were immaterial for the years ended September 30, 2024 and 2023.

[0000080420-24-000086:notes:83]
Contract assets and liabilities as of September 30, 2024 and September 30, 2023 are summarized below (in thousands):

[0000080420-24-000086:notes:84]
|  | September 30, |
|  | 2024 |  | 2023 |
| Contract assets | $ | 102,827 |  |  | $ | 60,621 |  |
| Contract liabilities | (287,763) |  |  | (279,796) |  |
| Net contract liability | $ | (184,936) |  |  | $ | (219,175) |  |

[0000080420-24-000086:notes:85]
Our net contract billing position remained a net liability at both September 30, 2024 and September 30, 2023, primarily due to favorable contract billing milestones. We typically allocate a significant percentage of the progress billing to the early stages of the contract. To determine the amount of revenue recognized during the period from contract liabilities, we first allocate revenue to the individual contract liability balance outstanding at the beginning of the period until the revenue exceeds that balance. During the year ended September 30, 2024, we recognized revenue of $246.2 million that was related to contract liabilities outstanding at September 30, 2023.

[0000080420-24-000086:notes:86]
The timing of our invoice process is typically dependent on the completion of certain milestones and contract terms and subject to agreement by our customer. Payment is typically expected within 30 days of invoice. Any uncollected invoiced amounts for our performance obligations recognized over time, including contract retentions, are recorded as accounts receivable in the Consolidated Balance Sheets. Certain contracts allow customers to withhold a small percentage of billings pursuant to retainage provisions, and such amounts are generally due upon completion of the contract and acceptance of the project by the customer. Based on our experience in recent years, the majority of these retainage balances are expected to be collected within approximately twelve months. As of September 30, 2024 and September 30, 2023, we had retention amounts of $7.1 million and $7.4 million, respectively. Of the retained amount at September 30, 2024, $6.1 million is expected to be collected in the next twelve months and is recorded in accounts receivable. The remaining $1.0 million is recorded in other assets.

[0000080420-24-000086:notes:87]
Disaggregation of Revenue

[0000080420-24-000086:notes:88]
The following tables present our disaggregated revenue by geographic destination and market sector for the years ended September 30, 2024, 2023 and 2022 (in thousands):

[0000080420-24-000086:notes:89]
|  | 2024 |  | 2023 |  | 2022 |
| United States | $ | 846,526 |  |  | $ | 557,934 |  |  | $ | 404,973 |  |
| Canada | 106,521 |  |  | 84,090 |  |  | 81,218 |  |
| Europe | 31,388 |  |  | 26,699 |  |  | 17,699 |  |
| Middle East and Africa | 13,440 |  |  | 14,998 |  |  | 20,712 |  |
| Mexico, Central and South America | 7,631 |  |  | 9,399 |  |  | 3,095 |  |
| Asia/Pacific | 6,850 |  |  | 6,188 |  |  | 4,885 |  |
| Total revenues by geographic destination | $ | 1,012,356 |  |  | $ | 699,308 |  |  | $ | 532,582 |  |

[0000080420-24-000086:notes:90]
|  | 2024 |  | 2023 |  | 2022 |
| Oil and gas (excludes petrochemical) | $ | 417,170 |  |  | $ | 273,117 |  |  | $ | 215,235 |  |
| Petrochemical | 185,606 |  |  | 94,188 |  |  | 66,538 |  |
| Electric utility | 186,547 |  |  | 158,400 |  |  | 122,361 |  |
| Commercial and other industrial | 149,899 |  |  | 103,966 |  |  | 56,448 |  |
| Light rail traction power | 22,019 |  |  | 28,112 |  |  | 44,930 |  |
| All others | 51,115 |  |  | 41,525 |  |  | 27,070 |  |
| Total revenues by market sector | $ | 1,012,356 |  |  | $ | 699,308 |  |  | $ | 532,582 |  |


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0000080420-24-000086:notes:91]
Goodwill and Intangible AssetsIn December 2023, we acquired intellectual property for a total consideration of $0.5 million, of which $250 thousand was paid in cash at the acquisition date. The intellectual property is not yet subject to amortization. Our intangible assets also include goodwill of $1.0 million, which is not being amortized. No impairment expense has been recorded for the last three fiscal years.


## us-gaap:LongTermDebtTextBlock

[0000080420-24-000086:notes:92]
Long-Term Debt
U.S. Revolver

[0000080420-24-000086:notes:93]
On October 4, 2023, we entered into a third amendment (the Third Amendment) to our credit agreement with Bank of America, N.A. (as amended, the U.S. Revolver). The Third Amendment which added Texas Capital Bank as Syndication Agent and a lender, increased the amount of the revolving line of credit from $125.0 million to $150.0 million, and extended the expiry date to October 4, 2028. The aggregate commitment of $150.0 million consists of $100.0 million committed by Bank of America and $50.0 million committed by Texas Capital Bank. As amended by the Third Amendment, the lesser of (a) $60.0 million, (b) 60% of available cash, and (c) the aggregate face amount of the issued but undrawn letters of credit that are not cash-secured shall be deducted from consolidated funded indebtedness, when calculating the consolidated net leverage ratio. We have the option to cash collateralize all or a portion of the letters of credit outstanding, which would favorably impact the consolidated funded indebtedness calculation and the consolidated net leverage ratio.

[0000080420-24-000086:notes:94]
On June 26, 2024, in connection with the expected discontinuation of the publication of the Canadian Dollar Offered Rate (CDOR), we further amended the U.S. Revolver by entering into a Canadian benchmark replacement conforming changes amendment with Bank of America, N.A. that added and amended certain terms related to the replacement of the CDOR as a benchmark rate with the forward-looking term rate based on the Canadian Overnight Repo Rate Average. On September 24, 2024, in connection with the expected discontinuation of the publication of the Bloomberg Short-Term Bank Yield Index Rate as administered by the Bloomberg Index Service Limited (BSBY), we further amended the U.S. Revolver by entering into a conforming changes amendment with Bank of America, N.A. that added and amended certain terms related to the replacement of the BSBY as a benchmark rate with the Secured Overnight Financing Rate (SOFR) as administered by the Federal Reserve Bank of New York.

[0000080420-24-000086:notes:95]
As of September 30, 2024, there were no amounts borrowed under the U.S. Revolver, and letters of credit outstanding were $63.8 million. There was $86.2 million available for the issuance of letters of credit and borrowings under the U.S. Revolver as of September 30, 2024.

[0000080420-24-000086:notes:96]
As of September 30, 2024, we are required to maintain certain financial covenants, the most significant of which are a consolidated net leverage ratio less than 3.0 to 1.0 and a consolidated interest coverage ratio of greater than 3.0 to 1.0. Our most restrictive covenant, the consolidated net leverage ratio, is the ratio of earnings before interest, taxes, depreciation, amortization and stock-based compensation (EBITDAS) to funded indebtedness. An increase in indebtedness, which includes letters of credit, or a decrease in EBITDAS could restrict our ability to issue letters of credit or borrow under the U.S. Revolver. Additionally, we must maintain a consolidated cash balance of $60 million at all times, which can be deducted from the letters of credit outstanding as noted above. The U.S. Revolver also contains a "material adverse effect" clause which is a material change in our operations, business, properties, liabilities or condition (financial or otherwise) or a material impairment of our ability to perform our obligations under the U.S. Revolver. As of September 30, 2024, we were in compliance with all of the financial covenants of the U.S. Revolver.

[0000080420-24-000086:notes:97]
The U.S. Revolver allows the Company to elect that any borrowing under the facility bears an interest rate based on either the base rate or the eurocurrency rate, in each case, plus the applicable rate. The base rate is generally the highest of (a) the federal funds rate plus 0.50%, (b) the Bank of America prime rate or (c) the BSBY rate plus 1.00%. The BSBY rate will be replaced by the SOFR rate, effective November 20, 2024. The applicable rate is generally a range from 0% to 2% depending on the type of loan and the Company's consolidated net leverage ratio.

[0000080420-24-000086:notes:98]
The U.S. Revolver is collateralized by a pledge of 100% of the voting capital stock of each of our domestic subsidiaries and 65% of the voting capital stock of each non-domestic subsidiary. The U.S. Revolver provides for customary events of default and carries cross-default provisions with other existing debt agreements. If an event of default (as defined in the U.S. Revolver) occurs and is continuing, on the terms and subject to the conditions set forth in the U.S. Revolver, amounts and letters of credit outstanding under the U.S. Revolver may be accelerated and may become immediately due and payable.

[0000080420-24-000086:notes:99]
Industrial Development Revenue Bonds
We borrowed $8.0 million in October 2001 through a loan agreement funded with proceeds from tax-exempt industrial development revenue bonds (Bonds) for the completion of our Northlake, Illinois facility. The Bonds matured on October 1, 2021, and our final payment of $0.4 million was made upon maturity.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0000080420-24-000086:notes:100]
Commitments and Contingencies
Letters of Credit, Bank Guarantees and Bonds

[0000080420-24-000086:notes:101]
Certain customers require us to post letters of credit, bank guarantees or surety bonds. These security instruments assure that we will perform under the terms of our contract. In the event of default, the counterparty may demand payment from the bank under a letter of credit or bank guarantee, or performance by the surety under a bond. To date, there have been no significant draws or claims related to security instruments for the periods reported. We were contingently liable for letters of credit of $63.8 million as of September 30, 2024. We also had outstanding surety bonds totaling $426.8 million, with additional bonding capacity of $773.2 million available, at September 30, 2024. We have strong surety relationships; however, a change in market conditions or the sureties' assessment of our financial position could cause the sureties to require cash collateralization for undischarged liabilities under the bonds.

[0000080420-24-000086:notes:102]
We have a $20.1 million facility agreement (Facility Agreement) between Powell (UK) Limited and a large international bank that provides Powell (UK) Limited the ability to enter into bank guarantees as well as forward exchange contracts and currency options. At September 30, 2024, we had outstanding guarantees totaling $7.2 million, with additional capacity of $12.9 million available under this Facility Agreement. The Facility Agreement provides for customary events of default and carries cross-default provisions with the U.S. Revolver. If an event of default (as defined in the Facility Agreement) occurs and is continuing, per the terms and subject to the conditions set forth therein, obligations outstanding under the Facility Agreement may be accelerated and declared immediately due and payable. Additionally, we are required to maintain cash collateral for guarantees greater than two years. As of September 30, 2024, we were in compliance with all of the financial covenants of the Facility Agreement.

[0000080420-24-000086:notes:103]
Litigation

[0000080420-24-000086:notes:104]
We are involved in various legal proceedings, claims and other disputes arising from our commercial operations, projects, employees and other matters which, in general, are subject to uncertainties and in which the outcomes are not predictable. Although we can give no assurances about the resolution of pending claims, litigation or other disputes, and the effect such outcomes may have on us, management believes that any ultimate liability resulting from the outcome of such proceedings, to the extent not otherwise provided or covered by insurance, will not have a material adverse effect on our consolidated financial position, results of operations or liquidity.

[0000080420-24-000086:notes:105]
Liquidated Damages

[0000080420-24-000086:notes:106]
Certain of our customer contracts have schedule and performance obligation clauses that, if we fail to meet them, could require us to pay liquidated damages. Each individual contract defines the conditions under which the customer may make a claim against us. As of September 30, 2024, certain contracts had a probable exposure to liquidated damage claims of $4.1 million, which could possibly increase to $4.6 million under certain circumstances. Based on our actual or projected failure to meet these various contractual commitments, $3.2 million has been recorded as a reduction to revenue. We will attempt to obtain change orders, contract extensions or accelerate project completion, which may resolve the potential for any unrecorded liquidated damage claims. Should we fail to achieve relief on some or all of these contractual obligations, we could be required to pay additional liquidated damages, which could negatively impact our future operating results.


## us-gaap:IncomeTaxDisclosureTextBlock

[0000080420-24-000086:notes:107]
Income Taxes 
The components of the income tax provision were as follows (in thousands):

[0000080420-24-000086:notes:108]
|  | Year Ended September 30, |
|  | 2024 |  | 2023 |  | 2022 |
| Current: |  |  |  |  |  |
| Federal | $ | 45,271 |  |  | $ | 18,129 |  |  | $ | 557 |  |
| State | 8,101 |  |  | 4,036 |  |  | 403 |  |
| Foreign | 342 |  |  | 107 |  |  | 7 |  |
|  | 53,714 |  |  | 22,272 |  |  | 967 |  |
| Deferred: |  |  |  |  |  |
| Federal | (11,872) |  |  | (7,458) |  |  | (154) |  |
| State | (1,620) |  |  | (1,499) |  |  | (41) |  |
| Foreign | 6,018 |  |  | 1,110 |  |  | (4,666) |  |
|  | (7,474) |  |  | (7,847) |  |  | (4,861) |  |
| Total income tax provision (benefit) | $ | 46,240 |  |  | $ | 14,425 |  |  | $ | (3,894) |  |

[0000080420-24-000086:notes:109]
Income before income taxes was as follows (in thousands):

[0000080420-24-000086:notes:110]
|  | Year Ended September 30, |
|  | 2024 |  | 2023 |  | 2022 |
| U.S. | $ | 167,887 |  |  | $ | 56,923 |  |  | $ | 3,175 |  |
| Foreign | 28,201 |  |  | 12,027 |  |  | 6,668 |  |
| Income before income taxes | $ | 196,088 |  |  | $ | 68,950 |  |  | $ | 9,843 |  |

[0000080420-24-000086:notes:111]
A reconciliation of the statutory U.S. income tax rate and the effective income tax rate, as computed on earnings before income tax provision (benefit) in each of the three years presented in the Consolidated Statements of Operations, was as follows:

[0000080420-24-000086:notes:112]
|  | Year Ended September 30, |
|  | 2024 |  | 2023 |  | 2022 |
| Statutory rate | 21 | % |  | 21 | % |  | 21 | % |
| State income taxes, net of federal benefit | 3 |  |  | 3 |  |  | 3 |  |
| Research and development credit | (1) |  |  | (2) |  |  | (14) |  |
| Foreign rate differential | — |  |  | — |  |  | 1 |  |
| Valuation allowance | — |  |  | (3) |  |  | (62) |  |
| Deferred tax rate differential | — |  |  | — |  |  | (1) |  |
| Non-deductible expenses | 1 |  |  | 1 |  |  | 9 |  |
| Impact of U.S. global intangible taxes and benefits | 1 |  |  | 1 |  |  | 3 |  |
| Stock-based compensation | (1) |  |  | — |  |  | — |  |
| Effective rate | 24 | % |  | 21 | % |  | (40) | % |

[0000080420-24-000086:notes:113]
Our income tax provision reflects an effective tax rate on pre-tax results of 24% in Fiscal 2024 compared to 21% and negative 40% in Fiscal 2023 and 2022, respectively. The income tax provision for Fiscal 2024 was favorably impacted by the current year estimated Research and Development (R&D) Tax Credit and benefits related to the vesting of restricted stock units. These items were offset by state income tax expense, the tax expense related to certain nondeductible expenses and an income inclusion related to U.S. global intangible income.

[0000080420-24-000086:notes:114]
The income tax provision for Fiscal 2023 was favorably impacted by the reversal of a valuation allowance on the United Kingdom (U.K.) deferred tax assets that were previously fully reserved, in addition to the estimated R&D Tax Credit. These items were offset by state tax expense, the tax expense related to certain nondeductible expenses and an income inclusion related to U.S. global intangible income.

[0000080420-24-000086:notes:115]
The income tax benefit for Fiscal 2022 was largely a result of the reversal of a valuation allowance on the Canadian deferred tax assets that were previously fully reserved, in addition to the estimated R&D Tax Credit. These items were partially offset by the tax expense related to certain nondeductible expenses, the gain on the disposition of a small, non-core division of our Canadian operations and an income inclusion related to U.S. global intangible income.

[0000080420-24-000086:notes:116]
We record and maintain valuation allowances against the deferred tax assets of various foreign jurisdictions until sufficient evidence is available to demonstrate that it is more likely than not that the net deferred tax assets will be recognized. As of each reporting date, management considers new evidence, both positive and negative, that could affect its view of the future realization of deferred tax assets. During Fiscal 2024, management determined that there was sufficient positive evidence to conclude that certain Canadian tax credits in the amount of $0.5 million were realizable. The determination was based on the operating results of the past three years and the anticipated future taxable income from our Canadian operations. The release of the valuation allowance resulted in a $0.5 million tax benefit and a corresponding increase in the deferred tax assets.

[0000080420-24-000086:notes:117]
During the period ended September 30, 2023, management determined that there was sufficient positive evidence to conclude that the U.K. net deferred tax assets of $1.9 million were realizable. This determination was based on operating results over the past three years and anticipated future taxable income from our U.K. operations. The valuation allowance was released accordingly, and a $1.9 million tax benefit and corresponding increase in the deferred tax assets were recorded. Likewise, during the period ended June 30, 2022, management concluded that Canadian net deferred tax assets of $5.9 million were realizable based on current and anticipated market conditions, continued market diversification, operating results over the past three years and anticipated future taxable income from our Canadian operations. The release of the Canadian valuation allowance resulted in a $5.9 million tax benefit and a corresponding increase in the deferred tax assets.

[0000080420-24-000086:notes:118]
We have not recorded deferred income taxes on $23.0 million of undistributed earnings of our foreign subsidiaries because of management’s intent to indefinitely reinvest such earnings. Upon distribution of these earnings in the form of dividends or otherwise, we may be subject to U.S. income taxes and foreign withholding taxes. It is not practical, however, to estimate the amount of taxes that may be payable on the eventual remittance of these earnings.

[0000080420-24-000086:notes:119]
We are subject to income tax in the U.S., multiple state jurisdictions and certain international jurisdictions, primarily the U.K. and Canada. The significant jurisdictions that remain open to examination are as follows: Canada 2017 – 2023, U.K. 2023 and

[0000080420-24-000086:notes:120]
U.S. federal and state 2020 – 2023. As of September 30, 2024, we did not have any state audits underway that would have a material impact on our financial position or results of operations.

[0000080420-24-000086:notes:121]
The tax effect of temporary differences between U.S. GAAP accounting and federal income tax accounting creating deferred income tax assets and liabilities was as follows (in thousands):

[0000080420-24-000086:notes:122]
|  | September 30, |
|  | 2024 |  | 2023 |
| Deferred Tax Assets: |  |  |  |
| Research and experimental expenditures(1) | $ | 12,552 |  |  | $ | 8,118 |  |
| Long-term contracts | 7,480 |  |  | — |  |
| Deferred compensation | 2,868 |  |  | 2,274 |  |
| Uniform capitalization and inventory | 1,511 |  |  | 1,253 |  |
| Credit carryforwards | 1,304 |  |  | 1,378 |  |
| Warranty accrual | 1,304 |  |  | 752 |  |
| Stock-based compensation | 1,269 |  |  | 1,555 |  |
| Net operating loss | 1,248 |  |  | 7,432 |  |
| Reserve for accrued employee benefits | 1,029 |  |  | 988 |  |
| Other | 655 |  |  | 317 |  |
| Deferred tax assets | $ | 31,220 |  |  | $ | 24,067 |  |
| Deferred Tax Liabilities: |  |  |  |
| Depreciation and amortization(1) | $ | (3,773) |  |  | $ | (3,545) |  |
| Retention and other | (1,310) |  |  | (1,491) |  |
| Deferred tax liabilities | $ | (5,083) |  |  | $ | (5,036) |  |
| Less: valuation allowance | (1,599) |  |  | (1,967) |  |
| Net deferred tax asset | $ | 24,538 |  |  | $ | 17,064 |  |
| (1)Certain prior year amounts have been reclassified for consistency with the current year presentation. |

[0000080420-24-000086:notes:123]
We have deferred tax assets related to international net operating loss carryforwards of $0.5 million that are not reserved with a valuation allowance available to offset future tax liabilities in the respective jurisdictions. The majority of these net operating loss carryforwards are related to our Canadian operations and expire beginning in 2035. The remaining unreserved net operating loss carryforwards related to other jurisdictions have an indefinite carryforward period. As of September 30, 2024, the majority of our tax credit carryforwards are fully reserved with a valuation allowance.

[0000080420-24-000086:notes:124]
The net decrease in the total valuation allowance during the year was $0.4 million, which was largely a result of the reversal of the Canadian valuation allowance on certain tax credits. In assessing the realizability of net deferred tax assets, we consider whether it is more likely than not that some portion or all of the net deferred tax assets may not be realized. The ultimate realization of net deferred tax assets is dependent on the generation of future taxable income during the periods in which those temporary differences become deductible.

[0000080420-24-000086:notes:125]
A reconciliation of the beginning and ending amount of the unrecognized tax benefits follows (in thousands):

[0000080420-24-000086:notes:126]
|  | Year Ended September 30, |
|  | 2024 |  | 2023 |  | 2022 |
| Balance at beginning of period | $ | 1,889 |  |  | $ | 1,377 |  |  | $ | 1,409 |  |
| Increases related to tax positions taken during the current period | 460 |  |  | 400 |  |  | 240 |  |
| Increases related to tax positions taken during a prior period | 70 |  |  | 112 |  |  | 92 |  |
| Decreases related to expiration of statute of limitations | (680) |  |  | — |  |  | (327) |  |
| Decreases related to settlement with taxing authorities | — |  |  | — |  |  | (37) |  |
| Balance at end of period | $ | 1,739 |  |  | $ | 1,889 |  |  | $ | 1,377 |  |

[0000080420-24-000086:notes:127]
Included in the balance of unrecognized tax benefits at the end of Fiscal 2024, 2023, and 2022 are $1.5 million, $1.6 million, and $1.1 million, respectively, of tax benefits that, if recognized, would affect the effective tax rate. Our policy is to recognize

[0000080420-24-000086:notes:128]
interest and penalties related to income tax matters as tax expense. The amount of interest and penalty expense recorded for the year ended September 30, 2024 was not material.

[0000080420-24-000086:notes:129]
Management believes that, within the next twelve months, it is reasonably possible that the unrecognized tax benefits will decrease by approximately $0.3 million due to the expiration of certain federal statutes of limitations. We are unable to make reasonably reliable estimates regarding the timing of future cash outflows, if any, associated with the remaining unrecognized tax benefits for the open periods of fiscal years ended September 30, 2021 – 2024.
Management believes that an adequate provision has been made for any adjustments that may result from tax examinations. However, the outcome of tax audits cannot be predicted with certainty. If any issues addressed in our tax audits are resolved in a manner not consistent with management’s expectations, we could be required to adjust our provision for income tax in the period such resolution occurs.


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0000080420-24-000086:notes:130]
Employee Benefit Plans
Retirement Plans

[0000080420-24-000086:notes:131]
We have defined employee contribution plans for substantially all of our U.S. employees (401k plan) and our Canadian employees (Registered Retirement Savings Plan). We recognized expenses under these plans primarily related to matching contributions of $4.4 million, $3.4 million and $3.0 million in Fiscal 2024, 2023 and 2022, respectively.

[0000080420-24-000086:notes:132]
Deferred Compensation

[0000080420-24-000086:notes:133]
We offer a non-qualified deferred compensation plan to a select group of highly compensated individuals (as defined). The plan permits the deferral of up to 50% of a participant’s base salary and 100% of a participant’s annual incentive. The deferrals are held in a separate irrevocable rabbi trust (the Rabbi Trust), which has been established to administer the plan. The Rabbi Trust is intended to be used as a source of funds to match respective funding obligations to participants. The assets of the trust are subject to the claims of our creditors in the event that we become insolvent. Consequently, the Rabbi Trust qualifies as a grantor trust for income tax purposes. We make periodic payments into company-owned life insurance policies held in the Rabbi Trust to fund the expected obligations arising under this plan. Changes in the deferred compensation balance are recorded to compensation expense and reflected within the selling, general and administrative expenses line in the Consolidated Statements of Operations. The plan is not qualified under Section 401 of the Internal Revenue code. We recorded net compensation expense adjustments of $0.2 million related to this plan in Fiscal 2024 and $0.8 million in Fiscal 2023. At September 30, 2024, total assets held in the Rabbi Trust were $12.3 million and recorded in other assets and the liability was $12.0 million and recorded in deferred compensation in our Consolidated Balance Sheets. The $12.3 million of assets held in the Rabbi Trust is invested in company-owned life insurance policies.

[0000080420-24-000086:notes:134]
Retiree Medical Plan

[0000080420-24-000086:notes:135]
We have an unfunded plan that extends health benefits to retirees that are also available to active employees under our existing health plans. The current plan provides coverage for employees with at least 10 years of service who are age 55 or older but less than 65. Effective January 1, 2023, eligibility for postretirement medical benefits changed to age 60 with 10 years of continuous service. Employees who are under age 50 as of January 1, 2023 or who are hired after January 1, 2023 are no longer eligible for postretirement medical benefits. The retiree is required to pay the COBRA rate less a subsidy provided by us based on years of service at the time of retirement. The unfunded liability is recorded in other long-term liabilities and was $0.3 million as of September 30, 2024 and $0.5 million as of September 30, 2023. Our net periodic postretirement costs were immaterial for all periods presented in the Consolidated Statements of Operations. Due to the immateriality of the costs and liabilities of this plan, no further disclosure is being presented.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0000080420-24-000086:notes:136]
Stock-Based Compensation
We have the following stock-based compensation plans:

[0000080420-24-000086:notes:137]
Restricted Stock Units

[0000080420-24-000086:notes:138]
In February 2014, our stockholders approved and adopted at the Annual Meeting of Stockholders the 2014 Equity Incentive Plan (the 2014 Plan), which replaced our 2006 Equity Compensation Plan (2006 Plan). Persons eligible to receive awards under the 2014 Plan include our officers and employees. The 2014 Plan authorizes stock options, stock appreciation rights, restricted stock, restricted stock units (RSUs) and performance-based awards, as well as certain other awards. In February 2023, our stockholders approved an amendment to the 2014 Plan that extended the term of the 2014 Plan by five years and increased the number of shares of common stock that may be issued under the plan by 600,000 shares for a total of 1,350,000 shares.

[0000080420-24-000086:notes:139]
In accordance with the 2014 Plan, the Compensation and Human Capital Committee has authorized grants of RSUs to certain officers and key employees of the Company. The fair value of the RSUs is based on the price of our common stock as reported on the NASDAQ Global Market on the grant dates. Typically, these grants vest over a three-year period from the date of issuance and are a blend of time-based and performance-based shares. Fifty percent of the grant is time-based and vests over a three-year period on each anniversary of the grant date, based on continued employment. The remaining fifty percent of the grant is earned based on the three-year earnings and safety performance of the Company following the grant date. At September 30, 2024, there were 192,011 RSUs outstanding. The RSUs do not have voting rights but do receive dividend equivalents upon vesting, which are accrued quarterly. Additionally, the shares of common stock underlying the RSUs are not considered issued and outstanding until vested and common stock is issued.

[0000080420-24-000086:notes:140]
Total RSU activity (number of shares) for the past fiscal year is summarized below:

[0000080420-24-000086:notes:141]
|  | Number ofRestrictedStockUnits |  | WeightedAverageGrant ValuePer Share |
| Outstanding at September 30, 2023 | 292,497 |  |  | $ | 22.90 |  |
| Granted | 44,670 |  |  | 89.23 |  |
| Vested | (143,431) |  |  | 25.98 |  |
| Forfeited/canceled | (1,725) |  |  | 74.22 |  |
| Outstanding at September 30, 2024 | 192,011 |  |  | $ | 35.38 |  |

[0000080420-24-000086:notes:142]
Restricted Stock

[0000080420-24-000086:notes:143]
In February 2022, our stockholders approved an amendment to the 2014 Non-Employee Director Equity Incentive Plan (the 2014 Director Plan) that extended the term of the 2014 Director Plan by ten years and increased the number of shares of common stock that may be issued under the 2014 Director Plan by 200,000 shares for a total of 350,000 shares. The plan is administered by the Compensation and Human Capital Committee. Eligibility to participate in the plan is limited to those individuals who are members of the Board of Directors of the Company and who are not employees of the Company or any affiliate of the Company.

[0000080420-24-000086:notes:144]
Under the terms of the 2014 Director Plan, the maximum number of shares that may be granted during any calendar year to any individual is 12,000 shares. The total number of shares that may be issued for awards to any single participant during a calendar year for other stock-based awards (excluding stock options and stock appreciation rights) is 4,000 shares. In December 2023, the Company's Compensation and Human Capital Committee revised the non-employee directors' annual restricted stock compensation from a fixed-shares arrangement to a fixed-value arrangement, retrospectively effective on October 1, 2023. Prior to October 1, 2023, each non-employee director received 2,400 restricted shares of the Company’s common stock annually. Fifty percent of the restricted stock granted to each of our non-employee directors was vested immediately, while the remaining fifty percent vested on the anniversary of the grant date. Compensation expense was recognized immediately for the first fifty percent of the restricted stock granted, while compensation expense for the remaining fifty percent was recognized over the remaining vesting period. Subsequent to October 1, 2023, each non-employee director shall receive restricted shares of the Company's common stock valued at $0.1 million annually. The number of granted shares is calculated by dividing the $0.1 million by the average of high and low prices of our common stock on the grant date. The shares shall vest on the earlier of the grant anniversary date or the date of the next annual meeting of stockholders, whichever occurs first.

[0000080420-24-000086:notes:145]
Under this 2014 Director Plan, in February 2024, 4,620 shares of restricted stock were issued to our non-employee directors at a price of $153.81 per share. In February 2023, we issued 16,800 shares of restricted stock to our non-employee directors at a price of $43.22 per share. The total number of shares of common stock available for future awards under the 2014 Director plan

[0000080420-24-000086:notes:146]
was 185,980 shares as of September 30, 2024. At September 30, 2024 and 2023, there were 4,620 shares and 8,400 shares, respectively, of unvested restricted stock outstanding.

[0000080420-24-000086:notes:147]
Compensation Expense

[0000080420-24-000086:notes:148]
Total compensation expense related to restricted stock grants under all plans was $0.6 million, $0.6 million and $0.4 million for the years ended September 30, 2024, 2023 and 2022, respectively. Total compensation expense related to RSUs under all plans was $4.2 million, $4.0 million and $3.7 million for the years ended September 30, 2024, 2023 and 2022, respectively.
We record the amortization of non-vested restricted stock and restricted stock units as an increase to additional paid-in capital. As of September 30, 2024 and 2023, amounts of deferred compensation expense not yet recognized related to non-vested stock and RSUs totaled $2.1 million and $1.4 million, respectively. As of September 30, 2024, the total weighted average remaining contractual life of our non-vested restricted stock and RSUs is approximately five months and 1.23 years, respectively.


## us-gaap:FairValueDisclosuresTextBlock

[0000080420-24-000086:notes:149]
Fair Value Measurements
We measure certain financial assets and liabilities at fair value. Fair value is defined as an “exit price,” which represents the amount that would be received to sell an asset or paid to transfer a liability in an orderly transaction between market participants as of the measurement date. As such, fair value is a market-based measurement that should be determined based on assumptions that market participants would use in valuing an asset or liability. The accounting guidance requires the use of valuation techniques to measure fair value that maximize the use of observable inputs and minimize the use of unobservable inputs. As a basis for considering such assumptions and inputs, a fair value hierarchy has been established that identifies and prioritizes three levels of inputs to be used in measuring fair value.

[0000080420-24-000086:notes:150]
The three levels of the fair value hierarchy are as follows:

[0000080420-24-000086:notes:151]
Level 1 — Observable inputs such as quoted prices (unadjusted) in active markets for identical assets or liabilities.

[0000080420-24-000086:notes:152]
Level 2 — Inputs other than the quoted prices in active markets that are observable either directly or indirectly, including quoted prices for similar assets and liabilities in active markets; quoted prices for identical or similar assets and liabilities in markets that are not active or other inputs that are observable or can be corroborated by observable market data.

[0000080420-24-000086:notes:153]
Level 3 — Unobservable inputs that are supported by little or no market data and require the reporting entity to develop its own assumptions.

[0000080420-24-000086:notes:154]
The following table summarizes the fair value of our assets and liabilities that were accounted for at fair value on a recurring basis as of September 30, 2024 (in thousands):

[0000080420-24-000086:notes:155]
|  | Fair Value Measurements at September 30, 2024 |
|  | Quoted Prices inActive Markets forIdentical Assets(Level 1) |  | Significant OtherObservableInputs(Level 2) |  | SignificantUnobservableInputs(Level 3) |  | Fair Value at September 30, 2024 |
| Assets: |  |  |  |  |  |  |  |
| Cash and cash equivalents | $ | 315,331 |  |  | $ | — |  |  | $ | — |  |  | $ | 315,331 |  |
| Short-term investments | 43,061 |  |  | — |  |  | — |  |  | 43,061 |  |
| Rabbi trust assets | — |  |  | 12,324 |  |  | — |  |  | 12,324 |  |
| Liabilities: |  |  |  |  |  |  |  |
| Deferred compensation | — |  |  | 12,027 |  |  | — |  |  | 12,027 |  |

[0000080420-24-000086:notes:156]
The following table summarizes the fair value of our assets and liabilities that were accounted for at fair value on a recurring basis as of September 30, 2023 (in thousands):

[0000080420-24-000086:notes:157]
|  | Fair Value Measurements at September 30, 2023 |
|  | Quoted Prices inActive Markets forIdentical Assets(Level 1) |  | Significant OtherObservableInputs(Level 2) |  | SignificantUnobservableInputs(Level 3) |  | Fair Value at September 30, 2023 |
| Assets: |  |  |  |  |  |  |  |
| Cash and cash equivalents | $ | 245,875 |  |  | $ | — |  |  | $ | — |  |  | $ | 245,875 |  |
| Short-term investments | 33,134 |  |  | — |  |  | — |  |  | 33,134 |  |
| Rabbi trust assets | — |  |  | 9,117 |  |  | — |  |  | 9,117 |  |
| Liabilities: |  |  |  |  |  |  |  |
| Deferred compensation | — |  |  | 9,145 |  |  | — |  |  | 9,145 |  |

[0000080420-24-000086:notes:158]
Fair value guidance requires certain fair value disclosures to be presented in both interim and annual reports. The estimated fair value amounts of financial instruments have been determined using available market information and valuation methodologies described below.

[0000080420-24-000086:notes:159]
Cash and cash equivalents – Cash and cash equivalents, primarily funds held in money market savings instruments, are reported at their current carrying value, which approximates fair value due to the short-term nature of these instruments and are included in cash and cash equivalents in our Consolidated Balance Sheets.

[0000080420-24-000086:notes:160]
Rabbi trust assets and deferred compensation – We hold investments in an irrevocable rabbi trust for our deferred compensation plan. The assets are primarily related to company-owned life insurance policies and are included in other assets in the accompanying Consolidated Balance Sheets. Because the mutual funds and company-owned life insurance policies are combined in the plan, they are categorized as Level 2 in the fair value measurement hierarchy. The deferred compensation liability represents the investment options that the plan participants have designated to serve as the basis for measurement of the notional value of their accounts. Because the deferred compensation liability is intended to offset the plan assets, it is also categorized as Level 2 in the fair value measurement hierarchy.

[0000080420-24-000086:notes:161]
There were no transfers between levels within the fair value measurement hierarchy during the year ended September 30, 2024.


## us-gaap:LesseeOperatingLeasesTextBlock

[0000080420-24-000086:notes:162]
Leases
Our leases consist primarily of office space and construction equipment. All of our future lease obligations are related to non-cancelable operating leases. The following table provides a summary of lease cost components for the years ended September 30, 2024, 2023 and 2022 respectively (in thousands):

[0000080420-24-000086:notes:163]
| Lease Cost |  | 2024 |  | 2023 |  | 2022 |
| Operating lease cost |  | $ | 920 |  |  | $ | 1,457 |  |  | $ | 2,146 |  |
| Less: sublease income |  | — |  |  | (515) |  |  | (685) |  |
| Variable lease cost(1) |  | 108 |  |  | 369 |  |  | 457 |  |
| Short-term lease cost(2) |  | 2,476 |  |  | 1,864 |  |  | 1,643 |  |
| Total lease cost |  | $ | 3,504 |  |  | $ | 3,175 |  |  | $ | 3,561 |  |
| (1) Variable lease cost represents common area maintenance charges related to our Canadian office space lease. |
| (2) Short-term lease cost includes leases and rentals with initial terms of one year or less. |

[0000080420-24-000086:notes:164]
We recognize operating lease assets and operating lease liabilities representing the present value of the remaining lease payments for leases with initial terms greater than twelve months. Leases with initial terms of twelve months or less are not recorded in our Consolidated Balance Sheets. The following table provides a summary of the operating lease assets and

[0000080420-24-000086:notes:165]
operating lease liabilities included in our Consolidated Balance Sheets as of September 30, 2024 and 2023, respectively (in thousands):

[0000080420-24-000086:notes:166]
|  |  | September 30, |
| Operating Leases |  | 2024 |  | 2023 |
| Assets: |  |  |  |  |
| Operating lease assets, net |  | $ | 1,216 |  |  | $ | 1,436 |  |
| Liabilities: |  |  |  |  |
| Current operating lease liabilities |  | 595 |  |  | 773 |  |
| Long-term operating lease liabilities |  | 621 |  |  | 663 |  |
| Total lease liabilities |  | $ | 1,216 |  |  | $ | 1,436 |  |

[0000080420-24-000086:notes:167]
The following table provides the maturities of our operating lease liabilities as of September 30, 2024 (in thousands):

[0000080420-24-000086:notes:168]
|  |  | Operating Leases |
| 2025 |  | $ | 633 |  |
| 2026 |  | 382 |  |
| 2027 |  | 202 |  |
| 2028 |  | 53 |  |
| 2029 |  | 30 |  |
| Thereafter |  | — |  |
| Total future minimum lease payments |  | $ | 1,300 |  |
| Less: present value discount (imputed interest) |  | (84) |  |
| Present value of lease liabilities |  | $ | 1,216 |  |

[0000080420-24-000086:notes:169]
The weighted average discount rates as of September 30, 2024 and 2023 were 5.44% and 3.32%, respectively. The weighted average remaining lease term was 2.47 years and 2.67 years, respectively, at September 30, 2024 and 2023.


## us-gaap:SegmentReportingDisclosureTextBlock

[0000080420-24-000086:notes:170]
Segment Information
We manage our business as one reportable operating segment related to the development, design, manufacturing and servicing of custom-engineered equipment and systems for the distribution, control and monitoring of electrical energy.

[0000080420-24-000086:notes:171]
Revenues by country represent sales to unaffiliated customers as determined by the ultimate destination of our products and services, summarized for the last three fiscal years by region in the table below (in thousands):

[0000080420-24-000086:notes:172]
|  | Year Ended September 30, |
|  | 2024 |  | 2023 |  | 2022 |
| United States | $ | 846,526 |  |  | $ | 557,934 |  |  | $ | 404,973 |  |
| Canada | 106,521 |  |  | 84,090 |  |  | 81,218 |  |
| Europe | 31,388 |  |  | 26,699 |  |  | 17,699 |  |
| Middle East and Africa | 13,440 |  |  | 14,998 |  |  | 20,712 |  |
| Mexico, Central and South America | 7,631 |  |  | 9,399 |  |  | 3,095 |  |
| Asia/Pacific | 6,850 |  |  | 6,188 |  |  | 4,885 |  |
| Total revenues | $ | 1,012,356 |  |  | $ | 699,308 |  |  | $ | 532,582 |  |

[0000080420-24-000086:notes:173]
Long-lived assets by country consist of property, plant and equipment, net of accumulated depreciation and are determined based on the location of the tangible assets, summarized for the last two fiscal years in the table below (in thousands):

[0000080420-24-000086:notes:174]
|  | September 30, |
|  | 2024 |  | 2023 |
| Long-lived assets: |  |  |  |
| United States | $ | 64,560 |  |  | $ | 58,514 |  |
| Canada | 34,456 |  |  | 35,214 |  |
| United Kingdom | 4,405 |  |  | 3,897 |  |
| Total | $ | 103,421 |  |  | $ | 97,625 |  |


## us-gaap:QuarterlyFinancialInformationTextBlock

[0000080420-24-000086:notes:175]
Quarterly Information
The table below sets forth the unaudited consolidated operating results by fiscal quarter for the years ended September 30, 2024 and 2023 (in thousands, except per share data):

[0000080420-24-000086:notes:176]
|  | 2024 Quarters |
|  | First(1) |  | Second |  | Third |  | Fourth(2) |  | 2024 |
| Revenues | $ | 194,017 |  |  | $ | 255,108 |  |  | $ | 288,168 |  |  | $ | 275,063 |  |  | $ | 1,012,356 |  |
| Gross profit | 48,194 |  |  | 62,720 |  |  | 81,740 |  |  | 80,434 |  |  | 273,088 |  |
| Net income | 24,085 |  |  | 33,488 |  |  | 46,223 |  |  | 46,052 |  |  | 149,848 |  |
| Earnings per share: |  |  |  |  |  |  |  |  |  |
| Basic | $ | 2.02 |  |  | $ | 2.79 |  |  | $ | 3.85 |  |  | $ | 3.84 |  |  | $ | 12.51 |  |
| Diluted | $ | 1.98 |  |  | $ | 2.75 |  |  | $ | 3.79 |  |  | $ | 3.77 |  |  | $ | 12.29 |  |
| (1) The results for the first quarter of Fiscal 2024 demonstrated normal seasonality and were negatively impacted by holidays and work schedules compared to other quarterly periods. |
| (2) The results for the fourth quarter of Fiscal 2024 were positively impacted by project cancellations of $2.2 million. |

[0000080420-24-000086:notes:177]
|  | 2023 Quarters |
|  | First(1) |  | Second(2) |  | Third(3) |  | Fourth(4) |  | 2023 |
| Revenues | $ | 126,858 |  |  | $ | 171,444 |  |  | $ | 192,365 |  |  | $ | 208,641 |  |  | $ | 699,308 |  |
| Gross profit | 19,464 |  |  | 33,437 |  |  | 42,670 |  |  | 51,982 |  |  | 147,553 |  |
| Net income | 1,162 |  |  | 8,473 |  |  | 18,454 |  |  | 26,436 |  |  | 54,525 |  |
| Earnings per share: |  |  |  |  |  |  |  |  |  |
| Basic | $ | 0.10 |  |  | $ | 0.71 |  |  | $ | 1.55 |  |  | $ | 2.22 |  |  | $ | 4.59 |  |
| Diluted | $ | 0.10 |  |  | $ | 0.70 |  |  | $ | 1.52 |  |  | $ | 2.17 |  |  | $ | 4.50 |  |
| (1) The results for the first quarter of Fiscal 2023 demonstrated normal seasonality and were negatively impacted by holidays and work schedules compared to other quarterly periods. |
| (2) The results for the second quarter of Fiscal 2023 were positively impacted by a project cancellation of $1.6 million. |
| (3) The results for the third quarter of Fiscal 2023 were positively impacted by a project cancellation of $1.7 million. |
| (4) The results for the fourth quarter of Fiscal 2023 were positively impacted by project cancellations of $1.0 million and the reversal of a $1.9 million valuation allowance against the U.K. net deferred tax assets. |

[0000080420-24-000086:notes:178]
The sum of the individual earnings per share amounts may not agree with year-to-date earnings per share as each period’s computation is based on the weighted-average number of shares outstanding during the period.


## us-gaap:MergersAcquisitionsAndDispositionsDisclosuresTextBlock

[0000080420-24-000086:notes:179]
Divestiture
On June 30, 2022, we sold a non-core, industrial valve repair and servicing business within our Canadian operations and received proceeds of $4.3 million. We recorded a $2.0 million pre-tax gain on this transaction, which has been presented in other income on our Consolidated Statement of Operations for the year ended September 30, 2022.


## us-gaap:SubsequentEventsTextBlock

[0000080420-24-000086:notes:180]
Subsequent Event
Quarterly Dividend Declared

[0000080420-24-000086:notes:181]
On November 5, 2024, our Board of Directors declared a quarterly cash dividend on our common stock in the amount of $0.2650 per share. The dividend is payable on December 18, 2024 to shareholders of record at the close of business on November 20, 2024.
