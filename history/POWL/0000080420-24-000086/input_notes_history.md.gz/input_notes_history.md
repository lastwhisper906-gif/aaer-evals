# POWL note change history — 0000080420-24-000030 → 0000080420-24-000059


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2024-07-31):
[0000080420-24-000059:note_history:1]
Certain customers require us to post letters of credit, bank guarantees or surety bonds. These security instruments assure that we will perform under the terms of our contract. In the event of default, the counterparty may demand payment from the bank under a letter of credit or bank guarantee, or performance by the surety under a bond. To date, there have been no significant draws or claims related to security instruments for the periods reported. We were contingently liable for letters of credit of $68.4 million as of June 30, 2024. We also had surety bonds totaling $422.1 million that were outstanding, with additional bonding capacity of $777.9 million available, at June 30, 2024. We have strong surety relationships; however, a change in market conditions or the sureties' assessment of our financial position could cause the sureties to require cash collateralization for undischarged liabilities under the bonds.
  (was, 2024-05-01, similarity 0.9901):
[0000080420-24-000030:note_history:1]
Certain customers require us to post letters of credit, bank guarantees or surety bonds. These security instruments assure that we will perform under the terms of our contract. In the event of default, the counterparty may demand payment from the bank under a letter of credit or bank guarantee, or performance by the surety under a bond. To date, there have been no significant draws or claims related to security instruments for the periods reported. We were contingently liable for letters of credit of $87.8 million as of March 31, 2024. We also had surety bonds totaling $481.9 million that were outstanding, with additional bonding capacity of $718.1 million available, at March 31, 2024. We have strong surety relationships; however, a change in market conditions or the sureties' assessment of our financial position could cause the sureties to require cash collateralization for undischarged liabilities under the bonds.

- changed (2024-07-31):
[0000080420-24-000059:note_history:2]
We have a $19.0 million facility agreement (Facility Agreement) between Powell (UK) Limited and a large international bank that provides Powell (UK) Limited the ability to enter into bank guarantees as well as forward exchange contracts and currency options. At June 30, 2024, we had outstanding guarantees totaling $6.4 million, with an additional capacity of $12.6 million available under this Facility Agreement. The Facility Agreement provides for customary events of default and carries cross-default provisions with the U.S. Revolver. If an event of default (as defined in the Facility Agreement) occurs and is continuing, per the terms and subject to the conditions set forth therein, obligations outstanding under the Facility Agreement may be accelerated and declared immediately due and payable. Additionally, we are required to maintain cash collateral for guarantees greater than two years. As of June 30, 2024, we were in compliance with all of the financial covenants of the Facility Agreement.
  (was, 2024-05-01, similarity 0.9904):
[0000080420-24-000030:note_history:2]
We have an $18.9 million facility agreement (Facility Agreement) between Powell (UK) Limited and a large international bank that provides Powell (UK) Limited the ability to enter into bank guarantees as well as forward exchange contracts and currency options. At March 31, 2024, we had outstanding guarantees totaling $7.4 million, with an additional capacity of $11.5 million available under this Facility Agreement. The Facility Agreement provides for customary events of default and carries cross-default provisions with the U.S. Revolver. If an event of default (as defined in the Facility Agreement) occurs and is continuing, per the terms and subject to the conditions set forth therein, obligations outstanding under the Facility Agreement may be accelerated and declared immediately due and payable. Additionally, we are required to maintain cash collateral for guarantees greater than two years. As of March 31, 2024, we were in compliance with all of the financial covenants of the Facility Agreement.

- added (2024-07-31):
[0000080420-24-000059:note_history:3]
Certain of our customer contracts have schedule and performance obligation clauses that, if we fail to meet them, could require us to pay liquidated damages. Each individual contract defines the conditions under which the customer may make a claim against us. As of June 30, 2024, certain contracts had a probable exposure to liquidated damages claims of $2.5 million, which

- added (2024-07-31):
[0000080420-24-000059:note_history:4]
could possibly increase to $2.8 million under certain circumstances. Based on our actual or projected failure to meet these various contractual commitments, $1.7 million has been recorded as a reduction to revenue. We will attempt to obtain change orders, contract extensions or accelerate project completion, which may resolve the potential for any unrecorded liquidated damages claims. Should we fail to achieve relief on some or all of these contractual obligations, we could be required to pay additional liquidated damages, which could negatively impact our future operating results.

- removed (2024-07-31):
[0000080420-24-000030:note_history:5]
Certain of our customer contracts have schedule and performance obligation clauses that, if we fail to meet them, could require us to pay liquidated damages. Each individual contract defines the conditions under which the customer may make a claim against us. As of March 31, 2024, certain contracts had a probable exposure to liquidated damages claims of $1.7 million, which could possibly increase to $2.1 million under certain circumstances. Based on our actual or projected failure to meet these various contractual commitments, $1.0 million has been recorded as a reduction to revenue. We will attempt to obtain change orders, contract extensions or accelerate project completion, which may resolve the potential for any unrecorded liquidated damages claims. Should we fail to achieve relief on some or all of these contractual obligations, we could be required to pay additional liquidated damages, which could negatively impact our future operating results.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureAndSignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- added (2024-07-31):
[0000080420-24-000059:note_history:6]
We develop, design, manufacture and service custom-engineered equipment and systems that distribute, control and monitor the flow of electrical energy and provide protection to motors, transformers and other electrically powered equipment. We are headquartered in Houston, Texas, and serve the oil and gas and petrochemical markets that include onshore and offshore production, hydrogen, carbon capture, liquefied natural gas (LNG) facilities and terminals, pipelines, refineries and petrochemical plants. Additional markets include electric utility, light rail traction power, and commercial and other industrial markets that include end markets such as data centers, mining and metals, and pulp and paper.

- removed (2024-07-31):
[0000080420-24-000030:note_history:7]
We develop, design, manufacture and service custom-engineered equipment and systems that (1) distribute, control and monitor the flow of electrical energy and (2) provide protection to motors, transformers and other electrically powered equipment. We are headquartered in Houston, Texas, and serve the oil and gas and petrochemical markets, which include onshore and offshore production, liquefied natural gas (LNG) facilities and terminals, pipelines, refineries and petrochemical plants. Additional markets include electric utility, data centers, renewable energy, mining and metals, light rail traction power, pulp and paper, and other municipal, commercial and industrial markets.


## us-gaap:LongTermDebtTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2024-07-31):
[0000080420-24-000059:note_history:8]
On October 4, 2023, we entered into a third amendment (the Third Amendment) to our credit agreement with Bank of America, N.A. (as amended, the U.S. Revolver). The Third Amendment added Texas Capital Bank as Syndication Agent and a lender, increased the amount of the revolving line of credit from $125.0 million to $150.0 million, and extended the expiry date to October 4, 2028. The aggregate commitment of $150.0 million consists of $100.0 million committed by Bank of America and $50.0 million committed by Texas Capital Bank. As amended by the Third Amendment, the lesser of (a) $60 million, (b) 60% of available cash, and (c) the aggregate face amount of the issued but undrawn letters of credit that are not cash-secured, shall be deducted from consolidated funded indebtedness, when calculating the consolidated net leverage ratio. We have the option to cash collateralize all or a portion of the letters of credit outstanding, which would favorably impact the consolidated funded indebtedness calculation and the consolidated net leverage ratio. On June 26, 2024, in connection with the expected discontinuation of the publication of the Canadian Dollar Offered Rate (CDOR), we further amended the U.S. Revolver by entering into a Canadian benchmark replacement conforming changes amendment with Bank of America, N.A. that added and amended certain terms related to the replacement of the CDOR as a benchmark rate with the forward-looking term rate based on the Canadian Overnight Repo Rate Average.
  (was, 2024-05-01, similarity 0.7537):
[0000080420-24-000030:note_history:8]
On October 4, 2023, we entered into a third amendment (the Third Amendment) to our credit agreement with Bank of America, N.A. (as amended, the U.S. Revolver). The Third Amendment added Texas Capital Bank as Syndication Agent and a lender, increased the amount of the revolving line of credit from $125.0 million to $150.0 million, and extended the expiry date to October 4, 2028. The aggregate commitment of $150.0 million consists of $100.0 million committed by Bank of America and $50.0 million committed by Texas Capital Bank. As amended by the Third Amendment, the lesser of (a) $60 million, (b) 60% of available cash, and (c) the aggregate face amount of the issued but undrawn letters of credit that are not cash-secured, shall be deducted from consolidated funded indebtedness, when calculating the consolidated net leverage ratio. We have the option to cash collateralize all or a portion of the letters of credit outstanding, which would favorably impact the consolidated funded indebtedness calculation and the consolidated net leverage ratio. As of March 31, 2024, there were no amounts borrowed under the U.S. Revolver, and letters of credit outstanding were $87.8 million. There was $62.2 million available for the issuance of letters of credit and borrowings under the U.S. Revolver as of March 31, 2024.

- added (2024-07-31):
[0000080420-24-000059:note_history:9]
As of June 30, 2024, there were no amounts borrowed under the U.S. Revolver, and letters of credit outstanding were $68.4 million. There was $81.6 million available for the issuance of letters of credit and borrowings under the U.S. Revolver as of June 30, 2024.

- changed (2024-07-31):
[0000080420-24-000059:note_history:10]
As of June 30, 2024, we were in compliance with all of the financial covenants of the U.S. Revolver.
  (was, 2024-05-01, similarity 0.9524):
[0000080420-24-000030:note_history:10]
As of March 31, 2024, we were in compliance with all of the financial covenants of the U.S. Revolver.


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2024-07-31):
[0000080420-24-000059:note_history:11]
The following tables present our disaggregated revenue by geographic destination and market sector for the three and nine months ended June 30, 2024 and 2023 (in thousands):
  (was, 2024-05-01, similarity 0.9576):
[0000080420-24-000030:note_history:11]
The following tables present our disaggregated revenue by geographic destination and market sector for the three and six months ended March 31, 2024 and 2023 (in thousands):

- changed (2024-07-31):
[0000080420-24-000059:note_history:12]
|  | Three months ended June 30, |  | Nine months ended June 30, |
|  | 2024 |  | 2023 |  | 2024 |  | 2023 |
| United States | $ | 243,744 |  |  | $ | 153,258 |  |  | $ | 620,537 |  |  | $ | 387,531 |  |
| Canada | 29,695 |  |  | 21,765 |  |  | 74,205 |  |  | 62,255 |  |
| Europe | 9,464 |  |  | 8,038 |  |  | 24,261 |  |  | 20,125 |  |
| Middle East and Africa | 2,322 |  |  | 3,966 |  |  | 8,400 |  |  | 10,396 |  |
| Mexico, Central and South America | 1,962 |  |  | 3,000 |  |  | 6,778 |  |  | 5,457 |  |
| Asia/Pacific | 981 |  |  | 2,338 |  |  | 3,112 |  |  | 4,903 |  |
| Total revenues by geographic destination | $ | 288,168 |  |  | $ | 192,365 |  |  | $ | 737,293 |  |  | $ | 490,667 |  |
  (was, 2024-05-01, similarity 0.9324):
[0000080420-24-000030:note_history:12]
|  | Three months ended March 31, |  | Six months ended March 31, |
|  | 2024 |  | 2023 |  | 2024 |  | 2023 |
| United States | $ | 216,933 |  |  | $ | 134,161 |  |  | $ | 376,793 |  |  | $ | 234,273 |  |
| Canada | 24,160 |  |  | 21,995 |  |  | 44,510 |  |  | 40,491 |  |
| Europe | 8,265 |  |  | 7,953 |  |  | 14,797 |  |  | 12,087 |  |
| Middle East and Africa | 2,803 |  |  | 4,004 |  |  | 6,078 |  |  | 6,429 |  |
| Mexico, Central and South America | 2,159 |  |  | 1,543 |  |  | 4,816 |  |  | 2,458 |  |
| Asia/Pacific | 788 |  |  | 1,788 |  |  | 2,131 |  |  | 2,564 |  |
| Total revenues by geographic destination | $ | 255,108 |  |  | $ | 171,444 |  |  | $ | 449,125 |  |  | $ | 298,302 |  |

- changed (2024-07-31):
[0000080420-24-000059:note_history:13]
|  | Three months ended June 30, |  | Nine months ended June 30, |
|  | 2024 |  | 2023 |  | 2024 |  | 2023 |
| Oil and gas (excludes petrochemical) | $ | 114,336 |  |  | $ | 73,452 |  |  | $ | 301,792 |  |  | $ | 179,560 |  |
| Petrochemical | 56,784 |  |  | 21,995 |  |  | 135,221 |  |  | 70,372 |  |
| Electric utility | 57,009 |  |  | 43,824 |  |  | 145,214 |  |  | 114,899 |  |
| Commercial and other industrial | 42,044 |  |  | 35,527 |  |  | 101,610 |  |  | 74,846 |  |
| Light rail traction power | 5,322 |  |  | 7,143 |  |  | 14,184 |  |  | 21,532 |  |
| All others | 12,673 |  |  | 10,424 |  |  | 39,272 |  |  | 29,458 |  |
| Total revenues by market sector | $ | 288,168 |  |  | $ | 192,365 |  |  | $ | 737,293 |  |  | $ | 490,667 |  |
  (was, 2024-05-01, similarity 0.9363):
[0000080420-24-000030:note_history:13]
|  | Three months ended March 31, |  | Six months ended March 31, |
|  | 2024 |  | 2023 |  | 2024 |  | 2023 |
| Oil and gas (excludes petrochemical) | $ | 103,820 |  |  | $ | 62,597 |  |  | $ | 187,456 |  |  | $ | 106,107 |  |
| Petrochemical | 50,070 |  |  | 25,887 |  |  | 78,437 |  |  | 48,377 |  |
| Electric utility | 47,502 |  |  | 42,668 |  |  | 88,205 |  |  | 71,075 |  |
| Commercial and other industrial | 34,894 |  |  | 22,270 |  |  | 59,566 |  |  | 39,320 |  |
| Light rail traction power | 4,517 |  |  | 7,317 |  |  | 8,862 |  |  | 14,389 |  |
| All others | 14,305 |  |  | 10,705 |  |  | 26,599 |  |  | 19,034 |  |
| Total revenues by market sector | $ | 255,108 |  |  | $ | 171,444 |  |  | $ | 449,125 |  |  | $ | 298,302 |  |


## us-gaap:RevenueFromContractWithCustomerPolicyTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2024-07-31):
[0000080420-24-000059:note_history:14]
We also have contracts to provide field service inspection, installation, commissioning, modification, and repair services, as well as retrofit and retrofill components for existing systems. If the service contract terms give us the right to invoice the customer for an amount that corresponds directly with the value of our performance completed to date (i.e., a service contract in which we bill a fixed amount for each hour of service provided), then we recognize revenue over time in each reporting period corresponding to the amount that we have the right to invoice. Our performance obligations are satisfied as the work progresses. Revenues from our custom-engineered products and value-added services transferred to customers over time accounted for approximately 96% and 95% of revenues for the three and nine months ended June 30, 2024, respectively, and approximately 94% and 93% of revenues for the three and nine months ended June 30, 2023, respectively.
  (was, 2024-05-01, similarity 0.8602):
[0000080420-24-000030:note_history:14]
We also have contracts to provide field service inspection, installation, commissioning, modification, and repair services, as well as retrofit and retrofill components for existing systems. If the service contract terms give us the right to invoice the customer for an amount that corresponds directly with the value of our performance completed to date (i.e., a service contract in which we bill a fixed amount for each hour of service provided), then we recognize revenue over time in each reporting period corresponding to the amount that we have the right to invoice. Our performance obligations are satisfied as the work progresses. Revenues from our custom-engineered products and value-added services transferred to customers over time accounted for approximately 95% of revenues for the three months ended March 31, 2024, 94% of revenues for the six months ended March 31, 2024, and 93% of revenues for the three and six months ended March 31, 2023.

- changed (2024-07-31):
[0000080420-24-000059:note_history:15]
We also have sales orders for spare parts and replacement circuit breakers for switchgear that are obsolete or that are no longer produced by the original manufacturer. Revenues from these sales orders are recognized at the time we fulfill our performance obligation to the customer, which is typically upon shipment and represented approximately 4% and 5% of revenues for the three and nine months ended June 30, 2024, respectively, and approximately 6% and 7% of revenues for the three and nine months ended June 30, 2023, respectively.
  (was, 2024-05-01, similarity 0.7264):
[0000080420-24-000030:note_history:15]
We also have sales orders for spare parts and replacement circuit breakers for switchgear that are obsolete or that are no longer produced by the original manufacturer. Revenues from these sales orders are recognized at the time we fulfill our performance obligation to the customer, which is typically upon shipment and represented approximately 5% of revenues for the three months ended March 31, 2024, 6% of revenues for the six months ended March 31, 2024, and 7% of revenues for the three and six months ended March 31, 2023.

- changed (2024-07-31):
[0000080420-24-000059:note_history:16]
Contract liabilities typically represent advance payments from contractual billing milestones and billings in excess of revenue recognized. It is unusual to have advanced milestone payments with a term greater than one year, which could represent a financing component of the contract.  
Our contract assets and liabilities are reported in a net position on a contract-by-contract basis at the end of each reporting period and are generally classified as current.The timing of our invoice process is typically dependent on the completion of certain milestones and contract terms and subject to agreement by our customer. Payment is typically expected within 30 days of invoice. Any uncollected invoiced amounts for our performance obligations recognized over time, including contract retentions, are recorded as accounts receivable in the Condensed Consolidated Balance Sheets. Certain contracts allow customers to withhold a small percentage of billings pursuant to retainage provisions, and such amounts are generally due upon completion of the contract and acceptance of the project by the customer. Based on our experience in recent years, the majority of these retainage balances are expected to be collected within approximately twelve months.
  (was, 2024-05-01, similarity 0.9992):
[0000080420-24-000030:note_history:16]
Contract liabilities typically represent advance payments from contractual billing milestones and billings in excess of revenue recognized. It is unusual to have advanced milestone payments with a term greater than one year, which could represent a financing component on the contract.  
Our contract assets and liabilities are reported in a net position on a contract-by-contract basis at the end of each reporting period and are generally classified as current.The timing of our invoice process is typically dependent on the completion of certain milestones and contract terms and subject to agreement by our customer. Payment is typically expected within 30 days of invoice. Any uncollected invoiced amounts for our performance obligations recognized over time, including contract retentions, are recorded as accounts receivable in the Condensed Consolidated Balance Sheets. Certain contracts allow customers to withhold a small percentage of billings pursuant to retainage provisions, and such amounts are generally due upon completion of the contract and acceptance of the project by the customer. Based on our experience in recent years, the majority of these retainage balances are expected to be collected within approximately twelve months.


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2024-07-31):
[0000080420-24-000059:note_history:17]
We also have contracts to provide field service inspection, installation, commissioning, modification, and repair services, as well as retrofit and retrofill components for existing systems. If the service contract terms give us the right to invoice the customer for an amount that corresponds directly with the value of our performance completed to date (i.e., a service contract in which we bill a fixed amount for each hour of service provided), then we recognize revenue over time in each reporting period corresponding to the amount that we have the right to invoice. Our performance obligations are satisfied as the work progresses. Revenues from our custom-engineered products and value-added services transferred to customers over time accounted for approximately 96% and 95% of revenues for the three and nine months ended June 30, 2024, respectively, and approximately 94% and 93% of revenues for the three and nine months ended June 30, 2023, respectively.
  (was, 2024-05-01, similarity 0.8602):
[0000080420-24-000030:note_history:17]
We also have contracts to provide field service inspection, installation, commissioning, modification, and repair services, as well as retrofit and retrofill components for existing systems. If the service contract terms give us the right to invoice the customer for an amount that corresponds directly with the value of our performance completed to date (i.e., a service contract in which we bill a fixed amount for each hour of service provided), then we recognize revenue over time in each reporting period corresponding to the amount that we have the right to invoice. Our performance obligations are satisfied as the work progresses. Revenues from our custom-engineered products and value-added services transferred to customers over time accounted for approximately 95% of revenues for the three months ended March 31, 2024, 94% of revenues for the six months ended March 31, 2024, and 93% of revenues for the three and six months ended March 31, 2023.

- changed (2024-07-31):
[0000080420-24-000059:note_history:18]
We also have sales orders for spare parts and replacement circuit breakers for switchgear that are obsolete or that are no longer produced by the original manufacturer. Revenues from these sales orders are recognized at the time we fulfill our performance obligation to the customer, which is typically upon shipment and represented approximately 4% and 5% of revenues for the three and nine months ended June 30, 2024, respectively, and approximately 6% and 7% of revenues for the three and nine months ended June 30, 2023, respectively.
  (was, 2024-05-01, similarity 0.7264):
[0000080420-24-000030:note_history:18]
We also have sales orders for spare parts and replacement circuit breakers for switchgear that are obsolete or that are no longer produced by the original manufacturer. Revenues from these sales orders are recognized at the time we fulfill our performance obligation to the customer, which is typically upon shipment and represented approximately 5% of revenues for the three months ended March 31, 2024, 6% of revenues for the six months ended March 31, 2024, and 7% of revenues for the three and six months ended March 31, 2023.

- changed (2024-07-31):
[0000080420-24-000059:note_history:19]
Remaining unsatisfied performance obligations, which we refer to as backlog, represent the estimated transaction price for goods and services for which we have a material right, but work has not been performed. As of June 30, 2024, we had backlog of $1.3 billion, of which approximately $841 million is expected to be recognized as revenue within the next twelve months.
  (was, 2024-05-01, similarity 0.9762):
[0000080420-24-000030:note_history:19]
Remaining unsatisfied performance obligations, which we refer to as backlog, represent the estimated transaction price for goods and services for which we have a material right, but work has not been performed. As of March 31, 2024, we had backlog of $1.3 billion, of which approximately $733 million is expected to be recognized as revenue within the next twelve

- changed (2024-07-31):
[0000080420-24-000059:note_history:20]
Backlog may not be indicative of future operating results as orders may be cancelled or modified by our customers. Our backlog does not include service and maintenance-type contracts for which we have the right to invoice as services are performed.
  (was, 2024-05-01, similarity 0.9841):
[0000080420-24-000030:note_history:20]
months. Backlog may not be indicative of future operating results as orders may be cancelled or modified by our customers. Our backlog does not include service and maintenance-type contracts for which we have the right to invoice as services are performed.

- changed (2024-07-31):
[0000080420-24-000059:note_history:21]
For the nine months ended June 30, 2024 and 2023, our operating results were positively impacted by $14.2 million and $13.2 million, respectively, as a result of net changes in contract estimates related to projects in progress at the beginning of the respective period. These changes in estimates resulted primarily from favorable project execution, reduced cost estimates and negotiations of variable consideration, discussed below, as well as revenue recognized from project cancellations and other changes in facts and circumstances during these periods. Project cancellations on two projects increased gross profit for the nine months ended June 30, 2023 by $3.4 million. Gross unfavorable changes in contract estimates were immaterial for both the nine months ended June 30, 2024 and 2023.
  (was, 2024-05-01, similarity 0.741):
[0000080420-24-000030:note_history:21]
For the six months ended March 31, 2024 and 2023, our operating results were positively impacted by $7.8 million and $7.4 million, respectively, as a result of net changes in contract estimates related to projects in progress at the beginning of the respective period. These changes in estimates resulted primarily from favorable project execution, reduced cost estimates and negotiations of variable consideration, discussed below, as well as revenue recognized from project cancellations and other changes in facts and circumstances during these periods. Gross unfavorable changes in contract estimates were immaterial for both the six months ended March 31, 2024 and 2023.

- changed (2024-07-31):
[0000080420-24-000059:note_history:22]
Contract liabilities typically represent advance payments from contractual billing milestones and billings in excess of revenue recognized. It is unusual to have advanced milestone payments with a term greater than one year, which could represent a financing component of the contract.
  (was, 2024-05-01, similarity 0.9965):
[0000080420-24-000030:note_history:22]
Contract liabilities typically represent advance payments from contractual billing milestones and billings in excess of revenue recognized. It is unusual to have advanced milestone payments with a term greater than one year, which could represent a financing component on the contract.

- changed (2024-07-31):
[0000080420-24-000059:note_history:23]
Contract assets and liabilities as of June 30, 2024 and September 30, 2023 are summarized below (in thousands):
  (was, 2024-05-01, similarity 0.9557):
[0000080420-24-000030:note_history:23]
Contract assets and liabilities as of March 31, 2024 and September 30, 2023 are summarized below (in thousands):

- changed (2024-07-31):
[0000080420-24-000059:note_history:24]
|  | June 30, 2024 |  | September 30, 2023 |
| Contract assets | $ | 90,955 |  |  | $ | 60,621 |  |
| Contract liabilities | (282,924) |  |  | (279,796) |  |
| Net contract liability | $ | (191,969) |  |  | $ | (219,175) |  |
  (was, 2024-05-01, similarity 0.9736):
[0000080420-24-000030:note_history:24]
|  | March 31, 2024 |  | September 30, 2023 |
| Contract assets | $ | 75,010 |  |  | $ | 60,621 |  |
| Contract liabilities | (315,699) |  |  | (279,796) |  |
| Net contract liability | $ | (240,689) |  |  | $ | (219,175) |  |

- changed (2024-07-31):
[0000080420-24-000059:note_history:25]
Our net contract billing position remained a net liability at both June 30, 2024 and September 30, 2023, primarily due to favorable contract billing milestones. We typically allocate a significant percentage of the progress billing to the early stages of the contract. To determine the amount of revenue recognized during the period from contract liabilities, we first allocate revenue to the individual contract liability balance outstanding at the beginning of the period until the revenue exceeds that balance. During the nine months ended June 30, 2024, we recognized revenue of $228.9 million that was related to contract liabilities outstanding at September 30, 2023.
  (was, 2024-05-01, similarity 0.8481):
[0000080420-24-000030:note_history:25]
Our net contract billing position remained a net liability at both March 31, 2024 and September 30, 2023, primarily due to favorable contract billing milestones. We typically allocate a significant percentage of the progress billing to the early stages of the contract. These favorable billing milestones are driving the increase in the net contract liability at March 31, 2024. To determine the amount of revenue recognized during the period from contract liabilities, we first allocate revenue to the individual contract liability balance outstanding at the beginning of the period until the revenue exceeds that balance. During the six months ended March 31, 2024, we recognized revenue of $185.4 million that was related to contract liabilities outstanding at September 30, 2023.

- changed (2024-07-31):
[0000080420-24-000059:note_history:26]
The timing of our invoice process is typically dependent on the completion of certain milestones and contract terms and subject to agreement by our customer. Payment is typically expected within 30 days of invoice. Any uncollected invoiced amounts for our performance obligations recognized over time, including contract retentions, are recorded as accounts receivable in the Condensed Consolidated Balance Sheets. Certain contracts allow customers to withhold a small percentage of billings pursuant to retainage provisions, and such amounts are generally due upon completion of the contract and acceptance of the project by the customer. Based on our experience in recent years, the majority of these retainage balances are expected to be collected within approximately twelve months. As of June 30, 2024 and September 30, 2023, we had retention amounts of $6.6 million and $7.4 million, respectively. Of the retained amount at June 30, 2024, $5.9 million is expected to be collected in the next twelve months and is recorded in accounts receivable. The remaining $0.7 million is recorded in other assets.
  (was, 2024-05-01, similarity 0.8262):
[0000080420-24-000030:note_history:26]
The timing of our invoice process is typically dependent on the completion of certain milestones and contract terms and subject to agreement by our customer. Payment is typically expected within 30 days of invoice. Any uncollected invoiced amounts for our performance obligations recognized over time, including contract retentions, are recorded as accounts receivable in the Condensed Consolidated Balance Sheets. Certain contracts allow customers to withhold a small percentage of billings pursuant to retainage provisions, and such amounts are generally due upon completion of the contract and acceptance of the project by the customer. Based on our experience in recent years, the majority of these retainage balances are expected to be collected within approximately twelve months. As of both March 31, 2024 and September 30, 2023, we had retention amounts of $7.4 million. Of the retained amount at March 31, 2024, $7.1 million is expected to be collected in the next twelve months and is recorded in accounts receivable. The remaining $0.3 million is recorded in other assets.

- changed (2024-07-31):
[0000080420-24-000059:note_history:27]
The following tables present our disaggregated revenue by geographic destination and market sector for the three and nine months ended June 30, 2024 and 2023 (in thousands):
  (was, 2024-05-01, similarity 0.9576):
[0000080420-24-000030:note_history:27]
The following tables present our disaggregated revenue by geographic destination and market sector for the three and six months ended March 31, 2024 and 2023 (in thousands):

- changed (2024-07-31):
[0000080420-24-000059:note_history:28]
|  | Three months ended June 30, |  | Nine months ended June 30, |
|  | 2024 |  | 2023 |  | 2024 |  | 2023 |
| United States | $ | 243,744 |  |  | $ | 153,258 |  |  | $ | 620,537 |  |  | $ | 387,531 |  |
| Canada | 29,695 |  |  | 21,765 |  |  | 74,205 |  |  | 62,255 |  |
| Europe | 9,464 |  |  | 8,038 |  |  | 24,261 |  |  | 20,125 |  |
| Middle East and Africa | 2,322 |  |  | 3,966 |  |  | 8,400 |  |  | 10,396 |  |
| Mexico, Central and South America | 1,962 |  |  | 3,000 |  |  | 6,778 |  |  | 5,457 |  |
| Asia/Pacific | 981 |  |  | 2,338 |  |  | 3,112 |  |  | 4,903 |  |
| Total revenues by geographic destination | $ | 288,168 |  |  | $ | 192,365 |  |  | $ | 737,293 |  |  | $ | 490,667 |  |
  (was, 2024-05-01, similarity 0.9324):
[0000080420-24-000030:note_history:28]
|  | Three months ended March 31, |  | Six months ended March 31, |
|  | 2024 |  | 2023 |  | 2024 |  | 2023 |
| United States | $ | 216,933 |  |  | $ | 134,161 |  |  | $ | 376,793 |  |  | $ | 234,273 |  |
| Canada | 24,160 |  |  | 21,995 |  |  | 44,510 |  |  | 40,491 |  |
| Europe | 8,265 |  |  | 7,953 |  |  | 14,797 |  |  | 12,087 |  |
| Middle East and Africa | 2,803 |  |  | 4,004 |  |  | 6,078 |  |  | 6,429 |  |
| Mexico, Central and South America | 2,159 |  |  | 1,543 |  |  | 4,816 |  |  | 2,458 |  |
| Asia/Pacific | 788 |  |  | 1,788 |  |  | 2,131 |  |  | 2,564 |  |
| Total revenues by geographic destination | $ | 255,108 |  |  | $ | 171,444 |  |  | $ | 449,125 |  |  | $ | 298,302 |  |

- changed (2024-07-31):
[0000080420-24-000059:note_history:29]
|  | Three months ended June 30, |  | Nine months ended June 30, |
|  | 2024 |  | 2023 |  | 2024 |  | 2023 |
| Oil and gas (excludes petrochemical) | $ | 114,336 |  |  | $ | 73,452 |  |  | $ | 301,792 |  |  | $ | 179,560 |  |
| Petrochemical | 56,784 |  |  | 21,995 |  |  | 135,221 |  |  | 70,372 |  |
| Electric utility | 57,009 |  |  | 43,824 |  |  | 145,214 |  |  | 114,899 |  |
| Commercial and other industrial | 42,044 |  |  | 35,527 |  |  | 101,610 |  |  | 74,846 |  |
| Light rail traction power | 5,322 |  |  | 7,143 |  |  | 14,184 |  |  | 21,532 |  |
| All others | 12,673 |  |  | 10,424 |  |  | 39,272 |  |  | 29,458 |  |
| Total revenues by market sector | $ | 288,168 |  |  | $ | 192,365 |  |  | $ | 737,293 |  |  | $ | 490,667 |  |
  (was, 2024-05-01, similarity 0.9363):
[0000080420-24-000030:note_history:29]
|  | Three months ended March 31, |  | Six months ended March 31, |
|  | 2024 |  | 2023 |  | 2024 |  | 2023 |
| Oil and gas (excludes petrochemical) | $ | 103,820 |  |  | $ | 62,597 |  |  | $ | 187,456 |  |  | $ | 106,107 |  |
| Petrochemical | 50,070 |  |  | 25,887 |  |  | 78,437 |  |  | 48,377 |  |
| Electric utility | 47,502 |  |  | 42,668 |  |  | 88,205 |  |  | 71,075 |  |
| Commercial and other industrial | 34,894 |  |  | 22,270 |  |  | 59,566 |  |  | 39,320 |  |
| Light rail traction power | 4,517 |  |  | 7,317 |  |  | 8,862 |  |  | 14,389 |  |
| All others | 14,305 |  |  | 10,705 |  |  | 26,599 |  |  | 19,034 |  |
| Total revenues by market sector | $ | 255,108 |  |  | $ | 171,444 |  |  | $ | 449,125 |  |  | $ | 298,302 |  |


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: tag_name, score: 1.0

- added (2024-07-31):
[0000080420-24-000059:note_history:30]
Subsequent Events
Cash Acquisition of Property, Plant and Equipment

- added (2024-07-31):
[0000080420-24-000059:note_history:31]
On July 1, 2024, we acquired land and buildings in Houston, Texas, for a total cash purchase price of approximately $5.5 million to help further facilitate executing the current backlog as well as planning for modest future volume growth.

- added (2024-07-31):
[0000080420-24-000059:note_history:32]
Hurricane Beryl

- added (2024-07-31):
[0000080420-24-000059:note_history:33]
During the second week of July 2024, operations across our three facilities located in Houston, Texas, experienced a temporary power outage and subsequent shutdown of our operations resulting from Hurricane Beryl. These facilities resumed limited operations within the same week. We are evaluating the potential financial impact, if any, associated with this event.

- changed (2024-07-31):
[0000080420-24-000059:note_history:34]
Quarterly Dividend Declared
  (was, 2024-05-01, similarity 0.75):
[0000080420-24-000030:note_history:34]
Subsequent Events
Quarterly Dividend Declared

- added (2024-07-31):
[0000080420-24-000059:note_history:35]
On July 30, 2024, our Board of Directors declared a quarterly cash dividend on our common stock in the amount of $0.2650 per share. The dividend is payable on September 18, 2024 to stockholders of record at the close of business on August 14, 2024.

- removed (2024-07-31):
[0000080420-24-000030:note_history:36]
On April 30, 2024, our Board of Directors declared a quarterly cash dividend on our common stock in the amount of $0.2650 per share. The dividend is payable on June 12, 2024 to stockholders of record at the close of business on May 15, 2024.
