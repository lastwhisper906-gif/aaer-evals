# POWL 8-K — 0000080420-24-000084 filed 2024-11-19

## item codes, every 8-K on or before 2024-11-20

- 2024-11-19 0000080420-24-000084 — 2.02, 9.01
- 2024-11-05 0000080420-24-000081 — 8.01, 9.01
- 2024-07-30 0000080420-24-000057 — 2.02, 8.01, 9.01
- 2024-04-30 0000080420-24-000026 — 2.02, 8.01, 9.01
- 2024-02-15 0000080420-24-000014 — 5.02, 5.07
- 2024-01-30 0000080420-24-000005 — 2.02, 8.01, 9.01
- 2024-01-08 0000080420-24-000002 — 5.02
- 2023-12-05 0000080420-23-000047 — 2.02, 9.01
- 2023-11-03 0000080420-23-000044 — 8.01, 9.01
- 2023-10-11 0000080420-23-000041 — 1.01, 2.03
- 2023-08-01 0000080420-23-000036 — 2.02, 8.01, 9.01
- 2023-05-19 0001193125-23-149334 — 5.07 — amendment of 0000080420-23-000011
- 2023-05-03 0000080420-23-000025 — 2.02, 8.01, 9.01
- 2023-04-06 0000080420-23-000020 — 1.01, 2.03, 9.01
- 2023-04-05 0000080420-23-000018 — 5.02
- 2023-02-16 0000080420-23-000011 — 5.02, 5.07, 9.01
- 2023-01-31 0000080420-23-000004 — 2.02, 8.01
- 2022-12-05 0000080420-22-000034 — 2.02, 9.01
- 2022-08-02 0000080420-22-000030 — 2.02, 8.01, 9.01
- 2022-05-13 0000080420-22-000024 — 5.02, 9.01
- 2022-05-03 0000080420-22-000016 — 2.02, 9.01
- 2022-05-03 0000080420-22-000015 — 8.01, 9.01
- 2022-02-17 0000080420-22-000010 — 5.07
- 2022-02-08 0000080420-22-000005 — 2.02, 9.01
- 2022-02-01 0000080420-22-000002 — 8.01, 9.01
- 2021-12-07 0000080420-21-000043 — 2.02, 9.01
- 2021-08-03 0000080420-21-000036 — 2.02, 8.01, 9.01
- 2021-05-04 0000080420-21-000026 — 2.02, 8.01, 9.01
- 2021-03-16 0001193125-21-082878 — 1.01, 2.03, 9.01
- 2021-03-05 0000080420-21-000021 — 5.02, 8.01, 9.01
- 2021-02-26 0000080420-21-000018 — 5.03
- 2021-02-18 0000080420-21-000016 — 5.07
- 2021-02-02 0000080420-21-000010 — 2.02, 8.01, 9.01
- 2020-12-08 0000080420-20-000032 — 2.02, 9.01
- 2020-11-12 0000080420-20-000030 — 8.01, 9.01
- 2020-08-04 0000080420-20-000024 — 2.02, 8.01, 9.01
- 2020-05-05 0000080420-20-000017 — 2.02, 8.01, 9.01
- 2020-02-21 0000080420-20-000008 — 5.07
- 2020-02-04 0000080420-20-000003 — 2.02, 8.01, 9.01
- 2019-12-04 0001193125-19-306243 — 2.02, 9.01
- 2019-11-08 0000080420-19-000032 — 8.01, 9.01
- 2019-10-03 0000080420-19-000030 — 1.01, 2.03
- 2019-09-24 0000080420-19-000028 — 8.01, 9.01
- 2019-08-06 0000080420-19-000022 — 2.02, 8.01, 9.01
- 2019-05-08 0000080420-19-000017 — 5.02, 9.01
- 2019-05-07 0000080420-19-000011 — 2.02, 8.01, 9.01
- 2019-02-22 0001193125-19-048366 — 5.07
- 2019-02-05 0000080420-19-000003 — 2.02, 8.01
- 2018-12-21 0000080420-18-000038 — 5.02, 9.01
- 2018-12-12 0000080420-18-000031 — 2.02
- 2018-11-05 0000080420-18-000029 — 8.01, 9.01
- 2018-11-01 0000080420-18-000027 — 5.02, 8.01, 9.01
- 2018-10-01 0000080420-18-000024 — 5.02
- 2018-08-07 0000080420-18-000020 — 2.02, 8.01
- 2018-05-15 0000080420-18-000016 — 5.02, 8.01
- 2018-05-09 0000080420-18-000011 — 2.02, 8.01
- 2018-02-22 0000080420-18-000009 — 5.07
- 2018-02-06 0000080420-18-000003 — 2.02, 8.01
- 2017-12-27 0001193125-17-379928 — 5.02
- 2017-12-05 0000080420-17-000028 — 2.02, 9.01
- 2017-11-08 0000080420-17-000024 — 8.01, 9.01
- 2017-11-03 0000080420-17-000022 — 5.02
- 2017-08-09 0000080420-17-000017 — 2.02, 8.01
- 2017-06-30 0000080420-17-000014 — 1.01, 9.01
- 2017-05-03 0000080420-17-000006 — 2.02, 8.01, 9.01
- 2017-02-23 0000080420-17-000004 — 5.07
- 2017-02-08 0001628280-17-000965 — 2.02 — amendment of 0001628280-17-000949
- 2017-02-07 0001628280-17-000949 — 2.01, 8.01, 9.01
- 2016-12-07 0001193125-16-787354 — 2.02, 9.01
- 2016-11-01 0001193125-16-755475 — 8.01, 9.01
- 2016-09-30 0001193125-16-726999 — 5.02, 8.01, 9.01
- 2016-08-03 0001193125-16-669308 — 2.02, 8.01, 9.01
- 2016-05-04 0001193125-16-576528 — 2.02, 8.01, 9.01
- 2016-02-25 0001193125-16-477896 — 5.07
- 2016-02-03 0001193125-16-449052 — 2.02, 8.01, 9.01
- 2015-12-31 0001193125-15-418363 — 5.02, 7.01, 9.01
- 2015-12-02 0001193125-15-393109 — 2.02, 9.01
- 2015-11-05 0001193125-15-368085 — 8.01, 9.01
- 2015-09-25 0001193125-15-329031 — 5.02
- 2015-08-05 0001193125-15-277912 — 2.02, 8.01, 9.01
- 2015-05-06 0001193125-15-174291 — 2.02, 8.01, 9.01
- 2015-03-06 0001193125-15-081070 — 5.02
- 2015-03-02 0001193125-15-072946 — 5.07
- 2015-02-03 0001193125-15-031772 — 2.02, 8.01, 9.01
- 2014-12-18 0001193125-14-446513 — 8.01, 9.01
- 2014-12-03 0001193125-14-431745 — 2.02, 9.01
- 2014-11-05 0001193125-14-397955 — 8.01, 9.01
- 2014-09-26 0001193125-14-353741 — 7.01, 9.01
- 2014-08-05 0001193125-14-296001 — 2.02, 8.01, 9.01
- 2014-05-07 0001193125-14-187496 — 2.02, 8.01, 9.01
- 2014-03-03 0001193125-14-079843 — 5.02, 5.07
- 2014-02-05 0001193125-14-036633 — 2.02, 8.01, 9.01
- 2014-01-17 0001193125-14-014351 — 1.01, 8.01, 9.01
- 2014-01-06 0001193125-14-002795 — 1.01, 2.03
- 2013-12-06 0001564590-13-001411 — 2.02, 9.01
- 2013-12-05 0001564590-13-001406 — 5.02, 8.01, 9.01
- 2013-11-07 0001193125-13-432950 — 8.01, 9.01
- 2013-08-07 0001193125-13-324337 — 2.02, 9.01
- 2013-05-08 0001193125-13-206800 — 2.02, 9.01
- 2013-02-22 0001193125-13-070971 — 5.02, 5.07
- 2013-02-06 0001193125-13-040556 — 2.02, 9.01
- 2012-12-18 0001193125-12-506417 — 5.02, 9.01
- 2012-12-05 0001193125-12-491749 — 2.02, 9.01
- 2012-10-12 0001193125-12-421889 — 3.03, 5.02, 5.03, 9.01
- 2012-08-09 0001193125-12-344617 — 5.02, 8.01, 9.01
- 2012-08-08 0001193125-12-343630 — 2.02, 9.01
- 2012-05-09 0001193125-12-221356 — 2.02, 9.01
- 2012-02-08 0001193125-12-046560 — 2.02, 9.01
- 2011-12-08 0001193125-11-334810 — 2.02, 9.01
- 2011-11-08 0000950123-11-096524 — 2.02, 2.06, 4.02, 9.01
- 2011-10-14 0000950123-11-090124 — 5.02
- 2011-10-06 0000950123-11-088969 — 5.02
- 2011-09-19 0000950123-11-085224 — 5.02, 9.01
- 2011-09-15 0000950123-11-084806 — 5.02, 9.01
- 2011-08-04 0000950123-11-072788 — 2.02, 9.01
- 2011-07-22 0000950123-11-067402 — 5.07
- 2011-05-24 0000950123-11-053550 — 1.01, 2.03, 9.01
- 2011-05-04 0000950123-11-044561 — 2.02, 9.01
- 2011-02-02 0000950123-11-008188 — 2.02, 9.01
- 2010-12-08 0000950123-10-111987 — 2.02, 9.01
- 2010-08-05 0000950123-10-073114 — 2.02, 9.01
- 2010-05-18 0000950123-10-050900 — 5.02
- 2010-05-05 0000950123-10-044499 — 2.02, 9.01
- 2010-02-03 0000950123-10-008278 — 2.02, 9.01
- 2009-12-21 0000950123-09-072269 — 1.01, 2.01, 2.03, 8.01, 9.01
- 2009-12-09 0000950123-09-069525 — 2.02, 9.01
- 2009-10-27 0000950123-09-053501 — 1.01, 8.01, 9.01
- 2009-08-04 0000950123-09-029476 — 2.02, 9.01
- 2009-05-06 0000950129-09-001498 — 2.02, 9.01
- 2009-03-05 0000950129-09-000749 — 1.01, 9.01
- 2009-02-10 0000950129-09-000349 — 2.02, 9.01
- 2008-12-10 0000950134-08-021934 — 2.02, 9.01
- 2008-08-06 0000950129-08-004267 — 2.02, 9.01
- 2008-07-24 0000950129-08-004063 — 1.01, 5.02, 8.01, 9.01
- 2008-06-16 0000950129-08-003500 — 9.01 — amendment of 0000950134-06-015374
- 2008-06-05 0000950129-08-003378 — 5.02, 9.01
- 2008-05-08 0000950129-08-002843 — 2.02, 9.01
- 2008-02-06 0000950129-08-000533 — 2.02, 9.01
- 2007-12-19 0000950129-07-006277 — 1.01, 2.03, 9.01
- 2007-12-06 0000950129-07-006003 — 2.02, 9.01
- 2007-08-21 0000950129-07-004181 — 2.02, 9.01
- 2007-05-31 0000950129-07-002810 — 2.02, 9.01
- 2007-05-21 0000950129-07-002668 — 2.02, 3.01, 4.02, 9.01
- 2007-04-16 0000950129-07-002002 — 2.02, 4.02, 9.01
- 2007-03-01 0000950129-07-001104 — 5.02, 8.01, 9.01
- 2007-02-08 0000950129-07-000451 — 2.02, 9.01
- 2006-12-08 0000950129-06-010041 — 2.02, 9.01
- 2006-09-08 0000950129-06-008379 — 2.02, 9.01
- 2006-08-09 0000950134-06-015374 — 1.01, 2.01, 8.01, 9.01
- 2006-06-08 0000950129-06-006127 — 2.02, 9.01
- 2006-03-09 0000950129-06-002455 — 2.02, 9.01
- 2005-12-16 0000950129-05-012031 — 2.02, 5.03, 9.01
- 2005-09-13 0000950129-05-009181 — 2.01, 9.01 — amendment of 0000950129-05-006889
- 2005-09-12 0000950129-05-009151 — 2.02, 9.01
- 2005-07-06 0000950129-05-006889 — 1.01, 1.02, 2.01, 2.03, 9.01
- 2005-06-10 0000950129-05-006128 — 2.02, 9.01
- 2005-04-20 0000080420-05-000031 — 5.02
- 2005-03-11 0000080420-05-000024 — 9.01
- 2005-02-25 0000080420-05-000018 — 7.01, 9.01
- 2005-01-21 0000080420-05-000009 — 7.01, 9.01
- 2004-12-17 0000080420-04-000049 — 2.02, 9.01
- 2004-11-01 0000080420-04-000045 — 8.01, 9.01
- 2004-10-08 0001169232-04-005133 — 2.05
- 2004-09-14 0000080420-04-000037 — 5.02
- 2004-09-02 0000080420-04-000030 — 2.02, 9.01
- 2004-06-08 0000080420-04-000021 — 7
- 2004-05-13 0000080420-04-000019 — 4
- 2004-02-27 0000080420-04-000013 — 7
- 2003-12-16 0000950129-03-006136 — 12, 7
- 2003-08-29 0000950129-03-004531 — 12, 7
- 2003-06-03 0000950129-03-003035 — 7, 9
- 2003-05-15 0000950129-03-002812 — 7, 9
- 2002-05-29 0000950129-02-002795 — 4
- 2000-12-21 0000950129-00-006093 — 5, 7
- 1998-09-04 0000950129-98-003802 — 5
- 1996-08-09 0000950129-96-001705 — 2, 7

## late-filing notifications on or before 2024-11-20

- 2007-05-11 0000950129-07-002494 — NT 10-Q, for the period ended 2007-03-31
- 2005-01-18 0000080420-05-000004 — NT 10-K, for the period ended 2004-10-31

## item 2.02 — earnings release, exhibit 99.1

[0000080420-24-000084:8k_2_02:1]
EX-99.1
2
ex991-powlq4xfy2024earning.htm
EX-99.1

[0000080420-24-000084:8k_2_02:2]
Document

[0000080420-24-000084:8k_2_02:3]
Exhibit 99.1

[0000080420-24-000084:8k_2_02:4]
PRESS RELEASE

[0000080420-24-000084:8k_2_02:5]
| For Immediate Release |  |  | Contact: | Michael Metcalf, CFO |
|  |  |  |  | Powell Industries, Inc. |
|  |  |  |  | 713-947-4422 |
|  |  |  |  | Robert Winters or Ryan Coleman |
|  |  |  |  | Alpha IR Group |
|  |  |  |  | POWL@alpha-ir.com |
|  |  |  |  | 312-445-2870 |

[0000080420-24-000084:8k_2_02:6]
POWELL INDUSTRIES ANNOUNCES FOURTH QUARTER AND FULL YEAR FISCAL 2024 RESULTS

[0000080420-24-000084:8k_2_02:7]
HOUSTON — November 19, 2024 — Powell Industries, Inc. (NASDAQ: POWL), a leading supplier of custom-engineered solutions for the management, control and distribution of electrical energy, today announced results for the fourth quarter and full year fiscal 2024 ended September 30, 2024. All comparisons are to the comparable periods of fiscal 2023, unless otherwise noted.

[0000080420-24-000084:8k_2_02:8]
Fourth Quarter Key Financial Highlights:

[0000080420-24-000084:8k_2_02:9]
•Revenues totaled $275 million, an increase of 32%;

[0000080420-24-000084:8k_2_02:10]
•Gross profit of $80 million, or 29.2% of revenue;

[0000080420-24-000084:8k_2_02:11]
•Net income of $46 million, or $3.77 per diluted share, increased 74%;

[0000080420-24-000084:8k_2_02:12]
•New orders(1) totaled $267 million;

[0000080420-24-000084:8k_2_02:13]
•Backlog(2) as of September 30, 2024 remained at $1.3 billion;

[0000080420-24-000084:8k_2_02:14]
•Cash and short-term investments as of September 30, 2024 totaled $358 million.

[0000080420-24-000084:8k_2_02:15]
Full Year Key Financial Highlights:

[0000080420-24-000084:8k_2_02:16]
•Revenues totaled $1.0 billion, an increase of 45%;

[0000080420-24-000084:8k_2_02:17]
•Gross profit of $273 million, or 27.0% of revenue;

[0000080420-24-000084:8k_2_02:18]
•Net income of $150 million, or $12.29 per diluted share, increased 175%;

[0000080420-24-000084:8k_2_02:19]
•Net new orders totaled $1.1 billion.

[0000080420-24-000084:8k_2_02:20]
Brett A. Cope, Powell’s Chairman and Chief Executive Officer, stated, “Powell delivered a strong fourth quarter performance that closed out another incredible year for the Company. We experienced tremendous growth in our largest markets, with our top line growing by 45% in fiscal 2024.  We continue to execute at a high standard for both our customers and our shareholders as reflected by our gross margin, which improved 590 basis points compared to the prior year.  Having recorded our second consecutive year of more than $1.0 billion in new orders, we continue to grow in our traditional markets of oil & gas, petrochemical and electrical utilities, while further diversifying in markets such as data centers, hydrogen, carbon capture and other alternative fuels. I’m incredibly proud of the Powell team for their performance in fiscal 2024 and their unwavering commitment to our customers and mission.”

[0000080420-24-000084:8k_2_02:21]
Fourth Quarter Fiscal 2024 Results

[0000080420-24-000084:8k_2_02:22]
Revenues totaled $275.1 million, an increase of 32% compared to $208.6 million in the prior year, and a 5% decline compared to $288.2 million in the third quarter. The increase compared to the prior year was mainly driven by the Petrochemical sector, which increased 112% to $50.4 million, and the Oil & Gas sector, which grew 23% to $115.4 million.  In addition, revenues within the Commercial & Other Industrial sector improved 66% to $48.3 million.

[0000080420-24-000084:8k_2_02:23]
Gross profit of $80.4 million, or 29.2% of revenue, increased 55% compared to the prior year of $52.0 million, or 24.9% of revenue, and compares to $81.7 million, or 28.4% of revenue, in the third quarter. The increase in gross margin was predominantly driven by the higher volume levels across all of Powell’s manufacturing facilities generating favorable volume leverage, strong project execution, and continuing efforts to improve factory efficiencies while also managing product pricing that corresponds to current cost levels.

[0000080420-24-000084:8k_2_02:24]
New orders totaled $267 million compared to $171 million in the prior year and $356 million in the third quarter. The growth compared to the prior year was driven by strong order activity across the Company’s Oil & Gas and Petrochemical sectors as well as the Electric Utility sector.

[0000080420-24-000084:8k_2_02:25]
Backlog totaled $1.3 billion as of September 30, 2024, essentially remaining the same as the backlog at both June 30, 2024 and September 30, 2023.

[0000080420-24-000084:8k_2_02:26]
Net income of $46.1 million, or $3.77 per diluted share, increased 74% compared to $26.4 million, or $2.17 per diluted share, in the prior year and was essentially flat compared to $46.2 million, or $3.79 per diluted share, in the third quarter.

[0000080420-24-000084:8k_2_02:27]
Full Year 2024 Financial Results

[0000080420-24-000084:8k_2_02:28]
Revenues totaled $1.0 billion, an increase of 45% compared to $699.3 million in the prior year. The increase was primarily driven by growth within the Company’s Oil & Gas and Petrochemical sectors, which grew 53% and 97%, respectively, compared to fiscal 2023.  Additionally, revenues within the Commercial & Other Industrial and Electric Utility sectors increased 44% and 18%, respectively, compared to fiscal 2023.

[0000080420-24-000084:8k_2_02:29]
Gross profit of $273.1 million, or 27.0% of revenues, increased 85% compared to $147.6 million, or 21.1% of revenues, in fiscal 2023. The improvement in gross margin was driven by the same factors mentioned above.

[0000080420-24-000084:8k_2_02:30]
Net new orders totaled $1.1 billion compared to $1.4 billion in fiscal 2023. The decline was mainly due to the inclusion of three large megaprojects in the Company’s Oil & Gas and Petrochemical sectors in fiscal 2023.

[0000080420-24-000084:8k_2_02:31]
Net income of $149.8 million, or $12.29 per diluted share, increased 175% compared to $54.5 million, or $4.50 per diluted share, in fiscal 2023.

[0000080420-24-000084:8k_2_02:32]
Cope added, “We are entering fiscal 2025 with strong backlog and remain focused on the continued execution of our strategic priorities. We expect modest manufacturing capacity upgrades to be completed during the middle of fiscal 2025, which will help to facilitate organic growth within our targeted markets. It is becoming increasingly clear that the supply of electrical energy will grow significantly over the next several years to meet rising global demand. As an industry leader in handling the supply, control, and distribution of electrical energy, we are well-positioned to leverage our more than 75 years of expertise to bring custom-engineered solutions to our key markets.”

[0000080420-24-000084:8k_2_02:33]
OUTLOOK

[0000080420-24-000084:8k_2_02:34]
Commenting on the Company's outlook, Michael Metcalf, Powell’s Chief Financial Officer, said, “As we look ahead to fiscal 2025, we expect continued strength across most of our end markets spanning across all of the geographies that we compete in. We are pleased with our fiscal 2024 results and remain focused on carrying forward the strong operational execution and commercial momentum that we have experienced this year, into fiscal 2025. Notwithstanding our seasonally slower fiscal first quarter, considering the healthy backdrop, robust backlog, strong liquidity, and a solid balance sheet, we anticipate that fiscal 2025 will be another successful year for Powell.”

[0000080420-24-000084:8k_2_02:35]
CONFERENCE CALL

[0000080420-24-000084:8k_2_02:36]
Powell Industries has scheduled a conference call for Wednesday, November 20, 2024 at 11:00 a.m. Eastern time. To participate in the conference call, dial 1-833-953-2431 (domestic) or 1-412-317-5760 (international) at least 10 minutes before the call begins and ask for the Powell Industries conference call. A telephonic replay of the conference call will be available through November 27, 2024 and may be accessed by calling 1-877-344-7529 (domestic) or 1-412-317-0088 (international) and using passcode 3321661#.

[0000080420-24-000084:8k_2_02:37]
Investors, analysts and the general public will also have the opportunity to listen to the conference call over the Internet by visiting powellind.com. To listen to the live call on the web, please visit the website at least 15 minutes before the call begins to register, download and install any necessary audio software.  For those who cannot listen to the live webcast, an archive will be available shortly after the call and will remain available for approximately 90 days at powellind.com.

[0000080420-24-000084:8k_2_02:38]
About Powell Industries

[0000080420-24-000084:8k_2_02:39]
Powell Industries, Inc., headquartered in Houston, Texas, develops, designs, manufactures and services custom-engineered equipment and systems that distribute, control and monitor the flow of electrical energy and provide protection to motors, transformers and other electrically powered equipment.  Powell Industries, Inc. primarily serve the oil and gas and petrochemical markets, the electric utility market, and commercial and other industrial markets. Beyond these major markets, we also provide products and services to the light rail traction power market and

[0000080420-24-000084:8k_2_02:40]
other markets that include universities and government entities. We are continuously developing new channels to electrical markets through original equipment manufacturers and distribution market channels.   For more information, please visit powellind.com.

[0000080420-24-000084:8k_2_02:41]
5

[0000080420-24-000084:8k_2_02:42]
POWELL INDUSTRIES, INC. & SUBSIDIARIES

[0000080420-24-000084:8k_2_02:43]
CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS

[0000080420-24-000084:8k_2_02:44]
|  | Three Months EndedSeptember 30, |  | Year EndedSeptember 30, |
|  | 2024 |  | 2023 |  | 2024 |  | 2023 |
| (In thousands, except per share data) |  |  |  |  |  |  |  |
|  | (Unaudited) |  |  |
| Revenues | $ | 275,063 |  |  | $ | 208,641 |  |  | $ | 1,012,356 |  |  | $ | 699,308 |  |
| Cost of goods sold | 194,629 |  |  | 156,659 |  |  | 739,268 |  |  | 551,755 |  |
| Gross profit | 80,434 |  | 51,982 |  | 273,088 |  | 147,553 |
| Selling, general and administrative expenses | 21,572 |  |  | 20,429 |  |  | 84,888 |  |  | 78,813 |  |
| Research and development expenses | 2,746 |  |  | 1,749 |  |  | 9,427 |  |  | 6,220 |  |
| Operating income | 56,116 |  |  | 29,804 |  |  | 178,773 |  |  | 62,520 |  |
| Other expenses (income): |  |  |  |  |  |  |  |
| Interest income, net | (4,381) |  |  | (2,915) |  |  | (17,315) |  |  | (6,430) |  |
| Income before income taxes | 60,497 |  | 32,719 |  | 196,088 |  | 68,950 |
| Income tax provision | 14,445 |  |  | 6,283 |  |  | 46,240 |  |  | 14,425 |  |
| Net income | $ | 46,052 |  |  | $ | 26,436 |  |  | $ | 149,848 |  |  | $ | 54,525 |  |
| Earnings per share: |  |  |  |  |  |  |  |
| Basic | $ | 3.84 |  |  | $ | 2.22 |  |  | $ | 12.51 |  |  | $ | 4.59 |  |
| Diluted | $ | 3.77 |  |  | $ | 2.17 |  |  | $ | 12.29 |  |  | $ | 4.50 |  |
| Weighted average shares: |  |  |  |  |  |  |  |
| Basic | 11,999 |  |  | 11,890 |  |  | 11,982 |  |  | 11,879 |  |
| Diluted | 12,211 |  |  | 12,158 |  |  | 12,188 |  |  | 12,120 |  |
| SELECTED FINANCIAL DATA: |  |  |  |  |  |  |  |
| Depreciation | $ | 1,797 |  |  | $ | 2,106 |  |  | $ | 6,871 |  |  | $ | 8,606 |  |
| Capital Expenditures | $ | 8,456 |  |  | $ | 3,813 |  |  | $ | 11,983 |  |  | $ | 7,819 |  |
| Dividends Paid | $ | 3,178 |  |  | $ | 3,115 |  |  | $ | 12,653 |  |  | $ | 12,407 |  |

[0000080420-24-000084:8k_2_02:45]
6

[0000080420-24-000084:8k_2_02:46]
POWELL INDUSTRIES, INC. & SUBSIDIARIES

[0000080420-24-000084:8k_2_02:47]
CONDENSED CONSOLIDATED BALANCE SHEETS

[0000080420-24-000084:8k_2_02:48]
|  | September 30, 2024 |  | September 30, 2023 |
| (In thousands) |  |
| Assets: |  |  |  |
| Cash, cash equivalents and short-term investments | $ | 358,392 |  |  | $ | 279,009 |  |
| Other current assets | 418,089 |  |  | 342,976 |  |
| Property, plant and equipment, net | 103,421 |  |  | 97,625 |  |
| Long-term assets | 48,278 |  |  | 32,632 |  |
| Total assets | $ | 928,180 |  |  | $ | 752,242 |  |
| Liabilities and equity: |  |  |  |
| Current liabilities | $ | 428,015 |  |  | $ | 395,686 |  |
| Deferred and other long-term liabilities | 17,092 |  |  | 11,530 |  |
| Stockholders’ equity | 483,073 |  |  | 345,026 |  |
| Total liabilities and stockholders’ equity | $ | 928,180 |  |  | $ | 752,242 |  |
| SELECTED FINANCIAL DATA: |  |  |  |
| Working capital | $ | 348,466 |  |  | $ | 226,299 |  |

[0000080420-24-000084:8k_2_02:49]
(1)New orders (bookings) represent the estimated value of contracts added to existing backlog (unsatisfied performance obligations).

[0000080420-24-000084:8k_2_02:50]
(2)The amounts recorded in backlog may not be a reliable indicator of our future operating results and may not be indicative of continuing revenue performance over future fiscal quarters or years primarily due to unexpected contract adjustments, cancellations or scope reductions.
