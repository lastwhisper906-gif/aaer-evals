# POWL notes — 0000080420-25-000061


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureAndSignificantAccountingPoliciesTextBlock

[0000080420-25-000061:notes:1]
[same as prior period, unchanged from 0000080420-25-000029:notes:1]

[0000080420-25-000061:notes:2]
[same as prior period, unchanged from 0000080420-25-000029:notes:2]

[0000080420-25-000061:notes:3]
[same as prior period, unchanged from 0000080420-25-000029:notes:3]

[0000080420-25-000061:notes:4]
[same as prior period, unchanged from 0000080420-25-000029:notes:4]

[0000080420-25-000061:notes:5]
[same as prior period, unchanged from 0000080420-25-000029:notes:5]

[0000080420-25-000061:notes:6]
[same as prior period, unchanged from 0000080420-25-000029:notes:6]

[0000080420-25-000061:notes:7]
[same as prior period, unchanged from 0000080420-25-000029:notes:7]

[0000080420-25-000061:notes:8]
[same as prior period, unchanged from 0000080420-25-000029:notes:8]

[0000080420-25-000061:notes:9]
[same as prior period, unchanged from 0000080420-25-000029:notes:9]

[0000080420-25-000061:notes:10]
[same as prior period, unchanged from 0000080420-25-000029:notes:10]

[0000080420-25-000061:notes:11]
[same as prior period, unchanged from 0000080420-25-000029:notes:11]

[0000080420-25-000061:notes:12]
In November 2023, the Financial Accounting Standard Board (FASB) issued Accounting Standards Update (ASU) 2023-07,

[0000080420-25-000061:notes:13]
Segment Reporting (Topic 280): Improvements to Reportable Segment Disclosures, which requires that public entities disclose significant segment expenses that are regularly provided to the chief operating decision maker (CODM) on an annual and interim basis. It also requires that public entities disclose the title and position of the CODM and an explanation of how the CODM uses the reported measures in assessing segment performance and resource allocation. Additionally, it requires that all existing annual disclosures about segment profit or loss and assets must be provided on an interim basis and clarifies that single reportable segment entities are subject to the disclosure requirement under Topic 280 in its entirety. ASU 2023-07 is effective for fiscal years beginning after December 15, 2023 and interim periods within fiscal years beginning after December 15, 2024. A public entity should apply ASU 2023-07 retrospectively to all prior periods presented in the financial statements. Early adoption is permitted. We will implement the new disclosure requirements beginning with our Fiscal 2025 Form 10-K.

[0000080420-25-000061:notes:14]
In December 2023, the FASB issued ASU 2023-09, Improvements to Income Tax Disclosures, which enhances the transparency of income tax disclosures. It requires greater disaggregation of information in the tax rate reconciliation and income taxes paid disaggregated by jurisdiction. This ASU is effective for fiscal years beginning after December 15, 2024, and should be applied on a prospective basis. Retrospective application and early adoption are permitted. We are currently evaluating the impacts of the new standard.

[0000080420-25-000061:notes:15]
In November 2024, the FASB issued ASU No. 2024-03, Reporting Comprehensive Income – Expense Disaggregation Disclosures, which requires additional qualitative and quantitative information about specific expense categories in the notes to financial statements for both interim and annual reporting periods. In January 2025, the FASB further clarified the effective date for interim reporting periods. This ASU is effective for fiscal years beginning after December 15, 2026 and interim periods within those fiscal years beginning after December 15, 2027, with early adoption permitted. We are currently evaluating the impacts of the new standard.


## us-gaap:EarningsPerShareTextBlock

[0000080420-25-000061:notes:16]
[same as prior period, unchanged from 0000080420-25-000029:notes:17]

[0000080420-25-000061:notes:17]
[same as prior period, unchanged from 0000080420-25-000029:notes:18]

[0000080420-25-000061:notes:18]
|  | Three months ended March 31, |  | Six months ended March 31, |
|  | 2025 |  | 2024 |  | 2025 |  | 2024 |
| Numerator: |  |  |  |  |  |  |  |
| Net income | $ | 46,330 |  |  | $ | 33,488 |  |  | $ | 81,093 |  |  | $ | 57,573 |  |
| Denominator: |  |  |  |  |  |  |  |
| Weighted average basic shares | 12,069 |  |  | 11,992 |  |  | 12,053 |  |  | 11,966 |  |
| Dilutive effect of restricted stock and restricted stock units | 105 |  |  | 199 |  |  | 110 |  |  | 201 |  |
| Weighted average diluted shares | 12,174 |  |  | 12,191 |  |  | 12,163 |  |  | 12,167 |  |
| Earnings per share: |  |  |  |  |  |  |  |
| Basic | $ | 3.84 |  |  | $ | 2.79 |  |  | $ | 6.73 |  |  | $ | 4.81 |  |
| Diluted | $ | 3.81 |  |  | $ | 2.75 |  |  | $ | 6.67 |  |  | $ | 4.73 |  |


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0000080420-25-000061:notes:19]
[same as prior period, unchanged from 0000080420-25-000029:notes:20]

[0000080420-25-000061:notes:20]
[same as prior period, unchanged from 0000080420-25-000029:notes:21]

[0000080420-25-000061:notes:21]
|  | March 31, 2025 |  | September 30, 2024 |
| Raw materials, parts and sub-assemblies | $ | 95,257 |  |  | $ | 92,314 |  |
| Work-in-progress | 1,650 |  |  | 920 |  |
| Provision for excess and obsolete inventories | (7,891) |  |  | (7,361) |  |
| Total inventories | $ | 89,016 |  |  | $ | 85,873 |  |

[0000080420-25-000061:notes:22]
[same as prior period, unchanged from 0000080420-25-000029:notes:23]

[0000080420-25-000061:notes:23]
[same as prior period, unchanged from 0000080420-25-000029:notes:24]

[0000080420-25-000061:notes:24]
|  | March 31, 2025 |  | September 30, 2024 |  |  |  |  |
| Land | $ | 23,754 |  |  | $ | 24,110 |  |  |  |  |  |
| Buildings and improvements | 124,588 |  |  | 127,094 |  |  |  |  |  |
| Machinery and equipment | 95,121 |  |  | 94,889 |  |  |  |  |  |
| Furniture and fixtures | 2,830 |  |  | 2,885 |  |  |  |  |  |
| Construction in process | 9,363 |  |  | 3,317 |  |  |  |  |  |
|  | $ | 255,656 |  |  | $ | 252,295 |  |  |  |  |  |
| Less: Accumulated depreciation | (150,254) |  |  | (148,874) |  |  |  |  |  |
| Total property, plant and equipment, net | $ | 105,402 |  |  | $ | 103,421 |  |  |  |  |  |

[0000080420-25-000061:notes:25]
There were no assets under finance lease as of March 31, 2025 or September 30, 2024.

[0000080420-25-000061:notes:26]
[same as prior period, unchanged from 0000080420-25-000029:notes:27]

[0000080420-25-000061:notes:27]
[same as prior period, unchanged from 0000080420-25-000029:notes:28]

[0000080420-25-000061:notes:28]
|  | Three months ended March 31, |  | Six months ended March 31, |
|  | 2025 |  | 2024 |  | 2025 |  | 2024 |
| Balance at beginning of period | $ | 6,106 |  |  | $ | 3,680 |  |  | $ | 5,822 |  |  | $ | 3,305 |  |
| Increase to warranty expense | 1,357 |  |  | 1,867 |  |  | 2,854 |  |  | 2,994 |  |
| Deduction for warranty charges | (1,192) |  |  | (968) |  |  | (2,341) |  |  | (1,742) |  |
| Change due to foreign currency translation | 13 |  |  | (11) |  |  | (51) |  |  | 11 |  |
| Balance at end of period | $ | 6,284 |  |  | $ | 4,568 |  |  | $ | 6,284 |  |  | $ | 4,568 |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0000080420-25-000061:notes:29]
[same as prior period, unchanged from 0000080420-25-000029:notes:30]

[0000080420-25-000061:notes:30]
[same as prior period, unchanged from 0000080420-25-000029:notes:31]

[0000080420-25-000061:notes:31]
[same as prior period, unchanged from 0000080420-25-000029:notes:32]

[0000080420-25-000061:notes:32]
We also have contracts to provide field service inspection, installation, commissioning, modification, and repair services, as well as retrofit and retrofill components for existing systems. If the service contract terms give us the right to invoice the customer for an amount that corresponds directly with the value of our performance completed to date (i.e., a service contract in which we bill a fixed amount for each hour of service provided), then we recognize revenue over time in each reporting period corresponding to the amount that we have the right to invoice. Our performance obligations are satisfied as the work progresses. Revenues from our custom-engineered products and value-added services transferred to customers over time accounted for approximately 95% of revenues for the three months ended March 31, 2025, 96% of revenues for the six months ended March 31, 2025, 95% of revenues for the three months ended March 31, 2024, and 94% of revenues for the six months ended March 31, 2024.

[0000080420-25-000061:notes:33]
We also have sales orders for spare parts and replacement circuit breakers for switchgear that are obsolete or that are no longer produced by the original manufacturer. Revenues from these sales orders are recognized at the time we fulfill our performance obligation to the customer, which is typically upon shipment and represented approximately 5% of revenues for the three months ended March 31, 2025, 4% of revenues for the six months ended March 31, 2025, 5% of revenues for the three months ended March 31, 2024, and 6% of revenues for the six months ended March 31, 2024.

[0000080420-25-000061:notes:34]
[same as prior period, unchanged from 0000080420-25-000029:notes:35]

[0000080420-25-000061:notes:35]
[same as prior period, unchanged from 0000080420-25-000029:notes:36]

[0000080420-25-000061:notes:36]
[same as prior period, unchanged from 0000080420-25-000029:notes:37]

[0000080420-25-000061:notes:37]
[same as prior period, unchanged from 0000080420-25-000029:notes:38]

[0000080420-25-000061:notes:38]
Remaining unsatisfied performance obligations, which we refer to as backlog, represent the estimated transaction price for goods and services for which we have a material right, but work has not been performed. As of March 31, 2025, we had

[0000080420-25-000061:notes:39]
backlog of $1.3 billion, of which approximately $831 million is expected to be recognized as revenue within the next twelve months. Backlog may not be indicative of future operating results as orders may be cancelled or modified by our customers. Our backlog does not include service and maintenance-type contracts for which we have the right to invoice as services are performed.

[0000080420-25-000061:notes:40]
[same as prior period, unchanged from 0000080420-25-000029:notes:41]

[0000080420-25-000061:notes:41]
[same as prior period, unchanged from 0000080420-25-000029:notes:42]

[0000080420-25-000061:notes:42]
For the six months ended March 31, 2025 and 2024, our operating results were positively impacted by $8.8 million and $7.8 million, respectively, as a result of net changes in contract estimates related to projects in progress at the beginning of the respective period. These changes in estimates resulted primarily from favorable project execution, reduced cost estimates and negotiations of variable consideration, discussed below, as well as revenue recognized from project cancellations and other changes in facts and circumstances during these periods. Gross unfavorable changes in contract estimates were immaterial for both the six months ended March 31, 2025 and 2024.

[0000080420-25-000061:notes:43]
[same as prior period, unchanged from 0000080420-25-000029:notes:44]

[0000080420-25-000061:notes:44]
[same as prior period, unchanged from 0000080420-25-000029:notes:45]

[0000080420-25-000061:notes:45]
[same as prior period, unchanged from 0000080420-25-000029:notes:46]

[0000080420-25-000061:notes:46]
[same as prior period, unchanged from 0000080420-25-000029:notes:47]

[0000080420-25-000061:notes:47]
[same as prior period, unchanged from 0000080420-25-000029:notes:48]

[0000080420-25-000061:notes:48]
[same as prior period, unchanged from 0000080420-25-000029:notes:49]

[0000080420-25-000061:notes:49]
[same as prior period, unchanged from 0000080420-25-000029:notes:50]

[0000080420-25-000061:notes:50]
[same as prior period, unchanged from 0000080420-25-000029:notes:51]

[0000080420-25-000061:notes:51]
[same as prior period, unchanged from 0000080420-25-000029:notes:52]

[0000080420-25-000061:notes:52]
Contract assets and liabilities as of March 31, 2025 and September 30, 2024 are summarized below (in thousands):

[0000080420-25-000061:notes:53]
|  | March 31, 2025 |  | September 30, 2024 |
| Contract assets | $ | 115,943 |  |  | $ | 102,827 |  |
| Contract liabilities | (283,372) |  |  | (287,763) |  |
| Net contract liability | $ | (167,429) |  |  | $ | (184,936) |  |

[0000080420-25-000061:notes:54]
Our net contract billing position remained a net liability at both March 31, 2025 and September 30, 2024, primarily due to favorable contract billing milestones. We typically allocate a significant percentage of the progress billing to the early stages of the contract. To determine the amount of revenue recognized during the period from contract liabilities, we first allocate revenue to the individual contract liability balance outstanding at the beginning of the period until the revenue exceeds that balance. During the six months ended March 31, 2025, we recognized revenue of $203.4 million that was related to contract liabilities outstanding at September 30, 2024.

[0000080420-25-000061:notes:55]
The timing of our invoice process is typically dependent on the completion of certain milestones and contract terms and subject to agreement by our customer. Payment is typically expected within 30 days of invoice. Any uncollected invoiced amounts for our performance obligations recognized over time, including contract retentions, are recorded as accounts receivable in the Condensed Consolidated Balance Sheets. Certain contracts allow customers to withhold a small percentage of billings pursuant to retainage provisions, and such amounts are generally due upon completion of the contract and acceptance of the project by the customer. Based on our experience in recent years, the majority of these retainage balances are expected to be collected within approximately twelve months. As of March 31, 2025 and September 30, 2024, we had retention amounts of $7.9 million and $7.1 million, respectively. Of the retained amount at March 31, 2025, $7.6 million is expected to be collected in the next twelve months and is recorded in accounts receivable. The remaining $0.3 million is recorded in other assets.

[0000080420-25-000061:notes:56]
[same as prior period, unchanged from 0000080420-25-000029:notes:57]

[0000080420-25-000061:notes:57]
The following tables present our disaggregated revenue by geographic destination and market sector for the three and six months ended March 31, 2025 and 2024 (in thousands):

[0000080420-25-000061:notes:58]
|  | Three months ended March 31, |  | Six months ended March 31, |
|  | 2025 |  | 2024 |  | 2025 |  | 2024 |
| United States | $ | 227,834 |  |  | $ | 216,933 |  |  | $ | 425,606 |  |  | $ | 376,793 |  |
| Canada | 33,970 |  |  | 24,160 |  |  | 65,664 |  |  | 44,510 |  |
| Europe | 5,897 |  |  | 8,265 |  |  | 11,425 |  |  | 14,797 |  |
| Middle East and Africa | 8,282 |  |  | 2,803 |  |  | 12,840 |  |  | 6,078 |  |
| Mexico, Central and South America | 1,002 |  |  | 2,159 |  |  | 1,301 |  |  | 4,816 |  |
| Asia/Pacific | 1,646 |  |  | 788 |  |  | 3,226 |  |  | 2,131 |  |
| Total revenues by geographic destination | $ | 278,631 |  |  | $ | 255,108 |  |  | $ | 520,062 |  |  | $ | 449,125 |  |

[0000080420-25-000061:notes:59]
|  | Three months ended March 31, |  | Six months ended March 31, |
|  | 2025 |  | 2024 |  | 2025 |  | 2024 |
| Oil and gas (excludes petrochemical) | $ | 101,167 |  |  | $ | 103,820 |  |  | $ | 196,846 |  |  | $ | 187,456 |  |
| Petrochemical | 43,704 |  |  | 50,070 |  |  | 76,887 |  |  | 78,437 |  |
| Electric utility | 70,339 |  |  | 47,502 |  |  | 121,579 |  |  | 88,205 |  |
| Commercial and other industrial | 40,369 |  |  | 34,894 |  |  | 84,669 |  |  | 59,566 |  |
| Light rail traction power | 10,008 |  |  | 4,517 |  |  | 18,236 |  |  | 8,862 |  |
| All others | 13,044 |  |  | 14,305 |  |  | 21,845 |  |  | 26,599 |  |
| Total revenues by market sector | $ | 278,631 |  |  | $ | 255,108 |  |  | $ | 520,062 |  |  | $ | 449,125 |  |


## us-gaap:RevenueFromContractWithCustomerPolicyTextBlock

[0000080420-25-000061:notes:60]
[same as prior period, unchanged from 0000080420-25-000029:notes:61]

[0000080420-25-000061:notes:61]
[same as prior period, unchanged from 0000080420-25-000029:notes:62]

[0000080420-25-000061:notes:62]
[same as prior period, unchanged from 0000080420-25-000029:notes:63]

[0000080420-25-000061:notes:63]
[same as prior period, unchanged from 0000080420-25-000029:notes:64]


## us-gaap:LongTermDebtTextBlock

[0000080420-25-000061:notes:64]
Long-Term Debt
U.S. Revolver

[0000080420-25-000061:notes:65]
We have a credit agreement with Bank of America, N.A. and Texas Capital Bank with an aggregate commitment of $150.0 million, consisting of $100.0 million committed by Bank of America and $50.0 million committed by Texas Capital Bank (the U.S. Revolver). The U.S. Revolver has an expiration date of October 4, 2028.

[0000080420-25-000061:notes:66]
As of March 31, 2025, there were no amounts borrowed under the U.S. Revolver, and letters of credit outstanding were $64.4 million. There was $85.6 million available for the issuance of letters of credit and borrowings under the U.S. Revolver as of March 31, 2025.

[0000080420-25-000061:notes:67]
As of March 31, 2025, we were in compliance with all of the financial covenants of the U.S. Revolver.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0000080420-25-000061:notes:68]
Commitments and Contingencies
Letters of Credit, Bank Guarantees and Bonds

[0000080420-25-000061:notes:69]
Certain customers require us to post letters of credit, bank guarantees or surety bonds. These security instruments assure that we will perform under the terms of our contract. In the event of default, the counterparty may demand payment from the bank under a letter of credit or bank guarantee, or performance by the surety under a bond. To date, there have been no significant draws or claims related to security instruments for the periods reported. We were contingently liable for letters of credit of $64.4 million as of March 31, 2025. We also had surety bonds totaling $420.3 million that were outstanding, with additional bonding capacity of $779.7 million available, at March 31, 2025. We have strong surety relationships; however, a change in market conditions or the sureties' assessment of our financial position could cause the sureties to require cash collateralization for undischarged liabilities under the bonds.

[0000080420-25-000061:notes:70]
We have a $19.4 million facility agreement (Facility Agreement) between Powell (UK) Limited and a large international bank that provides Powell (UK) Limited the ability to enter into bank guarantees as well as forward exchange contracts and currency options. At March 31, 2025, we had outstanding guarantees totaling $4.0 million, with an additional capacity of $15.4 million available under this Facility Agreement. The Facility Agreement provides for customary events of default and carries cross-default provisions with the U.S. Revolver. If an event of default (as defined in the Facility Agreement) occurs and is continuing, per the terms and subject to the conditions set forth therein, obligations outstanding under the Facility Agreement may be accelerated and declared immediately due and payable. Additionally, we are required to maintain cash collateral for guarantees greater than two years. As of March 31, 2025, we were in compliance with all of the financial covenants of the Facility Agreement.

[0000080420-25-000061:notes:71]
Litigation

[0000080420-25-000061:notes:72]
We are involved in various legal proceedings, claims and other disputes arising from our commercial operations, projects, employees and other matters which, in general, are subject to uncertainties and for which the outcomes are not predictable. Although we can give no assurances about the resolution of pending claims, litigation or other disputes, and the effect such outcomes may have on us, management believes that any ultimate liability resulting from the outcome of such proceedings, to the extent not otherwise provided or covered by insurance, will not have a material adverse effect on our consolidated financial position or results of operations or liquidity.

[0000080420-25-000061:notes:73]
Liquidated Damages

[0000080420-25-000061:notes:74]
Certain of our customer contracts have schedule and performance obligation clauses that, if we fail to meet them, could require us to pay liquidated damages. Each individual contract defines the conditions under which the customer may make a claim against us. As of March 31, 2025, certain contracts had a probable exposure to liquidated damages claims of $2.7 million, which could possibly increase to $3.6 million under certain circumstances. Based on our actual or projected failure to meet these various contractual commitments, $2.5 million has been recorded as a reduction to revenue. We will attempt to obtain change orders, contract extensions or accelerate project completion, which may resolve the potential for any unrecorded liquidated damages claims. Should we fail to achieve relief on some or all of these contractual obligations, we could be required to pay additional liquidated damages, which could negatively impact our future operating results.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0000080420-25-000061:notes:75]
[same as prior period, unchanged from 0000080420-25-000029:notes:76]

[0000080420-25-000061:notes:76]
[same as prior period, unchanged from 0000080420-25-000029:notes:77]

[0000080420-25-000061:notes:77]
We issue restricted stock units (RSUs) to certain officers and key employees of the Company. The fair value of the RSUs is based on the price of our common stock as reported on the NASDAQ Global Market during a specified period prior to the grant dates. Typically, these grants vest over a three-year period from the date of issuance and are a blend of time-based and performance-based shares. The portion of the grant that is time-based typically vests over a three-year period on each anniversary of the grant date, based on continued employment. The performance-based shares vest based on the three-year earnings and safety performance of the Company following the grant date. At March 31, 2025, there were 119,996 RSUs outstanding. The RSUs do not have voting rights but do receive dividend equivalents upon vesting, which are accrued quarterly. Additionally, the shares of common stock underlying the RSUs are not considered issued and outstanding until vested and common stock is issued.

[0000080420-25-000061:notes:78]
Total RSU activity (number of shares) for the six months ended March 31, 2025 is summarized below:

[0000080420-25-000061:notes:79]
|  | Number ofRestrictedStockUnits |  | WeightedAverageGrant ValuePer Share |
| Outstanding at September 30, 2024 | 192,011 |  |  | $ | 35.38 |  |
| Granted | 20,380 |  |  | 184.01 |  |
| Vested | (91,332) |  |  | 30.18 |  |
| Forfeited/canceled | (1,063) |  |  | 45.09 |  |
| Outstanding at March 31, 2025 | 119,996 |  |  | $ | 64.81 |  |

[0000080420-25-000061:notes:80]
During the six months ended March 31, 2025 and 2024, we recorded compensation expense of $2.2 million and $2.7 million, respectively, related to the RSUs.

[0000080420-25-000061:notes:81]
Restricted Stock
Each non-employee director receives restricted shares of the Company's common stock valued at $0.1 million annually. The number of granted shares is calculated by dividing the $0.1 million by the average of high and low prices of our common stock on the grant date. The shares shall vest on the earlier of the grant anniversary date or the date of the next annual meeting of stockholders, whichever occurs first. In February 2025, 3,500 shares of restricted stock were issued to our non-employee directors at a price of $200.02 per share. During the six months ended March 31, 2025 and 2024, we recorded compensation expense of $0.4 million and $0.2 million, respectively, related to restricted stock.


## us-gaap:FairValueDisclosuresTextBlock

[0000080420-25-000061:notes:82]
[same as prior period, unchanged from 0000080420-25-000029:notes:83]

[0000080420-25-000061:notes:83]
[same as prior period, unchanged from 0000080420-25-000029:notes:84]

[0000080420-25-000061:notes:84]
[same as prior period, unchanged from 0000080420-25-000029:notes:85]

[0000080420-25-000061:notes:85]
[same as prior period, unchanged from 0000080420-25-000029:notes:86]

[0000080420-25-000061:notes:86]
[same as prior period, unchanged from 0000080420-25-000029:notes:87]

[0000080420-25-000061:notes:87]
The following table summarizes the fair value of our assets and liabilities that were accounted for at fair value on a recurring basis as of March 31, 2025 (in thousands):

[0000080420-25-000061:notes:88]
|  | Fair Value Measurements at March 31, 2025 |
|  | Quoted Prices inActive Markets forIdentical Assets(Level 1) |  | Significant OtherObservableInputs(Level 2) |  | SignificantUnobservableInputs(Level 3) |  | Fair Value at March 31,2025 |
| Assets: |  |  |  |  |  |  |  |
| Cash and cash equivalents | $ | 359,542 |  |  | $ | — |  |  | $ | — |  |  | $ | 359,542 |  |
| Short-term investments | 29,750 |  |  | — |  |  | — |  |  | 29,750 |  |
| Rabbi trust assets | — |  |  | 11,784 |  |  | — |  |  | 11,784 |  |
| Liabilities: |  |  |  |  |  |  |  |
| Deferred compensation | — |  |  | 12,418 |  |  | — |  |  | 12,418 |  |

[0000080420-25-000061:notes:89]
[same as prior period, unchanged from 0000080420-25-000029:notes:90]

[0000080420-25-000061:notes:90]
[same as prior period, unchanged from 0000080420-25-000029:notes:91]

[0000080420-25-000061:notes:91]
[same as prior period, unchanged from 0000080420-25-000029:notes:92]

[0000080420-25-000061:notes:92]
[same as prior period, unchanged from 0000080420-25-000029:notes:93]

[0000080420-25-000061:notes:93]
[same as prior period, unchanged from 0000080420-25-000029:notes:94]

[0000080420-25-000061:notes:94]
[same as prior period, unchanged from 0000080420-25-000029:notes:95]

[0000080420-25-000061:notes:95]
There were no transfers between levels within the fair value measurement hierarchy during the quarter ended March 31, 2025.


## us-gaap:LesseeOperatingLeasesTextBlock

[0000080420-25-000061:notes:96]
Leases
Our leases consist primarily of office and construction equipment. All of our future lease obligations are related to non-cancelable operating leases. The following table provides a summary of lease cost components for the three and six months ended March 31, 2025 and 2024, respectively (in thousands):

[0000080420-25-000061:notes:97]
|  |  | Three months ended March 31, |  | Six months ended March 31, |
| Lease Cost |  | 2025 |  | 2024 |  | 2025 |  | 2024 |
| Operating lease cost |  | $ | 247 |  |  | $ | 249 |  |  | $ | 445 |  |  | $ | 505 |  |
| Variable lease cost(1) |  | 47 |  |  | 23 |  |  | 81 |  |  | 53 |  |
| Short-term lease cost(2) |  | 668 |  |  | 644 |  |  | 1,307 |  |  | 1,044 |  |
| Total lease cost |  | $ | 962 |  |  | $ | 916 |  |  | $ | 1,833 |  |  | $ | 1,602 |  |

[0000080420-25-000061:notes:98]
[same as prior period, unchanged from 0000080420-25-000029:notes:99]

[0000080420-25-000061:notes:99]
[same as prior period, unchanged from 0000080420-25-000029:notes:100]

[0000080420-25-000061:notes:100]
We recognize operating lease assets and operating lease liabilities representing the present value of the remaining lease payments for leases with initial terms greater than twelve months. Leases with initial terms of twelve months or less are not recorded in our Condensed Consolidated Balance Sheets. The following table provides a summary of the operating lease assets and operating lease liabilities included in our Condensed Consolidated Balance Sheets as of March 31, 2025 and September 30, 2024, respectively (in thousands):

[0000080420-25-000061:notes:101]
| Operating Leases |  | March 31, 2025 |  | September 30, 2024 |
| Assets: |  |  |  |  |
| Operating lease assets, net |  | $ | 1,411 |  |  | $ | 1,216 |  |
| Liabilities: |  |  |  |  |
| Current operating lease liabilities |  | 650 |  |  | 595 |  |
| Long-term operating lease liabilities |  | 761 |  |  | 621 |  |
| Total lease liabilities |  | $ | 1,411 |  |  | $ | 1,216 |  |

[0000080420-25-000061:notes:102]
The following table provides the maturities of our operating lease liabilities as of March 31, 2025 (in thousands):

[0000080420-25-000061:notes:103]
|  |  | Operating Leases |  |  |
| Remainder of 2025 |  | $ | 401 |  |  |  |
| 2026 |  | 606 |  |  |  |
| 2027 |  | 413 |  |  |  |
| 2028 |  | 71 |  |  |  |
| 2029 |  | 28 |  |  |  |
| Thereafter |  | — |  |  |  |
| Total future minimum lease payments |  | $ | 1,519 |  |  |  |
| Less: present value discount (imputed interest) |  | (108) |  |  |  |
| Present value of lease liabilities |  | $ | 1,411 |  |  |  |

[0000080420-25-000061:notes:104]
The weighted average discount rate as of March 31, 2025 was 6.55%. The weighted average remaining lease term was 2.34 years at March 31, 2025.


## us-gaap:IncomeTaxDisclosureTextBlock

[0000080420-25-000061:notes:105]
[same as prior period, unchanged from 0000080420-25-000029:notes:106]

[0000080420-25-000061:notes:106]
|  | Three months ended March 31, |  | Six months ended March 31, |
|  | 2025 |  | 2024 |  | 2025 |  | 2024 |
| Income before income taxes | $ | 62,474 |  |  | $ | 43,917 |  |  | $ | 101,911 |  |  | $ | 73,795 |  |
| Income tax provision | 16,144 |  |  | 10,429 |  |  | 20,818 |  |  | 16,222 |  |
| Net income | $ | 46,330 |  |  | $ | 33,488 |  |  | $ | 81,093 |  |  | $ | 57,573 |  |
| Effective tax rate | 26 | % |  | 24 | % |  | 20 | % |  | 22 | % |

[0000080420-25-000061:notes:107]
Our income tax provision reflects an effective tax rate on pre-tax income of 26% and 20% for the three and six months ended March 31, 2025, respectively, compared to 24% and 22% for the three and six months ended March 31, 2024, respectively. The effective tax rates for the three and six months ended March 31, 2025 were favorably impacted by the estimated Research and Development (R&D) Tax Credit, which was offset by the tax expense related to certain nondeductible items. In addition, discrete items related to the vesting of RSUs recorded in the first quarter of Fiscal 2025 favorably impacted the effective tax rate for the six months ended March 31, 2025. Similarly, the effective tax rates for the three and six months ended March 31, 2024 were favorably impacted by the estimated R&D Tax Credit and discrete items related to the release of a reserve for unrecognized tax benefits upon expiration of the statute of limitations. These items were offset by an income inclusion related to U.S. global intangible income.


## us-gaap:SubsequentEventsTextBlock

[0000080420-25-000061:notes:108]
Subsequent Events
Quarterly Dividend Declared

[0000080420-25-000061:notes:109]
On May 6, 2025, our Board of Directors declared a quarterly cash dividend on our common stock in the amount of $0.2675 per share. The dividend is payable on June 18, 2025 to shareholders of record at the close of business on May 21, 2025.
