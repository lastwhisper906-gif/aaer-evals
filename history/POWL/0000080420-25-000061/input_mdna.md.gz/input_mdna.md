# POWL MD&A — 0000080420-25-000061


## mdna

[0000080420-25-000061:mdna:1]
[same as prior period, unchanged from 0000080420-25-000029:mdna:1]

[0000080420-25-000061:mdna:2]
[same as prior period, unchanged from 0000080420-25-000029:mdna:2]

[0000080420-25-000061:mdna:3]
[same as prior period, unchanged from 0000080420-25-000029:mdna:3]

[0000080420-25-000061:mdna:4]
[same as prior period, unchanged from 0000080420-25-000029:mdna:4]

[0000080420-25-000061:mdna:5]
In the second quarter of Fiscal 2025, we reported revenues of $278.6 million, net income of $46.3 million, and generated $59.5 million in cash from operating activities. As of March 31, 2025, we had total assets of $965.4 million.

[0000080420-25-000061:mdna:6]
[same as prior period, unchanged from 0000080420-25-000029:mdna:6]

[0000080420-25-000061:mdna:7]
Our backlog remained at $1.3 billion as of March 31, 2025, of which approximately $831 million is expected to be recognized as revenue within the next twelve months. Although current commercial activity remains active in most of the markets that we compete in, we remain attentive to the macro environment and geopolitical events that may have an impact on future market activity.

[0000080420-25-000061:mdna:8]
Oil and gas and petrochemical markets. The North American market is responding to increased international demand for Liquefied Natural Gas (LNG) and gas-to-chemical processes utilizing low-cost gas feedstocks. We believe the fundamentals of the U.S. natural gas market, through abundant supply and low cost, will continue to support investments in LNG, related gas processing, and petrochemical processes, and as a result, will continue to sustain our order activity associated with such markets, which is evidenced by two large, domestic LNG project awards during the first half of Fiscal 2025. In addition to the traditional crude oil refining and other oil and gas downstream processes, we have recently expanded our end markets into hydrogen production, carbon capture as well as alternative fuels, such as biofuels and sustainable aviation fuel, in response to the demand for clean energy.

[0000080420-25-000061:mdna:9]
[same as prior period, unchanged from 0000080420-25-000029:mdna:9]

[0000080420-25-000061:mdna:10]
Commercial and other industrial markets. As a result of a mix of factors we are experiencing strong growth in commercial facilities that provide for the production of various consumer goods and the expansion of data centers that support cloud computing and increasing investments in artificial intelligence. We are also experiencing increased activity in other industrial markets such as pulp and paper, and mining which includes the large mining project for the production of potash in the second quarter of Fiscal 2025.

[0000080420-25-000061:mdna:11]
[same as prior period, unchanged from 0000080420-25-000029:mdna:11]

[0000080420-25-000061:mdna:12]
[same as prior period, unchanged from 0000080420-25-000029:mdna:12]

[0000080420-25-000061:mdna:13]
[same as prior period, unchanged from 0000080420-25-000029:mdna:13]

[0000080420-25-000061:mdna:14]
[same as prior period, unchanged from 0000080420-25-000029:mdna:14]

[0000080420-25-000061:mdna:15]
[same as prior period, unchanged from 0000080420-25-000029:mdna:15]

[0000080420-25-000061:mdna:16]
During the second quarter of Fiscal 2025, we experienced an increase in volatility for commodity prices and ongoing supply chain delays for specific engineered components that remain a persistent challenge. Moreover, recently announced changes and proposed changes to U.S. global trade policy, along with potential international retaliatory measures, have caused high volatility in global markets and uncertainty around short- and long-term economic impacts in the United States and other markets we serve, including concerns over inflation, recession and slowing growth. We continue to evaluate and monitor the potential impacts of these changes and measures, including the imposition of tariffs, on our business and operations. We could potentially face the challenge of increased costs of raw materials and engineered components as well as negative impacts on our margins; however, it is not possible to predict the impact, if any, of any changes or proposed changes to the U.S. global trade policy, or any international retaliatory measures, on our business and operations. In response to the rising cost environment and persistent supply chain challenges, we are taking strategic measures to effectively manage our product pricing, refine delivery schedules, and manage bid validity dates with our customers. Our supplier engagement includes improving forecasting and negotiating favorable terms that allow us to meet or exceed customer timelines. Additionally, we remain focused on enhancing factory efficiencies and improving project execution to mitigate risks and maintain customer satisfaction.

[0000080420-25-000061:mdna:17]
[same as prior period, unchanged from 0000080420-25-000029:mdna:17]

[0000080420-25-000061:mdna:18]
Quarter Ended March 31, 2025 Compared to the Quarter Ended March 31, 2024 (Unaudited)

[0000080420-25-000061:mdna:19]
[same as prior period, unchanged from 0000080420-25-000029:mdna:19]

[0000080420-25-000061:mdna:20]
Revenues increased by 9%, or $23.5 million, to $278.6 million in the second quarter of Fiscal 2025, primarily driven by strong project backlog at the end of Fiscal 2024 and strong bookings that continued through the first half of Fiscal 2025. Domestic revenues increased by 5%, or $10.9 million, to $227.8 million in the second quarter of Fiscal 2025. International revenues increased by 33%, or $12.6 million, to $50.8 million in the second quarter of Fiscal 2025, primarily driven by increased project volume from our Canada operations and increased activity in the Middle East and Africa region. Our international revenues include both revenues generated from our international facilities as well as revenues from export projects generated at our domestic facilities.

[0000080420-25-000061:mdna:21]
In the second quarter of Fiscal 2025, revenue from our oil and gas market (excluding petrochemical) decreased by 3%, or $2.7 million, to $101.2 million; petrochemical market revenue decreased by 13%, or $6.4 million, to $43.7 million; revenue from our electric utility market increased by 48%, or $22.8 million, to $70.3 million; commercial and other industrial market revenue increased by 16%, or $5.5 million, to $40.4 million; and revenue from our light rail traction power market increased by 122%, or $5.5 million, to $10.0 million. These increases in revenue were primarily driven by our strategic effort to expand our business into electric utility and commercial and other industrial markets and the improved market conditions in these end markets. Revenue from all other markets combined decreased by 9%, or $1.3 million, to $13.0 million in the second quarter of Fiscal 2025 due to less project volume.

[0000080420-25-000061:mdna:22]
Gross profit increased by 33%, or $20.7 million, to $83.4 million for the second quarter of Fiscal 2025. Gross profit as a percentage of revenues increased to 30% in the second quarter of Fiscal 2025, as compared to 25% in the second quarter of Fiscal 2024. The increase in gross profit was primarily driven by higher revenues, favorable volume leverage, strong project execution, as well as benefit from project closeouts in the second quarter of Fiscal 2025.

[0000080420-25-000061:mdna:23]
[same as prior period, unchanged from 0000080420-25-000029:mdna:23]

[0000080420-25-000061:mdna:24]
Selling, general and administrative expenses increased by 4%, or $0.8 million, to $21.8 million in the second quarter of Fiscal 2025, primarily due to increased compensation expense. Selling, general and administrative expenses as a percentage of revenues remained at 8% for both periods.

[0000080420-25-000061:mdna:25]
[same as prior period, unchanged from 0000080420-25-000029:mdna:25]

[0000080420-25-000061:mdna:26]
We recorded an income tax provision of $16.1 million in the second quarter of Fiscal 2025, compared to an income tax provision of $10.4 million in the second quarter of Fiscal 2024. The effective tax rate for the second quarter of Fiscal 2025 was 26%, compared to an effective tax rate of 24% for the second quarter of Fiscal 2024. For each of the three months ended March 31, 2025 and 2024, the effective tax rate was favorably impacted by the estimated Research and Development (R&D) Tax Credit. Additionally, for the second quarter of Fiscal 2024, we recognized a benefit for discrete items related to the vesting of restricted stock units (RSUs) and the release of a reserve for unrecognized tax benefits. For further information regarding our income taxes, see Note J of the Notes to Condensed Consolidated Financial Statements.

[0000080420-25-000061:mdna:27]
[same as prior period, unchanged from 0000080420-25-000029:mdna:27]

[0000080420-25-000061:mdna:28]
In the second quarter of Fiscal 2025, we recorded net income of $46.3 million, or $3.81 per diluted share, compared to net income of $33.5 million, or $2.75 per diluted share, in the second quarter of Fiscal 2024. The increase in net income was primarily driven by higher revenue and improved gross profit margin in the second quarter of Fiscal 2025.

[0000080420-25-000061:mdna:29]
[same as prior period, unchanged from 0000080420-25-000029:mdna:29]

[0000080420-25-000061:mdna:30]
The order backlog, which is our remaining unsatisfied performance obligations, represents the estimated transaction price for goods and services for which we have a material right, but work has not been performed. The order backlog at March 31, 2025 was $1.3 billion, consistent with our backlog at December 31, 2024. Bookings, net of cancellations and scope reductions, increased by 6% in the second quarter of Fiscal 2025 to $249.0 million, compared to $235.4 million in the second quarter of Fiscal 2024.

[0000080420-25-000061:mdna:31]
Six Months Ended March 31, 2025 Compared to the Six Months Ended March 31, 2024 (Unaudited)

[0000080420-25-000061:mdna:32]
Revenue and Gross Profit

[0000080420-25-000061:mdna:33]
Revenues increased by 16%, or $70.9 million, to $520.1 million in the six months ended March 31, 2025, primarily driven by strong project backlog at the end of Fiscal 2024 and strong bookings that continued in the first half of Fiscal 2025. Domestic revenues increased by 13%, or $48.8 million, to $425.6 million in the six months ended March 31, 2025. International revenues increased by 31%, or $22.1 million, to $94.5 million in the six months ended March 31, 2025, primarily driven by increased project volume from our Canada operations. Our international revenues include both revenues generated from our international facilities as well as revenues from export projects generated at our domestic facilities.

[0000080420-25-000061:mdna:34]
In the six months ended March 31, 2025, revenue from our oil and gas market (excluding petrochemical) increased by 5%, or $9.4 million, to $196.8 million; petrochemical market revenue decreased by 2%, or $1.6 million, to $76.9 million; revenue from our electric utility market increased by 38%, or $33.4 million, to $121.6 million; commercial and other industrial market revenue increased by 42%, or $25.1 million, to $84.7 million; and revenue from our light rail traction power market increased by 106%, or $9.4 million, to $18.2 million. These increases in revenue were primarily driven by our strategic effort to expand our business into electric utility and commercial and other industrial markets and the improved market conditions in these end markets. Revenue from all other markets combined decreased by 18%, or $4.8 million, to $21.8 million in the six months ended March 31, 2025 due to less project volume.

[0000080420-25-000061:mdna:35]
Gross profit increased by 29%, or $32.0 million, to $143.0 million for the six months ended March 31, 2025. Gross profit as a percentage of revenues increased to 27% in the first half of Fiscal 2025, compared to 25% in the first half of Fiscal 2024. The increase in gross profit was primarily driven by higher revenues in the first half of Fiscal 2025 and strong gross profit margin in the second quarter of Fiscal 2025 due to favorable volume leverage, strong project execution, as well as benefit from project closeouts in the quarter.

[0000080420-25-000061:mdna:36]
Selling, General and Administrative Expenses

[0000080420-25-000061:mdna:37]
Selling, general and administrative expenses increased by 5%, or $1.9 million, to $43.2 million in the six months ended March 31, 2025, primarily due to increased compensation expense. Selling, general and administrative expenses as a percentage of revenues decreased to 8% during the first half of Fiscal 2025, compared to 9% during the first half of Fiscal 2024, resulting from higher revenues on our existing cost structure.

[0000080420-25-000061:mdna:38]
Income Tax Provision

[0000080420-25-000061:mdna:39]
We recorded an income tax provision of $20.8 million in the six months ended March 31, 2025, compared to an income tax provision of $16.2 million in the six months ended March 31, 2024. The effective tax rate for the six months ended March 31, 2025 was 20%, compared to an effective tax rate of 22% for the six months ended March 31, 2024. For each of the six months ended March 31, 2025 and 2024, the effective tax rate was favorably impacted by discrete items related to the vesting of RSUs and the estimated R&D Tax Credit. Additionally, we recognized a benefit due to the release of a reserve for unrecognized tax benefits in the six months ended March 31, 2024. The decreased effective tax rate for the first half of Fiscal 2025 was primarily driven by higher stock prices associated with the vested RSUs. For further information regarding our income taxes, see Note J of the Notes to Condensed Consolidated Financial Statements.

[0000080420-25-000061:mdna:40]
Net Income

[0000080420-25-000061:mdna:41]
In the six months ended March 31, 2025, we recorded net income of $81.1 million, or $6.67 per diluted share, compared to net income of $57.6 million, or $4.73 per diluted share, in the six months ended March 31, 2024. The increase in net income was primarily driven by higher revenue and improved gross profit margin in the first half of Fiscal 2025.

[0000080420-25-000061:mdna:42]
Backlog

[0000080420-25-000061:mdna:43]
The order backlog, which is our remaining unsatisfied performance obligations, represents the estimated transaction price for goods and services for which we have a material right, but work has not been performed. The order backlog at March 31, 2025 was $1.3 billion, consistent with our backlog at September 30, 2024. Bookings, net of cancellations and scope reductions, increased by 20% during the six months ended March 31, 2025 to $517.6 million, compared to $433.0 million during the six months ended March 31, 2024.

[0000080420-25-000061:mdna:44]
[same as prior period, unchanged from 0000080420-25-000029:mdna:31]

[0000080420-25-000061:mdna:45]
As of March 31, 2025, current assets exceeded current liabilities by 2.0 times.

[0000080420-25-000061:mdna:46]
Cash, cash equivalents and short-term investments increased to $389.3 million at March 31, 2025, compared to $358.4 million at September 30, 2024. The increase in cash, cash equivalents and short-term investments was primarily driven by our improved earnings due to higher gross profit, partially offset by capital spending, dividend payments, and cash payments related to shares withheld in lieu of employee tax withholding. We believe that our cash, cash equivalents and short-term investments, as well as available borrowings under our U.S. credit facility, will be sufficient to support our future operating activities, working capital requirements, payment of dividends and capital spending, as well as research and development initiatives for the next twelve months and beyond.

[0000080420-25-000061:mdna:47]
Approximately $75.4 million of our cash, cash equivalents and short-term investments at March 31, 2025 was held outside of the U.S. for our international operations. It is our intention to indefinitely reinvest all current and future foreign earnings internationally in order to ensure sufficient working capital to support our international operations. In the event that we elect to repatriate some or all of the foreign earnings that were previously deemed to be indefinitely reinvested outside the U.S., we may incur additional tax expense upon such repatriation under current tax laws.

[0000080420-25-000061:mdna:48]
[same as prior period, unchanged from 0000080420-25-000029:mdna:35]

[0000080420-25-000061:mdna:49]
[same as prior period, unchanged from 0000080420-25-000029:mdna:36]

[0000080420-25-000061:mdna:50]
As of March 31, 2025, there were no amounts borrowed under the U.S. Revolver, and letters of credit outstanding were $64.4 million. There was $85.6 million available for the issuance of letters of credit and borrowings under the U.S. Revolver as of March 31, 2025. For further information regarding our debt, see Notes E and F of the Notes to Condensed Consolidated Financial Statements.

[0000080420-25-000061:mdna:51]
[same as prior period, unchanged from 0000080420-25-000029:mdna:38]

[0000080420-25-000061:mdna:52]
[same as prior period, unchanged from 0000080420-25-000029:mdna:39]

[0000080420-25-000061:mdna:53]
Operating activities provided net cash of $59.5 million during the six months ended March 31, 2025, and provided net cash of $100.9 million during the same period in Fiscal 2024. Cash flow from operations is primarily influenced by project volume and margins, as well as working capital requirements, the timing of milestone payments from our customers, and payment terms with our suppliers. The decrease in operating cash flow was primarily due to working capital impact as we allocate capital to projects in the order book, partially offset by higher earnings.

[0000080420-25-000061:mdna:54]
[same as prior period, unchanged from 0000080420-25-000029:mdna:41]

[0000080420-25-000061:mdna:55]
Investing activities provided $4.6 million of cash during the six months ended March 31, 2025 and used $11.2 million of cash during the same period in Fiscal 2024. Cash provided by investing activities in the first half of Fiscal 2025 was primarily due to net maturities of short-term investments, partially offset by capital spending on the facility expansion and improvement project at our electrical products facility in Houston. In December 2023, we acquired intellectual property for a total consideration of $0.5 million, of which $250 thousand was paid in cash.

[0000080420-25-000061:mdna:56]
We have planned capital spending of approximately $11 million on a facility expansion and improvement project at our electrical products facility in Houston. We recently completed the expansion and improvement project and the incremental capacity will be in service in the third quarter of Fiscal 2025.

[0000080420-25-000061:mdna:57]
[same as prior period, unchanged from 0000080420-25-000029:mdna:44]

[0000080420-25-000061:mdna:58]
Net cash used in financing activities was $18.4 million during the six months ended March 31, 2025 compared to $12.8 million used during the same period in Fiscal 2024. The increase in cash used in financing activities was primarily due to cash payments related to shares withheld in lieu of employee tax withholding, largely driven by the significant increase in our share price in the first half of Fiscal 2025 compared to the same period of Fiscal 2024.

[0000080420-25-000061:mdna:59]
[same as prior period, unchanged from 0000080420-25-000029:mdna:48]

[0000080420-25-000061:mdna:60]
[same as prior period, unchanged from 0000080420-25-000029:mdna:49]

[0000080420-25-000061:mdna:61]
[same as prior period, unchanged from 0000080420-25-000029:mdna:50]
