# POWL note change history — 0000080420-25-000029 → 0000080420-25-000061


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2025-05-07):
[0000080420-25-000061:note_history:1]
Certain customers require us to post letters of credit, bank guarantees or surety bonds. These security instruments assure that we will perform under the terms of our contract. In the event of default, the counterparty may demand payment from the bank under a letter of credit or bank guarantee, or performance by the surety under a bond. To date, there have been no significant draws or claims related to security instruments for the periods reported. We were contingently liable for letters of credit of $64.4 million as of March 31, 2025. We also had surety bonds totaling $420.3 million that were outstanding, with additional bonding capacity of $779.7 million available, at March 31, 2025. We have strong surety relationships; however, a change in market conditions or the sureties' assessment of our financial position could cause the sureties to require cash collateralization for undischarged liabilities under the bonds.
  (was, 2025-02-07, similarity 0.9857):
[0000080420-25-000029:note_history:1]
Certain customers require us to post letters of credit, bank guarantees or surety bonds. These security instruments assure that we will perform under the terms of our contract. In the event of default, the counterparty may demand payment from the bank under a letter of credit or bank guarantee, or performance by the surety under a bond. To date, there have been no significant draws or claims related to security instruments for the periods reported. We were contingently liable for letters of credit of $56.1 million as of December 31, 2024. We also had surety bonds totaling $432.1 million that were outstanding, with additional bonding capacity of $767.9 million available, at December 31, 2024. We have strong surety relationships; however, a change in market conditions or the sureties' assessment of our financial position could cause the sureties to require cash collateralization for undischarged liabilities under the bonds.

- changed (2025-05-07):
[0000080420-25-000061:note_history:2]
We have a $19.4 million facility agreement (Facility Agreement) between Powell (UK) Limited and a large international bank that provides Powell (UK) Limited the ability to enter into bank guarantees as well as forward exchange contracts and currency options. At March 31, 2025, we had outstanding guarantees totaling $4.0 million, with an additional capacity of $15.4 million available under this Facility Agreement. The Facility Agreement provides for customary events of default and carries cross-default provisions with the U.S. Revolver. If an event of default (as defined in the Facility Agreement) occurs and is continuing, per the terms and subject to the conditions set forth therein, obligations outstanding under the Facility Agreement may be accelerated and declared immediately due and payable. Additionally, we are required to maintain cash collateral for guarantees greater than two years. As of March 31, 2025, we were in compliance with all of the financial covenants of the Facility Agreement.
  (was, 2025-02-07, similarity 0.9864):
[0000080420-25-000029:note_history:2]
We have an $18.8 million facility agreement (Facility Agreement) between Powell (UK) Limited and a large international bank that provides Powell (UK) Limited the ability to enter into bank guarantees as well as forward exchange contracts and currency options. At December 31, 2024, we had outstanding guarantees totaling $7.7 million, with an additional capacity of $11.1 million available under this Facility Agreement. The Facility Agreement provides for customary events of default and carries cross-default provisions with the U.S. Revolver. If an event of default (as defined in the Facility Agreement) occurs and is continuing, per the terms and subject to the conditions set forth therein, obligations outstanding under the Facility Agreement may be accelerated and declared immediately due and payable. Additionally, we are required to maintain cash collateral for guarantees greater than two years. As of December 31, 2024, we were in compliance with all of the financial covenants of the Facility Agreement.

- changed (2025-05-07):
[0000080420-25-000061:note_history:3]
Certain of our customer contracts have schedule and performance obligation clauses that, if we fail to meet them, could require us to pay liquidated damages. Each individual contract defines the conditions under which the customer may make a claim against us. As of March 31, 2025, certain contracts had a probable exposure to liquidated damages claims of $2.7 million, which could possibly increase to $3.6 million under certain circumstances. Based on our actual or projected failure to meet these various contractual commitments, $2.5 million has been recorded as a reduction to revenue. We will attempt to obtain change orders, contract extensions or accelerate project completion, which may resolve the potential for any unrecorded liquidated damages claims. Should we fail to achieve relief on some or all of these contractual obligations, we could be required to pay additional liquidated damages, which could negatively impact our future operating results.
  (was, 2025-02-07, similarity 0.9932):
[0000080420-25-000029:note_history:3]
Certain of our customer contracts have schedule and performance obligation clauses that, if we fail to meet them, could require us to pay liquidated damages. Each individual contract defines the conditions under which the customer may make a claim against us. As of December 31, 2024, certain contracts had a probable exposure to liquidated damages claims of $2.4 million, which could possibly increase to $3.1 million under certain circumstances. Based on our actual or projected failure to meet these various contractual commitments, $2.0 million has been recorded as a reduction to revenue. We will attempt to obtain change orders, contract extensions or accelerate project completion, which may resolve the potential for any unrecorded liquidated damages claims. Should we fail to achieve relief on some or all of these contractual obligations, we could be required to pay additional liquidated damages, which could negatively impact our future operating results.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureAndSignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2025-05-07):
[0000080420-25-000061:note_history:4]
Segment Reporting (Topic 280): Improvements to Reportable Segment Disclosures, which requires that public entities disclose significant segment expenses that are regularly provided to the chief operating decision maker (CODM) on an annual and interim basis. It also requires that public entities disclose the title and position of the CODM and an explanation of how the CODM uses the reported measures in assessing segment performance and resource allocation. Additionally, it requires that all existing annual disclosures about segment profit or loss and assets must be provided on an interim basis and clarifies that single reportable segment entities are subject to the disclosure requirement under Topic 280 in its entirety. ASU 2023-07 is effective for fiscal years beginning after December 15, 2023 and interim periods within fiscal years beginning after December 15, 2024. A public entity should apply ASU 2023-07 retrospectively to all prior periods presented in the financial statements. Early adoption is permitted. We will implement the new disclosure requirements beginning with our Fiscal 2025 Form 10-K.
  (was, 2025-02-07, similarity 0.9364):
[0000080420-25-000029:note_history:4]
Segment Reporting (Topic 280): Improvements to Reportable Segment Disclosures, which requires that public entities disclose significant segment expenses that are regularly provided to the chief operating decision maker (CODM) on an annual and interim basis. It also requires that public entities disclose the title and position of the CODM and an explanation of how the CODM uses the reported measures in assessing segment performance and resource allocation. Additionally, it requires that all existing annual disclosures about segment profit or loss and assets must be provided on an interim basis and clarifies that single reportable segment entities are subject to the disclosure requirement under Topic 280 in its entirety. ASU 2023-07 is effective for fiscal years beginning after December 15, 2023 and interim periods within fiscal years beginning after December 15, 2024. A public entity should apply ASU 2023-07 retrospectively to all prior periods presented in the financial statements. Early adoption is permitted. We are currently evaluating the impacts of the new standard.

- removed (2025-05-07):
[0000080420-25-000029:note_history:5]
In March 2024, the SEC adopted final rules designed to enhance and standardize disclosures related to the risks and impacts of climate-related matters. The final rules require registrants to disclose certain climate-related information in registration statements and annual reports. Such information relates to climate-related risks and risk management processes for, and governance and oversight activities of, such risks. The final rules also include requirements to disclose the financial effects of severe weather events and other natural conditions in the audited financial statements. In addition, larger registrants will be required to disclose information about greenhouse gas emissions, which will be subject to a phased-in assurance requirement. These disclosure requirements were scheduled to be effective for the Company's fiscal year beginning October 1, 2025. However, in April 2024, the SEC voluntarily stayed the final rules as a result of pending legal challenges. We are currently evaluating the impacts of the final rules on our consolidated financial statements and related disclosures.


## us-gaap:LongTermDebtTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2025-05-07):
[0000080420-25-000061:note_history:6]
As of March 31, 2025, there were no amounts borrowed under the U.S. Revolver, and letters of credit outstanding were $64.4 million. There was $85.6 million available for the issuance of letters of credit and borrowings under the U.S. Revolver as of March 31, 2025.
  (was, 2025-02-07, similarity 0.9317):
[0000080420-25-000029:note_history:6]
As of December 31, 2024, there were no amounts borrowed under the U.S. Revolver, and letters of credit outstanding were $56.1 million. There was $93.9 million available for the issuance of letters of credit and borrowings under the U.S. Revolver as of December 31, 2024.

- changed (2025-05-07):
[0000080420-25-000061:note_history:7]
As of March 31, 2025, we were in compliance with all of the financial covenants of the U.S. Revolver.
  (was, 2025-02-07, similarity 0.9534):
[0000080420-25-000029:note_history:7]
As of December 31, 2024, we were in compliance with all of the financial covenants of the U.S. Revolver.


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2025-05-07):
[0000080420-25-000061:note_history:8]
The following tables present our disaggregated revenue by geographic destination and market sector for the three and six months ended March 31, 2025 and 2024 (in thousands):
  (was, 2025-02-07, similarity 0.9477):
[0000080420-25-000029:note_history:8]
The following tables present our disaggregated revenue by geographic destination and market sector for the three months ended December 31, 2024 and 2023 (in thousands):

- added (2025-05-07):
[0000080420-25-000061:note_history:9]
|  | Three months ended March 31, |  | Six months ended March 31, |
|  | 2025 |  | 2024 |  | 2025 |  | 2024 |
| United States | $ | 227,834 |  |  | $ | 216,933 |  |  | $ | 425,606 |  |  | $ | 376,793 |  |
| Canada | 33,970 |  |  | 24,160 |  |  | 65,664 |  |  | 44,510 |  |
| Europe | 5,897 |  |  | 8,265 |  |  | 11,425 |  |  | 14,797 |  |
| Middle East and Africa | 8,282 |  |  | 2,803 |  |  | 12,840 |  |  | 6,078 |  |
| Mexico, Central and South America | 1,002 |  |  | 2,159 |  |  | 1,301 |  |  | 4,816 |  |
| Asia/Pacific | 1,646 |  |  | 788 |  |  | 3,226 |  |  | 2,131 |  |
| Total revenues by geographic destination | $ | 278,631 |  |  | $ | 255,108 |  |  | $ | 520,062 |  |  | $ | 449,125 |  |

- added (2025-05-07):
[0000080420-25-000061:note_history:10]
|  | Three months ended March 31, |  | Six months ended March 31, |
|  | 2025 |  | 2024 |  | 2025 |  | 2024 |
| Oil and gas (excludes petrochemical) | $ | 101,167 |  |  | $ | 103,820 |  |  | $ | 196,846 |  |  | $ | 187,456 |  |
| Petrochemical | 43,704 |  |  | 50,070 |  |  | 76,887 |  |  | 78,437 |  |
| Electric utility | 70,339 |  |  | 47,502 |  |  | 121,579 |  |  | 88,205 |  |
| Commercial and other industrial | 40,369 |  |  | 34,894 |  |  | 84,669 |  |  | 59,566 |  |
| Light rail traction power | 10,008 |  |  | 4,517 |  |  | 18,236 |  |  | 8,862 |  |
| All others | 13,044 |  |  | 14,305 |  |  | 21,845 |  |  | 26,599 |  |
| Total revenues by market sector | $ | 278,631 |  |  | $ | 255,108 |  |  | $ | 520,062 |  |  | $ | 449,125 |  |

- removed (2025-05-07):
[0000080420-25-000029:note_history:11]
|  | Three months ended December 31, |  |  |
|  | 2024 |  | 2023 |  |  |  |  |
| United States | $ | 197,772 |  |  | $ | 159,860 |  |  |  |  |  |
| Canada | 31,694 |  |  | 20,350 |  |  |  |  |  |
| Europe | 5,528 |  |  | 6,532 |  |  |  |  |  |
| Middle East and Africa | 4,558 |  |  | 3,275 |  |  |  |  |  |
| Mexico, Central and South America | 299 |  |  | 2,657 |  |  |  |  |  |
| Asia/Pacific | 1,580 |  |  | 1,343 |  |  |  |  |  |
| Total revenues by geographic destination | $ | 241,431 |  |  | $ | 194,017 |  |  |  |  |  |

- removed (2025-05-07):
[0000080420-25-000029:note_history:12]
|  | Three months ended December 31, |  |  |
|  | 2024 |  | 2023 |  |  |  |  |
| Oil and gas (excludes petrochemical) | $ | 95,679 |  |  | $ | 83,636 |  |  |  |  |  |
| Petrochemical | 33,183 |  |  | 28,367 |  |  |  |  |  |
| Electric utility | 51,240 |  |  | 40,703 |  |  |  |  |  |
| Commercial and other industrial | 44,300 |  |  | 24,672 |  |  |  |  |  |
| Light rail traction power | 8,228 |  |  | 4,345 |  |  |  |  |  |
| All others | 8,801 |  |  | 12,294 |  |  |  |  |  |
| Total revenues by market sector | $ | 241,431 |  |  | $ | 194,017 |  |  |  |  |  |


## us-gaap:RevenueFromContractWithCustomerPolicyTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2025-05-07):
[0000080420-25-000061:note_history:13]
We also have contracts to provide field service inspection, installation, commissioning, modification, and repair services, as well as retrofit and retrofill components for existing systems. If the service contract terms give us the right to invoice the customer for an amount that corresponds directly with the value of our performance completed to date (i.e., a service contract in which we bill a fixed amount for each hour of service provided), then we recognize revenue over time in each reporting period corresponding to the amount that we have the right to invoice. Our performance obligations are satisfied as the work progresses. Revenues from our custom-engineered products and value-added services transferred to customers over time accounted for approximately 95% of revenues for the three months ended March 31, 2025, 96% of revenues for the six months ended March 31, 2025, 95% of revenues for the three months ended March 31, 2024, and 94% of revenues for the six months ended March 31, 2024.
  (was, 2025-02-07, similarity 0.8768):
[0000080420-25-000029:note_history:13]
We also have contracts to provide field service inspection, installation, commissioning, modification, and repair services, as well as retrofit and retrofill components for existing systems. If the service contract terms give us the right to invoice the customer for an amount that corresponds directly with the value of our performance completed to date (i.e., a service contract in which we bill a fixed amount for each hour of service provided), then we recognize revenue over time in each reporting period corresponding to the amount that we have the right to invoice. Our performance obligations are satisfied as the work progresses. Revenues from our custom-engineered products and value-added services transferred to customers over time accounted for approximately 97% and 94% of revenues for the three months ended December 31, 2024 and December 31, 2023, respectively.

- changed (2025-05-07):
[0000080420-25-000061:note_history:14]
We also have sales orders for spare parts and replacement circuit breakers for switchgear that are obsolete or that are no longer produced by the original manufacturer. Revenues from these sales orders are recognized at the time we fulfill our performance obligation to the customer, which is typically upon shipment and represented approximately 5% of revenues for the three months ended March 31, 2025, 4% of revenues for the six months ended March 31, 2025, 5% of revenues for the three months ended March 31, 2024, and 6% of revenues for the six months ended March 31, 2024.
  (was, 2025-02-07, similarity 0.7875):
[0000080420-25-000029:note_history:14]
We also have sales orders for spare parts and replacement circuit breakers for switchgear that are obsolete or that are no longer produced by the original manufacturer. Revenues from these sales orders are recognized at the time we fulfill our performance obligation to the customer, which is typically upon shipment and represented approximately 3% and 6% of revenues for the three months ended December 31, 2024 and December 31, 2023, respectively.


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2025-05-07):
[0000080420-25-000061:note_history:15]
We also have contracts to provide field service inspection, installation, commissioning, modification, and repair services, as well as retrofit and retrofill components for existing systems. If the service contract terms give us the right to invoice the customer for an amount that corresponds directly with the value of our performance completed to date (i.e., a service contract in which we bill a fixed amount for each hour of service provided), then we recognize revenue over time in each reporting period corresponding to the amount that we have the right to invoice. Our performance obligations are satisfied as the work progresses. Revenues from our custom-engineered products and value-added services transferred to customers over time accounted for approximately 95% of revenues for the three months ended March 31, 2025, 96% of revenues for the six months ended March 31, 2025, 95% of revenues for the three months ended March 31, 2024, and 94% of revenues for the six months ended March 31, 2024.
  (was, 2025-02-07, similarity 0.8768):
[0000080420-25-000029:note_history:15]
We also have contracts to provide field service inspection, installation, commissioning, modification, and repair services, as well as retrofit and retrofill components for existing systems. If the service contract terms give us the right to invoice the customer for an amount that corresponds directly with the value of our performance completed to date (i.e., a service contract in which we bill a fixed amount for each hour of service provided), then we recognize revenue over time in each reporting period corresponding to the amount that we have the right to invoice. Our performance obligations are satisfied as the work progresses. Revenues from our custom-engineered products and value-added services transferred to customers over time accounted for approximately 97% and 94% of revenues for the three months ended December 31, 2024 and December 31, 2023, respectively.

- changed (2025-05-07):
[0000080420-25-000061:note_history:16]
We also have sales orders for spare parts and replacement circuit breakers for switchgear that are obsolete or that are no longer produced by the original manufacturer. Revenues from these sales orders are recognized at the time we fulfill our performance obligation to the customer, which is typically upon shipment and represented approximately 5% of revenues for the three months ended March 31, 2025, 4% of revenues for the six months ended March 31, 2025, 5% of revenues for the three months ended March 31, 2024, and 6% of revenues for the six months ended March 31, 2024.
  (was, 2025-02-07, similarity 0.7875):
[0000080420-25-000029:note_history:16]
We also have sales orders for spare parts and replacement circuit breakers for switchgear that are obsolete or that are no longer produced by the original manufacturer. Revenues from these sales orders are recognized at the time we fulfill our performance obligation to the customer, which is typically upon shipment and represented approximately 3% and 6% of revenues for the three months ended December 31, 2024 and December 31, 2023, respectively.

- changed (2025-05-07):
[0000080420-25-000061:note_history:17]
Remaining unsatisfied performance obligations, which we refer to as backlog, represent the estimated transaction price for goods and services for which we have a material right, but work has not been performed. As of March 31, 2025, we had
  (was, 2025-02-07, similarity 0.6404):
[0000080420-25-000029:note_history:17]
Remaining unsatisfied performance obligations, which we refer to as backlog, represent the estimated transaction price for goods and services for which we have a material right, but work has not been performed. As of December 31, 2024, we had backlog of $1.3 billion, of which approximately $893 million is expected to be recognized as revenue within the next twelve months. Backlog may not be indicative of future operating results as orders may be cancelled or modified by our customers.

- added (2025-05-07):
[0000080420-25-000061:note_history:18]
backlog of $1.3 billion, of which approximately $831 million is expected to be recognized as revenue within the next twelve months. Backlog may not be indicative of future operating results as orders may be cancelled or modified by our customers. Our backlog does not include service and maintenance-type contracts for which we have the right to invoice as services are performed.

- changed (2025-05-07):
[0000080420-25-000061:note_history:19]
For the six months ended March 31, 2025 and 2024, our operating results were positively impacted by $8.8 million and $7.8 million, respectively, as a result of net changes in contract estimates related to projects in progress at the beginning of the respective period. These changes in estimates resulted primarily from favorable project execution, reduced cost estimates and negotiations of variable consideration, discussed below, as well as revenue recognized from project cancellations and other changes in facts and circumstances during these periods. Gross unfavorable changes in contract estimates were immaterial for both the six months ended March 31, 2025 and 2024.
  (was, 2025-02-07, similarity 0.9103):
[0000080420-25-000029:note_history:19]
For the three months ended December 31, 2024 and 2023, our operating results were positively impacted by $2.4 million and $5.4 million, respectively, as a result of net changes in contract estimates related to projects in progress at the beginning of the respective period. These changes in estimates resulted primarily from favorable project execution, reduced cost estimates and negotiations of variable consideration, discussed below, as well as revenue recognized from project cancellations and other changes in facts and circumstances during these periods. Gross unfavorable changes in contract estimates were immaterial for both the three months ended December 31, 2024 and 2023.

- changed (2025-05-07):
[0000080420-25-000061:note_history:20]
Contract assets and liabilities as of March 31, 2025 and September 30, 2024 are summarized below (in thousands):
  (was, 2025-02-07, similarity 0.9565):
[0000080420-25-000029:note_history:20]
Contract assets and liabilities as of December 31, 2024 and September 30, 2024 are summarized below (in thousands):

- changed (2025-05-07):
[0000080420-25-000061:note_history:21]
|  | March 31, 2025 |  | September 30, 2024 |
| Contract assets | $ | 115,943 |  |  | $ | 102,827 |  |
| Contract liabilities | (283,372) |  |  | (287,763) |  |
| Net contract liability | $ | (167,429) |  |  | $ | (184,936) |  |
  (was, 2025-02-07, similarity 0.9739):
[0000080420-25-000029:note_history:21]
|  | December 31, 2024 |  | September 30, 2024 |
| Contract assets | $ | 92,349 |  |  | $ | 102,827 |  |
| Contract liabilities | (282,595) |  |  | (287,763) |  |
| Net contract liability | $ | (190,246) |  |  | $ | (184,936) |  |

- changed (2025-05-07):
[0000080420-25-000061:note_history:22]
Our net contract billing position remained a net liability at both March 31, 2025 and September 30, 2024, primarily due to favorable contract billing milestones. We typically allocate a significant percentage of the progress billing to the early stages of the contract. To determine the amount of revenue recognized during the period from contract liabilities, we first allocate revenue to the individual contract liability balance outstanding at the beginning of the period until the revenue exceeds that balance. During the six months ended March 31, 2025, we recognized revenue of $203.4 million that was related to contract liabilities outstanding at September 30, 2024.
  (was, 2025-02-07, similarity 0.9524):
[0000080420-25-000029:note_history:22]
Our net contract billing position remained a net liability at both December 31, 2024 and September 30, 2024, primarily due to favorable contract billing milestones. We typically allocate a significant percentage of the progress billing to the early stages of the contract. To determine the amount of revenue recognized during the period from contract liabilities, we first allocate revenue to the individual contract liability balance outstanding at the beginning of the period until the revenue exceeds that balance. During the three months ended December 31, 2024, we recognized revenue of $116.9 million that was related to contract liabilities outstanding at September 30, 2024.

- changed (2025-05-07):
[0000080420-25-000061:note_history:23]
The timing of our invoice process is typically dependent on the completion of certain milestones and contract terms and subject to agreement by our customer. Payment is typically expected within 30 days of invoice. Any uncollected invoiced amounts for our performance obligations recognized over time, including contract retentions, are recorded as accounts receivable in the Condensed Consolidated Balance Sheets. Certain contracts allow customers to withhold a small percentage of billings pursuant to retainage provisions, and such amounts are generally due upon completion of the contract and acceptance of the project by the customer. Based on our experience in recent years, the majority of these retainage balances are expected to be collected within approximately twelve months. As of March 31, 2025 and September 30, 2024, we had retention amounts of $7.9 million and $7.1 million, respectively. Of the retained amount at March 31, 2025, $7.6 million is expected to be collected in the next twelve months and is recorded in accounts receivable. The remaining $0.3 million is recorded in other assets.
  (was, 2025-02-07, similarity 0.988):
[0000080420-25-000029:note_history:23]
The timing of our invoice process is typically dependent on the completion of certain milestones and contract terms and subject to agreement by our customer. Payment is typically expected within 30 days of invoice. Any uncollected invoiced amounts for our performance obligations recognized over time, including contract retentions, are recorded as accounts receivable in the Condensed Consolidated Balance Sheets. Certain contracts allow customers to withhold a small percentage of billings pursuant to retainage provisions, and such amounts are generally due upon completion of the contract and acceptance of the project by the customer. Based on our experience in recent years, the majority of these retainage balances are expected to be collected within approximately twelve months. As of December 31, 2024 and September 30, 2024, we had retention amounts of $7.5 million and $7.1 million, respectively. Of the retained amount at December 31, 2024, $6.7 million is expected to be collected in the next twelve months and is recorded in accounts receivable. The remaining $0.8 million is recorded in other assets.

- changed (2025-05-07):
[0000080420-25-000061:note_history:24]
The following tables present our disaggregated revenue by geographic destination and market sector for the three and six months ended March 31, 2025 and 2024 (in thousands):
  (was, 2025-02-07, similarity 0.9477):
[0000080420-25-000029:note_history:24]
The following tables present our disaggregated revenue by geographic destination and market sector for the three months ended December 31, 2024 and 2023 (in thousands):

- added (2025-05-07):
[0000080420-25-000061:note_history:25]
|  | Three months ended March 31, |  | Six months ended March 31, |
|  | 2025 |  | 2024 |  | 2025 |  | 2024 |
| United States | $ | 227,834 |  |  | $ | 216,933 |  |  | $ | 425,606 |  |  | $ | 376,793 |  |
| Canada | 33,970 |  |  | 24,160 |  |  | 65,664 |  |  | 44,510 |  |
| Europe | 5,897 |  |  | 8,265 |  |  | 11,425 |  |  | 14,797 |  |
| Middle East and Africa | 8,282 |  |  | 2,803 |  |  | 12,840 |  |  | 6,078 |  |
| Mexico, Central and South America | 1,002 |  |  | 2,159 |  |  | 1,301 |  |  | 4,816 |  |
| Asia/Pacific | 1,646 |  |  | 788 |  |  | 3,226 |  |  | 2,131 |  |
| Total revenues by geographic destination | $ | 278,631 |  |  | $ | 255,108 |  |  | $ | 520,062 |  |  | $ | 449,125 |  |

- added (2025-05-07):
[0000080420-25-000061:note_history:26]
|  | Three months ended March 31, |  | Six months ended March 31, |
|  | 2025 |  | 2024 |  | 2025 |  | 2024 |
| Oil and gas (excludes petrochemical) | $ | 101,167 |  |  | $ | 103,820 |  |  | $ | 196,846 |  |  | $ | 187,456 |  |
| Petrochemical | 43,704 |  |  | 50,070 |  |  | 76,887 |  |  | 78,437 |  |
| Electric utility | 70,339 |  |  | 47,502 |  |  | 121,579 |  |  | 88,205 |  |
| Commercial and other industrial | 40,369 |  |  | 34,894 |  |  | 84,669 |  |  | 59,566 |  |
| Light rail traction power | 10,008 |  |  | 4,517 |  |  | 18,236 |  |  | 8,862 |  |
| All others | 13,044 |  |  | 14,305 |  |  | 21,845 |  |  | 26,599 |  |
| Total revenues by market sector | $ | 278,631 |  |  | $ | 255,108 |  |  | $ | 520,062 |  |  | $ | 449,125 |  |

- removed (2025-05-07):
[0000080420-25-000029:note_history:27]
Our backlog does not include service and maintenance-type contracts for which we have the right to invoice as services are performed.

- removed (2025-05-07):
[0000080420-25-000029:note_history:28]
|  | Three months ended December 31, |  |  |
|  | 2024 |  | 2023 |  |  |  |  |
| United States | $ | 197,772 |  |  | $ | 159,860 |  |  |  |  |  |
| Canada | 31,694 |  |  | 20,350 |  |  |  |  |  |
| Europe | 5,528 |  |  | 6,532 |  |  |  |  |  |
| Middle East and Africa | 4,558 |  |  | 3,275 |  |  |  |  |  |
| Mexico, Central and South America | 299 |  |  | 2,657 |  |  |  |  |  |
| Asia/Pacific | 1,580 |  |  | 1,343 |  |  |  |  |  |
| Total revenues by geographic destination | $ | 241,431 |  |  | $ | 194,017 |  |  |  |  |  |

- removed (2025-05-07):
[0000080420-25-000029:note_history:29]
|  | Three months ended December 31, |  |  |
|  | 2024 |  | 2023 |  |  |  |  |
| Oil and gas (excludes petrochemical) | $ | 95,679 |  |  | $ | 83,636 |  |  |  |  |  |
| Petrochemical | 33,183 |  |  | 28,367 |  |  |  |  |  |
| Electric utility | 51,240 |  |  | 40,703 |  |  |  |  |  |
| Commercial and other industrial | 44,300 |  |  | 24,672 |  |  |  |  |  |
| Light rail traction power | 8,228 |  |  | 4,345 |  |  |  |  |  |
| All others | 8,801 |  |  | 12,294 |  |  |  |  |  |
| Total revenues by market sector | $ | 241,431 |  |  | $ | 194,017 |  |  |  |  |  |


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: tag_name, score: 1.0

- added (2025-05-07):
[0000080420-25-000061:note_history:30]
On May 6, 2025, our Board of Directors declared a quarterly cash dividend on our common stock in the amount of $0.2675 per share. The dividend is payable on June 18, 2025 to shareholders of record at the close of business on May 21, 2025.

- removed (2025-05-07):
[0000080420-25-000029:note_history:31]
On February 4, 2025, our Board of Directors approved an increase to the quarterly cash dividend on our common stock to $0.2675 per share, equating to an annualized dividend of $1.07 per share from the current amount of $1.06 per share. The dividend is payable on March 19, 2025 to shareholders of record at the close of business on February 19, 2025.
