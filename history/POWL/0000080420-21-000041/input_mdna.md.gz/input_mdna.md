# POWL MD&A — 0000080420-21-000041


## mdna

[0000080420-21-000041:mdna:1]
[same as prior period, unchanged from 0000080420-21-000029:mdna:1]

[0000080420-21-000041:mdna:2]
[same as prior period, unchanged from 0000080420-21-000029:mdna:2]

[0000080420-21-000041:mdna:3]
[same as prior period, unchanged from 0000080420-21-000029:mdna:3]

[0000080420-21-000041:mdna:4]
We develop, design, manufacture and service custom-engineered equipment and systems which (1) distribute, control and monitor the flow of electrical energy and (2) provide protection to motors, transformers and other electrically powered equipment. We are headquartered in Houston, Texas and serve the oil and gas markets, including onshore and offshore oil and gas production, petrochemical, liquefied natural gas (LNG) terminals, pipeline, terminal, mining and metals, light rail traction power, electric utility, pulp and paper and other industrial markets. Revenues and costs are primarily related to custom engineered-to-order equipment and systems and are accounted for under percentage-of-completion accounting, which precludes us from providing detailed price and volume information. Our backlog includes various projects that typically take a number of months to produce.

[0000080420-21-000041:mdna:5]
[same as prior period, unchanged from 0000080420-21-000029:mdna:5]

[0000080420-21-000041:mdna:6]
[same as prior period, unchanged from 0000080420-21-000029:mdna:6]

[0000080420-21-000041:mdna:7]
The combination of a growing global economy, abundant sources of favorably priced natural gas feedstock, and an energy industry focus on transition to natural gas and cleaner-burning fuels drove an increase in capital investment opportunities, specifically across the oil, gas and petrochemical sectors. Some of these opportunities were for natural gas related projects targeting global demand for cleaner-burning fuels. Additionally, projects within the domestic petrochemical sector benefited from the low feedstock prices of natural gas. Specific to natural gas, the business was awarded a substantial contract in the second quarter of Fiscal 2020 that will support the integrated electrical distribution requirements for a large domestic industrial complex and should be substantially completed in Fiscal 2022. However, we began to experience reduced commercial activity in Fiscal 2020 driven in large part by the uncertainties across our industrial end markets in the U.S. resulting from the COVID-19 pandemic. Considering the long cycle nature of our business, we anticipate that these cyclical conditions may persist throughout Fiscal 2021 and into early Fiscal 2022.

[0000080420-21-000041:mdna:8]
[same as prior period, unchanged from 0000080420-21-000029:mdna:8]

[0000080420-21-000041:mdna:9]
Through the first nine months of Fiscal 2021, the COVID-19 pandemic continues to impact global energy markets. This pandemic has negatively impacted demand, which in turn has resulted in considerable volatility across global oil and gas commodity markets. The demand for our products and services as well as our operations have been negatively impacted by COVID-19, resulting from the associated reduction in oil and gas demand and volatility in commodity prices noted above. As a result, some of our industrial customers are deferring or suspending their planned capital expenditures. Certain of our customers have asked that we delay or cancel our manufacturing on their projects as their operations have been negatively impacted by this pandemic and the reduced oil and gas demand which has resulted in recognition of cancellation fees based on contract terms and the extent of our progress on the projects. We continue to work with and review the contracts with our key suppliers who have been impacted by this pandemic to ensure that we are able to meet our customer commitments.

[0000080420-21-000041:mdna:10]
In response to the lower demand across select end markets, we have taken and will continue to take various actions to reduce costs. During Fiscal 2020, we reduced our global workforce and reduced our capital and discretionary spending in response to current business conditions. We continue to operate at these lower thresholds and are consistently monitoring the macro-economic conditions throughout the remainder of Fiscal 2021.

[0000080420-21-000041:mdna:11]
[same as prior period, unchanged from 0000080420-21-000029:mdna:11]

[0000080420-21-000041:mdna:12]
[same as prior period, unchanged from 0000080420-21-000029:mdna:12]

[0000080420-21-000041:mdna:13]
Quarter Ended June 30, 2021 Compared to the Quarter Ended June 30, 2020 (Unaudited)

[0000080420-21-000041:mdna:14]
[same as prior period, unchanged from 0000080420-21-000029:mdna:14]

[0000080420-21-000041:mdna:15]
Revenues decreased by 2%, or $2.2 million, to $115.8 million in the third quarter of Fiscal 2021, due to a decrease in orders as well as project delays and cancellations of potential projects associated with the global economic impact resulting from the COVID-19 pandemic and associated reduction in demand across our industrial end markets. These cyclical market conditions, which began in the second half of Fiscal 2020, led to a reduction in project bookings and an increase in project delays which have negatively impacted, and will continue to negatively impact, our revenues in Fiscal 2021. Domestic revenues decreased, as noted above, by 3%, or $2.8 million, to $88.4 million in the third quarter of Fiscal 2021. Included in our domestic revenues is our large domestic industrial project awarded in Fiscal 2020, which accounted for approximately 18% of our consolidated revenues for the third quarter of Fiscal 2021 compared to 9% in the same period of the prior year. International revenues increased by $0.6 million, to $27.4 million in the third quarter of Fiscal 2021. Our international revenues include both revenues generated from our international facilities as well as revenues from export projects generated at our domestic facilities.

[0000080420-21-000041:mdna:16]
Revenue from our oil and gas end markets increased by 7%, or $3.4 million, to $49.3 million in the third quarter of Fiscal 2021, while petrochemical revenue decreased by 48%, or $13.9 million, to $15.4 million in the third quarter of Fiscal 2021, primarily due to the uncertainty across our industrial end markets. Revenue from our utility markets increased by 57%, or $9.5 million, to $26.2 million, and traction market revenue increased by 52%, or $4.7 million, to $13.8 million in the third quarter of Fiscal 2021. Revenue from all other markets combined decreased by $5.9 million to $11.2 million in the third quarter of Fiscal 2021.

[0000080420-21-000041:mdna:17]
The reduction in revenue led to a subsequent reduction in gross profit, decreasing by 20%, or $4.2 million, to $17.2 million for the third quarter of Fiscal 2021. Gross profit as a percentage of revenues decreased to 15% in the third quarter of Fiscal 2021, compared to 18% in the third quarter of Fiscal 2020. The reduction in gross profit as a percentage of revenues was driven predominately by increasing commodity costs, facility under-utilization driven by lower revenues and increased employee benefit costs.

[0000080420-21-000041:mdna:18]
[same as prior period, unchanged from 0000080420-21-000029:mdna:18]

[0000080420-21-000041:mdna:19]
Selling, general and administrative expenses increased by 8%, or $1.2 million, to $16.7 million in the third quarter of Fiscal 2021, driven by increased employee benefit costs in the third quarter of Fiscal 2021. In the third quarter of Fiscal 2020, employee benefit costs and travel-related expenses were lower as a result of the COVID-19 pandemic. Selling, general and administrative expenses as a percentage of revenues was 14% during the third quarter of Fiscal 2021 compared to 13% during the third quarter of Fiscal 2020, primarily due to the decrease in revenue.

[0000080420-21-000041:mdna:20]
Restructuring and Other, Net

[0000080420-21-000041:mdna:21]
In the third quarter of Fiscal 2020, as a result of the COVID-19 pandemic, reductions in oil and gas demand and volatility of commodity prices, we implemented workforce reductions across the business and recorded $1.4 million of separation costs.

[0000080420-21-000041:mdna:22]
[same as prior period, unchanged from 0000080420-21-000029:mdna:20]

[0000080420-21-000041:mdna:23]
We recorded an income tax provision of $0.7 million in the third quarter of Fiscal 2021, compared to an income tax benefit of $0.6 million in the third quarter of Fiscal 2020. The effective tax rate for the third quarter of Fiscal 2021 was negative 53%, compared to an effective tax rate of negative 19% in the third quarter of Fiscal 2020. For the three months ended June 30, 2021, the effective tax rate was negatively impacted by our inability to recognize a tax benefit related to losses in the United Kingdom and the change in the estimated relative amounts of income/loss recognized in the various tax jurisdictions. The estimated Research and Development Tax Credit (R&D Tax Credit) and the utilization of net operating loss carryforwards in Canada that were fully reserved with a valuation allowance provided a tax benefit for the three months ended June 30, 2021 and 2020. Additionally, in the third quarter of Fiscal 2020, we recognized a benefit primarily from the settlement of an Internal Revenue Service (IRS) audit for $1.7 million.

[0000080420-21-000041:mdna:24]
[same as prior period, unchanged from 0000080420-21-000029:mdna:22]

[0000080420-21-000041:mdna:25]
In the third quarter of Fiscal 2021, we recorded a net loss of $2.0 million, or a loss of $0.17 per diluted share, compared to net income of $3.5 million, or $0.30 per diluted share, in the third quarter of Fiscal 2020. This decrease is attributable to lower revenues and the associated negative operating leverage in the third fiscal quarter of 2021 versus the prior year as well as increasing commodity costs for both copper and steel.

[0000080420-21-000041:mdna:26]
[same as prior period, unchanged from 0000080420-21-000029:mdna:24]

[0000080420-21-000041:mdna:27]
The order backlog at June 30, 2021 was $425.5 million, a decrease of 3% from $436.6 million at March 31, 2021 and a decrease of 20% from $532.2 million of backlog at June 30, 2020. Bookings, net of cancellations and scope reductions, increased by 27% in the third quarter of Fiscal 2021 to $103.2 million, compared to $81.4 million in the third quarter of Fiscal 2020.

[0000080420-21-000041:mdna:28]
Nine Months Ended June 30, 2021 Compared to the Nine Months Ended June 30, 2020 (Unaudited)

[0000080420-21-000041:mdna:29]
[same as prior period, unchanged from 0000080420-21-000029:mdna:27]

[0000080420-21-000041:mdna:30]
Revenues decreased by 16%, or $62.7 million, to $341.1 million in the nine months ended June 30, 2021, due to a decrease in orders as well as project delays and cancellations of potential projects associated with the global economic impact resulting from the COVID-19 pandemic and associated reduction in demand across our industrial end markets. Domestic revenues decreased by 19%, or $61.3 million, to $256.9 million in the nine months ended June 30, 2021. International revenues decreased by 2%, or $1.4 million, to $84.2 million. Our international revenues include both revenues generated from our international facilities as well as revenues from export projects generated at our domestic facilities.

[0000080420-21-000041:mdna:31]
Revenue from our oil and gas markets decreased by 12%, or $18.4 million, to $139.4 million in the nine months ended June 30, 2021. Petrochemical revenue decreased by 68%, or $72.3 million, to $34.7 million in the nine months ended June 30, 2021. Revenue from utility markets increased by 29%, or $18.8 million, to $82.8 million, and traction market revenue increased by 35%, or $10.9 million, to $42.3 million in the nine months ended June 30, 2021. Revenue from all other markets combined decreased by 4%, or $1.7 million, to $41.8 million in the nine months ended June 30, 2021.

[0000080420-21-000041:mdna:32]
The reduction in revenue led to a reduction in gross profit of 28%, or $20.3 million, as compared to the first nine months of Fiscal 2020. However, gross profit of $52.6 million for the first nine months of Fiscal 2021 benefited from favorable close out gains on certain projects resulting from cost and productivity efficiencies and to a lesser extent from cancellation fees from certain contracts in our North American manufacturing facilities, which was partially offset by higher commodity prices and factory underutilization. Gross profit as a percentage of revenues decreased to 15% in the nine months ended June 30, 2021, compared to 18% in the nine months ended June 30, 2020 as a result of the reduction in revenue noted above.

[0000080420-21-000041:mdna:33]
[same as prior period, unchanged from 0000080420-21-000029:mdna:31]

[0000080420-21-000041:mdna:34]
Selling, general and administrative expenses decreased by 2%, or $1.1 million, to $50.3 million in the nine months ended June 30, 2021, partially due to the restructuring action taken in the third quarter of Fiscal 2020 as well as lower travel-related costs. Selling, general and administrative expenses, as a percentage of revenues increased to 15% during the nine months ended June 30, 2021, compared to 13% during the nine months ended June 30, 2020, primarily due to the decrease in revenues.

[0000080420-21-000041:mdna:35]
Restructuring and Other, Net

[0000080420-21-000041:mdna:36]
In response to the COVID-19 pandemic, reductions in oil and gas demand and volatility of commodity prices, we implemented workforce reductions across the business. As a result, we recorded $1.4 million of separation costs during the third quarter of Fiscal 2020.

[0000080420-21-000041:mdna:37]
[same as prior period, unchanged from 0000080420-21-000029:mdna:33]

[0000080420-21-000041:mdna:38]
We recorded an income tax benefit of $0.1 million in the nine months ended June 30, 2021, compared to an income tax provision of $2.1 million in the nine months ended June 30, 2020. The effective tax rate for the nine months ended June 30, 2021 was 5%, compared to an effective tax rate of 13% for the nine months ended June 30, 2020. For the nine months ended June 30, 2021 and 2020, the effective tax rate was negatively impacted by our inability to recognize a tax benefit related to losses in the United Kingdom and the estimated relative amounts of income/loss recognized in various jurisdictions. The estimated R&D Tax Credit as well as the utilization of net operating loss carryforwards in Canada that were fully reserved with a valuation allowance provided a tax benefit for the nine months ended June 30, 2021.

[0000080420-21-000041:mdna:39]
[same as prior period, unchanged from 0000080420-21-000029:mdna:35]

[0000080420-21-000041:mdna:40]
In the nine months ended June 30, 2021, we recorded a net loss of $2.6 million, or a loss of $0.22 per diluted share, compared to net income of $13.7 million, or $1.17 per diluted share, in the nine months ended June 30, 2020, primarily due to a decline in revenues and gross profit resulting from lower orders and project delays caused by the economic impact resulting from the COVID-19 pandemic and the associated reduction in global demand across our industrial end markets.

[0000080420-21-000041:mdna:41]
[same as prior period, unchanged from 0000080420-21-000029:mdna:37]

[0000080420-21-000041:mdna:42]
The order backlog at June 30, 2021 was $425.5 million, a decrease of 11% from $476.8 million at September 30, 2020. Bookings, net of cancellations and scope reductions, decreased by 46% during the nine months ended June 30, 2021 to $282.9 million, compared to $519.5 million in the nine months ended June 30, 2020. The decrease in bookings was primarily due to the large contract awarded in the second quarter of Fiscal 2020 and decreased global demand across our industrial end markets.

[0000080420-21-000041:mdna:43]
[same as prior period, unchanged from 0000080420-21-000029:mdna:39]

[0000080420-21-000041:mdna:44]
As noted in "Overview" above, the markets in which we participate are capital-intensive and cyclical in nature. A significant portion of our revenues has historically been from the oil, gas and petrochemical markets. Oil and gas commodity price levels have been unstable over the last several years, and our customers have in certain cases delayed or cancelled some of their major capital investment projects. Beginning in late Fiscal 2018 through the first quarter of Fiscal 2020, our customers' decisions to invest in projects in our key oil and gas and petrochemical markets were influenced to some extent by relative stabilization of commodity prices and the increased global demand for cleaner-burning fuels during that period of time. We believe that this change in market sentiment during that period of time had a favorable impact on our orders and backlog entering Fiscal 2020. However, the uncertainty in oil prices and the global economic impacts from COVID-19 have had, and may continue to have, a negative impact on our business going forward, as discussed in more detail below. Specific to the energy industry focus on transitioning to natural gas and cleaner-burning fuels, the business was awarded a substantial contract in Fiscal 2020 that will support the integrated electrical distribution requirements for a large domestic industrial complex and should be substantially completed in Fiscal 2022.

[0000080420-21-000041:mdna:45]
Our operating results are impacted by factors such as the timing of new order awards, customer approval of final engineering and design specifications and delays in customer construction schedules, all of which contribute to short-term earnings variability and the timing of project execution. Our operating results also have been, and may continue to be, impacted by the timing and resolution of change orders, project close-out and resolution of potential contract claims and liquidated damages, all of which could improve or deteriorate gross margins during the period in which these items are resolved with our customers. These factors may result in periods of underutilization of our resources and facilities, which may negatively impact our ability to cover our fixed costs. The strong commercial activity and subsequent orders in Fiscal 2018 and 2019 led to solid revenue and operating results for Fiscal 2020. We began to experience lower commercial activity in Fiscal 2020 driven in large part from the   uncertainty resulting from the COVID-19 pandemic, as discussed in "Overview" above. Considering the long cycle nature of our business, we anticipate these cyclical conditions may persist throughout Fiscal 2021 and into early Fiscal 2022. We will continue to monitor the variables that impact our markets while adjusting to the global conditions in order to maintain competitive cost and technological advantages in the markets that we serve.

[0000080420-21-000041:mdna:46]
[same as prior period, unchanged from 0000080420-21-000029:mdna:42]

[0000080420-21-000041:mdna:47]
[same as prior period, unchanged from 0000080420-21-000029:mdna:43]

[0000080420-21-000041:mdna:48]
As of June 30, 2021, current assets exceeded current liabilities by 2.7 times, and our debt to total capitalization was 0.13%.

[0000080420-21-000041:mdna:49]
Cash, cash equivalents and short-term investments decreased to $128.8 million at June 30, 2021, compared to $178.9 million at September 30, 2020. This decrease in cash was primarily driven by the timing of contract billing milestones. We believe that our strong working capital position, available borrowings under our credit facility and available cash should be sufficient to finance future operating activities, capital improvements, research and development initiatives and debt repayments for the foreseeable future.

[0000080420-21-000041:mdna:50]
We have a credit agreement with Bank of America, N.A. (the "U.S. Revolver") which is a $75.0 million revolving credit facility available for both borrowings and letters of credit and expires September 27, 2024. On March 12, 2021, we entered into a first amendment to the U.S. Revolver which, among other things, amended certain terms related to the calculation of the consolidated leverage ratio from gross leverage to net leverage. As a result of the first amendment, up to $30 million may be deducted from the amount of letters of credit outstanding (not to be less than zero) when calculating the consolidated funded indebtedness which is a component of the consolidated net leverage ratio. Additionally, we have the option to cash collateralize all or a portion of the letters of credit outstanding, which would favorably impact the consolidated funded indebtedness calculation and the consolidated net leverage ratio.

[0000080420-21-000041:mdna:51]
As of June 30, 2021, there were no amounts borrowed under the U.S. Revolver, and letters of credit outstanding were $39.9 million. As of June 30, 2021, $35.1 million was available for the issuance of letters of credit and borrowing under the U.S. Revolver. Total long-term debt, including current maturities, totaled $0.4 million at June 30, 2021 related to outstanding industrial development revenue bonds. We are required to maintain certain financial covenants, the most significant of which are a consolidated net leverage ratio of less than 3.0 to 1.0 and a consolidated interest coverage ratio of greater than 3.0 to 1.0. Our most restrictive covenant, the consolidated net leverage ratio, is the ratio of earnings before interest, taxes, depreciation, amortization and stock-based compensation (EBITDAS) to funded indebtedness, which includes letters of credit. An increase in indebtedness or a decrease in EBITDAS could restrict our ability to issue letters of credit or borrow under the U.S. Revolver. For further information regarding our debt, see Notes E and F of Notes to Condensed Consolidated Financial Statements.

[0000080420-21-000041:mdna:52]
Approximately $27.9 million of our cash, cash equivalents and short-term investments at June 30, 2021 was held outside of the U.S. for our international operations. It is our intention to indefinitely reinvest all current and future foreign earnings internationally in order to ensure sufficient working capital to support our international operations. In the event that we elect to repatriate some or all of the foreign earnings that were previously deemed to be indefinitely reinvested outside the U.S., we may incur additional tax expense upon such repatriation under current tax laws.

[0000080420-21-000041:mdna:53]
[same as prior period, unchanged from 0000080420-21-000029:mdna:50]

[0000080420-21-000041:mdna:54]
Operating activities used $39.7 million during the nine months ended June 30, 2021 and provided $53.4 million during the same period in Fiscal 2020. Cash flow from operations is primarily influenced by the timing of milestone payments from our customers, project volume and the payment terms with our suppliers. This decrease in operating cash flow was primarily due to the timing of contract billing milestones.

[0000080420-21-000041:mdna:55]
[same as prior period, unchanged from 0000080420-21-000029:mdna:52]

[0000080420-21-000041:mdna:56]
Investing activities used $2.0 million during the nine months ended June 30, 2021 compared to $5.5 million used during the same period in Fiscal 2020. The decrease in cash used by investing activities in the first nine months of Fiscal 2021 was primarily due to a decrease in capital expenditures. Additionally, the proceeds received from a Company-owned life insurance policy related to a retired employee provided investing cash flow in Fiscal 2021.

[0000080420-21-000041:mdna:57]
[same as prior period, unchanged from 0000080420-21-000029:mdna:54]

[0000080420-21-000041:mdna:58]
Net cash used in financing activities was $10.1 million during each of the nine months ended June 30, 2021 and 2020, which primarily consisted of approximately $9.1 million of dividends paid in each period.

[0000080420-21-000041:mdna:59]
[same as prior period, unchanged from 0000080420-21-000029:mdna:56]

[0000080420-21-000041:mdna:60]
[same as prior period, unchanged from 0000080420-21-000029:mdna:57]

[0000080420-21-000041:mdna:61]
[same as prior period, unchanged from 0000080420-21-000029:mdna:58]

[0000080420-21-000041:mdna:62]
[same as prior period, unchanged from 0000080420-21-000029:mdna:59]

[0000080420-21-000041:mdna:63]
[same as prior period, unchanged from 0000080420-21-000029:mdna:60]
