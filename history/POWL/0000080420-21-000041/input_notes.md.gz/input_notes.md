# POWL notes — 0000080420-21-000041


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureAndSignificantAccountingPoliciesTextBlock

[0000080420-21-000041:notes:1]
[same as prior period, unchanged from 0000080420-21-000029:notes:1]

[0000080420-21-000041:notes:2]
[same as prior period, unchanged from 0000080420-21-000029:notes:2]

[0000080420-21-000041:notes:3]
[same as prior period, unchanged from 0000080420-21-000029:notes:3]

[0000080420-21-000041:notes:4]
[same as prior period, unchanged from 0000080420-21-000029:notes:4]

[0000080420-21-000041:notes:5]
Through the first nine months of Fiscal 2021, the COVID-19 pandemic continues to impact global energy markets. This pandemic has negatively impacted demand, which in turn has resulted in considerable volatility across global oil and gas commodity markets. As a result, some of our industrial customers are deferring or suspending their planned capital expenditures. Certain of our customers have asked that we delay or cancel our manufacturing on their projects as their operations have been negatively impacted by this pandemic and the reduced oil and gas demand which has resulted in recognition of cancellation fees based on contract terms and the extent of our progress on the projects. We continue to work with and review the contracts with our key suppliers who have been impacted by this pandemic to ensure that we are able to meet our customer commitments.

[0000080420-21-000041:notes:6]
[same as prior period, unchanged from 0000080420-21-000029:notes:6]

[0000080420-21-000041:notes:7]
[same as prior period, unchanged from 0000080420-21-000029:notes:7]

[0000080420-21-000041:notes:8]
[same as prior period, unchanged from 0000080420-21-000029:notes:8]

[0000080420-21-000041:notes:9]
[same as prior period, unchanged from 0000080420-21-000029:notes:9]

[0000080420-21-000041:notes:10]
[same as prior period, unchanged from 0000080420-21-000029:notes:10]

[0000080420-21-000041:notes:11]
[same as prior period, unchanged from 0000080420-21-000029:notes:11]

[0000080420-21-000041:notes:12]
[same as prior period, unchanged from 0000080420-21-000029:notes:12]

[0000080420-21-000041:notes:13]
[same as prior period, unchanged from 0000080420-21-000029:notes:13]

[0000080420-21-000041:notes:14]
[same as prior period, unchanged from 0000080420-21-000029:notes:14]

[0000080420-21-000041:notes:15]
[same as prior period, unchanged from 0000080420-21-000029:notes:15]


## us-gaap:EarningsPerShareTextBlock

[0000080420-21-000041:notes:16]
[same as prior period, unchanged from 0000080420-21-000029:notes:16]

[0000080420-21-000041:notes:17]
[same as prior period, unchanged from 0000080420-21-000029:notes:17]

[0000080420-21-000041:notes:18]
|  | Three months ended June 30, |  | Nine months ended June 30, |
|  | 2021 |  | 2020 |  | 2021 |  | 2020 |
| Numerator: |  |  |  |  |  |  |  |
| Net income (loss) | $ | (2,041) |  |  | $ | 3,481 |  |  | $ | (2,629) |  |  | $ | 13,677 |  |
| Denominator: |  |  |  |  |  |  |  |
| Weighted average basic shares | 11,720 |  |  | 11,631 |  |  | 11,700 |  |  | 11,622 |  |
| Dilutive effect of restricted stock units | — |  |  | 67 |  |  | — |  |  | 64 |  |
| Weighted average diluted shares | 11,720 |  |  | 11,698 |  |  | 11,700 |  |  | 11,686 |  |
| Earnings (loss) per share: |  |  |  |  |  |  |  |
| Basic | $ | (0.17) |  |  | $ | 0.30 |  |  | $ | (0.22) |  |  | $ | 1.18 |  |
| Diluted | $ | (0.17) |  |  | $ | 0.30 |  |  | $ | (0.22) |  |  | $ | 1.17 |  |

[0000080420-21-000041:notes:19]
For the three and nine months ended June 30, 2021, we incurred a net loss and therefore all potential common shares were deemed to be anti-dilutive.


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0000080420-21-000041:notes:20]
[same as prior period, unchanged from 0000080420-21-000029:notes:20]

[0000080420-21-000041:notes:21]
[same as prior period, unchanged from 0000080420-21-000029:notes:21]

[0000080420-21-000041:notes:22]
|  | Three months ended June 30, |  | Nine months ended June 30, |
|  | 2021 |  | 2020 |  | 2021 |  | 2020 |
| Balance at beginning of period | $ | 382 |  |  | $ | 300 |  |  | $ | 510 |  |  | $ | 301 |  |
| Bad debt expense, net | 326 |  |  | 136 |  |  | 194 |  |  | 187 |  |
| Uncollectible accounts written off, net of recoveries | (168) |  |  | (2) |  |  | (178) |  |  | (57) |  |
| Change due to foreign currency translation | 5 |  |  | — |  |  | 19 |  |  | 3 |  |
| Balance at end of period | $ | 545 |  |  | $ | 434 |  |  | $ | 545 |  |  | $ | 434 |  |

[0000080420-21-000041:notes:23]
[same as prior period, unchanged from 0000080420-21-000029:notes:23]

[0000080420-21-000041:notes:24]
[same as prior period, unchanged from 0000080420-21-000029:notes:24]

[0000080420-21-000041:notes:25]
|  | June 30, 2021 |  | September 30, 2020 |
| Raw materials, parts and sub-assemblies, net | $ | 27,325 |  |  | $ | 27,429 |  |
| Work-in-progress | 1,072 |  |  | 1,539 |  |
| Total inventories | $ | 28,397 |  |  | $ | 28,968 |  |

[0000080420-21-000041:notes:26]
[same as prior period, unchanged from 0000080420-21-000029:notes:26]

[0000080420-21-000041:notes:27]
[same as prior period, unchanged from 0000080420-21-000029:notes:27]

[0000080420-21-000041:notes:28]
|  | Three months ended June 30, |  | Nine months ended June 30, |
|  | 2021 |  | 2020 |  | 2021 |  | 2020 |
| Balance at beginning of period | $ | 2,467 |  |  | $ | 3,276 |  |  | $ | 2,771 |  |  | $ | 2,946 |  |
| Increase to warranty expense | 515 |  |  | 276 |  |  | 1,568 |  |  | 1,904 |  |
| Deduction for warranty charges | (557) |  |  | (555) |  |  | (1,970) |  |  | (1,826) |  |
| Change due to foreign currency translation | 7 |  |  | 14 |  |  | 63 |  |  | (13) |  |
| Balance at end of period | $ | 2,432 |  |  | $ | 3,011 |  |  | $ | 2,432 |  |  | $ | 3,011 |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0000080420-21-000041:notes:29]
[same as prior period, unchanged from 0000080420-21-000029:notes:29]

[0000080420-21-000041:notes:30]
[same as prior period, unchanged from 0000080420-21-000029:notes:30]

[0000080420-21-000041:notes:31]
[same as prior period, unchanged from 0000080420-21-000029:notes:31]

[0000080420-21-000041:notes:32]
[same as prior period, unchanged from 0000080420-21-000029:notes:32]

[0000080420-21-000041:notes:33]
in each reporting period corresponding to the amount with which we have the right to invoice.  Our performance obligations are satisfied as the work progresses. Revenues from our custom-engineered products and value-added services transferred to customers over time accounted for approximately 93% of total revenues for the three months ended June 30, 2021,  92% of total revenues for the nine months ended June 30, 2021 and 95% of total revenues for each of the three and nine months ended June 30, 2020.

[0000080420-21-000041:notes:34]
We also have sales orders for spare parts and replacement circuit breakers for switchgear that are obsolete or that are no longer produced by the original manufacturer. Revenues from these sales orders are recognized at the time we fulfill our performance obligation to the customer, which is typically upon shipment and represented approximately 7% of total revenues for the three months ended June 30, 2021, 8% of total revenues for the nine months ended June 30, 2021 and 5% of total revenues for each of the three and nine months ended June 30, 2020.

[0000080420-21-000041:notes:35]
[same as prior period, unchanged from 0000080420-21-000029:notes:35]

[0000080420-21-000041:notes:36]
[same as prior period, unchanged from 0000080420-21-000029:notes:36]

[0000080420-21-000041:notes:37]
[same as prior period, unchanged from 0000080420-21-000029:notes:37]

[0000080420-21-000041:notes:38]
[same as prior period, unchanged from 0000080420-21-000029:notes:38]

[0000080420-21-000041:notes:39]
Remaining unsatisfied performance obligations, which we refer to as backlog, represent the estimated transaction price for goods and services for which we have a material right, but work has not been performed. As of June 30, 2021, we had backlog of $425.5 million, of which approximately $292.8 million is expected to be recognized as revenue within the next twelve months. Backlog may not be indicative of future operating results as orders may be cancelled or modified by our customers. Our backlog does not include service and maintenance-type contracts for which we have the right to invoice as services are performed.

[0000080420-21-000041:notes:40]
[same as prior period, unchanged from 0000080420-21-000029:notes:40]

[0000080420-21-000041:notes:41]
[same as prior period, unchanged from 0000080420-21-000029:notes:41]

[0000080420-21-000041:notes:42]
For the nine months ended June 30, 2021 and 2020, our operating results were positively impacted by $11.4 million and $10.8 million, respectively, as a result of changes in contract estimates related to projects in progress at the beginning of the respective period. These changes in estimates resulted primarily from favorable project execution and negotiations of variable consideration, discussed below, as well as revenue and reduced costs recognized from project cancellations and other changes in facts and circumstances during these periods.

[0000080420-21-000041:notes:43]
[same as prior period, unchanged from 0000080420-21-000029:notes:43]

[0000080420-21-000041:notes:44]
It is common for our long-term contracts to contain variable consideration that can either increase or decrease the transaction price. Due to the nature of our contracts, estimating total cost and revenue can be complex and subject to variability due to change orders, back charges, spare parts, early completion bonuses, customer allowances and liquidated damages. We estimate the amount of variable consideration based on the expected value method, which is the sum of the probability-weighted amounts, or the most likely amount method which uses various factors including experience with similar transactions and assessment of our anticipated performance. Variable consideration is included in the transaction price if legally enforceable and to the extent it is probable that a significant reversal of cumulative revenue recognized will not occur once the uncertainty associated with the variable consideration is resolved.

[0000080420-21-000041:notes:45]
[same as prior period, unchanged from 0000080420-21-000029:notes:45]

[0000080420-21-000041:notes:46]
[same as prior period, unchanged from 0000080420-21-000029:notes:46]

[0000080420-21-000041:notes:47]
[same as prior period, unchanged from 0000080420-21-000029:notes:47]

[0000080420-21-000041:notes:48]
[same as prior period, unchanged from 0000080420-21-000029:notes:48]

[0000080420-21-000041:notes:49]
[same as prior period, unchanged from 0000080420-21-000029:notes:49]

[0000080420-21-000041:notes:50]
[same as prior period, unchanged from 0000080420-21-000029:notes:50]

[0000080420-21-000041:notes:51]
Our contract assets and liabilities are reported in a net position on a contract-by-contract basis at the end of each reporting period and are generally classified as current. The timing of contract billing milestones related to our Fiscal 2020 contract award for a large industrial project contributed significantly to our net contract liability at September 30, 2020.

[0000080420-21-000041:notes:52]
Contract assets and liabilities as of June 30, 2021 and September 30, 2020 are summarized below (in thousands):

[0000080420-21-000041:notes:53]
|  | June 30, 2021 |  | September 30, 2020 |
| Contract assets | $ | 50,827 |  |  | $ | 50,995 |  |
| Contract liabilities | (43,140) |  |  | (79,445) |  |
| Net contract asset (liability) | $ | 7,687 |  |  | $ | (28,450) |  |

[0000080420-21-000041:notes:54]
The increase in net contract asset at June 30, 2021 from September 30, 2020 was primarily due to the timing of contract billing milestones and new orders. To determine the amount of revenue recognized during the period from contract liabilities, we first allocate revenue to the individual contract liability balance outstanding at the beginning of the period until the revenue exceeds that balance. During the nine months ended June 30, 2021, we recognized revenue of approximately $63.5 million that was related to contract liabilities outstanding at September 30, 2020.

[0000080420-21-000041:notes:55]
The timing of our invoice process is typically dependent on the completion of certain milestones and contract terms and subject to agreement by our customer.  Payment is typically expected within 30 days of invoice. Any uncollected invoiced amounts for our performance obligations recognized over time, including contract retentions, are recorded as accounts receivable in the Condensed Consolidated Balance Sheets. Certain contracts contain retention provisions that become due upon completion of contractual requirements. As of June 30, 2021 and September 30, 2020, accounts receivable included retention amounts of $9.3 million and $6.9 million, respectively. Of the retained amount at June 30, 2021, $7.3 million is expected to be collected in the next twelve months and is recorded in accounts receivable. The remaining $2.0 million is recorded in other assets.

[0000080420-21-000041:notes:56]
[same as prior period, unchanged from 0000080420-21-000029:notes:56]

[0000080420-21-000041:notes:57]
The following tables present our disaggregated revenue by geographic destination and market sector for the three and nine months ended June 30, 2021 and 2020 (in thousands):

[0000080420-21-000041:notes:58]
|  | Three months ended June 30, |  | Nine months ended June 30, |
|  | 2021 |  | 2020 |  | 2021 |  | 2020 |
| United States | $ | 88,412 |  |  | $ | 89,499 |  |  | $ | 256,937 |  |  | $ | 318,009 |  |
| Canada | 16,529 |  |  | 16,970 |  |  | 48,354 |  |  | 46,831 |  |
| Europe, Middle East and Africa | 8,926 |  |  | 6,422 |  |  | 28,120 |  |  | 25,404 |  |
| Asia/Pacific | 1,651 |  |  | 4,643 |  |  | 6,376 |  |  | 11,784 |  |
| Mexico, Central and South America | 295 |  |  | 528 |  |  | 1,318 |  |  | 1,753 |  |
| Total revenues by geographic destination | $ | 115,813 |  |  | $ | 118,062 |  |  | $ | 341,105 |  |  | $ | 403,781 |  |

[0000080420-21-000041:notes:59]
|  | Three months ended June 30, |  | Nine months ended June 30, |
|  | 2021 |  | 2020 |  | 2021 |  | 2020 |
| Oil and gas | $ | 49,272 |  |  | $ | 45,851 |  |  | $ | 139,443 |  |  | $ | 157,798 |  |
| Petrochemical | 15,365 |  |  | 29,293 |  |  | 34,725 |  |  | 107,057 |  |
| Electric utility | 26,175 |  |  | 16,725 |  |  | 82,797 |  |  | 63,994 |  |
| Traction power | 13,821 |  |  | 9,122 |  |  | 42,322 |  |  | 31,417 |  |
| All others | 11,180 |  |  | 17,071 |  |  | 41,818 |  |  | 43,515 |  |
| Total revenues by market sector | $ | 115,813 |  |  | $ | 118,062 |  |  | $ | 341,105 |  |  | $ | 403,781 |  |


## us-gaap:RevenueFromContractWithCustomerPolicyTextBlock

[0000080420-21-000041:notes:60]
[same as prior period, unchanged from 0000080420-21-000029:notes:60]

[0000080420-21-000041:notes:61]
[same as prior period, unchanged from 0000080420-21-000029:notes:61]

[0000080420-21-000041:notes:62]
[same as prior period, unchanged from 0000080420-21-000029:notes:62]

[0000080420-21-000041:notes:63]
[same as prior period, unchanged from 0000080420-21-000029:notes:63]


## us-gaap:LongTermDebtTextBlock

[0000080420-21-000041:notes:64]
Long-Term Debt
Long-term debt consisted of the following (in thousands):

[0000080420-21-000041:notes:65]
|  | June 30, 2021 |  | September 30, 2020 |
| Industrial development revenue bonds | $ | 400 |  |  | $ | 800 |  |
| Less: current portion | (400) |  |  | (400) |  |
| Total long-term debt | $ | — |  |  | $ | 400 |  |

[0000080420-21-000041:notes:66]
U.S. Revolver

[0000080420-21-000041:notes:67]
We have a credit agreement with Bank of America, N.A. (the "U.S. Revolver") which is a $75.0 million revolving credit facility that is available for both borrowings and letters of credit and expires September 27, 2024. On March 12, 2021, we entered into a first amendment to the U.S. Revolver which, among other things, amended certain terms related to the calculation of the consolidated leverage ratio from gross leverage to net leverage. As a result of the first amendment, up to $30 million may be deducted from the amount of letters of credit outstanding (not to be less than zero) when calculating the consolidated funded indebtedness which is a component of the consolidated net leverage ratio. Additionally, we have the option to cash collateralize all or a portion of the letters of credit outstanding, which would favorably impact the consolidated funded indebtedness calculation and the consolidated net leverage ratio. As of June 30, 2021, there were no amounts borrowed under the U.S. Revolver and letters of credit outstanding were $39.9 million. There was $35.1 million available for the issuance of letters of credit and borrowings under the U.S. Revolver as of June 30, 2021.

[0000080420-21-000041:notes:68]
We are required to maintain certain financial covenants, the most significant of which are a consolidated net leverage ratio less than 3.0 to 1.0 and a consolidated interest coverage ratio of greater than 3.0 to 1.0. Our most restrictive covenant, the consolidated net leverage ratio, is the ratio of earnings before interest, taxes, depreciation, amortization and stock-based compensation (EBITDAS) to funded indebtedness. An increase in indebtedness, which includes letters of credit, or a decrease in EBITDAS could restrict our ability to issue letters of credit or borrow under the U.S. Revolver. Additionally, we must maintain a consolidated cash balance of $30 million at all times, which now can be deducted from the letters of credit outstanding as noted above. The U.S. Revolver also contains a "material adverse effect" clause which is a material change in our operations, business, properties, liabilities or condition (financial or otherwise) or a material impairment of our ability to

[0000080420-21-000041:notes:69]
perform our obligations under our credit agreements. As of June 30, 2021, we were in compliance with all of the financial covenants of the U.S. Revolver.

[0000080420-21-000041:notes:70]
The U.S. Revolver allows the Company to elect that any borrowing under the facility bears an interest rate based on either the base rate or the eurocurrency rate, in each case, plus the applicable rate. The base rate is generally the highest of (a) the federal funds rate plus 0.50%, (b) the Bank of America prime rate or (c) the London Interbank Offered Rate (LIBOR) plus 1.00%. The applicable rate is generally a range from (0.25)% to 1.75% depending on the type of loan and the Company's consolidated leverage ratio.

[0000080420-21-000041:notes:71]
The U.S. Revolver is collateralized by a pledge of 100% of the voting capital stock of each of our domestic subsidiaries and 65% of the voting capital stock of each non-domestic subsidiary. The U.S. Revolver provides for customary events of default and carries cross-default provisions with other existing debt agreements. If an event of default (as defined in the U.S. Revolver) occurs and is continuing, on the terms and subject to the conditions set forth in the U.S. Revolver, amounts and letters of credit outstanding under the U.S. Revolver may be accelerated and may become immediately due and payable.

[0000080420-21-000041:notes:72]
Industrial Development Revenue Bonds

[0000080420-21-000041:notes:73]
We borrowed $8.0 million in October 2001 through a loan agreement funded with proceeds from tax-exempt industrial development revenue bonds (Bonds) for the completion of our Northlake, Illinois facility. The Bonds are subject to various covenants, for which we were in compliance at June 30, 2021. The Bonds mature in October 2021 and bear interest at a floating rate determined weekly by the Bonds’ remarketing agent. This interest rate was 0.13% as of June 30, 2021.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0000080420-21-000041:notes:74]
Commitments and Contingencies
Letters of Credit, Bank Guarantees and Bonds

[0000080420-21-000041:notes:75]
Certain customers require us to post letters of credit, bank guarantees or surety bonds. These security instruments assure that we will perform under the terms of our contract. In the event of default, the counterparty may demand payment from the bank under a letter of credit or bank guarantee, or performance by the surety under a bond. To date, there have been no significant draws or claims related to security instruments for the periods reported. We were contingently liable for letters of credit of $39.9 million as of June 30, 2021. We also had surety bonds totaling $141.2 million that were outstanding, with additional bonding capacity of $458.8 million available, at June 30, 2021. At present, we have strong surety relationships; however, a change in market conditions or the sureties' assessment of our financial position could cause the sureties to require cash collateralization for undischarged liabilities under the bonds.

[0000080420-21-000041:notes:76]
We have a $9.7 million facility agreement (Facility Agreement) between Powell (UK) Limited and a large international bank that provides Powell (UK) Limited the ability to enter into bank guarantees as well as forward exchange contracts and currency options. At June 30, 2021, we had outstanding guarantees totaling $7.7 million and amounts available under this Facility Agreement were $2.0 million. The Facility Agreement provides for financial covenants and customary events of default, and carries cross-default provisions with our U.S. Revolver. If an event of default (as defined in the Facility Agreement) occurs and is continuing, per the terms and subject to the conditions set forth therein, obligations outstanding under the Facility Agreement may be accelerated and declared immediately due and payable. Additionally, we are required to maintain cash collateral for guarantees greater than two years. As of June 30, 2021, we were in compliance with all of the financial covenants of the Facility Agreement.

[0000080420-21-000041:notes:77]
Litigation

[0000080420-21-000041:notes:78]
We are involved in various legal proceedings, claims and other disputes arising from our commercial operations, projects, employees and other matters which, in general, are subject to uncertainties and in which the outcomes are not predictable. Although we can give no assurances about the resolution of pending claims, litigation or other disputes and the effect such outcomes may have on us, management believes that any ultimate liability resulting from the outcome of such proceedings, to the extent not otherwise provided or covered by insurance, will not have a material adverse effect on our consolidated financial position or results of operations or liquidity.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0000080420-21-000041:notes:79]
[same as prior period, unchanged from 0000080420-21-000029:notes:78]

[0000080420-21-000041:notes:80]
[same as prior period, unchanged from 0000080420-21-000029:notes:79]

[0000080420-21-000041:notes:81]
We issue restricted stock units (RSUs) to certain officers and key employees of the Company. The fair value of the RSUs is based on the price of our common stock as reported on the NASDAQ Global Market on the grant dates. Typically, these grants vest over a three-year period from the date of issuance and are a blend of time-based and performance-based shares. The portion of the grant that is time-based typically vests over a three-year period on each anniversary of the grant date, based on continued employment. The performance-based shares vest based on the three-year earnings performance of the Company following the grant date. At June 30, 2021, there were 200,919 RSUs outstanding. The RSUs do not have voting rights but do receive dividend equivalents upon vesting. Additionally, the shares of common stock underlying the RSUs are not considered issued and outstanding until vested and common stock is issued.

[0000080420-21-000041:notes:82]
Total RSU activity (number of shares) for the nine months ended June 30, 2021 is summarized below:

[0000080420-21-000041:notes:83]
|  | Number ofRestrictedStockUnits |  | WeightedAverageGrant ValuePer Share |
| Outstanding at September 30, 2020 | 154,034 |  |  | $ | 35.37 |  |
| Granted | 104,550 |  |  | 24.08 |  |
| Vested | (55,748) |  |  | 32.50 |  |
| Forfeited/canceled | (1,917) |  |  | 32.58 |  |
| Outstanding at June 30, 2021 | 200,919 |  |  | $ | 30.32 |  |

[0000080420-21-000041:notes:84]
During the nine months ended June 30, 2021 and 2020, we recorded compensation expense of $1.7 million and $1.9 million, respectively, related to the RSUs.

[0000080420-21-000041:notes:85]
Restricted Stock
Each non-employee director receives 2,400 restricted shares of the Company’s common stock annually. Fifty-percent of the restricted stock granted to each of our non-employee directors vests immediately, while the remaining fifty-percent vests on the anniversary of the grant date. Compensation expense is recognized immediately for the first fifty-percent of the restricted stock granted, while compensation expense for the remaining fifty-percent is recognized over the remaining vesting period. In February 2021, 16,800 shares of restricted stock were issued to our non-employee directors under the 2014 Non-Employee Director Equity Incentive Plan at a price of $31.33 per share. During both the nine months ended June 30, 2021 and 2020, we recorded compensation expense of $0.5 million related to restricted stock.


## us-gaap:FairValueDisclosuresTextBlock

[0000080420-21-000041:notes:86]
[same as prior period, unchanged from 0000080420-21-000029:notes:85]

[0000080420-21-000041:notes:87]
[same as prior period, unchanged from 0000080420-21-000029:notes:86]

[0000080420-21-000041:notes:88]
[same as prior period, unchanged from 0000080420-21-000029:notes:87]

[0000080420-21-000041:notes:89]
[same as prior period, unchanged from 0000080420-21-000029:notes:88]

[0000080420-21-000041:notes:90]
[same as prior period, unchanged from 0000080420-21-000029:notes:89]

[0000080420-21-000041:notes:91]
The following table summarizes the fair value of our assets and liabilities that were accounted for at fair value on a recurring basis as of June 30, 2021 (in thousands):

[0000080420-21-000041:notes:92]
|  | Fair Value Measurements at June 30, 2021 |
|  | Quoted Prices inActive Markets forIdentical Assets(Level 1) |  | Significant OtherObservableInputs(Level 2) |  | SignificantUnobservableInputs(Level 3) |  | Fair Value at June 30,2021 |
| Assets: |  |  |  |  |  |  |  |
| Cash and cash equivalents | $ | 108,675 |  |  | $ | — |  |  | $ | — |  |  | $ | 108,675 |  |
| Short-term investments | 20,165 |  |  | — |  |  | — |  |  | 20,165 |  |
| Other assets | — |  |  | 9,191 |  |  | — |  |  | 9,191 |  |
| Liabilities: |  |  |  |  |  |  |  |
| Deferred compensation | — |  |  | 8,693 |  |  | — |  |  | 8,693 |  |

[0000080420-21-000041:notes:93]
[same as prior period, unchanged from 0000080420-21-000029:notes:92]

[0000080420-21-000041:notes:94]
[same as prior period, unchanged from 0000080420-21-000029:notes:93]

[0000080420-21-000041:notes:95]
[same as prior period, unchanged from 0000080420-21-000029:notes:94]

[0000080420-21-000041:notes:96]
[same as prior period, unchanged from 0000080420-21-000029:notes:95]

[0000080420-21-000041:notes:97]
[same as prior period, unchanged from 0000080420-21-000029:notes:96]

[0000080420-21-000041:notes:98]
[same as prior period, unchanged from 0000080420-21-000029:notes:97]

[0000080420-21-000041:notes:99]
There were no transfers between levels within the fair value measurement hierarchy during the quarter ended June 30, 2021.


## us-gaap:LesseeOperatingLeasesTextBlock

[0000080420-21-000041:notes:100]
Leases
Our leases consist primarily of office and manufacturing space, construction equipment and office equipment. All of our future lease obligations are related to non-cancelable operating leases. The most significant portion of our lease portfolio relates to leases of office and manufacturing facilities in Canada which we no longer occupy. We currently sublease the majority of these Canadian facilities. The following table provides a summary of lease cost components for the three and nine months ended June 30, 2021 and 2020, respectively (in thousands):

[0000080420-21-000041:notes:101]
|  |  | Three months ended June 30, |  | Nine months ended June 30, |
| Lease Cost |  | 2021 |  | 2020 |  | 2021 |  | 2020 |
| Operating lease cost |  | $ | 598 |  |  | $ | 571 |  |  | $ | 1,835 |  |  | $ | 1,779 |  |
| Less: sublease income |  | (175) |  |  | (156) |  |  | (532) |  |  | (393) |  |
| Variable lease cost(1) |  | 117 |  |  | 86 |  |  | 334 |  |  | 265 |  |
| Short-term lease cost(2) |  | 365 |  |  | 148 |  |  | 853 |  |  | 496 |  |
| Total lease cost |  | $ | 905 |  |  | $ | 649 |  |  | $ | 2,490 |  |  | $ | 2,147 |  |

[0000080420-21-000041:notes:102]
[same as prior period, unchanged from 0000080420-21-000029:notes:101]

[0000080420-21-000041:notes:103]
[same as prior period, unchanged from 0000080420-21-000029:notes:102]

[0000080420-21-000041:notes:104]
We recognize operating lease assets and operating lease liabilities representing the present value of the remaining lease payments for leases with initial terms greater than twelve months. Leases with initial terms of twelve months or less are not recorded in our Condensed Consolidated Balance Sheets. Our operating lease assets have been reduced by a lease accrual of $0.5 million related to certain unused facility leases in Canada. The following table provides a summary of the operating lease assets and operating lease liabilities included in our Condensed Consolidated Balance Sheets as of June 30, 2021 and September 30, 2020, respectively (in thousands):

[0000080420-21-000041:notes:105]
| Operating Leases |  | June 30, 2021 |  | September 30, 2020 |
| Assets: |  |  |  |  |
| Operating lease assets, net |  | $ | 3,732 |  |  | $ | 5,217 |  |
| Liabilities: |  |  |  |  |
| Current operating lease liabilities |  | 1,640 |  |  | 2,352 |  |
| Long-term operating lease liabilities |  | 2,554 |  |  | 3,434 |  |
| Total lease liabilities |  | $ | 4,194 |  |  | $ | 5,786 |  |

[0000080420-21-000041:notes:106]
The following table provides the maturities of our operating lease liabilities as of June 30, 2021 (in thousands):

[0000080420-21-000041:notes:107]
|  |  | Operating Leases |  |  |
| Remainder of 2021 |  | $ | 469 |  |  |  |
| 2022 |  | 2,411 |  |  |  |
| 2023 |  | 1,380 |  |  |  |
| 2024 |  | 101 |  |  |  |
| 2025 |  | — |  |  |  |
| Thereafter |  | — |  |  |  |
| Total future minimum lease payments |  | 4,361 |  |  |  |
| Less: present value discount (imputed interest) |  | (167) |  |  |  |
| Present value of lease liabilities |  | $ | 4,194 |  |  |  |

[0000080420-21-000041:notes:108]
The weighted average discount rate as of June 30, 2021 was 4.1%. The weighted average remaining lease term was 1.9 years at June 30, 2021.


## us-gaap:IncomeTaxDisclosureTextBlock

[0000080420-21-000041:notes:109]
[same as prior period, unchanged from 0000080420-21-000029:notes:108]

[0000080420-21-000041:notes:110]
|  | Three months ended June 30, |  | Nine months ended June 30, |
|  | 2021 |  | 2020 |  | 2021 |  | 2020 |
| Income (loss) before income taxes | $ | (1,338) |  |  | $ | 2,922 |  |  | $ | (2,767) |  |  | $ | 15,810 |  |
| Income tax provision (benefit) | 703 |  |  | (559) |  |  | (138) |  |  | 2,133 |  |
| Net income (loss) | $ | (2,041) |  |  | $ | 3,481 |  |  | $ | (2,629) |  |  | $ | 13,677 |  |
| Effective tax rate | (53) | % |  | (19) | % |  | 5 | % |  | 13 | % |

[0000080420-21-000041:notes:111]
For the three months ended June 30, 2021, the income tax provision resulted in a negative effective tax rate for the period due to our inability to recognize a tax benefit related to losses in the United Kingdom and the change in the estimated relative amounts of income/loss recognized in the various tax jurisdictions. These items also reduced the tax benefit for the nine months ended June 30, 2021. The estimated Research and Development Tax Credit (R&D Tax Credit) as well as the utilization of net operating loss carryforwards in Canada that were fully reserved with a valuation allowance provided a tax benefit for the three and nine months ended June 30, 2021.

[0000080420-21-000041:notes:112]
The effective tax rate for the quarter ended June 30, 2020 was favorably impacted by the tax benefits related to the R&D Tax Credit as well as the projected utilization of net operating loss carryforwards in Canada that were fully reserved with a valuation allowance. In addition, as a result of the expiration of certain U.S. federal statutes of limitations and the effective settlement of an Internal Revenue Service (IRS) audit, $1.7 million of reserves for unrecognized tax benefits related to these matters was released. These benefits were partially offset by losses recognized by various foreign jurisdictions that were reserved with a valuation allowance. For the nine months ended June 30, 2020, the effective tax rate was also negatively impacted by the $0.5 million valuation allowance recorded against our UK deferred tax assets as a discrete item during the second quarter of Fiscal 2020.


## us-gaap:SubsequentEventsTextBlock

[0000080420-21-000041:notes:113]
Subsequent Events
Quarterly Dividend Declared

[0000080420-21-000041:notes:114]
On August 3, 2021, our Board of Directors declared a quarterly cash dividend on our common stock in the amount of $0.26 per share. The dividend is payable on September 15, 2021 to shareholders of record at the close of business on August 18, 2021.
