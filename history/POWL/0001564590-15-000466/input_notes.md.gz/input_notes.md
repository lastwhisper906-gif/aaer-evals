# POWL notes — 0001564590-15-000466


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureAndSignificantAccountingPoliciesTextBlock

[0001564590-15-000466:notes:1]
[same as prior period, unchanged from 0001564590-14-003175:notes:1]

[0001564590-15-000466:notes:2]
[same as prior period, unchanged from 0001564590-14-003175:notes:2]

[0001564590-15-000466:notes:3]
Powell Industries, Inc. (we, us, our, Powell or the Company) was incorporated in the state of Delaware in 2004 as a successor to a Nevada company incorporated in 1968. The Nevada corporation was the successor to a company founded by William E. Powell in 1947, which merged into the Company in 1977. Our major subsidiaries, all of which are wholly owned, include: Powell Electrical Systems, Inc.; Powell (UK) Limited; Powell Canada Inc. and Powell Industries International, B.V.

[0001564590-15-000466:notes:4]
We develop, design, manufacture and service custom-engineered equipment and systems for the distribution, control and monitoring of electrical energy designed to (1) distribute, monitor and control the flow of electrical energy and (2)  provide protection to motors, transformers and other electrically powered equipment. Headquartered in Houston, Texas, we serve the transportation, energy, industrial and utility industries.

[0001564590-15-000466:notes:5]
[same as prior period, unchanged from 0001564590-14-003175:notes:5]

[0001564590-15-000466:notes:6]
[same as prior period, unchanged from 0001564590-14-003175:notes:6]

[0001564590-15-000466:notes:7]
[same as prior period, unchanged from 0001564590-14-003175:notes:7]

[0001564590-15-000466:notes:8]
These unaudited condensed consolidated financial statements should be read in conjunction with the audited consolidated financial statements and notes thereto of Powell and its subsidiaries included in Powell’s Annual Report on Form 10-K for the year ended September 30, 2014, which was filed with the Securities and Exchange Commission (SEC) on December 3, 2014.

[0001564590-15-000466:notes:9]
References to Fiscal 2015, Fiscal 2014 and Fiscal 2013 used throughout this report shall mean our fiscal years ended September 30, 2015, 2014 and 2013, respectively.

[0001564590-15-000466:notes:10]
[same as prior period, unchanged from 0001564590-14-003175:notes:10]

[0001564590-15-000466:notes:11]
The preparation of financial statements in conformity with U.S. GAAP requires management to make estimates and assumptions that affect the amounts reported in the consolidated financial statements and accompanying footnotes. The most significant estimates used in our financial statements affect revenue and cost recognition for construction contracts, the allowance for doubtful accounts, provision for excess and obsolete inventory, goodwill and other intangible assets, self-insurance, warranty accruals and income taxes. The amounts recorded for insurance claims, warranties, legal, income taxes and other contingent liabilities require judgments regarding the amount of expenses that will ultimately be incurred. We base our estimates on historical experience and on various other assumptions, as well as the specific circumstances surrounding these contingent liabilities, in evaluating the amount of liability that should be recorded. Additionally, the recognition of deferred tax assets requires estimates related to future income and other assumptions regarding timing and future profitability.  Estimates may change as new events occur, additional information becomes available or operating environments change. Actual results may differ from our estimates.

[0001564590-15-000466:notes:12]
Supplemental Disclosures of Cash Flow Information (in thousands):

[0001564590-15-000466:notes:13]
|  | Three months ended December 31, |
|  | 2014 |  |  |  |  | 2013 |  |
| Non-cash capital expenditures | $ | 8,727 |  |  |  |  | $ | — |  |

[0001564590-15-000466:notes:14]
[same as prior period, unchanged from 0001564590-14-003175:notes:12]

[0001564590-15-000466:notes:15]
In July 2013, the FASB issued accounting guidance on the presentation of an unrecognized tax benefit when a net operating loss carryforward, a similar tax loss, or a tax credit carryforward exists. The guidance states that an unrecognized tax benefit, or a portion of an unrecognized tax benefit, should be presented in the financial statements as a reduction to a deferred tax asset for a net operating loss carryforward, a similar tax loss, or a tax credit carryforward. To the extent a net operating loss carryforward, a similar tax loss, or a tax credit carryforward is not available at the reporting date under the tax law of the applicable jurisdiction to settle any additional income taxes that would result from the disallowance of a tax position or the tax law of the applicable jurisdiction does not require the entity to use, and the entity does not intend to use, the deferred tax asset for such purpose, the unrecognized tax benefit should be presented in the financial statements as a liability and should not be combined with deferred tax assets. This guidance is effective for fiscal years, and interim periods within those years, beginning after December 15, 2013, which would be our fiscal year ended September 30, 2015. This guidance should be applied prospectively to all unrecognized tax benefits that exist at the effective date. Retrospective application is permitted. The adoption of this guidance has not had a significant impact on our consolidated financial position or results of operations.

[0001564590-15-000466:notes:16]
In April 2014, the FASB issued an amendment to the financial reporting of discontinued operations.  The amendments in this update changed the criteria for reporting discontinued operations while enhancing disclosures in this area. It also addresses sources of confusion and inconsistent application related to the financial reporting of discontinued operations guidance in U.S. GAAP.  Under the new guidance, only disposals representing a strategic shift in operations that have a major effect on the organization’s operations and financial results should be presented as discontinued operations. Examples include a disposal of a major geographic area, a major line of business, or a major equity method investment.  In addition, the new guidance requires expanded disclosures about discontinued operations that will provide financial statement users with more information about the assets, liabilities, income, and expenses of discontinued operations.  The new guidance also requires disclosure of the pre-tax income attributable to a disposal of a significant part of an organization that does not qualify for discontinued operations reporting. This disclosure will provide users with information about the ongoing trends in a reporting organization’s results from continuing operations. The amendments in this update are effective in the first quarter of 2015, which would be our fiscal year end September 30, 2016.  Early adoption is permitted for disposals that have not been previously reported as discontinued operations.

[0001564590-15-000466:notes:17]
[same as prior period, unchanged from 0001564590-14-003175:notes:16]

[0001564590-15-000466:notes:18]
In June 2014, the FASB issued an amendment to the topic regarding share-based payments and instances where terms of an award provide that a performance target can be achieved after the requisite service period.  This guidance has been provided to resolve the diversity in practice concerning employee share-based payments that contain performance targets that could be achieved after the requisite service period. The updated guidance requires that a performance target that affects vesting and that can be achieved after the requisite service period be treated as a performance condition. Compensation cost should be recognized in the period in which it becomes probable that the performance target will be achieved and is attributable to the periods for which service has been rendered. If the performance target becomes probable of being achieved before the end of the service period, the remaining unrecognized compensation cost for which requisite service has not yet been rendered is recognized prospectively over the remaining service period. The total amount of compensation cost recognized during and after the service period should reflect the number of awards that are expected to vest and should be adjusted to reflect those awards that ultimately vest. The updated guidance is effective for annual and interim periods beginning after December 15, 2015, with early adoption permitted. The adoption of this guidance is not expected to have a material impact on our consolidated financial position or results of operations.

[0001564590-15-000466:notes:19]
Discontinued operations

[0001564590-15-000466:notes:20]
In January 2014, we sold our wholly owned subsidiary Transdyn Inc. (Transdyn).  For the quarter ended December 31, 2013, we have presented the results of these operations as income from discontinued operations, net of tax.  See Note I.


## us-gaap:EarningsPerShareTextBlock

[0001564590-15-000466:notes:21]
[same as prior period, unchanged from 0001564590-14-003175:notes:17]

[0001564590-15-000466:notes:22]
We compute basic earnings per share by dividing net income by the weighted average number of common shares outstanding during the period. Diluted earnings per common and potential common share includes the weighted average of additional shares associated with the incremental effect of dilutive restricted stock and restrictive stock units, as prescribed by the FASB guidance on earnings per share.

[0001564590-15-000466:notes:23]
The following table reconciles basic and diluted weighted average shares used in the computation of earnings per share (in thousands, except per share data):

[0001564590-15-000466:notes:24]
|  | Three months ended December 31, |  |
|  | 2014 |  |  | 2013 |  |
| Numerator: |  |  |  |  |  |  |  |
| Income (loss) from continuing operations | $ | (239 | ) |  | $ | 7,268 |  |
| Income from discontinued operations |  | — |  |  |  | 987 |  |
| Net income (loss) | $ | (239 | ) |  | $ | 8,255 |  |
| Denominator: |  |  |  |  |  |  |  |
| Weighted average basic shares |  | 12,041 |  |  |  | 11,994 |  |
| Dilutive effect of restricted stock units |  | — |  |  |  | 60 |  |
| Weighted average diluted shares with assumed conversions |  | 12,041 |  |  |  | 12,054 |  |
| Net earnings (loss) per share: |  |  |  |  |  |  |  |
| Continuing operations | $ | (0.02 | ) |  | $ | 0.61 |  |
| Discontinued operations |  | — |  |  |  | 0.08 |  |
| Basic earnings (loss) per share | $ | (0.02 | ) |  | $ | 0.69 |  |
| Continuing operations | $ | (0.02 | ) |  | $ | 0.60 |  |
| Discontinued operations |  | — |  |  |  | 0.08 |  |
| Diluted earnings (loss) per share | $ | (0.02 | ) |  | $ | 0.68 |  |

[0001564590-15-000466:notes:25]
For the quarter ended December 31, 2014, we incurred a net loss and therefore all potential common shares were deemed to be anti-dilutive.  On December 17, 2014, our Board of Directors authorized a repurchase program (the Repurchase Program) under which we may repurchase up to $25 million of our outstanding stock.  The purchases may be made from time to time in the open market, through privately negotiated transactions and Rule 10b5-1 trading plans in accordance with applicable laws, rules and regulations.  The Repurchase Program will be funded from cash on hand and cash provided by operating activities.  The Repurchase Program will expire as of the close of business on December 31, 2015.  As of December 31, 2014, no purchases have been made under the Repurchase Program.


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0001564590-15-000466:notes:26]
[same as prior period, unchanged from 0001564590-14-003175:notes:21]

[0001564590-15-000466:notes:27]
[same as prior period, unchanged from 0001564590-14-003175:notes:22]

[0001564590-15-000466:notes:28]
[same as prior period, unchanged from 0001564590-14-003175:notes:23]

[0001564590-15-000466:notes:29]
|  | Three months ended December 31, |  |
|  | 2014 |  |  | 2013 |  |
| Balance at beginning of period | $ | 1,577 |  |  | $ | 572 |  |
| Bad debt expense/(recovery) |  | 283 |  |  |  | 15 |  |
| Uncollectible accounts written off, net of recoveries |  | (2 | ) |  |  | 88 |  |
| Change in foreign currency translation |  | (14 | ) |  |  | (2 | ) |
| Balance at end of period | $ | 1,844 |  |  | $ | 673 |  |

[0001564590-15-000466:notes:30]
[same as prior period, unchanged from 0001564590-14-003175:notes:25]

[0001564590-15-000466:notes:31]
[same as prior period, unchanged from 0001564590-14-003175:notes:26]

[0001564590-15-000466:notes:32]
|  | December 31, |  |  | September 30, |  |
|  | 2014 |  |  | 2014 |  |
| Raw materials, parts and subassemblies | $ | 40,017 |  |  | $ | 35,349 |  |
| Work-in-progress |  | 1,495 |  |  |  | 2,035 |  |
| Provision for excess and obsolete inventory |  | (4,882 | ) |  |  | (4,569 | ) |
| Total inventories | $ | 36,630 |  |  | $ | 32,815 |  |

[0001564590-15-000466:notes:33]
[same as prior period, unchanged from 0001564590-14-003175:notes:28]

[0001564590-15-000466:notes:34]
[same as prior period, unchanged from 0001564590-14-003175:notes:29]

[0001564590-15-000466:notes:35]
|  | December 31, |  |  | September 30, |  |
|  | 2014 |  |  | 2014 |  |
| Costs incurred on uncompleted contracts | $ | 611,852 |  |  | $ | 604,939 |  |
| Estimated earnings |  | 155,112 |  |  |  | 157,562 |  |
|  |  | 766,964 |  |  |  | 762,501 |  |
| Less: Billings to date |  | (741,322 | ) |  |  | (715,233 | ) |
| Net underbilled position | $ | 25,642 |  |  | $ | 47,268 |  |
| Included in the accompanying balance sheets under the following captions: |  |  |  |  |  |  |  |
| Costs and estimated earnings in excess of billings on uncompleted contracts - underbilled | $ | 84,922 |  |  | $ | 95,970 |  |
| Billings in excess of costs and estimated earnings on uncompleted contracts - overbilled |  | (59,280 | ) |  |  | (48,702 | ) |
| Net underbilled position | $ | 25,642 |  |  | $ | 47,268 |  |

[0001564590-15-000466:notes:36]
[same as prior period, unchanged from 0001564590-14-003175:notes:31]

[0001564590-15-000466:notes:37]
[same as prior period, unchanged from 0001564590-14-003175:notes:32]

[0001564590-15-000466:notes:38]
|  | Three months ended December 31, |  |
|  | 2014 |  |  | 2013 |  |
| Balance at beginning of period | $ | 4,557 |  |  | $ | 5,282 |  |
| Increase to warranty expense |  | 537 |  |  |  | 464 |  |
| Deduction for warranty charges |  | (524 | ) |  |  | (731 | ) |
| Increase (decrease) due to foreign currency translations |  | (90 | ) |  |  | (5 | ) |
| Balance at end of period | $ | 4,480 |  |  | $ | 5,010 |  |


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0001564590-15-000466:notes:39]
[same as prior period, unchanged from 0001564590-14-003175:notes:34]

[0001564590-15-000466:notes:40]
Intangible assets balances, subject to amortization, at December 31, 2014 and September 30, 2014 consisted of the following (in thousands):

[0001564590-15-000466:notes:41]
|  | December 31, 2014 |  |  | September 30, 2014 |  |
|  | Gross |  |  |  |  |  |  | Net |  |  | Gross |  |  |  |  |  |  | Net |  |
|  | Carrying |  |  | Accumulated |  |  | Carrying |  |  | Carrying |  |  | Accumulated |  |  | Carrying |  |
|  | Value |  |  | Amortization |  |  | Value |  |  | Value |  |  | Amortization |  |  | Value |  |
| Purchased technology | $ | 11,749 |  |  | $ | (10,034 | ) |  | $ | 1,715 |  |  | $ | 11,749 |  |  | $ | (9,918 | ) |  | $ | 1,831 |  |
| Trade name |  | 1,136 |  |  |  | (1,089 | ) |  |  | 47 |  |  |  | 1,136 |  |  |  | (1,063 | ) |  |  | 73 |  |
| Total | $ | 12,885 |  |  | $ | (11,123 | ) |  | $ | 1,762 |  |  | $ | 12,885 |  |  | $ | (10,981 | ) |  | $ | 1,904 |  |

[0001564590-15-000466:notes:42]
Amortization of intangible assets recorded for the three months ended December 31, 2014 and 2013 was $0.1 million and $0.4 million, respectively.

[0001564590-15-000466:notes:43]
On August 7, 2006, we purchased certain assets related to the manufacturing of ANSI medium-voltage switchgear and circuit breaker business from General Electric Company (GE).  In connection with the acquisition, we entered into a 15 year supply agreement with GE pursuant to which GE would purchase from the Company all of its requirements for ANSI medium-voltage switchgear and circuit breakers and other related equipment and components (the Products)  In connection with the acquisition, we recorded an intangible asset related to this supply agreement.  On December 30, 2013, the Company and GE amended the supply agreement to allow GE to manufacture similar Products for sale immediately and allow GE to begin purchasing Products from other suppliers beginning December 31, 2014.  In return, GE paid us $10 million upon execution of the amended supply agreement and agreed to pay an additional $7 million over three years.  We wrote off the intangible asset related to the original supply agreement and recorded a deferred credit in the amount of $8.1 million at December 31, 2013, the amount by which the proceeds from GE exceeded the unamortized balance of our intangible asset. This deferred credit is being amortized over the four year life of the agreement.


## us-gaap:LongTermDebtTextBlock

[0001564590-15-000466:notes:44]
E. LONG-TERM DEBT

[0001564590-15-000466:notes:45]
Long-term debt consisted of the following (in thousands):

[0001564590-15-000466:notes:46]
|  | December 31, 2014 |  |  | September 30, 2014 |  |
| Industrial development revenue bonds | $ | 2,800 |  |  | $ | 3,200 |  |
| Less current portion |  | (400 | ) |  |  | (400 | ) |
| Total long-term debt and capital lease obligations | $ | 2,400 |  |  | $ | 2,800 |  |

[0001564590-15-000466:notes:47]
U.S. Revolver

[0001564590-15-000466:notes:48]
In December 2013, we amended and restated our existing credit agreement (the Amended Credit Agreement) with a major domestic bank.  In December 2014, we entered into the Second Amendment of the Amended Credit Agreement (the Second Amendment).  The Second Amendment provides for the expansion of our Canadian manufacturing facility and allows for the repurchase of our common stock pursuant to a share repurchase program announced in December 2014. The Amended Credit Agreement provides for a $75.0 million revolving credit facility (U.S. Revolver). Obligations are collateralized by the stock of certain of our subsidiaries.

[0001564590-15-000466:notes:49]
The interest rate for amounts outstanding under the Amended Credit Agreement for the U.S. Revolver is a floating rate based upon the higher of the Federal Funds Rate plus 0.5%, the bank’s prime rate, or the Eurocurrency rate plus 1.00%. Once the applicable rate is determined, a margin ranging up to 1.75%, as determined by our consolidated leverage ratio, is added to the applicable rate.

[0001564590-15-000466:notes:50]
The U.S. Revolver provides for the issuance of letters of credit which reduce the amounts that may be borrowed under this revolver. The amount available under the U.S. Revolver was reduced by $18.3 million for our outstanding letters of credit at December 31, 2014.

[0001564590-15-000466:notes:51]
There were no borrowings outstanding under the U.S. Revolver as of December 31, 2014. Amounts available under the U.S. Revolver were $56.7 million at December 31, 2014. The U.S. Revolver expires on December 31, 2018.

[0001564590-15-000466:notes:52]
The Amended Credit Agreement contains certain restrictive and maintenance-type covenants, such as restrictions on the amount of capital expenditures allowed. It also contains financial covenants defining various financial measures and the levels of these measures with which we must comply, as well as a “material adverse change” clause. A “material adverse change” is defined as a material change in our operations, business, properties, liabilities or condition (financial or otherwise) or a material impairment of our ability to perform our obligations under our credit agreements.

[0001564590-15-000466:notes:53]
The Amended Credit Agreement is collateralized by a pledge of 100% of the voting capital stock of each of our domestic subsidiaries and 66% of the voting capital stock of each non-domestic subsidiary, excluding Powell Canada. The Amended Credit Agreement provides for customary events of default and carries cross-default provisions with other existing debt agreements. If an event of default (as defined in the Amended Credit Agreement) occurs and is continuing, on the terms and subject to the conditions set forth in the Amended Credit Agreement, amounts outstanding under the Amended Credit Agreement may be accelerated and may become immediately due and payable. As of December 31, 2014, we were in compliance with all of the financial covenants of the Amended Credit Agreement.

[0001564590-15-000466:notes:54]
Canadian Revolver

[0001564590-15-000466:notes:55]
We have an $8.6 million credit agreement with a major international bank in Canada (the Canadian Revolver) to provide working capital support and letters of credit for our operations in Canada. The Canadian Revolver provides for the issuance of letters of credit which reduce the amounts that may be borrowed under this revolver.  There were no outstanding letters of credit under the Canadian Revolver at December 31, 2014.

[0001564590-15-000466:notes:56]
There were no borrowings outstanding under the Canadian Revolver as of December 31, 2014 and amounts available under the Canadian Revolver were $8.6 million at December 31, 2014. The Canadian Revolver expires on February 28, 2015. The interest rate for amounts outstanding under the Canadian Revolver is a floating interest rate based upon either the Canadian Prime Rate, or the lender’s Bankers’ Acceptance Rate. Once the applicable rate is determined, a margin of 0.50% to 1.75%, as determined by our consolidated leverage ratio, is added to the applicable rate.

[0001564590-15-000466:notes:57]
The principal financial covenants are consistent with those described in our Amended Credit Agreement. The Canadian Revolver contains a “material adverse effect” clause. A “material adverse effect” is defined as a material change in the operations of Powell or Powell Canada in relation to our financial condition, property, business operations, expected net cash flows, liabilities or capitalization.

[0001564590-15-000466:notes:58]
The Canadian Revolver is secured by the assets of our Canadian operations and provides for customary events of default and carries cross-default provisions with our existing debt agreements. If an event of default (as defined in the Canadian Revolver) occurs and is continuing, per the terms and subject to the conditions set forth in the Canadian Revolver, amounts outstanding under the Canadian Revolver may be accelerated and may become immediately due and payable. As of December 31, 2014, we were in compliance with all of the financial covenants of the Canadian Revolver.

[0001564590-15-000466:notes:59]
Industrial Development Revenue Bonds

[0001564590-15-000466:notes:60]
We borrowed $8.0 million in October 2001 through a loan agreement funded with proceeds from tax-exempt industrial development revenue bonds (Bonds). These Bonds were issued by the Illinois Development Finance Authority and were used for the completion of our Northlake, Illinois facility. Pursuant to the Bond issuance, a reimbursement agreement between us and a major domestic bank required an issuance by the bank of an irrevocable direct-pay letter of credit (Bond LC), as collateral, to the Bonds’ trustee to guarantee payment of the Bonds’ principal and interest when due. The Bond LC is subject to both early termination and extension provisions customary to such agreements, as well as various covenants, for which we were in compliance at December 31, 2014. While the Bonds mature in 2021, the reimbursement agreement requires annual redemptions of $0.4 million that commenced on October 25, 2002. A sinking fund is used for the redemption of the Bonds. At December 31, 2014, the balance in the restricted sinking fund was approximately $0.1 million and was recorded in cash and cash equivalents. The Bonds bear interest at a floating rate determined weekly by the Bonds’ remarketing agent, which was the underwriter for the Bonds and is an affiliate of the bank. This interest rate was 0.18% as of December 31, 2014.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001564590-15-000466:notes:61]
F. COMMITMENTS AND CONTINGENCIES

[0001564590-15-000466:notes:62]
Long-Term Debt

[0001564590-15-000466:notes:63]
See Note E herein for discussion of our long-term debt.

[0001564590-15-000466:notes:64]
Letters of Credit and Bonds

[0001564590-15-000466:notes:65]
Certain customers require us to post bank letter of credit guarantees or performance bonds issued by a surety. These guarantees and performance bonds assure that we will perform under the terms of our contract. In the event of default, the counterparty may demand payment from the bank under a letter of credit or performance by the surety under a performance bond. To date, there have been no significant expenses related to either letters of credit or performance bonds for the periods reported. We were contingently liable for secured and unsecured letters of credit of $18.3 million as of December 31, 2014. We also had performance and maintenance bonds totaling $311.9 million that were outstanding, with additional bonding capacity of $288.1 million available, at December 31, 2014.

[0001564590-15-000466:notes:66]
We have a $15.5 million facility agreement (Facility Agreement) between Powell (UK) Limited and a large international bank. This Facility Agreement provides Powell (UK) the ability to enter into bank guarantees as well as forward exchange contracts and currency options. At December 31, 2014, we had outstanding guarantees totaling $3.9 million under this Facility Agreement.  Amounts available under this Facility Agreement were $11.6 million as of December 31, 2014.

[0001564590-15-000466:notes:67]
The Facility Agreement provides for financial covenants and customary events of default, and carries cross-default provisions with our Amended Credit Facility. If an event of default (as defined in the Facility Agreement) occurs and is continuing, per the terms and subject to the conditions set forth in the Facility Agreement, obligations outstanding under the Facility Agreement may be accelerated and may become or be declared immediately due and payable. As of December 31, 2014, we were in compliance with all of the financial covenants of the Facility Agreement.

[0001564590-15-000466:notes:68]
Litigation

[0001564590-15-000466:notes:69]
We are involved in various legal proceedings, claims and other disputes arising in the ordinary course of business which, in general, are subject to uncertainties and in which the outcomes are not predictable. Although we can give no assurance about the outcome of pending or threatened litigation and the effect such outcomes may have on us, management believes that any ultimate liability resulting from the outcome of such proceedings, to the extent not otherwise provided or covered by insurance, will not have a material adverse effect on our consolidated financial position or results of operations or liquidity.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001564590-15-000466:notes:70]
| G. | STOCK-BASED COMPENSATION |

[0001564590-15-000466:notes:71]
Refer to our Annual Report on Form 10-K for the fiscal year ended September 30, 2014 for a full description of our existing stock-based compensation plans.

[0001564590-15-000466:notes:72]
In February 2014, our stockholders approved our 2014 Equity Incentive Plan (the 2014 Plan).  Persons eligible to receive awards under the 2014 Plan include certain officers and employees.  This Plan authorizes stock options, stock appreciation rights, restricted stock, restricted stock units and performance-based awards, as well as certain other awards.

[0001564590-15-000466:notes:73]
Restricted Stock Units

[0001564590-15-000466:notes:74]
We issue restricted stock units (RSUs) to certain officers and key employees of the Company. The RSUs vest over a three-year period from their date of issuance. The fair value of the RSUs is based on the closing price of our common stock as reported on the  NASDAQ Global Market on the grant dates. Sixty-percent of the actual amount of the RSUs earned will be based on the cumulative earnings as reported relative to the three-year performance cycle which begins October 1 of the year granted, and ranges from 0% to 150% of the target RSUs granted. The remaining forty-percent of the RSUs are time-based and vest over a three-year period. At December 31, 2014, there were 167,137 RSUs outstanding. The RSUs do not have voting rights and do not receive dividends on common stock; additionally, the shares of common stock underlying the RSUs are not considered issued and outstanding until actually issued.

[0001564590-15-000466:notes:75]
RSU activity (number of shares) for the quarter is summarized below:

[0001564590-15-000466:notes:76]
|  | Number of |  |  | Weighted |  |
|  | Restricted |  |  | Average |  |
|  | Stock |  |  | Fair Value |  |
|  | Units |  |  | Per Share |  |
| Outstanding at September 30, 2014 |  | 106,845 |  |  | $ | 51.30 |  |
| Granted |  | 85,000 |  |  |  | 41.88 |  |
| Vested |  | (24,708 | ) |  |  | 40.26 |  |
| Forfeited |  | — |  |  |  | — |  |
| Outstanding at December 31, 2014 |  | 167,137 |  |  | $ | 48.14 |  |

[0001564590-15-000466:notes:77]
During the three months ended December 31, 2014 and 2013, we recorded compensation expense of $0.8 million and $0.9 million, respectively, related to the RSUs.

[0001564590-15-000466:notes:78]
Restricted Stock

[0001564590-15-000466:notes:79]
In February 2014 our stockholders also approved the 2014 Non-Employee Director Equity Incentive Plan (the 2014 Director Plan) for the benefit of members of the Board of Directors of the Company who, at the time of their service are not employees of the Company or any of its affiliates. The 2014 Director Plan authorizes stock options, stock appreciation rights, restricted stock, restricted stock units, as well as certain other awards.

[0001564590-15-000466:notes:80]
During the first quarter of Fiscal 2015 and Fiscal 2014, there was no restricted stock granted under either of these plans.

[0001564590-15-000466:notes:81]
During the three months ended December 31, 2014 and December 31, 2013, we recorded compensation expense of $0.3 million and $0.2 million, respectively, related to restricted stock grants.


## us-gaap:FairValueDisclosuresTextBlock

[0001564590-15-000466:notes:82]
[same as prior period, unchanged from 0001564590-14-003175:notes:74]

[0001564590-15-000466:notes:83]
[same as prior period, unchanged from 0001564590-14-003175:notes:75]

[0001564590-15-000466:notes:84]
[same as prior period, unchanged from 0001564590-14-003175:notes:76]

[0001564590-15-000466:notes:85]
[same as prior period, unchanged from 0001564590-14-003175:notes:77]

[0001564590-15-000466:notes:86]
[same as prior period, unchanged from 0001564590-14-003175:notes:78]

[0001564590-15-000466:notes:87]
[same as prior period, unchanged from 0001564590-14-003175:notes:79]

[0001564590-15-000466:notes:88]
The following table summarizes the fair value of our assets and liabilities that were accounted for at fair value on a recurring basis as of December 31, 2014 (in thousands):

[0001564590-15-000466:notes:89]
|  | Fair Value Measurements at December 31, 2014 |  |
|  | Quoted Prices in |  |  | Significant Other |  |  | Significant |  |  |  |  |  |
|  | Active Markets for |  |  | Observable |  |  | Unobservable |  |  | Fair Value at |  |
|  | Identical Assets |  |  | Inputs |  |  | Inputs |  |  | December 31, |  |
|  | (Level 1) |  |  | (Level 2) |  |  | (Level 3) |  |  | 2014 |  |
| Assets: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cash equivalents | $ | 134 |  |  | $ | — |  |  | $ | — |  |  | $ | 134 |  |
| Deferred compensation |  | 1,795 |  |  |  | 2,845 |  |  |  | — |  |  |  | 4,640 |  |
| Liabilities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Deferred compensation |  | — |  |  |  | 4,857 |  |  |  | — |  |  |  | 4,857 |  |

[0001564590-15-000466:notes:90]
The following table summarizes the fair value of our assets and liabilities that were accounted for at fair value on a recurring basis as of September 30, 2014 (in thousands):

[0001564590-15-000466:notes:91]
|  | Fair Value Measurements at September 30, 2014 |  |
|  | Quoted Prices in |  |  | Significant Other |  |  | Significant |  |  |  |  |  |
|  | Active Markets for |  |  | Observable |  |  | Unobservable |  |  | Fair Value at |  |
|  | Identical Assets |  |  | Inputs |  |  | Inputs |  |  | September 30, |  |
|  | (Level 1) |  |  | (Level 2) |  |  | (Level 3) |  |  | 2014 |  |
| Assets: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cash equivalents | $ | 10,535 |  |  | $ | — |  |  | $ | — |  |  | $ | 10,535 |  |
| Deferred compensation |  | 724 |  |  |  | 2,802 |  |  |  | — |  |  |  | 3,526 |  |
| Liabilities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Deferred compensation |  | — |  |  |  | 3,688 |  |  |  | — |  |  |  | 3,688 |  |

[0001564590-15-000466:notes:92]
[same as prior period, unchanged from 0001564590-14-003175:notes:84]

[0001564590-15-000466:notes:93]
[same as prior period, unchanged from 0001564590-14-003175:notes:85]

[0001564590-15-000466:notes:94]
Fair value guidance requires certain fair value disclosures be presented in both interim and annual reports.  The estimated fair value amounts of financial instruments have been determined using available market information and valuation methodologies described below.

[0001564590-15-000466:notes:95]
Deferred Compensation – We hold investments in an irrevocable Rabbi Trust for our deferred compensation plan. These assets include various mutual fund investments and company-owned life insurance policies. Under the plan, participants designate investment options to serve as the basis for measurement of the notional value of their accounts.  The fair values of the underlying securities of these funds are based on quoted market prices and are categorized as Level I in the fair value measurement hierarchy.  The company-owned life insurance policies are valued at cash surrender value and are therefore categorized as Level 2 in the fair value measurement hierarchy.

[0001564590-15-000466:notes:96]
Industrial Development Revenue Bond – The fair value of our long-term debt depends primarily on the coupon rate of our industrial development revenue bonds.  The carrying value of our long-term debt at December 31, 2014, approximates fair value based on the current coupon rate of the bonds, which is reset weekly, and is classified as a Level 2 input in the fair value measurement hierarchy as there is an active market for the trading of these industrial development revenue bonds.

[0001564590-15-000466:notes:97]
There were no transfers between levels within the fair value measurement hierarchy during the three months ended December 31, 2014.


## us-gaap:DisposalGroupsIncludingDiscontinuedOperationsDisclosureTextBlock

[0001564590-15-000466:notes:98]
[same as prior period, unchanged from 0001564590-14-003175:notes:89]

[0001564590-15-000466:notes:99]
On January 15, 2014, we sold our wholly-owned subsidiary Transdyn to a global provider of electronic toll collection systems, headquartered in Vienna, Austria.  The purchase price from the sale of this subsidiary totaled $16.0 million, subject to working capital adjustments.  We received cash of $14.4 million and the remaining $1.6 million was placed into an escrow account until April 2015, to be released subject to certain contingent obligations.

[0001564590-15-000466:notes:100]
We have presented the results of these operations as income from discontinued operations, net of tax, in the condensed consolidated statements of operations as of December 31, 2013.

[0001564590-15-000466:notes:101]
[same as prior period, unchanged from 0001564590-14-003175:notes:92]

[0001564590-15-000466:notes:102]
|  | Three months ended December 31, |  |
|  | 2014 |  |  | 2013 |  |
| Revenues | $ | — |  |  | $ | 12,365 |  |
| Income from discontinued operations, net of tax of zero and $502, respectively |  | — |  |  |  | 987 |  |
| Earnings per share information: |  |  |  |  |  |  |  |
| Basic | $ | — |  |  | $ | 0.08 |  |
| Diluted | $ | — |  |  | $ | 0.08 |  |


## us-gaap:IncomeTaxDisclosureTextBlock

[0001564590-15-000466:notes:103]
J. INCOME TAXES

[0001564590-15-000466:notes:104]
The calculation of the effective tax rate is as follows (in thousands):

[0001564590-15-000466:notes:105]
|  | Three months ended December 31, |  |
|  | 2014 |  |  | 2013 |  |
| Income (loss) from continuing operations before income taxes | $ | (1,230 | ) |  | $ | 11,205 |  |
| Income tax provision (benefit) |  | (991 | ) |  |  | 3,937 |  |
| Income (loss) from continuing operations | $ | (239 | ) |  | $ | 7,268 |  |
| Effective tax rate |  | 81 | % |  |  | 35 | % |

[0001564590-15-000466:notes:106]
We recorded a benefit for income taxes for continuing operations of $1.0 million in the first quarter of Fiscal 2015, compared to the provision of $3.9 million recorded in the first quarter of Fiscal 2014.  The effective tax rate for the first quarter of Fiscal 2015 was    81% compared to an effective tax rate of 35% in the first quarter of Fiscal 2014, primarily due to the differences in the availability of the Federal Research and Development Tax Credit (R&D Tax Credit).  On December 19, 2014, the “Tax Increase Prevention Act of 2014” was enacted which retroactively reinstated and extended the R&D Tax Credit for one year through December 31, 2014.  The retroactive tax benefit for the previously expired period from January 1, 2014 to September 30, 2014 of $0.6 million is reflected as a discrete item and had a favorable impact to our consolidated tax benefit for the first quarter of Fiscal 2015. The effective tax rate for the quarter ended December 31, 2013 approximated the expected U.S. federal and state statutory rates as the majority of our income is attributable to the U.S.

[0001564590-15-000466:notes:107]
At December 31, 2014, we had $26 million of gross foreign operating loss carryforwards which are subject to a 20-year carryforward period, the first of which will expire in 2031. At September 30, 2013, we released a valuation allowance that was recorded against Canadian deferred tax assets, resulting in a $7 million tax benefit.  Although our Canadian operations reported a loss for Fiscal 2014 and the first quarter of Fiscal 2015, we believe these deferred tax assets are more likely than not to be utilized by future taxable income. With the exception of the deferred tax assets related to certain foreign withholding taxes as well as the net operating losses of our Dutch entities, we believe that our other deferred tax assets are more likely than not realizable through future reversals of existing taxable temporary differences and our estimate of future taxable income. The recognition of deferred tax assets requires estimates related to future income and other assumptions regarding timing and future profitability. Estimates may change as new events occur, additional information becomes available or operating environments change.
