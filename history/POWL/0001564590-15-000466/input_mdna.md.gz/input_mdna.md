# POWL MD&A — 0001564590-15-000466


## mdna

[0001564590-15-000466:mdna:1]
[same as prior period, unchanged from 0001564590-14-003175:mdna:1]

[0001564590-15-000466:mdna:2]
The following discussion and analysis of our financial condition and results of operations should be read in conjunction with the accompanying condensed consolidated financial statements and related notes included elsewhere in this Quarterly Report on Form 10-Q and with our Annual Report on Form 10-K for the year ended September 30, 2014 which was filed with the Securities and Exchange Commission (SEC) on December 3, 2014 and is available on the SEC’s website at www.sec.gov.

[0001564590-15-000466:mdna:3]
[same as prior period, unchanged from 0001564590-14-003175:mdna:3]

[0001564590-15-000466:mdna:4]
We develop, design, manufacture and service custom-engineered equipment and systems for the management and control of electrical energy and other critical processes. Headquartered in Houston, Texas, we serve the oil and gas refining, offshore oil and gas production, petrochemical, pipeline, terminal, pulp and paper, mining and metals, light rail traction power, and electric utility markets. Revenues and costs are primarily related to custom engineered-to-order equipment and systems and accounted for under percentage of completion accounting which precludes us from providing detailed price and volume information.

[0001564590-15-000466:mdna:5]
The markets in which we participate are capital intensive and cyclical in nature. Cyclicality is predominantly driven by customer demand, global economic conditions and anticipated environmental or regulatory changes which affect the manner in which our customers proceed with capital investments. Our customers analyze various factors including the demand and price for oil, gas and electrical energy, the overall financial environment, governmental budgets, regulatory actions and environmental concerns. These factors influence the release of new capital projects by our customers, which are traditionally awarded in competitive bid situations. Scheduling is matched to the customer requirements and projects may take a number of months to produce; schedules also may change during the course of any particular project. Our operating results can be impacted by factors outside of our control.  For example, many of our projects have contracting arrangements where the customer’s approval of engineering and design specifications may affect the timing of the project execution thus impacting the recognition of revenue and costs.

[0001564590-15-000466:mdna:6]
As of December 31, 2014, we have a backlog of unfilled orders of $505.7 million, which is a slight decrease from our backlog of unfilled orders of $507.1 million as of September 30, 2014.  Our backlog includes various projects, some of which are petrochemical, oil and gas construction and transportation infrastructure projects which take a number of months to produce.

[0001564590-15-000466:mdna:7]
We anticipate that demand for our solutions in the western Canadian oil and gas markets will continue to be a contributor to our strategic position in the Canadian market place.  We completed the construction of our new Canadian facility and relocated operations in the fall of 2013 and we are currently working on a $33 million expansion of this manufacturing facility, of which approximately $20 million has been incurred as of December 31, 2014. The production ramp of our Canadian operations has presented and continues to present challenges resulting in inefficiencies that have led to extended project delivery times, higher operating costs, gross margin deterioration and delayed project revenues.  We continue to take actions to mitigate the risks associated with replicating our U.S. project-based integration model which we believe will allow for the design, fabrication, integration and testing of our products.   Prior to the construction of our new Canadian facility, we performed only final assembly operations in Canada.

[0001564590-15-000466:mdna:8]
On January 15, 2014, we sold our wholly-owned subsidiary Transdyn to a global provider of electronic toll collection systems, headquartered in Vienna, Austria.  The purchase price from the sale of this subsidiary totaled $16.0 million, subject to working capital adjustments. We received cash of $14.4 million and the remaining $1.6 million was placed into an escrow account until April 2015, to be released subject to certain contingent obligations. We have presented the results of these operations as income from discontinued operations, net of tax, in the condensed consolidated statements of operations for the quarter ended December 31, 2013.  Accordingly, we have removed Transdyn from the Results of Operations discussions below.

[0001564590-15-000466:mdna:9]
[same as prior period, unchanged from 0001564590-14-003175:mdna:9]

[0001564590-15-000466:mdna:10]
[same as prior period, unchanged from 0001564590-14-003175:mdna:11]

[0001564590-15-000466:mdna:11]
Revenues decreased 11%, or $19.3 million, to $152.6 million in the first quarter of Fiscal 2015, compared to the first quarter of Fiscal 2014, primarily due to the substantial completion of a large international project in Fiscal 2014.  Domestic revenues increased by 9%, or $7.9 million, to $96.9 million in the first quarter of Fiscal 2015, compared to the first quarter of Fiscal 2014, and international revenues decreased by 33%, or $27.2 million, to $55.7 million in the first quarter of Fiscal 2015, compared to the first quarter of Fiscal 2014.  We substantially completed a large international project in the fourth quarter of Fiscal 2014 which is the primary reason for the decrease in international revenues and revenues as a whole in the first quarter of Fiscal 2015.  Revenues from commercial and industrial customers decreased $2.0 million to $122.5 million in the first quarter of Fiscal 2015, compared to the first quarter of Fiscal 2014. Revenues from public and private utilities decreased $10.2 million to $24.5 million in the first quarter of Fiscal 2015, compared to the first quarter of Fiscal 2014. Revenues from municipal and transit projects decreased $7.1 million to $5.6 million in the first quarter of Fiscal 2015, compared to the first quarter of Fiscal 2014.

[0001564590-15-000466:mdna:12]
Gross profit for the first quarter of Fiscal 2015 decreased 40.1%, or $14.1 million, to $21.1 million, compared to the first quarter of Fiscal 2014.  Gross profit as a percentage of revenues decreased to 13.8% in the first quarter of Fiscal 2015, compared to 20.5% in the

[0001564590-15-000466:mdna:13]
first quarter of Fiscal 2014 primarily due to continued inefficiencies and incremental costs to hold customers’ schedules associated with the expansion and ramp-up of our Canadian operations as well as the completion of the large international project noted above.

[0001564590-15-000466:mdna:14]
[same as prior period, unchanged from 0001564590-14-003175:mdna:14]

[0001564590-15-000466:mdna:15]
Selling, general and administrative expenses decreased $0.8 million to $20.8 million during the first quarter of Fiscal 2015 when compared to the first quarter of Fiscal 2014 partially due to the reduction in revenues and a reduction to incentive compensation, offset by an increase in personnel and administrative costs associated with the expansion of our Canadian operations.  Additionally, costs increased in Fiscal 2015 as we are no longer capitalizing certain personnel costs associated with the development and implementation of our enterprise resource planning, engineering and manufacturing process systems which were implemented in the second half of Fiscal 2014.  Selling, general and administrative expenses, as a percentage of revenues, increased slightly to 13.6% during the first quarter of Fiscal 2015, compared to 12.6% during the first quarter of Fiscal 2014 due to the factors mentioned above.

[0001564590-15-000466:mdna:16]
[same as prior period, unchanged from 0001564590-14-003175:mdna:18]

[0001564590-15-000466:mdna:17]
We recorded a benefit for income taxes for continuing operations of $1.0 million in the first quarter of Fiscal 2015, compared to the provision of $3.9 million recorded in the first quarter of Fiscal 2014.  The effective tax rate for the first quarter of Fiscal 2015 was    81% compared to an effective tax rate of 35% in the first quarter of Fiscal 2014, primarily due to the differences in the availability of the Federal Research and Development Tax Credit (R&D Tax Credit).  On December 19, 2014, the Tax Increase Prevention Act of 2014 was enacted which retroactively reinstated and extended the R&D Tax Credit for one year through December 31, 2014.  The retroactive benefit for the previously expired period from January 1, 2014 to September 30, 2014 of $0.6 million is reflected as a discrete item which had a favorable impact to our consolidated tax benefit for the first quarter of Fiscal 2015. The effective tax rate for the quarter ended December 31, 2013 approximated the expected U.S. federal and state statutory rates as the majority of our income is attributable to the U.S.

[0001564590-15-000466:mdna:18]
Income from continuing operations

[0001564590-15-000466:mdna:19]
In the first quarter of Fiscal 2015, we recorded a loss from continuing operations of $0.2 million, or a loss per share of $0.02, compared to $7.3 million, or $0.60 per diluted share, in the first quarter of Fiscal 2014.  Due to the R&D Tax Credit mentioned above, we recorded an additional tax benefit of $0.6 million in the first quarter of Fiscal 2015.

[0001564590-15-000466:mdna:20]
Income from discontinued operations

[0001564590-15-000466:mdna:21]
In January 2014, we sold our wholly-owned subsidiary Transdyn to a global provider of electronic toll collection systems, headquartered in Vienna, Austria.  We presented the results of these operations as income from discontinued operations, net of tax, for the quarter ended December 31, 2013.  We had no income from discontinued operations in the first quarter of Fiscal 2015, and in the first quarter of Fiscal 2014, we recorded $1.0 million in discontinued operations. For additional information about this disposition, see Note I in the Notes to Condensed Consolidated Financial Statements.

[0001564590-15-000466:mdna:22]
[same as prior period, unchanged from 0001564590-14-003175:mdna:24]

[0001564590-15-000466:mdna:23]
The order backlog at December 31, 2014 was $505.7 million, compared to $507.1 million at September 30, 2014.  New orders placed during the first quarter of Fiscal 2015 totaled $154.4 million compared to $192.2 million in the first quarter of Fiscal 2014.

[0001564590-15-000466:mdna:24]
[same as prior period, unchanged from 0001564590-14-003175:mdna:42]

[0001564590-15-000466:mdna:25]
Cash and cash equivalents decreased to $56.5 million at December 31, 2014, compared to $103.1 million at September 30, 2014.  As of December 31, 2014, current assets exceeded current liabilities by 2.3 times and our debt to total capitalization was 0.76%.

[0001564590-15-000466:mdna:26]
We have a $75.0 million revolving credit facility in the U.S., which expires in December 2016. As of December 31, 2014, there were no amounts borrowed under this line of credit. We also have an $8.6 million revolving credit facility in Canada. At December 31, 2014, there was no balance outstanding under the Canadian revolving credit facility. Total long-term debt and capital lease obligations, including current maturities, totaled $2.8 million at December 31, 2014, compared to $3.2 million at September 30, 2014. Total letters of credit outstanding were $18.3 million and $19.2 million at December 31, 2014 and 2013, respectively, which reduce our availability under our U.S. credit facility and our Canadian revolving credit facility. Amounts available at December 31, 2014 under the U.S. and Canadian revolving credit facilities were $56.7 million and $8.6 million, respectively.  For further information regarding our debt, see Notes E and F of Notes to Condensed Consolidated Financial Statements.

[0001564590-15-000466:mdna:27]
Approximately $9.2 million of our cash at December 31, 2014, was held outside of the United States for international operations.  It is our intention to indefinitely reinvest all current and future foreign earnings internationally in order to ensure sufficient working capital and support and expand these international operations.  In the event that we elect to repatriate some or all of the foreign earnings that were previously deemed to be indefinitely reinvested outside the U.S., under current tax laws we would incur additional tax expense upon such repatriation.

[0001564590-15-000466:mdna:28]
We believe that cash available and borrowing capacity under our existing credit facilities should be sufficient to finance anticipated operating activities, capital improvements and expansions, debt repayments and share repurchases, for the foreseeable future. We continue to monitor the factors that drive our markets and strive to maintain our leadership and competitive advantage in the markets we serve while aligning our cost structures with market conditions.

[0001564590-15-000466:mdna:29]
[same as prior period, unchanged from 0001564590-14-003175:mdna:47]

[0001564590-15-000466:mdna:30]
Cash used in operating activities was $22.7 million during the first quarter of Fiscal 2015, compared to cash provided by operating activities of $5.3 million during the first quarter of Fiscal 2014, primarily due to the net increase in accounts receivable, reduction of accrued liabilities primarily related to incentive compensation payments offset by the improvement in our net underbilled position in the first quarter of Fiscal 2015. Cash flow from operations is primarily influenced by demand for our products and services and is impacted as our progress payment terms with our customers are matched with the payment terms with our suppliers.

[0001564590-15-000466:mdna:31]
[same as prior period, unchanged from 0001564590-14-003175:mdna:49]

[0001564590-15-000466:mdna:32]
Purchases of property, plant and equipment during the first quarter of Fiscal 2015 totaled $19.0 million compared to $5.8 million during the first quarter of Fiscal 2014.  This increase results from the continued expansion of our Canadian operations in Fiscal 2015.

[0001564590-15-000466:mdna:33]
[same as prior period, unchanged from 0001564590-14-003175:mdna:51]

[0001564590-15-000466:mdna:34]
Net cash used in financing activities was $4.0 million during the first quarter of Fiscal 2015 and $3.9 million during the first quarter of Fiscal 2014 primarily from dividends paid during these quarters.

[0001564590-15-000466:mdna:35]
Share Repurchase Program

[0001564590-15-000466:mdna:36]
On December 17, 2014, our Board of Directors authorized a repurchase program (the Repurchase Program) under which we may repurchase up to $25 million of our outstanding stock.  The purchases may be made from time to time in the open market, through privately negotiated transactions and Rule 10b5-1 trading plans in accordance with applicable laws, rules and regulations.  The Repurchase Program will be funded from cash on hand and cash provided by operating activities.  The Repurchase Program will expire as of the close of business on December 31, 2015.  As of December 31, 2014, no purchases have been made under the Repurchase Program.

[0001564590-15-000466:mdna:37]
[same as prior period, unchanged from 0001564590-14-003175:mdna:53]

[0001564590-15-000466:mdna:38]
See Note A to our condensed consolidated financial statements included in this report for information on new accounting standards.

[0001564590-15-000466:mdna:39]
[same as prior period, unchanged from 0001564590-14-003175:mdna:55]

[0001564590-15-000466:mdna:40]
[same as prior period, unchanged from 0001564590-14-003175:mdna:56]

[0001564590-15-000466:mdna:41]
There have been no material changes to our critical accounting policies as disclosed in our Annual Report on Form 10-K for the year ended September 30, 2014.

[0001564590-15-000466:mdna:42]
[same as prior period, unchanged from 0001564590-14-003175:mdna:58]

[0001564590-15-000466:mdna:43]
The markets in which we participate are capital-intensive and cyclical in nature. Cyclicality is predominantly driven by customer demand, global economic conditions and anticipated environmental or regulatory changes which affect the manner in which our customers proceed with capital investments. Our customers analyze various factors including the demand and price for oil, gas and

[0001564590-15-000466:mdna:44]
electrical energy, the overall financial environment, governmental budgets, regulatory actions and environmental concerns. These factors influence the release of new capital projects by our customers, which are traditionally awarded in competitive bid situations. Scheduling is matched to the customer requirements; and projects may take a number of months to produce; schedules also may change during the course of any particular project.

[0001564590-15-000466:mdna:45]
Growth in demand for energy is expected to continue over the long term. This, when coupled with the need for replacement of existing infrastructure that is nearing the end of its life cycle, demonstrates a continued need for products and services produced by us. Our orders over the past year have been solid, driven primarily by the oil and gas and petrochemical industries overall, along with the specific demand associated with Canadian projects.  The recent decline in oil prices may present challenges in the near-term related to the funding of projects.  We continue to monitor the impact of oil prices on our markets and will adjust our cost structure accordingly.

[0001564590-15-000466:mdna:46]
Our operating results are frequently impacted by the timing and resolution of change orders and project close-out which could cause gross margins to improve or deteriorate during the period in which these items are approved and finalized with customers. Our operating results are also impacted by other factors, such as projects that have contract arrangements where the customer approval of final engineering and design specifications may delay the timing of the project execution.

[0001564590-15-000466:mdna:47]
We completed the construction of our new Acheson, Alberta facility and relocated operations in the fall of 2013. The production ramp of our Canadian operations has presented and may continue to present challenges resulting in inefficiencies and extended project delivery times. These challenges resulted in incremental costs to hold customers’ schedules, gross margin deterioration and ultimately delayed the recognition of revenues.  We continue to take actions to mitigate the risks associated with replicating our U.S. project-based integration model which we believe will allow for the design, fabrication, integration and testing of our products.  Prior to the construction of our new Canadian facility, we performed only final assembly operations in Canada.

[0001564590-15-000466:mdna:48]
We are in the process of expanding our manufacturing facility in Acheson, Alberta, Canada. The expansion is expected to cost approximately $33 million, of which approximately $20 million has been incurred as of December 31, 2014.  The remainder is expected to be funded from our existing cash and cash equivalents and future cash flows from operations.  We expect the expansion of our Canadian facility to be completed in the spring of 2015.

[0001564590-15-000466:mdna:49]
We believe that cash available and borrowing capacity under our existing credit facilities should be sufficient to finance anticipated operating activities, capital improvements, debt repayments and share repurchases for the foreseeable future. We continue to monitor our markets and will strive to maintain our leadership and competitive advantage in the markets we serve.
