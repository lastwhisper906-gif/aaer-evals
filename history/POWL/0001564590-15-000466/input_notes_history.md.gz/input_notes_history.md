# POWL note change history — 0001564590-14-003175 → 0001564590-15-000466


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2015-02-04):
[0001564590-15-000466:note_history:1]
Certain customers require us to post bank letter of credit guarantees or performance bonds issued by a surety. These guarantees and performance bonds assure that we will perform under the terms of our contract. In the event of default, the counterparty may demand payment from the bank under a letter of credit or performance by the surety under a performance bond. To date, there have been no significant expenses related to either letters of credit or performance bonds for the periods reported. We were contingently liable for secured and unsecured letters of credit of $18.3 million as of December 31, 2014. We also had performance and maintenance bonds totaling $311.9 million that were outstanding, with additional bonding capacity of $288.1 million available, at December 31, 2014.
  (was, 2014-08-06, similarity 0.9842):
[0001564590-14-003175:note_history:1]
Certain customers require us to post bank letter of credit guarantees or performance bonds issued by a surety. These guarantees and performance bonds assure that we will perform under the terms of our contract. In the event of default, the counterparty may demand payment from the bank under a letter of credit or performance by the surety under a performance bond. To date, there have been no significant expenses related to either letters of credit or performance bonds for the periods reported. We were contingently liable for secured and unsecured letters of credit of $21.2 million as of June 30, 2014. We also had performance and maintenance bonds totaling $330.2 million that were outstanding, with additional bonding capacity of $269.8 million available, at June 30, 2014.

- added (2015-02-04):
[0001564590-15-000466:note_history:2]
We have a $15.5 million facility agreement (Facility Agreement) between Powell (UK) Limited and a large international bank. This Facility Agreement provides Powell (UK) the ability to enter into bank guarantees as well as forward exchange contracts and currency options. At December 31, 2014, we had outstanding guarantees totaling $3.9 million under this Facility Agreement.  Amounts available under this Facility Agreement were $11.6 million as of December 31, 2014.

- changed (2015-02-04):
[0001564590-15-000466:note_history:3]
The Facility Agreement provides for financial covenants and customary events of default, and carries cross-default provisions with our Amended Credit Facility. If an event of default (as defined in the Facility Agreement) occurs and is continuing, per the terms and subject to the conditions set forth in the Facility Agreement, obligations outstanding under the Facility Agreement may be accelerated and may become or be declared immediately due and payable. As of December 31, 2014, we were in compliance with all of the financial covenants of the Facility Agreement.
  (was, 2014-08-06, similarity 0.9893):
[0001564590-14-003175:note_history:3]
The Facility Agreement provides for financial covenants and customary events of default, and carries cross-default provisions with our Amended Credit Facility. If an event of default (as defined in the Facility Agreement) occurs and is continuing, per the terms and subject to the conditions set forth in the Facility Agreement, obligations outstanding under the Facility Agreement may be accelerated and may become or be declared immediately due and payable. As of June 30, 2014, we were in compliance with all of the financial covenants of the Facility Agreement.

- changed (2015-02-04):
[0001564590-15-000466:note_history:4]
We are involved in various legal proceedings, claims and other disputes arising in the ordinary course of business which, in general, are subject to uncertainties and in which the outcomes are not predictable. Although we can give no assurance about the outcome of pending or threatened litigation and the effect such outcomes may have on us, management believes that any ultimate liability resulting from the outcome of such proceedings, to the extent not otherwise provided or covered by insurance, will not have a material adverse effect on our consolidated financial position or results of operations or liquidity.
  (was, 2014-08-06, similarity 0.9927):
[0001564590-14-003175:note_history:4]
We are involved in various legal proceedings, claims and other disputes arising in the ordinary course of business which, in general, are subject to uncertainties and the outcomes are not predictable. Although we can give no assurance about the outcome of pending or threatened litigation and the effect such outcomes may have on us, management believes that any ultimate liability resulting from the outcome of such proceedings, to the extent not otherwise provided or covered by insurance, will not have a material adverse effect on our consolidated financial position or results of operations or liquidity.

- removed (2015-02-04):
[0001564590-14-003175:note_history:5]
We have an $8.5 million facility agreement (Facility Agreement) between Powell (UK) Limited and a large international bank. This Facility Agreement provides Powell (UK) the ability to enter into various guarantees, such as forward exchange contracts, currency options and performance bonds. At June 30, 2014, we had outstanding guarantees totaling $3.7 million under this Facility Agreement.  Amounts available under this Facility Agreement were $4.8 million as of June 30, 2014.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureAndSignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2015-02-04):
[0001564590-15-000466:note_history:6]
Powell Industries, Inc. (we, us, our, Powell or the Company) was incorporated in the state of Delaware in 2004 as a successor to a Nevada company incorporated in 1968. The Nevada corporation was the successor to a company founded by William E. Powell in 1947, which merged into the Company in 1977. Our major subsidiaries, all of which are wholly owned, include: Powell Electrical Systems, Inc.; Powell (UK) Limited; Powell Canada Inc. and Powell Industries International, B.V.
  (was, 2014-08-06, similarity 0.858):
[0001564590-14-003175:note_history:6]
Powell Industries, Inc. (we, us, our, Powell or the Company) was incorporated in the state of Delaware in 2004 as a successor to a Nevada company incorporated in 1968. The Nevada corporation was the successor to a company founded by William E. Powell in 1947, which merged into the Company in 1977. Our major subsidiaries, all of which are wholly-owned, include: Powell Electrical Systems, Inc.; Powell Industries International, B.V.; Powell (UK) Limited (formerly Switchgear & Instrumentation Limited) and Powell Canada Inc.

- added (2015-02-04):
[0001564590-15-000466:note_history:7]
We develop, design, manufacture and service custom-engineered equipment and systems for the distribution, control and monitoring of electrical energy designed to (1) distribute, monitor and control the flow of electrical energy and (2)  provide protection to motors, transformers and other electrically powered equipment. Headquartered in Houston, Texas, we serve the transportation, energy, industrial and utility industries.

- added (2015-02-04):
[0001564590-15-000466:note_history:8]
References to Fiscal 2015, Fiscal 2014 and Fiscal 2013 used throughout this report shall mean our fiscal years ended September 30, 2015, 2014 and 2013, respectively.

- changed (2015-02-04):
[0001564590-15-000466:note_history:9]
The preparation of financial statements in conformity with U.S. GAAP requires management to make estimates and assumptions that affect the amounts reported in the consolidated financial statements and accompanying footnotes. The most significant estimates used in our financial statements affect revenue and cost recognition for construction contracts, the allowance for doubtful accounts, provision for excess and obsolete inventory, goodwill and other intangible assets, self-insurance, warranty accruals and income taxes. The amounts recorded for insurance claims, warranties, legal, income taxes and other contingent liabilities require judgments regarding the amount of expenses that will ultimately be incurred. We base our estimates on historical experience and on various other assumptions, as well as the specific circumstances surrounding these contingent liabilities, in evaluating the amount of liability that should be recorded. Additionally, the recognition of deferred tax assets requires estimates related to future income and other assumptions regarding timing and future profitability.  Estimates may change as new events occur, additional information becomes available or operating environments change. Actual results may differ from our estimates.
  (was, 2014-08-06, similarity 0.8):
[0001564590-14-003175:note_history:9]
The preparation of financial statements in conformity with U.S. GAAP requires management to make estimates and assumptions that affect the amounts reported in the consolidated financial statements and accompanying footnotes. The most significant estimates used in our financial statements affect revenue and cost recognition for construction contracts, the allowance for doubtful accounts, provision for excess and obsolete inventory, goodwill and other intangible assets, self-insurance, warranty accruals and income taxes. The amounts recorded for insurance claims, warranties, legal, income taxes and other contingent liabilities require judgments regarding the amount of expenses that will ultimately be incurred. We base our estimates on historical experience and on various other assumptions, as well as the specific circumstances surrounding these contingent liabilities, in evaluating the amount of liability that should be recorded. Estimates may change as new events occur, additional information becomes available or operating environments change. Actual results may differ from our estimates.

- added (2015-02-04):
[0001564590-15-000466:note_history:10]
Supplemental Disclosures of Cash Flow Information (in thousands):

- added (2015-02-04):
[0001564590-15-000466:note_history:11]
|  | Three months ended December 31, |
|  | 2014 |  |  |  |  | 2013 |  |
| Non-cash capital expenditures | $ | 8,727 |  |  |  |  | $ | — |  |

- changed (2015-02-04):
[0001564590-15-000466:note_history:12]
In July 2013, the FASB issued accounting guidance on the presentation of an unrecognized tax benefit when a net operating loss carryforward, a similar tax loss, or a tax credit carryforward exists. The guidance states that an unrecognized tax benefit, or a portion of an unrecognized tax benefit, should be presented in the financial statements as a reduction to a deferred tax asset for a net operating loss carryforward, a similar tax loss, or a tax credit carryforward. To the extent a net operating loss carryforward, a similar tax loss, or a tax credit carryforward is not available at the reporting date under the tax law of the applicable jurisdiction to settle any additional income taxes that would result from the disallowance of a tax position or the tax law of the applicable jurisdiction does not require the entity to use, and the entity does not intend to use, the deferred tax asset for such purpose, the unrecognized tax benefit should be presented in the financial statements as a liability and should not be combined with deferred tax assets. This guidance is effective for fiscal years, and interim periods within those years, beginning after December 15, 2013, which would be our fiscal year ended September 30, 2015. This guidance should be applied prospectively to all unrecognized tax benefits that exist at the effective date. Retrospective application is permitted. The adoption of this guidance has not had a significant impact on our consolidated financial position or results of operations.
  (was, 2014-08-06, similarity 0.9887):
[0001564590-14-003175:note_history:12]
In July 2013, the FASB issued accounting guidance on the presentation of an unrecognized tax benefit when a net operating loss carryforward, a similar tax loss, or a tax credit carryforward exists. The guidance states that an unrecognized tax benefit, or a portion of an unrecognized tax benefit, should be presented in the financial statements as a reduction to a deferred tax asset for a net operating loss carryforward, a similar tax loss, or a tax credit carryforward. To the extent a net operating loss carryforward, a similar tax loss, or a tax credit carryforward is not available at the reporting date under the tax law of the applicable jurisdiction to settle any additional income taxes that would result from the disallowance of a tax position or the tax law of the applicable jurisdiction does not require the entity to use, and the entity does not intend to use, the deferred tax asset for such purpose, the unrecognized tax benefit should be presented in the financial statements as a liability and should not be combined with deferred tax assets. This guidance is effective for fiscal years, and interim periods within those years, beginning after December 15, 2013, which would be our fiscal year ended September 30, 2015. This guidance should be applied prospectively to all unrecognized tax benefits that exist at the effective date. Retrospective application is permitted. The adoption of this guidance is not expected to have a significant impact on our consolidated financial position or results of operations.

- changed (2015-02-04):
[0001564590-15-000466:note_history:13]
In April 2014, the FASB issued an amendment to the financial reporting of discontinued operations.  The amendments in this update changed the criteria for reporting discontinued operations while enhancing disclosures in this area. It also addresses sources of confusion and inconsistent application related to the financial reporting of discontinued operations guidance in U.S. GAAP.  Under the new guidance, only disposals representing a strategic shift in operations that have a major effect on the organization’s operations and financial results should be presented as discontinued operations. Examples include a disposal of a major geographic area, a major line of business, or a major equity method investment.  In addition, the new guidance requires expanded disclosures about discontinued operations that will provide financial statement users with more information about the assets, liabilities, income, and expenses of discontinued operations.  The new guidance also requires disclosure of the pre-tax income attributable to a disposal of a significant part of an organization that does not qualify for discontinued operations reporting. This disclosure will provide users with information about the ongoing trends in a reporting organization’s results from continuing operations. The amendments in this update are effective in the first quarter of 2015, which would be our fiscal year end September 30, 2016.  Early adoption is permitted for disposals that have not been previously reported as discontinued operations.
  (was, 2014-08-06, similarity 0.9983):
[0001564590-14-003175:note_history:13]
In April 2014, the FASB issued an amendment to the financial reporting of discontinued operations.  The amendments in this update change the criteria for reporting discontinued operations while enhancing disclosures in this area. It also addresses sources of confusion and inconsistent application related to financial reporting of discontinued operations guidance in U.S. GAAP.  Under the new guidance, only disposals representing a strategic shift in operations that have a major effect on the organization’s operations and financial results should be presented as discontinued operations. Examples include a disposal of a major geographic area, a major line of business, or a major equity method investment.  In addition, the new guidance requires expanded disclosures about discontinued operations that will provide financial statement users with more information about the assets, liabilities, income, and expenses of discontinued operations.  The new guidance also requires disclosure of the pre-tax income attributable to a disposal of a significant part of an organization that does not qualify for discontinued operations reporting. This disclosure will provide users with information about the ongoing trends in a reporting organization’s results from continuing operations. The amendments in this update are effective in the first quarter of 2015, which would be our fiscal year end September 30, 2016.  Early adoption is permitted for disposals that have not been previously reported as discontinued operations.

- added (2015-02-04):
[0001564590-15-000466:note_history:14]
In June 2014, the FASB issued an amendment to the topic regarding share-based payments and instances where terms of an award provide that a performance target can be achieved after the requisite service period.  This guidance has been provided to resolve the diversity in practice concerning employee share-based payments that contain performance targets that could be achieved after the requisite service period. The updated guidance requires that a performance target that affects vesting and that can be achieved after the requisite service period be treated as a performance condition. Compensation cost should be recognized in the period in which it becomes probable that the performance target will be achieved and is attributable to the periods for which service has been rendered. If the performance target becomes probable of being achieved before the end of the service period, the remaining unrecognized compensation cost for which requisite service has not yet been rendered is recognized prospectively over the remaining service period. The total amount of compensation cost recognized during and after the service period should reflect the number of awards that are expected to vest and should be adjusted to reflect those awards that ultimately vest. The updated guidance is effective for annual and interim periods beginning after December 15, 2015, with early adoption permitted. The adoption of this guidance is not expected to have a material impact on our consolidated financial position or results of operations.

- added (2015-02-04):
[0001564590-15-000466:note_history:15]
Discontinued operations

- added (2015-02-04):
[0001564590-15-000466:note_history:16]
In January 2014, we sold our wholly owned subsidiary Transdyn Inc. (Transdyn).  For the quarter ended December 31, 2013, we have presented the results of these operations as income from discontinued operations, net of tax.  See Note I.

- removed (2015-02-04):
[0001564590-14-003175:note_history:17]
We develop, design, manufacture and service custom engineered-to-order equipment and systems for the management and control of electrical energy. Headquartered in Houston, Texas, we serve the transportation, energy, industrial and utility industries.

- removed (2015-02-04):
[0001564590-14-003175:note_history:18]
As discussed in Note I, on January 15, 2014, we sold our wholly-owned subsidiary Transdyn Inc. (Transdyn).  We reclassified the assets and liabilities of Transdyn as held for sale within the accompanying condensed consolidated balance sheet as of September 30, 2013 and presented the results of these operations as income from discontinued operations, net of tax, for each of the accompanying condensed consolidated statements of operations. While this sale did not result in a material disposition of assets or material reduction to income before income taxes relative to Powell’s consolidated financial statements, the revenues, gross profit, income before income taxes and assets of Transdyn comprised a significant majority of those respective amounts previously reported in our Process Control Systems business segment. As we previously only reported two business segments, Electrical Power Products and Process Control Systems, we have removed the presentation of segments in our Notes to Condensed Consolidated Financial Statements.

- removed (2015-02-04):
[0001564590-14-003175:note_history:19]
In March 2013, the FASB issued accounting guidance to resolve the diversity in practice for accounting for the release of the cumulative translation adjustment into net income when a parent either sells a part or all of its investment in a foreign entity or no longer holds a controlling financial interest in a subsidiary or group of assets that is a nonprofit activity or a business (other than a sale of real estate or conveyance of oil and gas mineral rights) within a foreign entity. This guidance is effective prospectively for fiscal years (and interim reporting periods within those years) beginning after December 15, 2013, which would be our fiscal year ending September 30, 2015. We do not expect this guidance to have a material impact on our consolidated financial position or results of operations.


## us-gaap:LongTermDebtTextBlock (debt) — matched_by: tag_name, score: 1.0

- added (2015-02-04):
[0001564590-15-000466:note_history:20]
|  | December 31, 2014 |  |  | September 30, 2014 |  |
| Industrial development revenue bonds | $ | 2,800 |  |  | $ | 3,200 |  |
| Less current portion |  | (400 | ) |  |  | (400 | ) |
| Total long-term debt and capital lease obligations | $ | 2,400 |  |  | $ | 2,800 |  |

- changed (2015-02-04):
[0001564590-15-000466:note_history:21]
U.S. Revolver
  (was, 2014-08-06, similarity 0.9167):
[0001564590-14-003175:note_history:21]
US Revolver

- added (2015-02-04):
[0001564590-15-000466:note_history:22]
In December 2013, we amended and restated our existing credit agreement (the Amended Credit Agreement) with a major domestic bank.  In December 2014, we entered into the Second Amendment of the Amended Credit Agreement (the Second Amendment).  The Second Amendment provides for the expansion of our Canadian manufacturing facility and allows for the repurchase of our common stock pursuant to a share repurchase program announced in December 2014. The Amended Credit Agreement provides for a $75.0 million revolving credit facility (U.S. Revolver). Obligations are collateralized by the stock of certain of our subsidiaries.

- changed (2015-02-04):
[0001564590-15-000466:note_history:23]
The U.S. Revolver provides for the issuance of letters of credit which reduce the amounts that may be borrowed under this revolver. The amount available under the U.S. Revolver was reduced by $18.3 million for our outstanding letters of credit at December 31, 2014.
  (was, 2014-08-06, similarity 0.9764):
[0001564590-14-003175:note_history:23]
The U.S. Revolver provides for the issuance of letters of credit which reduce the amounts that may be borrowed under this revolver. The amount available under the U.S. Revolver was reduced by $21.1 million for our outstanding letters of credit at June 30, 2014.

- changed (2015-02-04):
[0001564590-15-000466:note_history:24]
There were no borrowings outstanding under the U.S. Revolver as of December 31, 2014. Amounts available under the U.S. Revolver were $56.7 million at December 31, 2014. The U.S. Revolver expires on December 31, 2018.
  (was, 2014-08-06, similarity 0.9476):
[0001564590-14-003175:note_history:24]
There were no borrowings outstanding under the U.S. Revolver as of June 30, 2014. Amounts available under the U.S. Revolver were $53.9 million at June 30, 2014. The U.S. Revolver expires on December 31, 2018.

- changed (2015-02-04):
[0001564590-15-000466:note_history:25]
The Amended Credit Agreement is collateralized by a pledge of 100% of the voting capital stock of each of our domestic subsidiaries and 66% of the voting capital stock of each non-domestic subsidiary, excluding Powell Canada. The Amended Credit Agreement provides for customary events of default and carries cross-default provisions with other existing debt agreements. If an event of default (as defined in the Amended Credit Agreement) occurs and is continuing, on the terms and subject to the conditions set forth in the Amended Credit Agreement, amounts outstanding under the Amended Credit Agreement may be accelerated and may become immediately due and payable. As of December 31, 2014, we were in compliance with all of the financial covenants of the Amended Credit Agreement.
  (was, 2014-08-06, similarity 0.9922):
[0001564590-14-003175:note_history:25]
The Amended Credit Agreement is collateralized by a pledge of 100% of the voting capital stock of each of our domestic subsidiaries and 66% of the voting capital stock of each non-domestic subsidiary, excluding Powell Canada. The Amended Credit Agreement provides for customary events of default and carries cross-default provisions with other existing debt agreements. If an event of default (as defined in the Amended Credit Agreement) occurs and is continuing, on the terms and subject to the conditions set forth in the Amended Credit Agreement, amounts outstanding under the Amended Credit Agreement may be accelerated and may become immediately due and payable. As of June 30, 2014, we were in compliance with all of the financial covenants of the Amended Credit Agreement.

- changed (2015-02-04):
[0001564590-15-000466:note_history:26]
We have an $8.6 million credit agreement with a major international bank in Canada (the Canadian Revolver) to provide working capital support and letters of credit for our operations in Canada. The Canadian Revolver provides for the issuance of letters of credit which reduce the amounts that may be borrowed under this revolver.  There were no outstanding letters of credit under the Canadian Revolver at December 31, 2014.
  (was, 2014-08-06, similarity 0.8171):
[0001564590-14-003175:note_history:26]
We have a $9.4 million credit agreement with a major international bank in Canada (the Canadian Revolver) to provide working capital support and letters of credit for our operations in Canada. The Canadian Revolver provides for the issuance of letters of credit which reduce the amounts that may be borrowed under this revolver. The amount available under the Canadian Revolver was reduced by $0.1 million for an outstanding letter of credit at June 30, 2014.

- changed (2015-02-04):
[0001564590-15-000466:note_history:27]
There were no borrowings outstanding under the Canadian Revolver as of December 31, 2014 and amounts available under the Canadian Revolver were $8.6 million at December 31, 2014. The Canadian Revolver expires on February 28, 2015. The interest rate for amounts outstanding under the Canadian Revolver is a floating interest rate based upon either the Canadian Prime Rate, or the lender’s Bankers’ Acceptance Rate. Once the applicable rate is determined, a margin of 0.50% to 1.75%, as determined by our consolidated leverage ratio, is added to the applicable rate.
  (was, 2014-08-06, similarity 0.9662):
[0001564590-14-003175:note_history:27]
There were no borrowings outstanding under the Canadian Revolver as of June 30, 2014.  Amounts available under the Canadian Revolver were $9.3 million at June 30, 2014. The Canadian Revolver expires on February 28, 2015. The interest rate for amounts outstanding under the Canadian Revolver is a floating interest rate based upon either the Canadian Prime Rate, or the lender’s Bankers’ Acceptance Rate. Once the applicable rate is determined, a margin of 0.50% to 1.75%, as determined by our consolidated leverage ratio, is added to the applicable rate.

- changed (2015-02-04):
[0001564590-15-000466:note_history:28]
The Canadian Revolver is secured by the assets of our Canadian operations and provides for customary events of default and carries cross-default provisions with our existing debt agreements. If an event of default (as defined in the Canadian Revolver) occurs and is continuing, per the terms and subject to the conditions set forth in the Canadian Revolver, amounts outstanding under the Canadian Revolver may be accelerated and may become immediately due and payable. As of December 31, 2014, we were in compliance with all of the financial covenants of the Canadian Revolver.
  (was, 2014-08-06, similarity 0.9895):
[0001564590-14-003175:note_history:28]
The Canadian Revolver is secured by the assets of our Canadian operations and provides for customary events of default and carries cross-default provisions with our existing debt agreements. If an event of default (as defined in the Canadian Revolver) occurs and is continuing, per the terms and subject to the conditions set forth in the Canadian Revolver, amounts outstanding under the Canadian Revolver may be accelerated and may become immediately due and payable. As of June 30, 2014, we were in compliance with all of the financial covenants of the Canadian Revolver.

- changed (2015-02-04):
[0001564590-15-000466:note_history:29]
We borrowed $8.0 million in October 2001 through a loan agreement funded with proceeds from tax-exempt industrial development revenue bonds (Bonds). These Bonds were issued by the Illinois Development Finance Authority and were used for the completion of our Northlake, Illinois facility. Pursuant to the Bond issuance, a reimbursement agreement between us and a major domestic bank required an issuance by the bank of an irrevocable direct-pay letter of credit (Bond LC), as collateral, to the Bonds’ trustee to guarantee payment of the Bonds’ principal and interest when due. The Bond LC is subject to both early termination and extension provisions customary to such agreements, as well as various covenants, for which we were in compliance at December 31, 2014. While the Bonds mature in 2021, the reimbursement agreement requires annual redemptions of $0.4 million that commenced on October 25, 2002. A sinking fund is used for the redemption of the Bonds. At December 31, 2014, the balance in the restricted sinking fund was approximately $0.1 million and was recorded in cash and cash equivalents. The Bonds bear interest at a floating rate determined weekly by the Bonds’ remarketing agent, which was the underwriter for the Bonds and is an affiliate of the bank. This interest rate was 0.18% as of December 31, 2014.
  (was, 2014-08-06, similarity 0.9828):
[0001564590-14-003175:note_history:29]
We borrowed $8.0 million in October 2001 through a loan agreement funded with proceeds from tax-exempt industrial development revenue bonds (Bonds). These Bonds were issued by the Illinois Development Finance Authority and were used for the completion of our Northlake, Illinois facility. Pursuant to the Bond issuance, a reimbursement agreement between us and a major domestic bank required an issuance by the bank of an irrevocable direct-pay letter of credit (Bond LC), as collateral, to the Bonds’ trustee to guarantee payment of the Bonds’ principal and interest when due. The Bond LC is subject to both early termination and extension provisions customary to such agreements, as well as various covenants, for which we were in compliance at June 30, 2014. While the Bonds mature in 2021, the reimbursement agreement requires annual redemptions of $0.4 million that commenced on October 25, 2002. A sinking fund is used for the redemption of the Bonds. At June 30, 2014, the balance in the restricted sinking fund was approximately $0.3 million and was recorded in cash and cash equivalents. The Bonds bear interest at a floating rate determined weekly by the Bonds’ remarketing agent, which was the underwriter for the Bonds and is an affiliate of the bank. This interest rate was 0.25% as of June 30, 2014.

- removed (2015-02-04):
[0001564590-14-003175:note_history:30]
|  | June 30, |  |  | September 30, |  |
|  | 2014 |  |  | 2013 |  |
| Industrial development revenue bonds | $ | 3,200 |  |  | $ | 3,600 |  |
| Capital lease obligations |  | — |  |  |  | 16 |  |
| Subtotal long-term debt and capital lease obligations |  | 3,200 |  |  |  | 3,616 |  |
| Less current portion |  | (400 | ) |  |  | (416 | ) |
| Total long-term debt and capital lease obligations | $ | 2,800 |  |  | $ | 3,200 |  |

- removed (2015-02-04):
[0001564590-14-003175:note_history:31]
In fiscal year 2014, we amended and restated our existing credit agreement (Amended Credit Agreement) with a major domestic bank. We entered into this Amended Credit Agreement to, among other things, allow for the payment of dividends and to extend the expiration date of the facility. The Amended Credit Agreement provides for a $75.0 million revolving credit facility (U.S. Revolver). Obligations are collateralized by the stock of certain of our subsidiaries.


## us-gaap:ScheduleOfDebtInstrumentsTextBlock (debt) — matched_by: tag_name, score: 1.0

- added (2015-02-04):
[0001564590-15-000466:note_history:32]
|  | December 31, 2014 |  |  | September 30, 2014 |  |
| Industrial development revenue bonds | $ | 2,800 |  |  | $ | 3,200 |  |
| Less current portion |  | (400 | ) |  |  | (400 | ) |
| Total long-term debt and capital lease obligations | $ | 2,400 |  |  | $ | 2,800 |  |

- removed (2015-02-04):
[0001564590-14-003175:note_history:33]
|  | June 30, |  |  | September 30, |  |
|  | 2014 |  |  | 2013 |  |
| Industrial development revenue bonds | $ | 3,200 |  |  | $ | 3,600 |  |
| Capital lease obligations |  | — |  |  |  | 16 |  |
| Subtotal long-term debt and capital lease obligations |  | 3,200 |  |  |  | 3,616 |  |
| Less current portion |  | (400 | ) |  |  | (416 | ) |
| Total long-term debt and capital lease obligations | $ | 2,800 |  |  | $ | 3,200 |  |
