# POWL 8-K — 0001193125-15-031772 filed 2015-02-03

## item codes, every 8-K on or before 2015-02-04

- 2015-02-03 0001193125-15-031772 — 2.02, 8.01, 9.01
- 2014-12-18 0001193125-14-446513 — 8.01, 9.01
- 2014-12-03 0001193125-14-431745 — 2.02, 9.01
- 2014-11-05 0001193125-14-397955 — 8.01, 9.01
- 2014-09-26 0001193125-14-353741 — 7.01, 9.01
- 2014-08-05 0001193125-14-296001 — 2.02, 8.01, 9.01
- 2014-05-07 0001193125-14-187496 — 2.02, 8.01, 9.01
- 2014-03-03 0001193125-14-079843 — 5.02, 5.07
- 2014-02-05 0001193125-14-036633 — 2.02, 8.01, 9.01
- 2014-01-17 0001193125-14-014351 — 1.01, 8.01, 9.01
- 2014-01-06 0001193125-14-002795 — 1.01, 2.03
- 2013-12-06 0001564590-13-001411 — 2.02, 9.01
- 2013-12-05 0001564590-13-001406 — 5.02, 8.01, 9.01
- 2013-11-07 0001193125-13-432950 — 8.01, 9.01
- 2013-08-07 0001193125-13-324337 — 2.02, 9.01
- 2013-05-08 0001193125-13-206800 — 2.02, 9.01
- 2013-02-22 0001193125-13-070971 — 5.02, 5.07
- 2013-02-06 0001193125-13-040556 — 2.02, 9.01
- 2012-12-18 0001193125-12-506417 — 5.02, 9.01
- 2012-12-05 0001193125-12-491749 — 2.02, 9.01
- 2012-10-12 0001193125-12-421889 — 3.03, 5.02, 5.03, 9.01
- 2012-08-09 0001193125-12-344617 — 5.02, 8.01, 9.01
- 2012-08-08 0001193125-12-343630 — 2.02, 9.01
- 2012-05-09 0001193125-12-221356 — 2.02, 9.01
- 2012-02-08 0001193125-12-046560 — 2.02, 9.01
- 2011-12-08 0001193125-11-334810 — 2.02, 9.01
- 2011-11-08 0000950123-11-096524 — 2.02, 2.06, 4.02, 9.01
- 2011-10-14 0000950123-11-090124 — 5.02
- 2011-10-06 0000950123-11-088969 — 5.02
- 2011-09-19 0000950123-11-085224 — 5.02, 9.01
- 2011-09-15 0000950123-11-084806 — 5.02, 9.01
- 2011-08-04 0000950123-11-072788 — 2.02, 9.01
- 2011-07-22 0000950123-11-067402 — 5.07
- 2011-05-24 0000950123-11-053550 — 1.01, 2.03, 9.01
- 2011-05-04 0000950123-11-044561 — 2.02, 9.01
- 2011-02-02 0000950123-11-008188 — 2.02, 9.01
- 2010-12-08 0000950123-10-111987 — 2.02, 9.01
- 2010-08-05 0000950123-10-073114 — 2.02, 9.01
- 2010-05-18 0000950123-10-050900 — 5.02
- 2010-05-05 0000950123-10-044499 — 2.02, 9.01
- 2010-02-03 0000950123-10-008278 — 2.02, 9.01
- 2009-12-21 0000950123-09-072269 — 1.01, 2.01, 2.03, 8.01, 9.01
- 2009-12-09 0000950123-09-069525 — 2.02, 9.01
- 2009-10-27 0000950123-09-053501 — 1.01, 8.01, 9.01
- 2009-08-04 0000950123-09-029476 — 2.02, 9.01
- 2009-05-06 0000950129-09-001498 — 2.02, 9.01
- 2009-03-05 0000950129-09-000749 — 1.01, 9.01
- 2009-02-10 0000950129-09-000349 — 2.02, 9.01
- 2008-12-10 0000950134-08-021934 — 2.02, 9.01
- 2008-08-06 0000950129-08-004267 — 2.02, 9.01
- 2008-07-24 0000950129-08-004063 — 1.01, 5.02, 8.01, 9.01
- 2008-06-16 0000950129-08-003500 — 9.01 — amendment of 0000950134-06-015374
- 2008-06-05 0000950129-08-003378 — 5.02, 9.01
- 2008-05-08 0000950129-08-002843 — 2.02, 9.01
- 2008-02-06 0000950129-08-000533 — 2.02, 9.01
- 2007-12-19 0000950129-07-006277 — 1.01, 2.03, 9.01
- 2007-12-06 0000950129-07-006003 — 2.02, 9.01
- 2007-08-21 0000950129-07-004181 — 2.02, 9.01
- 2007-05-31 0000950129-07-002810 — 2.02, 9.01
- 2007-05-21 0000950129-07-002668 — 2.02, 3.01, 4.02, 9.01
- 2007-04-16 0000950129-07-002002 — 2.02, 4.02, 9.01
- 2007-03-01 0000950129-07-001104 — 5.02, 8.01, 9.01
- 2007-02-08 0000950129-07-000451 — 2.02, 9.01
- 2006-12-08 0000950129-06-010041 — 2.02, 9.01
- 2006-09-08 0000950129-06-008379 — 2.02, 9.01
- 2006-08-09 0000950134-06-015374 — 1.01, 2.01, 8.01, 9.01
- 2006-06-08 0000950129-06-006127 — 2.02, 9.01
- 2006-03-09 0000950129-06-002455 — 2.02, 9.01
- 2005-12-16 0000950129-05-012031 — 2.02, 5.03, 9.01
- 2005-09-13 0000950129-05-009181 — 2.01, 9.01 — amendment of 0000950129-05-006889
- 2005-09-12 0000950129-05-009151 — 2.02, 9.01
- 2005-07-06 0000950129-05-006889 — 1.01, 1.02, 2.01, 2.03, 9.01
- 2005-06-10 0000950129-05-006128 — 2.02, 9.01
- 2005-04-20 0000080420-05-000031 — 5.02
- 2005-03-11 0000080420-05-000024 — 9.01
- 2005-02-25 0000080420-05-000018 — 7.01, 9.01
- 2005-01-21 0000080420-05-000009 — 7.01, 9.01
- 2004-12-17 0000080420-04-000049 — 2.02, 9.01
- 2004-11-01 0000080420-04-000045 — 8.01, 9.01
- 2004-10-08 0001169232-04-005133 — 2.05
- 2004-09-14 0000080420-04-000037 — 5.02
- 2004-09-02 0000080420-04-000030 — 2.02, 9.01
- 2004-06-08 0000080420-04-000021 — 7
- 2004-05-13 0000080420-04-000019 — 4
- 2004-02-27 0000080420-04-000013 — 7
- 2003-12-16 0000950129-03-006136 — 12, 7
- 2003-08-29 0000950129-03-004531 — 12, 7
- 2003-06-03 0000950129-03-003035 — 7, 9
- 2003-05-15 0000950129-03-002812 — 7, 9
- 2002-05-29 0000950129-02-002795 — 4
- 2000-12-21 0000950129-00-006093 — 5, 7
- 1998-09-04 0000950129-98-003802 — 5
- 1996-08-09 0000950129-96-001705 — 2, 7

## late-filing notifications on or before 2015-02-04

- 2007-05-11 0000950129-07-002494 — NT 10-Q, for the period ended 2007-03-31
- 2005-01-18 0000080420-05-000004 — NT 10-K, for the period ended 2004-10-31

## item 2.02 — earnings release, exhibit 99.1

[0001193125-15-031772:8k_2_02:1]
EX-99.1
2
d865162dex991.htm
EX-99.1

[0001193125-15-031772:8k_2_02:2]
EX-99.1

[0001193125-15-031772:8k_2_02:3]
Exhibit 99.1

[0001193125-15-031772:8k_2_02:4]
|  |  | Press Release |

[0001193125-15-031772:8k_2_02:5]
|  |  |  |  | Contacts: |  | Don R. Madison, CFO |
| FOR IMMEDIATE RELEASE |  |  |  |  |  | Powell Industries, Inc. |
|  |  |  |  |  | 713-947-4422 |

[0001193125-15-031772:8k_2_02:6]
POWELL INDUSTRIES ANNOUNCES FISCAL 2015

[0001193125-15-031772:8k_2_02:7]
FIRST QUARTER RESULTS

[0001193125-15-031772:8k_2_02:8]
HOUSTON —
FEBRUARY 3, 2015 — Powell Industries, Inc. (NASDAQ: POWL) (“Powell”), a leading supplier of custom engineered solutions for the management, distribution and control of electrical energy, today announced results for the fiscal 2015
first quarter ended December 31, 2014.

[0001193125-15-031772:8k_2_02:9]
Revenues for the first quarter of fiscal 2015 were $152.6 million compared to revenues of
$171.9 million for the first quarter of fiscal 2014. The Company reported a net loss from continuing operations for the first quarter of fiscal 2015 of $0.2 million, or $0.02 per diluted share, compared to income from continuing operations of $7.3
million, or $0.60 per diluted share, in the first quarter of fiscal 2014. The first quarter loss was primarily attributable to incremental costs and inefficiencies incurred to maintain customer project schedule commitments at its Canadian
operations.

[0001193125-15-031772:8k_2_02:10]
Michael A. Lucas, President and Chief Executive Officer, stated, “We were disappointed with the financial results for
the first quarter of fiscal 2015 as the costs to hold customer schedules were higher than we had previously anticipated. Holding customer commitments and delivering quality solutions are critical in building long-term customer relationships, and we
view the additional cost associated with producing the projects in our backlog as a necessity of high importance. We continue to work to improve project efficiencies throughout the organization.

[0001193125-15-031772:8k_2_02:11]
“Our core oil and gas markets have experienced rapidly changing industry conditions as oil prices have declined in recent months. Our
customers will respond to these changing

[0001193125-15-031772:8k_2_02:12]
conditions by re-examining the timing and returns of future projects, which will likely impact our bookings later this year. Projects already in our backlog will move forward. We have weathered
market cycles in the past and understand the factors that drive customer capital investment decisions.”

[0001193125-15-031772:8k_2_02:13]
New orders placed during the
first quarter of fiscal 2015 totaled $154 million compared to $199 million in the fourth quarter of fiscal 2014 and compared to $192 million in the first quarter of fiscal 2014. The Company’s backlog for continuing operations as of
December 31, 2014 was $506 million compared to $507 million as of September 30, 2014 and compared to $455 million at the end of last year’s first quarter.

[0001193125-15-031772:8k_2_02:14]
OUTLOOK

[0001193125-15-031772:8k_2_02:15]
The following statements are
based on current expectations of the Company. These statements are forward-looking, and actual results may differ materially as further elaborated in the last paragraph below.

[0001193125-15-031772:8k_2_02:16]
Based on its backlog and current business conditions, Powell Industries has reduced full year fiscal 2015 revenues to range between $625
million and $675 million from its previous guidance of $650 million to $710 million and has reduced fiscal year 2015 earnings to range between $1.25 and $1.75 per diluted share from its previous guidance of $1.75 to $2.30 per diluted share.

[0001193125-15-031772:8k_2_02:17]
CONFERENCE CALL

[0001193125-15-031772:8k_2_02:18]
Powell Industries has
scheduled a conference call for Wednesday, February 4, 2015 at 11:00 a.m. Eastern time. To participate in the conference call, dial 412-902-0030 at least 10 minutes before the call begins and ask for the Powell Industries conference call. A
replay of the call will be available approximately two hours after the live broadcast ends and will be accessible until February 11, 2015. To access the replay, dial 201-612-7415 using a passcode of 13598967#.

[0001193125-15-031772:8k_2_02:19]
Investors, analysts and the general public will also have the opportunity to listen to the conference call over the Internet by visiting
powellind.com. To listen to the live call on the web, please visit the website at least fifteen minutes before the call begins to register, download and install any necessary audio software. For those who cannot listen to the live webcast, an
archive will be available shortly after the call and will remain available for approximately 90 days at powellind.com.

[0001193125-15-031772:8k_2_02:20]
Powell Industries, Inc., headquartered in Houston, engineers packaged solutions and systems for the management,
distribution and control of electrical energy. Powell markets include large industrial customers such as utilities, oil and gas producers, refineries, petrochemical plants, pulp and paper producers, mining operations and commuter
railways. For more information, please visit powellind.com.

[0001193125-15-031772:8k_2_02:21]
POWELL INDUSTRIES, INC. & SUBSIDIARIES

[0001193125-15-031772:8k_2_02:22]
CONDENSED CONSOLIDATED STATEMENT OF OPERATIONS

[0001193125-15-031772:8k_2_02:23]
|  |  | Three Months EndedDecember 31, |  |
|  |  | 2014 |  |  | 2013 |  |
| (In thousands, except per share data) |  | (Unaudited) |  |
| Revenues |  | $ | 152,601 |  |  | $ | 171,872 |  |
| Cost of goods sold |  |  | 131,532 |  |  |  | 136,714 |  |
| Gross profit |  |  | 21,069 |  |  |  | 35,158 |  |
| Selling, general and administrative expenses |  |  | 20,816 |  |  |  | 21,632 |  |
| Research and development expenses |  |  | 1,840 |  |  |  | 1,839 |  |
| Amortization of intangible assets |  |  | 118 |  |  |  | 416 |  |
| Operating income (loss) |  |  | (1,705 | ) |  |  | 11,271 |  |
| Other income |  |  | (507 | ) |  |  | — |  |
| Interest expense |  |  | 33 |  |  |  | 69 |  |
| Interest income |  |  | (1 | ) |  |  | (3 | ) |
| Income (loss) before income taxes |  |  | (1,230 | ) |  |  | 11,205 |  |
| Income tax provision (benefit) |  |  | (991 | ) |  |  | 3,937 |  |
| Income (loss) from continuing operations |  |  | (239 | ) |  |  | 7,268 |  |
| Income from discontinued operations, net of tax of zero and $502 |  |  | — |  |  |  | 987 |  |
| Net income (loss) |  | $ | (239 | ) |  | $ | 8,255 |  |
| Earnings (loss) per share: |  |  |  |  |  |  |  |  |
| Continuing operations |  | $ | (0.02 | ) |  | $ | 0.61 |  |
| Discontinued operations |  |  | — |  |  |  | 0.08 |  |
| Basic earnings (loss) per share |  | $ | (0.02 | ) |  | $ | 0.69 |  |
| Continuing operations |  | $ | (0.02 | ) |  | $ | 0.60 |  |
| Discontinued operations |  |  | — |  |  |  | 0.08 |  |
| Diluted earnings (loss) per share |  | $ | (0.02 | ) |  | $ | 0.68 |  |
| Weighted average shares: |  |  |  |  |  |  |  |  |
| Basic |  |  | 12,041 |  |  |  | 11,994 |  |
| Diluted |  |  | 12,041 |  |  |  | 12,054 |  |
| SELECTED FINANCIAL DATA: |  |  |  |  |  |  |  |  |
| Depreciation and Amortization |  | $ | 3,436 |  |  | $ | 2,978 |  |
| Capital Expenditures |  | $ | 18,962 |  |  | $ | 5,764 |  |

[0001193125-15-031772:8k_2_02:24]
POWELL INDUSTRIES, INC. & SUBSIDIARIES

[0001193125-15-031772:8k_2_02:25]
CONDENSED CONSOLIDATED BALANCE SHEETS

[0001193125-15-031772:8k_2_02:26]
|  |  | December 31,2014 |  |  | September 30,2014 |  |
| (In thousands) |  | (Unaudited) |  |  |  |  |
| Assets: |  |  |  |  |  |  |  |  |
| Current assets |  | $ | 326,817 |  |  | $ | 357,327 |  |
| Property, plant and equipment (net) |  |  | 165,426 |  |  |  | 156,896 |  |
| Long-term assets |  |  | 28,645 |  |  |  | 27,220 |  |
| Total assets |  | $ | 520,888 |  |  | $ | 541,443 |  |
| Liabilities & equity: |  |  |  |  |  |  |  |  |
| Current liabilities |  | $ | 144,243 |  |  | $ | 158,099 |  |
| Long-term debt and capital lease obligations, net of current maturities |  |  | 2,400 |  |  |  | 2,800 |  |
| Deferred and other long-term liabilities |  |  | 10,090 |  |  |  | 9,447 |  |
| Stockholders’ equity |  |  | 364,155 |  |  |  | 371,097 |  |
| Total liabilities and stockholders’ equity |  | $ | 520,888 |  |  | $ | 541,443 |  |

[0001193125-15-031772:8k_2_02:27]
# # #
