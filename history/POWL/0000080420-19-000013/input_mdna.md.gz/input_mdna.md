# POWL MD&A — 0000080420-19-000013


## mdna

[0000080420-19-000013:mdna:1]
[same as prior period, unchanged from 0000080420-19-000005:mdna:1]

[0000080420-19-000013:mdna:2]
[same as prior period, unchanged from 0000080420-19-000005:mdna:2]

[0000080420-19-000013:mdna:3]
[same as prior period, unchanged from 0000080420-19-000005:mdna:3]

[0000080420-19-000013:mdna:4]
[same as prior period, unchanged from 0000080420-19-000005:mdna:4]

[0000080420-19-000013:mdna:5]
The markets in which we participate are capital intensive and cyclical in nature. Cyclicality is predominantly driven by customer demand, global economic conditions and anticipated environmental, safety or regulatory changes which affect the manner in which our customers proceed with capital investments. Our customers analyze various factors including the demand and price for oil, gas and electrical energy, the overall economic and financial environment, governmental budgets, regulatory actions and environmental concerns. These factors influence the release of new capital projects by our customers, which are traditionally awarded in competitive bid situations. Scheduling of projects is matched to the customer requirements and projects typically take a number of months to produce. Schedules may change during the course of any particular project and our operating results can therefore be impacted by factors outside of our control.

[0000080420-19-000013:mdna:6]
Due to the significant decline in oil and gas prices from peak 2014 levels, many of our customers reduced their capital budgets and cut costs, and in certain instances have delayed or canceled projects that we were pursuing. This decline in projects negatively impacted our results in Fiscal 2018. However, customers have begun to invest in projects in our key oil and gas and petrochemical markets and this shift has had a favorable impact on our orders and backlog over recent quarters, resulting in increased revenues in Fiscal 2019.

[0000080420-19-000013:mdna:7]
[same as prior period, unchanged from 0000080420-19-000005:mdna:8]

[0000080420-19-000013:mdna:8]
Quarter Ended March 31, 2019 Compared to the Quarter Ended March 31, 2018 (Unaudited)

[0000080420-19-000013:mdna:9]
[same as prior period, unchanged from 0000080420-19-000005:mdna:10]

[0000080420-19-000013:mdna:10]
Revenues increased by 22%, or $22.2 million, to $123.7 million in the second quarter of Fiscal 2019, compared to the second quarter of Fiscal 2018, primarily due to an increase in orders over the past few quarters in our domestic operations from improved market conditions, primarily in our oil and gas markets. Domestic revenues increased by 36%, or $25.8 million, to $97.3 million in the second quarter of Fiscal 2019, compared to the second quarter of Fiscal 2018. International revenues decreased by 12%, or $3.6 million, to $26.4 million in the second quarter of Fiscal 2019, compared to the second quarter of Fiscal 2018. Our international revenue includes both revenue generated from our international facilities, as well as export revenues from our domestic facilities.

[0000080420-19-000013:mdna:11]
Revenues from commercial and industrial projects increased by 30%, or $21.0 million, to $91.6 million in the second quarter of Fiscal 2019, compared to the second quarter of Fiscal 2018, primarily driven by the continued strengthening of the core oil and gas and petrochemical end markets. Revenues from public and private utilities decreased by 11%, or $2.5 million, to $20.4 million in the second quarter of Fiscal 2019, compared to the second quarter of Fiscal 2018 as the business nears completion of select large utility projects in the backlog.  Revenues from municipal and transit projects increased by 46%, or $3.7 million, to $11.7 million in the second quarter of Fiscal 2019, compared to the second quarter of Fiscal 2018, primarily impacted by project timing and product mix as this market remains stable versus the prior year.

[0000080420-19-000013:mdna:12]
Gross profit for the second quarter of Fiscal 2019 increased by 62%, or $7.7 million, to $20.1 million, compared to the second quarter of Fiscal 2018. Gross profit as a percentage of revenues increased to 16% in the second quarter of Fiscal 2019, compared to 12% in the second quarter of Fiscal 2018. Gross profit and margins increased due to improved market conditions and efficiencies resulting from increased volume in our domestic manufacturing facilities.

[0000080420-19-000013:mdna:13]
[same as prior period, unchanged from 0000080420-19-000005:mdna:13]

[0000080420-19-000013:mdna:14]
Selling, general and administrative expenses increased by 7%, or $1.1 million, to $17.2 million during the second quarter of Fiscal 2019, compared to $16.1 million in the second quarter of Fiscal 2018. Selling, general and administrative expenses, as a percentage of revenues, decreased to 14% during the second quarter of Fiscal 2019, compared to 16% during the second quarter of Fiscal 2018, primarily due to the increase in revenues and our continued focus on our cost structure.

[0000080420-19-000013:mdna:15]
Income Tax Expense/Benefit

[0000080420-19-000013:mdna:16]
We recorded income tax expense of $0.4 million in the second quarter of Fiscal 2019, compared to an income tax benefit of $1.8 million in the second quarter of Fiscal 2018. The effective tax rate for the second quarter of Fiscal 2019 was 30%, compared to an effective tax rate of 35% in the second quarter of Fiscal 2018. On December 22, 2017, the Tax Cuts and Jobs Act was signed into law, which lowered the corporate tax rate from 35% to 21% effective January 1, 2018. As a result, the U.S. federal statutory rate for Fiscal 2019 is 21%, compared to the blended statutory rate of 24.5% effective for Fiscal 2018. For the three months ended March 31, 2019 and 2018, the effective tax rate was negatively impacted by foreign tax losses that are reserved with a valuation allowance. The change in the effective tax rate for the three months ended March 31, 2019 compared to the same period of the prior year primarily relates to the relative amounts of income (loss) recognized in various jurisdictions.

[0000080420-19-000013:mdna:17]
Net Income/Loss

[0000080420-19-000013:mdna:18]
In the second quarter of Fiscal 2019, we recorded net income of $1.0 million, or $0.08 per diluted share, compared to a net loss of $3.3 million, or $0.29 per diluted share, in the second quarter of Fiscal 2018. This improvement in operating results over the prior year was primarily due to improved market conditions and efficiencies resulting from increased volume in our domestic manufacturing facilities.

[0000080420-19-000013:mdna:19]
[same as prior period, unchanged from 0000080420-19-000005:mdna:21]

[0000080420-19-000013:mdna:20]
Our backlog includes various projects that can take a number of months to produce. The order backlog at March 31, 2019 increased to $397.2 million, compared to $322.0 million at December 31, 2018, primarily due to increased demand from our customers in our core oil and gas and petrochemical markets. New orders placed during the second quarter of Fiscal 2019 increased to $196.7 million, compared to $141.5 million in the second quarter of Fiscal 2018, primarily due to increased demand from our customers in our core oil and gas and petrochemical markets.

[0000080420-19-000013:mdna:21]
Six Months Ended March 31, 2019 Compared to the Six Months Ended March 31, 2018 (Unaudited)

[0000080420-19-000013:mdna:22]
Revenue and Gross Profit

[0000080420-19-000013:mdna:23]
Revenues increased  by 22%, or $41.4 million, to $233.1 million for the six months ended March 31, 2019, compared to the six months ended March 31, 2018, primarily due to an increase in orders over the past few quarters in our domestic operations from improved market conditions, primarily in our oil and gas markets. Domestic revenues increased by 42%, or $55.6 million, to $187.2 million for the six months ended March 31, 2019, compared to the six months ended March 31, 2018. International revenues decreased by 24%, or $14.2 million, to $45.9 million for the six months ended March 31, 2019, compared to the six months ended March 31, 2018, primarily due to a decrease in export projects from our domestic facilities. Our international revenue includes both revenue generated from our international facilities, as well as export revenues from our domestic facilities.

[0000080420-19-000013:mdna:24]
Revenues from commercial and industrial projects increased by 33%, or $43.4 million, to $174.8 million for the six months ended March 31, 2019, compared to the six months ended March 31, 2018, driven by the strength across the core oil and gas and petrochemical end markets.  Revenues from public and private utilities decreased by 18%, or $8.5 million, to $39.6 million for the six months ended March 31, 2019, compared to the six months ended March 31, 2018, as the business nears completion of select large utility projects in the backlog. Revenues from municipal and transit projects increased by 53%, or $6.5 million, to $18.7 million for the six months ended March 31, 2019, compared to the six months ended March 31, 2018, primarily impacted by the project timing and product mix of projects at or near completion for some of our key municipal customers.

[0000080420-19-000013:mdna:25]
Gross profit for the six months ended March 31, 2019 increased by 51%, or $11.7 million, to $34.7 million, compared to the six months ended March 31, 2018. Gross profit as a percentage of revenues increased to 15% for the six months ended March 31, 2019, compared to 12% for the six months ended March 31, 2018.  Gross profit increased due to improved market conditions and efficiencies resulting from increased volume in our domestic manufacturing facilities.

[0000080420-19-000013:mdna:26]
Selling, General and Administrative Expenses

[0000080420-19-000013:mdna:27]
Selling, general and administrative expenses increased by 3%, or $0.8 million, to $33.1 million for the six months ended March 31, 2019, compared to the six months ended March 31, 2018. Selling, general and administrative expenses, as a percentage of revenues, decreased to 14% during the six months ended March 31, 2019, compared to 17% during the six months ended March 31, 2018, primarily due to the increase in revenues and our continued focus on our cost structure.

[0000080420-19-000013:mdna:28]
Income Tax Expense/Benefit

[0000080420-19-000013:mdna:29]
We recorded income tax expense of $0.2 million for the six months ended March 31, 2019 compared to an income tax benefit of $2.8 million for the six months ended March 31, 2018.  The effective tax rate for the six months ended March 31, 2019 was a negative 11% compared to an effective tax rate of 24% for the six months ended March 31, 2018.  The effective tax rate for the six months ended March 31, 2019 and 2018 was negatively impacted by foreign tax losses that are reserved with a valuation allowance. The income tax benefit for the six months ended March 31, 2018 was also negatively impacted from a deferred tax expense of $0.8 million due to the re-measurement of our U.S. deferred tax assets. The change in the effective tax rate for the six months ended March 31, 2019 compared to the same period of the prior year primarily relates to the relative amounts of income (loss) recognized in various jurisdictions.

[0000080420-19-000013:mdna:30]
[same as prior period, unchanged from 0000080420-19-000005:mdna:19]

[0000080420-19-000013:mdna:31]
For the six months ended March 31, 2019, we recorded a net loss of $1.7 million, or $0.15 per diluted share, compared to a net loss of $9.0 million, or $0.78 per diluted share, for the six months ended March 31, 2018.  The improvement in our operating results over the prior year was primarily due to improved market conditions and efficiencies resulting from increased volume in our domestic manufacturing facilities.

[0000080420-19-000013:mdna:32]
Backlog

[0000080420-19-000013:mdna:33]
The order backlog at March 31, 2019 was $397.2 million, an increase from the $260.9 million at September 30, 2018, primarily due to increased demand from our customers in our core oil and gas and petrochemical markets. New orders increased during the six months ended March 31, 2019 to $369.1 million, compared to $241.4 million for the six months ended March 31, 2018, primarily due to improved market conditions.

[0000080420-19-000013:mdna:34]
[same as prior period, unchanged from 0000080420-19-000005:mdna:24]

[0000080420-19-000013:mdna:35]
The markets in which we participate are capital-intensive and cyclical in nature. Cyclicality is predominantly driven by customer demand, global economic conditions and anticipated environmental, safety or regulatory changes which affect the manner in which our customers proceed with capital investments. Our customers analyze various factors including the demand and price for oil, gas and electrical energy, the overall economic and financial environment, governmental budgets, regulatory actions and environmental concerns. These factors influence the release of new capital projects by our customers, which are traditionally awarded in competitive bid situations. Scheduling of projects is matched to customer requirements and projects typically take a number of months to produce. Schedules may change during the course of any particular project and our operating results can therefore be impacted by factors outside of our control.

[0000080420-19-000013:mdna:36]
A significant portion of our revenues have historically been from the oil, gas and petrochemical markets. Oil and gas commodity price levels have been unstable over the last several years and our customers delayed some of their major capital investment projects. Commodity prices have begun to improve and customers have begun to invest in projects in our key oil and gas and petrochemical markets and this shift in market sentiment has had a favorable impact on our orders and backlog over recent quarters.

[0000080420-19-000013:mdna:37]
Our operating results are impacted by factors such as the timing of new order awards, customer approval of final engineering and design specifications and delays in customer construction schedules, all of which contribute to short-term earnings variability and the timing of project execution. Our operating results also have been, and could continue to be, impacted by the timing and resolution of change orders, project close-out and resolution of potential contract claims and liquidated damages, all of which could improve or deteriorate gross margins during the period in which these items are resolved with our customers. These factors may result in periods of underutilization of our resources and facilities and negatively impact our ability to cover our fixed costs. We continue to assess our cost structure, operating performance and service offerings as the oil and gas and petrochemical markets remain challenging and uncertain. In Fiscal 2018, we experienced an increase in new orders which has continued into the first half of 2019. This improvement in orders has led to improvement in revenues and operating results that we anticipate will continue

[0000080420-19-000013:mdna:38]
for the remainder of Fiscal 2019. We continue to focus on maintaining our cash position, improving efficiencies in production and investing in future business opportunities.

[0000080420-19-000013:mdna:39]
[same as prior period, unchanged from 0000080420-19-000005:mdna:28]

[0000080420-19-000013:mdna:40]
[same as prior period, unchanged from 0000080420-19-000005:mdna:29]

[0000080420-19-000013:mdna:41]
As of March 31, 2019, current assets exceeded current liabilities by 2.4 times and our debt to total capitalization was 0.41%.

[0000080420-19-000013:mdna:42]
Cash, cash equivalents and short-term investments increased to $72.4 million at March 31, 2019, compared to $49.8 million at September 30, 2018. We also had restricted cash held in a pledged collateral account related to our amended credit agreement (U.S. Revolver) of $18.6 million at March 31, 2019 and $25.1 million at September 30, 2018. For further information regarding our U.S. Revolver, see Note E of Notes to Condensed Consolidated Financial Statements.

[0000080420-19-000013:mdna:43]
Our U.S. Revolver is a $75.0 million revolving credit facility in the U.S. As of March 31, 2019, there were no amounts borrowed under this facility. Total letters of credit outstanding under our U.S. Revolver, which reduce our availability, were $15.6 million at March 31, 2019 and $23.1 million at September 30, 2018. Currently, our U.S. Revolver can only be used for letters of credit until we meet certain financial ratios as described in Note E of Notes to Condensed Consolidated Financial Statements. As of March 31, 2019, there was $59.4 million available for the issuance of letters of credit under the U.S. Revolver. Total long-term debt, including current maturities, totaled $1.2 million at March 31, 2019, compared to $1.6 million at September 30, 2018.

[0000080420-19-000013:mdna:44]
Approximately $23.6 million of our cash and short-term investments at March 31, 2019 was held outside of the U.S. for international operations. It is our intention to indefinitely reinvest all current and future foreign earnings internationally in order to ensure sufficient working capital to support our international operations. In the event that we elect to repatriate some or all of the foreign earnings that were previously deemed to be indefinitely reinvested outside the U.S., under current tax laws we would incur additional tax expense upon such repatriation.

[0000080420-19-000013:mdna:45]
[same as prior period, unchanged from 0000080420-19-000005:mdna:34]

[0000080420-19-000013:mdna:46]
Cash provided by operating activities increased to $26.0 million during the six months ended March 31, 2019, compared to cash used in operating activities of $10.6 million during the same period in Fiscal 2018. This increase in operating cash flow for the six months ended March 31, 2019 was primarily due to the collection of accounts receivable and the receipt of a $6.6 million income tax refund in the first quarter of Fiscal 2019. Cash flow from operations is primarily influenced by project volume, the timing of milestone payments from our customers and the payment terms with our suppliers.

[0000080420-19-000013:mdna:47]
[same as prior period, unchanged from 0000080420-19-000005:mdna:36]

[0000080420-19-000013:mdna:48]
Net cash provided by investing activities during the six months ended March 31, 2019 totaled $5.3 million compared to cash provided by investing activities of $2.5 million during the same period in Fiscal 2018. This increase in cash provided by investing activities in the current period was primarily due to an increase in the net maturities of short-term investments and a decrease in property, plant and equipment expenditures compared to the same period in the prior year.

[0000080420-19-000013:mdna:49]
[same as prior period, unchanged from 0000080420-19-000005:mdna:38]

[0000080420-19-000013:mdna:50]
Net cash used in financing activities was $7.5 million and $6.8 million during the six months ended March 31, 2019 and 2018, respectively. These amounts primarily consisted of cash dividends of approximately $6.0 million in each period.

[0000080420-19-000013:mdna:51]
[same as prior period, unchanged from 0000080420-19-000005:mdna:40]

[0000080420-19-000013:mdna:52]
[same as prior period, unchanged from 0000080420-19-000005:mdna:41]

[0000080420-19-000013:mdna:53]
[same as prior period, unchanged from 0000080420-19-000005:mdna:42]

[0000080420-19-000013:mdna:54]
The discussion and analysis of our financial condition and results of operations are based on our condensed consolidated financial statements, which have been prepared in accordance with U.S. GAAP. The preparation of these condensed consolidated financial statements requires us to make estimates and assumptions that affect the reported amounts of assets and liabilities, disclosures of contingent assets and liabilities known to exist at the date of the condensed consolidated financial statements and the reported amounts of revenues and expenses during the reporting period. We evaluate our estimates on an ongoing basis, based on historical experience and on various other assumptions that are believed to be reasonable under the circumstances. There can be no assurance that actual results will not differ from those estimates.

[0000080420-19-000013:mdna:55]
[same as prior period, unchanged from 0000080420-19-000005:mdna:45]
