# POWL notes — 0000080420-19-000013


## us-gaap:AllowanceForCreditLossesOnFinancingReceivablesTableTextBlock

[0000080420-19-000013:notes:1]
[same as prior period, unchanged from 0000080420-19-000005:notes:1]

[0000080420-19-000013:notes:2]
|  | Three months ended March 31, |  | Six months ended March 31, |
|  | 2019 |  | 2018 |  | 2019 |  | 2018 |
| Balance at beginning of period | $ | 139 |  |  | $ | 158 |  |  | $ | 157 |  |  | $ | 179 |  |
| Bad debt expense | 74 |  |  | 112 |  |  | 101 |  |  | 92 |  |
| Uncollectible accounts written off, net of recoveries | (2 | ) |  | (7 | ) |  | (44 | ) |  | (8 | ) |
| Change due to foreign currency translation | 3 |  |  | 1 |  |  | — |  |  | 1 |  |
| Balance at end of period | $ | 214 |  |  | $ | 264 |  |  | $ | 214 |  |  | $ | 264 |  |


## us-gaap:BasisOfAccountingPolicyPolicyTextBlock

[0000080420-19-000013:notes:3]
[same as prior period, unchanged from 0000080420-19-000005:notes:3]

[0000080420-19-000013:notes:4]
[same as prior period, unchanged from 0000080420-19-000005:notes:4]

[0000080420-19-000013:notes:5]
[same as prior period, unchanged from 0000080420-19-000005:notes:5]

[0000080420-19-000013:notes:6]
[same as prior period, unchanged from 0000080420-19-000005:notes:6]

[0000080420-19-000013:notes:7]
[same as prior period, unchanged from 0000080420-19-000005:notes:7]


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0000080420-19-000013:notes:8]
COMMITMENTS AND CONTINGENCIES

[0000080420-19-000013:notes:9]
Letters of Credit, Surety Bonds and Bank Guarantees

[0000080420-19-000013:notes:10]
Certain customers require us to post letters of credit or surety bonds which assure that we will perform under the terms of our contract. In the event of default, the counterparty may demand payment from the bank under a letter of credit or performance by the surety under a bond. To date, there have been no significant expenses related to either letters of credit or surety bonds for the periods reported. We were contingently liable for letters of credit of $15.6 million as of March 31, 2019. We also had surety bonds totaling $140.7 million that were outstanding, with additional bonding capacity of $609.3 million available, at March 31, 2019.

[0000080420-19-000013:notes:11]
Additionally, we have a $6.5 million facility agreement (Facility Agreement) between Powell (UK) Limited and a large international bank. This Facility Agreement provides Powell (UK) Limited the ability to enter into bank guarantees as well as forward exchange contracts and currency options. At March 31, 2019, we had outstanding guarantees totaling $3.8 million under this Facility Agreement and amounts available under this Facility Agreement were $2.7 million. The Facility Agreement provides for financial covenants and customary events of default, and carries cross-default provisions with our U.S. Revolver. If an event of default (as defined in the Facility Agreement) occurs and is continuing, per the terms and subject to the conditions set forth therein, obligations outstanding under the Facility Agreement may be accelerated and declared immediately due and payable. As of March 31, 2019, we were in compliance with all of the financial covenants of the Facility Agreement.

[0000080420-19-000013:notes:12]
Litigation

[0000080420-19-000013:notes:13]
We are involved in various legal proceedings, claims and other disputes arising from our commercial operations, projects, employees and other matters which, in general, are subject to uncertainties and in which the outcomes are not predictable. Although we can give no assurances about the resolution of pending claims, litigation or other disputes and the effect such outcomes may have on us, management believes that any ultimate liability resulting from the outcome of such proceedings, to the extent not otherwise provided or covered by insurance, will not have a material adverse effect on our consolidated financial position or results of operations or liquidity.


## us-gaap:ContractWithCustomerAssetAndLiabilityTableTextBlock

[0000080420-19-000013:notes:14]
Contract assets and liabilities as of March 31, 2019 and September 30, 2018 are summarized below (in thousands):

[0000080420-19-000013:notes:15]
|  | March 31, 2019 |  | September 30, 2018 |
| Contract assets | $ | 70,727 |  |  | $ | 82,545 |  |
| Contract liabilities | (51,088 | ) |  | (43,174 | ) |
| Net contract assets | $ | 19,639 |  |  | $ | 39,371 |  |


## us-gaap:DisaggregationOfRevenueTableTextBlock

[0000080420-19-000013:notes:16]
The following tables present our disaggregated revenue by geographic destination and market sector for the three and six months ended March 31, 2019 (in thousands):

[0000080420-19-000013:notes:17]
|  | Three months ended March 31, 2019 |  | Six months ended March 31, 2019 |
| United States | $ | 102,406 |  |  | $ | 192,304 |  |
| Canada | 15,094 |  |  | 24,809 |  |
| Europe, Middle East and Africa | 5,508 |  |  | 10,949 |  |
| Asia/Pacific | 729 |  |  | 4,473 |  |
| Mexico, Central and South America | — |  |  | 553 |  |
| Total revenues by geographic destination | $ | 123,737 |  |  | $ | 233,088 |  |

[0000080420-19-000013:notes:18]
|  | Three months ended March 31, 2019 |  | Six months ended March 31, 2019 |
| Oil and gas | $ | 56,022 |  |  | $ | 105,598 |  |
| Petrochemical | 22,523 |  |  | 42,301 |  |
| Electric utility | 20,383 |  |  | 39,641 |  |
| Traction power | 6,025 |  |  | 11,034 |  |
| All others | 18,784 |  |  | 34,514 |  |
| Total revenues by market sector | $ | 123,737 |  |  | $ | 233,088 |  |


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0000080420-19-000013:notes:19]
[same as prior period, unchanged from 0000080420-19-000005:notes:19]

[0000080420-19-000013:notes:20]
[same as prior period, unchanged from 0000080420-19-000005:notes:20]

[0000080420-19-000013:notes:21]
[same as prior period, unchanged from 0000080420-19-000005:notes:21]

[0000080420-19-000013:notes:22]
We issue restricted stock units (RSUs) to certain officers and key employees of the Company. The fair value of the RSUs is based on the price of our common stock as reported on the NASDAQ Global Market on the grant dates. The typical annual grant vests over a three-year period from the date of issuance and is a blend of time-based and performance-based shares. The portion of the grant that is time-based typically vests over a three-year period on each anniversary of the grant date, based on continued employment. The performance-based shares vest based on the three-year earnings performance of the Company following the grant date. At March 31, 2019, there were 159,716 RSUs outstanding. The RSUs do not have voting rights but do receive dividend equivalents upon vesting; additionally, the shares of common stock underlying the RSUs are not considered issued and outstanding until vested and common stock is issued.

[0000080420-19-000013:notes:23]
RSU activity (number of shares) for the six months ended March 31, 2019 is summarized below:

[0000080420-19-000013:notes:24]
|  | Number ofRestrictedStockUnits |  | WeightedAverageFair ValuePer Share |
| Outstanding at September 30, 2018 | 190,500 |  |  | $ | 33.73 |  |
| Granted | 77,150 |  |  | 34.89 |  |
| Vested | (97,184 | ) |  | 32.35 |  |
| Forfeited/canceled | (10,750 | ) |  | 34.27 |  |
| Outstanding at March 31, 2019 | 159,716 |  |  | $ | 34.45 |  |

[0000080420-19-000013:notes:25]
During the six months ended March 31, 2019 and 2018, we recorded compensation expense of $1.6 million and $1.7 million, respectively, related to the RSUs.

[0000080420-19-000013:notes:26]
[same as prior period, unchanged from 0000080420-19-000005:notes:26]

[0000080420-19-000013:notes:27]
Each non-employee director receives 2,000 restricted shares of the Company’s common stock annually. Fifty-percent of the restricted stock granted to each of our non-employee directors vests immediately, while the remaining fifty-percent vests on the anniversary of the grant date. Compensation expense is recognized immediately for the first fifty-percent of the restricted stock granted, while compensation expense for the remaining fifty-percent is recognized over the remaining vesting period based on the closing price per share on the grant date. In February 2019, 14,000 shares of restricted stock were issued to our non-employee directors under the 2014 Director Plan at a price of $34.02 per share. During the six months ended March 31, 2019 and 2018, we recorded compensation expense of $0.3 million and $0.4 million, respectively, related to restricted stock.


## us-gaap:EarningsPerShareTextBlock

[0000080420-19-000013:notes:28]
[same as prior period, unchanged from 0000080420-19-000005:notes:28]

[0000080420-19-000013:notes:29]
[same as prior period, unchanged from 0000080420-19-000005:notes:29]

[0000080420-19-000013:notes:30]
[same as prior period, unchanged from 0000080420-19-000005:notes:30]

[0000080420-19-000013:notes:31]
|  | Three months ended March 31, |  | Six months ended March 31, |
|  | 2019 |  | 2018 |  | 2019 |  | 2018 |
| Numerator: |  |  |  |  |  |  |  |
| Net income (loss) | $ | 958 |  |  | $ | (3,330 | ) |  | $ | (1,737 | ) |  | $ | (8,992 | ) |
| Denominator: |  |  |  |  |  |  |  |
| Weighted average basic shares | 11,570 |  |  | 11,509 |  |  | 11,560 |  |  | 11,503 |  |
| Dilutive effect of restricted stock units | 62 |  |  | — |  |  | — |  |  | — |  |
| Weighted average diluted shares | 11,632 |  |  | 11,509 |  |  | 11,560 |  |  | 11,503 |  |
| Income (loss) per share: |  |  |  |  |  |  |  |
| Basic | $ | 0.08 |  |  | $ | (0.29 | ) |  | $ | (0.15 | ) |  | $ | (0.78 | ) |
| Diluted | $ | 0.08 |  |  | $ | (0.29 | ) |  | $ | (0.15 | ) |  | $ | (0.78 | ) |

[0000080420-19-000013:notes:32]
For the quarter ended March 31, 2018 and six months ended March 31, 2019 and 2018, we incurred net losses and therefore all potential common shares were deemed to be anti-dilutive.


## us-gaap:FairValueDisclosuresTextBlock

[0000080420-19-000013:notes:33]
[same as prior period, unchanged from 0000080420-19-000005:notes:33]

[0000080420-19-000013:notes:34]
[same as prior period, unchanged from 0000080420-19-000005:notes:34]

[0000080420-19-000013:notes:35]
[same as prior period, unchanged from 0000080420-19-000005:notes:35]

[0000080420-19-000013:notes:36]
[same as prior period, unchanged from 0000080420-19-000005:notes:36]

[0000080420-19-000013:notes:37]
[same as prior period, unchanged from 0000080420-19-000005:notes:37]

[0000080420-19-000013:notes:38]
[same as prior period, unchanged from 0000080420-19-000005:notes:38]

[0000080420-19-000013:notes:39]
The following table summarizes the fair value of our assets and liabilities that were accounted for at fair value on a recurring basis as of March 31, 2019 (in thousands):

[0000080420-19-000013:notes:40]
|  | Fair Value Measurements at March 31, 2019 |
|  | Quoted Prices inActive Markets forIdentical Assets(Level 1) |  | Significant OtherObservableInputs(Level 2) |  | SignificantUnobservableInputs(Level 3) |  | Fair Value at March 31, 2019 |
| Assets: |  |  |  |  |  |  |  |
| Cash and cash equivalents | $ | 66,376 |  |  | $ | — |  |  | $ | — |  |  | $ | 66,376 |  |
| Short-term investments | 5,991 |  |  | — |  |  | — |  |  | 5,991 |  |
| Restricted cash | 18,626 |  |  | — |  |  | — |  |  | 18,626 |  |
| Other assets | — |  |  | 6,621 |  |  | — |  |  | 6,621 |  |
| Liabilities: |  |  |  |  |  |  |  |
| Deferred compensation | — |  |  | 6,119 |  |  | — |  |  | 6,119 |  |

[0000080420-19-000013:notes:41]
[same as prior period, unchanged from 0000080420-19-000005:notes:41]

[0000080420-19-000013:notes:42]
|  | Fair Value Measurements at September 30, 2018 |
|  | Quoted Prices inActive Markets forIdentical Assets(Level 1) |  | Significant OtherObservableInputs(Level 2) |  | SignificantUnobservableInputs(Level 3) |  | Fair Value at September 30, 2018 |
| Assets: |  |  |  |  |  |  |  |
| Cash and cash equivalents | $ | 36,584 |  |  | $ | — |  |  | $ | — |  |  | $ | 36,584 |  |
| Short-term investments | 13,170 |  |  | — |  |  | — |  |  | 13,170 |  |
| Restricted cash | 25,141 |  |  | — |  |  | — |  |  | 25,141 |  |
| Other assets | — |  |  | 6,817 |  |  | — |  |  | 6,817 |  |
| Liabilities: |  |  |  |  |  |  |  |
| Deferred compensation | — |  |  | 5,644 |  |  | — |  |  | 5,644 |  |

[0000080420-19-000013:notes:43]
[same as prior period, unchanged from 0000080420-19-000005:notes:43]

[0000080420-19-000013:notes:44]
[same as prior period, unchanged from 0000080420-19-000005:notes:44]

[0000080420-19-000013:notes:45]
[same as prior period, unchanged from 0000080420-19-000005:notes:45]

[0000080420-19-000013:notes:46]
[same as prior period, unchanged from 0000080420-19-000005:notes:46]

[0000080420-19-000013:notes:47]
[same as prior period, unchanged from 0000080420-19-000005:notes:47]

[0000080420-19-000013:notes:48]
[same as prior period, unchanged from 0000080420-19-000005:notes:48]

[0000080420-19-000013:notes:49]
There were no transfers between levels within the fair value measurement hierarchy during the quarter ended March 31, 2019.


## us-gaap:IncomeTaxDisclosureTextBlock

[0000080420-19-000013:notes:50]
[same as prior period, unchanged from 0000080420-19-000005:notes:50]

[0000080420-19-000013:notes:51]
[same as prior period, unchanged from 0000080420-19-000005:notes:51]

[0000080420-19-000013:notes:52]
|  | Three months ended March 31, |  | Six months ended March 31, |
|  | 2019 |  | 2018 |  | 2019 |  | 2018 |
| Income (loss) before income taxes | $ | 1,363 |  |  | $ | (5,090 | ) |  | $ | (1,571 | ) |  | $ | (11,823 | ) |
| Income tax expense (benefit) | 405 |  |  | (1,760 | ) |  | 166 |  |  | (2,831 | ) |
| Net income (loss) | $ | 958 |  |  | $ | (3,330 | ) |  | $ | (1,737 | ) |  | $ | (8,992 | ) |
| Effective tax rate | 30 | % |  | 35 | % |  | (11 | )% |  | 24 | % |

[0000080420-19-000013:notes:53]
On December 22, 2017, the Tax Cuts and Jobs Act was signed into law, which lowered the corporate tax rate from 35% to 21% effective January 1, 2018. As a result, the U.S. federal statutory rate for Fiscal 2019 is 21%, compared to the blended statutory rate of 24.5% effective for Fiscal 2018. The effective tax rate of 30% for the second quarter of Fiscal 2019 and the effective tax rate of 35% in the second quarter of Fiscal 2018 was negatively impacted by foreign tax losses that are reserved with a valuation allowance.

[0000080420-19-000013:notes:54]
For the six months ended March 31, 2019, the effective tax rate of a negative 11% was negatively impacted by foreign tax losses that are reserved with a valuation allowance. The effective tax rate of 24% for the six months ended March 31, 2018 was similarly impacted by foreign tax losses reserved with a valuation allowance, as well as $0.8 million of tax expense related to the re-measurement of U.S. deferred tax assets as a result of tax reform.


## us-gaap:LongTermDebtTextBlock

[0000080420-19-000013:notes:55]
LONG-TERM DEBT

[0000080420-19-000013:notes:56]
Long-term debt consisted of the following (in thousands):

[0000080420-19-000013:notes:57]
|  | March 31, 2019 |  | September 30, 2018 |
| Industrial development revenue bonds | $ | 1,200 |  |  | $ | 1,600 |  |
| Less current portion | (400 | ) |  | (400 | ) |
| Total long-term debt | $ | 800 |  |  | $ | 1,200 |  |

[0000080420-19-000013:notes:58]
U.S. Revolver

[0000080420-19-000013:notes:59]
We have a $75.0 million revolving credit facility (U.S. Revolver) to provide working capital support and letters of credit which expires in June 2022. The amount available under the U.S. Revolver at March 31, 2019 was reduced by $15.6 million for our outstanding letters of credit. Currently, our U.S. Revolver can only be used for letters of credit until we meet certain financial ratios. There were no loans outstanding under the U.S. Revolver as of March 31, 2019.

[0000080420-19-000013:notes:60]
Per the terms of the U.S. Revolver, we are required to maintain cash in a pledged collateral account until we satisfy the following two financial ratios for two consecutive fiscal quarters: a max leverage ratio and a fixed charge coverage ratio. The max leverage ratio requires that the ratio of our consolidated funded indebtedness to our consolidated earnings before interest, taxes and depreciation (EBITDA) for the last four consecutive quarters not exceed 2.75 to 1.00. The fixed charge coverage ratio requires that the ratio of consolidated EBITDA for the last four fiscal quarters, less income taxes, capital expenditures, principal debt payments and interest charges be at least 1.25 to 1.00. If we are not in compliance with the these two ratios, we are required to maintain a cash balance in a pledged cash collateral account equal to 102% of the outstanding amount of any loans and letter of credit obligations until we meet the aforementioned required ratios. As of March 31, 2019, the balance in the cash collateral account was $18.6 million and is recorded as restricted cash in our Condensed Consolidated Balance Sheets. The portion of the cash collateral associated with the outstanding letters of credit that are due to expire beyond twelve months has been classified as non-current restricted cash on the balance sheet. As of March 31, 2019, there was $59.4 million available for the issuance of letters of credit under the U.S. Revolver, subject to the cash collateral requirements mentioned above.

[0000080420-19-000013:notes:61]
The interest rate for amounts outstanding under the U.S. Revolver is a floating rate based upon the higher of the Federal Funds Rate plus 0.5%, the bank’s prime rate, or the Eurocurrency rate plus 1.00%. Once the applicable rate is determined, a margin ranging up to 1.25% is added to the applicable rate.

[0000080420-19-000013:notes:62]
The U.S. Revolver is collateralized by a pledge of 100% of the voting capital stock of each of our domestic subsidiaries and 65% of the voting capital stock of each non-domestic subsidiary. The U.S. Revolver provides for customary events of default and carries cross-default provisions with other existing debt agreements. If an event of default (as defined in the U.S. Revolver) occurs and is continuing, on the terms and subject to the conditions set forth in the U.S. Revolver, amounts outstanding under the U.S. Revolver may be accelerated and may become immediately due and payable. It also contains financial covenants defining various financial measures and the levels of these measures with which we must comply, as well as a “material adverse change” clause. A “material adverse change” is defined as a material change in our operations, business, properties, liabilities or condition (financial or otherwise) or a material impairment of our ability to perform our obligations under our credit agreements. As of March 31, 2019, we were in compliance with all of the financial covenants of the U.S. Revolver.

[0000080420-19-000013:notes:63]
Industrial Development Revenue Bonds

[0000080420-19-000013:notes:64]
We borrowed $8.0 million in October 2001 through a loan agreement funded with proceeds from tax-exempt industrial development revenue bonds (Bonds). These Bonds were issued by the Illinois Development Finance Authority and were used for the completion of our Northlake, Illinois facility. Pursuant to the Bond issuance, a reimbursement agreement between us and a major domestic bank required an issuance by the bank of an irrevocable direct-pay letter of credit (Bond LC), as collateral, to the Bonds’ trustee to guarantee payment of the Bonds’ principal and interest when due. The Bond LC is subject to both early termination and extension provisions customary to such agreements, as well as various covenants, for which we were in compliance at March 31, 2019. While the Bonds mature in 2021, the reimbursement agreement requires annual redemptions of $0.4 million that commenced on October 25, 2002. A sinking fund is used for the redemption of the Bonds. The Bonds bear interest at a floating rate determined weekly by the Bonds’ remarketing agent, which was the underwriter for the Bonds and is an affiliate of the bank. This interest rate was 1.62% as of March 31, 2019.


## us-gaap:NewAccountingPronouncementsPolicyPolicyTextBlock

[0000080420-19-000013:notes:65]
New Accounting Standards

[0000080420-19-000013:notes:66]
In May 2014, the Financial Accounting Standards Board (FASB) issued a new standard on revenue recognition that supersedes previously issued revenue recognition guidance. This standard provides a five-step approach to be applied to all contracts with customers and requires expanded disclosures about the nature, amount, timing and uncertainty of revenue (and the related cash flows) arising from customer contracts, significant judgments and changes in judgments used in applying the revenue model and the assets recognized from costs incurred to obtain or fulfill a contract. Effective October 1, 2018, we adopted this standard using the modified retrospective basis. After evaluating the impact of this new standard on contracts outstanding as of October 1, 2018, we determined that no adjustment to retained earnings was necessary. See Note D for further discussion of revenue.

[0000080420-19-000013:notes:67]
In February 2016, the FASB issued a new topic on leases which requires lessees to recognize lease assets and lease liabilities on the balance sheet for all leases with terms longer than twelve months. Leases will be classified as either finance or operating, with classification affecting the pattern of expense recognition in the income statement. A modified retrospective transition approach is required for lessees for capital and operating leases existing at, or entered into after, the beginning of the earliest comparative period presented in the financial statements, with certain practical expedients available. The new topic is effective for fiscal years beginning after December 15, 2018, including interim periods within those fiscal years. This would be our fiscal year ending September 30, 2020. In Fiscal 2018, we acquired new lease software designed to assist with our compliance of this new topic. We are still evaluating the impact this new topic will have on our consolidated financial position and results of operations.

[0000080420-19-000013:notes:68]
In November 2016, the FASB issued a new topic on the statement of cash flows that changes the presentation of restricted cash and cash equivalents on the statement of cash flows. Restricted cash and restricted cash equivalents is to be included with cash and cash equivalents when reconciling the beginning-of-period and end-of-period total amounts shown on the statement of cash flows. We adopted this topic in Fiscal 2019 and our Condensed Consolidated Cash Flow Statements for all periods reflect this presentation.

[0000080420-19-000013:notes:69]
In May 2017, the FASB issued a new topic on modification accounting with regards to stock based compensation. This new topic clarifies when a change to the terms or conditions of a share-based payment award should be accounted for as a modification. An entity should account for the effects of a modification unless the fair value, vesting conditions and classification, as an equity instrument or a liability instrument, of the modified award are the same before and after a change to the terms or conditions of the share-based payment award. We adopted this topic in Fiscal 2019 and it has not had a material impact on our consolidated financial position or results of operations.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureAndSignificantAccountingPoliciesTextBlock

[0000080420-19-000013:notes:70]
[same as prior period, unchanged from 0000080420-19-000005:notes:70]

[0000080420-19-000013:notes:71]
[same as prior period, unchanged from 0000080420-19-000005:notes:71]

[0000080420-19-000013:notes:72]
[same as prior period, unchanged from 0000080420-19-000005:notes:72]

[0000080420-19-000013:notes:73]
[same as prior period, unchanged from 0000080420-19-000005:notes:73]

[0000080420-19-000013:notes:74]
[same as prior period, unchanged from 0000080420-19-000005:notes:74]

[0000080420-19-000013:notes:75]
[same as prior period, unchanged from 0000080420-19-000005:notes:75]


## us-gaap:RevenueFromContractWithCustomerPolicyTextBlock

[0000080420-19-000013:notes:76]
[same as prior period, unchanged from 0000080420-19-000005:notes:76]

[0000080420-19-000013:notes:77]
[same as prior period, unchanged from 0000080420-19-000005:notes:77]

[0000080420-19-000013:notes:78]
[same as prior period, unchanged from 0000080420-19-000005:notes:78]

[0000080420-19-000013:notes:79]
[same as prior period, unchanged from 0000080420-19-000005:notes:79]

[0000080420-19-000013:notes:80]
We also have contracts to provide value-added services such as field service inspection, installation, commissioning, modification and repair, as well as retrofit and retrofill components for existing systems.  As a practical expedient, if the service contract terms give us the right to invoice the customer for an amount that corresponds directly with the value of our performance completed to date (i.e., a service contract in which we bill a fixed amount for each hour of service provided), then we recognize revenue over time in each reporting period corresponding to the amount with which we have the right to invoice.  Our performance obligations are satisfied as the work progresses. Revenues from our custom-engineered products and value-added services transferred to customers over time accounted for approximately 93% of total revenues for both the three and six months ended March 31, 2019.

[0000080420-19-000013:notes:81]
We also have sales orders for spare parts and replacement circuit breakers for switchgear that are obsolete or that are no longer produced by the original manufacturer. Revenues from these sales orders are recognized at a point in time when we fulfill our performance obligation to the customer which is typically upon shipment. Revenue related to sales orders represents approximately 7% of total revenues for both the three and six months ended March 31, 2019.

[0000080420-19-000013:notes:82]
[same as prior period, unchanged from 0000080420-19-000005:notes:82]

[0000080420-19-000013:notes:83]
[same as prior period, unchanged from 0000080420-19-000005:notes:83]

[0000080420-19-000013:notes:84]
[same as prior period, unchanged from 0000080420-19-000005:notes:87]

[0000080420-19-000013:notes:85]
[same as prior period, unchanged from 0000080420-19-000005:notes:88]

[0000080420-19-000013:notes:86]
[same as prior period, unchanged from 0000080420-19-000005:notes:89]

[0000080420-19-000013:notes:87]
[same as prior period, unchanged from 0000080420-19-000005:notes:90]

[0000080420-19-000013:notes:88]
[same as prior period, unchanged from 0000080420-19-000005:notes:91]

[0000080420-19-000013:notes:89]
[same as prior period, unchanged from 0000080420-19-000005:notes:92]

[0000080420-19-000013:notes:90]
[same as prior period, unchanged from 0000080420-19-000005:notes:93]

[0000080420-19-000013:notes:91]
[same as prior period, unchanged from 0000080420-19-000005:notes:94]

[0000080420-19-000013:notes:92]
[same as prior period, unchanged from 0000080420-19-000005:notes:95]

[0000080420-19-000013:notes:93]
[same as prior period, unchanged from 0000080420-19-000005:notes:86]

[0000080420-19-000013:notes:94]
[same as prior period, unchanged from 0000080420-19-000005:notes:84]

[0000080420-19-000013:notes:95]
[same as prior period, unchanged from 0000080420-19-000005:notes:85]

[0000080420-19-000013:notes:96]
[same as prior period, unchanged from 0000080420-19-000005:notes:96]

[0000080420-19-000013:notes:97]
[same as prior period, unchanged from 0000080420-19-000005:notes:97]

[0000080420-19-000013:notes:98]
[same as prior period, unchanged from 0000080420-19-000005:notes:98]


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0000080420-19-000013:notes:99]
[same as prior period, unchanged from 0000080420-19-000005:notes:99]

[0000080420-19-000013:notes:100]
[same as prior period, unchanged from 0000080420-19-000005:notes:100]

[0000080420-19-000013:notes:101]
Remaining unsatisfied performance obligations, which we refer to as backlog, represent the estimated transaction price for goods and services for which we have a material right but work has not been performed. As of March 31, 2019, we had backlog of $397.2 million, of which approximately $334.7 million is expected to be recognized within the next twelve months. Backlog may not be indicative of future operating results as orders may be cancelled or modified by our customers. Our backlog does not include service and maintenance-type contracts for which we have the right to invoice as services are performed.

[0000080420-19-000013:notes:102]
For the six months ended March 31, 2019 and 2018, our operating loss was positively impacted by $4.3 million and $2.5 million, respectively, as a result of changes in contract estimates related to projects in progress at the beginning of the respective period. These changes in estimates resulted primarily from favorable project execution and negotiations of variable consideration, discussed below, as well as other changes in facts and circumstances during these periods.

[0000080420-19-000013:notes:103]
The decrease in net contract assets at March 31, 2019 was primarily due to our progress towards completion on our projects and the timing of contract billing milestones and new orders. To determine the amount of revenue recognized during the period from contract liabilities, we first allocate revenue to the individual contract liability balance outstanding at the beginning of the period until the revenue exceeds that balance. During the three and six months ended March 31, 2019, we recognized revenue of approximately $15.6 million and $37.2 million, respectively, related to contract liabilities outstanding at September 30, 2018.

[0000080420-19-000013:notes:104]
The timing of our invoice process is typically dependent on the completion of certain milestones and contract terms and subject to agreement by our customer.  Payment is typically expected within 30 days of invoice. Any uncollected invoiced amounts for our performance obligations recognized over time, including contract retentions, are recorded as accounts receivable in the Condensed Consolidated Balance Sheets. Certain contracts contain retention provisions that become due upon completion of contractual requirements. As of March 31, 2019 and September 30, 2018, accounts receivable included retention amounts of $3.8 million and $4.2 million, respectively. Of the retained amount at March 31, 2019, $3.4 million is expected to be collected in the next twelve months.

[0000080420-19-000013:notes:105]
[same as prior period, unchanged from 0000080420-19-000005:notes:105]


## us-gaap:ScheduleOfInventoryCurrentTableTextBlock

[0000080420-19-000013:notes:106]
[same as prior period, unchanged from 0000080420-19-000005:notes:106]

[0000080420-19-000013:notes:107]
|  | March 31, 2019 |  | September 30, 2018 |
| Raw materials, parts and subassemblies, net | $ | 23,535 |  |  | $ | 20,272 |  |
| Work-in-progress | 1,189 |  |  | 1,080 |  |
| Total inventories | $ | 24,724 |  |  | $ | 21,352 |  |


## us-gaap:ScheduleOfProductWarrantyLiabilityTableTextBlock

[0000080420-19-000013:notes:108]
[same as prior period, unchanged from 0000080420-19-000005:notes:108]

[0000080420-19-000013:notes:109]
|  | Three months ended March 31, |  | Six months ended March 31, |
|  | 2019 |  | 2018 |  | 2019 |  | 2018 |
| Balance at beginning of period | $ | 2,732 |  |  | $ | 2,890 |  |  | $ | 2,604 |  |  | $ | 3,174 |  |
| Increase (decrease) in warranty expense | 881 |  |  | (261 | ) |  | 1,627 |  |  | (66 | ) |
| Deduction for warranty charges | (634 | ) |  | (383 | ) |  | (1,238 | ) |  | (861 | ) |
| Change due to foreign currency translation | 7 |  |  | (5 | ) |  | (7 | ) |  | (6 | ) |
| Balance at end of period | $ | 2,986 |  |  | $ | 2,241 |  |  | $ | 2,986 |  |  | $ | 2,241 |  |


## us-gaap:SubsequentEventsTextBlock

[0000080420-19-000013:notes:110]
SUBSEQUENT EVENTS

[0000080420-19-000013:notes:111]
On May 7, 2019, our Board of Directors declared a quarterly cash dividend on our common stock in the amount of $0.26 per share. The dividend is payable on June 19, 2019 to shareholders of record at the close of business on May 22, 2019.


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0000080420-19-000013:notes:112]
[same as prior period, unchanged from 0000080420-19-000005:notes:112]

[0000080420-19-000013:notes:113]
[same as prior period, unchanged from 0000080420-19-000005:notes:113]

[0000080420-19-000013:notes:114]
[same as prior period, unchanged from 0000080420-19-000005:notes:114]

[0000080420-19-000013:notes:115]
[same as prior period, unchanged from 0000080420-19-000005:notes:115]
