# POWL note change history — 0000080420-19-000005 → 0000080420-19-000013


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2019-05-08):
[0000080420-19-000013:note_history:1]
Certain customers require us to post letters of credit or surety bonds which assure that we will perform under the terms of our contract. In the event of default, the counterparty may demand payment from the bank under a letter of credit or performance by the surety under a bond. To date, there have been no significant expenses related to either letters of credit or surety bonds for the periods reported. We were contingently liable for letters of credit of $15.6 million as of March 31, 2019. We also had surety bonds totaling $140.7 million that were outstanding, with additional bonding capacity of $609.3 million available, at March 31, 2019.
  (was, 2019-02-06, similarity 0.9793):
[0000080420-19-000005:note_history:1]
Certain customers require us to post letters of credit or surety bonds which assure that we will perform under the terms of our contract. In the event of default, the counterparty may demand payment from the bank under a letter of credit or performance by the surety under a bond. To date, there have been no significant expenses related to either letters of credit or surety bonds for the periods reported. We were contingently liable for letters of credit of $15.2 million as of December 31, 2018. We also had surety bonds totaling $172.3 million that were outstanding, with additional bonding capacity of $577.7 million available, at December 31, 2018.

- changed (2019-05-08):
[0000080420-19-000013:note_history:2]
Additionally, we have a $6.5 million facility agreement (Facility Agreement) between Powell (UK) Limited and a large international bank. This Facility Agreement provides Powell (UK) Limited the ability to enter into bank guarantees as well as forward exchange contracts and currency options. At March 31, 2019, we had outstanding guarantees totaling $3.8 million under this Facility Agreement and amounts available under this Facility Agreement were $2.7 million. The Facility Agreement provides for financial covenants and customary events of default, and carries cross-default provisions with our U.S. Revolver. If an event of default (as defined in the Facility Agreement) occurs and is continuing, per the terms and subject to the conditions set forth therein, obligations outstanding under the Facility Agreement may be accelerated and declared immediately due and payable. As of March 31, 2019, we were in compliance with all of the financial covenants of the Facility Agreement.
  (was, 2019-02-06, similarity 0.9866):
[0000080420-19-000005:note_history:2]
Additionally, we have a $6.4 million facility agreement (Facility Agreement) between Powell (UK) Limited and a large international bank. This Facility Agreement provides Powell (UK) Limited the ability to enter into bank guarantees as well as forward exchange contracts and currency options. At December 31, 2018, we had outstanding guarantees totaling $3.9 million under this Facility Agreement and amounts available under this Facility Agreement were $2.5 million. The Facility Agreement provides for financial covenants and customary events of default, and carries cross-default provisions with our U.S. Revolver. If an event of default (as defined in the Facility Agreement) occurs and is continuing, per the terms and subject to the conditions set forth therein, obligations outstanding under the Facility Agreement may be accelerated and declared immediately due and payable. As of December 31, 2018, we were in compliance with all of the financial covenants of the Facility Agreement.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureAndSignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2019-05-08):
[0000080420-19-000013:note_history:3]
In February 2016, the FASB issued a new topic on leases which requires lessees to recognize lease assets and lease liabilities on the balance sheet for all leases with terms longer than twelve months. Leases will be classified as either finance or operating, with classification affecting the pattern of expense recognition in the income statement. A modified retrospective transition approach is required for lessees for capital and operating leases existing at, or entered into after, the beginning of the earliest comparative period presented in the financial statements, with certain practical expedients available. The new topic is effective for fiscal years beginning after December 15, 2018, including interim periods within those fiscal years. This would be our fiscal year ending September 30, 2020. In Fiscal 2018, we acquired new lease software designed to assist with our compliance of this new topic. We are still evaluating the impact this new topic will have on our consolidated financial position and results of operations.
  (was, 2019-02-06, similarity 0.9592):
[0000080420-19-000005:note_history:3]
In February 2016, the FASB issued a new topic on leases which requires lessees to recognize lease assets and lease liabilities on the balance sheet for all leases with terms longer than twelve months. Leases will be classified as either finance or operating, with classification affecting the pattern of expense recognition in the income statement. A modified retrospective transition approach is required for lessees for capital and operating leases existing at, or entered into after, the beginning of the earliest comparative period presented in the financial statements, with certain practical expedients available. The new topic is effective for fiscal years beginning after December 15, 2018, including interim periods within those fiscal years. This would be our fiscal year ending September 30, 2020. In Fiscal 2018, we acquired new lease software designed to assist with the transition and our migrating our existing leases. We are still evaluating the impact this new topic will have on our consolidated financial position and results of operations.


## us-gaap:LongTermDebtTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2019-05-08):
[0000080420-19-000013:note_history:4]
|  | March 31, 2019 |  | September 30, 2018 |
| Industrial development revenue bonds | $ | 1,200 |  |  | $ | 1,600 |  |
| Less current portion | (400 | ) |  | (400 | ) |
| Total long-term debt | $ | 800 |  |  | $ | 1,200 |  |
  (was, 2019-02-06, similarity 0.9763):
[0000080420-19-000005:note_history:4]
|  | December 31, 2018 |  | September 30, 2018 |
| Industrial development revenue bonds | $ | 1,200 |  |  | $ | 1,600 |  |
| Less current portion | (400 | ) |  | (400 | ) |
| Total long-term debt | $ | 800 |  |  | $ | 1,200 |  |

- changed (2019-05-08):
[0000080420-19-000013:note_history:5]
We have a $75.0 million revolving credit facility (U.S. Revolver) to provide working capital support and letters of credit which expires in June 2022. The amount available under the U.S. Revolver at March 31, 2019 was reduced by $15.6 million for our outstanding letters of credit. Currently, our U.S. Revolver can only be used for letters of credit until we meet certain financial ratios. There were no loans outstanding under the U.S. Revolver as of March 31, 2019.
  (was, 2019-02-06, similarity 0.9621):
[0000080420-19-000005:note_history:5]
We have a $75.0 million revolving credit facility (U.S. Revolver) to provide working capital support and letters of credit which expires in June 2022. The amount available under the U.S. Revolver at December 31, 2018 was reduced by $15.2 million for our outstanding letters of credit. Currently, our U.S. Revolver can only be used for letters of credit until we meet certain financial ratios. There were no loans outstanding under the U.S. Revolver as of December 31, 2018.

- changed (2019-05-08):
[0000080420-19-000013:note_history:6]
Per the terms of the U.S. Revolver, we are required to maintain cash in a pledged collateral account until we satisfy the following two financial ratios for two consecutive fiscal quarters: a max leverage ratio and a fixed charge coverage ratio. The max leverage ratio requires that the ratio of our consolidated funded indebtedness to our consolidated earnings before interest, taxes and depreciation (EBITDA) for the last four consecutive quarters not exceed 2.75 to 1.00. The fixed charge coverage ratio requires that the ratio of consolidated EBITDA for the last four fiscal quarters, less income taxes, capital expenditures, principal debt payments and interest charges be at least 1.25 to 1.00. If we are not in compliance with the these two ratios, we are required to maintain a cash balance in a pledged cash collateral account equal to 102% of the outstanding amount of any loans and letter of credit obligations until we meet the aforementioned required ratios. As of March 31, 2019, the balance in the cash collateral account was $18.6 million and is recorded as restricted cash in our Condensed Consolidated Balance Sheets. The portion of the cash collateral associated with the outstanding letters of credit that are due to expire beyond twelve months has been classified as non-current restricted cash on the balance sheet. As of March 31, 2019, there was $59.4 million available for the issuance of letters of credit under the U.S. Revolver, subject to the cash collateral requirements mentioned above.
  (was, 2019-02-06, similarity 0.9913):
[0000080420-19-000005:note_history:6]
Per the terms of the U.S. Revolver, we are required to maintain cash in a pledged collateral account until we satisfy the following two financial ratios for two consecutive fiscal quarters: a max leverage ratio and a fixed charge coverage ratio. The max leverage ratio requires that the ratio of our consolidated funded indebtedness to our consolidated earnings before interest, taxes and depreciation (EBITDA) for the last four consecutive quarters not exceed 2.75 to 1.00. The fixed charge coverage ratio requires that the ratio of consolidated EBITDA for the last four fiscal quarters, less income taxes, capital expenditures, principal debt payments and interest charges be at least 1.25 to 1.00. If we are not in compliance with the these two ratios, we are required to maintain a cash balance in a pledged cash collateral account equal to 102% of the outstanding amount of any loans and letter of credit obligations until we meet the aforementioned required ratios. As of December 31, 2018, the balance in the cash collateral account was $15.9 million and is recorded as restricted cash in our Condensed Consolidated Balance Sheets. The portion of the cash collateral associated with the outstanding letters of credit that are due to expire beyond twelve months has been classified as non-current restricted cash on the balance sheet. As of December 31, 2018, there was $59.8 million available for the issuance of letters of credit under the U.S. Revolver, subject to the cash collateral requirements mentioned above.

- changed (2019-05-08):
[0000080420-19-000013:note_history:7]
The U.S. Revolver is collateralized by a pledge of 100% of the voting capital stock of each of our domestic subsidiaries and 65% of the voting capital stock of each non-domestic subsidiary. The U.S. Revolver provides for customary events of default and carries cross-default provisions with other existing debt agreements. If an event of default (as defined in the U.S. Revolver) occurs and is continuing, on the terms and subject to the conditions set forth in the U.S. Revolver, amounts outstanding under the U.S. Revolver may be accelerated and may become immediately due and payable. It also contains financial covenants defining various financial measures and the levels of these measures with which we must comply, as well as a “material adverse change” clause. A “material adverse change” is defined as a material change in our operations, business, properties, liabilities or condition (financial or otherwise) or a material impairment of our ability to perform our obligations under our credit agreements. As of March 31, 2019, we were in compliance with all of the financial covenants of the U.S. Revolver.
  (was, 2019-02-06, similarity 0.9941):
[0000080420-19-000005:note_history:7]
The U.S. Revolver is collateralized by a pledge of 100% of the voting capital stock of each of our domestic subsidiaries and 65% of the voting capital stock of each non-domestic subsidiary. The U.S. Revolver provides for customary events of default and carries cross-default provisions with other existing debt agreements. If an event of default (as defined in the U.S. Revolver) occurs and is continuing, on the terms and subject to the conditions set forth in the U.S. Revolver, amounts outstanding under the U.S. Revolver may be accelerated and may become immediately due and payable. It also contains financial covenants defining various financial measures and the levels of these measures with which we must comply, as well as a “material adverse change” clause. A “material adverse change” is defined as a material change in our operations, business, properties, liabilities or condition (financial or otherwise) or a material impairment of our ability to perform our obligations under our credit agreements. As of December 31, 2018, we were in compliance with all of the financial covenants of the U.S. Revolver.

- changed (2019-05-08):
[0000080420-19-000013:note_history:8]
We borrowed $8.0 million in October 2001 through a loan agreement funded with proceeds from tax-exempt industrial development revenue bonds (Bonds). These Bonds were issued by the Illinois Development Finance Authority and were used for the completion of our Northlake, Illinois facility. Pursuant to the Bond issuance, a reimbursement agreement between us and a major domestic bank required an issuance by the bank of an irrevocable direct-pay letter of credit (Bond LC), as collateral, to the Bonds’ trustee to guarantee payment of the Bonds’ principal and interest when due. The Bond LC is subject to both early termination and extension provisions customary to such agreements, as well as various covenants, for which we were in compliance at March 31, 2019. While the Bonds mature in 2021, the reimbursement agreement requires annual redemptions of $0.4 million that commenced on October 25, 2002. A sinking fund is used for the redemption of the Bonds. The Bonds bear interest at a floating rate determined weekly by the Bonds’ remarketing agent, which was the underwriter for the Bonds and is an affiliate of the bank. This interest rate was 1.62% as of March 31, 2019.
  (was, 2019-02-06, similarity 0.9887):
[0000080420-19-000005:note_history:8]
We borrowed $8.0 million in October 2001 through a loan agreement funded with proceeds from tax-exempt industrial development revenue bonds (Bonds). These Bonds were issued by the Illinois Development Finance Authority and were used for the completion of our Northlake, Illinois facility. Pursuant to the Bond issuance, a reimbursement agreement between us and a major domestic bank required an issuance by the bank of an irrevocable direct-pay letter of credit (Bond LC), as collateral, to the Bonds’ trustee to guarantee payment of the Bonds’ principal and interest when due. The Bond LC is subject to both early termination and extension provisions customary to such agreements, as well as various covenants, for which we were in compliance at December 31, 2018. While the Bonds mature in 2021, the reimbursement agreement requires annual redemptions of $0.4 million that commenced on October 25, 2002. A sinking fund is used for the redemption of the Bonds. The Bonds bear interest at a floating rate determined weekly by the Bonds’ remarketing agent, which was the underwriter for the Bonds and is an affiliate of the bank. This interest rate was 1.86% as of December 31, 2018.


## us-gaap:ScheduleOfDebtInstrumentsTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2019-05-08):
[0000080420-19-000013:note_history:9]
|  | March 31, 2019 |  | September 30, 2018 |
| Industrial development revenue bonds | $ | 1,200 |  |  | $ | 1,600 |  |
| Less current portion | (400 | ) |  | (400 | ) |
| Total long-term debt | $ | 800 |  |  | $ | 1,200 |  |
  (was, 2019-02-06, similarity 0.9763):
[0000080420-19-000005:note_history:9]
|  | December 31, 2018 |  | September 30, 2018 |
| Industrial development revenue bonds | $ | 1,200 |  |  | $ | 1,600 |  |
| Less current portion | (400 | ) |  | (400 | ) |
| Total long-term debt | $ | 800 |  |  | $ | 1,200 |  |


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2019-05-08):
[0000080420-19-000013:note_history:10]
The following tables present our disaggregated revenue by geographic destination and market sector for the three and six months ended March 31, 2019 (in thousands):
  (was, 2019-02-06, similarity 0.8961):
[0000080420-19-000005:note_history:10]
The following tables present our disaggregated revenue by geographic destination and market sector for the quarter ended December 31, 2018 (in thousands):

- changed (2019-05-08):
[0000080420-19-000013:note_history:11]
|  | Three months ended March 31, 2019 |  | Six months ended March 31, 2019 |
| United States | $ | 102,406 |  |  | $ | 192,304 |  |
| Canada | 15,094 |  |  | 24,809 |  |
| Europe, Middle East and Africa | 5,508 |  |  | 10,949 |  |
| Asia/Pacific | 729 |  |  | 4,473 |  |
| Mexico, Central and South America | — |  |  | 553 |  |
| Total revenues by geographic destination | $ | 123,737 |  |  | $ | 233,088 |  |
  (was, 2019-02-06, similarity 0.8049):
[0000080420-19-000005:note_history:11]
|  | Three months ended December 31, 2018 |
| United States | $ | 89,898 |  |
| Canada | 9,715 |  |
| Europe, Middle East and Africa | 5,441 |  |
| Asia/Pacific | 3,744 |  |
| Mexico, Central and South America | 553 |  |
| Total revenues by geographic destination | $ | 109,351 |  |

- changed (2019-05-08):
[0000080420-19-000013:note_history:12]
|  | Three months ended March 31, 2019 |  | Six months ended March 31, 2019 |
| Oil and gas | $ | 56,022 |  |  | $ | 105,598 |  |
| Petrochemical | 22,523 |  |  | 42,301 |  |
| Electric utility | 20,383 |  |  | 39,641 |  |
| Traction power | 6,025 |  |  | 11,034 |  |
| All others | 18,784 |  |  | 34,514 |  |
| Total revenues by market sector | $ | 123,737 |  |  | $ | 233,088 |  |
  (was, 2019-02-06, similarity 0.7581):
[0000080420-19-000005:note_history:12]
|  | Three months ended December 31, 2018 |
| Oil and gas | $ | 49,576 |  |
| Petrochemical | 19,778 |  |
| Electric utility | 19,258 |  |
| Traction power | 5,009 |  |
| All others | 15,730 |  |
| Total revenues by market sector | $ | 109,351 |  |


## us-gaap:RevenueFromContractWithCustomerPolicyTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2019-05-08):
[0000080420-19-000013:note_history:13]
We also have contracts to provide value-added services such as field service inspection, installation, commissioning, modification and repair, as well as retrofit and retrofill components for existing systems.  As a practical expedient, if the service contract terms give us the right to invoice the customer for an amount that corresponds directly with the value of our performance completed to date (i.e., a service contract in which we bill a fixed amount for each hour of service provided), then we recognize revenue over time in each reporting period corresponding to the amount with which we have the right to invoice.  Our performance obligations are satisfied as the work progresses. Revenues from our custom-engineered products and value-added services transferred to customers over time accounted for approximately 93% of total revenues for both the three and six months ended March 31, 2019.
  (was, 2019-02-06, similarity 0.9606):
[0000080420-19-000005:note_history:13]
We also have contracts to provide value-added services such as field service inspection, installation, commissioning, modification and repair, as well as retrofit and retrofill components for existing systems.  As a practical expedient, if the service contract terms give us the right to invoice the customer for an amount that corresponds directly with the value of our performance completed to date (i.e., a service contract in which we bill a fixed amount for each hour of service provided), then we recognize revenue over time in each reporting period corresponding to the amount with which we have the right to invoice.  Our performance obligations are satisfied as the work progresses. Revenues from our custom-engineered products and value-added services transferred to customers over time accounted for approximately 93% of total revenues for the three months ended December 31, 2018.

- changed (2019-05-08):
[0000080420-19-000013:note_history:14]
We also have sales orders for spare parts and replacement circuit breakers for switchgear that are obsolete or that are no longer produced by the original manufacturer. Revenues from these sales orders are recognized at a point in time when we fulfill our performance obligation to the customer which is typically upon shipment. Revenue related to sales orders represents approximately 7% of total revenues for both the three and six months ended March 31, 2019.
  (was, 2019-02-06, similarity 0.9212):
[0000080420-19-000005:note_history:14]
We also have sales orders for spare parts and replacement circuit breakers for switchgear that are obsolete or that are no longer produced by the original manufacturer. Revenues from these sales orders are recognized at a point in time when we fulfil our performance obligation to the customer which is typically upon shipment. Revenue related to sales orders represents approximately 7% of total revenues for the three months ended December 31, 2018.


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2019-05-08):
[0000080420-19-000013:note_history:15]
We also have contracts to provide value-added services such as field service inspection, installation, commissioning, modification and repair, as well as retrofit and retrofill components for existing systems.  As a practical expedient, if the service contract terms give us the right to invoice the customer for an amount that corresponds directly with the value of our performance completed to date (i.e., a service contract in which we bill a fixed amount for each hour of service provided), then we recognize revenue over time in each reporting period corresponding to the amount with which we have the right to invoice.  Our performance obligations are satisfied as the work progresses. Revenues from our custom-engineered products and value-added services transferred to customers over time accounted for approximately 93% of total revenues for both the three and six months ended March 31, 2019.
  (was, 2019-02-06, similarity 0.9606):
[0000080420-19-000005:note_history:15]
We also have contracts to provide value-added services such as field service inspection, installation, commissioning, modification and repair, as well as retrofit and retrofill components for existing systems.  As a practical expedient, if the service contract terms give us the right to invoice the customer for an amount that corresponds directly with the value of our performance completed to date (i.e., a service contract in which we bill a fixed amount for each hour of service provided), then we recognize revenue over time in each reporting period corresponding to the amount with which we have the right to invoice.  Our performance obligations are satisfied as the work progresses. Revenues from our custom-engineered products and value-added services transferred to customers over time accounted for approximately 93% of total revenues for the three months ended December 31, 2018.

- changed (2019-05-08):
[0000080420-19-000013:note_history:16]
We also have sales orders for spare parts and replacement circuit breakers for switchgear that are obsolete or that are no longer produced by the original manufacturer. Revenues from these sales orders are recognized at a point in time when we fulfill our performance obligation to the customer which is typically upon shipment. Revenue related to sales orders represents approximately 7% of total revenues for both the three and six months ended March 31, 2019.
  (was, 2019-02-06, similarity 0.9212):
[0000080420-19-000005:note_history:16]
We also have sales orders for spare parts and replacement circuit breakers for switchgear that are obsolete or that are no longer produced by the original manufacturer. Revenues from these sales orders are recognized at a point in time when we fulfil our performance obligation to the customer which is typically upon shipment. Revenue related to sales orders represents approximately 7% of total revenues for the three months ended December 31, 2018.

- changed (2019-05-08):
[0000080420-19-000013:note_history:17]
Remaining unsatisfied performance obligations, which we refer to as backlog, represent the estimated transaction price for goods and services for which we have a material right but work has not been performed. As of March 31, 2019, we had backlog of $397.2 million, of which approximately $334.7 million is expected to be recognized within the next twelve months. Backlog may not be indicative of future operating results as orders may be cancelled or modified by our customers. Our backlog does not include service and maintenance-type contracts for which we have the right to invoice as services are performed.
  (was, 2019-02-06, similarity 0.9892):
[0000080420-19-000005:note_history:17]
Remaining unsatisfied performance obligations, which we refer to as backlog, represent the estimated transaction price for goods and services for which we have a material right but work has not been performed. As of December 31, 2018, we had backlog of $322.0 million, of which approximately $302 million is expected to be recognized within the next twelve months. Backlog may not be indicative of future operating results as orders may be cancelled or modified by our customers. Our backlog does not include service and maintenance-type contracts for which we have the right to invoice as services are performed.

- changed (2019-05-08):
[0000080420-19-000013:note_history:18]
For the six months ended March 31, 2019 and 2018, our operating loss was positively impacted by $4.3 million and $2.5 million, respectively, as a result of changes in contract estimates related to projects in progress at the beginning of the respective period. These changes in estimates resulted primarily from favorable project execution and negotiations of variable consideration, discussed below, as well as other changes in facts and circumstances during these periods.
  (was, 2019-02-06, similarity 0.9512):
[0000080420-19-000005:note_history:18]
For the quarters ended December 31, 2018 and 2017, our operating loss was positively impacted by $3.1 million and $2.0 million, respectively, as a result of changes in contract estimates related to projects in progress at the beginning of the respective period. These changes in estimates resulted primarily from favorable project execution and negotiations of variable consideration, discussed below, as well as other changes in facts and circumstances during these periods.

- changed (2019-05-08):
[0000080420-19-000013:note_history:19]
Contract assets and liabilities as of March 31, 2019 and September 30, 2018 are summarized below (in thousands):
  (was, 2019-02-06, similarity 0.9565):
[0000080420-19-000005:note_history:19]
Contract assets and liabilities as of December 31, 2018 and September 30, 2018 are summarized below (in thousands):

- changed (2019-05-08):
[0000080420-19-000013:note_history:20]
|  | March 31, 2019 |  | September 30, 2018 |
| Contract assets | $ | 70,727 |  |  | $ | 82,545 |  |
| Contract liabilities | (51,088 | ) |  | (43,174 | ) |
| Net contract assets | $ | 19,639 |  |  | $ | 39,371 |  |
  (was, 2019-02-06, similarity 0.9038):
[0000080420-19-000005:note_history:20]
|  | December 31, 2018 |  | September 30, 2018 |
| Contract assets | $ | 69,601 |  |  | $ | 82,545 |  |
| Contract liabilities | 51,410 |  |  | 43,174 |  |
| Net contract assets (liabilities) | $ | 18,191 |  |  | $ | 39,371 |  |

- added (2019-05-08):
[0000080420-19-000013:note_history:21]
The decrease in net contract assets at March 31, 2019 was primarily due to our progress towards completion on our projects and the timing of contract billing milestones and new orders. To determine the amount of revenue recognized during the period from contract liabilities, we first allocate revenue to the individual contract liability balance outstanding at the beginning of the period until the revenue exceeds that balance. During the three and six months ended March 31, 2019, we recognized revenue of approximately $15.6 million and $37.2 million, respectively, related to contract liabilities outstanding at September 30, 2018.

- changed (2019-05-08):
[0000080420-19-000013:note_history:22]
The timing of our invoice process is typically dependent on the completion of certain milestones and contract terms and subject to agreement by our customer.  Payment is typically expected within 30 days of invoice. Any uncollected invoiced amounts for our performance obligations recognized over time, including contract retentions, are recorded as accounts receivable in the Condensed Consolidated Balance Sheets. Certain contracts contain retention provisions that become due upon completion of contractual requirements. As of March 31, 2019 and September 30, 2018, accounts receivable included retention amounts of $3.8 million and $4.2 million, respectively. Of the retained amount at March 31, 2019, $3.4 million is expected to be collected in the next twelve months.
  (was, 2019-02-06, similarity 0.9827):
[0000080420-19-000005:note_history:22]
The timing of our invoice process is typically dependent on the completion of certain milestones and contract terms and subject to agreement by our customer.  Payment is typically expected within 30 days of invoice. Any uncollected invoiced amounts for our performance obligations recognized over time, including contract retentions, are recorded as accounts receivable in the Condensed Consolidated Balance Sheets. Certain contracts contain retention provisions that become due upon completion of contractual requirements. As of December 31, 2018 and September 30, 2018, accounts receivable included retention amounts of $3.3 million and $4.2 million, respectively. Of the retained amount at December 31, 2018, $3.0 million is expected to be collected in the next twelve months.

- changed (2019-05-08):
[0000080420-19-000013:note_history:23]
The following tables present our disaggregated revenue by geographic destination and market sector for the three and six months ended March 31, 2019 (in thousands):
  (was, 2019-02-06, similarity 0.8961):
[0000080420-19-000005:note_history:23]
The following tables present our disaggregated revenue by geographic destination and market sector for the quarter ended December 31, 2018 (in thousands):

- changed (2019-05-08):
[0000080420-19-000013:note_history:24]
|  | Three months ended March 31, 2019 |  | Six months ended March 31, 2019 |
| United States | $ | 102,406 |  |  | $ | 192,304 |  |
| Canada | 15,094 |  |  | 24,809 |  |
| Europe, Middle East and Africa | 5,508 |  |  | 10,949 |  |
| Asia/Pacific | 729 |  |  | 4,473 |  |
| Mexico, Central and South America | — |  |  | 553 |  |
| Total revenues by geographic destination | $ | 123,737 |  |  | $ | 233,088 |  |
  (was, 2019-02-06, similarity 0.8049):
[0000080420-19-000005:note_history:24]
|  | Three months ended December 31, 2018 |
| United States | $ | 89,898 |  |
| Canada | 9,715 |  |
| Europe, Middle East and Africa | 5,441 |  |
| Asia/Pacific | 3,744 |  |
| Mexico, Central and South America | 553 |  |
| Total revenues by geographic destination | $ | 109,351 |  |

- changed (2019-05-08):
[0000080420-19-000013:note_history:25]
|  | Three months ended March 31, 2019 |  | Six months ended March 31, 2019 |
| Oil and gas | $ | 56,022 |  |  | $ | 105,598 |  |
| Petrochemical | 22,523 |  |  | 42,301 |  |
| Electric utility | 20,383 |  |  | 39,641 |  |
| Traction power | 6,025 |  |  | 11,034 |  |
| All others | 18,784 |  |  | 34,514 |  |
| Total revenues by market sector | $ | 123,737 |  |  | $ | 233,088 |  |
  (was, 2019-02-06, similarity 0.7581):
[0000080420-19-000005:note_history:25]
|  | Three months ended December 31, 2018 |
| Oil and gas | $ | 49,576 |  |
| Petrochemical | 19,778 |  |
| Electric utility | 19,258 |  |
| Traction power | 5,009 |  |
| All others | 15,730 |  |
| Total revenues by market sector | $ | 109,351 |  |

- removed (2019-05-08):
[0000080420-19-000005:note_history:26]
The decrease in net contract assets at December 31, 2018 was primarily due to the timing of contract billing milestones and new orders. To determine the amount of revenue recognized during the period from contract liabilities, we first allocate revenue to the individual contract liability balance outstanding at the beginning of the period until the revenue exceeds that balance. During the quarter ended December 31, 2018, we recognized revenue of approximately $28 million related to contract liabilities outstanding at September 30, 2018.


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: tag_name, score: 1.0

- changed (2019-05-08):
[0000080420-19-000013:note_history:27]
On May 7, 2019, our Board of Directors declared a quarterly cash dividend on our common stock in the amount of $0.26 per share. The dividend is payable on June 19, 2019 to shareholders of record at the close of business on May 22, 2019.
  (was, 2019-02-06, similarity 0.6517):
[0000080420-19-000005:note_history:27]
On February 5, 2019, our Board of Directors declared a quarterly cash dividend on our common stock in the amount of $0.26 per share. The dividend is payable on March 20, 2019 to shareholders of record at the close of business on February 20, 2019.
