# POWL notes — 0000080420-24-000008


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureAndSignificantAccountingPoliciesTextBlock

[0000080420-24-000008:notes:1]
[same as prior period, unchanged from 0000080420-23-000038:notes:1]

[0000080420-24-000008:notes:2]
Powell Industries, Inc. (we, us, our, Powell or the Company) is incorporated in the state of Delaware. Powell's predecessor companies were founded 77 years ago by William E. Powell in 1947. Our major subsidiaries, all of which are wholly owned, include Powell Electrical Systems, Inc.; Powell (UK) Limited; Powell Canada Inc.; and Powell Industries International, B.V.

[0000080420-24-000008:notes:3]
We develop, design, manufacture and service custom-engineered equipment and systems which (1) distribute, control and monitor the flow of electrical energy and (2) provide protection to motors, transformers and other electrically powered equipment. We are headquartered in Houston, Texas and serve the oil and gas and petrochemical markets, which include onshore and offshore production, liquefied natural gas (LNG) facilities and terminals, pipelines, refineries and petrochemical plants. Additionally, we manufacture products for the electric utility, light rail traction power, mining and metals, pulp and paper, data centers and other municipal, commercial and industrial markets.

[0000080420-24-000008:notes:4]
[same as prior period, unchanged from 0000080420-23-000038:notes:4]

[0000080420-24-000008:notes:5]
The unaudited condensed consolidated financial statements include the accounts of Powell and our wholly-owned subsidiaries. All significant intercompany accounts and transactions have been eliminated in consolidation.

[0000080420-24-000008:notes:6]
The unaudited condensed consolidated financial statements have been prepared in accordance with the instructions to Form 10-Q and Rule 10-01 of Regulation S-X for interim financial information. Certain information and footnote disclosures, normally included in annual financial statements prepared in accordance with accounting principles generally accepted in the United States (U.S. GAAP), have been condensed or omitted pursuant to those rules and regulations. In the opinion of management, all adjustments, consisting only of normal recurring adjustments, necessary to fairly state the financial position, results of operations and cash flows with respect to the interim condensed consolidated financial statements have been included. The results of operations for the interim periods are not necessarily indicative of the results for the entire fiscal year. We believe that these financial statements contain all adjustments necessary so that they are not misleading.

[0000080420-24-000008:notes:7]
The unaudited condensed consolidated financial statements should be read in conjunction with the audited consolidated financial statements and notes thereto of Powell and its subsidiaries included in Powell’s Annual Report on Form 10-K for the year ended September 30, 2023, which was filed with the Securities and Exchange Commission (SEC) on December 6, 2023.

[0000080420-24-000008:notes:8]
References to Fiscal 2024 and Fiscal 2023 used throughout this report shall mean the current fiscal year ending September 30, 2024 and the prior fiscal year ended September 30, 2023, respectively.

[0000080420-24-000008:notes:9]
Use of Estimates

[0000080420-24-000008:notes:10]
The preparation of condensed consolidated financial statements in conformity with U.S. GAAP requires management to make estimates and assumptions that affect the amounts reported in the condensed consolidated financial statements and accompanying footnotes. The most significant estimates used in our condensed consolidated financial statements affect revenue recognition and estimated cost recognition on our customer contracts, allowance for credit losses, provision for excess and obsolete inventory, warranty accruals and income taxes. The amounts recorded for warranties, legal, income taxes, impairment of long-lived assets (when applicable), liquidated damages and other contingent liabilities require judgments regarding the amount of expenses that will ultimately be incurred. We base our estimates on historical experience, forecasts and various other assumptions, as well as the specific circumstances surrounding these contingent liabilities, in evaluating the amount of liability that should be recorded. Additionally, the basis for recognition of deferred tax assets requires estimates related to future income and other assumptions regarding timing and future profitability because the ultimate realization of net deferred tax assets is dependent on the generation of future taxable income during periods in which temporary differences become deductible. Estimates routinely change as new events occur, additional information becomes available or operating environments change. Actual results may differ from our prior estimates.

[0000080420-24-000008:notes:11]
Accounting Standards Updates Issued but Not Yet Adopted

[0000080420-24-000008:notes:12]
In November 2023, the Financial Accounting Standard Board (FASB) issued Accounting Standards Update (ASU) 2023-07,

[0000080420-24-000008:notes:13]
Segment Reporting (Topic 280): Improvements to Reportable Segment Disclosures, which requires that public entities disclose significant segment expenses that are regularly provided to the chief operating decision maker (CODM) on an annual and interim basis. It also requires that public entities disclose the title and position of the CODM and an explanation of how the CODM uses the reported measures in assessing segment performance and resource allocation. Additionally, it requires that all existing annual disclosures about segment profit or loss and assets must be provided on an interim basis and clarifies that single reportable segment entities are subject to the disclosure requirement under Topic 280 in its entirety. ASU 2023-07 is effective for fiscal years beginning after December 15, 2023 and interim periods within those fiscal years beginning after December 15, 2024. A public entity should apply ASU 2023-07 retrospectively to all prior periods presented in the financial statements. Early adoption is permitted. We are currently evaluating the impacts of the new standard.

[0000080420-24-000008:notes:14]
In December 2023, the FASB issued ASU 2023-09, Improvements to Income Tax Disclosures, which enhances the transparency of income tax disclosures. It requires greater disaggregation of information in the tax rate reconciliation and income taxes paid disaggregated by jurisdiction. This ASU is effective for fiscal years beginning after December 15, 2024, and should be applied on a prospective basis. Retrospective application and early adoption are permitted. We are currently evaluating the impacts of the new standard.


## us-gaap:EarningsPerShareTextBlock

[0000080420-24-000008:notes:15]
Earnings Per Share
We compute basic earnings per share by dividing net income by the weighted average number of common shares outstanding during the period. Diluted earnings per common and potential common share include the weighted average of additional shares associated with the incremental effect of dilutive restricted stock and restricted stock units.

[0000080420-24-000008:notes:16]
[same as prior period, unchanged from 0000080420-23-000038:notes:11]

[0000080420-24-000008:notes:17]
|  | Three months ended December 31, |  |  |
|  | 2023 |  | 2022 |  |  |  |  |
| Numerator: |  |  |  |  |  |  |  |
| Net income | $ | 24,085 |  |  | $ | 1,162 |  |  |  |  |  |
| Denominator: |  |  |  |  |  |  |  |
| Weighted average basic shares | 11,941 |  |  | 11,859 |  |  |  |  |  |
| Dilutive effect of restricted stock and restricted stock units | 233 |  |  | 218 |  |  |  |  |  |
| Weighted average diluted shares | 12,174 |  |  | 12,077 |  |  |  |  |  |
| Earnings per share: |  |  |  |  |  |  |  |
| Basic | $ | 2.02 |  |  | $ | 0.10 |  |  |  |  |  |
| Diluted | $ | 1.98 |  |  | $ | 0.10 |  |  |  |  |  |


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0000080420-24-000008:notes:18]
[same as prior period, unchanged from 0000080420-23-000038:notes:13]

[0000080420-24-000008:notes:19]
[same as prior period, unchanged from 0000080420-23-000038:notes:14]

[0000080420-24-000008:notes:20]
|  | December 31, 2023 |  | September 30, 2023 |
| Raw materials, parts and sub-assemblies | $ | 74,181 |  |  | $ | 68,631 |  |
| Work-in-progress | 2,056 |  |  | 1,379 |  |
| Provision for excess and obsolete inventories | (6,555) |  |  | (6,145) |  |
| Total inventories | $ | 69,682 |  |  | $ | 63,865 |  |

[0000080420-24-000008:notes:21]
Property, Plant and Equipment

[0000080420-24-000008:notes:22]
Property, plant and equipment are summarized below (in thousands):

[0000080420-24-000008:notes:23]
|  | December 31, 2023 |  | September 30, 2023 |  |  |  |  |
| Land | $ | 21,729 |  |  | $ | 21,526 |  |  |  |  |  |
| Buildings and improvements | 122,706 |  |  | 121,454 |  |  |  |  |  |
| Machinery and equipment | 93,636 |  |  | 92,477 |  |  |  |  |  |
| Furniture and fixtures | 3,792 |  |  | 3,726 |  |  |  |  |  |
| Construction in process | 4,434 |  |  | 4,129 |  |  |  |  |  |
|  | $ | 246,297 |  |  | $ | 243,312 |  |  |  |  |  |
| Less: Accumulated depreciation | (147,979) |  |  | (145,687) |  |  |  |  |  |
| Total property, plant and equipment, net | $ | 98,318 |  |  | $ | 97,625 |  |  |  |  |  |

[0000080420-24-000008:notes:24]
There were no assets under finance lease as of December 31, 2023 or September 30, 2023.

[0000080420-24-000008:notes:25]
Intangible Asset

[0000080420-24-000008:notes:26]
In December 2023, we acquired intellectual property for a total consideration of $0.5 million, of which $250 thousand was paid in cash.

[0000080420-24-000008:notes:27]
[same as prior period, unchanged from 0000080420-23-000038:notes:16]

[0000080420-24-000008:notes:28]
[same as prior period, unchanged from 0000080420-23-000038:notes:17]

[0000080420-24-000008:notes:29]
|  | Three months ended December 31, |  |  |
|  | 2023 |  | 2022 |  |  |  |  |
| Balance at beginning of period | $ | 3,305 |  |  | $ | 2,345 |  |  |  |  |  |
| Increase to warranty expense | 1,127 |  |  | 479 |  |  |  |  |  |
| Deduction for warranty charges | (774) |  |  | (454) |  |  |  |  |  |
| Change due to foreign currency translation | 22 |  |  | 10 |  |  |  |  |  |
| Balance at end of period | $ | 3,680 |  |  | $ | 2,380 |  |  |  |  |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0000080420-24-000008:notes:30]
[same as prior period, unchanged from 0000080420-23-000038:notes:19]

[0000080420-24-000008:notes:31]
Our revenues are primarily generated from the manufacturing of custom-engineered products and systems under long-term fixed-price contracts under which we agree to manufacture various products such as traditional and arc-resistant distribution switchgear and control gear, medium-voltage circuit breakers, monitoring and control communications systems, motor control centers, switches and bus duct systems. These products may be sold separately as an engineered solution but are typically integrated into custom-built enclosures which we also build. These enclosures are referred to as power control room substations (PCRs®), custom-engineered modules or electrical houses (E-Houses). Some contracts may also include the installation and the commissioning of these enclosures.

[0000080420-24-000008:notes:32]
[same as prior period, unchanged from 0000080420-23-000038:notes:22]

[0000080420-24-000008:notes:33]
We also have contracts to provide field service inspection, installation, commissioning, modification, and repair services, as well as retrofit and retrofill components for existing systems. If the service contract terms give us the right to invoice the customer for an amount that corresponds directly with the value of our performance completed to date (i.e., a service contract in which we bill a fixed amount for each hour of service provided), then we recognize revenue over time in each reporting period

[0000080420-24-000008:notes:34]
corresponding to the amount that we have the right to invoice. Our performance obligations are satisfied as the work progresses. Revenues from our custom-engineered products and value-added services transferred to customers over time accounted for approximately 94% of revenues for the three months ended December 31, 2023 and 93% of revenues for the three months ended December 31, 2022.

[0000080420-24-000008:notes:35]
We also have sales orders for spare parts and replacement circuit breakers for switchgear that are obsolete or that are no longer produced by the original manufacturer. Revenues from these sales orders are recognized at the time we fulfill our performance obligation to the customer, which is typically upon shipment and represented approximately 6% of revenues for the three months ended December 31, 2023 and 7% of revenues for the three months ended December 31, 2022.

[0000080420-24-000008:notes:36]
[same as prior period, unchanged from 0000080420-23-000038:notes:25]

[0000080420-24-000008:notes:37]
[same as prior period, unchanged from 0000080420-23-000038:notes:26]

[0000080420-24-000008:notes:38]
[same as prior period, unchanged from 0000080420-23-000038:notes:27]

[0000080420-24-000008:notes:39]
[same as prior period, unchanged from 0000080420-23-000038:notes:28]

[0000080420-24-000008:notes:40]
Remaining unsatisfied performance obligations, which we refer to as backlog, represent the estimated transaction price for goods and services for which we have a material right, but work has not been performed. As of December 31, 2023, we had backlog of $1.3 billion, of which approximately $713 million is expected to be recognized as revenue within the next twelve months. Backlog may not be indicative of future operating results as orders may be cancelled or modified by our customers. Our backlog does not include service and maintenance-type contracts for which we have the right to invoice as services are performed.

[0000080420-24-000008:notes:41]
[same as prior period, unchanged from 0000080420-23-000038:notes:30]

[0000080420-24-000008:notes:42]
Actual revenues and project costs may vary from previous estimates due to changes in a variety of factors. The cost estimation process is based upon the professional knowledge and experience of our engineers, project managers and financial professionals. Factors that are considered in estimating the work to be completed and ultimate contract recovery include the availability and productivity of labor, the nature and complexity of the work to be performed, the availability of materials, and the effect of any delays on our project performance. We periodically review our job performance, job conditions, estimated profitability and final contract settlements, including our estimate of total costs and make revisions to costs and income in the period in which the revisions are probable and reasonably estimable. We bear the risk of cost overruns in most of our contracts, which may result in reduced profits. Whenever revisions of estimated contract costs and contract values indicate that the contract costs will exceed estimated revenues, thus creating a loss, a provision for the total estimated loss is recorded in that period.

[0000080420-24-000008:notes:43]
For the three months ended December 31, 2023 and 2022, our operating results were positively impacted by $5.4 million and $3.6 million, respectively, as a result of net changes in contract estimates related to projects in progress at the beginning of the respective period. These changes in estimates resulted primarily from favorable project execution, reduced cost estimates and negotiations of variable consideration, discussed below, as well as revenue recognized from project cancellations and other changes in facts and circumstances during these periods. Gross unfavorable changes in contract estimates were immaterial for both the three months ended December 31, 2023 and 2022.

[0000080420-24-000008:notes:44]
[same as prior period, unchanged from 0000080420-23-000038:notes:34]

[0000080420-24-000008:notes:45]
[same as prior period, unchanged from 0000080420-23-000038:notes:35]

[0000080420-24-000008:notes:46]
[same as prior period, unchanged from 0000080420-23-000038:notes:36]

[0000080420-24-000008:notes:47]
[same as prior period, unchanged from 0000080420-23-000038:notes:37]

[0000080420-24-000008:notes:48]
[same as prior period, unchanged from 0000080420-23-000038:notes:38]

[0000080420-24-000008:notes:49]
[same as prior period, unchanged from 0000080420-23-000038:notes:39]

[0000080420-24-000008:notes:50]
[same as prior period, unchanged from 0000080420-23-000038:notes:40]

[0000080420-24-000008:notes:51]
[same as prior period, unchanged from 0000080420-23-000038:notes:41]

[0000080420-24-000008:notes:52]
[same as prior period, unchanged from 0000080420-23-000038:notes:42]

[0000080420-24-000008:notes:53]
Contract assets and liabilities as of December 31, 2023 and September 30, 2023 are summarized below (in thousands):

[0000080420-24-000008:notes:54]
|  | December 31, 2023 |  | September 30, 2023 |
| Contract assets | $ | 67,594 |  |  | $ | 60,621 |  |
| Contract liabilities | (328,888) |  |  | (279,796) |  |
| Net contract liability | $ | (261,294) |  |  | $ | (219,175) |  |

[0000080420-24-000008:notes:55]
Our net contract billing position remained a net liability at both December 31, 2023 and September 30, 2023, primarily due to favorable contract billing milestones. We typically allocate a significant percentage of the progress billing to the early stages of the contract. These favorable billing milestones are driving the increase in the net contract liability at December 31, 2023. To determine the amount of revenue recognized during the period from contract liabilities, we first allocate revenue to the individual contract liability balance outstanding at the beginning of the period until the revenue exceeds that balance. During the three months ended December 31, 2023, we recognized revenue of $103.5 million that was related to contract liabilities outstanding at September 30, 2023.

[0000080420-24-000008:notes:56]
The timing of our invoice process is typically dependent on the completion of certain milestones and contract terms and subject to agreement by our customer. Payment is typically expected within 30 days of invoice. Any uncollected invoiced amounts for our performance obligations recognized over time, including contract retentions, are recorded as accounts receivable in the Condensed Consolidated Balance Sheets. Certain contracts allow customers to withhold a small percentage of billings pursuant to retainage provisions, and such amounts are generally due upon completion of the contract and acceptance of the project by the customer. Based on our experience in recent years, the majority of these retainage balances are expected to be collected within approximately twelve months. As of December 31, 2023 and September 30, 2023, we had retention amounts of $7.3 million and $7.4 million, respectively. Of the retained amount at December 31, 2023, $7.1 million is expected to be collected in the next twelve months and is recorded in accounts receivable. The remaining $0.2 million is recorded in other assets.

[0000080420-24-000008:notes:57]
[same as prior period, unchanged from 0000080420-23-000038:notes:48]

[0000080420-24-000008:notes:58]
The following tables present our disaggregated revenue by geographic destination and market sector for the three months ended December 31, 2023 and 2022 (in thousands):

[0000080420-24-000008:notes:59]
|  | Three months ended December 31, |  |  |
|  | 2023 |  | 2022 |  |  |  |  |
| United States | $ | 159,860 |  |  | $ | 100,112 |  |  |  |  |  |
| Canada | 20,350 |  |  | 18,496 |  |  |  |  |  |
| Europe | 6,532 |  |  | 4,134 |  |  |  |  |  |
| Middle East and Africa | 3,275 |  |  | 2,425 |  |  |  |  |  |
| Mexico, Central and South America | 2,657 |  |  | 915 |  |  |  |  |  |
| Asia/Pacific | 1,343 |  |  | 776 |  |  |  |  |  |
| Total revenues by geographic destination | $ | 194,017 |  |  | $ | 126,858 |  |  |  |  |  |

[0000080420-24-000008:notes:60]
|  | Three months ended December 31, |  |  |
|  | 2023 |  | 2022 |  |  |  |  |
| Oil and gas (excludes petrochemical) | $ | 83,636 |  |  | $ | 43,510 |  |  |  |  |  |
| Petrochemical | 28,367 |  |  | 22,490 |  |  |  |  |  |
| Electric utility | 40,703 |  |  | 28,407 |  |  |  |  |  |
| Commercial and other industrial | 24,672 |  |  | 17,050 |  |  |  |  |  |
| Traction power | 4,345 |  |  | 7,072 |  |  |  |  |  |
| All others | 12,294 |  |  | 8,329 |  |  |  |  |  |
| Total revenues by market sector | $ | 194,017 |  |  | $ | 126,858 |  |  |  |  |  |


## us-gaap:RevenueFromContractWithCustomerPolicyTextBlock

[0000080420-24-000008:notes:61]
[same as prior period, unchanged from 0000080420-23-000038:notes:52]

[0000080420-24-000008:notes:62]
[same as prior period, unchanged from 0000080420-23-000038:notes:53]

[0000080420-24-000008:notes:63]
[same as prior period, unchanged from 0000080420-23-000038:notes:54]

[0000080420-24-000008:notes:64]
[same as prior period, unchanged from 0000080420-23-000038:notes:56]


## us-gaap:LongTermDebtTextBlock

[0000080420-24-000008:notes:65]
Long-Term Debt
U.S. Revolver

[0000080420-24-000008:notes:66]
On October 4, 2023, we entered into a third amendment (the Third Amendment) to our credit agreement with Bank of America, N.A. (as amended, the U.S. Revolver). The Third Amendment added Texas Capital Bank as Syndication Agent and a lender, increased the amount of the revolving line of credit from $125.0 million to $150.0 million, and extended the expiry date to October 4, 2028. The aggregate commitment of $150.0 million consists of $100.0 million committed by Bank of America and $50.0 million committed by Texas Capital Bank. As amended by the Third Amendment, the lesser of (a) $60 million, (b) 60% of available cash, and (c) the aggregate face amount of the issued but undrawn letters of credit that are not cash-secured, shall be deducted from consolidated funded indebtedness, when calculating the consolidated net leverage ratio. We have the option to cash collateralize all or a portion of the letters of credit outstanding, which would favorably impact the consolidated funded indebtedness calculation and the consolidated net leverage ratio. As of December 31, 2023, there were no amounts borrowed under the U.S. Revolver, and letters of credit outstanding were $87.1 million. There was $62.9 million available for the issuance of letters of credit and borrowings under the U.S. Revolver as of December 31, 2023.

[0000080420-24-000008:notes:67]
As of December 31, 2023, we were in compliance with all of the financial covenants of the U.S. Revolver.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0000080420-24-000008:notes:68]
Commitments and Contingencies
Letters of Credit, Bank Guarantees and Bonds

[0000080420-24-000008:notes:69]
Certain customers require us to post letters of credit, bank guarantees or surety bonds. These security instruments assure that we will perform under the terms of our contract. In the event of default, the counterparty may demand payment from the bank under a letter of credit or bank guarantee, or performance by the surety under a bond. To date, there have been no significant draws or claims related to security instruments for the periods reported. We were contingently liable for letters of credit of $87.1 million as of December 31, 2023. We also had surety bonds totaling $483.6 million that were outstanding, with additional bonding capacity of $716.4 million available, at December 31, 2023. We have strong surety relationships; however, a change in market conditions or the sureties' assessment of our financial position could cause the sureties to require cash collateralization for undischarged liabilities under the bonds.

[0000080420-24-000008:notes:70]
We have a $19.1 million facility agreement (Facility Agreement) between Powell (UK) Limited and a large international bank that provides Powell (UK) Limited the ability to enter into bank guarantees as well as forward exchange contracts and currency options. At December 31, 2023, we had outstanding guarantees totaling $6.8 million, with an additional capacity of $12.3 million available under this Facility Agreement. The Facility Agreement provides for customary events of default and carries cross-default provisions with the U.S. Revolver. If an event of default (as defined in the Facility Agreement) occurs and is continuing, per the terms and subject to the conditions set forth therein, obligations outstanding under the Facility Agreement may be accelerated and declared immediately due and payable. Additionally, we are required to maintain cash collateral for guarantees greater than two years. As of December 31, 2023, we were in compliance with all of the financial covenants of the Facility Agreement.

[0000080420-24-000008:notes:71]
Litigation

[0000080420-24-000008:notes:72]
We are involved in various legal proceedings, claims and other disputes arising from our commercial operations, projects, employees and other matters which, in general, are subject to uncertainties and in which the outcomes are not predictable. Although we can give no assurances about the resolution of pending claims, litigation or other disputes, and the effect such outcomes may have on us, management believes that any ultimate liability resulting from the outcome of such proceedings, to the extent not otherwise provided or covered by insurance, will not have a material adverse effect on our consolidated financial position or results of operations or liquidity.

[0000080420-24-000008:notes:73]
Liquidated Damages

[0000080420-24-000008:notes:74]
Certain of our customer contracts have schedule and performance obligation clauses that, if we fail to meet them, could require us to pay liquidated damages. Each individual contract defines the conditions under which the customer may make a claim against us. As of December 31, 2023, certain contracts had a probable exposure to liquidated damages claims of $3.6 million, which could possibly increase to $4.2 million under certain circumstances. Based on our actual or projected failure to meet these various contractual commitments, $1.5 million has been recorded as a reduction to revenue. We will attempt to obtain change orders, contract extensions or accelerate project completion, which may resolve the potential for any unrecorded liquidated damages claims. Should we fail to achieve relief on some or all of these contractual obligations, we could be required to pay additional liquidated damages, which could negatively impact our future operating results.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0000080420-24-000008:notes:75]
Stock-Based Compensation
Refer to our Annual Report on Form 10-K for the fiscal year ended September 30, 2023 for a full description of our existing stock-based compensation plans.

[0000080420-24-000008:notes:76]
[same as prior period, unchanged from 0000080420-23-000038:notes:70]

[0000080420-24-000008:notes:77]
We issue restricted stock units (RSUs) to certain officers and key employees of the Company. The fair value of the RSUs is based on the price of our common stock as reported on the NASDAQ Global Market on the grant dates. Typically, these grants vest over a three-year period from the date of issuance and are a blend of time-based and performance-based shares. The portion of the grant that is time-based typically vests over a three-year period on each anniversary of the grant date, based on continued employment. The performance-based shares vest based on the three-year earnings and safety performance of the Company following the grant date. At December 31, 2023, there were 230,420 RSUs outstanding. The RSUs do not have voting rights but do receive dividend equivalents upon vesting which are accrued quarterly. Additionally, the shares of common stock underlying the RSUs are not considered issued and outstanding until vested and common stock is issued.

[0000080420-24-000008:notes:78]
Total RSU activity (number of shares) for the three months ended December 31, 2023 is summarized below:

[0000080420-24-000008:notes:79]
|  | Number ofRestrictedStockUnits |  | WeightedAverageGrant ValuePer Share |
| Outstanding at September 30, 2023 | 292,497 |  |  | $ | 22.90 |  |
| Granted | 41,485 |  |  | 84.63 |  |
| Vested | (103,562) |  |  | 23.65 |  |
| Forfeited/canceled | — |  |  | — |  |
| Outstanding at December 31, 2023 | 230,420 |  |  | $ | 33.68 |  |

[0000080420-24-000008:notes:80]
During the three months ended December 31, 2023 and 2022, we recorded compensation expense of $1.6 million and $1.3 million, respectively, related to the RSUs.

[0000080420-24-000008:notes:81]
Restricted Stock
In December 2023, the Company's Compensation and Human Capital Committee revised the non-employee directors' annual restricted stock compensation from a fixed-shares arrangement to a fixed-value arrangement, retrospectively effective on October 1, 2023. Prior to October 1, 2023, each non-employee director received 2,400 restricted shares of the Company’s common stock annually. Fifty-percent of the restricted stock granted to each of our non-employee directors vested immediately, while the remaining fifty-percent vested on the anniversary of the grant date. Compensation expense was recognized immediately for the first fifty-percent of the restricted stock granted, while compensation expense for the remaining fifty-percent was recognized over the remaining vesting period. Subsequent to October 1, 2023, each non-employee director will receive restricted shares of the Company's common stock valued at $0.1 million annually. The number of granted shares is then calculated by dividing the $0.1 million by the average of high and low prices of our common stock on the grant date. The shares will vest on the earlier of the grant anniversary date or the date of the next annual meeting of shareholders, whichever occurs first. During the three months ended December 31, 2023 and 2022, we recorded compensation expense of less than $0.1 million for both periods, related to restricted stock.


## us-gaap:FairValueDisclosuresTextBlock

[0000080420-24-000008:notes:82]
[same as prior period, unchanged from 0000080420-23-000038:notes:76]

[0000080420-24-000008:notes:83]
[same as prior period, unchanged from 0000080420-23-000038:notes:77]

[0000080420-24-000008:notes:84]
[same as prior period, unchanged from 0000080420-23-000038:notes:78]

[0000080420-24-000008:notes:85]
[same as prior period, unchanged from 0000080420-23-000038:notes:79]

[0000080420-24-000008:notes:86]
[same as prior period, unchanged from 0000080420-23-000038:notes:80]

[0000080420-24-000008:notes:87]
The following table summarizes the fair value of our assets and liabilities that were accounted for at fair value on a recurring basis as of December 31, 2023 (in thousands):

[0000080420-24-000008:notes:88]
|  | Fair Value Measurements at December 31, 2023 |
|  | Quoted Prices inActive Markets forIdentical Assets(Level 1) |  | Significant OtherObservableInputs(Level 2) |  | SignificantUnobservableInputs(Level 3) |  | Fair Value at December 31,2023 |
| Assets: |  |  |  |  |  |  |  |
| Cash and cash equivalents | $ | 321,400 |  |  | $ | — |  |  | $ | — |  |  | $ | 321,400 |  |
| Short-term investments | 33,943 |  |  | — |  |  | — |  |  | 33,943 |  |
| Rabbi trust assets | — |  |  | 9,901 |  |  | — |  |  | 9,901 |  |
| Liabilities: |  |  |  |  |  |  |  |
| Deferred compensation | — |  |  | 10,965 |  |  | — |  |  | 10,965 |  |

[0000080420-24-000008:notes:89]
The following table summarizes the fair value of our assets and liabilities that were accounted for at fair value on a recurring basis as of September 30, 2023 (in thousands):

[0000080420-24-000008:notes:90]
|  | Fair Value Measurements at September 30, 2023 |
|  | Quoted Prices inActive Markets forIdentical Assets(Level 1) |  | Significant OtherObservableInputs(Level 2) |  | SignificantUnobservableInputs(Level 3) |  | Fair Value at September 30,2023 |
| Assets: |  |  |  |  |  |  |  |
| Cash and cash equivalents | $ | 245,875 |  |  | $ | — |  |  | $ | — |  |  | $ | 245,875 |  |
| Short-term investments | 33,134 |  |  | — |  |  | — |  |  | 33,134 |  |
| Rabbi trust assets | — |  |  | 9,117 |  |  | — |  |  | 9,117 |  |
| Liabilities: |  |  |  |  |  |  |  |
| Deferred compensation | — |  |  | 9,145 |  |  | — |  |  | 9,145 |  |

[0000080420-24-000008:notes:91]
[same as prior period, unchanged from 0000080420-23-000038:notes:85]

[0000080420-24-000008:notes:92]
[same as prior period, unchanged from 0000080420-23-000038:notes:86]

[0000080420-24-000008:notes:93]
Short-term investments – Short-term investments include time deposits with original maturities of three months or more.

[0000080420-24-000008:notes:94]
Rabbi trust assets and deferred compensation – We hold investments in an irrevocable rabbi trust for our deferred compensation plan. The assets are primarily related to company-owned life insurance policies and are included in other assets in the accompanying Condensed Consolidated Balance Sheets. Because the mutual funds and company-owned life insurance policies are combined in the plan, they are categorized as Level 2 in the fair value measurement hierarchy. The deferred compensation liability represents the investment options that the plan participants have designated to serve as the basis for measurement of the notional value of their accounts. Because the deferred compensation liability is intended to offset the plan assets, it is also categorized as Level 2 in the fair value measurement hierarchy.

[0000080420-24-000008:notes:95]
There were no transfers between levels within the fair value measurement hierarchy during the quarter ended December 31, 2023.


## us-gaap:LesseeOperatingLeasesTextBlock

[0000080420-24-000008:notes:96]
Leases
Our leases consist primarily of office and construction equipment. All of our future lease obligations are related to non-cancelable operating leases. The following table provides a summary of lease cost components for the three months ended December 31, 2023 and 2022, respectively (in thousands):

[0000080420-24-000008:notes:97]
|  |  | Three months ended December 31, |  |  |
| Lease Cost |  | 2023 |  | 2022 |  |  |  |  |
| Operating lease cost |  | $ | 256 |  |  | $ | 378 |  |  |  |  |  |
| Less: sublease income |  | — |  |  | (162) |  |  |  |  |  |
| Variable lease cost(1) |  | 30 |  |  | 108 |  |  |  |  |  |
| Short-term lease cost(2) |  | 400 |  |  | 387 |  |  |  |  |  |
| Total lease cost |  | $ | 686 |  |  | $ | 711 |  |  |  |  |  |

[0000080420-24-000008:notes:98]
[same as prior period, unchanged from 0000080420-23-000038:notes:92]

[0000080420-24-000008:notes:99]
[same as prior period, unchanged from 0000080420-23-000038:notes:93]

[0000080420-24-000008:notes:100]
We recognize operating lease assets and operating lease liabilities representing the present value of the remaining lease payments for leases with initial terms greater than twelve months. Leases with initial terms of twelve months or less are not recorded in our Condensed Consolidated Balance Sheets. The following table provides a summary of the operating lease assets and operating lease liabilities included in our Condensed Consolidated Balance Sheets as of December 31, 2023 and September 30, 2023, respectively (in thousands):

[0000080420-24-000008:notes:101]
| Operating Leases |  | December 31, 2023 |  | September 30, 2023 |
| Assets: |  |  |  |  |
| Operating lease assets, net |  | $ | 1,218 |  |  | $ | 1,436 |  |
| Liabilities: |  |  |  |  |
| Current operating lease liabilities |  | 645 |  |  | 773 |  |
| Long-term operating lease liabilities |  | 573 |  |  | 663 |  |
| Total lease liabilities |  | $ | 1,218 |  |  | $ | 1,436 |  |

[0000080420-24-000008:notes:102]
The following table provides the maturities of our operating lease liabilities as of December 31, 2023 (in thousands):

[0000080420-24-000008:notes:103]
|  |  | Operating Leases |  |  |
| Remainder of 2024 |  | $ | 550 |  |  |  |
| 2025 |  | 370 |  |  |  |
| 2026 |  | 180 |  |  |  |
| 2027 |  | 147 |  |  |  |
| 2028 |  | 19 |  |  |  |
| Thereafter |  | — |  |  |  |
| Total future minimum lease payments |  | $ | 1,266 |  |  |  |
| Less: present value discount (imputed interest) |  | (48) |  |  |  |
| Present value of lease liabilities |  | $ | 1,218 |  |  |  |

[0000080420-24-000008:notes:104]
The weighted average discount rate as of December 31, 2023 was 3.4%. The weighted average remaining lease term was 2.61 years at December 31, 2023.


## us-gaap:IncomeTaxDisclosureTextBlock

[0000080420-24-000008:notes:105]
[same as prior period, unchanged from 0000080420-23-000038:notes:99]

[0000080420-24-000008:notes:106]
|  | Three months ended December 31, |  |  |
|  | 2023 |  | 2022 |  |  |  |  |
| Income before income taxes | $ | 29,878 |  |  | $ | 1,613 |  |  |  |  |  |
| Income tax provision | 5,793 |  |  | 451 |  |  |  |  |  |
| Net income | $ | 24,085 |  |  | $ | 1,162 |  |  |  |  |  |
| Effective tax rate | 19 | % |  | 28 | % |  |  |  |  |

[0000080420-24-000008:notes:107]
Our income tax provision reflects an effective tax rate on pre-tax income of 19% for the three months ended December 31, 2023 compared to 28% for the three months ended December 31, 2022. The effective tax rate for the first quarter of Fiscal 2024 was favorably impacted by a discrete item related to the vesting of restricted stock units and the estimated Research and Development Tax Credit (R&D Tax Credit). These items were partially offset by an inclusion related to U.S. global intangible income and the tax expense related to certain nondeductible expenses. The effective tax rate for the first quarter of Fiscal 2023 was also favorably impacted by the estimated R&D Tax Credit but was partially offset by an unfavorable discrete item related to the vesting of restricted stock units.


## us-gaap:SubsequentEventsTextBlock

[0000080420-24-000008:notes:108]
Subsequent Events
Quarterly Dividend Declared

[0000080420-24-000008:notes:109]
On January 30, 2024, our Board of Directors approved an increase to the quarterly cash dividend on our common stock to $0.2650 per share, equating to an annualized dividend of $1.06 per share from the current amount of $1.05 per share. The dividend is payable on March 13, 2024 to shareholders of record at the close of business on February 14, 2024.
