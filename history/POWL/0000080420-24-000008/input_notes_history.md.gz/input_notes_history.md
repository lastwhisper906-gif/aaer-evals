# POWL note change history — 0000080420-23-000038 → 0000080420-24-000008


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2024-01-31):
[0000080420-24-000008:note_history:1]
Certain customers require us to post letters of credit, bank guarantees or surety bonds. These security instruments assure that we will perform under the terms of our contract. In the event of default, the counterparty may demand payment from the bank under a letter of credit or bank guarantee, or performance by the surety under a bond. To date, there have been no significant draws or claims related to security instruments for the periods reported. We were contingently liable for letters of credit of $87.1 million as of December 31, 2023. We also had surety bonds totaling $483.6 million that were outstanding, with additional bonding capacity of $716.4 million available, at December 31, 2023. We have strong surety relationships; however, a change in market conditions or the sureties' assessment of our financial position could cause the sureties to require cash collateralization for undischarged liabilities under the bonds.
  (was, 2023-08-02, similarity 0.9868):
[0000080420-23-000038:note_history:1]
Certain customers require us to post letters of credit, bank guarantees or surety bonds. These security instruments assure that we will perform under the terms of our contract. In the event of default, the counterparty may demand payment from the bank under a letter of credit or bank guarantee, or performance by the surety under a bond. To date, there have been no significant draws or claims related to security instruments for the periods reported. We were contingently liable for letters of credit of $49.0 million as of June 30, 2023. We also had surety bonds totaling $357.5 million that were outstanding, with additional bonding capacity of $342.5 million available, at June 30, 2023. We have strong surety relationships; however, a change in market conditions or the sureties' assessment of our financial position could cause the sureties to require cash collateralization for undischarged liabilities under the bonds.

- changed (2024-01-31):
[0000080420-24-000008:note_history:2]
We have a $19.1 million facility agreement (Facility Agreement) between Powell (UK) Limited and a large international bank that provides Powell (UK) Limited the ability to enter into bank guarantees as well as forward exchange contracts and currency options. At December 31, 2023, we had outstanding guarantees totaling $6.8 million, with an additional capacity of $12.3 million available under this Facility Agreement. The Facility Agreement provides for customary events of default and carries cross-default provisions with the U.S. Revolver. If an event of default (as defined in the Facility Agreement) occurs and is continuing, per the terms and subject to the conditions set forth therein, obligations outstanding under the Facility Agreement may be accelerated and declared immediately due and payable. Additionally, we are required to maintain cash collateral for guarantees greater than two years. As of December 31, 2023, we were in compliance with all of the financial covenants of the Facility Agreement.
  (was, 2023-08-02, similarity 0.8204):
[0000080420-23-000038:note_history:2]
We have a $10.1 million facility agreement (Facility Agreement) between Powell (UK) Limited and a large international bank that provides Powell (UK) Limited the ability to enter into bank guarantees as well as forward exchange contracts and currency options. At June 30, 2023, we had outstanding guarantees totaling $8.2 million. The Facility Agreement provides for customary events of default and carries cross-default provisions with our Second Amendment. If an event of default (as defined in the Facility Agreement) occurs and is continuing, per the terms and subject to the conditions set forth therein, obligations outstanding under the Facility Agreement may be accelerated and declared immediately due and payable. Additionally, we are required to maintain cash collateral for guarantees greater than two years. As of June 30, 2023, we were in compliance with all of the financial covenants of the Facility Agreement.

- added (2024-01-31):
[0000080420-24-000008:note_history:3]
Liquidated Damages

- added (2024-01-31):
[0000080420-24-000008:note_history:4]
Certain of our customer contracts have schedule and performance obligation clauses that, if we fail to meet them, could require us to pay liquidated damages. Each individual contract defines the conditions under which the customer may make a claim against us. As of December 31, 2023, certain contracts had a probable exposure to liquidated damages claims of $3.6 million, which could possibly increase to $4.2 million under certain circumstances. Based on our actual or projected failure to meet these various contractual commitments, $1.5 million has been recorded as a reduction to revenue. We will attempt to obtain change orders, contract extensions or accelerate project completion, which may resolve the potential for any unrecorded liquidated damages claims. Should we fail to achieve relief on some or all of these contractual obligations, we could be required to pay additional liquidated damages, which could negatively impact our future operating results.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureAndSignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2024-01-31):
[0000080420-24-000008:note_history:5]
We develop, design, manufacture and service custom-engineered equipment and systems which (1) distribute, control and monitor the flow of electrical energy and (2) provide protection to motors, transformers and other electrically powered equipment. We are headquartered in Houston, Texas and serve the oil and gas and petrochemical markets, which include onshore and offshore production, liquefied natural gas (LNG) facilities and terminals, pipelines, refineries and petrochemical plants. Additionally, we manufacture products for the electric utility, light rail traction power, mining and metals, pulp and paper, data centers and other municipal, commercial and industrial markets.
  (was, 2023-08-02, similarity 0.7733):
[0000080420-23-000038:note_history:5]
We develop, design, manufacture and service custom-engineered equipment and systems that (1) distribute, control and monitor the flow of electrical energy and (2) provide protection to motors, transformers and other electrically powered equipment. We are headquartered in Houston, Texas and serve the oil and gas and petrochemical markets, which include onshore and offshore production, liquefied natural gas (LNG) facilities and terminals, pipelines, refineries and petrochemical plants. Additional markets include electric utility, light rail traction power as well as mining and metals, pulp and paper and other municipal, commercial and other industrial markets.

- changed (2024-01-31):
[0000080420-24-000008:note_history:6]
The unaudited condensed consolidated financial statements include the accounts of Powell and our wholly-owned subsidiaries. All significant intercompany accounts and transactions have been eliminated in consolidation.
  (was, 2023-08-02, similarity 0.9954):
[0000080420-23-000038:note_history:6]
These unaudited condensed consolidated financial statements include the accounts of Powell and our wholly-owned subsidiaries. All significant intercompany accounts and transactions have been eliminated in consolidation.

- changed (2024-01-31):
[0000080420-24-000008:note_history:7]
The unaudited condensed consolidated financial statements have been prepared in accordance with the instructions to Form 10-Q and Rule 10-01 of Regulation S-X for interim financial information. Certain information and footnote disclosures, normally included in annual financial statements prepared in accordance with accounting principles generally accepted in the United States (U.S. GAAP), have been condensed or omitted pursuant to those rules and regulations. In the opinion of management, all adjustments, consisting only of normal recurring adjustments, necessary to fairly state the financial position, results of operations and cash flows with respect to the interim condensed consolidated financial statements have been included. The results of operations for the interim periods are not necessarily indicative of the results for the entire fiscal year. We believe that these financial statements contain all adjustments necessary so that they are not misleading.
  (was, 2023-08-02, similarity 0.999):
[0000080420-23-000038:note_history:7]
These unaudited condensed consolidated financial statements have been prepared in accordance with the instructions to Form 10-Q and Rule 10-01 of Regulation S-X for interim financial information. Certain information and footnote disclosures, normally included in annual financial statements prepared in accordance with accounting principles generally accepted in the United States (U.S. GAAP), have been condensed or omitted pursuant to those rules and regulations. In the opinion of management, all adjustments, consisting only of normal recurring adjustments, necessary to fairly state the financial position, results of operations and cash flows with respect to the interim condensed consolidated financial statements have been included. The results of operations for the interim periods are not necessarily indicative of the results for the entire fiscal year. We believe that these financial statements contain all adjustments necessary so that they are not misleading.

- changed (2024-01-31):
[0000080420-24-000008:note_history:8]
The unaudited condensed consolidated financial statements should be read in conjunction with the audited consolidated financial statements and notes thereto of Powell and its subsidiaries included in Powell’s Annual Report on Form 10-K for the year ended September 30, 2023, which was filed with the Securities and Exchange Commission (SEC) on December 6, 2023.
  (was, 2023-08-02, similarity 0.9971):
[0000080420-23-000038:note_history:8]
These unaudited condensed consolidated financial statements should be read in conjunction with the audited consolidated financial statements and notes thereto of Powell and its subsidiaries included in Powell’s Annual Report on Form 10-K for the year ended September 30, 2022, which was filed with the Securities and Exchange Commission (SEC) on December 6, 2022.

- added (2024-01-31):
[0000080420-24-000008:note_history:9]
Use of Estimates

- changed (2024-01-31):
[0000080420-24-000008:note_history:10]
The preparation of condensed consolidated financial statements in conformity with U.S. GAAP requires management to make estimates and assumptions that affect the amounts reported in the condensed consolidated financial statements and accompanying footnotes. The most significant estimates used in our condensed consolidated financial statements affect revenue recognition and estimated cost recognition on our customer contracts, allowance for credit losses, provision for excess and obsolete inventory, warranty accruals and income taxes. The amounts recorded for warranties, legal, income taxes, impairment of long-lived assets (when applicable), liquidated damages and other contingent liabilities require judgments regarding the amount of expenses that will ultimately be incurred. We base our estimates on historical experience, forecasts and various other assumptions, as well as the specific circumstances surrounding these contingent liabilities, in evaluating the amount of liability that should be recorded. Additionally, the basis for recognition of deferred tax assets requires estimates related to future income and other assumptions regarding timing and future profitability because the ultimate realization of net deferred tax assets is dependent on the generation of future taxable income during periods in which temporary differences become deductible. Estimates routinely change as new events occur, additional information becomes available or operating environments change. Actual results may differ from our prior estimates.
  (was, 2023-08-02, similarity 0.6948):
[0000080420-23-000038:note_history:10]
Use of Estimates
The preparation of condensed consolidated financial statements in conformity with U.S. GAAP requires management to make estimates and assumptions that affect the amounts reported in the condensed consolidated financial statements and accompanying footnotes. The most significant estimates used in our condensed consolidated financial statements affect revenue recognition and estimated cost recognition on our customer contracts, the allowance for credit losses, provision for excess and obsolete inventory, warranty accruals and income taxes. The amounts recorded for warranties, legal, income taxes, impairment of long-lived assets (when applicable), liquidated damages and other contingent liabilities require judgments regarding the amount of expenses that will ultimately be incurred. We base our estimates on historical experience, forecasts and various other assumptions, as well as the specific circumstances surrounding these contingent liabilities, in evaluating the amount of liability that should be recorded. Additionally, the recognition of deferred tax assets requires estimates related to future income and other assumptions regarding timing and future profitability because the ultimate realization of net deferred tax assets is dependent on the generation of future taxable income during the periods in which temporary differences become deductible. Estimates routinely change as new events occur, additional information becomes available or operating environments change. Actual results may differ from our prior estimates.

- added (2024-01-31):
[0000080420-24-000008:note_history:11]
Accounting Standards Updates Issued but Not Yet Adopted

- added (2024-01-31):
[0000080420-24-000008:note_history:12]
In November 2023, the Financial Accounting Standard Board (FASB) issued Accounting Standards Update (ASU) 2023-07,

- added (2024-01-31):
[0000080420-24-000008:note_history:13]
Segment Reporting (Topic 280): Improvements to Reportable Segment Disclosures, which requires that public entities disclose significant segment expenses that are regularly provided to the chief operating decision maker (CODM) on an annual and interim basis. It also requires that public entities disclose the title and position of the CODM and an explanation of how the CODM uses the reported measures in assessing segment performance and resource allocation. Additionally, it requires that all existing annual disclosures about segment profit or loss and assets must be provided on an interim basis and clarifies that single reportable segment entities are subject to the disclosure requirement under Topic 280 in its entirety. ASU 2023-07 is effective for fiscal years beginning after December 15, 2023 and interim periods within those fiscal years beginning after December 15, 2024. A public entity should apply ASU 2023-07 retrospectively to all prior periods presented in the financial statements. Early adoption is permitted. We are currently evaluating the impacts of the new standard.

- added (2024-01-31):
[0000080420-24-000008:note_history:14]
In December 2023, the FASB issued ASU 2023-09, Improvements to Income Tax Disclosures, which enhances the transparency of income tax disclosures. It requires greater disaggregation of information in the tax rate reconciliation and income taxes paid disaggregated by jurisdiction. This ASU is effective for fiscal years beginning after December 15, 2024, and should be applied on a prospective basis. Retrospective application and early adoption are permitted. We are currently evaluating the impacts of the new standard.


## us-gaap:LongTermDebtTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2024-01-31):
[0000080420-24-000008:note_history:15]
Long-Term Debt
U.S. Revolver
  (was, 2023-08-02, similarity 0.9818):
[0000080420-23-000038:note_history:15]
Long-Term Debt
U.S Revolver

- added (2024-01-31):
[0000080420-24-000008:note_history:16]
On October 4, 2023, we entered into a third amendment (the Third Amendment) to our credit agreement with Bank of America, N.A. (as amended, the U.S. Revolver). The Third Amendment added Texas Capital Bank as Syndication Agent and a lender, increased the amount of the revolving line of credit from $125.0 million to $150.0 million, and extended the expiry date to October 4, 2028. The aggregate commitment of $150.0 million consists of $100.0 million committed by Bank of America and $50.0 million committed by Texas Capital Bank. As amended by the Third Amendment, the lesser of (a) $60 million, (b) 60% of available cash, and (c) the aggregate face amount of the issued but undrawn letters of credit that are not cash-secured, shall be deducted from consolidated funded indebtedness, when calculating the consolidated net leverage ratio. We have the option to cash collateralize all or a portion of the letters of credit outstanding, which would favorably impact the consolidated funded indebtedness calculation and the consolidated net leverage ratio. As of December 31, 2023, there were no amounts borrowed under the U.S. Revolver, and letters of credit outstanding were $87.1 million. There was $62.9 million available for the issuance of letters of credit and borrowings under the U.S. Revolver as of December 31, 2023.

- added (2024-01-31):
[0000080420-24-000008:note_history:17]
As of December 31, 2023, we were in compliance with all of the financial covenants of the U.S. Revolver.

- removed (2024-01-31):
[0000080420-23-000038:note_history:18]
On March 31, 2023, we entered into a second amendment (the Second Amendment) to our credit agreement with Bank of America, N.A. (as amended, the U.S. Revolver). The Second Amendment increased the revolving credit facility extended to us under the U.S. Revolver, which is available for both borrowings and letters of credit and expires September 27, 2024, from $75.0 million to $125.0 million. As amended by the Second Amendment, the U.S. Revolver states that the lesser of $50 million or 50% of readily and available cash may be deducted from the amount of letters of credit outstanding (not to be less than zero) when calculating the consolidated funded indebtedness, which is a component of the consolidated net leverage ratio. We have the option to cash collateralize all or a portion of the letters of credit outstanding, which would favorably impact the consolidated funded indebtedness calculation and the consolidated net leverage ratio. As of June 30, 2023, there were no amounts borrowed under the U.S. Revolver, and letters of credit outstanding were $49.0 million. There was $76.0 million available for the issuance of letters of credit and borrowings under the U.S. Revolver as of June 30, 2023.

- removed (2024-01-31):
[0000080420-23-000038:note_history:19]
We are required to maintain certain financial covenants, the most significant of which are a consolidated net leverage ratio less than 3.0 to 1.0 and a consolidated interest coverage ratio of greater than 3.0 to 1.0. Our most restrictive covenant, the consolidated net leverage ratio, is the ratio of earnings before interest, taxes, depreciation, amortization and stock-based compensation (EBITDAS) to funded indebtedness. An increase in indebtedness, which includes letters of credit, or a decrease in EBITDAS could restrict our ability to issue letters of credit or borrow under the U.S. Revolver. Additionally, we must maintain a consolidated cash balance of $50 million at all times, which can be deducted from the letters of credit outstanding as noted above. The U.S. Revolver also contains a "material adverse effect" clause which is a material change in our operations, business, properties, liabilities or condition (financial or otherwise) or a material impairment of our ability to perform our obligations under our credit agreements. As of June 30, 2023, we were in compliance with all of the financial covenants of the U.S. Revolver.

- removed (2024-01-31):
[0000080420-23-000038:note_history:20]
The U.S. Revolver allows the Company to elect that any borrowing under the facility bears an interest rate based on either the base rate or the eurocurrency rate, in each case, plus the applicable rate. The base rate is generally the highest of (a) the federal funds rate plus 0.50%, (b) the Bank of America prime rate or (c) the Bloomberg Short-Term Bank Yield Index (BSBY) rate plus 1.00%. The applicable rate is generally a range from 0% to 2% depending on the type of loan and the Company's consolidated net leverage ratio.

- removed (2024-01-31):
[0000080420-23-000038:note_history:21]
The U.S. Revolver is collateralized by a pledge of 100% of the voting capital stock of each of our domestic subsidiaries and 65% of the voting capital stock of each non-domestic subsidiary. The U.S. Revolver provides for customary events of default and carries cross-default provisions with other existing debt agreements. If an event of default (as defined in the U.S. Revolver) occurs and is continuing, on the terms and subject to the conditions set forth in the U.S. Revolver, amounts and letters of credit outstanding under the U.S. Revolver may be accelerated and may become immediately due and payable.

- removed (2024-01-31):
[0000080420-23-000038:note_history:22]
Industrial Development Revenue Bonds

- removed (2024-01-31):
[0000080420-23-000038:note_history:23]
We borrowed $8.0 million in October 2001 through a loan agreement funded with proceeds from tax-exempt industrial development revenue bonds (Bonds) for the completion of our Northlake, Illinois facility. The Bonds matured on October 1, 2021 and our final payment of $0.4 million was made.


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2024-01-31):
[0000080420-24-000008:note_history:24]
The following tables present our disaggregated revenue by geographic destination and market sector for the three months ended December 31, 2023 and 2022 (in thousands):
  (was, 2023-08-02, similarity 0.9415):
[0000080420-23-000038:note_history:24]
The following tables present our disaggregated revenue by geographic destination and market sector for the three and nine months ended June 30, 2023 and 2022 (in thousands):

- added (2024-01-31):
[0000080420-24-000008:note_history:25]
|  | Three months ended December 31, |  |  |
|  | 2023 |  | 2022 |  |  |  |  |
| United States | $ | 159,860 |  |  | $ | 100,112 |  |  |  |  |  |
| Canada | 20,350 |  |  | 18,496 |  |  |  |  |  |
| Europe | 6,532 |  |  | 4,134 |  |  |  |  |  |
| Middle East and Africa | 3,275 |  |  | 2,425 |  |  |  |  |  |
| Mexico, Central and South America | 2,657 |  |  | 915 |  |  |  |  |  |
| Asia/Pacific | 1,343 |  |  | 776 |  |  |  |  |  |
| Total revenues by geographic destination | $ | 194,017 |  |  | $ | 126,858 |  |  |  |  |  |

- changed (2024-01-31):
[0000080420-24-000008:note_history:26]
|  | Three months ended December 31, |  |  |
|  | 2023 |  | 2022 |  |  |  |  |
| Oil and gas (excludes petrochemical) | $ | 83,636 |  |  | $ | 43,510 |  |  |  |  |  |
| Petrochemical | 28,367 |  |  | 22,490 |  |  |  |  |  |
| Electric utility | 40,703 |  |  | 28,407 |  |  |  |  |  |
| Commercial and other industrial | 24,672 |  |  | 17,050 |  |  |  |  |  |
| Traction power | 4,345 |  |  | 7,072 |  |  |  |  |  |
| All others | 12,294 |  |  | 8,329 |  |  |  |  |  |
| Total revenues by market sector | $ | 194,017 |  |  | $ | 126,858 |  |  |  |  |  |
  (was, 2023-08-02, similarity 0.7175):
[0000080420-23-000038:note_history:26]
|  | Three months ended June 30, |  | Nine months ended June 30, |
|  | 2023 |  | 2022 |  | 2023 |  | 2022 |
| Oil and gas (excludes petrochemical) | $ | 73,452 |  |  | $ | 58,669 |  |  | $ | 179,560 |  |  | $ | 155,324 |  |
| Petrochemical | 21,995 |  |  | 15,187 |  |  | 70,372 |  |  | 51,268 |  |
| Electric utility | 43,824 |  |  | 30,173 |  |  | 114,899 |  |  | 82,079 |  |
| Commercial and other industrial | 35,527 |  |  | 14,966 |  |  | 74,846 |  |  | 30,583 |  |
| Traction power | 7,143 |  |  | 9,775 |  |  | 21,532 |  |  | 31,200 |  |
| All others | 10,424 |  |  | 6,713 |  |  | 29,458 |  |  | 19,453 |  |
| Total revenues by market sector | $ | 192,365 |  |  | $ | 135,483 |  |  | $ | 490,667 |  |  | $ | 369,907 |  |

- removed (2024-01-31):
[0000080420-23-000038:note_history:27]
|  | Three months ended June 30, |  | Nine months ended June 30, |
|  | 2023 |  | 2022 |  | 2023 |  | 2022 |
| United States | $ | 153,258 |  |  | $ | 102,931 |  |  | $ | 387,531 |  |  | $ | 272,069 |  |
| Canada | 21,765 |  |  | 23,599 |  |  | 62,255 |  |  | 60,777 |  |
| Europe, Middle East and Africa | 12,004 |  |  | 6,697 |  |  | 30,521 |  |  | 30,078 |  |
| Asia/Pacific | 2,338 |  |  | 1,645 |  |  | 4,903 |  |  | 4,235 |  |
| Mexico, Central and South America | 3,000 |  |  | 611 |  |  | 5,457 |  |  | 2,748 |  |
| Total revenues by geographic destination | $ | 192,365 |  |  | $ | 135,483 |  |  | $ | 490,667 |  |  | $ | 369,907 |  |


## us-gaap:RevenueFromContractWithCustomerPolicyTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2024-01-31):
[0000080420-24-000008:note_history:28]
Our revenues are primarily generated from the manufacturing of custom-engineered products and systems under long-term fixed-price contracts under which we agree to manufacture various products such as traditional and arc-resistant distribution switchgear and control gear, medium-voltage circuit breakers, monitoring and control communications systems, motor control centers, switches and bus duct systems. These products may be sold separately as an engineered solution but are typically integrated into custom-built enclosures which we also build. These enclosures are referred to as power control room substations (PCRs®), custom-engineered modules or electrical houses (E-Houses). Some contracts may also include the installation and the commissioning of these enclosures.
  (was, 2023-08-02, similarity 0.8851):
[0000080420-23-000038:note_history:28]
Our revenues are primarily generated from the manufacturing of custom-engineered products and systems under long-term fixed-price contracts under which we agree to manufacture various products such as traditional and arc-resistant distribution switchgear and control gear, medium-voltage circuit breakers, monitoring and control communications systems, motor control centers, switches and bus duct systems. These products may be sold separately as an engineered solution but are typically integrated into custom-built enclosures which we also build. These enclosures are referred to as power control room substations

- changed (2024-01-31):
[0000080420-24-000008:note_history:29]
We also have contracts to provide field service inspection, installation, commissioning, modification, and repair services, as well as retrofit and retrofill components for existing systems. If the service contract terms give us the right to invoice the customer for an amount that corresponds directly with the value of our performance completed to date (i.e., a service contract in which we bill a fixed amount for each hour of service provided), then we recognize revenue over time in each reporting period
  (was, 2023-08-02, similarity 0.7055):
[0000080420-23-000038:note_history:29]
We also have contracts to provide field service inspection, installation, commissioning, modification, and repair services, as well as retrofit and retrofill components for existing systems. If the service contract terms give us the right to invoice the customer for an amount that corresponds directly with the value of our performance completed to date (i.e., a service contract in which we bill a fixed amount for each hour of service provided), then we recognize revenue over time in each reporting period corresponding to the amount with which we have the right to invoice. Our performance obligations are satisfied as the work progresses. Revenues from our custom-engineered products and value-added services transferred to customers over time accounted for approximately 94% and 93% of total revenues for the three and nine months ended June 30, 2023, respectively, and 94% of total revenues for the three and nine months ended June 30, 2022.

- added (2024-01-31):
[0000080420-24-000008:note_history:30]
corresponding to the amount that we have the right to invoice. Our performance obligations are satisfied as the work progresses. Revenues from our custom-engineered products and value-added services transferred to customers over time accounted for approximately 94% of revenues for the three months ended December 31, 2023 and 93% of revenues for the three months ended December 31, 2022.

- changed (2024-01-31):
[0000080420-24-000008:note_history:31]
We also have sales orders for spare parts and replacement circuit breakers for switchgear that are obsolete or that are no longer produced by the original manufacturer. Revenues from these sales orders are recognized at the time we fulfill our performance obligation to the customer, which is typically upon shipment and represented approximately 6% of revenues for the three months ended December 31, 2023 and 7% of revenues for the three months ended December 31, 2022.
  (was, 2023-08-02, similarity 0.8474):
[0000080420-23-000038:note_history:31]
We also have sales orders for spare parts and replacement circuit breakers for switchgear that are obsolete or that are no longer produced by the original manufacturer. Revenues from these sales orders are recognized at the time we fulfill our performance obligation to the customer, which is typically upon shipment and represented approximately 6% and 7% of total revenues for the three and nine months ended June 30, 2023, respectively, and 6% of total revenues for the three and nine months ended June 30, 2022.

- changed (2024-01-31):
[0000080420-24-000008:note_history:32]
Actual revenues and project costs may vary from previous estimates due to changes in a variety of factors. The cost estimation process is based upon the professional knowledge and experience of our engineers, project managers and financial professionals. Factors that are considered in estimating the work to be completed and ultimate contract recovery include the availability and productivity of labor, the nature and complexity of the work to be performed, the availability of materials, and the effect of any delays on our project performance. We periodically review our job performance, job conditions, estimated profitability and final contract settlements, including our estimate of total costs and make revisions to costs and income in the period in which the revisions are probable and reasonably estimable. We bear the risk of cost overruns in most of our contracts, which may result in reduced profits. Whenever revisions of estimated contract costs and contract values indicate that the contract costs will exceed estimated revenues, thus creating a loss, a provision for the total estimated loss is recorded in that period.
  (was, 2023-08-02, similarity 0.99):
[0000080420-23-000038:note_history:32]
Actual revenues and project costs may vary from previous estimates due to changes in a variety of factors. The cost estimation process is based upon the professional knowledge and experience of our engineers, project managers and financial professionals. Factors that are considered in estimating the work to be completed and ultimate contract recovery include the 
availability and productivity of labor, the nature and complexity of the work to be performed, the availability of materials, and the effect of any delays on our project performance. We periodically review our job performance, job conditions, estimated profitability and final contract settlements, including our estimate of total costs and make revisions to costs and income in the period in which the revisions are probable and reasonably estimable. We bear the risk of cost overruns in most of our contracts, which may result in reduced profits. Whenever revisions of estimated contract costs and contract values indicate that the contract costs will exceed estimated revenues, thus creating a loss, a provision for the total estimated loss is recorded in that period.
Variable Consideration

- added (2024-01-31):
[0000080420-24-000008:note_history:33]
Variable Consideration

- removed (2024-01-31):
[0000080420-23-000038:note_history:34]
(PCRs®), custom-engineered modules or electrical houses (E-Houses). Some contracts may also include the installation and the commissioning of these enclosures.


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2024-01-31):
[0000080420-24-000008:note_history:35]
Our revenues are primarily generated from the manufacturing of custom-engineered products and systems under long-term fixed-price contracts under which we agree to manufacture various products such as traditional and arc-resistant distribution switchgear and control gear, medium-voltage circuit breakers, monitoring and control communications systems, motor control centers, switches and bus duct systems. These products may be sold separately as an engineered solution but are typically integrated into custom-built enclosures which we also build. These enclosures are referred to as power control room substations (PCRs®), custom-engineered modules or electrical houses (E-Houses). Some contracts may also include the installation and the commissioning of these enclosures.
  (was, 2023-08-02, similarity 0.8851):
[0000080420-23-000038:note_history:35]
Our revenues are primarily generated from the manufacturing of custom-engineered products and systems under long-term fixed-price contracts under which we agree to manufacture various products such as traditional and arc-resistant distribution switchgear and control gear, medium-voltage circuit breakers, monitoring and control communications systems, motor control centers, switches and bus duct systems. These products may be sold separately as an engineered solution but are typically integrated into custom-built enclosures which we also build. These enclosures are referred to as power control room substations

- changed (2024-01-31):
[0000080420-24-000008:note_history:36]
We also have contracts to provide field service inspection, installation, commissioning, modification, and repair services, as well as retrofit and retrofill components for existing systems. If the service contract terms give us the right to invoice the customer for an amount that corresponds directly with the value of our performance completed to date (i.e., a service contract in which we bill a fixed amount for each hour of service provided), then we recognize revenue over time in each reporting period
  (was, 2023-08-02, similarity 0.7055):
[0000080420-23-000038:note_history:36]
We also have contracts to provide field service inspection, installation, commissioning, modification, and repair services, as well as retrofit and retrofill components for existing systems. If the service contract terms give us the right to invoice the customer for an amount that corresponds directly with the value of our performance completed to date (i.e., a service contract in which we bill a fixed amount for each hour of service provided), then we recognize revenue over time in each reporting period corresponding to the amount with which we have the right to invoice. Our performance obligations are satisfied as the work progresses. Revenues from our custom-engineered products and value-added services transferred to customers over time accounted for approximately 94% and 93% of total revenues for the three and nine months ended June 30, 2023, respectively, and 94% of total revenues for the three and nine months ended June 30, 2022.

- added (2024-01-31):
[0000080420-24-000008:note_history:37]
corresponding to the amount that we have the right to invoice. Our performance obligations are satisfied as the work progresses. Revenues from our custom-engineered products and value-added services transferred to customers over time accounted for approximately 94% of revenues for the three months ended December 31, 2023 and 93% of revenues for the three months ended December 31, 2022.

- changed (2024-01-31):
[0000080420-24-000008:note_history:38]
We also have sales orders for spare parts and replacement circuit breakers for switchgear that are obsolete or that are no longer produced by the original manufacturer. Revenues from these sales orders are recognized at the time we fulfill our performance obligation to the customer, which is typically upon shipment and represented approximately 6% of revenues for the three months ended December 31, 2023 and 7% of revenues for the three months ended December 31, 2022.
  (was, 2023-08-02, similarity 0.8474):
[0000080420-23-000038:note_history:38]
We also have sales orders for spare parts and replacement circuit breakers for switchgear that are obsolete or that are no longer produced by the original manufacturer. Revenues from these sales orders are recognized at the time we fulfill our performance obligation to the customer, which is typically upon shipment and represented approximately 6% and 7% of total revenues for the three and nine months ended June 30, 2023, respectively, and 6% of total revenues for the three and nine months ended June 30, 2022.

- changed (2024-01-31):
[0000080420-24-000008:note_history:39]
Remaining unsatisfied performance obligations, which we refer to as backlog, represent the estimated transaction price for goods and services for which we have a material right, but work has not been performed. As of December 31, 2023, we had backlog of $1.3 billion, of which approximately $713 million is expected to be recognized as revenue within the next twelve months. Backlog may not be indicative of future operating results as orders may be cancelled or modified by our customers. Our backlog does not include service and maintenance-type contracts for which we have the right to invoice as services are performed.
  (was, 2023-08-02, similarity 0.9902):
[0000080420-23-000038:note_history:39]
Remaining unsatisfied performance obligations, which we refer to as backlog, represent the estimated transaction price for goods and services for which we have a material right, but work has not been performed. As of June 30, 2023, we had backlog of $1.3 billion, of which approximately $690 million is expected to be recognized as revenue within the next twelve months. Backlog may not be indicative of future operating results as orders may be cancelled or modified by our customers. Our backlog does not include service and maintenance-type contracts for which we have the right to invoice as services are performed.

- added (2024-01-31):
[0000080420-24-000008:note_history:40]
Actual revenues and project costs may vary from previous estimates due to changes in a variety of factors. The cost estimation process is based upon the professional knowledge and experience of our engineers, project managers and financial professionals. Factors that are considered in estimating the work to be completed and ultimate contract recovery include the availability and productivity of labor, the nature and complexity of the work to be performed, the availability of materials, and the effect of any delays on our project performance. We periodically review our job performance, job conditions, estimated profitability and final contract settlements, including our estimate of total costs and make revisions to costs and income in the period in which the revisions are probable and reasonably estimable. We bear the risk of cost overruns in most of our contracts, which may result in reduced profits. Whenever revisions of estimated contract costs and contract values indicate that the contract costs will exceed estimated revenues, thus creating a loss, a provision for the total estimated loss is recorded in that period.

- changed (2024-01-31):
[0000080420-24-000008:note_history:41]
For the three months ended December 31, 2023 and 2022, our operating results were positively impacted by $5.4 million and $3.6 million, respectively, as a result of net changes in contract estimates related to projects in progress at the beginning of the respective period. These changes in estimates resulted primarily from favorable project execution, reduced cost estimates and negotiations of variable consideration, discussed below, as well as revenue recognized from project cancellations and other changes in facts and circumstances during these periods. Gross unfavorable changes in contract estimates were immaterial for both the three months ended December 31, 2023 and 2022.
  (was, 2023-08-02, similarity 0.8395):
[0000080420-23-000038:note_history:41]
For the nine months ended June 30, 2023 and 2022, our operating results were positively impacted by $13.2 million and $5.9 million, respectively, as a result of net changes in contract estimates related to projects in progress at the beginning of the respective period. These changes in estimates resulted primarily from favorable project execution, reduced cost estimates and negotiations of variable consideration, discussed below, as well as revenue recognized from project cancellations and other changes in facts and circumstances during these periods. Project cancellations on two projects increased gross profit for the nine months ended June 30, 2023 by $3.4 million. Gross unfavorable changes in contract estimates were immaterial for both the nine months ended June 30, 2023 and 2022.

- changed (2024-01-31):
[0000080420-24-000008:note_history:42]
Contract assets and liabilities as of December 31, 2023 and September 30, 2023 are summarized below (in thousands):
  (was, 2023-08-02, similarity 0.9515):
[0000080420-23-000038:note_history:42]
Contract assets and liabilities as of June 30, 2023 and September 30, 2022 are summarized below (in thousands):

- changed (2024-01-31):
[0000080420-24-000008:note_history:43]
|  | December 31, 2023 |  | September 30, 2023 |
| Contract assets | $ | 67,594 |  |  | $ | 60,621 |  |
| Contract liabilities | (328,888) |  |  | (279,796) |  |
| Net contract liability | $ | (261,294) |  |  | $ | (219,175) |  |
  (was, 2023-08-02, similarity 0.9429):
[0000080420-23-000038:note_history:43]
|  | June 30, 2023 |  | September 30, 2022 |
| Contract assets | $ | 56,148 |  |  | $ | 88,351 |  |
| Contract liabilities | (225,767) |  |  | (79,857) |  |
| Net contract asset (liability) | $ | (169,619) |  |  | $ | 8,494 |  |

- added (2024-01-31):
[0000080420-24-000008:note_history:44]
Our net contract billing position remained a net liability at both December 31, 2023 and September 30, 2023, primarily due to favorable contract billing milestones. We typically allocate a significant percentage of the progress billing to the early stages of the contract. These favorable billing milestones are driving the increase in the net contract liability at December 31, 2023. To determine the amount of revenue recognized during the period from contract liabilities, we first allocate revenue to the individual contract liability balance outstanding at the beginning of the period until the revenue exceeds that balance. During the three months ended December 31, 2023, we recognized revenue of $103.5 million that was related to contract liabilities outstanding at September 30, 2023.

- changed (2024-01-31):
[0000080420-24-000008:note_history:45]
The timing of our invoice process is typically dependent on the completion of certain milestones and contract terms and subject to agreement by our customer. Payment is typically expected within 30 days of invoice. Any uncollected invoiced amounts for our performance obligations recognized over time, including contract retentions, are recorded as accounts receivable in the Condensed Consolidated Balance Sheets. Certain contracts allow customers to withhold a small percentage of billings pursuant to retainage provisions, and such amounts are generally due upon completion of the contract and acceptance of the project by the customer. Based on our experience in recent years, the majority of these retainage balances are expected to be collected within approximately twelve months. As of December 31, 2023 and September 30, 2023, we had retention amounts of $7.3 million and $7.4 million, respectively. Of the retained amount at December 31, 2023, $7.1 million is expected to be collected in the next twelve months and is recorded in accounts receivable. The remaining $0.2 million is recorded in other assets.
  (was, 2023-08-02, similarity 0.9745):
[0000080420-23-000038:note_history:45]
The timing of our invoice process is typically dependent on the completion of certain milestones and contract terms and subject to agreement by our customer. Payment is typically expected within 30 days of invoice. Any uncollected invoiced amounts for our performance obligations recognized over time, including contract retentions, are recorded as accounts receivable in the Condensed Consolidated Balance Sheets. Certain contracts allow customers to withhold a small percentage of billings pursuant to retainage provisions, and such amounts are generally due upon completion of the contract and acceptance of the project by the customer. Based on our experience in recent years, the majority of these retainage balances are expected to be collected within approximately twelve months. As of June 30, 2023 and September 30, 2022, accounts receivable included retention amounts of $7.0 million and $6.9 million, respectively. Of the retained amount at June 30, 2023, $6.8 million is expected to be collected in the next twelve months and is recorded in accounts receivable. The remaining $0.2 million is recorded in other assets.

- changed (2024-01-31):
[0000080420-24-000008:note_history:46]
The following tables present our disaggregated revenue by geographic destination and market sector for the three months ended December 31, 2023 and 2022 (in thousands):
  (was, 2023-08-02, similarity 0.9415):
[0000080420-23-000038:note_history:46]
The following tables present our disaggregated revenue by geographic destination and market sector for the three and nine months ended June 30, 2023 and 2022 (in thousands):

- added (2024-01-31):
[0000080420-24-000008:note_history:47]
|  | Three months ended December 31, |  |  |
|  | 2023 |  | 2022 |  |  |  |  |
| United States | $ | 159,860 |  |  | $ | 100,112 |  |  |  |  |  |
| Canada | 20,350 |  |  | 18,496 |  |  |  |  |  |
| Europe | 6,532 |  |  | 4,134 |  |  |  |  |  |
| Middle East and Africa | 3,275 |  |  | 2,425 |  |  |  |  |  |
| Mexico, Central and South America | 2,657 |  |  | 915 |  |  |  |  |  |
| Asia/Pacific | 1,343 |  |  | 776 |  |  |  |  |  |
| Total revenues by geographic destination | $ | 194,017 |  |  | $ | 126,858 |  |  |  |  |  |

- changed (2024-01-31):
[0000080420-24-000008:note_history:48]
|  | Three months ended December 31, |  |  |
|  | 2023 |  | 2022 |  |  |  |  |
| Oil and gas (excludes petrochemical) | $ | 83,636 |  |  | $ | 43,510 |  |  |  |  |  |
| Petrochemical | 28,367 |  |  | 22,490 |  |  |  |  |  |
| Electric utility | 40,703 |  |  | 28,407 |  |  |  |  |  |
| Commercial and other industrial | 24,672 |  |  | 17,050 |  |  |  |  |  |
| Traction power | 4,345 |  |  | 7,072 |  |  |  |  |  |
| All others | 12,294 |  |  | 8,329 |  |  |  |  |  |
| Total revenues by market sector | $ | 194,017 |  |  | $ | 126,858 |  |  |  |  |  |
  (was, 2023-08-02, similarity 0.7175):
[0000080420-23-000038:note_history:48]
|  | Three months ended June 30, |  | Nine months ended June 30, |
|  | 2023 |  | 2022 |  | 2023 |  | 2022 |
| Oil and gas (excludes petrochemical) | $ | 73,452 |  |  | $ | 58,669 |  |  | $ | 179,560 |  |  | $ | 155,324 |  |
| Petrochemical | 21,995 |  |  | 15,187 |  |  | 70,372 |  |  | 51,268 |  |
| Electric utility | 43,824 |  |  | 30,173 |  |  | 114,899 |  |  | 82,079 |  |
| Commercial and other industrial | 35,527 |  |  | 14,966 |  |  | 74,846 |  |  | 30,583 |  |
| Traction power | 7,143 |  |  | 9,775 |  |  | 21,532 |  |  | 31,200 |  |
| All others | 10,424 |  |  | 6,713 |  |  | 29,458 |  |  | 19,453 |  |
| Total revenues by market sector | $ | 192,365 |  |  | $ | 135,483 |  |  | $ | 490,667 |  |  | $ | 369,907 |  |

- removed (2024-01-31):
[0000080420-23-000038:note_history:49]
(PCRs®), custom-engineered modules or electrical houses (E-Houses). Some contracts may also include the installation and the commissioning of these enclosures.

- removed (2024-01-31):
[0000080420-23-000038:note_history:50]
Actual revenues and project costs may vary from previous estimates due to changes in a variety of factors. The cost estimation process is based upon the professional knowledge and experience of our engineers, project managers and financial professionals. Factors that are considered in estimating the work to be completed and ultimate contract recovery include the

- removed (2024-01-31):
[0000080420-23-000038:note_history:51]
availability and productivity of labor, the nature and complexity of the work to be performed, the availability of materials, and the effect of any delays on our project performance. We periodically review our job performance, job conditions, estimated profitability and final contract settlements, including our estimate of total costs and make revisions to costs and income in the period in which the revisions are probable and reasonably estimable. We bear the risk of cost overruns in most of our contracts, which may result in reduced profits. Whenever revisions of estimated contract costs and contract values indicate that the contract costs will exceed estimated revenues, thus creating a loss, a provision for the total estimated loss is recorded in that period.

- removed (2024-01-31):
[0000080420-23-000038:note_history:52]
Our net contract billing position improved to a net liability at June 30, 2023 from a net asset position at September 30, 2022 primarily due to favorable contract billing milestones. We typically allocate a significant percentage of the progress billing to the early stages of the contract. These favorable billing milestones along with our increase in project backlog are driving the

- removed (2024-01-31):
[0000080420-23-000038:note_history:53]
increase in the net contract liability at June 30, 2023. To determine the amount of revenue recognized during the period from contract liabilities, we first allocate revenue to the individual contract liability balance outstanding at the beginning of the period until the revenue exceeds that balance. During the nine months ended June 30, 2023, we recognized revenue of $68.1 million that was related to contract liabilities outstanding at September 30, 2022.

- removed (2024-01-31):
[0000080420-23-000038:note_history:54]
|  | Three months ended June 30, |  | Nine months ended June 30, |
|  | 2023 |  | 2022 |  | 2023 |  | 2022 |
| United States | $ | 153,258 |  |  | $ | 102,931 |  |  | $ | 387,531 |  |  | $ | 272,069 |  |
| Canada | 21,765 |  |  | 23,599 |  |  | 62,255 |  |  | 60,777 |  |
| Europe, Middle East and Africa | 12,004 |  |  | 6,697 |  |  | 30,521 |  |  | 30,078 |  |
| Asia/Pacific | 2,338 |  |  | 1,645 |  |  | 4,903 |  |  | 4,235 |  |
| Mexico, Central and South America | 3,000 |  |  | 611 |  |  | 5,457 |  |  | 2,748 |  |
| Total revenues by geographic destination | $ | 192,365 |  |  | $ | 135,483 |  |  | $ | 490,667 |  |  | $ | 369,907 |  |


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: tag_name, score: 1.0

- added (2024-01-31):
[0000080420-24-000008:note_history:55]
On January 30, 2024, our Board of Directors approved an increase to the quarterly cash dividend on our common stock to $0.2650 per share, equating to an annualized dividend of $1.06 per share from the current amount of $1.05 per share. The dividend is payable on March 13, 2024 to shareholders of record at the close of business on February 14, 2024.

- removed (2024-01-31):
[0000080420-23-000038:note_history:56]
On August 1, 2023, our Board of Directors declared a quarterly cash dividend on our common stock in the amount of $0.2625 per share. The dividend is payable on September 20, 2023 to shareholders of record at the close of business on August 16, 2023.
