# POWL MD&A — 0000080420-24-000008


## mdna

[0000080420-24-000008:mdna:1]
[same as prior period, unchanged from 0000080420-23-000038:mdna:1]

[0000080420-24-000008:mdna:2]
The following discussion and analysis of our financial condition and results of operations should be read in conjunction with the accompanying condensed consolidated financial statements and related notes included elsewhere in this Quarterly Report on Form 10-Q and with our Annual Report on Form 10-K for the fiscal year ended September 30, 2023, which was filed with the Securities and Exchange Commission (SEC) on December 6, 2023 and is available on the SEC’s website at www.sec.gov.

[0000080420-24-000008:mdna:3]
[same as prior period, unchanged from 0000080420-23-000038:mdna:3]

[0000080420-24-000008:mdna:4]
We develop, design, manufacture and service custom-engineered equipment and systems that (1) distribute, control and monitor the flow of electrical energy and (2) provide protection to motors, transformers and other electrically powered equipment. We are headquartered in Houston, Texas, and serve the oil and gas and petrochemical markets, which include onshore and offshore production, liquefied natural gas (LNG) facilities and terminals, pipelines, refineries and petrochemical plants. Additional markets include electric utility, light rail traction power as well as mining and metals, pulp and paper, data centers and other municipal, commercial and industrial markets. Revenues and costs are primarily related to custom engineered-to-order equipment and systems and are accounted for under percentage-of-completion accounting, which precludes us from providing detailed price and volume information. Our backlog includes various projects that typically take a number of months to produce.

[0000080420-24-000008:mdna:5]
[same as prior period, unchanged from 0000080420-23-000038:mdna:5]

[0000080420-24-000008:mdna:6]
Within the industrial sector, specifically oil, gas and petrochemical, the demand for our electrical distribution solutions is very cyclical and closely correlated to the level of capital expenditures of our end-user customers as well as prevailing global economic conditions. The North American market is responding to increased international demand for LNG and gas-to-chemical processes utilizing low-cost gas feedstocks. As a result, we have been awarded a number of large LNG and petrochemical contracts in Fiscal 2023 that positively impact our backlog in Fiscal 2024.

[0000080420-24-000008:mdna:7]
One element of our strategic focus is to strengthen our project portfolio beyond our core oil, gas and petrochemical end market sectors. Diversification efforts outside of our core oil, gas and petrochemical end markets have resulted in a strong backlog across the utility and commercial and other industrial sectors in Fiscal 2023, and the trend continues in the first quarter of Fiscal 2024. As of December 31, 2023, our backlog remained at $1.3 billion.

[0000080420-24-000008:mdna:8]
Even though commodity prices remained stable in Fiscal 2023 and throughout the first quarter of Fiscal 2024, we continue to experience supply chain delays for specific engineered components and continue to work with our suppliers to meet our customer commitments. In response to the increased cost environment and supply chain challenges, we strive to effectively manage our product pricing, delivery schedules and bid validity dates with our customers, as well as improve factory efficiencies and project execution.

[0000080420-24-000008:mdna:9]
[same as prior period, unchanged from 0000080420-23-000038:mdna:9]

[0000080420-24-000008:mdna:10]
Quarter Ended December 31, 2023 Compared to the Quarter Ended December 31, 2022 (Unaudited)

[0000080420-24-000008:mdna:11]
[same as prior period, unchanged from 0000080420-23-000038:mdna:11]

[0000080420-24-000008:mdna:12]
Revenues increased by 53%, or $67.2 million, to $194.0 million in the first quarter of Fiscal 2024, primarily driven by the increase in project backlog resulting from large contracts awarded throughout Fiscal 2023. Domestic revenues increased by 60%, or $59.7 million, to $159.9 million in the first quarter of Fiscal 2024. International revenues increased by 28%, or $7.4 million, to $34.1 million in the first quarter of Fiscal 2024. Our international revenues include both revenues generated from our international facilities as well as revenues from export projects generated at our domestic facilities.

[0000080420-24-000008:mdna:13]
In the first quarter of Fiscal 2024, revenue from our core oil and gas markets (excluding petrochemical) increased by 92%, or $40.1 million, to $83.6 million; petrochemical revenue increased by 26%, or $5.9 million, to $28.4 million; revenue from our utility markets increased by 43%, or $12.3 million, to $40.7 million; commercial and other industrial market revenue increased by 45%, or $7.6 million, to $24.7 million; and revenue from all other markets combined increased by 48%, or $4.0 million, to

[0000080420-24-000008:mdna:14]
$12.3 million. These increases in revenue were driven by improved market conditions and increased capital spending in our core oil, gas and petrochemical markets, as well as our strategic effort to diversify our business into utility and other industrial markets. Revenue from our traction market decreased by 39%, or $2.7 million, to $4.3 million in the first quarter of Fiscal 2024 due to less project volume in this market.

[0000080420-24-000008:mdna:15]
Gross profit increased by 148%, or $28.7 million, to $48.2 million for the first quarter of Fiscal 2024.  Gross profit as a percentage of revenues increased to 25% in the first quarter of Fiscal 2024, compared to 15% in the first quarter of Fiscal 2023. This increase in gross profit reflects the higher volume levels across our manufacturing facilities driving favorable volume leverage, efficient project execution, as well as our continuing effort to improve key factory efficiencies and to effectively manage product pricing that corresponds to current cost levels.

[0000080420-24-000008:mdna:16]
[same as prior period, unchanged from 0000080420-23-000038:mdna:15]

[0000080420-24-000008:mdna:17]
Selling, general and administrative expenses increased by 21%, or $3.5 million, to $20.3 million in the first quarter of Fiscal 2024, due to increased variable incentive compensation expenses. Selling, general and administrative expenses as a percentage of revenues decreased to 10% during the first quarter of Fiscal 2024 compared to 13% during the first quarter of Fiscal 2023, resulting from higher revenues on our existing cost structure.

[0000080420-24-000008:mdna:18]
Income Tax Provision

[0000080420-24-000008:mdna:19]
We recorded an income tax provision of $5.8 million in the first quarter of Fiscal 2024, compared to an income tax provision of $0.5 million in the first quarter of Fiscal 2023. The effective tax rate for the first quarter of Fiscal 2024 was 19%, compared to an effective tax rate of 28% for the first quarter of Fiscal 2023. For each of the three months ended December 31, 2023 and December 31, 2022, the effective tax rate was favorably impacted by the estimated Research and Development Tax Credit (R&D Tax Credit). We recognized an additional benefit in the first quarter of Fiscal 2024 related to a discrete item for the vesting of restricted stock units. Conversely, in the first quarter of Fiscal 2023, we recognized an unfavorable discrete item related to the vesting of restricted stock units.

[0000080420-24-000008:mdna:20]
[same as prior period, unchanged from 0000080420-23-000038:mdna:21]

[0000080420-24-000008:mdna:21]
In the first quarter of Fiscal 2024, we recorded net income of $24.1 million, or $1.98 per diluted share, compared to net income of $1.2 million, or $0.10 per diluted share, in the first quarter of Fiscal 2023. This increase in net income was primarily due to the strength and quality of our backlog at the end of Fiscal 2023, which has led to an increase in revenue coupled with improved project margins.

[0000080420-24-000008:mdna:22]
[same as prior period, unchanged from 0000080420-23-000038:mdna:23]

[0000080420-24-000008:mdna:23]
The order backlog at December 31, 2023 was $1.3 billion, consistent with our September 30, 2023 backlog, and an increase of 91% from $679.8 million at December 31, 2022. Bookings, net of cancellations and scope reductions, decreased by 7% in the first quarter of Fiscal 2024 to $197.5 million, compared to $211.8 million in the first quarter of Fiscal 2023.

[0000080420-24-000008:mdna:24]
[same as prior period, unchanged from 0000080420-23-000038:mdna:40]

[0000080420-24-000008:mdna:25]
We continue to experience a cyclical recovery across our core oil, gas and petrochemical markets, combined with increased global demand for cleaner-burning fuels as well as related processes utilizing lower cost gas feedstocks. Our order activity in most of our core markets remains active and diversification efforts outside of our core oil, gas and petrochemical end markets continue to be a positive catalyst. Our backlog remained at $1.3 billion as of December 31, 2023, of which approximately $713 million of the backlog is expected to be recognized as revenue within the next twelve months. Although current commercial activity remains active in most of the sectors that we compete in, we remain attentive to the macro environment and geopolitical events that may have an impact on future market activity.

[0000080420-24-000008:mdna:26]
Our operating results are impacted by several factors such as the timing of new order awards, project backlog, changes in project cost estimates, customer approval of final engineering specifications and delays in customer construction schedules, all of which contribute to short-term earnings variability and the timing of project execution. Our operating results also have been, and may continue to be, impacted by the timing and resolution of change orders and the resolution of potential contract claims and liquidated damages, all of which could improve or deteriorate gross margins during the period in which these items are resolved with our customers. Disruptions in the global supply chain have, in the past, negatively impacted our business and operating results due to the limited availability resulting in uncertainty in the timing of the receipt of key component parts and commodities. We continue to remain focused on the variables that impact our markets as well as cost management, labor availability and supply chain challenges.

[0000080420-24-000008:mdna:27]
[same as prior period, unchanged from 0000080420-23-000038:mdna:43]

[0000080420-24-000008:mdna:28]
As of December 31, 2023, current assets exceeded current liabilities by 1.6 times.

[0000080420-24-000008:mdna:29]
Cash, cash equivalents and short-term investments increased to $355.3 million at December 31, 2023, compared to $279.0 million at September 30, 2023. This increase in cash, cash equivalents and short-term investments was primarily driven by the increased project volume and favorable timing of contract billing milestones on many of our large projects. We typically allocate a significant percentage of the progress billing to the early stages of the contract. These favorable billing milestones are the primary drivers for the increase in cash at December 31, 2023. We believe that our strong working capital position, available borrowings under our credit facility and available cash, cash equivalents and short-term investments should be sufficient to support our future operating activities, working capital requirements, capital improvements, as well as research and development initiatives for the foreseeable future.

[0000080420-24-000008:mdna:30]
On October 4, 2023, we entered into a third amendment (the Third Amendment) to our credit agreement with Bank of America, N.A. (as amended, the U.S. Revolver). The Third Amendment added Texas Capital Bank as Syndication Agent and a lender, increased the amount of the revolving line of credit from $125.0 million to $150.0 million, and extended the expiry date to October 4, 2028. As amended by the Third Amendment, the lesser of (a) $60 million, (b) 60% of available cash, and (c) the aggregate face amount of the issued but undrawn letters of credit that are not cash-secured, shall be deducted from consolidated funded indebtedness, when calculating the consolidated net leverage ratio. We have the option to cash collateralize all or a portion of the letters of credit outstanding, which would favorably impact the consolidated funded indebtedness calculation and the consolidated net leverage ratio. We have the option to cash collateralize all or a portion of the letters of credit outstanding, which would favorably impact the consolidated funded indebtedness calculation and the consolidated net leverage ratio.

[0000080420-24-000008:mdna:31]
As of December 31, 2023, there were no amounts borrowed under the U.S. Revolver, and letters of credit outstanding were $87.1 million. There was $62.9 million available for the issuance of letters of credit and borrowings under the U.S. Revolver as of December 31, 2023. For further information regarding our debt, see Notes E and F of Notes to Condensed Consolidated Financial Statements.

[0000080420-24-000008:mdna:32]
Approximately $64.2 million of our cash, cash equivalents and short-term investments at December 31, 2023 was held outside of the U.S. for our international operations. It is our intention to indefinitely reinvest all current and future foreign earnings internationally in order to ensure sufficient working capital to support our international operations. In the event that we elect to repatriate some or all of the foreign earnings that were previously deemed to be indefinitely reinvested outside the U.S., we may incur additional tax expense upon such repatriation under current tax laws.

[0000080420-24-000008:mdna:33]
[same as prior period, unchanged from 0000080420-23-000038:mdna:50]

[0000080420-24-000008:mdna:34]
Operating activities provided net cash of $83.9 million during the three months ended December 31, 2023 and used net cash of $0.5 million during the same period in Fiscal 2023. Cash flow from operations is primarily influenced by the timing of milestone payments from our customers, project volume and the associated working capital requirements, as well as payment terms with our suppliers. This increase in operating cash flow was primarily due to the increase in project volume, improved project margins, and the favorable timing of contract billing milestones, as well as timely collection of accounts receivable.

[0000080420-24-000008:mdna:35]
[same as prior period, unchanged from 0000080420-23-000038:mdna:52]

[0000080420-24-000008:mdna:36]
Investing activities used $1.5 million during the three months ended December 31, 2023 and provided $1.0 million during the same period in Fiscal 2023. The increase in cash used in investing activities in the first quarter of Fiscal 2024 was primarily due to the timing of short-term investment maturities. In December 2023, we acquired intellectual property for a total consideration of $0.5 million, of which $250 thousand was paid in cash.

[0000080420-24-000008:mdna:37]
[same as prior period, unchanged from 0000080420-23-000038:mdna:54]

[0000080420-24-000008:mdna:38]
Net cash used in financing activities was $7.9 million during the three months ended December 31, 2023 and $3.5 million during the same period in Fiscal 2023. The increase in cash used in financing activities was primarily due to cash payments related to shares withheld in lieu of employee tax withholding, largely driven by the significant increase in our share price in the current fiscal quarter compared to the same period of Fiscal 2023.

[0000080420-24-000008:mdna:39]
[same as prior period, unchanged from 0000080420-23-000038:mdna:56]

[0000080420-24-000008:mdna:40]
The discussion and analysis of our financial condition and results of operations are based on our condensed consolidated financial statements, which have been prepared in accordance with U.S. GAAP. The preparation of our condensed consolidated financial statements requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities, disclosures of contingent assets and liabilities known to exist at the date of the condensed consolidated financial statements and the reported amounts of revenues and expenses during the reporting period. We evaluate our estimates on an ongoing basis, based on historical experience and on various other assumptions that are believed to be reasonable under the circumstances. There can be no assurance that actual results will be consistent with those estimates.

[0000080420-24-000008:mdna:41]
There have been no material changes to our critical accounting policies as disclosed in our Annual Report on Form 10-K for the fiscal year ended September 30, 2023, which was filed with the SEC on December 6, 2023.
