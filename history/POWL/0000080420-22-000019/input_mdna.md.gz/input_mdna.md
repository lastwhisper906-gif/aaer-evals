# POWL MD&A — 0000080420-22-000019


## mdna

[0000080420-22-000019:mdna:1]
[same as prior period, unchanged from 0000080420-22-000007:mdna:1]

[0000080420-22-000019:mdna:2]
[same as prior period, unchanged from 0000080420-22-000007:mdna:2]

[0000080420-22-000019:mdna:3]
[same as prior period, unchanged from 0000080420-22-000007:mdna:3]

[0000080420-22-000019:mdna:4]
[same as prior period, unchanged from 0000080420-22-000007:mdna:4]

[0000080420-22-000019:mdna:5]
The markets in which we participate are capital-intensive and cyclical in nature. Cyclicality is predominantly driven by customer demand, global economic and geopolitical conditions and anticipated environmental, safety or regulatory changes which affect the manner in which our customers proceed with capital investments. Our customers analyze various factors, including the demand and price for oil, gas and electrical energy, the overall economic and financial environment, governmental budgets, regulatory actions and environmental concerns. These factors influence the release of new capital projects by our customers, which are traditionally awarded in competitive bid situations. Scheduling of projects is matched to customer requirements, and projects typically take a number of months to produce. Schedules may change during the course of any particular project, and our operating results can, therefore, be impacted by factors outside of our control.

[0000080420-22-000019:mdna:6]
[same as prior period, unchanged from 0000080420-22-000007:mdna:6]

[0000080420-22-000019:mdna:7]
Historically, the combination of a growing global economy, abundant sources of favorably priced natural gas feedstock, and an energy industry focus on transition to natural gas and cleaner-burning fuels drove an increase in capital investment opportunities, specifically across the oil, gas and petrochemical sectors. Some of these opportunities were for natural gas related projects targeting global demand for cleaner-burning fuels. Additionally, projects within the domestic petrochemical sector benefited from the low feedstock prices of natural gas. Specific to natural gas, the business was awarded a substantial contract in the second quarter of Fiscal 2020 that will support the integrated electrical distribution requirements for a large domestic industrial complex and should be substantially completed in Fiscal 2022. We began to experience reduced commercial activity in Fiscal 2020 driven in large part by the uncertainties across our industrial end markets in the U.S. resulting from the COVID-19 pandemic. Considering the long cycle nature of our business, these cyclical conditions may persist throughout the remainder of Fiscal 2022.

[0000080420-22-000019:mdna:8]
Impact of Global Economic Uncertainty and Oil and Gas Commodity Market Volatility on Powell

[0000080420-22-000019:mdna:9]
Various factors resulting in global economic uncertainty have negatively impacted our results over the last 18 months. In particular, the COVID-19 pandemic continues to impact global energy markets. This pandemic has negatively impacted demand, which in turn has resulted in considerable volatility across global oil and gas commodity markets. The pandemic and global economic uncertainty have had a negative impact on the demand for our products and services as well as our operations as a result of the associated reduction in oil and gas demand and volatility in commodity prices noted above. As a result, some of our industrial customers have deferred or suspended their planned capital expenditures. During this period, certain of our customers have asked that we delay or cancel our manufacturing on their projects as their operations have been negatively impacted by this pandemic and the reduced oil and gas demand, which has resulted in recognition of cancellation fees based on contract terms and the extent of our progress on the projects. We continue to work with our key suppliers who are facing various issues related to the availability and timing of the receipt of key component parts and commodities to ensure that we are able to meet our customer commitments.

[0000080420-22-000019:mdna:10]
In response to the lower demand across select end markets, we have taken and will continue to take various actions to reduce costs. During Fiscal 2020, we reduced our global workforce and our capital and discretionary spending in response to business conditions. We continued to operate at these lower thresholds throughout Fiscal 2021 and the first half of Fiscal 2022 and will continue to consistently monitor the macro-economic conditions throughout the remainder of Fiscal 2022.

[0000080420-22-000019:mdna:11]
As discussed further under the heading "Outlook" below, it is difficult to predict the economic impact that this pandemic, as well as reduced oil and gas demand, supply chain issues and inflationary pressures, may have on our business, results of operations and cash flows going forward.

[0000080420-22-000019:mdna:12]
[same as prior period, unchanged from 0000080420-22-000007:mdna:12]

[0000080420-22-000019:mdna:13]
Quarter Ended March 31, 2022 Compared to the Quarter Ended March 31, 2021 (Unaudited)

[0000080420-22-000019:mdna:14]
[same as prior period, unchanged from 0000080420-22-000007:mdna:14]

[0000080420-22-000019:mdna:15]
Revenues increased by 8%, or $9.1 million, to $127.9 million in the second quarter of Fiscal 2022. Domestic revenues decreased by 1%, or $0.9 million, to $87.0 million in the second quarter of Fiscal 2022. Included in our domestic revenues in the oil and gas markets is our large domestic industrial project awarded in Fiscal 2020, which accounted for approximately 16% of our consolidated revenues for the second quarter of Fiscal 2022 compared to 20% in the same period of the prior year. International revenues increased by 33%, or $10.1 million, to $40.9 million in the second quarter of Fiscal 2022. Our international revenues include both revenues generated from our international facilities as well as revenues from export projects generated at our domestic facilities.

[0000080420-22-000019:mdna:16]
Revenue from our core oil and gas markets (excluding petrochemical) increased by 7%, or $3.5 million, to $53.6 million in the second quarter of Fiscal 2022, while petrochemical revenue increased by 85%, or $8.7 million, to $18.9 million in the second quarter of Fiscal 2022, primarily due to project mix. Revenue from our utility markets increased by 7%, or $1.9 million, to $30.4 million, and traction market revenue decreased by 34%, or $5.1 million, to $10.1 million in the second quarter of Fiscal 2022. Revenue from all other markets combined increased by $0.2 million to $14.9 million in the second quarter of Fiscal 2022.

[0000080420-22-000019:mdna:17]
Gross profit increased by 11%, or $1.9 million, to $19.1 million for the second quarter of Fiscal 2022.  Gross profit as a percentage of revenues increased to 15% in the second quarter of Fiscal 2022, compared to 14% in the second quarter of Fiscal 2021. The increase in gross profit was driven predominately by increased volume and operating efficiencies across most of our North American operations and improved project execution and performance from our UK operations in the second quarter of Fiscal 2022. This incremental increase in gross profit incorporates favorable productivity and pricing impacts, offset by inflationary pressures across our supply base.

[0000080420-22-000019:mdna:18]
[same as prior period, unchanged from 0000080420-22-000007:mdna:18]

[0000080420-22-000019:mdna:19]
Selling, general and administrative expenses increased by 2%, or $0.4 million, to $17.1 million in the second quarter of Fiscal 2022, primarily due to increased bad debt expense. Selling, general and administrative expenses as a percentage of revenues decreased to 13% during the second quarter of Fiscal 2022 compared to 14% during the second quarter of Fiscal 2021.

[0000080420-22-000019:mdna:20]
Other Income

[0000080420-22-000019:mdna:21]
We recorded other income of $0.3 million in the second quarter of Fiscal 2022 related to a gain on the sale of land. We did not record other income during the second quarter of Fiscal 2021.

[0000080420-22-000019:mdna:22]
[same as prior period, unchanged from 0000080420-22-000007:mdna:20]

[0000080420-22-000019:mdna:23]
We recorded an income tax provision of $1.8 million in the second quarter of Fiscal 2022, compared to an income tax benefit of $0.9 million in the second quarter of Fiscal 2021. The effective tax rate for the second quarter of Fiscal 2022 was 305%, compared to an effective tax rate of 81% in the second quarter of Fiscal 2021. For the three months ended March 31, 2022, the effective tax rate was negatively impacted by the change in the annual estimated relative amounts of income (loss) recognized in the various tax jurisdictions. The tax provision recorded in the second quarter of Fiscal 2022 resulted from an increase in forecasted pre-tax income.

[0000080420-22-000019:mdna:24]
[same as prior period, unchanged from 0000080420-22-000007:mdna:22]

[0000080420-22-000019:mdna:25]
In the second quarter of Fiscal 2022, we recorded a net loss of $1.2 million, or $0.10 per diluted share, compared to a net loss of $0.2 million, or $0.02 per diluted share, in the second quarter of Fiscal 2021. This increase in net loss is primarily due to the provision for income taxes resulting from applying an estimated annual effective tax rate to year-to-date ordinary pre-tax income (loss).

[0000080420-22-000019:mdna:26]
[same as prior period, unchanged from 0000080420-22-000007:mdna:24]

[0000080420-22-000019:mdna:27]
The order backlog at March 31, 2022 was $440.0 million, an increase of 6% from $416.0 million at December 31, 2021 and a slight increase from $436.6 million at March 31, 2021. Bookings, net of cancellations and scope reductions, increased by 70% in the second quarter of Fiscal 2022 to $150.8 million, compared to $88.5 million in the second quarter of Fiscal 2021, primarily driven by activity outside of our oil and gas and petrochemical sectors.

[0000080420-22-000019:mdna:28]
Six Months Ended March 31, 2022 Compared to the Six Months Ended March 31, 2021 (Unaudited)

[0000080420-22-000019:mdna:29]
Revenue and Gross Profit

[0000080420-22-000019:mdna:30]
Revenues increased by 4%, or $9.1 million, to $234.4 million in the six months ended March 31, 2022. Revenues continue to be negatively impacted due to project delays and cancellations of potential projects associated with the global economic impact resulting from the COVID-19 pandemic and associated reduction in demand across our industrial end markets. Domestic revenues increased slightly to $169.1 million in the six months ended March 31, 2022. International revenues increased by 15.0%, or $8.5 million, to $65.3 million. Our international revenues include both revenues generated from our international facilities as well as revenues from export projects generated at our domestic facilities.

[0000080420-22-000019:mdna:31]
Revenue from our core oil and gas markets (excluding petrochemical) increased by 7%, or $6.5 million, to $96.7 million in the six months ended March 31, 2022, while petrochemical revenue increased by 86%, or $16.7 million, to $36.1 million in the first half of Fiscal 2022, primarily due to project mix. Revenue from our utility markets decreased by 8%, or $4.7 million, to $51.9 million, and traction market revenue decreased by 25%, or $7.1 million, to $21.4 million in the six months ended March 31, 2022. Revenue from all other markets combined decreased by 7%, or $2.3 million, to $28.3 million in the six months ended March 31, 2022.

[0000080420-22-000019:mdna:32]
Gross profit decreased by 8%, or $2.9 million, to $32.5 million as compared to the first half of Fiscal 2021. The decrease in gross profit was driven predominately by higher direct material costs. Gross profit may continue to be negatively impacted by higher material costs to the extent we are not able to pass these increases to our customers.

[0000080420-22-000019:mdna:33]
Selling, General and Administrative Expenses

[0000080420-22-000019:mdna:34]
Selling, general and administrative expenses decreased by 2%, or $0.6 million, to $33.0 million in the six months ended March 31, 2022, primarily due to decreased variable incentive compensation. Selling, general and administrative expenses as a percentage of revenues decreased to 14% during the six months ended March 31, 2022 compared to 15% during the six months ended March 31, 2021.

[0000080420-22-000019:mdna:35]
Other Income

[0000080420-22-000019:mdna:36]
We recorded other income of $0.3 million in the six months ended March 31, 2022 related to a gain on the sale of land. We did not record other income during the six months ended March 31, 2021.

[0000080420-22-000019:mdna:37]
Income Tax Benefit/Provision

[0000080420-22-000019:mdna:38]
We recorded an income tax provision of $0.4 million in the six months ended March 31, 2022, compared to an income tax benefit of $0.8 million in the six months ended March 31, 2021. The effective tax rate for the six months ended March 31, 2022 was negative 10%, compared to an effective tax rate of 59% for the six months ended March 31, 2021. For the six months ended March 31, 2022, the effective tax rate was negatively impacted by the change in the annual estimated relative amounts of income (loss) recognized in the various tax jurisdictions. The effective tax rate was favorably impacted by the estimated R&D Tax Credit and the projected utilization of net operating loss carryforwards in Canada that were fully reserved with a valuation allowance in the six months ended March 31, 2022 and 2021.

[0000080420-22-000019:mdna:39]
Net Loss

[0000080420-22-000019:mdna:40]
In the six months ended March 31, 2022, we recorded a net loss of $4.1 million, or $0.34 per diluted share, compared to a net loss of $0.6 million, or $0.05 per diluted share, in the six months ended March 31, 2021. This increase in net loss is due to a decline in gross profit as discussed above.

[0000080420-22-000019:mdna:41]
Backlog

[0000080420-22-000019:mdna:42]
The order backlog at March 31, 2022 was $440.0 million, an increase of 6% from $414.9 million at September 30, 2021. Bookings, net of cancellations and scope reductions, increased by 44% during the six months ended March 31, 2022 to $258.5 million, compared to $179.6 million in the six months ended March 31, 2021.

[0000080420-22-000019:mdna:43]
[same as prior period, unchanged from 0000080420-22-000007:mdna:26]

[0000080420-22-000019:mdna:44]
As noted in "Overview" above, the markets in which we participate are capital-intensive and cyclical in nature. A significant portion of our revenues has historically been from the oil, gas and petrochemical markets. Oil and gas commodity price levels have been unstable over the last several years, and our customers have in certain cases delayed or cancelled some of their major capital investment projects. Recently we have seen increased global demand for cleaner-burning fuels; however, the uncertainty in oil prices and the global economic impacts from COVID-19, including supply chain disruptions and associated inflationary pressures, as well as other geopolitical events may have a negative impact on our business going forward, as discussed in more detail below. Specific to the energy industry focus on transitioning to natural gas and cleaner-burning fuels, the business was awarded a substantial contract in Fiscal 2020 that will support the integrated electrical distribution requirements for a large domestic industrial complex and should be substantially completed in Fiscal 2022.

[0000080420-22-000019:mdna:45]
Our operating results are impacted by factors such as the timing of new order awards, customer approval of final engineering and design specifications and delays in customer construction schedules, all of which contribute to short-term earnings variability and the timing of project execution. Our operating results also have been, and may continue to be, impacted by the timing and resolution of change orders, project close-out and resolution of potential contract claims and liquidated damages, all of which could improve or deteriorate gross margins during the period in which these items are resolved with our customers. Disruption in the global supply chain has negatively impacted our business as well due to the reduction in availability and uncertainty in the timing of the receipt of certain key component parts and commodities. These factors may result in periods of underutilization of our resources and facilities, which may negatively impact our ability to cover our fixed costs, or inhibit our ability to deliver completed products on time. We experienced lower commercial activity in Fiscal 2020 and Fiscal 2021 driven in large part from the uncertainty resulting from the COVID-19 pandemic, as discussed in "Overview" above. Considering the long cycle nature of our business, we anticipate these cyclical conditions may persist throughout the remainder of Fiscal 2022. We will continue to remain focused on the variables that impact our markets as well as cost management, labor and supply chain challenges. We will also continue to adjust to the global conditions in order to maintain competitive cost and technological advantages in the markets that we serve.

[0000080420-22-000019:mdna:46]
The consequences of a prolonged economic decline could include, but are not limited to, a continued reduction in commercial and industrial activity. The Company cannot reasonably estimate the duration or severity of these global economic challenges, or the extent to which the resulting disruptions may materially impact our business, results of operations or cash flows. We will take prudent measures to maintain our strong liquidity and cash position, which may include reducing our capital expenditures and research and development costs, as well as reducing or eliminating future dividend payments.

[0000080420-22-000019:mdna:47]
[same as prior period, unchanged from 0000080420-22-000007:mdna:30]

[0000080420-22-000019:mdna:48]
As of March 31, 2022, current assets exceeded current liabilities by 2.3 times.

[0000080420-22-000019:mdna:49]
Cash, cash equivalents and short-term investments decreased to $113.6 million at March 31, 2022, compared to $134.0 million at September 30, 2021. This decrease in cash was primarily driven by increases in each of accounts receivable and inventory. We have strategically increased certain inventories due to uncertainty from the global supply chain issues impacting our business.  We believe that our strong working capital position, available borrowings under our credit facility and available cash should be sufficient to finance future operating activities, capital improvements, research and development initiatives and debt repayments for the foreseeable future.

[0000080420-22-000019:mdna:50]
We have a credit agreement with Bank of America, N.A. (as amended, the "U.S. Revolver") which is a $75.0 million revolving credit facility available for both borrowings and letters of credit and expires September 27, 2024. The U.S. Revolver states that up to $30 million may be deducted from the amount of letters of credit outstanding (not to be less than zero) when calculating the consolidated funded indebtedness which is a component of the consolidated net leverage ratio. Additionally, we have the option to cash collateralize all or a portion of the letters of credit outstanding, which would favorably impact the consolidated funded indebtedness calculation and the consolidated net leverage ratio.

[0000080420-22-000019:mdna:51]
On October 1, 2021, our industrial development revenue bonds matured and as a result we had no long-term debt at March 31, 2022. As of March 31, 2022, there were no amounts borrowed under the U.S. Revolver, and letters of credit outstanding were $32.2 million. As of March 31, 2022, $42.8 million was available for the issuance of letters of credit and borrowing under the U.S. Revolver. We are required to maintain certain financial covenants, the most significant of which are a consolidated net leverage ratio of less than 3.0 to 1.0 and a consolidated interest coverage ratio of greater than 3.0 to 1.0. Our most restrictive covenant, the consolidated net leverage ratio, is the ratio of earnings before interest, taxes, depreciation, amortization and stock-based compensation (EBITDAS) to funded indebtedness, which includes letters of credit. An increase in indebtedness or a decrease in EBITDAS could restrict our ability to issue letters of credit or borrow under the U.S. Revolver. For further information regarding our debt, see Notes E and F of Notes to Condensed Consolidated Financial Statements.

[0000080420-22-000019:mdna:52]
Approximately $30.4 million of our cash, cash equivalents and short-term investments at March 31, 2022 was held outside of the U.S. for our international operations. It is our intention to indefinitely reinvest all current and future foreign earnings internationally in order to ensure sufficient working capital to support our international operations. In the event that we elect to repatriate some or all of the foreign earnings that were previously deemed to be indefinitely reinvested outside the U.S., we may incur additional tax expense upon such repatriation under current tax laws.

[0000080420-22-000019:mdna:53]
[same as prior period, unchanged from 0000080420-22-000007:mdna:36]

[0000080420-22-000019:mdna:54]
Operating activities used net cash of $13.0 million during the six months ended March 31, 2022 and $18.1 million during the same period in Fiscal 2021. Cash flow from operations is primarily influenced by the timing of milestone payments from our customers, project volume and the payment terms with our suppliers. This increase in operating cash flow was primarily due to the timing of contract billing milestones although slightly offset by the increase in accounts receivable. The strategic increase in inventory as a result of the uncertainty in the global supply chain negatively impacted cash flow for the first six months of Fiscal 2022.

[0000080420-22-000019:mdna:55]
[same as prior period, unchanged from 0000080420-22-000007:mdna:38]

[0000080420-22-000019:mdna:56]
Investing activities used $7.6 million during the six months ended March 31, 2022 and $1.2 million during the same period in Fiscal 2021. The increase in cash used in investing activities in the first six months of Fiscal 2022 was primarily due to short-term investment activity.

[0000080420-22-000019:mdna:57]
[same as prior period, unchanged from 0000080420-22-000007:mdna:40]

[0000080420-22-000019:mdna:58]
Net cash used in financing activities was $7.2 million during the six months ended March 31, 2022 and $7.1 million during the same period in Fiscal 2021, which primarily consisted of approximately $6.1 million of dividends paid in each period.

[0000080420-22-000019:mdna:59]
[same as prior period, unchanged from 0000080420-22-000007:mdna:42]

[0000080420-22-000019:mdna:60]
[same as prior period, unchanged from 0000080420-22-000007:mdna:43]

[0000080420-22-000019:mdna:61]
[same as prior period, unchanged from 0000080420-22-000007:mdna:44]
