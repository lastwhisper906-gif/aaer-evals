# POWL notes — 0000080420-22-000019


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureAndSignificantAccountingPoliciesTextBlock

[0000080420-22-000019:notes:1]
[same as prior period, unchanged from 0000080420-22-000007:notes:1]

[0000080420-22-000019:notes:2]
[same as prior period, unchanged from 0000080420-22-000007:notes:2]

[0000080420-22-000019:notes:3]
[same as prior period, unchanged from 0000080420-22-000007:notes:3]

[0000080420-22-000019:notes:4]
Impact of Global Economic Uncertainty and Oil and Gas Commodity Market Volatility on Powell

[0000080420-22-000019:notes:5]
Various factors resulting in global economic uncertainty have negatively impacted our results over the last 18 months. In particular, the COVID-19 pandemic continues to impact global energy markets. This pandemic has negatively impacted demand, which in turn has resulted in considerable volatility across global oil and gas commodity markets. As a result, some of our industrial customers have deferred or suspended their planned capital expenditures. During this period, certain of our customers have asked that we delay or cancel our manufacturing on their projects as their operations have been negatively impacted by this pandemic and the reduced oil and gas demand, which has resulted in recognition of cancellation fees based on contract terms and the extent of our progress on the projects. We continue to work with our key suppliers who are facing various issues related to the availability and timing of the receipt of key component parts and commodities to ensure that we are able to meet our customer commitments.

[0000080420-22-000019:notes:6]
[same as prior period, unchanged from 0000080420-22-000007:notes:6]

[0000080420-22-000019:notes:7]
[same as prior period, unchanged from 0000080420-22-000007:notes:7]

[0000080420-22-000019:notes:8]
[same as prior period, unchanged from 0000080420-22-000007:notes:8]

[0000080420-22-000019:notes:9]
[same as prior period, unchanged from 0000080420-22-000007:notes:9]

[0000080420-22-000019:notes:10]
[same as prior period, unchanged from 0000080420-22-000007:notes:10]

[0000080420-22-000019:notes:11]
[same as prior period, unchanged from 0000080420-22-000007:notes:11]


## us-gaap:EarningsPerShareTextBlock

[0000080420-22-000019:notes:12]
Earnings Per Share
We compute basic earnings per share by dividing net income (loss) by the weighted average number of common shares outstanding during the period. Diluted earnings per common and potential common share includes the weighted average of additional shares associated with the incremental effect of dilutive restricted stock and restricted stock units.

[0000080420-22-000019:notes:13]
[same as prior period, unchanged from 0000080420-22-000007:notes:13]

[0000080420-22-000019:notes:14]
|  | Three months ended March 31, |  | Six months ended March 31, |
|  | 2022 |  | 2021 |  | 2022 |  | 2021 |
| Numerator: |  |  |  |  |  |  |  |
| Net loss | $ | (1,217) |  |  | $ | (225) |  |  | $ | (4,063) |  |  | $ | (589) |  |
| Denominator: |  |  |  |  |  |  |  |
| Weighted average basic shares | 11,801 |  |  | 11,707 |  |  | 11,783 |  |  | 11,690 |  |
| Dilutive effect of restricted stock units | — |  |  | — |  |  | — |  |  | — |  |
| Weighted average diluted shares | 11,801 |  |  | 11,707 |  |  | 11,783 |  |  | 11,690 |  |
| Loss per share: |  |  |  |  |  |  |  |
| Basic | $ | (0.10) |  |  | $ | (0.02) |  |  | $ | (0.34) |  |  | $ | (0.05) |  |
| Diluted | $ | (0.10) |  |  | $ | (0.02) |  |  | $ | (0.34) |  |  | $ | (0.05) |  |

[0000080420-22-000019:notes:15]
For each of the three and six months ended March 31, 2022 and 2021, we incurred net losses and therefore all potential common shares were deemed to be anti-dilutive.


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0000080420-22-000019:notes:16]
[same as prior period, unchanged from 0000080420-22-000007:notes:16]

[0000080420-22-000019:notes:17]
[same as prior period, unchanged from 0000080420-22-000007:notes:17]

[0000080420-22-000019:notes:18]
|  | Three months ended March 31, |  | Six months ended March 31, |
|  | 2022 |  | 2021 |  | 2022 |  | 2021 |
| Balance at beginning of period | $ | 411 |  |  | $ | 493 |  |  | $ | 333 |  |  | $ | 510 |  |
| Bad debt expense (recovery), net | 353 |  |  | (113) |  |  | 445 |  |  | (132) |  |
| Uncollectible accounts written off, net of recoveries | (57) |  |  | — |  |  | (71) |  |  | (10) |  |
| Change due to foreign currency translation | (4) |  |  | 2 |  |  | (4) |  |  | 14 |  |
| Balance at end of period | $ | 703 |  |  | $ | 382 |  |  | $ | 703 |  |  | $ | 382 |  |

[0000080420-22-000019:notes:19]
[same as prior period, unchanged from 0000080420-22-000007:notes:19]

[0000080420-22-000019:notes:20]
[same as prior period, unchanged from 0000080420-22-000007:notes:20]

[0000080420-22-000019:notes:21]
|  | March 31, 2022 |  | September 30, 2021 |
| Raw materials, parts and sub-assemblies, net | $ | 42,282 |  |  | $ | 28,688 |  |
| Work-in-progress | 1,403 |  |  | 1,147 |  |
| Total inventories | $ | 43,685 |  |  | $ | 29,835 |  |

[0000080420-22-000019:notes:22]
[same as prior period, unchanged from 0000080420-22-000007:notes:22]

[0000080420-22-000019:notes:23]
[same as prior period, unchanged from 0000080420-22-000007:notes:23]

[0000080420-22-000019:notes:24]
|  | Three months ended March 31, |  | Six months ended March 31, |
|  | 2022 |  | 2021 |  | 2022 |  | 2021 |
| Balance at beginning of period | $ | 2,443 |  |  | $ | 2,675 |  |  | $ | 2,531 |  |  | $ | 2,771 |  |
| Increase to warranty expense | 323 |  |  | 395 |  |  | 616 |  |  | 1,053 |  |
| Deduction for warranty charges | (421) |  |  | (609) |  |  | (803) |  |  | (1,388) |  |
| Change due to foreign currency translation | 2 |  |  | 6 |  |  | 3 |  |  | 31 |  |
| Balance at end of period | $ | 2,347 |  |  | $ | 2,467 |  |  | $ | 2,347 |  |  | $ | 2,467 |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0000080420-22-000019:notes:25]
[same as prior period, unchanged from 0000080420-22-000007:notes:25]

[0000080420-22-000019:notes:26]
[same as prior period, unchanged from 0000080420-22-000007:notes:26]

[0000080420-22-000019:notes:27]
[same as prior period, unchanged from 0000080420-22-000007:notes:27]

[0000080420-22-000019:notes:28]
We also have contracts to provide value-added services such as field service inspection, installation, commissioning, modification and repair, as well as retrofit and retrofill components for existing systems.  If the service contract terms give us the right to invoice the customer for an amount that corresponds directly with the value of our performance completed to date (i.e., a service contract in which we bill a fixed amount for each hour of service provided), then we recognize revenue over time in each reporting period corresponding to the amount with which we have the right to invoice.  Our performance obligations are satisfied as the work progresses. Revenues from our custom-engineered products and value-added services transferred to customers over time accounted for approximately 94% of total revenues for the three and six months ended March 31, 2022, 93% of total revenues for the three months ended March 31, 2021 and 92% of total revenues for the six months ended March 31, 2021.

[0000080420-22-000019:notes:29]
Additionally, we have sales orders for spare parts and replacement circuit breakers for switchgear that are obsolete or that are no longer produced by the original manufacturer. Revenues from these sales orders are recognized at the time we fulfill our performance obligation to the customer, which is typically upon shipment and represented approximately 6% of total revenues for the three and six months ended March 31, 2022, 7% of total revenues for the three months ended March 31, 2021 and 8% of total revenues for the six months ended March 31, 2021.

[0000080420-22-000019:notes:30]
[same as prior period, unchanged from 0000080420-22-000007:notes:30]

[0000080420-22-000019:notes:31]
[same as prior period, unchanged from 0000080420-22-000007:notes:31]

[0000080420-22-000019:notes:32]
[same as prior period, unchanged from 0000080420-22-000007:notes:32]

[0000080420-22-000019:notes:33]
[same as prior period, unchanged from 0000080420-22-000007:notes:33]

[0000080420-22-000019:notes:34]
Remaining unsatisfied performance obligations, which we refer to as backlog, represent the estimated transaction price for goods and services for which we have a material right, but work has not been performed. As of March 31, 2022, we had backlog of $440.0 million, of which approximately $310.9 million is expected to be recognized as revenue within the next twelve months. Backlog may not be indicative of future operating results as orders may be cancelled or modified by our customers. Our backlog does not include service and maintenance-type contracts for which we have the right to invoice as services are performed.

[0000080420-22-000019:notes:35]
[same as prior period, unchanged from 0000080420-22-000007:notes:35]

[0000080420-22-000019:notes:36]
[same as prior period, unchanged from 0000080420-22-000007:notes:36]

[0000080420-22-000019:notes:37]
For the six months ended March 31, 2022 and 2021, our operating results were positively impacted by $5.6 million and $8.2 million, respectively, as a result of changes in contract estimates related to projects in progress at the beginning of the respective period. These changes in estimates resulted primarily from favorable project execution and negotiations of variable consideration, discussed below, as well as revenue and reduced costs recognized from project cancellations and other changes in facts and circumstances during these periods. The decrease from the prior year is primarily due to the increase in direct materials cost, which we were not able to pass on to our customers.

[0000080420-22-000019:notes:38]
[same as prior period, unchanged from 0000080420-22-000007:notes:38]

[0000080420-22-000019:notes:39]
[same as prior period, unchanged from 0000080420-22-000007:notes:39]

[0000080420-22-000019:notes:40]
[same as prior period, unchanged from 0000080420-22-000007:notes:40]

[0000080420-22-000019:notes:41]
[same as prior period, unchanged from 0000080420-22-000007:notes:41]

[0000080420-22-000019:notes:42]
[same as prior period, unchanged from 0000080420-22-000007:notes:42]

[0000080420-22-000019:notes:43]
[same as prior period, unchanged from 0000080420-22-000007:notes:43]

[0000080420-22-000019:notes:44]
[same as prior period, unchanged from 0000080420-22-000007:notes:44]

[0000080420-22-000019:notes:45]
[same as prior period, unchanged from 0000080420-22-000007:notes:45]

[0000080420-22-000019:notes:46]
[same as prior period, unchanged from 0000080420-22-000007:notes:46]

[0000080420-22-000019:notes:47]
Contract assets and liabilities as of March 31, 2022 and September 30, 2021 are summarized below (in thousands):

[0000080420-22-000019:notes:48]
|  | March 31, 2022 |  | September 30, 2021 |
| Contract assets | $ | 58,553 |  |  | $ | 54,199 |  |
| Contract liabilities | (56,706) |  |  | (42,433) |  |
| Net contract asset | $ | 1,847 |  |  | $ | 11,766 |  |

[0000080420-22-000019:notes:49]
The decrease in net contract asset at March 31, 2022 from September 30, 2021 was primarily due to the timing of contract billing milestones and new orders as well as cash used on our large industrial project awarded in Fiscal 2020. To determine the amount of revenue recognized during the period from contract liabilities, we first allocate revenue to the individual contract liability balance outstanding at the beginning of the period until the revenue exceeds that balance. During the six months ended March 31, 2022, we recognized revenue of approximately $33.5 million that was related to contract liabilities outstanding at September 30, 2021.

[0000080420-22-000019:notes:50]
The timing of our invoice process is typically dependent on the completion of certain milestones and contract terms and subject to agreement by our customer.  Payment is typically expected within 30 days of invoice. Any uncollected invoiced amounts for our performance obligations recognized over time, including contract retentions, are recorded as accounts receivable in the Condensed Consolidated Balance Sheets. Certain contracts allow customers to withhold a small percentage of billings pursuant to retainage provisions, and such amounts are generally due upon completion of the contract and acceptance of the project by the customer. Based on our experience in recent years, the majority of these retainage balances are expected to be collected within approximately twelve months. As of March 31, 2022 and September 30, 2021, accounts receivable included retention amounts of $9.8 million and $9.6 million, respectively. Of the retained amount at March 31, 2022, $9.1 million is expected to be collected in the next twelve months and is recorded in accounts receivable. The remaining $0.7 million is recorded in other assets.

[0000080420-22-000019:notes:51]
[same as prior period, unchanged from 0000080420-22-000007:notes:51]

[0000080420-22-000019:notes:52]
The following tables present our disaggregated revenue by geographic destination and market sector for the three and six months ended March 31, 2022 and 2021 (in thousands):

[0000080420-22-000019:notes:53]
|  | Three months ended March 31, |  | Six months ended March 31, |
|  | 2022 |  | 2021 |  | 2022 |  | 2021 |
| United States | $ | 86,992 |  |  | $ | 87,939 |  |  | $ | 169,137 |  |  | $ | 168,525 |  |
| Canada | 22,053 |  |  | 17,734 |  |  | 37,178 |  |  | 31,825 |  |
| Europe, Middle East and Africa | 15,551 |  |  | 10,937 |  |  | 23,381 |  |  | 19,193 |  |
| Asia/Pacific | 1,646 |  |  | 2,009 |  |  | 2,590 |  |  | 4,725 |  |
| Mexico, Central and South America | 1,612 |  |  | 97 |  |  | 2,137 |  |  | 1,023 |  |
| Total revenues by geographic destination | $ | 127,854 |  |  | $ | 118,716 |  |  | $ | 234,423 |  |  | $ | 225,291 |  |

[0000080420-22-000019:notes:54]
|  | Three months ended March 31, |  | Six months ended March 31, |
|  | 2022 |  | 2021 |  | 2022 |  | 2021 |
| Oil and gas (excludes petrochemical) | $ | 53,634 |  |  | $ | 50,142 |  |  | $ | 96,655 |  |  | $ | 90,171 |  |
| Petrochemical | 18,853 |  |  | 10,196 |  |  | 36,081 |  |  | 19,361 |  |
| Electric utility | 30,374 |  |  | 28,452 |  |  | 51,907 |  |  | 56,622 |  |
| Traction power | 10,054 |  |  | 15,140 |  |  | 21,426 |  |  | 28,501 |  |
| All others | 14,939 |  |  | 14,786 |  |  | 28,354 |  |  | 30,636 |  |
| Total revenues by market sector | $ | 127,854 |  |  | $ | 118,716 |  |  | $ | 234,423 |  |  | $ | 225,291 |  |


## us-gaap:RevenueFromContractWithCustomerPolicyTextBlock

[0000080420-22-000019:notes:55]
[same as prior period, unchanged from 0000080420-22-000007:notes:55]

[0000080420-22-000019:notes:56]
Additionally, we have sales orders for spare parts and replacement circuit breakers for switchgear that are obsolete or that are no longer produced by the original manufacturer. Revenues from these sales orders are recognized at the time we fulfill our performance obligation to the customer, which is typically upon shipment and represented approximately 6% of total revenues for the three and six months ended March 31, 2022, 7% of total revenues for the three months ended March 31, 2021 and 8% of total revenues for the six months ended March 31, 2021. 
Some contracts may contain a cancellation clause that could limit the amount of revenue we are able to recognize over time. In these instances, revenue and costs associated with these contracts are deferred and recognized at a point in time when the performance obligation is fulfilled.Selling and administrative costs incurred in relation to obtaining a contract are typically expensed as incurred. We periodically utilize a third-party sales agent to obtain a contract and will pay a commission to that agent. We record the full commission liability to the third-party sales agents at the order date, with a corresponding deferred asset. As the project progresses, we record commission expense based on percentage of completion rates that correlate to the project and reduce the deferred asset. Once we have been paid by the customer, we pay the commission and the deferred liability is reduced
Performance Obligations

[0000080420-22-000019:notes:57]
[same as prior period, unchanged from 0000080420-22-000007:notes:57]

[0000080420-22-000019:notes:58]
[same as prior period, unchanged from 0000080420-22-000007:notes:58]


## us-gaap:LongTermDebtTextBlock

[0000080420-22-000019:notes:59]
Long-Term Debt
Long-term debt consisted of the following (in thousands):

[0000080420-22-000019:notes:60]
|  | March 31, 2022 |  | September 30, 2021 |
| Industrial development revenue bonds | $ | — |  |  | $ | 400 |  |
| Less: current portion | — |  |  | (400) |  |
| Total long-term debt | $ | — |  |  | $ | — |  |

[0000080420-22-000019:notes:61]
U.S. Revolver

[0000080420-22-000019:notes:62]
We have a credit agreement with Bank of America, N.A. (as amended, the "U.S. Revolver"), which is a $75.0 million revolving credit facility that is available for both borrowings and letters of credit and expires September 27, 2024. The U.S. Revolver states that up to $30 million may be deducted from the amount of letters of credit outstanding (not to be less than zero) when calculating the consolidated funded indebtedness which is a component of the consolidated net leverage ratio. Additionally, we have the option to cash collateralize all or a portion of the letters of credit outstanding, which would favorably impact the consolidated funded indebtedness calculation and the consolidated net leverage ratio. As of March 31, 2022, there were no amounts borrowed under the U.S. Revolver and letters of credit outstanding were $32.2 million. There was $42.8 million available for the issuance of letters of credit and borrowings under the U.S. Revolver as of March 31, 2022.

[0000080420-22-000019:notes:63]
We are required to maintain certain financial covenants, the most significant of which are a consolidated net leverage ratio less than 3.0 to 1.0 and a consolidated interest coverage ratio of greater than 3.0 to 1.0. Our most restrictive covenant, the consolidated net leverage ratio, is the ratio of earnings before interest, taxes, depreciation, amortization and stock-based compensation (EBITDAS) to funded indebtedness. An increase in indebtedness, which includes letters of credit, or a decrease in EBITDAS could restrict our ability to issue letters of credit or borrow under the U.S. Revolver. Additionally, we must maintain a consolidated cash balance of $30 million at all times, which can be deducted from the letters of credit outstanding as noted above. The U.S. Revolver also contains a "material adverse effect" clause which is a material change in our operations, business, properties, liabilities or condition (financial or otherwise) or a material impairment of our ability to perform our obligations under our credit agreements. As of March 31, 2022, we were in compliance with all of the financial covenants of the U.S. Revolver.

[0000080420-22-000019:notes:64]
The U.S. Revolver allows the Company to elect that any borrowing under the facility bears an interest rate based on either the base rate or the eurocurrency rate, in each case, plus the applicable rate. The base rate is generally the highest of (a) the federal funds rate plus 0.50%, (b) the Bank of America prime rate or (c) the London Interbank Offered Rate (LIBOR) successor rate plus 1.00%. The applicable rate is generally a range from (0.25)% to 1.75% depending on the type of loan and the Company's consolidated net leverage ratio. On December 31, 2021, the Company entered into a LIBOR Transition Amendment with Bank of America that states that LIBOR will be replaced with a successor rate in accordance with the U.S. Revolver.

[0000080420-22-000019:notes:65]
The U.S. Revolver is collateralized by a pledge of 100% of the voting capital stock of each of our domestic subsidiaries and 65% of the voting capital stock of each non-domestic subsidiary. The U.S. Revolver provides for customary events of default and carries cross-default provisions with other existing debt agreements. If an event of default (as defined in the U.S. Revolver) occurs and is continuing, on the terms and subject to the conditions set forth in the U.S. Revolver, amounts and letters of credit outstanding under the U.S. Revolver may be accelerated and may become immediately due and payable.

[0000080420-22-000019:notes:66]
Industrial Development Revenue Bonds

[0000080420-22-000019:notes:67]
We borrowed $8.0 million in October 2001 through a loan agreement funded with proceeds from tax-exempt industrial development revenue bonds (Bonds) for the completion of our Northlake, Illinois facility. The Bonds matured on October 1, 2021 and our final payment of $0.4 million was made.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0000080420-22-000019:notes:68]
Commitments and Contingencies
Letters of Credit, Bank Guarantees and Bonds

[0000080420-22-000019:notes:69]
Certain customers require us to post letters of credit, bank guarantees or surety bonds. These security instruments assure that we will perform under the terms of our contract. In the event of default, the counterparty may demand payment from the bank under a letter of credit or bank guarantee, or performance by the surety under a bond. To date, there have been no significant draws or claims related to security instruments for the periods reported. We were contingently liable for letters of credit of $32.2 million as of March 31, 2022. We also had surety bonds totaling $149.0 million that were outstanding, with additional bonding capacity of $451.0 million available, at March 31, 2022. We have strong surety relationships; however, a change in market conditions or the sureties' assessment of our financial position could cause the sureties to require cash collateralization for undischarged liabilities under the bonds.

[0000080420-22-000019:notes:70]
We have a $6.6 million facility agreement (Facility Agreement) between Powell (UK) Limited and a large international bank that provides Powell (UK) Limited the ability to enter into bank guarantees as well as forward exchange contracts and currency options. At March 31, 2022, we had outstanding guarantees totaling $3.2 million and amounts available under this Facility Agreement were $3.4 million. The Facility Agreement provides for customary events of default, and carries cross-default provisions with our U.S. Revolver. If an event of default (as defined in the Facility Agreement) occurs and is continuing, per the terms and subject to the conditions set forth therein, obligations outstanding under the Facility Agreement may be accelerated and declared immediately due and payable. Additionally, we are required to maintain cash collateral for guarantees greater than two years. As of March 31, 2022, we were in compliance with all of the financial covenants of the Facility Agreement.

[0000080420-22-000019:notes:71]
Litigation

[0000080420-22-000019:notes:72]
We are involved in various legal proceedings, claims and other disputes arising from our commercial operations, projects, employees and other matters which, in general, are subject to uncertainties and in which the outcomes are not predictable. Although we can give no assurances about the resolution of pending claims, litigation or other disputes and the effect such outcomes may have on us, management believes that any ultimate liability resulting from the outcome of such proceedings, to the extent not otherwise provided or covered by insurance, will not have a material adverse effect on our consolidated financial position or results of operations or liquidity.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0000080420-22-000019:notes:73]
[same as prior period, unchanged from 0000080420-22-000007:notes:73]

[0000080420-22-000019:notes:74]
[same as prior period, unchanged from 0000080420-22-000007:notes:74]

[0000080420-22-000019:notes:75]
We issue restricted stock units (RSUs) to certain officers and key employees of the Company. The fair value of the RSUs is based on the price of our common stock as reported on the NASDAQ Global Market on the grant dates. Typically, these grants vest over a three-year period from the date of issuance and are a blend of time-based and performance-based shares. The portion of the grant that is time-based typically vests over a three-year period on each anniversary of the grant date, based on continued employment. The performance-based shares vest based on the three-year earnings performance of the Company following the grant date. At March 31, 2022, there were 235,502 RSUs outstanding. The RSUs do not have voting rights but do receive dividend equivalents upon vesting which are accrued quarterly. Additionally, the shares of common stock underlying the RSUs are not considered issued and outstanding until vested and common stock is issued.

[0000080420-22-000019:notes:76]
Total RSU activity (number of shares) for the six months ended March 31, 2022 is summarized below:

[0000080420-22-000019:notes:77]
|  | Number ofRestrictedStockUnits |  | WeightedAverageGrant ValuePer Share |
| Outstanding at September 30, 2021 | 199,919 |  |  | $ | 30.34 |  |
| Granted | 107,350 |  |  | 24.79 |  |
| Vested | (71,767) |  |  | 32.66 |  |
| Forfeited/canceled | — |  |  | — |  |
| Outstanding at March 31, 2022 | 235,502 |  |  | $ | 26.94 |  |

[0000080420-22-000019:notes:78]
During the six months ended March 31, 2022 and 2021, we recorded compensation expense of $1.4 million and $1.3 million, respectively, related to the RSUs.

[0000080420-22-000019:notes:79]
Restricted Stock
Each non-employee director receives 2,400 restricted shares of the Company’s common stock annually. Fifty-percent of the restricted stock granted to each of our non-employee directors vests immediately, while the remaining fifty-percent vests on the anniversary of the grant date. Compensation expense is recognized immediately for the first fifty-percent of the restricted stock granted, while compensation expense for the remaining fifty-percent is recognized over the remaining vesting period. In February 2022, 16,800 shares of restricted stock were issued to our non-employee directors under the 2014 Non-Employee Director Equity Incentive Plan at a price of $23.09 per share. During the six months ended March 31, 2022 and 2021, we recorded compensation expense of $0.3 million and $0.4 million, respectively, related to restricted stock.


## us-gaap:FairValueDisclosuresTextBlock

[0000080420-22-000019:notes:80]
[same as prior period, unchanged from 0000080420-22-000007:notes:80]

[0000080420-22-000019:notes:81]
[same as prior period, unchanged from 0000080420-22-000007:notes:81]

[0000080420-22-000019:notes:82]
[same as prior period, unchanged from 0000080420-22-000007:notes:82]

[0000080420-22-000019:notes:83]
[same as prior period, unchanged from 0000080420-22-000007:notes:83]

[0000080420-22-000019:notes:84]
[same as prior period, unchanged from 0000080420-22-000007:notes:84]

[0000080420-22-000019:notes:85]
The following table summarizes the fair value of our assets and liabilities that were accounted for at fair value on a recurring basis as of March 31, 2022 (in thousands):

[0000080420-22-000019:notes:86]
|  | Fair Value Measurements at March 31, 2022 |
|  | Quoted Prices inActive Markets forIdentical Assets(Level 1) |  | Significant OtherObservableInputs(Level 2) |  | SignificantUnobservableInputs(Level 3) |  | Fair Value at March 31,2022 |
| Assets: |  |  |  |  |  |  |  |
| Cash and cash equivalents | $ | 86,431 |  |  | $ | — |  |  | $ | — |  |  | $ | 86,431 |  |
| Short-term investments | 27,143 |  |  | — |  |  | — |  |  | 27,143 |  |
| Other assets | — |  |  | 8,674 |  |  | — |  |  | 8,674 |  |
| Liabilities: |  |  |  |  |  |  |  |
| Deferred compensation | — |  |  | 9,024 |  |  | — |  |  | 9,024 |  |

[0000080420-22-000019:notes:87]
[same as prior period, unchanged from 0000080420-22-000007:notes:87]

[0000080420-22-000019:notes:88]
[same as prior period, unchanged from 0000080420-22-000007:notes:88]

[0000080420-22-000019:notes:89]
[same as prior period, unchanged from 0000080420-22-000007:notes:89]

[0000080420-22-000019:notes:90]
[same as prior period, unchanged from 0000080420-22-000007:notes:90]

[0000080420-22-000019:notes:91]
[same as prior period, unchanged from 0000080420-22-000007:notes:91]

[0000080420-22-000019:notes:92]
[same as prior period, unchanged from 0000080420-22-000007:notes:92]

[0000080420-22-000019:notes:93]
There were no transfers between levels within the fair value measurement hierarchy during the quarter ended March 31, 2022.


## us-gaap:LesseeOperatingLeasesTextBlock

[0000080420-22-000019:notes:94]
Leases
Our leases consist primarily of office and manufacturing space and construction equipment. All of our future lease obligations are related to non-cancelable operating leases. The most significant portion of our lease portfolio relates to leases of office and manufacturing facilities in Canada which we no longer occupy. We currently sublease the majority of these Canadian facilities. The following table provides a summary of lease cost components for the three and six months ended March 31, 2022 and 2021, respectively (in thousands):

[0000080420-22-000019:notes:95]
|  |  | Three months ended March 31, |  | Six months ended March 31, |
| Lease Cost |  | 2022 |  | 2021 |  | 2022 |  | 2021 |
| Operating lease cost |  | $ | 573 |  |  | $ | 629 |  |  | $ | 1,143 |  |  | $ | 1,237 |  |
| Less: sublease income |  | (173) |  |  | (177) |  |  | (347) |  |  | (357) |  |
| Variable lease cost(1) |  | 117 |  |  | 109 |  |  | 258 |  |  | 217 |  |
| Short-term lease cost(2) |  | 579 |  |  | 319 |  |  | 852 |  |  | 488 |  |
| Total lease cost |  | $ | 1,096 |  |  | $ | 880 |  |  | $ | 1,906 |  |  | $ | 1,585 |  |

[0000080420-22-000019:notes:96]
[same as prior period, unchanged from 0000080420-22-000007:notes:96]

[0000080420-22-000019:notes:97]
[same as prior period, unchanged from 0000080420-22-000007:notes:97]

[0000080420-22-000019:notes:98]
We recognize operating lease assets and operating lease liabilities representing the present value of the remaining lease payments for leases with initial terms greater than twelve months. Leases with initial terms of twelve months or less are not recorded in our Condensed Consolidated Balance Sheets. As of March 31, 2022 and September 30, 2021, our operating lease assets have been reduced by a lease accrual of $0.3 million and $0.4 million, respectively, related to certain unused facility leases in Canada. The following table provides a summary of the operating lease assets and operating lease liabilities included in our Condensed Consolidated Balance Sheets as of March 31, 2022 and September 30, 2021, respectively (in thousands):

[0000080420-22-000019:notes:99]
| Operating Leases |  | March 31, 2022 |  | September 30, 2021 |
| Assets: |  |  |  |  |
| Operating lease assets, net |  | $ | 3,205 |  |  | $ | 3,453 |  |
| Liabilities: |  |  |  |  |
| Current operating lease liabilities |  | 1,629 |  |  | 1,415 |  |
| Long-term operating lease liabilities |  | 1,836 |  |  | 2,413 |  |
| Total lease liabilities |  | $ | 3,465 |  |  | $ | 3,828 |  |

[0000080420-22-000019:notes:100]
The following table provides the maturities of our operating lease liabilities as of March 31, 2022 (in thousands):

[0000080420-22-000019:notes:101]
|  |  | Operating Leases |  |  |
| Remainder of 2022 |  | $ | 1,232 |  |  |  |
| 2023 |  | 1,616 |  |  |  |
| 2024 |  | 416 |  |  |  |
| 2025 |  | 258 |  |  |  |
| 2026 |  | 65 |  |  |  |
| Thereafter |  | — |  |  |  |
| Total future minimum lease payments |  | $ | 3,587 |  |  |  |
| Less: present value discount (imputed interest) |  | (122) |  |  |  |
| Present value of lease liabilities |  | $ | 3,465 |  |  |  |

[0000080420-22-000019:notes:102]
The weighted average discount rate as of March 31, 2022 was 3.81%. The weighted average remaining lease term was 1.96 years at March 31, 2022.


## us-gaap:IncomeTaxDisclosureTextBlock

[0000080420-22-000019:notes:103]
[same as prior period, unchanged from 0000080420-22-000007:notes:103]

[0000080420-22-000019:notes:104]
|  | Three months ended March 31, |  | Six months ended March 31, |
|  | 2022 |  | 2021 |  | 2022 |  | 2021 |
| Income (loss) before income taxes | $ | 595 |  |  | $ | (1,171) |  |  | $ | (3,692) |  |  | $ | (1,430) |  |
| Income tax provision (benefit) | 1,812 |  |  | (946) |  |  | 371 |  |  | (841) |  |
| Net loss | $ | (1,217) |  |  | $ | (225) |  |  | $ | (4,063) |  |  | $ | (589) |  |
| Effective tax rate | 305 | % |  | 81 | % |  | (10) | % |  | 59 | % |

[0000080420-22-000019:notes:105]
During interim reporting periods, the provision for income taxes is calculated by applying an estimated annual effective tax rate to year-to-date ordinary pre-tax income (loss). As a result, a significant variation in the customary relationship between income tax expense and pre-tax income may occur. Due to the estimated Research and Development Tax Credit (R&D Tax Credit) as well as the projected utilization of net operating loss carryforwards in Canada that were fully reserved with a valuation allowance, we are projecting an income tax benefit for the full fiscal year ended September 30, 2022, which would result in a negative effective tax rate. When this annual effective tax rate is applied to the year-to-date loss, a tax provision results for the three and six months ended March 31, 2022. The effective tax rate was largely impacted by the change in the annual estimated relative amounts of income (loss) recognized in the various tax jurisdictions.

[0000080420-22-000019:notes:106]
For the three and six months ended March 31, 2021, the income tax benefit resulted from the relative amounts of income (loss) recognized in various tax jurisdictions, the utilization of net operating loss carryforwards in Canada that have been fully reserved with a valuation allowance, and the estimated R&D Tax Credit.
We have recorded valuation allowances against the deferred tax assets of various foreign jurisdictions as it was determined that it was more-likely-than-not that the deferred tax assets may not be recognized. We maintain a full valuation allowance on our deferred tax assets until there is sufficient evidence to support the reversal of all or some portion of these allowances. However, given our current earnings and anticipated future earnings in Canada, we believe that there is a possibility that within the next 12 months, sufficient positive evidence may become available to allow us to reach a conclusion that a significant portion of the Canadian valuation allowance will no longer be needed. A release of the valuation allowance would result in the recognition of certain net deferred tax assets and a decrease to income tax expense for the period the release is recorded. However, the exact timing and amount of the valuation allowance released are subject to change on the basis of the level of profitability that we believe we may be able to achieve.


## us-gaap:SubsequentEventsTextBlock

[0000080420-22-000019:notes:107]
Subsequent Events
Quarterly Dividend Declared

[0000080420-22-000019:notes:108]
On May 3, 2022, our Board of Directors declared a quarterly cash dividend on our common stock in the amount of $0.26 per share. The dividend is payable on June 15, 2022 to shareholders of record at the close of business on May 18, 2022.
