# POWL note change history — 0000080420-22-000007 → 0000080420-22-000019


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2022-05-04):
[0000080420-22-000019:note_history:1]
Certain customers require us to post letters of credit, bank guarantees or surety bonds. These security instruments assure that we will perform under the terms of our contract. In the event of default, the counterparty may demand payment from the bank under a letter of credit or bank guarantee, or performance by the surety under a bond. To date, there have been no significant draws or claims related to security instruments for the periods reported. We were contingently liable for letters of credit of $32.2 million as of March 31, 2022. We also had surety bonds totaling $149.0 million that were outstanding, with additional bonding capacity of $451.0 million available, at March 31, 2022. We have strong surety relationships; however, a change in market conditions or the sureties' assessment of our financial position could cause the sureties to require cash collateralization for undischarged liabilities under the bonds.
  (was, 2022-02-09, similarity 0.9792):
[0000080420-22-000007:note_history:1]
Certain customers require us to post letters of credit, bank guarantees or surety bonds. These security instruments assure that we will perform under the terms of our contract. In the event of default, the counterparty may demand payment from the bank under a letter of credit or bank guarantee, or performance by the surety under a bond. To date, there have been no significant draws or claims related to security instruments for the periods reported. We were contingently liable for letters of credit of $31.2 million as of December 31, 2021. We also had surety bonds totaling $144.4 million that were outstanding, with additional bonding capacity of $455.6 million available, at December 31, 2021. At present, we have strong surety relationships; however, a change in market conditions or the sureties' assessment of our financial position could cause the sureties to require cash collateralization for undischarged liabilities under the bonds.

- changed (2022-05-04):
[0000080420-22-000019:note_history:2]
We have a $6.6 million facility agreement (Facility Agreement) between Powell (UK) Limited and a large international bank that provides Powell (UK) Limited the ability to enter into bank guarantees as well as forward exchange contracts and currency options. At March 31, 2022, we had outstanding guarantees totaling $3.2 million and amounts available under this Facility Agreement were $3.4 million. The Facility Agreement provides for customary events of default, and carries cross-default provisions with our U.S. Revolver. If an event of default (as defined in the Facility Agreement) occurs and is continuing, per the terms and subject to the conditions set forth therein, obligations outstanding under the Facility Agreement may be accelerated and declared immediately due and payable. Additionally, we are required to maintain cash collateral for guarantees greater than two years. As of March 31, 2022, we were in compliance with all of the financial covenants of the Facility Agreement.
  (was, 2022-02-09, similarity 0.9218):
[0000080420-22-000007:note_history:2]
We have a $9.5 million facility agreement (Facility Agreement) between Powell (UK) Limited and a large international bank that provides Powell (UK) Limited the ability to enter into bank guarantees as well as forward exchange contracts and currency options. At December 31, 2021, we had outstanding guarantees totaling $3.3 million and amounts available under this Facility Agreement were $6.2 million. The Facility Agreement provides for customary events of default, and carries cross-default provisions with our U.S. Revolver. If an event of default (as defined in the Facility Agreement) occurs and is continuing, per the terms and subject to the conditions set forth therein, obligations outstanding under the Facility Agreement may be accelerated and declared immediately due and payable. Additionally, we are required to maintain cash collateral for guarantees greater than two years. As of December 31, 2021, we were in compliance with all of the financial covenants of the Facility Agreement. In accordance with the terms of the Facility Agreement, the total amount available was reduced from $9.5 million to $6.8 million in January 2022.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureAndSignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2022-05-04):
[0000080420-22-000019:note_history:3]
Impact of Global Economic Uncertainty and Oil and Gas Commodity Market Volatility on Powell
  (was, 2022-02-09, similarity 0.8114):
[0000080420-22-000007:note_history:3]
Impact of the COVID-19 Pandemic and Oil and Gas Commodity Market Volatility on Powell

- changed (2022-05-04):
[0000080420-22-000019:note_history:4]
Various factors resulting in global economic uncertainty have negatively impacted our results over the last 18 months. In particular, the COVID-19 pandemic continues to impact global energy markets. This pandemic has negatively impacted demand, which in turn has resulted in considerable volatility across global oil and gas commodity markets. As a result, some of our industrial customers have deferred or suspended their planned capital expenditures. During this period, certain of our customers have asked that we delay or cancel our manufacturing on their projects as their operations have been negatively impacted by this pandemic and the reduced oil and gas demand, which has resulted in recognition of cancellation fees based on contract terms and the extent of our progress on the projects. We continue to work with our key suppliers who are facing various issues related to the availability and timing of the receipt of key component parts and commodities to ensure that we are able to meet our customer commitments.
  (was, 2022-02-09, similarity 0.8017):
[0000080420-22-000007:note_history:4]
The COVID-19 pandemic continues to impact global energy markets. This pandemic has negatively impacted demand, which in turn has resulted in considerable volatility across global oil and gas commodity markets. As a result, some of our industrial customers are deferring or suspending their planned capital expenditures. Certain of our customers have asked that we delay or cancel our manufacturing on their projects as their operations have been negatively impacted by this pandemic and the reduced oil and gas demand, which has resulted in recognition of cancellation fees based on contract terms and the extent of our progress on the projects. We continue to work with and review the contracts with our key suppliers who have been impacted by this pandemic to ensure that we are able to meet our customer commitments.


## us-gaap:LongTermDebtTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2022-05-04):
[0000080420-22-000019:note_history:5]
|  | March 31, 2022 |  | September 30, 2021 |
| Industrial development revenue bonds | $ | — |  |  | $ | 400 |  |
| Less: current portion | — |  |  | (400) |  |
| Total long-term debt | $ | — |  |  | $ | — |  |
  (was, 2022-02-09, similarity 0.9759):
[0000080420-22-000007:note_history:5]
|  | December 31, 2021 |  | September 30, 2021 |
| Industrial development revenue bonds | $ | — |  |  | $ | 400 |  |
| Less: current portion | — |  |  | (400) |  |
| Total long-term debt | $ | — |  |  | $ | — |  |

- changed (2022-05-04):
[0000080420-22-000019:note_history:6]
We have a credit agreement with Bank of America, N.A. (as amended, the "U.S. Revolver"), which is a $75.0 million revolving credit facility that is available for both borrowings and letters of credit and expires September 27, 2024. The U.S. Revolver states that up to $30 million may be deducted from the amount of letters of credit outstanding (not to be less than zero) when calculating the consolidated funded indebtedness which is a component of the consolidated net leverage ratio. Additionally, we have the option to cash collateralize all or a portion of the letters of credit outstanding, which would favorably impact the consolidated funded indebtedness calculation and the consolidated net leverage ratio. As of March 31, 2022, there were no amounts borrowed under the U.S. Revolver and letters of credit outstanding were $32.2 million. There was $42.8 million available for the issuance of letters of credit and borrowings under the U.S. Revolver as of March 31, 2022.
  (was, 2022-02-09, similarity 0.9864):
[0000080420-22-000007:note_history:6]
We have a credit agreement with Bank of America, N.A. (as amended, the "U.S. Revolver"), which is a $75.0 million revolving credit facility that is available for both borrowings and letters of credit and expires September 27, 2024. The U.S. Revolver states that up to $30 million may be deducted from the amount of letters of credit outstanding (not to be less than zero) when calculating the consolidated funded indebtedness which is a component of the consolidated net leverage ratio. Additionally, we have the option to cash collateralize all or a portion of the letters of credit outstanding, which would favorably impact the consolidated funded indebtedness calculation and the consolidated net leverage ratio. As of December 31, 2021, there were no amounts borrowed under the U.S. Revolver and letters of credit outstanding were $31.2 million. There was $43.8 million available for the issuance of letters of credit and borrowings under the U.S. Revolver as of December 31, 2021.

- changed (2022-05-04):
[0000080420-22-000019:note_history:7]
We are required to maintain certain financial covenants, the most significant of which are a consolidated net leverage ratio less than 3.0 to 1.0 and a consolidated interest coverage ratio of greater than 3.0 to 1.0. Our most restrictive covenant, the consolidated net leverage ratio, is the ratio of earnings before interest, taxes, depreciation, amortization and stock-based compensation (EBITDAS) to funded indebtedness. An increase in indebtedness, which includes letters of credit, or a decrease in EBITDAS could restrict our ability to issue letters of credit or borrow under the U.S. Revolver. Additionally, we must maintain a consolidated cash balance of $30 million at all times, which can be deducted from the letters of credit outstanding as noted above. The U.S. Revolver also contains a "material adverse effect" clause which is a material change in our operations, business, properties, liabilities or condition (financial or otherwise) or a material impairment of our ability to perform our obligations under our credit agreements. As of March 31, 2022, we were in compliance with all of the financial covenants of the U.S. Revolver.
  (was, 2022-02-09, similarity 0.9943):
[0000080420-22-000007:note_history:7]
We are required to maintain certain financial covenants, the most significant of which are a consolidated net leverage ratio less than 3.0 to 1.0 and a consolidated interest coverage ratio of greater than 3.0 to 1.0. Our most restrictive covenant, the consolidated net leverage ratio, is the ratio of earnings before interest, taxes, depreciation, amortization and stock-based compensation (EBITDAS) to funded indebtedness. An increase in indebtedness, which includes letters of credit, or a decrease in EBITDAS could restrict our ability to issue letters of credit or borrow under the U.S. Revolver. Additionally, we must maintain a consolidated cash balance of $30 million at all times, which can be deducted from the letters of credit outstanding as noted above. The U.S. Revolver also contains a "material adverse effect" clause which is a material change in our operations, business, properties, liabilities or condition (financial or otherwise) or a material impairment of our ability to perform our obligations under our credit agreements. As of December 31, 2021, we were in compliance with all of the financial covenants of the U.S. Revolver.


## us-gaap:ScheduleOfDebtInstrumentsTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2022-05-04):
[0000080420-22-000019:note_history:8]
|  | March 31, 2022 |  | September 30, 2021 |
| Industrial development revenue bonds | $ | — |  |  | $ | 400 |  |
| Less: current portion | — |  |  | (400) |  |
| Total long-term debt | $ | — |  |  | $ | — |  |
  (was, 2022-02-09, similarity 0.9759):
[0000080420-22-000007:note_history:8]
|  | December 31, 2021 |  | September 30, 2021 |
| Industrial development revenue bonds | $ | — |  |  | $ | 400 |  |
| Less: current portion | — |  |  | (400) |  |
| Total long-term debt | $ | — |  |  | $ | — |  |


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2022-05-04):
[0000080420-22-000019:note_history:9]
The following tables present our disaggregated revenue by geographic destination and market sector for the three and six months ended March 31, 2022 and 2021 (in thousands):
  (was, 2022-02-09, similarity 0.9477):
[0000080420-22-000007:note_history:9]
The following tables present our disaggregated revenue by geographic destination and market sector for the three months ended December 31, 2021 and 2020 (in thousands):

- changed (2022-05-04):
[0000080420-22-000019:note_history:10]
|  | Three months ended March 31, |  | Six months ended March 31, |
|  | 2022 |  | 2021 |  | 2022 |  | 2021 |
| United States | $ | 86,992 |  |  | $ | 87,939 |  |  | $ | 169,137 |  |  | $ | 168,525 |  |
| Canada | 22,053 |  |  | 17,734 |  |  | 37,178 |  |  | 31,825 |  |
| Europe, Middle East and Africa | 15,551 |  |  | 10,937 |  |  | 23,381 |  |  | 19,193 |  |
| Asia/Pacific | 1,646 |  |  | 2,009 |  |  | 2,590 |  |  | 4,725 |  |
| Mexico, Central and South America | 1,612 |  |  | 97 |  |  | 2,137 |  |  | 1,023 |  |
| Total revenues by geographic destination | $ | 127,854 |  |  | $ | 118,716 |  |  | $ | 234,423 |  |  | $ | 225,291 |  |
  (was, 2022-02-09, similarity 0.7057):
[0000080420-22-000007:note_history:10]
|  | Three months ended December 31, |  |  |
|  | 2021 |  | 2020 |  |  |  |  |
| United States | $ | 82,145 |  |  | $ | 80,586 |  |  |  |  |  |
| Canada | 15,125 |  |  | 14,091 |  |  |  |  |  |
| Europe, Middle East and Africa | 7,830 |  |  | 8,256 |  |  |  |  |  |
| Asia/Pacific | 944 |  |  | 2,716 |  |  |  |  |  |
| Mexico, Central and South America | 525 |  |  | 926 |  |  |  |  |  |
| Total revenues by geographic destination | $ | 106,569 |  |  | $ | 106,575 |  |  |  |  |  |

- changed (2022-05-04):
[0000080420-22-000019:note_history:11]
|  | Three months ended March 31, |  | Six months ended March 31, |
|  | 2022 |  | 2021 |  | 2022 |  | 2021 |
| Oil and gas (excludes petrochemical) | $ | 53,634 |  |  | $ | 50,142 |  |  | $ | 96,655 |  |  | $ | 90,171 |  |
| Petrochemical | 18,853 |  |  | 10,196 |  |  | 36,081 |  |  | 19,361 |  |
| Electric utility | 30,374 |  |  | 28,452 |  |  | 51,907 |  |  | 56,622 |  |
| Traction power | 10,054 |  |  | 15,140 |  |  | 21,426 |  |  | 28,501 |  |
| All others | 14,939 |  |  | 14,786 |  |  | 28,354 |  |  | 30,636 |  |
| Total revenues by market sector | $ | 127,854 |  |  | $ | 118,716 |  |  | $ | 234,423 |  |  | $ | 225,291 |  |
  (was, 2022-02-09, similarity 0.6386):
[0000080420-22-000007:note_history:11]
|  | Three months ended December 31, |  |  |
|  | 2021 |  | 2020 |  |  |  |  |
| Oil and gas (excludes petrochemical) | $ | 43,021 |  |  | $ | 40,028 |  |  |  |  |  |
| Petrochemical | 17,228 |  |  | 9,165 |  |  |  |  |  |
| Electric utility | 21,533 |  |  | 28,171 |  |  |  |  |  |
| Traction power | 11,372 |  |  | 13,361 |  |  |  |  |  |
| All others | 13,415 |  |  | 15,850 |  |  |  |  |  |
| Total revenues by market sector | $ | 106,569 |  |  | $ | 106,575 |  |  |  |  |  |


## us-gaap:RevenueFromContractWithCustomerPolicyTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2022-05-04):
[0000080420-22-000019:note_history:12]
We also have contracts to provide value-added services such as field service inspection, installation, commissioning, modification and repair, as well as retrofit and retrofill components for existing systems.  If the service contract terms give us the right to invoice the customer for an amount that corresponds directly with the value of our performance completed to date (i.e., a service contract in which we bill a fixed amount for each hour of service provided), then we recognize revenue over time in each reporting period corresponding to the amount with which we have the right to invoice.  Our performance obligations are satisfied as the work progresses. Revenues from our custom-engineered products and value-added services transferred to customers over time accounted for approximately 94% of total revenues for the three and six months ended March 31, 2022, 93% of total revenues for the three months ended March 31, 2021 and 92% of total revenues for the six months ended March 31, 2021.
  (was, 2022-02-09, similarity 0.9348):
[0000080420-22-000007:note_history:12]
We also have contracts to provide value-added services such as field service inspection, installation, commissioning, modification and repair, as well as retrofit and retrofill components for existing systems.  If the service contract terms give us the right to invoice the customer for an amount that corresponds directly with the value of our performance completed to date (i.e., a service contract in which we bill a fixed amount for each hour of service provided), then we recognize revenue over time in each reporting period corresponding to the amount with which we have the right to invoice.  Our performance obligations are satisfied as the work progresses. Revenues from our custom-engineered products and value-added services transferred to customers over time accounted for approximately 94% of total revenues for the three months ended December 31, 2021 and 92% of total revenues for the three months ended December 31, 2020.

- added (2022-05-04):
[0000080420-22-000019:note_history:13]
Additionally, we have sales orders for spare parts and replacement circuit breakers for switchgear that are obsolete or that are no longer produced by the original manufacturer. Revenues from these sales orders are recognized at the time we fulfill our performance obligation to the customer, which is typically upon shipment and represented approximately 6% of total revenues for the three and six months ended March 31, 2022, 7% of total revenues for the three months ended March 31, 2021 and 8% of total revenues for the six months ended March 31, 2021. 
Some contracts may contain a cancellation clause that could limit the amount of revenue we are able to recognize over time. In these instances, revenue and costs associated with these contracts are deferred and recognized at a point in time when the performance obligation is fulfilled.Selling and administrative costs incurred in relation to obtaining a contract are typically expensed as incurred. We periodically utilize a third-party sales agent to obtain a contract and will pay a commission to that agent. We record the full commission liability to the third-party sales agents at the order date, with a corresponding deferred asset. As the project progresses, we record commission expense based on percentage of completion rates that correlate to the project and reduce the deferred asset. Once we have been paid by the customer, we pay the commission and the deferred liability is reduced
Performance Obligations

- removed (2022-05-04):
[0000080420-22-000007:note_history:14]
Additionally, we have sales orders for spare parts and replacement circuit breakers for switchgear that are obsolete or that are no longer produced by the original manufacturer. Revenues from these sales orders are recognized at the time we fulfill our performance obligation to the customer, which is typically upon shipment and represented approximately 6% of total revenues for the three months ended December 31, 2021 and 8% of total revenues for the three months ended December 31, 2020.

- removed (2022-05-04):
[0000080420-22-000007:note_history:15]
Some contracts may contain a cancellation clause that could limit the amount of revenue we are able to recognize over time. In these instances, revenue and costs associated with these contracts are deferred and recognized at a point in time when the performance obligation is fulfilled.
Selling and administrative costs incurred in relation to obtaining a contract are typically expensed as incurred. We periodically utilize a third-party sales agent to obtain a contract and will pay a commission to that agent. We record the full commission liability to the third-party sales agents at the order date, with a corresponding deferred asset. As the project progresses, we record commission expense based on percentage of completion rates that correlate to the project and reduce the deferred asset. Once we have been paid by the customer, we pay the commission and the deferred liability is reduced
Performance Obligations


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2022-05-04):
[0000080420-22-000019:note_history:16]
We also have contracts to provide value-added services such as field service inspection, installation, commissioning, modification and repair, as well as retrofit and retrofill components for existing systems.  If the service contract terms give us the right to invoice the customer for an amount that corresponds directly with the value of our performance completed to date (i.e., a service contract in which we bill a fixed amount for each hour of service provided), then we recognize revenue over time in each reporting period corresponding to the amount with which we have the right to invoice.  Our performance obligations are satisfied as the work progresses. Revenues from our custom-engineered products and value-added services transferred to customers over time accounted for approximately 94% of total revenues for the three and six months ended March 31, 2022, 93% of total revenues for the three months ended March 31, 2021 and 92% of total revenues for the six months ended March 31, 2021.
  (was, 2022-02-09, similarity 0.9348):
[0000080420-22-000007:note_history:16]
We also have contracts to provide value-added services such as field service inspection, installation, commissioning, modification and repair, as well as retrofit and retrofill components for existing systems.  If the service contract terms give us the right to invoice the customer for an amount that corresponds directly with the value of our performance completed to date (i.e., a service contract in which we bill a fixed amount for each hour of service provided), then we recognize revenue over time in each reporting period corresponding to the amount with which we have the right to invoice.  Our performance obligations are satisfied as the work progresses. Revenues from our custom-engineered products and value-added services transferred to customers over time accounted for approximately 94% of total revenues for the three months ended December 31, 2021 and 92% of total revenues for the three months ended December 31, 2020.

- changed (2022-05-04):
[0000080420-22-000019:note_history:17]
Additionally, we have sales orders for spare parts and replacement circuit breakers for switchgear that are obsolete or that are no longer produced by the original manufacturer. Revenues from these sales orders are recognized at the time we fulfill our performance obligation to the customer, which is typically upon shipment and represented approximately 6% of total revenues for the three and six months ended March 31, 2022, 7% of total revenues for the three months ended March 31, 2021 and 8% of total revenues for the six months ended March 31, 2021.
  (was, 2022-02-09, similarity 0.8627):
[0000080420-22-000007:note_history:17]
Additionally, we have sales orders for spare parts and replacement circuit breakers for switchgear that are obsolete or that are no longer produced by the original manufacturer. Revenues from these sales orders are recognized at the time we fulfill our performance obligation to the customer, which is typically upon shipment and represented approximately 6% of total revenues for the three months ended December 31, 2021 and 8% of total revenues for the three months ended December 31, 2020.

- changed (2022-05-04):
[0000080420-22-000019:note_history:18]
Remaining unsatisfied performance obligations, which we refer to as backlog, represent the estimated transaction price for goods and services for which we have a material right, but work has not been performed. As of March 31, 2022, we had backlog of $440.0 million, of which approximately $310.9 million is expected to be recognized as revenue within the next twelve months. Backlog may not be indicative of future operating results as orders may be cancelled or modified by our customers. Our backlog does not include service and maintenance-type contracts for which we have the right to invoice as services are performed.
  (was, 2022-02-09, similarity 0.9894):
[0000080420-22-000007:note_history:18]
Remaining unsatisfied performance obligations, which we refer to as backlog, represent the estimated transaction price for goods and services for which we have a material right, but work has not been performed. As of December 31, 2021, we had backlog of $416.0 million, of which approximately $301.7 million is expected to be recognized as revenue within the next twelve months. Backlog may not be indicative of future operating results as orders may be cancelled or modified by our customers. Our backlog does not include service and maintenance-type contracts for which we have the right to invoice as services are performed.

- changed (2022-05-04):
[0000080420-22-000019:note_history:19]
For the six months ended March 31, 2022 and 2021, our operating results were positively impacted by $5.6 million and $8.2 million, respectively, as a result of changes in contract estimates related to projects in progress at the beginning of the respective period. These changes in estimates resulted primarily from favorable project execution and negotiations of variable consideration, discussed below, as well as revenue and reduced costs recognized from project cancellations and other changes in facts and circumstances during these periods. The decrease from the prior year is primarily due to the increase in direct materials cost, which we were not able to pass on to our customers.
  (was, 2022-02-09, similarity 0.8889):
[0000080420-22-000007:note_history:19]
For the three months ended December 31, 2021 and 2020, our operating results were positively impacted by $2.8 million and $5.5 million, respectively, as a result of changes in contract estimates related to projects in progress at the beginning of the respective period. These changes in estimates resulted primarily from favorable project execution and negotiations of variable consideration, discussed below, as well as revenue and reduced costs recognized from project cancellations and other changes in facts and circumstances during these periods. The decrease from the prior year is primarily due to the increase in raw material commodity costs.

- changed (2022-05-04):
[0000080420-22-000019:note_history:20]
Contract assets and liabilities as of March 31, 2022 and September 30, 2021 are summarized below (in thousands):
  (was, 2022-02-09, similarity 0.9565):
[0000080420-22-000007:note_history:20]
Contract assets and liabilities as of December 31, 2021 and September 30, 2021 are summarized below (in thousands):

- changed (2022-05-04):
[0000080420-22-000019:note_history:21]
|  | March 31, 2022 |  | September 30, 2021 |
| Contract assets | $ | 58,553 |  |  | $ | 54,199 |  |
| Contract liabilities | (56,706) |  |  | (42,433) |  |
| Net contract asset | $ | 1,847 |  |  | $ | 11,766 |  |
  (was, 2022-02-09, similarity 0.9726):
[0000080420-22-000007:note_history:21]
|  | December 31, 2021 |  | September 30, 2021 |
| Contract assets | $ | 67,904 |  |  | $ | 54,199 |  |
| Contract liabilities | (49,396) |  |  | (42,433) |  |
| Net contract asset | $ | 18,508 |  |  | $ | 11,766 |  |

- changed (2022-05-04):
[0000080420-22-000019:note_history:22]
The decrease in net contract asset at March 31, 2022 from September 30, 2021 was primarily due to the timing of contract billing milestones and new orders as well as cash used on our large industrial project awarded in Fiscal 2020. To determine the amount of revenue recognized during the period from contract liabilities, we first allocate revenue to the individual contract liability balance outstanding at the beginning of the period until the revenue exceeds that balance. During the six months ended March 31, 2022, we recognized revenue of approximately $33.5 million that was related to contract liabilities outstanding at September 30, 2021.
  (was, 2022-02-09, similarity 0.7019):
[0000080420-22-000007:note_history:22]
The increase in net contract asset at December 31, 2021 from September 30, 2021 was primarily due to the timing of contract billing milestones and new orders as well as cash used on our large industrial project awarded in Fiscal 2020. To determine the amount of revenue recognized during the period from contract liabilities, we first allocate revenue to the individual contract liability balance outstanding at the beginning of the period until the revenue exceeds that balance. During the three months ended December 31, 2021, we recognized revenue of approximately $23.3 million that was related to contract liabilities outstanding at September 30, 2021.

- changed (2022-05-04):
[0000080420-22-000019:note_history:23]
The timing of our invoice process is typically dependent on the completion of certain milestones and contract terms and subject to agreement by our customer.  Payment is typically expected within 30 days of invoice. Any uncollected invoiced amounts for our performance obligations recognized over time, including contract retentions, are recorded as accounts receivable in the Condensed Consolidated Balance Sheets. Certain contracts allow customers to withhold a small percentage of billings pursuant to retainage provisions, and such amounts are generally due upon completion of the contract and acceptance of the project by the customer. Based on our experience in recent years, the majority of these retainage balances are expected to be collected within approximately twelve months. As of March 31, 2022 and September 30, 2021, accounts receivable included retention amounts of $9.8 million and $9.6 million, respectively. Of the retained amount at March 31, 2022, $9.1 million is expected to be collected in the next twelve months and is recorded in accounts receivable. The remaining $0.7 million is recorded in other assets.
  (was, 2022-02-09, similarity 0.9883):
[0000080420-22-000007:note_history:23]
The timing of our invoice process is typically dependent on the completion of certain milestones and contract terms and subject to agreement by our customer.  Payment is typically expected within 30 days of invoice. Any uncollected invoiced amounts for our performance obligations recognized over time, including contract retentions, are recorded as accounts receivable in the Condensed Consolidated Balance Sheets. Certain contracts allow customers to withhold a small percentage of billings pursuant to retainage provisions, and such amounts are generally due upon completion of the contract and acceptance of the project by the customer. Based on our experience in recent years, the majority of these retainage balances are expected to be collected within approximately twelve months. As of December 31, 2021 and September 30, 2021, accounts receivable included retention amounts of $9.3 million and $9.6 million, respectively. Of the retained amount at December 31, 2021, $6.8 million is expected to be collected in the next twelve months and is recorded in accounts receivable. The remaining $2.5 million is recorded in other assets.

- changed (2022-05-04):
[0000080420-22-000019:note_history:24]
The following tables present our disaggregated revenue by geographic destination and market sector for the three and six months ended March 31, 2022 and 2021 (in thousands):
  (was, 2022-02-09, similarity 0.9477):
[0000080420-22-000007:note_history:24]
The following tables present our disaggregated revenue by geographic destination and market sector for the three months ended December 31, 2021 and 2020 (in thousands):

- changed (2022-05-04):
[0000080420-22-000019:note_history:25]
|  | Three months ended March 31, |  | Six months ended March 31, |
|  | 2022 |  | 2021 |  | 2022 |  | 2021 |
| United States | $ | 86,992 |  |  | $ | 87,939 |  |  | $ | 169,137 |  |  | $ | 168,525 |  |
| Canada | 22,053 |  |  | 17,734 |  |  | 37,178 |  |  | 31,825 |  |
| Europe, Middle East and Africa | 15,551 |  |  | 10,937 |  |  | 23,381 |  |  | 19,193 |  |
| Asia/Pacific | 1,646 |  |  | 2,009 |  |  | 2,590 |  |  | 4,725 |  |
| Mexico, Central and South America | 1,612 |  |  | 97 |  |  | 2,137 |  |  | 1,023 |  |
| Total revenues by geographic destination | $ | 127,854 |  |  | $ | 118,716 |  |  | $ | 234,423 |  |  | $ | 225,291 |  |
  (was, 2022-02-09, similarity 0.7057):
[0000080420-22-000007:note_history:25]
|  | Three months ended December 31, |  |  |
|  | 2021 |  | 2020 |  |  |  |  |
| United States | $ | 82,145 |  |  | $ | 80,586 |  |  |  |  |  |
| Canada | 15,125 |  |  | 14,091 |  |  |  |  |  |
| Europe, Middle East and Africa | 7,830 |  |  | 8,256 |  |  |  |  |  |
| Asia/Pacific | 944 |  |  | 2,716 |  |  |  |  |  |
| Mexico, Central and South America | 525 |  |  | 926 |  |  |  |  |  |
| Total revenues by geographic destination | $ | 106,569 |  |  | $ | 106,575 |  |  |  |  |  |

- changed (2022-05-04):
[0000080420-22-000019:note_history:26]
|  | Three months ended March 31, |  | Six months ended March 31, |
|  | 2022 |  | 2021 |  | 2022 |  | 2021 |
| Oil and gas (excludes petrochemical) | $ | 53,634 |  |  | $ | 50,142 |  |  | $ | 96,655 |  |  | $ | 90,171 |  |
| Petrochemical | 18,853 |  |  | 10,196 |  |  | 36,081 |  |  | 19,361 |  |
| Electric utility | 30,374 |  |  | 28,452 |  |  | 51,907 |  |  | 56,622 |  |
| Traction power | 10,054 |  |  | 15,140 |  |  | 21,426 |  |  | 28,501 |  |
| All others | 14,939 |  |  | 14,786 |  |  | 28,354 |  |  | 30,636 |  |
| Total revenues by market sector | $ | 127,854 |  |  | $ | 118,716 |  |  | $ | 234,423 |  |  | $ | 225,291 |  |
  (was, 2022-02-09, similarity 0.6386):
[0000080420-22-000007:note_history:26]
|  | Three months ended December 31, |  |  |
|  | 2021 |  | 2020 |  |  |  |  |
| Oil and gas (excludes petrochemical) | $ | 43,021 |  |  | $ | 40,028 |  |  |  |  |  |
| Petrochemical | 17,228 |  |  | 9,165 |  |  |  |  |  |
| Electric utility | 21,533 |  |  | 28,171 |  |  |  |  |  |
| Traction power | 11,372 |  |  | 13,361 |  |  |  |  |  |
| All others | 13,415 |  |  | 15,850 |  |  |  |  |  |
| Total revenues by market sector | $ | 106,569 |  |  | $ | 106,575 |  |  |  |  |  |


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: tag_name, score: 1.0

- changed (2022-05-04):
[0000080420-22-000019:note_history:27]
On May 3, 2022, our Board of Directors declared a quarterly cash dividend on our common stock in the amount of $0.26 per share. The dividend is payable on June 15, 2022 to shareholders of record at the close of business on May 18, 2022.
  (was, 2022-02-09, similarity 0.6517):
[0000080420-22-000007:note_history:27]
On February 1, 2022, our Board of Directors declared a quarterly cash dividend on our common stock in the amount of $0.26 per share. The dividend is payable on March 16, 2022 to shareholders of record at the close of business on February 16, 2022.
