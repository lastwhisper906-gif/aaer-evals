# POWL MD&A — 0000080420-18-000013


## mdna

[0000080420-18-000013:mdna:1]
[same as prior period, unchanged from 0000080420-18-000007:mdna:1]

[0000080420-18-000013:mdna:2]
[same as prior period, unchanged from 0000080420-18-000007:mdna:2]

[0000080420-18-000013:mdna:3]
[same as prior period, unchanged from 0000080420-18-000007:mdna:3]

[0000080420-18-000013:mdna:4]
[same as prior period, unchanged from 0000080420-18-000007:mdna:4]

[0000080420-18-000013:mdna:5]
[same as prior period, unchanged from 0000080420-18-000007:mdna:5]

[0000080420-18-000013:mdna:6]
[same as prior period, unchanged from 0000080420-18-000007:mdna:6]

[0000080420-18-000013:mdna:7]
[same as prior period, unchanged from 0000080420-18-000007:mdna:7]

[0000080420-18-000013:mdna:8]
Quarter Ended March 31, 2018 Compared to the Quarter Ended March 31, 2017 (Unaudited)

[0000080420-18-000013:mdna:9]
[same as prior period, unchanged from 0000080420-18-000007:mdna:9]

[0000080420-18-000013:mdna:10]
Revenues decreased by 3%, or $3.2 million, to $101.5 million in the second quarter of Fiscal 2018, compared to the second quarter of Fiscal 2017, primarily due to the decrease in our project backlog at the beginning of the respective quarter. This decrease in revenues is primarily from our international operations as we complete existing projects and continue to see lower demand from customers in their core oil and gas markets. Domestic revenues decreased by 5%, or $4.0 million, to $71.6 million in the second quarter of Fiscal 2018, compared to the second quarter of Fiscal 2017. The reduction in domestic revenues year over year was driven by the decline in our project backlog mentioned above. International revenues increased by 3%, or $0.8 million, to $30.0 million in the second quarter of Fiscal 2018, compared to the second quarter of Fiscal 2017. Our international revenue includes both revenue generated from our international facilities as well as export revenues from our domestic facilities. The increase in international revenues resulted from an increase in international export projects manufactured at our domestic facilities. Revenues from commercial and industrial customers increased slightly by 1%, or $0.7 million, to $70.6 million in the second quarter of Fiscal 2018, compared to the second quarter of Fiscal 2017. Revenues from public and private utilities increased by 43%, or $6.9 million, to $22.8 million in the second quarter of Fiscal 2018, compared to the second quarter of Fiscal 2017. Revenues from municipal and transit projects decreased by 57%, or $10.8 million, to $8.0 million in the second quarter of Fiscal 2018, compared to the second quarter of Fiscal 2017. The increase in public and private utilities and the decrease in municipal and transit revenues were primarily due to the timing of projects.

[0000080420-18-000013:mdna:11]
Gross profit for the second quarter of Fiscal 2018 decreased by 21%, or $3.4 million, to $12.4 million, compared to the second quarter of Fiscal 2017. Gross profit as a percentage of revenues decreased to 12% in the second quarter of Fiscal 2018, compared to 15% in the second quarter of Fiscal 2017. Gross profit and margins continued to be negatively impacted by our reduced volume resulting in under absorption of our manufacturing facility costs and a shift in project mix to smaller projects. This decline in volume and margins is primarily due to the decline in our project backlog at the beginning of the respective periods resulting from depressed market conditions and competitive pricing pressures primarily in our core oil, gas and petrochemical markets. Gross profit and margins were also negatively impacted by costs incurred on an oil and gas project for which change orders have not been finalized.

[0000080420-18-000013:mdna:12]
[same as prior period, unchanged from 0000080420-18-000007:mdna:12]

[0000080420-18-000013:mdna:13]
Selling, general and administrative expenses increased by less than $0.1 million, to $16.1 million during the second quarter of Fiscal 2018, compared to the second quarter of Fiscal 2017. Selling, general and administrative expenses, as a percentage of revenues, increased to 16% during the second quarter of Fiscal 2018, compared to 15% during the second quarter of Fiscal 2017, primarily due to the reduction in revenue.

[0000080420-18-000013:mdna:14]
Restructuring and Separation Expenses

[0000080420-18-000013:mdna:15]
During the second quarter of Fiscal 2018, we had no restructuring or separation expenses.  However, in the second quarter of Fiscal 2017 we incurred $0.8 million in restructuring and separation expenses as we continued to reduce our overall cost structure to better align our costs with future production requirements.

[0000080420-18-000013:mdna:16]
[same as prior period, unchanged from 0000080420-18-000007:mdna:14]

[0000080420-18-000013:mdna:17]
We recorded an income tax benefit of $1.8 million in the second quarter of Fiscal 2018, compared to an income tax benefit of $1.3 million in the second quarter of Fiscal 2017. The effective tax rate for the second quarter of Fiscal 2018 was 35% compared to an effective tax rate of 62% in the second quarter of Fiscal 2017. On December 22, 2017, President Trump signed into law the Tax Cuts and Jobs Act (the Act). The Act lowers the corporate tax rate from 35% to 21% effective January 1, 2018. As a result, the effective tax rate for the second quarter of Fiscal 2018 is a reduced blended U.S. tax rate of 24.5%. The final impact of the Act may differ from our estimates based on changes in interpretations or assumptions we make, as well as the issuance of additional guidance. In the second quarter of Fiscal 2018, the effective tax rate was impacted by the relative amounts of income/loss recognized in various jurisdictions as well as a deferred tax expense due to the remeasurement of our U.S. deferred tax assets, which are not expected to be realized prior to the end of Fiscal 2018 and a foreign tax loss which is reserved with a valuation allowance.

[0000080420-18-000013:mdna:18]
The effective tax rate for the second quarter of Fiscal 2017 was favorably impacted by the lower tax rate in the United Kingdom, the relative amounts of income/loss recognized in various jurisdictions, as well as the utilization of net operating loss carryforwards in Canada that are fully reserved with a valuation allowance.

[0000080420-18-000013:mdna:19]
[same as prior period, unchanged from 0000080420-18-000007:mdna:17]

[0000080420-18-000013:mdna:20]
In the second quarter of Fiscal 2018, we recorded a loss of $3.3 million, or $0.29 per diluted share compared to a net loss of $0.8 million, or $0.07 per diluted share, in the second quarter of Fiscal 2017. The increase in our net loss compared to the prior year was primarily due to a decline from our international operations due to depressed market conditions and competitive pricing pressures, primarily in their core oil and gas markets and the reduction in our effective tax rate as a result of the Act.

[0000080420-18-000013:mdna:21]
[same as prior period, unchanged from 0000080420-18-000007:mdna:19]

[0000080420-18-000013:mdna:22]
The order backlog at March 31, 2018 was $299.8 million, an increase from the $260.3 million at December 31, 2017, primarily due to an increase in commercial and industrial projects. New orders increased during the second quarter of Fiscal 2018 to $141.5 million, compared to $62.0 million in the second quarter of Fiscal 2017, primarily due to increased demand from our customers in our core oil, gas and petrochemical markets.

[0000080420-18-000013:mdna:23]
Six Months Ended March 31, 2018 Compared to the Six Months Ended March 31, 2017 (Unaudited)

[0000080420-18-000013:mdna:24]
Revenue and Gross Profit

[0000080420-18-000013:mdna:25]
Revenues decreased by 11%, or $23.3 million, to $191.7 million for the six months ended March 31, 2018, compared to the six months ended March 31, 2017, primarily due to the decrease in our project backlog at the beginning of the respective fiscal year as we complete existing projects and continue to see lower demand from our customers in our core oil, gas and petrochemical markets. Domestic revenues decreased by 18%, or $29.5 million, to $131.6 million for the six months ended March 31, 2018, compared to the six months ended March 31, 2017. The reduction in domestic revenues year over year was driven by the decline in our project backlog mentioned above. However, short-term, high demand remediation efforts following Hurricane Harvey resulted in approximately $7 million of revenue which partially offset the market challenges discussed above. International revenues increased by 12%, or $6.2 million, to $60.1 million for the six months ended March 31, 2018, compared to the six months ended March 31, 2017. Our international revenue includes both revenue generated from our international facilities as well as export revenues from our domestic facilities. The increase in international revenues resulted from an increase in international export projects manufactured at our domestic facilities. Revenues from commercial and industrial customers decreased by 8%, or $11.2 million, to $131.4 million for the six months ended March 31, 2018, compared to the six months ended March 31, 2017, primarily

[0000080420-18-000013:mdna:26]
due to lower demand in our core oil, gas and petrochemical markets. Revenues from public and private utilities increased by 48%, or $15.6 million, to $48.1 million for the six months ended March 31, 2018, compared to the six months ended March 31, 2017. Revenues from municipal and transit projects decreased by 70%, or $27.7 million, to $12.2 million for the six months ended March 31, 2018, compared to the six months ended March 31, 2017. The increase in public and private utilities and the decrease in municipal and transit revenues were primarily due to the timing of projects.

[0000080420-18-000013:mdna:27]
Gross profit for the six months ended March 31, 2018 decreased by 25%, or $7.8 million, to $23.0 million, compared to the six months ended March 31, 2017. Gross profit as a percentage of revenues decreased to 12% for the six months ended March 31, 2018, compared to 14% for the six months ended March 31, 2017. Gross profit and margins continued to be negatively impacted by our reduced volume resulting in under absorption of our manufacturing facility costs and a shift in project mix to smaller projects. This decline in volume and margins is primarily due to the decline in our project backlogs at the beginning of the respective periods resulting from depressed market conditions and competitive pricing pressures primarily in our core oil, gas and petrochemical markets. Gross profit and margins were also negatively impacted by costs incurred on an oil and gas project for which change orders have not been finalized.

[0000080420-18-000013:mdna:28]
Selling, General and Administrative Expenses

[0000080420-18-000013:mdna:29]
Selling, general and administrative expenses increased by 2%, or $0.6 million, to $32.3 million for the six months ended March 31, 2018, compared to the six months ended March 31, 2017, primarily due to the timing of variable performance based compensation. Selling, general and administrative expenses, as a percentage of revenues, increased to 17% during the six months ended March 31, 2018, compared to 15% during the six months ended March 31, 2017, primarily due to the reduction in revenue and slight increase in costs year over year.

[0000080420-18-000013:mdna:30]
Restructuring and Separation Expenses

[0000080420-18-000013:mdna:31]
In the six months ended March 31, 2018, we had no restructuring or separation expenses. However, in the six months ended March 31, 2017, we incurred $0.8 million in restructuring and separation expenses as we continued to reduce our overall cost structure to better align our costs with future production requirements.

[0000080420-18-000013:mdna:32]
Income Tax Benefit

[0000080420-18-000013:mdna:33]
We recorded an income tax benefit of $2.8 million for both the six months ended March 31, 2018 and 2017. However, the effective tax rate for the six months ended March 31, 2018 was 24% compared to an effective tax rate of 71% for the six months ended March 31, 2017. The effective tax rate for the six months ended March 31, 2018 was favorably impacted due to the lower corporate tax rate under the Act, but was partially offset by deferred tax expense of $0.8 million due to the remeasurement of our U.S. deferred tax assets, which are not expected to be realized prior to the end of Fiscal 2018. The effective tax rate for the six months ended March 31, 2017 was favorably impacted by a discrete item relating to the close of an IRS audit recorded during the first quarter of Fiscal 2017 due to the release of a $0.3 million FIN 48 reserve relating to the R&D Tax Credit. Additionally, the effective tax rate for the six months ended March 31, 2017 was impacted by the lower tax rate in the United Kingdom, the relative amounts of income/loss recognized in various jurisdictions, as well as the utilization of net operating loss carryforwards in Canada that are fully reserved with a valuation allowance.

[0000080420-18-000013:mdna:34]
Net loss

[0000080420-18-000013:mdna:35]
For the six months ended March 31, 2018, we recorded a loss of $9.0 million, or $0.78 per diluted share compared to a net loss of $1.1 million, or $0.10 per diluted share, for the six months ended March 31, 2017. The increase in our net loss compared to the prior year was primarily due to a decline in our project backlog at the beginning of the respective periods due to depressed market conditions and competitive pricing pressures, primarily in our core oil, gas and petrochemical markets and the reduction in our income tax benefit as a result of the Act.

[0000080420-18-000013:mdna:36]
Backlog

[0000080420-18-000013:mdna:37]
The order backlog at March 31, 2018 was $299.8 million, an increase from the $250.1 million at September 30, 2017, primarily due to an increase in commercial and industrial projects. New orders increased during the six months ended March 31, 2018 to $241.4 million, compared to $152.8 million for the six months ended March 31, 2017, primarily due to increased demand from our customers in our core oil, gas and petrochemical markets.

[0000080420-18-000013:mdna:38]
[same as prior period, unchanged from 0000080420-18-000007:mdna:21]

[0000080420-18-000013:mdna:39]
As of March 31, 2018, current assets exceeded current liabilities by 2.8 times and our debt to total capitalization was 0.52%.

[0000080420-18-000013:mdna:40]
Cash, cash equivalents and short-term investments decreased to $69.2 million at March 31, 2018, compared to $95.2 million at September 30, 2017. We had restricted cash held in a pledged collateral account related to our U.S. Revolver of $30.5 million at March 31, 2018 and $24.9 million at September 30, 2017. For further information regarding our U.S. Revolver, see Note D of Notes to Condensed Consolidated Financial Statements.

[0000080420-18-000013:mdna:41]
Our U.S. Revolver is a $75.0 million revolving credit facility in the U.S. As of March 31, 2018, there were no amounts borrowed under this facility. Total letters of credit outstanding under our U.S. Revolver, which reduce our availability, were $29.0 million at March 31, 2018 and $24.1 million at September 30, 2017. As of March 31, 2018, there was $46.0 million available for the issuance of letters of credit under the U.S. Revolver. Total long-term debt, including current maturities, totaled $1.6 million at March 31, 2018, compared to $2.0 million at September 30, 2017. For further information regarding our debt, see Notes D and E of Notes to Condensed Consolidated Financial Statements.

[0000080420-18-000013:mdna:42]
Approximately $33 million of our cash and short-term investments at March 31, 2018 was held outside of the United States for international operations. It is our intention to indefinitely reinvest all current and future foreign earnings internationally in order to ensure sufficient working capital to support our international operations. In the event that we elect to repatriate some or all of the foreign earnings that were previously deemed to be indefinitely reinvested outside the U.S., under current tax laws we would incur additional tax expense upon such repatriation.

[0000080420-18-000013:mdna:43]
[same as prior period, unchanged from 0000080420-18-000007:mdna:27]

[0000080420-18-000013:mdna:44]
[same as prior period, unchanged from 0000080420-18-000007:mdna:28]

[0000080420-18-000013:mdna:45]
Cash used in operating activities decreased to $10.6 million during the six months ended March 31, 2018, compared to cash provided by operating activities of $19.7 million during the same period in Fiscal 2017. This decrease in operating cash flow for the six months ended March 31, 2018 was primarily due to the reduction in earnings year over year and increases in accounts receivable, partially offset by project billings. Cash flow from operations is primarily influenced by project volume, the timing of milestone payments from our customers and the payment terms with our suppliers.

[0000080420-18-000013:mdna:46]
[same as prior period, unchanged from 0000080420-18-000007:mdna:30]

[0000080420-18-000013:mdna:47]
Net cash used in investing activities during the six months ended March 31, 2018 totaled $3.1 million compared to $16.6 million during the same period in Fiscal 2017. For the six months ended March 31, 2018, our net short-term investment activity was $5.3 million and we spent approximately $2.8 million on purchases of plant improvements and equipment. For the six months ended March 31, 2017, we had purchases of short-term investments of $14.9 million.

[0000080420-18-000013:mdna:48]
[same as prior period, unchanged from 0000080420-18-000007:mdna:32]

[0000080420-18-000013:mdna:49]
Net cash used in financing activities was $6.8 million and $6.7 million during the six months ended March 31, 2018 and 2017, respectively. These amounts primarily consisted of cash dividends of approximately $5.9 million in each period.

[0000080420-18-000013:mdna:50]
[same as prior period, unchanged from 0000080420-18-000007:mdna:34]

[0000080420-18-000013:mdna:51]
[same as prior period, unchanged from 0000080420-18-000007:mdna:35]

[0000080420-18-000013:mdna:52]
[same as prior period, unchanged from 0000080420-18-000007:mdna:36]

[0000080420-18-000013:mdna:53]
[same as prior period, unchanged from 0000080420-18-000007:mdna:37]

[0000080420-18-000013:mdna:54]
[same as prior period, unchanged from 0000080420-18-000007:mdna:38]

[0000080420-18-000013:mdna:55]
For the six months ended March 31, 2018, our operating loss was positively impacted by $2.5 million, as a result of changes in contract estimates related to projects in progress at the beginning of the respective periods. These changes in estimates resulted primarily from, among other things, successful execution and close-out improvements, as well as other changes in facts and circumstances during these periods.

[0000080420-18-000013:mdna:56]
[same as prior period, unchanged from 0000080420-18-000007:mdna:40]

[0000080420-18-000013:mdna:57]
[same as prior period, unchanged from 0000080420-18-000007:mdna:41]

[0000080420-18-000013:mdna:58]
A significant portion of our revenues have historically been from the oil, gas and petrochemical markets. Although oil and gas commodity price levels have stabilized, our customers continue to delay their investments. The reduction in available projects across the markets we serve has increased price pressures during this market cycle. This reduction in new business opportunities and increased market price pressures have impacted, and may continue to negatively impact, our backlog, revenues and operating results.

[0000080420-18-000013:mdna:59]
Our operating results have been, and we anticipate could continue to be, negatively impacted by factors such as the timing of new order awards, customer approval of final engineering and design specifications and delays in customer construction schedules, all of which have and could continue to have, a negative impact on the timing of project execution. Our operating results also have been, and could continue to be, impacted by the timing and resolution of change orders, project close-out and resolution of potential contract claims and liquidated damages, all of which could improve or deteriorate gross margins during the period in which these items are resolved with our customers. These factors may result in periods of underutilization of our resources and facilities and negatively impact our ability to cover our fixed costs. We continue to assess our cost structure, operating performance and service offerings as the oil, gas and petrochemical markets remain challenging and uncertain. Although our international operations continue to see challenging market conditions, our domestic operations have experienced a recent increase in bookings and we anticipate second half revenues and operating results to improve over the first half of Fiscal 2018.

[0000080420-18-000013:mdna:60]
We believe that our strong working capital position, cash available, low debt position and borrowing capacity under our existing credit facility should be sufficient to finance future operating activities, research and development initiatives, capital improvements and debt repayments for the foreseeable future. We continue to monitor the factors that drive our markets and will continue to strive to maintain our leadership and competitive advantage in the markets we serve while aligning our cost structures with market conditions.
