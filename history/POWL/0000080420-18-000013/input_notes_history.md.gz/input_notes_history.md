# POWL note change history — 0000080420-18-000007 → 0000080420-18-000013


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2018-05-09):
[0000080420-18-000013:note_history:1]
Certain customers require us to post letters of credit or surety bonds which assure that we will perform under the terms of our contract. In the event of default, the counterparty may demand payment from the bank under a letter of credit or performance by the surety under a bond. To date, there have been no significant expenses related to either letters of credit or surety bonds for the periods reported. We were contingently liable for letters of credit of $29.0 million as of March 31, 2018. We also had surety bonds totaling $176.9 million that were outstanding, with additional bonding capacity of $573.1 million available, at March 31, 2018.
  (was, 2018-02-07, similarity 0.9793):
[0000080420-18-000007:note_history:1]
Certain customers require us to post letters of credit or surety bonds which assure that we will perform under the terms of our contract. In the event of default, the counterparty may demand payment from the bank under a letter of credit or performance by the surety under a bond. To date, there have been no significant expenses related to either letters of credit or surety bonds for the periods reported. We were contingently liable for letters of credit of $27.0 million as of December 31, 2017. We also had surety bonds totaling $217.0 million that were outstanding, with additional bonding capacity of $533.0 million available, at December 31, 2017.

- changed (2018-05-09):
[0000080420-18-000013:note_history:2]
Additionally, we have a $7.0 million facility agreement (Facility Agreement) between Powell (UK) Limited and a large international bank. This Facility Agreement provides Powell (UK) Limited the ability to enter into bank guarantees as well as forward exchange contracts and currency options. At March 31, 2018, we had outstanding guarantees totaling $4.0 million under this Facility Agreement and amounts available under this Facility Agreement were $3.0 million. This facility expires May 31, 2018. The Facility Agreement provides for financial covenants and customary events of default, and carries cross-default provisions with our U.S. Revolver. If an event of default (as defined in the Facility Agreement) occurs and is continuing, per the terms and subject to the conditions set forth therein, obligations outstanding under the Facility Agreement may be accelerated and declared immediately due and payable. As of March 31, 2018, we were in compliance with all of the financial covenants of the Facility Agreement.
  (was, 2018-02-07, similarity 0.9815):
[0000080420-18-000007:note_history:2]
Additionally, we have a $6.7 million facility agreement (Facility Agreement) between Powell (UK) Limited and a large international bank. This Facility Agreement provides Powell (UK) Limited the ability to enter into bank guarantees as well as forward exchange contracts and currency options. At December 31, 2017, we had outstanding guarantees totaling $3.9 million under this Facility Agreement and amounts available under this Facility Agreement were $2.8 million. This facility expires in May 2018. The Facility Agreement provides for financial covenants and customary events of default, and carries cross-default provisions with our U.S. Revolver. If an event of default (as defined in the Facility Agreement) occurs and is continuing, per the terms and subject to the conditions set forth therein, obligations outstanding under the Facility Agreement may be accelerated and declared immediately due and payable. As of December 31, 2017, we were in compliance with all of the financial covenants of the Facility Agreement.

- changed (2018-05-09):
[0000080420-18-000013:note_history:3]
Certain of our customer contracts have schedule and performance obligation clauses that, if we fail to meet them, could require us to pay liquidated damages. Each individual contract defines the conditions under which the customer may make a claim against us. As of March 31, 2018, our exposure to possible liquidated damages was $2.5 million, of which approximately $1.6 million is probable. Based on our actual or projected failure to meet these various contractual commitments, $1.6 million has been recorded as a reduction to revenue. We will attempt to obtain change orders, contract extensions or accelerate project completion which may resolve the potential for any unaccrued liquidated damage. Should we fail to achieve relief on some or all of these contractual obligations, we could be required to pay additional liquidated damages, which could negatively impact our future operating results.
  (was, 2018-02-07, similarity 0.9927):
[0000080420-18-000007:note_history:3]
Certain of our customer contracts have schedule and performance obligation clauses that, if we fail to meet them, could require us to pay liquidated damages. Each individual contract defines the conditions under which the customer may make a claim against us. As of December 31, 2017, our exposure to possible liquidated damages was $2.4 million, of which approximately $1.5 million is probable. Based on our actual or projected failure to meet these various contractual commitments, $1.4 million has been recorded as a reduction to revenue. We will attempt to obtain change orders, contract extensions or accelerate project completion which may resolve the potential for any unaccrued liquidated damage. Should we fail to achieve relief on some or all of these contractual obligations, we could be required to pay additional liquidated damages, which could negatively impact our future operating results.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureAndSignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- added (2018-05-09):
[0000080420-18-000013:note_history:4]
In May 2014, the Financial Accounting Standards Board (FASB) issued a new standard on revenue recognition that supersedes previously issued revenue recognition guidance. This standard provides a five-step approach to be applied to all contracts with customers and requires expanded disclosures about the nature, amount, timing and uncertainty of revenue (and the related cash flows) arising from customer contracts, significant judgments and changes in judgments used in applying the revenue model and the assets recognized from costs incurred to obtain or fulfill a contract. This standard is effective for fiscal years, and interim periods within those years, beginning after December 15, 2017, which would be our fiscal year ending September 30, 2019. We plan to use the modified retrospective basis upon adoption. As part of our implementation process, we are evaluating a sample of contracts to identity potential impacts of the standard on our current accounting policies and disclosures. We will update our accounting policies and procedures and determine the impact from this new standard on our contracts outstanding as of October 1, 2018. While we are still evaluating the potential impact of this standard on our financial statements, we believe accounting for variable consideration, cancellations for convenience clauses and the number of performance obligations contained in each contract could have the greatest significance. The materiality of this guidance on our financial statements will be determined in large part by the contracts that are in progress as of the adoption date.

- changed (2018-05-09):
[0000080420-18-000013:note_history:5]
In November 2015, the FASB issued an amendment to the topic regarding income taxes which requires an entity to separate deferred income tax liabilities and assets into current and noncurrent amounts in the statement of financial position.  Deferred tax liabilities and assets are classified as current or noncurrent based on the classification of the related asset or liability for financial reporting.  Deferred tax liabilities and assets that are not related to an asset or liability for financial reporting are classified according to the expected reversal date of the temporary difference. To simplify the presentation of deferred income taxes, the amendments require that deferred income tax liabilities and assets be classified as noncurrent in a classified statement of financial position. We have adopted this topic prospectively in Fiscal 2018 and our statement of financial position reflects this reclassification. We have not retrospectively adjusted prior periods.
  (was, 2018-02-07, similarity 0.9918):
[0000080420-18-000007:note_history:5]
In November 2015, the FASB issued an amendment to the topic regarding income taxes which requires an entity to separate deferred income tax liabilities and assets into current and noncurrent amounts in the statement of financial position.  Deferred tax liabilities and assets are classified as current or noncurrent based on the classification of the related asset or liability for financial reporting.  Deferred tax liabilities and assets that are not related to an asset or liability for financial reporting are classified according to the expected reversal date of the temporary difference. To simplify the presentation of deferred income taxes, the amendments require that deferred income tax liabilities and assets be classified as noncurrent in a classified statement of financial position. We have adopted this topic prospectively in Fiscal 2018 and our statement of financial position at December 31, 2017 reflects this reclassification. We have not retrospectively adjusted prior periods.

- changed (2018-05-09):
[0000080420-18-000013:note_history:6]
In February 2016, the FASB issued a new topic on leases which requires lessees to recognize lease assets and lease liabilities on the balance sheet for all leases with terms longer than twelve months. Leases will be classified as either finance or operating, with classification affecting the pattern of expense recognition in the income statement. A modified retrospective transition approach is required for lessees for capital and operating leases existing at, or entered into after, the beginning of the earliest comparative period presented in the financial statements, with certain practical expedients available. The new topic is effective for fiscal years beginning after December 15, 2018, including interim periods within those fiscal years. This would be our fiscal year ending September 30, 2020. We are still evaluating the potential impact of this topic on our financial statements.
  (was, 2018-02-07, similarity 0.9926):
[0000080420-18-000007:note_history:6]
In February 2016, the FASB issued a new topic on leases which requires lessees to recognize lease assets and lease liabilities on the balance sheet for all leases with terms longer than twelve months. Leases will be classified as either finance or operating, with classification affecting the pattern of expense recognition in the income statement. A modified retrospective transition approach is required for lessees for capital and operating leases existing at, or entered into after, the beginning of the earliest comparative period presented in the financial statements, with certain practical expedients available. The new standard is effective for fiscal years beginning after December 15, 2018, including interim periods within those fiscal years. This would be our fiscal year ending September 30, 2020. We are still evaluating the potential impact of this topic on our financial statements.

- changed (2018-05-09):
[0000080420-18-000013:note_history:7]
In November 2016, the FASB issued a new topic on the statement of cash flows that changes the presentation of restricted cash and cash equivalents on the statement of cash flows. Restricted cash and restricted cash equivalents will be included with cash and cash equivalents when reconciling the beginning-of-period and end-of-period total amounts shown on the statement of cash flows. This topic is effective for fiscal years beginning after December 15, 2017, and interim periods within those fiscal years, which would be our fiscal year ending September 30, 2019. We are still evaluating this new standard, but we do not expect it to have a material impact on our consolidated financial position or results of operations.
  (was, 2018-02-07, similarity 0.8275):
[0000080420-18-000007:note_history:7]
In November 2016, the FASB issued new standards on the statement of cash flows and restricted cash that change the presentation of restricted cash and cash equivalents on the statement of cash flows. Restricted cash and restricted cash equivalents will be included with cash and cash equivalents when reconciling the beginning-of-period and end-of-period total amounts shown on the statement of cash flows. These standards are effective for public business entities for fiscal years beginning after December 15, 2017, and interim periods within those fiscal years, which would be our fiscal year ending September 30, 2019. We have no plans for early adoption. We are still evaluating these new standards, but we do not expect them to have a material impact on our consolidated financial position or results of operations.

- removed (2018-05-09):
[0000080420-18-000007:note_history:8]
In May 2014, the Financial Accounting Standards Board (FASB) issued a new standard on revenue recognition that supersedes previously issued revenue recognition guidance. This standard provides a five-step approach to be applied to all contracts with customers and requires expanded disclosures about the nature, amount, timing and uncertainty of revenue (and the related cash flows) arising from customer contracts, significant judgments and changes in judgments used in applying the revenue model and the assets recognized from costs incurred to obtain or fulfill a contract. This standard is effective for fiscal years, and interim periods within those years, beginning after December 15, 2017, which would be our fiscal year ending September 30, 2019. We plan to use the modified retrospective basis upon adoption. While we are still evaluating the potential impact of this standard on our financial statements, we believe accounting for variable consideration and the number of performance obligations contained in each contract will have the greatest significance. The materiality of this guidance on our financial statements will be determined in large part by the contracts that are in progress as of the adoption date.

- removed (2018-05-09):
[0000080420-18-000007:note_history:9]
In January 2017, the FASB issued new guidance on goodwill impairment intended to simplify the testing for goodwill impairment by the elimination of Step 2 in the determination on whether goodwill should be considered impaired. The annual and/or interim assessments are still required to be completed. This guidance is effective for fiscal years (including interim periods) beginning after December 15, 2019, which would be our fiscal year ending September 30, 2021. The adoption of this guidance is not expected to have a material impact on our consolidated financial position or results of operations.


## us-gaap:LongTermDebtTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2018-05-09):
[0000080420-18-000013:note_history:10]
|  | March 31, 2018 |  | September 30, 2017 |
| Industrial development revenue bonds | $ | 1,600 |  |  | $ | 2,000 |  |
| Less current portion | (400 | ) |  | (400 | ) |
| Total long-term debt | $ | 1,200 |  |  | $ | 1,600 |  |
  (was, 2018-02-07, similarity 0.9763):
[0000080420-18-000007:note_history:10]
|  | December 31, 2017 |  | September 30, 2017 |
| Industrial development revenue bonds | $ | 1,600 |  |  | $ | 2,000 |  |
| Less current portion | (400 | ) |  | (400 | ) |
| Total long-term debt | $ | 1,200 |  |  | $ | 1,600 |  |

- changed (2018-05-09):
[0000080420-18-000013:note_history:11]
We have a $75.0 million revolving credit facility (U.S. Revolver) to provide working capital support and letters of credit which expires on June 27, 2022. The amount available under the U.S. Revolver at March 31, 2018 was reduced by $29.0 million for our outstanding letters of credit. Currently, our U.S. Revolver can only be used for letters of credit until we meet certain financial ratios. There were no loans outstanding under the U.S. Revolver as of March 31, 2018.
  (was, 2018-02-07, similarity 0.6106):
[0000080420-18-000007:note_history:11]
We have a $75.0 million revolving credit facility (U.S. Revolver) to provide working capital support and letters of credit which expires on June 27, 2022. The amount available under the U.S. Revolver at December 31, 2017 was reduced by $27.0 million for our outstanding letters of credit. There were no loans outstanding under the U.S. Revolver as of December 31, 2017. Amounts available under the U.S. Revolver were $48.0 million at December 31, 2017.

- changed (2018-05-09):
[0000080420-18-000013:note_history:12]
Per the terms of the U.S. Revolver, we are required to maintain a cash balance in a pledged cash collateral account equal to 102% of the outstanding amount of any loans and letter of credit obligations until we meet certain financial ratios. As of March 31, 2018, the balance in the pledged account was $30.5 million. The cash collateral associated with the outstanding letters of credit that are due to expire beyond twelve months has been classified as non-current restricted cash on the balance sheet. As of March 31, 2018, there was $46.0 million available for the issuance of letters of credit under the U.S. Revolver.
  (was, 2018-02-07, similarity 0.8791):
[0000080420-18-000007:note_history:12]
Per the terms of the U.S. Revolver, we are required to maintain a cash balance in a pledged cash collateral account equal to 102% of the outstanding amount of any loans and letter of credit obligations until we meet certain financial ratios. As of December 31, 2017, the balance in the pledged account was $27.8 million. The cash collateral associated with the outstanding letters of credit that are due to expire beyond twelve months has been classified as non-current restricted cash on the balance sheet as of December 31, 2017.

- changed (2018-05-09):
[0000080420-18-000013:note_history:13]
The U.S. Revolver is collateralized by a pledge of 100% of the voting capital stock of each of our domestic subsidiaries and 65% of the voting capital stock of each non-domestic subsidiary. The U.S. Revolver provides for customary events of default and carries cross-default provisions with other existing debt agreements. If an event of default (as defined in the U.S. Revolver) occurs and is continuing, on the terms and subject to the conditions set forth in the U.S. Revolver, amounts outstanding under the U.S. Revolver may be accelerated and may become immediately due and payable. It also contains financial covenants defining various financial measures and the levels of these measures with which we must comply, as well as a “material adverse change” clause. A “material adverse change” is defined as a material change in our operations, business, properties, liabilities or condition (financial or otherwise) or a material impairment of our ability to perform our obligations under our credit agreements. As of March 31, 2018, we were in compliance with all of the financial covenants of the U.S. Revolver.
  (was, 2018-02-07, similarity 0.9941):
[0000080420-18-000007:note_history:13]
The U.S. Revolver is collateralized by a pledge of 100% of the voting capital stock of each of our domestic subsidiaries and 65% of the voting capital stock of each non-domestic subsidiary. The U.S. Revolver provides for customary events of default and carries cross-default provisions with other existing debt agreements. If an event of default (as defined in the U.S. Revolver) occurs and is continuing, on the terms and subject to the conditions set forth in the U.S. Revolver, amounts outstanding under the U.S. Revolver may be accelerated and may become immediately due and payable. It also contains financial covenants defining various financial measures and the levels of these measures with which we must comply, as well as a “material adverse change” clause. A “material adverse change” is defined as a material change in our operations, business, properties, liabilities or condition (financial or otherwise) or a material impairment of our ability to perform our obligations under our credit agreements. As of December 31, 2017, we were in compliance with all of the financial covenants of the U.S. Revolver.

- changed (2018-05-09):
[0000080420-18-000013:note_history:14]
We borrowed $8.0 million in October 2001 through a loan agreement funded with proceeds from tax-exempt industrial development revenue bonds (Bonds). These Bonds were issued by the Illinois Development Finance Authority and were used for the completion of our Northlake, Illinois facility. Pursuant to the Bond issuance, a reimbursement agreement between us and a major domestic bank required an issuance by the bank of an irrevocable direct-pay letter of credit (Bond LC), as collateral, to the Bonds’ trustee to guarantee payment of the Bonds’ principal and interest when due. The Bond LC is subject to both early termination and extension provisions customary to such agreements, as well as various covenants, for which we were in compliance at March 31, 2018. While the Bonds mature in 2021, the reimbursement agreement requires annual redemptions of $0.4 million that commenced on October 25, 2002. A sinking fund is used for the redemption of the Bonds. The Bonds bear interest at a floating rate determined weekly by the Bonds’ remarketing agent, which was the underwriter for the Bonds and is an affiliate of the bank. This interest rate was 1.76% as of March 31, 2018.
  (was, 2018-02-07, similarity 0.9887):
[0000080420-18-000007:note_history:14]
We borrowed $8.0 million in October 2001 through a loan agreement funded with proceeds from tax-exempt industrial development revenue bonds (Bonds). These Bonds were issued by the Illinois Development Finance Authority and were used for the completion of our Northlake, Illinois facility. Pursuant to the Bond issuance, a reimbursement agreement between us and a major domestic bank required an issuance by the bank of an irrevocable direct-pay letter of credit (Bond LC), as collateral, to the Bonds’ trustee to guarantee payment of the Bonds’ principal and interest when due. The Bond LC is subject to both early termination and extension provisions customary to such agreements, as well as various covenants, for which we were in compliance at December 31, 2017. While the Bonds mature in 2021, the reimbursement agreement requires annual redemptions of $0.4 million that commenced on October 25, 2002. A sinking fund is used for the redemption of the Bonds. The Bonds bear interest at a floating rate determined weekly by the Bonds’ remarketing agent, which was the underwriter for the Bonds and is an affiliate of the bank. This interest rate was 1.90% as of December 31, 2017.


## us-gaap:ScheduleOfDebtInstrumentsTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2018-05-09):
[0000080420-18-000013:note_history:15]
|  | March 31, 2018 |  | September 30, 2017 |
| Industrial development revenue bonds | $ | 1,600 |  |  | $ | 2,000 |  |
| Less current portion | (400 | ) |  | (400 | ) |
| Total long-term debt | $ | 1,200 |  |  | $ | 1,600 |  |
  (was, 2018-02-07, similarity 0.9763):
[0000080420-18-000007:note_history:15]
|  | December 31, 2017 |  | September 30, 2017 |
| Industrial development revenue bonds | $ | 1,600 |  |  | $ | 2,000 |  |
| Less current portion | (400 | ) |  | (400 | ) |
| Total long-term debt | $ | 1,200 |  |  | $ | 1,600 |  |


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: tag_name, score: 1.0

- changed (2018-05-09):
[0000080420-18-000013:note_history:16]
On May 7, 2018, our Board of Directors declared a quarterly cash dividend on our common stock in the amount of $0.26 per share. The dividend is payable on June 20, 2018 to shareholders of record at the close of business on May 23, 2018.
  (was, 2018-02-07, similarity 0.6517):
[0000080420-18-000007:note_history:16]
On February 5, 2018, our Board of Directors declared a quarterly cash dividend on our common stock in the amount of $0.26 per share. The dividend is payable on March 21, 2018 to shareholders of record at the close of business on February 21, 2018.
