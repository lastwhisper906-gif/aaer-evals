# POWL MD&A — 0000080420-23-000051


## mdna

[0000080420-23-000051:mdna:1]
Item 7. Management’s Discussion and Analysis of Financial Condition and Results of Operations

[0000080420-23-000051:mdna:2]
Overview

[0000080420-23-000051:mdna:3]
We develop, design, manufacture and service custom-engineered equipment and systems that (1) distribute, control and monitor the flow of electrical energy and (2) provide protection to motors, transformers and other electrically powered equipment. We are headquartered in Houston, Texas and serve the oil and gas and petrochemical markets, which include onshore and offshore production, LNG facilities and terminals, pipelines, refineries and petrochemical plants. Additional markets include electric utility, light rail traction power as well as mining and metals, pulp and paper, data centers and other municipal, commercial and industrial markets. Revenues and costs are primarily related to custom engineered-to-order equipment and systems and are accounted for under percentage-of-completion accounting, which precludes us from providing detailed price and volume information. Our backlog includes various projects that typically take a number of months to produce.

[0000080420-23-000051:mdna:4]
The markets in which we participate are capital-intensive and cyclical in nature. Cyclicality is predominantly driven by customer demand, global economic and geopolitical conditions and anticipated environmental, safety or regulatory changes that affect the manner in which our customers proceed with capital investments. Our customers analyze various factors, including the demand and price for oil, gas and electrical energy, the overall economic and financial environment, governmental budgets, regulatory actions and environmental concerns. These factors influence the release of new capital projects by our customers, which are traditionally awarded in competitive bid situations. Scheduling of projects is matched to customer requirements, and projects typically take a number of months to produce. Schedules may change during the course of any particular project, and our operating results can, therefore, be impacted by factors outside of our control.

[0000080420-23-000051:mdna:5]
Within the industrial sector, specifically oil, gas and petrochemical, the demand for our electrical distribution solutions is very cyclical and closely correlated to the level of capital expenditures of our end-user customers as well as prevailing global economic conditions. The North American market is responding to increased international demand for LNG and gas-to-chemical processes utilizing low-cost gas feedstocks. As a result, the business has been awarded a number of large LNG and petrochemical contracts that have had a positive impact on our backlog.

[0000080420-23-000051:mdna:6]
One element of our strategic focus is to strengthen our project portfolio beyond our core oil, gas and petrochemical end market sectors. Diversification efforts outside of our core oil, gas and petrochemical end markets have resulted in an increase in backlog across the utility and commercial and other industrial sectors. Over the past year, these efforts have contributed to a strong backlog of projects coming into Fiscal 2023 and near record levels going into Fiscal 2024.

[0000080420-23-000051:mdna:7]
Various factors resulting in global economic uncertainty negatively impacted our results over the previous two years. Uncertainty and demand disruptions resulted in considerable volatility across commodity markets. We experienced supply chain disruptions driven predominantly by availability and cost volatility across our raw materials, components and labor force. All of these factors contributed to the lower margins realized in Fiscal 2022 relative to prior oil and gas cycles. Commodity prices have stabilized in Fiscal 2023; however, we continue to experience supply chain delays for specific engineered components and continue to work with our suppliers in order to meet our customer commitments. Additionally, we have adjusted our product pricing, delivery schedules and bid validity dates with our customers in response to the increased cost environment and supply chain delays, and as a result our gross margins have been improved in Fiscal 2023.

[0000080420-23-000051:mdna:8]
Results of Operations

[0000080420-23-000051:mdna:9]
Twelve Months Ended September 30, 2023 Compared to Twelve Months Ended September 30, 2022

[0000080420-23-000051:mdna:10]
Revenue and Gross Profit

[0000080420-23-000051:mdna:11]
Revenues increased by 31%, or $166.7 million, to $699.3 million in Fiscal 2023, primarily driven by the increase in project backlog resulting from a recovery of our core oil, gas and petrochemical markets. Domestic revenues increased by 38%, or $153.0 million, to $557.9 million in Fiscal 2023. International revenues increased by 11%, or $13.8 million, to $141.4 million. Our international revenues include both revenues generated from our international facilities as well as revenues from export projects generated at our domestic facilities.

[0000080420-23-000051:mdna:12]
Revenue from our core oil and gas markets (excluding petrochemical) increased by 27%, or $57.9 million, to $273.1 million in Fiscal 2023, and petrochemical revenue increased by 42%, or $27.6 million, to $94.2 million in Fiscal 2023. Revenue from our utility end markets increased by 29%, or $36.0 million, to $158.4 million in Fiscal 2023. Commercial and other industrial market revenue increased by 84%, or $47.5 million, to $104.0 million driven by an increase in traditionally non-core markets such as data centers, university projects and other miscellaneous applications. Revenue from all other markets combined increased by $14.5 million to $41.5 million in Fiscal 2023. These increases in revenue were driven by improved market conditions and our strategic effort to diversify our business. Revenue from our traction market decreased by 37%, or $16.8 million, to $28.1 million in Fiscal 2023.

[0000080420-23-000051:mdna:13]
Gross profit increased by 74%, or $62.5 million, to $147.6 million in Fiscal 2023. Gross profit as a percentage of revenues increased to 21% in Fiscal 2023 as compared to 16% in the prior year. This increase in gross profit was favorably impacted by the higher volume levels across the manufacturing facilities driving key factory efficiencies, strong project execution as well as, effectively managing product pricing that corresponds to current cost levels. Additionally, project cancellations contributed $4.3 million to gross profit in Fiscal 2023.

[0000080420-23-000051:mdna:14]
Selling, General and Administrative Expenses

[0000080420-23-000051:mdna:15]
Selling, general and administrative expenses increased by 11%, or $8.0 million, to $78.8 million in Fiscal 2023, primarily due to increased variable performance-based compensation. Selling, general and administrative expenses, as a percentage of revenues, decreased to 11% in Fiscal 2023, compared to 13% in Fiscal 2022, based upon leveraging our cost structure on the increase in revenues.

[0000080420-23-000051:mdna:16]
Other Income

[0000080420-23-000051:mdna:17]
During Fiscal 2022 we recorded other income of $2.3 million related to a gain on the sale of a small, non-core, industrial valve repair and servicing business within our Canadian operations as well as the sale of an excess parcel of land in the U.S. We did not record other income in Fiscal 2023.

[0000080420-23-000051:mdna:18]
Income Tax Provision (Benefit)

[0000080420-23-000051:mdna:19]
We recorded an income tax provision of $14.4 million in Fiscal 2023, resulting in an effective tax rate of 21%, compared to an income tax benefit of $3.9 million in Fiscal 2022 at an effective tax rate of negative 40%. In Fiscal 2023, the effective tax rate approximated the U.S. federal statutory rate. The favorable impacts of the estimated Research and Development Tax Credit (R&D Tax Credit) and the release of the valuation allowance previously recorded against the U.K. net deferred tax assets in the amount of $1.9 million were offset by state income tax expense, certain non-deductible items and the tax impact of U.S. global intangible income.

[0000080420-23-000051:mdna:20]
In Fiscal 2022, the tax benefit primarily resulted from the release of the valuation allowance previously recorded against the Canadian net deferred tax assets in the amount of $5.9 million and the estimated R&D Tax Credit. The tax benefit was partially offset by certain non-deductible items, the tax expense related to the gain on the disposition of a small, non-core division of our Canadian operations and the tax impact of U.S. global intangible income.

[0000080420-23-000051:mdna:21]
Net Income

[0000080420-23-000051:mdna:22]
In Fiscal 2023, we recorded net income of $54.5 million, or $4.50 per diluted share, compared to net income of $13.7 million, or $1.15 per diluted share in Fiscal 2022. This increase in net income is primarily due to the increase in bookings which led to an increase in revenues coupled with increased project margins.

[0000080420-23-000051:mdna:23]
Backlog

[0000080420-23-000051:mdna:24]
The order backlog at September 30, 2023 was $1.3 billion, a 118% increase from $592.2 million at September 30, 2022. This increase in backlog is driven primarily from our oil and gas markets, including LNG, petrochemical, utility and commercial and other industrial markets. Bookings, net of cancellations and scope reductions, increased by 94% in Fiscal 2023 to $1.4 billion, compared to $718.6 million in Fiscal 2022, primarily driven by continued strength from our core oil, gas and petrochemical markets, including several large LNG and petrochemical projects.

[0000080420-23-000051:mdna:25]
Outlook

[0000080420-23-000051:mdna:26]
Recently we have seen a cyclical recovery across our core oil, gas and petrochemical markets combined with increased global demand for cleaner-burning fuels as well as related processes utilizing lower cost gas feedstocks. Our order activity in most of our core markets has been strong and includes multiple large LNG and petrochemical projects. This elevated project activity has increased our backlog to approximately $1.3 billion. Diversification efforts outside of our core oil, gas and petrochemical end markets have also been a positive catalyst, helping to drive the increase in backlog. This strong backlog of projects, which incorporates pricing and productivity initiatives in response to persistent inflationary pressures, should continue to support an increasing level of revenue into Fiscal 2024. Approximately $648 million of the backlog is expected to be recognized as revenue within the next twelve months. We do not anticipate our backlog will continue to grow at the same pace as we have recognized in the last twelve months, which included several large LNG and petrochemical projects booked throughout Fiscal 2023.

[0000080420-23-000051:mdna:27]
Our operating results are impacted by several factors such as the timing of new order awards, project backlog, changes in project cost estimates, customer approval of final engineering specifications and delays in customer construction schedules, all of which contribute to short-term earnings variability and the timing of project execution. Our operating results also have been, and may continue to be, impacted by the timing and resolution of change orders and the resolution of potential contract claims and liquidated damages, all of which could improve or deteriorate gross margins during the period in which these items are resolved with our customers. Disruptions in the global supply chain have, in the past, negatively impacted our business and operating results due to the limited availability resulting in uncertainty in the timing of the receipt of key component parts and commodities. We continue to remain focused on the variables that impact our markets as well as cost management, labor availability and supply chain challenges.

[0000080420-23-000051:mdna:28]
Liquidity and Capital Resources

[0000080420-23-000051:mdna:29]
As of September 30, 2023, current assets exceeded current liabilities by 1.6 times.

[0000080420-23-000051:mdna:30]
Cash, cash equivalents and short-term investments increased to $279.0 million at September 30, 2023, compared to $116.5 million at September 30, 2022. The increase in cash, cash equivalents and short-term investments was primarily driven by the increased project volume and favorable timing of contract billing milestones on some of our large projects. We typically allocate a significant percentage of the progress billing to the early stages of the contract. These favorable billing milestones along with our increase in project backlog are the primary drivers for the increase at September 30, 2023. We believe that our strong working capital position, available borrowings under our credit facility and available cash and cash equivalents should be sufficient to support our future operating activities, capital improvements and research and development initiatives for the foreseeable future.

[0000080420-23-000051:mdna:31]
On March 31, 2023, we entered into a second amendment (the Second Amendment) to our credit agreement with Bank of America, N.A. (as amended, the U.S. Revolver). The Second Amendment increased the revolving credit facility, which is available for both borrowings and letters of credit from $75.0 million to $125.0 million. As amended by the Second Amendment, the U.S. Revolver states the lesser of $50 million or 50% of available cash may be deducted from the amount of letters of credit outstanding (not to be less than zero) when calculating the consolidated funded indebtedness, which is a component of the consolidated net leverage ratio. We have the option to cash collateralize all or a portion of the letters of credit outstanding, which would favorably impact the consolidated funded indebtedness calculation and the consolidated net leverage ratio.

[0000080420-23-000051:mdna:32]
As of September 30, 2023, there were no amounts borrowed under the U.S. Revolver, and letters of credit outstanding were $89.1 million. There was $35.9 million available for the issuance of letters of credit and borrowings under the U.S. Revolver as of September 30, 2023. We are required to maintain certain financial covenants, the most significant of which are a

[0000080420-23-000051:mdna:33]
consolidated net leverage ratio of less than 3.0 to 1.0 and a consolidated interest coverage ratio of greater than 3.0 to 1.0. Our most restrictive covenant, the consolidated net leverage ratio, is the ratio of earnings before interest, taxes, depreciation, amortization and stock-based compensation (EBITDAS) to funded indebtedness, which includes letters of credit. An increase in indebtedness or a decrease in EBITDAS could restrict our ability to issue letters of credit or borrow under the U.S. Revolver. For further information regarding our debt, see Notes G and H of Notes to Consolidated Financial Statements.

[0000080420-23-000051:mdna:34]
On October 4, 2023, we entered into a third amendment to the U.S. Revolver (the Third Amendment) with Bank of America, N.A., and Texas Capital Bank has agreed to join as an additional lender under the U.S. Revolver. The Third Amendment increased the amount of the revolving line of credit from $125.0 million to $150.0 million and extended the expiry date to October 4, 2028. For further information regarding the Third Amendment, see Note G to Consolidated Financial Statements.

[0000080420-23-000051:mdna:35]
Approximately $57.4 million of our cash, cash equivalents and short-term investments at September 30, 2023 was held outside of the U.S. for our international operations. It is our intention to indefinitely reinvest all current and future foreign earnings internationally in order to ensure sufficient working capital to support our international operations. In the event that we elect to repatriate some or all of the foreign earnings that were previously deemed to be indefinitely reinvested outside the U.S., we may incur additional tax expense upon such repatriation under current tax laws.

[0000080420-23-000051:mdna:36]
Operating Activities

[0000080420-23-000051:mdna:37]
Operating activities provided net cash of $182.6 million during Fiscal 2023 and used net cash of $3.6 million during Fiscal 2022. Cash flow from operations is primarily influenced by the timing of milestone payments from our customers, project volume and the associated working capital requirements, as well as payment terms with our suppliers. This increase in operating cash flow was primarily due to the increase in project volume and the favorable timing of contract billing milestones, although partially offset by the increases in accounts receivable and inventory. Inventory has increased to support our increased backlog and stock levels to help mitigate global supply chain risks.

[0000080420-23-000051:mdna:38]
Investing Activities

[0000080420-23-000051:mdna:39]
Investing activities used $26.6 million of cash during Fiscal 2023 compared to $6.5 million of cash provided in Fiscal 2022. The increase in cash used in investing activities during Fiscal 2023 was primarily due to the timing of cash used to purchase short-term investments.

[0000080420-23-000051:mdna:40]
Financing Activities

[0000080420-23-000051:mdna:41]
Net cash used in financing activities was $13.1 million during Fiscal 2023 compared to $13.3 million during Fiscal 2022, which primarily consisted of approximately $12.4 million and $12.2 million of dividends paid in the respective years.

[0000080420-23-000051:mdna:42]
Other Commercial Commitments

[0000080420-23-000051:mdna:43]
We are contingently liable for letters of credit and bank guarantees totaling $96.7 million as of September 30, 2023, with the following potential cash outflows in the event that we are unable to perform under our contracts (in thousands):

[0000080420-23-000051:mdna:44]
| Payments Due by Period: | Letters ofCredit/ Bank Guarantees |
| Less than 1 year | $ | 48,459 |  |
| 1 to 3 years | 33,711 |  |
| More than 3 years | 14,511 |  |
| Total long-term commercial obligations | $ | 96,681 |  |

[0000080420-23-000051:mdna:45]
We also had surety bonds totaling $393.4 million that were outstanding at September 30, 2023. Surety bonds are primarily used to guarantee our contract performance to our customers.

[0000080420-23-000051:mdna:46]
Off-Balance Sheet Arrangements

[0000080420-23-000051:mdna:47]
We had no significant off-balance sheet arrangements during the periods presented.

[0000080420-23-000051:mdna:48]
Effects of Inflation

[0000080420-23-000051:mdna:49]
We are subject to inflation, which can cause increases in our costs of labor, indirect expenses and raw materials, primarily copper, aluminum and steel. Fixed-price contracts can limit our ability to pass these increases to our customers, thus negatively impacting our earnings and operations in future quarters and years.

[0000080420-23-000051:mdna:50]
Critical Accounting Estimates

[0000080420-23-000051:mdna:51]
The preparation of consolidated financial statements in conformity with accounting principles generally accepted in the United States (U.S. GAAP) requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities, disclosures of contingent assets and liabilities known to exist at the date of the consolidated financial statements and the reported amounts of revenues and expenses during the reporting period. We evaluate our estimates on an ongoing basis, based on historical experience and on various other assumptions that are believed to be reasonable under the circumstances. There can be no assurance that actual results will not differ from those estimates.

[0000080420-23-000051:mdna:52]
We believe the following accounting estimates to be critical in the preparation and reporting of our consolidated financial statements.

[0000080420-23-000051:mdna:53]
Revenue Recognition

[0000080420-23-000051:mdna:54]
Our revenues are primarily generated from the manufacturing of custom-engineered products and systems under long-term fixed-price contracts under which we agree to manufacture various products such as traditional and arc-resistant distribution switchgear and control gear, medium-voltage circuit breakers, monitoring and control communications systems, motor control centers, switches and bus duct systems. These products may be sold separately as an engineered solution, but are typically integrated into custom-built enclosures which we also build. These enclosures are referred to as power control room substations (PCRs®), custom-engineered modules or electrical houses (E-Houses). Some contracts may also include the installation and commissioning of these enclosures.

[0000080420-23-000051:mdna:55]
Revenue from these contracts is generally recognized over time utilizing the cost-to-cost method. Under the cost-to-cost method, the extent of progress towards completion is measured based on the ratio of costs incurred to date to the total estimated costs at completion of the performance obligation. We believe that this method is the most accurate representation of our performance because it directly measures the value of the services transferred to the customer over time as we incur costs on our contracts. Contract costs include all direct materials, labor and indirect costs related to contract performance, which may include indirect labor, supplies, tools, repairs and depreciation costs.

[0000080420-23-000051:mdna:56]
Performance Obligations

[0000080420-23-000051:mdna:57]
A performance obligation is a promise in a contract or with a customer to transfer a distinct good or service. A contract’s transaction price is allocated to each distinct performance obligation and recognized as revenue as the performance obligations are satisfied. To determine the proper revenue recognition for contracts, we evaluate whether a contract should be accounted for as more than one performance obligation or, less commonly, whether two or more contracts should be combined and accounted for as one performance obligation. This evaluation of performance obligations requires significant judgment. The majority of our contracts have a single performance obligation where multiple engineered products and services are combined into a single custom-engineered solution. Our contracts include a standard one-year assurance warranty. Occasionally, we provide service-type warranties that will extend the warranty period. These extended warranties qualify as separate performance obligations, and revenue is deferred and recognized over the warranty period. If we determine during the evaluation of the contract that there are multiple performance obligations, we allocate the transaction price to each performance obligation using our best estimate of the standalone selling price of each distinct good or service in the contract.

[0000080420-23-000051:mdna:58]
Contract Estimates

[0000080420-23-000051:mdna:59]
Actual revenues and project costs may vary from previous estimates due to changes in a variety of factors. The cost estimation process is based on the professional knowledge and experience of our engineers, project managers and financial professionals. Factors that are considered in estimating the work to be completed and ultimate contract recovery include the availability and productivity of labor, the nature and complexity of the work to be performed, the availability of materials, and the effect of any delays on our project performance. We periodically review our job performance, job conditions, estimated profitability and final contract settlements, including our estimate of total costs and make revisions to costs and income in the period in which the revisions are probable and reasonably estimable. We bear the risk of cost overruns in most of our contracts, which may result in reduced profits. Whenever revisions of estimated contract costs and contract values indicate that the contract costs will exceed

[0000080420-23-000051:mdna:60]
estimated revenues, thus creating a loss, a provision for the total estimated loss is recorded in that period. See Note E of Notes to Consolidated Financial Statements for disclosures related to changes in contract estimates.

[0000080420-23-000051:mdna:61]
Variable Consideration

[0000080420-23-000051:mdna:62]
It is common for our long-term contracts to contain variable consideration that can either increase or decrease the transaction price. Due to the nature of our contracts, estimating total cost and revenue can be complex and subject to variability due to change orders, back charges, spare parts, early completion bonuses, customer allowances and liquidated damages. We estimate the amount of variable consideration based on the expected value method, which is the sum of probability-weighted amounts, or the most likely amount method, which uses various factors including experience with similar transactions and assessment of our anticipated performance. Variable consideration is included in the transaction price if legally enforceable and to the extent it is probable that a significant reversal of cumulative revenue recognized will not occur once the uncertainty associated with the variable consideration is resolved.

[0000080420-23-000051:mdna:63]
Contract Modifications

[0000080420-23-000051:mdna:64]
Contracts may be modified for changes in contract specifications and requirements. We consider contract modifications to exist when the modification either creates new or changes the enforceable rights and obligations under the contract. Most of our contract modifications are for goods and services that are not distinct from the existing performance obligation. Contract modifications result in a cumulative catch-up adjustment to revenue based on our measure of progress for the performance obligation.

[0000080420-23-000051:mdna:65]
Impairment of Long-Lived Assets

[0000080420-23-000051:mdna:66]
We review long-lived assets for impairment whenever events or changes in circumstances indicate that the carrying value may not be realizable. If an evaluation is required, the estimated future undiscounted cash flows associated with the asset are compared to the asset’s carrying amount to determine if recording an impairment of such asset is necessary. This requires us to make long-term forecasts of the future revenues and costs related to the assets subject to review. Forecasts require assumptions about demand for our products and future market conditions. Estimating future cash flows requires significant judgment, and our projections may vary from cash flows eventually realized. Future events and unanticipated changes to assumptions could require a provision for impairment in a future period. The effect of any impairment would be reflected in operating income in the Consolidated Statements of Operations. In addition, we estimate the useful lives of our long-lived assets and other intangibles, and periodically review these estimates to determine whether these lives are appropriate.

[0000080420-23-000051:mdna:67]
Accruals for Contingent Liabilities

[0000080420-23-000051:mdna:68]
From time to time, contingencies such as insurance-related claims, liquidated damages and legal claims arise in the normal course of business. Pursuant to applicable accounting standards, we must evaluate such contingencies to subjectively determine the likelihood that an asset has been impaired, or a liability has been incurred at the date of the financial statements, as well as evaluate whether the amount of the loss can be reasonably estimated. If the likelihood is determined to be probable, and it can be reasonably estimated, the estimated loss is recorded. The amounts we record for contingent liabilities require judgments regarding the amount of expenses that will ultimately be incurred. We use past experience and history, as well as the specific circumstances surrounding each contingent liability, including estimated legal costs, in evaluating the amount of liability that should be recorded. Actual results could differ from our estimates.

[0000080420-23-000051:mdna:69]
Warranty Costs

[0000080420-23-000051:mdna:70]
Estimated costs of warranties are accrued based on historical warranty claim costs in relation to current revenues. In addition, specific provisions are made when product failures are projected outside historical experience. Our standard terms and conditions of sale include a warranty for parts and service for one year. Occasionally, we provide service-type warranties that will extend the warranty period. Actual results could differ from our estimate.

[0000080420-23-000051:mdna:71]
Projects may require, on occasion, warranty terms that are longer than our standard terms due to the nature of the project. Extended warranty terms may be negotiated and included in our contracts. The allocated revenue associated with the extended warranty is deferred and recorded as a contract liability and recognized as revenue over the extended warranty period.

[0000080420-23-000051:mdna:72]
Accounting for Income Taxes

[0000080420-23-000051:mdna:73]
We account for income taxes under the asset and liability method, based on the income tax laws and rates in the countries in which operations are conducted, and income is earned. This approach requires the recognition of deferred tax assets and liabilities for the expected future tax consequences of temporary differences between the carrying amounts and the tax basis of assets and liabilities. Developing our provision for income taxes requires significant judgment and expertise in federal, international and state income tax laws, regulations and strategies, including the determination of deferred tax assets and liabilities and, if necessary, any valuation allowances that may be required for deferred tax assets. In assessing the extent to which net deferred tax assets may be realized, we consider whether it is more likely than not that some portion or all of the net deferred tax assets may not be realized. The ultimate realization of net deferred tax assets is dependent on the generation of future taxable income during the periods in which those temporary differences become deductible. Estimates may change as new events occur, estimates of future taxable income during the carryforward period are reduced or increased, additional information becomes available, or operating environments change, which may result in a full or partial reversal of the valuation allowance. We will continue to assess the adequacy of the valuation allowance on a quarterly basis. Our judgments and tax strategies are subject to audit by various taxing authorities.

[0000080420-23-000051:mdna:74]
The objectives of accounting for income taxes are to recognize the amount of taxes payable or refundable for the current year and deferred tax liabilities and assets for the future tax consequences of events that have been recognized in an entity’s financial statements or tax returns. We recognize the tax benefit from an uncertain tax position only if it is more likely than not that the tax position will be sustained on examination by the taxing authorities, based on the technical merits of the position. The tax benefits recognized in the financial statements from such a position should be measured based on the largest benefit that has a greater than 50% likelihood of being realized upon ultimate settlement. Accounting literature also provides guidance on derecognition of income tax assets and liabilities, classification of current and deferred income tax assets and liabilities, accounting for interest and penalties associated with tax positions, and income tax disclosures. Judgment is required in assessing the future tax consequences of events that have been recognized in our financial statements or tax returns. Variations in the actual outcome of these future tax consequences could materially impact our financial position and results of operations.

[0000080420-23-000051:mdna:75]
See Note I of Notes to Consolidated Financial Statements for disclosures related to the valuation allowance recorded in relation to deferred taxes.
