# POWL 8-K — 0000080420-23-000047 filed 2023-12-05

## item codes, every 8-K on or before 2023-12-06

- 2023-12-05 0000080420-23-000047 — 2.02, 9.01
- 2023-11-03 0000080420-23-000044 — 8.01, 9.01
- 2023-10-11 0000080420-23-000041 — 1.01, 2.03
- 2023-08-01 0000080420-23-000036 — 2.02, 8.01, 9.01
- 2023-05-19 0001193125-23-149334 — 5.07 — amendment of 0000080420-23-000011
- 2023-05-03 0000080420-23-000025 — 2.02, 8.01, 9.01
- 2023-04-06 0000080420-23-000020 — 1.01, 2.03, 9.01
- 2023-04-05 0000080420-23-000018 — 5.02
- 2023-02-16 0000080420-23-000011 — 5.02, 5.07, 9.01
- 2023-01-31 0000080420-23-000004 — 2.02, 8.01
- 2022-12-05 0000080420-22-000034 — 2.02, 9.01
- 2022-08-02 0000080420-22-000030 — 2.02, 8.01, 9.01
- 2022-05-13 0000080420-22-000024 — 5.02, 9.01
- 2022-05-03 0000080420-22-000016 — 2.02, 9.01
- 2022-05-03 0000080420-22-000015 — 8.01, 9.01
- 2022-02-17 0000080420-22-000010 — 5.07
- 2022-02-08 0000080420-22-000005 — 2.02, 9.01
- 2022-02-01 0000080420-22-000002 — 8.01, 9.01
- 2021-12-07 0000080420-21-000043 — 2.02, 9.01
- 2021-08-03 0000080420-21-000036 — 2.02, 8.01, 9.01
- 2021-05-04 0000080420-21-000026 — 2.02, 8.01, 9.01
- 2021-03-16 0001193125-21-082878 — 1.01, 2.03, 9.01
- 2021-03-05 0000080420-21-000021 — 5.02, 8.01, 9.01
- 2021-02-26 0000080420-21-000018 — 5.03
- 2021-02-18 0000080420-21-000016 — 5.07
- 2021-02-02 0000080420-21-000010 — 2.02, 8.01, 9.01
- 2020-12-08 0000080420-20-000032 — 2.02, 9.01
- 2020-11-12 0000080420-20-000030 — 8.01, 9.01
- 2020-08-04 0000080420-20-000024 — 2.02, 8.01, 9.01
- 2020-05-05 0000080420-20-000017 — 2.02, 8.01, 9.01
- 2020-02-21 0000080420-20-000008 — 5.07
- 2020-02-04 0000080420-20-000003 — 2.02, 8.01, 9.01
- 2019-12-04 0001193125-19-306243 — 2.02, 9.01
- 2019-11-08 0000080420-19-000032 — 8.01, 9.01
- 2019-10-03 0000080420-19-000030 — 1.01, 2.03
- 2019-09-24 0000080420-19-000028 — 8.01, 9.01
- 2019-08-06 0000080420-19-000022 — 2.02, 8.01, 9.01
- 2019-05-08 0000080420-19-000017 — 5.02, 9.01
- 2019-05-07 0000080420-19-000011 — 2.02, 8.01, 9.01
- 2019-02-22 0001193125-19-048366 — 5.07
- 2019-02-05 0000080420-19-000003 — 2.02, 8.01
- 2018-12-21 0000080420-18-000038 — 5.02, 9.01
- 2018-12-12 0000080420-18-000031 — 2.02
- 2018-11-05 0000080420-18-000029 — 8.01, 9.01
- 2018-11-01 0000080420-18-000027 — 5.02, 8.01, 9.01
- 2018-10-01 0000080420-18-000024 — 5.02
- 2018-08-07 0000080420-18-000020 — 2.02, 8.01
- 2018-05-15 0000080420-18-000016 — 5.02, 8.01
- 2018-05-09 0000080420-18-000011 — 2.02, 8.01
- 2018-02-22 0000080420-18-000009 — 5.07
- 2018-02-06 0000080420-18-000003 — 2.02, 8.01
- 2017-12-27 0001193125-17-379928 — 5.02
- 2017-12-05 0000080420-17-000028 — 2.02, 9.01
- 2017-11-08 0000080420-17-000024 — 8.01, 9.01
- 2017-11-03 0000080420-17-000022 — 5.02
- 2017-08-09 0000080420-17-000017 — 2.02, 8.01
- 2017-06-30 0000080420-17-000014 — 1.01, 9.01
- 2017-05-03 0000080420-17-000006 — 2.02, 8.01, 9.01
- 2017-02-23 0000080420-17-000004 — 5.07
- 2017-02-08 0001628280-17-000965 — 2.02 — amendment of 0001628280-17-000949
- 2017-02-07 0001628280-17-000949 — 2.01, 8.01, 9.01
- 2016-12-07 0001193125-16-787354 — 2.02, 9.01
- 2016-11-01 0001193125-16-755475 — 8.01, 9.01
- 2016-09-30 0001193125-16-726999 — 5.02, 8.01, 9.01
- 2016-08-03 0001193125-16-669308 — 2.02, 8.01, 9.01
- 2016-05-04 0001193125-16-576528 — 2.02, 8.01, 9.01
- 2016-02-25 0001193125-16-477896 — 5.07
- 2016-02-03 0001193125-16-449052 — 2.02, 8.01, 9.01
- 2015-12-31 0001193125-15-418363 — 5.02, 7.01, 9.01
- 2015-12-02 0001193125-15-393109 — 2.02, 9.01
- 2015-11-05 0001193125-15-368085 — 8.01, 9.01
- 2015-09-25 0001193125-15-329031 — 5.02
- 2015-08-05 0001193125-15-277912 — 2.02, 8.01, 9.01
- 2015-05-06 0001193125-15-174291 — 2.02, 8.01, 9.01
- 2015-03-06 0001193125-15-081070 — 5.02
- 2015-03-02 0001193125-15-072946 — 5.07
- 2015-02-03 0001193125-15-031772 — 2.02, 8.01, 9.01
- 2014-12-18 0001193125-14-446513 — 8.01, 9.01
- 2014-12-03 0001193125-14-431745 — 2.02, 9.01
- 2014-11-05 0001193125-14-397955 — 8.01, 9.01
- 2014-09-26 0001193125-14-353741 — 7.01, 9.01
- 2014-08-05 0001193125-14-296001 — 2.02, 8.01, 9.01
- 2014-05-07 0001193125-14-187496 — 2.02, 8.01, 9.01
- 2014-03-03 0001193125-14-079843 — 5.02, 5.07
- 2014-02-05 0001193125-14-036633 — 2.02, 8.01, 9.01
- 2014-01-17 0001193125-14-014351 — 1.01, 8.01, 9.01
- 2014-01-06 0001193125-14-002795 — 1.01, 2.03
- 2013-12-06 0001564590-13-001411 — 2.02, 9.01
- 2013-12-05 0001564590-13-001406 — 5.02, 8.01, 9.01
- 2013-11-07 0001193125-13-432950 — 8.01, 9.01
- 2013-08-07 0001193125-13-324337 — 2.02, 9.01
- 2013-05-08 0001193125-13-206800 — 2.02, 9.01
- 2013-02-22 0001193125-13-070971 — 5.02, 5.07
- 2013-02-06 0001193125-13-040556 — 2.02, 9.01
- 2012-12-18 0001193125-12-506417 — 5.02, 9.01
- 2012-12-05 0001193125-12-491749 — 2.02, 9.01
- 2012-10-12 0001193125-12-421889 — 3.03, 5.02, 5.03, 9.01
- 2012-08-09 0001193125-12-344617 — 5.02, 8.01, 9.01
- 2012-08-08 0001193125-12-343630 — 2.02, 9.01
- 2012-05-09 0001193125-12-221356 — 2.02, 9.01
- 2012-02-08 0001193125-12-046560 — 2.02, 9.01
- 2011-12-08 0001193125-11-334810 — 2.02, 9.01
- 2011-11-08 0000950123-11-096524 — 2.02, 2.06, 4.02, 9.01
- 2011-10-14 0000950123-11-090124 — 5.02
- 2011-10-06 0000950123-11-088969 — 5.02
- 2011-09-19 0000950123-11-085224 — 5.02, 9.01
- 2011-09-15 0000950123-11-084806 — 5.02, 9.01
- 2011-08-04 0000950123-11-072788 — 2.02, 9.01
- 2011-07-22 0000950123-11-067402 — 5.07
- 2011-05-24 0000950123-11-053550 — 1.01, 2.03, 9.01
- 2011-05-04 0000950123-11-044561 — 2.02, 9.01
- 2011-02-02 0000950123-11-008188 — 2.02, 9.01
- 2010-12-08 0000950123-10-111987 — 2.02, 9.01
- 2010-08-05 0000950123-10-073114 — 2.02, 9.01
- 2010-05-18 0000950123-10-050900 — 5.02
- 2010-05-05 0000950123-10-044499 — 2.02, 9.01
- 2010-02-03 0000950123-10-008278 — 2.02, 9.01
- 2009-12-21 0000950123-09-072269 — 1.01, 2.01, 2.03, 8.01, 9.01
- 2009-12-09 0000950123-09-069525 — 2.02, 9.01
- 2009-10-27 0000950123-09-053501 — 1.01, 8.01, 9.01
- 2009-08-04 0000950123-09-029476 — 2.02, 9.01
- 2009-05-06 0000950129-09-001498 — 2.02, 9.01
- 2009-03-05 0000950129-09-000749 — 1.01, 9.01
- 2009-02-10 0000950129-09-000349 — 2.02, 9.01
- 2008-12-10 0000950134-08-021934 — 2.02, 9.01
- 2008-08-06 0000950129-08-004267 — 2.02, 9.01
- 2008-07-24 0000950129-08-004063 — 1.01, 5.02, 8.01, 9.01
- 2008-06-16 0000950129-08-003500 — 9.01 — amendment of 0000950134-06-015374
- 2008-06-05 0000950129-08-003378 — 5.02, 9.01
- 2008-05-08 0000950129-08-002843 — 2.02, 9.01
- 2008-02-06 0000950129-08-000533 — 2.02, 9.01
- 2007-12-19 0000950129-07-006277 — 1.01, 2.03, 9.01
- 2007-12-06 0000950129-07-006003 — 2.02, 9.01
- 2007-08-21 0000950129-07-004181 — 2.02, 9.01
- 2007-05-31 0000950129-07-002810 — 2.02, 9.01
- 2007-05-21 0000950129-07-002668 — 2.02, 3.01, 4.02, 9.01
- 2007-04-16 0000950129-07-002002 — 2.02, 4.02, 9.01
- 2007-03-01 0000950129-07-001104 — 5.02, 8.01, 9.01
- 2007-02-08 0000950129-07-000451 — 2.02, 9.01
- 2006-12-08 0000950129-06-010041 — 2.02, 9.01
- 2006-09-08 0000950129-06-008379 — 2.02, 9.01
- 2006-08-09 0000950134-06-015374 — 1.01, 2.01, 8.01, 9.01
- 2006-06-08 0000950129-06-006127 — 2.02, 9.01
- 2006-03-09 0000950129-06-002455 — 2.02, 9.01
- 2005-12-16 0000950129-05-012031 — 2.02, 5.03, 9.01
- 2005-09-13 0000950129-05-009181 — 2.01, 9.01 — amendment of 0000950129-05-006889
- 2005-09-12 0000950129-05-009151 — 2.02, 9.01
- 2005-07-06 0000950129-05-006889 — 1.01, 1.02, 2.01, 2.03, 9.01
- 2005-06-10 0000950129-05-006128 — 2.02, 9.01
- 2005-04-20 0000080420-05-000031 — 5.02
- 2005-03-11 0000080420-05-000024 — 9.01
- 2005-02-25 0000080420-05-000018 — 7.01, 9.01
- 2005-01-21 0000080420-05-000009 — 7.01, 9.01
- 2004-12-17 0000080420-04-000049 — 2.02, 9.01
- 2004-11-01 0000080420-04-000045 — 8.01, 9.01
- 2004-10-08 0001169232-04-005133 — 2.05
- 2004-09-14 0000080420-04-000037 — 5.02
- 2004-09-02 0000080420-04-000030 — 2.02, 9.01
- 2004-06-08 0000080420-04-000021 — 7
- 2004-05-13 0000080420-04-000019 — 4
- 2004-02-27 0000080420-04-000013 — 7
- 2003-12-16 0000950129-03-006136 — 12, 7
- 2003-08-29 0000950129-03-004531 — 12, 7
- 2003-06-03 0000950129-03-003035 — 7, 9
- 2003-05-15 0000950129-03-002812 — 7, 9
- 2002-05-29 0000950129-02-002795 — 4
- 2000-12-21 0000950129-00-006093 — 5, 7
- 1998-09-04 0000950129-98-003802 — 5
- 1996-08-09 0000950129-96-001705 — 2, 7

## late-filing notifications on or before 2023-12-06

- 2007-05-11 0000950129-07-002494 — NT 10-Q, for the period ended 2007-03-31
- 2005-01-18 0000080420-05-000004 — NT 10-K, for the period ended 2004-10-31

## item 2.02 — earnings release, exhibit 99.1

[0000080420-23-000047:8k_2_02:1]
EX-99.1
2
ex991-powlq4xfy2023earning.htm
EX-99.1

[0000080420-23-000047:8k_2_02:2]
Document

[0000080420-23-000047:8k_2_02:3]
Exhibit 99.1

[0000080420-23-000047:8k_2_02:4]
PRESS RELEASE

[0000080420-23-000047:8k_2_02:5]
For Immediate Release

[0000080420-23-000047:8k_2_02:6]
Contacts:        Michael W. Metcalf, CFO

[0000080420-23-000047:8k_2_02:7]
Powell Industries, Inc.

[0000080420-23-000047:8k_2_02:8]
713-947-4422

[0000080420-23-000047:8k_2_02:9]
Robert Winters or Ryan Coleman

[0000080420-23-000047:8k_2_02:10]
Alpha IR Group

[0000080420-23-000047:8k_2_02:11]
POWL@alpha-ir.com

[0000080420-23-000047:8k_2_02:12]
312-445-2870

[0000080420-23-000047:8k_2_02:13]
POWELL INDUSTRIES ANNOUNCES FISCAL 2023 FOURTH QUARTER AND FULL YEAR RESULTS

[0000080420-23-000047:8k_2_02:14]
HOUSTON — December 5, 2023 — Powell Industries, Inc. (NASDAQ: POWL), a leading supplier of custom-engineered solutions for the management, control and distribution of electrical  energy, today announced results for the Fiscal 2023 fourth quarter and full year ended September 30, 2023. All comparisons are to the comparable period in the prior fiscal year, unless otherwise noted.

[0000080420-23-000047:8k_2_02:15]
Fourth Quarter Key Highlights:

[0000080420-23-000047:8k_2_02:16]
•Revenues totaled $209 million, an increase of 28%;

[0000080420-23-000047:8k_2_02:17]
•Gross profit was $52 million, or 24.9% of revenue, an improvement of 430 basis points;

[0000080420-23-000047:8k_2_02:18]
•Net Income was $26 million, or $2.17 per diluted share, and included:

[0000080420-23-000047:8k_2_02:19]
−Unusual items resulting in a benefit of $0.22 per diluted share;

[0000080420-23-000047:8k_2_02:20]
•Net new orders totaled $171 million;

[0000080420-23-000047:8k_2_02:21]
•As of September 30, 2023, backlog was $1.3 billion, an increase of 118%;

[0000080420-23-000047:8k_2_02:22]
•Cash and short-term investments as of September 30, 2023, totaled $279 million.

[0000080420-23-000047:8k_2_02:23]
Full Year Key Highlights:

[0000080420-23-000047:8k_2_02:24]
•Revenues totaled $699 million, an increase of 31%;

[0000080420-23-000047:8k_2_02:25]
•Gross profit was $148 million, or 21.1% of revenue, an improvement of 510 basis points;

[0000080420-23-000047:8k_2_02:26]
•Net Income was $54.5 million, or $4.50 per diluted share and included:

[0000080420-23-000047:8k_2_02:27]
−Unusual items throughout Fiscal 2023 with a combined benefit of $0.38 per diluted share;

[0000080420-23-000047:8k_2_02:28]
•Net new orders totaled $1.4 billion, approximately double the prior year.

[0000080420-23-000047:8k_2_02:29]
Brett A. Cope, Powell’s Chairman and Chief Executive Officer, stated, “The Powell team delivered another outstanding quarter to close out a record year for the Company. Our revenue grew 28% in the quarter, driven by strength across our core industrial end markets as well as continued growth within our Utility and Commercial and Other Industrial market sectors. We recorded $171 million of net new orders in the quarter, reflecting our expectation that new order activity will remain healthy, but return to a more normalized trend compared to previous quarters. Overall, Powell was awarded $1.4 billion of new orders in Fiscal 2023, which was almost double the prior year total, and marked the highest in the Company’s history. I’m incredibly proud of the entire Powell team’s performance to put together one of the best years in the Company’s history.”

[0000080420-23-000047:8k_2_02:30]
Fourth Quarter 2023 Results

[0000080420-23-000047:8k_2_02:31]
Revenues totaled $208.6 million compared to $192.4 million in the third quarter of Fiscal 2023 and $162.7 million in the fourth quarter of the prior year. These increases reflect our strong growth within the Oil and Gas market sector, mainly driven by higher LNG revenue.

[0000080420-23-000047:8k_2_02:32]
Gross profit totaled $52.0 million, or 24.9% of revenue, compared to $42.7 million, or 22.2% of revenue, in the third quarter of Fiscal 2023, and $33.4 million, or 20.6% of revenue, in the fourth quarter of the prior year.

[0000080420-23-000047:8k_2_02:33]
Net new orders totaled $171 million compared to $505 million in the third quarter of Fiscal 2023 and $259 million in the fourth quarter of the prior year. The declines are predominantly a function of challenging comparable periods and new order activity returning to a more normalized cadence.

[0000080420-23-000047:8k_2_02:34]
Backlog totaled $1.3 billion as of September 30, 2023, which was consistent with our backlog as of June 30, 2023, and improved from the $592 million of backlog as of September 30, 2022.

[0000080420-23-000047:8k_2_02:35]
Net income was $26.4 million, or $2.17 per diluted share, compared to $18.5 million, or $1.52 per diluted share, in the third quarter of Fiscal 2023 and $8.7 million, or $0.73 per diluted share, in the fourth quarter of the prior year.

[0000080420-23-000047:8k_2_02:36]
Full Year 2023 Results

[0000080420-23-000047:8k_2_02:37]
Revenues totaled $699.3 million, an increase of 31% compared to $532.6 million in Fiscal 2022, driven by strong growth in the Company’s Oil & Gas, Petrochemical, Utility, and Commercial & Other Industrial markets, partially offset by lower revenue in the Traction market.

[0000080420-23-000047:8k_2_02:38]
Gross profit was $147.6 million, or 21.1% of revenue, compared to $85.0 million, or 16.0% of revenue, in Fiscal 2022.

[0000080420-23-000047:8k_2_02:39]
New orders placed totaled $1.4 billion, roughly double the $718 million of new orders placed in Fiscal 2022. The increase was mainly due to strength in the Company’s core Oil, Gas and Petrochemical markets, continued growth in the Commercial and Other Industrial markets, as well as sustained market activity in the Utility market sector.

[0000080420-23-000047:8k_2_02:40]
Net income was $54.5 million, or $4.50 per diluted share, compared to $13.7 million, or $1.15 per diluted share, in Fiscal 2022.

[0000080420-23-000047:8k_2_02:41]
In Fiscal 2023, our fourth quarter and full year results both include unusual items, which include gains from order cancellations and a $1.9 million non-cash tax benefit resulting from the

[0000080420-23-000047:8k_2_02:42]
release of the valuation allowance associated with our U.K. operations.  The combined impact was $0.22 per diluted share and $0.38 per diluted share, respectively, for the fourth quarter and the full year of Fiscal 2023.

[0000080420-23-000047:8k_2_02:43]
During Fiscal 2022, the Company recognized three unusual events that, when combined, contributed $0.80 per diluted share.

[0000080420-23-000047:8k_2_02:44]
Cope added, “We are entering Fiscal 2024 with $1.3 billion of backlog comprised predominantly of projects that are of a nature, scope and duration that are core to what Powell does best. We continue to see healthy levels of project activity across our end markets, and believe the fundamentals supporting our core industrial markets remain favorable and robust. We continue to take steps to optimize our operational efficiencies while proactively addressing staffing levels, all of which have had a significant positive impact on our profitability. We are confident that our execution and strategic initiatives coupled with favorable industry dynamics will support another successful year for Powell.”

[0000080420-23-000047:8k_2_02:45]
OUTLOOK

[0000080420-23-000047:8k_2_02:46]
Commenting on the Company's outlook, Michael Metcalf, Powell’s Chief Financial Officer said, “Looking forward, we anticipate continued strength commercially across our core end markets throughout Fiscal 2024.  We are also encouraged by our profitability improvements resulting from strengthening operating leverage, as well as the commercial levers that have been implemented in an effort to grow and protect our margin profile. Our focus remains on executing our growing backlog as we navigate through Fiscal 2024.  As we assess the quality and mix of our backlog, along with the staying power of these commercial improvements that we’ve implemented, we expect our Fiscal 2024 margins to be similar to what we experienced throughout Fiscal 2023, which includes the normal seasonality impact that we regularly encounter in our fiscal first quarter.  Considering these variables, in addition to the strong commercial outlook across most of our end markets, as well as our liquidity position and the strength of our balance sheet, we are confident that Fiscal 2024 will be another strong year for Powell.”

[0000080420-23-000047:8k_2_02:47]
4

[0000080420-23-000047:8k_2_02:48]
CONFERENCE CALL

[0000080420-23-000047:8k_2_02:49]
Powell Industries has scheduled a conference call for Wednesday, December 6, 2023, at 11:00 a.m. Eastern time.   To participate in the conference call, dial 1-833-953-2431 (domestic) or 1-412-317-5760 (international) at least 10 minutes before the call begins and ask for the Powell Industries conference call.  A telephonic replay of the conference call will be available through December 13, 2023 and may be accessed by calling 1-877-344-7529 (domestic) or 1-412-317-0088 (international) and using passcode 4055736#.

[0000080420-23-000047:8k_2_02:50]
Investors, analysts and the general public will also have the opportunity to listen to the conference call over the Internet by visiting powellind.com. To listen to the live call on the web, please visit the website at least 15 minutes before the call begins to register, download and install any necessary audio software.  For those who cannot listen to the live webcast, an archive will be available shortly after the call and will remain available for approximately 90 days at powellind.com.

[0000080420-23-000047:8k_2_02:51]
Powell Industries, Inc., headquartered in Houston, designs, manufactures and services custom-engineered equipment and systems for the distribution, control and monitoring of electrical energy.  Powell markets include large industrial customers such as utilities, oil and gas producers, refineries, liquefied natural gas facilities, petrochemical plants, pulp and paper producers, mining operations and commuter railways.   For more information, please visit powellind.com.

[0000080420-23-000047:8k_2_02:52]
of business strategy.  For further information, please refer to the Company's filings with the Securities and Exchange Commission, copies of which are available from the Company without charge.

[0000080420-23-000047:8k_2_02:53]
6

[0000080420-23-000047:8k_2_02:54]
POWELL INDUSTRIES, INC. & SUBSIDIARIES

[0000080420-23-000047:8k_2_02:55]
CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS

[0000080420-23-000047:8k_2_02:56]
|  | Three Months EndedSeptember 30, |  | Year EndedSeptember 30, |
|  | 2023 |  | 2022 |  | 2023 |  | 2022 |
| (In thousands, except per share data) |  |  |  |  |  |  |  |
|  | (Unaudited) |  |  |
| Revenues | $ | 208,641 |  |  | $ | 162,676 |  |  | $ | 699,308 |  |  | $ | 532,582 |  |
| Cost of goods sold | 156,659 |  |  | 129,236 |  |  | 551,755 |  |  | 447,564 |  |
| Gross profit | 51,982 |  | 33,440 |  | 147,553 |  | 85,018 |
| Selling, general and administrative expenses | 20,429 |  |  | 21,458 |  |  | 78,813 |  |  | 70,831 |  |
| Research and development expenses | 1,749 |  |  | 1,620 |  |  | 6,220 |  |  | 6,963 |  |
| Operating income | 29,804 |  |  | 10,362 |  |  | 62,520 |  |  | 7,224 |  |
| Other income | — |  |  | — |  |  | — |  |  | (2,285) |  |
| Interest income, net | (2,915) |  |  | (255) |  |  | (6,430) |  |  | (334) |  |
| Income before income taxes | 32,719 |  | 10,617 |  | 68,950 |  | 9,843 |
| Income tax provision (benefit) | 6,283 |  |  | 1,878 |  |  | 14,425 |  |  | (3,894) |  |
| Net income | $ | 26,436 |  |  | $ | 8,739 |  |  | $ | 54,525 |  |  | $ | 13,737 |  |
| Earnings per share: |  |  |  |  |  |  |  |
| Basic | $ | 2.22 |  |  | $ | 0.74 |  |  | $ | 4.59 |  |  | $ | 1.16 |  |
| Diluted | $ | 2.17 |  |  | $ | 0.73 |  |  | $ | 4.50 |  |  | $ | 1.15 |  |
| Weighted average shares: |  |  |  |  |  |  |  |
| Basic | 11,890 |  |  | 11,811 |  |  | 11,879 |  |  | 11,797 |  |
| Diluted | 12,158 |  |  | 11,969 |  |  | 12,120 |  |  | 11,943 |  |
| SELECTED FINANCIAL DATA: |  |  |  |  |  |  |  |
| Depreciation | $ | 2,106 |  |  | $ | 2,152 |  |  | $ | 8,606 |  |  | $ | 9,358 |  |
| Capital Expenditures | $ | 3,813 |  |  | $ | 686 |  |  | $ | 7,819 |  |  | $ | 2,451 |  |
| Dividends Paid | $ | 3,115 |  |  | $ | 3,063 |  |  | $ | 12,407 |  |  | $ | 12,233 |  |

[0000080420-23-000047:8k_2_02:57]
7

[0000080420-23-000047:8k_2_02:58]
POWELL INDUSTRIES, INC. & SUBSIDIARIES

[0000080420-23-000047:8k_2_02:59]
CONDENSED CONSOLIDATED BALANCE SHEETS

[0000080420-23-000047:8k_2_02:60]
|  | September 30, 2023 |  | September 30, 2022 |
| (In thousands) |  |
| Assets: |  |  |  |
| Cash, cash equivalents and short-term investments | $ | 279,009 |  |  | $ | 116,508 |  |
| Other current assets | 342,976 |  |  | 253,475 |  |
| Property, plant and equipment, net | 97,625 |  |  | 98,628 |  |
| Long-term assets | 32,632 |  |  | 24,769 |  |
| Total assets | $ | 752,242 |  |  | $ | 493,380 |  |
| Liabilities and equity: |  |  |  |
| Current liabilities | $ | 395,686 |  |  | $ | 186,373 |  |
| Deferred and other long-term liabilities | 11,530 |  |  | 9,801 |  |
| Stockholders’ equity | 345,026 |  |  | 297,206 |  |
| Total liabilities and stockholders’ equity | $ | 752,242 |  |  | $ | 493,380 |  |
| SELECTED FINANCIAL DATA: |  |  |  |
| Working capital | $ | 226,299 |  |  | $ | 183,610 |  |
