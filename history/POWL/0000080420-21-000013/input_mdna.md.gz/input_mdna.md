# POWL MD&A — 0000080420-21-000013


## mdna

[0000080420-21-000013:mdna:1]
[same as prior period, unchanged from 0000080420-20-000027:mdna:1]

[0000080420-21-000013:mdna:2]
The following discussion and analysis of our financial condition and results of operations should be read in conjunction with the accompanying condensed consolidated financial statements and related notes included elsewhere in this Quarterly Report on Form 10-Q and with our Annual Report on Form 10-K for the year ended September 30, 2020, which was filed with the Securities and Exchange Commission (SEC) on December 9, 2020 and is available on the SEC’s website at www.sec.gov.

[0000080420-21-000013:mdna:3]
[same as prior period, unchanged from 0000080420-20-000027:mdna:3]

[0000080420-21-000013:mdna:4]
We develop, design, manufacture and service custom-engineered equipment and systems which (1) distribute, control and monitor the flow of electrical energy and (2) provide protection to motors, transformers and other electrically powered equipment. We are headquartered in Houston, Texas and serve the oil and gas markets, including onshore and offshore oil and gas production, petrochemical, liquefied natural gas (LNG) terminals, pipeline, terminal, mining and metals, light rail traction power, electric utility, pulp and paper and other heavy industrial markets. Revenues and costs are primarily related to custom engineered-to-order equipment and systems and are accounted for under percentage-of-completion accounting, which precludes us from providing detailed price and volume information. Our backlog includes various projects that typically take a number of months to produce.

[0000080420-21-000013:mdna:5]
The markets in which we participate are capital-intensive and cyclical in nature. Cyclicality is predominantly driven by customer demand, global economic conditions and anticipated environmental, safety or regulatory changes which affect the manner in which our customers proceed with capital investments. Our customers analyze various factors, including the demand and price for oil, gas and electrical energy, the overall economic and financial environment, governmental budgets, regulatory actions and environmental concerns. These factors influence the release of new capital projects by our customers, which are traditionally awarded in competitive bid situations. Scheduling of projects is matched to the customer requirements, and projects typically take a number of months to produce. Schedules may change during the course of any particular project, and our operating results can, therefore, be impacted by factors outside of our control.

[0000080420-21-000013:mdna:6]
Within the industrial sector, specifically oil, gas and petrochemical, the demand for our electrical distribution solutions is very cyclical and closely correlated to the level of capital expenditures of our end-user customers as well as prevailing global economic conditions.

[0000080420-21-000013:mdna:7]
Beginning in late Fiscal 2018, the combination of a growing global economy, abundant sources of favorably priced natural gas feedstock, and an energy industry focus on transition to natural gas and cleaner-burning fuels drove an increase in capital investment opportunities, specifically across the oil, gas and petrochemical sectors. Some of these opportunities were for natural gas related projects targeting global demand for cleaner-burning fuels. Additionally, projects within the domestic petrochemical sector have benefited from the low feedstock prices of natural gas. Specific to natural gas, the business was awarded a substantial contract in the second quarter of Fiscal 2020 that will support the integrated electrical distribution requirements for a large domestic industrial complex and should be substantially completed in Fiscal 2022. However, we began to experience reduced commercial activity in Fiscal 2020 driven in large part by the uncertainties across our industrial end markets in the U.S. resulting from the COVID-19 pandemic. Considering the long cycle nature of our business, we anticipate that these cyclical conditions will persist through Fiscal 2021.

[0000080420-21-000013:mdna:8]
[same as prior period, unchanged from 0000080420-20-000027:mdna:8]

[0000080420-21-000013:mdna:9]
Through the first fiscal quarter of 2021, the COVID-19 pandemic continues to significantly impact global economic conditions. This pandemic has negatively impacted energy demand, which in turn has resulted in considerable volatility across global oil and gas commodity markets. The demand for our products and services as well as our operations have been negatively impacted by COVID-19, resulting from the associated reduction in oil and gas demand and volatility in commodity prices noted above. As a result, some of our industrial customers are deferring or suspending their planned capital expenditures. Certain of our customers have asked that we delay or cancel our manufacturing on their projects as their operations have been negatively impacted by this pandemic and the reduced oil and gas demand which has resulted in recognition of cancellation fees based on contract terms and the extent of our progress on the projects. We continue to work with and review the contracts with our key suppliers who have been impacted by this pandemic to ensure that we are able to meet our customer commitments.

[0000080420-21-000013:mdna:10]
In response to the lower demand across select end markets, we have taken and will continue to take various actions to reduce costs. During Fiscal 2020, we reduced our global workforce and instituted a temporary furlough program for our salaried workforce in North America. We have also reduced our capital and discretionary spending in response to current business conditions and will continue to monitor the economic conditions during the remainder of Fiscal 2021.

[0000080420-21-000013:mdna:11]
As discussed further under the heading "Outlook" below, it is difficult to predict the economic impact that this pandemic, as well as reduced oil and gas demand and commodity price volatility, may have on our business, results of operations and cash flows going forward.

[0000080420-21-000013:mdna:12]
[same as prior period, unchanged from 0000080420-20-000027:mdna:13]

[0000080420-21-000013:mdna:13]
Quarter Ended December 31, 2020 Compared to the Quarter Ended December 31, 2019 (Unaudited)

[0000080420-21-000013:mdna:14]
[same as prior period, unchanged from 0000080420-20-000027:mdna:15]

[0000080420-21-000013:mdna:15]
Revenues decreased by 21%, or $27.6 million, to $106.6 million in the first quarter of Fiscal 2021, due to a decrease in orders as well as project delays and cancellations of potential projects associated with the global economic impact resulting from the  COVID-19 pandemic and associated reduction in demand across the oil and gas end markets. These cyclical market conditions, which began in the second half of Fiscal 2020, led to a reduction in project bookings which has negatively impacted, and will continue to negatively impact, our revenues in Fiscal 2021. Domestic revenues decreased by 25%, or $26.4 million, to $79.7 million in the first quarter of Fiscal 2021. Domestic revenues were favorably impacted by our progress on our large domestic industrial project awarded in Fiscal 2020, which accounted for approximately 13% of our consolidated revenues for the first quarter of Fiscal 2021. International revenues decreased by 4%, or $1.1 million, to $26.9 million in the first quarter of Fiscal 2021 as a result of lower commercial activity across our international operations. Our international revenues include both revenues generated from our international facilities as well as revenues from export projects generated at our domestic facilities.

[0000080420-21-000013:mdna:16]
Revenue from our oil and gas end markets decreased by 33%, or $20.0 million, to $40.0 million in the first quarter of Fiscal 2021, while petrochemical revenue decreased by 70%, or $21.3 million, to $9.2 million in the first quarter of Fiscal 2021, in each case primarily due to the uncertainty across our end markets. Revenue from utility markets increased by 22%, or $5.2 million, to $28.2 million, and traction market revenue increased by 60%, or $5.0 million, to $13.4 million in the first quarter of Fiscal 2021, as the mix of our projects shifts across our global operating facilities. Revenue from all other markets combined increased by $3.5 million to $15.9 million in the first quarter of Fiscal 2021.

[0000080420-21-000013:mdna:17]
The reduction in revenue led to a reduction in gross profit of 16%, or $3.6 million, as compared to the first quarter of Fiscal 2020. However, gross profit of $18.3 million for the first quarter of Fiscal 2021 benefited from favorable close out gains on certain projects resulting from cost and productivity efficiencies and to a lesser extent from cancellation fees from certain contracts in our North American manufacturing facilities. As a result, gross profit as a percentage of revenues increased to 17% in the first quarter of Fiscal 2021, compared to 16% in the first quarter of Fiscal 2020.

[0000080420-21-000013:mdna:18]
[same as prior period, unchanged from 0000080420-20-000027:mdna:19]

[0000080420-21-000013:mdna:19]
Selling, general and administrative expenses decreased by 2%, or $0.4 million, to $16.9 million in the first quarter of Fiscal 2021, primarily due to decreased personnel costs as a result of workforce reductions in Fiscal 2020 and lower travel-related costs resulting from the COVID-19 pandemic. Selling, general and administrative expenses, as a percentage of revenues, was 16% during the first quarter of Fiscal 2021 compared to 13% during the first quarter of Fiscal 2020, primarily due to the decrease in revenues.

[0000080420-21-000013:mdna:20]
[same as prior period, unchanged from 0000080420-20-000027:mdna:39]

[0000080420-21-000013:mdna:21]
We recorded an income tax provision of $0.1 million in the first quarter of Fiscal 2021, compared to an income tax provision of $0.6 million in the first quarter of Fiscal 2020. The effective tax rate for the first quarter of Fiscal 2021 was negative 41%, compared to an effective tax rate of 17% in the first quarter of Fiscal 2020. For the three months ended December 31, 2020, the income tax provision was negatively impacted by losses recognized in various foreign jurisdictions that were reserved with a valuation allowance as well as discrete items primarily related to the vesting of restricted stock units. The income tax provision was favorably impacted by the estimated Research and Development Tax Credit and the projected utilization of net operating loss carryforwards in Canada that were fully reserved with a valuation allowance in the first quarter of Fiscal 2021 and 2020.

[0000080420-21-000013:mdna:22]
Net Income/Loss

[0000080420-21-000013:mdna:23]
In the first quarter of Fiscal 2021, we recorded a net loss of $0.4 million, or $0.03 per diluted share, compared to net income of $2.8 million, or $0.24 per diluted share, in the first quarter of Fiscal 2020, primarily due to a decline in revenues and gross profit resulting from lower orders caused by the economic impact resulting from the COVID-19 pandemic and the associated reduction in global demand across the oil and gas end markets.

[0000080420-21-000013:mdna:24]
[same as prior period, unchanged from 0000080420-20-000027:mdna:28]

[0000080420-21-000013:mdna:25]
The order backlog at December 31, 2020 was $464.9 million, a decrease of 2% from $476.8 million at September 30, 2020 and a 9% increase over the $425.9 million backlog at December 31, 2019. Bookings, net of cancellations and scope reductions, decreased by 34% in the first quarter of Fiscal 2021 to $91.1 million, compared to $137.4 million in the first quarter of Fiscal 2020, primarily due to decreased global demand across our core oil and gas markets.

[0000080420-21-000013:mdna:26]
[same as prior period, unchanged from 0000080420-20-000027:mdna:46]

[0000080420-21-000013:mdna:27]
As noted in "Overview" above, the markets in which we participate are capital-intensive and cyclical in nature. A significant portion of our revenues has historically been from the oil, gas and petrochemical markets. Oil and gas commodity price levels have been unstable over the last several years, and our customers have in certain cases, delayed some of their major capital investment projects. Beginning in late Fiscal 2018 through the first quarter of Fiscal 2020, our customers' decisions to invest in projects in our key oil and gas and petrochemical markets were influenced to some extent by relative stabilization of commodity prices and the increased global demand for cleaner-burning fuels during that period of time. We believe that this change in market sentiment during that period of time had a favorable impact on our orders and backlog entering Fiscal 2020. However, the recent declines in oil prices and the global economic impacts from COVID-19 have had, and may continue to have, a negative impact on our business going forward, as discussed in more detail below. Specific to the energy industry focus on transition to natural gas and cleaner-burning fuels, the business was awarded a substantial contract in Fiscal 2020 that will support the integrated electrical distribution requirements for a large domestic industrial complex and should be substantially completed in Fiscal 2022.

[0000080420-21-000013:mdna:28]
Our operating results are impacted by factors such as the timing of new order awards, customer approval of final engineering and design specifications and delays in customer construction schedules, all of which contribute to short-term earnings variability and the timing of project execution. Our operating results also have been, and may continue to be, impacted by the timing and resolution of change orders, project close-out and resolution of potential contract claims and liquidated damages, all of which could improve or deteriorate gross margins during the period in which these items are resolved with our customers. These factors may result in periods of underutilization of our resources and facilities, which may negatively impact our ability to cover our fixed costs. The strong commercial activity and subsequent orders in Fiscal 2018 and 2019 led to solid revenue and operating results for Fiscal 2020. We began to experience lower commercial activity in Fiscal 2020 driven in large part from the  uncertainty resulting from the COVID-19 pandemic, as discussed in "Overview" above. Considering the long cycle nature of our business, we anticipate these cyclical conditions will persist through Fiscal 2021. We will continue to monitor the variables that impact our markets while adjusting to the global conditions in order to maintain a competitive cost and technological advantage in the markets that we serve.

[0000080420-21-000013:mdna:29]
The consequences of a prolonged economic decline could include, but are not limited to, a continued reduction in commercial and industrial activity. Accordingly, the Company cannot reasonably estimate the duration or severity of this pandemic, or the extent to which the disruption may materially impact our business, results of operations or cash flows. We will take prudent measures to maintain our strong liquidity and cash position, which may include reducing our capital expenditures and research and development costs, as well as reducing or eliminating future dividend payments.

[0000080420-21-000013:mdna:30]
[same as prior period, unchanged from 0000080420-20-000027:mdna:52]

[0000080420-21-000013:mdna:31]
As of December 31, 2020, current assets exceeded current liabilities by 2.4 times, and our debt to total capitalization was 0.13%.

[0000080420-21-000013:mdna:32]
Cash, cash equivalents and short-term investments decreased to $149.7 million at December 31, 2020, compared to $178.9 million at September 30, 2020. This decrease in cash was primarily driven by a decrease in accounts receivable collections and the timing of contract billing milestones as well as the payment of Fiscal 2020 variable incentive compensation. We believe that our strong working capital position, available borrowings under our credit facility and available cash should be sufficient to finance future operating activities, capital improvements, research and development initiatives and debt repayments for the foreseeable future.

[0000080420-21-000013:mdna:33]
We have a credit agreement with Bank of America, N.A. (the "U.S. Revolver") which is a $75.0 million revolving credit facility available for both borrowings and letters of credit and expires September 2024. As of December 31, 2020, there were no amounts borrowed under this facility, and letters of credit outstanding were $38.9 million. As of December 31, 2020, $36.1 million was available for the issuance of letters of credit and borrowing under the U.S. Revolver. Total long-term debt, including current maturities, totaled $0.4 million at December 31, 2020 related to outstanding industrial development revenue bonds. We are required to maintain certain financial covenants, the most significant of which are a consolidated leverage ratio of less than 3.0 to 1.0 and a consolidated interest coverage ratio of greater than 3.0 to 1.0. The consolidated leverage ratio is our most restrictive covenant and a decrease in our earnings before interest, taxes, depreciation and amortization (EBITDA) could restrict our ability to issue letters of credit under the U.S. Revolver. For further information regarding our debt, see Notes E and F of Notes to Condensed Consolidated Financial Statements.

[0000080420-21-000013:mdna:34]
Approximately $26.6 million of our cash and cash equivalents at December 31, 2020 was held outside of the U.S. for international operations. It is our intention to indefinitely reinvest all current and future foreign earnings internationally in order to ensure sufficient working capital to support our international operations. In the event that we elect to repatriate some or all of the foreign earnings that were previously deemed to be indefinitely reinvested outside the U.S., we may incur additional tax expense upon such repatriation under current tax laws.

[0000080420-21-000013:mdna:35]
[same as prior period, unchanged from 0000080420-20-000027:mdna:57]

[0000080420-21-000013:mdna:36]
Operating activities used $25.2 million during the three months ended December 31, 2020 and provided $2.1 million during the same period in Fiscal 2020. Cash flow from operations is primarily influenced by project volume, the timing of milestone payments from our customers and the payment terms with our suppliers. This decrease in operating cash flow was primarily due to a decrease in accounts receivable collections and the timing of contract billing milestones.

[0000080420-21-000013:mdna:37]
[same as prior period, unchanged from 0000080420-20-000027:mdna:59]

[0000080420-21-000013:mdna:38]
Investing activities provided $3.0 million during the three months ended December 31, 2020 compared to $3.7 million provided during the same period in Fiscal 2020. The decrease in cash provided by investing activities in the first three months of Fiscal 2020 was primarily due to short-term investment activity offset by a decrease in capital expenditures.

[0000080420-21-000013:mdna:39]
[same as prior period, unchanged from 0000080420-20-000027:mdna:61]

[0000080420-21-000013:mdna:40]
Net cash used in financing activities was $4.1 million during the three months ended December 31, 2020 and $4.0 million during the same period in Fiscal 2020, which primarily consisted of approximately $3.0 million of dividends paid in each period.

[0000080420-21-000013:mdna:41]
[same as prior period, unchanged from 0000080420-20-000027:mdna:63]

[0000080420-21-000013:mdna:42]
[same as prior period, unchanged from 0000080420-20-000027:mdna:64]

[0000080420-21-000013:mdna:43]
[same as prior period, unchanged from 0000080420-20-000027:mdna:65]

[0000080420-21-000013:mdna:44]
[same as prior period, unchanged from 0000080420-20-000027:mdna:66]

[0000080420-21-000013:mdna:45]
There have been no material changes to our critical accounting policies as disclosed in our Annual Report on Form 10-K for the fiscal year ended September 30, 2020, which was filed with the SEC on December 9, 2020.
