# POWL notes — 0000080420-21-000013


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureAndSignificantAccountingPoliciesTextBlock

[0000080420-21-000013:notes:1]
[same as prior period, unchanged from 0000080420-20-000027:notes:1]

[0000080420-21-000013:notes:2]
Powell Industries, Inc. (we, us, our, Powell or the Company) was incorporated in the state of Delaware in 2004 as a successor to a Nevada company incorporated in 1968. The Nevada company was the successor to a company founded by William E. Powell in 1947, which merged into the Company in 1977. Our major subsidiaries, all of which are wholly owned, include: Powell Electrical Systems, Inc.; Powell (UK) Limited; Powell Canada Inc.; and Powell Industries International, B.V.

[0000080420-21-000013:notes:3]
We develop, design, manufacture and service custom-engineered equipment and systems which (1) distribute, control and monitor the flow of electrical energy and (2) provide protection to motors, transformers and other electrically powered equipment. We are headquartered in Houston, Texas and serve the oil and gas markets, including onshore and offshore oil and gas production, petrochemical, liquefied natural gas (LNG) terminals, pipeline, terminal, mining and metals, light rail traction power, electric utility, pulp and paper and other heavy industrial markets.

[0000080420-21-000013:notes:4]
[same as prior period, unchanged from 0000080420-20-000027:notes:4]

[0000080420-21-000013:notes:5]
Through the first fiscal quarter of 2021, the COVID-19 pandemic continues to significantly impact global economic conditions. This pandemic has negatively impacted energy demand, which in turn has resulted in considerable volatility across global oil and gas commodity markets. As a result, some of our industrial customers are deferring or suspending their planned capital expenditures. Certain of our customers have asked that we delay or cancel our manufacturing on their projects as their operations have been negatively impacted by this pandemic and the reduced oil and gas demand. We continue to work with and review the contracts with our key suppliers who have been impacted by this pandemic to ensure that we are able to meet our customer commitments.

[0000080420-21-000013:notes:6]
The consequences of a prolonged economic decline could include, but are not limited to, a continued reduction in commercial and industrial activity. Accordingly, the Company cannot reasonably estimate the duration or severity of this pandemic, or the extent to which the disruption may materially impact our business, results of operations or cash flows. We will take prudent measures to maintain our strong liquidity and cash position, which may include reducing our capital expenditures and research and development costs, as well as reducing or eliminating future dividend payments.

[0000080420-21-000013:notes:7]
[same as prior period, unchanged from 0000080420-20-000027:notes:8]

[0000080420-21-000013:notes:8]
[same as prior period, unchanged from 0000080420-20-000027:notes:9]

[0000080420-21-000013:notes:9]
[same as prior period, unchanged from 0000080420-20-000027:notes:10]

[0000080420-21-000013:notes:10]
These unaudited condensed consolidated financial statements should be read in conjunction with the audited consolidated financial statements and notes thereto of Powell and its subsidiaries included in Powell’s Annual Report on Form 10-K for the year ended September 30, 2020, which was filed with the Securities and Exchange Commission (SEC) on December 9, 2020.

[0000080420-21-000013:notes:11]
References to Fiscal 2021 and Fiscal 2020 used throughout this report shall mean our fiscal years ended September 30, 2021 and 2020, respectively.

[0000080420-21-000013:notes:12]
[same as prior period, unchanged from 0000080420-20-000027:notes:13]

[0000080420-21-000013:notes:13]
The preparation of condensed consolidated financial statements in conformity with U.S. GAAP requires management to make estimates and assumptions that affect the amounts reported in the condensed consolidated financial statements and accompanying footnotes. The most significant estimates used in our condensed consolidated financial statements affect revenue recognition and estimated cost recognition on our customer contracts, the allowance for doubtful accounts, provision for excess and obsolete inventory, warranty accruals and income taxes. The amounts recorded for warranties, legal, income taxes, impairment of long-lived assets (when applicable) and other contingent liabilities require judgments regarding the amount of expenses that will ultimately be incurred. We base our estimates on historical experience, forecasts and various other assumptions, as well as the specific circumstances surrounding these contingent liabilities, in evaluating the amount of liability that should be recorded. Additionally, the recognition of deferred tax assets requires estimates related to future income and other assumptions regarding timing and future profitability because the ultimate realization of net deferred tax assets is dependent on the generation of future taxable income during the periods in which temporary differences become deductible. Estimates routinely change as new events occur, additional information becomes available or operating environments change. Actual results may differ from our prior estimates.

[0000080420-21-000013:notes:14]
New Accounting Standard

[0000080420-21-000013:notes:15]
In June 2016, the Financial Accounting Standards Board (FASB) issued a new topic on measurement of credit losses. The topic introduces an impairment model known as the current expected credit loss (CECL) model that is based on an expected loss methodology rather than an incurred loss methodology for financial instruments. Under the new topic, an entity recognizes as an allowance its estimate of expected credit losses with the intention of improving financial reporting by requiring timelier recognition of such losses. We adopted this topic on October 1, 2020 and such adoption did not have a material impact on our consolidated financial statements.


## us-gaap:EarningsPerShareTextBlock

[0000080420-21-000013:notes:16]
Earnings Per Share
We compute basic earnings per share by dividing net income (loss) by the weighted average number of common shares outstanding during the period. Diluted earnings per common and potential common share includes the weighted average of additional shares associated with the incremental effect of dilutive restricted stock and restricted stock units, as prescribed by the FASB guidance on earnings per share.

[0000080420-21-000013:notes:17]
[same as prior period, unchanged from 0000080420-20-000027:notes:19]

[0000080420-21-000013:notes:18]
|  | Three months ended December 31, |  |  |
|  | 2020 |  | 2019 |  |  |  |  |
| Numerator: |  |  |  |  |  |  |  |
| Net income (loss) | $ | (364) |  |  | $ | 2,775 |  |  |  |  |  |
| Denominator: |  |  |  |  |  |  |  |
| Weighted average basic shares | 11,674 |  |  | 11,614 |  |  |  |  |  |
| Dilutive effect of restricted stock units | — |  |  | 51 |  |  |  |  |  |
| Weighted average diluted shares | 11,674 |  |  | 11,665 |  |  |  |  |  |
| Earnings per share: |  |  |  |  |  |  |  |
| Basic | $ | (0.03) |  |  | $ | 0.24 |  |  |  |  |  |
| Diluted | $ | (0.03) |  |  | $ | 0.24 |  |  |  |  |  |

[0000080420-21-000013:notes:19]
For the three months ended December 31, 2020, we incurred a net loss and therefore all potential common shares were deemed to be anti-dilutive.


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0000080420-21-000013:notes:20]
[same as prior period, unchanged from 0000080420-20-000027:notes:21]

[0000080420-21-000013:notes:21]
[same as prior period, unchanged from 0000080420-20-000027:notes:22]

[0000080420-21-000013:notes:22]
|  | Three months ended December 31, |  |  |
|  | 2020 |  | 2019 |  |  |  |  |
| Balance at beginning of period | $ | 510 |  |  | $ | 301 |  |  |  |  |  |
| Bad debt expense (recovery) | (19) |  |  | 42 |  |  |  |  |  |
| Uncollectible accounts written off, net of recoveries | (10) |  |  | (10) |  |  |  |  |  |
| Change due to foreign currency translation | 12 |  |  | 13 |  |  |  |  |  |
| Balance at end of period | $ | 493 |  |  | $ | 346 |  |  |  |  |  |

[0000080420-21-000013:notes:23]
[same as prior period, unchanged from 0000080420-20-000027:notes:24]

[0000080420-21-000013:notes:24]
[same as prior period, unchanged from 0000080420-20-000027:notes:25]

[0000080420-21-000013:notes:25]
|  | December 31, 2020 |  | September 30, 2020 |
| Raw materials, parts and sub-assemblies, net | $ | 28,261 |  |  | $ | 27,429 |  |
| Work-in-progress | 758 |  |  | 1,539 |  |
| Total inventories | $ | 29,019 |  |  | $ | 28,968 |  |

[0000080420-21-000013:notes:26]
[same as prior period, unchanged from 0000080420-20-000027:notes:27]

[0000080420-21-000013:notes:27]
[same as prior period, unchanged from 0000080420-20-000027:notes:28]

[0000080420-21-000013:notes:28]
|  | Three months ended December 31, |  |  |
|  | 2020 |  | 2019 |  |  |  |  |
| Balance at beginning of period | $ | 2,771 |  |  | $ | 2,946 |  |  |  |  |  |
| Increase to warranty expense | 658 |  |  | 843 |  |  |  |  |  |
| Deduction for warranty charges | (779) |  |  | (645) |  |  |  |  |  |
| Change due to foreign currency translation | 25 |  |  | 18 |  |  |  |  |  |
| Balance at end of period | $ | 2,675 |  |  | $ | 3,162 |  |  |  |  |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0000080420-21-000013:notes:29]
[same as prior period, unchanged from 0000080420-20-000027:notes:30]

[0000080420-21-000013:notes:30]
Our revenues are primarily generated from the manufacturing of custom-engineered products and systems under long-term fixed-price contracts under which we agree to manufacture various products such as traditional and arc-resistant distribution switchgear and control gear, medium-voltage circuit breakers, monitoring and control communications systems, motor control centers, switches and bus duct systems. These products may be sold separately as an engineered solution, but are typically integrated into custom-built enclosures which we also build.  These enclosures are referred to as power control room substations (PCRs®), custom-engineered modules or electrical houses (E-Houses). Some contracts may also include the installation and the commissioning of these enclosures.

[0000080420-21-000013:notes:31]
[same as prior period, unchanged from 0000080420-20-000027:notes:32]

[0000080420-21-000013:notes:32]
We also have contracts to provide value-added services such as field service inspection, installation, commissioning, modification and repair, as well as retrofit and retrofill components for existing systems.  If the service contract terms give us the right to invoice the customer for an amount that corresponds directly with the value of our performance completed to date (i.e., a service contract in which we bill a fixed amount for each hour of service provided), then we recognize revenue over time

[0000080420-21-000013:notes:33]
in each reporting period corresponding to the amount with which we have the right to invoice.  Our performance obligations are satisfied as the work progresses. Revenues from our custom-engineered products and value-added services transferred to customers over time accounted for approximately 92% of total revenues for the three months ended December 31, 2020 and 95% of total revenues for the three months ended December 31, 2019.

[0000080420-21-000013:notes:34]
We also have sales orders for spare parts and replacement circuit breakers for switchgear that are obsolete or that are no longer produced by the original manufacturer. Revenues from these sales orders are recognized at the time we fulfill our performance obligation to the customer, which is typically upon shipment and represented approximately 8% of total revenues for the three months ended December 31, 2020 and 5% of total revenues for the three months ended December 31, 2019.

[0000080420-21-000013:notes:35]
[same as prior period, unchanged from 0000080420-20-000027:notes:36]

[0000080420-21-000013:notes:36]
Selling and administrative costs incurred in relation to obtaining a contract are typically expensed as incurred. We periodically utilize a third-party sales agent to obtain a contract and will pay a commission to that agent. We record the full commission liability to the third-party sales agents at the order date, with a corresponding deferred asset. As the project progresses, we record commission expense based on percentage of completion rates that correlate to the project and reduce the deferred asset. Once we have been paid by the customer, we pay the commission and the liability is reduced.

[0000080420-21-000013:notes:37]
[same as prior period, unchanged from 0000080420-20-000027:notes:38]

[0000080420-21-000013:notes:38]
[same as prior period, unchanged from 0000080420-20-000027:notes:39]

[0000080420-21-000013:notes:39]
Remaining unsatisfied performance obligations, which we refer to as backlog, represent the estimated transaction price for goods and services for which we have a material right, but work has not been performed. As of December 31, 2020, we had backlog of $464.9 million, of which approximately $306.8 million is expected to be recognized as revenue within the next twelve months. Backlog may not be indicative of future operating results as orders may be cancelled or modified by our customers. Our backlog does not include service and maintenance-type contracts for which we have the right to invoice as services are performed.

[0000080420-21-000013:notes:40]
[same as prior period, unchanged from 0000080420-20-000027:notes:41]

[0000080420-21-000013:notes:41]
[same as prior period, unchanged from 0000080420-20-000027:notes:42]

[0000080420-21-000013:notes:42]
For the three months ended December 31, 2020 and 2019, our operating results were positively impacted by $5.5 million and $4.3 million, respectively, as a result of changes in contract estimates related to projects in progress at the beginning of the respective period. These changes in estimates resulted primarily from favorable project execution and negotiations of variable consideration, discussed below, as well as revenue and reduced costs recognized from project cancellations and other changes in facts and circumstances during these periods.

[0000080420-21-000013:notes:43]
[same as prior period, unchanged from 0000080420-20-000027:notes:44]

[0000080420-21-000013:notes:44]
[same as prior period, unchanged from 0000080420-20-000027:notes:45]

[0000080420-21-000013:notes:45]
[same as prior period, unchanged from 0000080420-20-000027:notes:46]

[0000080420-21-000013:notes:46]
[same as prior period, unchanged from 0000080420-20-000027:notes:47]

[0000080420-21-000013:notes:47]
[same as prior period, unchanged from 0000080420-20-000027:notes:48]

[0000080420-21-000013:notes:48]
The timing of revenue recognition, billings and cash collections affects accounts receivable, contract assets and contract liabilities in our Condensed Consolidated Balance Sheets.

[0000080420-21-000013:notes:49]
[same as prior period, unchanged from 0000080420-20-000027:notes:50]

[0000080420-21-000013:notes:50]
[same as prior period, unchanged from 0000080420-20-000027:notes:51]

[0000080420-21-000013:notes:51]
Our contract assets and liabilities are reported in a net position on a contract-by-contract basis at the end of each reporting period and are generally classified as current. The timing of contract billing milestones related to our Fiscal 2020 contract award for a large industrial project contributed significantly to our net contract liability at September 30, 2020 and December 31, 2020.

[0000080420-21-000013:notes:52]
Contract assets and liabilities as of December 31, 2020 and September 30, 2020 are summarized below (in thousands):

[0000080420-21-000013:notes:53]
|  | December 31, 2020 |  | September 30, 2020 |
| Contract assets | $ | 47,886 |  |  | $ | 50,995 |  |
| Contract liabilities | (70,939) |  |  | (79,445) |  |
| Net contract liability | $ | (23,053) |  |  | $ | (28,450) |  |

[0000080420-21-000013:notes:54]
The decrease in net contract liability at December 31, 2020 from September 30, 2020 was primarily due to the timing of contract billing milestones and new orders. To determine the amount of revenue recognized during the period from contract liabilities, we first allocate revenue to the individual contract liability balance outstanding at the beginning of the period until the revenue exceeds that balance. During the three months ended December 31, 2020, we recognized revenue of approximately $36.4 million that was related to contract liabilities outstanding at September 30, 2020.

[0000080420-21-000013:notes:55]
The timing of our invoice process is typically dependent on the completion of certain milestones and contract terms and subject to agreement by our customer.  Payment is typically expected within 30 days of invoice. Any uncollected invoiced amounts for our performance obligations recognized over time, including contract retentions, are recorded as accounts receivable in the Condensed Consolidated Balance Sheets. Certain contracts contain retention provisions that become due upon completion of contractual requirements. As of December 31, 2020 and September 30, 2020, accounts receivable included retention amounts of $7.8 million and $6.9 million, respectively. Of the retained amount at December 31, 2020, $6.1 million is expected to be collected in the next twelve months and is recorded in accounts receivable. The remaining $1.7 million is recorded in other assets.

[0000080420-21-000013:notes:56]
[same as prior period, unchanged from 0000080420-20-000027:notes:57]

[0000080420-21-000013:notes:57]
The following tables present our disaggregated revenue by geographic destination and market sector for the three months ended December 31, 2020 and 2019 (in thousands):

[0000080420-21-000013:notes:58]
|  | Three months ended December 31, |  |  |
|  | 2020 |  | 2019 |  |  |  |  |
| United States | $ | 80,586 |  |  | $ | 107,078 |  |  |  |  |  |
| Canada | 14,091 |  |  | 14,454 |  |  |  |  |  |
| Europe, Middle East and Africa | 8,256 |  |  | 10,166 |  |  |  |  |  |
| Asia/Pacific | 2,716 |  |  | 1,686 |  |  |  |  |  |
| Mexico, Central and South America | 926 |  |  | 766 |  |  |  |  |  |
| Total revenues by geographic destination | $ | 106,575 |  |  | $ | 134,150 |  |  |  |  |  |

[0000080420-21-000013:notes:59]
|  | Three months ended December 31, |  |  |
|  | 2020 |  | 2019 |  |  |  |  |
| Oil and gas | $ | 40,028 |  |  | $ | 59,994 |  |  |  |  |  |
| Petrochemical | 9,165 |  |  | 30,426 |  |  |  |  |  |
| Electric utility | 28,171 |  |  | 23,015 |  |  |  |  |  |
| Traction power | 13,361 |  |  | 8,351 |  |  |  |  |  |
| All others | 15,850 |  |  | 12,364 |  |  |  |  |  |
| Total revenues by market sector | $ | 106,575 |  |  | $ | 134,150 |  |  |  |  |  |


## us-gaap:RevenueFromContractWithCustomerPolicyTextBlock

[0000080420-21-000013:notes:60]
Revenue Recognition

[0000080420-21-000013:notes:61]
Additionally, some contracts may contain a cancellation clause that could limit the amount of revenue we are able to recognize over time. In these instances, revenue and costs associated with these contracts are deferred and recognized at a point in time when the performance obligation is fulfilled.
Selling and administrative costs incurred in relation to obtaining a contract are typically expensed as incurred. We periodically utilize a third-party sales agent to obtain a contract and will pay a commission to that agent. We record the full commission liability to the third-party sales agents at the order date, with a corresponding deferred asset. As the project progresses, we record commission expense based on percentage of completion rates that correlate to the project and reduce the deferred asset. Once we have been paid by the customer, we pay the commission and the liability is reduced
Performance Obligations

[0000080420-21-000013:notes:62]
A performance obligation is a promise in a contract or with a customer to transfer a distinct good or service. A contract’s transaction price is allocated to each distinct performance obligation and recognized as revenue as the performance obligations are satisfied. To determine the proper revenue recognition for contracts, we evaluate whether a contract should be accounted for as more than one performance obligation or, less commonly, whether two or more contracts should be combined and accounted for as one performance obligation.  This evaluation of performance obligations requires significant judgment.  The majority of our contracts have a single performance obligation where multiple engineered products and services are combined into a single custom-engineered solution. Our contracts generally include a standard assurance warranty that typically ends 18 months after shipment. Occasionally, we provide service-type warranties that will extend the warranty period. These extended warranties qualify as a separate performance obligation, and revenue is deferred and recognized over the warranty period. If we determine during the evaluation of the contract that there are multiple performance obligations, we allocate the transaction price to each performance obligation using our best estimate of the standalone selling price of each distinct good or service in the contract. 
Remaining unsatisfied performance obligations, which we refer to as backlog, represent the estimated transaction price for goods and services for which we have a material right, but work has not been performed.
Contract Estimates

[0000080420-21-000013:notes:63]
Contract liabilities typically represent advance payments from contractual billing milestones and billings in excess of revenue recognized. It is unusual to have advanced milestone payments with a term greater than one year, which could represent a financing component on the contract.  
Our contract assets and liabilities are reported in a net position on a contract-by-contract basis at the end of each reporting period and are generally classified as current. The timing of contract billing milestones related to our Fiscal 2020 contract award for a large industrial project contributed significantly to our net contract liability at September 30, 2020 and The timing of our invoice process is typically dependent on the completion of certain milestones and contract terms and subject to agreement by our customer.  Payment is typically expected within 30 days of invoice. Any uncollected invoiced amounts for our performance obligations recognized over time, including contract retentions, are recorded as accounts receivable in the Condensed Consolidated Balance Sheets. Certain contracts contain retention provisions that become due upon completion of contractual requirements.


## us-gaap:LongTermDebtTextBlock

[0000080420-21-000013:notes:64]
Long-Term Debt
Long-term debt consisted of the following (in thousands):

[0000080420-21-000013:notes:65]
|  | December 31, 2020 |  | September 30, 2020 |
| Industrial development revenue bonds | $ | 400 |  |  | $ | 800 |  |
| Less: current portion | (400) |  |  | (400) |  |
| Total long-term debt | $ | — |  |  | $ | 400 |  |

[0000080420-21-000013:notes:66]
U.S. Revolver

[0000080420-21-000013:notes:67]
We have a credit agreement with Bank of America, N.A. (the "U.S. Revolver") which is a $75.0 million revolving credit facility that is available for both borrowings and letters of credit and expires September 2024. As of December 31, 2020, there were no amounts borrowed under this facility and letters of credit outstanding were $38.9 million. There was $36.1 million available for the issuance of letters of credit and borrowings under the U.S. Revolver as of December 31, 2020.

[0000080420-21-000013:notes:68]
We are required to maintain certain financial covenants, the most significant of which are a consolidated leverage ratio less than 3.0 to 1.0 and a consolidated interest coverage ratio of greater than 3.0 to 1.0. The consolidated leverage ratio is our most restrictive covenant and a decrease in our earnings before interest, taxes, depreciation and amortization (EBITDA) could restrict our ability to issue letters of credit under the U.S. Revolver. Additionally, we must maintain a consolidated cash balance of $30 million at all times. The U.S. Revolver also contains a "material adverse effect" clause which is a material change in our operations, business, properties, liabilities or condition (financial or otherwise) or a material impairment of our ability to perform our obligations under our credit agreements. As of December 31, 2020, we were in compliance with all of the financial covenants of the U.S. Revolver.

[0000080420-21-000013:notes:69]
The U.S. Revolver allows the Company to elect that any borrowing under the facility bears an interest rate based on either the base rate or the eurocurrency rate, in each case, plus the applicable rate. The base rate is generally the highest of (a) the federal funds rate plus 0.50%, (b) the Bank of America prime rate or (c) the London Interbank Offered Rate (LIBOR) plus 1.00%. The applicable rate is generally a range from (0.25)% to 1.75% depending on the type of loan and the Company's consolidated leverage ratio.

[0000080420-21-000013:notes:70]
The U.S. Revolver is collateralized by a pledge of 100% of the voting capital stock of each of our domestic subsidiaries and 65% of the voting capital stock of each non-domestic subsidiary. The U.S. Revolver provides for customary events of default and carries cross-default provisions with other existing debt agreements. If an event of default (as defined in the U.S. Revolver) occurs and is continuing, on the terms and subject to the conditions set forth in the U.S. Revolver, amounts and letters of credit outstanding under the U.S. Revolver may be accelerated and may become immediately due and payable.

[0000080420-21-000013:notes:71]
Industrial Development Revenue Bonds

[0000080420-21-000013:notes:72]
We borrowed $8.0 million in October 2001 through a loan agreement funded with proceeds from tax-exempt industrial development revenue bonds (Bonds) for the completion of our Northlake, Illinois facility. The Bonds are subject to various covenants, for which we were in compliance at December 31, 2020. The Bonds mature in 2021 and bear interest at a floating rate determined weekly by the Bonds’ remarketing agent. This interest rate was 0.24% as of December 31, 2020.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0000080420-21-000013:notes:73]
Commitments and Contingencies
Letters of Credit, Bank Guarantees and Bonds

[0000080420-21-000013:notes:74]
Certain customers require us to post letters of credit, bank guarantees or surety bonds. These security instruments assure that we will perform under the terms of our contract. In the event of default, the counterparty may demand payment from the bank under a letter of credit or bank guarantee, or performance by the surety under a bond. To date, there have been no significant draws or claims related to security instruments for the periods reported. We were contingently liable for letters of credit of $38.9 million as of December 31, 2020. We also had surety bonds totaling $185.0 million that were outstanding, with additional bonding capacity of $565.0 million available, at December 31, 2020.

[0000080420-21-000013:notes:75]
We have a $9.6 million facility agreement (Facility Agreement) between Powell (UK) Limited and a large international bank that provides Powell (UK) Limited the ability to enter into bank guarantees as well as forward exchange contracts and currency options. At December 31, 2020, we had outstanding guarantees totaling $7.6 million and amounts available under this Facility Agreement were $2.0 million. The Facility Agreement provides for financial covenants and customary events of default, and carries cross-default provisions with our U.S. Revolver. If an event of default (as defined in the Facility Agreement) occurs and is continuing, per the terms and subject to the conditions set forth therein, obligations outstanding under the Facility Agreement may be accelerated and declared immediately due and payable. Additionally, we are required to maintain cash collateral for guarantees greater than two years. As of December 31, 2020, we were in compliance with all of the financial covenants of the Facility Agreement.

[0000080420-21-000013:notes:76]
Litigation

[0000080420-21-000013:notes:77]
We are involved in various legal proceedings, claims and other disputes arising from our commercial operations, projects, employees and other matters which, in general, are subject to uncertainties and in which the outcomes are not predictable. Although we can give no assurances about the resolution of pending claims, litigation or other disputes and the effect such outcomes may have on us, management believes that any ultimate liability resulting from the outcome of such proceedings, to the extent not otherwise provided or covered by insurance, will not have a material adverse effect on our consolidated financial position or results of operations or liquidity.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0000080420-21-000013:notes:78]
Stock-Based Compensation
Refer to our Annual Report on Form 10-K for the fiscal year ended September 30, 2020 for a full description of our existing stock-based compensation plans.

[0000080420-21-000013:notes:79]
[same as prior period, unchanged from 0000080420-20-000027:notes:79]

[0000080420-21-000013:notes:80]
We issue restricted stock units (RSUs) to certain officers and key employees of the Company. The fair value of the RSUs is based on the price of our common stock as reported on the NASDAQ Global Market on the grant dates. Typically, these grants vest over a three-year period from the date of issuance and are a blend of time-based and performance-based shares. The portion of the grant that is time-based typically vests over a three-year period on each anniversary of the grant date, based on continued employment. The performance-based shares vest based on the three-year earnings performance of the Company following the grant date. At December 31, 2020, there were 202,836 RSUs outstanding. The RSUs do not have voting rights but do receive dividend equivalents upon vesting. Additionally, the shares of common stock underlying the RSUs are not considered issued and outstanding until vested and common stock is issued.

[0000080420-21-000013:notes:81]
Total RSU activity (number of shares) for the three months ended December 31, 2020 is summarized below:

[0000080420-21-000013:notes:82]
|  | Number ofRestrictedStockUnits |  | WeightedAverageGrant ValuePer Share |
| Outstanding at September 30, 2020 | 154,034 |  |  | $ | 35.37 |  |
| Granted | 104,550 |  |  | 24.08 |  |
| Vested | (55,748) |  |  | 32.50 |  |
| Forfeited/canceled | — |  |  | — |  |
| Outstanding at December 31, 2020 | 202,836 |  |  | $ | 30.34 |  |

[0000080420-21-000013:notes:83]
During the three months ended December 31, 2020 and 2019, we recorded compensation expense of $0.8 million and $0.9 million, respectively, related to the RSUs.

[0000080420-21-000013:notes:84]
Restricted Stock
Each non-employee director receives 2,400 restricted shares of the Company’s common stock annually. Fifty-percent of the restricted stock granted to each of our non-employee directors vests immediately, while the remaining fifty-percent vests on the anniversary of the grant date. Compensation expense is recognized immediately for the first fifty-percent of the restricted stock granted, while compensation expense for the remaining fifty-percent is recognized over the remaining vesting period. During the three months ended December 31, 2020 and 2019, there were no restricted shares granted. During both the three months ended December 31, 2020 and 2019, we recorded compensation expense of $0.1 million related to restricted stock.


## us-gaap:FairValueDisclosuresTextBlock

[0000080420-21-000013:notes:85]
Fair Value Measurements
We measure certain financial assets and liabilities at fair value. Fair value is defined as an “exit price,” which represents the amount that would be received to sell an asset or paid to transfer a liability in an orderly transaction between market participants as of the measurement date. As such, fair value is a market-based measurement that should be determined based on assumptions that market participants would use in valuing an asset or liability. The accounting guidance requires the use of valuation techniques to measure fair value that maximize the use of observable inputs and minimize the use of unobservable inputs. As a basis for considering such assumptions and inputs, a fair value hierarchy has been established which identifies and prioritizes three levels of inputs to be used in measuring fair value.

[0000080420-21-000013:notes:86]
[same as prior period, unchanged from 0000080420-20-000027:notes:86]

[0000080420-21-000013:notes:87]
[same as prior period, unchanged from 0000080420-20-000027:notes:87]

[0000080420-21-000013:notes:88]
[same as prior period, unchanged from 0000080420-20-000027:notes:88]

[0000080420-21-000013:notes:89]
[same as prior period, unchanged from 0000080420-20-000027:notes:89]

[0000080420-21-000013:notes:90]
The following table summarizes the fair value of our assets and liabilities that were accounted for at fair value on a recurring basis as of December 31, 2020 (in thousands):

[0000080420-21-000013:notes:91]
|  | Fair Value Measurements at December 31, 2020 |
|  | Quoted Prices inActive Markets forIdentical Assets(Level 1) |  | Significant OtherObservableInputs(Level 2) |  | SignificantUnobservableInputs(Level 3) |  | Fair Value at December 31,2020 |
| Assets: |  |  |  |  |  |  |  |
| Cash and cash equivalents | $ | 134,016 |  |  | $ | — |  |  | $ | — |  |  | $ | 134,016 |  |
| Short-term investments | 15,694 |  |  | — |  |  | — |  |  | 15,694 |  |
| Other assets | — |  |  | 8,098 |  |  | — |  |  | 8,098 |  |
| Liabilities: |  |  |  |  |  |  |  |
| Deferred compensation | — |  |  | 8,070 |  |  | — |  |  | 8,070 |  |

[0000080420-21-000013:notes:92]
The following table summarizes the fair value of our assets and liabilities that were accounted for at fair value on a recurring basis as of September 30, 2020 (in thousands):

[0000080420-21-000013:notes:93]
|  | Fair Value Measurements at September 30, 2020 |
|  | Quoted Prices inActive Markets forIdentical Assets(Level 1) |  | Significant OtherObservableInputs(Level 2) |  | SignificantUnobservableInputs(Level 3) |  | Fair Value at September 30,2020 |
| Assets: |  |  |  |  |  |  |  |
| Cash and cash equivalents | $ | 160,216 |  |  | $ | — |  |  | $ | — |  |  | $ | 160,216 |  |
| Short-term investments | 18,075 |  |  | — |  |  | — |  |  | 18,075 |  |
| Other assets | — |  |  | 7,351 |  |  | — |  |  | 7,351 |  |
| Liabilities: |  |  |  |  |  |  |  |
| Deferred compensation | — |  |  | 6,569 |  |  | — |  |  | 6,569 |  |

[0000080420-21-000013:notes:94]
[same as prior period, unchanged from 0000080420-20-000027:notes:94]

[0000080420-21-000013:notes:95]
[same as prior period, unchanged from 0000080420-20-000027:notes:95]

[0000080420-21-000013:notes:96]
[same as prior period, unchanged from 0000080420-20-000027:notes:96]

[0000080420-21-000013:notes:97]
Other Assets and Deferred Compensation – We hold investments in an irrevocable Rabbi Trust for our deferred compensation plan. The assets are primarily related to company-owned life insurance policies and are included in other assets in the accompanying Condensed Consolidated Balance Sheets. Because the mutual funds and company-owned life insurance policies are combined in the plan, they are categorized as Level 2 in the fair value measurement hierarchy. The deferred compensation liability represents the investment options that the plan participants have designated to serve as the basis for measurement of the notional value of their accounts. Because the deferred compensation liability is intended to offset the plan assets, it is also categorized as Level 2 in the fair value measurement hierarchy.

[0000080420-21-000013:notes:98]
There were no transfers between levels within the fair value measurement hierarchy during the quarter ended December 31, 2020.


## us-gaap:LesseeOperatingLeasesTextBlock

[0000080420-21-000013:notes:99]
Leases
Our leases consist primarily of office and manufacturing space, construction equipment and office equipment. All of our future lease obligations are related to non-cancelable operating leases. The most significant portion of our lease portfolio relates to leases of office and manufacturing facilities in Canada which we no longer occupy. We currently sublease the majority of these Canadian facilities. The following table provides a summary of lease cost components for the three months ended December 31, 2020 (in thousands):

[0000080420-21-000013:notes:100]
|  |  | Three months ended December 31, |  |  |
| Lease Cost |  | 2020 |  | 2019 |  |  |
| Operating lease cost |  | $ | 608 |  |  | $ | 628 |  |  |  |
| Less: sublease income |  | (180) |  |  | (79) |  |  |  |
| Variable lease cost(1) |  | 108 |  |  | 94 |  |  |  |
| Short-term lease cost(2) |  | 169 |  |  | 190 |  |  |  |
| Total lease cost |  | $ | 705 |  |  | $ | 833 |  |  |  |

[0000080420-21-000013:notes:101]
(1) Variable lease cost represents common area maintenance charges related to our Canadian office space lease.

[0000080420-21-000013:notes:102]
[same as prior period, unchanged from 0000080420-20-000027:notes:103]

[0000080420-21-000013:notes:103]
We recognize operating lease assets and operating lease liabilities representing the present value of the remaining lease payments for leases with initial terms greater than twelve months. Leases with initial terms of twelve months or less are not recorded in our Condensed Consolidated Balance Sheets. Our operating lease assets have been reduced by a lease accrual of $0.5 million related to certain unused facility leases in Canada. The following table provides a summary of the operating lease assets and operating lease liabilities included in our Condensed Consolidated Balance Sheets as of December 31, 2020 (in thousands):

[0000080420-21-000013:notes:104]
| Operating Leases |  | December 31, 2020 |  | September 30, 2020 |
| Assets: |  |  |  |  |
| Operating lease assets, net |  | $ | 4,711 |  |  | $ | 5,217 |  |
| Liabilities: |  |  |  |  |
| Current operating lease liabilities |  | 2,154 |  |  | 2,352 |  |
| Long-term operating lease liabilities |  | 3,075 |  |  | 3,434 |  |
| Total lease liabilities |  | $ | 5,229 |  |  | $ | 5,786 |  |

[0000080420-21-000013:notes:105]
The following table provides the maturities of our operating lease liabilities as of December 31, 2020 (in thousands):

[0000080420-21-000013:notes:106]
|  |  | Operating Leases |  |  |
| Remainder of 2021 |  | $ | 1,859 |  |  |  |
| 2022 |  | 2,302 |  |  |  |
| 2023 |  | 1,233 |  |  |  |
| 2024 |  | 86 |  |  |  |
| 2025 |  | — |  |  |  |
| Thereafter |  | — |  |  |  |
| Total future minimum lease payments |  | 5,480 |  |  |  |
| Less: present value discount (imputed interest) |  | (251) |  |  |  |
| Present value of lease liabilities |  | $ | 5,229 |  |  |  |

[0000080420-21-000013:notes:107]
The weighted average discount rate as of December 31, 2020 was 4.17%. The weighted average remaining lease term was 2.3 years at December 31, 2020.


## us-gaap:IncomeTaxDisclosureTextBlock

[0000080420-21-000013:notes:108]
[same as prior period, unchanged from 0000080420-20-000027:notes:109]

[0000080420-21-000013:notes:109]
|  | Three months ended December 31, |  |  |
|  | 2020 |  | 2019 |  |  |  |  |
| Income (loss) before income taxes | $ | (259) |  |  | $ | 3,333 |  |  |  |  |  |
| Income tax provision | 105 |  |  | 558 |  |  |  |  |  |
| Net income (loss) | $ | (364) |  |  | $ | 2,775 |  |  |  |  |  |
| Effective tax rate | (41) | % |  | 17 | % |  |  |  |  |

[0000080420-21-000013:notes:110]
Our income tax provision reflects an effective tax rate on pre-tax income (loss) of negative 41% for the first quarter of Fiscal 2021 compared to 17% in the first quarter of Fiscal 2020. For the three months ended December 31, 2020, the income tax provision was negatively impacted by losses recognized in various foreign jurisdictions that were reserved with a valuation allowance as well as discrete items in the amount of $0.1 million primarily related to the vesting of restricted stock units. The income tax provision was partially offset by the estimated Research and Development Tax Credit and the projected utilization of net operating loss carryforwards in Canada that were fully reserved with a valuation allowance for the three months ended December 31, 2020 and 2019. There were no material discrete items recognized in the first quarter of Fiscal 2020.


## us-gaap:SubsequentEventsTextBlock

[0000080420-21-000013:notes:111]
Subsequent Events
Quarterly Dividend Declared

[0000080420-21-000013:notes:112]
On February 2, 2021, our Board of Directors declared a quarterly cash dividend on our common stock in the amount of $0.26 per share. The dividend is payable on March 17, 2021 to shareholders of record at the close of business on February 17, 2021.
