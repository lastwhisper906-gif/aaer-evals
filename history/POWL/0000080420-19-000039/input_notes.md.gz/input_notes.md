# POWL notes — 0000080420-19-000039


## powl:ScheduleofLeaseExpenseandSubleaseIncomeTableTextBlock

[0000080420-19-000039:notes:1]
Lease expense and sublease income from third parties was as follows (in thousands):

[0000080420-19-000039:notes:2]
|  | Year Ended September 30, |
|  | 2019 |  | 2018 |  | 2017 |
| Lease expense | $ | 3,493 |  |  | $ | 3,432 |  |  | $ | 3,734 |  |
| Sublease income from third parties | (1,280 | ) |  | (1,487 | ) |  | (1,389 | ) |


## us-gaap:AllowanceForCreditLossesOnFinancingReceivablesTableTextBlock

[0000080420-19-000039:notes:3]
Activity in our allowance for doubtful accounts consisted of the following (in thousands):

[0000080420-19-000039:notes:4]
|  | September 30, |
|  | 2019 |  | 2018 |
| Balance at beginning of period | $ | 157 |  |  | $ | 179 |  |
| Bad debt expense | 233 |  |  | 111 |  |
| Uncollectible accounts written off, net of recoveries | (81 | ) |  | (125 | ) |
| Change due to foreign currency translation | (8 | ) |  | (8 | ) |
| Balance at end of period | $ | 301 |  |  | $ | 157 |  |


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0000080420-19-000039:notes:5]
Commitments and Contingencies

[0000080420-19-000039:notes:6]
Leases

[0000080420-19-000039:notes:7]
We lease certain offices, facilities and equipment under operating leases expiring at various dates through 2023. We also sublease certain facilities that we are no longer occupying. Our sublease terms do not fully cover the existing rental commitments on certain facilities.

[0000080420-19-000039:notes:8]
At September 30, 2019, the future minimum annual rental commitments and expected receipts under non-cancelable operating leases having terms in excess of one year were as follows (in thousands):

[0000080420-19-000039:notes:9]
| Years Ended September 30, | Operating Leases Payments |  | Operating Sublease Income |
| 2020 | $ | 3,040 |  |  | $ | (877 | ) |
| 2021 | 2,859 |  |  | (1,028 | ) |
| 2022 | 2,612 |  |  | (1,159 | ) |
| 2023 | 1,508 |  |  | (943 | ) |
| 2024 | 85 |  |  | — |  |
| Thereafter | — |  |  | — |  |
| Total lease commitments | $ | 10,104 |  |  | $ | (4,007 | ) |

[0000080420-19-000039:notes:10]
In Fiscal 2019, we recorded additional lease expense of $0.7 million related to certain facility leases in Canada that are no longer utilized in our operations. In Fiscal 2018, we incurred approximately $0.8 million due to anticipated losses on the sublet of a Canadian facility we exited in a prior period.

[0000080420-19-000039:notes:11]
Letters of Credit, Bank Guarantees and Bonds

[0000080420-19-000039:notes:12]
Certain customers require us to post letters of credit, bank guarantees or surety bonds. These security instruments assure that we will perform under the terms of our contract. In the event of default, the counterparty may demand payment from the bank under a letter of credit or bank guarantee, or performance by the surety under a bond. To date, there have been no significant expenses related to security instruments for the periods reported. We were contingently liable for letters of credit of $13.4 million as of September 30, 2019. We also had outstanding surety bonds totaling $170.5 million, with additional bonding capacity of $579.5 million available, at September 30, 2019.

[0000080420-19-000039:notes:13]
We have an $11.1 million facility agreement (Facility Agreement) between Powell (UK) Limited and a large international bank that provides Powell (UK) Limited the ability to enter into bank guarantees as well as forward exchange contracts and currency options. At September 30, 2019, we had outstanding guarantees totaling $5.7 million and amounts available under this Facility Agreement were $5.4 million. The Facility Agreement expires in May 2020 and provides for financial covenants and customary events of default, and carries cross-default provisions with our U.S. Revolver. If an event of default (as defined in the Facility Agreement) occurs and is continuing, per the terms and subject to the conditions set forth therein, obligations outstanding under the Facility Agreement may be accelerated and may become or be declared immediately due and payable. As of September 30, 2019, we were in compliance with all of the financial covenants of the Facility Agreement.

[0000080420-19-000039:notes:14]
Litigation

[0000080420-19-000039:notes:15]
We are involved in various legal proceedings, claims and other disputes arising from our commercial operations, projects, employees and other matters which, in general, are subject to uncertainties and in which the outcomes are not predictable. Although we can give no assurances about the resolution of pending claims, litigation or other disputes and the effect such outcomes may have on us, management believes that any ultimate liability resulting from the outcome of such proceedings, to the extent not otherwise provided or covered by insurance, will not have a material adverse effect on our consolidated financial position or results of operations or liquidity.

[0000080420-19-000039:notes:16]
Liquidated Damages

[0000080420-19-000039:notes:17]
Certain of our customer contracts have schedule and performance obligation clauses that, if we fail to meet them, could require us to pay liquidated damages. Each individual contract defines the conditions under which the customer may make a claim against us. As of September 30, 2019, our exposure to possible liquidated damages was $2.0 million, of which approximately $0.9 million was probable. Based on our actual or projected failure to meet these various contractual commitments, $0.8 million has been recorded as a reduction to revenue. We will attempt to obtain change orders, contract extensions or accelerate project completion, which may resolve the potential for any unrecorded liquidated damage. Should we fail to achieve relief on some or all of these contractual obligations, we could be required to pay additional liquidated damages, which could negatively impact our future operating results.


## us-gaap:ConsolidationPolicyTextBlock

[0000080420-19-000039:notes:18]
Principles of Consolidation

[0000080420-19-000039:notes:19]
The consolidated financial statements include the accounts of Powell and our wholly owned subsidiaries. All intercompany accounts and transactions have been eliminated in consolidation.


## us-gaap:ContractWithCustomerAssetAndLiabilityTableTextBlock

[0000080420-19-000039:notes:20]
Contract assets and liabilities as of September 30, 2019 and September 30, 2018 are summarized below (in thousands):

[0000080420-19-000039:notes:21]
|  | September 30, |
|  | 2019 |  | 2018 |
| Contract assets | $ | 55,374 |  |  | $ | 82,545 |  |
| Contract liabilities | (71,464 | ) |  | (43,174 | ) |
| Net contract asset (liability) | $ | (16,090 | ) |  | $ | 39,371 |  |


## us-gaap:DisaggregationOfRevenueTableTextBlock

[0000080420-19-000039:notes:22]
The following tables present our disaggregated revenue by geographic destination and market sector for the year ended September 30, 2019 (in thousands):

[0000080420-19-000039:notes:23]
|  | 2019 |
| United States | $ | 406,609 |  |
| Canada | 64,326 |  |
| Europe, Middle East and Africa | 32,166 |  |
| Asia/Pacific | 11,405 |  |
| Mexico, Central and South America | 2,674 |  |
| Total revenues by geographic destination | $ | 517,180 |  |

[0000080420-19-000039:notes:24]
|  | 2019 |
| Oil and gas | $ | 242,291 |  |
| Petrochemical | 93,391 |  |
| Electric utility | 84,993 |  |
| Traction power | 26,781 |  |
| All others | 69,724 |  |
| Total revenues by market sector | $ | 517,180 |  |


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0000080420-19-000039:notes:25]
Stock-Based Compensation

[0000080420-19-000039:notes:26]
We have the following stock-based compensation plans:

[0000080420-19-000039:notes:27]
2014 Equity Incentive Plan

[0000080420-19-000039:notes:28]
In February 2014, our stockholders approved and adopted at the Annual Meeting of Stockholders the 2014 Equity Incentive Plan (the 2014 Plan), which replaced our 2006 Equity Compensation Plan (2006 Plan). Persons eligible to receive awards under the 2014 Plan include our officers and employees. The 2014 Plan authorizes stock options, stock appreciation rights, restricted stock, restricted stock units and performance-based awards, as well as certain other awards.

[0000080420-19-000039:notes:29]
In accordance with the 2014 Plan, the compensation committee has authorized grants of restricted stock units (RSUs) to certain officers and key employees of the company. The fair value of the RSUs is based on the closing price of our common stock as reported on the NASDAQ Global Market on the grant dates. Typically, these grants vest over a three-year period from their date of issuance. Fifty to sixty percent of the grant is time-based and vests over a three-year period on each anniversary of the grant date, based on continued employment. The remaining forty to fifty percent of the grant is earned based on the three-year earnings performance of the Company following the grant date. At September 30, 2019, there were 131,850 RSUs outstanding. The RSUs do not have voting rights but receive dividend equivalents upon vesting. Additionally, the shares of common stock underlying the RSUs are not considered issued and outstanding until vested and common stock is issued.

[0000080420-19-000039:notes:30]
Total RSU activity (number of shares) for the past fiscal year is summarized below:

[0000080420-19-000039:notes:31]
|  | Number ofRestrictedStockUnits |  | WeightedAverageGrant ValuePer Share |
| Outstanding at September 30, 2018 | 190,500 |  |  | $ | 33.73 |  |
| Granted | 77,150 |  |  | 34.89 |  |
| Vested | (117,684 | ) |  | 33.57 |  |
| Forfeited/cancelled | (18,116 | ) |  | 33.75 |  |
| Outstanding at September 30, 2019 | 131,850 |  |  | $ | 33.76 |  |

[0000080420-19-000039:notes:32]
We have reserved 750,000 shares of common stock for issuance under the 2014 Plan. As of September 30, 2019, there were 554,801 shares of common stock available for future grants.

[0000080420-19-000039:notes:33]
2014 Non-Employee Director Equity Incentive Plan

[0000080420-19-000039:notes:34]
In February 2014, our stockholders approved the 2014 Non-Employee Director Equity Incentive Plan (the 2014 Director Plan). The total number of shares of common stock reserved under the plan is 150,000 shares. The plan is administered by the compensation committee. Eligibility to participate in the plan is limited to those individuals who are members of the Board of Directors of the Company and who are not employees of the Company or any affiliate of the Company.

[0000080420-19-000039:notes:35]
Under the terms of the 2014 Director Plan, the maximum number of shares that may be granted during any calendar year to any individual is 12,000 shares. The total number of shares that may be issued for awards to any single participant during a calendar year for other stock-based awards (excluding stock options and SARs) is 4,000 shares. The Compensation Committee has determined that each non-employee director will receive 2,000 restricted shares of the Company’s common stock annually. Fifty percent of the restricted stock granted to each of our non-employee directors vests immediately, while the remaining fifty percent vests on the anniversary of the grant date. Compensation expense is based on the closing share price on the grant date and recognized immediately for the first fifty percent of the restricted stock granted, while compensation expense for the remaining fifty percent will be recognized over the remaining vesting period.

[0000080420-19-000039:notes:36]
Under this 2014 Director Plan, in February 2019, 7,000 shares of common stock and 7,000 shares of restricted stock were issued to our non-employee directors at a price of $34.02 per share. In February 2018, we issued 6,000 shares of restricted stock to our non-employee directors at a price of $27.88 per share, and in April 2018, we issued 1,000 shares of restricted stock to a single non-employee director at a price of $27.15. The total number of shares of common stock available for future awards under the 2014 Director plan was 56,600 shares as of September 30, 2019.

[0000080420-19-000039:notes:37]
At both September 30, 2019 and 2018, there were 7,000 shares of unvested restricted stock outstanding. Total compensation expense related to restricted stock grants under all plans was $0.5 million, $0.5 million and $0.7 million for the years ended September 30, 2019, 2018 and 2017, respectively. Total compensation expense related to RSUs under all plans was $3.3 million, $2.7 million and $2.0 million for the years ended September 30, 2019, 2018 and 2017, respectively.

[0000080420-19-000039:notes:38]
We record the amortization of non-vested restricted stock and restricted stock units as an increase to additional paid-in capital. As of September 30, 2019 and 2018, amounts of deferred compensation expense not yet recognized related to non-vested stock and RSUs totaled $1.0 million and $1.2 million, respectively. As of September 30, 2019, the total weighted average remaining contractual life of our non-vested restricted stock and RSUs is approximately six months and 1.4 years, respectively.


## us-gaap:EarningsPerShareTextBlock

[0000080420-19-000039:notes:39]
Earnings Per Share

[0000080420-19-000039:notes:40]
We compute basic earnings per share by dividing net income (loss) by the weighted average number of common shares outstanding during the period. Diluted earnings per common and potential common share includes the weighted average of additional shares associated with the incremental effect of dilutive restricted stock and restricted stock units, as prescribed by the FASB guidance on earnings per share.

[0000080420-19-000039:notes:41]
The following table reconciles basic and diluted weighted average shares used in the computation of earnings per share (in thousands, except per share data):

[0000080420-19-000039:notes:42]
|  | Year Ended September 30, |
|  | 2019 |  | 2018 |  | 2017 |
| Numerator: |  |  |  |  |  |
| Net income (loss) | $ | 9,890 |  |  | $ | (7,152 | ) |  | $ | (9,486 | ) |
| Denominator: |  |  |  |  |  |
| Weighted average basic shares | 11,571 |  |  | 11,507 |  |  | 11,453 |  |
| Dilutive effect of restricted stock units | 63 |  |  | — |  |  | — |  |
| Weighted average diluted shares with assumed conversions | 11,634 |  |  | 11,507 |  |  | 11,453 |  |
| Earnings (loss) per share: |  |  |  |  |  |
| Basic | $ | 0.85 |  |  | $ | (0.62 | ) |  | $ | (0.83 | ) |
| Diluted | $ | 0.85 |  |  | $ | (0.62 | ) |  | $ | (0.83 | ) |

[0000080420-19-000039:notes:43]
For the years ended September 30, 2018 and 2017, we incurred net losses; therefore, all potential common shares were deemed to be anti-dilutive.


## us-gaap:FairValueDisclosuresTextBlock

[0000080420-19-000039:notes:44]
Fair Value Measurements

[0000080420-19-000039:notes:45]
We measure certain financial assets and liabilities at fair value. Fair value is defined as an “exit price,” which represents the amount that would be received to sell an asset or paid to transfer a liability in an orderly transaction between market participants as of the measurement date. As such, fair value is a market-based measurement that should be determined based on assumptions that market participants would use in valuing an asset or liability. The accounting guidance requires the use of valuation techniques to measure fair value that maximize the use of observable inputs and minimize the use of unobservable inputs. As a basis for considering such assumptions and inputs, a fair value hierarchy has been established that identifies and prioritizes three levels of inputs to be used in measuring fair value.

[0000080420-19-000039:notes:46]
The three levels of the fair value hierarchy are as follows:

[0000080420-19-000039:notes:47]
Level 1 — Observable inputs such as quoted prices (unadjusted) in active markets for identical assets or liabilities.

[0000080420-19-000039:notes:48]
Level 2 — Inputs other than the quoted prices in active markets that are observable either directly or indirectly, including: quoted prices for similar assets and liabilities in active markets; quoted prices for identical or similar assets and liabilities in markets that are not active or other inputs that are observable or can be corroborated by observable market data.

[0000080420-19-000039:notes:49]
Level 3 — Unobservable inputs that are supported by little or no market data and require the reporting entity to develop its own assumptions.

[0000080420-19-000039:notes:50]
The following table summarizes the fair value of our assets and liabilities that were accounted for at fair value on a recurring basis as of September 30, 2019 (in thousands):

[0000080420-19-000039:notes:51]
|  | Fair Value Measurements at September 30, 2019 |
|  | Quoted Prices inActive Markets forIdentical Assets(Level 1) |  | Significant OtherObservableInputs(Level 2) |  | SignificantUnobservableInputs(Level 3) |  | Fair Value at September 30, 2019 |
| Assets: |  |  |  |  |  |  |  |
| Cash and cash equivalents | $ | 118,639 |  |  | $ | — |  |  | $ | — |  |  | $ | 118,639 |  |
| Short-term investments | 6,042 |  |  | — |  |  | — |  |  | 6,042 |  |
| Other assets | — |  |  | 6,825 |  |  | — |  |  | 6,825 |  |
| Liabilities: |  |  |  |  |  |  |  |
| Deferred compensation | — |  |  | 6,249 |  |  | — |  |  | 6,249 |  |

[0000080420-19-000039:notes:52]
The following table summarizes the fair value of our assets and liabilities that were accounted for at fair value on a recurring basis as of September 30, 2018 (in thousands):

[0000080420-19-000039:notes:53]
|  | Fair Value Measurements at September 30, 2018 |
|  | Quoted Prices inActive Markets forIdentical Assets(Level 1) |  | Significant OtherObservableInputs(Level 2) |  | SignificantUnobservableInputs(Level 3) |  | Fair Value at September 30, 2018 |
| Assets: |  |  |  |  |  |  |  |
| Cash and cash equivalents | $ | 36,584 |  |  | $ | — |  |  | $ | — |  |  | $ | 36,584 |  |
| Short-term investments | 13,170 |  |  | — |  |  | — |  |  | 13,170 |  |
| Restricted cash | 25,141 |  |  | — |  |  | — |  |  | 25,141 |  |
| Other assets | — |  |  | 6,817 |  |  | — |  |  | 6,817 |  |
| Liabilities: |  |  |  |  |  |  |  |
| Deferred compensation | — |  |  | 5,644 |  |  | — |  |  | 5,644 |  |

[0000080420-19-000039:notes:54]
Fair value guidance requires certain fair value disclosures be presented in both interim and annual reports. The estimated fair value amounts of financial instruments have been determined using available market information and valuation methodologies described below.

[0000080420-19-000039:notes:55]
Cash and cash equivalents

[0000080420-19-000039:notes:56]
Cash and cash equivalents, primarily funds held in money market savings instruments, are reported at their current carrying value, which approximates fair value due to the short-term nature of these instruments and are included in cash and cash equivalents in our Consolidated Balance Sheets.

[0000080420-19-000039:notes:57]
Short-term Investments - Short-term investments include time deposits with original maturities of three months or more.

[0000080420-19-000039:notes:58]
Restricted Cash - Restricted cash represented a pledged cash collateral balance, which was required under our prior credit agreement and was held in an interest-bearing savings account. See Note G for further discussion on restricted cash.

[0000080420-19-000039:notes:59]
Other Assets and Deferred Compensation – We hold investments in an irrevocable Rabbi Trust for our deferred compensation plan. The assets are primarily related to company-owned life insurance policies and are included in other assets in the accompanying Consolidated Balance Sheets. Because the mutual funds and company-owned life insurance policies are combined in the plan, they are therefore categorized as Level 2 in the fair value measurement hierarchy. The deferred compensation liability represents the investment options that the plan participants have designated to serve as the basis for measurement of the notional value of their accounts.  Because the deferred compensation liability is intended to offset the plan assets, it is therefore also categorized as Level 2 in the fair value measurement hierarchy.


## us-gaap:FairValueMeasurementPolicyPolicyTextBlock

[0000080420-19-000039:notes:60]
Fair Value of Financial Instruments

[0000080420-19-000039:notes:61]
Financial instruments include cash, cash equivalents, short-term investments, restricted cash, receivables, deferred compensation, payables and debt obligations. Except as described below, due to the short-term nature of account receivables and account payables, the book value is representative of their fair value. The carrying value of debt approximates fair value as interest rates are indexed to the Federal Funds Rate or the bank’s prime rate.


## us-gaap:ForeignCurrencyTransactionsAndTranslationsPolicyTextBlock

[0000080420-19-000039:notes:62]
Foreign Currency Translation

[0000080420-19-000039:notes:63]
The functional currency for our foreign subsidiaries is the local currency in which the entity is located. The financial statements of all subsidiaries with a functional currency other than the U.S. Dollar have been translated into U.S. Dollars. All assets and liabilities of foreign operations are translated into U.S. Dollars using year-end exchange rates, and all revenues and expenses are translated at average rates during the respective period. The U.S. Dollar results that arise from such translation, as well as exchange gains and losses on intercompany balances of a long-term investment nature, are included in the cumulative currency translation adjustments in accumulated other comprehensive loss in stockholders’ equity.


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0000080420-19-000039:notes:64]
Goodwill and Intangible Assets

[0000080420-19-000039:notes:65]
Our intangible assets consist of goodwill of $1.0 million, which is not being amortized, and purchased technology of $0.3 million, which is amortized over its estimated useful life. No impairment expense has been recorded for the last three fiscal years.

[0000080420-19-000039:notes:66]
Intangible assets balances, subject to amortization, at September 30, 2019 and 2018 consisted of the following (in thousands):

[0000080420-19-000039:notes:67]
|  | September 30, 2019 |  | September 30, 2018 |
|  | GrossCarryingValue |  | AccumulatedAmortization |  | NetCarryingValue |  | GrossCarryingValue |  | AccumulatedAmortization |  | NetCarryingValue |
| Purchased technology | $ | 11,749 |  |  | $ | (11,415 | ) |  | $ | 334 |  |  | $ | 11,749 |  |  | $ | (11,239 | ) |  | $ | 510 |  |

[0000080420-19-000039:notes:68]
Amortization of intangible assets recorded for the years ended September 30, 2019, 2018 and 2017 was $0.2 million, $0.2 million and $0.4 million, respectively.

[0000080420-19-000039:notes:69]
Estimated amortization expense for each of the five subsequent fiscal years is expected to be (in thousands):

[0000080420-19-000039:notes:70]
| Years Ended September 30, | Total |
| 2020 | $ | 177 |  |
| 2021 | 157 |  |
| 2022 | — |  |
| 2023 | — |  |
| 2024 | — |  |

[0000080420-19-000039:notes:71]
On August 7, 2006, we purchased certain assets related to the manufacturing of ANSI medium-voltage switchgear and circuit breaker business from General Electric Company (GE). In connection with the acquisition, we entered into a 15-year supply agreement with GE pursuant to which GE would purchase from us all of its requirements for ANSI medium-voltage switchgear and circuit breakers and other related equipment and components (the Products). We recorded an intangible asset related to this supply agreement. On December 30, 2013, we and GE amended the supply agreement to allow GE to manufacture similar Products for sale immediately and allow them to begin purchasing Products from other suppliers beginning December 31, 2014. In return, GE paid us $10 million upon execution of the amended supply agreement and agreed to pay an additional $7 million over three years, beginning March 2015. The final balance of $2.3 million was received in April 2017. We wrote off the intangible asset related to the original supply agreement and recorded a deferred credit in the amount of $8.1 million at December 31, 2013, the amount by which the total proceeds from GE exceeded the unamortized balance of our intangible asset. We amortized this deferred credit over the four-year life of the agreement and recorded $0.5 million in other income in Fiscal 2018, and $2.0 million in both Fiscal 2017 and 2016.


## us-gaap:IncomeTaxDisclosureTextBlock

[0000080420-19-000039:notes:72]
Income Taxes

[0000080420-19-000039:notes:73]
The components of the income tax provision (benefit) were as follows (in thousands):

[0000080420-19-000039:notes:74]
|  | Year Ended September 30, |
|  | 2019 |  | 2018 |  | 2017 |
| Current: |  |  |  |  |  |
| Federal | $ | 1,350 |  |  | $ | 973 |  |  | $ | (7,782 | ) |
| State | 186 |  |  | 201 |  |  | (101 | ) |
| Foreign | 88 |  |  | 449 |  |  | 350 |  |
|  | 1,624 |  |  | 1,623 |  |  | (7,533 | ) |
| Deferred: |  |  |  |  |  |  |  |  |
| Federal | 366 |  |  | (1,834 | ) |  | 392 |  |
| State | 457 |  |  | (247 | ) |  | (515 | ) |
| Foreign | (3 | ) |  | (89 | ) |  | 223 |  |
|  | 820 |  |  | (2,170 | ) |  | 100 |  |
| Total income tax provision (benefit) | $ | 2,444 |  |  | $ | (547 | ) |  | $ | (7,433 | ) |

[0000080420-19-000039:notes:75]
Income (loss) before income taxes was as follows (in thousands):

[0000080420-19-000039:notes:76]
|  | Year Ended September 30, |
|  | 2019 |  | 2018 |  | 2017 |
| U.S. | $ | 11,859 |  |  | $ | (2,103 | ) |  | $ | (19,932 | ) |
| Other than U.S. | 475 |  |  | (5,596 | ) |  | 3,013 |  |
| Income (loss) before income taxes | $ | 12,334 |  |  | $ | (7,699 | ) |  | $ | (16,919 | ) |

[0000080420-19-000039:notes:77]
A reconciliation of the statutory U.S. income tax rate and the effective income tax rate, as computed on earnings before income tax provision in each of the three years presented in the Consolidated Statements of Operations, was as follows:

[0000080420-19-000039:notes:78]
|  | Year Ended September 30, |
|  | 2019 |  | 2018 |  | 2017 |
| Statutory rate | 21 | % |  | 25 | % |  | 35 | % |
| State income taxes, net of federal benefit | 4 |  |  | (2 | ) |  | 2 |  |
| Research and development credit | (7 | ) |  | 9 |  |  | 9 |  |
| Foreign rate differential | 1 |  |  | 1 |  |  | 2 |  |
| Foreign withholding | 1 |  |  | (3 | ) |  | — |  |
| Foreign valuation allowance | (2 | ) |  | (20 | ) |  | 2 |  |
| NOL carryback impact on deductions | — |  |  | — |  |  | (4 | ) |
| Deferred tax rate differential | — |  |  | (4 | ) |  | — |  |
| Other | 2 |  |  | 1 |  |  | (2 | ) |
| Effective rate | 20 | % |  | 7 | % |  | 44 | % |

[0000080420-19-000039:notes:79]
On December 22, 2017, the new tax law lowered the corporate tax rate from 35% to 21% effective January 1, 2018. As a result, the U.S. federal statutory rate for Fiscal 2019 is 21%, compared to the blended statutory rate of 24.5% effective for Fiscal 2018.

[0000080420-19-000039:notes:80]
Our income tax provision (benefit) reflects an effective tax rate on pre-tax results of 20% in Fiscal 2019 compared to 7% and 44% in Fiscal 2018 and 2017, respectively. The effective rate for Fiscal 2019 approximated the U.S. federal statutory rate as favorable adjustments related to the utilization of net operating loss carryforwards in Canada that were fully reserved with a valuation allowance and the Research and Development Tax Credit (R&D Tax Credit) were largely offset by unfavorable adjustments primarily related to state income taxes and other permanent items. Due to the loss position in Fiscal 2018, the effective tax rate was negatively impacted by foreign losses reserved for with a valuation allowance as well as $0.5 million of tax expense related to the re-measurement of U.S. deferred tax assets as a result of tax reform. Likewise, due to the loss in Fiscal 2017, the effective tax rate was favorably impacted by the relative amounts of income/loss recognized in the various tax jurisdictions, the utilization of net operating loss carryforwards in Canada that have been fully reserved with a valuation allowance, the lower tax rate in the U.K., as well as $0.9 million of discrete items recognized during the year, primarily related to the R&D Tax Credit.

[0000080420-19-000039:notes:81]
We have not recorded deferred income taxes on $19.4 million of undistributed earnings of our foreign subsidiaries because of management’s intent to indefinitely reinvest such earnings. Upon distribution of these earnings in the form of dividends or otherwise, we may be subject to U.S. income taxes and foreign withholding taxes. It is not practical, however, to estimate the amount of taxes that may be payable on the eventual remittance of these earnings.

[0000080420-19-000039:notes:82]
We are subject to income tax in the U.S., multiple state jurisdictions and certain international jurisdictions, primarily the U.K. and Canada. We do not consider any state in which we do business to be a major tax jurisdiction. We remain open to examination in the other jurisdictions as follows:  Canada 2012 – 2018, United Kingdom 2017 – 2018 and the United States 2013 – 2018. As of September 30, 2019, we did not have any state audits underway that would have a material impact on our financial position or results of operations.

[0000080420-19-000039:notes:83]
The net deferred income tax asset was comprised of the following (in thousands):

[0000080420-19-000039:notes:84]
|  | September 30, |
|  | 2019 |  | 2018 |
| Gross assets | $ | 18,486 |  |  | $ | 22,480 |  |
| Gross liabilities and valuation allowance | (13,369 | ) |  | (16,543 | ) |
| Net deferred income tax asset | $ | 5,117 |  |  | $ | 5,937 |  |

[0000080420-19-000039:notes:85]
The tax effect of temporary differences between U.S. GAAP accounting and federal income tax accounting creating deferred income tax assets and liabilities was as follows (in thousands):

[0000080420-19-000039:notes:86]
|  | September 30, |
|  | 2019 |  | 2018 |
| Deferred Tax Assets: |  |  |  |
| Net operating loss | $ | 10,636 |  |  | $ | 13,444 |  |
| Credit carryforwards | 2,895 |  |  | 3,987 |  |
| Deferred compensation | 1,590 |  |  | 1,456 |  |
| Uniform capitalization and inventory | 983 |  |  | 1,043 |  |
| Stock-based compensation | 744 |  |  | 879 |  |
| Reserve for accrued employee benefits | 752 |  |  | 791 |  |
| Warranty accrual | 341 |  |  | 448 |  |
| Accrued legal | 115 |  |  | 154 |  |
| Postretirement benefits liability | 110 |  |  | 112 |  |
| Goodwill | 44 |  |  | 54 |  |
| Other | 276 |  |  | 112 |  |
| Deferred tax assets | 18,486 |  |  | 22,480 |  |
| Deferred Tax Liabilities: |  |  |  |  |  |
| Depreciation and amortization | (5,138 | ) |  | (6,946 | ) |
| Deferred tax liabilities | (5,138 | ) |  | (6,946 | ) |
| Less: valuation allowance | (8,231 | ) |  | (9,597 | ) |
| Net deferred tax asset | $ | 5,117 |  |  | $ | 5,937 |  |

[0000080420-19-000039:notes:87]
As of September 30, 2019, we had tax credit carryforwards of $2.0 million not reserved with a valuation allowance that are available to reduce future U.S. federal tax liabilities. The majority of these tax credit carryforwards expire beginning in 2037. In addition, we had international net operating loss carryforwards of $2.9 million that were not reserved with a valuation allowance available to offset future taxable income in the respective jurisdictions, with less than 10% expiring in 2029 and the remainder having an indefinite carryforward period.

[0000080420-19-000039:notes:88]
We have established a valuation allowance in the amount of $8.2 million primarily related to the Canadian net deferred tax assets. In assessing the realizability of net deferred tax assets, we consider whether it is more likely than not that some portion or all of the net deferred tax assets may not be realized. The ultimate realization of net deferred tax assets is dependent on the generation of future taxable income during the periods in which those temporary differences become deductible.

[0000080420-19-000039:notes:89]
A rollforward of the valuation allowance for the past three years is summarized below:

[0000080420-19-000039:notes:90]
| Balance at September 30, 2016 | $ | 8,439 |  |
| Charged to cost and expenses | (260 | ) |
| Charged to other accounts | 588 |  |
| Balance at September 30, 2017 | $ | 8,767 |  |
| Charged to cost and expenses | 1,575 |  |
| Charged to other accounts | (745 | ) |
| Balance at September 30, 2018 | $ | 9,597 |  |
| Charged to cost and expenses | (209 | ) |
| Charged to other accounts | (1,157 | ) |
| Balance at September 30, 2019 | $ | 8,231 |  |

[0000080420-19-000039:notes:91]
A reconciliation of the beginning and ending amount of the unrecognized tax benefits that if recognized would affect the effective tax rate follows (in thousands):

[0000080420-19-000039:notes:92]
|  | Year Ended September 30, |
|  | 2019 |  | 2018 |  | 2017 |
| Balance at beginning of period | $ | 1,854 |  |  | $ | 1,219 |  |  | $ | 1,046 |  |
| Increases related to tax positions taken during the current period | 240 |  |  | 180 |  |  | 179 |  |
| Increases related to tax positions taken during a prior period | 609 |  |  | 455 |  |  | 338 |  |
| Decreases related to expiration of statute of limitations | — |  |  | — |  |  | — |  |
| Decreases related to settlement with taxing authorities | — |  |  | — |  |  | (344 | ) |
| Balance at end of period | $ | 2,703 |  |  | $ | 1,854 |  |  | $ | 1,219 |  |

[0000080420-19-000039:notes:93]
Our policy is to recognize interest and penalties related to income tax matters as tax expense. The amount of interest and penalty expense recorded for the year ended September 30, 2019 was not material.

[0000080420-19-000039:notes:94]
Due to the expiration of certain federal statutes of limitations and voluntary filings, management believes that, within the next 12 months, it is reasonably possible that the unrecognized tax benefits will decrease by approximately $0.9 million and would positively impact our effective tax rate. We are unable to make reasonably reliable estimates regarding the timing of future cash outflows, if any, associated with the remaining unrecognized tax benefits.

[0000080420-19-000039:notes:95]
In November 2018, we received a refund of $6.6 million related to the U.S. federal carryback claim filed for the Fiscal 2017 net operating loss. Subsequently, we were notified that the IRS would conduct a review of the carryback claim. Management believes that an adequate provision has been made for any adjustments that may result from tax examinations. However, the outcome of tax audits cannot be predicted with certainty. If any issues addressed in our tax audits are resolved in a manner not consistent with management’s expectations, we could be required to adjust our provision for income tax in the period such resolution occurs.


## us-gaap:IncomeTaxPolicyTextBlock

[0000080420-19-000039:notes:96]
We account for income taxes under the asset and liability method, based on the income tax laws and rates in the countries in which operations are conducted, and income is earned. This approach requires the recognition of deferred tax assets and liabilities for the expected future tax consequences of temporary differences between the carrying amounts and the tax basis of assets and liabilities. Developing our provision for income taxes requires significant judgment and expertise in federal, international and state income tax laws, regulations and strategies, including the determination of deferred tax assets and liabilities and, if necessary, any valuation allowances that may be required for deferred tax assets. In assessing the extent to which net deferred tax assets may be realized, we consider whether it is more likely than not that some portion or all of the net deferred tax assets may not be realized. The ultimate realization of net deferred tax assets is dependent on the generation of future taxable income during the periods in which those temporary differences become deductible. Estimates may change as new events occur, estimates of future taxable income during the carryforward period are reduced or increased, additional information becomes available or operating environments change, which may result in a full or partial reversal of the valuation allowance. We will continue to assess the adequacy of the valuation allowance on a quarterly basis. Our judgments and tax strategies are subject to audit by various taxing authorities.

[0000080420-19-000039:notes:97]
The objectives of accounting for income taxes are to recognize the amount of taxes payable or refundable for the current year and deferred tax liabilities and assets for the future tax consequences of events that have been recognized in an entity’s financial statements or tax returns. We recognize the tax benefit from an uncertain tax position only if it is more likely than not that the tax position will be sustained on examination by the taxing authorities, based on the technical merits of the position. The tax benefits recognized in the financial statements from such a position should be measured based on the largest benefit that has a greater than 50% likelihood of being realized upon ultimate settlement. Accounting literature also provides guidance on derecognition of income tax assets and liabilities, classification of current and deferred income tax assets and liabilities, accounting for interest and penalties associated with tax positions, and income tax disclosures. Judgment is required in assessing the future tax consequences of events that have been recognized in our financial statements or tax returns. Variations in the actual outcome of these future tax consequences could materially impact our financial statements.


## us-gaap:InventoryPolicyTextBlock

[0000080420-19-000039:notes:98]
Inventories

[0000080420-19-000039:notes:99]
Inventories are stated at the lower of cost or net realizable value using weighted-average methods and include the cost of materials, labor and manufacturing overhead. We use estimates in determining the level of reserves required to state inventory at the lower of cost or net realizable value. Our estimates are based on market activity levels, production requirements, the physical condition of products and technological innovation. Changes in any of these factors may result in adjustments to the carrying value of inventory.


## us-gaap:LongLivedAssetsByGeographicAreasTableTextBlock

[0000080420-19-000039:notes:100]
|  | September 30, |
|  | 2019 |  | 2018 |
| Long-lived assets: |  |  |  |
| United States | $ | 71,325 |  |  | $ | 76,016 |  |
| Canada | 44,933 |  |  | 48,126 |  |
| United Kingdom | 4,554 |  |  | 4,622 |  |
| Total | $ | 120,812 |  |  | $ | 128,764 |  |


## us-gaap:LongTermDebtTextBlock

[0000080420-19-000039:notes:101]
Long-Term Debt

[0000080420-19-000039:notes:102]
Long-term debt consisted of the following (in thousands):

[0000080420-19-000039:notes:103]
|  | September 30, |
|  | 2019 |  | 2018 |
| Industrial development revenue bonds | $ | 1,200 |  |  | $ | 1,600 |  |
| Less: current portion | (400 | ) |  | (400 | ) |
| Total long-term debt | $ | 800 |  |  | $ | 1,200 |  |

[0000080420-19-000039:notes:104]
The annual maturities of long-term debt as of September 30, 2019, were as follows (in thousands):

[0000080420-19-000039:notes:105]
| Year Ending September 30, | Long‑TermDebtMaturities |
| 2020 | $ | 400 |  |
| 2021 | 400 |  |
| 2022 | — |  |
| 2023 | — |  |
| 2024 | — |  |
| Total long-term debt maturities | $ | 800 |  |

[0000080420-19-000039:notes:106]
U.S. Revolver

[0000080420-19-000039:notes:107]
On September 27, 2019, we entered into an Amended and Restated Credit Agreement with Bank of America, N.A. (the "U.S. Revolver"), which replaced our prior credit agreement. The U.S. Revolver is a $75.0 million revolving credit facility, which is available for both borrowings and letters of credit and expires September 2024. As of September 30, 2019, there were no amounts borrowed under this facility and letters of credit outstanding were $13.4 million. As of September 30, 2019, $61.6 million was available for the issuance of letters of credit and borrowing under the U.S. Revolver. In addition, the U.S. Revolver includes a right of the Company to request from time to time an increase in the revolving line of credit of up to $50.0 million, provided that (i) no default exists, (ii) each request must be in a minimum amount of $15.0 million (or, if less, the remaining portion of the increase), (iii) the Company may make a maximum of four such requests and (iv) each lender may agree whether or not to increase its revolving commitment.

[0000080420-19-000039:notes:108]
We are required to maintain certain financial covenants, the most significant of which are a consolidated leverage ratio greater than 3.0 to 1.0 and a consolidated interest coverage ratio of less than 3.0 to 1.0. Additionally, we must maintain a consolidated cash balance of $30 million at all times. The U.S. Revolver also contains a "material adverse effect" clause which is a material change in our operations, business, properties, liabilities or condition (financial or otherwise) or a material impairment of our ability to perform our obligations under our credit agreements. As of September 30, 2019, we were in compliance with all of the financial covenants of the U.S. Revolver.

[0000080420-19-000039:notes:109]
As of September 30, 2018, the balance in the cash collateral account was $25.1 million and was recorded as restricted cash in our Consolidated Balance Sheets, which was required by our prior credit agreement. The portion of the cash collateral account associated with the outstanding letters of credit that were due to expire beyond twelve months was classified as non-current restricted cash. Our U.S. Revolver removes the previous requirement for all letters of credit and borrowings to be collateralized at 102%.

[0000080420-19-000039:notes:110]
The U.S. Revolver allows the Company to elect that any borrowing under the facility bear an interest rate based on either the base rate or the eurocurrency rate, in each case, plus the applicable rate. The base rate is generally the highest of (a) the federal funds rate plus 0.50%, (b) the Bank of America prime rate and (c) the London Interbank Offered Rate (“LIBOR”) plus 1.00%, subject to certain interest rate floors set forth in the U.S. Revolver. The eurocurrency rate is generally (i) LIBOR for credit extensions denominated in U.S. dollars, euros or pound sterling, (ii) the Canadian dollar offered rate for credit extensions denominated in Canadian dollars and (iii) the rate designated by Bank of America for credit extensions denominated in other currencies. The applicable rate is generally a range from (0.25)% to 0.25% for base rate loans and 1.25% to 1.75% for eurocurrency rate loans, in each case based on the Company's consolidated leverage ratio, provided that the applicable rate is initially (0.25)% for base rate loans and 1.25% for eurocurrency rate loans until January 1, 2020.

[0000080420-19-000039:notes:111]
The U.S. Revolver is collateralized by a pledge of 100% of the voting capital stock of each of our domestic subsidiaries and 65% of the voting capital stock of each non-domestic subsidiary. The U.S. Revolver provides for customary events of default and carries cross-default provisions with other existing debt agreements. If an event of default (as defined in the U.S. Revolver) occurs and is continuing, on the terms and subject to the conditions set forth in the U.S. Revolver, amounts and letters of credit outstanding under the U.S. Revolver may be accelerated and may become immediately due and payable.

[0000080420-19-000039:notes:112]
Industrial Development Revenue Bonds

[0000080420-19-000039:notes:113]
We borrowed $8.0 million in October 2001 through a loan agreement funded with proceeds from tax-exempt industrial development revenue bonds (Bonds). These Bonds were issued by the Illinois Development Finance Authority and were used for the completion of our Northlake, Illinois facility. Pursuant to the Bond issuance, a reimbursement agreement between us and a major domestic bank required an issuance by the bank of an irrevocable direct-pay letter of credit (Bond LC), as collateral, to the Bonds’ trustee to guarantee payment of the Bonds’ principal and interest when due. The Bond LC is subject to both early termination and extension provisions customary to such agreements. While the Bonds mature in 2021, the reimbursement agreement requires annual redemptions of $0.4 million that commenced on October 25, 2002. A sinking fund is used for the annual principal payment. The Bonds bear interest at a floating rate determined weekly by the Bonds’ remarketing agent, which was the underwriter for the Bonds and is an affiliate of the bank. This interest rate was 1.69% as of September 30, 2019. As of September 30, 2019, we were in compliance with all of the covenants of the Bonds.


## us-gaap:NewAccountingPronouncementsPolicyPolicyTextBlock

[0000080420-19-000039:notes:114]
New Accounting Standards

[0000080420-19-000039:notes:115]
In May 2014, the Financial Accounting Standards Board (FASB) issued a new standard on revenue recognition that supersedes previously issued revenue recognition guidance. This standard provides a five-step approach to be applied to all contracts with customers and requires expanded disclosures about the nature, amount, timing and uncertainty of revenue (and the related cash flows) arising from customer contracts, significant judgments and changes in judgments used in applying the revenue model and the assets recognized from costs incurred to obtain or fulfill a contract. Effective October 1, 2018, we adopted this standard using a modified retrospective basis. After evaluating the impact of this new standard on contracts outstanding as of October 1, 2018, we determined that no adjustment to retained earnings was necessary. See Note E for further discussion of revenue.

[0000080420-19-000039:notes:116]
In February 2016, the FASB issued a new topic on leases that requires lessees to recognize lease assets and lease liabilities on the balance sheet for all leases with terms longer than twelve months. Leases will be classified as either finance or operating, with classification affecting the pattern of expense recognition in the income statement. A modified retrospective transition approach is required for lessees for capital and operating leases existing at, or entered into after, the beginning of the earliest comparative period presented in the financial statements, with certain practical expedients available. The new topic is effective for fiscal years beginning after December 15, 2018, including interim periods within those fiscal years which will be our fiscal year ending September 30, 2020. In Fiscal 2018, we acquired new lease software designed to assist in our compliance with this new topic. We anticipate recording right-of-use assets and lease liabilities in similar amounts of less than $10 million on our Consolidated Balance Sheets as of October 1, 2019, and do not anticipate a material adjustment to retained earnings will be necessary. We do not expect this topic to have a significant effect on our Consolidated Statements of Operations or Statements of Cash Flows.

[0000080420-19-000039:notes:117]
In November 2016, the FASB issued a new topic on the statement of cash flows that changes the presentation of restricted cash and cash equivalents on the statement of cash flows. Restricted cash and restricted cash equivalents will be included with cash and cash equivalents when reconciling the beginning-of-period and end-of-period total amounts shown on the statement of cash flows. We adopted this topic in Fiscal 2019, and our Consolidated Cash Flow Statements for all periods reflect this presentation.

[0000080420-19-000039:notes:118]
In May 2017, the FASB issued a new topic on modification accounting with regards to stock-based compensation. This new topic clarifies when a change to the terms or conditions of a share-based payment award should be accounted for as a modification. An entity should account for the effects of a modification unless the fair value, vesting conditions and classification, as an equity instrument or a liability instrument, of the modified award are the same before and after a change to the terms or conditions of the share-based payment award. We adopted this topic in Fiscal 2019, and it has not had a material impact on our Consolidated Balance Sheets or Statements of Operations.


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0000080420-19-000039:notes:119]
Employee Benefit Plans

[0000080420-19-000039:notes:120]
Retirement Plans

[0000080420-19-000039:notes:121]
We have defined employee contribution plans for substantially all of our U.S. employees (401(k) plan) and our Canadian employees (Registered Retirement Savings Plan). We recognized expenses under these plans primarily related to matching contributions of $3.2 million, $2.8 million and $2.8 million in Fiscal 2019, 2018 and 2017, respectively.

[0000080420-19-000039:notes:122]
Deferred Compensation

[0000080420-19-000039:notes:123]
We offer a non-qualified deferred compensation plan to a select group of management and highly compensated individuals. The plan permits the deferral of up to 50% of a participant’s base salary and/or 100% of a participant’s annual incentive bonus. The deferrals are held in a separate trust, an irrevocable rabbi trust (the Rabbi Trust), which has been established to administer the plan. The Rabbi Trust is intended to be used as a source of funds to match respective funding obligations to participants. The assets of the trust are subject to the claims of our creditors in the event that we become insolvent. Consequently, the Rabbi Trust qualifies as a grantor trust for income tax purposes. We make periodic payments into company-owned life insurance policies held in this Rabbi Trust to fund the expected obligations arising under this plan. The assets and liabilities of the plan are recorded in other assets and deferred compensation, respectively, in the accompanying Consolidated Balance Sheets. Changes in the deferred compensation balance are recorded to compensation expense and reflected within the selling, general and administrative line in the Consolidated Statements of Operations. The plan is not qualified under Section 401 of the Internal Revenue code. We recorded net compensation expense adjustments of $0.2 million related to this plan in Fiscal 2019. At September 30, 2019, total assets held by the trustee were $6.8 million and recorded in other assets and the liability was $6.2 million and recorded in other long-term liabilities in our Consolidated Balance Sheets. Of the $6.8 million of assets held by the trustee, $6.7 million is invested in company-owned life insurance policies and the remainder in mutual funds.

[0000080420-19-000039:notes:124]
Certain former executives were provided an executive benefit plan that provides for fixed payments upon normal retirement on or after age 65 and the completion of at least 10 years of continuous employment. The estimated present value of these payments was accrued over the service life of these individuals, and $0.2 million is recorded in deferred compensation related to this executive benefit plan. To assist in funding the deferred compensation liability, we invested in company-owned life insurance policies. The cash surrender value of these policies is presented in other assets and was $3.2 million at September 30, 2019.

[0000080420-19-000039:notes:125]
Retiree Medical Plan

[0000080420-19-000039:notes:126]
We have a plan that extends health benefits to retirees that are also available to active employees under our existing health plans. This plan is unfunded. The plan provides coverage for employees with at least 10 years of service who are age 55 or older but less than 65. The retiree is required to pay the COBRA rate less a subsidy provided by us based on years of service at the time of retirement. The unfunded liability is recorded in other long-term liabilities and was $0.9 million as of both September 30, 2019 and 2018. Our net periodic postretirement benefit expenses have been less than $0.1 million for the last three fiscal years. Due to the immateriality of the costs and liabilities of this plan, no further disclosure is being presented.


## us-gaap:PropertyPlantAndEquipmentPolicyTextBlock

[0000080420-19-000039:notes:127]
Property, Plant and Equipment

[0000080420-19-000039:notes:128]
Property, plant and equipment are stated at cost and are depreciated using the straight-line method over the estimated useful lives of the assets. Expenditures for repairs and maintenance are charged to expense when incurred. Expenditures for major renewals and improvements, which extend the useful lives of existing equipment, are capitalized and depreciated. Upon retirement or disposition of property, plant and equipment, the cost and related accumulated depreciation are removed from the accounts, and any resulting gain or loss is recognized in the Consolidated Statements of Operations.

[0000080420-19-000039:notes:129]
We review property, plant and equipment for impairment whenever events or changes in circumstances indicate that the carrying value may not be realizable. If an evaluation is required, the estimated future undiscounted cash flows associated with the asset are compared to the asset’s carrying amount to determine if recording an impairment of such asset is necessary. If an impairment is indicated, we record an impairment loss equal to the difference between the carrying value and the fair value of the long-lived asset. This requires us to make long-term forecasts of the future revenues and the costs related to the assets subject to review. Forecasts require assumptions about demand for our products and future market conditions. Estimating future cash flows requires significant judgment, and our projections may vary from cash flows eventually realized. Future events and unanticipated changes to assumptions could require a provision for impairment in a future period. The effect of any impairment would be reflected in income (loss) from operations in the Consolidated Statements of Operations. In addition, we estimate the useful lives of our property, plant and equipment and periodically review these estimates to determine whether these lives are appropriate.


## us-gaap:PropertyPlantAndEquipmentTextBlock

[0000080420-19-000039:notes:130]
Property, plant and equipment are summarized below (in thousands):

[0000080420-19-000039:notes:131]
|  | September 30, |  | Range of |
|  | 2019 |  | 2018 |  | Asset Lives |
| Land | $ | 21,963 |  |  | $ | 22,207 |  |  | — |
| Buildings and improvements | 122,404 |  |  | 123,320 |  |  | 3 - 39 Years |
| Machinery and equipment | 106,137 |  |  | 104,542 |  |  | 3 - 15 Years |
| Furniture and fixtures | 3,611 |  |  | 3,799 |  |  | 3 - 10 Years |
| Construction in process | 2,118 |  |  | 357 |  |  | — |
|  | $ | 256,233 |  |  | $ | 254,225 |  |  |  |
| Less: Accumulated depreciation | (135,421 | ) |  | (125,461 | ) |  |  |
| Total property, plant and equipment, net | $ | 120,812 |  |  | $ | 128,764 |  |  |  |


## us-gaap:QuarterlyFinancialInformationTextBlock

[0000080420-19-000039:notes:132]
Quarterly Information

[0000080420-19-000039:notes:133]
The table below sets forth the unaudited consolidated operating results by fiscal quarter for the years ended September 30, 2019 and 2018 (in thousands, except per share data):

[0000080420-19-000039:notes:134]
|  | 2019 Quarters |
|  | First |  | Second |  | Third |  | Fourth |  | 2019 |
| Revenues | $ | 109,351 |  |  | $ | 123,737 |  |  | $ | 135,588 |  |  | $ | 148,504 |  |  | $ | 517,180 |  |
| Gross profit | 14,631 |  |  | 20,075 |  |  | 23,715 |  |  | 28,555 |  |  | 86,976 |  |
| Net income (loss) | (2,695 | ) |  | 958 |  |  | 5,089 |  |  | 6,538 |  |  | 9,890 |  |
| Earnings (loss) per share: |  |  |  |  |  |  |  |  |  |
| Basic | $ | (0.23 | ) |  | $ | 0.08 |  |  | $ | 0.44 |  |  | $ | 0.56 |  |  | $ | 0.85 |  |
| Diluted | $ | (0.23 | ) |  | $ | 0.08 |  |  | $ | 0.44 |  |  | $ | 0.56 |  |  | $ | 0.85 |  |

[0000080420-19-000039:notes:135]
|  | 2018 Quarters |
|  | First |  | Second |  | Third |  | Fourth |  | 2018 |
| Revenues | $ | 90,184 |  |  | $ | 101,505 |  |  | $ | 122,130 |  |  | $ | 134,897 |  |  | $ | 448,716 |  |
| Gross profit | 10,554 |  |  | 12,421 |  |  | 18,375 |  |  | 24,005 |  |  | 65,355 |  |
| Net income (loss) | (5,662 | ) |  | (3,330 | ) |  | 301 |  |  | 1,539 |  |  | (7,152 | ) |
| Earnings (loss) per share: |  |  |  |  |  |  |  |  |  |
| Basic | $ | (0.49 | ) |  | $ | (0.29 | ) |  | $ | 0.03 |  |  | $ | 0.13 |  |  | $ | (0.62 | ) |
| Diluted | $ | (0.49 | ) |  | $ | (0.29 | ) |  | $ | 0.03 |  |  | $ | 0.13 |  |  | $ | (0.62 | ) |

[0000080420-19-000039:notes:136]
The sum of the individual earnings per share amounts may not agree with year-to-date earnings per share as each period’s computation is based on the weighted-average number of shares outstanding during the period.


## us-gaap:RevenueFromContractWithCustomerPolicyTextBlock

[0000080420-19-000039:notes:137]
Revenue Recognition

[0000080420-19-000039:notes:138]
Our revenues are primarily generated from the manufacturing of custom-engineered products and systems under long-term fixed-price contracts that may last from one month to several years, depending on the contract. Revenue from these contracts is generally recognized over time utilizing the cost-to-cost method to measure the extent of progress toward the completion of the performance obligation and the recognition of revenue over time. We believe that this method is the most accurate representation of our performance because it directly measures the value of the services transferred to the customer over time as we incur costs on our contracts. Contract costs include all direct materials, labor and indirect costs related to contract performance, which may include indirect labor, supplies, tools, repairs and depreciation costs.

[0000080420-19-000039:notes:139]
We also have contracts to provide value-added services such as field service inspection, installation, commissioning, modification and repair, as well as retrofit and retrofill components for existing systems. As a practical expedient, if the service contract terms give us the right to invoice the customer for an amount that corresponds directly with the value of our performance completed to date (i.e., a service contract in which we bill a fixed amount for each hour of service provided), then we recognize revenue over time in each reporting period corresponding to the amount with which we have the right to invoice.  Our performance obligations are satisfied as the work progresses.

[0000080420-19-000039:notes:140]
We also have sales orders for spare parts and replacement circuit breakers for switchgear that are obsolete or that are no longer produced by the original manufacturer. Revenues from these sales orders are recognized at a point in time when we fulfill our performance obligation to the customer, which is typically upon shipment.

[0000080420-19-000039:notes:141]
Additionally, some contracts may contain a cancellation clause that could limit the amount of revenue we are able to recognize over time. In these instances, revenue and costs associated with these contracts are deferred and recognized at a point in time when the performance obligation is fulfilled.

[0000080420-19-000039:notes:142]
Selling and administrative costs incurred in relation to obtaining a contract are typically expensed as incurred. We periodically utilize a third-party sales agent to obtain a contract and will pay a commission to that agent. We record the full commission liability to the third-party sales agent at the order date, with a corresponding deferred asset. As the project progresses, we record commission expense based on percentage of completion rates that correlate to the project and reduce the deferred asset. Once we have been paid by the customer, we pay the commission, and the deferred liability is reduced.

[0000080420-19-000039:notes:143]
Contract Balances

[0000080420-19-000039:notes:144]
Contract assets, previously referred to as costs and estimated earnings in excess of billings on uncompleted contracts are recorded when revenues are recognized in excess of amounts billed for fixed-price contracts as determined by the billing milestone schedule. Contract assets are transferred to accounts receivable when billing milestones have been met, or we have an unconditional right to payment.

[0000080420-19-000039:notes:145]
Contract liabilities, previously referred to as billings in excess of costs and estimated earnings on uncompleted contracts, typically represent advance payments from contractual billing milestones and billings in excess of revenue recognized. It is unusual to have advanced milestone payments with a term greater than one year, which could represent a financing component on the contract.

[0000080420-19-000039:notes:146]
Our contract assets and liabilities are reported in a net position on a contract-by-contract basis at the end of each reporting period and are generally classified as current.

[0000080420-19-000039:notes:147]
Variable Consideration

[0000080420-19-000039:notes:148]
It is common for our long-term contracts to contain variable consideration that can either increase or decrease the transaction price. Due to the nature of our contracts, estimating total cost and revenue can be complex and subject to variability due to change orders, back charges, spare parts, early completion bonuses, customer allowances and liquidated damages. We estimate the amount of variable consideration based on the expected value method, which is the sum of probability-weighted amount, or the most likely amount method, which uses various factors including experience with similar transactions and assessment of our anticipated performance. Variable consideration is included in the transaction price if legally enforceable and to the extent it is probable that a significant reversal of cumulative revenue recognized will not occur once the uncertainty associated with the variable consideration is resolved.

[0000080420-19-000039:notes:149]
Contract Modifications

[0000080420-19-000039:notes:150]
Contracts may be modified for changes in contract specifications and requirements. We consider contract modifications to exist when the modification either creates new or changes the enforceable rights and obligations under the contract. Most of our contract modifications are for goods and services that are not distinct from the existing performance obligation. Contract modifications result in a cumulative catch-up adjustment to revenue based on our measure of progress for the performance obligation.

[0000080420-19-000039:notes:151]
The timing of revenue recognition, billings and cash collections affects accounts receivable, costs and estimated earnings in excess of billings on uncompleted contracts (contract assets) and billings in excess of costs and estimated earnings on uncompleted contracts (contract liabilities) in our Consolidated Balance Sheet.

[0000080420-19-000039:notes:152]
Contract assets, previously referred to as costs and estimated earnings in excess of billings on uncompleted contracts, are recorded when revenues are recognized in excess of amounts billed for fixed-price contracts as determined by the billing milestone schedule. Contract assets are transferred to accounts receivable when billing milestones have been met, or we have an unconditional right to payment.

[0000080420-19-000039:notes:153]
Contract Estimates

[0000080420-19-000039:notes:154]
Actual revenues and project costs may vary from previous estimates due to changes in a variety of factors. The cost estimation process is based upon the professional knowledge and experience of our engineers, project managers and financial professionals. Factors that are considered in estimating the work to be completed and ultimate contract recovery include the availability and productivity of labor, the nature and complexity of the work to be performed, the availability of materials, and the effect of any delays on our project performance. We periodically review our job performance, job conditions, estimated profitability and final contract settlements, including our estimate of total costs and make revisions to costs and income in the period in which the revisions are probable and reasonably estimable. Whenever revisions of estimated contract costs and contract values indicate that the contract costs will exceed estimated revenues, thus creating a loss, a provision for the total estimated loss is recorded in that period.

[0000080420-19-000039:notes:155]
Performance Obligations

[0000080420-19-000039:notes:156]
A performance obligation is a promise in a contract or with a customer to transfer a distinct good or service. A contract’s transaction price is allocated to each distinct performance obligation and recognized as revenue as the performance obligations are satisfied. To determine the proper revenue recognition for contracts, we evaluate whether a contract should be accounted for as more than one performance obligation or, less commonly, whether two or more contracts should be combined and accounted for as one performance obligation.  This evaluation of performance obligations requires significant judgment.  The majority of our contracts have a single performance obligation where multiple engineered products and services are combined into a single custom-engineered solution. Our contracts generally include a standard assurance warranty that typically ends 18 months after shipment. Occasionally, we provide service-type warranties that will extend the warranty period. These extended warranties qualify as a separate performance obligation, and revenue is deferred and recognized over the warranty period. If we determine during the evaluation of the contract that there are multiple performance obligations, we allocate the transaction price to each performance obligation using our best estimate of the standalone selling price of each distinct good or service in the contract.

[0000080420-19-000039:notes:157]
Remaining unsatisfied performance obligations, which we refer to as backlog, represent the estimated transaction price for goods and services for which we have a material right, but work has not been performed.


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0000080420-19-000039:notes:158]
Revenue

[0000080420-19-000039:notes:159]
On October 1, 2018, we adopted the new revenue recognition standard using the modified retrospective transition method. We applied the guidance in the standard to customer contracts that were not substantially complete at that time and we determined that no adjustment to retained earnings was necessary. Financial results for reporting periods after October 1, 2018 are reported under the new standard; however, financial results for prior periods were not adjusted and will continue to be presented in accordance with the previous standard.

[0000080420-19-000039:notes:160]
The majority of our revenues are generated from the manufacturing of custom-engineered products and systems under long-term fixed-price contracts under which we agree to manufacture various products such as traditional and arc-resistant distribution switchgear and control gear, medium-voltage circuit breakers, monitoring and control communications systems, motor control centers and bus duct systems. These products may be sold separately as an engineered solution, but are typically integrated into custom-built enclosures which we also build.  These enclosures are referred to as power control room substations (PCRs®), custom-engineered modules or electrical houses (E-Houses). Some contracts may also include the installation and the commissioning of these enclosures.

[0000080420-19-000039:notes:161]
Revenue from these contracts is generally recognized over time utilizing the cost-to-cost method to measure the extent of progress toward the completion of the performance obligation and the recognition of revenue over time. We believe that this method is the most accurate representation of our performance, because it directly measures the value of the services transferred to the customer over time as we incur costs on our contracts.  Contract costs include all direct materials, labor, and indirect costs related to contract performance, which may include indirect labor, supplies, tools, repairs and depreciation costs.

[0000080420-19-000039:notes:162]
We also have contracts to provide value-added services such as field service inspection, installation, commissioning, modification and repair, as well as retrofit and retrofill components for existing systems.  As a practical expedient, if the service contract terms give us the right to invoice the customer for an amount that corresponds directly with the value of our performance completed to date (i.e., a service contract in which we bill a fixed amount for each hour of service provided), then we recognize revenue over time in each reporting period corresponding to the amount with which we have the right to invoice.  Our performance obligations are satisfied as the work progresses. Revenues from our custom-engineered products and value-added services transferred to customers over time accounted for approximately 94% of revenues for the year ended September 30, 2019.

[0000080420-19-000039:notes:163]
We also have sales orders for spare parts and replacement circuit breakers for switchgear that are obsolete or that are no longer produced by the original manufacturer. Revenues from these sales orders are recognized at the time we fulfill our performance obligation to the customer, which is typically upon shipment and represented approximately 6% of revenues for the year ended September 30, 2019.

[0000080420-19-000039:notes:164]
Remaining unsatisfied performance obligations, which we refer to as backlog, represent the estimated transaction price for goods and services for which we have a material right, but work has not been performed. As of September 30, 2019, we had backlog of $419.0 million, of which approximately $345 million is expected to be recognized as revenue within the next twelve months. Backlog may not be indicative of future operating results as orders may be cancelled or modified by our customers. Our backlog does not include service and maintenance-type contracts for which we have the right to invoice as services are performed.

[0000080420-19-000039:notes:165]
For the years ended September 30, 2019 and 2018, our operating results were positively impacted by $5.1 million and $3.9 million, respectively, as a result of changes in contract estimates related to projects in progress at the beginning of the respective period. These changes in estimates resulted primarily from favorable project execution and negotiations of variable consideration, discussed below, as well as other changes in facts and circumstances during these periods.

[0000080420-19-000039:notes:166]
The decrease in net contract asset to a contract liability at September 30, 2019 from September 30, 2018 was primarily due to our progress towards completion on our projects and the timing of contract billing milestones and new orders. To determine the amount of revenue recognized during the period from contract liabilities, we first allocate revenue to the individual contract liability balance outstanding at the beginning of the period until the revenue exceeds that balance. During the year ended September 30, 2019, we recognized revenue of approximately $39.5 million related to contract liabilities outstanding at September 30, 2018.

[0000080420-19-000039:notes:167]
The timing of our invoice process is typically dependent on the completion of certain milestones and contract terms and subject to agreement by our customer.  Payment is typically expected within 30 days of invoice. Any uncollected invoiced amounts for our performance obligations recognized over time, including contract retentions, are recorded as accounts receivable in the Consolidated Balance Sheets. Certain contracts contain retention provisions that become due upon completion of contractual requirements. As of September 30, 2019 and September 30, 2018, accounts receivable included retention amounts of $5.6 million and $4.2 million, respectively. Of the retained amount at September 30, 2019, $4.9 million is expected to be collected in the next twelve months.

[0000080420-19-000039:notes:168]
Disaggregation of Revenue


## us-gaap:RevenueFromExternalCustomersByGeographicAreasTableTextBlock

[0000080420-19-000039:notes:169]
Revenues by country represent sales to unaffiliated customers as determined by the ultimate destination of our products and services, summarized for the last three fiscal years by region in the table below (in thousands):

[0000080420-19-000039:notes:170]
|  | Year Ended September 30, |
|  | 2019 |  | 2018 |  | 2017 |
| United States | $ | 406,609 |  |  | $ | 335,743 |  |  | $ | 279,352 |  |
| Canada | 64,326 |  |  | 42,235 |  |  | 45,540 |  |
| Middle East and Africa | 18,420 |  |  | 38,490 |  |  | 26,639 |  |
| Far East | 11,405 |  |  | 12,976 |  |  | 3,877 |  |
| Europe | 13,746 |  |  | 10,538 |  |  | 21,194 |  |
| Mexico, Central and South America | 2,674 |  |  | 8,734 |  |  | 19,309 |  |
| Total revenues | $ | 517,180 |  |  | $ | 448,716 |  |  | $ | 395,911 |  |


## us-gaap:ScheduleOfCashFlowSupplementalDisclosuresTableTextBlock

[0000080420-19-000039:notes:171]
Supplemental Disclosures of Cash Flow Information (in thousands):

[0000080420-19-000039:notes:172]
|  | Year Ended September 30, |
|  | 2019 |  | 2018 |  | 2017 |
| Cash paid (received) during the period for: |  |  |  |  |  |
| Interest paid, net of interest income | $ | (873 | ) |  | $ | (676 | ) |  | (384 | ) |
| Income taxes paid, net of refunds | (5,219 | ) |  | 354 |  |  | (764 | ) |
| Non-cash capital expenditures | 1,248 |  |  | 129 |  |  | 634 |  |


## us-gaap:ScheduleOfInventoryCurrentTableTextBlock

[0000080420-19-000039:notes:173]
The components of inventories are summarized below (in thousands):

[0000080420-19-000039:notes:174]
|  | September 30, |
|  | 2019 |  | 2018 |
| Raw materials, parts and subassemblies | $ | 31,781 |  |  | $ | 24,563 |  |
| Work-in-progress | 1,100 |  |  | 1,080 |  |
| Provision for excess and obsolete inventory | (3,679 | ) |  | (4,291 | ) |
| Total inventories | $ | 29,202 |  |  | $ | 21,352 |  |


## us-gaap:ScheduleOfProductWarrantyLiabilityTableTextBlock

[0000080420-19-000039:notes:175]
Activity in our product warranty accrual consisted of the following (in thousands):

[0000080420-19-000039:notes:176]
|  | September 30, |
|  | 2019 |  | 2018 |
| Balance at beginning of period | $ | 2,604 |  |  | $ | 3,174 |  |
| Increase to warranty expense | 3,004 |  |  | 2,031 |  |
| Deduction for warranty charges | (2,649 | ) |  | (2,574 | ) |
| Change due to foreign currency translation | (13 | ) |  | (27 | ) |
| Balance at end of period | $ | 2,946 |  |  | $ | 2,604 |  |


## us-gaap:SegmentReportingDisclosureTextBlock

[0000080420-19-000039:notes:177]
Geographic Information

[0000080420-19-000039:notes:178]
Long-lived assets by country consist of property, plant and equipment, net of accumulated depreciation and are determined based on the location of the tangible assets.


## us-gaap:SignificantAccountingPoliciesTextBlock

[0000080420-19-000039:notes:179]
Summary of Significant Accounting Policies

[0000080420-19-000039:notes:180]
Use of Estimates

[0000080420-19-000039:notes:181]
The preparation of financial statements in conformity with accounting principles generally accepted in the United States (U.S. GAAP) requires management to make estimates and assumptions that affect the amounts reported in the consolidated financial statements and accompanying footnotes. The most significant estimates used in our financial statements affect revenue recognition and estimated cost recognition on our customer contracts, the allowance for doubtful accounts, provision for excess and obsolete inventory, warranty accruals and income taxes. The amounts recorded for warranties, legal, income taxes, impairment of long-lived assets (when applicable) and other contingent liabilities require judgments regarding the amount of expenses that will ultimately be incurred. We base our estimates on historical experience and on various other assumptions, as well as the specific circumstances surrounding these contingent liabilities, in evaluating the amount of liability that should be recorded. Additionally, the recognition of deferred tax assets requires estimates related to future income and other assumptions regarding timing and future profitability because the ultimate realization of net deferred tax assets is dependent on the generation of future taxable income during periods in which temporary differences become deductible. Estimates routinely change as new events occur, additional information becomes available or operating environments change. Actual results may differ from our prior estimates.

[0000080420-19-000039:notes:182]
Cash and Investments

[0000080420-19-000039:notes:183]
Cash and cash equivalents, primarily funds held in money market savings instruments, are reported at their current carrying value, which approximates fair value due to the short-term nature of these instruments, and are included in cash and cash equivalents in our Consolidated Balance Sheets.

[0000080420-19-000039:notes:184]
Restricted Cash - Restricted cash included cash and cash equivalents that were unavailable for withdrawal or usage for general obligations and represented a pledged cash collateral balance that was required under our prior credit agreement and was held in an interest-bearing savings account. See Note G for further discussion on restricted cash.

[0000080420-19-000039:notes:185]
Accounts Receivable

[0000080420-19-000039:notes:186]
Accounts receivable are stated net of allowances for doubtful accounts. We maintain and continually assess the adequacy of the allowance for doubtful accounts representing our estimate for losses resulting from the inability of our customers to pay amounts due to us. This estimated allowance is based on historical experience of uncollected accounts, the level of past due accounts, the overall level of outstanding accounts receivable, information about specific customers with respect to their inability to make payments and expectations of future conditions that could impact the collectability of accounts receivable. Future changes in our customers’ operating performance and cash flows, or in general economic conditions, could have an impact on their ability to fully pay these amounts, which could have a material impact on our operating results. In most cases, receivables are not collateralized. However, we utilize letters of credit to secure payment on projects when possible. As of September 30, 2019 and 2018, accounts receivable included retention amounts of $5.6 million and $4.2 million, respectively. Retention amounts are in accordance with applicable provisions of contracts and become due upon completion of contractual requirements. Of the retained amount at September 30, 2019, $4.9 million is expected to be collected in the next twelve months and is recorded in accounts receivable. The remaining $0.7 million is recorded in other assets and is expected to be collected in Fiscal 2021.

[0000080420-19-000039:notes:187]
Warranty Costs

[0000080420-19-000039:notes:188]
We provide for estimated warranty costs with the recognition of revenue based upon historical rates applicable to individual product lines. In addition, specific provisions are made when the costs of such warranties are expected to exceed accruals. Our standard terms and conditions of sale include a warranty for parts and service for the earlier of 18 months from the date of shipment or 12 months from the date of energization, whichever occurs first. Occasionally projects require warranty terms that are longer than our standard terms due to the nature of the project. Extended warranty terms may be negotiated and included in our contracts. We use past experience and historical claims to determine the estimated liability. Actual results could differ from our estimate.

[0000080420-19-000039:notes:189]
Research and Development Expense

[0000080420-19-000039:notes:190]
Research and development activities are directed toward the development of new products and processes as well as improvements in existing products and processes. These costs, which primarily include salaries, contract services and supplies, are expensed as incurred. Such amounts were $6.3 million, $6.7 million and $6.9 million in Fiscal 2019, 2018 and 2017, respectively.

[0000080420-19-000039:notes:191]
We measure stock-based compensation cost at the grant date based on the fair value of the award. Compensation expense is recognized over the period during which the recipient is required to provide service in exchange for the awards, typically the vesting period. Excess income tax benefits related to share-based compensation expense is recognized as income tax expense or benefit in the Consolidated Statement of Operations. Cash paid when directly withholding shares on an employee's behalf for tax withholding purposes is classified as a financing activity. We account for forfeitures as they occur, rather than estimate expected forfeitures.


## us-gaap:SubsequentEventsTextBlock

[0000080420-19-000039:notes:192]
Subsequent Events

[0000080420-19-000039:notes:193]
On November 4, 2019, our Board of Directors declared a quarterly cash dividend on our common stock in the amount of $0.26 per share. The dividend is payable on December 18, 2019 to shareholders of record at the close of business on November 20, 2019.


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0000080420-19-000039:notes:194]
Detail of Selected Balance Sheet Accounts

[0000080420-19-000039:notes:195]
Allowance for Doubtful Accounts

[0000080420-19-000039:notes:196]
There were no assets under capital lease as of September 30, 2019 or September 30, 2018. Depreciation expense was $11.9 million, $12.7 million and $12.4 million for fiscal years 2019, 2018, and 2017, respectively.

[0000080420-19-000039:notes:197]
Accrued Product Warranty
