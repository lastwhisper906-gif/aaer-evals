# POWL MD&A — 0000080420-19-000039


## mdna

[0000080420-19-000039:mdna:1]
Item 7. Management’s Discussion and Analysis of Financial Condition and Results of Operations

[0000080420-19-000039:mdna:2]
Overview

[0000080420-19-000039:mdna:3]
We develop, design, manufacture and service custom-engineered equipment and systems for the distribution, control and monitoring of electrical energy. Headquartered in Houston, Texas, we serve the oil and gas markets, including onshore and offshore oil and gas production, pipeline, refining and liquid natural gas terminals, as well as petrochemical, electric utility and light traction power. Revenues and costs are primarily related to custom engineered-to-order equipment and systems and are accounted for under percentage-of-completion accounting, which precludes us from providing detailed price and volume information. Our backlog includes various projects that typically take a number of months to produce.

[0000080420-19-000039:mdna:4]
The markets in which we participate are capital-intensive and cyclical in nature. Cyclicality is predominantly driven by customer demand, global economic conditions and anticipated environmental, safety or regulatory changes that affect the manner in which our customers proceed with capital investments. Our customers analyze various factors including the demand and price for oil, gas and electrical energy, the overall economic and financial environment, governmental budgets, regulatory actions and environmental concerns. These factors influence the release of new capital projects by our customers, which are traditionally awarded in competitive bid situations. Scheduling of projects is matched to the customer requirements, and projects typically take a number of months to produce. Schedules may change during the course of any particular project, and our operating results can, therefore, be impacted by factors outside of our control.

[0000080420-19-000039:mdna:5]
Due to the significant decline in oil and gas prices from peak 2014 levels, many of our customers reduced their capital budgets and cut costs, and in certain instances delayed or canceled projects that we were pursuing. This decline in projects negatively impacted our results in Fiscal 2018. However, customers have begun to invest in projects in our key oil and gas and petrochemical markets, and this shift has had a favorable impact on our orders and backlog over recent quarters, resulting in increased revenues in Fiscal 2019.

[0000080420-19-000039:mdna:6]
Results of Operations

[0000080420-19-000039:mdna:7]
Twelve Months Ended September 30, 2019 Compared to Twelve Months Ended September 30, 2018

[0000080420-19-000039:mdna:8]
Revenue and Gross Profit

[0000080420-19-000039:mdna:9]
Revenues increased by 15%, or $68.5 million, to $517.2 million in Fiscal 2019, primarily due to improved market conditions, primarily in our oil and gas markets over the past few quarters. Domestic revenues increased by 22%, or $72.8 million, to $405.0 million in Fiscal 2019. International revenues decreased by 4% to $112.1 million in Fiscal 2019, primarily due to a slight decrease in export projects from our domestic facilities. Our international revenues include both revenues generated from our international facilities as well as revenues from export projects generated at our domestic facilities.

[0000080420-19-000039:mdna:10]
Commercial and industrial revenue increased by 21%, or $69.0 million, to $394.2 million in Fiscal 2019, driven by the strength across the core oil and gas and petrochemical end markets. Public and private utilities revenue decreased by 5%, or $4.0 million, to $85.0 million in Fiscal 2019, as we completed various large domestic utility projects in the backlog in Fiscal 2018. Municipal and transit revenue increased by 10%, or $3.5 million, to $38.0 million in Fiscal 2019, primarily from project timing and product mix of projects for some of our key municipal customers.

[0000080420-19-000039:mdna:11]
Gross profit increased by 33%, or $21.6 million, to $87.0 million in Fiscal 2019. Gross profit as a percentage of revenues increased to 17% in Fiscal 2019, compared to 15% in Fiscal 2018, due to improved market conditions and efficiencies from increased volume in our domestic and Canadian manufacturing facilities.

[0000080420-19-000039:mdna:12]
Selling, General and Administrative Expenses

[0000080420-19-000039:mdna:13]
Selling, general and administrative expenses increased 5%, or $3.2 million, to $70.0 million in Fiscal 2019, primarily due to increased personnel costs associated with increased project volume. Selling, general and administrative expenses, as a percentage of revenues, decreased to 14% in Fiscal 2019 compared to 15% in Fiscal 2018, primarily due to the increase in revenues and our continued focus on our cost structure.

[0000080420-19-000039:mdna:14]
Insurance Proceeds

[0000080420-19-000039:mdna:15]
In Fiscal 2019, we settled a 2017 business interruption insurance claim relating to Hurricane Harvey and received proceeds of $1.0 million, which is included within operating income.

[0000080420-19-000039:mdna:16]
Restructuring, Separation and Other Expenses, Net

[0000080420-19-000039:mdna:17]
In Fiscal 2019, we recorded additional lease expense of $0.7 million related to certain unused facility leases in Canada. We also recorded income from a recovery of $0.7 million in Fiscal 2019 as a result of a favorable settlement of a claim related to the divestiture of a subsidiary in Fiscal 2014. In Fiscal 2018, we incurred $0.8 million of restructuring expense related to anticipated losses on the sublet of a Canadian facility that we exited in a prior period.

[0000080420-19-000039:mdna:18]
Other Income

[0000080420-19-000039:mdna:19]
We did not record other income in Fiscal 2019. In Fiscal 2018, we recorded the final $0.5 million amortization of the deferred gain from the amended supply agreement (see Note F of the Notes to Consolidated Financial Statements), as well as a $0.2 million gain from the settlement of a Company-owned life insurance policy.

[0000080420-19-000039:mdna:20]
Income Tax Provision/Benefit

[0000080420-19-000039:mdna:21]
We recorded income tax provision of $2.4 million in Fiscal 2019, compared to an income tax benefit of $0.5 million in Fiscal 2018. The effective tax rate for Fiscal 2019 was 20% compared to an effective tax rate of 7% for Fiscal 2018. For Fiscal 2019, the effective tax rate approximated the U.S. federal statutory rate due to the benefit of the utilization of net operating loss carryforwards in Canada that were fully reserved with a valuation allowance and the benefit from Research and Development Tax Credit (R&D Tax Credit). These tax benefits were largely offset by state income tax expense and other non-deductible costs. Due to the loss position in Fiscal 2018, the effective tax rate was negatively impacted by foreign tax losses for which no tax benefit was recognized and tax expense of $0.5 million due to the re-measurement of U.S. deferred tax assets as a result of tax reform.

[0000080420-19-000039:mdna:22]
Net Income/Loss

[0000080420-19-000039:mdna:23]
In Fiscal 2019, net income of $9.9 million, or $0.85 per diluted share, improved from a net loss of $7.2 million, or $0.62 per diluted share in Fiscal 2018, primarily due to improved market conditions and efficiencies from increased volume in our domestic and Canadian manufacturing facilities.

[0000080420-19-000039:mdna:24]
Backlog

[0000080420-19-000039:mdna:25]
The order backlog at September 30, 2019 was $419.0 million, a 61% increase from the $260.9 million at September 30, 2018, primarily due to increased demand in our core oil and gas and petrochemical markets. New orders increased by 47% in Fiscal 2019 to $676.1 million, compared to $458.9 million in Fiscal 2018, primarily due to improved market conditions.

[0000080420-19-000039:mdna:26]
Outlook

[0000080420-19-000039:mdna:27]
The markets in which we participate are capital-intensive and cyclical in nature. Cyclicality is predominantly driven by customer demand, global economic conditions and anticipated environmental, safety or regulatory changes which affect the manner in which our customers proceed with capital investments. Our customers analyze various factors including the demand and price for oil, gas and electrical energy, the overall economic and financial environment, governmental budgets, regulatory actions and environmental concerns. These factors influence the release of new capital projects by our customers, which are traditionally awarded in competitive bid situations. Scheduling of projects is matched to customer requirements, and projects typically take a number of months to produce. Schedules may change during the course of any particular project, and our operating results can, therefore, be impacted by factors outside of our control.

[0000080420-19-000039:mdna:28]
A significant portion of our revenues has historically been from the oil, gas and petrochemical markets. Oil and gas commodity price levels have been unstable over the last several years, and our customers delayed some of their major capital investment

[0000080420-19-000039:mdna:29]
projects. Commodity prices have stabilized, and customers continue to invest in projects in our key oil and gas and petrochemical markets, and this shift in market sentiment has had a favorable impact on our orders and backlog over recent quarters.

[0000080420-19-000039:mdna:30]
Our operating results have been impacted by factors such as the timing of new order awards, customer approval of final engineering and design specifications and delays in customer construction schedules, all of which contribute to short-term earnings variability and the timing of project execution. Our operating results also have been, and could continue to be, impacted by the timing and resolution of change orders, project close-out and resolution of potential contract claims and liquidated damages, all of which could improve or deteriorate gross margins during the period in which these items are resolved with our customers. These factors may result in periods of underutilization of our resources and facilities and negatively impact our ability to cover our fixed costs. The increased orders in Fiscal 2018 and 2019 have led to improvement in revenues and operating results that we anticipate will continue into Fiscal 2020. We continue to focus on maintaining our cash position, improving efficiencies in production and investing in future business opportunities. We continue to monitor the factors that drive our markets and will continue to strive to maintain our leadership and competitive advantage in the markets we serve while aligning our cost structures with market conditions.

[0000080420-19-000039:mdna:31]
Liquidity and Capital Resources

[0000080420-19-000039:mdna:32]
As of September 30, 2019, current assets exceeded current liabilities by 2.1 times, and our debt to total capitalization was 0.40%.

[0000080420-19-000039:mdna:33]
Cash, cash equivalents and short-term investments increased to $124.7 million at September 30, 2019, compared to $49.8 million at September 30, 2018. We also had restricted cash held in a pledged collateral account related to our prior credit agreement of $25.1 million at September 30, 2018. Our increase in project volume typically requires cash to fund operations. We believe that our strong working capital position, available borrowings under our credit facility and available cash and short-term investments should be sufficient to finance future operating activities, capital improvements, research and development initiatives and debt repayments for the foreseeable future.

[0000080420-19-000039:mdna:34]
On September 27, 2019, we entered into an Amended and Restated Credit Agreement with Bank of America, N.A. (the "U.S. Revolver") which replaced our prior credit agreement. The U.S. Revolver is a $75.0 million revolving credit facility, which is available for both borrowings and letters of credit. As of September 30, 2019, there were no amounts borrowed under this facility, and letters of credit outstanding were $13.4 million. As of September 30, 2019, $61.6 million was available for the issuance of letters of credit and borrowing under the U.S. Revolver. Total long-term debt, including current maturities, totaled $1.2 million at September 30, 2019 related to outstanding industrial development revenue bonds. For further information regarding our debt, see Notes G and H of Notes to Consolidated Financial Statements.

[0000080420-19-000039:mdna:35]
Approximately $21.7 million of our cash and short-term investments at September 30, 2019 was held outside of the U.S. for international operations. It is our intention to indefinitely reinvest all current and future foreign earnings internationally in order to ensure sufficient working capital to support our international operations. In the event that we elect to repatriate some or all of the foreign earnings that were previously deemed to be indefinitely reinvested outside the U.S., under current tax laws we may incur additional tax expense upon such repatriation.

[0000080420-19-000039:mdna:36]
Operating Activities

[0000080420-19-000039:mdna:37]
Operating activities provided net cash of $68.8 million in Fiscal 2019 and used net cash of $28.5 million in Fiscal 2018. Cash flow from operations is primarily influenced by project volume, the timing of milestone payments from our customers and the payment terms with our suppliers. The increase in operating cash flows during Fiscal 2019 was primarily due to the completion and cash collection of contractual billing milestones, the collection of accounts receivable and the receipt of a $6.6 million income tax refund.

[0000080420-19-000039:mdna:38]
Investing Activities

[0000080420-19-000039:mdna:39]
Investing activities provided $3.0 million during Fiscal 2019 compared to $10.4 million in Fiscal 2018. The decrease in cash provided by investing activities in Fiscal 2019 was primarily due to a decrease in the net maturities of short-term investments to $7.2 million in Fiscal 2019, compared to $13.0 million in Fiscal 2018.

[0000080420-19-000039:mdna:40]
Net purchases of property, plant and equipment during Fiscal 2019 totaled $4.3 million compared to $4.4 million in Fiscal 2018.

[0000080420-19-000039:mdna:41]
Financing Activities

[0000080420-19-000039:mdna:42]
Net cash used in financing activities was $13.9 million in Fiscal 2019 and $13.0 million in Fiscal 2018, which primarily consisted of approximately $12 million of dividends paid in each year.

[0000080420-19-000039:mdna:43]
Contractual and Other Obligations

[0000080420-19-000039:mdna:44]
At September 30, 2019, our long-term contractual obligations were limited to debt and leases. The table below details our commitments by type of obligation, including interest if applicable, and the period that the payment will become due (in thousands).

[0000080420-19-000039:mdna:45]
| Payments Due by Period: |  |  |  |  |  |
|  | Long-Term Debt Obligations |  | Net Operating Lease Obligations |  | Total |
| Less than 1 year | $ | 414 |  |  | $ | 2,164 |  |  | $ | 2,578 |  |
| 1 to 3 years | 807 |  |  | 3,283 |  |  | 4,090 |  |
| 3 to 5 years | — |  |  | 650 |  |  | 650 |  |
| More than 5 years | — |  |  | — |  |  | — |  |
| Total long-term contractual obligations | $ | 1,221 |  |  | $ | 6,097 |  |  | $ | 7,318 |  |

[0000080420-19-000039:mdna:46]
As of September 30, 2019, the total unrecognized tax benefit related to uncertain tax positions was $2.7 million. We estimate that none of this will be paid within the next 12 months. However, we believe that it is reasonably possible that within the next 12 months, the total unrecognized tax benefits will decrease by approximately $0.9 million due to the expiration of certain statutes of limitations and voluntary filings. We are unable to make reasonably reliable estimates regarding the timing of future cash outflows, if any, associated with the remaining unrecognized tax benefits.

[0000080420-19-000039:mdna:47]
Other Commercial Commitments

[0000080420-19-000039:mdna:48]
We are contingently liable for letters of credit and bank guarantees totaling $19.0 million as of September 30, 2019, with the following potential cash outflows in the event that we are unable to perform under our contracts (in thousands):

[0000080420-19-000039:mdna:49]
| Payments Due by Period: | Letters ofCredit/Bank Guarantees |
| Less than 1 year | $ | 9,728 |  |
| 1 to 3 years | 8,530 |  |
| More than 3 years | 784 |  |
| Total long-term commercial obligations | $ | 19,042 |  |

[0000080420-19-000039:mdna:50]
We also had performance and maintenance bonds totaling $170.5 million that were outstanding at September 30, 2019. Performance and maintenance bonds are primarily used to guarantee our contract performance to our customers.

[0000080420-19-000039:mdna:51]
Off-Balance Sheet Arrangements

[0000080420-19-000039:mdna:52]
We had no off-balance sheet arrangements during the periods presented.

[0000080420-19-000039:mdna:53]
Effects of Inflation

[0000080420-19-000039:mdna:54]
We are subject to inflation, which can cause increases in our costs of raw materials, primarily copper, aluminum and steel. Fixed-price contracts can limit our ability to pass these increases to our customers, thus negatively impacting our earnings. Inflation in commodity prices could potentially impact our operations in future years.

[0000080420-19-000039:mdna:55]
Critical Accounting Policies and Estimates

[0000080420-19-000039:mdna:56]
The preparation of consolidated financial statements in conformity with accounting principles generally accepted in the U.S. requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities, disclosures of contingent assets and liabilities known to exist at the date of the consolidated financial statements and the reported amounts of revenues and expenses during the reporting period. We evaluate our estimates on an ongoing basis, based on historical experience and on various other assumptions that are believed to be reasonable under the circumstances. There can be no assurance that actual results will not differ from those estimates.

[0000080420-19-000039:mdna:57]
We believe the following accounting policies and estimates to be critical in the preparation and reporting of our consolidated financial statements.

[0000080420-19-000039:mdna:58]
Revenue Recognition

[0000080420-19-000039:mdna:59]
On October 1, 2018, we adopted the new revenue recognition standard using the modified retrospective transition method. We applied the guidance in the standard to customer contracts that were not substantially complete at that time, and we determined that no adjustment to retained earnings was necessary. Financial results for reporting periods after October 1, 2018 are reported under the new standard; however, financial results for prior periods were not adjusted and continue to be presented in accordance with the previous standard.

[0000080420-19-000039:mdna:60]
The majority of our revenues are generated from the manufacturing of custom-engineered products and systems under long-term fixed-price contracts under which we agree to manufacture various products such as traditional and arc-resistant distribution switchgear and control gear, medium-voltage circuit breakers, monitoring and control communications systems, motor control centers and bus duct systems. These products may be sold separately as an engineered solution, but are typically integrated into custom-built enclosures which we also build.  These enclosures are referred to as power control room substations (PCRs®), custom-engineered modules or electrical houses (E-Houses). Some contracts may also include the installation and the commissioning of these enclosures.

[0000080420-19-000039:mdna:61]
Revenue from these contracts is generally recognized over time utilizing the cost-to-cost method to measure the extent of progress toward the completion of the performance obligation and the recognition of revenue over time. We believe that this method is the most accurate representation of our performance, because it directly measures the value of the services transferred to the customer over time as we incur costs on our contracts. Contract costs include all direct materials, labor, and indirect costs related to contract performance, which may include indirect labor, supplies, tools, repairs and depreciation costs.

[0000080420-19-000039:mdna:62]
We also have contracts to provide value-added services such as field service inspection, installation, commissioning, modification and repair, as well as retrofit and retrofill components for existing systems. As a practical expedient, if the service contract terms give us the right to invoice the customer for an amount that corresponds directly with the value of our performance completed to date (i.e., a service contract in which we bill a fixed amount for each hour of service provided), then we recognize revenue over time in each reporting period corresponding to the amount with which we have the right to invoice. Our performance obligations are satisfied as the work progresses. Revenues from our custom-engineered products and value-added services transferred to customers over time accounted for approximately 94% of revenues for Fiscal 2019.

[0000080420-19-000039:mdna:63]
We also have sales orders for spare parts and replacement circuit breakers for switchgear that are obsolete or that are no longer produced by the original manufacturer. Revenues from these sales orders are recognized at the time we fulfill our performance obligation to the customer, which is typically upon shipment and represented approximately 6% of revenues for Fiscal 2019.

[0000080420-19-000039:mdna:64]
Additionally, some contracts may contain a cancellation clause that could limit the amount of revenue we are able to recognize over time. In these instances, revenue and costs associated with these contracts are deferred and recognized at the time the performance obligation is fulfilled.

[0000080420-19-000039:mdna:65]
Performance Obligations

[0000080420-19-000039:mdna:66]
A performance obligation is a promise in a contract or with a customer to transfer a distinct good or service. A contract’s transaction price is allocated to each distinct performance obligation and recognized as revenue as the performance obligations are satisfied. To determine the proper revenue recognition for contracts, we evaluate whether a contract should be accounted for as more than one performance obligation or, less commonly, whether two or more contracts should be combined and accounted for as one performance obligation. This evaluation of performance obligations requires significant judgment. The majority of our contracts have a single performance obligation where multiple engineered products and services are combined into a single, custom-engineered solution. Our contracts generally include a standard assurance warranty that typically ends 18 months after shipment. Occasionally, we provide service-type warranties that will extend the warranty period. These extended warranties qualify as  separate performance obligations, and revenue is deferred and recognized over the warranty period. If we determine during the

[0000080420-19-000039:mdna:67]
evaluation of the contract that there are multiple performance obligations, we allocate the transaction price to each performance obligation using our best estimate of the standalone selling price of each distinct good or service in the contract.

[0000080420-19-000039:mdna:68]
Remaining unsatisfied performance obligations, which we refer to as backlog, represent the estimated transaction price for goods and services for which we have a material right, but work has not been performed. As of September 30, 2019, we had backlog of $419.0 million, of which approximately $345 million is expected to be recognized as revenue within the next twelve months. Backlog may not be indicative of future operating results as orders may be cancelled or modified by our customers. Our backlog does not include service and maintenance-type contracts for which we have the right to invoice as services are performed.

[0000080420-19-000039:mdna:69]
Contract Estimates

[0000080420-19-000039:mdna:70]
Actual revenues and project costs may vary from previous estimates due to changes in a variety of factors. The cost estimation process is based upon the professional knowledge and experience of our engineers, project managers and financial professionals. Factors that are considered in estimating the work to be completed and ultimate contract recovery include the availability and productivity of labor, the nature and complexity of the work to be performed, the availability of materials, and the effect of any delays on our project performance. We periodically review our job performance, job conditions, estimated profitability and final contract settlements, including our estimate of total costs and make revisions to costs and income in the period in which the revisions are probable and reasonably estimable. Whenever revisions of estimated contract costs and contract values indicate that the contract costs will exceed estimated revenues, thus creating a loss, a provision for the total estimated loss is recorded in that period.

[0000080420-19-000039:mdna:71]
For Fiscal 2019 and Fiscal 2018, our operating results were positively impacted by $5.1 million and $3.9 million, respectively, as a result of changes in contract estimates related to projects in progress at the beginning of the respective period. These changes in estimates resulted primarily from favorable project execution and negotiations of variable consideration as well as other changes in facts and circumstances during these periods.

[0000080420-19-000039:mdna:72]
Allowance for Doubtful Accounts

[0000080420-19-000039:mdna:73]
We maintain and continually assess the adequacy of an allowance for doubtful accounts representing our estimate for losses resulting from the inability of our customers to pay amounts due to us. This estimated allowance is based on historical experience of uncollected accounts, the level of past due accounts, the overall level of outstanding accounts receivable, information about specific customers with respect to their inability to make payments and expectations of future conditions that could impact the collectability of accounts receivable. However, future changes in our customers’ operating performance and cash flows, or in general economic conditions, could have an impact on their ability to fully pay these amounts, which, among other things, could have a material adverse impact on our operating results.

[0000080420-19-000039:mdna:74]
Impairment of Long-Lived Assets

[0000080420-19-000039:mdna:75]
We review long-lived assets for impairment whenever events or changes in circumstances indicate that the carrying value may not be realizable. If an evaluation is required, the estimated future undiscounted cash flows associated with the asset are compared to the asset’s carrying amount to determine if recording an impairment of such asset is necessary. This requires us to make long-term forecasts of the future revenues and costs related to the assets subject to review. Forecasts require assumptions about demand for our products and future market conditions. Estimating future cash flows requires significant judgment, and our projections may vary from cash flows eventually realized. Future events and unanticipated changes to assumptions could require a provision for impairment in a future period. The effect of any impairment would be reflected in income (loss) from operations in the Consolidated Statements of Operations. In addition, we estimate the useful lives of our long-lived assets and other intangibles and periodically review these estimates to determine whether these lives are appropriate.

[0000080420-19-000039:mdna:76]
Accruals for Contingent Liabilities

[0000080420-19-000039:mdna:77]
From time to time, contingencies such as insurance-related claims, liquidated damages and legal claims arise in the normal course of business. Pursuant to applicable accounting standards, we must evaluate such contingencies to subjectively determine the likelihood that an asset has been impaired, or a liability has been incurred at the date of the financial statements, as well as evaluate whether the amount of the loss can be reasonably estimated. If the likelihood is determined to be probable, and it can be reasonably estimated, the estimated loss is recorded. The amounts we record for contingent liabilities require judgments regarding the amount of expenses that will ultimately be incurred. We use past experience and history, as well as the specific circumstances surrounding each contingent liability, including estimated legal costs, in evaluating the amount of liability that should be recorded. Actual results could differ from our estimates.

[0000080420-19-000039:mdna:78]
Warranty Costs

[0000080420-19-000039:mdna:79]
We provide for estimated warranty costs with the recognition of revenue based upon historical rates applicable to individual product lines. In addition, specific provisions are made when the costs of such warranties are expected to exceed accruals. Our standard terms and conditions of sale include a warranty for parts and service for the earlier of 18 months from the date of shipment or 12 months from the date of energization, whichever occurs first. Occasionally projects require warranty terms that are longer than our standard terms due to the nature of the project. Extended warranty terms may be negotiated and included in our contracts. We use past experience and historical claims to determine the estimated liability. Actual results could differ from our estimate.

[0000080420-19-000039:mdna:80]
Accounting for Income Taxes

[0000080420-19-000039:mdna:81]
We account for income taxes under the asset and liability method, based on the income tax laws and rates in the countries in which operations are conducted, and income is earned. This approach requires the recognition of deferred tax assets and liabilities for the expected future tax consequences of temporary differences between the carrying amounts and the tax basis of assets and liabilities. Developing our provision for income taxes requires significant judgment and expertise in federal, international and state income tax laws, regulations and strategies, including the determination of deferred tax assets and liabilities and, if necessary, any valuation allowances that may be required for deferred tax assets. In assessing the extent to which net deferred tax assets may be realized, we consider whether it is more likely than not that some portion or all of the net deferred tax assets may not be realized. The ultimate realization of net deferred tax assets is dependent on the generation of future taxable income during the periods in which those temporary differences become deductible. Estimates may change as new events occur, estimates of future taxable income during the carryforward period are reduced or increased, additional information becomes available, or operating environments change, which may result in a full or partial reversal of the valuation allowance. We will continue to assess the adequacy of the valuation allowance on a quarterly basis. Our judgments and tax strategies are subject to audit by various taxing authorities.

[0000080420-19-000039:mdna:82]
The objectives of accounting for income taxes are to recognize the amount of taxes payable or refundable for the current year and deferred tax liabilities and assets for the future tax consequences of events that have been recognized in an entity’s financial statements or tax returns. We recognize the tax benefit from an uncertain tax position only if it is more likely than not that the tax position will be sustained on examination by the taxing authorities, based on the technical merits of the position. The tax benefits recognized in the financial statements from such a position should be measured based on the largest benefit that has a greater than 50% likelihood of being realized upon ultimate settlement. Accounting literature also provides guidance on derecognition of income tax assets and liabilities, classification of current and deferred income tax assets and liabilities, accounting for interest and penalties associated with tax positions, and income tax disclosures. Judgment is required in assessing the future tax consequences of events that have been recognized in our financial statements or tax returns. Variations in the actual outcome of these future tax consequences could materially impact our financial position and results of operations.

[0000080420-19-000039:mdna:83]
See Note I of Notes to Consolidated Financial Statements for disclosures related to the valuation allowance recorded in relation to foreign deferred taxes.

[0000080420-19-000039:mdna:84]
Foreign Currency Translation

[0000080420-19-000039:mdna:85]
The functional currency for our foreign operating subsidiaries is the local currency in which the entity is located. The financial statements of all subsidiaries with a functional currency other than the U.S. Dollar have been translated into U.S. Dollars. All assets and liabilities of foreign operations are translated into U.S. Dollars using year-end exchange rates, and all revenues and expenses are translated at average rates during the respective period. The U.S. Dollar results that arise from such translation, as well as exchange gains and losses on intercompany balances of a long-term investment nature, are included in the cumulative currency translation adjustments in accumulated other comprehensive loss in stockholders’ equity.
