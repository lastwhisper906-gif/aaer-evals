# POWL note change history — 0001564590-15-000466 → 0001564590-15-003392


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2015-05-06):
[0001564590-15-003392:note_history:1]
Certain customers require us to post bank letter of credit guarantees or performance bonds issued by a surety. These guarantees and performance bonds assure that we will perform under the terms of our contract. In the event of default, the counterparty may demand payment from the bank under a letter of credit or performance by the surety under a performance bond. To date, there have been no significant expenses related to either letters of credit or performance bonds for the periods reported. We were contingently liable for secured and unsecured letters of credit of $18.0 million as of March 31, 2015. We also had performance and maintenance bonds totaling $300.9 million that were outstanding, with additional bonding capacity of $299.1 million available, at March 31, 2015.
  (was, 2015-02-04, similarity 0.9829):
[0001564590-15-000466:note_history:1]
Certain customers require us to post bank letter of credit guarantees or performance bonds issued by a surety. These guarantees and performance bonds assure that we will perform under the terms of our contract. In the event of default, the counterparty may demand payment from the bank under a letter of credit or performance by the surety under a performance bond. To date, there have been no significant expenses related to either letters of credit or performance bonds for the periods reported. We were contingently liable for secured and unsecured letters of credit of $18.3 million as of December 31, 2014. We also had performance and maintenance bonds totaling $311.9 million that were outstanding, with additional bonding capacity of $288.1 million available, at December 31, 2014.

- changed (2015-05-06):
[0001564590-15-003392:note_history:2]
We have a $14.8 million facility agreement (Facility Agreement) between Powell (UK) Limited and a large international bank. This Facility Agreement provides Powell (UK) the ability to enter into bank guarantees as well as forward exchange contracts and currency options. At March 31, 2015, we had outstanding guarantees totaling $5.3 million under this Facility Agreement.  Amounts available under this Facility Agreement were $9.5 million as of March 31, 2015.
  (was, 2015-02-04, similarity 0.9617):
[0001564590-15-000466:note_history:2]
We have a $15.5 million facility agreement (Facility Agreement) between Powell (UK) Limited and a large international bank. This Facility Agreement provides Powell (UK) the ability to enter into bank guarantees as well as forward exchange contracts and currency options. At December 31, 2014, we had outstanding guarantees totaling $3.9 million under this Facility Agreement.  Amounts available under this Facility Agreement were $11.6 million as of December 31, 2014.

- changed (2015-05-06):
[0001564590-15-003392:note_history:3]
The Facility Agreement provides for financial covenants and customary events of default, and carries cross-default provisions with our Amended Credit Facility. If an event of default (as defined in the Facility Agreement) occurs and is continuing, per the terms and subject to the conditions set forth in the Facility Agreement, obligations outstanding under the Facility Agreement may be accelerated and may become or be declared immediately due and payable. As of March 31, 2015, we were in compliance with all of the financial covenants of the Facility Agreement.
  (was, 2015-02-04, similarity 0.9884):
[0001564590-15-000466:note_history:3]
The Facility Agreement provides for financial covenants and customary events of default, and carries cross-default provisions with our Amended Credit Facility. If an event of default (as defined in the Facility Agreement) occurs and is continuing, per the terms and subject to the conditions set forth in the Facility Agreement, obligations outstanding under the Facility Agreement may be accelerated and may become or be declared immediately due and payable. As of December 31, 2014, we were in compliance with all of the financial covenants of the Facility Agreement.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureAndSignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2015-05-06):
[0001564590-15-003392:note_history:4]
|  | Six months ended March 31, |
|  | 2015 |  |  |  |  | 2014 |  |
| Non-cash capital expenditures | $ | 3,351 |  |  |  |  | $ | 389 |  |
  (was, 2015-02-04, similarity 0.917):
[0001564590-15-000466:note_history:4]
|  | Three months ended December 31, |
|  | 2014 |  |  |  |  | 2013 |  |
| Non-cash capital expenditures | $ | 8,727 |  |  |  |  | $ | — |  |

- added (2015-05-06):
[0001564590-15-003392:note_history:5]
In January 2014, we sold our wholly owned subsidiary Transdyn Inc. (Transdyn).  For the quarter and six months ended March 31, 2014, we have presented the results of these operations as income from discontinued operations, net of tax.  See Note J.

- removed (2015-05-06):
[0001564590-15-000466:note_history:6]
In January 2014, we sold our wholly owned subsidiary Transdyn Inc. (Transdyn).  For the quarter ended December 31, 2013, we have presented the results of these operations as income from discontinued operations, net of tax.  See Note I.


## us-gaap:LongTermDebtTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2015-05-06):
[0001564590-15-003392:note_history:7]
|  | March 31, 2015 |  |  | September 30, 2014 |  |
| Industrial development revenue bonds | $ | 2,800 |  |  | $ | 3,200 |  |
| Less current portion |  | (400 | ) |  |  | (400 | ) |
| Total long-term debt and capital lease obligations | $ | 2,400 |  |  | $ | 2,800 |  |
  (was, 2015-02-04, similarity 0.9758):
[0001564590-15-000466:note_history:7]
|  | December 31, 2014 |  |  | September 30, 2014 |  |
| Industrial development revenue bonds | $ | 2,800 |  |  | $ | 3,200 |  |
| Less current portion |  | (400 | ) |  |  | (400 | ) |
| Total long-term debt and capital lease obligations | $ | 2,400 |  |  | $ | 2,800 |  |

- changed (2015-05-06):
[0001564590-15-003392:note_history:8]
The U.S. Revolver provides for the issuance of letters of credit which reduce the amounts that may be borrowed under this revolver. The amount available under the U.S. Revolver was reduced by $18.0 million for our outstanding letters of credit at March 31, 2015.
  (was, 2015-02-04, similarity 0.9745):
[0001564590-15-000466:note_history:8]
The U.S. Revolver provides for the issuance of letters of credit which reduce the amounts that may be borrowed under this revolver. The amount available under the U.S. Revolver was reduced by $18.3 million for our outstanding letters of credit at December 31, 2014.

- changed (2015-05-06):
[0001564590-15-003392:note_history:9]
There were no borrowings outstanding under the U.S. Revolver as of March 31, 2015.  Amounts available under the U.S. Revolver were $57.0 million at March 31, 2015. The U.S. Revolver expires on December 31, 2018.
  (was, 2015-02-04, similarity 0.9531):
[0001564590-15-000466:note_history:9]
There were no borrowings outstanding under the U.S. Revolver as of December 31, 2014. Amounts available under the U.S. Revolver were $56.7 million at December 31, 2014. The U.S. Revolver expires on December 31, 2018.

- changed (2015-05-06):
[0001564590-15-003392:note_history:10]
The Amended Credit Agreement is collateralized by a pledge of 100% of the voting capital stock of each of our domestic subsidiaries and 65% of the voting capital stock of each non-domestic subsidiary, excluding Powell Canada. The Amended Credit Agreement provides for customary events of default and carries cross-default provisions with other existing debt agreements. If an event of default (as defined in the Amended Credit Agreement) occurs and is continuing, on the terms and subject to the conditions set forth in the Amended Credit Agreement, amounts outstanding under the Amended Credit Agreement may be accelerated and may become immediately due and payable. As of March 31, 2015, we were in compliance with all of the financial covenants of the Amended Credit Agreement.
  (was, 2015-02-04, similarity 0.9916):
[0001564590-15-000466:note_history:10]
The Amended Credit Agreement is collateralized by a pledge of 100% of the voting capital stock of each of our domestic subsidiaries and 66% of the voting capital stock of each non-domestic subsidiary, excluding Powell Canada. The Amended Credit Agreement provides for customary events of default and carries cross-default provisions with other existing debt agreements. If an event of default (as defined in the Amended Credit Agreement) occurs and is continuing, on the terms and subject to the conditions set forth in the Amended Credit Agreement, amounts outstanding under the Amended Credit Agreement may be accelerated and may become immediately due and payable. As of December 31, 2014, we were in compliance with all of the financial covenants of the Amended Credit Agreement.

- added (2015-05-06):
[0001564590-15-003392:note_history:11]
On April 15, 2015, we completed the renegotiation of a credit agreement with a major international bank in Canada (the Canadian Revolver) to provide working capital support and letters of credit for our operations in Canada to replace our $7.9 million agreement which expired on February 28, 2015. The Canadian Revolver provides for the issuance of letters of credit which reduce the amounts that may be borrowed under this revolver.

- changed (2015-05-06):
[0001564590-15-003392:note_history:12]
The interest rate for amounts outstanding under the Canadian Revolver is a floating interest rate based upon either the Canadian Prime Rate, or the lender’s Bankers’ Acceptance Rate. Once the applicable rate is determined, a margin of 0.50% to 1.75%, as determined by our consolidated leverage ratio, is added to the applicable rate.
  (was, 2015-02-04, similarity 0.7552):
[0001564590-15-000466:note_history:12]
There were no borrowings outstanding under the Canadian Revolver as of December 31, 2014 and amounts available under the Canadian Revolver were $8.6 million at December 31, 2014. The Canadian Revolver expires on February 28, 2015. The interest rate for amounts outstanding under the Canadian Revolver is a floating interest rate based upon either the Canadian Prime Rate, or the lender’s Bankers’ Acceptance Rate. Once the applicable rate is determined, a margin of 0.50% to 1.75%, as determined by our consolidated leverage ratio, is added to the applicable rate.

- changed (2015-05-06):
[0001564590-15-003392:note_history:13]
The Canadian Revolver is secured by the assets of our Canadian operations and provides for customary events of default and carries cross-default provisions with our existing debt agreements. If an event of default (as defined in the Canadian Revolver) occurs and is continuing, per the terms and subject to the conditions set forth in the Canadian Revolver, amounts outstanding under the Canadian Revolver may be accelerated and may become immediately due and payable.
  (was, 2015-02-04, similarity 0.9009):
[0001564590-15-000466:note_history:13]
The Canadian Revolver is secured by the assets of our Canadian operations and provides for customary events of default and carries cross-default provisions with our existing debt agreements. If an event of default (as defined in the Canadian Revolver) occurs and is continuing, per the terms and subject to the conditions set forth in the Canadian Revolver, amounts outstanding under the Canadian Revolver may be accelerated and may become immediately due and payable. As of December 31, 2014, we were in compliance with all of the financial covenants of the Canadian Revolver.

- changed (2015-05-06):
[0001564590-15-003392:note_history:14]
We borrowed $8.0 million in October 2001 through a loan agreement funded with proceeds from tax-exempt industrial development revenue bonds (Bonds). These Bonds were issued by the Illinois Development Finance Authority and were used for the completion of our Northlake, Illinois facility. Pursuant to the Bond issuance, a reimbursement agreement between us and a major domestic bank required an issuance by the bank of an irrevocable direct-pay letter of credit (Bond LC), as collateral, to the Bonds’ trustee to guarantee payment of the Bonds’ principal and interest when due. The Bond LC is subject to both early termination and extension provisions customary to such agreements, as well as various covenants, for which we were in compliance at March 31, 2015. While the Bonds mature in 2021, the reimbursement agreement requires annual redemptions of $0.4 million that commenced on October 25, 2002. A sinking fund is used for the redemption of the Bonds. At March 31, 2015, the balance in the restricted sinking fund was approximately $0.2 million and was recorded in cash and cash equivalents. The Bonds bear interest at a floating rate determined weekly by the Bonds’ remarketing agent, which was the underwriter for the Bonds and is an affiliate of the bank. This interest rate was 0.16% as of March 31, 2015.
  (was, 2015-02-04, similarity 0.9816):
[0001564590-15-000466:note_history:14]
We borrowed $8.0 million in October 2001 through a loan agreement funded with proceeds from tax-exempt industrial development revenue bonds (Bonds). These Bonds were issued by the Illinois Development Finance Authority and were used for the completion of our Northlake, Illinois facility. Pursuant to the Bond issuance, a reimbursement agreement between us and a major domestic bank required an issuance by the bank of an irrevocable direct-pay letter of credit (Bond LC), as collateral, to the Bonds’ trustee to guarantee payment of the Bonds’ principal and interest when due. The Bond LC is subject to both early termination and extension provisions customary to such agreements, as well as various covenants, for which we were in compliance at December 31, 2014. While the Bonds mature in 2021, the reimbursement agreement requires annual redemptions of $0.4 million that commenced on October 25, 2002. A sinking fund is used for the redemption of the Bonds. At December 31, 2014, the balance in the restricted sinking fund was approximately $0.1 million and was recorded in cash and cash equivalents. The Bonds bear interest at a floating rate determined weekly by the Bonds’ remarketing agent, which was the underwriter for the Bonds and is an affiliate of the bank. This interest rate was 0.18% as of December 31, 2014.

- removed (2015-05-06):
[0001564590-15-000466:note_history:15]
We have an $8.6 million credit agreement with a major international bank in Canada (the Canadian Revolver) to provide working capital support and letters of credit for our operations in Canada. The Canadian Revolver provides for the issuance of letters of credit which reduce the amounts that may be borrowed under this revolver.  There were no outstanding letters of credit under the Canadian Revolver at December 31, 2014.


## us-gaap:ScheduleOfDebtInstrumentsTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2015-05-06):
[0001564590-15-003392:note_history:16]
|  | March 31, 2015 |  |  | September 30, 2014 |  |
| Industrial development revenue bonds | $ | 2,800 |  |  | $ | 3,200 |  |
| Less current portion |  | (400 | ) |  |  | (400 | ) |
| Total long-term debt and capital lease obligations | $ | 2,400 |  |  | $ | 2,800 |  |
  (was, 2015-02-04, similarity 0.9758):
[0001564590-15-000466:note_history:16]
|  | December 31, 2014 |  |  | September 30, 2014 |  |
| Industrial development revenue bonds | $ | 2,800 |  |  | $ | 3,200 |  |
| Less current portion |  | (400 | ) |  |  | (400 | ) |
| Total long-term debt and capital lease obligations | $ | 2,400 |  |  | $ | 2,800 |  |
