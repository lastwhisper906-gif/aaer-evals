# POWL notes — 0001564590-15-003392


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureAndSignificantAccountingPoliciesTextBlock

[0001564590-15-003392:notes:1]
[same as prior period, unchanged from 0001564590-15-000466:notes:1]

[0001564590-15-003392:notes:2]
[same as prior period, unchanged from 0001564590-15-000466:notes:2]

[0001564590-15-003392:notes:3]
[same as prior period, unchanged from 0001564590-15-000466:notes:3]

[0001564590-15-003392:notes:4]
We develop, design, manufacture and service custom-engineered equipment and systems for the distribution, control and monitoring of electrical energy designed to (1) distribute, monitor and control the flow of electrical energy and (2) provide protection to motors, transformers and other electrically powered equipment. Headquartered in Houston, Texas, we serve the transportation, energy, industrial and utility industries.

[0001564590-15-003392:notes:5]
[same as prior period, unchanged from 0001564590-15-000466:notes:5]

[0001564590-15-003392:notes:6]
[same as prior period, unchanged from 0001564590-15-000466:notes:6]

[0001564590-15-003392:notes:7]
[same as prior period, unchanged from 0001564590-15-000466:notes:7]

[0001564590-15-003392:notes:8]
[same as prior period, unchanged from 0001564590-15-000466:notes:8]

[0001564590-15-003392:notes:9]
[same as prior period, unchanged from 0001564590-15-000466:notes:9]

[0001564590-15-003392:notes:10]
[same as prior period, unchanged from 0001564590-15-000466:notes:10]

[0001564590-15-003392:notes:11]
[same as prior period, unchanged from 0001564590-15-000466:notes:11]

[0001564590-15-003392:notes:12]
[same as prior period, unchanged from 0001564590-15-000466:notes:12]

[0001564590-15-003392:notes:13]
|  | Six months ended March 31, |
|  | 2015 |  |  |  |  | 2014 |  |
| Non-cash capital expenditures | $ | 3,351 |  |  |  |  | $ | 389 |  |

[0001564590-15-003392:notes:14]
[same as prior period, unchanged from 0001564590-15-000466:notes:14]

[0001564590-15-003392:notes:15]
[same as prior period, unchanged from 0001564590-15-000466:notes:15]

[0001564590-15-003392:notes:16]
[same as prior period, unchanged from 0001564590-15-000466:notes:16]

[0001564590-15-003392:notes:17]
[same as prior period, unchanged from 0001564590-15-000466:notes:17]

[0001564590-15-003392:notes:18]
[same as prior period, unchanged from 0001564590-15-000466:notes:18]

[0001564590-15-003392:notes:19]
[same as prior period, unchanged from 0001564590-15-000466:notes:19]

[0001564590-15-003392:notes:20]
In January 2014, we sold our wholly owned subsidiary Transdyn Inc. (Transdyn).  For the quarter and six months ended March 31, 2014, we have presented the results of these operations as income from discontinued operations, net of tax.  See Note J.


## us-gaap:EarningsPerShareTextBlock

[0001564590-15-003392:notes:21]
[same as prior period, unchanged from 0001564590-15-000466:notes:21]

[0001564590-15-003392:notes:22]
[same as prior period, unchanged from 0001564590-15-000466:notes:22]

[0001564590-15-003392:notes:23]
[same as prior period, unchanged from 0001564590-15-000466:notes:23]

[0001564590-15-003392:notes:24]
|  | Three months ended March 31, |  |  | Six months ended March 31, |  |
|  | 2015 |  |  | 2014 |  |  | 2015 |  |  | 2014 |  |
| Numerator: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Income (loss) from continuing operations | $ | (3,683 | ) |  | $ | 6,976 |  |  | $ | (3,922 | ) |  | $ | 14,243 |  |
| Income from discontinued operations |  | — |  |  |  | 8,617 |  |  |  | — |  |  |  | 9,604 |  |
| Net income (loss) | $ | (3,683 | ) |  | $ | 15,593 |  |  | $ | (3,922 | ) |  | $ | 23,847 |  |
| Denominator: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Weighted average basic shares |  | 12,018 |  |  |  | 12,004 |  |  |  | 12,029 |  |  |  | 11,999 |  |
| Dilutive effect of restricted stock units |  | — |  |  |  | 60 |  |  |  | — |  |  |  | 58 |  |
| Weighted average diluted shares with assumed conversions |  | 12,018 |  |  |  | 12,064 |  |  |  | 12,029 |  |  |  | 12,057 |  |
| Net earnings (loss) per share: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Continuing operations | $ | (0.31 | ) |  | $ | 0.58 |  |  | $ | (0.33 | ) |  | $ | 1.19 |  |
| Discontinued operations |  | — |  |  |  | 0.72 |  |  |  | — |  |  |  | 0.80 |  |
| Basic earnings (loss) per share | $ | (0.31 | ) |  | $ | 1.30 |  |  | $ | (0.33 | ) |  | $ | 1.99 |  |
| Continuing operations | $ | (0.31 | ) |  | $ | 0.58 |  |  | $ | (0.33 | ) |  | $ | 1.18 |  |
| Discontinued operations |  | — |  |  |  | 0.71 |  |  |  | — |  |  |  | 0.80 |  |
| Diluted earnings (loss) per share | $ | (0.31 | ) |  | $ | 1.29 |  |  | $ | (0.33 | ) |  | $ | 1.98 |  |

[0001564590-15-003392:notes:25]
For the quarter and six months ended March 31, 2015, we incurred a net loss and therefore all potential common shares were deemed to be anti-dilutive.


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0001564590-15-003392:notes:26]
[same as prior period, unchanged from 0001564590-15-000466:notes:26]

[0001564590-15-003392:notes:27]
[same as prior period, unchanged from 0001564590-15-000466:notes:27]

[0001564590-15-003392:notes:28]
[same as prior period, unchanged from 0001564590-15-000466:notes:28]

[0001564590-15-003392:notes:29]
|  | Three months ended March 31, |  |  | Six months ended March 31, |  |
|  | 2015 |  |  | 2014 |  |  | 2015 |  |  | 2014 |  |
| Balance at beginning of period | $ | 1,844 |  |  | $ | 673 |  |  | $ | 1,577 |  |  | $ | 572 |  |
| Bad debt expense/(recovery) |  | 186 |  |  |  | (170 | ) |  |  | 469 |  |  |  | (60 | ) |
| Uncollectible accounts written off, net of recoveries |  | (120 | ) |  |  | — |  |  |  | (122 | ) |  |  | (9 | ) |
| Change in foreign currency translation |  | (29 | ) |  |  | (2 | ) |  |  | (43 | ) |  |  | (2 | ) |
| Balance at end of period | $ | 1,881 |  |  | $ | 501 |  |  | $ | 1,881 |  |  | $ | 501 |  |

[0001564590-15-003392:notes:30]
[same as prior period, unchanged from 0001564590-15-000466:notes:30]

[0001564590-15-003392:notes:31]
[same as prior period, unchanged from 0001564590-15-000466:notes:31]

[0001564590-15-003392:notes:32]
|  | March 31, 2015 |  |  | September 30, 2014 |  |
| Raw materials, parts and subassemblies | $ | 39,063 |  |  | $ | 35,349 |  |
| Work-in-progress |  | 1,558 |  |  |  | 2,035 |  |
| Provision for excess and obsolete inventory |  | (4,886 | ) |  |  | (4,569 | ) |
| Total inventories | $ | 35,735 |  |  | $ | 32,815 |  |

[0001564590-15-003392:notes:33]
[same as prior period, unchanged from 0001564590-15-000466:notes:33]

[0001564590-15-003392:notes:34]
[same as prior period, unchanged from 0001564590-15-000466:notes:34]

[0001564590-15-003392:notes:35]
|  | March 31, |  |  | September 30, |  |
|  | 2015 |  |  | 2014 |  |
| Costs incurred on uncompleted contracts | $ | 618,778 |  |  | $ | 604,939 |  |
| Estimated earnings |  | 161,724 |  |  |  | 157,562 |  |
|  |  | 780,502 |  |  |  | 762,501 |  |
| Less: Billings to date |  | (747,964 | ) |  |  | (715,233 | ) |
| Net underbilled position | $ | 32,538 |  |  | $ | 47,268 |  |
| Included in the accompanying balance sheets under the following captions: |  |  |  |  |  |  |  |
| Costs and estimated earnings in excess of billings on uncompleted contracts - underbilled | $ | 96,709 |  |  | $ | 95,970 |  |
| Billings in excess of costs and estimated earnings on uncompleted contracts - overbilled |  | (64,171 | ) |  |  | (48,702 | ) |
| Net underbilled position | $ | 32,538 |  |  | $ | 47,268 |  |

[0001564590-15-003392:notes:36]
[same as prior period, unchanged from 0001564590-15-000466:notes:36]

[0001564590-15-003392:notes:37]
[same as prior period, unchanged from 0001564590-15-000466:notes:37]

[0001564590-15-003392:notes:38]
|  | Three months ended March 31, |  |  | Six months ended March 31, |  |
|  | 2015 |  |  | 2014 |  |  | 2015 |  |  | 2014 |  |
| Balance at beginning of period | $ | 4,480 |  |  | $ | 5,010 |  |  | $ | 4,557 |  |  | $ | 5,282 |  |
| Increase to warranty expense |  | 530 |  |  |  | 1,042 |  |  |  | 1,067 |  |  |  | 1,505 |  |
| Deduction for warranty charges |  | (504 | ) |  |  | (1,196 | ) |  |  | (1,028 | ) |  |  | (1,926 | ) |
| Increase (decrease) due to foreign currency translations |  | (131 | ) |  |  | (23 | ) |  |  | (221 | ) |  |  | (28 | ) |
| Balance at end of period | $ | 4,375 |  |  | $ | 4,833 |  |  | $ | 4,375 |  |  | $ | 4,833 |  |


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0001564590-15-003392:notes:39]
[same as prior period, unchanged from 0001564590-15-000466:notes:39]

[0001564590-15-003392:notes:40]
Intangible assets balances, subject to amortization, at March 31, 2015 and September 30, 2014 consisted of the following (in thousands):

[0001564590-15-003392:notes:41]
|  | March 31, 2015 |  |  | September 30, 2014 |  |
|  | Gross |  |  |  |  |  |  | Net |  |  | Gross |  |  |  |  |  |  | Net |  |
|  | Carrying |  |  | Accumulated |  |  | Carrying |  |  | Carrying |  |  | Accumulated |  |  | Carrying |  |
|  | Value |  |  | Amortization |  |  | Value |  |  | Value |  |  | Amortization |  |  | Value |  |
| Purchased technology | $ | 11,749 |  |  | $ | (10,165 | ) |  | $ | 1,584 |  |  | $ | 11,749 |  |  | $ | (9,918 | ) |  | $ | 1,831 |  |
| Trade name |  | 1,136 |  |  |  | (1,113 | ) |  |  | 23 |  |  |  | 1,136 |  |  |  | (1,063 | ) |  |  | 73 |  |
| Total | $ | 12,885 |  |  | $ | (11,278 | ) |  | $ | 1,607 |  |  | $ | 12,885 |  |  | $ | (10,981 | ) |  | $ | 1,904 |  |

[0001564590-15-003392:notes:42]
Amortization of intangible assets recorded for the six months ended March 31, 2015 and 2014 was $0.2 million and $0.5 million, respectively.

[0001564590-15-003392:notes:43]
On August 7, 2006, we purchased certain assets related to the manufacturing of ANSI medium-voltage switchgear and circuit breaker business from General Electric Company (GE).  In connection with the acquisition, we entered into a 15 year supply agreement with GE pursuant to which GE would purchase from the Company all of its requirements for ANSI medium-voltage switchgear and circuit breakers and other related equipment and components (the Products).  In connection with the acquisition, we recorded an intangible asset related to this supply agreement.  On December 30, 2013, the Company and GE amended the supply agreement to allow GE to manufacture similar Products for sale immediately and allow GE to begin purchasing Products from other suppliers beginning December 31, 2014.  In return, GE paid us $10 million upon execution of the amended supply agreement in the first quarter of Fiscal 2014 and agreed to pay an additional $7 million over three years.  The first payment of $2.3 million was received in March 2015.  We wrote off the intangible asset related to the original supply agreement and recorded a deferred credit in the amount of $8.1 million at December 31, 2013, the amount by which the proceeds from GE exceeded the unamortized balance of our intangible asset. This deferred credit is being amortized over the four year life of the agreement.


## us-gaap:LongTermDebtTextBlock

[0001564590-15-003392:notes:44]
E. LONG-TERM DEBT

[0001564590-15-003392:notes:45]
Long-term debt consisted of the following (in thousands):

[0001564590-15-003392:notes:46]
|  | March 31, 2015 |  |  | September 30, 2014 |  |
| Industrial development revenue bonds | $ | 2,800 |  |  | $ | 3,200 |  |
| Less current portion |  | (400 | ) |  |  | (400 | ) |
| Total long-term debt and capital lease obligations | $ | 2,400 |  |  | $ | 2,800 |  |

[0001564590-15-003392:notes:47]
U.S. Revolver

[0001564590-15-003392:notes:48]
In December 2013, we amended and restated our existing credit agreement (the Amended Credit Agreement) with a major domestic bank.  In December 2014, we entered into the Second Amendment of the Amended Credit Agreement (the Second Amendment).  The Second Amendment provides for the expansion of our Canadian manufacturing facility and allows for the repurchase of our common stock pursuant to a share repurchase program announced in December 2014. The Amended Credit Agreement provides for a $75.0 million revolving credit facility (U.S. Revolver). Obligations are collateralized by the stock of certain of our subsidiaries.

[0001564590-15-003392:notes:49]
The interest rate for amounts outstanding under the Amended Credit Agreement for the U.S. Revolver is a floating rate based upon the higher of the Federal Funds Rate plus 0.5%, the bank’s prime rate, or the Eurocurrency rate plus 1.00%. Once the applicable rate is determined, a margin ranging up to 1.75%, as determined by our consolidated leverage ratio, is added to the applicable rate.

[0001564590-15-003392:notes:50]
The U.S. Revolver provides for the issuance of letters of credit which reduce the amounts that may be borrowed under this revolver. The amount available under the U.S. Revolver was reduced by $18.0 million for our outstanding letters of credit at March 31, 2015.

[0001564590-15-003392:notes:51]
There were no borrowings outstanding under the U.S. Revolver as of March 31, 2015.  Amounts available under the U.S. Revolver were $57.0 million at March 31, 2015. The U.S. Revolver expires on December 31, 2018.

[0001564590-15-003392:notes:52]
The Amended Credit Agreement contains certain restrictive and maintenance-type covenants, such as restrictions on the amount of capital expenditures allowed. It also contains financial covenants defining various financial measures and the levels of these measures with which we must comply, as well as a “material adverse change” clause. A “material adverse change” is defined as a material change in our operations, business, properties, liabilities or condition (financial or otherwise) or a material impairment of our ability to perform our obligations under our credit agreements.

[0001564590-15-003392:notes:53]
The Amended Credit Agreement is collateralized by a pledge of 100% of the voting capital stock of each of our domestic subsidiaries and 65% of the voting capital stock of each non-domestic subsidiary, excluding Powell Canada. The Amended Credit Agreement provides for customary events of default and carries cross-default provisions with other existing debt agreements. If an event of default (as defined in the Amended Credit Agreement) occurs and is continuing, on the terms and subject to the conditions set forth in the Amended Credit Agreement, amounts outstanding under the Amended Credit Agreement may be accelerated and may become immediately due and payable. As of March 31, 2015, we were in compliance with all of the financial covenants of the Amended Credit Agreement.

[0001564590-15-003392:notes:54]
Canadian Revolver

[0001564590-15-003392:notes:55]
On April 15, 2015, we completed the renegotiation of a credit agreement with a major international bank in Canada (the Canadian Revolver) to provide working capital support and letters of credit for our operations in Canada to replace our $7.9 million agreement which expired on February 28, 2015. The Canadian Revolver provides for the issuance of letters of credit which reduce the amounts that may be borrowed under this revolver.

[0001564590-15-003392:notes:56]
The interest rate for amounts outstanding under the Canadian Revolver is a floating interest rate based upon either the Canadian Prime Rate, or the lender’s Bankers’ Acceptance Rate. Once the applicable rate is determined, a margin of 0.50% to 1.75%, as determined by our consolidated leverage ratio, is added to the applicable rate.

[0001564590-15-003392:notes:57]
The principal financial covenants are consistent with those described in our Amended Credit Agreement. The Canadian Revolver contains a “material adverse effect” clause. A “material adverse effect” is defined as a material change in the operations of Powell or Powell Canada in relation to our financial condition, property, business operations, expected net cash flows, liabilities or capitalization.

[0001564590-15-003392:notes:58]
The Canadian Revolver is secured by the assets of our Canadian operations and provides for customary events of default and carries cross-default provisions with our existing debt agreements. If an event of default (as defined in the Canadian Revolver) occurs and is continuing, per the terms and subject to the conditions set forth in the Canadian Revolver, amounts outstanding under the Canadian Revolver may be accelerated and may become immediately due and payable.

[0001564590-15-003392:notes:59]
Industrial Development Revenue Bonds

[0001564590-15-003392:notes:60]
We borrowed $8.0 million in October 2001 through a loan agreement funded with proceeds from tax-exempt industrial development revenue bonds (Bonds). These Bonds were issued by the Illinois Development Finance Authority and were used for the completion of our Northlake, Illinois facility. Pursuant to the Bond issuance, a reimbursement agreement between us and a major domestic bank required an issuance by the bank of an irrevocable direct-pay letter of credit (Bond LC), as collateral, to the Bonds’ trustee to guarantee payment of the Bonds’ principal and interest when due. The Bond LC is subject to both early termination and extension provisions customary to such agreements, as well as various covenants, for which we were in compliance at March 31, 2015. While the Bonds mature in 2021, the reimbursement agreement requires annual redemptions of $0.4 million that commenced on October 25, 2002. A sinking fund is used for the redemption of the Bonds. At March 31, 2015, the balance in the restricted sinking fund was approximately $0.2 million and was recorded in cash and cash equivalents. The Bonds bear interest at a floating rate determined weekly by the Bonds’ remarketing agent, which was the underwriter for the Bonds and is an affiliate of the bank. This interest rate was 0.16% as of March 31, 2015.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001564590-15-003392:notes:61]
F. COMMITMENTS AND CONTINGENCIES

[0001564590-15-003392:notes:62]
Long-Term Debt

[0001564590-15-003392:notes:63]
See Note E herein for discussion of our long-term debt.

[0001564590-15-003392:notes:64]
Letters of Credit and Bonds

[0001564590-15-003392:notes:65]
Certain customers require us to post bank letter of credit guarantees or performance bonds issued by a surety. These guarantees and performance bonds assure that we will perform under the terms of our contract. In the event of default, the counterparty may demand payment from the bank under a letter of credit or performance by the surety under a performance bond. To date, there have been no significant expenses related to either letters of credit or performance bonds for the periods reported. We were contingently liable for secured and unsecured letters of credit of $18.0 million as of March 31, 2015. We also had performance and maintenance bonds totaling $300.9 million that were outstanding, with additional bonding capacity of $299.1 million available, at March 31, 2015.

[0001564590-15-003392:notes:66]
We have a $14.8 million facility agreement (Facility Agreement) between Powell (UK) Limited and a large international bank. This Facility Agreement provides Powell (UK) the ability to enter into bank guarantees as well as forward exchange contracts and currency options. At March 31, 2015, we had outstanding guarantees totaling $5.3 million under this Facility Agreement.  Amounts available under this Facility Agreement were $9.5 million as of March 31, 2015.

[0001564590-15-003392:notes:67]
The Facility Agreement provides for financial covenants and customary events of default, and carries cross-default provisions with our Amended Credit Facility. If an event of default (as defined in the Facility Agreement) occurs and is continuing, per the terms and subject to the conditions set forth in the Facility Agreement, obligations outstanding under the Facility Agreement may be accelerated and may become or be declared immediately due and payable. As of March 31, 2015, we were in compliance with all of the financial covenants of the Facility Agreement.

[0001564590-15-003392:notes:68]
Litigation

[0001564590-15-003392:notes:69]
We are involved in various legal proceedings, claims and other disputes arising in the ordinary course of business which, in general, are subject to uncertainties and in which the outcomes are not predictable. Although we can give no assurance about the outcome of pending or threatened litigation and the effect such outcomes may have on us, management believes that any ultimate liability resulting from the outcome of such proceedings, to the extent not otherwise provided or covered by insurance, will not have a material adverse effect on our consolidated financial position or results of operations or liquidity.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001564590-15-003392:notes:70]
[same as prior period, unchanged from 0001564590-15-000466:notes:70]

[0001564590-15-003392:notes:71]
[same as prior period, unchanged from 0001564590-15-000466:notes:71]

[0001564590-15-003392:notes:72]
[same as prior period, unchanged from 0001564590-15-000466:notes:72]

[0001564590-15-003392:notes:73]
[same as prior period, unchanged from 0001564590-15-000466:notes:73]

[0001564590-15-003392:notes:74]
We issue restricted stock units (RSUs) to certain officers and key employees of the Company. The RSUs typically vest over a three-year period from their date of issuance. The fair value of the RSUs is based on the closing price of our common stock as reported on the NASDAQ Global Market on the grant dates. Sixty-percent of the actual amount of the RSUs earned will be based on the cumulative earnings as reported relative to the three-year performance cycle which begins October 1 of the year granted, and ranges from 0% to 150% of the target RSUs granted. The remaining forty-percent of the RSUs are time-based and vest over a three-year period. At March 31, 2015, there were 161,337 RSUs outstanding. The RSUs do not have voting rights and do not receive dividends on common stock; additionally, the shares of common stock underlying the RSUs are not considered issued and outstanding until actually issued.

[0001564590-15-003392:notes:75]
[same as prior period, unchanged from 0001564590-15-000466:notes:75]

[0001564590-15-003392:notes:76]
|  | Number of |  |  | Weighted |  |
|  | Restricted |  |  | Average |  |
|  | Stock |  |  | Fair Value |  |
|  | Units |  |  | Per Share |  |
| Outstanding at September 30, 2014 |  | 106,845 |  |  | $ | 51.30 |  |
| Granted |  | 88,000 |  |  |  | 41.88 |  |
| Vested |  | (33,508 | ) |  |  | 44.06 |  |
| Forfeited |  | — |  |  |  | — |  |
| Outstanding at March 31, 2015 |  | 161,337 |  |  | $ | 47.66 |  |

[0001564590-15-003392:notes:77]
During the six months ended March 31, 2015 and 2014, we recorded compensation expense of $0.9 million and $1.5 million, respectively, related to the RSUs.

[0001564590-15-003392:notes:78]
[same as prior period, unchanged from 0001564590-15-000466:notes:78]

[0001564590-15-003392:notes:79]
In February 2014 our stockholders also approved the 2014 Non-Employee Director Equity Incentive Plan (the 2014 Director Plan) for the benefit of members of the Board of Directors of the Company who, at the time of their service are not employees of the Company or any of its affiliates. The 2014 Director Plan authorizes stock options, stock appreciation rights, restricted stock, restricted stock units, as well as certain other awards.  In February 2015, 16,000 shares of restricted stock were issued to such directors at a price of $33.37 per share under the 2014 Director Plan.  The annual restricted stock grants vest 50% per year over a two-year period on each anniversary of the grant date.

[0001564590-15-003392:notes:80]
During the six months ended March 31, 2015 and 2015, we recorded compensation expense of $0.7 million and $0.5 million, respectively, related to restricted stock grants.


## powl:StockRepurchaseProgramTextBlock

[0001564590-15-003392:notes:81]
H. SHARE REPURCHASE PROGRAM

[0001564590-15-003392:notes:82]
On December 17, 2014, our Board of Directors authorized a repurchase program (the Repurchase Program) under which we may repurchase up to $25 million of our outstanding stock.  The purchases may be made from time to time in the open market, through privately negotiated transactions and Rule 10b5-1 trading plans in accordance with applicable laws, rules and regulations.  The Repurchase Program will be funded from cash on hand and cash provided by operating activities.  The Repurchase Program will expire as of the close of business on December 31, 2015.  As of March 31, 2015, we have purchased 171,416 shares at cost of $5.8 million under this Repurchase Program.  The average price per share through March 31, 2015 has been $33.60.


## us-gaap:FairValueDisclosuresTextBlock

[0001564590-15-003392:notes:83]
I. FAIR VALUE MEASUREMENTS

[0001564590-15-003392:notes:84]
[same as prior period, unchanged from 0001564590-15-000466:notes:83]

[0001564590-15-003392:notes:85]
[same as prior period, unchanged from 0001564590-15-000466:notes:84]

[0001564590-15-003392:notes:86]
[same as prior period, unchanged from 0001564590-15-000466:notes:85]

[0001564590-15-003392:notes:87]
[same as prior period, unchanged from 0001564590-15-000466:notes:86]

[0001564590-15-003392:notes:88]
[same as prior period, unchanged from 0001564590-15-000466:notes:87]

[0001564590-15-003392:notes:89]
The following table summarizes the fair value of our assets and liabilities that were accounted for at fair value on a recurring basis as of March 31, 2015 (in thousands):

[0001564590-15-003392:notes:90]
|  | Fair Value Measurements at March 31, 2015 |  |
|  | Quoted Prices in |  |  | Significant Other |  |  | Significant |  |  |  |  |  |
|  | Active Markets for |  |  | Observable |  |  | Unobservable |  |  | Fair Value at |  |
|  | Identical Assets |  |  | Inputs |  |  | Inputs |  |  | March 31, |  |
|  | (Level 1) |  |  | (Level 2) |  |  | (Level 3) |  |  | 2015 |  |
| Assets: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cash equivalents | $ | 234 |  |  | $ | — |  |  | $ | — |  |  | $ | 234 |  |
| Deferred compensation |  | 2,001 |  |  |  | 3,134 |  |  |  | — |  |  |  | 5,135 |  |
| Liabilities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Deferred compensation |  | — |  |  |  | 4,947 |  |  |  | — |  |  |  | 4,947 |  |

[0001564590-15-003392:notes:91]
[same as prior period, unchanged from 0001564590-15-000466:notes:90]

[0001564590-15-003392:notes:92]
[same as prior period, unchanged from 0001564590-15-000466:notes:91]

[0001564590-15-003392:notes:93]
[same as prior period, unchanged from 0001564590-15-000466:notes:92]

[0001564590-15-003392:notes:94]
[same as prior period, unchanged from 0001564590-15-000466:notes:93]

[0001564590-15-003392:notes:95]
[same as prior period, unchanged from 0001564590-15-000466:notes:94]

[0001564590-15-003392:notes:96]
[same as prior period, unchanged from 0001564590-15-000466:notes:95]

[0001564590-15-003392:notes:97]
Industrial Development Revenue Bond – The fair value of our long-term debt depends primarily on the coupon rate of our industrial development revenue bonds.  The carrying value of our long-term debt at March 31, 2015, approximates fair value based on the current coupon rate of the bonds, which is reset weekly, and is classified as a Level 2 input in the fair value measurement hierarchy as there is an active market for the trading of these industrial development revenue bonds.

[0001564590-15-003392:notes:98]
There were no transfers between levels within the fair value measurement hierarchy during the six months ended March 31, 2015.


## us-gaap:DisposalGroupsIncludingDiscontinuedOperationsDisclosureTextBlock

[0001564590-15-003392:notes:99]
J. DISCONTINUED OPERATIONS

[0001564590-15-003392:notes:100]
On January 15, 2014, we sold our wholly-owned subsidiary Transdyn to a global provider of electronic toll collection systems, headquartered in Vienna, Austria.  The purchase price from the sale of this subsidiary totaled $16.0 million, subject to working capital adjustments.  We received cash of $14.4 million and the remaining $1.6 million was placed into an escrow account, to be released subject to resolution of certain claims.

[0001564590-15-003392:notes:101]
We have presented the results of these operations as income from discontinued operations, net of tax, in the condensed consolidated statements of operations as of March 31, 2014.

[0001564590-15-003392:notes:102]
[same as prior period, unchanged from 0001564590-15-000466:notes:101]

[0001564590-15-003392:notes:103]
|  | Three months ended March 31, |  |  | Six months ended March 31, |  |
|  | 2015 |  |  | 2014 |  |  | 2015 |  |  | 2014 |  |
| Revenues | $ | — |  |  | $ | 1,557 |  |  | $ | — |  |  | $ | 13,923 |  |
| Income from discontinued operations, net of tax of zero, $131, zero and $633, respectively |  | — |  |  |  | 54 |  |  |  | — |  |  |  | 1,041 |  |
| Gain on sale of discontinued operations, net of tax of $5,218 |  | — |  |  |  | 8,563 |  |  |  | — |  |  |  | 8,563 |  |
| Net income from discontinued operations, net of tax | $ | — |  |  | $ | 8,617 |  |  | $ | — |  |  | $ | 9,604 |  |
| Earnings per share information: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic | $ | — |  |  | $ | 0.72 |  |  | $ | — |  |  | $ | 0.80 |  |
| Diluted | $ | — |  |  | $ | 0.71 |  |  | $ | — |  |  | $ | 0.80 |  |


## us-gaap:IncomeTaxDisclosureTextBlock

[0001564590-15-003392:notes:104]
K. INCOME TAXES

[0001564590-15-003392:notes:105]
[same as prior period, unchanged from 0001564590-15-000466:notes:104]

[0001564590-15-003392:notes:106]
|  | Three months ended March 31, |  |  | Six months ended March 31, |  |
|  | 2015 |  |  | 2014 |  |  | 2015 |  |  | 2014 |  |
| Income from continuing operations before income taxes | $ | 2,696 |  |  | $ | 11,031 |  |  | $ | 1,466 |  |  | $ | 22,235 |  |
| Income tax provision |  | 6,379 |  |  |  | 4,055 |  |  |  | 5,388 |  |  |  | 7,992 |  |
| Income (loss) from continuing operations | $ | (3,683 | ) |  | $ | 6,976 |  |  | $ | (3,922 | ) |  | $ | 14,243 |  |
| Effective tax rate |  | 237 | % |  |  | 37 | % |  |  | 368 | % |  |  | 36 | % |

[0001564590-15-003392:notes:107]
A reconciliation of the significant differences between the statutory U. S. income tax rate and the effective income tax rate, as computed on earnings (loss) before income tax provision for the six months ended March 31, 2015 and 2014, is as follows:

[0001564590-15-003392:notes:108]
|  | Six months ended March 31, |  |
|  | 2015 |  |  | 2014 |  |
| Statutory rate |  | 35 | % |  |  | 35 | % |
| Canadian valuation allowance |  | 661 |  |  |  | — |  |
| Research and Development Credit |  | (327 | ) |  |  | — |  |
| State rate |  | 2 |  |  |  | 2 |  |
| Domestic production activities deduction |  | (2 | ) |  |  | (2 | ) |
| Other |  | (1 | ) |  |  | 1 |  |
| Effective rate |  | 368 | % |  |  | 36 | % |

[0001564590-15-003392:notes:109]
We recorded a provision for income taxes from continuing operations of $6.4 million in the second quarter of Fiscal 2015, compared to the provision of $4.1 million recorded in the second quarter of Fiscal 2014.  The effective tax rate for the second quarter of Fiscal 2015 was 236.6% compared to an effective tax rate of 36.8% for the second quarter of Fiscal 2014, primarily due to certain discrete items recorded in the second quarter of Fiscal 2015. These discrete items include a valuation allowance recorded against our Canadian deferred tax assets in the amount of $9.0 million, as discussed below, partially offset by the release of a FIN 48 reserve related to the  Federal Research and Development Tax Credit (R&D Credit) in the amount of $4.1 million upon closing an Internal Revenue Service (IRS) audit. The effective tax rate for the quarter ended March 31, 2014 approximated the combined U.S. federal and state statutory rates as the majority of our income was attributable to the U.S.

[0001564590-15-003392:notes:110]
We recorded a provision for income taxes from continuing operations of $5.4 million in the six months ended March 31, 2015, compared to the provision of $8.0 million recorded in the six months ended March 31, 2014.  The effective tax rate for the six months ended March 31, 2015 was 367.5% compared to an effective tax rate of 35.9% for the six months ended March 31, 2014 primarily due to a valuation allowance against our Canadian deferred tax assets partially offset by the release of a FIN 48 reserve related to the R&D Credit upon closing an IRS audit as well as the December 19, 2014 retroactive reinstatement of the R&D Credit from January 1, 2014 through December 31, 2014.  The effective tax rate for the six months ended March 31, 2014 approximated the combined U.S. federal and state statutory rate as the majority of our income was attributable to the U.S.

[0001564590-15-003392:notes:111]
At March 31, 2015, we had $32 million of gross foreign net operating loss carryforwards, the benefits of which are recorded as deferred tax assets and are subject to a 20-year carryforward period, the first of which will expire in 2031. During our quarterly assessment of deferred taxes, in the second quarter of Fiscal 2015, we established a valuation allowance in the amount of $9.0 million against Canadian net deferred tax assets.  In assessing the realizability of net deferred tax assets, we consider whether it is more-likely-than-not that some portion or all of the net deferred tax assets may not be realized.  The ultimate realization of net deferred tax assets is dependent on the generation of future taxable income during the periods in which those temporary differences become deductible.  In light of the historical Canadian losses, and recent changes in projected losses in the near term, we are required under the more-likely-than-not accounting standard to record a valuation allowance against the Canadian net deferred assets because we may not be able to realize the benefits of the net operating loss carryforwards and other deductible differences.

[0001564590-15-003392:notes:112]
We believe that our deferred tax assets in other tax jurisdictions, with the exception of those related to certain foreign withholding taxes and the net operating losses of our Dutch entities, are more-likely-than-not realizable through future reversals of existing taxable temporary differences and our estimate of future taxable income. Estimates may change as new events occur, estimates of future taxable income during the carryforward period are reduced or increased, additional information becomes available or operating environments change, which may result in a full or partial reversal of the valuation allowance.


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0001564590-15-003392:notes:113]
L. RESTRUCTURING AND SEPARATION COSTS

[0001564590-15-003392:notes:114]
In the second quarter of Fiscal 2015, we incurred approximately $1.3 million in restructuring and separation costs associated with the departure of our former Chief Operating Officer and severance costs related to our Canadian operations and certain U.S. operations which were negatively impacted by deteriorating market conditions.  Of these costs, $0.8 million has been paid as of March 31, 2015 and the remaining $0.5 million will be distributed over the next sixteen months.
