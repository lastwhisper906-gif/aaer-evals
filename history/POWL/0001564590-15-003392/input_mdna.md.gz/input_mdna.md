# POWL MD&A — 0001564590-15-003392


## mdna

[0001564590-15-003392:mdna:1]
[same as prior period, unchanged from 0001564590-15-000466:mdna:1]

[0001564590-15-003392:mdna:2]
[same as prior period, unchanged from 0001564590-15-000466:mdna:2]

[0001564590-15-003392:mdna:3]
[same as prior period, unchanged from 0001564590-15-000466:mdna:3]

[0001564590-15-003392:mdna:4]
[same as prior period, unchanged from 0001564590-15-000466:mdna:4]

[0001564590-15-003392:mdna:5]
[same as prior period, unchanged from 0001564590-15-000466:mdna:5]

[0001564590-15-003392:mdna:6]
As of March 31, 2015, we have a backlog of unfilled orders of $498.5 million, which is a decrease from our backlog of unfilled orders of $507.1 million as of September 30, 2014.  Our backlog includes various projects, some of which are petrochemical, oil and gas construction and transportation infrastructure projects which take a number of months to produce.

[0001564590-15-003392:mdna:7]
We anticipate that demand for our solutions in the western Canadian oil and gas markets will continue to be a contributor to our strategic position in the Canadian market place.  We completed the construction of our new Canadian facility and relocated operations in the fall of 2013 and we are nearing the completion of a $26 million expansion of this manufacturing facility, of which approximately $25 million has been incurred as of March 31, 2015. The stabilization of our Canadian operations has presented and continues to present challenges resulting in inefficiencies that have led to extended project delivery times, delayed project revenues, higher operating costs, gross margin deterioration and operating losses.  We continue to take actions to mitigate the risks associated with replicating our U.S. project-based integration model which allows for the design, fabrication, integration and testing of our products at a single location.  Prior to the construction of our new Canadian facility, we performed only final assembly operations in Canada.

[0001564590-15-003392:mdna:8]
On January 15, 2014, we sold our wholly-owned subsidiary Transdyn to a global provider of electronic toll collection systems, headquartered in Vienna, Austria.  The purchase price from the sale of this subsidiary totaled $16.0 million, subject to working capital adjustments. We received cash of $14.4 million and the remaining $1.6 million was placed into an escrow account, to be released subject to resolution of certain claims. We have presented the results of these operations as income from discontinued operations, net of tax, in the condensed consolidated statements of operations for the quarter and six months ended March 31, 2014.  Accordingly, we have removed Transdyn from the Results of Operations discussions below.

[0001564590-15-003392:mdna:9]
[same as prior period, unchanged from 0001564590-15-000466:mdna:9]

[0001564590-15-003392:mdna:10]
Quarter Ended March 31, 2015 Compared to the Quarter Ended March 31, 2014 (Unaudited)

[0001564590-15-003392:mdna:11]
[same as prior period, unchanged from 0001564590-15-000466:mdna:10]

[0001564590-15-003392:mdna:12]
Revenues increased 4.9%, or $7.9 million, to $170.2 million in the second quarter of Fiscal 2015, compared to the second quarter of Fiscal 2014, primarily due to an increase in domestic revenues.  Domestic revenues increased by 31.0%, or $28.5 million, to $120.4 million in the second quarter of Fiscal 2015, compared to the second quarter of Fiscal 2014, and international revenues decreased by 29.3%, or $20.6 million, to $49.8 million in the second quarter of Fiscal 2015, compared to the second quarter of Fiscal 2014. This decrease in international revenues in the second quarter of Fiscal 2015 was primarily due to the substantial completion of a large international project in Fiscal 2014. Revenues from commercial and industrial customers increased $14.2 million to $128.8 million in the second quarter of Fiscal 2015, compared to the second quarter of Fiscal 2014. Revenues from public and private utilities decreased $12.2 million to $23.2 million in the second quarter of Fiscal 2015, compared to the second quarter of Fiscal 2014. Revenues from municipal and transit projects increased $5.9 million to $18.2 million in the second quarter of Fiscal 2015, compared to the second quarter of Fiscal 2014.

[0001564590-15-003392:mdna:13]
Gross profit for the second quarter of Fiscal 2015 decreased 30.4%, or $10.6 million, to $24.3 million, compared to the second quarter of Fiscal 2014.  Gross profit as a percentage of revenues decreased to 14.3% in the second quarter of Fiscal 2015, compared to 21.5% in the second quarter of Fiscal 2014 primarily due to the margins associated with the mix of projects types, the large international project noted above as well as continued inefficiencies and incremental costs to hold customers’ schedules associated with the expansion and stabilization of our Canadian operations.

[0001564590-15-003392:mdna:14]
[same as prior period, unchanged from 0001564590-15-000466:mdna:14]

[0001564590-15-003392:mdna:15]
Selling, general and administrative expenses decreased $2.6 million to $19.5 million during the second quarter of Fiscal 2015 when compared to the second quarter of Fiscal 2014 partially due to a reduction in performance-based compensation, offset by an increase in personnel and administrative costs associated with the expansion of our Canadian operations.  Selling, general and administrative expenses, as a percentage of revenues, decreased to 11.4% during the second quarter of Fiscal 2015, compared to 13.6% during the second quarter of Fiscal 2014 due to the factors discussed above.

[0001564590-15-003392:mdna:16]
Restructuring and separation costs

[0001564590-15-003392:mdna:17]
In the second quarter of Fiscal 2015, we incurred approximately $1.3 million in restructuring and separation costs associated with the departure of our former Chief Operating Officer and severance costs related to our Canadian operations and certain U.S. operations which were negatively impacted by deteriorating market conditions.

[0001564590-15-003392:mdna:18]
Other Income

[0001564590-15-003392:mdna:19]
We recorded other income of $0.9 million during the second quarter of Fiscal 2015.  This was primarily the amortization of the deferred gain from the amended supply agreement, discussed in Note D of Notes to Condensed Consolidated Financial Statements, as well as death benefits received from our company-owned life insurance policy.  Other income was $0.5 million in the second quarter of Fiscal 2014 which was solely the amortization of the deferred gain.

[0001564590-15-003392:mdna:20]
[same as prior period, unchanged from 0001564590-15-000466:mdna:16]

[0001564590-15-003392:mdna:21]
We recorded a provision for income taxes from continuing operations of $6.4 million in the second quarter of Fiscal 2015, compared to the provision of $4.1 million recorded in the second quarter of Fiscal 2014.  The effective tax rate for the second quarter of Fiscal 2015 was 236.6% compared to an effective tax rate of 36.8% in the second quarter of Fiscal 2014, primarily due to certain discrete items recorded in the second quarter of Fiscal 2015.  These discrete items include a valuation allowance recorded against our Canadian deferred tax assets in the amount of $9.0 million partially offset by the release of a FIN 48 reserve related to the Federal Research and Development Tax Credit (R&D Credit) in the amount of $4.1 million upon closing an Internal Revenue Service (IRS) audit. The effective tax rate for the second quarter of Fiscal 2014 approximated the combined U.S. federal and state statutory rates as the majority of our income was attributable to the U.S.

[0001564590-15-003392:mdna:22]
[same as prior period, unchanged from 0001564590-15-000466:mdna:18]

[0001564590-15-003392:mdna:23]
In the second quarter of Fiscal 2015, we recorded a loss from continuing operations of $3.6 million, or a loss per share of $0.31, compared to income of $7.0 million, or $0.58 per diluted share, in the second quarter of Fiscal 2014.  This loss was primarily due to the valuation allowance recorded against our Canadian deferred tax assets mentioned above.

[0001564590-15-003392:mdna:24]
[same as prior period, unchanged from 0001564590-15-000466:mdna:20]

[0001564590-15-003392:mdna:25]
In January 2014, we sold our wholly-owned subsidiary Transdyn to a global provider of electronic toll collection systems, headquartered in Vienna, Austria.  We presented the results of these operations as income from discontinued operations, net of tax, for the second quarter of Fiscal 2014.  We had no income from discontinued operations in the second quarter of Fiscal 2015, and in the second quarter of Fiscal 2014, we recorded $8.6 million, or $0.71 per diluted share which included the gain on the sale. For additional information about this disposition, see Note J in the Notes to Condensed Consolidated Financial Statements.

[0001564590-15-003392:mdna:26]
[same as prior period, unchanged from 0001564590-15-000466:mdna:22]

[0001564590-15-003392:mdna:27]
The order backlog at March 31, 2015 was $498.5 million, compared to $507.1 million at September 30, 2014.  New orders placed during the second quarter of Fiscal 2015 totaled $167.1 million compared to $162.6 million in the second quarter of Fiscal 2014.

[0001564590-15-003392:mdna:28]
Six Months Ended March 31, 2015 Compared to the Six Months Ended March 31, 2014 (Unaudited)

[0001564590-15-003392:mdna:29]
Revenue and Gross Profit

[0001564590-15-003392:mdna:30]
Revenues decreased 3.4%, or $11.4 million, to $322.8 million for the six months ended March 31, 2015, compared to the six months ended March 31, 2014.  Domestic revenues increased by 20.1%, or $36.4 million, to $217.3 million for the six months ended March 31, 2015, compared to the six months ended March 31, 2014, and international revenues decreased by 31.2%, or $47.8 million, to $105.5 million for the six months ended March 31, 2015, compared to the six months ended March 31, 2014.  International revenues decreased in the six months ended March 31, 2015 primarily due the substantial completion of a large international project in Fiscal 2014.  Revenues from commercial and industrial customers increased $12.2 million to $251.3 million for the six months ended March 31, 2015, compared to the six months ended March 31, 2014. Revenues from public and private utilities decreased $22.4 million to $47.7 million for the six months ended March 31, 2015, compared to the six months ended March 31, 2014. Revenues from municipal and transit projects decreased $1.2 million to $23.8 million for the six months ended March 31, 2015, compared to the six months ended March 31, 2014.

[0001564590-15-003392:mdna:31]
Gross profit for the six months ended March 31, 2015 decreased 35.3%, or $24.7 million, to $45.4 million, compared to the six months ended March 31, 2014.  Gross profit as a percentage of revenues was 14.1% for the six months ended March 31, 2015, compared to 21.0% for the six months ended March 31, 2014.  Our gross profit as a percentage of revenues was down in the six months ended March 31, 2015, compared to the six months ended March 31, 2014, primarily due to the costs associated with our Canadian operations, the international project noted above and the overall mix of project types.

[0001564590-15-003392:mdna:32]
Selling, General and Administrative Expenses

[0001564590-15-003392:mdna:33]
Selling, general and administrative expenses decreased by $3.4 million to $40.3 million during six months ended March 31, 2015, compared to the six months ended March 31, 2014, primarily due to a reduction in performance-based compensation and overall cost cutting efforts.  Selling, general and administrative expenses, as a percentage of revenues, decreased slightly to 12.5% during the six months ended March 31, 2015, compared to 13.1% during the six months ended March 31, 2014.

[0001564590-15-003392:mdna:34]
Restructuring and separation costs

[0001564590-15-003392:mdna:35]
In the six months ended March 31, 2015, we incurred approximately $1.3 million in restructuring and separation costs associated with the departure of our former Chief Operating Officer and severance costs related to our Canadian operations and certain U.S. operations which were negatively impacted by deteriorating market conditions.

[0001564590-15-003392:mdna:36]
Other Income

[0001564590-15-003392:mdna:37]
We recorded other income of $1.4 million in the six months ended March 31, 2015 which was the amortization of the deferred gain from the amended supply agreement, discussed in Note D of Notes to Condensed Consolidated Financial Statements, and the death benefit from our company-owned life insurance policy.  We recorded other income of $0.5 million in the same period in fiscal year 2014 which was solely the amortization of the deferred gain.

[0001564590-15-003392:mdna:38]
Income Tax Provision

[0001564590-15-003392:mdna:39]
We recorded a provision for income taxes from continuing operations of $5.4 million for the six months ended March 31, 2015, compared to the provision of $8.0 million for the six months ended March 31, 2014.  The effective tax rate for the six months ended March 31, 2015 was 367.5%, compared to an effective tax rate of 35.9% for the six months ended March 31, 2014 primarily due to a valuation allowance recorded against our Canadian deferred tax assets partially offset by the release of a FIN 48 reserve related to the R&D Credit upon closing an IRS audit as well as the December 19, 2014 retroactive reinstatement of the R&D Credit from January 1, 2014 through December 31, 2014.  The effective tax rate for the six months ended March 31, 2014 approximated the combined U.S. federal and state statutory rate as the majority of our income was attributable to the U.S.

[0001564590-15-003392:mdna:40]
Income from Continuing Operations

[0001564590-15-003392:mdna:41]
For the six months ended March 31, 2015, we recorded a loss from continuing operations of $3.9 million, or $0.33 per share, compared to income from continuing operations of $14.2 million, or $1.18 per diluted share, for the six months ended March 31, 2014.  This loss was primarily due to the valuation allowance recorded against our Canadian deferred tax assets mentioned above.

[0001564590-15-003392:mdna:42]
Income from Discontinued Operations

[0001564590-15-003392:mdna:43]
For the six months ended March 31, 2014, we recorded $9.6 million, or $0.80 per diluted share, of income from discontinued operations which included the gain on the sale.  For additional information about this disposition, see Note I in the Notes to Condensed Consolidated Financial Statements.

[0001564590-15-003392:mdna:44]
Backlog

[0001564590-15-003392:mdna:45]
The order backlog at March 31, 2015 was $498.5 million, compared to $507.1 million at September 30, 2014.  New orders placed during the six months ended March 31, 2015 totaled $321.5 million compared to $354.8 million for the six months ended March 31, 2014.  The year over year decrease in new orders was primarily due to the timing of certain complex oil and gas production and petrochemical projects.

[0001564590-15-003392:mdna:46]
[same as prior period, unchanged from 0001564590-15-000466:mdna:24]

[0001564590-15-003392:mdna:47]
Cash and cash equivalents decreased to $55.7 million at March, 2015, compared to $103.1 million at September 30, 2014.  As of March 31, 2015, current assets exceeded current liabilities by 2.2 times and our debt to total capitalization was 0.81%.

[0001564590-15-003392:mdna:48]
We have a $75.0 million revolving credit facility in the U.S., which expires in December 2016. As of March 31, 2015, there were no amounts borrowed under this line of credit.  Total long-term debt and capital lease obligations, including current maturities, totaled $2.8 million at March 31, 2015, compared to $3.2 million at September 30, 2014. Total letters of credit outstanding were $18.0 million and $21.5 million at March 31, 2015 and September 30, 2014, respectively, which reduce our availability under our U.S. credit facility. Amounts available at March 31, 2015 under the U.S. revolving credit facility was $57.0 million.  For further information regarding our debt, see Notes E and F of Notes to Condensed Consolidated Financial Statements.

[0001564590-15-003392:mdna:49]
Approximately $4.3 million of our cash at March 31, 2015, was held outside of the United States for international operations.  It is our intention to indefinitely reinvest all current and future foreign earnings internationally in order to ensure sufficient working capital and support and expand these international operations.  In the event that we elect to repatriate some or all of the foreign earnings that were previously deemed to be indefinitely reinvested outside the U.S., under current tax laws we would incur additional tax expense upon such repatriation.

[0001564590-15-003392:mdna:50]
[same as prior period, unchanged from 0001564590-15-000466:mdna:28]

[0001564590-15-003392:mdna:51]
[same as prior period, unchanged from 0001564590-15-000466:mdna:29]

[0001564590-15-003392:mdna:52]
Cash used in operating activities was $4.1 million during the first six months of Fiscal 2015, compared to cash provided by operating activities of $6.8 million during the first six months of Fiscal 2014.  This decrease was primarily due to the reduction in earnings and an increase in accounts receivable, partially offset by the improvement in our net underbilled position. Cash flow from operations is primarily influenced by demand for our products and services and is impacted as our progress payment terms with our customers are matched with the payment terms with our suppliers.

[0001564590-15-003392:mdna:53]
[same as prior period, unchanged from 0001564590-15-000466:mdna:31]

[0001564590-15-003392:mdna:54]
Purchases of property, plant and equipment during the first six months of Fiscal 2015 totaled $28.7 million compared to $8.5 million during the first six months of Fiscal 2014.  This increase results from the expansion of our Canadian facility in Fiscal 2015.

[0001564590-15-003392:mdna:55]
[same as prior period, unchanged from 0001564590-15-000466:mdna:33]

[0001564590-15-003392:mdna:56]
Net cash used in financing activities was $13.0 million during the first six months of Fiscal 2015 and $6.9 million during the first six months of Fiscal 2014.  This increase in the use of cash in the same period in Fiscal 2015 was primarily driven by our share repurchase program discussed below.   During the first six months of Fiscal 2015, we have spent $5.8 million to repurchase shares of our common stock.

[0001564590-15-003392:mdna:57]
[same as prior period, unchanged from 0001564590-15-000466:mdna:35]

[0001564590-15-003392:mdna:58]
On December 17, 2014, our Board of Directors authorized a share repurchase program under which we may repurchase up to $25 million of our outstanding stock.  The purchases may be made from time to time in the open market, through privately negotiated transactions and Rule 10b5-1 trading plans in accordance with applicable laws, rules and regulations.  The Repurchase Program will be funded from cash on hand and cash provided by operating activities.  The Repurchase Program will expire as of the close of business on December 31, 2015. As of March 31, 2015, a total of $5.8 million of our stock (171,416 shares) has been purchased under the Repurchase Program.

[0001564590-15-003392:mdna:59]
[same as prior period, unchanged from 0001564590-15-000466:mdna:37]

[0001564590-15-003392:mdna:60]
[same as prior period, unchanged from 0001564590-15-000466:mdna:38]

[0001564590-15-003392:mdna:61]
[same as prior period, unchanged from 0001564590-15-000466:mdna:39]

[0001564590-15-003392:mdna:62]
[same as prior period, unchanged from 0001564590-15-000466:mdna:40]

[0001564590-15-003392:mdna:63]
[same as prior period, unchanged from 0001564590-15-000466:mdna:41]

[0001564590-15-003392:mdna:64]
[same as prior period, unchanged from 0001564590-15-000466:mdna:42]

[0001564590-15-003392:mdna:65]
The markets in which we participate are capital-intensive and cyclical in nature. Cyclicality is predominantly driven by customer demand, global economic conditions and anticipated environmental or regulatory changes which affect the manner in which our customers proceed with capital investments. Our customers analyze various factors including the demand and price for oil, gas and electrical energy, the overall financial environment, governmental budgets, regulatory actions and environmental concerns. These factors influence the release of new capital projects by our customers, which are traditionally awarded in competitive bid situations. Scheduling is matched to the customer requirements; and projects may take a number of months to produce; schedules also may change during the course of any particular project.

[0001564590-15-003392:mdna:66]
A significant portion of our revenues are derived from the oil and gas market sectors.  Due to the decline in oil prices, many of our customers have reduced their capital budgets and cuts costs, and in certain instances have deferred or cancelled projects that we were pursuing.  We believe that lower oil prices will impact future orders due to reduced capital spending and project deferrals by our customers.  Market price pressures have intensified.  This reduction in orders and market price pressures will ultimately negatively impact our revenues, operating results and cash flows from operations.  Accordingly, we are reviewing our cost structure in all operating locations as well as our corporate office and are taking actions to align our operating cost structure with expected revenues in the near-term.

[0001564590-15-003392:mdna:67]
Prior to these recent economic challenges, our orders over the past two years have been strong, driven primarily by the oil and gas and petrochemical industries overall, along with the specific demand associated with Canadian projects.  Our operating results are frequently impacted by the timing and resolution of change orders and project close-out which could cause gross margins to improve or deteriorate during the period in which these items are approved and finalized with customers. Our operating results are also

[0001564590-15-003392:mdna:68]
impacted by other factors, such as projects that have contract arrangements where the customer approval of final engineering and design specifications may delay the timing of the project execution.

[0001564590-15-003392:mdna:69]
We completed the construction of our new Acheson, Alberta facility and relocated operations in the fall of 2013 and are nearing the completion of a $26 million expansion of this facility. The production ramp and stabilization of our Canadian operations has presented and may continue to present challenges resulting in inefficiencies and extended project delivery times. These challenges resulted in delayed project revenues, incremental costs to hold customers’ schedules, gross margin deterioration and operating losses.  We continue to take actions to stabilize our Canadian operations and mitigate the risks associated with replicating our U.S. project-based integration model which allows for the design, fabrication, integration and testing of our products at a single location.  However, we may continue to incur operating losses in Canada in the near term as we continue to improve our training and execution as well as enhance our engineering and project management competencies.  Prior to the construction of our new Canadian facility, we performed only final assembly operations in Canada.

[0001564590-15-003392:mdna:70]
We have funded the construction and expansion of our Canadian facility from our existing cash and cash equivalents and future cash flows from operations.  We expect the expansion to be completed in the third quarter of Fiscal 2015.

[0001564590-15-003392:mdna:71]
[same as prior period, unchanged from 0001564590-15-000466:mdna:49]
