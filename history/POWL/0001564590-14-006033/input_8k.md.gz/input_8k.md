# POWL 8-K — 0001193125-14-431745 filed 2014-12-03

## item codes, every 8-K on or before 2014-12-03

- 2014-12-03 0001193125-14-431745 — 2.02, 9.01
- 2014-11-05 0001193125-14-397955 — 8.01, 9.01
- 2014-09-26 0001193125-14-353741 — 7.01, 9.01
- 2014-08-05 0001193125-14-296001 — 2.02, 8.01, 9.01
- 2014-05-07 0001193125-14-187496 — 2.02, 8.01, 9.01
- 2014-03-03 0001193125-14-079843 — 5.02, 5.07
- 2014-02-05 0001193125-14-036633 — 2.02, 8.01, 9.01
- 2014-01-17 0001193125-14-014351 — 1.01, 8.01, 9.01
- 2014-01-06 0001193125-14-002795 — 1.01, 2.03
- 2013-12-06 0001564590-13-001411 — 2.02, 9.01
- 2013-12-05 0001564590-13-001406 — 5.02, 8.01, 9.01
- 2013-11-07 0001193125-13-432950 — 8.01, 9.01
- 2013-08-07 0001193125-13-324337 — 2.02, 9.01
- 2013-05-08 0001193125-13-206800 — 2.02, 9.01
- 2013-02-22 0001193125-13-070971 — 5.02, 5.07
- 2013-02-06 0001193125-13-040556 — 2.02, 9.01
- 2012-12-18 0001193125-12-506417 — 5.02, 9.01
- 2012-12-05 0001193125-12-491749 — 2.02, 9.01
- 2012-10-12 0001193125-12-421889 — 3.03, 5.02, 5.03, 9.01
- 2012-08-09 0001193125-12-344617 — 5.02, 8.01, 9.01
- 2012-08-08 0001193125-12-343630 — 2.02, 9.01
- 2012-05-09 0001193125-12-221356 — 2.02, 9.01
- 2012-02-08 0001193125-12-046560 — 2.02, 9.01
- 2011-12-08 0001193125-11-334810 — 2.02, 9.01
- 2011-11-08 0000950123-11-096524 — 2.02, 2.06, 4.02, 9.01
- 2011-10-14 0000950123-11-090124 — 5.02
- 2011-10-06 0000950123-11-088969 — 5.02
- 2011-09-19 0000950123-11-085224 — 5.02, 9.01
- 2011-09-15 0000950123-11-084806 — 5.02, 9.01
- 2011-08-04 0000950123-11-072788 — 2.02, 9.01
- 2011-07-22 0000950123-11-067402 — 5.07
- 2011-05-24 0000950123-11-053550 — 1.01, 2.03, 9.01
- 2011-05-04 0000950123-11-044561 — 2.02, 9.01
- 2011-02-02 0000950123-11-008188 — 2.02, 9.01
- 2010-12-08 0000950123-10-111987 — 2.02, 9.01
- 2010-08-05 0000950123-10-073114 — 2.02, 9.01
- 2010-05-18 0000950123-10-050900 — 5.02
- 2010-05-05 0000950123-10-044499 — 2.02, 9.01
- 2010-02-03 0000950123-10-008278 — 2.02, 9.01
- 2009-12-21 0000950123-09-072269 — 1.01, 2.01, 2.03, 8.01, 9.01
- 2009-12-09 0000950123-09-069525 — 2.02, 9.01
- 2009-10-27 0000950123-09-053501 — 1.01, 8.01, 9.01
- 2009-08-04 0000950123-09-029476 — 2.02, 9.01
- 2009-05-06 0000950129-09-001498 — 2.02, 9.01
- 2009-03-05 0000950129-09-000749 — 1.01, 9.01
- 2009-02-10 0000950129-09-000349 — 2.02, 9.01
- 2008-12-10 0000950134-08-021934 — 2.02, 9.01
- 2008-08-06 0000950129-08-004267 — 2.02, 9.01
- 2008-07-24 0000950129-08-004063 — 1.01, 5.02, 8.01, 9.01
- 2008-06-16 0000950129-08-003500 — 9.01 — amendment of 0000950134-06-015374
- 2008-06-05 0000950129-08-003378 — 5.02, 9.01
- 2008-05-08 0000950129-08-002843 — 2.02, 9.01
- 2008-02-06 0000950129-08-000533 — 2.02, 9.01
- 2007-12-19 0000950129-07-006277 — 1.01, 2.03, 9.01
- 2007-12-06 0000950129-07-006003 — 2.02, 9.01
- 2007-08-21 0000950129-07-004181 — 2.02, 9.01
- 2007-05-31 0000950129-07-002810 — 2.02, 9.01
- 2007-05-21 0000950129-07-002668 — 2.02, 3.01, 4.02, 9.01
- 2007-04-16 0000950129-07-002002 — 2.02, 4.02, 9.01
- 2007-03-01 0000950129-07-001104 — 5.02, 8.01, 9.01
- 2007-02-08 0000950129-07-000451 — 2.02, 9.01
- 2006-12-08 0000950129-06-010041 — 2.02, 9.01
- 2006-09-08 0000950129-06-008379 — 2.02, 9.01
- 2006-08-09 0000950134-06-015374 — 1.01, 2.01, 8.01, 9.01
- 2006-06-08 0000950129-06-006127 — 2.02, 9.01
- 2006-03-09 0000950129-06-002455 — 2.02, 9.01
- 2005-12-16 0000950129-05-012031 — 2.02, 5.03, 9.01
- 2005-09-13 0000950129-05-009181 — 2.01, 9.01 — amendment of 0000950129-05-006889
- 2005-09-12 0000950129-05-009151 — 2.02, 9.01
- 2005-07-06 0000950129-05-006889 — 1.01, 1.02, 2.01, 2.03, 9.01
- 2005-06-10 0000950129-05-006128 — 2.02, 9.01
- 2005-04-20 0000080420-05-000031 — 5.02
- 2005-03-11 0000080420-05-000024 — 9.01
- 2005-02-25 0000080420-05-000018 — 7.01, 9.01
- 2005-01-21 0000080420-05-000009 — 7.01, 9.01
- 2004-12-17 0000080420-04-000049 — 2.02, 9.01
- 2004-11-01 0000080420-04-000045 — 8.01, 9.01
- 2004-10-08 0001169232-04-005133 — 2.05
- 2004-09-14 0000080420-04-000037 — 5.02
- 2004-09-02 0000080420-04-000030 — 2.02, 9.01
- 2004-06-08 0000080420-04-000021 — 7
- 2004-05-13 0000080420-04-000019 — 4
- 2004-02-27 0000080420-04-000013 — 7
- 2003-12-16 0000950129-03-006136 — 12, 7
- 2003-08-29 0000950129-03-004531 — 12, 7
- 2003-06-03 0000950129-03-003035 — 7, 9
- 2003-05-15 0000950129-03-002812 — 7, 9
- 2002-05-29 0000950129-02-002795 — 4
- 2000-12-21 0000950129-00-006093 — 5, 7
- 1998-09-04 0000950129-98-003802 — 5
- 1996-08-09 0000950129-96-001705 — 2, 7

## late-filing notifications on or before 2014-12-03

- 2007-05-11 0000950129-07-002494 — NT 10-Q, for the period ended 2007-03-31
- 2005-01-18 0000080420-05-000004 — NT 10-K, for the period ended 2004-10-31

## item 2.02 — earnings release, exhibit 99.1

[0001193125-14-431745:8k_2_02:1]
EX-99.1
2
d833098dex991.htm
EX-99.1

[0001193125-14-431745:8k_2_02:2]
EX-99.1

[0001193125-14-431745:8k_2_02:3]
Ex. 99.1

[0001193125-14-431745:8k_2_02:4]
|  |  | PRESS RELEASE |

[0001193125-14-431745:8k_2_02:5]
| FOR IMMEDIATE RELEASE |  |  |  | Contacts: |  | Don R. Madison, CFO |
|  |  |  |  |  |  | Powell Industries, Inc. |
|  |  |  |  |  |  | 713-947-4422 |

[0001193125-14-431745:8k_2_02:6]
POWELL INDUSTRIES ANNOUNCES FISCAL 2014

[0001193125-14-431745:8k_2_02:7]
FOURTH QUARTER AND YEAR-END RESULTS

[0001193125-14-431745:8k_2_02:8]
HOUSTON — DECEMBER 2, 2014 — Powell Industries, Inc. (NASDAQ: POWL), a leading supplier of custom-engineered solutions for the management and
control of electrical energy and other critical processes, today announced results for the fiscal 2014 fourth quarter and year ended September 30, 2014.

[0001193125-14-431745:8k_2_02:9]
Revenues from continuing operations for the fourth quarter of fiscal 2014 were $162.8 million compared to revenues of $176.2 million for the
fourth quarter of fiscal 2013. Income from continuing operations for the fourth quarter of 2014 was $2.4 million, or $0.20 per diluted share, compared to income from continuing operations of $17.3 million, or $1.44 per diluted share, in the fourth
quarter of fiscal 2013 including special items. Excluding the special items, income from continuing operations for the fourth quarter of fiscal 2013 was $9.1 million, or $0.75 per diluted share. A reconciliation of this non-GAAP financial measure to
net income is included in the financial tables below.

[0001193125-14-431745:8k_2_02:10]
Michael A. Lucas, President and Chief Executive Officer, stated, “We are
pleased that our fourth quarter results were better than anticipated, largely due to strong service related revenues along with lower than anticipated costs on a few large projects. Our operational improvement actions, both in the U.S. and Canada,
are on track and are producing positive results. We remain focused on meeting customer schedules and improving efficiencies.

[0001193125-14-431745:8k_2_02:11]
“Presently, demand for our products and services in our major markets remains solid as we ended fiscal 2014 with another quarter of
strong bookings, resulting in record orders from continuing operations of $726 million for the full year. The recent decline in oil prices, however, may impact future capital projects as spending plans could be reduced if lower oil prices
persist.”

[0001193125-14-431745:8k_2_02:12]
New orders placed during the fourth quarter of fiscal 2014 totaled $199 million compared to $172
million in the third quarter of fiscal 2014 and compared to $196 million in the fourth quarter of fiscal 2013. The Company’s backlog as of September 30, 2014 was $507 million compared to $477 million as of June 30, 2014 and compared
to $438 million at the end of last year’s fourth quarter.

[0001193125-14-431745:8k_2_02:13]
FISCAL 2014 RESULTS

[0001193125-14-431745:8k_2_02:14]
Revenues from continuing operations for fiscal 2014 were $647.8 million compared to revenues of $640.9 million for fiscal 2013. Income from
continuing operations for fiscal 2014 was $19.6 million, or $1.62 per diluted share, compared to income from continuing operations of $39.7 million, or $3.32 per diluted share, in fiscal 2013 including special items. Excluding the special items,
income from continuing operations for fiscal 2013 was $31.4 million, or $2.62 per diluted share. A reconciliation of this non-GAAP financial measure to net income is included in the financial tables below.

[0001193125-14-431745:8k_2_02:15]
OUTLOOK

[0001193125-14-431745:8k_2_02:16]
The following statements are
based on the current expectations of the Company. These statements are forward-looking, and actual results may differ materially as further elaborated in the last paragraph below.

[0001193125-14-431745:8k_2_02:17]
Based on its backlog and current business conditions, Powell Industries currently expects full year fiscal 2015 revenues to range between $650
million and $710 million and full year fiscal 2015 earnings to range between $1.75 and $2.30 per diluted share.

[0001193125-14-431745:8k_2_02:18]
CONFERENCE CALL

[0001193125-14-431745:8k_2_02:19]
Powell Industries has scheduled a conference call for Wednesday, December 3, 2014 at 11:00 a.m. eastern time. To participate in the
conference call, dial 201-689-8349 at least 10 minutes before the call begins and ask for the Powell Industries conference call. A replay of the call will be available approximately two hours after the live broadcast ends and will be accessible
until December 10, 2014. To access the replay, dial 201-612-7415 using a passcode of 13595294#.

[0001193125-14-431745:8k_2_02:20]
Investors, analysts and the general public will also have the opportunity to listen to the
conference call over the Internet by visiting powellind.com. To listen to the live call on the web, please visit the website at least fifteen minutes before the call begins to register, download and install any necessary audio software. For
those who cannot listen to the live webcast, an archive will be available shortly after the call and will remain available for approximately 90 days at powellind.com.

[0001193125-14-431745:8k_2_02:21]
Powell Industries, Inc., headquartered in Houston, engineers packaged, custom-engineered solutions and systems for the distribution and control of electrical
energy. Powell markets include large industrial customers such as oil and gas refiners, offshore oil and gas producers, petrochemical plants, pipelines, gas and liquid terminals, pulp and paper producers, mining and metal operations, traction
power facilities, and electric utilities. For more information, please visit powellind.com.

[0001193125-14-431745:8k_2_02:22]
This press release contains references to certain non-GAAP financial measures
discussed above. Please see the financial table below for more details on these non-GAAP financial measures, including a reconciliation of these non-GAAP financial measures to net income and the reasons management believes these measures are useful
to investors.

[0001193125-14-431745:8k_2_02:23]
POWELL INDUSTRIES, INC. & SUBSIDIARIES

[0001193125-14-431745:8k_2_02:24]
CONDENSED CONSOLIDATED STATEMENT OF OPERATIONS

[0001193125-14-431745:8k_2_02:25]
|  |  | Three Months Ended |  |  | Years Ended |  |
|  |  | Sept 30, 2014 |  |  | Sept 30, 2013 |  |  | Sept 30, 2014 |  |  | Sept 30, 2013 |  |
| (In thousands, except per share data) |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | (Unaudited) |  |
| Revenues |  | $ | 162,847 |  |  | $ | 176,235 |  |  | $ | 647,814 |  |  | $ | 640,867 |  |
| Cost of goods sold |  |  | 137,101 |  |  |  | 136,281 |  |  |  | 522,340 |  |  |  | 502,375 |  |
| Gross profit |  |  | 25,746 |  |  |  | 39,954 |  |  |  | 125,474 |  |  |  | 138,492 |  |
| Selling, general and administrative expenses |  |  | 21,012 |  |  |  | 18,798 |  |  |  | 87,756 |  |  |  | 79,707 |  |
| Restructuring and relocation expenses |  |  | — |  |  |  | 2,210 |  |  |  | — |  |  |  | 3,927 |  |
| Research and development expenses |  |  | 1,821 |  |  |  | 1,944 |  |  |  | 7,608 |  |  |  | 7,615 |  |
| Amortization expense |  |  | 120 |  |  |  | 416 |  |  |  | 779 |  |  |  | 1,659 |  |
| Operating income |  |  | 2,793 |  |  |  | 16,586 |  |  |  | 29,331 |  |  |  | 45,584 |  |
| Other income |  |  | (508 | ) |  |  | — |  |  |  | (1,522 | ) |  |  | (1,709 | ) |
| Interest expense |  |  | 32 |  |  |  | 51 |  |  |  | 178 |  |  |  | 202 |  |
| Interest income |  |  | (3 | ) |  |  | (7 | ) |  |  | (13 | ) |  |  | (35 | ) |
| Income from continuing operations before income taxes |  |  | 3,272 |  |  |  | 16,542 |  |  |  | 30,688 |  |  |  | 47,126 |  |
| Income tax provision |  |  | 843 |  |  |  | (792 | ) |  |  | 11,068 |  |  |  | 7,387 |  |
| Income from continuing operations |  |  | 2,429 |  |  |  | 17,334 |  |  |  | 19,620 |  |  |  | 39,739 |  |
| Income from discontinued operations, net of tax |  |  | — |  |  |  | 1,234 |  |  |  | 9,604 |  |  |  | 2,337 |  |
| Net income |  | $ | 2,429 |  |  | $ | 18,568 |  |  | $ | 29,224 |  |  | $ | 42,076 |  |
| Earnings per share: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Continuing operations |  | $ | 0.20 |  |  | $ | 1.45 |  |  | $ | 1.63 |  |  | $ | 3.32 |  |
| Discontinued operations |  | $ | — |  |  | $ | 0.10 |  |  | $ | 0.80 |  |  | $ | 0.20 |  |
| Basic earnings per share |  | $ | 0.20 |  |  | $ | 1.55 |  |  | $ | 2.43 |  |  | $ | 3.52 |  |
| Continuing operations |  | $ | 0.20 |  |  | $ | 1.44 |  |  | $ | 1.62 |  |  | $ | 3.32 |  |
| Discontinued operations |  | $ | — |  |  | $ | 0.10 |  |  | $ | 0.80 |  |  | $ | 0.19 |  |
| Diluted earnings per share |  | $ | 0.20 |  |  | $ | 1.54 |  |  | $ | 2.42 |  |  | $ | 3.51 |  |
| Weighted average shares: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  |  | 12,015 |  |  |  | 11,970 |  |  |  | 12,003 |  |  |  | 11,948 |  |
| Diluted |  |  | 12,071 |  |  |  | 12,028 |  |  |  | 12,058 |  |  |  | 11,994 |  |
| SELECTED FINANCIAL DATA: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Depreciation and Amortization |  | $ | 3,737 |  |  | $ | 2,415 |  |  | $ | 12,165 |  |  | $ | 10,190 |  |
| Capital Expenditures |  | $ | 5,199 |  |  | $ | 20,641 |  |  | $ | 16,495 |  |  | $ | 74,369 |  |

[0001193125-14-431745:8k_2_02:26]
POWELL INDUSTRIES, INC. & SUBSIDIARIES

[0001193125-14-431745:8k_2_02:27]
CONDENSED CONSOLIDATED BALANCE SHEETS

[0001193125-14-431745:8k_2_02:28]
|  |  | September 30, |  |  | September 30, |  |
|  |  | 2014 |  |  | 2013 |  |
| (In thousands) |  | (Unaudited) |  |
| Assets: |  |  |  |  |  |  |  |  |
| Current assets |  | $ | 357,327 |  |  | $ | 341,931 |  |
| Current assets held for sale |  |  | — |  |  |  | 15,409 |  |
| Property, plant and equipment (net) |  |  | 156,896 |  |  |  | 144,495 |  |
| Long-term assets |  |  | 27,220 |  |  |  | 28,924 |  |
| Long-term assets held for sale |  |  | — |  |  |  | 144 |  |
| Total assets |  | $ | 541,443 |  |  | $ | 530,903 |  |
| Liabilities & equity: |  |  |  |  |  |  |  |  |
| Current liabilities |  | $ | 158,099 |  |  | $ | 150,215 |  |
| Current liabilities held for sale |  |  | — |  |  |  | 17,848 |  |
| Long-term debt and capital lease obligations, net of current maturities |  |  | 2,800 |  |  |  | 3,200 |  |
| Deferred and other long-term liabilities |  |  | 9,447 |  |  |  | 4,210 |  |
| Long-term liabilities held for sale |  |  | — |  |  |  | 204 |  |
| Stockholders’ equity |  |  | 371,097 |  |  |  | 355,226 |  |
| Total liabilities and stockholders’ equity |  | $ | 541,443 |  |  | $ | 530,903 |  |

[0001193125-14-431745:8k_2_02:29]
POWELL INDUSTRIES, INC. & SUBSIDIARIES

[0001193125-14-431745:8k_2_02:30]
NON-GAAP NET INCOME RECONCILIATION

[0001193125-14-431745:8k_2_02:31]
|  |  | Three Months Ended |  |  | Years Ended |  |
| (In thousands) |  | Sept 30, 2014 |  |  | Sept 30, 2013 |  |  | Sept 30, 2014 |  |  | Sept 30, 2013 |  |
|  |  | (Unaudited) |  |  | (Unaudited) |  |
| Net Income: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Income from continuing operations |  | $ | 2,429 |  |  | $ | 17,334 |  |  | $ | 19,620 |  |  | $ | 39,739 |  |
| Canadian project claim settlement, net of tax |  |  | — |  |  |  | (2,850 | ) |  |  | — |  |  |  | (2,850 | ) |
| Gain on settlement, net of tax |  |  | — |  |  |  | — |  |  |  | — |  |  |  | (1,328 | ) |
| Restructuring and relocation expenses, net of tax |  |  | — |  |  |  | 1,654 |  |  |  | — |  |  |  | 2,964 |  |
| Release of Canadian tax valuation allowance |  |  | — |  |  |  | (7,079 | ) |  |  | — |  |  |  | (7,079 | ) |
| Non-GAAP net income |  | $ | 2,429 |  |  | $ | 9,059 |  |  | $ | 19,620 |  |  | $ | 31,446 |  |
| Diluted shares outstanding |  |  | 12,071 |  |  |  | 12,028 |  |  |  | 12,058 |  |  |  | 11,994 |  |
| Diluted Earnings Per Share: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Earnings per share |  | $ | 0.20 |  |  | $ | 1.44 |  |  | $ | 1.62 |  |  | $ | 3.32 |  |
| Non-GAAP earnings per share |  | $ | 0.20 |  |  | $ | 0.75 |  |  | $ | 1.62 |  |  | $ | 2.62 |  |

[0001193125-14-431745:8k_2_02:32]
For all periods presented, the Company defines non-GAAP net income as net income which excludes: 1) Canadian project claim
settlement, net of tax; 2) Gain on legal settlement, net of tax; 3) Restructuring and relocation expenses, net of tax; and 4) Release of Canadian tax valuation allowance. Non-GAAP financial measures should not be considered a substitute for, or
superior to, measures of financial performance prepared in accordance with GAAP. However, the Company believes by excluding these items, these non-GAAP financial measures are helpful in comparing the historical results to current results and
measuring operating earnings trends. The Company also believes the disclosure of non-GAAP net income will help investors meaningfully evaluate and compare its cash flow generating capacity from quarter to quarter and year to year.

[0001193125-14-431745:8k_2_02:33]
The non-GAAP adjustments, and the basis for excluding them from GAAP financial measures, are outlined below:

[0001193125-14-431745:8k_2_02:34]
|  | • |  | Canadian project claim settlement, net of tax – In the fourth quarter of fiscal 2013, a project claim recovery was received on a large industrial project at Powell Canada. This project experienced significant delays and cost overruns in fiscal 2012. |

[0001193125-14-431745:8k_2_02:35]
|  | • |  | Gain on settlement, net of tax – In the second quarter of fiscal 2013, we settled a lawsuit filed against the previous owners of Powell Canada. |

[0001193125-14-431745:8k_2_02:36]
|  | • |  | Restructuring and relocation expenses, net of tax – Significant expenses were incurred related to relocation efforts in connection with the construction of two new manufacturing facilities in fiscal 2013. We also incurred expenses related to the restructuring of our operations in the United Kingdom in fiscal 2013. |

[0001193125-14-431745:8k_2_02:37]
|  | • |  | Release of Canadian tax valuation allowance - In the fourth quarter of fiscal 2013, we released a tax valuation allowance recorded as an offset to prior years’ Canadian pre-tax losses because we believed it is more likely than not that market conditions and our operating results going forward will allow us to realize the deferred tax assets associated with prior year losses in Canada. |

[0001193125-14-431745:8k_2_02:38]
Due to the nature of these items, the Company does not believe that these items reflect its ongoing operations.

[0001193125-14-431745:8k_2_02:39]
# # #
