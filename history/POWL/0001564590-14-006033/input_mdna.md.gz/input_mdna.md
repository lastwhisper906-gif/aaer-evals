# POWL MD&A — 0001564590-14-006033


## mdna

[0001564590-14-006033:mdna:1]
Item 7. Management’s Discussion and Analysis of Financial Condition and Results of Operations

[0001564590-14-006033:mdna:2]
Overview

[0001564590-14-006033:mdna:3]
We develop, design, manufacture and service custom-engineered equipment and systems for the management and control of electrical energy and other critical processes. Headquartered in Houston, Texas, we serve the oil and gas refining, offshore oil and gas production, petrochemical, pipeline, terminal, pulp and paper, mining and metals, light rail traction power, and electric utility markets. Revenues and costs are primarily related to custom engineered-to-order equipment and systems and accounted for under percentage of completion accounting which precludes us from providing detailed price and volume information.

[0001564590-14-006033:mdna:4]
The markets in which we participate are capital intensive and cyclical in nature. Cyclicality is predominantly driven by customer demand, global economic conditions and anticipated environmental or regulatory changes which affect the manner in which our customers proceed with capital investments. Our customers analyze various factors including the demand for oil, gas and electrical energy, the overall financial environment, governmental budgets, regulatory actions and environmental concerns. These factors influence the release of new capital projects by our customers, which are traditionally awarded in competitive bid situations. Scheduling is matched to the customer requirements and projects may take a number of months to produce; schedules also may change during the course of any particular project. Our operating results can be impacted by factors outside of our control.  For example, many of our projects have contracting arrangements where the approval of engineering and design specifications may affect the timing of the project execution thus impacting the recognition of revenue and costs. In the second half of Fiscal 2014, we experienced schedule changes on various U.S. projects which negatively impacted our results as the revenues have been pushed into subsequent quarters.

[0001564590-14-006033:mdna:5]
As of September 30, 2014, our order backlog strengthened to $507.1 million, an increase of approximately $69.2 million over the beginning of this fiscal year. Our backlog includes various projects, some of which are petrochemical, oil and gas construction and transportation infrastructure projects which take a number of months to produce.

[0001564590-14-006033:mdna:6]
The strength in the western Canadian oil and gas markets continued to be a major contributor to our increase in revenue in Fiscal 2014.  We completed the construction of our new Canadian facility and relocated operations from our previous facility in the fall of 2013. The production ramp of our Canadian operations has presented challenges resulting in inefficiencies that have led to extended project delivery times, higher operating costs, gross margin deterioration and project revenues being pushed into Fiscal 2015.  We continue to take actions to mitigate the risks associated with these challenges.

[0001564590-14-006033:mdna:7]
On January 15, 2014, we sold Transdyn to a global provider of electronic toll collection systems, headquartered in Vienna, Austria.  The purchase price from the sale of this subsidiary totaled $16.0 million, of which we received cash of $14.4 million. The remaining $1.6 million was placed into an escrow account until April 2015, to be released subject to certain contingent obligations, and was recorded to other assets.  We received additional cash of $0.4 million after the final working capital adjustment was calculated in March 2014. We recorded a gain on this transaction of $8.6 million, net of tax, which has been included in income from discontinued operations in Fiscal 2014 in the accompanying consolidated statements of operations. We reclassified the assets and liabilities of Transdyn as held for sale within the accompanying consolidated balance sheets as of September 30, 2013 and presented the results of these operations as income from discontinued operations, net of tax, for each of the accompanying consolidated statements of operations.  Accordingly, we have removed Transdyn from the Results of Operations discussions below. For more information about this disposition, see Note N of the Notes to Consolidated Financial Statements included elsewhere in this Annual Report.

[0001564590-14-006033:mdna:8]
In the fourth quarter of Fiscal 2013, we recovered approximately $5.1 million related to one large project at Powell Canada, of which approximately $3.8 million was recorded as revenue and the remaining $1.3 million was related to amounts recorded to other assets in prior periods.  This recovery related to cost overruns on a large project with execution challenges which negatively impacted revenue and gross profit in Fiscal 2012.

[0001564590-14-006033:mdna:9]
Results of Operations

[0001564590-14-006033:mdna:10]
Twelve Months Ended September 30, 2014 Compared to Twelve Months Ended September 30, 2013

[0001564590-14-006033:mdna:11]
Revenue and Gross Profit

[0001564590-14-006033:mdna:12]
Revenues increased 1.1% or $6.9 million, to $647.8 million in Fiscal 2014.  Domestic revenues decreased 2.5%, or $9.3 million, to $365.1 million in Fiscal 2014 primarily due to the mix of projects and international revenues increased 6.1%, or $16.3 million, to $282.7 million in Fiscal 2014. The expansion of our Canadian operations contributed to the increase in international revenues.  Revenues from industrial customers increased $18.8 million to $474.4 million in Fiscal 2014. Revenues from public and private utilities decreased $11.6 million to $127.0 million in Fiscal 2014. Revenues from municipal and transit projects decreased $0.3 million to $46.3 million in Fiscal 2014. Additionally, revenues in Fiscal 2013 were favorably impacted by the recovery of $3.8 million related to cost overruns from a previous year on a large industrial project.

[0001564590-14-006033:mdna:13]
Gross profit decreased 9.4%, or $13.0 million, to $125.5 million in Fiscal 2014.  Gross profit as a percentage of revenues decreased to 19.4% in Fiscal 2014, compared to 21.6% in Fiscal 2013 primarily due to higher costs resulting from the efficiency and utilization challenges associated with the ramp of our Canadian operations.  Additionally, we incurred higher operating costs associated with inefficiencies from the re-implementation of our existing ERP system and added a suite of new software tools to expand our Business Systems.  These higher costs were partially offset by various supply chain and productivity initiatives.  Gross profit for Fiscal 2013 was favorably impacted by the $3.8 million recovery from the project discussed above.

[0001564590-14-006033:mdna:14]
Selling, General and Administrative Expenses

[0001564590-14-006033:mdna:15]
Selling, general and administrative expenses increased by $8.0 million to $87.8 million in Fiscal 2014, compared to Fiscal 2013, primarily due to increased personnel costs, travel and administrative expenses and bad debts.  Selling, general and administrative expenses, as a percentage of revenues, increased to 13.5% in Fiscal 2014, compared to 12.4% in Fiscal 2013. This increase in selling, general and administrative expense was partially offset by a decrease in depreciation expense as our existing Business Systems became fully depreciated in December 2012 and the favorable impact of the capitalization of certain personnel costs associated with the development and implementation of our new Business Systems, which went live in May 2014.  However, going forward, the favorable impact of depreciation expense and capitalization of certain personnel costs will no longer be realized.

[0001564590-14-006033:mdna:16]
Amortization of Intangible Assets

[0001564590-14-006033:mdna:17]
Amortization of intangible assets decreased to $0.8 million in Fiscal 2014 compared to $1.7 million in Fiscal 2013 primarily due to the amendment to the supply agreement which is discussed in Note E of the Notes to Consolidated Financial Statements included elsewhere in this Annual Report.

[0001564590-14-006033:mdna:18]
Other Income

[0001564590-14-006033:mdna:19]
We recorded other income of $1.5 million in Fiscal 2014 which represents the amortization of the deferred gain from the amendment to the supply agreement discussed above.  We did not record other income in Fiscal 2013.

[0001564590-14-006033:mdna:20]
Income Tax Provision

[0001564590-14-006033:mdna:21]
Our provision for income taxes for continuing operations was $11.1 million in Fiscal 2014, compared to $7.4 million in Fiscal 2013.  The effective tax rate in Fiscal 2014 was 36.1%, which approximates the combined U.S. federal and state statutory rates as the majority of our income is attributable to the U.S. Additionally, the Federal Research and Development Tax Credit (R&D Credit) expired December 31, 2013.   The effective tax rate for Fiscal 2013 was 15.7% and was favorably impacted by the release of the $7 million valuation allowance recorded as an offset to the prior years’ Canadian pre-tax losses and the R&D Credit as well as the utilization of certain foreign tax credits.  For further information on the effective tax rate for Fiscal 2013, see Note H of the Notes to Consolidated Financial Statements included elsewhere in this Annual Report.

[0001564590-14-006033:mdna:22]
Income from Continuing Operations

[0001564590-14-006033:mdna:23]
In Fiscal 2014, we recorded income from continuing operations of $19.6 million, or $1.62 per diluted share, compared to $39.7 million, or $3.32 per diluted share, in Fiscal 2013.  This decrease in income from continuing operations was primarily due to efficiency and utilization challenges associated with the ramp of our Canadian operations, higher operating costs associated with inefficiencies from the re-implementation of our existing ERP system and the mix of projects in process at our domestic operations.

[0001564590-14-006033:mdna:24]
Income from Discontinued Operations

[0001564590-14-006033:mdna:25]
In Fiscal 2014, we recorded $9.6 million, or $0.80 per diluted share, of income from discontinued operations compared to $2.3 million, or $0.19 per diluted share, in Fiscal 2013 as the current fiscal year includes the gain on the sale. For additional information about this disposition, see Note N of the Notes to Consolidated Financial Statements included elsewhere in this Annual Report.

[0001564590-14-006033:mdna:26]
Backlog

[0001564590-14-006033:mdna:27]
The order backlog at September 30, 2014 was $507.1 million, compared to $437.9 million at September 30, 2013.  New orders placed in Fiscal 2014 totaled $725.8 million compared to $715.7 million in Fiscal 2013.  The year over year increase in new orders was primarily due to the continued strength in oil and gas production and petrochemical and pipeline projects.

[0001564590-14-006033:mdna:28]
Twelve Months Ended September 30, 2013 Compared to Twelve Months Ended September 30, 2012

[0001564590-14-006033:mdna:29]
Revenue and Gross Profit

[0001564590-14-006033:mdna:30]
Revenues decreased 7.2%, or $49.9 million, to $640.9 million in Fiscal 2013 compared to Fiscal 2012.  Domestic revenues decreased by 3.7%, or $14.6 million, to $374.4 million in Fiscal 2013 and international revenues decreased 11.7%, or $35.3 million, to $266.5 million in Fiscal 2013. Revenues decreased primarily due to the completion of certain complex domestic and international petrochemical and oil and gas construction projects that were in process during Fiscal 2012. However, revenues in Fiscal 2013 were favorably impacted by the recovery of $3.8 million related to cost overruns on a large industrial project at Powell Canada.  This Canadian project experienced execution challenges in the first half of Fiscal 2012, which negatively impacted revenue and gross profit in Fiscal 2012. Revenues from public and private utilities increased $22.8 million to $138.6 million in Fiscal 2013. Revenues from industrial customers decreased $70.7 million to $455.6 million in Fiscal 2013. Revenues from municipal and transit projects decreased $2.0 million to $46.6 million in Fiscal 2013.

[0001564590-14-006033:mdna:31]
Gross profit increased 4.3%, or $5.7 million, to $138.5 million in Fiscal 2013. Gross profit as a percentage of revenues increased to 21.6% in Fiscal 2013, compared to 19.2% in Fiscal 2012.  These increases were primarily driven by the recovery from the Canadian contract settlement discussed above, the margins associated with the mix of projects in process during Fiscal 2012 and 2013, as well as the increased focus on cost reduction activities.

[0001564590-14-006033:mdna:32]
Selling, General and Administrative Expenses

[0001564590-14-006033:mdna:33]
Selling, general and administrative expenses increased $2.7 million to $79.7 million in Fiscal 2013. Selling, general and administrative expenses, as a percentage of revenues, increased to 12.4% in Fiscal 2013 from 11.1% in Fiscal 2012. This increase was primarily related to increased personnel costs and increased long-term incentive compensation resulting from higher levels of operating performance over the three-year performance cycle. This increase in selling, general and administrative expenses was offset by a decrease in depreciation expense as our Business Systems became fully depreciated in December 2012. Additionally, selling, general and administrative costs for Fiscal 2013 were favorably impacted by the capitalization of certain personnel costs in Fiscal 2013 associated with the development and implementation of our new Business Systems. However, the favorable impact of depreciation expense and capitalization of certain personnel costs will no longer be realized as the Business Systems were implemented in Fiscal 2014.

[0001564590-14-006033:mdna:34]
Amortization of Intangible Assets

[0001564590-14-006033:mdna:35]
Amortization of intangible assets decreased to $1.7 million in Fiscal 2013, compared to $2.6 million in Fiscal 2012, as certain intangible assets became fully amortized.

[0001564590-14-006033:mdna:36]
Restructuring and Relocation Costs

[0001564590-14-006033:mdna:37]
During Fiscal 2013, we recorded restructuring and relocation charges totaling $3.9 million.  We incurred approximately $2.8 million in Fiscal 2013 related to relocation efforts in connection with the construction of our new facility in Houston, Texas and our new facility in Acheson, Alberta, Canada.  These costs were primarily related to the relocation of our operations, the loss on the sublease, and the abandonment of leasehold improvements on the previously occupied facilities in the second half of Fiscal 2013. The construction of our two new facilities was substantially completed in September 2013 and we relocated the majority of our operations and personnel from their previously leased facilities.

[0001564590-14-006033:mdna:38]
In the third quarter of Fiscal 2013, we recorded and paid $1.1 million related to severance at our United Kingdom operations.  These operations were negatively impacted by market conditions and competitive pressures in the international markets in which they operate; therefore, we exited certain non-core operations and eliminated certain positions to better align our workforce with current market conditions.

[0001564590-14-006033:mdna:39]
Gain on Settlement

[0001564590-14-006033:mdna:40]
In March 2013, we settled a lawsuit we had filed against the previous owners of Powell Canada in the amount of $1.7 million, which was received in April 2013.  There was no gain on settlement in Fiscal 2012.

[0001564590-14-006033:mdna:41]
Income Tax Provision

[0001564590-14-006033:mdna:42]
Our provision for income taxes reflected an effective tax rate on earnings before income taxes of 15.7% in Fiscal 2013 compared to 38.6% in Fiscal 2012.  The effective tax rate for Fiscal 2013 was favorably impacted by the release of the $7 million valuation allowance recorded as an offset to the prior years’ Canadian pre-tax losses.  We believe that it is more likely than not that the market conditions and our operating results going forward will allow us to realize the deferred tax assets associated with the prior year losses in Canada.  The rate for Fiscal 2013 was also favorably impacted by the Federal Research and Development Tax Credit and the utilization of certain foreign tax credits.  The effective tax rate for Fiscal 2012 was negatively impacted by our inability to record a tax benefit related to pre-tax losses in Canada.  For further information on the effective tax rate for Fiscal 2013, see Note H of the Notes to Consolidated Financial Statements included elsewhere in this Annual Report.

[0001564590-14-006033:mdna:43]
Income from Continuing Operations

[0001564590-14-006033:mdna:44]
In Fiscal 2013, we recorded income from continuing operations of $39.7 million, or $3.32 per diluted share, compared to $28.7 million, or $2.41 per diluted share, in Fiscal 2012.  Income from continuing operations in Fiscal 2013 was positively impacted by the recovery of $3.8 million from the Canadian contract settlement and the favorable tax benefits discussed above.

[0001564590-14-006033:mdna:45]
Income from Discontinued Operations

[0001564590-14-006033:mdna:46]
In Fiscal 2013, we recorded $2.3 million, or $0.19 per diluted share, of income from discontinued operations compared to $0.9 million, or $0.08 per diluted share, in Fiscal 2012. For additional information about this disposition, see Note N of the Notes to Consolidated Financial Statements.

[0001564590-14-006033:mdna:47]
Backlog

[0001564590-14-006033:mdna:48]
The order backlog at September 30, 2013, was $437.9 million, compared to $365.9 million at September 30, 2012. New orders placed during Fiscal 2013 totaled $715.7 million compared to $659.9 million in Fiscal 2012. The backlog for Fiscal 2013 increased primarily due to continued strength in oil and gas production projects, refining projects and transportation markets.

[0001564590-14-006033:mdna:49]
Liquidity and Capital Resources

[0001564590-14-006033:mdna:50]
Cash and cash equivalents decreased to $103.1 million at September 30, 2014, compared to $107.4 million at September 30, 2013.  As of September 30, 2014, current assets exceeded current liabilities by 2.3 times and our debt to total capitalization ratio was 0.85%.

[0001564590-14-006033:mdna:51]
We have a $75.0 million revolving credit facility in the U.S., which expires in December 2016. As of September 30, 2014, there were no amounts borrowed under this line of credit. We also have a $9.0 million revolving credit facility in Canada. At September 30, 2014, there was no balance outstanding under the Canadian revolving credit facility. Total long-term debt and capital lease obligations, including current maturities, totaled $3.2 million at September 30, 2014, compared to $3.6 million at September 30, 2013. Total letters of credit outstanding were $21.5 million and $20.1 million at September 30, 2014 and 2013, respectively, which reduce our availability under our U.S. credit facility and our Canadian revolving credit facility. Amounts available at September 30, 2014 under the U.S. and Canadian revolving credit facilities were $53.5 million and $9.0 million, respectively. For further information regarding our debt, see Notes F and G of the Notes to Consolidated Financial Statements included elsewhere in this Annual Report.

[0001564590-14-006033:mdna:52]
Approximately $5.9 million of our cash at September 30, 2014 was held outside of the United States for international operations. It is our intention to indefinitely reinvest all current and future foreign earnings internationally in order to ensure sufficient working capital and support and expand these international operations. In the event that we elect to repatriate some or all of the foreign earnings that were previously deemed to be indefinitely reinvested outside the U.S., under current tax laws we would incur additional tax expense upon such repatriation.

[0001564590-14-006033:mdna:53]
We believe that cash available and borrowing capacity under our existing credit facilities should be sufficient to finance anticipated operating activities, capital improvements and expansions, as well as debt repayments, for the foreseeable future. We continue to monitor the factors that drive our markets and strive to maintain our leadership and competitive advantage in the markets we serve while aligning our cost structures with market conditions.

[0001564590-14-006033:mdna:54]
Operating Activities

[0001564590-14-006033:mdna:55]
During Fiscal 2014, net cash provided by operating activities was $9.1 million.  During Fiscal 2013, net cash provided by operating activities was $91.4 million and in Fiscal 2012, net cash used in operating activities was $6.0 million. Cash flow from operations is primarily influenced by demand for our products and services and is impacted as our progress payment terms with our customers are matched with the payment terms with our suppliers. During Fiscal 2014, our cash from operations decreased over Fiscal 2013, primarily due to the timing of billing and collection of contracts receivable based on the progress billing milestones, an increase in inventories and a decrease in accounts payable and income taxes payable.  The increase in inventories resulted in part from supply chain inefficiencies resulting from the re-implementation of our Business Systems.  These uses of cash were partially offset by the $10.0 million received from the amended supply agreement.  For further information regarding the amended supply agreement, see Note E of the Notes to Consolidated Financial Statements included elsewhere in this Annual Report.  Additionally in Fiscal 2013, we received $6.8 million in contract settlements related to Fiscal 2012 matters. During Fiscal 2012, the cash used in operations of $6.0 million was primarily the result of increased unbilled contract receivables based on progress billing milestones.

[0001564590-14-006033:mdna:56]
Investing Activities

[0001564590-14-006033:mdna:57]
Purchases of property, plant and equipment during Fiscal 2014 totaled $16.5 million compared to $74.4 million and $29.1 million in Fiscal 2013 and 2012, respectively. A significant portion of the investments in Fiscal 2012 and 2013 were to acquire land and build facilities in the United States and Canada to support our continued expansion in our key markets, including the oil and gas markets and Canadian oil sands region. Costs related to the re-implementation and additional software added to our Business Systems were incurred during Fiscal 2013 and were placed into service in the third quarter of Fiscal 2014.

[0001564590-14-006033:mdna:58]
Financing Activities

[0001564590-14-006033:mdna:59]
Net cash used in financing activities was $12.5 million in Fiscal 2014 and $0.5 million in Fiscal 2013. Net cash provided by financing activities was $1.3 million during Fiscal 2012 due to cash being received from the exercise of stock options. The increase in the use of cash in Fiscal 2014 was primarily driven by the payment of $12.0 million in cash dividends.

[0001564590-14-006033:mdna:60]
Contractual and Other Obligations

[0001564590-14-006033:mdna:61]
At September 30, 2014, our long-term contractual obligations were limited to debt and leases. The table below details our commitments by type of obligation, including interest if applicable, and the period that the payment will become due (in thousands).

[0001564590-14-006033:mdna:62]
| As of September 30, 2014, Payments Due by Period: | Long‑TermDebtObligations |  |  |  | OperatingLeaseObligations |  |  | Total |  |
| Less than 1 year | $ | 406 |  |  |  | $ | 4,155 |  |  | $ | 4,561 |  |
| 1 to 3 years |  | 809 |  |  |  |  | 5,490 |  |  |  | 6,299 |  |
| 3 to 5 years |  | 806 |  |  |  |  | 3,036 |  |  |  | 3,842 |  |
| More than 5 years |  | 1,202 |  |  |  |  | 5,586 |  |  |  | 6,788 |  |
| Total long-term contractual obligations | $ | 3,223 |  |  |  | $ | 18,267 |  |  | $ | 21,490 |  |

[0001564590-14-006033:mdna:63]
The lease on our previously occupied Canadian facility does not expire until July 2023; however, we have sublet that facility through July 2019.

[0001564590-14-006033:mdna:64]
As of September 30, 2014, the total unrecognized tax benefit related to uncertain tax positions was $4.0 million. We estimate that none of this will be paid within the next 12 months.  However, we believe that it is reasonably possible that within the next 12 months, the total unrecognized tax benefits will decrease by approximately 1% due to the expiration of certain statutes of limitations in various state and local jurisdictions.  We are unable to make reasonably reliable estimates regarding the timing of future cash outflows, if any, associated with the remaining unrecognized tax benefits.

[0001564590-14-006033:mdna:65]
Other Commercial Commitments

[0001564590-14-006033:mdna:66]
We are contingently liable for secured and unsecured letters of credit of $24.2 million as of September 30, 2014, of which $21.5 million reduces our borrowing capacity.

[0001564590-14-006033:mdna:67]
The following table reflects potential cash outflows that may result in the event that we are unable to perform under our contracts (in thousands):

[0001564590-14-006033:mdna:68]
| As of September 30, 2014, Payments Due by Period: |  | Letters ofCredit |  |
| Less than 1 year |  | $ | 12,939 |  |
| 1 to 3 years |  |  | 8,340 |  |
| More than 3 years |  |  | 2,893 |  |
| Total long-term commercial obligations |  | $ | 24,172 |  |

[0001564590-14-006033:mdna:69]
We also had performance and maintenance bonds totaling $298.7 million that were outstanding at September 30, 2014. Performance and maintenance bonds are primarily used to guarantee our contract performance to our customers.

[0001564590-14-006033:mdna:70]
Outlook

[0001564590-14-006033:mdna:71]
The markets in which we participate are capital-intensive and cyclical in nature. Cyclicality is predominantly driven by customer demand, global economic conditions and anticipated environmental or regulatory changes which affect the manner in which our customers proceed with capital investments. Our customers analyze various factors including the demand for oil, gas and electrical energy, the overall financial environment, governmental budgets, regulatory actions and environmental concerns. These factors influence the release of new capital projects by our customers, which are traditionally awarded in competitive bid situations. Scheduling is matched to the customer requirements; and projects may take a number of months to produce; schedules also may change during the course of any particular project.

[0001564590-14-006033:mdna:72]
Growth in demand for energy is expected to continue over the long term. This, when coupled with the need for replacement of existing infrastructure that is nearing the end of its life cycle, demonstrates a continued need for products and services produced by us. Our orders over the past year have been solid, driven primarily by the relative stability in the oil and gas industry overall, along with the specific demand associated with Canadian oil sands related projects. We continue to experience timing challenges in the near-term related to the awarding of large projects due to various global market conditions and industry constraints. However, the long-term outlook for continued opportunities for our products and services remains positive; even though the timing and pricing of many of these projects are difficult to predict.

[0001564590-14-006033:mdna:73]
Our operating results are frequently impacted by the timing and resolution of change orders and project close-out which could cause gross margins to improve or deteriorate during the period in which these items are approved and finalized with customers. Our operating results are also impacted by factors outside of our control, such as our projects that have contract arrangements where the approval of engineering and design specifications may affect the timing of the project execution.

[0001564590-14-006033:mdna:74]
The western Canadian oil and gas market continues to provide project opportunities for Powell. Demand for our products and solutions in this market are placing pressure on our production ramp plan. We completed the construction of our new Acheson, Alberta facility and relocated operations from our previous facility in the fall of 2013. The production ramp of our Canadian operations has presented and may continue to present challenges resulting in inefficiencies and extended project delivery times. We believe the challenges from the ramp of our Canadian operations will likely result in higher costs, gross margin deterioration and delay the recognition of revenues into Fiscal 2015.  We continue to take actions to mitigate the risks associated with these challenges.

[0001564590-14-006033:mdna:75]
We are in the process of expanding our manufacturing facility in Acheson, Alberta, Canada. The expansion is expected to cost approximately $33 million and is expected to be funded from our existing cash and cash equivalents and future cash flows from operations.  We expect the expansion of our Canadian facility to be completed in early Fiscal 2015.

[0001564590-14-006033:mdna:76]
We believe that cash available and borrowing capacity under our existing credit facilities should be sufficient to finance anticipated operating activities, capital improvements and debt repayments for the foreseeable future. We continue to monitor our markets and will strive to maintain our leadership and competitive advantage in the markets we serve.

[0001564590-14-006033:mdna:77]
Effects of Inflation

[0001564590-14-006033:mdna:78]
We are subject to inflation, which can cause increases in our costs of raw materials, primarily copper, aluminum and steel. Fixed-price contracts can limit our ability to pass these increases to our customers, thus negatively impacting our earnings. The inflation in commodity prices could potentially impact our operations in future years.

[0001564590-14-006033:mdna:79]
Critical Accounting Policies and Estimates

[0001564590-14-006033:mdna:80]
The preparation of consolidated financial statements in conformity with accounting principles generally accepted in the United States of America requires management to make estimates and assumptions that affect the reported amounts of assets, liabilities, revenues and expenses and the disclosures of contingent assets and liabilities. We base our estimates on historical experience and on various other assumptions that are believed to be reasonable under the circumstances. Actual results may differ from these estimates. We believe the following accounting policies and estimates to be critical in the preparation and reporting of our consolidated financial statements.

[0001564590-14-006033:mdna:81]
Revenue Recognition

[0001564590-14-006033:mdna:82]
Our revenues are primarily generated from the engineering and manufacturing of custom products under long-term contracts that may last from one month to several years, depending on the contract. Revenues from long-term contracts are recognized on the percentage-of-completion method of accounting. Occasionally a contract may require that we segment the project into specific deliverables for revenue recognition. Segmenting a contract may result in different interim rates of profitability for each scope of service than if we had recognized revenue on a combined basis.

[0001564590-14-006033:mdna:83]
Under the percentage-of-completion method of accounting, revenues are recognized as work is performed. The estimated completion to date is calculated by multiplying the total contract price by the percentage of performance to date, which is based on total costs or total labor dollars incurred to date compared to the total estimated costs or total labor dollars estimated at completion. The method used to determine the percentage of completion is typically the cost method, unless the labor method is a more accurate method of measuring the progress of the project. Application of the percentage-of-completion method of accounting requires the use of estimates of costs to be incurred for the performance of the contract. Contract costs include all direct material costs, direct labor costs and those indirect costs related to contract performance, such as indirect labor, supplies, tools, repairs and all costs associated with operation of equipment. The cost estimation process is based upon the professional knowledge and experience of our engineers, project managers and financial professionals. Factors that are considered in estimating the work to be completed and ultimate contract recovery include the availability and productivity of labor, the nature and complexity of the work to be performed, the effect of change orders, the availability of materials, the effect of any delays on our project performance and the recoverability of any claims. Changes in job performance, job conditions, estimated profitability and final contract settlements, including our estimate of liquidated damages, if any, may result in revisions to costs and income, with their effects being recognized in the period in which the revisions are determined. Whenever revisions of estimated contract costs and contract values indicate that the contract costs will exceed estimated revenues, thus creating a loss, a provision for the total estimated loss is recorded in that period.

[0001564590-14-006033:mdna:84]
Revenues associated with maintenance, repair and service contracts are recognized when the services are performed. Expenses related to these types of services are recognized as incurred.

[0001564590-14-006033:mdna:85]
Costs and estimated earnings in excess of billings on uncompleted contracts also include certain costs associated with unapproved change orders. These costs are included when change order approval is probable. Amounts are carried at the lower of cost or net realizable value. Revenue is recognized to the extent of costs incurred when recovery is probable. The amounts recorded involve the use of judgments and estimates; thus, actual recoverable amounts could differ from original assumptions.

[0001564590-14-006033:mdna:86]
Allowance for Doubtful Accounts

[0001564590-14-006033:mdna:87]
We maintain and continually assess the adequacy of an allowance for doubtful accounts representing our estimate for losses resulting from the inability of our customers to pay amounts due to us. This estimated allowance is based on historical experience of uncollected accounts, the level of past due accounts, the overall level of outstanding accounts receivable, information about specific customers with respect to their inability to make payments and expectations of future conditions that could impact the collectability of accounts receivable. However, future changes in our customers’ operating performance and cash flows, or in general economic conditions, could have an impact on their ability to fully pay these amounts, which, among other things, could have a material adverse impact on our operating results.

[0001564590-14-006033:mdna:88]
Impairment of Long-Lived Assets

[0001564590-14-006033:mdna:89]
We review long-lived assets for impairment whenever events or changes in circumstances indicate that the carrying value may not be realizable. If an evaluation is required, the estimated future undiscounted cash flows associated with the asset are compared to the asset’s carrying amount to determine if an impairment of such asset is necessary. This requires us to make long-term forecasts of the future revenues and costs related to the assets subject to review. Forecasts require assumptions about demand for our products and future market conditions. Estimating future cash flows requires significant judgment, and our projections may vary from cash flows eventually realized. Future events and unanticipated changes to assumptions could require a provision for impairment in a future period. The effect of any impairment would be reflected in income (loss) from operations in the Consolidated Statements of

[0001564590-14-006033:mdna:90]
Operations. In addition, we estimate the useful lives of our long-lived assets and other intangibles and periodically review these estimates to determine whether these lives are appropriate.

[0001564590-14-006033:mdna:91]
Intangible Assets

[0001564590-14-006033:mdna:92]
Goodwill and other intangible assets with indefinite useful lives are no longer amortized, but are evaluated for impairment annually, or immediately if conditions indicate that impairment could exist. The evaluation requires a two-step impairment test to identify potential goodwill impairment and measure the amount of a goodwill impairment loss. The first step of the test compares the fair value of a reporting unit with its carrying amount, including goodwill. If the carrying amount of a reporting unit exceeds its fair value, the second step of the goodwill impairment test is performed to measure the amount of the impairment loss. Both steps of the goodwill impairment testing involve significant estimates.

[0001564590-14-006033:mdna:93]
The costs of intangible assets with determinable useful lives are amortized over their estimated useful lives. When certain events or changes in operating conditions occur, an impairment assessment is performed and the lives of intangible assets with determinable lives may be adjusted.

[0001564590-14-006033:mdna:94]
Accruals for Contingent Liabilities

[0001564590-14-006033:mdna:95]
From time to time, contingencies such as insurance, liquidated damages and legal claims arise in the normal course of business. Pursuant to current accounting standards, we must evaluate such contingencies to subjectively determine the likelihood that an asset has been impaired or a liability has been incurred at the date of the financial statements, as well as evaluate whether the amount of the loss can be reasonably estimated. If the likelihood is determined to be probable and it can be reasonably estimated, the estimated loss is recorded. The amounts we record for insurance claims, warranties, legal and other contingent liabilities require judgments regarding the amount of expenses that will ultimately be incurred. We use past experience and history, as well as the specific circumstances surrounding each contingent liability, in evaluating the amount of liability that should be recorded. Actual results could differ from our estimates.

[0001564590-14-006033:mdna:96]
Warranty Costs

[0001564590-14-006033:mdna:97]
We provide for estimated warranty costs with the recognition of revenue based upon historical rates applicable to individual product lines. In addition, specific provisions are made when the costs of such warranties are expected to exceed accruals. Our standard terms and conditions of sale include a warranty for parts and service for the earlier of 18 months from the date of shipment or 12 months from the date of energization. Occasionally projects require warranty terms that are longer than our standard terms due to the nature of the project. Extended warranty terms may be negotiated and included in our contracts. We use past experience and historical claims to determine the estimated liability. Actual results could differ from our estimate.

[0001564590-14-006033:mdna:98]
Accounting for Income Taxes

[0001564590-14-006033:mdna:99]
We account for income taxes under the asset and liability method, based on the income tax laws and rates in the countries in which operations are conducted and income is earned. This approach requires the recognition of deferred tax assets and liabilities for the expected future tax consequences of temporary differences between the carrying amounts and the tax basis of assets and liabilities. Developing our provision for income taxes requires significant judgment and expertise in federal, international and state income tax laws, regulations and strategies, including the determination of deferred tax assets and liabilities and, if necessary, any valuation allowances that may be required for deferred tax assets. We record a valuation allowance to reduce our deferred tax assets to the amount that is more likely than not to be realized. Although our Canadian operations reported a loss for Fiscal 2014, we believe that the net deferred tax asset recorded as of September 30, 2014, is realizable through future reversals of existing taxable temporary differences and future taxable income. The recognition of deferred tax assets requires estimates related to future income and other assumptions regarding timing and future profitability.  Estimates may change as new events occur, additional information becomes available or operating environments change. We will continue to assess the adequacy of the valuation allowance on a quarterly basis. Our judgments and tax strategies are subject to audit by various taxing authorities.

[0001564590-14-006033:mdna:100]
The objectives of accounting for income taxes are to recognize the amount of taxes payable or refundable for the current year and deferred tax liabilities and assets for the future tax consequences of events that have been recognized in an entity’s financial statements or tax returns. We recognize the tax benefit from an uncertain tax position only if it is more likely than not that the tax position will be sustained on examination by the taxing authorities, based on the technical merits of the position. The tax benefits recognized in the financial statements from such a position should be measured based on the largest benefit that has a greater than 50% likelihood of being realized upon ultimate settlement. Accounting literature also provides guidance on derecognition of income tax assets and liabilities, classification of current and deferred income tax assets and liabilities, accounting for interest and penalties associated with tax positions, and income tax disclosures. Judgment is required in assessing the future tax consequences of events that

[0001564590-14-006033:mdna:101]
have been recognized in our financial statements or tax returns. Variations in the actual outcome of these future tax consequences could materially impact our financial statements.

[0001564590-14-006033:mdna:102]
See Note H of Notes to Consolidated Financial Statements included elsewhere in this Annual Report for disclosures related to the valuation allowance recorded in relation to foreign deferred taxes.

[0001564590-14-006033:mdna:103]
Foreign Currency Translation

[0001564590-14-006033:mdna:104]
The functional currency for our foreign subsidiaries is the local currency in which the entity is located. The financial statements of all subsidiaries with a functional currency other than the U.S. Dollar have been translated into U.S. Dollars. All assets and liabilities of foreign operations are translated into U.S. Dollars using year-end exchange rates, and all revenues and expenses are translated at average rates during the respective period. The U.S. Dollar results that arise from such translation, as well as exchange gains and losses on intercompany balances of a long-term investment nature, are included in the cumulative currency translation adjustments in accumulated other comprehensive income in stockholders’ equity.

[0001564590-14-006033:mdna:105]
New Accounting Pronouncements

[0001564590-14-006033:mdna:106]
From time to time, new accounting pronouncements are issued by the Financial Accounting Standards Board (the FASB), which are adopted by us as of the specified effective date. Unless otherwise discussed, management believes that the impact of recently issued standards, which are not yet effective, will not have a material impact on our consolidated statements upon adoption.

[0001564590-14-006033:mdna:107]
In March 2013, the FASB issued accounting guidance to resolve the diversity in practice for accounting for the release of the cumulative translation adjustment into net income when a parent either sells a part or all of its investment in a foreign entity or no longer holds a controlling financial interest in a subsidiary or group of assets that is a nonprofit activity or a business (other than a sale of real estate or conveyance of oil and gas mineral rights) within a foreign entity. This guidance is effective prospectively for fiscal years (and interim reporting periods within those years) beginning after December 15, 2013, which would be our fiscal year ended September 30, 2015. We do not expect this guidance to have a material impact on our consolidated financial position or results of operations.

[0001564590-14-006033:mdna:108]
In July 2013, the FASB issued accounting guidance on the presentation of an unrecognized tax benefit when a net operating loss carryforward, a similar tax loss, or a tax credit carryforward exists. The guidance states that an unrecognized tax benefit, or a portion of an unrecognized tax benefit, should be presented in the financial statements as a reduction to a deferred tax asset for a net operating loss carryforward, a similar tax loss, or a tax credit carryforward. To the extent a net operating loss carryforward, a similar tax loss, or a tax credit carryforward is not available at the reporting date under the tax law of the applicable jurisdiction to settle any additional income taxes that would result from the disallowance of a tax position or the tax law of the applicable jurisdiction does not require the entity to use, and the entity does not intend to use, the deferred tax asset for such purpose, the unrecognized tax benefit should be presented in the financial statements as a liability and should not be combined with deferred tax assets. This guidance is effective for fiscal years, and interim periods within those years, beginning after December 15, 2013, which would be our fiscal year ended September 30, 2015. This guidance should be applied prospectively to all unrecognized tax benefits that exist at the effective date. Retrospective application is permitted. The adoption of this guidance is not expected to have a significant impact on our consolidated financial position or results of operations.

[0001564590-14-006033:mdna:109]
In April 2014, the FASB issued an amendment to the financial reporting of discontinued operations.  The amendments in this update changed the criteria for reporting discontinued operations while enhancing disclosures in this area. It also addresses sources of confusion and inconsistent application related to the financial reporting of discontinued operations guidance in U.S. GAAP.  Under the new guidance, only disposals representing a strategic shift in operations that have a major effect on the organization’s operations and financial results should be presented as discontinued operations. Examples include a disposal of a major geographic area, a major line of business, or a major equity method investment.  In addition, the new guidance requires expanded disclosures about discontinued operations that will provide financial statement users with more information about the assets, liabilities, income, and expenses of discontinued operations.  The new guidance also requires disclosure of the pre-tax income attributable to a disposal of a significant part of an organization that does not qualify for discontinued operations reporting. This disclosure will provide users with information about the ongoing trends in a reporting organization’s results from continuing operations. The amendments in this update are effective in the first quarter of 2015, which would be our fiscal year end September 30, 2016.  Early adoption is permitted for disposals that have not been previously reported as discontinued operations.

[0001564590-14-006033:mdna:110]
In May 2014, the FASB issued a new standard on revenue recognition that supersedes previously issued revenue recognition guidance.  This standard provides a five-step approach to be applied to all contracts with customers and requires expanded disclosures about the nature, amount, timing and uncertainty of revenue (and the related cash flows) arising from customer contracts, significant judgments and changes in judgments used in applying the revenue model and the assets recognized from costs incurred to obtain or fulfill a contract.  This new standard is effective for us beginning in fiscal year 2018.  Early application is not permitted. The standard permits

[0001564590-14-006033:mdna:111]
the use of either the retrospective or cumulative effect transition method therefore we are evaluating the effect that this new guidance will have on our consolidated financial statements and related disclosures. We have not yet selected a transition method nor have we determined the effect of the standard on our ongoing financial reporting.

[0001564590-14-006033:mdna:112]
In June 2014, the FASB issued an amendment to the topic regarding share-based payments and instances where terms of an award provide that a performance target can be achieved after the requisite service period.  This guidance has been provided to resolve the diversity in practice concerning employee share-based payments that contain performance targets that could be achieved after the requisite service period. The updated guidance requires that a performance target that affects vesting and that can be achieved after the requisite service period be treated as a performance condition. Compensation cost should be recognized in the period in which it becomes probable that the performance target will be achieved and is attributable to the periods for which service has been rendered. If the performance target becomes probable of being achieved before the end of the service period, the remaining unrecognized compensation cost for which requisite service has not yet been rendered is recognized prospectively over the remaining service period. The total amount of compensation cost recognized during and after the service period should reflect the number of awards that are expected to vest and should be adjusted to reflect those awards that ultimately vest. The updated guidance is effective for annual and interim periods beginning after December 15, 2015, with early adoption permitted. The adoption of this guidance is not expected to have a material impact on our consolidated financial position or results of operations.

[0001564590-14-006033:mdna:113]
24
