# POWL notes — 0001564590-14-006033


## us-gaap:SignificantAccountingPoliciesTextBlock

[0001564590-14-006033:notes:1]
B. Summary of Significant Accounting Policies

[0001564590-14-006033:notes:2]
Principles of Consolidation

[0001564590-14-006033:notes:3]
The consolidated financial statements include the accounts of Powell and our wholly owned subsidiaries. All intercompany accounts and transactions have been eliminated in consolidation.

[0001564590-14-006033:notes:4]
Reclassifications

[0001564590-14-006033:notes:5]
Reclassifications have been made in prior years’ Consolidated Statements of Cash Flows and Consolidated Statements of Stockholders’ Equity to conform and expand the presentation of shares withheld in lieu of employee tax withholding in the current year. These reclassifications have not resulted in any changes to previously reported cash flows or equity for any periods.

[0001564590-14-006033:notes:6]
Use of Estimates

[0001564590-14-006033:notes:7]
The preparation of financial statements in conformity with accounting principles generally accepted in the United States (U.S. GAAP) requires management to make estimates and assumptions that affect the amounts reported in the consolidated financial statements and accompanying footnotes. The most significant estimates used in our financial statements affect revenue and cost recognition for construction contracts, the allowance for doubtful accounts, provision for excess and obsolete inventory, goodwill and other intangible assets, self-insurance, warranty accruals and income taxes. The amounts recorded for insurance claims, warranties, legal, income taxes and other contingent liabilities require judgments regarding the amount of expenses that will ultimately be incurred. We base our estimates on historical experience and on various other assumptions, as well as the specific circumstances surrounding these contingent liabilities, in evaluating the amount of liability that should be recorded. Additionally, the recognition of deferred tax assets requires estimates related to future income and other assumptions regarding timing and future profitability.  Estimates may change as new events occur, additional information becomes available or operating environments change. Actual results may differ from our estimates.

[0001564590-14-006033:notes:8]
Cash and Cash Equivalents

[0001564590-14-006033:notes:9]
Cash and cash equivalents include cash on hand, deposits with banks and highly liquid investments with original maturities of three months or less.

[0001564590-14-006033:notes:10]
Supplemental Disclosures of Cash Flow Information (in thousands):

[0001564590-14-006033:notes:11]
|  | Year Ended September 30, |
|  | 2014 |  |  | 2013 |  |  | 2012 |  |
| Cash paid during the period for: |  |  |  |  |  |  |  |  |  |  |  |
| Interest, net of interest income | $ | 149 |  |  | $ | 164 |  |  | $ | 141 |  |
| Income taxes, net of refunds |  | 18,889 |  |  |  | 14,783 |  |  |  | 12,104 |  |
| Non-cash capital expenditures |  | 13,527 |  |  |  | 2,807 |  |  |  | — |  |

[0001564590-14-006033:notes:12]
Fair Value of Financial Instruments

[0001564590-14-006033:notes:13]
Financial instruments include cash, cash equivalents, receivables, deferred compensation, payables and debt obligations. Except as described below, due to the short-term nature of account receivables and account payables, the book value is representative of their fair value. The carrying value of debt approximates fair value as interest rates are indexed to the Federal Funds Rate, the Canadian Prime Rate or the bank’s prime rate.

[0001564590-14-006033:notes:14]
Accounts Receivable

[0001564590-14-006033:notes:15]
Accounts receivable are stated net of allowances for doubtful accounts. We maintain and continually assess the adequacy of the allowance for doubtful accounts representing our estimate for losses resulting from the inability of our customers to pay amounts due to us. This estimated allowance is based on historical experience of uncollected accounts, the level of past due accounts, the overall level of outstanding accounts receivable, information about specific customers with respect to their inability to make payments and expectations of future conditions that could impact the collectability of accounts receivable. Future changes in our customers’ operating performance and cash flows, or in general economic conditions, could have an impact on their ability to fully pay these amounts, which could have a material impact on our operating results. In most cases, receivables are not collateralized. However, we utilize letters of credit to secure payment on sales when possible. At September 30, 2014 and 2013, accounts receivable included retention amounts of $6.7 million and $9.7 million, respectively. Retention amounts are in accordance with applicable provisions of contracts and become due upon completion of contractual requirements. Approximately $0.4 million of the retained amount at September 30, 2014, is expected to be collected subsequent to September 30, 2015.

[0001564590-14-006033:notes:16]
Costs and Estimated Earnings in Excess of Billings on Uncompleted Contracts

[0001564590-14-006033:notes:17]
Costs and estimated earnings in excess of billings on uncompleted contracts arise when revenues are recorded on a percentage-of-completion basis but cannot be invoiced under the terms of the contract. Such amounts are invoiced upon completion of contractual milestones.

[0001564590-14-006033:notes:18]
Costs and estimated earnings in excess of billings on uncompleted contracts also include certain costs associated with unapproved change orders. These costs are included when the approval of the change order is probable. Amounts are carried at the lower of cost or net realizable value. Revenue is recognized to the extent of costs incurred when recovery is probable. The amounts recorded involve the use of judgments and estimates; thus, actual recoverable amounts could differ from original assumptions.

[0001564590-14-006033:notes:19]
In accordance with industry practice, assets and liabilities related to costs and estimated earnings in excess of billings on uncompleted contracts, as well as billings in excess of costs and estimated earnings on uncompleted contracts, have been classified as current. The contract cycle for certain long-term contracts may extend beyond one year; thus, collection of amounts related to these contracts may extend beyond one year.

[0001564590-14-006033:notes:20]
Inventories

[0001564590-14-006033:notes:21]
Inventories are stated at the lower of cost or market using weighted-average methods and include the cost of materials, labor and manufacturing overhead. We use estimates in determining the level of reserves required to state inventory at the lower of cost or market. Our estimates are based on market activity levels, production requirements, the physical condition of products and technological innovation. Changes in any of these factors may result in adjustments to the carrying value of inventory.

[0001564590-14-006033:notes:22]
Property, Plant and Equipment

[0001564590-14-006033:notes:23]
Property, plant and equipment are stated at cost and are depreciated using the straight-line method over the estimated useful lives of the assets. Expenditures for repairs and maintenance are charged to expense when incurred. Expenditures for major renewals and improvements, which extend the useful lives of existing equipment, are capitalized and depreciated. Upon retirement or disposition of property, plant and equipment, the cost and related accumulated depreciation are removed from the accounts, and any resulting gain or loss is recognized in the Consolidated Statements of Operations.

[0001564590-14-006033:notes:24]
We review property, plant and equipment for impairment whenever events or changes in circumstances indicate that the carrying value may not be realizable. If an evaluation is required, the estimated future undiscounted cash flows associated with the asset are compared to the asset’s carrying amount to determine if an impairment of such asset is necessary. This requires us to make long-term forecasts of the future revenues and the costs related to the assets subject to review. Forecasts require assumptions about demand for our products and future market conditions. Estimating future cash flows requires significant judgment and our projections may vary from cash flows eventually realized. Future events and unanticipated changes to assumptions could require a provision for impairment in a future period. The effect of any impairment would be reflected in income (loss) from operations in the Consolidated Statements of Operations. In addition, we estimate the useful lives of our property, plant and equipment and periodically review these estimates to determine whether these lives are appropriate.

[0001564590-14-006033:notes:25]
Intangible Assets

[0001564590-14-006033:notes:26]
The costs of intangible assets with determinable useful lives are amortized over their estimated useful lives. When certain events or changes in operating conditions occur, the estimated future undiscounted cash flows associated with the asset are compared to the asset’s carrying amount to determine if an impairment of such assets is necessary. For intangible assets that are amortized, we review their estimated useful lives and evaluate whether events and circumstances warrant a revision to the remaining useful life. For additional information regarding our intangible assets and related impairment, see Note E herein.

[0001564590-14-006033:notes:27]
Goodwill

[0001564590-14-006033:notes:28]
Goodwill is evaluated for impairment annually, or immediately if conditions indicate that impairment could exist. The evaluation requires a two-step impairment test to identify potential goodwill impairment and measure the amount of a goodwill impairment loss. The first step of the test compares the fair value of a reporting unit with its carrying amount, including goodwill. If the carrying amount of a reporting unit exceeds its fair value, the second step of the goodwill impairment test is performed to measure the amount of the impairment loss. Both steps of the goodwill impairment testing involve significant estimates.

[0001564590-14-006033:notes:29]
Income Taxes

[0001564590-14-006033:notes:30]
We account for income taxes under the asset and liability method, based on the income tax laws and rates in the countries in which operations are conducted and income is earned. This approach requires the recognition of deferred tax assets and liabilities for the expected future tax consequences of temporary differences between the carrying amounts and the tax basis of assets and liabilities. Developing our provision for income taxes requires significant judgment and expertise in federal, international and state income tax laws, regulations and strategies, including the determination of deferred tax assets and liabilities and, if necessary, any valuation allowances that may be required for deferred tax assets. We record a valuation allowance to reduce our deferred tax assets to the amount that is more likely than not to be realized. Although our Canadian operations reported a loss for Fiscal 2014, we believe that the deferred tax asset recorded as of September 30, 2014, is realizable through future reversals of existing taxable temporary differences and future taxable income. The recognition of deferred tax assets requires estimates related to future income and other assumptions regarding timing and future profitability.  Estimates may change as new events occur, additional information becomes available or operating environments change.  We will continue to assess the adequacy of the valuation allowance on a quarterly basis. Our judgments and tax strategies are subject to audit by various taxing authorities.

[0001564590-14-006033:notes:31]
The objectives of accounting for income taxes are to recognize the amount of taxes payable or refundable for the current year and deferred tax liabilities and assets for the future tax consequences of events that have been recognized in an entity’s financial statements or tax returns. We recognize the tax benefit from an uncertain tax position only if it is more likely than not that the tax position will be sustained on examination by the taxing authorities, based on the technical merits of the position. The tax benefits recognized in the financial statements from such a position should be measured based on the largest benefit that has a greater than 50% likelihood of being realized upon ultimate settlement. Accounting literature also provides guidance on derecognition of income tax assets and liabilities, classification of current and deferred income tax assets and liabilities, accounting for interest and penalties associated with tax positions, and income tax disclosures. Judgment is required in assessing the future tax consequences of events that have been recognized in our financial statements or tax returns. Variations in the actual outcome of these future tax consequences could materially impact our financial statements.

[0001564590-14-006033:notes:32]
Revenue Recognition

[0001564590-14-006033:notes:33]
Our revenues are primarily generated from engineering and manufacturing of custom products under long-term contracts that may last from one month to several years, depending on the contract. Revenues from long-term contracts are recognized on the percentage-of-completion method of accounting. Occasionally a contract may require that we segment the project into specific deliverables for revenue recognition. Segmenting a contract may result in different interim rates of profitability for each scope of service than if we had recognized revenue on a combined basis.

[0001564590-14-006033:notes:34]
Under the percentage-of-completion method of accounting, revenues are recognized as work is performed. The estimated completion to date is calculated by multiplying the total contract price by the percentage of performance to date, which is based on total costs or total labor dollars incurred to date compared to the total estimated costs or total labor dollars estimated at completion. The method used to determine the percentage of completion is typically the cost method, unless the labor method is a more accurate method of measuring the progress of the project. Application of the percentage-of-completion method of accounting requires the use of estimates of costs to be incurred for the performance of the contract. Contract costs include all direct material costs, direct labor costs and those indirect costs related to contract performance, such as indirect labor, supplies, tools, repairs and all costs associated with operation of equipment. The cost estimation process is based upon the professional knowledge and experience of our engineers, project managers and financial professionals. Factors that are considered in estimating the work to be completed and ultimate contract recovery include the availability and productivity of labor, the nature and complexity of the work to be performed, the effect of change orders, the availability of materials, the effect of any delays on our project performance and the recoverability of any claims. Changes in job performance, job conditions, estimated profitability and final contract settlements, including our estimate of liquidated damages, if any, may result in revisions to costs and income, with their effects being recognized in the period in which the revisions are determined. Whenever revisions of estimated contract costs and contract values indicate that the contract costs will exceed estimated revenues, thus creating a loss, a provision for the total estimated loss is recorded in that period.

[0001564590-14-006033:notes:35]
Revenues associated with maintenance, repair and service contracts are recognized when the services are performed. Expenses related to these types of services are recognized as incurred.

[0001564590-14-006033:notes:36]
Warranties

[0001564590-14-006033:notes:37]
We provide for estimated warranty costs with the recognition of revenue based upon historical rates applicable to individual product lines. In addition, specific provisions are made when the costs of such warranties are expected to exceed accruals. Our standard terms and conditions of sale include a warranty for parts and service for the earlier of 18 months from the date of shipment or 12 months from the date of energization, whichever occurs first.  Occasionally projects require warranty terms that are longer than our standard terms due to the nature of the project. Extended warranty terms may be negotiated and included in our contracts.  We use past experience and historical claims to determine the estimated liability. Actual results could differ from our estimate.

[0001564590-14-006033:notes:38]
Research and Development Expense

[0001564590-14-006033:notes:39]
Research and development activities are directed toward the development of new products and processes as well as improvements in existing products and processes. These costs, which primarily include salaries, contract services and supplies, are expensed as incurred.  Such amounts were $7.6 million, $7.6 million and $6.3 million in Fiscal 2014, 2013 and 2012, respectively.

[0001564590-14-006033:notes:40]
Foreign Currency Translation

[0001564590-14-006033:notes:41]
The functional currency for our foreign subsidiaries is the local currency in which the entity is located. The financial statements of all subsidiaries with a functional currency other than the U.S. Dollar have been translated into U.S. Dollars. All assets and liabilities of foreign operations are translated into U.S. Dollars using year-end exchange rates, and all revenues and expenses are translated at average rates during the respective period. The U.S. Dollar results that arise from such translation, as well as exchange gains and losses on intercompany balances of a long-term investment nature, are included in the cumulative currency translation adjustments in accumulated other comprehensive income in stockholders’ equity.

[0001564590-14-006033:notes:42]
Stock-Based Compensation

[0001564590-14-006033:notes:43]
We measure stock-based compensation cost at the grant date based on the fair value of the award. Compensation expense is recognized over the period during which the employee is required to provide service in exchange for the awards, typically the vesting period. Excess income tax benefits related to share-based compensation expense that must be recognized directly in equity are considered financing rather than operating cash flow activities.

[0001564590-14-006033:notes:44]
New Accounting Standards

[0001564590-14-006033:notes:45]
From time to time, new accounting pronouncements are issued by the Financial Accounting Standards Board (the FASB), which are adopted by us as of the specified effective date. Unless otherwise discussed, management believes that the impact of recently issued standards, which are not yet effective, will not have a material impact on our consolidated statements upon adoption.

[0001564590-14-006033:notes:46]
In March 2013, the FASB issued accounting guidance to resolve the diversity in practice for accounting for the release of the cumulative translation adjustment into net income when a parent either sells a part or all of its investment in a foreign entity or no longer holds a controlling financial interest in a subsidiary or group of assets that is a nonprofit activity or a business (other than a sale of real estate or conveyance of oil and gas mineral rights) within a foreign entity. This guidance is effective prospectively for fiscal years (and interim reporting periods within those years) beginning after December 15, 2013, which would be our fiscal year ending September 30, 2015. We do not expect this guidance to have a material impact on our consolidated financial position or results of operations.

[0001564590-14-006033:notes:47]
In July 2013, the FASB issued accounting guidance on the presentation of an unrecognized tax benefit when a net operating loss carryforward, a similar tax loss, or a tax credit carryforward exists. The guidance states that an unrecognized tax benefit, or a portion of an unrecognized tax benefit, should be presented in the financial statements as a reduction to a deferred tax asset for a net operating loss carryforward, a similar tax loss, or a tax credit carryforward. To the extent a net operating loss carryforward, a similar tax loss, or a tax credit carryforward is not available at the reporting date under the tax law of the applicable jurisdiction to settle any additional income taxes that would result from the disallowance of a tax position or the tax law of the applicable jurisdiction does not require the entity to use, and the entity does not intend to use, the deferred tax asset for such purpose, the unrecognized tax benefit should be presented in the financial statements as a liability and should not be combined with deferred tax assets. This guidance is effective for fiscal years, and interim periods within those years, beginning after December 15, 2013, which would be our fiscal year ended September 30, 2015. This guidance should be applied prospectively to all unrecognized tax benefits that exist at the effective date. Retrospective application is permitted. The adoption of this guidance is not expected to have a significant impact on our consolidated financial position or results of operations.

[0001564590-14-006033:notes:48]
In April 2014, the FASB issued an amendment to the financial reporting of discontinued operations.  The amendments in this update changed the criteria for reporting discontinued operations while enhancing disclosures in this area. It also addresses sources of confusion and inconsistent application related to the financial reporting of discontinued operations guidance in U.S. GAAP.  Under the new guidance, only disposals representing a strategic shift in operations that have a major effect on the organization’s operations and financial results should be presented as discontinued operations. Examples include a disposal of a major geographic area, a major line of business, or a major equity method investment.  In addition, the new guidance requires expanded disclosures about discontinued operations that will provide financial statement users with more information about the assets, liabilities, income, and expenses of discontinued operations.  The new guidance also requires disclosure of the pre-tax income attributable to a disposal of a significant part of an organization that does not qualify for discontinued operations reporting. This disclosure will provide users with information about the ongoing trends in a reporting organization’s results from continuing operations. The amendments in this update are effective in the first quarter of 2015, which would be our fiscal year end September 30, 2016.  Early adoption is permitted for disposals that have not been previously reported as discontinued operations.

[0001564590-14-006033:notes:49]
In May 2014, the FASB issued a new standard on revenue recognition that supersedes previously issued revenue recognition guidance.  This standard provides a five-step approach to be applied to all contracts with customers and requires expanded disclosures about the nature, amount, timing and uncertainty of revenue (and the related cash flows) arising from customer contracts, significant judgments and changes in judgments used in applying the revenue model and the assets recognized from costs incurred to obtain or fulfill a contract.  This new standard is effective for us beginning in fiscal year 2018.  Early application is not permitted. The standard permits the use of either the retrospective or cumulative effect transition method therefore we are evaluating the effect that this new guidance will have on our consolidated financial statements and related disclosures. We have not yet selected a transition method nor have we determined the effect of the standard on our ongoing financial reporting.

[0001564590-14-006033:notes:50]
In June 2014, the FASB issued an amendment to the topic regarding share-based payments and instances where terms of an award provide that a performance target can be achieved after the requisite service period.  This guidance has been provided to resolve the diversity in practice concerning employee share-based payments that contain performance targets that could be achieved after the requisite service period. The updated guidance requires that a performance target that affects vesting and that can be achieved after the requisite service period be treated as a performance condition. Compensation cost should be recognized in the period in which it becomes probable that the performance target will be achieved and is attributable to the periods for which service has been rendered. If the performance target becomes probable of being achieved before the end of the service period, the remaining unrecognized compensation cost for which requisite service has not yet been rendered is recognized prospectively over the remaining service period. The total amount of compensation cost recognized during and after the service period should reflect the number of awards that are expected to vest and should be adjusted to reflect those awards that ultimately vest. The updated guidance is effective for annual and interim periods beginning after December 15, 2015, with early adoption permitted. The adoption of this guidance is not expected to have a material impact on our consolidated financial position or results of operations.


## us-gaap:EarningsPerShareTextBlock

[0001564590-14-006033:notes:51]
C. Earnings Per Share

[0001564590-14-006033:notes:52]
We compute basic earnings per share by dividing net income by the weighted average number of common shares outstanding during the period. Diluted earnings per common and potential common share includes the weighted average of additional shares associated with the incremental effect of dilutive restricted stock and restrictive stock units, as prescribed by the FASB guidance on earnings per share.

[0001564590-14-006033:notes:53]
The following table reconciles basic and diluted weighted average shares used in the computation of earnings per share for the years ended September 30, 2014, 2013 and 2012 (in thousands, except per share data):

[0001564590-14-006033:notes:54]
|  | Year Ended September 30, |  |
|  | 2014 |  |  | 2013 |  |  | 2012 |  |
| Numerator: |  |  |  |  |  |  |  |  |  |  |  |
| Income from continuing operations | $ | 19,620 |  |  | $ | 39,739 |  |  | $ | 28,743 |  |
| Income from discontinued operations |  | 9,604 |  |  |  | 2,337 |  |  |  | 914 |  |
| Net income | $ | 29,224 |  |  | $ | 42,076 |  |  | $ | 29,657 |  |
| Denominator: |  |  |  |  |  |  |  |  |  |  |  |
| Weighted average basic shares |  | 12,003 |  |  |  | 11,948 |  |  |  | 11,850 |  |
| Dilutive effect of restricted stock units |  | 55 |  |  |  | 46 |  |  |  | 75 |  |
| Weighted average diluted shares with assumed conversions |  | 12,058 |  |  |  | 11,994 |  |  |  | 11,925 |  |
| Net earnings per share: |  |  |  |  |  |  |  |  |  |  |  |
| Continuing operations | $ | 1.63 |  |  | $ | 3.32 |  |  | $ | 2.43 |  |
| Discontinued operations |  | 0.80 |  |  |  | 0.20 |  |  |  | 0.07 |  |
| Basic earnings per share | $ | 2.43 |  |  | $ | 3.52 |  |  | $ | 2.50 |  |
| Continuing operations | $ | 1.62 |  |  | $ | 3.32 |  |  | $ | 2.41 |  |
| Discontinued operations |  | 0.80 |  |  |  | 0.19 |  |  |  | 0.08 |  |
| Diluted earnings per share | $ | 2.42 |  |  | $ | 3.51 |  |  | $ | 2.49 |  |


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0001564590-14-006033:notes:55]
D. Detail of Selected Balance Sheet Accounts

[0001564590-14-006033:notes:56]
Allowance for Doubtful Accounts

[0001564590-14-006033:notes:57]
Activity in our allowance for doubtful accounts consisted of the following (in thousands):

[0001564590-14-006033:notes:58]
|  | September 30, |  |
|  | 2014 |  |  | 2013 |  |
| Balance at beginning of period | $ | 572 |  |  | $ | 1,297 |  |
| Bad debt expense/(recovery) |  | 1,074 |  |  |  | (544 | ) |
| Uncollectible accounts written off, net of recoveries |  | (58 | ) |  |  | (171 | ) |
| Change in foreign currency translation |  | (11 | ) |  |  | (10 | ) |
| Balance at end of period | $ | 1,577 |  |  | $ | 572 |  |

[0001564590-14-006033:notes:59]
The components of inventories are summarized below (in thousands):

[0001564590-14-006033:notes:60]
|  | September 30, |  |
|  | 2014 |  |  | 2013 |  |
| Raw materials, parts and subassemblies | $ | 35,349 |  |  | $ | 30,077 |  |
| Work-in-progress |  | 2,035 |  |  |  | 3,818 |  |
| Provision for excess and obsolete inventory |  | (4,569 | ) |  |  | (4,932 | ) |
| Total inventories | $ | 32,815 |  |  | $ | 28,963 |  |

[0001564590-14-006033:notes:61]
Cost and Estimated Earnings on Uncompleted Contracts

[0001564590-14-006033:notes:62]
The components of costs and estimated earnings and related amounts billed on uncompleted contracts are summarized below (in thousands):

[0001564590-14-006033:notes:63]
|  | September 30, |  |
|  | 2014 |  |  | 2013 |  |
| Costs incurred on uncompleted contracts | $ | 604,939 |  |  | $ | 618,570 |  |
| Estimated earnings |  | 157,562 |  |  |  | 159,962 |  |
|  |  | 762,501 |  |  |  | 778,532 |  |
| Less: Billings to date |  | (715,233 | ) |  |  | (747,446 | ) |
| Net underbilled position | $ | 47,268 |  |  | $ | 31,086 |  |
| Included in the accompanying balance sheets under the following captions: |  |  |  |  |  |  |  |
| Costs and estimated earnings in excess of billings on uncompleted contracts – underbilled | $ | 95,970 |  |  | $ | 79,420 |  |
| Billings in excess of costs and estimated earnings on uncompleted contracts – overbilled |  | (48,702 | ) |  |  | (48,334 | ) |
| Net underbilled position | $ | 47,268 |  |  | $ | 31,086 |  |

[0001564590-14-006033:notes:64]
Property, plant and equipment are summarized below (in thousands):

[0001564590-14-006033:notes:65]
|  | September 30, |  |  | Range of |
|  | 2014 |  |  | 2013 |  |  | Asset Lives |
| Land | $ | 23,545 |  |  | $ | 24,022 |  |  | — |
| Buildings and improvements |  | 100,901 |  |  |  | 79,621 |  |  | 3 - 39 Years |
| Machinery and equipment |  | 100,922 |  |  |  | 71,808 |  |  | 3 - 15 Years |
| Furniture and fixtures |  | 3,852 |  |  |  | 2,736 |  |  | 3 - 10 Years |
| Construction in process |  | 15,878 |  |  |  | 48,301 |  |  | — |
|  | $ | 245,098 |  |  | $ | 226,488 |  |  |  |
| Less: Accumulated depreciation |  | (88,202 | ) |  |  | (81,993 | ) |  |  |
| Total property, plant and equipment, net | $ | 156,896 |  |  | $ | 144,495 |  |  |  |

[0001564590-14-006033:notes:66]
The increase in buildings and improvements and machinery and equipment was primarily the result of construction of the new facilities in Houston, Texas, and Acheson, Alberta, Canada.

[0001564590-14-006033:notes:67]
There were no assets under capital lease as of September 30, 2014; however, at September 30, 2013, we had assets under capital lease of $0.5 million, with related accumulated depreciation of $0.5 million which was included in property and equipment.  Depreciation expense from continuing operations, including the depreciation of capital leases, was $11.4 million, $8.5 million and $10.5 million for fiscal years 2014, 2013 and 2012, respectively.

[0001564590-14-006033:notes:68]
Warranty Accrual

[0001564590-14-006033:notes:69]
Activity in our product warranty accrual consisted of the following (in thousands):

[0001564590-14-006033:notes:70]
|  | September 30, |  |
|  | 2014 |  |  | 2013 |  |
| Balance at beginning of period | $ | 5,282 |  |  | $ | 5,548 |  |
| Increase to warranty expense |  | 3,237 |  |  |  | 4,020 |  |
| Deduction for warranty charges |  | (3,892 | ) |  |  | (4,321 | ) |
| Increase (decrease) due to foreign currency translations |  | (70 | ) |  |  | 35 |  |
| Balance at end of period | $ | 4,557 |  |  | $ | 5,282 |  |


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0001564590-14-006033:notes:71]
E. Intangible Assets

[0001564590-14-006033:notes:72]
Our intangible assets consist of goodwill, which is not being amortized, purchased technology (6- to 7-year useful lives) and trade names (10-year useful life), which are amortized over their estimated useful lives. We test for impairment of goodwill and intangible assets annually, or immediately if conditions indicate that impairment could exist. No impairment was identified as a result of performing our annual impairment test of goodwill for Fiscal 2014 or 2013.

[0001564590-14-006033:notes:73]
Intangible assets balances, subject to amortization, at September 30, 2014 and 2013, consisted of the following (in thousands):

[0001564590-14-006033:notes:74]
|  | September 30, 2014 |  |  | September 30, 2013 |  |
|  | Gross |  |  |  |  |  |  | Net |  |  | Gross |  |  |  |  |  |  | Net |  |
|  | Carrying |  |  | Accumulated |  |  | Carrying |  |  | Carrying |  |  | Accumulated |  |  | Carrying |  |
|  | Value |  |  | Amortization |  |  | Value |  |  | Value |  |  | Amortization |  |  | Value |  |
| Purchased technology | $ | 11,749 |  |  | $ | (9,918 | ) |  | $ | 1,831 |  |  | $ | 11,749 |  |  | $ | (9,489 | ) |  | $ | 2,260 |  |
| Trade name |  | 1,136 |  |  |  | (1,063 | ) |  |  | 73 |  |  |  | 1,136 |  |  |  | (967 | ) |  |  | 169 |  |
| Supply agreement |  | — |  |  |  | — |  |  |  | — |  |  |  | 17,580 |  |  |  | (8,397 | ) |  |  | 9,183 |  |
| Total | $ | 12,885 |  |  | $ | (10,981 | ) |  | $ | 1,904 |  |  | $ | 30,465 |  |  | $ | (18,853 | ) |  | $ | 11,612 |  |

[0001564590-14-006033:notes:75]
Amortization of intangible assets recorded for the years ended September 30, 2014, 2013 and 2012, was $0.8 million, $1.7 million and $2.6 million, respectively.

[0001564590-14-006033:notes:76]
Estimated amortization expense for each of the five subsequent fiscal years is expected to be (in thousands):

[0001564590-14-006033:notes:77]
| Years Ending September 30, |  | Total |  |
| 2015 |  | $ | 449 |  |
| 2016 |  |  | 376 |  |
| 2017 |  |  | 376 |  |
| 2018 |  |  | 376 |  |
| 2019 |  |  | 327 |  |

[0001564590-14-006033:notes:78]
On August 7, 2006, we purchased certain assets related to the manufacturing of ANSI medium-voltage switchgear and circuit breaker business from General Electric Company (GE).  In connection with the acquisition, we entered into a 15-year supply agreement with GE pursuant to which GE would purchase from the Company all of its requirements for ANSI medium-voltage switchgear and circuit breakers and other related equipment and components (the Products).  In connection with the acquisition, we recorded an intangible asset related to this supply agreement.  On December 30, 2013, the Company and GE amended the supply agreement to allow GE to manufacture similar Products for sale immediately and allow GE to begin purchasing Products from other suppliers beginning December 31, 2014.  In return, GE paid us $10 million upon execution of the amended supply agreement and agreed to pay an additional $7 million over three years, subject to certain conditions.  We have $2.3 million recorded in other current assets and the remaining $4.7 million is recorded as a long-term receivable. We wrote off the intangible asset related to the original supply agreement and recorded a deferred credit in the amount of $8.1 million, the amount by which the total proceeds from GE exceeded the unamortized balance of our intangible asset. We are amortizing this deferred credit over the four-year life of the agreement and have recognized the $1.5 million gain in other income in Fiscal 2014.


## us-gaap:LongTermDebtTextBlock

[0001564590-14-006033:notes:79]
F. Long-Term Debt

[0001564590-14-006033:notes:80]
Long-term debt consisted of the following (in thousands):

[0001564590-14-006033:notes:81]
|  | September 30, |  |
|  | 2014 |  |  | 2013 |  |
| Industrial development revenue bonds | $ | 3,200 |  |  | $ | 3,600 |  |
| Capital lease obligations |  | — |  |  |  | 16 |  |
| Subtotal long-term debt and capital lease obligations |  | 3,200 |  |  |  | 3,616 |  |
| Less: current portion |  | (400 | ) |  |  | (416 | ) |
| Total long-term debt and capital lease obligations | $ | 2,800 |  |  | $ | 3,200 |  |

[0001564590-14-006033:notes:82]
The annual maturities of long-term debt as of September 30, 2014, were as follows (in thousands):

[0001564590-14-006033:notes:83]
| Year Ending September 30, |  | Long‑TermDebtMaturities |  |
| 2015 |  | $ | 400 |  |
| 2016 |  |  | 400 |  |
| 2017 |  |  | 400 |  |
| 2018 |  |  | 400 |  |
| 2019 |  |  | 400 |  |
| Thereafter |  |  | 1,200 |  |
| Total long-term debt maturities |  | $ | 3,200 |  |

[0001564590-14-006033:notes:84]
U.S. Revolver

[0001564590-14-006033:notes:85]
In Fiscal 2014, we amended and restated our existing credit agreement (Amended Credit Agreement) with a major domestic bank. We entered into this Amended Credit Agreement to, among other things, allow for the payment of dividends and to extend the expiration date of the facility. The Amended Credit Agreement provides for a $75.0 million revolving credit facility (U.S. Revolver). Obligations are collateralized by the stock of certain of our subsidiaries.

[0001564590-14-006033:notes:86]
The interest rate for amounts outstanding under the Amended Credit Agreement for the U.S. Revolver is a floating rate based upon the higher of the Federal Funds Rate plus 0.5%, the bank’s prime rate, or the Eurocurrency rate plus 1.00%. Once the applicable rate is determined, a margin ranging up to 1.75%, as determined by our consolidated leverage ratio, is added to the applicable rate.

[0001564590-14-006033:notes:87]
The U.S. Revolver provides for the issuance of letters of credit which reduce the amounts that may be borrowed under this revolver. The amount available under the U.S. Revolver was reduced by $21.5 million for our outstanding letters of credit at September 30, 2014.

[0001564590-14-006033:notes:88]
There were no borrowings outstanding under the U.S. Revolver as of September 30, 2014. Amounts available under the U.S. Revolver were $53.5 million at September 30, 2014. The U.S. Revolver expires on December 31, 2018.

[0001564590-14-006033:notes:89]
The Amended Credit Agreement contains certain restrictive and maintenance-type covenants, such as restrictions on the amount of capital expenditures allowed. It also contains financial covenants defining various financial measures and the levels of these measures with which we must comply, as well as a “material adverse change” clause. A “material adverse change” is defined as a material change in our operations, business, properties, liabilities or condition (financial or otherwise) or a material impairment of our ability to perform our obligations under our credit agreements.

[0001564590-14-006033:notes:90]
The Amended Credit Agreement is collateralized by a pledge of 100% of the voting capital stock of each of our domestic subsidiaries and 66% of the voting capital stock of each non-domestic subsidiary, excluding Powell Canada. The Amended Credit Agreement provides for customary events of default and carries cross-default provisions with other existing debt agreements. If an event of default (as defined in the Amended Credit Agreement) occurs and is continuing, on the terms and subject to the conditions set forth in the Amended Credit Agreement, amounts outstanding under the Amended Credit Agreement may be accelerated and may become immediately due and payable. As of September 30, 2014, we were in compliance with all of the financial covenants of the Amended Credit Agreement.

[0001564590-14-006033:notes:91]
Canadian Revolver

[0001564590-14-006033:notes:92]
We have a $9.0 million credit agreement with a major international bank in Canada (the Canadian Revolver) to provide working capital support and letters of credit for our operations in Canada. The Canadian Revolver provides for the issuance of letters of credit which reduce the amounts that may be borrowed under this revolver. There were no outstanding letters of credit at September 30, 2014.

[0001564590-14-006033:notes:93]
There were no borrowings outstanding under the Canadian Revolver as of September 30, 2014 and amounts available under the Canadian Revolver were $9.0 million at September 30, 2014. The Canadian Revolver expires on February 28, 2015. The interest rate for amounts outstanding under the Canadian Revolver is a floating interest rate based upon either the Canadian Prime Rate, or the lender’s Bankers’ Acceptance Rate. Once the applicable rate is determined, a margin of 0.50% to 1.75%, as determined by our consolidated leverage ratio, is added to the applicable rate.

[0001564590-14-006033:notes:94]
The principal financial covenants are consistent with those described in our Amended Credit Agreement. The Canadian Revolver contains a “material adverse effect” clause. A “material adverse effect” is defined as a material change in the operations of Powell or Powell Canada in relation to our financial condition, property, business operations, expected net cash flows, liabilities or capitalization.

[0001564590-14-006033:notes:95]
The Canadian Revolver is secured by the assets of our Canadian operations and provides for customary events of default and carries cross-default provisions with our existing debt agreements. If an event of default (as defined in the Canadian Revolver) occurs and is continuing, per the terms and subject to the conditions set forth in the Canadian Revolver, amounts outstanding under the Canadian Revolver may be accelerated and may become immediately due and payable. As of September 30, 2014, we were in compliance with all of the financial covenants of the Canadian Revolver.

[0001564590-14-006033:notes:96]
Industrial Development Revenue Bonds

[0001564590-14-006033:notes:97]
We borrowed $8.0 million in October 2001 through a loan agreement funded with proceeds from tax-exempt industrial development revenue bonds (Bonds). These Bonds were issued by the Illinois Development Finance Authority and were used for the completion of our Northlake, Illinois facility. Pursuant to the Bond issuance, a reimbursement agreement between us and a major domestic bank required an issuance by the bank of an irrevocable direct-pay letter of credit (Bond LC), as collateral, to the Bonds’ trustee to guarantee payment of the Bonds’ principal and interest when due. The Bond LC is subject to both early termination and extension provisions customary to such agreements, as well as various covenants, for which we were in compliance at June 30, 2014. While the Bonds mature in 2021, the reimbursement agreement requires annual redemptions of $0.4 million that commenced on October 25, 2002. A sinking fund is used for the redemption of the Bonds. At September 30, 2014, the balance in the restricted sinking fund was approximately $0.4 million and was recorded in cash and cash equivalents. The Bonds bear interest at a floating rate determined weekly by the Bonds’ remarketing agent, which was the underwriter for the Bonds and is an affiliate of the bank. This interest rate was 0.20% as of September 30, 2014.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001564590-14-006033:notes:98]
G. Commitments and Contingencies

[0001564590-14-006033:notes:99]
Long-Term Debt

[0001564590-14-006033:notes:100]
See Note F herein for a discussion of our long-term debt.

[0001564590-14-006033:notes:101]
Leases

[0001564590-14-006033:notes:102]
We lease certain offices, facilities and equipment under operating leases expiring at various dates through 2023.

[0001564590-14-006033:notes:103]
At September 30, 2014, the minimum annual rental commitments under leases having terms in excess of one year were as follows (in thousands):

[0001564590-14-006033:notes:104]
| Years Ending September 30, |  | OperatingLeases |  |
| 2015 | $ | 4,155 |  |
| 2016 |  | 3,183 |  |
| 2017 |  | 2,307 |  |
| 2018 |  | 1,600 |  |
| 2019 |  | 1,436 |  |
| Thereafter |  | 5,586 |  |
| Total lease commitments | $ | 18,267 |  |

[0001564590-14-006033:notes:105]
Lease expense for all operating leases was $3.9 million, $4.7 million and $4.3 million for Fiscal 2014, 2013 and 2012, respectively. The lease on our previous Canadian facility does not expire until July 2023; however, we have sublet that facility through July 2019. We recorded a $1.7 million loss in the fourth quarter of fiscal year 2013 for the net difference between our annual lease costs and the expected receipts from the anticipated sublease, as well as the write-off of leasehold improvements.

[0001564590-14-006033:notes:106]
Letters of Credit and Bonds

[0001564590-14-006033:notes:107]
Certain customers require us to post bank letter of credit guarantees or performance bonds issued by a surety. These guarantees and performance bonds assure that we will perform under the terms of our contract. In the event of default, the counterparty may demand payment from the bank under a letter of credit or performance by the surety under a performance bond. To date, there have been no significant expenses related to either letters of credit or performance bonds for the periods reported. We were contingently liable for secured and unsecured letters of credit of $21.5 million as of September 30, 2014. We also had performance and maintenance bonds totaling $298.7 million that were outstanding, with additional bonding capacity of $301.3 million available, at September 30, 2014.

[0001564590-14-006033:notes:108]
In October 2014 we extended our $16.2 million facility agreement (Facility Agreement) between Powell (UK) Limited and a large international bank. This Facility Agreement provides Powell (UK) the ability to enter into bank guarantees as well as forward exchange contracts and currency options. At September 30, 2014, we had outstanding guarantees totaling $2.6 million under this Facility Agreement.  Amounts available under this Facility Agreement were $13.6 million as of September 30, 2014.

[0001564590-14-006033:notes:109]
The Facility Agreement provides for financial covenants and customary events of default, and carries cross-default provisions with our Amended Credit Facility. If an event of default (as defined in the Facility Agreement) occurs and is continuing, per the terms and subject to the conditions set forth in the Facility Agreement, obligations outstanding under the Facility Agreement may be accelerated and may become or be declared immediately due and payable. As of September 30, 2014, we were in compliance with all of the financial covenants of the Facility Agreement.

[0001564590-14-006033:notes:110]
Litigation

[0001564590-14-006033:notes:111]
We are involved in various legal proceedings, claims and other disputes arising in the ordinary course of business which, in general, are subject to uncertainties and in which the outcomes are not predictable. Although we can give no assurance about the outcome of pending or threatened litigation and the effect such outcomes may have on us, management believes that any ultimate liability resulting from the outcome of such proceedings, to the extent not otherwise provided or covered by insurance, will not have a material adverse effect on our consolidated financial position or results of operations or liquidity.

[0001564590-14-006033:notes:112]
In March 2013, we settled a lawsuit we had filed against the previous owners of Powell Canada in the amount of $1.7 million, which was received in April 2013 and is recorded as gain on settlement in the accompanying Consolidated Statement of Operations.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001564590-14-006033:notes:113]
H. Income Taxes

[0001564590-14-006033:notes:114]
The components of the income tax provision were as follows (in thousands):

[0001564590-14-006033:notes:115]
|  | Year Ended September 30, |  |
|  | 2014 |  |  | 2013 |  |  | 2012 |  |
| Current: |  |  |  |  |  |  |  |  |  |  |  |
| Federal | $ | 12,184 |  |  | $ | 10,919 |  |  | $ | 17,648 |  |
| State |  | 2,226 |  |  |  | 1,757 |  |  |  | 1,513 |  |
| Foreign |  | (130 | ) |  |  | 1,575 |  |  |  | 331 |  |
|  |  | 14,280 |  |  |  | 14,251 |  |  |  | 19,492 |  |
| Deferred: |  |  |  |  |  |  |  |  |  |  |  |
| Federal |  | (1,798 | ) |  |  | (580 | ) |  |  | (1,853 | ) |
| State |  | (311 | ) |  |  | (114 | ) |  |  | 24 |  |
| Foreign |  | (1,103 | ) |  |  | (6,170 | ) |  |  | 393 |  |
|  |  | (3,212 | ) |  |  | (6,864 | ) |  |  | (1,436 | ) |
| Total income tax provision | $ | 11,068 |  |  | $ | 7,387 |  |  | $ | 18,056 |  |

[0001564590-14-006033:notes:116]
Income before income taxes was as follows (in thousands):

[0001564590-14-006033:notes:117]
|  | Year Ended September 30, |  |
|  | 2014 |  |  | 2013 |  |  | 2012 |  |
| U.S. | $ | 35,131 |  |  | $ | 43,299 |  |  | $ | 52,450 |  |
| Other than U.S. |  | (4,443 | ) |  |  | 3,827 |  |  |  | (5,651 | ) |
| Income before income taxes | $ | 30,688 |  |  | $ | 47,126 |  |  | $ | 46,799 |  |

[0001564590-14-006033:notes:118]
A reconciliation of the statutory U.S. income tax rate and the effective income tax rate, as computed on earnings before income tax provision in each of the three years presented in the Consolidated Statements of Operations, was as follows:

[0001564590-14-006033:notes:119]
|  | Year Ended September 30, |  |
|  | 2014 |  |  | 2013 |  |  | 2012 |  |
| Statutory rate |  | 35 | % |  |  | 35 | % |  |  | 35 | % |
| State income taxes, net of federal benefit |  | 3 |  |  |  | 2 |  |  |  | 2 |  |
| International withholding tax |  | — |  |  |  | (1 | ) |  |  | (1 | ) |
| Other permanent tax items |  | 1 |  |  |  | 1 |  |  |  | — |  |
| Foreign rate differential |  | 1 |  |  |  | (1 | ) |  |  | 1 |  |
| Domestic production activities deduction |  | (3 | ) |  |  | (3 | ) |  |  | (3 | ) |
| Foreign valuation allowance and other |  | (1 | ) |  |  | (17 | ) |  |  | 4 |  |
| Effective rate |  | 36 | % |  |  | 16 | % |  |  | 38 | % |

[0001564590-14-006033:notes:120]
Our provision for income taxes reflects an effective tax rate on pre-tax earnings of 36% in Fiscal 2014 compared to 16% and 38% in Fiscal 2013 and 2012, respectively. The effective tax rates for Fiscal 2014 and 2012 are comparable while the effective tax rate in Fiscal 2013 was materially lower, resulting from the release of a valuation allowance that was recorded against Canadian deferred tax assets.

[0001564590-14-006033:notes:121]
We have not recorded deferred income taxes on $19 million of undistributed earnings of our foreign subsidiaries because of management’s intent to indefinitely reinvest such earnings. Upon distribution of these earnings in the form of dividends or otherwise, we may be subject to U.S. income taxes and foreign withholding taxes. It is not practical, however, to estimate the amount of taxes that may be payable on the eventual remittance of these earnings.

[0001564590-14-006033:notes:122]
We are subject to income tax in the U.S., multiple state jurisdictions and certain international jurisdictions, primarily the U.K. and Canada. We do not consider any state in which we do business to be a major tax jurisdiction. We remain open to examination in the other jurisdictions as follows:  Canada 2010 – 2013, United Kingdom 2013 and the United States 2009 – 2013.

[0001564590-14-006033:notes:123]
The net deferred income tax asset (liability) was comprised of the following (in thousands):

[0001564590-14-006033:notes:124]
|  | September 30, |  |
|  | 2014 |  |  | 2013 |  |
| Current deferred income taxes: |  |  |  |  |  |  |  |
| Gross assets | $ | 5,297 |  |  | $ | 5,335 |  |
| Gross liabilities |  | — |  |  |  | (845 | ) |
| Net current deferred income tax asset |  | 5,297 |  |  |  | 4,490 |  |
| Noncurrent deferred income taxes: |  |  |  |  |  |  |  |
| Gross assets |  | 11,532 |  |  |  | 9,016 |  |
| Gross liabilities |  | (110 | ) |  |  | — |  |
| Net noncurrent deferred income tax asset |  | 11,422 |  |  |  | 9,016 |  |
| Net deferred income tax asset | $ | 16,719 |  |  | $ | 13,506 |  |

[0001564590-14-006033:notes:125]
The tax effect of temporary differences between U.S. GAAP accounting and federal income tax accounting creating deferred income tax assets and liabilities was as follows (in thousands):

[0001564590-14-006033:notes:126]
|  | September 30, |  |
|  | 2014 |  |  | 2013 |  |
| Deferred Tax Assets: |  |  |  |  |  |  |  |
| Net operating loss | $ | 6,236 |  |  | $ | 3,892 |  |
| Uniform capitalization and inventory |  | 2,529 |  |  |  | 2,510 |  |
| Deferred compensation |  | 1,611 |  |  |  | 1,297 |  |
| Stock-based compensation |  | 1,529 |  |  |  | 1,291 |  |
| Reserve for accrued employee benefits |  | 1,444 |  |  |  | 1,396 |  |
| Depreciation and amortization |  | 1,217 |  |  |  | 944 |  |
| Warranty accrual |  | 643 |  |  |  | 1,042 |  |
| Goodwill |  | 474 |  |  |  | 1,198 |  |
| Postretirement benefits liability |  | 252 |  |  |  | 396 |  |
| Allowance for doubtful accounts |  | 495 |  |  |  | 163 |  |
| Workers’ compensation |  | 128 |  |  |  | 185 |  |
| Accrued legal |  | 65 |  |  |  | 57 |  |
| Credit carryforwards and other |  | 1,109 |  |  |  | 845 |  |
| Gross deferred tax asset |  | 17,732 |  |  |  | 15,216 |  |
| Less: valuation allowance |  | (903 | ) |  |  | (865 | ) |
| Deferred tax asset |  | 16,829 |  |  |  | 14,351 |  |
| Deferred Tax Liabilities: |  |  |  |  |  |  |  |
| Uncompleted contracts |  | — |  |  |  | (845 | ) |
| Other |  | (110 | ) |  |  | — |  |
| Deferred tax liabilities |  | (110 | ) |  |  | (845 | ) |
| Net deferred tax asset | $ | 16,719 |  |  | $ | 13,506 |  |

[0001564590-14-006033:notes:127]
At September 30, 2014, we had $24 million of gross foreign operating loss carryforwards which are subject to a 20-year carryforward period, the first of which will expire in 2031. At September 30, 2013, we released a valuation allowance that was recorded against Canadian deferred tax assets, resulting in a $7 million tax benefit.  Although our Canadian operations reported a loss for Fiscal 2014, we believe these deferred tax assets are more likely than not to be utilized by future taxable income. With the exception of the deferred tax assets related to certain foreign withholding taxes as well as the net operating losses of our Dutch entities, we believe that our other deferred tax assets are more likely than not realizable through future reversals of existing taxable temporary differences and our estimate of future taxable income. The recognition of deferred tax assets requires estimates related to future income and other assumptions regarding timing and future profitability. Estimates may change as new events occur, additional information becomes available or operating environments change.

[0001564590-14-006033:notes:128]
A reconciliation of the beginning and ending amount of the unrecognized tax liabilities follows (in thousands):

[0001564590-14-006033:notes:129]
| Balance as of September 30, 2013 | $ | 3,845 |  |
| Increases related to tax positions taken during the current period |  | 225 |  |
| Increases related to tax positions taken during a prior period |  | 14 |  |
| Decreases related to expirations of statute of limitations |  | (58 | ) |
| Balance as of September 30, 2014 | $ | 4,026 |  |

[0001564590-14-006033:notes:130]
Our continuing policy is to recognize interest and penalties related to income tax matters as tax expense. The amount of interest and penalty expense recorded for the year ended September 30, 2014 was not material.

[0001564590-14-006033:notes:131]
During Fiscal 2013, prior year U.S. federal income tax returns were amended to reflect increased research and development credits, and unrecognized tax benefits related to these refund claims were recorded. Fiscal 2012 and 2011 tax returns, along with the refund claims, are currently under review by the Internal Revenue Service Joint Committee on Taxation (JCT).  It is reasonably possible that the amount of unrecognized tax benefits related to our research and development credits will change during the next twelve months. In addition, management believes that it is reasonably possible that within the next 12 months other unrecognized tax benefits will decrease by approximately 1% due to the expiration of certain federal statutes of limitations.

[0001564590-14-006033:notes:132]
Management believes that an adequate provision has been made for any adjustments that may result from tax examinations. However, the outcome of tax audits cannot be predicted with certainty. If any issues addressed in our tax audits are resolved in a manner not consistent with management’s expectations, we could be required to adjust our provision for income tax in the period such resolution occurs. Although timing of the resolution and/or closure of audits is highly uncertain, with the exception of the JCT review, we do not believe it is reasonably possible that our unrecognized tax benefits could materially change in the next 12 months.


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0001564590-14-006033:notes:133]
I. Employee Benefit Plans

[0001564590-14-006033:notes:134]
Retirement Plans

[0001564590-14-006033:notes:135]
We have defined employee contribution plans for substantially all of our U.S. employees (401(k) plan) and our Canadian employees (Registered Retirement Savings Plan). We recognized expenses under these plans primarily related to matching contributions of $5.3 million, $4.9 million and $4.2 million in Fiscal 2014, 2013 and 2012, respectively.

[0001564590-14-006033:notes:136]
Deferred Compensation

[0001564590-14-006033:notes:137]
We offer a non-qualified deferred compensation plan to a select group of management and highly compensated individuals. The plan permits the deferral of up to 50% of a participant’s base salary and/or 100% of a participant’s annual incentive bonus. The deferrals are held in a separate trust, an irrevocable rabbi trust (the Rabbi Trust), which has been established to administer the plan. The Rabbi Trust is intended to be used as a source of funds to match respective funding obligations to participants.  The assets of the trust are subject to the claims of our creditors in the event that we become insolvent. Consequently, the Rabbi Trust qualifies as a grantor trust for income tax purposes. We make periodic payments into company-owned life insurance policies held in this Rabbi Trust to fund the expected obligations arising under this plan. The assets and liabilities of the plan are recorded in other assets and deferred compensation, respectively, in the accompanying Consolidated Balance Sheets. Changes in the deferred compensation balance are charged to compensation expense. The plan is not qualified under Section 401 of the Internal Revenue code. We recorded $0.2 million in compensation expense related to this plan in Fiscal 2014. Total assets held by the trustee and deferred compensation liabilities were $3.5 million and $3.7 million, respectively, at September 30, 2014.

[0001564590-14-006033:notes:138]
Certain former executives were provided an executive benefit plan which provides for fixed payments upon normal retirement on or after age 65 and the completion of at least 10 years of continuous employment. The estimated present value of these payments were accrued over the service life of these individuals, and $0.5 million is recorded in deferred compensation related to this executive benefit plan. To assist in funding the deferred compensation liability, we have invested in corporate-owned life insurance policies. The cash surrender value of these policies is presented in other assets and was $4.4 million at September 30, 2014.

[0001564590-14-006033:notes:139]
Retiree Medical Plan

[0001564590-14-006033:notes:140]
We have a plan that extends health benefits to retirees that are also available to active employees under our existing health plans. This plan is unfunded. The plan provides coverage for employees with at least 10 years of service who are age 55 or older but less than 65. The retiree is required to pay the COBRA rate less a subsidy provided by us based on years of service at the time of retirement.  The unfunded liability was $0.7 million as of September 30, 2014 and 2013 and our net periodic postretirement benefit costs have been less than $0.1 million for the last three fiscal years. Due to the immateriality of the costs and liabilities of this plan, no further disclosure is being presented.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001564590-14-006033:notes:141]
J. Stock-Based Compensation

[0001564590-14-006033:notes:142]
We have the following stock-based compensation plans:

[0001564590-14-006033:notes:143]
In February 2014, our stockholders approved and adopted at the Annual Meeting of Stockholders the 2014 Equity Incentive Plan (the 2014 Plan) which replaced our 2006 Equity Compensation Plan (2006 Plan). Persons eligible to receive awards under the 2014 Plan include our officers and employees. The 2014 Plan authorizes stock options, stock appreciation rights, restricted stock, restricted stock units and performance-based awards, as well as certain other awards.  We have reserved 750,000 shares of common stock for issuance under the 2014 Plan.  In Fiscal 2014, 4,778 shares were issued under the 2014 Plan and the total number of shares of common stock left available was 745,222 shares.  In August 2012, 45,000 shares of restricted stock were issued under the 2006 Plan to our new President and Chief Executive Officer. These shares were issued at a price of $39.11 per share and vest over a three-year period on each anniversary of the grant date.  In June 2012, 2,000 shares of restricted stock were issued under the 2006 Plan to the Chairman of the Board, who was an employee of the Company at the time the shares were issued. These shares were issued at a price of $37.50 per share and vest over a two-year period on each anniversary of the grant date. The 2006 Plan terminated in December 2013 and no further awards will be made under this plan.

[0001564590-14-006033:notes:144]
In February 2014, our stockholders approved and adopted at the Annual Meeting of Stockholders the 2014 Non-Employee Director Equity Incentive Plan (the 2014 Director Plan), which replaced our former Restricted Stock Plan. Persons eligible to receive awards under the 2014 Director Plan are non-employee directors of the Board.  The 2014 Director Plan authorizes stock options, stock appreciation rights, restricted stock, restricted stock units, as well as certain other awards. Subject to certain conditions and restrictions as determined by the Compensation Committee of the Board and proportionate adjustments in the event of stock dividends, stock splits and similar corporate transactions, each eligible director will receive 2,000 shares of restricted stock annually.  The annual restricted stock grants vest 50% per year over a two-year period on each anniversary of the grant date.  We reserved 150,000 shares of common stock for issuance under the 2014 Director Plan and in February 2014, 16,000 shares of restricted stock were issued to our non-employee directors at a price of $66.15 per share under this plan.  The total number of shares of common stock available for future awards under this plan was 134,000 shares as of September 30, 2014.  We did not issue any shares in Fiscal 2014 under the Restricted Stock Plan, however, in January 2013, 500 shares of restricted stock were issued to a newly appointed director at a price of $42.54 per share.  In February 2013, 16,000 shares of restricted stock were issued to our directors at a price of $58.54 per share. In Fiscal 2012, 16,000 shares of restricted stock were issued to our directors at a price of $37.50 per share.  The Restricted Stock Plan terminates in December 2014, and no further grants shall be made under this plan.

[0001564590-14-006033:notes:145]
Restricted stock grants vest equally over their respective vesting period on each anniversary of the grant date and compensation expense is recognized over their respective vesting periods based on the price per share on the grant date.  At September 30, 2014 and 2013, there were 54,240 shares and 68,100 shares of unvested restricted stock outstanding.  During the year ended September 30, 2014, we recorded compensation expense of $1.3 million related to restricted stock grants. We recorded compensation expense of $2.1 million and $0.7 million related to restricted stock grants for the years ended September 30, 2013 and 2012, respectively.

[0001564590-14-006033:notes:146]
We also issue restricted stock units (RSUs) to certain officers and key employees of the company. The RSUs vest over a three-year period from their date of issuance. The fair value of the RSUs is based on the closing price of our common stock as reported on the NASDAQ Global Market (NASDAQ) on the grant dates. Sixty percent of the actual amount of the RSUs earned will be based on the cumulative earnings as reported relative to the three-year performance cycle which begins October 1 of the year granted, and ranges from 0% to 150% of the target RSUs granted. The remaining forty percent of the RSUs are time-based and vest over a three-year period. At September 30, 2014, there were 106,845 RSUs outstanding. The RSUs do not have voting rights and do not receive dividends on common stock; additionally, the shares of common stock underlying the RSUs are not considered issued and outstanding until actually issued.  In Fiscal 2014, 2,200 restricted stock units were issued under the 2006 Plan. We recorded compensation expense of $2.1 million, $2.4 million and $1.5 million related to RSUs for the years ended September 30, 2014, 2013 and 2012, respectively.

[0001564590-14-006033:notes:147]
Total RSU activity (number of shares) for the past three years is summarized below:

[0001564590-14-006033:notes:148]
|  | Number of |  |  | Weighted |  |
|  | Restricted |  |  | Average |  |
|  | Stock |  |  | Fair Value |  |
|  | Units |  |  | Per Share |  |
| Outstanding at September 30, 2011 |  | 69,378 |  |  | $ | 36.10 |  |
| Granted |  | 54,825 |  |  |  | 31.18 |  |
| Vested |  | (24,478 | ) |  |  | 38.71 |  |
| Forfeited |  | — |  |  |  | — |  |
| Outstanding at September 30, 2012 |  | 99,725 |  |  | $ | 32.69 |  |
| Granted |  | 58,775 |  |  |  | 39.05 |  |
| Vested |  | (66,383 | ) |  |  | 34.00 |  |
| Forfeited |  | (10,562 | ) |  |  | 33.46 |  |
| Outstanding at September 30, 2013 |  | 81,555 |  |  | $ | 38.66 |  |
| Granted |  | 57,200 |  |  |  | 66.15 |  |
| Vested |  | (29,832 | ) |  |  | 44.88 |  |
| Forfeited |  | (2,078 | ) |  |  | 56.34 |  |
| Outstanding at September 30, 2014 |  | 106,845 |  |  | $ | 51.30 |  |

[0001564590-14-006033:notes:149]
We record the amortization of non-vested restricted stock and restricted stock units as an increase to additional paid-in capital.  As of September 30, 2014 and 2013, amounts not yet recognized related to non-vested stock totaled $2.4 million and $2.1 million, respectively. As of September 30, 2014, the total weighted average remaining contractual life of our restricted stock and RSU’s is 0.87 years and 1.15 years, respectively.


## us-gaap:FairValueDisclosuresTextBlock

[0001564590-14-006033:notes:150]
K. Fair Value Measurements

[0001564590-14-006033:notes:151]
We measure certain financial assets and liabilities at fair value. Fair value is defined as an “exit price” which represents the amount that would be received to sell an asset or paid to transfer a liability in an orderly transaction between market participants as of the measurement date. As such, fair value is a market-based measurement that should be determined based on assumptions that market participants would use in valuing an asset or liability. The accounting guidance requires the use of valuation techniques to measure fair value that maximize the use of observable inputs and minimize the use of unobservable inputs. As a basis for considering such assumptions and inputs, a fair value hierarchy has been established that identifies and prioritizes three levels of inputs to be used in measuring fair value.

[0001564590-14-006033:notes:152]
The three levels of the fair value hierarchy are as follows:

[0001564590-14-006033:notes:153]
Level 1 — Observable inputs such as quoted prices (unadjusted) in active markets for identical assets or liabilities.

[0001564590-14-006033:notes:154]
Level 2 — Inputs other than the quoted prices in active markets that are observable either directly or indirectly, including: quoted prices for similar assets and liabilities in active markets; quoted prices for identical or similar assets and liabilities in markets that are not active or other inputs that are observable or can be corroborated by observable market data.

[0001564590-14-006033:notes:155]
Level 3 — Unobservable inputs that are supported by little or no market data and require the reporting entity to develop its own assumptions.

[0001564590-14-006033:notes:156]
The following table summarizes the fair value of our assets that were accounted for at fair value on a recurring basis as of September 30, 2014 (in thousands):

[0001564590-14-006033:notes:157]
|  | Fair Value Measurements at September 30, 2014 |  |
|  | Quoted Prices in |  |  | Significant Other |  |  | Significant |  |  |  |  |  |
|  | Active Markets for |  |  | Observable |  |  | Unobservable |  |  | Fair Value at |  |
|  | Identical Assets |  |  | Inputs |  |  | Inputs |  |  | September 30, |  |
|  | (Level 1) |  |  | (Level 2) |  |  | (Level 3) |  |  | 2014 |  |
| Assets: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cash equivalents | $ | 10,535 |  |  | $ | — |  |  | $ | — |  |  | $ | 10,535 |  |
| Deferred compensation |  | 724 |  |  |  | 2,802 |  |  |  | — |  |  |  | 3,526 |  |
| Liabilities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Deferred compensation |  | — |  |  |  | 3,688 |  |  |  | — |  |  |  | 3,688 |  |

[0001564590-14-006033:notes:158]
The following table summarizes the fair value of our assets that were accounted for at fair value on a recurring basis as of September 30, 2013 (in thousands):

[0001564590-14-006033:notes:159]
|  | Fair Value Measurements at September 30, 2013 |  |
|  | Quoted Prices in |  |  | Significant Other |  |  | Significant |  |  |  |  |  |
|  | Active Markets for |  |  | Observable |  |  | Unobservable |  |  | Fair Value at |  |
|  | Identical Assets |  |  | Inputs |  |  | Inputs |  |  | September 30, |  |
|  | (Level 1) |  |  | (Level 2) |  |  | (Level 3) |  |  | 2013 |  |
| Assets: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cash equivalents | $ | 10,531 |  |  | $ | — |  |  | $ | — |  |  | $ | 10,531 |  |
| Deferred compensation |  | 793 |  |  |  | 2,069 |  |  |  | — |  |  |  | 2,862 |  |
| Liabilities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Deferred compensation |  | — |  |  |  | 2,862 |  |  |  | — |  |  |  | 2,862 |  |

[0001564590-14-006033:notes:160]
Cash equivalents, primarily funds held in money market savings instruments, are reported at their current carrying value which approximates fair value due to the short-term nature of these instruments and are included in cash and cash equivalents in our Consolidated Balance Sheets.

[0001564590-14-006033:notes:161]
Fair Value of Other Financial Instruments

[0001564590-14-006033:notes:162]
Fair value guidance requires certain fair value disclosures be presented in both interim and annual reports. The estimated fair value amounts of financial instruments have been determined using available market information and valuation methodologies described below.

[0001564590-14-006033:notes:163]
Deferred Compensation – We hold investments in an irrevocable Rabbi Trust for our deferred compensation plan. These assets include both mutual fund investments and company-owned life insurance policies.  Under the plan, participants designate investment options to serve as the basis for measurement of the notional value of their accounts.  The fair values of the underlying securities of these funds are based on quoted market prices and are categorized as Level I in the fair value measurement hierarchy.  The company-owned life insurance policies are valued at cash surrender value and are therefore categorized as Level 2 in the fair value measurement hierarchy.

[0001564590-14-006033:notes:164]
Industrial Development Revenue Bonds – The fair value of our long-term debt depends primarily on the coupon rate of our industrial development revenue bonds. The carrying value of our long-term debt at September 30, 2013, approximates fair value based on the current coupon rate of the bonds, which is reset weekly. It is classified as a Level 2 input in the fair value measurement hierarchy as there is an active market for the trading of these industrial development revenue bonds.

[0001564590-14-006033:notes:165]
There were no transfers between levels with the fair value measurement hierarchy during Fiscal 2014.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001564590-14-006033:notes:166]
L. Geographic Information

[0001564590-14-006033:notes:167]
All revenues represent sales to unaffiliated customers and are summarized for the last three fiscal years by region in the table below:

[0001564590-14-006033:notes:168]
|  | Year Ended September 30, |  |
|  | 2014 |  |  | 2013 |  |  | 2012 |  |
| United States | $ | 365,085 |  |  | $ | 374,453 |  |  | $ | 388,977 |  |
| Canada |  | 137,684 |  |  |  | 113,391 |  |  |  | 92,656 |  |
| Middle East and Africa |  | 84,330 |  |  |  | 61,618 |  |  |  | 79,778 |  |
| Europe (including former Soviet Union) |  | 34,920 |  |  |  | 24,092 |  |  |  | 24,857 |  |
| Far East |  | 15,127 |  |  |  | 35,388 |  |  |  | 12,418 |  |
| Mexico, Central and South America |  | 10,668 |  |  |  | 31,925 |  |  |  | 92,055 |  |
| Total revenues | $ | 647,814 |  |  | $ | 640,867 |  |  | $ | 690,741 |  |

[0001564590-14-006033:notes:169]
|  | September 30, |  |
|  | 2014 |  |  | 2013 |  |
| Long-lived assets: |  |  |  |  |  |  |  |
| United States | $ | 99,711 |  |  | $ | 96,824 |  |
| Canada |  | 51,493 |  |  |  | 41,777 |  |
| United Kingdom |  | 5,692 |  |  |  | 5,894 |  |
| Total | $ | 156,896 |  |  | $ | 144,495 |  |

[0001564590-14-006033:notes:170]
Long-lived assets consist of property, plant and equipment net of accumulated depreciation.


## us-gaap:QuarterlyFinancialInformationTextBlock

[0001564590-14-006033:notes:171]
M. Quarterly Information

[0001564590-14-006033:notes:172]
The table below sets forth the unaudited consolidated operating results by fiscal quarter for the years ended September 30, 2014 and 2013 (in thousands, except per share data):

[0001564590-14-006033:notes:173]
|  | 2014 Quarters |  |
|  | First |  |  | Second |  |  | Third |  |  | Fourth |  |  | 2014 |  |
| Revenues | $ | 171,872 |  |  | $ | 162,295 |  |  | $ | 150,800 |  |  | $ | 162,847 |  |  | $ | 647,814 |  |
| Gross profit |  | 35,158 |  |  |  | 34,928 |  |  |  | 29,642 |  |  |  | 25,746 |  |  |  | 125,474 |  |
| Income from continuing operations |  | 7,268 |  |  |  | 6,976 |  |  |  | 2,947 |  |  |  | 2,429 |  |  |  | 19,620 |  |
| Net income |  | 8,255 |  |  |  | 15,593 |  |  |  | 2,947 |  |  |  | 2,429 |  |  |  | 29,224 |  |
| Earnings per share ─ continuing operations: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic | $ | 0.61 |  |  | $ | 0.58 |  |  | $ | 0.25 |  |  | $ | 0.20 |  |  | $ | 1.63 |  |
| Diluted | $ | 0.60 |  |  | $ | 0.58 |  |  | $ | 0.24 |  |  | $ | 0.20 |  |  | $ | 1.62 |  |
| Earnings per share: (1) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic | $ | 0.69 |  |  | $ | 1.30 |  |  | $ | 0.25 |  |  | $ | 0.20 |  |  | $ | 2.43 |  |
| Diluted | $ | 0.68 |  |  | $ | 1.29 |  |  | $ | 0.24 |  |  | $ | 0.20 |  |  | $ | 2.42 |  |

[0001564590-14-006033:notes:174]
|  | 2013 Quarters |  |
|  | First |  |  | Second |  |  | Third |  |  | Fourth |  |  | 2013 |  |
| Revenues | $ | 146,858 |  |  | $ | 146,041 |  |  | $ | 171,733 |  |  | $ | 176,235 |  |  | $ | 640,867 |  |
| Gross profit |  | 32,402 |  |  |  | 29,543 |  |  |  | 36,593 |  |  |  | 39,954 |  |  |  | 138,492 |  |
| Income from continuing operations |  | 7,120 |  |  |  | 6,202 |  |  |  | 9,083 |  |  |  | 17,334 |  |  |  | 39,739 |  |
| Net income |  | 7,385 |  |  |  | 6,818 |  |  |  | 9,305 |  |  |  | 18,568 |  |  |  | 42,076 |  |
| Earnings per share ─ continuing operations: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic | $ | 0.60 |  |  | $ | 0.52 |  |  | $ | 0.76 |  |  | $ | 1.45 |  |  | $ | 3.32 |  |
| Diluted | $ | 0.60 |  |  | $ | 0.52 |  |  | $ | 0.76 |  |  | $ | 1.44 |  |  | $ | 3.32 |  |
| Earnings per share: (2) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic | $ | 0.62 |  |  | $ | 0.57 |  |  | $ | 0.78 |  |  | $ | 1.55 |  |  | $ | 3.52 |  |
| Diluted | $ | 0.62 |  |  | $ | 0.57 |  |  | $ | 0.78 |  |  | $ | 1.54 |  |  | $ | 3.51 |  |

[0001564590-14-006033:notes:175]
| (1) | The increase in earnings per share for the second quarter of Fiscal 2014 was primarily due to the sale of Transdyn. For additional information on this disposition, see Note N. |

[0001564590-14-006033:notes:176]
| (2) | The increase in earnings per share for the fourth quarter of Fiscal 2013 was primarily driven by the release of our Canadian valuation allowance. For an explanation of the effective tax rate in Fiscal 2013, see Note H. |

[0001564590-14-006033:notes:177]
The sum of the individual earnings per share amounts may not agree with year-to-date earnings per share as each period’s computation is based on the weighted-average number of shares outstanding during the period.


## us-gaap:DisposalGroupsIncludingDiscontinuedOperationsDisclosureTextBlock

[0001564590-14-006033:notes:178]
N. Discontinued Operations

[0001564590-14-006033:notes:179]
On January 15, 2014, we sold our wholly owned subsidiary Transdyn to a global provider of electronic toll collection systems, headquartered in Vienna, Austria.  The purchase price from the sale of this subsidiary totaled $16.0 million, of which we received cash of $14.4 million.  The remaining $1.6 million was placed into an escrow account until April 2015, to be released subject to certain contingent obligations, and was recorded to other assets.  We received additional cash of $0.4 million after the final working capital adjustment was calculated in March 2014. We recorded a gain on this transaction of $8.6 million, net of tax, which has been included in income from discontinued operations in Fiscal 2014 in the accompanying consolidated statements of operations.  Transdyn’s results were previously reflected in the Process Control Systems business segment.

[0001564590-14-006033:notes:180]
We reclassified the assets and liabilities of Transdyn as held for sale within the accompanying consolidated balance sheets as of September 30, 2013 and presented the results of these operations as income from discontinued operations, net of tax, for each of the accompanying consolidated statements of operations.

[0001564590-14-006033:notes:181]
Summary comparative financial results of discontinued operations were as follows (in thousands):

[0001564590-14-006033:notes:182]
|  | Year Ended September 30, |  |
|  | 2014 |  |  | 2013 |  |  | 2012 |  |
| Revenues | $ | 13,923 |  |  | $ | 33,905 |  |  | $ | 26,452 |  |
| Income from discontinued operations, net of tax of $633, $1,269 and $522, respectively | $ | 1,041 |  |  | $ | 2,337 |  |  | $ | 914 |  |
| Gain on sale of discontinued operations, net of tax of $5,218 |  | 8,563 |  |  |  | — |  |  |  | — |  |
| Net income from discontinued operations, net of tax | $ | 9,604 |  |  | $ | 2,337 |  |  | $ | 914 |  |
| Earnings per share information: |  |  |  |  |  |  |  |  |  |  |  |
| Basic | $ | 0.80 |  |  | $ | 0.20 |  |  | $ | 0.07 |  |
| Diluted | $ | 0.80 |  |  | $ | 0.19 |  |  | $ | 0.08 |  |

[0001564590-14-006033:notes:183]
|  | September 30, |  |
|  | 2013 |  |
| Current assets: |  |  |  |
| Cash and cash equivalents | $ | 337 |  |
| Accounts receivable |  | 7,346 |  |
| Contracts in progress |  | 7,201 |  |
| Inventories, net |  | 20 |  |
| Prepaid expenses and other current assets |  | 505 |  |
| Current assets held for sale | $ | 15,409 |  |
| Long-term assets: |  |  |  |
| Property, plant and equipment, net | $ | 93 |  |
| Other assets |  | 51 |  |
| Long-term assets held for sale | $ | 144 |  |
| Current liabilities: |  |  |  |
| Accounts payable | $ | 2,973 |  |
| Accrued salaries, bonuses and commissions |  | 1,675 |  |
| Billings in excess of cost |  | 11,867 |  |
| Other accrued expenses and liabilities |  | 1,333 |  |
| Current liabilities held for sale | $ | 17,848 |  |
| Long-term liabilities: |  |  |  |
| Long-term liabilities held for sale | $ | 204 |  |
