# POWL MD&A — 0001564590-14-003175


## mdna

[0001564590-14-003175:mdna:1]
[same as prior period, unchanged from 0001564590-14-001858:mdna:1]

[0001564590-14-003175:mdna:2]
[same as prior period, unchanged from 0001564590-14-001858:mdna:2]

[0001564590-14-003175:mdna:3]
[same as prior period, unchanged from 0001564590-14-001858:mdna:3]

[0001564590-14-003175:mdna:4]
[same as prior period, unchanged from 0001564590-14-001858:mdna:4]

[0001564590-14-003175:mdna:5]
The markets in which we participate are capital intensive and cyclical in nature. Cyclicality is predominantly driven by customer demand, global economic conditions and anticipated environmental or regulatory changes which affect the manner in which our customers proceed with capital investments. Our customers analyze various factors including the demand for oil, gas and electrical energy, the overall financial environment, governmental budgets, regulatory actions and environmental concerns. These factors influence the release of new capital projects by our customers, which are traditionally awarded in competitive bid situations. Scheduling is matched to the customer requirements and projects may take a number of months to produce; schedules also may change during the course of any particular project. Our operating results are impacted by factors outside of our control, for example, many of our projects have contracting arrangements where the approval of engineering and design specifications may affect the timing of the project execution. In the third quarter of fiscal year 2014, we experienced schedule changes on various U.S. projects which negatively impacted our results as the revenues have been pushed into subsequent quarters.

[0001564590-14-003175:mdna:6]
We entered fiscal year 2014 with a backlog of unfilled orders of $437.9 million at September 30, 2013, an increase of $72.0 million compared to our backlog of orders at September 30, 2012.  Our backlog includes various projects, some of which are for complex petrochemical and oil and gas construction projects which take a number of months to produce. The timing of project execution and revenues can be difficult to predict due to the complexity and duration of these projects.

[0001564590-14-003175:mdna:7]
The strength in the western Canadian oil and gas markets continues to be a major contributor to our increase in revenue this year.  We completed the construction of our new Canadian facility and relocated operations from our previous facility in the fall of 2013. The production ramp of our Canadian operations has presented challenges resulting in inefficiencies that have led to custom material shortages, extended project delivery times, higher costs, gross margin deterioration and revenues being pushed into subsequent quarters.  We continue to take actions to mitigate these challenges.

[0001564590-14-003175:mdna:8]
On January 15, 2014, we sold our wholly-owned subsidiary Transdyn to a global provider of electronic toll collection systems, headquartered in Vienna, Austria.  The purchase price from the sale of this subsidiary totaled $16.0 million, of which we received cash of $14.4 million. The remaining $1.6 million was placed into an escrow account until April 2015, to be released subject to certain contingent obligations, and was recorded to other assets.  We received additional cash of $0.4 million after the final working capital adjustment was calculated in March 2014. We recorded a gain on this transaction of $8.6 million, net of tax, which has been included in income from discontinued operations for the nine months ended June 30, 2014 in the accompanying consolidated statements of operations. We reclassified the assets and liabilities of Transdyn as held for sale within the accompanying condensed consolidated balance sheets as of September 30, 2013 and presented the results of these operations as income from discontinued operations, net of tax, for each of the accompanying condensed consolidated statements of operations.  Accordingly, we have removed Transdyn from the Results of Operations discussions below.

[0001564590-14-003175:mdna:9]
[same as prior period, unchanged from 0001564590-14-001858:mdna:9]

[0001564590-14-003175:mdna:10]
Quarter Ended June 30, 2014 Compared to the Quarter Ended June 30, 2013 (Unaudited)

[0001564590-14-003175:mdna:11]
[same as prior period, unchanged from 0001564590-14-001858:mdna:11]

[0001564590-14-003175:mdna:12]
Revenues decreased 12.2%, or $20.9 million, to $150.8 million in the third quarter of fiscal year 2014, compared to the third quarter of fiscal year 2013, primarily due to schedule delays and the timing of certain projects.  Domestic revenues decreased by 15.6%, or $15.7 million, to $85.3 million in the third quarter of fiscal year 2014, compared to the third quarter of fiscal year 2013, and international revenues decreased by 7.3%, or $5.2 million, to $65.5 million in the third quarter of fiscal year 2014, compared to the third quarter of fiscal year 2013.  Revenues from commercial and industrial customers decreased $9.8 million to $112.8 million in the third quarter of fiscal year 2014, compared to the third quarter of fiscal year 2013. Revenues from public and private utilities decreased $3.5 million to $28.2 million in the third quarter of fiscal year 2014, compared to the third quarter of fiscal year 2013. Revenues from municipal and transit projects decreased $7.7 million to $9.8 million in the third quarter of fiscal year 2014, compared to the third quarter of fiscal year 2013.

[0001564590-14-003175:mdna:13]
Gross profit for the third quarter of fiscal year 2014 decreased 19.0%, or $7.0 million, to $29.6 million, compared to the third quarter of fiscal year 2013.  Gross profit as a percentage of revenues decreased to 19.7% in the third quarter of fiscal year 2014, compared to 21.3% in the third quarter of fiscal year 2013. This decrease in gross profit as a percentage of revenue was primarily driven by the margins associated with the mix of projects in process, overhead costs that were not fully absorbed as a result of the reduction in revenue and higher costs resulting from efficiency and utilization challenges associated with the ramp of our Canadian operations.

[0001564590-14-003175:mdna:14]
[same as prior period, unchanged from 0001564590-14-001858:mdna:14]

[0001564590-14-003175:mdna:15]
Selling, general and administrative expenses, as a percentage of revenues, increased to 15.3% during the third quarter of fiscal year 2014, compared to 11.8% during the third quarter of fiscal year 2013, due to the decrease in revenues.  Selling, general and administrative expenses increased by $2.8 million to $23.0 million during the third quarter of fiscal year 2014, compared to the third quarter of fiscal year 2013, primarily due to increased personnel costs, travel, bad debt expense and administrative expenses associated with our strategic growth initiatives.

[0001564590-14-003175:mdna:16]
[same as prior period, unchanged from 0001564590-14-001858:mdna:16]

[0001564590-14-003175:mdna:17]
We recorded other income of $0.5 million in the third quarter of fiscal year 2014 which was the amortization of the deferred gain from the amended supply agreement.

[0001564590-14-003175:mdna:18]
[same as prior period, unchanged from 0001564590-14-001858:mdna:18]

[0001564590-14-003175:mdna:19]
Our provision for income taxes for continuing operations was $2.2 million in the third quarter of fiscal year 2014, compared to $3.0 million in the third quarter of fiscal year 2013.  The effective tax rate for the third quarter of fiscal year 2014 was 43.1% which is above the combined U.S. federal and state statutory rates primarily due to discrete tax items recognized during the quarter as well as the nondeductibility of certain executive compensation costs.  The effective tax rate for the third quarter of fiscal year 2013 was 24.8% and was favorably impacted by the utilization of loss carryforwards on Canadian income and the retroactive availability of the Federal Research and Development Tax Credit.

[0001564590-14-003175:mdna:20]
[same as prior period, unchanged from 0001564590-14-001858:mdna:20]

[0001564590-14-003175:mdna:21]
In the third quarter of fiscal year 2014, we recorded income from continuing operations of $2.9 million, or $0.24 per diluted share, compared to $9.1 million, or $0.76 per diluted share, in the third quarter of fiscal year 2013.  This decrease in income from continuing operations was primarily due to decreased revenue and margins which resulted from project delays and the mix of projects in process.  Additionally, the efficiency and utilization challenges associated with the ramp of our Canadian operations contributed to the decrease in income from continuing operations compared to the prior year.

[0001564590-14-003175:mdna:22]
[same as prior period, unchanged from 0001564590-14-001858:mdna:22]

[0001564590-14-003175:mdna:23]
We had no income from discontinued operations in the third quarter of fiscal year 2014; however, we recorded $0.2 million, or $0.02 per diluted share in the third quarter of fiscal year 2013. For additional information about this disposition, see Note I in the Notes to Condensed Consolidated Financial Statements.

[0001564590-14-003175:mdna:24]
[same as prior period, unchanged from 0001564590-14-001858:mdna:24]

[0001564590-14-003175:mdna:25]
The order backlog at June 30, 2014 was $477.4 million, compared to $452.2 million at March 31, 2014.  New orders placed during the third quarter of fiscal year 2014 totaled $171.7 million compared to $150.2 million in the third quarter of fiscal year 2013.  Orders have increased primarily due to continued strength in oil and gas production and refining projects.

[0001564590-14-003175:mdna:26]
Nine Months Ended June 30, 2014 Compared to the Nine Months Ended June 30, 2013 (Unaudited)

[0001564590-14-003175:mdna:27]
[same as prior period, unchanged from 0001564590-14-001858:mdna:27]

[0001564590-14-003175:mdna:28]
Revenues increased 4.4% or $20.3 million, to $485.0 million for the nine months ended June 30, 2014, compared to the nine months ended June 30, 2013, primarily due to increased demand for our products as a result of our Canadian expansion.  Domestic revenues decreased 3.9%, or $10.8 million, to $266.2 million for the nine months ended June 30, 2014, compared to the nine months ended June 30, 2013, and international revenues increased 16.6%, or $31.1 million, to $218.8 million for the nine months ended June 30, 2014, compared to the nine months ended June 30, 2013.  The increase in international revenues was primarily driven by the expansions of our Canadian operations.  Revenues from commercial and industrial customers increased $22.9 million to $351.8 million for the nine months ended June 30, 2014, compared to the nine months ended June 30, 2013. Revenues from public and private utilities increased $0.8 million to $98.3 million for the nine months ended June 30, 2014, compared to the nine months ended June 30, 2013. Revenues from municipal and transit projects decreased $3.3 million to $34.9 million for the nine months ended June 30, 2014, compared to the nine months ended June 30, 2013.

[0001564590-14-003175:mdna:29]
Gross profit for the nine months ended June 30, 2014 increased 1.2%, or $1.2 million, to $99.7 million, compared to the nine months ended June 30, 2013.  Gross profit as a percentage of revenues was 20.6% for the nine months ended June 30, 2014, compared to 21.2% for the nine months ended June 30, 2013.  Our gross profit as a percentage of revenues declined in the first nine months of fiscal year 2014, compared to fiscal year 2013, primarily due to higher costs resulting from the efficiency and utilization challenges associated with the ramp of our Canadian operations.  Excluding the operational challenges in Canada, gross profit as percentage of revenue improved overall as a result of various cost savings and productivity initiatives.

[0001564590-14-003175:mdna:30]
[same as prior period, unchanged from 0001564590-14-001858:mdna:30]

[0001564590-14-003175:mdna:31]
Selling, general and administrative expenses, as a percentage of revenues, increased to 13.8% during the nine months ended June 30, 2014, compared to 13.0% during the nine months ended June 30, 2013. Selling, general and administrative expenses increased by $6.3 million to $66.8 million during nine months ended June 30, 2014, compared to the nine months ended June 30, 2013, primarily due to increased personnel costs, travel and administrative expenses associated with our strategic growth initiatives.  This increase in selling, general and administrative expense was partially offset by a decrease in depreciation expense as our existing Business Systems became fully depreciated in December 2012 and the favorable impact of the capitalization of certain personnel costs associated with the development and implementation of our new Business Systems.  However, going forward, the favorable impact of depreciation expense and capitalization of certain personnel costs will no longer be realized.

[0001564590-14-003175:mdna:32]
[same as prior period, unchanged from 0001564590-14-001858:mdna:32]

[0001564590-14-003175:mdna:33]
We recorded other income of $1.0 million in the nine months ended June 30, 2014 which was the amortization of the deferred gain from the amended supply agreement, compared to other income of $1.7 million in the same period in fiscal year 2013 which resulted from the settlement of a lawsuit filed against the previous owners of Powell Canada.

[0001564590-14-003175:mdna:34]
[same as prior period, unchanged from 0001564590-14-001858:mdna:34]

[0001564590-14-003175:mdna:35]
Our provision for income taxes for continuing operations was $10.2 million for the nine months ended June 30, 2014, compared to $8.2 million for the nine months ended June 30, 2013.  The effective tax rate for nine months ended June 30, 2014 was 37.3% which approximates the combined U.S. federal and state statutory rates as the majority of our income is attributable to the U.S.  The effective tax rate for the nine months ended June 30, 2013 was 26.5% and was favorably impacted by the utilization of loss carryforwards on Canadian income as well as the extension of the Federal Research and Development Tax Credit.

[0001564590-14-003175:mdna:36]
[same as prior period, unchanged from 0001564590-14-001858:mdna:36]

[0001564590-14-003175:mdna:37]
For the nine months ended June 30, 2014, we recorded income from continuing operations of $17.2 million, or $1.43 per diluted share, compared to $22.8 million, or $1.90 per diluted share, for the nine months ended June 30, 2013.  This decrease in income from continuing operations was primarily due to schedule delays and the mix of projects in process at our domestic operations as well as the efficiency and utilization challenges associated with the ramp of our Canadian operations.

[0001564590-14-003175:mdna:38]
[same as prior period, unchanged from 0001564590-14-001858:mdna:38]

[0001564590-14-003175:mdna:39]
For the nine months ended June 30, 2014, we recorded $9.6 million, or $0.80 per diluted share, of income from discontinued operations compared to $0.7 million, or $0.06 per diluted share, recorded for the nine months ended June 30, 2013 as the current fiscal year includes the gain on the sale. For additional information about this disposition, see Note I in the Notes to Condensed Consolidated Financial Statements.

[0001564590-14-003175:mdna:40]
[same as prior period, unchanged from 0001564590-14-001858:mdna:40]

[0001564590-14-003175:mdna:41]
The order backlog at June 30, 2014 was $477.4 million, compared to $437.9 million at September 30, 2013.  New orders placed during the nine months ended June 30, 2014 totaled $526.5 million compared to $519.3 million for the nine months ended June 30, 2013.  The year over year increase in new orders was primarily due to the continued strength in oil and gas production and refining projects.

[0001564590-14-003175:mdna:42]
[same as prior period, unchanged from 0001564590-14-001858:mdna:42]

[0001564590-14-003175:mdna:43]
Cash and cash equivalents decreased to $87.8 million at June 30, 2014, compared to $107.4 million at September 30, 2013.  As of June 30, 2014, current assets exceeded current liabilities by 2.8 times and our debt to total capitalization was 0.85%.

[0001564590-14-003175:mdna:44]
We have a $75.0 million revolving credit facility in the U.S. which expires in December 2018. As of June 30, 2014, there were no amounts borrowed under this line of credit. We also have a $9.4 million revolving credit facility in Canada. At June 30, 2014, there was no balance outstanding under the Canadian revolving credit facility. Total long-term debt and capital lease obligations, including current maturities, totaled $3.2 million at June 30, 2014, compared to $3.6 million at September 30, 2013. Total letters of credit outstanding were $21.2 million at June 30, 2014 compared to $20.1 million at September 30, 2013, which reduced our availability under our U.S. credit facility and our Canadian revolving credit facility. Amounts available at June 30, 2014 under the U.S. and Canadian revolving credit facilities were $53.9 million and $9.3 million, respectively.  For further information regarding our debt, see Notes E and F of Notes to Condensed Consolidated Financial Statements.

[0001564590-14-003175:mdna:45]
Approximately $7.5 million of our cash at June 30, 2014, was held outside of the United States for international operations.  It is our intention to indefinitely reinvest all current and future foreign earnings internationally in order to ensure sufficient working capital and support and expand these international operations.  In the event that we elect to repatriate some or all of the foreign earnings that were previously deemed to be indefinitely reinvested outside the U.S., under current tax laws we would incur additional tax expense upon such repatriation.

[0001564590-14-003175:mdna:46]
[same as prior period, unchanged from 0001564590-14-001858:mdna:46]

[0001564590-14-003175:mdna:47]
[same as prior period, unchanged from 0001564590-14-001858:mdna:47]

[0001564590-14-003175:mdna:48]
Cash used in operating activities was $14.6 million during the first nine months of fiscal year 2014, compared to cash provided by operating activities of $88.7 million during the first nine months of fiscal year 2013. Cash flow from operations is primarily influenced by demand for our products and services and is impacted as our progress payment terms with our customers are matched with the payment terms with our suppliers.  The change in the first nine months of fiscal year 2014, compared to the same period in the prior year, was primarily due to the billing and collection of contracts receivable based on the progress billing milestones, as well as an unfavorable change in receivables due to a temporary delay in the processing of customer invoices caused by the re-implementation of our Business Systems.  These uses of cash were partially offset by the $10.0 million received from the amended supply agreement.  For further information regarding the amended supply agreement, see Note D in the Notes to Condensed Consolidated Financial Statements.

[0001564590-14-003175:mdna:49]
[same as prior period, unchanged from 0001564590-14-001858:mdna:50]

[0001564590-14-003175:mdna:50]
Cash provided by investing activities during the first nine months of fiscal year 2014 was $3.6 million compared to cash used in investing activities for the same period in fiscal year 2013 of $53.0 million.  Purchases of property, plant and equipment during the first nine months of fiscal year 2014 totaled $12.2 million compared to $53.7 million during the first nine months of fiscal year 2013.  This decrease results from the completion of the construction of our new facilities in fiscal year 2013, offset by the implementation of our Business Systems upgrade in the third quarter of fiscal year 2014.  Additionally, cash provided by investing activities in fiscal year 2014 includes the proceeds from the sale of Transdyn of $14.8 million.

[0001564590-14-003175:mdna:51]
[same as prior period, unchanged from 0001564590-14-001858:mdna:52]

[0001564590-14-003175:mdna:52]
Net cash used in financing activities was $9.9 million during the first nine months of fiscal year 2014 and $0.7 million during the same period of fiscal year 2013.  This increase in the use of cash in the first nine months of fiscal year 2014 was primarily driven by the payment of $9.0 million in cash dividends.

[0001564590-14-003175:mdna:53]
[same as prior period, unchanged from 0001564590-14-001858:mdna:54]

[0001564590-14-003175:mdna:54]
[same as prior period, unchanged from 0001564590-14-001858:mdna:55]

[0001564590-14-003175:mdna:55]
[same as prior period, unchanged from 0001564590-14-001858:mdna:56]

[0001564590-14-003175:mdna:56]
[same as prior period, unchanged from 0001564590-14-001858:mdna:57]

[0001564590-14-003175:mdna:57]
[same as prior period, unchanged from 0001564590-14-001858:mdna:58]

[0001564590-14-003175:mdna:58]
[same as prior period, unchanged from 0001564590-14-001858:mdna:59]

[0001564590-14-003175:mdna:59]
[same as prior period, unchanged from 0001564590-14-001858:mdna:60]

[0001564590-14-003175:mdna:60]
[same as prior period, unchanged from 0001564590-14-001858:mdna:61]

[0001564590-14-003175:mdna:61]
[same as prior period, unchanged from 0001564590-14-001858:mdna:62]

[0001564590-14-003175:mdna:62]
The strength in the western Canadian oil and gas markets continues to provide project opportunities for Powell. Demand for our products and solutions in the Canadian market are placing pressure on our production ramp plan. We completed the construction of our new Canadian facility and relocated operations from our previous facility in the fall of 2013. The production ramp of our Canadian operations may continue to present challenges resulting in inefficiencies which could lead to custom material shortages and extended project delivery times which could result in higher costs, gross margin deterioration and delay the recognition of revenues.  We continue to take actions to mitigate these challenges.

[0001564590-14-003175:mdna:63]
We believe that cash available and borrowing capacity under our existing credit facilities should be sufficient to finance anticipated operating activities, capital improvements and debt repayments for the foreseeable future. We continue to monitor our markets and will strive to maintain our leadership and competitive advantage in the markets we serve.
