# POWL 10-Q controls and the auditor's report


## item_4_controls

[0001564590-14-003175:item_4_controls:1]
Item 4. Controls and Procedures

[0001564590-14-003175:item_4_controls:2]
Evaluation of Disclosure Controls and Procedures

[0001564590-14-003175:item_4_controls:3]
We have established and maintain a system of disclosure controls and procedures that are designed to provide reasonable assurance that information required to be disclosed in our reports filed with the SEC pursuant to the Securities Exchange Act of 1934, as amended (Exchange Act), is recorded, processed, summarized and reported within the time periods specified in the rules and forms of the SEC and that such information is accumulated and communicated to our management, including our Chief Executive Officer (CEO) and Chief Financial Officer (CFO), as appropriate, to allow timely decisions regarding required disclosures.

[0001564590-14-003175:item_4_controls:4]
Management, with the participation of our CEO and CFO, has evaluated the effectiveness of the design and operation of our disclosure controls and procedures (as defined in Rules 13a-15(e) and 15d-15(e) of the Exchange Act) as of the end of the period covered by this report.  Based on such evaluation, our CEO and CFO have each concluded that as of the end of the period, our disclosure controls and procedures were effective to provide reasonable assurance that information required to be disclosed by us in reports that we file or submit under the Exchange Act is recorded, processed, summarized and reported within the time periods

[0001564590-14-003175:item_4_controls:5]
24

[0001564590-14-003175:item_4_controls:6]
specified in the SEC’s rules and forms and that such information is accumulated and communicated to our management, including the CEO and CFO, as appropriate, to allow timely decisions regarding required disclosures.

[0001564590-14-003175:item_4_controls:7]
Changes in Internal Control over Financial Reporting

[0001564590-14-003175:item_4_controls:8]
Except as discussed in the paragraph below, there have been no changes in our internal control over financial reporting that occurred during the last fiscal quarter that have materially affected, or are reasonably likely to materially affect, our internal control over financial reporting.

[0001564590-14-003175:item_4_controls:9]
In 2013, we began to re-implement our enterprise resource planning, engineering and manufacturing process systems (Business Systems) and add additional software that is designed to improve our processes and enhance operational efficiency. We went “live” in early May 2014.  Although we believe the new software enhances our internal control over financial reporting, we continue to conduct post-implementation monitoring and process modification through and around the Business Systems to provide reasonable assurance that our internal controls continue to be effective.
