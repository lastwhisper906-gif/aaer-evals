# POWL notes — 0001564590-14-003175


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureAndSignificantAccountingPoliciesTextBlock

[0001564590-14-003175:notes:1]
[same as prior period, unchanged from 0001564590-14-001858:notes:1]

[0001564590-14-003175:notes:2]
[same as prior period, unchanged from 0001564590-14-001858:notes:2]

[0001564590-14-003175:notes:3]
[same as prior period, unchanged from 0001564590-14-001858:notes:3]

[0001564590-14-003175:notes:4]
[same as prior period, unchanged from 0001564590-14-001858:notes:4]

[0001564590-14-003175:notes:5]
[same as prior period, unchanged from 0001564590-14-001858:notes:5]

[0001564590-14-003175:notes:6]
[same as prior period, unchanged from 0001564590-14-001858:notes:6]

[0001564590-14-003175:notes:7]
[same as prior period, unchanged from 0001564590-14-001858:notes:7]

[0001564590-14-003175:notes:8]
[same as prior period, unchanged from 0001564590-14-001858:notes:8]

[0001564590-14-003175:notes:9]
[same as prior period, unchanged from 0001564590-14-001858:notes:9]

[0001564590-14-003175:notes:10]
[same as prior period, unchanged from 0001564590-14-001858:notes:10]

[0001564590-14-003175:notes:11]
[same as prior period, unchanged from 0001564590-14-001858:notes:11]

[0001564590-14-003175:notes:12]
[same as prior period, unchanged from 0001564590-14-001858:notes:12]

[0001564590-14-003175:notes:13]
[same as prior period, unchanged from 0001564590-14-001858:notes:13]

[0001564590-14-003175:notes:14]
[same as prior period, unchanged from 0001564590-14-001858:notes:14]

[0001564590-14-003175:notes:15]
[same as prior period, unchanged from 0001564590-14-001858:notes:15]

[0001564590-14-003175:notes:16]
In May 2014, the FASB issued a new standard on revenue recognition that supersedes previously issued revenue recognition guidance.  This standard provides a five-step approach to be applied to all contracts with customers and requires expanded disclosures about the nature, amount, timing and uncertainty of revenue (and the related cash flows) arising from customer contracts, significant judgments and changes in judgments used in applying the revenue model and the assets recognized from costs incurred to obtain or fulfill a contract.  This new standard is effective for us beginning in fiscal year 2018.  Early application is not permitted. The standard permits the use of either the retrospective or cumulative effect transition method therefore we are evaluating the effect that this new guidance will have on our consolidated financial statements and related disclosures. We have not yet selected a transition method nor have we determined the effect of the standard on our ongoing financial reporting.


## us-gaap:EarningsPerShareTextBlock

[0001564590-14-003175:notes:17]
[same as prior period, unchanged from 0001564590-14-001858:notes:16]

[0001564590-14-003175:notes:18]
[same as prior period, unchanged from 0001564590-14-001858:notes:17]

[0001564590-14-003175:notes:19]
[same as prior period, unchanged from 0001564590-14-001858:notes:18]

[0001564590-14-003175:notes:20]
|  | Three Months Ended |  |  | Nine Months Ended |  |
|  | June 30, |  |  | June 30, |  |
|  | 2014 |  |  | 2013 |  |  | 2014 |  |  | 2013 |  |
| Numerator: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Income from continuing operations |  | 2,947 |  |  |  | 9,083 |  |  |  | 17,190 |  |  |  | 22,806 |  |
| Income from discontinued operations |  | - |  |  |  | 222 |  |  |  | 9,604 |  |  |  | 702 |  |
| Net income | $ | 2,947 |  |  | $ | 9,305 |  |  | $ | 26,794 |  |  | $ | 23,508 |  |
| Denominator: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Weighted average basic shares |  | 12,015 |  |  |  | 11,941 |  |  |  | 12,004 |  |  |  | 11,932 |  |
| Dilutive effect of restricted stock units |  | 60 |  |  |  | 75 |  |  |  | 59 |  |  |  | 75 |  |
| Weighted average diluted shares with assumed conversions |  | 12,075 |  |  |  | 12,016 |  |  |  | 12,063 |  |  |  | 12,007 |  |
| Net earnings per share: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Continuing operations | $ | 0.25 |  |  | $ | 0.76 |  |  | $ | 1.43 |  |  | $ | 1.91 |  |
| Discontinued operations |  | — |  |  |  | 0.02 |  |  |  | 0.80 |  |  |  | 0.06 |  |
| Basic earnings per share | $ | 0.25 |  |  | $ | 0.78 |  |  | $ | 2.23 |  |  | $ | 1.97 |  |
| Continuing operations | $ | 0.24 |  |  | $ | 0.76 |  |  | $ | 1.43 |  |  | $ | 1.90 |  |
| Discontinued operations |  | — |  |  |  | 0.02 |  |  |  | 0.80 |  |  |  | 0.06 |  |
| Diluted earnings per share | $ | 0.24 |  |  | $ | 0.78 |  |  | $ | 2.23 |  |  | $ | 1.96 |  |


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0001564590-14-003175:notes:21]
[same as prior period, unchanged from 0001564590-14-001858:notes:20]

[0001564590-14-003175:notes:22]
[same as prior period, unchanged from 0001564590-14-001858:notes:21]

[0001564590-14-003175:notes:23]
[same as prior period, unchanged from 0001564590-14-001858:notes:22]

[0001564590-14-003175:notes:24]
|  | Three Months Ended |  |  | Nine Months Ended |  |
|  | June 30, |  |  | June 30, |  |
|  | 2014 |  |  | 2013 |  |  | 2014 |  |  | 2013 |  |
| Balance at beginning of period | $ | 501 |  |  | $ | 818 |  |  | $ | 572 |  |  | $ | 1,297 |  |
| Bad debt expense/(recovery) |  | 676 |  |  |  | 20 |  |  |  | 616 |  |  |  | (310 | ) |
| Uncollectible accounts written off, net of recoveries |  | (38 | ) |  |  | (19 | ) |  |  | (46 | ) |  |  | (156 | ) |
| Change in foreign currency translation |  | 5 |  |  |  | (2 | ) |  |  | 2 |  |  |  | (14 | ) |
| Balance at end of period | $ | 1,144 |  |  | $ | 817 |  |  | $ | 1,144 |  |  | $ | 817 |  |

[0001564590-14-003175:notes:25]
[same as prior period, unchanged from 0001564590-14-001858:notes:24]

[0001564590-14-003175:notes:26]
[same as prior period, unchanged from 0001564590-14-001858:notes:25]

[0001564590-14-003175:notes:27]
|  | June 30, |  |  | September 30, |  |
|  | 2014 |  |  | 2013 |  |
| Raw materials, parts and subassemblies | $ | 31,484 |  |  | $ | 30,077 |  |
| Work-in-progress |  | 1,551 |  |  |  | 3,818 |  |
| Provision for excess and obsolete inventory |  | (4,326 | ) |  |  | (4,932 | ) |
| Total inventories | $ | 28,709 |  |  | $ | 28,963 |  |

[0001564590-14-003175:notes:28]
[same as prior period, unchanged from 0001564590-14-001858:notes:27]

[0001564590-14-003175:notes:29]
[same as prior period, unchanged from 0001564590-14-001858:notes:28]

[0001564590-14-003175:notes:30]
|  | June 30, |  |  | September 30, |  |
|  | 2014 |  |  | 2013 |  |
| Costs incurred on uncompleted contracts | $ | 709,561 |  |  | $ | 618,570 |  |
| Estimated earnings |  | 182,506 |  |  |  | 159,962 |  |
|  |  | 892,067 |  |  |  | 778,532 |  |
| Less: Billings to date |  | (842,322 | ) |  |  | (747,446 | ) |
| Net underbilled position | $ | 49,745 |  |  | $ | 31,086 |  |
| Included in the accompanying balance sheets under the following captions: |  |  |  |  |  |  |  |
| Costs and estimated earnings in excess of billings on uncompleted contracts – underbilled | $ | 83,999 |  |  | $ | 79,420 |  |
| Billings in excess of costs and estimated earnings on uncompleted contracts – overbilled |  | (34,254 | ) |  |  | (48,334 | ) |
| Net underbilled position | $ | 49,745 |  |  | $ | 31,086 |  |

[0001564590-14-003175:notes:31]
[same as prior period, unchanged from 0001564590-14-001858:notes:30]

[0001564590-14-003175:notes:32]
[same as prior period, unchanged from 0001564590-14-001858:notes:31]

[0001564590-14-003175:notes:33]
|  | Three Months Ended |  |  | Nine Months Ended |  |
|  | June 30, |  |  | June 30, |  |
|  | 2014 |  |  | 2013 |  |  | 2014 |  |  | 2013 |  |
| Balance at beginning of period | $ | 4,833 |  |  | $ | 5,109 |  |  | $ | 5,282 |  |  | $ | 5,548 |  |
| Increase to warranty expense |  | 884 |  |  |  | 430 |  |  |  | 2,390 |  |  |  | 2,048 |  |
| Deduction for warranty charges |  | (1,023 | ) |  |  | (874 | ) |  |  | (2,949 | ) |  |  | (2,849 | ) |
| Increase (decrease) due to foreign currency translations |  | 61 |  |  |  | (10 | ) |  |  | 32 |  |  |  | (92 | ) |
| Balance at end of period | $ | 4,755 |  |  | $ | 4,655 |  |  | $ | 4,755 |  |  | $ | 4,655 |  |


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0001564590-14-003175:notes:34]
[same as prior period, unchanged from 0001564590-14-001858:notes:33]

[0001564590-14-003175:notes:35]
Intangible assets balances, subject to amortization, at June 30, 2014 and September 30, 2013 consisted of the following (in thousands):

[0001564590-14-003175:notes:36]
|  | June 30, 2014 |  |  | September 30, 2013 |  |
|  | Gross |  |  |  |  |  |  | Net |  |  | Gross |  |  |  |  |  |  | Net |  |
|  | Carrying |  |  | Accumulated |  |  | Carrying |  |  | Carrying |  |  | Accumulated |  |  | Carrying |  |
|  | Value |  |  | Amortization |  |  | Value |  |  | Value |  |  | Amortization |  |  | Value |  |
| Purchased technology | $ | 11,749 |  |  | $ | (9,795 | ) |  | $ | 1,954 |  |  | $ | 11,749 |  |  | $ | (9,489 | ) |  | $ | 2,260 |  |
| Trade name |  | 1,136 |  |  |  | (1,034 | ) |  |  | 102 |  |  |  | 1,136 |  |  |  | (967 | ) |  |  | 169 |  |
| Supply agreement |  | — |  |  |  | — |  |  |  | — |  |  |  | 17,580 |  |  |  | (8,397 | ) |  |  | 9,183 |  |
| Total | $ | 12,885 |  |  | $ | (10,829 | ) |  | $ | 2,056 |  |  | $ | 30,465 |  |  | $ | (18,853 | ) |  | $ | 11,612 |  |

[0001564590-14-003175:notes:37]
Amortization of intangible assets recorded for the nine months ended June 30, 2014 and 2013 was $0.7 million and $1.2 million, respectively.

[0001564590-14-003175:notes:38]
On August 7, 2006, we purchased certain assets related to the manufacturing of ANSI medium-voltage switchgear and circuit breaker business from General Electric Company (GE).  In connection with the acquisition, we entered into a 15 year supply agreement with GE pursuant to which GE would purchase from the Company all of its requirements for ANSI medium-voltage switchgear and circuit breakers and other related equipment and components (the Products)  In connection with the acquisition, we recorded an intangible asset related to this supply agreement.  On December 30, 2013, the Company and GE amended the supply agreement to allow GE to manufacture similar Products for sale immediately and allow GE to begin purchasing Products from other suppliers beginning December 31, 2014.  In return, GE paid us $10 million upon execution of the amended supply agreement and agreed to pay an additional $7 million over three years, subject to certain conditions.  We have $2.3 million recorded in other current assets and the remaining $4.7 million is recorded as a long-term receivable. We wrote off the intangible asset related to the original supply agreement and recorded a deferred credit in the amount of $8.1 million, the amount by which the total proceeds from GE exceeded the unamortized balance of our intangible asset. We are amortizing this deferred credit over the four year life of the agreement and have recognized the $1.0 million gain in other income in the first nine months of fiscal year 2014.


## us-gaap:LongTermDebtTextBlock

[0001564590-14-003175:notes:39]
E. LONG-TERM DEBT

[0001564590-14-003175:notes:40]
Long-term debt consisted of the following (in thousands):

[0001564590-14-003175:notes:41]
|  | June 30, |  |  | September 30, |  |
|  | 2014 |  |  | 2013 |  |
| Industrial development revenue bonds | $ | 3,200 |  |  | $ | 3,600 |  |
| Capital lease obligations |  | — |  |  |  | 16 |  |
| Subtotal long-term debt and capital lease obligations |  | 3,200 |  |  |  | 3,616 |  |
| Less current portion |  | (400 | ) |  |  | (416 | ) |
| Total long-term debt and capital lease obligations | $ | 2,800 |  |  | $ | 3,200 |  |

[0001564590-14-003175:notes:42]
US Revolver

[0001564590-14-003175:notes:43]
In fiscal year 2014, we amended and restated our existing credit agreement (Amended Credit Agreement) with a major domestic bank. We entered into this Amended Credit Agreement to, among other things, allow for the payment of dividends and to extend the expiration date of the facility. The Amended Credit Agreement provides for a $75.0 million revolving credit facility (U.S. Revolver). Obligations are collateralized by the stock of certain of our subsidiaries.

[0001564590-14-003175:notes:44]
The interest rate for amounts outstanding under the Amended Credit Agreement for the U.S. Revolver is a floating rate based upon the higher of the Federal Funds Rate plus 0.5%, the bank’s prime rate, or the Eurocurrency rate plus 1.00%. Once the applicable rate is determined, a margin ranging up to 1.75%, as determined by our consolidated leverage ratio, is added to the applicable rate.

[0001564590-14-003175:notes:45]
The U.S. Revolver provides for the issuance of letters of credit which reduce the amounts that may be borrowed under this revolver. The amount available under the U.S. Revolver was reduced by $21.1 million for our outstanding letters of credit at June 30, 2014.

[0001564590-14-003175:notes:46]
There were no borrowings outstanding under the U.S. Revolver as of June 30, 2014. Amounts available under the U.S. Revolver were $53.9 million at June 30, 2014. The U.S. Revolver expires on December 31, 2018.

[0001564590-14-003175:notes:47]
The Amended Credit Agreement contains certain restrictive and maintenance-type covenants, such as restrictions on the amount of capital expenditures allowed. It also contains financial covenants defining various financial measures and the levels of these measures with which we must comply, as well as a “material adverse change” clause. A “material adverse change” is defined as a material change in our operations, business, properties, liabilities or condition (financial or otherwise) or a material impairment of our ability to perform our obligations under our credit agreements.

[0001564590-14-003175:notes:48]
The Amended Credit Agreement is collateralized by a pledge of 100% of the voting capital stock of each of our domestic subsidiaries and 66% of the voting capital stock of each non-domestic subsidiary, excluding Powell Canada. The Amended Credit Agreement provides for customary events of default and carries cross-default provisions with other existing debt agreements. If an event of default (as defined in the Amended Credit Agreement) occurs and is continuing, on the terms and subject to the conditions set forth in the Amended Credit Agreement, amounts outstanding under the Amended Credit Agreement may be accelerated and may become immediately due and payable. As of June 30, 2014, we were in compliance with all of the financial covenants of the Amended Credit Agreement.

[0001564590-14-003175:notes:49]
Canadian Revolver

[0001564590-14-003175:notes:50]
We have a $9.4 million credit agreement with a major international bank in Canada (the Canadian Revolver) to provide working capital support and letters of credit for our operations in Canada. The Canadian Revolver provides for the issuance of letters of credit which reduce the amounts that may be borrowed under this revolver. The amount available under the Canadian Revolver was reduced by $0.1 million for an outstanding letter of credit at June 30, 2014.

[0001564590-14-003175:notes:51]
There were no borrowings outstanding under the Canadian Revolver as of June 30, 2014.  Amounts available under the Canadian Revolver were $9.3 million at June 30, 2014. The Canadian Revolver expires on February 28, 2015. The interest rate for amounts outstanding under the Canadian Revolver is a floating interest rate based upon either the Canadian Prime Rate, or the lender’s Bankers’ Acceptance Rate. Once the applicable rate is determined, a margin of 0.50% to 1.75%, as determined by our consolidated leverage ratio, is added to the applicable rate.

[0001564590-14-003175:notes:52]
The principal financial covenants are consistent with those described in our Amended Credit Agreement. The Canadian Revolver contains a “material adverse effect” clause. A “material adverse effect” is defined as a material change in the operations of Powell or Powell Canada in relation to our financial condition, property, business operations, expected net cash flows, liabilities or capitalization.

[0001564590-14-003175:notes:53]
The Canadian Revolver is secured by the assets of our Canadian operations and provides for customary events of default and carries cross-default provisions with our existing debt agreements. If an event of default (as defined in the Canadian Revolver) occurs and is continuing, per the terms and subject to the conditions set forth in the Canadian Revolver, amounts outstanding under the Canadian Revolver may be accelerated and may become immediately due and payable. As of June 30, 2014, we were in compliance with all of the financial covenants of the Canadian Revolver.

[0001564590-14-003175:notes:54]
Industrial Development Revenue Bonds

[0001564590-14-003175:notes:55]
We borrowed $8.0 million in October 2001 through a loan agreement funded with proceeds from tax-exempt industrial development revenue bonds (Bonds). These Bonds were issued by the Illinois Development Finance Authority and were used for the completion of our Northlake, Illinois facility. Pursuant to the Bond issuance, a reimbursement agreement between us and a major domestic bank required an issuance by the bank of an irrevocable direct-pay letter of credit (Bond LC), as collateral, to the Bonds’ trustee to guarantee payment of the Bonds’ principal and interest when due. The Bond LC is subject to both early termination and extension provisions customary to such agreements, as well as various covenants, for which we were in compliance at June 30, 2014. While the Bonds mature in 2021, the reimbursement agreement requires annual redemptions of $0.4 million that commenced on October 25, 2002. A sinking fund is used for the redemption of the Bonds. At June 30, 2014, the balance in the restricted sinking fund was approximately $0.3 million and was recorded in cash and cash equivalents. The Bonds bear interest at a floating rate determined weekly by the Bonds’ remarketing agent, which was the underwriter for the Bonds and is an affiliate of the bank. This interest rate was 0.25% as of June 30, 2014.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001564590-14-003175:notes:56]
F. COMMITMENTS AND CONTINGENCIES

[0001564590-14-003175:notes:57]
Long-Term Debt

[0001564590-14-003175:notes:58]
See Note E herein for discussion of our long-term debt.

[0001564590-14-003175:notes:59]
Letters of Credit and Bonds

[0001564590-14-003175:notes:60]
Certain customers require us to post bank letter of credit guarantees or performance bonds issued by a surety. These guarantees and performance bonds assure that we will perform under the terms of our contract. In the event of default, the counterparty may demand payment from the bank under a letter of credit or performance by the surety under a performance bond. To date, there have been no significant expenses related to either letters of credit or performance bonds for the periods reported. We were contingently liable for secured and unsecured letters of credit of $21.2 million as of June 30, 2014. We also had performance and maintenance bonds totaling $330.2 million that were outstanding, with additional bonding capacity of $269.8 million available, at June 30, 2014.

[0001564590-14-003175:notes:61]
We have an $8.5 million facility agreement (Facility Agreement) between Powell (UK) Limited and a large international bank. This Facility Agreement provides Powell (UK) the ability to enter into various guarantees, such as forward exchange contracts, currency options and performance bonds. At June 30, 2014, we had outstanding guarantees totaling $3.7 million under this Facility Agreement.  Amounts available under this Facility Agreement were $4.8 million as of June 30, 2014.

[0001564590-14-003175:notes:62]
The Facility Agreement provides for financial covenants and customary events of default, and carries cross-default provisions with our Amended Credit Facility. If an event of default (as defined in the Facility Agreement) occurs and is continuing, per the terms and subject to the conditions set forth in the Facility Agreement, obligations outstanding under the Facility Agreement may be accelerated and may become or be declared immediately due and payable. As of June 30, 2014, we were in compliance with all of the financial covenants of the Facility Agreement.

[0001564590-14-003175:notes:63]
Litigation

[0001564590-14-003175:notes:64]
We are involved in various legal proceedings, claims and other disputes arising in the ordinary course of business which, in general, are subject to uncertainties and the outcomes are not predictable. Although we can give no assurance about the outcome of pending or threatened litigation and the effect such outcomes may have on us, management believes that any ultimate liability resulting from the outcome of such proceedings, to the extent not otherwise provided or covered by insurance, will not have a material adverse effect on our consolidated financial position or results of operations or liquidity.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001564590-14-003175:notes:65]
[same as prior period, unchanged from 0001564590-14-001858:notes:64]

[0001564590-14-003175:notes:66]
[same as prior period, unchanged from 0001564590-14-001858:notes:65]

[0001564590-14-003175:notes:67]
[same as prior period, unchanged from 0001564590-14-001858:notes:66]

[0001564590-14-003175:notes:68]
We issue restricted stock units (RSUs) to certain officers and key employees of the Company. The RSUs vest over a three-year period from their date of issuance. The fair value of the RSUs is based on the closing price of our common stock as reported on the NASDAQ Global Market (NASDAQ) on the grant dates. Typically, sixty-percent of the actual amount of the RSUs are earned based on the cumulative earnings as reported relative to the three-year performance cycle which begins October 1 of the year granted, and ranges from 0% to 150% of the target RSUs granted and the remaining of the RSUs are time-based and vest over a three-year period. At June 30, 2014, there were 132,282 RSUs outstanding. The RSUs do not have voting rights and the shares of common stock underlying the RSUs are not issued until they vest.

[0001564590-14-003175:notes:69]
[same as prior period, unchanged from 0001564590-14-001858:notes:68]

[0001564590-14-003175:notes:70]
|  | Number of |  |  | Weighted |  |
|  | Restricted |  |  | Average |  |
|  | Stock |  |  | Fair Value |  |
|  | Units |  |  | Per Share |  |
| Outstanding at September 30, 2013 |  | 81,555 |  |  | $ | 38.66 |  |
| Granted |  | 57,200 |  |  |  | 60.47 |  |
| Vested |  | (5,973) |  |  |  | 61.79 |  |
| Forfeited |  | (500) |  |  |  | 60.32 |  |
| Outstanding at June 30, 2014 |  | 132,282 |  |  | $ | 46.97 |  |

[0001564590-14-003175:notes:71]
During the nine months ended June 30, 2014 and 2013, we recorded compensation expense of $2.0 million and $2.2 million, respectively, related to the RSUs.

[0001564590-14-003175:notes:72]
[same as prior period, unchanged from 0001564590-14-001858:notes:71]

[0001564590-14-003175:notes:73]
During the nine months ended June 30, 2014 and 2013, we recorded compensation expense of $0.9 million and $1.0 million, respectively, related to restricted stock grants.


## us-gaap:FairValueDisclosuresTextBlock

[0001564590-14-003175:notes:74]
[same as prior period, unchanged from 0001564590-14-001858:notes:73]

[0001564590-14-003175:notes:75]
[same as prior period, unchanged from 0001564590-14-001858:notes:74]

[0001564590-14-003175:notes:76]
[same as prior period, unchanged from 0001564590-14-001858:notes:75]

[0001564590-14-003175:notes:77]
[same as prior period, unchanged from 0001564590-14-001858:notes:76]

[0001564590-14-003175:notes:78]
[same as prior period, unchanged from 0001564590-14-001858:notes:77]

[0001564590-14-003175:notes:79]
[same as prior period, unchanged from 0001564590-14-001858:notes:78]

[0001564590-14-003175:notes:80]
The following table summarizes the fair value of our assets and liabilities that were accounted for at fair value on a recurring basis as of June 30, 2014 (in thousands):

[0001564590-14-003175:notes:81]
|  | Fair Value Measurements at June 30, 2014 |  |
|  | Quoted Prices in |  |  | Significant Other |  |  |  |  |  |  |  |  |  |
|  | Active Markets for |  |  | Observable |  |  | Significant |  |  |  |  |  |
|  | Identical Assets |  |  | Inputs |  |  | Unobservable Inputs |  |  | Fair Value at |  |
|  | (Level 1) |  |  | (Level 2) |  |  | (Level 3) |  |  | June 30, 2014 |  |
| Assets: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cash equivalents | $ | 10,434 |  |  | $ | — |  |  | $ | — |  |  | $ | 10,434 |  |
| Total | $ | 10,434 |  |  | $ | — |  |  | $ | — |  |  | $ | 10,434 |  |

[0001564590-14-003175:notes:82]
[same as prior period, unchanged from 0001564590-14-001858:notes:81]

[0001564590-14-003175:notes:83]
|  | Fair Value Measurements at September 30, 2013 |  |
|  | Quoted Prices in |  |  | Significant Other |  |  |  |  |  |  |  |  |  |
|  | Active Markets for |  |  | Observable |  |  | Significant |  |  |  |  |  |
|  | Identical Assets |  |  | Inputs |  |  | Unobservable Inputs |  |  | Fair Value at |  |
|  | (Level 1) |  |  | (Level 2) |  |  | (Level 3) |  |  | September 30, 2013 |  |
| Assets: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cash equivalents | $ | 10,531 |  |  | $ | — |  |  | $ | — |  |  | $ | 10,531 |  |
| Total | $ | 10,531 |  |  | $ | — |  |  | $ | — |  |  | $ | 10,531 |  |

[0001564590-14-003175:notes:84]
[same as prior period, unchanged from 0001564590-14-001858:notes:83]

[0001564590-14-003175:notes:85]
[same as prior period, unchanged from 0001564590-14-001858:notes:84]

[0001564590-14-003175:notes:86]
[same as prior period, unchanged from 0001564590-14-001858:notes:85]

[0001564590-14-003175:notes:87]
Industrial Development Revenue Bond ─ The fair value of our long-term debt depends primarily on the coupon rate of our industrial development revenue bonds.  The carrying value of our long-term debt at June 30, 2014 approximates fair value based on the current coupon rate of the bonds, which is reset weekly, and is classified as a Level 2 input in the fair value measurement hierarchy as there is an active market for the trading of these industrial development revenue bonds.

[0001564590-14-003175:notes:88]
There were no transfers between levels within the fair value measurement hierarchy during the nine months ended June 30, 2014.


## us-gaap:DisposalGroupsIncludingDiscontinuedOperationsDisclosureTextBlock

[0001564590-14-003175:notes:89]
[same as prior period, unchanged from 0001564590-14-001858:notes:88]

[0001564590-14-003175:notes:90]
On January 15, 2014, we sold our wholly-owned subsidiary Transdyn to a global provider of electronic toll collection systems, headquartered in Vienna, Austria.  The purchase price from the sale of this subsidiary totaled $16.0 million, of which we received cash of $14.4 million.  The remaining $1.6 million was placed into an escrow account until April 2015, to be released subject to certain contingent obligations, and was recorded to other assets.  We received additional cash of $0.4 million after the final working capital adjustment was calculated in March 2014. We recorded a gain on this transaction of $8.6 million, net of tax, which has been included in income from discontinued operations for the nine months ended June 30, 2014 in the accompanying condensed consolidated statements of operations.  Transdyn’s results were previously reflected in the Process Control Systems business segment.

[0001564590-14-003175:notes:91]
[same as prior period, unchanged from 0001564590-14-001858:notes:90]

[0001564590-14-003175:notes:92]
[same as prior period, unchanged from 0001564590-14-001858:notes:91]

[0001564590-14-003175:notes:93]
|  | Three Months Ended |  |  | Nine Months Ended |  |
|  | June 30, |  |  | June 30, |  |
|  | 2014 |  |  | 2013 |  |  | 2014 |  |  | 2013 |  |
| Revenues | $ | — |  |  | $ | 7,786 |  |  | $ | 13,923 |  |  | $ | 22,743 |  |
| Income from discontinued operations, net of tax of $0, $206, $633 and $652, respectively |  | — |  |  |  | 222 |  |  |  | 1,041 |  |  |  | 702 |  |
| Gain on sale of discontinued operations, net of tax of $0, $0, $5,218 and $0, respectively |  | — |  |  |  | — |  |  |  | 8,563 |  |  |  | — |  |
| Net income from discontinued operations, net of tax | $ | — |  |  | $ | 222 |  |  | $ | 9,604 |  |  | $ | 702 |  |
| Earnings per share information: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic | $ | — |  |  | $ | 0.02 |  |  | $ | 0.80 |  |  | $ | 0.06 |  |
| Diluted | $ | — |  |  | $ | 0.02 |  |  | $ | 0.80 |  |  | $ | 0.06 |  |

[0001564590-14-003175:notes:94]
[same as prior period, unchanged from 0001564590-14-001858:notes:93]

[0001564590-14-003175:notes:95]
|  | September 30, 2013 |  |
| Current assets: |  |  |  |
| Cash and cash equivalents | $ | 337 |  |
| Accounts receivable |  | 7,346 |  |
| Contracts in progress |  | 7,201 |  |
| Inventories |  | 20 |  |
| Prepaid expenses and other current assets |  | 505 |  |
| Current assets held for sale | $ | 15,409 |  |
| Long-term assets: |  |  |  |
| Property, plant and equipment, net | $ | 93 |  |
| Other assets |  | 51 |  |
| Long-term assets held for sale | $ | 144 |  |
| Current liabilities: |  |  |  |
| Accounts payable | $ | 2,973 |  |
| Accrued salaries, bonuses and commissions |  | 1,675 |  |
| Billings in excess of cost |  | 11,867 |  |
| Other accrued expenses and liabilities |  | 1,333 |  |
| Current liabilities held for sale | $ | 17,848 |  |
| Long-term liabilities: |  |  |  |
| Long-term liabilities held for sale | $ | 204 |  |


## us-gaap:IncomeTaxDisclosureTextBlock

[0001564590-14-003175:notes:96]
[same as prior period, unchanged from 0001564590-14-001858:notes:95]

[0001564590-14-003175:notes:97]
|  | Three Months Ended |  |  | Nine Months Ended |  |
|  | June 30, |  |  | June 30, |  |
|  | 2014 |  |  | 2013 |  |  | 2014 |  |  | 2013 |  |
| Income from continuing operations before income taxes | $ | 5,180 |  |  | $ | 12,080 |  |  | $ | 27,416 |  |  | $ | 31,017 |  |
| Income tax provision |  | 2,233 |  |  |  | 2,997 |  |  |  | 10,226 |  |  |  | 8,211 |  |
| Income from continuing operations | $ | 2,947 |  |  | $ | 9,083 |  |  | $ | 17,190 |  |  | $ | 22,806 |  |
| Effective tax rate |  | 43 | % |  |  | 25 | % |  |  | 37 | % |  |  | 27 | % |

[0001564590-14-003175:notes:98]
Our provision for income taxes for continuing operations was $2.2 million in the third quarter of fiscal year 2014, compared to $3.0 million in the third quarter of fiscal year 2013.  The effective tax rate for the third quarter of fiscal year 2014 was 43.1% which is above the combined U.S. federal and state statutory rates primarily due to discrete tax items recognized during the quarter as well as the nondeductibility of certain executive compensation costs.  The effective tax rate for the third quarter of fiscal year 2013 was 24.8% and was favorably impacted by the utilization of loss carryforwards on Canadian income and the retroactive availability of the Federal Research and Development Tax Credit.

[0001564590-14-003175:notes:99]
Our provision for income taxes for continuing operations was $10.2 million for the nine months ended June 30, 2014, compared to $8.2 million for the nine months ended June 30, 2013.  The effective tax rate for nine months ended June 30, 2014 was 37.3% which approximates the combined U.S. federal and state statutory rates as the majority of our income is attributable to the U.S.  The effective tax rate for the nine months ended June 30, 2013 was 26.5% and was favorably impacted by the utilization of loss carryforwards on Canadian income as well as the extension of the Federal Research and Development Tax Credit.
