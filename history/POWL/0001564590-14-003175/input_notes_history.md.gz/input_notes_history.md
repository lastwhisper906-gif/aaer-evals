# POWL note change history — 0001564590-14-001858 → 0001564590-14-003175


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2014-08-06):
[0001564590-14-003175:note_history:1]
Certain customers require us to post bank letter of credit guarantees or performance bonds issued by a surety. These guarantees and performance bonds assure that we will perform under the terms of our contract. In the event of default, the counterparty may demand payment from the bank under a letter of credit or performance by the surety under a performance bond. To date, there have been no significant expenses related to either letters of credit or performance bonds for the periods reported. We were contingently liable for secured and unsecured letters of credit of $21.2 million as of June 30, 2014. We also had performance and maintenance bonds totaling $330.2 million that were outstanding, with additional bonding capacity of $269.8 million available, at June 30, 2014.
  (was, 2014-05-07, similarity 0.9881):
[0001564590-14-001858:note_history:1]
Certain customers require us to post bank letter of credit guarantees or performance bonds issued by a surety. These guarantees and performance bonds assure that we will perform under the terms of our contract. In the event of default, the counterparty may demand payment from the bank under a letter of credit or performance by the surety under a performance bond. To date, there have been no significant expenses related to either letters of credit or performance bonds for the periods reported. We were contingently liable for secured and unsecured letters of credit of $22.1 million as of March 31, 2014. We also had performance and maintenance bonds totaling $306.7 million that were outstanding, with additional bonding capacity of $293.3 million available, at March 31, 2014.

- added (2014-08-06):
[0001564590-14-003175:note_history:2]
We have an $8.5 million facility agreement (Facility Agreement) between Powell (UK) Limited and a large international bank. This Facility Agreement provides Powell (UK) the ability to enter into various guarantees, such as forward exchange contracts, currency options and performance bonds. At June 30, 2014, we had outstanding guarantees totaling $3.7 million under this Facility Agreement.  Amounts available under this Facility Agreement were $4.8 million as of June 30, 2014.

- changed (2014-08-06):
[0001564590-14-003175:note_history:3]
The Facility Agreement provides for financial covenants and customary events of default, and carries cross-default provisions with our Amended Credit Facility. If an event of default (as defined in the Facility Agreement) occurs and is continuing, per the terms and subject to the conditions set forth in the Facility Agreement, obligations outstanding under the Facility Agreement may be accelerated and may become or be declared immediately due and payable. As of June 30, 2014, we were in compliance with all of the financial covenants of the Facility Agreement.
  (was, 2014-05-07, similarity 0.8103):
[0001564590-14-001858:note_history:3]
The Facility Agreement provides for financial covenants and customary events of default, and carries cross-default provisions with our Amended Credit Facility. If an event of default (as defined in the Facility Agreement) occurs and is continuing, per the terms and subject to the conditions set forth in the Facility Agreement, obligations outstanding under the Facility Agreement may be accelerated and may become or be declared immediately due and payable. As of March 31, 2014, we were in compliance with all of the financial covenants of the Facility Agreement.  The Facility Agreement expires in July 2014.

- removed (2014-08-06):
[0001564590-14-001858:note_history:4]
We have an $8.3 million facility agreement (Facility Agreement) between S&I and a large international bank. This Facility Agreement provides S&I the ability to enter into various guarantees, such as forward exchange contracts, currency options and performance bonds. At March 31, 2014, we had outstanding guarantees totaling $3.9 million under this Facility Agreement.  Amounts available under this Facility Agreement were $4.4 million as of March 31, 2014.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureAndSignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- added (2014-08-06):
[0001564590-14-003175:note_history:5]
In May 2014, the FASB issued a new standard on revenue recognition that supersedes previously issued revenue recognition guidance.  This standard provides a five-step approach to be applied to all contracts with customers and requires expanded disclosures about the nature, amount, timing and uncertainty of revenue (and the related cash flows) arising from customer contracts, significant judgments and changes in judgments used in applying the revenue model and the assets recognized from costs incurred to obtain or fulfill a contract.  This new standard is effective for us beginning in fiscal year 2018.  Early application is not permitted. The standard permits the use of either the retrospective or cumulative effect transition method therefore we are evaluating the effect that this new guidance will have on our consolidated financial statements and related disclosures. We have not yet selected a transition method nor have we determined the effect of the standard on our ongoing financial reporting.


## us-gaap:LongTermDebtTextBlock (debt) — matched_by: tag_name, score: 1.0

- added (2014-08-06):
[0001564590-14-003175:note_history:6]
|  | June 30, |  |  | September 30, |  |
|  | 2014 |  |  | 2013 |  |
| Industrial development revenue bonds | $ | 3,200 |  |  | $ | 3,600 |  |
| Capital lease obligations |  | — |  |  |  | 16 |  |
| Subtotal long-term debt and capital lease obligations |  | 3,200 |  |  |  | 3,616 |  |
| Less current portion |  | (400 | ) |  |  | (416 | ) |
| Total long-term debt and capital lease obligations | $ | 2,800 |  |  | $ | 3,200 |  |

- changed (2014-08-06):
[0001564590-14-003175:note_history:7]
The U.S. Revolver provides for the issuance of letters of credit which reduce the amounts that may be borrowed under this revolver. The amount available under the U.S. Revolver was reduced by $21.1 million for our outstanding letters of credit at June 30, 2014.
  (was, 2014-05-07, similarity 0.9822):
[0001564590-14-001858:note_history:7]
The U.S. Revolver provides for the issuance of letters of credit which reduce the amounts that may be borrowed under this revolver. The amount available under the U.S. Revolver was reduced by $21.9 million for our outstanding letters of credit at March 31, 2014.

- changed (2014-08-06):
[0001564590-14-003175:note_history:8]
There were no borrowings outstanding under the U.S. Revolver as of June 30, 2014. Amounts available under the U.S. Revolver were $53.9 million at June 30, 2014. The U.S. Revolver expires on December 31, 2018.
  (was, 2014-05-07, similarity 0.9521):
[0001564590-14-001858:note_history:8]
There were no borrowings outstanding under the U.S. Revolver as of March 31, 2014. Amounts available under the U.S. Revolver were $53.1 million at March 31, 2014. The U.S. Revolver expires on December 31, 2018.

- changed (2014-08-06):
[0001564590-14-003175:note_history:9]
The Amended Credit Agreement is collateralized by a pledge of 100% of the voting capital stock of each of our domestic subsidiaries and 66% of the voting capital stock of each non-domestic subsidiary, excluding Powell Canada. The Amended Credit Agreement provides for customary events of default and carries cross-default provisions with other existing debt agreements. If an event of default (as defined in the Amended Credit Agreement) occurs and is continuing, on the terms and subject to the conditions set forth in the Amended Credit Agreement, amounts outstanding under the Amended Credit Agreement may be accelerated and may become immediately due and payable. As of June 30, 2014, we were in compliance with all of the financial covenants of the Amended Credit Agreement.
  (was, 2014-05-07, similarity 0.9942):
[0001564590-14-001858:note_history:9]
The Amended Credit Agreement is collateralized by a pledge of 100% of the voting capital stock of each of our domestic subsidiaries and 66% of the voting capital stock of each non-domestic subsidiary, excluding Powell Canada. The Amended Credit Agreement provides for customary events of default and carries cross-default provisions with other existing debt agreements. If an event of default (as defined in the Amended Credit Agreement) occurs and is continuing, on the terms and subject to the conditions set forth in the Amended Credit Agreement, amounts outstanding under the Amended Credit Agreement may be accelerated and may become immediately due and payable. As of March 31, 2014, we were in compliance with all of the financial covenants of the Amended Credit Agreement.

- changed (2014-08-06):
[0001564590-14-003175:note_history:10]
We have a $9.4 million credit agreement with a major international bank in Canada (the Canadian Revolver) to provide working capital support and letters of credit for our operations in Canada. The Canadian Revolver provides for the issuance of letters of credit which reduce the amounts that may be borrowed under this revolver. The amount available under the Canadian Revolver was reduced by $0.1 million for an outstanding letter of credit at June 30, 2014.
  (was, 2014-05-07, similarity 0.99):
[0001564590-14-001858:note_history:10]
We have a $9.0 million credit agreement with a major international bank in Canada (the Canadian Revolver) to provide working capital support and letters of credit for our operations in Canada. The Canadian Revolver provides for the issuance of letters of credit which reduce the amounts that may be borrowed under this revolver. The amount available under the Canadian Revolver was reduced by $0.1 million for an outstanding letter of credit at March 31, 2014.

- changed (2014-08-06):
[0001564590-14-003175:note_history:11]
There were no borrowings outstanding under the Canadian Revolver as of June 30, 2014.  Amounts available under the Canadian Revolver were $9.3 million at June 30, 2014. The Canadian Revolver expires on February 28, 2015. The interest rate for amounts outstanding under the Canadian Revolver is a floating interest rate based upon either the Canadian Prime Rate, or the lender’s Bankers’ Acceptance Rate. Once the applicable rate is determined, a margin of 0.50% to 1.75%, as determined by our consolidated leverage ratio, is added to the applicable rate.
  (was, 2014-05-07, similarity 0.983):
[0001564590-14-001858:note_history:11]
There were no borrowings outstanding under the Canadian Revolver as of March 31, 2014.  Amounts available under the Canadian Revolver were $8.9 million at March 31, 2014. The Canadian Revolver expires on February 28, 2015. The interest rate for amounts outstanding under the Canadian Revolver is a floating interest rate based upon either the Canadian Prime Rate, or the lender’s Bankers’ Acceptance Rate. Once the applicable rate is determined, a margin of 0.50% to 1.75%, as determined by our consolidated leverage ratio, is added to the applicable rate.

- changed (2014-08-06):
[0001564590-14-003175:note_history:12]
The Canadian Revolver is secured by the assets of our Canadian operations and provides for customary events of default and carries cross-default provisions with our existing debt agreements. If an event of default (as defined in the Canadian Revolver) occurs and is continuing, per the terms and subject to the conditions set forth in the Canadian Revolver, amounts outstanding under the Canadian Revolver may be accelerated and may become immediately due and payable. As of June 30, 2014, we were in compliance with all of the financial covenants of the Canadian Revolver.
  (was, 2014-05-07, similarity 0.9921):
[0001564590-14-001858:note_history:12]
The Canadian Revolver is secured by the assets of our Canadian operations and provides for customary events of default and carries cross-default provisions with our existing debt agreements. If an event of default (as defined in the Canadian Revolver) occurs and is continuing, per the terms and subject to the conditions set forth in the Canadian Revolver, amounts outstanding under the Canadian Revolver may be accelerated and may become immediately due and payable. As of March 31, 2014, we were in compliance with all of the financial covenants of the Canadian Revolver.

- changed (2014-08-06):
[0001564590-14-003175:note_history:13]
We borrowed $8.0 million in October 2001 through a loan agreement funded with proceeds from tax-exempt industrial development revenue bonds (Bonds). These Bonds were issued by the Illinois Development Finance Authority and were used for the completion of our Northlake, Illinois facility. Pursuant to the Bond issuance, a reimbursement agreement between us and a major domestic bank required an issuance by the bank of an irrevocable direct-pay letter of credit (Bond LC), as collateral, to the Bonds’ trustee to guarantee payment of the Bonds’ principal and interest when due. The Bond LC is subject to both early termination and extension provisions customary to such agreements, as well as various covenants, for which we were in compliance at June 30, 2014. While the Bonds mature in 2021, the reimbursement agreement requires annual redemptions of $0.4 million that commenced on October 25, 2002. A sinking fund is used for the redemption of the Bonds. At June 30, 2014, the balance in the restricted sinking fund was approximately $0.3 million and was recorded in cash and cash equivalents. The Bonds bear interest at a floating rate determined weekly by the Bonds’ remarketing agent, which was the underwriter for the Bonds and is an affiliate of the bank. This interest rate was 0.25% as of June 30, 2014.
  (was, 2014-05-07, similarity 0.9863):
[0001564590-14-001858:note_history:13]
We borrowed $8.0 million in October 2001 through a loan agreement funded with proceeds from tax-exempt industrial development revenue bonds (Bonds). These Bonds were issued by the Illinois Development Finance Authority and were used for the completion of our Northlake, Illinois facility. Pursuant to the Bond issuance, a reimbursement agreement between us and a major domestic bank required an issuance by the bank of an irrevocable direct-pay letter of credit (Bond LC), as collateral, to the Bonds’ trustee to guarantee payment of the Bonds’ principal and interest when due. The Bond LC is subject to both early termination and extension provisions customary to such agreements, as well as various covenants, for which we were in compliance at March 31, 2014. While the Bonds mature in 2021, the reimbursement agreement requires annual redemptions of $0.4 million that commenced on October 25, 2002. A sinking fund is used for the redemption of the Bonds. At March 31, 2014, the balance in the restricted sinking fund was approximately $0.2 million and was recorded in cash and cash equivalents. The Bonds bear interest at a floating rate determined weekly by the Bonds’ remarketing agent, which was the underwriter for the Bonds and is an affiliate of the bank. This interest rate was 0.25% as of March 31, 2014.

- removed (2014-08-06):
[0001564590-14-001858:note_history:14]
|  | March 31, |  |  | September 30, |  |
|  | 2014 |  |  | 2013 |  |
| Industrial development revenue bonds | $ | 3,200 |  |  | $ | 3,600 |  |
| Capital lease obligations |  | — |  |  |  | 16 |  |
| Subtotal long-term debt and capital lease obligations |  | 3,200 |  |  |  | 3,616 |  |
| Less current portion |  | (400 | ) |  |  | (416 | ) |
| Total long-term debt and capital lease obligations | $ | 2,800 |  |  | $ | 3,200 |  |


## us-gaap:ScheduleOfDebtInstrumentsTextBlock (debt) — matched_by: tag_name, score: 1.0

- added (2014-08-06):
[0001564590-14-003175:note_history:15]
|  | June 30, |  |  | September 30, |  |
|  | 2014 |  |  | 2013 |  |
| Industrial development revenue bonds | $ | 3,200 |  |  | $ | 3,600 |  |
| Capital lease obligations |  | — |  |  |  | 16 |  |
| Subtotal long-term debt and capital lease obligations |  | 3,200 |  |  |  | 3,616 |  |
| Less current portion |  | (400 | ) |  |  | (416 | ) |
| Total long-term debt and capital lease obligations | $ | 2,800 |  |  | $ | 3,200 |  |

- removed (2014-08-06):
[0001564590-14-001858:note_history:16]
|  | March 31, |  |  | September 30, |  |
|  | 2014 |  |  | 2013 |  |
| Industrial development revenue bonds | $ | 3,200 |  |  | $ | 3,600 |  |
| Capital lease obligations |  | — |  |  |  | 16 |  |
| Subtotal long-term debt and capital lease obligations |  | 3,200 |  |  |  | 3,616 |  |
| Less current portion |  | (400 | ) |  |  | (416 | ) |
| Total long-term debt and capital lease obligations | $ | 2,800 |  |  | $ | 3,200 |  |
