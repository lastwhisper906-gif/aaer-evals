# POWL MD&A — 0001628280-17-000997


## mdna

[0001628280-17-000997:mdna:1]
[same as prior period, unchanged from 0001564590-16-022303:mdna:1]

[0001628280-17-000997:mdna:2]
The following discussion and analysis of our financial condition and results of operations should be read in conjunction with the accompanying condensed consolidated financial statements and related notes included elsewhere in this Quarterly Report on Form 10-Q and with our Annual Report on Form 10-K for the year ended September 30, 2016 which was filed with the Securities and Exchange Commission (SEC) on December 7, 2016 and is available on the SEC’s website at www.sec.gov.

[0001628280-17-000997:mdna:3]
[same as prior period, unchanged from 0001564590-16-022303:mdna:3]

[0001628280-17-000997:mdna:4]
[same as prior period, unchanged from 0001564590-16-022303:mdna:4]

[0001628280-17-000997:mdna:5]
The markets in which we participate are capital intensive and cyclical in nature. Cyclicality is predominantly driven by customer demand, global economic conditions and anticipated environmental, safety or regulatory changes that affect the manner in which our customers proceed with capital investments. Our customers analyze various factors including the demand and price for oil, gas and electrical energy, the overall economic and financial environment, governmental budgets, regulatory actions and environmental concerns. These factors influence the release of new capital projects by our customers, which are traditionally awarded in competitive bid situations. Scheduling of projects is matched to the customer requirements and projects typically take a number of months to produce.  Schedules may change during the course of any particular project and our operating results can therefore be impacted by factors outside of our control. Due to the significant decline in oil and gas prices from late 2014 levels, many of our customers have reduced their capital budgets and cut costs, and in certain instances have delayed or cancelled projects that we were pursuing. If oil and gas markets remain depressed, or decline from current levels, our project backlog could continue to decline and negatively impact our operations for the foreseeable future. In response to our reduced project backlog and market outlook, we took steps in Fiscal 2016 to reduce our cost structure, restructure our senior management team and align our salaried and hourly workforce with future production requirements.

[0001628280-17-000997:mdna:6]
Our strategy in Canada has been to replicate our project-based integration model which allows for the design, fabrication, integration and testing of our products at a single location. This strategic initiative has presented challenges for our Canadian operations in prior years, resulting in inefficiencies that led to higher operating costs, gross margin deterioration and operating losses. We took various actions in Canada and saw improvements in our operational efficiencies beginning with the second quarter of Fiscal 2016.

[0001628280-17-000997:mdna:7]
[same as prior period, unchanged from 0001564590-16-022303:mdna:9]

[0001628280-17-000997:mdna:8]
Quarter Ended December 31, 2016 Compared to the Quarter Ended December 31, 2015 (Unaudited)

[0001628280-17-000997:mdna:9]
[same as prior period, unchanged from 0001564590-16-022303:mdna:11]

[0001628280-17-000997:mdna:10]
Revenues decreased by 26%, or $39.6 million, to $110.3 million in the first quarter of Fiscal 2017, compared to the first quarter of Fiscal 2016, primarily due to the continued decrease in our project backlog as we complete existing projects and continue to see lower demand from our customers in the oil and gas markets. Domestic revenues decreased by 19%, or $19.8 million, to $85.6 million in the first quarter of Fiscal 2017, compared to the first quarter of Fiscal 2016, and international revenues decreased by 44%, or $19.8 million, to $24.7 million in the first quarter of Fiscal 2017, compared to the first quarter of Fiscal 2016.  These decreases are due to the overall reduction in revenues year over year driven by the decline in our project backlog mentioned above. Revenues from commercial and industrial customers decreased by 35%, or $39.8 million, to $72.7 million in the first quarter of Fiscal 2017, compared to the first quarter of Fiscal 2016. Revenues from public and private utilities decreased by 42%, or $12.2 million, to $16.6 million in the first quarter of Fiscal 2017, compared to the first quarter of Fiscal 2016.  Revenues from municipal and transit projects increased by 142%, or $12.4 million, to $21.1 million in the first quarter of Fiscal 2017, compared to the first quarter of Fiscal 2016 due to the timing of transit projects and our ability to ramp up across various facilities to meet our customer schedules.

[0001628280-17-000997:mdna:11]
Gross profit for the first quarter of Fiscal 2017 decreased by 35%, or $8.2 million, to $15.0 million, compared to the first quarter of Fiscal 2016, primarily due to the decrease in revenues.  Gross profit as a percentage of revenues decreased to 14% in the first quarter of Fiscal 2017, compared to 15% in the first quarter of Fiscal 2016. Our Canadian operations experienced an increase in gross profit, which was offset by the decline in gross profit from our domestic operations. Margins were negatively impacted primarily by our reduced volume as a result of weak oil and gas market conditions and lower margins from the increased volume from our transit markets noted above.

[0001628280-17-000997:mdna:12]
[same as prior period, unchanged from 0001564590-16-022303:mdna:15]

[0001628280-17-000997:mdna:13]
Selling, general and administrative expenses decreased by 19%, or $3.7 million, to $15.7 million during the first quarter of Fiscal 2017, compared to the first quarter of Fiscal 2016, primarily due to the cost reduction efforts we took in Fiscal 2016 in response to our reduced project backlog. Selling, general and administrative expenses, as a percentage of revenues, increased to 14% during the first quarter of Fiscal 2017, compared to 13% during the first quarter of Fiscal 2016, primarily due to the reduction in revenue quarter over quarter.

[0001628280-17-000997:mdna:14]
[same as prior period, unchanged from 0001564590-16-022303:mdna:17]

[0001628280-17-000997:mdna:15]
In the first quarter of Fiscal 2017, we did not incur any restructuring or separation costs.  However, in the first quarter of Fiscal 2016, we incurred approximately $3.8 million of separation costs related to the departure of our former Chief Executive Officer in December 2015.

[0001628280-17-000997:mdna:16]
[same as prior period, unchanged from 0001564590-16-022303:mdna:19]

[0001628280-17-000997:mdna:17]
We recorded an income tax benefit of $1.4 million in the first quarter of Fiscal 2017, compared to an income tax benefit of $1.0 million in the first quarter of Fiscal 2016.  The effective tax rate for the first quarter of Fiscal 2017 was 83% compared to an effective tax rate of 70% in the first quarter of Fiscal 2016. The effective tax rates for the first quarter of Fiscal 2017 and 2016 were favorably impacted by the lower tax rate in the United Kingdom, the relative amounts of income/loss recognized in various jurisdictions, as well as the utilization of net operating loss carryforwards in Canada that are fully reserved with a valuation allowance.  We also completed an IRS audit during the first quarter of Fiscal 2017 which favorably impacted the effective tax rate due to the release of a $0.3 million FIN 48 reserve relating to the Research and Development Tax Credit (R&D Tax Credit).  The effective tax rate for the first quarter of Fiscal 2016 was also favorably impacted by a discrete item of $0.8 million related to the retroactive reinstatement of the R&D Tax Credit to January 31, 2016.

[0001628280-17-000997:mdna:18]
Net loss

[0001628280-17-000997:mdna:19]
In the first quarter of Fiscal 2017, we recorded a loss of $0.3 million, or $0.03 per diluted share compared to a loss of $0.5 million, or $0.04 per diluted share, in the first quarter of Fiscal 2016. Our decrease in selling, general and administrative costs in the first quarter of Fiscal 2017 was offset by the reduction in revenue and gross profit compared to the first quarter of Fiscal 2016 as our project backlog has declined due to depressed market conditions, primarily in our oil and gas markets.

[0001628280-17-000997:mdna:20]
[same as prior period, unchanged from 0001564590-16-022303:mdna:23]

[0001628280-17-000997:mdna:21]
The order backlog at December 31, 2016 was $271.5 million, which declined from $291.4 million at September 30, 2016.  New orders declined during the first quarter of Fiscal 2017 to $90.8 million, compared to $101.8 million in the first quarter of Fiscal 2016, primarily due to lower demand from our customers in the oil and gas markets.

[0001628280-17-000997:mdna:22]
[same as prior period, unchanged from 0001564590-16-022303:mdna:43]

[0001628280-17-000997:mdna:23]
Cash,  cash equivalents and short-term investments  decreased to $95.5 million at December 31, 2016, compared to $97.7 million at September 30, 2016.  As of December 31, 2016, current assets exceeded current liabilities by 2.9 times and our debt to total capitalization was 0.60%.

[0001628280-17-000997:mdna:24]
We have a $75.0 million revolving credit facility in the U.S., which expires in December 2018. As of December 31, 2016, there were no amounts borrowed under this line of credit. We also have a $7.4 million revolving credit facility in Canada, and as of December 31, 2016 there were no amounts borrowed under this line of credit. Total letters of credit outstanding under our U.S. credit facility, which reduce our availability, were $20.3 million at December 31, 2016 and $26.8 million at September 30, 2016. There were no letters of credit outstanding under the Canadian revolving credit facility at December 31, 2016 or September 30, 2016. Amounts available at December 31, 2016 under the U.S. and Canadian revolving credit facilities were $54.7 million and $7.4 million, respectively.  Total long-term debt, including current maturities, totaled $2.0 million at December 31, 2016, compared to $2.4 million at September 30, 2016. For further information regarding our debt, see Notes E and F of Notes to Condensed Consolidated Financial Statements.

[0001628280-17-000997:mdna:25]
Approximately $31 million of our cash at December 31, 2016, was held outside of the United States for international operations. It is our intention to indefinitely reinvest all current and future foreign earnings internationally in order to ensure sufficient working capital to support our international operations.  In the event that we elect to repatriate some or all of the foreign earnings that were

[0001628280-17-000997:mdna:26]
previously deemed to be indefinitely reinvested outside the U.S., under current tax laws we would incur additional tax expense upon such repatriation.

[0001628280-17-000997:mdna:27]
We believe that cash and short-term investments available and borrowing capacity under our existing credit facilities should be sufficient to finance future operating activities, capital improvements and debt repayments for the foreseeable future. We continue to monitor the factors that drive our markets and will continue to strive to maintain our leadership and competitive advantage in the markets we serve while aligning our cost structures with market conditions.

[0001628280-17-000997:mdna:28]
[same as prior period, unchanged from 0001564590-16-022303:mdna:48]

[0001628280-17-000997:mdna:29]
Cash provided by operating activities decreased to $3.4 million for the three months ended December 31, 2016, compared to cash provided by operating activities of $24.1 million during the same period in Fiscal 2016. This decrease in operating cash flow in the first quarter of Fiscal 2017 was primarily from increased incentive compensation payments in the first quarter of Fiscal 2017 and a decrease in cash flow from the collection of project milestone billings compared to the same period in Fiscal 2016. Cash flow from operations is primarily influenced by the timing of milestone payments from our customers and the payment terms with our suppliers.

[0001628280-17-000997:mdna:30]
[same as prior period, unchanged from 0001564590-16-022303:mdna:50]

[0001628280-17-000997:mdna:31]
Net cash used in investing activities during the three months ended December 31, 2016 totaled $15.8 million compared to $0.6 million during the same period in Fiscal 2016.  For the three months ended December 31, 2016, we invested $14.9 million in short-term investments and spent approximately $0.9 million on purchases of property, plant and equipment.  For the three months ended December 31, 2015, we spent approximately $0.6 million on purchases of property, plant and equipment.

[0001628280-17-000997:mdna:32]
[same as prior period, unchanged from 0001564590-16-022303:mdna:52]

[0001628280-17-000997:mdna:33]
Net cash used in financing activities was $3.8 million for the three months ended December 31, 2016 and $7.9 million during the same period in Fiscal 2016.  This reduction was primarily due to the completion of our share repurchase program in December 2015 discussed below.

[0001628280-17-000997:mdna:34]
[same as prior period, unchanged from 0001564590-16-022303:mdna:54]

[0001628280-17-000997:mdna:35]
[same as prior period, unchanged from 0001564590-16-022303:mdna:55]

[0001628280-17-000997:mdna:36]
[same as prior period, unchanged from 0001564590-16-022303:mdna:56]

[0001628280-17-000997:mdna:37]
[same as prior period, unchanged from 0001564590-16-022303:mdna:57]

[0001628280-17-000997:mdna:38]
[same as prior period, unchanged from 0001564590-16-022303:mdna:58]

[0001628280-17-000997:mdna:39]
[same as prior period, unchanged from 0001564590-16-022303:mdna:59]

[0001628280-17-000997:mdna:40]
There have been no material changes to our critical accounting policies as disclosed in our Annual Report on Form 10-K for the year ended September 30, 2016.

[0001628280-17-000997:mdna:41]
[same as prior period, unchanged from 0001564590-16-022303:mdna:61]

[0001628280-17-000997:mdna:42]
The markets in which we participate are capital-intensive and cyclical in nature. Cyclicality is predominantly driven by customer demand, global economic conditions and anticipated environmental or regulatory changes which affect the manner in which our customers proceed with capital investments. Our customers analyze various factors including the demand and price for oil, gas and electrical energy, the overall economic and financial environment, governmental budgets, regulatory actions and environmental concerns. These factors influence the release of new capital projects by our customers, which are traditionally awarded in competitive bid situations. Scheduling of projects is matched to customer requirements.  Projects typically take a number of months to produce, and schedules may change during the course of any particular project.

[0001628280-17-000997:mdna:43]
A significant portion of our revenues have historically been from the oil and gas markets. Unfavorable long-term oil and gas commodity price levels have caused, and may continue to cause, our customers to change their strategies or delay or cancel planned projects. The reduction in available projects, across the markets we serve, has increased market price pressures during this downward market cycle. This reduction in new business opportunities and increased market price pressures have impacted, and will continue to negatively impact, our backlog, revenues and operating results. It is difficult to predict how long the current depressed market cycle will continue.

[0001628280-17-000997:mdna:44]
Our operating results have been, and may continue to be, negatively impacted by factors such as the timing of new order awards, customer approval of final engineering and design specifications and delays in customer construction schedules, all of which have and may continue to have, a negative impact on the timing of project execution. Our operating results also have been, and may continue to be, impacted by the timing and resolution of change orders, project close-out and resolution of potential contract claims, all of which could improve or deteriorate gross margins during the period in which these items are resolved with our customers. These factors may result in periods of underutilization of our resources and facilities and negatively impact our ability to cover our fixed costs. If oil and gas markets remain depressed, or decline further, our project backlog could continue to decline  and negatively impact our operations for the foreseeable future. In response to our reduced project backlog and market outlook, we took steps in Fiscal 2016 to reduce our cost structure, restructure our senior management team and align our salaried and hourly workforce with future production requirements. However, these efforts, and any future efforts, will not be sufficient to avoid operating losses in the near-term.

[0001628280-17-000997:mdna:45]
We believe that our strong working capital position, cash available, low debt position and borrowing capacity under our existing credit facilities should be sufficient to finance future operating activities, research and development initiatives, capital improvements and debt repayments for the foreseeable future. We continue to monitor the factors that drive our markets and will continue to strive to maintain our leadership and competitive advantage in the markets we serve while aligning our cost structures with market conditions.
