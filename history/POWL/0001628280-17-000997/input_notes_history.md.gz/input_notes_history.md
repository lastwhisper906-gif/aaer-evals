# POWL note change history — 0001564590-16-022303 → 0001628280-17-000997


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2017-02-08):
[0001628280-17-000997:note_history:1]
COMMITMENTS AND CONTINGENCIES
  (was, 2016-08-03, similarity 0.9508):
[0001564590-16-022303:note_history:1]
F. COMMITMENTS AND CONTINGENCIES

- changed (2017-02-08):
[0001628280-17-000997:note_history:2]
Certain customers require us to post bank letter of credit guarantees or surety bonds. These guarantees and surety bonds assure that we will perform under the terms of our contract. In the event of default, the counterparty may demand payment from the bank under a letter of credit or performance by the surety under a bond. To date, there have been no significant expenses related to either letters of credit or surety bonds for the periods reported. We were contingently liable for secured and unsecured letters of credit of $20.3 million as of December 31, 2016. We also had surety bonds totaling $229.4 million that were outstanding, with additional bonding capacity of $520.6 million available, at December 31, 2016.
  (was, 2016-08-03, similarity 0.9827):
[0001564590-16-022303:note_history:2]
Certain customers require us to post bank letter of credit guarantees or surety bonds. These guarantees and surety bonds assure that we will perform under the terms of our contract. In the event of default, the counterparty may demand payment from the bank under a letter of credit or performance by the surety under a bond. To date, there have been no significant expenses related to either letters of credit or surety bonds for the periods reported. We were contingently liable for secured and unsecured letters of credit of $26.8 million as of June 30, 2016. We also had surety bonds totaling $233.0 million that were outstanding, with additional bonding capacity of $517.0 million available, at June 30, 2016.

- added (2017-02-08):
[0001628280-17-000997:note_history:3]
We have a $6.2 million facility agreement (Facility Agreement) between Powell (UK) Limited and a large international bank. This Facility Agreement provides Powell (UK) Limited the ability to enter into bank guarantees as well as forward exchange contracts and currency options. At December 31, 2016, we had outstanding guarantees totaling $4.8 million under this Facility Agreement and amounts available under this Facility Agreement were $1.4 million.  This facility expires in May 2017. The Facility Agreement provides for financial covenants and customary events of default, and carries cross-default provisions with our U.S. Revolver. If an event of default (as defined in the Facility Agreement) occurs and is continuing, per the terms and subject to the conditions set forth therein, obligations outstanding under the Facility Agreement may be accelerated and may become or be declared immediately due and payable. As of December 31, 2016, we were in compliance with all of the financial covenants of the Facility Agreement.

- changed (2017-02-08):
[0001628280-17-000997:note_history:4]
Certain of our customer contracts have schedule and performance obligation clauses that, if we fail to meet them, could require us to pay liquidated damages. Each individual contract defines the conditions under which the customer may make a claim against us. As of December 31, 2016, our exposure to possible liquidated damages was $2.7 million, of which approximately $1.7 million is probable.  Based on our actual or projected failure to meet these various contractual commitments, $1.5 million has been recorded as a reduction to revenue. We will attempt to obtain change orders, contract extensions or accelerate project completion which may resolve the potential for any unaccrued liquidated damage. Should we fail to achieve relief on some or all of these contractual obligations, we could be required to pay additional liquidated damages, which could negatively impact our future operating results.
  (was, 2016-08-03, similarity 0.6478):
[0001564590-16-022303:note_history:4]
Certain of our customer contracts have schedule and performance obligation clauses that, if we fail to meet them, could require us to pay liquidated damages.  Each individual contract defines the conditions under which the customer may make a claim against us.  As of June 30, 2016, our exposure to possible liquidated damages was $7.4 million, of which approximately $1.7 million is estimated to be probable.  Based on our actual or projected failure to meet these various contractual commitments, $1.7 million has been recorded as a reduction to revenue.  We will attempt to obtain change orders or contract extensions that may resolve the potential for any unaccrued liquidated damage.  Should we fail to achieve relief on some or all of these contractual obligations, we could be required to pay additional liquidated damages, which could negatively impact our future operating results.

- removed (2017-02-08):
[0001564590-16-022303:note_history:5]
We have a $9.4 million facility agreement (Facility Agreement) between Powell (UK) Limited and a large international bank. This Facility Agreement provides Powell (UK) Limited the ability to enter into bank guarantees as well as forward exchange contracts and currency options. At June 30, 2016, we had outstanding guarantees totaling $3.0 million under this Facility Agreement and amounts available under this Facility Agreement were $6.4 million.  This facility expires in November 2016. The Facility Agreement provides for financial covenants and customary events of default, and carries cross-default provisions with our Amended Credit Agreement. If an event of default (as defined in the Facility Agreement) occurs and is continuing, per the terms and subject to the conditions set forth therein, obligations outstanding under the Facility Agreement may be accelerated and may become or be declared immediately due and payable. As of June 30, 2016, we were in compliance with all of the financial covenants of the Facility Agreement.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureAndSignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2017-02-08):
[0001628280-17-000997:note_history:6]
OVERVIEW AND SUMMARY OF SIGNIFICANT ACCOUNTING POLICIES
  (was, 2016-08-03, similarity 0.9735):
[0001564590-16-022303:note_history:6]
A. OVERVIEW AND SUMMARY OF SIGNIFICANT ACCOUNTING POLICIES

- changed (2017-02-08):
[0001628280-17-000997:note_history:7]
The preparation of condensed consolidated financial statements in conformity with U.S. GAAP requires management to make estimates and assumptions that affect the amounts reported in the condensed consolidated financial statements and accompanying footnotes. The most significant estimates used in our condensed consolidated financial statements affect revenue and cost recognition for construction contracts, the allowance for doubtful accounts, provision for excess and obsolete inventory, self-insurance, warranty accruals, liquidated damages and income taxes. The amounts recorded for insurance claims, warranties, legal, liquidated damages, income taxes and other contingent liabilities require judgments regarding the amount of expenses that will ultimately be incurred. We base our estimates on historical experience and on various other assumptions, as well as the specific circumstances surrounding these contingent liabilities, in evaluating the amount of liability that should be recorded. Additionally, the recognition of deferred tax assets requires estimates related to future income and other assumptions regarding timing and future profitability. Estimates may change as new events occur, additional information becomes available or operating environments change. Actual results may differ from our estimates.
  (was, 2016-08-03, similarity 0.6632):
[0001564590-16-022303:note_history:7]
The preparation of condensed consolidated financial statements in conformity with U.S. GAAP requires management to make estimates and assumptions that affect the amounts reported in the condensed consolidated financial statements and accompanying footnotes as of the date they were prepared. The most significant estimates used in our financial statements affect revenue and cost recognition for contracts, allowance for doubtful accounts, provision for excess and obsolete inventory, goodwill and intangible assets, self-insurance, warranty accruals, liquidated damages and income taxes. The amounts recorded in the condensed consolidated financial statements require judgments that could change in future periods and actual amounts may differ from those recorded in the condensed consolidated financial statements. We base our estimates on historical experience and on various other assumptions, as well as the specific circumstances surrounding contingent liabilities, in evaluating the amount of liability that should be recorded. Additionally, the recognition of deferred tax assets, and our determination of whether the value of our long-lived assets has been impaired, requires estimates related to future income and other assumptions regarding timing and future profitability.  Estimates may change as new events occur, additional information becomes available or operating conditions change.

- added (2017-02-08):
[0001628280-17-000997:note_history:8]
In May 2014, the Financial Accounting Standards Board (FASB) issued a new standard on revenue recognition that supersedes previously issued revenue recognition guidance. This standard provides a five-step approach to be applied to all contracts with customers and requires expanded disclosures about the nature, amount, timing and uncertainty of revenue (and the related cash flows) arising from customer contracts, significant judgments and changes in judgments used in applying the revenue model and the assets recognized from costs incurred to obtain or fulfill a contract. This guidance is now effective for fiscal years, and interim periods within those years, beginning after December 15, 2017, which would be our fiscal year ending September 30, 2019. The standard permits the use of either the full retrospective or modified retrospective transition method; therefore, we are evaluating the effect that this new guidance will have on our consolidated financial statements and related disclosures. We have not yet selected a transition method nor have we determined the effect of the standard on our ongoing financial reporting.

- added (2017-02-08):
[0001628280-17-000997:note_history:9]
In August 2014, the FASB issued guidance to address the diversity in practice in determining when there is substantial doubt about an entity’s ability to continue as a going concern and when and how an entity must disclose certain relevant conditions and events. This update requires an entity to evaluate whether there are conditions or events, considered in the aggregate, that raise substantial doubt about the entity’s ability to continue as a going concern for a period of one year after the date that the financial statements are issued (or available to be issued). If such conditions or events exist, an entity should disclose that there is substantial doubt about the entity’s ability to continue as a going concern for a period of one year after the date that the financial statements are issued (or available to be issued), along with the principal conditions or events that raise substantial doubt, management’s evaluation of the significance of those conditions or events in relation to the entity’s ability to meet its obligations and management’s plans that are intended to mitigate those conditions or events. This guidance impacts the disclosure and presentation of any substantial doubt about our ability to continue as a going concern, if such substantial doubt were to exist. This guidance is effective for our first quarter ended December 31, 2016 and does not have an impact on disclosures in our condensed consolidated financial statements.

- changed (2017-02-08):
[0001628280-17-000997:note_history:10]
In February 2016, the FASB issued a new topic on leases which requires lessees to recognize lease assets and lease liabilities on the balance sheet for all leases with terms longer than twelve months. Leases will be classified as either finance or operating, with classification affecting the pattern of expense recognition in the income statement. A modified retrospective transition approach is required for lessees for capital and operating leases existing at, or entered into after, the beginning of the earliest comparative period presented in the financial statements, with certain practical expedients available. The new standard is effective for fiscal years beginning after December 15, 2018, including interim periods within those fiscal years. This would be our fiscal year ending September 30, 2020.  We are currently evaluating the impact of our pending adoption of the new standard, but do not expect it to have a material impact on our consolidated financial position or results of operations.
  (was, 2016-08-03, similarity 0.9752):
[0001564590-16-022303:note_history:10]
In February 2016, the FASB issued a new topic on leases which requires lessees to recognize lease assets and lease liabilities on the balance sheet for all leases with terms longer than twelve months.  Leases will be classified as either finance or operating, with classification affecting the pattern of expense recognition in the income statement.  A modified retrospective transition approach is required for lessees for capital and operating leases existing at, or entered into after, the beginning of the earliest comparative period presented in the financial statements, with certain practical expedients available. The new standard is effective for fiscal years beginning after December 15, 2018, including interim periods within those fiscal years. This would be our fiscal year ending September 30, 2020.  We are currently evaluating the impact of our pending adoption of the new standard on our consolidated financial position or results of operations.

- added (2017-02-08):
[0001628280-17-000997:note_history:11]
In March 2016, the FASB issued new guidance on stock-based compensation, which includes amendments to existing guidance for employee share-based payment accounting. We elected to early adopt this new guidance in the first quarter of Fiscal 2017.  Beginning with this quarter, stock-based compensation excess tax benefits or deficiencies are reflected in the Condensed Consolidated Statement of Operations as a component of income taxes, whereas they were previously recorded in additional paid in capital in the Condensed Consolidated Statement of Stockholders’ Equity.  Additionally, we will now present excess tax benefits as an operating activity in the Condensed Consolidated Statements of Cash Flows, and prior periods will be adjusted accordingly.  Finally, we will continue to account for forfeitures as they occur, rather than estimate expected forfeitures.

- removed (2017-02-08):
[0001564590-16-022303:note_history:12]
In May 2014, the FASB issued a new standard on revenue recognition that supersedes previously issued revenue recognition guidance.  This standard provides a five-step approach to be applied to all contracts with customers and requires expanded disclosures about the nature, amount, timing and uncertainty of revenue (and the related cash flows) arising from customer contracts, significant judgments and changes in judgments used in applying the revenue model and the assets recognized from costs incurred to obtain or fulfill a contract.  This guidance is now effective for fiscal years, and interim periods within those years, beginning after December 15, 2017, which would be our fiscal year ending September 30, 2019.  The standard permits the use of either the retrospective or cumulative effect transition method; therefore, we are evaluating the effect that this new guidance will have on our consolidated financial statements and related disclosures. We have not yet selected a transition method nor have we determined the effect of the standard on our ongoing financial reporting.

- removed (2017-02-08):
[0001564590-16-022303:note_history:13]
In July 2015, the FASB issued a new topic on simplifying the measurement of inventory.  The current standard is to measure inventory at lower of cost or market; where market could be replacement cost, net realizable value, or net realizable value less an approximate normal profit margin. This topic updates this guidance to measure inventory at the lower of cost and net realizable value; where net realizable value is the estimated selling prices in the ordinary course of business, less reasonably predictable costs of completion, disposal, and transportation. This update is effective for annual reporting periods beginning after December 15, 2016, which would be our fiscal year ending September 30, 2018.  The amendments should be applied prospectively with earlier application permitted as of the beginning of an interim or annual reporting period. This topic is not expected to have a material impact on our consolidated financial position or results of operations.

- removed (2017-02-08):
[0001564590-16-022303:note_history:14]
In March 2016, the FASB issued new guidance on stock-based compensation. The new guidance simplifies several aspects of the accounting for share-based payment transactions, including the income tax consequences, classification of awards as either equity or liabilities, and classification on the statement of cash flows. For public companies, the amendments in this standard are effective for annual periods beginning after December 15, 2016, including interim periods within those annual periods.  This would be our fiscal year ending September 30, 2018.  The adoption of this guidance is not expected to have a material impact on our consolidated financial position, results of operations or cash flows.


## us-gaap:LongTermDebtTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2017-02-08):
[0001628280-17-000997:note_history:15]
LONG-TERM DEBT
  (was, 2016-08-03, similarity 0.9032):
[0001564590-16-022303:note_history:15]
E. LONG-TERM DEBT

- added (2017-02-08):
[0001628280-17-000997:note_history:16]
|  | December 31 2016 |  | September 30 2016 |
| Industrial development revenue bonds | $ | 2,000 |  |  | $ | 2,400 |  |
| Less current portion | (400 | ) |  | (400 | ) |
| Total long-term debt and capital lease obligations | $ | 1,600 |  |  | $ | 2,000 |  |

- added (2017-02-08):
[0001628280-17-000997:note_history:17]
We have a $75.0 million revolving credit facility (U.S. Revolver) to provide working capital support and letters of credit. The interest rate for amounts outstanding under the U.S. Revolver is a floating rate based upon the higher of the Federal Funds Rate plus 0.5%, the bank’s prime rate, or the Eurocurrency rate plus 1.00%. Once the applicable rate is determined, a margin ranging up to 1.75%, as determined by our consolidated leverage ratio, is added to the applicable rate. The U.S. Revolver provides for the issuance of letters of credit which reduce the amounts that may be borrowed under this revolver. The amount available under the U.S. Revolver was reduced by $20.3 million for our outstanding letters of credit at December 31, 2016.

- changed (2017-02-08):
[0001628280-17-000997:note_history:18]
There were no borrowings outstanding under the U.S. Revolver as of December 31, 2016.  Amounts available under the U.S. Revolver were $54.7 million at December 31, 2016. The U.S. Revolver expires on December 31, 2018.
  (was, 2016-08-03, similarity 0.9476):
[0001564590-16-022303:note_history:18]
There were no borrowings outstanding under the U.S. Revolver as of June 30, 2016.  Amounts available under the U.S. Revolver were $48.2 million at June 30, 2016. The U.S. Revolver expires on December 31, 2018.

- changed (2017-02-08):
[0001628280-17-000997:note_history:19]
The U.S. Revolver contains certain restrictive and maintenance-type covenants, such as restrictions on the amount of capital expenditures allowed. It also contains financial covenants defining various financial measures and the levels of these measures with which we must comply, as well as a “material adverse change” clause. A “material adverse change” is defined as a material change in our operations, business, properties, liabilities or condition (financial or otherwise) or a material impairment of our ability to perform our obligations under our credit agreements.
  (was, 2016-08-03, similarity 0.968):
[0001564590-16-022303:note_history:19]
The Amended Credit Agreement contains certain restrictive and maintenance-type covenants, such as restrictions on the amount of capital expenditures allowed. It also contains financial covenants defining various financial measures and the levels of these measures with which we must comply, as well as a “material adverse change” clause. A “material adverse change” is defined as a material change in our operations, business, properties, liabilities or condition (financial or otherwise) or a material impairment of our ability to perform our obligations under our credit agreements.

- added (2017-02-08):
[0001628280-17-000997:note_history:20]
The U.S. Revolver is collateralized by a pledge of 100% of the voting capital stock of each of our domestic subsidiaries and 65% of the voting capital stock of each non-domestic subsidiary, excluding Powell Canada Inc. The U.S. Revolver provides for customary events of default and carries cross-default provisions with other existing debt agreements. If an event of default (as defined in the U.S. Revolver) occurs and is continuing, on the terms and subject to the conditions set forth in the U.S. Revolver, amounts outstanding under the U.S. Revolver may be accelerated and may become immediately due and payable. As of December 31, 2016, we were in compliance with all of the financial covenants of the U.S. Revolver.

- changed (2017-02-08):
[0001628280-17-000997:note_history:21]
We have a $7.4 million credit agreement with a major international bank in Canada (the Canadian Revolver) to provide working capital support and letters of credit for our operations in Canada. The Canadian Revolver provides for the issuance of letters of credit which reduce the amounts that may be borrowed under this revolver. There were no outstanding letters of credit under the Canadian Revolver at December 31, 2016. The interest rate for amounts outstanding under the Canadian Revolver is a floating interest rate based upon either the Canadian Prime Rate, or the lender’s Bankers’ Acceptance Rate. Once the applicable rate is determined, a margin of 0.50% to 1.75%, as determined by our consolidated leverage ratio, is added to the applicable rate.
  (was, 2016-08-03, similarity 0.7049):
[0001564590-16-022303:note_history:21]
We have a $7.7 million credit agreement with a major international bank in Canada (the Canadian Revolver) to provide working capital support and letters of credit for our operations in Canada. The Canadian Revolver provides for the issuance of letters of credit which reduce the amounts that may be borrowed under this revolver.  There were no outstanding letters of credit under the Canadian Revolver at June 30, 2016.

- added (2017-02-08):
[0001628280-17-000997:note_history:22]
There were no borrowings outstanding under the Canadian Revolver as of December 31, 2016 and amounts available under the Canadian Revolver were $7.4 million at December 31, 2016. The Canadian Revolver expires on March 31, 2018.

- changed (2017-02-08):
[0001628280-17-000997:note_history:23]
The principal financial covenants are consistent with those described in our U.S. Revolver. The Canadian Revolver contains a “material adverse effect” clause. A “material adverse effect” is defined as a material change in the operations of Powell or Powell Canada Inc. in relation to our financial condition, property, business operations, expected net cash flows, liabilities or capitalization.
  (was, 2016-08-03, similarity 0.9538):
[0001564590-16-022303:note_history:23]
The principal financial covenants are consistent with those described in our Amended Credit Agreement. The Canadian Revolver contains a “material adverse effect” clause. A “material adverse effect” is defined as a material change in the operations of Powell or Powell Canada Inc. in relation to our financial condition, property, business operations, expected net cash flows, liabilities or capitalization.

- changed (2017-02-08):
[0001628280-17-000997:note_history:24]
The Canadian Revolver is secured by the assets of our Canadian operations and provides for customary events of default and carries cross-default provisions with our existing debt agreements. If an event of default (as defined in the Canadian Revolver) occurs and is continuing, per the terms and subject to the conditions set forth in the Canadian Revolver, amounts outstanding under the Canadian Revolver may be accelerated and may become immediately due and payable. As of December 31, 2016, we were in compliance with all of the financial covenants of the Canadian Revolver.
  (was, 2016-08-03, similarity 0.9895):
[0001564590-16-022303:note_history:24]
The Canadian Revolver is secured by the assets of our Canadian operations and provides for customary events of default and carries cross-default provisions with our existing debt agreements. If an event of default (as defined in the Canadian Revolver) occurs and is continuing, per the terms and subject to the conditions set forth in the Canadian Revolver, amounts outstanding under the Canadian Revolver may be accelerated and may become immediately due and payable. As of June 30, 2016, we were in compliance with all of the financial covenants of the Canadian Revolver.

- changed (2017-02-08):
[0001628280-17-000997:note_history:25]
We borrowed $8.0 million in October 2001 through a loan agreement funded with proceeds from tax-exempt industrial development revenue bonds (Bonds). These Bonds were issued by the Illinois Development Finance Authority and were used for the completion of our Northlake, Illinois facility. Pursuant to the Bond issuance, a reimbursement agreement between us and a major domestic bank required an issuance by the bank of an irrevocable direct-pay letter of credit (Bond LC), as collateral, to the Bonds’ trustee to guarantee payment of the Bonds’ principal and interest when due. The Bond LC is subject to both early termination and extension provisions customary to such agreements, as well as various covenants, for which we were in compliance at December 31, 2016. While the Bonds mature in 2021, the reimbursement agreement requires annual redemptions of $0.4 million that commenced on October 25, 2002. A sinking fund is used for the redemption of the Bonds. The Bonds bear interest at a floating rate determined weekly by the Bonds’ remarketing agent, which was the underwriter for the Bonds and is an affiliate of the bank. This interest rate was 0.90% as of December 31, 2016.
  (was, 2016-08-03, similarity 0.9895):
[0001564590-16-022303:note_history:25]
We borrowed $8.0 million in October 2001 through a loan agreement funded with proceeds from tax-exempt industrial development revenue bonds (Bonds). These Bonds were issued by the Illinois Development Finance Authority and were used for the completion of our Northlake, Illinois facility. Pursuant to the Bond issuance, a reimbursement agreement between us and a major domestic bank required an issuance by the bank of an irrevocable direct-pay letter of credit (Bond LC), as collateral, to the Bonds’ trustee to guarantee payment of the Bonds’ principal and interest when due. The Bond LC is subject to both early termination and extension provisions customary to such agreements, as well as various covenants, for which we were in compliance at June 30, 2016. While the Bonds mature in 2021, the reimbursement agreement requires annual redemptions of $0.4 million that commenced on October 25, 2002. A sinking fund is used for the redemption of the Bonds. The Bonds bear interest at a floating rate determined weekly by the Bonds’ remarketing agent, which was the underwriter for the Bonds and is an affiliate of the bank. This interest rate was 0.58% as of June 30, 2016.

- removed (2017-02-08):
[0001564590-16-022303:note_history:26]
|  | June 30, 2016 |  |  | September 30, 2015 |  |
| Industrial development revenue bonds | $ | 2,400 |  |  | $ | 2,800 |  |
| Less current portion |  | (400 | ) |  |  | (400 | ) |
| Total long-term debt and capital lease obligations | $ | 2,000 |  |  | $ | 2,400 |  |

- removed (2017-02-08):
[0001564590-16-022303:note_history:27]
In Fiscal 2015, we entered into the Second Amendment (the Second Amendment) of our existing amended and restated credit agreement (as amended, the Amended Credit Agreement).  The Second Amendment provided for the expansion of our Canadian manufacturing facility and allowed for the repurchase of our common stock pursuant to a share repurchase program announced in December 2014.  The Amended Credit Agreement provides for a $75.0 million revolving credit facility (U.S. Revolver).

- removed (2017-02-08):
[0001564590-16-022303:note_history:28]
The interest rate for amounts outstanding under the Amended Credit Agreement for the U.S. Revolver is a floating rate based upon the higher of the Federal Funds Rate plus 0.5%, the bank’s prime rate, or the Eurocurrency rate plus 1.00%. Once the applicable rate is determined, a margin ranging up to 1.75%, as determined by our consolidated leverage ratio, is added to the applicable rate.

- removed (2017-02-08):
[0001564590-16-022303:note_history:29]
The U.S. Revolver provides for the issuance of letters of credit which reduce the amounts that may be borrowed under this revolver. The amount available under the U.S. Revolver was reduced by $26.8 million for our outstanding letters of credit at June 30, 2016.

- removed (2017-02-08):
[0001564590-16-022303:note_history:30]
The Amended Credit Agreement is collateralized by a pledge of 100% of the voting capital stock of each of our domestic subsidiaries and 65% of the voting capital stock of each non-domestic subsidiary, excluding Powell Canada Inc. The Amended Credit Agreement provides for customary events of default and carries cross-default provisions with other existing debt agreements. If an event of default (as defined in the Amended Credit Agreement) occurs and is continuing, on the terms and subject to the conditions set forth in the Amended Credit Agreement, amounts outstanding under the Amended Credit Agreement may be accelerated and may become immediately due and payable. As of June 30, 2016, we were in compliance with all of the financial covenants of the Amended Credit Agreement.

- removed (2017-02-08):
[0001564590-16-022303:note_history:31]
There were no borrowings outstanding under the Canadian Revolver as of June 30, 2016 and amounts available under the Canadian Revolver were $7.7 million at June 30, 2016.  The interest rate for amounts outstanding under the Canadian Revolver is a floating interest rate based upon either the Canadian Prime Rate, or the lender’s Bankers’ Acceptance Rate. Once the applicable rate is determined, a margin of 0.50% to 1.75%, as determined by our consolidated leverage ratio, is added to the applicable rate. The Canadian Revolver expires on March 31, 2018.


## us-gaap:ScheduleOfDebtInstrumentsTextBlock (debt) — matched_by: tag_name, score: 1.0

- added (2017-02-08):
[0001628280-17-000997:note_history:32]
|  | December 31 2016 |  | September 30 2016 |
| Industrial development revenue bonds | $ | 2,000 |  |  | $ | 2,400 |  |
| Less current portion | (400 | ) |  | (400 | ) |
| Total long-term debt and capital lease obligations | $ | 1,600 |  |  | $ | 2,000 |  |

- removed (2017-02-08):
[0001564590-16-022303:note_history:33]
|  | June 30, 2016 |  |  | September 30, 2015 |  |
| Industrial development revenue bonds | $ | 2,400 |  |  | $ | 2,800 |  |
| Less current portion |  | (400 | ) |  |  | (400 | ) |
| Total long-term debt and capital lease obligations | $ | 2,000 |  |  | $ | 2,400 |  |
