# POWL MD&A — 0001564590-16-012239


## mdna

[0001564590-16-012239:mdna:1]
[same as prior period, unchanged from 0001564590-15-006239:mdna:1]

[0001564590-16-012239:mdna:2]
The following discussion and analysis of our financial condition and results of operations should be read in conjunction with the accompanying condensed consolidated financial statements and related notes included elsewhere in this Quarterly Report on Form 10-Q and with our Annual Report on Form 10-K for the year ended September 30, 2015 which was filed with the Securities and Exchange Commission (SEC) on December 2, 2015 and is available on the SEC’s website at www.sec.gov.

[0001564590-16-012239:mdna:3]
[same as prior period, unchanged from 0001564590-15-006239:mdna:3]

[0001564590-16-012239:mdna:4]
We develop, design, manufacture and service custom-engineered equipment and systems for the distribution, control and monitoring of electrical energy. Headquartered in Houston, Texas, we serve the oil and gas refining, offshore oil and gas production, petrochemical, pipeline, terminal, mining and metals, light rail traction power, electric utility, pulp and paper and other industrial markets. Revenues and costs are primarily related to custom engineered-to-order equipment and systems and accounted for under percentage-of-completion accounting which precludes us from providing detailed price and volume information. Our backlog includes various projects, some of which are petrochemical, oil and gas construction and transportation infrastructure projects which take a number of months to produce.

[0001564590-16-012239:mdna:5]
The markets in which we participate are capital intensive and cyclical in nature. Cyclicality is predominantly driven by customer demand, global economic conditions and anticipated environmental or regulatory changes which affect the manner in which our customers proceed with capital investments. Our customers analyze various factors including the demand and price for oil, gas and electrical energy, the overall economic and financial environment, governmental budgets, regulatory actions and environmental concerns. These factors influence the release of new capital projects by our customers, which are traditionally awarded in competitive bid situations. Scheduling of projects is matched to the customer requirements and projects may take a number of months to produce; but schedules may change during the course of any particular project. Our operating results can be impacted by factors outside of our control.

[0001564590-16-012239:mdna:6]
During Fiscal 2015, our operating results were negatively impacted by operational inefficiencies resulting from increased volume and project scheduling delays. Our inability to meet contractual commitments on existing projects, as well as delays in customer construction schedules, negatively impacted the timing and costs related to project execution.  These factors resulted in an imbalance of our factory resources with our customer commitments, resulting in higher production costs due to inefficiencies.  Our operating results were, and may continue to be, negatively impacted by the timing and resolution of change orders, project close-out and resolution of potential liquidated damage claims, all of which impact gross margins during the period in which these items are resolved with our customers.

[0001564590-16-012239:mdna:7]
Our strategy in Canada has been to replicate our U.S. project-based integration model which allows for the design, fabrication, integration and testing of our products at a single location.  This strategic initiative presented challenges for our Canadian operations over the last two years resulting in inefficiencies that led to higher operating costs, gross margin deterioration and operating losses.  We have taken various actions which have improved our operational efficiencies in Canada this quarter.

[0001564590-16-012239:mdna:8]
[same as prior period, unchanged from 0001564590-15-006239:mdna:9]

[0001564590-16-012239:mdna:9]
[same as prior period, unchanged from 0001564590-15-006239:mdna:11]

[0001564590-16-012239:mdna:10]
Revenues decreased by 2%, or $2.6 million, to $150.0 million in the first quarter of Fiscal 2016, compared to the first quarter of Fiscal 2015, primarily due to the decrease in our project backlog entering Fiscal 2016. Domestic revenues increased by 9%, or $8.5 million, to $105.4 million in the first quarter of Fiscal 2016, compared to the first quarter of Fiscal 2015, and international revenues decreased by 20%, or $11.1 million, to $44.5 million in the first quarter of Fiscal 2016, compared to the first quarter of Fiscal 2015 due to the reduced number of large projects in our overseas markets year over year. Revenues from commercial and industrial customers decreased $10.0 million to $112.5 million in the first quarter of Fiscal 2016, compared to the first quarter of Fiscal 2015. Revenues from public and private utilities increased $4.3 million to $28.8 million in the first quarter of Fiscal 2016, compared to the first quarter of Fiscal 2015.  Revenues from municipal and transit projects increased $3.1 million to $8.7 million in the first quarter of Fiscal 2016, compared to the first quarter of Fiscal 2015.

[0001564590-16-012239:mdna:11]
Gross profit for the first quarter of Fiscal 2016 increased 10%, or $2.1 million, to $23.2 million, compared to the first quarter of Fiscal 2015.  Gross profit as a percentage of revenues increased to 15% in the first quarter of Fiscal 2016, compared to 14% in the first quarter of Fiscal 2015, primarily due to improvements at our Canadian operations, as well as the overall mix of project types. Our improvement in Canada was partially offset by unfavorable project costs from a municipal transit project.

[0001564590-16-012239:mdna:12]
[same as prior period, unchanged from 0001564590-15-006239:mdna:15]

[0001564590-16-012239:mdna:13]
Selling, general and administrative expenses decreased $1.4 million to $19.4 million during the first quarter of Fiscal 2016 when compared to the first quarter of Fiscal 2015 partially due to cost reduction efforts.  Selling, general and administrative expenses, as a

[0001564590-16-012239:mdna:14]
percentage of revenues, decreased slightly to 13% during the first quarter of Fiscal 2016, compared to 14% during the first quarter of Fiscal 2015 as we have begun to align our spending with current market conditions.

[0001564590-16-012239:mdna:15]
[same as prior period, unchanged from 0001564590-15-006239:mdna:17]

[0001564590-16-012239:mdna:16]
In the first quarter of Fiscal 2016, we incurred $3.8 million of restructuring and separation costs associated with the departure of our former Chief Executive Officer on December 24, 2015, which includes stock-based compensation expense of approximately $1.8 million.   We did not incur any restructuring or separation costs in the first quarter of Fiscal 2015.

[0001564590-16-012239:mdna:17]
[same as prior period, unchanged from 0001564590-15-006239:mdna:21]

[0001564590-16-012239:mdna:18]
We recorded a benefit for income taxes of $1.0 million in the first quarter of Fiscal 2016 and Fiscal 2015.  The effective tax rate for the first quarter of Fiscal 2016 was 70% compared to an effective tax rate of 81% in the first quarter of Fiscal 2015, primarily due to our inability to recognize a tax benefit on the Canadian loss incurred in the first quarter of Fiscal 2016 while a tax benefit related to the Canadian loss was recognized in the first quarter of Fiscal 2015. Additionally, our income tax benefits were favorably impacted in the first quarters of Fiscal 2016 and Fiscal 2015 by the retroactive reinstatement of the Federal Research and Development Tax Credit.

[0001564590-16-012239:mdna:19]
Net loss

[0001564590-16-012239:mdna:20]
In the first quarter of Fiscal 2016, we recorded a loss of $0.5 million, or $0.04 per diluted share compared to a loss of $0.2 million, or $0.02 per diluted share, in the first quarter of Fiscal 2015. Our improvement in gross profit in Fiscal 2016 was offset by the $3.8 million of separation costs.

[0001564590-16-012239:mdna:21]
[same as prior period, unchanged from 0001564590-15-006239:mdna:25]

[0001564590-16-012239:mdna:22]
The order backlog at December 31, 2015 was $390.8 million, which declined from $441.4 million at September 30, 2015.  New orders declined during the first quarter of Fiscal 2016 to $101.8 million, compared to $154.4 million in the first quarter of Fiscal 2015, primarily due to the continued decline in oil and gas markets.

[0001564590-16-012239:mdna:23]
[same as prior period, unchanged from 0001564590-15-006239:mdna:45]

[0001564590-16-012239:mdna:24]
Cash and cash equivalents increased to $58.9 million at December 31, 2015, compared to $43.6 million at September 30, 2015.  As of December 31, 2015, current assets exceeded current liabilities by 2.4 times and our debt to total capitalization was 0.73%.

[0001564590-16-012239:mdna:25]
We have a $75.0 million revolving credit facility in the U.S., which expires in December 2018. As of December 31, 2015, there were no amounts borrowed under this line of credit. We also have a $7.2 million revolving credit facility in Canada. At December 31, 2015, there was no balance outstanding under the Canadian revolving credit facility. Total long-term debt, including current maturities, totaled $2.4 million at December 31, 2015, compared to $2.8 million at September 30, 2015. Total letters of credit outstanding were $21.6 million at December 31, 2015 and $21.1 million at September 30, 2015, which reduced our availability under our U.S. credit facility. Amounts available at December 31, 2015 under the U.S. and Canadian revolving credit facilities were $53.4 million and $7.2 million, respectively.  For further information regarding our debt, see Notes E and F of Notes to Condensed Consolidated Financial Statements.

[0001564590-16-012239:mdna:26]
Approximately $21.0 million of our cash at December 31, 2015, was held outside of the United States for international operations. It is our intention to indefinitely reinvest all current and future foreign earnings internationally in order to ensure sufficient working capital to support and expand these international operations.  In the event that we elect to repatriate some or all of the foreign earnings that were previously deemed to be indefinitely reinvested outside the U.S., under current tax laws we would incur additional tax expense upon such repatriation.

[0001564590-16-012239:mdna:27]
We believe that cash available and borrowing capacity under our existing credit facilities should be sufficient to finance future operating activities, capital improvements and debt repayments for the foreseeable future. We continue to monitor the factors that drive our markets and will continue to strive to maintain our leadership and competitive advantage in the markets we serve while aligning our cost structures with market conditions.

[0001564590-16-012239:mdna:28]
[same as prior period, unchanged from 0001564590-15-006239:mdna:50]

[0001564590-16-012239:mdna:29]
Cash provided by operating activities was $24.1 million during the first quarter of Fiscal 2016, compared to cash used in operating activities of $22.7 million during the first quarter of Fiscal 2015.  This change was primarily due to the reduction in accounts receivable since September 30, 2015. Cash flow from operations is primarily influenced by the timing of milestone payments from our customers and the payment terms with our suppliers.

[0001564590-16-012239:mdna:30]
[same as prior period, unchanged from 0001564590-15-006239:mdna:52]

[0001564590-16-012239:mdna:31]
Purchases of property, plant and equipment during the first quarter of Fiscal 2016 totaled $0.6 million compared to $19.0 million during the first quarter of Fiscal 2015.  In the first quarter of Fiscal 2015, we were completing the expansion of our Canadian facilities.

[0001564590-16-012239:mdna:32]
[same as prior period, unchanged from 0001564590-15-006239:mdna:54]

[0001564590-16-012239:mdna:33]
Net cash used in financing activities was $7.9 million during the first quarter of Fiscal 2016 and $4.0 million during the first quarter of Fiscal 2015.  This increase was primarily due to the $3.7 million of cash used for the share repurchase program discussed below.

[0001564590-16-012239:mdna:34]
[same as prior period, unchanged from 0001564590-15-006239:mdna:56]

[0001564590-16-012239:mdna:35]
On December 17, 2014, our Board of Directors authorized a share repurchase program which allowed us to repurchase up to $25 million of our outstanding stock.  The purchases were made from time to time in the open market, through privately negotiated transactions and Rule 10b5-1 trading plans in accordance with applicable laws, rules and regulations.  The Repurchase Program was funded from cash on hand and cash provided by operating activities.  The Repurchase Program expired on December 31, 2015.  As of December 31, 2015, we had purchased 806,018 shares at an aggregate cost of $25 million under the Repurchase Program.  The average purchase price per share since inception of the program was $31.02.

[0001564590-16-012239:mdna:36]
[same as prior period, unchanged from 0001564590-15-006239:mdna:58]

[0001564590-16-012239:mdna:37]
[same as prior period, unchanged from 0001564590-15-006239:mdna:59]

[0001564590-16-012239:mdna:38]
[same as prior period, unchanged from 0001564590-15-006239:mdna:60]

[0001564590-16-012239:mdna:39]
[same as prior period, unchanged from 0001564590-15-006239:mdna:61]

[0001564590-16-012239:mdna:40]
There have been no material changes to our critical accounting policies as disclosed in our Annual Report on Form 10-K for the year ended September 30, 2015.

[0001564590-16-012239:mdna:41]
[same as prior period, unchanged from 0001564590-15-006239:mdna:63]

[0001564590-16-012239:mdna:42]
The markets in which we participate are capital-intensive and cyclical in nature. Cyclicality is predominantly driven by customer demand, global economic conditions and anticipated environmental or regulatory changes which affect the manner in which our customers proceed with capital investments. Our customers analyze various factors including the demand and price for oil, gas and electrical energy, the overall economic and financial environment, governmental budgets, regulatory actions and environmental concerns. These factors influence the release of new capital projects by our customers, which are traditionally awarded in competitive bid situations. Scheduling of projects is matched to the customer requirements and projects may take a number of months to produce, but schedules may change during the course of any particular project.

[0001564590-16-012239:mdna:43]
A significant portion of our revenues have historically been from the oil and gas markets.  Unfavorable long-term commodity price levels can cause oil and gas companies to change their strategies or delay or cancel projects.  Due to the precipitous decline in oil and gas prices over the past eighteen months, many of our customers have reduced their capital budgets and cut costs, and in certain instances have deferred or cancelled projects that we were pursuing.  We believe that sustained lower oil and gas prices from a continued global supply/demand imbalance will negatively impact future orders due to reduced capital spending by our customers which may result in project deferrals and cancellations. The reduction in available projects, across the markets we serve, will increase market price pressures during this downward cycle. This reduction in new business opportunities and increased market price pressures will negatively impact our revenues, backlog, operating results and cash flows from operations.  If commodity prices do not improve, or they continue to decline, the number of projects in our markets could further decline.  We will continue to monitor our cost structure and strategic objectives and continue to take actions to align our resources and facilities with expected production requirements.

[0001564590-16-012239:mdna:44]
Our operating results have been, and may continue to be, negatively impacted by factors such as the timing of new order awards, customer approval of final engineering and design specifications and delays in customer construction schedules, all of which have and may continue to have, a negative impact on the timing of project execution.  These factors have resulted, and may continue to result in,

[0001564590-16-012239:mdna:45]
periods when our factory resources are not in balance with our customers’ scheduling requirements, resulting in higher production costs due to inefficiencies.  Our operating results also have been, and may continue to be, impacted by the timing and resolution of change orders, project close-out and resolution of potential contract claims, all of which could improve or deteriorate gross margins during the period in which these items are resolved with our customers.

[0001564590-16-012239:mdna:46]
Our strategy in Canada has been to replicate our U.S. project-based integration model which allows for the design, fabrication, integration and testing of our products at a single location.  This strategic initiative has presented challenges for our Canadian operations over the last two years resulting in inefficiencies that led to higher operating costs, gross margin deterioration and operating losses.  We have taken various actions which have improved our operational efficiencies in Canada this quarter.  We anticipate that the long-term demand for our solutions in the Canadian oil and gas markets will continue to be a contributor to this strategy.

[0001564590-16-012239:mdna:47]
We believe that cash available and borrowing capacity under our existing credit facilities should be sufficient to finance future operating activities, capital improvements and debt repayments for the foreseeable future. We continue to monitor the factors that drive our markets and will continue to strive to maintain our leadership and competitive advantage in the markets we serve while aligning our cost structures with market conditions.
