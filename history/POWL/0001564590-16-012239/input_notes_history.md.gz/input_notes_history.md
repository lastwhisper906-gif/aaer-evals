# POWL note change history — 0001564590-15-006239 → 0001564590-16-012239


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2016-02-03):
[0001564590-16-012239:note_history:1]
Certain customers require us to post bank letter of credit guarantees or performance bonds issued by a surety. These guarantees and performance bonds assure that we will perform under the terms of our contract. In the event of default, the counterparty may demand payment from the bank under a letter of credit or performance by the surety under a performance bond. To date, there have been no significant expenses related to either letters of credit or performance bonds for the periods reported. We were contingently liable for secured and unsecured letters of credit of $21.6 million as of December 31, 2015. We also had performance and maintenance bonds totaling $307.5 million that were outstanding, with additional bonding capacity of $442.5 million available, at December 31, 2015.
  (was, 2015-08-05, similarity 0.9842):
[0001564590-15-006239:note_history:1]
Certain customers require us to post bank letter of credit guarantees or performance bonds issued by a surety. These guarantees and performance bonds assure that we will perform under the terms of our contract. In the event of default, the counterparty may demand payment from the bank under a letter of credit or performance by the surety under a performance bond. To date, there have been no significant expenses related to either letters of credit or performance bonds for the periods reported. We were contingently liable for secured and unsecured letters of credit of $18.1 million as of June 30, 2015. We also had performance and maintenance bonds totaling $303.2 million that were outstanding, with additional bonding capacity of $446.8 million available, at June 30, 2015.

- changed (2016-02-03):
[0001564590-16-012239:note_history:2]
We have a $14.8 million facility agreement (Facility Agreement) between Powell (UK) Limited and a large international bank. This Facility Agreement provides Powell (UK) the ability to enter into bank guarantees as well as forward exchange contracts and currency options. At December 31, 2015, we had outstanding guarantees totaling $3.0 million under this Facility Agreement and amounts available under this Facility Agreement were $11.8 million.  This facility is renewable in May 2016.
  (was, 2015-08-05, similarity 0.6262):
[0001564590-15-006239:note_history:2]
We have a $15.7 million facility agreement (Facility Agreement) between Powell (UK) Limited and a large international bank. This Facility Agreement provides Powell (UK) the ability to enter into bank guarantees as well as forward exchange contracts and currency options. At June 30, 2015, we had outstanding guarantees totaling $6.4 million under this Facility Agreement.  Amounts available under this Facility Agreement were $9.3 million as of June 30, 2015.

- changed (2016-02-03):
[0001564590-16-012239:note_history:3]
The Facility Agreement provides for financial covenants and customary events of default, and carries cross-default provisions with our Amended Credit Facility. If an event of default (as defined in the Facility Agreement) occurs and is continuing, per the terms and subject to the conditions set forth therein, obligations outstanding under the Facility Agreement may be accelerated and may become or be declared immediately due and payable. As of December 31, 2015, we were in compliance with all of the financial covenants of the Facility Agreement.
  (was, 2015-08-05, similarity 0.9601):
[0001564590-15-006239:note_history:3]
The Facility Agreement provides for financial covenants and customary events of default, and carries cross-default provisions with our Amended Credit Facility. If an event of default (as defined in the Facility Agreement) occurs and is continuing, per the terms and subject to the conditions set forth in the Facility Agreement, obligations outstanding under the Facility Agreement may be accelerated and may become or be declared immediately due and payable. As of June 30, 2015, we were in compliance with all of the financial covenants of the Facility Agreement.

- changed (2016-02-03):
[0001564590-16-012239:note_history:4]
We are involved in various legal proceedings, claims and other disputes arising from our commercial operations, projects, employees and other matters which, in general, are subject to uncertainties and in which the outcomes are not predictable. Although we can give no assurances about the resolution of pending claims, litigation or other disputes and the effect such outcomes may have on us, management believes that any ultimate liability resulting from the outcome of such proceedings, to the extent not otherwise provided or covered by insurance, will not have a material adverse effect on our consolidated financial position or results of operations or liquidity.
  (was, 2015-08-05, similarity 0.8438):
[0001564590-15-006239:note_history:4]
We are involved in various legal proceedings, claims and other disputes arising in the ordinary course of business which, in general, are subject to uncertainties and in which the outcomes are not predictable. Although we can give no assurance about the outcome of pending or threatened litigation and the effect such outcomes may have on us, management believes that any ultimate liability resulting from the outcome of such proceedings, to the extent not otherwise provided or covered by insurance, will not have a material adverse effect on our consolidated financial position or results of operations or liquidity.

- added (2016-02-03):
[0001564590-16-012239:note_history:5]
Certain of our customer contracts have schedule and performance obligation clauses that, if we fail to meet them, could subject us to liquidated damages.  Each individual contract defines the conditions under which the customer may make a claim against us.  As of December 31, 2015, our exposure to possible liquidated damages is $7.5 million, of which approximately $2.2 million is probable.  Based on our actual or projected failure to meet these various contractual commitments, $1.7 million has been recorded against revenue in our statement of operations.  We believe that we will be successful in obtaining change orders or contract extensions that should resolve the potential for any unaccrued liquidated damages; however, should we fail to achieve relief on some or all of these contractual obligations, we could be subject to additional liquidated damages which could impact our future operating results.

- removed (2016-02-03):
[0001564590-15-006239:note_history:6]
Certain of our customer contracts have schedule and performance obligation clauses that, if we fail to meet them, could subject us to liquidated damages.  Each individual contract defines the conditions under which the customer may make a claim against us.  We have had potential exposure for liquidated damages in the past, but in most instances they were not asserted by the customer.  As of June 30, 2015, our exposure to possible liquidated damages is $6.7 million, of which approximately $2.0 million is probable.  Based on our actual or projected failure to meet these various contractual commitments, $0.8 million has been recorded in our financial statements.  We believe that we will be successful in obtaining change orders or contract extensions that should resolve the potential for any unaccrued liquidated damages; however, should we fail to achieve relief on some or all of these contractual obligations, we could be subject to additional liquidated damages which could impact our future operating results.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureAndSignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- added (2016-02-03):
[0001564590-16-012239:note_history:7]
We develop, design, manufacture and service custom-engineered equipment and systems for the distribution, control and monitoring of electrical energy. Headquartered in Houston, Texas, we serve the oil and gas refining, offshore oil and gas production, petrochemical, pipeline, terminal, mining and metals, light rail traction power, electric utility, pulp and paper and other industrial markets.

- changed (2016-02-03):
[0001564590-16-012239:note_history:8]
The preparation of financial statements in conformity with U.S. GAAP requires management to make estimates and assumptions that affect the amounts reported in the consolidated financial statements and accompanying footnotes. The most significant estimates used in our financial statements affect revenue and cost recognition for construction contracts, the allowance for doubtful accounts, provision for excess and obsolete inventory, goodwill and intangible assets, self-insurance, warranty accruals, liquidated damages and income taxes. The amounts recorded for insurance claims, warranties, legal, liquidated damages, income taxes and other contingent liabilities require judgments regarding the amount of expenses that will ultimately be incurred. We base our estimates on historical experience and on various other assumptions, as well as the specific circumstances surrounding these contingent liabilities, in evaluating the amount of liability that should be recorded. Additionally, the recognition of deferred tax assets requires estimates related to future income and other assumptions regarding timing and future profitability.  Estimates may change as new events occur, additional information becomes available or operating environments change. Actual results may differ from our estimates.
  (was, 2015-08-05, similarity 0.9244):
[0001564590-15-006239:note_history:8]
The preparation of financial statements in conformity with U.S. GAAP requires management to make estimates and assumptions that affect the amounts reported in the consolidated financial statements and accompanying footnotes. The most significant estimates used in our financial statements affect revenue and cost recognition for construction contracts, the allowance for doubtful accounts, provision for excess and obsolete inventory, goodwill and other intangible assets, self-insurance, warranty accruals and income taxes. The amounts recorded for insurance claims, warranties, legal, income taxes and other contingent liabilities require judgments regarding the amount of expenses that will ultimately be incurred. We base our estimates on historical experience and on various other assumptions, as well as the specific circumstances surrounding these contingent liabilities, in evaluating the amount of liability that should be recorded. Additionally, the recognition of deferred tax assets requires estimates related to future income and other assumptions regarding timing and future profitability.  Estimates may change as new events occur, additional information becomes available or operating environments change. Actual results may differ from our estimates.

- added (2016-02-03):
[0001564590-16-012239:note_history:9]
In May 2014, the FASB issued a new standard on revenue recognition that supersedes previously issued revenue recognition guidance.  This standard provides a five-step approach to be applied to all contracts with customers and requires expanded disclosures about the nature, amount, timing and uncertainty of revenue (and the related cash flows) arising from customer contracts, significant judgments and changes in judgments used in applying the revenue model and the assets recognized from costs incurred to obtain or fulfill a contract.  This guidance is now effective for fiscal years, and interim periods within those years, beginning after December 15, 2017, which would be our fiscal year ending September 30, 2019.  The standard permits the use of either the retrospective or cumulative effect transition method therefore we are evaluating the effect that this new guidance will have on our consolidated financial statements and related disclosures. We have not yet selected a transition method nor have we determined the effect of the standard on our ongoing financial reporting.

- added (2016-02-03):
[0001564590-16-012239:note_history:10]
In July 2015, the FASB issued a new topic on simplifying the measurement of inventory.  The current standard is to measure inventory at lower of cost or market; where market could be replacement cost, net realizable value, or net realizable value less an approximately normal profit margin. This topic updates this guidance to measure inventory at the lower of cost and net realizable value; where net realizable value is the estimated selling prices in the ordinary course of business, less reasonably predictable costs of completion, disposal, and transportation. This update is effective for annual reporting periods beginning after December 15, 2016, which would be our fiscal year ending September 30, 2018.  The amendments should be applied prospectively with earlier application permitted as of the beginning of an interim or annual reporting period. This topic is not expected to have a material impact on our consolidated financial position or results of operations.

- added (2016-02-03):
[0001564590-16-012239:note_history:11]
In November 2015, the FASB issued an amendment to the topic regarding income taxes which requires an entity to separate deferred income tax liabilities and assets into current and noncurrent amounts in the statement of financial position.  Deferred tax liabilities and assets are classified as current or noncurrent based on the classification of the related asset or liability for financial reporting.  Deferred tax liabilities and assets that are not related to an asset or liability for financial reporting are classified according to the expected reversal date of the temporary difference.  To simplify the presentation of deferred income taxes, the amendments require that deferred income tax liabilities and assets be classified as noncurrent in a classified statement of financial position.  This amendment is effective for us beginning with fiscal year 2018 and we have no plans for early adoption.  The adoption of t his guidance is not expected to have a material impact on our consolidated financial position or results of operations.

- removed (2016-02-03):
[0001564590-15-006239:note_history:12]
We develop, design, manufacture and service custom-engineered equipment and systems for the distribution, control and monitoring of electrical energy designed to (1) distribute, monitor and control the flow of electrical energy and (2) provide protection to motors, transformers and other electrically powered equipment. Headquartered in Houston, Texas, we serve the transportation, energy, industrial and utility industries.

- removed (2016-02-03):
[0001564590-15-006239:note_history:13]
In July 2013, the FASB issued accounting guidance on the presentation of an unrecognized tax benefit when a net operating loss carryforward, a similar tax loss, or a tax credit carryforward exists. The guidance states that an unrecognized tax benefit, or a portion of an unrecognized tax benefit, should be presented in the financial statements as a reduction to a deferred tax asset for a net operating loss carryforward, a similar tax loss, or a tax credit carryforward. To the extent a net operating loss carryforward, a similar tax loss, or a tax credit carryforward is not available at the reporting date under the tax law of the applicable jurisdiction to settle any additional income taxes that would result from the disallowance of a tax position or the tax law of the applicable jurisdiction does not require the entity to use, and the entity does not intend to use, the deferred tax asset for such purpose, the unrecognized tax benefit should be presented in the financial statements as a liability and should not be combined with deferred tax assets. This guidance is effective for fiscal years, and interim periods within those years, beginning after December 15, 2013, which would be our fiscal year ending September 30, 2015. This guidance should be applied prospectively to all unrecognized tax benefits that exist at the effective date. Retrospective application is permitted. The adoption of this guidance has not had a significant impact on our consolidated financial position or results of operations.

- removed (2016-02-03):
[0001564590-15-006239:note_history:14]
In April 2014, the FASB issued an amendment to the financial reporting of discontinued operations.  The amendments in this update changed the criteria for reporting discontinued operations while enhancing disclosures in this area. It also addresses sources of confusion and inconsistent application related to the financial reporting of discontinued operations guidance in U.S. GAAP.  Under the new guidance, only disposals representing a strategic shift in operations that have a major effect on the organization’s operations and financial results should be presented as discontinued operations. Examples include a disposal of a major geographic area, a major line of business, or a major equity method investment.  In addition, the new guidance requires expanded disclosures about discontinued operations that will provide financial statement users with more information about the assets, liabilities, income, and expenses of discontinued operations.  The new guidance also requires disclosure of the pre-tax income attributable to a disposal of a significant part of an organization that does not qualify for discontinued operations reporting. This disclosure will provide users with information about the ongoing trends in a reporting organization’s results from continuing operations. The amendments in this update are effective in the first quarter of 2015, which would be in our fiscal year ending September 30, 2016.  Early adoption is permitted for disposals that have not been previously reported as discontinued operations. This amendment is not expected to have a material impact on our consolidated financial position or results of operations.

- removed (2016-02-03):
[0001564590-15-006239:note_history:15]
In May 2014, the FASB issued a new standard on revenue recognition that supersedes previously issued revenue recognition guidance.  This standard provides a five-step approach to be applied to all contracts with customers and requires expanded disclosures about the nature, amount, timing and uncertainty of revenue (and the related cash flows) arising from customer contracts, significant judgments and changes in judgments used in applying the revenue model and the assets recognized from costs incurred to obtain or fulfill a contract.  The effective date for this standard was deferred in July 2015 and will now be effective for us beginning in fiscal year 2019.  The standard permits the use of either the retrospective or cumulative effect transition method therefore we are evaluating the effect that this new guidance will have on our consolidated financial statements and related disclosures. We have not yet selected a transition method nor have we determined the effect of the standard on our ongoing financial reporting.

- removed (2016-02-03):
[0001564590-15-006239:note_history:16]
Discontinued operations

- removed (2016-02-03):
[0001564590-15-006239:note_history:17]
In January 2014, we sold our wholly owned subsidiary Transdyn Inc. (Transdyn).  For the nine months ended June 30, 2014, we have presented the results of these operations as income from discontinued operations, net of tax.  See Note J.


## us-gaap:LongTermDebtTextBlock (debt) — matched_by: tag_name, score: 1.0

- added (2016-02-03):
[0001564590-16-012239:note_history:18]
|  | December 31, 2015 |  |  | September 30, 2015 |  |
| Industrial development revenue bonds......................................... | $ | 2,400 |  |  | $ | 2,800 |  |
| Less current portion..................................................... |  | (400 | ) |  |  | (400 | ) |
| Total long-term debt and capital lease obligations............................... | $ | 2,000 |  |  | $ | 2,400 |  |

- changed (2016-02-03):
[0001564590-16-012239:note_history:19]
In Fiscal 2014, we amended and restated our existing credit agreement (the Amended Credit Agreement) with a major domestic bank. In Fiscal 2015, we entered into the Second Amendment of the Amended Credit Agreement (the Second Amendment).  The Second Amendment provided for the expansion of our Canadian manufacturing facility and allowed for the repurchase of our common stock pursuant to a share repurchase program announced in December 2014.  The Amended Credit Agreement provides for a $75.0 million revolving credit facility (U.S. Revolver). Obligations are collateralized by the stock of certain of our subsidiaries.
  (was, 2015-08-05, similarity 0.9727):
[0001564590-15-006239:note_history:19]
In December 2013, we amended and restated our existing credit agreement (the Amended Credit Agreement) with a major domestic bank.  In December 2014, we entered into the Second Amendment of the Amended Credit Agreement (the Second Amendment).  The Second Amendment provides for the expansion of our Canadian manufacturing facility and allows for the repurchase of our common stock pursuant to a share repurchase program announced in December 2014. The Amended Credit Agreement provides for a $75.0 million revolving credit facility (U.S. Revolver). Obligations are collateralized by the stock of certain of our subsidiaries.

- changed (2016-02-03):
[0001564590-16-012239:note_history:20]
The U.S. Revolver provides for the issuance of letters of credit which reduce the amounts that may be borrowed under this revolver. The amount available under the U.S. Revolver was reduced by $21.6 million for our outstanding letters of credit at December 31, 2015.
  (was, 2015-08-05, similarity 0.9764):
[0001564590-15-006239:note_history:20]
The U.S. Revolver provides for the issuance of letters of credit which reduce the amounts that may be borrowed under this revolver. The amount available under the U.S. Revolver was reduced by $18.1 million for our outstanding letters of credit at June 30, 2015.

- changed (2016-02-03):
[0001564590-16-012239:note_history:21]
There were no borrowings outstanding under the U.S. Revolver as of December 31, 2015.  Amounts available under the U.S. Revolver were $53.4 million at December 31, 2015. The U.S. Revolver expires on December 31, 2018.
  (was, 2015-08-05, similarity 0.9476):
[0001564590-15-006239:note_history:21]
There were no borrowings outstanding under the U.S. Revolver as of June 30, 2015.  Amounts available under the U.S. Revolver were $56.9 million at June 30, 2015. The U.S. Revolver expires on December 31, 2018.

- changed (2016-02-03):
[0001564590-16-012239:note_history:22]
The Amended Credit Agreement is collateralized by a pledge of 100% of the voting capital stock of each of our domestic subsidiaries and 65% of the voting capital stock of each non-domestic subsidiary, excluding Powell Canada. The Amended Credit Agreement provides for customary events of default and carries cross-default provisions with other existing debt agreements. If an event of default (as defined in the Amended Credit Agreement) occurs and is continuing, on the terms and subject to the conditions set forth in the Amended Credit Agreement, amounts outstanding under the Amended Credit Agreement may be accelerated and may become immediately due and payable. As of December 31, 2015, we were in compliance with all of the financial covenants of the Amended Credit Agreement.
  (was, 2015-08-05, similarity 0.9922):
[0001564590-15-006239:note_history:22]
The Amended Credit Agreement is collateralized by a pledge of 100% of the voting capital stock of each of our domestic subsidiaries and 65% of the voting capital stock of each non-domestic subsidiary, excluding Powell Canada. The Amended Credit Agreement provides for customary events of default and carries cross-default provisions with other existing debt agreements. If an event of default (as defined in the Amended Credit Agreement) occurs and is continuing, on the terms and subject to the conditions set forth in the Amended Credit Agreement, amounts outstanding under the Amended Credit Agreement may be accelerated and may become immediately due and payable. As of June 30, 2015, we were in compliance with all of the financial covenants of the Amended Credit Agreement.

- added (2016-02-03):
[0001564590-16-012239:note_history:23]
We have a $7.2 million credit agreement with a major international bank in Canada (the Canadian Revolver) to provide working capital support and letters of credit for our operations in Canada. The Canadian Revolver provides for the issuance of letters of credit which reduce the amounts that may be borrowed under this revolver.  There were no outstanding letters of credit under the Canadian Revolver at December 31, 2015.

- changed (2016-02-03):
[0001564590-16-012239:note_history:24]
There were no borrowings outstanding under the Canadian Revolver as of December 31, 2015 and amounts available under the Canadian Revolver were $7.2 million at December 31, 2015.  The interest rate for amounts outstanding under the Canadian Revolver is a floating interest rate based upon either the Canadian Prime Rate, or the lender’s Bankers’ Acceptance Rate. Once the applicable rate is determined, a margin of 0.50% to 1.75%, as determined by our consolidated leverage ratio, is added to the applicable rate. The Canadian Revolver expires on March 31, 2018.
  (was, 2015-08-05, similarity 0.9344):
[0001564590-15-006239:note_history:24]
There were no borrowings outstanding under the Canadian Revolver as of June 30, 2015 and amounts available under the Canadian Revolver were $8.1 million at June 30, 2015. The interest rate for amounts outstanding under the Canadian Revolver is a floating interest rate based upon either the Canadian Prime Rate, or the lender’s Bankers’ Acceptance Rate. Once the applicable rate is determined, a margin of 0.50% to 1.75%, as determined by our consolidated leverage ratio, is added to the applicable rate.

- changed (2016-02-03):
[0001564590-16-012239:note_history:25]
The Canadian Revolver is secured by the assets of our Canadian operations and provides for customary events of default and carries cross-default provisions with our existing debt agreements. If an event of default (as defined in the Canadian Revolver) occurs and is continuing, per the terms and subject to the conditions set forth in the Canadian Revolver, amounts outstanding under the Canadian Revolver may be accelerated and may become immediately due and payable. As of December 31, 2015, we were in compliance with all of the financial covenants of the Canadian Revolver.
  (was, 2015-08-05, similarity 0.9895):
[0001564590-15-006239:note_history:25]
The Canadian Revolver is secured by the assets of our Canadian operations and provides for customary events of default and carries cross-default provisions with our existing debt agreements. If an event of default (as defined in the Canadian Revolver) occurs and is continuing, per the terms and subject to the conditions set forth in the Canadian Revolver, amounts outstanding under the Canadian Revolver may be accelerated and may become immediately due and payable. As of June 30, 2015, we were in compliance with all of the financial covenants of the Canadian Revolver.

- changed (2016-02-03):
[0001564590-16-012239:note_history:26]
We borrowed $8.0 million in October 2001 through a loan agreement funded with proceeds from tax-exempt industrial development revenue bonds (Bonds). These Bonds were issued by the Illinois Development Finance Authority and were used for the completion of our Northlake, Illinois facility. Pursuant to the Bond issuance, a reimbursement agreement between us and a major domestic bank required an issuance by the bank of an irrevocable direct-pay letter of credit (Bond LC), as collateral, to the Bonds’ trustee to guarantee payment of the Bonds’ principal and interest when due. The Bond LC is subject to both early termination and extension provisions customary to such agreements, as well as various covenants, for which we were in compliance at December 31, 2015. While the Bonds mature in 2021, the reimbursement agreement requires annual redemptions of $0.4 million that commenced on October 25, 2002. A sinking fund is used for the redemption of the Bonds. The Bonds bear interest at a floating rate determined weekly by the Bonds’ remarketing agent, which was the underwriter for the Bonds and is an affiliate of the bank. This interest rate was 0.15% as of December 31, 2015.
  (was, 2015-08-05, similarity 0.9327):
[0001564590-15-006239:note_history:26]
We borrowed $8.0 million in October 2001 through a loan agreement funded with proceeds from tax-exempt industrial development revenue bonds (Bonds). These Bonds were issued by the Illinois Development Finance Authority and were used for the completion of our Northlake, Illinois facility. Pursuant to the Bond issuance, a reimbursement agreement between us and a major domestic bank required an issuance by the bank of an irrevocable direct-pay letter of credit (Bond LC), as collateral, to the Bonds’ trustee to guarantee payment of the Bonds’ principal and interest when due. The Bond LC is subject to both early termination and extension provisions customary to such agreements, as well as various covenants, for which we were in compliance at June 30, 2015. While the Bonds mature in 2021, the reimbursement agreement requires annual redemptions of $0.4 million that commenced on October 25, 2002. A sinking fund is used for the redemption of the Bonds. At June 30, 2015, the balance in the restricted sinking fund was approximately $0.3 million and was recorded in cash and cash equivalents. The Bonds bear interest at a floating rate determined weekly by the Bonds’ remarketing agent, which was the underwriter for the Bonds and is an affiliate of the bank. This interest rate was 0.20% as of June 30, 2015.

- removed (2016-02-03):
[0001564590-15-006239:note_history:27]
|  | June 30, 2015 |  |  | September 30, 2014 |  |
| Industrial development revenue bonds | $ | 2,800 |  |  | $ | 3,200 |  |
| Less current portion |  | (400 | ) |  |  | (400 | ) |
| Total long-term debt and capital lease obligations | $ | 2,400 |  |  | $ | 2,800 |  |

- removed (2016-02-03):
[0001564590-15-006239:note_history:28]
We have an $8.1 million credit facility with a major international bank in Canada (the Canadian Revolver) to provide working capital support and letters of credit for our operations in Canada. The Canadian Revolver provides for the issuance of letters of credit which reduce the amounts that may be borrowed under this revolver.  There were no outstanding letters of credit under the Canadian Revolver at June 30, 2015.


## us-gaap:ScheduleOfDebtInstrumentsTextBlock (debt) — matched_by: tag_name, score: 1.0

- added (2016-02-03):
[0001564590-16-012239:note_history:29]
|  | December 31, 2015 |  |  | September 30, 2015 |  |
| Industrial development revenue bonds......................................... | $ | 2,400 |  |  | $ | 2,800 |  |
| Less current portion..................................................... |  | (400 | ) |  |  | (400 | ) |
| Total long-term debt and capital lease obligations............................... | $ | 2,000 |  |  | $ | 2,400 |  |

- removed (2016-02-03):
[0001564590-15-006239:note_history:30]
|  | June 30, 2015 |  |  | September 30, 2014 |  |
| Industrial development revenue bonds | $ | 2,800 |  |  | $ | 3,200 |  |
| Less current portion |  | (400 | ) |  |  | (400 | ) |
| Total long-term debt and capital lease obligations | $ | 2,400 |  |  | $ | 2,800 |  |
