# POWL notes — 0001564590-16-012239


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureAndSignificantAccountingPoliciesTextBlock

[0001564590-16-012239:notes:1]
[same as prior period, unchanged from 0001564590-15-006239:notes:1]

[0001564590-16-012239:notes:2]
[same as prior period, unchanged from 0001564590-15-006239:notes:2]

[0001564590-16-012239:notes:3]
[same as prior period, unchanged from 0001564590-15-006239:notes:3]

[0001564590-16-012239:notes:4]
We develop, design, manufacture and service custom-engineered equipment and systems for the distribution, control and monitoring of electrical energy. Headquartered in Houston, Texas, we serve the oil and gas refining, offshore oil and gas production, petrochemical, pipeline, terminal, mining and metals, light rail traction power, electric utility, pulp and paper and other industrial markets.

[0001564590-16-012239:notes:5]
[same as prior period, unchanged from 0001564590-15-006239:notes:5]

[0001564590-16-012239:notes:6]
These unaudited condensed consolidated financial statements include the accounts of Powell and its wholly-owned subsidiaries.  All significant intercompany accounts and transactions have been eliminated in consolidation.

[0001564590-16-012239:notes:7]
These unaudited condensed consolidated financial statements have been prepared in accordance with the instructions to Form 10-Q and Rule 10-01 of Regulation S-X for interim financial information.  Certain information and footnote disclosures, normally included in annual financial statements prepared in accordance with accounting principles generally accepted in the United States (U.S. GAAP), have been condensed or omitted pursuant to those rules and regulations. In the opinion of management, all adjustments, consisting only of normal recurring adjustments, necessary to fairly state the financial position, results of operations and cash flows with respect to the interim consolidated financial statements have been included. The results of operations for the interim periods are not necessarily indicative of the results for the entire fiscal year.  We believe that these financial statements contain all adjustments necessary so that they are not misleading. The year-end balance sheet data was derived from audited financial statements, but does not include all disclosures required by U.S. GAAP.

[0001564590-16-012239:notes:8]
These unaudited condensed consolidated financial statements should be read in conjunction with the audited consolidated financial statements and notes thereto of Powell and its subsidiaries included in Powell’s Annual Report on Form 10-K for the year ended September 30, 2015, which was filed with the Securities and Exchange Commission (SEC) on December 2, 2015.

[0001564590-16-012239:notes:9]
References to Fiscal 2016, Fiscal 2015 and Fiscal 2014 used throughout this report shall mean our fiscal years ended September 30, 2016, 2015 and 2014, respectively.

[0001564590-16-012239:notes:10]
[same as prior period, unchanged from 0001564590-15-006239:notes:10]

[0001564590-16-012239:notes:11]
The preparation of financial statements in conformity with U.S. GAAP requires management to make estimates and assumptions that affect the amounts reported in the consolidated financial statements and accompanying footnotes. The most significant estimates used in our financial statements affect revenue and cost recognition for construction contracts, the allowance for doubtful accounts, provision for excess and obsolete inventory, goodwill and intangible assets, self-insurance, warranty accruals, liquidated damages and income taxes. The amounts recorded for insurance claims, warranties, legal, liquidated damages, income taxes and other contingent liabilities require judgments regarding the amount of expenses that will ultimately be incurred. We base our estimates on historical experience and on various other assumptions, as well as the specific circumstances surrounding these contingent liabilities, in evaluating the amount of liability that should be recorded. Additionally, the recognition of deferred tax assets requires estimates related to future income and other assumptions regarding timing and future profitability.  Estimates may change as new events occur, additional information becomes available or operating environments change. Actual results may differ from our estimates.

[0001564590-16-012239:notes:12]
[same as prior period, unchanged from 0001564590-15-006239:notes:12]

[0001564590-16-012239:notes:13]
In May 2014, the FASB issued a new standard on revenue recognition that supersedes previously issued revenue recognition guidance.  This standard provides a five-step approach to be applied to all contracts with customers and requires expanded disclosures about the nature, amount, timing and uncertainty of revenue (and the related cash flows) arising from customer contracts, significant judgments and changes in judgments used in applying the revenue model and the assets recognized from costs incurred to obtain or fulfill a contract.  This guidance is now effective for fiscal years, and interim periods within those years, beginning after December 15, 2017, which would be our fiscal year ending September 30, 2019.  The standard permits the use of either the retrospective or cumulative effect transition method therefore we are evaluating the effect that this new guidance will have on our consolidated financial statements and related disclosures. We have not yet selected a transition method nor have we determined the effect of the standard on our ongoing financial reporting.

[0001564590-16-012239:notes:14]
In June 2014, the FASB issued an amendment to the topic regarding share-based payments and instances where terms of an award provide that a performance target can be achieved after the requisite service period.  This guidance has been provided to resolve the diversity in practice concerning employee share-based payments that contain performance targets that could be achieved after the requisite service period. The updated guidance requires that a performance target that affects vesting and that can be achieved after the requisite service period be treated as a performance condition. Compensation cost should be recognized in the period in which it becomes probable that the performance target will be achieved and is attributable to the periods for which service has been rendered. If the performance target becomes probable of being achieved before the end of the service period, the remaining unrecognized compensation cost for which requisite service has not yet been rendered is recognized prospectively over the remaining service period. The total amount of compensation cost recognized during and after the service period should reflect the number of awards that are expected to vest and should be adjusted to reflect those awards that ultimately vest. The updated guidance is effective for annual and interim periods beginning after December 15, 2015, with early adoption permitted. The adoption of this guidance is not expected to have a material impact on our consolidated financial position or results of operations.

[0001564590-16-012239:notes:15]
In July 2015, the FASB issued a new topic on simplifying the measurement of inventory.  The current standard is to measure inventory at lower of cost or market; where market could be replacement cost, net realizable value, or net realizable value less an approximately normal profit margin. This topic updates this guidance to measure inventory at the lower of cost and net realizable value; where net realizable value is the estimated selling prices in the ordinary course of business, less reasonably predictable costs of completion, disposal, and transportation. This update is effective for annual reporting periods beginning after December 15, 2016, which would be our fiscal year ending September 30, 2018.  The amendments should be applied prospectively with earlier application permitted as of the beginning of an interim or annual reporting period. This topic is not expected to have a material impact on our consolidated financial position or results of operations.

[0001564590-16-012239:notes:16]
In November 2015, the FASB issued an amendment to the topic regarding income taxes which requires an entity to separate deferred income tax liabilities and assets into current and noncurrent amounts in the statement of financial position.  Deferred tax liabilities and assets are classified as current or noncurrent based on the classification of the related asset or liability for financial reporting.  Deferred tax liabilities and assets that are not related to an asset or liability for financial reporting are classified according to the expected reversal date of the temporary difference.  To simplify the presentation of deferred income taxes, the amendments require that deferred income tax liabilities and assets be classified as noncurrent in a classified statement of financial position.  This amendment is effective for us beginning with fiscal year 2018 and we have no plans for early adoption.  The adoption of t his guidance is not expected to have a material impact on our consolidated financial position or results of operations.


## us-gaap:EarningsPerShareTextBlock

[0001564590-16-012239:notes:17]
[same as prior period, unchanged from 0001564590-15-006239:notes:19]

[0001564590-16-012239:notes:18]
[same as prior period, unchanged from 0001564590-15-006239:notes:20]

[0001564590-16-012239:notes:19]
[same as prior period, unchanged from 0001564590-15-006239:notes:21]

[0001564590-16-012239:notes:20]
|  | Three months ended December 31, |  |
|  | 2015 |  |  | 2014 |  |
| Numerator: |  |  |  |  |  |  |  |
| Net loss...................................................... | $ | (459 | ) |  | $ | (239 | ) |
| Denominator: |  |  |  |  |  |  |  |
| Weighted average basic shares....................................... |  | 11,395 |  |  |  | 12,041 |  |
| Dilutive effect of restricted stock units.................................. |  | — |  |  |  | — |  |
| Weighted average diluted shares with assumed conversions.................... |  | 11,395 |  |  |  | 12,041 |  |
| Net loss per share: |  |  |  |  |  |  |  |
| Basic........................................................ | $ | (0.04 | ) |  | $ | (0.02 | ) |
| Diluted...................................................... | $ | (0.04 | ) |  | $ | (0.02 | ) |

[0001564590-16-012239:notes:21]
For the quarters ended December 31, 2015 and 2014, we incurred net losses and therefore all potential common shares were deemed to be anti-dilutive.


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0001564590-16-012239:notes:22]
[same as prior period, unchanged from 0001564590-15-006239:notes:23]

[0001564590-16-012239:notes:23]
[same as prior period, unchanged from 0001564590-15-006239:notes:24]

[0001564590-16-012239:notes:24]
[same as prior period, unchanged from 0001564590-15-006239:notes:25]

[0001564590-16-012239:notes:25]
|  | Three months ended December 31, |  |
|  | 2015 |  |  | 2014 |  |
| Balance at beginning of period................................... | $ | 746 |  |  | $ | 1,577 |  |
| Bad debt expense............................................ |  | 248 |  |  |  | 283 |  |
| Uncollectible accounts written off, net of recoveries..................... |  | 26 |  |  |  | (2 | ) |
| Change in foreign currency translation.............................. |  | (10 | ) |  |  | (14 | ) |
| Balance at end of period....................................... | $ | 1,010 |  |  | $ | 1,844 |  |

[0001564590-16-012239:notes:26]
[same as prior period, unchanged from 0001564590-15-006239:notes:27]

[0001564590-16-012239:notes:27]
[same as prior period, unchanged from 0001564590-15-006239:notes:28]

[0001564590-16-012239:notes:28]
|  | December 31, 2015 |  |  | September 30, 2015 |  |
| Raw materials, parts and subassemblies, net.............................. | $ | 33,552 |  |  | $ | 31,807 |  |
| Work-in-progress................................................ |  | 693 |  |  |  | 1,084 |  |
| Total inventories................................................ | $ | 34,245 |  |  | $ | 32,891 |  |

[0001564590-16-012239:notes:29]
[same as prior period, unchanged from 0001564590-15-006239:notes:30]

[0001564590-16-012239:notes:30]
[same as prior period, unchanged from 0001564590-15-006239:notes:31]

[0001564590-16-012239:notes:31]
|  | December 31, 2015 |  |  | September 30, 2015 |  |
| Costs incurred on uncompleted contracts.................................... | $ | 934,278 |  |  | $ | 912,237 |  |
| Estimated earnings.................................................. |  | 274,099 |  |  |  | 271,640 |  |
|  |  | 1,208,377 |  |  |  | 1,183,877 |  |
| Less: Billings to date................................................. |  | (1,152,518 | ) |  |  | (1,121,141 | ) |
| Net underbilled position............................................... | $ | 55,859 |  |  | $ | 62,736 |  |
| Included in the accompanying balance sheets under the following captions: |  |  |  |  |  |  |  |
| Costs and estimated earnings in excess of billings on uncompleted contracts – underbilled... | $ | 99,266 |  |  | $ | 104,793 |  |
| Billings in excess of costs and estimated earnings on uncompleted contracts – overbilled.... |  | (43,407 | ) |  |  | (42,057 | ) |
| Net underbilled position............................................... | $ | 55,859 |  |  | $ | 62,736 |  |

[0001564590-16-012239:notes:32]
[same as prior period, unchanged from 0001564590-15-006239:notes:33]

[0001564590-16-012239:notes:33]
[same as prior period, unchanged from 0001564590-15-006239:notes:34]

[0001564590-16-012239:notes:34]
|  | Three months ended December 31, |  |
|  | 2015 |  |  | 2014 |  |
| Balance at beginning of period.............................................. | $ | 4,930 |  |  | $ | 4,557 |  |
| Increase to warranty expense............................................... |  | 1,326 |  |  |  | 537 |  |
| Deduction for warranty charges.............................................. |  | (1,100 | ) |  |  | (524 | ) |
| Change in foreign currency translation......................................... |  | (51 | ) |  |  | (90 | ) |
| Balance at end of period.................................................. | $ | 5,105 |  |  | $ | 4,480 |  |


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0001564590-16-012239:notes:35]
D. GOODWILL AND INTANGIBLE ASSETS

[0001564590-16-012239:notes:36]
Our intangible assets consist of goodwill, which is not being amortized, and purchased technology, which is amortized over its estimated useful life.  Intangible assets balances, subject to amortization, at December 31, 2015 and September 30, 2015 consisted of the following (in thousands):

[0001564590-16-012239:notes:37]
|  | December 31, 2015 |  |  | September 30, 2015 |  |
|  | Gross |  |  |  |  |  |  | Net |  |  | Gross |  |  |  |  |  |  | Net |  |
|  | Carrying |  |  | Accumulated |  |  | Carrying |  |  | Carrying |  |  | Accumulated |  |  | Carrying |  |
|  | Value |  |  | Amortization |  |  | Value |  |  | Value |  |  | Amortization |  |  | Value |  |
| Purchased technology........... | $ | 11,749 |  |  | $ | (10,453 | ) |  | $ | 1,296 |  |  | $ | 11,749 |  |  | $ | (10,359 | ) |  | $ | 1,390 |  |
| Goodwill................... |  | 1,003 |  |  |  | — |  |  |  | 1,003 |  |  |  | 1,003 |  |  |  | — |  |  |  | 1,003 |  |
| Total.................... | $ | 12,752 |  |  | $ | (10,453 | ) |  | $ | 2,299 |  |  | $ | 12,752 |  |  | $ | (10,359 | ) |  | $ | 2,393 |  |

[0001564590-16-012239:notes:38]
Amortization of intangible assets was $0.1 million for the three months ended December 31, 2015 and 2014.

[0001564590-16-012239:notes:39]
On August 7, 2006, we purchased certain assets related to the manufacturing of ANSI medium-voltage switchgear and circuit breaker business from General Electric Company (GE).  In connection with the acquisition, we entered into a 15 year supply agreement with GE pursuant to which GE would purchase from the Company all of its requirements for ANSI medium-voltage switchgear and circuit breakers and other related equipment and components (the Products).  In connection with the acquisition, we recorded an intangible asset related to this supply agreement.  On December 30, 2013, the Company and GE amended the supply agreement to allow GE to manufacture similar Products for sale immediately and allow GE to begin purchasing Products from other suppliers beginning December 31, 2014.  In return, GE paid us $10 million upon execution of the amended supply agreement and agreed to pay an additional $7 million over three years, subject to certain conditions.  The first payment of $2.3 million was received in March 2015.  We have $2.3 million recorded in other current assets and the remaining $2.3 million is recorded as a long-term receivable. We wrote off the intangible asset related to the original supply agreement and recorded a deferred credit in the amount of $8.1 million at December 31, 2013, the amount by which the proceeds from GE exceeded the unamortized balance of our intangible asset. We are amortizing this deferred credit over the four-year life of the agreement and have recognized gains in other income of $0.5 million for the quarters ended December 31, 2015 and 2014.


## us-gaap:LongTermDebtTextBlock

[0001564590-16-012239:notes:40]
E. LONG-TERM DEBT

[0001564590-16-012239:notes:41]
Long-term debt consisted of the following (in thousands):

[0001564590-16-012239:notes:42]
|  | December 31, 2015 |  |  | September 30, 2015 |  |
| Industrial development revenue bonds......................................... | $ | 2,400 |  |  | $ | 2,800 |  |
| Less current portion..................................................... |  | (400 | ) |  |  | (400 | ) |
| Total long-term debt and capital lease obligations............................... | $ | 2,000 |  |  | $ | 2,400 |  |

[0001564590-16-012239:notes:43]
U.S. Revolver

[0001564590-16-012239:notes:44]
In Fiscal 2014, we amended and restated our existing credit agreement (the Amended Credit Agreement) with a major domestic bank. In Fiscal 2015, we entered into the Second Amendment of the Amended Credit Agreement (the Second Amendment).  The Second Amendment provided for the expansion of our Canadian manufacturing facility and allowed for the repurchase of our common stock pursuant to a share repurchase program announced in December 2014.  The Amended Credit Agreement provides for a $75.0 million revolving credit facility (U.S. Revolver). Obligations are collateralized by the stock of certain of our subsidiaries.

[0001564590-16-012239:notes:45]
The interest rate for amounts outstanding under the Amended Credit Agreement for the U.S. Revolver is a floating rate based upon the higher of the Federal Funds Rate plus 0.5%, the bank’s prime rate, or the Eurocurrency rate plus 1.00%. Once the applicable rate is determined, a margin ranging up to 1.75%, as determined by our consolidated leverage ratio, is added to the applicable rate.

[0001564590-16-012239:notes:46]
The U.S. Revolver provides for the issuance of letters of credit which reduce the amounts that may be borrowed under this revolver. The amount available under the U.S. Revolver was reduced by $21.6 million for our outstanding letters of credit at December 31, 2015.

[0001564590-16-012239:notes:47]
There were no borrowings outstanding under the U.S. Revolver as of December 31, 2015.  Amounts available under the U.S. Revolver were $53.4 million at December 31, 2015. The U.S. Revolver expires on December 31, 2018.

[0001564590-16-012239:notes:48]
The Amended Credit Agreement contains certain restrictive and maintenance-type covenants, such as restrictions on the amount of capital expenditures allowed. It also contains financial covenants defining various financial measures and the levels of these measures with which we must comply, as well as a “material adverse change” clause. A “material adverse change” is defined as a material change in our operations, business, properties, liabilities or condition (financial or otherwise) or a material impairment of our ability to perform our obligations under our credit agreements.

[0001564590-16-012239:notes:49]
The Amended Credit Agreement is collateralized by a pledge of 100% of the voting capital stock of each of our domestic subsidiaries and 65% of the voting capital stock of each non-domestic subsidiary, excluding Powell Canada. The Amended Credit Agreement provides for customary events of default and carries cross-default provisions with other existing debt agreements. If an event of default (as defined in the Amended Credit Agreement) occurs and is continuing, on the terms and subject to the conditions set forth in the Amended Credit Agreement, amounts outstanding under the Amended Credit Agreement may be accelerated and may become immediately due and payable. As of December 31, 2015, we were in compliance with all of the financial covenants of the Amended Credit Agreement.

[0001564590-16-012239:notes:50]
Canadian Revolver

[0001564590-16-012239:notes:51]
We have a $7.2 million credit agreement with a major international bank in Canada (the Canadian Revolver) to provide working capital support and letters of credit for our operations in Canada. The Canadian Revolver provides for the issuance of letters of credit which reduce the amounts that may be borrowed under this revolver.  There were no outstanding letters of credit under the Canadian Revolver at December 31, 2015.

[0001564590-16-012239:notes:52]
There were no borrowings outstanding under the Canadian Revolver as of December 31, 2015 and amounts available under the Canadian Revolver were $7.2 million at December 31, 2015.  The interest rate for amounts outstanding under the Canadian Revolver is a floating interest rate based upon either the Canadian Prime Rate, or the lender’s Bankers’ Acceptance Rate. Once the applicable rate is determined, a margin of 0.50% to 1.75%, as determined by our consolidated leverage ratio, is added to the applicable rate. The Canadian Revolver expires on March 31, 2018.

[0001564590-16-012239:notes:53]
The principal financial covenants are consistent with those described in our Amended Credit Agreement. The Canadian Revolver contains a “material adverse effect” clause. A “material adverse effect” is defined as a material change in the operations of Powell or Powell Canada in relation to our financial condition, property, business operations, expected net cash flows, liabilities or capitalization.

[0001564590-16-012239:notes:54]
The Canadian Revolver is secured by the assets of our Canadian operations and provides for customary events of default and carries cross-default provisions with our existing debt agreements. If an event of default (as defined in the Canadian Revolver) occurs and is continuing, per the terms and subject to the conditions set forth in the Canadian Revolver, amounts outstanding under the Canadian Revolver may be accelerated and may become immediately due and payable. As of December 31, 2015, we were in compliance with all of the financial covenants of the Canadian Revolver.

[0001564590-16-012239:notes:55]
Industrial Development Revenue Bonds

[0001564590-16-012239:notes:56]
We borrowed $8.0 million in October 2001 through a loan agreement funded with proceeds from tax-exempt industrial development revenue bonds (Bonds). These Bonds were issued by the Illinois Development Finance Authority and were used for the completion of our Northlake, Illinois facility. Pursuant to the Bond issuance, a reimbursement agreement between us and a major domestic bank required an issuance by the bank of an irrevocable direct-pay letter of credit (Bond LC), as collateral, to the Bonds’ trustee to guarantee payment of the Bonds’ principal and interest when due. The Bond LC is subject to both early termination and extension provisions customary to such agreements, as well as various covenants, for which we were in compliance at December 31, 2015. While the Bonds mature in 2021, the reimbursement agreement requires annual redemptions of $0.4 million that commenced on October 25, 2002. A sinking fund is used for the redemption of the Bonds. The Bonds bear interest at a floating rate determined weekly by the Bonds’ remarketing agent, which was the underwriter for the Bonds and is an affiliate of the bank. This interest rate was 0.15% as of December 31, 2015.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001564590-16-012239:notes:57]
F. COMMITMENTS AND CONTINGENCIES

[0001564590-16-012239:notes:58]
Long-Term Debt

[0001564590-16-012239:notes:59]
See Note E herein for discussion of our long-term debt.

[0001564590-16-012239:notes:60]
Letters of Credit and Bonds

[0001564590-16-012239:notes:61]
Certain customers require us to post bank letter of credit guarantees or performance bonds issued by a surety. These guarantees and performance bonds assure that we will perform under the terms of our contract. In the event of default, the counterparty may demand payment from the bank under a letter of credit or performance by the surety under a performance bond. To date, there have been no significant expenses related to either letters of credit or performance bonds for the periods reported. We were contingently liable for secured and unsecured letters of credit of $21.6 million as of December 31, 2015. We also had performance and maintenance bonds totaling $307.5 million that were outstanding, with additional bonding capacity of $442.5 million available, at December 31, 2015.

[0001564590-16-012239:notes:62]
We have a $14.8 million facility agreement (Facility Agreement) between Powell (UK) Limited and a large international bank. This Facility Agreement provides Powell (UK) the ability to enter into bank guarantees as well as forward exchange contracts and currency options. At December 31, 2015, we had outstanding guarantees totaling $3.0 million under this Facility Agreement and amounts available under this Facility Agreement were $11.8 million.  This facility is renewable in May 2016.

[0001564590-16-012239:notes:63]
The Facility Agreement provides for financial covenants and customary events of default, and carries cross-default provisions with our Amended Credit Facility. If an event of default (as defined in the Facility Agreement) occurs and is continuing, per the terms and subject to the conditions set forth therein, obligations outstanding under the Facility Agreement may be accelerated and may become or be declared immediately due and payable. As of December 31, 2015, we were in compliance with all of the financial covenants of the Facility Agreement.

[0001564590-16-012239:notes:64]
Litigation

[0001564590-16-012239:notes:65]
We are involved in various legal proceedings, claims and other disputes arising from our commercial operations, projects, employees and other matters which, in general, are subject to uncertainties and in which the outcomes are not predictable. Although we can give no assurances about the resolution of pending claims, litigation or other disputes and the effect such outcomes may have on us, management believes that any ultimate liability resulting from the outcome of such proceedings, to the extent not otherwise provided or covered by insurance, will not have a material adverse effect on our consolidated financial position or results of operations or liquidity.

[0001564590-16-012239:notes:66]
Liquidated Damages

[0001564590-16-012239:notes:67]
Certain of our customer contracts have schedule and performance obligation clauses that, if we fail to meet them, could subject us to liquidated damages.  Each individual contract defines the conditions under which the customer may make a claim against us.  As of December 31, 2015, our exposure to possible liquidated damages is $7.5 million, of which approximately $2.2 million is probable.  Based on our actual or projected failure to meet these various contractual commitments, $1.7 million has been recorded against revenue in our statement of operations.  We believe that we will be successful in obtaining change orders or contract extensions that should resolve the potential for any unaccrued liquidated damages; however, should we fail to achieve relief on some or all of these contractual obligations, we could be subject to additional liquidated damages which could impact our future operating results.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001564590-16-012239:notes:68]
G.STOCK-BASED COMPENSATION

[0001564590-16-012239:notes:69]
Refer to our Annual Report on Form 10-K for the fiscal year ended September 30, 2015 for a full description of our existing stock-based compensation plans.

[0001564590-16-012239:notes:70]
[same as prior period, unchanged from 0001564590-15-006239:notes:72]

[0001564590-16-012239:notes:71]
We issue restricted stock units (RSUs) to certain officers and key employees of the Company.  The fair value of the RSUs is based on the closing price of our common stock as reported on the NASDAQ Global Market on the grant dates. Typically, these grants vest over a three-year period from their date of issuance, of which sixty percent of the grant will be earned based on the three year earnings performance of the Company following the grant date.  The remaining forty percent of the grant is time-based and vests over a three-year period on each anniversary of the grant date, based on continued employment.  At December 31, 2015, there were 153,522 RSUs outstanding. The RSUs do not have voting rights but receive dividend equivalents upon vesting; additionally, the shares of common stock underlying the RSUs are not considered issued and outstanding until vested and common stock is issued.

[0001564590-16-012239:notes:72]
[same as prior period, unchanged from 0001564590-15-006239:notes:74]

[0001564590-16-012239:notes:73]
|  | Number of |  |  | Weighted |  |
|  | Restricted |  |  | Average |  |
|  | Stock |  |  | Fair Value |  |
|  | Units |  |  | Per Share |  |
| Outstanding at September 30, 2015.......................................... |  | 133,506 |  |  | $ | 50.26 |  |
| Granted.......................................................... |  | 123,000 |  |  |  | 30.27 |  |
| Vested(1)........................................................ |  | (91,934 | ) |  |  | 33.36 |  |
| Forfeited/cancelled.................................................. |  | (11,050 | ) |  |  | 30.27 |  |
| Outstanding at December 31, 2015.......................................... |  | 153,522 |  |  | $ | 45.80 |  |

[0001564590-16-012239:notes:74]
(1)      Includes the accelerated vesting of 60,909 shares previously issued to our former Chief Executive Officer as part of his separation package, see Note J.

[0001564590-16-012239:notes:75]
During the three months ended December 31, 2015 and 2014, we recorded compensation expense of $2.1 million and $0.8 million, respectively, related to the RSUs.  The increase in compensation expense recorded in the three months ended December 31, 2015, was primarily due to separation costs, see Note J.

[0001564590-16-012239:notes:76]
[same as prior period, unchanged from 0001564590-15-006239:notes:77]

[0001564590-16-012239:notes:77]
Restricted stock grants vest equally over their respective vesting period on each anniversary of the grant date and compensation expense is recognized over their respective vesting periods based on the price per share on the grant date.  During the first quarter of Fiscal 2015 and Fiscal 2014, there was no restricted stock granted.

[0001564590-16-012239:notes:78]
During the three months ended December 31, 2015 and 2014, we recorded compensation expense of $0.2 million and $0.3 million, respectively, related to restricted stock grants.


## us-gaap:FairValueDisclosuresTextBlock

[0001564590-16-012239:notes:79]
H. FAIR VALUE MEASUREMENTS

[0001564590-16-012239:notes:80]
[same as prior period, unchanged from 0001564590-15-006239:notes:83]

[0001564590-16-012239:notes:81]
[same as prior period, unchanged from 0001564590-15-006239:notes:84]

[0001564590-16-012239:notes:82]
[same as prior period, unchanged from 0001564590-15-006239:notes:85]

[0001564590-16-012239:notes:83]
[same as prior period, unchanged from 0001564590-15-006239:notes:86]

[0001564590-16-012239:notes:84]
[same as prior period, unchanged from 0001564590-15-006239:notes:87]

[0001564590-16-012239:notes:85]
The following table summarizes the fair value of our assets and liabilities that were accounted for at fair value on a recurring basis as of December 31, 2015 (in thousands):

[0001564590-16-012239:notes:86]
|  | Fair Value Measurements at December 31, 2015 |  |
|  | Quoted Prices in |  |  | Significant Other |  |  | Significant |  |  |  |  |  |
|  | Active Markets for |  |  | Observable |  |  | Unobservable |  |  | Fair Value at |  |
|  | Identical Assets |  |  | Inputs |  |  | Inputs |  |  | December 31, |  |
|  | (Level 1) |  |  | (Level 2) |  |  | (Level 3) |  |  | 2015 |  |
| Assets: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cash equivalents........................ | $ | 134 |  |  | $ | — |  |  | $ | — |  |  | $ | 134 |  |
| Deferred compensation.................... |  | 2,502 |  |  |  | 2,980 |  |  |  | — |  |  |  | 5,482 |  |
| Liabilities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Deferred compensation.................... |  | — |  |  |  | 5,315 |  |  |  | — |  |  |  | 5,315 |  |

[0001564590-16-012239:notes:87]
The following table summarizes the fair value of our assets and liabilities that were accounted for at fair value on a recurring basis as of September 30, 2015 (in thousands):

[0001564590-16-012239:notes:88]
|  | Fair Value Measurements at September 30, 2015 |  |
|  | Quoted Prices in |  |  | Significant Other |  |  | Significant |  |  |  |  |  |
|  | Active Markets for |  |  | Observable |  |  | Unobservable |  |  | Fair Value at |  |
|  | Identical Assets |  |  | Inputs |  |  | Inputs |  |  | September 30, |  |
|  | (Level 1) |  |  | (Level 2) |  |  | (Level 3) |  |  | 2015 |  |
| Assets: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cash equivalents........................ | $ | 434 |  |  | $ | — |  |  | $ | — |  |  | $ | 434 |  |
| Deferred compensation.................... |  | 1,879 |  |  |  | 2,904 |  |  |  | — |  |  |  | 4,783 |  |
| Liabilities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Deferred compensation.................... |  | — |  |  |  | 4,487 |  |  |  | — |  |  |  | 4,487 |  |

[0001564590-16-012239:notes:89]
[same as prior period, unchanged from 0001564590-15-006239:notes:92]

[0001564590-16-012239:notes:90]
[same as prior period, unchanged from 0001564590-15-006239:notes:93]

[0001564590-16-012239:notes:91]
Fair value guidance requires certain fair value disclosures be presented in both interim and annual reports.  The estimated fair value amounts of financial instruments have been determined using available market information and valuation methodologies described below.

[0001564590-16-012239:notes:92]
Deferred Compensation – We hold investments in an irrevocable Rabbi Trust for our deferred compensation plan. These assets include both mutual fund investments and company-owned life insurance policies. Under the plan, participants designate investment options to serve as the basis for measurement of the notional value of their accounts.  The fair values of the underlying securities of these funds are based on quoted market prices and are categorized as Level I in the fair value measurement hierarchy.  The company-owned life insurance policies are valued at cash surrender value and are therefore categorized as Level 2 in the fair value measurement hierarchy.

[0001564590-16-012239:notes:93]
Industrial Development Revenue Bond – The fair value of our long-term debt depends primarily on the coupon rate of our industrial development revenue bonds.  The carrying value of our long-term debt at December 31, 2015, approximates fair value based on the current coupon rate of the bonds, which is reset weekly, and is classified as a Level 2 input in the fair value measurement hierarchy as there is an active market for the trading of these industrial development revenue bonds.

[0001564590-16-012239:notes:94]
There were no transfers between levels within the fair value measurement hierarchy during the three months ended December 31, 2015.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001564590-16-012239:notes:95]
I. INCOME TAXES

[0001564590-16-012239:notes:96]
[same as prior period, unchanged from 0001564590-15-006239:notes:104]

[0001564590-16-012239:notes:97]
|  | Three months ended December 31, |  |
|  | 2015 |  |  | 2014 |  |
| Loss before income taxes.................................... | $ | (1,506 | ) |  | $ | (1,230 | ) |
| Income tax benefit......................................... |  | (1,047 | ) |  |  | (991 | ) |
| Net loss................................................ | $ | (459 | ) |  | $ | (239 | ) |
| Effective tax rate.......................................... |  | 70 | % |  |  | 81 | % |

[0001564590-16-012239:notes:98]
|  | Three months ended December 31, |  |
|  | 2015 |  |  | 2014 |  |
| Statutory rate............................................... |  | 35 | % |  |  | 35 | % |
| Foreign valuation allowance..................................... |  | (11 | ) |  |  | — |  |
| Research and development credit................................. |  | 45 |  |  |  | 46 |  |
| State income taxes, net of federal benefit............................ |  | 3 |  |  |  | 2 |  |
| Domestic production activities deduction............................ |  | (2 | ) |  |  | (2 | ) |
| Effective rate............................................... |  | 70 | % |  |  | 81 | % |

[0001564590-16-012239:notes:99]
We recorded an income tax benefit of $1.0 million in the first quarter of Fiscal 2016 and Fiscal 2015.  The effective tax rate for the first quarter of Fiscal 2016 was 70% compared to an effective tax rate of 81% in the first quarter of Fiscal 2015, primarily due to our inability to recognize a tax benefit on the Canadian loss incurred in the first quarter of Fiscal 2016. A tax benefit related to the Canadian loss was recognized in the first quarter of Fiscal 2015.

[0001564590-16-012239:notes:100]
In the second quarter of Fiscal 2015, we recorded a valuation allowance against the Canadian net deferred assets.  Due to the historical Canadian losses, and the projected losses in the near term, we were required under the more-likely-than-not accounting standard to record a valuation allowance against the Canadian net deferred assets because we anticipated that we may not be able to realize the benefits of the net operating loss carryforwards and other deductible differences.

[0001564590-16-012239:notes:101]
On December 18, 2015, the “Protecting Americans from Tax Hikes Act of 2015” was enacted which retroactively reinstated and made permanent the Research and Development Tax Credit (R&D Tax Credit).  The retroactive tax benefit for the previously expired period from January 1, 2015 to September 30, 2015 of $0.8 million is reflected as a discrete item and had a favorable impact to our consolidated tax benefit for the first quarter of Fiscal 2016.  A retroactive reinstatement of the R&D Tax Credit resulting in a discrete item of $0.6 million was made in the first quarter of Fiscal 2015.


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0001564590-16-012239:notes:102]
J. RESTRUCTURING AND SEPARATION COSTS

[0001564590-16-012239:notes:103]
In the first quarter of Fiscal 2016, we incurred $3.8 million of restructuring and separation costs associated with the departure of our former Chief Executive Officer on December 24, 2015.  This includes stock-based compensation expense of $1.8 million due to the accelerated vesting of 60,909 restricted stock units, as well as future cash payments of $2.0 million, of which $1.7 million will be paid in Fiscal 2016.
