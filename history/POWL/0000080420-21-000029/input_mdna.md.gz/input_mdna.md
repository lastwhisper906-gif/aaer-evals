# POWL MD&A — 0000080420-21-000029


## mdna

[0000080420-21-000029:mdna:1]
[same as prior period, unchanged from 0000080420-21-000013:mdna:1]

[0000080420-21-000029:mdna:2]
[same as prior period, unchanged from 0000080420-21-000013:mdna:2]

[0000080420-21-000029:mdna:3]
[same as prior period, unchanged from 0000080420-21-000013:mdna:3]

[0000080420-21-000029:mdna:4]
[same as prior period, unchanged from 0000080420-21-000013:mdna:4]

[0000080420-21-000029:mdna:5]
[same as prior period, unchanged from 0000080420-21-000013:mdna:5]

[0000080420-21-000029:mdna:6]
[same as prior period, unchanged from 0000080420-21-000013:mdna:6]

[0000080420-21-000029:mdna:7]
Beginning in late Fiscal 2018, the combination of a growing global economy, abundant sources of favorably priced natural gas feedstock, and an energy industry focus on transition to natural gas and cleaner-burning fuels drove an increase in capital investment opportunities, specifically across the oil, gas and petrochemical sectors. Some of these opportunities were for natural gas related projects targeting global demand for cleaner-burning fuels. Additionally, projects within the domestic petrochemical sector benefited from the low feedstock prices of natural gas. Specific to natural gas, the business was awarded a substantial contract in the second quarter of Fiscal 2020 that will support the integrated electrical distribution requirements for a large domestic industrial complex and should be substantially completed in Fiscal 2022. However, we began to experience reduced commercial activity in Fiscal 2020 driven in large part by the uncertainties across our industrial end markets in the U.S. resulting from the COVID-19 pandemic. Considering the long cycle nature of our business, we anticipate that these cyclical conditions will persist throughout Fiscal 2021.

[0000080420-21-000029:mdna:8]
[same as prior period, unchanged from 0000080420-21-000013:mdna:8]

[0000080420-21-000029:mdna:9]
Through the first half of Fiscal 2021, the COVID-19 pandemic continues to significantly impact global economic conditions. This pandemic has negatively impacted energy demand, which in turn has resulted in considerable volatility across global oil and gas commodity markets. The demand for our products and services as well as our operations have been negatively impacted by COVID-19, resulting from the associated reduction in oil and gas demand and volatility in commodity prices noted above. As a result, some of our industrial customers are deferring or suspending their planned capital expenditures. Certain of our customers have asked that we delay or cancel our manufacturing on their projects as their operations have been negatively impacted by this pandemic and the reduced oil and gas demand which has resulted in recognition of cancellation fees based on contract terms and the extent of our progress on the projects. We continue to work with and review the contracts with our key suppliers who have been impacted by this pandemic to ensure that we are able to meet our customer commitments.

[0000080420-21-000029:mdna:10]
In response to the lower demand across select end markets, we have taken and will continue to take various actions to reduce costs. During Fiscal 2020, we reduced our global workforce and reduced our capital and discretionary spending in response to current business conditions and will continue to monitor the economic conditions during the remainder of Fiscal 2021.

[0000080420-21-000029:mdna:11]
[same as prior period, unchanged from 0000080420-21-000013:mdna:11]

[0000080420-21-000029:mdna:12]
[same as prior period, unchanged from 0000080420-21-000013:mdna:12]

[0000080420-21-000029:mdna:13]
Quarter Ended March 31, 2021 Compared to the Quarter Ended March 31, 2020 (Unaudited)

[0000080420-21-000029:mdna:14]
[same as prior period, unchanged from 0000080420-21-000013:mdna:14]

[0000080420-21-000029:mdna:15]
Revenues decreased by 22%, or $32.9 million, to $118.7 million in the second quarter of Fiscal 2021, due to a decrease in orders as well as project delays and cancellations of potential projects associated with the global economic impact resulting from the COVID-19 pandemic and associated reduction in demand across the oil and gas end markets. These cyclical market conditions, which began in the second half of Fiscal 2020, led to a reduction in project bookings and project delays which have negatively impacted, and will continue to negatively impact, our revenues in Fiscal 2021. Domestic revenues decreased, as noted above, by 27%, or $32.9 million, to $87.9 million in the second quarter of Fiscal 2021. Included in our domestic revenues is our large domestic industrial project awarded in Fiscal 2020, which accounted for approximately 20% of our consolidated revenues for the second quarter of Fiscal 2021. International revenues increased by $0.1 million, to $30.8 million in the second quarter of Fiscal 2021 as a result of lower commercial activity across our international operations. Our international revenues include both revenues generated from our international facilities as well as revenues from export projects generated at our domestic facilities.

[0000080420-21-000029:mdna:16]
Revenue from our oil and gas end markets decreased by 3%, or $1.8 million, to $50.1 million in the second quarter of Fiscal 2021, while petrochemical revenue decreased by 78%, or $37.1 million, to $10.2 million in the second quarter of Fiscal 2021, in each case primarily due to the uncertainty across our end markets. Revenue from utility markets increased by 17%, or $4.2 million, to $28.5 million, and traction market revenue increased by 9%, or $1.2 million, to $15.1 million in the second quarter of Fiscal 2021, as the mix of our projects shifts across our global operating facilities. Revenue from all other markets combined increased by $0.7 million to $14.8 million in the second quarter of Fiscal 2021.

[0000080420-21-000029:mdna:17]
The reduction in revenues led to a subsequent reduction in gross profit, decreasing by 42%, or $12.5 million, to $17.2 million for the second quarter of Fiscal 2021. Gross profit as a percentage of revenues decreased to 14% in the second quarter of Fiscal 2021, compared to 20% in the second quarter of Fiscal 2020. The decrease in gross profit as a percentage of revenues was driven in part by underutilization across our Texas manufacturing facilities resulting from the lower volume as well as a one week shutdown due to a statewide power outage resulting from winter storm Uri, but also was adversely impacted by the increasing commodity costs, specifically for copper and steel.

[0000080420-21-000029:mdna:18]
[same as prior period, unchanged from 0000080420-21-000013:mdna:18]

[0000080420-21-000029:mdna:19]
Selling, general and administrative expenses decreased by 10%, or $1.9 million, to $16.7 million in the second quarter of Fiscal 2021, driven by the restructuring actions that were initiated in the third quarter of Fiscal 2020, as well as a reduction in personnel costs and lower travel-related costs resulting from the COVID-19 pandemic. Selling, general and administrative expenses as a percentage of revenues was 14% during the second quarter of Fiscal 2021 compared to 12% during the second quarter of Fiscal 2020, primarily due to the decrease in revenues.

[0000080420-21-000029:mdna:20]
Income Tax Provision/Benefit

[0000080420-21-000029:mdna:21]
We recorded an income tax benefit of $0.9 million in the second quarter of Fiscal 2021, compared to an income tax provision of $2.1 million in the second quarter of Fiscal 2020. The effective tax rate for the second quarter of Fiscal 2021 was 81%, compared to an effective tax rate of 22% in the second quarter of Fiscal 2020. For the three months ended March 31, 2021, the effective tax rate was favorably impacted by the relative amounts of income/loss recognized in various tax jurisdictions. The effective tax rate was also favorably impacted by the estimated Research and Development Tax Credit (R&D Tax Credit) and the projected utilization of net operating loss carryforwards in Canada that were fully reserved with a valuation allowance in the second quarter of Fiscal 2021 and 2020.

[0000080420-21-000029:mdna:22]
[same as prior period, unchanged from 0000080420-21-000013:mdna:22]

[0000080420-21-000029:mdna:23]
In the second quarter of Fiscal 2021, we recorded a net loss of $0.2 million, or $0.02 per diluted share, compared to net income of $7.4 million, or $0.64 per diluted share, in the second quarter of Fiscal 2020. This decrease is attributable to lower revenues in the second fiscal quarter of 2021 versus the prior year and the associated leverage impact resulting from the lower global demand across our industrial end markets, as well as increasing commodity costs for both copper and steel.

[0000080420-21-000029:mdna:24]
[same as prior period, unchanged from 0000080420-21-000013:mdna:24]

[0000080420-21-000029:mdna:25]
The order backlog at March 31, 2021 was $436.6 million, a decrease of 6% from $464.9 million at December 31, 2020 and a decrease of 23% from $566.4 million backlog at March 31, 2020. Bookings, net of cancellations and scope reductions, decreased by 71% in the second quarter of Fiscal 2021 to $88.5 million, compared to $300.7 million in the second quarter of Fiscal 2020, primarily due to a substantial contract awarded in the second quarter of Fiscal 2020 that will support the integrated electrical distribution requirements for a large domestic industrial complex and decreased global demand across our core oil and gas markets.

[0000080420-21-000029:mdna:26]
Six Months Ended March 31, 2021 Compared to the Six Months Ended March 31, 2020 (Unaudited)

[0000080420-21-000029:mdna:27]
Revenue and Gross Profit

[0000080420-21-000029:mdna:28]
Revenues decreased by 21%, or $60.4 million, to $225.3 million in the six months ended March 31, 2021, due to a decrease in orders as well as project delays and cancellations of potential projects associated with the global economic impact resulting from the COVID-19 pandemic and associated reduction in demand across the oil and gas end markets. Domestic revenues decreased by 26%, or $58.5 million, to $168.5 million in the six months ended March 31, 2021. International revenues decreased by 3%, or $1.9 million, to $56.8 million. Our international revenues include both revenues generated from our international facilities as well as revenues from export projects generated at our domestic facilities.

[0000080420-21-000029:mdna:29]
Revenue from our oil and gas markets decreased by 19%, or $21.8 million, to $90.2 million in the six months ended March 31, 2021. Petrochemical revenue decreased by 75%, or $58.4 million, to $19.4 million in the six months ended March 31, 2021. Revenue from utility markets increased by 20%, or $9.4 million, to $56.6 million, and traction market revenue increased by 28%, or $6.2 million, to $28.5 million in the six months ended March 31, 2021, as the mix of our projects shifts across our global operating facilities. Revenue from all other markets combined increased by 16%, or $4.2 million, to $30.6 million in the six months ended March 31, 2021.

[0000080420-21-000029:mdna:30]
The reduction in revenue led to a reduction in gross profit of 31%, or $16.1 million, as compared to the first half of Fiscal 2020. However, gross profit of $35.4 million for the first half of Fiscal 2021 benefited from favorable close out gains on certain projects resulting from cost and productivity efficiencies and to a lesser extent from cancellation fees from certain contracts in our North American manufacturing facilities, which was partially offset by higher commodity prices and factory underutilization. Gross profit as a percentage of revenues decreased to 16% in the six months ended March 31, 2021, compared to 18% in the six months ended March 31, 2020 as a result of the reduction in revenues noted above.

[0000080420-21-000029:mdna:31]
Selling, General and Administrative Expenses

[0000080420-21-000029:mdna:32]
Selling, general and administrative expenses decreased by 6%, or $2.3 million, to $33.5 million in the six months ended March 31, 2021, partially due to the restructuring action taken in the third quarter of Fiscal 2020 as well as the decreased personnel costs and travel-related costs. Selling, general and administrative expenses, as a percentage of revenues increased to 15% during the six months ended March 31, 2021, compared to 13% during the six months ended March 31, 2020, primarily due to the decrease in revenues.

[0000080420-21-000029:mdna:33]
Income Tax Provision/Benefit

[0000080420-21-000029:mdna:34]
We recorded an income tax benefit of $0.8 million in the six months ended March 31, 2021, compared to an income tax provision of $2.7 million in the six months ended March 31, 2020. The effective tax rate for the six months ended March 31, 2021 was 59%, compared to an effective tax rate of 21% for the six months ended March 31, 2020. For the six months ended March 31, 2021 and 2020, the effective tax rate was favorably impacted by the R&D Tax Credit as well as the projected utilization of net operating loss carryforwards in Canada that were fully reserved with a valuation allowance. Conversely, the effective tax rate was negatively impacted by a discrete item related to the establishment of a valuation allowance against the UK deferred tax assets in the six months ended March 31, 2020.

[0000080420-21-000029:mdna:35]
Net Income/Loss

[0000080420-21-000029:mdna:36]
In the six months ended March 31, 2021, we recorded a net loss of $0.6 million, or $0.05 per diluted share, compared to net income of $10.2 million, or $0.87 per diluted share, in the six months ended March 31, 2020, primarily due to a decline in revenues and gross profit resulting from lower orders and project delays caused by the economic impact resulting from the COVID-19 pandemic and the associated reduction in global demand across our industrial end markets.

[0000080420-21-000029:mdna:37]
Backlog

[0000080420-21-000029:mdna:38]
The order backlog at March 31, 2021 was $436.6 million, a decrease of 8% from $476.8 million at September 30, 2020. Bookings, net of cancellations and scope reductions, decreased by 59% during the six months ended March 31, 2021 to $179.6 million, compared to $438.1 million in the six months ended March 31, 2020. The decrease in bookings was primarily due to the large contract awarded in the second quarter of Fiscal 2020 and decreased global demand across our core oil and gas markets.

[0000080420-21-000029:mdna:39]
[same as prior period, unchanged from 0000080420-21-000013:mdna:26]

[0000080420-21-000029:mdna:40]
As noted in "Overview" above, the markets in which we participate are capital-intensive and cyclical in nature. A significant portion of our revenues has historically been from the oil, gas and petrochemical markets. Oil and gas commodity price levels have been unstable over the last several years, and our customers have in certain cases delayed or cancelled some of their major capital investment projects. Beginning in late Fiscal 2018 through the first quarter of Fiscal 2020, our customers' decisions to invest in projects in our key oil and gas and petrochemical markets were influenced to some extent by relative stabilization of commodity prices and the increased global demand for cleaner-burning fuels during that period of time. We believe that this change in market sentiment during that period of time had a favorable impact on our orders and backlog entering Fiscal 2020. However, the recent declines in oil prices and the global economic impacts from COVID-19 have had, and may continue to have, a negative impact on our business going forward, as discussed in more detail below. Specific to the energy industry focus on transition to natural gas and cleaner-burning fuels, the business was awarded a substantial contract in Fiscal 2020 that will support the integrated electrical distribution requirements for a large domestic industrial complex and should be substantially completed in Fiscal 2022.

[0000080420-21-000029:mdna:41]
Our operating results are impacted by factors such as the timing of new order awards, customer approval of final engineering and design specifications and delays in customer construction schedules, all of which contribute to short-term earnings variability and the timing of project execution. Our operating results also have been, and may continue to be, impacted by the timing and resolution of change orders, project close-out and resolution of potential contract claims and liquidated damages, all of which could improve or deteriorate gross margins during the period in which these items are resolved with our customers. These factors may result in periods of underutilization of our resources and facilities, which may negatively impact our ability to cover our fixed costs. The strong commercial activity and subsequent orders in Fiscal 2018 and 2019 led to solid revenue and operating results for Fiscal 2020. We began to experience lower commercial activity in Fiscal 2020 driven in large part from the  uncertainty resulting from the COVID-19 pandemic, as discussed in "Overview" above. Considering the long cycle nature of our business, we anticipate these cyclical conditions will persist throughout Fiscal 2021. We will continue to monitor the variables that impact our markets while adjusting to the global conditions in order to maintain a competitive cost and technological advantage in the markets that we serve.

[0000080420-21-000029:mdna:42]
[same as prior period, unchanged from 0000080420-21-000013:mdna:29]

[0000080420-21-000029:mdna:43]
[same as prior period, unchanged from 0000080420-21-000013:mdna:30]

[0000080420-21-000029:mdna:44]
As of March 31, 2021, current assets exceeded current liabilities by 2.5 times, and our debt to total capitalization was 0.13%.

[0000080420-21-000029:mdna:45]
Cash, cash equivalents and short-term investments decreased to $153.9 million at March 31, 2021, compared to $178.9 million at September 30, 2020. This decrease in cash was primarily driven by the timing of contract billing milestones. We believe that our strong working capital position, available borrowings under our credit facility and available cash should be sufficient to finance future operating activities, capital improvements, research and development initiatives and debt repayments for the foreseeable future.

[0000080420-21-000029:mdna:46]
We have a credit agreement with Bank of America, N.A. (the "U.S. Revolver") which is a $75.0 million revolving credit facility available for both borrowings and letters of credit and expires September 27, 2024. On March 12, 2021, we entered into a first amendment to the U.S. Revolver which, among other things, amended certain terms related to the calculation of the consolidated leverage ratio from gross leverage to net leverage. As a result of the first amendment, up to $30 million may be

[0000080420-21-000029:mdna:47]
deducted from the amount of letters of credit outstanding (not to be less than zero) when calculating the consolidated funded indebtedness which is a component of the consolidated net leverage ratio. Additionally, we now have the option to cash collateralize all or a portion of the letters of credit outstanding, which would favorably impact the consolidated funded indebtedness calculation and the consolidated net leverage ratio.

[0000080420-21-000029:mdna:48]
As of March 31, 2021, there were no amounts borrowed under the U.S. Revolver, and letters of credit outstanding were $38.6 million. As of March 31, 2021, $36.4 million was available for the issuance of letters of credit and borrowing under the U.S. Revolver. Total long-term debt, including current maturities, totaled $0.4 million at March 31, 2021 related to outstanding industrial development revenue bonds. We are required to maintain certain financial covenants, the most significant of which are a consolidated net leverage ratio of less than 3.0 to 1.0 and a consolidated interest coverage ratio of greater than 3.0 to 1.0. The consolidated leverage ratio is our most restrictive covenant and a decrease in our earnings before interest, taxes, depreciation, amortization and stock-based compensation (EBITDAS) could restrict our ability to issue letters of credit under the U.S. Revolver. For further information regarding our debt, see Notes E and F of Notes to Condensed Consolidated Financial Statements.

[0000080420-21-000029:mdna:49]
Approximately $28.2 million of our cash and cash equivalents at March 31, 2021 was held outside of the U.S. for international operations. It is our intention to indefinitely reinvest all current and future foreign earnings internationally in order to ensure sufficient working capital to support our international operations. In the event that we elect to repatriate some or all of the foreign earnings that were previously deemed to be indefinitely reinvested outside the U.S., we may incur additional tax expense upon such repatriation under current tax laws.

[0000080420-21-000029:mdna:50]
[same as prior period, unchanged from 0000080420-21-000013:mdna:35]

[0000080420-21-000029:mdna:51]
Operating activities used $18.1 million during the six months ended March 31, 2021 and provided $7.4 million during the same period in Fiscal 2020. Cash flow from operations is primarily influenced by project volume, the timing of milestone payments from our customers and the payment terms with our suppliers. This decrease in operating cash flow was primarily due to a decrease in accounts receivable collections and the timing of contract billing milestones.

[0000080420-21-000029:mdna:52]
[same as prior period, unchanged from 0000080420-21-000013:mdna:37]

[0000080420-21-000029:mdna:53]
Investing activities used $1.2 million during the six months ended March 31, 2021 compared to $2.7 million provided during the same period in Fiscal 2020. The increase in cash used by investing activities in the first half of Fiscal 2021 was primarily due to short-term investment activity partially offset by a decrease in capital expenditures and proceeds received from a Company-owned life insurance policy related to a retired employee.

[0000080420-21-000029:mdna:54]
[same as prior period, unchanged from 0000080420-21-000013:mdna:39]

[0000080420-21-000029:mdna:55]
Net cash used in financing activities was $7.1 million during the six months ended March 31, 2021 and $7.0 million during the same period in Fiscal 2020, which primarily consisted of approximately $6.0 million of dividends paid in each period.

[0000080420-21-000029:mdna:56]
[same as prior period, unchanged from 0000080420-21-000013:mdna:41]

[0000080420-21-000029:mdna:57]
[same as prior period, unchanged from 0000080420-21-000013:mdna:42]

[0000080420-21-000029:mdna:58]
[same as prior period, unchanged from 0000080420-21-000013:mdna:43]

[0000080420-21-000029:mdna:59]
[same as prior period, unchanged from 0000080420-21-000013:mdna:44]

[0000080420-21-000029:mdna:60]
[same as prior period, unchanged from 0000080420-21-000013:mdna:45]
