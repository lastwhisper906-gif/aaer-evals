# POWL 8-K — 0000080420-21-000026 filed 2021-05-04

## item codes, every 8-K on or before 2021-05-05

- 2021-05-04 0000080420-21-000026 — 2.02, 8.01, 9.01
- 2021-03-16 0001193125-21-082878 — 1.01, 2.03, 9.01
- 2021-03-05 0000080420-21-000021 — 5.02, 8.01, 9.01
- 2021-02-26 0000080420-21-000018 — 5.03
- 2021-02-18 0000080420-21-000016 — 5.07
- 2021-02-02 0000080420-21-000010 — 2.02, 8.01, 9.01
- 2020-12-08 0000080420-20-000032 — 2.02, 9.01
- 2020-11-12 0000080420-20-000030 — 8.01, 9.01
- 2020-08-04 0000080420-20-000024 — 2.02, 8.01, 9.01
- 2020-05-05 0000080420-20-000017 — 2.02, 8.01, 9.01
- 2020-02-21 0000080420-20-000008 — 5.07
- 2020-02-04 0000080420-20-000003 — 2.02, 8.01, 9.01
- 2019-12-04 0001193125-19-306243 — 2.02, 9.01
- 2019-11-08 0000080420-19-000032 — 8.01, 9.01
- 2019-10-03 0000080420-19-000030 — 1.01, 2.03
- 2019-09-24 0000080420-19-000028 — 8.01, 9.01
- 2019-08-06 0000080420-19-000022 — 2.02, 8.01, 9.01
- 2019-05-08 0000080420-19-000017 — 5.02, 9.01
- 2019-05-07 0000080420-19-000011 — 2.02, 8.01, 9.01
- 2019-02-22 0001193125-19-048366 — 5.07
- 2019-02-05 0000080420-19-000003 — 2.02, 8.01
- 2018-12-21 0000080420-18-000038 — 5.02, 9.01
- 2018-12-12 0000080420-18-000031 — 2.02
- 2018-11-05 0000080420-18-000029 — 8.01, 9.01
- 2018-11-01 0000080420-18-000027 — 5.02, 8.01, 9.01
- 2018-10-01 0000080420-18-000024 — 5.02
- 2018-08-07 0000080420-18-000020 — 2.02, 8.01
- 2018-05-15 0000080420-18-000016 — 5.02, 8.01
- 2018-05-09 0000080420-18-000011 — 2.02, 8.01
- 2018-02-22 0000080420-18-000009 — 5.07
- 2018-02-06 0000080420-18-000003 — 2.02, 8.01
- 2017-12-27 0001193125-17-379928 — 5.02
- 2017-12-05 0000080420-17-000028 — 2.02, 9.01
- 2017-11-08 0000080420-17-000024 — 8.01, 9.01
- 2017-11-03 0000080420-17-000022 — 5.02
- 2017-08-09 0000080420-17-000017 — 2.02, 8.01
- 2017-06-30 0000080420-17-000014 — 1.01, 9.01
- 2017-05-03 0000080420-17-000006 — 2.02, 8.01, 9.01
- 2017-02-23 0000080420-17-000004 — 5.07
- 2017-02-08 0001628280-17-000965 — 2.02 — amendment of 0001628280-17-000949
- 2017-02-07 0001628280-17-000949 — 2.01, 8.01, 9.01
- 2016-12-07 0001193125-16-787354 — 2.02, 9.01
- 2016-11-01 0001193125-16-755475 — 8.01, 9.01
- 2016-09-30 0001193125-16-726999 — 5.02, 8.01, 9.01
- 2016-08-03 0001193125-16-669308 — 2.02, 8.01, 9.01
- 2016-05-04 0001193125-16-576528 — 2.02, 8.01, 9.01
- 2016-02-25 0001193125-16-477896 — 5.07
- 2016-02-03 0001193125-16-449052 — 2.02, 8.01, 9.01
- 2015-12-31 0001193125-15-418363 — 5.02, 7.01, 9.01
- 2015-12-02 0001193125-15-393109 — 2.02, 9.01
- 2015-11-05 0001193125-15-368085 — 8.01, 9.01
- 2015-09-25 0001193125-15-329031 — 5.02
- 2015-08-05 0001193125-15-277912 — 2.02, 8.01, 9.01
- 2015-05-06 0001193125-15-174291 — 2.02, 8.01, 9.01
- 2015-03-06 0001193125-15-081070 — 5.02
- 2015-03-02 0001193125-15-072946 — 5.07
- 2015-02-03 0001193125-15-031772 — 2.02, 8.01, 9.01
- 2014-12-18 0001193125-14-446513 — 8.01, 9.01
- 2014-12-03 0001193125-14-431745 — 2.02, 9.01
- 2014-11-05 0001193125-14-397955 — 8.01, 9.01
- 2014-09-26 0001193125-14-353741 — 7.01, 9.01
- 2014-08-05 0001193125-14-296001 — 2.02, 8.01, 9.01
- 2014-05-07 0001193125-14-187496 — 2.02, 8.01, 9.01
- 2014-03-03 0001193125-14-079843 — 5.02, 5.07
- 2014-02-05 0001193125-14-036633 — 2.02, 8.01, 9.01
- 2014-01-17 0001193125-14-014351 — 1.01, 8.01, 9.01
- 2014-01-06 0001193125-14-002795 — 1.01, 2.03
- 2013-12-06 0001564590-13-001411 — 2.02, 9.01
- 2013-12-05 0001564590-13-001406 — 5.02, 8.01, 9.01
- 2013-11-07 0001193125-13-432950 — 8.01, 9.01
- 2013-08-07 0001193125-13-324337 — 2.02, 9.01
- 2013-05-08 0001193125-13-206800 — 2.02, 9.01
- 2013-02-22 0001193125-13-070971 — 5.02, 5.07
- 2013-02-06 0001193125-13-040556 — 2.02, 9.01
- 2012-12-18 0001193125-12-506417 — 5.02, 9.01
- 2012-12-05 0001193125-12-491749 — 2.02, 9.01
- 2012-10-12 0001193125-12-421889 — 3.03, 5.02, 5.03, 9.01
- 2012-08-09 0001193125-12-344617 — 5.02, 8.01, 9.01
- 2012-08-08 0001193125-12-343630 — 2.02, 9.01
- 2012-05-09 0001193125-12-221356 — 2.02, 9.01
- 2012-02-08 0001193125-12-046560 — 2.02, 9.01
- 2011-12-08 0001193125-11-334810 — 2.02, 9.01
- 2011-11-08 0000950123-11-096524 — 2.02, 2.06, 4.02, 9.01
- 2011-10-14 0000950123-11-090124 — 5.02
- 2011-10-06 0000950123-11-088969 — 5.02
- 2011-09-19 0000950123-11-085224 — 5.02, 9.01
- 2011-09-15 0000950123-11-084806 — 5.02, 9.01
- 2011-08-04 0000950123-11-072788 — 2.02, 9.01
- 2011-07-22 0000950123-11-067402 — 5.07
- 2011-05-24 0000950123-11-053550 — 1.01, 2.03, 9.01
- 2011-05-04 0000950123-11-044561 — 2.02, 9.01
- 2011-02-02 0000950123-11-008188 — 2.02, 9.01
- 2010-12-08 0000950123-10-111987 — 2.02, 9.01
- 2010-08-05 0000950123-10-073114 — 2.02, 9.01
- 2010-05-18 0000950123-10-050900 — 5.02
- 2010-05-05 0000950123-10-044499 — 2.02, 9.01
- 2010-02-03 0000950123-10-008278 — 2.02, 9.01
- 2009-12-21 0000950123-09-072269 — 1.01, 2.01, 2.03, 8.01, 9.01
- 2009-12-09 0000950123-09-069525 — 2.02, 9.01
- 2009-10-27 0000950123-09-053501 — 1.01, 8.01, 9.01
- 2009-08-04 0000950123-09-029476 — 2.02, 9.01
- 2009-05-06 0000950129-09-001498 — 2.02, 9.01
- 2009-03-05 0000950129-09-000749 — 1.01, 9.01
- 2009-02-10 0000950129-09-000349 — 2.02, 9.01
- 2008-12-10 0000950134-08-021934 — 2.02, 9.01
- 2008-08-06 0000950129-08-004267 — 2.02, 9.01
- 2008-07-24 0000950129-08-004063 — 1.01, 5.02, 8.01, 9.01
- 2008-06-16 0000950129-08-003500 — 9.01 — amendment of 0000950134-06-015374
- 2008-06-05 0000950129-08-003378 — 5.02, 9.01
- 2008-05-08 0000950129-08-002843 — 2.02, 9.01
- 2008-02-06 0000950129-08-000533 — 2.02, 9.01
- 2007-12-19 0000950129-07-006277 — 1.01, 2.03, 9.01
- 2007-12-06 0000950129-07-006003 — 2.02, 9.01
- 2007-08-21 0000950129-07-004181 — 2.02, 9.01
- 2007-05-31 0000950129-07-002810 — 2.02, 9.01
- 2007-05-21 0000950129-07-002668 — 2.02, 3.01, 4.02, 9.01
- 2007-04-16 0000950129-07-002002 — 2.02, 4.02, 9.01
- 2007-03-01 0000950129-07-001104 — 5.02, 8.01, 9.01
- 2007-02-08 0000950129-07-000451 — 2.02, 9.01
- 2006-12-08 0000950129-06-010041 — 2.02, 9.01
- 2006-09-08 0000950129-06-008379 — 2.02, 9.01
- 2006-08-09 0000950134-06-015374 — 1.01, 2.01, 8.01, 9.01
- 2006-06-08 0000950129-06-006127 — 2.02, 9.01
- 2006-03-09 0000950129-06-002455 — 2.02, 9.01
- 2005-12-16 0000950129-05-012031 — 2.02, 5.03, 9.01
- 2005-09-13 0000950129-05-009181 — 2.01, 9.01 — amendment of 0000950129-05-006889
- 2005-09-12 0000950129-05-009151 — 2.02, 9.01
- 2005-07-06 0000950129-05-006889 — 1.01, 1.02, 2.01, 2.03, 9.01
- 2005-06-10 0000950129-05-006128 — 2.02, 9.01
- 2005-04-20 0000080420-05-000031 — 5.02
- 2005-03-11 0000080420-05-000024 — 9.01
- 2005-02-25 0000080420-05-000018 — 7.01, 9.01
- 2005-01-21 0000080420-05-000009 — 7.01, 9.01
- 2004-12-17 0000080420-04-000049 — 2.02, 9.01
- 2004-11-01 0000080420-04-000045 — 8.01, 9.01
- 2004-10-08 0001169232-04-005133 — 2.05
- 2004-09-14 0000080420-04-000037 — 5.02
- 2004-09-02 0000080420-04-000030 — 2.02, 9.01
- 2004-06-08 0000080420-04-000021 — 7
- 2004-05-13 0000080420-04-000019 — 4
- 2004-02-27 0000080420-04-000013 — 7
- 2003-12-16 0000950129-03-006136 — 12, 7
- 2003-08-29 0000950129-03-004531 — 12, 7
- 2003-06-03 0000950129-03-003035 — 7, 9
- 2003-05-15 0000950129-03-002812 — 7, 9
- 2002-05-29 0000950129-02-002795 — 4
- 2000-12-21 0000950129-00-006093 — 5, 7
- 1998-09-04 0000950129-98-003802 — 5
- 1996-08-09 0000950129-96-001705 — 2, 7

## late-filing notifications on or before 2021-05-05

- 2007-05-11 0000950129-07-002494 — NT 10-Q, for the period ended 2007-03-31
- 2005-01-18 0000080420-05-000004 — NT 10-K, for the period ended 2004-10-31

## item 2.02 — earnings release, exhibit 99.1

[0000080420-21-000026:8k_2_02:1]
EX-99.1
2
ex991-q221earningsrelease.htm
EX-99.1

[0000080420-21-000026:8k_2_02:2]
Document

[0000080420-21-000026:8k_2_02:3]
Exhibit 99.1

[0000080420-21-000026:8k_2_02:4]
PRESS RELEASE

[0000080420-21-000026:8k_2_02:5]
For immediate release

[0000080420-21-000026:8k_2_02:6]
Contacts:    Michael W. Metcalf, CFO

[0000080420-21-000026:8k_2_02:7]
Powell Industries, Inc.

[0000080420-21-000026:8k_2_02:8]
713-947-4422

[0000080420-21-000026:8k_2_02:9]
Robert Winters or Ryan Coleman

[0000080420-21-000026:8k_2_02:10]
Alpha IR Group

[0000080420-21-000026:8k_2_02:11]
POWL@alpha-ir.com

[0000080420-21-000026:8k_2_02:12]
312-445-2870

[0000080420-21-000026:8k_2_02:13]
POWELL INDUSTRIES ANNOUNCES FISCAL 2021 SECOND QUARTER RESULTS

[0000080420-21-000026:8k_2_02:14]
HOUSTON — May 4, 2021 — Powell Industries, Inc. (NASDAQ: POWL), a leading supplier of custom-engineered solutions for the management, control and distribution of electrical energy, today announced results for the fiscal 2021 second quarter ended March 31, 2021.

[0000080420-21-000026:8k_2_02:15]
Fiscal Second Quarter Key Highlights:

[0000080420-21-000026:8k_2_02:16]
•Revenues totaled $119 million;

[0000080420-21-000026:8k_2_02:17]
•Backlog as of March 31, 2021 totaled $437 million;

[0000080420-21-000026:8k_2_02:18]
•Net Loss was $0.2 million, or a $0.02 loss per diluted share;

[0000080420-21-000026:8k_2_02:19]
•Cash and short-term investments as of March 31, 2021 totaled $154 million.

[0000080420-21-000026:8k_2_02:20]
Brett A. Cope, Powell’s Chairman and Chief Executive Officer, stated, “Our consolidated revenues for the second quarter were in-line with our expectations and higher by 11% sequentially.   Additionally, we were pleased with our cash performance, generating $6 million of free cash flow during the quarter. New orders in the second quarter were $89 million, consistent with the prior quarter, as macroeconomic conditions continue to create uncertainty across our Industrial end-markets.  That was partially offset by the steady growth across our non-Industrial sectors, specifically, revenues from our Utility and Traction customers, which grew 17% and 9%, respectively, compared to last year. I want to acknowledge the hard work of our

[0000080420-21-000026:8k_2_02:21]
team, as these results are in spite of the extraordinary winter storm that adversely affected our Houston based facilities for nearly a full week in February.”

[0000080420-21-000026:8k_2_02:22]
Revenues for the second quarter of fiscal 2021 totaled $118.7 million compared to $106.6 million in the first fiscal quarter of 2021 and $151.6 million in the second fiscal quarter of 2020.

[0000080420-21-000026:8k_2_02:23]
New orders in the second quarter totaled $89 million compared to $91 million of new orders in the first quarter of 2021 and $301 million of new orders in the second quarter of fiscal 2020. The $301 million of new orders during the comparable period of the prior year was attributable to the Company’s largest ever Industrial award to support the design, manufacture, integration and testing of a custom-integrated electrical distribution solution for an industrial complex being constructed in the United States. Backlog as of March 31, 2021 totaled $437 million which represents a sequential decline of 6% and compares to $566 million as of March 31, 2020.

[0000080420-21-000026:8k_2_02:24]
Net loss for the second fiscal quarter was $0.2 million, or a $0.02 loss per diluted share, compared to a first fiscal quarter net loss of $0.4 million, or a loss of $0.03 per diluted share.  Net income in the second quarter of fiscal 2020 was $7.4 million, or $0.64 per diluted share.

[0000080420-21-000026:8k_2_02:25]
Mr. Cope added, “I am pleased with the level of execution across the company despite the challenging conditions in our core Oil, Gas and Petrochemical markets.  We have a strong focus on maximizing productivity while identifying accretive growth opportunities as we continue to work closely with our customers to adapt to the current environment.”

[0000080420-21-000026:8k_2_02:26]
OUTLOOK

[0000080420-21-000026:8k_2_02:27]
Commenting on the Company's outlook, Michael Metcalf, Powell’s Chief Financial Officer said, “Our expectation for a challenging environment across our core Industrial markets throughout the remainder of fiscal 2021 remains unchanged. However, we maintain our positive outlook across our Utility and Traction markets.  Additionally, we are encouraged by the prospects of more nascent opportunities for Powell within the energy markets of hydrogen, biofuels and biodiesel, as well as select opportunities in the mining sector. From a cost perspective, we have most recently encountered modest inflationary cost pressure across key commodities such as copper and steel during the second quarter and expect this to continue

[0000080420-21-000026:8k_2_02:28]
through the remainder of fiscal 2021.  Nonetheless, our balance sheet remains essentially debt-free and we continue to maintain a strong cash position. We remain acutely focused on factors within our control as we navigate the remainder of the year.”

[0000080420-21-000026:8k_2_02:29]
CONFERENCE CALL

[0000080420-21-000026:8k_2_02:30]
Powell Industries has scheduled a conference call for Wednesday, May 5, 2021 at 11:00 a.m. Eastern time.   To participate in the conference call, dial 877-270-2148 at least 10 minutes before the call begins and ask for the Powell Industries conference call.  A replay of the call will be available approximately two hours after the live broadcast ends and will be accessible until May 12, 2021.  To access the replay, dial 877-344-7529 using a passcode of 10154642#.

[0000080420-21-000026:8k_2_02:31]
Investors, analysts and the general public will also have the opportunity to listen to the conference call over the Internet by visiting powellind.com. To listen to the live call on the web, please visit the website at least 15 minutes before the call begins to register, download and install any necessary audio software.  For those who cannot listen to the live webcast, an archive will be available shortly after the call and will remain available for approximately 90 days at powellind.com.

[0000080420-21-000026:8k_2_02:32]
Powell Industries, Inc., headquartered in Houston, designs, manufactures and services custom-engineered equipment and systems for the distribution, control and monitoring of electrical energy.  Powell markets include large industrial customers such as utilities, oil and gas producers, refineries, liquefied natural gas facilities, petrochemical plants, pulp and paper producers, mining operations and commuter railways. For more information, please visit powellind.com.

[0000080420-21-000026:8k_2_02:33]
3

[0000080420-21-000026:8k_2_02:34]
POWELL INDUSTRIES, INC. & SUBSIDIARIES

[0000080420-21-000026:8k_2_02:35]
CONDENSED CONSOLIDATED STATEMENT OF OPERATIONS

[0000080420-21-000026:8k_2_02:36]
|  | Three Months EndedMarch 31, |  | Six Months EndedMarch 31, |
|  | 2021 |  | 2020 |  | 2021 |  | 2020 |
| (In thousands, except per share data) |  |  |  |  |  |  |  |
|  | (Unaudited) |
| Revenues | $ | 118,716 |  |  | $ | 151,570 |  |  | $ | 225,291 |  |  | $ | 285,720 |  |
| Cost of goods sold | 101,563 |  |  | 121,885 |  |  | 189,867 |  |  | 234,209 |  |
| Gross profit | 17,153 |  | 29,685 |  | 35,424 |  | 51,511 |
| Selling, general and administrative expenses | 16,675 |  |  | 18,573 |  |  | 33,549 |  |  | 35,861 |  |
| Research and development expenses | 1,601 |  |  | 1,783 |  |  | 3,274 |  |  | 3,258 |  |
| Amortization of intangible assets | 44 |  |  | 44 |  |  | 88 |  |  | 88 |  |
| Operating income (loss) | (1,167) |  |  | 9,285 |  |  | (1,487) |  |  | 12,304 |  |
| Interest expense | 51 |  |  | 60 |  |  | 101 |  |  | 127 |  |
| Interest income | (47) |  |  | (330) |  |  | (158) |  |  | (711) |  |
| Income (loss) before income taxes | (1,171) |  |  | 9,555 |  |  | (1,430) |  |  | 12,888 |  |
| Income tax provision (benefit) | (946) |  |  | 2,134 |  |  | (841) |  |  | 2,692 |  |
| Net income (loss) | $ | (225) |  |  | $ | 7,421 |  |  | $ | (589) |  |  | $ | 10,196 |  |
| Earnings (loss) per share: |  |  |  |  |  |  |  |
| Basic | $ | (0.02) |  |  | $ | 0.64 |  |  | $ | (0.05) |  |  | $ | 0.88 |  |
| Diluted | $ | (0.02) |  |  | $ | 0.64 |  |  | $ | (0.05) |  |  | $ | 0.87 |  |
| Weighted average shares: |  |  |  |  |  |  |  |
| Basic | 11,707 |  |  | 11,621 |  |  | 11,690 |  |  | 11,617 |  |
| Diluted | 11,707 |  |  | 11,681 |  |  | 11,690 |  |  | 11,673 |  |
| SELECTED FINANCIAL DATA: |  |  |  |  |  |  |  |
| Depreciation and Amortization | $ | 2,659 |  |  | $ | 2,644 |  |  | $ | 5,289 |  |  | $ | 5,241 |  |
| Capital Expenditures | $ | 662 |  |  | $ | 1,080 |  |  | $ | 1,623 |  |  | $ | 3,502 |  |
| Dividends Paid | $ | 3,035 |  |  | $ | 3,015 |  |  | $ | 6,063 |  |  | $ | 6,028 |  |

[0000080420-21-000026:8k_2_02:37]
5

[0000080420-21-000026:8k_2_02:38]
POWELL INDUSTRIES, INC. & SUBSIDIARIES

[0000080420-21-000026:8k_2_02:39]
CONDENSED CONSOLIDATED BALANCE SHEETS

[0000080420-21-000026:8k_2_02:40]
|  | March 31, 2021 |  | September 30, 2020 |
| (In thousands) | (Unaudited) |
| Assets: |  |  |  |
| Cash, cash equivalents and short-term investments | $ | 153,945 |  |  | $ | 178,921 |  |
| Other current assets | 148,843 |  |  | 156,737 |  |
| Property, plant and equipment, net | 113,653 |  |  | 114,372 |  |
| Long-term assets | 24,307 |  |  | 22,248 |  |
| Total assets | $ | 440,748 |  |  | $ | 472,278 |  |
| Liabilities and equity: |  |  |  |
| Current liabilities | $ | 120,955 |  |  | $ | 152,947 |  |
| Long-term debt, net of current maturities | — |  |  | 400 |  |
| Deferred and other long-term liabilities | 13,461 |  | 12,305 |
| Stockholders’ equity | 306,332 |  |  | 306,626 |  |
| Total liabilities and stockholders’ equity | $ | 440,748 |  |  | $ | 472,278 |  |
| SELECTED FINANCIAL DATA: |  |  |  |
| Working capital | $ | 181,833 |  |  | $ | 182,711 |  |

[0000080420-21-000026:8k_2_02:41]
6
