# POWL note change history — 0000080420-21-000013 → 0000080420-21-000029


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2021-05-05):
[0000080420-21-000029:note_history:1]
Certain customers require us to post letters of credit, bank guarantees or surety bonds. These security instruments assure that we will perform under the terms of our contract. In the event of default, the counterparty may demand payment from the bank under a letter of credit or bank guarantee, or performance by the surety under a bond. To date, there have been no significant draws or claims related to security instruments for the periods reported. We were contingently liable for letters of credit of $38.6 million as of March 31, 2021. We also had surety bonds totaling $173.4 million that were outstanding, with additional bonding capacity of $276.6 million available, at March 31, 2021. At present, we have strong surety relationships; however a change in market conditions or the sureties' assessment of our financial position could cause the sureties to require cash collateralization for undischarged liabilities under the bonds.
  (was, 2021-02-03, similarity 0.8294):
[0000080420-21-000013:note_history:1]
Certain customers require us to post letters of credit, bank guarantees or surety bonds. These security instruments assure that we will perform under the terms of our contract. In the event of default, the counterparty may demand payment from the bank under a letter of credit or bank guarantee, or performance by the surety under a bond. To date, there have been no significant draws or claims related to security instruments for the periods reported. We were contingently liable for letters of credit of $38.9 million as of December 31, 2020. We also had surety bonds totaling $185.0 million that were outstanding, with additional bonding capacity of $565.0 million available, at December 31, 2020.

- changed (2021-05-05):
[0000080420-21-000029:note_history:2]
We have a $9.6 million facility agreement (Facility Agreement) between Powell (UK) Limited and a large international bank that provides Powell (UK) Limited the ability to enter into bank guarantees as well as forward exchange contracts and currency options. At March 31, 2021, we had outstanding guarantees totaling $6.8 million and amounts available under this Facility Agreement were $2.8 million. The Facility Agreement expires in May 2021 and provides for financial covenants and customary events of default, and carries cross-default provisions with our U.S. Revolver. If an event of default (as defined in the Facility Agreement) occurs and is continuing, per the terms and subject to the conditions set forth therein, obligations outstanding under the Facility Agreement may be accelerated and declared immediately due and payable. Additionally, we are required to maintain cash collateral for guarantees greater than two years. As of March 31, 2021, we were in compliance with all of the financial covenants of the Facility Agreement.
  (was, 2021-02-03, similarity 0.9768):
[0000080420-21-000013:note_history:2]
We have a $9.6 million facility agreement (Facility Agreement) between Powell (UK) Limited and a large international bank that provides Powell (UK) Limited the ability to enter into bank guarantees as well as forward exchange contracts and currency options. At December 31, 2020, we had outstanding guarantees totaling $7.6 million and amounts available under this Facility Agreement were $2.0 million. The Facility Agreement provides for financial covenants and customary events of default, and carries cross-default provisions with our U.S. Revolver. If an event of default (as defined in the Facility Agreement) occurs and is continuing, per the terms and subject to the conditions set forth therein, obligations outstanding under the Facility Agreement may be accelerated and declared immediately due and payable. Additionally, we are required to maintain cash collateral for guarantees greater than two years. As of December 31, 2020, we were in compliance with all of the financial covenants of the Facility Agreement.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureAndSignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2021-05-05):
[0000080420-21-000029:note_history:3]
Through the first half of Fiscal 2021, the COVID-19 pandemic continues to significantly impact global economic conditions. This pandemic has negatively impacted energy demand, which in turn has resulted in considerable volatility across global oil and gas commodity markets. As a result, some of our industrial customers are deferring or suspending their planned capital expenditures. Certain of our customers have asked that we delay or cancel our manufacturing on their projects as their operations have been negatively impacted by this pandemic and the reduced oil and gas demand which has resulted in recognition of cancellation fees based on contract terms and the extent of our progress on the projects. We continue to work with and review the contracts with our key suppliers who have been impacted by this pandemic to ensure that we are able to meet our customer commitments.
  (was, 2021-02-03, similarity 0.7006):
[0000080420-21-000013:note_history:3]
Through the first fiscal quarter of 2021, the COVID-19 pandemic continues to significantly impact global economic conditions. This pandemic has negatively impacted energy demand, which in turn has resulted in considerable volatility across global oil and gas commodity markets. As a result, some of our industrial customers are deferring or suspending their planned capital expenditures. Certain of our customers have asked that we delay or cancel our manufacturing on their projects as their operations have been negatively impacted by this pandemic and the reduced oil and gas demand. We continue to work with and review the contracts with our key suppliers who have been impacted by this pandemic to ensure that we are able to meet our customer commitments.

- added (2021-05-05):
[0000080420-21-000029:note_history:4]
The consequences of a prolonged global economic decline could include, but are not limited to, a continued reduction in commercial and industrial activity. Accordingly, the Company cannot reasonably estimate the duration or severity of this pandemic, or the extent to which the disruption may materially impact our business, results of operations or cash flows. We will take prudent measures to maintain our strong liquidity and cash position, which may include reducing our capital expenditures and research and development costs, as well as reducing or eliminating future dividend payments.

- changed (2021-05-05):
[0000080420-21-000029:note_history:5]
The preparation of condensed consolidated financial statements in conformity with U.S. GAAP requires management to make estimates and assumptions that affect the amounts reported in the condensed consolidated financial statements and accompanying footnotes. The most significant estimates used in our condensed consolidated financial statements affect revenue recognition and estimated cost recognition on our customer contracts, the allowance for credit losses, provision for excess and obsolete inventory, warranty accruals and income taxes. The amounts recorded for warranties, legal, income taxes, impairment of long-lived assets (when applicable), liquidated damages and other contingent liabilities require judgments regarding the amount of expenses that will ultimately be incurred. We base our estimates on historical experience, forecasts and various other assumptions, as well as the specific circumstances surrounding these contingent liabilities, in evaluating the amount of liability that should be recorded. Additionally, the recognition of deferred tax assets requires estimates related to future income and other assumptions regarding timing and future profitability because the ultimate realization of net deferred tax assets is dependent on the generation of future taxable income during the periods in which temporary differences become deductible. Estimates routinely change as new events occur, additional information becomes available or operating environments change. Actual results may differ from our prior estimates.
  (was, 2021-02-03, similarity 0.9844):
[0000080420-21-000013:note_history:5]
The preparation of condensed consolidated financial statements in conformity with U.S. GAAP requires management to make estimates and assumptions that affect the amounts reported in the condensed consolidated financial statements and accompanying footnotes. The most significant estimates used in our condensed consolidated financial statements affect revenue recognition and estimated cost recognition on our customer contracts, the allowance for doubtful accounts, provision for excess and obsolete inventory, warranty accruals and income taxes. The amounts recorded for warranties, legal, income taxes, impairment of long-lived assets (when applicable) and other contingent liabilities require judgments regarding the amount of expenses that will ultimately be incurred. We base our estimates on historical experience, forecasts and various other assumptions, as well as the specific circumstances surrounding these contingent liabilities, in evaluating the amount of liability that should be recorded. Additionally, the recognition of deferred tax assets requires estimates related to future income and other assumptions regarding timing and future profitability because the ultimate realization of net deferred tax assets is dependent on the generation of future taxable income during the periods in which temporary differences become deductible. Estimates routinely change as new events occur, additional information becomes available or operating environments change. Actual results may differ from our prior estimates.

- removed (2021-05-05):
[0000080420-21-000013:note_history:6]
The consequences of a prolonged economic decline could include, but are not limited to, a continued reduction in commercial and industrial activity. Accordingly, the Company cannot reasonably estimate the duration or severity of this pandemic, or the extent to which the disruption may materially impact our business, results of operations or cash flows. We will take prudent measures to maintain our strong liquidity and cash position, which may include reducing our capital expenditures and research and development costs, as well as reducing or eliminating future dividend payments.


## us-gaap:LongTermDebtTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2021-05-05):
[0000080420-21-000029:note_history:7]
|  | March 31, 2021 |  | September 30, 2020 |
| Industrial development revenue bonds | $ | 400 |  |  | $ | 800 |  |
| Less: current portion | (400) |  |  | (400) |  |
| Total long-term debt | $ | — |  |  | $ | 400 |  |
  (was, 2021-02-03, similarity 0.9761):
[0000080420-21-000013:note_history:7]
|  | December 31, 2020 |  | September 30, 2020 |
| Industrial development revenue bonds | $ | 400 |  |  | $ | 800 |  |
| Less: current portion | (400) |  |  | (400) |  |
| Total long-term debt | $ | — |  |  | $ | 400 |  |

- added (2021-05-05):
[0000080420-21-000029:note_history:8]
We have a credit agreement with Bank of America, N.A. (the "U.S. Revolver") which is a $75.0 million revolving credit facility that is available for both borrowings and letters of credit and expires September 27, 2024. On March 12, 2021, we entered into a first amendment to the U.S. Revolver which, among other things, amended certain terms related to the calculation of the consolidated leverage ratio from gross leverage to net leverage. As a result of the first amendment, up to $30 million may be deducted from the amount of letters of credit outstanding (not to be less than zero) when calculating the consolidated funded indebtedness which is a component of the consolidated net leverage ratio. Additionally, we now have the option to cash collateralize all or a portion of the letters of credit outstanding, which would favorably impact the consolidated funded indebtedness calculation and the consolidated net leverage ratio. As of March 31, 2021, there were no amounts borrowed under the U.S. Revolver and letters of credit outstanding were $38.6 million. There was $36.4 million available for the issuance of letters of credit and borrowings under the U.S. Revolver as of March 31, 2021.

- added (2021-05-05):
[0000080420-21-000029:note_history:9]
We are required to maintain certain financial covenants, the most significant of which are a consolidated net leverage ratio less than 3.0 to 1.0 and a consolidated interest coverage ratio of greater than 3.0 to 1.0. The consolidated leverage ratio is our most restrictive covenant and a decrease in our earnings before interest, taxes, depreciation, amortization and stock-based compensation (EBITDAS) could restrict our ability to issue letters of credit and borrow under the U.S. Revolver. Additionally, we must maintain a consolidated cash balance of $30 million at all times, which now can be deducted from the letters of credit outstanding as noted above. The U.S. Revolver also contains a "material adverse effect" clause which is a material change in our operations, business, properties, liabilities or condition (financial or otherwise) or a material impairment of our ability to perform our obligations under our credit agreements. As of March 31, 2021, we were in compliance with all of the financial covenants of the U.S. Revolver.

- changed (2021-05-05):
[0000080420-21-000029:note_history:10]
We borrowed $8.0 million in October 2001 through a loan agreement funded with proceeds from tax-exempt industrial development revenue bonds (Bonds) for the completion of our Northlake, Illinois facility. The Bonds are subject to various covenants, for which we were in compliance at March 31, 2021. The Bonds mature in October 2021 and bear interest at a floating rate determined weekly by the Bonds’ remarketing agent. This interest rate was 0.14% as of March 31, 2021.
  (was, 2021-02-03, similarity 0.8991):
[0000080420-21-000013:note_history:10]
We borrowed $8.0 million in October 2001 through a loan agreement funded with proceeds from tax-exempt industrial development revenue bonds (Bonds) for the completion of our Northlake, Illinois facility. The Bonds are subject to various covenants, for which we were in compliance at December 31, 2020. The Bonds mature in 2021 and bear interest at a floating rate determined weekly by the Bonds’ remarketing agent. This interest rate was 0.24% as of December 31, 2020.

- removed (2021-05-05):
[0000080420-21-000013:note_history:11]
We have a credit agreement with Bank of America, N.A. (the "U.S. Revolver") which is a $75.0 million revolving credit facility that is available for both borrowings and letters of credit and expires September 2024. As of December 31, 2020, there were no amounts borrowed under this facility and letters of credit outstanding were $38.9 million. There was $36.1 million available for the issuance of letters of credit and borrowings under the U.S. Revolver as of December 31, 2020.

- removed (2021-05-05):
[0000080420-21-000013:note_history:12]
We are required to maintain certain financial covenants, the most significant of which are a consolidated leverage ratio less than 3.0 to 1.0 and a consolidated interest coverage ratio of greater than 3.0 to 1.0. The consolidated leverage ratio is our most restrictive covenant and a decrease in our earnings before interest, taxes, depreciation and amortization (EBITDA) could restrict our ability to issue letters of credit under the U.S. Revolver. Additionally, we must maintain a consolidated cash balance of $30 million at all times. The U.S. Revolver also contains a "material adverse effect" clause which is a material change in our operations, business, properties, liabilities or condition (financial or otherwise) or a material impairment of our ability to perform our obligations under our credit agreements. As of December 31, 2020, we were in compliance with all of the financial covenants of the U.S. Revolver.


## us-gaap:ScheduleOfDebtInstrumentsTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2021-05-05):
[0000080420-21-000029:note_history:13]
|  | March 31, 2021 |  | September 30, 2020 |
| Industrial development revenue bonds | $ | 400 |  |  | $ | 800 |  |
| Less: current portion | (400) |  |  | (400) |  |
| Total long-term debt | $ | — |  |  | $ | 400 |  |
  (was, 2021-02-03, similarity 0.9761):
[0000080420-21-000013:note_history:13]
|  | December 31, 2020 |  | September 30, 2020 |
| Industrial development revenue bonds | $ | 400 |  |  | $ | 800 |  |
| Less: current portion | (400) |  |  | (400) |  |
| Total long-term debt | $ | — |  |  | $ | 400 |  |


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2021-05-05):
[0000080420-21-000029:note_history:14]
The following tables present our disaggregated revenue by geographic destination and market sector for the six months ended March 31, 2021 and 2020 (in thousands):
  (was, 2021-02-03, similarity 0.946):
[0000080420-21-000013:note_history:14]
The following tables present our disaggregated revenue by geographic destination and market sector for the three months ended December 31, 2020 and 2019 (in thousands):

- changed (2021-05-05):
[0000080420-21-000029:note_history:15]
|  | Three months ended March 31, |  | Six months ended March 31, |
|  | 2021 |  | 2020 |  | 2021 |  | 2020 |
| United States | $ | 87,939 |  |  | $ | 121,432 |  |  | $ | 168,525 |  |  | $ | 228,510 |  |
| Canada | 17,734 |  |  | 15,407 |  |  | 31,825 |  |  | 29,861 |  |
| Europe, Middle East and Africa | 10,937 |  |  | 8,816 |  |  | 19,193 |  |  | 18,982 |  |
| Asia/Pacific | 2,009 |  |  | 5,456 |  |  | 4,725 |  |  | 7,142 |  |
| Mexico, Central and South America | 97 |  |  | 459 |  |  | 1,023 |  |  | 1,225 |  |
| Total revenues by geographic destination | $ | 118,716 |  |  | $ | 151,570 |  |  | $ | 225,291 |  |  | $ | 285,720 |  |
  (was, 2021-02-03, similarity 0.7057):
[0000080420-21-000013:note_history:15]
|  | Three months ended December 31, |  |  |
|  | 2020 |  | 2019 |  |  |  |  |
| United States | $ | 80,586 |  |  | $ | 107,078 |  |  |  |  |  |
| Canada | 14,091 |  |  | 14,454 |  |  |  |  |  |
| Europe, Middle East and Africa | 8,256 |  |  | 10,166 |  |  |  |  |  |
| Asia/Pacific | 2,716 |  |  | 1,686 |  |  |  |  |  |
| Mexico, Central and South America | 926 |  |  | 766 |  |  |  |  |  |
| Total revenues by geographic destination | $ | 106,575 |  |  | $ | 134,150 |  |  |  |  |  |

- added (2021-05-05):
[0000080420-21-000029:note_history:16]
|  | Three months ended March 31, |  | Six months ended March 31, |
|  | 2021 |  | 2020 |  | 2021 |  | 2020 |
| Oil and gas | $ | 50,142 |  |  | $ | 51,954 |  |  | $ | 90,171 |  |  | $ | 111,948 |  |
| Petrochemical | 10,196 |  |  | 47,337 |  |  | 19,361 |  |  | 77,763 |  |
| Electric utility | 28,452 |  |  | 24,255 |  |  | 56,622 |  |  | 47,270 |  |
| Traction power | 15,140 |  |  | 13,944 |  |  | 28,501 |  |  | 22,295 |  |
| All others | 14,786 |  |  | 14,080 |  |  | 30,636 |  |  | 26,444 |  |
| Total revenues by market sector | $ | 118,716 |  |  | $ | 151,570 |  |  | $ | 225,291 |  |  | $ | 285,720 |  |

- removed (2021-05-05):
[0000080420-21-000013:note_history:17]
|  | Three months ended December 31, |  |  |
|  | 2020 |  | 2019 |  |  |  |  |
| Oil and gas | $ | 40,028 |  |  | $ | 59,994 |  |  |  |  |  |
| Petrochemical | 9,165 |  |  | 30,426 |  |  |  |  |  |
| Electric utility | 28,171 |  |  | 23,015 |  |  |  |  |  |
| Traction power | 13,361 |  |  | 8,351 |  |  |  |  |  |
| All others | 15,850 |  |  | 12,364 |  |  |  |  |  |
| Total revenues by market sector | $ | 106,575 |  |  | $ | 134,150 |  |  |  |  |  |


## us-gaap:RevenueFromContractWithCustomerPolicyTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2021-05-05):
[0000080420-21-000029:note_history:18]
in each reporting period corresponding to the amount with which we have the right to invoice.  Our performance obligations are satisfied as the work progresses. Revenues from our custom-engineered products and value-added services transferred to customers over time accounted for approximately 93% of total revenues for the three months ended March 31, 2021,  92% of total revenues for the six months ended March 31, 2021 and 96% of total revenues for each of the three and six months ended March 31, 2020.
  (was, 2021-02-03, similarity 0.8226):
[0000080420-21-000013:note_history:18]
in each reporting period corresponding to the amount with which we have the right to invoice.  Our performance obligations are satisfied as the work progresses. Revenues from our custom-engineered products and value-added services transferred to customers over time accounted for approximately 92% of total revenues for the three months ended December 31, 2020 and 95% of total revenues for the three months ended December 31, 2019.

- changed (2021-05-05):
[0000080420-21-000029:note_history:19]
We also have sales orders for spare parts and replacement circuit breakers for switchgear that are obsolete or that are no longer produced by the original manufacturer. Revenues from these sales orders are recognized at the time we fulfill our performance obligation to the customer, which is typically upon shipment and represented approximately 7% of total revenues for the three months ended March 31, 2021, 8% of total revenues for the six months ended March 31, 2021 and 4% of total revenues for each of the three and six months ended March 31, 2020.
  (was, 2021-02-03, similarity 0.8416):
[0000080420-21-000013:note_history:19]
We also have sales orders for spare parts and replacement circuit breakers for switchgear that are obsolete or that are no longer produced by the original manufacturer. Revenues from these sales orders are recognized at the time we fulfill our performance obligation to the customer, which is typically upon shipment and represented approximately 8% of total revenues for the three months ended December 31, 2020 and 5% of total revenues for the three months ended December 31, 2019.

- changed (2021-05-05):
[0000080420-21-000029:note_history:20]
A performance obligation is a promise in a contract or with a customer to transfer a distinct good or service. A contract’s transaction price is allocated to each distinct performance obligation and recognized as revenue as the performance obligations are satisfied. To determine the proper revenue recognition for contracts, we evaluate whether a contract should be accounted for as more than one performance obligation or, less commonly, whether two or more contracts should be combined and accounted for as one performance obligation.  This evaluation of performance obligations requires significant judgment.  The majority of our contracts have a single performance obligation where multiple engineered products and services are combined into a single custom-engineered solution. Our contracts include a standard one year assurance warranty. Occasionally, we provide service-type warranties that will extend the warranty period. These extended warranties qualify as a separate performance obligation, and revenue is deferred and recognized over the warranty period. If we determine during the evaluation of the contract that there are multiple performance obligations, we allocate the transaction price to each performance obligation using our best estimate of the standalone selling price of each distinct good or service in the contract. 
Remaining unsatisfied performance obligations, which we refer to as backlog, represent the estimated transaction price for goods and services for which we have a material right, but work has not been performed.
Contract Estimates
  (was, 2021-02-03, similarity 0.9696):
[0000080420-21-000013:note_history:20]
A performance obligation is a promise in a contract or with a customer to transfer a distinct good or service. A contract’s transaction price is allocated to each distinct performance obligation and recognized as revenue as the performance obligations are satisfied. To determine the proper revenue recognition for contracts, we evaluate whether a contract should be accounted for as more than one performance obligation or, less commonly, whether two or more contracts should be combined and accounted for as one performance obligation.  This evaluation of performance obligations requires significant judgment.  The majority of our contracts have a single performance obligation where multiple engineered products and services are combined into a single custom-engineered solution. Our contracts generally include a standard assurance warranty that typically ends 18 months after shipment. Occasionally, we provide service-type warranties that will extend the warranty period. These extended warranties qualify as a separate performance obligation, and revenue is deferred and recognized over the warranty period. If we determine during the evaluation of the contract that there are multiple performance obligations, we allocate the transaction price to each performance obligation using our best estimate of the standalone selling price of each distinct good or service in the contract. 
Remaining unsatisfied performance obligations, which we refer to as backlog, represent the estimated transaction price for goods and services for which we have a material right, but work has not been performed.
Contract Estimates

- changed (2021-05-05):
[0000080420-21-000029:note_history:21]
Contract liabilities typically represent advance payments from contractual billing milestones and billings in excess of revenue recognized. It is unusual to have advanced milestone payments with a term greater than one year, which could represent a financing component on the contract.  
Our contract assets and liabilities are reported in a net position on a contract-by-contract basis at the end of each reporting period and are generally classified as current.The timing of our invoice process is typically dependent on the completion of certain milestones and contract terms and subject to agreement by our customer.  Payment is typically expected within 30 days of invoice. Any uncollected invoiced amounts for our performance obligations recognized over time, including contract retentions, are recorded as accounts receivable in the Condensed Consolidated Balance Sheets. Certain contracts contain retention provisions that become due upon completion of contractual requirements.
  (was, 2021-02-03, similarity 0.9118):
[0000080420-21-000013:note_history:21]
Contract liabilities typically represent advance payments from contractual billing milestones and billings in excess of revenue recognized. It is unusual to have advanced milestone payments with a term greater than one year, which could represent a financing component on the contract.  
Our contract assets and liabilities are reported in a net position on a contract-by-contract basis at the end of each reporting period and are generally classified as current. The timing of contract billing milestones related to our Fiscal 2020 contract award for a large industrial project contributed significantly to our net contract liability at September 30, 2020 and The timing of our invoice process is typically dependent on the completion of certain milestones and contract terms and subject to agreement by our customer.  Payment is typically expected within 30 days of invoice. Any uncollected invoiced amounts for our performance obligations recognized over time, including contract retentions, are recorded as accounts receivable in the Condensed Consolidated Balance Sheets. Certain contracts contain retention provisions that become due upon completion of contractual requirements.


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2021-05-05):
[0000080420-21-000029:note_history:22]
in each reporting period corresponding to the amount with which we have the right to invoice.  Our performance obligations are satisfied as the work progresses. Revenues from our custom-engineered products and value-added services transferred to customers over time accounted for approximately 93% of total revenues for the three months ended March 31, 2021,  92% of total revenues for the six months ended March 31, 2021 and 96% of total revenues for each of the three and six months ended March 31, 2020.
  (was, 2021-02-03, similarity 0.8226):
[0000080420-21-000013:note_history:22]
in each reporting period corresponding to the amount with which we have the right to invoice.  Our performance obligations are satisfied as the work progresses. Revenues from our custom-engineered products and value-added services transferred to customers over time accounted for approximately 92% of total revenues for the three months ended December 31, 2020 and 95% of total revenues for the three months ended December 31, 2019.

- changed (2021-05-05):
[0000080420-21-000029:note_history:23]
We also have sales orders for spare parts and replacement circuit breakers for switchgear that are obsolete or that are no longer produced by the original manufacturer. Revenues from these sales orders are recognized at the time we fulfill our performance obligation to the customer, which is typically upon shipment and represented approximately 7% of total revenues for the three months ended March 31, 2021, 8% of total revenues for the six months ended March 31, 2021 and 4% of total revenues for each of the three and six months ended March 31, 2020.
  (was, 2021-02-03, similarity 0.8416):
[0000080420-21-000013:note_history:23]
We also have sales orders for spare parts and replacement circuit breakers for switchgear that are obsolete or that are no longer produced by the original manufacturer. Revenues from these sales orders are recognized at the time we fulfill our performance obligation to the customer, which is typically upon shipment and represented approximately 8% of total revenues for the three months ended December 31, 2020 and 5% of total revenues for the three months ended December 31, 2019.

- changed (2021-05-05):
[0000080420-21-000029:note_history:24]
A performance obligation is a promise in a contract or with a customer to transfer a distinct good or service. A contract’s transaction price is allocated to each distinct performance obligation and recognized as revenue as the performance obligations are satisfied. To determine the proper revenue recognition for contracts, we evaluate whether a contract should be accounted for as more than one performance obligation or, less commonly, whether two or more contracts should be combined and accounted for as one performance obligation.  This evaluation of performance obligations requires significant judgment.  The majority of our contracts have a single performance obligation where multiple engineered products and services are combined into a single custom-engineered solution. Our contracts include a standard one year assurance warranty. Occasionally, we provide service-type warranties that will extend the warranty period. These extended warranties qualify as a separate performance obligation, and revenue is deferred and recognized over the warranty period. If we determine during the evaluation of the contract that there are multiple performance obligations, we allocate the transaction price to each performance obligation using our best estimate of the standalone selling price of each distinct good or service in the contract.
  (was, 2021-02-03, similarity 0.9644):
[0000080420-21-000013:note_history:24]
A performance obligation is a promise in a contract or with a customer to transfer a distinct good or service. A contract’s transaction price is allocated to each distinct performance obligation and recognized as revenue as the performance obligations are satisfied. To determine the proper revenue recognition for contracts, we evaluate whether a contract should be accounted for as more than one performance obligation or, less commonly, whether two or more contracts should be combined and accounted for as one performance obligation.  This evaluation of performance obligations requires significant judgment.  The majority of our contracts have a single performance obligation where multiple engineered products and services are combined into a single custom-engineered solution. Our contracts generally include a standard assurance warranty that typically ends 18 months after shipment. Occasionally, we provide service-type warranties that will extend the warranty period. These extended warranties qualify as a separate performance obligation, and revenue is deferred and recognized over the warranty period. If we determine during the evaluation of the contract that there are multiple performance obligations, we allocate the transaction price to each performance obligation using our best estimate of the standalone selling price of each distinct good or service in the contract.

- changed (2021-05-05):
[0000080420-21-000029:note_history:25]
Remaining unsatisfied performance obligations, which we refer to as backlog, represent the estimated transaction price for goods and services for which we have a material right, but work has not been performed. As of March 31, 2021, we had backlog of $436.6 million, of which approximately $322.7 million is expected to be recognized as revenue within the next twelve months. Backlog may not be indicative of future operating results as orders may be cancelled or modified by our customers. Our backlog does not include service and maintenance-type contracts for which we have the right to invoice as services are performed.
  (was, 2021-02-03, similarity 0.9894):
[0000080420-21-000013:note_history:25]
Remaining unsatisfied performance obligations, which we refer to as backlog, represent the estimated transaction price for goods and services for which we have a material right, but work has not been performed. As of December 31, 2020, we had backlog of $464.9 million, of which approximately $306.8 million is expected to be recognized as revenue within the next twelve months. Backlog may not be indicative of future operating results as orders may be cancelled or modified by our customers. Our backlog does not include service and maintenance-type contracts for which we have the right to invoice as services are performed.

- changed (2021-05-05):
[0000080420-21-000029:note_history:26]
For the six months ended March 31, 2021 and 2020, our operating results were positively impacted by $8.2 million and $9.0 million, respectively, as a result of changes in contract estimates related to projects in progress at the beginning of the respective period. These changes in estimates resulted primarily from favorable project execution and negotiations of variable consideration, discussed below, as well as revenue and reduced costs recognized from project cancellations and other changes in facts and circumstances during these periods.
  (was, 2021-02-03, similarity 0.9542):
[0000080420-21-000013:note_history:26]
For the three months ended December 31, 2020 and 2019, our operating results were positively impacted by $5.5 million and $4.3 million, respectively, as a result of changes in contract estimates related to projects in progress at the beginning of the respective period. These changes in estimates resulted primarily from favorable project execution and negotiations of variable consideration, discussed below, as well as revenue and reduced costs recognized from project cancellations and other changes in facts and circumstances during these periods.

- changed (2021-05-05):
[0000080420-21-000029:note_history:27]
Our contract assets and liabilities are reported in a net position on a contract-by-contract basis at the end of each reporting period and are generally classified as current. The timing of contract billing milestones related to our Fiscal 2020 contract award for a large industrial project contributed significantly to our net contract liability at September 30, 2020 and March 31, 2021.
  (was, 2021-02-03, similarity 0.9747):
[0000080420-21-000013:note_history:27]
Our contract assets and liabilities are reported in a net position on a contract-by-contract basis at the end of each reporting period and are generally classified as current. The timing of contract billing milestones related to our Fiscal 2020 contract award for a large industrial project contributed significantly to our net contract liability at September 30, 2020 and December 31, 2020.

- changed (2021-05-05):
[0000080420-21-000029:note_history:28]
Contract assets and liabilities as of March 31, 2021 and September 30, 2020 are summarized below (in thousands):
  (was, 2021-02-03, similarity 0.9565):
[0000080420-21-000013:note_history:28]
Contract assets and liabilities as of December 31, 2020 and September 30, 2020 are summarized below (in thousands):

- changed (2021-05-05):
[0000080420-21-000029:note_history:29]
|  | March 31, 2021 |  | September 30, 2020 |
| Contract assets | $ | 42,728 |  |  | $ | 50,995 |  |
| Contract liabilities | (54,098) |  |  | (79,445) |  |
| Net contract liability | $ | (11,370) |  |  | $ | (28,450) |  |
  (was, 2021-02-03, similarity 0.9739):
[0000080420-21-000013:note_history:29]
|  | December 31, 2020 |  | September 30, 2020 |
| Contract assets | $ | 47,886 |  |  | $ | 50,995 |  |
| Contract liabilities | (70,939) |  |  | (79,445) |  |
| Net contract liability | $ | (23,053) |  |  | $ | (28,450) |  |

- changed (2021-05-05):
[0000080420-21-000029:note_history:30]
The decrease in net contract liability at March 31, 2021 from September 30, 2020 was primarily due to the timing of contract billing milestones and new orders. To determine the amount of revenue recognized during the period from contract liabilities, we first allocate revenue to the individual contract liability balance outstanding at the beginning of the period until the revenue exceeds that balance. During the six months ended March 31, 2021, we recognized revenue of approximately $55.2 million that was related to contract liabilities outstanding at September 30, 2020.
  (was, 2021-02-03, similarity 0.7266):
[0000080420-21-000013:note_history:30]
The decrease in net contract liability at December 31, 2020 from September 30, 2020 was primarily due to the timing of contract billing milestones and new orders. To determine the amount of revenue recognized during the period from contract liabilities, we first allocate revenue to the individual contract liability balance outstanding at the beginning of the period until the revenue exceeds that balance. During the three months ended December 31, 2020, we recognized revenue of approximately $36.4 million that was related to contract liabilities outstanding at September 30, 2020.

- changed (2021-05-05):
[0000080420-21-000029:note_history:31]
The timing of our invoice process is typically dependent on the completion of certain milestones and contract terms and subject to agreement by our customer.  Payment is typically expected within 30 days of invoice. Any uncollected invoiced amounts for our performance obligations recognized over time, including contract retentions, are recorded as accounts receivable in the Condensed Consolidated Balance Sheets. Certain contracts contain retention provisions that become due upon completion of contractual requirements. As of March 31, 2021 and September 30, 2020, accounts receivable included retention amounts of $8.8 million and $6.9 million, respectively. Of the retained amount at March 31, 2021, $7.1 million is expected to be collected in the next twelve months and is recorded in accounts receivable. The remaining $1.7 million is recorded in other assets.
  (was, 2021-02-03, similarity 0.9846):
[0000080420-21-000013:note_history:31]
The timing of our invoice process is typically dependent on the completion of certain milestones and contract terms and subject to agreement by our customer.  Payment is typically expected within 30 days of invoice. Any uncollected invoiced amounts for our performance obligations recognized over time, including contract retentions, are recorded as accounts receivable in the Condensed Consolidated Balance Sheets. Certain contracts contain retention provisions that become due upon completion of contractual requirements. As of December 31, 2020 and September 30, 2020, accounts receivable included retention amounts of $7.8 million and $6.9 million, respectively. Of the retained amount at December 31, 2020, $6.1 million is expected to be collected in the next twelve months and is recorded in accounts receivable. The remaining $1.7 million is recorded in other assets.

- changed (2021-05-05):
[0000080420-21-000029:note_history:32]
The following tables present our disaggregated revenue by geographic destination and market sector for the six months ended March 31, 2021 and 2020 (in thousands):
  (was, 2021-02-03, similarity 0.946):
[0000080420-21-000013:note_history:32]
The following tables present our disaggregated revenue by geographic destination and market sector for the three months ended December 31, 2020 and 2019 (in thousands):

- changed (2021-05-05):
[0000080420-21-000029:note_history:33]
|  | Three months ended March 31, |  | Six months ended March 31, |
|  | 2021 |  | 2020 |  | 2021 |  | 2020 |
| United States | $ | 87,939 |  |  | $ | 121,432 |  |  | $ | 168,525 |  |  | $ | 228,510 |  |
| Canada | 17,734 |  |  | 15,407 |  |  | 31,825 |  |  | 29,861 |  |
| Europe, Middle East and Africa | 10,937 |  |  | 8,816 |  |  | 19,193 |  |  | 18,982 |  |
| Asia/Pacific | 2,009 |  |  | 5,456 |  |  | 4,725 |  |  | 7,142 |  |
| Mexico, Central and South America | 97 |  |  | 459 |  |  | 1,023 |  |  | 1,225 |  |
| Total revenues by geographic destination | $ | 118,716 |  |  | $ | 151,570 |  |  | $ | 225,291 |  |  | $ | 285,720 |  |
  (was, 2021-02-03, similarity 0.7057):
[0000080420-21-000013:note_history:33]
|  | Three months ended December 31, |  |  |
|  | 2020 |  | 2019 |  |  |  |  |
| United States | $ | 80,586 |  |  | $ | 107,078 |  |  |  |  |  |
| Canada | 14,091 |  |  | 14,454 |  |  |  |  |  |
| Europe, Middle East and Africa | 8,256 |  |  | 10,166 |  |  |  |  |  |
| Asia/Pacific | 2,716 |  |  | 1,686 |  |  |  |  |  |
| Mexico, Central and South America | 926 |  |  | 766 |  |  |  |  |  |
| Total revenues by geographic destination | $ | 106,575 |  |  | $ | 134,150 |  |  |  |  |  |

- added (2021-05-05):
[0000080420-21-000029:note_history:34]
|  | Three months ended March 31, |  | Six months ended March 31, |
|  | 2021 |  | 2020 |  | 2021 |  | 2020 |
| Oil and gas | $ | 50,142 |  |  | $ | 51,954 |  |  | $ | 90,171 |  |  | $ | 111,948 |  |
| Petrochemical | 10,196 |  |  | 47,337 |  |  | 19,361 |  |  | 77,763 |  |
| Electric utility | 28,452 |  |  | 24,255 |  |  | 56,622 |  |  | 47,270 |  |
| Traction power | 15,140 |  |  | 13,944 |  |  | 28,501 |  |  | 22,295 |  |
| All others | 14,786 |  |  | 14,080 |  |  | 30,636 |  |  | 26,444 |  |
| Total revenues by market sector | $ | 118,716 |  |  | $ | 151,570 |  |  | $ | 225,291 |  |  | $ | 285,720 |  |

- removed (2021-05-05):
[0000080420-21-000013:note_history:35]
|  | Three months ended December 31, |  |  |
|  | 2020 |  | 2019 |  |  |  |  |
| Oil and gas | $ | 40,028 |  |  | $ | 59,994 |  |  |  |  |  |
| Petrochemical | 9,165 |  |  | 30,426 |  |  |  |  |  |
| Electric utility | 28,171 |  |  | 23,015 |  |  |  |  |  |
| Traction power | 13,361 |  |  | 8,351 |  |  |  |  |  |
| All others | 15,850 |  |  | 12,364 |  |  |  |  |  |
| Total revenues by market sector | $ | 106,575 |  |  | $ | 134,150 |  |  |  |  |  |


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: tag_name, score: 1.0

- changed (2021-05-05):
[0000080420-21-000029:note_history:36]
On May 4, 2021, our Board of Directors declared a quarterly cash dividend on our common stock in the amount of $0.26 per share. The dividend is payable on June 16, 2021 to shareholders of record at the close of business on May 19, 2021.
  (was, 2021-02-03, similarity 0.6517):
[0000080420-21-000013:note_history:36]
On February 2, 2021, our Board of Directors declared a quarterly cash dividend on our common stock in the amount of $0.26 per share. The dividend is payable on March 17, 2021 to shareholders of record at the close of business on February 17, 2021.
