# POWL notes — 0000080420-21-000029


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureAndSignificantAccountingPoliciesTextBlock

[0000080420-21-000029:notes:1]
[same as prior period, unchanged from 0000080420-21-000013:notes:1]

[0000080420-21-000029:notes:2]
[same as prior period, unchanged from 0000080420-21-000013:notes:2]

[0000080420-21-000029:notes:3]
[same as prior period, unchanged from 0000080420-21-000013:notes:3]

[0000080420-21-000029:notes:4]
[same as prior period, unchanged from 0000080420-21-000013:notes:4]

[0000080420-21-000029:notes:5]
Through the first half of Fiscal 2021, the COVID-19 pandemic continues to significantly impact global economic conditions. This pandemic has negatively impacted energy demand, which in turn has resulted in considerable volatility across global oil and gas commodity markets. As a result, some of our industrial customers are deferring or suspending their planned capital expenditures. Certain of our customers have asked that we delay or cancel our manufacturing on their projects as their operations have been negatively impacted by this pandemic and the reduced oil and gas demand which has resulted in recognition of cancellation fees based on contract terms and the extent of our progress on the projects. We continue to work with and review the contracts with our key suppliers who have been impacted by this pandemic to ensure that we are able to meet our customer commitments.

[0000080420-21-000029:notes:6]
The consequences of a prolonged global economic decline could include, but are not limited to, a continued reduction in commercial and industrial activity. Accordingly, the Company cannot reasonably estimate the duration or severity of this pandemic, or the extent to which the disruption may materially impact our business, results of operations or cash flows. We will take prudent measures to maintain our strong liquidity and cash position, which may include reducing our capital expenditures and research and development costs, as well as reducing or eliminating future dividend payments.

[0000080420-21-000029:notes:7]
[same as prior period, unchanged from 0000080420-21-000013:notes:7]

[0000080420-21-000029:notes:8]
[same as prior period, unchanged from 0000080420-21-000013:notes:8]

[0000080420-21-000029:notes:9]
[same as prior period, unchanged from 0000080420-21-000013:notes:9]

[0000080420-21-000029:notes:10]
[same as prior period, unchanged from 0000080420-21-000013:notes:10]

[0000080420-21-000029:notes:11]
[same as prior period, unchanged from 0000080420-21-000013:notes:11]

[0000080420-21-000029:notes:12]
[same as prior period, unchanged from 0000080420-21-000013:notes:12]

[0000080420-21-000029:notes:13]
The preparation of condensed consolidated financial statements in conformity with U.S. GAAP requires management to make estimates and assumptions that affect the amounts reported in the condensed consolidated financial statements and accompanying footnotes. The most significant estimates used in our condensed consolidated financial statements affect revenue recognition and estimated cost recognition on our customer contracts, the allowance for credit losses, provision for excess and obsolete inventory, warranty accruals and income taxes. The amounts recorded for warranties, legal, income taxes, impairment of long-lived assets (when applicable), liquidated damages and other contingent liabilities require judgments regarding the amount of expenses that will ultimately be incurred. We base our estimates on historical experience, forecasts and various other assumptions, as well as the specific circumstances surrounding these contingent liabilities, in evaluating the amount of liability that should be recorded. Additionally, the recognition of deferred tax assets requires estimates related to future income and other assumptions regarding timing and future profitability because the ultimate realization of net deferred tax assets is dependent on the generation of future taxable income during the periods in which temporary differences become deductible. Estimates routinely change as new events occur, additional information becomes available or operating environments change. Actual results may differ from our prior estimates.

[0000080420-21-000029:notes:14]
[same as prior period, unchanged from 0000080420-21-000013:notes:14]

[0000080420-21-000029:notes:15]
[same as prior period, unchanged from 0000080420-21-000013:notes:15]


## us-gaap:EarningsPerShareTextBlock

[0000080420-21-000029:notes:16]
[same as prior period, unchanged from 0000080420-21-000013:notes:16]

[0000080420-21-000029:notes:17]
[same as prior period, unchanged from 0000080420-21-000013:notes:17]

[0000080420-21-000029:notes:18]
|  | Three months ended March 31, |  | Six months ended March 31, |
|  | 2021 |  | 2020 |  | 2021 |  | 2020 |
| Numerator: |  |  |  |  |  |  |  |
| Net income (loss) | $ | (225) |  |  | $ | 7,421 |  |  | $ | (589) |  |  | $ | 10,196 |  |
| Denominator: |  |  |  |  |  |  |  |
| Weighted average basic shares | 11,707 |  |  | 11,621 |  |  | 11,690 |  |  | 11,617 |  |
| Dilutive effect of restricted stock units | — |  |  | 60 |  |  | — |  |  | 56 |  |
| Weighted average diluted shares | 11,707 |  |  | 11,681 |  |  | 11,690 |  |  | 11,673 |  |
| Earnings (loss) per share: |  |  |  |  |  |  |  |
| Basic | $ | (0.02) |  |  | $ | 0.64 |  |  | $ | (0.05) |  |  | $ | 0.88 |  |
| Diluted | $ | (0.02) |  |  | $ | 0.64 |  |  | $ | (0.05) |  |  | $ | 0.87 |  |

[0000080420-21-000029:notes:19]
For the three and six months ended March 31, 2021, we incurred a net loss and therefore all potential common shares were deemed to be anti-dilutive.


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0000080420-21-000029:notes:20]
Detail of Selected Balance Sheet Accounts
Allowance for Credit Losses

[0000080420-21-000029:notes:21]
Activity in our allowance for credit losses consisted of the following (in thousands):

[0000080420-21-000029:notes:22]
|  | Three months ended March 31, |  | Six months ended March 31, |
|  | 2021 |  | 2020 |  | 2021 |  | 2020 |
| Balance at beginning of period | $ | 493 |  |  | $ | 346 |  |  | $ | 510 |  |  | $ | 301 |  |
| Bad debt expense (recovery), net | (113) |  |  | 9 |  |  | (132) |  |  | 51 |  |
| Uncollectible accounts written off, net of recoveries | — |  |  | (45) |  |  | (10) |  |  | (55) |  |
| Change due to foreign currency translation | 2 |  |  | (10) |  |  | 14 |  |  | 3 |  |
| Balance at end of period | $ | 382 |  |  | $ | 300 |  |  | $ | 382 |  |  | $ | 300 |  |

[0000080420-21-000029:notes:23]
[same as prior period, unchanged from 0000080420-21-000013:notes:23]

[0000080420-21-000029:notes:24]
[same as prior period, unchanged from 0000080420-21-000013:notes:24]

[0000080420-21-000029:notes:25]
|  | March 31, 2021 |  | September 30, 2020 |
| Raw materials, parts and sub-assemblies, net | $ | 29,302 |  |  | $ | 27,429 |  |
| Work-in-progress | 729 |  |  | 1,539 |  |
| Total inventories | $ | 30,031 |  |  | $ | 28,968 |  |

[0000080420-21-000029:notes:26]
[same as prior period, unchanged from 0000080420-21-000013:notes:26]

[0000080420-21-000029:notes:27]
[same as prior period, unchanged from 0000080420-21-000013:notes:27]

[0000080420-21-000029:notes:28]
|  | Three months ended March 31, |  | Six months ended March 31, |
|  | 2021 |  | 2020 |  | 2021 |  | 2020 |
| Balance at beginning of period | $ | 2,675 |  |  | $ | 3,162 |  |  | $ | 2,771 |  |  | $ | 2,946 |  |
| Increase to warranty expense | 395 |  |  | 784 |  |  | 1,053 |  |  | 1,627 |  |
| Deduction for warranty charges | (609) |  |  | (670) |  |  | (1,388) |  |  | (1,315) |  |
| Change due to foreign currency translation | 6 |  |  | — |  |  | 31 |  |  | 18 |  |
| Balance at end of period | $ | 2,467 |  |  | $ | 3,276 |  |  | $ | 2,467 |  |  | $ | 3,276 |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0000080420-21-000029:notes:29]
[same as prior period, unchanged from 0000080420-21-000013:notes:29]

[0000080420-21-000029:notes:30]
Our revenues are primarily generated from the manufacturing of custom-engineered products and systems under long-term fixed-price contracts under which we agree to manufacture various products such as traditional and arc-resistant distribution switchgear and control gear, medium-voltage circuit breakers, monitoring and control communications systems, motor control centers, switches and bus duct systems. These products may be sold separately as an engineered solution, but are typically integrated into custom-built enclosures which we also build. These enclosures are referred to as power control room substations (PCRs®), custom-engineered modules or electrical houses (E-Houses). Some contracts may also include the installation and the commissioning of these enclosures.

[0000080420-21-000029:notes:31]
Revenue from these contracts is generally recognized over time utilizing the cost-to-cost method to measure the extent of progress toward the completion of the performance obligation and the recognition of revenue over time. We believe that this method is the most accurate representation of our performance, because it directly measures the value of the services transferred to the customer over time as we incur costs on our contracts. Contract costs include all direct materials, labor, and indirect costs related to contract performance, which may include indirect labor, supplies, tools, repairs and depreciation costs.

[0000080420-21-000029:notes:32]
[same as prior period, unchanged from 0000080420-21-000013:notes:32]

[0000080420-21-000029:notes:33]
in each reporting period corresponding to the amount with which we have the right to invoice.  Our performance obligations are satisfied as the work progresses. Revenues from our custom-engineered products and value-added services transferred to customers over time accounted for approximately 93% of total revenues for the three months ended March 31, 2021,  92% of total revenues for the six months ended March 31, 2021 and 96% of total revenues for each of the three and six months ended March 31, 2020.

[0000080420-21-000029:notes:34]
We also have sales orders for spare parts and replacement circuit breakers for switchgear that are obsolete or that are no longer produced by the original manufacturer. Revenues from these sales orders are recognized at the time we fulfill our performance obligation to the customer, which is typically upon shipment and represented approximately 7% of total revenues for the three months ended March 31, 2021, 8% of total revenues for the six months ended March 31, 2021 and 4% of total revenues for each of the three and six months ended March 31, 2020.

[0000080420-21-000029:notes:35]
[same as prior period, unchanged from 0000080420-21-000013:notes:35]

[0000080420-21-000029:notes:36]
[same as prior period, unchanged from 0000080420-21-000013:notes:36]

[0000080420-21-000029:notes:37]
[same as prior period, unchanged from 0000080420-21-000013:notes:37]

[0000080420-21-000029:notes:38]
A performance obligation is a promise in a contract or with a customer to transfer a distinct good or service. A contract’s transaction price is allocated to each distinct performance obligation and recognized as revenue as the performance obligations are satisfied. To determine the proper revenue recognition for contracts, we evaluate whether a contract should be accounted for as more than one performance obligation or, less commonly, whether two or more contracts should be combined and accounted for as one performance obligation.  This evaluation of performance obligations requires significant judgment.  The majority of our contracts have a single performance obligation where multiple engineered products and services are combined into a single custom-engineered solution. Our contracts include a standard one year assurance warranty. Occasionally, we provide service-type warranties that will extend the warranty period. These extended warranties qualify as a separate performance obligation, and revenue is deferred and recognized over the warranty period. If we determine during the evaluation of the contract that there are multiple performance obligations, we allocate the transaction price to each performance obligation using our best estimate of the standalone selling price of each distinct good or service in the contract.

[0000080420-21-000029:notes:39]
Remaining unsatisfied performance obligations, which we refer to as backlog, represent the estimated transaction price for goods and services for which we have a material right, but work has not been performed. As of March 31, 2021, we had backlog of $436.6 million, of which approximately $322.7 million is expected to be recognized as revenue within the next twelve months. Backlog may not be indicative of future operating results as orders may be cancelled or modified by our customers. Our backlog does not include service and maintenance-type contracts for which we have the right to invoice as services are performed.

[0000080420-21-000029:notes:40]
[same as prior period, unchanged from 0000080420-21-000013:notes:40]

[0000080420-21-000029:notes:41]
[same as prior period, unchanged from 0000080420-21-000013:notes:41]

[0000080420-21-000029:notes:42]
For the six months ended March 31, 2021 and 2020, our operating results were positively impacted by $8.2 million and $9.0 million, respectively, as a result of changes in contract estimates related to projects in progress at the beginning of the respective period. These changes in estimates resulted primarily from favorable project execution and negotiations of variable consideration, discussed below, as well as revenue and reduced costs recognized from project cancellations and other changes in facts and circumstances during these periods.

[0000080420-21-000029:notes:43]
[same as prior period, unchanged from 0000080420-21-000013:notes:43]

[0000080420-21-000029:notes:44]
[same as prior period, unchanged from 0000080420-21-000013:notes:44]

[0000080420-21-000029:notes:45]
[same as prior period, unchanged from 0000080420-21-000013:notes:45]

[0000080420-21-000029:notes:46]
[same as prior period, unchanged from 0000080420-21-000013:notes:46]

[0000080420-21-000029:notes:47]
[same as prior period, unchanged from 0000080420-21-000013:notes:47]

[0000080420-21-000029:notes:48]
[same as prior period, unchanged from 0000080420-21-000013:notes:48]

[0000080420-21-000029:notes:49]
[same as prior period, unchanged from 0000080420-21-000013:notes:49]

[0000080420-21-000029:notes:50]
[same as prior period, unchanged from 0000080420-21-000013:notes:50]

[0000080420-21-000029:notes:51]
Our contract assets and liabilities are reported in a net position on a contract-by-contract basis at the end of each reporting period and are generally classified as current. The timing of contract billing milestones related to our Fiscal 2020 contract award for a large industrial project contributed significantly to our net contract liability at September 30, 2020 and March 31, 2021.

[0000080420-21-000029:notes:52]
Contract assets and liabilities as of March 31, 2021 and September 30, 2020 are summarized below (in thousands):

[0000080420-21-000029:notes:53]
|  | March 31, 2021 |  | September 30, 2020 |
| Contract assets | $ | 42,728 |  |  | $ | 50,995 |  |
| Contract liabilities | (54,098) |  |  | (79,445) |  |
| Net contract liability | $ | (11,370) |  |  | $ | (28,450) |  |

[0000080420-21-000029:notes:54]
The decrease in net contract liability at March 31, 2021 from September 30, 2020 was primarily due to the timing of contract billing milestones and new orders. To determine the amount of revenue recognized during the period from contract liabilities, we first allocate revenue to the individual contract liability balance outstanding at the beginning of the period until the revenue exceeds that balance. During the six months ended March 31, 2021, we recognized revenue of approximately $55.2 million that was related to contract liabilities outstanding at September 30, 2020.

[0000080420-21-000029:notes:55]
The timing of our invoice process is typically dependent on the completion of certain milestones and contract terms and subject to agreement by our customer.  Payment is typically expected within 30 days of invoice. Any uncollected invoiced amounts for our performance obligations recognized over time, including contract retentions, are recorded as accounts receivable in the Condensed Consolidated Balance Sheets. Certain contracts contain retention provisions that become due upon completion of contractual requirements. As of March 31, 2021 and September 30, 2020, accounts receivable included retention amounts of $8.8 million and $6.9 million, respectively. Of the retained amount at March 31, 2021, $7.1 million is expected to be collected in the next twelve months and is recorded in accounts receivable. The remaining $1.7 million is recorded in other assets.

[0000080420-21-000029:notes:56]
[same as prior period, unchanged from 0000080420-21-000013:notes:56]

[0000080420-21-000029:notes:57]
The following tables present our disaggregated revenue by geographic destination and market sector for the six months ended March 31, 2021 and 2020 (in thousands):

[0000080420-21-000029:notes:58]
|  | Three months ended March 31, |  | Six months ended March 31, |
|  | 2021 |  | 2020 |  | 2021 |  | 2020 |
| United States | $ | 87,939 |  |  | $ | 121,432 |  |  | $ | 168,525 |  |  | $ | 228,510 |  |
| Canada | 17,734 |  |  | 15,407 |  |  | 31,825 |  |  | 29,861 |  |
| Europe, Middle East and Africa | 10,937 |  |  | 8,816 |  |  | 19,193 |  |  | 18,982 |  |
| Asia/Pacific | 2,009 |  |  | 5,456 |  |  | 4,725 |  |  | 7,142 |  |
| Mexico, Central and South America | 97 |  |  | 459 |  |  | 1,023 |  |  | 1,225 |  |
| Total revenues by geographic destination | $ | 118,716 |  |  | $ | 151,570 |  |  | $ | 225,291 |  |  | $ | 285,720 |  |

[0000080420-21-000029:notes:59]
|  | Three months ended March 31, |  | Six months ended March 31, |
|  | 2021 |  | 2020 |  | 2021 |  | 2020 |
| Oil and gas | $ | 50,142 |  |  | $ | 51,954 |  |  | $ | 90,171 |  |  | $ | 111,948 |  |
| Petrochemical | 10,196 |  |  | 47,337 |  |  | 19,361 |  |  | 77,763 |  |
| Electric utility | 28,452 |  |  | 24,255 |  |  | 56,622 |  |  | 47,270 |  |
| Traction power | 15,140 |  |  | 13,944 |  |  | 28,501 |  |  | 22,295 |  |
| All others | 14,786 |  |  | 14,080 |  |  | 30,636 |  |  | 26,444 |  |
| Total revenues by market sector | $ | 118,716 |  |  | $ | 151,570 |  |  | $ | 225,291 |  |  | $ | 285,720 |  |


## us-gaap:RevenueFromContractWithCustomerPolicyTextBlock

[0000080420-21-000029:notes:60]
[same as prior period, unchanged from 0000080420-21-000013:notes:60]

[0000080420-21-000029:notes:61]
[same as prior period, unchanged from 0000080420-21-000013:notes:61]

[0000080420-21-000029:notes:62]
A performance obligation is a promise in a contract or with a customer to transfer a distinct good or service. A contract’s transaction price is allocated to each distinct performance obligation and recognized as revenue as the performance obligations are satisfied. To determine the proper revenue recognition for contracts, we evaluate whether a contract should be accounted for as more than one performance obligation or, less commonly, whether two or more contracts should be combined and accounted for as one performance obligation.  This evaluation of performance obligations requires significant judgment.  The majority of our contracts have a single performance obligation where multiple engineered products and services are combined into a single custom-engineered solution. Our contracts include a standard one year assurance warranty. Occasionally, we provide service-type warranties that will extend the warranty period. These extended warranties qualify as a separate performance obligation, and revenue is deferred and recognized over the warranty period. If we determine during the evaluation of the contract that there are multiple performance obligations, we allocate the transaction price to each performance obligation using our best estimate of the standalone selling price of each distinct good or service in the contract. 
Remaining unsatisfied performance obligations, which we refer to as backlog, represent the estimated transaction price for goods and services for which we have a material right, but work has not been performed.
Contract Estimates

[0000080420-21-000029:notes:63]
Contract liabilities typically represent advance payments from contractual billing milestones and billings in excess of revenue recognized. It is unusual to have advanced milestone payments with a term greater than one year, which could represent a financing component on the contract.  
Our contract assets and liabilities are reported in a net position on a contract-by-contract basis at the end of each reporting period and are generally classified as current.The timing of our invoice process is typically dependent on the completion of certain milestones and contract terms and subject to agreement by our customer.  Payment is typically expected within 30 days of invoice. Any uncollected invoiced amounts for our performance obligations recognized over time, including contract retentions, are recorded as accounts receivable in the Condensed Consolidated Balance Sheets. Certain contracts contain retention provisions that become due upon completion of contractual requirements.


## us-gaap:LongTermDebtTextBlock

[0000080420-21-000029:notes:64]
Long-Term Debt
Long-term debt consisted of the following (in thousands):

[0000080420-21-000029:notes:65]
|  | March 31, 2021 |  | September 30, 2020 |
| Industrial development revenue bonds | $ | 400 |  |  | $ | 800 |  |
| Less: current portion | (400) |  |  | (400) |  |
| Total long-term debt | $ | — |  |  | $ | 400 |  |

[0000080420-21-000029:notes:66]
U.S. Revolver

[0000080420-21-000029:notes:67]
We have a credit agreement with Bank of America, N.A. (the "U.S. Revolver") which is a $75.0 million revolving credit facility that is available for both borrowings and letters of credit and expires September 27, 2024. On March 12, 2021, we entered into a first amendment to the U.S. Revolver which, among other things, amended certain terms related to the calculation of the consolidated leverage ratio from gross leverage to net leverage. As a result of the first amendment, up to $30 million may be deducted from the amount of letters of credit outstanding (not to be less than zero) when calculating the consolidated funded indebtedness which is a component of the consolidated net leverage ratio. Additionally, we now have the option to cash collateralize all or a portion of the letters of credit outstanding, which would favorably impact the consolidated funded indebtedness calculation and the consolidated net leverage ratio. As of March 31, 2021, there were no amounts borrowed under the U.S. Revolver and letters of credit outstanding were $38.6 million. There was $36.4 million available for the issuance of letters of credit and borrowings under the U.S. Revolver as of March 31, 2021.

[0000080420-21-000029:notes:68]
We are required to maintain certain financial covenants, the most significant of which are a consolidated net leverage ratio less than 3.0 to 1.0 and a consolidated interest coverage ratio of greater than 3.0 to 1.0. The consolidated leverage ratio is our most restrictive covenant and a decrease in our earnings before interest, taxes, depreciation, amortization and stock-based compensation (EBITDAS) could restrict our ability to issue letters of credit and borrow under the U.S. Revolver. Additionally, we must maintain a consolidated cash balance of $30 million at all times, which now can be deducted from the letters of credit outstanding as noted above. The U.S. Revolver also contains a "material adverse effect" clause which is a material change in our operations, business, properties, liabilities or condition (financial or otherwise) or a material impairment of our ability to perform our obligations under our credit agreements. As of March 31, 2021, we were in compliance with all of the financial covenants of the U.S. Revolver.

[0000080420-21-000029:notes:69]
The U.S. Revolver allows the Company to elect that any borrowing under the facility bears an interest rate based on either the base rate or the eurocurrency rate, in each case, plus the applicable rate. The base rate is generally the highest of (a) the federal funds rate plus 0.50%, (b) the Bank of America prime rate or (c) the London Interbank Offered Rate (LIBOR) plus 1.00%. The applicable rate is generally a range from (0.25)% to 1.75% depending on the type of loan and the Company's consolidated leverage ratio.

[0000080420-21-000029:notes:70]
The U.S. Revolver is collateralized by a pledge of 100% of the voting capital stock of each of our domestic subsidiaries and 65% of the voting capital stock of each non-domestic subsidiary. The U.S. Revolver provides for customary events of default and carries cross-default provisions with other existing debt agreements. If an event of default (as defined in the U.S. Revolver) occurs and is continuing, on the terms and subject to the conditions set forth in the U.S. Revolver, amounts and letters of credit outstanding under the U.S. Revolver may be accelerated and may become immediately due and payable.

[0000080420-21-000029:notes:71]
Industrial Development Revenue Bonds

[0000080420-21-000029:notes:72]
We borrowed $8.0 million in October 2001 through a loan agreement funded with proceeds from tax-exempt industrial development revenue bonds (Bonds) for the completion of our Northlake, Illinois facility. The Bonds are subject to various covenants, for which we were in compliance at March 31, 2021. The Bonds mature in October 2021 and bear interest at a floating rate determined weekly by the Bonds’ remarketing agent. This interest rate was 0.14% as of March 31, 2021.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0000080420-21-000029:notes:73]
Commitments and Contingencies
Letters of Credit, Bank Guarantees and Bonds

[0000080420-21-000029:notes:74]
Certain customers require us to post letters of credit, bank guarantees or surety bonds. These security instruments assure that we will perform under the terms of our contract. In the event of default, the counterparty may demand payment from the bank under a letter of credit or bank guarantee, or performance by the surety under a bond. To date, there have been no significant draws or claims related to security instruments for the periods reported. We were contingently liable for letters of credit of $38.6 million as of March 31, 2021. We also had surety bonds totaling $173.4 million that were outstanding, with additional bonding capacity of $276.6 million available, at March 31, 2021. At present, we have strong surety relationships; however a change in market conditions or the sureties' assessment of our financial position could cause the sureties to require cash collateralization for undischarged liabilities under the bonds.

[0000080420-21-000029:notes:75]
We have a $9.6 million facility agreement (Facility Agreement) between Powell (UK) Limited and a large international bank that provides Powell (UK) Limited the ability to enter into bank guarantees as well as forward exchange contracts and currency options. At March 31, 2021, we had outstanding guarantees totaling $6.8 million and amounts available under this Facility Agreement were $2.8 million. The Facility Agreement expires in May 2021 and provides for financial covenants and customary events of default, and carries cross-default provisions with our U.S. Revolver. If an event of default (as defined in the Facility Agreement) occurs and is continuing, per the terms and subject to the conditions set forth therein, obligations outstanding under the Facility Agreement may be accelerated and declared immediately due and payable. Additionally, we are required to maintain cash collateral for guarantees greater than two years. As of March 31, 2021, we were in compliance with all of the financial covenants of the Facility Agreement.

[0000080420-21-000029:notes:76]
Litigation

[0000080420-21-000029:notes:77]
We are involved in various legal proceedings, claims and other disputes arising from our commercial operations, projects, employees and other matters which, in general, are subject to uncertainties and in which the outcomes are not predictable. Although we can give no assurances about the resolution of pending claims, litigation or other disputes and the effect such outcomes may have on us, management believes that any ultimate liability resulting from the outcome of such proceedings, to the extent not otherwise provided or covered by insurance, will not have a material adverse effect on our consolidated financial position or results of operations or liquidity.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0000080420-21-000029:notes:78]
[same as prior period, unchanged from 0000080420-21-000013:notes:78]

[0000080420-21-000029:notes:79]
[same as prior period, unchanged from 0000080420-21-000013:notes:79]

[0000080420-21-000029:notes:80]
We issue restricted stock units (RSUs) to certain officers and key employees of the Company. The fair value of the RSUs is based on the price of our common stock as reported on the NASDAQ Global Market on the grant dates. Typically, these grants vest over a three-year period from the date of issuance and are a blend of time-based and performance-based shares. The portion of the grant that is time-based typically vests over a three-year period on each anniversary of the grant date, based on continued employment. The performance-based shares vest based on the three-year earnings performance of the Company following the grant date. At March 31, 2021, there were 202,836 RSUs outstanding. The RSUs do not have voting rights but do receive dividend equivalents upon vesting. Additionally, the shares of common stock underlying the RSUs are not considered issued and outstanding until vested and common stock is issued.

[0000080420-21-000029:notes:81]
Total RSU activity (number of shares) for the six months ended March 31, 2021 is summarized below:

[0000080420-21-000029:notes:82]
|  | Number ofRestrictedStockUnits |  | WeightedAverageGrant ValuePer Share |
| Outstanding at September 30, 2020 | 154,034 |  |  | $ | 35.37 |  |
| Granted | 104,550 |  |  | 24.08 |  |
| Vested | (55,748) |  |  | 32.50 |  |
| Forfeited/canceled | — |  |  | — |  |
| Outstanding at March 31, 2021 | 202,836 |  |  | $ | 30.34 |  |

[0000080420-21-000029:notes:83]
During the six months ended March 31, 2021 and 2020, we recorded compensation expense of $1.3 million and $1.5 million, respectively, related to the RSUs.

[0000080420-21-000029:notes:84]
Restricted Stock
Each non-employee director receives 2,400 restricted shares of the Company’s common stock annually. Fifty-percent of the restricted stock granted to each of our non-employee directors vests immediately, while the remaining fifty-percent vests on the anniversary of the grant date. Compensation expense is recognized immediately for the first fifty-percent of the restricted stock granted, while compensation expense for the remaining fifty-percent is recognized over the remaining vesting period. In February 2021, 16,800 shares of restricted stock were issued to our non-employee directors under the 2014 Non-Employee Director Equity Incentive Plan at a price of $31.33 per share. During both the six months ended March 31, 2021 and 2020, we recorded compensation expense of $0.4 million related to restricted stock.


## us-gaap:FairValueDisclosuresTextBlock

[0000080420-21-000029:notes:85]
[same as prior period, unchanged from 0000080420-21-000013:notes:85]

[0000080420-21-000029:notes:86]
[same as prior period, unchanged from 0000080420-21-000013:notes:86]

[0000080420-21-000029:notes:87]
[same as prior period, unchanged from 0000080420-21-000013:notes:87]

[0000080420-21-000029:notes:88]
[same as prior period, unchanged from 0000080420-21-000013:notes:88]

[0000080420-21-000029:notes:89]
[same as prior period, unchanged from 0000080420-21-000013:notes:89]

[0000080420-21-000029:notes:90]
The following table summarizes the fair value of our assets and liabilities that were accounted for at fair value on a recurring basis as of March 31, 2021 (in thousands):

[0000080420-21-000029:notes:91]
|  | Fair Value Measurements at March 31, 2021 |
|  | Quoted Prices inActive Markets forIdentical Assets(Level 1) |  | Significant OtherObservableInputs(Level 2) |  | SignificantUnobservableInputs(Level 3) |  | Fair Value at March 31,2021 |
| Assets: |  |  |  |  |  |  |  |
| Cash and cash equivalents | $ | 134,093 |  |  | $ | — |  |  | $ | — |  |  | $ | 134,093 |  |
| Short-term investments | 19,852 |  |  | — |  |  | — |  |  | 19,852 |  |
| Other assets | — |  |  | 8,712 |  |  | — |  |  | 8,712 |  |
| Liabilities: |  |  |  |  |  |  |  |
| Deferred compensation | — |  |  | 8,300 |  |  | — |  |  | 8,300 |  |

[0000080420-21-000029:notes:92]
[same as prior period, unchanged from 0000080420-21-000013:notes:92]

[0000080420-21-000029:notes:93]
|  | Fair Value Measurements at September 30, 2020 |
|  | Quoted Prices inActive Markets forIdentical Assets(Level 1) |  | Significant OtherObservableInputs(Level 2) |  | SignificantUnobservableInputs(Level 3) |  | Fair Value at September 30,2020 |
| Assets: |  |  |  |  |  |  |  |
| Cash and cash equivalents | $ | 160,216 |  |  | $ | — |  |  | $ | — |  |  | $ | 160,216 |  |
| Short-term investments | 18,705 |  |  | — |  |  | — |  |  | 18,705 |  |
| Other assets | — |  |  | 7,351 |  |  | — |  |  | 7,351 |  |
| Liabilities: |  |  |  |  |  |  |  |
| Deferred compensation | — |  |  | 6,569 |  |  | — |  |  | 6,569 |  |

[0000080420-21-000029:notes:94]
[same as prior period, unchanged from 0000080420-21-000013:notes:94]

[0000080420-21-000029:notes:95]
[same as prior period, unchanged from 0000080420-21-000013:notes:95]

[0000080420-21-000029:notes:96]
[same as prior period, unchanged from 0000080420-21-000013:notes:96]

[0000080420-21-000029:notes:97]
[same as prior period, unchanged from 0000080420-21-000013:notes:97]

[0000080420-21-000029:notes:98]
There were no transfers between levels within the fair value measurement hierarchy during the quarter ended March 31, 2021.


## us-gaap:LesseeOperatingLeasesTextBlock

[0000080420-21-000029:notes:99]
Leases
Our leases consist primarily of office and manufacturing space, construction equipment and office equipment. All of our future lease obligations are related to non-cancelable operating leases. The most significant portion of our lease portfolio relates to leases of office and manufacturing facilities in Canada which we no longer occupy. We currently sublease the majority of these Canadian facilities. The following table provides a summary of lease cost components for the three and six months ended March 31, 2021 and 2020, respectively (in thousands):

[0000080420-21-000029:notes:100]
|  |  | Three months ended March 31, |  | Six months ended March 31, |
| Lease Cost |  | 2021 |  | 2020 |  | 2021 |  | 2020 |
| Operating lease cost |  | $ | 629 |  |  | $ | 580 |  |  | $ | 1,237 |  |  | $ | 1,208 |  |
| Less: sublease income |  | (177) |  |  | (158) |  |  | (357) |  |  | (237) |  |
| Variable lease cost(1) |  | 109 |  |  | 84 |  |  | 217 |  |  | 178 |  |
| Short-term lease cost(2) |  | 319 |  |  | 159 |  |  | 488 |  |  | 349 |  |
| Total lease cost |  | $ | 880 |  |  | $ | 665 |  |  | $ | 1,585 |  |  | $ | 1,498 |  |

[0000080420-21-000029:notes:101]
[same as prior period, unchanged from 0000080420-21-000013:notes:101]

[0000080420-21-000029:notes:102]
[same as prior period, unchanged from 0000080420-21-000013:notes:102]

[0000080420-21-000029:notes:103]
We recognize operating lease assets and operating lease liabilities representing the present value of the remaining lease payments for leases with initial terms greater than twelve months. Leases with initial terms of twelve months or less are not recorded in our Condensed Consolidated Balance Sheets. Our operating lease assets have been reduced by a lease accrual of $0.5 million related to certain unused facility leases in Canada. The following table provides a summary of the operating lease assets and operating lease liabilities included in our Condensed Consolidated Balance Sheets as of March 31, 2021 and September 30, 2020, respectively (in thousands):

[0000080420-21-000029:notes:104]
| Operating Leases |  | March 31, 2021 |  | September 30, 2020 |
| Assets: |  |  |  |  |
| Operating lease assets, net |  | $ | 4,390 |  |  | $ | 5,217 |  |
| Liabilities: |  |  |  |  |
| Current operating lease liabilities |  | 1,948 |  |  | 2,352 |  |
| Long-term operating lease liabilities |  | 2,897 |  |  | 3,434 |  |
| Total lease liabilities |  | $ | 4,845 |  |  | $ | 5,786 |  |

[0000080420-21-000029:notes:105]
The following table provides the maturities of our operating lease liabilities as of March 31, 2021 (in thousands):

[0000080420-21-000029:notes:106]
|  |  | Operating Leases |  |  |
| Remainder of 2021 |  | $ | 1,203 |  |  |  |
| 2022 |  | 2,387 |  |  |  |
| 2023 |  | 1,365 |  |  |  |
| 2024 |  | 101 |  |  |  |
| 2025 |  | — |  |  |  |
| Thereafter |  | — |  |  |  |
| Total future minimum lease payments |  | 5,056 |  |  |  |
| Less: present value discount (imputed interest) |  | (211) |  |  |  |
| Present value of lease liabilities |  | $ | 4,845 |  |  |  |

[0000080420-21-000029:notes:107]
The weighted average discount rate as of March 31, 2021 was 4.1%. The weighted average remaining lease term was 2.1 years at March 31, 2021.


## us-gaap:IncomeTaxDisclosureTextBlock

[0000080420-21-000029:notes:108]
[same as prior period, unchanged from 0000080420-21-000013:notes:108]

[0000080420-21-000029:notes:109]
|  | Three months ended March 31, |  | Six months ended March 31, |
|  | 2021 |  | 2020 |  | 2021 |  | 2020 |
| Income (loss) before income taxes | $ | (1,171) |  |  | $ | 9,555 |  |  | $ | (1,430) |  |  | $ | 12,888 |  |
| Income tax provision (benefit) | (946) |  |  | 2,134 |  |  | (841) |  |  | 2,692 |  |
| Net income (loss) | $ | (225) |  |  | $ | 7,421 |  |  | $ | (589) |  |  | $ | 10,196 |  |
| Effective tax rate | 81 | % |  | 22 | % |  | 59 | % |  | 21 | % |

[0000080420-21-000029:notes:110]
Our income tax provision (benefit) reflects an effective tax rate on pre-tax income (loss) of 81% for the second quarter of Fiscal 2021 compared to 22% for the second quarter of Fiscal 2020. For the three and six months ended March 31, 2021, the income tax benefit largely resulted from the relative amounts of income/loss recognized in various tax jurisdictions, the utilization of net operating loss carryforwards in Canada that have been fully reserved with a valuation allowance, and the estimated Research and Development Tax Credit (R&D Tax Credit).

[0000080420-21-000029:notes:111]
The effective tax rate for the three and six months ended March 31, 2020 was favorably impacted by the R&D Tax Credit as well as the projected utilization of net operating loss carryforwards in Canada that were fully reserved with a valuation allowance. These favorable impacts were offset by the valuation allowance recorded against our UK deferred tax assets as a discrete item during the second quarter of Fiscal 2020.


## us-gaap:SubsequentEventsTextBlock

[0000080420-21-000029:notes:112]
Subsequent Events
Quarterly Dividend Declared

[0000080420-21-000029:notes:113]
On May 4, 2021, our Board of Directors declared a quarterly cash dividend on our common stock in the amount of $0.26 per share. The dividend is payable on June 16, 2021 to shareholders of record at the close of business on May 19, 2021.
