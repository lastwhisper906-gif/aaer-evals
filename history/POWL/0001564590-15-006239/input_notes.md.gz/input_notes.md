# POWL notes — 0001564590-15-006239


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureAndSignificantAccountingPoliciesTextBlock

[0001564590-15-006239:notes:1]
[same as prior period, unchanged from 0001564590-15-003392:notes:1]

[0001564590-15-006239:notes:2]
[same as prior period, unchanged from 0001564590-15-003392:notes:2]

[0001564590-15-006239:notes:3]
[same as prior period, unchanged from 0001564590-15-003392:notes:3]

[0001564590-15-006239:notes:4]
[same as prior period, unchanged from 0001564590-15-003392:notes:4]

[0001564590-15-006239:notes:5]
[same as prior period, unchanged from 0001564590-15-003392:notes:5]

[0001564590-15-006239:notes:6]
[same as prior period, unchanged from 0001564590-15-003392:notes:6]

[0001564590-15-006239:notes:7]
[same as prior period, unchanged from 0001564590-15-003392:notes:7]

[0001564590-15-006239:notes:8]
[same as prior period, unchanged from 0001564590-15-003392:notes:8]

[0001564590-15-006239:notes:9]
[same as prior period, unchanged from 0001564590-15-003392:notes:9]

[0001564590-15-006239:notes:10]
[same as prior period, unchanged from 0001564590-15-003392:notes:10]

[0001564590-15-006239:notes:11]
[same as prior period, unchanged from 0001564590-15-003392:notes:11]

[0001564590-15-006239:notes:12]
[same as prior period, unchanged from 0001564590-15-003392:notes:14]

[0001564590-15-006239:notes:13]
In July 2013, the FASB issued accounting guidance on the presentation of an unrecognized tax benefit when a net operating loss carryforward, a similar tax loss, or a tax credit carryforward exists. The guidance states that an unrecognized tax benefit, or a portion of an unrecognized tax benefit, should be presented in the financial statements as a reduction to a deferred tax asset for a net operating loss carryforward, a similar tax loss, or a tax credit carryforward. To the extent a net operating loss carryforward, a similar tax loss, or a tax credit carryforward is not available at the reporting date under the tax law of the applicable jurisdiction to settle any additional income taxes that would result from the disallowance of a tax position or the tax law of the applicable jurisdiction does not require the entity to use, and the entity does not intend to use, the deferred tax asset for such purpose, the unrecognized tax benefit should be presented in the financial statements as a liability and should not be combined with deferred tax assets. This guidance is effective for fiscal years, and interim periods within those years, beginning after December 15, 2013, which would be our fiscal year ending September 30, 2015. This guidance should be applied prospectively to all unrecognized tax benefits that exist at the effective date. Retrospective application is permitted. The adoption of this guidance has not had a significant impact on our consolidated financial position or results of operations.

[0001564590-15-006239:notes:14]
In April 2014, the FASB issued an amendment to the financial reporting of discontinued operations.  The amendments in this update changed the criteria for reporting discontinued operations while enhancing disclosures in this area. It also addresses sources of confusion and inconsistent application related to the financial reporting of discontinued operations guidance in U.S. GAAP.  Under the new guidance, only disposals representing a strategic shift in operations that have a major effect on the organization’s operations and financial results should be presented as discontinued operations. Examples include a disposal of a major geographic area, a major line of business, or a major equity method investment.  In addition, the new guidance requires expanded disclosures about discontinued operations that will provide financial statement users with more information about the assets, liabilities, income, and expenses of discontinued operations.  The new guidance also requires disclosure of the pre-tax income attributable to a disposal of a significant part of an organization that does not qualify for discontinued operations reporting. This disclosure will provide users with information about the ongoing trends in a reporting organization’s results from continuing operations. The amendments in this update are effective in the first quarter of 2015, which would be in our fiscal year ending September 30, 2016.  Early adoption is permitted for disposals that have not been previously reported as discontinued operations. This amendment is not expected to have a material impact on our consolidated financial position or results of operations.

[0001564590-15-006239:notes:15]
In May 2014, the FASB issued a new standard on revenue recognition that supersedes previously issued revenue recognition guidance.  This standard provides a five-step approach to be applied to all contracts with customers and requires expanded disclosures about the nature, amount, timing and uncertainty of revenue (and the related cash flows) arising from customer contracts, significant judgments and changes in judgments used in applying the revenue model and the assets recognized from costs incurred to obtain or fulfill a contract.  The effective date for this standard was deferred in July 2015 and will now be effective for us beginning in fiscal year 2019.  The standard permits the use of either the retrospective or cumulative effect transition method therefore we are evaluating the effect that this new guidance will have on our consolidated financial statements and related disclosures. We have not yet selected a transition method nor have we determined the effect of the standard on our ongoing financial reporting.

[0001564590-15-006239:notes:16]
[same as prior period, unchanged from 0001564590-15-003392:notes:18]

[0001564590-15-006239:notes:17]
[same as prior period, unchanged from 0001564590-15-003392:notes:19]

[0001564590-15-006239:notes:18]
In January 2014, we sold our wholly owned subsidiary Transdyn Inc. (Transdyn).  For the nine months ended June 30, 2014, we have presented the results of these operations as income from discontinued operations, net of tax.  See Note J.


## us-gaap:EarningsPerShareTextBlock

[0001564590-15-006239:notes:19]
[same as prior period, unchanged from 0001564590-15-003392:notes:21]

[0001564590-15-006239:notes:20]
[same as prior period, unchanged from 0001564590-15-003392:notes:22]

[0001564590-15-006239:notes:21]
[same as prior period, unchanged from 0001564590-15-003392:notes:23]

[0001564590-15-006239:notes:22]
|  | Three months ended June 30, |  |  | Nine months ended June 30, |  |
|  | 2015 |  |  | 2014 |  |  | 2015 |  |  | 2014 |  |
| Numerator: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Income from continuing operations | $ | 7,049 |  |  | $ | 2,947 |  |  | $ | 3,127 |  |  | $ | 17,190 |  |
| Income from discontinued operations |  | — |  |  |  | — |  |  |  | — |  |  |  | 9,604 |  |
| Net income | $ | 7,049 |  |  | $ | 2,947 |  |  | $ | 3,127 |  |  | $ | 26,794 |  |
| Denominator: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Weighted average basic shares |  | 11,802 |  |  |  | 12,015 |  |  |  | 11,953 |  |  |  | 12,004 |  |
| Dilutive effect of restricted stock units |  | 43 |  |  |  | 60 |  |  |  | 38 |  |  |  | 59 |  |
| Weighted average diluted shares with assumed conversions |  | 11,845 |  |  |  | 12,075 |  |  |  | 11,991 |  |  |  | 12,063 |  |
| Net earnings per share: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Continuing operations | $ | 0.60 |  |  | $ | 0.25 |  |  | $ | 0.26 |  |  | $ | 1.43 |  |
| Discontinued operations |  | — |  |  |  | — |  |  |  | — |  |  |  | 0.80 |  |
| Basic earnings per share | $ | 0.60 |  |  | $ | 0.25 |  |  | $ | 0.26 |  |  | $ | 2.23 |  |
| Continuing operations | $ | 0.60 |  |  | $ | 0.24 |  |  | $ | 0.26 |  |  | $ | 1.43 |  |
| Discontinued operations |  | — |  |  |  | — |  |  |  | — |  |  |  | 0.80 |  |
| Diluted earnings per share | $ | 0.60 |  |  | $ | 0.24 |  |  | $ | 0.26 |  |  | $ | 2.23 |  |


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0001564590-15-006239:notes:23]
[same as prior period, unchanged from 0001564590-15-003392:notes:26]

[0001564590-15-006239:notes:24]
[same as prior period, unchanged from 0001564590-15-003392:notes:27]

[0001564590-15-006239:notes:25]
[same as prior period, unchanged from 0001564590-15-003392:notes:28]

[0001564590-15-006239:notes:26]
|  | Three months ended June 30, |  |  | Nine months ended June 30, |  |
|  | 2015 |  |  | 2014 |  |  | 2015 |  |  | 2014 |  |
| Balance at beginning of period | $ | 1,881 |  |  | $ | 501 |  |  | $ | 1,577 |  |  | $ | 572 |  |
| Bad debt expense/(recovery) |  | (438 | ) |  |  | 676 |  |  |  | 31 |  |  |  | 616 |  |
| Uncollectible accounts written off, net of recoveries |  | (145 | ) |  |  | (38 | ) |  |  | (267 | ) |  |  | (46 | ) |
| Change in foreign currency translation |  | 14 |  |  |  | 5 |  |  |  | (29 | ) |  |  | 2 |  |
| Balance at end of period | $ | 1,312 |  |  | $ | 1,144 |  |  | $ | 1,312 |  |  | $ | 1,144 |  |

[0001564590-15-006239:notes:27]
[same as prior period, unchanged from 0001564590-15-003392:notes:30]

[0001564590-15-006239:notes:28]
[same as prior period, unchanged from 0001564590-15-003392:notes:31]

[0001564590-15-006239:notes:29]
|  | June 30, 2015 |  |  | September 30, 2014 |  |
| Raw materials, parts and subassemblies | $ | 40,320 |  |  | $ | 35,349 |  |
| Work-in-progress |  | 1,029 |  |  |  | 2,035 |  |
| Provision for excess and obsolete inventory |  | (4,997 | ) |  |  | (4,569 | ) |
| Total inventories | $ | 36,352 |  |  | $ | 32,815 |  |

[0001564590-15-006239:notes:30]
[same as prior period, unchanged from 0001564590-15-003392:notes:33]

[0001564590-15-006239:notes:31]
[same as prior period, unchanged from 0001564590-15-003392:notes:34]

[0001564590-15-006239:notes:32]
|  | June 30, |  |  | September 30, |  |
|  | 2015 |  |  | 2014 |  |
| Costs incurred on uncompleted contracts | $ | 613,304 |  |  | $ | 604,939 |  |
| Estimated earnings |  | 162,292 |  |  |  | 157,562 |  |
|  |  | 775,596 |  |  |  | 762,501 |  |
| Less: Billings to date |  | (735,012 | ) |  |  | (715,233 | ) |
| Net underbilled position | $ | 40,584 |  |  | $ | 47,268 |  |
| Included in the accompanying balance sheets under the following captions: |  |  |  |  |  |  |  |
| Costs and estimated earnings in excess of billings on uncompleted contracts – underbilled | $ | 97,901 |  |  | $ | 95,970 |  |
| Billings in excess of costs and estimated earnings on uncompleted contracts – overbilled |  | (57,317 | ) |  |  | (48,702 | ) |
| Net underbilled position | $ | 40,584 |  |  | $ | 47,268 |  |

[0001564590-15-006239:notes:33]
[same as prior period, unchanged from 0001564590-15-003392:notes:36]

[0001564590-15-006239:notes:34]
[same as prior period, unchanged from 0001564590-15-003392:notes:37]

[0001564590-15-006239:notes:35]
|  | Three months ended June 30, |  |  | Nine months ended June 30, |  |
|  | 2015 |  |  | 2014 |  |  | 2015 |  |  | 2014 |  |
| Balance at beginning of period | $ | 4,375 |  |  | $ | 4,833 |  |  | $ | 4,557 |  |  | $ | 5,282 |  |
| Increase to warranty expense |  | 1,033 |  |  |  | 884 |  |  |  | 2,100 |  |  |  | 2,390 |  |
| Deduction for warranty charges |  | (766 | ) |  |  | (1,023 | ) |  |  | (1,794 | ) |  |  | (2,949 | ) |
| Increase (decrease) due to foreign currency translations |  | 81 |  |  |  | 61 |  |  |  | (140 | ) |  |  | 32 |  |
| Balance at end of period | $ | 4,723 |  |  | $ | 4,755 |  |  | $ | 4,723 |  |  | $ | 4,755 |  |


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0001564590-15-006239:notes:36]
[same as prior period, unchanged from 0001564590-15-003392:notes:39]

[0001564590-15-006239:notes:37]
Intangible assets balances, subject to amortization, at June 30, 2015 and September 30, 2014 consisted of the following (in thousands):

[0001564590-15-006239:notes:38]
|  | June 30, 2015 |  |  | September 30, 2014 |  |
|  | Gross |  |  |  |  |  |  | Net |  |  | Gross |  |  |  |  |  |  | Net |  |
|  | Carrying |  |  | Accumulated |  |  | Carrying |  |  | Carrying |  |  | Accumulated |  |  | Carrying |  |
|  | Value |  |  | Amortization |  |  | Value |  |  | Value |  |  | Amortization |  |  | Value |  |
| Purchased technology | $ | 11,749 |  |  | $ | (10,241 | ) |  | $ | 1,508 |  |  | $ | 11,749 |  |  | $ | (9,918 | ) |  | $ | 1,831 |  |
| Trade name |  | 1,136 |  |  |  | (1,136 | ) |  |  | - |  |  |  | 1,136 |  |  |  | (1,063 | ) |  |  | 73 |  |
| Total | $ | 12,885 |  |  | $ | (11,377 | ) |  | $ | 1,508 |  |  | $ | 12,885 |  |  | $ | (10,981 | ) |  | $ | 1,904 |  |

[0001564590-15-006239:notes:39]
Amortization of intangible assets recorded for the nine months ended June 30, 2015 and 2014 was $0.3 million and $0.7 million, respectively.

[0001564590-15-006239:notes:40]
[same as prior period, unchanged from 0001564590-15-003392:notes:43]


## us-gaap:LongTermDebtTextBlock

[0001564590-15-006239:notes:41]
E. LONG-TERM DEBT

[0001564590-15-006239:notes:42]
Long-term debt consisted of the following (in thousands):

[0001564590-15-006239:notes:43]
|  | June 30, 2015 |  |  | September 30, 2014 |  |
| Industrial development revenue bonds | $ | 2,800 |  |  | $ | 3,200 |  |
| Less current portion |  | (400 | ) |  |  | (400 | ) |
| Total long-term debt and capital lease obligations | $ | 2,400 |  |  | $ | 2,800 |  |

[0001564590-15-006239:notes:44]
U.S. Revolver

[0001564590-15-006239:notes:45]
In December 2013, we amended and restated our existing credit agreement (the Amended Credit Agreement) with a major domestic bank.  In December 2014, we entered into the Second Amendment of the Amended Credit Agreement (the Second Amendment).  The Second Amendment provides for the expansion of our Canadian manufacturing facility and allows for the repurchase of our common stock pursuant to a share repurchase program announced in December 2014. The Amended Credit Agreement provides for a $75.0 million revolving credit facility (U.S. Revolver). Obligations are collateralized by the stock of certain of our subsidiaries.

[0001564590-15-006239:notes:46]
The interest rate for amounts outstanding under the Amended Credit Agreement for the U.S. Revolver is a floating rate based upon the higher of the Federal Funds Rate plus 0.5%, the bank’s prime rate, or the Eurocurrency rate plus 1.00%. Once the applicable rate is determined, a margin ranging up to 1.75%, as determined by our consolidated leverage ratio, is added to the applicable rate.

[0001564590-15-006239:notes:47]
The U.S. Revolver provides for the issuance of letters of credit which reduce the amounts that may be borrowed under this revolver. The amount available under the U.S. Revolver was reduced by $18.1 million for our outstanding letters of credit at June 30, 2015.

[0001564590-15-006239:notes:48]
There were no borrowings outstanding under the U.S. Revolver as of June 30, 2015.  Amounts available under the U.S. Revolver were $56.9 million at June 30, 2015. The U.S. Revolver expires on December 31, 2018.

[0001564590-15-006239:notes:49]
The Amended Credit Agreement contains certain restrictive and maintenance-type covenants, such as restrictions on the amount of capital expenditures allowed. It also contains financial covenants defining various financial measures and the levels of these measures with which we must comply, as well as a “material adverse change” clause. A “material adverse change” is defined as a material change in our operations, business, properties, liabilities or condition (financial or otherwise) or a material impairment of our ability to perform our obligations under our credit agreements.

[0001564590-15-006239:notes:50]
The Amended Credit Agreement is collateralized by a pledge of 100% of the voting capital stock of each of our domestic subsidiaries and 65% of the voting capital stock of each non-domestic subsidiary, excluding Powell Canada. The Amended Credit Agreement provides for customary events of default and carries cross-default provisions with other existing debt agreements. If an event of default (as defined in the Amended Credit Agreement) occurs and is continuing, on the terms and subject to the conditions set forth in the Amended Credit Agreement, amounts outstanding under the Amended Credit Agreement may be accelerated and may become immediately due and payable. As of June 30, 2015, we were in compliance with all of the financial covenants of the Amended Credit Agreement.

[0001564590-15-006239:notes:51]
Canadian Revolver

[0001564590-15-006239:notes:52]
We have an $8.1 million credit facility with a major international bank in Canada (the Canadian Revolver) to provide working capital support and letters of credit for our operations in Canada. The Canadian Revolver provides for the issuance of letters of credit which reduce the amounts that may be borrowed under this revolver.  There were no outstanding letters of credit under the Canadian Revolver at June 30, 2015.

[0001564590-15-006239:notes:53]
There were no borrowings outstanding under the Canadian Revolver as of June 30, 2015 and amounts available under the Canadian Revolver were $8.1 million at June 30, 2015. The interest rate for amounts outstanding under the Canadian Revolver is a floating interest rate based upon either the Canadian Prime Rate, or the lender’s Bankers’ Acceptance Rate. Once the applicable rate is determined, a margin of 0.50% to 1.75%, as determined by our consolidated leverage ratio, is added to the applicable rate.

[0001564590-15-006239:notes:54]
The principal financial covenants are consistent with those described in our Amended Credit Agreement. The Canadian Revolver contains a “material adverse effect” clause. A “material adverse effect” is defined as a material change in the operations of Powell or Powell Canada in relation to our financial condition, property, business operations, expected net cash flows, liabilities or capitalization.

[0001564590-15-006239:notes:55]
The Canadian Revolver is secured by the assets of our Canadian operations and provides for customary events of default and carries cross-default provisions with our existing debt agreements. If an event of default (as defined in the Canadian Revolver) occurs and is continuing, per the terms and subject to the conditions set forth in the Canadian Revolver, amounts outstanding under the Canadian Revolver may be accelerated and may become immediately due and payable. As of June 30, 2015, we were in compliance with all of the financial covenants of the Canadian Revolver.

[0001564590-15-006239:notes:56]
Industrial Development Revenue Bonds

[0001564590-15-006239:notes:57]
We borrowed $8.0 million in October 2001 through a loan agreement funded with proceeds from tax-exempt industrial development revenue bonds (Bonds). These Bonds were issued by the Illinois Development Finance Authority and were used for the completion of our Northlake, Illinois facility. Pursuant to the Bond issuance, a reimbursement agreement between us and a major domestic bank required an issuance by the bank of an irrevocable direct-pay letter of credit (Bond LC), as collateral, to the Bonds’ trustee to guarantee payment of the Bonds’ principal and interest when due. The Bond LC is subject to both early termination and extension provisions customary to such agreements, as well as various covenants, for which we were in compliance at June 30, 2015. While the Bonds mature in 2021, the reimbursement agreement requires annual redemptions of $0.4 million that commenced on October 25, 2002. A sinking fund is used for the redemption of the Bonds. At June 30, 2015, the balance in the restricted sinking fund was approximately $0.3 million and was recorded in cash and cash equivalents. The Bonds bear interest at a floating rate determined weekly by the Bonds’ remarketing agent, which was the underwriter for the Bonds and is an affiliate of the bank. This interest rate was 0.20% as of June 30, 2015.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001564590-15-006239:notes:58]
F. COMMITMENTS AND CONTINGENCIES

[0001564590-15-006239:notes:59]
Long-Term Debt

[0001564590-15-006239:notes:60]
See Note E herein for discussion of our long-term debt.

[0001564590-15-006239:notes:61]
Letters of Credit and Bonds

[0001564590-15-006239:notes:62]
Certain customers require us to post bank letter of credit guarantees or performance bonds issued by a surety. These guarantees and performance bonds assure that we will perform under the terms of our contract. In the event of default, the counterparty may demand payment from the bank under a letter of credit or performance by the surety under a performance bond. To date, there have been no significant expenses related to either letters of credit or performance bonds for the periods reported. We were contingently liable for secured and unsecured letters of credit of $18.1 million as of June 30, 2015. We also had performance and maintenance bonds totaling $303.2 million that were outstanding, with additional bonding capacity of $446.8 million available, at June 30, 2015.

[0001564590-15-006239:notes:63]
We have a $15.7 million facility agreement (Facility Agreement) between Powell (UK) Limited and a large international bank. This Facility Agreement provides Powell (UK) the ability to enter into bank guarantees as well as forward exchange contracts and currency options. At June 30, 2015, we had outstanding guarantees totaling $6.4 million under this Facility Agreement.  Amounts available under this Facility Agreement were $9.3 million as of June 30, 2015.

[0001564590-15-006239:notes:64]
The Facility Agreement provides for financial covenants and customary events of default, and carries cross-default provisions with our Amended Credit Facility. If an event of default (as defined in the Facility Agreement) occurs and is continuing, per the terms and subject to the conditions set forth in the Facility Agreement, obligations outstanding under the Facility Agreement may be accelerated and may become or be declared immediately due and payable. As of June 30, 2015, we were in compliance with all of the financial covenants of the Facility Agreement.

[0001564590-15-006239:notes:65]
Litigation

[0001564590-15-006239:notes:66]
We are involved in various legal proceedings, claims and other disputes arising in the ordinary course of business which, in general, are subject to uncertainties and in which the outcomes are not predictable. Although we can give no assurance about the outcome of pending or threatened litigation and the effect such outcomes may have on us, management believes that any ultimate liability resulting from the outcome of such proceedings, to the extent not otherwise provided or covered by insurance, will not have a material adverse effect on our consolidated financial position or results of operations or liquidity.

[0001564590-15-006239:notes:67]
Liquidated Damages

[0001564590-15-006239:notes:68]
Certain of our customer contracts have schedule and performance obligation clauses that, if we fail to meet them, could subject us to liquidated damages.  Each individual contract defines the conditions under which the customer may make a claim against us.  We have had potential exposure for liquidated damages in the past, but in most instances they were not asserted by the customer.  As of June 30, 2015, our exposure to possible liquidated damages is $6.7 million, of which approximately $2.0 million is probable.  Based on our actual or projected failure to meet these various contractual commitments, $0.8 million has been recorded in our financial statements.  We believe that we will be successful in obtaining change orders or contract extensions that should resolve the potential for any unaccrued liquidated damages; however, should we fail to achieve relief on some or all of these contractual obligations, we could be subject to additional liquidated damages which could impact our future operating results.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001564590-15-006239:notes:69]
[same as prior period, unchanged from 0001564590-15-003392:notes:70]

[0001564590-15-006239:notes:70]
[same as prior period, unchanged from 0001564590-15-003392:notes:71]

[0001564590-15-006239:notes:71]
[same as prior period, unchanged from 0001564590-15-003392:notes:72]

[0001564590-15-006239:notes:72]
[same as prior period, unchanged from 0001564590-15-003392:notes:73]

[0001564590-15-006239:notes:73]
We issue restricted stock units (RSUs) to certain officers and key employees of the Company. The RSUs typically vest over a three-year period from their date of issuance. The fair value of the RSUs is based on the closing price of our common stock as reported on the NASDAQ Global Market on the grant dates. Sixty-percent of the actual amount of the RSUs earned will be based on the cumulative earnings as reported relative to the three-year performance cycle which begins October 1 of the year granted, and ranges from 0% to 250% of the target RSUs granted. The remaining forty-percent of the RSUs are time-based and vest over a three-year period. At June 30, 2015, there were 162,837 RSUs outstanding. The RSUs do not have voting rights and do not receive dividends on common stock; additionally, the shares of common stock underlying the RSUs are not considered issued and outstanding until actually issued.

[0001564590-15-006239:notes:74]
[same as prior period, unchanged from 0001564590-15-003392:notes:75]

[0001564590-15-006239:notes:75]
|  | Number of |  |  | Weighted |  |
|  | Restricted |  |  | Average |  |
|  | Stock |  |  | Fair Value |  |
|  | Units |  |  | Per Share |  |
| Outstanding at September 30, 2014 |  | 106,845 |  |  | $ | 51.30 |  |
| Granted |  | 89,500 |  |  |  | 41.75 |  |
| Vested |  | (33,508 | ) |  |  | 44.06 |  |
| Forfeited |  | — |  |  |  | — |  |
| Outstanding at June 30, 2015 |  | 162,837 |  |  | $ | 47.54 |  |

[0001564590-15-006239:notes:76]
During the nine months ended June 30, 2015 and 2014, we recorded compensation expense of $1.3 million and $2.0 million, respectively, related to the RSUs.

[0001564590-15-006239:notes:77]
[same as prior period, unchanged from 0001564590-15-003392:notes:78]

[0001564590-15-006239:notes:78]
In February 2014, our stockholders also approved the 2014 Non-Employee Director Equity Incentive Plan (the 2014 Director Plan) for the benefit of members of the Board of Directors of the Company who, at the time of their service are not employees of the Company or any of its affiliates. The 2014 Director Plan authorizes stock options, stock appreciation rights, restricted stock, restricted stock units, as well as certain other awards.  In February 2015, 16,000 shares of restricted stock were issued to such directors at a price of $33.37 per share under the 2014 Director Plan.  The annual restricted stock grants vest 50% per year over a two-year period on each anniversary of the grant date.

[0001564590-15-006239:notes:79]
During the nine months ended June 30, 2015 and 2014, we recorded compensation expense of $1.0 million and $0.9 million, respectively, related to restricted stock grants.


## powl:StockRepurchaseProgramTextBlock

[0001564590-15-006239:notes:80]
[same as prior period, unchanged from 0001564590-15-003392:notes:81]

[0001564590-15-006239:notes:81]
On December 17, 2014, our Board of Directors authorized a repurchase program (the Repurchase Program) under which we may repurchase up to $25 million of our outstanding stock.  The purchases may be made from time to time in the open market, through privately negotiated transactions and Rule 10b5-1 trading plans in accordance with applicable laws, rules and regulations.  The Repurchase Program is being funded from cash on hand and cash provided by operating activities.  The Repurchase Program will expire as of the close of business on December 31, 2015.  As of June 30, 2015, we have purchased 362,961 shares at cost of $12.5 million under this Repurchase Program.  The average price per share through June 30, 2015 has been $34.50.


## us-gaap:FairValueDisclosuresTextBlock

[0001564590-15-006239:notes:82]
[same as prior period, unchanged from 0001564590-15-003392:notes:83]

[0001564590-15-006239:notes:83]
[same as prior period, unchanged from 0001564590-15-003392:notes:84]

[0001564590-15-006239:notes:84]
[same as prior period, unchanged from 0001564590-15-003392:notes:85]

[0001564590-15-006239:notes:85]
[same as prior period, unchanged from 0001564590-15-003392:notes:86]

[0001564590-15-006239:notes:86]
[same as prior period, unchanged from 0001564590-15-003392:notes:87]

[0001564590-15-006239:notes:87]
[same as prior period, unchanged from 0001564590-15-003392:notes:88]

[0001564590-15-006239:notes:88]
The following table summarizes the fair value of our assets and liabilities that were accounted for at fair value on a recurring basis as of June 30, 2015 (in thousands):

[0001564590-15-006239:notes:89]
|  | Fair Value Measurements at June 30, 2015 |  |
|  | Quoted Prices in |  |  | Significant Other |  |  | Significant |  |  |  |  |  |
|  | Active Markets for |  |  | Observable |  |  | Unobservable |  |  | Fair Value at |  |
|  | Identical Assets |  |  | Inputs |  |  | Inputs |  |  | June 30, |  |
|  | (Level 1) |  |  | (Level 2) |  |  | (Level 3) |  |  | 2015 |  |
| Assets: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cash equivalents | $ | 334 |  |  | $ | — |  |  | $ | — |  |  | $ | 334 |  |
| Deferred compensation |  | 1,992 |  |  |  | 3,124 |  |  |  | — |  |  |  | 5,116 |  |
| Liabilities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Deferred compensation |  | — |  |  |  | 4,791 |  |  |  | — |  |  |  | 4,791 |  |

[0001564590-15-006239:notes:90]
[same as prior period, unchanged from 0001564590-15-003392:notes:91]

[0001564590-15-006239:notes:91]
[same as prior period, unchanged from 0001564590-15-003392:notes:92]

[0001564590-15-006239:notes:92]
[same as prior period, unchanged from 0001564590-15-003392:notes:93]

[0001564590-15-006239:notes:93]
[same as prior period, unchanged from 0001564590-15-003392:notes:94]

[0001564590-15-006239:notes:94]
[same as prior period, unchanged from 0001564590-15-003392:notes:95]

[0001564590-15-006239:notes:95]
[same as prior period, unchanged from 0001564590-15-003392:notes:96]

[0001564590-15-006239:notes:96]
Industrial Development Revenue Bond – The fair value of our long-term debt depends primarily on the coupon rate of our industrial development revenue bonds.  The carrying value of our long-term debt at June 30, 2015, approximates fair value based on the current coupon rate of the bonds, which is reset weekly, and is classified as a Level 2 input in the fair value measurement hierarchy as there is an active market for the trading of these industrial development revenue bonds.

[0001564590-15-006239:notes:97]
There were no transfers between levels within the fair value measurement hierarchy during the nine months ended June 30, 2015.


## us-gaap:DisposalGroupsIncludingDiscontinuedOperationsDisclosureTextBlock

[0001564590-15-006239:notes:98]
[same as prior period, unchanged from 0001564590-15-003392:notes:99]

[0001564590-15-006239:notes:99]
On January 15, 2014, we sold our wholly-owned subsidiary Transdyn to a global provider of electronic toll collection systems, headquartered in Vienna, Austria.  The purchase price from the sale of this subsidiary totaled $16.0 million, subject to working capital adjustments.  We received cash of $14.4 million and the remaining $1.6 million was placed into an escrow account and was released to us in July 2015.

[0001564590-15-006239:notes:100]
We have presented the results of these operations as income from discontinued operations, net of tax, in the condensed consolidated statements of operations as of June 30, 2014.

[0001564590-15-006239:notes:101]
[same as prior period, unchanged from 0001564590-15-003392:notes:102]

[0001564590-15-006239:notes:102]
|  | Three months ended June 30, |  |  | Nine months ended June 30, |  |
|  | 2015 |  |  | 2014 |  |  | 2015 |  |  | 2014 |  |
| Revenues | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 13,923 |  |
| Income from discontinued operations, net of tax of $633 |  | — |  |  |  | — |  |  |  | — |  |  |  | 1,041 |  |
| Gain on sale of discontinued operations, net of tax of $5,218 |  | — |  |  |  | — |  |  |  | — |  |  |  | 8,563 |  |
| Net income from discontinued operations, net of tax | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 9,604 |  |
| Earnings per share information: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 0.80 |  |
| Diluted | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 0.80 |  |


## us-gaap:IncomeTaxDisclosureTextBlock

[0001564590-15-006239:notes:103]
[same as prior period, unchanged from 0001564590-15-003392:notes:104]

[0001564590-15-006239:notes:104]
[same as prior period, unchanged from 0001564590-15-003392:notes:105]

[0001564590-15-006239:notes:105]
|  | Three months ended June 30, |  |  | Nine months ended June 30, |  |
|  | 2015 |  |  | 2014 |  |  | 2015 |  |  | 2014 |  |
| Income from continuing operations before income taxes | $ | 12,234 |  |  | $ | 5,180 |  |  | $ | 13,700 |  |  | $ | 27,416 |  |
| Income tax provision |  | 5,185 |  |  |  | 2,233 |  |  |  | 10,573 |  |  |  | 10,226 |  |
| Income from continuing operations | $ | 7,049 |  |  | $ | 2,947 |  |  | $ | 3,127 |  |  | $ | 17,190 |  |
| Effective tax rate |  | 42 | % |  |  | 43 | % |  |  | 77 | % |  |  | 37 | % |

[0001564590-15-006239:notes:106]
A reconciliation of the significant differences between the statutory U. S. income tax rate and the effective income tax rate, as computed on earnings (loss) before income tax provision for the nine months ended June 30, 2015 and 2014, is as follows:

[0001564590-15-006239:notes:107]
|  | Nine months ended June 30, |  |
|  | 2015 |  |  | 2014 |  |
| Statutory rate |  | 35 | % |  |  | 35 | % |
| Canadian valuation allowance |  | 76 |  |  |  | — |  |
| Research and Development Credit |  | (34 | ) |  |  | — |  |
| State rate |  | 2 |  |  |  | 2 |  |
| Domestic production activities deduction |  | (2 | ) |  |  | (1 | ) |
| Other |  | — |  |  |  | 1 |  |
| Effective rate |  | 77 | % |  |  | 37 | % |

[0001564590-15-006239:notes:108]
We recorded a provision for income taxes from continuing operations of $5.2 million in the third quarter of Fiscal 2015, compared to the provision of $2.2 million recorded in the third quarter of Fiscal 2014.  The effective tax rate for the third quarter of Fiscal 2015 was 42.4% compared to an effective tax rate of 43.1% for the third quarter of Fiscal 2014.  The effective tax rate for the third quarter of Fiscal 2015 is above the combined U.S. federal and state statutory rate as no tax benefit is recorded against Canadian pre-tax losses due to the valuation allowance recorded in the second quarter of Fiscal 2015.  The effective tax rate for both the third quarter of Fiscal 2015 and 2014 were also above the combined U.S. federal and state statutory rate due to discrete tax items recognized during the quarters as well as the nondeductibility of certain executive compensation costs.

[0001564590-15-006239:notes:109]
We recorded a provision for income taxes from continuing operations of $10.6 million for the nine months ended June 30, 2015, compared to the provision of $10.2 million recorded for the nine months ended June 30, 2014.  The effective tax rate for the nine months ended June 30, 2015 was 77.2% compared to an effective tax rate of 37.3% for the nine months ended June 30, 2014.  The higher rate for the nine months ended June 30, 2015 was primarily due to a valuation allowance against our Canadian deferred tax assets and the resulting inability to record a tax benefit against the year-to-date Canadian losses.  This was partially offset by the release of a FIN 48 reserve related to the R&D Credit upon closing an IRS audit as well as the December 19, 2014 retroactive reinstatement of the R&D Credit from January 1, 2014 through December 31, 2014.  The effective tax rate for the nine months ended June 30, 2014 approximated the combined U.S. federal and state statutory rate as the majority of our income was attributable to the U.S.

[0001564590-15-006239:notes:110]
At June 30, 2015, we had $34 million of gross foreign net operating loss carryforwards, the benefits of which are recorded as deferred tax assets and are subject to a 20-year carryforward period, the first of which will expire in 2031. During our quarterly assessment of deferred taxes, in the second quarter of Fiscal 2015, we established a valuation allowance in the amount of $9.0 million against Canadian net deferred tax assets.  In assessing the realizability of net deferred tax assets, we consider whether it is more-likely-than-not that some portion or all of the net deferred tax assets may not be realized.  The ultimate realization of net deferred tax assets is dependent on the generation of future taxable income during the periods in which those temporary differences become deductible.  In light of the historical Canadian losses, and recent changes in projected losses in the near term, we are required under the more-likely-than-not accounting standard to record a valuation allowance against the Canadian net deferred assets because we may not be able to realize the benefits of the net operating loss carryforwards and other deductible differences.

[0001564590-15-006239:notes:111]
[same as prior period, unchanged from 0001564590-15-003392:notes:112]


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0001564590-15-006239:notes:112]
[same as prior period, unchanged from 0001564590-15-003392:notes:113]

[0001564590-15-006239:notes:113]
In the third quarter of Fiscal 2015, we incurred $1.4 million of restructuring and separation costs.  Of this, $0.8 million was the termination of a Canadian facility lease and the write-off of associated leasehold improvements.  The remaining $0.6 million were severance costs due to additional headcount reductions in Canada and certain U.S. operations as we continue to respond to current market conditions.

[0001564590-15-006239:notes:114]
For the nine months ended June 30, 2015, we incurred $2.7 million in restructuring and separation costs. Of this, $1.9 million was from separation and severance costs and the remaining $0.8 million resulted from the termination of a Canadian facility lease and the write-off of associated leasehold improvements.  During the nine months ended June 30, 2015, we have paid out $1.4 million in severance and separation costs.
