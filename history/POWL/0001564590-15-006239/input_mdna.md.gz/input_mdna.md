# POWL MD&A — 0001564590-15-006239


## mdna

[0001564590-15-006239:mdna:1]
[same as prior period, unchanged from 0001564590-15-003392:mdna:1]

[0001564590-15-006239:mdna:2]
[same as prior period, unchanged from 0001564590-15-003392:mdna:2]

[0001564590-15-006239:mdna:3]
[same as prior period, unchanged from 0001564590-15-003392:mdna:3]

[0001564590-15-006239:mdna:4]
We develop, design, manufacture and service custom-engineered equipment and systems for the management and control of electrical energy and other critical processes. Headquartered in Houston, Texas, we serve the oil and gas refining, offshore oil and gas production, petrochemical, pipeline, terminal, pulp and paper, mining and metals, light rail traction power, and electric utility markets. Revenues and costs are primarily related to custom engineered-to-order equipment and systems and accounted for under percentage of completion accounting which precludes us from providing detailed price and volume information. Our backlog includes various projects, some of which are petrochemical, oil and gas construction and transportation infrastructure projects which take a number of months to produce.

[0001564590-15-006239:mdna:5]
[same as prior period, unchanged from 0001564590-15-003392:mdna:5]

[0001564590-15-006239:mdna:6]
Our operating results have been negatively impacted by factors such as our operational inefficiencies, our contractual commitments on existing projects, customer approval of final engineering and design specifications and delays in customer construction schedules, all of which have negatively impacted the timing of our project execution.  These factors resulted in an imbalance of our factory resources with our customer commitments, resulting in higher production costs due to inefficiencies.  Our operating results are also impacted by the timing and resolution of change orders, project close-out and resolution of potential liquidated damage claims, all of which could improve or deteriorate gross margins during the period in which these items are resolved with our customers.

[0001564590-15-006239:mdna:7]
We anticipate that demand for our solutions in the western Canadian oil and gas markets will continue to be a contributor to our strategic position in the Canadian market place.  We completed the construction of our new Canadian facility and relocated operations in the fall of 2013 and completed a $26 million expansion of this manufacturing facility in the third quarter of Fiscal 2015. The stabilization of our Canadian operations has presented challenges resulting in inefficiencies that led to extended project delivery times, delayed project revenues, higher operating costs, gross margin deterioration and operating losses.  We have taken actions to mitigate the risks associated with replicating our U.S. project-based integration model which allows for the design, fabrication, integration and testing of our products at a single location.  Prior to the construction of our new Canadian facility, we performed only final assembly operations in Canada.

[0001564590-15-006239:mdna:8]
On January 15, 2014, we sold our wholly-owned subsidiary Transdyn to a global provider of electronic toll collection systems, headquartered in Vienna, Austria.  The purchase price from the sale of this subsidiary totaled $16.0 million, subject to working capital adjustments. We received cash of $14.4 million and the remaining $1.6 million was placed into an escrow account and released to us in July 2015. We have presented the results of these operations as income from discontinued operations, net of tax, in the condensed consolidated statements of operations for the nine months ended June 30, 2014.  Accordingly, we have removed Transdyn from the Results of Operations discussions below.

[0001564590-15-006239:mdna:9]
[same as prior period, unchanged from 0001564590-15-003392:mdna:9]

[0001564590-15-006239:mdna:10]
Quarter Ended June 30, 2015 Compared to the Quarter Ended June 30, 2014 (Unaudited)

[0001564590-15-006239:mdna:11]
[same as prior period, unchanged from 0001564590-15-003392:mdna:11]

[0001564590-15-006239:mdna:12]
Revenues increased 17.2%, or $25.9 million, to $176.7 million in the third quarter of Fiscal 2015, compared to the third quarter of Fiscal 2014, primarily due to our increased production efforts resulting from the customer scheduling of projects during this quarter from our backlog.  Domestic revenues increased by 57.2%, or $48.7 million, to $134.0 million in the third quarter of Fiscal 2015, compared to the third quarter of Fiscal 2014, primarily due to our production efforts on various large petrochemical projects awarded

[0001564590-15-006239:mdna:13]
in 2014.  International revenues decreased by 34.8%, or $22.8 million, to $42.7 million in the third quarter of Fiscal 2015, compared to the third quarter of Fiscal 2014, primarily due to the substantial completion of several large projects for both the Canadian market and our U.S. export projects. Revenues from commercial and industrial customers increased $34.0 million to $146.7 million in the third quarter of Fiscal 2015, compared to the third quarter of Fiscal 2014. Revenues from public and private utilities decreased $11.8 million to $16.4 million in the third quarter of Fiscal 2015, compared to the third quarter of Fiscal 2014. Revenues from municipal and transit projects increased $3.7 million to $13.6 million in the third quarter of Fiscal 2015, compared to the third quarter of Fiscal 2014.

[0001564590-15-006239:mdna:14]
Gross profit for the third quarter of Fiscal 2015 increased 11.1%, or $3.3 million, to $32.9 million, compared to the third quarter of Fiscal 2014, primarily due to the increase in production efforts on projects as noted above.  Gross profit as a percentage of revenues decreased to 18.6% in the third quarter of Fiscal 2015, compared to 19.7% in the third quarter of Fiscal 2014, primarily driven by inefficiencies resulting from our production efforts and incremental costs required to maintain our customer’s schedules, as well as the overall mix of project types.

[0001564590-15-006239:mdna:15]
[same as prior period, unchanged from 0001564590-15-003392:mdna:14]

[0001564590-15-006239:mdna:16]
Selling, general and administrative expenses decreased $5.0 million to $18.0 million during the third quarter of Fiscal 2015 compared to the third quarter of Fiscal 2014 primarily due to a decrease in performance-based compensation, sales commissions, personnel and administrative costs, reduced bad debt expense and overall cost reduction efforts.  Selling, general and administrative expenses, as a percentage of revenues, decreased to 10.2% during the third quarter of Fiscal 2015, compared to 15.3% during the third quarter of Fiscal 2014, due to the lower expenses and increased revenues discussed above.

[0001564590-15-006239:mdna:17]
[same as prior period, unchanged from 0001564590-15-003392:mdna:16]

[0001564590-15-006239:mdna:18]
In the third quarter of Fiscal 2015, we incurred approximately $1.4 million in restructuring and separation costs.  Of this, $0.8 million was the termination of a Canadian facility lease and the write-off of associated leasehold improvements and the remaining $0.6 million were severance costs due to additional headcount reductions in Canada and certain U.S. operations as we continue to respond to current market conditions.  There were no restructuring costs in the third quarter of Fiscal 2014.

[0001564590-15-006239:mdna:19]
[same as prior period, unchanged from 0001564590-15-003392:mdna:18]

[0001564590-15-006239:mdna:20]
We recorded other income of $0.5 million in both the third quarter of Fiscal 2015 and the third quarter of Fiscal 2014.  This was the amortization of the deferred gain from the amended supply agreement, discussed in Note D of the Notes to Condensed Consolidated Financial Statements.

[0001564590-15-006239:mdna:21]
[same as prior period, unchanged from 0001564590-15-003392:mdna:20]

[0001564590-15-006239:mdna:22]
We recorded a provision for income taxes from continuing operations of $5.2 million in the third quarter of Fiscal 2015, compared to the provision of $2.2 million recorded in the third quarter of Fiscal 2014.  The effective tax rate for the third quarter of Fiscal 2015 was 42.4% compared to an effective tax rate of 43.1% for the third quarter of Fiscal 2014. The effective tax rate for the third quarter of Fiscal 2015 is above the combined U.S. federal and state statutory rate as no tax benefit is recorded against Canadian pre-tax losses due to the valuation allowance recorded in the second quarter of Fiscal 2015 discussed in Note K of the Notes to Condensed Consolidated Financial Statements. The effective tax rates for both the third quarter of Fiscal 2015 and 2014 were also above the combined U.S. federal and state statutory rate due to discrete tax items recognized during the quarter as well as the nondeductibility of certain executive compensation costs.

[0001564590-15-006239:mdna:23]
Net income

[0001564590-15-006239:mdna:24]
In the third quarter of Fiscal 2015, we recorded income of $7.0 million, or earnings per diluted share of $0.60, compared to income of $2.9 million, or $0.24 per diluted share, in the third quarter of Fiscal 2014.  This increase was primarily due to higher revenues and lower selling, general and administrative expenses which were partially offset by higher production costs due to inefficiencies.

[0001564590-15-006239:mdna:25]
[same as prior period, unchanged from 0001564590-15-003392:mdna:26]

[0001564590-15-006239:mdna:26]
Our backlog includes various projects, some of which are petrochemical, oil and gas construction and transportation infrastructure projects which take a number of months to produce. The order backlog at June 30, 2015 increased to $518.0 million, compared to $507.1 million at September 30, 2014.  New orders placed during the third quarter of Fiscal 2015 increased to $193.2 million compared to $171.7 million in the third quarter of Fiscal 2014.

[0001564590-15-006239:mdna:27]
Nine Months Ended June 30, 2015 Compared to the Nine Months Ended June 30, 2014 (Unaudited)

[0001564590-15-006239:mdna:28]
[same as prior period, unchanged from 0001564590-15-003392:mdna:29]

[0001564590-15-006239:mdna:29]
Revenues increased 3.0%, or $14.6 million, to $499.5 million for the nine months ended June 30, 2015, compared to the nine months ended June 30, 2014 primarily due to the increase in domestic revenues.  Domestic revenues increased by 32.0%, or $85.2 million, to $351.4 million for the nine months ended June 30, 2015, compared to the nine months ended June 30, 2014, due to our production efforts on various large petrochemical projects awarded in 2014. International revenues decreased by 32.3%, or $70.6 million, to $148.2 million for the nine months ended June 30, 2015, compared to the nine months ended June 30, 2014, primarily due the substantial completion of several large projects for the both Canadian market as well U.S. export projects.  Revenues from commercial and industrial customers increased $46.2 million to $398.0 million for the nine months ended June 30, 2015, compared to the nine months ended June 30, 2014. Revenues from public and private utilities decreased $34.1 million to $64.1 million for the nine months ended June 30, 2015, compared to the nine months ended June 30, 2014. Revenues from municipal and transit projects increased $2.5 million to $37.4 million for the nine months ended June 30, 2015, compared to the nine months ended June 30, 2014.

[0001564590-15-006239:mdna:30]
Gross profit for the nine months ended June 30, 2015 decreased 21.5%, or $21.4 million, to $78.3 million, compared to the nine months ended June 30, 2014.  Gross profit as a percentage of revenues decreased to 15.7% for the nine months ended June 30, 2015, compared to 20.6% for the nine months ended June 30, 2014.  Our gross profit and gross profit as a percentage of revenues decreased in the nine months ended June 30, 2015, compared to the nine months ended June 30, 2014, primarily driven by inefficiencies resulting from our production efforts and incremental costs required to maintain our customer’s schedules, as well as the overall mix of project types.

[0001564590-15-006239:mdna:31]
[same as prior period, unchanged from 0001564590-15-003392:mdna:32]

[0001564590-15-006239:mdna:32]
Selling, general and administrative expenses decreased by $8.5 million to $58.3 million during nine months ended June 30, 2015, compared to the nine months ended June 30, 2014, primarily due to a decrease in performance-based compensation, sales commissions, personnel and administrative costs, reduced bad debt expense and overall cost reduction efforts.  Selling, general and administrative expenses, as a percentage of revenues, decreased to 11.7% during the nine months ended June 30, 2015, compared to 13.8% during the nine months ended June 30, 2014.

[0001564590-15-006239:mdna:33]
[same as prior period, unchanged from 0001564590-15-003392:mdna:34]

[0001564590-15-006239:mdna:34]
For the nine months ended June 30, 2015, we incurred $2.7 million in restructuring and separation costs. Of this, $1.9 million was from separation and severance costs and the remaining $0.8 million resulted from the termination of a Canadian facility lease and the write-off of associated leasehold improvements.

[0001564590-15-006239:mdna:35]
[same as prior period, unchanged from 0001564590-15-003392:mdna:36]

[0001564590-15-006239:mdna:36]
We recorded other income of $1.9 million in the nine months ended June 30, 2015, of which $1.5 million was from the amortization of the deferred gain from the amended supply agreement, discussed in Note D of the Notes to Condensed Consolidated Financial Statements, and $0.4 million was from a death benefit received from our company-owned life insurance policy.  We recorded other income of $1.0 million in the same period in Fiscal 2014 which was solely from the amortization of the deferred gain.

[0001564590-15-006239:mdna:37]
[same as prior period, unchanged from 0001564590-15-003392:mdna:38]

[0001564590-15-006239:mdna:38]
We recorded a provision for income taxes from continuing operations of $10.6 million for the nine months ended June 30, 2015, compared to the provision of $10.2 million for the nine months ended June 30, 2014.  The effective tax rate for the nine months ended June 30, 2015 was 77.2%, compared to an effective tax rate of 37.3% for the nine months ended June 30, 2014, primarily due to a valuation allowance against our Canadian deferred tax assets recorded in the second quarter of Fiscal 2015 and the resulting inability to record a tax benefit against the year-to-date Canadian losses (see Note K of the Notes to Condensed Consolidated Financial Statements), partially offset by the release of a FIN 48 reserve related to the R&D Credit upon closing an IRS audit as well as the December 19, 2014 retroactive reinstatement of the R&D Credit from January 1, 2014 through December 31, 2014.  The effective tax rate for the nine months ended June 30, 2014 approximated the combined U.S. federal and state statutory rate as the majority of our income was attributable to the U.S.

[0001564590-15-006239:mdna:39]
[same as prior period, unchanged from 0001564590-15-003392:mdna:40]

[0001564590-15-006239:mdna:40]
For the nine months ended June 30, 2015, we recorded income from continuing operations of $3.1 million, or $0.26 per diluted share, compared to income from continuing operations of $17.2 million, or $1.43 per diluted share, for the nine months ended June 30, 2014.  This reduction to net income was primarily due to a valuation allowance recorded against our Canadian deferred tax assets (as discussed above) and higher domestic productions costs caused by inefficiencies resulting from our production efforts to maintain our customer’s scheduling requirements related to our increased volume.  These reductions to net income were partially offset by lower selling, general and administrative costs.

[0001564590-15-006239:mdna:41]
[same as prior period, unchanged from 0001564590-15-003392:mdna:42]

[0001564590-15-006239:mdna:42]
For the nine months ended June 30, 2014, we recorded $9.6 million, or $0.80 per diluted share, of income from discontinued operations which included the gain on the sale.  For additional information about this disposition, see Note I of the Notes to Condensed Consolidated Financial Statements.

[0001564590-15-006239:mdna:43]
[same as prior period, unchanged from 0001564590-15-003392:mdna:44]

[0001564590-15-006239:mdna:44]
Our backlog includes various projects, some of which are petrochemical, oil and gas construction and transportation infrastructure projects which take a number of months to produce.  The order backlog at June 30, 2015 was $518.0 million, compared to $507.1 million at September 30, 2014.  New orders placed during the nine months ended June 30, 2015 decreased to $514.7 million from $526.5 million for the nine months ended June 30, 2014.  This decrease in orders was due to reduced investments by our customers primarily in oil and gas and petrochemical infrastructure.

[0001564590-15-006239:mdna:45]
[same as prior period, unchanged from 0001564590-15-003392:mdna:46]

[0001564590-15-006239:mdna:46]
Cash and cash equivalents decreased to $63.4 million at June 30, 2015, compared to $103.1 million at September 30, 2014.  As of June 30, 2015, current assets exceeded current liabilities by 2.2 times and our debt to total capitalization was 0.80%.

[0001564590-15-006239:mdna:47]
We have a $75.0 million revolving credit facility in the U.S., which expires in December 2016. As of June 30, 2015, there were no amounts borrowed under this line of credit.  We also have an $8.1 million revolving credit facility in Canada. At June 30, 2015, there was no balance outstanding under the Canadian revolving credit facility. Total long-term debt and capital lease obligations, including current maturities, totaled $2.8 million at June 30, 2015, compared to $3.2 million at September 30, 2014. Total letters of credit outstanding were $18.1 million and $21.5 million at June 30, 2015 and September 30, 2014, respectively, which reduce our availability under our U.S. credit facility. Amounts available at June 30, 2015 under the U.S. and Canadian revolving credit facilities were $56.9 million and $8.1 million, respectively.  For further information regarding our debt, see Notes E and F of the Notes to Condensed Consolidated Financial Statements.

[0001564590-15-006239:mdna:48]
Approximately $6.7 million of our cash at June 30, 2015, was held outside of the United States for international operations.  It is our intention to indefinitely reinvest all current and future foreign earnings internationally in order to ensure sufficient working capital and support and expand these international operations.  In the event that we elect to repatriate some or all of the foreign earnings that were previously deemed to be indefinitely reinvested outside the U.S., under current tax laws we would incur additional tax expense upon such repatriation.

[0001564590-15-006239:mdna:49]
[same as prior period, unchanged from 0001564590-15-003392:mdna:50]

[0001564590-15-006239:mdna:50]
[same as prior period, unchanged from 0001564590-15-003392:mdna:51]

[0001564590-15-006239:mdna:51]
Cash provided by operating activities was $18.6 million during the first nine months of Fiscal 2015, compared to cash used in operating activities of $14.6 million during the first nine months of Fiscal 2014.  This increase was primarily due to a shift in our net underbilled position and an increase in accounts payable. Cash flow from operations is primarily influenced by demand for our products and services and is impacted as our progress payment terms with our customers are matched with the payment terms with our suppliers.

[0001564590-15-006239:mdna:52]
[same as prior period, unchanged from 0001564590-15-003392:mdna:53]

[0001564590-15-006239:mdna:53]
Purchases of property, plant and equipment during the first nine months of Fiscal 2015 totaled $34.2 million compared to $11.3 million during the first nine months of Fiscal 2014.  This increase resulted primarily from the expansion of our Canadian facility in Fiscal 2015.

[0001564590-15-006239:mdna:54]
[same as prior period, unchanged from 0001564590-15-003392:mdna:55]

[0001564590-15-006239:mdna:55]
Net cash used in financing activities was $22.8 million during the first nine months of Fiscal 2015 and $9.9 million during the first nine months of Fiscal 2014.  This increase in the use of cash in the same period in Fiscal 2015 was primarily driven by our share repurchase program discussed below.   During the first nine months of Fiscal 2015, we have spent $12.5 million to repurchase shares of our common stock.

[0001564590-15-006239:mdna:56]
[same as prior period, unchanged from 0001564590-15-003392:mdna:57]

[0001564590-15-006239:mdna:57]
On December 17, 2014, our Board of Directors authorized a share repurchase program under which we may repurchase up to $25 million of our outstanding stock.  The purchases may be made from time to time in the open market, through privately negotiated transactions and Rule 10b5-1 trading plans in accordance with applicable laws, rules and regulations.  The Repurchase Program is being funded from cash on hand and cash provided by operating activities.  The Repurchase Program will expire as of the close of business on December 31, 2015.  As of June 30, 2015, a total of $12.5 million of our stock (362,961 shares) has been purchased under the Repurchase Program.

[0001564590-15-006239:mdna:58]
[same as prior period, unchanged from 0001564590-15-003392:mdna:59]

[0001564590-15-006239:mdna:59]
[same as prior period, unchanged from 0001564590-15-003392:mdna:60]

[0001564590-15-006239:mdna:60]
[same as prior period, unchanged from 0001564590-15-003392:mdna:61]

[0001564590-15-006239:mdna:61]
[same as prior period, unchanged from 0001564590-15-003392:mdna:62]

[0001564590-15-006239:mdna:62]
[same as prior period, unchanged from 0001564590-15-003392:mdna:63]

[0001564590-15-006239:mdna:63]
[same as prior period, unchanged from 0001564590-15-003392:mdna:64]

[0001564590-15-006239:mdna:64]
The markets in which we participate are capital-intensive and cyclical in nature. Cyclicality is predominantly driven by customer demand, global economic conditions and anticipated environmental or regulatory changes which affect the manner in which our customers proceed with capital investments. Our customers analyze various factors including the demand and price for oil, gas and electrical energy, the overall financial environment, governmental budgets, regulatory actions and environmental concerns. These factors influence the release of new capital projects by our customers, which are traditionally awarded in competitive bid situations. Scheduling of projects is matched to the customer requirements and projects may take a number of months to produce, but schedules may change during the course of any particular project.

[0001564590-15-006239:mdna:65]
A significant portion of our revenues are derived from the oil and gas and petrochemical market sectors.  Due to the decline in oil prices, many of our customers have reduced their capital budgets and cut costs, and in certain instances have deferred or cancelled projects that we were pursuing.  We believe that sustained lower oil prices will negatively impact future orders due to reduced capital spending and project deferrals by our customers resulting in market price pressures.  This reduction in new business opportunities and market price pressures will ultimately negatively impact our revenues, operating results and cash flows from operations.  Accordingly, we will continue to review our cost structure and take actions to align our operating cost structure with expected revenues.

[0001564590-15-006239:mdna:66]
Our operating results have been and may continue to be negatively impacted by factors such as the timing of new order awards, customer approval of final engineering and design specifications and delays in customer construction schedules, all of which have and may continue to negatively impact the timing of project execution.  These factors have resulted and may continue to result in periods when our factory resources are not in balance with our customer’s scheduling requirements, resulting in higher production costs due to inefficiencies.  Our operating results are also impacted by the timing and resolution of change orders, project close-out and resolution of potential liquidated damage claims, all of which could improve or deteriorate gross margins during the period in which these items are resolved with our customers.

[0001564590-15-006239:mdna:67]
We completed the construction of our new Acheson, Alberta facility and relocated operations in the fall of 2013 and completed a $26 million expansion of this facility in the third quarter of Fiscal 2015. The production ramp and stabilization of our Canadian operations has presented and may continue to present challenges resulting in inefficiencies and extended project delivery times. These challenges

[0001564590-15-006239:mdna:68]
resulted in delayed project revenues, incremental costs to hold customers’ schedules, gross margin deterioration and operating losses.  We have taken actions to stabilize our Canadian operations and mitigate the risks associated with replicating our U.S. project-based integration model which allows for the design, fabrication, integration and testing of our products at a single location.  However, we may continue to incur operating losses in Canada as we continue to enhance our engineering and project management competencies and improve our overall project execution.  Prior to the construction of our new Canadian facility, we only performed final assembly operations in Canada.

[0001564590-15-006239:mdna:69]
[same as prior period, unchanged from 0001564590-15-003392:mdna:71]
