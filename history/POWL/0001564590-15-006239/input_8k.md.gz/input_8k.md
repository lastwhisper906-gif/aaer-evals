# POWL 8-K — 0001193125-15-277912 filed 2015-08-05

## item codes, every 8-K on or before 2015-08-05

- 2015-08-05 0001193125-15-277912 — 2.02, 8.01, 9.01
- 2015-05-06 0001193125-15-174291 — 2.02, 8.01, 9.01
- 2015-03-06 0001193125-15-081070 — 5.02
- 2015-03-02 0001193125-15-072946 — 5.07
- 2015-02-03 0001193125-15-031772 — 2.02, 8.01, 9.01
- 2014-12-18 0001193125-14-446513 — 8.01, 9.01
- 2014-12-03 0001193125-14-431745 — 2.02, 9.01
- 2014-11-05 0001193125-14-397955 — 8.01, 9.01
- 2014-09-26 0001193125-14-353741 — 7.01, 9.01
- 2014-08-05 0001193125-14-296001 — 2.02, 8.01, 9.01
- 2014-05-07 0001193125-14-187496 — 2.02, 8.01, 9.01
- 2014-03-03 0001193125-14-079843 — 5.02, 5.07
- 2014-02-05 0001193125-14-036633 — 2.02, 8.01, 9.01
- 2014-01-17 0001193125-14-014351 — 1.01, 8.01, 9.01
- 2014-01-06 0001193125-14-002795 — 1.01, 2.03
- 2013-12-06 0001564590-13-001411 — 2.02, 9.01
- 2013-12-05 0001564590-13-001406 — 5.02, 8.01, 9.01
- 2013-11-07 0001193125-13-432950 — 8.01, 9.01
- 2013-08-07 0001193125-13-324337 — 2.02, 9.01
- 2013-05-08 0001193125-13-206800 — 2.02, 9.01
- 2013-02-22 0001193125-13-070971 — 5.02, 5.07
- 2013-02-06 0001193125-13-040556 — 2.02, 9.01
- 2012-12-18 0001193125-12-506417 — 5.02, 9.01
- 2012-12-05 0001193125-12-491749 — 2.02, 9.01
- 2012-10-12 0001193125-12-421889 — 3.03, 5.02, 5.03, 9.01
- 2012-08-09 0001193125-12-344617 — 5.02, 8.01, 9.01
- 2012-08-08 0001193125-12-343630 — 2.02, 9.01
- 2012-05-09 0001193125-12-221356 — 2.02, 9.01
- 2012-02-08 0001193125-12-046560 — 2.02, 9.01
- 2011-12-08 0001193125-11-334810 — 2.02, 9.01
- 2011-11-08 0000950123-11-096524 — 2.02, 2.06, 4.02, 9.01
- 2011-10-14 0000950123-11-090124 — 5.02
- 2011-10-06 0000950123-11-088969 — 5.02
- 2011-09-19 0000950123-11-085224 — 5.02, 9.01
- 2011-09-15 0000950123-11-084806 — 5.02, 9.01
- 2011-08-04 0000950123-11-072788 — 2.02, 9.01
- 2011-07-22 0000950123-11-067402 — 5.07
- 2011-05-24 0000950123-11-053550 — 1.01, 2.03, 9.01
- 2011-05-04 0000950123-11-044561 — 2.02, 9.01
- 2011-02-02 0000950123-11-008188 — 2.02, 9.01
- 2010-12-08 0000950123-10-111987 — 2.02, 9.01
- 2010-08-05 0000950123-10-073114 — 2.02, 9.01
- 2010-05-18 0000950123-10-050900 — 5.02
- 2010-05-05 0000950123-10-044499 — 2.02, 9.01
- 2010-02-03 0000950123-10-008278 — 2.02, 9.01
- 2009-12-21 0000950123-09-072269 — 1.01, 2.01, 2.03, 8.01, 9.01
- 2009-12-09 0000950123-09-069525 — 2.02, 9.01
- 2009-10-27 0000950123-09-053501 — 1.01, 8.01, 9.01
- 2009-08-04 0000950123-09-029476 — 2.02, 9.01
- 2009-05-06 0000950129-09-001498 — 2.02, 9.01
- 2009-03-05 0000950129-09-000749 — 1.01, 9.01
- 2009-02-10 0000950129-09-000349 — 2.02, 9.01
- 2008-12-10 0000950134-08-021934 — 2.02, 9.01
- 2008-08-06 0000950129-08-004267 — 2.02, 9.01
- 2008-07-24 0000950129-08-004063 — 1.01, 5.02, 8.01, 9.01
- 2008-06-16 0000950129-08-003500 — 9.01 — amendment of 0000950134-06-015374
- 2008-06-05 0000950129-08-003378 — 5.02, 9.01
- 2008-05-08 0000950129-08-002843 — 2.02, 9.01
- 2008-02-06 0000950129-08-000533 — 2.02, 9.01
- 2007-12-19 0000950129-07-006277 — 1.01, 2.03, 9.01
- 2007-12-06 0000950129-07-006003 — 2.02, 9.01
- 2007-08-21 0000950129-07-004181 — 2.02, 9.01
- 2007-05-31 0000950129-07-002810 — 2.02, 9.01
- 2007-05-21 0000950129-07-002668 — 2.02, 3.01, 4.02, 9.01
- 2007-04-16 0000950129-07-002002 — 2.02, 4.02, 9.01
- 2007-03-01 0000950129-07-001104 — 5.02, 8.01, 9.01
- 2007-02-08 0000950129-07-000451 — 2.02, 9.01
- 2006-12-08 0000950129-06-010041 — 2.02, 9.01
- 2006-09-08 0000950129-06-008379 — 2.02, 9.01
- 2006-08-09 0000950134-06-015374 — 1.01, 2.01, 8.01, 9.01
- 2006-06-08 0000950129-06-006127 — 2.02, 9.01
- 2006-03-09 0000950129-06-002455 — 2.02, 9.01
- 2005-12-16 0000950129-05-012031 — 2.02, 5.03, 9.01
- 2005-09-13 0000950129-05-009181 — 2.01, 9.01 — amendment of 0000950129-05-006889
- 2005-09-12 0000950129-05-009151 — 2.02, 9.01
- 2005-07-06 0000950129-05-006889 — 1.01, 1.02, 2.01, 2.03, 9.01
- 2005-06-10 0000950129-05-006128 — 2.02, 9.01
- 2005-04-20 0000080420-05-000031 — 5.02
- 2005-03-11 0000080420-05-000024 — 9.01
- 2005-02-25 0000080420-05-000018 — 7.01, 9.01
- 2005-01-21 0000080420-05-000009 — 7.01, 9.01
- 2004-12-17 0000080420-04-000049 — 2.02, 9.01
- 2004-11-01 0000080420-04-000045 — 8.01, 9.01
- 2004-10-08 0001169232-04-005133 — 2.05
- 2004-09-14 0000080420-04-000037 — 5.02
- 2004-09-02 0000080420-04-000030 — 2.02, 9.01
- 2004-06-08 0000080420-04-000021 — 7
- 2004-05-13 0000080420-04-000019 — 4
- 2004-02-27 0000080420-04-000013 — 7
- 2003-12-16 0000950129-03-006136 — 12, 7
- 2003-08-29 0000950129-03-004531 — 12, 7
- 2003-06-03 0000950129-03-003035 — 7, 9
- 2003-05-15 0000950129-03-002812 — 7, 9
- 2002-05-29 0000950129-02-002795 — 4
- 2000-12-21 0000950129-00-006093 — 5, 7
- 1998-09-04 0000950129-98-003802 — 5
- 1996-08-09 0000950129-96-001705 — 2, 7

## late-filing notifications on or before 2015-08-05

- 2007-05-11 0000950129-07-002494 — NT 10-Q, for the period ended 2007-03-31
- 2005-01-18 0000080420-05-000004 — NT 10-K, for the period ended 2004-10-31

## item 2.02 — earnings release, exhibit 99.1

[0001193125-15-277912:8k_2_02:1]
EX-99.1
2
d74648dex991.htm
EX-99.1

[0001193125-15-277912:8k_2_02:2]
EX-99.1

[0001193125-15-277912:8k_2_02:3]
Exhibit 99.1

[0001193125-15-277912:8k_2_02:4]
| FOR IMMEDIATE RELEASE |  |  |  | Contacts: |  | Don R. Madison, CFO Powell Industries, Inc. 713-947-4422 |

[0001193125-15-277912:8k_2_02:5]
POWELL INDUSTRIES ANNOUNCES FISCAL 2015

[0001193125-15-277912:8k_2_02:6]
THIRD QUARTER RESULTS

[0001193125-15-277912:8k_2_02:7]
Company reports adjusted diluted EPS of $0.71

[0001193125-15-277912:8k_2_02:8]
HOUSTON – AUGUST 4, 2015 – Powell Industries, Inc. (NASDAQ: POWL), a leading supplier of custom engineered solutions for the management, control and
distribution of electrical energy, today announced results for the fiscal 2015 third quarter ended June 30, 2015.

[0001193125-15-277912:8k_2_02:9]
Revenues for the
third quarter of fiscal 2015 were $176.7 million compared to revenues of $150.8 million for the third quarter of fiscal 2014. The Company reported net income for the third quarter of $7.0 million, or $0.60 per diluted share, compared to net income
of $2.9 million, or $0.24 per diluted share, in the third quarter of fiscal 2014. Third quarter fiscal 2015 results include a $1.3 million restructuring and separation charge, net of tax. Excluding the restructuring and separation charge, net income
for the third quarter of fiscal 2015 was $8.4 million, or $0.71 per diluted share. A reconciliation of this non-GAAP financial measure to net income is included in the financial tables below.

[0001193125-15-277912:8k_2_02:10]
Michael A. Lucas, President and Chief Executive Officer, stated, “We realized improved operational and project execution during the third
quarter. Project execution and efficiencies remain our top priority for the short term. Order rates also held up better than expected as we saw solid new bookings in the quarter, driven by a couple of large projects that included an LNG terminal and
a pipeline project.

[0001193125-15-277912:8k_2_02:11]
“The continued downward pressure on oil prices has significantly reduced capital spending throughout the energy
markets. Although it is not clear how long this cycle will extend, we anticipate slowing order rates throughout the remainder of 2015 and well into 2016. We continue to closely monitor activity in order to be prepared to support our customers with
their capital projects.”

[0001193125-15-277912:8k_2_02:12]
New orders placed during the third quarter of fiscal 2015 totaled $193 million compared to $167
million in the second quarter of fiscal 2015 and $172 million in the third quarter of fiscal 2014. The Company’s backlog as of June 30, 2015 was $518 million compared to $499 million as of March 31, 2015 and compared to $477 million
at the end of last year’s third quarter.

[0001193125-15-277912:8k_2_02:13]
OUTLOOK

[0001193125-15-277912:8k_2_02:14]
The following statements are based on the current expectations of the Company. These statements are forward-looking, and actual results may
differ materially as further elaborated in the last paragraph below.

[0001193125-15-277912:8k_2_02:15]
Based on its backlog and current business conditions, Powell
Industries currently expects full year fiscal 2015 revenues to range between $635 million and $665 million, compared to its previous guidance range of $625 million and $675 million. Fiscal year 2015 adjusted earnings are now expected to range
between $1.25 and $1.40 per diluted share, revised from $1.25 to $1.50 in previous guidance. The Company’s earnings guidance excludes all restructuring and separation costs and tax adjustments. Year-to-date, the Company recorded $2.2 million in
restructuring and separation costs, net of tax, and is continuing to evaluate additional restructuring that may be needed to align operating costs with expected market conditions.

[0001193125-15-277912:8k_2_02:16]
CONFERENCE CALL

[0001193125-15-277912:8k_2_02:17]
Powell Industries has
scheduled a conference call for Wednesday, August 5, 2015 at 11:00 a.m. eastern time. To participate in the conference call, dial 412-902-0030 at least 10 minutes before the call begins and ask for the Powell Industries conference call. A
replay of the call will be available approximately two hours after the live broadcast ends and will be accessible until August 12, 2015. To access the replay, dial 201-612-7415 using a passcode of 13613041#.

[0001193125-15-277912:8k_2_02:18]
Investors, analysts and the general public will also have the opportunity to listen to the conference call over the Internet by visiting
powellind.com. To listen to the live call on the web, please visit the website at least fifteen minutes before the call begins to register, download and install any necessary audio software. For those who cannot listen to the live webcast, an
archive will be available shortly after the call and will remain available for approximately 90 days at powellind.com.

[0001193125-15-277912:8k_2_02:19]
2

[0001193125-15-277912:8k_2_02:20]
Powell Industries, Inc., headquartered in Houston, engineers packaged solutions and systems for the management,
control and distribution of electrical energy. Powell markets include large industrial customers such as utilities, oil and gas producers, refineries, petrochemical plants, pulp and paper producers, mining operations and commuter
railways. For more information, please visit powellind.com.

[0001193125-15-277912:8k_2_02:21]
This press release contains references to certain non-GAAP financial measures discussed above. Please see the financial table
below for more details on these non-GAAP financial measures, including a reconciliation of these non-GAAP financial measures to net income and the reasons management believes these measures are useful to investors.

[0001193125-15-277912:8k_2_02:22]
3

[0001193125-15-277912:8k_2_02:23]
POWELL INDUSTRIES, INC. & SUBSIDIARIES

[0001193125-15-277912:8k_2_02:24]
CONDENSED CONSOLIDATED STATEMENT OF OPERATIONS

[0001193125-15-277912:8k_2_02:25]
|  |  | Three months endedJune 30, |  |  | Nine months endedJune 30, |  |
|  |  | 2015 |  |  | 2014 |  |  | 2015 |  |  | 2014 |  |
| (In thousands, except per share data) |  | (Unaudited) |  |
| Revenues |  | $ | 176,733 |  |  | $ | 150,800 |  |  | $ | 499,533 |  |  | $ | 484,967 |  |
| Cost of goods sold |  |  | 143,789 |  |  |  | 121,158 |  |  |  | 421,219 |  |  |  | 385,239 |  |
| Gross profit |  |  | 32,944 |  |  |  | 29,642 |  |  |  | 78,314 |  |  |  | 99,728 |  |
| Selling, general and administrative expenses |  |  | 18,013 |  |  |  | 23,024 |  |  |  | 58,293 |  |  |  | 66,750 |  |
| Research and development expenses |  |  | 1,642 |  |  |  | 1,791 |  |  |  | 5,108 |  |  |  | 5,787 |  |
| Restructuring and relocation expenses |  |  | 1,406 |  |  |  | — |  |  |  | 2,738 |  |  |  | — |  |
| Amortization expense |  |  | 114 |  |  |  | 122 |  |  |  | 345 |  |  |  | 658 |  |
| Operating income |  |  | 11,769 |  |  |  | 4,705 |  |  |  | 11,830 |  |  |  | 26,533 |  |
| Other income |  |  | (507 | ) |  |  | (507 | ) |  |  | (1,893 | ) |  |  | (1,014 | ) |
| Interest expense |  |  | 42 |  |  |  | 36 |  |  |  | 111 |  |  |  | 141 |  |
| Interest income |  |  | — |  |  |  | (4 | ) |  |  | (88 | ) |  |  | (10 | ) |
| Income from continuing operations before income taxes |  |  | 12,234 |  |  |  | 5,180 |  |  |  | 13,700 |  |  |  | 27,416 |  |
| Income tax provision |  |  | 5,185 |  |  |  | 2,233 |  |  |  | 10,573 |  |  |  | 10,226 |  |
| Income from continuing operations |  |  | 7,049 |  |  |  | 2,947 |  |  |  | 3,127 |  |  |  | 17,190 |  |
| Income from discontinued operations, net of tax |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 9,604 |  |
| Net income |  | $ | 7,049 |  |  | $ | 2,947 |  |  | $ | 3,127 |  |  | $ | 26,794 |  |
| Earnings per share: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Continuing operations |  | $ | 0.60 |  |  | $ | 0.25 |  |  | $ | 0.26 |  |  | $ | 1.43 |  |
| Discontinued operations |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 0.80 |  |
| Basic earnings per share |  | $ | 0.60 |  |  | $ | 0.25 |  |  | $ | 0.26 |  |  | $ | 2.23 |  |
| Continuing operations |  | $ | 0.60 |  |  | $ | 0.24 |  |  | $ | 0.26 |  |  | $ | 1.43 |  |
| Discontinued operations |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 0.80 |  |
| Diluted earnings per share |  | $ | 0.60 |  |  | $ | 0.24 |  |  | $ | 0.26 |  |  | $ | 2.23 |  |
| Weighted average shares: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  |  | 11,802 |  |  |  | 12,015 |  |  |  | 11,953 |  |  |  | 12,004 |  |
| Diluted |  |  | 11,845 |  |  |  | 12,075 |  |  |  | 11,991 |  |  |  | 12,063 |  |
| SELECTED FINANCIAL DATA: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Depreciation and Amortization |  | $ | 3,445 |  |  | $ | 2,833 |  |  | $ | 10,239 |  |  | $ | 8,428 |  |
| Capital Expenditures |  | $ | 5,554 |  |  | $ | 3,730 |  |  | $ | 34,246 |  |  | $ | 11,296 |  |

[0001193125-15-277912:8k_2_02:26]
4

[0001193125-15-277912:8k_2_02:27]
POWELL INDUSTRIES, INC. & SUBSIDIARIES

[0001193125-15-277912:8k_2_02:28]
CONDENSED CONSOLIDATED BALANCE SHEETS

[0001193125-15-277912:8k_2_02:29]
|  |  | June 30,2015 |  |  | September 30,2014 |  |
| (In thousands) |  | (Unaudited) |  |
| Assets: |  |  |  |  |  |  |  |  |
| Current assets |  | $ | 323,518 |  |  | $ | 357,327 |  |
| Property, plant and equipment (net) |  |  | 162,266 |  |  |  | 156,896 |  |
| Long-term assets |  |  | 17,639 |  |  |  | 27,220 |  |
| Total assets |  | $ | 503,423 |  |  | $ | 541,443 |  |
| Liabilities & equity: |  |  |  |  |  |  |  |  |
| Current liabilities |  | $ | 146,395 |  |  | $ | 158,099 |  |
| Long-term debt and capital lease obligations, net of current maturities |  |  | 2,400 |  |  |  | 2,800 |  |
| Deferred and other long-term liabilities |  |  | 8,980 |  |  |  | 9,447 |  |
| Stockholders’ equity |  |  | 345,648 |  |  |  | 371,097 |  |
| Total liabilities and stockholders’ equity |  | $ | 503,423 |  |  | $ | 541,443 |  |

[0001193125-15-277912:8k_2_02:30]
5

[0001193125-15-277912:8k_2_02:31]
POWELL INDUSTRIES, INC. & SUBSIDIARIES

[0001193125-15-277912:8k_2_02:32]
NON-GAAP NET INCOME RECONCILIATION

[0001193125-15-277912:8k_2_02:33]
|  |  | Three months endedJune 30, |  |  | Nine months endedJune 30, |  |
| (In thousands) |  | 2015 |  |  | 2014 |  |  | 2015 |  |  | 2014 |  |
|  | (Unaudited) |  |  | (Unaudited) |  |
| Net Income: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Income from continuing operations |  | $ | 7,049 |  |  | $ | 2,947 |  |  | $ | 3,127 |  |  | $ | 17,190 |  |
| Income tax reserve release (FIN 48) |  |  | — |  |  |  | — |  |  |  | (4,149 | ) |  |  | — |  |
| Restructuring and separation costs, net of tax |  |  | 1,341 |  |  |  | — |  |  |  | 2,207 |  |  |  | — |  |
| Canadian tax valuation allowance |  |  | — |  |  |  | — |  |  |  | 8,996 |  |  |  | — |  |
| Non-GAAP net income from continuing operations |  | $ | 8,390 |  |  | $ | 2,947 |  |  | $ | 10,181 |  |  | $ | 17,190 |  |
| Diluted shares outstanding |  |  | 11,845 |  |  |  | 12,075 |  |  |  | 11,991 |  |  |  | 12,063 |  |
| Diluted Earnings Per Share: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Earnings (loss) per share |  | $ | 0.60 |  |  | $ | 0.24 |  |  | $ | 0.26 |  |  | $ | 1.43 |  |
| Non-GAAP earnings per share |  | $ | 0.71 |  |  | $ | 0.24 |  |  | $ | 0.85 |  |  | $ | 1.43 |  |

[0001193125-15-277912:8k_2_02:34]
For all periods presented, the Company defines non-GAAP net income as net income from continuing operations which excludes:
1) the Income tax reserve release (FIN 48); 2) Restructuring and separation costs, net of tax; and 3) the Canadian tax valuation allowance. Non-GAAP financial measures should not be considered a substitute for, or superior to, measures of financial
performance prepared in accordance with GAAP. However, the Company believes by excluding these items, these non-GAAP financial measures are helpful in comparing the historical results to current results and measuring operating earnings trends. The
Company also believes the disclosure of non-GAAP net income will help investors meaningfully evaluate and compare its cash flow generating capacity from quarter to quarter and year to year.

[0001193125-15-277912:8k_2_02:35]
The non-GAAP adjustments, and the basis for excluding them from GAAP financial measures, are outlined below:

[0001193125-15-277912:8k_2_02:36]
|  | • |  | Income tax reserve release (FIN 48) – In the second quarter of Fiscal 2015, we released an income tax reserve of $4.1 million for R&D tax credits upon the closing of an IRS audit |

[0001193125-15-277912:8k_2_02:37]
|  | • |  | Restructuring and separation costs, net of tax – In Fiscal 2015, we incurred restructuring and separation costs of approximately $1.3 million in the third quarter and $2.2 million year-to-date to align our operating cost structure with expected market conditions. |

[0001193125-15-277912:8k_2_02:38]
|  | • |  | Canadian tax valuation allowance – In the second quarter of Fiscal 2015, we established a $9.0 million valuation allowance against the Canadian deferred tax assets because we believe that we may not be able to realize the benefits of the deductible differences based on the historical Canadian losses. |

[0001193125-15-277912:8k_2_02:39]
Due to the nature of
these items, the Company does not believe that these items reflect its ongoing operations.

[0001193125-15-277912:8k_2_02:40]
# # #

[0001193125-15-277912:8k_2_02:41]
6
