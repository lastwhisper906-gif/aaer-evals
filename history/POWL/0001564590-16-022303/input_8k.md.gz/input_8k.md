# POWL 8-K — 0001193125-16-669308 filed 2016-08-03

## item codes, every 8-K on or before 2016-08-03

- 2016-08-03 0001193125-16-669308 — 2.02, 8.01, 9.01
- 2016-05-04 0001193125-16-576528 — 2.02, 8.01, 9.01
- 2016-02-25 0001193125-16-477896 — 5.07
- 2016-02-03 0001193125-16-449052 — 2.02, 8.01, 9.01
- 2015-12-31 0001193125-15-418363 — 5.02, 7.01, 9.01
- 2015-12-02 0001193125-15-393109 — 2.02, 9.01
- 2015-11-05 0001193125-15-368085 — 8.01, 9.01
- 2015-09-25 0001193125-15-329031 — 5.02
- 2015-08-05 0001193125-15-277912 — 2.02, 8.01, 9.01
- 2015-05-06 0001193125-15-174291 — 2.02, 8.01, 9.01
- 2015-03-06 0001193125-15-081070 — 5.02
- 2015-03-02 0001193125-15-072946 — 5.07
- 2015-02-03 0001193125-15-031772 — 2.02, 8.01, 9.01
- 2014-12-18 0001193125-14-446513 — 8.01, 9.01
- 2014-12-03 0001193125-14-431745 — 2.02, 9.01
- 2014-11-05 0001193125-14-397955 — 8.01, 9.01
- 2014-09-26 0001193125-14-353741 — 7.01, 9.01
- 2014-08-05 0001193125-14-296001 — 2.02, 8.01, 9.01
- 2014-05-07 0001193125-14-187496 — 2.02, 8.01, 9.01
- 2014-03-03 0001193125-14-079843 — 5.02, 5.07
- 2014-02-05 0001193125-14-036633 — 2.02, 8.01, 9.01
- 2014-01-17 0001193125-14-014351 — 1.01, 8.01, 9.01
- 2014-01-06 0001193125-14-002795 — 1.01, 2.03
- 2013-12-06 0001564590-13-001411 — 2.02, 9.01
- 2013-12-05 0001564590-13-001406 — 5.02, 8.01, 9.01
- 2013-11-07 0001193125-13-432950 — 8.01, 9.01
- 2013-08-07 0001193125-13-324337 — 2.02, 9.01
- 2013-05-08 0001193125-13-206800 — 2.02, 9.01
- 2013-02-22 0001193125-13-070971 — 5.02, 5.07
- 2013-02-06 0001193125-13-040556 — 2.02, 9.01
- 2012-12-18 0001193125-12-506417 — 5.02, 9.01
- 2012-12-05 0001193125-12-491749 — 2.02, 9.01
- 2012-10-12 0001193125-12-421889 — 3.03, 5.02, 5.03, 9.01
- 2012-08-09 0001193125-12-344617 — 5.02, 8.01, 9.01
- 2012-08-08 0001193125-12-343630 — 2.02, 9.01
- 2012-05-09 0001193125-12-221356 — 2.02, 9.01
- 2012-02-08 0001193125-12-046560 — 2.02, 9.01
- 2011-12-08 0001193125-11-334810 — 2.02, 9.01
- 2011-11-08 0000950123-11-096524 — 2.02, 2.06, 4.02, 9.01
- 2011-10-14 0000950123-11-090124 — 5.02
- 2011-10-06 0000950123-11-088969 — 5.02
- 2011-09-19 0000950123-11-085224 — 5.02, 9.01
- 2011-09-15 0000950123-11-084806 — 5.02, 9.01
- 2011-08-04 0000950123-11-072788 — 2.02, 9.01
- 2011-07-22 0000950123-11-067402 — 5.07
- 2011-05-24 0000950123-11-053550 — 1.01, 2.03, 9.01
- 2011-05-04 0000950123-11-044561 — 2.02, 9.01
- 2011-02-02 0000950123-11-008188 — 2.02, 9.01
- 2010-12-08 0000950123-10-111987 — 2.02, 9.01
- 2010-08-05 0000950123-10-073114 — 2.02, 9.01
- 2010-05-18 0000950123-10-050900 — 5.02
- 2010-05-05 0000950123-10-044499 — 2.02, 9.01
- 2010-02-03 0000950123-10-008278 — 2.02, 9.01
- 2009-12-21 0000950123-09-072269 — 1.01, 2.01, 2.03, 8.01, 9.01
- 2009-12-09 0000950123-09-069525 — 2.02, 9.01
- 2009-10-27 0000950123-09-053501 — 1.01, 8.01, 9.01
- 2009-08-04 0000950123-09-029476 — 2.02, 9.01
- 2009-05-06 0000950129-09-001498 — 2.02, 9.01
- 2009-03-05 0000950129-09-000749 — 1.01, 9.01
- 2009-02-10 0000950129-09-000349 — 2.02, 9.01
- 2008-12-10 0000950134-08-021934 — 2.02, 9.01
- 2008-08-06 0000950129-08-004267 — 2.02, 9.01
- 2008-07-24 0000950129-08-004063 — 1.01, 5.02, 8.01, 9.01
- 2008-06-16 0000950129-08-003500 — 9.01 — amendment of 0000950134-06-015374
- 2008-06-05 0000950129-08-003378 — 5.02, 9.01
- 2008-05-08 0000950129-08-002843 — 2.02, 9.01
- 2008-02-06 0000950129-08-000533 — 2.02, 9.01
- 2007-12-19 0000950129-07-006277 — 1.01, 2.03, 9.01
- 2007-12-06 0000950129-07-006003 — 2.02, 9.01
- 2007-08-21 0000950129-07-004181 — 2.02, 9.01
- 2007-05-31 0000950129-07-002810 — 2.02, 9.01
- 2007-05-21 0000950129-07-002668 — 2.02, 3.01, 4.02, 9.01
- 2007-04-16 0000950129-07-002002 — 2.02, 4.02, 9.01
- 2007-03-01 0000950129-07-001104 — 5.02, 8.01, 9.01
- 2007-02-08 0000950129-07-000451 — 2.02, 9.01
- 2006-12-08 0000950129-06-010041 — 2.02, 9.01
- 2006-09-08 0000950129-06-008379 — 2.02, 9.01
- 2006-08-09 0000950134-06-015374 — 1.01, 2.01, 8.01, 9.01
- 2006-06-08 0000950129-06-006127 — 2.02, 9.01
- 2006-03-09 0000950129-06-002455 — 2.02, 9.01
- 2005-12-16 0000950129-05-012031 — 2.02, 5.03, 9.01
- 2005-09-13 0000950129-05-009181 — 2.01, 9.01 — amendment of 0000950129-05-006889
- 2005-09-12 0000950129-05-009151 — 2.02, 9.01
- 2005-07-06 0000950129-05-006889 — 1.01, 1.02, 2.01, 2.03, 9.01
- 2005-06-10 0000950129-05-006128 — 2.02, 9.01
- 2005-04-20 0000080420-05-000031 — 5.02
- 2005-03-11 0000080420-05-000024 — 9.01
- 2005-02-25 0000080420-05-000018 — 7.01, 9.01
- 2005-01-21 0000080420-05-000009 — 7.01, 9.01
- 2004-12-17 0000080420-04-000049 — 2.02, 9.01
- 2004-11-01 0000080420-04-000045 — 8.01, 9.01
- 2004-10-08 0001169232-04-005133 — 2.05
- 2004-09-14 0000080420-04-000037 — 5.02
- 2004-09-02 0000080420-04-000030 — 2.02, 9.01
- 2004-06-08 0000080420-04-000021 — 7
- 2004-05-13 0000080420-04-000019 — 4
- 2004-02-27 0000080420-04-000013 — 7
- 2003-12-16 0000950129-03-006136 — 12, 7
- 2003-08-29 0000950129-03-004531 — 12, 7
- 2003-06-03 0000950129-03-003035 — 7, 9
- 2003-05-15 0000950129-03-002812 — 7, 9
- 2002-05-29 0000950129-02-002795 — 4
- 2000-12-21 0000950129-00-006093 — 5, 7
- 1998-09-04 0000950129-98-003802 — 5
- 1996-08-09 0000950129-96-001705 — 2, 7

## late-filing notifications on or before 2016-08-03

- 2007-05-11 0000950129-07-002494 — NT 10-Q, for the period ended 2007-03-31
- 2005-01-18 0000080420-05-000004 — NT 10-K, for the period ended 2004-10-31

## item 2.02 — earnings release, exhibit 99.1

[0001193125-16-669308:8k_2_02:1]
EX-99.1
2
d236760dex991.htm
EX-99.1

[0001193125-16-669308:8k_2_02:2]
EX-99.1

[0001193125-16-669308:8k_2_02:3]
Exhibit 99.1

[0001193125-16-669308:8k_2_02:4]
|  |  | PRESS RELEASE |

[0001193125-16-669308:8k_2_02:5]
|  |  |  |  | Contacts: |  | Don R. Madison, CFO |
|  |  |  |  |  |  | Powell Industries, Inc. |
| FOR IMMEDIATE RELEASE |  |  |  |  |  | 713-947-4422 |

[0001193125-16-669308:8k_2_02:6]
POWELL INDUSTRIES ANNOUNCES FISCAL 2016

[0001193125-16-669308:8k_2_02:7]
THIRD QUARTER RESULTS

[0001193125-16-669308:8k_2_02:8]
HOUSTON —
AUGUST 2, 2016 — Powell Industries, Inc. (NASDAQ: POWL), a leading supplier of custom engineered solutions for the management, control and distribution of electrical energy, today announced results for the fiscal 2016 third quarter ended
June 30, 2016.

[0001193125-16-669308:8k_2_02:9]
Revenues for the third quarter of fiscal 2016 were $133.2 million compared to revenues of $176.7 million for the
third quarter of fiscal 2015. The Company reported net income for the third quarter of $4.9 million, or $0.43 per diluted share, compared to net income of $7.0 million, or $0.60 per diluted share, for the third quarter of fiscal 2015. Excluding
restructuring and separation costs, net income for the third quarter of fiscal 2016 was $5.4 million, or $0.47 per diluted share. A reconciliation of this non-GAAP financial measure to net income is included in the financial tables below.

[0001193125-16-669308:8k_2_02:10]
Thomas W. Powell, President and Chief Executive Officer, stated, “Project execution and manufacturing efficiencies continued to drive
margin improvement in spite of lower revenues. We are particularly pleased with performance improvements at both our Houston and UK operations. Our Canadian operations continued their strong performance from last quarter.

[0001193125-16-669308:8k_2_02:11]
“Market conditions and competitive price pressures during the third quarter were particularly difficult. Reduced capital spending in our
primary oil and gas markets limited the available project opportunities and reduced our bookings and backlog. While we anticipate these challenging market conditions could persist well into 2017, we remain committed to supporting our customers and
delivering the high performance they deserve.”

[0001193125-16-669308:8k_2_02:12]
New orders placed during the third quarter of fiscal 2016 totaled $88 million
compared to $117 million in the second quarter of fiscal 2016 and $193 million in the third quarter of fiscal 2015. The Company’s backlog as of June 30, 2016 was $312 million compared to $357 million as of March 31, 2016 and compared
to $518 million at the end of last year’s third quarter.

[0001193125-16-669308:8k_2_02:13]
OUTLOOK

[0001193125-16-669308:8k_2_02:14]
The following statements are based on the current expectations of the Company. These statements are forward-looking, and actual results may
differ materially as further elaborated in the last paragraph below.

[0001193125-16-669308:8k_2_02:15]
Reflecting current backlog and business conditions, Powell expects
full year fiscal 2016 revenues to range between $550 million and $565 million, compared to previous forecast of $520 million and $560 million, and fiscal year 2016 adjusted earnings to range between $1.30 and $1.45 per diluted share, compared to
previous forecast of $0.80 and $1.10 per diluted share. The Company’s earnings guidance excludes restructuring and separation costs, as reflected in the Non-GAAP Net Income Reconciliation. Powell recorded $7.7 million in restructuring and
separation costs in the first nine months of fiscal 2016 and will continue to evaluate additional restructuring that may be required to align operating costs with anticipated market conditions.

[0001193125-16-669308:8k_2_02:16]
CONFERENCE CALL

[0001193125-16-669308:8k_2_02:17]
Powell Industries has
scheduled a conference call for Wednesday, August 3, 2016 at 11:00 a.m. Eastern time. To participate in the conference call, dial 412-902-0030 at least 10 minutes before the call begins and ask for the Powell Industries conference call. A
replay of the call will be available approximately two hours after the live broadcast ends and will be accessible until August 10, 2016. To access the replay, dial 201-612-7415 using a passcode of 13640312#.

[0001193125-16-669308:8k_2_02:18]
Investors, analysts and the general public will also have the opportunity to listen to the conference call over the Internet by visiting
powellind.com. To listen to the live call on the web, please visit the website at least fifteen minutes before the call begins to register, download and install any necessary audio software. For those who cannot listen to the live webcast, an
archive will be available shortly after the call and will remain available for approximately 90 days at powellind.com.

[0001193125-16-669308:8k_2_02:19]
Powell Industries,
Inc., headquartered in Houston, engineers packaged solutions and systems for the management, control and distribution of electrical energy. Powell markets include large industrial customers such as utilities, oil and gas producers, refineries,
petrochemical plants, pulp and paper producers, mining operations and commuter railways. For more information, please visit powellind.com.

[0001193125-16-669308:8k_2_02:20]
2

[0001193125-16-669308:8k_2_02:21]
This press release contains references to certain non-GAAP financial measures discussed above. Please see the financial table below for
more details on these non-GAAP financial measures, including a reconciliation of these non-GAAP financial measures to net income and the reasons management believes these measures are useful to investors.

[0001193125-16-669308:8k_2_02:22]
3

[0001193125-16-669308:8k_2_02:23]
POWELL INDUSTRIES, INC. & SUBSIDIARIES

[0001193125-16-669308:8k_2_02:24]
CONDENSED CONSOLIDATED STATEMENT OF OPERATIONS

[0001193125-16-669308:8k_2_02:25]
|  |  | Three months endedJune 30, |  |  | Nine months endedJune 30, |  |
|  |  | 2016 |  |  | 2015 |  |  | 2016 |  |  | 2015 |  |
| (In thousands, except per share data) |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | (Unaudited) |  |
| Revenues |  | $ | 133,207 |  |  | $ | 176,733 |  |  | $ | 435,450 |  |  | $ | 499,533 |  |
| Cost of goods sold |  |  | 105,922 |  |  |  | 143,789 |  |  |  | 354,921 |  |  |  | 421,219 |  |
| Gross profit |  |  | 27,285 |  |  |  | 32,944 |  |  |  | 80,529 |  |  |  | 78,314 |  |
| Selling, general and administrative expenses |  |  | 19,362 |  |  |  | 18,013 |  |  |  | 57,787 |  |  |  | 58,293 |  |
| Research and development expenses |  |  | 1,640 |  |  |  | 1,642 |  |  |  | 5,453 |  |  |  | 5,108 |  |
| Amortization of intangible assets |  |  | 89 |  |  |  | 114 |  |  |  | 263 |  |  |  | 345 |  |
| Restructuring and separation expenses |  |  | 647 |  |  |  | 1,406 |  |  |  | 7,703 |  |  |  | 2,738 |  |
| Operating income |  |  | 5,547 |  |  |  | 11,769 |  |  |  | 9,323 |  |  |  | 11,830 |  |
| Other income |  |  | (507 | ) |  |  | (507 | ) |  |  | (1,522 | ) |  |  | (1,893 | ) |
| Interest expense |  |  | 38 |  |  |  | 42 |  |  |  | 112 |  |  |  | 111 |  |
| Interest income |  |  | (42 | ) |  |  | — |  |  |  | (113 | ) |  |  | (88 | ) |
| Income before income taxes |  |  | 6,058 |  |  |  | 12,234 |  |  |  | 10,846 |  |  |  | 13,700 |  |
| Income tax provision (benefit) |  |  | 1,164 |  |  |  | 5,185 |  |  |  | 844 |  |  |  | 10,573 |  |
| Net income |  | $ | 4,894 |  |  | $ | 7,049 |  |  | $ | 10,002 |  |  | $ | 3,127 |  |
| Earnings per share: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  | $ | 0.43 |  |  | $ | 0.60 |  |  | $ | 0.88 |  |  | $ | 0.26 |  |
| Diluted |  | $ | 0.43 |  |  | $ | 0.60 |  |  | $ | 0.87 |  |  | $ | 0.26 |  |
| Weighted average shares: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  |  | 11,397 |  |  |  | 11,802 |  |  |  | 11,387 |  |  |  | 11,953 |  |
| Diluted |  |  | 11,473 |  |  |  | 11,845 |  |  |  | 11,435 |  |  |  | 11,991 |  |
| SELECTED FINANCIAL DATA: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Depreciation and Amortization |  | $ | 3,372 |  |  | $ | 3,445 |  |  | $ | 10,064 |  |  | $ | 10,239 |  |
| Capital Expenditures |  | $ | 874 |  |  | $ | 5,554 |  |  | $ | 2,000 |  |  | $ | 34,246 |  |
| Dividends Paid |  | $ | 2,961 |  |  | $ | 3,062 |  |  | $ | 8,882 |  |  | $ | 9,326 |  |

[0001193125-16-669308:8k_2_02:26]
4

[0001193125-16-669308:8k_2_02:27]
POWELL INDUSTRIES, INC. & SUBSIDIARIES

[0001193125-16-669308:8k_2_02:28]
CONDENSED CONSOLIDATED BALANCE SHEETS

[0001193125-16-669308:8k_2_02:29]
|  |  | June 30,2016 |  |  | September 30,2015 |  |
| (In thousands) |  | (Unaudited) |  |
| Assets: |  |  |  |  |  |  |  |  |
| Cash |  | $ | 89,351 |  |  | $ | 43,569 |  |
| Other current assets |  |  | 209,609 |  |  |  | 253,530 |  |
| Property, plant and equipment (net) |  |  | 147,810 |  |  |  | 154,594 |  |
| Long-term assets |  |  | 13,636 |  |  |  | 17,131 |  |
| Total assets |  | $ | 460,406 |  |  | $ | 468,824 |  |
| Liabilities & equity: |  |  |  |  |  |  |  |  |
| Current liabilities |  | $ | 116,437 |  |  | $ | 124,952 |  |
| Long-term debt, net of current maturities |  |  | 2,000 |  |  |  | 2,400 |  |
| Deferred and other long-term liabilities |  |  | 7,369 |  |  |  | 8,210 |  |
| Stockholders’ equity |  |  | 334,600 |  |  |  | 333,262 |  |
| Total liabilities and stockholders’ equity |  | $ | 460,406 |  |  | $ | 468,824 |  |
| SELECTED FINANCIAL DATA: |  |  |  |  |  |  |  |  |
| Working capital |  | $ | 182,523 |  |  | $ | 172,147 |  |

[0001193125-16-669308:8k_2_02:30]
5

[0001193125-16-669308:8k_2_02:31]
POWELL INDUSTRIES, INC. & SUBSIDIARIES

[0001193125-16-669308:8k_2_02:32]
NON-GAAP NET INCOME RECONCILIATION

[0001193125-16-669308:8k_2_02:33]
|  |  | Three months endedJune 30, |  |  | Nine months endedJune 30, |  |
| (In thousands) |  | 2016 |  |  | 2015 |  |  | 2016 |  |  | 2015 |  |
|  |  | (Unaudited) |  |  | (Unaudited) |  |
| Reconciliation of GAAP Net Income to Non-GAAP Net Income: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| GAAP Net income |  | $ | 4,894 |  |  | $ | 7,049 |  |  | $ | 10,002 |  |  | $ | 3,127 |  |
| Non-GAAP items: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Restructuring and separation costs |  |  | 647 |  |  |  | 1,406 |  |  |  | 7,703 |  |  |  | 2,738 |  |
| Income tax reserve release (FIN 48) |  |  | — |  |  |  | — |  |  |  | — |  |  |  | (4,149 | ) |
| Canadian tax valuation allowance |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 8,996 |  |
| Income tax effect of non-GAAP items |  |  | (132 | ) |  |  | (65 | ) |  |  | (2,424 | ) |  |  | (531 | ) |
| Non-GAAP Net income |  | $ | 5,409 |  |  | $ | 8,390 |  |  | $ | 15,281 |  |  | $ | 10,181 |  |
| Diluted shares outstanding |  |  | 11,473 |  |  |  | 11,845 |  |  |  | 11,435 |  |  |  | 11,991 |  |
| Diluted Earnings Per Share: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| GAAP earnings per share |  | $ | 0.43 |  |  | $ | 0.60 |  |  | $ | 0.87 |  |  | $ | 0.26 |  |
| Non-GAAP earnings per share |  | $ | 0.47 |  |  | $ | 0.71 |  |  | $ | 1.34 |  |  | $ | 0.85 |  |

[0001193125-16-669308:8k_2_02:34]
For all periods presented, the Company defines non-GAAP net income as net income which excludes: 1) Restructuring and
separation costs; 2) the income tax reserve release (FIN 48); and 3) the Canadian tax valuation allowance. The income tax effect is based on the applicable statutory rate. Non-GAAP financial measures should not be considered a substitute for, or
superior to, measures of financial performance prepared in accordance with GAAP. However, the Company believes by excluding these items, these non-GAAP financial measures are helpful in comparing the historical results to current results because
this non-GAAP information provides consistent measures of the underlying results of our ongoing operations. The Company also believes the disclosure of non-GAAP net income will help investors meaningfully evaluate and compare its cash flow
generating capacity from quarter to quarter and year to year.

[0001193125-16-669308:8k_2_02:35]
The non-GAAP items, and the basis for excluding them from GAAP financial measures,
are outlined below:

[0001193125-16-669308:8k_2_02:36]
|  | • |  | Restructuring and separation costs– For the nine months ended June 30, 2016, we recorded $7.7 million in restructuring and separation costs due to the restructuring of our senior management team and the alignment of our salaried and hourly workforce with future production requirements. For the nine months ended June 30, 2015, we incurred $2.2 million in restructuring and separation costs. |

[0001193125-16-669308:8k_2_02:37]
|  | • |  | Income tax reserve release (FIN 48) – In the nine months ended June 30, 2015, we released an income tax reserve of $4.1 million for R&D tax credits upon the closing of an IRS audit |

[0001193125-16-669308:8k_2_02:38]
|  | • |  | Canadian tax valuation allowance - In the nine months ended June 30, 2015, we established a $9.0 million valuation allowance against the Canadian deferred tax assets because we anticipated that we might not be able to realize the benefits of the net operating loss carryforwards and other deductible differences. |

[0001193125-16-669308:8k_2_02:39]
Due to the
nature of these items, the Company does not believe that these items reflect its ongoing operations.

[0001193125-16-669308:8k_2_02:40]
# # #

[0001193125-16-669308:8k_2_02:41]
6
