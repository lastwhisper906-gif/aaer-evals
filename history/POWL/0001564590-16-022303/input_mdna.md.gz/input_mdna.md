# POWL MD&A — 0001564590-16-022303


## mdna

[0001564590-16-022303:mdna:1]
[same as prior period, unchanged from 0001564590-16-017619:mdna:1]

[0001564590-16-022303:mdna:2]
[same as prior period, unchanged from 0001564590-16-017619:mdna:2]

[0001564590-16-022303:mdna:3]
[same as prior period, unchanged from 0001564590-16-017619:mdna:3]

[0001564590-16-022303:mdna:4]
We develop, design, manufacture and service custom-engineered equipment and systems for the distribution, control and monitoring of electrical energy. Headquartered in Houston, Texas, we serve the oil and gas refining, offshore oil and gas production, petrochemical, pipeline, terminal, mining and metals, light rail traction power, electric utility, pulp and paper and other industrial markets. Revenues and costs are primarily related to custom engineered-to-order equipment and systems and are accounted for under percentage-of-completion accounting which precludes us from providing detailed price and volume information. Our backlog includes various projects that take a number of months to produce.

[0001564590-16-022303:mdna:5]
The markets in which we participate are capital intensive and cyclical in nature. Cyclicality is predominantly driven by customer demand, global economic conditions and anticipated environmental, safety or regulatory changes that affect the manner in which our customers proceed with capital investments. Our customers analyze various factors including the demand and price for oil, gas and electrical energy, the overall economic and financial environment, governmental budgets, regulatory actions and environmental concerns. These factors influence the release of new capital projects by our customers, which are traditionally awarded in competitive bid situations. Scheduling of projects is matched to the customer requirements and projects typically take a number of months to produce.  Schedules may change during the course of any particular project and our operating results can therefore be impacted by factors outside of our control.

[0001564590-16-022303:mdna:6]
Our strategy in Canada has been to replicate our U.S. project-based integration model which allows for the design, fabrication, integration and testing of our products at a single location.  This strategic initiative presented challenges for our Canadian operations over the last two years resulting in inefficiencies that led to higher operating costs, gross margin deterioration and operating losses.  While we have taken various actions in Canada and have begun to see improvement in our operational efficiencies during Fiscal 2016, market conditions continue to have a negative impact on us.

[0001564590-16-022303:mdna:7]
During Fiscal 2015, our consolidated operating results were negatively impacted by operational inefficiencies resulting from increased volume and project scheduling delays. Our inability to meet contractual commitments on existing projects, as well as delays in customer construction schedules, negatively impacted the timing and costs related to project execution. Our operating results were negatively impacted by the timing and resolution of change orders, project close-out and resolution of potential liquidated damage claims, all of which impacted gross margins during the period in which these items are resolved with our customers.

[0001564590-16-022303:mdna:8]
During Fiscal 2016, the decline in the number and size of projects in the markets we serve has decreased our revenues and backlog of projects.  In response to our reduced project backlog and continued weak market conditions, primarily in our oil and gas markets, we have taken steps to reduce our cost structure, restructure our senior management team and align our salaried and hourly workforce with future production requirements. Our Canadian operations continue to take various actions that have improved their operational efficiencies and have resulted in improved operating results.

[0001564590-16-022303:mdna:9]
[same as prior period, unchanged from 0001564590-16-017619:mdna:9]

[0001564590-16-022303:mdna:10]
Quarter Ended June 30, 2016 Compared to the Quarter Ended June 30, 2015 (Unaudited)

[0001564590-16-022303:mdna:11]
[same as prior period, unchanged from 0001564590-16-017619:mdna:11]

[0001564590-16-022303:mdna:12]
Revenues decreased by 25%, or $43.5 million, to $133.2 million in the third quarter of Fiscal 2016, compared to the third quarter of Fiscal 2015, primarily due to the continued decrease in our project backlog mainly driven by lower demand from our customers in the oil and gas markets.  Domestic revenues decreased by 30%, or $40.0 million, to $94.0 million in the third quarter of Fiscal 2016, compared to the third quarter of Fiscal 2015, and international revenues decreased by 8%, or $3.5 million, to $39.2 million in the third quarter of Fiscal 2016, compared to the third quarter of Fiscal 2015 due to the reduced number of large projects in our overseas markets year over year. Revenues from commercial and industrial customers decreased $47.0 million to $99.7 million in the third quarter of Fiscal 2016, compared to the third quarter of Fiscal 2015. Revenues from public and private utilities increased $6.3 million to $22.8 million in the third quarter of Fiscal 2016, compared to the third quarter of Fiscal 2015.  Revenues from municipal and transit projects decreased $2.8 million to $10.7 million in the third quarter of Fiscal 2016, compared to the third quarter of Fiscal 2015.

[0001564590-16-022303:mdna:13]
Gross profit for the third quarter of Fiscal 2016 decreased 17%, or $5.7 million, to $27.3 million, compared to the third quarter of Fiscal 2015, primarily due to the decrease in revenues.  Gross profit as a percentage of revenues increased to 21% in the third quarter of Fiscal 2016, compared to 19% in the third quarter of Fiscal 2015, due to improvements in our international operations primarily driven by improved project execution, operational efficiency and reduced costs in our Canadian operations. The increase in gross

[0001564590-16-022303:mdna:14]
profit from our international operations was offset by a decline in gross profit from our domestic operations as margins were negatively impacted primarily by our reduced volume as a result of weak market conditions, reduced project backlog and cost overruns related to a large transit project.

[0001564590-16-022303:mdna:15]
[same as prior period, unchanged from 0001564590-16-017619:mdna:14]

[0001564590-16-022303:mdna:16]
Selling, general and administrative expenses increased $1.3 million to $19.4 million during the third quarter of Fiscal 2016 compared to the third quarter of Fiscal 2015, primarily due to an increase in performance-based compensation accruals, partially offset by cost reduction efforts.  Selling, general and administrative expenses, as a percentage of revenues, increased to 15% during the third quarter of Fiscal 2016, compared to 10% during the third quarter of Fiscal 2015 due to increased expenses and the reduction in revenue quarter over quarter.

[0001564590-16-022303:mdna:17]
[same as prior period, unchanged from 0001564590-16-017619:mdna:16]

[0001564590-16-022303:mdna:18]
In the third quarter of Fiscal 2016, we incurred approximately $0.4 million of separation costs as we continued to align our workforce with future production requirements.  Additionally in the third quarter of Fiscal 2016, we incurred approximately $0.3 million of restructuring costs related to a leased Canadian facility that we exited in the third quarter of Fiscal 2015.  In the third quarter of Fiscal 2015, we incurred $1.4 million of restructuring and separation costs.

[0001564590-16-022303:mdna:19]
[same as prior period, unchanged from 0001564590-16-017619:mdna:18]

[0001564590-16-022303:mdna:20]
We recorded an income tax provision of $1.2 million in the third quarter of Fiscal 2016, compared to an income tax provision of $5.2 million in the third quarter of Fiscal 2015.  The effective tax rate for the third quarter of Fiscal 2016 was 19% compared to an effective tax rate of 42% in the third quarter of Fiscal 2015.  The effective tax rate for Fiscal 2016 was favorably impacted by the mix of income from our Canadian operations and the utilization of net operating loss carryforwards in Canada that are fully reserved with a valuation allowance.  The effective tax rate for the third quarter of Fiscal 2015 was above the combined U.S. federal and state statutory rate as no tax benefit is recorded against Canadian pre-tax losses due to the $9.0 million valuation allowance recorded in the second quarter of Fiscal 2015 discussed in Note I of the Notes to Condensed Consolidated Financial Statements.

[0001564590-16-022303:mdna:21]
Net income

[0001564590-16-022303:mdna:22]
In the third quarter of Fiscal 2016, we recorded net income of $4.9 million, or $0.43 per diluted share, which decreased from net income of $7.0 million, or $0.60 per diluted share, in the third quarter of Fiscal 2015.  This decrease in net income was primarily due to the decrease in revenues as we continue to see a decrease in our project backlog mainly driven by lower demand from our customers in the oil and gas markets.

[0001564590-16-022303:mdna:23]
[same as prior period, unchanged from 0001564590-16-017619:mdna:22]

[0001564590-16-022303:mdna:24]
The order backlog at June 30, 2016 was $311.6 million, which declined from $441.4 million at September 30, 2015.  New orders declined during the third quarter of Fiscal 2016 to $88.1 million, compared to $193.2 million in the third quarter of Fiscal 2015, primarily due to lower demand from our customers in the oil and gas markets.

[0001564590-16-022303:mdna:25]
Nine Months Ended June 30, 2016 Compared to the Nine Months Ended June 30, 2015 (Unaudited)

[0001564590-16-022303:mdna:26]
[same as prior period, unchanged from 0001564590-16-017619:mdna:25]

[0001564590-16-022303:mdna:27]
Revenues decreased by 13%, or $64.1 million, to $435.4 million for the nine months ended June 30, 2016, compared to the nine months ended June 30, 2015.  Domestic revenues decreased by 13%, or $45.2 million, to $306.2 million for the nine months ended June 30, 2016, compared to the nine months ended June 30, 2015, and international revenues decreased by 13%, or $18.9 million, to $129.2 million for the nine months ended June 30, 2016, compared to the nine months ended June 30, 2015.  All revenues decreased in the nine months ended June 30, 2016 primarily due to the continued decrease in our project backlog primarily as a result of lower demand from our customers in the oil and gas markets.  Revenues from commercial and industrial customers decreased $70.2 million to $327.9 million for the nine months ended June 30, 2016, compared to the nine months ended June 30, 2015. Revenues from public and private utilities increased $13.8 million to $77.9 million for the nine months ended June 30, 2016, compared to the nine months ended June 30, 2015. Revenues from municipal and transit projects decreased $7.7 million to $29.6 million for the nine months ended June 30, 2016, compared to the nine months ended June 30, 2015.

[0001564590-16-022303:mdna:28]
Gross profit for the nine months ended June 30, 2016 increased by 3%, or $2.2 million, to $80.5 million, compared to the nine months ended June 30, 2015.  Gross profit as a percentage of revenues was 19% for the nine months ended June 30, 2016, compared to 16% for the nine months ended June 30, 2015.  Our gross profit as a percentage of revenues improved in the nine months ended June 30, 2016, compared to the nine months ended June 30, 2015, due to improvements in our international operations primarily driven by improved project execution, operational efficiency and reduced costs in our Canadian operations. The increase in gross profit from our

[0001564590-16-022303:mdna:29]
international operations was offset by a decline in gross profit from our US operations as margins were negatively impacted primarily by our reduced volume as a result of weak market conditions, reduced project backlog and cost overruns related to a large transit project.

[0001564590-16-022303:mdna:30]
[same as prior period, unchanged from 0001564590-16-017619:mdna:28]

[0001564590-16-022303:mdna:31]
Selling, general and administrative expenses decreased $0.5 million to $57.8 million for the nine months ended June 30, 2016 compared to the $58.3 million that we recorded for the nine months ended June 30, 2015. Selling, general and administrative expenses, as a percentage of revenues increased to 13% for the nine months ended June 30, 2016 compared to 12% for the nine months ended June 2015 due to the reduction in revenue year over year.

[0001564590-16-022303:mdna:32]
[same as prior period, unchanged from 0001564590-16-017619:mdna:30]

[0001564590-16-022303:mdna:33]
For the nine months ended June 30, 2016, we incurred approximately $7.7 million in restructuring and separation costs.  Of this, $3.8 million were separation costs related to the departure of our former Chief Executive Officer in December 2015.  The remaining $3.9 million were separation costs related to the restructuring of our senior management team and salaried and hourly workforce, as well as restructuring costs associated with a leased Canadian facility that we exited in the third quarter of Fiscal 2015.  In the nine months ended June 30, 2015, we incurred $2.7 million of restructuring and separation costs.

[0001564590-16-022303:mdna:34]
[same as prior period, unchanged from 0001564590-16-017619:mdna:32]

[0001564590-16-022303:mdna:35]
We recorded other income of $1.5 million in the nine months ended June 30, 2016 from the amortization of the deferred gain from the amended supply agreement, discussed in Note D of Notes to Condensed Consolidated Financial Statements.  For the nine months ended June 30, 2015, we recorded the same $1.5 million from the amortization of the deferred gain as well as a $0.4 million death benefit received from our Company-owned life insurance policy.

[0001564590-16-022303:mdna:36]
[same as prior period, unchanged from 0001564590-16-017619:mdna:34]

[0001564590-16-022303:mdna:37]
We recorded an income tax provision of $0.8 million for the nine months ended June 30, 2016, compared to an income tax provision of $10.6 million for the nine months ended June 30, 2015.  The effective tax rate for the nine months ended June 30, 2016 was 8% compared to an effective tax rate of 77% for the nine months ended June 30, 2015.  The effective tax rate for Fiscal 2016 was favorably impacted by the mix of income from our Canadian operations and the utilization of net operating loss carryforwards in Canada that are fully reserved with a valuation allowance.  Additionally, the effective tax rate for the nine months ended June 30, 2016 was favorably impacted by a $0.8 million discrete item recorded in the first quarter of Fiscal 2016 related to the retroactive reinstatement of the R&D Tax Credit for the previously expired period from January 1, 2015 to September 30, 2015.  On December 18, 2015, the “Protecting Americans from Tax Hikes Act of 2015” was enacted which retroactively reinstated and made permanent the R&D Tax Credit.

[0001564590-16-022303:mdna:38]
In the first nine months of Fiscal 2015, our effective tax rate increased due to a $9.0 million valuation allowance recorded against our Canadian deferred tax assets during the second quarter of Fiscal 2015.  Due to the historical Canadian losses, and the losses that we projected at the time of determination, we were required under the more-likely-than-not accounting standard to record a valuation allowance against the Canadian net deferred tax assets because we anticipated that we may not be able to realize the benefits of the net operating loss carryforwards and other deductible differences.   This was partially offset by the release of a $4.1 million FIN 48 reserve related to the R&D Tax Credit upon closing an IRS audit. We recorded a $0.6 million discrete item for the nine months ended June 30, 2015 that was also related to the retroactive reinstatement of the R&D Tax Credit referred to above.

[0001564590-16-022303:mdna:39]
Net income

[0001564590-16-022303:mdna:40]
For the nine months ended June 30, 2016, we recorded net income of $10.0 million, or $0.87 per diluted share, compared to $3.1 million, or $0.26 per diluted share, for the nine months ended June 30, 2015. This increase in net income was primarily due to gross profit improvement in our international operations, driven by improved project execution in our Canadian operations in the first half of Fiscal 2016, offset by the $5.0 million increase in restructuring and separation costs.  Additionally, net income has increased due to lower income tax expense in Fiscal 2016, due to the utilization of net operating losses to offset Canadian income.

[0001564590-16-022303:mdna:41]
[same as prior period, unchanged from 0001564590-16-017619:mdna:39]

[0001564590-16-022303:mdna:42]
The order backlog at June 30, 2016 was $311.6 million, which declined from $441.4 million at September 30, 2015.  New orders placed during the nine months ended June 30, 2016 totaled $306.7 million compared to $514.7 million for the nine months ended June 30, 2015.  The year over year decrease in new orders was primarily due to lower demand from our customers in the oil and gas markets.

[0001564590-16-022303:mdna:43]
[same as prior period, unchanged from 0001564590-16-017619:mdna:41]

[0001564590-16-022303:mdna:44]
Cash and cash equivalents increased to $89.4 million at June 30, 2016, compared to $43.6 million at September 30, 2015.  As of June 30, 2016, current assets exceeded current liabilities by 2.6 times and our debt to total capitalization was 0.71%.

[0001564590-16-022303:mdna:45]
We have a $75.0 million revolving credit facility in the U.S., which expires in December 2018. As of June 30, 2016, there were no amounts borrowed under this line of credit. We also have a $7.7 million revolving credit facility in Canada. At June 30, 2016, there was no balance outstanding under the Canadian revolving credit facility. Total long-term debt, including current maturities, totaled $2.4 million at June 30, 2016, compared to $2.8 million at September 30, 2015. Total letters of credit outstanding were $26.8 million at June 30, 2016 and $21.1 million at September 30, 2015, which reduced our availability under our U.S. credit facility. Amounts available at June 30, 2016 under the U.S. and Canadian revolving credit facilities were $48.2 million and $7.7 million, respectively.  For further information regarding our debt, see Notes E and F of Notes to Condensed Consolidated Financial Statements.

[0001564590-16-022303:mdna:46]
Approximately $30 million of our cash at June 30, 2016, was held outside of the United States for international operations. It is our intention to indefinitely reinvest all current and future foreign earnings internationally in order to ensure sufficient working capital to support and expand these international operations.  In the event that we elect to repatriate some or all of the foreign earnings that were previously deemed to be indefinitely reinvested outside the U.S., under current tax laws we would incur additional tax expense upon such repatriation.

[0001564590-16-022303:mdna:47]
[same as prior period, unchanged from 0001564590-16-017619:mdna:45]

[0001564590-16-022303:mdna:48]
[same as prior period, unchanged from 0001564590-16-017619:mdna:46]

[0001564590-16-022303:mdna:49]
Cash provided by operating activities increased to $61.8 million for the nine months ended June 30, 2016, compared to cash provided by operating activities of $18.6 million during the same period in Fiscal 2015. This increase was primarily due to favorable improvements in accounts receivable, and the timing of project milestone billings, continued focus on inventory reduction and timing of cash payments on accrued liabilities in the nine months ended June 30, 2016, compared to the same period in the prior year.  Cash flow from operations is primarily influenced by the timing of milestone payments from our customers and the payment terms with our suppliers, and is favorably impacted during a down cycle as project milestones are billed and collected as projects are completed.

[0001564590-16-022303:mdna:50]
[same as prior period, unchanged from 0001564590-16-017619:mdna:48]

[0001564590-16-022303:mdna:51]
Purchases of property, plant and equipment during the nine months ended June 30, 2016 totaled $2.0 million compared to $34.2 million during the same period in Fiscal 2015.  This decrease in Fiscal 2016 was due to the completion of the expansion of our Canadian facilities in Fiscal 2015.

[0001564590-16-022303:mdna:52]
[same as prior period, unchanged from 0001564590-16-017619:mdna:50]

[0001564590-16-022303:mdna:53]
Net cash used in financing activities was $14.0 million for the nine months ended June 30, 2016 and $22.8 million during the same period in Fiscal 2015.  This reduction was primarily due to the completion of our share repurchase program in December 2015 discussed below.

[0001564590-16-022303:mdna:54]
[same as prior period, unchanged from 0001564590-16-017619:mdna:52]

[0001564590-16-022303:mdna:55]
[same as prior period, unchanged from 0001564590-16-017619:mdna:53]

[0001564590-16-022303:mdna:56]
[same as prior period, unchanged from 0001564590-16-017619:mdna:54]

[0001564590-16-022303:mdna:57]
[same as prior period, unchanged from 0001564590-16-017619:mdna:55]

[0001564590-16-022303:mdna:58]
[same as prior period, unchanged from 0001564590-16-017619:mdna:56]

[0001564590-16-022303:mdna:59]
[same as prior period, unchanged from 0001564590-16-017619:mdna:57]

[0001564590-16-022303:mdna:60]
[same as prior period, unchanged from 0001564590-16-017619:mdna:58]

[0001564590-16-022303:mdna:61]
[same as prior period, unchanged from 0001564590-16-017619:mdna:59]

[0001564590-16-022303:mdna:62]
The markets in which we participate are capital-intensive and cyclical in nature. Cyclicality is predominantly driven by customer demand, global economic conditions and anticipated environmental or regulatory changes which affect the manner in which our customers proceed with capital investments. Our customers analyze various factors including the demand and price for oil, gas and electrical energy, the overall economic and financial environment, governmental budgets, regulatory actions and environmental concerns. These factors influence the release of new capital projects by our customers, which are traditionally awarded in competitive bid situations. Scheduling of projects is matched to customer requirements.  Projects typically take a number of months to produce, and schedules may change during the course of any particular project.

[0001564590-16-022303:mdna:63]
A significant portion of our revenues have historically been from the oil and gas markets.  Unfavorable long-term commodity price levels can cause oil and gas companies to change their strategies or delay or cancel projects.  Due to the precipitous decline in oil and gas prices since late 2014, many of our customers have reduced their capital budgets and cut costs, and in certain instances have deferred or cancelled projects that we were pursuing.  We believe that sustained lower oil and gas prices from a continued global supply/demand imbalance will continue to negatively impact future orders due to reduced capital spending by our customers.  The reduction in available projects, across the markets we serve, has increased market price pressures during this downward market cycle. This reduction in new business opportunities and increased market price pressures will negatively impact our backlog, revenues, operating results and cash flows from operations which could potentially result in impairment losses if the current downward market cycle continues for an extended period of time.

[0001564590-16-022303:mdna:64]
[same as prior period, unchanged from 0001564590-16-017619:mdna:62]

[0001564590-16-022303:mdna:65]
We believe that our strong working capital position, cash available, relatively low debt position and borrowing capacity under our existing credit facilities should be sufficient to finance future operating activities, research and development initiatives, capital improvements and debt repayments for the foreseeable future. We continue to monitor the factors that drive our markets and will continue to strive to maintain our leadership and competitive advantage in the markets we serve while aligning our cost structures with market conditions.
