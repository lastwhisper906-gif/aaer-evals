# POWL notes — 0001564590-16-022303


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureAndSignificantAccountingPoliciesTextBlock

[0001564590-16-022303:notes:1]
[same as prior period, unchanged from 0001564590-16-017619:notes:1]

[0001564590-16-022303:notes:2]
[same as prior period, unchanged from 0001564590-16-017619:notes:2]

[0001564590-16-022303:notes:3]
[same as prior period, unchanged from 0001564590-16-017619:notes:3]

[0001564590-16-022303:notes:4]
[same as prior period, unchanged from 0001564590-16-017619:notes:4]

[0001564590-16-022303:notes:5]
[same as prior period, unchanged from 0001564590-16-017619:notes:5]

[0001564590-16-022303:notes:6]
[same as prior period, unchanged from 0001564590-16-017619:notes:6]

[0001564590-16-022303:notes:7]
These unaudited condensed consolidated financial statements have been prepared in accordance with the instructions to Form 10-Q and Rule 10-01 of Regulation S-X for interim financial information.  Certain information and footnote disclosures, normally included in annual financial statements prepared in accordance with accounting principles generally accepted in the United States (U.S. GAAP), have been condensed or omitted pursuant to those rules and regulations. In the opinion of management, all adjustments, consisting only of normal recurring adjustments, necessary to fairly state the financial position, results of operations and cash flows with respect to the interim condensed consolidated financial statements have been included. The results of operations for the interim periods are not necessarily indicative of the results for the entire fiscal year.  We believe that these financial statements contain all adjustments necessary so that they are not misleading. The year-end balance sheet data was derived from audited financial statements, but does not include all disclosures required by U.S. GAAP.

[0001564590-16-022303:notes:8]
[same as prior period, unchanged from 0001564590-16-017619:notes:8]

[0001564590-16-022303:notes:9]
[same as prior period, unchanged from 0001564590-16-017619:notes:9]

[0001564590-16-022303:notes:10]
[same as prior period, unchanged from 0001564590-16-017619:notes:10]

[0001564590-16-022303:notes:11]
The preparation of condensed consolidated financial statements in conformity with U.S. GAAP requires management to make estimates and assumptions that affect the amounts reported in the condensed consolidated financial statements and accompanying footnotes as of the date they were prepared. The most significant estimates used in our financial statements affect revenue and cost recognition for contracts, allowance for doubtful accounts, provision for excess and obsolete inventory, goodwill and intangible assets, self-insurance, warranty accruals, liquidated damages and income taxes. The amounts recorded in the condensed consolidated financial statements require judgments that could change in future periods and actual amounts may differ from those recorded in the condensed consolidated financial statements. We base our estimates on historical experience and on various other assumptions, as well as the specific circumstances surrounding contingent liabilities, in evaluating the amount of liability that should be recorded. Additionally, the recognition of deferred tax assets, and our determination of whether the value of our long-lived assets has been impaired, requires estimates related to future income and other assumptions regarding timing and future profitability.  Estimates may change as new events occur, additional information becomes available or operating conditions change.

[0001564590-16-022303:notes:12]
[same as prior period, unchanged from 0001564590-16-017619:notes:12]

[0001564590-16-022303:notes:13]
In May 2014, the FASB issued a new standard on revenue recognition that supersedes previously issued revenue recognition guidance.  This standard provides a five-step approach to be applied to all contracts with customers and requires expanded disclosures about the nature, amount, timing and uncertainty of revenue (and the related cash flows) arising from customer contracts, significant judgments and changes in judgments used in applying the revenue model and the assets recognized from costs incurred to obtain or fulfill a contract.  This guidance is now effective for fiscal years, and interim periods within those years, beginning after December 15, 2017, which would be our fiscal year ending September 30, 2019.  The standard permits the use of either the retrospective or cumulative effect transition method; therefore, we are evaluating the effect that this new guidance will have on our consolidated financial statements and related disclosures. We have not yet selected a transition method nor have we determined the effect of the standard on our ongoing financial reporting.

[0001564590-16-022303:notes:14]
[same as prior period, unchanged from 0001564590-16-017619:notes:14]

[0001564590-16-022303:notes:15]
[same as prior period, unchanged from 0001564590-16-017619:notes:15]

[0001564590-16-022303:notes:16]
In February 2016, the FASB issued a new topic on leases which requires lessees to recognize lease assets and lease liabilities on the balance sheet for all leases with terms longer than twelve months.  Leases will be classified as either finance or operating, with classification affecting the pattern of expense recognition in the income statement.  A modified retrospective transition approach is required for lessees for capital and operating leases existing at, or entered into after, the beginning of the earliest comparative period presented in the financial statements, with certain practical expedients available. The new standard is effective for fiscal years beginning after December 15, 2018, including interim periods within those fiscal years. This would be our fiscal year ending September 30, 2020.  We are currently evaluating the impact of our pending adoption of the new standard on our consolidated financial position or results of operations.

[0001564590-16-022303:notes:17]
In March 2016, the FASB issued new guidance on stock-based compensation. The new guidance simplifies several aspects of the accounting for share-based payment transactions, including the income tax consequences, classification of awards as either equity or liabilities, and classification on the statement of cash flows. For public companies, the amendments in this standard are effective for annual periods beginning after December 15, 2016, including interim periods within those annual periods.  This would be our fiscal year ending September 30, 2018.  The adoption of this guidance is not expected to have a material impact on our consolidated financial position, results of operations or cash flows.


## us-gaap:EarningsPerShareTextBlock

[0001564590-16-022303:notes:18]
[same as prior period, unchanged from 0001564590-16-017619:notes:18]

[0001564590-16-022303:notes:19]
[same as prior period, unchanged from 0001564590-16-017619:notes:19]

[0001564590-16-022303:notes:20]
[same as prior period, unchanged from 0001564590-16-017619:notes:20]

[0001564590-16-022303:notes:21]
|  | Three months ended June 30, |  |  | Nine months ended June 30, |  |
|  | 2016 |  |  | 2015 |  |  | 2016 |  |  | 2015 |  |
| Numerator: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Net income | $ | 4,894 |  |  | $ | 7,049 |  |  | $ | 10,002 |  |  | $ | 3,127 |  |
| Denominator: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Weighted average basic shares |  | 11,397 |  |  |  | 11,802 |  |  |  | 11,387 |  |  |  | 11,953 |  |
| Dilutive effect of restricted stock units |  | 76 |  |  |  | 43 |  |  |  | 48 |  |  |  | 38 |  |
| Weighted average diluted shares with assumed conversions |  | 11,473 |  |  |  | 11,845 |  |  |  | 11,435 |  |  |  | 11,991 |  |
| Net income per share: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic | $ | 0.43 |  |  | $ | 0.60 |  |  | $ | 0.88 |  |  | $ | 0.26 |  |
| Diluted | $ | 0.43 |  |  | $ | 0.60 |  |  | $ | 0.87 |  |  | $ | 0.26 |  |


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0001564590-16-022303:notes:22]
[same as prior period, unchanged from 0001564590-16-017619:notes:23]

[0001564590-16-022303:notes:23]
[same as prior period, unchanged from 0001564590-16-017619:notes:24]

[0001564590-16-022303:notes:24]
[same as prior period, unchanged from 0001564590-16-017619:notes:25]

[0001564590-16-022303:notes:25]
|  | Three months ended June 30, |  |  | Nine months ended June 30, |  |
|  | 2016 |  |  | 2015 |  |  | 2016 |  |  | 2015 |  |
| Balance at beginning of period | $ | 976 |  |  | $ | 1,881 |  |  | $ | 746 |  |  | $ | 1,577 |  |
| Bad debt expense (recovery) |  | (118 | ) |  |  | (438 | ) |  |  | 221 |  |  |  | 31 |  |
| Uncollectible accounts written off, net of recoveries |  | 16 |  |  |  | (145 | ) |  |  | (98 | ) |  |  | (267 | ) |
| Change in foreign currency translation |  | (3 | ) |  |  | 14 |  |  |  | 2 |  |  |  | (29 | ) |
| Balance at end of period | $ | 871 |  |  | $ | 1,312 |  |  | $ | 871 |  |  | $ | 1,312 |  |

[0001564590-16-022303:notes:26]
[same as prior period, unchanged from 0001564590-16-017619:notes:27]

[0001564590-16-022303:notes:27]
[same as prior period, unchanged from 0001564590-16-017619:notes:28]

[0001564590-16-022303:notes:28]
|  | June 30, 2016 |  |  | September 30, 2015 |  |
| Raw materials, parts and subassemblies, net | $ | 27,308 |  |  | $ | 31,807 |  |
| Work-in-progress |  | 830 |  |  |  | 1,084 |  |
| Total inventories | $ | 28,138 |  |  | $ | 32,891 |  |

[0001564590-16-022303:notes:29]
[same as prior period, unchanged from 0001564590-16-017619:notes:30]

[0001564590-16-022303:notes:30]
[same as prior period, unchanged from 0001564590-16-017619:notes:31]

[0001564590-16-022303:notes:31]
|  | June 30, 2016 |  |  | September 30, 2015 |  |
| Costs incurred on uncompleted contracts | $ | 1,048,831 |  |  | $ | 912,237 |  |
| Estimated earnings |  | 332,472 |  |  |  | 271,640 |  |
|  |  | 1,381,303 |  |  |  | 1,183,877 |  |
| Less: Billings to date |  | (1,344,298 | ) |  |  | (1,121,141 | ) |
| Net underbilled position | $ | 37,005 |  |  | $ | 62,736 |  |
| Included in the accompanying balance sheets under the following captions: |  |  |  |  |  |  |  |
| Costs and estimated earnings in excess of billings on uncompleted contracts – underbilled | $ | 80,026 |  |  | $ | 104,793 |  |
| Billings in excess of costs and estimated earnings on uncompleted contracts – overbilled |  | (43,021 | ) |  |  | (42,057 | ) |
| Net underbilled position | $ | 37,005 |  |  | $ | 62,736 |  |

[0001564590-16-022303:notes:32]
[same as prior period, unchanged from 0001564590-16-017619:notes:33]

[0001564590-16-022303:notes:33]
[same as prior period, unchanged from 0001564590-16-017619:notes:34]

[0001564590-16-022303:notes:34]
|  | Three months ended June 30, |  |  | Nine months ended June 30, |  |
|  | 2016 |  |  | 2015 |  |  | 2016 |  |  | 2015 |  |
| Balance at beginning of period | $ | 4,787 |  |  | $ | 4,375 |  |  | $ | 4,930 |  |  | $ | 4,557 |  |
| Increase to warranty expense |  | 1,174 |  |  |  | 1,033 |  |  |  | 3,332 |  |  |  | 2,100 |  |
| Deduction for warranty charges |  | (1,206 | ) |  |  | (766 | ) |  |  | (3,481 | ) |  |  | (1,794 | ) |
| Change in foreign currency translation |  | (26 | ) |  |  | 81 |  |  |  | (52 | ) |  |  | (140 | ) |
| Balance at end of period | $ | 4,729 |  |  | $ | 4,723 |  |  | $ | 4,729 |  |  | $ | 4,723 |  |


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0001564590-16-022303:notes:35]
[same as prior period, unchanged from 0001564590-16-017619:notes:36]

[0001564590-16-022303:notes:36]
Our intangible assets consist of goodwill, which is not being amortized, and purchased technology, which is amortized over its estimated useful life.  Intangible assets balances, subject to amortization, at June 30, 2016 and September 30, 2015 consisted of the following (in thousands):

[0001564590-16-022303:notes:37]
|  | June 30, 2016 |  |  | September 30, 2015 |  |
|  | Gross |  |  |  |  |  |  | Net |  |  | Gross |  |  |  |  |  |  | Net |  |
|  | Carrying |  |  | Accumulated |  |  | Carrying |  |  | Carrying |  |  | Accumulated |  |  | Carrying |  |
|  | Value |  |  | Amortization |  |  | Value |  |  | Value |  |  | Amortization |  |  | Value |  |
| Purchased technology | $ | 11,749 |  |  | $ | (10,604 | ) |  | $ | 1,145 |  |  | $ | 11,749 |  |  | $ | (10,359 | ) |  | $ | 1,390 |  |
| Goodwill |  | 1,003 |  |  |  | — |  |  |  | 1,003 |  |  |  | 1,003 |  |  |  | — |  |  |  | 1,003 |  |
| Total | $ | 12,752 |  |  | $ | (10,604 | ) |  | $ | 2,148 |  |  | $ | 12,752 |  |  | $ | (10,359 | ) |  | $ | 2,393 |  |

[0001564590-16-022303:notes:38]
Amortization of intangible assets was $0.3 million for the nine months ended June 30, 2016 and 2015.

[0001564590-16-022303:notes:39]
On August 7, 2006, we purchased certain assets related to the manufacturing of ANSI medium-voltage switchgear and circuit breaker business from General Electric Company (GE).  In connection with the acquisition, we entered into a 15 year supply agreement with GE pursuant to which GE would purchase from us all of their requirements for ANSI medium-voltage switchgear and circuit breakers and other related equipment and components (the Products).  In connection with the acquisition, we recorded an intangible asset related to this supply agreement.  On December 30, 2013, we and GE amended the supply agreement to allow GE to manufacture similar Products for sale immediately and allow them to begin purchasing Products from other suppliers beginning December 31, 2014.  In return, GE paid us $10 million upon execution of the amended supply agreement and agreed to pay an additional $7 million over three years, subject to certain conditions.  As of June 30, 2016, we had $2.3 million recorded in other current assets.  We wrote off the intangible asset related to the original supply agreement and recorded a deferred credit in the amount of $8.1 million at December 31, 2013, the amount by which the proceeds from GE exceeded the unamortized balance of our intangible asset. We are amortizing this deferred credit over the four-year life of the agreement and have recognized gains in other income of $1.5 million for the nine months ended June 30, 2016 and 2015.


## us-gaap:LongTermDebtTextBlock

[0001564590-16-022303:notes:40]
E. LONG-TERM DEBT

[0001564590-16-022303:notes:41]
Long-term debt consisted of the following (in thousands):

[0001564590-16-022303:notes:42]
|  | June 30, 2016 |  |  | September 30, 2015 |  |
| Industrial development revenue bonds | $ | 2,400 |  |  | $ | 2,800 |  |
| Less current portion |  | (400 | ) |  |  | (400 | ) |
| Total long-term debt and capital lease obligations | $ | 2,000 |  |  | $ | 2,400 |  |

[0001564590-16-022303:notes:43]
U.S. Revolver

[0001564590-16-022303:notes:44]
In Fiscal 2015, we entered into the Second Amendment (the Second Amendment) of our existing amended and restated credit agreement (as amended, the Amended Credit Agreement).  The Second Amendment provided for the expansion of our Canadian manufacturing facility and allowed for the repurchase of our common stock pursuant to a share repurchase program announced in December 2014.  The Amended Credit Agreement provides for a $75.0 million revolving credit facility (U.S. Revolver).

[0001564590-16-022303:notes:45]
The interest rate for amounts outstanding under the Amended Credit Agreement for the U.S. Revolver is a floating rate based upon the higher of the Federal Funds Rate plus 0.5%, the bank’s prime rate, or the Eurocurrency rate plus 1.00%. Once the applicable rate is determined, a margin ranging up to 1.75%, as determined by our consolidated leverage ratio, is added to the applicable rate.

[0001564590-16-022303:notes:46]
The U.S. Revolver provides for the issuance of letters of credit which reduce the amounts that may be borrowed under this revolver. The amount available under the U.S. Revolver was reduced by $26.8 million for our outstanding letters of credit at June 30, 2016.

[0001564590-16-022303:notes:47]
There were no borrowings outstanding under the U.S. Revolver as of June 30, 2016.  Amounts available under the U.S. Revolver were $48.2 million at June 30, 2016. The U.S. Revolver expires on December 31, 2018.

[0001564590-16-022303:notes:48]
The Amended Credit Agreement contains certain restrictive and maintenance-type covenants, such as restrictions on the amount of capital expenditures allowed. It also contains financial covenants defining various financial measures and the levels of these measures with which we must comply, as well as a “material adverse change” clause. A “material adverse change” is defined as a material change in our operations, business, properties, liabilities or condition (financial or otherwise) or a material impairment of our ability to perform our obligations under our credit agreements.

[0001564590-16-022303:notes:49]
The Amended Credit Agreement is collateralized by a pledge of 100% of the voting capital stock of each of our domestic subsidiaries and 65% of the voting capital stock of each non-domestic subsidiary, excluding Powell Canada Inc. The Amended Credit Agreement provides for customary events of default and carries cross-default provisions with other existing debt agreements. If an event of default (as defined in the Amended Credit Agreement) occurs and is continuing, on the terms and subject to the conditions set forth in the Amended Credit Agreement, amounts outstanding under the Amended Credit Agreement may be accelerated and may become immediately due and payable. As of June 30, 2016, we were in compliance with all of the financial covenants of the Amended Credit Agreement.

[0001564590-16-022303:notes:50]
Canadian Revolver

[0001564590-16-022303:notes:51]
We have a $7.7 million credit agreement with a major international bank in Canada (the Canadian Revolver) to provide working capital support and letters of credit for our operations in Canada. The Canadian Revolver provides for the issuance of letters of credit which reduce the amounts that may be borrowed under this revolver.  There were no outstanding letters of credit under the Canadian Revolver at June 30, 2016.

[0001564590-16-022303:notes:52]
There were no borrowings outstanding under the Canadian Revolver as of June 30, 2016 and amounts available under the Canadian Revolver were $7.7 million at June 30, 2016.  The interest rate for amounts outstanding under the Canadian Revolver is a floating interest rate based upon either the Canadian Prime Rate, or the lender’s Bankers’ Acceptance Rate. Once the applicable rate is determined, a margin of 0.50% to 1.75%, as determined by our consolidated leverage ratio, is added to the applicable rate. The Canadian Revolver expires on March 31, 2018.

[0001564590-16-022303:notes:53]
The principal financial covenants are consistent with those described in our Amended Credit Agreement. The Canadian Revolver contains a “material adverse effect” clause. A “material adverse effect” is defined as a material change in the operations of Powell or Powell Canada Inc. in relation to our financial condition, property, business operations, expected net cash flows, liabilities or capitalization.

[0001564590-16-022303:notes:54]
The Canadian Revolver is secured by the assets of our Canadian operations and provides for customary events of default and carries cross-default provisions with our existing debt agreements. If an event of default (as defined in the Canadian Revolver) occurs and is continuing, per the terms and subject to the conditions set forth in the Canadian Revolver, amounts outstanding under the Canadian Revolver may be accelerated and may become immediately due and payable. As of June 30, 2016, we were in compliance with all of the financial covenants of the Canadian Revolver.

[0001564590-16-022303:notes:55]
Industrial Development Revenue Bonds

[0001564590-16-022303:notes:56]
We borrowed $8.0 million in October 2001 through a loan agreement funded with proceeds from tax-exempt industrial development revenue bonds (Bonds). These Bonds were issued by the Illinois Development Finance Authority and were used for the completion of our Northlake, Illinois facility. Pursuant to the Bond issuance, a reimbursement agreement between us and a major domestic bank required an issuance by the bank of an irrevocable direct-pay letter of credit (Bond LC), as collateral, to the Bonds’ trustee to guarantee payment of the Bonds’ principal and interest when due. The Bond LC is subject to both early termination and extension provisions customary to such agreements, as well as various covenants, for which we were in compliance at June 30, 2016. While the Bonds mature in 2021, the reimbursement agreement requires annual redemptions of $0.4 million that commenced on October 25, 2002. A sinking fund is used for the redemption of the Bonds. The Bonds bear interest at a floating rate determined weekly by the Bonds’ remarketing agent, which was the underwriter for the Bonds and is an affiliate of the bank. This interest rate was 0.58% as of June 30, 2016.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001564590-16-022303:notes:57]
F. COMMITMENTS AND CONTINGENCIES

[0001564590-16-022303:notes:58]
Long-Term Debt

[0001564590-16-022303:notes:59]
See Note E herein for discussion of our long-term debt.

[0001564590-16-022303:notes:60]
Letters of Credit and Surety Bonds

[0001564590-16-022303:notes:61]
Certain customers require us to post bank letter of credit guarantees or surety bonds. These guarantees and surety bonds assure that we will perform under the terms of our contract. In the event of default, the counterparty may demand payment from the bank under a letter of credit or performance by the surety under a bond. To date, there have been no significant expenses related to either letters of credit or surety bonds for the periods reported. We were contingently liable for secured and unsecured letters of credit of $26.8 million as of June 30, 2016. We also had surety bonds totaling $233.0 million that were outstanding, with additional bonding capacity of $517.0 million available, at June 30, 2016.

[0001564590-16-022303:notes:62]
We have a $9.4 million facility agreement (Facility Agreement) between Powell (UK) Limited and a large international bank. This Facility Agreement provides Powell (UK) Limited the ability to enter into bank guarantees as well as forward exchange contracts and currency options. At June 30, 2016, we had outstanding guarantees totaling $3.0 million under this Facility Agreement and amounts available under this Facility Agreement were $6.4 million.  This facility expires in November 2016. The Facility Agreement provides for financial covenants and customary events of default, and carries cross-default provisions with our Amended Credit Agreement. If an event of default (as defined in the Facility Agreement) occurs and is continuing, per the terms and subject to the conditions set forth therein, obligations outstanding under the Facility Agreement may be accelerated and may become or be declared immediately due and payable. As of June 30, 2016, we were in compliance with all of the financial covenants of the Facility Agreement.

[0001564590-16-022303:notes:63]
Litigation

[0001564590-16-022303:notes:64]
We are involved in various legal proceedings, claims and other disputes arising from our commercial operations, projects, employees and other matters which, in general, are subject to uncertainties and in which the outcomes are not predictable. Although we can give no assurances about the resolution of pending claims, litigation or other disputes and the effect such outcomes may have on us, management believes that any ultimate liability resulting from the outcome of such proceedings, to the extent not otherwise provided or covered by insurance, will not have a material adverse effect on our consolidated financial position or results of operations or liquidity.

[0001564590-16-022303:notes:65]
Liquidated Damages

[0001564590-16-022303:notes:66]
Certain of our customer contracts have schedule and performance obligation clauses that, if we fail to meet them, could require us to pay liquidated damages.  Each individual contract defines the conditions under which the customer may make a claim against us.  As of June 30, 2016, our exposure to possible liquidated damages was $7.4 million, of which approximately $1.7 million is estimated to be probable.  Based on our actual or projected failure to meet these various contractual commitments, $1.7 million has been recorded as a reduction to revenue.  We will attempt to obtain change orders or contract extensions that may resolve the potential for any unaccrued liquidated damage.  Should we fail to achieve relief on some or all of these contractual obligations, we could be required to pay additional liquidated damages, which could negatively impact our future operating results.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001564590-16-022303:notes:67]
[same as prior period, unchanged from 0001564590-16-017619:notes:69]

[0001564590-16-022303:notes:68]
[same as prior period, unchanged from 0001564590-16-017619:notes:70]

[0001564590-16-022303:notes:69]
[same as prior period, unchanged from 0001564590-16-017619:notes:71]

[0001564590-16-022303:notes:70]
We issue restricted stock units (RSUs) to certain officers and key employees of the Company.  The fair value of the RSUs is based on the closing price of our common stock as reported on the NASDAQ Global Market on the grant dates. These grants vest over a three-year period from their date of issuance.  In February 2016, the Board of Directors voted to modify the RSU awards.  The modification provides that sixty percent of the grant is time-based and vests over a three-year period on each anniversary of the grant date, based on continued employment.  The remaining forty percent of the grant will be earned based on the three-year earnings performance of the Company following the grant date.  At June 30, 2016, there were 142,688 RSUs outstanding. The RSUs do not have voting rights but receive dividend equivalents upon vesting; additionally, the shares of common stock underlying the RSUs are not considered issued and outstanding until vested and common stock is issued.

[0001564590-16-022303:notes:71]
RSU activity (number of shares) for the nine months ending June 30, 2016 is summarized below:

[0001564590-16-022303:notes:72]
|  | Number of |  |  | Weighted |  |
|  | Restricted |  |  | Average |  |
|  | Stock |  |  | Fair Value |  |
|  | Units |  |  | Per Share |  |
| Outstanding at September 30, 2015 |  | 133,506 |  |  | $ | 50.26 |  |
| Granted |  | 136,800 |  |  |  | 29.80 |  |
| Vested(1) |  | (116,568 | ) |  |  | 33.10 |  |
| Forfeited/cancelled |  | (11,050 | ) |  |  | 30.27 |  |
| Outstanding at June 30, 2016 |  | 142,688 |  |  | $ | 46.22 |  |

[0001564590-16-022303:notes:73]
[same as prior period, unchanged from 0001564590-16-017619:notes:75]

[0001564590-16-022303:notes:74]
During the nine months ended June 30, 2016 and 2015, we recorded compensation expense of $3.7 million and $1.3 million, respectively, related to the RSUs.  The increase in compensation expense recorded in the nine months ended June 30, 2016, was primarily due to the early vesting of shares associated with executive separation costs, see Note J.

[0001564590-16-022303:notes:75]
[same as prior period, unchanged from 0001564590-16-017619:notes:77]

[0001564590-16-022303:notes:76]
Restricted stock grants vest equally over their respective vesting period on each anniversary of the grant date and compensation expense is recognized over their respective vesting periods based on the price per share on the grant date.  In February 2016, 16,000 shares of restricted stock were issued to our non-employee directors at a price of $25.63 per share under the 2014 Director Plan. In April 2016, we issued 1,000 shares of restricted stock to a non-employee director at a price of $29.38 per share. The annual restricted stock grants vest 50% per year over a two-year period on each anniversary of the grant date.

[0001564590-16-022303:notes:77]
During the nine months ended June 30, 2016 and 2015, we recorded compensation expense of $0.6 million and $1.0 million, respectively, related to restricted stock grants.


## us-gaap:FairValueDisclosuresTextBlock

[0001564590-16-022303:notes:78]
[same as prior period, unchanged from 0001564590-16-017619:notes:80]

[0001564590-16-022303:notes:79]
[same as prior period, unchanged from 0001564590-16-017619:notes:81]

[0001564590-16-022303:notes:80]
[same as prior period, unchanged from 0001564590-16-017619:notes:82]

[0001564590-16-022303:notes:81]
[same as prior period, unchanged from 0001564590-16-017619:notes:83]

[0001564590-16-022303:notes:82]
[same as prior period, unchanged from 0001564590-16-017619:notes:84]

[0001564590-16-022303:notes:83]
[same as prior period, unchanged from 0001564590-16-017619:notes:85]

[0001564590-16-022303:notes:84]
The following table summarizes the fair value of our assets and liabilities that were accounted for at fair value on a recurring basis as of June 30, 2016 (in thousands):

[0001564590-16-022303:notes:85]
|  | Fair Value Measurements at June 30, 2016 |  |
|  | Quoted Prices in |  |  | Significant Other |  |  | Significant |  |  |  |  |  |
|  | Active Markets for |  |  | Observable |  |  | Unobservable |  |  | Fair Value at |  |
|  | Identical Assets |  |  | Inputs |  |  | Inputs |  |  | March 31, |  |
|  | (Level 1) |  |  | (Level 2) |  |  | (Level 3) |  |  | 2016 |  |
| Assets: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cash equivalents | $ | 335 |  |  | $ | — |  |  | $ | — |  |  | $ | 335 |  |
| Deferred compensation |  | 1,609 |  |  |  | 3,972 |  |  |  | — |  |  |  | 5,581 |  |
| Liabilities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Deferred compensation |  | — |  |  |  | 5,154 |  |  |  | — |  |  |  | 5,154 |  |

[0001564590-16-022303:notes:86]
[same as prior period, unchanged from 0001564590-16-017619:notes:88]

[0001564590-16-022303:notes:87]
[same as prior period, unchanged from 0001564590-16-017619:notes:89]

[0001564590-16-022303:notes:88]
[same as prior period, unchanged from 0001564590-16-017619:notes:90]

[0001564590-16-022303:notes:89]
[same as prior period, unchanged from 0001564590-16-017619:notes:91]

[0001564590-16-022303:notes:90]
[same as prior period, unchanged from 0001564590-16-017619:notes:92]

[0001564590-16-022303:notes:91]
[same as prior period, unchanged from 0001564590-16-017619:notes:93]

[0001564590-16-022303:notes:92]
Industrial Development Revenue Bond – The fair value of our long-term debt depends primarily on the coupon rate of our industrial development revenue bonds.  The carrying value of our long-term debt at June 30, 2016, approximates fair value based on the current coupon rate of the bonds, which is reset weekly, and is classified as a Level 2 input in the fair value measurement hierarchy as there is an active market for the trading of these industrial development revenue bonds.

[0001564590-16-022303:notes:93]
There were no transfers between levels within the fair value measurement hierarchy during the three months ended June 30, 2016.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001564590-16-022303:notes:94]
[same as prior period, unchanged from 0001564590-16-017619:notes:96]

[0001564590-16-022303:notes:95]
[same as prior period, unchanged from 0001564590-16-017619:notes:97]

[0001564590-16-022303:notes:96]
|  | Three months ended June 30, |  |  | Nine months ended June 30, |  |
|  | 2016 |  |  | 2015 |  |  | 2016 |  |  | 2015 |  |
| Income before income taxes | $ | 6,058 |  |  | $ | 12,234 |  |  | $ | 10,846 |  |  | $ | 13,700 |  |
| Income tax provision |  | 1,164 |  |  |  | 5,185 |  |  |  | 844 |  |  |  | 10,573 |  |
| Net income | $ | 4,894 |  |  | $ | 7,049 |  |  | $ | 10,002 |  |  | $ | 3,127 |  |
| Effective tax rate |  | 19 | % |  |  | 42 | % |  |  | 8 | % |  |  | 77 | % |

[0001564590-16-022303:notes:97]
|  | Nine months ended June 30, |  |
|  | 2016 |  |  | 2015 |  |
| Statutory rate |  | 35 | % |  |  | 35 | % |
| Foreign valuation allowance |  | (11 | ) |  |  | 76 |  |
| Research and development credit |  | (12 | ) |  |  | (34 | ) |
| State income taxes, net of federal benefit |  | 1 |  |  |  | 2 |  |
| Rate differential and other |  | (5 | ) |  |  | (2 | ) |
| Effective tax rate |  | 8 | % |  |  | 77 | % |

[0001564590-16-022303:notes:98]
We recorded an income tax provision of $0.8 million for the nine months ended June 30, 2016, compared to an income tax provision of $10.6 million for the nine months ended June 30, 2015.  The effective tax rate for the nine months ended June 30, 2016 was 8% compared to an effective tax rate of 77% for the nine months ended June 30, 2015.  The effective tax rate for Fiscal 2016 was favorably impacted by the mix of income from our Canadian operations and the utilization of net operating loss carryforwards in Canada that have been fully reserved with a valuation allowance.  Additionally, the effective tax rate for the nine months ended June 30, 2016 was favorably impacted by a $0.8 million discrete item recorded in the first quarter of Fiscal 2016 related to the retroactive reinstatement of the Research and Development Tax Credit (R&D Tax Credit) for the previously expired period from January 1, 2015 to September 30, 2015.  On December 18, 2015, the “Protecting Americans from Tax Hikes Act of 2015” was enacted which retroactively reinstated and made permanent the R&D Tax Credit.

[0001564590-16-022303:notes:99]
In the first nine months of Fiscal 2015, our effective tax rate increased due to a $9.0 million valuation allowance recorded against our Canadian deferred tax assets during the second quarter of Fiscal 2015.  Due to the historical Canadian losses, and the losses that we projected at the time of determination, we were required under the more-likely-than-not accounting standard to record a valuation allowance against the Canadian net deferred tax assets because we anticipated that we may not be able to realize the benefits of the net operating loss carryforwards and other deductible differences.   This was partially offset by the release of a $4.1 million FIN 48 reserve related to the R&D Tax Credit upon closing an IRS audit. We recorded a $0.6 million discrete item for the nine months ended June 30, 2015 that was also related to the retroactive reinstatement of the R&D Tax Credit referred to above.


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0001564590-16-022303:notes:100]
[same as prior period, unchanged from 0001564590-16-017619:notes:102]

[0001564590-16-022303:notes:101]
We have taken various actions during Fiscal 2016 in response to challenging conditions primarily in the oil and gas markets.  In the third quarter of Fiscal 2016, we incurred approximately $0.4 million of separation costs as we continued to align our workforce with future production requirements. Additionally in the third quarter of Fiscal 2016, we incurred approximately $0.3 million of restructuring costs related to a leased Canadian facility that we exited in the third quarter of Fiscal 2015.

[0001564590-16-022303:notes:102]
In the third quarter of Fiscal 2015, we incurred $1.4 million of restructuring and separation costs.  Of this, $0.8 million were restructuring costs related to the termination of a Canadian facility lease and the write-off of associated leasehold improvements.  The remaining $0.6 million were separation costs due to additional headcount reductions in Canada and certain U.S. operations as we responded to market conditions at the time and aligned our workforce with future production requirements.

[0001564590-16-022303:notes:103]
For the nine months ended June 30, 2016, we incurred approximately $7.7 million in restructuring and separation costs, of which $3.8 million were separation costs related to the departure of our former Chief Executive Officer in December 2015.  Of the $7.7 million in restructuring and separation costs recorded in Fiscal 2016, $5.3 million has been paid and the remaining $2.4 million will be paid over the next fifteen months.

[0001564590-16-022303:notes:104]
For the nine months ended June 30, 2015, we incurred $2.7 million in restructuring and separation costs. Of this, $1.9 million was from separation costs, and the remaining $0.8 million resulted from the termination of a Canadian facility lease and the write-off of associated leasehold improvements.
