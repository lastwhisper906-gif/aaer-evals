# POWL 8-K — 0000080420-22-000030 filed 2022-08-02

## item codes, every 8-K on or before 2022-08-03

- 2022-08-02 0000080420-22-000030 — 2.02, 8.01, 9.01
- 2022-05-13 0000080420-22-000024 — 5.02, 9.01
- 2022-05-03 0000080420-22-000016 — 2.02, 9.01
- 2022-05-03 0000080420-22-000015 — 8.01, 9.01
- 2022-02-17 0000080420-22-000010 — 5.07
- 2022-02-08 0000080420-22-000005 — 2.02, 9.01
- 2022-02-01 0000080420-22-000002 — 8.01, 9.01
- 2021-12-07 0000080420-21-000043 — 2.02, 9.01
- 2021-08-03 0000080420-21-000036 — 2.02, 8.01, 9.01
- 2021-05-04 0000080420-21-000026 — 2.02, 8.01, 9.01
- 2021-03-16 0001193125-21-082878 — 1.01, 2.03, 9.01
- 2021-03-05 0000080420-21-000021 — 5.02, 8.01, 9.01
- 2021-02-26 0000080420-21-000018 — 5.03
- 2021-02-18 0000080420-21-000016 — 5.07
- 2021-02-02 0000080420-21-000010 — 2.02, 8.01, 9.01
- 2020-12-08 0000080420-20-000032 — 2.02, 9.01
- 2020-11-12 0000080420-20-000030 — 8.01, 9.01
- 2020-08-04 0000080420-20-000024 — 2.02, 8.01, 9.01
- 2020-05-05 0000080420-20-000017 — 2.02, 8.01, 9.01
- 2020-02-21 0000080420-20-000008 — 5.07
- 2020-02-04 0000080420-20-000003 — 2.02, 8.01, 9.01
- 2019-12-04 0001193125-19-306243 — 2.02, 9.01
- 2019-11-08 0000080420-19-000032 — 8.01, 9.01
- 2019-10-03 0000080420-19-000030 — 1.01, 2.03
- 2019-09-24 0000080420-19-000028 — 8.01, 9.01
- 2019-08-06 0000080420-19-000022 — 2.02, 8.01, 9.01
- 2019-05-08 0000080420-19-000017 — 5.02, 9.01
- 2019-05-07 0000080420-19-000011 — 2.02, 8.01, 9.01
- 2019-02-22 0001193125-19-048366 — 5.07
- 2019-02-05 0000080420-19-000003 — 2.02, 8.01
- 2018-12-21 0000080420-18-000038 — 5.02, 9.01
- 2018-12-12 0000080420-18-000031 — 2.02
- 2018-11-05 0000080420-18-000029 — 8.01, 9.01
- 2018-11-01 0000080420-18-000027 — 5.02, 8.01, 9.01
- 2018-10-01 0000080420-18-000024 — 5.02
- 2018-08-07 0000080420-18-000020 — 2.02, 8.01
- 2018-05-15 0000080420-18-000016 — 5.02, 8.01
- 2018-05-09 0000080420-18-000011 — 2.02, 8.01
- 2018-02-22 0000080420-18-000009 — 5.07
- 2018-02-06 0000080420-18-000003 — 2.02, 8.01
- 2017-12-27 0001193125-17-379928 — 5.02
- 2017-12-05 0000080420-17-000028 — 2.02, 9.01
- 2017-11-08 0000080420-17-000024 — 8.01, 9.01
- 2017-11-03 0000080420-17-000022 — 5.02
- 2017-08-09 0000080420-17-000017 — 2.02, 8.01
- 2017-06-30 0000080420-17-000014 — 1.01, 9.01
- 2017-05-03 0000080420-17-000006 — 2.02, 8.01, 9.01
- 2017-02-23 0000080420-17-000004 — 5.07
- 2017-02-08 0001628280-17-000965 — 2.02 — amendment of 0001628280-17-000949
- 2017-02-07 0001628280-17-000949 — 2.01, 8.01, 9.01
- 2016-12-07 0001193125-16-787354 — 2.02, 9.01
- 2016-11-01 0001193125-16-755475 — 8.01, 9.01
- 2016-09-30 0001193125-16-726999 — 5.02, 8.01, 9.01
- 2016-08-03 0001193125-16-669308 — 2.02, 8.01, 9.01
- 2016-05-04 0001193125-16-576528 — 2.02, 8.01, 9.01
- 2016-02-25 0001193125-16-477896 — 5.07
- 2016-02-03 0001193125-16-449052 — 2.02, 8.01, 9.01
- 2015-12-31 0001193125-15-418363 — 5.02, 7.01, 9.01
- 2015-12-02 0001193125-15-393109 — 2.02, 9.01
- 2015-11-05 0001193125-15-368085 — 8.01, 9.01
- 2015-09-25 0001193125-15-329031 — 5.02
- 2015-08-05 0001193125-15-277912 — 2.02, 8.01, 9.01
- 2015-05-06 0001193125-15-174291 — 2.02, 8.01, 9.01
- 2015-03-06 0001193125-15-081070 — 5.02
- 2015-03-02 0001193125-15-072946 — 5.07
- 2015-02-03 0001193125-15-031772 — 2.02, 8.01, 9.01
- 2014-12-18 0001193125-14-446513 — 8.01, 9.01
- 2014-12-03 0001193125-14-431745 — 2.02, 9.01
- 2014-11-05 0001193125-14-397955 — 8.01, 9.01
- 2014-09-26 0001193125-14-353741 — 7.01, 9.01
- 2014-08-05 0001193125-14-296001 — 2.02, 8.01, 9.01
- 2014-05-07 0001193125-14-187496 — 2.02, 8.01, 9.01
- 2014-03-03 0001193125-14-079843 — 5.02, 5.07
- 2014-02-05 0001193125-14-036633 — 2.02, 8.01, 9.01
- 2014-01-17 0001193125-14-014351 — 1.01, 8.01, 9.01
- 2014-01-06 0001193125-14-002795 — 1.01, 2.03
- 2013-12-06 0001564590-13-001411 — 2.02, 9.01
- 2013-12-05 0001564590-13-001406 — 5.02, 8.01, 9.01
- 2013-11-07 0001193125-13-432950 — 8.01, 9.01
- 2013-08-07 0001193125-13-324337 — 2.02, 9.01
- 2013-05-08 0001193125-13-206800 — 2.02, 9.01
- 2013-02-22 0001193125-13-070971 — 5.02, 5.07
- 2013-02-06 0001193125-13-040556 — 2.02, 9.01
- 2012-12-18 0001193125-12-506417 — 5.02, 9.01
- 2012-12-05 0001193125-12-491749 — 2.02, 9.01
- 2012-10-12 0001193125-12-421889 — 3.03, 5.02, 5.03, 9.01
- 2012-08-09 0001193125-12-344617 — 5.02, 8.01, 9.01
- 2012-08-08 0001193125-12-343630 — 2.02, 9.01
- 2012-05-09 0001193125-12-221356 — 2.02, 9.01
- 2012-02-08 0001193125-12-046560 — 2.02, 9.01
- 2011-12-08 0001193125-11-334810 — 2.02, 9.01
- 2011-11-08 0000950123-11-096524 — 2.02, 2.06, 4.02, 9.01
- 2011-10-14 0000950123-11-090124 — 5.02
- 2011-10-06 0000950123-11-088969 — 5.02
- 2011-09-19 0000950123-11-085224 — 5.02, 9.01
- 2011-09-15 0000950123-11-084806 — 5.02, 9.01
- 2011-08-04 0000950123-11-072788 — 2.02, 9.01
- 2011-07-22 0000950123-11-067402 — 5.07
- 2011-05-24 0000950123-11-053550 — 1.01, 2.03, 9.01
- 2011-05-04 0000950123-11-044561 — 2.02, 9.01
- 2011-02-02 0000950123-11-008188 — 2.02, 9.01
- 2010-12-08 0000950123-10-111987 — 2.02, 9.01
- 2010-08-05 0000950123-10-073114 — 2.02, 9.01
- 2010-05-18 0000950123-10-050900 — 5.02
- 2010-05-05 0000950123-10-044499 — 2.02, 9.01
- 2010-02-03 0000950123-10-008278 — 2.02, 9.01
- 2009-12-21 0000950123-09-072269 — 1.01, 2.01, 2.03, 8.01, 9.01
- 2009-12-09 0000950123-09-069525 — 2.02, 9.01
- 2009-10-27 0000950123-09-053501 — 1.01, 8.01, 9.01
- 2009-08-04 0000950123-09-029476 — 2.02, 9.01
- 2009-05-06 0000950129-09-001498 — 2.02, 9.01
- 2009-03-05 0000950129-09-000749 — 1.01, 9.01
- 2009-02-10 0000950129-09-000349 — 2.02, 9.01
- 2008-12-10 0000950134-08-021934 — 2.02, 9.01
- 2008-08-06 0000950129-08-004267 — 2.02, 9.01
- 2008-07-24 0000950129-08-004063 — 1.01, 5.02, 8.01, 9.01
- 2008-06-16 0000950129-08-003500 — 9.01 — amendment of 0000950134-06-015374
- 2008-06-05 0000950129-08-003378 — 5.02, 9.01
- 2008-05-08 0000950129-08-002843 — 2.02, 9.01
- 2008-02-06 0000950129-08-000533 — 2.02, 9.01
- 2007-12-19 0000950129-07-006277 — 1.01, 2.03, 9.01
- 2007-12-06 0000950129-07-006003 — 2.02, 9.01
- 2007-08-21 0000950129-07-004181 — 2.02, 9.01
- 2007-05-31 0000950129-07-002810 — 2.02, 9.01
- 2007-05-21 0000950129-07-002668 — 2.02, 3.01, 4.02, 9.01
- 2007-04-16 0000950129-07-002002 — 2.02, 4.02, 9.01
- 2007-03-01 0000950129-07-001104 — 5.02, 8.01, 9.01
- 2007-02-08 0000950129-07-000451 — 2.02, 9.01
- 2006-12-08 0000950129-06-010041 — 2.02, 9.01
- 2006-09-08 0000950129-06-008379 — 2.02, 9.01
- 2006-08-09 0000950134-06-015374 — 1.01, 2.01, 8.01, 9.01
- 2006-06-08 0000950129-06-006127 — 2.02, 9.01
- 2006-03-09 0000950129-06-002455 — 2.02, 9.01
- 2005-12-16 0000950129-05-012031 — 2.02, 5.03, 9.01
- 2005-09-13 0000950129-05-009181 — 2.01, 9.01 — amendment of 0000950129-05-006889
- 2005-09-12 0000950129-05-009151 — 2.02, 9.01
- 2005-07-06 0000950129-05-006889 — 1.01, 1.02, 2.01, 2.03, 9.01
- 2005-06-10 0000950129-05-006128 — 2.02, 9.01
- 2005-04-20 0000080420-05-000031 — 5.02
- 2005-03-11 0000080420-05-000024 — 9.01
- 2005-02-25 0000080420-05-000018 — 7.01, 9.01
- 2005-01-21 0000080420-05-000009 — 7.01, 9.01
- 2004-12-17 0000080420-04-000049 — 2.02, 9.01
- 2004-11-01 0000080420-04-000045 — 8.01, 9.01
- 2004-10-08 0001169232-04-005133 — 2.05
- 2004-09-14 0000080420-04-000037 — 5.02
- 2004-09-02 0000080420-04-000030 — 2.02, 9.01
- 2004-06-08 0000080420-04-000021 — 7
- 2004-05-13 0000080420-04-000019 — 4
- 2004-02-27 0000080420-04-000013 — 7
- 2003-12-16 0000950129-03-006136 — 12, 7
- 2003-08-29 0000950129-03-004531 — 12, 7
- 2003-06-03 0000950129-03-003035 — 7, 9
- 2003-05-15 0000950129-03-002812 — 7, 9
- 2002-05-29 0000950129-02-002795 — 4
- 2000-12-21 0000950129-00-006093 — 5, 7
- 1998-09-04 0000950129-98-003802 — 5
- 1996-08-09 0000950129-96-001705 — 2, 7

## late-filing notifications on or before 2022-08-03

- 2007-05-11 0000950129-07-002494 — NT 10-Q, for the period ended 2007-03-31
- 2005-01-18 0000080420-05-000004 — NT 10-K, for the period ended 2004-10-31

## item 2.02 — earnings release, exhibit 99.1

[0000080420-22-000030:8k_2_02:1]
EX-99.1
2
ex991-q322earningsrelease.htm
EX-99.1

[0000080420-22-000030:8k_2_02:2]
Document

[0000080420-22-000030:8k_2_02:3]
Exhibit 99.1

[0000080420-22-000030:8k_2_02:4]
PRESS RELEASE

[0000080420-22-000030:8k_2_02:5]
FOR IMMEDIATE RELEASE

[0000080420-22-000030:8k_2_02:6]
Contacts:    Michael W. Metcalf, CFO

[0000080420-22-000030:8k_2_02:7]
Powell Industries, Inc.

[0000080420-22-000030:8k_2_02:8]
713-947-4422

[0000080420-22-000030:8k_2_02:9]
Robert Winters or Ryan Coleman

[0000080420-22-000030:8k_2_02:10]
Alpha IR Group

[0000080420-22-000030:8k_2_02:11]
POWL@alpha-ir.com

[0000080420-22-000030:8k_2_02:12]
312-445-2870

[0000080420-22-000030:8k_2_02:13]
POWELL INDUSTRIES ANNOUNCES FISCAL 2022 THIRD QUARTER RESULTS

[0000080420-22-000030:8k_2_02:14]
HOUSTON — August 2, 2022 — Powell Industries, Inc. (NASDAQ: POWL), a leading supplier of custom-engineered solutions for the management, control and distribution of electrical energy, today announced results for the fiscal 2022 third quarter ended June 30, 2022.

[0000080420-22-000030:8k_2_02:15]
Fiscal Third Quarter Key Highlights:

[0000080420-22-000030:8k_2_02:16]
•Revenues totaled $135 million;

[0000080420-22-000030:8k_2_02:17]
•Net Income was $9 million, or $0.76 per diluted share including;

[0000080420-22-000030:8k_2_02:18]
–$1.6 million or $0.14 per diluted share gain on the sale of a non-core division, and

[0000080420-22-000030:8k_2_02:19]
–$5.9 million or $0.49 per diluted share from a non-recurring tax benefit;

[0000080420-22-000030:8k_2_02:20]
•New orders totaled $202 million;

[0000080420-22-000030:8k_2_02:21]
•Backlog as of June 30, 2022, totaled $503 million;

[0000080420-22-000030:8k_2_02:22]
•Cash and short-term investments as of June 30, 2022, totaled $99 million.

[0000080420-22-000030:8k_2_02:23]
Brett A. Cope, Powell’s Chairman and Chief Executive Officer, stated, “Powell delivered a solid fiscal third quarter as we continue to recover from challenges brought on by the pandemic including the on-going disruptions to the global supply chain.  Our operating divisions across the company delivered solid execution as we continue to progress productivity improvements across all elements of the business including our engineering, manufacturing and strategic sourcing teams.  The $202 million of new orders represents the highest quarterly total of new orders in

[0000080420-22-000030:8k_2_02:24]
over two years and more importantly, marks the fifth consecutive quarter of increasing gross new order activity. It is also notable that there were no single, large project orders in the quarter as market activity was much more broad and balanced across most of our end markets.”

[0000080420-22-000030:8k_2_02:25]
Revenues for the third quarter totaled $135.5 million compared to $127.9 million in the second quarter and compared to $115.8 million in the third quarter in the prior year.

[0000080420-22-000030:8k_2_02:26]
New orders placed in the third quarter totaled $202 million compared to $151 million in the second quarter and compared to $103 million of new orders in the third quarter of the prior fiscal year.

[0000080420-22-000030:8k_2_02:27]
Backlog as of June 30, 2022, totaled $503 million which represents sequential growth of 14% compared to $440 million as of March 31, 2022, and compares to $426 million as of June 30, 2021.

[0000080420-22-000030:8k_2_02:28]
Net income in the fiscal third quarter was $9.1 million, or $0.76 per diluted share, compared to a net loss of $1.2 million, or $0.10 per diluted share, in the fiscal second quarter and compared to a net loss of $2.0 million, or $0.17 per diluted share, in the fiscal third quarter of the prior year.

[0000080420-22-000030:8k_2_02:29]
During the third fiscal quarter, the business recognized income resulting from two non-operational events.  First, a $1.6 million after tax gain was realized through the divestiture of a non-core, industrial valve repair and servicing division within the Powell Canada entity.  This generated $4 million of cash and added $0.14 per diluted share.  Secondly, due to the sustained, positive earnings generated out of Powell Canada, the valuation allowance that was previously established against the entity’s deferred tax assets was reversed.  The reversal of this allowance results in a non-cash, increase in Net Income of $5.9 million or $0.49 per diluted share.

[0000080420-22-000030:8k_2_02:30]
Cope added, “We remain pleased with the steady and consistent recovery of our Industrial end markets as well as the improvements that our strategic efforts, both to diversify our business and broaden our Services offering, are yielding. Across the industrial landscape, our Oil & Gas and Petrochemical end markets continue to show signs of a slow and steady recovery, supported by the favorable fundamentals of LNG, gas pipeline and gas-to-chemical projects. We continue to experience robust activity within our Utility and Commercial end markets. As a

[0000080420-22-000030:8k_2_02:31]
result, we are entering our fiscal fourth quarter on very strong financial footing and with a large, healthy backlog of project orders.”

[0000080420-22-000030:8k_2_02:32]
OUTLOOK

[0000080420-22-000030:8k_2_02:33]
Commenting on the Company's outlook, Michael Metcalf, Powell’s Chief Financial Officer said, “Our book-to-bill ratio of 1.5x in the third quarter demonstrates the ongoing recovery across our core end markets and we are optimistic that these conditions will persist in the coming quarters. While we are experiencing a gradual and consistent recovery across our industrial base of customers, the positive momentum that we’ve seen in our Utility and Commercial markets is very encouraging, as evidenced by our strong backlog, closing the third quarter at $503 million. Although the macro inflationary pressure and component availability challenges still persist across the supply chain, we continue to make steady progress offsetting these headwinds through pricing actions, efficiency improvements and strong supplier partnerships.  Looking forward, we continue to anticipate gradually improving profitability as pricing, factory efficiencies and cost controls continue to gain traction, further enabling us to execute our strong and growing order book.”

[0000080420-22-000030:8k_2_02:34]
CONFERENCE CALL

[0000080420-22-000030:8k_2_02:35]
Powell Industries has scheduled a conference call for Wednesday, August 3, 2022, at 11:00 a.m. Eastern time.   To participate in the conference call, dial 1-833-953-2431 (domestic) or 1-412-317-5760 (international) at least 10 minutes before the call begins and ask for the Powell Industries conference call.  A telephonic replay of the conference call will be available through August 10, 2022 and may be accessed by calling 1-877-344-7529 (domestic) or 1-412-317-0088 (international) and using passcode 7590577#.

[0000080420-22-000030:8k_2_02:36]
Investors, analysts and the general public will also have the opportunity to listen to the conference call over the Internet by visiting powellind.com. To listen to the live call on the web, please visit the website at least 15 minutes before the call begins to register, download and install any necessary audio software.  For those who cannot listen to the live webcast, an archive will be available shortly after the call and will remain available for approximately 90 days at powellind.com.

[0000080420-22-000030:8k_2_02:37]
3

[0000080420-22-000030:8k_2_02:38]
Powell Industries, Inc., headquartered in Houston, designs, manufactures and services custom-engineered equipment and systems for the distribution, control and monitoring of electrical energy.  Powell markets include large industrial customers such as utilities, oil and gas producers, refineries, liquefied natural gas facilities, petrochemical plants, pulp and paper producers, mining operations and commuter railways.   For more information, please visit powellind.com.

[0000080420-22-000030:8k_2_02:39]
POWELL INDUSTRIES, INC. & SUBSIDIARIES

[0000080420-22-000030:8k_2_02:40]
CONDENSED CONSOLIDATED STATEMENT OF OPERATIONS

[0000080420-22-000030:8k_2_02:41]
|  | Three Months EndedJune 30, |  | Nine Months EndedJune 30, |
|  | 2022 |  | 2021 |  | 2022 |  | 2021 |
| (In thousands, except per share data) |  |  |  |  |  |  |  |
|  | (Unaudited) |
| Revenues | $ | 135,483 |  |  | $ | 115,813 |  |  | $ | 369,907 |  |  | $ | 341,105 |  |
| Cost of goods sold | 116,424 |  |  | 98,646 |  |  | 318,329 |  |  | 288,513 |  |
| Gross profit | 19,059 |  | 17,167 |  | 51,578 |  | 52,592 |
| Selling, general and administrative expenses | 16,404 |  |  | 16,710 |  |  | 49,374 |  |  | 50,259 |  |
| Research and development expenses | 1,806 |  |  | 1,772 |  |  | 5,342 |  |  | 5,046 |  |
| Amortization of intangible assets | — |  |  | 44 |  |  | — |  |  | 132 |  |
| Operating income (loss) | 849 |  |  | (1,359) |  |  | (3,138) |  |  | (2,845) |  |
| Other income | (2,006) |  |  | — |  |  | (2,285) |  |  | — |  |
| Interest expense (income) | (63) |  |  | (21) |  |  | (79) |  |  | (78) |  |
| Income (loss) before income taxes | 2,918 |  |  | (1,338) |  |  | (774) |  |  | (2,767) |  |
| Income tax provision (benefit) | (6,143) |  |  | 703 |  |  | (5,772) |  |  | (138) |  |
| Net income (loss) | $ | 9,061 |  |  | $ | (2,041) |  |  | $ | 4,998 |  |  | $ | (2,629) |  |
| Income (loss) per share: |  |  |  |  |  |  |  |
| Basic | $ | 0.77 |  |  | $ | (0.17) |  |  | $ | 0.42 |  |  | $ | (0.22) |  |
| Diluted | $ | 0.76 |  |  | $ | (0.17) |  |  | $ | 0.42 |  |  | $ | (0.22) |  |
| Weighted average shares: |  |  |  |  |  |  |  |
| Basic | 11,810 |  |  | 11,720 |  |  | 11,792 |  |  | 11,700 |  |
| Diluted | 11,901 |  |  | 11,720 |  |  | 11,877 |  |  | 11,700 |  |
| SELECTED FINANCIAL DATA: |  |  |  |  |  |  |  |
| Depreciation and Amortization | $ | 2,375 |  |  | $ | 2,610 |  |  | $ | 7,206 |  |  | $ | 7,899 |  |
| Capital Expenditures | $ | 649 |  |  | $ | 857 |  |  | $ | 1,765 |  |  | $ | 2,480 |  |
| Dividends Paid | $ | 3,064 |  |  | $ | 3,039 |  |  | $ | 9,170 |  |  | $ | 9,102 |  |

[0000080420-22-000030:8k_2_02:42]
5

[0000080420-22-000030:8k_2_02:43]
POWELL INDUSTRIES, INC. & SUBSIDIARIES

[0000080420-22-000030:8k_2_02:44]
CONDENSED CONSOLIDATED BALANCE SHEETS

[0000080420-22-000030:8k_2_02:45]
|  | June 30, 2022 |  | September 30, 2021 |
| (In thousands) | (Unaudited) |
| Assets: |  |  |  |
| Cash, cash equivalents and short-term investments | $ | 98,512 |  |  | $ | 133,981 |  |
| Other current assets | 226,260 |  |  | 168,480 |  |
| Property, plant and equipment, net | 102,023 |  |  | 109,457 |  |
| Long-term assets | 25,009 |  |  | 24,274 |  |
| Total assets | $ | 451,804 |  |  | $ | 436,192 |  |
| Liabilities and equity: |  |  |  |
| Current liabilities | $ | 144,350 |  |  | $ | 121,156 |  |
| Deferred and other long-term liabilities | 11,506 |  | 13,813 |
| Stockholders’ equity | 295,948 |  |  | 301,223 |  |
| Total liabilities and stockholders’ equity | $ | 451,804 |  |  | $ | 436,192 |  |
| SELECTED FINANCIAL DATA: |  |  |  |
| Working capital | $ | 180,422 |  |  | $ | 181,305 |  |

[0000080420-22-000030:8k_2_02:46]
6
