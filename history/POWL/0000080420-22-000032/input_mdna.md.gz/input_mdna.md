# POWL MD&A — 0000080420-22-000032


## mdna

[0000080420-22-000032:mdna:1]
[same as prior period, unchanged from 0000080420-22-000019:mdna:1]

[0000080420-22-000032:mdna:2]
[same as prior period, unchanged from 0000080420-22-000019:mdna:2]

[0000080420-22-000032:mdna:3]
[same as prior period, unchanged from 0000080420-22-000019:mdna:3]

[0000080420-22-000032:mdna:4]
[same as prior period, unchanged from 0000080420-22-000019:mdna:4]

[0000080420-22-000032:mdna:5]
[same as prior period, unchanged from 0000080420-22-000019:mdna:5]

[0000080420-22-000032:mdna:6]
[same as prior period, unchanged from 0000080420-22-000019:mdna:6]

[0000080420-22-000032:mdna:7]
Historically, the combination of a growing global economy, abundant sources of favorably priced natural gas feedstock, and an energy industry focus on transition to natural gas and cleaner-burning fuels drove an increase in capital investment opportunities, specifically across the oil, gas and petrochemical sectors. Some of these opportunities were for natural gas related projects targeting global demand for cleaner-burning fuels. Additionally, projects within the domestic petrochemical sector benefited from the low feedstock prices of natural gas. Specific to LNG, the business was awarded a substantial contract in the second quarter of Fiscal 2020 that will support the integrated electrical distribution requirements for a large domestic industrial complex and should be substantially completed in Fiscal 2022. We began to experience reduced commercial activity in Fiscal 2020 driven in large part by the uncertainties across our industrial end markets in the U.S. resulting from the COVID-19 pandemic.

[0000080420-22-000032:mdna:8]
[same as prior period, unchanged from 0000080420-22-000019:mdna:8]

[0000080420-22-000032:mdna:9]
Various factors resulting in global economic uncertainty have negatively impacted our results over the past two years. Uncertainty and demand disruptions have resulted in considerable volatility across commodity markets. Although global oil prices have rebounded, our industrial end markets have responded with modest increases in capital expenditures. Additionally, we continue to experience supply chain disruptions driven predominately by availability and cost volatility across our raw materials, components and labor force. All of these factors have contributed to the lower margins realized in Fiscal 2022. As we address disruptions and increased costs, we continue to work with our suppliers of key components and commodities to ensure that we are able to meet our customer commitments. Additionally, we have adjusted our pricing models in response to the increased cost environment.

[0000080420-22-000032:mdna:10]
In response to the lower demand across select end markets, we have taken and will continue to take various actions to reduce costs. We continue to operate at lower thresholds throughout Fiscal 2021 and the first nine months of Fiscal 2022 and will continue to consistently monitor the macro-economic conditions throughout the remainder of Fiscal 2022.

[0000080420-22-000032:mdna:11]
As discussed further under the heading "Outlook" below, it is difficult to predict the economic impact that this pandemic, as well as reduced oil and gas demand, supply chain issues, and inflationary pressures, may have on our business, results of operations and cash flows going forward.

[0000080420-22-000032:mdna:12]
[same as prior period, unchanged from 0000080420-22-000019:mdna:12]

[0000080420-22-000032:mdna:13]
Quarter Ended June 30, 2022 Compared to the Quarter Ended June 30, 2021 (Unaudited)

[0000080420-22-000032:mdna:14]
[same as prior period, unchanged from 0000080420-22-000019:mdna:14]

[0000080420-22-000032:mdna:15]
Revenues increased by 17%, or $19.7 million, to $135.5 million in the third quarter of Fiscal 2022. Domestic revenues increased by 16%, or $14.5 million, to $102.9 million in the third quarter of Fiscal 2022. Included in our domestic, oil and gas sector revenues is the large domestic industrial project awarded in Fiscal 2020, which accounted for approximately 16% of our consolidated revenues for the third quarter of Fiscal 2022 compared to 18% in the same period in the prior year. International revenues increased by 19%, or $5.2 million, to $32.6 million in the third quarter of Fiscal 2022. Our international revenues include both revenues generated from our international facilities as well as revenues from export projects generated at our domestic facilities.

[0000080420-22-000032:mdna:16]
Revenue from our core oil and gas markets (excluding petrochemical) increased by 19%, or $9.4 million, to $58.7 million in the third quarter of Fiscal 2022, while petrochemical revenue decreased by 1%, or $0.2 million, to $15.2 million in the third quarter of Fiscal 2022. Revenue from our utility markets increased by 15%, or $4.0 million, to $30.2 million, and traction market revenue decreased by 29%, or $4.0 million, to $9.8 million in the third quarter of Fiscal 2022. Revenue from all other markets combined increased by 94%, or $10.5 million, to $21.6 million in the third quarter of Fiscal 2022, primarily driven by other commercial markets.

[0000080420-22-000032:mdna:17]
Gross profit increased by 11%, or $1.9 million, to $19.1 million for the third quarter of Fiscal 2022.  Gross profit as a percentage of revenues decreased to 14% in the third quarter of Fiscal 2022, compared to 15% in the third quarter of Fiscal 2021. The decrease in gross profit as a percentage of revenues is primarily due to project execution challenges on select contracts for a new customer awarded in the prior year at one of our U.S. operations. The increased costs and scope attributable to these contracts was not transferable to the customer. As the volatility across the global supply chain continues to persist, gross profit may continue to be negatively impacted by higher material costs to the extent we are not able to pass these increases to our customers.

[0000080420-22-000032:mdna:18]
[same as prior period, unchanged from 0000080420-22-000019:mdna:18]

[0000080420-22-000032:mdna:19]
Selling, general and administrative expenses decreased by 2%, or $0.3 million, to $16.4 million in the third quarter of Fiscal 2022, primarily due to a reduction in bad debt expense and a continued focus on controlling costs. Selling, general and administrative expenses as a percentage of revenues decreased to 12% during the third quarter of Fiscal 2022 compared to 14% during the third quarter of Fiscal 2021.

[0000080420-22-000032:mdna:20]
[same as prior period, unchanged from 0000080420-22-000019:mdna:20]

[0000080420-22-000032:mdna:21]
We recorded other income of $2.0 million in the third quarter of Fiscal 2022 related to a gain on the sale of a non-core, industrial valve repair and servicing business within our Canadian operations. We did not record other income during the third quarter of Fiscal 2021.

[0000080420-22-000032:mdna:22]
[same as prior period, unchanged from 0000080420-22-000019:mdna:22]

[0000080420-22-000032:mdna:23]
We recorded an income tax benefit of $6.1 million in the third quarter of Fiscal 2022, compared to an income tax provision of $0.7 million in the third quarter of Fiscal 2021. For the three months ended June 30, 2022, the tax benefit primarily resulted from the release of the valuation allowance recorded against the Canadian net deferred tax assets in the amount of $5.9 million that was partially offset by the tax expense of $0.4 million related to the gain on the disposition of a small, non-core division of our Canadian operations. The tax provision recorded in the third quarter of Fiscal 2021 resulted from our inability to recognize a tax benefit related to losses incurred in the United Kingdom and the change in the estimated amounts of income (loss) recognized in the various tax jurisdictions.

[0000080420-22-000032:mdna:24]
Net Income/Loss

[0000080420-22-000032:mdna:25]
In the third quarter of Fiscal 2022, we recorded net income of $9.1 million, or $0.76 per diluted share, compared to a net loss of $2.0 million, or $0.17 per diluted share, in the third quarter of Fiscal 2021. This increase in net income is primarily due to the release of a Canadian valuation allowance recorded against net deferred tax assets and the gain on the sale of a non-core valve repair and servicing business within our Canadian operations during the third quarter of Fiscal 2022.

[0000080420-22-000032:mdna:26]
[same as prior period, unchanged from 0000080420-22-000019:mdna:26]

[0000080420-22-000032:mdna:27]
The order backlog at June 30, 2022 was $502.5 million, an increase of 14% from $440.0 million at March 31, 2022 and an increase from $425.5 million at June 30, 2021 as most of Powell's core end market activity increases. Bookings, net of cancellations and scope reductions, increased by 95% in the third quarter of Fiscal 2022 to $201.5 million, compared to $103.2 million in the third quarter of Fiscal 2021, primarily driven by increased activity broadly across most of Powell's core end markets.

[0000080420-22-000032:mdna:28]
Nine Months Ended June 30, 2022 Compared to the Nine Months Ended June 30, 2021 (Unaudited)

[0000080420-22-000032:mdna:29]
[same as prior period, unchanged from 0000080420-22-000019:mdna:29]

[0000080420-22-000032:mdna:30]
Revenues increased by 8%, or $28.8 million, to $369.9 million in the nine months ended June 30, 2022. Domestic revenues increased by 6% to $272.1 million in the nine months ended June 30, 2022. International revenues increased by 16.2%, or $13.7 million, to $97.8 million. Our international revenues include both revenues generated from our international facilities as well as revenues from export projects generated at our domestic facilities.

[0000080420-22-000032:mdna:31]
Revenue from our core oil and gas markets (excluding petrochemical) increased by 11%, or $15.9 million, to $155.3 million in the nine months ended June 30, 2022, while petrochemical revenue increased by 48%, or $16.5 million, to $51.3 million in the first nine months of Fiscal 2022, primarily due to increased market activity. Revenue from our utility markets decreased by 1%, or $0.7 million, to $82.1 million, and traction market revenue decreased by 26%, or $11.1 million, to $31.2 million in the nine months ended June 30, 2022. Revenue from all other markets combined increased by 20%, or $8.2 million, to $50.0 million in the nine months ended June 30, 2022, primarily driven by other commercial end markets.

[0000080420-22-000032:mdna:32]
Gross profit decreased by 2%, or $1.0 million, to $51.6 million as compared to the first nine months of Fiscal 2021. Gross profit as a percentage of revenues decreased to 14% in the first nine months of Fiscal 2022, compared to 15% in the first nine months of Fiscal 2021. The decrease in gross profit and gross profit as a percentage of revenue was driven predominately by  inflationary pressures on raw materials and components negatively impacting our operations as we were not able to pass on the increased costs to the customer for projects awarded in prior periods of lower input costs and pricing. In circumstances where select, older projects in backlog are subject to the material and labor availability, as well as cost escalation, gross profit may be negatively impacted to the extent we are not able to pass these increases to our customers.

[0000080420-22-000032:mdna:33]
[same as prior period, unchanged from 0000080420-22-000019:mdna:33]

[0000080420-22-000032:mdna:34]
Selling, general and administrative expenses decreased by 2%, or $0.9 million, to $49.4 million in the nine months ended June 30, 2022, primarily due to decreased personnel costs and a continued focus on controlling costs. Selling, general and administrative expenses as a percentage of revenues decreased to 13% during the nine months ended June 30, 2022 compared to 15% during the nine months ended June 30, 2021.

[0000080420-22-000032:mdna:35]
[same as prior period, unchanged from 0000080420-22-000019:mdna:35]

[0000080420-22-000032:mdna:36]
We recorded other income of $2.3 million in the nine months ended June 30, 2022 related to a gain on the sale of a small, non-core, industrial valve repair and servicing business within our Canadian operations as well as the sale of an excess parcel of land in the U.S. We did not record other income during the nine months ended June 30, 2021.

[0000080420-22-000032:mdna:37]
Income Tax Benefit

[0000080420-22-000032:mdna:38]
We recorded an income tax benefit of $5.8 million in the nine months ended June 30, 2022, compared to an income tax benefit of $0.1 million in the nine months ended June 30, 2021. For the nine months ended June 30, 2022, the tax benefit primarily resulted from the release of the valuation allowance recorded against the Canadian net deferred tax assets in the amount of $5.9 million that was partially offset by the tax expense of $0.4 million related to the gain on the disposition of a small, non-core division of our Canadian operations. The estimated R&D Tax Credit as well as the utilization of net operating loss carryforwards in Canada that were fully reserved with a valuation allowance provided a tax benefit for the nine months ended June 30, 2021 that was largely offset by our inability to recognize a tax benefit related to losses in the United Kingdom and the change in the estimated amounts of income (loss) recognized in various jurisdictions.

[0000080420-22-000032:mdna:39]
Net Income/Loss

[0000080420-22-000032:mdna:40]
In the nine months ended June 30, 2022, we recorded net income of $5.0 million, or $0.42 per diluted share, compared to a net loss of $2.6 million, or $0.22 per diluted share, in the nine months ended June 30, 2021. This increase in net income is primarily due to the release of a Canadian valuation allowance recorded against net deferred tax assets and the gain on the sale of a non-core valve repair and servicing business within our Canadian operations during the third quarter of Fiscal 2022.

[0000080420-22-000032:mdna:41]
[same as prior period, unchanged from 0000080420-22-000019:mdna:41]

[0000080420-22-000032:mdna:42]
The order backlog at June 30, 2022 was $502.5 million, an increase of 21% from $414.9 million at September 30, 2021 primarily driven by increased activity across most of our core end markets. Bookings, net of cancellations and scope reductions, increased by 63% during the nine months ended June 30, 2022 to $460.0 million, compared to $282.9 million in the nine months ended June 30, 2021.

[0000080420-22-000032:mdna:43]
[same as prior period, unchanged from 0000080420-22-000019:mdna:43]

[0000080420-22-000032:mdna:44]
As noted in "Overview" above, the markets in which we participate are capital-intensive and cyclical in nature. A significant portion of our revenues has historically been from the oil, gas and petrochemical markets. Oil and gas commodity price levels have been unstable over the last several years, and our customers have in certain cases delayed or cancelled some of their major capital investment projects. Recently we have seen increased global demand for cleaner-burning fuels; however, the uncertainty in oil prices and the global economic impacts from COVID-19, including supply chain disruptions and associated inflationary pressures, as well as other geopolitical events may have a negative impact on our business going forward, as discussed in more detail below. Specific to the energy industry focus on transitioning to natural gas and cleaner-burning fuels, the business was awarded a substantial contract in Fiscal 2020 that will support the integrated electrical distribution requirements for a large domestic industrial complex and should be substantially completed in Fiscal 2022. We continue to experience increased demand from markets outside our core oil, gas and petrochemical end markets, helping to diversify our project portfolio.

[0000080420-22-000032:mdna:45]
Our operating results are impacted by factors such as the timing of new order awards, customer approval of final engineering and design specifications and delays in customer construction schedules, all of which contribute to short-term earnings variability and the timing of project execution. Our operating results also have been, and may continue to be, impacted by the timing and resolution of change orders, project close-out and resolution of potential contract claims and liquidated damages, all of which could improve or deteriorate gross margins during the period in which these items are resolved with our customers. Disruption in the global supply chain has negatively impacted our business and operating results as well due to the reduction in availability and uncertainty in the timing of the receipt of certain key component parts and commodities. These factors may result in periods of underutilization of our resources and facilities, which may negatively impact our ability to cover our fixed costs, or inhibit our ability to deliver completed products on time. Additionally, the increases in commodity and component costs from projects awarded in prior years may have a negative impact on our operating results in the event that we are not able to pass these cost increases to our customers. We experienced lower commercial activity in Fiscal 2020 and Fiscal 2021 driven in large part from the uncertainty resulting from the COVID-19 pandemic, as discussed in "Overview" above. Considering the long cycle nature of our business, we anticipate these cyclical conditions may persist throughout the remainder of Fiscal 2022. We will continue to remain focused on the variables that impact our markets as well as cost management, labor and supply chain challenges. We will also continue to adjust to the global conditions in order to maintain competitive cost and technological advantages in the markets that we serve.

[0000080420-22-000032:mdna:46]
The consequences of a prolonged economic decline could include, but are not limited to, a reduction in commercial and industrial activity. The Company cannot reasonably estimate the duration or severity of these global economic challenges, or the extent to which the resulting disruptions may materially impact our business, results of operations or cash flows. We will take prudent measures to maintain our strong liquidity and cash position, which may include reducing our capital expenditures and research and development costs, as well as reducing or eliminating future dividend payments.

[0000080420-22-000032:mdna:47]
[same as prior period, unchanged from 0000080420-22-000019:mdna:47]

[0000080420-22-000032:mdna:48]
As of June 30, 2022, current assets exceeded current liabilities by 2.2 times.

[0000080420-22-000032:mdna:49]
Cash, cash equivalents and short-term investments decreased to $98.5 million at June 30, 2022, compared to $134.0 million at September 30, 2021. This decrease in cash was primarily driven by increases in each of accounts receivable and inventory. We have strategically increased certain inventories due to uncertainty from the global supply chain issues impacting our business.  We believe that our strong working capital position, available borrowings under our credit facility and available cash should be sufficient to finance future operating activities, capital improvements, research and development initiatives and debt repayments for the foreseeable future.

[0000080420-22-000032:mdna:50]
We have a credit agreement with Bank of America, N.A. (as amended, the "U.S. Revolver") which is a $75.0 million revolving credit facility available for both borrowings and letters of credit and expires September 27, 2024. The U.S. Revolver states that up to $30 million may be deducted from the amount of letters of credit outstanding (not to be less than zero) when calculating the consolidated funded indebtedness which is a component of the consolidated net leverage ratio. Additionally, we have the option to cash collateralize all or a portion of the letters of credit outstanding, which would favorably impact the consolidated funded indebtedness calculation and the consolidated net leverage ratio.

[0000080420-22-000032:mdna:51]
On October 1, 2021, our industrial development revenue bonds matured and as a result we had no long-term debt at June 30, 2022. As of June 30, 2022, there were no amounts borrowed under the U.S. Revolver, and letters of credit outstanding were $30.8 million. As of June 30, 2022, $44.2 million was available for the issuance of letters of credit and borrowing under the U.S. Revolver. We are required to maintain certain financial covenants, the most significant of which are a consolidated net leverage ratio of less than 3.0 to 1.0 and a consolidated interest coverage ratio of greater than 3.0 to 1.0. Our most restrictive covenant, the consolidated net leverage ratio, is the ratio of earnings before interest, taxes, depreciation, amortization and stock-based compensation (EBITDAS) to funded indebtedness, which includes letters of credit. An increase in indebtedness or a decrease in EBITDAS could restrict our ability to issue letters of credit or borrow under the U.S. Revolver. For further information regarding our debt, see Notes E and F of Notes to Condensed Consolidated Financial Statements.

[0000080420-22-000032:mdna:52]
Approximately $28.4 million of our cash, cash equivalents and short-term investments at June 30, 2022 was held outside of the U.S. for our international operations. It is our intention to indefinitely reinvest all current and future foreign earnings internationally in order to ensure sufficient working capital to support our international operations. In the event that we elect to repatriate some or all of the foreign earnings that were previously deemed to be indefinitely reinvested outside the U.S., we may incur additional tax expense upon such repatriation under current tax laws.

[0000080420-22-000032:mdna:53]
[same as prior period, unchanged from 0000080420-22-000019:mdna:53]

[0000080420-22-000032:mdna:54]
Operating activities used net cash of $27.8 million during the nine months ended June 30, 2022 and $39.7 million during the same period in Fiscal 2021. Cash flow from operations is primarily influenced by the timing of milestone payments from our customers, project volume and the associated working capital requirements, as well as the payment terms with our suppliers. This increase in operating cash flow was primarily due to the timing of contract billing milestones although offset by the increase in accounts receivable. The strategic increase in inventory as a result of the uncertainty in the global supply chain negatively impacted cash flow for the first nine months of Fiscal 2022.

[0000080420-22-000032:mdna:55]
[same as prior period, unchanged from 0000080420-22-000019:mdna:55]

[0000080420-22-000032:mdna:56]
Investing activities used less than $0.1 million during the nine months ended June 30, 2022 and $2.0 million during the same period in Fiscal 2021. The decrease in cash used in investing activities in the first nine months of Fiscal 2022 was primarily due to proceeds of $4.3 million received from the sale of a small, non-core division of our Canadian operations.

[0000080420-22-000032:mdna:57]
[same as prior period, unchanged from 0000080420-22-000019:mdna:57]

[0000080420-22-000032:mdna:58]
Net cash used in financing activities was $10.2 million during the nine months ended June 30, 2022 and $10.1 million during the same period in Fiscal 2021, which primarily consisted of approximately $9.1 million of dividends paid in each period.

[0000080420-22-000032:mdna:59]
[same as prior period, unchanged from 0000080420-22-000019:mdna:59]

[0000080420-22-000032:mdna:60]
[same as prior period, unchanged from 0000080420-22-000019:mdna:60]

[0000080420-22-000032:mdna:61]
[same as prior period, unchanged from 0000080420-22-000019:mdna:61]
