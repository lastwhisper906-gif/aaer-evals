# POWL notes — 0000080420-22-000032


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureAndSignificantAccountingPoliciesTextBlock

[0000080420-22-000032:notes:1]
[same as prior period, unchanged from 0000080420-22-000019:notes:1]

[0000080420-22-000032:notes:2]
[same as prior period, unchanged from 0000080420-22-000019:notes:2]

[0000080420-22-000032:notes:3]
[same as prior period, unchanged from 0000080420-22-000019:notes:3]

[0000080420-22-000032:notes:4]
[same as prior period, unchanged from 0000080420-22-000019:notes:4]

[0000080420-22-000032:notes:5]
Various factors resulting in global economic uncertainty have negatively impacted our results over the past two years. Uncertainty and demand disruptions have resulted in considerable volatility across commodity markets. Although global oil prices have rebounded, our industrial end markets have responded with modest increases in capital expenditures. Additionally, we continue to experience supply chain disruptions driven predominately by availability and cost volatility across our raw materials, components and labor force. All of these factors have contributed to the lower margins realized in Fiscal 2022. As we address disruptions and increased costs, we continue to work with our suppliers of key components and commodities to ensure that we are able to meet our customer commitments. Additionally, we have adjusted our pricing models in response to the increased cost environment.

[0000080420-22-000032:notes:6]
The consequences of a continued and prolonged global economic decline could include, but are not limited to, reductions in commercial and industrial activity in the markets we serve. The Company cannot reasonably estimate the duration or extent to which the resulting disruptions may materially impact our business, results of operations or cash flows. We will take prudent measures to maintain our strong liquidity and cash position, which may include reducing our capital expenditures and research and development costs, as well as reducing or eliminating future dividend payments.

[0000080420-22-000032:notes:7]
[same as prior period, unchanged from 0000080420-22-000019:notes:7]

[0000080420-22-000032:notes:8]
[same as prior period, unchanged from 0000080420-22-000019:notes:8]

[0000080420-22-000032:notes:9]
[same as prior period, unchanged from 0000080420-22-000019:notes:9]

[0000080420-22-000032:notes:10]
[same as prior period, unchanged from 0000080420-22-000019:notes:10]

[0000080420-22-000032:notes:11]
[same as prior period, unchanged from 0000080420-22-000019:notes:11]


## us-gaap:EarningsPerShareTextBlock

[0000080420-22-000032:notes:12]
[same as prior period, unchanged from 0000080420-22-000019:notes:12]

[0000080420-22-000032:notes:13]
[same as prior period, unchanged from 0000080420-22-000019:notes:13]

[0000080420-22-000032:notes:14]
|  | Three months ended June 30, |  | Nine months ended June 30, |
|  | 2022 |  | 2021 |  | 2022 |  | 2021 |
| Numerator: |  |  |  |  |  |  |  |
| Net income (loss) | $ | 9,061 |  |  | $ | (2,041) |  |  | $ | 4,998 |  |  | $ | (2,629) |  |
| Denominator: |  |  |  |  |  |  |  |
| Weighted average basic shares | 11,810 |  |  | 11,720 |  |  | 11,792 |  |  | 11,700 |  |
| Dilutive effect of restricted stock units | 91 |  |  | — |  |  | 85 |  |  | — |  |
| Weighted average diluted shares | 11,901 |  |  | 11,720 |  |  | 11,877 |  |  | 11,700 |  |
| Income (loss) per share: |  |  |  |  |  |  |  |
| Basic | $ | 0.77 |  |  | $ | (0.17) |  |  | $ | 0.42 |  |  | $ | (0.22) |  |
| Diluted | $ | 0.76 |  |  | $ | (0.17) |  |  | $ | 0.42 |  |  | $ | (0.22) |  |

[0000080420-22-000032:notes:15]
For each of the three and nine months ended June 30, 2021, we incurred net losses and therefore all potential common shares were deemed to be anti-dilutive.


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0000080420-22-000032:notes:16]
[same as prior period, unchanged from 0000080420-22-000019:notes:16]

[0000080420-22-000032:notes:17]
[same as prior period, unchanged from 0000080420-22-000019:notes:17]

[0000080420-22-000032:notes:18]
|  | Three months ended June 30, |  | Nine months ended June 30, |
|  | 2022 |  | 2021 |  | 2022 |  | 2021 |
| Balance at beginning of period | $ | 703 |  |  | $ | 382 |  |  | $ | 333 |  |  | $ | 510 |  |
| Bad debt expense (recovery), net | (170) |  |  | 326 |  |  | 274 |  |  | 194 |  |
| Uncollectible accounts written off, net of recoveries | 6 |  |  | (168) |  |  | (64) |  |  | (178) |  |
| Change due to foreign currency translation | (22) |  |  | 5 |  |  | (26) |  |  | 19 |  |
| Balance at end of period | $ | 517 |  |  | $ | 545 |  |  | $ | 517 |  |  | $ | 545 |  |

[0000080420-22-000032:notes:19]
[same as prior period, unchanged from 0000080420-22-000019:notes:19]

[0000080420-22-000032:notes:20]
[same as prior period, unchanged from 0000080420-22-000019:notes:20]

[0000080420-22-000032:notes:21]
|  | June 30, 2022 |  | September 30, 2021 |
| Raw materials, parts and sub-assemblies, net | $ | 47,458 |  |  | $ | 28,688 |  |
| Work-in-progress | 1,281 |  |  | 1,147 |  |
| Total inventories | $ | 48,739 |  |  | $ | 29,835 |  |

[0000080420-22-000032:notes:22]
[same as prior period, unchanged from 0000080420-22-000019:notes:22]

[0000080420-22-000032:notes:23]
[same as prior period, unchanged from 0000080420-22-000019:notes:23]

[0000080420-22-000032:notes:24]
|  | Three months ended June 30, |  | Nine months ended June 30, |
|  | 2022 |  | 2021 |  | 2022 |  | 2021 |
| Balance at beginning of period | $ | 2,347 |  |  | $ | 2,467 |  |  | $ | 2,531 |  |  | $ | 2,771 |  |
| Increase to warranty expense | 462 |  |  | 515 |  |  | 1,077 |  |  | 1,568 |  |
| Deduction for warranty charges | (499) |  |  | (557) |  |  | (1,303) |  |  | (1,970) |  |
| Change due to foreign currency translation | (22) |  |  | 7 |  |  | (17) |  |  | 63 |  |
| Balance at end of period | $ | 2,288 |  |  | $ | 2,432 |  |  | $ | 2,288 |  |  | $ | 2,432 |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0000080420-22-000032:notes:25]
[same as prior period, unchanged from 0000080420-22-000019:notes:25]

[0000080420-22-000032:notes:26]
[same as prior period, unchanged from 0000080420-22-000019:notes:26]

[0000080420-22-000032:notes:27]
[same as prior period, unchanged from 0000080420-22-000019:notes:27]

[0000080420-22-000032:notes:28]
We also have contracts to provide value-added services such as field service inspection, installation, commissioning, modification and repair, as well as retrofit and retro-fill components for existing systems.  If the service contract terms give us the right to invoice the customer for an amount that corresponds directly with the value of our performance completed to date (i.e., a service contract in which we bill a fixed amount for each hour of service provided), then we recognize revenue over time in each reporting period corresponding to the amount with which we have the right to invoice.  Our performance obligations are satisfied as the work progresses. Revenues from our custom-engineered products and value-added services transferred to customers over time accounted for approximately 94% of total revenues for the three and nine months ended June 30, 2022, 93% of total revenues for the three months ended June 30, 2021 and 92% of total revenues for the nine months ended June 30, 2021.

[0000080420-22-000032:notes:29]
Additionally, we have sales orders for spare parts and replacement circuit breakers for switchgear that are obsolete or that are no longer produced by the original manufacturer. Revenues from these sales orders are recognized at the time we fulfill our performance obligation to the customer, which is typically upon shipment and represented approximately 6% of total revenues for the three and nine months ended June 30, 2022, 7% of total revenues for the three months ended June 30, 2021 and 8% of total revenues for the nine months ended June 30, 2021.

[0000080420-22-000032:notes:30]
[same as prior period, unchanged from 0000080420-22-000019:notes:30]

[0000080420-22-000032:notes:31]
[same as prior period, unchanged from 0000080420-22-000019:notes:31]

[0000080420-22-000032:notes:32]
[same as prior period, unchanged from 0000080420-22-000019:notes:32]

[0000080420-22-000032:notes:33]
[same as prior period, unchanged from 0000080420-22-000019:notes:33]

[0000080420-22-000032:notes:34]
Remaining unsatisfied performance obligations, which we refer to as backlog, represent the estimated transaction price for goods and services for which we have a material right, but work has not been performed. As of June 30, 2022, we had backlog of $502.5 million, of which approximately $379.6 million is expected to be recognized as revenue within the next twelve months. Backlog may not be indicative of future operating results as orders may be cancelled or modified by our customers. Our backlog does not include service and maintenance-type contracts for which we have the right to invoice as services are performed.

[0000080420-22-000032:notes:35]
[same as prior period, unchanged from 0000080420-22-000019:notes:35]

[0000080420-22-000032:notes:36]
[same as prior period, unchanged from 0000080420-22-000019:notes:36]

[0000080420-22-000032:notes:37]
For the nine months ended June 30, 2022 and 2021, our operating results were positively impacted by $5.9 million and $11.4 million, respectively, as a result of changes in contract estimates related to projects in progress at the beginning of the respective period. These changes in estimates resulted primarily from favorable project execution and negotiations of variable consideration, discussed below, as well as revenue and reduced costs recognized from project cancellations and other changes in facts and circumstances during these periods. The decrease from the prior year is primarily due to the increase in direct materials cost, which we were not able to pass on to our customers for projects awarded in prior years.

[0000080420-22-000032:notes:38]
[same as prior period, unchanged from 0000080420-22-000019:notes:38]

[0000080420-22-000032:notes:39]
[same as prior period, unchanged from 0000080420-22-000019:notes:39]

[0000080420-22-000032:notes:40]
[same as prior period, unchanged from 0000080420-22-000019:notes:40]

[0000080420-22-000032:notes:41]
[same as prior period, unchanged from 0000080420-22-000019:notes:41]

[0000080420-22-000032:notes:42]
[same as prior period, unchanged from 0000080420-22-000019:notes:42]

[0000080420-22-000032:notes:43]
[same as prior period, unchanged from 0000080420-22-000019:notes:43]

[0000080420-22-000032:notes:44]
[same as prior period, unchanged from 0000080420-22-000019:notes:44]

[0000080420-22-000032:notes:45]
[same as prior period, unchanged from 0000080420-22-000019:notes:45]

[0000080420-22-000032:notes:46]
[same as prior period, unchanged from 0000080420-22-000019:notes:46]

[0000080420-22-000032:notes:47]
Contract assets and liabilities as of June 30, 2022 and September 30, 2021 are summarized below (in thousands):

[0000080420-22-000032:notes:48]
|  | June 30, 2022 |  | September 30, 2021 |
| Contract assets | $ | 68,245 |  |  | $ | 54,199 |  |
| Contract liabilities | (66,582) |  |  | (42,433) |  |
| Net contract asset | $ | 1,663 |  |  | $ | 11,766 |  |

[0000080420-22-000032:notes:49]
The decrease in net contract asset at June 30, 2022 from September 30, 2021 was primarily due to the timing of contract billing milestones and new orders as well as cash used on our large industrial project awarded in Fiscal 2020. To determine the amount of revenue recognized during the period from contract liabilities, we first allocate revenue to the individual contract liability balance outstanding at the beginning of the period until the revenue exceeds that balance. During the nine months ended June 30, 2022, we recognized revenue of approximately $36.0 million that was related to contract liabilities outstanding at September 30, 2021.

[0000080420-22-000032:notes:50]
The timing of our invoice process is typically dependent on the completion of certain milestones and contract terms and subject to agreement by our customer.  Payment is typically expected within 30 days of invoice. Any uncollected invoiced amounts for our performance obligations recognized over time, including contract retentions, are recorded as accounts receivable in the Condensed Consolidated Balance Sheets. Certain contracts allow customers to withhold a small percentage of billings pursuant to retainage provisions, and such amounts are generally due upon completion of the contract and acceptance of the project by the customer. Based on our experience in recent years, the majority of these retainage balances are expected to be collected within approximately twelve months. As of June 30, 2022 and September 30, 2021, accounts receivable included retention amounts of $9.2 million and $9.6 million, respectively. Of the retained amount at June 30, 2022, $8.6 million is expected to be collected in the next twelve months and is recorded in accounts receivable. The remaining $0.6 million is recorded in other assets.

[0000080420-22-000032:notes:51]
[same as prior period, unchanged from 0000080420-22-000019:notes:51]

[0000080420-22-000032:notes:52]
The following tables present our disaggregated revenue by geographic destination and market sector for the three and nine months ended June 30, 2022 and 2021 (in thousands):

[0000080420-22-000032:notes:53]
|  | Three months ended June 30, |  | Nine months ended June 30, |
|  | 2022 |  | 2021 |  | 2022 |  | 2021 |
| United States | $ | 102,931 |  |  | $ | 88,412 |  |  | $ | 272,069 |  |  | $ | 256,937 |  |
| Canada | 23,599 |  |  | 16,529 |  |  | 60,777 |  |  | 48,354 |  |
| Europe, Middle East and Africa | 6,697 |  |  | 8,926 |  |  | 30,078 |  |  | 28,120 |  |
| Asia/Pacific | 1,645 |  |  | 1,651 |  |  | 4,235 |  |  | 6,376 |  |
| Mexico, Central and South America | 611 |  |  | 295 |  |  | 2,748 |  |  | 1,318 |  |
| Total revenues by geographic destination | $ | 135,483 |  |  | $ | 115,813 |  |  | $ | 369,907 |  |  | $ | 341,105 |  |

[0000080420-22-000032:notes:54]
|  | Three months ended June 30, |  | Nine months ended June 30, |
|  | 2022 |  | 2021 |  | 2022 |  | 2021 |
| Oil and gas (excludes petrochemical) | $ | 58,669 |  |  | $ | 49,272 |  |  | $ | 155,324 |  |  | $ | 139,443 |  |
| Petrochemical | 15,187 |  |  | 15,365 |  |  | 51,268 |  |  | 34,725 |  |
| Electric utility | 30,173 |  |  | 26,175 |  |  | 82,079 |  |  | 82,797 |  |
| Traction power | 9,775 |  |  | 13,821 |  |  | 31,200 |  |  | 42,322 |  |
| All others | 21,679 |  |  | 11,180 |  |  | 50,036 |  |  | 41,818 |  |
| Total revenues by market sector | $ | 135,483 |  |  | $ | 115,813 |  |  | $ | 369,907 |  |  | $ | 341,105 |  |


## us-gaap:RevenueFromContractWithCustomerPolicyTextBlock

[0000080420-22-000032:notes:55]
[same as prior period, unchanged from 0000080420-22-000019:notes:55]

[0000080420-22-000032:notes:56]
Additionally, we have sales orders for spare parts and replacement circuit breakers for switchgear that are obsolete or that are no longer produced by the original manufacturer. Revenues from these sales orders are recognized at the time we fulfill our performance obligation to the customer, which is typically upon shipment and represented approximately 6% of total revenues for the three and nine months ended June 30, 2022, 7% of total revenues for the three months ended June 30, 2021 and 8% of total revenues for the nine months ended June 30, 2021. 
Some contracts may contain a cancellation clause that could limit the amount of revenue we are able to recognize over time. In these instances, revenue and costs associated with these contracts are deferred and recognized at a point in time when the performance obligation is fulfilled.Selling and administrative costs incurred in relation to obtaining a contract are typically expensed as incurred. We periodically utilize a third-party sales agent to obtain a contract and will pay a commission to that agent. We record the full commission liability to the third-party sales agents at the order date, with a corresponding deferred asset. As the project progresses, we record commission expense based on percentage of completion rates that correlate to the project and reduce the deferred asset. Once we have been paid by the customer, we pay the commission and the deferred liability is reduced
Performance Obligations

[0000080420-22-000032:notes:57]
[same as prior period, unchanged from 0000080420-22-000019:notes:57]

[0000080420-22-000032:notes:58]
[same as prior period, unchanged from 0000080420-22-000019:notes:58]


## us-gaap:LongTermDebtTextBlock

[0000080420-22-000032:notes:59]
Long-Term Debt
Long-term debt consisted of the following (in thousands):

[0000080420-22-000032:notes:60]
|  | June 30, 2022 |  | September 30, 2021 |
| Industrial development revenue bonds | $ | — |  |  | $ | 400 |  |
| Less: current portion | — |  |  | (400) |  |
| Total long-term debt | $ | — |  |  | $ | — |  |

[0000080420-22-000032:notes:61]
U.S. Revolver

[0000080420-22-000032:notes:62]
We have a credit agreement with Bank of America, N.A. (as amended, the "U.S. Revolver"), which is a $75.0 million revolving credit facility that is available for both borrowings and letters of credit and expires September 27, 2024. The U.S. Revolver states that up to $30 million may be deducted from the amount of letters of credit outstanding (not to be less than zero) when calculating the consolidated funded indebtedness which is a component of the consolidated net leverage ratio. Additionally, we have the option to cash collateralize all or a portion of the letters of credit outstanding, which would favorably impact the consolidated funded indebtedness calculation and the consolidated net leverage ratio. As of June 30, 2022, there were no amounts borrowed under the U.S. Revolver and letters of credit outstanding were $30.8 million. There was $44.2 million available for the issuance of letters of credit and borrowings under the U.S. Revolver as of June 30, 2022.

[0000080420-22-000032:notes:63]
We are required to maintain certain financial covenants, the most significant of which are a consolidated net leverage ratio less than 3.0 to 1.0 and a consolidated interest coverage ratio of greater than 3.0 to 1.0. Our most restrictive covenant, the consolidated net leverage ratio, is the ratio of earnings before interest, taxes, depreciation, amortization and stock-based compensation (EBITDAS) to funded indebtedness. An increase in indebtedness, which includes letters of credit, or a decrease in EBITDAS could restrict our ability to issue letters of credit or borrow under the U.S. Revolver. Additionally, we must maintain a consolidated cash balance of $30 million at all times, which can be deducted from the letters of credit outstanding as noted above. The U.S. Revolver also contains a "material adverse effect" clause which is a material change in our operations, business, properties, liabilities or condition (financial or otherwise) or a material impairment of our ability to perform our obligations under our credit agreements. As of June 30, 2022, we were in compliance with all of the financial covenants of the U.S. Revolver.

[0000080420-22-000032:notes:64]
The U.S. Revolver allows the Company to elect that any borrowing under the facility bears an interest rate based on either the base rate or the eurocurrency rate, in each case, plus the applicable rate. The base rate is generally the highest of (a) the federal funds rate plus 0.50%, (b) the Bank of America prime rate or (c) the London Interbank Offered Rate (LIBOR) successor rate plus 1.00%. The applicable rate is generally a range from (0.25)% to 1.75% depending on the type of loan and the Company's consolidated net leverage ratio. On December 31, 2021, the Company entered into a LIBOR Transition Amendment with Bank of America that states that LIBOR will be replaced with a successor rate in accordance with the U.S. Revolver.

[0000080420-22-000032:notes:65]
The U.S. Revolver is collateralized by a pledge of 100% of the voting capital stock of each of our domestic subsidiaries and 65% of the voting capital stock of each non-domestic subsidiary. The U.S. Revolver provides for customary events of default and carries cross-default provisions with other existing debt agreements. If an event of default (as defined in the U.S. Revolver) occurs and is continuing, on the terms and subject to the conditions set forth in the U.S. Revolver, amounts and letters of credit outstanding under the U.S. Revolver may be accelerated and may become immediately due and payable.

[0000080420-22-000032:notes:66]
Industrial Development Revenue Bonds

[0000080420-22-000032:notes:67]
We borrowed $8.0 million in October 2001 through a loan agreement funded with proceeds from tax-exempt industrial development revenue bonds (Bonds) for the completion of our Northlake, Illinois facility. The Bonds matured on October 1, 2021 and our final payment of $0.4 million was made.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0000080420-22-000032:notes:68]
Commitments and Contingencies
Letters of Credit, Bank Guarantees and Bonds

[0000080420-22-000032:notes:69]
Certain customers require us to post letters of credit, bank guarantees or surety bonds. These security instruments assure that we will perform under the terms of our contract. In the event of default, the counterparty may demand payment from the bank under a letter of credit or bank guarantee, or performance by the surety under a bond. To date, there have been no significant draws or claims related to security instruments for the periods reported. We were contingently liable for letters of credit of $30.8 million as of June 30, 2022. We also had surety bonds totaling $159.9 million that were outstanding, with additional bonding capacity of $440.1 million available, at June 30, 2022. We have strong surety relationships; however, a change in market conditions or the sureties' assessment of our financial position could cause the sureties to require cash collateralization for undischarged liabilities under the bonds.

[0000080420-22-000032:notes:70]
We have a $6.1 million facility agreement (Facility Agreement) between Powell (UK) Limited and a large international bank that provides Powell (UK) Limited the ability to enter into bank guarantees as well as forward exchange contracts and currency options. At June 30, 2022, we had outstanding guarantees totaling $3.1 million and amounts available under this Facility Agreement were $3.0 million. The Facility Agreement provides for customary events of default, and carries cross-default provisions with our U.S. Revolver. If an event of default (as defined in the Facility Agreement) occurs and is continuing, per the terms and subject to the conditions set forth therein, obligations outstanding under the Facility Agreement may be accelerated and declared immediately due and payable. Additionally, we are required to maintain cash collateral for guarantees greater than two years. As of June 30, 2022, we were in compliance with all of the financial covenants of the Facility Agreement.

[0000080420-22-000032:notes:71]
Litigation

[0000080420-22-000032:notes:72]
We are involved in various legal proceedings, claims and other disputes arising from our commercial operations, projects, employees and other matters which, in general, are subject to uncertainties and in which the outcomes are not predictable. Although we can give no assurances about the resolution of pending claims, litigation or other disputes and the effect such outcomes may have on us, management believes that any ultimate liability resulting from the outcome of such proceedings, to the extent not otherwise provided or covered by insurance, will not have a material adverse effect on our consolidated financial position or results of operations or liquidity.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0000080420-22-000032:notes:73]
[same as prior period, unchanged from 0000080420-22-000019:notes:73]

[0000080420-22-000032:notes:74]
[same as prior period, unchanged from 0000080420-22-000019:notes:74]

[0000080420-22-000032:notes:75]
We issue restricted stock units (RSUs) to certain officers and key employees of the Company. The fair value of the RSUs is based on the price of our common stock as reported on the NASDAQ Global Market on the grant dates. Typically, these grants vest over a three-year period from the date of issuance and are a blend of time-based and performance-based shares. The portion of the grant that is time-based typically vests over a three-year period on each anniversary of the grant date, based on continued employment. The performance-based shares vest based on the three-year earnings performance of the Company following the grant date. At June 30, 2022, there were 234,852 RSUs outstanding. The RSUs do not have voting rights but do receive dividend equivalents upon vesting which are accrued quarterly. Additionally, the shares of common stock underlying the RSUs are not considered issued and outstanding until vested and common stock is issued.

[0000080420-22-000032:notes:76]
Total RSU activity (number of shares) for the nine months ended June 30, 2022 is summarized below:

[0000080420-22-000032:notes:77]
|  | Number ofRestrictedStockUnits |  | WeightedAverageGrant ValuePer Share |
| Outstanding at September 30, 2021 | 199,919 |  |  | $ | 30.34 |  |
| Granted | 107,350 |  |  | 24.79 |  |
| Vested | (72,017) |  |  | 32.68 |  |
| Forfeited/canceled | (400) |  |  | 38.58 |  |
| Outstanding at June 30, 2022 | 234,852 |  |  | $ | 26.91 |  |

[0000080420-22-000032:notes:78]
During the nine months ended June 30, 2022 and 2021, we recorded compensation expense of $1.9 million and $1.7 million, respectively, related to the RSUs.

[0000080420-22-000032:notes:79]
Restricted Stock
Each non-employee director receives 2,400 restricted shares of the Company’s common stock annually. Fifty-percent of the restricted stock granted to each of our non-employee directors vests immediately, while the remaining fifty-percent vests on the anniversary of the grant date. Compensation expense is recognized immediately for the first fifty-percent of the restricted stock granted, while compensation expense for the remaining fifty-percent is recognized over the remaining vesting period. In February 2022, 16,800 shares of restricted stock were issued to our non-employee directors under the 2014 Non-Employee Director Equity Incentive Plan at a price of $23.09 per share. During the nine months ended June 30, 2022 and 2021, we recorded compensation expense of $0.4 million and $0.5 million, respectively, related to restricted stock.


## us-gaap:FairValueDisclosuresTextBlock

[0000080420-22-000032:notes:80]
[same as prior period, unchanged from 0000080420-22-000019:notes:80]

[0000080420-22-000032:notes:81]
[same as prior period, unchanged from 0000080420-22-000019:notes:81]

[0000080420-22-000032:notes:82]
[same as prior period, unchanged from 0000080420-22-000019:notes:82]

[0000080420-22-000032:notes:83]
[same as prior period, unchanged from 0000080420-22-000019:notes:83]

[0000080420-22-000032:notes:84]
[same as prior period, unchanged from 0000080420-22-000019:notes:84]

[0000080420-22-000032:notes:85]
The following table summarizes the fair value of our assets and liabilities that were accounted for at fair value on a recurring basis as of June 30, 2022 (in thousands):

[0000080420-22-000032:notes:86]
|  | Fair Value Measurements at June 30, 2022 |
|  | Quoted Prices inActive Markets forIdentical Assets(Level 1) |  | Significant OtherObservableInputs(Level 2) |  | SignificantUnobservableInputs(Level 3) |  | Fair Value at June 30,2022 |
| Assets: |  |  |  |  |  |  |  |
| Cash and cash equivalents | $ | 75,830 |  |  | $ | — |  |  | $ | — |  |  | $ | 75,830 |  |
| Short-term investments | 22,682 |  |  | — |  |  | — |  |  | 22,682 |  |
| Other assets | — |  |  | 7,569 |  |  | — |  |  | 7,569 |  |
| Liabilities: |  |  |  |  |  |  |  |
| Deferred compensation | — |  |  | 8,052 |  |  | — |  |  | 8,052 |  |

[0000080420-22-000032:notes:87]
[same as prior period, unchanged from 0000080420-22-000019:notes:87]

[0000080420-22-000032:notes:88]
[same as prior period, unchanged from 0000080420-22-000019:notes:88]

[0000080420-22-000032:notes:89]
[same as prior period, unchanged from 0000080420-22-000019:notes:89]

[0000080420-22-000032:notes:90]
[same as prior period, unchanged from 0000080420-22-000019:notes:90]

[0000080420-22-000032:notes:91]
[same as prior period, unchanged from 0000080420-22-000019:notes:91]

[0000080420-22-000032:notes:92]
[same as prior period, unchanged from 0000080420-22-000019:notes:92]

[0000080420-22-000032:notes:93]
There were no transfers between levels within the fair value measurement hierarchy during the quarter ended June 30, 2022.


## us-gaap:LesseeOperatingLeasesTextBlock

[0000080420-22-000032:notes:94]
Leases
Our leases consist primarily of office and manufacturing space and construction equipment. All of our future lease obligations are related to non-cancelable operating leases. The most significant portion of our lease portfolio relates to leases of office and manufacturing facilities in Canada which we no longer occupy. We currently sublease the majority of these Canadian facilities. The following table provides a summary of lease cost components for the three and nine months ended June 30, 2022 and 2021, respectively (in thousands):

[0000080420-22-000032:notes:95]
|  |  | Three months ended June 30, |  | Nine months ended June 30, |
| Lease Cost |  | 2022 |  | 2021 |  | 2022 |  | 2021 |
| Operating lease cost |  | $ | 551 |  |  | $ | 598 |  |  | $ | 1,695 |  |  | $ | 1,835 |  |
| Less: sublease income |  | (171) |  |  | (175) |  |  | (519) |  |  | (532) |  |
| Variable lease cost(1) |  | 114 |  |  | 117 |  |  | 372 |  |  | 334 |  |
| Short-term lease cost(2) |  | 413 |  |  | 365 |  |  | 1,266 |  |  | 853 |  |
| Total lease cost |  | $ | 907 |  |  | $ | 905 |  |  | $ | 2,814 |  |  | $ | 2,490 |  |

[0000080420-22-000032:notes:96]
[same as prior period, unchanged from 0000080420-22-000019:notes:96]

[0000080420-22-000032:notes:97]
[same as prior period, unchanged from 0000080420-22-000019:notes:97]

[0000080420-22-000032:notes:98]
We recognize operating lease assets and operating lease liabilities representing the present value of the remaining lease payments for leases with initial terms greater than twelve months. Leases with initial terms of twelve months or less are not recorded in our Condensed Consolidated Balance Sheets. As of June 30, 2022 and September 30, 2021, our operating lease assets have been reduced by a lease accrual of $0.2 million and $0.4 million, respectively, related to certain unused facility leases in Canada. The following table provides a summary of the operating lease assets and operating lease liabilities included in our Condensed Consolidated Balance Sheets as of June 30, 2022 and September 30, 2021, respectively (in thousands):

[0000080420-22-000032:notes:99]
| Operating Leases |  | June 30, 2022 |  | September 30, 2021 |
| Assets: |  |  |  |  |
| Operating lease assets, net |  | $ | 1,909 |  |  | $ | 3,453 |  |
| Liabilities: |  |  |  |  |
| Current operating lease liabilities |  | 953 |  |  | 1,415 |  |
| Long-term operating lease liabilities |  | 1,159 |  |  | 2,413 |  |
| Total lease liabilities |  | $ | 2,112 |  |  | $ | 3,828 |  |

[0000080420-22-000032:notes:100]
The following table provides the maturities of our operating lease liabilities as of June 30, 2022 (in thousands):

[0000080420-22-000032:notes:101]
|  |  | Operating Leases |  |  |
| Remainder of 2022 |  | $ | 529 |  |  |  |
| 2023 |  | 1,336 |  |  |  |
| 2024 |  | 221 |  |  |  |
| 2025 |  | 58 |  |  |  |
| 2026 |  | 20 |  |  |  |
| Thereafter |  | 2 |  |  |  |
| Total future minimum lease payments |  | $ | 2,166 |  |  |  |
| Less: present value discount (imputed interest) |  | (54) |  |  |  |
| Present value of lease liabilities |  | $ | 2,112 |  |  |  |

[0000080420-22-000032:notes:102]
The weighted average discount rate as of June 30, 2022 was 3.89%. The weighted average remaining lease term was 1.44 years at June 30, 2022.


## us-gaap:IncomeTaxDisclosureTextBlock

[0000080420-22-000032:notes:103]
[same as prior period, unchanged from 0000080420-22-000019:notes:103]

[0000080420-22-000032:notes:104]
|  | Three months ended June 30, |  | Nine months ended June 30, |
|  | 2022 |  | 2021 |  | 2022 |  | 2021 |
| Income (loss) before income taxes | $ | 2,918 |  |  | $ | (1,338) |  |  | $ | (774) |  |  | $ | (2,767) |  |
| Income tax provision (benefit) | (6,143) |  |  | 703 |  |  | (5,772) |  |  | (138) |  |
| Net income (loss) | $ | 9,061 |  |  | $ | (2,041) |  |  | $ | 4,998 |  |  | $ | (2,629) |  |
| Effective tax rate | (211) | % |  | (53) | % |  | 746 | % |  | 5 | % |

[0000080420-22-000032:notes:105]
We record and maintain valuation allowances against the deferred tax assets of various foreign jurisdictions until sufficient evidence is available to demonstrate that it is more-likely-than-not that the net deferred tax assets will be recognized. As of each reporting date, management considers new evidence, both positive and negative, that could affect its view of the future realization of deferred tax assets. During the period ended June 30, 2022, management determined that there is sufficient positive evidence to conclude that Canadian net deferred tax assets of $5.9 million are realizable. This determination was based on current and anticipated market conditions, continued market diversification, operating results over the past three years and anticipated future taxable income from our Canadian operations. The valuation allowance was released accordingly, and a $5.9 million tax benefit and corresponding increase in the deferred tax asset were recorded.

[0000080420-22-000032:notes:106]
The tax benefit for the three and nine months ended June 30, 2022 was also impacted by a discrete item related to the gain recognized from the disposition of a small, non-core division of our Canadian operations.  This gain on the disposal resulted in tax expense of $0.4 million.

[0000080420-22-000032:notes:107]
For the three months ended June 30, 2021, we recorded an income tax provision due to our inability to recognize a tax benefit related to losses in the United Kingdom and the change in the estimated amounts of income (loss) recognized in the various tax jurisdictions. These items also reduced the tax benefit for the nine months ended June 30, 2021 that largely resulted from the estimated Research and Development Tax Credit (R&D Tax Credit) as well as the utilization of net operating loss carryforwards in Canada that were fully reserved with a valuation allowance.


## us-gaap:DisposalGroupsIncludingDiscontinuedOperationsDisclosureTextBlock

[0000080420-22-000032:notes:108]
DivestitureOn June 30, 2022, we sold a non-core, industrial valve repair and servicing business within our Canadian operations and received proceeds of $4.3 million. We recorded a $2.0 million pre-tax gain on this transaction, which has been presented as other income on our Condensed Consolidated Statements of Operations for the quarter ended June 30, 2022.


## us-gaap:SubsequentEventsTextBlock

[0000080420-22-000032:notes:109]
Subsequent Events
Quarterly Dividend Declared

[0000080420-22-000032:notes:110]
On August 2, 2022, our Board of Directors declared a quarterly cash dividend on our common stock in the amount of $0.26 per share. The dividend is payable on September 21, 2022 to shareholders of record at the close of business on August 17, 2022.
