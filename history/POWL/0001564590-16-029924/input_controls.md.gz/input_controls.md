# POWL 10-K controls and the auditor's report


## auditors_report

10-K auditors_report: 2 candidate headings, none whose body matches 'critical audit matter'.


## item_9a

[0001564590-16-029924:item_9a:1]
Item 9A. Controls and Procedures

[0001564590-16-029924:item_9a:2]
Evaluation of Disclosure Controls and Procedures

[0001564590-16-029924:item_9a:3]
We have established and maintain a system of disclosure controls and procedures that are designed to provide reasonable assurance that information required to be disclosed in our reports filed with the SEC pursuant to the Securities Exchange Act of 1934, as amended (Exchange Act), is recorded, processed, summarized and reported within the time periods specified in the rules and forms of the SEC and that such information is accumulated and communicated to our management, including our Chief Executive Officer (CEO) and Chief Financial Officer (CFO), as appropriate, to allow timely decisions regarding required disclosures.

[0001564590-16-029924:item_9a:4]
Management, with the participation of our CEO and CFO, has evaluated the effectiveness of the design and operation of our disclosure controls and procedures (as defined in Rules 13a-15(e) and 15d-15(e) of the Exchange Act) as of the end of the period covered by this Annual Report on Form 10-K. Based on such evaluation, our CEO and CFO have each concluded that, as of September 30, 2016, the end of the period covered by this Annual Report on Form 10-K, our disclosure controls and procedures were effective to provide reasonable assurance that information required to be disclosed by us in reports that we file or submit under the Exchange Act is recorded, processed, summarized and reported within the time periods specified in the SEC’s rules and forms and that such information is accumulated and communicated to our management, including the CEO and CFO, as appropriate, to allow timely decisions regarding required disclosures.

[0001564590-16-029924:item_9a:5]
Management’s Report on Internal Control Over Financial Reporting

[0001564590-16-029924:item_9a:6]
Management is responsible for establishing and maintaining effective internal control over financial reporting as defined in Rule 13a-15(f) under the Exchange Act. Our system of internal control was designed using a top-down risk-based approach to provide reasonable assurance regarding the reliability of financial reporting and the preparation of financial statements for external purposes in accordance with generally accepted accounting principles. Due to its inherent limitations, internal control over financial reporting may not prevent or detect misstatements. Also, projections of any evaluation of effectiveness to future periods are subject to the risk that controls may become ineffective due to changes in conditions or deterioration in the degree of compliance with the policies or procedures.

[0001564590-16-029924:item_9a:7]
Management of the Company has assessed the effectiveness of our internal control over financial reporting as of September 30, 2016. Management evaluated the effectiveness of our internal control over financial reporting based on the criteria in Internal Control – Integrated Framework (2013) issued by the Committee of Sponsoring Organizations of the Treadway Commission (COSO). Based on management’s evaluation, management has concluded that our internal control over financial reporting was effective at the reasonable assurance level as of September 30, 2016, based on criteria in Internal Control – Integrated Framework (2013) issued by the COSO.

[0001564590-16-029924:item_9a:8]
PricewaterhouseCoopers LLP, an independent registered public accounting firm, has audited and issued their report on the effectiveness of our internal control over financial reporting as of September 30, 2016, which appears in their report on the financial statements included herein.

[0001564590-16-029924:item_9a:9]
Changes in Internal Control Over Financial Reporting

[0001564590-16-029924:item_9a:10]
There have been no changes in our internal control over financial reporting that occurred during the last fiscal quarter that have materially affected, or are reasonably likely to materially affect, our internal control over financial reporting.
