# POWL MD&A — 0001564590-16-029924


## mdna

[0001564590-16-029924:mdna:1]
Item 7. Management’s Discussion and Analysis of Financial Condition and Results of Operations

[0001564590-16-029924:mdna:2]
Overview

[0001564590-16-029924:mdna:3]
We develop design, manufacture and service custom-engineered equipment and systems for the distribution, control and monitoring of electrical energy. Headquartered in Houston, Texas, we serve the oil and gas refining, offshore oil and gas production, petrochemical, pipeline, terminal, mining and metals, light rail traction power, electric utility, pulp and paper and other industrial markets. Revenues and costs are primarily related to custom engineered-to-order equipment and systems and are accounted for under percentage-of-completion accounting which precludes us from providing detailed price and volume information. Our backlog includes various projects that take a number of months to produce.

[0001564590-16-029924:mdna:4]
The markets in which we participate are capital intensive and cyclical in nature. Cyclicality is predominantly driven by customer demand, global economic conditions and anticipated environmental, safety or regulatory changes that affect the manner in which our customers proceed with capital investments. Our customers analyze various factors including the demand and price for oil, gas and electrical energy, the overall economic and financial environment, governmental budgets, regulatory actions and environmental concerns. These factors influence the release of new capital projects by our customers, which are traditionally awarded in competitive bid situations. Scheduling of projects is matched to the customer requirements and projects typically take a number of months to produce.  Schedules may change during the course of any particular project and our operating results can therefore be impacted by factors outside of our control.  Due to the decline in oil and gas prices from 2014 levels, many of our customers have reduced their capital budgets and cut costs, and in certain instances have delayed or cancelled projects that we were pursuing.

[0001564590-16-029924:mdna:5]
Our strategy in Canada has been to replicate our project-based integration model which allows for the design, fabrication, integration and testing of our products at a single location.  This strategic initiative has presented challenges for our Canadian operations in prior years, resulting in inefficiencies that led to higher operating costs, gross margin deterioration and operating losses.  We took various actions in Canada and have seen improvements in our operational efficiencies during Fiscal 2016.  However, the depressed oil and gas market conditions will likely have a negative impact on our Canadian operations for the foreseeable future.

[0001564590-16-029924:mdna:6]
During Fiscal 2015, our consolidated operating results were negatively impacted by operational inefficiencies resulting from increased volume and project scheduling delays. Our inability to meet contractual commitments on existing projects, as well as delays in customer construction schedules, negatively impacted the timing and costs related to project execution. Our operating results were negatively impacted by the timing and resolution of change orders, project close-out and resolution of potential liquidated damage claims, all of which impacted gross margins during the period in which these items are resolved with our customers.

[0001564590-16-029924:mdna:7]
During Fiscal 2016, continued weakness in the oil and gas markets caused further declines in the number and size of projects leading to a decrease in revenues and backlog of projects.  In response to our reduced project backlog, we have taken steps to reduce our cost structure, restructure our senior management team and align our salaried and hourly workforce with future production requirements.

[0001564590-16-029924:mdna:8]
On January 15, 2014, we sold our wholly-owned subsidiary Transdyn to a global provider of electronic toll collection systems, headquartered in Vienna, Austria.  The purchase price from the sale of this subsidiary totaled $16.0 million, subject to working capital adjustments. We received cash of $14.4 million and the remaining $1.6 million was placed into an escrow account and released to us in July 2015. We have presented the results of these operations as income from discontinued operations, net of tax, in the consolidated statements of operations for all periods presented.  Accordingly, we have removed Transdyn from the Results of Operations discussions below.

[0001564590-16-029924:mdna:9]
Results of Operations

[0001564590-16-029924:mdna:10]
Twelve Months Ended September 30, 2016 Compared to Twelve Months Ended September 30, 2015

[0001564590-16-029924:mdna:11]
Revenue and Gross Profit

[0001564590-16-029924:mdna:12]
Revenues decreased 15%, or $96.6 million, to $565.2 in Fiscal 2016, compared to Fiscal 2015, primarily due to the continued decrease in our project backlog as we continue to see lower demand from our customers in the oil and gas markets.  Domestic revenues decreased 15%, or $69.4 million, to $405.3 million and international revenues decreased 15%, or $27.2 million, to $159.9 million in

[0001564590-16-029924:mdna:13]
Fiscal 2016, compared to Fiscal 2015. These decreases are due to the overall reduction in revenues year over year primarily driven by the decline in backlog resulting from lower demand from our customers in the oil and gas markets. Revenues from commercial and industrial customers decreased 20%, or $105.4 million, to $419.1 million in Fiscal 2016, compared to Fiscal 2015, primarily from lower demand from our customers in the oil and gas markets.  Revenues from public and private utilities increased 20%, or $16.8 million, to $101.9 million in Fiscal 2016, compared to Fiscal 2015.  Revenues from municipal and transit projects decreased 15%, or $8.0 million, to $44.2 million in Fiscal 2016, compared to Fiscal 2015.

[0001564590-16-029924:mdna:14]
Gross profit decreased 2%, or $2.1 million, to $106.2 million in Fiscal 2016, compared to Fiscal 2015.  Gross profit as a percentage of revenues increased to 19% in Fiscal 2016 compared to 16% in Fiscal 2015, primarily due to improvements in our international operations. The improvements in gross profit and gross profit as a percentage of revenues were primarily due to improved efficiencies in project execution at our Canadian operations as the implementation of our project-based integration model has been completed in Canada.  Our Canadian operations have also overcome the operational challenges and cost overruns that occurred in previous years from their expansion and relocation into our new Canadian facility. Additionally, gross profit at our United Kingdom (U.K.) operations improved due to project execution.  The increase in gross profit from our international operations was partially offset by a decline in gross profit from our domestic operations as margins were negatively impacted primarily by our reduced volume as a result of weak oil and gas market conditions and cost overruns related to a large U.S.-based transit project.

[0001564590-16-029924:mdna:15]
Selling, General and Administrative Expenses

[0001564590-16-029924:mdna:16]
Selling, general and administrative expenses decreased 2%, or $1.9 million, to $74.9 million in Fiscal 2016, compared to Fiscal 2015. Selling, general and administrative expenses, as a percentage of revenues, increased slightly to 13% in Fiscal 2016 compared to 12% in Fiscal 2015, primarily due to the reduction in revenue year over year and the reduction in personnel as a result of the restructuring efforts discussed below.

[0001564590-16-029924:mdna:17]
Restructuring and Separation Expenses

[0001564590-16-029924:mdna:18]
In Fiscal 2016, we incurred $8.4 million in separation and restructuring costs, compared to $3.4 million in Fiscal 2015.  This increase in Fiscal 2016 was primarily due to separation costs we incurred from our continued efforts to align our workforce with future production requirements, the departure of our former Chief Executive Officer in December 2015, as well as additional costs related to a leased Canadian facility that we exited in the third quarter of Fiscal 2015 and that has now been sublet through the remaining term of the lease.

[0001564590-16-029924:mdna:19]
Other Income

[0001564590-16-029924:mdna:20]
We recorded other income of $2.0 million in Fiscal 2016, compared to $2.4 million in Fiscal 2015.  The $2.0 million in Fiscal 2016 was the amortization of the deferred gain from the amended supply agreement, discussed in Note E of the Notes to Consolidated Financial Statements.  In Fiscal 2015, in addition to the amortization of the gain from the amended supply agreement, we also recorded a $0.4 million death benefit received from our company-owned life insurance policy.

[0001564590-16-029924:mdna:21]
Income Tax Provision

[0001564590-16-029924:mdna:22]
Our provision for income taxes was $2.3 million in Fiscal 2016, compared to $13.6 million in Fiscal 2015.  The effective tax rate for Fiscal 2016 was 13% compared to an effective tax rate of 59% for Fiscal 2015. The effective tax rate for Fiscal 2016 was favorably impacted by $1.4 million due to the lower statutory tax rates in the U.K. and Canada and the relative amounts of income earned in those jurisdictions, as well as the utilization of net operating loss carryforwards of $1.9 million in Canada that are fully reserved with a valuation allowance. Additionally, the effective tax rate for Fiscal 2016 was favorably impacted by a $0.8 million discrete item recorded in the first quarter of Fiscal 2016 related to the retroactive reinstatement of the Research and Development Tax Credit (R&D Tax Credit) for the previously expired period from January 1, 2015 to September 30, 2015. The effective tax rate in Fiscal 2015 was above the combined U.S. federal and state statutory rate as no tax benefit was recorded against Canadian pre-tax losses due to the $9.0 million valuation allowance recorded in Fiscal 2015, partially offset by the resolution of an IRS audit and the retroactive reinstatement of the R&D Tax Credit for the second through fourth quarters of Fiscal 2014 (see Note H of the Notes to Consolidated Financial Statements included elsewhere in this Annual Report).

[0001564590-16-029924:mdna:23]
Net Income

[0001564590-16-029924:mdna:24]
In Fiscal 2016, we recorded net income of $15.5 million, or $1.36 per diluted share, which increased from net income of $9.4 million, or $0.79 per diluted share that we recorded in Fiscal 2015.  This increase in net income was due to the reduction in income tax provision in Fiscal 2016 compared to Fiscal 2015, which was favorably impacted by the income from our Canadian and U.K. operations in Fiscal 2016 and the utilization of net operating loss carryforwards discussed above.

[0001564590-16-029924:mdna:25]
Backlog

[0001564590-16-029924:mdna:26]
Our backlog includes various projects, some of which are petrochemical, oil and gas construction and transportation infrastructure projects which take a number of months to produce. The order backlog at September 30, 2016 was $291.4 million, compared to $441.4 million at September 30, 2015.  New orders placed in Fiscal 2016 totaled $417.5 million, compared to $606.8 million in Fiscal 2015. This decrease in orders was primarily due to lower demand from our customers in the oil and gas markets.

[0001564590-16-029924:mdna:27]
Twelve Months Ended September 30, 2015 Compared to Twelve Months Ended September 30, 2014

[0001564590-16-029924:mdna:28]
Revenue and Gross Profit

[0001564590-16-029924:mdna:29]
Revenues increased 2%, or $14.0 million, to $661.9 million in Fiscal 2015, primarily due to the increase in domestic revenues.  Domestic revenues increased 30%, or $109.6 million, to $474.7 million in Fiscal 2015 primarily due to our production efforts on various large petrochemical projects awarded in Fiscal 2014.  International revenues decreased 34%, or $95.6 million, to $187.2 million in Fiscal 2015 primarily due to the substantial completion of several large projects for both the Canadian market and the U.S. export projects.  Revenues from commercial and industrial customers increased $50.0 million to $524.5 million in Fiscal 2015.  Revenues from public and private utilities decreased $41.9 million to $85.1 million in Fiscal 2015.  Revenues from municipal and transit projects increased $5.9 million to $52.2 million in Fiscal 2015.

[0001564590-16-029924:mdna:30]
Gross profit decreased 14%, or $17.2 million, to $108.3 million in Fiscal 2015.  Gross profit as a percentage of revenues decreased to 16% in Fiscal 2015 compared to 19% in Fiscal 2014.  Our gross profit and gross profit as a percentage of revenues decreased in Fiscal 2015 compared to Fiscal 2014, primarily due to inefficiencies resulting from our production efforts and incremental costs required to maintain our customer’s schedules, as well as the overall mix of project types.

[0001564590-16-029924:mdna:31]
Selling, General and Administrative Expenses

[0001564590-16-029924:mdna:32]
Selling, general and administrative expenses decreased by $11.0 million to $76.8 million in Fiscal 2015 compared to Fiscal 2014. Selling, general and administrative expenses, as a percentage of revenues, decreased to 12% in Fiscal 2015 compared to 14% in Fiscal 2014. These decreases were primarily due to a decrease in performance-based compensation, sales commissions, personnel and administrative costs resulting from reductions in force, reduced bad debt expense and overall cost reduction efforts.

[0001564590-16-029924:mdna:33]
Restructuring and Separation Expenses

[0001564590-16-029924:mdna:34]
In Fiscal 2015, we incurred $3.4 million in restructuring and separation costs. Of this, $2.6 million was from separation and severance costs and the remaining $0.8 million resulted from the exit of a Canadian facility lease and the write-off of associated leasehold improvements.

[0001564590-16-029924:mdna:35]
Other Income

[0001564590-16-029924:mdna:36]
We recorded other income of $2.4 million in Fiscal 2015, of which $2.0 million related to the amortization of the deferred gain from the amended supply agreement, discussed in Note E of the Notes to Consolidated Financial Statements, and $0.4 million was from a death benefit received from our company-owned life insurance policy.  We recorded other income of $1.5 million in Fiscal 2014, which was solely from the amortization of the deferred gain.

[0001564590-16-029924:mdna:37]
Income Tax Provision

[0001564590-16-029924:mdna:38]
Our provision for income taxes was $13.6 million in Fiscal 2015, compared to $11.1 million in Fiscal 2014.  The effective tax rate in Fiscal 2015 was 59% compared to an effective tax rate of 36% for Fiscal 2014.  This increase in effective tax rate in Fiscal 2015 was primarily due to the establishment of a valuation allowance against the Canadian net deferred tax assets, partially offset by the resolution of an IRS audit and the retroactive reinstatement of the Federal Research and Development Tax Credit for the second through fourth quarters of Fiscal 2014 (see Note H of the Notes to Consolidated Financial Statements included elsewhere in this Annual Report).  The effective tax rate for Fiscal 2014 approximated the combined U.S. federal and state statutory rate as the majority of our income was attributable to the U.S.

[0001564590-16-029924:mdna:39]
Income from Continuing Operations

[0001564590-16-029924:mdna:40]
In Fiscal 2015, we recorded income from continuing operations of $9.4 million, or $0.79 per diluted share, compared to $19.6 million, or $1.62 per diluted share in Fiscal 2014. This reduction to net income was primarily due to a valuation allowance recorded against our Canadian deferred tax assets (as discussed above) and higher domestic productions costs caused by inefficiencies resulting from our production efforts and incremental costs to maintain our customers’ scheduling requirements.  These reductions to net income were partially offset by lower selling, general and administrative costs.

[0001564590-16-029924:mdna:41]
Income from Discontinued Operations

[0001564590-16-029924:mdna:42]
In Fiscal 2014, we recorded $9.6 million, or $0.80 per diluted share, of income from discontinued operations which included the gain on the sale. For additional information about this disposition, see Note N of the Notes to Consolidated Financial Statements.

[0001564590-16-029924:mdna:43]
Backlog

[0001564590-16-029924:mdna:44]
Our backlog includes various projects, some of which are petrochemical, oil and gas construction and transportation infrastructure projects which take a number of months to produce. The order backlog at September 30, 2015 was $441.4 million, compared to $507.1 million at September 30, 2014.  New orders placed in Fiscal 2015 totaled $606.8 million, compared to $725.8 million in Fiscal 2014. This decrease in orders was due to reduced capital investments by our customers primarily in oil and gas and petrochemical industries.

[0001564590-16-029924:mdna:45]
Liquidity and Capital Resources

[0001564590-16-029924:mdna:46]
Cash and cash equivalents increased to $97.7 million at September 30, 2016, compared to $43.6 million at September 30, 2015.  As of September 30, 2016, current assets exceeded current liabilities by 2.6 times and our total debt-to-capitalization ratio was 0.71%.

[0001564590-16-029924:mdna:47]
We have a $75.0 million revolving credit facility in the U.S., which expires in December 2018.  As of September 30, 2016, there were no amounts borrowed under this line of credit. We also have a $7.6 million revolving credit facility in Canada. At September 30, 2016, there was no balance outstanding under the Canadian revolving credit facility. Total long-term debt obligations, including current maturities, totaled $2.4 million at September 30, 2016, compared to $2.8 million at September 30, 2015. Total letters of credit outstanding were $26.8 million and $21.1 million at September 30, 2016 and 2015, respectively, which reduce our availability under our U.S. credit facility. Amounts available at September 30, 2016 under the U.S. and Canadian revolving credit facilities were $48.3 million and $7.6 million, respectively. For further information regarding our debt, see Notes F and G of the Notes to Consolidated Financial Statements included elsewhere in this Annual Report.

[0001564590-16-029924:mdna:48]
Approximately $30 million of our cash at September 30, 2016 was held outside of the United States for international operations. It is our intention to indefinitely reinvest all current and future foreign earnings internationally in order to ensure sufficient working capital to support and expand these international operations. In the event that we elect to repatriate some or all of the foreign earnings that were previously deemed to be indefinitely reinvested outside the U.S., under current tax laws we would incur additional tax expense upon such repatriation.

[0001564590-16-029924:mdna:49]
We believe that cash available and borrowing capacity under our existing credit facilities should be sufficient to finance future operating activities, capital improvements and debt repayments for the foreseeable future. We continue to monitor the factors that drive our markets and will continue to strive to maintain our leadership and competitive advantage in the markets we serve while aligning our cost structures with market conditions.

[0001564590-16-029924:mdna:50]
Operating Activities

[0001564590-16-029924:mdna:51]
During Fiscal 2016, net cash provided by operating activities was $74.9 million.  During Fiscal 2015, net cash provided by operating activities was $12.9 million and in Fiscal 2014, net cash provided by operating activities was $9.1 million.  Cash flow from operations is primarily influenced by the timing of milestone payments from our customers and the payment terms with our suppliers, and is favorably impacted during a down cycle as project milestones are billed and collected as projects are completed.   During Fiscal 2016, our cash provided by operations increased over Fiscal 2015 primarily due to our ability to reduce working capital as projects were completed and payments on contracts were received.  In Fiscal 2014, we received the $10.0 million payment related to the amended supply agreement discussed in Note E of the Notes to Consolidated Financial Statements included elsewhere in this Annual Report.

[0001564590-16-029924:mdna:52]
Investing Activities

[0001564590-16-029924:mdna:53]
Purchases of property, plant and equipment during Fiscal 2016 totaled $3.0 million compared to $34.7 million and $16.5 million in Fiscal 2015 and 2014, respectively.  This decrease in Fiscal 2016 was due to the completion of the expansion of our Canadian facilities in Fiscal 2015.

[0001564590-16-029924:mdna:54]
Financing Activities

[0001564590-16-029924:mdna:55]
Net cash used in financing activities was $17.4 in Fiscal 2016, $34.9 in Fiscal 2015 and $12.5 million in Fiscal 2014. This reduction was primarily due to the completion of our share repurchase program in December 2015 discussed below.

[0001564590-16-029924:mdna:56]
Share Repurchase Program

[0001564590-16-029924:mdna:57]
On December 17, 2014, our Board of Directors authorized a share repurchase program which allowed us to repurchase up to $25 million of our outstanding stock.  The purchases were made in the open market through Rule 10b5-1 trading plans in accordance with applicable laws, rules and regulations.  The Repurchase Program was funded from cash on hand and cash provided by operating activities.  The Repurchase Program expired on December 31, 2015.  As of December 31, 2015, we had purchased 806,018 shares at an aggregate cost of $25 million under the Repurchase Program. The average purchase price per share from inception of the program until its expiration was $31.02.

[0001564590-16-029924:mdna:58]
Contractual and Other Obligations

[0001564590-16-029924:mdna:59]
At September 30, 2016, our long-term contractual obligations were limited to debt and leases. The table below details our commitments by type of obligation, including interest if applicable, and the period that the payment will become due (in thousands).

[0001564590-16-029924:mdna:60]
| As of September 30, 2016, |  |  |  |  |  |  |  |  |  |  |  |
| Payments Due by Period: |  |  |  |  |  |  |  |  |  |  |  |
|  | Long-Term Debt Obligations |  |  | Operating Lease Obligations |  |  | Total |  |
| Less than 1 year | $ | 420 |  |  | $ | 2,495 |  |  | $ | 2,915 |  |
| 1 to 3 years |  | 829 |  |  |  | 2,657 |  |  |  | 3,486 |  |
| 3 to 5 years |  | 812 |  |  |  | 2,840 |  |  |  | 3,652 |  |
| More than 5 years |  | 400 |  |  |  | 2,485 |  |  |  | 2,885 |  |
| Total long-term contractual obligations | $ | 2,461 |  |  | $ | 10,477 |  |  | $ | 12,938 |  |

[0001564590-16-029924:mdna:61]
As of September 30, 2016, the total unrecognized tax benefit related to uncertain tax positions was $1.0 million. We estimate that none of this will be paid within the next 12 months.  However, we believe that it is reasonably possible that within the next 12 months, the total unrecognized tax benefits will decrease by approximately 65% due to the expiration of certain statutes of limitations or resolution of tax audits.  We are unable to make reasonably reliable estimates regarding the timing of future cash outflows, if any, associated with the remaining unrecognized tax benefits.

[0001564590-16-029924:mdna:62]
Other Commercial Commitments

[0001564590-16-029924:mdna:63]
We are contingently liable for secured and unsecured letters of credit of $30.8 million as of September 30, 2016, of which $26.8 million reduces our borrowing capacity.

[0001564590-16-029924:mdna:64]
The following table reflects potential cash outflows that may result in the event that we are unable to perform under our contracts (in thousands):

[0001564590-16-029924:mdna:65]
| As of September 30, 2016, Payments Due by Period: |  | Letters ofCredit |  |
| Less than 1 year |  | $ | 11,417 |  |
| 1 to 3 years |  |  | 18,362 |  |
| More than 3 years |  |  | 986 |  |
| Total long-term commercial obligations |  | $ | 30,765 |  |

[0001564590-16-029924:mdna:66]
We also had performance and maintenance bonds totaling $233.6 million that were outstanding at September 30, 2016. Performance and maintenance bonds are primarily used to guarantee our contract performance to our customers.

[0001564590-16-029924:mdna:67]
Off-Balance Sheet Arrangements

[0001564590-16-029924:mdna:68]
We had no off-balance sheet arrangements during the periods presented.

[0001564590-16-029924:mdna:69]
Outlook

[0001564590-16-029924:mdna:70]
The markets in which we participate are capital-intensive and cyclical in nature. Cyclicality is predominantly driven by customer demand, global economic conditions and anticipated environmental or regulatory changes which affect the manner in which our customers proceed with capital investments. Our customers analyze various factors including the demand and price for oil, gas and electrical energy, the overall economic and financial environment, governmental budgets, regulatory actions and environmental concerns. These factors influence the release of new capital projects by our customers, which are traditionally awarded in competitive bid situations. Scheduling of projects is matched to customer requirements.  Projects typically take a number of months to produce, and schedules may change during the course of any particular project.

[0001564590-16-029924:mdna:71]
A significant portion of our revenues have historically been from the oil and gas markets.  Unfavorable long-term oil and gas commodity price levels have caused, and may continue to cause, our customers to change their strategies or delay or cancel planned projects.  We believe that sustained lower oil and gas prices from a continued global supply/demand imbalance will continue to negatively impact future orders due to reduced capital spending by our customers.  The reduction in available projects, across the markets we serve, has increased market price pressures during this downward market cycle. This reduction in new business opportunities and increased market price pressures have impacted, and will continue to negatively impact, our backlog, revenues and operating results.  It is difficult to predict how long the current depressed market cycle will continue.

[0001564590-16-029924:mdna:72]
Our operating results have been, and may continue to be, negatively impacted by factors such as the timing of new order awards, customer approval of final engineering and design specifications and delays in customer construction schedules, all of which have and may continue to have, a negative impact on the timing of project execution.  Our operating results also have been, and may continue to be, impacted by the timing and resolution of change orders, project close-out and resolution of potential contract claims, all of which could improve or deteriorate gross margins during the period in which these items are resolved with our customers. These factors may result in periods of underutilization of our resources and facilities and negatively impact our ability to cover our fixed costs.  In 2016, in response to the continued adverse effects of the materially lower oil and gas commodity prices on our results of operations, we took steps to reduce our costs structure, restructure our senior management team and align our salaried and hourly workforce with future production requirements.  However, these efforts may not be sufficient to avoid operating losses in the near-term.

[0001564590-16-029924:mdna:73]
We believe that our strong working capital position, cash available, low debt position and borrowing capacity under our existing credit facilities should be sufficient to finance future operating activities, research and development initiatives, capital improvements and debt repayments for the foreseeable future. We continue to monitor the factors that drive our markets and will continue to strive to maintain our leadership and competitive advantage in the markets we serve while aligning our cost structures with market conditions.

[0001564590-16-029924:mdna:74]
Effects of Inflation

[0001564590-16-029924:mdna:75]
We are subject to inflation, which can cause increases in our costs of raw materials, primarily copper, aluminum and steel. Fixed-price contracts can limit our ability to pass these increases to our customers, thus negatively impacting our earnings. The inflation in commodity prices could potentially impact our operations in future years.

[0001564590-16-029924:mdna:76]
Critical Accounting Policies and Estimates

[0001564590-16-029924:mdna:77]
The preparation of consolidated financial statements in conformity with accounting principles generally accepted in the United States of America requires management to make estimates and assumptions that affect the reported amounts of assets, liabilities, revenues and expenses and the disclosures of contingent assets and liabilities. We base our estimates on historical experience and on various other assumptions that are believed to be reasonable under the circumstances. Actual results may differ from these estimates. We believe the following accounting policies and estimates to be critical in the preparation and reporting of our consolidated financial statements.

[0001564590-16-029924:mdna:78]
Revenue Recognition

[0001564590-16-029924:mdna:79]
Our revenues are primarily generated from the engineering and manufacturing of custom products under long-term contracts that may last from one month to several years, depending on the contract. Revenues from long-term contracts are recognized on the percentage-of-completion method of accounting. Occasionally a contract may require that we segment the project into specific deliverables for revenue recognition. Segmenting a contract may result in different interim rates of profitability for each scope of service than if we had recognized revenue on a combined basis.

[0001564590-16-029924:mdna:80]
Under the percentage-of-completion method of accounting, revenues are recognized as work is performed. The revenue earned to date is calculated by multiplying the total contract price by the percentage of performance to date, which is based on total costs or total labor dollars incurred to date compared to the total estimated costs or total labor dollars estimated at completion. The method used to determine the percentage of completion is typically the cost method, unless the labor method is a more accurate method of measuring the progress of the project. Application of the percentage-of-completion method of accounting requires the use of estimates of costs to be incurred for the performance of the contract. Contract costs include all direct material costs, direct labor costs and those indirect costs related to contract performance, such as indirect labor, supplies, tools, repairs and all costs associated with operation of equipment. The cost estimation process is based upon the professional knowledge and experience of our engineers, project managers and financial professionals. Factors that are considered in estimating the work to be completed and ultimate contract recovery include the availability and productivity of labor, the nature and complexity of the work to be performed, the effect of change orders, the availability of materials, the effect of any delays on our project performance and the recoverability of any claims. Changes in job performance, job conditions, estimated profitability and final contract settlements, including our estimate of liquidated damages, if any, may result in revisions to costs and income, with their effects being recognized in the period in which the revisions are determined. Whenever revisions of estimated contract costs and contract values indicate that the contract costs will exceed estimated revenues, thus creating a loss, a provision for the total estimated loss is recorded in that period.

[0001564590-16-029924:mdna:81]
Revenues associated with maintenance, repair and service contracts are recognized when the services are performed. Expenses related to these types of services are recognized as incurred.

[0001564590-16-029924:mdna:82]
Costs and estimated earnings in excess of billings on uncompleted contracts also include certain costs associated with unapproved change orders. These costs are included when change order approval is probable. Amounts are carried at the lower of cost or net realizable value. Revenue is recognized to the extent of costs incurred when recovery is probable. The amounts recorded involve the use of judgments and estimates; thus, actual recoverable amounts could differ from original assumptions.

[0001564590-16-029924:mdna:83]
Allowance for Doubtful Accounts

[0001564590-16-029924:mdna:84]
We maintain and continually assess the adequacy of an allowance for doubtful accounts representing our estimate for losses resulting from the inability of our customers to pay amounts due to us. This estimated allowance is based on historical experience of uncollected accounts, the level of past due accounts, the overall level of outstanding accounts receivable, information about specific customers with respect to their inability to make payments and expectations of future conditions that could impact the collectability of accounts receivable. However, future changes in our customers’ operating performance and cash flows, or in general economic conditions, could have an impact on their ability to fully pay these amounts, which, among other things, could have a material adverse impact on our operating results.

[0001564590-16-029924:mdna:85]
Impairment of Long-Lived Assets

[0001564590-16-029924:mdna:86]
We review long-lived assets for impairment whenever events or changes in circumstances indicate that the carrying value may not be realizable. If an evaluation is required, the estimated future undiscounted cash flows associated with the asset are compared to the asset’s carrying amount to determine if recording an impairment of such asset is necessary. This requires us to make long-term forecasts of the future revenues and costs related to the assets subject to review. Forecasts require assumptions about demand for our products and future market conditions. Estimating future cash flows requires significant judgment, and our projections may vary from cash flows eventually realized. Future events and unanticipated changes to assumptions could require a provision for impairment in a future period. The effect of any impairment would be reflected in income (loss) from operations in the Consolidated Statements of Operations. In addition, we estimate the useful lives of our long-lived assets and other intangibles and periodically review these estimates to determine whether these lives are appropriate.

[0001564590-16-029924:mdna:87]
Accruals for Contingent Liabilities

[0001564590-16-029924:mdna:88]
From time to time, contingencies such as insurance-related claims, liquidated damages and legal claims arise in the normal course of business. Pursuant to applicable accounting standards, we must evaluate such contingencies to subjectively determine the likelihood that an asset has been impaired or a liability has been incurred at the date of the financial statements, as well as evaluate whether the amount of the loss can be reasonably estimated. If the likelihood is determined to be probable and it can be reasonably estimated, the estimated loss is recorded. The amounts we record for contingent liabilities require judgments regarding the amount of expenses that will ultimately be incurred. We use past experience and history, as well as the specific circumstances surrounding each contingent liability, in evaluating the amount of liability that should be recorded. Actual results could differ from our estimates.

[0001564590-16-029924:mdna:89]
Warranty Costs

[0001564590-16-029924:mdna:90]
We provide for estimated warranty costs with the recognition of revenue based upon historical rates applicable to individual product lines. In addition, specific provisions are made when the costs of such warranties are expected to exceed accruals. Our standard terms and conditions of sale include a warranty for parts and service for the earlier of 18 months from the date of shipment or 12 months from the date of energization, whichever occurs first. Occasionally projects require warranty terms which are longer than our standard terms due to the nature of the project. Extended warranty terms may be negotiated and included in our contracts. We use past experience and historical claims to determine the estimated liability. Actual results could differ from our estimate.

[0001564590-16-029924:mdna:91]
Accounting for Income Taxes

[0001564590-16-029924:mdna:92]
We account for income taxes under the asset and liability method, based on the income tax laws and rates in the countries in which operations are conducted and income is earned. This approach requires the recognition of deferred tax assets and liabilities for the expected future tax consequences of temporary differences between the carrying amounts and the tax basis of assets and liabilities. Developing our provision for income taxes requires significant judgment and expertise in federal, international and state income tax laws, regulations and strategies, including the determination of deferred tax assets and liabilities and, if necessary, any valuation allowances that may be required for deferred tax assets.  In assessing the extent to which net deferred tax assets may be realized, we consider whether it is more-likely-than-not that some portion or all of the net deferred tax assets may not be realized.  The ultimate realization of net deferred tax assets is dependent on the generation of future taxable income during the periods in which those temporary differences become deductible.  Due to the historical Canadian losses, and the losses that we projected at the time of determination, we were required under the more-likely-than-not accounting standard to record a valuation allowance against the Canadian net deferred tax assets because we anticipated that we may not be able to realize the benefits of the net operating loss carryforwards and other deductible differences.  Estimates may change as new events occur, estimates of future taxable income during the carryforward period are reduced or increased, additional information becomes available or operating environments change, which may result in a full or partial reversal of the valuation allowance. We will continue to assess the adequacy of the valuation allowance on a quarterly basis.  Our judgments and tax strategies are subject to audit by various taxing authorities.

[0001564590-16-029924:mdna:93]
The objectives of accounting for income taxes are to recognize the amount of taxes payable or refundable for the current year and deferred tax liabilities and assets for the future tax consequences of events that have been recognized in an entity’s financial statements or tax returns. We recognize the tax benefit from an uncertain tax position only if it is more likely than not that the tax position will be sustained on examination by the taxing authorities, based on the technical merits of the position. The tax benefits recognized in the financial statements from such a position should be measured based on the largest benefit that has a greater than 50% likelihood of being realized upon ultimate settlement. Accounting literature also provides guidance on derecognition of income tax assets and liabilities, classification of current and deferred income tax assets and liabilities, accounting for interest and penalties associated with tax positions, and income tax disclosures. Judgment is required in assessing the future tax consequences of events that have been recognized in our financial statements or tax returns. Variations in the actual outcome of these future tax consequences could materially impact our financial statements.

[0001564590-16-029924:mdna:94]
See Note H of Notes to Consolidated Financial Statements included elsewhere in this Annual Report for disclosures related to the valuation allowance recorded in relation to foreign deferred taxes.

[0001564590-16-029924:mdna:95]
Foreign Currency Translation

[0001564590-16-029924:mdna:96]
The functional currency for our foreign subsidiaries is the local currency in which the entity is located. The financial statements of all subsidiaries with a functional currency other than the U.S. Dollar have been translated into U.S. Dollars. All assets and liabilities of foreign operations are translated into U.S. Dollars using year-end exchange rates, and all revenues and expenses are translated at average rates during the respective period. The U.S. Dollar results that arise from such translation, as well as exchange gains and losses on intercompany balances of a long-term investment nature, are included in the cumulative currency translation adjustments in accumulated other comprehensive income in stockholders’ equity.

[0001564590-16-029924:mdna:97]
New Accounting Standards

[0001564590-16-029924:mdna:98]
From time to time, new accounting pronouncements are issued by the Financial Accounting Standards Board (the FASB), which are adopted by us as of the specified effective date. Unless otherwise discussed, management believes that the impact of recently issued standards, which are not yet effective, will not have a material impact on our consolidated statements upon adoption.

[0001564590-16-029924:mdna:99]
In May 2014, the FASB issued a new standard on revenue recognition that supersedes previously issued revenue recognition guidance.  This standard provides a five-step approach to be applied to all contracts with customers and requires expanded disclosures about the nature, amount, timing and uncertainty of revenue (and the related cash flows) arising from customer contracts, significant judgments and changes in judgments used in applying the revenue model and the assets recognized from costs incurred to obtain or fulfill a

[0001564590-16-029924:mdna:100]
contract.  This guidance is now effective for fiscal years, and interim periods within those years, beginning after December 15, 2017, which would be our fiscal year ending September 30, 2019.  The standard permits the use of either the full retrospective or modified retrospective transition method; therefore, we are evaluating the effect that this new guidance will have on our consolidated financial statements and related disclosures. We have not yet selected a transition method nor have we determined the effect of the standard on our ongoing financial reporting.

[0001564590-16-029924:mdna:101]
In November 2015, the FASB issued an amendment to the topic regarding income taxes which requires an entity to separate deferred income tax liabilities and assets into current and noncurrent amounts in the statement of financial position.  Deferred tax liabilities and assets are classified as current or noncurrent based on the classification of the related asset or liability for financial reporting.  Deferred tax liabilities and assets that are not related to an asset or liability for financial reporting are classified according to the expected reversal date of the temporary difference.  To simplify the presentation of deferred income taxes, the amendments require that deferred income tax liabilities and assets be classified as noncurrent in a classified statement of financial position.  This amendment is effective for annual reporting periods beginning after December 15, 2016, which would be our fiscal year ending September 30, 2018.  We have no plans for early adoption.  The adoption of this guidance is not expected to have a material impact on our consolidated financial position or results of operations.

[0001564590-16-029924:mdna:102]
In February 2016, the FASB issued a new topic on leases which requires lessees to recognize lease assets and lease liabilities on the balance sheet for all leases with terms longer than twelve months.  Leases will be classified as either finance or operating, with classification affecting the pattern of expense recognition in the income statement.  A modified retrospective transition approach is required for lessees for capital and operating leases existing at, or entered into after, the beginning of the earliest comparative period presented in the financial statements, with certain practical expedients available. The new standard is effective for fiscal years beginning after December 15, 2018, including interim periods within those fiscal years. This would be our fiscal year ending September 30, 2020.  We are currently evaluating the impact of our pending adoption of the new standard, but do not expect it to have a material impact on our consolidated financial position or results of operations.

[0001564590-16-029924:mdna:103]
In March 2016, the FASB issued new guidance on stock-based compensation, which includes amendments to existing guidance for employee share-based payment accounting. The amendments require the recognition in the income statement of the income tax effects of vested or settled awards. The amendments also allow for the employer to repurchase more of an employee’s shares for tax withholding purposes and not classify the award as a liability that requires valuation on a mark-to-market basis. In addition, the amendments allow for a policy election to account for forfeitures as they occur rather than on an estimated basis. For public companies, the amendments in this standard are effective for annual periods beginning after December 15, 2016, including interim periods within those annual periods.  This would be our fiscal year ending September 30, 2018.  Early adoption is permitted in any interim or annual period.  We will early adopt in Fiscal 2017, but it will not have a material impact on our consolidated financial position or results of operations.

[0001564590-16-029924:mdna:104]
23
