# POWL notes — 0001564590-16-029924


## us-gaap:SignificantAccountingPoliciesTextBlock

[0001564590-16-029924:notes:1]
B. Summary of Significant Accounting Policies

[0001564590-16-029924:notes:2]
Principles of Consolidation

[0001564590-16-029924:notes:3]
The consolidated financial statements include the accounts of Powell and our wholly owned subsidiaries. All intercompany accounts and transactions have been eliminated in consolidation.

[0001564590-16-029924:notes:4]
Use of Estimates

[0001564590-16-029924:notes:5]
The preparation of financial statements in conformity with accounting principles generally accepted in the United States (U.S. GAAP) requires management to make estimates and assumptions that affect the amounts reported in the consolidated financial statements and accompanying footnotes. The most significant estimates used in our financial statements affect revenue and cost recognition for construction contracts, the allowance for doubtful accounts, provision for excess and obsolete inventory, goodwill and other intangible assets, self-insurance, warranty accruals and income taxes. The amounts recorded for insurance claims, warranties, legal, income taxes and other contingent liabilities require judgments regarding the amount of expenses that will ultimately be incurred. We base our estimates on historical experience and on various other assumptions, as well as the specific circumstances surrounding these contingent liabilities, in evaluating the amount of liability that should be recorded. Additionally, the recognition of deferred tax assets requires estimates related to future income and other assumptions regarding timing and future profitability.  Estimates may change as new events occur, additional information becomes available or operating environments change. Actual results may differ from our estimates.

[0001564590-16-029924:notes:6]
Cash and Cash Equivalents

[0001564590-16-029924:notes:7]
Cash and cash equivalents include cash on hand, deposits with banks and highly liquid investments with original maturities of three months or less.

[0001564590-16-029924:notes:8]
Supplemental Disclosures of Cash Flow Information (in thousands):

[0001564590-16-029924:notes:9]
|  | Year Ended September 30, |
|  | 2016 |  |  | 2015 |  |  | 2014 |  |
| Cash paid (received) during the period for: |  |  |  |  |  |  |  |  |  |  |  |
| Interest, net of interest income | $ | 4 |  |  | $ | 70 |  |  | $ | 149 |  |
| Income taxes, net of refunds |  | (352) |  |  |  | 2,298 |  |  |  | 18,889 |  |
| Non-cash capital expenditures |  | 221 |  |  |  | 147 |  |  |  | 13,527 |  |

[0001564590-16-029924:notes:10]
Fair Value of Financial Instruments

[0001564590-16-029924:notes:11]
Financial instruments include cash, cash equivalents, receivables, deferred compensation, payables and debt obligations. Except as described below, due to the short-term nature of account receivables and account payables, the book value is representative of their fair value. The carrying value of debt approximates fair value as interest rates are indexed to the Federal Funds Rate, the Canadian Prime Rate or the bank’s prime rate.

[0001564590-16-029924:notes:12]
Accounts Receivable

[0001564590-16-029924:notes:13]
Accounts receivable are stated net of allowances for doubtful accounts. We maintain and continually assess the adequacy of the allowance for doubtful accounts representing our estimate for losses resulting from the inability of our customers to pay amounts due to us. This estimated allowance is based on historical experience of uncollected accounts, the level of past due accounts, the overall level of outstanding accounts receivable, information about specific customers with respect to their inability to make payments and expectations of future conditions that could impact the collectability of accounts receivable. Future changes in our customers’ operating performance and cash flows, or in general economic conditions, could have an impact on their ability to fully pay these amounts, which could have a material impact on our operating results. In most cases, receivables are not collateralized. However, we utilize letters of credit to secure payment on projects when possible. At September 30, 2016 and 2015, accounts receivable included retention amounts of $2.7 million and $5.4 million, respectively. Retention amounts are in accordance with applicable provisions of contracts and become due upon completion of contractual requirements. All of the retained amount at September 30, 2016, is expected to be collected in the next fiscal year.

[0001564590-16-029924:notes:14]
Costs and Estimated Earnings in Excess of Billings on Uncompleted Contracts

[0001564590-16-029924:notes:15]
Costs and estimated earnings in excess of billings on uncompleted contracts arise when revenues are recorded on a percentage-of-completion basis but cannot be invoiced under the terms of the contract. Such amounts are invoiced upon completion of contractual milestones.

[0001564590-16-029924:notes:16]
Costs and estimated earnings in excess of billings on uncompleted contracts also include certain costs associated with unapproved change orders. These costs are included when the approval of the change order is probable. Amounts are carried at the lower of cost or net realizable value. Revenue is recognized to the extent of costs incurred when recovery is probable. The amounts recorded involve the use of judgments and estimates; thus, actual recoverable amounts could differ from original assumptions.

[0001564590-16-029924:notes:17]
In accordance with industry practice, assets and liabilities related to costs and estimated earnings in excess of billings on uncompleted contracts, as well as billings in excess of costs and estimated earnings on uncompleted contracts, have been classified as current. The contract cycle for certain long-term contracts may extend beyond one year; thus, collection of amounts related to these contracts may extend beyond one year.

[0001564590-16-029924:notes:18]
Inventories

[0001564590-16-029924:notes:19]
Inventories are stated at the lower of cost or market using weighted-average methods and include the cost of materials, labor and manufacturing overhead. We use estimates in determining the level of reserves required to state inventory at the lower of cost or market. Our estimates are based on market activity levels, production requirements, the physical condition of products and technological innovation. Changes in any of these factors may result in adjustments to the carrying value of inventory.

[0001564590-16-029924:notes:20]
Property, Plant and Equipment

[0001564590-16-029924:notes:21]
Property, plant and equipment are stated at cost and are depreciated using the straight-line method over the estimated useful lives of the assets. Expenditures for repairs and maintenance are charged to expense when incurred. Expenditures for major renewals and improvements, which extend the useful lives of existing equipment, are capitalized and depreciated. Upon retirement or disposition of property, plant and equipment, the cost and related accumulated depreciation are removed from the accounts, and any resulting gain or loss is recognized in the Consolidated Statements of Operations.

[0001564590-16-029924:notes:22]
We review property, plant and equipment for impairment whenever events or changes in circumstances indicate that the carrying value may not be realizable. If an evaluation is required, the estimated future undiscounted cash flows associated with the asset are compared to the asset’s carrying amount to determine if recording an impairment of such asset is necessary. If an impairment is indicated, we record an impairment loss equal to the difference between the carrying value and the fair value of the long-lived asset.  This requires us to make long-term forecasts of the future revenues and the costs related to the assets subject to review. Forecasts require assumptions about demand for our products and future market conditions. Estimating future cash flows requires significant judgment and our projections may vary from cash flows eventually realized. Future events and unanticipated changes to assumptions could require a provision for impairment in a future period. The effect of any impairment would be reflected in income (loss) from operations in the Consolidated Statements of Operations. In addition, we estimate the useful lives of our property, plant and equipment and periodically review these estimates to determine whether these lives are appropriate.

[0001564590-16-029924:notes:23]
Goodwill

[0001564590-16-029924:notes:24]
Goodwill is evaluated for impairment annually, or immediately if conditions indicate that impairment could exist. The evaluation requires a two-step impairment test to identify potential goodwill impairment and measure the amount of a goodwill impairment loss. The first step of the test compares the fair value of a reporting unit with its carrying amount, including goodwill. If the carrying amount of a reporting unit exceeds its fair value, the second step of the goodwill impairment test is performed to measure the amount of the impairment loss. Both steps of the goodwill impairment testing involve significant estimates.

[0001564590-16-029924:notes:25]
Intangible Assets

[0001564590-16-029924:notes:26]
The costs of intangible assets with determinable useful lives are amortized over their estimated useful lives. Intangible assets with determinable lives are reviewed for impairment in a similar method as property, plant and equipment as discussed above.  For additional information regarding our intangible assets, see Note E herein.

[0001564590-16-029924:notes:27]
Income Taxes

[0001564590-16-029924:notes:28]
We account for income taxes under the asset and liability method, based on the income tax laws and rates in the countries in which operations are conducted and income is earned. This approach requires the recognition of deferred tax assets and liabilities for the expected future tax consequences of temporary differences between the carrying amounts and the tax basis of assets and liabilities. Developing our provision for income taxes requires significant judgment and expertise in federal, international and state income tax laws, regulations and strategies, including the determination of deferred tax assets and liabilities and, if necessary, any valuation allowances that may be required for deferred tax assets. In assessing the extent to which net deferred tax assets may be realized, we consider whether it is more-likely-than-not that some portion or all of the net deferred tax assets may not be realized.  The ultimate realization of net deferred tax assets is dependent on the generation of future taxable income during the periods in which those temporary differences become deductible.  Due to the historical Canadian losses, and the losses that we projected at the time of determination, we were required under the more-likely-than-not accounting standard to record a valuation allowance against the Canadian net deferred tax assets because we anticipated that we may not be able to realize the benefits of the net operating loss carryforwards and other deductible differences.  Estimates may change as new events occur, estimates of future taxable income during the carryforward period are reduced or increased, additional information becomes available or operating environments change, which may result in a full or partial reversal of the valuation allowance.  We will continue to assess the adequacy of the valuation allowance on a quarterly basis. Our judgments and tax strategies are subject to audit by various taxing authorities.

[0001564590-16-029924:notes:29]
The objectives of accounting for income taxes are to recognize the amount of taxes payable or refundable for the current year and deferred tax liabilities and assets for the future tax consequences of events that have been recognized in an entity’s financial statements or tax returns. We recognize the tax benefit from an uncertain tax position only if it is more likely than not that the tax position will be sustained on examination by the taxing authorities, based on the technical merits of the position. The tax benefits recognized in the financial statements from such a position should be measured based on the largest benefit that has a greater than 50% likelihood of being realized upon ultimate settlement. Accounting literature also provides guidance on derecognition of income tax assets and liabilities, classification of current and deferred income tax assets and liabilities, accounting for interest and penalties associated with tax positions, and income tax disclosures. Judgment is required in assessing the future tax consequences of events that have been recognized in our financial statements or tax returns. Variations in the actual outcome of these future tax consequences could materially impact our financial statements.

[0001564590-16-029924:notes:30]
Revenue Recognition

[0001564590-16-029924:notes:31]
Our revenues are primarily generated from the engineering and manufacturing of custom products under long-term contracts that may last from one month to several years, depending on the contract. Revenues from long-term contracts are recognized on the percentage-of-completion method of accounting. Occasionally a contract may require that we segment the project into specific deliverables for revenue recognition. Segmenting a contract may result in different interim rates of profitability for each scope of service than if we had recognized revenue on a combined basis.

[0001564590-16-029924:notes:32]
Under the percentage-of-completion method of accounting, revenues are recognized as work is performed. The revenue earned to date is calculated by multiplying the total contract price by the percentage of performance to date, which is based on total costs or total labor dollars incurred to date compared to the total estimated costs or total labor dollars estimated at completion. The method used to determine the percentage of completion is typically the cost method, unless the labor method is a more accurate method of measuring the progress of the project. Application of the percentage-of-completion method of accounting requires the use of estimates of costs to be incurred for the performance of the contract. Contract costs include all direct material costs, direct labor costs and those indirect costs related to contract performance, such as indirect labor, supplies, tools, repairs and all costs associated with operation of equipment. The cost estimation process is based upon the professional knowledge and experience of our engineers, project managers and financial professionals. Factors that are considered in estimating the work to be completed and ultimate contract recovery include the availability and productivity of labor, the nature and complexity of the work to be performed, the effect of change orders, the availability of materials, the effect of any delays on our project performance and the recoverability of any claims. Changes in job performance, job conditions, estimated profitability and final contract settlements, including our estimate of liquidated damages, if any, may result in revisions to costs and income, with their effects being recognized in the period in which the revisions are determined. Whenever revisions of estimated contract costs and contract values indicate that the contract costs will exceed estimated revenues, thus creating a loss, a provision for the total estimated loss is recorded in that period.

[0001564590-16-029924:notes:33]
Revenues associated with maintenance, repair and service contracts are recognized when the services are performed. Expenses related to these types of services are recognized as incurred.

[0001564590-16-029924:notes:34]
Warranty Costs

[0001564590-16-029924:notes:35]
We provide for estimated warranty costs with the recognition of revenue based upon historical rates applicable to individual product lines. In addition, specific provisions are made when the costs of such warranties are expected to exceed accruals. Our standard terms and conditions of sale include a warranty for parts and service for the earlier of 18 months from the date of shipment or 12 months from the date of energization, whichever occurs first.  Occasionally projects require warranty terms that are longer than our standard terms due to the nature of the project. Extended warranty terms may be negotiated and included in our contracts.  We use past experience and historical claims to determine the estimated liability. Actual results could differ from our estimate.

[0001564590-16-029924:notes:36]
Research and Development Expense

[0001564590-16-029924:notes:37]
Research and development activities are directed toward the development of new products and processes as well as improvements in existing products and processes. These costs, which primarily include salaries, contract services and supplies, are expensed as incurred.  Such amounts were $6.7 million, $7.0 million and $7.6 million in Fiscal 2016, 2015 and 2014, respectively.

[0001564590-16-029924:notes:38]
Foreign Currency Translation

[0001564590-16-029924:notes:39]
The functional currency for our foreign subsidiaries is the local currency in which the entity is located. The financial statements of all subsidiaries with a functional currency other than the U.S. Dollar have been translated into U.S. Dollars. All assets and liabilities of foreign operations are translated into U.S. Dollars using year-end exchange rates, and all revenues and expenses are translated at average rates during the respective period. The U.S. Dollar results that arise from such translation, as well as exchange gains and losses on intercompany balances of a long-term investment nature, are included in the cumulative currency translation adjustments in accumulated other comprehensive income in stockholders’ equity.

[0001564590-16-029924:notes:40]
Stock-Based Compensation

[0001564590-16-029924:notes:41]
We measure stock-based compensation cost at the grant date based on the fair value of the award. Compensation expense is recognized over the period during which the recipient is required to provide service in exchange for the awards, typically the vesting period. Excess income tax benefits related to share-based compensation expense that must be recognized directly in equity are considered financing rather than operating cash flow activities.

[0001564590-16-029924:notes:42]
New Accounting Standards

[0001564590-16-029924:notes:43]
From time to time, new accounting pronouncements are issued by the Financial Accounting Standards Board (the FASB), which are adopted by us as of the specified effective date. Unless otherwise discussed, management believes that the impact of recently issued standards, which are not yet effective, will not have a material impact on our consolidated statements upon adoption.

[0001564590-16-029924:notes:44]
In May 2014, the FASB issued a new standard on revenue recognition that supersedes previously issued revenue recognition guidance.  This standard provides a five-step approach to be applied to all contracts with customers and requires expanded disclosures about the nature, amount, timing and uncertainty of revenue (and the related cash flows) arising from customer contracts, significant judgments and changes in judgments used in applying the revenue model and the assets recognized from costs incurred to obtain or fulfill a contract.  This guidance is now effective for fiscal years, and interim periods within those years, beginning after December 15, 2017, which would be our fiscal year ending September 30, 2019.  The standard permits the use of either the full retrospective or modified retrospective transition method; therefore, we are evaluating the effect that this new guidance will have on our consolidated financial statements and related disclosures. We have not yet selected a transition method nor have we determined the effect of the standard on our ongoing financial reporting.

[0001564590-16-029924:notes:45]
In November 2015, the FASB issued an amendment to the topic regarding income taxes which requires an entity to separate deferred income tax liabilities and assets into current and noncurrent amounts in the statement of financial position.  Deferred tax liabilities and assets are classified as current or noncurrent based on the classification of the related asset or liability for financial reporting.  Deferred tax liabilities and assets that are not related to an asset or liability for financial reporting are classified according to the expected reversal date of the temporary difference.  To simplify the presentation of deferred income taxes, the amendments require that deferred income tax liabilities and assets be classified as noncurrent in a classified statement of financial position.  This amendment is effective for annual reporting periods beginning after December 15, 2016, which would be our fiscal year ending September 30, 2018.  We have no plans for early adoption.  The adoption of this guidance is not expected to have a material impact on our consolidated financial position or results of operations.

[0001564590-16-029924:notes:46]
In February 2016, the FASB issued a new topic on leases which requires lessees to recognize lease assets and lease liabilities on the balance sheet for all leases with terms longer than twelve months.  Leases will be classified as either finance or operating, with classification affecting the pattern of expense recognition in the income statement.  A modified retrospective transition approach is required for lessees for capital and operating leases existing at, or entered into after, the beginning of the earliest comparative period presented in the financial statements, with certain practical expedients available. The new standard is effective for fiscal years beginning after December 15, 2018, including interim periods within those fiscal years. This would be our fiscal year ending September 30, 2020.  We are currently evaluating the impact of our pending adoption of the new standard, but do not expect it to have a material impact on our consolidated financial position or results of operations.

[0001564590-16-029924:notes:47]
In March 2016, the FASB issued new guidance on stock-based compensation, which includes amendments to existing guidance for employee share-based payment accounting. The amendments require the recognition in the income statement of the income tax effects of vested or settled awards. The amendments also allow for the employer to repurchase more of an employee’s shares for tax withholding purposes and not classify the award as a liability that requires valuation on a mark-to-market basis. In addition, the amendments allow for a policy election to account for forfeitures as they occur rather than on an estimated basis. For public companies, the amendments in this standard are effective for annual periods beginning after December 15, 2016, including interim periods within those annual periods.  This would be our fiscal year ending September 30, 2018.  Early adoption is permitted in any interim or annual period.  We will early adopt in Fiscal 2017, but it will not have a material impact on our consolidated financial position or results of operations.


## us-gaap:EarningsPerShareTextBlock

[0001564590-16-029924:notes:48]
C. Earnings Per Share

[0001564590-16-029924:notes:49]
We compute basic earnings per share by dividing net income by the weighted average number of common shares outstanding during the period. Diluted earnings per common and potential common share includes the weighted average of additional shares associated with the incremental effect of dilutive restricted stock and restrictive stock units, as prescribed by the FASB guidance on earnings per share.

[0001564590-16-029924:notes:50]
The following table reconciles basic and diluted weighted average shares used in the computation of earnings per share for the years ended September 30, 2016, 2015 and 2014 (in thousands, except per share data):

[0001564590-16-029924:notes:51]
|  | Year Ended September 30, |  |
|  | 2016 |  |  | 2015 |  |  | 2014 |  |
| Numerator: |  |  |  |  |  |  |  |  |  |  |  |
| Income from continuing operations | $ | 15,510 |  |  | $ | 9,439 |  |  | $ | 19,620 |  |
| Income from discontinued operations |  | — |  |  |  | — |  |  |  | 9,604 |  |
| Net income | $ | 15,510 |  |  | $ | 9,439 |  |  | $ | 29,224 |  |
| Denominator: |  |  |  |  |  |  |  |  |  |  |  |
| Weighted average basic shares |  | 11,400 |  |  |  | 11,869 |  |  |  | 12,003 |  |
| Dilutive effect of restricted stock units |  | 31 |  |  |  | 39 |  |  |  | 55 |  |
| Weighted average diluted shares with assumed conversions |  | 11,431 |  |  |  | 11,908 |  |  |  | 12,058 |  |
| Net earnings per share: |  |  |  |  |  |  |  |  |  |  |  |
| Continuing operations | $ | 1.36 |  |  | $ | 0.80 |  |  | $ | 1.63 |  |
| Discontinued operations |  | — |  |  |  | — |  |  |  | 0.80 |  |
| Basic earnings per share | $ | 1.36 |  |  | $ | 0.80 |  |  | $ | 2.43 |  |
| Continuing operations | $ | 1.36 |  |  | $ | 0.79 |  |  | $ | 1.62 |  |
| Discontinued operations |  | — |  |  |  | — |  |  |  | 0.80 |  |
| Diluted earnings per share | $ | 1.36 |  |  | $ | 0.79 |  |  | $ | 2.42 |  |


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0001564590-16-029924:notes:52]
D. Detail of Selected Balance Sheet Accounts

[0001564590-16-029924:notes:53]
Allowance for Doubtful Accounts

[0001564590-16-029924:notes:54]
Activity in our allowance for doubtful accounts consisted of the following (in thousands):

[0001564590-16-029924:notes:55]
|  | September 30, |  |
|  | 2016 |  |  | 2015 |  |
| Balance at beginning of period | $ | 746 |  |  | $ | 1,577 |  |
| Bad debt expense (recovery) |  | 187 |  |  |  | (29 | ) |
| Uncollectible accounts written off, net of recoveries |  | (120 | ) |  |  | (749 | ) |
| Change due to foreign currency translation |  | (2 | ) |  |  | (53 | ) |
| Balance at end of period | $ | 811 |  |  | $ | 746 |  |

[0001564590-16-029924:notes:56]
The components of inventories are summarized below (in thousands):

[0001564590-16-029924:notes:57]
|  | September 30, |  |
|  | 2016 |  |  | 2015 |  |
| Raw materials, parts and subassemblies | $ | 29,639 |  |  | $ | 36,575 |  |
| Work-in-progress |  | 996 |  |  |  | 1,084 |  |
| Provision for excess and obsolete inventory |  | (4,114 | ) |  |  | (4,768 | ) |
| Total inventories | $ | 26,521 |  |  | $ | 32,891 |  |

[0001564590-16-029924:notes:58]
Cost and Estimated Earnings on Uncompleted Contracts

[0001564590-16-029924:notes:59]
The components of costs and estimated earnings and related amounts billed on uncompleted contracts are summarized below (in thousands):

[0001564590-16-029924:notes:60]
|  | September 30, |  |
|  | 2016 |  |  | 2015 |  |
| Costs incurred on uncompleted contracts | $ | 1,088,921 |  |  | $ | 912,237 |  |
| Estimated earnings |  | 350,125 |  |  |  | 271,640 |  |
|  |  | 1,439,046 |  |  |  | 1,183,877 |  |
| Less: Billings to date |  | (1,416,914 | ) |  |  | (1,121,141 | ) |
| Net underbilled position | $ | 22,132 |  |  | $ | 62,736 |  |
| Included in the accompanying balance sheets under the following captions: |  |  |  |  |  |  |  |
| Costs and estimated earnings in excess of billings on uncompleted contracts – underbilled | $ | 66,106 |  |  | $ | 104,793 |  |
| Billings in excess of costs and estimated earnings on uncompleted contracts – overbilled |  | (43,974 | ) |  |  | (42,057 | ) |
| Net underbilled position | $ | 22,132 |  |  | $ | 62,736 |  |

[0001564590-16-029924:notes:61]
Property, plant and equipment are summarized below (in thousands):

[0001564590-16-029924:notes:62]
|  | September 30, |  |  | Range of |
|  | 2016 |  |  | 2015 |  |  | Asset Lives |
| Land | $ | 22,107 |  |  | $ | 22,380 |  |  | — |
| Buildings and improvements |  | 119,512 |  |  |  | 120,983 |  |  | 3 - 39 Years |
| Machinery and equipment |  | 103,268 |  |  |  | 100,306 |  |  | 3 - 15 Years |
| Furniture and fixtures |  | 3,806 |  |  |  | 3,564 |  |  | 3 - 10 Years |
| Construction in process |  | 1,009 |  |  |  | 1,013 |  |  | — |
|  | $ | 249,702 |  |  | $ | 248,246 |  |  |  |
| Less: Accumulated depreciation |  | (104,725 | ) |  |  | (93,652 | ) |  |  |
| Total property, plant and equipment, net | $ | 144,977 |  |  | $ | 154,594 |  |  |  |

[0001564590-16-029924:notes:63]
There were no assets under capital lease as of September 30, 2016 or September 30, 2015.  Depreciation expense from continuing operations, including the depreciation of capital leases when applicable, was $13.0 million, $13.1 million and $11.4 million for fiscal years 2016, 2015, and 2014, respectively.

[0001564590-16-029924:notes:64]
Warranty Accrual

[0001564590-16-029924:notes:65]
Activity in our warranty accrual consisted of the following (in thousands):

[0001564590-16-029924:notes:66]
|  | September 30, |  |
|  | 2016 |  |  | 2015 |  |
| Balance at beginning of period | $ | 4,930 |  |  | $ | 4,557 |  |
| Increase to warranty expense |  | 4,249 |  |  |  | 3,364 |  |
| Deduction for warranty charges |  | (4,464 | ) |  |  | (2,738 | ) |
| Change due to foreign currency translation |  | (76 | ) |  |  | (253 | ) |
| Balance at end of period | $ | 4,639 |  |  | $ | 4,930 |  |


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0001564590-16-029924:notes:67]
E. Goodwill and Intangible Assets

[0001564590-16-029924:notes:68]
Our intangible assets consist of goodwill, which is not being amortized and purchased technology, which is amortized over 6 to 7 years. We evaluate goodwill and intangible assets for impairment annually, or immediately if qualitative conditions indicate that an impairment could exist. No impairment expense has been recorded for the last three fiscal years.

[0001564590-16-029924:notes:69]
Intangible assets balances, subject to amortization, at September 30, 2016 and 2015 consisted of the following (in thousands):

[0001564590-16-029924:notes:70]
|  | September 30, 2016 |  |  | September 30, 2015 |  |
|  | Gross |  |  |  |  |  |  | Net |  |  | Gross |  |  |  |  |  |  | Net |  |
|  | Carrying |  |  | Accumulated |  |  | Carrying |  |  | Carrying |  |  | Accumulated |  |  | Carrying |  |
|  | Value |  |  | Amortization |  |  | Value |  |  | Value |  |  | Amortization |  |  | Value |  |
| Purchased technology | $ | 11,749 |  |  | $ | (10,693 | ) |  | $ | 1,056 |  |  | $ | 11,749 |  |  | $ | (10,359 | ) |  | $ | 1,390 |  |

[0001564590-16-029924:notes:71]
Amortization of intangible assets recorded for the years ended September 30, 2016, 2015 and 2014, was $0.4 million, $0.4 million and $0.8 million, respectively.

[0001564590-16-029924:notes:72]
Estimated amortization expense for each of the five subsequent fiscal years is expected to be (in thousands):

[0001564590-16-029924:notes:73]
| Years Ending September 30, |  | Total |  |
| 2017 |  | $ | 352 |  |
| 2018 |  |  | 352 |  |
| 2019 |  |  | 352 |  |
| 2020 |  |  | ― |  |
| 2021 |  |  | ― |  |

[0001564590-16-029924:notes:74]
On August 7, 2006, we purchased certain assets related to the manufacturing of ANSI medium-voltage switchgear and circuit breaker business from General Electric Company (GE).  In connection with the acquisition, we entered into a 15-year supply agreement with GE pursuant to which GE would purchase from us all of its requirements for ANSI medium-voltage switchgear and circuit breakers and other related equipment and components (the Products).  In connection with the acquisition, we recorded an intangible asset related to this supply agreement.  On December 30, 2013, we and GE amended the supply agreement to allow GE to manufacture similar Products for sale immediately and allow them to begin purchasing Products from other suppliers beginning December 31, 2014.  In return, GE paid us $10 million upon execution of the amended supply agreement and agreed to pay an additional $7 million over three years, subject to certain conditions.  As of September 30, 2016, the remaining balance of $2.3 million is classified as other current assets.  We wrote off the intangible asset related to the original supply agreement and recorded a deferred credit in the amount of $8.1 million at December 31, 2013, the amount by which the total proceeds from GE exceeded the unamortized balance of our intangible asset. We are amortizing this deferred credit over the four-year life of the agreement and have recognized gains in other income of $2.0 million for both the years ended September 30, 2016 and 2015.


## us-gaap:LongTermDebtTextBlock

[0001564590-16-029924:notes:75]
F. Long-Term Debt

[0001564590-16-029924:notes:76]
Long-term debt consisted of the following (in thousands):

[0001564590-16-029924:notes:77]
|  | September 30, |  |
|  | 2016 |  |  | 2015 |  |
| Industrial development revenue bonds | $ | 2,400 |  |  | $ | 2,800 |  |
| Less: current portion |  | (400 | ) |  |  | (400 | ) |
| Total long-term debt | $ | 2,000 |  |  | $ | 2,400 |  |

[0001564590-16-029924:notes:78]
The annual maturities of long-term debt as of September 30, 2016, were as follows (in thousands):

[0001564590-16-029924:notes:79]
| Year Ending September 30, |  | Long‑TermDebtMaturities |  |
| 2017 |  | $ | 400 |  |
| 2018 |  |  | 400 |  |
| 2019 |  |  | 400 |  |
| 2020 |  |  | 400 |  |
| 2021 |  |  | 400 |  |
| Thereafter |  |  | 400 |  |
| Total long-term debt maturities |  | $ | 2,400 |  |

[0001564590-16-029924:notes:80]
U.S. Revolver

[0001564590-16-029924:notes:81]
We have a $75.0 million revolving credit facility (U.S. Revolver) to provide working capital support and letters of credit.

[0001564590-16-029924:notes:82]
The interest rate for amounts outstanding under the U.S. Revolver is a floating rate based upon the higher of the Federal Funds Rate plus 0.5%, the bank’s prime rate, or the Eurocurrency rate plus 1.00%. Once the applicable rate is determined, a margin ranging up to 1.75%, as determined by our consolidated leverage ratio, is added to the applicable rate.

[0001564590-16-029924:notes:83]
The U.S. Revolver provides for the issuance of letters of credit which reduce the amounts that may be borrowed under this revolver. The amount available under the U.S. Revolver was reduced by $26.8 million for our outstanding letters of credit at September 30, 2016.

[0001564590-16-029924:notes:84]
There were no borrowings outstanding under the U.S. Revolver as of September 30, 2016. Amounts available under the U.S. Revolver were $48.2 million at September 30, 2016. The U.S. Revolver expires on December 31, 2018.

[0001564590-16-029924:notes:85]
The U.S. Revolver contains certain restrictive and maintenance-type covenants, such as restrictions on the amount of capital expenditures allowed. It also contains financial covenants defining various financial measures and the levels of these measures with which we must comply, as well as a “material adverse change” clause. A “material adverse change” is defined as a material change in our operations, business, properties, liabilities or condition (financial or otherwise) or a material impairment of our ability to perform our obligations under our credit agreements.

[0001564590-16-029924:notes:86]
The U.S. Revolver is collateralized by a pledge of 100% of the voting capital stock of each of our domestic subsidiaries and 65% of the voting capital stock of each non-domestic subsidiary. The U.S. Revolver provides for customary events of default and carries cross-default provisions with other existing debt agreements. If an event of default (as defined in the U.S. Revolver) occurs and is continuing, on the terms and subject to the conditions set forth in the U.S. Revolver, amounts outstanding under the U.S. Revolver may be accelerated and may become immediately due and payable. As of September 30, 2016, we were in compliance with all of the financial covenants of the U.S. Revolver.

[0001564590-16-029924:notes:87]
Canadian Revolver

[0001564590-16-029924:notes:88]
We have a $7.6 million credit agreement with a major international bank in Canada (the Canadian Revolver) to provide working capital support and letters of credit for our operations in Canada. The Canadian Revolver provides for the issuance of letters of credit which reduce the amounts that may be borrowed under this revolver. There were no outstanding letters of credit at September 30, 2016.  The interest rate for amounts outstanding under the Canadian Revolver is a floating interest rate based upon either the Canadian Prime Rate, or the lender’s Bankers’ Acceptance Rate. Once the applicable rate is determined, a margin of 0.50% to 1.75%, as determined by our consolidated leverage ratio, is added to the applicable rate. The Canadian Revolver expires on March 31, 2018.

[0001564590-16-029924:notes:89]
There were no borrowings outstanding under the Canadian Revolver as of September 30, 2016 and amounts available under the Canadian Revolver were $7.6 million at September 30, 2016.

[0001564590-16-029924:notes:90]
The principal financial covenants are consistent with those described in our U.S. Revolver. The Canadian Revolver contains a “material adverse effect” clause. A “material adverse effect” is defined as a material change in the operations of Powell or Powell Canada Inc. in relation to our financial condition, property, business operations, expected net cash flows, liabilities or capitalization.

[0001564590-16-029924:notes:91]
The Canadian Revolver is secured by the assets of our Canadian operations and provides for customary events of default and carries cross-default provisions with our existing debt agreements. If an event of default (as defined in the Canadian Revolver) occurs and is continuing, per the terms and subject to the conditions set forth in the Canadian Revolver, amounts outstanding under the Canadian Revolver may be accelerated and may become immediately due and payable. As of September 30, 2016, we were in compliance with all of the financial covenants of the Canadian Revolver.

[0001564590-16-029924:notes:92]
Industrial Development Revenue Bonds

[0001564590-16-029924:notes:93]
We borrowed $8.0 million in October 2001 through a loan agreement funded with proceeds from tax-exempt industrial development revenue bonds (Bonds). These Bonds were issued by the Illinois Development Finance Authority and were used for the completion of our Northlake, Illinois facility. Pursuant to the Bond issuance, a reimbursement agreement between us and a major domestic bank required an issuance by the bank of an irrevocable direct-pay letter of credit (Bond LC), as collateral, to the Bonds’ trustee to guarantee payment of the Bonds’ principal and interest when due. The Bond LC is subject to both early termination and extension provisions customary to such agreements, as well as various covenants, for which we were in compliance at September 30, 2016. While the Bonds mature in 2021, the reimbursement agreement requires annual redemptions of $0.4 million that commenced on October 25, 2002. A sinking fund is used for the redemption of the Bonds. The Bonds bear interest at a floating rate determined weekly by the Bonds’ remarketing agent, which was the underwriter for the Bonds and is an affiliate of the bank. This interest rate was 1.02% as of September 30, 2016.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001564590-16-029924:notes:94]
G. Commitments and Contingencies

[0001564590-16-029924:notes:95]
Long-Term Debt

[0001564590-16-029924:notes:96]
See Note F herein for a discussion of our long-term debt.

[0001564590-16-029924:notes:97]
Leases

[0001564590-16-029924:notes:98]
We lease certain offices, facilities and equipment under operating leases expiring at various dates through 2023.

[0001564590-16-029924:notes:99]
At September 30, 2016, the minimum annual rental commitments under leases having terms in excess of one year were as follows (in thousands):

[0001564590-16-029924:notes:100]
| Years Ending September 30, |  | OperatingLeases |  |
| 2017 | $ | 2,495 |  |
| 2018 |  | 1,491 |  |
| 2019 |  | 1,167 |  |
| 2020 |  | 1,470 |  |
| 2021 |  | 1,370 |  |
| Thereafter |  | 2,485 |  |
| Total lease commitments | $ | 10,478 |  |

[0001564590-16-029924:notes:101]
Lease expense for all operating leases was $3.5 million, $4.0 million and $3.9 million for Fiscal 2016, 2015 and 2014, respectively. In Fiscal 2015, we exited one of our previously occupied leased facilities in Acheson, Alberta, Canada.  The lease does not expire until October 2019; however, we have sublet that facility through the remaining term of the lease.  In Fiscal 2014, we also exited one of our previously occupied leased facilities in Edmonton, Alberta, Canada.  This lease does not expire until July 2023; however, we have sublet that facility through July 2019.

[0001564590-16-029924:notes:102]
Letters of Credit and Bonds

[0001564590-16-029924:notes:103]
Certain customers require us to post bank letter of credit guarantees or surety bonds. These guarantees and surety bonds assure that we will perform under the terms of our contract. In the event of default, the counterparty may demand payment from the bank under a letter of credit or performance by the surety under a bond. To date, there have been no significant expenses related to either letters of credit or surety bonds for the periods reported. We were contingently liable for secured and unsecured letters of credit of $26.8 million as of September 30, 2016. We also had performance and maintenance bonds totaling $233.6 million that were outstanding, with additional bonding capacity of $516.4 million available, at September 30, 2016.

[0001564590-16-029924:notes:104]
We have a $9.1 million facility agreement (Facility Agreement) between Powell (UK) Limited and a large international bank. This Facility Agreement provides Powell (UK) Limited the ability to enter into bank guarantees as well as forward exchange contracts and currency options. At September 30, 2016, we had outstanding guarantees totaling $4.1 million under this Facility Agreement and amounts available under this Facility Agreement were $5.0 million.  This facility expired in November 2016. The Facility Agreement provides for financial covenants and customary events of default, and carries cross-default provisions with our U.S. Revolver. If an event of default (as defined in the Facility Agreement) occurs and is continuing, per the terms and subject to the conditions set forth therein, obligations outstanding under the Facility Agreement may be accelerated and may become or be declared immediately due and payable. As of September 30, 2016, we were in compliance with all of the financial covenants of the Facility Agreement.

[0001564590-16-029924:notes:105]
Litigation

[0001564590-16-029924:notes:106]
We are involved in various legal proceedings, claims and other disputes arising from our commercial operations, projects, employees and other matters which, in general, are subject to uncertainties and in which the outcomes are not predictable. Although we can give no assurances about the resolution of pending claims, litigation or other disputes and the effect such outcomes may have on us, management believes that any ultimate liability resulting from the outcome of such proceedings, to the extent not otherwise provided or covered by insurance, will not have a material adverse effect on our consolidated financial position or results of operations or liquidity.

[0001564590-16-029924:notes:107]
Liquidated Damages

[0001564590-16-029924:notes:108]
Certain of our customer contracts have schedule and performance obligation clauses that, if we fail to meet them, could require us to pay liquidated damages.  Each individual contract defines the conditions under which the customer may make a claim against us.  As of September 30, 2016, our exposure to possible liquidated damages is $2.5 million, of which approximately $1.5 million is probable.  Based on our actual or projected failure to meet these various contractual commitments, $1.5 million has been recorded as a reduction to revenue.  We will attempt to obtain change orders, contract extensions or accelerate project completion which may resolve the potential for any unaccrued liquidated damage.  Should we fail to achieve relief on some or all of these contractual obligations, we could be required to pay additional liquidated damages, which could negatively impact our future operating results.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001564590-16-029924:notes:109]
H. Income Taxes

[0001564590-16-029924:notes:110]
The components of the income tax provision were as follows (in thousands):

[0001564590-16-029924:notes:111]
|  | Year Ended September 30, |  |
|  | 2016 |  |  | 2015 |  |  | 2014 |  |
| Current: |  |  |  |  |  |  |  |  |  |  |  |
| Federal | $ | (1,395 | ) |  | $ | 2,638 |  |  | $ | 12,184 |  |
| State |  | 449 |  |  |  | 699 |  |  |  | 2,226 |  |
| Foreign |  | 899 |  |  |  | (306 | ) |  |  | (130 | ) |
|  |  | (47 | ) |  |  | 3,031 |  |  |  | 14,280 |  |
| Deferred: |  |  |  |  |  |  |  |  |  |  |  |
| Federal |  | 1,923 |  |  |  | 3,296 |  |  |  | (1,798 | ) |
| State |  | 47 |  |  |  | 420 |  |  |  | (311 | ) |
| Foreign |  | 360 |  |  |  | 6,805 |  |  |  | (1,103 | ) |
|  |  | 2,330 |  |  |  | 10,521 |  |  |  | (3,212 | ) |
| Total income tax provision | $ | 2,283 |  |  | $ | 13,552 |  |  | $ | 11,068 |  |

[0001564590-16-029924:notes:112]
Income before income taxes was as follows (in thousands):

[0001564590-16-029924:notes:113]
|  | Year Ended September 30, |  |
|  | 2016 |  |  | 2015 |  |  | 2014 |  |
| U.S. | $ | 5,087 |  |  | $ | 33,549 |  |  | $ | 35,131 |  |
| Other than U.S. |  | 12,706 |  |  |  | (10,558 | ) |  |  | (4,443 | ) |
| Income before income taxes | $ | 17,793 |  |  | $ | 22,991 |  |  | $ | 30,688 |  |

[0001564590-16-029924:notes:114]
A reconciliation of the statutory U.S. income tax rate and the effective income tax rate, as computed on earnings before income tax provision in each of the three years presented in the Consolidated Statements of Operations, was as follows:

[0001564590-16-029924:notes:115]
|  | Year Ended September 30, |  |
|  | 2016 |  |  | 2015 |  |  | 2014 |  |
| Statutory rate |  | 35 | % |  |  | 35 | % |  |  | 35 | % |
| State income taxes, net of federal benefit |  | 2 |  |  |  | 3 |  |  |  | 3 |  |
| Research and development credit |  | (8 | ) |  |  | (21 | ) |  |  | — |  |
| Foreign rate differential |  | (8 | ) |  |  | 4 |  |  |  | 1 |  |
| Domestic production activities deduction |  | — |  |  |  | (3 | ) |  |  | (3 | ) |
| Foreign valuation allowance |  | (11 | ) |  |  | 43 |  |  |  | — |  |
| Other |  | 3 |  |  |  | (2 | ) |  |  | — |  |
| Effective rate |  | 13 | % |  |  | 59 | % |  |  | 36 | % |

[0001564590-16-029924:notes:116]
Our provision for income taxes reflects an effective tax rate on pre-tax earnings of 13% in Fiscal 2016 compared to 59% and 36% in Fiscal 2015 and 2014, respectively. The effective tax rate for Fiscal 2016 was favorably impacted by the statutory tax rates in the United Kingdom (U.K.) and Canada and the relative amounts of income earned in those jurisdictions, as well as the utilization of net operating loss carryforwards in Canada that have been fully reserved with a valuation allowance.  Additionally, the effective tax rate for Fiscal 2016 was favorably impacted by a $0.8 million discrete item recorded in the first quarter of Fiscal 2016 related to the retroactive reinstatement of the Research and Development Tax Credit (R&D Tax Credit) for the previously expired period from January 1, 2015 to September 30, 2015.  On December 18, 2015, the “Protecting Americans from Tax Hikes Act of 2015” was enacted which retroactively reinstated and made permanent the R&D Tax Credit. The effective tax rate for Fiscal 2015 was adversely impacted by the establishment of a valuation allowance against our Canadian deferred tax assets during the second quarter of Fiscal 2015.  This was partially offset by the release of a $4.1 million FIN 48 reserve related to the R&D Tax Credit upon closing an IRS audit. We also recorded a $0.6 million discrete item in Fiscal 2015 that was also related to the retroactive reinstatement of the R&D Tax Credit referred to above.  The effective tax rate for Fiscal 2014 approximated the combined U.S. federal and state statutory rate.

[0001564590-16-029924:notes:117]
We have not recorded deferred income taxes on $21.5 million of undistributed earnings of our foreign subsidiaries because of management’s intent to indefinitely reinvest such earnings. Upon distribution of these earnings in the form of dividends or otherwise, we may be subject to U.S. income taxes and foreign withholding taxes. It is not practical, however, to estimate the amount of taxes that may be payable on the eventual remittance of these earnings.

[0001564590-16-029924:notes:118]
We are subject to income tax in the U.S., multiple state jurisdictions and certain international jurisdictions, primarily the U.K. and Canada. We do not consider any state in which we do business to be a major tax jurisdiction. We remain open to examination in the other jurisdictions as follows:  Canada 2011 – 2015, United Kingdom 2014 – 2015 and the United States 2013 and 2015.

[0001564590-16-029924:notes:119]
The net deferred income tax asset was comprised of the following (in thousands):

[0001564590-16-029924:notes:120]
|  | September 30, |  |
|  | 2016 |  |  | 2015 |  |
| Current deferred income taxes: |  |  |  |  |  |  |  |
| Gross assets | $ | 4,384 |  |  | $ | 3,910 |  |
| Gross liabilities |  | (378 | ) |  |  | — |  |
| Net current deferred income tax asset |  | 4,006 |  |  |  | 3,910 |  |
| Noncurrent deferred income taxes: |  |  |  |  |  |  |  |
| Gross assets |  | 16,170 |  |  |  | 5,005 |  |
| Gross liabilities |  | (16,308 | ) |  |  | (2,717 | ) |
| Net noncurrent deferred income tax asset (liability) |  | (138 | ) |  |  | 2,288 |  |
| Net deferred income tax asset | $ | 3,868 |  |  | $ | 6,198 |  |

[0001564590-16-029924:notes:121]
The tax effect of temporary differences between U.S. GAAP accounting and federal income tax accounting creating deferred income tax assets and liabilities was as follows (in thousands):

[0001564590-16-029924:notes:122]
|  | September 30, |  |
|  | 2016 |  |  | 2015 |  |
| Deferred Tax Assets: |  |  |  |  |  |  |  |
| Net operating loss | $ | 10,453 |  |  | $ | 9,877 |  |
| Uniform capitalization and inventory |  | 1,596 |  |  |  | 1,895 |  |
| Deferred compensation |  | 1,853 |  |  |  | 1,848 |  |
| Stock-based compensation |  | 760 |  |  |  | 993 |  |
| Reserve for accrued employee benefits |  | 1,679 |  |  |  | 1,482 |  |
| Warranty accrual |  | 1,388 |  |  |  | 915 |  |
| Goodwill |  | 345 |  |  |  | 398 |  |
| Postretirement benefits liability |  | 503 |  |  |  | — |  |
| Allowance for doubtful accounts |  | 220 |  |  |  | 166 |  |
| Accrued legal |  | 294 |  |  |  | 60 |  |
| Credit carryforwards |  | 1,292 |  |  |  | 1,329 |  |
| Other |  | 171 |  |  |  | 8 |  |
| Deferred tax assets |  | 20,554 |  |  |  | 18,971 |  |
| Deferred Tax Liabilities: |  |  |  |  |  |  |  |
| Depreciation and amortization |  | (8,247 | ) |  |  | (2,705 | ) |
| Other |  | — |  |  |  | (12 | ) |
| Deferred tax liabilities |  | (8,247 | ) |  |  | (2,717 | ) |
| Less: valuation allowance |  | (8,439 | ) |  |  | (10,056 | ) |
| Net deferred tax asset | $ | 3,868 |  |  | $ | 6,198 |  |

[0001564590-16-029924:notes:123]
At September 30, 2016, we had $39 million of gross foreign net operating loss carryforwards, the majority of which are subject to a 20-year carryforward period and will begin to expire in 2031.  During Fiscal 2015, we established a valuation allowance in the amount of $9.3 million against Canadian net deferred tax assets.  In assessing the realizability of net deferred tax assets, we consider whether it is more-likely-than-not that some portion or all of the net deferred tax assets may not be realized.  The ultimate realization of net deferred tax assets is dependent on the generation of future taxable income during the periods in which those temporary differences become deductible. Due to the historical Canadian losses, and the losses that we projected at the time of determination, we were required under the more-likely-than-not accounting standard to record a valuation allowance against the Canadian net deferred tax assets because we anticipated that we may not be able to realize the benefits of the net operating loss carryforwards and other deductible differences.

[0001564590-16-029924:notes:124]
A rollforward of the valuation allowance for the past three years is summarized below:

[0001564590-16-029924:notes:125]
| Balance at September 30, 2013 | $ | 135 |  |  |
| Charged to cost and expenses |  | 80 |  |  |
| Charged to other accounts |  | 688 |  |  |
| Balance at September 30, 2014 | $ | 903 |  |  |
| Charged to cost and expenses |  | 10,048 |  |  |
| Charged to other accounts |  | (895 | ) |  |
| Balance at September 30, 2015 | $ | 10,056 |  |  |
| Charged to cost and expenses |  | (1,934 | ) |  |
| Charged to other accounts |  | 317 |  |  |
| Balance at September 30, 2016 | $ | 8,439 |  |  |

[0001564590-16-029924:notes:126]
A reconciliation of the beginning and ending amount of the unrecognized tax benefits follows (in thousands):

[0001564590-16-029924:notes:127]
|  | Year Ended September 30, |  |
|  | 2016 |  |  | 2015 |  |  | 2014 |  |
| Balance at beginning of period | $ | 784 |  |  | $ | 4,026 |  |  | $ | 3,845 |  |
| Increases related to tax positions taken during the current period |  | 293 |  |  |  | 954 |  |  |  | 225 |  |
| Increases related to tax positions taken during a prior period |  | ― |  |  |  | 2 |  |  |  | 14 |  |
| Decreases related to expiration of statute of limitations |  | (31 | ) |  |  | (49 | ) |  |  | (58 | ) |
| Decreases related to settlement with taxing authorities |  | ― |  |  |  | (4,149 | ) |  |  | — |  |
| Balance at end of period | $ | 1,046 |  |  | $ | 784 |  |  | $ | 4,026 |  |

[0001564590-16-029924:notes:128]
Our continuing policy is to recognize interest and penalties related to income tax matters as tax expense. The amount of interest and penalty expense recorded for the year ended September 30, 2016 was not material.

[0001564590-16-029924:notes:129]
During Fiscal 2013, prior year U.S. federal income tax returns were amended to reflect increased R&D Credits and unrecognized tax benefits related to these refund claims were recorded. These amended returns, along with the refund claims, were subject to an Internal Revenue Service audit which was closed during the second quarter of Fiscal 2015 resulting in a $4.1 million tax benefit.  Due to the expiration of certain federal statutes of limitations, management believes that, within the next 12 months, it is reasonably possible that the unrecognized tax benefits will decrease by approximately 32%.

[0001564590-16-029924:notes:130]
Management believes that an adequate provision has been made for any adjustments that may result from tax examinations. However, the outcome of tax audits cannot be predicted with certainty. If any issues addressed in our tax audits are resolved in a manner not consistent with management’s expectations, we could be required to adjust our provision for income tax in the period such resolution occurs. Although timing of the resolution and/or closure of audits is uncertain, we believe it is probable that our unrecognized tax benefits could decrease by approximately 33% in the next 12 months due to an audit resolution.


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0001564590-16-029924:notes:131]
I. Employee Benefit Plans

[0001564590-16-029924:notes:132]
Retirement Plans

[0001564590-16-029924:notes:133]
We have defined employee contribution plans for substantially all of our U.S. employees (401(k) plan) and our Canadian employees (Registered Retirement Savings Plan). We recognized expenses under these plans primarily related to matching contributions of $3.9 million, $5.9 million and $5.3 million in Fiscal 2016, 2015 and 2014, respectively.

[0001564590-16-029924:notes:134]
Deferred Compensation

[0001564590-16-029924:notes:135]
We offer a non-qualified deferred compensation plan to a select group of management and highly compensated individuals. The plan permits the deferral of up to 50% of a participant’s base salary and/or 100% of a participant’s annual incentive bonus. The deferrals are held in a separate trust, an irrevocable rabbi trust (the Rabbi Trust), which has been established to administer the plan. The Rabbi Trust is intended to be used as a source of funds to match respective funding obligations to participants.  The assets of the trust are subject to the claims of our creditors in the event that we become insolvent. Consequently, the Rabbi Trust qualifies as a grantor trust for income tax purposes. We make periodic payments into company-owned life insurance policies held in this Rabbi Trust to fund the expected obligations arising under this plan. The assets and liabilities of the plan are recorded in other assets and deferred compensation, respectively, in the accompanying Consolidated Balance Sheets. Changes in the deferred compensation balance are recorded to compensation expense and reflected within the selling, general and administrative line in the Consolidated Statements of Operations. The plan is not qualified under Section 401 of the Internal Revenue code. We recorded net compensation expense adjustments of $0.1 million related to this plan in Fiscal 2016. Total assets held by the trustee and deferred compensation liabilities were $5.8 million and $4.4 million, respectively, at September 30, 2016.

[0001564590-16-029924:notes:136]
Certain former executives were provided an executive benefit plan which provides for fixed payments upon normal retirement on or after age 65 and the completion of at least 10 years of continuous employment. The estimated present value of these payments were accrued over the service life of these individuals, and $0.4 million is recorded in deferred compensation related to this executive benefit plan. To assist in funding the deferred compensation liability, we have invested in corporate-owned life insurance policies. The cash surrender value of these policies is presented in other assets and was $4.6 million at September 30, 2016.

[0001564590-16-029924:notes:137]
Retiree Medical Plan

[0001564590-16-029924:notes:138]
We have a plan that extends health benefits to retirees that are also available to active employees under our existing health plans. This plan is unfunded. The plan provides coverage for employees with at least 10 years of service who are age 55 or older but less than 65. The retiree is required to pay the COBRA rate less a subsidy provided by us based on years of service at the time of retirement.  The unfunded liability was $1.4 million and $0.7 million as of September 30, 2016 and 2015, respectively, and our net periodic postretirement benefit expenses have been less than $0.1 million for the last three fiscal years. Due to the immateriality of the costs and liabilities of this plan, no further disclosure is being presented.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001564590-16-029924:notes:139]
J. Stock-Based Compensation

[0001564590-16-029924:notes:140]
We have the following stock-based compensation plans:

[0001564590-16-029924:notes:141]
2014 Equity Incentive Plan

[0001564590-16-029924:notes:142]
In February 2014, our stockholders approved and adopted at the Annual Meeting of Stockholders the 2014 Equity Incentive Plan (the 2014 Plan) which replaced our 2006 Equity Compensation Plan (2006 Plan). Persons eligible to receive awards under the 2014 Plan include our officers and employees. The 2014 Plan authorizes stock options, stock appreciation rights, restricted stock, restricted stock units and performance-based awards, as well as certain other awards.  Restricted stock grants vest equally over their respective vesting period on each anniversary of the grant date and compensation expense is recognized over their respective vesting periods based on the price per share on the grant date.

[0001564590-16-029924:notes:143]
In accordance with the 2014 Plan, the compensation committee has authorized grants of restricted stock units (RSUs) to certain officers and key employees of the company.  The fair value of the RSUs is based on the closing price of our common stock as reported on the NASDAQ Global Market (NASDAQ) on the grant dates.  Typically, these grants vest over a three-year period from their date of issuance.  In February 2016, the Board of Directors voted to modify future RSU awards.  The modification provides that sixty percent of the grant is time-based and vests over a three-year period on each anniversary of the grant date, based on continued employment.  The remaining forty percent of the grant will be earned based on the three-year earnings performance of the Company following the grant date. At September 30, 2016, there were 159,988 RSUs outstanding. The RSUs do not have voting rights but do receive dividend equivalents upon vesting; additionally, the shares of common stock underlying the RSUs are not considered issued and outstanding until vested and common stock is issued.

[0001564590-16-029924:notes:144]
Total RSU activity (number of shares) for the past three years is summarized below:

[0001564590-16-029924:notes:145]
|  | Number of |  |  | Weighted |  |
|  | Restricted |  |  | Average |  |
|  | Stock |  |  | Fair Value |  |
|  | Units |  |  | Per Share |  |
| Outstanding at September 30, 2013 |  | 81,555 |  |  | $ | 38.66 |  |
| Granted |  | 57,200 |  |  |  | 66.15 |  |
| Vested |  | (29,832 | ) |  |  | 44.88 |  |
| Forfeited |  | (2,078 | ) |  |  | 56.34 |  |
| Outstanding at September 30, 2014 |  | 106,845 |  |  | $ | 51.30 |  |
| Granted |  | 89,500 |  |  |  | 41.75 |  |
| Vested |  | (55,431 | ) |  |  | 45.23 |  |
| Forfeited |  | (7,408 | ) |  |  | 43.82 |  |
| Outstanding at September 30, 2015 |  | 133,506 |  |  | $ | 47.83 |  |
| Granted |  | 168,800 |  |  |  | 31.64 |  |
| Vested(1) |  | (116,568 | ) |  |  | 33.10 |  |
| Forfeited |  | (25,750 | ) |  |  | 50.28 |  |
| Outstanding at September 30, 2016 |  | 159,988 |  |  | $ | 43.12 |  |

[0001564590-16-029924:notes:146]
| (1) | Includes the accelerated vesting of 84,043 shares previously issued to our former Chief Executive Officer and other senior managers as part of their separation packages, see Note M. |

[0001564590-16-029924:notes:147]
We have reserved 750,000 shares of common stock for issuance under the 2014 Plan.  In Fiscal 2016, 63,628 shares were issued under the 2014 Plan and the total number of shares of common stock left available was 664,911 shares.

[0001564590-16-029924:notes:148]
2014 Non-Employee Director Equity Incentive Plan

[0001564590-16-029924:notes:149]
In February 2014, our stockholders approved and adopted at the Annual Meeting of Stockholders the 2014 Non-Employee Director Equity Incentive Plan (the 2014 Director Plan).  The total number of shares of common stock reserved under the plan is 150,000 shares. The plan is administered by the Compensation Committee. Eligibility to participate in the plan is limited to those individuals who are members of the Board of the Company and who are not employees of the Company or any affiliate of the Company.

[0001564590-16-029924:notes:150]
Under the terms of the 2014 Director Plan, the maximum number of shares that may be granted during any calendar year to any individual is 12,000 shares. The total number of shares that may be issued for awards to any single participant during a calendar year for other stock-based awards (excluding stock options and SARs) is 4,000 shares. The Compensation Committee has determined that each non-employee director will receive 2,000 restricted shares of the Company’s common stock annually and that the annual grant of restricted shares will vest over a two-year period, of which 50% will vest on each anniversary of the grant date.

[0001564590-16-029924:notes:151]
In February 2016, we issued 16,000 shares of restricted stock to our non-employee directors at a price of $25.63 per share and in April 2016, we also issued 1,000 shares of restricted stock to a non-employee director at a price of $29.38 per share under the 2014 Director Plan. In February 2015, we issued 16,000 restricted shares at a price of $33.37 per share and in September 2015, we issued 1,400 restricted shares at a price of $29.48 per share under the 2014 Director Plan.  The total number of shares of common stock available for future awards under the 2014 Director plan was 101,600 shares as of September 30, 2016.

[0001564590-16-029924:notes:152]
At September 30, 2016 and 2015, there were 26,800 shares and 26,200 shares of unvested restricted stock outstanding. Total compensation expense related to restricted stock grants under all plans was $0.7 million, $1.3 million and $1.3 million for the years ended September 30, 2016, 2015 and 2014, respectively. Total compensation expense related to RSU’s under all plans was $4.2 million, $1.9 million and $2.1 million for the years ended September 30, 2016, 2015 and 2014, respectively.

[0001564590-16-029924:notes:153]
We record the amortization of non-vested restricted stock and restricted stock units as an increase to additional paid-in capital.  As of September 30, 2016 and 2015, amounts not yet recognized related to non-vested stock totaled $2.1 million and $1.9 million, respectively.  As of September 30, 2016, the total weighted average remaining contractual life of our restricted stock and RSU’s is 0.82 years and 1.83 years, respectively.


## us-gaap:FairValueDisclosuresTextBlock

[0001564590-16-029924:notes:154]
K. Fair Value Measurements

[0001564590-16-029924:notes:155]
We measure certain financial assets and liabilities at fair value. Fair value is defined as an “exit price” which represents the amount that would be received to sell an asset or paid to transfer a liability in an orderly transaction between market participants as of the measurement date. As such, fair value is a market-based measurement that should be determined based on assumptions that market participants would use in valuing an asset or liability. The accounting guidance requires the use of valuation techniques to measure fair value that maximize the use of observable inputs and minimize the use of unobservable inputs. As a basis for considering such assumptions and inputs, a fair value hierarchy has been established that identifies and prioritizes three levels of inputs to be used in measuring fair value.

[0001564590-16-029924:notes:156]
The three levels of the fair value hierarchy are as follows:

[0001564590-16-029924:notes:157]
Level 1 — Observable inputs such as quoted prices (unadjusted) in active markets for identical assets or liabilities.

[0001564590-16-029924:notes:158]
Level 2 — Inputs other than the quoted prices in active markets that are observable either directly or indirectly, including: quoted prices for similar assets and liabilities in active markets; quoted prices for identical or similar assets and liabilities in markets that are not active or other inputs that are observable or can be corroborated by observable market data.

[0001564590-16-029924:notes:159]
Level 3 — Unobservable inputs that are supported by little or no market data and require the reporting entity to develop its own assumptions.

[0001564590-16-029924:notes:160]
The following table summarizes the fair value of our assets and liabilities that were accounted for at fair value on a recurring basis as of September 30, 2016 (in thousands):

[0001564590-16-029924:notes:161]
|  | Fair Value Measurements at September 30, 2016 |  |
|  | Quoted Prices in |  |  | Significant Other |  |  | Significant |  |  |  |  |  |
|  | Active Markets for |  |  | Observable |  |  | Unobservable |  |  | Fair Value at |  |
|  | Identical Assets |  |  | Inputs |  |  | Inputs |  |  | September 30, |  |
|  | (Level 1) |  |  | (Level 2) |  |  | (Level 3) |  |  | 2016 |  |
| Assets: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cash equivalents | $ | 435 |  |  | $ | — |  |  | $ | — |  |  | $ | 435 |  |
| Deferred compensation |  | 1,643 |  |  |  | 4,130 |  |  |  | — |  |  |  | 5,773 |  |
| Liabilities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Deferred compensation |  | — |  |  |  | 4,449 |  |  |  | — |  |  |  | 4,449 |  |

[0001564590-16-029924:notes:162]
The following table summarizes the fair value of our assets and liabilities that were accounted for at fair value on a recurring basis as of September 30, 2015 (in thousands):

[0001564590-16-029924:notes:163]
|  | Fair Value Measurements at September 30, 2015 |  |
|  | Quoted Prices in |  |  | Significant Other |  |  | Significant |  |  |  |  |  |
|  | Active Markets for |  |  | Observable |  |  | Unobservable |  |  | Fair Value at |  |
|  | Identical Assets |  |  | Inputs |  |  | Inputs |  |  | September 30, |  |
|  | (Level 1) |  |  | (Level 2) |  |  | (Level 3) |  |  | 2015 |  |
| Assets: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cash equivalents | $ | 434 |  |  | $ | — |  |  | $ | — |  |  | $ | 434 |  |
| Deferred compensation |  | 1,879 |  |  |  | 2,904 |  |  |  | — |  |  |  | 4,783 |  |
| Liabilities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Deferred compensation |  | — |  |  |  | 4,487 |  |  |  | — |  |  |  | 4,487 |  |

[0001564590-16-029924:notes:164]
Cash equivalents, primarily funds held in money market savings instruments, are reported at their current carrying value which approximates fair value due to the short-term nature of these instruments and are included in cash and cash equivalents in our Consolidated Balance Sheets.

[0001564590-16-029924:notes:165]
Fair Value of Other Financial Instruments

[0001564590-16-029924:notes:166]
Fair value guidance requires certain fair value disclosures be presented in both interim and annual reports. The estimated fair value amounts of financial instruments have been determined using available market information and valuation methodologies described below.

[0001564590-16-029924:notes:167]
Deferred Compensation – We hold investments in an irrevocable Rabbi Trust for our deferred compensation plan. These assets include both mutual fund investments and company-owned life insurance policies.  Under the plan, participants designate investment options to serve as the basis for measurement of the notional value of their accounts.  The fair values of the underlying securities of these funds are based on quoted market prices and are categorized as Level I in the fair value measurement hierarchy.  The company-owned life insurance policies are valued at cash surrender value and are therefore categorized as Level 2 in the fair value measurement hierarchy.

[0001564590-16-029924:notes:168]
Industrial Development Revenue Bonds – The fair value of our long-term debt depends primarily on the coupon rate of our industrial development revenue bonds. The carrying value of our long-term debt at September 30, 2016, approximates fair value based on the current coupon rate of the bonds, which is reset weekly. It is classified as a Level 2 input in the fair value measurement hierarchy as there is an active market for the trading of these industrial development revenue bonds.

[0001564590-16-029924:notes:169]
There were no transfers between levels with the fair value measurement hierarchy during Fiscal 2016.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001564590-16-029924:notes:170]
L. Geographic Information

[0001564590-16-029924:notes:171]
Revenues by country represent sales to unaffiliated customers as determined by the ultimate destination of our products and services, summarized for the last three fiscal years by region in the table below (in thousands):

[0001564590-16-029924:notes:172]
|  | Year Ended September 30, |  |
|  | 2016 |  |  | 2015 |  |  | 2014 |  |
| United States | $ | 405,298 |  |  | $ | 474,038 |  |  | $ | 365,085 |  |
| Canada |  | 77,252 |  |  |  | 101,191 |  |  |  | 137,684 |  |
| Middle East and Africa |  | 40,294 |  |  |  | 40,557 |  |  |  | 84,330 |  |
| Europe |  | 26,200 |  |  |  | 23,567 |  |  |  | 34,920 |  |
| Far East |  | 7,895 |  |  |  | 12,026 |  |  |  | 15,127 |  |
| Mexico, Central and South America |  | 8,304 |  |  |  | 10,479 |  |  |  | 10,668 |  |
| Total revenues | $ | 565,243 |  |  | $ | 661,858 |  |  | $ | 647,814 |  |

[0001564590-16-029924:notes:173]
|  | September 30, |  |
|  | 2016 |  |  | 2015 |  |
| Long-lived assets: |  |  |  |  |  |  |  |
| United States | $ | 88,304 |  |  | $ | 95,694 |  |
| Canada |  | 52,292 |  |  |  | 53,879 |  |
| United Kingdom |  | 4,381 |  |  |  | 5,021 |  |
| Total | $ | 144,977 |  |  | $ | 154,594 |  |

[0001564590-16-029924:notes:174]
Long-lived assets by country consist of property, plant and equipment, net of accumulated depreciation and are determined based on the location of the tangible assets.


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0001564590-16-029924:notes:175]
M. Restructuring and Separation Costs

[0001564590-16-029924:notes:176]
In response to challenging conditions primarily in the oil and gas markets, we have taken various actions during Fiscal 2016 to continue to align our workforce with future production requirements.  In Fiscal 2016, we incurred approximately $7.9 million of separation costs, of which $3.8 million were separation costs related to the departure of our former Chief Executive Officer in December 2015.  Additionally in Fiscal 2016, we incurred approximately $0.5 million of restructuring costs related to a Canadian facility that we leased and exited in the third quarter of Fiscal 2015.  Of the $7.9 million in separation costs recorded in Fiscal 2016, $6.8 million has been paid and the remaining $1.1 million will be paid over the next fiscal year.

[0001564590-16-029924:notes:177]
In Fiscal 2015, we incurred $3.4 million of restructuring and separation costs.  Of this, $2.6 million were separation and severance costs associated with headcount reductions in Canada and certain U.S. operations, as well as the departure of our former Chief Operating Officer.  The remaining $0.8 million was related to the exit of one of our previously occupied leased facilities in Acheson, Alberta, Canada and the write-off of associated leasehold improvements.  The lease does not expire until October 2019; however, we have sublet the facility through the remaining term of the lease.


## us-gaap:DisposalGroupsIncludingDiscontinuedOperationsDisclosureTextBlock

[0001564590-16-029924:notes:178]
N. Discontinued Operations

[0001564590-16-029924:notes:179]
On January 15, 2014, we sold our wholly owned subsidiary Transdyn to a global provider of electronic toll collection systems, headquartered in Vienna, Austria.  The purchase price from the sale of this subsidiary totaled $16.0 million, of which we received cash of $14.4 million.  The remaining $1.6 million was placed into an escrow account and was released to us in July 2015.  We received additional cash of $0.4 million after the final working capital adjustment was calculated in March 2014. We recorded a gain on this transaction of $8.6 million, net of tax, which has been included in income from discontinued operations in Fiscal 2014 in the accompanying consolidated statements of operations.  Transdyn’s results were previously reflected in the Process Control Systems business segment.

[0001564590-16-029924:notes:180]
We have presented the results of these operations as income from discontinued operations, net of tax, in the Fiscal 2014 consolidated statement of operations.

[0001564590-16-029924:notes:181]
Summary comparative financial results of discontinued operations were as follows (in thousands):

[0001564590-16-029924:notes:182]
|  | Year Ended September 30, |  |
|  | 2016 |  |  | 2015 |  |  | 2014 |  |
| Revenues | $ | — |  |  | $ | — |  |  | $ | 13,923 |  |
| Income from discontinued operations, net of tax of $633 | $ | — |  |  | $ | — |  |  | $ | 1,041 |  |
| Gain on sale of discontinued operations, net of tax of $5,218 |  | — |  |  |  | — |  |  |  | 8,563 |  |
| Net income from discontinued operations, net of tax | $ | — |  |  | $ | — |  |  | $ | 9,604 |  |
| Earnings per share information: |  |  |  |  |  |  |  |  |  |  |  |
| Basic | $ | — |  |  | $ | — |  |  | $ | 0.80 |  |
| Diluted | $ | — |  |  | $ | — |  |  | $ | 0.80 |  |


## powl:StockRepurchaseProgramTextBlock

[0001564590-16-029924:notes:183]
O. Share Repurchase Program

[0001564590-16-029924:notes:184]
On December 17, 2014, our Board of Directors authorized a share repurchase program (the Repurchase Program) which allowed us to repurchase up to $25 million of our outstanding stock.  The purchases were made from time to time in the open market, through privately negotiated transactions and Rule 10b5-1 trading plans in accordance with applicable laws, rules and regulations.  The Repurchase Program was funded from cash on hand and cash provided by operating activities.  The Repurchase Program expired on December 31, 2015.  As of December 31, 2015, we had purchased 806,018 shares at a cost of $25 million under the Repurchase Program.  The average purchase price per share from inception of the program until its expiration was $31.02.


## us-gaap:QuarterlyFinancialInformationTextBlock

[0001564590-16-029924:notes:185]
P.  Quarterly Information

[0001564590-16-029924:notes:186]
The table below sets forth the unaudited consolidated operating results by fiscal quarter for the years ended September 30, 2016 and 2015 (in thousands, except per share data):

[0001564590-16-029924:notes:187]
|  | 2016 Quarters |  |
|  | First |  |  | Second |  |  | Third |  |  | Fourth |  |  | 2016 |  |
| Revenues | $ | 149,977 |  |  | $ | 152,266 |  |  | $ | 133,207 |  |  | $ | 129,793 |  |  | $ | 565,243 |  |
| Gross profit |  | 23,150 |  |  |  | 30,094 |  |  |  | 27,285 |  |  |  | 25,676 |  |  |  | 106,205 |  |
| Net income (loss) |  | (459 | ) |  |  | 5,567 |  |  |  | 4,894 |  |  |  | 5,508 |  |  |  | 15,510 |  |
| Earnings (loss) per share: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic | $ | (0.04 | ) |  | $ | 0.49 |  |  | $ | 0.43 |  |  | $ | 0.48 |  |  | $ | 1.36 |  |
| Diluted | $ | (0.04 | ) |  | $ | 0.49 |  |  | $ | 0.43 |  |  | $ | 0.48 |  |  | $ | 1.36 |  |

[0001564590-16-029924:notes:188]
|  | 2015 Quarters |  |
|  | First |  |  | Second |  |  | Third |  |  | Fourth |  |  | 2015 |  |
| Revenues | $ | 152,601 |  |  | $ | 170,199 |  |  | $ | 176,733 |  |  | $ | 162,325 |  |  | $ | 661,858 |  |
| Gross profit |  | 21,069 |  |  |  | 24,301 |  |  |  | 32,944 |  |  |  | 29,947 |  |  |  | 108,261 |  |
| Net income (loss) |  | (239 | ) |  |  | (3,683 | ) |  |  | 7,049 |  |  |  | 6,312 |  |  |  | 9,439 |  |
| Earnings (loss) per share: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic | $ | (0.02 | ) |  | $ | (0.31 | ) |  | $ | 0.60 |  |  | $ | 0.54 |  |  | $ | 0.80 |  |
| Diluted | $ | (0.02 | ) |  | $ | (0.31 | ) |  | $ | 0.60 |  |  | $ | 0.54 |  |  | $ | 0.79 |  |

[0001564590-16-029924:notes:189]
The sum of the individual earnings per share amounts may not agree with year-to-date earnings per share as each period’s computation is based on the weighted-average number of shares outstanding during the period.
