# POWL note change history — 0001564590-16-017619 → 0001564590-16-022303


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2016-08-03):
[0001564590-16-022303:note_history:1]
Certain customers require us to post bank letter of credit guarantees or surety bonds. These guarantees and surety bonds assure that we will perform under the terms of our contract. In the event of default, the counterparty may demand payment from the bank under a letter of credit or performance by the surety under a bond. To date, there have been no significant expenses related to either letters of credit or surety bonds for the periods reported. We were contingently liable for secured and unsecured letters of credit of $26.8 million as of June 30, 2016. We also had surety bonds totaling $233.0 million that were outstanding, with additional bonding capacity of $517.0 million available, at June 30, 2016.
  (was, 2016-05-04, similarity 0.987):
[0001564590-16-017619:note_history:1]
Certain customers require us to post bank letter of credit guarantees or surety bonds. These guarantees and surety bonds assure that we will perform under the terms of our contract. In the event of default, the counterparty may demand payment from the bank under a letter of credit or performance by the surety under a bond. To date, there have been no significant expenses related to either letters of credit or surety bonds for the periods reported. We were contingently liable for secured and unsecured letters of credit of $24.7 million as of March 31, 2016. We also had surety bonds totaling $298.9 million that were outstanding, with additional bonding capacity of $451.1 million available, at March 31, 2016.

- added (2016-08-03):
[0001564590-16-022303:note_history:2]
We have a $9.4 million facility agreement (Facility Agreement) between Powell (UK) Limited and a large international bank. This Facility Agreement provides Powell (UK) Limited the ability to enter into bank guarantees as well as forward exchange contracts and currency options. At June 30, 2016, we had outstanding guarantees totaling $3.0 million under this Facility Agreement and amounts available under this Facility Agreement were $6.4 million.  This facility expires in November 2016. The Facility Agreement provides for financial covenants and customary events of default, and carries cross-default provisions with our Amended Credit Agreement. If an event of default (as defined in the Facility Agreement) occurs and is continuing, per the terms and subject to the conditions set forth therein, obligations outstanding under the Facility Agreement may be accelerated and may become or be declared immediately due and payable. As of June 30, 2016, we were in compliance with all of the financial covenants of the Facility Agreement.

- changed (2016-08-03):
[0001564590-16-022303:note_history:3]
Certain of our customer contracts have schedule and performance obligation clauses that, if we fail to meet them, could require us to pay liquidated damages.  Each individual contract defines the conditions under which the customer may make a claim against us.  As of June 30, 2016, our exposure to possible liquidated damages was $7.4 million, of which approximately $1.7 million is estimated to be probable.  Based on our actual or projected failure to meet these various contractual commitments, $1.7 million has been recorded as a reduction to revenue.  We will attempt to obtain change orders or contract extensions that may resolve the potential for any unaccrued liquidated damage.  Should we fail to achieve relief on some or all of these contractual obligations, we could be required to pay additional liquidated damages, which could negatively impact our future operating results.
  (was, 2016-05-04, similarity 0.6827):
[0001564590-16-017619:note_history:3]
Certain of our customer contracts have schedule and performance obligation clauses that, if we fail to meet them, could require us to pay liquidated damages.  Each individual contract defines the conditions under which the customer may make a claim against us.  As of March 31, 2016, our exposure to possible liquidated damages was $8.9 million, of which approximately $2.0 million is estimated to be probable.  Based on our actual or projected failure to meet these various contractual commitments, $1.6 million has been recorded as a reduction to revenue.  We believe that we will be successful in obtaining change orders or contract extensions that should resolve the potential for any unaccrued liquidated damages; however, should we fail to achieve relief on some or all of these contractual obligations, we could be required to pay additional liquidated damages which could negatively impact our future operating results.

- removed (2016-08-03):
[0001564590-16-017619:note_history:4]
We have a $14.4 million facility agreement (Facility Agreement) between Powell (UK) Limited and a large international bank. This Facility Agreement provides Powell (UK) the ability to enter into bank guarantees as well as forward exchange contracts and currency options. At March 31, 2016, we had outstanding guarantees totaling $2.8 million under this Facility Agreement and amounts available under this Facility Agreement were $11.6 million.  This facility is renewable in May 2016.

- removed (2016-08-03):
[0001564590-16-017619:note_history:5]
The Facility Agreement provides for financial covenants and customary events of default, and carries cross-default provisions with our Amended Credit Facility. If an event of default (as defined in the Facility Agreement) occurs and is continuing, per the terms and subject to the conditions set forth therein, obligations outstanding under the Facility Agreement may be accelerated and may become or be declared immediately due and payable. As of March 31, 2016, we were in compliance with all of the financial covenants of the Facility Agreement.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureAndSignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2016-08-03):
[0001564590-16-022303:note_history:6]
These unaudited condensed consolidated financial statements have been prepared in accordance with the instructions to Form 10-Q and Rule 10-01 of Regulation S-X for interim financial information.  Certain information and footnote disclosures, normally included in annual financial statements prepared in accordance with accounting principles generally accepted in the United States (U.S. GAAP), have been condensed or omitted pursuant to those rules and regulations. In the opinion of management, all adjustments, consisting only of normal recurring adjustments, necessary to fairly state the financial position, results of operations and cash flows with respect to the interim condensed consolidated financial statements have been included. The results of operations for the interim periods are not necessarily indicative of the results for the entire fiscal year.  We believe that these financial statements contain all adjustments necessary so that they are not misleading. The year-end balance sheet data was derived from audited financial statements, but does not include all disclosures required by U.S. GAAP.
  (was, 2016-05-04, similarity 0.9955):
[0001564590-16-017619:note_history:6]
These unaudited condensed consolidated financial statements have been prepared in accordance with the instructions to Form 10-Q and Rule 10-01 of Regulation S-X for interim financial information.  Certain information and footnote disclosures, normally included in annual financial statements prepared in accordance with accounting principles generally accepted in the United States (U.S. GAAP), have been condensed or omitted pursuant to those rules and regulations. In the opinion of management, all adjustments, consisting only of normal recurring adjustments, necessary to fairly state the financial position, results of operations and cash flows with respect to the interim consolidated financial statements have been included. The results of operations for the interim periods are not necessarily indicative of the results for the entire fiscal year.  We believe that these financial statements contain all adjustments necessary so that they are not misleading. The year-end balance sheet data was derived from audited financial statements, but does not include all disclosures required by U.S. GAAP.

- changed (2016-08-03):
[0001564590-16-022303:note_history:7]
The preparation of condensed consolidated financial statements in conformity with U.S. GAAP requires management to make estimates and assumptions that affect the amounts reported in the condensed consolidated financial statements and accompanying footnotes as of the date they were prepared. The most significant estimates used in our financial statements affect revenue and cost recognition for contracts, allowance for doubtful accounts, provision for excess and obsolete inventory, goodwill and intangible assets, self-insurance, warranty accruals, liquidated damages and income taxes. The amounts recorded in the condensed consolidated financial statements require judgments that could change in future periods and actual amounts may differ from those recorded in the condensed consolidated financial statements. We base our estimates on historical experience and on various other assumptions, as well as the specific circumstances surrounding contingent liabilities, in evaluating the amount of liability that should be recorded. Additionally, the recognition of deferred tax assets, and our determination of whether the value of our long-lived assets has been impaired, requires estimates related to future income and other assumptions regarding timing and future profitability.  Estimates may change as new events occur, additional information becomes available or operating conditions change.
  (was, 2016-05-04, similarity 0.7477):
[0001564590-16-017619:note_history:7]
The preparation of financial statements in conformity with U.S. GAAP requires management to make estimates and assumptions that affect the amounts reported in the consolidated financial statements and accompanying footnotes. The most significant estimates used in our financial statements affect revenue and cost recognition for construction contracts, the allowance for doubtful accounts, provision for excess and obsolete inventory, goodwill and intangible assets, self-insurance, warranty accruals, liquidated damages and income taxes. The amounts recorded for insurance claims, warranties, legal, liquidated damages, income taxes and other contingent liabilities require judgments regarding the amount of expenses that will ultimately be incurred. We base our estimates on historical experience and on various other assumptions, as well as the specific circumstances surrounding these contingent liabilities, in evaluating the amount of liability that should be recorded. Additionally, the recognition of deferred tax assets requires estimates related to future income and other assumptions regarding timing and future profitability.  Estimates may change as new events occur, additional information becomes available or operating environments change. Actual results may differ from our estimates.

- changed (2016-08-03):
[0001564590-16-022303:note_history:8]
In May 2014, the FASB issued a new standard on revenue recognition that supersedes previously issued revenue recognition guidance.  This standard provides a five-step approach to be applied to all contracts with customers and requires expanded disclosures about the nature, amount, timing and uncertainty of revenue (and the related cash flows) arising from customer contracts, significant judgments and changes in judgments used in applying the revenue model and the assets recognized from costs incurred to obtain or fulfill a contract.  This guidance is now effective for fiscal years, and interim periods within those years, beginning after December 15, 2017, which would be our fiscal year ending September 30, 2019.  The standard permits the use of either the retrospective or cumulative effect transition method; therefore, we are evaluating the effect that this new guidance will have on our consolidated financial statements and related disclosures. We have not yet selected a transition method nor have we determined the effect of the standard on our ongoing financial reporting.
  (was, 2016-05-04, similarity 0.9897):
[0001564590-16-017619:note_history:8]
In May 2014, the FASB issued a new standard on revenue recognition that supersedes previously issued revenue recognition guidance.  This standard provides a five-step approach to be applied to all contracts with customers and requires expanded disclosures about the nature, amount, timing and uncertainty of revenue (and the related cash flows) arising from customer contracts, significant judgments and changes in judgments used in applying the revenue model and the assets recognized from costs incurred to obtain or fulfill a contract.  This guidance is now effective for fiscal years, and interim periods within those years, beginning after December 15, 2017, which would be our fiscal year ending September 30, 2019.  The standard permits the use of either the retrospective or cumulative effect transition method therefore we are evaluating the effect that this new guidance will have on our consolidated financial statements and related disclosures. We have not yet selected a transition method nor have we determined the effect of the standard on our ongoing financial reporting.

- changed (2016-08-03):
[0001564590-16-022303:note_history:9]
In February 2016, the FASB issued a new topic on leases which requires lessees to recognize lease assets and lease liabilities on the balance sheet for all leases with terms longer than twelve months.  Leases will be classified as either finance or operating, with classification affecting the pattern of expense recognition in the income statement.  A modified retrospective transition approach is required for lessees for capital and operating leases existing at, or entered into after, the beginning of the earliest comparative period presented in the financial statements, with certain practical expedients available. The new standard is effective for fiscal years beginning after December 15, 2018, including interim periods within those fiscal years. This would be our fiscal year ending September 30, 2020.  We are currently evaluating the impact of our pending adoption of the new standard on our consolidated financial position or results of operations.
  (was, 2016-05-04, similarity 0.978):
[0001564590-16-017619:note_history:9]
In February 2016, the FASB issued a new topic on leases which requires lessees to recognize lease assets and lease liabilities on the balance sheet for all leases with terms longer than twelve months.  Leases will be classified as either finance or operating, with classification affecting the pattern of expense recognition in the income statement.  A modified retrospective transition approach is required for lessees for capital and operating leases existing at, or entered into after, the beginning of the earliest comparative period presented in the financial statements, with certain practical expedients available. The new standard is effective for fiscal years beginning after December 15, 2018, including interim periods within those fiscal years. This would be our fiscal year ending September 30, 2020.  We are currently evaluating the impact of our pending adoption of the new standard on our consolidated financial statements.

- changed (2016-08-03):
[0001564590-16-022303:note_history:10]
In March 2016, the FASB issued new guidance on stock-based compensation. The new guidance simplifies several aspects of the accounting for share-based payment transactions, including the income tax consequences, classification of awards as either equity or liabilities, and classification on the statement of cash flows. For public companies, the amendments in this standard are effective for annual periods beginning after December 15, 2016, including interim periods within those annual periods.  This would be our fiscal year ending September 30, 2018.  The adoption of this guidance is not expected to have a material impact on our consolidated financial position, results of operations or cash flows.
  (was, 2016-05-04, similarity 0.9346):
[0001564590-16-017619:note_history:10]
In March 2016, the FASB issued new guidance on stock-based compensation. The new guidance simplifies several aspects of the accounting for share-based payment transactions, including the income tax consequences, classification of awards as either equity or liabilities, and classification on the statement of cash flows. For public companies, the amendments in this standard are effective for annual periods beginning after December 15, 2016, including interim periods within those annual periods.  This would be our fiscal year ending September 30, 2018.  We have no plans for early adoption. The adoption of this guidance is not expected to have a material impact on our consolidated financial statements.


## us-gaap:LongTermDebtTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2016-08-03):
[0001564590-16-022303:note_history:11]
|  | June 30, 2016 |  |  | September 30, 2015 |  |
| Industrial development revenue bonds | $ | 2,400 |  |  | $ | 2,800 |  |
| Less current portion |  | (400 | ) |  |  | (400 | ) |
| Total long-term debt and capital lease obligations | $ | 2,000 |  |  | $ | 2,400 |  |
  (was, 2016-05-04, similarity 0.98):
[0001564590-16-017619:note_history:11]
|  | March 31, 2016 |  |  | September 30, 2015 |  |
| Industrial development revenue bonds | $ | 2,400 |  |  | $ | 2,800 |  |
| Less current portion |  | (400 | ) |  |  | (400 | ) |
| Total long-term debt and capital lease obligations | $ | 2,000 |  |  | $ | 2,400 |  |

- changed (2016-08-03):
[0001564590-16-022303:note_history:12]
In Fiscal 2015, we entered into the Second Amendment (the Second Amendment) of our existing amended and restated credit agreement (as amended, the Amended Credit Agreement).  The Second Amendment provided for the expansion of our Canadian manufacturing facility and allowed for the repurchase of our common stock pursuant to a share repurchase program announced in December 2014.  The Amended Credit Agreement provides for a $75.0 million revolving credit facility (U.S. Revolver).
  (was, 2016-05-04, similarity 0.666):
[0001564590-16-017619:note_history:12]
In Fiscal 2014, we amended and restated our existing credit agreement (the Amended Credit Agreement) with a major domestic bank. In Fiscal 2015, we entered into the Second Amendment of the Amended Credit Agreement (the Second Amendment).  The Second Amendment provided for the expansion of our Canadian manufacturing facility and allowed for the repurchase of our common stock pursuant to a share repurchase program announced in December 2014.  The Amended Credit Agreement provides for a $75.0 million revolving credit facility (U.S. Revolver). Obligations are collateralized by the stock of certain of our subsidiaries.

- changed (2016-08-03):
[0001564590-16-022303:note_history:13]
The U.S. Revolver provides for the issuance of letters of credit which reduce the amounts that may be borrowed under this revolver. The amount available under the U.S. Revolver was reduced by $26.8 million for our outstanding letters of credit at June 30, 2016.
  (was, 2016-05-04, similarity 0.9822):
[0001564590-16-017619:note_history:13]
The U.S. Revolver provides for the issuance of letters of credit which reduce the amounts that may be borrowed under this revolver. The amount available under the U.S. Revolver was reduced by $24.7 million for our outstanding letters of credit at March 31, 2016.

- changed (2016-08-03):
[0001564590-16-022303:note_history:14]
There were no borrowings outstanding under the U.S. Revolver as of June 30, 2016.  Amounts available under the U.S. Revolver were $48.2 million at June 30, 2016. The U.S. Revolver expires on December 31, 2018.
  (was, 2016-05-04, similarity 0.9521):
[0001564590-16-017619:note_history:14]
There were no borrowings outstanding under the U.S. Revolver as of March 31, 2016.  Amounts available under the U.S. Revolver were $50.3 million at March 31, 2016. The U.S. Revolver expires on December 31, 2018.

- changed (2016-08-03):
[0001564590-16-022303:note_history:15]
The Amended Credit Agreement is collateralized by a pledge of 100% of the voting capital stock of each of our domestic subsidiaries and 65% of the voting capital stock of each non-domestic subsidiary, excluding Powell Canada Inc. The Amended Credit Agreement provides for customary events of default and carries cross-default provisions with other existing debt agreements. If an event of default (as defined in the Amended Credit Agreement) occurs and is continuing, on the terms and subject to the conditions set forth in the Amended Credit Agreement, amounts outstanding under the Amended Credit Agreement may be accelerated and may become immediately due and payable. As of June 30, 2016, we were in compliance with all of the financial covenants of the Amended Credit Agreement.
  (was, 2016-05-04, similarity 0.9916):
[0001564590-16-017619:note_history:15]
The Amended Credit Agreement is collateralized by a pledge of 100% of the voting capital stock of each of our domestic subsidiaries and 65% of the voting capital stock of each non-domestic subsidiary, excluding Powell Canada. The Amended Credit Agreement provides for customary events of default and carries cross-default provisions with other existing debt agreements. If an event of default (as defined in the Amended Credit Agreement) occurs and is continuing, on the terms and subject to the conditions set forth in the Amended Credit Agreement, amounts outstanding under the Amended Credit Agreement may be accelerated and may become immediately due and payable. As of March 31, 2016, we were in compliance with all of the financial covenants of the Amended Credit Agreement.

- changed (2016-08-03):
[0001564590-16-022303:note_history:16]
We have a $7.7 million credit agreement with a major international bank in Canada (the Canadian Revolver) to provide working capital support and letters of credit for our operations in Canada. The Canadian Revolver provides for the issuance of letters of credit which reduce the amounts that may be borrowed under this revolver.  There were no outstanding letters of credit under the Canadian Revolver at June 30, 2016.
  (was, 2016-05-04, similarity 0.989):
[0001564590-16-017619:note_history:16]
We have a $7.7 million credit agreement with a major international bank in Canada (the Canadian Revolver) to provide working capital support and letters of credit for our operations in Canada. The Canadian Revolver provides for the issuance of letters of credit which reduce the amounts that may be borrowed under this revolver.  There were no outstanding letters of credit under the Canadian Revolver at March 31, 2016.

- changed (2016-08-03):
[0001564590-16-022303:note_history:17]
There were no borrowings outstanding under the Canadian Revolver as of June 30, 2016 and amounts available under the Canadian Revolver were $7.7 million at June 30, 2016.  The interest rate for amounts outstanding under the Canadian Revolver is a floating interest rate based upon either the Canadian Prime Rate, or the lender’s Bankers’ Acceptance Rate. Once the applicable rate is determined, a margin of 0.50% to 1.75%, as determined by our consolidated leverage ratio, is added to the applicable rate. The Canadian Revolver expires on March 31, 2018.
  (was, 2016-05-04, similarity 0.983):
[0001564590-16-017619:note_history:17]
There were no borrowings outstanding under the Canadian Revolver as of March 31, 2016 and amounts available under the Canadian Revolver were $7.7 million at March 31, 2016.  The interest rate for amounts outstanding under the Canadian Revolver is a floating interest rate based upon either the Canadian Prime Rate, or the lender’s Bankers’ Acceptance Rate. Once the applicable rate is determined, a margin of 0.50% to 1.75%, as determined by our consolidated leverage ratio, is added to the applicable rate. The Canadian Revolver expires on March 31, 2018.

- changed (2016-08-03):
[0001564590-16-022303:note_history:18]
The principal financial covenants are consistent with those described in our Amended Credit Agreement. The Canadian Revolver contains a “material adverse effect” clause. A “material adverse effect” is defined as a material change in the operations of Powell or Powell Canada Inc. in relation to our financial condition, property, business operations, expected net cash flows, liabilities or capitalization.
  (was, 2016-05-04, similarity 0.9938):
[0001564590-16-017619:note_history:18]
The principal financial covenants are consistent with those described in our Amended Credit Agreement. The Canadian Revolver contains a “material adverse effect” clause. A “material adverse effect” is defined as a material change in the operations of Powell or Powell Canada in relation to our financial condition, property, business operations, expected net cash flows, liabilities or capitalization.

- changed (2016-08-03):
[0001564590-16-022303:note_history:19]
The Canadian Revolver is secured by the assets of our Canadian operations and provides for customary events of default and carries cross-default provisions with our existing debt agreements. If an event of default (as defined in the Canadian Revolver) occurs and is continuing, per the terms and subject to the conditions set forth in the Canadian Revolver, amounts outstanding under the Canadian Revolver may be accelerated and may become immediately due and payable. As of June 30, 2016, we were in compliance with all of the financial covenants of the Canadian Revolver.
  (was, 2016-05-04, similarity 0.9921):
[0001564590-16-017619:note_history:19]
The Canadian Revolver is secured by the assets of our Canadian operations and provides for customary events of default and carries cross-default provisions with our existing debt agreements. If an event of default (as defined in the Canadian Revolver) occurs and is continuing, per the terms and subject to the conditions set forth in the Canadian Revolver, amounts outstanding under the Canadian Revolver may be accelerated and may become immediately due and payable. As of March 31, 2016, we were in compliance with all of the financial covenants of the Canadian Revolver.

- changed (2016-08-03):
[0001564590-16-022303:note_history:20]
We borrowed $8.0 million in October 2001 through a loan agreement funded with proceeds from tax-exempt industrial development revenue bonds (Bonds). These Bonds were issued by the Illinois Development Finance Authority and were used for the completion of our Northlake, Illinois facility. Pursuant to the Bond issuance, a reimbursement agreement between us and a major domestic bank required an issuance by the bank of an irrevocable direct-pay letter of credit (Bond LC), as collateral, to the Bonds’ trustee to guarantee payment of the Bonds’ principal and interest when due. The Bond LC is subject to both early termination and extension provisions customary to such agreements, as well as various covenants, for which we were in compliance at June 30, 2016. While the Bonds mature in 2021, the reimbursement agreement requires annual redemptions of $0.4 million that commenced on October 25, 2002. A sinking fund is used for the redemption of the Bonds. The Bonds bear interest at a floating rate determined weekly by the Bonds’ remarketing agent, which was the underwriter for the Bonds and is an affiliate of the bank. This interest rate was 0.58% as of June 30, 2016.
  (was, 2016-05-04, similarity 0.9921):
[0001564590-16-017619:note_history:20]
We borrowed $8.0 million in October 2001 through a loan agreement funded with proceeds from tax-exempt industrial development revenue bonds (Bonds). These Bonds were issued by the Illinois Development Finance Authority and were used for the completion of our Northlake, Illinois facility. Pursuant to the Bond issuance, a reimbursement agreement between us and a major domestic bank required an issuance by the bank of an irrevocable direct-pay letter of credit (Bond LC), as collateral, to the Bonds’ trustee to guarantee payment of the Bonds’ principal and interest when due. The Bond LC is subject to both early termination and extension provisions customary to such agreements, as well as various covenants, for which we were in compliance at March 31, 2016. While the Bonds mature in 2021, the reimbursement agreement requires annual redemptions of $0.4 million that commenced on October 25, 2002. A sinking fund is used for the redemption of the Bonds. The Bonds bear interest at a floating rate determined weekly by the Bonds’ remarketing agent, which was the underwriter for the Bonds and is an affiliate of the bank. This interest rate was 0.57% as of March 31, 2016.


## us-gaap:ScheduleOfDebtInstrumentsTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2016-08-03):
[0001564590-16-022303:note_history:21]
|  | June 30, 2016 |  |  | September 30, 2015 |  |
| Industrial development revenue bonds | $ | 2,400 |  |  | $ | 2,800 |  |
| Less current portion |  | (400 | ) |  |  | (400 | ) |
| Total long-term debt and capital lease obligations | $ | 2,000 |  |  | $ | 2,400 |  |
  (was, 2016-05-04, similarity 0.98):
[0001564590-16-017619:note_history:21]
|  | March 31, 2016 |  |  | September 30, 2015 |  |
| Industrial development revenue bonds | $ | 2,400 |  |  | $ | 2,800 |  |
| Less current portion |  | (400 | ) |  |  | (400 | ) |
| Total long-term debt and capital lease obligations | $ | 2,000 |  |  | $ | 2,400 |  |
