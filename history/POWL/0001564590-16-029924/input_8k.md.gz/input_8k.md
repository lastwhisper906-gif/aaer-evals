# POWL 8-K — 0001193125-16-787354 filed 2016-12-07

## item codes, every 8-K on or before 2016-12-07

- 2016-12-07 0001193125-16-787354 — 2.02, 9.01
- 2016-11-01 0001193125-16-755475 — 8.01, 9.01
- 2016-09-30 0001193125-16-726999 — 5.02, 8.01, 9.01
- 2016-08-03 0001193125-16-669308 — 2.02, 8.01, 9.01
- 2016-05-04 0001193125-16-576528 — 2.02, 8.01, 9.01
- 2016-02-25 0001193125-16-477896 — 5.07
- 2016-02-03 0001193125-16-449052 — 2.02, 8.01, 9.01
- 2015-12-31 0001193125-15-418363 — 5.02, 7.01, 9.01
- 2015-12-02 0001193125-15-393109 — 2.02, 9.01
- 2015-11-05 0001193125-15-368085 — 8.01, 9.01
- 2015-09-25 0001193125-15-329031 — 5.02
- 2015-08-05 0001193125-15-277912 — 2.02, 8.01, 9.01
- 2015-05-06 0001193125-15-174291 — 2.02, 8.01, 9.01
- 2015-03-06 0001193125-15-081070 — 5.02
- 2015-03-02 0001193125-15-072946 — 5.07
- 2015-02-03 0001193125-15-031772 — 2.02, 8.01, 9.01
- 2014-12-18 0001193125-14-446513 — 8.01, 9.01
- 2014-12-03 0001193125-14-431745 — 2.02, 9.01
- 2014-11-05 0001193125-14-397955 — 8.01, 9.01
- 2014-09-26 0001193125-14-353741 — 7.01, 9.01
- 2014-08-05 0001193125-14-296001 — 2.02, 8.01, 9.01
- 2014-05-07 0001193125-14-187496 — 2.02, 8.01, 9.01
- 2014-03-03 0001193125-14-079843 — 5.02, 5.07
- 2014-02-05 0001193125-14-036633 — 2.02, 8.01, 9.01
- 2014-01-17 0001193125-14-014351 — 1.01, 8.01, 9.01
- 2014-01-06 0001193125-14-002795 — 1.01, 2.03
- 2013-12-06 0001564590-13-001411 — 2.02, 9.01
- 2013-12-05 0001564590-13-001406 — 5.02, 8.01, 9.01
- 2013-11-07 0001193125-13-432950 — 8.01, 9.01
- 2013-08-07 0001193125-13-324337 — 2.02, 9.01
- 2013-05-08 0001193125-13-206800 — 2.02, 9.01
- 2013-02-22 0001193125-13-070971 — 5.02, 5.07
- 2013-02-06 0001193125-13-040556 — 2.02, 9.01
- 2012-12-18 0001193125-12-506417 — 5.02, 9.01
- 2012-12-05 0001193125-12-491749 — 2.02, 9.01
- 2012-10-12 0001193125-12-421889 — 3.03, 5.02, 5.03, 9.01
- 2012-08-09 0001193125-12-344617 — 5.02, 8.01, 9.01
- 2012-08-08 0001193125-12-343630 — 2.02, 9.01
- 2012-05-09 0001193125-12-221356 — 2.02, 9.01
- 2012-02-08 0001193125-12-046560 — 2.02, 9.01
- 2011-12-08 0001193125-11-334810 — 2.02, 9.01
- 2011-11-08 0000950123-11-096524 — 2.02, 2.06, 4.02, 9.01
- 2011-10-14 0000950123-11-090124 — 5.02
- 2011-10-06 0000950123-11-088969 — 5.02
- 2011-09-19 0000950123-11-085224 — 5.02, 9.01
- 2011-09-15 0000950123-11-084806 — 5.02, 9.01
- 2011-08-04 0000950123-11-072788 — 2.02, 9.01
- 2011-07-22 0000950123-11-067402 — 5.07
- 2011-05-24 0000950123-11-053550 — 1.01, 2.03, 9.01
- 2011-05-04 0000950123-11-044561 — 2.02, 9.01
- 2011-02-02 0000950123-11-008188 — 2.02, 9.01
- 2010-12-08 0000950123-10-111987 — 2.02, 9.01
- 2010-08-05 0000950123-10-073114 — 2.02, 9.01
- 2010-05-18 0000950123-10-050900 — 5.02
- 2010-05-05 0000950123-10-044499 — 2.02, 9.01
- 2010-02-03 0000950123-10-008278 — 2.02, 9.01
- 2009-12-21 0000950123-09-072269 — 1.01, 2.01, 2.03, 8.01, 9.01
- 2009-12-09 0000950123-09-069525 — 2.02, 9.01
- 2009-10-27 0000950123-09-053501 — 1.01, 8.01, 9.01
- 2009-08-04 0000950123-09-029476 — 2.02, 9.01
- 2009-05-06 0000950129-09-001498 — 2.02, 9.01
- 2009-03-05 0000950129-09-000749 — 1.01, 9.01
- 2009-02-10 0000950129-09-000349 — 2.02, 9.01
- 2008-12-10 0000950134-08-021934 — 2.02, 9.01
- 2008-08-06 0000950129-08-004267 — 2.02, 9.01
- 2008-07-24 0000950129-08-004063 — 1.01, 5.02, 8.01, 9.01
- 2008-06-16 0000950129-08-003500 — 9.01 — amendment of 0000950134-06-015374
- 2008-06-05 0000950129-08-003378 — 5.02, 9.01
- 2008-05-08 0000950129-08-002843 — 2.02, 9.01
- 2008-02-06 0000950129-08-000533 — 2.02, 9.01
- 2007-12-19 0000950129-07-006277 — 1.01, 2.03, 9.01
- 2007-12-06 0000950129-07-006003 — 2.02, 9.01
- 2007-08-21 0000950129-07-004181 — 2.02, 9.01
- 2007-05-31 0000950129-07-002810 — 2.02, 9.01
- 2007-05-21 0000950129-07-002668 — 2.02, 3.01, 4.02, 9.01
- 2007-04-16 0000950129-07-002002 — 2.02, 4.02, 9.01
- 2007-03-01 0000950129-07-001104 — 5.02, 8.01, 9.01
- 2007-02-08 0000950129-07-000451 — 2.02, 9.01
- 2006-12-08 0000950129-06-010041 — 2.02, 9.01
- 2006-09-08 0000950129-06-008379 — 2.02, 9.01
- 2006-08-09 0000950134-06-015374 — 1.01, 2.01, 8.01, 9.01
- 2006-06-08 0000950129-06-006127 — 2.02, 9.01
- 2006-03-09 0000950129-06-002455 — 2.02, 9.01
- 2005-12-16 0000950129-05-012031 — 2.02, 5.03, 9.01
- 2005-09-13 0000950129-05-009181 — 2.01, 9.01 — amendment of 0000950129-05-006889
- 2005-09-12 0000950129-05-009151 — 2.02, 9.01
- 2005-07-06 0000950129-05-006889 — 1.01, 1.02, 2.01, 2.03, 9.01
- 2005-06-10 0000950129-05-006128 — 2.02, 9.01
- 2005-04-20 0000080420-05-000031 — 5.02
- 2005-03-11 0000080420-05-000024 — 9.01
- 2005-02-25 0000080420-05-000018 — 7.01, 9.01
- 2005-01-21 0000080420-05-000009 — 7.01, 9.01
- 2004-12-17 0000080420-04-000049 — 2.02, 9.01
- 2004-11-01 0000080420-04-000045 — 8.01, 9.01
- 2004-10-08 0001169232-04-005133 — 2.05
- 2004-09-14 0000080420-04-000037 — 5.02
- 2004-09-02 0000080420-04-000030 — 2.02, 9.01
- 2004-06-08 0000080420-04-000021 — 7
- 2004-05-13 0000080420-04-000019 — 4
- 2004-02-27 0000080420-04-000013 — 7
- 2003-12-16 0000950129-03-006136 — 12, 7
- 2003-08-29 0000950129-03-004531 — 12, 7
- 2003-06-03 0000950129-03-003035 — 7, 9
- 2003-05-15 0000950129-03-002812 — 7, 9
- 2002-05-29 0000950129-02-002795 — 4
- 2000-12-21 0000950129-00-006093 — 5, 7
- 1998-09-04 0000950129-98-003802 — 5
- 1996-08-09 0000950129-96-001705 — 2, 7

## late-filing notifications on or before 2016-12-07

- 2007-05-11 0000950129-07-002494 — NT 10-Q, for the period ended 2007-03-31
- 2005-01-18 0000080420-05-000004 — NT 10-K, for the period ended 2004-10-31

## item 2.02 — earnings release, exhibit 99.1

[0001193125-16-787354:8k_2_02:1]
EX-99.1
2
d255451dex991.htm
EX-99.1

[0001193125-16-787354:8k_2_02:2]
EX-99.1

[0001193125-16-787354:8k_2_02:3]
Exhibit 99.1

[0001193125-16-787354:8k_2_02:4]
|  |  | PRESS RELEASE |

[0001193125-16-787354:8k_2_02:5]
|  |  |  |  | Contacts: |  | Don R. Madison, CFO |
|  |  |  |  |  |  | Powell Industries, Inc. |
|  |  |  |  |  |  | 713-947-4422 |

[0001193125-16-787354:8k_2_02:6]
POWELL INDUSTRIES ANNOUNCES

[0001193125-16-787354:8k_2_02:7]
FISCAL 2016 FOURTH QUARTER RESULTS

[0001193125-16-787354:8k_2_02:8]
HOUSTON — DECEMBER 6, 2016 — Powell Industries, Inc. (NASDAQ: POWL), a leading supplier of custom engineered solutions for the management, control
and distribution of electrical energy, today announced results for the fiscal 2016 fourth quarter and year ended September 30, 2016.

[0001193125-16-787354:8k_2_02:9]
Revenues for the fourth quarter of fiscal 2016 were $129.8 million compared to revenues of $162.3 million for the fourth quarter of fiscal
2015. The Company reported net income for the fourth quarter of $5.5 million, or $0.48 per diluted share, compared to net income of $6.3 million, or $0.54 per diluted share, for the fourth quarter of fiscal 2015. Excluding special items, net
income for the fourth quarter of fiscal 2016 was $6.2 million, or $0.54 per diluted share. A reconciliation of this non-GAAP financial measure to net income is included in the financial tables below.

[0001193125-16-787354:8k_2_02:10]
Brett A. Cope, Powell’s President and Chief Executive Officer, stated, “Our fourth quarter results continue to reflect positive
operational trends, driven by both project execution and manufacturing efficiencies. We remain focused on leveraging these internal initiatives across our business to boost operational efficiency, reduce costs, and further improve cycle time.

[0001193125-16-787354:8k_2_02:11]
“Due to the lingering market uncertainty among our customers, Powell’s fourth quarter yet again experienced a softness in order
activity. We ended the year with a backlog of $291 million – our lowest level since 2005. In addition, pricing pressures on new orders remained challenging as competition for projects intensified. During this ongoing period of reduced
capital spending in our key markets, Powell remains committed to investing in product development and will continue to provide innovative solutions to our client base that we believe will further expand Powell’s competitive position.”

[0001193125-16-787354:8k_2_02:12]
New orders placed during the fourth quarter of fiscal 2016 totaled $111 million compared to $88
million in the third quarter of fiscal 2016 and compared to $92 million in the fourth quarter of fiscal 2015. The Company’s backlog as of September 30, 2016 was $291 million compared to $312 million as of June 30, 2016 and compared to
$441 million at the end of last year’s fourth quarter.

[0001193125-16-787354:8k_2_02:13]
FISCAL 2016 RESULTS

[0001193125-16-787354:8k_2_02:14]
Revenues for fiscal 2016 were $565.2 million compared to revenues of $661.9 million for fiscal 2015. Net income for fiscal 2016 was $15.5
million, or $1.36 per diluted share, compared to net income of $9.4 million, or $0.79 per diluted share, in fiscal 2015. Excluding special items, net income for fiscal 2016 was $21.4 million, or $1.87 per diluted share. A reconciliation of
this non-GAAP financial measure to net income is included in the financial tables below.

[0001193125-16-787354:8k_2_02:15]
OUTLOOK

[0001193125-16-787354:8k_2_02:16]
Commenting on the company’s outlook, Don R. Madison, Powell’s Executive Vice President and Chief Financial and Administrative Officer
said, “Powell continues to be adversely affected by uncertain market conditions, and unless these conditions improve significantly, our backlog and current business conditions are not likely to improve over the short-term. Revenue for the first
quarter 2017 is not likely to improve sequentially from the fourth quarter and we expect to report a net loss in fiscal 2017. However, throughout fiscal 2017, we expect to strengthen our balance sheet, generate positive net cash from operating
activities and increase our cash position.”

[0001193125-16-787354:8k_2_02:17]
Due in large part to current uncertainty of order activity, fluctuating revenue trends
and the evolving nature of the Company’s business, including the continuing alignment of our operating costs with market conditions and other initiatives, we are suspending the issuance of annual financial guidance. ”

[0001193125-16-787354:8k_2_02:18]
CONFERENCE CALL

[0001193125-16-787354:8k_2_02:19]
Powell Industries has
scheduled a conference call for Wednesday, December 7, 2016 at 11:00 a.m. Eastern time. To participate in the conference call, dial 412-902-0030 at least 10 minutes before the call begins and ask for the Powell Industries conference call. A
replay of the call will be available approximately two hours after the live broadcast ends and will be accessible until December 14, 2016. To access the replay, dial 201-612-7415 using a passcode of 13650251#.

[0001193125-16-787354:8k_2_02:20]
2

[0001193125-16-787354:8k_2_02:21]
Investors, analysts and the general public will also have the opportunity to listen to the
conference call over the Internet by visiting powellind.com. To listen to the live call on the web, please visit the website at least fifteen minutes before the call begins to register, download and install any necessary audio software. For
those who cannot listen to the live webcast, an archive will be available shortly after the call and will remain available for approximately 90 days at powellind.com.

[0001193125-16-787354:8k_2_02:22]
Powell Industries, Inc., headquartered in Houston, designs, manufactures and services custom-engineered equipment and systems for the
distribution, control and monitoring of electrical energy. Powell markets include large industrial customers such as utilities, oil and gas producers, refineries, petrochemical plants, pulp and paper producers, mining operations and commuter
railways. For more information, please visit powellind.com.

[0001193125-16-787354:8k_2_02:23]
This press release contains references to certain non-GAAP financial measures discussed above. Please see the financial table
below for more details on these non-GAAP financial measures, including a reconciliation of these non-GAAP financial measures to net income and the reasons management believes these measures are useful to investors.

[0001193125-16-787354:8k_2_02:24]
3

[0001193125-16-787354:8k_2_02:25]
POWELL INDUSTRIES, INC. & SUBSIDIARIES

[0001193125-16-787354:8k_2_02:26]
CONDENSED CONSOLIDATED STATEMENT OF OPERATIONS

[0001193125-16-787354:8k_2_02:27]
|  |  | Three months endedSeptember 30, |  |  | Year endedSeptember 30, |  |
|  |  | 2016 |  |  | 2015 |  |  | 2016 |  |  | 2015 |  |
| (In thousands, except per share data) |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | (Unaudited) |  |
| Revenues |  | $ | 129,793 |  |  | $ | 162,325 |  |  | $ | 565,243 |  |  | $ | 661,858 |  |
| Cost of goods sold |  |  | 104,117 |  |  |  | 132,378 |  |  |  | 459,038 |  |  |  | 553,597 |  |
| Gross profit |  |  | 25,676 |  |  |  | 29,947 |  |  |  | 106,205 |  |  |  | 108,261 |  |
| Selling, general and administrative expenses |  |  | 17,138 |  |  |  | 18,508 |  |  |  | 74,924 |  |  |  | 76,801 |  |
| Research and development expenses |  |  | 1,278 |  |  |  | 1,872 |  |  |  | 6,731 |  |  |  | 6,980 |  |
| Amortization of intangible assets |  |  | 89 |  |  |  | 90 |  |  |  | 352 |  |  |  | 435 |  |
| Restructuring and separation expenses |  |  | 738 |  |  |  | 659 |  |  |  | 8,441 |  |  |  | 3,397 |  |
| Operating income |  |  | 6,433 |  |  |  | 8,818 |  |  |  | 15,757 |  |  |  | 20,648 |  |
| Other income |  |  | (508 | ) |  |  | (509 | ) |  |  | (2,029 | ) |  |  | (2,402 | ) |
| Interest expense |  |  | 37 |  |  |  | 34 |  |  |  | 149 |  |  |  | 145 |  |
| Interest income |  |  | (43 | ) |  |  | 2 |  |  |  | (156 | ) |  |  | (86 | ) |
| Income before income taxes |  |  | 6,947 |  |  |  | 9,291 |  |  |  | 17,793 |  |  |  | 22,991 |  |
| Income tax provision (benefit) |  |  | 1,439 |  |  |  | 2,979 |  |  |  | 2,283 |  |  |  | 13,552 |  |
| Net income |  | $ | 5,508 |  |  | $ | 6,312 |  |  | $ | 15,510 |  |  | $ | 9,439 |  |
| Earnings per share: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  | $ | 0.48 |  |  | $ | 0.54 |  |  | $ | 1.36 |  |  | $ | 0.80 |  |
| Diluted |  | $ | 0.48 |  |  | $ | 0.54 |  |  | $ | 1.36 |  |  | $ | 0.79 |  |
| Weighted average shares: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  |  | 11,413 |  |  |  | 11,619 |  |  |  | 11,400 |  |  |  | 11,869 |  |
| Diluted |  |  | 11,463 |  |  |  | 11,669 |  |  |  | 11,431 |  |  |  | 11,908 |  |
| SELECTED FINANCIAL DATA: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Depreciation and Amortization |  | $ | 3,267 |  |  | $ | 3,316 |  |  | $ | 13,331 |  |  | $ | 13,555 |  |
| Capital Expenditures |  | $ | 1,044 |  |  | $ | 473 |  |  | $ | 3,044 |  |  | $ | 34,719 |  |
| Dividends Paid |  | $ | 2,963 |  |  | $ | 3,032 |  |  | $ | 11,845 |  |  | $ | 12,358 |  |

[0001193125-16-787354:8k_2_02:28]
POWELL INDUSTRIES, INC. & SUBSIDIARIES

[0001193125-16-787354:8k_2_02:29]
CONDENSED CONSOLIDATED BALANCE SHEETS

[0001193125-16-787354:8k_2_02:30]
|  |  | September 30, |  |  | September 30, |  |
|  |  | 2016 |  |  | 2015 |  |
| (In thousands) |  | (Unaudited) |  |
| Assets: |  |  |  |  |  |  |  |  |
| Cash and cash equivalents |  | $ | 97,720 |  |  | $ | 43,569 |  |
| Other current assets |  |  | 206,420 |  |  |  | 253,530 |  |
| Property, plant and equipment (net) |  |  | 144,977 |  |  |  | 154,594 |  |
| Long-term assets |  |  | 13,399 |  |  |  | 17,131 |  |
| Total assets |  | $ | 462,516 |  |  | $ | 468,824 |  |
| Liabilities & equity: |  |  |  |  |  |  |  |  |
| Current liabilities |  | $ | 118,248 |  |  | $ | 124,952 |  |
| Long-term debt, net of current maturities |  |  | 2,000 |  |  |  | 2,400 |  |
| Deferred and other long-term liabilities |  |  | 6,951 |  |  |  | 8,210 |  |
| Stockholders’ equity |  |  | 335,317 |  |  |  | 333,262 |  |
| Total liabilities and stockholders’ equity |  | $ | 462,516 |  |  | $ | 468,824 |  |
| SELECTED FINANCIAL DATA: |  |  |  |  |  |  |  |  |
| Working capital |  | $ | 185,892 |  |  | $ | 172,147 |  |

[0001193125-16-787354:8k_2_02:31]
5

[0001193125-16-787354:8k_2_02:32]
POWELL INDUSTRIES, INC. & SUBSIDIARIES

[0001193125-16-787354:8k_2_02:33]
NON-GAAP NET INCOME RECONCILIATION

[0001193125-16-787354:8k_2_02:34]
|  |  | Three months endedSeptember 30, |  |  | Year endedSeptember 30, |  |
| (In thousands) |  | 2016 |  |  | 2015 |  |  | 2016 |  |  | 2015 |  |
|  |  | (Unaudited) |  |  | (Unaudited) |  |
| Reconciliation of GAAP Net Income to Non-GAAP Net Income: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| GAAP Net income |  | $ | 5,508 |  |  | $ | 6,312 |  |  | $ | 15,510 |  |  | $ | 9,439 |  |
| Non-GAAP items: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Restructuring and separation costs |  |  | 738 |  |  |  | 659 |  |  |  | 8,441 |  |  |  | 3,397 |  |
| Income tax reserve release (FIN 48) |  |  | — |  |  |  | — |  |  |  | — |  |  |  | (4,149 | ) |
| Sales and use tax audit |  |  | — |  |  |  | (1,107 | ) |  |  | — |  |  |  | (1,107 | ) |
| Canadian tax valuation allowance |  |  | — |  |  |  | (857 | ) |  |  | — |  |  |  | 8,139 |  |
| Income tax effect of non-GAAP items |  |  | (95 | ) |  |  | 211 |  |  |  | (2,519 | ) |  |  | (320 | ) |
| Non-GAAP Net income |  | $ | 6,151 |  |  | $ | 5,218 |  |  | $ | 21,432 |  |  | $ | 15,399 |  |
| Diluted shares outstanding |  |  | 11,463 |  |  |  | 11,669 |  |  |  | 11,431 |  |  |  | 11,908 |  |
| Diluted Earnings Per Share: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| GAAP earnings per share |  | $ | 0.48 |  |  | $ | 0.54 |  |  | $ | 1.36 |  |  | $ | 0.79 |  |
| Non-GAAP earnings per share |  | $ | 0.54 |  |  | $ | 0.45 |  |  | $ | 1.87 |  |  | $ | 1.29 |  |

[0001193125-16-787354:8k_2_02:35]
For all periods presented, the Company defines non-GAAP net income as net income which excludes: 1) Restructuring and
separation costs; 2) the income tax reserve release (FIN 48); 3) Sales and use tax audit, net of tax and 4) the Canadian tax valuation allowance. The income tax effect is based on the applicable statutory rate. Non-GAAP financial measures should not
be considered a substitute for, or superior to, measures of financial performance prepared in accordance with GAAP. However, the Company believes by excluding these items, these non-GAAP financial measures are helpful in comparing the historical
results to current results because this non-GAAP information provides consistent measures of the underlying results of our ongoing operations. The Company also believes the disclosure of non-GAAP net income will help investors meaningfully evaluate
and compare its cash flow generating capacity from quarter to quarter and year to year.

[0001193125-16-787354:8k_2_02:36]
The non-GAAP items, and the basis for excluding them from
GAAP financial measures, are outlined below:

[0001193125-16-787354:8k_2_02:37]
|  | • |  | Restructuring and separation costs– For the year ended September 30, 2016, we recorded $8.4 million in restructuring and separation costs due to the restructuring of our senior management team and the alignment of our salaried and hourly workforce with future production requirements. For the year ended September 30, 2015, we incurred $3.4 million in restructuring and separation costs. |

[0001193125-16-787354:8k_2_02:38]
|  | • |  | Income tax reserve release (FIN 48) – During the year ended September 30, 2015, we released an income tax reserve of $4.1 million for R&D tax credits upon the closing of an IRS audit. |

[0001193125-16-787354:8k_2_02:39]
|  | • |  | Sales and use tax audit– In the fourth quarter of Fiscal 2015, we recorded a benefit of $0.7 million following the conclusion of a state sales and use tax audit. |

[0001193125-16-787354:8k_2_02:40]
|  | • |  | Canadian tax valuation allowance – During the year ended September 30, 2015, we established a valuation allowance against the Canadian deferred tax assets of approximately $9.0 million in the second quarter and recorded a fourth quarter adjustment of ($0.9 million). This valuation allowance was recorded because we anticipated that we might not be able to realize the benefits of the net operating loss carryforwards and other deductible differences. |

[0001193125-16-787354:8k_2_02:41]
Due to the nature of these items, the Company does not believe that these items reflect its ongoing operations.

[0001193125-16-787354:8k_2_02:42]
# # #
