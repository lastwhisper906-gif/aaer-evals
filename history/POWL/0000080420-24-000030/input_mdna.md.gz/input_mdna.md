# POWL MD&A — 0000080420-24-000030


## mdna

[0000080420-24-000030:mdna:1]
[same as prior period, unchanged from 0000080420-24-000008:mdna:1]

[0000080420-24-000030:mdna:2]
The following discussion and analysis of our financial condition and results of operations should be read in conjunction with the accompanying condensed consolidated financial statements and related notes included elsewhere in this Quarterly Report on Form 10-Q and with our Annual Report on Form 10-K for the fiscal year ended September 30, 2023, which was filed with the SEC on December 6, 2023 and is available on the SEC’s website at www.sec.gov.

[0000080420-24-000030:mdna:3]
[same as prior period, unchanged from 0000080420-24-000008:mdna:3]

[0000080420-24-000030:mdna:4]
We develop, design, manufacture and service custom-engineered equipment and systems that (1) distribute, control and monitor the flow of electrical energy and (2) provide protection to motors, transformers and other electrically powered equipment. We are headquartered in Houston, Texas, and serve the oil and gas and petrochemical markets, which include onshore and offshore production, liquefied natural gas (LNG) facilities and terminals, pipelines, refineries and petrochemical plants. Additional markets include electric utility, data centers, renewable energy, mining and metals, light rail traction power, pulp and paper, and other municipal, commercial and industrial markets. Revenues and costs are primarily related to custom engineered-to-order equipment and systems and are accounted for under percentage-of-completion accounting, which precludes us from providing detailed price and volume information. Our backlog includes various projects that typically take a number of months to produce.

[0000080420-24-000030:mdna:5]
[same as prior period, unchanged from 0000080420-24-000008:mdna:5]

[0000080420-24-000030:mdna:6]
[same as prior period, unchanged from 0000080420-24-000008:mdna:6]

[0000080420-24-000030:mdna:7]
One element of our strategic focus is to strengthen our project portfolio beyond our core oil, gas and petrochemical end market sectors. Diversification efforts outside of our core oil, gas and petrochemical end markets have resulted in a solid backlog across the electric utility and commercial and other industrial sectors in Fiscal 2023 and continuing throughout the first half of Fiscal 2024. As of March 31, 2024, our backlog remained at $1.3 billion.

[0000080420-24-000030:mdna:8]
Even though commodity prices remained stable throughout the first half of Fiscal 2024, we continue to experience supply chain delays for specific engineered components and are working with our suppliers to meet our customer commitments. In response to the increased cost environment and supply chain challenges, we strive to effectively manage our product pricing, delivery schedules and bid validity dates with our customers, as well as improve factory efficiencies and project execution.

[0000080420-24-000030:mdna:9]
[same as prior period, unchanged from 0000080420-24-000008:mdna:9]

[0000080420-24-000030:mdna:10]
Quarter Ended March 31, 2024 Compared to the Quarter Ended March 31, 2023 (Unaudited)

[0000080420-24-000030:mdna:11]
[same as prior period, unchanged from 0000080420-24-000008:mdna:11]

[0000080420-24-000030:mdna:12]
Revenues increased by 49%, or $83.7 million, to $255.1 million in the second quarter of Fiscal 2024, primarily driven by the increase in project backlog resulting from large contracts awarded in Fiscal 2023 and solid bookings throughout the first half of Fiscal 2024. Domestic revenues increased by 62%, or $82.8 million, to $216.9 million in the second quarter of Fiscal 2024. International revenues increased by 2%, or $0.9 million, to $38.2 million in the second quarter of Fiscal 2024. Our international revenues include both revenues generated from our international facilities as well as revenues from export projects generated at our domestic facilities.

[0000080420-24-000030:mdna:13]
In the second quarter of Fiscal 2024, revenue from our core oil and gas market (excluding petrochemical) increased by 66%, or $41.2 million, to $103.8 million; petrochemical market revenue increased by 93%, or $24.2 million, to $50.1 million; revenue from our electric utility market increased by 11%, or $4.8 million, to $47.5 million; commercial and other industrial market revenue increased by 57%, or $12.6 million, to $34.9 million; and revenue from all other markets combined increased by 34%,

[0000080420-24-000030:mdna:14]
or $3.6 million, to $14.3 million. These increases in revenue were driven by improved market conditions and increased capital spending in our core oil, gas and petrochemical markets, as well as our strategic effort to diversify our business into electric utility and commercial and other industrial markets. Revenue from our light rail traction power market decreased by 38%, or $2.8 million, to $4.5 million in the second quarter of Fiscal 2024 due to less project volume in this market.

[0000080420-24-000030:mdna:15]
Gross profit increased by 88%, or $29.3 million, to $62.7 million for the second quarter of Fiscal 2024.  Gross profit as a percentage of revenues increased to 25% in the second quarter of Fiscal 2024, compared to 20% in the second quarter of Fiscal 2023. This increase in gross profit reflects the higher volume levels across our manufacturing facilities driving favorable volume leverage, efficient project execution, as well as our continuing effort to improve key factory efficiencies and to effectively manage product pricing that corresponds to current cost levels.

[0000080420-24-000030:mdna:16]
[same as prior period, unchanged from 0000080420-24-000008:mdna:16]

[0000080420-24-000030:mdna:17]
Selling, general and administrative expenses decreased by 4%, or $0.9 million, to $20.9 million in the second quarter of Fiscal 2024, primarily due to a lower level of variable incentive compensation expenses. Selling, general and administrative expenses as a percentage of revenues decreased to 8% during the second quarter of Fiscal 2024 compared to 13% during the second quarter of Fiscal 2023, resulting from higher revenues on our existing cost structure.

[0000080420-24-000030:mdna:18]
[same as prior period, unchanged from 0000080420-24-000008:mdna:18]

[0000080420-24-000030:mdna:19]
We recorded an income tax provision of $10.4 million in the second quarter of Fiscal 2024, compared to an income tax provision of $2.5 million in the second quarter of Fiscal 2023. The effective tax rate for the second quarter of Fiscal 2024 was 24%, compared to an effective tax rate of 23% for the second quarter of Fiscal 2023. For each of the three months ended March 31, 2024 and 2023, the effective tax rate was favorably impacted by the estimated Research and Development Tax Credit (R&D Tax Credit). Additionally, we recognized benefits related to discrete items for the vesting of restricted stock units (RSUs) and the release of a reserve for unrecognized tax benefits in the second quarter of Fiscal 2024 and a benefit related to the projected utilization of net operating loss carryforwards in the United Kingdom (the U.K.) that had been fully reserved with a valuation allowance in the second quarter of Fiscal 2023. For each of the three months ended March 31, 2024 and 2023, these benefits were offset by an income inclusion related to U.S. global intangible income and certain nondeductible expenses.

[0000080420-24-000030:mdna:20]
[same as prior period, unchanged from 0000080420-24-000008:mdna:20]

[0000080420-24-000030:mdna:21]
In the second quarter of Fiscal 2024, we recorded net income of $33.5 million, or $2.75 per diluted share, compared to net income of $8.5 million, or $0.70 per diluted share, in the second quarter of Fiscal 2023. This increase in net income was primarily due to the strength and quality of our backlog at the end of Fiscal 2023, as well as solid bookings throughout the first half of Fiscal 2024, which has led to an increase in revenue coupled with improved project margins.

[0000080420-24-000030:mdna:22]
[same as prior period, unchanged from 0000080420-24-000008:mdna:22]

[0000080420-24-000030:mdna:23]
The order backlog, which is our remaining unsatisfied performance obligations, represents the estimated transaction price for goods and services for which we have a material right, but work has not been performed. The order backlog at March 31, 2024 was $1.3 billion, consistent with our December 31, 2023 backlog, and an increase of 25% from $1.0 billion at March 31, 2023. Bookings, net of cancellations and scope reductions, decreased by 54% in the second quarter of Fiscal 2024 to $235.4 million, compared to $508.2 million in the second quarter of Fiscal 2023. Despite solid bookings in the second quarter of Fiscal 2024, the decrease was due to a normalization of the oil and gas sector and fewer large orders awarded during Fiscal 2024.

[0000080420-24-000030:mdna:24]
Six Months Ended March 31, 2024 Compared to Six Months Ended March 31, 2023 (Unaudited)

[0000080420-24-000030:mdna:25]
Revenue and Gross Profit

[0000080420-24-000030:mdna:26]
Revenues increased by 51%, or $150.8 million, to $449.1 million in the six months ended March 31, 2024, primarily driven by the increase in project backlog resulting from large contracts awarded throughout Fiscal 2023 and solid bookings throughout the first half of Fiscal 2024. Domestic revenues increased by 61%, or $142.5 million, to $376.8 million in the six months ended March 31, 2024. International revenues increased by 13%, or $8.3 million, to $72.3 million in the six months ended March 31, 2024. Our international revenues include both revenues generated from our international facilities as well as revenues from export projects generated at our domestic facilities.

[0000080420-24-000030:mdna:27]
In the six months ended March 31, 2024, revenue from our core oil and gas market (excluding petrochemical) increased by 77%, or $81.3 million, to $187.5 million; petrochemical market revenue increased by 62%, or $30.1 million, to $78.4 million; revenue from our electric utility market increased by 24%, or $17.1 million, to $88.2 million; commercial and other industrial market revenue increased by 51%, or $20.2 million, to $59.6 million; and revenue from all other markets combined increased by 40%, or $7.6 million, to $26.6 million. These increases in revenue were driven by improved market conditions and increased capital spending in our core oil, gas and petrochemical markets, as well as our strategic effort to diversify our business into electric utility and commercial and other industrial markets. Revenue from our light rail traction power market decreased by 38%, or $5.5 million, to $8.9 million in the first half of Fiscal 2024 due to less project volume in this market.

[0000080420-24-000030:mdna:28]
Gross profit increased by 110%, or $58.0 million, to $110.9 million for the first half of Fiscal 2024. Gross profit as a percentage of revenues increased to 25% in the first half of Fiscal 2024, compared to 18% in the first half of Fiscal 2023. This increase in gross profit reflects the higher volume levels across our manufacturing facilities driving favorable volume, leverage, efficient project execution, as well as our continuing effort to improve key factory efficiencies and to effectively manage product pricing that corresponds to current cost levels.

[0000080420-24-000030:mdna:29]
Selling, General and Administrative Expenses

[0000080420-24-000030:mdna:30]
Selling, general and administrative expenses increased by 7%, or $2.6 million, to $41.3 million in the six months ended March 31, 2024, primarily due to increased compensation expenses. Selling, general and administrative expenses as a percentage of revenues decreased to 9% during the first half of Fiscal 2024 compared to 13% during the first half of Fiscal 2023, resulting from higher revenues on our existing cost structure.

[0000080420-24-000030:mdna:31]
Income Tax Provision

[0000080420-24-000030:mdna:32]
We recorded an income tax provision of $16.2 million in the six months ended March 31, 2024, compared to an income tax provision of $3.0 million in the six months ended March 31, 2023. The effective tax rate for the six months ended March 31, 2024 was 22%, compared to an effective tax rate of 23% for the six months ended March 31, 2023. For each of the six months ended March 31, 2024 and 2023, the effective tax rate was favorably impacted by the estimated R&D Tax Credit. Additionally, we recognized benefits related to discrete items for the vesting of RSUs and the release of a reserve for unrecognized tax benefits in the six months ended March 31, 2024 and a benefit related to the projected utilization of net operating loss carryforwards in the U.K. that had been fully reserved with a valuation allowance in the six months ended March 31, 2023. In both periods, these benefits were offset by an income inclusion related to U.S. global intangible income and certain nondeductible expenses.

[0000080420-24-000030:mdna:33]
Net Income

[0000080420-24-000030:mdna:34]
In the six months ended March 31, 2024, we recorded net income of $57.6 million, or $4.73 per diluted share, compared to net income of $9.6 million, or $0.80 per diluted share, in the six months ended March 31, 2023. This increase in net income was primarily due to the strength and quality of our backlog at the end of Fiscal 2023, as well as solid bookings throughout the first half of Fiscal 2024, which has led to an increase in revenue coupled with improved project margins.

[0000080420-24-000030:mdna:35]
Backlog

[0000080420-24-000030:mdna:36]
The order backlog, which is our remaining unsatisfied performance obligations, represents the estimated transaction price for goods and services for which we have a material right, but work has not been performed. The order backlog at March 31, 2024 was $1.3 billion, consistent with our backlog at September 30, 2023. Bookings, net of cancellations and scope reductions, decreased by 40% during the six months ended March 31, 2024 to $433.0 million, compared to $720.0 million during the six months ended March 31, 2023. Despite solid bookings in the first half of Fiscal 2024, the decrease was due to a normalization of the oil and gas sector and fewer large orders awarded in Fiscal 2024.

[0000080420-24-000030:mdna:37]
[same as prior period, unchanged from 0000080420-24-000008:mdna:24]

[0000080420-24-000030:mdna:38]
Our order activity in most of our core markets remains active and diversification efforts outside of our core oil, gas and petrochemical markets continue to be a positive catalyst. We believe the fundamentals of the US natural gas market, through abundant supply and low cost, will continue to support investments in LNG, related gas processing, and petrochemical processes. We continue to monitor the Biden administration's pause of LNG export permitting by the Department of Energy, which may impact the timing of future project activity. We have achieved strong bookings in electric utility and commercial markets through the first half of Fiscal 2024 in the US, Canada and the U.K., largely driven by the markets where our operations are based. Our backlog remained at $1.3 billion as of March 31, 2024, of which approximately $733 million is expected to be recognized as revenue within the next twelve months. Although current commercial activity remains active in most of the sectors that we compete in, we remain attentive to the macro environment and geopolitical events that may have an impact on future market activity.

[0000080420-24-000030:mdna:39]
Our operating results are impacted by several factors such as the timing of new order awards, project backlog, changes in project cost estimates, customer approval of final engineering specifications and delays in customer construction schedules, all of which contribute to short-term earnings variability and the timing of project execution. Our operating results also have been, and may continue to be, impacted by the timing and resolution of change orders and the resolution of potential contract claims and liquidated damages, all of which could improve or deteriorate gross margins during the period in which these items are resolved with our customers. Disruptions in the global supply chain have negatively impacted and may continue to negatively impact our business and operating results due to the limited supply of, delays for and uncertainty in the timing of the receipt of key component parts and commodities. We continue to remain focused on the variables that impact our markets as well as cost management, labor availability and supply chain challenges.

[0000080420-24-000030:mdna:40]
We have planned capital spending of approximately $11.0 million on a facility expansion project at our products factory in Houston. We expect to complete the expansion project by mid-Fiscal 2025.

[0000080420-24-000030:mdna:41]
[same as prior period, unchanged from 0000080420-24-000008:mdna:27]

[0000080420-24-000030:mdna:42]
As of March 31, 2024, current assets exceeded current liabilities by 1.6 times.

[0000080420-24-000030:mdna:43]
Cash, cash equivalents and short-term investments increased to $365.3 million at March 31, 2024, compared to $279.0 million at September 30, 2023. This increase in cash, cash equivalents and short-term investments was primarily driven by the increased project volume and favorable timing of contract billing milestones on many of our large projects. We typically allocate a significant percentage of the progress billing to the early stages of the contract. Our improved earnings, as well as favorable billing milestones largely contributed to the increase in our cash, cash equivalents and short-term investments at March 31, 2024. We believe that our cash, cash equivalents and short-term investments, as well as available borrowings under the U.S. Revolver, will be sufficient to support our future operating activities, working capital requirements, payment of dividends and capital spending, as well as research and development initiatives for the next twelve months and beyond.

[0000080420-24-000030:mdna:44]
On October 4, 2023, we entered into the Third Amendment to the U.S. Revolver. The Third Amendment added Texas Capital Bank as Syndication Agent and a lender, increased the amount of the revolving line of credit from $125.0 million to $150.0 million, and extended the expiry date to October 4, 2028. The aggregate commitment of $150.0 million consists of $100.0 million committed by Bank of America and $50.0 million committed by Texas Capital Bank. As amended by the Third Amendment, the lesser of (a) $60 million, (b) 60% of available cash, and (c) the aggregate face amount of the issued but undrawn letters of credit that are not cash-secured, shall be deducted from consolidated funded indebtedness, when calculating the consolidated net leverage ratio. We have the option to cash collateralize all or a portion of the letters of credit outstanding, which would favorably impact the consolidated funded indebtedness calculation and the consolidated net leverage ratio.

[0000080420-24-000030:mdna:45]
As of March 31, 2024, there were no amounts borrowed under the U.S. Revolver, and letters of credit outstanding were $87.8 million. There was $62.2 million available for the issuance of letters of credit and borrowings under the U.S. Revolver as of March 31, 2024. For further information regarding our debt, see Notes E and F of Notes to Condensed Consolidated Financial Statements.

[0000080420-24-000030:mdna:46]
Approximately $70.6 million of our cash, cash equivalents and short-term investments at March 31, 2024 was held outside of the U.S. for our international operations. It is our intention to indefinitely reinvest all current and future foreign earnings internationally in order to ensure sufficient working capital to support our international operations. In the event that we elect to repatriate some or all of the foreign earnings that were previously deemed to be indefinitely reinvested outside the U.S., we may incur additional tax expense upon such repatriation under current tax laws.

[0000080420-24-000030:mdna:47]
[same as prior period, unchanged from 0000080420-24-000008:mdna:33]

[0000080420-24-000030:mdna:48]
Operating activities provided net cash of $100.9 million during the six months ended March 31, 2024 and provided net cash of $55.5 million during the same period in Fiscal 2023. Cash flow from operations is primarily influenced by project volume and margins, as well as the associated working capital requirements, the timing of milestone payments from our customers, and payment terms with our suppliers. This increase in operating cash flow was primarily due to higher net income resulting from increased project volume and improved project margins.

[0000080420-24-000030:mdna:49]
[same as prior period, unchanged from 0000080420-24-000008:mdna:35]

[0000080420-24-000030:mdna:50]
Investing activities used $11.2 million during the six months ended March 31, 2024 and provided $0.3 million during the same period in Fiscal 2023. The increase in cash used in investing activities was primarily due to net purchases of short-term investments of $8.9 million in the first half of Fiscal 2024 compared to net maturities of short-term investments of $3.7 million in the same period of Fiscal 2023. In December 2023, we acquired intellectual property for a total consideration of $0.5 million, of which $250 thousand was paid in cash.

[0000080420-24-000030:mdna:51]
[same as prior period, unchanged from 0000080420-24-000008:mdna:37]

[0000080420-24-000030:mdna:52]
Net cash used in financing activities was $12.8 million during the six months ended March 31, 2024 and $6.8 million during the same period in Fiscal 2023. The increase in cash used in financing activities was primarily due to cash payments related to shares withheld in lieu of employee tax withholding, largely driven by the significant increase in our share price in the first half of Fiscal 2024 compared to the same period of Fiscal 2023.

[0000080420-24-000030:mdna:53]
[same as prior period, unchanged from 0000080420-24-000008:mdna:39]

[0000080420-24-000030:mdna:54]
[same as prior period, unchanged from 0000080420-24-000008:mdna:40]

[0000080420-24-000030:mdna:55]
[same as prior period, unchanged from 0000080420-24-000008:mdna:41]
