# POWL note change history — 0000080420-24-000008 → 0000080420-24-000030


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2024-05-01):
[0000080420-24-000030:note_history:1]
Certain customers require us to post letters of credit, bank guarantees or surety bonds. These security instruments assure that we will perform under the terms of our contract. In the event of default, the counterparty may demand payment from the bank under a letter of credit or bank guarantee, or performance by the surety under a bond. To date, there have been no significant draws or claims related to security instruments for the periods reported. We were contingently liable for letters of credit of $87.8 million as of March 31, 2024. We also had surety bonds totaling $481.9 million that were outstanding, with additional bonding capacity of $718.1 million available, at March 31, 2024. We have strong surety relationships; however, a change in market conditions or the sureties' assessment of our financial position could cause the sureties to require cash collateralization for undischarged liabilities under the bonds.
  (was, 2024-01-31, similarity 0.9857):
[0000080420-24-000008:note_history:1]
Certain customers require us to post letters of credit, bank guarantees or surety bonds. These security instruments assure that we will perform under the terms of our contract. In the event of default, the counterparty may demand payment from the bank under a letter of credit or bank guarantee, or performance by the surety under a bond. To date, there have been no significant draws or claims related to security instruments for the periods reported. We were contingently liable for letters of credit of $87.1 million as of December 31, 2023. We also had surety bonds totaling $483.6 million that were outstanding, with additional bonding capacity of $716.4 million available, at December 31, 2023. We have strong surety relationships; however, a change in market conditions or the sureties' assessment of our financial position could cause the sureties to require cash collateralization for undischarged liabilities under the bonds.

- changed (2024-05-01):
[0000080420-24-000030:note_history:2]
We have an $18.9 million facility agreement (Facility Agreement) between Powell (UK) Limited and a large international bank that provides Powell (UK) Limited the ability to enter into bank guarantees as well as forward exchange contracts and currency options. At March 31, 2024, we had outstanding guarantees totaling $7.4 million, with an additional capacity of $11.5 million available under this Facility Agreement. The Facility Agreement provides for customary events of default and carries cross-default provisions with the U.S. Revolver. If an event of default (as defined in the Facility Agreement) occurs and is continuing, per the terms and subject to the conditions set forth therein, obligations outstanding under the Facility Agreement may be accelerated and declared immediately due and payable. Additionally, we are required to maintain cash collateral for guarantees greater than two years. As of March 31, 2024, we were in compliance with all of the financial covenants of the Facility Agreement.
  (was, 2024-01-31, similarity 0.9864):
[0000080420-24-000008:note_history:2]
We have a $19.1 million facility agreement (Facility Agreement) between Powell (UK) Limited and a large international bank that provides Powell (UK) Limited the ability to enter into bank guarantees as well as forward exchange contracts and currency options. At December 31, 2023, we had outstanding guarantees totaling $6.8 million, with an additional capacity of $12.3 million available under this Facility Agreement. The Facility Agreement provides for customary events of default and carries cross-default provisions with the U.S. Revolver. If an event of default (as defined in the Facility Agreement) occurs and is continuing, per the terms and subject to the conditions set forth therein, obligations outstanding under the Facility Agreement may be accelerated and declared immediately due and payable. Additionally, we are required to maintain cash collateral for guarantees greater than two years. As of December 31, 2023, we were in compliance with all of the financial covenants of the Facility Agreement.

- changed (2024-05-01):
[0000080420-24-000030:note_history:3]
We are involved in various legal proceedings, claims and other disputes arising from our commercial operations, projects, employees and other matters which, in general, are subject to uncertainties and for which the outcomes are not predictable. Although we can give no assurances about the resolution of pending claims, litigation or other disputes, and the effect such outcomes may have on us, management believes that any ultimate liability resulting from the outcome of such proceedings, to the extent not otherwise provided or covered by insurance, will not have a material adverse effect on our consolidated financial position or results of operations or liquidity.
  (was, 2024-01-31, similarity 0.9963):
[0000080420-24-000008:note_history:3]
We are involved in various legal proceedings, claims and other disputes arising from our commercial operations, projects, employees and other matters which, in general, are subject to uncertainties and in which the outcomes are not predictable. Although we can give no assurances about the resolution of pending claims, litigation or other disputes, and the effect such outcomes may have on us, management believes that any ultimate liability resulting from the outcome of such proceedings, to the extent not otherwise provided or covered by insurance, will not have a material adverse effect on our consolidated financial position or results of operations or liquidity.

- changed (2024-05-01):
[0000080420-24-000030:note_history:4]
Certain of our customer contracts have schedule and performance obligation clauses that, if we fail to meet them, could require us to pay liquidated damages. Each individual contract defines the conditions under which the customer may make a claim against us. As of March 31, 2024, certain contracts had a probable exposure to liquidated damages claims of $1.7 million, which could possibly increase to $2.1 million under certain circumstances. Based on our actual or projected failure to meet these various contractual commitments, $1.0 million has been recorded as a reduction to revenue. We will attempt to obtain change orders, contract extensions or accelerate project completion, which may resolve the potential for any unrecorded liquidated damages claims. Should we fail to achieve relief on some or all of these contractual obligations, we could be required to pay additional liquidated damages, which could negatively impact our future operating results.
  (was, 2024-01-31, similarity 0.9932):
[0000080420-24-000008:note_history:4]
Certain of our customer contracts have schedule and performance obligation clauses that, if we fail to meet them, could require us to pay liquidated damages. Each individual contract defines the conditions under which the customer may make a claim against us. As of December 31, 2023, certain contracts had a probable exposure to liquidated damages claims of $3.6 million, which could possibly increase to $4.2 million under certain circumstances. Based on our actual or projected failure to meet these various contractual commitments, $1.5 million has been recorded as a reduction to revenue. We will attempt to obtain change orders, contract extensions or accelerate project completion, which may resolve the potential for any unrecorded liquidated damages claims. Should we fail to achieve relief on some or all of these contractual obligations, we could be required to pay additional liquidated damages, which could negatively impact our future operating results.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureAndSignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2024-05-01):
[0000080420-24-000030:note_history:5]
Powell Industries, Inc. (we, us, our, Powell or the Company) is a Delaware corporation founded by William E. Powell in 1947. Our major subsidiaries, all of which are wholly owned, include Powell Electrical Systems, Inc.; Powell (UK) Limited; Powell Canada Inc.; and Powell Industries International, B.V.
  (was, 2024-01-31, similarity 0.8157):
[0000080420-24-000008:note_history:5]
Powell Industries, Inc. (we, us, our, Powell or the Company) is incorporated in the state of Delaware. Powell's predecessor companies were founded 77 years ago by William E. Powell in 1947. Our major subsidiaries, all of which are wholly owned, include Powell Electrical Systems, Inc.; Powell (UK) Limited; Powell Canada Inc.; and Powell Industries International, B.V.

- changed (2024-05-01):
[0000080420-24-000030:note_history:6]
We develop, design, manufacture and service custom-engineered equipment and systems that (1) distribute, control and monitor the flow of electrical energy and (2) provide protection to motors, transformers and other electrically powered equipment. We are headquartered in Houston, Texas, and serve the oil and gas and petrochemical markets, which include onshore and offshore production, liquefied natural gas (LNG) facilities and terminals, pipelines, refineries and petrochemical plants. Additional markets include electric utility, data centers, renewable energy, mining and metals, light rail traction power, pulp and paper, and other municipal, commercial and industrial markets.
  (was, 2024-01-31, similarity 0.7368):
[0000080420-24-000008:note_history:6]
We develop, design, manufacture and service custom-engineered equipment and systems which (1) distribute, control and monitor the flow of electrical energy and (2) provide protection to motors, transformers and other electrically powered equipment. We are headquartered in Houston, Texas and serve the oil and gas and petrochemical markets, which include onshore and offshore production, liquefied natural gas (LNG) facilities and terminals, pipelines, refineries and petrochemical plants. Additionally, we manufacture products for the electric utility, light rail traction power, mining and metals, pulp and paper, data centers and other municipal, commercial and industrial markets.

- changed (2024-05-01):
[0000080420-24-000030:note_history:7]
The unaudited condensed consolidated financial statements include the accounts of Powell and our wholly owned subsidiaries. All significant intercompany accounts and transactions have been eliminated in consolidation.
  (was, 2024-01-31, similarity 0.9954):
[0000080420-24-000008:note_history:7]
The unaudited condensed consolidated financial statements include the accounts of Powell and our wholly-owned subsidiaries. All significant intercompany accounts and transactions have been eliminated in consolidation.

- changed (2024-05-01):
[0000080420-24-000030:note_history:8]
Accounting Standards Updates and Disclosure Rules Issued but Not Yet Adopted
  (was, 2024-01-31, similarity 0.8397):
[0000080420-24-000008:note_history:8]
Accounting Standards Updates Issued but Not Yet Adopted

- added (2024-05-01):
[0000080420-24-000030:note_history:9]
In December 2023, the FASB issued ASU 2023-09, Improvements to Income Tax Disclosures, which enhances the transparency of income tax disclosures. It requires greater disaggregation of information in the tax rate reconciliation and income taxes paid disaggregated by jurisdiction. This ASU is effective for fiscal years beginning after December 15, 2024, and should be applied on a prospective basis. Retrospective application and early adoption are permitted. We are currently evaluating the impacts of the new standard.
In March 2024, the SEC adopted final rules designed to enhance and standardize disclosures related to the risks and impacts of climate-related matters. The final rules require registrants to disclose certain climate-related information in registration statements and annual reports. Such information relates to climate-related risks and risk management processes for, and governance and oversight activities of such risks. The final rules also include requirements to disclose the financial effects of severe weather events and other natural conditions in the audited financial statements. In addition, larger registrants will be required to disclose information about greenhouse gas emissions, which will be subject to a phased-in assurance requirement. These disclosure requirements will be effective for the Company's fiscal year beginning October 1, 2025. In April 2024, the SEC voluntarily stayed the final rules as a result of pending legal challenges. We are currently evaluating the impacts of the final rules on our consolidated financial statements and related disclosures.

- removed (2024-05-01):
[0000080420-24-000008:note_history:10]
In December 2023, the FASB issued ASU 2023-09, Improvements to Income Tax Disclosures, which enhances the transparency of income tax disclosures. It requires greater disaggregation of information in the tax rate reconciliation and income taxes paid disaggregated by jurisdiction. This ASU is effective for fiscal years beginning after December 15, 2024, and should be applied on a prospective basis. Retrospective application and early adoption are permitted. We are currently evaluating the impacts of the new standard.


## us-gaap:LongTermDebtTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2024-05-01):
[0000080420-24-000030:note_history:11]
On October 4, 2023, we entered into a third amendment (the Third Amendment) to our credit agreement with Bank of America, N.A. (as amended, the U.S. Revolver). The Third Amendment added Texas Capital Bank as Syndication Agent and a lender, increased the amount of the revolving line of credit from $125.0 million to $150.0 million, and extended the expiry date to October 4, 2028. The aggregate commitment of $150.0 million consists of $100.0 million committed by Bank of America and $50.0 million committed by Texas Capital Bank. As amended by the Third Amendment, the lesser of (a) $60 million, (b) 60% of available cash, and (c) the aggregate face amount of the issued but undrawn letters of credit that are not cash-secured, shall be deducted from consolidated funded indebtedness, when calculating the consolidated net leverage ratio. We have the option to cash collateralize all or a portion of the letters of credit outstanding, which would favorably impact the consolidated funded indebtedness calculation and the consolidated net leverage ratio. As of March 31, 2024, there were no amounts borrowed under the U.S. Revolver, and letters of credit outstanding were $87.8 million. There was $62.2 million available for the issuance of letters of credit and borrowings under the U.S. Revolver as of March 31, 2024.
  (was, 2024-01-31, similarity 0.9866):
[0000080420-24-000008:note_history:11]
On October 4, 2023, we entered into a third amendment (the Third Amendment) to our credit agreement with Bank of America, N.A. (as amended, the U.S. Revolver). The Third Amendment added Texas Capital Bank as Syndication Agent and a lender, increased the amount of the revolving line of credit from $125.0 million to $150.0 million, and extended the expiry date to October 4, 2028. The aggregate commitment of $150.0 million consists of $100.0 million committed by Bank of America and $50.0 million committed by Texas Capital Bank. As amended by the Third Amendment, the lesser of (a) $60 million, (b) 60% of available cash, and (c) the aggregate face amount of the issued but undrawn letters of credit that are not cash-secured, shall be deducted from consolidated funded indebtedness, when calculating the consolidated net leverage ratio. We have the option to cash collateralize all or a portion of the letters of credit outstanding, which would favorably impact the consolidated funded indebtedness calculation and the consolidated net leverage ratio. As of December 31, 2023, there were no amounts borrowed under the U.S. Revolver, and letters of credit outstanding were $87.1 million. There was $62.9 million available for the issuance of letters of credit and borrowings under the U.S. Revolver as of December 31, 2023.

- changed (2024-05-01):
[0000080420-24-000030:note_history:12]
As of March 31, 2024, we were in compliance with all of the financial covenants of the U.S. Revolver.
  (was, 2024-01-31, similarity 0.9534):
[0000080420-24-000008:note_history:12]
As of December 31, 2023, we were in compliance with all of the financial covenants of the U.S. Revolver.


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2024-05-01):
[0000080420-24-000030:note_history:13]
The following tables present our disaggregated revenue by geographic destination and market sector for the three and six months ended March 31, 2024 and 2023 (in thousands):
  (was, 2024-01-31, similarity 0.9477):
[0000080420-24-000008:note_history:13]
The following tables present our disaggregated revenue by geographic destination and market sector for the three months ended December 31, 2023 and 2022 (in thousands):

- added (2024-05-01):
[0000080420-24-000030:note_history:14]
|  | Three months ended March 31, |  | Six months ended March 31, |
|  | 2024 |  | 2023 |  | 2024 |  | 2023 |
| United States | $ | 216,933 |  |  | $ | 134,161 |  |  | $ | 376,793 |  |  | $ | 234,273 |  |
| Canada | 24,160 |  |  | 21,995 |  |  | 44,510 |  |  | 40,491 |  |
| Europe | 8,265 |  |  | 7,953 |  |  | 14,797 |  |  | 12,087 |  |
| Middle East and Africa | 2,803 |  |  | 4,004 |  |  | 6,078 |  |  | 6,429 |  |
| Mexico, Central and South America | 2,159 |  |  | 1,543 |  |  | 4,816 |  |  | 2,458 |  |
| Asia/Pacific | 788 |  |  | 1,788 |  |  | 2,131 |  |  | 2,564 |  |
| Total revenues by geographic destination | $ | 255,108 |  |  | $ | 171,444 |  |  | $ | 449,125 |  |  | $ | 298,302 |  |

- changed (2024-05-01):
[0000080420-24-000030:note_history:15]
|  | Three months ended March 31, |  | Six months ended March 31, |
|  | 2024 |  | 2023 |  | 2024 |  | 2023 |
| Oil and gas (excludes petrochemical) | $ | 103,820 |  |  | $ | 62,597 |  |  | $ | 187,456 |  |  | $ | 106,107 |  |
| Petrochemical | 50,070 |  |  | 25,887 |  |  | 78,437 |  |  | 48,377 |  |
| Electric utility | 47,502 |  |  | 42,668 |  |  | 88,205 |  |  | 71,075 |  |
| Commercial and other industrial | 34,894 |  |  | 22,270 |  |  | 59,566 |  |  | 39,320 |  |
| Light rail traction power | 4,517 |  |  | 7,317 |  |  | 8,862 |  |  | 14,389 |  |
| All others | 14,305 |  |  | 10,705 |  |  | 26,599 |  |  | 19,034 |  |
| Total revenues by market sector | $ | 255,108 |  |  | $ | 171,444 |  |  | $ | 449,125 |  |  | $ | 298,302 |  |
  (was, 2024-01-31, similarity 0.6554):
[0000080420-24-000008:note_history:15]
|  | Three months ended December 31, |  |  |
|  | 2023 |  | 2022 |  |  |  |  |
| Oil and gas (excludes petrochemical) | $ | 83,636 |  |  | $ | 43,510 |  |  |  |  |  |
| Petrochemical | 28,367 |  |  | 22,490 |  |  |  |  |  |
| Electric utility | 40,703 |  |  | 28,407 |  |  |  |  |  |
| Commercial and other industrial | 24,672 |  |  | 17,050 |  |  |  |  |  |
| Traction power | 4,345 |  |  | 7,072 |  |  |  |  |  |
| All others | 12,294 |  |  | 8,329 |  |  |  |  |  |
| Total revenues by market sector | $ | 194,017 |  |  | $ | 126,858 |  |  |  |  |  |

- removed (2024-05-01):
[0000080420-24-000008:note_history:16]
|  | Three months ended December 31, |  |  |
|  | 2023 |  | 2022 |  |  |  |  |
| United States | $ | 159,860 |  |  | $ | 100,112 |  |  |  |  |  |
| Canada | 20,350 |  |  | 18,496 |  |  |  |  |  |
| Europe | 6,532 |  |  | 4,134 |  |  |  |  |  |
| Middle East and Africa | 3,275 |  |  | 2,425 |  |  |  |  |  |
| Mexico, Central and South America | 2,657 |  |  | 915 |  |  |  |  |  |
| Asia/Pacific | 1,343 |  |  | 776 |  |  |  |  |  |
| Total revenues by geographic destination | $ | 194,017 |  |  | $ | 126,858 |  |  |  |  |  |


## us-gaap:RevenueFromContractWithCustomerPolicyTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2024-05-01):
[0000080420-24-000030:note_history:17]
We also have contracts to provide field service inspection, installation, commissioning, modification, and repair services, as well as retrofit and retrofill components for existing systems. If the service contract terms give us the right to invoice the customer for an amount that corresponds directly with the value of our performance completed to date (i.e., a service contract in which we bill a fixed amount for each hour of service provided), then we recognize revenue over time in each reporting period corresponding to the amount that we have the right to invoice. Our performance obligations are satisfied as the work progresses. Revenues from our custom-engineered products and value-added services transferred to customers over time accounted for approximately 95% of revenues for the three months ended March 31, 2024, 94% of revenues for the six months ended March 31, 2024, and 93% of revenues for the three and six months ended March 31, 2023.
  (was, 2024-01-31, similarity 0.704):
[0000080420-24-000008:note_history:17]
We also have contracts to provide field service inspection, installation, commissioning, modification, and repair services, as well as retrofit and retrofill components for existing systems. If the service contract terms give us the right to invoice the customer for an amount that corresponds directly with the value of our performance completed to date (i.e., a service contract in which we bill a fixed amount for each hour of service provided), then we recognize revenue over time in each reporting period

- changed (2024-05-01):
[0000080420-24-000030:note_history:18]
We also have sales orders for spare parts and replacement circuit breakers for switchgear that are obsolete or that are no longer produced by the original manufacturer. Revenues from these sales orders are recognized at the time we fulfill our performance obligation to the customer, which is typically upon shipment and represented approximately 5% of revenues for the three months ended March 31, 2024, 6% of revenues for the six months ended March 31, 2024, and 7% of revenues for the three and six months ended March 31, 2023.
  (was, 2024-01-31, similarity 0.8498):
[0000080420-24-000008:note_history:18]
We also have sales orders for spare parts and replacement circuit breakers for switchgear that are obsolete or that are no longer produced by the original manufacturer. Revenues from these sales orders are recognized at the time we fulfill our performance obligation to the customer, which is typically upon shipment and represented approximately 6% of revenues for the three months ended December 31, 2023 and 7% of revenues for the three months ended December 31, 2022.

- removed (2024-05-01):
[0000080420-24-000008:note_history:19]
corresponding to the amount that we have the right to invoice. Our performance obligations are satisfied as the work progresses. Revenues from our custom-engineered products and value-added services transferred to customers over time accounted for approximately 94% of revenues for the three months ended December 31, 2023 and 93% of revenues for the three months ended December 31, 2022.


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2024-05-01):
[0000080420-24-000030:note_history:20]
We also have contracts to provide field service inspection, installation, commissioning, modification, and repair services, as well as retrofit and retrofill components for existing systems. If the service contract terms give us the right to invoice the customer for an amount that corresponds directly with the value of our performance completed to date (i.e., a service contract in which we bill a fixed amount for each hour of service provided), then we recognize revenue over time in each reporting period corresponding to the amount that we have the right to invoice. Our performance obligations are satisfied as the work progresses. Revenues from our custom-engineered products and value-added services transferred to customers over time accounted for approximately 95% of revenues for the three months ended March 31, 2024, 94% of revenues for the six months ended March 31, 2024, and 93% of revenues for the three and six months ended March 31, 2023.
  (was, 2024-01-31, similarity 0.704):
[0000080420-24-000008:note_history:20]
We also have contracts to provide field service inspection, installation, commissioning, modification, and repair services, as well as retrofit and retrofill components for existing systems. If the service contract terms give us the right to invoice the customer for an amount that corresponds directly with the value of our performance completed to date (i.e., a service contract in which we bill a fixed amount for each hour of service provided), then we recognize revenue over time in each reporting period

- changed (2024-05-01):
[0000080420-24-000030:note_history:21]
We also have sales orders for spare parts and replacement circuit breakers for switchgear that are obsolete or that are no longer produced by the original manufacturer. Revenues from these sales orders are recognized at the time we fulfill our performance obligation to the customer, which is typically upon shipment and represented approximately 5% of revenues for the three months ended March 31, 2024, 6% of revenues for the six months ended March 31, 2024, and 7% of revenues for the three and six months ended March 31, 2023.
  (was, 2024-01-31, similarity 0.8498):
[0000080420-24-000008:note_history:21]
We also have sales orders for spare parts and replacement circuit breakers for switchgear that are obsolete or that are no longer produced by the original manufacturer. Revenues from these sales orders are recognized at the time we fulfill our performance obligation to the customer, which is typically upon shipment and represented approximately 6% of revenues for the three months ended December 31, 2023 and 7% of revenues for the three months ended December 31, 2022.

- changed (2024-05-01):
[0000080420-24-000030:note_history:22]
Remaining unsatisfied performance obligations, which we refer to as backlog, represent the estimated transaction price for goods and services for which we have a material right, but work has not been performed. As of March 31, 2024, we had backlog of $1.3 billion, of which approximately $733 million is expected to be recognized as revenue within the next twelve
  (was, 2024-01-31, similarity 0.7205):
[0000080420-24-000008:note_history:22]
Remaining unsatisfied performance obligations, which we refer to as backlog, represent the estimated transaction price for goods and services for which we have a material right, but work has not been performed. As of December 31, 2023, we had backlog of $1.3 billion, of which approximately $713 million is expected to be recognized as revenue within the next twelve months. Backlog may not be indicative of future operating results as orders may be cancelled or modified by our customers. Our backlog does not include service and maintenance-type contracts for which we have the right to invoice as services are performed.

- added (2024-05-01):
[0000080420-24-000030:note_history:23]
months. Backlog may not be indicative of future operating results as orders may be cancelled or modified by our customers. Our backlog does not include service and maintenance-type contracts for which we have the right to invoice as services are performed.

- changed (2024-05-01):
[0000080420-24-000030:note_history:24]
For the six months ended March 31, 2024 and 2023, our operating results were positively impacted by $7.8 million and $7.4 million, respectively, as a result of net changes in contract estimates related to projects in progress at the beginning of the respective period. These changes in estimates resulted primarily from favorable project execution, reduced cost estimates and negotiations of variable consideration, discussed below, as well as revenue recognized from project cancellations and other changes in facts and circumstances during these periods. Gross unfavorable changes in contract estimates were immaterial for both the six months ended March 31, 2024 and 2023.
  (was, 2024-01-31, similarity 0.9103):
[0000080420-24-000008:note_history:24]
For the three months ended December 31, 2023 and 2022, our operating results were positively impacted by $5.4 million and $3.6 million, respectively, as a result of net changes in contract estimates related to projects in progress at the beginning of the respective period. These changes in estimates resulted primarily from favorable project execution, reduced cost estimates and negotiations of variable consideration, discussed below, as well as revenue recognized from project cancellations and other changes in facts and circumstances during these periods. Gross unfavorable changes in contract estimates were immaterial for both the three months ended December 31, 2023 and 2022.

- changed (2024-05-01):
[0000080420-24-000030:note_history:25]
Contract assets and liabilities as of March 31, 2024 and September 30, 2023 are summarized below (in thousands):
  (was, 2024-01-31, similarity 0.9565):
[0000080420-24-000008:note_history:25]
Contract assets and liabilities as of December 31, 2023 and September 30, 2023 are summarized below (in thousands):

- changed (2024-05-01):
[0000080420-24-000030:note_history:26]
|  | March 31, 2024 |  | September 30, 2023 |
| Contract assets | $ | 75,010 |  |  | $ | 60,621 |  |
| Contract liabilities | (315,699) |  |  | (279,796) |  |
| Net contract liability | $ | (240,689) |  |  | $ | (219,175) |  |
  (was, 2024-01-31, similarity 0.9739):
[0000080420-24-000008:note_history:26]
|  | December 31, 2023 |  | September 30, 2023 |
| Contract assets | $ | 67,594 |  |  | $ | 60,621 |  |
| Contract liabilities | (328,888) |  |  | (279,796) |  |
| Net contract liability | $ | (261,294) |  |  | $ | (219,175) |  |

- changed (2024-05-01):
[0000080420-24-000030:note_history:27]
Our net contract billing position remained a net liability at both March 31, 2024 and September 30, 2023, primarily due to favorable contract billing milestones. We typically allocate a significant percentage of the progress billing to the early stages of the contract. These favorable billing milestones are driving the increase in the net contract liability at March 31, 2024. To determine the amount of revenue recognized during the period from contract liabilities, we first allocate revenue to the individual contract liability balance outstanding at the beginning of the period until the revenue exceeds that balance. During the six months ended March 31, 2024, we recognized revenue of $185.4 million that was related to contract liabilities outstanding at September 30, 2023.
  (was, 2024-01-31, similarity 0.9504):
[0000080420-24-000008:note_history:27]
Our net contract billing position remained a net liability at both December 31, 2023 and September 30, 2023, primarily due to favorable contract billing milestones. We typically allocate a significant percentage of the progress billing to the early stages of the contract. These favorable billing milestones are driving the increase in the net contract liability at December 31, 2023. To determine the amount of revenue recognized during the period from contract liabilities, we first allocate revenue to the individual contract liability balance outstanding at the beginning of the period until the revenue exceeds that balance. During the three months ended December 31, 2023, we recognized revenue of $103.5 million that was related to contract liabilities outstanding at September 30, 2023.

- changed (2024-05-01):
[0000080420-24-000030:note_history:28]
The timing of our invoice process is typically dependent on the completion of certain milestones and contract terms and subject to agreement by our customer. Payment is typically expected within 30 days of invoice. Any uncollected invoiced amounts for our performance obligations recognized over time, including contract retentions, are recorded as accounts receivable in the Condensed Consolidated Balance Sheets. Certain contracts allow customers to withhold a small percentage of billings pursuant to retainage provisions, and such amounts are generally due upon completion of the contract and acceptance of the project by the customer. Based on our experience in recent years, the majority of these retainage balances are expected to be collected within approximately twelve months. As of both March 31, 2024 and September 30, 2023, we had retention amounts of $7.4 million. Of the retained amount at March 31, 2024, $7.1 million is expected to be collected in the next twelve months and is recorded in accounts receivable. The remaining $0.3 million is recorded in other assets.
  (was, 2024-01-31, similarity 0.8231):
[0000080420-24-000008:note_history:28]
The timing of our invoice process is typically dependent on the completion of certain milestones and contract terms and subject to agreement by our customer. Payment is typically expected within 30 days of invoice. Any uncollected invoiced amounts for our performance obligations recognized over time, including contract retentions, are recorded as accounts receivable in the Condensed Consolidated Balance Sheets. Certain contracts allow customers to withhold a small percentage of billings pursuant to retainage provisions, and such amounts are generally due upon completion of the contract and acceptance of the project by the customer. Based on our experience in recent years, the majority of these retainage balances are expected to be collected within approximately twelve months. As of December 31, 2023 and September 30, 2023, we had retention amounts of $7.3 million and $7.4 million, respectively. Of the retained amount at December 31, 2023, $7.1 million is expected to be collected in the next twelve months and is recorded in accounts receivable. The remaining $0.2 million is recorded in other assets.

- changed (2024-05-01):
[0000080420-24-000030:note_history:29]
The following tables present our disaggregated revenue by geographic destination and market sector for the three and six months ended March 31, 2024 and 2023 (in thousands):
  (was, 2024-01-31, similarity 0.9477):
[0000080420-24-000008:note_history:29]
The following tables present our disaggregated revenue by geographic destination and market sector for the three months ended December 31, 2023 and 2022 (in thousands):

- added (2024-05-01):
[0000080420-24-000030:note_history:30]
|  | Three months ended March 31, |  | Six months ended March 31, |
|  | 2024 |  | 2023 |  | 2024 |  | 2023 |
| United States | $ | 216,933 |  |  | $ | 134,161 |  |  | $ | 376,793 |  |  | $ | 234,273 |  |
| Canada | 24,160 |  |  | 21,995 |  |  | 44,510 |  |  | 40,491 |  |
| Europe | 8,265 |  |  | 7,953 |  |  | 14,797 |  |  | 12,087 |  |
| Middle East and Africa | 2,803 |  |  | 4,004 |  |  | 6,078 |  |  | 6,429 |  |
| Mexico, Central and South America | 2,159 |  |  | 1,543 |  |  | 4,816 |  |  | 2,458 |  |
| Asia/Pacific | 788 |  |  | 1,788 |  |  | 2,131 |  |  | 2,564 |  |
| Total revenues by geographic destination | $ | 255,108 |  |  | $ | 171,444 |  |  | $ | 449,125 |  |  | $ | 298,302 |  |

- changed (2024-05-01):
[0000080420-24-000030:note_history:31]
|  | Three months ended March 31, |  | Six months ended March 31, |
|  | 2024 |  | 2023 |  | 2024 |  | 2023 |
| Oil and gas (excludes petrochemical) | $ | 103,820 |  |  | $ | 62,597 |  |  | $ | 187,456 |  |  | $ | 106,107 |  |
| Petrochemical | 50,070 |  |  | 25,887 |  |  | 78,437 |  |  | 48,377 |  |
| Electric utility | 47,502 |  |  | 42,668 |  |  | 88,205 |  |  | 71,075 |  |
| Commercial and other industrial | 34,894 |  |  | 22,270 |  |  | 59,566 |  |  | 39,320 |  |
| Light rail traction power | 4,517 |  |  | 7,317 |  |  | 8,862 |  |  | 14,389 |  |
| All others | 14,305 |  |  | 10,705 |  |  | 26,599 |  |  | 19,034 |  |
| Total revenues by market sector | $ | 255,108 |  |  | $ | 171,444 |  |  | $ | 449,125 |  |  | $ | 298,302 |  |
  (was, 2024-01-31, similarity 0.6554):
[0000080420-24-000008:note_history:31]
|  | Three months ended December 31, |  |  |
|  | 2023 |  | 2022 |  |  |  |  |
| Oil and gas (excludes petrochemical) | $ | 83,636 |  |  | $ | 43,510 |  |  |  |  |  |
| Petrochemical | 28,367 |  |  | 22,490 |  |  |  |  |  |
| Electric utility | 40,703 |  |  | 28,407 |  |  |  |  |  |
| Commercial and other industrial | 24,672 |  |  | 17,050 |  |  |  |  |  |
| Traction power | 4,345 |  |  | 7,072 |  |  |  |  |  |
| All others | 12,294 |  |  | 8,329 |  |  |  |  |  |
| Total revenues by market sector | $ | 194,017 |  |  | $ | 126,858 |  |  |  |  |  |

- removed (2024-05-01):
[0000080420-24-000008:note_history:32]
corresponding to the amount that we have the right to invoice. Our performance obligations are satisfied as the work progresses. Revenues from our custom-engineered products and value-added services transferred to customers over time accounted for approximately 94% of revenues for the three months ended December 31, 2023 and 93% of revenues for the three months ended December 31, 2022.

- removed (2024-05-01):
[0000080420-24-000008:note_history:33]
|  | Three months ended December 31, |  |  |
|  | 2023 |  | 2022 |  |  |  |  |
| United States | $ | 159,860 |  |  | $ | 100,112 |  |  |  |  |  |
| Canada | 20,350 |  |  | 18,496 |  |  |  |  |  |
| Europe | 6,532 |  |  | 4,134 |  |  |  |  |  |
| Middle East and Africa | 3,275 |  |  | 2,425 |  |  |  |  |  |
| Mexico, Central and South America | 2,657 |  |  | 915 |  |  |  |  |  |
| Asia/Pacific | 1,343 |  |  | 776 |  |  |  |  |  |
| Total revenues by geographic destination | $ | 194,017 |  |  | $ | 126,858 |  |  |  |  |  |


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: tag_name, score: 1.0

- changed (2024-05-01):
[0000080420-24-000030:note_history:34]
On April 30, 2024, our Board of Directors declared a quarterly cash dividend on our common stock in the amount of $0.2650 per share. The dividend is payable on June 12, 2024 to stockholders of record at the close of business on May 15, 2024.
  (was, 2024-01-31, similarity 0.6248):
[0000080420-24-000008:note_history:34]
On January 30, 2024, our Board of Directors approved an increase to the quarterly cash dividend on our common stock to $0.2650 per share, equating to an annualized dividend of $1.06 per share from the current amount of $1.05 per share. The dividend is payable on March 13, 2024 to shareholders of record at the close of business on February 14, 2024.
