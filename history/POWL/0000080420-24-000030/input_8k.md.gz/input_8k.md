# POWL 8-K — 0000080420-24-000026 filed 2024-04-30

## item codes, every 8-K on or before 2024-05-01

- 2024-04-30 0000080420-24-000026 — 2.02, 8.01, 9.01
- 2024-02-15 0000080420-24-000014 — 5.02, 5.07
- 2024-01-30 0000080420-24-000005 — 2.02, 8.01, 9.01
- 2024-01-08 0000080420-24-000002 — 5.02
- 2023-12-05 0000080420-23-000047 — 2.02, 9.01
- 2023-11-03 0000080420-23-000044 — 8.01, 9.01
- 2023-10-11 0000080420-23-000041 — 1.01, 2.03
- 2023-08-01 0000080420-23-000036 — 2.02, 8.01, 9.01
- 2023-05-19 0001193125-23-149334 — 5.07 — amendment of 0000080420-23-000011
- 2023-05-03 0000080420-23-000025 — 2.02, 8.01, 9.01
- 2023-04-06 0000080420-23-000020 — 1.01, 2.03, 9.01
- 2023-04-05 0000080420-23-000018 — 5.02
- 2023-02-16 0000080420-23-000011 — 5.02, 5.07, 9.01
- 2023-01-31 0000080420-23-000004 — 2.02, 8.01
- 2022-12-05 0000080420-22-000034 — 2.02, 9.01
- 2022-08-02 0000080420-22-000030 — 2.02, 8.01, 9.01
- 2022-05-13 0000080420-22-000024 — 5.02, 9.01
- 2022-05-03 0000080420-22-000016 — 2.02, 9.01
- 2022-05-03 0000080420-22-000015 — 8.01, 9.01
- 2022-02-17 0000080420-22-000010 — 5.07
- 2022-02-08 0000080420-22-000005 — 2.02, 9.01
- 2022-02-01 0000080420-22-000002 — 8.01, 9.01
- 2021-12-07 0000080420-21-000043 — 2.02, 9.01
- 2021-08-03 0000080420-21-000036 — 2.02, 8.01, 9.01
- 2021-05-04 0000080420-21-000026 — 2.02, 8.01, 9.01
- 2021-03-16 0001193125-21-082878 — 1.01, 2.03, 9.01
- 2021-03-05 0000080420-21-000021 — 5.02, 8.01, 9.01
- 2021-02-26 0000080420-21-000018 — 5.03
- 2021-02-18 0000080420-21-000016 — 5.07
- 2021-02-02 0000080420-21-000010 — 2.02, 8.01, 9.01
- 2020-12-08 0000080420-20-000032 — 2.02, 9.01
- 2020-11-12 0000080420-20-000030 — 8.01, 9.01
- 2020-08-04 0000080420-20-000024 — 2.02, 8.01, 9.01
- 2020-05-05 0000080420-20-000017 — 2.02, 8.01, 9.01
- 2020-02-21 0000080420-20-000008 — 5.07
- 2020-02-04 0000080420-20-000003 — 2.02, 8.01, 9.01
- 2019-12-04 0001193125-19-306243 — 2.02, 9.01
- 2019-11-08 0000080420-19-000032 — 8.01, 9.01
- 2019-10-03 0000080420-19-000030 — 1.01, 2.03
- 2019-09-24 0000080420-19-000028 — 8.01, 9.01
- 2019-08-06 0000080420-19-000022 — 2.02, 8.01, 9.01
- 2019-05-08 0000080420-19-000017 — 5.02, 9.01
- 2019-05-07 0000080420-19-000011 — 2.02, 8.01, 9.01
- 2019-02-22 0001193125-19-048366 — 5.07
- 2019-02-05 0000080420-19-000003 — 2.02, 8.01
- 2018-12-21 0000080420-18-000038 — 5.02, 9.01
- 2018-12-12 0000080420-18-000031 — 2.02
- 2018-11-05 0000080420-18-000029 — 8.01, 9.01
- 2018-11-01 0000080420-18-000027 — 5.02, 8.01, 9.01
- 2018-10-01 0000080420-18-000024 — 5.02
- 2018-08-07 0000080420-18-000020 — 2.02, 8.01
- 2018-05-15 0000080420-18-000016 — 5.02, 8.01
- 2018-05-09 0000080420-18-000011 — 2.02, 8.01
- 2018-02-22 0000080420-18-000009 — 5.07
- 2018-02-06 0000080420-18-000003 — 2.02, 8.01
- 2017-12-27 0001193125-17-379928 — 5.02
- 2017-12-05 0000080420-17-000028 — 2.02, 9.01
- 2017-11-08 0000080420-17-000024 — 8.01, 9.01
- 2017-11-03 0000080420-17-000022 — 5.02
- 2017-08-09 0000080420-17-000017 — 2.02, 8.01
- 2017-06-30 0000080420-17-000014 — 1.01, 9.01
- 2017-05-03 0000080420-17-000006 — 2.02, 8.01, 9.01
- 2017-02-23 0000080420-17-000004 — 5.07
- 2017-02-08 0001628280-17-000965 — 2.02 — amendment of 0001628280-17-000949
- 2017-02-07 0001628280-17-000949 — 2.01, 8.01, 9.01
- 2016-12-07 0001193125-16-787354 — 2.02, 9.01
- 2016-11-01 0001193125-16-755475 — 8.01, 9.01
- 2016-09-30 0001193125-16-726999 — 5.02, 8.01, 9.01
- 2016-08-03 0001193125-16-669308 — 2.02, 8.01, 9.01
- 2016-05-04 0001193125-16-576528 — 2.02, 8.01, 9.01
- 2016-02-25 0001193125-16-477896 — 5.07
- 2016-02-03 0001193125-16-449052 — 2.02, 8.01, 9.01
- 2015-12-31 0001193125-15-418363 — 5.02, 7.01, 9.01
- 2015-12-02 0001193125-15-393109 — 2.02, 9.01
- 2015-11-05 0001193125-15-368085 — 8.01, 9.01
- 2015-09-25 0001193125-15-329031 — 5.02
- 2015-08-05 0001193125-15-277912 — 2.02, 8.01, 9.01
- 2015-05-06 0001193125-15-174291 — 2.02, 8.01, 9.01
- 2015-03-06 0001193125-15-081070 — 5.02
- 2015-03-02 0001193125-15-072946 — 5.07
- 2015-02-03 0001193125-15-031772 — 2.02, 8.01, 9.01
- 2014-12-18 0001193125-14-446513 — 8.01, 9.01
- 2014-12-03 0001193125-14-431745 — 2.02, 9.01
- 2014-11-05 0001193125-14-397955 — 8.01, 9.01
- 2014-09-26 0001193125-14-353741 — 7.01, 9.01
- 2014-08-05 0001193125-14-296001 — 2.02, 8.01, 9.01
- 2014-05-07 0001193125-14-187496 — 2.02, 8.01, 9.01
- 2014-03-03 0001193125-14-079843 — 5.02, 5.07
- 2014-02-05 0001193125-14-036633 — 2.02, 8.01, 9.01
- 2014-01-17 0001193125-14-014351 — 1.01, 8.01, 9.01
- 2014-01-06 0001193125-14-002795 — 1.01, 2.03
- 2013-12-06 0001564590-13-001411 — 2.02, 9.01
- 2013-12-05 0001564590-13-001406 — 5.02, 8.01, 9.01
- 2013-11-07 0001193125-13-432950 — 8.01, 9.01
- 2013-08-07 0001193125-13-324337 — 2.02, 9.01
- 2013-05-08 0001193125-13-206800 — 2.02, 9.01
- 2013-02-22 0001193125-13-070971 — 5.02, 5.07
- 2013-02-06 0001193125-13-040556 — 2.02, 9.01
- 2012-12-18 0001193125-12-506417 — 5.02, 9.01
- 2012-12-05 0001193125-12-491749 — 2.02, 9.01
- 2012-10-12 0001193125-12-421889 — 3.03, 5.02, 5.03, 9.01
- 2012-08-09 0001193125-12-344617 — 5.02, 8.01, 9.01
- 2012-08-08 0001193125-12-343630 — 2.02, 9.01
- 2012-05-09 0001193125-12-221356 — 2.02, 9.01
- 2012-02-08 0001193125-12-046560 — 2.02, 9.01
- 2011-12-08 0001193125-11-334810 — 2.02, 9.01
- 2011-11-08 0000950123-11-096524 — 2.02, 2.06, 4.02, 9.01
- 2011-10-14 0000950123-11-090124 — 5.02
- 2011-10-06 0000950123-11-088969 — 5.02
- 2011-09-19 0000950123-11-085224 — 5.02, 9.01
- 2011-09-15 0000950123-11-084806 — 5.02, 9.01
- 2011-08-04 0000950123-11-072788 — 2.02, 9.01
- 2011-07-22 0000950123-11-067402 — 5.07
- 2011-05-24 0000950123-11-053550 — 1.01, 2.03, 9.01
- 2011-05-04 0000950123-11-044561 — 2.02, 9.01
- 2011-02-02 0000950123-11-008188 — 2.02, 9.01
- 2010-12-08 0000950123-10-111987 — 2.02, 9.01
- 2010-08-05 0000950123-10-073114 — 2.02, 9.01
- 2010-05-18 0000950123-10-050900 — 5.02
- 2010-05-05 0000950123-10-044499 — 2.02, 9.01
- 2010-02-03 0000950123-10-008278 — 2.02, 9.01
- 2009-12-21 0000950123-09-072269 — 1.01, 2.01, 2.03, 8.01, 9.01
- 2009-12-09 0000950123-09-069525 — 2.02, 9.01
- 2009-10-27 0000950123-09-053501 — 1.01, 8.01, 9.01
- 2009-08-04 0000950123-09-029476 — 2.02, 9.01
- 2009-05-06 0000950129-09-001498 — 2.02, 9.01
- 2009-03-05 0000950129-09-000749 — 1.01, 9.01
- 2009-02-10 0000950129-09-000349 — 2.02, 9.01
- 2008-12-10 0000950134-08-021934 — 2.02, 9.01
- 2008-08-06 0000950129-08-004267 — 2.02, 9.01
- 2008-07-24 0000950129-08-004063 — 1.01, 5.02, 8.01, 9.01
- 2008-06-16 0000950129-08-003500 — 9.01 — amendment of 0000950134-06-015374
- 2008-06-05 0000950129-08-003378 — 5.02, 9.01
- 2008-05-08 0000950129-08-002843 — 2.02, 9.01
- 2008-02-06 0000950129-08-000533 — 2.02, 9.01
- 2007-12-19 0000950129-07-006277 — 1.01, 2.03, 9.01
- 2007-12-06 0000950129-07-006003 — 2.02, 9.01
- 2007-08-21 0000950129-07-004181 — 2.02, 9.01
- 2007-05-31 0000950129-07-002810 — 2.02, 9.01
- 2007-05-21 0000950129-07-002668 — 2.02, 3.01, 4.02, 9.01
- 2007-04-16 0000950129-07-002002 — 2.02, 4.02, 9.01
- 2007-03-01 0000950129-07-001104 — 5.02, 8.01, 9.01
- 2007-02-08 0000950129-07-000451 — 2.02, 9.01
- 2006-12-08 0000950129-06-010041 — 2.02, 9.01
- 2006-09-08 0000950129-06-008379 — 2.02, 9.01
- 2006-08-09 0000950134-06-015374 — 1.01, 2.01, 8.01, 9.01
- 2006-06-08 0000950129-06-006127 — 2.02, 9.01
- 2006-03-09 0000950129-06-002455 — 2.02, 9.01
- 2005-12-16 0000950129-05-012031 — 2.02, 5.03, 9.01
- 2005-09-13 0000950129-05-009181 — 2.01, 9.01 — amendment of 0000950129-05-006889
- 2005-09-12 0000950129-05-009151 — 2.02, 9.01
- 2005-07-06 0000950129-05-006889 — 1.01, 1.02, 2.01, 2.03, 9.01
- 2005-06-10 0000950129-05-006128 — 2.02, 9.01
- 2005-04-20 0000080420-05-000031 — 5.02
- 2005-03-11 0000080420-05-000024 — 9.01
- 2005-02-25 0000080420-05-000018 — 7.01, 9.01
- 2005-01-21 0000080420-05-000009 — 7.01, 9.01
- 2004-12-17 0000080420-04-000049 — 2.02, 9.01
- 2004-11-01 0000080420-04-000045 — 8.01, 9.01
- 2004-10-08 0001169232-04-005133 — 2.05
- 2004-09-14 0000080420-04-000037 — 5.02
- 2004-09-02 0000080420-04-000030 — 2.02, 9.01
- 2004-06-08 0000080420-04-000021 — 7
- 2004-05-13 0000080420-04-000019 — 4
- 2004-02-27 0000080420-04-000013 — 7
- 2003-12-16 0000950129-03-006136 — 12, 7
- 2003-08-29 0000950129-03-004531 — 12, 7
- 2003-06-03 0000950129-03-003035 — 7, 9
- 2003-05-15 0000950129-03-002812 — 7, 9
- 2002-05-29 0000950129-02-002795 — 4
- 2000-12-21 0000950129-00-006093 — 5, 7
- 1998-09-04 0000950129-98-003802 — 5
- 1996-08-09 0000950129-96-001705 — 2, 7

## late-filing notifications on or before 2024-05-01

- 2007-05-11 0000950129-07-002494 — NT 10-Q, for the period ended 2007-03-31
- 2005-01-18 0000080420-05-000004 — NT 10-K, for the period ended 2004-10-31

## item 2.02 — earnings release, exhibit 99.1

[0000080420-24-000026:8k_2_02:1]
EX-99.1
2
ex991-powlq2xfy2024earning.htm
EX-99.1

[0000080420-24-000026:8k_2_02:2]
Document

[0000080420-24-000026:8k_2_02:3]
Exhibit 99.1

[0000080420-24-000026:8k_2_02:4]
PRESS RELEASE

[0000080420-24-000026:8k_2_02:5]
For Immediate Release

[0000080420-24-000026:8k_2_02:6]
|  |  |  | Contacts: | Michael W. Metcalf, CFO |
|  |  |  |  | Powell Industries, Inc. |
|  |  |  |  | 713-947-4422 |
|  |  |  |  | Robert Winters or Ryan Coleman |
|  |  |  |  | Alpha IR Group |
|  |  |  |  | POWL@alpha-ir.com |
|  |  |  |  | 312-445-2870 |

[0000080420-24-000026:8k_2_02:7]
POWELL INDUSTRIES ANNOUNCES FISCAL 2024 SECOND QUARTER RESULTS

[0000080420-24-000026:8k_2_02:8]
HOUSTON — April 30, 2024 — Powell Industries, Inc. (NASDAQ: POWL), a leading supplier of custom-engineered solutions for the management, control and distribution of electrical energy, today announced results for the Fiscal 2024 second quarter ended March 31, 2024. All comparisons are to the second quarter of Fiscal 2023, unless otherwise noted.

[0000080420-24-000026:8k_2_02:9]
Second Quarter Key Highlights:

[0000080420-24-000026:8k_2_02:10]
•Revenues totaled $255 million, an increase of 49%;

[0000080420-24-000026:8k_2_02:11]
•Gross profit of $63 million, or 24.6% of revenue, a 510 basis point improvement;

[0000080420-24-000026:8k_2_02:12]
•Net income of $33 million, or $2.75 per diluted share;

[0000080420-24-000026:8k_2_02:13]
•New orders(1) totaled $235 million;

[0000080420-24-000026:8k_2_02:14]
•Backlog(2) as of March 31, 2024, remained at $1.3 billion;

[0000080420-24-000026:8k_2_02:15]
•Cash and short-term investments as of March 31, 2024, totaled $365 million.

[0000080420-24-000026:8k_2_02:16]
Brett A. Cope, Powell’s Chairman and Chief Executive Officer, stated, “Powell delivered solid second quarter results supported by continued growth within our Industrial end markets as well as strong performances from both our Electric Utility and Commercial and Other Industrial markets. Revenue in the quarter was 49% higher than the second quarter of Fiscal 2023, while excellent project execution and volume leverage drove a 510 basis point improvement in gross margin to 24.6%. New orders of $235 million in the quarter were higher by 19% sequentially and

[0000080420-24-000026:8k_2_02:17]
were well-balanced across the markets we serve, keeping our backlog essentially unchanged at $1.3 billion. Overall, we are encouraged by both our financial performance in the first half of the year as well as the activity levels within each of the markets we serve.”

[0000080420-24-000026:8k_2_02:18]
Second Quarter 2024 Results

[0000080420-24-000026:8k_2_02:19]
Revenues totaled $255.1 million compared to $171.4 million in the second quarter of Fiscal 2023, and $194.0 million in the first fiscal quarter.  The increase compared to second quarter of Fiscal 2023 was primarily driven by strong growth across the Oil and Gas and Petrochemical sectors, which grew 66% and 93%, respectively. Revenue from the Commercial and Other Industrial sector increased 57%, and revenue from the Electric Utility sector grew 11%.

[0000080420-24-000026:8k_2_02:20]
Gross profit increased 88% to $62.7 million, or 24.6% of revenue, compared to $33.4 million, or 19.5% of revenue, in the second quarter of Fiscal 2023 and compares to $48.2 million, or 24.8% of revenue, in the first fiscal quarter.

[0000080420-24-000026:8k_2_02:21]
New orders totaled $235 million compared to $508 million in the second quarter of Fiscal 2023 and $198 million in the first fiscal quarter. The year-over-year decline was the result of two large, domestic projects in the LNG and Petrochemical markets awarded in the second quarter of Fiscal 2023.

[0000080420-24-000026:8k_2_02:22]
Backlog totaled $1.3 billion as of March 31, 2024, which was essentially flat sequentially compared to backlog as of December 31, 2023, and increased 25% compared to backlog of $1.0 billion as of March 31, 2023.

[0000080420-24-000026:8k_2_02:23]
Net income was $33.5 million, or $2.75 per diluted share, compared to $8.5 million, or $0.70 per diluted share, in the second quarter of Fiscal 2023 and $24.1 million, or $1.98 per diluted share, in the first fiscal quarter.

[0000080420-24-000026:8k_2_02:24]
Cope added, “Project activity across the markets we serve remains active. We anticipate that projects within the LNG market will continue to progress, however, based upon the recent pause on LNG export permitting by the Department of Energy, the timing of these future projects may be impacted.  We are experiencing continued growth of our Commercial and Other Industrial sector, as well as the Electric Utility sector, while also seeing strong activity related to energy transition projects.  We remain encouraged by the growth dynamics across the markets in which we compete and are well positioned to support these newer applications with Powell’s products and expertise.”

[0000080420-24-000026:8k_2_02:25]
OUTLOOK

[0000080420-24-000026:8k_2_02:26]
Commenting on the Company's outlook, Michael Metcalf, Powell’s Chief Financial Officer said, “We continue to expect another strong year of financial performance in Fiscal 2024 as our core Industrial end markets, as well as our Electric Utility and Commercial and Other Industrial markets, are exhibiting favorable dynamics and activity levels to support our growth. The quality and duration of our backlog, in conjunction with the level of commercial activity also support our expectation that this strong financial performance can be sustained throughout Fiscal 2024 and into Fiscal 2025. Our capacity initiatives focused on servicing current and future backlog remain on track and are progressing as planned, with our Gulf Coast fabrication yard expansion now fully utilized and helping to support the execution of our $1.3 billion backlog. We expect to complete the current capacity expansion initiative at our products factory in Houston by mid-Fiscal 2025, which will help to enable our initiatives to facilitate future growth.”

[0000080420-24-000026:8k_2_02:27]
CONFERENCE CALL

[0000080420-24-000026:8k_2_02:28]
Powell Industries has scheduled a conference call for Wednesday, May 1, 2024 at 11:00 a.m. Eastern time. To participate in the conference call, dial 1-833-953-2431 (domestic) or 1-412-317-5760 (international) at least 10 minutes before the call begins and ask for the Powell Industries conference call. A telephonic replay of the conference call will be available through May 8, 2024 and may be accessed by calling 1-877-344-7529 (domestic) or 1-412-317-0088 (international) and using passcode 4054049#.

[0000080420-24-000026:8k_2_02:29]
Investors, analysts and the general public will also have the opportunity to listen to the conference call over the Internet by visiting powellind.com. To listen to the live call on the web, please visit the website at least 15 minutes before the call begins to register, download and install any necessary audio software.  For those who cannot listen to the live webcast, an archive will be available shortly after the call and will remain available for approximately 90 days at powellind.com.

[0000080420-24-000026:8k_2_02:30]
About Powell Industries

[0000080420-24-000026:8k_2_02:31]
Powell Industries, Inc., headquartered in Houston, designs, manufactures and services custom-engineered equipment and systems for the distribution, control and monitoring of electrical energy.  Powell markets include large industrial customers such as utilities, data centers, oil and

[0000080420-24-000026:8k_2_02:32]
gas producers, refineries, liquefied natural gas facilities, petrochemical plants, pulp and paper producers, mining operations and commuter railways.   For more information, please visit powellind.com.

[0000080420-24-000026:8k_2_02:33]
4

[0000080420-24-000026:8k_2_02:34]
POWELL INDUSTRIES, INC. & SUBSIDIARIES

[0000080420-24-000026:8k_2_02:35]
CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS

[0000080420-24-000026:8k_2_02:36]
|  | Three Months Ended March 31, |  | Six Months Ended March 31, |
|  | 2024 |  | 2023 |  | 2024 |  | 2023 |
| (In thousands, except per share data) |  |  |  |  |  |  |  |
|  | (Unaudited) |
| Revenues | $ | 255,108 |  |  | $ | 171,444 |  |  | $ | 449,125 |  |  | $ | 298,302 |  |
| Cost of goods sold | 192,388 |  |  | 138,007 |  |  | 338,211 |  |  | 245,401 |  |
| Gross profit | 62,720 |  | 33,437 |  | 110,914 |  | 52,901 |
| Selling, general and administrative expenses | 20,947 |  |  | 21,820 |  |  | 41,294 |  |  | 38,693 |  |
| Research and development expenses | 2,284 |  |  | 1,543 |  |  | 4,251 |  |  | 3,044 |  |
| Operating income | 39,489 |  | 10,074 |  | 65,369 |  | 11,164 |
| Interest income, net | (4,428) |  |  | (899) |  |  | (8,426) |  |  | (1,423) |  |
| Income before income taxes | 43,917 |  | 10,973 |  | 73,795 |  | 12,587 |
| Income tax provision | 10,429 |  |  | 2,500 |  |  | 16,222 |  |  | 2,951 |  |
| Net income | $ | 33,488 |  |  | $ | 8,473 |  |  | $ | 57,573 |  |  | $ | 9,636 |  |
| Earnings per share: |  |  |  |  |  |  |  |
| Basic | $ | 2.79 |  |  | $ | 0.71 |  |  | $ | 4.81 |  |  | $ | 0.81 |  |
| Diluted | $ | 2.75 |  |  | $ | 0.70 |  |  | $ | 4.73 |  |  | $ | 0.80 |  |
| Weighted average shares: |  |  |  |  |  |  |  |
| Basic | 11,992 |  |  | 11,878 |  |  | 11,966 |  |  | 11,869 |  |
| Diluted | 12,191 |  |  | 12,149 |  |  | 12,167 |  |  | 12,109 |  |
| SELECTED FINANCIAL DATA: |  |  |  |  |  |  |  |
| Depreciation | $ | 1,724 |  |  | $ | 2,176 |  |  | $ | 3,365 |  |  | $ | 4,312 |  |
| Capital Expenditures | $ | 903 |  |  | $ | 630 |  |  | $ | 2,138 |  |  | $ | 3,356 |  |
| Dividends Paid | $ | 3,175 |  |  | $ | 3,106 |  |  | $ | 6,299 |  |  | $ | 6,180 |  |

[0000080420-24-000026:8k_2_02:37]
5

[0000080420-24-000026:8k_2_02:38]
POWELL INDUSTRIES, INC. & SUBSIDIARIES

[0000080420-24-000026:8k_2_02:39]
CONDENSED CONSOLIDATED BALANCE SHEETS

[0000080420-24-000026:8k_2_02:40]
|  | March 31, 2024 |  | September 30, 2023 |
| (In thousands) |  |  |  |
|  | (Unaudited) |
| Assets: |  |  |  |
| Cash, cash equivalents and short-term investments | $ | 365,339 |  |  | $ | 279,009 |  |
| Other current assets | 351,306 |  |  | 342,976 |  |
| Property, plant and equipment, net | 96,655 |  |  | 97,625 |  |
| Long-term assets | 36,318 |  |  | 32,632 |  |
| Total assets | $ | 849,618 |  |  | $ | 752,242 |  |
| Liabilities and equity: |  |  |  |
| Current liabilities | $ | 441,826 |  |  | $ | 395,686 |  |
| Deferred and other long-term liabilities | 14,007 |  |  | 11,530 |  |
| Stockholders’ equity | 393,785 |  |  | 345,026 |  |
| Total liabilities and stockholders’ equity | $ | 849,618 |  |  | $ | 752,242 |  |
| SELECTED FINANCIAL DATA: |  |  |  |
| Working capital | $ | 274,819 |  |  | $ | 226,299 |  |
| (1) New orders (bookings) represent the estimated value of contracts added to existing backlog (unsatisfied performance obligations). |
| (2) The amounts recorded in backlog may not be a reliable indicator of our future operating results and may not be indicative of continuing revenue performance over future fiscal quarters or years primarily due to unexpected contract adjustments, cancellations or scope reductions. |
