# POWL notes — 0000080420-19-000005


## us-gaap:AllowanceForCreditLossesOnFinancingReceivablesTableTextBlock

[0000080420-19-000005:notes:1]
[same as prior period, unchanged from 0000080420-18-000022:notes:1]

[0000080420-19-000005:notes:2]
|  | Three months ended December 31, |
|  | 2018 |  | 2017 |
| Balance at beginning of period | $ | 157 |  |  | $ | 179 |  |
| Bad debt expense (recovery) | 27 |  |  | (20 | ) |
| Uncollectible accounts written off, net of recoveries | (42 | ) |  | (1 | ) |
| Change due to foreign currency translation | (3 | ) |  | — |  |
| Balance at end of period | $ | 139 |  |  | $ | 158 |  |


## us-gaap:BasisOfAccountingPolicyPolicyTextBlock

[0000080420-19-000005:notes:3]
[same as prior period, unchanged from 0000080420-18-000022:notes:3]

[0000080420-19-000005:notes:4]
[same as prior period, unchanged from 0000080420-18-000022:notes:4]

[0000080420-19-000005:notes:5]
[same as prior period, unchanged from 0000080420-18-000022:notes:5]

[0000080420-19-000005:notes:6]
These unaudited condensed consolidated financial statements should be read in conjunction with the audited consolidated financial statements and notes thereto of Powell and its subsidiaries included in Powell’s Annual Report on Form 10-K for the year ended September 30, 2018, which was filed with the Securities and Exchange Commission (SEC) on December 12, 2018.

[0000080420-19-000005:notes:7]
References to Fiscal 2019 and Fiscal 2018 used throughout this report shall mean our fiscal years ended September 30, 2019 and 2018, respectively.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0000080420-19-000005:notes:8]
COMMITMENTS AND CONTINGENCIES

[0000080420-19-000005:notes:9]
Letters of Credit, Surety Bonds and Bank Guarantees

[0000080420-19-000005:notes:10]
Certain customers require us to post letters of credit or surety bonds which assure that we will perform under the terms of our contract. In the event of default, the counterparty may demand payment from the bank under a letter of credit or performance by the surety under a bond. To date, there have been no significant expenses related to either letters of credit or surety bonds for the periods reported. We were contingently liable for letters of credit of $15.2 million as of December 31, 2018. We also had surety bonds totaling $172.3 million that were outstanding, with additional bonding capacity of $577.7 million available, at December 31, 2018.

[0000080420-19-000005:notes:11]
Additionally, we have a $6.4 million facility agreement (Facility Agreement) between Powell (UK) Limited and a large international bank. This Facility Agreement provides Powell (UK) Limited the ability to enter into bank guarantees as well as forward exchange contracts and currency options. At December 31, 2018, we had outstanding guarantees totaling $3.9 million under this Facility Agreement and amounts available under this Facility Agreement were $2.5 million. The Facility Agreement provides for financial covenants and customary events of default, and carries cross-default provisions with our U.S. Revolver. If an event of default (as defined in the Facility Agreement) occurs and is continuing, per the terms and subject to the conditions set forth therein, obligations outstanding under the Facility Agreement may be accelerated and declared immediately due and payable. As of December 31, 2018, we were in compliance with all of the financial covenants of the Facility Agreement.

[0000080420-19-000005:notes:12]
Litigation

[0000080420-19-000005:notes:13]
We are involved in various legal proceedings, claims and other disputes arising from our commercial operations, projects, employees and other matters which, in general, are subject to uncertainties and in which the outcomes are not predictable. Although we can give no assurances about the resolution of pending claims, litigation or other disputes and the effect such outcomes may have on us, management believes that any ultimate liability resulting from the outcome of such proceedings, to the extent not otherwise provided or covered by insurance, will not have a material adverse effect on our consolidated financial position or results of operations or liquidity.


## us-gaap:ContractWithCustomerAssetAndLiabilityTableTextBlock

[0000080420-19-000005:notes:14]
Contract assets and liabilities as of December 31, 2018 and September 30, 2018 are summarized below (in thousands):

[0000080420-19-000005:notes:15]
|  | December 31, 2018 |  | September 30, 2018 |
| Contract assets | $ | 69,601 |  |  | $ | 82,545 |  |
| Contract liabilities | 51,410 |  |  | 43,174 |  |
| Net contract assets (liabilities) | $ | 18,191 |  |  | $ | 39,371 |  |


## us-gaap:DisaggregationOfRevenueTableTextBlock

[0000080420-19-000005:notes:16]
The following tables present our disaggregated revenue by geographic destination and market sector for the quarter ended December 31, 2018 (in thousands):

[0000080420-19-000005:notes:17]
|  | Three months ended December 31, 2018 |
| United States | $ | 89,898 |  |
| Canada | 9,715 |  |
| Europe, Middle East and Africa | 5,441 |  |
| Asia/Pacific | 3,744 |  |
| Mexico, Central and South America | 553 |  |
| Total revenues by geographic destination | $ | 109,351 |  |

[0000080420-19-000005:notes:18]
|  | Three months ended December 31, 2018 |
| Oil and gas | $ | 49,576 |  |
| Petrochemical | 19,778 |  |
| Electric utility | 19,258 |  |
| Traction power | 5,009 |  |
| All others | 15,730 |  |
| Total revenues by market sector | $ | 109,351 |  |


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0000080420-19-000005:notes:19]
[same as prior period, unchanged from 0000080420-18-000022:notes:18]

[0000080420-19-000005:notes:20]
Refer to our Annual Report on Form 10-K for the fiscal year ended September 30, 2018 for a full description of our existing stock-based compensation plans.

[0000080420-19-000005:notes:21]
[same as prior period, unchanged from 0000080420-18-000022:notes:20]

[0000080420-19-000005:notes:22]
We issue restricted stock units (RSUs) to certain officers and key employees of the Company. The fair value of the RSUs is based on the price of our common stock as reported on the NASDAQ Global Market on the grant dates. The typical annual grant vests over a three-year period from the date of issuance and is a blend of time-based and performance-based shares. The portion of the grant that is time-based typically vests over a three-year period on each anniversary of the grant date, based on continued employment. The performance-based shares vest based on the three-year earnings performance of the Company following the grant date. At December 31, 2018, there were 207,483 RSUs outstanding. The RSUs do not have voting rights but do receive dividend equivalents upon vesting; additionally, the shares of common stock underlying the RSUs are not considered issued and outstanding until vested and common stock is issued.

[0000080420-19-000005:notes:23]
RSU activity (number of shares) for the three months ended December 31, 2018 is summarized below:

[0000080420-19-000005:notes:24]
|  | Number ofRestrictedStockUnits |  | WeightedAverageFair ValuePer Share |
| Outstanding at September 30, 2018 | 190,500 |  |  | $ | 33.73 |  |
| Granted | 79,050 |  |  | 35.14 |  |
| Vested | (62,067 | ) |  | 30.52 |  |
| Outstanding at December 31, 2018 | 207,483 |  |  | $ | 34.74 |  |

[0000080420-19-000005:notes:25]
During the three months ended December 31, 2018 and 2017, we recorded compensation expense of $1.2 million and $1.0 million, respectively, related to the RSUs.

[0000080420-19-000005:notes:26]
[same as prior period, unchanged from 0000080420-18-000022:notes:25]

[0000080420-19-000005:notes:27]
Each non-employee director receives 2,000 restricted shares of the Company’s common stock annually. Fifty-percent of the restricted stock granted to each of our non-employee directors vests immediately, while the remaining fifty-percent vests on the anniversary of the grant date. Compensation expense is recognized immediately for the first fifty-percent of the restricted stock granted, while compensation expense for the remaining fifty-percent is recognized over the remaining vesting period based on the closing price per share on the grant date. During the three months ended December 31, 2018 and 2017, there were no restricted shares granted. During the three months ended December 31, 2018 and 2017, we recorded compensation expense of less than $0.1 million and $0.1 million, respectively, related to restricted stock.


## us-gaap:EarningsPerShareTextBlock

[0000080420-19-000005:notes:28]
[same as prior period, unchanged from 0000080420-18-000022:notes:28]

[0000080420-19-000005:notes:29]
[same as prior period, unchanged from 0000080420-18-000022:notes:29]

[0000080420-19-000005:notes:30]
[same as prior period, unchanged from 0000080420-18-000022:notes:30]

[0000080420-19-000005:notes:31]
|  | Three months ended December 31, |
|  | 2018 |  | 2017 |
| Numerator: |  |  |  |
| Net loss | $ | (2,695 | ) |  | $ | (5,662 | ) |
| Denominator: |  |  |  |
| Weighted average basic shares | 11,551 |  |  | 11,497 |  |
| Dilutive effect of restricted stock units | — |  |  | — |  |
| Weighted average diluted shares | 11,551 |  |  | 11,497 |  |
| Loss per share: |  |  |  |
| Basic | $ | (0.23 | ) |  | $ | (0.49 | ) |
| Diluted | $ | (0.23 | ) |  | $ | (0.49 | ) |

[0000080420-19-000005:notes:32]
For the three months ended December 31, 2018 and 2017, we incurred net losses and therefore all potential common shares were deemed to be anti-dilutive.


## us-gaap:FairValueDisclosuresTextBlock

[0000080420-19-000005:notes:33]
[same as prior period, unchanged from 0000080420-18-000022:notes:33]

[0000080420-19-000005:notes:34]
[same as prior period, unchanged from 0000080420-18-000022:notes:34]

[0000080420-19-000005:notes:35]
[same as prior period, unchanged from 0000080420-18-000022:notes:35]

[0000080420-19-000005:notes:36]
[same as prior period, unchanged from 0000080420-18-000022:notes:36]

[0000080420-19-000005:notes:37]
[same as prior period, unchanged from 0000080420-18-000022:notes:37]

[0000080420-19-000005:notes:38]
[same as prior period, unchanged from 0000080420-18-000022:notes:38]

[0000080420-19-000005:notes:39]
The following table summarizes the fair value of our assets and liabilities that were accounted for at fair value on a recurring basis as of December 31, 2018 (in thousands):

[0000080420-19-000005:notes:40]
|  | Fair Value Measurements at December 31, 2018 |
|  | Quoted Prices inActive Markets forIdentical Assets(Level 1) |  | Significant OtherObservableInputs(Level 2) |  | SignificantUnobservableInputs(Level 3) |  | Fair Value at December 31, 2018 |
| Assets: |  |  |  |  |  |  |  |
| Cash and cash equivalents | $ | 55,005 |  |  | $ | — |  |  | $ | — |  |  | $ | 55,005 |  |
| Short-term investments | 7,336 |  |  | — |  |  | — |  |  | 7,336 |  |
| Restricted cash | 15,890 |  |  | — |  |  | — |  |  | 15,890 |  |
| Other assets | — |  |  | 6,065 |  |  | — |  |  | 6,065 |  |
| Liabilities: |  |  |  |  |  |  |  |
| Deferred compensation | — |  |  | 5,596 |  |  | — |  |  | 5,596 |  |

[0000080420-19-000005:notes:41]
The following table summarizes the fair value of our assets and liabilities that were accounted for at fair value on a recurring basis as of September 30, 2018 (in thousands):

[0000080420-19-000005:notes:42]
|  | Fair Value Measurements at September 30, 2018 |
|  | Quoted Prices inActive Markets forIdentical Assets(Level 1) |  | Significant OtherObservableInputs(Level 2) |  | SignificantUnobservableInputs(Level 3) |  | Fair Value at September 30, 2018 |
| Assets: |  |  |  |  |  |  |  |
| Cash and cash equivalents | $ | 36,584 |  |  | $ | — |  |  | $ | — |  |  | $ | 36,584 |  |
| Short-term investments | 13,170 |  |  | — |  |  | — |  |  | 13,170 |  |
| Restricted cash | 25,141 |  |  |  |  |  |  | 25,141 |  |
| Other assets | — |  |  | 6,817 |  |  | — |  |  | 6,817 |  |
| Liabilities: |  |  |  |  |  |  |  |
| Deferred compensation | — |  |  | 5,644 |  |  | — |  |  | 5,644 |  |

[0000080420-19-000005:notes:43]
[same as prior period, unchanged from 0000080420-18-000022:notes:43]

[0000080420-19-000005:notes:44]
[same as prior period, unchanged from 0000080420-18-000022:notes:44]

[0000080420-19-000005:notes:45]
[same as prior period, unchanged from 0000080420-18-000022:notes:45]

[0000080420-19-000005:notes:46]
[same as prior period, unchanged from 0000080420-18-000022:notes:46]

[0000080420-19-000005:notes:47]
Restricted Cash – Restricted cash represents a pledged cash collateral balance which is required under our amended credit agreement and is held in an interest-bearing account. See Note E for further discussion on restricted cash.

[0000080420-19-000005:notes:48]
Other Assets/Deferred Compensation – We hold investments in an irrevocable Rabbi Trust for our deferred compensation plan. The assets include both mutual fund investments and company-owned life insurance policies and are included in other assets in the accompanying Condensed Consolidated Balance sheets. Because the mutual funds and company-owned life insurance policies are combined in the plan, they are categorized as Level 2 in the fair value measurement hierarchy. The deferred compensation liability represents the investment options that the plan participants have designated to serve as the basis for measurement of the notional value of their accounts. Because the deferred compensation liability is intended to offset the plan assets, it is also categorized as Level 2 in the fair value measurement hierarchy.

[0000080420-19-000005:notes:49]
There were no transfers between levels within the fair value measurement hierarchy during the quarter ended December 31, 2018.


## us-gaap:IncomeTaxDisclosureTextBlock

[0000080420-19-000005:notes:50]
[same as prior period, unchanged from 0000080420-18-000022:notes:50]

[0000080420-19-000005:notes:51]
[same as prior period, unchanged from 0000080420-18-000022:notes:51]

[0000080420-19-000005:notes:52]
|  | Three months ended December 31, |
|  | 2018 |  | 2017 |
| Loss before income taxes | $ | (2,934 | ) |  | $ | (6,733 | ) |
| Income tax benefit | (239 | ) |  | (1,071 | ) |
| Net loss | $ | (2,695 | ) |  | $ | (5,662 | ) |
| Effective tax rate | 8 | % |  | 16 | % |

[0000080420-19-000005:notes:53]
On December 22, 2017, the Tax Cuts and Jobs Act was signed into law, which lowered the corporate tax rate from 35% to 21% effective January 1, 2018. As a result, the U.S. federal statutory rate for Fiscal 2019 is 21%, compared to the blended statutory rate of 24.5% effective for Fiscal 2018.

[0000080420-19-000005:notes:54]
For the three months ended December 31, 2018, the effective tax rate was negatively impacted by a foreign tax loss that is reserved with a valuation allowance. The effective tax rate for the three months ended December 31, 2017 was similarly impacted by a foreign tax loss reserved with a valuation allowance, as well as $0.7 million tax expense related to the re-measurement of U.S. deferred tax assets as a result of tax reform.


## us-gaap:LongTermDebtTextBlock

[0000080420-19-000005:notes:55]
LONG-TERM DEBT

[0000080420-19-000005:notes:56]
Long-term debt consisted of the following (in thousands):

[0000080420-19-000005:notes:57]
|  | December 31, 2018 |  | September 30, 2018 |
| Industrial development revenue bonds | $ | 1,200 |  |  | $ | 1,600 |  |
| Less current portion | (400 | ) |  | (400 | ) |
| Total long-term debt | $ | 800 |  |  | $ | 1,200 |  |

[0000080420-19-000005:notes:58]
U.S. Revolver

[0000080420-19-000005:notes:59]
We have a $75.0 million revolving credit facility (U.S. Revolver) to provide working capital support and letters of credit which expires in June 2022. The amount available under the U.S. Revolver at December 31, 2018 was reduced by $15.2 million for our outstanding letters of credit. Currently, our U.S. Revolver can only be used for letters of credit until we meet certain financial ratios. There were no loans outstanding under the U.S. Revolver as of December 31, 2018.

[0000080420-19-000005:notes:60]
Per the terms of the U.S. Revolver, we are required to maintain cash in a pledged collateral account until we satisfy the following two financial ratios for two consecutive fiscal quarters: a max leverage ratio and a fixed charge coverage ratio. The max leverage ratio requires that the ratio of our consolidated funded indebtedness to our consolidated earnings before interest, taxes and depreciation (EBITDA) for the last four consecutive quarters not exceed 2.75 to 1.00. The fixed charge coverage ratio requires that the ratio of consolidated EBITDA for the last four fiscal quarters, less income taxes, capital expenditures, principal debt payments and interest charges be at least 1.25 to 1.00. If we are not in compliance with the these two ratios, we are required to maintain a cash balance in a pledged cash collateral account equal to 102% of the outstanding amount of any loans and letter of credit obligations until we meet the aforementioned required ratios. As of December 31, 2018, the balance in the cash collateral account was $15.9 million and is recorded as restricted cash in our Condensed Consolidated Balance Sheets. The portion of the cash collateral associated with the outstanding letters of credit that are due to expire beyond twelve months has been classified as non-current restricted cash on the balance sheet. As of December 31, 2018, there was $59.8 million available for the issuance of letters of credit under the U.S. Revolver, subject to the cash collateral requirements mentioned above.

[0000080420-19-000005:notes:61]
The interest rate for amounts outstanding under the U.S. Revolver is a floating rate based upon the higher of the Federal Funds Rate plus 0.5%, the bank’s prime rate, or the Eurocurrency rate plus 1.00%. Once the applicable rate is determined, a margin ranging up to 1.25% is added to the applicable rate.

[0000080420-19-000005:notes:62]
The U.S. Revolver is collateralized by a pledge of 100% of the voting capital stock of each of our domestic subsidiaries and 65% of the voting capital stock of each non-domestic subsidiary. The U.S. Revolver provides for customary events of default and carries cross-default provisions with other existing debt agreements. If an event of default (as defined in the U.S. Revolver) occurs and is continuing, on the terms and subject to the conditions set forth in the U.S. Revolver, amounts outstanding under the U.S. Revolver may be accelerated and may become immediately due and payable. It also contains financial covenants defining various financial measures and the levels of these measures with which we must comply, as well as a “material adverse change” clause. A “material adverse change” is defined as a material change in our operations, business, properties, liabilities or condition (financial or otherwise) or a material impairment of our ability to perform our obligations under our credit agreements. As of December 31, 2018, we were in compliance with all of the financial covenants of the U.S. Revolver.

[0000080420-19-000005:notes:63]
Industrial Development Revenue Bonds

[0000080420-19-000005:notes:64]
We borrowed $8.0 million in October 2001 through a loan agreement funded with proceeds from tax-exempt industrial development revenue bonds (Bonds). These Bonds were issued by the Illinois Development Finance Authority and were used for the completion of our Northlake, Illinois facility. Pursuant to the Bond issuance, a reimbursement agreement between us and a major domestic bank required an issuance by the bank of an irrevocable direct-pay letter of credit (Bond LC), as collateral, to the Bonds’ trustee to guarantee payment of the Bonds’ principal and interest when due. The Bond LC is subject to both early termination and extension provisions customary to such agreements, as well as various covenants, for which we were in compliance at December 31, 2018. While the Bonds mature in 2021, the reimbursement agreement requires annual redemptions of $0.4 million that commenced on October 25, 2002. A sinking fund is used for the redemption of the Bonds. The Bonds bear interest at a floating rate determined weekly by the Bonds’ remarketing agent, which was the underwriter for the Bonds and is an affiliate of the bank. This interest rate was 1.86% as of December 31, 2018.


## us-gaap:NewAccountingPronouncementsPolicyPolicyTextBlock

[0000080420-19-000005:notes:65]
New Accounting Standards

[0000080420-19-000005:notes:66]
In May 2014, the Financial Accounting Standards Board (FASB) issued a new standard on revenue recognition that supersedes previously issued revenue recognition guidance. This standard provides a five-step approach to be applied to all contracts with customers and requires expanded disclosures about the nature, amount, timing and uncertainty of revenue (and the related cash flows) arising from customer contracts, significant judgments and changes in judgments used in applying the revenue model and the assets recognized from costs incurred to obtain or fulfill a contract. Effective October 1, 2018, we adopted this standard using the modified retrospective basis. After evaluating the impact of this new standard on contracts outstanding as of October 1, 2018, we determined that no adjustment to retained earnings was necessary. See Note D for further discussion of revenue.

[0000080420-19-000005:notes:67]
In February 2016, the FASB issued a new topic on leases which requires lessees to recognize lease assets and lease liabilities on the balance sheet for all leases with terms longer than twelve months. Leases will be classified as either finance or operating, with classification affecting the pattern of expense recognition in the income statement. A modified retrospective transition approach is required for lessees for capital and operating leases existing at, or entered into after, the beginning of the earliest comparative period presented in the financial statements, with certain practical expedients available. The new topic is effective for fiscal years beginning after December 15, 2018, including interim periods within those fiscal years. This would be our fiscal year ending September 30, 2020. In Fiscal 2018, we acquired new lease software designed to assist with the transition and our migrating our existing leases. We are still evaluating the impact this new topic will have on our consolidated financial position and results of operations.

[0000080420-19-000005:notes:68]
In November 2016, the FASB issued a new topic on the statement of cash flows that changes the presentation of restricted cash and cash equivalents on the statement of cash flows. Restricted cash and restricted cash equivalents is to be included with cash and cash equivalents when reconciling the beginning-of-period and end-of-period total amounts shown on the statement of cash flows. We adopted this topic in Fiscal 2019 and our Condensed Consolidated Cash Flow Statements for all periods reflect this presentation.

[0000080420-19-000005:notes:69]
In May 2017, the FASB issued a new topic on modification accounting with regards to stock based compensation. This new topic clarifies when a change to the terms or conditions of a share-based payment award should be accounted for as a modification. An entity should account for the effects of a modification unless the fair value, vesting conditions and classification, as an equity instrument or a liability instrument, of the modified award are the same before and after a change to the terms or conditions of the share-based payment award. We adopted this topic in Fiscal 2019 and it has not had a material impact on our consolidated financial position or results of operations.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureAndSignificantAccountingPoliciesTextBlock

[0000080420-19-000005:notes:70]
[same as prior period, unchanged from 0000080420-18-000022:notes:72]

[0000080420-19-000005:notes:71]
[same as prior period, unchanged from 0000080420-18-000022:notes:73]

[0000080420-19-000005:notes:72]
[same as prior period, unchanged from 0000080420-18-000022:notes:74]

[0000080420-19-000005:notes:73]
We develop, design, manufacture and service custom-engineered products and systems for the distribution, control and monitoring of electrical energy. Headquartered in Houston, Texas, we serve the oil and gas markets, including onshore and offshore oil and gas production, pipeline, refining and liquid natural gas terminals, as well as petrochemical, electric utility and light traction power.

[0000080420-19-000005:notes:74]
[same as prior period, unchanged from 0000080420-18-000022:notes:76]

[0000080420-19-000005:notes:75]
The preparation of condensed consolidated financial statements in conformity with U.S. GAAP requires management to make estimates and assumptions that affect the amounts reported in the condensed consolidated financial statements and accompanying footnotes. The most significant estimates used in our condensed consolidated financial statements affect revenue recognition and estimated cost recognition on our customer contracts, the allowance for doubtful accounts, provision for excess and obsolete inventory, warranty accruals and income taxes. The amounts recorded for warranties, legal, income taxes, impairment of long-lived assets (when applicable) and other contingent liabilities require judgments regarding the amount of expenses that will ultimately be incurred. We base our estimates on historical experience and on various other assumptions, as well as the specific circumstances surrounding these contingent liabilities, in evaluating the amount of liability that should be recorded. Additionally, the recognition of deferred tax assets requires estimates related to future income and other assumptions regarding timing and future profitability because the ultimate realization of net deferred tax assets is dependent on the generation of future taxable income during the periods in which temporary differences become deductible. Estimates routinely change as new events occur, additional information becomes available or operating environments change. Actual results may differ from our prior estimates.


## us-gaap:RevenueFromContractWithCustomerPolicyTextBlock

[0000080420-19-000005:notes:76]
On October 1, 2018, we adopted the new revenue recognition standard using the modified retrospective transition method. We applied the guidance to customer contracts which were not substantially complete at that time and we determined that no adjustment to retained earnings was necessary. Financial results for reporting periods after October 1, 2018 are reported under the new guidance; however financial results for prior periods were not adjusted and will continue to be presented in accordance with the previous guidance.

[0000080420-19-000005:notes:77]
Revenue Recognition

[0000080420-19-000005:notes:78]
The majority of our revenues are generated from the manufacturing of custom engineered products and systems under long-term fixed price contracts under which we agree to manufacture various products such as traditional and arc-resistant distribution switchgear and control gear, medium-voltage circuit breakers, monitoring and control communications systems, motor control centers and bus duct systems. These products may be sold separately as an engineered solution, but are typically integrated into custom-built enclosures which we also build.  These enclosures are referred to as power control room substations (PCRs®), custom-engineered modules or electrical houses (E-Houses). Some contracts may also include the installation and the commissioning of these enclosures.

[0000080420-19-000005:notes:79]
Revenue from these contracts is generally recognized over time utilizing the cost to cost method to measure the extent of progress toward the completion of the performance obligation and the recognition of revenue over time. We believe that this method is the most accurate representation of our performance because it directly measures the value of the services transferred to the customer over time as we incur costs on our contracts.  Contract costs include all direct materials, labor, and indirect costs related to contract performance which may include indirect labor, supplies, tools, repairs and depreciation costs.

[0000080420-19-000005:notes:80]
We also have contracts to provide value-added services such as field service inspection, installation, commissioning, modification and repair, as well as retrofit and retrofill components for existing systems.  As a practical expedient, if the service contract terms give us the right to invoice the customer for an amount that corresponds directly with the value of our performance completed to date (i.e., a service contract in which we bill a fixed amount for each hour of service provided), then we recognize revenue over time in each reporting period corresponding to the amount with which we have the right to invoice.  Our performance obligations are satisfied as the work progresses. Revenues from our custom-engineered products and value-added services transferred to customers over time accounted for approximately 93% of total revenues for the three months ended December 31, 2018.

[0000080420-19-000005:notes:81]
We also have sales orders for spare parts and replacement circuit breakers for switchgear that are obsolete or that are no longer produced by the original manufacturer. Revenues from these sales orders are recognized at a point in time when we fulfil our performance obligation to the customer which is typically upon shipment. Revenue related to sales orders represents approximately 7% of total revenues for the three months ended December 31, 2018.

[0000080420-19-000005:notes:82]
Additionally, some contracts may contain a cancellation clause that could limit the amount of revenue we are able to recognize over time. In these instances, revenue and costs associated with these contracts are deferred and recognized at a point in time when the performance obligation is fulfilled.

[0000080420-19-000005:notes:83]
Selling and administrative costs incurred in relation to obtaining a contract are typically expensed as incurred. We periodically utilize a third-party sales agent to obtain a contract and will pay a commission to that agent. We record the full commission liability to the third-party sales agents at the order date, with a corresponding deferred asset. As the project progresses, we record commission expense based on percentage of completion rates that correlate to the project and reduce the deferred asset. Once we have been paid by the customer, we pay the commission and the deferred liability is reduced

[0000080420-19-000005:notes:84]
Contract Estimates

[0000080420-19-000005:notes:85]
Actual revenues and project costs may vary from previous estimates due to changes in a variety of factors. The cost estimation process is based upon the professional knowledge and experience of our engineers, project managers and financial professionals. Factors that are considered in estimating the work to be completed and ultimate contract recovery include the availability and productivity of labor, the nature and complexity of the work to be performed, the availability of materials, and the effect of any delays on our project performance. We periodically review our job performance, job conditions, estimated profitability and final contract settlements, including our estimate of total costs and make revisions to costs and income in the period in which the revisions are probable and reasonably estimable. Whenever revisions of estimated contract costs and contract values indicate that the contract costs will exceed estimated revenues, thus creating a loss, a provision for the total estimated loss is recorded in that period.

[0000080420-19-000005:notes:86]
The timing of our invoice process is typically dependent on the completion of certain milestones and contract terms and subject to agreement by our customer.  Payment is typically expected within 30 days of invoice. Any uncollected invoiced amounts for our performance obligations recognized over time, including contract retentions, are recorded as accounts receivable in the Condensed Consolidated Balance Sheets. Certain contracts contain retention provisions that become due upon completion of contractual requirements.

[0000080420-19-000005:notes:87]
Variable Consideration

[0000080420-19-000005:notes:88]
It is common for our long-term contracts to contain variable consideration that can either increase or decrease the transaction price. Due to the nature of our contracts, estimating total cost and revenue can be complex and subject to variability due to change orders, back charges, spare parts, early completion bonuses, customer allowances and liquidated damages. We estimate the amount of variable consideration based on the expected value method, which is the sum of probability-weighted amount, or the most likely amount method which uses various factors including experience with similar transactions and assessment of our anticipated performance. Variable consideration is included in the transaction price if legally enforceable and to the extent it is probable that a significant reversal of cumulative revenue recognized will not occur once the uncertainty associated with the variable consideration is resolved.

[0000080420-19-000005:notes:89]
Contract Modifications

[0000080420-19-000005:notes:90]
Contracts may be modified for changes in contract specifications and requirements. We consider contract modifications to exist when the modification either creates new or changes the enforceable rights and obligations under the contract. Most of our contract modifications are for goods and services that are not distinct from the existing performance obligation. Contract modifications result in a cumulative catch up adjustment to revenue based on our measure of progress for the performance obligation.

[0000080420-19-000005:notes:91]
Contract Balances

[0000080420-19-000005:notes:92]
The timing of revenue recognition, billings and cash collections affects accounts receivable, costs and estimated earnings in excess of billings on uncompleted contracts (contract assets) and billings in excess of costs and estimated earnings on uncompleted contracts (contract liabilities) in our Condensed Consolidated Balance Sheet.

[0000080420-19-000005:notes:93]
Contract assets, previously referred to as costs and estimated earnings in excess of billings on uncompleted contracts, are recorded when revenues are recognized in excess of amounts billed for fixed-price contracts as determined by the billing milestone schedule. Contract assets are transferred to accounts receivables when billing milestones have been met or we have an unconditional right to payment.

[0000080420-19-000005:notes:94]
Contract liabilities, previously referred to as billings in excess of costs and estimated earnings on uncompleted contracts, typically represent advance payments from contractual billing milestones and billings in excess of revenue recognized. It is unusual to have advanced milestone payments with a term greater than one year, which could represent a financing component on the contract.

[0000080420-19-000005:notes:95]
Our contract assets and liabilities are reported in a net position on a contract-by-contract basis at the end of each reporting period and are generally classified as current.

[0000080420-19-000005:notes:96]
Performance Obligations

[0000080420-19-000005:notes:97]
A performance obligation is a promise in a contract or with a customer to transfer a distinct good or service. A contract’s transaction price is allocated to each distinct performance obligation and recognized as revenue as the performance obligations are satisfied. To determine the proper revenue recognition for contracts, we evaluate whether a contract should be accounted for as more than one performance obligation or, less commonly, whether two or more contracts should be combined and accounted for as one performance obligation.  This evaluation of performance obligations requires significant judgement.  The majority of our contracts have a single performance obligation where multiple engineered products and services are combined into a single custom engineered solution. Our contracts generally include a standard assurance warranty that typically ends eighteen months after shipment. Occasionally, we provide service-type warranties that will extend the warranty period. These extended warranties qualify as a separate performance obligation. If we determine during the evaluation of the contract that there are multiple performance obligations, we allocate the transaction price to each performance obligation using our best estimate of the standalone selling price of each distinct good or service in the contract.

[0000080420-19-000005:notes:98]
Remaining unsatisfied performance obligations, which we refer to as backlog, represent the estimated transaction price for goods and services for which we have a material right but work has not been performed.


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0000080420-19-000005:notes:99]
REVENUE

[0000080420-19-000005:notes:100]
Selling and administrative costs incurred in relation to obtaining a contract are typically expensed as incurred. We periodically utilize a third-party sales agent to obtain a contract and will pay a commission to that agent. We record the full commission liability to the third-party sales agents at the order date, with a corresponding deferred asset. As the project progresses, we record commission expense based on percentage of completion rates that correlate to the project and reduce the deferred asset. Once we have been paid by the customer, we pay the commission and the deferred liability is reduced.

[0000080420-19-000005:notes:101]
Remaining unsatisfied performance obligations, which we refer to as backlog, represent the estimated transaction price for goods and services for which we have a material right but work has not been performed. As of December 31, 2018, we had backlog of $322.0 million, of which approximately $302 million is expected to be recognized within the next twelve months. Backlog may not be indicative of future operating results as orders may be cancelled or modified by our customers. Our backlog does not include service and maintenance-type contracts for which we have the right to invoice as services are performed.

[0000080420-19-000005:notes:102]
For the quarters ended December 31, 2018 and 2017, our operating loss was positively impacted by $3.1 million and $2.0 million, respectively, as a result of changes in contract estimates related to projects in progress at the beginning of the respective period. These changes in estimates resulted primarily from favorable project execution and negotiations of variable consideration, discussed below, as well as other changes in facts and circumstances during these periods.

[0000080420-19-000005:notes:103]
The decrease in net contract assets at December 31, 2018 was primarily due to the timing of contract billing milestones and new orders. To determine the amount of revenue recognized during the period from contract liabilities, we first allocate revenue to the individual contract liability balance outstanding at the beginning of the period until the revenue exceeds that balance. During the quarter ended December 31, 2018, we recognized revenue of approximately $28 million related to contract liabilities outstanding at September 30, 2018.

[0000080420-19-000005:notes:104]
The timing of our invoice process is typically dependent on the completion of certain milestones and contract terms and subject to agreement by our customer.  Payment is typically expected within 30 days of invoice. Any uncollected invoiced amounts for our performance obligations recognized over time, including contract retentions, are recorded as accounts receivable in the Condensed Consolidated Balance Sheets. Certain contracts contain retention provisions that become due upon completion of contractual requirements. As of December 31, 2018 and September 30, 2018, accounts receivable included retention amounts of $3.3 million and $4.2 million, respectively. Of the retained amount at December 31, 2018, $3.0 million is expected to be collected in the next twelve months.

[0000080420-19-000005:notes:105]
Disaggregation of Revenue


## us-gaap:ScheduleOfInventoryCurrentTableTextBlock

[0000080420-19-000005:notes:106]
[same as prior period, unchanged from 0000080420-18-000022:notes:78]

[0000080420-19-000005:notes:107]
|  | December 31, 2018 |  | September 30, 2018 |
| Raw materials, parts and subassemblies, net | $ | 24,056 |  |  | $ | 20,272 |  |
| Work-in-progress | 990 |  |  | 1,080 |  |
| Total inventories | $ | 25,046 |  |  | $ | 21,352 |  |


## us-gaap:ScheduleOfProductWarrantyLiabilityTableTextBlock

[0000080420-19-000005:notes:108]
[same as prior period, unchanged from 0000080420-18-000022:notes:80]

[0000080420-19-000005:notes:109]
|  | Three months ended December 31, |
|  | 2018 |  | 2017 |
| Balance at beginning of period | $ | 2,604 |  |  | $ | 3,174 |  |
| Increase in warranty expense | 746 |  |  | 195 |  |
| Deduction for warranty charges | (604 | ) |  | (478 | ) |
| Change due to foreign currency translation | (14 | ) |  | (1 | ) |
| Balance at end of period | $ | 2,732 |  |  | $ | 2,890 |  |


## us-gaap:SubsequentEventsTextBlock

[0000080420-19-000005:notes:110]
SUBSEQUENT EVENTS

[0000080420-19-000005:notes:111]
On February 5, 2019, our Board of Directors declared a quarterly cash dividend on our common stock in the amount of $0.26 per share. The dividend is payable on March 20, 2019 to shareholders of record at the close of business on February 20, 2019.


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0000080420-19-000005:notes:112]
[same as prior period, unchanged from 0000080420-18-000022:notes:84]

[0000080420-19-000005:notes:113]
[same as prior period, unchanged from 0000080420-18-000022:notes:85]

[0000080420-19-000005:notes:114]
[same as prior period, unchanged from 0000080420-18-000022:notes:86]

[0000080420-19-000005:notes:115]
[same as prior period, unchanged from 0000080420-18-000022:notes:88]
