# POWL note change history — 0000080420-18-000022 → 0000080420-19-000005


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2019-02-06):
[0000080420-19-000005:note_history:1]
Certain customers require us to post letters of credit or surety bonds which assure that we will perform under the terms of our contract. In the event of default, the counterparty may demand payment from the bank under a letter of credit or performance by the surety under a bond. To date, there have been no significant expenses related to either letters of credit or surety bonds for the periods reported. We were contingently liable for letters of credit of $15.2 million as of December 31, 2018. We also had surety bonds totaling $172.3 million that were outstanding, with additional bonding capacity of $577.7 million available, at December 31, 2018.
  (was, 2018-08-08, similarity 0.9809):
[0000080420-18-000022:note_history:1]
Certain customers require us to post letters of credit or surety bonds which assure that we will perform under the terms of our contract. In the event of default, the counterparty may demand payment from the bank under a letter of credit or performance by the surety under a bond. To date, there have been no significant expenses related to either letters of credit or surety bonds for the periods reported. We were contingently liable for letters of credit of $22.3 million as of June 30, 2018. We also had surety bonds totaling $168.3 million that were outstanding, with additional bonding capacity of $581.7 million available, at June 30, 2018.

- changed (2019-02-06):
[0000080420-19-000005:note_history:2]
Additionally, we have a $6.4 million facility agreement (Facility Agreement) between Powell (UK) Limited and a large international bank. This Facility Agreement provides Powell (UK) Limited the ability to enter into bank guarantees as well as forward exchange contracts and currency options. At December 31, 2018, we had outstanding guarantees totaling $3.9 million under this Facility Agreement and amounts available under this Facility Agreement were $2.5 million. The Facility Agreement provides for financial covenants and customary events of default, and carries cross-default provisions with our U.S. Revolver. If an event of default (as defined in the Facility Agreement) occurs and is continuing, per the terms and subject to the conditions set forth therein, obligations outstanding under the Facility Agreement may be accelerated and declared immediately due and payable. As of December 31, 2018, we were in compliance with all of the financial covenants of the Facility Agreement.
  (was, 2018-08-08, similarity 0.9876):
[0000080420-18-000022:note_history:2]
Additionally, we have a $6.6 million facility agreement (Facility Agreement) between Powell (UK) Limited and a large international bank. This Facility Agreement provides Powell (UK) Limited the ability to enter into bank guarantees as well as forward exchange contracts and currency options. At June 30, 2018, we had outstanding guarantees totaling $3.2 million under this Facility Agreement and amounts available under this Facility Agreement were $3.4 million. The Facility Agreement provides for financial covenants and customary events of default, and carries cross-default provisions with our U.S. Revolver. If an event of default (as defined in the Facility Agreement) occurs and is continuing, per the terms and subject to the conditions set forth therein, obligations outstanding under the Facility Agreement may be accelerated and declared immediately due and payable. As of June 30, 2018, we were in compliance with all of the financial covenants of the Facility Agreement.

- removed (2019-02-06):
[0000080420-18-000022:note_history:3]
Liquidated Damages

- removed (2019-02-06):
[0000080420-18-000022:note_history:4]
Certain of our customer contracts have schedule and performance obligation clauses that, if we fail to meet them, could require us to pay liquidated damages. Each individual contract defines the conditions under which the customer may make a claim against us. As of June 30, 2018, our exposure to possible liquidated damages was $2.6 million, of which approximately $1.6 million is probable. Based on our actual or projected failure to meet these various contractual commitments, $1.5 million has been recorded as a reduction to revenue. Of the $1.5 million recorded as a reduction to revenue, approximately $1.0 million was recognized in prior periods. We will attempt to obtain change orders, contract extensions or accelerate project completion which may resolve the potential for any unaccrued liquidated damage. Should we fail to achieve relief on some or all of these contractual obligations, we could be required to pay additional liquidated damages, which could negatively impact our future operating results.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureAndSignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- added (2019-02-06):
[0000080420-19-000005:note_history:5]
We develop, design, manufacture and service custom-engineered products and systems for the distribution, control and monitoring of electrical energy. Headquartered in Houston, Texas, we serve the oil and gas markets, including onshore and offshore oil and gas production, pipeline, refining and liquid natural gas terminals, as well as petrochemical, electric utility and light traction power.

- changed (2019-02-06):
[0000080420-19-000005:note_history:6]
The preparation of condensed consolidated financial statements in conformity with U.S. GAAP requires management to make estimates and assumptions that affect the amounts reported in the condensed consolidated financial statements and accompanying footnotes. The most significant estimates used in our condensed consolidated financial statements affect revenue recognition and estimated cost recognition on our customer contracts, the allowance for doubtful accounts, provision for excess and obsolete inventory, warranty accruals and income taxes. The amounts recorded for warranties, legal, income taxes, impairment of long-lived assets (when applicable) and other contingent liabilities require judgments regarding the amount of expenses that will ultimately be incurred. We base our estimates on historical experience and on various other assumptions, as well as the specific circumstances surrounding these contingent liabilities, in evaluating the amount of liability that should be recorded. Additionally, the recognition of deferred tax assets requires estimates related to future income and other assumptions regarding timing and future profitability because the ultimate realization of net deferred tax assets is dependent on the generation of future taxable income during the periods in which temporary differences become deductible. Estimates routinely change as new events occur, additional information becomes available or operating environments change. Actual results may differ from our prior estimates.
  (was, 2018-08-08, similarity 0.7898):
[0000080420-18-000022:note_history:6]
The preparation of condensed consolidated financial statements in conformity with U.S. GAAP requires management to make estimates and assumptions that affect the amounts reported in the condensed consolidated financial statements and accompanying footnotes. The most significant estimates used in our condensed consolidated financial statements affect revenue and cost recognition for construction contracts, the allowance for doubtful accounts, provision for excess and obsolete inventory, warranty accruals and income taxes. The amounts recorded for warranties, legal, income taxes, impairment of long-lived assets (when applicable) and other contingent liabilities require judgments regarding the amount of expenses that will ultimately be incurred. We base our estimates on historical experience and on various other assumptions, as well as the specific circumstances surrounding these contingent liabilities, in evaluating the amount of liability that should be recorded. Additionally, the recognition of deferred tax assets requires estimates related to future income and other assumptions regarding timing and future profitability. Estimates routinely change as new events occur, additional information becomes available or operating environments change. Actual results may differ from our prior estimates.

- added (2019-02-06):
[0000080420-19-000005:note_history:7]
In May 2014, the Financial Accounting Standards Board (FASB) issued a new standard on revenue recognition that supersedes previously issued revenue recognition guidance. This standard provides a five-step approach to be applied to all contracts with customers and requires expanded disclosures about the nature, amount, timing and uncertainty of revenue (and the related cash flows) arising from customer contracts, significant judgments and changes in judgments used in applying the revenue model and the assets recognized from costs incurred to obtain or fulfill a contract. Effective October 1, 2018, we adopted this standard using the modified retrospective basis. After evaluating the impact of this new standard on contracts outstanding as of October 1, 2018, we determined that no adjustment to retained earnings was necessary. See Note D for further discussion of revenue.

- changed (2019-02-06):
[0000080420-19-000005:note_history:8]
In February 2016, the FASB issued a new topic on leases which requires lessees to recognize lease assets and lease liabilities on the balance sheet for all leases with terms longer than twelve months. Leases will be classified as either finance or operating, with classification affecting the pattern of expense recognition in the income statement. A modified retrospective transition approach is required for lessees for capital and operating leases existing at, or entered into after, the beginning of the earliest comparative period presented in the financial statements, with certain practical expedients available. The new topic is effective for fiscal years beginning after December 15, 2018, including interim periods within those fiscal years. This would be our fiscal year ending September 30, 2020. In Fiscal 2018, we acquired new lease software designed to assist with the transition and our migrating our existing leases. We are still evaluating the impact this new topic will have on our consolidated financial position and results of operations.
  (was, 2018-08-08, similarity 0.8348):
[0000080420-18-000022:note_history:8]
In February 2016, the FASB issued a new topic on leases which requires lessees to recognize lease assets and lease liabilities on the balance sheet for all leases with terms longer than twelve months. Leases will be classified as either finance or operating, with classification affecting the pattern of expense recognition in the income statement. A modified retrospective transition approach is required for lessees for capital and operating leases existing at, or entered into after, the beginning of the earliest comparative period presented in the financial statements, with certain practical expedients available. The new topic is effective for fiscal years beginning after December 15, 2018, including interim periods within those fiscal years. This would be our fiscal year ending September 30, 2020. We are still evaluating the potential impact of this topic on our financial statements.

- changed (2019-02-06):
[0000080420-19-000005:note_history:9]
In November 2016, the FASB issued a new topic on the statement of cash flows that changes the presentation of restricted cash and cash equivalents on the statement of cash flows. Restricted cash and restricted cash equivalents is to be included with cash and cash equivalents when reconciling the beginning-of-period and end-of-period total amounts shown on the statement of cash flows. We adopted this topic in Fiscal 2019 and our Condensed Consolidated Cash Flow Statements for all periods reflect this presentation.
  (was, 2018-08-08, similarity 0.6475):
[0000080420-18-000022:note_history:9]
In November 2016, the FASB issued a new topic on the statement of cash flows that changes the presentation of restricted cash and cash equivalents on the statement of cash flows. Restricted cash and restricted cash equivalents will be included with cash and cash equivalents when reconciling the beginning-of-period and end-of-period total amounts shown on the statement of cash flows. This topic is effective for fiscal years beginning after December 15, 2017, and interim periods within those fiscal years, which would be our fiscal year ending September 30, 2019. We are still evaluating this new topic, but do not expect it to have a material impact on our statement of cash flows.

- changed (2019-02-06):
[0000080420-19-000005:note_history:10]
In May 2017, the FASB issued a new topic on modification accounting with regards to stock based compensation. This new topic clarifies when a change to the terms or conditions of a share-based payment award should be accounted for as a modification. An entity should account for the effects of a modification unless the fair value, vesting conditions and classification, as an equity instrument or a liability instrument, of the modified award are the same before and after a change to the terms or conditions of the share-based payment award. We adopted this topic in Fiscal 2019 and it has not had a material impact on our consolidated financial position or results of operations.
  (was, 2018-08-08, similarity 0.838):
[0000080420-18-000022:note_history:10]
In May 2017, the FASB issued a new topic on modification accounting with regards to stock based compensation. This new topic clarifies when a change to the terms or conditions of a share-based payment award should be accounted for as a modification. An entity should account for the effects of a modification unless the fair value, vesting conditions and classification, as an equity instrument or a liability instrument, of the modified award are the same before and after a change to the terms or conditions of the share-based payment award. This topic is effective for annual reporting periods beginning after December 15, 2017, which is our fiscal year ending September 30, 2019. We are still evaluating this new topic, but do not expect it to have a material impact on our consolidated financial position or results of operations.

- removed (2019-02-06):
[0000080420-18-000022:note_history:11]
We develop, design, manufacture and service custom-engineered products and systems for the distribution, control and monitoring of electrical energy. Headquartered in Houston, Texas, we serve the oil and gas refining, onshore and offshore oil and gas production, petrochemical, pipeline, terminal, mining and metals, light rail traction power, electric utility, pulp and paper and other heavy industrial markets.

- removed (2019-02-06):
[0000080420-18-000022:note_history:12]
In May 2014, the Financial Accounting Standards Board (FASB) issued a new standard on revenue recognition that supersedes previously issued revenue recognition guidance. This standard provides a five-step approach to be applied to all contracts with customers and requires expanded disclosures about the nature, amount, timing and uncertainty of revenue (and the related cash flows) arising from customer contracts, significant judgments and changes in judgments used in applying the revenue model and the assets recognized from costs incurred to obtain or fulfill a contract. This standard is effective for fiscal years, and interim periods within those years, beginning after December 15, 2017, which would be our fiscal year ending September 30, 2019. We plan to use the modified retrospective basis upon adoption which could result in a cumulative effect adjustment as of October 1, 2018, if material. We continue to hold regular meetings with our implementation team which includes training and evaluating contracts to identity potential impacts of the standard on our current accounting policies and disclosures. We will update our accounting policies and procedures and determine the impact from this new standard on our contracts outstanding as of October 1, 2018. While we are still evaluating the potential impact of this standard on our financial statements, we believe accounting for variable consideration, cancellations for convenience clauses and the number of performance obligations contained in each contract could have the greatest significance. We have not yet been able to estimate the impact the new revenue recognition criteria will have on our consolidated financial statements and related disclosures, but the impact on our financial statements from this guidance will be determined in large part by the contracts that are in progress as of the adoption date.

- removed (2019-02-06):
[0000080420-18-000022:note_history:13]
In November 2015, the FASB issued an amendment to the topic regarding income taxes which requires an entity to separate deferred income tax liabilities and assets into current and noncurrent amounts in the statement of financial position.  Deferred tax liabilities and assets are classified as current or noncurrent based on the classification of the related asset or liability for financial reporting.  Deferred tax liabilities and assets that are not related to an asset or liability for financial reporting are classified according to the expected reversal date of the temporary difference. To simplify the presentation of deferred income taxes, the amendments require that deferred income tax liabilities and assets be classified as noncurrent in a classified statement of financial position. We have adopted this topic prospectively in Fiscal 2018 and our statement of financial position reflects this reclassification. We have not retrospectively adjusted prior periods.


## us-gaap:LongTermDebtTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2019-02-06):
[0000080420-19-000005:note_history:14]
|  | December 31, 2018 |  | September 30, 2018 |
| Industrial development revenue bonds | $ | 1,200 |  |  | $ | 1,600 |  |
| Less current portion | (400 | ) |  | (400 | ) |
| Total long-term debt | $ | 800 |  |  | $ | 1,200 |  |
  (was, 2018-08-08, similarity 0.9735):
[0000080420-18-000022:note_history:14]
|  | June 30, 2018 |  | September 30, 2017 |
| Industrial development revenue bonds | $ | 1,600 |  |  | $ | 2,000 |  |
| Less current portion | (400 | ) |  | (400 | ) |
| Total long-term debt | $ | 1,200 |  |  | $ | 1,600 |  |

- changed (2019-02-06):
[0000080420-19-000005:note_history:15]
We have a $75.0 million revolving credit facility (U.S. Revolver) to provide working capital support and letters of credit which expires in June 2022. The amount available under the U.S. Revolver at December 31, 2018 was reduced by $15.2 million for our outstanding letters of credit. Currently, our U.S. Revolver can only be used for letters of credit until we meet certain financial ratios. There were no loans outstanding under the U.S. Revolver as of December 31, 2018.
  (was, 2018-08-08, similarity 0.9599):
[0000080420-18-000022:note_history:15]
We have a $75.0 million revolving credit facility (U.S. Revolver) to provide working capital support and letters of credit which expires on June 27, 2022. The amount available under the U.S. Revolver at June 30, 2018 was reduced by $22.3 million for our outstanding letters of credit. Currently, our U.S. Revolver can only be used for letters of credit until we meet certain financial ratios. There were no loans outstanding under the U.S. Revolver as of June 30, 2018.

- added (2019-02-06):
[0000080420-19-000005:note_history:16]
Per the terms of the U.S. Revolver, we are required to maintain cash in a pledged collateral account until we satisfy the following two financial ratios for two consecutive fiscal quarters: a max leverage ratio and a fixed charge coverage ratio. The max leverage ratio requires that the ratio of our consolidated funded indebtedness to our consolidated earnings before interest, taxes and depreciation (EBITDA) for the last four consecutive quarters not exceed 2.75 to 1.00. The fixed charge coverage ratio requires that the ratio of consolidated EBITDA for the last four fiscal quarters, less income taxes, capital expenditures, principal debt payments and interest charges be at least 1.25 to 1.00. If we are not in compliance with the these two ratios, we are required to maintain a cash balance in a pledged cash collateral account equal to 102% of the outstanding amount of any loans and letter of credit obligations until we meet the aforementioned required ratios. As of December 31, 2018, the balance in the cash collateral account was $15.9 million and is recorded as restricted cash in our Condensed Consolidated Balance Sheets. The portion of the cash collateral associated with the outstanding letters of credit that are due to expire beyond twelve months has been classified as non-current restricted cash on the balance sheet. As of December 31, 2018, there was $59.8 million available for the issuance of letters of credit under the U.S. Revolver, subject to the cash collateral requirements mentioned above.

- changed (2019-02-06):
[0000080420-19-000005:note_history:17]
The U.S. Revolver is collateralized by a pledge of 100% of the voting capital stock of each of our domestic subsidiaries and 65% of the voting capital stock of each non-domestic subsidiary. The U.S. Revolver provides for customary events of default and carries cross-default provisions with other existing debt agreements. If an event of default (as defined in the U.S. Revolver) occurs and is continuing, on the terms and subject to the conditions set forth in the U.S. Revolver, amounts outstanding under the U.S. Revolver may be accelerated and may become immediately due and payable. It also contains financial covenants defining various financial measures and the levels of these measures with which we must comply, as well as a “material adverse change” clause. A “material adverse change” is defined as a material change in our operations, business, properties, liabilities or condition (financial or otherwise) or a material impairment of our ability to perform our obligations under our credit agreements. As of December 31, 2018, we were in compliance with all of the financial covenants of the U.S. Revolver.
  (was, 2018-08-08, similarity 0.9946):
[0000080420-18-000022:note_history:17]
The U.S. Revolver is collateralized by a pledge of 100% of the voting capital stock of each of our domestic subsidiaries and 65% of the voting capital stock of each non-domestic subsidiary. The U.S. Revolver provides for customary events of default and carries cross-default provisions with other existing debt agreements. If an event of default (as defined in the U.S. Revolver) occurs and is continuing, on the terms and subject to the conditions set forth in the U.S. Revolver, amounts outstanding under the U.S. Revolver may be accelerated and may become immediately due and payable. It also contains financial covenants defining various financial measures and the levels of these measures with which we must comply, as well as a “material adverse change” clause. A “material adverse change” is defined as a material change in our operations, business, properties, liabilities or condition (financial or otherwise) or a material impairment of our ability to perform our obligations under our credit agreements. As of June 30, 2018, we were in compliance with all of the financial covenants of the U.S. Revolver.

- changed (2019-02-06):
[0000080420-19-000005:note_history:18]
We borrowed $8.0 million in October 2001 through a loan agreement funded with proceeds from tax-exempt industrial development revenue bonds (Bonds). These Bonds were issued by the Illinois Development Finance Authority and were used for the completion of our Northlake, Illinois facility. Pursuant to the Bond issuance, a reimbursement agreement between us and a major domestic bank required an issuance by the bank of an irrevocable direct-pay letter of credit (Bond LC), as collateral, to the Bonds’ trustee to guarantee payment of the Bonds’ principal and interest when due. The Bond LC is subject to both early termination and extension provisions customary to such agreements, as well as various covenants, for which we were in compliance at December 31, 2018. While the Bonds mature in 2021, the reimbursement agreement requires annual redemptions of $0.4 million that commenced on October 25, 2002. A sinking fund is used for the redemption of the Bonds. The Bonds bear interest at a floating rate determined weekly by the Bonds’ remarketing agent, which was the underwriter for the Bonds and is an affiliate of the bank. This interest rate was 1.86% as of December 31, 2018.
  (was, 2018-08-08, similarity 0.9895):
[0000080420-18-000022:note_history:18]
We borrowed $8.0 million in October 2001 through a loan agreement funded with proceeds from tax-exempt industrial development revenue bonds (Bonds). These Bonds were issued by the Illinois Development Finance Authority and were used for the completion of our Northlake, Illinois facility. Pursuant to the Bond issuance, a reimbursement agreement between us and a major domestic bank required an issuance by the bank of an irrevocable direct-pay letter of credit (Bond LC), as collateral, to the Bonds’ trustee to guarantee payment of the Bonds’ principal and interest when due. The Bond LC is subject to both early termination and extension provisions customary to such agreements, as well as various covenants, for which we were in compliance at June 30, 2018. While the Bonds mature in 2021, the reimbursement agreement requires annual redemptions of $0.4 million that commenced on October 25, 2002. A sinking fund is used for the redemption of the Bonds. The Bonds bear interest at a floating rate determined weekly by the Bonds’ remarketing agent, which was the underwriter for the Bonds and is an affiliate of the bank. This interest rate was 1.58% as of June 30, 2018.

- removed (2019-02-06):
[0000080420-18-000022:note_history:19]
Per the terms of the U.S. Revolver, we are required to maintain a cash balance in a pledged cash collateral account equal to 102% of the outstanding amount of any loans and letter of credit obligations until we meet certain financial ratios. As of June 30, 2018, the balance in the pledged account was $23.6 million. The cash collateral associated with the outstanding letters of credit that are due to expire beyond twelve months has been classified as non-current restricted cash on the balance sheet. As of June 30, 2018, there was $52.7 million available for the issuance of letters of credit under the U.S. Revolver.


## us-gaap:ScheduleOfDebtInstrumentsTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2019-02-06):
[0000080420-19-000005:note_history:20]
|  | December 31, 2018 |  | September 30, 2018 |
| Industrial development revenue bonds | $ | 1,200 |  |  | $ | 1,600 |  |
| Less current portion | (400 | ) |  | (400 | ) |
| Total long-term debt | $ | 800 |  |  | $ | 1,200 |  |
  (was, 2018-08-08, similarity 0.9735):
[0000080420-18-000022:note_history:20]
|  | June 30, 2018 |  | September 30, 2017 |
| Industrial development revenue bonds | $ | 1,600 |  |  | $ | 2,000 |  |
| Less current portion | (400 | ) |  | (400 | ) |
| Total long-term debt | $ | 1,200 |  |  | $ | 1,600 |  |


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: no_prior_note, score: 0.0

- added (2019-02-06):
[0000080420-19-000005:note_history:21]
The following tables present our disaggregated revenue by geographic destination and market sector for the quarter ended December 31, 2018 (in thousands):

- added (2019-02-06):
[0000080420-19-000005:note_history:22]
|  | Three months ended December 31, 2018 |
| United States | $ | 89,898 |  |
| Canada | 9,715 |  |
| Europe, Middle East and Africa | 5,441 |  |
| Asia/Pacific | 3,744 |  |
| Mexico, Central and South America | 553 |  |
| Total revenues by geographic destination | $ | 109,351 |  |

- added (2019-02-06):
[0000080420-19-000005:note_history:23]
|  | Three months ended December 31, 2018 |
| Oil and gas | $ | 49,576 |  |
| Petrochemical | 19,778 |  |
| Electric utility | 19,258 |  |
| Traction power | 5,009 |  |
| All others | 15,730 |  |
| Total revenues by market sector | $ | 109,351 |  |


## us-gaap:RevenueFromContractWithCustomerPolicyTextBlock (revenue_recognition_policy) — matched_by: no_prior_note, score: 0.0

- added (2019-02-06):
[0000080420-19-000005:note_history:24]
On October 1, 2018, we adopted the new revenue recognition standard using the modified retrospective transition method. We applied the guidance to customer contracts which were not substantially complete at that time and we determined that no adjustment to retained earnings was necessary. Financial results for reporting periods after October 1, 2018 are reported under the new guidance; however financial results for prior periods were not adjusted and will continue to be presented in accordance with the previous guidance.

- added (2019-02-06):
[0000080420-19-000005:note_history:25]
Revenue Recognition

- added (2019-02-06):
[0000080420-19-000005:note_history:26]
The majority of our revenues are generated from the manufacturing of custom engineered products and systems under long-term fixed price contracts under which we agree to manufacture various products such as traditional and arc-resistant distribution switchgear and control gear, medium-voltage circuit breakers, monitoring and control communications systems, motor control centers and bus duct systems. These products may be sold separately as an engineered solution, but are typically integrated into custom-built enclosures which we also build.  These enclosures are referred to as power control room substations (PCRs®), custom-engineered modules or electrical houses (E-Houses). Some contracts may also include the installation and the commissioning of these enclosures.

- added (2019-02-06):
[0000080420-19-000005:note_history:27]
Revenue from these contracts is generally recognized over time utilizing the cost to cost method to measure the extent of progress toward the completion of the performance obligation and the recognition of revenue over time. We believe that this method is the most accurate representation of our performance because it directly measures the value of the services transferred to the customer over time as we incur costs on our contracts.  Contract costs include all direct materials, labor, and indirect costs related to contract performance which may include indirect labor, supplies, tools, repairs and depreciation costs.

- added (2019-02-06):
[0000080420-19-000005:note_history:28]
We also have contracts to provide value-added services such as field service inspection, installation, commissioning, modification and repair, as well as retrofit and retrofill components for existing systems.  As a practical expedient, if the service contract terms give us the right to invoice the customer for an amount that corresponds directly with the value of our performance completed to date (i.e., a service contract in which we bill a fixed amount for each hour of service provided), then we recognize revenue over time in each reporting period corresponding to the amount with which we have the right to invoice.  Our performance obligations are satisfied as the work progresses. Revenues from our custom-engineered products and value-added services transferred to customers over time accounted for approximately 93% of total revenues for the three months ended December 31, 2018.

- added (2019-02-06):
[0000080420-19-000005:note_history:29]
We also have sales orders for spare parts and replacement circuit breakers for switchgear that are obsolete or that are no longer produced by the original manufacturer. Revenues from these sales orders are recognized at a point in time when we fulfil our performance obligation to the customer which is typically upon shipment. Revenue related to sales orders represents approximately 7% of total revenues for the three months ended December 31, 2018.

- added (2019-02-06):
[0000080420-19-000005:note_history:30]
Additionally, some contracts may contain a cancellation clause that could limit the amount of revenue we are able to recognize over time. In these instances, revenue and costs associated with these contracts are deferred and recognized at a point in time when the performance obligation is fulfilled.

- added (2019-02-06):
[0000080420-19-000005:note_history:31]
Selling and administrative costs incurred in relation to obtaining a contract are typically expensed as incurred. We periodically utilize a third-party sales agent to obtain a contract and will pay a commission to that agent. We record the full commission liability to the third-party sales agents at the order date, with a corresponding deferred asset. As the project progresses, we record commission expense based on percentage of completion rates that correlate to the project and reduce the deferred asset. Once we have been paid by the customer, we pay the commission and the deferred liability is reduced

- added (2019-02-06):
[0000080420-19-000005:note_history:32]
Contract Estimates

- added (2019-02-06):
[0000080420-19-000005:note_history:33]
Actual revenues and project costs may vary from previous estimates due to changes in a variety of factors. The cost estimation process is based upon the professional knowledge and experience of our engineers, project managers and financial professionals. Factors that are considered in estimating the work to be completed and ultimate contract recovery include the availability and productivity of labor, the nature and complexity of the work to be performed, the availability of materials, and the effect of any delays on our project performance. We periodically review our job performance, job conditions, estimated profitability and final contract settlements, including our estimate of total costs and make revisions to costs and income in the period in which the revisions are probable and reasonably estimable. Whenever revisions of estimated contract costs and contract values indicate that the contract costs will exceed estimated revenues, thus creating a loss, a provision for the total estimated loss is recorded in that period.

- added (2019-02-06):
[0000080420-19-000005:note_history:34]
The timing of our invoice process is typically dependent on the completion of certain milestones and contract terms and subject to agreement by our customer.  Payment is typically expected within 30 days of invoice. Any uncollected invoiced amounts for our performance obligations recognized over time, including contract retentions, are recorded as accounts receivable in the Condensed Consolidated Balance Sheets. Certain contracts contain retention provisions that become due upon completion of contractual requirements.

- added (2019-02-06):
[0000080420-19-000005:note_history:35]
Variable Consideration

- added (2019-02-06):
[0000080420-19-000005:note_history:36]
It is common for our long-term contracts to contain variable consideration that can either increase or decrease the transaction price. Due to the nature of our contracts, estimating total cost and revenue can be complex and subject to variability due to change orders, back charges, spare parts, early completion bonuses, customer allowances and liquidated damages. We estimate the amount of variable consideration based on the expected value method, which is the sum of probability-weighted amount, or the most likely amount method which uses various factors including experience with similar transactions and assessment of our anticipated performance. Variable consideration is included in the transaction price if legally enforceable and to the extent it is probable that a significant reversal of cumulative revenue recognized will not occur once the uncertainty associated with the variable consideration is resolved.

- added (2019-02-06):
[0000080420-19-000005:note_history:37]
Contract Modifications

- added (2019-02-06):
[0000080420-19-000005:note_history:38]
Contracts may be modified for changes in contract specifications and requirements. We consider contract modifications to exist when the modification either creates new or changes the enforceable rights and obligations under the contract. Most of our contract modifications are for goods and services that are not distinct from the existing performance obligation. Contract modifications result in a cumulative catch up adjustment to revenue based on our measure of progress for the performance obligation.

- added (2019-02-06):
[0000080420-19-000005:note_history:39]
Contract Balances

- added (2019-02-06):
[0000080420-19-000005:note_history:40]
The timing of revenue recognition, billings and cash collections affects accounts receivable, costs and estimated earnings in excess of billings on uncompleted contracts (contract assets) and billings in excess of costs and estimated earnings on uncompleted contracts (contract liabilities) in our Condensed Consolidated Balance Sheet.

- added (2019-02-06):
[0000080420-19-000005:note_history:41]
Contract assets, previously referred to as costs and estimated earnings in excess of billings on uncompleted contracts, are recorded when revenues are recognized in excess of amounts billed for fixed-price contracts as determined by the billing milestone schedule. Contract assets are transferred to accounts receivables when billing milestones have been met or we have an unconditional right to payment.

- added (2019-02-06):
[0000080420-19-000005:note_history:42]
Contract liabilities, previously referred to as billings in excess of costs and estimated earnings on uncompleted contracts, typically represent advance payments from contractual billing milestones and billings in excess of revenue recognized. It is unusual to have advanced milestone payments with a term greater than one year, which could represent a financing component on the contract.

- added (2019-02-06):
[0000080420-19-000005:note_history:43]
Our contract assets and liabilities are reported in a net position on a contract-by-contract basis at the end of each reporting period and are generally classified as current.

- added (2019-02-06):
[0000080420-19-000005:note_history:44]
Performance Obligations

- added (2019-02-06):
[0000080420-19-000005:note_history:45]
A performance obligation is a promise in a contract or with a customer to transfer a distinct good or service. A contract’s transaction price is allocated to each distinct performance obligation and recognized as revenue as the performance obligations are satisfied. To determine the proper revenue recognition for contracts, we evaluate whether a contract should be accounted for as more than one performance obligation or, less commonly, whether two or more contracts should be combined and accounted for as one performance obligation.  This evaluation of performance obligations requires significant judgement.  The majority of our contracts have a single performance obligation where multiple engineered products and services are combined into a single custom engineered solution. Our contracts generally include a standard assurance warranty that typically ends eighteen months after shipment. Occasionally, we provide service-type warranties that will extend the warranty period. These extended warranties qualify as a separate performance obligation. If we determine during the evaluation of the contract that there are multiple performance obligations, we allocate the transaction price to each performance obligation using our best estimate of the standalone selling price of each distinct good or service in the contract.

- added (2019-02-06):
[0000080420-19-000005:note_history:46]
Remaining unsatisfied performance obligations, which we refer to as backlog, represent the estimated transaction price for goods and services for which we have a material right but work has not been performed.


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: no_prior_note, score: 0.0

- added (2019-02-06):
[0000080420-19-000005:note_history:47]
REVENUE

- added (2019-02-06):
[0000080420-19-000005:note_history:48]
On October 1, 2018, we adopted the new revenue recognition standard using the modified retrospective transition method. We applied the guidance to customer contracts which were not substantially complete at that time and we determined that no adjustment to retained earnings was necessary. Financial results for reporting periods after October 1, 2018 are reported under the new guidance; however financial results for prior periods were not adjusted and will continue to be presented in accordance with the previous guidance.

- added (2019-02-06):
[0000080420-19-000005:note_history:49]
Revenue Recognition

- added (2019-02-06):
[0000080420-19-000005:note_history:50]
The majority of our revenues are generated from the manufacturing of custom engineered products and systems under long-term fixed price contracts under which we agree to manufacture various products such as traditional and arc-resistant distribution switchgear and control gear, medium-voltage circuit breakers, monitoring and control communications systems, motor control centers and bus duct systems. These products may be sold separately as an engineered solution, but are typically integrated into custom-built enclosures which we also build.  These enclosures are referred to as power control room substations (PCRs®), custom-engineered modules or electrical houses (E-Houses). Some contracts may also include the installation and the commissioning of these enclosures.

- added (2019-02-06):
[0000080420-19-000005:note_history:51]
Revenue from these contracts is generally recognized over time utilizing the cost to cost method to measure the extent of progress toward the completion of the performance obligation and the recognition of revenue over time. We believe that this method is the most accurate representation of our performance because it directly measures the value of the services transferred to the customer over time as we incur costs on our contracts.  Contract costs include all direct materials, labor, and indirect costs related to contract performance which may include indirect labor, supplies, tools, repairs and depreciation costs.

- added (2019-02-06):
[0000080420-19-000005:note_history:52]
We also have contracts to provide value-added services such as field service inspection, installation, commissioning, modification and repair, as well as retrofit and retrofill components for existing systems.  As a practical expedient, if the service contract terms give us the right to invoice the customer for an amount that corresponds directly with the value of our performance completed to date (i.e., a service contract in which we bill a fixed amount for each hour of service provided), then we recognize revenue over time in each reporting period corresponding to the amount with which we have the right to invoice.  Our performance obligations are satisfied as the work progresses. Revenues from our custom-engineered products and value-added services transferred to customers over time accounted for approximately 93% of total revenues for the three months ended December 31, 2018.

- added (2019-02-06):
[0000080420-19-000005:note_history:53]
We also have sales orders for spare parts and replacement circuit breakers for switchgear that are obsolete or that are no longer produced by the original manufacturer. Revenues from these sales orders are recognized at a point in time when we fulfil our performance obligation to the customer which is typically upon shipment. Revenue related to sales orders represents approximately 7% of total revenues for the three months ended December 31, 2018.

- added (2019-02-06):
[0000080420-19-000005:note_history:54]
Additionally, some contracts may contain a cancellation clause that could limit the amount of revenue we are able to recognize over time. In these instances, revenue and costs associated with these contracts are deferred and recognized at a point in time when the performance obligation is fulfilled.

- added (2019-02-06):
[0000080420-19-000005:note_history:55]
Selling and administrative costs incurred in relation to obtaining a contract are typically expensed as incurred. We periodically utilize a third-party sales agent to obtain a contract and will pay a commission to that agent. We record the full commission liability to the third-party sales agents at the order date, with a corresponding deferred asset. As the project progresses, we record commission expense based on percentage of completion rates that correlate to the project and reduce the deferred asset. Once we have been paid by the customer, we pay the commission and the deferred liability is reduced.

- added (2019-02-06):
[0000080420-19-000005:note_history:56]
Performance Obligations

- added (2019-02-06):
[0000080420-19-000005:note_history:57]
A performance obligation is a promise in a contract or with a customer to transfer a distinct good or service. A contract’s transaction price is allocated to each distinct performance obligation and recognized as revenue as the performance obligations are satisfied. To determine the proper revenue recognition for contracts, we evaluate whether a contract should be accounted for as more than one performance obligation or, less commonly, whether two or more contracts should be combined and accounted for as one performance obligation.  This evaluation of performance obligations requires significant judgement.  The majority of our contracts have a single performance obligation where multiple engineered products and services are combined into a single custom engineered solution. Our contracts generally include a standard assurance warranty that typically ends eighteen months after shipment. Occasionally, we provide service-type warranties that will extend the warranty period. These extended warranties qualify as a separate performance obligation. If we determine during the evaluation of the contract that there are multiple performance obligations, we allocate the transaction price to each performance obligation using our best estimate of the standalone selling price of each distinct good or service in the contract.

- added (2019-02-06):
[0000080420-19-000005:note_history:58]
Remaining unsatisfied performance obligations, which we refer to as backlog, represent the estimated transaction price for goods and services for which we have a material right but work has not been performed. As of December 31, 2018, we had backlog of $322.0 million, of which approximately $302 million is expected to be recognized within the next twelve months. Backlog may not be indicative of future operating results as orders may be cancelled or modified by our customers. Our backlog does not include service and maintenance-type contracts for which we have the right to invoice as services are performed.

- added (2019-02-06):
[0000080420-19-000005:note_history:59]
Contract Estimates

- added (2019-02-06):
[0000080420-19-000005:note_history:60]
Actual revenues and project costs may vary from previous estimates due to changes in a variety of factors. The cost estimation process is based upon the professional knowledge and experience of our engineers, project managers and financial professionals. Factors that are considered in estimating the work to be completed and ultimate contract recovery include the availability and productivity of labor, the nature and complexity of the work to be performed, the availability of materials, and the effect of any delays on our project performance. We periodically review our job performance, job conditions, estimated profitability and final contract settlements, including our estimate of total costs and make revisions to costs and income in the period in which the revisions are probable and reasonably estimable. Whenever revisions of estimated contract costs and contract values indicate that the contract costs will exceed estimated revenues, thus creating a loss, a provision for the total estimated loss is recorded in that period.

- added (2019-02-06):
[0000080420-19-000005:note_history:61]
For the quarters ended December 31, 2018 and 2017, our operating loss was positively impacted by $3.1 million and $2.0 million, respectively, as a result of changes in contract estimates related to projects in progress at the beginning of the respective period. These changes in estimates resulted primarily from favorable project execution and negotiations of variable consideration, discussed below, as well as other changes in facts and circumstances during these periods.

- added (2019-02-06):
[0000080420-19-000005:note_history:62]
Variable Consideration

- added (2019-02-06):
[0000080420-19-000005:note_history:63]
It is common for our long-term contracts to contain variable consideration that can either increase or decrease the transaction price. Due to the nature of our contracts, estimating total cost and revenue can be complex and subject to variability due to change orders, back charges, spare parts, early completion bonuses, customer allowances and liquidated damages. We estimate the amount of variable consideration based on the expected value method, which is the sum of probability-weighted amount, or the most likely amount method which uses various factors including experience with similar transactions and assessment of our anticipated performance. Variable consideration is included in the transaction price if legally enforceable and to the extent it is probable that a significant reversal of cumulative revenue recognized will not occur once the uncertainty associated with the variable consideration is resolved.

- added (2019-02-06):
[0000080420-19-000005:note_history:64]
Contract Modifications

- added (2019-02-06):
[0000080420-19-000005:note_history:65]
Contracts may be modified for changes in contract specifications and requirements. We consider contract modifications to exist when the modification either creates new or changes the enforceable rights and obligations under the contract. Most of our contract modifications are for goods and services that are not distinct from the existing performance obligation. Contract modifications result in a cumulative catch up adjustment to revenue based on our measure of progress for the performance obligation.

- added (2019-02-06):
[0000080420-19-000005:note_history:66]
Contract Balances

- added (2019-02-06):
[0000080420-19-000005:note_history:67]
The timing of revenue recognition, billings and cash collections affects accounts receivable, costs and estimated earnings in excess of billings on uncompleted contracts (contract assets) and billings in excess of costs and estimated earnings on uncompleted contracts (contract liabilities) in our Condensed Consolidated Balance Sheet.

- added (2019-02-06):
[0000080420-19-000005:note_history:68]
Contract assets, previously referred to as costs and estimated earnings in excess of billings on uncompleted contracts, are recorded when revenues are recognized in excess of amounts billed for fixed-price contracts as determined by the billing milestone schedule. Contract assets are transferred to accounts receivables when billing milestones have been met or we have an unconditional right to payment.

- added (2019-02-06):
[0000080420-19-000005:note_history:69]
Contract liabilities, previously referred to as billings in excess of costs and estimated earnings on uncompleted contracts, typically represent advance payments from contractual billing milestones and billings in excess of revenue recognized. It is unusual to have advanced milestone payments with a term greater than one year, which could represent a financing component on the contract.

- added (2019-02-06):
[0000080420-19-000005:note_history:70]
Our contract assets and liabilities are reported in a net position on a contract-by-contract basis at the end of each reporting period and are generally classified as current.

- added (2019-02-06):
[0000080420-19-000005:note_history:71]
Contract assets and liabilities as of December 31, 2018 and September 30, 2018 are summarized below (in thousands):

- added (2019-02-06):
[0000080420-19-000005:note_history:72]
|  | December 31, 2018 |  | September 30, 2018 |
| Contract assets | $ | 69,601 |  |  | $ | 82,545 |  |
| Contract liabilities | 51,410 |  |  | 43,174 |  |
| Net contract assets (liabilities) | $ | 18,191 |  |  | $ | 39,371 |  |

- added (2019-02-06):
[0000080420-19-000005:note_history:73]
The decrease in net contract assets at December 31, 2018 was primarily due to the timing of contract billing milestones and new orders. To determine the amount of revenue recognized during the period from contract liabilities, we first allocate revenue to the individual contract liability balance outstanding at the beginning of the period until the revenue exceeds that balance. During the quarter ended December 31, 2018, we recognized revenue of approximately $28 million related to contract liabilities outstanding at September 30, 2018.

- added (2019-02-06):
[0000080420-19-000005:note_history:74]
The timing of our invoice process is typically dependent on the completion of certain milestones and contract terms and subject to agreement by our customer.  Payment is typically expected within 30 days of invoice. Any uncollected invoiced amounts for our performance obligations recognized over time, including contract retentions, are recorded as accounts receivable in the Condensed Consolidated Balance Sheets. Certain contracts contain retention provisions that become due upon completion of contractual requirements. As of December 31, 2018 and September 30, 2018, accounts receivable included retention amounts of $3.3 million and $4.2 million, respectively. Of the retained amount at December 31, 2018, $3.0 million is expected to be collected in the next twelve months.

- added (2019-02-06):
[0000080420-19-000005:note_history:75]
Disaggregation of Revenue

- added (2019-02-06):
[0000080420-19-000005:note_history:76]
The following tables present our disaggregated revenue by geographic destination and market sector for the quarter ended December 31, 2018 (in thousands):

- added (2019-02-06):
[0000080420-19-000005:note_history:77]
|  | Three months ended December 31, 2018 |
| United States | $ | 89,898 |  |
| Canada | 9,715 |  |
| Europe, Middle East and Africa | 5,441 |  |
| Asia/Pacific | 3,744 |  |
| Mexico, Central and South America | 553 |  |
| Total revenues by geographic destination | $ | 109,351 |  |

- added (2019-02-06):
[0000080420-19-000005:note_history:78]
|  | Three months ended December 31, 2018 |
| Oil and gas | $ | 49,576 |  |
| Petrochemical | 19,778 |  |
| Electric utility | 19,258 |  |
| Traction power | 5,009 |  |
| All others | 15,730 |  |
| Total revenues by market sector | $ | 109,351 |  |


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: tag_name, score: 1.0

- added (2019-02-06):
[0000080420-19-000005:note_history:79]
On February 5, 2019, our Board of Directors declared a quarterly cash dividend on our common stock in the amount of $0.26 per share. The dividend is payable on March 20, 2019 to shareholders of record at the close of business on February 20, 2019.

- removed (2019-02-06):
[0000080420-18-000022:note_history:80]
On August 6, 2018, our Board of Directors declared a quarterly cash dividend on our common stock in the amount of $0.26 per share. The dividend is payable on September 19, 2018 to shareholders of record at the close of business on August 22, 2018.
