# POWL MD&A — 0000080420-19-000005


## mdna

[0000080420-19-000005:mdna:1]
[same as prior period, unchanged from 0000080420-18-000022:mdna:1]

[0000080420-19-000005:mdna:2]
The following discussion and analysis of our financial condition and results of operations should be read in conjunction with the accompanying condensed consolidated financial statements and related notes included elsewhere in this Quarterly Report on Form 10-Q and with our Annual Report on Form 10-K for the year ended September 30, 2018, which was filed with the Securities and Exchange Commission (SEC) on December 12, 2018 and is available on the SEC’s website at www.sec.gov.

[0000080420-19-000005:mdna:3]
[same as prior period, unchanged from 0000080420-18-000022:mdna:3]

[0000080420-19-000005:mdna:4]
We develop, design, manufacture and service custom-engineered equipment and systems for the distribution, control and monitoring of electrical energy. Headquartered in Houston, Texas, we serve the oil and gas markets, including onshore and offshore oil and gas production, pipeline, refining and liquid natural gas terminals, as well as petrochemical, electric utility and light traction power. Revenues and costs are primarily related to custom engineered-to-order equipment and systems and are accounted for under percentage-of-completion accounting which precludes us from providing detailed price and volume information. Our backlog includes various projects that typically take a number of months to produce.

[0000080420-19-000005:mdna:5]
[same as prior period, unchanged from 0000080420-18-000022:mdna:5]

[0000080420-19-000005:mdna:6]
Due to the significant decline in oil and gas prices from peak 2014 levels, many of our customers have reduced their capital budgets and cut costs, and in certain instances have delayed or canceled projects that we were pursuing. Customers are beginning to invest in maintenance and small projects and this shift in market sentiment has had a favorable impact on our orders and backlog over recent quarters. Since the second half of Fiscal 2017, our core oil, gas and petrochemical markets have begun to strengthen resulting in increased revenues and orders.

[0000080420-19-000005:mdna:7]
Our first fiscal quarter operations are negatively impacted by the number of holidays in November and December and we typically shut down our manufacturing facilities for a brief period during the last week of December.

[0000080420-19-000005:mdna:8]
[same as prior period, unchanged from 0000080420-18-000022:mdna:7]

[0000080420-19-000005:mdna:9]
Quarter Ended December 31, 2018 Compared to the Quarter Ended December 31, 2017 (Unaudited)

[0000080420-19-000005:mdna:10]
[same as prior period, unchanged from 0000080420-18-000022:mdna:9]

[0000080420-19-000005:mdna:11]
Revenues increased by 21%, or $19.2 million, to $109.4 million in the first quarter of Fiscal 2019, compared to the first quarter of Fiscal 2018, primarily due to an increase in orders over the past few quarters in our domestic operations from improved market conditions, primarily in our oil and gas markets. Domestic revenues increased by 50%, or $29.8 million, to $89.9 million in the first quarter of Fiscal 2019, compared to the first quarter of Fiscal 2018. International revenues decreased by 35%, or $10.7 million, to $19.5 million in the first quarter of Fiscal 2019, compared to the first quarter of Fiscal 2018. Our international revenue includes both revenue generated from our international facilities, as well as export revenues from our domestic facilities.

[0000080420-19-000005:mdna:12]
Gross profit for the first quarter of Fiscal 2019 increased by 39%, or $4.1 million, to $14.6 million, compared to the first quarter of Fiscal 2018. Gross profit as a percentage of revenues increased to 13% in the first quarter of Fiscal 2019, compared to 12% in the first quarter of Fiscal 2018. Gross profit and margins increased due to improved market conditions and efficiencies resulting from increased volume in our domestic manufacturing facilities.

[0000080420-19-000005:mdna:13]
[same as prior period, unchanged from 0000080420-18-000022:mdna:12]

[0000080420-19-000005:mdna:14]
Selling, general and administrative expenses decreased slightly by $0.3 million, to $15.9 million during the first quarter of Fiscal 2019, compared to $16.2 million in the first quarter of Fiscal 2018. Selling, general and administrative expenses, as a percentage of revenues, decreased to 15% during the first quarter of Fiscal 2019, compared to 18% during the first quarter of Fiscal 2018, primarily due to the increase in revenues.

[0000080420-19-000005:mdna:15]
Other Income

[0000080420-19-000005:mdna:16]
In the first quarter of Fiscal 2018, we recorded other income of $0.5 million which represented the amortization of the deferred gain from an amended supply agreement, which was fully amortized at December 31, 2017.

[0000080420-19-000005:mdna:17]
[same as prior period, unchanged from 0000080420-18-000022:mdna:28]

[0000080420-19-000005:mdna:18]
We recorded an income tax benefit of $0.2 million in the first quarter of Fiscal 2019, compared to an income tax benefit of $1.1 million in the first quarter of Fiscal 2018. The effective tax rate for the first quarter of Fiscal 2019 was 8%, compared to an effective tax rate of 16% in the first quarter of Fiscal 2018. On December 22, 2017, the Tax Cuts and Jobs Act was signed into law, which lowered the corporate tax rate from 35% to 21% effective January 1, 2018. As a result, the U.S. federal statutory rate for Fiscal 2019 is 21%, compared to the blended statutory rate of 24.5% effective for Fiscal 2018. For the three months ended December 31, 2018, the effective tax rate was negatively impacted by a foreign tax loss that is reserved with a valuation allowance. The effective tax rate for the three months ended December 31, 2017 was similarly impacted by a foreign tax loss reserved with a valuation allowance, as well as $0.7 million tax expense related to the re-measurement of U.S. deferred tax assets as a result of tax reform.

[0000080420-19-000005:mdna:19]
[same as prior period, unchanged from 0000080420-18-000022:mdna:30]

[0000080420-19-000005:mdna:20]
In the first quarter of Fiscal 2019, we recorded a loss of $2.7 million, or $0.23 per diluted share, compared to a net loss of $5.7 million, or $0.49 per diluted share, in the first quarter of Fiscal 2018. This improvement in operating results over the prior year was primarily due to improved market conditions and efficiencies resulting from increased volume in our domestic manufacturing facilities.

[0000080420-19-000005:mdna:21]
[same as prior period, unchanged from 0000080420-18-000022:mdna:18]

[0000080420-19-000005:mdna:22]
Our backlog includes various projects that can take a number of months to produce. The order backlog at December 31, 2018 increased to $322.0 million, compared to $260.9 million at September 30, 2018.

[0000080420-19-000005:mdna:23]
New orders placed during the first quarter of Fiscal 2019 increased to $172.0 million, compared to $100.0 million in the first quarter of Fiscal 2018, primarily due to increased demand from our customers in our core oil, gas and petrochemical markets.

[0000080420-19-000005:mdna:24]
[same as prior period, unchanged from 0000080420-18-000022:mdna:52]

[0000080420-19-000005:mdna:25]
[same as prior period, unchanged from 0000080420-18-000022:mdna:53]

[0000080420-19-000005:mdna:26]
A significant portion of our revenues have historically been from the oil, gas and petrochemical markets. Oil and gas commodity price levels have been unstable over the last several years and our customers delayed some of their major capital investment projects. Customers are beginning to invest in maintenance and small projects and this shift in market sentiment has had a favorable impact on our orders and backlog over recent quarters.

[0000080420-19-000005:mdna:27]
Our operating results have been impacted by factors such as the timing of new order awards, customer approval of final engineering and design specifications and delays in customer construction schedules, all of which have had a negative impact on the timing of project execution. Our operating results also have been, and could continue to be, impacted by the timing and resolution of change orders, project close-out and resolution of potential contract claims and liquidated damages, all of which could improve or deteriorate gross margins during the period in which these items are resolved with our customers. These factors may result in periods of underutilization of our resources and facilities and negatively impact our ability to cover our fixed costs. We continue to assess our cost structure, operating performance and service offerings as the oil, gas and petrochemical markets remain challenging and uncertain. In Fiscal 2018, we experienced an increase in new orders which has continued into the first quarter of 2019. This improvement in orders has led to improvement in revenues and operating results that we anticipate will continue into Fiscal 2019. We continue to focus on maintaining our cash position, improving efficiencies in production and investing in future business opportunities.

[0000080420-19-000005:mdna:28]
Our increase in project volume typically requires cash to fund operations, but we believe that our strong working capital position and available cash and short-term investments should be sufficient to finance future operating activities, research and development initiatives, capital improvements and debt repayments for the foreseeable future. We continue to monitor the factors that drive our markets and will continue to strive to maintain our leadership and competitive advantage in the markets we serve while aligning our cost structures with market conditions.

[0000080420-19-000005:mdna:29]
[same as prior period, unchanged from 0000080420-18-000022:mdna:34]

[0000080420-19-000005:mdna:30]
As of December 31, 2018, current assets exceeded current liabilities by 2.5 times and our debt to total capitalization was 0.41%.

[0000080420-19-000005:mdna:31]
Cash, cash equivalents and short-term investments increased to $62.3 million at December 31, 2018, compared to $49.8 million at September 30, 2018. We also had restricted cash held in a pledged collateral account related to our amended credit agreement (U.S. Revolver) of $15.9 million at December 31, 2018 and $25.1 million at September 30, 2018. For further information regarding our U.S. Revolver, see Note E of Notes to Condensed Consolidated Financial Statements.

[0000080420-19-000005:mdna:32]
Our U.S. Revolver is a $75.0 million revolving credit facility in the U.S. As of December 31, 2018, there were no amounts borrowed under this facility. Total letters of credit outstanding under our U.S. Revolver, which reduce our availability, were $15.2 million at December 31, 2018 and $23.1 million at September 30, 2018. Currently, our U.S. Revolver can only be used for letters of credit until we meet certain financial ratios as described in Note E of Notes to Condensed Consolidated Financial Statements. As of December 31, 2018, there was $59.8 million available for the issuance of letters of credit under the U.S. Revolver. Total long-term debt, including current maturities, totaled $1.2 million at December 31, 2018, compared to $1.6 million at September 30, 2018.

[0000080420-19-000005:mdna:33]
Approximately $26 million of our cash and short-term investments at December 31, 2018 was held outside of the U.S. for international operations. It is our intention to indefinitely reinvest all current and future foreign earnings internationally in order to ensure sufficient working capital to support our international operations. In the event that we elect to repatriate some or all of the foreign earnings that were previously deemed to be indefinitely reinvested outside the U.S., under current tax laws we would incur additional tax expense upon such repatriation.

[0000080420-19-000005:mdna:34]
[same as prior period, unchanged from 0000080420-18-000022:mdna:40]

[0000080420-19-000005:mdna:35]
Cash provided by operating activities increased to $9.1 million during the three months ended December 31, 2018, compared to cash used in operating activities of $14.1 million during the same period in Fiscal 2018. This increase in operating cash flow for the three months ended December 31, 2018 was primarily due to the collection of accounts receivable and the receipt of a $6.6 million income tax refund in the first quarter of Fiscal 2019. Cash flow from operations is primarily influenced by project volume, the timing of milestone payments from our customers and the payment terms with our suppliers.

[0000080420-19-000005:mdna:36]
[same as prior period, unchanged from 0000080420-18-000022:mdna:42]

[0000080420-19-000005:mdna:37]
Net cash provided by investing activities during the three months ended December 31, 2018 totaled $5.0 million compared to cash provided by investing activities of $2.1 million during the same period in Fiscal 2018. This increase in cash provided by investments in the current quarter was primarily due to the net maturities of short-term investments and a decrease in property, plant and equipment expenditures compared to the same period in the prior year.

[0000080420-19-000005:mdna:38]
[same as prior period, unchanged from 0000080420-18-000022:mdna:44]

[0000080420-19-000005:mdna:39]
Net cash used in financing activities was $4.1 million and $3.8 million during the three months ended December 31, 2018 and 2017, respectively. These amounts primarily consisted of cash dividends of approximately $3.0 million in each period.

[0000080420-19-000005:mdna:40]
[same as prior period, unchanged from 0000080420-18-000022:mdna:46]

[0000080420-19-000005:mdna:41]
[same as prior period, unchanged from 0000080420-18-000022:mdna:47]

[0000080420-19-000005:mdna:42]
[same as prior period, unchanged from 0000080420-18-000022:mdna:48]

[0000080420-19-000005:mdna:43]
The discussion and analysis of our financial condition and results of operations are based on our condensed consolidated financial statements, which have been prepared in accordance with U.S. GAAP. The preparation of these condensed consolidated financial

[0000080420-19-000005:mdna:44]
statements requires us to make estimates and assumptions that affect the reported amounts of assets and liabilities, disclosures of contingent assets and liabilities known to exist at the date of the condensed consolidated financial statements and the reported amounts of revenues and expenses during the reporting period. We evaluate our estimates on an ongoing basis, based on historical experience and on various other assumptions that are believed to be reasonable under the circumstances. There can be no assurance that actual results will not differ from those estimates.

[0000080420-19-000005:mdna:45]
Effective October 1, 2018, we adopted the new revenue recognition guidance which resulted in changes to our revenue recognition policy. See Note D of Notes to Condensed Consolidated Financial Statements for information on the new revenue recognition guidance and related disclosures. There have been no other material changes to our critical accounting policies as disclosed in our Annual Report on Form 10-K for the year ended September 30, 2018.
