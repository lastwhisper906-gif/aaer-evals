# POWL MD&A — 0000080420-17-000032


## mdna

[0000080420-17-000032:mdna:1]
Item 7. Management’s Discussion and Analysis of Financial Condition and Results of Operations

[0000080420-17-000032:mdna:2]
Overview

[0000080420-17-000032:mdna:3]
We develop, design, manufacture and service custom-engineered equipment and systems for the distribution, control and monitoring of electrical energy. Headquartered in Houston, Texas, we serve the oil and gas refining, onshore and offshore oil and gas production, petrochemical, pipeline, terminal, mining and metals, light rail traction power, electric utility, pulp and paper and other heavy industrial markets. Revenues and costs are primarily related to custom engineered-to-order equipment and systems and are accounted for under percentage-of-completion accounting which precludes us from providing detailed price and volume information. Our backlog includes various projects that typically take a number of months to produce.

[0000080420-17-000032:mdna:4]
The markets in which we participate are capital intensive and cyclical in nature. Cyclicality is predominantly driven by customer demand, global economic conditions and anticipated environmental, safety or regulatory changes that affect the manner in which our customers proceed with capital investments. Our customers analyze various factors including the demand and price for oil, gas and electrical energy, the overall economic and financial environment, governmental budgets, regulatory actions and environmental concerns. These factors influence the release of new capital projects by our customers, which are traditionally awarded in competitive bid situations. Scheduling of projects is matched to the customer requirements and projects typically take a number of months to produce. Schedules may change during the course of any particular project and our operating results can therefore be impacted by factors outside of our control.

[0000080420-17-000032:mdna:5]
Due to the significant decline in oil and gas prices from late 2014 levels, many of our customers have reduced their capital budgets and cut costs, and in certain instances have delayed or cancelled projects that we were pursuing. As a result, our revenues and project backlog have declined, and may continue to decline, which may further negatively impact our operations. In response to our reduced project backlog and the challenging market outlook in our core oil, gas and petrochemical markets, we took steps in Fiscal 2016, and have taken additional actions in Fiscal 2017, to reduce our overall cost structure and better align our costs with current and future production requirements.

[0000080420-17-000032:mdna:6]
Results of Operations

[0000080420-17-000032:mdna:7]
Twelve Months Ended September 30, 2017 Compared to Twelve Months Ended September 30, 2016

[0000080420-17-000032:mdna:8]
Revenue and Gross Profit

[0000080420-17-000032:mdna:9]
Revenues decreased 30%, or $169.3 million, to $395.9 million in Fiscal 2017, compared to Fiscal 2016, primarily due to the continued decrease in our project backlog as we complete existing projects and continue to see lower demand from our customers in our core oil, gas and petrochemical markets. Domestic revenues decreased 31%, or $126.0 million, to $279.3 million and international revenues decreased 27%, or $43.4 million, to $116.6 million in Fiscal 2017, compared to Fiscal 2016. This reduction in geographic revenues year over year was primarily driven by the decline in our project backlog mentioned above. Revenues from commercial and industrial customers decreased 39%, or $164.9 million, to $254.2 million in Fiscal 2017, compared to Fiscal 2016, primarily due to lower demand in our core oil, gas and petrochemical markets. Revenues from public and private utilities decreased 17%, or $17.5 million, to $84.4 million in Fiscal 2017, compared to Fiscal 2016. Revenues from municipal and transit projects increased 30%, or $13.1 million, to $57.3 million in Fiscal 2017, compared to Fiscal 2016 due to the timing of certain projects.

[0000080420-17-000032:mdna:10]
Gross profit decreased 52%, or $55.4 million, to $50.8 million in Fiscal 2017, compared to Fiscal 2016. Gross profit as a percentage of revenues decreased to 13% in Fiscal 2017 compared to 19% in Fiscal 2016. Gross profit and margins continued to be negatively impacted by our reduced volume resulting in under absorption of our manufacturing facility costs and a shift in our project mix to smaller projects which typically have lower margins. This decline in volume and margins is primarily due to a decline in our project backlog resulting from depressed market conditions and competitive pricing pressures primarily in our core oil, gas and petrochemical markets. Gross profit margins were negatively impacted by execution challenges on certain municipal transit projects and operating inefficiencies associated with the increased volume from municipal transit projects. The municipal transit market is price competitive and projects typically yield lower margins.

[0000080420-17-000032:mdna:11]
Selling, General and Administrative Expenses

[0000080420-17-000032:mdna:12]
Selling, general and administrative expenses decreased 18%, or $13.4 million, to $61.5 million in Fiscal 2017, compared to Fiscal 2016, primarily due to the cost reduction efforts we took in Fiscal 2016 in response to our adverse market outlook as well as lower incentive compensation expenses. Selling, general and administrative expenses, as a percentage of revenues, increased to 16% in Fiscal 2017 compared to 13% in Fiscal 2016, primarily due to the reduction in revenue discussed above.

[0000080420-17-000032:mdna:13]
Restructuring and Separation Expenses

[0000080420-17-000032:mdna:14]
In Fiscal 2017, we incurred $1.3 million in separation and restructuring costs, compared to $8.4 million in Fiscal 2016. In Fiscal 2017, we continued to reduce our overall cost structure to better align our costs with current and future production requirements. The separation and restructuring costs incurred in Fiscal 2016 were due to the realignment of our senior management team and workforce reductions as a result of our adverse market outlook and reduction in project backlog.

[0000080420-17-000032:mdna:15]
Other Income

[0000080420-17-000032:mdna:16]
We recorded other income of $2.0 million in both Fiscal 2017 and Fiscal 2016, which was the amortization of the deferred gain from the amended supply agreement, which will be fully amortized at December 31, 2017. See Note E of the Notes to Consolidated Financial Statements.

[0000080420-17-000032:mdna:17]
Income Tax Provision

[0000080420-17-000032:mdna:18]
We recorded an income tax benefit of $7.4 million in Fiscal 2017, compared to the income tax provision of $2.3 million we recorded in Fiscal 2016. The effective tax rate for Fiscal 2017 was 44% compared to an effective tax rate of 13% for Fiscal 2016. The effective tax rates for both Fiscal 2017 and 2016 were favorably impacted by the lower tax rate in the U.K., the relative amounts of income/loss recognized in various jurisdictions, as well as the utilization of net operating loss carryforwards in Canada that are fully reserved with a valuation allowance. Additionally, the effective tax rates for both Fiscal 2017 and 2016 were favorably impacted by discrete items recognized, primarily related to the Research and Development Tax Credit (R&D Tax Credit), in the amounts of $0.9 million and $0.8 million, respectively. See Note H of the Notes to Consolidated Financial Statements.

[0000080420-17-000032:mdna:19]
Net Income

[0000080420-17-000032:mdna:20]
In Fiscal 2017, we recorded a net loss of $9.5 million, or $0.83 per diluted share, a decrease from net income of $15.5 million, or $1.36 per diluted share that we recorded in Fiscal 2016. The reduction in net income compared to the prior year was primarily due to a decline in our project backlog due to depressed market conditions and competitive pricing pressures, primarily in our core oil, gas and petrochemical markets.

[0000080420-17-000032:mdna:21]
Backlog

[0000080420-17-000032:mdna:22]
Our backlog includes various projects, some of which are petrochemical, oil and gas construction and transportation infrastructure projects which take a number of months to produce. The order backlog at September 30, 2017 was $250.1 million, compared to $291.4 million at September 30, 2016. New orders placed in Fiscal 2017 totaled $355.1 million, compared to $417.5 million in Fiscal 2016. This decrease in orders was primarily due to lower demand from our customers in our core oil, gas and petrochemical markets.

[0000080420-17-000032:mdna:23]
Twelve Months Ended September 30, 2016 Compared to Twelve Months Ended September 30, 2015

[0000080420-17-000032:mdna:24]
Revenue and Gross Profit

[0000080420-17-000032:mdna:25]
Revenues decreased 15%, or $96.6 million, to $565.2 in Fiscal 2016, compared to Fiscal 2015, primarily due to the continued decrease in our project backlog as we continued to see lower demand from our customers in the oil and gas markets. Domestic revenues decreased 15%, or $69.4 million, to $405.3 million and international revenues decreased 15%, or $27.2 million, to $159.9 million in Fiscal 2016, compared to Fiscal 2015. These decreases were due to the overall reduction in revenues year over year primarily driven by the decline in backlog resulting from lower demand from our customers in the oil and gas markets. Revenues from commercial and industrial customers decreased 20%, or $105.4 million, to $419.1 million in Fiscal 2016, compared to Fiscal 2015, primarily from lower demand from our customers in the oil and gas markets. Revenues from public and private utilities increased 20%, or $16.8 million, to $101.9 million in Fiscal 2016, compared to Fiscal 2015. Revenues from municipal and transit projects decreased 15%, or $8.0 million, to $44.2 million in Fiscal 2016, compared to Fiscal 2015.

[0000080420-17-000032:mdna:26]
Gross profit decreased 2%, or $2.1 million, to $106.2 million in Fiscal 2016, compared to Fiscal 2015. Gross profit as a percentage of revenues increased to 19% in Fiscal 2016 compared to 16% in Fiscal 2015, primarily due to improvements in our international

[0000080420-17-000032:mdna:27]
operations. The improvements in gross profit and gross profit as a percentage of revenues were primarily due to improved efficiencies in project execution at our Canadian operations as the implementation of our project-based integration model has been completed in Canada. Our Canadian operations also overcame the operational challenges and cost overruns that occurred in previous years from their expansion and relocation into our new Canadian facility. Additionally, gross profit at our U.K. operations improved due to project execution. The increase in gross profit from our international operations was partially offset by a decline in gross profit from our domestic operations as margins were negatively impacted primarily by our reduced volume as a result of weak oil and gas market conditions and cost overruns related to a large U.S.-based transit project.

[0000080420-17-000032:mdna:28]
Selling, General and Administrative Expenses

[0000080420-17-000032:mdna:29]
Selling, general and administrative expenses decreased 2%, or $1.9 million, to $74.9 million in Fiscal 2016, compared to Fiscal 2015. Selling, general and administrative expenses, as a percentage of revenues, increased slightly to 13% in Fiscal 2016 compared to 12% in Fiscal 2015, primarily due to the reduction in revenue year over year and the reduction in personnel as a result of the restructuring efforts discussed below.

[0000080420-17-000032:mdna:30]
Restructuring and Separation Expenses

[0000080420-17-000032:mdna:31]
In Fiscal 2016, we incurred $8.4 million in separation and restructuring costs, compared to $3.4 million in Fiscal 2015. This increase in Fiscal 2016 was primarily due to separation costs we incurred from our continued efforts to align our workforce with future production requirements, the departure of our former Chief Executive Officer in December 2015, as well as additional costs related to a leased Canadian facility that we exited in the third quarter of Fiscal 2015 and that has now been sublet through the remaining term of the lease.

[0000080420-17-000032:mdna:32]
Other Income

[0000080420-17-000032:mdna:33]
We recorded other income of $2.0 million in Fiscal 2016, compared to $2.4 million in Fiscal 2015. The $2.0 million in Fiscal 2016 was the amortization of the deferred gain from the amended supply agreement, discussed in Note E of the Notes to Consolidated Financial Statements. In Fiscal 2015, in addition to the amortization of the gain from the amended supply agreement, we also recorded a $0.4 million death benefit received from our company-owned life insurance policy.

[0000080420-17-000032:mdna:34]
Income Tax Provision

[0000080420-17-000032:mdna:35]
Our provision for income taxes was $2.3 million in Fiscal 2016, compared to $13.6 million in Fiscal 2015.  The effective tax rate for Fiscal 2016 was 13% compared to an effective tax rate of 59% for Fiscal 2015. The effective tax rate for Fiscal 2016 was favorably impacted by $1.4 million due to the lower statutory tax rates in the U.K. and Canada and the relative amounts of income earned in those jurisdictions, as well as the utilization of net operating loss carryforwards of $1.9 million in Canada that are fully reserved with a valuation allowance. Additionally, the effective tax rate for Fiscal 2016 was favorably impacted by a $0.8 million discrete item recorded in the first quarter of Fiscal 2016 related to the retroactive reinstatement of the R&D Tax Credit for the previously expired period from January 1, 2015 to September 30, 2015. The effective tax rate in Fiscal 2015 was above the combined U.S. federal and state statutory rate as no tax benefit was recorded against Canadian pre-tax losses due to the $9.0 million valuation allowance recorded in Fiscal 2015, partially offset by the resolution of an IRS audit and the retroactive reinstatement of the R&D Tax Credit for the second through fourth quarters of Fiscal 2014. See Note H of the Notes to Consolidated Financial Statements.

[0000080420-17-000032:mdna:36]
Net Income

[0000080420-17-000032:mdna:37]
In Fiscal 2016, we recorded net income of $15.5 million, or $1.36 per diluted share, which increased from net income of $9.4 million, or $0.79 per diluted share that we recorded in Fiscal 2015. This increase in net income was due to the reduction in income tax provision in Fiscal 2016 compared to Fiscal 2015, which was favorably impacted by the income from our Canadian and U.K. operations in Fiscal 2016 and the utilization of net operating loss carryforwards discussed above.

[0000080420-17-000032:mdna:38]
Backlog

[0000080420-17-000032:mdna:39]
Our backlog includes various projects, some of which are petrochemical, oil and gas construction and transportation infrastructure projects which take a number of months to produce. The order backlog at September 30, 2016 was $291.4 million, compared to $441.4 million at September 30, 2015. New orders placed in Fiscal 2016 totaled $417.5 million, compared to $606.8 million in Fiscal 2015. This decrease in orders was primarily due to lower demand from our customers in the oil and gas markets.

[0000080420-17-000032:mdna:40]
Liquidity and Capital Resources

[0000080420-17-000032:mdna:41]
As of September 30, 2017, current assets exceeded current liabilities by 2.9 times and our debt to total capitalization was 0.62%.

[0000080420-17-000032:mdna:42]
Cash, cash equivalents and short-term investments decreased to $95.2 million at September 30, 2017, compared to $97.7 million at September 30, 2016. In addition, at September 30, 2017, we had restricted cash of $24.9 million held in a pledged collateral account related to our amended credit agreement. As of September 30, 2016, we did not have any cash balances classified as restricted. For further information regarding our amended credit agreement, see Note F of the Notes to Consolidated Financial Statements.

[0000080420-17-000032:mdna:43]
We have a $75.0 million revolving credit facility in the U.S, and as of September 30, 2017, there were no amounts borrowed under this line of credit. Total letters of credit outstanding under our U.S. credit facility, which reduce our availability, were $24.1 million at September 30, 2017 and $26.8 million at September 30, 2016. The amount available under the U.S. revolving credit facility at September 30, 2017 was $50.9 million. Total long-term debt, including current maturities, totaled $2.0 million at September 30, 2017, compared to $2.4 million at September 30, 2016. For further information regarding our debt, see Notes F and G of Notes to Consolidated Financial Statements.

[0000080420-17-000032:mdna:44]
Approximately $36 million of our cash and short-term investments at September 30, 2017 was held outside of the U.S. for international operations. It is our intention to indefinitely reinvest all current and future foreign earnings internationally in order to ensure sufficient working capital to support our international operations. In the event that we elect to repatriate some or all of the foreign earnings that were previously deemed to be indefinitely reinvested outside the U.S., under current tax laws we would incur additional tax expense upon such repatriation.

[0000080420-17-000032:mdna:45]
We believe that cash and short-term investments available and borrowing capacity under our existing credit facility should be sufficient to finance future operating activities, capital improvements and debt repayments for the foreseeable future. We continue to monitor the factors that drive our markets and will continue to strive to maintain our leadership and competitive advantage in the markets we serve while aligning our cost structures with market conditions.

[0000080420-17-000032:mdna:46]
Operating Activities

[0000080420-17-000032:mdna:47]
During Fiscal 2017, net cash provided by operating activities was $36.8 million. During Fiscal 2016, net cash provided by operating activities was $74.9 million and in Fiscal 2015, net cash provided by operating activities was $12.9 million. Cash flow from operations is primarily influenced by the timing of milestone payments from our customers and the payment terms with our suppliers, and is favorably impacted during a down cycle as project milestones are billed and collected as projects are completed. Cash flow from operations declined during Fiscal 2017 compared to Fiscal 2016 primarily as a result of our decrease in operating income and the payments of prior year accrued bonuses and commissions. Cash flow from operations in Fiscal 2017 was favorably impacted by the collection of accounts receivable and the reduction in inventories during our down cycle in project activity. During Fiscal 2016, our cash provided by operations increased over Fiscal 2015 primarily due to our ability to reduce working capital as projects were completed and payments on contracts were received.

[0000080420-17-000032:mdna:48]
Investing Activities

[0000080420-17-000032:mdna:49]
Purchases of property, plant and equipment during Fiscal 2017 totaled $3.6 million compared to $3.0 million and $34.7 million in Fiscal 2016 and 2015, respectively. The reduction in capital spending in Fiscal 2017 and 2016 was in response to our challenging market conditions. The $34.7 million spent in Fiscal 2015 was primarily due to the completion of the expansion of our Canadian facilities. During Fiscal 2017, we invested a net $26.8 million in short-term investments and reclassified $24.9 million as restricted cash for pledged collateral as stipulated by our amended credit agreement.

[0000080420-17-000032:mdna:50]
Financing Activities

[0000080420-17-000032:mdna:51]
Net cash used in financing activities was $12.7 million in Fiscal 2017, $17.4 million in Fiscal 2016 and $34.9 in Fiscal 2015 and includes approximately $12 million of dividends paid in each of the three years. The reduction in financing activities from Fiscal 2015 was primarily due to the completion of our share repurchase program in December 2015, which is discussed below.

[0000080420-17-000032:mdna:52]
Share Repurchase Program

[0000080420-17-000032:mdna:53]
On December 17, 2014, our Board of Directors authorized a share repurchase program which allowed us to repurchase up to $25 million of our outstanding stock. The purchases were made from time to time in the open market through Rule 10b5-1 trading plans in accordance with applicable laws, rules and regulations. The repurchase of shares was funded from cash on hand and cash provided by operating activities. The share repurchase program expired on December 31, 2015. As of December 31, 2015, we had purchased 806,018 shares at an aggregate cost of $25 million under this program. The average purchase price per share from inception of the program until its expiration was $31.02.

[0000080420-17-000032:mdna:54]
Contractual and Other Obligations

[0000080420-17-000032:mdna:55]
At September 30, 2017, our long-term contractual obligations were limited to debt and leases. The table below details our commitments by type of obligation, including interest if applicable, and the period that the payment will become due (in thousands).

[0000080420-17-000032:mdna:56]
| As of September 30, 2017,Payments Due by Period: |  |  |  |  |  |
|  | Long-Term Debt Obligations |  | Net Operating Lease Obligations |  | Total |
| Less than 1 year | $ | 419 |  |  | $ | 1,890 |  |  | $ | 2,309 |  |
| 1 to 3 years | 1,229 |  |  | 3,580 |  |  | 4,809 |  |
| 3 to 5 years | 400 |  |  | 3,510 |  |  | 3,910 |  |
| More than 5 years | — |  |  | 1,172 |  |  | 1,172 |  |
| Total long-term contractual obligations | $ | 2,048 |  |  | $ | 10,152 |  |  | $ | 12,200 |  |

[0000080420-17-000032:mdna:57]
As of September 30, 2017, the total unrecognized tax benefit related to uncertain tax positions was $1.2 million. We estimate that none of this will be paid within the next 12 months. However, we believe that it is reasonably possible that within the next 12 months, the total unrecognized tax benefits will decrease by approximately 11% due to the expiration of certain statutes of limitations or resolution of tax audits. We are unable to make reasonably reliable estimates regarding the timing of future cash outflows, if any, associated with the remaining unrecognized tax benefits.

[0000080420-17-000032:mdna:58]
Other Commercial Commitments

[0000080420-17-000032:mdna:59]
We are contingently liable for secured and unsecured letters of credit of $28.5 million as of September 30, 2017.

[0000080420-17-000032:mdna:60]
The following table reflects potential cash outflows that may result in the event that we are unable to perform under our contracts (in thousands):

[0000080420-17-000032:mdna:61]
| As of September 30, 2017,Payments Due by Period: | Letters ofCredit |
| Less than 1 year | $ | 17,143 |  |
| 1 to 3 years | 7,739 |  |
| More than 3 years | 3,619 |  |
| Total long-term commercial obligations | $ | 28,501 |  |

[0000080420-17-000032:mdna:62]
We also had performance and maintenance bonds totaling $218.8 million that were outstanding at September 30, 2017. Performance and maintenance bonds are primarily used to guarantee our contract performance to our customers.

[0000080420-17-000032:mdna:63]
Off-Balance Sheet Arrangements

[0000080420-17-000032:mdna:64]
We had no off-balance sheet arrangements during the periods presented.

[0000080420-17-000032:mdna:65]
Outlook

[0000080420-17-000032:mdna:66]
The markets in which we participate are capital-intensive and cyclical in nature. Cyclicality is predominantly driven by customer demand, global economic conditions and anticipated environmental or regulatory changes which affect the manner in which our customers proceed with capital investments. Our customers analyze various factors including the demand and price for oil, gas and electrical energy, the overall economic and financial environment, governmental budgets, regulatory actions and environmental concerns. These factors influence the release of new capital projects by our customers, which are traditionally awarded in competitive bid situations. Scheduling of projects is matched to customer requirements. Projects typically take a number of months to produce, and schedules may change during the course of any particular project.

[0000080420-17-000032:mdna:67]
A significant portion of our revenues have historically been from the oil, gas and petrochemical markets. Unfavorable oil and gas commodity price levels have caused, and we anticipate will continue to cause, our customers to further delay their investments. The reduction in available projects across the markets we serve has increased price pressures during this downward market cycle. This reduction in new business opportunities and increased market price pressures have impacted, and will continue to negatively impact, our backlog, revenues and operating results. It is difficult to predict the duration of the current depressed market cycle.

[0000080420-17-000032:mdna:68]
Our operating results have been, and we anticipate will continue to be, negatively impacted by factors such as the timing of new order awards, customer approval of final engineering and design specifications and delays in customer construction schedules, all of which have and will continue to have, a negative impact on the timing of project execution. Our operating results also have been, and will continue to be, impacted by the timing and resolution of change orders, project close-out and resolution of potential contract claims and liquidated damages, all of which could improve or deteriorate gross margins during the period in which these items are resolved with our customers. These factors may result in periods of underutilization of our resources and facilities and negatively impact our ability to cover our fixed costs. If our core oil, gas and petrochemical markets remain depressed, or decline further, our project backlog and revenue could continue to decline and negatively impact our operations. In response to our reduced project backlog and depressed market outlook, we took steps these past two fiscal years to reduce our overall cost structure and better align our costs with future production requirements. We continue to assess our cost structure, operating performance and service offerings as the oil, gas and petrochemical markets remain challenging and uncertain. During Fiscal 2018, additional actions may be necessary.

[0000080420-17-000032:mdna:69]
We believe that our strong working capital position, cash available, low debt position and borrowing capacity under our existing credit facility should be sufficient to finance future operating activities, research and development initiatives, capital improvements and debt repayments for the foreseeable future. We continue to monitor the factors that drive our markets and will continue to strive to maintain our leadership and competitive advantage in the markets we serve while aligning our cost structures with market conditions.

[0000080420-17-000032:mdna:70]
Effects of Inflation

[0000080420-17-000032:mdna:71]
We are subject to inflation, which can cause increases in our costs of raw materials, primarily copper, aluminum and steel. Fixed-price contracts can limit our ability to pass these increases to our customers, thus negatively impacting our earnings. The inflation in commodity prices could potentially impact our operations in future years.

[0000080420-17-000032:mdna:72]
Critical Accounting Policies and Estimates

[0000080420-17-000032:mdna:73]
The preparation of consolidated financial statements in conformity with accounting principles generally accepted in the United States of America requires management to make estimates and assumptions that affect the reported amounts of assets, liabilities, revenues and expenses and the disclosures of contingent assets and liabilities. We base our estimates on historical experience and on various other assumptions that are believed to be reasonable under the circumstances. Actual results may differ from these estimates. We believe the following accounting policies and estimates to be critical in the preparation and reporting of our consolidated financial statements.

[0000080420-17-000032:mdna:74]
For the year ended September 30, 2017, our operating loss was reduced by $3.5 million as a result of changes in contract estimates related to projects in progress at the beginning of the year. These changes in estimates resulted primarily from, among other things, successful execution and close-out improvements, as well as other changes in facts and circumstances during these periods.

[0000080420-17-000032:mdna:75]
Revenue Recognition

[0000080420-17-000032:mdna:76]
Our revenues are primarily generated from the engineering and manufacturing of custom products under long-term contracts that may last from one month to several years, depending on the contract. Revenues from long-term contracts are recognized on the percentage-of-completion method of accounting.

[0000080420-17-000032:mdna:77]
Under the percentage-of-completion method of accounting, revenues are recognized as work is performed. The revenue earned to date is calculated by multiplying the total contract price by the percentage of performance to date, which is based on total costs or total labor dollars incurred to date compared to the total estimated costs or total labor dollars estimated at completion. The method used to determine the percentage of completion is typically the cost method, unless the labor method is a more accurate method of measuring the progress of the project. Application of the percentage-of-completion method of accounting requires the use of estimates of costs to be incurred for the performance of the contract. Contract costs include all direct material costs, direct labor costs and those indirect costs related to contract performance, such as indirect labor, supplies, tools, repairs and all costs associated with operation of equipment. The cost estimation process is based upon the professional knowledge and experience of our engineers, project managers and financial professionals. Factors that are considered in estimating the work to be completed and ultimate contract recovery include the availability and productivity of labor, the nature and complexity of the work to be performed, the effect of change orders, the availability of materials, the effect of any delays on our project performance and the recoverability of any claims. Changes in job performance, job conditions, estimated profitability and final contract settlements, including our estimate of liquidated damages, if any, may result in revisions to costs and income, with their effects being recognized in the period in which the revisions are determined. Whenever revisions of estimated contract costs and contract values indicate

[0000080420-17-000032:mdna:78]
that the contract costs will exceed estimated revenues, thus creating a loss, a provision for the total estimated loss is recorded in that period.

[0000080420-17-000032:mdna:79]
Revenues associated with maintenance, repair and service contracts are recognized when the services are performed. Expenses related to these types of services are recognized as incurred.

[0000080420-17-000032:mdna:80]
Costs and estimated earnings in excess of billings on uncompleted contracts also include certain costs associated with unapproved change orders. These costs are included when change order approval is probable. Amounts are carried at the lower of cost or net realizable value. Revenue is recognized to the extent of costs incurred when recovery is probable. The amounts recorded involve the use of judgments and estimates; thus, actual recoverable amounts could differ from original assumptions.

[0000080420-17-000032:mdna:81]
Allowance for Doubtful Accounts

[0000080420-17-000032:mdna:82]
We maintain and continually assess the adequacy of an allowance for doubtful accounts representing our estimate for losses resulting from the inability of our customers to pay amounts due to us. This estimated allowance is based on historical experience of uncollected accounts, the level of past due accounts, the overall level of outstanding accounts receivable, information about specific customers with respect to their inability to make payments and expectations of future conditions that could impact the collectability of accounts receivable. However, future changes in our customers’ operating performance and cash flows, or in general economic conditions, could have an impact on their ability to fully pay these amounts, which, among other things, could have a material adverse impact on our operating results.

[0000080420-17-000032:mdna:83]
Impairment of Long-Lived Assets

[0000080420-17-000032:mdna:84]
We review long-lived assets for impairment whenever events or changes in circumstances indicate that the carrying value may not be realizable. If an evaluation is required, the estimated future undiscounted cash flows associated with the asset are compared to the asset’s carrying amount to determine if recording an impairment of such asset is necessary. This requires us to make long-term forecasts of the future revenues and costs related to the assets subject to review. Forecasts require assumptions about demand for our products and future market conditions. Estimating future cash flows requires significant judgment, and our projections may vary from cash flows eventually realized. Future events and unanticipated changes to assumptions could require a provision for impairment in a future period. The effect of any impairment would be reflected in income (loss) from operations in the Consolidated Statements of Operations. In addition, we estimate the useful lives of our long-lived assets and other intangibles and periodically review these estimates to determine whether these lives are appropriate.

[0000080420-17-000032:mdna:85]
Accruals for Contingent Liabilities

[0000080420-17-000032:mdna:86]
From time to time, contingencies such as insurance-related claims, liquidated damages and legal claims arise in the normal course of business. Pursuant to applicable accounting standards, we must evaluate such contingencies to subjectively determine the likelihood that an asset has been impaired or a liability has been incurred at the date of the financial statements, as well as evaluate whether the amount of the loss can be reasonably estimated. If the likelihood is determined to be probable and it can be reasonably estimated, the estimated loss is recorded. The amounts we record for contingent liabilities require judgments regarding the amount of expenses that will ultimately be incurred. We use past experience and history, as well as the specific circumstances surrounding each contingent liability, including estimated legal costs, in evaluating the amount of liability that should be recorded. Actual results could differ from our estimates.

[0000080420-17-000032:mdna:87]
Warranty Costs

[0000080420-17-000032:mdna:88]
We provide for estimated warranty costs with the recognition of revenue based upon historical rates applicable to individual product lines. In addition, specific provisions are made when the costs of such warranties are expected to exceed accruals. Our standard terms and conditions of sale include a warranty for parts and service for the earlier of 18 months from the date of shipment or 12 months from the date of energization, whichever occurs first. Occasionally projects require warranty terms which are longer than our standard terms due to the nature of the project. Extended warranty terms may be negotiated and included in our contracts. We use past experience and historical claims to determine the estimated liability. Actual results could differ from our estimate.

[0000080420-17-000032:mdna:89]
Accounting for Income Taxes

[0000080420-17-000032:mdna:90]
We account for income taxes under the asset and liability method, based on the income tax laws and rates in the countries in which operations are conducted and income is earned. This approach requires the recognition of deferred tax assets and liabilities for the expected future tax consequences of temporary differences between the carrying amounts and the tax basis of assets and liabilities. Developing our provision for income taxes requires significant judgment and expertise in federal, international and state income

[0000080420-17-000032:mdna:91]
tax laws, regulations and strategies, including the determination of deferred tax assets and liabilities and, if necessary, any valuation allowances that may be required for deferred tax assets. In assessing the extent to which net deferred tax assets may be realized, we consider whether it is more likely than not that some portion or all of the net deferred tax assets may not be realized. The ultimate realization of net deferred tax assets is dependent on the generation of future taxable income during the periods in which those temporary differences become deductible. Due to the historical Canadian losses, and the losses that we projected at the time of determination, we were required under the more likely than not accounting standard to record a valuation allowance against the Canadian net deferred tax assets because we anticipated that we may not be able to realize the benefits of the net operating loss carryforwards and other deductible differences. Estimates may change as new events occur, estimates of future taxable income during the carryforward period are reduced or increased, additional information becomes available or operating environments change, which may result in a full or partial reversal of the valuation allowance. We will continue to assess the adequacy of the valuation allowance on a quarterly basis. Our judgments and tax strategies are subject to audit by various taxing authorities.

[0000080420-17-000032:mdna:92]
The objectives of accounting for income taxes are to recognize the amount of taxes payable or refundable for the current year and deferred tax liabilities and assets for the future tax consequences of events that have been recognized in an entity’s financial statements or tax returns. We recognize the tax benefit from an uncertain tax position only if it is more likely than not that the tax position will be sustained on examination by the taxing authorities, based on the technical merits of the position. The tax benefits recognized in the financial statements from such a position should be measured based on the largest benefit that has a greater than 50% likelihood of being realized upon ultimate settlement. Accounting literature also provides guidance on derecognition of income tax assets and liabilities, classification of current and deferred income tax assets and liabilities, accounting for interest and penalties associated with tax positions, and income tax disclosures. Judgment is required in assessing the future tax consequences of events that have been recognized in our financial statements or tax returns. Variations in the actual outcome of these future tax consequences could materially impact our financial statements.

[0000080420-17-000032:mdna:93]
See Note H of Notes to Consolidated Financial Statements for disclosures related to the valuation allowance recorded in relation to foreign deferred taxes.

[0000080420-17-000032:mdna:94]
Foreign Currency Translation

[0000080420-17-000032:mdna:95]
The functional currency for our foreign operating subsidiaries is the local currency in which the entity is located. The financial statements of all subsidiaries with a functional currency other than the U.S. Dollar have been translated into U.S. Dollars. All assets and liabilities of foreign operations are translated into U.S. Dollars using year-end exchange rates, and all revenues and expenses are translated at average rates during the respective period. The U.S. Dollar results that arise from such translation, as well as exchange gains and losses on intercompany balances of a long-term investment nature, are included in the cumulative currency translation adjustments in accumulated other comprehensive income in stockholders’ equity.

[0000080420-17-000032:mdna:96]
New Accounting Standards

[0000080420-17-000032:mdna:97]
In May 2014, the Financial Accounting Standards Board (FASB) issued a new standard on revenue recognition that supersedes previously issued revenue recognition guidance. This standard provides a five-step approach to be applied to all contracts with customers and requires expanded disclosures about the nature, amount, timing and uncertainty of revenue (and the related cash flows) arising from customer contracts, significant judgments and changes in judgments used in applying the revenue model and the assets recognized from costs incurred to obtain or fulfill a contract. This standard is effective for fiscal years, and interim periods within those years, beginning after December 15, 2017, which would be our fiscal year ending September 30, 2019. We plan to use the modified retrospective basis upon adoption. While we are still evaluating the potential impact of this standard on our financial statements, we believe accounting for variable consideration and the number of performance obligations contained in each contract will have the greatest significance. The materiality of this guidance on our financial statements will be determined in large part by the contracts that are in progress as of the adoption date.

[0000080420-17-000032:mdna:98]
In November 2015, the FASB issued an amendment to the topic regarding income taxes which requires an entity to separate deferred income tax liabilities and assets into current and noncurrent amounts in the statement of financial position. Deferred tax liabilities and assets are classified as current or noncurrent based on the classification of the related asset or liability for financial reporting. Deferred tax liabilities and assets that are not related to an asset or liability for financial reporting are classified according to the expected reversal date of the temporary difference. To simplify the presentation of deferred income taxes, the amendments require that deferred income tax liabilities and assets be classified as noncurrent in a classified statement of financial position. This amendment is effective for annual reporting periods beginning after December 15, 2016, which would be our fiscal year ending September 30, 2018. We have no plans for early adoption. We are still evaluating this new amendment, but we do not expect it to have a material impact on our consolidated financial position or results of operations.

[0000080420-17-000032:mdna:99]
In February 2016, the FASB issued a new topic on leases which requires lessees to recognize lease assets and lease liabilities on the balance sheet for all leases with terms longer than twelve months. Leases will be classified as either finance or operating, with classification affecting the pattern of expense recognition in the income statement. A modified retrospective transition approach is required for lessees for capital and operating leases existing at, or entered into after, the beginning of the earliest comparative period presented in the financial statements, with certain practical expedients available. The new topic is effective for fiscal years beginning after December 15, 2018, including interim periods within those fiscal years, which would be our fiscal year ending September 30, 2020.  We are still evaluating the potential impact of this guidance on our financial statements. Our future obligations under operating leases as of September 30, 2017 are summarized in Note G of the Notes to Consolidated Financial Statements.

[0000080420-17-000032:mdna:100]
In March 2016, the FASB issued new guidance on stock-based compensation, which includes amendments to existing guidance for employee share-based payment accounting. We elected to early adopt this new guidance in the first quarter of Fiscal 2017.  Beginning Fiscal 2017, stock-based compensation excess tax benefits or deficiencies are reflected in the Consolidated Statement of Operations as a component of income taxes, whereas they were previously recorded in additional paid-in capital in the Consolidated Statement of Stockholders’ Equity. Additionally, we will now present excess tax benefits as an operating activity in the Consolidated Statements of Cash Flows. These changes have been adopted prospectively.  Finally, we will continue to account for forfeitures as they occur, rather than estimate expected forfeitures.

[0000080420-17-000032:mdna:101]
In November 2016, the FASB issued new standards on the statement of cash flows and restricted cash that change the presentation of restricted cash and cash equivalents on the statement of cash flows. Restricted cash and restricted cash equivalents will be included with cash and cash equivalents when reconciling the beginning-of-period and end-of-period total amounts shown on the statement of cash flows. These standards are effective for public business entities for fiscal years beginning after December 15, 2017, and interim periods within those fiscal years, which would be our fiscal year ending September 30, 2019. We have no plans for early adoption. We are still evaluating these new standards, but we do not expect them to have a material impact on our consolidated financial position or results of operations.

[0000080420-17-000032:mdna:102]
In January 2017, the FASB issued new guidance on goodwill impairment intended to simplify the testing for goodwill impairment by the elimination of Step 2 in the determination on whether goodwill should be considered impaired. The annual and/or interim assessments are still required to be completed. This guidance is effective for fiscal years (including interim periods) beginning after December 15, 2019. The adoption of this guidance is not expected to have a material impact on our consolidated financial position or results of operations.

[0000080420-17-000032:mdna:103]
In May 2017, the FASB issued a new topic on modification accounting with regards to stock-based compensation. This new topic clarifies when a change to the terms or conditions of a share-based payment award should be accounted for as a modification. An entity should account for the effects of a modification unless the fair value, vesting conditions and classification, as an equity instrument or a liability instrument, of the modified award are the same before and after a change to the terms or conditions of the share-based payment award. This topic is effective for annual reporting periods beginning after December 15, 2017, which would be our fiscal year ending September 30, 2018. We do not expect this topic to have a material impact on our consolidated financial position or results of operations.
