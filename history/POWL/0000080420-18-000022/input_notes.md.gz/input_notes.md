# POWL notes — 0000080420-18-000022


## us-gaap:AllowanceForCreditLossesOnFinancingReceivablesTableTextBlock

[0000080420-18-000022:notes:1]
[same as prior period, unchanged from 0000080420-18-000013:notes:1]

[0000080420-18-000022:notes:2]
|  | Three months ended June 30, |  | Nine months ended June 30, |
|  | 2018 |  | 2017 |  | 2018 |  | 2017 |
| Balance at beginning of period | $ | 264 |  |  | $ | 310 |  |  | $ | 179 |  |  | $ | 811 |  |
| Bad debt expense (recovery) | 18 |  |  | (129 | ) |  | 110 |  |  | (226 | ) |
| Uncollectible accounts written off, net of recoveries | (36 | ) |  | (92 | ) |  | (44 | ) |  | (493 | ) |
| Change due to foreign currency translation | (7 | ) |  | 1 |  |  | (6 | ) |  | (2 | ) |
| Balance at end of period | $ | 239 |  |  | $ | 90 |  |  | $ | 239 |  |  | $ | 90 |  |


## us-gaap:BasisOfAccountingPolicyPolicyTextBlock

[0000080420-18-000022:notes:3]
[same as prior period, unchanged from 0000080420-18-000013:notes:3]

[0000080420-18-000022:notes:4]
[same as prior period, unchanged from 0000080420-18-000013:notes:4]

[0000080420-18-000022:notes:5]
[same as prior period, unchanged from 0000080420-18-000013:notes:5]

[0000080420-18-000022:notes:6]
[same as prior period, unchanged from 0000080420-18-000013:notes:6]

[0000080420-18-000022:notes:7]
[same as prior period, unchanged from 0000080420-18-000013:notes:7]


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0000080420-18-000022:notes:8]
COMMITMENTS AND CONTINGENCIES

[0000080420-18-000022:notes:9]
Letters of Credit, Surety Bonds and Bank Guarantees

[0000080420-18-000022:notes:10]
Certain customers require us to post letters of credit or surety bonds which assure that we will perform under the terms of our contract. In the event of default, the counterparty may demand payment from the bank under a letter of credit or performance by the surety under a bond. To date, there have been no significant expenses related to either letters of credit or surety bonds for the periods reported. We were contingently liable for letters of credit of $22.3 million as of June 30, 2018. We also had surety bonds totaling $168.3 million that were outstanding, with additional bonding capacity of $581.7 million available, at June 30, 2018.

[0000080420-18-000022:notes:11]
Additionally, we have a $6.6 million facility agreement (Facility Agreement) between Powell (UK) Limited and a large international bank. This Facility Agreement provides Powell (UK) Limited the ability to enter into bank guarantees as well as forward exchange contracts and currency options. At June 30, 2018, we had outstanding guarantees totaling $3.2 million under this Facility Agreement and amounts available under this Facility Agreement were $3.4 million. The Facility Agreement provides for financial covenants and customary events of default, and carries cross-default provisions with our U.S. Revolver. If an event of default (as defined in the Facility Agreement) occurs and is continuing, per the terms and subject to the conditions set forth therein, obligations outstanding under the Facility Agreement may be accelerated and declared immediately due and payable. As of June 30, 2018, we were in compliance with all of the financial covenants of the Facility Agreement.

[0000080420-18-000022:notes:12]
Litigation

[0000080420-18-000022:notes:13]
We are involved in various legal proceedings, claims and other disputes arising from our commercial operations, projects, employees and other matters which, in general, are subject to uncertainties and in which the outcomes are not predictable. Although we can give no assurances about the resolution of pending claims, litigation or other disputes and the effect such outcomes may have on us, management believes that any ultimate liability resulting from the outcome of such proceedings, to the extent not otherwise provided or covered by insurance, will not have a material adverse effect on our consolidated financial position or results of operations or liquidity.

[0000080420-18-000022:notes:14]
Liquidated Damages

[0000080420-18-000022:notes:15]
Certain of our customer contracts have schedule and performance obligation clauses that, if we fail to meet them, could require us to pay liquidated damages. Each individual contract defines the conditions under which the customer may make a claim against us. As of June 30, 2018, our exposure to possible liquidated damages was $2.6 million, of which approximately $1.6 million is probable. Based on our actual or projected failure to meet these various contractual commitments, $1.5 million has been recorded as a reduction to revenue. Of the $1.5 million recorded as a reduction to revenue, approximately $1.0 million was recognized in prior periods. We will attempt to obtain change orders, contract extensions or accelerate project completion which may resolve the potential for any unaccrued liquidated damage. Should we fail to achieve relief on some or all of these contractual obligations, we could be required to pay additional liquidated damages, which could negatively impact our future operating results.


## us-gaap:CostsInExcessOfBillingsAndBillingsInExcessOfCostsTableTextBlock

[0000080420-18-000022:notes:16]
[same as prior period, unchanged from 0000080420-18-000013:notes:16]

[0000080420-18-000022:notes:17]
|  | June 30, 2018 |  | September 30, 2017 |
| Costs incurred on uncompleted contracts | $ | 823,190 |  |  | $ | 987,164 |  |
| Estimated earnings | 246,852 |  |  | 316,970 |  |
|  | 1,070,042 |  |  | 1,304,134 |  |
| Less: Billings to date | (1,038,540 | ) |  | (1,278,746 | ) |
| Net underbilled position | $ | 31,502 |  |  | $ | 25,388 |  |
| Included in the accompanying balance sheets under the following captions: |  |  |  |
| Costs and estimated earnings in excess of billings on uncompleted contracts | $ | 70,939 |  |  | $ | 51,554 |  |
| Billings in excess of costs and estimated earnings on uncompleted contracts | (39,437 | ) |  | (26,166 | ) |
| Net underbilled position | $ | 31,502 |  |  | $ | 25,388 |  |


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0000080420-18-000022:notes:18]
[same as prior period, unchanged from 0000080420-18-000013:notes:18]

[0000080420-18-000022:notes:19]
[same as prior period, unchanged from 0000080420-18-000013:notes:19]

[0000080420-18-000022:notes:20]
[same as prior period, unchanged from 0000080420-18-000013:notes:20]

[0000080420-18-000022:notes:21]
We issue restricted stock units (RSUs) to certain officers and key employees of the Company. The fair value of the RSUs is based on the price of our common stock as reported on the NASDAQ Global Market on the grant dates. The typical annual grant vests over a three-year period from the date of issuance. Sixty percent of those grants are time-based and vest over a three-year period on each anniversary of the grant date, based on continued employment. The remaining forty percent of the grant will be earned based on the three-year earnings performance of the Company following the grant date. At June 30, 2018, there were 199,317 RSUs outstanding. The RSUs do not have voting rights but do receive dividend equivalents upon vesting; additionally, the shares of common stock underlying the RSUs are not considered issued and outstanding until vested and common stock is issued.

[0000080420-18-000022:notes:22]
RSU activity (number of shares) for the nine months ended June 30, 2018 is summarized below:

[0000080420-18-000022:notes:23]
|  | Number ofRestrictedStockUnits |  | WeightedAverageFair ValuePer Share |
| Outstanding at September 30, 2017 | 177,737 |  |  | $ | 37.00 |  |
| Granted | 88,000 |  |  | 29.88 |  |
| Vested | (43,620 | ) |  | 35.30 |  |
| Forfeited/canceled | (22,800 | ) |  | 41.88 |  |
| Outstanding at June 30, 2018 | 199,317 |  |  | $ | 33.69 |  |

[0000080420-18-000022:notes:24]
During the nine months ended June 30, 2018 and 2017, we recorded compensation expense of $2.0 million and $1.7 million, respectively, related to the RSUs.

[0000080420-18-000022:notes:25]
[same as prior period, unchanged from 0000080420-18-000013:notes:25]

[0000080420-18-000022:notes:26]
Each non-employee director receives 2,000 restricted shares of the Company’s common stock annually. Fifty-percent of the restricted stock granted to each of our non-employee directors vests immediately, while the remaining fifty-percent will vest on the first anniversary of the grant date. Compensation expense is recognized immediately for the first fifty-percent of the restricted stock granted, while compensation expense for the remaining fifty-percent is recognized over the remaining vesting period based on the price per share on the grant date. In February 2018, 12,000 shares of restricted stock were issued to our non-employee directors under the 2014 Director Plan at a price of $27.88 per share. In April 2018, we issued 2,000 shares of restricted stock to a non-employee director at a price of $27.15 per share.

[0000080420-18-000022:notes:27]
During the nine months ended June 30, 2018 and 2017, we recorded compensation expense of $0.4 million and $0.6 million, respectively, related to restricted stock.


## us-gaap:EarningsPerShareTextBlock

[0000080420-18-000022:notes:28]
[same as prior period, unchanged from 0000080420-18-000013:notes:28]

[0000080420-18-000022:notes:29]
[same as prior period, unchanged from 0000080420-18-000013:notes:29]

[0000080420-18-000022:notes:30]
[same as prior period, unchanged from 0000080420-18-000013:notes:30]

[0000080420-18-000022:notes:31]
|  | Three months ended June 30, |  | Nine months ended June 30, |
|  | 2018 |  | 2017 |  | 2018 |  | 2017 |
| Numerator: |  |  |  |  |  |  |  |
| Net income (loss) | $ | 301 |  |  | $ | (3,215 | ) |  | $ | (8,691 | ) |  | $ | (4,343 | ) |
| Denominator: |  |  |  |  |  |  |  |
| Weighted average basic shares | 11,514 |  |  | 11,463 |  |  | 11,503 |  |  | 11,449 |  |
| Dilutive effect of restricted stock units | 73 |  |  | — |  |  | — |  |  | — |  |
| Weighted average diluted shares | 11,587 |  |  | 11,463 |  |  | 11,503 |  |  | 11,449 |  |
| Income (loss) per share: |  |  |  |  |  |  |  |
| Basic | $ | 0.03 |  |  | $ | (0.28 | ) |  | $ | (0.76 | ) |  | $ | (0.38 | ) |
| Diluted | $ | 0.03 |  |  | $ | (0.28 | ) |  | $ | (0.76 | ) |  | $ | (0.38 | ) |

[0000080420-18-000022:notes:32]
For the quarter ended June 30, 2017 and nine months ended June 30, 2018 and 2017, we incurred net losses and therefore all potential common shares were deemed to be anti-dilutive.


## us-gaap:FairValueDisclosuresTextBlock

[0000080420-18-000022:notes:33]
[same as prior period, unchanged from 0000080420-18-000013:notes:33]

[0000080420-18-000022:notes:34]
[same as prior period, unchanged from 0000080420-18-000013:notes:34]

[0000080420-18-000022:notes:35]
[same as prior period, unchanged from 0000080420-18-000013:notes:35]

[0000080420-18-000022:notes:36]
[same as prior period, unchanged from 0000080420-18-000013:notes:36]

[0000080420-18-000022:notes:37]
[same as prior period, unchanged from 0000080420-18-000013:notes:37]

[0000080420-18-000022:notes:38]
[same as prior period, unchanged from 0000080420-18-000013:notes:38]

[0000080420-18-000022:notes:39]
The following table summarizes the fair value of our assets and liabilities that were accounted for at fair value on a recurring basis as of June 30, 2018 (in thousands):

[0000080420-18-000022:notes:40]
|  | Fair Value Measurements at June 30, 2018 |
|  | Quoted Prices inActive Markets forIdentical Assets(Level 1) |  | Significant OtherObservableInputs(Level 2) |  | SignificantUnobservableInputs(Level 3) |  | Fair Value at June 30, 2018 |
| Assets: |  |  |  |  |  |  |  |
| Cash and cash equivalents | $ | 40,075 |  |  | $ | — |  |  | $ | — |  |  | $ | 40,075 |  |
| Short-term investments | 15,218 |  |  | — |  |  | — |  |  | 15,218 |  |
| Restricted cash | 23,587 |  |  | — |  |  | — |  |  | 23,587 |  |
| Deferred compensation | — |  |  | 6,591 |  |  | — |  |  | 6,591 |  |
| Liabilities: |  |  |  |  |  |  |  |
| Deferred compensation | — |  |  | 5,377 |  |  | — |  |  | 5,377 |  |

[0000080420-18-000022:notes:41]
[same as prior period, unchanged from 0000080420-18-000013:notes:41]

[0000080420-18-000022:notes:42]
|  | Fair Value Measurements at September 30, 2017 |
|  | Quoted Prices inActive Markets forIdentical Assets(Level 1) |  | Significant OtherObservableInputs(Level 2) |  | SignificantUnobservableInputs(Level 3) |  | Fair Value at September 30, 2017 |
| Assets: |  |  |  |  |  |  |  |
| Cash and cash equivalents | $ | 68,359 |  |  | $ | — |  |  | $ | — |  |  | $ | 68,359 |  |
| Short-term investments | 26,829 |  |  | — |  |  | — |  |  | 26,829 |  |
| Restricted cash | 24,851 |  |  |  |  |  |  | 24,851 |  |
| Deferred compensation | — |  |  | 6,442 |  |  | — |  |  | 6,442 |  |
| Liabilities: |  |  |  |  |  |  |  |
| Deferred compensation | — |  |  | 4,991 |  |  | — |  |  | 4,991 |  |

[0000080420-18-000022:notes:43]
[same as prior period, unchanged from 0000080420-18-000013:notes:43]

[0000080420-18-000022:notes:44]
[same as prior period, unchanged from 0000080420-18-000013:notes:44]

[0000080420-18-000022:notes:45]
[same as prior period, unchanged from 0000080420-18-000013:notes:45]

[0000080420-18-000022:notes:46]
[same as prior period, unchanged from 0000080420-18-000013:notes:46]

[0000080420-18-000022:notes:47]
[same as prior period, unchanged from 0000080420-18-000013:notes:47]

[0000080420-18-000022:notes:48]
[same as prior period, unchanged from 0000080420-18-000013:notes:48]

[0000080420-18-000022:notes:49]
There were no transfers between levels within the fair value measurement hierarchy during the quarter ended June 30, 2018.


## us-gaap:IncomeTaxDisclosureTextBlock

[0000080420-18-000022:notes:50]
[same as prior period, unchanged from 0000080420-18-000013:notes:50]

[0000080420-18-000022:notes:51]
[same as prior period, unchanged from 0000080420-18-000013:notes:51]

[0000080420-18-000022:notes:52]
|  | Three months ended June 30, |  | Nine months ended June 30, |
|  | 2018 |  | 2017 |  | 2018 |  | 2017 |
| Income (loss) before income taxes | $ | 689 |  |  | $ | (6,898 | ) |  | $ | (11,134 | ) |  | $ | (10,812 | ) |
| Income tax provision (benefit) | 388 |  |  | (3,683 | ) |  | (2,443 | ) |  | (6,469 | ) |
| Net income (loss) | $ | 301 |  |  | $ | (3,215 | ) |  | $ | (8,691 | ) |  | $ | (4,343 | ) |
| Effective tax rate | 56 | % |  | 53 | % |  | 22 | % |  | 60 | % |

[0000080420-18-000022:notes:53]
On December 22, 2017, President Trump signed into law the Tax Cuts and Jobs Act (the Act). The Act lowers the corporate tax rate from 35% to 21% effective January 1, 2018. As a result, the U.S. federal statutory rate for Fiscal 2018 is a reduced blended U.S. tax rate of 24.5%. The final impact of the Act may differ from our estimates based on changes in interpretations or assumptions we make, as well as the issuance of additional guidance.

[0000080420-18-000022:notes:54]
In the third quarter of Fiscal 2018, the effective tax rate was negatively impacted by the relative amounts of income/loss recognized in various jurisdictions as well as a foreign tax loss which is reserved with a valuation allowance. The effective tax rate for the third quarter of Fiscal 2017 was favorably impacted by discrete items recognized during the quarter, primarily related to the Research and Development Tax Credit (R&D Tax Credit). The effective tax rate for the third quarter of Fiscal 2017 was also favorably impacted by the lower tax rate in the United Kingdom, the relative amounts of income/loss recognized in various jurisdictions, as well as the utilization of net operating loss carryforwards in Canada that are fully reserved with a valuation allowance.

[0000080420-18-000022:notes:55]
The effective tax rate for the nine months ended June 30, 2018 decreased due to the lower U.S. corporate tax rate as well as a foreign tax loss which is reserved with a valuation allowance. Additionally we recorded deferred tax expense of $0.7 million due to the re-measurement of our U.S. deferred tax assets under the Act, which are not expected to be realized prior to the end of Fiscal 2018. The effective tax rate for the nine months ended June 30, 2017 was favorably impacted by discrete items, primarily related to the R&D Tax Credit. The effective tax rate for the nine months ended June 30, 2017 was also favorably impacted by the lower tax rate in the United Kingdom, the relative amounts of income/loss recognized in various jurisdictions, as well as the utilization of net operating loss carryforwards in Canada that are fully reserved with a valuation allowance.


## us-gaap:LongTermDebtTextBlock

[0000080420-18-000022:notes:56]
LONG-TERM DEBT

[0000080420-18-000022:notes:57]
Long-term debt consisted of the following (in thousands):

[0000080420-18-000022:notes:58]
|  | June 30, 2018 |  | September 30, 2017 |
| Industrial development revenue bonds | $ | 1,600 |  |  | $ | 2,000 |  |
| Less current portion | (400 | ) |  | (400 | ) |
| Total long-term debt | $ | 1,200 |  |  | $ | 1,600 |  |

[0000080420-18-000022:notes:59]
U.S. Revolver

[0000080420-18-000022:notes:60]
We have a $75.0 million revolving credit facility (U.S. Revolver) to provide working capital support and letters of credit which expires on June 27, 2022. The amount available under the U.S. Revolver at June 30, 2018 was reduced by $22.3 million for our outstanding letters of credit. Currently, our U.S. Revolver can only be used for letters of credit until we meet certain financial ratios. There were no loans outstanding under the U.S. Revolver as of June 30, 2018.

[0000080420-18-000022:notes:61]
Per the terms of the U.S. Revolver, we are required to maintain a cash balance in a pledged cash collateral account equal to 102% of the outstanding amount of any loans and letter of credit obligations until we meet certain financial ratios. As of June 30, 2018, the balance in the pledged account was $23.6 million. The cash collateral associated with the outstanding letters of credit that are due to expire beyond twelve months has been classified as non-current restricted cash on the balance sheet. As of June 30, 2018, there was $52.7 million available for the issuance of letters of credit under the U.S. Revolver.

[0000080420-18-000022:notes:62]
The interest rate for amounts outstanding under the U.S. Revolver is a floating rate based upon the higher of the Federal Funds Rate plus 0.5%, the bank’s prime rate, or the Eurocurrency rate plus 1.00%. Once the applicable rate is determined, a margin ranging up to 1.25% is added to the applicable rate.

[0000080420-18-000022:notes:63]
The U.S. Revolver is collateralized by a pledge of 100% of the voting capital stock of each of our domestic subsidiaries and 65% of the voting capital stock of each non-domestic subsidiary. The U.S. Revolver provides for customary events of default and carries cross-default provisions with other existing debt agreements. If an event of default (as defined in the U.S. Revolver) occurs and is continuing, on the terms and subject to the conditions set forth in the U.S. Revolver, amounts outstanding under the U.S. Revolver may be accelerated and may become immediately due and payable. It also contains financial covenants defining various financial measures and the levels of these measures with which we must comply, as well as a “material adverse change” clause. A “material adverse change” is defined as a material change in our operations, business, properties, liabilities or condition (financial or otherwise) or a material impairment of our ability to perform our obligations under our credit agreements. As of June 30, 2018, we were in compliance with all of the financial covenants of the U.S. Revolver.

[0000080420-18-000022:notes:64]
Industrial Development Revenue Bonds

[0000080420-18-000022:notes:65]
We borrowed $8.0 million in October 2001 through a loan agreement funded with proceeds from tax-exempt industrial development revenue bonds (Bonds). These Bonds were issued by the Illinois Development Finance Authority and were used for the completion of our Northlake, Illinois facility. Pursuant to the Bond issuance, a reimbursement agreement between us and a major domestic bank required an issuance by the bank of an irrevocable direct-pay letter of credit (Bond LC), as collateral, to the Bonds’ trustee to guarantee payment of the Bonds’ principal and interest when due. The Bond LC is subject to both early termination and extension provisions customary to such agreements, as well as various covenants, for which we were in compliance at June 30, 2018. While the Bonds mature in 2021, the reimbursement agreement requires annual redemptions of $0.4 million that commenced on October 25, 2002. A sinking fund is used for the redemption of the Bonds. The Bonds bear interest at a floating rate determined weekly by the Bonds’ remarketing agent, which was the underwriter for the Bonds and is an affiliate of the bank. This interest rate was 1.58% as of June 30, 2018.


## us-gaap:NewAccountingPronouncementsPolicyPolicyTextBlock

[0000080420-18-000022:notes:66]
New Accounting Standards

[0000080420-18-000022:notes:67]
In May 2014, the Financial Accounting Standards Board (FASB) issued a new standard on revenue recognition that supersedes previously issued revenue recognition guidance. This standard provides a five-step approach to be applied to all contracts with customers and requires expanded disclosures about the nature, amount, timing and uncertainty of revenue (and the related cash flows) arising from customer contracts, significant judgments and changes in judgments used in applying the revenue model and the assets recognized from costs incurred to obtain or fulfill a contract. This standard is effective for fiscal years, and interim periods within those years, beginning after December 15, 2017, which would be our fiscal year ending September 30, 2019. We plan to use the modified retrospective basis upon adoption which could result in a cumulative effect adjustment as of October 1, 2018, if material. We continue to hold regular meetings with our implementation team which includes training and evaluating contracts to identity potential impacts of the standard on our current accounting policies and disclosures. We will update our accounting policies and procedures and determine the impact from this new standard on our contracts outstanding as of October 1, 2018. While we are still evaluating the potential impact of this standard on our financial statements, we believe accounting for variable consideration, cancellations for convenience clauses and the number of performance obligations contained in each contract could have the greatest significance. We have not yet been able to estimate the impact the new revenue recognition criteria will have on our consolidated financial statements and related disclosures, but the impact on our financial statements from this guidance will be determined in large part by the contracts that are in progress as of the adoption date.

[0000080420-18-000022:notes:68]
In November 2015, the FASB issued an amendment to the topic regarding income taxes which requires an entity to separate deferred income tax liabilities and assets into current and noncurrent amounts in the statement of financial position.  Deferred tax liabilities and assets are classified as current or noncurrent based on the classification of the related asset or liability for financial reporting.  Deferred tax liabilities and assets that are not related to an asset or liability for financial reporting are classified according to the expected reversal date of the temporary difference. To simplify the presentation of deferred income taxes, the amendments require that deferred income tax liabilities and assets be classified as noncurrent in a classified statement of financial position. We have adopted this topic prospectively in Fiscal 2018 and our statement of financial position reflects this reclassification. We have not retrospectively adjusted prior periods.

[0000080420-18-000022:notes:69]
In February 2016, the FASB issued a new topic on leases which requires lessees to recognize lease assets and lease liabilities on the balance sheet for all leases with terms longer than twelve months. Leases will be classified as either finance or operating, with classification affecting the pattern of expense recognition in the income statement. A modified retrospective transition approach is required for lessees for capital and operating leases existing at, or entered into after, the beginning of the earliest comparative period presented in the financial statements, with certain practical expedients available. The new topic is effective for fiscal years beginning after December 15, 2018, including interim periods within those fiscal years. This would be our fiscal year ending September 30, 2020. We are still evaluating the potential impact of this topic on our financial statements.

[0000080420-18-000022:notes:70]
In November 2016, the FASB issued a new topic on the statement of cash flows that changes the presentation of restricted cash and cash equivalents on the statement of cash flows. Restricted cash and restricted cash equivalents will be included with cash and cash equivalents when reconciling the beginning-of-period and end-of-period total amounts shown on the statement of cash flows. This topic is effective for fiscal years beginning after December 15, 2017, and interim periods within those fiscal years, which would be our fiscal year ending September 30, 2019. We are still evaluating this new topic, but do not expect it to have a material impact on our statement of cash flows.

[0000080420-18-000022:notes:71]
In May 2017, the FASB issued a new topic on modification accounting with regards to stock based compensation. This new topic clarifies when a change to the terms or conditions of a share-based payment award should be accounted for as a modification. An entity should account for the effects of a modification unless the fair value, vesting conditions and classification, as an equity instrument or a liability instrument, of the modified award are the same before and after a change to the terms or conditions of the share-based payment award. This topic is effective for annual reporting periods beginning after December 15, 2017, which is our fiscal year ending September 30, 2019. We are still evaluating this new topic, but do not expect it to have a material impact on our consolidated financial position or results of operations.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureAndSignificantAccountingPoliciesTextBlock

[0000080420-18-000022:notes:72]
[same as prior period, unchanged from 0000080420-18-000013:notes:71]

[0000080420-18-000022:notes:73]
[same as prior period, unchanged from 0000080420-18-000013:notes:72]

[0000080420-18-000022:notes:74]
[same as prior period, unchanged from 0000080420-18-000013:notes:73]

[0000080420-18-000022:notes:75]
[same as prior period, unchanged from 0000080420-18-000013:notes:74]

[0000080420-18-000022:notes:76]
[same as prior period, unchanged from 0000080420-18-000013:notes:75]

[0000080420-18-000022:notes:77]
[same as prior period, unchanged from 0000080420-18-000013:notes:76]


## us-gaap:ScheduleOfInventoryCurrentTableTextBlock

[0000080420-18-000022:notes:78]
[same as prior period, unchanged from 0000080420-18-000013:notes:77]

[0000080420-18-000022:notes:79]
|  | June 30, 2018 |  | September 30, 2017 |
| Raw materials, parts and subassemblies, net | $ | 21,402 |  |  | $ | 17,848 |  |
| Work-in-progress | 1,452 |  |  | 600 |  |
| Total inventories | $ | 22,854 |  |  | $ | 18,448 |  |


## us-gaap:ScheduleOfProductWarrantyLiabilityTableTextBlock

[0000080420-18-000022:notes:80]
[same as prior period, unchanged from 0000080420-18-000013:notes:79]

[0000080420-18-000022:notes:81]
|  | Three months ended June 30, |  | Nine months ended June 30, |
|  | 2018 |  | 2017 |  | 2018 |  | 2017 |
| Balance at beginning of period | $ | 2,241 |  |  | $ | 3,649 |  |  | $ | 3,174 |  |  | $ | 4,639 |  |
| Increase in warranty expense | 1,036 |  |  | 593 |  |  | 970 |  |  | 1,313 |  |
| Deduction for warranty charges | (891 | ) |  | (949 | ) |  | (1,752 | ) |  | (2,618 | ) |
| Change due to foreign currency translation | (23 | ) |  | 39 |  |  | (29 | ) |  | (2 | ) |
| Balance at end of period | $ | 2,363 |  |  | $ | 3,332 |  |  | $ | 2,363 |  |  | $ | 3,332 |  |


## us-gaap:SubsequentEventsTextBlock

[0000080420-18-000022:notes:82]
SUBSEQUENT EVENTS

[0000080420-18-000022:notes:83]
On August 6, 2018, our Board of Directors declared a quarterly cash dividend on our common stock in the amount of $0.26 per share. The dividend is payable on September 19, 2018 to shareholders of record at the close of business on August 22, 2018.


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0000080420-18-000022:notes:84]
[same as prior period, unchanged from 0000080420-18-000013:notes:83]

[0000080420-18-000022:notes:85]
[same as prior period, unchanged from 0000080420-18-000013:notes:84]

[0000080420-18-000022:notes:86]
[same as prior period, unchanged from 0000080420-18-000013:notes:85]

[0000080420-18-000022:notes:87]
[same as prior period, unchanged from 0000080420-18-000013:notes:86]

[0000080420-18-000022:notes:88]
[same as prior period, unchanged from 0000080420-18-000013:notes:87]
