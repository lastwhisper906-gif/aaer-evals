# POWL MD&A — 0000080420-18-000022


## mdna

[0000080420-18-000022:mdna:1]
[same as prior period, unchanged from 0000080420-18-000013:mdna:1]

[0000080420-18-000022:mdna:2]
[same as prior period, unchanged from 0000080420-18-000013:mdna:2]

[0000080420-18-000022:mdna:3]
[same as prior period, unchanged from 0000080420-18-000013:mdna:3]

[0000080420-18-000022:mdna:4]
[same as prior period, unchanged from 0000080420-18-000013:mdna:4]

[0000080420-18-000022:mdna:5]
[same as prior period, unchanged from 0000080420-18-000013:mdna:5]

[0000080420-18-000022:mdna:6]
Due to the significant decline in oil and gas prices from peak 2014 levels, many of our customers have reduced their capital budgets and cut costs, and in certain instances have delayed or cancelled projects that we were pursuing. As a result, our revenues and project backlog declined. In response to our reduced project backlog and the challenging market outlook in our core oil, gas and petrochemical markets, we took steps in Fiscal 2016 and 2017 to reduce our overall cost structure and better align our costs with future production requirements. Since the second half of Fiscal 2017, our core oil, gas and petrochemical markets have begun to strengthen resulting in increased revenues and backlog.

[0000080420-18-000022:mdna:7]
[same as prior period, unchanged from 0000080420-18-000013:mdna:7]

[0000080420-18-000022:mdna:8]
Quarter Ended June 30, 2018 Compared to the Quarter Ended June 30, 2017 (Unaudited)

[0000080420-18-000022:mdna:9]
[same as prior period, unchanged from 0000080420-18-000013:mdna:9]

[0000080420-18-000022:mdna:10]
Revenues increased by 42%, or $36.2 million, to $122.1 million in the third quarter of Fiscal 2018, compared to the third quarter of Fiscal 2017, primarily due to an increase in orders from our domestic operations in Fiscal 2018. Domestic revenues increased by 66%, or $36.2 million, to $91.3 million in the third quarter of Fiscal 2018, compared to the third quarter of Fiscal 2017. International revenues were $30.8 million in the third quarter of Fiscal 2018 and the third quarter of Fiscal 2017. Our international revenue includes both revenue generated from our international facilities as well as export revenues from our domestic facilities. Revenues from commercial and industrial customers increased by 94%, or $45.3 million, to $93.3 million in the third quarter of Fiscal 2018, compared to the third quarter of Fiscal 2017. Revenues from public and private utilities decreased by 32%, or $9.1 million, to $19.3 million in the third quarter of Fiscal 2018, compared to the third quarter of Fiscal 2017. Revenues from municipal and transit projects were $9.5 million in the third quarter of Fiscal 2018, and the third quarter of Fiscal 2017. The increase in commercial and industrial revenues and decrease in public and private utilities revenues were primarily due to the timing of projects.

[0000080420-18-000022:mdna:11]
Gross profit for the third quarter of Fiscal 2018 increased by 103%, or $9.3 million, to $18.4 million, compared to the third quarter of Fiscal 2017. Gross profit as a percentage of revenues increased to 15% in the third quarter of Fiscal 2018, compared to 11% in the third quarter of Fiscal 2017. Gross profit and margins are improving due to improved efficiencies in our manufacturing facilities and increased volumes due to the increased demand.

[0000080420-18-000022:mdna:12]
[same as prior period, unchanged from 0000080420-18-000013:mdna:12]

[0000080420-18-000022:mdna:13]
Selling, general and administrative expenses increased by $1.4 million, to $16.2 million during the third quarter of Fiscal 2018, compared to $14.8 million in the third quarter of Fiscal 2017, primarily due to the timing of variable performance based compensation. Selling, general and administrative expenses, as a percentage of revenues, decreased to 13% during the third quarter of Fiscal 2018, compared to 17% during the third quarter of Fiscal 2017, primarily due to the increase in revenues.

[0000080420-18-000022:mdna:14]
Income Tax Provision/Benefit

[0000080420-18-000022:mdna:15]
We recorded an income tax provision of $0.4 million in the third quarter of Fiscal 2018, compared to an income tax benefit of $3.7 million in the third quarter of Fiscal 2017. The effective tax rate for the third quarter of Fiscal 2018 was 56% compared to an effective tax rate of 53% in the third quarter of Fiscal 2017. On December 22, 2017, President Trump signed into law the Tax Cuts and Jobs Act (the Act). The Act lowered the corporate tax rate from 35% to 21% effective January 1, 2018. The final impact of the Act may differ from our estimates based on changes in interpretations or assumptions we make, as well as the issuance of additional guidance. In the third quarter of Fiscal 2018, the effective tax rate was negatively impacted by the relative amounts of income/loss recognized in various jurisdictions as well as a foreign tax loss which is reserved with a valuation allowance. The effective tax rate for the third quarter of 2017 was favorably impacted by discrete items recognized during the quarter, primarily related to the Research and Development Tax Credit (R&D Tax Credit). The effective tax rate for the third quarter of Fiscal 2017 was also favorably impacted by the lower tax rate in the United Kingdom, the relative amounts of income/loss recognized in various jurisdictions, as well as the utilization of net operating loss carryforwards in Canada that are fully reserved with a valuation allowance.

[0000080420-18-000022:mdna:16]
Net Income/Loss

[0000080420-18-000022:mdna:17]
In the third quarter of Fiscal 2018, we recorded income of $0.3 million, or $0.03 per diluted share compared to a net loss of $3.2 million, or $0.28 per diluted share, in the third quarter of Fiscal 2017. This improvement in operating results over the prior year was primarily due to the increase in revenues and gross profit from increased bookings and backlog, primarily from our core oil, gas and petrochemical markets.

[0000080420-18-000022:mdna:18]
[same as prior period, unchanged from 0000080420-18-000013:mdna:21]

[0000080420-18-000022:mdna:19]
New orders increased during the third quarter of Fiscal 2018 to $139.2 million, compared to $90.7 million in the third quarter of Fiscal 2017, primarily due to increased demand from our customers in our core oil, gas and petrochemical markets. The order backlog at June 30, 2018 was $316.2 million, an increase from $299.8 million at March 31, 2018.

[0000080420-18-000022:mdna:20]
Nine Months Ended June 30, 2018 Compared to the Nine Months Ended June 30, 2017 (Unaudited)

[0000080420-18-000022:mdna:21]
[same as prior period, unchanged from 0000080420-18-000013:mdna:24]

[0000080420-18-000022:mdna:22]
Revenues increased by 4%, or $12.9 million, to $313.8 million for the nine months ended June 30, 2018, compared to the nine months ended June 30, 2017, primarily due to the increase in orders in Fiscal 2018. Domestic revenues increased by 3%, or $6.6 million, to $222.9 million for the nine months ended June 30, 2018, compared to the nine months ended June 30, 2017. This was primarily due to remediation efforts following Hurricane Harvey which resulted in approximately $7 million of revenue. International revenues increased by 7%, or $6.2 million, to $90.9 million for the nine months ended June 30, 2018, compared to the nine months ended June 30, 2017. Our international revenue includes both revenue generated from our international facilities as well as export revenues from our domestic facilities. The increase in international revenues resulted from an increase in oil and gas export projects manufactured at our domestic facilities. Revenues from commercial and industrial customers increased by 18%, or $34.2 million, to $224.8 million for the nine months ended June 30, 2018, compared to the nine months ended June 30, 2017. Revenues from public and private utilities increased by 11%, or $6.4 million, to $67.4 million for the nine months ended June 30, 2018, compared to the nine months ended June 30, 2017. Revenues from municipal and transit projects decreased by 56%, or $27.7 million, to $21.6 million for the nine months ended June 30, 2018, compared to the nine months ended June 30, 2017. The increase in commercial and industrial revenues and public and private utilities revenues and the decline in municipal and transit projects were primarily due to the timing of projects.

[0000080420-18-000022:mdna:23]
Gross profit for the nine months ended June 30, 2018 increased by 4%, or $1.5 million, to $41.4 million, compared to the nine months ended June 30, 2017. Gross profit as a percentage of revenues was 13% for both the nine months ended June 30, 2018 and 2017. Gross profit is improving due to improved efficiencies in our manufacturing facilities and increased volumes due to the increased demand.

[0000080420-18-000022:mdna:24]
[same as prior period, unchanged from 0000080420-18-000013:mdna:28]

[0000080420-18-000022:mdna:25]
Selling, general and administrative expenses increased by 4%, or $2.0 million, to $48.5 million for the nine months ended June 30, 2018, compared to the nine months ended June 30, 2017, primarily due to the timing of variable performance based compensation. Selling, general and administrative expenses, as a percentage of revenues, was 15% for both the nine months ended June 30, 2018 and 2017.

[0000080420-18-000022:mdna:26]
[same as prior period, unchanged from 0000080420-18-000013:mdna:14]

[0000080420-18-000022:mdna:27]
In the nine months ended June 30, 2018, we had no restructuring or separation expenses. However, in the nine months ended June 30, 2017, we incurred $0.8 million in restructuring and separation expenses as we continued to reduce our overall cost structure to better align our costs with future production requirements.

[0000080420-18-000022:mdna:28]
[same as prior period, unchanged from 0000080420-18-000013:mdna:16]

[0000080420-18-000022:mdna:29]
We recorded an income tax benefit of $2.4 million for the nine months ended June 30, 2018 compared to an income tax benefit of $6.5 million for the nine months ended June 30, 2017. However, the effective tax rate for the nine months ended June 30, 2018 was 22% compared to an effective tax rate of 60% for the nine months ended June 30, 2017. The effective tax rate for the nine months ended June 30, 2018 decreased due to the lower U.S. corporate tax rate as well as a foreign tax loss which is reserved with a valuation allowance. Additionally we recorded deferred tax expense of $0.7 million due to the re-measurement of our U.S. deferred tax assets under the Act, which are not expected to be realized prior to the end of Fiscal 2018. The effective tax rate for the nine months ended June 30, 2017 was favorably impacted by discrete items, primarily related to the R&D Tax Credit. The effective tax rate for the nine months ended June 30, 2017 was also favorably impacted by the lower tax rate in the United Kingdom, the relative amounts of income/loss recognized in various jurisdictions, as well as the utilization of net operating loss carryforwards in Canada that are fully reserved with a valuation allowance.

[0000080420-18-000022:mdna:30]
Net Loss

[0000080420-18-000022:mdna:31]
For the nine months ended June 30, 2018, we recorded a loss of $8.7 million, or $0.76 per diluted share compared to a net loss of $4.3 million, or $0.38 per diluted share, for the nine months ended June 30, 2017. The increase in our net loss compared to the prior year was primarily due to the reduction in our income tax benefit as a result of the Act.

[0000080420-18-000022:mdna:32]
[same as prior period, unchanged from 0000080420-18-000013:mdna:36]

[0000080420-18-000022:mdna:33]
New orders increased during the nine months ended June 30, 2018 to $380.6 million, compared to $243.5 million for the nine months ended June 30, 2017, primarily due to increased demand from our customers in our core oil, gas and petrochemical markets. The order backlog at June 30, 2018 was $316.2 million, an increase from $250.1 million at September 30, 2017.

[0000080420-18-000022:mdna:34]
[same as prior period, unchanged from 0000080420-18-000013:mdna:38]

[0000080420-18-000022:mdna:35]
As of June 30, 2018, current assets exceeded current liabilities by 2.5 times and our debt to total capitalization was 0.53%.

[0000080420-18-000022:mdna:36]
Cash, cash equivalents and short-term investments decreased to $55.3 million at June 30, 2018, compared to $95.2 million at September 30, 2017 as cash has been used in operations to fund working capital requirements from our increased project volume. We had restricted cash held in a pledged collateral account related to our U.S. Revolver of $23.6 million at June 30, 2018 and $24.9 million at September 30, 2017. For further information regarding our U.S. Revolver, see Note D of Notes to Condensed Consolidated Financial Statements.

[0000080420-18-000022:mdna:37]
Our U.S. Revolver is a $75.0 million revolving credit facility in the U.S. As of June 30, 2018, there were no amounts borrowed under this facility. Total letters of credit outstanding under our U.S. Revolver, which reduce our availability, were $22.3 million at June 30, 2018 and $24.1 million at September 30, 2017. Currently, our U.S. Revolver can only be used for letters of credit until we meet certain financial ratios. As of June 30, 2018, there was $52.7 million available for the issuance of letters of credit under the U.S. Revolver. Total long-term debt, including current maturities, totaled $1.6 million at June 30, 2018, compared to $2.0 million at September 30, 2017. For further information regarding our debt, see Notes D and E of Notes to Condensed Consolidated Financial Statements.

[0000080420-18-000022:mdna:38]
Approximately $31 million of our cash and short-term investments at June 30, 2018 was held outside of the United States for international operations. It is our intention to indefinitely reinvest all current and future foreign earnings internationally in order to ensure sufficient working capital to support our international operations. In the event that we elect to repatriate some or all of the foreign earnings that were previously deemed to be indefinitely reinvested outside the U.S., under current tax laws we would incur additional tax expense upon such repatriation.

[0000080420-18-000022:mdna:39]
We believe that our strong working capital position and available cash and short-term investments should be sufficient to finance future operating activities, capital improvements and debt repayments for the foreseeable future. We continue to monitor the factors that drive our markets and will continue to strive to maintain our leadership and competitive advantage in the markets we serve while aligning our cost structures with market conditions.

[0000080420-18-000022:mdna:40]
[same as prior period, unchanged from 0000080420-18-000013:mdna:44]

[0000080420-18-000022:mdna:41]
Cash used in operating activities decreased to $26.1 million during the nine months ended June 30, 2018, compared to cash provided by operating activities of $27.1 million during the same period in Fiscal 2017. This decrease in operating cash flow for the nine months ended June 30, 2018 was primarily due to the reduction in earnings year over year and increases in accounts receivable, project billings and inventories as our increased project volume requires cash to fund the growth. Cash flow from operations is primarily influenced by project volume, the timing of milestone payments from our customers and the payment terms with our suppliers.

[0000080420-18-000022:mdna:42]
[same as prior period, unchanged from 0000080420-18-000013:mdna:46]

[0000080420-18-000022:mdna:43]
Net cash provided by investing activities during the nine months ended June 30, 2018 totaled $8.1 million compared to cash used in investing activities of $83.2 million during the same period in Fiscal 2017. This increase in Fiscal 2018 was primarily due to maturities of short-term investments. For the nine months ended June 30, 2018, our net short-term investment surplus was $10.7 million and we spent approximately $4.0 million on purchases of plant improvements and equipment. For the nine months ended June 30, 2017, we had net short-term investment purchases of $55.4 million as well as the establishment of restricted cash of $25.3 million.

[0000080420-18-000022:mdna:44]
[same as prior period, unchanged from 0000080420-18-000013:mdna:48]

[0000080420-18-000022:mdna:45]
Net cash used in financing activities was $9.9 million and $9.7 million during the nine months ended June 30, 2018 and 2017, respectively. These amounts primarily consisted of cash dividends of approximately $8.9 million in each period.

[0000080420-18-000022:mdna:46]
[same as prior period, unchanged from 0000080420-18-000013:mdna:50]

[0000080420-18-000022:mdna:47]
[same as prior period, unchanged from 0000080420-18-000013:mdna:51]

[0000080420-18-000022:mdna:48]
[same as prior period, unchanged from 0000080420-18-000013:mdna:52]

[0000080420-18-000022:mdna:49]
[same as prior period, unchanged from 0000080420-18-000013:mdna:53]

[0000080420-18-000022:mdna:50]
[same as prior period, unchanged from 0000080420-18-000013:mdna:54]

[0000080420-18-000022:mdna:51]
For the nine months ended June 30, 2018, our operating loss was positively impacted by $2.9 million due to changes in contract estimates related to projects in progress at the beginning of the period. These changes in estimates resulted primarily from, among other things, successful execution and close-out improvements, as well as other changes in facts and circumstances during the period.

[0000080420-18-000022:mdna:52]
[same as prior period, unchanged from 0000080420-18-000013:mdna:56]

[0000080420-18-000022:mdna:53]
[same as prior period, unchanged from 0000080420-18-000013:mdna:57]

[0000080420-18-000022:mdna:54]
A significant portion of our revenues have historically been from the oil, gas and petrochemical markets. Oil and gas commodity price levels have stabilized and our customers are beginning to invest in maintenance and small projects; however, customers

[0000080420-18-000022:mdna:55]
continue to delay their major capital investments. The reduction in available projects has increased price pressures over the past two years and has impacted, and may continue to negatively impact, our backlog, revenues and operating results.

[0000080420-18-000022:mdna:56]
Our operating results have been impacted by factors such as the timing of new order awards, customer approval of final engineering and design specifications and delays in customer construction schedules, all of which have had a negative impact on the timing of project execution. Our operating results also have been, and could continue to be, impacted by the timing and resolution of change orders, project close-out and resolution of potential contract claims and liquidated damages, all of which could improve or deteriorate gross margins during the period in which these items are resolved with our customers. These factors may result in periods of underutilization of our resources and facilities and negatively impact our ability to cover our fixed costs. We continue to assess our cost structure, operating performance and service offerings as the oil, gas and petrochemical markets remain challenging and uncertain. During the first nine months of Fiscal 2018, we have experienced an increase in bookings and are beginning to see an improvement in revenues and operating results that we anticipate will continue for the remainder of Fiscal 2018 and into Fiscal 2019. We continue to focus on maintaining our cash position, improving efficiencies in production and investing in future business opportunities.

[0000080420-18-000022:mdna:57]
Our increase in project volume has required cash to fund operations, but we believe that our strong working capital position and available cash and short-term investments should be sufficient to finance future operating activities, research and development initiatives, capital improvements and debt repayments for the foreseeable future. We continue to monitor the factors that drive our markets and will continue to strive to maintain our leadership and competitive advantage in the markets we serve while aligning our cost structures with market conditions.
