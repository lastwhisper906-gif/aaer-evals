# POWL MD&A — 0001564590-14-001858


## mdna

[0001564590-14-001858:mdna:1]
[same as prior period, unchanged from 0001564590-14-000140:mdna:1]

[0001564590-14-001858:mdna:2]
[same as prior period, unchanged from 0001564590-14-000140:mdna:2]

[0001564590-14-001858:mdna:3]
[same as prior period, unchanged from 0001564590-14-000140:mdna:3]

[0001564590-14-001858:mdna:4]
[same as prior period, unchanged from 0001564590-14-000140:mdna:4]

[0001564590-14-001858:mdna:5]
[same as prior period, unchanged from 0001564590-14-000140:mdna:5]

[0001564590-14-001858:mdna:6]
We entered fiscal year 2014 with a backlog of unfilled orders of $437.9 million at September 30, 2013, an increase of $72.0 million compared to our backlog of orders at September 30, 2012.  Our backlog includes various projects, some of which are for complex petrochemical and oil and gas construction projects which take a number of months to produce.

[0001564590-14-001858:mdna:7]
The strength in the Canadian oil sands region continues to be a major contributor to our increase in our backlog.  We have completed the construction of our new facility and relocation from our previous facility.  The ramp up and project execution at our Canadian operation continues to present risks and challenges as we position our operations to respond to the strength in the Canadian markets.

[0001564590-14-001858:mdna:8]
On January 15, 2014, we sold our wholly-owned subsidiary Transdyn to a global provider of electronic toll collection systems, headquartered in Vienna, Austria.  The purchase price from the sale of this subsidiary totaled $16.0 million, of which we received cash of $14.4 million. The remaining $1.6 million was placed into an escrow account until April 2015, to be released subject to certain contingent obligations, and was recorded to other assets.  We received additional cash of $0.4 million after the final working capital adjustment was calculated in March 2014. We recorded a gain on this transaction of $8.6 million, net of tax, which has been included in income from discontinued operations for the quarter and six months ended March 31, 2014 in the accompanying consolidated statements of operations. We reclassified the assets and liabilities of Transdyn as held for sale within the accompanying condensed consolidated balance sheets as of September 30, 2013 and presented the results of these operations as income from discontinued operations, net of tax, for each of the accompanying condensed consolidated statements of operations.  Accordingly, we have removed Transdyn from the Results of Operations discussions below.

[0001564590-14-001858:mdna:9]
[same as prior period, unchanged from 0001564590-14-000140:mdna:9]

[0001564590-14-001858:mdna:10]
Quarter Ended March 31, 2014 Compared to the Quarter Ended March 31, 2013 (Unaudited)

[0001564590-14-001858:mdna:11]
[same as prior period, unchanged from 0001564590-14-000140:mdna:10]

[0001564590-14-001858:mdna:12]
Revenues increased 11.1%, or $16.3 million, to $162.3 million in the second quarter of fiscal year 2014, compared to the second quarter of fiscal year 2013, primarily due to the expansion and ramp-up of our Canadian operations and the timing of projects in process.  Domestic revenues increased by 2.9%, or $2.6 million, to $91.9 million in the second quarter of fiscal year 2014, compared to the second quarter of fiscal year 2013, and international revenues increased by 24.0%, or $13.7 million, to $70.4 million in the second quarter of fiscal year 2014, compared to the second quarter of fiscal year 2013.  The increase in international revenues was primarily driven by the expansions of our Canadian operations and the timing of oil and gas construction projects.  Revenues from commercial and industrial customers increased $14.7 million to $114.6 million in the second quarter of fiscal year 2014, compared to the second quarter of fiscal year 2013. Revenues from public and private utilities increased $1.1 million to $35.4 million in the second quarter of fiscal year 2014, compared to the second quarter of fiscal year 2013. Revenues from municipal and transit projects increased $0.5 million to $12.3 million in the second quarter of fiscal year 2014, compared to the second quarter of fiscal year 2013.

[0001564590-14-001858:mdna:13]
Gross profit for the second quarter of fiscal year 2014 increased 18.2%, or $5.4 million, to $34.9 million, compared to the second quarter of fiscal year 2013.  Gross profit as a percentage of revenues increased to 21.5% in the second quarter of fiscal year 2014, compared to 20.2% in the second quarter of fiscal year 2013. This increase in gross profit as a percentage of revenue was primarily driven by the margins associated with the mix of projects in process and the increase in project activity to cover fixed and overhead operating costs, partially offset by the ramp up of our Canadian operations.

[0001564590-14-001858:mdna:14]
[same as prior period, unchanged from 0001564590-14-000140:mdna:14]

[0001564590-14-001858:mdna:15]
Selling, general and administrative expenses, as a percentage of revenues, decreased to 13.6% during the second quarter of fiscal year 2014, compared to 14.4% during the second quarter of fiscal year 2013, due to the increase in revenues.  Selling, general and administrative expenses increased by $1.1 million to $22.1 million during the second quarter of fiscal year 2014, compared to the second quarter of fiscal year 2013, primarily due to increased personnel costs and administrative expenses associated with increased volume as well as the ramp-up at our Canadian operations. This increase in selling, general and administrative expenses was offset by a decrease in depreciation expense as our enterprise resource planning, engineering and manufacturing process systems (Business Systems) became fully depreciated in December 2012.  Additionally, selling, general and administrative expense was favorably impacted by the capitalization of certain personnel costs associated with the development and implementation of our new Business Systems.  However, the favorable impact of depreciation expense and capitalization of certain personnel costs will no longer be realized once the Business Systems are implemented later this fiscal year.

[0001564590-14-001858:mdna:16]
Other Income

[0001564590-14-001858:mdna:17]
We recorded other income of $0.5 million in the second quarter of fiscal year 2014 which was the amortization of the deferred gain from the amended supply agreement, compared to other income of $1.7 million in the second quarter of fiscal year 2013 which resulted from the settlement of a lawsuit filed against the previous owners of Powell Canada.

[0001564590-14-001858:mdna:18]
[same as prior period, unchanged from 0001564590-14-000140:mdna:16]

[0001564590-14-001858:mdna:19]
Our provision for income taxes for continuing operations was $4.1 million in the second quarter of fiscal year 2014, compared to $1.8 million in the second quarter of fiscal year 2013.  The effective tax rate for the second quarter of fiscal year 2014 was 36.8% which approximates the combined U.S. federal and state statutory rate as the majority of our income is attributable to the U.S. The effective tax rate for the second quarter of fiscal year 2013 was 22.1% and was favorably impacted by the utilization of loss carryforwards on Canadian income.

[0001564590-14-001858:mdna:20]
Income from Continuing Operations

[0001564590-14-001858:mdna:21]
In the second quarter of fiscal year 2014, we recorded income from continuing operations of $7.0 million, or $0.58 per diluted share, compared to $6.2 million, or $0.52 per diluted share, in the second quarter of fiscal year 2013.  We continue to have strong performance from oil and gas related projects which offset the inefficiencies associated with the expansion and ramp-up of our Canadian operations.

[0001564590-14-001858:mdna:22]
Income from Discontinued Operations

[0001564590-14-001858:mdna:23]
In January 2014, we sold Transdyn to a global provider of electronic toll collection systems, headquartered in Vienna, Austria.  We have reclassified the assets and liabilities of Transdyn as held for sale within the accompanying condensed consolidated balance sheets as of March 31, 2014 and September 30, 2013 and presented the results of these operations as income from discontinued operations, net of tax, for each of the accompanying statements of operations.  In the second quarter of fiscal year 2014, we recorded $8.6 million, or $0.71 per diluted share, of income from discontinued operations compared to the $0.6 million, or $0.05 per diluted share, recorded in the second quarter of fiscal year 2013 as the current quarter includes the gain on the sale. For additional information about this disposition, see Note I in the Notes to Condensed Consolidated Financial Statements.

[0001564590-14-001858:mdna:24]
[same as prior period, unchanged from 0001564590-14-000140:mdna:22]

[0001564590-14-001858:mdna:25]
The order backlog at March 31, 2014 was $452.2 million, compared to $455.1 million at December 31, 2013.  New orders placed during the second quarter of fiscal year 2014 totaled $162.6 million compared to $118.2 million in the second quarter of fiscal year 2013.  Orders have increased primarily due to continued strength in oil and gas production and refining projects.

[0001564590-14-001858:mdna:26]
Six Months Ended March 31, 2014 Compared to the Six Months Ended March 31, 2013 (Unaudited)

[0001564590-14-001858:mdna:27]
Revenue and Gross Profit

[0001564590-14-001858:mdna:28]
Revenues increased 14.1%, or $41.3 million, to $334.2 million for the six months ended March 31, 2014, compared to the six months ended March 31, 2013, primarily due to the expansion and ramp-up of our Canadian operations and the timing of projects in process.  Domestic revenues increased by 2.8%, or $5.0 million, to $180.9 million for the six months ended March 31, 2014, compared to the six months ended March 31, 2013, and international revenues increased by 31.0%, or $36.3 million, to $153.2 million for the six months ended March 31, 2014, compared to the six months ended March 31, 2013.  The increase in international revenues was primarily driven by the expansions of our Canadian operations and the timing of oil and gas construction projects.  Revenues from commercial and industrial customers increased $32.7 million to $239.1 million for the six months ended March 31, 2014, compared to the six months ended March 31, 2013. Revenues from public and private utilities increased $4.3 million to $70.1 million for the six months ended March 31, 2014, compared to the six months ended March 31, 2013. Revenues from municipal and transit projects increased $4.3 million to $25.0 million for the six months ended March 31, 2014, compared to the six months ended March 31, 2013.

[0001564590-14-001858:mdna:29]
Gross profit for the six months ended March 31, 2014 increased 13.1%, or $8.1 million, to $70.1 million, compared to the six months ended March 31, 2013.  Gross profit as a percentage of revenues was 21.0% for the six months ended March 31, 2014, compared to 21.1% for the six months ended March 31, 2013.  Our gross profit as a percentage of revenues was down slightly in the first half of fiscal year 2014, compared to fiscal year 2013, due to the costs associated with the ramp up of our Canadian operations and the overall mix of project types.

[0001564590-14-001858:mdna:30]
Selling, General and Administrative Expenses

[0001564590-14-001858:mdna:31]
Selling, general and administrative expenses, as a percentage of revenues, decreased to 13.1% during the six months ended March 31, 2014, compared to 13.9% during the six months ended March 31, 2013, due to the increase in revenues. Selling, general and administrative expenses increased by $3.0 million to $43.7 million during six months ended March 31, 2014, compared to the six months ended March 31, 2013, primarily due to increased personnel costs, incentive compensation and administrative expenses associated with increased volume as well as the ramp-up at our Canadian operations. This increase in selling, general and administrative expenses was offset by a decrease in depreciation expense as our enterprise resource planning, engineering and manufacturing process systems (Business Systems) became fully depreciated in December 2012.  Additionally, selling, general and administrative expense was favorably impacted by the capitalization of certain personnel costs associated with the development and implementation of our new Business Systems.  However, the favorable impact of depreciation expense and capitalization of certain personnel costs will no longer be realized once the Business Systems are implemented later this fiscal year.

[0001564590-14-001858:mdna:32]
Other Income

[0001564590-14-001858:mdna:33]
We recorded other income of $0.5 million in the six months ended March 31, 2014 which was the amortization of the deferred gain from the amended supply agreement, compared to other income of $1.7 million in the same period in fiscal year 2013 which resulted from the settlement of a lawsuit filed against the previous owners of Powell Canada.

[0001564590-14-001858:mdna:34]
Income Tax Provision

[0001564590-14-001858:mdna:35]
Our provision for income taxes for continuing operations was $8.0 million for the six months ended March 31, 2014, compared to $5.2 million for the six months ended March 31, 2013.  The effective tax rate for six months ended March 31, 2014 was 35.9% which approximates the combined U.S. federal and state statutory rate as the majority of our income is attributable to the U.S.  The effective tax rate for the six months ended March 31, 2013 was 28.0% and was favorably impacted by the utilization of loss carryforwards on Canadian income and the domestic production activities deduction in the United States.

[0001564590-14-001858:mdna:36]
Income from Continuing Operations

[0001564590-14-001858:mdna:37]
For the six months ended March 31, 2014, we recorded income from continuing operations of $14.2 million, or $1.18 per diluted share, compared to $13.3 million, or $1.11 per diluted share, for the six months ended March 31, 2013.  We continue to have strong performance from oil and gas related projects which offset the inefficiencies associated with the expansion and ramp-up of our Canadian operations.

[0001564590-14-001858:mdna:38]
Income from Discontinued Operations

[0001564590-14-001858:mdna:39]
For the six months ended March 31, 2014, we recorded $9.6 million, or $0.80 per diluted share, of income from discontinued operations compared to the $0.9 million, or $0.07 per diluted share, recorded for the six months ended March 31, 2013 as the current fiscal year includes the gain on the sale. For additional information about this disposition, see Note I in the Notes to Condensed Consolidated Financial Statements.

[0001564590-14-001858:mdna:40]
Backlog

[0001564590-14-001858:mdna:41]
The order backlog at March 31, 2014 was $452.2 million, compared to $437.9 million at September 30, 2013.  New orders placed during the six months ended March 31, 2014 totaled $354.8 million compared to $369.1 million for the six months ended March 31, 2013.  The year over year decrease in new orders was primarily due to the timing of certain complex oil and gas production and petrochemical projects.

[0001564590-14-001858:mdna:42]
[same as prior period, unchanged from 0001564590-14-000140:mdna:24]

[0001564590-14-001858:mdna:43]
Cash and cash equivalents decreased to $101.4 million at March 31, 2014, compared to $107.4 million at September 30, 2013.  As of March 31, 2014, current assets exceeded current liabilities by 2.6 times and our debt to total capitalization was 0.85%.

[0001564590-14-001858:mdna:44]
We have a $75.0 million revolving credit facility in the U.S. which expires in December 2018. As of March 31, 2014, there were no amounts borrowed under this line of credit. We also have a $9.0 million revolving credit facility in Canada. At March 31, 2014, there was no balance outstanding under the Canadian revolving credit facility. Total long-term debt and capital lease obligations, including current maturities, totaled $3.2 million at March 31, 2014, compared to $3.6 million at September 30, 2013. Total letters of credit outstanding were $22.0 million at March 31, 2014 compared to $20.1 million at September 30, 2013, which reduced our availability under our U.S. credit facility and our Canadian revolving credit facility. Amounts available at March 31, 2014 under the U.S. and Canadian revolving credit facilities were $53.1 million and $8.9 million, respectively.  For further information regarding our debt, see Notes E and F of Notes to Condensed Consolidated Financial Statements.

[0001564590-14-001858:mdna:45]
Approximately $9.0 million of our cash at March 31, 2014, was held outside of the United States for international operations.  It is our intention to indefinitely reinvest all current and future foreign earnings internationally in order to ensure sufficient working capital and support and expand these international operations.  In the event that we elect to repatriate some or all of the foreign earnings that were previously deemed to be indefinitely reinvested outside the U.S., under current tax laws we would incur additional tax expense upon such repatriation.

[0001564590-14-001858:mdna:46]
[same as prior period, unchanged from 0001564590-14-000140:mdna:28]

[0001564590-14-001858:mdna:47]
[same as prior period, unchanged from 0001564590-14-000140:mdna:29]

[0001564590-14-001858:mdna:48]
Cash used in operating activities was $6.8 million during the first six months of fiscal year 2014, compared to cash provided by operating activities of $57.2 million during the first six months of fiscal year 2013. Cash flow from operations is primarily influenced by demand for our products and services and is impacted as our progress payment terms with our customers are matched with the payment terms with our suppliers.  The change in the first six months of fiscal year 2014, compared to the same period in the prior

[0001564590-14-001858:mdna:49]
year, was primarily due to the billing and collection of contracts receivable based on the progress billing milestones, as well as an unfavorable change in receivables, offset by the $10.0 million received from the amended supply agreement. For further information regarding the amended supply agreement, see Note D in the Notes to Condensed Consolidated Financial Statements.

[0001564590-14-001858:mdna:50]
[same as prior period, unchanged from 0001564590-14-000140:mdna:31]

[0001564590-14-001858:mdna:51]
Cash provided by investing activities during the first six months of fiscal year 2014 was $6.4 million compared to cash used in investing activities for the same period in fiscal year 2013 of $32.6 million.  Purchases of property, plant and equipment during the first six months of fiscal year 2014 totaled $8.5 million compared to $33.3 million during the first six months of fiscal year 2013.  This decrease results from the completion of the construction of our new facilities in fiscal year 2013.  Additionally, cash provided by investing activities in fiscal year 2014 includes the proceeds from the sale of Transdyn of $14.8 million.

[0001564590-14-001858:mdna:52]
[same as prior period, unchanged from 0001564590-14-000140:mdna:33]

[0001564590-14-001858:mdna:53]
Net cash used in financing activities was $6.9 million during the first six months of fiscal year 2014 and $0.7 million during the same period of fiscal year 2013.  This increase in the use of cash in the first six months of fiscal year 2014 was primarily driven by the payment of $6.0 million in cash dividends.

[0001564590-14-001858:mdna:54]
[same as prior period, unchanged from 0001564590-14-000140:mdna:35]

[0001564590-14-001858:mdna:55]
See Note A in the Notes to Condensed Consolidated Financial Statements included in this report for information on new accounting standards.

[0001564590-14-001858:mdna:56]
[same as prior period, unchanged from 0001564590-14-000140:mdna:37]

[0001564590-14-001858:mdna:57]
[same as prior period, unchanged from 0001564590-14-000140:mdna:38]

[0001564590-14-001858:mdna:58]
[same as prior period, unchanged from 0001564590-14-000140:mdna:39]

[0001564590-14-001858:mdna:59]
[same as prior period, unchanged from 0001564590-14-000140:mdna:40]

[0001564590-14-001858:mdna:60]
[same as prior period, unchanged from 0001564590-14-000140:mdna:41]

[0001564590-14-001858:mdna:61]
Growth in demand for energy is expected to continue over the long term. This, when coupled with the need for replacement of existing infrastructure that is nearing the end of its life cycle, demonstrates a continued need for products and services produced by us. Our orders over the past year have been solid, driven primarily by continued strength in oil and gas production projects and refining projects, along with demand associated with Canadian oil sands related projects. We continue to experience timing challenges in the near-term related to the awarding of large projects due to various global market conditions and industry constraints. However, the outlook for continued opportunities for our products and services remains positive; even though the timing and pricing of many of these projects are difficult to predict.

[0001564590-14-001858:mdna:62]
[same as prior period, unchanged from 0001564590-14-000140:mdna:43]

[0001564590-14-001858:mdna:63]
The strength in the Canadian oil sands region continues to be a major contributor to our increase in our backlog.  We have completed the construction of our new facility and relocation from our previous facility which was leased.  The ramp up and project execution at our Canadian operation continues to present risks and challenges as we position our operations to respond to the strength in the Canadian markets.

[0001564590-14-001858:mdna:64]
[same as prior period, unchanged from 0001564590-14-000140:mdna:45]
