# POWL note change history — 0001564590-14-000140 → 0001564590-14-001858


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2014-05-07):
[0001564590-14-001858:note_history:1]
Certain customers require us to post bank letter of credit guarantees or performance bonds issued by a surety. These guarantees and performance bonds assure that we will perform under the terms of our contract. In the event of default, the counterparty may demand payment from the bank under a letter of credit or performance by the surety under a performance bond. To date, there have been no significant expenses related to either letters of credit or performance bonds for the periods reported. We were contingently liable for secured and unsecured letters of credit of $22.1 million as of March 31, 2014. We also had performance and maintenance bonds totaling $306.7 million that were outstanding, with additional bonding capacity of $293.3 million available, at March 31, 2014.
  (was, 2014-02-05, similarity 0.9829):
[0001564590-14-000140:note_history:1]
Certain customers require us to post bank letter of credit guarantees or performance bonds issued by a surety. These guarantees and performance bonds assure that we will perform under the terms of our contract. In the event of default, the counterparty may demand payment from the bank under a letter of credit or performance by the surety under a performance bond. To date, there have been no significant expenses related to either letters of credit or performance bonds for the periods reported. We were contingently liable for secured and unsecured letters of credit of $19.2 million as of December 31, 2013. We also had performance and maintenance bonds totaling $333.3 million that were outstanding, with additional bonding capacity of $66.7 million available, at December 31, 2013.

- changed (2014-05-07):
[0001564590-14-001858:note_history:2]
We have an $8.3 million facility agreement (Facility Agreement) between S&I and a large international bank. This Facility Agreement provides S&I the ability to enter into various guarantees, such as forward exchange contracts, currency options and performance bonds. At March 31, 2014, we had outstanding guarantees totaling $3.9 million under this Facility Agreement.  Amounts available under this Facility Agreement were $4.4 million as of March 31, 2014.
  (was, 2014-02-05, similarity 0.8836):
[0001564590-14-000140:note_history:2]
We have an $8.2 million facility agreement (Facility Agreement) between S&I and a large international bank. This Facility Agreement provides S&I the ability to enter into various guarantees, such as forward exchange contracts, currency options and performance bonds. At December 31, 2013, we had outstanding guarantees totaling $4.6 million under this Facility Agreement.

- changed (2014-05-07):
[0001564590-14-001858:note_history:3]
The Facility Agreement provides for financial covenants and customary events of default, and carries cross-default provisions with our Amended Credit Facility. If an event of default (as defined in the Facility Agreement) occurs and is continuing, per the terms and subject to the conditions set forth in the Facility Agreement, obligations outstanding under the Facility Agreement may be accelerated and may become or be declared immediately due and payable. As of March 31, 2014, we were in compliance with all of the financial covenants of the Facility Agreement.  The Facility Agreement expires in July 2014.
  (was, 2014-02-05, similarity 0.9892):
[0001564590-14-000140:note_history:3]
The Facility Agreement provides for financial covenants and customary events of default, and carries cross-default provisions with our Amended Credit Facility. If an event of default (as defined in the Facility Agreement) occurs and is continuing, per the terms and subject to the conditions set forth in the Facility Agreement, obligations outstanding under the Facility Agreement may be accelerated and may become or be declared immediately due and payable. As of December 31, 2013, we were in compliance with all of the financial covenants of the Facility Agreement.  The Facility Agreement expires in July 2014.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureAndSignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2014-05-07):
[0001564590-14-001858:note_history:4]
Powell Industries, Inc. (we, us, our, Powell or the Company) was incorporated in the state of Delaware in 2004 as a successor to a Nevada company incorporated in 1968. The Nevada corporation was the successor to a company founded by William E. Powell in 1947, which merged into the Company in 1977. Our major subsidiaries, all of which are wholly-owned, include: Powell Electrical Systems, Inc.; Powell Industries International, B.V.; Powell (UK) Limited (formerly Switchgear & Instrumentation Limited) and Powell Canada Inc.
  (was, 2014-02-05, similarity 0.8523):
[0001564590-14-000140:note_history:4]
Powell Industries, Inc. (we, us, our, Powell or the Company) was incorporated in the state of Delaware in 2004 as a successor to a Nevada company incorporated in 1968. The Nevada corporation was the successor to a company founded by William E. Powell in 1947, which merged into the Company in 1977. Our major subsidiaries, all of which are wholly-owned, include: Powell Electrical Systems, Inc.; Powell Industries International, B.V.; Switchgear & Instrumentation Limited (S&I) and Powell Canada Inc.

- changed (2014-05-07):
[0001564590-14-001858:note_history:5]
These unaudited condensed consolidated financial statements have been prepared in accordance with the instructions to Form 10-Q and Rule 10-01 of Regulation S-X for interim financial information.  Certain information and footnote disclosures, normally included in annual financial statements prepared in accordance with accounting principles generally accepted in the United States (U.S. GAAP), have been condensed or omitted pursuant to those rules and regulations. In the opinion of management, all adjustments, consisting only of normal recurring adjustments, necessary to fairly state the financial position, results of operations and cash flows with respect to the interim consolidated financial statements have been included. The results of operations for the interim periods are not necessarily indicative of the results for the entire fiscal year.  We believe that these financial statements contain all adjustments necessary so that they are not misleading. The year-end balance sheet data was derived from audited financial statements, but does not include all disclosures required by U.S. GAAP.
  (was, 2014-02-05, similarity 0.917):
[0001564590-14-000140:note_history:5]
These unaudited condensed consolidated financial statements have been prepared pursuant to the rules of the Securities and Exchange Commission (SEC). Certain information and footnote disclosures, normally included in annual financial statements prepared in accordance with accounting principles generally accepted in the United States (U.S. GAAP), have been condensed or omitted pursuant to those rules and regulations. In the opinion of management, all adjustments, consisting only of normal recurring adjustments, necessary to fairly state the financial position, results of operations and cash flows with respect to the interim consolidated financial statements have been included. The results of operations for the interim periods are not necessarily indicative of the results for the entire fiscal year.  We believe that these financial statements contain all adjustments necessary so that they are not misleading. The year-end balance sheet data was derived from audited financial statements, but does not include all disclosures required by U.S. GAAP.

- added (2014-05-07):
[0001564590-14-001858:note_history:6]
As discussed in Note I, on January 15, 2014, we sold our wholly-owned subsidiary Transdyn Inc. (Transdyn).  We reclassified the assets and liabilities of Transdyn as held for sale within the accompanying condensed consolidated balance sheet as of September 30, 2013 and presented the results of these operations as income from discontinued operations, net of tax, for each of the accompanying condensed consolidated statements of operations. While this sale did not result in a material disposition of assets or material reduction to income before income taxes relative to Powell’s consolidated financial statements, the revenues, gross profit, income before income taxes and assets of Transdyn comprised a significant majority of those respective amounts previously reported in our Process Control Systems business segment. As we previously only reported two business segments, Electrical Power Products and Process Control Systems, we have removed the presentation of segments in our Notes to Condensed Consolidated Financial Statements.

- changed (2014-05-07):
[0001564590-14-001858:note_history:7]
These unaudited condensed consolidated financial statements should be read in conjunction with the audited consolidated financial statements and notes thereto of Powell and its subsidiaries included in Powell’s Annual Report on Form 10-K for the year ended September 30, 2013, which was filed with the Securities and Exchange Commission (SEC) on December 4, 2013.
  (was, 2014-02-05, similarity 0.9444):
[0001564590-14-000140:note_history:7]
These unaudited condensed consolidated financial statements should be read in conjunction with the audited consolidated financial statements and notes thereto of Powell and its subsidiaries included in Powell’s Annual Report on Form 10-K for the year ended September 30, 2013, which was filed with the SEC on December 4, 2013.

- added (2014-05-07):
[0001564590-14-001858:note_history:8]
In April 2014, the FASB issued an amendment to the financial reporting of discontinued operations.  The amendments in this update change the criteria for reporting discontinued operations while enhancing disclosures in this area. It also addresses sources of confusion and inconsistent application related to financial reporting of discontinued operations guidance in U.S. GAAP.  Under the new guidance, only disposals representing a strategic shift in operations that have a major effect on the organization’s operations and financial results should be presented as discontinued operations. Examples include a disposal of a major geographic area, a major line of business, or a major equity method investment.  In addition, the new guidance requires expanded disclosures about discontinued operations that will provide financial statement users with more information about the assets, liabilities, income, and expenses of discontinued operations.  The new guidance also requires disclosure of the pre-tax income attributable to a disposal of a significant part of an organization that does not qualify for discontinued operations reporting. This disclosure will provide users with information about the ongoing trends in a reporting organization’s results from continuing operations. The amendments in this update are effective in the first quarter of 2015, which would be our fiscal year end September 30, 2016.  Early adoption is permitted for disposals that have not been previously reported as discontinued operations.

- removed (2014-05-07):
[0001564590-14-000140:note_history:9]
In August 2012, the Securities and Exchange Commission (SEC) adopted a rule mandated by the Wall Street Reform and Consumer Protection Act to require companies to publicly disclose their use of conflict minerals that originate in the Democratic Republic of the Congo or an adjoining country. The final rule applies to a company that uses minerals including tantalum, tin, gold or tungsten. The final rule requires companies to provide disclosure on a new form filed with the SEC, with the first specialized disclosure report due on May 31, 2014, for the 2013 calendar year, and annually on May 31 each year thereafter. We are implementing the processes and procedures to comply with this rule.

- removed (2014-05-07):
[0001564590-14-000140:note_history:10]
Subsequent events

- removed (2014-05-07):
[0001564590-14-000140:note_history:11]
On January 15, 2014, we sold our wholly-owned subsidiary Transdyn, Inc. (Transdyn) to a global provider of electronic toll collection systems, headquartered in Vienna, Austria.  See Note I for additional information about this transaction.

- removed (2014-05-07):
[0001564590-14-000140:note_history:12]
On February 3, 2014, our Board declared a quarterly cash dividend of $0.25 per share payable to shareholders of record on February 19, 2014.  This dividend will be approximately $3.0 million and paid on March 19, 2014.

- removed (2014-05-07):
[0001564590-14-000140:note_history:13]
Business Segments

- removed (2014-05-07):
[0001564590-14-000140:note_history:14]
Due to the sale of Transdyn discussed above, we have reclassified the assets and liabilities of Transdyn as held for sale within the accompanying condensed consolidated balance sheets as of December 31, 2013 and September 30, 2013 and presented the results of these operations as income from discontinued operations, net of tax, for each of the accompanying statements of operations.

- removed (2014-05-07):
[0001564590-14-000140:note_history:15]
While this sale did not result in a material disposition of assets or material reduction to income before income taxes relative to Powell’s consolidated financial statements, the revenues, gross profit, income before taxes and assets of Transdyn comprised a significant majority of those respective amounts previously reported in our Process Control Systems business segment. As we previously only reported two business segments, Electrical Power Products and Process Control Systems, we have removed the presentation of segments in our Notes to Condensed Consolidated Financial Statements.


## us-gaap:LongTermDebtTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2014-05-07):
[0001564590-14-001858:note_history:16]
|  | March 31, |  |  | September 30, |  |
|  | 2014 |  |  | 2013 |  |
| Industrial development revenue bonds | $ | 3,200 |  |  | $ | 3,600 |  |
| Capital lease obligations |  | — |  |  |  | 16 |  |
| Subtotal long-term debt and capital lease obligations |  | 3,200 |  |  |  | 3,616 |  |
| Less current portion |  | (400 | ) |  |  | (416 | ) |
| Total long-term debt and capital lease obligations | $ | 2,800 |  |  | $ | 3,200 |  |
  (was, 2014-02-05, similarity 0.8982):
[0001564590-14-000140:note_history:16]
|  | December 31, 2013 |  |  | September 30, 2013 |  |
| Industrial development revenue bonds | $ | 3,200 |  |  | $ | 3,600 |  |
| Capital lease obligations |  | − |  |  |  | 16 |  |
| Subtotal long-term debt and capital lease obligations |  | 3,200 |  |  |  | 3,616 |  |
| Less current portion |  | (400 | ) |  |  | (416 | ) |
| Total long-term debt and capital lease obligations | $ | 2,800 |  |  | $ | 3,200 |  |

- added (2014-05-07):
[0001564590-14-001858:note_history:17]
In fiscal year 2014, we amended and restated our existing credit agreement (Amended Credit Agreement) with a major domestic bank. We entered into this Amended Credit Agreement to, among other things, allow for the payment of dividends and to extend the expiration date of the facility. The Amended Credit Agreement provides for a $75.0 million revolving credit facility (U.S. Revolver). Obligations are collateralized by the stock of certain of our subsidiaries.

- changed (2014-05-07):
[0001564590-14-001858:note_history:18]
The U.S. Revolver provides for the issuance of letters of credit which reduce the amounts that may be borrowed under this revolver. The amount available under the U.S. Revolver was reduced by $21.9 million for our outstanding letters of credit at March 31, 2014.
  (was, 2014-02-05, similarity 0.9745):
[0001564590-14-000140:note_history:18]
The U.S. Revolver provides for the issuance of letters of credit which reduce the amounts that may be borrowed under this revolver. The amount available under the U.S. Revolver was reduced by $19.1 million for our outstanding letters of credit at December 31, 2013.

- changed (2014-05-07):
[0001564590-14-001858:note_history:19]
There were no borrowings outstanding under the U.S. Revolver as of March 31, 2014. Amounts available under the U.S. Revolver were $53.1 million at March 31, 2014. The U.S. Revolver expires on December 31, 2018.
  (was, 2014-02-05, similarity 0.9531):
[0001564590-14-000140:note_history:19]
There were no borrowings outstanding under the U.S. Revolver as of December 31, 2013. Amounts available under the U.S. Revolver were $52.9 million at December 31, 2013. The U.S. Revolver expires on December 31, 2018.

- changed (2014-05-07):
[0001564590-14-001858:note_history:20]
The Amended Credit Agreement is collateralized by a pledge of 100% of the voting capital stock of each of our domestic subsidiaries and 66% of the voting capital stock of each non-domestic subsidiary, excluding Powell Canada. The Amended Credit Agreement provides for customary events of default and carries cross-default provisions with other existing debt agreements. If an event of default (as defined in the Amended Credit Agreement) occurs and is continuing, on the terms and subject to the conditions set forth in the Amended Credit Agreement, amounts outstanding under the Amended Credit Agreement may be accelerated and may become immediately due and payable. As of March 31, 2014, we were in compliance with all of the financial covenants of the Amended Credit Agreement.
  (was, 2014-02-05, similarity 0.9916):
[0001564590-14-000140:note_history:20]
The Amended Credit Agreement is collateralized by a pledge of 100% of the voting capital stock of each of our domestic subsidiaries and 66% of the voting capital stock of each non-domestic subsidiary, excluding Powell Canada. The Amended Credit Agreement provides for customary events of default and carries cross-default provisions with other existing debt agreements. If an event of default (as defined in the Amended Credit Agreement) occurs and is continuing, on the terms and subject to the conditions set forth in the Amended Credit Agreement, amounts outstanding under the Amended Credit Agreement may be accelerated and may become immediately due and payable. As of December 31, 2013, we were in compliance with all of the financial covenants of the Amended Credit Agreement.

- changed (2014-05-07):
[0001564590-14-001858:note_history:21]
We have a $9.0 million credit agreement with a major international bank in Canada (the Canadian Revolver) to provide working capital support and letters of credit for our operations in Canada. The Canadian Revolver provides for the issuance of letters of credit which reduce the amounts that may be borrowed under this revolver. The amount available under the Canadian Revolver was reduced by $0.1 million for an outstanding letter of credit at March 31, 2014.
  (was, 2014-02-05, similarity 0.9856):
[0001564590-14-000140:note_history:21]
We have a $9.4 million credit agreement with a major international bank in Canada (the Canadian Revolver) to provide working capital support and letters of credit for our operations in Canada. The Canadian Revolver provides for the issuance of letters of credit which reduce the amounts that may be borrowed under this revolver. The amount available under the Canadian Revolver was reduced by $0.1 million for an outstanding letter of credit at December 31, 2013.

- changed (2014-05-07):
[0001564590-14-001858:note_history:22]
There were no borrowings outstanding under the Canadian Revolver as of March 31, 2014.  Amounts available under the Canadian Revolver were $8.9 million at March 31, 2014. The Canadian Revolver expires on February 28, 2015. The interest rate for amounts outstanding under the Canadian Revolver is a floating interest rate based upon either the Canadian Prime Rate, or the lender’s Bankers’ Acceptance Rate. Once the applicable rate is determined, a margin of 0.50% to 1.75%, as determined by our consolidated leverage ratio, is added to the applicable rate.
  (was, 2014-02-05, similarity 0.9756):
[0001564590-14-000140:note_history:22]
There were no borrowings outstanding under the Canadian Revolver as of December 31, 2013.  Amounts available under the Canadian Revolver were $9.3 million at December 31, 2013. The Canadian Revolver expires on February 28, 2015. The interest rate for amounts outstanding under the Canadian Revolver is a floating interest rate based upon either the Canadian Prime Rate, or the lender’s Bankers’ Acceptance Rate. Once the applicable rate is determined, a margin of 0.50% to 1.75%, as determined by our consolidated leverage ratio, is added to the applicable rate.

- changed (2014-05-07):
[0001564590-14-001858:note_history:23]
The Canadian Revolver is secured by the assets of our Canadian operations and provides for customary events of default and carries cross-default provisions with our existing debt agreements. If an event of default (as defined in the Canadian Revolver) occurs and is continuing, per the terms and subject to the conditions set forth in the Canadian Revolver, amounts outstanding under the Canadian Revolver may be accelerated and may become immediately due and payable. As of March 31, 2014, we were in compliance with all of the financial covenants of the Canadian Revolver.
  (was, 2014-02-05, similarity 0.9886):
[0001564590-14-000140:note_history:23]
The Canadian Revolver is secured by the assets of our Canadian operations and provides for customary events of default and carries cross-default provisions with our existing debt agreements. If an event of default (as defined in the Canadian Revolver) occurs and is continuing, per the terms and subject to the conditions set forth in the Canadian Revolver, amounts outstanding under the Canadian Revolver may be accelerated and may become immediately due and payable. As of December 31, 2013, we were in compliance with all of the financial covenants of the Canadian Revolver.

- changed (2014-05-07):
[0001564590-14-001858:note_history:24]
We borrowed $8.0 million in October 2001 through a loan agreement funded with proceeds from tax-exempt industrial development revenue bonds (Bonds). These Bonds were issued by the Illinois Development Finance Authority and were used for the completion of our Northlake, Illinois facility. Pursuant to the Bond issuance, a reimbursement agreement between us and a major domestic bank required an issuance by the bank of an irrevocable direct-pay letter of credit (Bond LC), as collateral, to the Bonds’ trustee to guarantee payment of the Bonds’ principal and interest when due. The Bond LC is subject to both early termination and extension provisions customary to such agreements, as well as various covenants, for which we were in compliance at March 31, 2014. While the Bonds mature in 2021, the reimbursement agreement requires annual redemptions of $0.4 million that commenced on October 25, 2002. A sinking fund is used for the redemption of the Bonds. At March 31, 2014, the balance in the restricted sinking fund was approximately $0.2 million and was recorded in cash and cash equivalents. The Bonds bear interest at a floating rate determined weekly by the Bonds’ remarketing agent, which was the underwriter for the Bonds and is an affiliate of the bank. This interest rate was 0.25% as of March 31, 2014.
  (was, 2014-02-05, similarity 0.9747):
[0001564590-14-000140:note_history:24]
We borrowed $8.0 million in October 2001 through a loan agreement funded with proceeds from tax-exempt industrial development revenue bonds (Bonds). These Bonds were issued by the Illinois Development Finance Authority and were used for the completion of our Northlake, Illinois facility. Pursuant to the Bond issuance, a reimbursement agreement between us and a major domestic bank required an issuance by the bank of an irrevocable direct-pay letter of credit (Bond LC), as collateral, to the Bonds’ trustee to guarantee payment of the Bonds’ principal and interest when due. The Bond LC is subject to both early termination and extension provisions customary to such agreements, as well as various covenants, for which we were in compliance at December 31, 2013. While the Bonds mature in 2021, the reimbursement agreement requires annual redemptions of $0.4 million that commenced on October 25, 2002. A sinking fund is used for the redemption of the Bonds. At December 31, 2013, the balance in the restricted sinking fund was approximately $0.1 million and was recorded in cash and cash equivalents. The Bonds bear interest at a floating rate determined weekly by the Bonds’ remarketing agent, which was the underwriter for the Bonds and is an affiliate of the bank. This interest rate was 0.18% per year on December 31, 2013.

- removed (2014-05-07):
[0001564590-14-000140:note_history:25]
In December 2013, we amended and restated our existing credit agreement (Amended Credit Agreement) with a major domestic bank. We entered into this Amended Credit Agreement to, among other things, allow for the payment of dividends and to extend the termination date of the facility. The Amended Credit Agreement provides for a $72.0 million revolving credit facility (U.S. Revolver). Obligations are collateralized by the stock of certain of our subsidiaries.


## us-gaap:ScheduleOfDebtInstrumentsTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2014-05-07):
[0001564590-14-001858:note_history:26]
|  | March 31, |  |  | September 30, |  |
|  | 2014 |  |  | 2013 |  |
| Industrial development revenue bonds | $ | 3,200 |  |  | $ | 3,600 |  |
| Capital lease obligations |  | — |  |  |  | 16 |  |
| Subtotal long-term debt and capital lease obligations |  | 3,200 |  |  |  | 3,616 |  |
| Less current portion |  | (400 | ) |  |  | (416 | ) |
| Total long-term debt and capital lease obligations | $ | 2,800 |  |  | $ | 3,200 |  |
  (was, 2014-02-05, similarity 0.8982):
[0001564590-14-000140:note_history:26]
|  | December 31, 2013 |  |  | September 30, 2013 |  |
| Industrial development revenue bonds | $ | 3,200 |  |  | $ | 3,600 |  |
| Capital lease obligations |  | − |  |  |  | 16 |  |
| Subtotal long-term debt and capital lease obligations |  | 3,200 |  |  |  | 3,616 |  |
| Less current portion |  | (400 | ) |  |  | (416 | ) |
| Total long-term debt and capital lease obligations | $ | 2,800 |  |  | $ | 3,200 |  |


## us-gaap:SubsequentEventsPolicyPolicyTextBlock (subsequent_events) — matched_by: no_current_note, score: 0.0

- removed (2014-05-07):
[0001564590-14-000140:note_history:27]
Subsequent events

- removed (2014-05-07):
[0001564590-14-000140:note_history:28]
On January 15, 2014, we sold our wholly-owned subsidiary Transdyn, Inc. (Transdyn) to a global provider of electronic toll collection systems, headquartered in Vienna, Austria.  See Note I for additional information about this transaction.

- removed (2014-05-07):
[0001564590-14-000140:note_history:29]
On February 3, 2014, our Board declared a quarterly cash dividend of $0.25 per share payable to shareholders of record on February 19, 2014.  This dividend will be approximately $3.0 million and paid on March 19, 2014.
