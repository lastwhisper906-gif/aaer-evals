# POWL 8-K — 0001193125-14-187496 filed 2014-05-07

## item codes, every 8-K on or before 2014-05-07

- 2014-05-07 0001193125-14-187496 — 2.02, 8.01, 9.01
- 2014-03-03 0001193125-14-079843 — 5.02, 5.07
- 2014-02-05 0001193125-14-036633 — 2.02, 8.01, 9.01
- 2014-01-17 0001193125-14-014351 — 1.01, 8.01, 9.01
- 2014-01-06 0001193125-14-002795 — 1.01, 2.03
- 2013-12-06 0001564590-13-001411 — 2.02, 9.01
- 2013-12-05 0001564590-13-001406 — 5.02, 8.01, 9.01
- 2013-11-07 0001193125-13-432950 — 8.01, 9.01
- 2013-08-07 0001193125-13-324337 — 2.02, 9.01
- 2013-05-08 0001193125-13-206800 — 2.02, 9.01
- 2013-02-22 0001193125-13-070971 — 5.02, 5.07
- 2013-02-06 0001193125-13-040556 — 2.02, 9.01
- 2012-12-18 0001193125-12-506417 — 5.02, 9.01
- 2012-12-05 0001193125-12-491749 — 2.02, 9.01
- 2012-10-12 0001193125-12-421889 — 3.03, 5.02, 5.03, 9.01
- 2012-08-09 0001193125-12-344617 — 5.02, 8.01, 9.01
- 2012-08-08 0001193125-12-343630 — 2.02, 9.01
- 2012-05-09 0001193125-12-221356 — 2.02, 9.01
- 2012-02-08 0001193125-12-046560 — 2.02, 9.01
- 2011-12-08 0001193125-11-334810 — 2.02, 9.01
- 2011-11-08 0000950123-11-096524 — 2.02, 2.06, 4.02, 9.01
- 2011-10-14 0000950123-11-090124 — 5.02
- 2011-10-06 0000950123-11-088969 — 5.02
- 2011-09-19 0000950123-11-085224 — 5.02, 9.01
- 2011-09-15 0000950123-11-084806 — 5.02, 9.01
- 2011-08-04 0000950123-11-072788 — 2.02, 9.01
- 2011-07-22 0000950123-11-067402 — 5.07
- 2011-05-24 0000950123-11-053550 — 1.01, 2.03, 9.01
- 2011-05-04 0000950123-11-044561 — 2.02, 9.01
- 2011-02-02 0000950123-11-008188 — 2.02, 9.01
- 2010-12-08 0000950123-10-111987 — 2.02, 9.01
- 2010-08-05 0000950123-10-073114 — 2.02, 9.01
- 2010-05-18 0000950123-10-050900 — 5.02
- 2010-05-05 0000950123-10-044499 — 2.02, 9.01
- 2010-02-03 0000950123-10-008278 — 2.02, 9.01
- 2009-12-21 0000950123-09-072269 — 1.01, 2.01, 2.03, 8.01, 9.01
- 2009-12-09 0000950123-09-069525 — 2.02, 9.01
- 2009-10-27 0000950123-09-053501 — 1.01, 8.01, 9.01
- 2009-08-04 0000950123-09-029476 — 2.02, 9.01
- 2009-05-06 0000950129-09-001498 — 2.02, 9.01
- 2009-03-05 0000950129-09-000749 — 1.01, 9.01
- 2009-02-10 0000950129-09-000349 — 2.02, 9.01
- 2008-12-10 0000950134-08-021934 — 2.02, 9.01
- 2008-08-06 0000950129-08-004267 — 2.02, 9.01
- 2008-07-24 0000950129-08-004063 — 1.01, 5.02, 8.01, 9.01
- 2008-06-16 0000950129-08-003500 — 9.01 — amendment of 0000950134-06-015374
- 2008-06-05 0000950129-08-003378 — 5.02, 9.01
- 2008-05-08 0000950129-08-002843 — 2.02, 9.01
- 2008-02-06 0000950129-08-000533 — 2.02, 9.01
- 2007-12-19 0000950129-07-006277 — 1.01, 2.03, 9.01
- 2007-12-06 0000950129-07-006003 — 2.02, 9.01
- 2007-08-21 0000950129-07-004181 — 2.02, 9.01
- 2007-05-31 0000950129-07-002810 — 2.02, 9.01
- 2007-05-21 0000950129-07-002668 — 2.02, 3.01, 4.02, 9.01
- 2007-04-16 0000950129-07-002002 — 2.02, 4.02, 9.01
- 2007-03-01 0000950129-07-001104 — 5.02, 8.01, 9.01
- 2007-02-08 0000950129-07-000451 — 2.02, 9.01
- 2006-12-08 0000950129-06-010041 — 2.02, 9.01
- 2006-09-08 0000950129-06-008379 — 2.02, 9.01
- 2006-08-09 0000950134-06-015374 — 1.01, 2.01, 8.01, 9.01
- 2006-06-08 0000950129-06-006127 — 2.02, 9.01
- 2006-03-09 0000950129-06-002455 — 2.02, 9.01
- 2005-12-16 0000950129-05-012031 — 2.02, 5.03, 9.01
- 2005-09-13 0000950129-05-009181 — 2.01, 9.01 — amendment of 0000950129-05-006889
- 2005-09-12 0000950129-05-009151 — 2.02, 9.01
- 2005-07-06 0000950129-05-006889 — 1.01, 1.02, 2.01, 2.03, 9.01
- 2005-06-10 0000950129-05-006128 — 2.02, 9.01
- 2005-04-20 0000080420-05-000031 — 5.02
- 2005-03-11 0000080420-05-000024 — 9.01
- 2005-02-25 0000080420-05-000018 — 7.01, 9.01
- 2005-01-21 0000080420-05-000009 — 7.01, 9.01
- 2004-12-17 0000080420-04-000049 — 2.02, 9.01
- 2004-11-01 0000080420-04-000045 — 8.01, 9.01
- 2004-10-08 0001169232-04-005133 — 2.05
- 2004-09-14 0000080420-04-000037 — 5.02
- 2004-09-02 0000080420-04-000030 — 2.02, 9.01
- 2004-06-08 0000080420-04-000021 — 7
- 2004-05-13 0000080420-04-000019 — 4
- 2004-02-27 0000080420-04-000013 — 7
- 2003-12-16 0000950129-03-006136 — 12, 7
- 2003-08-29 0000950129-03-004531 — 12, 7
- 2003-06-03 0000950129-03-003035 — 7, 9
- 2003-05-15 0000950129-03-002812 — 7, 9
- 2002-05-29 0000950129-02-002795 — 4
- 2000-12-21 0000950129-00-006093 — 5, 7
- 1998-09-04 0000950129-98-003802 — 5
- 1996-08-09 0000950129-96-001705 — 2, 7

## late-filing notifications on or before 2014-05-07

- 2007-05-11 0000950129-07-002494 — NT 10-Q, for the period ended 2007-03-31
- 2005-01-18 0000080420-05-000004 — NT 10-K, for the period ended 2004-10-31

## item 2.02 — earnings release, exhibit 99.1

[0001193125-14-187496:8k_2_02:1]
EX-99.1
2
d721694dex991.htm
EX-99.1

[0001193125-14-187496:8k_2_02:2]
EX-99.1

[0001193125-14-187496:8k_2_02:3]
Exhibit 99.1

[0001193125-14-187496:8k_2_02:4]
|  |  | PRESS RELEASE |

[0001193125-14-187496:8k_2_02:5]
| FOR IMMEDIATE RELEASE |  | Contacts: |  | Don R. Madison, CFO |
|  |  |  |  | Powell Industries, Inc. |
|  |  |  |  | 713-947-4422 |

[0001193125-14-187496:8k_2_02:6]
POWELL INDUSTRIES ANNOUNCES FISCAL 2014

[0001193125-14-187496:8k_2_02:7]
SECOND QUARTER RESULTS

[0001193125-14-187496:8k_2_02:8]
HOUSTON — MAY
6, 2014 — Powell Industries, Inc. (NASDAQ: POWL) (“Powell”), a leading supplier of custom engineered solutions for the distribution and control of electrical energy, today announced results for the fiscal 2014 second quarter ended
March 31, 2014.

[0001193125-14-187496:8k_2_02:9]
Revenues for the second quarter of fiscal 2014 were $162.3 million compared to revenues of $146.0 million for the
second quarter of fiscal 2013. Income from continuing operations for the second quarter of fiscal 2014 was $7.0 million, or $0.58 per diluted share, compared to income from continuing operations of $6.2 million, or $0.52 per diluted share, in the
second quarter of fiscal 2013.

[0001193125-14-187496:8k_2_02:10]
On January 15, 2014, Powell closed the sale of Transdyn, Inc. and has recorded the results of
Transdyn as discontinued operations. Income from discontinued operations in the second quarter of 2014, including the gain on sale, was $8.6 million, or $0.71 per diluted share. Net income for the second quarter of fiscal 2014 was $15.6 million, or
$1.29 per diluted share.

[0001193125-14-187496:8k_2_02:11]
Michael A. Lucas, President and Chief Executive Officer, stated, “We had a solid second quarter, with
improving margins as a result of our process enhancements and cost saving activities, and have a healthy ending backlog. At the request of customers, we rescheduled shipments of a few large projects, which will result in some revenues being pushed
into subsequent quarters. These delivery changes are not uncommon to our project-based business, and we are working to add some short cycle work to fill available short-term capacity. Additionally, we continued to manage efficiency and utilization
challenges as we ramped up capacity in our Canadian operations. In spite of this temporary issue, we are delivering on time and meeting customer commitments.

[0001193125-14-187496:8k_2_02:12]
“We continue to see strength in the oil and gas market, with a significant portion of our
activity in North America. We remain optimistic about the key segments of pipelines, petrochemical and LNG. Inquiry activity continues at a healthy pace, as we leverage our strong position in the U.S. and Canadian markets.”

[0001193125-14-187496:8k_2_02:13]
New orders from continuing operations in the fiscal 2014 second quarter were $163 million compared to $192 million in the first quarter of
fiscal 2014 and compared to $118 million in the second quarter of fiscal 2013. The Company’s backlog for continuing operations as of March 31, 2014 was $452 million compared to $455 million as of December 31, 2013 and compared to $439
million at the end of last year’s second quarter.

[0001193125-14-187496:8k_2_02:14]
OUTLOOK

[0001193125-14-187496:8k_2_02:15]
The following statements are based on the current expectations of the Company for its continuing operations. These statements are
forward-looking, and actual results may differ materially as further elaborated in the last paragraph below.

[0001193125-14-187496:8k_2_02:16]
Based on its backlog and
current business conditions, Powell Industries continues to expect full year fiscal 2014 revenues from continuing operations to range between $700 million and $750 million and fiscal year 2014 earnings to range between $2.85 and $3.35 per diluted
share. This earnings guidance excludes the discontinued operations of Transdyn, Inc. and the associated gain on sale.

[0001193125-14-187496:8k_2_02:17]
CONFERENCE CALL

[0001193125-14-187496:8k_2_02:18]
Powell Industries has scheduled a conference call for Wednesday, May 7, 2014 at 11:00 a.m. eastern time. To participate in the conference
call, dial 480-629-9771 at least 10 minutes before the call begins and ask for the Powell Industries conference call. A replay of the call will be available approximately two hours after the live broadcast ends and will be accessible until
May 14, 2014. To access the replay, dial 303-590-3030 using a passcode of 4679229#.

[0001193125-14-187496:8k_2_02:19]
Investors, analysts and the general public will
also have the opportunity to listen to the conference call over the Internet by visiting powellind.com. To listen to the live call on the web, please visit the website at least fifteen minutes before the call begins to register, download and
install any necessary audio software. For those who cannot listen to the live webcast, an archive will be available shortly after the call and will remain available for approximately 90 days at powellind.com.

[0001193125-14-187496:8k_2_02:20]
Powell Industries, Inc., headquartered in Houston, engineers packaged solutions and systems for the control,
distribution and management of electrical energy. Powell markets include large industrial customers such as utilities, oil and gas producers, refineries, petrochemical plants, pulp and paper producers, mining operations and commuter
railways. For more information, please visit powellind.com.

[0001193125-14-187496:8k_2_02:21]
POWELL INDUSTRIES, INC. & SUBSIDIARIES

[0001193125-14-187496:8k_2_02:22]
CONDENSED CONSOLIDATED STATEMENT OF OPERATIONS

[0001193125-14-187496:8k_2_02:23]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | March 31,2014 |  |  | March 31,2013 |  |  | March 31,2014 |  |  | March 31,2013 |  |
| (In thousands, except per share data) |  | (Unaudited) |  |
| Revenues |  | $ | 162,295 |  |  | $ | 146,041 |  |  | $ | 334,167 |  |  | $ | 292,899 |  |
| Cost of goods sold |  |  | 127,367 |  |  |  | 116,498 |  |  | $ | 264,081 |  |  |  | 230,954 |  |
| Gross profit |  |  | 34,928 |  |  |  | 29,543 |  |  |  | 70,086 |  |  |  | 61,945 |  |
| Selling, general and administrative expenses |  |  | 22,088 |  |  |  | 20,989 |  |  |  | 43,722 |  |  |  | 40,675 |  |
| Research and development expenses |  |  | 2,157 |  |  |  | 1,850 |  |  |  | 3,996 |  |  |  | 3,564 |  |
| Amortization of intangible assets |  |  | 121 |  |  |  | 413 |  |  |  | 536 |  |  |  | 828 |  |
| Operating income |  |  | 10,562 |  |  |  | 6,291 |  |  |  | 21,832 |  |  |  | 16,878 |  |
| Other income |  |  | (507 | ) |  |  | (1,709 | ) |  |  | (507 | ) |  |  | (1,709 | ) |
| Interest expense |  |  | 41 |  |  |  | 43 |  |  |  | 110 |  |  |  | 104 |  |
| Interest income |  |  | (3 | ) |  |  | (2 | ) |  |  | (6 | ) |  |  | (21 | ) |
| Income from continuing operations before income taxes |  |  | 11,031 |  |  |  | 7,959 |  |  |  | 22,235 |  |  |  | 18,504 |  |
| Income tax provision |  |  | 4,055 |  |  |  | 1,757 |  |  |  | 7,992 |  |  |  | 5,182 |  |
| Income from continuing operations |  |  | 6,976 |  |  |  | 6,202 |  |  |  | 14,243 |  |  |  | 13,322 |  |
| Income from discontinued operations, net of tax |  |  | 8,617 |  |  |  | 616 |  |  |  | 9,604 |  |  |  | 881 |  |
| Net income |  | $ | 15,593 |  |  | $ | 6,818 |  |  | $ | 23,847 |  |  | $ | 14,203 |  |
| Earnings per share: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Continuing operations |  | $ | 0.58 |  |  | $ | 0.52 |  |  | $ | 1.19 |  |  | $ | 1.12 |  |
| Discontinued operations |  | $ | 0.72 |  |  | $ | 0.05 |  |  | $ | 0.80 |  |  | $ | 0.07 |  |
| Basic earnings per share |  | $ | 1.30 |  |  | $ | 0.57 |  |  | $ | 1.99 |  |  | $ | 1.19 |  |
| Continuing operations |  | $ | 0.58 |  |  | $ | 0.52 |  |  | $ | 1.18 |  |  | $ | 1.11 |  |
| Discontinued operations |  | $ | 0.71 |  |  | $ | 0.05 |  |  | $ | 0.80 |  |  | $ | 0.07 |  |
| Diluted earnings per share |  | $ | 1.29 |  |  | $ | 0.57 |  |  | $ | 1.98 |  |  | $ | 1.18 |  |
| Weighted average shares: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  |  | 12,004 |  |  |  | 11,953 |  |  |  | 11,999 |  |  |  | 11,946 |  |
| Diluted |  |  | 12,064 |  |  |  | 12,029 |  |  |  | 12,057 |  |  |  | 12,021 |  |
| SELECTED FINANCIAL DATA: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Depreciation and Amortization |  | $ | 2,617 |  |  | $ | 2,355 |  |  | $ | 5,595 |  |  | $ | 5,427 |  |
| Capital Expenditures |  | $ | 2,700 |  |  | $ | 19,895 |  |  | $ | 8,464 |  |  | $ | 33,270 |  |

[0001193125-14-187496:8k_2_02:24]
POWELL INDUSTRIES, INC. & SUBSIDIARIES

[0001193125-14-187496:8k_2_02:25]
CONDENSED CONSOLIDATED BALANCE SHEETS

[0001193125-14-187496:8k_2_02:26]
|  |  | March 31, |  |  | September 30, |  |
|  |  | 2014 |  |  | 2013 |  |
| (In thousands) |  | (Unaudited) |  |  |  |  |
| Assets: |  |  |  |  |  |  |  |  |
| Current assets |  | $ | 341,941 |  |  | $ | 341,931 |  |
| Current assets held for sale |  |  | — |  |  |  | 15,409 |  |
| Property, plant and equipment (net) |  |  | 145,055 |  |  |  | 144,495 |  |
| Long-term assets |  |  | 28,068 |  |  |  | 28,924 |  |
| Long-term assets held for sale |  |  | — |  |  |  | 144 |  |
| Total assets |  | $ | 515,064 |  |  | $ | 530,903 |  |
| Liabilities & equity: |  |  |  |  |  |  |  |  |
| Current liabilities |  | $ | 130,241 |  |  | $ | 150,215 |  |
| Current liabilities held for sale |  |  | — |  |  |  | 17,848 |  |
| Long-term debt and capital lease obligations, net of current maturities |  |  | 2,800 |  |  |  | 3,200 |  |
| Deferred and other long-term liabilities |  |  | 10,476 |  |  |  | 4,210 |  |
| Long-term liabilities held for sale |  |  | — |  |  |  | 204 |  |
| Stockholders’ equity |  |  | 371,547 |  |  |  | 355,226 |  |
| Total liabilities and stockholders’ equity |  | $ | 515,064 |  |  | $ | 530,903 |  |

[0001193125-14-187496:8k_2_02:27]
# # #
