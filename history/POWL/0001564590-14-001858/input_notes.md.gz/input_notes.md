# POWL notes — 0001564590-14-001858


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureAndSignificantAccountingPoliciesTextBlock

[0001564590-14-001858:notes:1]
[same as prior period, unchanged from 0001564590-14-000140:notes:1]

[0001564590-14-001858:notes:2]
[same as prior period, unchanged from 0001564590-14-000140:notes:2]

[0001564590-14-001858:notes:3]
Powell Industries, Inc. (we, us, our, Powell or the Company) was incorporated in the state of Delaware in 2004 as a successor to a Nevada company incorporated in 1968. The Nevada corporation was the successor to a company founded by William E. Powell in 1947, which merged into the Company in 1977. Our major subsidiaries, all of which are wholly-owned, include: Powell Electrical Systems, Inc.; Powell Industries International, B.V.; Powell (UK) Limited (formerly Switchgear & Instrumentation Limited) and Powell Canada Inc.

[0001564590-14-001858:notes:4]
[same as prior period, unchanged from 0001564590-14-000140:notes:4]

[0001564590-14-001858:notes:5]
[same as prior period, unchanged from 0001564590-14-000140:notes:5]

[0001564590-14-001858:notes:6]
[same as prior period, unchanged from 0001564590-14-000140:notes:6]

[0001564590-14-001858:notes:7]
These unaudited condensed consolidated financial statements have been prepared in accordance with the instructions to Form 10-Q and Rule 10-01 of Regulation S-X for interim financial information.  Certain information and footnote disclosures, normally included in annual financial statements prepared in accordance with accounting principles generally accepted in the United States (U.S. GAAP), have been condensed or omitted pursuant to those rules and regulations. In the opinion of management, all adjustments, consisting only of normal recurring adjustments, necessary to fairly state the financial position, results of operations and cash flows with respect to the interim consolidated financial statements have been included. The results of operations for the interim periods are not necessarily indicative of the results for the entire fiscal year.  We believe that these financial statements contain all adjustments necessary so that they are not misleading. The year-end balance sheet data was derived from audited financial statements, but does not include all disclosures required by U.S. GAAP.

[0001564590-14-001858:notes:8]
As discussed in Note I, on January 15, 2014, we sold our wholly-owned subsidiary Transdyn Inc. (Transdyn).  We reclassified the assets and liabilities of Transdyn as held for sale within the accompanying condensed consolidated balance sheet as of September 30, 2013 and presented the results of these operations as income from discontinued operations, net of tax, for each of the accompanying condensed consolidated statements of operations. While this sale did not result in a material disposition of assets or material reduction to income before income taxes relative to Powell’s consolidated financial statements, the revenues, gross profit, income before income taxes and assets of Transdyn comprised a significant majority of those respective amounts previously reported in our Process Control Systems business segment. As we previously only reported two business segments, Electrical Power Products and Process Control Systems, we have removed the presentation of segments in our Notes to Condensed Consolidated Financial Statements.

[0001564590-14-001858:notes:9]
These unaudited condensed consolidated financial statements should be read in conjunction with the audited consolidated financial statements and notes thereto of Powell and its subsidiaries included in Powell’s Annual Report on Form 10-K for the year ended September 30, 2013, which was filed with the Securities and Exchange Commission (SEC) on December 4, 2013.

[0001564590-14-001858:notes:10]
[same as prior period, unchanged from 0001564590-14-000140:notes:9]

[0001564590-14-001858:notes:11]
[same as prior period, unchanged from 0001564590-14-000140:notes:10]

[0001564590-14-001858:notes:12]
[same as prior period, unchanged from 0001564590-14-000140:notes:11]

[0001564590-14-001858:notes:13]
[same as prior period, unchanged from 0001564590-14-000140:notes:13]

[0001564590-14-001858:notes:14]
[same as prior period, unchanged from 0001564590-14-000140:notes:14]

[0001564590-14-001858:notes:15]
In April 2014, the FASB issued an amendment to the financial reporting of discontinued operations.  The amendments in this update change the criteria for reporting discontinued operations while enhancing disclosures in this area. It also addresses sources of confusion and inconsistent application related to financial reporting of discontinued operations guidance in U.S. GAAP.  Under the new guidance, only disposals representing a strategic shift in operations that have a major effect on the organization’s operations and financial results should be presented as discontinued operations. Examples include a disposal of a major geographic area, a major line of business, or a major equity method investment.  In addition, the new guidance requires expanded disclosures about discontinued operations that will provide financial statement users with more information about the assets, liabilities, income, and expenses of discontinued operations.  The new guidance also requires disclosure of the pre-tax income attributable to a disposal of a significant part of an organization that does not qualify for discontinued operations reporting. This disclosure will provide users with information about the ongoing trends in a reporting organization’s results from continuing operations. The amendments in this update are effective in the first quarter of 2015, which would be our fiscal year end September 30, 2016.  Early adoption is permitted for disposals that have not been previously reported as discontinued operations.


## us-gaap:EarningsPerShareTextBlock

[0001564590-14-001858:notes:16]
[same as prior period, unchanged from 0001564590-14-000140:notes:21]

[0001564590-14-001858:notes:17]
We compute basic earnings per share by dividing net income by the weighted average number of common shares outstanding during the period. Diluted earnings per common and potential common share includes the weighted average of additional shares associated with the incremental effect of dilutive restrictive stock units, as prescribed by the FASB guidance on earnings per share.

[0001564590-14-001858:notes:18]
[same as prior period, unchanged from 0001564590-14-000140:notes:23]

[0001564590-14-001858:notes:19]
|  | Three Months Ended |  |  | Six Months Ended |  |
|  | March 31, |  |  | March 31, |  |
|  | 2014 |  |  | 2013 |  |  | 2014 |  |  | 2013 |  |
| Numerator: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Income from continuing operations |  | 6,976 |  |  |  | 6,202 |  |  |  | 14,243 |  |  |  | 13,322 |  |
| Income from discontinued operations |  | 8,617 |  |  |  | 616 |  |  |  | 9,604 |  |  |  | 881 |  |
| Net income | $ | 15,593 |  |  | $ | 6,818 |  |  | $ | 23,847 |  |  | $ | 14,203 |  |
| Denominator: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Weighted average basic shares |  | 12,004 |  |  |  | 11,953 |  |  |  | 11,999 |  |  |  | 11,946 |  |
| Dilutive effect of restricted stock units |  | 60 |  |  |  | 76 |  |  |  | 58 |  |  |  | 75 |  |
| Weighted average diluted shares with assumed conversions |  | 12,064 |  |  |  | 12,029 |  |  |  | 12,057 |  |  |  | 12,021 |  |
| Net earnings per share: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Continuing operations | $ | 0.58 |  |  | $ | 0.52 |  |  | $ | 1.19 |  |  | $ | 1.12 |  |
| Discontinued operations |  | 0.72 |  |  |  | 0.05 |  |  |  | 0.80 |  |  |  | 0.07 |  |
| Basic earnings per share | $ | 1.30 |  |  | $ | 0.57 |  |  | $ | 1.99 |  |  | $ | 1.19 |  |
| Continuing operations | $ | 0.58 |  |  | $ | 0.52 |  |  | $ | 1.18 |  |  | $ | 1.11 |  |
| Discontinued operations |  | 0.71 |  |  |  | 0.05 |  |  |  | 0.80 |  |  |  | 0.07 |  |
| Diluted earnings per share | $ | 1.29 |  |  | $ | 0.57 |  |  | $ | 1.98 |  |  | $ | 1.18 |  |


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0001564590-14-001858:notes:20]
[same as prior period, unchanged from 0001564590-14-000140:notes:25]

[0001564590-14-001858:notes:21]
[same as prior period, unchanged from 0001564590-14-000140:notes:26]

[0001564590-14-001858:notes:22]
[same as prior period, unchanged from 0001564590-14-000140:notes:27]

[0001564590-14-001858:notes:23]
|  | Three Months Ended |  |  | Six Months Ended |  |
|  | March 31, |  |  | March 31, |  |
|  | 2014 |  |  | 2013 |  |  | 2014 |  |  | 2013 |  |
| Balance at beginning of period | $ | 673 |  |  | $ | 928 |  |  | $ | 572 |  |  | $ | 1,297 |  |
| Bad debt recovery |  | (170 | ) |  |  | (59 | ) |  |  | (60 | ) |  |  | (380 | ) |
| Uncollectible accounts written off, net of recoveries |  | — |  |  |  | (28 | ) |  |  | (9 | ) |  |  | (85 | ) |
| Change in foreign currency translation |  | (2 | ) |  |  | (23 | ) |  |  | (2 | ) |  |  | (14 | ) |
| Balance at end of period | $ | 501 |  |  | $ | 818 |  |  | $ | 501 |  |  | $ | 818 |  |

[0001564590-14-001858:notes:24]
[same as prior period, unchanged from 0001564590-14-000140:notes:29]

[0001564590-14-001858:notes:25]
[same as prior period, unchanged from 0001564590-14-000140:notes:30]

[0001564590-14-001858:notes:26]
|  | March 31, |  |  | September 30, |  |
|  | 2014 |  |  | 2013 |  |
| Raw materials, parts and subassemblies | $ | 29,758 |  |  | $ | 30,077 |  |
| Work-in-progress |  | 3,771 |  |  |  | 3,818 |  |
| Provision for excess and obsolete inventory |  | (4,099 | ) |  |  | (4,932 | ) |
| Total inventories | $ | 29,430 |  |  | $ | 28,963 |  |

[0001564590-14-001858:notes:27]
[same as prior period, unchanged from 0001564590-14-000140:notes:32]

[0001564590-14-001858:notes:28]
[same as prior period, unchanged from 0001564590-14-000140:notes:33]

[0001564590-14-001858:notes:29]
|  | March 31, |  |  | September 30, |  |
|  | 2014 |  |  | 2013 |  |
| Costs incurred on uncompleted contracts | $ | 685,257 |  |  | $ | 618,570 |  |
| Estimated earnings |  | 172,948 |  |  |  | 159,962 |  |
|  |  | 858,205 |  |  |  | 778,532 |  |
| Less: Billings to date |  | (820,707 | ) |  |  | (747,446 | ) |
| Net underbilled position | $ | 37,498 |  |  | $ | 31,086 |  |
| Included in the accompanying balance sheets under the following captions: |  |  |  |  |  |  |  |
| Costs and estimated earnings in excess of billings on uncompleted contracts – underbilled | $ | 79,517 |  |  | $ | 79,420 |  |
| Billings in excess of costs and estimated earnings on uncompleted contracts – overbilled |  | (42,019 | ) |  |  | (48,334 | ) |
| Net underbilled position | $ | 37,498 |  |  | $ | 31,086 |  |

[0001564590-14-001858:notes:30]
[same as prior period, unchanged from 0001564590-14-000140:notes:35]

[0001564590-14-001858:notes:31]
[same as prior period, unchanged from 0001564590-14-000140:notes:36]

[0001564590-14-001858:notes:32]
|  | Three Months Ended |  |  | Six Months Ended |  |
|  | March 31, |  |  | March 31, |  |
|  | 2014 |  |  | 2013 |  |  | 2014 |  |  | 2013 |  |
| Balance at beginning of period | $ | 5,010 |  |  | $ | 5,610 |  |  | $ | 5,282 |  |  | $ | 5,548 |  |
| Increase to warranty expense |  | 1,042 |  |  |  | 810 |  |  |  | 1,505 |  |  |  | 1,495 |  |
| Deduction for warranty charges |  | (1,196 | ) |  |  | (1,230 | ) |  |  | (1,926 | ) |  |  | (1,851 | ) |
| Increase (decrease) due to foreign currency translations |  | (23 | ) |  |  | (81 | ) |  |  | (28 | ) |  |  | (83 | ) |
| Balance at end of period | $ | 4,833 |  |  | $ | 5,109 |  |  | $ | 4,833 |  |  | $ | 5,109 |  |


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0001564590-14-001858:notes:33]
[same as prior period, unchanged from 0001564590-14-000140:notes:38]

[0001564590-14-001858:notes:34]
Intangible assets balances, subject to amortization, at March 31, 2014 and September 30, 2013 consisted of the following (in thousands):

[0001564590-14-001858:notes:35]
|  | March 31, 2014 |  |  | September 30, 2013 |  |
|  | Gross |  |  |  |  |  |  | Net |  |  | Gross |  |  |  |  |  |  | Net |  |
|  | Carrying |  |  | Accumulated |  |  | Carrying |  |  | Carrying |  |  | Accumulated |  |  | Carrying |  |
|  | Value |  |  | Amortization |  |  | Value |  |  | Value |  |  | Amortization |  |  | Value |  |
| Purchased technology | $ | 11,749 |  |  | $ | (9,727 | ) |  | $ | 2,022 |  |  | $ | 11,749 |  |  | $ | (9,489 | ) |  | $ | 2,260 |  |
| Trade name |  | 1,136 |  |  |  | (1,011 | ) |  |  | 125 |  |  |  | 1,136 |  |  |  | (967 | ) |  |  | 169 |  |
| Supply agreement |  | — |  |  |  | — |  |  |  | — |  |  |  | 17,580 |  |  |  | (8,397 | ) |  |  | 9,183 |  |
| Total | $ | 12,885 |  |  | $ | (10,738 | ) |  | $ | 2,147 |  |  | $ | 30,465 |  |  | $ | (18,853 | ) |  | $ | 11,612 |  |

[0001564590-14-001858:notes:36]
Amortization of intangible assets recorded for the six months ended March 31, 2014 and 2013 was $0.5 million and $0.8 million, respectively.

[0001564590-14-001858:notes:37]
On August 7, 2006, we purchased certain assets related to the manufacturing of ANSI medium-voltage switchgear and circuit breaker business from General Electric Company (GE).  In connection with the acquisition, we entered into a 15 year supply agreement with GE pursuant to which GE would purchase from the Company all of its requirements for ANSI medium-voltage switchgear and circuit breakers and other related equipment and components (the Products)  In connection with the acquisition, we recorded an intangible asset related to this supply agreement.  On December 30, 2013, the Company and GE amended the supply agreement to allow GE to manufacture similar Products for sale immediately and allow GE to begin purchasing Products from other suppliers beginning December 31, 2014.  In return, GE paid us $10 million upon execution of the amended supply agreement and agreed to pay an additional $7 million over three years, subject to certain conditions.  We have $2.3 million recorded in other current assets and the remaining $4.7 million is recorded as a long-term receivable. We wrote off the intangible asset related to the original supply agreement and recorded a deferred credit in the amount of $8.1 million, the amount by which the total proceeds from GE exceeded the unamortized balance of our intangible asset. We are amortizing this deferred credit over the four year life of the agreement and have recognized a $0.5 million gain in the first six months of fiscal year 2014.


## us-gaap:LongTermDebtTextBlock

[0001564590-14-001858:notes:38]
E. LONG-TERM DEBT

[0001564590-14-001858:notes:39]
Long-term debt consisted of the following (in thousands):

[0001564590-14-001858:notes:40]
|  | March 31, |  |  | September 30, |  |
|  | 2014 |  |  | 2013 |  |
| Industrial development revenue bonds | $ | 3,200 |  |  | $ | 3,600 |  |
| Capital lease obligations |  | — |  |  |  | 16 |  |
| Subtotal long-term debt and capital lease obligations |  | 3,200 |  |  |  | 3,616 |  |
| Less current portion |  | (400 | ) |  |  | (416 | ) |
| Total long-term debt and capital lease obligations | $ | 2,800 |  |  | $ | 3,200 |  |

[0001564590-14-001858:notes:41]
US Revolver

[0001564590-14-001858:notes:42]
In fiscal year 2014, we amended and restated our existing credit agreement (Amended Credit Agreement) with a major domestic bank. We entered into this Amended Credit Agreement to, among other things, allow for the payment of dividends and to extend the expiration date of the facility. The Amended Credit Agreement provides for a $75.0 million revolving credit facility (U.S. Revolver). Obligations are collateralized by the stock of certain of our subsidiaries.

[0001564590-14-001858:notes:43]
The interest rate for amounts outstanding under the Amended Credit Agreement for the U.S. Revolver is a floating rate based upon the higher of the Federal Funds Rate plus 0.5%, the bank’s prime rate, or the Eurocurrency rate plus 1.00%. Once the applicable rate is determined, a margin ranging up to 1.75%, as determined by our consolidated leverage ratio, is added to the applicable rate.

[0001564590-14-001858:notes:44]
The U.S. Revolver provides for the issuance of letters of credit which reduce the amounts that may be borrowed under this revolver. The amount available under the U.S. Revolver was reduced by $21.9 million for our outstanding letters of credit at March 31, 2014.

[0001564590-14-001858:notes:45]
There were no borrowings outstanding under the U.S. Revolver as of March 31, 2014. Amounts available under the U.S. Revolver were $53.1 million at March 31, 2014. The U.S. Revolver expires on December 31, 2018.

[0001564590-14-001858:notes:46]
The Amended Credit Agreement contains certain restrictive and maintenance-type covenants, such as restrictions on the amount of capital expenditures allowed. It also contains financial covenants defining various financial measures and the levels of these measures with which we must comply, as well as a “material adverse change” clause. A “material adverse change” is defined as a material change in our operations, business, properties, liabilities or condition (financial or otherwise) or a material impairment of our ability to perform our obligations under our credit agreements.

[0001564590-14-001858:notes:47]
The Amended Credit Agreement is collateralized by a pledge of 100% of the voting capital stock of each of our domestic subsidiaries and 66% of the voting capital stock of each non-domestic subsidiary, excluding Powell Canada. The Amended Credit Agreement provides for customary events of default and carries cross-default provisions with other existing debt agreements. If an event of default (as defined in the Amended Credit Agreement) occurs and is continuing, on the terms and subject to the conditions set forth in the Amended Credit Agreement, amounts outstanding under the Amended Credit Agreement may be accelerated and may become immediately due and payable. As of March 31, 2014, we were in compliance with all of the financial covenants of the Amended Credit Agreement.

[0001564590-14-001858:notes:48]
Canadian Revolver

[0001564590-14-001858:notes:49]
We have a $9.0 million credit agreement with a major international bank in Canada (the Canadian Revolver) to provide working capital support and letters of credit for our operations in Canada. The Canadian Revolver provides for the issuance of letters of credit which reduce the amounts that may be borrowed under this revolver. The amount available under the Canadian Revolver was reduced by $0.1 million for an outstanding letter of credit at March 31, 2014.

[0001564590-14-001858:notes:50]
There were no borrowings outstanding under the Canadian Revolver as of March 31, 2014.  Amounts available under the Canadian Revolver were $8.9 million at March 31, 2014. The Canadian Revolver expires on February 28, 2015. The interest rate for amounts outstanding under the Canadian Revolver is a floating interest rate based upon either the Canadian Prime Rate, or the lender’s Bankers’ Acceptance Rate. Once the applicable rate is determined, a margin of 0.50% to 1.75%, as determined by our consolidated leverage ratio, is added to the applicable rate.

[0001564590-14-001858:notes:51]
The principal financial covenants are consistent with those described in our Amended Credit Agreement. The Canadian Revolver contains a “material adverse effect” clause. A “material adverse effect” is defined as a material change in the operations of Powell or Powell Canada in relation to our financial condition, property, business operations, expected net cash flows, liabilities or capitalization.

[0001564590-14-001858:notes:52]
The Canadian Revolver is secured by the assets of our Canadian operations and provides for customary events of default and carries cross-default provisions with our existing debt agreements. If an event of default (as defined in the Canadian Revolver) occurs and is continuing, per the terms and subject to the conditions set forth in the Canadian Revolver, amounts outstanding under the Canadian Revolver may be accelerated and may become immediately due and payable. As of March 31, 2014, we were in compliance with all of the financial covenants of the Canadian Revolver.

[0001564590-14-001858:notes:53]
Industrial Development Revenue Bonds

[0001564590-14-001858:notes:54]
We borrowed $8.0 million in October 2001 through a loan agreement funded with proceeds from tax-exempt industrial development revenue bonds (Bonds). These Bonds were issued by the Illinois Development Finance Authority and were used for the completion of our Northlake, Illinois facility. Pursuant to the Bond issuance, a reimbursement agreement between us and a major domestic bank required an issuance by the bank of an irrevocable direct-pay letter of credit (Bond LC), as collateral, to the Bonds’ trustee to guarantee payment of the Bonds’ principal and interest when due. The Bond LC is subject to both early termination and extension provisions customary to such agreements, as well as various covenants, for which we were in compliance at March 31, 2014. While the Bonds mature in 2021, the reimbursement agreement requires annual redemptions of $0.4 million that commenced on October 25, 2002. A sinking fund is used for the redemption of the Bonds. At March 31, 2014, the balance in the restricted sinking fund was approximately $0.2 million and was recorded in cash and cash equivalents. The Bonds bear interest at a floating rate determined weekly by the Bonds’ remarketing agent, which was the underwriter for the Bonds and is an affiliate of the bank. This interest rate was 0.25% as of March 31, 2014.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001564590-14-001858:notes:55]
F. COMMITMENTS AND CONTINGENCIES

[0001564590-14-001858:notes:56]
Long-Term Debt

[0001564590-14-001858:notes:57]
See Note E herein for discussion of our long-term debt.

[0001564590-14-001858:notes:58]
Letters of Credit and Bonds

[0001564590-14-001858:notes:59]
Certain customers require us to post bank letter of credit guarantees or performance bonds issued by a surety. These guarantees and performance bonds assure that we will perform under the terms of our contract. In the event of default, the counterparty may demand payment from the bank under a letter of credit or performance by the surety under a performance bond. To date, there have been no significant expenses related to either letters of credit or performance bonds for the periods reported. We were contingently liable for secured and unsecured letters of credit of $22.1 million as of March 31, 2014. We also had performance and maintenance bonds totaling $306.7 million that were outstanding, with additional bonding capacity of $293.3 million available, at March 31, 2014.

[0001564590-14-001858:notes:60]
We have an $8.3 million facility agreement (Facility Agreement) between S&I and a large international bank. This Facility Agreement provides S&I the ability to enter into various guarantees, such as forward exchange contracts, currency options and performance bonds. At March 31, 2014, we had outstanding guarantees totaling $3.9 million under this Facility Agreement.  Amounts available under this Facility Agreement were $4.4 million as of March 31, 2014.

[0001564590-14-001858:notes:61]
The Facility Agreement provides for financial covenants and customary events of default, and carries cross-default provisions with our Amended Credit Facility. If an event of default (as defined in the Facility Agreement) occurs and is continuing, per the terms and subject to the conditions set forth in the Facility Agreement, obligations outstanding under the Facility Agreement may be accelerated and may become or be declared immediately due and payable. As of March 31, 2014, we were in compliance with all of the financial covenants of the Facility Agreement.  The Facility Agreement expires in July 2014.

[0001564590-14-001858:notes:62]
Litigation

[0001564590-14-001858:notes:63]
We are involved in various legal proceedings, claims and other disputes arising in the ordinary course of business which, in general, are subject to uncertainties and the outcomes are not predictable. Although we can give no assurance about the outcome of pending or threatened litigation and the effect such outcomes may have on us, management believes that any ultimate liability resulting from the outcome of such proceedings, to the extent not otherwise provided or covered by insurance, will not have a material adverse effect on our consolidated financial position or results of operations or liquidity.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001564590-14-001858:notes:64]
G.  STOCK-BASED COMPENSATION

[0001564590-14-001858:notes:65]
[same as prior period, unchanged from 0001564590-14-000140:notes:70]

[0001564590-14-001858:notes:66]
On February 26, 2014, our stockholders approved and adopted at the Annual Meeting of Stockholders the 2014 Equity Incentive Plan (the 2014 Plan). Persons eligible to receive awards under the 2014 Plan include our officers and employees. The 2014 Plan authorizes stock options, stock appreciation rights, restricted stock, restricted stock units and performance-based awards, as well as certain other awards.  We have reserved 750,000 shares of common stock for issuance under the 2014 Plan.  No further awards will be made under the 1992 Stock Option Plan or the 2006 Equity Compensation Plan.

[0001564590-14-001858:notes:67]
We issue restricted stock units (RSUs) to certain officers and key employees of the Company. The RSUs vest over a three-year period from their date of issuance. The fair value of the RSUs is based on the closing price of our common stock as reported on the NASDAQ Global Market (NASDAQ) on the grant dates. Typically, sixty-percent of the actual amount of the RSUs are earned based on the cumulative earnings as reported relative to the three-year performance cycle which begins October 1 of the year granted, and ranges from 0% to 150% of the target RSUs granted and the remaining of the RSUs are time-based and vest over a three-year period. At March 31, 2014, there were 132,282 RSUs outstanding. The RSUs do not have voting rights and the shares of common stock underlying the RSUs are not considered issued and outstanding until actually issued.

[0001564590-14-001858:notes:68]
[same as prior period, unchanged from 0001564590-14-000140:notes:73]

[0001564590-14-001858:notes:69]
|  | Number of |  |  | Weighted |  |
|  | Restricted |  |  | Average |  |
|  | Stock |  |  | Fair Value |  |
|  | Units |  |  | Per Share |  |
| Outstanding at September 30, 2013 |  | 81,555 |  |  | $ | 38.66 |  |
| Granted |  | 57,200 |  |  |  | 60.47 |  |
| Vested |  | (5,973) |  |  |  | 61.79 |  |
| Forfeited |  | (500) |  |  |  | 60.32 |  |
| Outstanding at March 31, 2014 |  | 132,282 |  |  | $ | 46.97 |  |

[0001564590-14-001858:notes:70]
During the six months ended March 31, 2014 and 2013, we recorded compensation expense of $1.5 million and $1.1 million, respectively, related to the RSUs.

[0001564590-14-001858:notes:71]
On February 26, 2014, our stockholders approved and adopted at the Annual Meeting of Stockholders the 2014 Non-Employee Director Equity Incentive Plan (the 2014 Director Plan). Persons eligible to receive awards under the 2014 Director Plan are non-employee directors of the Board.  The 2014 Director Plan authorizes stock options, stock appreciation rights, restricted stock, restricted stock units, as well as certain other awards. We have reserved 150,000 shares of common stock for issuance under the 2014 Director Plan.  No further awards will be made under the Non-Employee Director Restricted Stock Plan or the Non-Employee Director Stock Option Plan.  In February 2014, 16,000 shares of restricted stock were issued to such directors at a price of $66.15 per share under the 2014 Director Plan.  The annual restricted stock grants vest 50% per year over a two-year period on each anniversary of the grant date.

[0001564590-14-001858:notes:72]
During the six months ended March 31, 2014 and 2013, we recorded compensation expense of $0.5 million and $1.1 million, respectively, related to restricted stock grants.


## us-gaap:FairValueDisclosuresTextBlock

[0001564590-14-001858:notes:73]
[same as prior period, unchanged from 0001564590-14-000140:notes:81]

[0001564590-14-001858:notes:74]
[same as prior period, unchanged from 0001564590-14-000140:notes:82]

[0001564590-14-001858:notes:75]
[same as prior period, unchanged from 0001564590-14-000140:notes:83]

[0001564590-14-001858:notes:76]
[same as prior period, unchanged from 0001564590-14-000140:notes:84]

[0001564590-14-001858:notes:77]
[same as prior period, unchanged from 0001564590-14-000140:notes:85]

[0001564590-14-001858:notes:78]
[same as prior period, unchanged from 0001564590-14-000140:notes:86]

[0001564590-14-001858:notes:79]
The following table summarizes the fair value of our assets and liabilities that were accounted for at fair value on a recurring basis as of March 31, 2014 (in thousands):

[0001564590-14-001858:notes:80]
|  | Fair Value Measurements at March 31, 2014 |  |
|  | Quoted Prices in |  |  | Significant Other |  |  |  |  |  |  |  |  |  |
|  | Active Markets for |  |  | Observable |  |  | Significant |  |  |  |  |  |
|  | Identical Assets |  |  | Inputs |  |  | Unobservable Inputs |  |  | Fair Value at |  |
|  | (Level 1) |  |  | (Level 2) |  |  | (Level 3) |  |  | March 31, 2014 |  |
| Assets |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cash equivalents | $ | 10,336 |  |  | $ | — |  |  | $ | — |  |  | $ | 10,336 |  |
| Total | $ | 10,336 |  |  | $ | — |  |  | $ | — |  |  | $ | 10,336 |  |

[0001564590-14-001858:notes:81]
[same as prior period, unchanged from 0001564590-14-000140:notes:89]

[0001564590-14-001858:notes:82]
|  | Fair Value Measurements at September 30, 2013 |  |
|  | Quoted Prices in |  |  | Significant Other |  |  |  |  |  |  |  |  |  |
|  | Active Markets for |  |  | Observable |  |  | Significant |  |  |  |  |  |
|  | Identical Assets |  |  | Inputs |  |  | Unobservable Inputs |  |  | Fair Value at |  |
|  | (Level 1) |  |  | (Level 2) |  |  | (Level 3) |  |  | September 30, 2013 |  |
| Assets |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cash equivalents | $ | 10,531 |  |  | $ | — |  |  | $ | — |  |  | $ | 10,531 |  |
| Total | $ | 10,531 |  |  | $ | — |  |  | $ | — |  |  | $ | 10,531 |  |

[0001564590-14-001858:notes:83]
[same as prior period, unchanged from 0001564590-14-000140:notes:91]

[0001564590-14-001858:notes:84]
[same as prior period, unchanged from 0001564590-14-000140:notes:92]

[0001564590-14-001858:notes:85]
[same as prior period, unchanged from 0001564590-14-000140:notes:93]

[0001564590-14-001858:notes:86]
Industrial Development Revenue Bond – The fair value of our long-term debt depends primarily on the coupon rate of our industrial development revenue bonds.  The carrying value of our long-term debt at March 31, 2014 approximates fair value based on the current coupon rate of the bonds, which is reset weekly, and is classified as a Level 2 input in the fair value measurement hierarchy as there is an active market for the trading of these industrial development revenue bonds.

[0001564590-14-001858:notes:87]
There were no transfers between levels within the fair value measurement hierarchy during the six months ended March 31, 2014.


## us-gaap:DisposalGroupsIncludingDiscontinuedOperationsDisclosureTextBlock

[0001564590-14-001858:notes:88]
[same as prior period, unchanged from 0001564590-14-000140:notes:96]

[0001564590-14-001858:notes:89]
On January 15, 2014, we sold our wholly-owned subsidiary Transdyn to a global provider of electronic toll collection systems, headquartered in Vienna, Austria.  The purchase price from the sale of this subsidiary totaled $16.0 million, of which we received cash of $14.4 million.  The remaining $1.6 million was placed into an escrow account until April 2015, to be released subject to certain contingent obligations, and was recorded to other assets.  We received additional cash of $0.4 million after the final working capital adjustment was calculated in March 2014. We recorded a gain on this transaction of $8.6 million, net of tax, which has been included in income from discontinued operations for the three and six months ended March 31, 2014 in the accompanying condensed consolidated statements of operations.  Transdyn’s results were previously reflected in the Process Control Systems business segment.

[0001564590-14-001858:notes:90]
We reclassified the assets and liabilities of Transdyn as held for sale within the accompanying condensed consolidated balance sheets as of September 30, 2013 and presented the results of these operations as income from discontinued operations, net of tax, for each of the accompanying condensed consolidated statements of operations.

[0001564590-14-001858:notes:91]
[same as prior period, unchanged from 0001564590-14-000140:notes:99]

[0001564590-14-001858:notes:92]
|  | Three Months Ended |  |  | Six Months Ended |  |
|  | March 31, |  |  | March 31, |  |
|  | 2014 |  |  | 2013 |  |  | 2014 |  |  | 2013 |  |
| Revenues | $ | 1,557 |  |  | $ | 7,874 |  |  | $ | 13,923 |  |  | $ | 14,957 |  |
| Income from discontinued operations, net of tax of $131, $334, $633 and $478, respectively |  | 54 |  |  |  | 616 |  |  |  | 1,041 |  |  |  | 881 |  |
| Gain on sale of discontinued operations, net of tax of $5,218, $0, $5,218 and $0, respectively |  | 8,563 |  |  |  | — |  |  |  | 8,563 |  |  |  | — |  |
| Net income from discontinued operations, net of tax | $ | 8,617 |  |  | $ | 616 |  |  | $ | 9,604 |  |  | $ | 881 |  |
| Earnings per share information: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic | $ | 0.72 |  |  | $ | 0.05 |  |  | $ | 0.80 |  |  | $ | 0.07 |  |
| Diluted | $ | 0.71 |  |  | $ | 0.05 |  |  | $ | 0.80 |  |  | $ | 0.07 |  |

[0001564590-14-001858:notes:93]
The following table presents the assets and liabilities of Transdyn as of September 30, 2013 (in thousands):

[0001564590-14-001858:notes:94]
|  | September 30, 2013 |  |
| Current assets: |  |  |  |
| Cash and cash equivalents | $ | 337 |  |
| Accounts receivable |  | 7,346 |  |
| Contracts in progress |  | 7,201 |  |
| Inventories, net |  | 20 |  |
| Prepaid expenses and other current assets |  | 505 |  |
| Current assets held for sale | $ | 15,409 |  |
| Long-term assets: |  |  |  |
| Property, plant and equipment, net | $ | 93 |  |
| Other assets |  | 51 |  |
| Long-term assets held for sale | $ | 144 |  |
| Current liabilities: |  |  |  |
| Accounts payable | $ | 2,973 |  |
| Accrued salaries, bonuses and commissions |  | 1,675 |  |
| Billings in excess of cost |  | 11,867 |  |
| Other accrued expenses and liabilities |  | 1,333 |  |
| Current liabilities held for sale | $ | 17,848 |  |
| Long-term liabilities: |  |  |  |
| Long-term liabilities held for sale | $ | 204 |  |


## us-gaap:IncomeTaxDisclosureTextBlock

[0001564590-14-001858:notes:95]
| J. INCOME TAXES |
|  | The calculation of the effective tax rate is as follows (in thousands): |

[0001564590-14-001858:notes:96]
|  | Three Months Ended |  |  | Six Months Ended |  |
|  | March 31, |  |  | March 31, |  |
|  | 2014 |  |  | 2013 |  |  | 2014 |  |  | 2013 |  |
| Income from continuing operations before income taxes | $ | 11,031 |  |  | $ | 7,959 |  |  | $ | 22,235 |  |  | $ | 18,504 |  |
| Income tax provision |  | 4,055 |  |  |  | 1,757 |  |  |  | 7,992 |  |  |  | 5,182 |  |
| Income from continuing operations | $ | 6,976 |  |  | $ | 6,202 |  |  | $ | 14,243 |  |  | $ | 13,322 |  |
| Effective tax rate |  | 37 | % |  |  | 22 | % |  |  | 36 | % |  |  | 28 | % |

[0001564590-14-001858:notes:97]
Our provision for income taxes for continuing operations was $4.1 million in the second quarter of fiscal year 2014, compared to $1.8 million in the second quarter of fiscal year 2013.  The effective tax rate for the second quarter of fiscal year 2014 was 36.8% which approximates the combined U.S. federal and state statutory rate as the majority of our income is attributable to the U.S. The effective tax rate for the second quarter of fiscal year 2013 was 22.1% and was favorably impacted by the utilization of loss carryforwards on Canadian income.

[0001564590-14-001858:notes:98]
Our provision for income taxes for continuing operations was $8.0 million for the six months ended March 31, 2014, compared to $5.2 million for the six months ended March 31, 2013.  The effective tax rate for six months ended March 31, 2014 was 35.9% which approximates the combined U.S. federal and state statutory rate as the majority of our income is attributable to the U.S.  The effective tax rate for the six months ended March 31, 2013 was 28.0% and was favorably impacted by the utilization of loss carryforwards on Canadian income and the domestic production activities deduction in the United States.
