# POWL 8-K — 0000080420-23-000036 filed 2023-08-01

## item codes, every 8-K on or before 2023-08-02

- 2023-08-01 0000080420-23-000036 — 2.02, 8.01, 9.01
- 2023-05-19 0001193125-23-149334 — 5.07 — amendment of 0000080420-23-000011
- 2023-05-03 0000080420-23-000025 — 2.02, 8.01, 9.01
- 2023-04-06 0000080420-23-000020 — 1.01, 2.03, 9.01
- 2023-04-05 0000080420-23-000018 — 5.02
- 2023-02-16 0000080420-23-000011 — 5.02, 5.07, 9.01
- 2023-01-31 0000080420-23-000004 — 2.02, 8.01
- 2022-12-05 0000080420-22-000034 — 2.02, 9.01
- 2022-08-02 0000080420-22-000030 — 2.02, 8.01, 9.01
- 2022-05-13 0000080420-22-000024 — 5.02, 9.01
- 2022-05-03 0000080420-22-000016 — 2.02, 9.01
- 2022-05-03 0000080420-22-000015 — 8.01, 9.01
- 2022-02-17 0000080420-22-000010 — 5.07
- 2022-02-08 0000080420-22-000005 — 2.02, 9.01
- 2022-02-01 0000080420-22-000002 — 8.01, 9.01
- 2021-12-07 0000080420-21-000043 — 2.02, 9.01
- 2021-08-03 0000080420-21-000036 — 2.02, 8.01, 9.01
- 2021-05-04 0000080420-21-000026 — 2.02, 8.01, 9.01
- 2021-03-16 0001193125-21-082878 — 1.01, 2.03, 9.01
- 2021-03-05 0000080420-21-000021 — 5.02, 8.01, 9.01
- 2021-02-26 0000080420-21-000018 — 5.03
- 2021-02-18 0000080420-21-000016 — 5.07
- 2021-02-02 0000080420-21-000010 — 2.02, 8.01, 9.01
- 2020-12-08 0000080420-20-000032 — 2.02, 9.01
- 2020-11-12 0000080420-20-000030 — 8.01, 9.01
- 2020-08-04 0000080420-20-000024 — 2.02, 8.01, 9.01
- 2020-05-05 0000080420-20-000017 — 2.02, 8.01, 9.01
- 2020-02-21 0000080420-20-000008 — 5.07
- 2020-02-04 0000080420-20-000003 — 2.02, 8.01, 9.01
- 2019-12-04 0001193125-19-306243 — 2.02, 9.01
- 2019-11-08 0000080420-19-000032 — 8.01, 9.01
- 2019-10-03 0000080420-19-000030 — 1.01, 2.03
- 2019-09-24 0000080420-19-000028 — 8.01, 9.01
- 2019-08-06 0000080420-19-000022 — 2.02, 8.01, 9.01
- 2019-05-08 0000080420-19-000017 — 5.02, 9.01
- 2019-05-07 0000080420-19-000011 — 2.02, 8.01, 9.01
- 2019-02-22 0001193125-19-048366 — 5.07
- 2019-02-05 0000080420-19-000003 — 2.02, 8.01
- 2018-12-21 0000080420-18-000038 — 5.02, 9.01
- 2018-12-12 0000080420-18-000031 — 2.02
- 2018-11-05 0000080420-18-000029 — 8.01, 9.01
- 2018-11-01 0000080420-18-000027 — 5.02, 8.01, 9.01
- 2018-10-01 0000080420-18-000024 — 5.02
- 2018-08-07 0000080420-18-000020 — 2.02, 8.01
- 2018-05-15 0000080420-18-000016 — 5.02, 8.01
- 2018-05-09 0000080420-18-000011 — 2.02, 8.01
- 2018-02-22 0000080420-18-000009 — 5.07
- 2018-02-06 0000080420-18-000003 — 2.02, 8.01
- 2017-12-27 0001193125-17-379928 — 5.02
- 2017-12-05 0000080420-17-000028 — 2.02, 9.01
- 2017-11-08 0000080420-17-000024 — 8.01, 9.01
- 2017-11-03 0000080420-17-000022 — 5.02
- 2017-08-09 0000080420-17-000017 — 2.02, 8.01
- 2017-06-30 0000080420-17-000014 — 1.01, 9.01
- 2017-05-03 0000080420-17-000006 — 2.02, 8.01, 9.01
- 2017-02-23 0000080420-17-000004 — 5.07
- 2017-02-08 0001628280-17-000965 — 2.02 — amendment of 0001628280-17-000949
- 2017-02-07 0001628280-17-000949 — 2.01, 8.01, 9.01
- 2016-12-07 0001193125-16-787354 — 2.02, 9.01
- 2016-11-01 0001193125-16-755475 — 8.01, 9.01
- 2016-09-30 0001193125-16-726999 — 5.02, 8.01, 9.01
- 2016-08-03 0001193125-16-669308 — 2.02, 8.01, 9.01
- 2016-05-04 0001193125-16-576528 — 2.02, 8.01, 9.01
- 2016-02-25 0001193125-16-477896 — 5.07
- 2016-02-03 0001193125-16-449052 — 2.02, 8.01, 9.01
- 2015-12-31 0001193125-15-418363 — 5.02, 7.01, 9.01
- 2015-12-02 0001193125-15-393109 — 2.02, 9.01
- 2015-11-05 0001193125-15-368085 — 8.01, 9.01
- 2015-09-25 0001193125-15-329031 — 5.02
- 2015-08-05 0001193125-15-277912 — 2.02, 8.01, 9.01
- 2015-05-06 0001193125-15-174291 — 2.02, 8.01, 9.01
- 2015-03-06 0001193125-15-081070 — 5.02
- 2015-03-02 0001193125-15-072946 — 5.07
- 2015-02-03 0001193125-15-031772 — 2.02, 8.01, 9.01
- 2014-12-18 0001193125-14-446513 — 8.01, 9.01
- 2014-12-03 0001193125-14-431745 — 2.02, 9.01
- 2014-11-05 0001193125-14-397955 — 8.01, 9.01
- 2014-09-26 0001193125-14-353741 — 7.01, 9.01
- 2014-08-05 0001193125-14-296001 — 2.02, 8.01, 9.01
- 2014-05-07 0001193125-14-187496 — 2.02, 8.01, 9.01
- 2014-03-03 0001193125-14-079843 — 5.02, 5.07
- 2014-02-05 0001193125-14-036633 — 2.02, 8.01, 9.01
- 2014-01-17 0001193125-14-014351 — 1.01, 8.01, 9.01
- 2014-01-06 0001193125-14-002795 — 1.01, 2.03
- 2013-12-06 0001564590-13-001411 — 2.02, 9.01
- 2013-12-05 0001564590-13-001406 — 5.02, 8.01, 9.01
- 2013-11-07 0001193125-13-432950 — 8.01, 9.01
- 2013-08-07 0001193125-13-324337 — 2.02, 9.01
- 2013-05-08 0001193125-13-206800 — 2.02, 9.01
- 2013-02-22 0001193125-13-070971 — 5.02, 5.07
- 2013-02-06 0001193125-13-040556 — 2.02, 9.01
- 2012-12-18 0001193125-12-506417 — 5.02, 9.01
- 2012-12-05 0001193125-12-491749 — 2.02, 9.01
- 2012-10-12 0001193125-12-421889 — 3.03, 5.02, 5.03, 9.01
- 2012-08-09 0001193125-12-344617 — 5.02, 8.01, 9.01
- 2012-08-08 0001193125-12-343630 — 2.02, 9.01
- 2012-05-09 0001193125-12-221356 — 2.02, 9.01
- 2012-02-08 0001193125-12-046560 — 2.02, 9.01
- 2011-12-08 0001193125-11-334810 — 2.02, 9.01
- 2011-11-08 0000950123-11-096524 — 2.02, 2.06, 4.02, 9.01
- 2011-10-14 0000950123-11-090124 — 5.02
- 2011-10-06 0000950123-11-088969 — 5.02
- 2011-09-19 0000950123-11-085224 — 5.02, 9.01
- 2011-09-15 0000950123-11-084806 — 5.02, 9.01
- 2011-08-04 0000950123-11-072788 — 2.02, 9.01
- 2011-07-22 0000950123-11-067402 — 5.07
- 2011-05-24 0000950123-11-053550 — 1.01, 2.03, 9.01
- 2011-05-04 0000950123-11-044561 — 2.02, 9.01
- 2011-02-02 0000950123-11-008188 — 2.02, 9.01
- 2010-12-08 0000950123-10-111987 — 2.02, 9.01
- 2010-08-05 0000950123-10-073114 — 2.02, 9.01
- 2010-05-18 0000950123-10-050900 — 5.02
- 2010-05-05 0000950123-10-044499 — 2.02, 9.01
- 2010-02-03 0000950123-10-008278 — 2.02, 9.01
- 2009-12-21 0000950123-09-072269 — 1.01, 2.01, 2.03, 8.01, 9.01
- 2009-12-09 0000950123-09-069525 — 2.02, 9.01
- 2009-10-27 0000950123-09-053501 — 1.01, 8.01, 9.01
- 2009-08-04 0000950123-09-029476 — 2.02, 9.01
- 2009-05-06 0000950129-09-001498 — 2.02, 9.01
- 2009-03-05 0000950129-09-000749 — 1.01, 9.01
- 2009-02-10 0000950129-09-000349 — 2.02, 9.01
- 2008-12-10 0000950134-08-021934 — 2.02, 9.01
- 2008-08-06 0000950129-08-004267 — 2.02, 9.01
- 2008-07-24 0000950129-08-004063 — 1.01, 5.02, 8.01, 9.01
- 2008-06-16 0000950129-08-003500 — 9.01 — amendment of 0000950134-06-015374
- 2008-06-05 0000950129-08-003378 — 5.02, 9.01
- 2008-05-08 0000950129-08-002843 — 2.02, 9.01
- 2008-02-06 0000950129-08-000533 — 2.02, 9.01
- 2007-12-19 0000950129-07-006277 — 1.01, 2.03, 9.01
- 2007-12-06 0000950129-07-006003 — 2.02, 9.01
- 2007-08-21 0000950129-07-004181 — 2.02, 9.01
- 2007-05-31 0000950129-07-002810 — 2.02, 9.01
- 2007-05-21 0000950129-07-002668 — 2.02, 3.01, 4.02, 9.01
- 2007-04-16 0000950129-07-002002 — 2.02, 4.02, 9.01
- 2007-03-01 0000950129-07-001104 — 5.02, 8.01, 9.01
- 2007-02-08 0000950129-07-000451 — 2.02, 9.01
- 2006-12-08 0000950129-06-010041 — 2.02, 9.01
- 2006-09-08 0000950129-06-008379 — 2.02, 9.01
- 2006-08-09 0000950134-06-015374 — 1.01, 2.01, 8.01, 9.01
- 2006-06-08 0000950129-06-006127 — 2.02, 9.01
- 2006-03-09 0000950129-06-002455 — 2.02, 9.01
- 2005-12-16 0000950129-05-012031 — 2.02, 5.03, 9.01
- 2005-09-13 0000950129-05-009181 — 2.01, 9.01 — amendment of 0000950129-05-006889
- 2005-09-12 0000950129-05-009151 — 2.02, 9.01
- 2005-07-06 0000950129-05-006889 — 1.01, 1.02, 2.01, 2.03, 9.01
- 2005-06-10 0000950129-05-006128 — 2.02, 9.01
- 2005-04-20 0000080420-05-000031 — 5.02
- 2005-03-11 0000080420-05-000024 — 9.01
- 2005-02-25 0000080420-05-000018 — 7.01, 9.01
- 2005-01-21 0000080420-05-000009 — 7.01, 9.01
- 2004-12-17 0000080420-04-000049 — 2.02, 9.01
- 2004-11-01 0000080420-04-000045 — 8.01, 9.01
- 2004-10-08 0001169232-04-005133 — 2.05
- 2004-09-14 0000080420-04-000037 — 5.02
- 2004-09-02 0000080420-04-000030 — 2.02, 9.01
- 2004-06-08 0000080420-04-000021 — 7
- 2004-05-13 0000080420-04-000019 — 4
- 2004-02-27 0000080420-04-000013 — 7
- 2003-12-16 0000950129-03-006136 — 12, 7
- 2003-08-29 0000950129-03-004531 — 12, 7
- 2003-06-03 0000950129-03-003035 — 7, 9
- 2003-05-15 0000950129-03-002812 — 7, 9
- 2002-05-29 0000950129-02-002795 — 4
- 2000-12-21 0000950129-00-006093 — 5, 7
- 1998-09-04 0000950129-98-003802 — 5
- 1996-08-09 0000950129-96-001705 — 2, 7

## late-filing notifications on or before 2023-08-02

- 2007-05-11 0000950129-07-002494 — NT 10-Q, for the period ended 2007-03-31
- 2005-01-18 0000080420-05-000004 — NT 10-K, for the period ended 2004-10-31

## item 2.02 — earnings release, exhibit 99.1

[0000080420-23-000036:8k_2_02:1]
EX-99.1
2
ex99-1q32023earningsrelease.htm
EX-99.1

[0000080420-23-000036:8k_2_02:2]
Document

[0000080420-23-000036:8k_2_02:3]
Exhibit 99.1

[0000080420-23-000036:8k_2_02:4]
PRESS RELEASE

[0000080420-23-000036:8k_2_02:5]
For Immediate Release    Contacts:    Michael W. Metcalf, CFO

[0000080420-23-000036:8k_2_02:6]
Powell Industries, Inc.

[0000080420-23-000036:8k_2_02:7]
713-947-4422

[0000080420-23-000036:8k_2_02:8]
Robert Winters or Ryan Coleman

[0000080420-23-000036:8k_2_02:9]
Alpha IR Group

[0000080420-23-000036:8k_2_02:10]
POWL@alpha-ir.com

[0000080420-23-000036:8k_2_02:11]
312-445-2870

[0000080420-23-000036:8k_2_02:12]
POWELL INDUSTRIES ANNOUNCES FISCAL 2023 THIRD QUARTER RESULTS

[0000080420-23-000036:8k_2_02:13]
HOUSTON — August 1, 2023 — Powell Industries, Inc. (NASDAQ: POWL), a leading supplier of custom-engineered solutions for the management, control and distribution of electrical energy, today announced results for the fiscal 2023 third quarter ended June 30, 2023. All comparisons are to the comparable period in the prior fiscal year, unless otherwise noted.

[0000080420-23-000036:8k_2_02:14]
Fiscal Third Quarter Key Highlights:

[0000080420-23-000036:8k_2_02:15]
•Revenues increased 42% to $192 million;

[0000080420-23-000036:8k_2_02:16]
•Backlog(1) nearly tripled to a record $1.3 billion;

[0000080420-23-000036:8k_2_02:17]
•New orders(2) totaled $505 million, an increase of $303 million;

[0000080420-23-000036:8k_2_02:18]
•Gross margin improved 810 basis points to 22.2%;

[0000080420-23-000036:8k_2_02:19]
•Net Income more than doubled to $19 million, or $1.52 per diluted share; and

[0000080420-23-000036:8k_2_02:20]
•Cash and short-term investments as of June 30, 2023 totaled $210 million.

[0000080420-23-000036:8k_2_02:21]
Brett A. Cope, Powell’s Chairman and Chief Executive Officer, stated, “Powell delivered another quarter of financial results that were among the best in our history, as commercial activity across our end markets and our solid project execution are supporting our continued strong performance. We recorded new orders that exceeded $500 million for the second consecutive quarter, which included two greenfield LNG projects on the Gulf Coast that

[0000080420-23-000036:8k_2_02:22]
combined for roughly $200 million. Order activity remains healthy, which has resulted in growing the backlog to $1.3 billion at the end of the period, a 31% increase from the prior quarter, and the highest level in the Company’s history. Although our end markets remain strong, the pace at which our backlog has grown over the last nine months as a result of the large LNG and petrochemical project bookings, will likely be more measured as we navigate through the next several quarters. From a profitability perspective, we remain pleased with our operational execution, increasing our gross margin to 22.2% in the quarter, which is 810 basis points better versus the prior year. Taken altogether, our focused efforts on our strategic initiatives and our outlook for the remainder of fiscal 2023 and into 2024 leave us very confident that the momentum that we have realized throughout this past fiscal year will continue into fiscal 2024.”

[0000080420-23-000036:8k_2_02:23]
Revenues in the third fiscal quarter totaled $192.4 million, an increase of 42% compared to $135.5 million in the prior year and a sequential increase of 12% compared to $171.4 million in the second fiscal quarter.

[0000080420-23-000036:8k_2_02:24]
Gross profit in the quarter totaled $42.7 million, an increase of $23.6 million compared to the prior year and an increase of $9.3 million compared to $33.4 million in the second fiscal quarter. Gross margin in the third quarter was 22.2%, an increase of 810 basis points compared to the prior year and an increase of 270 basis points compared to the second fiscal quarter.

[0000080420-23-000036:8k_2_02:25]
New orders placed in the third quarter totaled $505 million, compared to $202 million in the prior year and $508 million in the second fiscal quarter.

[0000080420-23-000036:8k_2_02:26]
Backlog as of June 30, 2023 was a record $1.3 billion, an increase of 31% compared to $1.0 billion as of March 31, 2023 and an increase of 166% compared to $503 million as of the end of the third fiscal quarter in the prior year.

[0000080420-23-000036:8k_2_02:27]
Net income in the third fiscal quarter more than doubled to $18.5 million, or $1.52 per diluted share, compared to $9.1 million, or $0.76 per diluted share, in the prior year. The prior year period included two non-recurring items that, when combined, accounted for $7.5 million of net income, or $0.63 per diluted share. The net income in the fiscal third quarter also increased compared to net income in the second fiscal quarter of $8.5 million, or $0.70 per diluted share.

[0000080420-23-000036:8k_2_02:28]
Cope added, “The increased volume leverage and strong project execution are helping support the margin growth across the business, while our strategic efforts to diversify our revenue base continues to yield positive results. Revenue from our newer Commercial and Other Industrial sector more than doubled compared to last year to more than $35 million and we remain very pleased with our growth in this sector. We are confident in our ability to execute on our backlog and meet customer expectations through this period of growth. These large projects are core to Powell’s capabilities and expertise and are being booked with realistic lead times that will provide us with visibility into project schedules that stretch into fiscal 2025.”

[0000080420-23-000036:8k_2_02:29]
OUTLOOK

[0000080420-23-000036:8k_2_02:30]
Commenting on the Company's outlook, Michael Metcalf, Powell’s Chief Financial Officer, said, “Looking forward, we anticipate continued strength across most of our core end markets into fiscal 2024. We are encouraged by the progress that has been made on margin accretion through a variety of operational and commercial levers and will remain focused on our operational priorities as we execute our record backlog. While we do recognize the typical project challenges of timing and mix, we are well positioned and confident in our ability to effectively execute for our customers.  Considering our current backlog and sustained level of market activity, as well as the strength of our balance sheet and liquidity position, we anticipate that these variables will continue to support the momentum of the business as we close out fiscal 2023 and look forward to fiscal 2024.”

[0000080420-23-000036:8k_2_02:31]
CONFERENCE CALL

[0000080420-23-000036:8k_2_02:32]
Powell Industries has scheduled a conference call for Wednesday, August 2, 2023, at 11:00 a.m. Eastern time.   To participate in the conference call, dial 1-833-953-2431 (domestic) or 1-412-317-5760 (international) and ask for the Powell Industries conference call.  A telephonic replay of the conference call will be available through August 9, 2023 and may be accessed by calling 1-877-344-7529 (domestic) or 1-412-317-0088 (international) and using passcode 8673999#.

[0000080420-23-000036:8k_2_02:33]
Investors, analysts and the general public will also have the opportunity to listen to the conference call over the Internet by visiting powellind.com. To listen to the live call on the web, please visit the website at least 15 minutes before the call begins to register, download and install

[0000080420-23-000036:8k_2_02:34]
3

[0000080420-23-000036:8k_2_02:35]
any necessary audio software.  For those who cannot listen to the live webcast, an archive will be available shortly after the call and will remain available for approximately 90 days at powellind.com.

[0000080420-23-000036:8k_2_02:36]
Powell Industries, Inc., headquartered in Houston, designs, manufactures and services custom-engineered equipment and systems for the distribution, control and monitoring of electrical energy.  Powell markets include large industrial customers such as utilities, oil and gas producers, refineries, liquefied natural gas facilities, petrochemical plants, pulp and paper producers, mining operations and commuter railways.   For more information, please visit powellind.com.

[0000080420-23-000036:8k_2_02:37]
POWELL INDUSTRIES, INC. & SUBSIDIARIES

[0000080420-23-000036:8k_2_02:38]
CONDENSED CONSOLIDATED STATEMENT OF OPERATIONS

[0000080420-23-000036:8k_2_02:39]
|  | Three Months Ended June 30, |  | Nine Months Ended June 30, |
|  | 2023 |  | 2022 |  | 2023 |  | 2022 |
| (In thousands, except per share data) |  |  |  |  |  |  |  |
|  | (Unaudited) |
| Revenues | $ | 192,365 |  |  | $ | 135,483 |  |  | $ | 490,667 |  |  | $ | 369,907 |  |
| Cost of goods sold | 149,695 |  |  | 116,424 |  |  | 395,096 |  |  | 318,329 |  |
| Gross profit | 42,670 |  | 19,059 |  | 95,571 |  | 51,578 |
| Selling, general and administrative expenses | 19,691 |  |  | 16,404 |  |  | 58,384 |  |  | 49,374 |  |
| Research and development expenses | 1,427 |  |  | 1,806 |  |  | 4,471 |  |  | 5,342 |  |
| Operating income (loss) | 21,552 |  |  | 849 |  |  | 32,716 |  |  | (3,138) |  |
| Other income | — |  |  | (2,006) |  |  | — |  |  | (2,285) |  |
| Interest income, net | (2,093) |  |  | (63) |  |  | (3,516) |  |  | (79) |  |
| Income (loss) before income taxes | 23,645 |  |  | 2,918 |  |  | 36,232 |  |  | (774) |  |
| Income tax provision (benefit) | 5,191 |  |  | (6,143) |  |  | 8,142 |  |  | (5,772) |  |
| Net income | $ | 18,454 |  |  | $ | 9,061 |  |  | $ | 28,090 |  |  | $ | 4,998 |  |
| Earnings per share: |  |  |  |  |  |  |  |
| Basic | $ | 1.55 |  |  | $ | 0.77 |  |  | $ | 2.37 |  |  | $ | 0.42 |  |
| Diluted | $ | 1.52 |  |  | $ | 0.76 |  |  | $ | 2.32 |  |  | $ | 0.42 |  |
| Weighted average shares: |  |  |  |  |  |  |  |
| Basic | 11,889 |  |  | 11,810 |  |  | 11,876 |  |  | 11,792 |  |
| Diluted | 12,140 |  |  | 11,901 |  |  | 12,106 |  |  | 11,877 |  |
| SELECTED FINANCIAL DATA: |  |  |  |  |  |  |  |
| Depreciation | $ | 2,188 |  |  | $ | 2,375 |  |  | $ | 6,500 |  |  | $ | 7,206 |  |
| Capital Expenditures | $ | 650 |  |  | $ | 649 |  |  | $ | 4,006 |  |  | $ | 1,765 |  |
| Dividends Paid | $ | 3,112 |  |  | $ | 3,064 |  |  | $ | 9,292 |  |  | $ | 9,170 |  |

[0000080420-23-000036:8k_2_02:40]
5

[0000080420-23-000036:8k_2_02:41]
POWELL INDUSTRIES, INC. & SUBSIDIARIES

[0000080420-23-000036:8k_2_02:42]
CONDENSED CONSOLIDATED BALANCE SHEETS

[0000080420-23-000036:8k_2_02:43]
|  | June 30, 2023 |  | September 30, 2022 |
| (In thousands) |  |  |  |
|  | (Unaudited) |
| Assets: |  |  |  |
| Cash, cash equivalents and short-term investments | $ | 209,769 |  |  | $ | 116,508 |  |
| Other current assets | 337,483 |  |  | 253,475 |  |
| Property, plant and equipment, net | 96,876 |  |  | 98,628 |  |
| Long-term assets | 26,970 |  |  | 24,769 |  |
| Total assets | $ | 671,098 |  |  | $ | 493,380 |  |
| Liabilities and equity: |  |  |  |
| Current liabilities | $ | 334,996 |  |  | $ | 186,373 |  |
| Deferred and other long-term liabilities | 12,032 |  | 9,801 |
| Stockholders’ equity | 324,070 |  |  | 297,206 |  |
| Total liabilities and stockholders’ equity | $ | 671,098 |  |  | $ | 493,380 |  |
| SELECTED FINANCIAL DATA: |  |  |  |
| Working capital | $ | 212,256 |  |  | $ | 183,610 |  |

[0000080420-23-000036:8k_2_02:44]
(1)    The amounts recorded in backlog may not be a reliable indicator of our future operating results and may not be indicative of continuing revenue performance over future fiscal quarters or years primarily due to unexpected contract adjustments, cancellations or scope reductions.

[0000080420-23-000036:8k_2_02:45]
(2)     New orders (bookings) represent the estimated value of contracts added to existing backlog (unsatisfied performance obligations).
