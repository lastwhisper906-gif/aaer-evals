# POWL note change history — 0000080420-23-000027 → 0000080420-23-000038


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2023-08-02):
[0000080420-23-000038:note_history:1]
Certain customers require us to post letters of credit, bank guarantees or surety bonds. These security instruments assure that we will perform under the terms of our contract. In the event of default, the counterparty may demand payment from the bank under a letter of credit or bank guarantee, or performance by the surety under a bond. To date, there have been no significant draws or claims related to security instruments for the periods reported. We were contingently liable for letters of credit of $49.0 million as of June 30, 2023. We also had surety bonds totaling $357.5 million that were outstanding, with additional bonding capacity of $342.5 million available, at June 30, 2023. We have strong surety relationships; however, a change in market conditions or the sureties' assessment of our financial position could cause the sureties to require cash collateralization for undischarged liabilities under the bonds.
  (was, 2023-05-03, similarity 0.9901):
[0000080420-23-000027:note_history:1]
Certain customers require us to post letters of credit, bank guarantees or surety bonds. These security instruments assure that we will perform under the terms of our contract. In the event of default, the counterparty may demand payment from the bank under a letter of credit or bank guarantee, or performance by the surety under a bond. To date, there have been no significant draws or claims related to security instruments for the periods reported. We were contingently liable for letters of credit of $44.8 million as of March 31, 2023. We also had surety bonds totaling $294.2 million that were outstanding, with additional bonding capacity of $305.8 million available, at March 31, 2023. We have strong surety relationships; however, a change in market conditions or the sureties' assessment of our financial position could cause the sureties to require cash collateralization for undischarged liabilities under the bonds.

- changed (2023-08-02):
[0000080420-23-000038:note_history:2]
We have a $10.1 million facility agreement (Facility Agreement) between Powell (UK) Limited and a large international bank that provides Powell (UK) Limited the ability to enter into bank guarantees as well as forward exchange contracts and currency options. At June 30, 2023, we had outstanding guarantees totaling $8.2 million. The Facility Agreement provides for customary events of default and carries cross-default provisions with our Second Amendment. If an event of default (as defined in the Facility Agreement) occurs and is continuing, per the terms and subject to the conditions set forth therein, obligations outstanding under the Facility Agreement may be accelerated and declared immediately due and payable. Additionally, we are required to maintain cash collateral for guarantees greater than two years. As of June 30, 2023, we were in compliance with all of the financial covenants of the Facility Agreement.
  (was, 2023-05-03, similarity 0.9901):
[0000080420-23-000027:note_history:2]
We have a $9.9 million facility agreement (Facility Agreement) between Powell (UK) Limited and a large international bank that provides Powell (UK) Limited the ability to enter into bank guarantees as well as forward exchange contracts and currency options. At March 31, 2023, we had outstanding guarantees totaling $7.7 million. The Facility Agreement provides for customary events of default and carries cross-default provisions with our Second Amendment. If an event of default (as defined in the Facility Agreement) occurs and is continuing, per the terms and subject to the conditions set forth therein, obligations outstanding under the Facility Agreement may be accelerated and declared immediately due and payable. Additionally, we are required to maintain cash collateral for guarantees greater than two years. As of March 31, 2023, we were in compliance with all of the financial covenants of the Facility Agreement.


## us-gaap:LongTermDebtTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2023-08-02):
[0000080420-23-000038:note_history:3]
On March 31, 2023, we entered into a second amendment (the Second Amendment) to our credit agreement with Bank of America, N.A. (as amended, the U.S. Revolver). The Second Amendment increased the revolving credit facility extended to us under the U.S. Revolver, which is available for both borrowings and letters of credit and expires September 27, 2024, from $75.0 million to $125.0 million. As amended by the Second Amendment, the U.S. Revolver states that the lesser of $50 million or 50% of readily and available cash may be deducted from the amount of letters of credit outstanding (not to be less than zero) when calculating the consolidated funded indebtedness, which is a component of the consolidated net leverage ratio. We have the option to cash collateralize all or a portion of the letters of credit outstanding, which would favorably impact the consolidated funded indebtedness calculation and the consolidated net leverage ratio. As of June 30, 2023, there were no amounts borrowed under the U.S. Revolver, and letters of credit outstanding were $49.0 million. There was $76.0 million available for the issuance of letters of credit and borrowings under the U.S. Revolver as of June 30, 2023.
  (was, 2023-05-03, similarity 0.9889):
[0000080420-23-000027:note_history:3]
On March 31, 2023, we entered into a second amendment (the Second Amendment) to our credit agreement with Bank of America, N.A. (as amended, the U.S. Revolver). The Second Amendment increased the revolving credit facility extended to us under the U.S. Revolver, which is available for both borrowings and letters of credit and expires September 27, 2024, from $75.0 million to $125.0 million. As amended by the Second Amendment, the U.S. Revolver states that the lesser of $50 million or 50% of readily and available cash may be deducted from the amount of letters of credit outstanding (not to be less than zero) when calculating the consolidated funded indebtedness, which is a component of the consolidated net leverage ratio. We have the option to cash collateralize all or a portion of the letters of credit outstanding, which would favorably impact the consolidated funded indebtedness calculation and the consolidated net leverage ratio. As of March 31, 2023, there were no amounts borrowed under the U.S. Revolver, and letters of credit outstanding were $44.8 million. There was $80.2 million available for the issuance of letters of credit and borrowings under the U.S. Revolver as of March 31, 2023.

- changed (2023-08-02):
[0000080420-23-000038:note_history:4]
We are required to maintain certain financial covenants, the most significant of which are a consolidated net leverage ratio less than 3.0 to 1.0 and a consolidated interest coverage ratio of greater than 3.0 to 1.0. Our most restrictive covenant, the consolidated net leverage ratio, is the ratio of earnings before interest, taxes, depreciation, amortization and stock-based compensation (EBITDAS) to funded indebtedness. An increase in indebtedness, which includes letters of credit, or a decrease in EBITDAS could restrict our ability to issue letters of credit or borrow under the U.S. Revolver. Additionally, we must maintain a consolidated cash balance of $50 million at all times, which can be deducted from the letters of credit outstanding as noted above. The U.S. Revolver also contains a "material adverse effect" clause which is a material change in our operations, business, properties, liabilities or condition (financial or otherwise) or a material impairment of our ability to perform our obligations under our credit agreements. As of June 30, 2023, we were in compliance with all of the financial covenants of the U.S. Revolver.
  (was, 2023-05-03, similarity 0.996):
[0000080420-23-000027:note_history:4]
We are required to maintain certain financial covenants, the most significant of which are a consolidated net leverage ratio less than 3.0 to 1.0 and a consolidated interest coverage ratio of greater than 3.0 to 1.0. Our most restrictive covenant, the consolidated net leverage ratio, is the ratio of earnings before interest, taxes, depreciation, amortization and stock-based compensation (EBITDAS) to funded indebtedness. An increase in indebtedness, which includes letters of credit, or a decrease in EBITDAS could restrict our ability to issue letters of credit or borrow under the U.S. Revolver. Additionally, we must maintain a consolidated cash balance of $50 million at all times, which can be deducted from the letters of credit outstanding as noted above. The U.S. Revolver also contains a "material adverse effect" clause which is a material change in our operations, business, properties, liabilities or condition (financial or otherwise) or a material impairment of our ability to perform our obligations under our credit agreements. As of March 31, 2023, we were in compliance with all of the financial covenants of the U.S. Revolver.


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2023-08-02):
[0000080420-23-000038:note_history:5]
The following tables present our disaggregated revenue by geographic destination and market sector for the three and nine months ended June 30, 2023 and 2022 (in thousands):
  (was, 2023-05-03, similarity 0.9576):
[0000080420-23-000027:note_history:5]
The following tables present our disaggregated revenue by geographic destination and market sector for the three and six months ended March 31, 2023 and 2022 (in thousands):

- changed (2023-08-02):
[0000080420-23-000038:note_history:6]
|  | Three months ended June 30, |  | Nine months ended June 30, |
|  | 2023 |  | 2022 |  | 2023 |  | 2022 |
| United States | $ | 153,258 |  |  | $ | 102,931 |  |  | $ | 387,531 |  |  | $ | 272,069 |  |
| Canada | 21,765 |  |  | 23,599 |  |  | 62,255 |  |  | 60,777 |  |
| Europe, Middle East and Africa | 12,004 |  |  | 6,697 |  |  | 30,521 |  |  | 30,078 |  |
| Asia/Pacific | 2,338 |  |  | 1,645 |  |  | 4,903 |  |  | 4,235 |  |
| Mexico, Central and South America | 3,000 |  |  | 611 |  |  | 5,457 |  |  | 2,748 |  |
| Total revenues by geographic destination | $ | 192,365 |  |  | $ | 135,483 |  |  | $ | 490,667 |  |  | $ | 369,907 |  |
  (was, 2023-05-03, similarity 0.9276):
[0000080420-23-000027:note_history:6]
|  | Three months ended March 31, |  | Six months ended March 31, |
|  | 2023 |  | 2022 |  | 2023 |  | 2022 |
| United States | $ | 134,161 |  |  | $ | 86,992 |  |  | $ | 234,273 |  |  | $ | 169,137 |  |
| Canada | 21,995 |  |  | 22,053 |  |  | 40,491 |  |  | 37,178 |  |
| Europe, Middle East and Africa | 11,957 |  |  | 15,551 |  |  | 18,516 |  |  | 23,381 |  |
| Asia/Pacific | 1,788 |  |  | 1,646 |  |  | 2,564 |  |  | 2,590 |  |
| Mexico, Central and South America | 1,543 |  |  | 1,612 |  |  | 2,458 |  |  | 2,137 |  |
| Total revenues by geographic destination | $ | 171,444 |  |  | $ | 127,854 |  |  | $ | 298,302 |  |  | $ | 234,423 |  |

- added (2023-08-02):
[0000080420-23-000038:note_history:7]
|  | Three months ended June 30, |  | Nine months ended June 30, |
|  | 2023 |  | 2022 |  | 2023 |  | 2022 |
| Oil and gas (excludes petrochemical) | $ | 73,452 |  |  | $ | 58,669 |  |  | $ | 179,560 |  |  | $ | 155,324 |  |
| Petrochemical | 21,995 |  |  | 15,187 |  |  | 70,372 |  |  | 51,268 |  |
| Electric utility | 43,824 |  |  | 30,173 |  |  | 114,899 |  |  | 82,079 |  |
| Commercial and other industrial | 35,527 |  |  | 14,966 |  |  | 74,846 |  |  | 30,583 |  |
| Traction power | 7,143 |  |  | 9,775 |  |  | 21,532 |  |  | 31,200 |  |
| All others | 10,424 |  |  | 6,713 |  |  | 29,458 |  |  | 19,453 |  |
| Total revenues by market sector | $ | 192,365 |  |  | $ | 135,483 |  |  | $ | 490,667 |  |  | $ | 369,907 |  |

- removed (2023-08-02):
[0000080420-23-000027:note_history:8]
|  | Three months ended March 31, |  | Six months ended March 31, |
|  | 2023 |  | 2022 |  | 2023 |  | 2022 |
| Oil and gas (excludes petrochemical) | $ | 62,597 |  |  | $ | 53,634 |  |  | $ | 106,107 |  |  | $ | 96,655 |  |
| Petrochemical | 25,887 |  |  | 18,853 |  |  | 48,377 |  |  | 36,081 |  |
| Electric utility | 42,668 |  |  | 30,374 |  |  | 71,075 |  |  | 51,907 |  |
| Traction power | 7,317 |  |  | 10,054 |  |  | 14,389 |  |  | 21,426 |  |
| Commercial and other industrial | 22,270 |  |  | 5,785 |  |  | 39,320 |  |  | 15,618 |  |
| All others | 10,705 |  |  | 9,154 |  |  | 19,034 |  |  | 12,736 |  |
| Total revenues by market sector | $ | 171,444 |  |  | $ | 127,854 |  |  | $ | 298,302 |  |  | $ | 234,423 |  |


## us-gaap:RevenueFromContractWithCustomerPolicyTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2023-08-02):
[0000080420-23-000038:note_history:9]
Our revenues are primarily generated from the manufacturing of custom-engineered products and systems under long-term fixed-price contracts under which we agree to manufacture various products such as traditional and arc-resistant distribution switchgear and control gear, medium-voltage circuit breakers, monitoring and control communications systems, motor control centers, switches and bus duct systems. These products may be sold separately as an engineered solution but are typically integrated into custom-built enclosures which we also build. These enclosures are referred to as power control room substations
  (was, 2023-05-03, similarity 0.7454):
[0000080420-23-000027:note_history:9]
Our revenues are primarily generated from the manufacturing of custom-engineered products and systems under long-term fixed-price contracts under which we agree to manufacture various products such as traditional and arc-resistant distribution switchgear and control gear, medium-voltage circuit breakers, monitoring and control communications systems, motor control

- added (2023-08-02):
[0000080420-23-000038:note_history:10]
(PCRs®), custom-engineered modules or electrical houses (E-Houses). Some contracts may also include the installation and the commissioning of these enclosures.

- changed (2023-08-02):
[0000080420-23-000038:note_history:11]
We also have contracts to provide field service inspection, installation, commissioning, modification, and repair services, as well as retrofit and retrofill components for existing systems. If the service contract terms give us the right to invoice the customer for an amount that corresponds directly with the value of our performance completed to date (i.e., a service contract in which we bill a fixed amount for each hour of service provided), then we recognize revenue over time in each reporting period corresponding to the amount with which we have the right to invoice. Our performance obligations are satisfied as the work progresses. Revenues from our custom-engineered products and value-added services transferred to customers over time accounted for approximately 94% and 93% of total revenues for the three and nine months ended June 30, 2023, respectively, and 94% of total revenues for the three and nine months ended June 30, 2022.
  (was, 2023-05-03, similarity 0.8966):
[0000080420-23-000027:note_history:11]
We also have contracts to provide field service inspection, installation, commissioning, modification, and repair services, as well as retrofit and retrofill components for existing systems. If the service contract terms give us the right to invoice the customer for an amount that corresponds directly with the value of our performance completed to date (i.e., a service contract in which we bill a fixed amount for each hour of service provided), then we recognize revenue over time in each reporting period corresponding to the amount with which we have the right to invoice. Our performance obligations are satisfied as the work progresses. Revenues from our custom-engineered products and value-added services transferred to customers over time accounted for approximately 93% of total revenues for the three and six months ended March 31, 2023 and 94% of total revenues for the three and six months ended March 31, 2022.

- changed (2023-08-02):
[0000080420-23-000038:note_history:12]
We also have sales orders for spare parts and replacement circuit breakers for switchgear that are obsolete or that are no longer produced by the original manufacturer. Revenues from these sales orders are recognized at the time we fulfill our performance obligation to the customer, which is typically upon shipment and represented approximately 6% and 7% of total revenues for the three and nine months ended June 30, 2023, respectively, and 6% of total revenues for the three and nine months ended June 30, 2022.
  (was, 2023-05-03, similarity 0.798):
[0000080420-23-000027:note_history:12]
We also have sales orders for spare parts and replacement circuit breakers for switchgear that are obsolete or that are no longer produced by the original manufacturer. Revenues from these sales orders are recognized at the time we fulfill our performance obligation to the customer, which is typically upon shipment and represented approximately 7% of total revenues for the three and six months ended March 31, 2023 and 6% of total revenues for the three and six months ended March 31, 2022.

- removed (2023-08-02):
[0000080420-23-000027:note_history:13]
centers, switches and bus duct systems. These products may be sold separately as an engineered solution but are typically integrated into custom-built enclosures which we also build. These enclosures are referred to as power control room substations (PCRs®), custom-engineered modules or electrical houses (E-Houses). Some contracts may also include the installation and the commissioning of these enclosures.


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2023-08-02):
[0000080420-23-000038:note_history:14]
Our revenues are primarily generated from the manufacturing of custom-engineered products and systems under long-term fixed-price contracts under which we agree to manufacture various products such as traditional and arc-resistant distribution switchgear and control gear, medium-voltage circuit breakers, monitoring and control communications systems, motor control centers, switches and bus duct systems. These products may be sold separately as an engineered solution but are typically integrated into custom-built enclosures which we also build. These enclosures are referred to as power control room substations
  (was, 2023-05-03, similarity 0.7454):
[0000080420-23-000027:note_history:14]
Our revenues are primarily generated from the manufacturing of custom-engineered products and systems under long-term fixed-price contracts under which we agree to manufacture various products such as traditional and arc-resistant distribution switchgear and control gear, medium-voltage circuit breakers, monitoring and control communications systems, motor control

- added (2023-08-02):
[0000080420-23-000038:note_history:15]
(PCRs®), custom-engineered modules or electrical houses (E-Houses). Some contracts may also include the installation and the commissioning of these enclosures.

- changed (2023-08-02):
[0000080420-23-000038:note_history:16]
We also have contracts to provide field service inspection, installation, commissioning, modification, and repair services, as well as retrofit and retrofill components for existing systems. If the service contract terms give us the right to invoice the customer for an amount that corresponds directly with the value of our performance completed to date (i.e., a service contract in which we bill a fixed amount for each hour of service provided), then we recognize revenue over time in each reporting period corresponding to the amount with which we have the right to invoice. Our performance obligations are satisfied as the work progresses. Revenues from our custom-engineered products and value-added services transferred to customers over time accounted for approximately 94% and 93% of total revenues for the three and nine months ended June 30, 2023, respectively, and 94% of total revenues for the three and nine months ended June 30, 2022.
  (was, 2023-05-03, similarity 0.8966):
[0000080420-23-000027:note_history:16]
We also have contracts to provide field service inspection, installation, commissioning, modification, and repair services, as well as retrofit and retrofill components for existing systems. If the service contract terms give us the right to invoice the customer for an amount that corresponds directly with the value of our performance completed to date (i.e., a service contract in which we bill a fixed amount for each hour of service provided), then we recognize revenue over time in each reporting period corresponding to the amount with which we have the right to invoice. Our performance obligations are satisfied as the work progresses. Revenues from our custom-engineered products and value-added services transferred to customers over time accounted for approximately 93% of total revenues for the three and six months ended March 31, 2023 and 94% of total revenues for the three and six months ended March 31, 2022.

- changed (2023-08-02):
[0000080420-23-000038:note_history:17]
We also have sales orders for spare parts and replacement circuit breakers for switchgear that are obsolete or that are no longer produced by the original manufacturer. Revenues from these sales orders are recognized at the time we fulfill our performance obligation to the customer, which is typically upon shipment and represented approximately 6% and 7% of total revenues for the three and nine months ended June 30, 2023, respectively, and 6% of total revenues for the three and nine months ended June 30, 2022.
  (was, 2023-05-03, similarity 0.798):
[0000080420-23-000027:note_history:17]
We also have sales orders for spare parts and replacement circuit breakers for switchgear that are obsolete or that are no longer produced by the original manufacturer. Revenues from these sales orders are recognized at the time we fulfill our performance obligation to the customer, which is typically upon shipment and represented approximately 7% of total revenues for the three and six months ended March 31, 2023 and 6% of total revenues for the three and six months ended March 31, 2022.

- changed (2023-08-02):
[0000080420-23-000038:note_history:18]
Remaining unsatisfied performance obligations, which we refer to as backlog, represent the estimated transaction price for goods and services for which we have a material right, but work has not been performed. As of June 30, 2023, we had backlog of $1.3 billion, of which approximately $690 million is expected to be recognized as revenue within the next twelve months. Backlog may not be indicative of future operating results as orders may be cancelled or modified by our customers. Our backlog does not include service and maintenance-type contracts for which we have the right to invoice as services are performed.
  (was, 2023-05-03, similarity 0.9926):
[0000080420-23-000027:note_history:18]
Remaining unsatisfied performance obligations, which we refer to as backlog, represent the estimated transaction price for goods and services for which we have a material right, but work has not been performed. As of March 31, 2023, we had backlog of $1.0 billion, of which approximately $584.4 million is expected to be recognized as revenue within the next twelve months. Backlog may not be indicative of future operating results as orders may be cancelled or modified by our customers. Our backlog does not include service and maintenance-type contracts for which we have the right to invoice as services are performed.

- changed (2023-08-02):
[0000080420-23-000038:note_history:19]
Actual revenues and project costs may vary from previous estimates due to changes in a variety of factors. The cost estimation process is based upon the professional knowledge and experience of our engineers, project managers and financial professionals. Factors that are considered in estimating the work to be completed and ultimate contract recovery include the
  (was, 2023-05-03, similarity 0.7927):
[0000080420-23-000027:note_history:19]
Actual revenues and project costs may vary from previous estimates due to changes in a variety of factors. The cost estimation process is based upon the professional knowledge and experience of our engineers, project managers and financial

- changed (2023-08-02):
[0000080420-23-000038:note_history:20]
availability and productivity of labor, the nature and complexity of the work to be performed, the availability of materials, and the effect of any delays on our project performance. We periodically review our job performance, job conditions, estimated profitability and final contract settlements, including our estimate of total costs and make revisions to costs and income in the period in which the revisions are probable and reasonably estimable. We bear the risk of cost overruns in most of our contracts, which may result in reduced profits. Whenever revisions of estimated contract costs and contract values indicate that the contract costs will exceed estimated revenues, thus creating a loss, a provision for the total estimated loss is recorded in that period.
  (was, 2023-05-03, similarity 0.925):
[0000080420-23-000027:note_history:20]
professionals. Factors that are considered in estimating the work to be completed and ultimate contract recovery include the availability and productivity of labor, the nature and complexity of the work to be performed, the availability of materials, and the effect of any delays on our project performance. We periodically review our job performance, job conditions, estimated profitability and final contract settlements, including our estimate of total costs and make revisions to costs and income in the period in which the revisions are probable and reasonably estimable. We bear the risk of cost overruns in most of our contracts, which may result in reduced profits. Whenever revisions of estimated contract costs and contract values indicate that the contract costs will exceed estimated revenues, thus creating a loss, a provision for the total estimated loss is recorded in that period.

- changed (2023-08-02):
[0000080420-23-000038:note_history:21]
For the nine months ended June 30, 2023 and 2022, our operating results were positively impacted by $13.2 million and $5.9 million, respectively, as a result of net changes in contract estimates related to projects in progress at the beginning of the respective period. These changes in estimates resulted primarily from favorable project execution, reduced cost estimates and negotiations of variable consideration, discussed below, as well as revenue recognized from project cancellations and other changes in facts and circumstances during these periods. Project cancellations on two projects increased gross profit for the nine months ended June 30, 2023 by $3.4 million. Gross unfavorable changes in contract estimates were immaterial for both the nine months ended June 30, 2023 and 2022.
  (was, 2023-05-03, similarity 0.7101):
[0000080420-23-000027:note_history:21]
For the six months ended March 31, 2023 and 2022, our operating results were positively impacted by $7.4 million and $5.6 million, respectively, as a result of net changes in contract estimates related to projects in progress at the beginning of the respective period. These changes in estimates resulted primarily from favorable project execution and negotiations of variable consideration, discussed below, as well as revenue and reduced costs recognized from project cancellations and other changes in facts and circumstances during these periods. Gross unfavorable changes in contract estimates were immaterial for both the six months ended March 31, 2023 and 2022.

- changed (2023-08-02):
[0000080420-23-000038:note_history:22]
Contract assets and liabilities as of June 30, 2023 and September 30, 2022 are summarized below (in thousands):
  (was, 2023-05-03, similarity 0.9557):
[0000080420-23-000027:note_history:22]
Contract assets and liabilities as of March 31, 2023 and September 30, 2022 are summarized below (in thousands):

- changed (2023-08-02):
[0000080420-23-000038:note_history:23]
|  | June 30, 2023 |  | September 30, 2022 |
| Contract assets | $ | 56,148 |  |  | $ | 88,351 |  |
| Contract liabilities | (225,767) |  |  | (79,857) |  |
| Net contract asset (liability) | $ | (169,619) |  |  | $ | 8,494 |  |
  (was, 2023-05-03, similarity 0.9745):
[0000080420-23-000027:note_history:23]
|  | March 31, 2023 |  | September 30, 2022 |
| Contract assets | $ | 63,560 |  |  | $ | 88,351 |  |
| Contract liabilities | (178,217) |  |  | (79,857) |  |
| Net contract asset (liability) | $ | (114,657) |  |  | $ | 8,494 |  |

- changed (2023-08-02):
[0000080420-23-000038:note_history:24]
Our net contract billing position improved to a net liability at June 30, 2023 from a net asset position at September 30, 2022 primarily due to favorable contract billing milestones. We typically allocate a significant percentage of the progress billing to the early stages of the contract. These favorable billing milestones along with our increase in project backlog are driving the
  (was, 2023-05-03, similarity 0.988):
[0000080420-23-000027:note_history:24]
Our net contract billing position improved to a net liability at March 31, 2023 from a net asset position at September 30, 2022 primarily due to favorable contract billing milestones. We typically allocate a significant percentage of the progress billing to the early stages of the contract. These favorable billing milestones along with our increase in project backlog are driving the

- changed (2023-08-02):
[0000080420-23-000038:note_history:25]
increase in the net contract liability at June 30, 2023. To determine the amount of revenue recognized during the period from contract liabilities, we first allocate revenue to the individual contract liability balance outstanding at the beginning of the period until the revenue exceeds that balance. During the nine months ended June 30, 2023, we recognized revenue of $68.1 million that was related to contract liabilities outstanding at September 30, 2022.
  (was, 2023-05-03, similarity 0.925):
[0000080420-23-000027:note_history:25]
increase in the net contract liability at March 31, 2023. To determine the amount of revenue recognized during the period from contract liabilities, we first allocate revenue to the individual contract liability balance outstanding at the beginning of the period until the revenue exceeds that balance. During the six months ended March 31, 2023, we recognized revenue of approximately $58.7 million that was related to contract liabilities outstanding at September 30, 2022.

- changed (2023-08-02):
[0000080420-23-000038:note_history:26]
The timing of our invoice process is typically dependent on the completion of certain milestones and contract terms and subject to agreement by our customer. Payment is typically expected within 30 days of invoice. Any uncollected invoiced amounts for our performance obligations recognized over time, including contract retentions, are recorded as accounts receivable in the Condensed Consolidated Balance Sheets. Certain contracts allow customers to withhold a small percentage of billings pursuant to retainage provisions, and such amounts are generally due upon completion of the contract and acceptance of the project by the customer. Based on our experience in recent years, the majority of these retainage balances are expected to be collected within approximately twelve months. As of June 30, 2023 and September 30, 2022, accounts receivable included retention amounts of $7.0 million and $6.9 million, respectively. Of the retained amount at June 30, 2023, $6.8 million is expected to be collected in the next twelve months and is recorded in accounts receivable. The remaining $0.2 million is recorded in other assets.
  (was, 2023-05-03, similarity 0.9918):
[0000080420-23-000027:note_history:26]
The timing of our invoice process is typically dependent on the completion of certain milestones and contract terms and subject to agreement by our customer. Payment is typically expected within 30 days of invoice. Any uncollected invoiced amounts for our performance obligations recognized over time, including contract retentions, are recorded as accounts receivable in the Condensed Consolidated Balance Sheets. Certain contracts allow customers to withhold a small percentage of billings pursuant to retainage provisions, and such amounts are generally due upon completion of the contract and acceptance of the project by the customer. Based on our experience in recent years, the majority of these retainage balances are expected to be collected within approximately twelve months. As of March 31, 2023 and September 30, 2022, accounts receivable included retention amounts of $6.6 million and $6.9 million, respectively. Of the retained amount at March 31, 2023, $6.4 million is expected to be collected in the next twelve months and is recorded in accounts receivable. The remaining $0.2 million is recorded in other assets.

- changed (2023-08-02):
[0000080420-23-000038:note_history:27]
The following tables present our disaggregated revenue by geographic destination and market sector for the three and nine months ended June 30, 2023 and 2022 (in thousands):
  (was, 2023-05-03, similarity 0.9576):
[0000080420-23-000027:note_history:27]
The following tables present our disaggregated revenue by geographic destination and market sector for the three and six months ended March 31, 2023 and 2022 (in thousands):

- changed (2023-08-02):
[0000080420-23-000038:note_history:28]
|  | Three months ended June 30, |  | Nine months ended June 30, |
|  | 2023 |  | 2022 |  | 2023 |  | 2022 |
| United States | $ | 153,258 |  |  | $ | 102,931 |  |  | $ | 387,531 |  |  | $ | 272,069 |  |
| Canada | 21,765 |  |  | 23,599 |  |  | 62,255 |  |  | 60,777 |  |
| Europe, Middle East and Africa | 12,004 |  |  | 6,697 |  |  | 30,521 |  |  | 30,078 |  |
| Asia/Pacific | 2,338 |  |  | 1,645 |  |  | 4,903 |  |  | 4,235 |  |
| Mexico, Central and South America | 3,000 |  |  | 611 |  |  | 5,457 |  |  | 2,748 |  |
| Total revenues by geographic destination | $ | 192,365 |  |  | $ | 135,483 |  |  | $ | 490,667 |  |  | $ | 369,907 |  |
  (was, 2023-05-03, similarity 0.9276):
[0000080420-23-000027:note_history:28]
|  | Three months ended March 31, |  | Six months ended March 31, |
|  | 2023 |  | 2022 |  | 2023 |  | 2022 |
| United States | $ | 134,161 |  |  | $ | 86,992 |  |  | $ | 234,273 |  |  | $ | 169,137 |  |
| Canada | 21,995 |  |  | 22,053 |  |  | 40,491 |  |  | 37,178 |  |
| Europe, Middle East and Africa | 11,957 |  |  | 15,551 |  |  | 18,516 |  |  | 23,381 |  |
| Asia/Pacific | 1,788 |  |  | 1,646 |  |  | 2,564 |  |  | 2,590 |  |
| Mexico, Central and South America | 1,543 |  |  | 1,612 |  |  | 2,458 |  |  | 2,137 |  |
| Total revenues by geographic destination | $ | 171,444 |  |  | $ | 127,854 |  |  | $ | 298,302 |  |  | $ | 234,423 |  |

- added (2023-08-02):
[0000080420-23-000038:note_history:29]
|  | Three months ended June 30, |  | Nine months ended June 30, |
|  | 2023 |  | 2022 |  | 2023 |  | 2022 |
| Oil and gas (excludes petrochemical) | $ | 73,452 |  |  | $ | 58,669 |  |  | $ | 179,560 |  |  | $ | 155,324 |  |
| Petrochemical | 21,995 |  |  | 15,187 |  |  | 70,372 |  |  | 51,268 |  |
| Electric utility | 43,824 |  |  | 30,173 |  |  | 114,899 |  |  | 82,079 |  |
| Commercial and other industrial | 35,527 |  |  | 14,966 |  |  | 74,846 |  |  | 30,583 |  |
| Traction power | 7,143 |  |  | 9,775 |  |  | 21,532 |  |  | 31,200 |  |
| All others | 10,424 |  |  | 6,713 |  |  | 29,458 |  |  | 19,453 |  |
| Total revenues by market sector | $ | 192,365 |  |  | $ | 135,483 |  |  | $ | 490,667 |  |  | $ | 369,907 |  |

- removed (2023-08-02):
[0000080420-23-000027:note_history:30]
centers, switches and bus duct systems. These products may be sold separately as an engineered solution but are typically integrated into custom-built enclosures which we also build. These enclosures are referred to as power control room substations (PCRs®), custom-engineered modules or electrical houses (E-Houses). Some contracts may also include the installation and the commissioning of these enclosures.

- removed (2023-08-02):
[0000080420-23-000027:note_history:31]
|  | Three months ended March 31, |  | Six months ended March 31, |
|  | 2023 |  | 2022 |  | 2023 |  | 2022 |
| Oil and gas (excludes petrochemical) | $ | 62,597 |  |  | $ | 53,634 |  |  | $ | 106,107 |  |  | $ | 96,655 |  |
| Petrochemical | 25,887 |  |  | 18,853 |  |  | 48,377 |  |  | 36,081 |  |
| Electric utility | 42,668 |  |  | 30,374 |  |  | 71,075 |  |  | 51,907 |  |
| Traction power | 7,317 |  |  | 10,054 |  |  | 14,389 |  |  | 21,426 |  |
| Commercial and other industrial | 22,270 |  |  | 5,785 |  |  | 39,320 |  |  | 15,618 |  |
| All others | 10,705 |  |  | 9,154 |  |  | 19,034 |  |  | 12,736 |  |
| Total revenues by market sector | $ | 171,444 |  |  | $ | 127,854 |  |  | $ | 298,302 |  |  | $ | 234,423 |  |


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: tag_name, score: 1.0

- changed (2023-08-02):
[0000080420-23-000038:note_history:32]
On August 1, 2023, our Board of Directors declared a quarterly cash dividend on our common stock in the amount of $0.2625 per share. The dividend is payable on September 20, 2023 to shareholders of record at the close of business on August 16, 2023.
  (was, 2023-05-03, similarity 0.6517):
[0000080420-23-000027:note_history:32]
On May 2, 2023, our Board of Directors declared a quarterly cash dividend on our common stock in the amount of $0.2625 per share. The dividend is payable on June 14, 2023 to shareholders of record at the close of business on May 17, 2023.
