# POWL MD&A — 0000080420-23-000038


## mdna

[0000080420-23-000038:mdna:1]
[same as prior period, unchanged from 0000080420-23-000027:mdna:1]

[0000080420-23-000038:mdna:2]
[same as prior period, unchanged from 0000080420-23-000027:mdna:2]

[0000080420-23-000038:mdna:3]
[same as prior period, unchanged from 0000080420-23-000027:mdna:3]

[0000080420-23-000038:mdna:4]
[same as prior period, unchanged from 0000080420-23-000027:mdna:4]

[0000080420-23-000038:mdna:5]
[same as prior period, unchanged from 0000080420-23-000027:mdna:5]

[0000080420-23-000038:mdna:6]
[same as prior period, unchanged from 0000080420-23-000027:mdna:6]

[0000080420-23-000038:mdna:7]
One element of our strategic focus is to strengthen our project portfolio beyond our core oil, gas and petrochemical end market sectors. Over the past year these efforts have contributed to a record backlog of projects coming into Fiscal 2023. There has been an increase in the planning and capital funding within North America as the market responds to the increased international demand for LNG and gas to chemical processes utilizing low cost gas feedstocks. As a result, the business has been awarded a number of large LNG and petrochemical contracts that have had a positive impact on our backlog. Additionally, diversification efforts outside of our core oil, gas and petrochemical end markets have resulted in an increase in backlog across the utility and commercial and other industrial sectors as well.

[0000080420-23-000038:mdna:8]
Various factors resulting in global economic uncertainty negatively impacted our results over the past two years. Uncertainty and demand disruptions resulted in considerable volatility across commodity markets. We experienced supply chain disruptions driven predominately by availability and cost volatility across our raw materials, components and labor force. All of these factors contributed to the lower margins realized in Fiscal 2022 relative to prior oil and gas cycles. As we continue to address supply chain challenges, we are working with our suppliers of key components and commodities to meet our customer commitments. Additionally, we have adjusted our pricing models with our customers in response to the increased cost environment which has made a positive impact on our gross margins in Fiscal 2023.

[0000080420-23-000038:mdna:9]
[same as prior period, unchanged from 0000080420-23-000027:mdna:9]

[0000080420-23-000038:mdna:10]
Quarter Ended June 30, 2023 Compared to the Quarter Ended June 30, 2022 (Unaudited)

[0000080420-23-000038:mdna:11]
[same as prior period, unchanged from 0000080420-23-000027:mdna:11]

[0000080420-23-000038:mdna:12]
Revenues increased by 42%, or $56.9 million, to $192.4 million in the third quarter of Fiscal 2023, primarily driven by the increase in project backlog. Domestic revenues increased by 49%, or $50.3 million, to $153.3 million in the third quarter of Fiscal 2023. International revenues increased by 20%, or $6.6 million, to $39.1 million in the third quarter of Fiscal 2023. Our international revenues include both revenues generated from our international facilities as well as revenues from export projects generated at our domestic facilities.

[0000080420-23-000038:mdna:13]
Revenue from our core oil and gas markets (excluding petrochemical) increased by 25%, or $14.8 million, to $73.5 million in the third quarter of Fiscal 2023, while petrochemical revenue increased by 45%, or $6.8 million, to $22.0 million in the third quarter of Fiscal 2023. Revenue from our utility markets increased by 45%, or $13.7 million, to $43.8 million in the third quarter of Fiscal 2023. Commercial and other industrial market revenue increased by 137%, or $20.6 million, to $35.6 million, driven by an increase in traditionally non-core markets such as data centers, university projects and other miscellaneous applications. Revenue from all other markets combined increased by 55%, or $3.7 million, to $10.4 million in the third quarter of Fiscal 2023. These increases in revenue were driven by improved market conditions and our strategic effort to diversify our business. Revenue from our traction market decreased by 27%, or $2.6 million, to $7.1 million in the third quarter of Fiscal 2023.

[0000080420-23-000038:mdna:14]
Gross profit increased by 124%, or $23.6 million, to $42.7 million for the third quarter of Fiscal 2023.  Gross profit as a percentage of revenues increased to 22% in the third quarter of Fiscal 2023, compared to 14% in the third quarter of Fiscal 2022. The increase in gross profit was directly attributable to volume leverage and factory efficiencies as a result of the increase in volume, project execution, as well as effectively managing inflationary pressures while maintaining pricing models to correspond to current cost levels. Gross profit for the third quarter of Fiscal 2023 also benefited from a project cancellation of $1.7 million.

[0000080420-23-000038:mdna:15]
[same as prior period, unchanged from 0000080420-23-000027:mdna:15]

[0000080420-23-000038:mdna:16]
Selling, general and administrative expenses increased by 20%, or $3.3 million, to $19.7 million in the third quarter of Fiscal 2023, primarily due to $2.3 million of increased variable incentive compensation resulting from improved earnings. Selling, general and administrative expenses as a percentage of revenues decreased to 10% during the third quarter of Fiscal 2023 compared to 12% during the third quarter of Fiscal 2022 as we were able to leverage our existing cost structure.

[0000080420-23-000038:mdna:17]
[same as prior period, unchanged from 0000080420-23-000027:mdna:30]

[0000080420-23-000038:mdna:18]
We recorded other income of $2.0 million in the third quarter of Fiscal 2022 related to a gain on the sale of a non-core, industrial valve repair and servicing business within our Canadian operations. We did not record other income during the third quarter of Fiscal 2023.

[0000080420-23-000038:mdna:19]
Income Tax Provision/Benefit

[0000080420-23-000038:mdna:20]
We recorded an income tax provision of $5.2 million in the third quarter of Fiscal 2023, compared to an income tax benefit of $6.1 million in the third quarter of Fiscal 2022. The effective tax rate for the third quarter of Fiscal 2023 was 22%, compared to an effective tax rate of negative 211% for the third quarter of Fiscal 2022. For the three months ended June 30, 2023, the effective tax rate was favorably impacted by the estimated Research and Development Tax Credit (R&D Tax Credit), in addition to the projected utilization of net operating loss carryforwards in the UK that have been fully reserved with a valuation allowance. These benefits were offset by state income tax expense, certain nondeductible expenses and an income inclusion related to U.S. global intangible income. For the three months ended June 30, 2022, the tax benefit primarily resulted from the release of the valuation allowance recorded against the Canadian net deferred tax assets in the amount of $5.9 million that was partially offset by the tax expense of $0.4 million related to the gain on the disposition of a small, non-core division of our Canadian operations.

[0000080420-23-000038:mdna:21]
Net Income

[0000080420-23-000038:mdna:22]
In the third quarter of Fiscal 2023, we recorded net income of $18.5 million, or $1.52 per diluted share, compared to net income of $9.1 million, or $0.76 per diluted share, in the third quarter of Fiscal 2022. This increase in net income was primarily due to the increase in bookings over the last 18 months which has led to an increase in revenues coupled with increased project margins.

[0000080420-23-000038:mdna:23]
[same as prior period, unchanged from 0000080420-23-000027:mdna:21]

[0000080420-23-000038:mdna:24]
The order backlog at June 30, 2023 was $1.3 billion, an increase of 31% from $1.0 billion at March 31, 2023 and an increase of 166% from $502.5 million at June 30, 2022. Bookings, net of cancellations and scope reductions, increased by 151% in the third quarter of Fiscal 2023 to $505.4 million, compared to $201.5 million in the third quarter of Fiscal 2022, primarily driven by continued strength from our core oil, gas and petrochemical markets, including several large LNG and petrochemical projects.

[0000080420-23-000038:mdna:25]
Nine Months Ended June 30, 2023 Compared to Nine Months Ended June 30, 2022 (Unaudited)

[0000080420-23-000038:mdna:26]
[same as prior period, unchanged from 0000080420-23-000027:mdna:24]

[0000080420-23-000038:mdna:27]
Revenues increased by 33%, or $120.8 million, to $490.7 million in the nine months ended June 30, 2023. Domestic revenues increased by 42%, or $115.5 million, to $387.6 million in the nine months ended June 30, 2023. International revenues increased by 5%, or $5.3 million, to $103.1 million. Our international revenues include both revenues generated from our international facilities as well as revenues from export projects generated at our domestic facilities.

[0000080420-23-000038:mdna:28]
Revenues from our core oil and gas markets (excluding petrochemical) increased by 16%, or $24.2 million, to $179.6 million in the nine months ended June 30, 2023, while petrochemical revenue increased by 37%, or $19.1 million, to $70.4 million in the first nine months of Fiscal 2023. Revenue from our utility markets increased by 40%, or $32.8 million, to $114.9 million in the nine months ended June 30, 2023. Commercial and other industrial market revenue increased by 145%, or $44.3 million, to $74.8 million, and revenues from all other markets combined increased by 51%, or $10.0 million, to $29.5 million in the first nine months of Fiscal 2023. Revenue from our traction market decreased by 31%, or $9.7 million, to $21.5 million in the nine months ended June 30, 2023.

[0000080420-23-000038:mdna:29]
Gross profit increased by 85%, or $44.0 million, to $95.6 million in the nine months ended June 30, 2023 as compared to the first nine months of Fiscal 2022. Gross profit as a percentage of revenues increased to 19% in the first nine months of Fiscal 2023 as compared to 14% in the nine months ended June 30, 2022. The increase in gross profit was directly attributable to volume leverage and factory efficiencies as a result of the increase in volume, project execution, as well as effectively managing inflationary pressures while maintaining pricing models to correspond to current cost levels. Gross profit for the nine months ended June 30, 2023 also benefited from project cancellations of $3.4 million.

[0000080420-23-000038:mdna:30]
[same as prior period, unchanged from 0000080420-23-000027:mdna:28]

[0000080420-23-000038:mdna:31]
Selling, general and administrative expenses increased by 18%, or $9.0 million, to $58.4 million in the nine months ended June 30, 2023, primarily due to $4.3 million of increased variable incentive compensation resulting from improved earnings. Selling, general and administrative expenses as a percentage of revenues decreased to 12% during the nine months ended June 30, 2023 compared to 13% during the nine months ended June 30, 2022.

[0000080420-23-000038:mdna:32]
Other Income

[0000080420-23-000038:mdna:33]
We recorded other income of $2.3 million in the nine months ended June 30, 2022 related to a gain on the sale of a non-core, industrial valve repair and servicing business within our Canadian operations as well as the sale of an excess parcel of land in the U.S. We did not record other income during the nine months ended June 30, 2023.

[0000080420-23-000038:mdna:34]
Income Tax Provision/Benefit

[0000080420-23-000038:mdna:35]
We recorded an income tax provision of $8.1 million in the nine months ended June 30, 2023, compared to an income tax benefit of $5.8 million in the nine months ended June 30, 2022. The effective tax rate for the nine months ended June 30, 2023 was 22%, compared to an effective tax rate of 746% for the nine months ended June 30, 2022. For the nine months ended June 30, 2023, the effective tax rate was favorably impacted by the estimated R&D Tax Credit, in addition to the projected utilization of net operating loss carryforwards in the UK that have been fully reserved with a valuation allowance. These benefits were offset by state income tax expense, certain nondeductible expenses and an income inclusion related to U.S. global intangible income. For the nine months ended June 30, 2022, the tax benefit primarily resulted from the release of the valuation allowance recorded against the Canadian net deferred tax assets in the amount of $5.9 million that was partially offset by the tax expense of $0.4 million related to the gain on the disposition of a small, non-core division of our Canadian operations.

[0000080420-23-000038:mdna:36]
Net Income

[0000080420-23-000038:mdna:37]
In the nine months ended June 30, 2023, we recorded net income of $28.1 million, or $2.32 per diluted share, compared to net income of $5.0 million, or $0.42 per diluted share, in the nine months ended June 30, 2022. This increase in net income was primarily due to the increase in bookings over the last 18 months which has led to an increase in revenues coupled with increased project margins.

[0000080420-23-000038:mdna:38]
[same as prior period, unchanged from 0000080420-23-000027:mdna:36]

[0000080420-23-000038:mdna:39]
The order backlog at June 30, 2023 was $1.3 billion, an increase of 126% from $592.2 million at September 30, 2022. Bookings, net of cancellations and scope reductions, increased by 166% during the nine months ended June 30, 2023 to $1.2 billion, compared to $460.0 million during the nine months ended June 30, 2022. The significant year-over-year increase was primarily driven by continued strength from our core oil, gas and petrochemical markets, including several large LNG and petrochemical projects.

[0000080420-23-000038:mdna:40]
[same as prior period, unchanged from 0000080420-23-000027:mdna:38]

[0000080420-23-000038:mdna:41]
Recently we have seen a cyclical recovery across our core oil, gas and petrochemical markets combined with increased global demand for cleaner-burning fuels as well as related processes utilizing lower cost gas feedstocks. Our order activity in most of our core markets has been strong and includes several large LNG and petrochemical projects. This elevalted project activity has increased our backlog to over $1.3 billion, which is the highest level in Powell's history. Diversification efforts outside of our core oil, gas and petrochemical end markets have also been a positive catalyst, helping to drive the increase in backlog. This strong backlog of projects, which incorporates pricing initiatives in response to persistent inflationary pressures, should continue to support strong revenue throughout the remainder of 2023 and into 2024. Approximately $690 million of the backlog is expected to be recognized as revenue within the next twelve months. We do not anticipate our backlog will continue to grow at the same pace as we have recognized in the last nine months, which included several large LNG and petrochemical projects.

[0000080420-23-000038:mdna:42]
Our operating results are impacted by factors such as the timing of new order awards, project backlog, changes in project cost estimates, customer approval of final engineering and design specifications and delays in customer construction schedules, all of which contribute to short-term earnings variability and the timing of project execution. Our operating results also have been, and may continue to be, impacted by the timing and resolution of change orders, project close-out and resolution of potential contract claims and liquidated damages, all of which could improve or deteriorate gross margins during the period in which these items are resolved with our customers. Disruption in the global supply chain has, in the past, negatively impacted our business and operating results as well due to the reduction in availability and uncertainty in the timing of the receipt of certain key component parts and commodities. These factors may result in periods of underutilization of our resources and facilities, which may negatively impact our ability to cover our fixed costs, or inhibit our ability to deliver completed products on time. We will continue to remain focused on the variables that impact our markets as well as cost management, labor availability and supply chain challenges. We will also continue to adjust to global conditions in order to maintain competitiveness in the markets that we serve.

[0000080420-23-000038:mdna:43]
[same as prior period, unchanged from 0000080420-23-000027:mdna:41]

[0000080420-23-000038:mdna:44]
As of June 30, 2023, current assets exceeded current liabilities by 1.6 times.

[0000080420-23-000038:mdna:45]
Cash, cash equivalents and short-term investments increased to $209.8 million at June 30, 2023, compared to $116.5 million at September 30, 2022. This increase in cash was primarily driven by increased project volume and the favorable timing of contract billing milestones on some of our large projects. We typically allocate a significant percentage of the progress billing to the early stages of the contract. These favorable billing milestones along with our increase in project backlog are the primary drivers for our increase in cash at June 30, 2023. We believe that our strong working capital position, available borrowings under our credit facility and available cash should be sufficient to finance future operating activities, capital improvements and research and development initiatives for the foreseeable future.

[0000080420-23-000038:mdna:46]
On March 31, 2023, we entered into a second amendment (the Second Amendment) to our credit agreement with Bank of America, N.A. (as amended, the U.S. Revolver). The Second Amendment increased the revolving credit facility extended to us under the U.S. Revolver, which is available for both borrowings and letters of credit and expires September 27, 2024, from $75.0 million to $125.0 million. As amended by the Second Amendment, the U.S. Revolver states the lesser of $50 million or 50% of readily and available cash may be deducted from the amount of letters of credit outstanding (not to be less than zero)

[0000080420-23-000038:mdna:47]
when calculating the consolidated funded indebtedness, which is a component of the consolidated net leverage ratio. We have the option to cash collateralize all or a portion of the letters of credit outstanding, which would favorably impact the consolidated funded indebtedness calculation and the consolidated net leverage ratio.

[0000080420-23-000038:mdna:48]
As of June 30, 2023, there were no amounts borrowed under the U.S Revolver, and letters of credit outstanding were $49.0 million. As of June 30, 2023, $76.0 million was available for the issuance of letters of credit and borrowing under the U.S. Revolver. We are required to maintain certain financial covenants, the most significant of which are a consolidated net leverage ratio of less than 3.0 to 1.0 and a consolidated interest coverage ratio of greater than 3.0 to 1.0. Our most restrictive covenant, the consolidated net leverage ratio, is the ratio of earnings before interest, taxes, depreciation, amortization and stock-based compensation (EBITDAS) to funded indebtedness, which includes letters of credit. An increase in indebtedness or a decrease in EBITDAS could restrict our ability to issue letters of credit or borrow under the U.S. Revolver. For further information regarding our debt, see Notes E and F of Notes to Condensed Consolidated Financial Statements.

[0000080420-23-000038:mdna:49]
Approximately $44.3 million of our cash, cash equivalents and short-term investments at June 30, 2023 was held outside of the U.S. for our international operations. It is our intention to indefinitely reinvest all current and future foreign earnings internationally in order to ensure sufficient working capital to support our international operations. In the event that we elect to repatriate some or all of the foreign earnings that were previously deemed to be indefinitely reinvested outside the U.S., we may incur additional tax expense upon such repatriation under current tax laws.

[0000080420-23-000038:mdna:50]
[same as prior period, unchanged from 0000080420-23-000027:mdna:47]

[0000080420-23-000038:mdna:51]
Operating activities provided net cash of $105.3 million during the nine months ended June 30, 2023 and used net cash of $27.8 million during the same period in Fiscal 2022. Cash flow from operations is primarily influenced by the timing of milestone payments from our customers, project volume and the associated working capital requirements, as well as payment terms with our suppliers. This increase in operating cash flow was primarily due to the favorable timing of contract billing milestones resulting in increased cash flow as our backlog of projects has increased (as noted above).

[0000080420-23-000038:mdna:52]
[same as prior period, unchanged from 0000080420-23-000027:mdna:49]

[0000080420-23-000038:mdna:53]
Investing activities used $15.4 million during the nine months ended June 30, 2023 and used less than $0.1 million during the same period in Fiscal 2022. The increase in cash used in investing activities in the first nine months of Fiscal 2023 is primarily due to short-term investment activity.

[0000080420-23-000038:mdna:54]
[same as prior period, unchanged from 0000080420-23-000027:mdna:51]

[0000080420-23-000038:mdna:55]
Net cash used in financing activities was $9.9 million during the nine months ended June 30, 2023 and $10.2 million during the same period in Fiscal 2022, which primarily consisted of approximately $9 million of dividends paid in each period.

[0000080420-23-000038:mdna:56]
[same as prior period, unchanged from 0000080420-23-000027:mdna:53]

[0000080420-23-000038:mdna:57]
[same as prior period, unchanged from 0000080420-23-000027:mdna:54]

[0000080420-23-000038:mdna:58]
[same as prior period, unchanged from 0000080420-23-000027:mdna:55]
