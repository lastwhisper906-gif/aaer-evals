# POWL notes — 0000080420-23-000038


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureAndSignificantAccountingPoliciesTextBlock

[0000080420-23-000038:notes:1]
[same as prior period, unchanged from 0000080420-23-000027:notes:1]

[0000080420-23-000038:notes:2]
[same as prior period, unchanged from 0000080420-23-000027:notes:2]

[0000080420-23-000038:notes:3]
[same as prior period, unchanged from 0000080420-23-000027:notes:3]

[0000080420-23-000038:notes:4]
[same as prior period, unchanged from 0000080420-23-000027:notes:4]

[0000080420-23-000038:notes:5]
[same as prior period, unchanged from 0000080420-23-000027:notes:5]

[0000080420-23-000038:notes:6]
[same as prior period, unchanged from 0000080420-23-000027:notes:6]

[0000080420-23-000038:notes:7]
[same as prior period, unchanged from 0000080420-23-000027:notes:7]

[0000080420-23-000038:notes:8]
[same as prior period, unchanged from 0000080420-23-000027:notes:8]

[0000080420-23-000038:notes:9]
[same as prior period, unchanged from 0000080420-23-000027:notes:9]


## us-gaap:EarningsPerShareTextBlock

[0000080420-23-000038:notes:10]
[same as prior period, unchanged from 0000080420-23-000027:notes:10]

[0000080420-23-000038:notes:11]
[same as prior period, unchanged from 0000080420-23-000027:notes:11]

[0000080420-23-000038:notes:12]
|  | Three months ended June 30, |  | Nine months ended June 30, |
|  | 2023 |  | 2022 |  | 2023 |  | 2022 |
| Numerator: |  |  |  |  |  |  |  |
| Net income | $ | 18,454 |  |  | $ | 9,061 |  |  | $ | 28,090 |  |  | $ | 4,998 |  |
| Denominator: |  |  |  |  |  |  |  |
| Weighted average basic shares | 11,889 |  |  | 11,810 |  |  | 11,876 |  |  | 11,792 |  |
| Dilutive effect of restricted stock units | 251 |  |  | 91 |  |  | 230 |  |  | 85 |  |
| Weighted average diluted shares | 12,140 |  |  | 11,901 |  |  | 12,106 |  |  | 11,877 |  |
| Earnings per share: |  |  |  |  |  |  |  |
| Basic | $ | 1.55 |  |  | $ | 0.77 |  |  | $ | 2.37 |  |  | $ | 0.42 |  |
| Diluted | $ | 1.52 |  |  | $ | 0.76 |  |  | $ | 2.32 |  |  | $ | 0.42 |  |


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0000080420-23-000038:notes:13]
[same as prior period, unchanged from 0000080420-23-000027:notes:14]

[0000080420-23-000038:notes:14]
[same as prior period, unchanged from 0000080420-23-000027:notes:15]

[0000080420-23-000038:notes:15]
|  | June 30, 2023 |  | September 30, 2022 |
| Raw materials, parts and sub-assemblies, net | $ | 64,960 |  |  | $ | 49,213 |  |
| Work-in-progress | 1,149 |  |  | 1,202 |  |
| Total inventories | $ | 66,109 |  |  | $ | 50,415 |  |

[0000080420-23-000038:notes:16]
[same as prior period, unchanged from 0000080420-23-000027:notes:17]

[0000080420-23-000038:notes:17]
[same as prior period, unchanged from 0000080420-23-000027:notes:18]

[0000080420-23-000038:notes:18]
|  | Three months ended June 30, |  | Nine months ended June 30, |
|  | 2023 |  | 2022 |  | 2023 |  | 2022 |
| Balance at beginning of period | $ | 2,711 |  |  | $ | 2,347 |  |  | $ | 2,345 |  |  | $ | 2,531 |  |
| Increase to warranty expense | 1,241 |  |  | 462 |  |  | 2,931 |  |  | 1,077 |  |
| Deduction for warranty charges | (760) |  |  | (499) |  |  | (2,095) |  |  | (1,303) |  |
| Change due to foreign currency translation | 10 |  |  | (22) |  |  | 21 |  |  | (17) |  |
| Balance at end of period | $ | 3,202 |  |  | $ | 2,288 |  |  | $ | 3,202 |  |  | $ | 2,288 |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0000080420-23-000038:notes:19]
[same as prior period, unchanged from 0000080420-23-000027:notes:20]

[0000080420-23-000038:notes:20]
Our revenues are primarily generated from the manufacturing of custom-engineered products and systems under long-term fixed-price contracts under which we agree to manufacture various products such as traditional and arc-resistant distribution switchgear and control gear, medium-voltage circuit breakers, monitoring and control communications systems, motor control centers, switches and bus duct systems. These products may be sold separately as an engineered solution but are typically integrated into custom-built enclosures which we also build. These enclosures are referred to as power control room substations

[0000080420-23-000038:notes:21]
(PCRs®), custom-engineered modules or electrical houses (E-Houses). Some contracts may also include the installation and the commissioning of these enclosures.

[0000080420-23-000038:notes:22]
[same as prior period, unchanged from 0000080420-23-000027:notes:23]

[0000080420-23-000038:notes:23]
We also have contracts to provide field service inspection, installation, commissioning, modification, and repair services, as well as retrofit and retrofill components for existing systems. If the service contract terms give us the right to invoice the customer for an amount that corresponds directly with the value of our performance completed to date (i.e., a service contract in which we bill a fixed amount for each hour of service provided), then we recognize revenue over time in each reporting period corresponding to the amount with which we have the right to invoice. Our performance obligations are satisfied as the work progresses. Revenues from our custom-engineered products and value-added services transferred to customers over time accounted for approximately 94% and 93% of total revenues for the three and nine months ended June 30, 2023, respectively, and 94% of total revenues for the three and nine months ended June 30, 2022.

[0000080420-23-000038:notes:24]
We also have sales orders for spare parts and replacement circuit breakers for switchgear that are obsolete or that are no longer produced by the original manufacturer. Revenues from these sales orders are recognized at the time we fulfill our performance obligation to the customer, which is typically upon shipment and represented approximately 6% and 7% of total revenues for the three and nine months ended June 30, 2023, respectively, and 6% of total revenues for the three and nine months ended June 30, 2022.

[0000080420-23-000038:notes:25]
[same as prior period, unchanged from 0000080420-23-000027:notes:26]

[0000080420-23-000038:notes:26]
[same as prior period, unchanged from 0000080420-23-000027:notes:27]

[0000080420-23-000038:notes:27]
[same as prior period, unchanged from 0000080420-23-000027:notes:28]

[0000080420-23-000038:notes:28]
[same as prior period, unchanged from 0000080420-23-000027:notes:29]

[0000080420-23-000038:notes:29]
Remaining unsatisfied performance obligations, which we refer to as backlog, represent the estimated transaction price for goods and services for which we have a material right, but work has not been performed. As of June 30, 2023, we had backlog of $1.3 billion, of which approximately $690 million is expected to be recognized as revenue within the next twelve months. Backlog may not be indicative of future operating results as orders may be cancelled or modified by our customers. Our backlog does not include service and maintenance-type contracts for which we have the right to invoice as services are performed.

[0000080420-23-000038:notes:30]
[same as prior period, unchanged from 0000080420-23-000027:notes:31]

[0000080420-23-000038:notes:31]
Actual revenues and project costs may vary from previous estimates due to changes in a variety of factors. The cost estimation process is based upon the professional knowledge and experience of our engineers, project managers and financial professionals. Factors that are considered in estimating the work to be completed and ultimate contract recovery include the

[0000080420-23-000038:notes:32]
availability and productivity of labor, the nature and complexity of the work to be performed, the availability of materials, and the effect of any delays on our project performance. We periodically review our job performance, job conditions, estimated profitability and final contract settlements, including our estimate of total costs and make revisions to costs and income in the period in which the revisions are probable and reasonably estimable. We bear the risk of cost overruns in most of our contracts, which may result in reduced profits. Whenever revisions of estimated contract costs and contract values indicate that the contract costs will exceed estimated revenues, thus creating a loss, a provision for the total estimated loss is recorded in that period.

[0000080420-23-000038:notes:33]
For the nine months ended June 30, 2023 and 2022, our operating results were positively impacted by $13.2 million and $5.9 million, respectively, as a result of net changes in contract estimates related to projects in progress at the beginning of the respective period. These changes in estimates resulted primarily from favorable project execution, reduced cost estimates and negotiations of variable consideration, discussed below, as well as revenue recognized from project cancellations and other changes in facts and circumstances during these periods. Project cancellations on two projects increased gross profit for the nine months ended June 30, 2023 by $3.4 million. Gross unfavorable changes in contract estimates were immaterial for both the nine months ended June 30, 2023 and 2022.

[0000080420-23-000038:notes:34]
[same as prior period, unchanged from 0000080420-23-000027:notes:35]

[0000080420-23-000038:notes:35]
[same as prior period, unchanged from 0000080420-23-000027:notes:36]

[0000080420-23-000038:notes:36]
[same as prior period, unchanged from 0000080420-23-000027:notes:37]

[0000080420-23-000038:notes:37]
[same as prior period, unchanged from 0000080420-23-000027:notes:38]

[0000080420-23-000038:notes:38]
[same as prior period, unchanged from 0000080420-23-000027:notes:39]

[0000080420-23-000038:notes:39]
[same as prior period, unchanged from 0000080420-23-000027:notes:40]

[0000080420-23-000038:notes:40]
[same as prior period, unchanged from 0000080420-23-000027:notes:41]

[0000080420-23-000038:notes:41]
[same as prior period, unchanged from 0000080420-23-000027:notes:42]

[0000080420-23-000038:notes:42]
[same as prior period, unchanged from 0000080420-23-000027:notes:43]

[0000080420-23-000038:notes:43]
Contract assets and liabilities as of June 30, 2023 and September 30, 2022 are summarized below (in thousands):

[0000080420-23-000038:notes:44]
|  | June 30, 2023 |  | September 30, 2022 |
| Contract assets | $ | 56,148 |  |  | $ | 88,351 |  |
| Contract liabilities | (225,767) |  |  | (79,857) |  |
| Net contract asset (liability) | $ | (169,619) |  |  | $ | 8,494 |  |

[0000080420-23-000038:notes:45]
Our net contract billing position improved to a net liability at June 30, 2023 from a net asset position at September 30, 2022 primarily due to favorable contract billing milestones. We typically allocate a significant percentage of the progress billing to the early stages of the contract. These favorable billing milestones along with our increase in project backlog are driving the

[0000080420-23-000038:notes:46]
increase in the net contract liability at June 30, 2023. To determine the amount of revenue recognized during the period from contract liabilities, we first allocate revenue to the individual contract liability balance outstanding at the beginning of the period until the revenue exceeds that balance. During the nine months ended June 30, 2023, we recognized revenue of $68.1 million that was related to contract liabilities outstanding at September 30, 2022.

[0000080420-23-000038:notes:47]
The timing of our invoice process is typically dependent on the completion of certain milestones and contract terms and subject to agreement by our customer. Payment is typically expected within 30 days of invoice. Any uncollected invoiced amounts for our performance obligations recognized over time, including contract retentions, are recorded as accounts receivable in the Condensed Consolidated Balance Sheets. Certain contracts allow customers to withhold a small percentage of billings pursuant to retainage provisions, and such amounts are generally due upon completion of the contract and acceptance of the project by the customer. Based on our experience in recent years, the majority of these retainage balances are expected to be collected within approximately twelve months. As of June 30, 2023 and September 30, 2022, accounts receivable included retention amounts of $7.0 million and $6.9 million, respectively. Of the retained amount at June 30, 2023, $6.8 million is expected to be collected in the next twelve months and is recorded in accounts receivable. The remaining $0.2 million is recorded in other assets.

[0000080420-23-000038:notes:48]
[same as prior period, unchanged from 0000080420-23-000027:notes:49]

[0000080420-23-000038:notes:49]
The following tables present our disaggregated revenue by geographic destination and market sector for the three and nine months ended June 30, 2023 and 2022 (in thousands):

[0000080420-23-000038:notes:50]
|  | Three months ended June 30, |  | Nine months ended June 30, |
|  | 2023 |  | 2022 |  | 2023 |  | 2022 |
| United States | $ | 153,258 |  |  | $ | 102,931 |  |  | $ | 387,531 |  |  | $ | 272,069 |  |
| Canada | 21,765 |  |  | 23,599 |  |  | 62,255 |  |  | 60,777 |  |
| Europe, Middle East and Africa | 12,004 |  |  | 6,697 |  |  | 30,521 |  |  | 30,078 |  |
| Asia/Pacific | 2,338 |  |  | 1,645 |  |  | 4,903 |  |  | 4,235 |  |
| Mexico, Central and South America | 3,000 |  |  | 611 |  |  | 5,457 |  |  | 2,748 |  |
| Total revenues by geographic destination | $ | 192,365 |  |  | $ | 135,483 |  |  | $ | 490,667 |  |  | $ | 369,907 |  |

[0000080420-23-000038:notes:51]
|  | Three months ended June 30, |  | Nine months ended June 30, |
|  | 2023 |  | 2022 |  | 2023 |  | 2022 |
| Oil and gas (excludes petrochemical) | $ | 73,452 |  |  | $ | 58,669 |  |  | $ | 179,560 |  |  | $ | 155,324 |  |
| Petrochemical | 21,995 |  |  | 15,187 |  |  | 70,372 |  |  | 51,268 |  |
| Electric utility | 43,824 |  |  | 30,173 |  |  | 114,899 |  |  | 82,079 |  |
| Commercial and other industrial | 35,527 |  |  | 14,966 |  |  | 74,846 |  |  | 30,583 |  |
| Traction power | 7,143 |  |  | 9,775 |  |  | 21,532 |  |  | 31,200 |  |
| All others | 10,424 |  |  | 6,713 |  |  | 29,458 |  |  | 19,453 |  |
| Total revenues by market sector | $ | 192,365 |  |  | $ | 135,483 |  |  | $ | 490,667 |  |  | $ | 369,907 |  |


## us-gaap:RevenueFromContractWithCustomerPolicyTextBlock

[0000080420-23-000038:notes:52]
[same as prior period, unchanged from 0000080420-23-000027:notes:53]

[0000080420-23-000038:notes:53]
[same as prior period, unchanged from 0000080420-23-000027:notes:54]

[0000080420-23-000038:notes:54]
[same as prior period, unchanged from 0000080420-23-000027:notes:55]

[0000080420-23-000038:notes:55]
Actual revenues and project costs may vary from previous estimates due to changes in a variety of factors. The cost estimation process is based upon the professional knowledge and experience of our engineers, project managers and financial professionals. Factors that are considered in estimating the work to be completed and ultimate contract recovery include the 
availability and productivity of labor, the nature and complexity of the work to be performed, the availability of materials, and the effect of any delays on our project performance. We periodically review our job performance, job conditions, estimated profitability and final contract settlements, including our estimate of total costs and make revisions to costs and income in the period in which the revisions are probable and reasonably estimable. We bear the risk of cost overruns in most of our contracts, which may result in reduced profits. Whenever revisions of estimated contract costs and contract values indicate that the contract costs will exceed estimated revenues, thus creating a loss, a provision for the total estimated loss is recorded in that period.
Variable Consideration

[0000080420-23-000038:notes:56]
[same as prior period, unchanged from 0000080420-23-000027:notes:57]


## us-gaap:LongTermDebtTextBlock

[0000080420-23-000038:notes:57]
Long-Term Debt
U.S Revolver

[0000080420-23-000038:notes:58]
On March 31, 2023, we entered into a second amendment (the Second Amendment) to our credit agreement with Bank of America, N.A. (as amended, the U.S. Revolver). The Second Amendment increased the revolving credit facility extended to us under the U.S. Revolver, which is available for both borrowings and letters of credit and expires September 27, 2024, from $75.0 million to $125.0 million. As amended by the Second Amendment, the U.S. Revolver states that the lesser of $50 million or 50% of readily and available cash may be deducted from the amount of letters of credit outstanding (not to be less than zero) when calculating the consolidated funded indebtedness, which is a component of the consolidated net leverage ratio. We have the option to cash collateralize all or a portion of the letters of credit outstanding, which would favorably impact the consolidated funded indebtedness calculation and the consolidated net leverage ratio. As of June 30, 2023, there were no amounts borrowed under the U.S. Revolver, and letters of credit outstanding were $49.0 million. There was $76.0 million available for the issuance of letters of credit and borrowings under the U.S. Revolver as of June 30, 2023.

[0000080420-23-000038:notes:59]
We are required to maintain certain financial covenants, the most significant of which are a consolidated net leverage ratio less than 3.0 to 1.0 and a consolidated interest coverage ratio of greater than 3.0 to 1.0. Our most restrictive covenant, the consolidated net leverage ratio, is the ratio of earnings before interest, taxes, depreciation, amortization and stock-based compensation (EBITDAS) to funded indebtedness. An increase in indebtedness, which includes letters of credit, or a decrease in EBITDAS could restrict our ability to issue letters of credit or borrow under the U.S. Revolver. Additionally, we must maintain a consolidated cash balance of $50 million at all times, which can be deducted from the letters of credit outstanding as noted above. The U.S. Revolver also contains a "material adverse effect" clause which is a material change in our operations, business, properties, liabilities or condition (financial or otherwise) or a material impairment of our ability to perform our obligations under our credit agreements. As of June 30, 2023, we were in compliance with all of the financial covenants of the U.S. Revolver.

[0000080420-23-000038:notes:60]
The U.S. Revolver allows the Company to elect that any borrowing under the facility bears an interest rate based on either the base rate or the eurocurrency rate, in each case, plus the applicable rate. The base rate is generally the highest of (a) the federal funds rate plus 0.50%, (b) the Bank of America prime rate or (c) the Bloomberg Short-Term Bank Yield Index (BSBY) rate plus 1.00%. The applicable rate is generally a range from 0% to 2% depending on the type of loan and the Company's consolidated net leverage ratio.

[0000080420-23-000038:notes:61]
The U.S. Revolver is collateralized by a pledge of 100% of the voting capital stock of each of our domestic subsidiaries and 65% of the voting capital stock of each non-domestic subsidiary. The U.S. Revolver provides for customary events of default and carries cross-default provisions with other existing debt agreements. If an event of default (as defined in the U.S. Revolver) occurs and is continuing, on the terms and subject to the conditions set forth in the U.S. Revolver, amounts and letters of credit outstanding under the U.S. Revolver may be accelerated and may become immediately due and payable.

[0000080420-23-000038:notes:62]
Industrial Development Revenue Bonds

[0000080420-23-000038:notes:63]
We borrowed $8.0 million in October 2001 through a loan agreement funded with proceeds from tax-exempt industrial development revenue bonds (Bonds) for the completion of our Northlake, Illinois facility. The Bonds matured on October 1, 2021 and our final payment of $0.4 million was made.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0000080420-23-000038:notes:64]
Commitments and Contingencies
Letters of Credit, Bank Guarantees and Bonds

[0000080420-23-000038:notes:65]
Certain customers require us to post letters of credit, bank guarantees or surety bonds. These security instruments assure that we will perform under the terms of our contract. In the event of default, the counterparty may demand payment from the bank under a letter of credit or bank guarantee, or performance by the surety under a bond. To date, there have been no significant draws or claims related to security instruments for the periods reported. We were contingently liable for letters of credit of $49.0 million as of June 30, 2023. We also had surety bonds totaling $357.5 million that were outstanding, with additional bonding capacity of $342.5 million available, at June 30, 2023. We have strong surety relationships; however, a change in market conditions or the sureties' assessment of our financial position could cause the sureties to require cash collateralization for undischarged liabilities under the bonds.

[0000080420-23-000038:notes:66]
We have a $10.1 million facility agreement (Facility Agreement) between Powell (UK) Limited and a large international bank that provides Powell (UK) Limited the ability to enter into bank guarantees as well as forward exchange contracts and currency options. At June 30, 2023, we had outstanding guarantees totaling $8.2 million. The Facility Agreement provides for customary events of default and carries cross-default provisions with our Second Amendment. If an event of default (as defined in the Facility Agreement) occurs and is continuing, per the terms and subject to the conditions set forth therein, obligations outstanding under the Facility Agreement may be accelerated and declared immediately due and payable. Additionally, we are required to maintain cash collateral for guarantees greater than two years. As of June 30, 2023, we were in compliance with all of the financial covenants of the Facility Agreement.

[0000080420-23-000038:notes:67]
Litigation

[0000080420-23-000038:notes:68]
We are involved in various legal proceedings, claims and other disputes arising from our commercial operations, projects, employees and other matters which, in general, are subject to uncertainties and in which the outcomes are not predictable. Although we can give no assurances about the resolution of pending claims, litigation or other disputes, and the effect such outcomes may have on us, management believes that any ultimate liability resulting from the outcome of such proceedings, to the extent not otherwise provided or covered by insurance, will not have a material adverse effect on our consolidated financial position or results of operations or liquidity.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0000080420-23-000038:notes:69]
Stock-Based Compensation
Refer to our Annual Report on Form 10-K for the fiscal year ended September 30, 2022 for a full description of our existing stock-based compensation plans. On February 15, 2023, at the 2023 Annual Meeting of Stockholders, our stockholders approved an amendment to our 2014 Equity Incentive Plan (the 2014 Plan) that extended the term of the 2014 Plan by five years and increased the number of shares of common stock that may be issued under the 2014 Plan by 600,000 shares for a total of 1,350,000 shares.

[0000080420-23-000038:notes:70]
[same as prior period, unchanged from 0000080420-23-000027:notes:71]

[0000080420-23-000038:notes:71]
We issue restricted stock units (RSUs) to certain officers and key employees of the Company. The fair value of the RSUs is based on the price of our common stock as reported on the NASDAQ Global Market on the grant dates. Typically, these grants vest over a three-year period from the date of issuance and are a blend of time-based and performance-based shares. The portion of the grant that is time-based typically vests over a three-year period on each anniversary of the grant date, based on continued employment. The performance-based shares vest based on the three-year earnings performance of the Company following the grant date. At June 30, 2023, there were 295,417 RSUs outstanding. The RSUs do not have voting rights but do receive dividend equivalents upon vesting which are accrued quarterly. Additionally, the shares of common stock underlying the RSUs are not considered issued and outstanding until vested and common stock is issued.

[0000080420-23-000038:notes:72]
Total RSU activity (number of shares) for the nine months ended June 30, 2023 is summarized below:

[0000080420-23-000038:notes:73]
|  | Number ofRestrictedStockUnits |  | WeightedAverageGrant ValuePer Share |
| Outstanding at September 30, 2022 | 239,862 |  |  | $ | 26.11 |  |
| Granted | 147,100 |  |  | 21.26 |  |
| Vested | (76,834) |  |  | 29.42 |  |
| Forfeited/canceled | (14,711) |  |  | 38.58 |  |
| Outstanding at June 30, 2023 | 295,417 |  |  | $ | 22.85 |  |

[0000080420-23-000038:notes:74]
During the nine months ended June 30, 2023 and 2022, we recorded compensation expense of $3.4 million and $1.9 million, respectively, related to the RSUs.

[0000080420-23-000038:notes:75]
Restricted Stock
Each non-employee director receives 2,400 restricted shares of the Company’s common stock annually. Fifty-percent of the restricted stock granted to each of our non-employee directors vests immediately, while the remaining fifty-percent vests on the anniversary of the grant date. Compensation expense is recognized immediately for the first fifty-percent of the restricted stock granted, while compensation expense for the remaining fifty-percent is recognized over the remaining vesting period. In February 2023, 16,800 shares of restricted stock were issued to our non-employee directors under the 2014 Non-Employee Director Equity Incentive Plan, as amended, at a price of $43.22 per share. During the nine months ended June 30, 2023 and 2022, we recorded compensation expense of $0.5 million and $0.4 million, respectively, related to restricted stock.


## us-gaap:FairValueDisclosuresTextBlock

[0000080420-23-000038:notes:76]
[same as prior period, unchanged from 0000080420-23-000027:notes:78]

[0000080420-23-000038:notes:77]
[same as prior period, unchanged from 0000080420-23-000027:notes:79]

[0000080420-23-000038:notes:78]
[same as prior period, unchanged from 0000080420-23-000027:notes:80]

[0000080420-23-000038:notes:79]
[same as prior period, unchanged from 0000080420-23-000027:notes:81]

[0000080420-23-000038:notes:80]
[same as prior period, unchanged from 0000080420-23-000027:notes:82]

[0000080420-23-000038:notes:81]
The following table summarizes the fair value of our assets and liabilities that were accounted for at fair value on a recurring basis as of June 30, 2023 (in thousands):

[0000080420-23-000038:notes:82]
|  | Fair Value Measurements at June 30, 2023 |
|  | Quoted Prices inActive Markets forIdentical Assets(Level 1) |  | Significant OtherObservableInputs(Level 2) |  | SignificantUnobservableInputs(Level 3) |  | Fair Value at June 30,2023 |
| Assets: |  |  |  |  |  |  |  |
| Cash and cash equivalents | $ | 183,355 |  |  | $ | — |  |  | $ | — |  |  | $ | 183,355 |  |
| Short-term investments | 26,414 |  |  | — |  |  | — |  |  | 26,414 |  |
| Other assets | — |  |  | 8,699 |  |  | — |  |  | 8,699 |  |
| Liabilities: |  |  |  |  |  |  |  |
| Deferred compensation | — |  |  | 9,439 |  |  | — |  |  | 9,439 |  |

[0000080420-23-000038:notes:83]
[same as prior period, unchanged from 0000080420-23-000027:notes:85]

[0000080420-23-000038:notes:84]
[same as prior period, unchanged from 0000080420-23-000027:notes:86]

[0000080420-23-000038:notes:85]
[same as prior period, unchanged from 0000080420-23-000027:notes:87]

[0000080420-23-000038:notes:86]
[same as prior period, unchanged from 0000080420-23-000027:notes:88]

[0000080420-23-000038:notes:87]
[same as prior period, unchanged from 0000080420-23-000027:notes:89]

[0000080420-23-000038:notes:88]
[same as prior period, unchanged from 0000080420-23-000027:notes:90]

[0000080420-23-000038:notes:89]
There were no transfers between levels within the fair value measurement hierarchy during the quarter ended June 30, 2023.


## us-gaap:LesseeOperatingLeasesTextBlock

[0000080420-23-000038:notes:90]
Leases
Our leases consist primarily of office and manufacturing and construction equipment. All of our future lease obligations are related to non-cancelable operating leases. The decrease of our lease portfolio relates to the wind down of our Canadian facility leases. The following table provides a summary of lease cost components for the three and nine months ended June 30, 2023 and 2022, respectively (in thousands):

[0000080420-23-000038:notes:91]
|  |  | Three months ended June 30, |  | Nine months ended June 30, |
| Lease Cost |  | 2023 |  | 2022 |  | 2023 |  | 2022 |
| Operating lease cost |  | $ | 391 |  |  | $ | 551 |  |  | $ | 1,147 |  |  | $ | 1,695 |  |
| Less: sublease income |  | (163) |  |  | (171) |  |  | (487) |  |  | (519) |  |
| Variable lease cost(1) |  | 93 |  |  | 114 |  |  | 288 |  |  | 372 |  |
| Short-term lease cost(2) |  | 669 |  |  | 413 |  |  | 1,486 |  |  | 1,266 |  |
| Total lease cost |  | $ | 990 |  |  | $ | 907 |  |  | $ | 2,434 |  |  | $ | 2,814 |  |

[0000080420-23-000038:notes:92]
[same as prior period, unchanged from 0000080420-23-000027:notes:94]

[0000080420-23-000038:notes:93]
[same as prior period, unchanged from 0000080420-23-000027:notes:95]

[0000080420-23-000038:notes:94]
We recognize operating lease assets and operating lease liabilities representing the present value of the remaining lease payments for leases with initial terms greater than twelve months. Leases with initial terms of twelve months or less are not recorded in our Condensed Consolidated Balance Sheets. The following table provides a summary of the operating lease assets and operating lease liabilities included in our Condensed Consolidated Balance Sheets as of June 30, 2023 and September 30, 2022, respectively (in thousands):

[0000080420-23-000038:notes:95]
| Operating Leases |  | June 30, 2023 |  | September 30, 2022 |
| Assets: |  |  |  |  |
| Operating lease assets, net |  | $ | 1,567 |  |  | $ | 2,179 |  |
| Liabilities: |  |  |  |  |
| Current operating lease liabilities |  | 839 |  |  | 1,777 |  |
| Long-term operating lease liabilities |  | 741 |  |  | 545 |  |
| Total lease liabilities |  | $ | 1,580 |  |  | $ | 2,322 |  |

[0000080420-23-000038:notes:96]
The following table provides the maturities of our operating lease liabilities as of June 30, 2023 (in thousands):

[0000080420-23-000038:notes:97]
|  |  | Operating Leases |  |  |
| Remainder of 2023 |  | $ | 344 |  |  |  |
| 2024 |  | 671 |  |  |  |
| 2025 |  | 330 |  |  |  |
| 2026 |  | 145 |  |  |  |
| 2027 |  | 133 |  |  |  |
| Thereafter |  | 19 |  |  |  |
| Total future minimum lease payments |  | $ | 1,642 |  |  |  |
| Less: present value discount (imputed interest) |  | (62) |  |  |  |
| Present value of lease liabilities |  | $ | 1,580 |  |  |  |

[0000080420-23-000038:notes:98]
The weighted average discount rate as of June 30, 2023 was 3.35%. The weighted average remaining lease term was 2.48 years at June 30, 2023.


## us-gaap:IncomeTaxDisclosureTextBlock

[0000080420-23-000038:notes:99]
[same as prior period, unchanged from 0000080420-23-000027:notes:101]

[0000080420-23-000038:notes:100]
|  | Three months ended June 30, |  | Nine months ended June 30, |
|  | 2023 |  | 2022 |  | 2023 |  | 2022 |
| Income (loss) before income taxes | $ | 23,645 |  |  | $ | 2,918 |  |  | $ | 36,232 |  |  | $ | (774) |  |
| Income tax provision (benefit) | 5,191 |  |  | (6,143) |  |  | 8,142 |  |  | (5,772) |  |
| Net income | $ | 18,454 |  |  | $ | 9,061 |  |  | $ | 28,090 |  |  | $ | 4,998 |  |
| Effective tax rate | 22 | % |  | (211) | % |  | 22 | % |  | 746 | % |

[0000080420-23-000038:notes:101]
Our income tax provision reflects an effective tax rate on pre-tax income of 22% for both the three and nine months ended June 30, 2023 compared to an income tax benefit that reflects an effective tax rate on pre-tax income of negative 211% for the three months ended June 30, 2022 and 746% for the nine months ended June 30, 2022. The effective tax rate for the three and nine months ended June 30, 2023 approximated the U.S. federal statutory rate. The favorable impacts of the estimated Research and Development Tax Credit (R&D Tax Credit) and the projected utilization of net operating loss carryforwards in the UK that have been fully reserved with a valuation allowance were offset by state income tax expense, certain nondeductible expenses and an income inclusion related to U.S. global intangible income.

[0000080420-23-000038:notes:102]
We record and maintain valuation allowances against the deferred tax assets of various foreign jurisdictions until sufficient evidence is available to demonstrate that it is more-likely-than-not that the net deferred tax assets will be recognized. As of each reporting date, management considers new evidence, both positive and negative, that could affect its view of the future realization of deferred tax assets. Given our current earnings and anticipated future earnings in the UK, we believe that there is a possibility that within the next 12 months, sufficient positive evidence may become available to allow us to reach a conclusion that a significant portion of the UK valuation allowance will no longer be needed.  A release in the valuation allowance would result in recognition of certain net deferred tax assets and a decrease to income tax expense for the period the release is recorded.  However, the exact timing and amount of the valuation allowance release are subject to change on the basis of the level of profitability that we believe we may be able to achieve.

[0000080420-23-000038:notes:103]
During the period ended June 30, 2022, management determined that there was sufficient positive evidence to conclude that Canadian net deferred tax assets were realizable. The valuation allowance was released accordingly, and a $5.9 million  tax benefit and corresponding increase in the deferred tax asset were recorded. The tax benefit for the three and nine months ended June 30, 2022 was also impacted by a discrete item related to the gain recognized from the disposition of a small, non-core division of our Canadian operations.  This gain on the disposal resulted in tax expense of $0.4 million.


## us-gaap:SubsequentEventsTextBlock

[0000080420-23-000038:notes:104]
Subsequent Events
Quarterly Dividend Declared

[0000080420-23-000038:notes:105]
On August 1, 2023, our Board of Directors declared a quarterly cash dividend on our common stock in the amount of $0.2625 per share. The dividend is payable on September 20, 2023 to shareholders of record at the close of business on August 16, 2023.
