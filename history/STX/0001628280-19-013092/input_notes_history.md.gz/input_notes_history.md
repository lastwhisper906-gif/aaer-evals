# STX note change history — 0001193125-19-129284 → 0001628280-19-013092


## us-gaap:LegalMattersAndContingenciesTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2019-11-01):
[0001628280-19-013092:note_history:1]
The Company assesses the probability of an unfavorable outcome of all its material litigation, claims, or assessments to determine whether a liability had been incurred and whether it is probable that one or more future events will occur confirming the fact of the loss. In the event that an unfavorable outcome is determined to be probable and the amount of the loss can be reasonably estimated, the Company establishes an accrual for the litigation, claim or assessment. In addition, in the event an unfavorable outcome is determined to be less than probable, but reasonably possible, the Company will disclose an estimate of the possible loss or range of such loss; however, when a reasonable estimate cannot be made, the Company will provide disclosure
  (was, 2019-04-30, similarity 0.8177):
[0001193125-19-129284:note_history:1]
The Company assesses the probability of an unfavorable outcome of all its material litigation, claims, or assessments to determine whether a liability had been incurred and whether it is probable that one or more future events will occur confirming the fact of the loss. In the event that an unfavorable outcome is determined to be probable and the amount of the loss can be reasonably estimated, the Company establishes an accrual for the litigation, claim or assessment. In addition, in the event an unfavorable outcome is determined to be less than probable, but reasonably possible, the Company will disclose an estimate of the possible loss or range of such loss; however, when a reasonable estimate cannot be made, the Company will provide disclosure to that effect. Litigation is inherently uncertain and may result in adverse rulings or decisions. Additionally, the Company may enter into settlements or be subject to judgments that may, individually or in the aggregate, have a material adverse effect on its results of operations. Accordingly, actual results could differ materially.

- added (2019-11-01):
[0001628280-19-013092:note_history:2]
to that effect. Litigation is inherently uncertain and may result in adverse rulings or decisions. Additionally, the Company may enter into settlements or be subject to judgments that may, individually or in the aggregate, have a material adverse effect on its results of operations. Accordingly, actual results could differ materially.

- changed (2019-11-01):
[0001628280-19-013092:note_history:3]
Lambeth Magnetic Structures LLC v. Seagate Technology (US) Holdings, Inc., et al. On April 29, 2016, Lambeth Magnetic Structures LLC filed a complaint against Seagate Technology (US) Holdings, Inc. and Seagate Technology LLC in the U.S. District Court for the Western District of Pennsylvania, alleging infringement of U.S. Patent No. 7,128,988, “Magnetic Material Structures, Devices and Methods.” The Company believes the claims asserted in the complaint are without merit and intends to vigorously defend this case. The court issued its claim construction ruling on October 18, 2017. A jury trial in this matter is scheduled for June 1, 2020. While the possible range of loss for this matter remains uncertain, the Company estimates the amount of loss to be immaterial to the financial statements.
  (was, 2019-04-30, similarity 0.7477):
[0001193125-19-129284:note_history:3]
Lambeth Magnetic Structures LLC v. Seagate Technology (US) Holdings, Inc., et al. On April 29, 2016, Lambeth Magnetic Structures LLC filed a complaint against Seagate Technology (US) Holdings, Inc. and Seagate Technology LLC in the U.S. District Court for the Western District of Pennsylvania, alleging infringement of U.S. Patent No. 7,128,988, “Magnetic Material Structures, Devices and Methods.” The Company believes the claims asserted in the complaint are without merit and intends to vigorously defend this case. The court issued its claim construction ruling on October 18, 2017. No trial date has been set. While the possible range of loss for this matter remains uncertain, the Company estimates the amount of loss to be immaterial to the financial statements.

- changed (2019-11-01):
[0001628280-19-013092:note_history:4]
The Company may be subject to various state, federal and international laws and regulations governing the environment, including those restricting the presence of certain substances in electronic products. For example, the European Union (“EU”) enacted the Restriction of the Use of Certain Hazardous Substances in Electrical and Electronic Equipment (2011/65/EU), which prohibits the use of certain substances, including lead, in certain products, including disk drives and server storage products, put on the market after July 1, 2006. Similar legislation has been or may be enacted in other jurisdictions, including in the United States, Canada, Mexico, Taiwan, China, Japan and others. The EU REACH Directive (Registration, Evaluation, Authorization, and Restriction of Chemicals, EC 1907/2006) also restricts substances of very high concern in products. If the Company or its suppliers fails to comply with the substance restrictions, recycle requirements or other environmental requirements as they are enacted worldwide, it could have a materially adverse effect on the Company’s business.
  (was, 2019-04-30, similarity 0.9899):
[0001193125-19-129284:note_history:4]
The Company may be subject to various state, federal and international laws and regulations governing the environment, including those restricting the presence of certain substances in electronic products. For example, the European Union (“EU”) enacted the Restriction of the Use of Certain Hazardous Substances in Electrical and Electronic Equipment (2011/65/EU), which prohibits the use of certain substances, including lead, in certain products, including disk drives and server storage products, put on the market after July 1, 2006. Similar legislation has been or may be enacted in other jurisdictions, including in the United States, Canada, Mexico, Taiwan, China, Japan and others. The European Union REACH Directive (Registration, Evaluation, Authorization, and Restriction of Chemicals, EC 1907/2006) also restricts substances of very high concern (“SVHCs”) in products. If the Company or its suppliers fails to comply with the substance restrictions, recycle requirements or other environmental requirements as they are enacted worldwide, it could have a materially adverse effect on the Company’s business.


## us-gaap:OrganizationConsolidationBasisOfPresentationBusinessDescriptionAndAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- added (2019-11-01):
[0001628280-19-013092:note_history:5]
Seagate Technology plc (“STX”) and its subsidiaries (collectively, unless the context otherwise indicates, the “Company”) is a leading provider of data storage technology and solutions. Its principal products are hard disk drives, commonly referred to as disk drives, hard drives or HDDs. In addition to HDDs, the Company produces a broad range of data storage products including solid state drives (“SSDs”), solid state hybrid drives (“SSHDs”) and storage subsystems.

- added (2019-11-01):
[0001628280-19-013092:note_history:6]
Hard disk drives are devices that store digitally encoded data on rapidly rotating disks with magnetic surfaces. Disk drives continue to be the primary medium of mass data storage due to their performance attributes, reliability, high quality and cost effectiveness. Complementing existing data center storage architecture, solid-state drives use integrated circuit assemblies as memory to store data, and most SSDs use NAND flash memory. In addition to HDDs and SSDs, SSHDs combine the features of SSDs and HDDs in the same unit, containing a high capacity hard disk drive and a smaller SSD acting as a cache to improve performance of frequently accessed data.

- added (2019-11-01):
[0001628280-19-013092:note_history:7]
The Company’s HDD products are designed for nearline and mission critical applications in enterprise servers and storage systems; edge non-compute applications, where its products are designed for a wide variety of end user devices such as portable external storage systems, video and image applications, including surveillance systems, network-attached storage (“NAS”), digital video recorders (“DVRs”) and gaming consoles; and edge compute applications, where its products are designed primarily for desktop and mobile computing. The Company’s SSD product portfolio is mainly comprised of Serial Attached SCSI (“SAS”) and Non-Volatile Memory Express (“NVMe”) and is designed for applications in enterprise servers and storage systems.

- added (2019-11-01):
[0001628280-19-013092:note_history:8]
The Company’s enterprise data solutions (“EDS”) portfolio includes storage subsystems for enterprises, cloud service providers, scale-out storage servers and original equipment manufacturers (“OEMs”).

- changed (2019-11-01):
[0001628280-19-013092:note_history:9]
The Company’s unaudited condensed consolidated financial statements include the accounts of the Company and all its wholly-owned and majority-owned subsidiaries, after elimination of intercompany transactions and balances.
  (was, 2019-04-30, similarity 0.9955):
[0001193125-19-129284:note_history:9]
The Company's unaudited condensed consolidated financial statements include the accounts of the Company and all its wholly-owned and majority-owned subsidiaries, after elimination of intercompany transactions and balances.

- changed (2019-11-01):
[0001628280-19-013092:note_history:10]
The preparation of financial statements in accordance with U.S. generally accepted accounting principles requires management to make estimates and assumptions that affect the amounts reported in the Company’s condensed consolidated financial statements and accompanying notes. Actual results could differ materially from those estimates. The methods, estimates and judgments the Company uses in applying its most critical accounting policies have a significant impact on the results the Company reports in its condensed consolidated financial statements.
  (was, 2019-04-30, similarity 0.7599):
[0001193125-19-129284:note_history:10]
The preparation of financial statements in accordance with U.S. generally accepted accounting principles requires management to make estimates and assumptions that affect the amounts reported in the Company’s condensed consolidated financial statements and accompanying notes. Actual results could differ materially from those estimates. The methods, estimates and judgments the Company uses in applying its most critical accounting policies have a significant impact on the results the Company reports in its condensed consolidated financial statements. The condensed consolidated financial statements reflect, in the opinion of management, all material adjustments necessary to present fairly the condensed consolidated financial position, results of operations, comprehensive income, cash flows and shareholders’ equity for the periods presented. Such adjustments are of a normal and recurring nature.

- changed (2019-11-01):
[0001628280-19-013092:note_history:11]
The Company’s consolidated financial statements for the fiscal year ended June 28, 2019, are included in its Annual Report on Form 10-K, as filed with the United States Securities and Exchange Commission (“SEC”) on August 2, 2019. The Company believes that the disclosures included in these unaudited condensed consolidated financial statements, when read in conjunction with its consolidated financial statements as of June 28, 2019, and the notes thereto, are adequate to make the information presented not misleading.
  (was, 2019-04-30, similarity 0.998):
[0001193125-19-129284:note_history:11]
The Company’s consolidated financial statements for the fiscal year ended June 29, 2018, are included in its Annual Report on Form 10-K, as filed with the United States Securities and Exchange Commission (“SEC”) on August 3, 2018. The Company believes that the disclosures included in the unaudited condensed consolidated financial statements, when read in conjunction with its consolidated financial statements as of June 29, 2018, and the notes thereto, are adequate to make the information presented not misleading.

- added (2019-11-01):
[0001628280-19-013092:note_history:12]
Fiscal Year

- added (2019-11-01):
[0001628280-19-013092:note_history:13]
The Company operates and reports financial results on a fiscal year of 52 or 53 weeks ending on the Friday closest to June 30. The three months ended October 4, 2019 consisted of 14 weeks and the three months ended September 28, 2018 consisted of 13 weeks. Fiscal year 2020, which ends on July 3, 2020, is comprised of 53 weeks and fiscal year 2019, which ended on June 28, 2019, is comprised of 52 weeks. The fiscal quarters ended October 4, 2019, June 28, 2019 and September 28, 2018, are also referred to herein as the “September 2019 quarter”, the “June 2019 quarter”, and the “September 2018 quarter”, respectively. The results of operations for the three months ended October 4, 2019 are not necessarily indicative of the results of operations to be expected for any subsequent interim period or for the Company’s fiscal year ending July 3, 2020.

- changed (2019-11-01):
[0001628280-19-013092:note_history:14]
Except for the change in the Company’s other long-lived assets and leases policies described below, there have been no material changes to the Company’s significant accounting policies disclosed in Note 1 - Basis of Presentation and Summary of Significant Accounting Policies of “Financial Statements and Supplementary Data” contained in Part II, Item 8 of the Company’s Annual Report on Form 10-K for the fiscal year ended June 28, 2019, as filed with the SEC on August 2, 2019.
  (was, 2019-04-30, similarity 0.8222):
[0001193125-19-129284:note_history:14]
Except for the change in the Company's revenue recognition policy described below, there have been no material changes to the Company’s significant accounting policies disclosed in Note 1 - Basis of Presentation and Summary of Significant Accounting Policies of "Financial Statements and Supplementary Data" contained in Part II, Item 8 of the Company's Annual Report on Form 10-K for the fiscal year ended June 29, 2018, as filed with the SEC on August 3, 2018.

- added (2019-11-01):
[0001628280-19-013092:note_history:15]
Other Long-Lived Assets

- added (2019-11-01):
[0001628280-19-013092:note_history:16]
In accordance with its policy, the Company reviews the estimated useful lives of its fixed assets on an ongoing basis. This review indicated that the actual lives of certain manufacturing equipment at its manufacturing facilities were longer than the estimated useful lives used for deprecation purposes in the Company’s condensed consolidated financial statements. As a result, effective June 29, 2019, the Company changed its estimate of the useful lives of its manufacturing equipment from a range of three to five years to a range of three to seven years. The effect of this change in estimate increased the September 2019 quarter net income by $23 million and diluted earnings per share by $0.09.

- added (2019-11-01):
[0001628280-19-013092:note_history:17]
Leases

- added (2019-11-01):
[0001628280-19-013092:note_history:18]
Effective June 29, 2019, the Company adopted a new accounting policy for leases in accordance with Accounting Standard Codification (“ASC”) 842, Leases, using the modified retrospective approach. Accordingly, the Company applied the new lease accounting standard prospectively to leases existing or commencing on or after June 29, 2019. The Company elected to apply the practical expedients which allow for not reassessing whether existing contracts contain leases, the classification of existing leases and whether the existing initial direct costs meet the new definition. In addition, the Company elected to combine lease and non-lease components for facility leases and to not recognize right-of-use (“ROU”) assets and lease liabilities for leases with an initial term of 12 months of less on the balance sheet.

- added (2019-11-01):
[0001628280-19-013092:note_history:19]
The Company determines if an arrangement is a lease or contains a lease at inception. ROU assets are included in Other assets, net and lease liabilities are included in Accrued expenses and Other non-current liabilities on the Company’s Condensed Consolidated Balance Sheets. ROU assets represent the Company’s right to use an underlying asset for the lease term and the corresponding lease liabilities represent its obligation to make lease payments arising from the lease.

- added (2019-11-01):
[0001628280-19-013092:note_history:20]
Lease liabilities are measured at the present value of the remaining lease payments and ROU assets are based on the lease liability, adjusted for lease prepayments, lease incentives received and the lessee’s initial direct costs. As the Company’s leases do not provide an implicit rate, the net present value of future minimum lease payments is determined using the Company’s estimated incremental borrowing rate based on the information available at the lease commencement date. Additionally, the Company’s lease term may include options to extend or terminate the lease. These options are reflected in the ROU asset and lease liability when it is reasonably certain that the Company will exercise the option. The Company’s lease agreements do not contain any material residual value guarantees.

- added (2019-11-01):
[0001628280-19-013092:note_history:21]
The Company recognizes lease expense on a straight-line basis over the lease term. Variable lease payments not dependent on an index or a rate primarily consist of common area maintenance charges, are expensed as incurred, and are not included in the ROU asset and lease liability calculation. The total operating and variable lease costs were included in operating expenses in the Company’s Condensed Consolidated Statements of Operations.

- added (2019-11-01):
[0001628280-19-013092:note_history:22]
In February 2016, the Financial Accounting Standards Board (“FASB”) issued Accounting Standard Update (“ASU”) 2016-02 (ASC Topic 842), Leases and subsequently issued certain interpretive clarifications on this new guidance which amends a number of aspects of lease accounting, including requiring a lessee to recognize an ROU asset and corresponding lease liability for operating leases and enhanced disclosures. As of June 29, 2019, adoption of the standard resulted in the recognition of ROU assets and corresponding current and non-current lease liabilities of $115 million, $17 million and $57 million, respectively, on the Company’s Condensed Consolidated Balance Sheet, primarily relating to real estate operating leases. The adoption of this ASU did not have a material impact on the Company’s other condensed consolidated financial statements. For information regarding the impact of ASC 842 adoption, see Summary of Significant Accounting Policies - Leases above and Note 5. Leases.

- changed (2019-11-01):
[0001628280-19-013092:note_history:23]
In February 2018, the FASB issued ASU 2018-02 (ASC Topic 220), Income Statement—Reporting Comprehensive Income: Reclassification of Certain Tax Effects from Accumulated Other Comprehensive Income. This ASU was issued following the enactment of the U.S. Tax Cuts and Jobs Act of 2017 (the “Tax Act”) and permits entities to elect a reclassification from accumulated other comprehensive income to retained earnings for stranded tax effects resulting from the Tax Act. This ASU became effective and the Company adopted the guidance in the September 2019 quarter. The Company has elected not to reclassify the stranded amounts. The adoption of this guidance did not have a material impact on its condensed consolidated financial statements and disclosures.
  (was, 2019-04-30, similarity 0.707):
[0001193125-19-129284:note_history:23]
In February 2018, the FASB issued ASU 2018-02 (ASC Topic 220), Income Statement—Reporting Comprehensive Income: Reclassification of Certain Tax Effects from Accumulated Other Comprehensive Income. This ASU was issued following the enactment of the U.S. Tax Cuts and Jobs Act of 2017 (the "Tax Act") and permits entities to elect a reclassification from accumulated other comprehensive income to retained earnings for stranded tax effects resulting from the Tax Act. The Company is required to adopt this guidance in the first quarter of fiscal year 2020. Early adoption is permitted. The Company is in the process of assessing the impact of this ASU on its condensed consolidated financial statements.

- added (2019-11-01):
[0001628280-19-013092:note_history:24]
In August 2018, the FASB issued ASU 2018-15 (ASC Subtopic 350-40), Intangibles - Goodwill and Other - Internal-Use Software - Customer’s Accounting for Implementation Costs Incurred in a Cloud Computing Arrangement That is a Service

- changed (2019-11-01):
[0001628280-19-013092:note_history:25]
Contract. This ASU aligns the accounting for capitalizing implementation costs incurred in a hosting arrangement that is a service contract with the accounting for implementation costs incurred to develop or obtain internal-use software. The Company is required to adopt the guidance in the first quarter of fiscal year 2021. Early adoption is permitted. The Company is in the process of assessing the impact of this ASU on its condensed consolidated financial statements.
  (was, 2019-04-30, similarity 0.8083):
[0001193125-19-129284:note_history:25]
In August 2018, the FASB issued ASU 2018-15 (ASC Subtopic 350-40), Intangibles - Goodwill and Other - Internal-Use Software - Customer’s Accounting for Implementation Costs Incurred in a Cloud Computing Arrangement That is a Service Contract. This ASU aligns the accounting for capitalizing implementation costs incurred in a hosting arrangement that is a service contract with the accounting for implementation costs incurred to develop or obtain internal-use software. The Company is required to adopt the guidance in the first quarter of fiscal year 2021. Early adoption is permitted. The Company is in the process of assessing the impact of this ASU on its condensed consolidated financial statements.

- changed (2019-11-01):
[0001628280-19-013092:note_history:26]
In June 2016, the FASB issued ASU 2016-13 (ASC Topic 326), Financial Instruments—Credit Losses: Measurement of Credit Losses on Financial Instruments. This ASU amends the requirement on the measurement and recognition of expected credit losses for financial assets held. The Company is required to adopt this guidance in the first quarter of fiscal year 2021. The Company is in the process of assessing the impact of this ASU on its condensed consolidated financial statements.
  (was, 2019-04-30, similarity 0.9095):
[0001193125-19-129284:note_history:26]
In June 2016, the FASB issued ASU 2016-13 (ASC Topic 326), Financial Instruments - Credit Losses: Measurement of Credit Losses on Financial Instruments. This ASU amends the requirement on the measurement and recognition of expected credit losses for financial assets held. The Company is required to adopt this guidance in the first quarter of fiscal year 2021. Early adoption is permitted in the first quarter of fiscal year 2020. The Company is in the process of assessing the impact of this ASU on its condensed consolidated financial statements.

- removed (2019-11-01):
[0001193125-19-129284:note_history:27]
Seagate Technology plc (the “Company”) is a leading provider of data storage technology and solutions. Its principal products are hard disk drives, commonly referred to as disk drives, hard drives or HDDs. In addition to HDDs, the Company produces a broad range of data storage products including solid state drives (“SSDs”) and storage subsystems.

- removed (2019-11-01):
[0001193125-19-129284:note_history:28]
Hard disk drives are devices that store digitally encoded data on rapidly rotating disks with magnetic surfaces. Disk drives continue to be the primary medium of mass data storage due to their performance attributes, high quality and cost effectiveness. Complementing existing data center storage architecture, solid-state storage devices use integrated circuit assemblies as memory to store data, and most SSDs use NAND flash memory.

- removed (2019-11-01):
[0001193125-19-129284:note_history:29]
The Company’s HDD products are designed for mission critical and nearline applications in enterprise servers and storage systems; edge compute applications, where its products are designed primarily for desktop and mobile computing; and edge non-compute applications, where its products are designed for a wide variety of end user devices such as portable external storage systems, surveillance systems, digital video recorders (“DVRs”), network-attached storage (“NAS”), and gaming consoles. The Company's SSD products mainly include serial attached SCSI ("SAS") and Non-Volatile Memory Express ("NVMe") SSDs.

- removed (2019-11-01):
[0001193125-19-129284:note_history:30]
The Company’s enterprise data solutions (formerly referred to as the "cloud systems and solutions") portfolio includes modular original equipment manufacturers (“OEM”) storage systems and scale-out storage servers.

- removed (2019-11-01):
[0001193125-19-129284:note_history:31]
The results of operations for the three and nine months ended March 29, 2019 are not necessarily indicative of the results of operations to be expected for any subsequent interim period or for the Company’s fiscal year ending June 28, 2019. The Company operates and reports financial results on a fiscal year of 52 or 53 weeks ending on the Friday closest to June 30. Both the three and nine months ended March 29, 2019 and March 30, 2018 consisted of 13 weeks and 39 weeks, respectively. Fiscal year 2019, which ends on June 28, 2019, and fiscal year 2018, which ended on June 29, 2018, are both comprised of 52 weeks. The fiscal quarters ended March 29, 2019, December 28, 2018, September 28, 2018 and March 30, 2018, are also referred to herein as the “March 2019 quarter”, the “December 2018 quarter”, the "September 2018 quarter" and the “March 2018 quarter”, respectively.

- removed (2019-11-01):
[0001193125-19-129284:note_history:32]
Revenue Recognition

- removed (2019-11-01):
[0001193125-19-129284:note_history:33]
Effective June 30, 2018, the Company adopted a new revenue recognition policy in accordance with Accounting Standard Codification ("ASC") 606, Revenue from Contracts with Customers, using the modified retrospective transition approach as discussed in the section titled Recently Adopted Accounting Pronouncements in this Note 1. Prior to fiscal year 2019, the revenue recognition policy was based on ASC 605, Revenue Recognition. Under ASC 606, the Company determines revenue recognition through the following steps: (1) identification of the contract with a customer; (2) identification of the performance obligations in the contract; (3) determination of the transaction price; (4) allocation of the transaction price to the performance obligations in the contract; and (5) recognition of revenue when, or as, the Company satisfies a performance obligation.

- removed (2019-11-01):
[0001193125-19-129284:note_history:34]
Revenue from sales of products is generally recognized upon transfer of control to customers in an amount that reflects the consideration the Company expects to receive in exchange for those products, net of sales taxes. This typically occurs upon shipment from the Company. When applicable, the Company includes shipping charges billed to customers in Revenue and includes the related shipping costs in Cost of revenue on the Company's Condensed Consolidated Statements of Operations.

- removed (2019-11-01):
[0001193125-19-129284:note_history:35]
The Company records estimated variable consideration at the time of revenue recognition as a reduction to net revenue. Variable consideration generally consists of sales incentive programs, such as price protection and volume incentives aimed at increasing customer demand. For OEM sales, rebates are typically established by estimating the most likely amount of consideration expected to be received based on an OEM customer’s volume of purchases from Seagate or other agreed upon rebate programs. For the distribution and retailing channel, these sales incentive programs typically involve estimating the most likely amount of rebates related to a customer’s level of sales, order size, advertising or point of sale activity as well as the expected value of price protection adjustments based on historical analysis and forecasted pricing environment. Marketing development program costs are accrued and recorded as a reduction to revenue at the same time that the related revenue is recognized.

- removed (2019-11-01):
[0001193125-19-129284:note_history:36]
The Company elected a practical expedient to expense sales commissions when the commissions are incurred because the amortization period would have been one year or less. These costs are recorded as Marketing and administrative on the Company's Condensed Consolidated Statements of Operations.

- removed (2019-11-01):
[0001193125-19-129284:note_history:37]
In February 2016 and July 2018, the Financial Accounting Standards Board ("FASB") issued Accounting Standard Update ("ASU") 2016-02 (ASC Topic 842), Leases ASU 2018-10, Codification Improvements to Topic 842, and Leases, ASU 2018-11, Leases (ASC Topic 842), Target Improvements, respectively. These ASUs amend a number of aspects of lease accounting, including requiring lessees to recognize operating leases with a term greater than one year on their balance sheet as a right-of-use asset and corresponding lease liability, measured at the present value of the lease payments. The Company plans to adopt this guidance in the first quarter of fiscal year 2020. The Company is in the process of assessing the impact of these ASUs on its condensed consolidated financial statements.

- removed (2019-11-01):
[0001193125-19-129284:note_history:38]
In May 2014, the FASB issued ASU 2014-09 (ASC Topic 606), Revenue from Contracts with Customers, and FASB also issued certain interpretive clarifications on this new guidance which outlines a single comprehensive model for entities to use in accounting for revenue arising from contracts with customers and supersedes the revenue recognition guidance under ASC 605. It also requires entities to disclose both quantitative and qualitative information that enable financial statements users to understand the nature, amount, timing, and uncertainty of revenue and cash flows arising from contracts with customers. This ASU became effective and was adopted by the Company in the September 2018 quarter retrospectively with a cumulative adjustment to accumulated deficit at the date of adoption ("modified retrospective transition approach"). The Company has completed the adoption and implemented policies, processes and controls to support the new standard’s measurement and disclosure requirements.

- removed (2019-11-01):
[0001193125-19-129284:note_history:39]
The Company applied the ASC 606 using a modified retrospective transition approach to all contracts that were not completed as of June 29, 2018. Results for reporting periods beginning June 30, 2018 are presented under ASC 606, while prior period amounts were not adjusted and continue to be reported under the historical accounting standard. As a result of the adoption, the Company identified a change in revenue recognition timing on its product sales made to certain retail customers and started to recognize revenue when the Company transfers control to the applicable customers rather than deferring recognition until those customers sell the products. In addition, the Company established accruals for the variable consideration related to customer incentives on these arrangements. On the date of initial adoption, the Company removed the related deferred income on the product sales made to these customers and recorded estimates of the accrual for variable consideration through a cumulative adjustment to accumulated deficit. The cumulative effect of the change to the Company's Condensed Consolidated Balance Sheet from the adoption of ASC 606 was as follows:

- removed (2019-11-01):
[0001193125-19-129284:note_history:40]
| (Dollars in millions) |  | As of June 29, 2018 |  | Effect of adoption of ASC 606 |  | As of June 30, 2018 |
| Accounts receivable, net |  | $ | 1,184 |  |  | $ | 9 |  |  | $ | 1,193 |  |
| Inventory |  | $ | 1,053 |  |  | $ | (9 | ) |  | $ | 1,044 |  |
| Accrued expenses |  | $ | 598 |  |  | $ | (34 | ) |  | $ | 564 |  |
| Accumulated deficit |  | $ | (4,696 | ) |  | $ | 34 |  |  | $ | (4,662 | ) |

- removed (2019-11-01):
[0001193125-19-129284:note_history:41]
The impact of applying the new accounting standard on the Company's condensed consolidated financial statements for the three and nine months ended March 29, 2019 was not material.

- removed (2019-11-01):
[0001193125-19-129284:note_history:42]
In January 2016, the FASB issued ASU 2016-01 (ASC Subtopic 825-10), Financial Instruments—Overall Recognition and Measurement of Financial Assets and Financial Liabilities, as amended by ASU 2018-03, Financial Instruments—Overall: Technical Correction and Improvements, issued in February 2018. The amendments in these ASUs require entities to measure all equity investments at fair value with changes recognized through net income. Additionally, the amendments eliminate certain disclosure requirements related to financial instruments measured at amortized cost and add disclosures related to the measurement categories of financial assets and financial liabilities. These ASUs became effective and were adopted by the Company in the September 2018 quarter. For equity investments without readily determinable fair value, the Company elected the measurement alternative for measurement of equity investments, defined as cost, less impairments, if any, plus or minus changes resulting from observable price changes in orderly transactions for an identical or similar investment in the same issuer until the equity investments' fair value becomes readily determinable. The adoption of this guidance had no impact on the Company's condensed consolidated financial statements and disclosures.

- removed (2019-11-01):
[0001193125-19-129284:note_history:43]
In January 2017, the FASB issued ASU 2017-01 (ASC Topic 805), Business Combination: Clarifying the Definition of a Business. The amendments in this ASU change the definition of a business to assist with evaluating when a set of transferred assets and activities is a business. The Company adopted the guidance in the September 2018 quarter. The adoption of this guidance had no impact on the Company's condensed consolidated financial statements and disclosures.

- removed (2019-11-01):
[0001193125-19-129284:note_history:44]
In May 2017, the FASB issued ASU 2017-09 (ASC Topic 718), Stock Compensation: Scope of Modification Accounting. The amendments in this ASU provide guidance about which changes to the terms or conditions of a share-based payment award require an entity to apply modification accounting. The Company adopted the guidance in the September 2018 quarter. The adoption of this guidance had no impact on its condensed consolidated financial statements and disclosures.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- added (2019-11-01):
[0001628280-19-013092:note_history:45]
Credit Agreement

- added (2019-11-01):
[0001628280-19-013092:note_history:46]
The Company’s subsidiary, Seagate HDD Cayman, entered into a credit agreement (the “Credit Agreement”) on February 20, 2019, which was most recently amended on September 16, 2019. The Credit Agreement provides an up to $1.5 billion senior unsecured revolving credit facility (“Revolving Credit Facility”) and a term loan facility in an aggregate principal amount of $500 million (“Term Loan”). The Revolving Credit Facility has a final maturity of February 20, 2024 and the Term Loan has a final maturity date of September 16, 2025. The loans made under the Revolving Credit Facility and the Term Loan will bear interest at a rate of the London Interbank Offered Rate (“LIBOR”) plus a variable margin for each facility that will be determined based on the corporate credit rating of the Company. STX and certain of its material subsidiaries fully and unconditionally guarantee both the Revolving Credit Facility and the Term Loan. The Revolving Credit Facility also allows such facility to increase by an additional $100 million, provided that (i) there has been, and will be after giving effect to such increase, no default, (ii) the increase is at least $25 million, and (iii) the existing commitments under such facility receive 0.50% most favored nation protection. An aggregate amount of up to $75 million of the Revolving Credit Facility is available for the issuance of letters of credit, and an aggregate amount of up to $50 million of such facility is also available for swing line loans.

- added (2019-11-01):
[0001628280-19-013092:note_history:47]
On September 17, 2019, Seagate HDD Cayman borrowed the $500 million principal amount under the Term Loan and the proceeds were used to repurchase a portion of its outstanding senior notes. The Term Loan is repayable in quarterly installments of 1.25% of the original principal amount beginning on December 31, 2020, with the remaining balance payable upon maturity.

- changed (2019-11-01):
[0001628280-19-013092:note_history:48]
The Credit Agreement includes three financial covenants: (1) interest coverage ratio, (2) total leverage ratio, and (3) a minimum liquidity amount. The Company was in compliance with the covenants as of October 4, 2019 and expects to be in compliance for the next 12 months.
  (was, 2019-04-30, similarity 0.7422):
[0001193125-19-129284:note_history:48]
The 2019 Revolving Credit Facility includes three financial covenants: (1) interest coverage ratio, (2) total leverage ratio, and (3) a minimum liquidity amount. The Company was in compliance with the covenants as of March 29, 2019 and expects to be in compliance for the next 12 months.

- changed (2019-11-01):
[0001628280-19-013092:note_history:49]
As of October 4, 2019, no borrowings were drawn and no letters of credit or swing line loans had been utilized under the Revolving Credit Facility.
  (was, 2019-04-30, similarity 0.8561):
[0001193125-19-129284:note_history:49]
As of March 29, 2019, $200 million had been drawn and no letters of credit or swing line loans had been utilized under the 2019 Revolving Credit Facility.

- changed (2019-11-01):
[0001628280-19-013092:note_history:50]
Other Long-Term Debt
  (was, 2019-04-30, similarity 0.8235):
[0001193125-19-129284:note_history:50]
Long-Term Debt

- changed (2019-11-01):
[0001628280-19-013092:note_history:51]
$750 million Aggregate Principal Amount of 4.25% Senior Notes due March 2022 (the “2022 Notes”). The interest on the 2022 Notes is payable semi-annually on March 1 and September 1 of each year. The issuer under the 2022 Notes is Seagate HDD Cayman, and the obligations under the 2022 Notes are fully and unconditionally guaranteed, on a senior unsecured basis, by STX. On September 18, 2019, the principal amount of approximately $250 million was repurchased pursuant to cash tender offers for certain senior notes (the “Tender Offers”). The Company recorded a loss of $10 million, which was included in Other, net in the Company’s Condensed Consolidated Statements of Operations.
  (was, 2019-04-30, similarity 0.6852):
[0001193125-19-129284:note_history:51]
$750 million Aggregate Principal Amount of 4.25% Senior Notes due March 2022 (the “2022 Notes”). The interest on the 2022 Notes is payable semi-annually on March 1 and September 1 of each year. The issuer under the 2022 Notes is Seagate HDD Cayman, and the obligations under the 2022 Notes are fully and unconditionally guaranteed, on a senior unsecured basis, by the Company.

- changed (2019-11-01):
[0001628280-19-013092:note_history:52]
$1 billion Aggregate Principal Amount of 4.75% Senior Notes due June 2023 (the “2023 Notes”). The interest on the 2023 Notes is payable semi-annually on June 1 and December 1 of each year. The issuer under the 2023 Notes is Seagate HDD Cayman, and the obligations under the 2023 Notes are fully and unconditionally guaranteed, on a senior unsecured basis, by STX. On September 18, 2019, the principal amount of $200 million was repurchased pursuant to the Tender Offers. The Company recorded a loss of $10 million, which was included in Other, net in the Company’s Condensed Consolidated Statements of Operations.
  (was, 2019-04-30, similarity 0.7284):
[0001193125-19-129284:note_history:52]
$1 billion Aggregate Principal Amount of 4.75% Senior Notes due June 2023 (the “2023 Notes”). The interest on the 2023 Notes is payable semi-annually on June 1 and December 1 of each year. The issuer under the 2023 Notes is Seagate HDD Cayman, and the obligations under the 2023 Notes are fully and unconditionally guaranteed, on a senior unsecured basis, by the Company.

- changed (2019-11-01):
[0001628280-19-013092:note_history:53]
$500 million Aggregate Principal Amount of 4.875% Senior Notes due March 2024 (the “2024 Notes”).The interest on the 2024 Notes is payable semi-annually on March 1 and September 1 of each year. The issuer under the 2024 Notes is Seagate HDD Cayman, and the obligations under the 2024 Notes are fully and unconditionally guaranteed, on a senior unsecured basis, by STX.
  (was, 2019-04-30, similarity 0.9801):
[0001193125-19-129284:note_history:53]
$500 million Aggregate Principal Amount of 4.875% Senior Notes due March 2024 (the “2024 Notes”).The interest on the 2024 Notes is payable semi-annually on March 1 and September 1 of each year. The issuer under the 2024 Notes is Seagate HDD Cayman, and the obligations under the 2024 Notes are fully and unconditionally guaranteed, on a senior unsecured basis, by the Company.

- changed (2019-11-01):
[0001628280-19-013092:note_history:54]
$1 billion Aggregate Principal Amount of 4.75% Senior Notes due January 2025 (the “2025 Notes”). The interest on the 2025 Notes is payable semi-annually on January 1 and July 1 of each year. The issuer under the 2025 Notes is Seagate HDD Cayman, and the obligations under the 2025 Notes are fully and unconditionally guaranteed, on a senior unsecured basis, by STX. On September 18, 2019, the principal amount of approximately $170 million was repurchased pursuant to the Tender Offers. The Company recorded a loss of $8 million, which was included in Other, net in the Company’s Condensed Consolidated Statements of Operations.
  (was, 2019-04-30, similarity 0.7419):
[0001193125-19-129284:note_history:54]
$1 billion Aggregate Principal Amount of 4.75% Senior Notes due January 2025 (the “2025 Notes”). The interest on the 2025 Notes is payable semi-annually on January 1 and July 1 of each year. The issuer under the 2025 Notes is Seagate HDD Cayman, and the obligations under the 2025 Notes are fully and unconditionally guaranteed, on a senior unsecured basis, by the Company.

- changed (2019-11-01):
[0001628280-19-013092:note_history:55]
$700 million Aggregate Principal Amount of 4.875% Senior Notes due June 2027 (the “2027 Notes”). The interest on the Notes is payable semi-annually on June 1 and December 1 of each year. The issuer under the 2027 Notes is Seagate HDD Cayman, and the obligations under the 2027 Notes are fully and unconditionally guaranteed, on a senior unsecured basis, by STX.
  (was, 2019-04-30, similarity 0.9798):
[0001193125-19-129284:note_history:55]
$700 million Aggregate Principal Amount of 4.875% Senior Notes due June 2027 (the “2027 Notes”). The interest on the Notes is payable semi-annually on June 1 and December 1 of each year. The issuer under the 2027 Notes is Seagate HDD Cayman, and the obligations under the 2027 Notes are fully and unconditionally guaranteed, on a senior unsecured basis, by the Company.

- changed (2019-11-01):
[0001628280-19-013092:note_history:56]
$500 million Aggregate Principal Amount of 5.75% Senior Notes due December 2034 (the “2034 Notes”). The interest on the 2034 Notes is payable semi-annually on June 1 and December 1 of each year. The issuer under the 2034 Notes is Seagate HDD Cayman, and the obligations under the 2034 Notes are fully and unconditionally guaranteed, on a senior unsecured basis, by STX.
  (was, 2019-04-30, similarity 0.9802):
[0001193125-19-129284:note_history:56]
$500 million Aggregate Principal Amount of 5.75% Senior Notes due December 2034 (the “2034 Notes”). The interest on the 2034 Notes is payable semi-annually on June 1 and December 1 of each year. The issuer under the 2034 Notes is Seagate HDD Cayman, and the obligations under the 2034 Notes are fully and unconditionally guaranteed, on a senior unsecured basis, by the Company.

- changed (2019-11-01):
[0001628280-19-013092:note_history:57]
At October 4, 2019, future principal payments on long-term debt were as follows (in millions):
  (was, 2019-04-30, similarity 0.9432):
[0001193125-19-129284:note_history:57]
At March 29, 2019, future principal payments on long-term debt were as follows (in millions):

- changed (2019-11-01):
[0001628280-19-013092:note_history:58]
| Fiscal Year |  | Amount |
| Remainder of 2020 |  | $ | — |  |
| 2021 |  | 19 |  |
| 2022 |  | 525 |  |
| 2023 |  | 766 |  |
| 2024 |  | 525 |  |
| Thereafter |  | 2,336 |  |
| Total |  | $ | 4,171 |  |
  (was, 2019-04-30, similarity 0.9873):
[0001193125-19-129284:note_history:58]
| Fiscal Year |  | Amount |
| Remainder of 2019 |  | $ | — |  |
| 2020 |  | — |  |
| 2021 |  | — |  |
| 2022 |  | 750 |  |
| 2023 |  | 951 |  |
| Thereafter |  | 2,862 |  |
| Total |  | $ | 4,563 |  |

- removed (2019-11-01):
[0001193125-19-129284:note_history:59]
Revolving Credit Facility

- removed (2019-11-01):
[0001193125-19-129284:note_history:60]
On February 20, 2019, the Company terminated its senior unsecured revolving credit facility scheduled to expire on January 15, 2020, under which the Company was able to draw up to $700 million. Upon termination, the Company and its subsidiary Seagate HDD Cayman entered into a new credit agreement (the "2019 Revolving Credit Facility") which provides the Company with a $1.3 billion senior unsecured revolving credit facility. The term of the 2019 Revolving Credit Facility is through February 20, 2024. The loans made under the 2019 Revolving Credit Facility will bear interest at a rate of LIBOR plus a variable margin that will be determined based on the corporate credit rating of the Company. The Company and certain other material subsidiaries of the Company fully and unconditionally guarantee the revolving credit facility. The 2019 Revolving Credit Facility also allows the Company to increase the facility by up to an aggregate of $300 million, provided that (i) there has been, and will be after giving effect to such increase, no default, (ii) the increase is at least $25 million, and (iii) the existing commitments under the facility receive 0.50% most favored nation protection. An aggregate amount of up to $75 million of the facility is available for the issuance of letters of credit, and an aggregate amount of up to $50 million of the facility is also available for swing line loans.

- removed (2019-11-01):
[0001193125-19-129284:note_history:61]
$800 million Aggregate Principal Amount of 3.75% Senior Notes due November 2018 (the “2018 Notes”). The Company recorded a loss of approximately $1 million and $3 million on repurchases during the three and nine months ended March 30, 2018, respectively, which is included in Other, net on the Company's Condensed Consolidated Statements of Operations. On November 15, 2018, the 2018 Notes matured and the Company repaid the entire outstanding principal amount of $499 million, plus accrued and unpaid interest.


## us-gaap:DebtSecuritiesAvailableForSaleTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- added (2019-11-01):
[0001628280-19-013092:note_history:62]
| (Dollars in millions) |  | AmortizedCost |  | UnrealizedGain/(Loss) |  | FairValue |
| Available-for-sale securities: |  |  |  |  |  |  |  |  |  |
| Money market funds |  | $ | 417 |  |  | $ | — |  |  | $ | 417 |  |
| Time deposits and certificates of deposit |  | 133 |  |  | — |  |  | 133 |  |
| Other debt securities |  | 7 |  |  | — |  |  | 7 |  |
| Total |  | $ | 557 |  |  | $ | — |  |  | $ | 557 |  |
| Included in Cash and cash equivalents |  |  |  |  |  |  |  | $ | 548 |  |
| Included in Other current assets |  |  |  |  |  |  |  | 2 |  |
| Included in Other assets, net |  |  |  |  |  | 7 |  |
| Total |  |  |  |  |  |  |  | $ | 557 |  |

- changed (2019-11-01):
[0001628280-19-013092:note_history:63]
The following table summarizes, by major type, the fair value and amortized cost of the Company’s investments as of October 4, 2019:
  (was, 2019-04-30, similarity 0.9606):
[0001193125-19-129284:note_history:63]
The following table summarizes, by major type, the fair value and amortized cost of the Company’s investments as of March 29, 2019:

- added (2019-11-01):
[0001628280-19-013092:note_history:64]
| (Dollars in millions) |  | AmortizedCost |  | UnrealizedGain/(Loss) |  | FairValue |
| Available-for-sale debt securities: |  |  |  |  |  |  |  |  |  |
| Money market funds |  | $ | 471 |  |  | $ | — |  |  | $ | 471 |  |
| Time deposits and certificates of deposit |  | 351 |  |  | — |  |  | 351 |  |
| Other debt securities |  | 10 |  |  | — |  |  | 10 |  |
| Total |  | $ | 832 |  |  | $ | — |  |  | $ | 832 |  |
| Included in Cash and cash equivalents |  |  |  |  |  |  |  | $ | 820 |  |
| Included in Other current assets |  |  |  |  |  |  |  | 2 |  |
| Included in Other assets, net |  |  |  |  |  | 10 |  |
| Total |  |  |  |  |  |  |  | $ | 832 |  |

- removed (2019-11-01):
[0001193125-19-129284:note_history:65]
| (Dollars in millions) |  | AmortizedCost |  | UnrealizedGain/(Loss) |  | FairValue |
| Available-for-sale debt securities: |  |  |  |  |  |  |  |  |  |
| Money market funds |  | $ | 239 |  |  | $ | — |  |  | $ | 239 |  |
| Time deposits and certificates of deposit |  | 300 |  |  | — |  |  | 300 |  |
| Total |  | $ | 539 |  |  | $ | — |  |  | $ | 539 |  |
| Included in Cash and cash equivalents |  |  |  |  |  |  |  | $ | 536 |  |
| Included in Other current assets |  |  |  |  |  |  |  | 3 |  |
| Total |  |  |  |  |  |  |  | $ | 539 |  |

- removed (2019-11-01):
[0001193125-19-129284:note_history:66]
| (Dollars in millions) |  | AmortizedCost |  | UnrealizedGain/(Loss) |  | FairValue |
| Available-for-sale securities: |  |  |  |  |  |  |  |  |  |
| Money market funds |  | $ | 621 |  |  | $ | — |  |  | $ | 621 |  |
| Time deposits and certificates of deposit |  | 395 |  |  | — |  |  | 395 |  |
| Total |  | $ | 1,016 |  |  | $ | — |  |  | $ | 1,016 |  |
| Included in Cash and cash equivalents |  |  |  |  |  |  |  | $ | 1,012 |  |
| Included in Other current assets |  |  |  |  |  |  |  | 4 |  |
| Total |  |  |  |  |  |  |  | $ | 1,016 |  |


## us-gaap:ScheduleOfCarryingValuesAndEstimatedFairValuesOfDebtInstrumentsTableTextBlock (debt) — matched_by: no_current_note, score: 0.0

- removed (2019-11-01):
[0001193125-19-129284:note_history:67]
orded at amortized cost and its fair value approximated the carrying value at June 29, 2018. As of


## us-gaap:ScheduleOfMaturitiesOfLongTermDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2019-11-01):
[0001628280-19-013092:note_history:68]
At October 4, 2019, future principal payments on long-term debt were as follows (in millions):
  (was, 2019-04-30, similarity 0.9432):
[0001193125-19-129284:note_history:68]
At March 29, 2019, future principal payments on long-term debt were as follows (in millions):

- changed (2019-11-01):
[0001628280-19-013092:note_history:69]
| Fiscal Year |  | Amount |
| Remainder of 2020 |  | $ | — |  |
| 2021 |  | 19 |  |
| 2022 |  | 525 |  |
| 2023 |  | 766 |  |
| 2024 |  | 525 |  |
| Thereafter |  | 2,336 |  |
| Total |  | $ | 4,171 |  |
  (was, 2019-04-30, similarity 0.9873):
[0001193125-19-129284:note_history:69]
| Fiscal Year |  | Amount |
| Remainder of 2019 |  | $ | — |  |
| 2020 |  | — |  |
| 2021 |  | — |  |
| 2022 |  | 750 |  |
| 2023 |  | 951 |  |
| Thereafter |  | 2,862 |  |
| Total |  | $ | 4,563 |  |


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- added (2019-11-01):
[0001628280-19-013092:note_history:70]
|  |  | For the Three Months Ended |
| (Dollars in millions) |  | October 4, 2019 |  | September 28, 2018 |
| Revenues by Channel |  |  |  |  |  |
| OEMs |  | $ | 1,820 |  |  | $ | 2,138 |  |
| Distributors |  | 461 |  |  | 534 |  |
| Retailers |  | 297 |  |  | 319 |  |
| Total |  | $ | 2,578 |  |  | $ | 2,991 |  |
| Revenues by Geography(1) |  |  |  |  |
| Americas |  | $ | 835 |  |  | $ | 1,006 |  |
| EMEA |  | 465 |  |  | 517 |  |
| Asia Pacific |  | 1,278 |  |  | 1,468 |  |
| Total |  | $ | 2,578 |  |  | $ | 2,991 |  |

- removed (2019-11-01):
[0001193125-19-129284:note_history:71]
|  |  | For the Three Months Ended |  | For the Nine Months Ended |
| (Dollars in million) |  | March 29, 2019 |  | March 30, 2018 |  | March 29, 2019 |  | March 30, 2018 |
| Revenues by Channel |  |  |  |  |  |  |  |  |  |
| OEMs |  | $ | 1,568 |  |  | $ | 1,971 |  |  | $ | 5,571 |  |  | $ | 5,801 |  |
| Distributors |  | 411 |  |  | 477 |  |  | 1,388 |  |  | 1,406 |  |
| Retailers |  | 334 |  |  | 355 |  |  | 1,060 |  |  | 1,142 |  |
| Total |  | $ | 2,313 |  |  | $ | 2,803 |  |  | $ | 8,019 |  |  | $ | 8,349 |  |
| Revenues by Geography(1) |  |  |  |  |  |  |  |  |
| Americas |  | $ | 796 |  |  | $ | 912 |  |  | $ | 2,533 |  |  | $ | 2,700 |  |
| EMEA |  | 448 |  |  | 522 |  |  | 1,563 |  |  | 1,561 |  |
| Asia Pacific |  | 1,069 |  |  | 1,369 |  |  | 3,923 |  |  | 4,088 |  |
| Total |  | $ | 2,313 |  |  | $ | 2,803 |  |  | $ | 8,019 |  |  | $ | 8,349 |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- added (2019-11-01):
[0001628280-19-013092:note_history:72]
|  |  | For the Three Months Ended |
| (Dollars in millions) |  | October 4, 2019 |  | September 28, 2018 |
| Revenues by Channel |  |  |  |  |  |
| OEMs |  | $ | 1,820 |  |  | $ | 2,138 |  |
| Distributors |  | 461 |  |  | 534 |  |
| Retailers |  | 297 |  |  | 319 |  |
| Total |  | $ | 2,578 |  |  | $ | 2,991 |  |
| Revenues by Geography(1) |  |  |  |  |
| Americas |  | $ | 835 |  |  | $ | 1,006 |  |
| EMEA |  | 465 |  |  | 517 |  |
| Asia Pacific |  | 1,278 |  |  | 1,468 |  |
| Total |  | $ | 2,578 |  |  | $ | 2,991 |  |

- removed (2019-11-01):
[0001193125-19-129284:note_history:73]
|  |  | For the Three Months Ended |  | For the Nine Months Ended |
| (Dollars in million) |  | March 29, 2019 |  | March 30, 2018 |  | March 29, 2019 |  | March 30, 2018 |
| Revenues by Channel |  |  |  |  |  |  |  |  |  |
| OEMs |  | $ | 1,568 |  |  | $ | 1,971 |  |  | $ | 5,571 |  |  | $ | 5,801 |  |
| Distributors |  | 411 |  |  | 477 |  |  | 1,388 |  |  | 1,406 |  |
| Retailers |  | 334 |  |  | 355 |  |  | 1,060 |  |  | 1,142 |  |
| Total |  | $ | 2,313 |  |  | $ | 2,803 |  |  | $ | 8,019 |  |  | $ | 8,349 |  |
| Revenues by Geography(1) |  |  |  |  |  |  |  |  |
| Americas |  | $ | 796 |  |  | $ | 912 |  |  | $ | 2,533 |  |  | $ | 2,700 |  |
| EMEA |  | 448 |  |  | 522 |  |  | 1,563 |  |  | 1,561 |  |
| Asia Pacific |  | 1,069 |  |  | 1,369 |  |  | 3,923 |  |  | 4,088 |  |
| Total |  | $ | 2,313 |  |  | $ | 2,803 |  |  | $ | 8,019 |  |  | $ | 8,349 |  |


## us-gaap:RevenueRecognitionPolicyTextBlock (revenue_recognition_policy) — matched_by: no_current_note, score: 0.0

- removed (2019-11-01):
[0001193125-19-129284:note_history:74]
Revenue Recognition

- removed (2019-11-01):
[0001193125-19-129284:note_history:75]
Effective June 30, 2018, the Company adopted a new revenue recognition policy in accordance with Accounting Standard Codification ("ASC") 606, Revenue from Contracts with Customers, using the modified retrospective transition approach as discussed in the section titled Recently Adopted Accounting Pronouncements in this Note 1. Prior to fiscal year 2019, the revenue recognition policy was based on ASC 605, Revenue Recognition. Under ASC 606, the Company determines revenue recognition through the following steps: (1) identification of the contract with a customer; (2) identification of the performance obligations in the contract; (3) determination of the transaction price; (4) allocation of the transaction price to the performance obligations in the contract; and (5) recognition of revenue when, or as, the Company satisfies a performance obligation.

- removed (2019-11-01):
[0001193125-19-129284:note_history:76]
Revenue from sales of products is generally recognized upon transfer of control to customers in an amount that reflects the consideration the Company expects to receive in exchange for those products, net of sales taxes. This typically occurs upon shipment from the Company. When applicable, the Company includes shipping charges billed to customers in Revenue and includes the related shipping costs in Cost of revenue on the Company's Condensed Consolidated Statements of Operations.

- removed (2019-11-01):
[0001193125-19-129284:note_history:77]
The Company records estimated variable consideration at the time of revenue recognition as a reduction to net revenue. Variable consideration generally consists of sales incentive programs, such as price protection and volume incentives aimed at increasing customer demand. For OEM sales, rebates are typically established by estimating the most likely amount of consideration expected to be received based on an OEM customer’s volume of purchases from Seagate or other agreed upon rebate programs. For the distribution and retailing channel, these sales incentive programs typically involve estimating the most likely amount of rebates related to a customer’s level of sales, order size, advertising or point of sale activity as well as the expected value of price protection adjustments based on historical analysis and forecasted pricing environment. Marketing development program costs are accrued and recorded as a reduction to revenue at the same time that the related revenue is recognized.

- removed (2019-11-01):
[0001193125-19-129284:note_history:78]
The Company elected a practical expedient to expense sales commissions when the commissions are incurred because the amortization period would have been one year or less. These costs are recorded as Marketing and administrative on the Company's Condensed Consolidated Statements of Operations.


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: tag_name, score: 1.0

- changed (2019-11-01):
[0001628280-19-013092:note_history:79]
On October 28, 2019, the Company’s Board of Directors declared a quarterly cash dividend of $0.65 per share, which will be payable on January 8, 2020 to shareholders of record as of the close of business on December 26, 2019.
  (was, 2019-04-30, similarity 0.938):
[0001193125-19-129284:note_history:79]
On April 30, 2019, the Company’s Board of Directors declared a quarterly cash dividend of $0.63 per share, which will be payable on July 3, 2019 to shareholders of record as of the close of business on June 19, 2019.
