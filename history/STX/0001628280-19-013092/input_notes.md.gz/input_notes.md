# STX notes — 0001628280-19-013092


## us-gaap:OrganizationConsolidationBasisOfPresentationBusinessDescriptionAndAccountingPoliciesTextBlock

[0001628280-19-013092:notes:1]
[same as prior period, unchanged from 0001193125-19-129284:notes:136]

[0001628280-19-013092:notes:2]
[same as prior period, unchanged from 0001193125-19-129284:notes:137]

[0001628280-19-013092:notes:3]
Seagate Technology plc (“STX”) and its subsidiaries (collectively, unless the context otherwise indicates, the “Company”) is a leading provider of data storage technology and solutions. Its principal products are hard disk drives, commonly referred to as disk drives, hard drives or HDDs. In addition to HDDs, the Company produces a broad range of data storage products including solid state drives (“SSDs”), solid state hybrid drives (“SSHDs”) and storage subsystems.

[0001628280-19-013092:notes:4]
Hard disk drives are devices that store digitally encoded data on rapidly rotating disks with magnetic surfaces. Disk drives continue to be the primary medium of mass data storage due to their performance attributes, reliability, high quality and cost effectiveness. Complementing existing data center storage architecture, solid-state drives use integrated circuit assemblies as memory to store data, and most SSDs use NAND flash memory. In addition to HDDs and SSDs, SSHDs combine the features of SSDs and HDDs in the same unit, containing a high capacity hard disk drive and a smaller SSD acting as a cache to improve performance of frequently accessed data.

[0001628280-19-013092:notes:5]
The Company’s HDD products are designed for nearline and mission critical applications in enterprise servers and storage systems; edge non-compute applications, where its products are designed for a wide variety of end user devices such as portable external storage systems, video and image applications, including surveillance systems, network-attached storage (“NAS”), digital video recorders (“DVRs”) and gaming consoles; and edge compute applications, where its products are designed primarily for desktop and mobile computing. The Company’s SSD product portfolio is mainly comprised of Serial Attached SCSI (“SAS”) and Non-Volatile Memory Express (“NVMe”) and is designed for applications in enterprise servers and storage systems.

[0001628280-19-013092:notes:6]
The Company’s enterprise data solutions (“EDS”) portfolio includes storage subsystems for enterprises, cloud service providers, scale-out storage servers and original equipment manufacturers (“OEMs”).

[0001628280-19-013092:notes:7]
[same as prior period, unchanged from 0001193125-19-129284:notes:142]

[0001628280-19-013092:notes:8]
The Company’s unaudited condensed consolidated financial statements include the accounts of the Company and all its wholly-owned and majority-owned subsidiaries, after elimination of intercompany transactions and balances.

[0001628280-19-013092:notes:9]
The preparation of financial statements in accordance with U.S. generally accepted accounting principles requires management to make estimates and assumptions that affect the amounts reported in the Company’s condensed consolidated financial statements and accompanying notes. Actual results could differ materially from those estimates. The methods, estimates and judgments the Company uses in applying its most critical accounting policies have a significant impact on the results the Company reports in its condensed consolidated financial statements.

[0001628280-19-013092:notes:10]
The Company’s consolidated financial statements for the fiscal year ended June 28, 2019, are included in its Annual Report on Form 10-K, as filed with the United States Securities and Exchange Commission (“SEC”) on August 2, 2019. The Company believes that the disclosures included in these unaudited condensed consolidated financial statements, when read in conjunction with its consolidated financial statements as of June 28, 2019, and the notes thereto, are adequate to make the information presented not misleading.

[0001628280-19-013092:notes:11]
Fiscal Year

[0001628280-19-013092:notes:12]
The Company operates and reports financial results on a fiscal year of 52 or 53 weeks ending on the Friday closest to June 30. The three months ended October 4, 2019 consisted of 14 weeks and the three months ended September 28, 2018 consisted of 13 weeks. Fiscal year 2020, which ends on July 3, 2020, is comprised of 53 weeks and fiscal year 2019, which ended on June 28, 2019, is comprised of 52 weeks. The fiscal quarters ended October 4, 2019, June 28, 2019 and September 28, 2018, are also referred to herein as the “September 2019 quarter”, the “June 2019 quarter”, and the “September 2018 quarter”, respectively. The results of operations for the three months ended October 4, 2019 are not necessarily indicative of the results of operations to be expected for any subsequent interim period or for the Company’s fiscal year ending July 3, 2020.

[0001628280-19-013092:notes:13]
[same as prior period, unchanged from 0001193125-19-129284:notes:144]

[0001628280-19-013092:notes:14]
Except for the change in the Company’s other long-lived assets and leases policies described below, there have been no material changes to the Company’s significant accounting policies disclosed in Note 1 - Basis of Presentation and Summary of Significant Accounting Policies of “Financial Statements and Supplementary Data” contained in Part II, Item 8 of the Company’s Annual Report on Form 10-K for the fiscal year ended June 28, 2019, as filed with the SEC on August 2, 2019.

[0001628280-19-013092:notes:15]
Other Long-Lived Assets

[0001628280-19-013092:notes:16]
In accordance with its policy, the Company reviews the estimated useful lives of its fixed assets on an ongoing basis. This review indicated that the actual lives of certain manufacturing equipment at its manufacturing facilities were longer than the estimated useful lives used for deprecation purposes in the Company’s condensed consolidated financial statements. As a result, effective June 29, 2019, the Company changed its estimate of the useful lives of its manufacturing equipment from a range of three to five years to a range of three to seven years. The effect of this change in estimate increased the September 2019 quarter net income by $23 million and diluted earnings per share by $0.09.

[0001628280-19-013092:notes:17]
Leases

[0001628280-19-013092:notes:18]
Effective June 29, 2019, the Company adopted a new accounting policy for leases in accordance with Accounting Standard Codification (“ASC”) 842, Leases, using the modified retrospective approach. Accordingly, the Company applied the new lease accounting standard prospectively to leases existing or commencing on or after June 29, 2019. The Company elected to apply the practical expedients which allow for not reassessing whether existing contracts contain leases, the classification of existing leases and whether the existing initial direct costs meet the new definition. In addition, the Company elected to combine lease and non-lease components for facility leases and to not recognize right-of-use (“ROU”) assets and lease liabilities for leases with an initial term of 12 months of less on the balance sheet.

[0001628280-19-013092:notes:19]
The Company determines if an arrangement is a lease or contains a lease at inception. ROU assets are included in Other assets, net and lease liabilities are included in Accrued expenses and Other non-current liabilities on the Company’s Condensed Consolidated Balance Sheets. ROU assets represent the Company’s right to use an underlying asset for the lease term and the corresponding lease liabilities represent its obligation to make lease payments arising from the lease.

[0001628280-19-013092:notes:20]
Lease liabilities are measured at the present value of the remaining lease payments and ROU assets are based on the lease liability, adjusted for lease prepayments, lease incentives received and the lessee’s initial direct costs. As the Company’s leases do not provide an implicit rate, the net present value of future minimum lease payments is determined using the Company’s estimated incremental borrowing rate based on the information available at the lease commencement date. Additionally, the Company’s lease term may include options to extend or terminate the lease. These options are reflected in the ROU asset and lease liability when it is reasonably certain that the Company will exercise the option. The Company’s lease agreements do not contain any material residual value guarantees.

[0001628280-19-013092:notes:21]
The Company recognizes lease expense on a straight-line basis over the lease term. Variable lease payments not dependent on an index or a rate primarily consist of common area maintenance charges, are expensed as incurred, and are not included in the ROU asset and lease liability calculation. The total operating and variable lease costs were included in operating expenses in the Company’s Condensed Consolidated Statements of Operations.

[0001628280-19-013092:notes:22]
Recently Adopted Accounting Pronouncements

[0001628280-19-013092:notes:23]
In February 2016, the Financial Accounting Standards Board (“FASB”) issued Accounting Standard Update (“ASU”) 2016-02 (ASC Topic 842), Leases and subsequently issued certain interpretive clarifications on this new guidance which amends a number of aspects of lease accounting, including requiring a lessee to recognize an ROU asset and corresponding lease liability for operating leases and enhanced disclosures. As of June 29, 2019, adoption of the standard resulted in the recognition of ROU assets and corresponding current and non-current lease liabilities of $115 million, $17 million and $57 million, respectively, on the Company’s Condensed Consolidated Balance Sheet, primarily relating to real estate operating leases. The adoption of this ASU did not have a material impact on the Company’s other condensed consolidated financial statements. For information regarding the impact of ASC 842 adoption, see Summary of Significant Accounting Policies - Leases above and Note 5. Leases.

[0001628280-19-013092:notes:24]
In February 2018, the FASB issued ASU 2018-02 (ASC Topic 220), Income Statement—Reporting Comprehensive Income: Reclassification of Certain Tax Effects from Accumulated Other Comprehensive Income. This ASU was issued following the enactment of the U.S. Tax Cuts and Jobs Act of 2017 (the “Tax Act”) and permits entities to elect a reclassification from accumulated other comprehensive income to retained earnings for stranded tax effects resulting from the Tax Act. This ASU became effective and the Company adopted the guidance in the September 2019 quarter. The Company has elected not to reclassify the stranded amounts. The adoption of this guidance did not have a material impact on its condensed consolidated financial statements and disclosures.

[0001628280-19-013092:notes:25]
Recently Issued Accounting Pronouncements

[0001628280-19-013092:notes:26]
In August 2018, the FASB issued ASU 2018-15 (ASC Subtopic 350-40), Intangibles - Goodwill and Other - Internal-Use Software - Customer’s Accounting for Implementation Costs Incurred in a Cloud Computing Arrangement That is a Service

[0001628280-19-013092:notes:27]
Contract. This ASU aligns the accounting for capitalizing implementation costs incurred in a hosting arrangement that is a service contract with the accounting for implementation costs incurred to develop or obtain internal-use software. The Company is required to adopt the guidance in the first quarter of fiscal year 2021. Early adoption is permitted. The Company is in the process of assessing the impact of this ASU on its condensed consolidated financial statements.

[0001628280-19-013092:notes:28]
In June 2016, the FASB issued ASU 2016-13 (ASC Topic 326), Financial Instruments—Credit Losses: Measurement of Credit Losses on Financial Instruments. This ASU amends the requirement on the measurement and recognition of expected credit losses for financial assets held. The Company is required to adopt this guidance in the first quarter of fiscal year 2021. The Company is in the process of assessing the impact of this ASU on its condensed consolidated financial statements.


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0001628280-19-013092:notes:29]
Balance Sheet Information
Available-for-sale Debt Securities

[0001628280-19-013092:notes:30]
The following table summarizes, by major type, the fair value and amortized cost of the Company’s investments as of October 4, 2019:

[0001628280-19-013092:notes:31]
| (Dollars in millions) |  | AmortizedCost |  | UnrealizedGain/(Loss) |  | FairValue |
| Available-for-sale debt securities: |  |  |  |  |  |  |  |  |  |
| Money market funds |  | $ | 471 |  |  | $ | — |  |  | $ | 471 |  |
| Time deposits and certificates of deposit |  | 351 |  |  | — |  |  | 351 |  |
| Other debt securities |  | 10 |  |  | — |  |  | 10 |  |
| Total |  | $ | 832 |  |  | $ | — |  |  | $ | 832 |  |
| Included in Cash and cash equivalents |  |  |  |  |  |  |  | $ | 820 |  |
| Included in Other current assets |  |  |  |  |  |  |  | 2 |  |
| Included in Other assets, net |  |  |  |  |  | 10 |  |
| Total |  |  |  |  |  |  |  | $ | 832 |  |

[0001628280-19-013092:notes:32]
As of October 4, 2019, the Company’s Other current assets included $2 million in restricted cash and investments held as collateral at banks for various performance obligations.

[0001628280-19-013092:notes:33]
As of October 4, 2019, the Company had no material available-for-sale debt securities that had been in a continuous unrealized loss position for a period greater than 12 months. The Company determined no available-for-sale debt securities were other-than-temporarily impaired as of October 4, 2019.

[0001628280-19-013092:notes:34]
The fair value and amortized cost of the Company’s investments classified as available-for-sale debt securities as of October 4, 2019, by remaining contractual maturity were as follows:

[0001628280-19-013092:notes:35]
| (Dollars in millions) |  | AmortizedCost |  | FairValue |
| Due in less than 1 year |  | $ | 822 |  |  | $ | 822 |  |
| Due in 1 to 5 years |  | 6 |  |  | 6 |  |
| Due in 6 to 10 years |  | — |  |  | — |  |
| Thereafter |  | 4 |  |  | 4 |  |
| Total |  | $ | 832 |  |  | $ | 832 |  |

[0001628280-19-013092:notes:36]
The following table summarizes, by major type, the fair value and amortized cost of the Company’s investments as of June 28, 2019:

[0001628280-19-013092:notes:37]
| (Dollars in millions) |  | AmortizedCost |  | UnrealizedGain/(Loss) |  | FairValue |
| Available-for-sale securities: |  |  |  |  |  |  |  |  |  |
| Money market funds |  | $ | 417 |  |  | $ | — |  |  | $ | 417 |  |
| Time deposits and certificates of deposit |  | 133 |  |  | — |  |  | 133 |  |
| Other debt securities |  | 7 |  |  | — |  |  | 7 |  |
| Total |  | $ | 557 |  |  | $ | — |  |  | $ | 557 |  |
| Included in Cash and cash equivalents |  |  |  |  |  |  |  | $ | 548 |  |
| Included in Other current assets |  |  |  |  |  |  |  | 2 |  |
| Included in Other assets, net |  |  |  |  |  | 7 |  |
| Total |  |  |  |  |  |  |  | $ | 557 |  |

[0001628280-19-013092:notes:38]
As of June 28, 2019, the Company’s Other current assets included $2 million in restricted cash and investments held as collateral at banks for various performance obligations.

[0001628280-19-013092:notes:39]
As of June 28, 2019, the Company had no material available-for-sale securities that had been in a continuous unrealized loss position for a period greater than 12 months. The Company determined no available-for-sale securities were other-than-temporarily impaired as of June 28, 2019.

[0001628280-19-013092:notes:40]
[same as prior period, unchanged from 0001193125-19-129284:notes:199]

[0001628280-19-013092:notes:41]
The following table provides a summary of cash, cash equivalents and restricted cash reported on the Company’s Condensed Consolidated Balance Sheets that reconciles to the corresponding amount in its Condensed Consolidated Statements of Cash Flows:

[0001628280-19-013092:notes:42]
| (Dollars in millions) |  | October 4, 2019 |  | June 28, 2019 |  | September 28, 2018 |  | June 29, 2018 |
| Cash and cash equivalents |  | $ | 1,784 |  |  | $ | 2,220 |  |  | $ | 1,942 |  |  | $ | 1,853 |  |
| Restricted cash included in Other current assets |  | 2 |  |  | 31 |  |  | 3 |  |  | 4 |  |
| Total cash, cash equivalents and restricted cash presented on the Statements of Cash Flows |  | $ | 1,786 |  |  | $ | 2,251 |  |  | $ | 1,945 |  |  | $ | 1,857 |  |

[0001628280-19-013092:notes:43]
[same as prior period, unchanged from 0001193125-19-129284:notes:200]

[0001628280-19-013092:notes:44]
The following table provides details of the inventory balance sheet item:

[0001628280-19-013092:notes:45]
| (Dollars in millions) |  | October 4, 2019 |  | June 28, 2019 |
| Raw materials and components |  | $ | 352 |  |  | $ | 336 |  |
| Work-in-process |  | 305 |  |  | 217 |  |
| Finished goods |  | 384 |  |  | 417 |  |
| Total inventories |  | $ | 1,041 |  |  | $ | 970 |  |

[0001628280-19-013092:notes:46]
[same as prior period, unchanged from 0001193125-19-129284:notes:201]

[0001628280-19-013092:notes:47]
The components of property, equipment and leasehold improvements, net, were as follows:

[0001628280-19-013092:notes:48]
| (Dollars in millions) |  | October 4, 2019 |  | June 28, 2019 |
| Property, equipment and leasehold improvements |  | $ | 9,994 |  |  | $ | 9,835 |  |
| Accumulated depreciation and amortization |  | (8,003 | ) |  | (7,966 | ) |
| Property, equipment and leasehold improvements, net |  | $ | 1,991 |  |  | $ | 1,869 |  |

[0001628280-19-013092:notes:49]
[same as prior period, unchanged from 0001193125-19-129284:notes:203]

[0001628280-19-013092:notes:50]
The following table provides details of the accrued expenses balance sheet item:

[0001628280-19-013092:notes:51]
| (Dollars in millions) |  | October 4, 2019 |  | June 28, 2019 |
| Dividends payable |  | $ | 165 |  |  | $ | 170 |  |
| Other accrued expenses |  | 399 |  |  | 382 |  |
| Total accrued expenses |  | $ | 564 |  |  | $ | 552 |  |

[0001628280-19-013092:notes:52]
[same as prior period, unchanged from 0001193125-19-129284:notes:204]

[0001628280-19-013092:notes:53]
The components of AOCI, net of tax, were as follows:

[0001628280-19-013092:notes:54]
| (Dollars in millions) |  | Unrealized Gains/(Losses) on Cash Flow Hedges |  | Unrealized Gains/(Losses) on Available-for-Sale Debt Securities |  | Unrealized Gains/(Losses) on Post-Retirement Plans |  | Foreign Currency Translation Adjustments |  | Total |
| Balance at June 28, 2019 |  | $ | — |  |  | $ | — |  |  | $ | (20 | ) |  | $ | (14 | ) |  | $ | (34 | ) |
| Other comprehensive income (loss) before reclassifications |  | (1 | ) |  | — |  |  | — |  |  | (5 | ) |  | (6 | ) |
| Amounts reclassified from AOCI |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Other comprehensive income (loss) |  | (1 | ) |  | — |  |  | — |  |  | (5 | ) |  | (6 | ) |
| Balance at October 4, 2019 |  | $ | (1 | ) |  | $ | — |  |  | $ | (20 | ) |  | $ | (19 | ) |  | $ | (40 | ) |
| Balance at June 29, 2018 |  | $ | — |  |  | $ | — |  |  | $ | (4 | ) |  | $ | (12 | ) |  | $ | (16 | ) |
| Other comprehensive income (loss) before reclassifications |  | 3 |  |  | — |  |  | — |  |  | 2 |  |  | 5 |  |
| Amounts reclassified from AOCI |  | (1 | ) |  | — |  |  | — |  |  | — |  |  | (1 | ) |
| Other comprehensive income (loss) |  | 2 |  |  | — |  |  | — |  |  | 2 |  |  | 4 |  |
| Balance at September 28, 2018 |  | $ | 2 |  |  | $ | — |  |  | $ | (4 | ) |  | $ | (10 | ) |  | $ | (12 | ) |


## us-gaap:DebtDisclosureTextBlock

[0001628280-19-013092:notes:55]
Debt

[0001628280-19-013092:notes:56]
Credit Agreement

[0001628280-19-013092:notes:57]
The Company’s subsidiary, Seagate HDD Cayman, entered into a credit agreement (the “Credit Agreement”) on February 20, 2019, which was most recently amended on September 16, 2019. The Credit Agreement provides an up to $1.5 billion senior unsecured revolving credit facility (“Revolving Credit Facility”) and a term loan facility in an aggregate principal amount of $500 million (“Term Loan”). The Revolving Credit Facility has a final maturity of February 20, 2024 and the Term Loan has a final maturity date of September 16, 2025. The loans made under the Revolving Credit Facility and the Term Loan will bear interest at a rate of the London Interbank Offered Rate (“LIBOR”) plus a variable margin for each facility that will be determined based on the corporate credit rating of the Company. STX and certain of its material subsidiaries fully and unconditionally guarantee both the Revolving Credit Facility and the Term Loan. The Revolving Credit Facility also allows such facility to increase by an additional $100 million, provided that (i) there has been, and will be after giving effect to such increase, no default, (ii) the increase is at least $25 million, and (iii) the existing commitments under such facility receive 0.50% most favored nation protection. An aggregate amount of up to $75 million of the Revolving Credit Facility is available for the issuance of letters of credit, and an aggregate amount of up to $50 million of such facility is also available for swing line loans.

[0001628280-19-013092:notes:58]
On September 17, 2019, Seagate HDD Cayman borrowed the $500 million principal amount under the Term Loan and the proceeds were used to repurchase a portion of its outstanding senior notes. The Term Loan is repayable in quarterly installments of 1.25% of the original principal amount beginning on December 31, 2020, with the remaining balance payable upon maturity.

[0001628280-19-013092:notes:59]
The Credit Agreement includes three financial covenants: (1) interest coverage ratio, (2) total leverage ratio, and (3) a minimum liquidity amount. The Company was in compliance with the covenants as of October 4, 2019 and expects to be in compliance for the next 12 months.

[0001628280-19-013092:notes:60]
As of October 4, 2019, no borrowings were drawn and no letters of credit or swing line loans had been utilized under the Revolving Credit Facility.

[0001628280-19-013092:notes:61]
Other Long-Term Debt

[0001628280-19-013092:notes:62]
$750 million Aggregate Principal Amount of 4.25% Senior Notes due March 2022 (the “2022 Notes”). The interest on the 2022 Notes is payable semi-annually on March 1 and September 1 of each year. The issuer under the 2022 Notes is Seagate HDD Cayman, and the obligations under the 2022 Notes are fully and unconditionally guaranteed, on a senior unsecured basis, by STX. On September 18, 2019, the principal amount of approximately $250 million was repurchased pursuant to cash tender offers for certain senior notes (the “Tender Offers”). The Company recorded a loss of $10 million, which was included in Other, net in the Company’s Condensed Consolidated Statements of Operations.

[0001628280-19-013092:notes:63]
$1 billion Aggregate Principal Amount of 4.75% Senior Notes due June 2023 (the “2023 Notes”). The interest on the 2023 Notes is payable semi-annually on June 1 and December 1 of each year. The issuer under the 2023 Notes is Seagate HDD Cayman, and the obligations under the 2023 Notes are fully and unconditionally guaranteed, on a senior unsecured basis, by STX. On September 18, 2019, the principal amount of $200 million was repurchased pursuant to the Tender Offers. The Company recorded a loss of $10 million, which was included in Other, net in the Company’s Condensed Consolidated Statements of Operations.

[0001628280-19-013092:notes:64]
$500 million Aggregate Principal Amount of 4.875% Senior Notes due March 2024 (the “2024 Notes”).The interest on the 2024 Notes is payable semi-annually on March 1 and September 1 of each year. The issuer under the 2024 Notes is Seagate HDD Cayman, and the obligations under the 2024 Notes are fully and unconditionally guaranteed, on a senior unsecured basis, by STX.

[0001628280-19-013092:notes:65]
$1 billion Aggregate Principal Amount of 4.75% Senior Notes due January 2025 (the “2025 Notes”). The interest on the 2025 Notes is payable semi-annually on January 1 and July 1 of each year. The issuer under the 2025 Notes is Seagate HDD Cayman, and the obligations under the 2025 Notes are fully and unconditionally guaranteed, on a senior unsecured basis, by STX. On September 18, 2019, the principal amount of approximately $170 million was repurchased pursuant to the Tender Offers. The Company recorded a loss of $8 million, which was included in Other, net in the Company’s Condensed Consolidated Statements of Operations.

[0001628280-19-013092:notes:66]
$700 million Aggregate Principal Amount of 4.875% Senior Notes due June 2027 (the “2027 Notes”). The interest on the Notes is payable semi-annually on June 1 and December 1 of each year. The issuer under the 2027 Notes is Seagate HDD Cayman, and the obligations under the 2027 Notes are fully and unconditionally guaranteed, on a senior unsecured basis, by STX.

[0001628280-19-013092:notes:67]
$500 million Aggregate Principal Amount of 5.75% Senior Notes due December 2034 (the “2034 Notes”). The interest on the 2034 Notes is payable semi-annually on June 1 and December 1 of each year. The issuer under the 2034 Notes is Seagate HDD Cayman, and the obligations under the 2034 Notes are fully and unconditionally guaranteed, on a senior unsecured basis, by STX.

[0001628280-19-013092:notes:68]
At October 4, 2019, future principal payments on long-term debt were as follows (in millions):

[0001628280-19-013092:notes:69]
| Fiscal Year |  | Amount |
| Remainder of 2020 |  | $ | — |  |
| 2021 |  | 19 |  |
| 2022 |  | 525 |  |
| 2023 |  | 766 |  |
| 2024 |  | 525 |  |
| Thereafter |  | 2,336 |  |
| Total |  | $ | 4,171 |  |


## us-gaap:IncomeTaxDisclosureTextBlock

[0001628280-19-013092:notes:70]
ompany’s income tax benefit of $2 million for the three months ended October 4, 2019 included approximately $11 million of net discrete tax benefit of which $8 million was associated with net excess tax benefits related to share-based compensation expense.

[0001628280-19-013092:notes:71]
The Company’s income tax provision recorded for the three months ended October 4, 2019 differed from the provision for income taxes that would be derived by applying the Irish statutory rate of 25% to income before income taxes, primarily due to the net effect of tax benefits related to (i) non-Irish earnings generated in jurisdictions that are subject to tax incentive programs and are considered indefinitely reinvested outside of Ireland and (ii) current year generation of research credits.

[0001628280-19-013092:notes:72]
During the three months ended October 4, 2019, the Company’s unrecognized tax benefits excluding interest and penalties increased by approximately $2 million to $85 million. The unrecognized tax benefits that, if recognized, would impact the effective tax rate were $85 million at October 4, 2019, subject to certain future valuation allowance reversals. During the twelve months beginning October 5, 2019, the Company expects that its unrecognized tax benefits could be reduced by an immaterial amount, as a result of expected cash payments to tax authorities.

[0001628280-19-013092:notes:73]
The Company’s income tax provision of $18 million for the three months ended September 28, 2018 included approximately $1 million of net discrete tax expense.

[0001628280-19-013092:notes:74]
The Company’s income tax provision recorded for the three months ended September 28, 2018 differed from the provision for income taxes that would be derived by applying the Irish statutory rate of 25% to income before income taxes, primarily due to the net effect of (i) tax benefits related to non-Irish earnings generated in jurisdictions that are subject to tax incentive programs and are considered indefinitely reinvested outside of Ireland and (ii) a decrease in valuation allowance for certain deferred tax assets.


## us-gaap:LesseeOperatingLeasesTextBlock

[0001628280-19-013092:notes:75]
The Company is a lessee in several operating leases related to real estate facilities for warehouse and office space.

[0001628280-19-013092:notes:76]
The Company’s lease arrangements comprise operating leases with various expiration dates through 2082. The lease term includes the non-cancelable period of the lease, adjusted for options to extend or terminate the lease when it is reasonably certain that an option will be exercised.

[0001628280-19-013092:notes:77]
Operating lease costs include short-term lease costs and are shown net of immaterial sublease income. The components of lease costs and other information related to leases were as follows:

[0001628280-19-013092:notes:78]
| (Dollars in millions) |  | For the Three Months Ended October 4, 2019 |
| Operating lease cost |  | $ | 6 |  |
| Variable lease cost |  | 1 |  |
| Total lease cost |  | $ | 7 |  |
| Operating cash outflows from operating leases |  | $ | 4 |  |
| Weighted-average remaining lease term |  | 12.8 years |  |
| Weighted-average discount rate |  | 6.41 | % |

[0001628280-19-013092:notes:79]
ROU assets and lease liabilities are included on the Company’s Condensed Consolidated Balance Sheet as follows:

[0001628280-19-013092:notes:80]
| (Dollars in millions) |  | Balance Sheet Location |  | October 4, 2019 |
| ROU assets |  | Other assets, net |  | $ | 111 |  |
| Current lease liabilities |  | Accrued expenses |  | $ | 15 |  |
| Non-current lease liabilities |  | Other non-current liabilities |  | $ | 56 |  |

[0001628280-19-013092:notes:81]
At October 4, 2019, future lease payments included in the measurement of lease liabilities were as follows (in millions):

[0001628280-19-013092:notes:82]
| Fiscal Year |  | Amount |
| Remainder of 2020 |  | $ | 11 |  |
| 2021 |  | 15 |  |
| 2022 |  | 14 |  |
| 2023 |  | 10 |  |
| 2024 |  | 5 |  |
| Thereafter |  | 104 |  |
| Total lease payments |  | 159 |  |
| Less: imputed interest |  | (88 | ) |
| Present value of lease liabilities |  | $ | 71 |  |


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0001628280-19-013092:notes:83]
For the three months ended October 4, 2019, and September 28, 2018, the Company recorded restructuring charges of approximately $17 million and $23 million, respectively, comprised primarily of charges related to workforce reduction costs and facilities and other exit costs. The Company’s significant restructuring plans are described below. All restructuring charges are reported in Restructuring and other, net on the Company’s Condensed Consolidated Statements of Operations.

[0001628280-19-013092:notes:84]
December 2017 Plan - On December 8, 2017, the Company committed to a restructuring plan (the “December 2017 Plan”) to reduce its cost structure. The December 2017 Plan included reducing the Company’s global headcount by approximately 500 employees. The December 2017 Plan was substantially completed by the end of fiscal year 2018.

[0001628280-19-013092:notes:85]
The following table summarizes the Company’s restructuring activities under all of the Company’s active restructuring plans for the three months ended October 4, 2019:

[0001628280-19-013092:notes:86]
|  |  | December 2017 Plan |  | Other Plans |  |  |
| (Dollars in millions) |  | Workforce Reduction Costs |  | Facilities and Other Exit Costs |  | Workforce Reduction Costs |  | Facilities and Other Exit Costs |  | Total |
| Accrual balances at June 28, 2019 |  | $ | — |  |  | $ | 1 |  |  | $ | 13 |  |  | $ | 16 |  |  | $ | 30 |  |
| Lease adoption adjustment |  | — |  |  | — |  |  | — |  |  | (11 | ) |  | (11 | ) |
| Restructuring charges |  | — |  |  | — |  |  | 17 |  |  | — |  |  | 17 |  |
| Cash payments |  | — |  |  | — |  |  | (13 | ) |  | (1 | ) |  | (14 | ) |
| Adjustments |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Accrual balances at October 4, 2019 |  | $ | — |  |  | $ | 1 |  |  | $ | 17 |  |  | $ | 4 |  |  | $ | 22 |  |
| Total costs incurred to date as of October 4, 2019 |  | $ | 26 |  |  | $ | 8 |  |  | $ | 449 |  |  | $ | 109 |  |  | $ | 592 |  |
| Total expected charges to be incurred as of October 4, 2019 |  | $ | — |  |  | $ | — |  |  | $ | 1 |  |  | $ | — |  |  | $ | 1 |  |


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001628280-19-013092:notes:87]
[same as prior period, unchanged from 0001193125-19-129284:notes:30]

[0001628280-19-013092:notes:88]
The Company is exposed to foreign currency exchange rate, interest rate, and to a lesser extent, equity market risks relating to its ongoing business operations. From time to time, the Company enters into cash flow hedges in the form of foreign currency forward exchange contracts. The objective of foreign currency forward exchange contracts is to manage the foreign currency exchange rate risk on forecasted expenses and investments denominated in foreign currencies.

[0001628280-19-013092:notes:89]
In the September 2019 quarter, the Company entered into certain interest rate swap agreements with a notional amount of $500 million to convert the variable interest rate on its Term Loan to fixed interest rates. The contracts were effective as of October 4, 2019 and will mature on September 16, 2025. The objective of the interest rate swap agreements is to eliminate the variability of interest payment cash flows associated with variable interest rates. The Company designated the interest rate swaps as cash flow hedges.

[0001628280-19-013092:notes:90]
The Company’s accounting policies for these instruments are based on whether the instruments are classified as designated or non-designated hedging instruments. The Company records all derivatives on its Condensed Consolidated Balance Sheets at fair value. The changes in the fair value of highly effective designated cash flow hedges are recorded in Accumulated

[0001628280-19-013092:notes:91]
other comprehensive loss until the hedged item is recognized in earnings. Derivatives that are not designated as hedging instruments or are not assessed to be highly effective are adjusted to fair value through earnings. The amount of net unrealized loss on cash flow hedges was not material as of October 4, 2019 and as of June 28, 2019.

[0001628280-19-013092:notes:92]
The Company de-designates its cash flow hedges when the forecasted hedged transactions affect earnings or it is probable the forecasted hedged transactions will not occur in the initially identified time period. At such time, the associated gains and losses deferred in Accumulated other comprehensive loss on the Company’s Condensed Consolidated Balance Sheets are reclassified immediately into earnings and any subsequent changes in the fair value of such derivative instruments are immediately reflected in earnings. The Company did not recognize any material amounts related to the loss of hedge designation on discontinued cash flow hedges during the three months ended October 4, 2019 and September 28, 2018, respectively.

[0001628280-19-013092:notes:93]
Other derivatives not designated as hedging instruments consist of foreign currency forward exchange contracts that the Company uses to hedge the foreign currency exposure on forecasted expenditures denominated in currency other than the U.S. dollar. The Company recognizes gains and losses on these contracts, as well as the related costs in Other, net on its Condensed Consolidated Statements of Operations. Deferred gains and deferred losses on derivatives are recognized in Other current assets and Accrued expenses, respectively, on the Condensed Consolidated Balance Sheets.

[0001628280-19-013092:notes:94]
The following tables show the total notional value of the Company’s outstanding foreign currency forward exchange contracts and interest rate swaps as of October 4, 2019 and June 28, 2019. All of the foreign currency forward exchange contracts mature within 12 months.

[0001628280-19-013092:notes:95]
|  |  | As of October 4, 2019 |
| (Dollars in millions) |  | ContractsDesignated asHedges |  | Contracts NotDesignated asHedges |
| Singapore Dollar |  | $ | 58 |  |  | $ | 46 |  |
| Chinese Renminbi |  | 30 |  |  | 30 |  |
| British Pound Sterling |  | — |  |  | 6 |  |
|  |  | $ | 88 |  |  | $ | 82 |  |

[0001628280-19-013092:notes:96]
|  |  | As of June 28, 2019 |
| (Dollars in millions) |  | ContractsDesignated asHedges |  | Contracts NotDesignated asHedges |
| Singapore Dollar |  | $ | 60 |  |  | $ | 40 |  |
| Chinese Renminbi |  | 79 |  |  | 20 |  |
| British Pound Sterling |  | 6 |  |  | 12 |  |
|  |  | $ | 145 |  |  | $ | 72 |  |

[0001628280-19-013092:notes:97]
The Company is subject to equity market risks due to changes in the fair value of the notional investments selected by its employees as part of its Non-qualified Deferred Compensation Plan—the Seagate Deferred Compensation Plan (the “SDCP”). In fiscal year 2014, the Company entered into a Total Return Swap (“TRS”) in order to manage the equity market risks associated with the SDCP liabilities. The Company pays a floating rate, based on LIBOR plus an interest rate spread, on the notional amount of the TRS. The TRS is designed to substantially offset changes in the SDCP liability due to changes in the value of the investment options made by employees. As of October 4, 2019, the notional investments underlying the TRS amounted to $117 million. The contract term of the TRS is through January 2020 and is settled on a monthly basis, therefore limiting counterparty performance risk. The Company does not designate the TRS as a hedge. Rather, the Company records all changes in the fair value of the TRS to earnings to offset the market value changes of the SDCP liabilities.

[0001628280-19-013092:notes:98]
The following tables show the Company’s derivative instruments measured at gross fair value as reflected on its Condensed Consolidated Balance Sheets as of October 4, 2019 and June 28, 2019:

[0001628280-19-013092:notes:99]
|  |  | As of October 4, 2019 |
|  |  | Derivative Assets |  | Derivative Liabilities |
| (Dollars in millions) |  | Balance SheetLocation |  | FairValue |  | Balance SheetLocation |  | FairValue |
| Derivatives designated as hedging instruments: |  |  |  |  |  |  |  |  |
| Foreign currency forward exchange contracts |  | Other current assets |  | $ | — |  |  | Accrued expenses |  | $ | (2 | ) |
| Derivatives not designated as hedging instruments: |  |  |  |  |  |  |  |  |
| Foreign currency forward exchange contracts |  | Other current assets |  | — |  |  | Accrued expenses |  | (2 | ) |
| Total derivatives |  |  |  | $ | — |  |  |  |  | $ | (4 | ) |

[0001628280-19-013092:notes:100]
|  |  | As of June 28, 2019 |
|  |  | Derivative Assets |  | Derivative Liabilities |
| (Dollars in millions) |  | Balance SheetLocation |  | FairValue |  | Balance SheetLocation |  | FairValue |
| Derivatives designated as hedging instruments: |  |  |  |  |  |  |  |  |
| Foreign currency forward exchange contracts |  | Other current assets |  | $ | — |  |  | Accrued expenses |  | $ | — |  |
| Derivatives not designated as hedging instruments: |  |  |  |  |  |  |  |  |
| Foreign currency forward exchange contracts |  | Other current assets |  | 1 |  |  | Accrued expenses |  | (1 | ) |
| Total derivatives |  |  |  | $ | 1 |  |  |  |  | $ | (1 | ) |

[0001628280-19-013092:notes:101]
The following tables show the effect of the Company’s derivative instruments on its Condensed Consolidated Statements of Comprehensive Income and the Condensed Consolidated Statements of Operations for the three months ended October 4, 2019:

[0001628280-19-013092:notes:102]
| Derivatives Not Designated as Hedging Instruments |  | Location of Gain/(Loss) Recognized inIncome on Derivatives |  | Amount of Gain/(Loss) Recognized inIncome on Derivatives |
| Foreign currency forward exchange contracts |  | Other, net |  | $ | 3 |  |

[0001628280-19-013092:notes:103]
The amount of loss recognized in the Condensed Consolidated Statement of Comprehensive Income on derivatives designated as cash flow hedges was $1 million for the three months ended October 4, 2019. The amount of loss recognized in income related to the ineffective portion of the hedging relationships and to the amount excluded from the assessment of hedge ineffectiveness was not material for the three months ended October 4, 2019.

[0001628280-19-013092:notes:104]
The following table shows the effect of the Company’s derivative instruments on its Condensed Consolidated Statement of Comprehensive Income and its Condensed Consolidated Statement of Operations for the three months ended September 28, 2018:

[0001628280-19-013092:notes:105]
| (Dollars in millions)Derivatives Not Designated as Hedging Instruments |  | Location of Gain/(Loss) Recognized inIncome on Derivatives |  | Amount of Gain/(Loss) Recognized inIncome on Derivatives |
| Foreign currency forward exchange contracts |  | Other, net |  | $ | 41 |  |
| Total return swap |  | Operating expenses |  | $ | 4 |  |

[0001628280-19-013092:notes:106]
| (Dollars in millions)Derivatives Designated as Hedging Instruments |  | Amount ofGain/(Loss)Recognizedin OCI onDerivatives(EffectivePortion) |  | Location ofGain/(Loss)ReclassifiedfromAccumulatedOCI intoIncome(EffectivePortion) |  | Amount ofGain/(Loss)ReclassifiedfromAccumulatedOCI intoIncome(EffectivePortion) |  | Location ofGain/(Loss)Recognized inIncome onDerivatives(IneffectivePortion andAmount ExcludedfromEffectivenessTesting) |  | Amount ofGain/(Loss)Recognized inIncome(IneffectivePortion andAmountExcluded fromEffectivenessTesting) |
| Foreign currency forward exchange contracts |  | $ | 3 |  |  | Other expense, net |  | $ | 1 |  |  | Other expense, net |  | $ | — |  |


## us-gaap:FairValueDisclosuresTextBlock

[0001628280-19-013092:notes:107]
[same as prior period, unchanged from 0001193125-19-129284:notes:59]

[0001628280-19-013092:notes:108]
[same as prior period, unchanged from 0001193125-19-129284:notes:60]

[0001628280-19-013092:notes:109]
[same as prior period, unchanged from 0001193125-19-129284:notes:61]

[0001628280-19-013092:notes:110]
[same as prior period, unchanged from 0001193125-19-129284:notes:62]

[0001628280-19-013092:notes:111]
[same as prior period, unchanged from 0001193125-19-129284:notes:63]

[0001628280-19-013092:notes:112]
[same as prior period, unchanged from 0001193125-19-129284:notes:64]

[0001628280-19-013092:notes:113]
[same as prior period, unchanged from 0001193125-19-129284:notes:65]

[0001628280-19-013092:notes:114]
[same as prior period, unchanged from 0001193125-19-129284:notes:66]

[0001628280-19-013092:notes:115]
[same as prior period, unchanged from 0001193125-19-129284:notes:67]

[0001628280-19-013092:notes:116]
[same as prior period, unchanged from 0001193125-19-129284:notes:68]

[0001628280-19-013092:notes:117]
The following tables present the Company’s assets and liabilities, by financial instrument type and balance sheet line item, that are measured at fair value on a recurring basis, excluding accrued interest components, as of October 4, 2019:

[0001628280-19-013092:notes:118]
|  |  | Fair Value Measurements at Reporting Date Using |
| (Dollars in millions) |  | QuotedPrices inActiveMarkets forIdenticalInstruments(Level 1) |  | SignificantOtherObservableInputs(Level 2) |  | SignificantUnobservableInputs(Level 3) |  | TotalBalance |
| Assets: |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds |  | $ | 470 |  |  | $ | — |  |  | $ | — |  |  | $ | 470 |  |
| Time deposits and certificates of deposit |  | — |  |  | 350 |  |  | — |  |  | 350 |  |
| Total cash equivalents |  | 470 |  |  | 350 |  |  | — |  |  | 820 |  |
| Restricted cash and investments: |  |  |  |  |  |  |  |  |
| Money market funds |  | 1 |  |  | — |  |  | — |  |  | 1 |  |
| Time deposits and certificates of deposit |  | — |  |  | 1 |  |  | — |  |  | 1 |  |
| Other debt securities |  | — |  |  | — |  |  | 10 |  |  | 10 |  |
| Total assets |  | $ | 471 |  |  | $ | 351 |  |  | $ | 10 |  |  | $ | 832 |  |
| Liabilities: |  |  |  |  |  |  |  |  |
| Derivative liabilities |  | $ | — |  |  | $ | 4 |  |  | $ | — |  |  | $ | 4 |  |
| Total liabilities |  | $ | — |  |  | $ | 4 |  |  | $ | — |  |  | $ | 4 |  |

[0001628280-19-013092:notes:119]
|  |  | Fair Value Measurements at Reporting Date Using |
| (Dollars in millions) |  | QuotedPrices inActiveMarkets forIdenticalInstruments(Level 1) |  | SignificantOtherObservableInputs(Level 2) |  | SignificantUnobservableInputs(Level 3) |  | TotalBalance |
| Assets: |  |  |  |  |  |  |  |  |
| Cash and cash equivalents |  | $ | 470 |  |  | $ | 350 |  |  | $ | — |  |  | $ | 820 |  |
| Other current assets |  | 1 |  |  | 1 |  |  | — |  |  | 2 |  |
| Other assets, net |  | — |  |  | — |  |  | 10 |  |  | 10 |  |
| Total assets |  | $ | 471 |  |  | $ | 351 |  |  | $ | 10 |  |  | $ | 832 |  |
| Liabilities: |  |  |  |  |  |  |  |  |
| Accrued expenses |  | $ | — |  |  | $ | 4 |  |  | $ | — |  |  | $ | 4 |  |
| Total liabilities |  | $ | — |  |  | $ | 4 |  |  | $ | — |  |  | $ | 4 |  |

[0001628280-19-013092:notes:120]
The following tables present the Company’s assets and liabilities, by financial instrument type and balance sheet line item, that are measured at fair value on a recurring basis, excluding accrued interest components, as of June 28, 2019:

[0001628280-19-013092:notes:121]
|  |  | Fair Value Measurements at Reporting Date Using |
| (Dollars in millions) |  | QuotedPrices inActiveMarkets forIdenticalInstruments(Level 1) |  | SignificantOtherObservableInputs(Level 2) |  | SignificantUnobservableInputs(Level 3) |  | TotalBalance |
| Assets: |  |  |  |  |  |  |  |  |
| Money market funds |  | $ | 416 |  |  | $ | — |  |  | $ | — |  |  | $ | 416 |  |
| Time deposits and certificates of deposit |  | — |  |  | 132 |  |  | — |  |  | 132 |  |
| Total cash equivalents |  | 416 |  |  | 132 |  |  | — |  |  | 548 |  |
| Restricted cash and investments: |  |  |  |  |  |  |  |  |
| Money market funds |  | 1 |  |  | — |  |  | — |  |  | 1 |  |
| Time deposits and certificates of deposit |  | — |  |  | 1 |  |  | — |  |  | 1 |  |
| Other debt securities |  | — |  |  | — |  |  | 7 |  |  | 7 |  |
| Derivative assets |  | — |  |  | 1 |  |  | — |  |  | 1 |  |
| Total assets |  | $ | 417 |  |  | $ | 134 |  |  | $ | 7 |  |  | $ | 558 |  |
| Liabilities: |  |  |  |  |  |  |  |  |
| Derivative liabilities |  | $ | — |  |  | $ | 1 |  |  | $ | — |  |  | $ | 1 |  |
| Total liabilities |  | $ | — |  |  | $ | 1 |  |  | $ | — |  |  | $ | 1 |  |

[0001628280-19-013092:notes:122]
|  |  | Fair Value Measurements at Reporting Date Using |
| (Dollars in millions) |  | QuotedPrices inActiveMarkets forIdenticalInstruments(Level 1) |  | SignificantOtherObservableInputs(Level 2) |  | SignificantUnobservableInputs(Level 3) |  | TotalBalance |
| Assets: |  |  |  |  |  |  |  |  |
| Cash and cash equivalents |  | $ | 416 |  |  | $ | 132 |  |  | $ | — |  |  | $ | 548 |  |
| Other current assets, net |  | 1 |  |  | 2 |  |  | — |  |  | 3 |  |
| Other current assets |  | — |  |  | — |  |  | 7 |  |  | 7 |  |
| Total assets |  | $ | 417 |  |  | $ | 134 |  |  | $ | 7 |  |  | $ | 558 |  |
| Liabilities: |  |  |  |  |  |  |  |  |
| Accrued expenses |  | $ | — |  |  | $ | 1 |  |  | $ | — |  |  | $ | 1 |  |
| Total liabilities |  | $ | — |  |  | $ | 1 |  |  | $ | — |  |  | $ | 1 |  |

[0001628280-19-013092:notes:123]
[same as prior period, unchanged from 0001193125-19-129284:notes:73]

[0001628280-19-013092:notes:124]
The Company classifies items in Level 2 if the financial asset or liability is valued using observable inputs. The Company uses observable inputs including quoted prices in active markets for similar assets or liabilities. Level 2 assets include: agency bonds, corporate bonds, commercial paper, municipal bonds, U.S. Treasuries, time deposits and certificates of deposit. These debt investments are priced using observable inputs and valuation models which vary by asset class. The Company uses a pricing service to assist in determining the fair value of all of its cash equivalents and short-term investments. For the cash equivalents and short-term investments in the Company’s portfolio, multiple pricing sources are generally available. The pricing service uses inputs from multiple industry-standard data providers or other third-party sources and various methodologies, such as weighting and models, to determine the appropriate price at the measurement date. The Company corroborates the prices obtained from the pricing service against other independent sources and, as of October 4, 2019, has not found it necessary to make any adjustments to the prices obtained. The Company’s derivative financial instruments are also classified within Level 2. The Company’s derivative financial instruments consist of foreign currency forward exchange contracts, interest rate swaps and the TRS. The Company recognizes derivative financial instruments in its condensed consolidated financial statements at fair value. The Company determines the fair value of these instruments by considering the estimated amount it would pay or receive to terminate these agreements at the reporting date.

[0001628280-19-013092:notes:125]
[same as prior period, unchanged from 0001193125-19-129284:notes:76]

[0001628280-19-013092:notes:126]
From time to time, the Company enters into certain strategic investments for the promotion of business and strategic objectives. These strategic investments primarily include cost basis investments representing those where the Company does have the ability to exercise significant influence but does not have control. These investments are included in Other assets, net on the Company’s Condensed Consolidated Balance Sheets, and are periodically analyzed to determine whether or not there are indicators of impairment.

[0001628280-19-013092:notes:127]
As of October 4, 2019 and June 28, 2019, the carrying value of the Company’s strategic investments was $115 million and $114 million, respectively. For the three months ended October 4, 2019 and September 28, 2018, there were no upward or downward adjustments on equity investments.

[0001628280-19-013092:notes:128]
As of June 28, 2019, the Company had $23 million of held for sale land and building (collectively, the “properties”) included in Other current assets on its Condensed Consolidated Balance Sheets. In July 2019, the Company completed the sale of the properties. As of October 4, 2019, the Company had no held for sale land and building.

[0001628280-19-013092:notes:129]
[same as prior period, unchanged from 0001193125-19-129284:notes:81]

[0001628280-19-013092:notes:130]
[same as prior period, unchanged from 0001193125-19-129284:notes:83]

[0001628280-19-013092:notes:131]
|  |  | October 4, 2019 |  | As of June 28, 2019 |
| (Dollars in millions) |  | CarryingAmount |  | EstimatedFair Value |  | CarryingAmount |  | EstimatedFair Value |
| 4.25% Senior Notes due March 2022 |  | $ | 499 |  |  | $ | 516 |  |  | $ | 749 |  |  | $ | 763 |  |
| 4.75% Senior Notes due June 2023 |  | 741 |  |  | 774 |  |  | 941 |  |  | 973 |  |
| 4.875% Senior Notes due March 2024 |  | 498 |  |  | 526 |  |  | 498 |  |  | 514 |  |
| 4.75% Senior Notes due January 2025 |  | 750 |  |  | 778 |  |  | 920 |  |  | 929 |  |
| 4.875% Senior Notes due June 2027 |  | 689 |  |  | 713 |  |  | 689 |  |  | 688 |  |
| 5.75% Senior Notes due December 2034 |  | 489 |  |  | 497 |  |  | 489 |  |  | 482 |  |
| LIBOR based Term Loan due September 2025 |  | 500 |  |  | 484 |  |  | — |  |  | — |  |
|  |  | $ | 4,166 |  |  | $ | 4,288 |  |  | $ | 4,286 |  |  | $ | 4,349 |  |
| Less: debt issuance costs |  | (26 | ) |  | — |  |  | (33 | ) |  | — |  |
| Long-term debt, net of debt issuance costs |  | $ | 4,140 |  |  | $ | 4,288 |  |  | $ | 4,253 |  |  | $ | 4,349 |  |


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001628280-19-013092:notes:132]
[same as prior period, unchanged from 0001193125-19-129284:notes:181]

[0001628280-19-013092:notes:133]
[same as prior period, unchanged from 0001193125-19-129284:notes:182]

[0001628280-19-013092:notes:134]
The Company’s authorized share capital is $13,500 and consists of 1,250,000,000 ordinary shares, par value $0.00001, of which 262,624,650 shares were outstanding as of October 4, 2019, and 100,000,000 preferred shares, par value $0.00001, of which none were issued or outstanding as of October 4, 2019.

[0001628280-19-013092:notes:135]
Ordinary shares—Holders of ordinary shares are entitled to receive dividends as and when declared by the board of directors (the “Board of Directors”). Upon any liquidation, dissolution, or winding up, after required payments are made to holders of preferred shares, any remaining assets will be distributed ratably to holders of the preferred and ordinary shares. Holders of shares are entitled to one vote per share on all matters upon which the ordinary shares are entitled to vote, including the election of directors.

[0001628280-19-013092:notes:136]
[same as prior period, unchanged from 0001193125-19-129284:notes:185]

[0001628280-19-013092:notes:137]
[same as prior period, unchanged from 0001193125-19-129284:notes:186]

[0001628280-19-013092:notes:138]
[same as prior period, unchanged from 0001193125-19-129284:notes:187]

[0001628280-19-013092:notes:139]
All repurchases are effected as redemptions in accordance with the Company’s Articles of Association.

[0001628280-19-013092:notes:140]
As of October 4, 2019, $1.7 billion remained available for repurchase under the existing repurchase authorization limit.

[0001628280-19-013092:notes:141]
The following table sets forth information with respect to repurchases of ordinary shares during the three months ended October 4, 2019:

[0001628280-19-013092:notes:142]
| (In millions) |  | Number of Shares Repurchased |  | Dollar Value of Shares Repurchased |
| Repurchases of ordinary shares |  | 9 |  |  | $ | 447 |  |
| Tax withholding related to vesting of equity awards |  | 1 |  |  | 37 |  |
| Total |  | 10 |  |  | $ | 484 |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0001628280-19-013092:notes:143]
[same as prior period, unchanged from 0001193125-19-129284:notes:172]

[0001628280-19-013092:notes:144]
The following table provides information about disaggregated revenue by sales channel and geographical region for the Company’s single reportable segment:

[0001628280-19-013092:notes:145]
|  |  | For the Three Months Ended |
| (Dollars in millions) |  | October 4, 2019 |  | September 28, 2018 |
| Revenues by Channel |  |  |  |  |  |
| OEMs |  | $ | 1,820 |  |  | $ | 2,138 |  |
| Distributors |  | 461 |  |  | 534 |  |
| Retailers |  | 297 |  |  | 319 |  |
| Total |  | $ | 2,578 |  |  | $ | 2,991 |  |
| Revenues by Geography(1) |  |  |  |  |
| Americas |  | $ | 835 |  |  | $ | 1,006 |  |
| EMEA |  | 465 |  |  | 517 |  |
| Asia Pacific |  | 1,278 |  |  | 1,468 |  |
| Total |  | $ | 2,578 |  |  | $ | 2,991 |  |

[0001628280-19-013092:notes:146]
__________________________________________

[0001628280-19-013092:notes:147]
(1) Revenue is attributed to countries based on bill from locations.


## us-gaap:ProductWarrantyDisclosureTextBlock

[0001628280-19-013092:notes:148]
[same as prior period, unchanged from 0001193125-19-129284:notes:151]

[0001628280-19-013092:notes:149]
[same as prior period, unchanged from 0001193125-19-129284:notes:152]

[0001628280-19-013092:notes:150]
Seagate Technology, an exempted company incorporated with limited liability under the laws of the Cayman Islands (“Seagate-Cayman”) and wholly-owned subsidiary of STX, from time to time enters into indemnification agreements with the directors, officers, employees and agents of STX or any of its subsidiaries (each, an “Indemnitee”). The indemnification agreements provide indemnification in addition to any of Indemnitee’s indemnification rights under any relevant Articles of Association (or similar constitutional document), applicable law or otherwise, and indemnifies an Indemnitee for certain expenses (including attorneys’ fees), judgments, fines and settlement amounts actually and reasonably incurred by him or her in any action or proceeding, including any action by or in the right of STX or any of its subsidiaries, arising out of his or her service as a director, officer, employee or agent of STX or any of its subsidiaries or of any other entity to which he or she provides services at the Company’s request. However, Indemnitees are not indemnified under the indemnification agreements for (i) any fraud or dishonesty in the performance of Indemnitee’s duty to STX or the applicable subsidiary or (ii) Indemnitee’s conscious, intentional or willful failure to act honestly, lawfully and in good faith with a view to the best interests of the Company. In addition, the indemnification agreements provide that Seagate-Cayman will advance expenses incurred by an Indemnitee in connection with enforcement of the indemnification agreement or with the investigation, settlement or appeal of any action or proceeding against him or her as to which he or she could be indemnified.

[0001628280-19-013092:notes:151]
The nature of these indemnification obligations prevents the Company from making a reasonable estimate of the maximum potential amount it could be required to pay on behalf of its officers and directors. Historically, the Company has not made any significant indemnification payments under such agreements and no amount has been accrued in the Company’s condensed consolidated financial statements with respect to these indemnification obligations.

[0001628280-19-013092:notes:152]
[same as prior period, unchanged from 0001193125-19-129284:notes:156]

[0001628280-19-013092:notes:153]
The Company has entered into agreements with customers and suppliers that include limited intellectual property indemnification obligations that are customary in the industry. These guarantees generally require the Company to compensate the other party for certain damages and costs incurred as a result of third party intellectual property claims arising from these transactions. The nature of the intellectual property indemnification obligations prevents the Company from making a reasonable estimate of the maximum potential amount it could be required to pay to its customers and suppliers. Historically, the Company has not made any significant indemnification payments under such agreements and no amount has been accrued in the Company’s condensed consolidated financial statements with respect to these indemnification obligations.

[0001628280-19-013092:notes:154]
[same as prior period, unchanged from 0001193125-19-129284:notes:158]

[0001628280-19-013092:notes:155]
The Company estimates probable product warranty costs at the time revenue is recognized. The Company generally warrants its products for a period of 1 to 5 years. The Company uses estimated repair or replacement costs and uses statistical modeling to estimate product return rates in order to determine its warranty obligation. Changes in the Company’s product warranty liability during the three months ended October 4, 2019 and September 28, 2018 were as follows:

[0001628280-19-013092:notes:156]
|  |  | For the Three Months Ended |
| (Dollars in millions) |  | October 4, 2019 |  | September 28, 2018 |
| Balance, beginning of period |  | $ | 195 |  |  | $ | 237 |  |
| Warranties issued |  | 24 |  |  | 34 |  |
| Repairs and replacements |  | (23 | ) |  | (25 | ) |
| Changes in liability for pre-existing warranties, including expirations |  | (12 | ) |  | (14 | ) |
| Balance, end of period |  | $ | 184 |  |  | $ | 232 |  |


## us-gaap:EarningsPerShareTextBlock

[0001628280-19-013092:notes:157]
[same as prior period, unchanged from 0001193125-19-129284:notes:53]

[0001628280-19-013092:notes:158]
Basic earnings per share is computed by dividing income available to shareholders by the weighted-average number of shares outstanding during the period. Diluted earnings per share is computed by dividing income available to shareholders by the weighted-average number of shares outstanding during the period and the number of additional shares that would have been outstanding if the potentially dilutive securities had been issued. Potentially dilutive securities include outstanding options, unvested restricted share units and performance-based share units and shares to be purchased under the Company’s Employee Stock Purchase Plan (“ESPP”). The dilutive effect of potentially dilutive securities is reflected in diluted earnings per share by application of the treasury stock method. Under the treasury stock method, an increase in fair market value of the Company’s share price can result in a greater dilutive effect from potentially dilutive securities. The following table sets forth the computation of basic and diluted net income per share attributable to the shareholders of the Company:

[0001628280-19-013092:notes:159]
|  |  | For the Three Months Ended |
| (In millions, except per share data) |  | October 4, 2019 |  | September 28, 2018 |
| Numerator: |  |  |  |  |  |  |
| Net income |  | $ | 200 |  |  | $ | 450 |  |
| Number of shares used in per share calculations: |  |  |  |  |  |  |
| Total shares for purposes of calculating basic net income per share |  | 266 |  |  | 287 |  |
| Weighted-average effect of dilutive securities: |  |  |  |  |  |  |
| Employee equity award plans |  | 4 |  |  | 5 |  |
| Total shares for purpose of calculating diluted net income per share |  | 270 |  |  | 292 |  |
| Net income per share: |  |  |  |  |  |  |
| Basic |  | $ | 0.75 |  |  | $ | 1.57 |  |
| Diluted |  | $ | 0.74 |  |  | $ | 1.54 |  |

[0001628280-19-013092:notes:160]
The anti-dilutive shares related to employee equity award plans that were excluded from the computation of diluted net income per share were not material for the three months ended October 4, 2019 and September 28, 2018.


## us-gaap:LegalMattersAndContingenciesTextBlock

[0001628280-19-013092:notes:161]
Legal, Environmental and Other Contingencies

[0001628280-19-013092:notes:162]
The Company assesses the probability of an unfavorable outcome of all its material litigation, claims, or assessments to determine whether a liability had been incurred and whether it is probable that one or more future events will occur confirming the fact of the loss. In the event that an unfavorable outcome is determined to be probable and the amount of the loss can be reasonably estimated, the Company establishes an accrual for the litigation, claim or assessment. In addition, in the event an unfavorable outcome is determined to be less than probable, but reasonably possible, the Company will disclose an estimate of the possible loss or range of such loss; however, when a reasonable estimate cannot be made, the Company will provide disclosure

[0001628280-19-013092:notes:163]
to that effect. Litigation is inherently uncertain and may result in adverse rulings or decisions. Additionally, the Company may enter into settlements or be subject to judgments that may, individually or in the aggregate, have a material adverse effect on its results of operations. Accordingly, actual results could differ materially.

[0001628280-19-013092:notes:164]
Intellectual Property Litigation

[0001628280-19-013092:notes:165]
Convolve, Inc. (“Convolve”) and Massachusetts Institute of Technology (“MIT”) v. Seagate Technology LLC, et al. On July 13, 2000, Convolve and MIT filed suit against Compaq Computer Corporation and Seagate Technology LLC in the U.S. District Court for the Southern District of New York, alleging infringement of U.S. Patent No. 4,916,635 (the “‘635 patent”) and U.S. Patent No. 5,638,267 (the “‘267 patent”), misappropriation of trade secrets, breach of contract, and other claims. On January 16, 2002, Convolve filed an amended complaint, alleging defendants were infringing U.S. Patent No. 6,314,473 (the “‘473 patent”). The district court ruled in 2010 that the ‘267 patent was out of the case.

[0001628280-19-013092:notes:166]
On August 16, 2011, the district court granted in part and denied in part the Company’s motion for summary judgment. On July 1, 2013, the U.S. Court of Appeals for the Federal Circuit: 1) affirmed the district court’s summary judgment rulings that Seagate did not misappropriate any of the alleged trade secrets and that the asserted claims of the ‘635 patent are invalid; 2) reversed and vacated the district court’s summary judgment of non-infringement with respect to the ‘473 patent; and 3) remanded the case for further proceedings on the ‘473 patent. On July 11, 2014, the district court granted the Company’s further summary judgment motion regarding the ‘473 patent. On February 10, 2016, the U.S. Court of Appeals for the Federal Circuit: 1) affirmed the district court’s summary judgment of no direct infringement by Seagate because Seagate’s ATA/SCSI disk drives do not meet the “user interface” limitation of the asserted claims of the ‘473 patent; 2) affirmed the district court’s summary judgment of non-infringement by Compaq’s products as to claims 1, 3, and 5 of the ‘473 patent because Compaq’s F10 BIOS interface does not meet the “commands” limitation of those claims; 3) vacated the district court’s summary judgment of non-infringement by Compaq’s accused products as to claims 7-15 of the ‘473 patent; 4) reversed the district court’s summary judgment of non-infringement based on intervening rights; and 5) remanded the case to the district court for further proceedings on the ‘473 patent. In view of the rulings made by the district court and the Court of Appeals and the uncertainty regarding the amount of damages, if any, that could be awarded Convolve in this matter, the Company does not believe that it is currently possible to determine a reasonable estimate of the possible range of loss related to this matter.

[0001628280-19-013092:notes:167]
Lambeth Magnetic Structures LLC v. Seagate Technology (US) Holdings, Inc., et al. On April 29, 2016, Lambeth Magnetic Structures LLC filed a complaint against Seagate Technology (US) Holdings, Inc. and Seagate Technology LLC in the U.S. District Court for the Western District of Pennsylvania, alleging infringement of U.S. Patent No. 7,128,988, “Magnetic Material Structures, Devices and Methods.” The Company believes the claims asserted in the complaint are without merit and intends to vigorously defend this case. The court issued its claim construction ruling on October 18, 2017. A jury trial in this matter is scheduled for June 1, 2020. While the possible range of loss for this matter remains uncertain, the Company estimates the amount of loss to be immaterial to the financial statements.

[0001628280-19-013092:notes:168]
Environmental Matters

[0001628280-19-013092:notes:169]
The Company’s operations are subject to U.S. and foreign laws and regulations relating to the protection of the environment, including those governing discharges of pollutants into the air and water, the management and disposal of hazardous substances and wastes and the cleanup of contaminated sites. Some of the Company’s operations require environmental permits and controls to prevent and reduce air and water pollution, and these permits are subject to modification, renewal and revocation by issuing authorities.

[0001628280-19-013092:notes:170]
The Company has established environmental management systems and continually updates its environmental policies and standard operating procedures for its operations worldwide. The Company believes that its operations are in material compliance with applicable environmental laws, regulations and permits. The Company budgets for operating and capital costs on an ongoing basis to comply with environmental laws. If additional or more stringent requirements are imposed on the Company in the future, it could incur additional operating costs and capital expenditures.

[0001628280-19-013092:notes:171]
Some environmental laws, such as the Comprehensive Environmental Response Compensation and Liability Act of 1980 (as amended, the “Superfund” law) and its state equivalents, can impose liability for the cost of cleanup of contaminated sites upon any of the current or former site owners or operators or upon parties who sent waste to these sites, regardless of whether the owner or operator owned the site at the time of the release of hazardous substances or the lawfulness of the original disposal activity. The Company has been identified as a responsible or potentially responsible party at several sites. At each of these sites, the Company has an assigned portion of the financial liability based on the type and amount of hazardous substances disposed of by each party at the site and the number of financially viable parties. The Company has fulfilled its responsibilities at some of these sites and remains involved in only a few at this time.

[0001628280-19-013092:notes:172]
While the Company’s ultimate costs in connection with these sites is difficult to predict with complete accuracy, based on its current estimates of cleanup costs and its expected allocation of these costs, the Company does not expect costs in connection with these sites to be material.

[0001628280-19-013092:notes:173]
The Company may be subject to various state, federal and international laws and regulations governing the environment, including those restricting the presence of certain substances in electronic products. For example, the European Union (“EU”) enacted the Restriction of the Use of Certain Hazardous Substances in Electrical and Electronic Equipment (2011/65/EU), which prohibits the use of certain substances, including lead, in certain products, including disk drives and server storage products, put on the market after July 1, 2006. Similar legislation has been or may be enacted in other jurisdictions, including in the United States, Canada, Mexico, Taiwan, China, Japan and others. The EU REACH Directive (Registration, Evaluation, Authorization, and Restriction of Chemicals, EC 1907/2006) also restricts substances of very high concern in products. If the Company or its suppliers fails to comply with the substance restrictions, recycle requirements or other environmental requirements as they are enacted worldwide, it could have a materially adverse effect on the Company’s business.

[0001628280-19-013092:notes:174]
Other Matters

[0001628280-19-013092:notes:175]
The Company is involved in a number of other judicial, regulatory or administrative proceedings and investigations incidental to its business, and the Company may be involved in such proceedings and investigations arising in the normal course of its business in the future. Although occasional adverse decisions or settlements may occur, the Company believes that the final disposition of such matters will not have a material adverse effect on its financial position or results of operations.


## us-gaap:SubsequentEventsTextBlock

[0001628280-19-013092:notes:176]
Subsequent Events

[0001628280-19-013092:notes:177]
Dividend Declared

[0001628280-19-013092:notes:178]
On October 28, 2019, the Company’s Board of Directors declared a quarterly cash dividend of $0.65 per share, which will be payable on January 8, 2020 to shareholders of record as of the close of business on December 26, 2019.
