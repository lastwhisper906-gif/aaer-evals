# STX MD&A — 0001628280-19-013092


## mdna

[0001628280-19-013092:mdna:1]
[same as prior period, unchanged from 0001193125-19-129284:mdna:1]

[0001628280-19-013092:mdna:2]
The following is a discussion of the financial condition, changes in financial condition, and results of operations for our fiscal quarters ended October 4, 2019, June 28, 2019 and September 28, 2018, referred to herein as the “September 2019 quarter,” the “June 2019 quarter,” and the “September 2018 quarter,” respectively. We operate and report financial results on a fiscal year of 52 or 53 weeks ending on the Friday closest to June 30. The September 2019 quarter was 14 weeks and the June 2019 quarter and September 2018 quarter were each 13 weeks.

[0001628280-19-013092:mdna:3]
You should read this discussion in conjunction with financial information and related notes included elsewhere in this report. Unless the context indicates otherwise, as used herein, the terms “we,” “us,” “Seagate,” the “Company” and “our” refer to Seagate Technology plc, an Irish public limited company, and its subsidiaries. References to “$” are to United States dollars.

[0001628280-19-013092:mdna:4]
| • | addressing the many challenges facing the Company’s business; |

[0001628280-19-013092:mdna:5]
| • | the uncertainty in global economic and political conditions; |

[0001628280-19-013092:mdna:6]
| • | the development and introduction of products based on new technologies and expansion into new data storage markets, and market acceptance of new products; |

[0001628280-19-013092:mdna:7]
| • | the impact of competitive product announcements and unexpected advances in competing technologies or changes in market trends; |

[0001628280-19-013092:mdna:8]
| • | the impact of variable demand, changes in market demand, and an adverse pricing environment for storage products; |

[0001628280-19-013092:mdna:9]
| • | the Company’s ability to effectively manage its debt obligations and comply with certain covenants in its credit facilities with respect to financial ratios and financial condition tests and its ability to maintain a favorable cash liquidity position; |

[0001628280-19-013092:mdna:10]
| • | the Company’s ability to successfully qualify, manufacture and sell its storage products in increasing volumes on a cost-effective basis and with acceptable quality; |

[0001628280-19-013092:mdna:11]
| • | any price erosion or volatility of sales volumes through the Company’s distributor and retail channel; |

[0001628280-19-013092:mdna:12]
| • | disruptions to the Company’s supply chain or production capabilities; |

[0001628280-19-013092:mdna:13]
| • | currency fluctuations that may impact the Company’s margins, international sales and results of operations; |

[0001628280-19-013092:mdna:14]
| • | the impact of trade barriers, such as import/export duties and restrictions, tariffs and quotas, imposed by the U.S. or other countries in which the Company conducts business; |

[0001628280-19-013092:mdna:15]
| • | the evolving legal, regulatory and administrative climate in the international markets where the Company operates; and |

[0001628280-19-013092:mdna:16]
| • | cyber-attacks or other data breaches that disrupt the Company’s operations or result in the dissemination of proprietary or confidential information and cause reputational harm. |

[0001628280-19-013092:mdna:17]
Our Management’s Discussion and Analysis of Financial Condition and Results of Operations (“MD&A”) is provided in addition to the accompanying condensed consolidated financial statements and notes to assist readers in understanding our results of operations, financial condition, and cash flows. Our MD&A is organized as follows:

[0001628280-19-013092:mdna:18]
| • | Overview of the September 2019 quarter. Highlights of events in the September 2019 quarter that impacted our financial position. |

[0001628280-19-013092:mdna:19]
| • | Results of Operations. An analysis of our financial results comparing the September 2019 quarter to the September 2018 quarter and the June 2019 quarter. |

[0001628280-19-013092:mdna:20]
| • | Liquidity and Capital Resources. An analysis of changes in our balance sheet and cash flows, and discussion of our financial condition including the credit quality of our investment portfolio and potential sources of liquidity. |

[0001628280-19-013092:mdna:21]
| • | Critical Accounting Policies. Accounting policies and estimates that we believe are important to understanding the assumptions and judgments incorporated in our reported financial results. |

[0001628280-19-013092:mdna:22]
For an overview of our business, see “Part I, Item 1. Financial Statements—Note 1. Basis of Presentation and Summary of Significant Accounting Policies—Organization”

[0001628280-19-013092:mdna:23]
Overview of the September 2019 quarter

[0001628280-19-013092:mdna:24]
During the September 2019 quarter, we shipped 98 exabytes of HDD storage capacity. We generated revenue of approximately $2.6 billion, gross margin of 26% and our operating cash flow was $456 million. We repurchased an aggregate principal amount of $620 million of certain outstanding senior notes in connection with the Tender Offers and borrowed $500 million under the Term Loan. We repurchased approximately 9 million of our ordinary shares for $450 million and paid $170 million in dividends. Additionally, we changed our estimate of the useful lives of our manufacturing equipment from a range of three to five years to a range of three to seven years. The effect of this change in estimate increased the September 2019 quarter net income by $23 million.

[0001628280-19-013092:mdna:25]
[same as prior period, unchanged from 0001193125-19-129284:mdna:34]

[0001628280-19-013092:mdna:26]
We list in the tables below summarized information from our Condensed Consolidated Statements of Operations by dollars and as a percentage of revenue:

[0001628280-19-013092:mdna:27]
|  |  | For the Three Months Ended |
| (Dollars in millions) |  | October 4, 2019 |  | June 28, 2019 |  | September 28, 2018 |
| Revenue |  | $ | 2,578 |  |  | $ | 2,371 |  |  | $ | 2,991 |  |
| Cost of revenue |  | 1,907 |  |  | 1,747 |  |  | 2,078 |  |
| Gross margin |  | 671 |  |  | 624 |  |  | 913 |  |
| Product development |  | 255 |  |  | 241 |  |  | 266 |  |
| Marketing and administrative |  | 122 |  |  | 108 |  |  | 115 |  |
| Amortization of intangibles |  | 4 |  |  | 6 |  |  | 6 |  |
| Restructuring and other, net |  | 17 |  |  | (63 | ) |  | 23 |  |
| Income from operations |  | 273 |  |  | 332 |  |  | 503 |  |
| Other expense, net |  | (75 | ) |  | (41 | ) |  | (35 | ) |
| Income before income taxes |  | 198 |  |  | 291 |  |  | 468 |  |
| (Benefit) provision for income taxes |  | (2 | ) |  | (692 | ) |  | 18 |  |
| Net income |  | $ | 200 |  |  | $ | 983 |  |  | $ | 450 |  |

[0001628280-19-013092:mdna:28]
28

[0001628280-19-013092:mdna:29]
|  |  | For the Three Months Ended |
|  |  | October 4, 2019 |  | June 28, 2019 |  | September 28, 2018 |
| Revenue |  | 100 | % |  | 100 | % |  | 100 | % |
| Cost of revenue |  | 74 |  |  | 74 |  |  | 69 |  |
| Gross margin |  | 26 |  |  | 26 |  |  | 31 |  |
| Product development |  | 10 |  |  | 10 |  |  | 9 |  |
| Marketing and administrative |  | 5 |  |  | 5 |  |  | 4 |  |
| Amortization of intangibles |  | — |  |  | — |  |  | — |  |
| Restructuring and other, net |  | — |  |  | (3 | ) |  | 1 |  |
| Income from operations |  | 11 |  |  | 14 |  |  | 17 |  |
| Other expense, net |  | (3 | ) |  | (2 | ) |  | (1 | ) |
| Income before income taxes |  | 8 |  |  | 12 |  |  | 16 |  |
| (Benefit) provision for income taxes |  | — |  |  | (29 | ) |  | 1 |  |
| Net income |  | 8 | % |  | 41 | % |  | 15 | % |

[0001628280-19-013092:mdna:30]
[same as prior period, unchanged from 0001193125-19-129284:mdna:38]

[0001628280-19-013092:mdna:31]
The following table summarizes information regarding consolidated revenues by channel and geography, HDD price per terabyte and HDD exabytes shipped:

[0001628280-19-013092:mdna:32]
|  |  | For the Three Months Ended |
|  |  | October 4, 2019 |  | June 28, 2019 |  | September 28, 2018 |
| Revenues by Channel (%) |  |  |  |  |  |  |  |  |
| OEMs |  | 71 | % |  | 71 | % |  | 71 | % |
| Distributors |  | 18 | % |  | 17 | % |  | 18 | % |
| Retailers |  | 11 | % |  | 12 | % |  | 11 | % |
| Revenues by Geography (%) |  |  |  |  |  |  |  |  |  |
| Americas |  | 32 | % |  | 33 | % |  | 34 | % |
| EMEA |  | 18 | % |  | 17 | % |  | 17 | % |
| Asia Pacific |  | 50 | % |  | 50 | % |  | 49 | % |
| HDD Price per Terabyte |  | $ | 24 |  |  | $ | 26 |  |  | $ | 28 |  |
| HDD Exabytes Shipped |  | 98 |  |  | 84 |  |  | 99 |  |

[0001628280-19-013092:mdna:33]
Revenue in the September 2019 quarter increased by $207 million from the June 2019 quarter primarily due to an increase in exabytes shipped and improved product mix, partially offset by price erosion.

[0001628280-19-013092:mdna:34]
Revenue in the September 2019 quarter decreased by $413 million from the September 2018 quarter primarily due to less favorable market conditions and price erosion.

[0001628280-19-013092:mdna:35]
We maintain various sales incentive programs such as channel rebates and price masking. Sales incentive programs were approximately 13%, 11% and 11% of gross HDD revenue for the September 2019 quarter, June 2019 quarter and September 2018 quarter, respectively. Adjustments to revenues due to under or over accruals for sales incentive programs related to revenues reported in prior quarterly periods were less than 1% of quarterly gross revenue in all periods presented.

[0001628280-19-013092:mdna:36]
[same as prior period, unchanged from 0001193125-19-129284:mdna:45]

[0001628280-19-013092:mdna:37]
|  |  | For the Three Months Ended |
| (Dollars in millions) |  | October 4, 2019 |  | June 28, 2019 |  | September 28, 2018 |
| Cost of revenue |  | $ | 1,907 |  |  | $ | 1,747 |  |  | $ | 2,078 |  |
| Gross margin |  | 671 |  |  | 624 |  |  | 913 |  |
| Gross margin percentage |  | 26 | % |  | 26 | % |  | 31 | % |

[0001628280-19-013092:mdna:38]
Gross margin as a percentage of revenue for the September 2019 quarter remained relatively flat compared to the June 2019 quarter.

[0001628280-19-013092:mdna:39]
Compared to the September 2018 quarter, gross margin as a percentage of revenue for the September 2019 quarter decreased primarily driven by price erosion and factory under-utilization.

[0001628280-19-013092:mdna:40]
In the September 2019 quarter, total warranty cost was 0.5% of revenue and included a favorable change in estimates of prior warranty accruals of 0.4% of revenue due to improvements in return rates on newer generation products. Warranty cost related to new shipments was 0.9%, 0.9% and 1.2% of revenue for the September 2019 quarter, June 2019 quarter and September 2018 quarter, respectively.

[0001628280-19-013092:mdna:41]
[same as prior period, unchanged from 0001193125-19-129284:mdna:51]

[0001628280-19-013092:mdna:42]
|  |  | For the Three Months Ended |
| (Dollars in millions) |  | October 4, 2019 |  | June 28, 2019 |  | September 28, 2018 |
| Product development |  | $ | 255 |  |  | $ | 241 |  |  | $ | 266 |  |
| Marketing and administrative |  | 122 |  |  | 108 |  |  | 115 |  |
| Amortization of intangibles |  | 4 |  |  | 6 |  |  | 6 |  |
| Restructuring and other, net |  | 17 |  |  | (63 | ) |  | 23 |  |
| Operating expenses |  | $ | 398 |  |  | $ | 292 |  |  | $ | 410 |  |

[0001628280-19-013092:mdna:43]
Product development expense. Product development expense for the September 2019 quarter increased by $14 million compared to the June 2019 quarter due to a $14 million increase in compensation and other employee benefits resulting primarily from the additional fourteenth week in the September 2019 quarter.

[0001628280-19-013092:mdna:44]
Compared to the September 2018 quarter, Product development expense for the September 2019 quarter decreased by $11 million primarily due to a $10 million decrease in other general expenses as a result of timing of materials purchases and a $5 million decrease in variable compensation expense, partially offset by an increase in expense from the additional fourteenth week in the September 2019 quarter.

[0001628280-19-013092:mdna:45]
Marketing and administrative expense. Marketing and administrative expense for the September 2019 quarter increased by $14 million from the June 2019 quarter, primarily due to a $9 million increase in other general expenses as a result of increased outside services, a $2 million increase in variable compensation expense and a $2 million increase in compensation and other employee benefits mainly resulting from the additional fourteenth week in the September 2019 quarter.

[0001628280-19-013092:mdna:46]
Compared to the September 2018 quarter, Marketing and administrative expense for the September 2019 quarter increased by $7 million, primarily due to a $4 million increase in share-based compensation expense and a $4 million increase in other general expenses mainly as a result of increased outside services and increase in expense from the additional fourteenth week in the September 2019 quarter.

[0001628280-19-013092:mdna:47]
Amortization of intangibles. Amortization of intangibles for the September 2019 quarter decreased by $2 million from the June 2019 quarter and the September 2018 quarter due to certain intangible assets reaching the end of their useful lives.

[0001628280-19-013092:mdna:48]
Restructuring and other, net. Restructuring and other, net for the September 2019 quarter was comprised of charges primarily related to a new voluntary early exit program.

[0001628280-19-013092:mdna:49]
Restructuring and other, net for the June 2019 quarter was comprised primarily of a gain from the sale of certain property.

[0001628280-19-013092:mdna:50]
Restructuring and other, net for the September 2018 quarter was comprised of charges primarily related to a voluntary early exit program.

[0001628280-19-013092:mdna:51]
[same as prior period, unchanged from 0001193125-19-129284:mdna:62]

[0001628280-19-013092:mdna:52]
|  |  | For the Three Months Ended |
| (Dollars in millions) |  | October 4, 2019 |  | June 28, 2019 |  | September 28, 2018 |
| Other expense, net |  | $ | (75 | ) |  | $ | (41 | ) |  | $ | (35 | ) |

[0001628280-19-013092:mdna:53]
Other expense, net. Other expense, net for the September 2019 quarter increased by $34 million from the June 2019 quarter, primarily due to a $30 million loss resulting from the repurchase of certain long-term debt and a $5 million decrease in interest income mainly resulting from the redemption of our investment in Toshiba Memory Holdings Corporation (“TMHC”) in the June 2019 quarter.

[0001628280-19-013092:mdna:54]
Compared to the September 2018 quarter, Other expense, net for the September 2019 quarter increased by $40 million primarily due to a $30 million loss resulting from the repurchase of certain long-term debt and an $11 million decrease in interest income mainly resulting from the redemption of our investment in TMHC in the June 2019 quarter.

[0001628280-19-013092:mdna:55]
[same as prior period, unchanged from 0001193125-19-129284:mdna:67]

[0001628280-19-013092:mdna:56]
|  |  | For the Three Months Ended |
| (Dollars in millions) |  | October 4, 2019 |  | June 28, 2019 |  | September 28, 2018 |
| (Benefit) provision for income taxes |  | $ | (2 | ) |  | $ | (692 | ) |  | $ | 18 |  |

[0001628280-19-013092:mdna:57]
Our income tax benefit of $2 million for the three months ended October 4, 2019 included approximately $11 million of net discrete tax benefit of which $8 million was associated with net excess tax benefits related to share-based compensation expense.

[0001628280-19-013092:mdna:58]
Our income tax provision recorded for the three months ended October 4, 2019 differed from the provision for income taxes that would be derived by applying the Irish statutory rate of 25% to income before income taxes, primarily due to the net effect of tax benefits related to (i) non-Irish earnings generated in jurisdictions that are subject to tax incentive programs and are considered indefinitely reinvested outside of Ireland and (ii) current year generation of research credits.

[0001628280-19-013092:mdna:59]
During the three months ended October 4, 2019, our unrecognized tax benefits excluding interest and penalties increased by approximately $2 million to $85 million. The unrecognized tax benefits that, if recognized, would impact the effective tax rate were $85 million at October 4, 2019, subject to certain future valuation allowance reversals. During the 12 months beginning October 5, 2019, we expect that our unrecognized tax benefits could be reduced by an immaterial amount, as a result of expected cash payments to tax authorities.

[0001628280-19-013092:mdna:60]
Our income tax provision of $18 million for the three months ended September 28, 2018 included approximately $1 million of net discrete tax expense.

[0001628280-19-013092:mdna:61]
Our income tax provision recorded for the three months ended September 28, 2018 differed from the provision from income taxes that would be derived by applying the Irish statutory rate of 25% to income before income taxes, primarily due to the net effect of (i) tax benefits related to non-Irish earnings generated in jurisdictions that are subject to tax holidays or tax incentive programs and are considered indefinitely reinvested outside of Ireland and (ii) a decrease in valuation allowance for certain deferred tax assets.

[0001628280-19-013092:mdna:62]
[same as prior period, unchanged from 0001193125-19-129284:mdna:78]

[0001628280-19-013092:mdna:63]
The following sections discuss our principal liquidity requirements, as well as our sources and uses of cash and our liquidity and capital resources. Our cash and cash equivalents are maintained in investments with remaining maturities of 90 days or less at the time of purchase. Our short-term investments consist primarily of money market funds, time deposits and certificates of deposit. The principal objectives of our investment policy are the preservation of principal and maintenance of liquidity. We believe our cash equivalents and short-term investments are liquid and accessible. We operate in some countries that have restrictive regulations over the movement of cash and/or foreign exchange across their borders. However, we believe our sources of cash have been and will continue to be sufficient to meet our cash needs for the next 12 months. We are not aware of any downgrades, losses or other significant deterioration in the fair value of our cash equivalents or short-term investments, and we do not believe the fair value of our short-term investments has significantly changed from the values reported as of October 4, 2019.

[0001628280-19-013092:mdna:64]
31

[0001628280-19-013092:mdna:65]
[same as prior period, unchanged from 0001193125-19-129284:mdna:80]

[0001628280-19-013092:mdna:66]
| (Dollars in millions) |  | October 4, 2019 |  | June 28, 2019 |  | Change |
| Cash and cash equivalents |  | $ | 1,784 |  |  | $ | 2,220 |  |  | $ | (436 | ) |

[0001628280-19-013092:mdna:67]
Our cash and cash equivalents as of October 4, 2019 decreased by $436 million from June 28, 2019 primarily as a result of the repurchase of certain senior notes of $645 million for $620 million in aggregate principal amount, repurchases of our ordinary shares of $450 million, dividends to our shareholders of $170 million, and payments for capital expenditures of $147 million, partially offset by net proceeds of $498 million from borrowings under our Term Loan and net cash of $456 million provided by operating activities.

[0001628280-19-013092:mdna:68]
[same as prior period, unchanged from 0001193125-19-129284:mdna:83]

[0001628280-19-013092:mdna:69]
Cash provided by operating activities for the three months ended October 4, 2019 was $456 million and includes the effects of net income adjusted for non-cash items including depreciation, amortization, share-based compensation and:

[0001628280-19-013092:mdna:70]
| • | an increase of $281 million in accounts payable, primarily due to timing of payments and an increase in materials purchases; |

[0001628280-19-013092:mdna:71]
| • | partially offset by an increase of $77 million in accounts receivable, primarily due to timing of collections and an increase in revenue; |

[0001628280-19-013092:mdna:72]
| • | an increase of $65 million in inventories, primarily due to an increase in material purchases; and |

[0001628280-19-013092:mdna:73]
| • | a decrease of $20 million in accrued employee compensation primarily due to cash paid to our employees as part of our discretionary spending plans. |

[0001628280-19-013092:mdna:74]
[same as prior period, unchanged from 0001193125-19-129284:mdna:88]

[0001628280-19-013092:mdna:75]
Cash used in investing activities for the three months ended October 4, 2019 was $151 million, primarily attributable to the payments for the purchase of property, equipment and leasehold improvements of $147 million.

[0001628280-19-013092:mdna:76]
[same as prior period, unchanged from 0001193125-19-129284:mdna:90]

[0001628280-19-013092:mdna:77]
Cash used in financing activities of $765 million for the three months ended October 4, 2019 was primarily attributable to the following activities:

[0001628280-19-013092:mdna:78]
| • | $645 million in payments for repurchase of certain long-term debt; |

[0001628280-19-013092:mdna:79]
| • | $450 million in payments for repurchase of our ordinary shares; |

[0001628280-19-013092:mdna:80]
| • | $170 million in dividend payments; |

[0001628280-19-013092:mdna:81]
| • | $37 million in payments for taxes related to net share settlement of equity awards; |

[0001628280-19-013092:mdna:82]
| • | partially offset by $498 million in net proceeds from the borrowing under the Term Loan; and |

[0001628280-19-013092:mdna:83]
| • | $39 million in proceeds from the issuance of ordinary shares under employee stock plans. |

[0001628280-19-013092:mdna:84]
[same as prior period, unchanged from 0001193125-19-129284:mdna:98]

[0001628280-19-013092:mdna:85]
Our primary sources of liquidity as of October 4, 2019 consisted of: (1) approximately $1.8 billion in cash and cash equivalents, (2) cash we expect to generate from operations, and (3) $1.5 billion available for borrowing under our Revolving Credit Facility.

[0001628280-19-013092:mdna:86]
On September 17, 2019, we borrowed a principal amount of $500 million under the Term Loan and the proceeds were used to repurchase a portion of our outstanding senior notes. The Term Loan bears interest at a rate of LIBOR plus a variable margin  determined based on our corporate credit rating. The Term Loan is repayable in quarterly installments of 1.25% of the original principal amount beginning on December 31, 2020, with the remaining balance payable upon maturity on September 16, 2025.

[0001628280-19-013092:mdna:87]
As of October 4, 2019, no borrowings had been drawn and no borrowings had been utilized for letters of credit or swing line loans issued under the Revolving Credit Facility. The Revolving Credit Facility is available for borrowings, subject to compliance with financial covenants and other customary conditions to borrowing.

[0001628280-19-013092:mdna:88]
The Credit Agreement includes three financial covenants: (1) interest coverage ratio, (2) total leverage ratio, and (3) a minimum liquidity amount. The term of the Revolving Credit Facility is through February 20, 2024, and the maturity date of the Term Loan is September 16, 2025. We were in compliance with the covenants as of October 4, 2019 and expect to be in compliance for the next 12 months.

[0001628280-19-013092:mdna:89]
32

[0001628280-19-013092:mdna:90]
Our liquidity requirements are primarily to meet our working capital, product development and capital expenditure needs, to fund scheduled payments of principal and interest on our indebtedness, and to fund our quarterly dividend and any future strategic investments. Our ability to fund these requirements will depend on our future cash flows, which are determined by future operating performance, and therefore, subject to prevailing global macroeconomic conditions and financial, business and other factors, some of which are beyond our control.

[0001628280-19-013092:mdna:91]
For fiscal year 2020, we expect capital expenditures to remain within our long-term targeted range of 6% to 8% of revenue.

[0001628280-19-013092:mdna:92]
From time to time we may repurchase any of our outstanding notes in open market or privately negotiated purchases or otherwise, or we may repurchase outstanding notes pursuant to the terms of the applicable indenture.

[0001628280-19-013092:mdna:93]
Dividends declared in the September 2019 quarter of $165 million were subsequently paid on October 9, 2019. Our Board of Directors declared a quarterly cash dividend of $0.65 per share on October 28, 2019, which is payable on January 8, 2020 to shareholders of record at the close of business on December 26, 2019.

[0001628280-19-013092:mdna:94]
From time to time, we may repurchase any of our outstanding ordinary shares through tender offers,  private, open market or  broker-assisted purchases or other means. As of October 4, 2019, $1.7 billion remained available for repurchases under our existing repurchase authorization. All repurchases are effected as redemptions in accordance with our Articles of Association.

[0001628280-19-013092:mdna:95]
[same as prior period, unchanged from 0001193125-19-129284:mdna:116]

[0001628280-19-013092:mdna:96]
Our discussion and analysis of financial condition and results of operations are based upon our condensed consolidated financial statements, which have been prepared in accordance with U.S. generally accepted accounting principles. The preparation of such statements requires us to make estimates and assumptions that affect the reported amounts of revenues and expenses during the reporting period and the reported amounts of assets and liabilities as of the date of the financial statements. Our estimates are based on historical experience and other assumptions that we consider to be appropriate in the circumstances. However, actual future results may vary from our estimates.

[0001628280-19-013092:mdna:97]
Other than as described in “Part I, Item 1. Financial Statements—Note 1. Basis of Presentation and Summary of Significant Accounting Policies”, there have been no other material changes in our critical accounting policies and estimates. Refer to “Management’s Discussion and Analysis of Financial Condition and Results of Operations” contained in Part II, Item 7. of our Annual Report on Form 10-K for the fiscal year ended June 28, 2019, as filed with the SEC on August 2, 2019, for a discussion of our critical accounting policies and estimates.

[0001628280-19-013092:mdna:98]
[same as prior period, unchanged from 0001193125-19-129284:mdna:119]

[0001628280-19-013092:mdna:99]
See “Part I, Item 1. Financial Statements—Note 1. Basis of Presentation and Summary of Significant Accounting Policies” for information regarding the effect of new accounting pronouncements on our financial statements.

[0001628280-19-013092:mdna:100]
33
