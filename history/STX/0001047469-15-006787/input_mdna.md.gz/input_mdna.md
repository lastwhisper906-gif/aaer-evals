# STX MD&A — 0001047469-15-006787


## mdna

[0001047469-15-006787:mdna:1]
ITEM 7.    MANAGEMENT'S DISCUSSION AND ANALYSIS OF FINANCIAL CONDITION AND RESULTS OF OPERATIONS

[0001047469-15-006787:mdna:2]
The following is a discussion of the Company's financial condition, changes in financial condition and results
of operations for the fiscal years ended, July 3, 2015, June 27, 2014 and June 28, 2013.

[0001047469-15-006787:mdna:3]
You should read this discussion in conjunction with "Item 6. Selected Financial Data" and "Item 8. Financial Statements and Supplementary Data"
included elsewhere in this Annual Report on Form 10-K. Except as noted, references to any fiscal year mean the twelve-month period ending on the Friday closest to June 30 of that year.
Accordingly, fiscal year 2015 comprised 53 weeks and ended on July 3, 2015. Fiscal years 2014 and 2013 comprised 52 weeks and ended on June 27, 2014 and June 28,
2013, respectively. Fiscal year 2016 will be 52 weeks and will end on July 1, 2016.

[0001047469-15-006787:mdna:4]
Our
Management's Discussion and Analysis of Financial Condition and Results of Operations (MD&A) is provided in addition to the accompanying consolidated financial statements and notes
to assist readers in understanding our results of operations, financial condition, and cash flows. MD&A is organized as follows:

[0001047469-15-006787:mdna:5]
•

[0001047469-15-006787:mdna:6]
Our Company.  Discussion of our business.

[0001047469-15-006787:mdna:7]
•

[0001047469-15-006787:mdna:8]
Business Overview.  Discussion of industry trends and
their impact on our business.

[0001047469-15-006787:mdna:9]
•

[0001047469-15-006787:mdna:10]
Fiscal Year 2015 Summary.  Overview of financial and
other highlights affecting us for fiscal year 2015.

[0001047469-15-006787:mdna:11]
•

[0001047469-15-006787:mdna:12]
Results of Operations.  Analysis of our financial results
comparing fiscal year 2015 to 2014 and comparing fiscal years 2014 to 2013.

[0001047469-15-006787:mdna:13]
•

[0001047469-15-006787:mdna:14]
Liquidity and Capital Resources.  An analysis of changes
in our balance sheets and cash flows, and discussion of our financial condition including the credit quality of our investment portfolio and potential sources of liquidity.

[0001047469-15-006787:mdna:15]
•

[0001047469-15-006787:mdna:16]
Contractual Obligations and Off-Balance-Sheet
Arrangements.  Overview of contractual obligations and contingent liabilities and commitments outstanding as of July 3, 2015 and
an explanation of off-balance-sheet arrangements.

[0001047469-15-006787:mdna:17]
•

[0001047469-15-006787:mdna:18]
Critical Accounting Estimates.  Accounting estimates that
we believe are important to understanding the assumptions and judgments incorporated in our reported financial results.

[0001047469-15-006787:mdna:19]
Our Company

[0001047469-15-006787:mdna:20]
We are a leading provider of electronic data storage technology and solutions. Our principal products are hard disk drives, commonly
referred to as disk drives, hard drives or HDDs. In addition to HDDs, we produce a broad range of electronic data storage products including solid state hybrid drives ("SSHD"), solid state drives
("SSD"), PCIe cards and SATA controllers. Our storage technology portfolio also includes storage subsystems, high performance computing (HPC) solutions, and data storage services.

[0001047469-15-006787:mdna:21]
Hard
disk drives are devices that store digitally encoded data on rapidly rotating disks with magnetic surfaces. Disk drives continue to be the primary medium of mass data storage due to
their performance attributes, high quality and cost effectiveness. Complementing existing data center storage architecture, solid-state storage devices use integrated circuit assemblies as memory to
store data, and most SSDs use NAND-based flash memory. In addition to HDDs and SSDs, Solid-state hybrid drives (SSHDs) combine the features of SSDs and HDDs in the same unit, containing a large hard
disk drive and an SSD cache to improve performance of frequently accessed data.

[0001047469-15-006787:mdna:22]
Our
products are designed for enterprise servers and storage systems in mission critical and nearline applications; client compute applications, where our products are designed primarily
for desktop and mobile computing; and client non-compute applications, where our products are designed for a wide variety of end user devices such as digital video recorders ("DVRs"), personal data
backup systems, portable external storage systems, digital media systems and surveillance systems.

[0001047469-15-006787:mdna:23]
Our
product and solution portfolio for the enterprise data storage industry includes storage enclosures, integrated application platforms and high performance computing ("HPC") data
storage solutions. Our storage subsystems support a range of high-speed interconnect technologies to meet demanding cost and performance specifications. Our modular subsystem architecture allows us to
support many segments within the networked storage market by enabling different specifications of storage subsystem designs to be created from a standard set of interlocking technology modules.

[0001047469-15-006787:mdna:24]
Our
data storage services provide online backup, data protection and recovery solutions for small to medium-sized businesses.

[0001047469-15-006787:mdna:25]
Business Overview

[0001047469-15-006787:mdna:26]
Our industry is characterized by several trends and factors that have a material impact on our strategic planning, financial condition
and results of operations.

[0001047469-15-006787:mdna:27]
Demand for Electronic Data Storage

[0001047469-15-006787:mdna:28]
The continued advancement of the cloud, the proliferation of a variety of mobile devices globally, development of the internet of
things, increasingly pervasive use of video surveillance, evolution of

[0001047469-15-006787:mdna:29]
consumer
electronic devices, and enterprise use of big data analytics are driving the growth of digital content. Factors contributing to this growth
include:

[0001047469-15-006787:mdna:30]
•

[0001047469-15-006787:mdna:31]
Creation, sharing, and consumption of media-rich digital content, such as high-resolution photos, high definition video, and digital
music through smart phones, tablets, digital cameras, personal video cameras, DVRs, gaming consoles or other digital devices;

[0001047469-15-006787:mdna:32]
•

[0001047469-15-006787:mdna:33]
Creation, aggregation and distribution of digital content through services and other offerings such as Facebook®,
Instagram®, iTunes®, LinkedIn®, Netflix®, Pandora®, Google® and YouTube®;

[0001047469-15-006787:mdna:34]
•

[0001047469-15-006787:mdna:35]
New surveillance systems which feature higher resolution digital cameras and thus require larger data storage capacities;

[0001047469-15-006787:mdna:36]
•

[0001047469-15-006787:mdna:37]
Creation and collection of data through the evolution of the internet of things ecosystem, big data analytics and new technology
trends such as self-driving cars and drones;

[0001047469-15-006787:mdna:38]
•

[0001047469-15-006787:mdna:39]
Build out of large numbers of cloud data centers by cloud service providers and private companies transitioning on-site data centers
into the cloud;

[0001047469-15-006787:mdna:40]
•

[0001047469-15-006787:mdna:41]
Protection of increased digital content through redundant storage on backup devices and externally provided storage services.

[0001047469-15-006787:mdna:42]
As
a result of these factors, the nature and volume of content being created requires greater storage, which is more efficiently and economically facilitated by higher capacity storage
devices in order to store, manage, distribute, analyze and backup such content. We expect this to support the growth in demand for electronic data storage solutions in developed and emerging economies
well into the future.

[0001047469-15-006787:mdna:43]
The
amount of data created as well as where and how data is stored continues to evolve with the proliferation of mobile devices, the growth of cloud computing, and the evolving internet
of things. In addition, the economics of storage infrastructure are also evolving with the utilization of public and private hyper-scale storage and open-source solutions reducing the total cost of
ownership of storage while increasing the speed and efficiency with which customers can leverage massive computing and storage devices. Accordingly, we expect these trends will continue to create
significant demand for electronic data storage solutions going forward.

[0001047469-15-006787:mdna:44]
Demand Trends for Disk Drives

[0001047469-15-006787:mdna:45]
We believe that continued growth in digital content requires increasingly higher storage capacity in order to store, aggregate, host,
distribute, analyze, manage, backup and use such content. We also believe that as architectures evolve to serve the growing commercial and consumer user base throughout the world, the manner which
hard drives are delivered to market and utilized by our customers will evolve as well.

[0001047469-15-006787:mdna:46]
We
believe that in the foreseeable future the traditional enterprise, client compute markets that require high capacity storage solutions, and the data intensive client non-compute
markets will continue to be best served by hard disk drives due to the industry's ability to deliver the most cost effective, reliable
and energy efficient mass storage devices. Furthermore, the increased use of client non-compute devices that both consume media-rich digital content streamed from the cloud and create rich digital
content that is stored in the cloud, increases the demand for high capacity hard disk drives in enterprise Nearline applications.

[0001047469-15-006787:mdna:47]
Industry Supply Balance

[0001047469-15-006787:mdna:48]
From time to time the HDD industry has experienced periods of imbalance between supply and demand. To the extent that the disk drive
industry builds or maintains capacity based on expectations of

[0001047469-15-006787:mdna:49]
44

[0001047469-15-006787:mdna:50]
demand
that do not materialize, price erosion may become more pronounced. Conversely, during periods where demand exceeds supply, price erosion is generally muted.

[0001047469-15-006787:mdna:51]
Price Erosion.

[0001047469-15-006787:mdna:52]
Historically, our industry has been characterized by price declines for disk drive products with comparable capacity, performance and
feature sets ("like-for-like products"). Price declines for like-for-like products ("price erosion") have been more pronounced during periods of:

[0001047469-15-006787:mdna:53]
•

[0001047469-15-006787:mdna:54]
economic contraction in which competitors may use discounted pricing to attempt to maintain or gain market share;

[0001047469-15-006787:mdna:55]
•

[0001047469-15-006787:mdna:56]
few new product introductions when competitors have comparable or alternative product offerings; and

[0001047469-15-006787:mdna:57]
•

[0001047469-15-006787:mdna:58]
industry supply exceeding demand.

[0001047469-15-006787:mdna:59]
Disk
drive manufacturers typically attempt to offset price erosion with an improved mix of disk drive products characterized by higher capacity, better performance and additional feature
sets and/or product cost reductions.

[0001047469-15-006787:mdna:60]
We
believe the HDD industry experienced benign price erosion in fiscal years 2013, 2014 and moderate price erosion in fiscal year 2015.

[0001047469-15-006787:mdna:61]
Product Life Cycles and Changing Technology.    Success in our industry has been dependent to a large extent on the ability to balance the
introduction
and transition of new products with time-to-volume, performance, capacity and quality metrics at a competitive price, level of service and support that our customers expect. Generally, the drive
manufacturer that introduces a new product first benefits from improved product mix, favorable profit margins and less pricing pressure until comparable products are introduced. Changing technology
also necessitates on-going investments in research and development, which may be difficult to recover due to rapid product life cycles and economic declines. Further, there is a continued need to
successfully execute product transitions and new product introductions, as factors such as quality, reliability and manufacturing yields continue to be of significant competitive importance.

[0001047469-15-006787:mdna:62]
Seasonality

[0001047469-15-006787:mdna:63]
The disk drive industry traditionally experiences seasonal variability in demand with higher levels of demand in the second half of the
calendar year. This seasonality is driven by consumer spending in the back-to-school season from late summer to fall and the traditional holiday shopping season from fall to winter. In fiscal years
2013 and 2014, our industry experienced muted seasonal patterns as supply and demand were relatively in balance. However, we believe fiscal year 2015 reflected a seasonal pattern consistent with
historical patterns.

[0001047469-15-006787:mdna:64]
Fiscal Year 2015 Summary

[0001047469-15-006787:mdna:65]
During the fiscal year 2015, we shipped 212 million units totaling 228 exabytes, generating revenue of $13.7 billion and
gross margins of 28% of revenue. Our operating cash flow was $2.6 billion, which included $773 million received from Western Digital as partial payment of the final award plus accrued
interest in our arbitration case against Western Digital and a $225 million payment related to the final audit assessment received from the Jiangsu Province State Tax Bureau of the People's
Republic of China for tax and interest associated with changes to our tax filings for the calendar years 2007 through 2013. We issued $500 million of 5.75% Senior Notes due 2034 and
$700 million of 4.875% Senior Notes due 2027 during the December 2014 and June 2015 quarters, respectively. We repurchased approximately 19 million of our ordinary shares during the year
for approximately $1.1 billion, paid $0.9 billion for the early repurchase and redemption of debt, paid dividends during the year of $0.7 billion, and completed our

[0001047469-15-006787:mdna:66]
45

[0001047469-15-006787:mdna:67]
acquisition
of certain assets and liabilities of LSI Corporation's ("LSI") Accelerated Solutions Division and Flash Components Division (collectively, the "Flash Business") from Avago Technologies
Limited for $450 million in cash.

[0001047469-15-006787:mdna:68]
Results of Operations

[0001047469-15-006787:mdna:69]
We list in the tables below summarized information from our Consolidated Statements of Operations by dollars and as a percentage of
revenue:

[0001047469-15-006787:mdna:70]
|  |  | Fiscal Years Ended |  |
| (Dollars in millions) |  | July 3, 2015 |  | June 27, 2014 |  | June 28, 2013 |  |
| Revenue |  | $ | 13,739 |  | $ | 13,724 |  | $ | 14,351 |  |
| Cost of revenue |  |  | 9,930 |  |  | 9,878 |  |  | 10,411 |  |
| Gross margin |  |  | 3,809 |  |  | 3,846 |  |  | 3,940 |  |
| Product development |  |  | 1,353 |  |  | 1,226 |  |  | 1,133 |  |
| Marketing and administrative |  |  | 857 |  |  | 722 |  |  | 635 |  |
| Amortization of intangibles |  |  | 129 |  |  | 98 |  |  | 79 |  |
| Restructuring and other, net |  |  | 32 |  |  | 24 |  |  | 2 |  |
| Gain on arbitration award, net |  |  | (620 | ) |  | — |  |  | — |  |
| Income from operations |  |  | 2,058 |  |  | 1,776 |  |  | 2,091 |  |
| Other income (expense), net |  |  | (88 | ) |  | (220 | ) |  | (260 | ) |
| Income before income taxes |  |  | 1,970 |  |  | 1,556 |  |  | 1,831 |  |
| Provision for (benefit from) income taxes |  |  | 228 |  |  | (14 | ) |  | (7 | ) |
| Net income |  | $ | 1,742 |  | $ | 1,570 |  | $ | 1,838 |  |

[0001047469-15-006787:mdna:71]
|  |  | Fiscal Years Ended |  |
|  |  | July 3, 2015 |  | June 27, 2014 |  | June 28, 2013 |  |
| Revenue |  |  | 100 | % |  | 100 | % |  | 100 | % |
| Cost of revenue |  |  | 72 |  |  | 72 |  |  | 73 |  |
| Gross margin |  |  | 28 |  |  | 28 |  |  | 27 |  |
| Product development |  |  | 10 |  |  | 9 |  |  | 8 |  |
| Marketing and administrative |  |  | 7 |  |  | 5 |  |  | 4 |  |
| Amortization of intangibles |  |  | 1 |  |  | 1 |  |  | 1 |  |
| Restructuring and other, net |  |  | — |  |  | — |  |  | — |  |
| Gain on arbitration award, net |  |  | (5 | ) |  | — |  |  | — |  |
| Income from operations |  |  | 15 |  |  | 13 |  |  | 14 |  |
| Other income (expense), net |  |  | (1 | ) |  | (2 | ) |  | (2 | ) |
| Income before income taxes |  |  | 14 |  |  | 11 |  |  | 12 |  |
| Provision for (benefit from) income taxes |  |  | 2 |  |  | — |  |  | — |  |
| Net income |  |  | 12 | % |  | 11 | % |  | 12 | % |

[0001047469-15-006787:mdna:72]
46

[0001047469-15-006787:mdna:73]
The
following table summarizes information regarding average drive selling prices ("ASPs") excluding storage systems; drive volume shipments, exabytes shipped, and revenues by channel
and geography:

[0001047469-15-006787:mdna:74]
|  |  | Fiscal Years Ended |  |
| (In millions, except percentages, exabytes and ASPs) |  | July 3, 2015 |  | June 27, 2014 |  | June 28, 2013 |  |
| Unit Shipments: |  |  |  |  |  |  |  |  |  |  |
| Enterprise |  |  | 36 |  |  | 31 |  |  | 30 |  |
| Client Compute |  |  | 132 |  |  | 144 |  |  | 151 |  |
| Client Non-Compute |  |  | 44 |  |  | 45 |  |  | 45 |  |
| Total Units Shipped |  |  | 212 |  |  | 220 |  |  | 226 |  |
| ASPs (per unit) |  | $ | 61 |  | $ | 61 |  | $ | 63 |  |
| Exabytes Shipped |  |  | 228 |  |  | 202 |  |  | 185 |  |
| Revenues by Channel (%) |  |  |  |  |  |  |  |  |  |  |
| OEMs |  |  | 71 | % |  | 68 | % |  | 68 | % |
| Distributors |  |  | 17 | % |  | 20 | % |  | 21 | % |
| Retailers |  |  | 12 | % |  | 12 | % |  | 11 | % |
| Revenues by Geography (%) |  |  |  |  |  |  |  |  |  |  |
| Americas |  |  | 28 | % |  | 27 | % |  | 27 | % |
| EMEA |  |  | 17 | % |  | 19 | % |  | 19 | % |
| Asia Pacific |  |  | 55 | % |  | 54 | % |  | 54 | % |

[0001047469-15-006787:mdna:75]
Fiscal Year 2015 Compared to Fiscal Year 2014

[0001047469-15-006787:mdna:76]
Revenue

[0001047469-15-006787:mdna:77]
|  |  | Fiscal Years Ended |  |
| (Dollars in millions) |  | July 3, 2015 |  | June 27, 2014 |  | Change |  | % Change |  |
| Revenue |  | $ | 13,739 |  | $ | 13,724 |  | $ | 15 |  |  | 0.1 | % |

[0001047469-15-006787:mdna:78]
Revenue
in fiscal year 2015 remained flat from fiscal year 2014, as a result of revenue contributed from our acquisitions of Xyratex and LSI's Flash Business and a favorable product mix,
partially offset by a 4% decrease in units shipped and moderate price erosion.

[0001047469-15-006787:mdna:79]
Cost of Revenue and Gross Margin

[0001047469-15-006787:mdna:80]
|  |  | Fiscal Years Ended |  |
| (Dollars in millions) |  | July 3, 2015 |  | June 27, 2014 |  | Change |  | % Change |  |
| Cost of revenue |  | $ | 9,930 |  | $ | 9,878 |  | $ | 52 |  |  | 1 | % |
| Gross margin |  | $ | 3,809 |  | $ | 3,846 |  | $ | (37 | ) |  | (1 | )% |
| Gross margin percentage |  |  | 28 | % |  | 28 | % |  |  |  |  |  |  |

[0001047469-15-006787:mdna:81]
For
fiscal year 2015, gross margin as a percentage of revenue remained flat from the prior fiscal year as a result of improved product mix and cost savings due to increased operational
efficiencies, offset by moderate price erosion.

[0001047469-15-006787:mdna:82]
Operating Expenses

[0001047469-15-006787:mdna:83]
|  |  | Fiscal Years Ended |  |
| (Dollars in millions) |  | July 3, 2015 |  | June 27, 2014 |  | Change |  | % Change |  |
| Product development |  | $ | 1,353 |  | $ | 1,226 |  | $ | 127 |  |  | 10 | % |
| Marketing and administrative |  |  | 857 |  |  | 722 |  |  | 135 |  |  | 19 | % |
| Amortization of intangibles |  |  | 129 |  |  | 98 |  |  | 31 |  |  | 32 | % |
| Restructuring and other, net |  |  | 32 |  |  | 24 |  |  | 8 |  |  | 33 | % |
| Gain on arbitration award, net |  |  | (620 | ) |  | — |  |  | (620 | ) |  | (100 | )% |
| Operating expenses |  | $ | 1,751 |  | $ | 2,070 |  | $ | (319 | ) |  |  |  |

[0001047469-15-006787:mdna:84]
Product Development Expense.    Product development expenses for fiscal year 2015 increased from fiscal year 2014 mostly due to an
increase in headcount
related costs of $111 million attributed to the consolidation of Xyratex and LSI's Flash Business as well as a 53-week fiscal year in 2015 compared to 52 weeks in 2014.

[0001047469-15-006787:mdna:85]
Marketing and Administrative Expense.    Marketing and administrative expenses for fiscal year 2015 increased from fiscal year 2014
primarily due to an
increase in headcount related costs of $50 million attributed to the consolidation of Xyratex and LSI's Flash Business, non-recurring legal cost reimbursement received in fiscal year 2014 of
$24 million, as well as a 53-week fiscal year in 2015 compared to 52 weeks in 2014.

[0001047469-15-006787:mdna:86]
Amortization of Intangibles.    Amortization of intangibles for fiscal year 2015 increased by $31 million, as compared to fiscal year
2014, as a
result of the acquisitions of LSI's Flash Business and Xyratex.

[0001047469-15-006787:mdna:87]
Restructuring and Other, net.    Restructuring and other, net for fiscal year 2015 increased by $8 million, as compared to fiscal year
2014
primarily due to a restructuring charge recorded during the March 2015 quarter to reduce work force as a result of our ongoing focus on cost efficiencies in all areas of our business.

[0001047469-15-006787:mdna:88]
Gain on arbitration award, net.    Gain on arbitration award, net for fiscal year 2015 increased from fiscal year 2014 due to final award
received in
the amount of $630 million, less litigation and other related costs of $10 million, in the Company's case against Western Digital for the misappropriation of the Company's trade secrets.

[0001047469-15-006787:mdna:89]
Other income (expense), net

[0001047469-15-006787:mdna:90]
|  |  | Fiscal Years Ended |  |
| (Dollars in millions) |  | July 3, 2015 |  | June 27, 2014 |  | Change |  | % Change |  |
| Other income (expense), net |  | $ | (88 | ) | $ | (220 | ) | $ | 132 |  |  | (60 | )% |

[0001047469-15-006787:mdna:91]
Other
income (expense), net for fiscal year 2015 decreased by $132 million, as compared to fiscal year 2014 primarily due to the partial payment of $143 million for
interest accrued on the final arbitration award amount in our case against Western Digital and a decrease in losses from early redemption and repurchase of debt of $15 million, partially offset
by a $12 million increase in interest expense.

[0001047469-15-006787:mdna:92]
48

[0001047469-15-006787:mdna:93]
Income Taxes

[0001047469-15-006787:mdna:94]
|  |  | Fiscal Years Ended |  |
| (Dollars in millions) |  | July 3, 2015 |  | June 27, 2014 |  | Change |  | % Change |  |
| Provision for (benefit from) income taxes |  | $ | 228 |  | $ | (14 | ) | $ | 242 |  |  | 1,729 | % |

[0001047469-15-006787:mdna:95]
We
recorded an income tax provision of $228 million for fiscal year 2015 compared to an income tax benefit of $14 million for fiscal year 2014. Our fiscal year 2015 income
tax provision included approximately $193 million of net income tax expense due to the final audit assessment received from the Jiangsu Province State Tax Bureau of the People's Republic of
China (China assessment) for calendar years 2007 through 2013. Our fiscal year 2014 benefit from income taxes included $58 million of income tax benefits related to the reversal of a portion of
the valuation allowances recorded in prior periods and a net decrease in tax reserves related to audit settlements offset by tax reserves on non-U.S. tax positions taken in prior fiscal years.

[0001047469-15-006787:mdna:96]
Our
Irish tax resident parent holding company owns various U.S. and non-U.S. subsidiaries that operate in multiple non-Irish income tax jurisdictions. Our worldwide operating income is
either subject to varying rates of income tax or is exempt from income tax due to tax holiday programs we operate under in Malaysia, Singapore and Thailand. These tax holidays are scheduled to expire
in whole or in part at various dates through 2022.

[0001047469-15-006787:mdna:97]
Our
income tax provision recorded for fiscal year 2015 differed from the provision for income taxes that would be derived by applying the Irish statutory rate of 25% to income before
income taxes, primarily due to the net effect of (i) tax benefits related to non-U.S. earnings generated in jurisdictions that are subject to tax holidays or tax incentive programs and are
considered indefinitely reinvested outside of Ireland, (ii) tax expense associated with the China assessment recorded during the December 2014 quarter, and (iii) an increase in valuation
allowance for certain deferred tax assets. The acquisition of LSI's Flash Business did not have a material impact on our effective tax rate. Our income tax benefit recorded for fiscal year 2014
differed from the provision for income taxes that would be derived by applying the Irish statutory rate of 25% to income before income taxes, primarily due to the net effect of (i) tax benefits
related to non-U.S. earnings generated in jurisdictions that are subject to tax holidays or tax incentive programs and are considered indefinitely reinvested outside of Ireland, and (ii) a
decrease in valuation allowance for certain deferred tax assets. The acquisition of Xyratex did not
have a material impact on our effective tax rate in fiscal year 2014. Fiscal year 2014 included a valuation allowance release associated with post-acquisition restructuring.

[0001047469-15-006787:mdna:98]
Based
on our non-U.S. ownership structure and subject to (i) potential future increases in our valuation allowance for deferred tax assets; and (ii) a future change in our
intention to indefinitely reinvest earnings from our subsidiaries outside of Ireland, we anticipate that our effective tax rate in future periods will generally be less than the Irish statutory rate.

[0001047469-15-006787:mdna:99]
At
July 3, 2015, our deferred tax asset valuation allowance was approximately $929 million.

[0001047469-15-006787:mdna:100]
At
July 3, 2015, we had net deferred tax assets of $612 million. The realization of these deferred tax assets is primarily dependent on our ability to generate sufficient
U.S. taxable income in future periods. Although realization is not assured, we believe that it is more likely than not that these deferred tax assets will be realized. The amount of deferred tax
assets considered realizable, however, may increase or decrease in subsequent periods when we re-evaluate the underlying basis for our estimates of future U.S. and certain non-U.S. taxable income.

[0001047469-15-006787:mdna:101]
As
of July 3, 2015, approximately $422 million and $90 million of our total U.S. net operating loss and tax credit carry forwards, respectively, are subject to an
aggregate annual limitation of $46 million pursuant to U.S. tax law.

[0001047469-15-006787:mdna:102]
As
of July 3, 2015 and June 27, 2014, we had approximately $83 million and $115 million, respectively, of unrecognized tax benefits excluding interest and
penalties. The unrecognized tax benefits that, if recognized, would impact the effective tax rate are $83 million and $115 million as of July 3, 2015 and June 27, 2014,
respectively, subject to certain future valuation allowance offsets.

[0001047469-15-006787:mdna:103]
It
is our policy to include interest and penalties related to unrecognized tax benefits in the provision for income taxes on the Consolidated Statements of Operations. During fiscal year
2015, we recognized a net income tax expense for interest and penalties of $26 million, $8 million during fiscal year 2014 and $2 million during fiscal year 2013. As of
July 3, 2015, we had $20 million of accrued interest and penalties related to unrecognized tax benefits compared to $27 million in fiscal year 2014.

[0001047469-15-006787:mdna:104]
During
the fiscal year ended July 3, 2015, our unrecognized tax benefits excluding interest and penalties decreased by approximately $32 million primarily due to
(i) reductions associated with audit settlements of $45 million, (ii) increases in current year unrecognized tax benefits of $9 million, (iii) net increases in prior
years' unrecognized tax benefits of $8 million, (iv) reductions associated with the expiration of certain statutes of limitation of $3 million, (v) net reductions from
other activity, including non-U.S. exchange gains, of $1 million.

[0001047469-15-006787:mdna:105]
During
the 12 months beginning July 4, 2015, we expect that our unrecognized tax benefits could be reduced by approximately $11 million as a result of the expiration
of certain statutes of limitation.

[0001047469-15-006787:mdna:106]
We
are subject to taxation in many jurisdictions globally and are required to file U.S. federal, U.S. state, and non-U.S income tax returns. In June 2014, we received the Revenue
Agent's Report and Notices of Proposed Adjustments for our U.S. federal income tax returns for fiscal years 2008, 2009 and 2010. We are currently contesting certain of these proposed adjustments
through the IRS Appeals Office. We believe that the resolution of these disputed issues will not have a material impact on our financial statements. As discussed above, on December 31, 2014, we
received a final audit assessment from the Jiangsu Province State Tax Bureau of the People's Republic of China. As a result of the assessment, we made payments of $225 million related to tax
and interest associated with changes to our tax filings in China for calendar years 2007 through 2013. In connection with resolving our tax audit with the Chinese tax authorities, we obtained an
Advance Pricing Agreement (APA) from the Jiangsu Province State Tax Bureau during the third quarter. The APA covers the periods through 2018 and provides the company a predictable future tax expense
that provides stability to our business model.

[0001047469-15-006787:mdna:107]
We
are no longer subject to tax examination of U.S. federal income tax returns for years prior to fiscal year 2008. With respect to U.S. state and non-U.S. income tax returns, we are
generally no longer subject to tax examination for years ending prior to fiscal year 2005.

[0001047469-15-006787:mdna:108]
Fiscal Year 2014 Compared to Fiscal Year 2013

[0001047469-15-006787:mdna:109]
Revenue

[0001047469-15-006787:mdna:110]
|  |  | Fiscal Years Ended |  |
| (Dollars in millions) |  | June 27, 2014 |  | June 28, 2013 |  | Change |  | % Change |  |
| Revenue |  | $ | 13,724 |  | $ | 14,351 |  | $ | (627 | ) |  | (4 | )% |

[0001047469-15-006787:mdna:111]
Revenue
in fiscal year 2014 decreased approximately 4%, or $0.6 billion, from fiscal year 2013 as a result of a 3% decrease in units shipped and a $2 decrease in the ASP due to
price erosion, partially offset by a more favorable product mix.

[0001047469-15-006787:mdna:112]
Gross Margin

[0001047469-15-006787:mdna:113]
|  |  | Fiscal Years Ended |  |
| (Dollars in millions) |  | June 27, 2014 |  | June 28, 2013 |  | Change |  | % Change |  |
| Cost of revenue |  | $ | 9,878 |  | $ | 10,411 |  | $ | (533 | ) |  | (5 | )% |
| Gross margin |  | $ | 3,846 |  | $ | 3,940 |  | $ | (94 | ) |  | (2 | )% |
| Gross margin percentage |  |  | 28 | % |  | 27 | % |  |  |  |  |  |  |

[0001047469-15-006787:mdna:114]
For
fiscal year 2014, gross margin as a percentage of revenue increased to 28% from 27% in the prior fiscal year, as a result of improved product mix and cost savings due to increases in
operational efficiencies, offset by modest price erosion.

[0001047469-15-006787:mdna:115]
Operating Expenses

[0001047469-15-006787:mdna:116]
|  |  | Fiscal Years Ended |  |
| (Dollars in millions) |  | June 27, 2014 |  | June 28, 2013 |  | Change |  | % Change |  |
| Product development |  | $ | 1,226 |  | $ | 1,133 |  | $ | 93 |  |  | 8 | % |
| Marketing and administrative |  |  | 722 |  |  | 635 |  |  | 87 |  |  | 14 | % |
| Amortization of intangibles |  |  | 98 |  |  | 79 |  |  | 19 |  |  | 24 | % |
| Restructuring and other, net |  |  | 24 |  |  | 2 |  |  | 22 |  |  | 1,100 | % |
| Operating expenses |  | $ | 2,070 |  | $ | 1,849 |  | $ | 221 |  |  |  |  |

[0001047469-15-006787:mdna:117]
Product Development Expense.    Product development expenses for fiscal year 2014 increased from fiscal year 2013 due to increased
investments in HDD
and alternative storage technologies of approximately $35 million and headcount related costs of approximately $36 million, net of a decrease in variable performance based compensation
expenses of $26 million. In addition, the consolidation of Xyratex, acquired on March 31, 2014 contributed approximately $23 million to Product development expense.

[0001047469-15-006787:mdna:118]
Marketing and Administrative Expense.    Marketing and administrative expenses for fiscal year 2014 increased from fiscal year 2013 due to
a
$40 million increase in headcount related expenses due to annual focal increases and increased investments in certain strategic initiatives as well as enhancement
of core businesses of $25 million. In addition, the consolidation of Xyratex contributed approximately $15 million to Marketing and administrative expense.

[0001047469-15-006787:mdna:119]
Amortization of Intangibles.    Amortization of intangibles for fiscal year 2014 increased from fiscal year 2013 due to the commencement
of amortization
of certain in-process research and development assets acquired from Samsung's HDD business in December of 2011 and LaCie in August of 2012.

[0001047469-15-006787:mdna:120]
Restructuring and Other, net.    Restructuring and other, net for fiscal years 2014 increased from fiscal year 2013 primarily due to a
restructuring
charge recorded during the December 2013 quarter associated with a reduction in work force.

[0001047469-15-006787:mdna:121]
Other Expense, net

[0001047469-15-006787:mdna:122]
|  |  | Fiscal Years Ended |  |
| (Dollars in millions) |  | June 27, 2014 |  | June 28, 2013 |  | Change |  | % Change |  |
| Other income (expense), net |  | $ | (220 | ) | $ | (260 | ) | $ | 40 |  |  | (15 | )% |

[0001047469-15-006787:mdna:123]
Other
income (expense), net for fiscal year 2014 decreased by $40 million from fiscal year 2013 due to a $60 million decrease in losses from the early redemption and
repurchase of debt and a decrease of $18 million in interest expense due to a reduction in the average interest rate on our outstanding debt. These decreases were partially offset by insurance
proceeds of $25 million received during fiscal year 2013 for equipment damaged during the severe flooding in Thailand in October of 2011 and $17 million lower gains on sales of our
available for sale securities and strategic investments.

[0001047469-15-006787:mdna:124]
Income Taxes

[0001047469-15-006787:mdna:125]
|  |  | Fiscal Years Ended |  |
| (Dollars in millions) |  | June 27, 2014 |  | June 28, 2013 |  | Change |  | % Change |  |
| (Benefit From) provision for income taxes |  | $ | (14 | ) | $ | (7 | ) | $ | (7 | ) |  | 100 | % |

[0001047469-15-006787:mdna:126]
We
recorded an income tax benefit of $14 million for fiscal year 2014 compared to an income tax benefit of $7 million for fiscal year 2013. Our fiscal year 2014 benefit
from income taxes included $58 million of income tax benefits related to the reversal of a portion of the valuation allowances recorded in prior periods and a net decrease in tax reserves
related to audit settlements offset by tax reserves on non-U.S. tax positions taken in prior fiscal years. Our fiscal year 2013 benefit for income taxes included $52 million of income tax
benefit from the reversal of a portion of the U.S. valuation allowance recorded in prior periods.

[0001047469-15-006787:mdna:127]
Our
income tax benefit recorded for fiscal year 2014 differed from the provision for income taxes that would be derived by applying the Irish statutory rate of 25% to income before
income taxes, primarily due to the net effect of (i) tax benefits related to non-U.S. earnings generated in jurisdictions that are subject to tax holidays or tax incentive programs and are
considered indefinitely reinvested outside of Ireland and (ii) a decrease in valuation allowance for certain deferred tax assets. The acquisition of Xyratex did not have a material impact on
our effective tax rate. Fiscal year 2014 included a valuation allowance release associated with post-acquisitions restructuring. Our income tax benefit recorded for fiscal year 2013 differed from the
provision for income taxes that would be derived by applying the Irish statutory rate of 25% to income before income taxes, primarily due to the net effect of (i) tax benefits related to
non-U.S. earnings generated in jurisdictions that are subject to tax holidays or tax incentive programs and are considered indefinitely reinvested outside of Ireland, and (ii) a decrease in
valuation allowance for certain U.S. deferred tax assets. The acquisition of a majority interest in the outstanding shares of LaCie did not have a material impact on our effective tax rate in fiscal
year 2013.

[0001047469-15-006787:mdna:128]
Liquidity and Capital Resources

[0001047469-15-006787:mdna:129]
The following sections discuss our principal liquidity requirements, as well as our sources and uses of cash and our liquidity and
capital resources. Our cash and cash equivalents are maintained in investments with remaining maturities of 90 days or less at the time of purchase. Our short-term investments consist primarily
of money market funds, certificates of deposits, and other interest-bearing bank deposits. The principal objectives of our investment policy are the preservation of principal and maintenance of
liquidity. We believe our cash equivalents and short-term investments are liquid and accessible. We operate in some countries that have restrictive regulations over the movement of cash and/or foreign
exchange across their borders. However, these restrictions have not impeded our ability to conduct our business, nor do we expect them to in the next 12 months. We are not aware of any
downgrades, losses or other significant deterioration in the fair value of our cash equivalents or short-term investments and we do not believe the fair value of our short-term investments has
significantly changed from the values reported as of July 3, 2015.

[0001047469-15-006787:mdna:130]
52

[0001047469-15-006787:mdna:131]
Cash and cash equivalents, short-term investments, and restricted cash and investments

[0001047469-15-006787:mdna:132]
|  |  | As of |  |
| (Dollars in millions) |  | July 3, 2015 |  | June 27, 2014 |  | Change |  |
| Cash and cash equivalents |  | $ | 2,479 |  | $ | 2,634 |  | $ | (155 | ) |
| Short-term investments |  |  | 6 |  |  | 20 |  |  | (14 | ) |
| Restricted cash and investments |  |  | 7 |  |  | 4 |  |  | 3 |  |
| Total |  | $ | 2,492 |  | $ | 2,658 |  | $ | (166 | ) |

[0001047469-15-006787:mdna:133]
Our
cash and cash equivalents, short-term investments and restricted cash and investments decreased from June 27, 2014 as a result of net cash outflow for repurchases of our
ordinary shares, early redemption and repayments of long-term debt, dividends paid to our shareholders, capital expenditures, the acquisition of LSI's Flash Business, and a $225 million payment
related to the final audit assessment received from the Jiangsu Province State Tax Bureau of the People's Republic of China. These cash outflows were partially offset by our cash provided by operating
activities, which included an arbitration award partial payment of $773 million from Western Digital, and the aggregate proceeds of $1.2 billion from the aggregated issuance of our 5.75%
Senior Notes due 2034 and 4.875% Senior Notes due 2027, as discussed below. The following table summarizes results from the statement of cash flows for the periods indicated:

[0001047469-15-006787:mdna:134]
|  |  | Fiscal Years Ended |  |
| (Dollars in millions) |  | July 3, 2015 |  | June 27, 2014 |  | June 28, 2013 |  |
| Net cash flow provided by (used in): |  |  |  |  |  |  |  |  |  |  |
| Operating activities |  | $ | 2,647 |  | $ | 2,558 |  | $ | 3,047 |  |
| Investing activities |  |  | (1,287 | ) |  | (322 | ) |  | (825 | ) |
| Financing activities |  |  | (1,495 | ) |  | (1,311 | ) |  | (2,222 | ) |
| Effect of foreign currency exchange rates |  |  | (20 | ) |  | 1 |  |  | 1 |  |
| Net increase (decrease) in cash and cash equivalents |  | $ | (155 | ) | $ | 926 |  | $ | 1 |  |

[0001047469-15-006787:mdna:135]
Cash Provided by Operating Activities

[0001047469-15-006787:mdna:136]
Cash provided by operating activities for fiscal year2015 was approximately $2.6 billion and includes the effects of net income
adjusted for non-cash items including depreciation, amortization, and stock-based compensation. Net income includes:

[0001047469-15-006787:mdna:137]
•

[0001047469-15-006787:mdna:138]
a partial payment of $773 million for the arbitration award and related accrued interest received from Western Digital; and

[0001047469-15-006787:mdna:139]
•

[0001047469-15-006787:mdna:140]
a $225 million payment related to the final audit assessment received from the Jiangsu Province State Tax Bureau of the
People's Republic of China for tax and interest associated with changes to our tax filings for the calendar years 2007 through 2013.

[0001047469-15-006787:mdna:141]
Cash
provided by operating activities for fiscal year 2014 was approximately $2.6 billion and includes the effects of net income adjusted for non-cash items including
depreciation, amortization, stock-based compensation, and:

[0001047469-15-006787:mdna:142]
•

[0001047469-15-006787:mdna:143]
a decrease of $217 million in vendor non-trade receivables primarily related to a change in the contractual relationship with
some of our contract manufacturers which reduced the volume of components we sold to them;

[0001047469-15-006787:mdna:144]
53

[0001047469-15-006787:mdna:145]
•

[0001047469-15-006787:mdna:146]
a decrease of $190 million in accounts payable due to a change in the contractual relationship with some of our contract
manufacturers which resulted in a reduction in direct materials purchased and subsequently sold to our contract manufacturers; and

[0001047469-15-006787:mdna:147]
•

[0001047469-15-006787:mdna:148]
a decrease of $104 million in restricted cash and investments primarily due to the restricted cash and investments held in a
rabbi trust being replaced with a standby letter of credit.

[0001047469-15-006787:mdna:149]
Cash
provided by operating activities for fiscal year 2013 was approximately $3.0 billion and includes the effects of net income adjusted for non-cash items including
depreciation, amortization, stock-based compensation, and:

[0001047469-15-006787:mdna:150]
•

[0001047469-15-006787:mdna:151]
a decrease of $661 million in accounts receivable, net, primarily due to a decrease in revenue in the fourth quarter of fiscal
year 2013 compared to the prior year period;

[0001047469-15-006787:mdna:152]
•

[0001047469-15-006787:mdna:153]
a decrease of $538 million in accounts payable, primarily due to a reduction in direct materials purchases due to a decrease in
build volume in the fourth quarter of fiscal year 2013 compared to the prior year period;

[0001047469-15-006787:mdna:154]
•

[0001047469-15-006787:mdna:155]
a decrease of $272 million in vendor non-trade receivables primarily due to a decrease in build volumes in the fourth quarter
of fiscal year 2013 compared to the prior year period;

[0001047469-15-006787:mdna:156]
•

[0001047469-15-006787:mdna:157]
a decrease of $170 million in accrued expenses, income taxes and warranty, primarily due to decreases in costs related to sales
activities resulting from lower sales volumes; and

[0001047469-15-006787:mdna:158]
•

[0001047469-15-006787:mdna:159]
a decrease of $102 million in inventory, due to lower volumes in the fourth quarter of fiscal year 2013 compared to the prior
year period.

[0001047469-15-006787:mdna:160]
Cash Used in Investing Activities

[0001047469-15-006787:mdna:161]
In fiscal year 2015, we used $1.3 billion for net cash investing activities, which was primarily due to payments for property,
equipment and leasehold improvements of approximately $747 million and the acquisition of LSI's Flash Business, for $450 million.

[0001047469-15-006787:mdna:162]
In
fiscal year 2014, we used $0.3 billion for net cash investing activities, which was primarily due to payments for property, equipment and leasehold improvements of
approximately $559 million and the
acquisition of Xyratex, for $285 million, partially offset by $508 million of proceeds from sales of short-term investments.

[0001047469-15-006787:mdna:163]
In
fiscal year 2013, we used $0.8 billion for net cash investing activities, which was primarily due to payments for property, equipment and leasehold improvements.

[0001047469-15-006787:mdna:164]
Cash Used in Financing Activities

[0001047469-15-006787:mdna:165]
Net cash used in financing activities of $1.5 billion for fiscal year 2015 was primarily attributable to the following
activities:

[0001047469-15-006787:mdna:166]
•

[0001047469-15-006787:mdna:167]
$1.1 billion paid to repurchase 19 million of our ordinary shares;

[0001047469-15-006787:mdna:168]
•

[0001047469-15-006787:mdna:169]
$1.0 billion for the repurchase and redemption of long term debt;

[0001047469-15-006787:mdna:170]
•

[0001047469-15-006787:mdna:171]
$0.7 billion in dividends paid to our shareholders; partially offset by

[0001047469-15-006787:mdna:172]
•

[0001047469-15-006787:mdna:173]
proceeds of $1.2 billion from aggregate cash generated from the issuance of our 5.75% Senior Notes due 2034 and 4.875% Senior
Notes due 2027.

[0001047469-15-006787:mdna:174]
Net
cash used in financing activities of $1.3 billion for fiscal year 2014 was primarily attributable to the following
activities:

[0001047469-15-006787:mdna:175]
•

[0001047469-15-006787:mdna:176]
$1.9 billion paid to repurchase 41 million of our ordinary shares;

[0001047469-15-006787:mdna:177]
54

[0001047469-15-006787:mdna:178]
•

[0001047469-15-006787:mdna:179]
$0.7 billion for the repurchase and redemption of long term debt;

[0001047469-15-006787:mdna:180]
•

[0001047469-15-006787:mdna:181]
$0.6 billion in dividends paid to our shareholders; partially offset by

[0001047469-15-006787:mdna:182]
•

[0001047469-15-006787:mdna:183]
proceeds of $1.8 billion from aggregate cash generated from the issuance of our 3.75% Senior Notes due in 2018 and 4.75% Senior
Notes due in 2025.

[0001047469-15-006787:mdna:184]
Net
cash used in financing activities of $2.2 billion for fiscal year 2013 was attributable to the following activities:

[0001047469-15-006787:mdna:185]
•

[0001047469-15-006787:mdna:186]
$1.7 billion paid to repurchase 54 million of our ordinary shares;

[0001047469-15-006787:mdna:187]
•

[0001047469-15-006787:mdna:188]
$1.2 billion for the repurchase and redemption of long term debt;

[0001047469-15-006787:mdna:189]
•

[0001047469-15-006787:mdna:190]
$0.5 billion in dividends paid to our shareholders; partially offset by

[0001047469-15-006787:mdna:191]
•

[0001047469-15-006787:mdna:192]
proceeds from the issuance of $1 billion of our 4.75% notes due 2023; and

[0001047469-15-006787:mdna:193]
•

[0001047469-15-006787:mdna:194]
proceeds of $0.3 billion from the issuance of ordinary shares under employee stock plans.

[0001047469-15-006787:mdna:195]
Liquidity Sources

[0001047469-15-006787:mdna:196]
Our primary sources of liquidity as of July 3, 2015, consisted of: (1) approximately $2.5 billion in cash and cash
equivalents, and short-term investments, (2) cash we expect to generate from operations and (3) a $700 million senior revolving credit facility.

[0001047469-15-006787:mdna:197]
As
of July 3, 2015, no borrowings have been drawn under the revolving credit facility or had been utilized for letters of credit issued under this credit facility. The line of
credit is available for borrowings, subject to compliance with financial covenants and other customary conditions to borrowing.

[0001047469-15-006787:mdna:198]
The
credit agreement that governs our revolving credit facility, as amended, contains certain covenants that we must satisfy in order to remain in compliance with the credit agreement,
as amended. The agreement includes three financial covenants: (1) minimum cash, cash equivalents and marketable securities; (2) a fixed charge coverage ratio; and (3) a net
leverage ratio. As of July 3, 2015, we were in compliance with all of the covenants under our Revolving Credit Facility and debt agreements.

[0001047469-15-006787:mdna:199]
As
of July 3, 2015, cash and cash equivalents held by non-Irish subsidiaries was $2.5 billion. This amount is potentially subject to taxation in Ireland upon repatriation
by means of a dividend into our Irish
parent. However, it is our intent to indefinitely reinvest earnings of non-Irish subsidiaries outside of Ireland and our current plans do not demonstrate a need to repatriate such earnings by means of
a taxable Irish dividend. Should funds be needed in the Irish parent company and should we be unable to fund parent company activities through means other than a taxable Irish dividend, we would be
required to accrue and pay Irish taxes on such dividend.

[0001047469-15-006787:mdna:200]
We
believe that our sources of cash will be sufficient to fund our operations and meet our cash requirements for at least the next 12 months.

[0001047469-15-006787:mdna:201]
Cash Requirements and Commitments

[0001047469-15-006787:mdna:202]
Our liquidity requirements are primarily to meet our working capital, research and development and capital expenditure needs, to fund
scheduled payments of principal and interest on our indebtedness, and to fund our dividend. Our ability to fund these requirements will depend on our future cash flows, which are determined by future
operating performance, and therefore, subject to prevailing global macroeconomic conditions and financial, business and other factors, some of which are beyond our control.

[0001047469-15-006787:mdna:203]
On
July 21, 2015, our Board of Directors approved a quarterly cash dividend of $0.54 per share, which will be payable on August 25, 2015 to shareholders of record as of the
close of business on August 11, 2015.

[0001047469-15-006787:mdna:204]
55

[0001047469-15-006787:mdna:205]
As
of July 3, 2015, we were in compliance with all of the covenants under our debt agreements. Based on our current outlook, we expect to be in compliance with the covenants of
our debt agreements over the next 12 months.

[0001047469-15-006787:mdna:206]
The
carrying value of our long-term debt as of July 3, 2015 and June 27, 2014 was $4.2 billion and $3.9 billion, respectively. The table below presents the
principal amounts of our outstanding long-term debt:

[0001047469-15-006787:mdna:207]
|  |  | As of |  |
| (Dollars in millions) |  | July 3, 2015 |  | June 27, 2014 |  | Change |  |
| 6.8% Senior Notes due October 2016 |  | $ | — |  | $ | 335 |  | $ | (335 | ) |
| 3.75% Senior Notes due November 2018 |  |  | 800 |  |  | 800 |  |  | — |  |
| 6.875% Senior Notes due May 2020 |  |  | — |  |  | 534 |  |  | (534 | ) |
| 7.00% Senior Notes due November 2021 |  |  | 158 |  |  | 251 |  |  | (93 | ) |
| 4.75% Senior Notes due June 2023 |  |  | 1,000 |  |  | 1,000 |  |  | — |  |
| 4.75% Senior Notes due January 2025 |  |  | 1,000 |  |  | 1,000 |  |  | — |  |
| 4.875% Senior Notes Due 2027 |  |  | 700 |  |  | — |  |  | 700 |  |
| 5.75% Senior Notes Due 2034 |  |  | 500 |  |  | — |  |  | 500 |  |
| Total |  | $ | 4,158 |  | $ | 3,920 |  | $ | 238 |  |

[0001047469-15-006787:mdna:208]
From
time to time we may repurchase any of our outstanding ordinary shares through private, open market, tender offers, broker assisted purchases or other means. During fiscal year 2015,
we repurchased approximately 19 million of our ordinary shares. See "Item 5. Market for Registrant's Common Equity, Related Stockholder Matters and Issuer Purchases of Equity
Securities-Repurchases of Our Equity Securities." As of July 3, 2015, $2.9 billion remained available for repurchase under our existing repurchase authorization limit. All repurchases
are effected as redemptions in accordance with the Company's Articles of Association.

[0001047469-15-006787:mdna:209]
For
fiscal year 2016, we expect capital expenditures to be at or below our long-term targeted range of 6% to 8% of revenue. We require substantial amounts of cash to fund scheduled
payments of principal and interest on our indebtedness, future capital expenditures and any increased working capital requirements. We will continue to evaluate and manage the retirement and
replacement of existing debt and associated obligations, including evaluating the issuance of new debt securities, exchanging existing debt securities for other debt securities and retiring debt
pursuant to privately negotiated transactions, open market purchases, tender offers or other means or otherwise. In addition, we may selectively pursue strategic alliances, acquisitions and
investments, which may require additional capital.

[0001047469-15-006787:mdna:210]
56

[0001047469-15-006787:mdna:211]
Contractual Obligations and Commitments

[0001047469-15-006787:mdna:212]
Our contractual cash obligations and commitments as of July 3, 2015, have been summarized in the table below:

[0001047469-15-006787:mdna:213]
|  |  |  |  | Fiscal Year(s) |  |
| (Dollars in millions) |  | Total |  | 2016 |  | 2017- 2018 |  | 2019- 2020 |  | Thereafter |  |
| Contractual Cash Obligations: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Long-term debt |  | $ | 4,158 |  | $ | — |  | $ | — |  | $ | 800 |  | $ | 3,358 |  |
| Interest payments on debt |  |  | 1,996 |  |  | 201 |  |  | 369 |  |  | 353 |  |  | 1,073 |  |
| Capital expenditures |  |  | 147 |  |  | 134 |  |  | 13 |  |  | — |  |  | — |  |
| Operating leases(1) |  |  | 218 |  |  | 41 |  |  | 53 |  |  | 32 |  |  | 92 |  |
| Purchase obligations(2) |  |  | 1,019 |  |  | 916 |  |  | 103 |  |  | — |  |  | — |  |
| Other funding requirements(3) |  |  | 48 |  |  | 30 |  |  | 12 |  |  | 6 |  |  | — |  |
| Subtotal |  |  | 7,586 |  |  | 1,322 |  |  | 550 |  |  | 1,191 |  |  | 4,523 |  |
| Commitments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Letters of credit or bank guarantees |  |  | 109 |  |  | 109 |  |  | — |  |  | — |  |  | — |  |
| Total |  | $ | 7,695 |  | $ | 1,431 |  | $ | 550 |  | $ | 1,191 |  | $ | 4,523 |  |

[0001047469-15-006787:mdna:214]
(1)

[0001047469-15-006787:mdna:215]
Includes
total future minimum rent expense under non-cancelable leases for both occupied and vacated facilities (rent expense is shown net of sublease
income).

[0001047469-15-006787:mdna:216]
(2)

[0001047469-15-006787:mdna:217]
Purchase
obligations are defined as contractual obligations for the purchase of goods or services, which are enforceable and legally binding on us, and that
specify all significant terms.

[0001047469-15-006787:mdna:218]
(3)

[0001047469-15-006787:mdna:219]
Consists
of funding requirements related to strategic commitments.

[0001047469-15-006787:mdna:220]
As
of July 3, 2015, we had a liability for unrecognized tax benefits and an accrual for the payment of related interest totaling $33 million, none of which is expected to
be settled within one year. Outside of one year, we are unable to make a reasonably reliable estimate of when cash settlement with a taxing authority will occur.

[0001047469-15-006787:mdna:221]
Off-Balance Sheet Arrangements

[0001047469-15-006787:mdna:222]
As of July 3, 2015, we did not have any material off-balance sheet arrangements (as defined in Item 303(a)(4)(ii) of
Regulation S-K).

[0001047469-15-006787:mdna:223]
Critical Accounting Policies

[0001047469-15-006787:mdna:224]
The methods, estimates and judgments we use in applying our most critical accounting policies have a significant impact on the results
we report in our consolidated financial statements. The SEC has defined the most critical accounting policies as the ones that are most important to the portrayal of our financial condition and
operating results, and require us to make our most difficult and subjective judgments, often as a result of the need to make estimates of matters that are highly uncertain at the time of estimation.
Based on this definition, our most critical policies include: establishment of sales program accruals, establishment of warranty accruals, accounting for income taxes, and the accounting for goodwill
and other long-lived assets. Below, we discuss these policies further, as well as the estimates and judgments involved. We also have other accounting policies and accounting estimates relating to
uncollectible customer accounts, valuation of inventory, valuation of share-based payments and restructuring. We believe that these other accounting policies and accounting estimates either do not
generally require us to make estimates and judgments that are as difficult or as subjective, or it is less likely that they would have a material impact on our reported results of operations for a
given period.

[0001047469-15-006787:mdna:225]
Establishment of Sales Program Accruals.    We establish certain distributor and OEM sales programs aimed at increasing customer demand.
For OEM sales,
rebates are typically based on an OEM
customer's volume of purchases or other agreed upon rebate programs. For the distribution channel, these programs typically involve rebates related to a distributor's level of sales, order size,
advertising or point of sale activity and price protection adjustments. We provide for these obligations at the time that revenue is recorded based on estimated requirements. We estimate these
contra-revenue rebates and adjustments based on various factors, including price reductions during the period reported, estimated future price erosion, customer orders, distributor sell-through and
inventory levels, program participation, customer claim submittals and sales returns. Our estimates reflect contractual arrangements but also our judgment relating to variables such as customer claim
rates and attainment of program goals, and inventory and sell-through levels reported by our distribution customers. Currently, our distributors' inventories are within the historical range.

[0001047469-15-006787:mdna:226]
While
we believe we have sufficient experience and knowledge of the market and customer buying patterns to reasonably estimate such rebates and adjustments, actual market conditions or
customer behavior could differ from our expectations. As a result, actual payments under these programs, which may spread over several months after the related sale, may vary from the amount accrued.
Accordingly, revenues and margins in the period in which the adjustment occurs may be affected.

[0001047469-15-006787:mdna:227]
Significant
actual variations in any of the factors upon which we base our contra-revenue estimates could have a material effect on our operating results. In fiscal year 2015, sales
programs were approximately 10% of gross revenue. For fiscal years 2014 and 2013, total sales programs ranged from 7% to 10% of gross revenues. Adjustments to revenues due to under or over accruals
for sales programs related to revenues reported in prior quarterly periods averaged 0.4% of quarterly gross revenue for fiscal year 2013 through 2014, and were approximately 0.2% of gross revenue in
fiscal year 2015. Any future shifts in the industry supply-demand balance as well as other factors may result in a more competitive pricing environment and may cause sales programs as a percentage of
gross revenue to increase from the current or historical levels. If such rebates and incentives trend upwards, revenues and margins will be reduced.

[0001047469-15-006787:mdna:228]
Establishment of Warranty Accruals.    We estimate probable product warranty costs at the time revenue is recognized. We generally warrant
our products
for a period of 1 to 5 years. Our warranty provision considers estimated product failure rates and trends (including the timing of product returns during the warranty periods), and estimated
repair or replacement costs related to product quality issues, if any. We also exercise judgment in estimating our ability to sell certain repaired products. Should actual experience in any future
period differ significantly from our estimates, our future results of operations could be materially affected. Our judgment is subject to a greater degree of subjectivity with respect to newly
introduced products because of limited experience with those products upon which to base our warranty estimates.

[0001047469-15-006787:mdna:229]
The
actual results with regard to warranty expenditures could have an adverse or favorable effect on our results of operations if the actual rate of unit failure, the cost to repair a
unit, or the actual cost required to satisfy customer claims differs from those estimates we used in determining the warranty accrual. Since we typically outsource our warranty repairs, our repair
cost is subject to periodic negotiations with vendors and may vary from our estimates. We also exercise judgment in estimating
our ability to sell certain repaired products. To the extent such sales fall below our forecast, warranty cost will be adversely impacted.

[0001047469-15-006787:mdna:230]
We
review our warranty accrual quarterly for products shipped in prior periods and which are still under warranty. Any changes in the estimates underlying the accrual may result in
adjustments that impact the current period gross margins and income. In fiscal years 2015, 2014 and 2013 net changes in estimates of prior warranty accruals as a percentage of revenue were immaterial.
Our total warranty cost was 1.1%, 1.3% and 1.6% of revenue during fiscal years 2015, 2014 and 2013, respectively, while warranty cost related

[0001047469-15-006787:mdna:231]
to
new shipments (exclusive of the impact of re-estimates of pre-existing liabilities) were 1.1%, 1.3% and 1.3% respectively, for the same periods. Changes in anticipated failure rates of specific
products and significant changes in repair or replacement costs have historically been the major reasons for significant changes in prior estimates. Any future changes in failure rates of certain
products, as well as changes in repair costs or the cost of replacement parts, may result in increased or decreased warranty accruals.

[0001047469-15-006787:mdna:232]
Accounting for Income Taxes.    We account for income taxes pursuant to Accounting Standards Codification (ASC) Topic 740 (ASC 740),
Income Taxes. In
applying, ASC 740, we make certain estimates and judgments in determining income tax expense for financial statement purposes. These estimates and judgments occur in the calculation of tax credits,
recognition of income and deductions and calculation of specific tax assets and liabilities, which arise from differences in the timing of recognition of revenue and expense for tax and financial
statement purposes, as well as tax liabilities associated with uncertain tax positions. The calculation of tax liabilities involves uncertainties in the application of complex tax rules and the
potential for future adjustment of our uncertain tax positions by the Internal Revenue Service or other tax jurisdictions. If estimates of these tax liabilities are greater or less than actual
results, an additional tax benefit or provision will result. The deferred tax assets we record each period depend primarily on our ability to generate future taxable income in the United States and
certain non-U.S. jurisdictions. Each period, we evaluate the need for a valuation allowance for our deferred tax assets and, if necessary, we adjust the valuation allowance so that net deferred tax
assets are recorded only to the extent we conclude it is more likely than not that these deferred tax assets will be realized. If our outlook for future taxable income changes significantly, our
assessment of the need for a valuation allowance may also change.

[0001047469-15-006787:mdna:233]
Assessing Goodwill and Other Long-lived Assets for Impairment.    We account for goodwill in accordance with ASC Topic 350,  Intangibles—Goodwill and Other. As permitted by ASC 350, we
perform a qualitative assessment in the fourth quarter of each year, or more frequently if indicators of potential impairment exist, to determine if any events or circumstances exist, such as an
adverse change in business climate or a decline in the overall industry that would indicate that it would more likely than not reduce the fair value of a reporting unit below its carrying amount.
Based on the qualitative assessment, if it is not more likely than not that the fair value of a reporting unit is less than its carrying amount, then the Company is not required to perform the
two-step goodwill impairment test. If it is determined in the qualitative assessment that the fair value of a reporting unit is more likely than not below its carrying amount, including goodwill, then
we perform a quantitative two-step impairment test. The first step, identifying a potential impairment, compares the fair value of a reporting unit with its carrying amount, including goodwill. If the
carrying value of the reporting unit exceeds its fair value, the second step would need to be conducted. The second step, measuring the impairment loss, compares the implied fair value of the
reporting unit goodwill with the carrying amount of that goodwill. Any excess of the reporting unit goodwill carrying value over its implied fair value is recognized as an impairment loss.

[0001047469-15-006787:mdna:234]
In
accordance with ASC 360-05-4, Impairment or Disposal of Long-lived Assets, we test other long-lived assets, including property,
equipment and leasehold improvements and other intangible assets subject to amortization, for recoverability whenever events or changes in circumstances indicate that the carrying values of those
assets may not be recoverable. We assess the recoverability of an asset group by determining if the carrying value of the asset group exceeds the sum of the projected undiscounted cash flows expected
to result from the use and eventual disposition of the assets over the remaining economic life of the primary asset in the asset group. If the recoverability test indicates that the carrying value of
the asset group is not recoverable, we will estimate the fair value of the asset group and compare it to its carrying value. The excess of the carrying value over the fair value is allocated pro rata
to derive the adjusted carrying value of each asset in the asset group. The adjusted carrying value of each asset in the asset group is not reduced below its fair value.

[0001047469-15-006787:mdna:235]
Recent Accounting Pronouncements

[0001047469-15-006787:mdna:236]
See "Item 8. Financial Statements and Supplementary Data-Note 1. Basis of Presentation and Summary of Significant
Accounting Policies" for information regarding the effect of new accounting pronouncements on our financial statements.
