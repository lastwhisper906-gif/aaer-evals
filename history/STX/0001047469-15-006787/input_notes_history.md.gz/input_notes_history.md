# STX note change history — 0001104659-15-005719 → 0001104659-15-032642


## us-gaap:LegalMattersAndContingenciesTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2015-04-30):
[0001104659-15-032642:note_history:1]
Alexander Shukh v. Seagate Technology—On February 12, 2010, Alexander Shukh filed a complaint against the Company in the U.S. District Court for the District of Minnesota, alleging, among other things, employment discrimination based on his Belarusian national origin and wrongful failure to name him as an inventor on several patents and patent applications. Mr. Shukh's employment was terminated as part of a company-wide reduction in force in fiscal year 2009. He seeks damages in excess of $75 million. On March 31, 2014, the district court granted Seagate’s summary judgment motion and entered judgment in favor of Seagate. Mr. Shukh filed a notice of appeal on April 7, 2014. Oral argument at the court of appeals has been scheduled for June 4, 2015. In view of the uncertainty regarding the amount of damages, if any, that could be awarded in this matter, the Company does not believe that it is currently possible to determine a reasonable estimate of the possible range of loss related to this matter.
  (was, 2015-01-30, similarity 0.7279):
[0001104659-15-005719:note_history:1]
Alexander Shukh v. Seagate Technology—On February 12, 2010, Alexander Shukh filed a complaint against the Company in the U.S. District Court for the District of Minnesota, alleging, among other things, employment discrimination based on his Belarusian national origin and wrongful failure to name him as an inventor on several patents and patent applications. Mr. Shukh's employment was terminated as part of a company-wide reduction in force in fiscal year 2009. He seeks damages in excess of $75 million. On March 31, 2014, the district court granted Seagate’s summary judgment motion and entered judgment in favor of Seagate.  Mr. Shukh filed a notice of appeal on April 7, 2014. The court of appeals has not yet set a date for oral argument. In view of the uncertainty regarding the amount of damages, if any, that could be awarded in this matter, the Company does not believe that it is currently possible to determine a reasonable estimate of the possible range of loss related to this matter.

- added (2015-04-30):
[0001104659-15-032642:note_history:2]
Enova Technology Corporation v. Seagate Technology (US) Holdings, Inc., et al.-On June 5, 2013, Enova Technology Corporation filed a complaint against Seagate Technology (US) Holdings, Inc. and Seagate Technology LLC in the U.S. District Court for the District of Delaware alleging infringement of U.S. Patent No. 7,136,995, “Cryptographic Device,” and U.S. Patent No. 7,900,057, “Cryptographic Serial ATA Apparatus and Method.” The complaint seeks unspecified compensatory damages, enhanced damages, injunctive relief, attorneys' fees, and other relief. The trial is scheduled to begin July 11, 2016. On April 27, 2015, the district court ordered a stay of the case until October 15, 2015, in view of proceedings regarding the ‘995 and ‘057 Patents before the Patent Trial and Appeal Board of the U.S. Patent and Trademark Office. The Company believes the claims are without merit and intends to vigorously defend this case. In view of the uncertainty regarding the amount of damages, if any, that could be awarded in this matter, the Company does not believe that it is currently possible to determine a reasonable estimate of the possible range of loss related to this matter.

- removed (2015-04-30):
[0001104659-15-005719:note_history:3]
Enova Technology Corporation v. Seagate Technology (US) Holdings, Inc., et al.-On June 5, 2013, Enova Technology Corporation filed a complaint against Seagate Technology (US) Holdings, Inc. and Seagate Technology LLC in the U.S. District Court for the District of Delaware alleging infringement of U.S. Patent No. 7,136,995, “Cryptographic Device,” and U.S. Patent No. 7,900,057, “Cryptographic Serial ATA Apparatus and Method.”  The complaint seeks unspecified compensatory damages, enhanced damages, injunctive relief, attorneys' fees, and other relief.  The trial is scheduled to begin July 11, 2016.  The Company believes the claims are without merit and intends to vigorously defend this case.  In view of the uncertainty regarding the amount of damages, if any, that could be awarded in this matter, the Company does not believe that it is currently possible to determine a reasonable estimate of the possible range of loss related to this matter.


## us-gaap:OrganizationConsolidationBasisOfPresentationBusinessDescriptionAndAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2015-04-30):
[0001104659-15-032642:note_history:4]
The results of operations for the three and nine months ended April 3, 2015, are not necessarily indicative of the results of operations to be expected for any subsequent interim period in the Company’s fiscal year ending July 3, 2015. The Company operates and reports financial results on a fiscal year of 52 or 53 weeks ending on the Friday closest to June 30. The three and nine months ended April 3, 2015 consisted of 13 weeks and 40 weeks, respectively. The three and nine months ended March 28, 2014 consisted of 13 weeks and 39 weeks, respectively.  Fiscal year 2015 will be comprised of 53 weeks and will end on July 3, 2015. The fiscal quarters ended April 3, 2015, January 2, 2015, and March 28, 2014, are also referred to herein as the “March 2015 quarter”, the “December 2014 quarter”, and the “March 2014 quarter”, respectively.
  (was, 2015-01-30, similarity 0.8615):
[0001104659-15-005719:note_history:4]
The results of operations for the three and six months ended January 2, 2015, are not necessarily indicative of the results of operations to be expected for any subsequent interim period in the Company’s fiscal year ending July 3, 2015. The Company operates and reports financial results on a fiscal year of 52 or 53 weeks ending on the Friday closest to June 30. The three and six months ended January 2, 2015 consisted of 13 weeks and 27 weeks, respectively. The three and six months ended December 27, 2013 consisted of 13 weeks and 26 weeks, respectively.  Fiscal year 2015 will be comprised of 53 weeks and will end on July 3, 2015. The fiscal quarters ended January 2, 2015, October 3, 2014, and December 27, 2013, are also referred to herein as the “December 2014 quarter”, the “September 2014 quarter”, and the “December 2013 quarter”, respectively.

- changed (2015-04-30):
[0001104659-15-032642:note_history:5]
In May 2014, the FASB issued ASU 2014-09 (ASC Topic 606), Revenue from Contracts with Customers. The ASU outlines a single comprehensive model for entities to use in accounting for revenue arising from contracts with customers and supersedes most current revenue recognition guidance, including industry-specific guidance. It also requires entities to disclose both quantitative and qualitative information that enable financial statements users to understand the nature, amount, timing, and uncertainty of revenue and cash flows arising from contracts with customers. The ASU, as currently proposed, will be effective for the Company's first quarter of fiscal year 2019. The Company is in the process of assessing the impact, if any, of ASU 2014-09 on its consolidated financial statements.
  (was, 2015-01-30, similarity 0.9842):
[0001104659-15-005719:note_history:5]
In May 2014, The FASB issued ASU 2014-09 (ASC Topic 606), Revenue from Contracts with Customers. The ASU outlines a single comprehensive model for entities to use in accounting for revenue arising from contracts with customers and supersedes most current revenue recognition guidance, including industry-specific guidance. It also requires entities to disclose both quantitative and qualitative information that enable financial statements users to understand the nature, amount, timing, and uncertainty of revenue and cash flows arising from contracts with customers. The ASU will be effective for the Company's first quarter of fiscal year 2018. The Company is in the process of assessing the impact, if any, of ASU 2014-09 on its consolidated financial statements.

- added (2015-04-30):
[0001104659-15-032642:note_history:6]
In April 2015, the FASB issued ASU 2015-03 (ASC Subtopic 835-30), Interest-Imputation of Interest: Simplifying the Presentation of Debt Issuance Costs. The amendments in this ASU require that debt issuance costs related to a recognized debt liability be presented in the balance sheet as a direct deduction from the carrying amount of that debt liability. The amendments in this ASU are effective for fiscal years, and interim periods within those years, beginning after December 15, 2015. Early adoption is permitted for financial statements that have not been previously issued. The adoption of this new guidance will not have a material impact on the Company’s consolidated financial statements and disclosures.

- added (2015-04-30):
[0001104659-15-032642:note_history:7]
8


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2015-04-30):
[0001104659-15-032642:note_history:8]
On January 15, 2015, the Company and its subsidiary, Seagate HDD Cayman, entered into the Third Amendment to the 2011 Credit Agreement which increased the commitments available under the senior secured revolving credit facility (the "Revolving Credit Facility") from $500 million to $700 million and also extended the maturity date on the Credit Agreement until January 15, 2020, provided that if the Company does not have Investment Grade Ratings (as defined in the Credit Agreement) on August 15, 2018, then the maturity date will be August 16, 2018 unless certain extension conditions have been satisfied. The loans made under the Credit Agreement will bear interest at a rate of LIBOR plus a variable margin that will be determined based on the corporate credit rating of the Company. The Company and certain of its material subsidiaries fully and unconditionally guarantee the Revolving Credit Facility. The Revolving Credit Facility is available for cash borrowings and for the issuance of letters of credit up to a sub-limit of $75 million. As of April 3, 2015, no borrowings had been drawn or letters of credit utilized under the Revolving Credit Facility.
  (was, 2015-01-30, similarity 0.8391):
[0001104659-15-005719:note_history:8]
As of January 2, 2015, the Company and its subsidiary, Seagate HDD Cayman, had a senior secured revolving credit facility (the "Revolving Credit Facility") of $500 million. On January 15, 2015, the Company and its subsidiary, Seagate HDD Cayman, entered into the Third Amendment to the 2011 Credit Agreement (the "Amendment") which increased the commitments available under the Revolving Credit Facility from $500 million to $700 million and also extended the maturity date on the Credit Agreement until January 15, 2020, provided that if the Company does not have Investment Grade Ratings (as defined in the Credit Agreement) on August 15, 2018, then the maturity date will be August 16, 2018 unless certain extension conditions have been satisfied.  The loans made under the Credit Agreement will bear interest at a rate of LIBOR plus a variable margin that will be determined based on the corporate credit rating of the Company. The Company and certain of its material subsidiaries fully and unconditionally guarantee the Revolving Credit Facility. The Revolving Credit Facility is available for cash borrowings and for the issuance of letters of credit up to a sub-limit of $75 million. As of January 2, 2015, no borrowings had been drawn or letters of credit utilized under the Revolving Credit Facility.

- changed (2015-04-30):
[0001104659-15-032642:note_history:9]
$600 million Aggregate Principal Amount of 6.8% Senior Notes due October 2016 (the “2016 Notes”). The interest on the 2016 Notes was payable semi-annually on April 1 and October 1 of each year. The issuer under the 2016 Notes was Seagate HDD Cayman, and the obligations under the 2016 Notes were unconditionally guaranteed by certain of the Company’s significant subsidiaries. During the December 2014 quarter, the 2016 Notes were fully extinguished through repurchase and redemption for cash at a premium to their principal amount, plus accrued and unpaid interest.
  (was, 2015-01-30, similarity 0.8526):
[0001104659-15-005719:note_history:9]
$600 million Aggregate Principal Amount of 6.8% Senior Notes due October 2016 (the “2016 Notes”). The interest on the 2016 Notes was payable semi-annually on April 1 and October 1 of each year. The issuer under the 2016 Notes was Seagate HDD Cayman, and the obligations under the 2016 Notes were unconditionally guaranteed by certain of the Company’s significant subsidiaries.  During the December 2014 quarter, the 2016 Notes were fully extinguished through repurchase and redemption for cash at a premium to their principal amount, plus accrued and unpaid interest.  The Company recorded a loss on the repurchase and redemption of approximately $34 million, which is included in Other, net in the Company's Condensed Consolidated Statement of Operations.

- changed (2015-04-30):
[0001104659-15-032642:note_history:10]
$600 million Aggregate Principal Amount of 6.875% Senior Notes due May 2020 (the “2020 Notes”). The interest on the 2020 Notes is payable semi-annually on May 1 and November 1 of each year. The issuer under the 2020 Notes is Seagate HDD Cayman, and the obligations under the 2020 Notes are fully and unconditionally guaranteed, on a senior unsecured basis, by the Company. During the March 2015 quarter, the Company repurchased $1 million aggregate principal amount of its 2020 Notes for cash at a premium to their principal amount, plus accrued and unpaid interest. On April 7, 2015, Seagate HDD Cayman announced that it will redeem all of its remaining outstanding 2020 Notes. The Notes will be redeemed on May 7, 2015 (the “Redemption Date”) at a redemption price equal to $1,034.38 per $1,000 principal amount of the 2020 Notes redeemed plus accrued and unpaid interest from the interest payment date of May 1, 2015 to the Redemption Date. As a result, the 2020 Notes are classified as Current portion of long-term debt on the Company's Condensed Consolidated Balance Sheet at April 3, 2015.
  (was, 2015-01-30, similarity 0.6216):
[0001104659-15-005719:note_history:10]
$600 million Aggregate Principal Amount of 6.875% Senior Notes due May 2020 (the “2020 Notes”). The interest on the 2020 Notes is payable semi-annually on May 1 and November 1 of each year. The issuer under the 2020 Notes is Seagate HDD Cayman, and the obligations under the 2020 Notes are fully and unconditionally guaranteed, on a senior unsecured basis, by the Company. During the December 2014 quarter, the Company repurchased $30 million aggregate principal amount of its 2020 Notes for cash at a premium to their principal amount, plus accrued and unpaid interest. The Company recorded a loss on the repurchase of approximately of $2 million, which is included in Other, net in the Company's Condensed Consolidated Statement of Operations.

- changed (2015-04-30):
[0001104659-15-032642:note_history:11]
$600 million Aggregate Principal Amount of 7.00% Senior Notes due November 2021 (the “2021 Notes”). The interest on the 2021 Notes is payable semi-annually on January 1 and July 1 of each year. The issuer under the 2021 Notes is Seagate HDD Cayman, and the obligations under the 2021 Notes are fully and unconditionally guaranteed, on a senior unsecured basis, by the Company.
  (was, 2015-01-30, similarity 0.6623):
[0001104659-15-005719:note_history:11]
$600 million Aggregate Principal Amount of 7.00% Senior Notes due November 2021 (the “2021 Notes”). The interest on the 2021 Notes is payable semi-annually on January 1 and July 1 of each year. The issuer under the 2021 Notes is Seagate HDD Cayman, and the obligations under the 2021 Notes are fully and unconditionally guaranteed, on a senior unsecured basis, by the Company. During the December 2014 quarter, the Company repurchased $14 million aggregate principal amount of its 2021 Notes for cash at a premium to their principal amount, plus accrued and unpaid interest. The Company recorded a loss on the repurchase of approximately $2 million, which is included in Other, net in the Company's Condensed Consolidated Statement of Operations.

- changed (2015-04-30):
[0001104659-15-032642:note_history:12]
$1 billion Aggregate Principal Amount of 4.75% Senior Notes due January 2025 (the “2025 Notes”). The interest on the 2025 Notes is payable semi-annually on January 1 and July 1 of each year, which commenced on January 1, 2015. The issuer under the 2025 Notes is Seagate HDD Cayman, and the obligations under the 2025 Notes are fully and unconditionally guaranteed, on a senior unsecured basis, by the Company.
  (was, 2015-01-30, similarity 0.9674):
[0001104659-15-005719:note_history:12]
$1 billion Aggregate Principal Amount of 4.75% Senior Notes due January 2025 (the “2025 Notes”). The interest on the 2025 Notes is payable semi-annually on January 1 and July 1 of each year, commencing on January 1, 2015. The issuer under the 2025 Notes is Seagate HDD Cayman, and the obligations under the 2025 Notes are fully and unconditionally guaranteed, on a senior unsecured basis, by the Company.

- changed (2015-04-30):
[0001104659-15-032642:note_history:13]
$500 million Aggregate Principal Amount of 5.75% Senior Notes due December 1, 2034 (the “2034 Notes”). On December 2, 2014, Seagate HDD Cayman issued, in a private placement, $500 million in aggregate principal amount of 5.75% Senior Notes due 2034 which mature on December 1, 2034. The interest on the Notes is payable semi-annually on June 1 and December 1 of each year, commencing on June 1, 2015. At any time before June 1, 2034, Seagate HDD Cayman may redeem some or all of the Notes at a “make-whole” redemption price. The ‘‘make-whole’’ redemption price will be equal to (1) 100% of the principal amount of the Notes redeemed, plus (2) the excess, if any of (x) the sum of the present values of the remaining scheduled payments of principal and interest on the Notes being redeemed, discounted to the redemption date on a semi-annual basis at a rate equal to the sum of the Treasury Rate plus 50 basis points, minus accrued and unpaid interest, if any, on the Notes being redeemed to, but excluding, the redemption date over (y) the principal amount of the Notes being redeemed, plus (3) accrued and unpaid interest, if any, on the Notes being redeemed to, but excluding, the redemption date. At any time on or after June 1, 2034, the Company may redeem some or all of the Notes at a redemption price equal to 100% of the principal amount of the Notes redeemed, plus accrued and unpaid interest, if any, to, but excluding, the redemption date. The issuer under the 2034 Notes is Seagate HDD Cayman, and the obligations under the 2034 Notes are fully and unconditionally guaranteed, on a senior unsecured basis, by the Company.
  (was, 2015-01-30, similarity 0.9987):
[0001104659-15-005719:note_history:13]
$500 million Aggregate Principal Amount of 5.75% Senior Notes due December 1, 2034 (the “2034 Notes”). On December 2, 2014, Seagate HDD Cayman issued, in a private placement, $500 million in aggregate principal amount of 5.75% Senior Notes due 2034 which mature on December 1, 2034. The interest on the Notes is payable semi-annually on June 1 and December 1 of each year, commencing on June 1, 2015. At any time before June 1, 2034, Seagate HDD Cayman may redeem some or all of the Notes at a "make-whole" redemption price. The ‘‘make-whole’’ redemption price will be equal to (1) 100% of the principal amount of the Notes redeemed, plus (2) the excess, if any of (x) the sum of the present values of the remaining scheduled payments of principal and interest on the Notes being redeemed, discounted to the redemption date on a semi-annual basis at a rate equal to the sum of the Treasury Rate plus 50 basis points, minus accrued and unpaid interest, if any, on the Notes being redeemed to, but excluding, the redemption date over (y) the principal amount of the Notes being redeemed, plus (3) accrued and unpaid interest, if any, on the Notes being redeemed to, but excluding, the redemption date. At any time on or after June 1, 2034, the Company may redeem some or all of the Notes at a redemption price equal to 100% of the principal amount of the Notes redeemed, plus accrued and unpaid interest, if any, to, but excluding, the redemption date. The issuer under the 2034 Notes is Seagate HDD Cayman, and the obligations under the 2034 Notes are fully and unconditionally guaranteed, on a senior unsecured basis, by the Company.

- changed (2015-04-30):
[0001104659-15-032642:note_history:14]
At April 3, 2015, future principal payments on long-term debt were as follows (in millions):
  (was, 2015-01-30, similarity 0.9545):
[0001104659-15-005719:note_history:14]
At January 2, 2015, future principal payments on long-term debt were as follows (in millions):

- changed (2015-04-30):
[0001104659-15-032642:note_history:15]
| Fiscal Year | Amount |
| Remainder of 2015 | $ | 474 |  |
| 2016 | — |  |
| 2017 | — |  |
| 2018 | — |  |
| 2019 | 800 |  |
| Thereafter | 2,659 |  |
|  | $ | 3,933 |  |
  (was, 2015-01-30, similarity 0.9926):
[0001104659-15-005719:note_history:15]
| Fiscal Year | Amount |
| Remainder of 2015 | $ | — |  |
| 2016 | — |  |
| 2017 | — |  |
| 2018 | — |  |
| 2019 | 800 |  |
| Thereafter | 3,134 |  |
|  | $ | 3,934 |  |


## us-gaap:ScheduleOfCarryingValuesAndEstimatedFairValuesOfDebtInstrumentsTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2015-04-30):
[0001104659-15-032642:note_history:16]
|  |  | April 3, 2015 |  | June 27, 2014 |
| (Dollars in millions) |  | CarryingAmount |  | EstimatedFair Value |  | CarryingAmount |  | EstimatedFair Value |
| 6.8% Senior Notes due October 2016 |  | $ | — |  |  | $ | — |  |  | $ | 335 |  |  | $ | 374 |  |
| 3.75% Senior Notes due November 2018 |  | 800 |  |  | 832 |  |  | 800 |  |  | 820 |  |
| 6.875% Senior Notes due May 2020 |  | 474 |  |  | 492 |  |  | 534 |  |  | 578 |  |
| 7.00% Senior Notes due November 2021 |  | 159 |  |  | 172 |  |  | 251 |  |  | 284 |  |
| 4.75% Senior Notes due June 2023 |  | 1,000 |  |  | 1,052 |  |  | 1,000 |  |  | 1,009 |  |
| 4.75% Senior Notes due January 2025 |  | 1,000 |  |  | 1,040 |  |  | 1,000 |  |  | 995 |  |
| 5.75% Senior Notes due December 2034 |  | 498 |  |  | 542 |  |  | — |  |  | — |  |
| Long-term debt |  | $ | 3,931 |  |  | $ | 4,130 |  |  | $ | 3,920 |  |  | $ | 4,060 |  |
  (was, 2015-01-30, similarity 0.8817):
[0001104659-15-005719:note_history:16]
|  |  | January 2, 2015 |  | June 27, 2014 |
| (Dollars in millions) |  | CarryingAmount |  | EstimatedFair Value |  | CarryingAmount |  | EstimatedFair Value |
| 3.75% Senior Notes due November 2018 |  | $ | 800 |  |  | $ | 824 |  |  | $ | 800 |  |  | $ | 820 |  |
| 6.875% Senior Notes due May 2020 |  | 476 |  |  | 501 |  |  | 534 |  |  | 578 |  |
| 7.00% Senior Notes due November 2021 |  | 158 |  |  | 174 |  |  | 251 |  |  | 284 |  |
| 4.75% Senior Notes due June 2023 |  | 1,000 |  |  | 1,050 |  |  | 1,000 |  |  | 1,009 |  |
| 4.75% Senior Notes due January 2025 |  | 1,000 |  |  | 1,032 |  |  | 1,000 |  |  | 995 |  |
| 5.75% Senior Notes due December 2034 |  | 498 |  |  | 537 |  |  | — |  |  | — |  |
| Long-term debt |  | $ | 3,932 |  |  | $ | 4,118 |  |  | $ | 3,585 |  |  | $ | 3,686 |  |


## us-gaap:ScheduleOfMaturitiesOfLongTermDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2015-04-30):
[0001104659-15-032642:note_history:17]
| Fiscal Year | Amount |
| Remainder of 2015 | $ | 474 |  |
| 2016 | — |  |
| 2017 | — |  |
| 2018 | — |  |
| 2019 | 800 |  |
| Thereafter | 2,659 |  |
|  | $ | 3,933 |  |
  (was, 2015-01-30, similarity 0.9926):
[0001104659-15-005719:note_history:17]
| Fiscal Year | Amount |
| Remainder of 2015 | $ | — |  |
| 2016 | — |  |
| 2017 | — |  |
| 2018 | — |  |
| 2019 | 800 |  |
| Thereafter | 3,134 |  |
|  | $ | 3,934 |  |
