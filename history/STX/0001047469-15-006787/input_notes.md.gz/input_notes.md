# STX notes — 0001047469-15-006787


## us-gaap:RevenueFromExternalCustomersByGeographicAreasTableTextBlock

[0001047469-15-006787:notes:1]
0.1


## invest:InvestmentTableTextBlock

[0001047469-15-006787:notes:2]
| (Dollars in millions) |  | AmortizedCost |  | UnrealizedGain/(Loss) |  | FairValue |
| Available-for-sale securities: |  |  |  |  |  |  |
| Money market funds |  | $ | 1,203 |  |  | $ | — |  |  | $ | 1,203 |  |
| Corporate bonds |  | 6 |  |  | — |  |  | 6 |  |
| Certificates of deposit |  | 867 |  |  | — |  |  | 867 |  |
| Total |  | $ | 2,076 |  |  | $ | — |  |  | $ | 2,076 |  |
| Included in Cash and cash equivalents |  |  |  |  |  |  | $ | 2,063 |  |
| Included in Short-term investments |  |  |  |  |  |  | 6 |  |
| Included in Restricted cash and investments |  |  |  |  |  |  | 7 |  |
| Total |  |  |  |  |  |  | $ | 2,076 |  |

[0001047469-15-006787:notes:3]
| (Dollars in millions) |  | AmortizedCost |  | UnrealizedGain/(Loss) |  | FairValue |
| Available-for-sale securities: |  |  |  |  |  |  |
| Money market funds |  | $ | 793 |  |  | $ | — |  |  | $ | 793 |  |
| Commercial paper |  | 1,261 |  |  | — |  |  | 1,261 |  |
| Corporate bonds |  | 6 |  |  | — |  |  | 6 |  |
| Certificates of deposit |  | 273 |  |  | — |  |  | 273 |  |
| Total |  | $ | 2,333 |  |  | $ | — |  |  | $ | 2,333 |  |
| Included in Cash and cash equivalents |  |  |  |  |  |  | $ | 2,309 |  |
| Included in Short-term investments |  |  |  |  |  |  | 20 |  |
| Included in Restricted cash and investments |  |  |  |  |  |  | 4 |  |
| Total |  |  |  |  |  |  | $ | 2,333 |  |


## stx:ScheduleOfFairValueOfNonvestedSharesAndPerformanceSharesTableTextBlock

[0001047469-15-006787:notes:4]
|  | Fiscal Years |
|  | 2015 |  | 2014 |  | 2013 |
| Nonvested awards: |  |  |  |  |  |
| Weighted-average fair value | $ | 58.93 |  |  | $ | 41.18 |  |  | $ | 30.26 |  |
| Performance awards: |  |  |  |  |  |
| Weighted-average fair value | $ | 59.51 |  |  | $ | 48.69 |  |  | $ | 30.01 |  |


## stx:ScheduleOfShareBasedPaymentAwardStockOptionAndEmployeeStockPurchasePlanValuationAssumptionsAndFairValueDisclosuresTableTextBlock

[0001047469-15-006787:notes:5]
|  | Fiscal Years |
|  | 2015 |  | 2014 |  | 2013 |
| Options |  |  |  |  |  |
| Expected term (in years) | 4.2 |  |  | 4.2 |  |  | 4.2 |  |
| Volatility | 33 - 35% |  |  | 35 - 41% |  |  | 41 - 53% |  |
| Weighted-average volatility | 34 | % |  | 40 | % |  | 52 | % |
| Expected dividend rate | 2.9% - 4.0% |  |  | 3.1% - 3.8% |  |  | 3.6- 5.8% |  |
| Weighted-average expected dividend rate | 3.0 | % |  | 3.7 | % |  | 4.4 | % |
| Risk-free interest rate | 1.1 - 1.5% |  |  | 1.2 - 1.4% |  |  | 0.5 - 1.1% |  |
| Weighted-average fair value | $ | 12.98 |  |  | $ | 10.41 |  |  | $ | 8.96 |  |
| ESPP |  |  |  |  |  |  |  |  |
| Expected term (in years) | 0.5 |  |  | 0.5 |  |  | 0.5 |  |
| Volatility | 28 - 29% |  |  | 34 - 36% |  |  | 38 - 46% |  |
| Weighted-average volatility | 28 | % |  | 35 | % |  | 42 | % |
| Expected dividend rate | 3.0 - 3.8% |  |  | 3.3 - 3.5% |  |  | 2.2 - 4.2% |  |
| Weighted-average expected dividend rate | 3.4 | % |  | 3.4 | % |  | 3.2 | % |
| Risk-free interest rate | 0.1 | % |  | 0.1 | % |  | 0.1% |  |
| Weighted-average fair value | $ | 12.21 |  |  | $ | 10.46 |  |  | $ | 7.74 |  |
| Performance restricted share awards subject to market condition |  |  |  |  |  |  |  |  |
| Expected term (in years) | 3.00 |  |  | 3.00 |  |  | 2.98 |  |
| Weighted-average volatility | 40 | % |  | 46 | % |  | 48 | % |
| Expected dividend rate | 2.8 | % |  | 3.8 | % |  | 4.3 | % |
| Risk-free interest rate | 1.1 | % |  | 0.9 | % |  | 0.3 | % |
| Weighted-average fair value | $ | 58.31 |  |  | $ | 37.51 |  |  | $ | 26.41 |  |


## us-gaap:AcceleratedShareRepurchasesTextBlock

[0001047469-15-006787:notes:6]
| (In millions) | Number ofSharesRepurchased |  | Dollar Valueof SharesRepurchased |
| Cumulative repurchased through June 29, 2012 | 190 |  |  | $ | 3,832 |  |
| Repurchased in fiscal year 2013 | 54 |  |  | 1,654 |  |
| Cumulative repurchased through June 28, 2013 | 244 |  |  | 5,486 |  |
| Repurchased in fiscal year 2014 | 41 |  |  | 1,912 |  |
| Cumulative repurchased through June 27, 2014 | 285 |  |  | 7,398 |  |
| Repurchased in fiscal year 2015 | 19 |  |  | 1,087 |  |
| Cumulative repurchased through July 3, 2015 | 304 |  |  | $ | 8,485 |  |


## us-gaap:AdvertisingCostsPolicyTextBlock

[0001047469-15-006787:notes:7]
Advertising Expense.    The cost of advertising is expensed as incurred. Advertising costs were approximately $64 million, $52 million and $51 million in fiscal years 2015, 2014 and 2013, respectively.


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001047469-15-006787:notes:8]
Acquisitions

[0001047469-15-006787:notes:9]
LSI's Flash Business

[0001047469-15-006787:notes:10]
On September 2, 2014, the Company completed the acquisition of certain assets and liabilities of LSI Corporation's ("LSI") Accelerated Solutions Division and Flash Components Division (collectively, the "Flash Business") from Avago Technologies Limited for $450 million in cash. The transaction is intended to strengthen Seagate's strategy to deliver a full suite of storage solutions, providing Seagate with established enterprise PCIe flash and SSD controller capabilities to deliver solutions for the growing flash storage market.

[0001047469-15-006787:notes:11]
The following table summarizes the estimated fair values of the assets acquired and liabilities assumed at the acquisition date:

[0001047469-15-006787:notes:12]
| (Dollars in millions) |  | Amount |
| Inventories |  | $ | 37 |  |
| Property, plant and equipment |  | 22 |  |
| Intangible assets |  | 141 |  |
| Other assets |  | 6 |  |
| Goodwill |  | 337 |  |
| Total assets |  | 543 |  |
| Liabilities |  | (93 | ) |
| Total liabilities |  | (93 | ) |
| Total |  | $ | 450 |  |

[0001047469-15-006787:notes:13]
The following table shows the fair value of the separately identifiable intangible assets at the time of acquisition and the weighted-average period over which intangible assets within each category will be amortized:

[0001047469-15-006787:notes:14]
| (Dollars in millions) |  | Fair Value |  | Weighted-AverageAmortizationPeriod |
| Existing technology |  | $ | 84 |  |  | 3.5 years |
| Customer relationships |  | 40 |  |  | 3.8 years |
| Trade names |  | 17 |  |  | 4.5 years |
| Total acquired identifiable intangible assets |  | $ | 141 |  |  |  |

[0001047469-15-006787:notes:15]
The goodwill recognized is primarily attributable to the benefits the Company expects to derive from enhanced market opportunities, and is not deductible for income tax purposes.

[0001047469-15-006787:notes:16]
The Company incurred approximately $1 million of expenses related to the acquisition of LSI's Flash Business during the twelve months ended July 3, 2015, which are included within Marketing and administrative expense on the Consolidated Statement of Operations.

[0001047469-15-006787:notes:17]
The amounts of revenue and earnings of LSI's Flash Business included in the Company's Consolidated Statement of Operations from the acquisition date through the end of fiscal year ended July 3, 2015 were not significant.

[0001047469-15-006787:notes:18]
Xyratex Ltd

[0001047469-15-006787:notes:19]
On March 31, 2014, the Company acquired all of the outstanding shares of Xyratex Ltd (“Xyratex”), a leading provider of data storage technology.  The Company paid $13.25 per share, or approximately $376 million in cash for the acquisition.  The acquisition of Xyratex further strengthens the Company’s vertically integrated supply and manufacturing chain for disk drives and provides access to important capital requirements, as well as expands the Company’s storage solutions portfolio.

[0001047469-15-006787:notes:20]
| (Dollars in millions) |  | Amount |
| Cash and cash equivalents |  | $ | 91 |  |
| Accounts receivable, net |  | 67 |  |
| Inventories |  | 111 |  |
| Other current and non-current assets |  | 28 |  |
| Property, plant and equipment |  | 55 |  |
| Intangible assets |  | 80 |  |
| Goodwill |  | 60 |  |
| Total assets |  | 492 |  |
| Accounts payable and accrued expenses |  | (116 | ) |
| Total liabilities |  | (116 | ) |
| Total |  | $ | 376 |  |

[0001047469-15-006787:notes:21]
The following table shows the fair value of the separately identifiable intangible assets at the time of acquisition and the period over which each intangible asset will be amortized:

[0001047469-15-006787:notes:22]
| (Dollars in millions) |  | Fair Value |  | Weighted-AverageAmortizationPeriod |
| Existing technology |  | $ | 23 |  |  | 5.5 years |
| Customer relationships |  | 18 |  |  | 3.9 years |
| Total amortizable intangible assets acquired |  | 41 |  |  | 4.8 years |
| In-process research and development |  | 39 |  |  |  |
| Total acquired identifiable intangible assets |  | $ | 80 |  |  |  |

[0001047469-15-006787:notes:23]
The goodwill recognized is primarily attributable to the synergies expected to arise after the acquisition, and is not deductible for income tax purposes.

[0001047469-15-006787:notes:24]
The Company incurred a total of $10 million of expenses related to the acquisition of Xyratex in fiscal year 2014, which are included within Marketing and administrative expense on the Consolidated Statement of Operations.

[0001047469-15-006787:notes:25]
The amounts of revenue and earnings of Xyratex included in the Company's Consolidated Statement of Operations from the acquisition date through the end of fiscal year ended June 27, 2014 are not significant.

[0001047469-15-006787:notes:26]
LaCie S.A.

[0001047469-15-006787:notes:27]
On August 3, 2012 the Company acquired 23,382,904 (or approximately 64.5%) of the outstanding shares of LaCie S.A. (“LaCie”) for a price of €4.05 per share with a price supplement of €0.12 per share, which would have been payable if the Company had successfully acquired at least 95% of the outstanding shares of LaCie within 6 months of the acquisition.  Of the amount paid at the acquisition date, €9 million is treated as compensation cost to one of the selling shareholders, who was an employee of the Company, to be recognized over a period of 36 months from the acquisition date, and may be refunded to the Company if the selling shareholder is no longer employed at the end of that period.  The transaction and related agreements are expected to accelerate the Company's growth strategy in the expanding consumer storage market, particularly in Europe, Japan and in premium distribution channels.

[0001047469-15-006787:notes:28]
The acquisition-date fair value of the consideration transferred for the business combination totaled $111 million, including cash paid of $107 million, and contingent consideration of $4 million.

[0001047469-15-006787:notes:29]
The following table summarizes the estimated fair values of the assets acquired, liabilities assumed, and noncontrolling interest at the acquisition date:

[0001047469-15-006787:notes:30]
| (Dollars in millions) |  | Amount |
| Cash and cash equivalents |  | $ | 71 |  |
| Accounts receivable |  | 29 |  |
| Marketable securities |  | 27 |  |
| Inventories |  | 46 |  |
| Other current and non-current assets |  | 19 |  |
| Property, plant and equipment |  | 12 |  |
| Intangible assets |  | 45 |  |
| Goodwill |  | 13 |  |
| Total assets |  | 262 |  |
| Accounts payable and accrued expenses |  | (73 | ) |
| Current and non-current portion of long-term debt |  | (6 | ) |
| Total liabilities |  | (79 | ) |
| Noncontrolling interest |  | (72 | ) |
| Total |  | $ | 111 |  |

[0001047469-15-006787:notes:31]
| (Dollars in millions) |  | Fair Value |  | Weighted-AverageAmortizationPeriod |
| Customer relationships |  | $ | 31 |  |  | 5.0 years |
| Existing technology |  | 1 |  |  | 5.0 years |
| Trade name |  | 13 |  |  | 5.0 years |
| Total acquired identifiable intangible assets |  | $ | 45 |  |  |  |

[0001047469-15-006787:notes:32]
In fiscal 2013, the Company recorded adjustments to the fair value of certain assets acquired and liabilities assumed with LaCie S.A. that resulted in a net increase of $1 million to Goodwill, and a corresponding decrease in Intangible assets.

[0001047469-15-006787:notes:33]
The goodwill recognized is attributable primarily to the benefits the Company expects to derive from LaCie's brand recognition and the acquired workforce, and is not deductible for income tax purposes.  The acquisition date fair value of the noncontrolling interest is based on the market price of their publicly traded shares as of the first trading date subsequent to the acquisition, as the shares did not trade on the acquisition date.

[0001047469-15-006787:notes:34]
The €0.12 supplement was not paid as only 94.5% of the LaCie business was acquired within six months of the acquisition date, resulting in a reversal of the contingent consideration liability which was recorded in fiscal year 2013 as a reduction of Marketing and administrative expenses of $4 million.

[0001047469-15-006787:notes:35]
The amounts of revenue and earnings of LaCie included in the Company's Consolidated Statement of Operations from the acquisition date through the end of fiscal year ended June 28, 2013 are not significant.

[0001047469-15-006787:notes:36]
The Company deposited $72 million into an escrow account in fiscal year 2013 with the intention of acquiring the remaining publicly held shares of LaCie through public and private transactions.  As of December 27, 2013, the Company had completed the acquisition of all outstanding shares.  The use of this deposit in fiscal year 2013 is treated as a non-cash financing activity and excluded from the Statement of Cash Flows.


## us-gaap:CashAndCashEquivalentsPolicyTextBlock

[0001047469-15-006787:notes:37]
Summary of Significant Accounting Policies

[0001047469-15-006787:notes:38]
Cash, Cash Equivalents and Short-Term Investments.   The Company considers all highly liquid investments with a remaining maturity of 90 days or less at the time of purchase to be cash equivalents. Cash equivalents are carried at cost, which approximates fair value. The Company's short-term investments are primarily comprised of money market funds, certificates of deposits, and other interest-bearing bank deposits. The Company has classified its marketable securities as available-for-sale and they are stated at fair value with unrealized gains and losses included in Accumulated other comprehensive income (loss), which is a component of Shareholders' Equity. The Company evaluates the available-for sale securities in an unrealized loss position for other-than-temporary impairment. Realized gains and losses are included in Other, net. The cost of securities sold is based on the specific identification method.


## us-gaap:CommitmentsDisclosureTextBlock

[0001047469-15-006787:notes:39]
Commitments

[0001047469-15-006787:notes:40]
Leases. The Company leases certain property, facilities and equipment under non-cancelable lease agreements. Land and facility leases expire at various dates through 2082 and contain various provisions for rental adjustments including, in certain cases, a provision based on increases in the Consumer Price Index. Also, certain leases provide for renewal of the lease at the Company's option at expiration of the lease. All of the leases require the Company to pay property taxes, insurance and normal maintenance costs.

[0001047469-15-006787:notes:41]
Future minimum lease payments for operating leases (including accrued lease payments relating to restructuring plans) with initial or remaining terms of one year or more were as follows at July 3, 2015 (lease payments are shown net of sublease income):

[0001047469-15-006787:notes:42]
| Fiscal Years Ending |  | Operating Leases |
|  |  | (Dollars in millions) |
| 2016 |  | $ | 41 |  |
| 2017 |  | 29 |  |
| 2018 |  | 24 |  |
| 2019 |  | 19 |  |
| 2020 |  | 13 |  |
| Thereafter |  | 92 |  |
|  |  | $ | 218 |  |

[0001047469-15-006787:notes:43]
Total rent expense for all land, facility and equipment operating leases, net of sublease income, was $50 million, $39 million and $35 million for fiscal years  2015,  2014 and  2013, respectively. Total sublease rental income for fiscal years  2015,  2014 and  2013 was $3 million, $2 million and $4 million, respectively. The Company subleases a portion of its facilities that it considers to be in excess of current requirements. As of July 3, 2015, total future lease income to be recognized for the Company's existing subleases is approximately $15 million.

[0001047469-15-006787:notes:44]
The Company recorded amounts for both adverse and favorable leasehold interests and for exit costs that apply directly to the lease commitments assumed through the 2006 acquisition of Maxtor. As of July 3, 2015, the Company had a $2 million adverse leasehold interest related to leases acquired from Maxtor. The adverse leasehold interest is being amortized to Cost of revenue and Operating expenses over the remaining duration of the leases. In addition, the Company had $2 million and $5 million remaining in accrued exit costs related to the planned exit of Maxtor leased excess facilities at July 3, 2015 and June 27, 2014, respectively.

[0001047469-15-006787:notes:45]
Capital Expenditures.    The Company's non-cancelable commitments for construction of manufacturing and product development facilities and purchases of equipment approximated $147 million at July 3, 2015.


## us-gaap:CompensationRelatedCostsPolicyTextBlock

[0001047469-15-006787:notes:46]
Stock-Based Compensation.    The Company accounts for stock-based compensation under the provisions of ASC Topic 718 (ASC 718), Compensation-Stock Compensation. The Company has elected to apply the with-and-without method to assess the realization of related excess tax benefits.


## us-gaap:ComprehensiveIncomePolicyPolicyTextBlock

[0001047469-15-006787:notes:47]
Comprehensive Income.    The Company presents comprehensive income in a separate statement. Comprehensive income is comprised of net income and other gains and losses affecting equity that are excluded from net income.


## us-gaap:ConsolidationPolicyTextBlock

[0001047469-15-006787:notes:48]
Basis of Presentation and Consolidation

[0001047469-15-006787:notes:49]
The consolidated financial statements include the accounts of the Company and all its wholly-owned and majority-owned subsidiaries, after elimination of intercompany transactions and balances.

[0001047469-15-006787:notes:50]
The preparation of financial statements in accordance with U.S. generally accepted accounting principles also requires management to make estimates and assumptions that affect the amounts reported in the Company’s consolidated financial statements and accompanying notes. Actual results could differ materially from those estimates. The methods, estimates and judgments the Company uses in applying its most critical accounting policies have a significant impact on the results the Company reports in its consolidated financial statements.

[0001047469-15-006787:notes:51]
The Company operates and reports financial results on a fiscal year of 52 or 53 weeks ending on the Friday closest to June 30. Accordingly, fiscal year 2015 comprised 53 weeks and ended on July 3, 2015.  Fiscal years 2014 and 2013 were comprised of 52 weeks and ended on June 27, 2014, and June 28, 2013, respectively.  All references to years in these Notes to Consolidated Financial Statements represent fiscal years unless otherwise noted. Fiscal year 2016 will be 52 weeks and will end on July 1, 2016.


## us-gaap:CostsAssociatedWithExitOrDisposalActivitiesOrRestructuringsPolicyTextBlock

[0001047469-15-006787:notes:52]
Restructuring Costs.     The Company records restructuring activities including costs for one-time termination benefits in accordance with ASC Topic 420 (ASC 420), Exit or Disposal Cost Obligations. The timing of recognition for severance costs accounted for under ASC 420 depends on whether employees are required to render service until they are terminated in order to receive the termination benefits.  If employees are required to render service until they are terminated in order to receive the termination benefits, a liability is recognized ratably over the future service period. Otherwise, a liability is recognized when management has committed to a restructuring plan and has communicated those actions to employees.  Employee termination benefits covered by existing benefit arrangements are recorded in accordance with ASC Topic 712, Non-retirement Postemployment Benefits. These costs are recognized when management has committed to a restructuring plan and the severance costs are probable and estimable.


## us-gaap:DebtDisclosureTextBlock

[0001047469-15-006787:notes:53]
Debt

[0001047469-15-006787:notes:54]
Short-Term Borrowings

[0001047469-15-006787:notes:55]
The Company and its subsidiary HDD Cayman have entered into a Credit Agreement providing the Company with a $700 million senior secured revolving credit facility (the "Revolving Credit Facility"). On January 15, 2015, pursuant to the Third Amendment to the Credit Agreement, the commitments available under the Revolving Credit Facility were increased from $500 million to $700 million and the maturity date was extended until January 15, 2020, provided that if the Company does not have Investment Grade Ratings (as defined in the Credit Agreement) on August 15, 2018, then the maturity date will be August 16, 2018 unless certain extension conditions have been satisfied. This Credit Agreement that was originally entered into by the Company and HDD Cayman on January 18, 2011 was subsequently amended with the Second Amendment to the Credit Agreement on April 30, 2013, which increased the commitments available under the Revolving Credit Facility from $350 million to $500 million. The loans made under the Credit Agreement will bear interest at a rate of LIBOR plus a variable margin that will be determined based on the corporate credit rating of the Company. The Company and certain of its material subsidiaries fully and unconditionally guarantee the Revolving Credit Facility. The Revolving Credit Facility is available for cash borrowings and for the issuance of letters of credit up to a sub-limit of $75 million.  As of July 3, 2015, no borrowings had been drawn or letters of credit utilized under the Revolving Credit Facility.

[0001047469-15-006787:notes:56]
Long-Term Debt

[0001047469-15-006787:notes:57]
$600 million Aggregate Principal Amount of 6.8% Senior Notes due October 2016 (the “2016 Notes”).   On September 20, 2006, the Company's subsidiary, Seagate Technology HDD Holdings, completed the sale of $600 million aggregate principal amount of the 2016 Notes, in a private placement exempt from the registration requirements of the Securities Act of 1933, as amended. The interest on the 2016 Notes is payable semi-annually on April 1 and October 1 of each year. The issuer under the 2016 Notes is Seagate HDD Cayman, and the obligations under the 2016 Notes are unconditionally guaranteed by certain of the Company’s significant subsidiaries. The 2016 Notes are redeemable at the option of the Company in whole or in part, on not less than 30, nor more than 60 days notice, at a "make-whole" premium redemption price. The "make-whole" redemption price will be equal to the greater of (1) 100% of the principal amount of the notes being redeemed, or (2) the sum of the present values of the remaining scheduled payments of principal and interest on the 2016 Notes being redeemed, discounted at the redemption date on a semi-annual basis at a rate equal to the sum of the applicable Treasury rate plus 50 basis points. During fiscal year 2013, the Company repurchased $265 million aggregate principal amount of its 2016 Notes for cash at a premium to their principal amount, plus accrued and unpaid interest, and recorded a loss on the repurchase of approximately $44 million, which is included in Other, net in the Company's Consolidated Statements of Operations. During the December 2014 quarter, the 2016 Notes were fully extinguished through repurchase and redemption for cash at a premium to their principal amount, plus accrued and unpaid interest.  The Company recorded a loss on the repurchase and redemption of approximately $34 million, which is included in Other, net in the Company’s Consolidated Statement of Operations.

[0001047469-15-006787:notes:58]
$800 million Aggregate Principal Amount of 3.75% Senior Notes due November 2018 (the “2018 Notes”).  On November 5, 2013, Seagate HDD Cayman, issued $800 million in aggregate principal amount of 3.75% Senior Notes, which mature on November 15, 2018, in a private placement. The interest on the Notes is payable semi-annually on May 15 and November 15 of each year. The Notes are redeemable at the option of Seagate HDD Cayman in whole or in part, on not less than 30, nor more than 60 days' notice, at a “make-whole” premium redemption price. The “make-whole” premium redemption price will be equal to the greater of (1) 100% of the principal amount of the notes being redeemed, or (2) the sum of the present values of the remaining schedule payments of principal and interest on the Notes being redeemed, discounted at the redemption date on a semi-annual basis at a rate equal to the sum of the applicable Treasury rate plus 50 basis points. Accrued and unpaid interest, if any will be paid to, but excluding, the redemption date. The Notes are fully and unconditionally guaranteed by the Company on a senior unsecured basis.

[0001047469-15-006787:notes:59]
$600 million Aggregate Principal Amount of 6.875% Senior Notes due May 2020 (the “2020 Notes”). On May 13, 2010, the Company's subsidiary, Seagate HDD Cayman, completed the sale of $600 million aggregate principal amount of the 2020 Notes, in a private placement exempt from the registration requirements of the Securities Act of 1933, as amended. The obligations under the 2020 Notes are fully and unconditionally guaranteed, on a senior unsecured basis, by the Company.  The interest on the 2020 Notes is payable semi-annually on May 1 and November 1 of each year. The 2020 Notes were redeemable any time prior to May 1, 2015 at the option of the Company, in whole or in part, at a redemption price of 100% of the principal amount plus an “applicable premium” and accrued and unpaid interest, if any, to the redemption date. The "applicable premium" was equal to the greater of (1) 1% of the principal amount of the 2020 Notes, or (2) the excess, if any, of (a) the present value of the redemption price on May 1, 2015 plus interest payments due through May 1, 2015, discounted at the applicable Treasury rate as of the redemption date plus 50 basis points; over (b) the principal amount of such note. The 2020 Notes are redeemable at any time on or after May 1, 2015 at various prices expressed as a percentage of principal amount, as set forth in the indentures, plus accrued and unpaid interest, if any, to the redemption date. The issuer under the 2020 Notes is Seagate HDD Cayman, and the obligations under the 2020 Notes are fully and unconditionally guaranteed, on a senior unsecured basis, by the Company. During fiscal year 2014, the Company repurchased $66 million aggregate principal amount of its 2020 Notes for cash at a premium to their principal amount, plus accrued and unpaid interest. The Company recorded a loss on the repurchase of approximately $7 million, which is included in Other, net in the Company's Consolidated Statement of Operations. During fiscal year 2015, the 2020 Notes were fully extinguished through repurchase and redemption for cash at a premium to their principal amount, plus accrued and unpaid interest.  The Company recorded a loss on the repurchase of approximately $26 million, which is included in Other, net in the Company's Consolidated Statement of Operations.

[0001047469-15-006787:notes:60]
$600 million Aggregate Principal Amount of 7.00% Senior Notes due November 2021 (the “2021 Notes”).  On May 18, 2011, the Company's subsidiary, Seagate HDD Cayman, completed the sale of $600 million aggregate principal amount of the 2021 Notes, in a private placement exempt from the registration requirements of the Securities Act of 1933, as amended. The obligations under the 2021 Notes are fully and unconditionally guaranteed, on a senior unsecured basis, by the Company.  The interest on the 2021 Notes is payable semi-annually on January 1 and July 1 of each year.  The 2021 Notes are redeemable any time prior to May 1, 2016 at the option of the Company, in whole or in part, at a redemption price of 100% of the principal amount plus an “applicable premium” and accrued and unpaid interest, if any, to the redemption date. The "applicable premium" will be equal to the greater of (1) 1% of the principal amount of the 2021 Notes, or (2) the excess, if any, of (a) the present value of the redemption price on May 1, 2016 plus interest payments due through May 1, 2016, discounted at the applicable Treasury rate as of the redemption date plus 50 basis points; over (b) the principal amount of such note. The 2021 Notes are redeemable at any time on or after May 1, 2016 at various prices expressed as a percentage of principal amount, as set forth in the indentures, plus accrued and unpaid interest, if any, to the redemption date. In addition, any time before May 1, 2014, the Company may redeem up to 35% of the principal amount with the net cash proceeds from permitted sales of the Company's stock at a redemption price of 107% of the principal amount plus accrued interest to the redemption date.  The issuer under the 2021 Notes is Seagate HDD Cayman and the obligations under the 2021 Notes are fully and unconditionally guaranteed, on a senior unsecured basis, by the Company. During fiscal year 2014, the Company repurchased $349 million aggregate principal amount of its 2021 Notes for cash at a premium to their principal amount, plus accrued and unpaid interest. The Company recorded a loss on the repurchase of approximately $54 million, which is included in Other, net in the Company's Consolidated Statement of Operations. During fiscal year 2015, the Company repurchased $93 million aggregate principal amount of its 2021 Notes for cash at a premium to their principal amount, plus accrued and unpaid interest. The Company recorded a loss on the repurchase of approximately $13 million, which is included in Other, net in the Company's Consolidated Statement of Operations.

[0001047469-15-006787:notes:61]
$1 billion Aggregate Principal Amount of 4.75% Senior Notes due June 2023 (the “2023 Notes”). On May 22, 2013, Seagate HDD Cayman, issued $1 billion in aggregate principal amount of 4.75% Senior Notes, which mature on June 1, 2023, in a private placement. The obligations under the 2023 Notes are fully and unconditionally guaranteed, on a senior unsecured basis, by the Company. The interest on the 2023 Notes is payable semi-annually on June 1 and December 1 of each year.  The 2023 Notes are redeemable at the option of the Company in whole or in part, on not less than 30, nor more than 60 days notice, at a "make-whole" premium redemption price.  The "make-whole" redemption price will be equal to the greater of (1) 100% of the principal amount of the notes being redeemed, or (2) the sum of the present values of the remaining scheduled payments of principal and interest on the 2023 Notes being redeemed, discounted at the redemption date on a semi-annual basis at a rate equal to the sum of the applicable Treasury rate plus 50 basis points.  Accrued and unpaid interest, if any, will be paid to, but excluding, the redemption date.

[0001047469-15-006787:notes:62]
$1 billion Aggregate principal amount of 4.75%Senior Notes due January 2025 (the “2025 Notes”).  On May 28, 2014, Seagate HDD Cayman issued $1 billion in aggregate principal amount of 4.75% Senior Notes due 2025, which mature on January 1, 2025. The interest on the Notes will be payable in cash semiannually on January 1 and July 1 of each year, commencing on January 1, 2015. At any time, upon not less than 30 nor more than 60 days’ notice, Seagate HDD may redeem some or all of the Notes at a ‘‘make-whole’’ redemption price. The ‘‘make-whole’’ redemption price will be equal to the greater of (1) 100% of the principal amount of the Notes redeemed, and (2) the sum of the present values of the remaining scheduled payments of principal and interest on the Notes being redeemed, discounted to the redemption date on a semi-annual basis at a rate equal to the sum of the Treasury Rate plus 50 basis points. Accrued and unpaid interest, if any, will be paid to, but excluding, the redemption date. The Notes are fully and unconditionally guaranteed by the Company on a senior unsecured basis.

[0001047469-15-006787:notes:63]
$500 million Aggregate Principal Amount of 5.75% Senior Notes due December, 2034 (the “2034 Notes”). On December 2, 2014, Seagate HDD Cayman issued, in a private placement, $500 million in aggregate principal amount of 5.75% Senior Notes, which mature on December 1, 2034. The interest on the Notes is payable semi-annually on June 1 and December 1 of each year, commencing on June 1, 2015. At any time before June 1, 2034, Seagate HDD Cayman may redeem some or all of the Notes at a “make-whole” redemption price. The ‘‘make-whole’’ redemption price will be equal to (1) 100% of the principal amount of the Notes redeemed, plus (2) the excess, if any of (x) the sum of the present values of the remaining scheduled payments of principal and interest on the Notes being redeemed, discounted to the redemption date on a semi-annual basis at a rate equal to the sum of the Treasury Rate plus 50 basis points, minus accrued and unpaid interest, if any, on the Notes being redeemed to, but excluding, the redemption date over (y) the principal amount of the Notes being redeemed, plus (3) accrued and unpaid interest, if any, on the Notes being redeemed to, but excluding, the redemption date. At any time on or after June 1, 2034, the Company may redeem some or all of the Notes at a redemption price equal to 100% of the principal amount of the Notes redeemed, plus accrued and unpaid interest, if any, to, but excluding, the redemption date. The issuer under the 2034 Notes is Seagate HDD Cayman, and the obligations under the 2034 Notes are fully and unconditionally guaranteed, on a senior unsecured basis, by the Company. If, under certain circumstances, the 2034 Notes have not otherwise become freely transferable by December 3, 2015, then the Company is required to exchange the Notes for notes registered under the Securities Act of 1933.

[0001047469-15-006787:notes:64]
$700 million Aggregate Principal Amount of 4.875% Senior Notes due June, 2027 (the “2027 Notes”). On May 14, 2015, Seagate HDD Cayman issued, in a private placement, $700 million in aggregate principal amount of 4.875% Senior Notes, which mature on June 1, 2027. The interest on the Notes is payable semi-annually on June 1 and December 1 of each year, commencing on December 1, 2015. At any time before March 1, 2027, Seagate HDD Cayman may redeem some or all of the Notes at a “make-whole” redemption price. The ‘‘make-whole’’ redemption price will be equal to (1) 100% of the principal amount of the Notes redeemed, plus (2) the excess, if any of (x) the sum of the present values of the remaining scheduled payments of principal and interest on the Notes being redeemed, discounted to the redemption date on a semi-annual basis at a rate equal to the sum of the Treasury Rate plus 40 basis points, minus accrued and unpaid interest, if any, on the Notes being redeemed to, but excluding, the redemption date over (y) the principal amount of the Notes being redeemed, plus (3) accrued and unpaid interest, if any, on the Notes being redeemed to, but excluding, the redemption date. At any time on or after March 1, 2027, the Company may redeem some or all of the Notes at a redemption price equal to 100% of the principal amount of the Notes redeemed, plus accrued and unpaid interest, if any, to, but excluding, the redemption date. The issuer under the 2027 Notes is Seagate HDD Cayman, and the obligations under the 2027 Notes are fully and unconditionally guaranteed, on a senior unsecured basis, by the Company. If, under certain circumstances, the 2027 Notes have not otherwise become freely transferable by May 14, 2016, then the Company is required to exchange the Notes for notes registered under the Securities Act of 1933.

[0001047469-15-006787:notes:65]
At July 3, 2015, future principal payments on long-term debt were as follows (in millions):

[0001047469-15-006787:notes:66]
| Fiscal Year |  | Amount |
| 2016 |  | $ | — |  |
| 2017 |  | — |  |
| 2018 |  | — |  |
| 2019 |  | 800 |  |
| 2020 |  | — |  |
| Thereafter |  | 3,358 |  |
|  |  | $ | 4,158 |  |


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001047469-15-006787:notes:67]
Derivative Financial Instruments

[0001047469-15-006787:notes:68]
The Company is exposed to foreign currency exchange rate, interest rate, and to a lesser extent, equity price risks relating to its ongoing business operations.  The Company enters into foreign currency forward exchange contracts in order to manage the foreign currency exchange rate risk on forecasted expenses denominated in foreign currencies and to mitigate the remeasurement risk of certain foreign currency denominated liabilities.  The Company's accounting policies for these instruments are based on whether the instruments are classified as designated or non-designated hedging instruments.  The Company records all derivatives in the Consolidated Balance Sheets at fair value.  The changes in the fair value of the effective portions of designated cash flow hedges are recorded in Accumulated other comprehensive loss until the hedged item is recognized in earnings.  Derivatives that are not designated as hedging instruments and the ineffective portions of cash flow hedges are adjusted to fair value through earnings.  The amount of net unrealized gain on cash flow hedges was $1 million as of July 3, 2015 and the amount of net unrealized loss on cash flow hedges was $1 million as of June 27, 2014.

[0001047469-15-006787:notes:69]
The Company dedesignates its cash flow hedges when the forecasted hedged transactions are realized or it is probable the forecasted hedged transactions will not occur in the initially identified time period.  At such time, the associated gains and losses deferred in Accumulated other comprehensive loss are reclassified immediately into earnings and any subsequent changes in the fair value of such derivative instruments are immediately reflected in earnings.  The Company did not recognize any material net gains or losses related to the loss of hedge designation on discontinued cash flow hedges during fiscal years 2015,  2014, and  2013.  As of July 3, 2015, the Company's existing foreign currency forward exchange contracts mature within 12 months.  The deferred amount currently recorded in Accumulated other comprehensive loss expected to be recognized into earnings over the next 12 months is immaterial.

[0001047469-15-006787:notes:70]
The following tables show the total notional value of the Company's outstanding foreign currency forward exchange contracts as of July 3, 2015 and June 27, 2014:

[0001047469-15-006787:notes:71]
|  |  | As of July 3, 2015 |
| (Dollars in millions) |  | Contracts Designated as Hedges |  | Contracts Not Designated as Hedges |
| Thai Baht |  | $ | 18 |  |  | $ | 48 |  |
| Singapore Dollars |  | 23 |  |  | 42 |  |
| Chinese Renminbi |  | 5 |  |  | 16 |  |
| Euro |  | — |  |  | 13 |  |
| British Pound Sterling |  | 35 |  |  | — |  |
| Malaysian Ringgit |  | 12 |  |  | 15 |  |
|  |  | $ | 93 |  |  | $ | 134 |  |

[0001047469-15-006787:notes:72]
|  |  | As of June 27, 2014 |
| (Dollars in millions) |  | Contracts Designated as Hedges |  | Contracts Not Designated as Hedges |
| Thai baht |  | $ | — |  |  | $ | 143 |  |
| British Pound Sterling |  | 25 |  |  | — |  |
| Malaysian Ringgit |  | 9 |  |  | — |  |
|  |  | $ | 34 |  |  | $ | 143 |  |

[0001047469-15-006787:notes:73]
The Company is subject to equity market risks due to changes in the fair value of the notional investments selected by its employees as part of its Non-qualified Deferred Compensation Plan—the Seagate Deferred Compensation Plan (the “SDCP”).  In the quarter ended December 27, 2013, the Company entered into a Total Return Swap (“TRS”) in order to manage the equity market risks associated with the SDCP liabilities.  The Company pays a floating rate, based on LIBOR plus an interest rate spread, on the notional amount of the TRS.  The TRS is designed to substantially offset changes in the SDCP liability due to changes in the value of the investment options made by employees.  As of July 3, 2015, the notional investments underlying the TRS amounted to $98 million.  The contract term of the TRS is through January 2016 and is settled on a monthly basis, therefore limiting counterparty performance risk.  The Company did not designate the TRS as a hedge. Rather, the Company records all changes in the fair value of the TRS to earnings to offset the market value changes of the SDCP liabilities.

[0001047469-15-006787:notes:74]
The following tables show the Company's derivative instruments measured at gross fair value as reflected in the Consolidated Balance Sheets as of July 3, 2015 and June 27, 2014:

[0001047469-15-006787:notes:75]
|  |  | As of July 3, 2015 |
|  |  | Asset Derivatives |  | Liability Derivatives |
| (Dollars in millions) |  | Balance SheetLocation |  | FairValue |  | Balance SheetLocation |  | FairValue |
| Derivatives designated as hedging instruments: |  |  |  |  |  |  |  |  |
| Foreign currency forward exchange contracts |  | Other current assets |  | $ | 2 |  |  | Accrued expenses |  | $ | (1 | ) |
| Derivatives not designated as hedging instruments: |  |  |  |  |  |  |  |  |
| Foreign currency forward exchange contracts |  | Other current assets |  | — |  |  | Accrued expenses |  | (3 | ) |
| Total return swap |  | Other current assets |  | 1 |  |  | Accrued expenses |  | — |  |
| Total derivatives |  |  |  | $ | 3 |  |  |  |  | $ | (4 | ) |

[0001047469-15-006787:notes:76]
|  |  | As of June 27, 2014 |
|  |  | Asset Derivatives |  | Liability Derivatives |
| (Dollars in millions) |  | Balance SheetLocation |  | FairValue |  | Balance SheetLocation |  | FairValue |
| Derivatives designated as hedging instruments: |  |  |  |  |  |  |  |  |
| Foreign currency forward exchange contracts |  | Other current assets |  | $ | 3 |  |  | Accrued expenses |  | $ | — |  |
| Derivatives not designated as hedging instruments: |  |  |  |  |  |  |  |  |
| Foreign currency forward exchange contracts |  | Other current assets |  | 2 |  |  | Accrued expenses |  | — |  |
| Total return swap |  | Other current assets |  | — |  |  | Accrued expenses |  | — |  |
| Total derivatives |  |  |  | $ | 5 |  |  |  |  | $ | — |  |

[0001047469-15-006787:notes:77]
The following tables show the effect of the Company's derivative instruments on the Consolidated Statement of Comprehensive Income and the Consolidated Statements of Operations for the fiscal year ended July 3, 2015:

[0001047469-15-006787:notes:78]
(Dollars in millions)

[0001047469-15-006787:notes:79]
| Derivatives Designated as Cash Flow Hedges |  | Amount ofGain or(Loss)Recognizedin OCI onDerivatives(EffectivePortion) |  | Location ofGain or (Loss)ReclassifiedfromAccumulatedOCI intoIncome(EffectivePortion) |  | Amount ofGain or(Loss)ReclassifiedfromAccumulatedOCI intoIncome(EffectivePortion) |  | Location ofGain or (Loss)Recognized inIncome onDerivatives(IneffectivePortion andAmount ExcludedfromEffectivenessTesting) |  | Amount ofGainor (Loss)Recognized inIncome(IneffectivePortion andAmountExcluded fromEffectivenessTesting) (a) |
| Foreign currency forward exchange contracts |  | $ | (11 | ) |  | Cost of revenue |  | $ | (13 | ) |  | Cost of revenue |  | $ | 1 |  |

[0001047469-15-006787:notes:80]
| Derivatives Not Designated as Hedging Instruments |  | Location of Gain or(Loss) Recognized inIncome on Derivatives |  | Amount of Gain or(Loss) Recognized inIncome on Derivatives |
| Foreign currency forward exchange contracts |  | Other, net |  | $ | (4 | ) |
| Total return swap |  | Operating expenses |  | $ | — |  |

[0001047469-15-006787:notes:81]
___________________________________

[0001047469-15-006787:notes:82]
| (a) | The amounts of gains or losses recognized in income related to the ineffective portion of the hedging relationships were immaterial for the fiscal year ended July 3, 2015. The amount of gains recognized in income related to the amount excluded from the assessment of hedge effectiveness was $1 million for the fiscal year ended July 3, 2015. |

[0001047469-15-006787:notes:83]
The following tables show the effect of the Company's derivative instruments on the Consolidated Statement of Comprehensive Income and the Consolidated Statements of Operations for the fiscal year ended June 27, 2014:

[0001047469-15-006787:notes:84]
| Derivatives Designated as Cash Flow Hedges |  | Amount ofGain or(Loss)Recognizedin OCI onDerivatives(EffectivePortion) |  | Location ofGain or (Loss)ReclassifiedfromAccumulatedOCI intoIncome(EffectivePortion) |  | Amount ofGain or(Loss)ReclassifiedfromAccumulatedOCI intoIncome(EffectivePortion) |  | Location ofGain or (Loss)Recognized inIncome onDerivatives(IneffectivePortion andAmount ExcludedfromEffectivenessTesting) |  | Amount ofGainor (Loss)Recognized inIncome(IneffectivePortion andAmountExcluded fromEffectivenessTesting) (a) |
| Foreign currency forward exchange contracts |  | $ | (1 | ) |  | Cost of revenue |  | $ | — |  |  | Cost of revenue |  | $ | — |  |

[0001047469-15-006787:notes:85]
| Derivatives Not Designated as Hedging Instruments |  | Location of Gain or(Loss) Recognized inIncome on Derivatives |  | Amount of Gain or(Loss) Recognized inIncome on Derivatives |
| Foreign currency forward exchange contracts |  | Other, net |  | $ | — |  |
| Total return swap |  | Operating expenses |  | $ | — |  |

[0001047469-15-006787:notes:86]
| (a) | The amounts of gains or losses recognized in income related to the ineffective portion of the hedging relationships and to the amount excluded from the assessment of hedge effectiveness were immaterial for the fiscal year ended June 27, 2014. |


## us-gaap:DerivativesPolicyTextBlock

[0001047469-15-006787:notes:87]
Derivative Financial Instruments.    The Company applies the requirements of ASC Topic 815 (ASC 815), Derivatives and Hedging. ASC 815 requires that all derivatives be recorded on the balance sheet at fair value and establishes criteria for designation and effectiveness of hedging relationships.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001047469-15-006787:notes:88]
Compensation

[0001047469-15-006787:notes:89]
Stock-Based Compensation Plans

[0001047469-15-006787:notes:90]
The Company's stock-based compensation plans have been established to promote the Company's long-term growth and financial success by providing incentives to its employees, directors, and consultants through grants of share-based awards.  The provisions of the Company's stock-based benefit plans, which allow for the grant of various types of equity-based awards, are also intended to provide greater flexibility to maintain the Company's competitive ability to attract, retain and motivate participants for the benefit of the Company and its shareholders.

[0001047469-15-006787:notes:91]
Seagate Technology plc 2012 Equity Incentive Plan (the “EIP”).  On October 26, 2011, the shareholders approved the EIP and authorized the issuance of up to a total of  27.0 million ordinary shares, par value $0.0001 per share, plus any shares remaining available for grant under the Seagate Technology plc 2004 Share Compensation Plan (the "SCP") as of the effective date of the EIP (which was equal to 11.0 million ordinary shares as of the effective date of the EIP and which will increase by such additional number of shares as will be returned to the share reserve in respect of awards previously granted under the SCP) (together, the “Share Reserve”).  Any shares that are subject to options or share appreciation rights granted under the EIP will be counted against the Share Reserve as one share for every one share granted, and any shares that are subject to restricted share bonus awards, restricted share units, performance share bonus awards or performance share awards (collectively, “Full-Value Share Awards”) will generally be counted against the Share Reserve as two and one-tenth shares for every one share granted.  As of July 3, 2015, there were approximately 40.0 million ordinary shares available for issuance under the EIP.

[0001047469-15-006787:notes:92]
Seagate Technology plc Stock Purchase Plan (the "ESPP").  There are 50.0 million ordinary shares authorized to be issued under the ESPP.  In no event shall the total number of shares issued under the ESPP exceed 75.0 million ordinary shares.  The ESPP consists of a six-month offering period with a maximum issuance of 1.5 million ordinary shares per offering period.  The ESPP permits eligible employees to purchase ordinary shares through payroll deductions generally at 85% of the fair market value of the ordinary shares.  As of July 3, 2015 there were approximately 8.9 million ordinary shares available for issuance under the ESPP.

[0001047469-15-006787:notes:93]
LyveMinds Inc. 2012 Equity Incentive Plan (the "LyveMinds Plan").  On October 19, 2012, LyveMinds Inc., a majority-owned subsidiary of the Company, adopted the LyveMinds Inc. 2012 Equity Incentive Plan (the "LyveMinds Plan").  A maximum of 31.9 million shares of LyveMinds' common stock are issuable under the LyveMinds Plan to employees, directors, and consultants of Lyve Minds.  Options granted to LyveMinds employees generally vest as follows:  25% of the options on the first anniversary of the vesting commencement date and the remaining 75% proportionately each month over the next 36 months.  Options expire ten years from the date of grant.  LyveMinds, Inc. adopted the Amended and Restated 2012 Equity Incentive Plan on March 26, 2014 in connection with LyveMinds' reincorporation as a Delaware corporation.  The compensation expense associated with options granted to date under the LyveMinds Plan was not material for fiscal years 2015,  2014, and  2013, respectively.

[0001047469-15-006787:notes:94]
Equity Awards

[0001047469-15-006787:notes:95]
Full-Value Share Awards (e.g. restricted share units) generally vest over a period of three to four years, with cliff vesting of a portion of each award occurring annually.  Options generally vest as follows:  25% of the options will vest on the first anniversary of the vesting commencement date and the remaining 75% will vest ratably each month thereafter over the next 36 months.  Options granted under the EIP and SCP have an exercise price equal to the closing price of the Company's ordinary shares on date of grant.

[0001047469-15-006787:notes:96]
The Company granted performance awards to its senior executive officers under the SCP and the EIP where vesting is subject to both the continued employment of the participant by the Company and the achievement of certain performance goals established by the Compensation Committee of the Company's Board of Directors, including market based performance goals.  A single award represents the right to receive a single ordinary share of the Company.  During fiscal years 2015,  2014 and 2013, the Company granted 0.3 million, 0.4 million and 0.7 million performance awards, respectively, where performance is measured based on a three-year average return on invested capital (ROIC) goal and a relative total shareholder return (TSR) goal, which is based on the Company's ordinary shares measured against a benchmark TSR of a peer group over the same three-year period (the "TSR/ROIC" awards).  These awards vest after the end of the performance period of three years from the grant date.  A percentage of these units may vest only if at least the minimum ROIC goal is met regardless of whether the TSR goal is met.  The number of stock units to vest will range from 0% to 200% of the targeted units.  In evaluating the fair value of these units, the Company used a Monte Carlo simulation on the grant date, taking the market-based TSR goal into consideration.  Compensation expense related to these units is only recorded in a period if it is probable that the ROIC goal will be met, and it is to be recorded at the expected level of achievement.

[0001047469-15-006787:notes:97]
The Company also granted 0.4 million, 0.3 million and 0.3 million performance awards during fiscal years  2015,  2014 and  2013 respectively, to its senior executive officers which are subject to a performance goal related to the Company's adjusted earnings per share (the "AEPS" awards).  These awards have a maximum seven-year vesting period, with 25% annual vesting starting on the first anniversary of the grant date.  If the performance goal is not achieved, vesting is delayed to a following year in which the AEPS goal is achieved.  Any unvested awards from prior years may vest cumulatively in a future year within the seven-year vesting period if the annual AEPS goal is achieved during a subsequent year.  If the AEPS goal has not been met by the end of the seven year period, any unvested shares will be forfeited.

[0001047469-15-006787:notes:98]
During fiscal year 2015 and 2014, the Company did not grant any performance-based options and performance based restricted share units to its CEO.  In fiscal year 2013, the Company granted 0.2 million performance-based options and 0.1 million performance-based restricted share units to its CEO which are based on the attainment of a minimum 40% TSR (the "40% TSR" awards).  The 40% TSR awards cliff vest after three years, contingent upon continued service and the attainment of a minimum 40% TSR, inclusive of dividends and share price appreciation, over a three-year performance period, which TSR must be sustained for a minimum of 30 consecutive trading days.

[0001047469-15-006787:notes:99]
Determining Fair Value of Seagate Technology Stock Plans

[0001047469-15-006787:notes:100]
Valuation and amortization method - The Company estimates the fair value of stock options granted using the Black-Scholes-Merton valuation model and a single option award approach.  This fair value is then amortized on a straight-line basis over the requisite service periods of the awards, which is generally the vesting period or the remaining service (vesting) period.

[0001047469-15-006787:notes:101]
Expected Term - Expected term represents the period that the Company's stock-based awards are expected to be outstanding and was determined based on historical experience of similar awards, giving consideration to the contractual terms of the stock-based awards, vesting schedules and expectations of future employee behavior as influenced by changes to the terms of its stock-based awards.

[0001047469-15-006787:notes:102]
Expected Volatility - The Company uses a combination of the implied volatility of its traded options and historical volatility of its share price.

[0001047469-15-006787:notes:103]
Expected Dividend - The Black-Scholes-Merton valuation model calls for a single expected dividend yield as an input.  The dividend yield is determined by dividing the expected per share dividend during the coming year by the grant date share price.  The expected dividend assumption is based on the Company's current expectations about its anticipated dividend policy.  Also, because the expected dividend yield should reflect marketplace participants' expectations, the Company does not incorporate changes in dividends anticipated by management unless those changes have been communicated to or otherwise are anticipated by marketplace participants.

[0001047469-15-006787:notes:104]
Risk-Free Interest Rate - The Company bases the risk-free interest rate used in the Black-Scholes-Merton valuation model on the implied yield currently available on U.S. Treasury zero-coupon issues with an equivalent remaining term.  Where the expected term of the Company's stock-based awards do not correspond with the terms for which interest rates are quoted, the Company performed a straight-line interpolation to determine the rate from the available term maturities.

[0001047469-15-006787:notes:105]
Fair Value - The fair value of the Company's nonvested awards and performance awards subject to an AEPS condition for fiscal years 2015,  2014, and  2013, is the price per share of the Company's common stock on the grant date.  The weighted average grant date fair value of awards granted are as follows:

[0001047469-15-006787:notes:106]
The fair value of the Company's shares related to options granted to employees, shares issued from the ESPP and performance awards subject to TSR/ROIC conditions for fiscal years  2015,  2014, and  2013 were estimated using the following assumptions:

[0001047469-15-006787:notes:107]
Stock Compensation Expense

[0001047469-15-006787:notes:108]
The Company recorded $137 million, $118 million and $76 million of share-based compensation during fiscal years 2015,  2014, and  2013, respectively.  Management has made an estimate of expected forfeitures and is recognizing compensation costs only for those equity awards expected to vest.  When estimating forfeitures, the Company considers voluntary termination behavior as well as analysis of actual forfeited awards.

[0001047469-15-006787:notes:109]
Stock Option Activity

[0001047469-15-006787:notes:110]
The Company issues new ordinary shares upon exercise of stock options. The following is a summary of option activities:

[0001047469-15-006787:notes:111]
| Options |  | Number ofShares |  | Weighted-AverageExercisePrice |  | Weighted-AverageRemainingContractualTerm |  | AggregateIntrinsicValue |
|  |  | (In millions) |  |  |  | (In years) |  | (Dollars In millions) |
| Outstanding at June 27, 2014 |  | 6.4 |  |  | $ | 19.80 |  |  | 3.8 |  | $ | 238 |  |
| Granted |  | 1.2 |  |  | $ | 59.47 |  |  |  |  |  |  |
| Exercised |  | (2.1 | ) |  | $ | 17.00 |  |  |  |  |  |  |
| Forfeitures |  | (0.6 | ) |  | $ | 41.36 |  |  |  |  |  |  |
| Expirations |  | — |  |  | — |  |  |  |  |  |  |
| Outstanding at July 3, 2015 |  | 4.9 |  |  | $ | 27.94 |  |  | 3.6 |  | $ | 110 |  |
| Vested and expected to vest at July 3, 2015 |  | 4.8 |  |  | $ | 27.43 |  |  | 3.6 |  | $ | 107 |  |
| Exercisable at July 3, 2015 |  | 2.8 |  |  | $ | 14.48 |  |  | 2.3 |  | $ | 93 |  |

[0001047469-15-006787:notes:112]
The aggregate intrinsic value is calculated as the difference between the exercise price of the underlying awards and the quoted price of the Company's ordinary shares for the options that were in-the-money at July 3, 2015.  During fiscal years 2015,  2014, and  2013, the aggregate intrinsic value of options exercised under the Company's stock option plans was $92 million, $140 million and $272 million, respectively, determined as of the date of option exercise.  The aggregate fair value of options vested during fiscal year 2015 was approximately $10 million.

[0001047469-15-006787:notes:113]
At July 3, 2015, the total compensation cost related to options granted to employees but not yet recognized was approximately $18 million, net of estimated forfeitures of approximately $1 million.  This cost is being amortized on a straight-line basis over a weighted-average remaining term of approximately 2.6 years and will be adjusted for subsequent changes in estimated forfeitures.

[0001047469-15-006787:notes:114]
Nonvested Awards Activity

[0001047469-15-006787:notes:115]
The following is a summary of nonvested award activities which do not contain a performance condition:

[0001047469-15-006787:notes:116]
| Nonvested Awards |  | Number ofShares |  | Weighted-AverageGrant-DateFair Value |
|  |  | (In millions) |  |  |
| Nonvested at June 27, 2014 |  | 7.0 |  |  | $ | 32.05 |  |
| Granted |  | 1.2 |  |  | $ | 58.93 |  |
| Forfeitures |  | (0.4 | ) |  | $ | 41.56 |  |
| Vested |  | (2.6 | ) |  | $ | 28.76 |  |
| Nonvested at July 3, 2015 |  | 5.2 |  |  | $ | 39.73 |  |

[0001047469-15-006787:notes:117]
At July 3, 2015, the total compensation cost related to nonvested awards granted to employees but not yet recognized was approximately $151 million, net of estimated forfeitures of approximately $8 million.  This cost is being amortized on a straight-line basis over a weighted-average remaining term of 2.4 years and will be adjusted for subsequent changes in estimated forfeitures.  The aggregate fair value of nonvested awards vested during fiscal year 2015 was approximately $156 million.

[0001047469-15-006787:notes:118]
Performance Awards

[0001047469-15-006787:notes:119]
The following is a summary of nonvested award activities which contain a performance condition:

[0001047469-15-006787:notes:120]
| Performance Awards |  | Number ofShares |  | Weighted-AverageGrant-DateFair Value |
|  |  | (In millions) |  |  |
| Performance units at June 27, 2014 |  | 2.4 |  |  | $ | 26.73 |  |
| Granted |  | 0.7 |  |  | $ | 58.97 |  |
| Forfeitures |  | (0.3 | ) |  | $ | 43.54 |  |
| Vested |  | (1.7 | ) |  | $ | 13.99 |  |
| Performance units at July 3, 2015 |  | 1.1 |  |  | $ | 61.12 |  |

[0001047469-15-006787:notes:121]
At July 3, 2015, the total compensation cost related to performance awards granted to employees but not yet recognized was approximately $39 million.  This cost is being amortized on a straight-line basis over a weighted-average remaining term of 3.8 years.

[0001047469-15-006787:notes:122]
ESPP

[0001047469-15-006787:notes:123]
During fiscal years 2015, 2014 and  2013, the aggregate intrinsic value of shares purchased under the Company's ESPP was approximately $15 million, $26 million and $17 million respectively.  At July 3, 2015, the total compensation cost related to options to purchase the Company's ordinary shares under the ESPP but not yet recognized was approximately $1.5 million.  This cost will be amortized on a straight-line basis over a weighted-average period of approximately one month.  During fiscal year 2015, the Company issued 1.3 million ordinary shares with a weighted-average purchase price of $45.78 per share.

[0001047469-15-006787:notes:124]
Tax-Deferred Savings Plan

[0001047469-15-006787:notes:125]
The Company has a tax-deferred savings plan, the Seagate 401(k) Plan (the "40l(k) plan"), for the benefit of qualified employees.  The 40l(k) plan is designed to provide employees with an accumulation of funds at retirement. Qualified employees may elect to make contributions to the 401(k) plan on a bi-weekly basis.  Pursuant to the 401(k) plan, the Company matches 50% of employee contributions, up to 6% of compensation, subject to maximum annual contributions of $4,500 per participating employee.  During fiscal years 2015,  2014, and  2013, the Company made matching contributions of $18 million, $16 million and $14 million, respectively.

[0001047469-15-006787:notes:126]
Deferred Compensation Plan

[0001047469-15-006787:notes:127]
On January 1, 2001, the Company adopted the SDCP for the benefit of eligible employees.  This plan is designed to permit certain discretionary employer contributions, in excess of the tax limits applicable to the 401(k) plan and to permit employee deferrals in excess of certain tax limits.  In the quarter ended December 27, 2013, the Company entered into a Total Return Swap (“TRS”) in order to manage the equity market risks associated with the SDCP liabilities.  See "Note 8. Derivative Financial Instruments" contained in this report for additional information about the TRS.


## us-gaap:EarningsPerShareTextBlock

[0001047469-15-006787:notes:128]
Earnings Per Share

[0001047469-15-006787:notes:129]
The following table sets forth the computation of basic and diluted net income per share:

[0001047469-15-006787:notes:130]
|  | Fiscal Years Ended |
| (In millions, except per share data) | July 3, 2015 |  | June 27, 2014 |  | June 28, 2013 |
| Numerator: |  |  |  |  |  |
| Net income attributable to Seagate Technology plc | $ | 1,742 |  |  | $ | 1,570 |  |  | $ | 1,838 |  |
| Number of shares used in per share calculations: |  |  |  |  |  |
| Total shares for purposes of calculating basic net income per share attributable to Seagate Technology plc | 324 |  |  | 337 |  |  | 370 |  |
| Weighted-average effect of dilutive securities: |  |  |  |  |  |
| Employee equity award plans | 7 |  |  | 10 |  |  | 12 |  |
| Total shares for purpose of calculating diluted net income per share attributable to Seagate Technology plc | 331 |  |  | 347 |  |  | 382 |  |
| Net income per share attributable to Seagate Technology plc shareholders: |  |  |  |  |  |
| Basic | $ | 5.38 |  |  | $ | 4.66 |  |  | $ | 4.97 |  |
| Diluted | $ | 5.26 |  |  | $ | 4.52 |  |  | $ | 4.81 |  |

[0001047469-15-006787:notes:131]
The following potential shares were excluded from the computation of diluted net income per share as their effect would have been anti-dilutive:

[0001047469-15-006787:notes:132]
|  | Fiscal Years Ended |
| (In millions) | July 3, 2015 |  | June 27, 2014 |  | June 28, 2013 |
| Employee equity award plans | — |  |  | — |  |  | — |  |


## us-gaap:FairValueByBalanceSheetGroupingTextBlock

[0001047469-15-006787:notes:133]
|  |  | Fair Value Measurements at Reporting Date Using |
| (Dollars in millions) |  | QuotedPrices inActiveMarkets forIdenticalInstruments(Level 1) |  | SignificantOtherObservableInputs(Level 2) |  | SignificantUnobservableInputs(Level 3) |  | TotalBalance |
| Assets: |  |  |  |  |  |  |  |  |
| Cash and cash equivalents |  | $ | 793 |  |  | $ | 1,516 |  |  | $ | — |  |  | $ | 2,309 |  |
| Short-term investments |  | — |  |  | 20 |  |  | — |  |  | 20 |  |
| Restricted cash and investments |  | — |  |  | 4 |  |  | — |  |  | 4 |  |
| Other assets, net |  | — |  |  | 5 |  |  | — |  |  | 5 |  |
| Total assets |  | $ | 793 |  |  | $ | 1,545 |  |  | $ | — |  |  | $ | 2,338 |  |
| Liabilities: |  |  |  |  |  |  |  |  |
| Accrued expenses |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |
| Total liabilities |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |

[0001047469-15-006787:notes:134]
|  |  | Fair Value Measurements at Reporting Date Using |
| (Dollars in millions) |  | QuotedPrices inActiveMarkets forIdenticalInstruments(Level 1) |  | SignificantOtherObservableInputs(Level 2) |  | SignificantUnobservableInputs(Level 3) |  | TotalBalance |
| Assets: |  |  |  |  |  |  |  |  |
| Cash and cash equivalents |  | $ | 1,201 |  |  | $ | 862 |  |  | $ | — |  |  | $ | 2,063 |  |
| Short-term investments |  | — |  |  | 6 |  |  | — |  |  | 6 |  |
| Restricted cash and investments |  | 2 |  |  | 5 |  |  | — |  |  | 7 |  |
| Other assets, net |  | — |  |  | 3 |  |  | — |  |  | 3 |  |
| Total assets |  | $ | 1,203 |  |  | $ | 876 |  |  | $ | — |  |  | $ | 2,079 |  |
| Liabilities: |  |  |  |  |  |  |  |  |
| Accrued expenses |  | $ | — |  |  | $ | (4 | ) |  | $ | — |  |  | $ | (4 | ) |
| Total liabilities |  | $ | — |  |  | $ | (4 | ) |  | $ | — |  |  | $ | (4 | ) |


## us-gaap:FairValueDisclosuresTextBlock

[0001047469-15-006787:notes:135]
Fair Value

[0001047469-15-006787:notes:136]
Measurement of Fair Value

[0001047469-15-006787:notes:137]
Fair value is defined as the price that would be received from selling an asset or paid to transfer a liability in an orderly transaction between market participants at the measurement date.  When determining the fair value measurements for assets and liabilities required to be recorded at fair value, the Company considers the principal or most advantageous market in which it would transact and it considers assumptions that market participants would use when pricing the asset or liability.

[0001047469-15-006787:notes:138]
Fair Value Hierarchy

[0001047469-15-006787:notes:139]
A fair value hierarchy is based on whether the market participant assumptions used in determining fair value are obtained from independent sources (observable inputs) or reflects the Company's own assumptions of market participant valuation (unobservable inputs).  A financial instrument's categorization within the fair value hierarchy is based upon the lowest level of input that is significant to the fair value measurement.  The three levels of inputs that may be used to measure fair value:

[0001047469-15-006787:notes:140]
Level 1 - Quoted prices in active markets that are unadjusted and accessible at the measurement date for identical, unrestricted assets or liabilities;

[0001047469-15-006787:notes:141]
Level 2 - Quoted prices for identical assets and liabilities in markets that are inactive; quoted prices for similar assets and liabilities in active markets or financial instruments for which significant inputs are observable, either directly or indirectly; or

[0001047469-15-006787:notes:142]
Level 3 - Prices or valuations that require inputs that are both unobservable and significant to the fair value measurement.

[0001047469-15-006787:notes:143]
The Company considers an active market to be one in which transactions for the asset or liability occur with sufficient frequency and volume to provide pricing information on an ongoing basis, and views an inactive market as one in which there are few transactions for the asset or liability, the prices are not current, or price quotations vary substantially either over time or among market makers.  Where appropriate the Company's or the counterparty's non-performance risk is considered in determining the fair values of liabilities and assets, respectively.

[0001047469-15-006787:notes:144]
Items Measured at Fair Value on a Recurring Basis

[0001047469-15-006787:notes:145]
The following table presents the Company's assets and liabilities that are measured at fair value on a recurring basis, excluding accrued interest components, as of July 3, 2015:

[0001047469-15-006787:notes:146]
|  |  | Fair Value Measurements at Reporting Date Using |
| (Dollars in millions) |  | QuotedPrices inActiveMarkets forIdenticalInstruments(Level 1) |  | SignificantOtherObservableInputs(Level 2) |  | SignificantUnobservableInputs(Level 3) |  | TotalBalance |
| Assets: |  |  |  |  |  |  |  |  |
| Money market funds |  | $ | 1,201 |  |  | $ | — |  |  | $ | — |  |  | $ | 1,201 |  |
| Certificates of deposit |  | — |  |  | 862 |  |  | — |  |  | 862 |  |
| Corporate bonds |  | — |  |  | 6 |  |  | — |  |  | 6 |  |
| Total cash equivalents and short-term investments |  | 1,201 |  |  | 868 |  |  | — |  |  | 2,069 |  |
| Restricted cash and investments: |  |  |  |  |  |  |  |  |
| Money market funds |  | 2 |  |  | — |  |  | — |  |  | 2 |  |
| Certificates of deposit |  | — |  |  | 5 |  |  | — |  |  | 5 |  |
| Derivative assets |  | — |  |  | 3 |  |  | — |  |  | 3 |  |
| Total assets |  | $ | 1,203 |  |  | $ | 876 |  |  | $ | — |  |  | $ | 2,079 |  |
| Liabilities: |  |  |  |  |  |  |  |  |
| Derivative liabilities |  | $ | — |  |  | $ | (4 | ) |  | $ | — |  |  | $ | (4 | ) |
| Total liabilities |  | $ | — |  |  | $ | (4 | ) |  | $ | — |  |  | $ | (4 | ) |

[0001047469-15-006787:notes:147]
The following table presents the Company's assets and liabilities that are measured at fair value on a recurring basis, excluding accrued interest components, as of June 27, 2014:

[0001047469-15-006787:notes:148]
|  |  | Fair Value Measurements at Reporting Date Using |
| (Dollars in millions) |  | QuotedPrices inActiveMarkets forIdenticalInstruments(Level 1) |  | SignificantOtherObservableInputs(Level 2) |  | SignificantUnobservableInputs(Level 3) |  | TotalBalance |
| Assets: |  |  |  |  |  |  |  |  |
| Money market funds |  | $ | 793 |  |  | $ | — |  |  | $ | — |  |  | $ | 793 |  |
| Commercial paper |  | — |  |  | 1,261 |  |  | — |  |  | 1,261 |  |
| Certificates of deposit |  | — |  |  | 269 |  |  | — |  |  | 269 |  |
| Corporate bonds |  | — |  |  | 6 |  |  | — |  |  | 6 |  |
| Total cash equivalents and short-term investments |  | 793 |  |  | 1,536 |  |  | — |  |  | 2,329 |  |
| Restricted Cash and Investments: |  |  |  |  |  |  |  |  |
| Other debt securities |  | — |  |  | 4 |  |  | — |  |  | 4 |  |
| Derivative assets |  | — |  |  | 5 |  |  | — |  |  | 5 |  |
| Total assets |  | $ | 793 |  |  | $ | 1,545 |  |  | $ | — |  |  | $ | 2,338 |  |
| Liabilities: |  |  |  |  |  |  |  |  |
| Derivative liabilities |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |
| Total liabilities |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |

[0001047469-15-006787:notes:149]
The Company classifies items in Level 1 if the financial assets consist of securities for which quoted prices are available in an active market.

[0001047469-15-006787:notes:150]
The Company classifies items in Level 2 if the financial asset or liability is valued using observable inputs.  The Company uses observable inputs including quoted prices in active markets for similar assets or liabilities.  Level 2 assets include:  agency bonds, corporate bonds, commercial paper, municipal bonds, U.S. Treasuries and certificates of deposits. These debt investments are priced using observable inputs and valuation models which vary by asset class.  The Company uses a pricing service to assist in determining the fair values of all of its cash equivalents and short-term investments.  For the cash equivalents and short-term investments in the Company's portfolio, multiple pricing sources are generally available.  The pricing service uses inputs from multiple industry standard data providers or other third party sources and various methodologies, such as weighting and models, to determine the appropriate price at the measurement date.  The Company corroborates the prices obtained from the pricing service against other independent sources and, as of July 3, 2015, has not found it necessary to make any adjustments to the prices obtained.  The Company's derivative financial instruments are also classified within Level 2.  The Company's derivative financial instruments consist of foreign currency forward exchange contracts and the TRS.  The Company recognizes derivative financial instruments in its consolidated financial statements at fair value.  The Company determines the fair value of these instruments by considering the estimated amount it would pay or receive to terminate these agreements at the reporting date.

[0001047469-15-006787:notes:151]
As of July 3, 2015 and June 27, 2014, we had no Level 3 assets.

[0001047469-15-006787:notes:152]
Items Measured at Fair Value on a Non-Recurring Basis

[0001047469-15-006787:notes:153]
The Company enters into certain strategic investments for the promotion of business and strategic objectives.  Strategic investments in equity securities where the Company does not have the ability to exercise significant influence over the investees, included in Other assets, net in the Consolidated Balance Sheets, are recorded at cost and are periodically analyzed to determine whether or not there are indicators of impairment.  The carrying value of the Company's strategic investments at July 3, 2015 and June 27, 2014 totaled $120 million and $46 million, respectively, and consisted primarily of privately held equity securities without a readily determinable fair value.

[0001047469-15-006787:notes:154]
During the fiscal years  2015,  2014 and  2013, the Company determined that certain of its equity investments accounted for under the cost method were other-than-temporarily impaired, and recognized charges of $7 million, $2 million and $5 million, respectively, in order to write down the carrying amount of the investments to its estimated fair value.  These amounts were recorded in Other, net in the Consolidated Statements of Operations. Since there was no active market for the equity securities of the investee, the Company estimated fair value of the investee by analyzing the underlying cash flows and future prospects of the investee.

[0001047469-15-006787:notes:155]
Other Fair Value Disclosures

[0001047469-15-006787:notes:156]
The Company's debt is carried at amortized cost.  The fair value of the Company's debt is derived using the closing price of the same debt instruments as of the date of valuation, which takes into account the yield curve, interest rates, and other observable inputs.  Accordingly, these fair value measurements are categorized as Level 2.  The following table presents the fair value and amortized cost of the Company's debt in order of maturity:

[0001047469-15-006787:notes:157]
|  |  | July 3, 2015 |  | June 27, 2014 |
| (Dollars in millions) |  | CarryingAmount |  | EstimatedFair Value |  | CarryingAmount |  | EstimatedFair Value |
| 6.8% Senior Notes due October 2016 |  | $ | — |  |  | $ | — |  |  | $ | 335 |  |  | $ | 374 |  |
| 3.75% Senior Notes due November 2018 |  | 800 |  |  | 828 |  |  | 800 |  |  | 820 |  |
| 6.875% Senior Notes due May 2020 |  | — |  |  | — |  |  | 534 |  |  | 578 |  |
| 7.00% Senior Notes due November 2021 |  | 158 |  |  | 170 |  |  | 251 |  |  | 284 |  |
| 4.75% Senior Notes due June 2023 |  | 1,000 |  |  | 1,016 |  |  | 1,000 |  |  | 1,009 |  |
| 4.75% Senior Notes due January 2025 |  | 1,000 |  |  | 995 |  |  | 1,000 |  |  | 995 |  |
| 4.875% Senior Notes due June 2027 |  | 698 |  |  | 675 |  |  | — |  |  | — |  |
| 5.75% Senior Notes due December 2034 |  | 499 |  |  | 491 |  |  | — |  |  | — |  |
|  |  | 4,155 |  |  | 4,175 |  |  | 3,920 |  |  | 4,060 |  |
| Less short-term borrowings and current portion of long-term debt |  | — |  |  | — |  |  | — |  |  | — |  |
| Long-term debt, less current portion |  | $ | 4,155 |  |  | $ | 4,175 |  |  | $ | 3,920 |  |  | $ | 4,060 |  |


## us-gaap:ForeignCurrencyTransactionsAndTranslationsPolicyTextBlock

[0001047469-15-006787:notes:158]
Foreign Currency Remeasurement and Translation.    The U.S. dollar is the functional currency for the majority of the Company's foreign operations. Monetary assets and liabilities denominated in foreign currencies are remeasured into the functional currency of the subsidiary at the balance sheet date. The gains and losses from the remeasurement of foreign currency denominated balances into the functional currency of the subsidiary are included in Other, net on the Company's Consolidated Statements of Operations.

[0001047469-15-006787:notes:159]
The Company translates the assets and liabilities of its non-U.S. dollar functional currency subsidiaries into U.S. dollars using exchange rates in effect at the end of each period. Revenue and expenses for these subsidiaries are translated using rates that approximate those in effect during the period. Gains and losses from these translations are recognized in foreign currency translation included in Accumulated Other comprehensive income (loss), which is a component of shareholders’ equity. The Company’s subsidiaries that use the U.S. dollar as their functional currency remeasure monetary assets and liabilities at exchange rates in effect at the end of each period, and inventories, property, and nonmonetary assets and liabilities at historical rates. Gains and losses from these remeasurements were not significant and have been included in the Company’s results of operations.


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0001047469-15-006787:notes:160]
Goodwill and Other Intangible Assets

[0001047469-15-006787:notes:161]
Goodwill

[0001047469-15-006787:notes:162]
The changes in the carrying amount of goodwill are as follows:

[0001047469-15-006787:notes:163]
| (Dollars in millions) | Amount |
| As of June 28, 2013 | $ | 476 |  |
| Goodwill acquired | 60 |  |
| Foreign currency translation effect | 1 |  |
| As of June 27, 2014 | $ | 537 |  |
| Goodwill acquired | 339 |  |
| Foreign currency translation effect | (2 | ) |
| As of July 3, 2015 | $ | 874 |  |

[0001047469-15-006787:notes:164]
Other Intangible Assets

[0001047469-15-006787:notes:165]
Other intangible assets consist primarily of existing technology, customer relationships, in-process research and development and trade names acquired in business combinations. With the exception of in-process research and development, acquired intangibles are amortized on a straight-line basis over the respective estimated useful lives of the assets. Amortization is charged to Operating expenses in the Consolidated Statements of Operations. In-process research and development has been determined to have an indefinite useful life and is not amortized, but instead tested for impairment annually or more frequently if events or changes in circumstance indicate that the asset might be impaired. If the carrying amount of in-process research and development exceeds its fair value, an impairment loss is recognized in an amount equal to that excess. There were no impairment charges recognized for in-process research and development. All in-process research and development was completed during fiscal year 2015, the related assets are now accounted for as existing technology and are being amortized over their useful lives.

[0001047469-15-006787:notes:166]
In fiscal years 2015, 2014 and  2013, amortization expense for other intangible assets was $152 million, $131 million and $147 million, respectively.

[0001047469-15-006787:notes:167]
The carrying value of other intangible assets subject to amortization as of July 3, 2015, is set forth in the following table:

[0001047469-15-006787:notes:168]
| (Dollars in millions) |  | Gross CarryingAmount |  | AccumulatedAmortization |  | Net CarryingAmount |  | Weighted AverageRemaining Useful Life |
| Existing technology |  | $ | 191 |  |  | $ | (69 | ) |  | $ | 122 |  |  | 4.1 years |
| Customer relationships |  | 487 |  |  | (282 | ) |  | 205 |  |  | 2.4 years |
| Trade name |  | 27 |  |  | (7 | ) |  | 20 |  |  | 3.2 years |
| Other intangible assets |  | 27 |  |  | (4 | ) |  | 23 |  |  | 4.2 years |
| Total amortizable other intangible assets |  | $ | 732 |  |  | $ | (362 | ) |  | $ | 370 |  |  | 3.1 years |

[0001047469-15-006787:notes:169]
The carrying value of other intangible assets subject to amortization as of June 27, 2014 is set forth in the following table:

[0001047469-15-006787:notes:170]
| (Dollars in millions) |  | Gross CarryingAmount |  | AccumulatedAmortization |  | Net CarryingAmount |  | Weighted AverageRemaining Useful Life |
| Existing technology |  | $ | 68 |  |  | $ | (18 | ) |  | $ | 50 |  |  | 2.9 years |
| Customer relationships |  | 450 |  |  | (192 | ) |  | 258 |  |  | 3.3 years |
| Trade name |  | 10 |  |  | (1 | ) |  | 9 |  |  | 3.1 years |
| Other intangible assets |  | 4 |  |  | (1 | ) |  | $ | 3 |  |  | 4.4 years |
| Total amortizable other intangible assets |  | $ | 532 |  |  | $ | (212 | ) |  | $ | 320 |  |  | 3.2 years |

[0001047469-15-006787:notes:171]
The carrying value of In-process research and development not subject to amortization was $39 million on June 27, 2014.

[0001047469-15-006787:notes:172]
As of July 3, 2015, expected amortization expense for other intangible assets for each of the next five years and thereafter is as follows:

[0001047469-15-006787:notes:173]
| (Dollars in millions) |  | Amount |
| 2016 |  | $ | 141 |  |
| 2017 |  | 122 |  |
| 2018 |  | 64 |  |
| 2019 |  | 24 |  |
| 2020 |  | 7 |  |
| Thereafter |  | 12 |  |
|  |  | $ | 370 |  |


## us-gaap:GoodwillAndIntangibleAssetsPolicyTextBlock

[0001047469-15-006787:notes:174]
Assessment of Goodwill and Other Long-lived Assets for Impairment.  The Company accounts for goodwill in accordance with Accounting Standards Codification (ASC) Topic 350 (ASC 350), Intangibles - Goodwill and Other. During fiscal year 2012, the Company adopted ASU No. 2011-08, Intangibles - Goodwill and Other (ASC Topic 350) - Testing Goodwill for Impairment. The Company performs a qualitative assessment at the fourth quarter of each year, or more frequently if indicators of potential impairment exist, to determine if any events or circumstances exist, such as an adverse change in business climate or a decline in the overall industry that would indicate that it would  more likely than not reduce the fair value of a reporting unit below its carrying amount, including goodwill. If it is determined in the qualitative assessment that the fair value of a reporting unit is more likely than not below its carrying amount, including goodwill, then the Company performs a quantitative two-step impairment test. The first step, identifying a potential impairment, compares the fair value of a reporting unit with its carrying amount, including goodwill. If the carrying value of the reporting unit exceeds its fair value, the second step would need to be conducted. The second step, measuring the impairment loss, compares the implied fair value of the reporting unit goodwill with the carrying amount of that goodwill. Any excess of the reporting unit goodwill carrying value over its implied fair value is recognized as an impairment loss.

[0001047469-15-006787:notes:175]
The Company tests other long-lived assets, including property, equipment and leasehold improvements and other intangible assets subject to amortization, for recoverability whenever events or changes in circumstances indicate that the carrying value of those assets may not be recoverable. The Company performs a recoverability test to assess the recoverability of an asset group. If the recoverability test indicates that the carrying value of the asset group is not recoverable, the Company will estimate the fair value of the asset group and the excess of the carrying value over the fair value is allocated pro rata to derive the adjusted carrying value of assets in the asset group. The adjusted carrying value of each asset in the asset group is not reduced below its fair value.

[0001047469-15-006787:notes:176]
The Company tests other intangible assets not subject to amortization whenever events occur or circumstances change, such as declining financial performance, deterioration in the environment in which the entity operates or deteriorating macroeconomic conditions that have a negative effect on future expected earnings and cash flows that could affect significant inputs used to determine the fair value of the indefinite-lived intangible asset.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001047469-15-006787:notes:177]
Income Taxes

[0001047469-15-006787:notes:178]
The provision for (benefit from) income taxes consisted of the following:

[0001047469-15-006787:notes:179]
|  | Fiscal Years Ended |
| (Dollars in millions) | July 3, 2015 |  | June 27, 2014 |  | June 28, 2013 |
| Current income tax expense (benefit): |  |  |  |  |  |
| U.S. Federal | $ | — |  |  | $ | (12 | ) |  | $ | 3 |  |
| U.S. State | 4 |  |  | 3 |  |  | 10 |  |
| Non-U.S. | 222 |  |  | 62 |  |  | 50 |  |
| Total Current | 226 |  |  | 53 |  |  | 63 |  |
| Deferred income tax expense (benefit): |  |  |  |  |  |
| U.S. Federal | (6 | ) |  | (43 | ) |  | (49 | ) |
| U.S. State | (2 | ) |  | 2 |  |  | (1 | ) |
| Non-U.S. | 10 |  |  | (26 | ) |  | (20 | ) |
| Total Deferred | 2 |  |  | (67 | ) |  | (70 | ) |
| Provision for (benefit from) income taxes | $ | 228 |  |  | $ | (14 | ) |  | $ | (7 | ) |

[0001047469-15-006787:notes:180]
Income before income taxes consisted of the following:

[0001047469-15-006787:notes:181]
|  | Fiscal Years Ended |
| (Dollars in millions) | July 3, 2015 |  | June 27, 2014 |  | June 28, 2013 |
| U.S. | $ | 101 |  |  | $ | 149 |  |  | $ | 175 |  |
| Non-U.S | 1,869 |  |  | 1,407 |  |  | 1,656 |  |
|  | $ | 1,970 |  |  | $ | 1,556 |  |  | $ | 1,831 |  |

[0001047469-15-006787:notes:182]
The Company recorded $2 million, $0.3 million and $1 million of excess tax benefits associated with stock option deductions in fiscal years 2015, 2014 and 2013, respectively.

[0001047469-15-006787:notes:183]
Deferred income taxes reflect the net tax effects of temporary differences between the carrying amounts of assets and liabilities for financial reporting purposes and the amounts used for income tax purposes. The significant components of the Company's deferred tax assets and liabilities were as follows:

[0001047469-15-006787:notes:184]
|  | Fiscal Years Ended |
| (Dollars in millions) | July 3, 2015 |  | June 27, 2014 |
| Deferred tax assets |  |  |  |
| Accrued warranty | $ | 88 |  |  | $ | 99 |  |
| Inventory carrying value adjustments | 43 |  |  | 49 |  |
| Receivable allowance | 16 |  |  | 15 |  |
| Accrued compensation and benefits | 106 |  |  | 103 |  |
| Depreciation | 171 |  |  | 140 |  |
| Restructuring accruals | 4 |  |  | 4 |  |
| Other accruals and deferred items | 31 |  |  | 39 |  |
| Net operating losses and tax credit carry-forwards | 1,099 |  |  | 1,081 |  |
| Other assets | 5 |  |  | 8 |  |
| Total deferred tax assets | 1,563 |  |  | 1,538 |  |
| Valuation allowance | (929 | ) |  | (888 | ) |
| Net deferred tax assets | 634 |  |  | 650 |  |
| Deferred tax liabilities |  |  |  |
| Unremitted earnings of certain non-U.S. entities | (6 | ) |  | (14 | ) |
| Acquisition-related items | (15 | ) |  | (19 | ) |
| Other liabilities | (1 | ) |  | (2 | ) |
| Total deferred tax liabilities | (22 | ) |  | (35 | ) |
| Total net deferred tax assets | $ | 612 |  |  | $ | 615 |  |
| As Reported on the Balance Sheet |  |  |  |  |  |
| Current assets—deferred income taxes | $ | 122 |  |  | $ | 126 |  |
| Non-current assets—deferred income taxes | 496 |  |  | 499 |  |
| Other non-current liabilities | (6 | ) |  | (10 | ) |
| Total net deferred income taxes | $ | 612 |  |  | $ | 615 |  |

[0001047469-15-006787:notes:185]
The deferred tax asset valuation allowance increased by $41 million in 2015, and decreased by $101 million and $75 million, in fiscal years 2014 and 2013, respectively.

[0001047469-15-006787:notes:186]
At July 3, 2015, the Company recorded $612 million of net deferred tax assets. The realization of these deferred tax assets is primarily dependent on the Company's ability to generate sufficient U.S. taxable income in future periods. Although realization is not assured, the Company's management believes it is more likely than not that these deferred tax assets will be realized. The amount of deferred tax assets considered realizable, however, may increase or decrease in subsequent periods when the Company reevaluates the underlying basis for its estimates of future U.S. and certain non-U.S. taxable income.

[0001047469-15-006787:notes:187]
At July 3, 2015, the Company had U.S. federal, state and non-U.S. tax net operating loss carryforwards of approximately $3.1 billion, $1.8 billion and $133.3 million, respectively which will expire at various dates beginning in fiscal year 2016, if not utilized.  U.S. state net operating loss carryforwards of approximately $25 million are scheduled to expire in fiscal year 2016. At July 3, 2015, the Company had U.S. federal and state tax credit carryforwards of $387 million and $89 million, respectively, which will expire at various dates beginning in fiscal year 2016, if not utilized.

[0001047469-15-006787:notes:188]
As of July 3, 2015, approximately $422 million and $90 million of the Company's total U.S. net operating loss and tax credit carryforwards, respectively, are subject to an aggregate annual limitation of $46 million pursuant to U.S. tax law.

[0001047469-15-006787:notes:189]
For purposes of the reconciliation between the provision for (benefit from) income taxes at the statutory rate and the effective tax rate, the Irish statutory rate of 25% was applied as follows:

[0001047469-15-006787:notes:190]
|  | Fiscal Years Ended |
| (Dollars in millions) | July 3, 2015 |  | June 27, 2014 |  | June 28, 2013 |
| Provision at statutory rate | $ | 493 |  |  | $ | 389 |  |  | $ | 458 |  |
| Net U.S. federal and state income taxes | 7 |  |  | 3 |  |  | 12 |  |
| Permanent differences | 2 |  |  | 3 |  |  | 3 |  |
| Valuation allowance | 15 |  |  | (100 | ) |  | (97 | ) |
| Non-U.S. losses with no tax benefits | 2 |  |  | 8 |  |  | 27 |  |
| Non-U.S. earnings taxed at less than statutory rate | (463 | ) |  | (313 | ) |  | (414 | ) |
| Audit assessment | 173 |  |  | — |  |  | — |  |
| Other individually immaterial items | (1 | ) |  | (4 | ) |  | 4 |  |
| Provision for (benefit from) income taxes | $ | 228 |  |  | $ | (14 | ) |  | $ | (7 | ) |

[0001047469-15-006787:notes:191]
A substantial portion of the Company's operations in Malaysia, Singapore, and Thailand operate under various tax holiday programs, which expire in whole or in part at various dates through 2022. Certain of the tax holidays may be extended if specific conditions are met. The net impact of these tax holiday programs was to increase the Company's net income by approximately $349 million in fiscal year 2015 ($1.05 per share, diluted), to increase the Company's net income by approximately $289 million in fiscal year 2014 ($0.83 per share, diluted), and to increase the Company's net income by $338 million in fiscal year 2013 ($0.89 per share, diluted).

[0001047469-15-006787:notes:192]
The Company consists of an Irish tax resident parent holding company with various U.S. and non-U.S. subsidiaries that operate in multiple non-Irish taxing jurisdictions. The amount of temporary differences (including undistributed earnings) related to outside basis differences in the stock of non-Irish resident subsidiaries considered indefinitely reinvested outside of Ireland for which Irish income taxes have not been provided as of July 3, 2015, was approximately $3 billion. If such amount were remitted to Ireland as a dividend, it is likely that tax at 25% or approximately $750 million would result.

[0001047469-15-006787:notes:193]
As of July 3, 2015 and June 27, 2014, the Company had approximately $83 million and $115 million, respectively, of unrecognized tax benefits excluding interest and penalties. The amount of unrecognized tax benefits, if recognized, that would impact the effective tax rate is $83 million and $115 million as of July 3, 2015 and June 27, 2014, respectively, subject to certain future valuation allowance offsets.

[0001047469-15-006787:notes:194]
The following table summarizes the activity related to the Company's gross unrecognized tax benefits:

[0001047469-15-006787:notes:195]
|  | Fiscal Years Ended |
| (Dollars in millions) | July 3, 2015 |  | June 27, 2014 |  | June 28, 2013 |
| Balance of unrecognized tax benefits at the beginning of the year | $ | 115 |  |  | $ | 157 |  |  | $ | 135 |  |
| Gross increase for tax positions of prior years | 12 |  |  | 10 |  |  | 14 |  |
| Gross decrease for tax positions of prior years | (4 | ) |  | (64 | ) |  | (4 | ) |
| Gross increase for tax positions of current year | 9 |  |  | 13 |  |  | 16 |  |
| Gross decrease for tax positions of current year | — |  |  | — |  |  | — |  |
| Settlements | (45 | ) |  | — |  |  | — |  |
| Lapse of statutes of limitation | (3 | ) |  | (3 | ) |  | (5 | ) |
| Non-U.S. exchange (gain)/loss | (1 | ) |  | 2 |  |  | 1 |  |
| Balance of unrecognized tax benefits at the end of the year | $ | 83 |  |  | $ | 115 |  |  | $ | 157 |  |

[0001047469-15-006787:notes:196]
It is the Company's policy to include interest and penalties related to unrecognized tax benefits in the provision for income taxes on the Consolidated Statements of Operations. During fiscal year 2015, the Company recognized net income tax expense for interest and penalties of $26 million, $8 million during fiscal year 2014 and $2 million during fiscal year 2013. As of July 3, 2015, the Company had $20 million of accrued interest and penalties related to unrecognized tax benefits compared to $27 million in fiscal year 2014.

[0001047469-15-006787:notes:197]
During the 12 months beginning July 4, 2015, the Company expects that its unrecognized tax benefits could be reduced by approximately $11 million as a result of the expiration of certain statutes of limitation.

[0001047469-15-006787:notes:198]
The Company is subject to taxation in many jurisdictions globally and is required to file U.S. federal, U.S. state and non-U.S. income tax returns. In June 2014, the Company received the Revenue Agent’s Report and Notices of Proposed Adjustments for its U.S. federal income tax returns for fiscal years 2008, 2009 and 2010. The Company is currently contesting certain of these proposed adjustments through the IRS Appeals Office. The Company believes that the resolution of these disputed issues will not have a material impact on its financial statements. On December 31, 2014, the Company received the final audit assessment from the Jiangsu Province State Tax Bureau of the People’s Republic of China. The Company recognized $193 million of income tax expense and made payments of $225 million related to tax and interest associated with changes to the Company’s tax filings in China from calendar years 2007 through 2013.

[0001047469-15-006787:notes:199]
The Company is no longer subject to tax examination of U.S. federal income tax returns for years prior to fiscal year 2008. With respect to U.S. state and non-U.S. income tax returns, the Company is generally no longer subject to tax examination for years ending prior to fiscal year 2005.


## us-gaap:IncomeTaxPolicyTextBlock

[0001047469-15-006787:notes:200]
Accounting for Income Taxes. The Company accounts for income taxes pursuant to ASC Topic 740 (ASC 740), Income Taxes.  In applying ASC 740, the Company makes certain estimates and judgments in determining income tax expense for financial statement purposes.  These estimates and judgments occur in the calculation of tax credits, recognition of income and deductions and calculation of specific tax assets and liabilities, which arise from differences in the timing of recognition of revenue and expense for income tax and financial statement purposes, as well as tax liabilities associated with uncertain tax positions. The calculation of tax liabilities involves uncertainties in the application of complex tax rules and the potential for future adjustment of the Company’s uncertain tax positions by the Internal Revenue Service or other tax jurisdictions. If estimates of these tax liabilities are greater or less than actual results, an additional tax benefit or provision will result. The deferred tax assets the Company records each period depend primarily on the Company’s ability to generate future taxable income in the United States and certain non-U.S. jurisdictions. Each period, the Company evaluates the need for a valuation allowance for its deferred tax assets and, if necessary, adjusts the valuation allowance so that net deferred tax assets are recorded only to the extent the Company concludes it is more likely than not that these deferred tax assets will be realized. If the Company’s outlook for future taxable income changes significantly, the Company’s assessment of the need for, and the amount of, a valuation allowance may also change.


## us-gaap:InventoryPolicyTextBlock

[0001047469-15-006787:notes:201]
Inventory.    Inventories are valued at the lower of cost (using the first-in, first-out method) or market. Market value is based upon an estimated average selling price reduced by estimated cost of completion and disposal.


## us-gaap:InvestmentsClassifiedByContractualMaturityDateTableTextBlock

[0001047469-15-006787:notes:202]
| (Dollars in millions) |  | AmortizedCost |  | FairValue |
| Due in less than 1 year |  | $ | 2,070 |  |  | $ | 2,070 |  |
| Due in 1 to 5 years |  | 6 |  |  | 6 |  |
| Due in 5 to 10 years |  | — |  |  | — |  |
| Thereafter |  | — |  |  | — |  |
| Total |  | $ | 2,076 |  |  | $ | 2,076 |  |


## us-gaap:LegalMattersAndContingenciesTextBlock

[0001047469-15-006787:notes:203]
Legal, Environmental and Other Contingencies

[0001047469-15-006787:notes:204]
The Company assesses the probability of an unfavorable outcome of all its material litigation, claims, or assessments to determine whether a liability had been incurred and whether it is probable that one or more future events will occur confirming the fact of the loss.  In the event that an unfavorable outcome is determined to be probable and the amount of the loss can be reasonably estimated, the Company establishes an accrual for the litigation, claim or assessment.  In addition, in the event an unfavorable outcome is determined to be less than probable, but reasonably possible, the Company will disclose an estimate of the possible loss or range of such loss; however, when a reasonable estimate cannot be made, the Company will provide disclosure to that effect.  Litigation is inherently uncertain and may result in adverse rulings or decisions.  Additionally, the Company may enter into settlements or be subject to judgments that may, individually or in the aggregate, have a material adverse effect on its results of operations. Accordingly, actual results could differ materially.

[0001047469-15-006787:notes:205]
Intellectual Property Litigation

[0001047469-15-006787:notes:206]
Convolve, Inc. (“Convolve”) and Massachusetts Institute of Technology (“MIT”) v. Seagate Technology LLC, et al.—On July 13, 2000, Convolve and MIT filed suit against Compaq Computer Corporation and Seagate Technology LLC in the U.S. District Court for the Southern District of New York, alleging infringement of U.S. Patent Nos. 4,916,635 (the “'635 patent”) and U.S. Patent No. 5,638,267 (the “'267 patent”), misappropriation of trade secrets, breach of contract, and other claims.  In the complaint, the plaintiffs requested injunctive relief, $800 million in compensatory damages and unspecified punitive damages, including for willful infringement.  On January 16, 2002, Convolve filed an amended complaint, alleging defendants infringe US Patent No. 6,314,473 (the “'473 patent”).  The district court ruled in 2010 that the '267 patent was out of the case.

[0001047469-15-006787:notes:207]
On August 16, 2011, the district court granted in part and denied in part the Company's motion for summary judgment.  On July 1, 2013, the U.S. Court of Appeals for the Federal Circuit: 1) affirmed the district court's summary judgment rulings that Seagate did not misappropriate any of the alleged trade secrets and that the asserted claims of the '635 patent are invalid; 2) reversed and vacated the district court's summary judgment of non-infringement with respect to the '473 patent; and 3) remanded the case for further proceedings on the '473 patent.  On July 11, 2014, the district court granted the Company’s summary judgment motion regarding Convolve’s only remaining cause of action, which alleged infringement of the ‘473 patent. The court entered judgment in favor of the Company on July 14, 2014. Convolve filed a notice of appeal on August 13, 2014. The court of appeals has not yet set a date for oral argument. In view of the rulings made by the district court and the Court of Appeals and the uncertainty regarding the amount of damages, if any, that could be awarded Convolve in this matter, the Company does not believe that it is currently possible to determine a reasonable estimate of the possible range of loss related to this matter.

[0001047469-15-006787:notes:208]
Alexander Shukh v. Seagate Technology—On February 12, 2010, Alexander Shukh filed a complaint against the Company in the U.S. District Court for the District of Minnesota, alleging, among other things, employment discrimination based on his Belarusian national origin and wrongful failure to name him as an inventor on several patents and patent applications. Mr. Shukh's employment was terminated as part of a company-wide reduction in force in fiscal year 2009. He seeks damages in excess of $75 million. On March 31, 2014, the district court granted Seagate’s summary judgment motion and entered judgment in favor of Seagate.  Mr. Shukh filed a notice of appeal on April 7, 2014. Oral argument at the court of appeals was held on June 4, 2015; the court has not yet issued its decision. In view of the uncertainty regarding the amount of damages, if any, that could be awarded in this matter, the Company does not believe that it is currently possible to determine a reasonable estimate of the possible range of loss related to this matter.

[0001047469-15-006787:notes:209]
LEAP Co., Ltd. v. Seagate Singapore International Headquarters Pte. Ltd. and Nippon Seagate Inc.—On July 4, 2012, LEAP Co., Ltd. filed a lawsuit in the Tokyo District Court of Japan against Seagate Singapore International Headquarters Pte. Ltd., Nippon Seagate Inc. and Buffalo Inc. alleging wrongful termination of purchase agreements and other claims, and seeking approximately $38 million in damages.  A date for the start of trial has not yet been scheduled.  The Company believes the claims are without merit and intends to vigorously defend this case. In view of the uncertainty regarding the amount of damages, if any, that could be awarded in this matter, the Company does not believe that it is currently possible to determine a reasonable estimate of the possible range of loss related to this matter.

[0001047469-15-006787:notes:210]
Enova Technology Corporation v. Seagate Technology (US) Holdings, Inc., et al.-On June 5, 2013, Enova Technology Corporation filed a complaint against Seagate Technology (US) Holdings, Inc. and Seagate Technology LLC in the U.S. District Court for the District of Delaware alleging infringement of U.S. Patent No. 7,136,995, “Cryptographic Device,” and U.S. Patent No. 7,900,057, “Cryptographic Serial ATA Apparatus and Method.”  The complaint seeks unspecified compensatory damages, enhanced damages, injunctive relief, attorneys' fees, and other relief.  The trial is scheduled to begin July 11, 2016.  On April 27, 2015, the district court ordered a stay of the case until October 15, 2015, in view of proceedings regarding the '995 and '057 Patents before the Patent Trial and Appeal Board of the U.S. Patent and Trademark Office. The Company believes the claims are without merit and intends to vigorously defend this case.  In view of the uncertainty regarding the amount of damages, if any, that could be awarded in this matter, the Company does not believe that it is currently possible to determine a reasonable estimate of the possible range of loss related to this matter.

[0001047469-15-006787:notes:211]
Seagate Technology LLC v. Western Digital Corp.  On October 8, 2014, the Minnesota Supreme Court ruled that the arbitration award in favor of the Company in its case against Western Digital for the misappropriation of the Company’s trade secrets should be confirmed. In the arbitration award, issued on January 23, 2012, the arbitrator determined that Western Digital and its former employee had misappropriated the Company’s trade secrets. The arbitrator awarded the Company $525 million in compensatory damages and, after adding interest, issued a final award of $630 million. Interest on the final award has been accruing at 10%. On October 14, 2014, the Company received a partial payment from Western Digital in the amount of $773 million. The amount of the final award, less litigation and other related costs, has been recorded by the Company in Gain on arbitration award, net, and the remaining amount received has been recorded in Other, net.

[0001047469-15-006787:notes:212]
Environmental Matters

[0001047469-15-006787:notes:213]
The Company's operations are subject to U.S. and foreign laws and regulations relating to the protection of the environment, including those governing discharges of pollutants into the air and water, the management and disposal of hazardous substances and wastes and the cleanup of contaminated sites.  Some of the Company's operations require environmental permits and controls to prevent and reduce air and water pollution, and these permits are subject to modification, renewal and revocation by issuing authorities.

[0001047469-15-006787:notes:214]
The Company has established environmental management systems and continually updates its environmental policies and standard operating procedures for its operations worldwide.  The Company believes that its operations are in material compliance with applicable environmental laws, regulations and permits.  The Company budgets for operating and capital costs on an ongoing basis to comply with environmental laws.  If additional or more stringent requirements are imposed on the Company in the future, it could incur additional operating costs and capital expenditures.

[0001047469-15-006787:notes:215]
Some environmental laws, such as the Comprehensive Environmental Response Compensation and Liability Act of 1980 (as amended, the “Superfund” law) and its state equivalents, can impose liability for the cost of cleanup of contaminated sites upon any of the current or former site owners or operators or upon parties who sent waste to these sites, regardless of whether the owner or operator owned the site at the time of the release of hazardous substances or the lawfulness of the original disposal activity.  The Company has been identified as a potentially responsible party at several sites.  At each of these sites, the Company has an assigned portion of the financial liability based on the type and amount of hazardous substances disposed of by each party at the site and the number of financially viable parties.  The Company has fulfilled its responsibilities at some of these sites and remains involved in only a few at this time.

[0001047469-15-006787:notes:216]
While the Company's ultimate costs in connection with these sites is difficult to predict with complete accuracy, based on its current estimates of cleanup costs and its expected allocation of these costs, the Company does not expect costs in connection with these sites to be material.

[0001047469-15-006787:notes:217]
The Company may be subject to various state, federal and international laws and regulations governing the environment, including those restricting the presence of certain substances in electronic products.  For example, the European Union (“EU”) enacted the Restriction of the Use of Certain Hazardous Substances in Electrical and Electronic Equipment, which prohibits the use of certain substances, including lead, in certain products, including disk drives and server storage products, put on the market after July 1, 2006.  Similar legislation has been or may be enacted in other jurisdictions, including in the United States, Canada, Mexico, Taiwan, China, Japan and others.  The European Union REACH Directive (Registration, Evaluation, Authorization, and Restriction of Chemicals, EC 1907/2006) also restricts substances of very high concern (“SVHCs”) in products.  If the Company or its suppliers fails to comply with the substance restrictions, recycle requirements or other environmental requirements as they are enacted worldwide, it could have a materially adverse effect on the Company's business.

[0001047469-15-006787:notes:218]
Other Matters

[0001047469-15-006787:notes:219]
The Company is involved in a number of other judicial and administrative proceedings incidental to its business, and the Company may be involved in various legal proceedings arising in the normal course of its business in the future.  Although occasional adverse decisions or settlements may occur, the Company believes that the final disposition of such matters will not have a material adverse effect on its financial position or results of operations.


## us-gaap:NewAccountingPronouncementsPolicyPolicyTextBlock

[0001047469-15-006787:notes:220]
Recent Accounting Pronouncements

[0001047469-15-006787:notes:221]
In May 2014, the FASB issued ASU 2014-09 (ASC Topic 606), Revenue from Contracts with Customers. The ASU outlines a single comprehensive model for entities to use in accounting for revenue arising from contracts with customers and supersedes most current revenue recognition guidance, including industry-specific guidance. It also requires entities to disclose both quantitative and qualitative information that enable financial statements users to understand the nature, amount, timing, and uncertainty of revenue and cash flows arising from contracts with customers. The amendments in this ASU are effective for fiscal years, and interim periods within those years, beginning after December 15, 2017. Early adoption is permitted for annual periods beginning after December 15, 2016. The Company is in the process of assessing the impact, if any, on its consolidated financial statements.

[0001047469-15-006787:notes:222]
In April 2015, the FASB issued ASU 2015-03 (ASC Subtopic 835-30), Interest-Imputation of Interest: Simplifying the Presentation of Debt Issuance Costs. The amendments in this ASU require that debt issuance costs related to a recognized debt liability be presented in the balance sheet as a direct deduction from the carrying amount of that debt liability. The amendments in this ASU are effective for fiscal years, and interim periods within those years, beginning after December 15, 2015. Early adoption is permitted for financial statements that have not been previously issued. The adoption of this new guidance will not have a material impact on the Company’s consolidated financial statements and disclosures.

[0001047469-15-006787:notes:223]
In July 2015, the FASB issued ASU 2015-11 (ASC Topic 330), Inventory: Simplifying the Measurement of Inventory. The amendments in this ASU require inventory measurement at the lower of cost and net realizable value. The amendments in this ASU are effective for fiscal years beginning after December 15, 2016, including interim periods within those fiscal years. Earlier application is permitted by all entities as of the beginning of an interim or annual reporting period. The Company is in the process of assessing the impact, if any, on its consolidated financial statements.


## us-gaap:OrganizationConsolidationBasisOfPresentationBusinessDescriptionAndAccountingPoliciesTextBlock

[0001047469-15-006787:notes:224]
Basis of Presentation and Summary of Significant Accounting Policies

[0001047469-15-006787:notes:225]
Organization

[0001047469-15-006787:notes:226]
Seagate Technology plc (the "Company") is a leading provider of electronic data storage technology and solutions.  Its principal products are hard disk drives, commonly referred to as disk drives, hard drives or HDDs. In addition to HDDs, it produces a broad range of electronic data storage products including solid state hybrid drives ("SSHD"), solid state drives ("SSD"), PCIe cards and SATA controllers. Its storage technology portfolio also includes storage subsystems, high performance computing (HPC) solutions, and data storage services.

[0001047469-15-006787:notes:227]
Hard disk drives are devices that store digitally encoded data on rapidly rotating disks with magnetic surfaces. Disk drives continue to be the primary medium of mass data storage due to their performance attributes, high quality and cost effectiveness. Complementing existing data center storage architecture, solid-state storage devices use integrated circuit assemblies as memory to store data, and most SSDs use NAND-based flash memory.  In addition to HDDs and SSDs, Solid-state hybrid drives (SSHDs) combine the features of SSDs and HDDs in the same unit, containing a large hard disk drive and an SSD cache to improve performance of frequently accessed data.

[0001047469-15-006787:notes:228]
The Company's products are designed for enterprise servers and storage systems in mission critical and nearline applications; client compute applications, where its products are designed primarily for desktop and mobile computing; and client non-compute applications, where its products are designed for a wide variety of end user devices such as digital video recorders ("DVRs"), personal data backup systems, portable external storage systems, digital media systems and surveillance systems.

[0001047469-15-006787:notes:229]
The Company's product and solution portfolio for the enterprise data storage industry includes storage enclosures, integrated application platforms and high performance computing ("HPC") data storage solutions. Its storage subsystems support a range of high-speed interconnect technologies to meet demanding cost and performance specifications. Its modular subsystem architecture allows it to support many segments within the networked storage market by enabling different specifications of storage subsystem designs to be created from a standard set of interlocking technology modules.

[0001047469-15-006787:notes:230]
The Company's data storage services provide online backup, data protection and recovery solutions for small to medium-sized businesses.

[0001047469-15-006787:notes:231]
Restricted Cash and Investments.    Restricted cash and investments represent cash and cash equivalents and investments that are restricted as to withdrawal or use for other than current operations.

[0001047469-15-006787:notes:232]
Allowances for Doubtful Accounts.    The Company maintains an allowance for uncollectible accounts receivable based upon expected collectability. This reserve is established based upon historical trends, global macroeconomic conditions and an analysis of specific exposures. The provision for doubtful accounts is recorded as a charge to Marketing and administrative expense.

[0001047469-15-006787:notes:233]
Property, Equipment and Leasehold Improvements.    Property, equipment and leasehold improvements are stated at cost. Equipment and buildings are depreciated using the straight-line method over the estimated useful lives of the assets. Leasehold improvements are amortized using the straight-line method over the shorter of the estimated life of the asset or the remaining term of the lease. The costs of additions and substantial improvements to property, equipment and leasehold improvements, which extend the economic life of the underlying assets, are capitalized. The cost of maintenance and repairs to property, equipment and leasehold improvements are expensed as incurred.

[0001047469-15-006787:notes:234]
Establishment of Warranty Accruals.    The Company estimates probable product warranty costs at the time revenue is recognized. The Company generally warrants its products for a period of 1 to 5 years. The Company's warranty provision considers estimated product failure rates and trends (including the timing of product returns during the warranty periods), and estimated repair or replacement costs related to product quality issues, if any. The Company also exercises judgment in estimating its ability to sell certain repaired products. Should actual experience in any future period differ significantly from its estimates, the Company's future results of operations could be materially affected.

[0001047469-15-006787:notes:235]
Revenue Recognition, Sales Returns and Allowances, and Sales Incentive Programs.    The Company's revenue recognition policy complies with ASC Topic 605 (ASC 605), Revenue Recognition. Revenue from sales of products, including sales to distribution customers, is generally recognized when title and risk of loss has passed to the buyer, which typically occurs upon shipment from the Company or third party warehouse facilities, persuasive evidence of an arrangement exists, including a fixed or determinable price to the buyer, and when collectability is reasonably assured. Revenue from sales of products to certain direct retail customers and to customers in certain indirect retail channels is recognized on a sell-through basis.

[0001047469-15-006787:notes:236]
The Company records estimated product returns at the time of shipment.  The Company also estimates reductions to revenue for sales incentive programs, such as price protection, and volume incentives, and records such reductions when revenue is recorded. The Company establishes certain distributor and OEM sales programs aimed at increasing customer demand. For OEM sales, rebates are typically based on an OEM customer's volume of purchases from Seagate or other agreed upon rebate programs. For the distribution channel, these programs typically involve rebates related to a distributor's level of sales, order size, advertising or point of sale activity and price protection adjustments. The Company provides for these obligations at the time that revenue is recorded based on estimated requirements. Marketing development programs are recorded as a reduction to revenue.

[0001047469-15-006787:notes:237]
Shipping and Handling.    The Company includes costs related to shipping and handling in Cost of revenue for all periods presented.

[0001047469-15-006787:notes:238]
Concentrations

[0001047469-15-006787:notes:239]
Concentration of Credit Risk.    The Company's customer base for disk drive products is concentrated with a small number of OEMs and distributors. The Company does not generally require collateral or other security to support accounts receivable. To reduce credit risk, the Company performs ongoing credit evaluations on its customers' financial condition. The Company establishes an allowance for doubtful accounts based upon factors surrounding the credit risk of customers, historical trends and other information. Hewlett-Packard Company and Dell Inc. each accounted for more than 10% of the Company's accounts receivable as of July 3, 2015.

[0001047469-15-006787:notes:240]
Financial instruments that potentially subject the Company to concentrations of credit risk consist primarily of cash equivalents, short-term investments and foreign currency forward exchange contracts. The Company further mitigates concentrations of credit risk in its investments through diversification, by limiting its investments in the debt securities of a single issuer, and investing in highly rated securities.

[0001047469-15-006787:notes:241]
In entering into foreign currency forward exchange contracts, the Company assumes the risk that might arise from the possible inability of counterparties to meet the terms of their contracts. The counterparties to these contracts are major multinational commercial banks, and the Company has not incurred and does not expect any losses as a result of counterparty defaults.

[0001047469-15-006787:notes:242]
Supplier Concentration.    Certain of the raw materials, components and equipment used by the Company in the manufacture of its products are available from a sole supplier or a limited number of suppliers. Shortages could occur in these essential materials and components due to an interruption of supply or increased demand in the industry. If the Company were unable to procure certain materials, components or equipment at acceptable prices, it would be required to reduce its manufacturing operations, which could have a material adverse effect on its results of operations. In addition, the Company has made prepayments to certain suppliers. Should these suppliers be unable to deliver on their obligations or experience financial difficulty, the Company may not be able to recover these prepayments.


## us-gaap:ProductWarrantyDisclosureTextBlock

[0001047469-15-006787:notes:243]
Guarantees

[0001047469-15-006787:notes:244]
Indemnifications to Officers and Directors

[0001047469-15-006787:notes:245]
On May 4, 2009,  Seagate Technology, an exempted company incorporated with limited liability under the laws of the Cayman Islands (“Seagate-Cayman”), then the parent company, entered into a new form of indemnification agreement (the “Revised Indemnification Agreement”) with its officers and directors of Seagate-Cayman and its subsidiaries (each, an “Indemnitee”). The Revised Indemnification Agreement provides indemnification in addition to any of Indemnitee's indemnification rights under Seagate-Cayman's Articles of Association, applicable law or otherwise, and indemnifies an Indemnitee for certain expenses (including attorneys' fees), judgments, fines and settlement amounts actually and reasonably incurred by him or her in any action or proceeding, including any action by or in the right of Seagate-Cayman or any of its subsidiaries, arising out of his or her service as a director, officer, employee or agent of Seagate-Cayman or any of its subsidiaries or of any other entity to which he or she provides services at Seagate-Caymans's request. However, an Indemnitee shall not be indemnified under the Revised Indemnification Agreement for (i) any fraud or dishonesty in the performance of Indemnitee's duty to Seagate-Cayman or the applicable subsidiary of Seagate-Cayman or (ii) Indemnitee's conscious, intentional or willful failure to act honestly, lawfully and in good faith with a view to the best interests of Seagate-Cayman or the applicable subsidiary of Seagate-Cayman. In addition, the Revised Indemnification Agreement provides that Seagate-Cayman will advance expenses incurred by an Indemnitee in connection with enforcement of the Revised Indemnification Agreement or with the investigation, settlement or appeal of any action or proceeding against him or her as to which he or she could be indemnified.

[0001047469-15-006787:notes:246]
On July 3, 2010, pursuant to a corporate reorganization, the common shareholders of Seagate-Cayman became ordinary shareholders of Seagate Technology plc (the "Company") and Seagate-Cayman became a wholly owned subsidiary of the Company, as described more fully in the Current Report on Form 8-K filed by the Company on July 6, 2010 (the “Redomestication”). On July 27, 2010, in connection with the Redomestication, the Company, as sole shareholder of Seagate-Cayman, approved a form of deed of indemnity (the “Deed of Indemnity”), which provides for the indemnification by Seagate-Cayman of any director, officer, employee or agent of the Company, Seagate-Cayman or any subsidiary of the Company (each, a “Deed Indemnitee”), in addition to any of a Deed Indemnitee's indemnification rights under the Company's Articles of Association, applicable law or otherwise, with a similar scope to the Revised Indemnification Agreement. Seagate-Cayman entered into the Deed of Indemnity with certain Deed Indemnitees effective as of July 3, 2010 and continues to enter into the Deed of Indemnity with additional Deed Indemnitees from time to time.

[0001047469-15-006787:notes:247]
The nature of these indemnification obligations prevents the Company from making a reasonable estimate of the maximum potential amount it could be required to pay on behalf of its officers and directors. Historically, the Company has not made any significant indemnification payments under such agreements and no amount has been accrued in the accompanying consolidated financial statements with respect to these indemnification obligations.

[0001047469-15-006787:notes:248]
Intellectual Property Indemnification Obligations

[0001047469-15-006787:notes:249]
The Company has entered into agreements with customers and suppliers that include limited intellectual property indemnification obligations that are customary in the industry. These guarantees generally require the Company to compensate the other party for certain damages and costs incurred as a result of third party intellectual property claims arising from these transactions. The nature of the intellectual property indemnification obligations prevents the Company from making a reasonable estimate of the maximum potential amount it could be required to pay to its customers and suppliers. Historically, the Company has not made any significant indemnification payments under such agreements and no amount has been accrued in the accompanying consolidated financial statements with respect to these indemnification obligations.

[0001047469-15-006787:notes:250]
Product Warranty

[0001047469-15-006787:notes:251]
The Company estimates probable product warranty costs at the time revenue is recognized. The Company generally warrants its products for a period of 1 to 5 years. The Company uses estimated repair or replacement costs and uses statistical modeling to estimate product return rates in order to determine its warranty obligation.  Changes in the Company's product warranty liability during the fiscal years ended July 3, 2015, June 27, 2014 and June 28, 2013 were as follows:

[0001047469-15-006787:notes:252]
|  |  | Fiscal Years Ended |
| (In millions) |  | July 3, 2015 |  | June 27, 2014 |  | June 28, 2013 |
| Balance, beginning of period |  | $ | 273 |  |  | $ | 320 |  |  | $ | 363 |  |
| Warranties issued |  | 147 |  |  | 177 |  |  | 193 |  |
| Repairs and replacements |  | (187 | ) |  | (228 | ) |  | (276 | ) |
| Changes in liability for pre-existing warranties, including expirations |  | 7 |  |  | 1 |  |  | 37 |  |
| Warranty liability assumed from acquisitions |  | 8 |  |  | 3 |  |  | 3 |  |
| Balance, end of period |  | $ | 248 |  |  | $ | 273 |  |  | $ | 320 |  |


## us-gaap:PropertyPlantAndEquipmentTextBlock

[0001047469-15-006787:notes:253]
| (Dollars in millions) |  | Useful Lifein Years |  | July 3, 2015 |  | June 27, 2014 |
| Land and land improvements |  |  |  | $ | 48 |  |  | $ | 45 |  |
| Equipment |  | 3 – 5 |  | 7,440 |  |  | 7,159 |  |
| Buildings and leasehold improvements |  | Up to 48 |  | 1,595 |  |  | 1,452 |  |
| Construction in progress |  |  |  | 547 |  |  | 323 |  |
|  |  |  |  | 9,630 |  |  | 8,979 |  |
| Less: accumulated depreciation and amortization |  |  |  | (7,352 | ) |  | (6,843 | ) |
|  |  |  |  | $ | 2,278 |  |  | $ | 2,136 |  |


## us-gaap:RelatedPartyTransactionsDisclosureTextBlock

[0001047469-15-006787:notes:254]
Related Party Transactions

[0001047469-15-006787:notes:255]
Samsung Electronics Co. Ltd. (“Samsung”) In connection with the Company's acquisition of the Samsung HDD business, Samsung became a shareholder of the Company and appointed one of its executives to the Company's Board of Directors. On October 22, 2013, Samsung filed an amendment to its Schedule 13D indicating that it holds less than 5% of the Company's outstanding shares. Dr. Seh-Woong Jeong was appointed to our Board of Directors by Samsung and joined our Board of Directors on April 26, 2012.  He retired from our Board of Directors on October 22, 2014. The Company recorded revenue of $216 million and $413 million from sales to Samsung for fiscal year 2014 and 2013, respectively.  The Company made payments to Samsung in fiscal years 2014 and 2013 of $318 million and $393 million, respectively, related to purchases of components and services.  The Company had accounts payable to Samsung of $34 million and $48 million at June 27, 2014 and June 28, 2013.  The Company had accounts receivable from Samsung of $25 million and $49 million at June 27, 2014 and June 28, 2013.

[0001047469-15-006787:notes:256]
Microsoft Corporation (“Microsoft”) During the years presented (through March 2014), the Company's Chairman and Chief Executive Officer also served on the board of Microsoft. The Company recorded revenue of $208 million and $141 million from sales to Microsoft for fiscal years 2014 and 2013, respectively. The Company made payments to Microsoft in fiscal years 2014 and 2013 of $1 million and $2 million, respectively, related to purchases of licensed software.  The Company had accounts receivable from Microsoft of $35 million and $33 million at June 27, 2014 and June 28, 2013.


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0001047469-15-006787:notes:257]
Restructuring and Exit Costs

[0001047469-15-006787:notes:258]
During fiscal year 2015 and 2014, the Company recorded restructuring charges of $32 million and $24 million, respectively, comprised primarily of charges related to employee termination costs associated with reductions in force during  each fiscal year. During fiscal year 2013, the Company recorded restructuring and other charges of  $2 million, mainly comprised of post-employment costs associated with a small restructuring plan.  The Company's significant restructuring plans are described below.  All restructuring charges are reported in Restructuring and other, net on the Consolidated Statements of Operations.

[0001047469-15-006787:notes:259]
2015 Plan.    During fiscal year 2015, the Company recorded employee termination costs of $25 million and made cash payments of $16 million associated with a reduction in the work force.

[0001047469-15-006787:notes:260]
Ang Mo Kio (AMK) Plan.    In August 2009, the Company announced that it will close its AMK manufacturing operations in Singapore.  Operations at this facility had ceased as of the third quarter of fiscal year 2011.  The hard drive manufacturing operations have been relocated to other existing Seagate facilities and the Company's Asia International Headquarters remains in Singapore.  This closure and relocation is part of the Company's ongoing focus on cost efficiencies in all areas of its business and is intended to facilitate leveraging manufacturing investments across fewer sites.  The Company currently estimates total restructuring charges of approximately $50 million, all in cash, including approximately $42 million for post-employment benefits, approximately $6 million for the relocation of manufacturing equipment, and approximately $2 million for other plant closure and relocation costs.  From the inception of the plan the Company has recorded $48 million in restructuring charges.  During fiscal year 2015, there were no cash payments or other settlements under the AMK Plan and no restructuring charges related to the plan during fiscal year 2015.  Payments under the AMK plan are expected to continue through fiscal year 2016.

[0001047469-15-006787:notes:261]
Other Restructuring and Exit Costs.    Through July 3, 2015, the Company has recorded other restructuring charges of approximately $126 million, net of adjustments, related to the previously announced closures of its Pittsburgh, Pennsylvania and Milpitas, California facilities, and also has recorded certain exit costs aggregating to $267 million related to its acquisition of Maxtor.  These plans are currently expected to result in total charges of approximately $400 million.  During fiscal year 2015, the Company incurred restructuring charges of $1 million in post-employment benefits and $2 million in other exit costs primarily related to the closures of its Pittsburgh, Pennsylvania and Milpitas, California facilities and to other smaller restructuring plans.  In addition, the Company recorded cash payments and other settlements of $9 million related to these plans during fiscal year 2015.  Restructuring activity relating to the Milpitas, California facility was completed during the fiscal year ended June 28, 2013.  Payment of these exit costs relating to the Pittsburgh, Pennsylvania facility and other smaller restructuring plans are expected to continue through the end of fiscal year 2023.

[0001047469-15-006787:notes:262]
The following table summarizes the Company's restructuring activities under all the Company’s active restructuring plans for fiscal years 2015,  2014 and  2013:

[0001047469-15-006787:notes:263]
| (Dollars in millions) |  | Post-EmploymentBenefits |  | OperatingLeases |  | OtherExitCosts |  | Total |
| All Restructuring Activities |  |  |  |  |  |  |  |  |
| Accrual balances at June 29, 2012 |  | $ | 3 |  |  | $ | 22 |  |  | $ | — |  |  | $ | 25 |  |
| Restructuring charges |  | 1 |  |  | 1 |  |  | 1 |  |  | 3 |  |
| Cash payments |  | (2 | ) |  | (7 | ) |  | (1 | ) |  | (10 | ) |
| Adjustments |  | — |  |  | (1 | ) |  | — |  |  | (1 | ) |
| Accrual balances at June 28, 2013 |  | 2 |  |  | 15 |  |  | — |  |  | 17 |  |
| Restructuring charges |  | 18 |  |  | 3 |  |  | 2 |  |  | 23 |  |
| Cash payments |  | (20 | ) |  | (5 | ) |  | (2 | ) |  | (27 | ) |
| Adjustments |  | 2 |  |  | (1 | ) |  | — |  |  | 1 |  |
| Accrual balances at June 27, 2014 |  | 2 |  |  | 12 |  |  | — |  |  | 14 |  |
| Restructuring charges |  | 23 |  |  | 3 |  |  | 4 |  |  | 30 |  |
| Cash payments |  | (17 | ) |  | (6 | ) |  | (4 | ) |  | (27 | ) |
| Adjustments |  | 3 |  |  | (1 | ) |  | — |  |  | 2 |  |
| Accrual balances at July 3, 2015 |  | $ | 11 |  |  | $ | 8 |  |  | $ | — |  |  | $ | 19 |  |

[0001047469-15-006787:notes:264]
Of the accrued restructuring balance of approximately $19 million at July 3, 2015, $15 million is included in Accrued expenses and $4 million is included in Other non-current liabilities in the Company's Consolidated Balance Sheet.  Of the accrued restructuring balance of approximately $14 million at June 27, 2014, $7 million is included in Accrued expenses and $7 million is included in Other non-current liabilities in the Company's Consolidated Balance Sheet.


## us-gaap:ScheduleOfAccountsNotesLoansAndFinancingReceivableTextBlock

[0001047469-15-006787:notes:265]
| (Dollars in millions) |  | July 3, 2015 |  | June 27, 2014 |
| Accounts receivable |  | $ | 1,744 |  |  | $ | 1,741 |  |
| Allowance for doubtful accounts |  | (9 | ) |  | (12 | ) |
|  |  | $ | 1,735 |  |  | $ | 1,729 |  |


## us-gaap:ScheduleOfAccumulatedOtherComprehensiveIncomeLossTableTextBlock

[0001047469-15-006787:notes:266]
| (Dollars in millions) |  | UnrealizedGains (Losses)on Cash FlowHedges |  | UnrealizedGains (Losses)on MarketableSecurities (a) |  | UnrealizedGains (Losses)on post-retirement plans |  | ForeignCurrencyTranslationAdjustments |  | Total |
| Balance at June 28, 2013 |  | $ | — |  |  | $ | (3 | ) |  | $ | (11 | ) |  | $ | 1 |  |  | $ | (13 | ) |
| Other comprehensive income (loss) before reclassifications |  | (1 | ) |  | 1 |  |  | 1 |  |  | 8 |  |  | 9 |  |
| Amounts reclassified from AOCI |  | — |  |  | 2 |  |  | — |  |  | — |  |  | 2 |  |
| Other comprehensive income (loss) |  | (1 | ) |  | 3 |  |  | 1 |  |  | 8 |  |  | 11 |  |
| Balance at June 27, 2014 |  | (1 | ) |  | — |  |  | (10 | ) |  | 9 |  |  | (2 | ) |
| Other comprehensive income (loss) before reclassifications |  | (11 | ) |  | — |  |  | (5 | ) |  | (25 | ) |  | (41 | ) |
| Amounts reclassified from AOCI |  | 13 |  |  | — |  |  | — |  |  | — |  |  | 13 |  |
| Other comprehensive income (loss) |  | 2 |  |  | — |  |  | (5 | ) |  | (25 | ) |  | (28 | ) |
| Balance at July 3, 2015 |  | $ | 1 |  |  | $ | — |  |  | $ | (15 | ) |  | $ | (16 | ) |  | $ | (30 | ) |

[0001047469-15-006787:notes:267]
___________________________________________

[0001047469-15-006787:notes:268]
| (a) | The cost of a security sold or the amount reclassified out of AOCI into earnings was determined using the specific identification method. |


## us-gaap:ScheduleOfInventoryCurrentTableTextBlock

[0001047469-15-006787:notes:269]
| (Dollars in millions) |  | July 3, 2015 |  | June 27, 2014 |
| Raw materials and components |  | $ | 352 |  |  | $ | 324 |  |
| Work-in-process |  | 239 |  |  | 267 |  |
| Finished goods |  | 402 |  |  | 394 |  |
|  |  | $ | 993 |  |  | $ | 985 |  |


## us-gaap:ScheduleOfOtherCurrentAssetsTableTextBlock

[0001047469-15-006787:notes:270]
| (Dollars in millions) |  | July 3, 2015 |  | June 27, 2014 |
| Vendor non-trade receivables |  | $ | 66 |  |  | $ | 112 |  |
| Other |  | 160 |  |  | 167 |  |
|  |  | $ | 226 |  |  | $ | 279 |  |


## us-gaap:ScheduleOfRevenuesFromExternalCustomersAndLongLivedAssetsByGeographicalAreasTableTextBlock

[0001047469-15-006787:notes:271]
|  |  | Fiscal Years Ended |
| (In millions) |  | July 3, 2015 |  | June 27, 2014 |  | June 28, 2013 |
| Revenue from external customers (a): |  |  |  |  |  |  |
| Singapore |  | $ | 6,844 |  |  | $ | 6,828 |  |  | $ | 7,429 |  |
| United States |  | 3,929 |  |  | 3,679 |  |  | 3,620 |  |
| The Netherlands |  | 2,291 |  |  | 2,652 |  |  | 2,804 |  |
| Other |  | 675 |  |  | 565 |  |  | 498 |  |
| Consolidated |  | $ | 13,739 |  |  | $ | 13,724 |  |  | $ | 14,351 |  |
| Long-lived assets: |  |  |  |  |  |  |
| Singapore |  | $ | 900 |  |  | $ | 788 |  |  | $ | 881 |  |
| Thailand |  | 328 |  |  | 398 |  |  | 398 |  |
| United States |  | 725 |  |  | 500 |  |  | 427 |  |
| China |  | 138 |  |  | 167 |  |  | 212 |  |
| Malaysia |  | 248 |  |  | 146 |  |  | 129 |  |
| Other |  | 568 |  |  | 680 |  |  | 852 |  |
| Consolidated |  | $ | 2,907 |  |  | $ | 2,679 |  |  | $ | 2,899 |  |

[0001047469-15-006787:notes:272]
| (a) | Revenue is attributed to countries based on the shipping location. |


## us-gaap:ScheduleOfValuationAndQualifyingAccountsDisclosureTextBlock

[0001047469-15-006787:notes:273]
| (Dollars in millions) |  | Balance atBeginning ofPeriod |  | Charges(credit) toOperations |  | Deductions (a) |  | Assumed fromLaCie S.A. |  | Balance atEnd ofPeriod |
| Fiscal year ended June 28, 2013 |  | $ | 10 |  |  | (2 | ) |  | (1 | ) |  | 1 |  |  | $ | 8 |  |
| Fiscal year ended June 27, 2014 |  | $ | 8 |  |  | 4 |  |  | — |  |  | — |  |  | $ | 12 |  |
| Fiscal year ended July 3, 2015 |  | $ | 12 |  |  | — |  |  | (3 | ) |  | — |  |  | $ | 9 |  |

[0001047469-15-006787:notes:274]
| (a) | Uncollectible accounts written off, net of recoveries. |


## us-gaap:SegmentReportingDisclosureTextBlock

[0001047469-15-006787:notes:275]
Business Segment and Geographic Information

[0001047469-15-006787:notes:276]
The Company has concluded that its manufacture and distribution of electronic storage solutions constitutes one reporting segment.  The Company's manufacturing operations are based on technology platforms that are used to produce various electronic storage solutions that serve multiple applications and markets.  The Company's main technology platforms are primarily focused around areal density of media and read/write head technologies.  In addition, the Company also invests in certain other technology platforms including motors, servo formatting read/write channels, solid state and other technologies.  The Company has determined that its Chief Executive Officer is the Company's chief operating decision maker (CODM) as he is responsible for reviewing and approving investments in the Company's technology platforms and manufacturing infrastructure.

[0001047469-15-006787:notes:277]
In fiscal years 2015, 2014 and 2013, Dell Inc. accounted for approximately 14%, 13% and 13% of consolidated revenue, respectively, while Hewlett-Packard Company accounted for approximately 12%, 13% and 10% of consolidated revenue, respectively. No other customer accounted for more than 10% of consolidated revenue in any year presented.

[0001047469-15-006787:notes:278]
Other long-lived assets consist of property, equipment and leasehold improvements, other intangible assets, capital leases, equity investments and other non-current assets as recorded by the Company's operations in each area.

[0001047469-15-006787:notes:279]
The following table summarizes the Company's operations by geographic area:


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001047469-15-006787:notes:280]
Shareholders' Equity

[0001047469-15-006787:notes:281]
Share Capital

[0001047469-15-006787:notes:282]
The Company's authorized share capital is $13,500 and consists of 1,250,000,000 ordinary shares, par value $0.00001, of which 315,445,536 shares were outstanding as of July 3, 2015, and 100,000,000 preferred shares, par value $0.00001, of which none were issued or outstanding as of July 3, 2015.

[0001047469-15-006787:notes:283]
Ordinary shares - Holders of ordinary shares are entitled to receive dividends when and as declared by the Company's board of directors (the "Board of Directors"). Upon any liquidation, dissolution, or winding up of the Company, after required payments are made to holders of preferred shares, any remaining assets of the Company will be distributed ratably to holders of the preferred and ordinary shares. Holders of shares are entitled to one vote per share on all matters upon which the ordinary shares are entitled to vote, including the election of directors.

[0001047469-15-006787:notes:284]
Preferred shares - The Company may issue preferred shares in one or more series, up to the authorized amount, without shareholder approval. The Board of Directors is authorized to establish from time to time the number of shares to be included in each series, and to fix the rights, preferences and privileges of the shares of each wholly unissued series and any of its qualifications, limitations or restrictions. The Board of Directors can also increase or decrease the number of shares of a series, but not below the number of shares of that series then outstanding, without any further vote or action by the shareholders.

[0001047469-15-006787:notes:285]
The Board of Directors may authorize the issuance of preferred shares with voting or conversion rights that could harm the voting power or other rights of the holders of the ordinary shares. The issuance of preferred shares, while providing flexibility in connection with possible acquisitions and other corporate purposes, could, among other things, have the effect of delaying, deferring or preventing a change in control of the Company and might harm the market price of its ordinary shares and the voting and other rights of the holders of ordinary shares.

[0001047469-15-006787:notes:286]
Repurchases of Equity Securities

[0001047469-15-006787:notes:287]
On July 24, 2013, the Board of Directors authorized the Company to repurchase an additional $2.5 billion of its outstanding ordinary shares.

[0001047469-15-006787:notes:288]
On April 22, 2015, the Board of Directors authorized the Company to repurchase an additional $2.5 billion of its outstanding ordinary shares.

[0001047469-15-006787:notes:289]
All repurchases are effected as redemptions in accordance with the Company's Articles of Association.

[0001047469-15-006787:notes:290]
As of July 3, 2015, $2.9 billion remained available for repurchase under the existing repurchase authorization limit.

[0001047469-15-006787:notes:291]
The following table sets forth information with respect to repurchases of the Company's ordinary shares during fiscal years 2015,  2014 and  2013:


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0001047469-15-006787:notes:292]
Balance Sheet Information

[0001047469-15-006787:notes:293]
Investments

[0001047469-15-006787:notes:294]
The following table summarizes, by major type, the fair value and amortized cost of the Company's investments as of July 3, 2015:

[0001047469-15-006787:notes:295]
As of July 3, 2015, the Company's Restricted cash and investments consisted of $7 million in cash and investments held as collateral at banks for various performance obligations.

[0001047469-15-006787:notes:296]
As of July 3, 2015, the Company had no material available-for-sale securities that had been in a continuous unrealized loss position for a period greater than 12 months.  The Company determined no available-for-sale securities were other-than-temporarily impaired as of July 3, 2015.

[0001047469-15-006787:notes:297]
The fair value and amortized cost of the Company's investments classified as available-for-sale at July 3, 2015 by remaining contractual maturity was as follows:

[0001047469-15-006787:notes:298]
Equity securities which do not have a contractual maturity date are not included in the above table.

[0001047469-15-006787:notes:299]
The following table summarizes, by major type, the fair value and amortized cost of the Company's investments as of June 27, 2014:

[0001047469-15-006787:notes:300]
As of June 27, 2014, the Company's Restricted cash and investments consisted of $4 million in cash and investments held as collateral at banks for various performance obligations.

[0001047469-15-006787:notes:301]
During the fourth quarter of 2014, the Company sold all of its auction rate securities and recognized an immaterial loss on the sale which is included in Other, net in the Company's Consolidated Statement of Operations.

[0001047469-15-006787:notes:302]
As of June 27, 2014, the Company had no available-for-sale securities that had been in a continuous unrealized loss position for a period greater than 12 months.  The Company determined no available-for-sale securities were other-than-temporarily impaired as of June 27, 2014.

[0001047469-15-006787:notes:303]
Accounts Receivable, net

[0001047469-15-006787:notes:304]
The following table provides details of the accounts receivable, net balance sheet item:

[0001047469-15-006787:notes:305]
Activity in the allowance for doubtful accounts is as follows:

[0001047469-15-006787:notes:306]
Inventories

[0001047469-15-006787:notes:307]
The following table provides details of the inventory balance sheet item:

[0001047469-15-006787:notes:308]
Other Current Assets

[0001047469-15-006787:notes:309]
The following table provides details of the other current assets balance sheet item:

[0001047469-15-006787:notes:310]
Other current assets include non-trade receivables from certain manufacturing vendors resulting from the sale of components to these vendors who manufacture completed sub-assemblies or finished goods for the Company.  The Company does not reflect the sale of these components in revenue and does not recognize any profits on these sales. The costs of the completed sub-assemblies are included in inventory upon purchase from the vendors.

[0001047469-15-006787:notes:311]
Property, Equipment and Leasehold Improvements, net

[0001047469-15-006787:notes:312]
The components of property, equipment and leasehold improvements, net were as follows:

[0001047469-15-006787:notes:313]
Depreciation expense, which includes amortization of leasehold improvements, was $689 million, $748 million and $727 million for fiscal years 2015, 2014, and 2013, respectively.  Interest on borrowings related to eligible capital expenditures is capitalized as part of the cost of the qualified assets and amortized over the estimated useful lives of the assets.  During fiscal years     2015, 2014, and  2013, the Company capitalized interest of $15 million, $7 million and $10 million, respectively.

[0001047469-15-006787:notes:314]
Accumulated Other Comprehensive Income (Loss) (“AOCI”)

[0001047469-15-006787:notes:315]
The components of AOCI, net of tax, were as follows:
