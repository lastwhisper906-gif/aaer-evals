# STX notes — 0001137789-26-000088


## us-gaap:OrganizationConsolidationBasisOfPresentationBusinessDescriptionAndAccountingPoliciesTextBlock

[0001137789-26-000088:notes:1]
[same as prior period, unchanged from 0001137789-26-000026:notes:1]

[0001137789-26-000088:notes:2]
Seagate Technology Holdings plc (“STX”) and its subsidiaries (collectively, unless the context otherwise indicates, the “Company”) is a leading provider of data storage technology and infrastructure solutions. Its principal business is the design, manufacture, and sale of hard disk drives, commonly referred to as disk drives, hard drives or HDDs. In addition to HDDs, the Company produces data storage systems that incorporate its high-capacity HDD products and offers solid state drives (“SSDs”).

[0001137789-26-000088:notes:3]
[same as prior period, unchanged from 0001137789-26-000026:notes:3]

[0001137789-26-000088:notes:4]
[same as prior period, unchanged from 0001137789-26-000026:notes:4]

[0001137789-26-000088:notes:5]
[same as prior period, unchanged from 0001137789-26-000026:notes:5]

[0001137789-26-000088:notes:6]
[same as prior period, unchanged from 0001137789-26-000026:notes:6]

[0001137789-26-000088:notes:7]
[same as prior period, unchanged from 0001137789-26-000026:notes:7]

[0001137789-26-000088:notes:8]
The Company’s Consolidated Financial Statements for the fiscal year ended June 27, 2025 are included in its Annual Report on Form 10-K, as filed with the U.S. Securities and Exchange Commission (“SEC”) on August 1, 2025. The Company believes that the disclosures included in these unaudited Condensed Consolidated Financial Statements, when read in conjunction with its Consolidated Financial Statements as of June 27, 2025, and the notes thereto, are adequate to make the information presented not misleading. The results of operations for the three and nine months ended April 3, 2026 are not necessarily indicative of the results to be expected for any subsequent interim period or for the Company’s fiscal year ending July 3, 2026.

[0001137789-26-000088:notes:9]
[same as prior period, unchanged from 0001137789-26-000026:notes:9]

[0001137789-26-000088:notes:10]
The Company operates and reports financial results on a fiscal year of 52 or 53 weeks ending on the Friday closest to June 30. In fiscal years with 53 weeks, the first quarter consists of 14 weeks and the remaining quarters consist of 13 weeks each. The three and nine months ended April 3, 2026 consisted of 13 weeks and 40 weeks, respectively, and the three and nine months ended March 28, 2025 consisted of 13 weeks and 39 weeks, respectively. Fiscal years 2026 and 2025 comprise 53 and 52 weeks and end on July 3, 2026 and June 27, 2025, respectively. The fiscal quarters ended April 3, 2026, January 2, 2026 and March 28, 2025, are also referred to herein as the “March 2026 quarter”, the “December 2025 quarter” and the “March 2025 quarter”, respectively.

[0001137789-26-000088:notes:11]
[same as prior period, unchanged from 0001137789-26-000026:notes:11]

[0001137789-26-000088:notes:12]
[same as prior period, unchanged from 0001137789-26-000026:notes:12]

[0001137789-26-000088:notes:13]
Recently Adopted Accounting Pronouncements

[0001137789-26-000088:notes:14]
In November 2023, the Financial Accounting Standards Board (“FASB”) issued ASU 2023-07 (ASC Topic 280), Improvements to Reportable Segment Disclosures. This ASU improves reportable segment disclosure requirements primarily through enhanced disclosures about significant segment expenses. The Company adopted the disclosure requirement for its annual reporting in fiscal year 2025 and adopted the guidance for interim period reporting beginning the first quarter of fiscal year 2026 on a retrospective basis. Refer to “Note 7. Business Segment”.

[0001137789-26-000088:notes:15]
In November 2024, the FASB issued ASU 2024-04 (ASC Subtopic 470-20), Induced Conversions of Convertible Debt Instruments. This ASU clarifies the requirements for determining whether certain settlements of convertible debt instruments should be accounted for as an induced conversion. The guidance is effective for fiscal years beginning after December 15, 2025, with early adoption permitted. The Company adopted the guidance on a prospective basis in fiscal year 2026 and applied the amendments in the ASU to the exchanges of the 2028 Notes. Refer to “Note 3. Debt”.

[0001137789-26-000088:notes:16]
Recently Issued Accounting Pronouncements

[0001137789-26-000088:notes:17]
In December 2023, the FASB issued ASU 2023-09 (ASC Topic 740), Improvements to Income Tax Disclosures. This ASU requires disaggregated income tax disclosures on the rate reconciliation and income taxes paid. The Company is required to adopt this guidance for its annual reporting in fiscal year 2026 on a prospective basis but has the option to apply it retrospectively. This standard is expected to impact the Company’s disclosures and will not have an impact on its Consolidated Financial Statements.


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0001137789-26-000088:notes:18]
[same as prior period, unchanged from 0001137789-26-000026:notes:18]

[0001137789-26-000088:notes:19]
[same as prior period, unchanged from 0001137789-26-000026:notes:19]

[0001137789-26-000088:notes:20]
| (Dollars in millions) |  | April 3, 2026 |  | June 27, 2025 |  |  |  |  |
| Cash and cash equivalents |  | $ | 1,146 |  |  | $ | 891 |  |  |  |  |  |
| Restricted cash included in Other current assets |  | 1 |  |  | 2 |  |  |  |  |  |
| Total cash, cash equivalents and restricted cash shown in the Statements of Cash Flows |  | $ | 1,147 |  |  | $ | 893 |  |  |  |  |  |

[0001137789-26-000088:notes:21]
[same as prior period, unchanged from 0001137789-26-000026:notes:21]

[0001137789-26-000088:notes:22]
[same as prior period, unchanged from 0001137789-26-000026:notes:22]

[0001137789-26-000088:notes:23]
During the three and nine months ended April 3, 2026, the Company did not sell any accounts receivables to a third party. During the three and nine months ended March 28, 2025, the Company sold accounts receivables without recourse for cash proceeds of $122 million and $692 million, respectively. As of April 3, 2026 and June 27, 2025, no amount remained subject to servicing.

[0001137789-26-000088:notes:24]
[same as prior period, unchanged from 0001137789-26-000026:notes:24]

[0001137789-26-000088:notes:25]
[same as prior period, unchanged from 0001137789-26-000026:notes:25]

[0001137789-26-000088:notes:26]
| (Dollars in millions) |  | April 3, 2026 |  | June 27, 2025 |
| Raw materials and components |  | $ | 254 |  |  | $ | 374 |  |
| Work-in-process |  | 1,035 |  |  | 838 |  |
| Finished goods |  | 241 |  |  | 228 |  |
| Total inventories, net |  | $ | 1,530 |  |  | $ | 1,440 |  |

[0001137789-26-000088:notes:27]
[same as prior period, unchanged from 0001137789-26-000026:notes:27]

[0001137789-26-000088:notes:28]
[same as prior period, unchanged from 0001137789-26-000026:notes:28]

[0001137789-26-000088:notes:29]
| (Dollars in millions) |  | April 3, 2026 |  | June 27, 2025 |
| Vendor receivables |  | $ | 159 |  |  | $ | 121 |  |
| Other current assets |  | 267 |  |  | 242 |  |
| Total |  | $ | 426 |  |  | $ | 363 |  |

[0001137789-26-000088:notes:30]
[same as prior period, unchanged from 0001137789-26-000026:notes:30]

[0001137789-26-000088:notes:31]
[same as prior period, unchanged from 0001137789-26-000026:notes:31]

[0001137789-26-000088:notes:32]
| (Dollars in millions) |  | April 3, 2026 |  | June 27, 2025 |
| Gross property, equipment and leasehold improvements |  | $ | 10,459 |  |  | $ | 10,330 |  |
| Less: accumulated depreciation and amortization |  | (8,607) |  |  | (8,673) |  |
| Property, equipment and leasehold improvements, net |  | $ | 1,852 |  |  | $ | 1,657 |  |

[0001137789-26-000088:notes:33]
[same as prior period, unchanged from 0001137789-26-000026:notes:33]

[0001137789-26-000088:notes:34]
[same as prior period, unchanged from 0001137789-26-000026:notes:34]

[0001137789-26-000088:notes:35]
| (Dollars in millions) |  | April 3, 2026 |  | June 27, 2025 |
| Dividends payable |  | $ | 166 |  |  | $ | 153 |  |
| Other accrued expenses |  | 605 |  |  | 479 |  |
| Total |  | $ | 771 |  |  | $ | 632 |  |

[0001137789-26-000088:notes:36]
[same as prior period, unchanged from 0001137789-26-000026:notes:36]

[0001137789-26-000088:notes:37]
[same as prior period, unchanged from 0001137789-26-000026:notes:37]

[0001137789-26-000088:notes:38]
| (Dollars in millions) |  | April 3, 2026 |  | June 27, 2025 |
| Deferred contract liabilities |  | $ | 194 |  |  | $ | 211 |  |
| Non-current income tax payable |  | 289 |  |  | 1 |  |
| Non-current lease liabilities |  | 315 |  |  | 317 |  |
| Other non-current accrued expenses |  | 184 |  |  | 227 |  |
| Total |  | $ | 982 |  |  | $ | 756 |  |

[0001137789-26-000088:notes:39]
[same as prior period, unchanged from 0001137789-26-000026:notes:39]

[0001137789-26-000088:notes:40]
[same as prior period, unchanged from 0001137789-26-000026:notes:40]

[0001137789-26-000088:notes:41]
Outstanding amounts related to suppliers participating in the SCF program, recorded within Accounts payable in the Company's Condensed Consolidated Balance Sheets, were $368 million and $20 million as of April 3, 2026 and June 27, 2025, respectively. The associated payments are included in Net cash provided by operating activities on its Condensed Consolidated Statements of Cash Flows.

[0001137789-26-000088:notes:42]
[same as prior period, unchanged from 0001137789-26-000026:notes:42]

[0001137789-26-000088:notes:43]
Accumulated other comprehensive loss, net of tax, was comprised of $8 million unrealized losses on defined benefit pension plans as of April 3, 2026 and June 27, 2025, respectively. Accumulated other comprehensive loss, net of tax, was comprised of $1 million and $2 million unrealized losses on defined benefit pension plans as of March 28, 2025 and June 28, 2024, respectively.


## us-gaap:DebtDisclosureTextBlock

[0001137789-26-000088:notes:44]
Debt
The following table provides details of the Company’s debt as of April 3, 2026 and June 27, 2025:

[0001137789-26-000088:notes:45]
| (Dollars in millions) |  | April 3, 2026 |  | June 27, 2025 |
| Unsecured Senior Notes issued by Seagate HDD Cayman (1) |  |  |  |  |
| $500 issued on June 18, 2020 at 4.091% due June 1, 2029 (the “Old June 2029 Notes”) (3) |  | $ | 38 |  |  | $ | 452 |  |
| $500 issued on December 8, 2020 at 3.125% due July 15, 2029 (the “Old July 2029 Notes”) (4) |  | 38 |  |  | 138 |  |
| $500 issued on May 30, 2023 at 8.25% due December 15, 2029 (the “Old December 2029 Notes”) (5) |  | 8 |  |  | 500 |  |
| $500 issued on June 10, 2020 at 4.125% due January 15, 2031 (the “Old January 2031 Notes”) (4) |  | 23 |  |  | 237 |  |
| $500 issued on December 8, 2020 at 3.375% due July 15, 2031 (the “Old July 2031 Notes”) (4) |  | 16 |  |  | 61 |  |
| $500 issued on May 30, 2023 at 8.50% due July 15, 2031 (the “Old 8.50% July 2031 Notes”) (4) |  | 29 |  |  | 500 |  |
| $750 issued on November 30, 2022 at 9.625% due December 1, 2032 (the “Old 2032 Notes”) (3) |  | 19 |  |  | 750 |  |
| $500 issued on December 2, 2014 at 5.75% due December 1, 2034 (the “Old 2034 Notes”) (3) |  | 162 |  |  | 489 |  |
| Unsecured Senior Notes issued by Seagate Data Storage Technology Pte. Ltd. (2) |  |  |  |  |
| $400 issued on May 27, 2025 at 5.875% due July 15, 2030 (the “2030 Notes”) (4) |  | 400 |  |  | 400 |  |
| $431 issued on June 30, 2025 at 4.091% due June 1, 2029 (the “New June 2029 Notes”) (3) |  | 379 |  |  | — |  |
| $100 issued on June 30, 2025 at 3.125% due July 15, 2029 (the “New July 2029 Notes”) (4) |  | 100 |  |  | — |  |
| $492 issued on June 30, 2025 at 8.25% due December 15, 2029 (the “New December 2029 Notes”) (5) |  | 492 |  |  | — |  |
| $213 issued on June 30, 2025 at 4.125% due January 15, 2031 (the “New January 2031 Notes”) (4) |  | 213 |  |  | — |  |
| $45 issued on June 30, 2025 at 3.375% due July 15, 2031 (the “New July 2031 Notes”) (4) |  | 45 |  |  | — |  |
| $471 issued on June 30, 2025 at 8.50% due July 15, 2031 (the “New 8.50% July 2031 Notes”) (4) |  | 471 |  |  | — |  |
| $731 issued on June 30, 2025 at 9.625% due December 1, 2032 (the “New 2032 Notes”) (3) |  | 731 |  |  | — |  |
| $328 issued on June 30, 2025 at 5.75% due December 1, 2034 (the “New 2034 Notes”) (3) |  | 327 |  |  | — |  |
| Exchangeable Senior Notes (1) |  |  |  |  |
| $1,500 issued on September 13, 2023 at 3.50% due June 1, 2028 (the “2028 Notes”) (6) |  | 399 |  |  | 1,500 |  |
|  |  | 3,890 |  |  | 5,027 |  |
| Less: unamortized debt issuance costs |  | (27) |  |  | (32) |  |
| Debt, net of debt issuance costs |  | 3,863 |  |  | 4,995 |  |
| Less: current portion of long-term debt, net of debt issuance costs |  | (398) |  |  | — |  |
| Long-term debt, less current portion |  | $ | 3,465 |  |  | $ | 4,995 |  |

[0001137789-26-000088:notes:46]
___________________________________

[0001137789-26-000088:notes:47]
(1) Notes are issued by Seagate HDD Cayman (“Seagate HDD”), and the obligations under these notes were fully and unconditionally guaranteed, on a senior unsecured basis, by Seagate Technology Unlimited Company (“STUC”) and Seagate Technology Holdings plc (“STH PLC”). Supplemental indentures for each series of Old Notes (as defined below) became operative on June 30, 2025 and gave effect to certain amendments which, among other things, released STUC and STH PLC from their respective guarantee obligations with respect to each series of Old Notes.

[0001137789-26-000088:notes:48]
(2) Notes are issued by Seagate Data Storage Technology Pte. Ltd. (“SDST”), and the obligations under these notes are fully and unconditionally guaranteed, on a senior unsecured basis, by STUC, Seagate HDD and STH PLC.

[0001137789-26-000088:notes:49]
(3) Interest payable semi-annually on June 1 and December 1 of each year.

[0001137789-26-000088:notes:50]
(4) Interest payable semi-annually on January 15 and July 15 of each year.

[0001137789-26-000088:notes:51]
(5) Interest payable semi-annually on June 15 and December 15 of each year.

[0001137789-26-000088:notes:52]
(6) Interest payable semi-annually on March 1 and September 1 of each year.

[0001137789-26-000088:notes:53]
Obligor Exchange

[0001137789-26-000088:notes:54]
On June 27, 2025, the Company completed offers to exchange (collectively, the “Exchange Offers”) any and all outstanding notes of eight series issued by Seagate HDD (the “Old Notes”) for new notes to be issued by SDST (the “New Notes”), and related consent solicitations.

[0001137789-26-000088:notes:55]
In accordance with the terms of the Exchange Offers and consent solicitations, the Company accepted for exchange all Old Notes validly tendered. The Exchange Offers and the consent solicitations were settled on June 30, 2025. No gain or loss was recorded as the Exchange Offers were accounted for as a debt modification. The Company incurred immaterial third party fees for the Exchange Offers during the September 2025 quarter.

[0001137789-26-000088:notes:56]
Other than the identity of SDST as the issuer and as an obligor, the terms of the New Notes are identical to the Old Notes with respect to their interest rate, interest payment dates, optional redemption prices and maturity. The New Notes were guaranteed by the same guarantors as the Old Notes, in addition to Seagate HDD (which is the issuer of the Old Notes). The New Notes have substantially the same covenants as the Old Notes and are subject to the same business and financial risks.

[0001137789-26-000088:notes:57]
2028 Exchangeable Senior Notes and related Capped Call Transactions

[0001137789-26-000088:notes:58]
On November 12, 2025, the Company completed separate, privately negotiated exchange agreements with certain holders of the 2028 Notes and exchanged $500 million total principal amount for consideration of $500 million cash and approximately 4.3 million shares of the Company’s common stock. On February 19, 2026, the Company completed separate, privately negotiated exchange agreements with certain holders of the 2028 Notes and exchanged $600 million total principal amount for consideration of $600 million cash and approximately 6 million shares of the Company’s common stock. The Company accounted for these exchange transactions as induced conversion transactions and recognized a non-cash induced conversion expense of $59 million and $120 million within Net loss from debt transactions in the Company’s Condensed Consolidated Statements of Operations in the three and nine months ended April 3, 2026, respectively, with a corresponding increase to Additional Paid-in Capital. There was no corresponding change to the $1.5 billion notional value of the capped call transactions.

[0001137789-26-000088:notes:59]
As of April 3, 2026, the effective interest rate for the 3.50% Exchangeable Senior Notes due 2028 (the “2028 Notes”) was 3.94%, with contractual interest expense of $6 million and $31 million for the three and nine months ended April 3, 2026, respectively, and immaterial amortization of debt issuance costs. As of March 28, 2025, the effective interest rate for the 2028 Notes was 3.94%, with contractual interest expense of $13 million and $39 million for the three and nine months ended March 28, 2025, respectively, and immaterial amortization of debt issuance costs.

[0001137789-26-000088:notes:60]
Prior to March 1, 2028, the 2028 Notes are exchangeable at the option of the holders only under certain circumstances as set out in the indenture for the 2028 Notes. As of the calendar quarter ended March 31, 2026, the sale price conditional conversion option of the 2028 Notes was triggered. Accordingly, the 2028 Notes are exchangeable through June 30, 2026. The Company has classified the total balance of the 2028 Notes as the Current portion of long-term debt within Current liabilities in the Company’s Condensed Consolidated Balance Sheets as of April 3, 2026.

[0001137789-26-000088:notes:61]
On or after March 1, 2028, the 2028 Notes are exchangeable at any time at the option of the holders until the close of business on the second scheduled trading day immediately preceding the maturity date, unless the 2028 Notes have been previously redeemed or repurchased by Seagate HDD.

[0001137789-26-000088:notes:62]
Upon exchange of the 2028 Notes, Seagate HDD will pay cash up to the aggregate principal amount of 2028 Notes to be exchanged and will pay or cause to be delivered, as the case may be, cash, ordinary shares of the Company or a combination of cash and ordinary shares of the Company, at Seagate HDD’s election, in respect of any remainder of the exchange obligation in excess of such principal amount. The exchange rate for the 2028 Notes as of April 3, 2026 is 12.1363 ordinary shares per $1,000 principal amount of 2028 Notes, which is equivalent to an exchange price of approximately $82.40 per share as of April 3, 2026. The exchange rate was adjusted from 12.1352 ordinary shares per $1,000 principal amount of 2028 Notes on March 25, 2026, and is subject to further adjustment pursuant to the terms of the Exchangeable Notes indenture.

[0001137789-26-000088:notes:63]
Seagate HDD may redeem the 2028 Notes at its option:

[0001137789-26-000088:notes:64]
(i) at any time, in whole but not in part, if Seagate HDD or the Guarantors have, or on the next interest payment date would, become obligated to pay to the holder of any 2028 Note additional amounts as a result of certain tax-related events which cannot be avoided by taking commercially reasonable measures and which have been confirmed by an opinion of outside legal counsel (a “Tax Redemption”); and/or

[0001137789-26-000088:notes:65]
(ii) on or after September 8, 2026, in whole or in part, if the last reported sale price of ordinary shares of the Company has been at least 130% of the exchange price then in effect for at least 20 trading days (whether or not consecutive) during any 30 consecutive trading day period (a “Provisional Redemption”) at a redemption price equal to 100% of the principal amount of the 2028 Notes to be redeemed, plus accrued and unpaid interest to, but excluding, the redemption date. If Seagate HDD redeems less than all the outstanding 2028 Notes, at least $150 million aggregate principal amount of 2028 Notes must be outstanding and not subject to redemption as of the relevant notice of redemption date.

[0001137789-26-000088:notes:66]
If Seagate HDD elects to redeem any of the 2028 Notes pursuant to a Tax Redemption or a Provisional Redemption, then a holder of any such called 2028 Notes (the “Redemption Called Notes”) may exchange such Redemption Called Notes at any time prior to the close of business on the second scheduled trading day preceding the relevant redemption date, or if later, until the relevant redemption price is paid.

[0001137789-26-000088:notes:67]
If a holder elects to exchange any Redemption Called Notes, Seagate HDD shall, under certain circumstances, increase the exchange rate for such Redemption Called Notes as set out in the indenture for the 2028 Notes.

[0001137789-26-000088:notes:68]
In connection with the 2028 Notes, the Company and Seagate HDD entered into privately negotiated capped call transactions with certain financial institutions. The current cap price of the capped call transactions, which was adjusted on March 25, 2026 in accordance with the applicable capped call confirmations, is $107.750 per share. The cost of the capped call transactions was $95 million, which met certain accounting criteria to be accounted under Additional Paid-in Capital as part of the Shareholders’ Deficit and are not accounted as derivatives in the Company’s Condensed Consolidated Balance Sheets.

[0001137789-26-000088:notes:69]
Debt Repurchases

[0001137789-26-000088:notes:70]
During the March 2026 quarter, $40 million principal amount of the New June 2029 Notes were repurchased for cash at a discount to their principal amount, plus accrued and unpaid interest. The Company recorded an immaterial loss which was included in Net loss from debt transactions in the Company’s Condensed Consolidated Statements of Operations.

[0001137789-26-000088:notes:71]
Credit Agreement

[0001137789-26-000088:notes:72]
On January 30, 2025, the Company and its subsidiary Seagate HDD Cayman (the “Borrower”), the Bank of Nova Scotia, as administrative agent, and the lenders thereto entered into a Credit Agreement (the “Credit Agreement”) which provides for a $1.3 billion senior unsecured revolving credit facility (“Revolving Credit Facility”), the term of which is through January 30, 2030. The Revolving Credit Facility is available for cash borrowings, subject to compliance with certain covenants and other customary conditions to borrowing. An aggregate amount of up to $150 million of the facility shall also be available for the issuance of letters of credit, and an aggregate amount of up to $50 million of the facility shall also be available for swing line loans. On April 3, 2026, no borrowings were outstanding under the Credit Agreement.

[0001137789-26-000088:notes:73]
The loans made under the Credit Agreement will bear interest at an Applicable Rate based on the secured overnight financing rate, or SOFR, plus a variable margin that will be determined based on the corporate credit rating of the Company. The Borrower’s obligations under the Credit Agreement are guaranteed by the Company and certain material subsidiaries of the Company.

[0001137789-26-000088:notes:74]
The Credit Agreement also contains a financial covenant that requires the Company to maintain a total net leverage ratio of less than or equal to 6.75 to 1.00, commencing with the fiscal quarter ended June 27, 2025 and declining over time so that the maximum permitted net leverage ratio for each fiscal quarter ending after July 2, 2027 is 4.25 to 1.00, in accordance with the terms of the Credit Agreement.

[0001137789-26-000088:notes:75]
Future Principal Payments on Long-term Debt

[0001137789-26-000088:notes:76]
At April 3, 2026, future principal payments on long-term debt were as follows (in millions):

[0001137789-26-000088:notes:77]
| Fiscal Year |  | Amount |
| Remainder of 2026 |  | $ | — |  |
| 2027 |  | — |  |
| 2028 |  | 399 |  |
| 2029 |  | 430 |  |
| 2030 |  | 638 |  |
| Thereafter |  | 2,438 |  |
| Total |  | $ | 3,905 |  |


## us-gaap:IncomeTaxDisclosureTextBlock

[0001137789-26-000088:notes:78]
Income Taxes
The Company recorded an income tax provision of $116 million and $295 million for the three and nine months ended April 3, 2026, respectively. The income tax provision for the three months ended April 3, 2026 included approximately $25 million of net discrete benefit, primarily associated with net excess tax benefits related to share-based compensation expense. The income tax provision for the nine months ended April 3, 2026 also includes total discrete tax benefit of approximately $65 million, primarily related to the release of certain valuation allowances in connection with the enactment of the One Big Beautiful Bill Act in July 2025, as well as net excess tax benefits related to share-based compensation expense.

[0001137789-26-000088:notes:79]
The Company’s income tax provision for the three and nine months ended April 3, 2026 differed from the provisions for income taxes that would be derived by applying the Singaporean statutory rate of 17% to income before income taxes, primarily due to the net effect of tax benefits related to earnings generated in jurisdictions that are subject to tax incentive programs, offset by the effects of Pillar Two global minimum tax in major jurisdictions that the Company operates starting from fiscal year 2026.

[0001137789-26-000088:notes:80]
During the nine months ended April 3, 2026, the Company’s unrecognized tax benefits excluding interest and penalties increased by approximately $30 million to $137 million, substantially all of which would impact the effective tax rate, if recognized, subject to certain future valuation allowance reversals. The Company is not expecting material changes to its unrecognized tax benefits in the next twelve months beginning April 4, 2026.

[0001137789-26-000088:notes:81]
The Company recorded an income tax provision of $15 million and $40 million for the three and nine months ended March 28, 2025, respectively. The discrete items in the income tax provision were not material for the three months ended March 28, 2025. The income tax provision for the nine months ended March 28, 2025 included approximately $19 million of net discrete benefit, primarily associated with the reversal of uncertain tax positions as a result of effective audit settlement, as well as net excess tax benefits related to share-based compensation expense.

[0001137789-26-000088:notes:82]
The Company’s income tax provisions recorded for the three and nine months ended March 28, 2025 differed from the provisions for income taxes that would be derived by applying the Singaporean statutory rate of 17% to income before income taxes, primarily due to the net effect of tax benefits related to earnings generated in jurisdictions that are subject to tax incentive programs.


## us-gaap:FairValueDisclosuresTextBlock

[0001137789-26-000088:notes:83]
[same as prior period, unchanged from 0001137789-26-000026:notes:77]

[0001137789-26-000088:notes:84]
[same as prior period, unchanged from 0001137789-26-000026:notes:78]

[0001137789-26-000088:notes:85]
[same as prior period, unchanged from 0001137789-26-000026:notes:79]

[0001137789-26-000088:notes:86]
[same as prior period, unchanged from 0001137789-26-000026:notes:80]

[0001137789-26-000088:notes:87]
[same as prior period, unchanged from 0001137789-26-000026:notes:81]

[0001137789-26-000088:notes:88]
[same as prior period, unchanged from 0001137789-26-000026:notes:82]

[0001137789-26-000088:notes:89]
[same as prior period, unchanged from 0001137789-26-000026:notes:83]

[0001137789-26-000088:notes:90]
[same as prior period, unchanged from 0001137789-26-000026:notes:84]

[0001137789-26-000088:notes:91]
[same as prior period, unchanged from 0001137789-26-000026:notes:85]

[0001137789-26-000088:notes:92]
[same as prior period, unchanged from 0001137789-26-000026:notes:86]

[0001137789-26-000088:notes:93]
|  |  |  |  | April 3, 2026 |  | June 27, 2025 |
|  |  |  |  | Fair Value Measurements at Reporting Date Using |  | Fair Value Measurements at Reporting Date Using |
| (Dollars in millions) |  | Balance SheetLocation |  | Quoted Prices in Active Markets for Identical Instruments(Level 1) |  | Significant Other Observable Inputs(Level 2) |  | Significant Unobservable Inputs(Level 3) |  | TotalBalance |  | Quoted Prices in Active Markets for Identical Instruments(Level 1) |  | Significant Other Observable Inputs(Level 2) |  | Significant Unobservable Inputs(Level 3) |  | TotalBalance |
| Assets: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds |  | Cash and cash equivalents |  | $ | 280 |  |  | $ | — |  |  | $ | — |  |  | $ | 280 |  |  | $ | 226 |  |  | $ | — |  |  | $ | — |  |  | $ | 226 |  |
| Time deposits |  | Cash and cash equivalents |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 26 |  |  | — |  |  | 26 |  |
| Total cash equivalents |  | 280 |  |  | — |  |  | — |  |  | 280 |  |  | 226 |  |  | 26 |  |  | — |  |  | 252 |  |
| Derivative assets |  | Other current assets |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 1 |  |  | — |  |  | 1 |  |
| Total assets |  |  |  | $ | 280 |  |  | $ | — |  |  | $ | — |  |  | $ | 280 |  |  | $ | 226 |  |  | $ | 27 |  |  | $ | — |  |  | $ | 253 |  |

[0001137789-26-000088:notes:94]
As of April 3, 2026 and June 27, 2025, the Company’s Other current assets included $1 million and $2 million, respectively, of restricted cash equivalents held as collateral at banks for various performance obligations.

[0001137789-26-000088:notes:95]
[same as prior period, unchanged from 0001137789-26-000026:notes:89]

[0001137789-26-000088:notes:96]
[same as prior period, unchanged from 0001137789-26-000026:notes:90]

[0001137789-26-000088:notes:97]
The carrying value of the Company’s strategic investments under the measurement alternative was $40 million and $26 million as of April 3, 2026 and June 27, 2025, respectively. For the investments that are accounted under the measurement alternative, the Company recorded no adjustment for the three and nine months ended April 3, 2026. The Company recorded no adjustment and a net loss of $39 million for the three and nine months ended March 28, 2025, respectively, related to downward adjustments to write down the carrying amount of certain investments to their fair value.

[0001137789-26-000088:notes:98]
[same as prior period, unchanged from 0001137789-26-000026:notes:92]

[0001137789-26-000088:notes:99]
[same as prior period, unchanged from 0001137789-26-000026:notes:93]

[0001137789-26-000088:notes:100]
|  |  | April 3, 2026 |  | June 27, 2025 |
| (Dollars in millions) |  | CarryingAmount |  | EstimatedFair Value |  | CarryingAmount |  | EstimatedFair Value |
| Exchangeable Senior Notes |  |  |  |  |  |  |  |  |
| 3.50% Exchangeable Senior Notes due June 2028 |  | $ | 399 |  |  | $ | 1,896 |  |  | $ | 1,500 |  |  | $ | 2,654 |  |
| Unsecured Senior Notes Issued by Seagate HDD Cayman |  |  |  |  |  |  |  |  |
| 4.091% Senior Notes due June 2029 |  | 38 |  |  | 38 |  |  | 452 |  |  | 453 |  |
| 3.125% Senior Notes due July 2029 |  | 38 |  |  | 34 |  |  | 138 |  |  | 125 |  |
| 8.25% Senior Notes due December 2029 |  | 8 |  |  | 9 |  |  | 500 |  |  | 535 |  |
| 4.125% Senior Notes due January 2031 |  | 23 |  |  | 21 |  |  | 237 |  |  | 218 |  |
| 3.375% Senior Notes due July 2031 |  | 16 |  |  | 14 |  |  | 61 |  |  | 52 |  |
| 8.50% Senior Notes due July 2031 |  | 29 |  |  | 31 |  |  | 500 |  |  | 538 |  |
| 9.625% Senior Notes due December 2032 |  | 19 |  |  | 21 |  |  | 750 |  |  | 854 |  |
| 5.75% Senior Notes due December 2034 |  | 162 |  |  | 162 |  |  | 489 |  |  | 482 |  |
| Unsecured Senior Notes issued by Seagate Data Storage Technology Pte. Ltd. |  |  |  |  |  |  |  |  |
| 4.091% Senior Notes due June 2029 |  | 379 |  |  | 380 |  |  | — |  |  | — |  |
| 3.125% Senior Notes due July 2029 |  | 100 |  |  | 90 |  |  | — |  |  | — |  |
| 8.25% Senior Notes due December 2029 |  | 492 |  |  | 516 |  |  | — |  |  | — |  |
| 5.875% Senior Notes due July 2030 |  | 400 |  |  | 407 |  |  | 400 |  |  | 407 |  |
| 4.125% Senior Notes due January 2031 |  | 213 |  |  | 200 |  |  | — |  |  | — |  |
| 3.375% Senior Notes due July 2031 |  | 45 |  |  | 38 |  |  | — |  |  | — |  |
| 8.50% Senior Notes due July 2031 |  | 471 |  |  | 495 |  |  | — |  |  | — |  |
| 9.625% Senior Notes due December 2032 |  | 731 |  |  | 816 |  |  | — |  |  | — |  |
| 5.75% Senior Notes due December 2034 |  | 327 |  |  | 328 |  |  | — |  |  | — |  |
|  |  | $ | 3,890 |  |  | $ | 5,496 |  |  | $ | 5,027 |  |  | $ | 6,318 |  |
| Less: unamortized debt issuance costs |  | (27) |  |  | — |  |  | (32) |  |  | — |  |
| Debt, net of debt issuance costs |  | $ | 3,863 |  |  | $ | 5,496 |  |  | $ | 4,995 |  |  | $ | 6,318 |  |
| Less: current portion of debt, net of debt issuance costs |  | (398) |  |  | — |  |  | — |  |  | — |  |
| Long-term debt, less current portion, net of debt issuance costs |  | $ | 3,465 |  |  | $ | 5,496 |  |  | $ | 4,995 |  |  | $ | 6,318 |  |

[0001137789-26-000088:notes:101]
[same as prior period, unchanged from 0001137789-26-000026:notes:95]


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001137789-26-000088:notes:102]
[same as prior period, unchanged from 0001137789-26-000026:notes:96]

[0001137789-26-000088:notes:103]
The Company’s authorized share capital is $13,500 and consists of 1,250,000,000 ordinary shares, par value $0.00001, of which 224,408,070 shares were outstanding as of April 3, 2026, and 100,000,000 preferred shares, par value $0.00001, of which none were issued or outstanding as of April 3, 2026.

[0001137789-26-000088:notes:104]
[same as prior period, unchanged from 0001137789-26-000026:notes:98]

[0001137789-26-000088:notes:105]
[same as prior period, unchanged from 0001137789-26-000026:notes:99]

[0001137789-26-000088:notes:106]
For the nine months ended April 3, 2026, the Company repurchased 0.3 million shares for $65 million under its share repurchase program. These amounts differ from the repurchases of ordinary shares amounts in the Company’s Condensed Consolidated Statements of Cash Flows due to timing differences between repurchases and cash settlement thereof. As of April 3, 2026, $4.9 billion remained available for repurchase under the existing repurchase authorization limit approved by the Board of Directors.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001137789-26-000088:notes:107]
Business Segment
The Company’s manufacturing operations are based on technology platforms that are used to produce various data storage and systems solutions that serve multiple applications and markets. The Company has determined that its Chief Operating Decision Maker (“CODM”), the Chief Executive Officer, evaluates performance of the Company and makes decisions regarding investments in the Company’s technology platforms and manufacturing infrastructure based on the Company’s consolidated results, including net income reported on the Condensed Consolidated Statements of Operations. As a result, the Company has concluded that its manufacture and distribution of storage solutions constitutes one operating segment.

[0001137789-26-000088:notes:108]
[same as prior period, unchanged from 0001137789-26-000026:notes:102]


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0001137789-26-000088:notes:109]
[same as prior period, unchanged from 0001137789-26-000026:notes:103]

[0001137789-26-000088:notes:110]
|  |  | For the Three Months Ended |  | For the Nine Months Ended |  |  |
| (Dollars in millions) |  | April 3, 2026 |  | March 28, 2025 |  | April 3, 2026 |  | March 28, 2025 |  |  |
| Revenues by Channel |  |  |  |  |  |  |  |  |  |  |
| OEMs |  | $ | 2,471 |  |  | $ | 1,711 |  |  | $ | 6,953 |  |  | $ | 5,301 |  |  |  |
| Distributors |  | 452 |  |  | 264 |  |  | 1,066 |  |  | 791 |  |  |  |
| Retailers |  | 189 |  |  | 185 |  |  | 547 |  |  | 561 |  |  |  |
| Total |  | $ | 3,112 |  |  | $ | 2,160 |  |  | $ | 8,566 |  |  | $ | 6,653 |  |  |  |

[0001137789-26-000088:notes:111]
| Revenue by Country (1): |  |  |  |  |  |  |  |  |  |  |
| United States |  | $ | 1,631 |  |  | $ | 1,090 |  |  | $ | 4,239 |  |  | $ | 3,246 |  |  |  |
| Singapore |  | 1,169 |  |  | 847 |  |  | 3,511 |  |  | 2,741 |  |  |  |
| The Netherlands |  | 311 |  |  | 222 |  |  | 813 |  |  | 663 |  |  |  |
| Other |  | 1 |  |  | 1 |  |  | 3 |  |  | 3 |  |  |  |
| Total |  | $ | 3,112 |  |  | $ | 2,160 |  |  | $ | 8,566 |  |  | $ | 6,653 |  |  |  |


## us-gaap:ProductWarrantyDisclosureTextBlock

[0001137789-26-000088:notes:112]
[same as prior period, unchanged from 0001137789-26-000026:notes:106]

[0001137789-26-000088:notes:113]
[same as prior period, unchanged from 0001137789-26-000026:notes:107]

[0001137789-26-000088:notes:114]
[same as prior period, unchanged from 0001137789-26-000026:notes:108]

[0001137789-26-000088:notes:115]
[same as prior period, unchanged from 0001137789-26-000026:notes:109]

[0001137789-26-000088:notes:116]
[same as prior period, unchanged from 0001137789-26-000026:notes:110]

[0001137789-26-000088:notes:117]
The Company estimates probable product warranty costs at the time revenue is recognized. The Company generally warrants its products for a period of 1 to 5 years. The Company uses estimated repair or replacement costs and uses statistical modeling to estimate product warranty return rates in order to determine its warranty obligation. Changes in the Company’s product warranty liability during the nine months ended April 3, 2026 and March 28, 2025 were as follows:

[0001137789-26-000088:notes:118]
|  |  | For the Nine Months Ended |
| (Dollars in millions) |  | April 3, 2026 |  | March 28, 2025 |
| Balance, beginning of period |  | $ | 137 |  |  | $ | 149 |  |
| Warranties issued |  | 80 |  |  | 49 |  |
| Repairs and replacements |  | (49) |  |  | (68) |  |
| Changes in liability for pre-existing warranties, including expirations |  | 11 |  |  | 4 |  |
| Balance, end of period |  | $ | 179 |  |  | $ | 134 |  |


## us-gaap:EarningsPerShareTextBlock

[0001137789-26-000088:notes:119]
[same as prior period, unchanged from 0001137789-26-000026:notes:113]

[0001137789-26-000088:notes:120]
|  |  | For the Three Months Ended |  | For the Nine Months Ended |
| (In millions, except per share data) |  | April 3, 2026 |  | March 28, 2025 |  | April 3, 2026 |  | March 28, 2025 |
| Numerator: |  |  |  |  |  |  |  |  |
| Net income |  | $ | 748 |  |  | $ | 340 |  |  | $ | 1,890 |  |  | $ | 981 |  |
| Number of shares used in per share calculations: |  |  |  |  |  |  |  |  |
| Total shares for purposes of calculating basic net income per share |  | 221 |  |  | 212 |  |  | 217 |  |  | 211 |  |
| Weighted-average effect of dilutive securities: |  |  |  |  |  |  |  |  |
| Employee equity award plans |  | 4 |  |  | 2 |  |  | 4 |  |  | 3 |  |
| 2028 Notes if-converted shares |  | 4 |  |  | 2 |  |  | 7 |  |  | 3 |  |
| Total shares for purposes of calculating diluted net income per share |  | 229 |  |  | 216 |  |  | 228 |  |  | 217 |  |
| Net income per share |  |  |  |  |  |  |  |  |
| Basic |  | $ | 3.38 |  |  | $ | 1.60 |  |  | $ | 8.71 |  |  | $ | 4.65 |  |
| Diluted |  | 3.27 |  |  | 1.57 |  |  | 8.29 |  |  | 4.52 |  |

[0001137789-26-000088:notes:121]
All potentially dilutive securities that could have an anti-dilutive effect on the calculation of the earnings per share have been excluded for the periods presented. The capped call transactions related to the 2028 Notes if-converted shares were excluded from the calculation of dilutive earnings per share as their effect would have been anti-dilutive. Other than the capped call, the weighted average anti-dilutive shares that were excluded from the computation of diluted net income per share were not material for the three and nine months ended April 3, 2026 and March 28, 2025, respectively.


## us-gaap:LegalMattersAndContingenciesTextBlock

[0001137789-26-000088:notes:122]
Legal, Environmental and Other Contingencies
The Company assesses the probability of an unfavorable outcome of all its material litigation, claims or assessments to determine whether a liability had been incurred and whether it is probable that one or more future events will occur confirming the fact of the loss. In the event that an unfavorable outcome is determined to be probable and the amount of the loss can be reasonably estimated, the Company establishes an accrual for the litigation, claim or assessment. In addition, in the event an unfavorable outcome is determined to be less than probable, but reasonably possible, the Company will disclose an estimate of the possible loss or range of such loss; however, when a reasonable estimate cannot be made, the Company will provide disclosure to that effect. Litigation is inherently uncertain and may result in adverse rulings or decisions. Additionally, the Company may enter into settlements or be subject to judgments that may, individually or in the aggregate, have a material adverse effect on its results of operations. Accordingly, actual results could differ materially.

[0001137789-26-000088:notes:123]
Litigation

[0001137789-26-000088:notes:124]
Lambeth Magnetic Structures LLC v. Seagate Technology (US) Holdings, Inc., et al. On April 29, 2016, Lambeth Magnetic Structures LLC filed a complaint against Seagate Technology (US) Holdings, Inc. and Seagate Technology LLC in the U.S. District Court for the Western District of Pennsylvania, alleging infringement of U.S. Patent No. 7,128,988, seeking damages as well as additional relief. The district court entered judgment in favor of Seagate on April 19, 2022. On September 17, 2025, the Court of Appeals for the Federal Circuit vacated the District Court’s judgment and remanded for a new trial on infringement and enablement. The Company believes the asserted claims are without merit and intends to vigorously defend this case.

[0001137789-26-000088:notes:125]
Seagate Technology LLC, et al. v. Headway Technologies, Inc., et al. On February 18, 2020, Seagate Technology LLC and certain of its affiliates, (collectively, the “Seagate Entities”) filed a complaint alleging violations of federal and state antitrust laws as well as breach of contract in the U.S. District Court for the Northern District of California against suppliers of HDD suspension assemblies, including NHK Spring Co. Ltd., TDK Corporation (“TDK”) and Hutchinson Technology Inc (“HTI”). The Seagate Entities seek to recover damages suffered as a result of the suspension assembly suppliers’ conduct, and additional relief permitted by law. On April 8, 2022, the court dismissed with prejudice all claims against TDK and HTI after the Seagate Entities settled with those defendants. On August 2, 2022, NHK Spring Co. Ltd. filed a motion for Partial Summary Judgment under the Foreign Trade Antitrust Improvement Act (“FTAIA Motion”). On November 17, 2023, the Court granted NHK’s FTAIA Motion on reconsideration, denying the majority of Seagate’s antitrust claims. On January 8, 2026, the Ninth Circuit reversed the District Court’s decision and remanded the case to the District Court, allowing Seagate’s antitrust claims to proceed.

[0001137789-26-000088:notes:126]
In re Seagate Technology Holdings plc Securities Litigation. On July 10, 2023 and July 26, 2023, two securities class action lawsuits were filed in the U.S. District Court for the Northern District of California against Seagate Technology Holdings plc, Dr. William D. Mosley, and Gianluca Romano. The cases were consolidated on September 25, 2023. On September 12, 2024, the plaintiffs filed the currently operative complaint, asserting claims under Sections 10(b) and 20(a) of the Securities Exchange Act of 1934 and SEC Rule 10b-5, and a class period between September 14, 2020 and April 19, 2023, inclusive. On April 3, 2026, the parties agreed to a settlement in principle to resolve the matter for a total amount of $175 million, approximately $70 million of which will be paid by the Company’s insurers. The Company recorded a charge of $105 million which was included in Legal settlement in its Condensed Consolidated Statements of Operations. The settlement is subject to court approval and execution of a definitive settlement agreement.

[0001137789-26-000088:notes:127]
Godo Kaisha IP Bridge 1 v. Seagate Technology LLC, Seagate Technology (US) Holding, Inc., Seagate Technology (Thailand) Limited, Seagate Singapore International Headquarters Ltd., Seagate Technology (Netherlands) B.V. On March 15, 2024, a patent infringement action was filed by Godo Kaisha IP Bridge 1 (“IP Bridge”) against Seagate in U.S. District Court for the District of Delaware. The case was subsequently transferred to the District Court of Minnesota on September 4, 2024. The complaint alleges patent infringement by Seagate of nine U.S. patents. The Company believes the asserted claims are without merit and intends to vigorously defend this case.

[0001137789-26-000088:notes:128]
BIS Settlement

[0001137789-26-000088:notes:129]
On April 18, 2023, the Company’s subsidiaries Seagate Technology LLC and Seagate Singapore International Headquarters Pte. Ltd (collectively, “Seagate”), entered into a settlement agreement (the “Settlement Agreement”) with the U.S. Department of Commerce’s Bureau of Industry and Security (“BIS”) that resolves BIS’ allegations regarding Seagate’s sales of hard disk drives to Huawei between August 17, 2020 and September 29, 2021. Under the terms of the Settlement Agreement, Seagate has agreed to pay $300 million to BIS in quarterly installments of $15 million over the course of five years beginning October 31, 2023. Seagate has also agreed to complete three audits of its compliance with the license requirements of Section 734.9 of the U.S. Export Administration Regulations (“EAR”), including one audit by an unaffiliated third-party consultant chosen by Seagate with expertise in U.S. export control laws and two internal audits.

[0001137789-26-000088:notes:130]
The Company accrued a charge of $300 million during fiscal year 2023, of which $45 million and $90 million were included in Accrued expense and Other non-current liabilities, respectively, on the Condensed Consolidated Balance Sheets as of April 3, 2026. For the nine months ended April 3, 2026, $60 million was paid and reported as an outflow from operating activities in its Condensed Consolidated Statements of Cash Flows.

[0001137789-26-000088:notes:131]
Environmental Matters

[0001137789-26-000088:notes:132]
The Company’s operations are subject to U.S. and foreign laws and regulations relating to the protection of the environment, including those governing discharges of pollutants into the air and water, the management and disposal of hazardous substances and wastes and the cleanup of contaminated sites. Some of the Company’s operations require environmental permits and controls to prevent and reduce air and water pollution, and these permits are subject to modification, renewal and revocation by issuing authorities.

[0001137789-26-000088:notes:133]
Some environmental laws, such as the Comprehensive Environmental Response Compensation and Liability Act of 1980 (as amended, the “Superfund” law) and its state equivalents, can impose liability for the cost of cleanup of contaminated sites upon any of the current or former site owners or operators or upon parties who sent waste to these sites, regardless of whether the owner or operator owned the site at the time of the release of hazardous substances or the lawfulness of the original disposal activity. The Company has been identified as a responsible or potentially responsible party at several sites. At each of these sites, the Company has an assigned portion of the financial liability based on the type and amount of hazardous substances disposed of by each party at the site and the number of financially viable parties. The Company has fulfilled its responsibilities at some of these sites and remains involved in only a few at this time.

[0001137789-26-000088:notes:134]
While the Company’s ultimate costs in connection with these sites is difficult to predict with complete accuracy, based on its current estimates of cleanup costs and its expected allocation of these costs, the Company does not expect costs in connection with these sites to be material.

[0001137789-26-000088:notes:135]
The Company may be subject to various state, federal and international laws and regulations governing the environment, including those restricting the presence of certain substances in electronic products. For example, the European Union (“EU”) enacted the Restriction of the Use of Certain Hazardous Substances in Electrical and Electronic Equipment (2011/65/EU), which prohibits the use of certain substances, including lead, in certain products, including disk drives and server storage products, put on the market after July 1, 2006. Similar legislation has been or may be enacted in other jurisdictions, including in the United States, Canada, Mexico, Taiwan, China, Japan and others. The EU REACH Directive (Registration, Evaluation, Authorization, and Restriction of Chemicals, EC 1907/2006) also restricts substances of very high concern in products. If the Company or its suppliers fail to comply with the substance restrictions, recycle content requirements or other environmental requirements as they are enacted worldwide, it could have a materially adverse effect on the Company’s business.

[0001137789-26-000088:notes:136]
Other Matters 
From time to time, arising in the normal course of business, the Company is involved in a number of other judicial, regulatory or administrative proceedings and investigations incidental to its business, and the Company expects to be involved in such proceedings and investigations arising in the normal course of its business in the future. Although occasional adverse decisions or settlements may occur, the Company believes that the final disposition of such matters will not have a material adverse effect on its financial position or results of operations.


## us-gaap:CommitmentsDisclosureTextBlock

[0001137789-26-000088:notes:137]
Commitments
Unconditional Long-Term Purchase Obligations. As of April 3, 2026, the Company had unconditional long-term purchase obligations of approximately $422 million. The Company expects the commitment to be paid to total $192 million, $204 million, $14 million, $11 million and $1 millon for fiscal years 2027, 2028, 2029, 2030 and thereafter. In addition, the Company also had certain long-term market share based inventory purchase commitments as of April 3, 2026.


## us-gaap:SubsequentEventsTextBlock

[0001137789-26-000088:notes:138]
Subsequent Events
Dividend Declared

[0001137789-26-000088:notes:139]
On April 28, 2026, the Board of Directors of the Company declared a quarterly cash dividend of $0.74 per share, which will be payable on July 7, 2026 to shareholders of record as of the close of business on June 24, 2026.


## ecd:MtrlTermsOfTrdArrTextBlock

[0001137789-26-000088:notes:140]
The table below summarizes the material terms of trading arrangements adopted by any of our executive officers or directors during the March 2026 quarter. All of the trading arrangements listed below are intended to satisfy the affirmative defense of Rule 10b5-1(c).

[0001137789-26-000088:notes:141]
| Name | Title | Date of Adoption | End Date¹ | Aggregate number of ordinary shares to be sold pursuant to the trading agreement |
| James C. Lee | Executive Vice President, Chief Legal Officer and Corporate Secretary | January 29, 2026 | January 29, 2027 | 19,958 |
| Dr. John C. Morris | Executive Vice President and Chief Technology Officer | January 29, 2026 | May 7, 2027 | 81,462 |
| Ban Seng Teh | Executive Vice President, Global Sales and Sales Operations | February 11, 2026 | February 11, 2027 | 54,366 |
| Dr. William D. Mosley | Board Chair and Chief Executive Officer | February 18, 2026 | April 30, 2027 | 360,000 |
| Prat S. Bhatt | Director | March 3, 2026 | May 31, 2027 | 2,580 |

[0001137789-26-000088:notes:142]
[same as prior period, unchanged from 0001137789-26-000026:notes:136]
